"""Freeze the authorized frontend diff and its verification/cleanup references."""

import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor/.worktree/othello-web129")
OUT = ROOT / ".artifacts/othello-web129"
evidence = json.loads((OUT / "evidence.json").read_text())
sources = evidence["source_refs"]
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
tracked = []
new = []
for item in sources:
    path = ROOT / item["path"]
    content = path.read_bytes()
    assert (
        hashlib.sha256(content).hexdigest(),
        len(content),
        f"{stat.S_IMODE(path.stat().st_mode):04o}",
    ) == (item["sha256"], item["bytes"], item["mode"])
    result = subprocess.run(
        ["git", "ls-files", "--error-unmatch", "--", item["path"]],
        cwd=ROOT,
        env=env,
        capture_output=True,
        check=False,
    )
    (tracked if result.returncode == 0 else new).append(item["path"])
result = subprocess.run(
    ["git", "diff", "--binary", "--no-ext-diff", "--", *tracked],
    cwd=ROOT,
    env=env,
    capture_output=True,
    check=True,
)
patch = bytearray(result.stdout)
subprocess.run(["git", "diff", "--check", "--", *tracked], cwd=ROOT, env=env, check=True)
for path in new:
    result = subprocess.run(
        ["git", "diff", "--no-index", "--binary", "--no-ext-diff", "--", "/dev/null", path],
        cwd=ROOT,
        env=env,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 1, (path, result.returncode, result.stderr)
    patch.extend(result.stdout)
    result = subprocess.run(
        ["git", "diff", "--no-index", "--check", "--", "/dev/null", path],
        cwd=ROOT,
        env=env,
        capture_output=True,
        check=False,
    )
    assert result.returncode in (0, 1) and not result.stdout and not result.stderr, (
        path,
        result.returncode,
        result.stderr,
        result.stdout,
    )
path = OUT / "source.patch"
path.write_bytes(patch)
path.chmod(0o644)
cleanup = []
for path in sorted(OUT.glob("*/command.process.json")):
    if path.parent.name == "source-freeze-repair":
        continue  # The enclosing execute writes this command's receipt after return.
    record = json.loads(path.read_text())
    assert (
        record["remaining"] == []
        and record["direct_child_reaped"]
        and record["process_cleanup_complete"]
        and record["handle_closes_complete"]
    ), str(path)
    cleanup.append(
        dict(
            path=str(path.relative_to(ROOT)),
            status=record["status"],
            wall_seconds=record["wall_seconds"],
            remaining=record["remaining"],
            reaped=record["direct_child_reaped"],
            cleanup=record["process_cleanup_complete"],
            handles=record["handle_closes_complete"],
        )
    )
resources = [json.loads(p.read_text()) for p in OUT.glob("*/resources.json")]
record = dict(
    issue="quoridor-4lc.324.12.9.7",
    owner="codex:01a15f23-0746-7953-a08b-9927d23d26f7",
    cwd=str(ROOT),
    base_source=evidence["base_source"],
    source_STOP=True,
    source_patch=dict(
        path=str(OUT / "source.patch"),
        sha256=hashlib.sha256(patch).hexdigest(),
        bytes=len(patch),
        mode="0644",
    ),
    source_refs=sources,
    proposal_patch="NONE: no common caller/config/manifest change needed",
    implementation="Othello-only Japanese accessible 8x8 UI, local2player and bounded nonlearning AI Worker; Rust API rules; strict independent versioned save; pending resume protects unreadable save; route-specific lazy imports and generation cancellation; Quoridor mount/source/settings/audio/keys unchanged",
    PASS=dict(
        direct_source_functional="22/22 unit-corrupt-fixed",
        typecheck="typecheck-handoff: actual WT declarations plus UI and authored e2e",
        vite="bundle-final, home lazy and distinct game/Worker/CSS chunks",
        browser_prior_source="5/6 first attempt; repaired long cross-game flow1/1; exact source/inputs in evidence-before-corrupt-fix.json",
        browser_final_source="new active-corrupt-resume regression1/1 browser-html; HTML GPU disabled by original contract",
        quality="prettier-handoff; ruff-format-check+ruff-handoff, plus freeze helper final checks",
    ),
    UNRUN=[
        "Rust/Clippy/real-Wasm unit acceptance already Root accepted; not replayed",
        "Old Quoridor scientific/numerical/model/solver/training/campaign suites",
        "Historical browser web-shell cases, not replayed",
        "Full 7-case browser suite on final source; final session-only save-preservation delta is covered by new regression and direct-source units",
    ],
    retained_failures=[
        "browser-first cross-game test-only45s timeout; trace/context untouched; causal120s repair leaves600s safety guard unchanged",
        "corrupt-active-original reproduced teardown overwriting unreadable save; fixed and verified",
        "normal-collection-final collector NameError; fixed in normal-collection-final-fixed without browser replay",
    ],
    actual_resources=dict(
        cpu_plan=resources[0]["cpu_plan"],
        family_limit_B=2147483648,
        controller_limit_B=67108864,
        child_limit_B=2080374784,
        hostreserve_B=4294967296,
        GPU=0,
        library_threads=1,
        peak_observed_family_RSS_B=max(r["peak_family_RSS_B"] for r in resources),
    ),
    cleanup=cleanup,
    browser_config_owner="Root; WHOLESTOP first/repair/html sent; no further browser/config access planned",
    git="Read commands only; no checkout/index/commit/push commands. Initial status emitted sparse-index expansion hint; subsequent Git reads use GIT_OPTIONAL_LOCKS=0.",
    next="Root accepts frozen patch, integrates/tests any common-caller changes, and closes issue; worker does not self-close",
)
(OUT / "handoff.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            patch=record["source_patch"],
            source_files=len(sources),
            command_records=len(cleanup),
            peak_RSS_B=record["actual_resources"]["peak_observed_family_RSS_B"],
        ),
        ensure_ascii=False,
    )
)
