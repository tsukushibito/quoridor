// 8036ab9928282c476d039a34cd3c4e0566e25de2
import { test, expect } from '@playwright/test';
const OTHELLO_SAVE = 'othello.game.v1';
const LEGACY_GAME = 'quoridor.m1.game.v1';
const LEGACY_SETTINGS = 'quoridor.m1.settings.v1';
const LEGACY_AUDIO = 'quoridor.audio.settings.v1';
const cell = (page, index) => page.locator(`.othello-cell[data-index="${index}"]`);
const openOthello = async page => {
  await page.locator('#choose-othello').click();
  await expect(page.locator('.othello h1')).toHaveText('Othello');
};
const leaveOthello = async page => {
  await page.getByRole('link', {
    name: 'ゲーム一覧へ戻る'
  }).click();
  await expect(page.locator('.home-page')).toBeVisible();
};
async function legacySlots(page) {
  return page.evaluate(([game, settings, audio]) => [game, settings, audio].map(key => localStorage.getItem(key)), [LEGACY_GAME, LEGACY_SETTINGS, LEGACY_AUDIO]);
}
async function savedOthello(page) {
  return page.evaluate(key => localStorage.getItem(key), OTHELLO_SAVE);
}
test('new cross-game flow plays and saves both games, resumes legacy and Othello slots, preserves history and basepath', async ({
  page
}) => {
  const requests = [],
    errors = [];
  page.on('request', request => requests.push(request.url()));
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('./?forceWebGL=1#/');
  await expect(page.locator('#choose-othello')).toBeVisible();
  expect(requests.filter(url => /\.wasm|ai\.worker|quoridor-|othello-|\.hdr|\.mp3|\.ogg/.test(url))).toEqual([]);
  await page.locator('#choose-quoridor').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_DI;
    return (_window$__QUORIDOR_DI = window.__QUORIDOR_DIAGNOSTICS__) === null || _window$__QUORIDOR_DI === void 0 ? void 0 : _window$__QUORIDOR_DI.phase;
  })).toBe('ready');
  await page.locator('#startup-new-game').click();
  await page.locator('#match-mode').selectOption('pvp');
  await page.locator('#dialog-start').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_AP;
    return (_window$__QUORIDOR_AP = window.__QUORIDOR_APP_TEST_API__) === null || _window$__QUORIDOR_AP === void 0 ? void 0 : _window$__QUORIDOR_AP.state().phase;
  })).toBe('humanTurn');
  const point = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__.projectCell(13));
  await page.mouse.click(point.x, point.y);
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_AP2;
    return (_window$__QUORIDOR_AP2 = window.__QUORIDOR_APP_TEST_API__) === null || _window$__QUORIDOR_AP2 === void 0 || (_window$__QUORIDOR_AP2 = _window$__QUORIDOR_AP2.state().view) === null || _window$__QUORIDOR_AP2 === void 0 ? void 0 : _window$__QUORIDOR_AP2.ply;
  })).toBe(1);
  const replay = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__.exportReplay());
  await page.locator('.top-actions .home-link').click();
  await expect(page.locator('.home-page')).toBeVisible();
  const legacy = await legacySlots(page);
  expect(legacy[0]).toBeTruthy();
  await openOthello(page);
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 2 石 ／ 白 2 石');
  await cell(page, 19).click();
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(cell(page, 27)).toHaveAttribute('data-stone', '1');
  const othello = await savedOthello(page);
  await page.screenshot({
    path: test.info().outputPath('othello-play.png')
  });
  await leaveOthello(page);
  expect(await legacySlots(page)).toEqual(legacy);
  await page.locator('#choose-quoridor').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_DI2;
    return (_window$__QUORIDOR_DI2 = window.__QUORIDOR_DIAGNOSTICS__) === null || _window$__QUORIDOR_DI2 === void 0 ? void 0 : _window$__QUORIDOR_DI2.phase;
  })).toBe('ready');
  await page.locator('#resume-game-choice').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_AP3;
    return (_window$__QUORIDOR_AP3 = window.__QUORIDOR_APP_TEST_API__) === null || _window$__QUORIDOR_AP3 === void 0 ? void 0 : _window$__QUORIDOR_AP3.state().phase;
  })).toBe('humanTurn');
  expect(await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__.exportReplay())).toEqual(replay);
  expect(await savedOthello(page)).toBe(othello);
  await page.locator('.top-actions .home-link').click();
  await openOthello(page);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(page.locator('#othello-players')).toContainText('ローカル2人');
  await page.goBack();
  await expect(page.locator('.home-page')).toBeVisible();
  await page.goForward();
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-turn')).toHaveText('白の手番');
  await page.goto('./?forceWebGL=1#/othello');
  expect(new URL(page.url()).pathname).toBe(new URL(test.info().project.use.baseURL).pathname);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(page.locator('canvas, dialog')).toHaveCount(0);
  expect(errors).toEqual([]);
});
test('Othello-only entry remains lazy on home, keyboard play and real bounded AI use explicit human colors', async ({
  page
}) => {
  await page.setViewportSize({
    width: 375,
    height: 812
  });
  const workers = [];
  page.on('worker', worker => workers.push(worker.url()));
  await page.goto('./#/');
  await openOthello(page);
  expect(workers).toEqual([]);
  await page.locator('#othello-new').click();
  await expect(cell(page, 19)).toHaveAttribute('aria-disabled', 'false');
  await cell(page, 19).focus();
  await page.keyboard.press('ArrowRight');
  await expect(cell(page, 20)).toBeFocused();
  await page.keyboard.press('ArrowLeft');
  await page.keyboard.press('Enter');
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.locator('#othello-mode').selectOption('ai');
  await page.locator('#othello-human-side').selectOption('2');
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-players')).toHaveText('簡易AI（非学習）と対戦 · 人間：白 ／ 簡易AI：黒');
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(page.locator('#othello-turn')).toHaveText('白の手番');
  expect(workers).toHaveLength(1);
  await expect(cell(page, 19)).toHaveAttribute('data-stone', '1');
  await leaveOthello(page);
  await openOthello(page);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-players')).toContainText('人間：白 ／ 簡易AI：黒');
  await expect(page.locator('#othello-turn')).toHaveText('白の手番');
  expect(workers).toHaveLength(1);
});
test('Othello Worker pending cancellation terminates once and rejects a deliberately late message without mutation or legacy writes', async ({
  page
}) => {
  await page.addInitScript(() => {
    const Native = window.Worker;
    const monitor = {
      starts: 0,
      stops: 0,
      late: () => {}
    };
    window.othelloWorker = monitor;
    window.Worker = class extends Native {
      postMessage(message) {
        monitor.starts++;
        const callback = this.savedCallback;
        monitor.late = () => callback(new MessageEvent('message', {
          data: {
            id: message.id,
            generation: message.generation,
            ok: true,
            move: 19
          }
        }));
        // Keep the real game-owned Worker pending; deliver the captured callback after teardown.
      }
      addEventListener(type, callback, options) {
        if (type === 'message') this.savedCallback = callback;
        super.addEventListener(type, callback, options);
      }
      terminate() {
        monitor.stops++;
        super.terminate();
      }
    };
    localStorage.setItem('quoridor.m1.game.v1', 'legacy sentinel');
    localStorage.setItem('quoridor.m1.settings.v1', 'settings sentinel');
    localStorage.setItem('quoridor.audio.settings.v1', 'audio sentinel');
  });
  await page.goto('./#/othello');
  const legacy = await legacySlots(page);
  await page.locator('#othello-mode').selectOption('ai');
  await page.locator('#othello-human-side').selectOption('2');
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-turn')).toContainText('考えています');
  const confirmed = await savedOthello(page);
  await leaveOthello(page);
  await page.evaluate(() => window.othelloWorker.late());
  await expect(page.locator('.othello, .othello-board, canvas')).toHaveCount(0);
  expect(await savedOthello(page)).toBe(confirmed);
  expect(await legacySlots(page)).toEqual(legacy);
  expect(await page.evaluate(() => ({
    starts: window.othelloWorker.starts,
    stops: window.othelloWorker.stops
  }))).toEqual({
    starts: 1,
    stops: 1
  });
});
test('leaving Othello during actual Wasm initialization cannot save or render the late result', async ({
  page
}) => {
  let release, requested;
  const gate = new Promise(resolve => {
    release = resolve;
  });
  const reached = new Promise(resolve => {
    requested = resolve;
  });
  await page.route('**/*othello_bg*.wasm', async route => {
    requested();
    await gate;
    await route.continue();
  });
  await page.goto('./#/othello');
  await page.locator('#othello-new').click();
  await reached;
  await leaveOthello(page);
  release();
  await page.waitForLoadState('networkidle');
  await expect(page.locator('.othello, .othello-board')).toHaveCount(0);
  expect(await savedOthello(page)).toBeNull();
});
test('bad saves are retained, retry and explicit new are available, unavailable storage is visible through exit', async ({
  page
}) => {
  await page.goto('./#/othello');
  await page.evaluate(key => localStorage.setItem(key, '{broken'), OTHELLO_SAVE);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-error')).not.toBeEmpty();
  expect(await savedOthello(page)).toBe('{broken');
  await page.locator('#othello-resume').click();
  expect(await savedOthello(page)).toBe('{broken');
  // The user's explicit new selection authorizes replacing the broken Othello slot.
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 2 石 ／ 白 2 石');
  await page.evaluate(() => {
    Storage.prototype.setItem = () => {
      throw new DOMException('quota', 'QuotaExceededError');
    };
  });
  await cell(page, 19).click();
  await expect(page.locator('#othello-save-status')).toContainText('保存できません');
  await leaveOthello(page);
  await expect(page.locator('#home-save-warning')).toContainText('Othelloを保存できません');
});
test('saved forced-pass and terminal fixtures render Rust status, wins and draw without JS rules', async ({
  page
}) => {
  await page.goto('./#/othello');
  async function resume(board, toMove) {
    await page.evaluate(({
      key,
      board,
      toMove
    }) => localStorage.setItem(key, JSON.stringify({
      version: 1,
      game: 'othello',
      mode: 'local',
      humanSide: 1,
      state: {
        version: 1,
        board,
        toMove
      }
    })), {
      key: OTHELLO_SAVE,
      board,
      toMove
    });
    await page.locator('#othello-resume').click();
  }
  const forced = Array(64).fill(0);
  forced[0] = 1;
  forced[1] = 2;
  await resume(forced, 2);
  await expect(page.locator('#othello-guide')).toContainText('パスが必要');
  await page.locator('#othello-pass').click();
  await expect(page.locator('#othello-turn')).toHaveText('黒の手番');
  await cell(page, 2).click();
  await expect(page.locator('#othello-turn')).toHaveText('終局：黒の勝ち');
  await expect(page.locator('#othello-score')).toHaveText('黒 3 石 ／ 白 0 石');
  await resume(Array(64).fill(2), 1);
  await expect(page.locator('#othello-turn')).toHaveText('終局：白の勝ち');
  await resume(Array.from({
    length: 64
  }, (_, i) => i < 32 ? 1 : 2), 2);
  await expect(page.locator('#othello-turn')).toHaveText('終局：引分け');
  await expect(page.locator('#othello-pass')).toBeHidden();
  expect(await page.locator('.othello-cell[aria-disabled="false"]').count()).toBe(0);
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ0ZXN0IiwiZXhwZWN0IiwiT1RIRUxMT19TQVZFIiwiTEVHQUNZX0dBTUUiLCJMRUdBQ1lfU0VUVElOR1MiLCJMRUdBQ1lfQVVESU8iLCJjZWxsIiwicGFnZSIsImluZGV4IiwibG9jYXRvciIsIm9wZW5PdGhlbGxvIiwiY2xpY2siLCJ0b0hhdmVUZXh0IiwibGVhdmVPdGhlbGxvIiwiZ2V0QnlSb2xlIiwibmFtZSIsInRvQmVWaXNpYmxlIiwibGVnYWN5U2xvdHMiLCJldmFsdWF0ZSIsImdhbWUiLCJzZXR0aW5ncyIsImF1ZGlvIiwibWFwIiwia2V5IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInNhdmVkT3RoZWxsbyIsInJlcXVlc3RzIiwiZXJyb3JzIiwib24iLCJyZXF1ZXN0IiwicHVzaCIsInVybCIsImVycm9yIiwibWVzc2FnZSIsImdvdG8iLCJmaWx0ZXIiLCJ0b0VxdWFsIiwicG9sbCIsIl93aW5kb3ckX19RVU9SSURPUl9ESSIsIndpbmRvdyIsIl9fUVVPUklET1JfRElBR05PU1RJQ1NfXyIsInBoYXNlIiwidG9CZSIsInNlbGVjdE9wdGlvbiIsIl93aW5kb3ckX19RVU9SSURPUl9BUCIsIl9fUVVPUklET1JfQVBQX1RFU1RfQVBJX18iLCJzdGF0ZSIsInBvaW50IiwicHJvamVjdENlbGwiLCJtb3VzZSIsIngiLCJ5IiwiX3dpbmRvdyRfX1FVT1JJRE9SX0FQMiIsInZpZXciLCJwbHkiLCJyZXBsYXkiLCJleHBvcnRSZXBsYXkiLCJsZWdhY3kiLCJ0b0JlVHJ1dGh5IiwidG9IYXZlQXR0cmlidXRlIiwib3RoZWxsbyIsInNjcmVlbnNob3QiLCJwYXRoIiwiaW5mbyIsIm91dHB1dFBhdGgiLCJfd2luZG93JF9fUVVPUklET1JfREkyIiwiX3dpbmRvdyRfX1FVT1JJRE9SX0FQMyIsInRvQ29udGFpblRleHQiLCJnb0JhY2siLCJnb0ZvcndhcmQiLCJVUkwiLCJwYXRobmFtZSIsInByb2plY3QiLCJ1c2UiLCJiYXNlVVJMIiwidG9IYXZlQ291bnQiLCJzZXRWaWV3cG9ydFNpemUiLCJ3aWR0aCIsImhlaWdodCIsIndvcmtlcnMiLCJ3b3JrZXIiLCJmb2N1cyIsImtleWJvYXJkIiwicHJlc3MiLCJ0b0JlRm9jdXNlZCIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50Iiwic2Nyb2xsV2lkdGgiLCJpbm5lcldpZHRoIiwidG9IYXZlTGVuZ3RoIiwiYWRkSW5pdFNjcmlwdCIsIk5hdGl2ZSIsIldvcmtlciIsIm1vbml0b3IiLCJzdGFydHMiLCJzdG9wcyIsImxhdGUiLCJvdGhlbGxvV29ya2VyIiwicG9zdE1lc3NhZ2UiLCJjYWxsYmFjayIsInNhdmVkQ2FsbGJhY2siLCJNZXNzYWdlRXZlbnQiLCJkYXRhIiwiaWQiLCJnZW5lcmF0aW9uIiwib2siLCJtb3ZlIiwiYWRkRXZlbnRMaXN0ZW5lciIsInR5cGUiLCJvcHRpb25zIiwidGVybWluYXRlIiwic2V0SXRlbSIsImNvbmZpcm1lZCIsInJlbGVhc2UiLCJyZXF1ZXN0ZWQiLCJnYXRlIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWFjaGVkIiwicm91dGUiLCJjb250aW51ZSIsIndhaXRGb3JMb2FkU3RhdGUiLCJ0b0JlTnVsbCIsIm5vdCIsInRvQmVFbXB0eSIsIlN0b3JhZ2UiLCJwcm90b3R5cGUiLCJET01FeGNlcHRpb24iLCJyZXN1bWUiLCJib2FyZCIsInRvTW92ZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJ2ZXJzaW9uIiwibW9kZSIsImh1bWFuU2lkZSIsImZvcmNlZCIsIkFycmF5IiwiZmlsbCIsImZyb20iLCJsZW5ndGgiLCJfIiwiaSIsInRvQmVIaWRkZW4iLCJjb3VudCJdLCJzb3VyY2VzIjpbIm11bHRpLWdhbWUtc2hlbGwuc3BlYy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0ZXN0LCBleHBlY3QsIHR5cGUgUGFnZSB9IGZyb20gJ0BwbGF5d3JpZ2h0L3Rlc3QnO1xuXG5jb25zdCBPVEhFTExPX1NBVkUgPSAnb3RoZWxsby5nYW1lLnYxJztcbmNvbnN0IExFR0FDWV9HQU1FID0gJ3F1b3JpZG9yLm0xLmdhbWUudjEnO1xuY29uc3QgTEVHQUNZX1NFVFRJTkdTID0gJ3F1b3JpZG9yLm0xLnNldHRpbmdzLnYxJztcbmNvbnN0IExFR0FDWV9BVURJTyA9ICdxdW9yaWRvci5hdWRpby5zZXR0aW5ncy52MSc7XG5jb25zdCBjZWxsID0gKHBhZ2U6IFBhZ2UsIGluZGV4OiBudW1iZXIpID0+IHBhZ2UubG9jYXRvcihgLm90aGVsbG8tY2VsbFtkYXRhLWluZGV4PVwiJHtpbmRleH1cIl1gKTtcbmNvbnN0IG9wZW5PdGhlbGxvID0gYXN5bmMgKHBhZ2U6IFBhZ2UpID0+IHtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjY2hvb3NlLW90aGVsbG8nKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcub3RoZWxsbyBoMScpKS50b0hhdmVUZXh0KCdPdGhlbGxvJyk7XG59O1xuY29uc3QgbGVhdmVPdGhlbGxvID0gYXN5bmMgKHBhZ2U6IFBhZ2UpID0+IHtcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2xpbmsnLCB7IG5hbWU6ICfjgrLjg7zjg6DkuIDopqfjgbjmiLvjgosnIH0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ob21lLXBhZ2UnKSkudG9CZVZpc2libGUoKTtcbn07XG5hc3luYyBmdW5jdGlvbiBsZWdhY3lTbG90cyhwYWdlOiBQYWdlKSB7XG4gIHJldHVybiBwYWdlLmV2YWx1YXRlKFxuICAgIChbZ2FtZSwgc2V0dGluZ3MsIGF1ZGlvXSkgPT4gW2dhbWUsIHNldHRpbmdzLCBhdWRpb10ubWFwKChrZXkpID0+IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSEpKSxcbiAgICBbTEVHQUNZX0dBTUUsIExFR0FDWV9TRVRUSU5HUywgTEVHQUNZX0FVRElPXSxcbiAgKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHNhdmVkT3RoZWxsbyhwYWdlOiBQYWdlKSB7XG4gIHJldHVybiBwYWdlLmV2YWx1YXRlKChrZXkpID0+IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSksIE9USEVMTE9fU0FWRSk7XG59XG5cbnRlc3QoJ25ldyBjcm9zcy1nYW1lIGZsb3cgcGxheXMgYW5kIHNhdmVzIGJvdGggZ2FtZXMsIHJlc3VtZXMgbGVnYWN5IGFuZCBPdGhlbGxvIHNsb3RzLCBwcmVzZXJ2ZXMgaGlzdG9yeSBhbmQgYmFzZXBhdGgnLCBhc3luYyAoe1xuICBwYWdlLFxufSkgPT4ge1xuICBjb25zdCByZXF1ZXN0czogc3RyaW5nW10gPSBbXSxcbiAgICBlcnJvcnM6IHN0cmluZ1tdID0gW107XG4gIHBhZ2Uub24oJ3JlcXVlc3QnLCAocmVxdWVzdCkgPT4gcmVxdWVzdHMucHVzaChyZXF1ZXN0LnVybCgpKSk7XG4gIHBhZ2Uub24oJ3BhZ2VlcnJvcicsIChlcnJvcikgPT4gZXJyb3JzLnB1c2goZXJyb3IubWVzc2FnZSkpO1xuICBhd2FpdCBwYWdlLmdvdG8oJy4vP2ZvcmNlV2ViR0w9MSMvJyk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNjaG9vc2Utb3RoZWxsbycpKS50b0JlVmlzaWJsZSgpO1xuICBleHBlY3QoXG4gICAgcmVxdWVzdHMuZmlsdGVyKCh1cmwpID0+IC9cXC53YXNtfGFpXFwud29ya2VyfHF1b3JpZG9yLXxvdGhlbGxvLXxcXC5oZHJ8XFwubXAzfFxcLm9nZy8udGVzdCh1cmwpKSxcbiAgKS50b0VxdWFsKFtdKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjY2hvb3NlLXF1b3JpZG9yJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0XG4gICAgLnBvbGwoKCkgPT4gcGFnZS5ldmFsdWF0ZSgoKSA9PiB3aW5kb3cuX19RVU9SSURPUl9ESUFHTk9TVElDU19fPy5waGFzZSkpXG4gICAgLnRvQmUoJ3JlYWR5Jyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI3N0YXJ0dXAtbmV3LWdhbWUnKS5jbGljaygpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNtYXRjaC1tb2RlJykuc2VsZWN0T3B0aW9uKCdwdnAnKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjZGlhbG9nLXN0YXJ0JykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0XG4gICAgLnBvbGwoKCkgPT4gcGFnZS5ldmFsdWF0ZSgoKSA9PiB3aW5kb3cuX19RVU9SSURPUl9BUFBfVEVTVF9BUElfXz8uc3RhdGUoKS5waGFzZSkpXG4gICAgLnRvQmUoJ2h1bWFuVHVybicpO1xuICBjb25zdCBwb2ludCA9IGF3YWl0IHBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93Ll9fUVVPUklET1JfQVBQX1RFU1RfQVBJX18hLnByb2plY3RDZWxsKDEzKSk7XG4gIGF3YWl0IHBhZ2UubW91c2UuY2xpY2socG9pbnQueCwgcG9pbnQueSk7XG4gIGF3YWl0IGV4cGVjdFxuICAgIC5wb2xsKCgpID0+IHBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93Ll9fUVVPUklET1JfQVBQX1RFU1RfQVBJX18/LnN0YXRlKCkudmlldz8ucGx5KSlcbiAgICAudG9CZSgxKTtcbiAgY29uc3QgcmVwbGF5ID0gYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiB3aW5kb3cuX19RVU9SSURPUl9BUFBfVEVTVF9BUElfXyEuZXhwb3J0UmVwbGF5KCkpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJy50b3AtYWN0aW9ucyAuaG9tZS1saW5rJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLmhvbWUtcGFnZScpKS50b0JlVmlzaWJsZSgpO1xuICBjb25zdCBsZWdhY3kgPSBhd2FpdCBsZWdhY3lTbG90cyhwYWdlKTtcbiAgZXhwZWN0KGxlZ2FjeVswXSkudG9CZVRydXRoeSgpO1xuICBhd2FpdCBvcGVuT3RoZWxsbyhwYWdlKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1uZXcnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1zY29yZScpKS50b0hhdmVUZXh0KCfpu5IgMiDnn7Mg77yPIOeZvSAyIOefsycpO1xuICBhd2FpdCBjZWxsKHBhZ2UsIDE5KS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1zY29yZScpKS50b0hhdmVUZXh0KCfpu5IgNCDnn7Mg77yPIOeZvSAxIOefsycpO1xuICBhd2FpdCBleHBlY3QoY2VsbChwYWdlLCAyNykpLnRvSGF2ZUF0dHJpYnV0ZSgnZGF0YS1zdG9uZScsICcxJyk7XG4gIGNvbnN0IG90aGVsbG8gPSBhd2FpdCBzYXZlZE90aGVsbG8ocGFnZSk7XG4gIGF3YWl0IHBhZ2Uuc2NyZWVuc2hvdCh7IHBhdGg6IHRlc3QuaW5mbygpLm91dHB1dFBhdGgoJ290aGVsbG8tcGxheS5wbmcnKSB9KTtcbiAgYXdhaXQgbGVhdmVPdGhlbGxvKHBhZ2UpO1xuICBleHBlY3QoYXdhaXQgbGVnYWN5U2xvdHMocGFnZSkpLnRvRXF1YWwobGVnYWN5KTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjY2hvb3NlLXF1b3JpZG9yJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0XG4gICAgLnBvbGwoKCkgPT4gcGFnZS5ldmFsdWF0ZSgoKSA9PiB3aW5kb3cuX19RVU9SSURPUl9ESUFHTk9TVElDU19fPy5waGFzZSkpXG4gICAgLnRvQmUoJ3JlYWR5Jyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI3Jlc3VtZS1nYW1lLWNob2ljZScpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdFxuICAgIC5wb2xsKCgpID0+IHBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93Ll9fUVVPUklET1JfQVBQX1RFU1RfQVBJX18/LnN0YXRlKCkucGhhc2UpKVxuICAgIC50b0JlKCdodW1hblR1cm4nKTtcbiAgZXhwZWN0KGF3YWl0IHBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93Ll9fUVVPUklET1JfQVBQX1RFU1RfQVBJX18hLmV4cG9ydFJlcGxheSgpKSkudG9FcXVhbChcbiAgICByZXBsYXksXG4gICk7XG4gIGV4cGVjdChhd2FpdCBzYXZlZE90aGVsbG8ocGFnZSkpLnRvQmUob3RoZWxsbyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignLnRvcC1hY3Rpb25zIC5ob21lLWxpbmsnKS5jbGljaygpO1xuICBhd2FpdCBvcGVuT3RoZWxsbyhwYWdlKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1yZXN1bWUnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1zY29yZScpKS50b0hhdmVUZXh0KCfpu5IgNCDnn7Mg77yPIOeZvSAxIOefsycpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1wbGF5ZXJzJykpLnRvQ29udGFpblRleHQoJ+ODreODvOOCq+ODqzLkuronKTtcbiAgYXdhaXQgcGFnZS5nb0JhY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLmhvbWUtcGFnZScpKS50b0JlVmlzaWJsZSgpO1xuICBhd2FpdCBwYWdlLmdvRm9yd2FyZCgpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXJlc3VtZScpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXR1cm4nKSkudG9IYXZlVGV4dCgn55m944Gu5omL55WqJyk7XG4gIGF3YWl0IHBhZ2UuZ290bygnLi8/Zm9yY2VXZWJHTD0xIy9vdGhlbGxvJyk7XG4gIGV4cGVjdChuZXcgVVJMKHBhZ2UudXJsKCkpLnBhdGhuYW1lKS50b0JlKG5ldyBVUkwodGVzdC5pbmZvKCkucHJvamVjdC51c2UuYmFzZVVSTCEpLnBhdGhuYW1lKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1yZXN1bWUnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1zY29yZScpKS50b0hhdmVUZXh0KCfpu5IgNCDnn7Mg77yPIOeZvSAxIOefsycpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCdjYW52YXMsIGRpYWxvZycpKS50b0hhdmVDb3VudCgwKTtcbiAgZXhwZWN0KGVycm9ycykudG9FcXVhbChbXSk7XG59KTtcblxudGVzdCgnT3RoZWxsby1vbmx5IGVudHJ5IHJlbWFpbnMgbGF6eSBvbiBob21lLCBrZXlib2FyZCBwbGF5IGFuZCByZWFsIGJvdW5kZWQgQUkgdXNlIGV4cGxpY2l0IGh1bWFuIGNvbG9ycycsIGFzeW5jICh7XG4gIHBhZ2UsXG59KSA9PiB7XG4gIGF3YWl0IHBhZ2Uuc2V0Vmlld3BvcnRTaXplKHsgd2lkdGg6IDM3NSwgaGVpZ2h0OiA4MTIgfSk7XG4gIGNvbnN0IHdvcmtlcnM6IHN0cmluZ1tdID0gW107XG4gIHBhZ2Uub24oJ3dvcmtlcicsICh3b3JrZXIpID0+IHdvcmtlcnMucHVzaCh3b3JrZXIudXJsKCkpKTtcbiAgYXdhaXQgcGFnZS5nb3RvKCcuLyMvJyk7XG4gIGF3YWl0IG9wZW5PdGhlbGxvKHBhZ2UpO1xuICBleHBlY3Qod29ya2VycykudG9FcXVhbChbXSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tbmV3JykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KGNlbGwocGFnZSwgMTkpKS50b0hhdmVBdHRyaWJ1dGUoJ2FyaWEtZGlzYWJsZWQnLCAnZmFsc2UnKTtcbiAgYXdhaXQgY2VsbChwYWdlLCAxOSkuZm9jdXMoKTtcbiAgYXdhaXQgcGFnZS5rZXlib2FyZC5wcmVzcygnQXJyb3dSaWdodCcpO1xuICBhd2FpdCBleHBlY3QoY2VsbChwYWdlLCAyMCkpLnRvQmVGb2N1c2VkKCk7XG4gIGF3YWl0IHBhZ2Uua2V5Ym9hcmQucHJlc3MoJ0Fycm93TGVmdCcpO1xuICBhd2FpdCBwYWdlLmtleWJvYXJkLnByZXNzKCdFbnRlcicpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1zY29yZScpKS50b0hhdmVUZXh0KCfpu5IgNCDnn7Mg77yPIOeZvSAxIOefsycpO1xuICBleHBlY3QoYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsV2lkdGggPD0gaW5uZXJXaWR0aCkpLnRvQmUodHJ1ZSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tbW9kZScpLnNlbGVjdE9wdGlvbignYWknKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1odW1hbi1zaWRlJykuc2VsZWN0T3B0aW9uKCcyJyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tbmV3JykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tcGxheWVycycpKS50b0hhdmVUZXh0KFxuICAgICfnsKHmmJNBSe+8iOmdnuWtpue/ku+8ieOBqOWvvuaIpiDCtyDkurrplpPvvJrnmb0g77yPIOewoeaYk0FJ77ya6buSJyxcbiAgKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tc2NvcmUnKSkudG9IYXZlVGV4dCgn6buSIDQg55+zIO+8jyDnmb0gMSDnn7MnKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tdHVybicpKS50b0hhdmVUZXh0KCfnmb3jga7miYvnlaonKTtcbiAgZXhwZWN0KHdvcmtlcnMpLnRvSGF2ZUxlbmd0aCgxKTtcbiAgYXdhaXQgZXhwZWN0KGNlbGwocGFnZSwgMTkpKS50b0hhdmVBdHRyaWJ1dGUoJ2RhdGEtc3RvbmUnLCAnMScpO1xuICBhd2FpdCBsZWF2ZU90aGVsbG8ocGFnZSk7XG4gIGF3YWl0IG9wZW5PdGhlbGxvKHBhZ2UpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXJlc3VtZScpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXBsYXllcnMnKSkudG9Db250YWluVGV4dCgn5Lq66ZaT77ya55m9IO+8jyDnsKHmmJNBSe+8mum7kicpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby10dXJuJykpLnRvSGF2ZVRleHQoJ+eZveOBruaJi+eVqicpO1xuICBleHBlY3Qod29ya2VycykudG9IYXZlTGVuZ3RoKDEpO1xufSk7XG5cbnRlc3QoJ090aGVsbG8gV29ya2VyIHBlbmRpbmcgY2FuY2VsbGF0aW9uIHRlcm1pbmF0ZXMgb25jZSBhbmQgcmVqZWN0cyBhIGRlbGliZXJhdGVseSBsYXRlIG1lc3NhZ2Ugd2l0aG91dCBtdXRhdGlvbiBvciBsZWdhY3kgd3JpdGVzJywgYXN5bmMgKHtcbiAgcGFnZSxcbn0pID0+IHtcbiAgYXdhaXQgcGFnZS5hZGRJbml0U2NyaXB0KCgpID0+IHtcbiAgICBjb25zdCBOYXRpdmUgPSB3aW5kb3cuV29ya2VyO1xuICAgIGNvbnN0IG1vbml0b3IgPSB7IHN0YXJ0czogMCwgc3RvcHM6IDAsIGxhdGU6ICgpID0+IHt9IH07XG4gICAgKHdpbmRvdyBhcyBhbnkpLm90aGVsbG9Xb3JrZXIgPSBtb25pdG9yO1xuICAgIHdpbmRvdy5Xb3JrZXIgPSBjbGFzcyBleHRlbmRzIE5hdGl2ZSB7XG4gICAgICBvdmVycmlkZSBwb3N0TWVzc2FnZShtZXNzYWdlOiBhbnkpOiB2b2lkIHtcbiAgICAgICAgbW9uaXRvci5zdGFydHMrKztcbiAgICAgICAgY29uc3QgY2FsbGJhY2sgPSAodGhpcyBhcyBhbnkpLnNhdmVkQ2FsbGJhY2s7XG4gICAgICAgIG1vbml0b3IubGF0ZSA9ICgpID0+XG4gICAgICAgICAgY2FsbGJhY2soXG4gICAgICAgICAgICBuZXcgTWVzc2FnZUV2ZW50KCdtZXNzYWdlJywge1xuICAgICAgICAgICAgICBkYXRhOiB7IGlkOiBtZXNzYWdlLmlkLCBnZW5lcmF0aW9uOiBtZXNzYWdlLmdlbmVyYXRpb24sIG9rOiB0cnVlLCBtb3ZlOiAxOSB9LFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgKTtcbiAgICAgICAgLy8gS2VlcCB0aGUgcmVhbCBnYW1lLW93bmVkIFdvcmtlciBwZW5kaW5nOyBkZWxpdmVyIHRoZSBjYXB0dXJlZCBjYWxsYmFjayBhZnRlciB0ZWFyZG93bi5cbiAgICAgIH1cbiAgICAgIG92ZXJyaWRlIGFkZEV2ZW50TGlzdGVuZXIodHlwZTogYW55LCBjYWxsYmFjazogYW55LCBvcHRpb25zPzogYW55KTogdm9pZCB7XG4gICAgICAgIGlmICh0eXBlID09PSAnbWVzc2FnZScpICh0aGlzIGFzIGFueSkuc2F2ZWRDYWxsYmFjayA9IGNhbGxiYWNrO1xuICAgICAgICBzdXBlci5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGNhbGxiYWNrLCBvcHRpb25zKTtcbiAgICAgIH1cbiAgICAgIG92ZXJyaWRlIHRlcm1pbmF0ZSgpOiB2b2lkIHtcbiAgICAgICAgbW9uaXRvci5zdG9wcysrO1xuICAgICAgICBzdXBlci50ZXJtaW5hdGUoKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdxdW9yaWRvci5tMS5nYW1lLnYxJywgJ2xlZ2FjeSBzZW50aW5lbCcpO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdxdW9yaWRvci5tMS5zZXR0aW5ncy52MScsICdzZXR0aW5ncyBzZW50aW5lbCcpO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdxdW9yaWRvci5hdWRpby5zZXR0aW5ncy52MScsICdhdWRpbyBzZW50aW5lbCcpO1xuICB9KTtcbiAgYXdhaXQgcGFnZS5nb3RvKCcuLyMvb3RoZWxsbycpO1xuICBjb25zdCBsZWdhY3kgPSBhd2FpdCBsZWdhY3lTbG90cyhwYWdlKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1tb2RlJykuc2VsZWN0T3B0aW9uKCdhaScpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLWh1bWFuLXNpZGUnKS5zZWxlY3RPcHRpb24oJzInKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1uZXcnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby10dXJuJykpLnRvQ29udGFpblRleHQoJ+iAg+OBiOOBpuOBhOOBvuOBmScpO1xuICBjb25zdCBjb25maXJtZWQgPSBhd2FpdCBzYXZlZE90aGVsbG8ocGFnZSk7XG4gIGF3YWl0IGxlYXZlT3RoZWxsbyhwYWdlKTtcbiAgYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiAod2luZG93IGFzIGFueSkub3RoZWxsb1dvcmtlci5sYXRlKCkpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcub3RoZWxsbywgLm90aGVsbG8tYm9hcmQsIGNhbnZhcycpKS50b0hhdmVDb3VudCgwKTtcbiAgZXhwZWN0KGF3YWl0IHNhdmVkT3RoZWxsbyhwYWdlKSkudG9CZShjb25maXJtZWQpO1xuICBleHBlY3QoYXdhaXQgbGVnYWN5U2xvdHMocGFnZSkpLnRvRXF1YWwobGVnYWN5KTtcbiAgZXhwZWN0KFxuICAgIGF3YWl0IHBhZ2UuZXZhbHVhdGUoKCkgPT4gKHtcbiAgICAgIHN0YXJ0czogKHdpbmRvdyBhcyBhbnkpLm90aGVsbG9Xb3JrZXIuc3RhcnRzLFxuICAgICAgc3RvcHM6ICh3aW5kb3cgYXMgYW55KS5vdGhlbGxvV29ya2VyLnN0b3BzLFxuICAgIH0pKSxcbiAgKS50b0VxdWFsKHsgc3RhcnRzOiAxLCBzdG9wczogMSB9KTtcbn0pO1xuXG50ZXN0KCdsZWF2aW5nIE90aGVsbG8gZHVyaW5nIGFjdHVhbCBXYXNtIGluaXRpYWxpemF0aW9uIGNhbm5vdCBzYXZlIG9yIHJlbmRlciB0aGUgbGF0ZSByZXN1bHQnLCBhc3luYyAoe1xuICBwYWdlLFxufSkgPT4ge1xuICBsZXQgcmVsZWFzZSE6ICgpID0+IHZvaWQsIHJlcXVlc3RlZCE6ICgpID0+IHZvaWQ7XG4gIGNvbnN0IGdhdGUgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuICAgIHJlbGVhc2UgPSByZXNvbHZlO1xuICB9KTtcbiAgY29uc3QgcmVhY2hlZCA9IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiB7XG4gICAgcmVxdWVzdGVkID0gcmVzb2x2ZTtcbiAgfSk7XG4gIGF3YWl0IHBhZ2Uucm91dGUoJyoqLypvdGhlbGxvX2JnKi53YXNtJywgYXN5bmMgKHJvdXRlKSA9PiB7XG4gICAgcmVxdWVzdGVkKCk7XG4gICAgYXdhaXQgZ2F0ZTtcbiAgICBhd2FpdCByb3V0ZS5jb250aW51ZSgpO1xuICB9KTtcbiAgYXdhaXQgcGFnZS5nb3RvKCcuLyMvb3RoZWxsbycpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLW5ldycpLmNsaWNrKCk7XG4gIGF3YWl0IHJlYWNoZWQ7XG4gIGF3YWl0IGxlYXZlT3RoZWxsbyhwYWdlKTtcbiAgcmVsZWFzZSgpO1xuICBhd2FpdCBwYWdlLndhaXRGb3JMb2FkU3RhdGUoJ25ldHdvcmtpZGxlJyk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5vdGhlbGxvLCAub3RoZWxsby1ib2FyZCcpKS50b0hhdmVDb3VudCgwKTtcbiAgZXhwZWN0KGF3YWl0IHNhdmVkT3RoZWxsbyhwYWdlKSkudG9CZU51bGwoKTtcbn0pO1xuXG50ZXN0KCdiYWQgc2F2ZXMgYXJlIHJldGFpbmVkLCByZXRyeSBhbmQgZXhwbGljaXQgbmV3IGFyZSBhdmFpbGFibGUsIHVuYXZhaWxhYmxlIHN0b3JhZ2UgaXMgdmlzaWJsZSB0aHJvdWdoIGV4aXQnLCBhc3luYyAoe1xuICBwYWdlLFxufSkgPT4ge1xuICBhd2FpdCBwYWdlLmdvdG8oJy4vIy9vdGhlbGxvJyk7XG4gIGF3YWl0IHBhZ2UuZXZhbHVhdGUoKGtleSkgPT4gbG9jYWxTdG9yYWdlLnNldEl0ZW0oa2V5LCAne2Jyb2tlbicpLCBPVEhFTExPX1NBVkUpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXJlc3VtZScpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLWVycm9yJykpLm5vdC50b0JlRW1wdHkoKTtcbiAgZXhwZWN0KGF3YWl0IHNhdmVkT3RoZWxsbyhwYWdlKSkudG9CZSgne2Jyb2tlbicpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXJlc3VtZScpLmNsaWNrKCk7XG4gIGV4cGVjdChhd2FpdCBzYXZlZE90aGVsbG8ocGFnZSkpLnRvQmUoJ3ticm9rZW4nKTtcbiAgLy8gVGhlIHVzZXIncyBleHBsaWNpdCBuZXcgc2VsZWN0aW9uIGF1dGhvcml6ZXMgcmVwbGFjaW5nIHRoZSBicm9rZW4gT3RoZWxsbyBzbG90LlxuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLW5ldycpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNjb3JlJykpLnRvSGF2ZVRleHQoJ+m7kiAyIOefsyDvvI8g55m9IDIg55+zJyk7XG4gIGF3YWl0IHBhZ2UuZXZhbHVhdGUoKCkgPT4ge1xuICAgIFN0b3JhZ2UucHJvdG90eXBlLnNldEl0ZW0gPSAoKSA9PiB7XG4gICAgICB0aHJvdyBuZXcgRE9NRXhjZXB0aW9uKCdxdW90YScsICdRdW90YUV4Y2VlZGVkRXJyb3InKTtcbiAgICB9O1xuICB9KTtcbiAgYXdhaXQgY2VsbChwYWdlLCAxOSkuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tc2F2ZS1zdGF0dXMnKSkudG9Db250YWluVGV4dCgn5L+d5a2Y44Gn44GN44G+44Gb44KTJyk7XG4gIGF3YWl0IGxlYXZlT3RoZWxsbyhwYWdlKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI2hvbWUtc2F2ZS13YXJuaW5nJykpLnRvQ29udGFpblRleHQoJ090aGVsbG/jgpLkv53lrZjjgafjgY3jgb7jgZvjgpMnKTtcbn0pO1xuXG50ZXN0KCdzYXZlZCBmb3JjZWQtcGFzcyBhbmQgdGVybWluYWwgZml4dHVyZXMgcmVuZGVyIFJ1c3Qgc3RhdHVzLCB3aW5zIGFuZCBkcmF3IHdpdGhvdXQgSlMgcnVsZXMnLCBhc3luYyAoe1xuICBwYWdlLFxufSkgPT4ge1xuICBhd2FpdCBwYWdlLmdvdG8oJy4vIy9vdGhlbGxvJyk7XG4gIGFzeW5jIGZ1bmN0aW9uIHJlc3VtZShib2FyZDogbnVtYmVyW10sIHRvTW92ZTogbnVtYmVyKSB7XG4gICAgYXdhaXQgcGFnZS5ldmFsdWF0ZShcbiAgICAgICh7IGtleSwgYm9hcmQsIHRvTW92ZSB9KSA9PlxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcbiAgICAgICAgICBrZXksXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgdmVyc2lvbjogMSxcbiAgICAgICAgICAgIGdhbWU6ICdvdGhlbGxvJyxcbiAgICAgICAgICAgIG1vZGU6ICdsb2NhbCcsXG4gICAgICAgICAgICBodW1hblNpZGU6IDEsXG4gICAgICAgICAgICBzdGF0ZTogeyB2ZXJzaW9uOiAxLCBib2FyZCwgdG9Nb3ZlIH0sXG4gICAgICAgICAgfSksXG4gICAgICAgICksXG4gICAgICB7IGtleTogT1RIRUxMT19TQVZFLCBib2FyZCwgdG9Nb3ZlIH0sXG4gICAgKTtcbiAgICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXJlc3VtZScpLmNsaWNrKCk7XG4gIH1cbiAgY29uc3QgZm9yY2VkID0gQXJyYXk8bnVtYmVyPig2NCkuZmlsbCgwKTtcbiAgZm9yY2VkWzBdID0gMTtcbiAgZm9yY2VkWzFdID0gMjtcbiAgYXdhaXQgcmVzdW1lKGZvcmNlZCwgMik7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLWd1aWRlJykpLnRvQ29udGFpblRleHQoJ+ODkeOCueOBjOW/heimgScpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXBhc3MnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby10dXJuJykpLnRvSGF2ZVRleHQoJ+m7kuOBruaJi+eVqicpO1xuICBhd2FpdCBjZWxsKHBhZ2UsIDIpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXR1cm4nKSkudG9IYXZlVGV4dCgn57WC5bGA77ya6buS44Gu5Yud44GhJyk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNjb3JlJykpLnRvSGF2ZVRleHQoJ+m7kiAzIOefsyDvvI8g55m9IDAg55+zJyk7XG4gIGF3YWl0IHJlc3VtZShBcnJheTxudW1iZXI+KDY0KS5maWxsKDIpLCAxKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tdHVybicpKS50b0hhdmVUZXh0KCfntYLlsYDvvJrnmb3jga7li53jgaEnKTtcbiAgYXdhaXQgcmVzdW1lKFxuICAgIEFycmF5LmZyb20oeyBsZW5ndGg6IDY0IH0sIChfLCBpKSA9PiAoaSA8IDMyID8gMSA6IDIpKSxcbiAgICAyLFxuICApO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby10dXJuJykpLnRvSGF2ZVRleHQoJ+e1guWxgO+8muW8leWIhuOBkScpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1wYXNzJykpLnRvQmVIaWRkZW4oKTtcbiAgZXhwZWN0KGF3YWl0IHBhZ2UubG9jYXRvcignLm90aGVsbG8tY2VsbFthcmlhLWRpc2FibGVkPVwiZmFsc2VcIl0nKS5jb3VudCgpKS50b0JlKDApO1xufSk7XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVNBLElBQUksRUFBRUMsTUFBTSxRQUFtQixrQkFBa0I7QUFFMUQsTUFBTUMsWUFBWSxHQUFHLGlCQUFpQjtBQUN0QyxNQUFNQyxXQUFXLEdBQUcscUJBQXFCO0FBQ3pDLE1BQU1DLGVBQWUsR0FBRyx5QkFBeUI7QUFDakQsTUFBTUMsWUFBWSxHQUFHLDRCQUE0QjtBQUNqRCxNQUFNQyxJQUFJLEdBQUdBLENBQUNDLElBQVUsRUFBRUMsS0FBYSxLQUFLRCxJQUFJLENBQUNFLE9BQU8sQ0FBQyw2QkFBNkJELEtBQUssSUFBSSxDQUFDO0FBQ2hHLE1BQU1FLFdBQVcsR0FBRyxNQUFPSCxJQUFVLElBQUs7RUFDeEMsTUFBTUEsSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsU0FBUyxDQUFDO0FBQ2pFLENBQUM7QUFDRCxNQUFNQyxZQUFZLEdBQUcsTUFBT04sSUFBVSxJQUFLO0VBQ3pDLE1BQU1BLElBQUksQ0FBQ08sU0FBUyxDQUFDLE1BQU0sRUFBRTtJQUFFQyxJQUFJLEVBQUU7RUFBVyxDQUFDLENBQUMsQ0FBQ0osS0FBSyxDQUFDLENBQUM7RUFDMUQsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDTyxXQUFXLENBQUMsQ0FBQztBQUN4RCxDQUFDO0FBQ0QsZUFBZUMsV0FBV0EsQ0FBQ1YsSUFBVSxFQUFFO0VBQ3JDLE9BQU9BLElBQUksQ0FBQ1csUUFBUSxDQUNsQixDQUFDLENBQUNDLElBQUksRUFBRUMsUUFBUSxFQUFFQyxLQUFLLENBQUMsS0FBSyxDQUFDRixJQUFJLEVBQUVDLFFBQVEsRUFBRUMsS0FBSyxDQUFDLENBQUNDLEdBQUcsQ0FBRUMsR0FBRyxJQUFLQyxZQUFZLENBQUNDLE9BQU8sQ0FBQ0YsR0FBSSxDQUFDLENBQUMsRUFDN0YsQ0FBQ3BCLFdBQVcsRUFBRUMsZUFBZSxFQUFFQyxZQUFZLENBQzdDLENBQUM7QUFDSDtBQUNBLGVBQWVxQixZQUFZQSxDQUFDbkIsSUFBVSxFQUFFO0VBQ3RDLE9BQU9BLElBQUksQ0FBQ1csUUFBUSxDQUFFSyxHQUFHLElBQUtDLFlBQVksQ0FBQ0MsT0FBTyxDQUFDRixHQUFHLENBQUMsRUFBRXJCLFlBQVksQ0FBQztBQUN4RTtBQUVBRixJQUFJLENBQUMsa0hBQWtILEVBQUUsT0FBTztFQUM5SE87QUFDRixDQUFDLEtBQUs7RUFDSixNQUFNb0IsUUFBa0IsR0FBRyxFQUFFO0lBQzNCQyxNQUFnQixHQUFHLEVBQUU7RUFDdkJyQixJQUFJLENBQUNzQixFQUFFLENBQUMsU0FBUyxFQUFHQyxPQUFPLElBQUtILFFBQVEsQ0FBQ0ksSUFBSSxDQUFDRCxPQUFPLENBQUNFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUM3RHpCLElBQUksQ0FBQ3NCLEVBQUUsQ0FBQyxXQUFXLEVBQUdJLEtBQUssSUFBS0wsTUFBTSxDQUFDRyxJQUFJLENBQUNFLEtBQUssQ0FBQ0MsT0FBTyxDQUFDLENBQUM7RUFDM0QsTUFBTTNCLElBQUksQ0FBQzRCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztFQUNwQyxNQUFNbEMsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUNPLFdBQVcsQ0FBQyxDQUFDO0VBQzNEZixNQUFNLENBQ0owQixRQUFRLENBQUNTLE1BQU0sQ0FBRUosR0FBRyxJQUFLLHdEQUF3RCxDQUFDaEMsSUFBSSxDQUFDZ0MsR0FBRyxDQUFDLENBQzdGLENBQUMsQ0FBQ0ssT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUNiLE1BQU05QixJQUFJLENBQUNFLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUM5QyxNQUFNVixNQUFNLENBQ1RxQyxJQUFJLENBQUMsTUFBTS9CLElBQUksQ0FBQ1csUUFBUSxDQUFDO0lBQUEsSUFBQXFCLHFCQUFBO0lBQUEsUUFBQUEscUJBQUEsR0FBTUMsTUFBTSxDQUFDQyx3QkFBd0IsY0FBQUYscUJBQUEsdUJBQS9CQSxxQkFBQSxDQUFpQ0csS0FBSztFQUFBLEVBQUMsQ0FBQyxDQUN2RUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztFQUNoQixNQUFNcEMsSUFBSSxDQUFDRSxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDL0MsTUFBTUosSUFBSSxDQUFDRSxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUNtQyxZQUFZLENBQUMsS0FBSyxDQUFDO0VBQ3JELE1BQU1yQyxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDM0MsTUFBTVYsTUFBTSxDQUNUcUMsSUFBSSxDQUFDLE1BQU0vQixJQUFJLENBQUNXLFFBQVEsQ0FBQztJQUFBLElBQUEyQixxQkFBQTtJQUFBLFFBQUFBLHFCQUFBLEdBQU1MLE1BQU0sQ0FBQ00seUJBQXlCLGNBQUFELHFCQUFBLHVCQUFoQ0EscUJBQUEsQ0FBa0NFLEtBQUssQ0FBQyxDQUFDLENBQUNMLEtBQUs7RUFBQSxFQUFDLENBQUMsQ0FDaEZDLElBQUksQ0FBQyxXQUFXLENBQUM7RUFDcEIsTUFBTUssS0FBSyxHQUFHLE1BQU16QyxJQUFJLENBQUNXLFFBQVEsQ0FBQyxNQUFNc0IsTUFBTSxDQUFDTSx5QkFBeUIsQ0FBRUcsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQzFGLE1BQU0xQyxJQUFJLENBQUMyQyxLQUFLLENBQUN2QyxLQUFLLENBQUNxQyxLQUFLLENBQUNHLENBQUMsRUFBRUgsS0FBSyxDQUFDSSxDQUFDLENBQUM7RUFDeEMsTUFBTW5ELE1BQU0sQ0FDVHFDLElBQUksQ0FBQyxNQUFNL0IsSUFBSSxDQUFDVyxRQUFRLENBQUM7SUFBQSxJQUFBbUMsc0JBQUE7SUFBQSxRQUFBQSxzQkFBQSxHQUFNYixNQUFNLENBQUNNLHlCQUF5QixjQUFBTyxzQkFBQSxnQkFBQUEsc0JBQUEsR0FBaENBLHNCQUFBLENBQWtDTixLQUFLLENBQUMsQ0FBQyxDQUFDTyxJQUFJLGNBQUFELHNCQUFBLHVCQUE5Q0Esc0JBQUEsQ0FBZ0RFLEdBQUc7RUFBQSxFQUFDLENBQUMsQ0FDcEZaLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDVixNQUFNYSxNQUFNLEdBQUcsTUFBTWpELElBQUksQ0FBQ1csUUFBUSxDQUFDLE1BQU1zQixNQUFNLENBQUNNLHlCQUF5QixDQUFFVyxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQzFGLE1BQU1sRCxJQUFJLENBQUNFLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUNyRCxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUNPLFdBQVcsQ0FBQyxDQUFDO0VBQ3RELE1BQU0wQyxNQUFNLEdBQUcsTUFBTXpDLFdBQVcsQ0FBQ1YsSUFBSSxDQUFDO0VBQ3RDTixNQUFNLENBQUN5RCxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsVUFBVSxDQUFDLENBQUM7RUFDOUIsTUFBTWpELFdBQVcsQ0FBQ0gsSUFBSSxDQUFDO0VBQ3ZCLE1BQU1BLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMxQyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RSxNQUFNTixJQUFJLENBQUNDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQ0ksS0FBSyxDQUFDLENBQUM7RUFDNUIsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxlQUFlLENBQUM7RUFDeEUsTUFBTVgsTUFBTSxDQUFDSyxJQUFJLENBQUNDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDcUQsZUFBZSxDQUFDLFlBQVksRUFBRSxHQUFHLENBQUM7RUFDL0QsTUFBTUMsT0FBTyxHQUFHLE1BQU1uQyxZQUFZLENBQUNuQixJQUFJLENBQUM7RUFDeEMsTUFBTUEsSUFBSSxDQUFDdUQsVUFBVSxDQUFDO0lBQUVDLElBQUksRUFBRS9ELElBQUksQ0FBQ2dFLElBQUksQ0FBQyxDQUFDLENBQUNDLFVBQVUsQ0FBQyxrQkFBa0I7RUFBRSxDQUFDLENBQUM7RUFDM0UsTUFBTXBELFlBQVksQ0FBQ04sSUFBSSxDQUFDO0VBQ3hCTixNQUFNLENBQUMsTUFBTWdCLFdBQVcsQ0FBQ1YsSUFBSSxDQUFDLENBQUMsQ0FBQzhCLE9BQU8sQ0FBQ3FCLE1BQU0sQ0FBQztFQUMvQyxNQUFNbkQsSUFBSSxDQUFDRSxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDOUMsTUFBTVYsTUFBTSxDQUNUcUMsSUFBSSxDQUFDLE1BQU0vQixJQUFJLENBQUNXLFFBQVEsQ0FBQztJQUFBLElBQUFnRCxzQkFBQTtJQUFBLFFBQUFBLHNCQUFBLEdBQU0xQixNQUFNLENBQUNDLHdCQUF3QixjQUFBeUIsc0JBQUEsdUJBQS9CQSxzQkFBQSxDQUFpQ3hCLEtBQUs7RUFBQSxFQUFDLENBQUMsQ0FDdkVDLElBQUksQ0FBQyxPQUFPLENBQUM7RUFDaEIsTUFBTXBDLElBQUksQ0FBQ0UsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQ2pELE1BQU1WLE1BQU0sQ0FDVHFDLElBQUksQ0FBQyxNQUFNL0IsSUFBSSxDQUFDVyxRQUFRLENBQUM7SUFBQSxJQUFBaUQsc0JBQUE7SUFBQSxRQUFBQSxzQkFBQSxHQUFNM0IsTUFBTSxDQUFDTSx5QkFBeUIsY0FBQXFCLHNCQUFBLHVCQUFoQ0Esc0JBQUEsQ0FBa0NwQixLQUFLLENBQUMsQ0FBQyxDQUFDTCxLQUFLO0VBQUEsRUFBQyxDQUFDLENBQ2hGQyxJQUFJLENBQUMsV0FBVyxDQUFDO0VBQ3BCMUMsTUFBTSxDQUFDLE1BQU1NLElBQUksQ0FBQ1csUUFBUSxDQUFDLE1BQU1zQixNQUFNLENBQUNNLHlCQUF5QixDQUFFVyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ3BCLE9BQU8sQ0FDekZtQixNQUNGLENBQUM7RUFDRHZELE1BQU0sQ0FBQyxNQUFNeUIsWUFBWSxDQUFDbkIsSUFBSSxDQUFDLENBQUMsQ0FBQ29DLElBQUksQ0FBQ2tCLE9BQU8sQ0FBQztFQUM5QyxNQUFNdEQsSUFBSSxDQUFDRSxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDckQsTUFBTUQsV0FBVyxDQUFDSCxJQUFJLENBQUM7RUFDdkIsTUFBTUEsSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxlQUFlLENBQUM7RUFDeEUsTUFBTVgsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMyRCxhQUFhLENBQUMsUUFBUSxDQUFDO0VBQ3RFLE1BQU03RCxJQUFJLENBQUM4RCxNQUFNLENBQUMsQ0FBQztFQUNuQixNQUFNcEUsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDTyxXQUFXLENBQUMsQ0FBQztFQUN0RCxNQUFNVCxJQUFJLENBQUMrRCxTQUFTLENBQUMsQ0FBQztFQUN0QixNQUFNL0QsSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsTUFBTSxDQUFDO0VBQzlELE1BQU1MLElBQUksQ0FBQzRCLElBQUksQ0FBQywwQkFBMEIsQ0FBQztFQUMzQ2xDLE1BQU0sQ0FBQyxJQUFJc0UsR0FBRyxDQUFDaEUsSUFBSSxDQUFDeUIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDd0MsUUFBUSxDQUFDLENBQUM3QixJQUFJLENBQUMsSUFBSTRCLEdBQUcsQ0FBQ3ZFLElBQUksQ0FBQ2dFLElBQUksQ0FBQyxDQUFDLENBQUNTLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDQyxPQUFRLENBQUMsQ0FBQ0gsUUFBUSxDQUFDO0VBQzdGLE1BQU1qRSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUM3QyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RSxNQUFNWCxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ21FLFdBQVcsQ0FBQyxDQUFDLENBQUM7RUFDM0QzRSxNQUFNLENBQUMyQixNQUFNLENBQUMsQ0FBQ1MsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUM1QixDQUFDLENBQUM7QUFFRnJDLElBQUksQ0FBQyxzR0FBc0csRUFBRSxPQUFPO0VBQ2xITztBQUNGLENBQUMsS0FBSztFQUNKLE1BQU1BLElBQUksQ0FBQ3NFLGVBQWUsQ0FBQztJQUFFQyxLQUFLLEVBQUUsR0FBRztJQUFFQyxNQUFNLEVBQUU7RUFBSSxDQUFDLENBQUM7RUFDdkQsTUFBTUMsT0FBaUIsR0FBRyxFQUFFO0VBQzVCekUsSUFBSSxDQUFDc0IsRUFBRSxDQUFDLFFBQVEsRUFBR29ELE1BQU0sSUFBS0QsT0FBTyxDQUFDakQsSUFBSSxDQUFDa0QsTUFBTSxDQUFDakQsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3pELE1BQU16QixJQUFJLENBQUM0QixJQUFJLENBQUMsTUFBTSxDQUFDO0VBQ3ZCLE1BQU16QixXQUFXLENBQUNILElBQUksQ0FBQztFQUN2Qk4sTUFBTSxDQUFDK0UsT0FBTyxDQUFDLENBQUMzQyxPQUFPLENBQUMsRUFBRSxDQUFDO0VBQzNCLE1BQU05QixJQUFJLENBQUNFLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDMUMsTUFBTVYsTUFBTSxDQUFDSyxJQUFJLENBQUNDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDcUQsZUFBZSxDQUFDLGVBQWUsRUFBRSxPQUFPLENBQUM7RUFDdEUsTUFBTXRELElBQUksQ0FBQ0MsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDMkUsS0FBSyxDQUFDLENBQUM7RUFDNUIsTUFBTTNFLElBQUksQ0FBQzRFLFFBQVEsQ0FBQ0MsS0FBSyxDQUFDLFlBQVksQ0FBQztFQUN2QyxNQUFNbkYsTUFBTSxDQUFDSyxJQUFJLENBQUNDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDOEUsV0FBVyxDQUFDLENBQUM7RUFDMUMsTUFBTTlFLElBQUksQ0FBQzRFLFFBQVEsQ0FBQ0MsS0FBSyxDQUFDLFdBQVcsQ0FBQztFQUN0QyxNQUFNN0UsSUFBSSxDQUFDNEUsUUFBUSxDQUFDQyxLQUFLLENBQUMsT0FBTyxDQUFDO0VBQ2xDLE1BQU1uRixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RVgsTUFBTSxDQUFDLE1BQU1NLElBQUksQ0FBQ1csUUFBUSxDQUFDLE1BQU1vRSxRQUFRLENBQUNDLGVBQWUsQ0FBQ0MsV0FBVyxJQUFJQyxVQUFVLENBQUMsQ0FBQyxDQUFDOUMsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNoRyxNQUFNcEMsSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUNtQyxZQUFZLENBQUMsSUFBSSxDQUFDO0VBQ3RELE1BQU1yQyxJQUFJLENBQUNFLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDbUMsWUFBWSxDQUFDLEdBQUcsQ0FBQztFQUMzRCxNQUFNckMsSUFBSSxDQUFDRSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzFDLE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQ3ZELDhCQUNGLENBQUM7RUFDRCxNQUFNWCxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RSxNQUFNWCxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxNQUFNLENBQUM7RUFDOURYLE1BQU0sQ0FBQytFLE9BQU8sQ0FBQyxDQUFDVSxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQy9CLE1BQU16RixNQUFNLENBQUNLLElBQUksQ0FBQ0MsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUNxRCxlQUFlLENBQUMsWUFBWSxFQUFFLEdBQUcsQ0FBQztFQUMvRCxNQUFNL0MsWUFBWSxDQUFDTixJQUFJLENBQUM7RUFDeEIsTUFBTUcsV0FBVyxDQUFDSCxJQUFJLENBQUM7RUFDdkIsTUFBTUEsSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMyRCxhQUFhLENBQUMsZUFBZSxDQUFDO0VBQzdFLE1BQU1uRSxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxNQUFNLENBQUM7RUFDOURYLE1BQU0sQ0FBQytFLE9BQU8sQ0FBQyxDQUFDVSxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQztBQUVGMUYsSUFBSSxDQUFDLCtIQUErSCxFQUFFLE9BQU87RUFDM0lPO0FBQ0YsQ0FBQyxLQUFLO0VBQ0osTUFBTUEsSUFBSSxDQUFDb0YsYUFBYSxDQUFDLE1BQU07SUFDN0IsTUFBTUMsTUFBTSxHQUFHcEQsTUFBTSxDQUFDcUQsTUFBTTtJQUM1QixNQUFNQyxPQUFPLEdBQUc7TUFBRUMsTUFBTSxFQUFFLENBQUM7TUFBRUMsS0FBSyxFQUFFLENBQUM7TUFBRUMsSUFBSSxFQUFFQSxDQUFBLEtBQU0sQ0FBQztJQUFFLENBQUM7SUFDdER6RCxNQUFNLENBQVMwRCxhQUFhLEdBQUdKLE9BQU87SUFDdkN0RCxNQUFNLENBQUNxRCxNQUFNLEdBQUcsY0FBY0QsTUFBTSxDQUFDO01BQzFCTyxXQUFXQSxDQUFDakUsT0FBWSxFQUFRO1FBQ3ZDNEQsT0FBTyxDQUFDQyxNQUFNLEVBQUU7UUFDaEIsTUFBTUssUUFBUSxHQUFJLElBQUksQ0FBU0MsYUFBYTtRQUM1Q1AsT0FBTyxDQUFDRyxJQUFJLEdBQUcsTUFDYkcsUUFBUSxDQUNOLElBQUlFLFlBQVksQ0FBQyxTQUFTLEVBQUU7VUFDMUJDLElBQUksRUFBRTtZQUFFQyxFQUFFLEVBQUV0RSxPQUFPLENBQUNzRSxFQUFFO1lBQUVDLFVBQVUsRUFBRXZFLE9BQU8sQ0FBQ3VFLFVBQVU7WUFBRUMsRUFBRSxFQUFFLElBQUk7WUFBRUMsSUFBSSxFQUFFO1VBQUc7UUFDN0UsQ0FBQyxDQUNILENBQUM7UUFDSDtNQUNGO01BQ1NDLGdCQUFnQkEsQ0FBQ0MsSUFBUyxFQUFFVCxRQUFhLEVBQUVVLE9BQWEsRUFBUTtRQUN2RSxJQUFJRCxJQUFJLEtBQUssU0FBUyxFQUFHLElBQUksQ0FBU1IsYUFBYSxHQUFHRCxRQUFRO1FBQzlELEtBQUssQ0FBQ1EsZ0JBQWdCLENBQUNDLElBQUksRUFBRVQsUUFBUSxFQUFFVSxPQUFPLENBQUM7TUFDakQ7TUFDU0MsU0FBU0EsQ0FBQSxFQUFTO1FBQ3pCakIsT0FBTyxDQUFDRSxLQUFLLEVBQUU7UUFDZixLQUFLLENBQUNlLFNBQVMsQ0FBQyxDQUFDO01BQ25CO0lBQ0YsQ0FBQztJQUNEdkYsWUFBWSxDQUFDd0YsT0FBTyxDQUFDLHFCQUFxQixFQUFFLGlCQUFpQixDQUFDO0lBQzlEeEYsWUFBWSxDQUFDd0YsT0FBTyxDQUFDLHlCQUF5QixFQUFFLG1CQUFtQixDQUFDO0lBQ3BFeEYsWUFBWSxDQUFDd0YsT0FBTyxDQUFDLDRCQUE0QixFQUFFLGdCQUFnQixDQUFDO0VBQ3RFLENBQUMsQ0FBQztFQUNGLE1BQU16RyxJQUFJLENBQUM0QixJQUFJLENBQUMsYUFBYSxDQUFDO0VBQzlCLE1BQU11QixNQUFNLEdBQUcsTUFBTXpDLFdBQVcsQ0FBQ1YsSUFBSSxDQUFDO0VBQ3RDLE1BQU1BLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDbUMsWUFBWSxDQUFDLElBQUksQ0FBQztFQUN0RCxNQUFNckMsSUFBSSxDQUFDRSxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQ21DLFlBQVksQ0FBQyxHQUFHLENBQUM7RUFDM0QsTUFBTXJDLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMxQyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMyRCxhQUFhLENBQUMsUUFBUSxDQUFDO0VBQ25FLE1BQU02QyxTQUFTLEdBQUcsTUFBTXZGLFlBQVksQ0FBQ25CLElBQUksQ0FBQztFQUMxQyxNQUFNTSxZQUFZLENBQUNOLElBQUksQ0FBQztFQUN4QixNQUFNQSxJQUFJLENBQUNXLFFBQVEsQ0FBQyxNQUFPc0IsTUFBTSxDQUFTMEQsYUFBYSxDQUFDRCxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQy9ELE1BQU1oRyxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGtDQUFrQyxDQUFDLENBQUMsQ0FBQ21FLFdBQVcsQ0FBQyxDQUFDLENBQUM7RUFDN0UzRSxNQUFNLENBQUMsTUFBTXlCLFlBQVksQ0FBQ25CLElBQUksQ0FBQyxDQUFDLENBQUNvQyxJQUFJLENBQUNzRSxTQUFTLENBQUM7RUFDaERoSCxNQUFNLENBQUMsTUFBTWdCLFdBQVcsQ0FBQ1YsSUFBSSxDQUFDLENBQUMsQ0FBQzhCLE9BQU8sQ0FBQ3FCLE1BQU0sQ0FBQztFQUMvQ3pELE1BQU0sQ0FDSixNQUFNTSxJQUFJLENBQUNXLFFBQVEsQ0FBQyxPQUFPO0lBQ3pCNkUsTUFBTSxFQUFHdkQsTUFBTSxDQUFTMEQsYUFBYSxDQUFDSCxNQUFNO0lBQzVDQyxLQUFLLEVBQUd4RCxNQUFNLENBQVMwRCxhQUFhLENBQUNGO0VBQ3ZDLENBQUMsQ0FBQyxDQUNKLENBQUMsQ0FBQzNELE9BQU8sQ0FBQztJQUFFMEQsTUFBTSxFQUFFLENBQUM7SUFBRUMsS0FBSyxFQUFFO0VBQUUsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQztBQUVGaEcsSUFBSSxDQUFDLHlGQUF5RixFQUFFLE9BQU87RUFDckdPO0FBQ0YsQ0FBQyxLQUFLO0VBQ0osSUFBSTJHLE9BQW9CLEVBQUVDLFNBQXNCO0VBQ2hELE1BQU1DLElBQUksR0FBRyxJQUFJQyxPQUFPLENBQVFDLE9BQU8sSUFBSztJQUMxQ0osT0FBTyxHQUFHSSxPQUFPO0VBQ25CLENBQUMsQ0FBQztFQUNGLE1BQU1DLE9BQU8sR0FBRyxJQUFJRixPQUFPLENBQVFDLE9BQU8sSUFBSztJQUM3Q0gsU0FBUyxHQUFHRyxPQUFPO0VBQ3JCLENBQUMsQ0FBQztFQUNGLE1BQU0vRyxJQUFJLENBQUNpSCxLQUFLLENBQUMsc0JBQXNCLEVBQUUsTUFBT0EsS0FBSyxJQUFLO0lBQ3hETCxTQUFTLENBQUMsQ0FBQztJQUNYLE1BQU1DLElBQUk7SUFDVixNQUFNSSxLQUFLLENBQUNDLFFBQVEsQ0FBQyxDQUFDO0VBQ3hCLENBQUMsQ0FBQztFQUNGLE1BQU1sSCxJQUFJLENBQUM0QixJQUFJLENBQUMsYUFBYSxDQUFDO0VBQzlCLE1BQU01QixJQUFJLENBQUNFLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDMUMsTUFBTTRHLE9BQU87RUFDYixNQUFNMUcsWUFBWSxDQUFDTixJQUFJLENBQUM7RUFDeEIyRyxPQUFPLENBQUMsQ0FBQztFQUNULE1BQU0zRyxJQUFJLENBQUNtSCxnQkFBZ0IsQ0FBQyxhQUFhLENBQUM7RUFDMUMsTUFBTXpILE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDbUUsV0FBVyxDQUFDLENBQUMsQ0FBQztFQUNyRTNFLE1BQU0sQ0FBQyxNQUFNeUIsWUFBWSxDQUFDbkIsSUFBSSxDQUFDLENBQUMsQ0FBQ29ILFFBQVEsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQztBQUVGM0gsSUFBSSxDQUFDLDJHQUEyRyxFQUFFLE9BQU87RUFDdkhPO0FBQ0YsQ0FBQyxLQUFLO0VBQ0osTUFBTUEsSUFBSSxDQUFDNEIsSUFBSSxDQUFDLGFBQWEsQ0FBQztFQUM5QixNQUFNNUIsSUFBSSxDQUFDVyxRQUFRLENBQUVLLEdBQUcsSUFBS0MsWUFBWSxDQUFDd0YsT0FBTyxDQUFDekYsR0FBRyxFQUFFLFNBQVMsQ0FBQyxFQUFFckIsWUFBWSxDQUFDO0VBQ2hGLE1BQU1LLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzdDLE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDbUgsR0FBRyxDQUFDQyxTQUFTLENBQUMsQ0FBQztFQUM1RDVILE1BQU0sQ0FBQyxNQUFNeUIsWUFBWSxDQUFDbkIsSUFBSSxDQUFDLENBQUMsQ0FBQ29DLElBQUksQ0FBQyxTQUFTLENBQUM7RUFDaEQsTUFBTXBDLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzdDVixNQUFNLENBQUMsTUFBTXlCLFlBQVksQ0FBQ25CLElBQUksQ0FBQyxDQUFDLENBQUNvQyxJQUFJLENBQUMsU0FBUyxDQUFDO0VBQ2hEO0VBQ0EsTUFBTXBDLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMxQyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RSxNQUFNTCxJQUFJLENBQUNXLFFBQVEsQ0FBQyxNQUFNO0lBQ3hCNEcsT0FBTyxDQUFDQyxTQUFTLENBQUNmLE9BQU8sR0FBRyxNQUFNO01BQ2hDLE1BQU0sSUFBSWdCLFlBQVksQ0FBQyxPQUFPLEVBQUUsb0JBQW9CLENBQUM7SUFDdkQsQ0FBQztFQUNILENBQUMsQ0FBQztFQUNGLE1BQU0xSCxJQUFJLENBQUNDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQ0ksS0FBSyxDQUFDLENBQUM7RUFDNUIsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMyRCxhQUFhLENBQUMsU0FBUyxDQUFDO0VBQzNFLE1BQU12RCxZQUFZLENBQUNOLElBQUksQ0FBQztFQUN4QixNQUFNTixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQzJELGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQztBQUNuRixDQUFDLENBQUM7QUFFRnBFLElBQUksQ0FBQyw0RkFBNEYsRUFBRSxPQUFPO0VBQ3hHTztBQUNGLENBQUMsS0FBSztFQUNKLE1BQU1BLElBQUksQ0FBQzRCLElBQUksQ0FBQyxhQUFhLENBQUM7RUFDOUIsZUFBZThGLE1BQU1BLENBQUNDLEtBQWUsRUFBRUMsTUFBYyxFQUFFO0lBQ3JELE1BQU01SCxJQUFJLENBQUNXLFFBQVEsQ0FDakIsQ0FBQztNQUFFSyxHQUFHO01BQUUyRyxLQUFLO01BQUVDO0lBQU8sQ0FBQyxLQUNyQjNHLFlBQVksQ0FBQ3dGLE9BQU8sQ0FDbEJ6RixHQUFHLEVBQ0g2RyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUNiQyxPQUFPLEVBQUUsQ0FBQztNQUNWbkgsSUFBSSxFQUFFLFNBQVM7TUFDZm9ILElBQUksRUFBRSxPQUFPO01BQ2JDLFNBQVMsRUFBRSxDQUFDO01BQ1p6RixLQUFLLEVBQUU7UUFBRXVGLE9BQU8sRUFBRSxDQUFDO1FBQUVKLEtBQUs7UUFBRUM7TUFBTztJQUNyQyxDQUFDLENBQ0gsQ0FBQyxFQUNIO01BQUU1RyxHQUFHLEVBQUVyQixZQUFZO01BQUVnSSxLQUFLO01BQUVDO0lBQU8sQ0FDckMsQ0FBQztJQUNELE1BQU01SCxJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMvQztFQUNBLE1BQU04SCxNQUFNLEdBQUdDLEtBQUssQ0FBUyxFQUFFLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUN4Q0YsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7RUFDYkEsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7RUFDYixNQUFNUixNQUFNLENBQUNRLE1BQU0sRUFBRSxDQUFDLENBQUM7RUFDdkIsTUFBTXhJLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDMkQsYUFBYSxDQUFDLE9BQU8sQ0FBQztFQUNuRSxNQUFNN0QsSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzNDLE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLE1BQU0sQ0FBQztFQUM5RCxNQUFNTixJQUFJLENBQUNDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQ0ksS0FBSyxDQUFDLENBQUM7RUFDM0IsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsU0FBUyxDQUFDO0VBQ2pFLE1BQU1YLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsZUFBZSxDQUFDO0VBQ3hFLE1BQU1xSCxNQUFNLENBQUNTLEtBQUssQ0FBUyxFQUFFLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztFQUMxQyxNQUFNMUksTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsU0FBUyxDQUFDO0VBQ2pFLE1BQU1xSCxNQUFNLENBQ1ZTLEtBQUssQ0FBQ0UsSUFBSSxDQUFDO0lBQUVDLE1BQU0sRUFBRTtFQUFHLENBQUMsRUFBRSxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBTUEsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBRSxDQUFDLEVBQ3RELENBQ0YsQ0FBQztFQUNELE1BQU05SSxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxRQUFRLENBQUM7RUFDaEUsTUFBTVgsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDdUksVUFBVSxDQUFDLENBQUM7RUFDeEQvSSxNQUFNLENBQUMsTUFBTU0sSUFBSSxDQUFDRSxPQUFPLENBQUMsc0NBQXNDLENBQUMsQ0FBQ3dJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ3RHLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDcEYsQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119