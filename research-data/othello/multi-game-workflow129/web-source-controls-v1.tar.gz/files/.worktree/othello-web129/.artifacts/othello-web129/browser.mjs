import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import assert from 'node:assert/strict';
import { readFileSync, statSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { once } from 'node:events';

const htmlOnly = process.argv.includes('--html-only');
if (!htmlOnly) {
  const path =
    '/workspaces/quoridor/artifacts/playwright/chromium_headless_shell-1243/chrome-headless-shell-linux64/SwiftShader.ini';
  const bytes = readFileSync(path);
  assert.equal(bytes.length, 63);
  assert.equal(statSync(path).mode & 0o777, 0o644);
  assert.equal(
    createHash('sha256').update(bytes).digest('hex'),
    'c30e9e654ace933b1cf2a0e10720a7f86aacdc1a0c97c3184731189ae94f3e2f',
  );
}
const server = spawn(
  process.execPath,
  [
    'node_modules/vite/bin/vite.js',
    'preview',
    'apps/web',
    '--config',
    'apps/web/vite.config.ts',
    '--host',
    '127.0.0.1',
    '--port',
    '4198',
    '--strictPort',
  ],
  {
    env: {
      ...process.env,
      APP_BASE: '/shell-check/',
      APP_OUT_DIR: process.env.OTHELLO_BUNDLE || '../../.artifacts/othello-web129/bundle',
    },
    stdio: ['ignore', 'inherit', 'inherit'],
  },
);
let exited = false;
server.on('exit', () => {
  exited = true;
});
try {
  let ready = false;
  for (let i = 0; i < 100; i++) {
    assert.equal(exited, false, 'preview exited before readiness');
    try {
      const response = await fetch('http://127.0.0.1:4198/shell-check/');
      if (response.ok) {
        ready = true;
        break;
      }
    } catch {}
    await delay(50);
  }
  assert.equal(ready, true, 'preview readiness');
  const test = spawn(
    process.execPath,
    [
      'node_modules/@playwright/test/cli.js',
      'test',
      '--config',
      '.artifacts/othello-web129/playwright.config.ts',
      ...process.argv.slice(2).filter((arg) => arg !== '--html-only'),
    ],
    {
      stdio: ['ignore', 'inherit', 'inherit'],
      env: { ...process.env, OTHELLO_HTML_ONLY: htmlOnly ? '1' : '0' },
    },
  );
  const [code, signal] = await once(test, 'exit');
  assert.equal(signal, null);
  assert.equal(code, 0, 'new multi-game rendered acceptance');
} finally {
  const completion = exited ? Promise.resolve() : once(server, 'exit');
  if (!exited) server.kill('SIGTERM');
  await completion;
  writeFileSync(
    htmlOnly
      ? '.artifacts/othello-web129/browser-helper-cleanup-html.json'
      : '.artifacts/othello-web129/browser-helper-cleanup.json',
    JSON.stringify({ previewDirectWait: true, previewExited: exited, testDirectWait: true }) + '\n',
  );
}
