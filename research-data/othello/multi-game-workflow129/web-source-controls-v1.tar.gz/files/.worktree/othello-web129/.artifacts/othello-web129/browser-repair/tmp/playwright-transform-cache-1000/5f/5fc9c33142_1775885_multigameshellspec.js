// 130cea1ea9ac0c6076fe55a42be1ed9ea12f2d63
import { test, expect } from '@playwright/test';
const OTHELLO_SAVE = 'othello.game.v1';
const LEGACY_GAME = 'quoridor.m1.game.v1';
const LEGACY_SETTINGS = 'quoridor.m1.settings.v1';
const LEGACY_AUDIO = 'quoridor.audio.settings.v1';
const cell = (page, index) => page.locator(`.othello-cell[data-index="${index}"]`);
const openOthello = async page => {
  await page.locator('#choose-othello').click();
  await expect(page.locator('.othello h1')).toHaveText('Othello');
};
const leaveOthello = async page => {
  await page.getByRole('link', {
    name: 'ゲーム一覧へ戻る'
  }).click();
  await expect(page.locator('.home-page')).toBeVisible();
};
async function legacySlots(page) {
  return page.evaluate(([game, settings, audio]) => [game, settings, audio].map(key => localStorage.getItem(key)), [LEGACY_GAME, LEGACY_SETTINGS, LEGACY_AUDIO]);
}
async function savedOthello(page) {
  return page.evaluate(key => localStorage.getItem(key), OTHELLO_SAVE);
}
test('new cross-game flow plays and saves both games, resumes legacy and Othello slots, preserves history and basepath', async ({
  page
}) => {
  // Two real Quoridor mounts and teardown compile/render PBR on the assigned single CPU.
  // This test budget is independent of the unchanged process resource/deadline guard.
  test.setTimeout(120000);
  const requests = [],
    errors = [];
  page.on('request', request => requests.push(request.url()));
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('./?forceWebGL=1#/');
  await expect(page.locator('#choose-othello')).toBeVisible();
  expect(requests.filter(url => /\.wasm|ai\.worker|quoridor-|othello-|\.hdr|\.mp3|\.ogg/.test(url))).toEqual([]);
  await page.locator('#choose-quoridor').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_DI;
    return (_window$__QUORIDOR_DI = window.__QUORIDOR_DIAGNOSTICS__) === null || _window$__QUORIDOR_DI === void 0 ? void 0 : _window$__QUORIDOR_DI.phase;
  })).toBe('ready');
  await page.locator('#startup-new-game').click();
  await page.locator('#match-mode').selectOption('pvp');
  await page.locator('#dialog-start').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_AP;
    return (_window$__QUORIDOR_AP = window.__QUORIDOR_APP_TEST_API__) === null || _window$__QUORIDOR_AP === void 0 ? void 0 : _window$__QUORIDOR_AP.state().phase;
  })).toBe('humanTurn');
  const point = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__.projectCell(13));
  await page.mouse.click(point.x, point.y);
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_AP2;
    return (_window$__QUORIDOR_AP2 = window.__QUORIDOR_APP_TEST_API__) === null || _window$__QUORIDOR_AP2 === void 0 || (_window$__QUORIDOR_AP2 = _window$__QUORIDOR_AP2.state().view) === null || _window$__QUORIDOR_AP2 === void 0 ? void 0 : _window$__QUORIDOR_AP2.ply;
  })).toBe(1);
  const replay = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__.exportReplay());
  await page.locator('.top-actions .home-link').click();
  await expect(page.locator('.home-page')).toBeVisible();
  const legacy = await legacySlots(page);
  expect(legacy[0]).toBeTruthy();
  await openOthello(page);
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 2 石 ／ 白 2 石');
  await cell(page, 19).click();
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(cell(page, 27)).toHaveAttribute('data-stone', '1');
  const othello = await savedOthello(page);
  await page.screenshot({
    path: test.info().outputPath('othello-play.png')
  });
  await leaveOthello(page);
  expect(await legacySlots(page)).toEqual(legacy);
  await page.locator('#choose-quoridor').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_DI2;
    return (_window$__QUORIDOR_DI2 = window.__QUORIDOR_DIAGNOSTICS__) === null || _window$__QUORIDOR_DI2 === void 0 ? void 0 : _window$__QUORIDOR_DI2.phase;
  })).toBe('ready');
  await page.locator('#resume-game-choice').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_AP3;
    return (_window$__QUORIDOR_AP3 = window.__QUORIDOR_APP_TEST_API__) === null || _window$__QUORIDOR_AP3 === void 0 ? void 0 : _window$__QUORIDOR_AP3.state().phase;
  })).toBe('humanTurn');
  expect(await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__.exportReplay())).toEqual(replay);
  expect(await savedOthello(page)).toBe(othello);
  await page.locator('.top-actions .home-link').click();
  await openOthello(page);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(page.locator('#othello-players')).toContainText('ローカル2人');
  await page.goBack();
  await expect(page.locator('.home-page')).toBeVisible();
  await page.goForward();
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-turn')).toHaveText('白の手番');
  await page.goto('./?forceWebGL=1#/othello');
  expect(new URL(page.url()).pathname).toBe(new URL(test.info().project.use.baseURL).pathname);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(page.locator('canvas, dialog')).toHaveCount(0);
  expect(errors).toEqual([]);
});
test('Othello-only entry remains lazy on home, keyboard play and real bounded AI use explicit human colors', async ({
  page
}) => {
  await page.setViewportSize({
    width: 375,
    height: 812
  });
  const workers = [];
  page.on('worker', worker => workers.push(worker.url()));
  await page.goto('./#/');
  await openOthello(page);
  expect(workers).toEqual([]);
  await page.locator('#othello-new').click();
  await expect(cell(page, 19)).toHaveAttribute('aria-disabled', 'false');
  await cell(page, 19).focus();
  await page.keyboard.press('ArrowRight');
  await expect(cell(page, 20)).toBeFocused();
  await page.keyboard.press('ArrowLeft');
  await page.keyboard.press('Enter');
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.locator('#othello-mode').selectOption('ai');
  await page.locator('#othello-human-side').selectOption('2');
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-players')).toHaveText('簡易AI（非学習）と対戦 · 人間：白 ／ 簡易AI：黒');
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(page.locator('#othello-turn')).toHaveText('白の手番');
  expect(workers).toHaveLength(1);
  await expect(cell(page, 19)).toHaveAttribute('data-stone', '1');
  await leaveOthello(page);
  await openOthello(page);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-players')).toContainText('人間：白 ／ 簡易AI：黒');
  await expect(page.locator('#othello-turn')).toHaveText('白の手番');
  expect(workers).toHaveLength(1);
});
test('Othello Worker pending cancellation terminates once and rejects a deliberately late message without mutation or legacy writes', async ({
  page
}) => {
  await page.addInitScript(() => {
    const Native = window.Worker;
    const monitor = {
      starts: 0,
      stops: 0,
      late: () => {}
    };
    window.othelloWorker = monitor;
    window.Worker = class extends Native {
      postMessage(message) {
        monitor.starts++;
        const callback = this.savedCallback;
        monitor.late = () => callback(new MessageEvent('message', {
          data: {
            id: message.id,
            generation: message.generation,
            ok: true,
            move: 19
          }
        }));
        // Keep the real game-owned Worker pending; deliver the captured callback after teardown.
      }
      addEventListener(type, callback, options) {
        if (type === 'message') this.savedCallback = callback;
        super.addEventListener(type, callback, options);
      }
      terminate() {
        monitor.stops++;
        super.terminate();
      }
    };
    localStorage.setItem('quoridor.m1.game.v1', 'legacy sentinel');
    localStorage.setItem('quoridor.m1.settings.v1', 'settings sentinel');
    localStorage.setItem('quoridor.audio.settings.v1', 'audio sentinel');
  });
  await page.goto('./#/othello');
  const legacy = await legacySlots(page);
  await page.locator('#othello-mode').selectOption('ai');
  await page.locator('#othello-human-side').selectOption('2');
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-turn')).toContainText('考えています');
  const confirmed = await savedOthello(page);
  await leaveOthello(page);
  await page.evaluate(() => window.othelloWorker.late());
  await expect(page.locator('.othello, .othello-board, canvas')).toHaveCount(0);
  expect(await savedOthello(page)).toBe(confirmed);
  expect(await legacySlots(page)).toEqual(legacy);
  expect(await page.evaluate(() => ({
    starts: window.othelloWorker.starts,
    stops: window.othelloWorker.stops
  }))).toEqual({
    starts: 1,
    stops: 1
  });
});
test('leaving Othello during actual Wasm initialization cannot save or render the late result', async ({
  page
}) => {
  let release, requested;
  const gate = new Promise(resolve => {
    release = resolve;
  });
  const reached = new Promise(resolve => {
    requested = resolve;
  });
  await page.route('**/*othello_bg*.wasm', async route => {
    requested();
    await gate;
    await route.continue();
  });
  await page.goto('./#/othello');
  await page.locator('#othello-new').click();
  await reached;
  await leaveOthello(page);
  release();
  await page.waitForLoadState('networkidle');
  await expect(page.locator('.othello, .othello-board')).toHaveCount(0);
  expect(await savedOthello(page)).toBeNull();
});
test('bad saves are retained, retry and explicit new are available, unavailable storage is visible through exit', async ({
  page
}) => {
  await page.goto('./#/othello');
  await page.evaluate(key => localStorage.setItem(key, '{broken'), OTHELLO_SAVE);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-error')).not.toBeEmpty();
  expect(await savedOthello(page)).toBe('{broken');
  await page.locator('#othello-resume').click();
  expect(await savedOthello(page)).toBe('{broken');
  // The user's explicit new selection authorizes replacing the broken Othello slot.
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 2 石 ／ 白 2 石');
  await page.evaluate(() => {
    Storage.prototype.setItem = () => {
      throw new DOMException('quota', 'QuotaExceededError');
    };
  });
  await cell(page, 19).click();
  await expect(page.locator('#othello-save-status')).toContainText('保存できません');
  await leaveOthello(page);
  await expect(page.locator('#home-save-warning')).toContainText('Othelloを保存できません');
});
test('saved forced-pass and terminal fixtures render Rust status, wins and draw without JS rules', async ({
  page
}) => {
  await page.goto('./#/othello');
  async function resume(board, toMove) {
    await page.evaluate(({
      key,
      board,
      toMove
    }) => localStorage.setItem(key, JSON.stringify({
      version: 1,
      game: 'othello',
      mode: 'local',
      humanSide: 1,
      state: {
        version: 1,
        board,
        toMove
      }
    })), {
      key: OTHELLO_SAVE,
      board,
      toMove
    });
    await page.locator('#othello-resume').click();
  }
  const forced = Array(64).fill(0);
  forced[0] = 1;
  forced[1] = 2;
  await resume(forced, 2);
  await expect(page.locator('#othello-guide')).toContainText('パスが必要');
  await page.locator('#othello-pass').click();
  await expect(page.locator('#othello-turn')).toHaveText('黒の手番');
  await cell(page, 2).click();
  await expect(page.locator('#othello-turn')).toHaveText('終局：黒の勝ち');
  await expect(page.locator('#othello-score')).toHaveText('黒 3 石 ／ 白 0 石');
  await resume(Array(64).fill(2), 1);
  await expect(page.locator('#othello-turn')).toHaveText('終局：白の勝ち');
  await resume(Array.from({
    length: 64
  }, (_, i) => i < 32 ? 1 : 2), 2);
  await expect(page.locator('#othello-turn')).toHaveText('終局：引分け');
  await expect(page.locator('#othello-pass')).toBeHidden();
  expect(await page.locator('.othello-cell[aria-disabled="false"]').count()).toBe(0);
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ0ZXN0IiwiZXhwZWN0IiwiT1RIRUxMT19TQVZFIiwiTEVHQUNZX0dBTUUiLCJMRUdBQ1lfU0VUVElOR1MiLCJMRUdBQ1lfQVVESU8iLCJjZWxsIiwicGFnZSIsImluZGV4IiwibG9jYXRvciIsIm9wZW5PdGhlbGxvIiwiY2xpY2siLCJ0b0hhdmVUZXh0IiwibGVhdmVPdGhlbGxvIiwiZ2V0QnlSb2xlIiwibmFtZSIsInRvQmVWaXNpYmxlIiwibGVnYWN5U2xvdHMiLCJldmFsdWF0ZSIsImdhbWUiLCJzZXR0aW5ncyIsImF1ZGlvIiwibWFwIiwia2V5IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInNhdmVkT3RoZWxsbyIsInNldFRpbWVvdXQiLCJyZXF1ZXN0cyIsImVycm9ycyIsIm9uIiwicmVxdWVzdCIsInB1c2giLCJ1cmwiLCJlcnJvciIsIm1lc3NhZ2UiLCJnb3RvIiwiZmlsdGVyIiwidG9FcXVhbCIsInBvbGwiLCJfd2luZG93JF9fUVVPUklET1JfREkiLCJ3aW5kb3ciLCJfX1FVT1JJRE9SX0RJQUdOT1NUSUNTX18iLCJwaGFzZSIsInRvQmUiLCJzZWxlY3RPcHRpb24iLCJfd2luZG93JF9fUVVPUklET1JfQVAiLCJfX1FVT1JJRE9SX0FQUF9URVNUX0FQSV9fIiwic3RhdGUiLCJwb2ludCIsInByb2plY3RDZWxsIiwibW91c2UiLCJ4IiwieSIsIl93aW5kb3ckX19RVU9SSURPUl9BUDIiLCJ2aWV3IiwicGx5IiwicmVwbGF5IiwiZXhwb3J0UmVwbGF5IiwibGVnYWN5IiwidG9CZVRydXRoeSIsInRvSGF2ZUF0dHJpYnV0ZSIsIm90aGVsbG8iLCJzY3JlZW5zaG90IiwicGF0aCIsImluZm8iLCJvdXRwdXRQYXRoIiwiX3dpbmRvdyRfX1FVT1JJRE9SX0RJMiIsIl93aW5kb3ckX19RVU9SSURPUl9BUDMiLCJ0b0NvbnRhaW5UZXh0IiwiZ29CYWNrIiwiZ29Gb3J3YXJkIiwiVVJMIiwicGF0aG5hbWUiLCJwcm9qZWN0IiwidXNlIiwiYmFzZVVSTCIsInRvSGF2ZUNvdW50Iiwic2V0Vmlld3BvcnRTaXplIiwid2lkdGgiLCJoZWlnaHQiLCJ3b3JrZXJzIiwid29ya2VyIiwiZm9jdXMiLCJrZXlib2FyZCIsInByZXNzIiwidG9CZUZvY3VzZWQiLCJkb2N1bWVudCIsImRvY3VtZW50RWxlbWVudCIsInNjcm9sbFdpZHRoIiwiaW5uZXJXaWR0aCIsInRvSGF2ZUxlbmd0aCIsImFkZEluaXRTY3JpcHQiLCJOYXRpdmUiLCJXb3JrZXIiLCJtb25pdG9yIiwic3RhcnRzIiwic3RvcHMiLCJsYXRlIiwib3RoZWxsb1dvcmtlciIsInBvc3RNZXNzYWdlIiwiY2FsbGJhY2siLCJzYXZlZENhbGxiYWNrIiwiTWVzc2FnZUV2ZW50IiwiZGF0YSIsImlkIiwiZ2VuZXJhdGlvbiIsIm9rIiwibW92ZSIsImFkZEV2ZW50TGlzdGVuZXIiLCJ0eXBlIiwib3B0aW9ucyIsInRlcm1pbmF0ZSIsInNldEl0ZW0iLCJjb25maXJtZWQiLCJyZWxlYXNlIiwicmVxdWVzdGVkIiwiZ2F0ZSIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVhY2hlZCIsInJvdXRlIiwiY29udGludWUiLCJ3YWl0Rm9yTG9hZFN0YXRlIiwidG9CZU51bGwiLCJub3QiLCJ0b0JlRW1wdHkiLCJTdG9yYWdlIiwicHJvdG90eXBlIiwiRE9NRXhjZXB0aW9uIiwicmVzdW1lIiwiYm9hcmQiLCJ0b01vdmUiLCJKU09OIiwic3RyaW5naWZ5IiwidmVyc2lvbiIsIm1vZGUiLCJodW1hblNpZGUiLCJmb3JjZWQiLCJBcnJheSIsImZpbGwiLCJmcm9tIiwibGVuZ3RoIiwiXyIsImkiLCJ0b0JlSGlkZGVuIiwiY291bnQiXSwic291cmNlcyI6WyJtdWx0aS1nYW1lLXNoZWxsLnNwZWMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdGVzdCwgZXhwZWN0LCB0eXBlIFBhZ2UgfSBmcm9tICdAcGxheXdyaWdodC90ZXN0JztcblxuY29uc3QgT1RIRUxMT19TQVZFID0gJ290aGVsbG8uZ2FtZS52MSc7XG5jb25zdCBMRUdBQ1lfR0FNRSA9ICdxdW9yaWRvci5tMS5nYW1lLnYxJztcbmNvbnN0IExFR0FDWV9TRVRUSU5HUyA9ICdxdW9yaWRvci5tMS5zZXR0aW5ncy52MSc7XG5jb25zdCBMRUdBQ1lfQVVESU8gPSAncXVvcmlkb3IuYXVkaW8uc2V0dGluZ3MudjEnO1xuY29uc3QgY2VsbCA9IChwYWdlOiBQYWdlLCBpbmRleDogbnVtYmVyKSA9PiBwYWdlLmxvY2F0b3IoYC5vdGhlbGxvLWNlbGxbZGF0YS1pbmRleD1cIiR7aW5kZXh9XCJdYCk7XG5jb25zdCBvcGVuT3RoZWxsbyA9IGFzeW5jIChwYWdlOiBQYWdlKSA9PiB7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI2Nob29zZS1vdGhlbGxvJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLm90aGVsbG8gaDEnKSkudG9IYXZlVGV4dCgnT3RoZWxsbycpO1xufTtcbmNvbnN0IGxlYXZlT3RoZWxsbyA9IGFzeW5jIChwYWdlOiBQYWdlKSA9PiB7XG4gIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdsaW5rJywgeyBuYW1lOiAn44Ky44O844Og5LiA6Kan44G45oi744KLJyB9KS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuaG9tZS1wYWdlJykpLnRvQmVWaXNpYmxlKCk7XG59O1xuYXN5bmMgZnVuY3Rpb24gbGVnYWN5U2xvdHMocGFnZTogUGFnZSkge1xuICByZXR1cm4gcGFnZS5ldmFsdWF0ZShcbiAgICAoW2dhbWUsIHNldHRpbmdzLCBhdWRpb10pID0+IFtnYW1lLCBzZXR0aW5ncywgYXVkaW9dLm1hcCgoa2V5KSA9PiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkhKSksXG4gICAgW0xFR0FDWV9HQU1FLCBMRUdBQ1lfU0VUVElOR1MsIExFR0FDWV9BVURJT10sXG4gICk7XG59XG5hc3luYyBmdW5jdGlvbiBzYXZlZE90aGVsbG8ocGFnZTogUGFnZSkge1xuICByZXR1cm4gcGFnZS5ldmFsdWF0ZSgoa2V5KSA9PiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpLCBPVEhFTExPX1NBVkUpO1xufVxuXG50ZXN0KCduZXcgY3Jvc3MtZ2FtZSBmbG93IHBsYXlzIGFuZCBzYXZlcyBib3RoIGdhbWVzLCByZXN1bWVzIGxlZ2FjeSBhbmQgT3RoZWxsbyBzbG90cywgcHJlc2VydmVzIGhpc3RvcnkgYW5kIGJhc2VwYXRoJywgYXN5bmMgKHtcbiAgcGFnZSxcbn0pID0+IHtcbiAgLy8gVHdvIHJlYWwgUXVvcmlkb3IgbW91bnRzIGFuZCB0ZWFyZG93biBjb21waWxlL3JlbmRlciBQQlIgb24gdGhlIGFzc2lnbmVkIHNpbmdsZSBDUFUuXG4gIC8vIFRoaXMgdGVzdCBidWRnZXQgaXMgaW5kZXBlbmRlbnQgb2YgdGhlIHVuY2hhbmdlZCBwcm9jZXNzIHJlc291cmNlL2RlYWRsaW5lIGd1YXJkLlxuICB0ZXN0LnNldFRpbWVvdXQoMTIwXzAwMCk7XG4gIGNvbnN0IHJlcXVlc3RzOiBzdHJpbmdbXSA9IFtdLFxuICAgIGVycm9yczogc3RyaW5nW10gPSBbXTtcbiAgcGFnZS5vbigncmVxdWVzdCcsIChyZXF1ZXN0KSA9PiByZXF1ZXN0cy5wdXNoKHJlcXVlc3QudXJsKCkpKTtcbiAgcGFnZS5vbigncGFnZWVycm9yJywgKGVycm9yKSA9PiBlcnJvcnMucHVzaChlcnJvci5tZXNzYWdlKSk7XG4gIGF3YWl0IHBhZ2UuZ290bygnLi8/Zm9yY2VXZWJHTD0xIy8nKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI2Nob29zZS1vdGhlbGxvJykpLnRvQmVWaXNpYmxlKCk7XG4gIGV4cGVjdChcbiAgICByZXF1ZXN0cy5maWx0ZXIoKHVybCkgPT4gL1xcLndhc218YWlcXC53b3JrZXJ8cXVvcmlkb3ItfG90aGVsbG8tfFxcLmhkcnxcXC5tcDN8XFwub2dnLy50ZXN0KHVybCkpLFxuICApLnRvRXF1YWwoW10pO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNjaG9vc2UtcXVvcmlkb3InKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3RcbiAgICAucG9sbCgoKSA9PiBwYWdlLmV2YWx1YXRlKCgpID0+IHdpbmRvdy5fX1FVT1JJRE9SX0RJQUdOT1NUSUNTX18/LnBoYXNlKSlcbiAgICAudG9CZSgncmVhZHknKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjc3RhcnR1cC1uZXctZ2FtZScpLmNsaWNrKCk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI21hdGNoLW1vZGUnKS5zZWxlY3RPcHRpb24oJ3B2cCcpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNkaWFsb2ctc3RhcnQnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3RcbiAgICAucG9sbCgoKSA9PiBwYWdlLmV2YWx1YXRlKCgpID0+IHdpbmRvdy5fX1FVT1JJRE9SX0FQUF9URVNUX0FQSV9fPy5zdGF0ZSgpLnBoYXNlKSlcbiAgICAudG9CZSgnaHVtYW5UdXJuJyk7XG4gIGNvbnN0IHBvaW50ID0gYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiB3aW5kb3cuX19RVU9SSURPUl9BUFBfVEVTVF9BUElfXyEucHJvamVjdENlbGwoMTMpKTtcbiAgYXdhaXQgcGFnZS5tb3VzZS5jbGljayhwb2ludC54LCBwb2ludC55KTtcbiAgYXdhaXQgZXhwZWN0XG4gICAgLnBvbGwoKCkgPT4gcGFnZS5ldmFsdWF0ZSgoKSA9PiB3aW5kb3cuX19RVU9SSURPUl9BUFBfVEVTVF9BUElfXz8uc3RhdGUoKS52aWV3Py5wbHkpKVxuICAgIC50b0JlKDEpO1xuICBjb25zdCByZXBsYXkgPSBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IHdpbmRvdy5fX1FVT1JJRE9SX0FQUF9URVNUX0FQSV9fIS5leHBvcnRSZXBsYXkoKSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignLnRvcC1hY3Rpb25zIC5ob21lLWxpbmsnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuaG9tZS1wYWdlJykpLnRvQmVWaXNpYmxlKCk7XG4gIGNvbnN0IGxlZ2FjeSA9IGF3YWl0IGxlZ2FjeVNsb3RzKHBhZ2UpO1xuICBleHBlY3QobGVnYWN5WzBdKS50b0JlVHJ1dGh5KCk7XG4gIGF3YWl0IG9wZW5PdGhlbGxvKHBhZ2UpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLW5ldycpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNjb3JlJykpLnRvSGF2ZVRleHQoJ+m7kiAyIOefsyDvvI8g55m9IDIg55+zJyk7XG4gIGF3YWl0IGNlbGwocGFnZSwgMTkpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNjb3JlJykpLnRvSGF2ZVRleHQoJ+m7kiA0IOefsyDvvI8g55m9IDEg55+zJyk7XG4gIGF3YWl0IGV4cGVjdChjZWxsKHBhZ2UsIDI3KSkudG9IYXZlQXR0cmlidXRlKCdkYXRhLXN0b25lJywgJzEnKTtcbiAgY29uc3Qgb3RoZWxsbyA9IGF3YWl0IHNhdmVkT3RoZWxsbyhwYWdlKTtcbiAgYXdhaXQgcGFnZS5zY3JlZW5zaG90KHsgcGF0aDogdGVzdC5pbmZvKCkub3V0cHV0UGF0aCgnb3RoZWxsby1wbGF5LnBuZycpIH0pO1xuICBhd2FpdCBsZWF2ZU90aGVsbG8ocGFnZSk7XG4gIGV4cGVjdChhd2FpdCBsZWdhY3lTbG90cyhwYWdlKSkudG9FcXVhbChsZWdhY3kpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNjaG9vc2UtcXVvcmlkb3InKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3RcbiAgICAucG9sbCgoKSA9PiBwYWdlLmV2YWx1YXRlKCgpID0+IHdpbmRvdy5fX1FVT1JJRE9SX0RJQUdOT1NUSUNTX18/LnBoYXNlKSlcbiAgICAudG9CZSgncmVhZHknKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjcmVzdW1lLWdhbWUtY2hvaWNlJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0XG4gICAgLnBvbGwoKCkgPT4gcGFnZS5ldmFsdWF0ZSgoKSA9PiB3aW5kb3cuX19RVU9SSURPUl9BUFBfVEVTVF9BUElfXz8uc3RhdGUoKS5waGFzZSkpXG4gICAgLnRvQmUoJ2h1bWFuVHVybicpO1xuICBleHBlY3QoYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiB3aW5kb3cuX19RVU9SSURPUl9BUFBfVEVTVF9BUElfXyEuZXhwb3J0UmVwbGF5KCkpKS50b0VxdWFsKFxuICAgIHJlcGxheSxcbiAgKTtcbiAgZXhwZWN0KGF3YWl0IHNhdmVkT3RoZWxsbyhwYWdlKSkudG9CZShvdGhlbGxvKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcudG9wLWFjdGlvbnMgLmhvbWUtbGluaycpLmNsaWNrKCk7XG4gIGF3YWl0IG9wZW5PdGhlbGxvKHBhZ2UpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXJlc3VtZScpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNjb3JlJykpLnRvSGF2ZVRleHQoJ+m7kiA0IOefsyDvvI8g55m9IDEg55+zJyk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXBsYXllcnMnKSkudG9Db250YWluVGV4dCgn44Ot44O844Kr44OrMuS6uicpO1xuICBhd2FpdCBwYWdlLmdvQmFjaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcuaG9tZS1wYWdlJykpLnRvQmVWaXNpYmxlKCk7XG4gIGF3YWl0IHBhZ2UuZ29Gb3J3YXJkKCk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tcmVzdW1lJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tdHVybicpKS50b0hhdmVUZXh0KCfnmb3jga7miYvnlaonKTtcbiAgYXdhaXQgcGFnZS5nb3RvKCcuLz9mb3JjZVdlYkdMPTEjL290aGVsbG8nKTtcbiAgZXhwZWN0KG5ldyBVUkwocGFnZS51cmwoKSkucGF0aG5hbWUpLnRvQmUobmV3IFVSTCh0ZXN0LmluZm8oKS5wcm9qZWN0LnVzZS5iYXNlVVJMISkucGF0aG5hbWUpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXJlc3VtZScpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNjb3JlJykpLnRvSGF2ZVRleHQoJ+m7kiA0IOefsyDvvI8g55m9IDEg55+zJyk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJ2NhbnZhcywgZGlhbG9nJykpLnRvSGF2ZUNvdW50KDApO1xuICBleHBlY3QoZXJyb3JzKS50b0VxdWFsKFtdKTtcbn0pO1xuXG50ZXN0KCdPdGhlbGxvLW9ubHkgZW50cnkgcmVtYWlucyBsYXp5IG9uIGhvbWUsIGtleWJvYXJkIHBsYXkgYW5kIHJlYWwgYm91bmRlZCBBSSB1c2UgZXhwbGljaXQgaHVtYW4gY29sb3JzJywgYXN5bmMgKHtcbiAgcGFnZSxcbn0pID0+IHtcbiAgYXdhaXQgcGFnZS5zZXRWaWV3cG9ydFNpemUoeyB3aWR0aDogMzc1LCBoZWlnaHQ6IDgxMiB9KTtcbiAgY29uc3Qgd29ya2Vyczogc3RyaW5nW10gPSBbXTtcbiAgcGFnZS5vbignd29ya2VyJywgKHdvcmtlcikgPT4gd29ya2Vycy5wdXNoKHdvcmtlci51cmwoKSkpO1xuICBhd2FpdCBwYWdlLmdvdG8oJy4vIy8nKTtcbiAgYXdhaXQgb3Blbk90aGVsbG8ocGFnZSk7XG4gIGV4cGVjdCh3b3JrZXJzKS50b0VxdWFsKFtdKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1uZXcnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QoY2VsbChwYWdlLCAxOSkpLnRvSGF2ZUF0dHJpYnV0ZSgnYXJpYS1kaXNhYmxlZCcsICdmYWxzZScpO1xuICBhd2FpdCBjZWxsKHBhZ2UsIDE5KS5mb2N1cygpO1xuICBhd2FpdCBwYWdlLmtleWJvYXJkLnByZXNzKCdBcnJvd1JpZ2h0Jyk7XG4gIGF3YWl0IGV4cGVjdChjZWxsKHBhZ2UsIDIwKSkudG9CZUZvY3VzZWQoKTtcbiAgYXdhaXQgcGFnZS5rZXlib2FyZC5wcmVzcygnQXJyb3dMZWZ0Jyk7XG4gIGF3YWl0IHBhZ2Uua2V5Ym9hcmQucHJlc3MoJ0VudGVyJyk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNjb3JlJykpLnRvSGF2ZVRleHQoJ+m7kiA0IOefsyDvvI8g55m9IDEg55+zJyk7XG4gIGV4cGVjdChhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxXaWR0aCA8PSBpbm5lcldpZHRoKSkudG9CZSh0cnVlKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1tb2RlJykuc2VsZWN0T3B0aW9uKCdhaScpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLWh1bWFuLXNpZGUnKS5zZWxlY3RPcHRpb24oJzInKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1uZXcnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1wbGF5ZXJzJykpLnRvSGF2ZVRleHQoXG4gICAgJ+ewoeaYk0FJ77yI6Z2e5a2m57+S77yJ44Go5a++5oimIMK3IOS6uumWk++8mueZvSDvvI8g57Ch5piTQUnvvJrpu5InLFxuICApO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1zY29yZScpKS50b0hhdmVUZXh0KCfpu5IgNCDnn7Mg77yPIOeZvSAxIOefsycpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby10dXJuJykpLnRvSGF2ZVRleHQoJ+eZveOBruaJi+eVqicpO1xuICBleHBlY3Qod29ya2VycykudG9IYXZlTGVuZ3RoKDEpO1xuICBhd2FpdCBleHBlY3QoY2VsbChwYWdlLCAxOSkpLnRvSGF2ZUF0dHJpYnV0ZSgnZGF0YS1zdG9uZScsICcxJyk7XG4gIGF3YWl0IGxlYXZlT3RoZWxsbyhwYWdlKTtcbiAgYXdhaXQgb3Blbk90aGVsbG8ocGFnZSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tcmVzdW1lJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tcGxheWVycycpKS50b0NvbnRhaW5UZXh0KCfkurrplpPvvJrnmb0g77yPIOewoeaYk0FJ77ya6buSJyk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXR1cm4nKSkudG9IYXZlVGV4dCgn55m944Gu5omL55WqJyk7XG4gIGV4cGVjdCh3b3JrZXJzKS50b0hhdmVMZW5ndGgoMSk7XG59KTtcblxudGVzdCgnT3RoZWxsbyBXb3JrZXIgcGVuZGluZyBjYW5jZWxsYXRpb24gdGVybWluYXRlcyBvbmNlIGFuZCByZWplY3RzIGEgZGVsaWJlcmF0ZWx5IGxhdGUgbWVzc2FnZSB3aXRob3V0IG11dGF0aW9uIG9yIGxlZ2FjeSB3cml0ZXMnLCBhc3luYyAoe1xuICBwYWdlLFxufSkgPT4ge1xuICBhd2FpdCBwYWdlLmFkZEluaXRTY3JpcHQoKCkgPT4ge1xuICAgIGNvbnN0IE5hdGl2ZSA9IHdpbmRvdy5Xb3JrZXI7XG4gICAgY29uc3QgbW9uaXRvciA9IHsgc3RhcnRzOiAwLCBzdG9wczogMCwgbGF0ZTogKCkgPT4ge30gfTtcbiAgICAod2luZG93IGFzIGFueSkub3RoZWxsb1dvcmtlciA9IG1vbml0b3I7XG4gICAgd2luZG93LldvcmtlciA9IGNsYXNzIGV4dGVuZHMgTmF0aXZlIHtcbiAgICAgIG92ZXJyaWRlIHBvc3RNZXNzYWdlKG1lc3NhZ2U6IGFueSk6IHZvaWQge1xuICAgICAgICBtb25pdG9yLnN0YXJ0cysrO1xuICAgICAgICBjb25zdCBjYWxsYmFjayA9ICh0aGlzIGFzIGFueSkuc2F2ZWRDYWxsYmFjaztcbiAgICAgICAgbW9uaXRvci5sYXRlID0gKCkgPT5cbiAgICAgICAgICBjYWxsYmFjayhcbiAgICAgICAgICAgIG5ldyBNZXNzYWdlRXZlbnQoJ21lc3NhZ2UnLCB7XG4gICAgICAgICAgICAgIGRhdGE6IHsgaWQ6IG1lc3NhZ2UuaWQsIGdlbmVyYXRpb246IG1lc3NhZ2UuZ2VuZXJhdGlvbiwgb2s6IHRydWUsIG1vdmU6IDE5IH0sXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICApO1xuICAgICAgICAvLyBLZWVwIHRoZSByZWFsIGdhbWUtb3duZWQgV29ya2VyIHBlbmRpbmc7IGRlbGl2ZXIgdGhlIGNhcHR1cmVkIGNhbGxiYWNrIGFmdGVyIHRlYXJkb3duLlxuICAgICAgfVxuICAgICAgb3ZlcnJpZGUgYWRkRXZlbnRMaXN0ZW5lcih0eXBlOiBhbnksIGNhbGxiYWNrOiBhbnksIG9wdGlvbnM/OiBhbnkpOiB2b2lkIHtcbiAgICAgICAgaWYgKHR5cGUgPT09ICdtZXNzYWdlJykgKHRoaXMgYXMgYW55KS5zYXZlZENhbGxiYWNrID0gY2FsbGJhY2s7XG4gICAgICAgIHN1cGVyLmFkZEV2ZW50TGlzdGVuZXIodHlwZSwgY2FsbGJhY2ssIG9wdGlvbnMpO1xuICAgICAgfVxuICAgICAgb3ZlcnJpZGUgdGVybWluYXRlKCk6IHZvaWQge1xuICAgICAgICBtb25pdG9yLnN0b3BzKys7XG4gICAgICAgIHN1cGVyLnRlcm1pbmF0ZSgpO1xuICAgICAgfVxuICAgIH07XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3F1b3JpZG9yLm0xLmdhbWUudjEnLCAnbGVnYWN5IHNlbnRpbmVsJyk7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3F1b3JpZG9yLm0xLnNldHRpbmdzLnYxJywgJ3NldHRpbmdzIHNlbnRpbmVsJyk7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3F1b3JpZG9yLmF1ZGlvLnNldHRpbmdzLnYxJywgJ2F1ZGlvIHNlbnRpbmVsJyk7XG4gIH0pO1xuICBhd2FpdCBwYWdlLmdvdG8oJy4vIy9vdGhlbGxvJyk7XG4gIGNvbnN0IGxlZ2FjeSA9IGF3YWl0IGxlZ2FjeVNsb3RzKHBhZ2UpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLW1vZGUnKS5zZWxlY3RPcHRpb24oJ2FpJyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8taHVtYW4tc2lkZScpLnNlbGVjdE9wdGlvbignMicpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLW5ldycpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXR1cm4nKSkudG9Db250YWluVGV4dCgn6ICD44GI44Gm44GE44G+44GZJyk7XG4gIGNvbnN0IGNvbmZpcm1lZCA9IGF3YWl0IHNhdmVkT3RoZWxsbyhwYWdlKTtcbiAgYXdhaXQgbGVhdmVPdGhlbGxvKHBhZ2UpO1xuICBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+ICh3aW5kb3cgYXMgYW55KS5vdGhlbGxvV29ya2VyLmxhdGUoKSk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5vdGhlbGxvLCAub3RoZWxsby1ib2FyZCwgY2FudmFzJykpLnRvSGF2ZUNvdW50KDApO1xuICBleHBlY3QoYXdhaXQgc2F2ZWRPdGhlbGxvKHBhZ2UpKS50b0JlKGNvbmZpcm1lZCk7XG4gIGV4cGVjdChhd2FpdCBsZWdhY3lTbG90cyhwYWdlKSkudG9FcXVhbChsZWdhY3kpO1xuICBleHBlY3QoXG4gICAgYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiAoe1xuICAgICAgc3RhcnRzOiAod2luZG93IGFzIGFueSkub3RoZWxsb1dvcmtlci5zdGFydHMsXG4gICAgICBzdG9wczogKHdpbmRvdyBhcyBhbnkpLm90aGVsbG9Xb3JrZXIuc3RvcHMsXG4gICAgfSkpLFxuICApLnRvRXF1YWwoeyBzdGFydHM6IDEsIHN0b3BzOiAxIH0pO1xufSk7XG5cbnRlc3QoJ2xlYXZpbmcgT3RoZWxsbyBkdXJpbmcgYWN0dWFsIFdhc20gaW5pdGlhbGl6YXRpb24gY2Fubm90IHNhdmUgb3IgcmVuZGVyIHRoZSBsYXRlIHJlc3VsdCcsIGFzeW5jICh7XG4gIHBhZ2UsXG59KSA9PiB7XG4gIGxldCByZWxlYXNlITogKCkgPT4gdm9pZCwgcmVxdWVzdGVkITogKCkgPT4gdm9pZDtcbiAgY29uc3QgZ2F0ZSA9IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiB7XG4gICAgcmVsZWFzZSA9IHJlc29sdmU7XG4gIH0pO1xuICBjb25zdCByZWFjaGVkID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcbiAgICByZXF1ZXN0ZWQgPSByZXNvbHZlO1xuICB9KTtcbiAgYXdhaXQgcGFnZS5yb3V0ZSgnKiovKm90aGVsbG9fYmcqLndhc20nLCBhc3luYyAocm91dGUpID0+IHtcbiAgICByZXF1ZXN0ZWQoKTtcbiAgICBhd2FpdCBnYXRlO1xuICAgIGF3YWl0IHJvdXRlLmNvbnRpbnVlKCk7XG4gIH0pO1xuICBhd2FpdCBwYWdlLmdvdG8oJy4vIy9vdGhlbGxvJyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tbmV3JykuY2xpY2soKTtcbiAgYXdhaXQgcmVhY2hlZDtcbiAgYXdhaXQgbGVhdmVPdGhlbGxvKHBhZ2UpO1xuICByZWxlYXNlKCk7XG4gIGF3YWl0IHBhZ2Uud2FpdEZvckxvYWRTdGF0ZSgnbmV0d29ya2lkbGUnKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLm90aGVsbG8sIC5vdGhlbGxvLWJvYXJkJykpLnRvSGF2ZUNvdW50KDApO1xuICBleHBlY3QoYXdhaXQgc2F2ZWRPdGhlbGxvKHBhZ2UpKS50b0JlTnVsbCgpO1xufSk7XG5cbnRlc3QoJ2JhZCBzYXZlcyBhcmUgcmV0YWluZWQsIHJldHJ5IGFuZCBleHBsaWNpdCBuZXcgYXJlIGF2YWlsYWJsZSwgdW5hdmFpbGFibGUgc3RvcmFnZSBpcyB2aXNpYmxlIHRocm91Z2ggZXhpdCcsIGFzeW5jICh7XG4gIHBhZ2UsXG59KSA9PiB7XG4gIGF3YWl0IHBhZ2UuZ290bygnLi8jL290aGVsbG8nKTtcbiAgYXdhaXQgcGFnZS5ldmFsdWF0ZSgoa2V5KSA9PiBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShrZXksICd7YnJva2VuJyksIE9USEVMTE9fU0FWRSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tcmVzdW1lJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tZXJyb3InKSkubm90LnRvQmVFbXB0eSgpO1xuICBleHBlY3QoYXdhaXQgc2F2ZWRPdGhlbGxvKHBhZ2UpKS50b0JlKCd7YnJva2VuJyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tcmVzdW1lJykuY2xpY2soKTtcbiAgZXhwZWN0KGF3YWl0IHNhdmVkT3RoZWxsbyhwYWdlKSkudG9CZSgne2Jyb2tlbicpO1xuICAvLyBUaGUgdXNlcidzIGV4cGxpY2l0IG5ldyBzZWxlY3Rpb24gYXV0aG9yaXplcyByZXBsYWNpbmcgdGhlIGJyb2tlbiBPdGhlbGxvIHNsb3QuXG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tbmV3JykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tc2NvcmUnKSkudG9IYXZlVGV4dCgn6buSIDIg55+zIO+8jyDnmb0gMiDnn7MnKTtcbiAgYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiB7XG4gICAgU3RvcmFnZS5wcm90b3R5cGUuc2V0SXRlbSA9ICgpID0+IHtcbiAgICAgIHRocm93IG5ldyBET01FeGNlcHRpb24oJ3F1b3RhJywgJ1F1b3RhRXhjZWVkZWRFcnJvcicpO1xuICAgIH07XG4gIH0pO1xuICBhd2FpdCBjZWxsKHBhZ2UsIDE5KS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1zYXZlLXN0YXR1cycpKS50b0NvbnRhaW5UZXh0KCfkv53lrZjjgafjgY3jgb7jgZvjgpMnKTtcbiAgYXdhaXQgbGVhdmVPdGhlbGxvKHBhZ2UpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjaG9tZS1zYXZlLXdhcm5pbmcnKSkudG9Db250YWluVGV4dCgnT3RoZWxsb+OCkuS/neWtmOOBp+OBjeOBvuOBm+OCkycpO1xufSk7XG5cbnRlc3QoJ3NhdmVkIGZvcmNlZC1wYXNzIGFuZCB0ZXJtaW5hbCBmaXh0dXJlcyByZW5kZXIgUnVzdCBzdGF0dXMsIHdpbnMgYW5kIGRyYXcgd2l0aG91dCBKUyBydWxlcycsIGFzeW5jICh7XG4gIHBhZ2UsXG59KSA9PiB7XG4gIGF3YWl0IHBhZ2UuZ290bygnLi8jL290aGVsbG8nKTtcbiAgYXN5bmMgZnVuY3Rpb24gcmVzdW1lKGJvYXJkOiBudW1iZXJbXSwgdG9Nb3ZlOiBudW1iZXIpIHtcbiAgICBhd2FpdCBwYWdlLmV2YWx1YXRlKFxuICAgICAgKHsga2V5LCBib2FyZCwgdG9Nb3ZlIH0pID0+XG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFxuICAgICAgICAgIGtleSxcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICB2ZXJzaW9uOiAxLFxuICAgICAgICAgICAgZ2FtZTogJ290aGVsbG8nLFxuICAgICAgICAgICAgbW9kZTogJ2xvY2FsJyxcbiAgICAgICAgICAgIGh1bWFuU2lkZTogMSxcbiAgICAgICAgICAgIHN0YXRlOiB7IHZlcnNpb246IDEsIGJvYXJkLCB0b01vdmUgfSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgKSxcbiAgICAgIHsga2V5OiBPVEhFTExPX1NBVkUsIGJvYXJkLCB0b01vdmUgfSxcbiAgICApO1xuICAgIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tcmVzdW1lJykuY2xpY2soKTtcbiAgfVxuICBjb25zdCBmb3JjZWQgPSBBcnJheTxudW1iZXI+KDY0KS5maWxsKDApO1xuICBmb3JjZWRbMF0gPSAxO1xuICBmb3JjZWRbMV0gPSAyO1xuICBhd2FpdCByZXN1bWUoZm9yY2VkLCAyKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tZ3VpZGUnKSkudG9Db250YWluVGV4dCgn44OR44K544GM5b+F6KaBJyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tcGFzcycpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXR1cm4nKSkudG9IYXZlVGV4dCgn6buS44Gu5omL55WqJyk7XG4gIGF3YWl0IGNlbGwocGFnZSwgMikuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tdHVybicpKS50b0hhdmVUZXh0KCfntYLlsYDvvJrpu5Ljga7li53jgaEnKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tc2NvcmUnKSkudG9IYXZlVGV4dCgn6buSIDMg55+zIO+8jyDnmb0gMCDnn7MnKTtcbiAgYXdhaXQgcmVzdW1lKEFycmF5PG51bWJlcj4oNjQpLmZpbGwoMiksIDEpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby10dXJuJykpLnRvSGF2ZVRleHQoJ+e1guWxgO+8mueZveOBruWLneOBoScpO1xuICBhd2FpdCByZXN1bWUoXG4gICAgQXJyYXkuZnJvbSh7IGxlbmd0aDogNjQgfSwgKF8sIGkpID0+IChpIDwgMzIgPyAxIDogMikpLFxuICAgIDIsXG4gICk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXR1cm4nKSkudG9IYXZlVGV4dCgn57WC5bGA77ya5byV5YiG44GRJyk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXBhc3MnKSkudG9CZUhpZGRlbigpO1xuICBleHBlY3QoYXdhaXQgcGFnZS5sb2NhdG9yKCcub3RoZWxsby1jZWxsW2FyaWEtZGlzYWJsZWQ9XCJmYWxzZVwiXScpLmNvdW50KCkpLnRvQmUoMCk7XG59KTtcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0EsSUFBSSxFQUFFQyxNQUFNLFFBQW1CLGtCQUFrQjtBQUUxRCxNQUFNQyxZQUFZLEdBQUcsaUJBQWlCO0FBQ3RDLE1BQU1DLFdBQVcsR0FBRyxxQkFBcUI7QUFDekMsTUFBTUMsZUFBZSxHQUFHLHlCQUF5QjtBQUNqRCxNQUFNQyxZQUFZLEdBQUcsNEJBQTRCO0FBQ2pELE1BQU1DLElBQUksR0FBR0EsQ0FBQ0MsSUFBVSxFQUFFQyxLQUFhLEtBQUtELElBQUksQ0FBQ0UsT0FBTyxDQUFDLDZCQUE2QkQsS0FBSyxJQUFJLENBQUM7QUFDaEcsTUFBTUUsV0FBVyxHQUFHLE1BQU9ILElBQVUsSUFBSztFQUN4QyxNQUFNQSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUM3QyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxTQUFTLENBQUM7QUFDakUsQ0FBQztBQUNELE1BQU1DLFlBQVksR0FBRyxNQUFPTixJQUFVLElBQUs7RUFDekMsTUFBTUEsSUFBSSxDQUFDTyxTQUFTLENBQUMsTUFBTSxFQUFFO0lBQUVDLElBQUksRUFBRTtFQUFXLENBQUMsQ0FBQyxDQUFDSixLQUFLLENBQUMsQ0FBQztFQUMxRCxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUNPLFdBQVcsQ0FBQyxDQUFDO0FBQ3hELENBQUM7QUFDRCxlQUFlQyxXQUFXQSxDQUFDVixJQUFVLEVBQUU7RUFDckMsT0FBT0EsSUFBSSxDQUFDVyxRQUFRLENBQ2xCLENBQUMsQ0FBQ0MsSUFBSSxFQUFFQyxRQUFRLEVBQUVDLEtBQUssQ0FBQyxLQUFLLENBQUNGLElBQUksRUFBRUMsUUFBUSxFQUFFQyxLQUFLLENBQUMsQ0FBQ0MsR0FBRyxDQUFFQyxHQUFHLElBQUtDLFlBQVksQ0FBQ0MsT0FBTyxDQUFDRixHQUFJLENBQUMsQ0FBQyxFQUM3RixDQUFDcEIsV0FBVyxFQUFFQyxlQUFlLEVBQUVDLFlBQVksQ0FDN0MsQ0FBQztBQUNIO0FBQ0EsZUFBZXFCLFlBQVlBLENBQUNuQixJQUFVLEVBQUU7RUFDdEMsT0FBT0EsSUFBSSxDQUFDVyxRQUFRLENBQUVLLEdBQUcsSUFBS0MsWUFBWSxDQUFDQyxPQUFPLENBQUNGLEdBQUcsQ0FBQyxFQUFFckIsWUFBWSxDQUFDO0FBQ3hFO0FBRUFGLElBQUksQ0FBQyxrSEFBa0gsRUFBRSxPQUFPO0VBQzlITztBQUNGLENBQUMsS0FBSztFQUNKO0VBQ0E7RUFDQVAsSUFBSSxDQUFDMkIsVUFBVSxDQUFDLE1BQU8sQ0FBQztFQUN4QixNQUFNQyxRQUFrQixHQUFHLEVBQUU7SUFDM0JDLE1BQWdCLEdBQUcsRUFBRTtFQUN2QnRCLElBQUksQ0FBQ3VCLEVBQUUsQ0FBQyxTQUFTLEVBQUdDLE9BQU8sSUFBS0gsUUFBUSxDQUFDSSxJQUFJLENBQUNELE9BQU8sQ0FBQ0UsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzdEMUIsSUFBSSxDQUFDdUIsRUFBRSxDQUFDLFdBQVcsRUFBR0ksS0FBSyxJQUFLTCxNQUFNLENBQUNHLElBQUksQ0FBQ0UsS0FBSyxDQUFDQyxPQUFPLENBQUMsQ0FBQztFQUMzRCxNQUFNNUIsSUFBSSxDQUFDNkIsSUFBSSxDQUFDLG1CQUFtQixDQUFDO0VBQ3BDLE1BQU1uQyxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQ08sV0FBVyxDQUFDLENBQUM7RUFDM0RmLE1BQU0sQ0FDSjJCLFFBQVEsQ0FBQ1MsTUFBTSxDQUFFSixHQUFHLElBQUssd0RBQXdELENBQUNqQyxJQUFJLENBQUNpQyxHQUFHLENBQUMsQ0FDN0YsQ0FBQyxDQUFDSyxPQUFPLENBQUMsRUFBRSxDQUFDO0VBQ2IsTUFBTS9CLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzlDLE1BQU1WLE1BQU0sQ0FDVHNDLElBQUksQ0FBQyxNQUFNaEMsSUFBSSxDQUFDVyxRQUFRLENBQUM7SUFBQSxJQUFBc0IscUJBQUE7SUFBQSxRQUFBQSxxQkFBQSxHQUFNQyxNQUFNLENBQUNDLHdCQUF3QixjQUFBRixxQkFBQSx1QkFBL0JBLHFCQUFBLENBQWlDRyxLQUFLO0VBQUEsRUFBQyxDQUFDLENBQ3ZFQyxJQUFJLENBQUMsT0FBTyxDQUFDO0VBQ2hCLE1BQU1yQyxJQUFJLENBQUNFLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMvQyxNQUFNSixJQUFJLENBQUNFLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQ29DLFlBQVksQ0FBQyxLQUFLLENBQUM7RUFDckQsTUFBTXRDLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMzQyxNQUFNVixNQUFNLENBQ1RzQyxJQUFJLENBQUMsTUFBTWhDLElBQUksQ0FBQ1csUUFBUSxDQUFDO0lBQUEsSUFBQTRCLHFCQUFBO0lBQUEsUUFBQUEscUJBQUEsR0FBTUwsTUFBTSxDQUFDTSx5QkFBeUIsY0FBQUQscUJBQUEsdUJBQWhDQSxxQkFBQSxDQUFrQ0UsS0FBSyxDQUFDLENBQUMsQ0FBQ0wsS0FBSztFQUFBLEVBQUMsQ0FBQyxDQUNoRkMsSUFBSSxDQUFDLFdBQVcsQ0FBQztFQUNwQixNQUFNSyxLQUFLLEdBQUcsTUFBTTFDLElBQUksQ0FBQ1csUUFBUSxDQUFDLE1BQU11QixNQUFNLENBQUNNLHlCQUF5QixDQUFFRyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7RUFDMUYsTUFBTTNDLElBQUksQ0FBQzRDLEtBQUssQ0FBQ3hDLEtBQUssQ0FBQ3NDLEtBQUssQ0FBQ0csQ0FBQyxFQUFFSCxLQUFLLENBQUNJLENBQUMsQ0FBQztFQUN4QyxNQUFNcEQsTUFBTSxDQUNUc0MsSUFBSSxDQUFDLE1BQU1oQyxJQUFJLENBQUNXLFFBQVEsQ0FBQztJQUFBLElBQUFvQyxzQkFBQTtJQUFBLFFBQUFBLHNCQUFBLEdBQU1iLE1BQU0sQ0FBQ00seUJBQXlCLGNBQUFPLHNCQUFBLGdCQUFBQSxzQkFBQSxHQUFoQ0Esc0JBQUEsQ0FBa0NOLEtBQUssQ0FBQyxDQUFDLENBQUNPLElBQUksY0FBQUQsc0JBQUEsdUJBQTlDQSxzQkFBQSxDQUFnREUsR0FBRztFQUFBLEVBQUMsQ0FBQyxDQUNwRlosSUFBSSxDQUFDLENBQUMsQ0FBQztFQUNWLE1BQU1hLE1BQU0sR0FBRyxNQUFNbEQsSUFBSSxDQUFDVyxRQUFRLENBQUMsTUFBTXVCLE1BQU0sQ0FBQ00seUJBQXlCLENBQUVXLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFDMUYsTUFBTW5ELElBQUksQ0FBQ0UsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQ3JELE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQ08sV0FBVyxDQUFDLENBQUM7RUFDdEQsTUFBTTJDLE1BQU0sR0FBRyxNQUFNMUMsV0FBVyxDQUFDVixJQUFJLENBQUM7RUFDdENOLE1BQU0sQ0FBQzBELE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxVQUFVLENBQUMsQ0FBQztFQUM5QixNQUFNbEQsV0FBVyxDQUFDSCxJQUFJLENBQUM7RUFDdkIsTUFBTUEsSUFBSSxDQUFDRSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzFDLE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsZUFBZSxDQUFDO0VBQ3hFLE1BQU1OLElBQUksQ0FBQ0MsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDSSxLQUFLLENBQUMsQ0FBQztFQUM1QixNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RSxNQUFNWCxNQUFNLENBQUNLLElBQUksQ0FBQ0MsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUNzRCxlQUFlLENBQUMsWUFBWSxFQUFFLEdBQUcsQ0FBQztFQUMvRCxNQUFNQyxPQUFPLEdBQUcsTUFBTXBDLFlBQVksQ0FBQ25CLElBQUksQ0FBQztFQUN4QyxNQUFNQSxJQUFJLENBQUN3RCxVQUFVLENBQUM7SUFBRUMsSUFBSSxFQUFFaEUsSUFBSSxDQUFDaUUsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsVUFBVSxDQUFDLGtCQUFrQjtFQUFFLENBQUMsQ0FBQztFQUMzRSxNQUFNckQsWUFBWSxDQUFDTixJQUFJLENBQUM7RUFDeEJOLE1BQU0sQ0FBQyxNQUFNZ0IsV0FBVyxDQUFDVixJQUFJLENBQUMsQ0FBQyxDQUFDK0IsT0FBTyxDQUFDcUIsTUFBTSxDQUFDO0VBQy9DLE1BQU1wRCxJQUFJLENBQUNFLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUM5QyxNQUFNVixNQUFNLENBQ1RzQyxJQUFJLENBQUMsTUFBTWhDLElBQUksQ0FBQ1csUUFBUSxDQUFDO0lBQUEsSUFBQWlELHNCQUFBO0lBQUEsUUFBQUEsc0JBQUEsR0FBTTFCLE1BQU0sQ0FBQ0Msd0JBQXdCLGNBQUF5QixzQkFBQSx1QkFBL0JBLHNCQUFBLENBQWlDeEIsS0FBSztFQUFBLEVBQUMsQ0FBQyxDQUN2RUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztFQUNoQixNQUFNckMsSUFBSSxDQUFDRSxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDakQsTUFBTVYsTUFBTSxDQUNUc0MsSUFBSSxDQUFDLE1BQU1oQyxJQUFJLENBQUNXLFFBQVEsQ0FBQztJQUFBLElBQUFrRCxzQkFBQTtJQUFBLFFBQUFBLHNCQUFBLEdBQU0zQixNQUFNLENBQUNNLHlCQUF5QixjQUFBcUIsc0JBQUEsdUJBQWhDQSxzQkFBQSxDQUFrQ3BCLEtBQUssQ0FBQyxDQUFDLENBQUNMLEtBQUs7RUFBQSxFQUFDLENBQUMsQ0FDaEZDLElBQUksQ0FBQyxXQUFXLENBQUM7RUFDcEIzQyxNQUFNLENBQUMsTUFBTU0sSUFBSSxDQUFDVyxRQUFRLENBQUMsTUFBTXVCLE1BQU0sQ0FBQ00seUJBQXlCLENBQUVXLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDcEIsT0FBTyxDQUN6Rm1CLE1BQ0YsQ0FBQztFQUNEeEQsTUFBTSxDQUFDLE1BQU15QixZQUFZLENBQUNuQixJQUFJLENBQUMsQ0FBQyxDQUFDcUMsSUFBSSxDQUFDa0IsT0FBTyxDQUFDO0VBQzlDLE1BQU12RCxJQUFJLENBQUNFLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUNyRCxNQUFNRCxXQUFXLENBQUNILElBQUksQ0FBQztFQUN2QixNQUFNQSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUM3QyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RSxNQUFNWCxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQzRELGFBQWEsQ0FBQyxRQUFRLENBQUM7RUFDdEUsTUFBTTlELElBQUksQ0FBQytELE1BQU0sQ0FBQyxDQUFDO0VBQ25CLE1BQU1yRSxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUNPLFdBQVcsQ0FBQyxDQUFDO0VBQ3RELE1BQU1ULElBQUksQ0FBQ2dFLFNBQVMsQ0FBQyxDQUFDO0VBQ3RCLE1BQU1oRSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUM3QyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxNQUFNLENBQUM7RUFDOUQsTUFBTUwsSUFBSSxDQUFDNkIsSUFBSSxDQUFDLDBCQUEwQixDQUFDO0VBQzNDbkMsTUFBTSxDQUFDLElBQUl1RSxHQUFHLENBQUNqRSxJQUFJLENBQUMwQixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUN3QyxRQUFRLENBQUMsQ0FBQzdCLElBQUksQ0FBQyxJQUFJNEIsR0FBRyxDQUFDeEUsSUFBSSxDQUFDaUUsSUFBSSxDQUFDLENBQUMsQ0FBQ1MsT0FBTyxDQUFDQyxHQUFHLENBQUNDLE9BQVEsQ0FBQyxDQUFDSCxRQUFRLENBQUM7RUFDN0YsTUFBTWxFLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzdDLE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsZUFBZSxDQUFDO0VBQ3hFLE1BQU1YLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDb0UsV0FBVyxDQUFDLENBQUMsQ0FBQztFQUMzRDVFLE1BQU0sQ0FBQzRCLE1BQU0sQ0FBQyxDQUFDUyxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQzVCLENBQUMsQ0FBQztBQUVGdEMsSUFBSSxDQUFDLHNHQUFzRyxFQUFFLE9BQU87RUFDbEhPO0FBQ0YsQ0FBQyxLQUFLO0VBQ0osTUFBTUEsSUFBSSxDQUFDdUUsZUFBZSxDQUFDO0lBQUVDLEtBQUssRUFBRSxHQUFHO0lBQUVDLE1BQU0sRUFBRTtFQUFJLENBQUMsQ0FBQztFQUN2RCxNQUFNQyxPQUFpQixHQUFHLEVBQUU7RUFDNUIxRSxJQUFJLENBQUN1QixFQUFFLENBQUMsUUFBUSxFQUFHb0QsTUFBTSxJQUFLRCxPQUFPLENBQUNqRCxJQUFJLENBQUNrRCxNQUFNLENBQUNqRCxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDekQsTUFBTTFCLElBQUksQ0FBQzZCLElBQUksQ0FBQyxNQUFNLENBQUM7RUFDdkIsTUFBTTFCLFdBQVcsQ0FBQ0gsSUFBSSxDQUFDO0VBQ3ZCTixNQUFNLENBQUNnRixPQUFPLENBQUMsQ0FBQzNDLE9BQU8sQ0FBQyxFQUFFLENBQUM7RUFDM0IsTUFBTS9CLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMxQyxNQUFNVixNQUFNLENBQUNLLElBQUksQ0FBQ0MsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUNzRCxlQUFlLENBQUMsZUFBZSxFQUFFLE9BQU8sQ0FBQztFQUN0RSxNQUFNdkQsSUFBSSxDQUFDQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM0RSxLQUFLLENBQUMsQ0FBQztFQUM1QixNQUFNNUUsSUFBSSxDQUFDNkUsUUFBUSxDQUFDQyxLQUFLLENBQUMsWUFBWSxDQUFDO0VBQ3ZDLE1BQU1wRixNQUFNLENBQUNLLElBQUksQ0FBQ0MsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMrRSxXQUFXLENBQUMsQ0FBQztFQUMxQyxNQUFNL0UsSUFBSSxDQUFDNkUsUUFBUSxDQUFDQyxLQUFLLENBQUMsV0FBVyxDQUFDO0VBQ3RDLE1BQU05RSxJQUFJLENBQUM2RSxRQUFRLENBQUNDLEtBQUssQ0FBQyxPQUFPLENBQUM7RUFDbEMsTUFBTXBGLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsZUFBZSxDQUFDO0VBQ3hFWCxNQUFNLENBQUMsTUFBTU0sSUFBSSxDQUFDVyxRQUFRLENBQUMsTUFBTXFFLFFBQVEsQ0FBQ0MsZUFBZSxDQUFDQyxXQUFXLElBQUlDLFVBQVUsQ0FBQyxDQUFDLENBQUM5QyxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2hHLE1BQU1yQyxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQ29DLFlBQVksQ0FBQyxJQUFJLENBQUM7RUFDdEQsTUFBTXRDLElBQUksQ0FBQ0UsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUNvQyxZQUFZLENBQUMsR0FBRyxDQUFDO0VBQzNELE1BQU10QyxJQUFJLENBQUNFLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDMUMsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FDdkQsOEJBQ0YsQ0FBQztFQUNELE1BQU1YLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsZUFBZSxDQUFDO0VBQ3hFLE1BQU1YLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLE1BQU0sQ0FBQztFQUM5RFgsTUFBTSxDQUFDZ0YsT0FBTyxDQUFDLENBQUNVLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFDL0IsTUFBTTFGLE1BQU0sQ0FBQ0ssSUFBSSxDQUFDQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQ3NELGVBQWUsQ0FBQyxZQUFZLEVBQUUsR0FBRyxDQUFDO0VBQy9ELE1BQU1oRCxZQUFZLENBQUNOLElBQUksQ0FBQztFQUN4QixNQUFNRyxXQUFXLENBQUNILElBQUksQ0FBQztFQUN2QixNQUFNQSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUM3QyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQzRELGFBQWEsQ0FBQyxlQUFlLENBQUM7RUFDN0UsTUFBTXBFLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLE1BQU0sQ0FBQztFQUM5RFgsTUFBTSxDQUFDZ0YsT0FBTyxDQUFDLENBQUNVLFlBQVksQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDO0FBRUYzRixJQUFJLENBQUMsK0hBQStILEVBQUUsT0FBTztFQUMzSU87QUFDRixDQUFDLEtBQUs7RUFDSixNQUFNQSxJQUFJLENBQUNxRixhQUFhLENBQUMsTUFBTTtJQUM3QixNQUFNQyxNQUFNLEdBQUdwRCxNQUFNLENBQUNxRCxNQUFNO0lBQzVCLE1BQU1DLE9BQU8sR0FBRztNQUFFQyxNQUFNLEVBQUUsQ0FBQztNQUFFQyxLQUFLLEVBQUUsQ0FBQztNQUFFQyxJQUFJLEVBQUVBLENBQUEsS0FBTSxDQUFDO0lBQUUsQ0FBQztJQUN0RHpELE1BQU0sQ0FBUzBELGFBQWEsR0FBR0osT0FBTztJQUN2Q3RELE1BQU0sQ0FBQ3FELE1BQU0sR0FBRyxjQUFjRCxNQUFNLENBQUM7TUFDMUJPLFdBQVdBLENBQUNqRSxPQUFZLEVBQVE7UUFDdkM0RCxPQUFPLENBQUNDLE1BQU0sRUFBRTtRQUNoQixNQUFNSyxRQUFRLEdBQUksSUFBSSxDQUFTQyxhQUFhO1FBQzVDUCxPQUFPLENBQUNHLElBQUksR0FBRyxNQUNiRyxRQUFRLENBQ04sSUFBSUUsWUFBWSxDQUFDLFNBQVMsRUFBRTtVQUMxQkMsSUFBSSxFQUFFO1lBQUVDLEVBQUUsRUFBRXRFLE9BQU8sQ0FBQ3NFLEVBQUU7WUFBRUMsVUFBVSxFQUFFdkUsT0FBTyxDQUFDdUUsVUFBVTtZQUFFQyxFQUFFLEVBQUUsSUFBSTtZQUFFQyxJQUFJLEVBQUU7VUFBRztRQUM3RSxDQUFDLENBQ0gsQ0FBQztRQUNIO01BQ0Y7TUFDU0MsZ0JBQWdCQSxDQUFDQyxJQUFTLEVBQUVULFFBQWEsRUFBRVUsT0FBYSxFQUFRO1FBQ3ZFLElBQUlELElBQUksS0FBSyxTQUFTLEVBQUcsSUFBSSxDQUFTUixhQUFhLEdBQUdELFFBQVE7UUFDOUQsS0FBSyxDQUFDUSxnQkFBZ0IsQ0FBQ0MsSUFBSSxFQUFFVCxRQUFRLEVBQUVVLE9BQU8sQ0FBQztNQUNqRDtNQUNTQyxTQUFTQSxDQUFBLEVBQVM7UUFDekJqQixPQUFPLENBQUNFLEtBQUssRUFBRTtRQUNmLEtBQUssQ0FBQ2UsU0FBUyxDQUFDLENBQUM7TUFDbkI7SUFDRixDQUFDO0lBQ0R4RixZQUFZLENBQUN5RixPQUFPLENBQUMscUJBQXFCLEVBQUUsaUJBQWlCLENBQUM7SUFDOUR6RixZQUFZLENBQUN5RixPQUFPLENBQUMseUJBQXlCLEVBQUUsbUJBQW1CLENBQUM7SUFDcEV6RixZQUFZLENBQUN5RixPQUFPLENBQUMsNEJBQTRCLEVBQUUsZ0JBQWdCLENBQUM7RUFDdEUsQ0FBQyxDQUFDO0VBQ0YsTUFBTTFHLElBQUksQ0FBQzZCLElBQUksQ0FBQyxhQUFhLENBQUM7RUFDOUIsTUFBTXVCLE1BQU0sR0FBRyxNQUFNMUMsV0FBVyxDQUFDVixJQUFJLENBQUM7RUFDdEMsTUFBTUEsSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUNvQyxZQUFZLENBQUMsSUFBSSxDQUFDO0VBQ3RELE1BQU10QyxJQUFJLENBQUNFLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDb0MsWUFBWSxDQUFDLEdBQUcsQ0FBQztFQUMzRCxNQUFNdEMsSUFBSSxDQUFDRSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzFDLE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQzRELGFBQWEsQ0FBQyxRQUFRLENBQUM7RUFDbkUsTUFBTTZDLFNBQVMsR0FBRyxNQUFNeEYsWUFBWSxDQUFDbkIsSUFBSSxDQUFDO0VBQzFDLE1BQU1NLFlBQVksQ0FBQ04sSUFBSSxDQUFDO0VBQ3hCLE1BQU1BLElBQUksQ0FBQ1csUUFBUSxDQUFDLE1BQU91QixNQUFNLENBQVMwRCxhQUFhLENBQUNELElBQUksQ0FBQyxDQUFDLENBQUM7RUFDL0QsTUFBTWpHLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxDQUFDb0UsV0FBVyxDQUFDLENBQUMsQ0FBQztFQUM3RTVFLE1BQU0sQ0FBQyxNQUFNeUIsWUFBWSxDQUFDbkIsSUFBSSxDQUFDLENBQUMsQ0FBQ3FDLElBQUksQ0FBQ3NFLFNBQVMsQ0FBQztFQUNoRGpILE1BQU0sQ0FBQyxNQUFNZ0IsV0FBVyxDQUFDVixJQUFJLENBQUMsQ0FBQyxDQUFDK0IsT0FBTyxDQUFDcUIsTUFBTSxDQUFDO0VBQy9DMUQsTUFBTSxDQUNKLE1BQU1NLElBQUksQ0FBQ1csUUFBUSxDQUFDLE9BQU87SUFDekI4RSxNQUFNLEVBQUd2RCxNQUFNLENBQVMwRCxhQUFhLENBQUNILE1BQU07SUFDNUNDLEtBQUssRUFBR3hELE1BQU0sQ0FBUzBELGFBQWEsQ0FBQ0Y7RUFDdkMsQ0FBQyxDQUFDLENBQ0osQ0FBQyxDQUFDM0QsT0FBTyxDQUFDO0lBQUUwRCxNQUFNLEVBQUUsQ0FBQztJQUFFQyxLQUFLLEVBQUU7RUFBRSxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDO0FBRUZqRyxJQUFJLENBQUMseUZBQXlGLEVBQUUsT0FBTztFQUNyR087QUFDRixDQUFDLEtBQUs7RUFDSixJQUFJNEcsT0FBb0IsRUFBRUMsU0FBc0I7RUFDaEQsTUFBTUMsSUFBSSxHQUFHLElBQUlDLE9BQU8sQ0FBUUMsT0FBTyxJQUFLO0lBQzFDSixPQUFPLEdBQUdJLE9BQU87RUFDbkIsQ0FBQyxDQUFDO0VBQ0YsTUFBTUMsT0FBTyxHQUFHLElBQUlGLE9BQU8sQ0FBUUMsT0FBTyxJQUFLO0lBQzdDSCxTQUFTLEdBQUdHLE9BQU87RUFDckIsQ0FBQyxDQUFDO0VBQ0YsTUFBTWhILElBQUksQ0FBQ2tILEtBQUssQ0FBQyxzQkFBc0IsRUFBRSxNQUFPQSxLQUFLLElBQUs7SUFDeERMLFNBQVMsQ0FBQyxDQUFDO0lBQ1gsTUFBTUMsSUFBSTtJQUNWLE1BQU1JLEtBQUssQ0FBQ0MsUUFBUSxDQUFDLENBQUM7RUFDeEIsQ0FBQyxDQUFDO0VBQ0YsTUFBTW5ILElBQUksQ0FBQzZCLElBQUksQ0FBQyxhQUFhLENBQUM7RUFDOUIsTUFBTTdCLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMxQyxNQUFNNkcsT0FBTztFQUNiLE1BQU0zRyxZQUFZLENBQUNOLElBQUksQ0FBQztFQUN4QjRHLE9BQU8sQ0FBQyxDQUFDO0VBQ1QsTUFBTTVHLElBQUksQ0FBQ29ILGdCQUFnQixDQUFDLGFBQWEsQ0FBQztFQUMxQyxNQUFNMUgsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUNvRSxXQUFXLENBQUMsQ0FBQyxDQUFDO0VBQ3JFNUUsTUFBTSxDQUFDLE1BQU15QixZQUFZLENBQUNuQixJQUFJLENBQUMsQ0FBQyxDQUFDcUgsUUFBUSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDO0FBRUY1SCxJQUFJLENBQUMsMkdBQTJHLEVBQUUsT0FBTztFQUN2SE87QUFDRixDQUFDLEtBQUs7RUFDSixNQUFNQSxJQUFJLENBQUM2QixJQUFJLENBQUMsYUFBYSxDQUFDO0VBQzlCLE1BQU03QixJQUFJLENBQUNXLFFBQVEsQ0FBRUssR0FBRyxJQUFLQyxZQUFZLENBQUN5RixPQUFPLENBQUMxRixHQUFHLEVBQUUsU0FBUyxDQUFDLEVBQUVyQixZQUFZLENBQUM7RUFDaEYsTUFBTUssSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNvSCxHQUFHLENBQUNDLFNBQVMsQ0FBQyxDQUFDO0VBQzVEN0gsTUFBTSxDQUFDLE1BQU15QixZQUFZLENBQUNuQixJQUFJLENBQUMsQ0FBQyxDQUFDcUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUNoRCxNQUFNckMsSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0NWLE1BQU0sQ0FBQyxNQUFNeUIsWUFBWSxDQUFDbkIsSUFBSSxDQUFDLENBQUMsQ0FBQ3FDLElBQUksQ0FBQyxTQUFTLENBQUM7RUFDaEQ7RUFDQSxNQUFNckMsSUFBSSxDQUFDRSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzFDLE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsZUFBZSxDQUFDO0VBQ3hFLE1BQU1MLElBQUksQ0FBQ1csUUFBUSxDQUFDLE1BQU07SUFDeEI2RyxPQUFPLENBQUNDLFNBQVMsQ0FBQ2YsT0FBTyxHQUFHLE1BQU07TUFDaEMsTUFBTSxJQUFJZ0IsWUFBWSxDQUFDLE9BQU8sRUFBRSxvQkFBb0IsQ0FBQztJQUN2RCxDQUFDO0VBQ0gsQ0FBQyxDQUFDO0VBQ0YsTUFBTTNILElBQUksQ0FBQ0MsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDSSxLQUFLLENBQUMsQ0FBQztFQUM1QixNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQzRELGFBQWEsQ0FBQyxTQUFTLENBQUM7RUFDM0UsTUFBTXhELFlBQVksQ0FBQ04sSUFBSSxDQUFDO0VBQ3hCLE1BQU1OLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDNEQsYUFBYSxDQUFDLGlCQUFpQixDQUFDO0FBQ25GLENBQUMsQ0FBQztBQUVGckUsSUFBSSxDQUFDLDRGQUE0RixFQUFFLE9BQU87RUFDeEdPO0FBQ0YsQ0FBQyxLQUFLO0VBQ0osTUFBTUEsSUFBSSxDQUFDNkIsSUFBSSxDQUFDLGFBQWEsQ0FBQztFQUM5QixlQUFlOEYsTUFBTUEsQ0FBQ0MsS0FBZSxFQUFFQyxNQUFjLEVBQUU7SUFDckQsTUFBTTdILElBQUksQ0FBQ1csUUFBUSxDQUNqQixDQUFDO01BQUVLLEdBQUc7TUFBRTRHLEtBQUs7TUFBRUM7SUFBTyxDQUFDLEtBQ3JCNUcsWUFBWSxDQUFDeUYsT0FBTyxDQUNsQjFGLEdBQUcsRUFDSDhHLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ2JDLE9BQU8sRUFBRSxDQUFDO01BQ1ZwSCxJQUFJLEVBQUUsU0FBUztNQUNmcUgsSUFBSSxFQUFFLE9BQU87TUFDYkMsU0FBUyxFQUFFLENBQUM7TUFDWnpGLEtBQUssRUFBRTtRQUFFdUYsT0FBTyxFQUFFLENBQUM7UUFBRUosS0FBSztRQUFFQztNQUFPO0lBQ3JDLENBQUMsQ0FDSCxDQUFDLEVBQ0g7TUFBRTdHLEdBQUcsRUFBRXJCLFlBQVk7TUFBRWlJLEtBQUs7TUFBRUM7SUFBTyxDQUNyQyxDQUFDO0lBQ0QsTUFBTTdILElBQUksQ0FBQ0UsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQy9DO0VBQ0EsTUFBTStILE1BQU0sR0FBR0MsS0FBSyxDQUFTLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ3hDRixNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztFQUNiQSxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztFQUNiLE1BQU1SLE1BQU0sQ0FBQ1EsTUFBTSxFQUFFLENBQUMsQ0FBQztFQUN2QixNQUFNekksTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM0RCxhQUFhLENBQUMsT0FBTyxDQUFDO0VBQ25FLE1BQU05RCxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDM0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsTUFBTSxDQUFDO0VBQzlELE1BQU1OLElBQUksQ0FBQ0MsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDSSxLQUFLLENBQUMsQ0FBQztFQUMzQixNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxTQUFTLENBQUM7RUFDakUsTUFBTVgsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxlQUFlLENBQUM7RUFDeEUsTUFBTXNILE1BQU0sQ0FBQ1MsS0FBSyxDQUFTLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQzFDLE1BQU0zSSxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxTQUFTLENBQUM7RUFDakUsTUFBTXNILE1BQU0sQ0FDVlMsS0FBSyxDQUFDRSxJQUFJLENBQUM7SUFBRUMsTUFBTSxFQUFFO0VBQUcsQ0FBQyxFQUFFLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxLQUFNQSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsR0FBRyxDQUFFLENBQUMsRUFDdEQsQ0FDRixDQUFDO0VBQ0QsTUFBTS9JLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLFFBQVEsQ0FBQztFQUNoRSxNQUFNWCxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUN3SSxVQUFVLENBQUMsQ0FBQztFQUN4RGhKLE1BQU0sQ0FBQyxNQUFNTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDeUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDdEcsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNwRixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=