"""Collect this task's bounded frontend evidence without loading game runtimes."""

import hashlib
import json
from pathlib import Path
import re
import stat

ROOT = Path("/workspaces/quoridor/.worktree/othello-web129")
OUT = ROOT / ".artifacts/othello-web129"


def ref(path):
    content = path.read_bytes()
    return dict(
        path=str(path.relative_to(ROOT)),
        sha256=hashlib.sha256(content).hexdigest(),
        bytes=len(content),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def results(path):
    value = json.loads(path.read_text())
    facts = []

    def visit(suite):
        for spec in suite.get("specs", []):
            for test in spec["tests"]:
                facts.append(
                    dict(
                        title=spec["title"],
                        expected=spec["ok"],
                        results=[r["status"] for r in test["results"]],
                    )
                )
        for child in suite.get("suites", []):
            visit(child)

    for suite in value["suites"]:
        visit(suite)
    return facts


sources = [
    ROOT / p
    for p in (
        "apps/web/src/app/main.ts",
        "apps/web/src/app/navigation.ts",
        "apps/web/src/pages/home/index.ts",
        "tests/e2e/web-shell.spec.ts",
        "tests/e2e/multi-game-shell.spec.ts",
        "tests/unit/web-navigation.test.mjs",
        "tests/unit/othello-lifecycle.test.mjs",
    )
]
sources += sorted((ROOT / "apps/web/src/games/othello").glob("*"))
inputs = sorted((ROOT / "games/othello/bridge/wasm").glob("*"))
legacy = sorted((ROOT / "games/quoridor/bridge/wasm").glob("*/*"))
assert len(legacy) == 8
assert len(inputs) == 4
assert all(not p.is_symlink() and p.is_file() for p in inputs + legacy)
html = (OUT / "bundle-final/index.html").read_text()
entry_name = re.search(r'<script[^>]+src="([^"]+)"', html)[1].split("/")[-1]
entry = (OUT / "bundle-final/assets" / entry_name).read_text()
assert not re.search(r"\bimport\s*(?:[\w{*]|[\'\"])", entry), (
    "unexpected eager static import in home entry"
)
assert "new Worker" not in entry
assert "WebAssembly.instantiate" not in entry
first = results(OUT / "browser-results.json")
repair = results(OUT / "browser-results-repair.json")
html_regression = results(OUT / "browser-results-html.json")
assert len(html_regression) == 1 and html_regression[0]["expected"]
assert len(first) == 6 and len(repair) == 1
assert sum(r["expected"] for r in first) == 5
assert repair[0]["expected"]
processes = []
for name in ("browser-first", "browser-repair", "browser-html"):
    path = OUT / name / "command.process.json"
    process = json.loads(path.read_text())
    assert (
        process["remaining"] == []
        and process["direct_child_reaped"]
        and process["process_cleanup_complete"]
        and process["handle_closes_complete"]
    )
    processes.append(dict(name=name, **process))
record = dict(
    source_root=str(ROOT),
    base_source="872068c52349acc1a7fa340912ad2a552867f39b",
    source_refs=[ref(p) for p in sources],
    othello_input_refs=[ref(p) for p in inputs],
    legacy_input_refs=[ref(p) for p in legacy],
    bundle_refs=[ref(p) for p in sorted((OUT / "bundle-final/assets").glob("*")) if p.is_file()],
    home_entry=entry_name,
    home_static_imports=0,
    home_worker_or_wasm_init=0,
    first_browser_attempt=first,
    causal_timeout_repair=repair,
    final_source_html_regression=html_regression,
    prior_render_source_manifest=ref(OUT / "evidence-before-corrupt-fix.json"),
    exact_render_scope="First6cases on prior source; post-review save-preservation delta on final source via new HTML regression; no full-suite replay",
    browser_processes=processes,
    rust_rules_acceptance="Root accepted; not replayed",
    scientific_runs=0,
    models_or_downloads=0,
)
(OUT / "evidence.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            source_files=len(sources),
            othello_inputs=len(inputs),
            quoridor_inputs=len(legacy),
            original_browser_pass=5,
            original_browser_failure=1,
            repaired_cross_game=repair[0]["results"],
            home_entry=entry_name,
        ),
        ensure_ascii=False,
    )
)
