// 1b6136541a7b13429aea73d460d49510a9a3052e
import { test, expect } from '@playwright/test';
const OTHELLO_SAVE = 'othello.game.v1';
const LEGACY_GAME = 'quoridor.m1.game.v1';
const LEGACY_SETTINGS = 'quoridor.m1.settings.v1';
const LEGACY_AUDIO = 'quoridor.audio.settings.v1';
const cell = (page, index) => page.locator(`.othello-cell[data-index="${index}"]`);
const openOthello = async page => {
  await page.locator('#choose-othello').click();
  await expect(page.locator('.othello h1')).toHaveText('Othello');
};
const leaveOthello = async page => {
  await page.getByRole('link', {
    name: 'ゲーム一覧へ戻る'
  }).click();
  await expect(page.locator('.home-page')).toBeVisible();
};
async function legacySlots(page) {
  return page.evaluate(([game, settings, audio]) => [game, settings, audio].map(key => localStorage.getItem(key)), [LEGACY_GAME, LEGACY_SETTINGS, LEGACY_AUDIO]);
}
async function savedOthello(page) {
  return page.evaluate(key => localStorage.getItem(key), OTHELLO_SAVE);
}
test('new cross-game flow plays and saves both games, resumes legacy and Othello slots, preserves history and basepath', async ({
  page
}) => {
  // Two real Quoridor mounts and teardown compile/render PBR on the assigned single CPU.
  // This test budget is independent of the unchanged process resource/deadline guard.
  test.setTimeout(120000);
  const requests = [],
    errors = [];
  page.on('request', request => requests.push(request.url()));
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('./?forceWebGL=1#/');
  await expect(page.locator('#choose-othello')).toBeVisible();
  expect(requests.filter(url => /\.wasm|ai\.worker|quoridor-|othello-|\.hdr|\.mp3|\.ogg/.test(url))).toEqual([]);
  await page.locator('#choose-quoridor').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_DI;
    return (_window$__QUORIDOR_DI = window.__QUORIDOR_DIAGNOSTICS__) === null || _window$__QUORIDOR_DI === void 0 ? void 0 : _window$__QUORIDOR_DI.phase;
  })).toBe('ready');
  await page.locator('#startup-new-game').click();
  await page.locator('#match-mode').selectOption('pvp');
  await page.locator('#dialog-start').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_AP;
    return (_window$__QUORIDOR_AP = window.__QUORIDOR_APP_TEST_API__) === null || _window$__QUORIDOR_AP === void 0 ? void 0 : _window$__QUORIDOR_AP.state().phase;
  })).toBe('humanTurn');
  const point = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__.projectCell(13));
  await page.mouse.click(point.x, point.y);
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_AP2;
    return (_window$__QUORIDOR_AP2 = window.__QUORIDOR_APP_TEST_API__) === null || _window$__QUORIDOR_AP2 === void 0 || (_window$__QUORIDOR_AP2 = _window$__QUORIDOR_AP2.state().view) === null || _window$__QUORIDOR_AP2 === void 0 ? void 0 : _window$__QUORIDOR_AP2.ply;
  })).toBe(1);
  const replay = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__.exportReplay());
  await page.locator('.top-actions .home-link').click();
  await expect(page.locator('.home-page')).toBeVisible();
  const legacy = await legacySlots(page);
  expect(legacy[0]).toBeTruthy();
  await openOthello(page);
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 2 石 ／ 白 2 石');
  await cell(page, 19).click();
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(cell(page, 27)).toHaveAttribute('data-stone', '1');
  const othello = await savedOthello(page);
  await page.screenshot({
    path: test.info().outputPath('othello-play.png')
  });
  await leaveOthello(page);
  expect(await legacySlots(page)).toEqual(legacy);
  await page.locator('#choose-quoridor').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_DI2;
    return (_window$__QUORIDOR_DI2 = window.__QUORIDOR_DIAGNOSTICS__) === null || _window$__QUORIDOR_DI2 === void 0 ? void 0 : _window$__QUORIDOR_DI2.phase;
  })).toBe('ready');
  await page.locator('#resume-game-choice').click();
  await expect.poll(() => page.evaluate(() => {
    var _window$__QUORIDOR_AP3;
    return (_window$__QUORIDOR_AP3 = window.__QUORIDOR_APP_TEST_API__) === null || _window$__QUORIDOR_AP3 === void 0 ? void 0 : _window$__QUORIDOR_AP3.state().phase;
  })).toBe('humanTurn');
  expect(await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__.exportReplay())).toEqual(replay);
  expect(await savedOthello(page)).toBe(othello);
  await page.locator('.top-actions .home-link').click();
  await openOthello(page);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(page.locator('#othello-players')).toContainText('ローカル2人');
  await page.goBack();
  await expect(page.locator('.home-page')).toBeVisible();
  await page.goForward();
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-turn')).toHaveText('白の手番');
  await page.goto('./?forceWebGL=1#/othello');
  expect(new URL(page.url()).pathname).toBe(new URL(test.info().project.use.baseURL).pathname);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(page.locator('canvas, dialog')).toHaveCount(0);
  expect(errors).toEqual([]);
});
test('Othello-only entry remains lazy on home, keyboard play and real bounded AI use explicit human colors', async ({
  page
}) => {
  await page.setViewportSize({
    width: 375,
    height: 812
  });
  const workers = [];
  page.on('worker', worker => workers.push(worker.url()));
  await page.goto('./#/');
  await openOthello(page);
  expect(workers).toEqual([]);
  await page.locator('#othello-new').click();
  await expect(cell(page, 19)).toHaveAttribute('aria-disabled', 'false');
  await cell(page, 19).focus();
  await page.keyboard.press('ArrowRight');
  await expect(cell(page, 20)).toBeFocused();
  await page.keyboard.press('ArrowLeft');
  await page.keyboard.press('Enter');
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.locator('#othello-mode').selectOption('ai');
  await page.locator('#othello-human-side').selectOption('2');
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-players')).toHaveText('簡易AI（非学習）と対戦 · 人間：白 ／ 簡易AI：黒');
  await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  await expect(page.locator('#othello-turn')).toHaveText('白の手番');
  expect(workers).toHaveLength(1);
  await expect(cell(page, 19)).toHaveAttribute('data-stone', '1');
  await leaveOthello(page);
  await openOthello(page);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-players')).toContainText('人間：白 ／ 簡易AI：黒');
  await expect(page.locator('#othello-turn')).toHaveText('白の手番');
  expect(workers).toHaveLength(1);
});
test('Othello Worker pending cancellation terminates once and rejects a deliberately late message without mutation or legacy writes', async ({
  page
}) => {
  await page.addInitScript(() => {
    const Native = window.Worker;
    const monitor = {
      starts: 0,
      stops: 0,
      late: () => {}
    };
    window.othelloWorker = monitor;
    window.Worker = class extends Native {
      postMessage(message) {
        monitor.starts++;
        const callback = this.savedCallback;
        monitor.late = () => callback(new MessageEvent('message', {
          data: {
            id: message.id,
            generation: message.generation,
            ok: true,
            move: 19
          }
        }));
        // Keep the real game-owned Worker pending; deliver the captured callback after teardown.
      }
      addEventListener(type, callback, options) {
        if (type === 'message') this.savedCallback = callback;
        super.addEventListener(type, callback, options);
      }
      terminate() {
        monitor.stops++;
        super.terminate();
      }
    };
    localStorage.setItem('quoridor.m1.game.v1', 'legacy sentinel');
    localStorage.setItem('quoridor.m1.settings.v1', 'settings sentinel');
    localStorage.setItem('quoridor.audio.settings.v1', 'audio sentinel');
  });
  await page.goto('./#/othello');
  const legacy = await legacySlots(page);
  await page.locator('#othello-mode').selectOption('ai');
  await page.locator('#othello-human-side').selectOption('2');
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-turn')).toContainText('考えています');
  const confirmed = await savedOthello(page);
  await leaveOthello(page);
  await page.evaluate(() => window.othelloWorker.late());
  await expect(page.locator('.othello, .othello-board, canvas')).toHaveCount(0);
  expect(await savedOthello(page)).toBe(confirmed);
  expect(await legacySlots(page)).toEqual(legacy);
  expect(await page.evaluate(() => ({
    starts: window.othelloWorker.starts,
    stops: window.othelloWorker.stops
  }))).toEqual({
    starts: 1,
    stops: 1
  });
});
test('leaving Othello during actual Wasm initialization cannot save or render the late result', async ({
  page
}) => {
  let release, requested;
  const gate = new Promise(resolve => {
    release = resolve;
  });
  const reached = new Promise(resolve => {
    requested = resolve;
  });
  await page.route('**/*othello_bg*.wasm', async route => {
    requested();
    await gate;
    await route.continue();
  });
  await page.goto('./#/othello');
  await page.locator('#othello-new').click();
  await reached;
  await leaveOthello(page);
  release();
  await page.waitForLoadState('networkidle');
  await expect(page.locator('.othello, .othello-board')).toHaveCount(0);
  expect(await savedOthello(page)).toBeNull();
});
test('bad saves are retained, retry and explicit new are available, unavailable storage is visible through exit', async ({
  page
}) => {
  await page.goto('./#/othello');
  await page.evaluate(key => localStorage.setItem(key, '{broken'), OTHELLO_SAVE);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-error')).not.toBeEmpty();
  expect(await savedOthello(page)).toBe('{broken');
  await page.locator('#othello-resume').click();
  expect(await savedOthello(page)).toBe('{broken');
  // The user's explicit new selection authorizes replacing the broken Othello slot.
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 2 石 ／ 白 2 石');
  await page.evaluate(() => {
    Storage.prototype.setItem = () => {
      throw new DOMException('quota', 'QuotaExceededError');
    };
  });
  await cell(page, 19).click();
  await expect(page.locator('#othello-save-status')).toContainText('保存できません');
  await leaveOthello(page);
  await expect(page.locator('#home-save-warning')).toContainText('Othelloを保存できません');
});
test('saved forced-pass and terminal fixtures render Rust status, wins and draw without JS rules', async ({
  page
}) => {
  await page.goto('./#/othello');
  async function resume(board, toMove) {
    await page.evaluate(({
      key,
      board,
      toMove
    }) => localStorage.setItem(key, JSON.stringify({
      version: 1,
      game: 'othello',
      mode: 'local',
      humanSide: 1,
      state: {
        version: 1,
        board,
        toMove
      }
    })), {
      key: OTHELLO_SAVE,
      board,
      toMove
    });
    await page.locator('#othello-resume').click();
  }
  const forced = Array(64).fill(0);
  forced[0] = 1;
  forced[1] = 2;
  await resume(forced, 2);
  await expect(page.locator('#othello-guide')).toContainText('パスが必要');
  await page.locator('#othello-pass').click();
  await expect(page.locator('#othello-turn')).toHaveText('黒の手番');
  await cell(page, 2).click();
  await expect(page.locator('#othello-turn')).toHaveText('終局：黒の勝ち');
  await expect(page.locator('#othello-score')).toHaveText('黒 3 石 ／ 白 0 石');
  await resume(Array(64).fill(2), 1);
  await expect(page.locator('#othello-turn')).toHaveText('終局：白の勝ち');
  await resume(Array.from({
    length: 64
  }, (_, i) => i < 32 ? 1 : 2), 2);
  await expect(page.locator('#othello-turn')).toHaveText('終局：引分け');
  await expect(page.locator('#othello-pass')).toBeHidden();
  expect(await page.locator('.othello-cell[aria-disabled="false"]').count()).toBe(0);
});
test('active Othello failed resume preserves corrupt slot on exit until explicit new choice', async ({
  page
}) => {
  await page.goto('./#/othello');
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 2 石 ／ 白 2 石');
  await page.evaluate(key => localStorage.setItem(key, '{active corrupt save'), OTHELLO_SAVE);
  await page.locator('#othello-resume').click();
  await expect(page.locator('#othello-error')).not.toBeEmpty();
  await page.locator('#othello-save').click();
  await expect(page.locator('#othello-save-status')).toContainText('元の保存を保持');
  expect(await savedOthello(page)).toBe('{active corrupt save');
  await leaveOthello(page);
  await expect(page.locator('#home-save-warning')).toContainText('元の保存を保持');
  expect(await savedOthello(page)).toBe('{active corrupt save');
  await openOthello(page);
  await page.locator('#othello-new').click();
  await expect(page.locator('#othello-score')).toHaveText('黒 2 石 ／ 白 2 石');
  expect(JSON.parse(await savedOthello(page)).version).toBe(1);
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJ0ZXN0IiwiZXhwZWN0IiwiT1RIRUxMT19TQVZFIiwiTEVHQUNZX0dBTUUiLCJMRUdBQ1lfU0VUVElOR1MiLCJMRUdBQ1lfQVVESU8iLCJjZWxsIiwicGFnZSIsImluZGV4IiwibG9jYXRvciIsIm9wZW5PdGhlbGxvIiwiY2xpY2siLCJ0b0hhdmVUZXh0IiwibGVhdmVPdGhlbGxvIiwiZ2V0QnlSb2xlIiwibmFtZSIsInRvQmVWaXNpYmxlIiwibGVnYWN5U2xvdHMiLCJldmFsdWF0ZSIsImdhbWUiLCJzZXR0aW5ncyIsImF1ZGlvIiwibWFwIiwia2V5IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInNhdmVkT3RoZWxsbyIsInNldFRpbWVvdXQiLCJyZXF1ZXN0cyIsImVycm9ycyIsIm9uIiwicmVxdWVzdCIsInB1c2giLCJ1cmwiLCJlcnJvciIsIm1lc3NhZ2UiLCJnb3RvIiwiZmlsdGVyIiwidG9FcXVhbCIsInBvbGwiLCJfd2luZG93JF9fUVVPUklET1JfREkiLCJ3aW5kb3ciLCJfX1FVT1JJRE9SX0RJQUdOT1NUSUNTX18iLCJwaGFzZSIsInRvQmUiLCJzZWxlY3RPcHRpb24iLCJfd2luZG93JF9fUVVPUklET1JfQVAiLCJfX1FVT1JJRE9SX0FQUF9URVNUX0FQSV9fIiwic3RhdGUiLCJwb2ludCIsInByb2plY3RDZWxsIiwibW91c2UiLCJ4IiwieSIsIl93aW5kb3ckX19RVU9SSURPUl9BUDIiLCJ2aWV3IiwicGx5IiwicmVwbGF5IiwiZXhwb3J0UmVwbGF5IiwibGVnYWN5IiwidG9CZVRydXRoeSIsInRvSGF2ZUF0dHJpYnV0ZSIsIm90aGVsbG8iLCJzY3JlZW5zaG90IiwicGF0aCIsImluZm8iLCJvdXRwdXRQYXRoIiwiX3dpbmRvdyRfX1FVT1JJRE9SX0RJMiIsIl93aW5kb3ckX19RVU9SSURPUl9BUDMiLCJ0b0NvbnRhaW5UZXh0IiwiZ29CYWNrIiwiZ29Gb3J3YXJkIiwiVVJMIiwicGF0aG5hbWUiLCJwcm9qZWN0IiwidXNlIiwiYmFzZVVSTCIsInRvSGF2ZUNvdW50Iiwic2V0Vmlld3BvcnRTaXplIiwid2lkdGgiLCJoZWlnaHQiLCJ3b3JrZXJzIiwid29ya2VyIiwiZm9jdXMiLCJrZXlib2FyZCIsInByZXNzIiwidG9CZUZvY3VzZWQiLCJkb2N1bWVudCIsImRvY3VtZW50RWxlbWVudCIsInNjcm9sbFdpZHRoIiwiaW5uZXJXaWR0aCIsInRvSGF2ZUxlbmd0aCIsImFkZEluaXRTY3JpcHQiLCJOYXRpdmUiLCJXb3JrZXIiLCJtb25pdG9yIiwic3RhcnRzIiwic3RvcHMiLCJsYXRlIiwib3RoZWxsb1dvcmtlciIsInBvc3RNZXNzYWdlIiwiY2FsbGJhY2siLCJzYXZlZENhbGxiYWNrIiwiTWVzc2FnZUV2ZW50IiwiZGF0YSIsImlkIiwiZ2VuZXJhdGlvbiIsIm9rIiwibW92ZSIsImFkZEV2ZW50TGlzdGVuZXIiLCJ0eXBlIiwib3B0aW9ucyIsInRlcm1pbmF0ZSIsInNldEl0ZW0iLCJjb25maXJtZWQiLCJyZWxlYXNlIiwicmVxdWVzdGVkIiwiZ2F0ZSIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVhY2hlZCIsInJvdXRlIiwiY29udGludWUiLCJ3YWl0Rm9yTG9hZFN0YXRlIiwidG9CZU51bGwiLCJub3QiLCJ0b0JlRW1wdHkiLCJTdG9yYWdlIiwicHJvdG90eXBlIiwiRE9NRXhjZXB0aW9uIiwicmVzdW1lIiwiYm9hcmQiLCJ0b01vdmUiLCJKU09OIiwic3RyaW5naWZ5IiwidmVyc2lvbiIsIm1vZGUiLCJodW1hblNpZGUiLCJmb3JjZWQiLCJBcnJheSIsImZpbGwiLCJmcm9tIiwibGVuZ3RoIiwiXyIsImkiLCJ0b0JlSGlkZGVuIiwiY291bnQiLCJwYXJzZSJdLCJzb3VyY2VzIjpbIm11bHRpLWdhbWUtc2hlbGwuc3BlYy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0ZXN0LCBleHBlY3QsIHR5cGUgUGFnZSB9IGZyb20gJ0BwbGF5d3JpZ2h0L3Rlc3QnO1xuXG5jb25zdCBPVEhFTExPX1NBVkUgPSAnb3RoZWxsby5nYW1lLnYxJztcbmNvbnN0IExFR0FDWV9HQU1FID0gJ3F1b3JpZG9yLm0xLmdhbWUudjEnO1xuY29uc3QgTEVHQUNZX1NFVFRJTkdTID0gJ3F1b3JpZG9yLm0xLnNldHRpbmdzLnYxJztcbmNvbnN0IExFR0FDWV9BVURJTyA9ICdxdW9yaWRvci5hdWRpby5zZXR0aW5ncy52MSc7XG5jb25zdCBjZWxsID0gKHBhZ2U6IFBhZ2UsIGluZGV4OiBudW1iZXIpID0+IHBhZ2UubG9jYXRvcihgLm90aGVsbG8tY2VsbFtkYXRhLWluZGV4PVwiJHtpbmRleH1cIl1gKTtcbmNvbnN0IG9wZW5PdGhlbGxvID0gYXN5bmMgKHBhZ2U6IFBhZ2UpID0+IHtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjY2hvb3NlLW90aGVsbG8nKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcub3RoZWxsbyBoMScpKS50b0hhdmVUZXh0KCdPdGhlbGxvJyk7XG59O1xuY29uc3QgbGVhdmVPdGhlbGxvID0gYXN5bmMgKHBhZ2U6IFBhZ2UpID0+IHtcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2xpbmsnLCB7IG5hbWU6ICfjgrLjg7zjg6DkuIDopqfjgbjmiLvjgosnIH0pLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ob21lLXBhZ2UnKSkudG9CZVZpc2libGUoKTtcbn07XG5hc3luYyBmdW5jdGlvbiBsZWdhY3lTbG90cyhwYWdlOiBQYWdlKSB7XG4gIHJldHVybiBwYWdlLmV2YWx1YXRlKFxuICAgIChbZ2FtZSwgc2V0dGluZ3MsIGF1ZGlvXSkgPT4gW2dhbWUsIHNldHRpbmdzLCBhdWRpb10ubWFwKChrZXkpID0+IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSEpKSxcbiAgICBbTEVHQUNZX0dBTUUsIExFR0FDWV9TRVRUSU5HUywgTEVHQUNZX0FVRElPXSxcbiAgKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHNhdmVkT3RoZWxsbyhwYWdlOiBQYWdlKSB7XG4gIHJldHVybiBwYWdlLmV2YWx1YXRlKChrZXkpID0+IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSksIE9USEVMTE9fU0FWRSk7XG59XG5cbnRlc3QoJ25ldyBjcm9zcy1nYW1lIGZsb3cgcGxheXMgYW5kIHNhdmVzIGJvdGggZ2FtZXMsIHJlc3VtZXMgbGVnYWN5IGFuZCBPdGhlbGxvIHNsb3RzLCBwcmVzZXJ2ZXMgaGlzdG9yeSBhbmQgYmFzZXBhdGgnLCBhc3luYyAoe1xuICBwYWdlLFxufSkgPT4ge1xuICAvLyBUd28gcmVhbCBRdW9yaWRvciBtb3VudHMgYW5kIHRlYXJkb3duIGNvbXBpbGUvcmVuZGVyIFBCUiBvbiB0aGUgYXNzaWduZWQgc2luZ2xlIENQVS5cbiAgLy8gVGhpcyB0ZXN0IGJ1ZGdldCBpcyBpbmRlcGVuZGVudCBvZiB0aGUgdW5jaGFuZ2VkIHByb2Nlc3MgcmVzb3VyY2UvZGVhZGxpbmUgZ3VhcmQuXG4gIHRlc3Quc2V0VGltZW91dCgxMjBfMDAwKTtcbiAgY29uc3QgcmVxdWVzdHM6IHN0cmluZ1tdID0gW10sXG4gICAgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuICBwYWdlLm9uKCdyZXF1ZXN0JywgKHJlcXVlc3QpID0+IHJlcXVlc3RzLnB1c2gocmVxdWVzdC51cmwoKSkpO1xuICBwYWdlLm9uKCdwYWdlZXJyb3InLCAoZXJyb3IpID0+IGVycm9ycy5wdXNoKGVycm9yLm1lc3NhZ2UpKTtcbiAgYXdhaXQgcGFnZS5nb3RvKCcuLz9mb3JjZVdlYkdMPTEjLycpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjY2hvb3NlLW90aGVsbG8nKSkudG9CZVZpc2libGUoKTtcbiAgZXhwZWN0KFxuICAgIHJlcXVlc3RzLmZpbHRlcigodXJsKSA9PiAvXFwud2FzbXxhaVxcLndvcmtlcnxxdW9yaWRvci18b3RoZWxsby18XFwuaGRyfFxcLm1wM3xcXC5vZ2cvLnRlc3QodXJsKSksXG4gICkudG9FcXVhbChbXSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI2Nob29zZS1xdW9yaWRvcicpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdFxuICAgIC5wb2xsKCgpID0+IHBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93Ll9fUVVPUklET1JfRElBR05PU1RJQ1NfXz8ucGhhc2UpKVxuICAgIC50b0JlKCdyZWFkeScpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNzdGFydHVwLW5ldy1nYW1lJykuY2xpY2soKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjbWF0Y2gtbW9kZScpLnNlbGVjdE9wdGlvbigncHZwJyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI2RpYWxvZy1zdGFydCcpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdFxuICAgIC5wb2xsKCgpID0+IHBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93Ll9fUVVPUklET1JfQVBQX1RFU1RfQVBJX18/LnN0YXRlKCkucGhhc2UpKVxuICAgIC50b0JlKCdodW1hblR1cm4nKTtcbiAgY29uc3QgcG9pbnQgPSBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IHdpbmRvdy5fX1FVT1JJRE9SX0FQUF9URVNUX0FQSV9fIS5wcm9qZWN0Q2VsbCgxMykpO1xuICBhd2FpdCBwYWdlLm1vdXNlLmNsaWNrKHBvaW50LngsIHBvaW50LnkpO1xuICBhd2FpdCBleHBlY3RcbiAgICAucG9sbCgoKSA9PiBwYWdlLmV2YWx1YXRlKCgpID0+IHdpbmRvdy5fX1FVT1JJRE9SX0FQUF9URVNUX0FQSV9fPy5zdGF0ZSgpLnZpZXc/LnBseSkpXG4gICAgLnRvQmUoMSk7XG4gIGNvbnN0IHJlcGxheSA9IGF3YWl0IHBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93Ll9fUVVPUklET1JfQVBQX1RFU1RfQVBJX18hLmV4cG9ydFJlcGxheSgpKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcudG9wLWFjdGlvbnMgLmhvbWUtbGluaycpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ob21lLXBhZ2UnKSkudG9CZVZpc2libGUoKTtcbiAgY29uc3QgbGVnYWN5ID0gYXdhaXQgbGVnYWN5U2xvdHMocGFnZSk7XG4gIGV4cGVjdChsZWdhY3lbMF0pLnRvQmVUcnV0aHkoKTtcbiAgYXdhaXQgb3Blbk90aGVsbG8ocGFnZSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tbmV3JykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tc2NvcmUnKSkudG9IYXZlVGV4dCgn6buSIDIg55+zIO+8jyDnmb0gMiDnn7MnKTtcbiAgYXdhaXQgY2VsbChwYWdlLCAxOSkuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tc2NvcmUnKSkudG9IYXZlVGV4dCgn6buSIDQg55+zIO+8jyDnmb0gMSDnn7MnKTtcbiAgYXdhaXQgZXhwZWN0KGNlbGwocGFnZSwgMjcpKS50b0hhdmVBdHRyaWJ1dGUoJ2RhdGEtc3RvbmUnLCAnMScpO1xuICBjb25zdCBvdGhlbGxvID0gYXdhaXQgc2F2ZWRPdGhlbGxvKHBhZ2UpO1xuICBhd2FpdCBwYWdlLnNjcmVlbnNob3QoeyBwYXRoOiB0ZXN0LmluZm8oKS5vdXRwdXRQYXRoKCdvdGhlbGxvLXBsYXkucG5nJykgfSk7XG4gIGF3YWl0IGxlYXZlT3RoZWxsbyhwYWdlKTtcbiAgZXhwZWN0KGF3YWl0IGxlZ2FjeVNsb3RzKHBhZ2UpKS50b0VxdWFsKGxlZ2FjeSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI2Nob29zZS1xdW9yaWRvcicpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdFxuICAgIC5wb2xsKCgpID0+IHBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93Ll9fUVVPUklET1JfRElBR05PU1RJQ1NfXz8ucGhhc2UpKVxuICAgIC50b0JlKCdyZWFkeScpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNyZXN1bWUtZ2FtZS1jaG9pY2UnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3RcbiAgICAucG9sbCgoKSA9PiBwYWdlLmV2YWx1YXRlKCgpID0+IHdpbmRvdy5fX1FVT1JJRE9SX0FQUF9URVNUX0FQSV9fPy5zdGF0ZSgpLnBoYXNlKSlcbiAgICAudG9CZSgnaHVtYW5UdXJuJyk7XG4gIGV4cGVjdChhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IHdpbmRvdy5fX1FVT1JJRE9SX0FQUF9URVNUX0FQSV9fIS5leHBvcnRSZXBsYXkoKSkpLnRvRXF1YWwoXG4gICAgcmVwbGF5LFxuICApO1xuICBleHBlY3QoYXdhaXQgc2F2ZWRPdGhlbGxvKHBhZ2UpKS50b0JlKG90aGVsbG8pO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJy50b3AtYWN0aW9ucyAuaG9tZS1saW5rJykuY2xpY2soKTtcbiAgYXdhaXQgb3Blbk90aGVsbG8ocGFnZSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tcmVzdW1lJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tc2NvcmUnKSkudG9IYXZlVGV4dCgn6buSIDQg55+zIO+8jyDnmb0gMSDnn7MnKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tcGxheWVycycpKS50b0NvbnRhaW5UZXh0KCfjg63jg7zjgqvjg6sy5Lq6Jyk7XG4gIGF3YWl0IHBhZ2UuZ29CYWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJy5ob21lLXBhZ2UnKSkudG9CZVZpc2libGUoKTtcbiAgYXdhaXQgcGFnZS5nb0ZvcndhcmQoKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1yZXN1bWUnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby10dXJuJykpLnRvSGF2ZVRleHQoJ+eZveOBruaJi+eVqicpO1xuICBhd2FpdCBwYWdlLmdvdG8oJy4vP2ZvcmNlV2ViR0w9MSMvb3RoZWxsbycpO1xuICBleHBlY3QobmV3IFVSTChwYWdlLnVybCgpKS5wYXRobmFtZSkudG9CZShuZXcgVVJMKHRlc3QuaW5mbygpLnByb2plY3QudXNlLmJhc2VVUkwhKS5wYXRobmFtZSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tcmVzdW1lJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tc2NvcmUnKSkudG9IYXZlVGV4dCgn6buSIDQg55+zIO+8jyDnmb0gMSDnn7MnKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignY2FudmFzLCBkaWFsb2cnKSkudG9IYXZlQ291bnQoMCk7XG4gIGV4cGVjdChlcnJvcnMpLnRvRXF1YWwoW10pO1xufSk7XG5cbnRlc3QoJ090aGVsbG8tb25seSBlbnRyeSByZW1haW5zIGxhenkgb24gaG9tZSwga2V5Ym9hcmQgcGxheSBhbmQgcmVhbCBib3VuZGVkIEFJIHVzZSBleHBsaWNpdCBodW1hbiBjb2xvcnMnLCBhc3luYyAoe1xuICBwYWdlLFxufSkgPT4ge1xuICBhd2FpdCBwYWdlLnNldFZpZXdwb3J0U2l6ZSh7IHdpZHRoOiAzNzUsIGhlaWdodDogODEyIH0pO1xuICBjb25zdCB3b3JrZXJzOiBzdHJpbmdbXSA9IFtdO1xuICBwYWdlLm9uKCd3b3JrZXInLCAod29ya2VyKSA9PiB3b3JrZXJzLnB1c2god29ya2VyLnVybCgpKSk7XG4gIGF3YWl0IHBhZ2UuZ290bygnLi8jLycpO1xuICBhd2FpdCBvcGVuT3RoZWxsbyhwYWdlKTtcbiAgZXhwZWN0KHdvcmtlcnMpLnRvRXF1YWwoW10pO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLW5ldycpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChjZWxsKHBhZ2UsIDE5KSkudG9IYXZlQXR0cmlidXRlKCdhcmlhLWRpc2FibGVkJywgJ2ZhbHNlJyk7XG4gIGF3YWl0IGNlbGwocGFnZSwgMTkpLmZvY3VzKCk7XG4gIGF3YWl0IHBhZ2Uua2V5Ym9hcmQucHJlc3MoJ0Fycm93UmlnaHQnKTtcbiAgYXdhaXQgZXhwZWN0KGNlbGwocGFnZSwgMjApKS50b0JlRm9jdXNlZCgpO1xuICBhd2FpdCBwYWdlLmtleWJvYXJkLnByZXNzKCdBcnJvd0xlZnQnKTtcbiAgYXdhaXQgcGFnZS5rZXlib2FyZC5wcmVzcygnRW50ZXInKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tc2NvcmUnKSkudG9IYXZlVGV4dCgn6buSIDQg55+zIO+8jyDnmb0gMSDnn7MnKTtcbiAgZXhwZWN0KGF3YWl0IHBhZ2UuZXZhbHVhdGUoKCkgPT4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNjcm9sbFdpZHRoIDw9IGlubmVyV2lkdGgpKS50b0JlKHRydWUpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLW1vZGUnKS5zZWxlY3RPcHRpb24oJ2FpJyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8taHVtYW4tc2lkZScpLnNlbGVjdE9wdGlvbignMicpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLW5ldycpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXBsYXllcnMnKSkudG9IYXZlVGV4dChcbiAgICAn57Ch5piTQUnvvIjpnZ7lrabnv5LvvInjgajlr77miKYgwrcg5Lq66ZaT77ya55m9IO+8jyDnsKHmmJNBSe+8mum7kicsXG4gICk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNjb3JlJykpLnRvSGF2ZVRleHQoJ+m7kiA0IOefsyDvvI8g55m9IDEg55+zJyk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXR1cm4nKSkudG9IYXZlVGV4dCgn55m944Gu5omL55WqJyk7XG4gIGV4cGVjdCh3b3JrZXJzKS50b0hhdmVMZW5ndGgoMSk7XG4gIGF3YWl0IGV4cGVjdChjZWxsKHBhZ2UsIDE5KSkudG9IYXZlQXR0cmlidXRlKCdkYXRhLXN0b25lJywgJzEnKTtcbiAgYXdhaXQgbGVhdmVPdGhlbGxvKHBhZ2UpO1xuICBhd2FpdCBvcGVuT3RoZWxsbyhwYWdlKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1yZXN1bWUnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1wbGF5ZXJzJykpLnRvQ29udGFpblRleHQoJ+S6uumWk++8mueZvSDvvI8g57Ch5piTQUnvvJrpu5InKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tdHVybicpKS50b0hhdmVUZXh0KCfnmb3jga7miYvnlaonKTtcbiAgZXhwZWN0KHdvcmtlcnMpLnRvSGF2ZUxlbmd0aCgxKTtcbn0pO1xuXG50ZXN0KCdPdGhlbGxvIFdvcmtlciBwZW5kaW5nIGNhbmNlbGxhdGlvbiB0ZXJtaW5hdGVzIG9uY2UgYW5kIHJlamVjdHMgYSBkZWxpYmVyYXRlbHkgbGF0ZSBtZXNzYWdlIHdpdGhvdXQgbXV0YXRpb24gb3IgbGVnYWN5IHdyaXRlcycsIGFzeW5jICh7XG4gIHBhZ2UsXG59KSA9PiB7XG4gIGF3YWl0IHBhZ2UuYWRkSW5pdFNjcmlwdCgoKSA9PiB7XG4gICAgY29uc3QgTmF0aXZlID0gd2luZG93LldvcmtlcjtcbiAgICBjb25zdCBtb25pdG9yID0geyBzdGFydHM6IDAsIHN0b3BzOiAwLCBsYXRlOiAoKSA9PiB7fSB9O1xuICAgICh3aW5kb3cgYXMgYW55KS5vdGhlbGxvV29ya2VyID0gbW9uaXRvcjtcbiAgICB3aW5kb3cuV29ya2VyID0gY2xhc3MgZXh0ZW5kcyBOYXRpdmUge1xuICAgICAgb3ZlcnJpZGUgcG9zdE1lc3NhZ2UobWVzc2FnZTogYW55KTogdm9pZCB7XG4gICAgICAgIG1vbml0b3Iuc3RhcnRzKys7XG4gICAgICAgIGNvbnN0IGNhbGxiYWNrID0gKHRoaXMgYXMgYW55KS5zYXZlZENhbGxiYWNrO1xuICAgICAgICBtb25pdG9yLmxhdGUgPSAoKSA9PlxuICAgICAgICAgIGNhbGxiYWNrKFxuICAgICAgICAgICAgbmV3IE1lc3NhZ2VFdmVudCgnbWVzc2FnZScsIHtcbiAgICAgICAgICAgICAgZGF0YTogeyBpZDogbWVzc2FnZS5pZCwgZ2VuZXJhdGlvbjogbWVzc2FnZS5nZW5lcmF0aW9uLCBvazogdHJ1ZSwgbW92ZTogMTkgfSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICk7XG4gICAgICAgIC8vIEtlZXAgdGhlIHJlYWwgZ2FtZS1vd25lZCBXb3JrZXIgcGVuZGluZzsgZGVsaXZlciB0aGUgY2FwdHVyZWQgY2FsbGJhY2sgYWZ0ZXIgdGVhcmRvd24uXG4gICAgICB9XG4gICAgICBvdmVycmlkZSBhZGRFdmVudExpc3RlbmVyKHR5cGU6IGFueSwgY2FsbGJhY2s6IGFueSwgb3B0aW9ucz86IGFueSk6IHZvaWQge1xuICAgICAgICBpZiAodHlwZSA9PT0gJ21lc3NhZ2UnKSAodGhpcyBhcyBhbnkpLnNhdmVkQ2FsbGJhY2sgPSBjYWxsYmFjaztcbiAgICAgICAgc3VwZXIuYWRkRXZlbnRMaXN0ZW5lcih0eXBlLCBjYWxsYmFjaywgb3B0aW9ucyk7XG4gICAgICB9XG4gICAgICBvdmVycmlkZSB0ZXJtaW5hdGUoKTogdm9pZCB7XG4gICAgICAgIG1vbml0b3Iuc3RvcHMrKztcbiAgICAgICAgc3VwZXIudGVybWluYXRlKCk7XG4gICAgICB9XG4gICAgfTtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgncXVvcmlkb3IubTEuZ2FtZS52MScsICdsZWdhY3kgc2VudGluZWwnKTtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgncXVvcmlkb3IubTEuc2V0dGluZ3MudjEnLCAnc2V0dGluZ3Mgc2VudGluZWwnKTtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgncXVvcmlkb3IuYXVkaW8uc2V0dGluZ3MudjEnLCAnYXVkaW8gc2VudGluZWwnKTtcbiAgfSk7XG4gIGF3YWl0IHBhZ2UuZ290bygnLi8jL290aGVsbG8nKTtcbiAgY29uc3QgbGVnYWN5ID0gYXdhaXQgbGVnYWN5U2xvdHMocGFnZSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tbW9kZScpLnNlbGVjdE9wdGlvbignYWknKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1odW1hbi1zaWRlJykuc2VsZWN0T3B0aW9uKCcyJyk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tbmV3JykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tdHVybicpKS50b0NvbnRhaW5UZXh0KCfogIPjgYjjgabjgYTjgb7jgZknKTtcbiAgY29uc3QgY29uZmlybWVkID0gYXdhaXQgc2F2ZWRPdGhlbGxvKHBhZ2UpO1xuICBhd2FpdCBsZWF2ZU90aGVsbG8ocGFnZSk7XG4gIGF3YWl0IHBhZ2UuZXZhbHVhdGUoKCkgPT4gKHdpbmRvdyBhcyBhbnkpLm90aGVsbG9Xb3JrZXIubGF0ZSgpKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignLm90aGVsbG8sIC5vdGhlbGxvLWJvYXJkLCBjYW52YXMnKSkudG9IYXZlQ291bnQoMCk7XG4gIGV4cGVjdChhd2FpdCBzYXZlZE90aGVsbG8ocGFnZSkpLnRvQmUoY29uZmlybWVkKTtcbiAgZXhwZWN0KGF3YWl0IGxlZ2FjeVNsb3RzKHBhZ2UpKS50b0VxdWFsKGxlZ2FjeSk7XG4gIGV4cGVjdChcbiAgICBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+ICh7XG4gICAgICBzdGFydHM6ICh3aW5kb3cgYXMgYW55KS5vdGhlbGxvV29ya2VyLnN0YXJ0cyxcbiAgICAgIHN0b3BzOiAod2luZG93IGFzIGFueSkub3RoZWxsb1dvcmtlci5zdG9wcyxcbiAgICB9KSksXG4gICkudG9FcXVhbCh7IHN0YXJ0czogMSwgc3RvcHM6IDEgfSk7XG59KTtcblxudGVzdCgnbGVhdmluZyBPdGhlbGxvIGR1cmluZyBhY3R1YWwgV2FzbSBpbml0aWFsaXphdGlvbiBjYW5ub3Qgc2F2ZSBvciByZW5kZXIgdGhlIGxhdGUgcmVzdWx0JywgYXN5bmMgKHtcbiAgcGFnZSxcbn0pID0+IHtcbiAgbGV0IHJlbGVhc2UhOiAoKSA9PiB2b2lkLCByZXF1ZXN0ZWQhOiAoKSA9PiB2b2lkO1xuICBjb25zdCBnYXRlID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcbiAgICByZWxlYXNlID0gcmVzb2x2ZTtcbiAgfSk7XG4gIGNvbnN0IHJlYWNoZWQgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuICAgIHJlcXVlc3RlZCA9IHJlc29sdmU7XG4gIH0pO1xuICBhd2FpdCBwYWdlLnJvdXRlKCcqKi8qb3RoZWxsb19iZyoud2FzbScsIGFzeW5jIChyb3V0ZSkgPT4ge1xuICAgIHJlcXVlc3RlZCgpO1xuICAgIGF3YWl0IGdhdGU7XG4gICAgYXdhaXQgcm91dGUuY29udGludWUoKTtcbiAgfSk7XG4gIGF3YWl0IHBhZ2UuZ290bygnLi8jL290aGVsbG8nKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1uZXcnKS5jbGljaygpO1xuICBhd2FpdCByZWFjaGVkO1xuICBhd2FpdCBsZWF2ZU90aGVsbG8ocGFnZSk7XG4gIHJlbGVhc2UoKTtcbiAgYXdhaXQgcGFnZS53YWl0Rm9yTG9hZFN0YXRlKCduZXR3b3JraWRsZScpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcub3RoZWxsbywgLm90aGVsbG8tYm9hcmQnKSkudG9IYXZlQ291bnQoMCk7XG4gIGV4cGVjdChhd2FpdCBzYXZlZE90aGVsbG8ocGFnZSkpLnRvQmVOdWxsKCk7XG59KTtcblxudGVzdCgnYmFkIHNhdmVzIGFyZSByZXRhaW5lZCwgcmV0cnkgYW5kIGV4cGxpY2l0IG5ldyBhcmUgYXZhaWxhYmxlLCB1bmF2YWlsYWJsZSBzdG9yYWdlIGlzIHZpc2libGUgdGhyb3VnaCBleGl0JywgYXN5bmMgKHtcbiAgcGFnZSxcbn0pID0+IHtcbiAgYXdhaXQgcGFnZS5nb3RvKCcuLyMvb3RoZWxsbycpO1xuICBhd2FpdCBwYWdlLmV2YWx1YXRlKChrZXkpID0+IGxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgJ3ticm9rZW4nKSwgT1RIRUxMT19TQVZFKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1yZXN1bWUnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1lcnJvcicpKS5ub3QudG9CZUVtcHR5KCk7XG4gIGV4cGVjdChhd2FpdCBzYXZlZE90aGVsbG8ocGFnZSkpLnRvQmUoJ3ticm9rZW4nKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1yZXN1bWUnKS5jbGljaygpO1xuICBleHBlY3QoYXdhaXQgc2F2ZWRPdGhlbGxvKHBhZ2UpKS50b0JlKCd7YnJva2VuJyk7XG4gIC8vIFRoZSB1c2VyJ3MgZXhwbGljaXQgbmV3IHNlbGVjdGlvbiBhdXRob3JpemVzIHJlcGxhY2luZyB0aGUgYnJva2VuIE90aGVsbG8gc2xvdC5cbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1uZXcnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1zY29yZScpKS50b0hhdmVUZXh0KCfpu5IgMiDnn7Mg77yPIOeZvSAyIOefsycpO1xuICBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IHtcbiAgICBTdG9yYWdlLnByb3RvdHlwZS5zZXRJdGVtID0gKCkgPT4ge1xuICAgICAgdGhyb3cgbmV3IERPTUV4Y2VwdGlvbigncXVvdGEnLCAnUXVvdGFFeGNlZWRlZEVycm9yJyk7XG4gICAgfTtcbiAgfSk7XG4gIGF3YWl0IGNlbGwocGFnZSwgMTkpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNhdmUtc3RhdHVzJykpLnRvQ29udGFpblRleHQoJ+S/neWtmOOBp+OBjeOBvuOBm+OCkycpO1xuICBhd2FpdCBsZWF2ZU90aGVsbG8ocGFnZSk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNob21lLXNhdmUtd2FybmluZycpKS50b0NvbnRhaW5UZXh0KCdPdGhlbGxv44KS5L+d5a2Y44Gn44GN44G+44Gb44KTJyk7XG59KTtcblxudGVzdCgnc2F2ZWQgZm9yY2VkLXBhc3MgYW5kIHRlcm1pbmFsIGZpeHR1cmVzIHJlbmRlciBSdXN0IHN0YXR1cywgd2lucyBhbmQgZHJhdyB3aXRob3V0IEpTIHJ1bGVzJywgYXN5bmMgKHtcbiAgcGFnZSxcbn0pID0+IHtcbiAgYXdhaXQgcGFnZS5nb3RvKCcuLyMvb3RoZWxsbycpO1xuICBhc3luYyBmdW5jdGlvbiByZXN1bWUoYm9hcmQ6IG51bWJlcltdLCB0b01vdmU6IG51bWJlcikge1xuICAgIGF3YWl0IHBhZ2UuZXZhbHVhdGUoXG4gICAgICAoeyBrZXksIGJvYXJkLCB0b01vdmUgfSkgPT5cbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXG4gICAgICAgICAga2V5LFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgIHZlcnNpb246IDEsXG4gICAgICAgICAgICBnYW1lOiAnb3RoZWxsbycsXG4gICAgICAgICAgICBtb2RlOiAnbG9jYWwnLFxuICAgICAgICAgICAgaHVtYW5TaWRlOiAxLFxuICAgICAgICAgICAgc3RhdGU6IHsgdmVyc2lvbjogMSwgYm9hcmQsIHRvTW92ZSB9LFxuICAgICAgICAgIH0pLFxuICAgICAgICApLFxuICAgICAgeyBrZXk6IE9USEVMTE9fU0FWRSwgYm9hcmQsIHRvTW92ZSB9LFxuICAgICk7XG4gICAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1yZXN1bWUnKS5jbGljaygpO1xuICB9XG4gIGNvbnN0IGZvcmNlZCA9IEFycmF5PG51bWJlcj4oNjQpLmZpbGwoMCk7XG4gIGZvcmNlZFswXSA9IDE7XG4gIGZvcmNlZFsxXSA9IDI7XG4gIGF3YWl0IHJlc3VtZShmb3JjZWQsIDIpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1ndWlkZScpKS50b0NvbnRhaW5UZXh0KCfjg5HjgrnjgYzlv4XopoEnKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1wYXNzJykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tdHVybicpKS50b0hhdmVUZXh0KCfpu5Ljga7miYvnlaonKTtcbiAgYXdhaXQgY2VsbChwYWdlLCAyKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby10dXJuJykpLnRvSGF2ZVRleHQoJ+e1guWxgO+8mum7kuOBruWLneOBoScpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1zY29yZScpKS50b0hhdmVUZXh0KCfpu5IgMyDnn7Mg77yPIOeZvSAwIOefsycpO1xuICBhd2FpdCByZXN1bWUoQXJyYXk8bnVtYmVyPig2NCkuZmlsbCgyKSwgMSk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXR1cm4nKSkudG9IYXZlVGV4dCgn57WC5bGA77ya55m944Gu5Yud44GhJyk7XG4gIGF3YWl0IHJlc3VtZShcbiAgICBBcnJheS5mcm9tKHsgbGVuZ3RoOiA2NCB9LCAoXywgaSkgPT4gKGkgPCAzMiA/IDEgOiAyKSksXG4gICAgMixcbiAgKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tdHVybicpKS50b0hhdmVUZXh0KCfntYLlsYDvvJrlvJXliIbjgZEnKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tcGFzcycpKS50b0JlSGlkZGVuKCk7XG4gIGV4cGVjdChhd2FpdCBwYWdlLmxvY2F0b3IoJy5vdGhlbGxvLWNlbGxbYXJpYS1kaXNhYmxlZD1cImZhbHNlXCJdJykuY291bnQoKSkudG9CZSgwKTtcbn0pO1xuXG50ZXN0KCdhY3RpdmUgT3RoZWxsbyBmYWlsZWQgcmVzdW1lIHByZXNlcnZlcyBjb3JydXB0IHNsb3Qgb24gZXhpdCB1bnRpbCBleHBsaWNpdCBuZXcgY2hvaWNlJywgYXN5bmMgKHtcbiAgcGFnZSxcbn0pID0+IHtcbiAgYXdhaXQgcGFnZS5nb3RvKCcuLyMvb3RoZWxsbycpO1xuICBhd2FpdCBwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLW5ldycpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNjb3JlJykpLnRvSGF2ZVRleHQoJ+m7kiAyIOefsyDvvI8g55m9IDIg55+zJyk7XG4gIGF3YWl0IHBhZ2UuZXZhbHVhdGUoKGtleSkgPT4gbG9jYWxTdG9yYWdlLnNldEl0ZW0oa2V5LCAne2FjdGl2ZSBjb3JydXB0IHNhdmUnKSwgT1RIRUxMT19TQVZFKTtcbiAgYXdhaXQgcGFnZS5sb2NhdG9yKCcjb3RoZWxsby1yZXN1bWUnKS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QocGFnZS5sb2NhdG9yKCcjb3RoZWxsby1lcnJvcicpKS5ub3QudG9CZUVtcHR5KCk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tc2F2ZScpLmNsaWNrKCk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNvdGhlbGxvLXNhdmUtc3RhdHVzJykpLnRvQ29udGFpblRleHQoJ+WFg+OBruS/neWtmOOCkuS/neaMgScpO1xuICBleHBlY3QoYXdhaXQgc2F2ZWRPdGhlbGxvKHBhZ2UpKS50b0JlKCd7YWN0aXZlIGNvcnJ1cHQgc2F2ZScpO1xuICBhd2FpdCBsZWF2ZU90aGVsbG8ocGFnZSk7XG4gIGF3YWl0IGV4cGVjdChwYWdlLmxvY2F0b3IoJyNob21lLXNhdmUtd2FybmluZycpKS50b0NvbnRhaW5UZXh0KCflhYPjga7kv53lrZjjgpLkv53mjIEnKTtcbiAgZXhwZWN0KGF3YWl0IHNhdmVkT3RoZWxsbyhwYWdlKSkudG9CZSgne2FjdGl2ZSBjb3JydXB0IHNhdmUnKTtcbiAgYXdhaXQgb3Blbk90aGVsbG8ocGFnZSk7XG4gIGF3YWl0IHBhZ2UubG9jYXRvcignI290aGVsbG8tbmV3JykuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KHBhZ2UubG9jYXRvcignI290aGVsbG8tc2NvcmUnKSkudG9IYXZlVGV4dCgn6buSIDIg55+zIO+8jyDnmb0gMiDnn7MnKTtcbiAgZXhwZWN0KEpTT04ucGFyc2UoKGF3YWl0IHNhdmVkT3RoZWxsbyhwYWdlKSkhKS52ZXJzaW9uKS50b0JlKDEpO1xufSk7XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVNBLElBQUksRUFBRUMsTUFBTSxRQUFtQixrQkFBa0I7QUFFMUQsTUFBTUMsWUFBWSxHQUFHLGlCQUFpQjtBQUN0QyxNQUFNQyxXQUFXLEdBQUcscUJBQXFCO0FBQ3pDLE1BQU1DLGVBQWUsR0FBRyx5QkFBeUI7QUFDakQsTUFBTUMsWUFBWSxHQUFHLDRCQUE0QjtBQUNqRCxNQUFNQyxJQUFJLEdBQUdBLENBQUNDLElBQVUsRUFBRUMsS0FBYSxLQUFLRCxJQUFJLENBQUNFLE9BQU8sQ0FBQyw2QkFBNkJELEtBQUssSUFBSSxDQUFDO0FBQ2hHLE1BQU1FLFdBQVcsR0FBRyxNQUFPSCxJQUFVLElBQUs7RUFDeEMsTUFBTUEsSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsU0FBUyxDQUFDO0FBQ2pFLENBQUM7QUFDRCxNQUFNQyxZQUFZLEdBQUcsTUFBT04sSUFBVSxJQUFLO0VBQ3pDLE1BQU1BLElBQUksQ0FBQ08sU0FBUyxDQUFDLE1BQU0sRUFBRTtJQUFFQyxJQUFJLEVBQUU7RUFBVyxDQUFDLENBQUMsQ0FBQ0osS0FBSyxDQUFDLENBQUM7RUFDMUQsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDTyxXQUFXLENBQUMsQ0FBQztBQUN4RCxDQUFDO0FBQ0QsZUFBZUMsV0FBV0EsQ0FBQ1YsSUFBVSxFQUFFO0VBQ3JDLE9BQU9BLElBQUksQ0FBQ1csUUFBUSxDQUNsQixDQUFDLENBQUNDLElBQUksRUFBRUMsUUFBUSxFQUFFQyxLQUFLLENBQUMsS0FBSyxDQUFDRixJQUFJLEVBQUVDLFFBQVEsRUFBRUMsS0FBSyxDQUFDLENBQUNDLEdBQUcsQ0FBRUMsR0FBRyxJQUFLQyxZQUFZLENBQUNDLE9BQU8sQ0FBQ0YsR0FBSSxDQUFDLENBQUMsRUFDN0YsQ0FBQ3BCLFdBQVcsRUFBRUMsZUFBZSxFQUFFQyxZQUFZLENBQzdDLENBQUM7QUFDSDtBQUNBLGVBQWVxQixZQUFZQSxDQUFDbkIsSUFBVSxFQUFFO0VBQ3RDLE9BQU9BLElBQUksQ0FBQ1csUUFBUSxDQUFFSyxHQUFHLElBQUtDLFlBQVksQ0FBQ0MsT0FBTyxDQUFDRixHQUFHLENBQUMsRUFBRXJCLFlBQVksQ0FBQztBQUN4RTtBQUVBRixJQUFJLENBQUMsa0hBQWtILEVBQUUsT0FBTztFQUM5SE87QUFDRixDQUFDLEtBQUs7RUFDSjtFQUNBO0VBQ0FQLElBQUksQ0FBQzJCLFVBQVUsQ0FBQyxNQUFPLENBQUM7RUFDeEIsTUFBTUMsUUFBa0IsR0FBRyxFQUFFO0lBQzNCQyxNQUFnQixHQUFHLEVBQUU7RUFDdkJ0QixJQUFJLENBQUN1QixFQUFFLENBQUMsU0FBUyxFQUFHQyxPQUFPLElBQUtILFFBQVEsQ0FBQ0ksSUFBSSxDQUFDRCxPQUFPLENBQUNFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUM3RDFCLElBQUksQ0FBQ3VCLEVBQUUsQ0FBQyxXQUFXLEVBQUdJLEtBQUssSUFBS0wsTUFBTSxDQUFDRyxJQUFJLENBQUNFLEtBQUssQ0FBQ0MsT0FBTyxDQUFDLENBQUM7RUFDM0QsTUFBTTVCLElBQUksQ0FBQzZCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztFQUNwQyxNQUFNbkMsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUNPLFdBQVcsQ0FBQyxDQUFDO0VBQzNEZixNQUFNLENBQ0oyQixRQUFRLENBQUNTLE1BQU0sQ0FBRUosR0FBRyxJQUFLLHdEQUF3RCxDQUFDakMsSUFBSSxDQUFDaUMsR0FBRyxDQUFDLENBQzdGLENBQUMsQ0FBQ0ssT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUNiLE1BQU0vQixJQUFJLENBQUNFLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUM5QyxNQUFNVixNQUFNLENBQ1RzQyxJQUFJLENBQUMsTUFBTWhDLElBQUksQ0FBQ1csUUFBUSxDQUFDO0lBQUEsSUFBQXNCLHFCQUFBO0lBQUEsUUFBQUEscUJBQUEsR0FBTUMsTUFBTSxDQUFDQyx3QkFBd0IsY0FBQUYscUJBQUEsdUJBQS9CQSxxQkFBQSxDQUFpQ0csS0FBSztFQUFBLEVBQUMsQ0FBQyxDQUN2RUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztFQUNoQixNQUFNckMsSUFBSSxDQUFDRSxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDL0MsTUFBTUosSUFBSSxDQUFDRSxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUNvQyxZQUFZLENBQUMsS0FBSyxDQUFDO0VBQ3JELE1BQU10QyxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDM0MsTUFBTVYsTUFBTSxDQUNUc0MsSUFBSSxDQUFDLE1BQU1oQyxJQUFJLENBQUNXLFFBQVEsQ0FBQztJQUFBLElBQUE0QixxQkFBQTtJQUFBLFFBQUFBLHFCQUFBLEdBQU1MLE1BQU0sQ0FBQ00seUJBQXlCLGNBQUFELHFCQUFBLHVCQUFoQ0EscUJBQUEsQ0FBa0NFLEtBQUssQ0FBQyxDQUFDLENBQUNMLEtBQUs7RUFBQSxFQUFDLENBQUMsQ0FDaEZDLElBQUksQ0FBQyxXQUFXLENBQUM7RUFDcEIsTUFBTUssS0FBSyxHQUFHLE1BQU0xQyxJQUFJLENBQUNXLFFBQVEsQ0FBQyxNQUFNdUIsTUFBTSxDQUFDTSx5QkFBeUIsQ0FBRUcsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQzFGLE1BQU0zQyxJQUFJLENBQUM0QyxLQUFLLENBQUN4QyxLQUFLLENBQUNzQyxLQUFLLENBQUNHLENBQUMsRUFBRUgsS0FBSyxDQUFDSSxDQUFDLENBQUM7RUFDeEMsTUFBTXBELE1BQU0sQ0FDVHNDLElBQUksQ0FBQyxNQUFNaEMsSUFBSSxDQUFDVyxRQUFRLENBQUM7SUFBQSxJQUFBb0Msc0JBQUE7SUFBQSxRQUFBQSxzQkFBQSxHQUFNYixNQUFNLENBQUNNLHlCQUF5QixjQUFBTyxzQkFBQSxnQkFBQUEsc0JBQUEsR0FBaENBLHNCQUFBLENBQWtDTixLQUFLLENBQUMsQ0FBQyxDQUFDTyxJQUFJLGNBQUFELHNCQUFBLHVCQUE5Q0Esc0JBQUEsQ0FBZ0RFLEdBQUc7RUFBQSxFQUFDLENBQUMsQ0FDcEZaLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDVixNQUFNYSxNQUFNLEdBQUcsTUFBTWxELElBQUksQ0FBQ1csUUFBUSxDQUFDLE1BQU11QixNQUFNLENBQUNNLHlCQUF5QixDQUFFVyxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQzFGLE1BQU1uRCxJQUFJLENBQUNFLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUNyRCxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUNPLFdBQVcsQ0FBQyxDQUFDO0VBQ3RELE1BQU0yQyxNQUFNLEdBQUcsTUFBTTFDLFdBQVcsQ0FBQ1YsSUFBSSxDQUFDO0VBQ3RDTixNQUFNLENBQUMwRCxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsVUFBVSxDQUFDLENBQUM7RUFDOUIsTUFBTWxELFdBQVcsQ0FBQ0gsSUFBSSxDQUFDO0VBQ3ZCLE1BQU1BLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMxQyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RSxNQUFNTixJQUFJLENBQUNDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQ0ksS0FBSyxDQUFDLENBQUM7RUFDNUIsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxlQUFlLENBQUM7RUFDeEUsTUFBTVgsTUFBTSxDQUFDSyxJQUFJLENBQUNDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDc0QsZUFBZSxDQUFDLFlBQVksRUFBRSxHQUFHLENBQUM7RUFDL0QsTUFBTUMsT0FBTyxHQUFHLE1BQU1wQyxZQUFZLENBQUNuQixJQUFJLENBQUM7RUFDeEMsTUFBTUEsSUFBSSxDQUFDd0QsVUFBVSxDQUFDO0lBQUVDLElBQUksRUFBRWhFLElBQUksQ0FBQ2lFLElBQUksQ0FBQyxDQUFDLENBQUNDLFVBQVUsQ0FBQyxrQkFBa0I7RUFBRSxDQUFDLENBQUM7RUFDM0UsTUFBTXJELFlBQVksQ0FBQ04sSUFBSSxDQUFDO0VBQ3hCTixNQUFNLENBQUMsTUFBTWdCLFdBQVcsQ0FBQ1YsSUFBSSxDQUFDLENBQUMsQ0FBQytCLE9BQU8sQ0FBQ3FCLE1BQU0sQ0FBQztFQUMvQyxNQUFNcEQsSUFBSSxDQUFDRSxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDOUMsTUFBTVYsTUFBTSxDQUNUc0MsSUFBSSxDQUFDLE1BQU1oQyxJQUFJLENBQUNXLFFBQVEsQ0FBQztJQUFBLElBQUFpRCxzQkFBQTtJQUFBLFFBQUFBLHNCQUFBLEdBQU0xQixNQUFNLENBQUNDLHdCQUF3QixjQUFBeUIsc0JBQUEsdUJBQS9CQSxzQkFBQSxDQUFpQ3hCLEtBQUs7RUFBQSxFQUFDLENBQUMsQ0FDdkVDLElBQUksQ0FBQyxPQUFPLENBQUM7RUFDaEIsTUFBTXJDLElBQUksQ0FBQ0UsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQ2pELE1BQU1WLE1BQU0sQ0FDVHNDLElBQUksQ0FBQyxNQUFNaEMsSUFBSSxDQUFDVyxRQUFRLENBQUM7SUFBQSxJQUFBa0Qsc0JBQUE7SUFBQSxRQUFBQSxzQkFBQSxHQUFNM0IsTUFBTSxDQUFDTSx5QkFBeUIsY0FBQXFCLHNCQUFBLHVCQUFoQ0Esc0JBQUEsQ0FBa0NwQixLQUFLLENBQUMsQ0FBQyxDQUFDTCxLQUFLO0VBQUEsRUFBQyxDQUFDLENBQ2hGQyxJQUFJLENBQUMsV0FBVyxDQUFDO0VBQ3BCM0MsTUFBTSxDQUFDLE1BQU1NLElBQUksQ0FBQ1csUUFBUSxDQUFDLE1BQU11QixNQUFNLENBQUNNLHlCQUF5QixDQUFFVyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ3BCLE9BQU8sQ0FDekZtQixNQUNGLENBQUM7RUFDRHhELE1BQU0sQ0FBQyxNQUFNeUIsWUFBWSxDQUFDbkIsSUFBSSxDQUFDLENBQUMsQ0FBQ3FDLElBQUksQ0FBQ2tCLE9BQU8sQ0FBQztFQUM5QyxNQUFNdkQsSUFBSSxDQUFDRSxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDckQsTUFBTUQsV0FBVyxDQUFDSCxJQUFJLENBQUM7RUFDdkIsTUFBTUEsSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxlQUFlLENBQUM7RUFDeEUsTUFBTVgsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM0RCxhQUFhLENBQUMsUUFBUSxDQUFDO0VBQ3RFLE1BQU05RCxJQUFJLENBQUMrRCxNQUFNLENBQUMsQ0FBQztFQUNuQixNQUFNckUsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDTyxXQUFXLENBQUMsQ0FBQztFQUN0RCxNQUFNVCxJQUFJLENBQUNnRSxTQUFTLENBQUMsQ0FBQztFQUN0QixNQUFNaEUsSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsTUFBTSxDQUFDO0VBQzlELE1BQU1MLElBQUksQ0FBQzZCLElBQUksQ0FBQywwQkFBMEIsQ0FBQztFQUMzQ25DLE1BQU0sQ0FBQyxJQUFJdUUsR0FBRyxDQUFDakUsSUFBSSxDQUFDMEIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDd0MsUUFBUSxDQUFDLENBQUM3QixJQUFJLENBQUMsSUFBSTRCLEdBQUcsQ0FBQ3hFLElBQUksQ0FBQ2lFLElBQUksQ0FBQyxDQUFDLENBQUNTLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDQyxPQUFRLENBQUMsQ0FBQ0gsUUFBUSxDQUFDO0VBQzdGLE1BQU1sRSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUM3QyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RSxNQUFNWCxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ29FLFdBQVcsQ0FBQyxDQUFDLENBQUM7RUFDM0Q1RSxNQUFNLENBQUM0QixNQUFNLENBQUMsQ0FBQ1MsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUM1QixDQUFDLENBQUM7QUFFRnRDLElBQUksQ0FBQyxzR0FBc0csRUFBRSxPQUFPO0VBQ2xITztBQUNGLENBQUMsS0FBSztFQUNKLE1BQU1BLElBQUksQ0FBQ3VFLGVBQWUsQ0FBQztJQUFFQyxLQUFLLEVBQUUsR0FBRztJQUFFQyxNQUFNLEVBQUU7RUFBSSxDQUFDLENBQUM7RUFDdkQsTUFBTUMsT0FBaUIsR0FBRyxFQUFFO0VBQzVCMUUsSUFBSSxDQUFDdUIsRUFBRSxDQUFDLFFBQVEsRUFBR29ELE1BQU0sSUFBS0QsT0FBTyxDQUFDakQsSUFBSSxDQUFDa0QsTUFBTSxDQUFDakQsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3pELE1BQU0xQixJQUFJLENBQUM2QixJQUFJLENBQUMsTUFBTSxDQUFDO0VBQ3ZCLE1BQU0xQixXQUFXLENBQUNILElBQUksQ0FBQztFQUN2Qk4sTUFBTSxDQUFDZ0YsT0FBTyxDQUFDLENBQUMzQyxPQUFPLENBQUMsRUFBRSxDQUFDO0VBQzNCLE1BQU0vQixJQUFJLENBQUNFLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDMUMsTUFBTVYsTUFBTSxDQUFDSyxJQUFJLENBQUNDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDc0QsZUFBZSxDQUFDLGVBQWUsRUFBRSxPQUFPLENBQUM7RUFDdEUsTUFBTXZELElBQUksQ0FBQ0MsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDNEUsS0FBSyxDQUFDLENBQUM7RUFDNUIsTUFBTTVFLElBQUksQ0FBQzZFLFFBQVEsQ0FBQ0MsS0FBSyxDQUFDLFlBQVksQ0FBQztFQUN2QyxNQUFNcEYsTUFBTSxDQUFDSyxJQUFJLENBQUNDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDK0UsV0FBVyxDQUFDLENBQUM7RUFDMUMsTUFBTS9FLElBQUksQ0FBQzZFLFFBQVEsQ0FBQ0MsS0FBSyxDQUFDLFdBQVcsQ0FBQztFQUN0QyxNQUFNOUUsSUFBSSxDQUFDNkUsUUFBUSxDQUFDQyxLQUFLLENBQUMsT0FBTyxDQUFDO0VBQ2xDLE1BQU1wRixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RVgsTUFBTSxDQUFDLE1BQU1NLElBQUksQ0FBQ1csUUFBUSxDQUFDLE1BQU1xRSxRQUFRLENBQUNDLGVBQWUsQ0FBQ0MsV0FBVyxJQUFJQyxVQUFVLENBQUMsQ0FBQyxDQUFDOUMsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNoRyxNQUFNckMsSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUNvQyxZQUFZLENBQUMsSUFBSSxDQUFDO0VBQ3RELE1BQU10QyxJQUFJLENBQUNFLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDb0MsWUFBWSxDQUFDLEdBQUcsQ0FBQztFQUMzRCxNQUFNdEMsSUFBSSxDQUFDRSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzFDLE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQ3ZELDhCQUNGLENBQUM7RUFDRCxNQUFNWCxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RSxNQUFNWCxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxNQUFNLENBQUM7RUFDOURYLE1BQU0sQ0FBQ2dGLE9BQU8sQ0FBQyxDQUFDVSxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQy9CLE1BQU0xRixNQUFNLENBQUNLLElBQUksQ0FBQ0MsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUNzRCxlQUFlLENBQUMsWUFBWSxFQUFFLEdBQUcsQ0FBQztFQUMvRCxNQUFNaEQsWUFBWSxDQUFDTixJQUFJLENBQUM7RUFDeEIsTUFBTUcsV0FBVyxDQUFDSCxJQUFJLENBQUM7RUFDdkIsTUFBTUEsSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM0RCxhQUFhLENBQUMsZUFBZSxDQUFDO0VBQzdFLE1BQU1wRSxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxNQUFNLENBQUM7RUFDOURYLE1BQU0sQ0FBQ2dGLE9BQU8sQ0FBQyxDQUFDVSxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQztBQUVGM0YsSUFBSSxDQUFDLCtIQUErSCxFQUFFLE9BQU87RUFDM0lPO0FBQ0YsQ0FBQyxLQUFLO0VBQ0osTUFBTUEsSUFBSSxDQUFDcUYsYUFBYSxDQUFDLE1BQU07SUFDN0IsTUFBTUMsTUFBTSxHQUFHcEQsTUFBTSxDQUFDcUQsTUFBTTtJQUM1QixNQUFNQyxPQUFPLEdBQUc7TUFBRUMsTUFBTSxFQUFFLENBQUM7TUFBRUMsS0FBSyxFQUFFLENBQUM7TUFBRUMsSUFBSSxFQUFFQSxDQUFBLEtBQU0sQ0FBQztJQUFFLENBQUM7SUFDdER6RCxNQUFNLENBQVMwRCxhQUFhLEdBQUdKLE9BQU87SUFDdkN0RCxNQUFNLENBQUNxRCxNQUFNLEdBQUcsY0FBY0QsTUFBTSxDQUFDO01BQzFCTyxXQUFXQSxDQUFDakUsT0FBWSxFQUFRO1FBQ3ZDNEQsT0FBTyxDQUFDQyxNQUFNLEVBQUU7UUFDaEIsTUFBTUssUUFBUSxHQUFJLElBQUksQ0FBU0MsYUFBYTtRQUM1Q1AsT0FBTyxDQUFDRyxJQUFJLEdBQUcsTUFDYkcsUUFBUSxDQUNOLElBQUlFLFlBQVksQ0FBQyxTQUFTLEVBQUU7VUFDMUJDLElBQUksRUFBRTtZQUFFQyxFQUFFLEVBQUV0RSxPQUFPLENBQUNzRSxFQUFFO1lBQUVDLFVBQVUsRUFBRXZFLE9BQU8sQ0FBQ3VFLFVBQVU7WUFBRUMsRUFBRSxFQUFFLElBQUk7WUFBRUMsSUFBSSxFQUFFO1VBQUc7UUFDN0UsQ0FBQyxDQUNILENBQUM7UUFDSDtNQUNGO01BQ1NDLGdCQUFnQkEsQ0FBQ0MsSUFBUyxFQUFFVCxRQUFhLEVBQUVVLE9BQWEsRUFBUTtRQUN2RSxJQUFJRCxJQUFJLEtBQUssU0FBUyxFQUFHLElBQUksQ0FBU1IsYUFBYSxHQUFHRCxRQUFRO1FBQzlELEtBQUssQ0FBQ1EsZ0JBQWdCLENBQUNDLElBQUksRUFBRVQsUUFBUSxFQUFFVSxPQUFPLENBQUM7TUFDakQ7TUFDU0MsU0FBU0EsQ0FBQSxFQUFTO1FBQ3pCakIsT0FBTyxDQUFDRSxLQUFLLEVBQUU7UUFDZixLQUFLLENBQUNlLFNBQVMsQ0FBQyxDQUFDO01BQ25CO0lBQ0YsQ0FBQztJQUNEeEYsWUFBWSxDQUFDeUYsT0FBTyxDQUFDLHFCQUFxQixFQUFFLGlCQUFpQixDQUFDO0lBQzlEekYsWUFBWSxDQUFDeUYsT0FBTyxDQUFDLHlCQUF5QixFQUFFLG1CQUFtQixDQUFDO0lBQ3BFekYsWUFBWSxDQUFDeUYsT0FBTyxDQUFDLDRCQUE0QixFQUFFLGdCQUFnQixDQUFDO0VBQ3RFLENBQUMsQ0FBQztFQUNGLE1BQU0xRyxJQUFJLENBQUM2QixJQUFJLENBQUMsYUFBYSxDQUFDO0VBQzlCLE1BQU11QixNQUFNLEdBQUcsTUFBTTFDLFdBQVcsQ0FBQ1YsSUFBSSxDQUFDO0VBQ3RDLE1BQU1BLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDb0MsWUFBWSxDQUFDLElBQUksQ0FBQztFQUN0RCxNQUFNdEMsSUFBSSxDQUFDRSxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQ29DLFlBQVksQ0FBQyxHQUFHLENBQUM7RUFDM0QsTUFBTXRDLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMxQyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM0RCxhQUFhLENBQUMsUUFBUSxDQUFDO0VBQ25FLE1BQU02QyxTQUFTLEdBQUcsTUFBTXhGLFlBQVksQ0FBQ25CLElBQUksQ0FBQztFQUMxQyxNQUFNTSxZQUFZLENBQUNOLElBQUksQ0FBQztFQUN4QixNQUFNQSxJQUFJLENBQUNXLFFBQVEsQ0FBQyxNQUFPdUIsTUFBTSxDQUFTMEQsYUFBYSxDQUFDRCxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQy9ELE1BQU1qRyxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGtDQUFrQyxDQUFDLENBQUMsQ0FBQ29FLFdBQVcsQ0FBQyxDQUFDLENBQUM7RUFDN0U1RSxNQUFNLENBQUMsTUFBTXlCLFlBQVksQ0FBQ25CLElBQUksQ0FBQyxDQUFDLENBQUNxQyxJQUFJLENBQUNzRSxTQUFTLENBQUM7RUFDaERqSCxNQUFNLENBQUMsTUFBTWdCLFdBQVcsQ0FBQ1YsSUFBSSxDQUFDLENBQUMsQ0FBQytCLE9BQU8sQ0FBQ3FCLE1BQU0sQ0FBQztFQUMvQzFELE1BQU0sQ0FDSixNQUFNTSxJQUFJLENBQUNXLFFBQVEsQ0FBQyxPQUFPO0lBQ3pCOEUsTUFBTSxFQUFHdkQsTUFBTSxDQUFTMEQsYUFBYSxDQUFDSCxNQUFNO0lBQzVDQyxLQUFLLEVBQUd4RCxNQUFNLENBQVMwRCxhQUFhLENBQUNGO0VBQ3ZDLENBQUMsQ0FBQyxDQUNKLENBQUMsQ0FBQzNELE9BQU8sQ0FBQztJQUFFMEQsTUFBTSxFQUFFLENBQUM7SUFBRUMsS0FBSyxFQUFFO0VBQUUsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQztBQUVGakcsSUFBSSxDQUFDLHlGQUF5RixFQUFFLE9BQU87RUFDckdPO0FBQ0YsQ0FBQyxLQUFLO0VBQ0osSUFBSTRHLE9BQW9CLEVBQUVDLFNBQXNCO0VBQ2hELE1BQU1DLElBQUksR0FBRyxJQUFJQyxPQUFPLENBQVFDLE9BQU8sSUFBSztJQUMxQ0osT0FBTyxHQUFHSSxPQUFPO0VBQ25CLENBQUMsQ0FBQztFQUNGLE1BQU1DLE9BQU8sR0FBRyxJQUFJRixPQUFPLENBQVFDLE9BQU8sSUFBSztJQUM3Q0gsU0FBUyxHQUFHRyxPQUFPO0VBQ3JCLENBQUMsQ0FBQztFQUNGLE1BQU1oSCxJQUFJLENBQUNrSCxLQUFLLENBQUMsc0JBQXNCLEVBQUUsTUFBT0EsS0FBSyxJQUFLO0lBQ3hETCxTQUFTLENBQUMsQ0FBQztJQUNYLE1BQU1DLElBQUk7SUFDVixNQUFNSSxLQUFLLENBQUNDLFFBQVEsQ0FBQyxDQUFDO0VBQ3hCLENBQUMsQ0FBQztFQUNGLE1BQU1uSCxJQUFJLENBQUM2QixJQUFJLENBQUMsYUFBYSxDQUFDO0VBQzlCLE1BQU03QixJQUFJLENBQUNFLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDMUMsTUFBTTZHLE9BQU87RUFDYixNQUFNM0csWUFBWSxDQUFDTixJQUFJLENBQUM7RUFDeEI0RyxPQUFPLENBQUMsQ0FBQztFQUNULE1BQU01RyxJQUFJLENBQUNvSCxnQkFBZ0IsQ0FBQyxhQUFhLENBQUM7RUFDMUMsTUFBTTFILE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDb0UsV0FBVyxDQUFDLENBQUMsQ0FBQztFQUNyRTVFLE1BQU0sQ0FBQyxNQUFNeUIsWUFBWSxDQUFDbkIsSUFBSSxDQUFDLENBQUMsQ0FBQ3FILFFBQVEsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQztBQUVGNUgsSUFBSSxDQUFDLDJHQUEyRyxFQUFFLE9BQU87RUFDdkhPO0FBQ0YsQ0FBQyxLQUFLO0VBQ0osTUFBTUEsSUFBSSxDQUFDNkIsSUFBSSxDQUFDLGFBQWEsQ0FBQztFQUM5QixNQUFNN0IsSUFBSSxDQUFDVyxRQUFRLENBQUVLLEdBQUcsSUFBS0MsWUFBWSxDQUFDeUYsT0FBTyxDQUFDMUYsR0FBRyxFQUFFLFNBQVMsQ0FBQyxFQUFFckIsWUFBWSxDQUFDO0VBQ2hGLE1BQU1LLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzdDLE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDb0gsR0FBRyxDQUFDQyxTQUFTLENBQUMsQ0FBQztFQUM1RDdILE1BQU0sQ0FBQyxNQUFNeUIsWUFBWSxDQUFDbkIsSUFBSSxDQUFDLENBQUMsQ0FBQ3FDLElBQUksQ0FBQyxTQUFTLENBQUM7RUFDaEQsTUFBTXJDLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzdDVixNQUFNLENBQUMsTUFBTXlCLFlBQVksQ0FBQ25CLElBQUksQ0FBQyxDQUFDLENBQUNxQyxJQUFJLENBQUMsU0FBUyxDQUFDO0VBQ2hEO0VBQ0EsTUFBTXJDLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMxQyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RSxNQUFNTCxJQUFJLENBQUNXLFFBQVEsQ0FBQyxNQUFNO0lBQ3hCNkcsT0FBTyxDQUFDQyxTQUFTLENBQUNmLE9BQU8sR0FBRyxNQUFNO01BQ2hDLE1BQU0sSUFBSWdCLFlBQVksQ0FBQyxPQUFPLEVBQUUsb0JBQW9CLENBQUM7SUFDdkQsQ0FBQztFQUNILENBQUMsQ0FBQztFQUNGLE1BQU0zSCxJQUFJLENBQUNDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQ0ksS0FBSyxDQUFDLENBQUM7RUFDNUIsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM0RCxhQUFhLENBQUMsU0FBUyxDQUFDO0VBQzNFLE1BQU14RCxZQUFZLENBQUNOLElBQUksQ0FBQztFQUN4QixNQUFNTixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQzRELGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQztBQUNuRixDQUFDLENBQUM7QUFFRnJFLElBQUksQ0FBQyw0RkFBNEYsRUFBRSxPQUFPO0VBQ3hHTztBQUNGLENBQUMsS0FBSztFQUNKLE1BQU1BLElBQUksQ0FBQzZCLElBQUksQ0FBQyxhQUFhLENBQUM7RUFDOUIsZUFBZThGLE1BQU1BLENBQUNDLEtBQWUsRUFBRUMsTUFBYyxFQUFFO0lBQ3JELE1BQU03SCxJQUFJLENBQUNXLFFBQVEsQ0FDakIsQ0FBQztNQUFFSyxHQUFHO01BQUU0RyxLQUFLO01BQUVDO0lBQU8sQ0FBQyxLQUNyQjVHLFlBQVksQ0FBQ3lGLE9BQU8sQ0FDbEIxRixHQUFHLEVBQ0g4RyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUNiQyxPQUFPLEVBQUUsQ0FBQztNQUNWcEgsSUFBSSxFQUFFLFNBQVM7TUFDZnFILElBQUksRUFBRSxPQUFPO01BQ2JDLFNBQVMsRUFBRSxDQUFDO01BQ1p6RixLQUFLLEVBQUU7UUFBRXVGLE9BQU8sRUFBRSxDQUFDO1FBQUVKLEtBQUs7UUFBRUM7TUFBTztJQUNyQyxDQUFDLENBQ0gsQ0FBQyxFQUNIO01BQUU3RyxHQUFHLEVBQUVyQixZQUFZO01BQUVpSSxLQUFLO01BQUVDO0lBQU8sQ0FDckMsQ0FBQztJQUNELE1BQU03SCxJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMvQztFQUNBLE1BQU0rSCxNQUFNLEdBQUdDLEtBQUssQ0FBUyxFQUFFLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUN4Q0YsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7RUFDYkEsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7RUFDYixNQUFNUixNQUFNLENBQUNRLE1BQU0sRUFBRSxDQUFDLENBQUM7RUFDdkIsTUFBTXpJLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDNEQsYUFBYSxDQUFDLE9BQU8sQ0FBQztFQUNuRSxNQUFNOUQsSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQzNDLE1BQU1WLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLE1BQU0sQ0FBQztFQUM5RCxNQUFNTixJQUFJLENBQUNDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQ0ksS0FBSyxDQUFDLENBQUM7RUFDM0IsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsU0FBUyxDQUFDO0VBQ2pFLE1BQU1YLE1BQU0sQ0FBQ00sSUFBSSxDQUFDRSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsZUFBZSxDQUFDO0VBQ3hFLE1BQU1zSCxNQUFNLENBQUNTLEtBQUssQ0FBUyxFQUFFLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztFQUMxQyxNQUFNM0ksTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDRyxVQUFVLENBQUMsU0FBUyxDQUFDO0VBQ2pFLE1BQU1zSCxNQUFNLENBQ1ZTLEtBQUssQ0FBQ0UsSUFBSSxDQUFDO0lBQUVDLE1BQU0sRUFBRTtFQUFHLENBQUMsRUFBRSxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBTUEsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBRSxDQUFDLEVBQ3RELENBQ0YsQ0FBQztFQUNELE1BQU0vSSxNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxRQUFRLENBQUM7RUFDaEUsTUFBTVgsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDd0ksVUFBVSxDQUFDLENBQUM7RUFDeERoSixNQUFNLENBQUMsTUFBTU0sSUFBSSxDQUFDRSxPQUFPLENBQUMsc0NBQXNDLENBQUMsQ0FBQ3lJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ3RHLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDcEYsQ0FBQyxDQUFDO0FBRUY1QyxJQUFJLENBQUMsdUZBQXVGLEVBQUUsT0FBTztFQUNuR087QUFDRixDQUFDLEtBQUs7RUFDSixNQUFNQSxJQUFJLENBQUM2QixJQUFJLENBQUMsYUFBYSxDQUFDO0VBQzlCLE1BQU03QixJQUFJLENBQUNFLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDMUMsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNHLFVBQVUsQ0FBQyxlQUFlLENBQUM7RUFDeEUsTUFBTUwsSUFBSSxDQUFDVyxRQUFRLENBQUVLLEdBQUcsSUFBS0MsWUFBWSxDQUFDeUYsT0FBTyxDQUFDMUYsR0FBRyxFQUFFLHNCQUFzQixDQUFDLEVBQUVyQixZQUFZLENBQUM7RUFDN0YsTUFBTUssSUFBSSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDN0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNvSCxHQUFHLENBQUNDLFNBQVMsQ0FBQyxDQUFDO0VBQzVELE1BQU12SCxJQUFJLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7RUFDM0MsTUFBTVYsTUFBTSxDQUFDTSxJQUFJLENBQUNFLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM0RCxhQUFhLENBQUMsU0FBUyxDQUFDO0VBQzNFcEUsTUFBTSxDQUFDLE1BQU15QixZQUFZLENBQUNuQixJQUFJLENBQUMsQ0FBQyxDQUFDcUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO0VBQzdELE1BQU0vQixZQUFZLENBQUNOLElBQUksQ0FBQztFQUN4QixNQUFNTixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQzRELGFBQWEsQ0FBQyxTQUFTLENBQUM7RUFDekVwRSxNQUFNLENBQUMsTUFBTXlCLFlBQVksQ0FBQ25CLElBQUksQ0FBQyxDQUFDLENBQUNxQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7RUFDN0QsTUFBTWxDLFdBQVcsQ0FBQ0gsSUFBSSxDQUFDO0VBQ3ZCLE1BQU1BLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUMxQyxNQUFNVixNQUFNLENBQUNNLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ0csVUFBVSxDQUFDLGVBQWUsQ0FBQztFQUN4RVgsTUFBTSxDQUFDb0ksSUFBSSxDQUFDYyxLQUFLLENBQUUsTUFBTXpILFlBQVksQ0FBQ25CLElBQUksQ0FBRyxDQUFDLENBQUNnSSxPQUFPLENBQUMsQ0FBQzNGLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakUsQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119