import { defineConfig } from '@playwright/test';
import { fileURLToPath } from 'node:url';

const htmlOnly = process.env.OTHELLO_HTML_ONLY === '1';
export default defineConfig({
  testDir: fileURLToPath(new URL('../../tests/e2e', import.meta.url)),
  testMatch: 'multi-game-shell.spec.ts',
  outputDir: fileURLToPath(
    new URL(htmlOnly ? './browser-results-html' : './browser-results-repair', import.meta.url),
  ),
  reporter: [
    ['list'],
    [
      'json',
      {
        outputFile: fileURLToPath(
          new URL(
            htmlOnly ? './browser-results-html.json' : './browser-results-repair.json',
            import.meta.url,
          ),
        ),
      },
    ],
  ],
  workers: 1,
  retries: 0,
  timeout: 45_000,
  expect: { timeout: 15_000 },
  use: {
    baseURL: 'http://127.0.0.1:4198/shell-check/',
    headless: true,
    browserName: 'chromium',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    launchOptions: {
      executablePath:
        '/workspaces/quoridor/artifacts/playwright/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell',
      args: htmlOnly
        ? ['--disable-gpu', '--disable-software-rasterizer']
        : ['--use-gl=angle', '--use-angle=swiftshader', '--enable-webgl'],
    },
  },
});
