# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: multi-game-shell.spec.ts >> new cross-game flow plays and saves both games, resumes legacy and Othello slots, preserves history and basepath
- Location: tests/e2e/multi-game-shell.spec.ts:26:1

# Error details

```
Test timeout of 45000ms exceeded.
```

```
Error: locator.click: Test timeout of 45000ms exceeded.
Call log:
  - waiting for locator('#choose-othello')

```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | 
  3   | const OTHELLO_SAVE = 'othello.game.v1';
  4   | const LEGACY_GAME = 'quoridor.m1.game.v1';
  5   | const LEGACY_SETTINGS = 'quoridor.m1.settings.v1';
  6   | const LEGACY_AUDIO = 'quoridor.audio.settings.v1';
  7   | const cell = (page: Page, index: number) => page.locator(`.othello-cell[data-index="${index}"]`);
  8   | const openOthello = async (page: Page) => {
> 9   |   await page.locator('#choose-othello').click();
      |                                         ^ Error: locator.click: Test timeout of 45000ms exceeded.
  10  |   await expect(page.locator('.othello h1')).toHaveText('Othello');
  11  | };
  12  | const leaveOthello = async (page: Page) => {
  13  |   await page.getByRole('link', { name: 'ゲーム一覧へ戻る' }).click();
  14  |   await expect(page.locator('.home-page')).toBeVisible();
  15  | };
  16  | async function legacySlots(page: Page) {
  17  |   return page.evaluate(
  18  |     ([game, settings, audio]) => [game, settings, audio].map((key) => localStorage.getItem(key!)),
  19  |     [LEGACY_GAME, LEGACY_SETTINGS, LEGACY_AUDIO],
  20  |   );
  21  | }
  22  | async function savedOthello(page: Page) {
  23  |   return page.evaluate((key) => localStorage.getItem(key), OTHELLO_SAVE);
  24  | }
  25  | 
  26  | test('new cross-game flow plays and saves both games, resumes legacy and Othello slots, preserves history and basepath', async ({
  27  |   page,
  28  | }) => {
  29  |   const requests: string[] = [],
  30  |     errors: string[] = [];
  31  |   page.on('request', (request) => requests.push(request.url()));
  32  |   page.on('pageerror', (error) => errors.push(error.message));
  33  |   await page.goto('./?forceWebGL=1#/');
  34  |   await expect(page.locator('#choose-othello')).toBeVisible();
  35  |   expect(
  36  |     requests.filter((url) => /\.wasm|ai\.worker|quoridor-|othello-|\.hdr|\.mp3|\.ogg/.test(url)),
  37  |   ).toEqual([]);
  38  |   await page.locator('#choose-quoridor').click();
  39  |   await expect
  40  |     .poll(() => page.evaluate(() => window.__QUORIDOR_DIAGNOSTICS__?.phase))
  41  |     .toBe('ready');
  42  |   await page.locator('#startup-new-game').click();
  43  |   await page.locator('#match-mode').selectOption('pvp');
  44  |   await page.locator('#dialog-start').click();
  45  |   await expect
  46  |     .poll(() => page.evaluate(() => window.__QUORIDOR_APP_TEST_API__?.state().phase))
  47  |     .toBe('humanTurn');
  48  |   const point = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.projectCell(13));
  49  |   await page.mouse.click(point.x, point.y);
  50  |   await expect
  51  |     .poll(() => page.evaluate(() => window.__QUORIDOR_APP_TEST_API__?.state().view?.ply))
  52  |     .toBe(1);
  53  |   const replay = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.exportReplay());
  54  |   await page.locator('.top-actions .home-link').click();
  55  |   await expect(page.locator('.home-page')).toBeVisible();
  56  |   const legacy = await legacySlots(page);
  57  |   expect(legacy[0]).toBeTruthy();
  58  |   await openOthello(page);
  59  |   await page.locator('#othello-new').click();
  60  |   await expect(page.locator('#othello-score')).toHaveText('黒 2 石 ／ 白 2 石');
  61  |   await cell(page, 19).click();
  62  |   await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  63  |   await expect(cell(page, 27)).toHaveAttribute('data-stone', '1');
  64  |   const othello = await savedOthello(page);
  65  |   await page.screenshot({ path: test.info().outputPath('othello-play.png') });
  66  |   await leaveOthello(page);
  67  |   expect(await legacySlots(page)).toEqual(legacy);
  68  |   await page.locator('#choose-quoridor').click();
  69  |   await expect
  70  |     .poll(() => page.evaluate(() => window.__QUORIDOR_DIAGNOSTICS__?.phase))
  71  |     .toBe('ready');
  72  |   await page.locator('#resume-game-choice').click();
  73  |   await expect
  74  |     .poll(() => page.evaluate(() => window.__QUORIDOR_APP_TEST_API__?.state().phase))
  75  |     .toBe('humanTurn');
  76  |   expect(await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.exportReplay())).toEqual(
  77  |     replay,
  78  |   );
  79  |   expect(await savedOthello(page)).toBe(othello);
  80  |   await page.locator('.top-actions .home-link').click();
  81  |   await openOthello(page);
  82  |   await page.locator('#othello-resume').click();
  83  |   await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  84  |   await expect(page.locator('#othello-players')).toContainText('ローカル2人');
  85  |   await page.goBack();
  86  |   await expect(page.locator('.home-page')).toBeVisible();
  87  |   await page.goForward();
  88  |   await page.locator('#othello-resume').click();
  89  |   await expect(page.locator('#othello-turn')).toHaveText('白の手番');
  90  |   await page.goto('./?forceWebGL=1#/othello');
  91  |   expect(new URL(page.url()).pathname).toBe(new URL(test.info().project.use.baseURL!).pathname);
  92  |   await page.locator('#othello-resume').click();
  93  |   await expect(page.locator('#othello-score')).toHaveText('黒 4 石 ／ 白 1 石');
  94  |   await expect(page.locator('canvas, dialog')).toHaveCount(0);
  95  |   expect(errors).toEqual([]);
  96  | });
  97  | 
  98  | test('Othello-only entry remains lazy on home, keyboard play and real bounded AI use explicit human colors', async ({
  99  |   page,
  100 | }) => {
  101 |   await page.setViewportSize({ width: 375, height: 812 });
  102 |   const workers: string[] = [];
  103 |   page.on('worker', (worker) => workers.push(worker.url()));
  104 |   await page.goto('./#/');
  105 |   await openOthello(page);
  106 |   expect(workers).toEqual([]);
  107 |   await page.locator('#othello-new').click();
  108 |   await expect(cell(page, 19)).toHaveAttribute('aria-disabled', 'false');
  109 |   await cell(page, 19).focus();
```