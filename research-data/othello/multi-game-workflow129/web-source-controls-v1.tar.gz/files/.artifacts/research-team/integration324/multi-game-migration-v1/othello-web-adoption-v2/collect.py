"""Apply frozen Web source and check its actual Main binding without browser replay."""

import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
WT = ROOT / ".worktree/othello-web129"
OWN = WT / ".artifacts/othello-web129"


def ref(p):
    b = p.read_bytes()
    return dict(
        sha256=hashlib.sha256(b).hexdigest(), bytes=len(b), mode=f"{p.stat().st_mode & 0o777:04o}"
    )


def run(name, args, env=None):
    p = subprocess.run(args, capture_output=True, text=True, timeout=180, check=False, env=env)
    (OUT / (name + ".log")).write_text(p.stdout + p.stderr)
    assert p.returncode == 0, (name, p.stderr[-2000:])
    return p.stdout


handoff = json.loads((OWN / "handoff.json").read_bytes())
evidence = json.loads((OWN / "evidence.json").read_bytes())
# v1 already applied14 files and passed Main TSC, then Vite refused the wrong
# default root before app source build. Reuse those successful stages.
for row in handoff["source_refs"]:
    assert ref(ROOT / row["path"]) == {k: row[k] for k in ("sha256", "bytes", "mode")}
assert (
    "Cannot resolve entry module index.html"
    in (OUT.with_name("othello-web-adoption-v1") / "actual-Main-bundle.log").read_text()
)
# Verify actual integration entry; unchanged worker functional/browser results stay pinned.
env = dict(os.environ, NODE_DISABLE_COMPILE_CACHE="1", APP_OUT_DIR=str(OUT / "web-dist"))
run(
    "actual-Main-bundle",
    [
        "node",
        "node_modules/vite/bin/vite.js",
        "build",
        "apps/web",
        "--config",
        "apps/web/vite.config.ts",
        "--configLoader",
        "native",
    ],
    env,
)
readme = ROOT / "README.md"
text = readme.read_text().replace("# Quoridor 3D web app", "# Quoridor / Othello web app", 1)
text = text.replace(
    "ローカルで2人対戦、または学習不要のRust B0 AIとの対戦ができます。",
    "一つのゲーム選択画面からQuoridorとOthelloを開けます。Quoridorはローカル2人、または学習不要のRust B0 AIと対戦できます。",
    1,
)
text = text.replace(
    "OthelloのRustルールとWasm接続は実装・単体検証済みですが、画面接続は後続工程のため現在のゲーム選択では利用できません。",
    "Othelloは `#/othello` からローカル2人、または簡易AI（非学習）と対戦できます。新規／続きからを選び、合法手の表示・必須パス・終局の石数を確認できます。Othelloの保存は独立した `othello.game.v1` で、Quoridorの保存・設定・音量データを変更しません。壊れた保存は勝手に削除せず、再開の再試行か明示した新規対局で扱います。",
)
readme.write_text(text)
design = ROOT / "docs/design/multi-game-repository.md"
text = (
    design.read_text()
    .replace(
        "現在は `#/` の選択画面から `#/quoridor` を遅延読込する。",
        "現在は `#/` の選択画面から `#/quoridor` と `#/othello` を選び、各ゲームを遅延読込する。",
    )
    .replace(
        "Othelloのルール・簡易AI（非学習）・Wasm APIは独立実装し、製品の単体検証を終えた。Web側は未接続のため選択画面では利用不可を表示し、画面と保存・起動終了は後続工程で適用する。",
        "Othelloのルール・簡易AI（非学習）・Wasm APIと画面を独立実装した。両ゲームは新規／保存再開とゲーム選択への復帰、個別保存、起動終了とAI取消を持つ。",
    )
)
design.write_text(text)
pretty = str(ROOT / "tools/research-quality/node_modules/.bin/prettier")
for mode in ("--write", "--check"):
    run(
        "Root-doc-" + mode,
        [
            pretty,
            "--config",
            "tools/research-quality/.prettierrc.json",
            mode,
            "README.md",
            "docs/design/multi-game-repository.md",
        ],
    )
run("diff-check", ["git", "diff", "--check"])
(OUT / "composition.json").write_text(
    json.dumps(
        dict(
            base="eb38a0010de1cd30aa0ea0dd583534ef65c4623e",
            handoff=handoff,
            evidence=evidence,
            Root_extra_docs=["README.md", "docs/design/multi-game-repository.md"],
            Main_checks=["actual-Main-typecheck", "actual-Main-bundle"],
            browser_replayed=False,
            qualification="Six broader pre-final-save-guard rendered flows have prior pinned source; final session-only guard delta covered by final22direct cases/new actual HTML corrupt-resume regression. No final7case rendered suite claim.",
            models_RAW_science=0,
        ),
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(dict(applied_source14=True, actual_Main_typecheck_bundle=True, browser_replay=False))
)
