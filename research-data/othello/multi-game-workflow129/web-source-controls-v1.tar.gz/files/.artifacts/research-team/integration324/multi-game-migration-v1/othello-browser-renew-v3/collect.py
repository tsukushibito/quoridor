"""Close the stopped failed browser attempt, then bind only its causal case repair."""

import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/othello-web129/.artifacts/othello-web129"
install = json.loads((BASE / "othello-browser-runtime-config-v1/installed.json").read_bytes())
process = json.loads((OWN / "browser-first/command.process.json").read_bytes())
cleanup = json.loads((OWN / "browser-helper-cleanup-first.json").read_bytes())
assert (
    process["remaining"] == []
    and process["direct_child_reaped"]
    and process["process_cleanup_complete"]
    and process["handle_closes_complete"]
)
assert process["status"] == "failed" and process["exit_code"] != 0
assert all(cleanup[k] for k in ("previewDirectWait", "previewExited", "testDirectWait"))
target = Path(install["path"])
body = target.read_bytes()
assert hashlib.sha256(body).hexdigest() == install["sha256"] and not target.is_symlink()
target.unlink()
assert not target.exists()
restored = dict(
    at=datetime.datetime.now(datetime.UTC).isoformat(),
    path=str(target),
    original_absence_restored=True,
    closed_lease="othello-browser-runtime-config-v1",
    actual_failed_process=process,
    actual_preview_test_cleanup=cleanup,
    success_claim=False,
    source_of_diagnosis="worker saved trace: global45s expired after two actual Quoridor mounts and successful Othello/legacy isolation; no route/rule failure evidenced",
)
(OUT / "previous-lease-restored.json").write_text(json.dumps(restored, indent=2) + "\n")
matching = []
denied = []
for proc in Path("/proc").iterdir():
    if not proc.name.isdigit():
        continue
    try:
        cmd = (proc / "cmdline").read_bytes()
        if cmd.split(b"\0", 1)[0].startswith(str(target.parent).encode()):
            matching.append(int(proc.name))
    except PermissionError:
        denied.append(int(proc.name))
    except (FileNotFoundError, ProcessLookupError):
        pass
assert not matching
with target.open("xb") as f:
    f.write(body)
target.chmod(0o644)
new = dict(
    at=datetime.datetime.now(datetime.UTC).isoformat(),
    path=str(target),
    sha256=hashlib.sha256(body).hexdigest(),
    bytes=len(body),
    mode="0644",
    original="ABSENT",
    CPU=12,
    threads=1,
    previous_original_absence_actually_restored=True,
    named_browser_snapshot=matching,
    denied_unknown=denied,
    scope="only repaired new cross-game flow case; test-only120s budget, unchanged execute600s/CPU12/G18/F2GiB/host4/G0, no five accepted case replay",
    no_allhost_quiet=True,
)
(OUT / "installed.json").write_text(json.dumps(new, indent=2) + "\n")
message = OUT / "message.md"
message.write_text(
    "Root actually restored original absence after your first failed-browser/normalcollection wholeSTOP, recording previous-lease-restored.json; then installed this NEW temporary lease for ONLY repaired new cross-game flow (--grep), not five accepted tests. FileRef "
    + json.dumps({k: new[k] for k in ("path", "sha256", "bytes", "mode")})
    + ". Same ThreadCount1/AffinityMask4096/any; same CPU12/G18/F2GiB/host4/G0, test-only120s limit is distinct from600s safety deadline. Keep exact config immutable; no extra flags/affinity/cap changes or oldcase replay. Immediately report actual browser+normalcollection wholeSTOP, then no further config/browser read so Root restores absence. Preserve first assertion failure/trace unchanged. Root may independently prepare Quoridor static asset path separation under a second disjoint WT; your active WT stays at its bound old asset paths for this case, no source reset/rebase/Quoridor asset edits. Continue same task causal repair/normal work without ACK gate."
)
p = subprocess.run(
    [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a15f23-0746-7953-a08b-9927d23d26f7",
        "--issue",
        "quoridor-4lc.324.12.9.7",
        "--cwd",
        "/workspaces/quoridor/.worktree/othello-web129",
        "--body-file",
        str(message),
    ],
    capture_output=True,
    text=True,
    timeout=90,
    check=False,
)
(OUT / "delivery.json").write_text(p.stdout)
(OUT / "delivery.stderr").write_text(p.stderr)
assert p.returncode == 0, p.stderr
print(
    json.dumps(
        dict(previous_restored=True, new_case_lease_installed=True, delivery=json.loads(p.stdout))
    )
)
