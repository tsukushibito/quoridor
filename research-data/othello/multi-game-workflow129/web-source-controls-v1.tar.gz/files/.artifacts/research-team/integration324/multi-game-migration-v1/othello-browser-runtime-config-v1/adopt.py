"""Bind the proven SwiftShader config read to the assigned temporary browser scope."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BROWSER = ROOT / "artifacts/playwright/chromium_headless_shell-1243/chrome-headless-shell-linux64"
TARGET = BROWSER / "SwiftShader.ini"
WORKER = ROOT / ".worktree/othello-web129"


def main():
    assert not TARGET.exists()
    matching, denied = [], []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit():
            continue
        try:
            data = (proc / "cmdline").read_bytes()
            if data.split(b"\0", 1)[0].startswith(str(BROWSER).encode()):
                matching.append(int(proc.name))
        except PermissionError:
            denied.append(int(proc.name))
        except (FileNotFoundError, ProcessLookupError):
            pass
    assert not matching, matching
    body = b"[Processor]\nThreadCount=1\nAffinityMask=4096\nAffinityPolicy=any\n"
    with TARGET.open("xb") as stream:
        stream.write(body)
    TARGET.chmod(0o644)
    assert TARGET.read_bytes() == body
    result = dict(
        at=datetime.now(timezone.utc).isoformat(),
        path=str(TARGET),
        original="ABSENT",
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode="0644",
        scope="Temporary existing headless-browser SwiftShader settings, assigned CPU12/thread1 "
        "only for12.9.7 actual browser lifetime. Restore original absence after actual "
        "browser and collection STOP. No permanent runtime override.",
        named_current_browser_processes=matching,
        denied_process_reads=denied,
        no_all_host_quiet_claim=True,
        no_CPU_RAM_G0_guard_relaxation=True,
        causal_trace="Prior accepted causal trace preserved in research-data/ai-sigma/multi-game-workflow129/web-shell source-controls; current runtime configuration reused for new game flow",
        upstream_runtime_configuration="https://swiftshader.googlesource.com/SwiftShader/+/master/docs/RuntimeConfiguration.md",
    )
    (OUT / "installed.json").write_text(json.dumps(result, indent=2) + "\n")
    message = OUT / "supplied.txt"
    message.write_text(
        "Root installed the previously proven TEMPORARY SwiftShader config at the installed browser directory; original ABSENT. ThreadCount1/AffinityMask4096/any, unchanged CPU12/G18/F2GiB/host4/G0. Exact FileRef: "
        + json.dumps({k: result[k] for k in ["path", "sha256", "bytes", "mode"]})
        + ". Named current browser path snapshot empty; access-denied UNKNOWN, no allhost quiet claim. No executable/library/model or guard/cap/affinity relaxation. Use for NEW cross-game product flow/save isolation, Othello lifecycle/AI Worker cancellation and history/basepath. Do not replay old accepted cases solely for historical proof or run Quoridor AI science; local2player for Quoridor. Keep this shared config immutable until browser plus normal collection actually returned, then send WHOLESTOP immediately before report/admin; Root restores original absence. No later browser/config reads after that STOP. Retain any assertion/environment failures and repair same task, no blind flags/config retries. Continue independent work without reply/ACK gate.\n"
    )

    delivery = subprocess.run(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a15f23-0746-7953-a08b-9927d23d26f7",
            "--issue",
            "quoridor-4lc.324.12.9.7",
            "--cwd",
            str(WORKER),
            "--body-file",
            str(message),
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=90,
    )
    (OUT / "delivery.stdout").write_text(delivery.stdout)
    (OUT / "delivery.stderr").write_text(delivery.stderr)
    assert delivery.returncode == 0, delivery.stdout + delivery.stderr
    print(json.dumps(dict(installed=result, delivery=json.loads(delivery.stdout))))


if __name__ == "__main__":
    main()
