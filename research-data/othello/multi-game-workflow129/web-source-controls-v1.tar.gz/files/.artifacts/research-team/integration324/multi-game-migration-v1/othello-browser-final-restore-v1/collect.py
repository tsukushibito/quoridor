"""Restore original browser configuration at the repaired actual whole-STOP boundary."""

import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/othello-web129/.artifacts/othello-web129"
install = json.loads((BASE / "othello-browser-renew-v3/installed.json").read_bytes())
records = []
for name in ("browser-repair", "normal-collection"):
    p = OWN / name / "command.process.json"
    r = json.loads(p.read_bytes())
    assert r["status"] == "complete" and r["exit_code"] == 0
    assert (
        r["remaining"] == []
        and r["direct_child_reaped"]
        and r["process_cleanup_complete"]
        and r["handle_closes_complete"]
    )
    records.append(dict(path=str(p), process=r))
target = Path(install["path"])
assert install["original"] == "ABSENT" and target.is_file() and not target.is_symlink()
raw = target.read_bytes()
assert hashlib.sha256(raw).hexdigest() == install["sha256"] and len(raw) == install["bytes"]
target.unlink()
assert not target.exists()
(OUT / "result.json").write_text(
    json.dumps(
        dict(
            at=datetime.datetime.now(datetime.UTC).isoformat(),
            original_absence_restored=True,
            path=str(target),
            removed_exact_sha=install["sha256"],
            actual_owned_browser_normal_collection=records,
            source_of_wholeSTOP="original worker12.9.7 reported returned preview/test/collector, no further browser/config reads; source14/productinput12 bound in worker evidence.json",
            prior5PASS_and_first_timeout_retained=True,
            repaired_new_cross_game_case_PASS=True,
            scientific_claim=False,
            no_future_hostquiet=True,
        ),
        indent=2,
    )
    + "\n"
)
print(json.dumps(dict(original_absence_restored=True, browser_and_collector_returned=True)))
