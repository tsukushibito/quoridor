"""Preserve late receipts and normally retire two accepted product-boundary tasks."""

import asyncio
import datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
THREAD = ""


def run(args):
    p = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, timeout=180, check=False)
    (OUT / "commands.log").open("a").write(
        json.dumps(
            dict(argv=args, code=p.returncode, stdout=p.stdout[-6000:], stderr=p.stderr[-2000:])
        )
        + "\n"
    )
    assert p.returncode == 0, (args, p.stderr[-1000:])
    return p.stdout


async def session_boundary(archive=False):
    spec = importlib.util.spec_from_file_location(
        "session", ROOT / "scripts/dev/research-session.py"
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    async with mod.AppServer(
        json.loads(run(["codex", "app-server", "daemon", "version"]))
    ) as server:
        latest = (await server.turns(THREAD, limit=1))[0]
        current = await server.read_thread(THREAD)
        assert latest["status"] == "completed" and latest.get("error") is None
        assert current["status"]["type"] in ["idle", "notLoaded"]
        result = dict(turn=latest["id"], status=latest["status"], thread_status=current["status"])
        if archive:
            with mod.dispatch_lock(ROOT):
                assert (await server.read_thread(THREAD))["status"]["type"] in ["idle", "notLoaded"]
                result["actual_archive_response"] = await server.request(
                    "thread/archive", {"threadId": THREAD}
                )
        return result


def main():
    global THREAD
    assert not run(["git", "status", "--porcelain=v1"])
    tasks = [
        dict(
            leaf="5",
            name="quoridor-tests-docs129",
            own="quoridor-test-doc129",
            thread="01a15f01-fe83-7c11-8a55-35cd2764abd8",
            pub="research-data/ai-sigma/multi-game-workflow129",
            acceptance="quoridor-test-doc-acceptance-v1.json",
            prefix="quoridor-test-doc",
            commit="68100f946a9c368be2490d04fd9a8e97f520a520",
        ),
        dict(
            leaf="6",
            name="othello-rules129",
            own="othello-rules129",
            thread="01a15f02-3229-7ba3-be7a-8d20079a6212",
            pub="research-data/othello/multi-game-workflow129",
            acceptance="rules-acceptance-v1.json",
            prefix="rules",
            commit="872068c52349acc1a7fa340912ad2a552867f39b",
        ),
    ]
    published = []
    reports = []
    for task in tasks:
        THREAD = task["thread"]
        issueid = "quoridor-4lc.324.12.9." + task["leaf"]
        issue = json.loads(run(["bash", "scripts/dev/beads.sh", "show", issueid, "--json"]))[0]
        assert issue["status"] == "closed" and issue["assignee"] == "codex:" + THREAD
        assignments = json.loads(
            run(
                [
                    "bash",
                    "scripts/dev/beads.sh",
                    "list",
                    "--all",
                    "--assignee",
                    "codex:" + THREAD,
                    "--brief",
                    "--flat",
                    "--limit",
                    "64",
                    "--max-rows",
                    "64",
                    "--json",
                ]
            )
        )
        assert len(assignments) < 64 and all(r["status"] == "closed" for r in assignments)
        before = asyncio.run(session_boundary())
        wt = ROOT / ".worktree" / task["name"]
        own = wt / ".artifacts" / task["own"]
        pub = ROOT / task["pub"]
        accepted = json.loads((pub / task["acceptance"]).read_bytes())

        def git(*args):
            return run(["git", "-C", str(wt), *args])

        # Known exact helpers only: no global process/reader census.
        observed = []
        for p in sorted(own.glob("*.process.json")):
            data = json.loads(p.read_bytes())
            assert (
                data.get("remaining") == []
                and data.get("direct_child_reaped")
                and data.get("process_cleanup_complete")
                and data.get("handle_closes_complete")
            ), p.name
            identity = "not supplied"
            child = data.get("child", {})
            if child.get("pid") and child.get("start_ticks"):
                try:
                    ticks = (
                        (Path("/proc") / str(child["pid"]) / "stat")
                        .read_text()
                        .rsplit(")", 1)[1]
                        .split()[19]
                    )
                    assert ticks != str(child["start_ticks"])
                    identity = "different start"
                except FileNotFoundError:
                    identity = "absent"
            observed.append(
                dict(
                    name=p.name,
                    status=data.get("status"),
                    exit_code=data.get("exit_code"),
                    signal_disk=data.get("signal_mask_restoration"),
                    exact_child=identity,
                )
            )
        prior = {r["original"]["path"]: r for r in accepted["members"]}
        archive = pub / (task["prefix"] + "-final-control-tail-v1.tar.gz")
        assert not archive.exists()
        rows = []
        reused = []
        with tarfile.open(archive, "w:gz") as stream:
            for p in sorted(own.rglob("*")):
                assert not p.is_symlink()
                if not p.is_file():
                    continue
                body = p.read_bytes()
                sha = hashlib.sha256(body).hexdigest()
                mode = f"{p.stat().st_mode & 0o777:04o}"
                old = prior.get(str(p.relative_to(ROOT)))
                if old and (
                    old["original"]["bytes"],
                    old["original"]["sha256"],
                    old["original"]["mode"],
                ) == (len(body), sha, mode):
                    reused.append(old)
                    continue
                info = tarfile.TarInfo("worker/" + str(p.relative_to(own)))
                info.size = len(body)
                info.mode = int(mode, 8)
                stream.addfile(info, io.BytesIO(body))
                rows.append(
                    dict(original=str(p), member=info.name, bytes=len(body), sha256=sha, mode=mode)
                )
        expected = {r["member"]: r for r in rows}
        with tarfile.open(archive, "r|gz") as stream:
            for entry in stream:
                r = expected.pop(entry.name)
                body = stream.extractfile(entry).read()
                assert (len(body), hashlib.sha256(body).hexdigest(), f"{entry.mode:04o}") == (
                    r["bytes"],
                    r["sha256"],
                    r["mode"],
                )
        assert not expected
        if task["leaf"] == "5":
            mapping = accepted["source_mapping"]["files"]
            names = {r[k] for r in mapping for k in ("old", "new")}
        else:
            names = {r["path"] for r in accepted["worker_source_manifest"]["source_files"]}
        assert not git("diff", "--cached", "--name-only")
        dirty = {
            r[3:] for r in git("status", "--porcelain=v1", "--untracked-files=all").splitlines()
        }
        assert dirty == names, (dirty - names, names - dirty)
        provided = []
        if task["leaf"] == "5":
            provided = json.loads(
                (BASE / "game-boundaries-entry-v1/test-doc-product-inputs.json").read_bytes()
            )
        provided_paths = {str(Path(r["destination"]).relative_to(wt)) for r in provided}
        ignored = [
            p
            for p in git("ls-files", "--others", "--ignored", "--exclude-standard", "-z").split(
                "\0"
            )
            if p
        ]
        assert all(
            p.startswith(".artifacts/" + task["own"] + "/")
            or p.startswith(".ruff_cache/")
            or p in provided_paths
            or p == "node_modules"
            for p in ignored
        ), ignored[:12]
        tracked = {
            r.split("\t", 1)[1]
            for r in git("ls-files", "--stage", "--", *sorted(names)).splitlines()
        }
        flags = {r[0] for r in git("ls-files", "-v").splitlines()}
        assert flags <= {"H", "S"}
        gd = Path(git("rev-parse", "--absolute-git-dir").strip())
        config = {n: (gd / n).read_text() for n in ("config.worktree", "info/sparse-checkout")}
        if tracked:
            git("restore", "--source=HEAD", "--worktree", "--", *sorted(tracked))
        for name in names - tracked:
            (wt / name).unlink()
        for p in provided_paths:
            (wt / p).unlink()
        link = wt / "node_modules"
        if link.exists():
            assert link.is_symlink()
            link.unlink()
        for p in (own, wt / ".ruff_cache"):
            if p.exists():
                assert not p.is_symlink()
                shutil.rmtree(p)
        # Only remove now-empty task-owned parent directories; no shared traversal.
        parents = {
            par
            for name in (names - tracked) | provided_paths
            for par in (wt / name).parents
            if par.is_relative_to(wt) and par != wt
        }
        parents.add(wt / ".artifacts")
        for p in sorted(parents, key=lambda p: len(p.parts), reverse=True):
            if p.is_dir() and not list(p.iterdir()):
                p.rmdir()
        assert not git("status", "--porcelain=v1", "--untracked-files=all", "--ignored")
        branch = run(["git", "rev-parse", "refs/heads/codex/" + task["name"]]).strip()
        removal = run(["bash", "scripts/dev/manage_worktree.sh", "remove", task["name"]])
        assert not wt.exists()
        assert run(["git", "rev-parse", "refs/heads/codex/" + task["name"]]).strip() == branch
        after = asyncio.run(session_boundary(archive=True))
        report = pub / (task["prefix"] + "-task-normal-retirement-v1.json")
        report.write_text(
            json.dumps(
                dict(
                    at=datetime.datetime.now(datetime.UTC).isoformat(),
                    issue=issueid,
                    source_acceptance=task["commit"],
                    same_owner_closed=dict(
                        status=issue["status"],
                        assignee=issue["assignee"],
                        close_reason=issue["close_reason"],
                    ),
                    session_before=before,
                    session_after=after,
                    normal_remove=removal,
                    branch_preserved=branch,
                    config_sparse_preserved=config,
                    index_flags=sorted(flags),
                    late_control_archive=str(archive.relative_to(ROOT)),
                    new_members=rows,
                    reused_original_archive_members=reused,
                    new_tail_one_stream="PASS exact bytes/SHA/modes/names without extraction",
                    worker_actual_process_cleanup=observed,
                    signal_facts="Original pending disk records immutable; available actual returned admin restoration kept in late archive separately. No blanket restoration or allhost quiet claim.",
                    generated_verification_input_recipes=provided,
                    Root_affected_point="test-doc-publication-v1/affected-point.json or othello-publication-v1/affected-once.json already observed once; no repeated point, late tail/globalactual/fullfees UNKNOWN",
                    USERPAUSE_assets_DB_seals_models_defaults_preserved=True,
                    scientific_calls=0,
                    whole_parent_complete=False,
                ),
                indent=2,
            )
            + "\n"
        )
        published.extend([str(archive.relative_to(ROOT)), str(report.relative_to(ROOT))])
        reports.append(
            dict(
                issue=issueid,
                new_members=len(rows),
                reused=len(reused),
                removed=True,
                archived=True,
            )
        )
    pretty = str(ROOT / "tools/research-quality/node_modules/.bin/prettier")
    jsonpaths = [p for p in published if p.endswith(".json")]
    for mode in ("--write", "--check"):
        run([pretty, "--config", "tools/research-quality/.prettierrc.json", mode, *jsonpaths])
    run(["git", "diff", "--check"])
    run(["git", "add", "--", *published])
    run(["git", "commit", "-m", "Preserve late receipts and retire completed game boundary tasks"])
    commit = run(["git", "rev-parse", "HEAD"]).strip()
    run(["git", "push", "origin", "HEAD:main"])
    assert run(["git", "ls-remote", "origin", "refs/heads/main"]).split()[0] == commit
    assert not run(["git", "status", "--porcelain=v1"])
    (OUT / "published.json").write_text(
        json.dumps(dict(commit=commit, clean=True, remote=commit, tasks=reports), indent=2) + "\n"
    )
    run(
        [
            "bash",
            "scripts/dev/beads.sh",
            "update",
            "quoridor-4lc.324.12.9",
            "--append-notes",
            "Completed normal retirement/publication "
            + commit
            + " for closed original12.9.5/.6: actual completed/idle contexts, known helper/directreap/handles, late receipts preserved with one new-tail stream and oldmember correspondence, normal managed removal and branch retention, actual sessionarchive. Existing affected points not rewalked.12.9.7 actual first useful source read and first app/home/navigation edit reported by original01a15f23-0746-7953-a08b-9927d23d26f7 under fixed7bec1e9f/CPU12/G18; source uses own Othello/Quoridor bridges, no new common edits or science. Parent migration remainsin_progress; no overall start notice repeated.",
        ]
    )
    run(["bash", "scripts/dev/beads.sh", "backup", "sync"])
    print(json.dumps(dict(commit=commit, retired=reports)))


if __name__ == "__main__":
    main()
