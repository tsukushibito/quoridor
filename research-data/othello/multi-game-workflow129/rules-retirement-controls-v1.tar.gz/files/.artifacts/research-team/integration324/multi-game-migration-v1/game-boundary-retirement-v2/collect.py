"""Resume only the uncompleted normal cleanup after the exact empty-cache cause."""

import asyncio
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
THREAD = "01a15f02-3229-7ba3-be7a-8d20079a6212"


def run(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=180, check=False)
    (OUT / "commands.log").open("a").write(
        json.dumps(
            dict(argv=args, code=p.returncode, stdout=p.stdout[-6000:], stderr=p.stderr[-2000:])
        )
        + "\n"
    )
    assert p.returncode == 0, (args, p.stderr[-1000:])
    return p.stdout


async def session_boundary(archive=False):
    spec = importlib.util.spec_from_file_location(
        "session", ROOT / "scripts/dev/research-session.py"
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    async with mod.AppServer(
        json.loads(run(["codex", "app-server", "daemon", "version"]))
    ) as server:
        latest = (await server.turns(THREAD, limit=1))[0]
        current = await server.read_thread(THREAD)
        assert latest["status"] == "completed" and latest.get("error") is None
        assert current["status"]["type"] in ["idle", "notLoaded"]
        result = dict(turn=latest["id"], status=latest["status"], thread_status=current["status"])
        if archive:
            with mod.dispatch_lock(ROOT):
                assert (await server.read_thread(THREAD))["status"]["type"] in ["idle", "notLoaded"]
                result["actual_archive_response"] = await server.request(
                    "thread/archive", {"threadId": THREAD}
                )
        return result


wt = ROOT / ".worktree/othello-rules129"
own = wt / ".artifacts/othello-rules129"
pub = ROOT / "research-data/othello/multi-game-workflow129"
archive = pub / "rules-final-control-tail-v1.tar.gz"
failed = (BASE / "game-boundary-retirement-v1/execution.log").read_text()
assert "assert link.is_symlink()" in failed
assert archive.exists()
# v1 reconstructed this exact archive successfully before its later link assertion.
# Current source writer stayed stopped; no archive decompression/restore replay.
accepted = json.loads((pub / "rules-acceptance-v1.json").read_bytes())
prior = {r["original"]["path"]: r for r in accepted["members"]}
rows = []
reused = []
for p in sorted(own.rglob("*")):
    assert not p.is_symlink()
    if not p.is_file():
        continue
    b = p.read_bytes()
    sha = hashlib.sha256(b).hexdigest()
    mode = f"{p.stat().st_mode & 0o777:04o}"
    old = prior.get(str(p.relative_to(ROOT)))
    if old and (old["original"]["bytes"], old["original"]["sha256"], old["original"]["mode"]) == (
        len(b),
        sha,
        mode,
    ):
        reused.append(old)
    else:
        rows.append(
            dict(
                original=str(p),
                member="worker/" + str(p.relative_to(own)),
                bytes=len(b),
                sha256=sha,
                mode=mode,
            )
        )
before = asyncio.run(session_boundary())
issue = json.loads(
    run(["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.324.12.9.6", "--json"])
)[0]
assert issue["status"] == "closed" and issue["assignee"] == "codex:" + THREAD
assert not run(["git", "-C", str(wt), "diff", "--cached", "--name-only"])
assert not run(["git", "-C", str(wt), "status", "--porcelain=v1", "--untracked-files=all"])
flags = {r[0] for r in run(["git", "-C", str(wt), "ls-files", "-v"]).splitlines()}
assert flags <= {"H", "S"}
gd = Path(run(["git", "-C", str(wt), "rev-parse", "--absolute-git-dir"]).strip())
config = {n: (gd / n).read_text() for n in ("config.worktree", "info/sparse-checkout")}
# Exactly two empty generated Prettier-cache directories, no package/source files.
for p in (wt / "node_modules/.cache/prettier", wt / "node_modules/.cache", wt / "node_modules"):
    assert p.is_dir() and not p.is_symlink() and not list(p.iterdir())
    p.rmdir()
shutil.rmtree(own)
art = wt / ".artifacts"
if art.exists():
    assert not list(art.iterdir())
    art.rmdir()
# Source already cleaned in v1 after preserved Main/worker mapping; do not replay it.
assert not run(
    ["git", "-C", str(wt), "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]
)
branch = run(["git", "rev-parse", "refs/heads/codex/othello-rules129"]).strip()
removal = run(["bash", "scripts/dev/manage_worktree.sh", "remove", "othello-rules129"])
assert (
    not wt.exists()
    and run(["git", "rev-parse", "refs/heads/codex/othello-rules129"]).strip() == branch
)
after = asyncio.run(session_boundary(archive=True))
report = pub / "rules-task-normal-retirement-v1.json"
report.write_text(
    json.dumps(
        dict(
            at=datetime.datetime.now(datetime.UTC).isoformat(),
            issue=issue["id"],
            source_acceptance="872068c52349acc1a7fa340912ad2a552867f39b",
            same_owner_closed=dict(
                status=issue["status"],
                assignee=issue["assignee"],
                close_reason=issue["close_reason"],
            ),
            session_before=before,
            session_after=after,
            normal_remove=removal,
            branch_preserved=branch,
            config_sparse_preserved=config,
            index_flags=sorted(flags),
            late_control_archive=str(archive.relative_to(ROOT)),
            new_members=rows,
            reused_original_archive_members=reused,
            one_stream_restore="PASS in v1 before later empty-cache type assertion; v2 reuses exact stopped archive without decompression/reconstruction replay",
            Root_failure_retained="v1 normally retired completed12.9.5 once then preserved/reconstructed12.9.6 tail; its later symlink assertion found node_modules/.cache/prettier two empty dirs, not dependency packages. v2 removed only exact empty dirs and continued unentered remove/archive. v1 FAILED is unchanged.",
            original_pending_disk_signal_facts="preserved; actual returned object absent for worker admin, no fabricated restoration observation",
            affected_point="othello-publication-v1/affected-once.json reused; no second point; late tails/globalactual/fullfees UNKNOWN/no refund",
            scientific_calls=0,
            pauses_models_assets_defaults_seals_unchanged=True,
            whole_parent_complete=False,
        ),
        indent=2,
    )
    + "\n"
)
paths = [
    "research-data/ai-sigma/multi-game-workflow129/quoridor-test-doc-final-control-tail-v1.tar.gz",
    "research-data/ai-sigma/multi-game-workflow129/quoridor-test-doc-task-normal-retirement-v1.json",
    str(archive.relative_to(ROOT)),
    str(report.relative_to(ROOT)),
]
pretty = str(ROOT / "tools/research-quality/node_modules/.bin/prettier")
for mode in ("--write", "--check"):
    run(
        [
            pretty,
            "--config",
            "tools/research-quality/.prettierrc.json",
            mode,
            *[p for p in paths if p.endswith(".json")],
        ]
    )
run(["git", "diff", "--check"])
run(["git", "add", "--", *paths])
run(["git", "commit", "-m", "Preserve final receipts and retire completed game boundary tasks"])
commit = run(["git", "rev-parse", "HEAD"]).strip()
run(["git", "push", "origin", "HEAD:main"])
assert run(["git", "ls-remote", "origin", "refs/heads/main"]).split()[0] == commit
assert not run(["git", "status", "--porcelain=v1"])
(OUT / "published.json").write_text(
    json.dumps(
        dict(
            commit=commit,
            remote=commit,
            clean=True,
            retired=["quoridor-tests-docs129", "othello-rules129"],
            archived_threads=["01a15f01-fe83-7c11-8a55-35cd2764abd8", THREAD],
            success_replay=False,
        ),
        indent=2,
    )
    + "\n"
)
run(
    [
        "bash",
        "scripts/dev/beads.sh",
        "update",
        "quoridor-4lc.324.12.9",
        "--append-notes",
        "Actual normal retirement/push "
        + commit
        + " for accepted closed12.9.5/.6; late tails preserved/reconstructed once with prior member custody, task sessions completed/idle and archived, registered checkouts removed normally/branches retained. Original v1 partial cleanup FAILED on exact empty Prettier cache directory type; v2 only unentered cleanup/remove/archive/publication, no successful replay. Original signal facts/permission-order limitations preserved.12.9.7 actual first useful read and first apps/app/navigation/home source edit reported under fixed7bec1e9f/CPU12/G18, one active implementation context; full migration remainsin_progress.",
    ]
)
run(["bash", "scripts/dev/beads.sh", "backup", "sync"])
print(
    json.dumps(
        dict(
            commit=commit,
            normal_retirement_complete=True,
            new_tail_members=len(rows),
            reused=len(reused),
        )
    )
)
