"""One authorized administrative close after Root technical acceptance."""

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor/.worktree/othello-rules129")
OWN = ROOT / ".artifacts/othello-rules129"
ISSUE = "quoridor-4lc.324.12.9.6"
ASSIGNEE = "codex:01a15f02-3229-7ba3-be7a-8d20079a6212"
REASON = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/multi-game-migration-v1/othello-close-dispatch-v1/exact-close-reason.txt"
)
reason_bytes = REASON.read_bytes()
reason = reason_bytes.decode("utf-8")
assert (
    hashlib.sha256(reason_bytes).hexdigest()
    == "3203f7b7e51833273d84bafbfc06187cddc1270361d5127e9edf9ffa7c706901"
)


def beads(label, *args):
    result = subprocess.run(
        ["bash", "scripts/dev/beads.sh", *args],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=True,
        timeout=30,
    )
    (OWN / (label + ".txt")).write_text(result.stdout + result.stderr)
    return result.stdout


before = json.loads(beads("admin-before", "show", ISSUE, "--json"))[0]
assert before["status"] == "in_progress" and before["assignee"] == ASSIGNEE
note = "ADMIN ONLY: Root technical acceptance/push872068c52349acc1a7fa340912ad2a552867f39b completed. Canonical evidence research-data/othello/multi-game-workflow129/rules-acceptance-v1.json. Saved current turn gpt-6.1-sol/high/exact managed cwd/danger-full-access/approval never verified before ordinary admin commands; original CPU plan descriptor unchanged. Closing this own issue once using exact UTF8 reason from Root dispatch (882B, SHA256 3203f7b7e51833273d84bafbfc06187cddc1270361d5127e9edf9ffa7c706901), preserving original assignee. Original pending signal disk records and failures remain intact. No source/test/Cargo/archive replay or other issue status changes. Source STOP retained; Root keeps tail custody/removal/sessionarchive after actual final-turn exit. Backup before and after closure and exact CLOSED/assignee/reason verification are part of this admin operation."
beads("admin-note", "update", ISSUE, "--append-notes", note)
beads("admin-backup-before", "backup", "sync")
beads("admin-close-once", "close", ISSUE, "--reason", reason)
closed = json.loads(beads("admin-show-closed", "show", ISSUE, "--json"))[0]
assert closed["status"] == "closed"
assert closed["assignee"] == ASSIGNEE
assert closed["close_reason"].encode("utf-8") == reason_bytes
beads("admin-backup-after", "backup", "sync")
verification = dict(
    issue=ISSUE,
    status=closed["status"],
    original_assignee=ASSIGNEE,
    actual_assignee=closed["assignee"],
    exact_reason_utf8=True,
    reason_bytes=len(reason_bytes),
    reason_sha256=hashlib.sha256(reason_bytes).hexdigest(),
    backup_before=True,
    backup_after=True,
    normal_close_calls=1,
    source_stop=True,
)
(OWN / "admin-close-verification.json").write_text(json.dumps(verification, indent=2) + "\n")
print(json.dumps(verification))
