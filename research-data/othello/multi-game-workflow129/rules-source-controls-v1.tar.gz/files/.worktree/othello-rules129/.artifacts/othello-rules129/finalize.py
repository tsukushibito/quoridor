"""Freeze task evidence and measure only the affected paths once."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat

ROOT = Path("/workspaces/quoridor/.worktree/othello-rules129")
OWN = ROOT / ".artifacts/othello-rules129"


def descriptor(path):
    data = path.read_bytes()
    return dict(
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=format(stat.S_IMODE(path.stat().st_mode), "04o"),
    )


references = json.loads((OWN / "common-caller-references.json").read_text())
for name, reference in references.items():
    actual = descriptor(ROOT / name)
    assert actual == dict(
        sha256=reference["before_sha256"],
        bytes=reference["before_bytes"],
        mode=reference["before_mode"],
    )
records = []
for path in OWN.glob("*.process.json"):
    record = json.loads(path.read_text())
    if record.get("child", {}).get("pid") == os.getpid():
        continue  # The current evidence writer is still running, not a completed check.
    assert record["status"] in {"complete", "failed"}
    if record["status"] == "failed":
        assert path.name == "finalmanifest.process.json" and record["exit_code"] == 1
    assert record["remaining"] == [] and record["direct_child_reaped"]
    assert record["cleanup_complete"] and record["handle_closes_complete"]
    assert record["finalization_errors"] == []
    records.append(dict(path=path.name, status=record["status"], exit_code=record["exit_code"]))
head = Path("/workspaces/quoridor/.git/worktrees/othello-rules129/HEAD").read_text().strip()
ref = head.removeprefix("ref: ")
base = (
    (Path("/workspaces/quoridor/.git") / ref).read_text().strip()
    if head.startswith("ref: ")
    else head
)
assert base.startswith("2dfe353c")
paths = sorted(path for path in (ROOT / "games/othello").rglob("*") if path.is_file())
assert len(paths) == 10
manifest = dict(
    source_stop_utc=datetime.now(timezone.utc).isoformat(),
    base=base,
    source_files=[
        dict(path=str(path.relative_to(ROOT)), before="ABSENT", after=descriptor(path))
        for path in paths
    ],
    common_callers_unchanged=True,
    common_proposal=descriptor(OWN / "common-caller-proposal.patch"),
    protected_after_only={
        name: descriptor(ROOT / name)
        for name in ["Cargo.lock", "package.json", "package-lock.json"]
    },
    rust_unit_definitions=11,
    rust_compile_tests="UNRUN",
    real_wasm="UNRUN",
    prior_bounded_records=records,
)
(OWN / "source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
(OWN / "proposed-build-wasm.mjs").unlink()
shutil.rmtree(OWN / "tmp")
totals = {}
for label, base_path in [("source", ROOT / "games/othello"), ("own_artifacts", OWN)]:
    files = [base_path, *base_path.rglob("*")]
    infos = [path.lstat() for path in files]
    totals[label] = dict(
        files=sum(stat.S_ISREG(info.st_mode) for info in infos),
        logical_bytes=sum(info.st_size for info in infos if stat.S_ISREG(info.st_mode)),
        allocated_bytes=sum(info.st_blocks * 512 for info in infos),
    )
(OWN / "affected-storage.json").write_text(
    json.dumps(
        dict(
            measured_utc=datetime.now(timezone.utc).isoformat(),
            scope="one snapshot of affected paths, excluding this final measurement record and subsequent control-log updates",
            totals=totals,
            bulk_work=False,
            global_cap_B=50_000_000_000,
        ),
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        dict(
            base=base,
            source_files=len(paths),
            prior_bounded_records_verified=len(records),
            source_stop=True,
            totals=totals,
        )
    )
)
