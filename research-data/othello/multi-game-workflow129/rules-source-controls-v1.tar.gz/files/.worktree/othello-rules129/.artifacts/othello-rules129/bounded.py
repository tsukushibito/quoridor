"""Task-local formatter/parser checks using the existing process owner."""

import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

from quoridor_runtime import cycle_process as process

ROOT = Path("/workspaces/quoridor/.worktree/othello-rules129")
OWN = ROOT / ".artifacts/othello-rules129"
PLAN_PATH = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/multi-game-migration-v1/game-boundaries-entry-v1/othello-rules129-cpu-plan.json"
)
data = PLAN_PATH.read_bytes()
assert (
    hashlib.sha256(data).hexdigest()
    == "b704b11107171bcc47ab60abe90c4f06abfe01c7891f7df5e8a6f5cf2a8743a1"
)
assert len(data) == 489 and stat.S_IMODE(PLAN_PATH.stat().st_mode) == 0o644
issued = json.loads(data)
plan = process.CPUPlan.from_record(issued["cpu_plan"])
plan.check_host(process.available_cpus())
plan.apply()
deadline = time.monotonic() + 60
config = dict(host_ram_reserve=issued["hostreserve_B"])
controller = process.CycleResources(
    {**config, "max_memory_bytes": issued["controller_B"]}, OWN, deadline
)
child = process.CycleResources({**config, "max_memory_bytes": issued["child_max_B"]}, OWN, deadline)


class Checks(process.CycleResources):
    def check(self, owned=(), *, include_self=True):
        super().check(owned, include_self=include_self)
        controller.check()
        child.check(owned, include_self=False)


resources = Checks({**config, "max_memory_bytes": issued["family_B"]}, OWN, deadline)
temporary = OWN / "tmp"
temporary.mkdir(exist_ok=True)
env = dict(
    os.environ,
    TMPDIR=str(temporary),
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    CUDA_VISIBLE_DEVICES="",
)
label, *command = sys.argv[1:]
assert label.replace("-", "").isalnum() and command
with process.cancellation_signals():
    process.execute(
        command,
        OWN / (label + ".log"),
        deadline,
        resources=resources,
        cpu_plan=plan,
        cpu_scope="implementation",
        cwd=ROOT,
        env=env,
    )
print((OWN / (label + ".log")).read_text())
