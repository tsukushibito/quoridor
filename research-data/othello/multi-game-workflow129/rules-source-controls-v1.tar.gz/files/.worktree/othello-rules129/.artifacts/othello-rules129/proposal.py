"""Prepare only the exact common-caller patch; never edit shared callers."""

import difflib
import hashlib
import json
from pathlib import Path
import stat
import sys
import tomllib

ROOT = Path("/workspaces/quoridor/.worktree/othello-rules129")
OWN = ROOT / ".artifacts/othello-rules129"

if sys.argv[1] == "prepare":
    build = (ROOT / "scripts/build-wasm.mjs").read_text()
    build = build.replace(
        "for (const [feature, name] of [", "for (const [game, feature, name] of ["
    )
    build = build.replace(
        "['rules', 'quoridor_rules'],", "['quoridor', 'rules', 'quoridor_rules'],"
    )
    build = build.replace(
        "['ai', 'quoridor_ai'],",
        "['quoridor', 'ai', 'quoridor_ai'],\n  ['othello', '', 'othello'],",
    )
    build = build.replace(
        "games/quoridor/bridge/wasm/${feature}", "games/${game}/bridge/wasm/${feature}"
    )
    build = build.replace(
        "resolve(root, 'games/quoridor/crates/quoridor-wasm')",
        "resolve(root, `games/${game}/crates/${game}-wasm`)",
    )
    build = build.replace(
        "'--features',\n    feature,", "...(feature ? ['--features', feature] : []),"
    )
    build = build.replace(
        "rules and AI Wasm with separate features.", "Quoridor rules/AI and Othello Wasm."
    )
    (OWN / "proposed-build-wasm.mjs").write_text(build)
else:
    patch = []
    references = {}
    for name in ["Cargo.toml", ".gitignore", "scripts/build-wasm.mjs"]:
        path = ROOT / name
        before = path.read_text()
        if name == "Cargo.toml":
            after = before.replace(
                '  "games/quoridor/crates/quoridor-runner",',
                '  "games/quoridor/crates/quoridor-runner",\n  "games/othello/crates/othello-core", "games/othello/crates/othello-wasm",',
            )
            tomllib.loads(after)
        elif name == ".gitignore":
            after = before.replace(
                "games/quoridor/bridge/wasm/\n",
                "games/quoridor/bridge/wasm/\ngames/othello/bridge/wasm/\n",
            )
        else:
            after = (OWN / "proposed-build-wasm.mjs").read_text()
        assert before != after
        references[name] = dict(
            before_sha256=hashlib.sha256(before.encode()).hexdigest(),
            before_bytes=len(before.encode()),
            before_mode=format(stat.S_IMODE(path.stat().st_mode), "04o"),
            proposed_sha256=hashlib.sha256(after.encode()).hexdigest(),
            proposed_bytes=len(after.encode()),
        )
        patch.extend(
            difflib.unified_diff(
                before.splitlines(keepends=True),
                after.splitlines(keepends=True),
                fromfile="a/" + name,
                tofile="b/" + name,
            )
        )
    (OWN / "common-caller-proposal.patch").write_text("".join(patch))
    (OWN / "common-caller-references.json").write_text(json.dumps(references, indent=2) + "\n")
    for name in [
        "games/othello/crates/othello-core/Cargo.toml",
        "games/othello/crates/othello-wasm/Cargo.toml",
    ]:
        tomllib.loads((ROOT / name).read_text())
    print("Exact proposal prepared; 3 TOML documents parsed; shared callers unchanged.")
