"""Root-only bounded technical acceptance of the new Othello product rules."""

import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time
import tomllib

from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus, execute

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
plan = CPUPlan.from_record(
    dict(
        management=[18],
        commands={"check": [0]},
        allocation=[0, 18],
        resource_CPUs=2,
        worker_CPUs=1,
        library_threads=1,
    )
)
plan.check_host(available_cpus())
plan.apply()
spec = importlib.util.spec_from_file_location(
    "lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lc)
assert lc.process.process_info(os.getpid())["rss"] < 64 * 1024**2
prior = json.loads((OUT.parent / "layout-software-v1/build-intent-release.json").read_bytes())
env = dict(
    os.environ,
    CUDA_VISIBLE_DEVICES="",
    PYTHONDONTWRITEBYTECODE="1",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    NODE_DISABLE_COMPILE_CACHE="1",
)
env.update({k: v for k, v in prior["env"].items() if k not in {"TMPDIR", "PATH", "PYTHONPATH"}})
env["PYTHONPATH"] = os.pathsep.join(
    str(ROOT / p) for p in ("games/quoridor/python", "shared/python")
)
tmp = OUT / "TMP"
tmp.mkdir()
env["TMPDIR"] = str(tmp)
cargo = "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo"
pretty = str(ROOT / "tools/research-quality/node_modules/.bin/prettier")
source = ROOT / "games/othello"
py = ["scripts/dev/research-lifecycle.py", "tools/research-session/test_build_provenance.py"]
js = [
    "scripts/build-wasm.mjs",
    "scripts/export-fresh-source.mjs",
    "tools/research-quality/test_export.mjs",
]
lock_before = tomllib.loads((ROOT / "Cargo.lock").read_text())
(OUT / "Cargo.lock.before").write_bytes((ROOT / "Cargo.lock").read_bytes())
commands = [
    (
        "Root-prettier-write",
        [pretty, "--config", "tools/research-quality/.prettierrc.json", "--write", *js],
        1,
    ),
    (
        "Root-prettier-check",
        [pretty, "--config", "tools/research-quality/.prettierrc.json", "--check", *js],
        1,
    ),
    (
        "Root-ruff-format",
        [
            "bash",
            "scripts/dev/project-env.sh",
            "ruff",
            "format",
            "--config",
            "tools/research-quality/ruff.toml",
            *py,
        ],
        1,
    ),
    (
        "Root-ruff-lint",
        [
            "bash",
            "scripts/dev/project-env.sh",
            "ruff",
            "check",
            "--no-cache",
            "--config",
            "tools/research-quality/ruff.toml",
            *py,
        ],
        1,
    ),
    (
        "export-current-scopes",
        [
            "node",
            "--test",
            "--test-name-pattern=current scopes",
            "tools/research-quality/test_export.mjs",
        ],
        1,
    ),
    (
        "Cargo-untracked-discriminator",
        [
            sys.executable,
            "-B",
            "-m",
            "unittest",
            "discover",
            "-s",
            "tools/research-session",
            "-p",
            "test_build_provenance.py",
            "-k",
            "test_build379_standard_git_revision_delta_and_untracked_input",
            "-v",
        ],
        1,
    ),
    (
        "new-Othello-rust-tests",
        [
            cargo,
            "test",
            "--offline",
            "-j1",
            "--message-format=json-render-diagnostics",
            "-p",
            "othello-core",
            "-p",
            "othello-wasm",
        ],
        4,
    ),
    (
        "new-Othello-clippy",
        [
            cargo,
            "clippy",
            "--locked",
            "--offline",
            "-j1",
            "-p",
            "othello-core",
            "-p",
            "othello-wasm",
            "--all-targets",
            "--",
            "-D",
            "warnings",
        ],
        4,
    ),
    (
        "new-Othello-Wasm",
        [
            shutil.which("wasm-pack"),
            "build",
            "games/othello/crates/othello-wasm",
            "--target",
            "web",
            "--dev",
            "--out-dir",
            str(OUT / "generated-wasm"),
            "--out-name",
            "othello",
            "--locked",
            "--no-default-features",
        ],
        4,
    ),
]
rows = []
failure = None
try:
    with lc.lease():
        for name, argv, family in commands:
            deadline = time.monotonic() + (900 if family == 4 else 180)
            resources = CycleResources(
                dict(
                    max_memory_bytes=family * 1024**3 - 64 * 1024**2, host_ram_reserve=4 * 1024**3
                ),
                OUT,
                deadline,
            )
            record = execute(
                argv,
                OUT / (name + ".log"),
                deadline,
                resources=resources,
                cpu_plan=plan,
                cpu_scope="check",
                cwd=ROOT,
                env=env,
            )
            lc.settled(record)
            assert record["handle_closes_complete"]
            rows.append(dict(name=name, argv=argv, record=record))
            (OUT / "returned-commands.json").write_text(json.dumps(rows, indent=2) + "\n")
        before = {p["name"]: p for p in lock_before["package"]}
        after = {p["name"]: p for p in tomllib.loads((ROOT / "Cargo.lock").read_text())["package"]}
        assert set(after) - set(before) == {"othello-core", "othello-wasm"}
        assert all(after[n] == v for n, v in before.items()), "existing dependency lock drift"
        (OUT / "lock-additions.json").write_text(
            json.dumps({n: after[n] for n in set(after) - set(before)}, indent=2) + "\n"
        )
        dest = source / "bridge/wasm"
        dest.mkdir()
        supplied = []
        for p in sorted((OUT / "generated-wasm").iterdir()):
            if p.suffix in (".js", ".ts", ".wasm"):
                shutil.copy2(p, dest / p.name)
                supplied.append(p.name)
        (OUT / "supplied-generated-files.json").write_text(json.dumps(supplied) + "\n")
        for name, argv in [
            ("real-generated-Wasm", ["node", "--test", "games/othello/bridge/test/wasm.test.mjs"]),
            (
                "real-generated-types",
                [
                    "node",
                    "node_modules/typescript/bin/tsc",
                    "--noEmit",
                    "--strict",
                    "--target",
                    "ES2022",
                    "--module",
                    "ESNext",
                    "--moduleResolution",
                    "Bundler",
                    "--lib",
                    "ES2022,DOM",
                    "games/othello/bridge/src/index.ts",
                    str(OUT / "wasm-url.d.ts"),
                    "games/othello/bridge/wasm/othello.d.ts",
                ],
            ),
        ]:
            deadline = time.monotonic() + 180
            resources = CycleResources(
                dict(max_memory_bytes=1024**3 - 64 * 1024**2, host_ram_reserve=4 * 1024**3),
                OUT,
                deadline,
            )
            record = execute(
                argv,
                OUT / (name + ".log"),
                deadline,
                resources=resources,
                cpu_plan=plan,
                cpu_scope="check",
                cwd=ROOT,
                env=env,
            )
            lc.settled(record)
            rows.append(dict(name=name, argv=argv, record=record))
            (OUT / "returned-commands.json").write_text(json.dumps(rows, indent=2) + "\n")
    for p in list(tmp.iterdir()):
        if p.name.startswith("uv-") and p.is_file() and p.stat().st_size == 0:
            p.unlink()
    assert not list(tmp.iterdir()), list(tmp.iterdir())
    tmp.rmdir()
except BaseException as e:
    failure = dict(type=type(e).__name__, message=str(e))
    raise
finally:
    (OUT / "result.json").write_text(
        json.dumps(
            dict(
                status="PASS" if failure is None else "FAILED",
                commands=rows,
                failure=failure,
                source_leases=[],
                actual_new_product_tests=True,
                scientific_calls=0,
                existing_Quoridor_tests_replayed=0,
                host_future_quiet=False,
            ),
            indent=2,
        )
        + "\n"
    )
print(
    json.dumps(
        dict(status="PASS", commands=len(rows), new_product_rust_definitions=11, real_Wasm_units=2)
    )
)
