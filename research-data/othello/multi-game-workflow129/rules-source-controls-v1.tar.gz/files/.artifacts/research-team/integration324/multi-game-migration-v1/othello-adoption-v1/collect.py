"""Integrate the stopped Othello product source and exact current callers."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
WT = ROOT / ".worktree/othello-rules129"
OWN = WT / ".artifacts/othello-rules129"


def ref(path):
    body = path.read_bytes()
    return dict(
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def run(args):
    p = subprocess.run(args, capture_output=True, text=True, check=False)
    assert p.returncode == 0, p.stderr
    return p.stdout


assert not run(["git", "status", "--porcelain=v1"])
manifest = json.loads((OWN / "source-manifest.json").read_bytes())
proposal = OWN / "common-caller-proposal.patch"
assert ref(proposal) == manifest["common_proposal"]
run(["git", "apply", "--check", str(proposal)])
for row in manifest["source_files"]:
    path = row["path"]
    assert row["before"] == "ABSENT" and not (ROOT / path).exists()
    assert ref(WT / path) == row["after"], path
for row in manifest["source_files"]:
    path = row["path"]
    (ROOT / path).parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(WT / path, ROOT / path)
    assert ref(ROOT / path) == row["after"]
run(["git", "apply", str(proposal)])
exporter = ROOT / "scripts/export-fresh-source.mjs"
text = exporter.read_text().replace(
    "    'python/',",
    "    'games/othello/crates/',\n    'games/quoridor/python/',\n    'shared/python/',\n    'games/quoridor/configs/',\n    'games/quoridor/tests/python/',",
)
text = text.replace(
    "    'games/quoridor/bridge/',",
    "    'games/quoridor/bridge/',\n    'games/othello/bridge/',\n    'games/othello/crates/',\n    'games/quoridor/configs/',\n    'games/quoridor/tests/',\n    'games/quoridor/docs/',",
)
exporter.write_text(text)
lifecycle = ROOT / "scripts/dev/research-lifecycle.py"
text = lifecycle.read_text()
assert text.count('        "games/quoridor/crates",') == 1
lifecycle.write_text(
    text.replace(
        '        "games/quoridor/crates",',
        '        "games/quoridor/crates",\n        "games/othello/crates",',
    )
)
provenance = ROOT / "tools/research-session/test_build_provenance.py"
text = provenance.read_text()
needle = '        extra.write_bytes(b"fn untracked_drift() {}\\n")'
assert needle in text
text = text.replace(
    needle,
    '        othello = self.file("games/othello/crates/new_module.rs", b"fn othello_input() {}\\n")\n        with self.assertRaisesRegex(lc.Refused, "untracked Cargo inputs drift"):\n            lc.source_check(self.source_info)\n        self.source_info["untracked_inputs"].append(fixture.ref(othello))\n        lc.source_check(self.source_info)\n'
    + needle,
)
provenance.write_text(text)
test = ROOT / "tools/research-quality/test_export.mjs"
text = test.read_text()
marker = "test('current scopes omit retired Web roots and require exact root filenames'"
pos = text.index(marker)
head, current = text[:pos], text[pos:]
extra = [
    "games/othello/crates/othello-core/src/lib.rs",
    "games/othello/bridge/src/index.ts",
    "games/quoridor/configs/arena/smoke.json",
    "games/quoridor/python/quoridor_training/current.py",
    "shared/python/quoridor_runtime/cycle_process.py",
    "games/quoridor/tests/python/test_current.py",
    "games/quoridor/docs/spec.md",
]
needle = "    'games/quoridor/crates/quoridor-core/src/lib.rs',"
current = current.replace(needle, needle + "\n" + "\n".join("    '" + p + "'," for p in extra), 1)
# Change the two expected lists independently; scope membership remains exact.
start = current.index("  const product =")
end = current.index("  const research =")
a, product, rest = current[:start], current[start:end], current[end:]
product_extra = sorted([p for p in extra if "/python/" not in p])
product = product.replace(
    "      'games/quoridor/bridge/src/index.ts',",
    "\n".join("      '" + p + "'," for p in product_extra[:2])
    + "\n      'games/quoridor/bridge/src/index.ts',",
)
product = product.replace(
    "      'games/quoridor/crates/quoridor-core/src/lib.rs',",
    "      'games/quoridor/configs/arena/smoke.json',\n      'games/quoridor/crates/quoridor-core/src/lib.rs',\n      'games/quoridor/docs/spec.md',",
)
rest = rest.replace(
    "      'games/quoridor/crates/quoridor-core/src/lib.rs',",
    "      'games/othello/crates/othello-core/src/lib.rs',\n      'games/quoridor/configs/arena/smoke.json',\n      'games/quoridor/crates/quoridor-core/src/lib.rs',\n      'games/quoridor/python/quoridor_training/current.py',\n      'games/quoridor/tests/python/test_current.py',",
)
rest = rest.replace(
    "      'python/quoridor_training/current.py',",
    "      'shared/python/quoridor_runtime/cycle_process.py',",
)
test.write_text(head + a + product + rest)
(OUT / "composition.json").write_text(
    json.dumps(
        dict(
            manifest=manifest,
            source_paths=[r["path"] for r in manifest["source_files"]],
            common_proposal_sha=ref(proposal),
            additional_current_callers=[
                str(p.relative_to(ROOT)) for p in (exporter, lifecycle, provenance, test)
            ],
            lock_before=ref(ROOT / "Cargo.lock"),
        ),
        indent=2,
    )
    + "\n"
)
print("Othello10 source files/common3 and current source/export selectors adopted; compile UNRUN")
