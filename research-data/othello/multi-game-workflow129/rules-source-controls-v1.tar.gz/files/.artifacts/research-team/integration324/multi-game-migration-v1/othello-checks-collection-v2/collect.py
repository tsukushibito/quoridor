"""Collect passed Othello checks and execute only the two unentered bindings."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tomllib

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
PRIOR = OUT.with_name("othello-checks-v1")
rows = json.loads((PRIOR / "returned-commands.json").read_bytes())
assert len(rows) == 9 and all(
    r["record"]["exit_code"] == 0
    and r["record"]["cleanup_complete"]
    and r["record"]["signal_mask_restoration"] == "completed"
    for r in rows
)
baseline = subprocess.check_output(
    ["git", "show", "68100f946a9c368be2490d04fd9a8e97f520a520:Cargo.lock"]
)
assert (
    hashlib.sha256(baseline).hexdigest()
    == "e660913aa85fefd7974d8b2d807698aa96325a6c16067053b6bf1e0a80b1a5de"
)
before = tomllib.loads(baseline.decode())["package"]
after = tomllib.loads((ROOT / "Cargo.lock").read_text())["package"]
added = [p for p in after if p["name"] in ("othello-core", "othello-wasm")]
assert len(added) == 2
assert [p for p in after if p not in added] == before
(OUT / "lock-additions.json").write_text(
    json.dumps(
        dict(
            packages=added,
            comparison="fixed accepted68100f9 Git lock; no existing dependency/version drift",
            observed_precommand_refresh="initial v1 lock snapshot already contains additions; earlier metadata refresh cause not observed; v1 post-check assertion FAILED retained",
        ),
        indent=2,
    )
    + "\n"
)
dest = ROOT / "games/othello/bridge/wasm"
assert not dest.exists()
dest.mkdir()
supplied = []
for p in sorted((PRIOR / "generated-wasm").iterdir()):
    if p.suffix in (".js", ".ts", ".wasm"):
        shutil.copy2(p, dest / p.name)
        supplied.append(
            dict(
                path=str((dest / p.name).relative_to(ROOT)),
                bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
            )
        )
(OUT / "supplied-generated-files.json").write_text(json.dumps(supplied, indent=2) + "\n")
commands = [
    ("actual-generated-Wasm", ["node", "--test", "games/othello/bridge/test/wasm.test.mjs"]),
    (
        "actual-generated-types",
        [
            "node",
            "node_modules/typescript/bin/tsc",
            "--noEmit",
            "--strict",
            "--target",
            "ES2022",
            "--module",
            "ESNext",
            "--moduleResolution",
            "Bundler",
            "--lib",
            "ES2022,DOM",
            "games/othello/bridge/src/index.ts",
            str(PRIOR / "wasm-url.d.ts"),
            "games/othello/bridge/wasm/othello.d.ts",
        ],
    ),
]
results = []
for name, argv in commands:
    p = subprocess.run(
        argv,
        capture_output=True,
        text=True,
        timeout=120,
        check=False,
        env=dict(os.environ, NODE_DISABLE_COMPILE_CACHE="1"),
    )
    (OUT / (name + ".log")).write_text(p.stdout + p.stderr)
    results.append(dict(name=name, argv=argv, code=p.returncode))
    (OUT / "binding-checks.json").write_text(json.dumps(results, indent=2) + "\n")
    assert p.returncode == 0, (name, p.stderr[-2000:])
for p in list((PRIOR / "TMP").iterdir()):
    assert p.name.startswith("uv-") and p.is_file() and p.stat().st_size == 0
    p.unlink()
(PRIOR / "TMP").rmdir()
(OUT / "collected.json").write_text(
    json.dumps(
        dict(
            prior9_actual_returned=rows,
            new_checks=results,
            Rust_unit_tests=11,
            real_Wasm_units=2,
            generated_type_declarations="actual generated .d.ts; fallback src/wasm.d.ts deliberately excluded",
            existing_Quoridor_test_replays=0,
            scientific_calls=0,
            sourceleases=[],
            prior_failed_postcondition_retained=True,
        ),
        indent=2,
    )
    + "\n"
)
print(json.dumps(dict(status="PASS", prior9_reused=True, new_Wasm_units=2, generated_types=True)))
