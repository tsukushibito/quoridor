/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const apply_move_json: (a: number, b: number, c: number) => [number, number, number, number];
export const choose_move_json: (a: number, b: number) => [number, number, number, number];
export const legal_moves_json: (a: number, b: number) => [number, number, number, number];
export const new_game_json: () => [number, number, number, number];
export const pass_turn_json: (a: number, b: number) => [number, number, number, number];
export const status_json: (a: number, b: number) => [number, number, number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
