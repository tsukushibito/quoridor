"""Finite frontend commands using the assigned CPUPlan and existing process owner."""

import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = Path("/workspaces/quoridor/.worktree/othello-web129")
sys.path.insert(0, str(ROOT / "shared/python"))
from quoridor_runtime import cycle_process as process

OUT = ROOT / ".artifacts/othello-web129"
REF = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/multi-game-migration-v1/othello-web-entry-v1/cpu-plan.json"
)
raw = REF.read_bytes()
assert (hashlib.sha256(raw).hexdigest(), len(raw), stat.S_IMODE(REF.stat().st_mode)) == (
    "7bec1e9fc1010fb1066019e2c386351b4d91d818e5ea40e691c27e51d1f1b964",
    487,
    0o644,
)
record = json.loads(raw)
plan = process.CPUPlan.from_record(record["cpu_plan"])
plan.check_host(process.available_cpus())
plan.apply()
label, *command = sys.argv[1:]
assert label and command
runtime = OUT / label
runtime.mkdir(exist_ok=False)
tmp = runtime / "tmp"
tmp.mkdir()
deadline = time.monotonic() + 600


class Resources(process.CycleResources):
    peak = 0

    def check(self, owned=(), *, include_self=True):
        super().check(owned, include_self=include_self)
        controller = process.process_info(os.getpid())["rss"]
        children = sum(
            (process.process_info(p["pid"]) or {}).get("rss", 0) for p in owned if process.alive(p)
        )
        self.peak = max(self.peak, controller + children)
        if controller > record["controller_B"] or children > record["child_max_B"]:
            raise process.CycleStopped("controller/child RSS partition exceeded")


resources = Resources(
    {
        "max_memory_bytes": record["family_B"],
        "host_ram_reserve": record["hostreserve_B"],
        "pause_file": str(OUT / "CANCEL"),
    },
    runtime,
    deadline,
)
env = dict(os.environ)
env.update(
    {
        name: "1"
        for name in (
            "OMP_NUM_THREADS",
            "OPENBLAS_NUM_THREADS",
            "MKL_NUM_THREADS",
            "NUMEXPR_NUM_THREADS",
            "RAYON_NUM_THREADS",
            "UV_THREADPOOL_SIZE",
        )
    }
)
env.update(TMPDIR=str(tmp), TMP=str(tmp), TEMP=str(tmp), CUDA_VISIBLE_DEVICES="")
try:
    with (OUT / "source-read.lock").open("a") as lease, process.cancellation_signals():
        fcntl.flock(lease, fcntl.LOCK_SH)
        returned = process.execute(
            command,
            runtime / "command.log",
            deadline,
            cwd=ROOT,
            env=env,
            resources=resources,
            cpu_plan=plan,
            cpu_scope="implementation",
        )
    (runtime / "execute-return.json").write_text(json.dumps(returned, indent=2) + "\n")
finally:
    evidence = {
        "peak_family_RSS_B": resources.peak,
        "controller_final_RSS_B": process.process_info(os.getpid())["rss"],
        "cpu_plan": plan.record(),
        "source_lease_returned": True,
        "tmp_entries": [p.name for p in tmp.iterdir()],
    }
    (runtime / "resources.json").write_text(json.dumps(evidence, indent=2) + "\n")
    if not any(tmp.iterdir()):
        tmp.rmdir()
    log = runtime / "command.log"
    if log.exists():
        print(log.read_text()[-18000:])
