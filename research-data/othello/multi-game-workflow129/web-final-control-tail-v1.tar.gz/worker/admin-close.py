"""Perform the single authorized Beads closure, retaining exact reason and returns."""

import hashlib
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor/.worktree/othello-web129")
OUT = ROOT / ".artifacts/othello-web129/admin-close-records"
OUT.mkdir(exist_ok=False)
ISSUE = "quoridor-4lc.324.12.9.7"
ASSIGNEE = "codex:01a15f23-0746-7953-a08b-9927d23d26f7"
REASON = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/multi-game-migration-v1/web-games-close-dispatch-v1/7-exact-reason.txt"
)
raw = REASON.read_bytes()
reason = raw.decode("utf-8", errors="strict")
assert reason
reason_ref = dict(
    path=str(REASON),
    sha256=hashlib.sha256(raw).hexdigest(),
    bytes=len(raw),
    mode=f"{stat.S_IMODE(REASON.stat().st_mode):04o}",
)
(OUT / "exact-reason-ref.json").write_text(json.dumps(reason_ref, indent=2) + "\n")


def beads(label, *arguments):
    result = subprocess.run(
        ["bash", "scripts/dev/beads.sh", *arguments],
        cwd=ROOT,
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=False,
    )
    record = dict(
        argv=["bash", "scripts/dev/beads.sh", *arguments],
        returncode=result.returncode,
        stdout=result.stdout,
        stderr=result.stderr,
    )
    (OUT / f"{label}.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    if result.returncode:
        raise RuntimeError(f"{label} returned {result.returncode}; no automatic retry")
    return result.stdout


def issue(output):
    value = json.loads(output)
    if isinstance(value, list):
        assert len(value) == 1
        value = value[0]
    assert value["id"] == ISSUE and value["assignee"] == ASSIGNEE, value
    return value


before = issue(beads("01-show-before", "show", ISSUE, "--json"))
assert before["status"] != "closed", "Already closed; refusing a duplicate close"
beads(
    "02-own-note",
    "update",
    ISSUE,
    "--append-notes",
    "ADMIN ONLY after Root technical acceptance/push883c3e00008f1663cde39fd2b83d9fbff46ed264: closing own12.9.7 once with byte-exact UTF8 reason supplied by Root web-games-close-dispatch-v1/7-exact-reason.txt. Exact saved turn_context gpt-6.1-sol/high, managed cwd, danger-full-access/never verified before ordinary commands. Original CPUPlan/CPU12/G18/F2GiB/host4GiB/GPU0/thread1 and existing guards unchanged. No source/test/browser/config/archive/science replay or other issue change. Original disk process pending facts remain untouched; new normal execute return object is recorded separately. Prior frozen handoff/evidence retained. Root owns final retirement.",
)
beads("03-backup-before", "backup", "sync")
beads("04-close-once", "close", ISSUE, "--reason", reason)
try:
    after = issue(beads("05-show-closed", "show", ISSUE, "--json"))
    assert after["status"] == "closed", after["status"]
    assert after["close_reason"] == reason, "Exact reason mismatch"
    assert after["assignee"] == before["assignee"] == ASSIGNEE
    verification = dict(
        id=ISSUE,
        status=after["status"],
        assignee=after["assignee"],
        exact_reason_equal=True,
        reason_utf8_sha256=hashlib.sha256(after["close_reason"].encode("utf-8")).hexdigest(),
        reason_ref=reason_ref,
        closed_at=after.get("closed_at"),
    )
    (OUT / "verification.json").write_text(
        json.dumps(verification, ensure_ascii=False, indent=2) + "\n"
    )
finally:
    beads("06-backup-after", "backup", "sync")
print(json.dumps(verification, ensure_ascii=False))
