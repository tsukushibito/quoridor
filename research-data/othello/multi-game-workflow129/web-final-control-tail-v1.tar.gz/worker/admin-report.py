"""Keep immutable disk cleanup facts separate from actual execute returns."""

import json
from pathlib import Path

OUT = Path("/workspaces/quoridor/.worktree/othello-web129/.artifacts/othello-web129")
verification = json.loads((OUT / "admin-close-records/verification.json").read_text())
assert verification["status"] == "closed" and verification["exact_reason_equal"]
records = []
for label in ("admin-format", "admin-helper-quality", "admin-close-execution"):
    directory = OUT / label
    disk = json.loads((directory / "command.process.json").read_text())
    returned = json.loads((directory / "execute-return.json").read_text())
    resources = json.loads((directory / "resources.json").read_text())
    assert returned["status"] == "complete" and returned["remaining"] == []
    assert returned["direct_child_reaped"] and returned["process_cleanup_complete"]
    assert returned["handle_closes_complete"] and resources["source_lease_returned"]
    records.append(
        dict(label=label, original_disk=disk, actual_returned_object=returned, resources=resources)
    )
for label in ("03-backup-before", "06-backup-after"):
    record = json.loads((OUT / f"admin-close-records/{label}.json").read_text())
    assert record["returncode"] == 0
report = dict(
    verification=verification,
    normal_close_count=1,
    cleanup_records=records,
    product_source_STOP=True,
    administrative_close_STOP=True,
    old_pending_disk_records="Preserved unchanged; no claim of previously unrecorded restoration",
    no_source_test_browser_config_archive_science_replay=True,
    final_parent_delivery="Not started in this snapshot; actual return will be recorded separately after delivery",
)
(OUT / "admin-close-stop.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            status=verification["status"],
            assignee=verification["assignee"],
            exact_reason_equal=True,
            backups_before_after="returned0",
            disk_signal_mask=[r["original_disk"]["signal_mask_restoration"] for r in records],
            actual_returned_signal_mask=[
                r["actual_returned_object"]["signal_mask_restoration"] for r in records
            ],
            source_leases_returned=True,
            owned_remaining=[r["actual_returned_object"]["remaining"] for r in records],
        )
    )
)
