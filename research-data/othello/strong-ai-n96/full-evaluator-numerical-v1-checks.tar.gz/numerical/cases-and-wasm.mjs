import assert from 'node:assert/strict';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
const out = process.argv[2];
const mode = process.argv[3];
const config = JSON.parse(fs.readFileSync(out + '/config.json', 'utf8'));
const api = await import(pathToFileURL(config.generatedJs.path).href);
api.initSync({ module: fs.readFileSync(config.generatedWasm.path) });
const parse = (fn, state, move) =>
  JSON.parse(move === undefined ? fn(JSON.stringify(state)) : fn(JSON.stringify(state), move));
if (mode === 'prepare') {
  const recorded = JSON.parse(fs.readFileSync(config.recorded.path, 'utf8'));
  assert.equal(recorded.series.length, 2);
  const base = [];
  for (const [series, record] of recorded.series.entries()) {
    assert.deepEqual(record.initial, JSON.parse(api.new_game_json()));
    let state = record.initial;
    base.push({ id: 'series' + series + '/0', state });
    for (const [index, move] of record.moves.entries()) {
      state =
        move === null ? parse(api.pass_turn_json, state) : parse(api.apply_move_json, state, move);
      base.push({ id: 'series' + series + '/' + (index + 1), state });
    }
    assert.equal(parse(api.status_json, state).terminal, true);
  }
  assert.equal(base.length, 123);
  const boundary = Array(64).fill(1);
  boundary[0] = 0;
  boundary[1] = 2;
  base.push({ id: 'boundary/phase59', state: { version: 1, board: [...boundary], toMove: 1 } });
  base.push({ id: 'boundary/pass59', state: { version: 1, board: [...boundary], toMove: 2 } });
  boundary[1] = 1;
  base.push({
    id: 'boundary/earlyTerminal',
    state: { version: 1, board: [...boundary], toMove: 1 },
  });
  boundary[0] = 1;
  base.push({
    id: 'boundary/fullTerminal',
    state: { version: 1, board: [...boundary], toMove: 1 },
  });
  const cases = [];
  const phases = Array(60).fill(0);
  let terminal = 0,
    mustPass = 0;
  for (const row of base)
    for (let symmetry = 0; symmetry < 8; symmetry++)
      for (let swapped = 0; swapped < 2; swapped++) {
        const board = Array(64).fill(0);
        row.state.board.forEach((cell, index) => {
          board[config.symmetries[symmetry][index]] = swapped && cell ? 3 - cell : cell;
        });
        const state = {
          version: 1,
          board,
          toMove: swapped ? 3 - row.state.toMove : row.state.toMove,
        };
        const status = parse(api.status_json, state);
        const occupied = board.filter(Boolean).length;
        if (status.terminal) terminal++;
        else {
          assert(occupied >= 4 && occupied <= 63);
          phases[occupied - 4]++;
        }
        if (status.mustPass) mustPass++;
        cases.push({
          id: row.id + '/d' + symmetry + '/c' + swapped,
          state,
          terminal: status.terminal,
          mustPass: status.mustPass,
        });
      }
  assert.equal(cases.length, 2032);
  assert(phases.every((n) => n > 0));
  assert(mustPass >= 16 && terminal >= 32);
  fs.writeFileSync(out + '/cases.json', JSON.stringify(cases) + '\n', { flag: 'wx' });
  fs.writeFileSync(
    out + '/case-census.json',
    JSON.stringify(
      {
        cases: cases.length,
        base: base.length,
        phases,
        terminal,
        mustPass,
        H: 0,
        weightsRead: 0,
        purpose:
          'frozen source numerical fixtures, development-observed series plus stated synthetic boundaries',
      },
      null,
      2,
    ) + '\n',
    { flag: 'wx' },
  );
  console.log(
    JSON.stringify({
      mode,
      cases: cases.length,
      terminal,
      mustPass,
      eligiblePhases: phases.filter(Boolean).length,
      weightsRead: 0,
    }),
  );
} else {
  assert.equal(mode, 'evaluate');
  const cases = JSON.parse(fs.readFileSync(out + '/cases.json', 'utf8'));
  const native = fs
    .readFileSync(out + '/native-oracle.jsonl', 'utf8')
    .trimEnd()
    .split('\n')
    .map(JSON.parse);
  assert.equal(native.length, cases.length);
  const midgame = fs.readFileSync(config.midgame.path);
  const ordering = fs.readFileSync(config.ordering.path);
  const output = fs.openSync(out + '/wasm.jsonl', 'wx');
  let comparisons = 0;
  try {
    for (const interpretation of ['generic', 'simd']) {
      const owner = new api.FullEvaluation(midgame, ordering, interpretation);
      try {
        assert.equal(owner.decoded_bytes(), 73963392);
        for (const [index, row] of cases.entries()) {
          const actual = JSON.parse(owner.evaluate_json(JSON.stringify(row.state)));
          fs.writeSync(
            output,
            JSON.stringify({ id: row.id, interpretation, evaluation: actual }) + '\n',
          );
          assert.deepEqual(
            actual,
            native[index][interpretation].evaluation,
            row.id + '/' + interpretation,
          );
          comparisons++;
        }
      } finally {
        owner.free();
      }
    }
  } finally {
    fs.closeSync(output);
  }
  fs.writeFileSync(
    out + '/wasm-result.json',
    JSON.stringify(
      {
        comparisons,
        complete: true,
        implementations: ['generic', 'scalar SIMD-table interpretation'],
        actualUpstreamSimdOracle: 'UNRUN',
        browser: 'UNRUN',
      },
      null,
      2,
    ) + '\n',
  );
  console.log(JSON.stringify({ mode, comparisons, complete: true }));
}
