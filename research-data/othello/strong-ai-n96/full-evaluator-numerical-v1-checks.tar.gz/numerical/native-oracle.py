"""One finite same-weight generic oracle correspondence; existing Process owns children."""

import json
from pathlib import Path
import time
from othello_arena.protocol import Process

OUT = Path(__file__).resolve().parent
CONFIG = json.loads((OUT / "config.json").read_bytes())
cases = json.loads((OUT / "cases.json").read_bytes())
assert len(cases) == 2032
mid = CONFIG["midgame"]
ordering = CONFIG["ordering"]
processes = {}
completed = 0
attempted = 0
primary = None
cleanups = {}
differences = 0
initialized = time.monotonic()
try:
    for interpretation in ("generic", "simd"):
        processes[interpretation] = Process(
            [
                CONFIG["native"]["path"],
                "--midgame",
                mid["path"],
                "--ordering",
                ordering["path"],
                "--midgame-id",
                "sha256:" + mid["sha256"],
                "--ordering-id",
                "sha256:" + ordering["sha256"],
                "--interpretation",
                interpretation,
            ],
            cwd=CONFIG["root"],
            log=OUT / (interpretation + "-protocol.log"),
            cancelled=lambda: (OUT / "CANCEL").exists(),
        )
    processes["oracle"] = Process(
        [CONFIG["oracle"]["path"], mid["path"], ordering["path"]],
        cwd=CONFIG["root"],
        log=OUT / "oracle-protocol.log",
        cancelled=lambda: (OUT / "CANCEL").exists(),
    )
    with (OUT / "native-oracle.jsonl").open("x") as evidence:
        for row in cases:
            attempted += 1
            record = {"id": row["id"]}
            for role, process in processes.items():
                record[role] = process.json_request(
                    {"op": "evaluate", "state": row["state"]}, deadline=time.monotonic() + 60
                )
            evidence.write(json.dumps(record, separators=(",", ":")) + "\n")
            evidence.flush()
            for role in ("generic", "simd"):
                identity = record[role]["weights"]
                assert identity["midgameId"] == "sha256:" + mid["sha256"]
                assert identity["orderingId"] == "sha256:" + ordering["sha256"]
                assert identity["decodedBytes"] == 73963392
            rust = record["generic"]["evaluation"]
            original = record["oracle"]
            assert original["engineCommit"] == rust["upstreamCommit"] == CONFIG["engineCommit"]
            for rk, ok in [
                ("terminal", "terminal"),
                ("occupied", "occupied"),
                ("ownCount", "stmDiscCount"),
                ("score", "score"),
                ("actualDiscDifference", "stmActualDiscDifference"),
            ]:
                assert rust[rk] == original[ok], (row["id"], rk, rust[rk], original[ok])
            assert rust["terminal"] == row["terminal"]
            assert rust["scoreUnits"] == original["scoreUnits"] == "engine-disc"
            if row["terminal"]:
                assert rust["midgame"] is None and original["tablePhase"] is None
                assert rust["scoreKind"] == "terminalEmptyAward"
            else:
                assert rust["indices"] == original["patternIndices"], (
                    row["id"],
                    "64 feature indices",
                )
                assert rust["phase"] == original["tablePhase"]
                for rk, ok in [
                    ("patternRaw", "patternSumStep"),
                    ("auxiliaryRaw", "discCountTermStep"),
                    ("totalRaw", "rawTotalStep"),
                    ("rounded", "roundedDiscScore"),
                    ("clamped", "cappedDiscScore"),
                ]:
                    assert rust["midgame"][rk] == original[ok], (
                        row["id"],
                        rk,
                        rust["midgame"][rk],
                        original[ok],
                    )
                assert rust["orderingRaw"] == original["endOrdering"]["rawTotalStep"]
                assert rust["orderingRounded"] == original["endOrdering"]["discScore"]
            differences += any(
                rust[k] != record["simd"]["evaluation"][k]
                for k in ("midgame", "orderingRaw", "orderingRounded", "score")
            )
            completed += 1
except BaseException as error:
    primary = {"type": type(error).__name__, "message": str(error)}
    raise
finally:
    errors = []
    for role, process in processes.items():
        try:
            process.close()
        except BaseException as error:
            errors.append({"role": role, "error": str(error)})
        cleanups[role] = process.cleanup
    result = dict(
        completed=completed,
        scheduled=len(cases),
        attempted=attempted,
        failedCases=attempted - completed,
        unrun=len(cases) - attempted,
        primary=primary,
        cleanup=cleanups,
        cleanupErrors=errors,
        complete=primary is None and not errors and completed == len(cases),
        totalWallSeconds=time.monotonic() - initialized,
        comparison="original generic only; SIMD table interpretation is separate",
        differingGenericSimdValues=differences,
    )
    (OUT / "native-result.json").write_text(json.dumps(result, indent=2) + "\n")
if not result["complete"]:
    raise RuntimeError("native/oracle did not complete with clean ownership")
assert all(
    v["directReaped"] and not v["errors"] and not v["unexpectedExit"] for v in cleanups.values()
)
print(json.dumps(result))
