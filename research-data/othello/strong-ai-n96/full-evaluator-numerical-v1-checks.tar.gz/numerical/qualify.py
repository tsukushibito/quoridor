"""Finite same-weight numerical boundary; no search/teacher/fit/new game."""

import hashlib
import json
import os
from pathlib import Path
import time
from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus
from quoridor_runtime.cycle_process import execute

ROOT = Path("/workspaces/quoridor")
WT = ROOT
OUT = Path(__file__).resolve().parent
CONFIG_REF = {
    "path": "/workspaces/quoridor/.artifacts/research-team/integration324/othello-strong-ai-n96/full-evaluator-numerical-v1/config.json",
    "bytes": 11536,
    "mode": "0644",
    "sha256": "0e01692ee10246ed39207f609d40113059976cd37bba74c538ec80ad9ae3d1b5",
}
config_bytes = Path(CONFIG_REF["path"]).read_bytes()
assert (
    len(config_bytes) == CONFIG_REF["bytes"]
    and hashlib.sha256(config_bytes).hexdigest() == CONFIG_REF["sha256"]
)
assert format(Path(CONFIG_REF["path"]).stat().st_mode & 0o777, "04o") == CONFIG_REF["mode"]
CONFIG = json.loads(config_bytes)
PLAN_REF = {
    "path": "/workspaces/quoridor/.artifacts/research-team/integration324/othello-strong-ai-n96/full-evaluator-numerical-v1/cpu-plan.json",
    "bytes": 190,
    "mode": "0644",
    "sha256": "a12e2052d0164f96b3d6d529e2ed7dea61323d76411b9aed0b9af7d5a487f890",
}
raw = Path(PLAN_REF["path"]).read_bytes()
assert len(raw) == PLAN_REF["bytes"] and hashlib.sha256(raw).hexdigest() == PLAN_REF["sha256"]
assert format(Path(PLAN_REF["path"]).stat().st_mode & 0o777, "04o") == PLAN_REF["mode"]
plan = CPUPlan.from_record(json.loads(raw))
plan.check_host(available_cpus())
plan.apply()


def verify(r):
    path = Path(r["path"])
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            h.update(block)
    assert path.stat().st_size == r["bytes"] and h.hexdigest() == r["sha256"], str(path)
    assert format(path.stat().st_mode & 0o777, "04o") == r["mode"]


for key in [
    "native",
    "oracle",
    "generatedJs",
    "generatedWasm",
    "generatedPackage",
    "recorded",
    "transformationSource",
]:
    verify(CONFIG[key])
for r in CONFIG["source"]:
    verify(r)
assert (
    int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
    <= 64 * 1024**2
)
tmp = OUT / "TMP"
tmp.mkdir()
target = (
    ROOT
    / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/target"
)
assert (
    json.loads((target / ".research-owner.json").read_bytes())["writer"]
    == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
)
env = dict(
    os.environ,
    RUSTUP_TOOLCHAIN="stable",
    RUSTUP_AUTO_INSTALL="0",
    RUSTC="/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustc",
    RUSTDOC="/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustdoc",
    CARGO_TARGET_DIR=str(target),
    CARGO_BUILD_JOBS="1",
    CARGO_INCREMENTAL="0",
    CARGO_NET_OFFLINE="true",
    CARGO_PROFILE_DEV_DEBUG="0",
    CARGO_PROFILE_TEST_DEBUG="0",
    RUSTFLAGS="-C debuginfo=0",
    PYTHONPATH=os.pathsep.join(
        [
            str(ROOT / "games/othello/python"),
            str(ROOT / "shared/python"),
            os.environ.get("PYTHONPATH", ""),
        ]
    ),
    PYTHONDONTWRITEBYTECODE="1",
    TMPDIR=str(tmp),
    CUDA_VISIBLE_DEVICES="",
    OMP_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
)
completed = []


def check(name, argv):
    deadline = time.monotonic() + 180
    resources = CycleResources(
        dict(
            max_memory_bytes=2 * 1024**3 - 64 * 1024**2,
            host_ram_reserve=4 * 1024**3,
            pause_file=str(OUT / "CANCEL"),
        ),
        OUT,
        deadline,
    )
    returned = None
    error = None
    try:
        returned = execute(
            argv,
            OUT / (name + ".log"),
            deadline,
            resources=resources,
            cpu_plan=plan,
            cpu_scope="numerical",
            cwd=WT,
            env=env,
        )
    except BaseException as caught:
        error = dict(type=type(caught).__name__, message=str(caught))
    finally:
        disk = OUT / (name + ".process.json")
        (OUT / (name + ".returned.json")).write_text(
            json.dumps(
                dict(
                    returned=returned,
                    error=error,
                    disk=json.loads(disk.read_bytes()) if disk.exists() else None,
                ),
                indent=2,
            )
            + "\n"
        )
    assert (
        error is None
        and returned["exit_code"] == 0
        and returned["remaining"] == []
        and returned["process_cleanup_complete"]
        and returned["handle_closes_complete"]
    ), (name, error)
    completed.append(dict(name=name, wall_seconds=returned["wall_seconds"]))
    (OUT / "completed.json").write_text(json.dumps(completed, indent=2) + "\n")


check("freeze-recorded-cases", ["node", str(OUT / "cases-and-wasm.mjs"), str(OUT), "prepare"])
census = json.loads((OUT / "case-census.json").read_bytes())
assert census["cases"] == 2032 and census["H"] == 0 and census["weightsRead"] == 0
assert len(census["phases"]) == 60 and all(census["phases"])
cases = OUT / "cases.json"
payload = cases.read_bytes()
freeze = dict(
    census=census,
    caseRef=dict(
        path=str(cases), bytes=len(payload), mode="0644", sha256=hashlib.sha256(payload).hexdigest()
    ),
    configSha256=hashlib.sha256((OUT / "config.json").read_bytes()).hexdigest(),
    frozenBeforeAnyWeightRead=True,
)
(OUT / "preweight-freeze.json").write_text(json.dumps(freeze, indent=2) + chr(10))
verify(CONFIG["midgame"])
verify(CONFIG["ordering"])
check("same-weight-native-oracle", ["python", "-B", str(OUT / "native-oracle.py")])
env["OTHELLO_FULL_EVAL_MIDGAME_PATH"] = CONFIG["midgame"]["path"]
env["OTHELLO_FULL_EVAL_ORDERING_PATH"] = CONFIG["ordering"]["path"]
env["OTHELLO_FULL_EVAL_RECORDED_FIXTURE_PATH"] = CONFIG["recorded"]["path"]
cargo = "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo"
check(
    "actual-weight-incremental",
    [
        cargo,
        "test",
        "--offline",
        "--locked",
        "-j1",
        "-p",
        "othello-core",
        "--test",
        "full_eval_recorded",
        "recorded_real_weight_incremental_parity",
        "--",
        "--exact",
        "--nocapture",
    ],
)
assert "1 passed; 0 failed" in (OUT / "actual-weight-incremental.log").read_text()
check("same-weight-wasm", ["node", str(OUT / "cases-and-wasm.mjs"), str(OUT), "evaluate"])
assert not list(tmp.iterdir())
tmp.rmdir()
retained = sum(p.stat().st_size for p in OUT.rglob("*") if p.is_file())
assert retained <= CONFIG["evidenceBytes"], retained
(OUT / "qualification.json").write_text(
    json.dumps(
        dict(
            config=CONFIG,
            census=census,
            completed=completed,
            retainedBytes=retained,
            scope="Original generic oracle equality, actual-weight incremental/undo/pass, native/Wasm generic and scalar-SIMD interpretation equality. Actual upstream SIMD numerical entry/search/strength/browser remain UNRUN.",
        ),
        indent=2,
    )
    + chr(10)
)
print(
    json.dumps(
        dict(census=census, completed=completed, retainedBytes=retained, search=0, teacher=0, fit=0)
    )
)
