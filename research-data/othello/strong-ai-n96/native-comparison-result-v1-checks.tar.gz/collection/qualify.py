"""Audit all original comparison records and replay only recorded moves, never search or RNG."""

from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import statistics
import time

from othello_arena.__main__ import checked_spec, comparison_bindings, comparison_families
from othello_arena.matches import _normal_comparison_game
from othello_arena.protocol import Native, Process

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
DATA = ROOT / ".worktree/assets/data/othello-native-comparison-n96-v1"
binding = json.loads((DATA / "matches-bindings.json").read_bytes())


def ref(p):
    b = p.read_bytes()
    return dict(
        path=str(p),
        bytes=len(b),
        mode=f"{p.stat().st_mode & 0o777:04o}",
        sha256=hashlib.sha256(b).hexdigest(),
    )


for row in binding["source"] + [binding["config"], binding["openings"], binding["openingConfig"]]:
    assert ref(Path(row["path"])) == row
config = json.loads(Path(binding["config"]["path"]).read_bytes())
evaluations = comparison_bindings(config)
families = comparison_families(config)
by_id = {f["id"]: f for f in families}
assert len(by_id) == 16
games = [json.loads(line) for line in (DATA / "matches/games.jsonl").read_text().splitlines()]
report = json.loads((DATA / "matches/result.json").read_bytes())
summary = report["comparison"]
assert report["failure"] is None and len(games) == 32
assert len({(g["family"], g["candidateSide"]) for g in games}) == 32
assert Counter(g["family"] for g in games) == Counter({f: 2 for f in by_id})
assert all(g["opponent"] == "v1-heuristic" for g in games)
assert all(_normal_comparison_game(g, by_id[g["family"]], evaluations) for g in games)
assert len(report["cleanup"]) == 3 and len(report["setupShutdown"]) == 3
assert all(
    r["directReaped"] and not r["errors"] and not r["unexpectedExit"] for r in report["cleanup"]
)
assert report["setupShutdown"][1]["initialResponse"]["evaluation"] == evaluations["candidate"]
assert report["setupShutdown"][2]["initialResponse"]["evaluation"] == evaluations["opponent"]
for role in report["setupShutdown"]:
    for key in ["launchValidationMs", "launchWallMs", "readyWallMs", "shutdownWallMs"]:
        assert isinstance(role[key], (int, float)) and role[key] >= 0
for spec in [config["rules"], config["candidate"], config["opponents"][0]]:
    checked_spec(spec)

process = Process(
    config["rules"]["argv"],
    cwd=config["rules"]["cwd"],
    log=OUT / "rules-replay.log",
    cancelled=lambda: (OUT / "CANCEL").exists(),
)
native = Native(process)
phase_metrics = defaultdict(list)
counts = Counter()
points = defaultdict(list)
transitions = 0
try:
    for game in games:
        state = native.request("new", deadline=time.monotonic() + 5)["state"]
        opening = by_id[game["family"]]
        for index, entry in enumerate(game["moves"]):
            status = native.request("status", state=state, deadline=time.monotonic() + 5)["status"]
            assert not status["terminal"] and entry["side"] == state["toMove"]
            move = entry["move"]
            if move is None:
                assert status["mustPass"] and not status["legalMoves"]
            else:
                assert not status["mustPass"] and move in status["legalMoves"]
            if not entry["opening"] and move is not None:
                role = "candidate" if state["toMove"] == game["candidateSide"] else "v1Heuristic"
                occupied = sum(x != 0 for x in state["board"])
                phase = min(3, max(0, occupied - 4) // 15)
                phase_metrics[(role, phase)].append(entry)
            state = native.request(
                "pass" if move is None else "play",
                state=state,
                deadline=time.monotonic() + 5,
                **({} if move is None else dict(move=move)),
            )["state"]
            transitions += 1
            if index + 1 == len(opening["moves"]):
                assert state == opening["state"]
        terminal = native.request("status", state=state, deadline=time.monotonic() + 5)["status"]
        assert state == game["state"] and terminal == game["status"] and terminal["terminal"]
        difference = terminal["black"] - terminal["white"]
        assert difference == game["blackMinusWhite"]
        oriented = difference * (1 if game["candidateSide"] == 1 else -1)
        score = 1 if oriented > 0 else 0 if oriented < 0 else 0.5
        assert score == game["candidateScore"]
        counts[score] += 1
        points[game["family"]].append(score)
finally:
    process.close()
    (OUT / "rules-replay-cleanup.json").write_text(json.dumps(process.cleanup, indent=2) + "\n")
assert process.cleanup["directReaped"] and not process.cleanup["errors"]
means = {family: sum(points[family]) / 2 for family in by_id}
assert means == summary["familyMeans"] and sum(means.values()) / 16 == summary["familyMeanScore"]
assert (
    summary["wins"] == counts[1]
    and summary["draws"] == counts[0.5]
    and summary["losses"] == counts[0]
)
assert (
    summary["completed"] == summary["knownGames"] == 32
    and summary["unknownGames"] == summary["unrun"] == 0
)
assert summary["failures"] == summary["invalidResults"] == [] and summary["ciEligible"] is True
assert summary["bootstrap"]["seed"] == 2026102203 and summary["bootstrap"]["resamples"] == 10000
assert (
    summary["familyBootstrap95"][1] < 0.5
    and summary["acceptance"] is False
    and summary["conclusion"] == "unsupported"
)
# Bootstrap is NOT recomputed here: the fixed arena performed it once.
metrics = []
for (role, phase), entries in sorted(phase_metrics.items()):
    heuristic = [e for e in entries if e["search"]["scoreKind"] == "heuristic"]
    metrics.append(
        dict(
            role=role,
            phase=phase,
            searches=len(entries),
            sumWallMs=sum(e["wallMs"] for e in entries),
            maxWallMs=max(e["wallMs"] for e in entries),
            medianCompletedDepth=statistics.median(e["search"]["completedDepth"] for e in entries),
            nodes=sum(e["search"]["nodes"] for e in entries),
            proven=sum(e["search"]["proven"] for e in entries),
            normalBudgetTimedOut=sum(e["search"]["timedOut"] for e in entries),
            heuristicCount=len(heuristic),
            zeroHeuristicSearchScores=sum(e["search"]["score"] == 0 for e in heuristic),
        )
    )
result = dict(
    scope="Original32/16 complete-pair, identity/clock/terminal audit and recorded-move replay only. No new search/game/RNG/fit.",
    data=[
        ref(DATA / p)
        for p in [
            "matches/games.jsonl",
            "matches/result.json",
            "matches-config.json",
            "matches-bindings.json",
        ]
    ],
    originalJob=json.loads((DATA / "runtime-matches/result.json").read_bytes()),
    originalCommand=json.loads((DATA / "matches-returned-STOP.json").read_bytes()),
    summary=summary,
    transitionsReplayed=transitions,
    rulesReplayCleanup=process.cleanup,
    phaseMetrics=metrics,
    scoreMeaning="zeroHeuristicSearchScores are returned search scores, not static-evaluator outputs or a causal explanation.",
    bootstrapRegenerated=False,
    independentConclusionReview="pending",
    H="Only root identity exclusion; no H trajectory/labels/features/loss/selector.",
    decision="Keep current v1 and product default. This candidate improvement unsupported in these16devfamilies; not equivalence or general pattern-learning impossibility.",
    RSSpeak_B=None,
    browserStrength="UNVERIFIED",
)
(OUT / "qualification.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        dict(
            originalGames=32,
            originalPairs=16,
            rulesReplayTransitions=transitions,
            summary=summary,
            searchRNGFitCalls=0,
        )
    )
)
