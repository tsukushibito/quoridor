**QUALIFIED FOR THE LIMITED DEV CONCLUSION — quoridor-n96.1.8**

No concrete blocker found. The original fixed32 games qualify for the predeclared16-family statistic. Their result supports the limited decision that improvement by candidate model7ed9 versus v1 is unsupported under these native development conditions. Keep v1/product defaults. This is not equivalence, a general impossibility result for pattern learning, a causal explanation of the loss, or a browser-strength result.

The independent recount is3W/2D/27L,4 points/32=.125, with16 complete both-color family means. The recorded original percentile interval is [.03125,.234375]; its upper endpoint is below.5, satisfying the predeclared “unsupported” branch. No bootstrap/RNG was regenerated and no target comparison_summary, search, game, replay, test or build was executed by this reviewer.

**Exact target identities**

Base D: `/workspaces/quoridor/.worktree/assets/data/othello-native-comparison-n96-v1`.
Base A: `/workspaces/quoridor/.artifacts/research-team/integration324/othello-strong-ai-n96`.

All eight supplied FileRefs matched bytes/mode/SHA256 before parsing and at the final identity check; full refs are in receipt.json:

| Artifact | Bytes / mode | SHA256 |
| --- | --- | --- |
| D/matches-config.json | 5182 /0644 | dbd33d6b7d856c541558bc0ef499c661c1719ad3e9a79c56473081d0632cbcf3 |
| D/matches-bindings.json | 2958 /0644 | 68116a15a0b7d6c86520d49e715ae35bd9a971712535117f6a3e7879420f569f |
| D/matches/games.jsonl | 602853 /0644 | 6cedf76fb5d47d9408a08dcf41d0e0a1f975fce45df34c6888eb77a03ca10d35 |
| D/matches/result.json | 9328 /0644 | 6a03acd4f628a74b55afed05980f29d64b4e5ca589120e21a7c630e879309525 |
| D/runtime-matches/result.json | 522 /0600 | 9bc46b9327e03833432182232f823c78fde4a7514bb64e0f00cf539801343827 |
| D/matches-returned-STOP.json | 3274 /0644 | f7aa3d7187f9aa40b269b14debd843bccefd569156b96170b55c238a34bb5e05 |
| A/native-comparison-collection-v1/qualification.json | 10644 /0644 | 608ddc13782a7f878f99429141631d4d19a558d9a404e65e1c91d6cb75bf6a6d |
| research-data/othello/strong-ai-n96/native-comparison-software-v1.json | 6971 /0644 | 5af3b491bde1cab964feebdad073678bdb961678b94e3f8dffffe3f9e61a2f54 |

All eight source refs in matches-bindings also match current Main bytes/mode/SHA. The relevant accepted source files below are under `games/othello/python/othello_arena/`:

- __main__.py:14103B/0644/`a4a1430a5d8193064c0caf5dbd2ffcf3bdac816beb05a1d3c96fc4ee9e11c1a7`.
- matches.py:12684B/0644/`f2205e01b3ca7fbc4a95ba4d7170251f13935e43eebd72695b15a659ecab04ad`.
- engines.py:6177B/0644/`4c991fb6ab7410f0fb772be8c17bb96d50c179c4998daa27e62be6b7936278ef`.
- protocol.py:8474B/0644/`6f4b7ffa8b4e662d22a15e85d4cc00c88bc60aff0f22d4844110cfe6be90b1f5`.
- generation.py:32175B/0644/`e56e71602e007fc6cf3cb9bf1ece3061c0576b897707eb4e8e1f052b91a1261f`.

The original launch binds sourceCommit cd5527c3182796a77d4be1bf462ac1fcaa567632. Source is identified by those exact files, not an assumption about mutable Main. Unchanged pattern/teacher source was identity-checked only; its math was not re-reviewed.

**Identity and clock qualification**

D/run-matches.py:14–23 verifies source, matches config, opening config and frozen openings bytes/mode/SHA before launching. It consumes the fixed CPUPlan and existing CycleResources/execute with2400s whole-operation,32MiB output bound, F1GiB including controller reserve, host4GiB, CANCEL, pilot CPU16/management18, library1/GPU0 (29–72). Runtime config selects that script. D/matches/config.json equals the frozen matches-config object.

__main__.py:44–126 requires one same-image native opponent, the exact shared2678 image identity800888B/0755, identical cwd/profile, rules/opponent no arguments, and candidate arguments exactly --pattern MODEL --model-id sha256:HASH with that model as its single asset. Only evaluator selection differs. Config and Native.choose agree on requested1000ms, TT32MiB upper, depth64/exact12, single thread, no book/ponder/simple policy or aggregate node cap (`protocol.py:215–219`). The shared PVS/clock/TT/exact implementation was unchanged, not rerun here.

At each actual process start, checked_spec validates executable and asset SHA/bytes/mode before Process construction (__main__.py:17–40,187–205). The candidate model ref is16161B/0644/SHA256 `7ed9fa38218f591d80cfa10f985d510635eaddcd9e2f530e3f778b16b052bd9a`; this review did not read/hash its body. Original startup and retained Root qualification supply that binding under immutable-config custody. Native model identity is explicitly callerVerified: engine did not compute/verify a SHA itself.

Candidate and opponent each initialize once outside move clocks; initial evaluate identities match the exact candidate pattern ID/bytes/callerVerified object and opponent {kind:v1Heuristic}. The manual raw-record audit checked every817 candidate and847 opponent search response against those identities, success/field types, matching move, non-cancelled result, and score-kind/proven consistency. No selection drift or missing search evidence was found. Normal timedOut:true is engine budget exhaustion, not a failed match.

matches.py:78–97 starts a monotonic send/response envelope after prepare, independently rejects wall>1100ms and illegal replies, and retains response evidence in finally. Protocol checks deadlines even for buffered lines (`protocol.py:53–57,104–123`). All actual retained search walls were finite and within1100ms; maxima were1004.257543ms candidate and1004.366125ms v1. Nominal1s is not a claim of zero clock overshoot: retained internal maxima were1000.580826ms and1001.563008ms. The outer1100ms rule accepted both. This is measured request/search timing, not an instantaneous or static evaluator benchmark.

Setup evidence separates validation, process launch, inclusive readiness and shutdown. Inclusive ready includes native/model initialization and transport, not pure model parsing. In role order rules/candidate/opponent, readyWallMs were .940001/.794242/.635674; launchValidationMs .513073/.452395/.463183; launchWallMs .348691/.644320/.498195; shutdownWallMs .180586/.243868/1.413672. Do not sum launch+inclusive-ready as independent disjoint costs or interpret candidate readiness as a model-only timer.

**All original games/pairs and terminal orientation qualify**

The frozen16-family schedule is played exactly once in frozen order, candidate black then white (`matches.py:131–148`). Both side slots occur once per family, all opponent IDs match, no duplicate/foreign/missing slots, failures, replacements or unrun games were found. First-bad STOP is enforced in paired and __main__.py:263–286; the complete original schedule did not take a success-only subset.

The manual audit checked every retained final board's actual black/white cell counts, terminal status/winner, blackMinusWhite, candidate-side orientation and score. All32 final boards are full; each uses actual Rust disc counts. Candidate score is1/0/.5 from blackMinusWhite times +1 for black and -1 for white (`matches.py:59–69`). No external teacher score, empty-square allocation or heuristic search score was substituted for terminal outcome.

The Root collection qualification's exact data refs bind the same original records. Its retained qualify.py:69–106 replays recorded new/status/play/pass only, checking every legal/pass transition, each frozen opening state, final state/status and oriented score. It contains no call to search, comparison_summary or RNG. Existing audit-recorded-games returned exit0/cleanup true/remaining empty;1961 transitions were replayed. Its replay process was directly reaped with no errors/unexpected exit. This reviewer only inspected that evidence; no native replay was repeated.

Manual counts reconcile1961 transitions =256 opening placements +1664 searched placements +41 forced passes. Forced passes have wall0 and no fabricated search. Independent per-family recount, suffixes001–016 in the frozen namespace:

| Family | Candidate black | Candidate white | Pair mean |
| --- | ---: | ---: | ---: |
| 001 | 0 | 0 | 0 |
| 002 | 1 | 0 | .5 |
| 003 | .5 | 0 | .25 |
| 004 | 0 | 0 | 0 |
| 005 | 0 | 1 | .5 |
| 006 | 0 | 0 | 0 |
| 007 | 0 | 0 | 0 |
| 008 | 0 | 0 | 0 |
| 009 | 0 | 0 | 0 |
| 010 | 0 | 0 | 0 |
| 011 | 0 | 1 | .5 |
| 012 | 0 | 0 | 0 |
| 013 | 0 | 0 | 0 |
| 014 | 0 | 0 | 0 |
| 015 | 0 | .5 | .25 |
| 016 | 0 | 0 | 0 |

These means equal the original report exactly; sum of means2/16=.125 equals points4/32. No score/bootstrap calculation from a completed-pair subset was used.

Original job07789c7f-edfa-4d01-9e10-2d3bba8c55ad succeeded, finished2026-10-21T21:06:02.527593Z, outer1159.073003907s, exit0/direct child reaped/remaining[]/cleanup true. Original command returned1158.709165507s, completed handles/signal restoration/final persistence, no errors; its disk snapshot remains pending/attempted for the last two fields. All three persistent engine cleanup records show directReaped true, errors[], unexpectedExit false. Their exitCode -15 is the deliberate Process.close termination, not an unexpected crash. CI eligibility is evaluated after ExitStack cleanup (__main__.py:293–325). Root's later audit also returned complete cleanup; its separate disk snapshot retains pending/attempted fields.

**Frozen roots and exclusion meaning**

Verified openingConfig6971B/0644/SHA `5b1a6827335461eb44aa71d1315bb1a6035ab449716a126a9b2da038009d8a21` and openings9147B/0644/SHA `72949316036cceb05e763cb7afdc53e748157c4d6846aeba68eec5e32fd67d4e`. They declare seed2026102202,16 D slots, eight placements, complete unlabeled roots,17 preparation attempts with one equivalence rejection, no result-driven refill. Sixteen canonical identity hashes are distinct.

comparison_families (__main__.py:129–145) verifies preparation/image/canonical/exclusion bindings and frozen actual slots; generation.py:191–201,250–292 checks exclusion counts, canonical duplicates and exact root identities. Root's existing collection calls this guard before replay. All prior4 smoke,24 tiny and128 teacher-opening FileRef size/mode/SHA identities matched during this review. The128/H-containing file body was not parsed or featured; only identity hashing was performed. No H trajectory, labels, evaluation, feature/loss/selector work was issued.

Interpret these as distinct D4/color/STM development roots, excluding those prior root identities. Shared prefixes and later trajectories can correlate. This does not prove IID games/families, lifetime-unseen positions, disjoint future paths, or a population-level generalization guarantee.

**Predeclared bootstrap and conclusion**

Canonical native-comparison-software-v1.json fixes original32/16, seed2026102203,10000 family resamples and R7(.025,.975) before the run. Accepted matches.py:234–327 implements that method: require exactly16 unique frozen families, exactly32 unique valid original side slots, all setup/cleanup qualified; otherwise retain the32 denominator and unknown bounds with no CI/means/acceptance. It averages the two colors per family, then uses a local Python random.Random MT19937 seed, resampling16 family means with replacement10000 times. Sorted index (10000-1)*p is linearly interpolated. Decision is supported only if lower>.5, unsupported if upper<.5, otherwise unresolved. __main__.py calls the summary once at finalization and aliases that summary under byOpponent; Root's collection does not recompute it.

Source-bound analytic fixture evidence was inspected, not rerun: `games/othello/tests/python/test_arena_native_comparison.py:236–261` uses prescribed draw blocks, checks160000 draws and R7 endpoints .4875/.5125;582–628 checks constant cases and denies RNG for incomplete/failed/duplicate/foreign/late/identity-mismatched/cleanup-unqualified schedules. Existing canonical5+6+3 invocation receipts/logs support13 unique focused methods (one affected repeat), all exit0/cleanup true/remaining[]; disk restoration/persistence remain pending/attempted. Earlier failed lint remains preserved.

The recorded original [.03125,.234375] is accepted as that qualified original computation. Its random samples/percentiles were intentionally not independently reproduced. With16 empirical family clusters, a percentile interval is a finite development statistic with small-sample/coverage/correlation limitations; its “95%” label is not a guarantee of population coverage or a probability that this candidate is inferior everywhere.

Accordingly: **this specific candidate's improvement is unsupported against no-args v1 under the fixed native development setup; retain v1 and current product defaults.** The observed low score and wholly sub-.5 recorded interval warrant that limited decision. They do not establish equivalence, universal inferiority, failure of all pattern learning, browser performance, or why the candidate lost. Model selection provenance (“teacher quantized-V best epoch10”) is a frozen config declaration here; teacher/training payloads and its broader model-selection history were outside scope.

Phase NPS/depth/proven/zero-score diagnostics are descriptive. Returned search scores combine evaluation, search horizon, possible exact terminal values and visited positions; zeros are not static-evaluator outputs. Unequal visited positions/nodes/depth under two evaluators do not establish a causal mechanism.

**Remaining limits and execution receipt**

RuntimeRSSpeak remains UNKNOWN/null; bounded successful execution is not a measured peak. Fair-timing resource custody is recorded in the original launch contract; this review does not certify all-host quiet or future scheduling. Browser strength, external-engine superiority, held-out generalization and new model/default adoption remain unverified. No new experiment/reply/ACK gate or framework is requested.

Saved actual context at2026-10-21T21:13:30.264Z matched original Sol6.1/high/Main/full-never before ordinary work. Exact original CPUPlan187B/0644/SHA `a1dfa82ca524ceeed1131526c90b0372bbb18e3dff42b1e64857a1b3504abe87` was verified before parsing and used unchanged through CPUPlan.from_record. Existing CycleResources/execute used review6/management18, library1/GPU0, conservative960MiB family RSS guard plus64MiB controller reserve within1GiB, host4GiB, <=180s per reader, explicit OWN CANCEL, bounded logs and direct wait/reap/handle cleanup. Controller RSS was checked before/after each check.

One orchestration attempt found an unavailable in-memory helper and aborted before ordinary commands; the same existing runtime controls were then defined locally. One evidence-reading helper raised KeyError by assuming the collection return file embedded a disk field; the actual disk record was subsequently read from its separate process file. No scientific operation occurred in either failure. Its error/process/cost and full capture digest are retained as FAILED in receipt, while transient source captures are removed after actual readers return.

All exact original refs/source identities were rechecked. No target summary/bootstrap/scientific RNG, native/Wasm/build/test, search/new game/replay, model/body/hash, training/teacher payload, H feature/loss, agent, source/Git/index/Cargo mutation, old-review replay or permanent data mirror was issued. Only authorized raw records/metadata/source were inspected and derived counts reported. Reader/helper STOP and one own affected-storage point are in receipt; actual returned completion is kept distinct from pending disk snapshots. Old n96.1.3/.4/.7, prior failures/costs, Quoridor pauses/seals/defaults/models and decimal50GB remain untouched. Root owns acceptance; no self-close or standing watcher.
