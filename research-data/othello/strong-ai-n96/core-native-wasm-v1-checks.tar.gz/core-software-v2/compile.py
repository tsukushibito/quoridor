"""One finite related Othello core qualification through the existing executor."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import time

from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus, execute

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
WT = ROOT / ".worktree/othello-core-n96"
TARGET = (
    ROOT
    / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/target"
)
EXPECTED = {
    "lib.rs": "451943acd93b73aab78d6e819bcdf12771b2985bdd7055bd9759a37bb446629b",
    "bitboard.rs": "c995c904587deaf33d3b27c762b7e73ed579b2e9ff8a3a731cf5b58001771fd4",
    "heuristic.rs": "6dd62ea17ff06675c1e2d8d5a0453530e32588d469bf6aaae5a14e72ab5244b8",
    "search.rs": "7f971fbeb5c550e4e2d981a9fcb45fdfee2194c83628d6e554f4c7e7355ba968",
    "search/tests.rs": "98db4711d1ba929e394204edb89c36f2243b4c825056d3cdd632f0d10936c11b",
    "bin/othello-engine.rs": "dff67c7e43a788c50a8307186b192f167d463bec95f81d769d0217d38b160292",
}


def source_refs():
    refs = []
    for relative, expected in EXPECTED.items():
        p = WT / "games/othello/crates/othello-core/src" / relative
        b = p.read_bytes()
        sha = hashlib.sha256(b).hexdigest()
        assert sha == expected, relative
        refs.append(
            dict(path=str(p), sha256=sha, bytes=len(b), mode=f"{p.stat().st_mode & 0o777:04o}")
        )
    return refs


plan = CPUPlan([18], {"software": [0]}, library_threads=1)
plan.check_host(available_cpus())
plan.apply()
assert (
    int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
    <= 64 * 1024**2
)
owner = json.loads((TARGET / ".research-owner.json").read_bytes())
assert owner["writer"] == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
refs = source_refs()
(OUT / "source-before.json").write_text(json.dumps(refs, indent=2) + "\n")
tmp = OUT / "TMP"
tmp.mkdir()
env = dict(
    os.environ,
    CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS="1",
    CARGO_INCREMENTAL="0",
    CARGO_NET_OFFLINE="true",
    CARGO_PROFILE_DEV_DEBUG="0",
    CARGO_PROFILE_TEST_DEBUG="0",
    CARGO_PROFILE_RELEASE_DEBUG="0",
    CARGO_PROFILE_RELEASE_LTO="false",
    CARGO_PROFILE_RELEASE_OPT_LEVEL="3",
    RUSTFLAGS="-C debuginfo=0",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    CUDA_VISIBLE_DEVICES="",
    PYTHONDONTWRITEBYTECODE="1",
    TMPDIR=str(tmp),
)
cargo = "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo"
common = ["--offline", "--locked", "--manifest-path", str(WT / "Cargo.toml")]
commands = [
    (
        "native-cli-test",
        [
            cargo,
            "test",
            *common,
            "-j1",
            "-p",
            "othello-core",
            "--bin",
            "othello-engine",
            "--",
            "--test-threads=1",
        ],
    ),
    (
        "core-clippy",
        [
            cargo,
            "clippy",
            *common,
            "-j1",
            "-p",
            "othello-core",
            "--all-targets",
            "--",
            "-D",
            "warnings",
        ],
    ),
    (
        "native-release",
        [
            cargo,
            "build",
            *common,
            "-j1",
            "--release",
            "-p",
            "othello-core",
            "--bin",
            "othello-engine",
        ],
    ),
]
completed = []
for name, argv in commands:
    deadline = time.monotonic() + 600
    resources = CycleResources(
        dict(
            max_memory_bytes=4 * 1024**3 - 64 * 1024**2,
            host_ram_reserve=4 * 1024**3,
            pause_file=str(OUT / "CANCEL"),
        ),
        OUT,
        deadline,
    )
    returned = None
    error = None
    try:
        returned = execute(
            argv,
            OUT / (name + ".log"),
            deadline,
            resources=resources,
            cpu_plan=plan,
            cpu_scope="software",
            cwd=WT,
            env=env,
        )
    except BaseException as caught:
        error = dict(type=type(caught).__name__, message=str(caught))
    finally:
        disk = OUT / (name + ".process.json")
        (OUT / (name + ".returned.json")).write_text(
            json.dumps(
                dict(
                    returned=returned,
                    error=error,
                    disk=json.loads(disk.read_bytes()) if disk.exists() else None,
                ),
                indent=2,
            )
            + "\n"
        )
    assert (
        error is None
        and returned["exit_code"] == 0
        and returned["remaining"] == []
        and returned["process_cleanup_complete"]
        and returned["handle_closes_complete"]
    ), (name, error)
    if name == "metadata":
        metadata = json.loads((OUT / "metadata.log").read_text())
        package = next(p for p in metadata["packages"] if p["name"] == "othello-core")
        assert Path(package["manifest_path"]) == WT / "games/othello/crates/othello-core/Cargo.toml"
        assert all(
            Path(t["src_path"]).is_relative_to(WT / "games/othello/crates/othello-core")
            for t in package["targets"]
        )
    completed.append(
        dict(name=name, exit_code=returned["exit_code"], wall_seconds=returned["wall_seconds"])
    )
    (OUT / "completed-commands.json").write_text(json.dumps(completed, indent=2) + "\n")
assert source_refs() == refs
image = TARGET / "release/othello-engine"
b = image.read_bytes()
sha = hashlib.sha256(b).hexdigest()
dest = OUT / ("image-" + sha) / "othello-engine"
dest.parent.mkdir()
shutil.copy2(image, dest)
assert dest.read_bytes() == b
result = dict(
    source=refs,
    completed=completed,
    image=dict(path=str(dest), sha256=sha, bytes=len(b), mode=f"{dest.stat().st_mode & 0o777:04o}"),
    scope="causal CLI-only qualification plus previously unentered Clippy/release; original v1 actual24 library PASS retained without replay; no Quoridor suite/strength claim",
    cpu_plan=plan.record(),
    family_B=4 * 1024**3,
    host_reserve_B=4 * 1024**3,
    source_unchanged=True,
)
(OUT / "qualification.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(dict(completed=completed, image=result["image"])))
