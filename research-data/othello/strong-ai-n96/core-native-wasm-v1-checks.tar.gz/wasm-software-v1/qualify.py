"""Qualify only changed Othello Wasm and its same-source native parity."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import time

from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus, execute

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
WT = ROOT / ".worktree/othello-core-n96"
TARGET = (
    ROOT
    / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/target"
)
NATIVE = json.loads((OUT.parent / "core-software-v3/qualification.json").read_bytes())
EXPECTED = {
    "games/othello/crates/othello-wasm/src/lib.rs": "440be7018f8df4628c1892d6a00eedd2d312dd17e5ca9d7446c21c461d6a459a",
    "games/othello/bridge/src/index.ts": "a1da079f83cb294941ccd8b99e83625188e0f1503ac8a80ac51479f5084d38b6",
    "games/othello/bridge/src/wasm.d.ts": "801bef72a6f9b60ea4e9fbf96bb88dea42548d03ea1c11aef363a342176207a6",
    "games/othello/bridge/test/facade.test.mjs": "c1af1a687d75a9e38d4f4a31fa72d74a0f0a4f7e36d6f542b3fdacd4c65dd7cf",
    "games/othello/bridge/test/wasm.test.mjs": "40ce275143e6482571a4da5bf228ed323e672e2e9b01cbbf5dce197969c5327b",
    "games/othello/bridge/README.md": "a98d69f68a92880fa8c9bf21e57f5edb1c7575e06059660259e80a8465f94030",
}


def refs():
    result = []
    for name, sha in EXPECTED.items():
        p = WT / name
        b = p.read_bytes()
        assert hashlib.sha256(b).hexdigest() == sha, name
        result.append(
            dict(path=str(p), sha256=sha, bytes=len(b), mode=f"{p.stat().st_mode & 0o777:04o}")
        )
    for row in NATIVE["source"]:
        assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["sha256"]
    return result


source = refs()
(OUT / "source.json").write_text(json.dumps(source, indent=2) + "\n")
plan = CPUPlan([18], {"software": [0]}, library_threads=1)
plan.check_host(available_cpus())
plan.apply()
assert (
    int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
    <= 64 * 1024**2
)
assert (
    json.loads((TARGET / ".research-owner.json").read_bytes())["writer"]
    == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
)
tmp = OUT / "TMP"
tmp.mkdir()
env = dict(
    os.environ,
    CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS="1",
    CARGO_INCREMENTAL="0",
    CARGO_NET_OFFLINE="true",
    CARGO_PROFILE_DEV_DEBUG="0",
    CARGO_PROFILE_TEST_DEBUG="0",
    RUSTFLAGS="-C debuginfo=0",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    CUDA_VISIBLE_DEVICES="",
    PYTHONDONTWRITEBYTECODE="1",
    TMPDIR=str(tmp),
    OTHELLO_NATIVE_ENGINE=NATIVE["image"]["path"],
)
cargo = "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo"
completed = []


def check(name, argv):
    deadline = time.monotonic() + 600
    resources = CycleResources(
        dict(
            max_memory_bytes=4 * 1024**3 - 64 * 1024**2,
            host_ram_reserve=4 * 1024**3,
            pause_file=str(OUT / "CANCEL"),
        ),
        OUT,
        deadline,
    )
    returned = None
    error = None
    try:
        returned = execute(
            argv,
            OUT / (name + ".log"),
            deadline,
            resources=resources,
            cpu_plan=plan,
            cpu_scope="software",
            cwd=WT,
            env=env,
        )
    except BaseException as caught:
        error = dict(type=type(caught).__name__, message=str(caught))
    finally:
        disk = OUT / (name + ".process.json")
        (OUT / (name + ".returned.json")).write_text(
            json.dumps(
                dict(
                    returned=returned,
                    error=error,
                    disk=json.loads(disk.read_bytes()) if disk.exists() else None,
                ),
                indent=2,
            )
            + "\n"
        )
    assert (
        error is None
        and returned["exit_code"] == 0
        and returned["remaining"] == []
        and returned["process_cleanup_complete"]
        and returned["handle_closes_complete"]
    ), (name, error)
    completed.append(dict(name=name, wall_seconds=returned["wall_seconds"]))
    (OUT / "completed.json").write_text(json.dumps(completed, indent=2) + "\n")


check(
    "wasm-clippy",
    [
        cargo,
        "clippy",
        "--offline",
        "--locked",
        "--manifest-path",
        str(WT / "Cargo.toml"),
        "-j1",
        "-p",
        "othello-wasm",
        "--all-targets",
        "--",
        "-D",
        "warnings",
    ],
)
check(
    "wasm-build",
    [
        "wasm-pack",
        "build",
        str(WT / "games/othello/crates/othello-wasm"),
        "--target",
        "web",
        "--dev",
        "--out-dir",
        str(OUT / "generated"),
        "--out-name",
        "othello",
        "--locked",
        "--no-default-features",
    ],
)
inputs = []
destination = WT / "games/othello/bridge/wasm"
destination.mkdir(exist_ok=True)
for name in ["othello.js", "othello.d.ts", "othello_bg.wasm", "othello_bg.wasm.d.ts"]:
    p = OUT / "generated" / name
    d = destination / name
    assert not d.exists()
    shutil.copy2(p, d)
    b = p.read_bytes()
    assert d.read_bytes() == b
    inputs.append(
        dict(
            path=str(d),
            source=str(p),
            sha256=hashlib.sha256(b).hexdigest(),
            bytes=len(b),
            mode=f"{d.stat().st_mode & 0o777:04o}",
        )
    )
(OUT / "generated-inputs.json").write_text(json.dumps(inputs, indent=2) + "\n")
check(
    "real-wasm-native-parity",
    ["node", "--test", str(WT / "games/othello/bridge/test/wasm.test.mjs")],
)
(OUT / "url.d.ts").write_text(
    "declare module '*.wasm?url' { const url: string; export default url; }\n"
)
config = dict(
    compilerOptions=dict(
        target="ES2022",
        module="ESNext",
        moduleResolution="Bundler",
        strict=True,
        noEmit=True,
        skipLibCheck=True,
        lib=["ES2022", "DOM"],
    ),
    files=[str(WT / "games/othello/bridge/src/index.ts"), str(OUT / "url.d.ts")],
)
(OUT / "tsconfig.json").write_text(json.dumps(config, indent=2) + "\n")
check(
    "real-generated-typecheck",
    [str(ROOT / "node_modules/.bin/tsc"), "-p", str(OUT / "tsconfig.json"), "--listFiles"],
)
listed = (OUT / "real-generated-typecheck.log").read_text()
assert str(WT / "games/othello/bridge/wasm/othello.d.ts") in listed
assert str(WT / "games/othello/bridge/src/wasm.d.ts") not in listed
assert refs() == source
(OUT / "qualification.json").write_text(
    json.dumps(
        dict(
            source=source,
            core_source=NATIVE["source"],
            generated=inputs,
            native_image=NATIVE["image"],
            completed=completed,
            scope="real changed Othello Wasm clock/export/JSON/native parity and generated-declaration typing; no Quoridor tests/build or browser/strength claims",
        ),
        indent=2,
    )
    + "\n"
)
print(json.dumps(dict(completed=completed, generated=inputs)))
