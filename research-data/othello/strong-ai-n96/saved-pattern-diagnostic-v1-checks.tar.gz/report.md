# 元896教師行・元32局の保存診断

original candidate7ed9 / native2678。元32局の3W2D27L・score .125・既存family CI [.03125,.234375] は不変。
追加 search/teacher/fit/game/RNG/CI は0。896行（T768/V128）と元1961 pre-move状態だけを使用し、各 native static2857回、計5714回。H16は feature/label/loss に入れていない。

## 値の意味と static 誤差

全896行で target=rawSTMScore*100、state.toMove 視点を維持し、白の再反転はしなかった。518 engine_estimate_stm と378 engine_exact_winner_empties_stm はともに teacherEstimate。外部終盤値は空きを勝者へ割り当て、native exactの実石差とは異なる。
native evaluate は両者とも heuristic STM centidiscs/proven:false。patternは±6400でclamp、v1静的式にはclamp自体がない。この入力では両者とも±6400境界に到達していない。
Vは元のmodel選択集合であり、独立の強さ評価ではない。誤差の良さを対局改善と同一視しない。

| split | n | candidate MSE | v1 MSE | candidate MAE | v1 MAE | sign一致 candidate/v1 |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| T | 768 | 1067842.289062 | 3769169.552083 | 786.065104 | 1505.401042 | 643/768 ; 539/768 |
| V | 128 | 2770099.531250 | 3063322.031250 | 1310.546875 | 1228.453125 | 78/128 ; 84/128 |

V-MSE 2770099.53125は元BESTの記録と一致した。V-MAEはcandidate1310.546875/v1 1228.453125、符号一致は78/128対84/128。MSE・MAE・符号は異なる性質で、因果的な敗因の証明ではない。
phase、phase×teacher scoreKind、STM黒/白別のMSE/MAE/meanError/sign混同行列/score範囲/境界数は result.json に保存。

## 実 signed feature vector の alias

同一phase＋同一signed sparse vector（係数を含む）だけでgroup化。T/Vを混ぜない。

| split/phase | states | 表現数 | alias内state数 | empty vector | 最大teacher範囲(cdisc) | state加重の群内teacher分散(cdisc²) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| T/0 | 192 | 92 | 121 | 30 | 3200 | 283673.239087 |
| T/1 | 192 | 191 | 2 | 0 | 500 | 651.041667 |
| T/2 | 192 | 191 | 2 | 0 | 2200 | 12604.166667 |
| T/3 | 192 | 192 | 0 | 0 | 0 | 0.000000 |
| V/0 | 32 | 21 | 15 | 3 | 2300 | 169567.708333 |
| V/1 | 32 | 32 | 0 | 0 | 0 | 0.000000 |
| V/2 | 32 | 32 | 0 | 0 | 0 | 0.000000 |
| V/3 | 32 | 32 | 0 | 0 | 0 | 0.000000 |

phase0のT192状態は92表現、V32状態は21表現。Tの最大teacher範囲3200cdisc、V2300cdisc。
illustrativeな4群×2実状態をprivate-alias-examples.jsonに保存した。既存canonical関数で正規化したpattern外の内部セルが異なるものだけを選び、signed vectorは同一。8状態とも元T/V入力の一部で追加評価していない。
これはこの標本の教師分散と表現の区別能力の診断であり、真のminimax値の差や一般的な学習不可能性の証明ではない。

## Tだけを正本とする coverage と元対局の static 0

Tで実観測したparameterは1018/2912、phase別46/190/369/413。signed parameter方向は1554だが、反対符号は同じantisymmetric parameterを共有するので別の未学習parameterとは呼ばない。
下表は32局のopening/passを含む全1961 pre-move状態。nativeの両評価器を各状態で評価した。非0 signed coefficientのID未観測と、(ID,符号)方向未観測を分け、係数の絶対値重み付きhitもJSONへ残した。

| phase | occurrences | T未観測IDを含む状態 | T未観測ID hits | 未観測signed方向 hits | empty vector | candidate static0 | v1 static0 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 480 | 7 | 13 | 17 | 234 | 235 | 66 |
| 1 | 480 | 98 | 213 | 302 | 20 | 20 | 4 |
| 2 | 480 | 203 | 337 | 643 | 0 | 0 | 0 |
| 3 | 521 | 221 | 366 | 778 | 0 | 0 | 0 |

candidate static0は255/1961。そのうち254状態はempty signed vector、残る1状態は非empty vectorだが全lookup項が0。非empty vectorの非0 weighted termsが和0へ相殺した状態は0だった。signed occurrenceの部分相殺はphase別29/213/172/174状態にあり、empty vectorや最終score0とは別に記録した。
これは元32局のdevelopment-observed状態の記述で、最終独立評価でも敗因の因果説明でもない。T未観測の存在だけでゲーム損失の寄与は識別できない。

## 記録済み returned Search と static の区別

元SearchのheuristicはSTM centidiscs、proven discDifferenceはSTM実石差の整数disc単位。異なる単位を混ぜてMSEを作らない。ゼロは下表で同じ実際の探索手に揃えて数えた。

| role/phase/returnedKind | n | その状態のstatic0 | returned Search0 | 両方0 |
| --- | ---: | ---: | ---: | ---: |
| candidate/phase0/heuristic | 112 | 17 | 9 | 4 |
| candidate/phase1/heuristic | 240 | 10 | 4 | 3 |
| candidate/phase2/discDifference | 36 | 0 | 2 | 0 |
| candidate/phase2/heuristic | 204 | 0 | 0 | 0 |
| candidate/phase3/discDifference | 225 | 0 | 15 | 0 |
| v1/phase0/heuristic | 112 | 4 | 2 | 0 |
| v1/phase1/heuristic | 240 | 2 | 0 | 0 |
| v1/phase2/discDifference | 31 | 0 | 3 | 0 |
| v1/phase2/heuristic | 209 | 0 | 1 | 0 |
| v1/phase3/discDifference | 255 | 0 | 15 | 0 |

既存returned heuristicの0はcandidate13/v1 3。これは静的0の個数でも単純な『探索していない』指標でもない。exactの0は実石差drawの別記述。深さ・horizon・solverの効果をこの診断から原因分解していない。

## 入力・復元・費用・STOP

原rows/games/attempt evidenceを各1回streamし、必要なbytes/mode/hashをparse前に確認した。evidenceの独立した事前SHAは既存canonical/prelabel metadataに無く、frozen labelの元teacher-v2 sibling pathを使い、1回のstream snapshot SHAをresolved-config.jsonへparse/evaluate前に固定した。896件すべてをgameId＋同一state＋raw scoreで対応付けた。fresh snapshotを過去の独立hash保証とは呼ばない。
元監査metadata・保存file名にdecoded状態cacheは無かった。Rust new32、play1920、pass41だけでpre-move状態を復元した。status/legal/oracle呼出し0、既存1961監査とfinal-state資格の再実施0。Rust play/pass内部の合法性処理は状態復元に不可避だが、独自ルールは複製していない。
main analysisは679.073524ms、既存execute outerは710.086400ms。native evaluate送受信総和candidate123.049281ms/v1 110.034499msはouterの内数で加算しない。startup through first scheduled evaluateはcandidate1.317142ms/v1 1.137982msで、pure model-parse timerではない。速度公平性の主張はない。
CPU analysis12/controller18・library1・GPU0。観測RSSはcontroller21057536B、全descendants38952960B（最大3: worker＋persistent native2）。family1GiB/hostreserve4GiB、180s、OWN CANCEL/TMP、既存CycleResources/executeを使用。periodic観測で瞬時絶対peakではない。
native2子ともdirectReaped true/errors[]/unexpectedExit false。outer direct_child_reaped/handles/process cleanup true、remaining[]、exit0。disk receiptのsignal-mask restorationはpending/final persist attemptedで、返却final dictをこの実行では保存していないため、そのフィールドを完了へ書き換えない。解析再実行で補わない。
全5714 static成功、失敗0。元32結果・モデル・source/defaultは変更していない。現在SOURCE/INPUT/PROCESS/TMP STOP、Root acceptanceまでissueはin_progress。
