"""One saved-input diagnostic; no search, new trajectories, optimizer or RNG."""

from collections import Counter, defaultdict
from contextlib import ExitStack
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time


def encode(value):
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n"
    ).encode()


def verified(reference, *, fresh_hash=False):
    """One streaming read, verify bytes/mode/hash before parsing; reuse memory buffer."""
    path = Path(reference["path"])
    stat = path.stat()
    assert path.is_absolute() and stat.st_size == reference["bytes"]
    assert f"{stat.st_mode & 0o777:04o}" == reference["mode"]
    digest, chunks = hashlib.sha256(), []
    with path.open("rb") as stream:
        while chunk := stream.read(65536):
            digest.update(chunk)
            chunks.append(chunk)
    data = b"".join(chunks)
    assert len(data) == reference["bytes"]
    actual = dict(reference, sha256=digest.hexdigest())
    if not fresh_hash:
        assert actual["sha256"] == reference["sha256"], str(path)
    return data, actual


def describe(values):
    return {
        "n": len(values),
        "minimum": min(values) if values else None,
        "maximum": max(values) if values else None,
        "mean": sum(values) / len(values) if values else None,
    }


def losses(records):
    result = {"n": len(records), "teacherTarget": describe([r["target"] for r in records])}

    def sign(x):
        return (x > 0) - (x < 0)

    for role in ("candidate", "v1"):
        errors = [r[role] - r["target"] for r in records]
        result[role] = {
            **describe([r[role] for r in records]),
            "MSE": sum(e * e for e in errors) / len(errors),
            "MAE": sum(abs(e) for e in errors) / len(errors),
            "meanError": sum(errors) / len(errors),
            "zeroScores": sum(r[role] == 0 for r in records),
            "exactSignAgreements": sum(sign(r[role]) == sign(r["target"]) for r in records),
            "signConfusion": dict(Counter(f"{sign(r['target'])}:{sign(r[role])}" for r in records)),
            "absScore6400": sum(abs(r[role]) == 6400 for r in records),
            "absScoreOver6400": sum(abs(r[role]) > 6400 for r in records),
            "saturationMeaning": "candidate clamp boundary"
            if role == "candidate"
            else "v1 has no static clamp; boundary count only",
        }
    return result


def main(config_path):
    own = Path(__file__).resolve().parent
    config = json.loads(Path(config_path).read_bytes())
    deadline = float(os.environ["SAVED_DIAGNOSTIC_DEADLINE"]) - 5
    started = time.monotonic()
    report = {
        "status": "STOP",
        "failure": None,
        "counts": Counter(),
        "cost": {},
        "cleanup": [],
        "prohibitedOps": {k: 0 for k in ("search", "simple", "status", "teacher", "fit", "RNG")},
    }
    processes, native, blobs = [], {}, {}
    counts, cost = report["counts"], report["cost"]
    teacher_facts, game_facts = [], []
    t_parameters, t_signed = set(), set()
    feature_groups = defaultdict(list)

    def cancelled():
        return (own / "CANCEL").exists()

    def check():
        if cancelled() or time.monotonic() >= deadline:
            raise RuntimeError("cancel/deadline STOP")

    def request(role, op, **fields):
        check()
        assert op in ("evaluate", "new", "play", "pass")
        counts[f"{role}.{op}.attempts"] += 1
        if op == "evaluate":
            assert counts[f"{role}.evaluate.attempts"] <= 2857
            assert counts["candidate.evaluate.attempts"] + counts["v1.evaluate.attempts"] <= 5714
        report["lastRequest"] = {
            "role": role,
            "op": op,
            "stateOccurrence": counts["stateOccurrences"],
        }
        before = time.monotonic()
        response = native[role].request(op, deadline=min(deadline, before + 5), **fields)
        cost[f"{role}.{op}.wallMs"] = (
            cost.get(f"{role}.{op}.wallMs", 0) + (time.monotonic() - before) * 1000
        )
        counts[f"{role}.{op}.completed"] += 1
        if op == "evaluate":
            assert response.get("evaluation") == config["evaluations"][role]
            assert response.get("scoreKind") == "heuristic" and response.get("proven") is False
            assert type(response["score"]) is int
        return response

    def features(position):
        counts["stateOccurrences"] += 1
        assert counts["stateOccurrences"] <= 2857
        p = pattern.phase(position)
        sparse, codes = pattern.features(position), pattern.codes(position)
        nonself = sum(code != pattern.swap_code(code) for shape in codes for code in shape)
        terms = [
            model["weights"][p][shape][code]
            for shape, occurrence in enumerate(codes)
            for code in occurrence
        ]
        signature = (p, tuple(sparse.items()))
        return {
            "phase": p,
            "signatureHash": hashlib.sha256(encode(signature)).hexdigest(),
            "emptySignedVector": not sparse,
            "signedL1": sum(map(abs, sparse.values())),
            "signedFeatureCount": len(sparse),
            "cancelledSignedOccurrencePairs": (nonself - sum(map(abs, sparse.values()))) // 2,
            "rawWeightedTermSum": sum(terms),
            "absoluteWeightedTermSum": sum(map(abs, terms)),
            "nonzeroLookupTerms": sum(t != 0 for t in terms),
            "_signature": signature,
            "_features": sparse,
        }

    def coverage(fact):
        sparse = fact["_features"]
        unseen = [i for i in sparse if i not in t_parameters]
        signed = [
            i for i, value in sparse.items() if (i, (value > 0) - (value < 0)) not in t_signed
        ]
        fact.update(
            tUnobservedParameterHits=len(unseen),
            tUnobservedParameterAbsCoefficientHits=sum(abs(sparse[i]) for i in unseen),
            tUnobservedSignedHits=len(signed),
            tUnobservedSignedAbsCoefficientHits=sum(abs(sparse[i]) for i in signed),
        )

    def save_scalar(stream, fact):
        stream.write(encode({k: v for k, v in fact.items() if not k.startswith("_")}))

    try:
        for reference in config["sourceRefs"]:
            verified(reference)
        from othello_training import pattern
        from othello_arena.protocol import Native, Process

        assert Path(pattern.__file__).resolve() == Path(config["patternSource"])
        freeze = dict(config)
        for name, reference in config["inputs"].items():
            blobs[name], actual = verified(reference, fresh_hash=name == "attempts")
            freeze["inputs"] = dict(freeze["inputs"], **{name: actual})
        verified(config["image"])
        blobs["model"], actual_model = verified(config["model"])
        freeze["model"] = actual_model
        (own / "resolved-config.json").write_bytes(encode(freeze))
        # Actual identities/count limits are frozen above, before any payload parse/evaluation.
        model = pattern.from_json(blobs.pop("model"))
        train_config = json.loads(blobs.pop("trainConfig"))
        rows = [json.loads(line) for line in blobs.pop("rows").splitlines()]
        attempts = json.loads(blobs.pop("attempts"))
        games = [json.loads(line) for line in blobs.pop("games").splitlines()]
        assert len(rows) == 896 and len(games) == 32 and len(attempts["requests"]) == 896
        assert attempts["config"]["sha256"] == config["teacherConfigSHA256"]
        assert sum(len(g["moves"]) for g in games) == 1961
        t_families, v_families, h_families = map(
            set,
            (
                train_config["trainFamilies"],
                train_config["validationFamilies"],
                train_config["holdoutFamilies"],
            ),
        )
        assert not t_families & v_families and len(h_families) == 16
        request_by_state = {}
        for attempt in attempts["requests"]:
            key = (attempt["gameId"], encode(attempt["request"]["state"]))
            assert key not in request_by_state and attempt["status"] == "complete"
            request_by_state[key] = attempt
        for index, row in enumerate(rows):
            family = row["openingFamily"]
            assert family not in h_families and family in t_families | v_families
            position = pattern.state(row["state"])
            teacher = row["teacher"]
            assert type(row["targetCentidiscs"]) in (int, float) and math.isfinite(
                row["targetCentidiscs"]
            )
            assert -6400 <= row["targetCentidiscs"] <= 6400
            assert (
                row["labelKind"] == "teacherEstimate"
                and teacher["id"] == train_config["teacher"]["id"]
            )
            assert (
                teacher["scorePerspective"] == "state.toMove"
                and teacher["scoreUnits"] == "engine-disc"
            )
            assert (
                teacher["scaleToCentidiscs"] == 100
                and row["targetCentidiscs"] == teacher["rawSTMScore"] * 100
            )
            attempt = request_by_state[(row["gameId"], encode(position))]
            raw = attempt["rawResponse"]
            assert raw["score"] == teacher["rawSTMScore"] and attempt["openingFamily"] == family
            assert raw["scoreKind"] in ("engine_estimate_stm", "engine_exact_winner_empties_stm")
            fact = {
                **features(position),
                "origin": "teacher",
                "index": index,
                "split": "T" if family in t_families else "V",
                "toMove": position["toMove"],
                "teacherScoreKind": raw["scoreKind"],
                "target": row["targetCentidiscs"],
                "teacherProven": teacher["proven"],
                "_row": row,
            }
            teacher_facts.append(fact)
            feature_groups[(fact["split"], fact["_signature"])].append(fact)
            if fact["split"] == "T":
                t_parameters.update(fact["_features"])
                t_signed.update((i, (v > 0) - (v < 0)) for i, v in fact["_features"].items())
        assert Counter(f["split"] for f in teacher_facts) == {"T": 768, "V": 128}
        assert (
            Counter(f["teacherScoreKind"] for f in teacher_facts)
            == config["teacherScoreKindCounts"]
        )
        counts["teacherStates"] = len(teacher_facts)
        cost["preflightAndFeaturesWallMs"] = (time.monotonic() - started) * 1000
        with ExitStack() as stack, (own / "state-scalars.jsonl").open("wb") as scalars:
            for role in ("candidate", "v1"):
                began = time.monotonic()
                process = stack.enter_context(
                    Process(
                        config["engines"][role]["argv"],
                        cwd=config["engines"][role]["cwd"],
                        log=own / (role + ".log"),
                        cancelled=cancelled,
                    )
                )
                processes.append((role, process, began))
                native[role] = Native(process)
            for fact in teacher_facts:
                coverage(fact)
                for role in ("candidate", "v1"):
                    fact[role] = request(role, "evaluate", state=fact["_row"]["state"])["score"]
                    if f"{role}.startupThroughFirstScheduledEvaluationWallMs" not in cost:
                        began = next(p[2] for p in processes if p[0] == role)
                        cost[f"{role}.startupThroughFirstScheduledEvaluationWallMs"] = (
                            time.monotonic() - began
                        ) * 1000
                save_scalar(scalars, fact)
            scalars.flush()
            for game_index, game in enumerate(games):
                state = request("v1", "new")["state"]
                for move_index, move in enumerate(game["moves"]):
                    assert state["toMove"] == move["side"]
                    fact = {
                        **features(state),
                        "origin": "recordedGame",
                        "gameIndex": game_index,
                        "moveIndex": move_index,
                        "role": "candidate" if move["side"] == game["candidateSide"] else "v1",
                    }
                    counts["recordedPreMoveStates"] += 1
                    assert counts["recordedPreMoveStates"] <= 1961
                    coverage(fact)
                    for role in ("candidate", "v1"):
                        fact[role] = request(role, "evaluate", state=state)["score"]
                    saved = move.get("search")
                    fact.update(
                        opening=move["opening"],
                        forcedPass=move["move"] is None,
                        returnedSearchKind=saved["scoreKind"] if saved else None,
                        returnedSearchScore=saved["score"] if saved else None,
                        returnedSearchProven=saved["proven"] if saved else None,
                    )
                    game_facts.append(fact)
                    save_scalar(scalars, fact)
                    fields = (
                        {"state": state}
                        if move["move"] is None
                        else {"state": state, "move": move["move"]}
                    )
                    state = request("v1", "pass" if move["move"] is None else "play", **fields)[
                        "state"
                    ]
            assert counts["stateOccurrences"] == 2857
            assert counts["candidate.evaluate.completed"] == counts["v1.evaluate.completed"] == 2857
        assert all(
            p.cleanup
            and p.cleanup["directReaped"]
            and not p.cleanup["unexpectedExit"]
            and not p.cleanup["errors"]
            for _, p, _ in processes
        )
        report["TObservedParameters"] = len(t_parameters)
        report["TObservedSignedParameterDirections"] = len(t_signed)
        report["TObservedParametersByPhase"] = dict(
            Counter(i // (2 * len(pattern.REPRESENTATIVES)) for i in t_parameters)
        )
        strata = defaultdict(list)
        for fact in teacher_facts:
            for key in (
                fact["split"],
                f"{fact['split']}/phase{fact['phase']}",
                f"{fact['split']}/phase{fact['phase']}/{fact['teacherScoreKind']}",
                f"{fact['split']}/STM{fact['toMove']}",
            ):
                strata[key].append(fact)
        report["staticLossBySplitPhaseTeacherKind"] = {
            k: losses(v) for k, v in sorted(strata.items())
        }
        alias_rows, examples = [], []
        internal = sorted(
            set(range(64))
            - {pattern.transform(i, s) for shape in pattern.SHAPES for i in shape for s in range(8)}
        )
        for (split, signature), group in feature_groups.items():
            targets = [f["target"] for f in group]
            mean = sum(targets) / len(targets)
            alias_rows.append(
                {
                    "split": split,
                    "phase": signature[0],
                    "signatureHash": group[0]["signatureHash"],
                    "n": len(group),
                    "emptySignedVector": group[0]["emptySignedVector"],
                    "minimumTeacher": min(targets),
                    "maximumTeacher": max(targets),
                    "teacherRange": max(targets) - min(targets),
                    "populationTeacherVariance": sum((v - mean) ** 2 for v in targets)
                    / len(targets),
                }
            )
        for summary in sorted(
            alias_rows, key=lambda g: (-g["teacherRange"], g["split"], g["signatureHash"])
        ):
            if len(examples) == 4:
                break
            if summary["n"] < 2 or summary["teacherRange"] == 0:
                continue
            group = next(
                g
                for (s, sig), g in feature_groups.items()
                if s == summary["split"] and g[0]["signatureHash"] == summary["signatureHash"]
            )
            first = min(group, key=lambda f: f["target"])
            a = pattern.canonical_board(first["_row"]["state"])
            other = next(
                (
                    f
                    for f in sorted(group, key=lambda f: -f["target"])
                    if f["target"] != first["target"]
                    and tuple(pattern.canonical_board(f["_row"]["state"])[i] for i in internal)
                    != tuple(a[i] for i in internal)
                ),
                None,
            )
            if other:
                examples.append(
                    {
                        **summary,
                        "actualSparseFeatures": list(first["_features"].items()),
                        "interiorIndicesOutsidePatternUnion": internal,
                        "actualStates": [
                            {
                                "state": f["_row"]["state"],
                                "gameId": f["_row"]["gameId"],
                                "openingFamily": f["_row"]["openingFamily"],
                                "targetCentidiscs": f["target"],
                                "teacherScoreKind": f["teacherScoreKind"],
                                "candidateStatic": f["candidate"],
                                "v1Static": f["v1"],
                            }
                            for f in (first, other)
                        ],
                    }
                )
        (own / "alias-group-scalars.json").write_bytes(encode(alias_rows))
        (own / "private-alias-examples.json").write_bytes(encode(examples))
        report["aliasBySplitPhase"] = {}
        for split in ("T", "V"):
            for p in range(4):
                groups = [g for g in alias_rows if g["split"] == split and g["phase"] == p]
                n = sum(g["n"] for g in groups)
                report["aliasBySplitPhase"][f"{split}/{p}"] = {
                    "states": n,
                    "representations": len(groups),
                    "aliasGroups": sum(g["n"] > 1 for g in groups),
                    "statesInAliasGroups": sum(g["n"] for g in groups if g["n"] > 1),
                    "excessStatesOverRepresentations": sum(g["n"] - 1 for g in groups),
                    "emptyVectorStates": sum(g["n"] for g in groups if g["emptySignedVector"]),
                    "maxWithinRepresentationTeacherRange": max(g["teacherRange"] for g in groups),
                    "stateWeightedWithinRepresentationTeacherVariance": sum(
                        g["n"] * g["populationTeacherVariance"] for g in groups
                    )
                    / n,
                }
        report["recordedGamePhase"] = {}
        for p in range(4):
            facts = [f for f in game_facts if f["phase"] == p]
            report["recordedGamePhase"][str(p)] = {
                "stateOccurrences": len(facts),
                "emptySignedVectors": sum(f["emptySignedVector"] for f in facts),
                "statesWithSignedOccurrenceCancellation": sum(
                    f["cancelledSignedOccurrencePairs"] > 0 for f in facts
                ),
                "cancelledSignedOccurrencePairs": sum(
                    f["cancelledSignedOccurrencePairs"] for f in facts
                ),
                "nonemptyVectorsWithNoNonzeroLookupTerms": sum(
                    not f["emptySignedVector"] and not f["nonzeroLookupTerms"] for f in facts
                ),
                "nonemptyVectorsWeightedTermsCancelToZero": sum(
                    not f["emptySignedVector"]
                    and f["absoluteWeightedTermSum"] > 0
                    and f["rawWeightedTermSum"] == 0
                    for f in facts
                ),
                "TUnobservedParameterHits": sum(f["tUnobservedParameterHits"] for f in facts),
                "TUnobservedParameterAbsCoefficientHits": sum(
                    f["tUnobservedParameterAbsCoefficientHits"] for f in facts
                ),
                "TUnobservedSignedHits": sum(f["tUnobservedSignedHits"] for f in facts),
                "TUnobservedSignedAbsCoefficientHits": sum(
                    f["tUnobservedSignedAbsCoefficientHits"] for f in facts
                ),
                "statesWithTUnobservedParameter": sum(
                    f["tUnobservedParameterHits"] > 0 for f in facts
                ),
                "candidateStatic": describe([f["candidate"] for f in facts]),
                "candidateStaticZero": sum(f["candidate"] == 0 for f in facts),
                "candidateStaticZeroAndEmptyVector": sum(
                    f["candidate"] == 0 and f["emptySignedVector"] for f in facts
                ),
                "v1Static": describe([f["v1"] for f in facts]),
                "v1StaticZero": sum(f["v1"] == 0 for f in facts),
            }
        returned = defaultdict(list)
        for fact in game_facts:
            if fact["returnedSearchKind"]:
                returned[
                    f"{fact['role']}/phase{fact['phase']}/{fact['returnedSearchKind']}"
                ].append(fact["returnedSearchScore"])
        report["originalReturnedSearchDescriptiveOnly"] = {
            k: {
                **describe(v),
                "zeros": v.count(0),
                "units": "actual STM discs"
                if k.endswith("discDifference")
                else "heuristic STM centidiscs",
            }
            for k, v in sorted(returned.items())
        }
        report["exampleGroups"] = len(examples)
        report["exampleActualStates"] = sum(len(g["actualStates"]) for g in examples)
        report["semantics"] = {
            "labels": "teacherEstimate: root STM engine-disc *100, no white reflip; winner-empties distinct from native actual-disc solver",
            "nativeStatic": "always heuristic STM centidiscs, proven false; v1 has no static clamp, pattern clamps +/-6400",
            "aliases": "same actual signed sparse vector+phase, T/V separate; empirical teacher variance/representation limits, not true-minimax proof",
            "coverage": "T only; parameter IDs and signed parameter directions reported separately; abs coefficient hits are multiplicities",
            "V": "selection set, not held-out strength",
            "games": "all32 development-observed, not final independent evaluation",
            "reconstruction": "no decoded cache in original collection refs/files; only32 Rust new +1961 play/pass to derive pre-move states; no status/legal/oracle qualification, final-state requalification or new scientific game",
            "conclusion": "original rejected32 result immutable; no causal loss claim/new model/default promotion",
        }
        report["status"] = "complete"
    except BaseException as error:
        report["failure"] = {"kind": type(error).__name__, "message": str(error)}
        raise
    finally:
        report["cleanup"] = [
            {"role": role, **(process.cleanup or {})} for role, process, _ in processes
        ]
        report["cost"]["analysisWallMs"] = (time.monotonic() - started) * 1000
        report["partialTeacherFacts"] = len(teacher_facts)
        report["partialRecordedFacts"] = len(game_facts)
        (own / "result.json").write_bytes(encode(report))


if __name__ == "__main__":
    main(sys.argv[1])
