"""Execute one preregistered finite native protocol/cost pilot, no refills."""

import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus, execute

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
WT = ROOT / ".worktree/othello-baselines-n96"
config = json.loads((OUT / "bound-config.json").read_bytes())
for row in config["launchBinding"]["source"]:
    p = Path(row["path"])
    b = p.read_bytes()
    assert len(b) == row["bytes"] and hashlib.sha256(b).hexdigest() == row["sha256"]
plan = CPUPlan([18], {"arena": [0]}, library_threads=1)
plan.check_host(available_cpus())
plan.apply()
assert (
    int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
    <= 64 * 1024**2
)
lock = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
with lock.open("a") as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    temporary = OUT / "TMP"
    temporary.mkdir()
    env = dict(
        os.environ,
        PYTHONPATH=str(WT / "games/othello/python") + os.pathsep + os.environ.get("PYTHONPATH", ""),
        PYTHONDONTWRITEBYTECODE="1",
        CUDA_VISIBLE_DEVICES="",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
        RAYON_NUM_THREADS="1",
        TMPDIR=str(temporary),
    )
    deadline = time.monotonic() + 3600
    resources = CycleResources(
        dict(
            max_memory_bytes=2 * 1024**3 - 64 * 1024**2,
            host_ram_reserve=4 * 1024**3,
            pause_file=str(OUT / "CANCEL"),
        ),
        OUT,
        deadline,
    )
    returned = None
    error = None
    try:
        returned = execute(
            [
                sys.executable,
                "-B",
                "-m",
                "othello_arena",
                "--config",
                str(OUT / "bound-config.json"),
                "--output",
                str(OUT / "games"),
            ],
            OUT / "arena.log",
            deadline,
            resources=resources,
            cpu_plan=plan,
            cpu_scope="arena",
            cwd=WT,
            env=env,
        )
    except BaseException as caught:
        error = dict(type=type(caught).__name__, message=str(caught))
    finally:
        disk = OUT / "arena.process.json"
        (OUT / "actual-returned-STOP.json").write_text(
            json.dumps(
                dict(
                    returned=returned,
                    error=error,
                    disk=json.loads(disk.read_bytes()) if disk.exists() else None,
                    source_leases=[],
                    global_host_quiet=False,
                ),
                indent=2,
            )
            + "\n"
        )
        allocated = 0
        logical = 0
        entries = 0
        for directory, dirs, files in os.walk(OUT):
            st = os.lstat(directory)
            allocated += st.st_blocks * 512
            entries += 1
            for name in files:
                st = os.lstat(Path(directory) / name)
                allocated += st.st_blocks * 512
                logical += st.st_size
                entries += 1
        (OUT / "affected-once.json").write_text(
            json.dumps(
                dict(
                    logical_B=logical,
                    allocated_B=allocated,
                    entries=entries,
                    scope="ONE new protocol-smoke-v1 subtree only, existing assets/holding not walked/recharged; final tails/globalactual/fullfeesUNKNOWN",
                ),
                indent=2,
            )
            + "\n"
        )
    assert (
        error is None
        and returned["exit_code"] == 0
        and returned["remaining"] == []
        and returned["cleanup_complete"]
    ), error
    print(
        json.dumps(
            dict(
                exit_code=returned["exit_code"],
                wall_seconds=returned["wall_seconds"],
                cleanup=returned["cleanup_complete"],
            )
        )
    )
