**SOURCE_CLEAR — finite Rust-primary Othello UI boundary review, quoridor-n96.1.7**

No blocking source defect found in confirmed-state/save/resume authority or synchronous cancellation/teardown ownership. No source repair or new abstraction is requested. One nonblocking malformed-response recovery limitation is recorded below. This conclusion is source reasoning plus retained software evidence; it is not rendered-browser or end-to-end lifecycle proof.

**Exact reviewed version**

Worktree: `/workspaces/quoridor/.worktree/othello-core-n96`.

The SOURCESTOP manifest `.artifacts/othello-rust-ui-n96/source-handoff-v1.json` was verified for12326B/0644/SHA256 `06b7c3e8eea50efe808cd972e5c7ffe986dd1f50eb006dbcbfdb2a61419e7f42` before parsing. All16 held source files matched bytes/mode/SHA and the corresponding16 entries of Root's `rust-ui-software-v1/qualification.json`, both initially and at final source STOP. The superseded `apps/web/src/games/othello/session.ts` is absent; no import of that session remains in the scoped Othello TS directory. The earlier input manifest9e3c9622 is not used as the edited-source identity. Full16 refs, qualification identity and four generated input refs are in receipt.json. The installed four generated JS/Wasm/declaration inputs matched qualification bytes/mode/SHA; none was executed.

Key identities, all0644:

| Worktree-relative file | Bytes | SHA256 |
| --- | ---: | --- |
| games/othello/crates/othello-wasm/src/ui.rs | 33009 | a4c4c1f31a0d5963253a3df49a724522b99c5fa4af2c61be9ba62cf06b7e5a7d |
| games/othello/crates/othello-wasm/src/lib.rs | 4084 | 53f23616a2506c66a28c0300cc6ae5beabf735207748f1eee816527d6433108c |
| games/othello/bridge/src/index.ts | 5170 | 795e63766a35acdd72970f4d9a14186305ff5a5f6c8484b9b2d37be38cc47dc6 |
| games/othello/bridge/src/ui.ts | 1722 | db144fe51f2b48009bf9c3d6d86195a2eea944edb0fba3dfc9a11a75a6c96b54 |
| apps/web/src/games/othello/host.ts | 4060 | 667f51be70a59ea0d45ae5d07a1086927a37766efa06f78b1c685b750a47cc54 |
| apps/web/src/games/othello/ai-client.ts | 2797 | e67b326e04d8c2eae097bdb692d15b6955ec4178b489865f071589149e06aa6a |
| apps/web/src/games/othello/index.ts | 1524 | a3e5a6d9f2a33415d0b36c7dacac4919302bb026ab9a557fdd02d4c7312536b8 |
| apps/web/src/games/othello/view.ts | 5773 | 637c096a1d2277e2916e4569609f2cecb77a9a986e8cff6d211ece959a7db2e5 |

Paths/lines below refer to this held version. UI Rust is `games/othello/crates/othello-wasm/src/ui.rs`; host files are beneath `apps/web/src/games/othello/`.

**Source conclusions**

1. **Confirmed-state authority remains in Rust.** The per-mount Wasm owner wraps one Rust Controller (`othello-wasm/src/lib.rs:12–37`); the typed bridge creates/frees independent objects and prevents dispatch after free (`bridge/src/index.ts:66–80`, `bridge/src/ui.ts:1–55`). Rust owns SavedGame and strict action/envelope parsing (`ui.rs:14–22,35–77,159–177`). Human play/pass is guarded by pending/paused/human/preserve state and delegated directly to the unchanged GameState (`ui.rs:424–448`). TS does not recreate legal moves, confirmed game state, resume validation or save eligibility. Worker entry calls only unchanged chooseMove, echoing its input token/state (`ai.worker.ts:8–19`); no new model/search default is selected.

2. **Revoked or mismatched replies cannot commit a board.** Rust increments generation and clears confirmation/read/write/AI ownership synchronously in invalidate (`ui.rs:202–212`). New/resume ask, setup, cancel, retry, board commit and dispose use that revocation. AI acceptance requires the full Rust token, echoed request board and still-current confirmed board before GameState.play (`ui.rs:450–474`); stale tokens and duplicate replies have no commit/save effect. At the transport, active Worker identity and both generation/request fields are checked (`ai-client.ts:15–47`). Host checks mount liveness/current Rust generation before asynchronous callbacks (`host.ts:19–32,39–87`). Its generation-only prefilter is not the sole request check: transport and Rust enforce the exact request. Matching-token valid-schema but different-board replies consume the pending request, cancel the Worker and return an error/retry state rather than applying a move.

3. **Unconfirmed, pending, corrupt and failed resume paths preserve the slot.** ask invalidates work and sets preserve_save before issuing confirmation (`ui.rs:282–305`); only matching confirmation may create a new game or initiate the read (`347–393`). Loaded checks its exact read token; raw error, missing bytes, invalid JSON/envelope/board/mode/side fail before assigning the candidate (`395–422`). Preserve protection remains active after these failures. save eligibility excludes preserve_save and pending work (`214–237`); play/pass are also blocked. Dispose computes eligibility before invalidation and cannot turn a protected pending/failed resume into a final write (`488–496`). Only confirmed new or validated resume releases protection. The host forwards raw bytes/errors and executes only Rust-provided key/raw write effects (`host.ts:39–59`, `storage.ts:1–10`), so TS cannot reconstruct or overwrite a corrupt candidate on its own.

   Normal effect ordering is also consistent: Rust serializes the confirmed state before emitting save, and automatic AI pass can supersede an earlier-generation write in the same output. Host's current-generation filter drops that superseded write; the final confirmed write survives. Write acknowledgements are synchronous and checked against the exact writing token (`ui.rs:308–321`, `host.ts:40–47`). Stale acknowledgements cannot clear a newer operation's warning.

4. **Cancellation terminates the synchronous execution owner.** cancel removes message/error/messageerror listeners, clears active ownership, and calls Worker.terminate (`ai-client.ts:15–24`). A replacement calls cancel before constructing another Worker (27–30); delayed old listeners reject mismatched Worker identity even if invoked after removal (31–39,55–57). Rust emits cancelWorker synchronously on revocation and the host executes it synchronously (`host.ts:34–37`). This does not rely on delivering a postMessage cancellation into synchronous Wasm. Worker error/construction/post failure is converted to an error reply using the original requested state; GameState remains Rust-owned.

5. **Mount and late initialization have explicit teardown ownership.** Mount registers abort before DOM creation or async loading, handles already-aborted signals, aborts DOM listeners, disposes host/view and clears DOM once (`index.ts:12–47`). Host closed/boot tickets revoke pending UI initialization; late/superseded created UI objects are freed rather than dispatched (`host.ts:90–125`). Shared bridge initialization resets its promise on failure (`bridge/src/index.ts:42–59`), allowing the next requested operation to retry. Dispose cancels Worker before Rust disposal/free, permits only the Rust final write and its acknowledgement while closed, and frees owner in finally (`host.ts:114–125`, `ui.rs:308–321,488–496`). The final effect does not reopen ordinary closed-host dispatch.

6. **Projection and action authority agree in the inspected source.** Rust derives title, player colors, actual score, pass/terminal state, legal cells, enabled actions and warnings (`ui.rs:503–608`). It distinguishes draft setup fields from the confirmed game's player summary; a setup change pauses the existing game until explicit next action (`336–345`). DOM renders those values and forwards typed actions (`view.ts:56–106`). Cell aria-disabled is a projection, not an alternate validator: clicks still pass through Rust's eligibility checks. The simple-policy label remains explicit. Focus/arrow-boundary behavior and listener abort are visible in source; actual layout, accessibility behavior, router composition and browser event ordering remain outside this source conclusion.

**Nonblocking recovery limitation**

A matching-token reply can pass the transport's truthy-state check with a malformed GameState, for example a complete64-cell board but toMove0 (`ai-client.ts:40–47`). Rust deserialization rejects that action before apply (`ui.rs:611–623`), while transport has already terminated the Worker. The Rust AI request can therefore remain pending and the view still say “thinking” with an error until the user selects Cancel, then Retry. Cancel is visible while ai.is_some and revokes that pending request (`ui.rs:482–485,528,574`).

This is source-derived, not executed here. It does not permit a board/save change or leave a live Worker after teardown; the current Worker normally echoes its original valid request state. The port fixtures' “malformed” case covers invalid move99, not malformed GameState. Do not overstate it as universal automatic malformed-state recovery. It does not block the requested state/save/cancellation ownership guarantees, and no speculative framework/repair is requested.

**Retained evidence and limits**

Root evidence under `/workspaces/quoridor/.artifacts/research-team/integration324/othello-strong-ai-n96/rust-ui-software-v1/` was inspected without replay. Raw logs record8 Rust UI tests and7 actual new UI Wasm tests passing; affected Clippy and real-generated bridge typing have successful returned receipts. Relevant returned records show exit0, cleanup true, empty remaining, completed signal restoration and completed final persistence. Qualified generated inputs match the installed files. This is actual software qualification, not a rendered browser session.

Author raw logs record12 source fixtures plus the one added DOM fixture,13 total. Corresponding process-ref SHA checks matched. Their disk snapshots show cleanup true/remaining empty but signal restoration pending/final persistence attempted; these are not upgraded to returned completion. Scripted Rust-port/mock-Wasm/fake-Element fixtures are not real Rust/DOM/browser proof.

Inspected definitions: Rust `ui.rs:677–906`; actual-Wasm `bridge/test/ui-wasm.test.mjs:42–187`; facade `bridge/test/ui-facade.test.mjs:8–65`; host/storage/transport/mount/projection `tests/unit/othello-lifecycle.test.mjs:101–560`. They cover confirmation/save protection, token/board rejection, pass/terminal, revocation, final-save acknowledgement, late owner disposal, transport listener cleanup and DOM projection. Their relevant source assertions support the reasoning above; they do not certify browser composition.

Web typing/bundle and rendered lifecycle remain UNRUN in this review's evidence. Root's separate normal browser qualification may proceed; the author adding a rendered spec is not a review gate. Common routes/CSS/browser-specific behavior, old core/pattern/search/teacher/trainer mathematics, strength, timing, models/default adoption and production/browser runtime guarantees were not re-reviewed or proven.

**Review execution and handoff**

Actual saved context2026-10-21T20:28:13.505Z matched original session Sol6.1/high, Main cwd, danger-full-access/never before ordinary commands. CPUPlan FileRef187B/0644/SHA256 `a1dfa82ca524ceeed1131526c90b0372bbb18e3dff42b1e64857a1b3504abe87` was verified before parse and passed unchanged through CPUPlan.from_record. Existing CycleResources/execute used management18/review6, library1/GPU0, conservative960MiB family RSS guard plus64MiB controller reserve within1GiB, host reserve4GiB, <=180s per check, explicit OWN reviewer/CANCEL pause_file, standard bounded logs and direct wait/reap/handle cleanup. Controller RSS was checked against64MiB before/after each check. No owned TMP was needed.

No target tests/build/native/Wasm/browser execution, scientific proof, model/data/weights/teacher/fit/RAW payload, new agent, source/Git/index/Cargo write, permanent mirror or old review replay occurred. Only own report/receipt/finite controls were written. Transient successful source-reading captures were removed after readers returned. Old n96.1.3/.1.4, failures/UNKNOWN costs, Quoridor pauses/seals/defaults/models and decimal50GB remain untouched. Final held-source identities were checked and reader children stopped/reaped before normal Root handoff; actual returned STOP is recorded separately from pending disk snapshots. One own affected-storage observation is retained in receipt. Own issue remains in_progress for Root acceptance; no self-close or standing watcher/ACK gate.
