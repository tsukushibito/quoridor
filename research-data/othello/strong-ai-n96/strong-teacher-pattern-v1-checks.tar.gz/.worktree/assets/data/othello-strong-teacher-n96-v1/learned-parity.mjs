import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import {
  initSync,
  PatternModel,
} from "/workspaces/quoridor/games/othello/bridge/wasm/othello.js";
const dir = new URL("./", import.meta.url);
const weights = new URL("fit/best-pattern.json", dir);
const input = readFileSync(new URL("learned-parity-inputs.json", dir), "utf8");
const expected = JSON.parse(input);
const text = readFileSync(weights, "utf8");
assert.equal(
  createHash("sha256").update(text).digest("hex"),
  expected.modelSHA256,
);
assert.equal(Buffer.byteLength(text), expected.modelBytes);
initSync({
  module: readFileSync(
    "/workspaces/quoridor/games/othello/bridge/wasm/othello_bg.wasm",
  ),
});
const model = new PatternModel(text);
try {
  const requests = expected.expected.map((x) => ({
    op: "evaluate",
    state: x.state,
  }));
  const native = spawnSync(
    process.env.OTHELLO_NATIVE_ENGINE,
    [
      "--pattern",
      fileURLToPath(weights),
      "--model-id",
      `sha256:${expected.modelSHA256}`,
    ],
    {
      input: requests.map(JSON.stringify).join("\n") + "\n",
      encoding: "utf8",
      timeout: 10000,
      maxBuffer: 1048576,
    },
  );
  assert.ifError(native.error);
  assert.equal(native.status, 0, native.stderr);
  const actual = native.stdout.trim().split("\n").map(JSON.parse);
  assert.equal(actual.length, 8);
  expected.expected.forEach((row, i) => {
    const wasm = JSON.parse(model.evaluate_json(JSON.stringify(row.state)));
    assert.deepEqual(wasm, {
      score: row.score,
      scoreKind: "heuristic",
      proven: false,
    });
    assert.equal(actual[i].ok, true);
    assert.equal(actual[i].score, row.score);
    assert.equal(actual[i].scoreKind, "heuristic");
    assert.equal(actual[i].proven, false);
    assert.equal(
      actual[i].evaluation.modelId,
      `sha256:${expected.modelSHA256}`,
    );
    assert.equal(actual[i].evaluation.modelBytes, expected.modelBytes);
  });
  console.log(
    JSON.stringify({
      learnedModelSHA256: expected.modelSHA256,
      allPhaseSTMPairs: 4,
      rawScoresCompared: 8,
      PythonNativeWasm: "PASS",
      strengthClaim: false,
    }),
  );
} finally {
  model.free();
}
