"""Qualify the actual frozen teacher labels without issuing any new search."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics

from othello_training import data, pattern

P = Path(__file__).resolve().parent


def checked(ref):
    p = Path(ref["path"])
    b = p.read_bytes()
    assert len(b) == ref["bytes"] and hashlib.sha256(b).hexdigest() == ref["sha256"]
    assert f"{p.stat().st_mode & 0o777:04o}" == ref["mode"]
    return json.loads(b)


binding = json.loads((P / "training-and-teacher-prelabel-binding.json").read_bytes())
config = data.validate_config(checked(binding["training"]))
issued = checked(binding["teacher_config"])
observations = checked(binding["observations"])
checked(binding["openings"])
result = json.loads((P / "teacher-v2/result.json").read_bytes())
job = json.loads((P / "runtime-teacher-v2/result.json").read_bytes())
stop = json.loads((P / "teacher-v2-returned-STOP.json").read_bytes())
assert job["job_id"] == "255b87ce-4cbb-4347-9bf3-bf0b364dbe69"
assert job["outcome"] == "succeeded" and job["cleanup_complete"] and job["remaining"] == []
assert stop["error"] is None and stop["returned"]["cleanup_complete"]
assert stop["returned"]["remaining"] == [] and stop["returned"]["direct_child_reaped"]
assert result["status"] == "complete" and result["failure"] is None
for key in [
    "teacherScheduled",
    "teacherAttempted",
    "teacherSearchIssued",
    "teacherComplete",
    "rows",
]:
    assert result[key] == 896
assert result["teacherUnrun"] == 0
assert config["teacher"] == {k: result["teacher"][k] for k in config["teacher"]}
assert result["config"]["sha256"] == binding["teacher_config"]["sha256"]
for cleanup in [result["cleanup"], result["teacherSession"]["cleanup"]]:
    assert cleanup["directReaped"] and not cleanup["unexpectedExit"] and cleanup["errors"] == []
rows = [json.loads(line) for line in (P / "teacher-v2/training.jsonl").read_text().splitlines()]
requests = json.loads((P / "teacher-v2/generation-evidence.json").read_bytes())["requests"]
records = observations["records"]
assert len(rows) == len(requests) == len(records) == 896
phases, splits, proven, probability = Counter(), Counter(), Counter(), Counter()
walls, resets = [], []
for row, request, record in zip(rows, requests, records, strict=True):
    assert {k: row[k] for k in record["row"]} == record["row"]
    assert request["request"]["state"] == row["state"]
    assert request["gameId"] == row["gameId"]
    assert request["openingFamily"] == row["openingFamily"]
    assert request["placement"] == record["placement"]
    assert request["status"] == "complete" and request["searchAttempted"]
    raw, teacher = request["rawResponse"], row["teacher"]
    assert raw["ok"] and raw["move"] in record["legalMoves"]
    assert raw["scoreKind"] == "engine_estimate_stm"
    assert row["targetCentidiscs"] == raw["score"] * 100 == teacher["rawSTMScore"] * 100
    assert teacher["scorePerspective"] == "state.toMove" and teacher["scoreUnits"] == "engine-disc"
    assert teacher["proven"] == raw["proven"] and teacher["bound"] == "UNKNOWN"
    assert teacher["reportedProbability"] == raw["probability"]
    assert teacher["completedDepth"] == raw["completedDepth"]
    assert request["outerWallMs"] == teacher["outerWallMs"] <= 1100
    assert request["request"]["timeMs"] == teacher["requestedTimeMs"] == 1000
    assert request["transportMs"] is None and request["cancelJoinMs"] is None
    assert row["openingFamily"] not in config["holdoutFamilies"]
    phases[pattern.phase(row["state"])] += 1
    splits[record["split"]] += 1
    proven[str(raw["proven"])] += 1
    probability[str(raw["probability"])] += 1
    walls.append(request["outerWallMs"])
    resets.append(request["resetWallMs"])
dataset = data.load_dataset(P / "teacher-v2/training.jsonl", config)
data.validate_fit_splits(dataset, config)
assert len(dataset.train) == 768 and len(dataset.validation) == 128
assert dict(phases) == {0: 224, 1: 224, 2: 224, 3: 224}
assert not dataset.inferred_final_black_minus_white
assert all(
    v["unobservedCapacity"] == 0 for split in dataset.coverage.values() for v in split.values()
)
report = dict(
    status="complete",
    rows=896,
    trainRows=768,
    validationRows=128,
    phaseRows=dict(phases),
    splitRows=dict(splits),
    holdoutRows=0,
    sourceConfig=issued["source"],
    dataSHA256=dataset.sha256,
    actualReportedProven=proven,
    actualReportedSelectivity=probability,
    requestWallMs=dict(sum=sum(walls), median=statistics.median(walls), maximum=max(walls)),
    resetWallMs=dict(sum=sum(resets), maximum=max(resets)),
    teacherSession=result["teacherSession"],
    outerTeacherJobSeconds=job["wall_seconds"],
    previousConfigurationFailureSeconds=0.2590263789752498,
    sourceLeases=[],
    interpretation="896 fixed external STM estimates, not896 terminal outcomes or own minimax truth; reported proof/selectivity retained, no H. No search/probe/generation repeated. Loader input qualified before fit.",
)
(P / "teacher-qualification.json").write_text(json.dumps(report, indent=2) + "\n")
print(
    json.dumps(
        {
            k: report[k]
            for k in ["rows", "trainRows", "validationRows", "phaseRows", "requestWallMs"]
        }
    )
)
