"""Verify selected FP/export identity and prepare all-phase learned-model parity."""

import hashlib
import json
from pathlib import Path
import numpy as np
from othello_training import data, pattern

P = Path(__file__).resolve().parent
model_path = P / "fit/best-pattern.json"
model = pattern.from_json(model_path.read_bytes())
fp = np.load(P / "fit/best-fp.npy", allow_pickle=False)
assert pattern.quantize(fp) == model
rows = [pattern.strict_json(x) for x in (P / "teacher-v2/training.jsonl").read_text().splitlines()]
states = []
for phase in range(4):
    state = next(r["state"] for r in rows if pattern.phase(r["state"]) == phase)
    states.extend([state, dict(state, toMove=3 - state["toMove"])])
expected = [
    dict(state=state, score=pattern.evaluate(model, state), phase=pattern.phase(state))
    for state in states
]
for i in range(0, 8, 2):
    assert expected[i]["score"] == -expected[i + 1]["score"]
(P / "learned-parity-inputs.json").write_text(
    json.dumps(
        dict(
            modelSHA256=hashlib.sha256(model_path.read_bytes()).hexdigest(),
            modelBytes=model_path.stat().st_size,
            expected=expected,
        ),
        indent=2,
    )
    + "\n"
)

config = data.validate_config(pattern.strict_json((P / "training-config.json").read_bytes()))
dataset = data.load_dataset(P / "teacher-v2/training.jsonl", config)
observed = {index for row in dataset.train for index, value in row.features.items() if value != 0}
metadata = json.loads((P / "fit/metadata.json").read_bytes())
coverage = dict(
    trainObservedParameters=len(observed),
    trainUnobservedParameters=pattern.PARAMETERS - len(observed),
    trainObservedParametersByPhase={
        str(phase): sum(index // (pattern.PARAMETERS // 4) == phase for index in observed)
        for phase in range(4)
    },
    selectedFloatNonzero=int(np.count_nonzero(fp)),
    quantizedZeroFromNonzeroFloat=int(np.count_nonzero((fp != 0) & (np.rint(fp) == 0))),
    quantizedExpandedNonzero=int(np.count_nonzero(np.asarray(model["weights"]))),
    bestEpoch=metadata["bestEpoch"],
    initialQuantizedValidationMSE=json.loads((P / "fit/curves.json").read_bytes())[0][
        "quantizedValidationMSE"
    ],
    explanation="Training feature coverage and selected FP/quantization only; all-phase actual states separate from synthetic opposite-STM counterparts, no strength inference.",
)
(P / "fit/feature-quantization-coverage.json").write_text(json.dumps(coverage, indent=2) + "\n")
