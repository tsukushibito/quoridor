"""Bound one finite fixed-depth comparison with existing research execution."""

import hashlib
import json
import os
from pathlib import Path
import sys
import time
from quoridor_runtime.cycle_process import (
    CPUPlan,
    CycleResources,
    available_cpus,
    available_memory,
    execute,
    process_info,
)

OUT = Path(__file__).resolve().parent
p = OUT / "config.json"
assert hashlib.sha256(p.read_bytes()).hexdigest() == sys.argv[1]
config = json.loads(p.read_bytes())


def verify(ref):
    p = Path(ref["path"])
    assert p.stat().st_size == ref["bytes"]
    assert format(p.stat().st_mode & 0o777, "04o") == ref["mode"]
    with p.open("rb") as stream:
        assert hashlib.file_digest(stream, "sha256").hexdigest() == ref["sha256"]


verify(config["cpuPlan"])
plan = CPUPlan.from_record(json.loads(Path(config["cpuPlan"]["path"]).read_bytes()))
plan.check_host(available_cpus())
plan.apply()
assert process_info(os.getpid())["rss"] <= 64 * 1024**2
assert available_memory() >= 6 * 1024**3
for ref in config["source"] + config["upstream"] + [config["comparator"], config["runner"]]:
    verify(ref)
tmp = OUT / "TMP"
tmp.mkdir()
deadline = time.monotonic() + config["limits"]["commandSeconds"]
resources = CycleResources(
    dict(
        max_memory_bytes=2 * 1024**3 - 64 * 1024**2,
        host_ram_reserve=4 * 1024**3,
        pause_file=str(OUT / "CANCEL"),
    ),
    OUT,
    deadline,
)
returned = None
error = None
try:
    returned = execute(
        [sys.executable, "-B", str(OUT / "compare.py"), str(p), sys.argv[1]],
        OUT / "fixed-depth.log",
        deadline,
        resources=resources,
        cpu_plan=plan,
        cpu_scope=config["cpuScope"],
        cwd="/workspaces/quoridor",
        env=dict(
            os.environ,
            TMPDIR=str(tmp),
            CUDA_VISIBLE_DEVICES="",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
            PYTHONDONTWRITEBYTECODE="1",
        ),
    )
except BaseException as exc:
    error = dict(type=type(exc).__name__, message=str(exc))
finally:
    disk = OUT / "fixed-depth.process.json"
    (OUT / "fixed-depth.returned.json").write_text(
        json.dumps(
            dict(
                returned=returned,
                error=error,
                disk=json.loads(disk.read_bytes()) if disk.exists() else None,
            ),
            indent=2,
        )
        + "\n"
    )
    if tmp.exists() and not list(tmp.iterdir()):
        tmp.rmdir()
assert error is None and returned["exit_code"] == 0, error
assert (
    returned["cleanup_complete"] and returned["direct_child_reaped"] and not returned["remaining"]
)
result = json.loads((OUT / "numerical-result.json").read_bytes())
assert result["completedCases"] == 29 and result["primary"] is None
(OUT / "qualification.json").write_text(
    json.dumps(
        dict(
            status="PASS",
            cases=29,
            requests=58,
            newGames=0,
            H=0,
            strength="UNRUN",
            commandSeconds=returned["wall_seconds"],
            comparison="nonselective fixed-depth requested-STM raw values",
            currentSearchImage=config["rust"],
            originalReference=config["oracle"],
            timing="Setup/reset/request/search clocks nested; no fair speed claim",
            RSSPeak=None,
        ),
        indent=2,
    )
    + "\n"
)
print(json.dumps(dict(cases=29, strength="UNRUN", cleanup=returned["cleanup_complete"])))
