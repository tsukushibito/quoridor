"""One frozen nonselective fixed-depth comparison; no games or generated states."""

import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def checked(ref):
    p = Path(ref["path"])
    assert p.stat().st_size == ref["bytes"]
    assert format(p.stat().st_mode & 0o777, "04o") == ref["mode"]
    with p.open("rb") as stream:
        assert hashlib.file_digest(stream, "sha256").hexdigest() == ref["sha256"]
    return p


config_path = Path(sys.argv[1])
assert hashlib.sha256(config_path.read_bytes()).hexdigest() == sys.argv[2]
config = json.loads(config_path.read_bytes())
checked(config["cases"])
for key in ["rust", "oracle", "midgame", "ordering", "protocol"]:
    checked(config[key])
sys.path.insert(0, str(ROOT / "games/othello/python"))
from othello_arena.protocol import Process  # noqa: E402

cases = json.loads(Path(config["cases"]["path"]).read_bytes())
assert len(cases) == config["caseCount"] == 29
assert all(all(c["state"]["board"][i] in (1, 2) for i in (27, 28, 35, 36)) for c in cases)
mid, ordering = config["midgame"], config["ordering"]
ids = ["sha256:" + mid["sha256"], "sha256:" + ordering["sha256"]]
argv = {
    "rust": [
        config["rust"]["path"],
        "--midgame",
        mid["path"],
        "--ordering",
        ordering["path"],
        "--midgame-id",
        ids[0],
        "--ordering-id",
        ids[1],
        "--interpretation",
        "simd",
    ],
    "original": [
        config["oracle"]["path"],
        mid["path"],
        ordering["path"],
        "--midgame-id",
        ids[0],
        "--ordering-id",
        ids[1],
    ],
}
processes = {}
setup = {}
attempted = 0
completed = []
primary = None
cleanup_errors = []
current = None
body_start = time.monotonic()
raw = (OUT / "responses.jsonl").open("x", encoding="utf8")


def request(role, payload, timeout):
    global attempted
    attempted += payload["op"] == "search"
    start = time.monotonic()
    answer = processes[role].json_request(payload, deadline=start + timeout)
    wall = (time.monotonic() - start) * 1000
    if payload["op"] == "search":
        raw.write(
            json.dumps(dict(case=current["id"], role=role, answer=answer, requestWallMs=wall))
            + "\n"
        )
        raw.flush()
        assert raw.tell() <= config["limits"]["evidenceBytes"]
    return answer, wall


try:
    for role in ("rust", "original"):
        start = time.monotonic()
        processes[role] = Process(
            argv[role],
            cwd=ROOT,
            log=OUT / (role + "-protocol.log"),
            cancelled=lambda: (OUT / "CANCEL").exists(),
            limit=65536,
        )
        launched = time.monotonic()
        info, _ = request(role, {"op": "info"}, config["limits"]["setupSeconds"])
        setup[role] = dict(
            launchMs=(launched - start) * 1000,
            inclusiveReadyMs=(time.monotonic() - start) * 1000,
            info=info,
        )
        if role == "rust":
            assert info["upstreamCommit"] == config["engineCommit"]
            assert info["interpretation"] == "simd" and info["hashLevel"] == 20
            assert info["workerPool"] == 0 and info["midgameId"] == ids[0]
            assert info["orderingId"] == ids[1] and info["hashSeed"] == 20261022
        else:
            assert info["engineCommit"] == config["engineCommit"]
            assert info["profile"] == "original-avx2-fixed-depth-mpc-off"
            assert info["controls"]["compiledMpc"] is False
            assert info["controls"]["workerPool"] == 0 and info["hashLevel"] == 20
            assert info["weightIdentity"]["midgameId"] == ids[0]
            assert info["weightIdentity"]["orderingId"] == ids[1]
            assert info["activeTTBytes"] <= 32 * 1024**2
    (OUT / "setup.json").write_text(json.dumps(setup, indent=2) + "\n")
    for current in cases:
        results = {}
        reset = {}
        walls = {}
        for role in ("rust", "original"):
            _, reset[role] = request(role, {"op": "clear"}, config["limits"]["requestSeconds"])
            options = dict(config["controls"], fixedDepth=current["fixedDepth"])
            payload = dict(op="search", state=current["state"], options=options)
            if role == "rust":
                options.update(maxDepth=current["fixedDepth"], timeMs=config["rustTimeMs"])
            else:
                payload["caseId"] = current["id"]
            answer, walls[role] = request(role, payload, config["limits"]["requestSeconds"])
            results[role] = answer["result"] if role == "rust" else answer
        r, o = results["rust"], results["original"]
        expected_depth = 0 if current["terminal"] else current["fixedDepth"]
        assert r["stopped"] is None and r["completedDepth"] == expected_depth
        assert o["completedDepth"] == expected_depth and o["completedSelectivity"] == 6
        assert r["scoreUnits"] == o["scoreUnits"] == "engine-disc"
        assert type(r["rawScore"]) is int and -64 <= r["rawScore"] <= 64
        assert r["rawScore"] == r["score"] == o["rawScore"], ("rawScore", current["id"], r, o)
        assert r["terminal"] == current["terminal"]
        assert r["mustPass"] == current["mustPass"]
        assert (o["action"] == "terminal") == current["terminal"]
        assert (o["action"] == "pass") == current["mustPass"]
        assert r["ttBytes"] <= 32 * 1024**2
        assert r["proven"] == o["proven"] == (current["kind"] != "heuristic")
        for value in (r["move"], o["move"]):
            if current["terminal"] or current["mustPass"]:
                assert value is None
            else:
                assert type(value) is int and 0 <= value < 64
                assert current["state"]["board"][value] == 0
        completed.append(
            dict(
                id=current["id"],
                rawScore=r["rawScore"],
                kind=current["kind"],
                policyDifferent=r["move"] != o["move"],
                rustMove=r["move"],
                originalMove=o["move"],
                resetWallMs=reset,
                requestWallMs=walls,
                rust=r,
                original=o,
            )
        )
except BaseException as exc:
    primary = dict(
        type=type(exc).__name__, message=str(exc), case=current["id"] if current else None
    )
finally:
    raw.close()
    for role, process in reversed(list(processes.items())):
        try:
            process.close()
        except BaseException as exc:
            cleanup_errors.append(dict(role=role, error=str(exc)))
    cleanup = {role: p.cleanup for role, p in processes.items()}
    result = dict(
        scheduled=29,
        attemptedRequests=attempted,
        completedCases=len(completed),
        remainingCases=29 - len(completed),
        primary=primary,
        cleanup=cleanup,
        cleanupErrors=cleanup_errors,
        cases=completed,
        setup=setup,
        wholeBodySeconds=time.monotonic() - body_start,
        newGames=0,
        H=0,
        RNGSelection=0,
        statistics=0,
        strength="UNRUN",
        RSSPeak=None,
        scope="Only frozen recorded-domain nonselective unsmoothed values; no timing or full-search fidelity guarantee",
    )
    (OUT / "numerical-result.json").write_text(json.dumps(result, indent=2) + "\n")
assert primary is None and not cleanup_errors, primary
assert len(completed) == 29 and attempted == 58
assert all(
    x["directReaped"] and not x["errors"] and not x["unexpectedExit"] for x in cleanup.values()
)
print(json.dumps(dict(cases=len(completed), requests=attempted, strength="UNRUN")))
