import assert from 'node:assert/strict';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';

const out = process.argv[2];
const api = await import(pathToFileURL(out + '/generated/othello.js'));
await api.default({ module_or_path: fs.readFileSync(out + '/generated/othello_bg.wasm') });
// Same explicit synthetic zero tables; no trained weights.
let remaining = 36745500;
const runs = [];
while (remaining) {
  const n = Math.min(remaining, 28671);
  runs.push(4096 + n);
  remaining -= n;
}
const midgame = new Uint8Array(4 + 2 * runs.length);
const view = new DataView(midgame.buffer);
view.setInt32(0, runs.length, true);
runs.forEach((n, i) => view.setInt16(4 + i * 2, n, true));
const model = new api.FullSearchModel(
  midgame,
  new Uint8Array(472392),
  'simd',
  6,
  api.original_mpc_coefficients_json(),
);
const state = (black, white, toMove) => {
  const board = Array(64).fill(0);
  black.forEach((i) => (board[i] = 1));
  white.forEach((i) => (board[i] = 2));
  return JSON.stringify({ version: 1, board, toMove });
};
const results = [];
try {
  for (const depth of [2, 3]) {
    model.clear();
    const r = JSON.parse(
      model.search_json(
        state([0, 29, 54], [28, 45], 2),
        JSON.stringify({ fixedDepth: depth, selectivity: 6, mpc: false, timeMs: 10000 }),
      ),
    );
    assert.equal(r.completedDepth, depth);
    assert.equal(r.rawScore, 0);
    assert.ok([30, 63].includes(r.move));
    assert.equal(r.mustPass, false);
    assert.equal(r.proven, false);
    assert.equal(r.scoreUnits, 'engine-disc');
    results.push({ case: 'R1', depth, result: r });
  }
  model.clear();
  const r = JSON.parse(
    model.search_json(
      state([1], [0, 27, 28, 35, 36, 62, 63], 1),
      JSON.stringify({ maxDepth: 30, timeMs: 10000 }),
    ),
  );
  assert.equal(r.completedDepth, 30);
  assert.equal(r.move, null);
  assert.equal(r.mustPass, true);
  assert.equal(r.terminal, false);
  assert.equal(r.rawScore, -64);
  assert.equal(r.score, -64);
  assert.equal(r.proven, false);
  results.push({ case: 'R2', result: r });
  fs.writeFileSync(
    out + '/new-review-wasm-result.json',
    JSON.stringify({
      cases: 2,
      searchCalls: 3,
      results,
      realWeights: false,
      scientificSearches: 0,
      scope: 'Only new R1 central coverage and R2 forced-pass regressions in actual Wasm',
    }) + '\n',
    { flag: 'wx' },
  );
} finally {
  model.free();
}
console.log('new R1/R2 actual Wasm synthetic regressions PASS');
