"""Qualify only changed Othello Wasm and its same-source native parity."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import time

from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus, execute

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
WT = ROOT / ".worktree/othello-core-n96"
TARGET = (
    ROOT
    / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/target"
)
NATIVE = json.loads((OUT.parent / "pattern-software-v1/qualification.json").read_bytes())
EXPECTED = {
    "games/othello/bridge/src/index.ts": "c577f6f31f2a83128397973e38696ea9052017e223e9ac6142371ec9b601dafd",
    "games/othello/bridge/src/wasm.d.ts": "810a080dd4a82423180f16d37a2a2cd96e60d471143c2ca0c9309f5db8ce8ddb",
    "games/othello/bridge/test/pattern-wasm.test.mjs": "fc3e61ba7c58422260ee5002aa04dd088212c68dd90ae5678629e6b9cab88d7e",
    "games/othello/python/othello_training/parity.py": "3faaa08dfef350ae68cfaa79bbc76e890d4438ca3818f960c5ed7de78140ef7d",
    "games/othello/python/othello_training/pattern.py": "c4cccb742b0ff1967c04a2a4405689ef24440760b9fbaed1a08a500cfc38d93c",
}


def refs():
    result = []
    for name, sha in EXPECTED.items():
        p = WT / name
        b = p.read_bytes()
        assert hashlib.sha256(b).hexdigest() == sha, name
        result.append(
            dict(path=str(p), sha256=sha, bytes=len(b), mode=f"{p.stat().st_mode & 0o777:04o}")
        )
    for row in NATIVE["source"]:
        assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["sha256"]
    return result


source = refs()
(OUT / "source.json").write_text(json.dumps(source, indent=2) + "\n")
plan = CPUPlan([18], {"software": [0]}, library_threads=1)
plan.check_host(available_cpus())
plan.apply()
assert (
    int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
    <= 64 * 1024**2
)
assert (
    json.loads((TARGET / ".research-owner.json").read_bytes())["writer"]
    == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
)
tmp = OUT / "TMP"
tmp.mkdir()
env = dict(
    os.environ,
    CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS="1",
    CARGO_INCREMENTAL="0",
    CARGO_NET_OFFLINE="true",
    CARGO_PROFILE_DEV_DEBUG="0",
    CARGO_PROFILE_TEST_DEBUG="0",
    RUSTFLAGS="-C debuginfo=0",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    CUDA_VISIBLE_DEVICES="",
    PYTHONDONTWRITEBYTECODE="1",
    TMPDIR=str(tmp),
    OTHELLO_NATIVE_ENGINE=NATIVE["image"]["path"],
    OTHELLO_PATTERN_PYTHON=__import__("sys").executable,
)
cargo = "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo"
completed = []


def check(name, argv):
    deadline = time.monotonic() + 600
    resources = CycleResources(
        dict(
            max_memory_bytes=4 * 1024**3 - 64 * 1024**2,
            host_ram_reserve=4 * 1024**3,
            pause_file=str(OUT / "CANCEL"),
        ),
        OUT,
        deadline,
    )
    returned = None
    error = None
    try:
        returned = execute(
            argv,
            OUT / (name + ".log"),
            deadline,
            resources=resources,
            cpu_plan=plan,
            cpu_scope="software",
            cwd=WT,
            env=env,
        )
    except BaseException as caught:
        error = dict(type=type(caught).__name__, message=str(caught))
    finally:
        disk = OUT / (name + ".process.json")
        (OUT / (name + ".returned.json")).write_text(
            json.dumps(
                dict(
                    returned=returned,
                    error=error,
                    disk=json.loads(disk.read_bytes()) if disk.exists() else None,
                ),
                indent=2,
            )
            + "\n"
        )
    assert (
        error is None
        and returned["exit_code"] == 0
        and returned["remaining"] == []
        and returned["process_cleanup_complete"]
        and returned["handle_closes_complete"]
    ), (name, error)
    completed.append(dict(name=name, wall_seconds=returned["wall_seconds"]))
    (OUT / "completed.json").write_text(json.dumps(completed, indent=2) + "\n")


check(
    "wasm-build",
    [
        "wasm-pack",
        "build",
        str(WT / "games/othello/crates/othello-wasm"),
        "--target",
        "web",
        "--dev",
        "--out-dir",
        str(OUT / "generated"),
        "--out-name",
        "othello",
        "--locked",
        "--no-default-features",
    ],
)
inputs = []
destination = WT / "games/othello/bridge/wasm"
destination.mkdir(exist_ok=True)
for name in ["othello.js", "othello.d.ts", "othello_bg.wasm", "othello_bg.wasm.d.ts"]:
    p = OUT / "generated" / name
    d = destination / name
    old = next(
        row
        for row in json.loads((OUT.parent / "wasm-software-v1/generated-inputs.json").read_bytes())
        if Path(row["path"]).name == name
    )
    assert hashlib.sha256(d.read_bytes()).hexdigest() == old["sha256"]
    shutil.copy2(p, d)
    b = p.read_bytes()
    assert d.read_bytes() == b
    inputs.append(
        dict(
            path=str(d),
            source=str(p),
            sha256=hashlib.sha256(b).hexdigest(),
            bytes=len(b),
            mode=f"{d.stat().st_mode & 0o777:04o}",
        )
    )
(OUT / "generated-inputs.json").write_text(json.dumps(inputs, indent=2) + "\n")
check(
    "real-wasm-native-parity",
    ["node", "--test", str(WT / "games/othello/bridge/test/pattern-wasm.test.mjs")],
)
(OUT / "url.d.ts").write_text(
    "declare module '*.wasm?url' { const url: string; export default url; }\n"
)
config = dict(
    compilerOptions=dict(
        target="ES2022",
        module="ESNext",
        moduleResolution="Bundler",
        strict=True,
        noEmit=True,
        skipLibCheck=True,
        lib=["ES2022", "DOM"],
    ),
    files=[str(WT / "games/othello/bridge/src/index.ts"), str(OUT / "url.d.ts")],
)
(OUT / "tsconfig.json").write_text(json.dumps(config, indent=2) + "\n")
check(
    "real-generated-typecheck",
    [str(ROOT / "node_modules/.bin/tsc"), "-p", str(OUT / "tsconfig.json"), "--listFiles"],
)
listed = (OUT / "real-generated-typecheck.log").read_text()
assert str(WT / "games/othello/bridge/wasm/othello.d.ts") in listed
assert str(WT / "games/othello/bridge/src/wasm.d.ts") not in listed
assert refs() == source
(OUT / "qualification.json").write_text(
    json.dumps(
        dict(
            source=source,
            core_source=NATIVE["source"],
            generated=inputs,
            native_image=NATIVE["image"],
            completed=completed,
            scope="new explicit pattern model load/free/evaluate/search Python/native/Wasm parity and true regenerated declarations; toy mathematical model fixture only, no fit/browser/strength claim",
        ),
        indent=2,
    )
    + "\n"
)
print(json.dumps(dict(completed=completed, generated=inputs)))
