"""Collect current ownership and send bounded source hold/direction once."""

import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def run(argv, label):
    p = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True, timeout=180, check=False)
    (OUT / (label + ".json")).write_text(
        json.dumps(
            dict(argv=argv, returncode=p.returncode, stdout=p.stdout, stderr=p.stderr), indent=2
        )
        + "\n"
    )
    assert p.returncode == 0, (label, p.stderr[-2000:])
    return p.stdout


ready = json.loads(run(["bash", "scripts/dev/beads.sh", "ready", "--json"], "ready"))
(OUT / "ready-projection.json").write_text(
    json.dumps(
        [
            dict(id=x["id"], status=x.get("status"))
            for x in ready
            if x["id"].startswith(("quoridor-n96", "quoridor-4lc.435"))
        ],
        indent=2,
    )
    + "\n"
)
for issue in ["quoridor-n96.1", "quoridor-4lc.435"]:
    d = json.loads(run(["bash", "scripts/dev/beads.sh", "show", issue, "--json"], issue))[0]
    assert (
        d["assignee"] == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
        and d["status"] == "in_progress"
    )
run(
    [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a15f72-2381-78b1-9c2d-5f2cf2b46bea",
        "--issue",
        "quoridor-n96.1.1",
        "--cwd",
        str(ROOT / ".worktree/othello-core-n96"),
        "--body-file",
        str(OUT / "hold.md"),
    ],
    "core-hold",
)
run(
    [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a118b8-bc3a-7b02-bd7c-4b456ca8cbae",
        "--issue",
        "quoridor-4lc.435.1",
        "--cwd",
        str(ROOT / ".worktree/quoridor-strong435"),
        "--body-file",
        str(
            ROOT
            / ".artifacts/research-team/integration324/quoridor-strong-ai435/entry-v1/research-judgment435.md"
        ),
    ],
    "435-direction",
)
run(
    [
        "bash",
        "scripts/dev/beads.sh",
        "update",
        "quoridor-4lc.435",
        "--append-notes",
        "Actual first source edit435.1 at2026-10-22T02:51:52.337787+09:00: runner claustrophobia.rs SHA3df71a0a; parse reply only after direct child reap + both stdout/stderr EOF. No Cargo/model/game yet. Same writer now receives accepted persistent-model clock and T384/V64/H64 joint-pilot source/config direction, no new actor/ACK. Othello pattern software qualification independent; fairness/Cargo coordinated by Root.",
    ],
    "435-source-start",
)
run(["bash", "scripts/dev/beads.sh", "backup", "sync"], "backup")
print("hold/direction/actual source note delivered")
