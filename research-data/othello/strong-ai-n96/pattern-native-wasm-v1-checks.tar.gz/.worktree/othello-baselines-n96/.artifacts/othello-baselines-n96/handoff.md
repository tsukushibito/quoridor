quoridor-n96.1.2 準備完了 / Root受入れ・有限対局入場用。issueはcloseしていません。

範囲: games/othello/python/othello_arena/{__init__,__main__,protocol,engines,matches}.py、games/othello/tests/python/test_arena.py、games/othello/docs/baselines.md の新規実装。root scripts/pyproject/lock/manifest/Cargo/bridge/core は未変更、Git/index/commit/共有Cargoは操作していません。source/tool readerと全直接子はSTOP。新session/agent/manager/監視/資格台帳なし。

実対象:
- Edax v4.7 commit6c6991bee9a3d31d04f87934b04a7fd23c279f2b、専用build binary SHA2561f63846be66155a5728ab94ce20f21880dc525d1dc8ce6166a886482326387f8、618576B。
- 公式Console7.8.1 commit570d5e0a478c9d720d75de06a5d31995f412704a。公式GTPは起動・盤面確認のみ。固定時間入口は明示label「Console7.8.1-engine + fixed-time adapter」。adapter binary SHA256abf3e68901aca0fdd58a7731c805b3078458f9a3e826afb1c99bd0b8a58f2c0e、782072B。adapter source/patch/build、195全upstream member/engine headers無変更、weights/各licenseは asset provenance.json にhash/bytes/mode。
- Root native image550b87377274b202056925a39bcfa4164aaf0dff3ff17bb993b6d43517be8975/712232B/0755を受領しparse前に実照合。native-integration.json: 四familyのRust replayと外部frozen state一致、Edax全board一致、fixed frontend合法手/side/pass/早期terminal一致、実native/fixed各1検索が合法手。native timedOut=trueは完了済み手を返す通常iteration deadlineでI/O timeoutと区別。

時計・memory:
- Edax startup-l1 (missingbook初期生成用)、searchはGTP time_settings1 0 1 + 手前time_left <color>1 1→level60、-nps0、1search task/bookponderOFF。訂正後単一要求0.99096s。-h20は約27MiB+小align/spin、共通upper32MiB。
- Egaroucid既存tree_search_legalに直接1000ms。ai_time_limitのper-game allocatorは通さない。depth5 clog実費差引→既存iterative time search、途中future取消join、最後の成功iterationのみ。無合法/完了iterationなしはerrorで手を推測しない。上流clock high_resolution、外側monotonic。clogには個別deadlineが無くjoinもあるためstrict1000ms停止ではない。probe1003.3ms、depth26/74%/未証明。100ms protocol allowanceを結果前config固定し超過をtimeoutとして残す。
- pool0/use_multi_thread=falseで検索worker1、上流asyncのcontrolwait含めOS最大2thread、全CPU12。activeTT25,165,872B、virtualstaticTT805,306,416B、他globalも維持。実processpeakRSS1,368,186,880B。family2GiB/child<=1984MiB/controller64MiB/hostreserve4GiBを既存CycleResources+executeで毎入場検査。Rootはnative processes含む合計を次jobで束縛。layout同一とは呼ばない。

入口/config:
- 実行argv: <project-python> -m othello_arena --config <bound-json> --output <new-OWN-dir>。既存execute childenvのPYTHONPATHに指定WT/games/othello/pythonを追加。外側は現行CPUPlan/guardian/jobを再用、GPU0/CUDA_VISIBLE_DEVICES空/librarythreads1、OWN CANCELとownedTMP、期限180/600s。
- .artifacts/othello-baselines-n96/smoke-config.unrun.json: 各相手4family×両色8局、1s/thread1/TT upper32MiB/bookponderOFF、purposeprotocol_cost、superiorityClaimfalse。rules/candidateは供給image、launchBindingだけnull (無断fullgame起動しない)。simple=trueで既存簡易policyとの比較も接続可能。
- Rootがclock/source/image/fair資源を束縛して有限jobを投入。各異常で結果/予定分母/UNRUNを保持し停止、補充/勝手な再試行なし。Rust new/status/play/passが終局/pass/実石差正本。外部空き勝者割当scoreは診断のみ。四openingのD4/色反転hashは異なりprotocol-smoke-only、train/dev/final作成時にそれらを除外。最終判定data未使用。

実check: tests-final-scope.log fakeprotocol8 PASS (persistentNative/GTP/fullentry、forcedpass/実counts、両色/失敗分母、timeout/cancel/EOF/crash/不正frame/大量stderr、回収/handle)。Ruff100 format --checkとlint、Prettier docs check PASS。専用Edax/Egaroucid/fixedFrontend compileと実probe PASS。C++frontendはclang-format無し→既存style手動整形+compile、upstreamは整形していない。詳細正本games/othello/docs/baselines.md。

保持した失敗: Egaroucid公式directGCC include不足→-include algorithmで修復、frontend初回const呼出しcompile失敗→frontendだけ修復、Edax起動-l60 timeout、誤GTP time_settings0 1 1の0.1007s、fake stderr close未drain→修復、誤った人工terminalfixture→修復、lint/Node実path誤り。各元log/processは上書きせず保持。初期ordinary pwdがcontext確認より先だった順序誤りもsource-start.jsonに記録。実contextはgpt-6.1-sol/high、exactcwd/fullnever一致。

実保持: directed scopeでasset allocated60,657,664B / logical60,128,050B、OWN約0.8MB。download上側57,721,735B、selected source+weight56,916,641B、partial0。各256MiB/512MiB/1GiB内。全体50GBや現在freeを保証する値ではない。storage-cleanup-summary.json時点45 guardian receiptsでdirectreap/remaining0/handlesclose確認、その後の限定checkもPASSして終了。

UNRUN/残Gap: full matches/棋力結論/本評価CI/実ブラウザ比較は未実施。Root fair timing job入場待ち。weights再利用の製品採用や全形式移植なし。Quoridor pause/seals/defaults/models/RAWFAILEDNULLUNKNOWN費とglobal50GBは維持。
