import hashlib
import json
import os
from pathlib import Path
import shutil
import time
from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus, execute

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
WT = ROOT
TARGET = (
    ROOT
    / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/target"
)
plan_ref = {
    "path": "/workspaces/quoridor/.artifacts/research-team/integration324/othello-strong-ai-n96/full-evaluator-software-v1/cpu-plan.json",
    "bytes": 189,
    "mode": "0644",
    "sha256": "029b180b527fc644a2c04ad072f4c2338445d8b335168b90483147600e193c6b",
}
plan_path = Path(plan_ref["path"])
plan_bytes = plan_path.read_bytes()
assert (
    len(plan_bytes) == plan_ref["bytes"]
    and hashlib.sha256(plan_bytes).hexdigest() == plan_ref["sha256"]
)
assert f"{plan_path.stat().st_mode & 0o777:04o}" == plan_ref["mode"]
plan = CPUPlan.from_record(json.loads(plan_bytes))
plan.check_host(available_cpus())
plan.apply()
assert (
    int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
    <= 64 * 1024**2
)
assert (
    json.loads((TARGET / ".research-owner.json").read_bytes())["writer"]
    == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
)
source = json.loads((OUT / "source.json").read_bytes())["source"]
upstream_source = json.loads((OUT / "upstream-source.json").read_bytes())
for ref in source + upstream_source:
    path = Path(ref["path"])
    body = path.read_bytes()
    assert len(body) == ref["bytes"] and hashlib.sha256(body).hexdigest() == ref["sha256"]
    assert f"{path.stat().st_mode & 0o777:04o}" == ref["mode"]
tmp = OUT / "TMP"
tmp.mkdir()
env = dict(
    os.environ,
    RUSTUP_TOOLCHAIN="stable",
    RUSTUP_AUTO_INSTALL="0",
    RUSTC="/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustc",
    RUSTDOC="/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustdoc",
    CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS="1",
    CARGO_INCREMENTAL="0",
    CARGO_NET_OFFLINE="true",
    CARGO_PROFILE_DEV_DEBUG="0",
    CARGO_PROFILE_TEST_DEBUG="0",
    RUSTFLAGS="-C debuginfo=0",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    CUDA_VISIBLE_DEVICES="",
    PYTHONDONTWRITEBYTECODE="1",
    TMPDIR=str(tmp),
)
cargo = "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo"
completed = []


def check(name, argv):
    deadline = time.monotonic() + 600
    resources = CycleResources(
        dict(
            max_memory_bytes=4 * 1024**3 - 64 * 1024**2,
            host_ram_reserve=4 * 1024**3,
            pause_file=str(OUT / "CANCEL"),
        ),
        OUT,
        deadline,
    )
    returned = None
    error = None
    try:
        returned = execute(
            argv,
            OUT / (name + ".log"),
            deadline,
            resources=resources,
            cpu_plan=plan,
            cpu_scope="software",
            cwd=WT,
            env=env,
        )
    except BaseException as caught:
        error = dict(type=type(caught).__name__, message=str(caught))
    finally:
        disk = OUT / (name + ".process.json")
        (OUT / (name + ".returned.json")).write_text(
            json.dumps(
                dict(
                    returned=returned,
                    error=error,
                    disk=json.loads(disk.read_bytes()) if disk.exists() else None,
                ),
                indent=2,
            )
            + "\n"
        )
    assert (
        error is None
        and returned["exit_code"] == 0
        and returned["remaining"] == []
        and returned["process_cleanup_complete"]
        and returned["handle_closes_complete"]
    ), (name, error)
    completed.append(dict(name=name, wall_seconds=returned["wall_seconds"]))
    (OUT / "completed.json").write_text(json.dumps(completed, indent=2) + "\n")


common = ["--offline", "--locked", "--manifest-path", str(ROOT / "Cargo.toml"), "-j1"]
check(
    "core-five-tests",
    [cargo, "test", *common, "-p", "othello-core", "--lib", "full_eval_", "--", "--test-threads=1"],
)
assert "5 passed; 0 failed" in (OUT / "core-five-tests.log").read_text()
check(
    "native-one-test",
    [cargo, "test", *common, "-p", "othello-core", "--bin", "othello-full-eval", "full_eval_"],
)
assert "1 passed; 0 failed" in (OUT / "native-one-test.log").read_text()
check(
    "affected-clippy",
    [
        cargo,
        "clippy",
        *common,
        "-p",
        "othello-core",
        "-p",
        "othello-wasm",
        "--all-targets",
        "--",
        "-D",
        "warnings",
    ],
)
check(
    "native-release",
    [cargo, "build", *common, "--release", "-p", "othello-core", "--bin", "othello-full-eval"],
)
shutil.copy2(TARGET / "release/othello-full-eval", OUT / "othello-full-eval")
upstream = ROOT / ".worktree/assets/tools/othello-baselines-n96-v1/egaroucid/src"
cpp = ["g++", "-std=c++20", "-DHAS_NO_AVX2", "-pthread", "-O2", "-I", str(upstream)]
check(
    "generic-oracle-build",
    [
        *cpp,
        str(ROOT / "games/othello/tools/egaroucid-eval-oracle.cpp"),
        "-o",
        str(OUT / "egaroucid-eval-oracle"),
    ],
)
check(
    "oracle-fixture-build",
    [
        *cpp,
        str(ROOT / "games/othello/tests/egaroucid_eval_oracle_test.cpp"),
        "-o",
        str(OUT / "egaroucid-eval-oracle-test"),
    ],
)
check("oracle-new-fixtures", [str(OUT / "egaroucid-eval-oracle-test"), str(tmp)])
for name in ["oracle-synthetic.egev2", "oracle-truncated.egev2"]:
    (tmp / name).unlink()
check(
    "wasm-generation",
    [
        "wasm-pack",
        "build",
        str(ROOT / "games/othello/crates/othello-wasm"),
        "--target",
        "web",
        "--dev",
        "--out-dir",
        str(OUT / "generated"),
        "--out-name",
        "othello",
        "--locked",
        "--no-default-features",
    ],
)
images = []
for name in ["othello-full-eval", "egaroucid-eval-oracle", "egaroucid-eval-oracle-test"]:
    path = OUT / name
    body = path.read_bytes()
    images.append(
        dict(
            path=str(path),
            bytes=len(body),
            mode=f"{path.stat().st_mode & 0o777:04o}",
            sha256=hashlib.sha256(body).hexdigest(),
        )
    )
assert not list(tmp.iterdir())
tmp.rmdir()
(OUT / "qualification.json").write_text(
    json.dumps(
        dict(
            source=source,
            images=images,
            completed=completed,
            realWeights="UNRUN",
            numericalNativeWasm="UNRUN",
            searchAndGames="UNRUN",
        ),
        indent=2,
    )
    + "\n"
)
print(json.dumps(dict(completed=completed, realWeights="UNRUN", numericalNativeWasm="UNRUN")))
