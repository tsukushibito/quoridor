/* tslint:disable */
/* eslint-disable */

/**
 * Explicit full Console7.8.1 evaluator owner. No model/global/default adoption,
 * and no search binding to the existing centidisc / actual-disc exact solver.
 * The host retains identity/provenance of the supplied original weight bytes.
 */
export class FullEvaluation {
    free(): void;
    [Symbol.dispose](): void;
    decoded_bytes(): number;
    evaluate_json(input: string): string;
    constructor(midgame: Uint8Array, ordering: Uint8Array, interpretation: string);
}

/**
 * Per-mount UI owner. All confirmed state, save eligibility and request tokens
 * live in Rust; the host only executes the returned browser effects.
 */
export class OthelloUi {
    free(): void;
    [Symbol.dispose](): void;
    dispatch_json(input: string): string;
    constructor();
}

/**
 * Explicit immutable model owner. Loading one never changes baseline search_json.
 * Rust UI/Worker hosts can own/drop this object and borrow its evaluator per call.
 */
export class PatternModel {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Raw heuristic only, including on terminal input; not a proven solver value.
     */
    evaluate_json(input: string): string;
    constructor(input: string);
    search_json(input: string, options: string): string;
}

export function apply_move_json(input: string, index: number): string;

export function choose_move_json(input: string): string;

export function legal_moves_json(input: string): string;

export function new_game_json(): string;

export function pass_turn_json(input: string): string;

/**
 * Synchronous, internally time-bounded search. A Worker message cannot cancel
 * this call while it owns the event loop; the caller must terminate/recreate
 * the Worker and discard stale responses for immediate external cancellation.
 */
export function search_json(input: string, options: string): string;

export function status_json(input: string): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_fullevaluation_free: (a: number, b: number) => void;
    readonly __wbg_othelloui_free: (a: number, b: number) => void;
    readonly __wbg_patternmodel_free: (a: number, b: number) => void;
    readonly apply_move_json: (a: number, b: number, c: number) => [number, number, number, number];
    readonly choose_move_json: (a: number, b: number) => [number, number, number, number];
    readonly fullevaluation_decoded_bytes: (a: number) => number;
    readonly fullevaluation_evaluate_json: (a: number, b: number, c: number) => [number, number, number, number];
    readonly fullevaluation_new: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly legal_moves_json: (a: number, b: number) => [number, number, number, number];
    readonly new_game_json: () => [number, number, number, number];
    readonly othelloui_dispatch_json: (a: number, b: number, c: number) => [number, number];
    readonly othelloui_new: () => number;
    readonly pass_turn_json: (a: number, b: number) => [number, number, number, number];
    readonly patternmodel_evaluate_json: (a: number, b: number, c: number) => [number, number, number, number];
    readonly patternmodel_new: (a: number, b: number) => [number, number, number];
    readonly patternmodel_search_json: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly search_json: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly status_json: (a: number, b: number) => [number, number, number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
