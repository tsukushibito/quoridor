"""Bind new generated rows to one independent replay of their saved Rust actions."""

import json
from pathlib import Path
import time
from othello_arena.__main__ import checked_spec
from othello_arena.protocol import Native, Process
from othello_training import data, pattern

P = Path(__file__).resolve().parent
config = json.loads((P / "games-config.json").read_bytes())
fit_config = data.validate_config(json.loads((P / "training-config.json").read_bytes()))
result = json.loads((P / "games/result.json").read_bytes())
assert result["status"] == "complete" and result["gamesComplete"] == 24
payload = P / "games/training.jsonl"
rows = [pattern.strict_json(x) for x in payload.read_text().splitlines()]
dataset = data.load_dataset(payload, fit_config)
evidence = json.loads((P / "games/terminal-evidence.json").read_bytes())["games"]
assert len(evidence) == 24 and len({g["gameId"] for g in evidence}) == 24
by_game = {g["gameId"]: [r for r in rows if r["gameId"] == g["gameId"]] for g in evidence}
spec = checked_spec(config["engine"])
process = Process(
    spec["argv"],
    cwd=spec["cwd"],
    log=P / "verification-protocol.log",
    cancelled=lambda: (P / "CANCEL").exists(),
)
checked = 0
phases = {str(i): 0 for i in range(4)}
with process:
    native = Native(process)

    def request(op, **kw):
        return native.request(op, deadline=time.monotonic() + 5, **kw)

    for game in evidence:
        state = request("new")["state"]
        samples = {}
        placement = 0
        for action in game["replay"]:
            status = request("status", state=state)["status"]
            assert not status["terminal"]
            if 8 <= placement <= 60 and placement % 4 == 0 and placement not in samples:
                samples[placement] = state
            move = action["move"]
            assert state["toMove"] == action["side"]
            assert (move is None and status["mustPass"]) or (
                type(move) is int and move in status["legalMoves"]
            )
            state = request(
                "pass" if move is None else "play",
                **dict(state=state, **({} if move is None else {"move": move})),
            )["state"]
            placement += move is not None
            assert placement == action["placement"]
        status = request("status", state=state)["status"]
        assert (
            status["terminal"]
            and status == game["terminalStatus"]
            and state == game["terminalState"]
        )
        difference = state["board"].count(1) - state["board"].count(2)
        assert (
            status["black"] == state["board"].count(1)
            and status["white"] == state["board"].count(2)
            and difference == game["actualBlackMinusWhite"]
        )
        for row in by_game[game["gameId"]]:
            pos = sum(x != 0 for x in row["state"]["board"]) - 4
            assert samples[pos] == row["state"] and row["openingFamily"] == game["openingFamily"]
            assert row["labelKind"] == "gameOutcome" and row[
                "targetCentidiscs"
            ] == 100 * difference * (1 if row["state"]["toMove"] == 1 else -1)
            phases[str(pattern.phase(row["state"]))] += 1
            checked += 1
assert process.cleanup["directReaped"] and not process.cleanup["unexpectedExit"]
assert checked == len(rows) and all(phases.values())
(P / "verified-data.json").write_text(
    json.dumps(
        dict(
            games=24,
            rows=checked,
            trainRows=len(dataset.train),
            validationRows=len(dataset.validation),
            phaseRows=phases,
            dataSHA256=dataset.sha256,
            verification="Saved24 game replays independently applied by Rust,0 new policy-generated games; every retained row exact observed preterminal state/STM target tied to actual terminal boardcounts; whole-game split/smoke exclusion frozen before labels",
            cleanup=process.cleanup,
        ),
        indent=2,
    )
    + "\n"
)
print(json.dumps(dict(rows=checked, phaseRows=phases)))
