"""Issue only the bound unlabeled opening stage through the maintained process owner."""

import json
import os
from pathlib import Path
import sys
import time
from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus, execute

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
plan = CPUPlan([18], {"pilot": [0]}, library_threads=1)
plan.check_host(available_cpus())
plan.apply()
assert (
    int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
    <= 64 * 1024**2
)
TMP = OUT / "TMP-openings"
TMP.mkdir()
env = dict(
    os.environ,
    PYTHONPATH=str(ROOT / "games/othello/python") + os.pathsep + os.environ.get("PYTHONPATH", ""),
    CUDA_VISIBLE_DEVICES="",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    PYTHONDONTWRITEBYTECODE="1",
    TMPDIR=str(TMP),
)
deadline = time.monotonic() + 180
resources = CycleResources(
    dict(
        max_memory_bytes=1024**3 - 64 * 1024**2,
        host_ram_reserve=4 * 1024**3,
        max_output_bytes=32 * 1024**2,
        pause_file=str(OUT / "CANCEL"),
    ),
    OUT,
    deadline,
)
command = [
    sys.executable,
    "-B",
    "-c",
    "import json,sys;from pathlib import Path;from othello_arena.generation import run;p=Path(sys.argv[1]);r=run(json.loads(p.read_bytes()),sys.argv[2],cancelled=lambda:Path(sys.argv[3]).exists());print(json.dumps(r));sys.exit(0 if r['status']=='complete' else 1)",
    str(OUT / "openings-config-ref.json"),
    str(OUT / "openings"),
    str(OUT / "CANCEL"),
]
returned = None
error = None
try:
    returned = execute(
        command,
        OUT / "openings-stage.log",
        deadline,
        resources=resources,
        cpu_plan=plan,
        cpu_scope="pilot",
        cwd=ROOT,
        env=env,
    )
except BaseException as caught:
    error = dict(type=type(caught).__name__, message=str(caught))
finally:
    p = OUT / "openings-stage.process.json"
    (OUT / "openings-returned-STOP.json").write_text(
        json.dumps(
            dict(
                returned=returned,
                error=error,
                disk=json.loads(p.read_bytes()) if p.exists() else None,
            ),
            indent=2,
        )
        + "\n"
    )
assert (
    error is None
    and returned["exit_code"] == 0
    and returned["remaining"] == []
    and returned["cleanup_complete"]
), error
