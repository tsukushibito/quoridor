"""One finite issued24-game generation, data qualification, tiny fit and export parity."""

import hashlib
import json
import os
from pathlib import Path
import sys
import time
from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus, execute

ROOT = Path("/workspaces/quoridor")
P = Path(__file__).resolve().parent
plan = CPUPlan([18], {"pilot": [0]}, library_threads=1)
plan.check_host(available_cpus())
plan.apply()
assert (
    int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
    <= 64 * 1024**2
)
TMP = P / "TMP-games-fit"
TMP.mkdir()
base = ROOT / ".artifacts/research-team/integration324/othello-strong-ai-n96"
image = json.loads((base / "pattern-software-v1/qualification.json").read_bytes())["image"]
assert hashlib.sha256(Path(image["path"]).read_bytes()).hexdigest() == image["sha256"]
for row in json.loads((base / "pattern-wasm-v1/qualification.json").read_bytes())["generated"]:
    local = ROOT / Path(row["path"]).relative_to(ROOT / ".worktree/othello-core-n96")
    assert hashlib.sha256(local.read_bytes()).hexdigest() == row["sha256"]
env = dict(
    os.environ,
    PYTHONPATH=str(ROOT / "games/othello/python") + os.pathsep + os.environ.get("PYTHONPATH", ""),
    CUDA_VISIBLE_DEVICES="",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    PYTHONDONTWRITEBYTECODE="1",
    TMPDIR=str(TMP),
    OTHELLO_NATIVE_ENGINE=image["path"],
    OTHELLO_PATTERN_PYTHON=sys.executable,
    OTHELLO_PATTERN_WEIGHTS=str(P / "fit/best-pattern.json"),
)
code = "import json,sys;from pathlib import Path;from othello_arena.generation import run;r=run(json.loads(Path(sys.argv[1]).read_bytes()),sys.argv[2],cancelled=lambda:Path(sys.argv[3]).exists());print(json.dumps(r));sys.exit(0 if r['status']=='complete' else 1)"
commands = [
    (
        "games",
        [
            sys.executable,
            "-B",
            "-c",
            code,
            str(P / "games-config-ref.json"),
            str(P / "games"),
            str(P / "CANCEL"),
        ],
    ),
    ("verify-data", [sys.executable, "-B", str(P / "verify-data.py")]),
    (
        "fit",
        [
            sys.executable,
            "-B",
            "-m",
            "othello_training.train",
            "--data",
            str(P / "games/training.jsonl"),
            "--config",
            str(P / "training-config.json"),
            "--output",
            str(P / "fit"),
        ],
    ),
    ("prepare-parity", [sys.executable, "-B", str(P / "prepare-parity.py")]),
    ("learned-allphase-parity", ["node", str(P / "learned-parity.mjs")]),
    (
        "learned-search-parity",
        [
            "node",
            "--test",
            "--test-name-pattern",
            "pattern raw scores and search match",
            str(ROOT / "games/othello/bridge/test/pattern-wasm.test.mjs"),
        ],
    ),
]
completed = []
for name, argv in commands:
    deadline = time.monotonic() + 180
    resources = CycleResources(
        dict(
            max_memory_bytes=1024**3 - 64 * 1024**2,
            host_ram_reserve=4 * 1024**3,
            max_output_bytes=32 * 1024**2,
            pause_file=str(P / "CANCEL"),
        ),
        P,
        deadline,
    )
    returned = None
    error = None
    try:
        returned = execute(
            argv,
            P / (name + ".log"),
            deadline,
            resources=resources,
            cpu_plan=plan,
            cpu_scope="pilot",
            cwd=ROOT,
            env=env,
        )
    except BaseException as caught:
        error = dict(type=type(caught).__name__, message=str(caught))
    finally:
        disk = P / (name + ".process.json")
        (P / (name + ".returned.json")).write_text(
            json.dumps(
                dict(
                    returned=returned,
                    error=error,
                    disk=json.loads(disk.read_bytes()) if disk.exists() else None,
                ),
                indent=2,
            )
            + "\n"
        )
    assert (
        error is None
        and returned["exit_code"] == 0
        and returned["remaining"] == []
        and returned["cleanup_complete"]
    ), (name, error)
    completed.append(dict(name=name, wall_seconds=returned["wall_seconds"]))
    (P / "completed-stages.json").write_text(json.dumps(completed, indent=2) + "\n")
print(
    json.dumps(
        dict(
            completed=completed,
            fit=json.loads((P / "fit/metadata.json").read_bytes()),
            strengthClaim=False,
        )
    )
)
