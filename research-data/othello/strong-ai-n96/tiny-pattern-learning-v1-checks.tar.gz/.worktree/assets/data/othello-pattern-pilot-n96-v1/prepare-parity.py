"""Verify selected FP/export identity and prepare all-phase learned-model parity."""

import hashlib
import json
from pathlib import Path
import numpy as np
from othello_training import pattern

P = Path(__file__).resolve().parent
model_path = P / "fit/best-pattern.json"
model = pattern.from_json(model_path.read_bytes())
fp = np.load(P / "fit/best-fp.npy", allow_pickle=False)
assert pattern.quantize(fp) == model
rows = [pattern.strict_json(x) for x in (P / "games/training.jsonl").read_text().splitlines()]
states = []
for phase in range(4):
    state = next(r["state"] for r in rows if pattern.phase(r["state"]) == phase)
    states.extend([state, dict(state, toMove=3 - state["toMove"])])
expected = [
    dict(state=state, score=pattern.evaluate(model, state), phase=pattern.phase(state))
    for state in states
]
for i in range(0, 8, 2):
    assert expected[i]["score"] == -expected[i + 1]["score"]
(P / "learned-parity-inputs.json").write_text(
    json.dumps(
        dict(
            modelSHA256=hashlib.sha256(model_path.read_bytes()).hexdigest(),
            modelBytes=model_path.stat().st_size,
            expected=expected,
        ),
        indent=2,
    )
    + "\n"
)
