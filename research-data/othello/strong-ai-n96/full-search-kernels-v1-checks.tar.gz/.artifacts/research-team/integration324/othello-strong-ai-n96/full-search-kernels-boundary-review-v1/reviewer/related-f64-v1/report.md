# quoridor-n96.1.20 — related f64 transport source check

SOURCE_CLEAR — essential 0, ordinary 0.

Fixed target: held-roundtrip-source-v1.json, 2146 bytes, 0644, SHA256 5a065e6d0cf9693f8f1d17123a22e66c07e9c093a90361549744b1592f89f18d. Only the held core Cargo.toml and new full_search_coefficients.rs definition were reviewed, with the supplied before-Cargo/adoption facts and necessary pinned local serde_json source. Original v6 report 933bc14f and its receipt remain unchanged; this is a separate causal result.

The Cargo change at line 9 retains the exact =1.0.151 dependency version and enables standard float_roundtrip. The before manifest and saved exact-line correspondence show no change to serde or algorithm/constants. The pinned lock still has the same serde_json 1.0.151 package/checksum. Local serde_json Cargo.toml:65–78 defines float_roundtrip without an additional dependency. Its src/de.rs:623–671 selects lexical::parse_concise_float::<f64> instead of the non-feature significand-to-f64 plus decimal scaling path. This addresses the intended decimal-to-typed-f64 rounding boundary without a custom parser, tolerance or parameter substitution.

Cargo features are additive for a shared package identity. With the supplied same-version normal dependency join, enabling this in core also requests that feature for the shared serde_json used by the Wasm consumer. This is source/configuration reasoning; no actual resolved or compiled target feature graph was inspected or executed here.

The new public integration definition is meaningful for the reported failure:
- lines 7–17 fix the known g anchor to 0x3ffc70a545d535a4 and independently supply the original seven decimal coefficients;
- lines 18–27 exercise both serialized public defaults and explicit decimal JSON through typed parsing, serialization and reparsing;
- lines 30–48 compare all seven parsed and repeated values with to_bits, without numeric tolerance. A g ending in ...35a5 would fail against the anchored ...35a4.
The explicit-decimal route supplements the default-to-default roundtrip rather than merely checking a value against its own serialization. This remains a source definition, not a test pass or an actual Wasm test.

The observed response discrepancy was coefficient metadata with MPC false and otherwise matching non-clock return fields. This review infers no score effect, MPC/search correctness effect, strength, performance or default/model promotion. Actual feature-enabled compilation, the new test and repaired native/Wasm transport/numerical correspondence remain UNRUN/unqualified in this review. Original native12/original4 and all old failures/costs retain their previous scopes.

No target imports, parser evaluation, compiler/Cargo/test/native/Wasm/oracle/Search/RNG, weights/model/data/RAW reads, comparison weakening or source changes occurred. Only maintained process/Beads infrastructure was executed. Fixed refs were checked before decoding and again at final source STOP. The original CPUPlan was used unchanged: management18/review6/library1/GPU0, 64MiB management plus conservative 960MiB descendants within 1GiB, 4GiB host reserve, explicit OWN CANCEL and <=180-second reader deadlines. Actual reader/handle/direct-reap/TMP facts and disk-versus-returned finalization distinctions are recorded separately; they assert no future quiet.

The issue stays in_progress pending Root acceptance. This related source minimum, ordinary note and backup are not build, native, parent-close or reply gates.
