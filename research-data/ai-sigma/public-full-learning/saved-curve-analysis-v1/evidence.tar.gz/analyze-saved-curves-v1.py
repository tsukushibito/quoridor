"""Compare recorded full-validation observations; no labels or model inference."""

import csv
import gzip
import hashlib
import json
import statistics
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

WORK = Path("/workspaces/quoridor/.worktree/learning-million")
ART = WORK / ".artifacts/public-full-learning"
BASE = Path("/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning")
DEST = ART / "curve-analysis-v1"
DEST.mkdir(exist_ok=True)
specs = [
    ("3e-5", BASE / "convergence-v1/lr3e-5/output", "fit-lr3e-5-result-collection-r1.json"),
    (
        "1e-4",
        BASE / "convergence-v1/lr1e-4/recovery-r3/output",
        "fit-lr1e-4-recovery-stop-receipt-r3.json",
    ),
    ("3e-4", BASE / "convergence-v1/lr3e-4/output", "fit-lr3e-4-stop-receipt-r3.json"),
    ("0.1", BASE / "lr-bracket-v1/lr0p1/output", "bracket-lr0p1-stop-collection-v1.json"),
    (
        "0.005477",
        BASE / "lr-bracket-v1/midpoint1/output",
        "bracket-midpoint1-stop-collection-v1.json",
    ),
    (
        "0.023403",
        BASE / "lr-bracket-v1/midpoint2/output",
        "bracket-midpoint2-stop-collection-v1.json",
    ),
    (
        "0.011322",
        BASE / "lr-bracket-v1/midpoint3/output",
        "bracket-midpoint3-stop-collection-v2.json",
    ),
    ("0.01", BASE / "decay-pair-v1/factor0p5/output", "decay-factor0p5-stop-collection-v1.json"),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def small(point):
    return {
        "epoch": point["completed_epochs"],
        "step": point["step"],
        "seen": point["training_seen"],
        "wall_seconds": point["wall_seconds"],
        "V": point["validation"]["target_mse"],
        "LR_after_selector": point["lr"][0],
    }


data = {}
summary = []
rows = []
for label, out, receipt_name in specs:
    path = out / "curves.jsonl.gz"
    if path.exists():
        with gzip.open(path, "rt") as stream:
            points = [json.loads(line) for line in stream]
    else:
        path = out / "curves.json"
        points = json.loads(path.read_text())
    receipt_path = ART / receipt_name
    receipt = json.loads(receipt_path.read_text())
    config = json.loads((out / "config.json").read_text())
    controller = receipt.get("controller", receipt.get("controller_failure_preserved"))
    assert all(p["validation"]["rows"] == 419150 for p in points)
    assert all(
        p["completed_epochs"] == e and p["step"] == 4109 * e and p["training_seen"] == 8413949 * e
        for e, p in enumerate(points)
    )
    assert config["training"]["lr_decay_factor"] == 0.5
    assert config["training"]["batch_size"] == 2048
    assert (
        digest(out / "initial-model/weights.f32")
        == "2ddacbf88145816b6b0c86e13ebb983d7c1b64e42f8d346623873a18ae7414ad"
    )
    best = min(points, key=lambda p: p["validation"]["target_mse"])
    minimum = best["validation"]["target_mse"]
    baseline = points[0]["validation"]["target_mse"]
    significant_best = float("inf")
    last_reset = None
    for p in points:
        loss = p["validation"]["target_mse"]
        if loss < significant_best - 0.0001:
            significant_best = loss
            last_reset = p["completed_epochs"]
    decays = []
    for index, (before, point) in enumerate(zip(points, points[1:]), 1):
        if point["lr"] != before["lr"]:
            following = points[index + 1] if index + 1 < len(points) else None
            decays.append(
                {
                    "after_epoch": point["completed_epochs"],
                    "before_LR": before["lr"][0],
                    "next_LR": point["lr"][0],
                    "V_before_trigger": point["validation"]["target_mse"],
                    "following_epoch": small(following) if following else None,
                    "following_epoch_V_drop": point["validation"]["target_mse"]
                    - following["validation"]["target_mse"]
                    if following
                    else None,
                }
            )
    crossings = {}
    for target in (0.44, 0.435, 0.43, 0.42605264436242674):
        first = next((p for p in points if p["validation"]["target_mse"] <= target), None)
        crossings[str(target)] = small(first) if first else None
    early = points[1:11]
    changes = [
        b["validation"]["target_mse"] - a["validation"]["target_mse"]
        for a, b in zip(early, early[1:])
    ]
    full_train_points = [p for p in points if p.get("train_scope") == "full_train"]
    train_match = full_train_points[-1] if full_train_points else None
    p10 = points[10] if len(points) > 10 else None
    times = [b["wall_seconds"] - a["wall_seconds"] for a, b in zip(points, points[1:])]
    item = {
        "label": label,
        "initial_LR": config["optimizer"]["lr"],
        "final_epoch": points[-1]["completed_epochs"],
        "BEST": small(best),
        "LAST": small(points[-1]),
        "whole_job_seconds": controller["wall_seconds"],
        "raw_job_outcome": controller["outcome"],
        "significant_best_last_reset_epoch": last_reset,
        "significant_best_value": significant_best,
        "strict_best_minus_significant_best": minimum - significant_best,
        "crossings": crossings,
        "decays": decays,
        "epoch10": small(p10) if p10 else None,
        "remaining_improvement_after_epoch10": p10["validation"]["target_mse"] - minimum
        if p10
        else None,
        "fraction_own_total_improvement_by_epoch10": (baseline - p10["validation"]["target_mse"])
        / (baseline - minimum)
        if p10
        else None,
        "epoch1to10_increases": sum(x > 0 for x in changes),
        "epoch1to10_max_upward_step": max(changes) if changes else None,
        "epoch_interval_mean": statistics.mean(times),
        "epoch_interval_median": statistics.median(times),
        "last_measured_fulltrain": {
            "epoch": train_match["completed_epochs"],
            "T": train_match["train"]["target_mse"],
            "V": train_match["validation"]["target_mse"],
            "V_minus_T": train_match["validation"]["target_mse"]
            - train_match["train"]["target_mse"],
        }
        if train_match
        else None,
        "BEST_V_sign_accuracy": best["validation"]["z_sign_accuracy"],
        "BEST_V_saturation_fraction": best["validation"]["saturation_fraction"],
        "bindings": {
            "output": str(out),
            "curve_path": str(path),
            "curve_SHA": digest(path),
            "receipt_path": str(receipt_path),
            "receipt_SHA": digest(receipt_path),
            "config_SHA": digest(out / "config.json"),
        },
    }
    summary.append(item)
    data[label] = points
    for p in points:
        row = {
            "initial_LR": config["optimizer"]["lr"],
            **small(p),
            "train_scope": p["train_scope"],
            "T_measured_MSE": p["train"]["target_mse"],
            "V_group_MSE_secondary": p["validation"]["target_game_equal_mse"],
            "V_sign_accuracy": p["validation"]["z_sign_accuracy"],
            "V_saturation_fraction": p["validation"]["saturation_fraction"],
        }
        rows.append(row)

payload = {
    "scope": "saved aggregate full-original-validation points only; no labels/checkpoint/model inference",
    "reference_target_fixed_before_current_run": 0.42605264436242674,
    "candidates": summary,
    "interpretation_limits": [
        "Same INITIAL/order/RNG/model/data; one stochastic trajectory per condition, no multi-seed uncertainty estimate.",
        "LR point is recorded AFTER epoch scheduler; new rate applies to subsequent updates; first epoch includes 257 warmup steps.",
        "Sequential change after decay is association, not a counterfactual proof of optimal trigger timing.",
        "FullV selection was repeatedly exposed; not a final heldout/generalization or strength claim.",
        "Original lr3e-5 pipeline output-limit failure remains failed; scientific stop was reconstructed separately from durable fullV.",
        "Compiler co-running and recording versions differ; whole wall is observed cost, not a fair comparative speed measurement.",
        "No interpolation used for threshold crossing; early stopping compares significant minimum, strict BEST may still improve.",
        "NewE and Sigma comparison remain sealed/unreleased.",
    ],
}
(DEST / "analysis.json").write_text(json.dumps(payload, indent=2) + "\n")
with (DEST / "epoch-observations.csv").open("w") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)

fig, axes = plt.subplots(2, 2, figsize=(14, 9), constrained_layout=True)
colors = plt.get_cmap("tab10")
for idx, (label, points) in enumerate(data.items()):
    epochs = [p["completed_epochs"] for p in points]
    values = [p["validation"]["target_mse"] for p in points]
    color = colors(idx)
    axes[0, 0].plot(epochs, values, ".-", markersize=3, linewidth=1, color=color, label=label)
    axes[0, 1].plot(epochs, values, ".-", markersize=2, linewidth=1, color=color)
    axes[1, 0].step(epochs, [p["lr"][0] for p in points], where="post", linewidth=1.3, color=color)
    axes[1, 1].plot(
        [p["wall_seconds"] / 60 for p in points],
        values,
        ".-",
        markersize=2,
        linewidth=1,
        color=color,
    )
for ax in (axes[0, 0], axes[0, 1], axes[1, 1]):
    ax.axhline(0.42605264436242674, color="black", linestyle="--", linewidth=1)
    ax.set_ylim(0.423, 0.52)
    ax.set_ylabel("Full original validation row MSE")
    ax.grid(alpha=0.3)
axes[0, 0].set(
    xlim=(0, 20),
    ylim=(0.423, 0.66),
    xlabel="Completed epochs",
    title="Initial decline including the finite 0.1 spike (step0 above range)",
)
axes[0, 0].legend(title="Initial LR; all decay factors 0.5", fontsize=8)
axes[0, 1].set(xlim=(0, 150), xlabel="Completed epochs", title="All recorded epoch observations")
axes[1, 0].set(
    xlim=(0, 70),
    yscale="log",
    ylim=(5e-7, 0.15),
    xlabel="Completed epochs",
    ylabel="LR for subsequent updates",
    title="Validation-triggered decay; warmup omitted from epoch trace",
)
axes[1, 0].grid(alpha=0.3)
axes[1, 1].set(
    xlabel="Saved training wall minutes (co-running costs differ)",
    title="Observed wall cost; dashed line is fixed near-reference target",
)
fig.suptitle(
    "Eight saved trajectories / same INITIAL and batch2048 / no new fits\nMarkers are observations; connecting lines are guides only"
)
fig.savefig(DEST / "comparison.png", dpi=120)
fig.savefig(DEST / "comparison.svg")
plt.close(fig)

print(json.dumps(summary, indent=2))
assert sum(p.stat().st_size for p in DEST.iterdir() if p.is_file()) < 1048576
