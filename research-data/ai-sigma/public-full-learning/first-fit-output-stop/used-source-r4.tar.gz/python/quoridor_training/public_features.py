"""Lossless QF1 input geometry and native-defined left/right augmentation.

The canonical Sigma adapter fixes STM to player zero. Geometry stores that
checked position, not a new feature layout; decoding returns the maintained
two QF1 views. Reflection preserves goal rows, STM, stocks, distance and z.
"""

import numpy as np

GEOMETRY = np.dtype(
    [
        ("pawns", "u1", (2,)),
        ("stocks", "u1", (2,)),
        ("horizontal", "<u8"),
        ("vertical", "<u8"),
    ]
)
RECORD = np.dtype(
    [
        ("geometry", GEOMETRY),
        ("distance", "<f4", (2,)),
        ("z", "i1"),
        ("shard", "u1"),
        ("row", "<u4"),
        ("input_sha", "u1", (32,)),
    ]
)
SCHEMA = "quoridor-public-geometry-v1"
REVISION_NAME = "original-full-v1"


def wall_bits(values):
    raw = np.ascontiguousarray(values, dtype="<u8").view("u1").reshape(-1, 8)
    return np.unpackbits(raw, axis=1, bitorder="little")


def wall_integers(bits):
    raw = np.packbits(bits, axis=1, bitorder="little")
    return np.ascontiguousarray(raw).view("<u8").reshape(-1)


def validate_geometry(geometry):
    if geometry.dtype != GEOMETRY or geometry.ndim != 1:
        raise ValueError("canonical geometry dtype/shape")
    if np.any(geometry["pawns"] >= 81) or np.any(geometry["stocks"] > 10):
        raise ValueError("canonical geometry pawn/stock bounds")
    if np.any(geometry["pawns"][:, 0] == geometry["pawns"][:, 1]):
        raise ValueError("canonical geometry coincident pawns")


def features(geometry):
    """Existing QF1: 81 own +81 opponent +64 H +64 V +11+11 stocks."""
    validate_geometry(geometry)
    n = len(geometry)
    x = np.zeros((n, 2, 312), dtype=np.float32)
    index = np.arange(n)
    for view in range(2):
        own = geometry["pawns"][:, view].astype(np.int64)
        other = geometry["pawns"][:, view ^ 1].astype(np.int64)
        if view == 1:
            own, other = 80 - own, 80 - other
        x[index, view, own] = 1
        x[index, view, 81 + other] = 1
        x[index, view, 290 + geometry["stocks"][:, view].astype(np.int64)] = 1
        x[index, view, 301 + geometry["stocks"][:, view ^ 1].astype(np.int64)] = 1
        for name, first in (("horizontal", 162), ("vertical", 226)):
            bits = wall_bits(geometry[name])
            x[:, view, first : first + 64] = bits if view == 0 else bits[:, ::-1]
    return x


def geometry_from_native(bits):
    """Accept only exact two-view QF1 bytes supplied by native qualification."""
    bits = np.asarray(bits)
    if bits.dtype != np.dtype("u1") or bits.ndim != 2 or bits.shape[1] != 78:
        raise ValueError("native bitset shape/dtype")
    x = np.unpackbits(bits, axis=1, bitorder="little").reshape(-1, 2, 312)
    view = x[:, 0]
    out = np.zeros(len(bits), dtype=GEOMETRY)
    for target, parts in (
        ("pawns", ((0, 81), (81, 162))),
        ("stocks", ((290, 301), (301, 312))),
    ):
        for player, (first, end) in enumerate(parts):
            values = view[:, first:end]
            if not np.all(values.sum(axis=1) == 1):
                raise ValueError("native QF1 one-hot qualification")
            out[target][:, player] = values.argmax(axis=1)
    out["horizontal"] = wall_integers(view[:, 162:226])
    out["vertical"] = wall_integers(view[:, 226:290])
    if not np.array_equal(features(out), x):
        raise ValueError("geometry does not reproduce both native QF1 views")
    return out


def reflect(geometry):
    """Native coordinates: pawn x ->8-x; each 8x8 wall anchor x ->7-x."""
    validate_geometry(geometry)
    out = geometry.copy()
    pawns = geometry["pawns"]
    out["pawns"] = pawns // 9 * 9 + (8 - pawns % 9)
    for name in ("horizontal", "vertical"):
        bits = wall_bits(geometry[name]).reshape(-1, 8, 8)
        out[name] = wall_integers(bits[:, :, ::-1].reshape(-1, 64))
    return out


def model_keys(records):
    """Injective geometry+f32 distance identity, equivalent to exact QF1 equality.

    No Python row dictionaries or full dense feature tensor are materialized.
    Original input SHA is separate because qualified float planes need not have
    identical original bytes for an identical native model input.
    """
    raw = records.view("u1").reshape(-1, RECORD.itemsize)
    return np.ascontiguousarray(raw[:, :28]).view("V28").reshape(-1)


def phase_proxy(geometry):
    total = geometry["stocks"].sum(axis=1, dtype=np.uint16)
    return np.where(total >= 16, 0, np.where(total >= 6, 1, 2)).astype(np.uint8)
