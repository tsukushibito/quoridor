# quoridor-4lc.323.1 全量original・correctLR入力境界レビュー

対象: input-review-binding-r2.json / same reviewer thread 01a1103c-fbe0-7412-a406-fbee697a1392。
仕様: main research-data/ai-sigma/public-full-learning/task.mdと今回契約。旧319 notes/推論は根拠に用いない。

## 結論

**固定r2の静的sourceと10件の小NN0 fixtureでは重大な実装欠陥を検出しなかった。** 全originalの行別資格、既alias split、開封済元IDの隔離、66B recordから両QF1 viewへの対応、correctLR geometry/同zは確認範囲で整合する。

**nativeLR R2の一つのexact fixtureもPASSを確認した。** 提示log/process/stop receiptを実際に読み、binding/fixture/ELF/immutable libraryのSHAを照合、exit0・exact wait・remaining=[]を確認した。R1失敗は保全する。固定producer/geometry/loaderの今回境界は確認完了。

実callerのonlineLR50%・別seed RNG・fixed original validation、最終freeze/test callerは今回binding外なので未確認。全43実corpus/live NNや実caller接続まで資格済みとはしない。SigmaNN入力への復元・最終比較は別関連差分。Rootは今回の採用範囲をこの固定入力境界へ限定し、実接続の関連差分/evidenceを同threadへ追補できる。

## 版不整合と通常修復の記録

開始時は初版bindingの全11path一致。読取中の再確認でexternal_outcomes.rsが初版SHAから変わったため、契約に従ってfixture実行を停止した。

- call: SHA256(external_outcomes.rs bytes)
- 初版期待/開始時実値: 3e02bd192026d7c7cec20023a3cb0476c5d1e4bf06d623b83fd9f42aec5ce8f0
- 不整合時実値: b22cdb1cea3d907e4220495311208049406f16b495a1e89d95383e2d1de1764c

その後、同じturn中の依頼通知でr2 bindingとfixture変更点が明示された。r2は上記実値を固定し、他10pathは変更なし、全11path再一致。**対象版不整合は再bindingによって解消**。初版・事象・費はJSONに保持してresetしない。

提示R1 stop-receiptはCargo build後のnative test exit101 / controller exit1、FAILED_TERMINAL_FIXTURE_TURN、cleanup_complete=true、remaining=[]を記録。winner0/turn0のterminal fixtureは維持された規則に反し、r2:140–164はturn=winner^1へ修復。r2:60–66は勝利遷移を確認するgoal predecessorを追加。collection最初のPYTHONPATH拒否もadministrative履歴として提示receiptに残る。**build PASSや旧exitをLR資格PASSへ昇格しない**。

## 一次sourceと各境界

### 全量・分割・開封観測

- public_sigma.py:54–60は全half candidate=True、旧seed31920261006/元blob+index由来mix64 XOR1によるsplitを維持。全43 originalに資格機会があり、bottom-rank切詰めなし。plan:337–345は決定的partition/厳密IID NOT_PROVEN/未知露出UNKNOWNを明記する。
- opened_observations:176–240は開封receipt hash/test_opened、旧manifest hash/revision/original-only/schema、旧174B binary hash/行数を束縛し、ID field offsets90/92/96からshard/row/aliasだけを解釈する。固定source blob/同元行数、row==alias、前半rowを確認し、重複IDをまとめる。原入力一致から由来を捏造しない。binary hashはファイルbyte全体を読むが、旧labelや旧featureを教師として解釈・供給する経路ではない。
- process_shard:243–309は前半originalを4096行単位でstates/valuesから読み、opened元indexをpartition3へ固定してT/V/newEから隔離する。native不正/code1–6とz0 UNKNOWN(reason7)/不正label(reason8)を行単位で除外し、原z/ID/reasonを保存する。同入力の別±1を群別削除せず保持。後半naiveLRを教師に使わない。
- 分母は全original観測。4partitionはT/V/newE/evaluation-openedで、旧開封観測も第4出力として保存される。distinct/model input group/game数を保存行数と同一視しない。開封50k receiptの実全coverage/config、実all43原分母・件数は大corpus読0のため未確認。

### 66B record・両QF1 view・correctLR

- public_features.py:10–27でrecord全体66B = canonical geometry20B + f32 STM distance8B + z1B + shard1B + row4B +原planes SHA32B。元rawplanes全floatの復元保証ではない。
- geometry_from_native:72–93はnative78Bをlittle bit順に解き、view0のonehot pawn/stock・H/V64anchorをgeometryへ格納した後、features(out)の**両view全624値**がnative bytes由来の特徴と一致することを要求する。
- features:51–69とNNUE features.rs:42–67のpawn own/opponent、P2の180度cell/anchor回転、H162/V226、stock290/301、STM distance順が一致。producerは距離f32を再丸め・推定せず保存する。model_keysは先頭28Bのgeometry+distanceの正確なbyte identityで、z/sourceID/rawSHAを群同定に混ぜない。
- native lib.rs:832–903はfinite/onehot/stock/segments/padding、Position.checked、全8plane/native distance-mapの一致を判定し、915–971はrow別にQF1 bitsetとDを出す。core research.rs:411–486のcanonical STM own/opponent/P2上下反転とH anchor補正に対応する。実replay履歴や原gameの復元を証明したものではない。
- reflect:96–105はpawn9wide x→8−xとwall8wide anchor x→7−xを区別する。player identity/stock/STM/goal行を変えない。scalar_reference/scalar_reflectionは独立のcell/anchor座標loopを使い、P2 view・非対称壁・境界・二回復帰と照合する。
- Rust r2 fixture:26–55の独立座標/Action oracle、58–164の両turn、boundary anchors、jump/diagonal条件、legal action集合、全legal遷移と勝利遷移/terminal goal、QF1 ids/STM/D同一・同zを検査する構成は静的に妥当。R2の実行担当によるexact fixture PASSを下記receiptで確認した（レビュー側のnative再実行は0）。

### bounded loader・labels

- CompactCorpus:65–105はschema/original-full-v1/66B/source43、partition/file/hash/byte数、finite distance/decisive z、原前半indexを確認。通常loadはtrain/validationだけをmap/hashし、test-sealedとevaluation-openedを開かない。
- records/batch:146–165はbounded indexのrecord copyに対して指定maskのみreflectし、distance/zは元の順に返す。mask dtype/shapeを確認し、元mappingを変更しない。両viewは必要batchだけ展開し、全dense corpusは保持しない。
- loaderはmaskを受け取る低層APIであり、validation indexにTrueを渡すこと自体は拒否しない。**実callerのtrain-only mask生成/50%/別RNGとvalidation無反転は今回source bindingに含まれないので未確認**。これは現loaderの欠陥と断定せず、採用前に必要なcaller境界として残す。
- cache.load:461–469はgeometry schemaをこのloaderへ接続。frozen test manifestの照合・label開封順を確認するtest_public_sigma:248–260はbinding外train.pyをimportするためレビュー側の実fixtureから除いた。final test callerを資格済みとはしない。
- producerはsource/admission SHAをcompute前に確認し、shard scratchを自分の所有範囲だけで削除。CycleResources:145–170はdeadline=Noneをそのまま扱い、RAM/output/pause制御を維持。保存aggregate/実peak・上位owner/cancel/controller設定は実jobのreceiptで別途確認する。全域/共有targetのwalkや大corpus scanは実施しない。

### upstream STM/z一次source

提示refsの3C++ sourceはbytes/SHA256とGit blob framing付きSHA1を独立計算して全一致（ネット照合0）。selfplay.hpp:638/645、1067/1078は同stateのnn_inputとcurrent_playerを記録し、1129–1137はrec_player==winnerなら+1、他は−1、winner0なら0。engine.hpp:138–139と458–493はdepth%2、own/opponent/P2上下反転とH anchor補正。bindings.cpp:303–329は同get_dataのstates/valuesをPythonへmemcpyする。

正しいLRはplayerを交換しないため同STMのzをコピーする。naiveLRのコピーzが正しい教師だという主張はしない。source game/history欠測と過去/Sigma露出UNKNOWNは保持する。

## 実検証と未確認

レビュー側はPublicGeometryTests、PublicSigmaContracts、bounded loader reflection/sealingの**10件PASS**。unittest0.038s、child wall0.168793s、peak RSS54,248KiB。affinity3、OPENBLAS1、address-space512MiB、TMPDIR=review-input、-B。

これらは独立scalar QF1/reflect oracle、involution、sourceIDとモデル群の区別、native bitset2view不整合拒否、全候補/旧split、mock nativeの行別除外/±1保持/hostile LR未入力、旧opened ID import、loader sealing/copy/D/zを検査する。mock nativeは本物の入力合法性を証明しない。実行担当の18NN0 PASSは別の提供証拠として保存し、reviewer10件と混算しない。native R1 failure/R2 PASSも別に維持する。

R2 native receiptの追補は確認済み。残る未確認はactual opened集合coverage/all43件数、実caller RNG50%/fixed V、frozen newE/SigmaNN評価境界。毎fitの再レビューや新担当は要求しない。実行担当から同threadへ対象追加binding/receiptを返す。

## Native R2追補の照合

input-qualification-r2/native-fixture-0.logはexact名の1 passed / 0 failed / 3 filteredを記録。process.jsonはcommand --exact、exit0、direct_child_reaped=true、remaining=[]、cleanup_complete=true。stop-receiptは同child identityとcontroller succeeded、fixture source b22cdb…、r2 binding a8ff2605…を束縛。ELF d75a362f…とimmutable compact library f83dbc68…を実ファイルSHAで照合して一致。実行担当controller wall10.645010秒（旧R1を含むnative累積33.467500秒）は親の費でありレビュー側費へ混算しない。

bindingのnative_test_statusはNOT_RUNの旧文字列を残すが、同じbinding SHAを参照するこのreceiptでR2 PASSが追加された。source/bindingをレビュー側で編集しない。build/NNforward/GPU/all43資格に拡張して解釈しない。

## 管理・停止

新namespace/quoridor-4lc.323.1に実費・source/refs/spec SHAを記録。時間/end/MAXcommand capはnull。旧319完了・旧費/失敗/報告を保持。source/code/main/Git writer0、native/Torch/build/GPU/network/大corpus/newjob/再委譲0。証拠のみreview-input専有で2MiB内。reader/自己job/childは停止する。

環境の有効設定danger-full-access/never・cwd・CPU3と同model/effortを確認。dispatch JSON自体はacceptedだけを含むためpermission適用応答の証明とは混同しない。ready/showはscalar、本人claim済み。今回の静的+NN0レビュー結果をBeadsへ記録し両宛先へ一度通知、backup後Idle。**親323の導入/本学習・評価をcompletedとしない**。native資格/関連caller差分の追補は同issue/threadで行う。
