quoridor-4lc.323.1 初回fullfit前の固定cohort/config関連確認完了。重大/通常指摘0。承認済みの研究条件と3候補の実入口に対応不整合は見つからなかった。最適条件・本fit成功・finalSigma/newE releaseの認定ではない。

対象 full-fit-source-binding-r4.json SHA49c0e51a78037c9ccebed18c200c9f1ed6930f418e59707f9b6beaa6c5dd3805 の18source SHA一致。locked-cohort-v1.json SHAdb5076c65798d68cce14924513e93ed1bd790b31ed57337206beed297a9f44cf。全3 config/input-binding/guard/job SHAと37件の参照artifact SHAを照合。train/test_observation以外16sourceはr3と同一。旧r3・失敗・費/11PASSを保持、reset0。

3候補LR3e-5/1e-4/3e-4はLR以外のconfig完全一致。batch2048、FT32/H32 route4off/dropout0/FP32、Adamwd0、D a0b8、seed32320261007、反転50%別seed32320261008、元V、z/row/epoch。T8413949からepoch4109updates/末尾765、warmupceil(4109/16)=257、診断間隔ceil(4109/8)=514。plateau.5/patience2/minLR1e-6、fullV rowMSE epoch patience8/min_delta1e-4、steps/time/samples/null。既観測最小BESTとmin_deltaの停止判定の区別はr3確認範囲を維持。

提供5実測medianを独立再計算：128=3.4279759745e-5、512=1.0634898956e-5、2048=3.4456079447e-6秒/元行。固定minmedian規則が2048を選ぶ。LR線形倍率や候補重み選定はない。これはwarm供給proxyでありwhole-fit費/収束/棋力ではない。

INITIAL SHA2ddacbf88145816b6b0c86e13ebb983d7c1b64e42f8d346623873a18ae7414adは全inputbinding/cohort/supply result/実qualified INITIAL weightsで一致。cache07d81…75279b、T-only scale0a322…4a61b/constantd1ee90…08b7、native ELF d8d5b9…ee635/libraryf83dbc…f1f3、選択source18/config/controlsは各guardのexpected SHAに対応。guarded_train1577–1608は固定fit_configとinput_bindingを子へ必ず渡す。実job3組は--guard-configに接続し--steps/--scale等overrideなし。null科学capsと既存RAM/VRAM/output/正確子回収は別制御として存続。storage admission within/errors[]も確認した。

train.py871–879: 実INITIAL nativeexport後、compact+input_binding callerでverify_initial_bindingを呼び、LAST保存/初selector/optimizer forwardより前に不一致を拒否。1174–1177は欠落identityも拒否。直接noinputbindingのtiny fixtureを本番入口の代用としない。新純NN0 mismatch/missing-identityケースをreviewerが1PASS（0.122340312s、peak44856KiB、CPU3/RAM512MiB、Torch import拒否/TorchFalse、native/build/GPU0）。提供20NN0 logはSHA確認した別実行で、重複加算しない。secondary stratum1138–1149は original_train_input_known となり、元cacheのtrain所属だけを示す。反転入力の未見性や独立game/IIDの根拠にしない。

提供 supply-recovery-r1 receipt/result SHA一致。controller40.979733054s/exit0/remaining[]、6 direct childrenは全exit0/reaped/cleanup[]。native initial+CPU二破棄更新のfull/delta/undo/FTScalarSimd/headScalarは提供証拠PASS、nativeCPU最大1.4551915e-11、CPUCUDA更新parameter最大3.7252903e-9。tiny fixtureは1epoch/2train rows/14model rowsでEARLY_STOPPED、INITIAL/BEST step0、LAST step2、PT/nativebytes/PNG assertionが通った実logとstatusを照合。親がPNGを閲覧済みとの報告は受領、reviewerは画像/PT/推論を再実行していない。

実supply/tiny証拠のsource bindingはr3(c9a8f8…)である。r4追加INITIAL guard/名称変更は今回静的+純NN0確認のみ。r4 bindingのrelated_new_fixtureに旧NOT_RUN記述が残るため、実行済範囲はactual_qualification_STOPとそのr3 SHAで区別する。全43本fitの成立・3LR収束/選定、全学習層でのnative一致、厳密IID、旧公開履歴未露出、finalSigma/newE開封は未認定。newE/旧開封labelsは読んでいない。

証拠 review-input/cohort-review-r4.md/json、-correspondence.json、-fixture.json、-control.json。writerは同review evidenceのみ2MiB内、製品/source/main/Git0。旧証拠/費は保全。reader/job/owned children停止、learning323とRootへ一度ずつ直接通知し323.1のみ閉じ、backup後Idle。毎fitレビュー/新role/新job/再委譲/常設監視なし。
