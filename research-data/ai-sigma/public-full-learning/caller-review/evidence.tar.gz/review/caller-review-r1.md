# quoridor-4lc.323.1 actual caller 関連レビュー r1

対象: caller-review-binding-r1.jsonの12source paths、convergence-plan-v1.json、NN0 log、data STOP receipt。same reviewer/thread。元input review・native R1 failure/R2 PASSは変更せず再利用。仕様はmain public-full-learning/task.mdと今回契約。

## 結論

**固定版のactual callerに重大指摘なし。静的確認と関連11件NN0 fixtureはPASS。** optimizer入力だけのcorrectLR、独立反転RNG、original V/予測、null科学的horizon、fullV row selector、T-only尺度/定数、named INITIAL/BEST/LASTの接続は確認範囲で整合する。

通常指摘2件は下記の失敗時カウンタ名・診断CSVのscope欠落。正常fitの教師・optimizer行平均・fullV選定を壊すものではない。実行担当が通常修正できる。**live trainer/GPU数値/実named export動作、採用batch/各LRの実config・guard/input binding、候補間比較の実結果は未確認。** finalSigma/test releaseは本reviewから採用しない。

## 通常指摘（重大ではない）

### C1 / P2: 反転供給のattemptをforward済み行数と表示する

sampling.py:73–78はcorpus.batch/transfer/forwardより前にtraining_seen/reflected_seenを加算し、train.py:820–824はこれをtraining_forward_original_rows/reflected_original_rowsとして保存する。供給/転送で失敗した場合、forwardしていない元行も含まれる。

- call: ReflectionBatches.batch([0], training=True)、mock corpus.batchがforward前にValueErrorを出す。
- 期待: forward済み行数0、attempted/drawn行数1を区別。
- 実値: supply.training_seen=1、actual forward_rows=0。
- 推奨: このcounterをaugmentation attempted/drawnと明示するか、completed forwardを別に保存する。成功update exposureはtrain.py:973–976で加算されるため正常epoch/教師量に影響しない。失敗後の成功・seenを水増ししない表示の修正であり、反転数学は変更不要。

### C2 / P2: 診断CSVだけではscopeを自己帰属できない

診断record(train.py:741–747)にはscope=fixed_target_blind_subset/used_for_selection=Falseがあるがtrain_scopeがない。_curve_csv:1168–1221はpoint.get(train_scope)を空欄にし、validation scope/rows/kind列を持たない。

- call: _curve_csv([fixed_target_blind_subset record], path)
- 期待: fixed diagnostic T/V scopeをCSV列でも明示。
- 実値: train_scope=""、validation_scope列なし（小NN0 probe）。
- JSONとdiagnostic-curves.csvのファイル名、SVG/PNGでは正しく区別される。CSVにscope/kind/T/V rowsを足すか、train_scopeを診断recordにも付与する通常修正を推奨。fullV selectorデータとの混同を防ぐための記録改善で、選定処理の欠陥ではない。

## 問いごとの確認

### 1. onlineLR caller / RNG / exposure

- train.py:326–328はReflectionBatchesをepoch samplerとは別seedで作成。sampling.py:60–78は専用np.default_rng、train probabilityに対するBernoulli mask（50%は確率であり各batchを厳密半数に固定しない）を生成し、training=Trueのindexがsplit0以外なら拒否する。
- optimizer loopのtrain.py:928だけがbatch(index, training=True)を呼ぶ。predict:470–484はbatch(sub)の既定training=Falseでoriginalを読む。T診断/fullT/V評価は反転RNGを消費しない。export traceもcorpus.batch直接でoriginal。
- EpochSamplerは独立np generatorで元行を各epoch一巡・小tailも一度使う。reflectionは元ID・D・zを変更せずsaved rowsを追加しない。train teacherは元labels[index,column]、row loss weightsは1。successful training_seen/row countsはfinite optimizer update完了後のみ加算され、effective epochの分母はT original行数。反転兄弟を独立gameにしない。
- common.py:183–187は反転seedとepoch seedの同一を拒否する。planはmodel/epoch32320261007、reflection32320261008、diagnostic32320261009、probability0.5、V originalを束縛する。実batch選択後の具体configはpendingなので、planの値が実guard/configへ採択されたという資格まではしない。

### 2. null horizon / selector / schedule / scopes

- update_steps(None)はitertools.count(1)。common.py:152–169はsteps=Noneの際にtime/samples=None、epoch sampling、row monitor、epoch early stop/patience>0、horizon依存checkpointsを禁止する。train.py:446–452/879–887はNone capを課さず、guarded_train:1563もcfg.seconds=Noneならdeadline=None。RAM/VRAM/output/owner/pause等の実制御は維持する。
- ConvergenceObservations:149–159はstep0+completed epochでfullV selector、dense0/1/2/5/10/20と25刻み≤2000、その後固定diagnostic_interval+epochs、fullT epoch1+指定epoch周期を決める。planned_seenから判定し、成功update後にevaluateする。診断だけの点はselector/patience/LR scheduling/BESTへ入らない。
- evaluate:651–724は全eligible V originalを同forward保存予測からrowMSEへ集計する。early stoppingはstep0とepoch selectorでmin_delta/patience、plateauはwarmup後のepoch lossだけ。BESTは別にloss<best_lossの厳密な観測最小なので、min_delta以下の改善も保存する。exact tieは既存早いstepを維持する。跨LRのlower-LR tie規則はplanで固定されるが実候補比較は未確認。
- compact gate:160–184はz/epoch/row loss/row monitor/original-full-v1、D残差FT32/H32、dropout0、a0/b8、Adam/wd0を要求。model sourceはFP32、route4ゼロ、TF32 off、finite loss/gradient/postupdate parametersの検査。warmupとReduceLROnPlateauは維持Torchの数学。レビュー側Torch/forwardは0。
- T fixed8192/V fixed8192はseed+2でtarget-blindに選び、selectorのTは通常diag、指定epochはfullT。JSONはtrain_scope/full_selector/fixed_target_blind_subsetを区別し、SVG/PNGもfull Vとfixed V診断を区別する。線は記録点間のguideで補間を測定としない。C2はCSVだけの不足。
- 曲線JSON/CSVは各観測点、PNG/SVGはselector/0/20/100/500/1000/2000/final。INITIAL/BEST/LAST以外の点別checkpointはunbounded configで禁じる。実image生成・外部plot環境は未実行。PNG helperに外部rendererの20秒administrative timeoutは残るため、science wall cap=Noneと全subprocessにtimeoutがないという主張は区別する。

### 3. T-only statistics / binding / actual checkpoints

- prepare_statistics:1345–1383は通常load(T/Vだけ)し、split0&eligibleの**original Tだけ**をmetadata_chunksへ渡す。reflectionなし、test/opened binなし。T row-mean constant、distance moments・QR diagnosticを保存し、fixed D a0/b8は診断fitと分ける。
- train:197/220でTのconstant/momentsを同じ経路で再計算。input_bindingが渡ればcache manifest SHA、scale/constant artifact SHA、config file SHA、実T mu/sigma/constant一致、外部scale override禁止を221–236で確認する。guarded_train:1565–1579はfixed config/cache/input-bindingを必ず渡し、source/control hashをchild前に確認。
- 直接train()/CLIではinput_bindingはoptionalで、config_pathのSHAはresolved override全体のSHAではない。今回の採用範囲はguarded_trainの固定config・overrideなしを前提とする。実guard config/input binding/scale artifactの最終組合せはpendingで、本reviewはその実ファイルの合格を認定しない。
- 小fixtureはtest/opened fileがないtoy cacheでprepare_statisticsを実行し、VのDを[0.7,0.9]、zを+1へ変更してもT mu/sigma/row constant=0が同一になることを確認。cache全partition manifest SHAはV変更で変わるので、artifact binding値まで同一だと主張しない。
- save_named_checkpoint:624–642は**その時のmodel**とoptimizer/config/scale/target/dataset/actual positionを保存し、そのmodelからnative weightsをexport。initialは初回eval前一度、bestは観測改善時、lastはselector後とfinallyの成功状態で上書きする。終了時にBESTをloadしてINITIAL/LASTを再exportする旧取り違えはない。
- 非finite等でmodel_state_status=UPDATE_IN_PROGRESS_OR_FAILED_UNKNOWNならLASTへ壊れた重みを上書きせず、前の実checkpoint位置を残す。LASTは失敗直前の全成功updateを必ず保持する保証ではなく、最後に保存済みの正確なpositionで帰属する。実Torch serialization/native参数対応・live interrupted runは未実行。

### 4. 開封・採用範囲

data STOP receipt SHAとRoot input acceptanceを参照し、提供実分母T8,413,949/V419,150/newE371,978/opened50,000、original9,457,039、excluded201,962を整合確認。これはRootが独立採用済みのmetadataであり、レビュー側はfull cache/newE/opened labelsを開かない。今回はinput/native oracleを再実行しない。

geometry schemaに合わせたverify_test_cache_before_open:1271–1284はfrozen cache manifest/schemaをload前に照合する経路を保持するが、finalSigma pathは未実装・未採用。各fitのBEST freezeと、全LR選定完了後の最終releaseは別。newEを学習・再選定に転用する許可を本reportから導かない。

## 実検証・版・費

全12source SHA、plan SHA、提供18NN0 log SHA、data STOP SHAが開始/fixture前/終盤で一致。既input review/native failure/PASS/archiveを編集しない。

reviewerはObservationContracts10件+T-only scale/constant1件の**11PASS**。unittest0.054秒、childwall0.168211秒、peak RSS59,120KiB。Torch importを拒否するimport guardを入れ、torch_imported=False。LiveTrainerObservation未実行。通常指摘の2小NN0 probeは0.064147秒/RSS40,340KiB/Torch=False。提供18PASSとは混算しない。native/build/GPU/network/fullcache/新job/再委譲0。

実commands/費・probe期待/実値・SHAはcaller-review-r1.json、-fixture.json、-probes.json、-control.json。今回time/end/count capsはnull。旧費/失敗は別namespaceで保全。source/product/main/Git writer0、evidence専有review-input2MiB内。same model/effort/cwd、実環境danger-full-access/never、CPU3/RAM512MiB。reader/自己job/child停止、両宛先へ一度通知・backup後Idle。親323は閉じない。
