"""Output-distance penalty; the frozen evaluator and tensor layout are unchanged."""

import math


def components(prediction, teacher, raw_distance, penalty_lambda):
    import torch

    if not math.isfinite(penalty_lambda) or penalty_lambda < 0:
        raise ValueError("nonnegative finite penalty lambda")
    if raw_distance.ndim != 2 or raw_distance.shape[1] < 2:
        raise ValueError("raw STM/opponent distance input required")
    distance_target = torch.tanh(8 * (raw_distance[:, 1] - raw_distance[:, 0]))
    teacher_loss = torch.nn.functional.mse_loss(prediction, teacher)
    penalty_loss = torch.nn.functional.mse_loss(prediction, distance_target)
    return {
        "teacher": teacher_loss,
        "penalty": penalty_loss,
        "total": teacher_loss + penalty_lambda * penalty_loss,
    }


def fixture():
    """Four scalar witnesses and two backwards, conservatively charge 32 equivalents."""
    import torch

    d = torch.tensor([[0.1, 0.2], [0.2, 0.1], [0.1, 0.1], [0.0, 1.0]])
    ref = torch.tanh(8 * (d[:, 1] - d[:, 0]))
    if ref[0] != -ref[1] or ref[2] != 0 or not torch.isfinite(ref).all():
        raise ValueError("f32 STM distance symmetry/finite")
    t = torch.tensor([0.3, -0.4, 0.5, -0.9])
    if components(ref, t, d, 1)["penalty"].item() != 0:
        raise ValueError("initial distance penalty must be bit-zero")
    p = torch.tensor([0.1, -0.2, 0.3, 0.7], requires_grad=True)
    zero = components(p, t, d, 0)
    if not torch.equal(zero["total"], torch.nn.functional.mse_loss(p, t)):
        raise ValueError("lambda0 criterion changed")
    zero["total"].backward()
    if not torch.allclose(p.grad, 2 * (p.detach() - t) / len(p), atol=1e-6, rtol=1e-6):
        raise ValueError("lambda0 gradient")
    p.grad = None
    one = components(p, t, d, 1)
    one["total"].backward()
    expected = 2 * (p.detach() - t) / len(p) + 2 * (p.detach() - ref) / len(p)
    if not torch.allclose(p.grad, expected, atol=1e-6, rtol=1e-6):
        raise ValueError("lambda1 penalty gradient")
    changed = components(p.detach(), -t, d, 1)
    if not torch.equal(changed["penalty"], one["penalty"]):
        raise ValueError("D penalty depends on teacher")
    if one["penalty"] < 0 or one["total"] < one["teacher"]:
        raise ValueError("nonnegative additive penalty")
    return {"status": "PASS", "sample_equivalent_upper": 32, "Torch_scalar_only": True}
