"""Apply exactly the stopped test/document migration and maintained callers."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/quoridor-tests-docs129/.artifacts/quoridor-test-doc129"


def fingerprint(path):
    data = path.read_bytes()
    return dict(
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def run(args):
    p = subprocess.run(args, capture_output=True, text=True, check=False)
    print(
        json.dumps(
            dict(argv=args, code=p.returncode, stdout=p.stdout[-4000:], stderr=p.stderr[-4000:])
        )
    )
    assert p.returncode == 0
    return p.stdout


manifest = json.loads((OWN / "manifest.json").read_bytes())
common = json.loads((OWN / "common-before.json").read_bytes())
for path, ref in common.items():
    actual = fingerprint(ROOT / path)
    expected = dict(ref)
    if path == "AGENTS.md":
        assert actual["mode"] == "0777"
        expected["mode"] = "0777"
    assert actual == expected, path
for row in manifest["files"]:
    assert fingerprint(ROOT / row["old"]) == dict(
        sha256=row["before_sha256"], bytes=row["before_bytes"], mode=row["mode"]
    ), row
    assert fingerprint(OWN.parents[1] / row["new"]) == dict(
        sha256=row["after_sha256"], bytes=row["after_bytes"], mode=row["mode"]
    ), row
for name, sha in (
    ("rename.patch", "6b3a2ac67316c956bac3387228c4b443807308526f809d1e703939e18b842180"),
    (
        "common-caller-proposal.patch",
        "bba7b04b0327088fb538b7aa117e3a44dc67782c4f20fb306ca4423e249048f9",
    ),
):
    assert fingerprint(OWN / name)["sha256"] == sha
    run(["git", "apply", "--check", str(OWN / name)])
for name in ("rename.patch", "common-caller-proposal.patch"):
    run(["git", "apply", str(OWN / name)])
for row in manifest["files"]:
    assert fingerprint(ROOT / row["new"]) == dict(
        sha256=row["after_sha256"], bytes=row["after_bytes"], mode=row["mode"]
    ), row
    if row["old"] != row["new"]:
        assert not (ROOT / row["old"]).exists()
readme = ROOT / "README.md"
text = readme.read_text()
text = text.replace(
    "| `tests/`                                                                                   | 製品のrender/audio/e2e検証・fixture",
    "| `games/quoridor/tests/`, `games/quoridor/docs/` | Quoridor固有のテスト・[製品仕様](games/quoridor/docs/quoridor-3d-webapp-design-rust-wasm-v1.md) |\n| `tests/` | 共通Web検証・既存fixture",
)
readme.write_text(text)
design = ROOT / "docs/design/multi-game-repository.md"
text = (
    design.read_text()
    .replace(
        "QuoridorのRust／bridge・Python・presetは",
        "QuoridorのRust／bridge・Python・preset・ゲーム固有テスト・製品文書は",
    )
    .replace(
        "残るゲーム固有テスト・文書の配置とOthello機能は後続工程で段階適用する",
        "Othello機能は後続工程で段階適用する",
    )
)
design.write_text(text)
check = (
    (OWN / "verify-callers.mjs")
    .read_text()
    .replace(
        "const own = resolve(root, '.artifacts/quoridor-test-doc129');",
        "const own = " + json.dumps(str(OUT)) + ";",
    )
    .replace(
        "readFileSync(resolve(own, 'proposal', path), 'utf8')",
        "readFileSync(resolve(root, path), 'utf8')",
    )
    .replace(
        "readFileSync(resolve(own, 'proposal/package.json'), 'utf8')",
        "readFileSync(resolve(root, 'package.json'), 'utf8')",
    )
)
(OUT / "verify-callers.mjs").write_text(check)
shutil.copyfile(OWN / "manifest.json", OUT / "manifest.json")
(OUT / "applied.json").write_text(
    json.dumps(
        dict(
            files=manifest["files"],
            common_paths=list(common),
            root_additional=["README.md"],
            baseline="3fc13bed28d40979b8e0fad3fb0936fc73710363",
            tests_replayed=False,
        ),
        indent=2,
    )
    + "\n"
)
print(
    "APPLIED exact43 source rows/42 relocations +8 common callers and Root readme/current-state text"
)
