import assert from 'node:assert/strict';
import { readFileSync, globSync } from 'node:fs';
import { createRequire, stripTypeScriptTypes } from 'node:module';
import { dirname, resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { defineConfig } from '@playwright/test';

const root = process.env.QUORIDOR_CODE_ROOT;
const own = "/workspaces/quoridor/.artifacts/research-team/integration324/multi-game-migration-v1/test-doc-adoption-v2";
const require = createRequire(import.meta.url);
const { createFileMatcher } = require(
  resolve(dirname(require.resolve('playwright')), 'lib/util.js'),
);
async function config(path, imports) {
  const url = pathToFileURL(resolve(root, path));
  const source = readFileSync(resolve(root, path), 'utf8');
  const context = vm.createContext({
    URL,
    process: { env: { E2E_BASE_URL: 'http://127.0.0.1:1/', N3L_RAW_DIR: own } },
  });
  const module = new vm.SourceTextModule(stripTypeScriptTypes(source, { mode: 'transform' }), {
    context,
    identifier: url.href,
    initializeImportMeta: (meta) => {
      meta.url = url.href;
    },
  });
  await module.link((name) => {
    assert.ok(Object.hasOwn(imports, name), name);
    const port = imports[name];
    return new vm.SyntheticModule(
      Object.keys(port),
      function () {
        for (const [key, value] of Object.entries(port)) this.setExport(key, value);
      },
      { context },
    );
  });
  await module.evaluate();
  return module.namespace.default;
}
const base = await config('playwright.config.ts', {
  '@playwright/test': { defineConfig },
  'node:url': { fileURLToPath },
});
const manifest = JSON.parse(readFileSync(resolve(own, 'manifest.json'), 'utf8'));
const e2e = manifest.files.filter((row) => row.new.endsWith('.spec.ts')).map((row) => row.new);
e2e.push('tests/e2e/web-shell.spec.ts');
const matcher = createFileMatcher(base.testMatch);
assert.equal(base.testDir, root + '/');
assert.ok(e2e.every((path) => matcher(resolve(root, path))));
assert.equal(e2e.length, 15);
assert.ok(!matcher(resolve(root, 'games/quoridor/tests/product/product-bfcache-worker.spec.mjs')));
const product = await config('tests/product/playwright.config.mjs', {
  '@playwright/test': { defineConfig },
  '../../playwright.config.ts': { default: base },
});
const productDir = resolve(root, 'tests/product', product.testDir);
assert.equal(productDir, resolve(root, 'games/quoridor/tests/product'));
const productPath = resolve(productDir, 'product-bfcache-worker.spec.mjs');
assert.ok(createFileMatcher(product.testMatch)(productPath));
const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));
const nodeFiles = {};
for (const name of ['unit', 'audio', 'render']) {
  const globs = pkg.scripts['test:' + name].split('--test ')[1].split(' && ')[0].split(' ');
  nodeFiles[name] = globs.flatMap((pattern) => [...globSync(pattern, { cwd: root })]);
  assert.equal(nodeFiles[name].length, name === 'unit' ? 5 : 1);
}
console.log(
  JSON.stringify(
    {
      status: 'PASS',
      defaultE2EFiles: e2e,
      productFile: productPath,
      preservedProductCLI: 'tests/product/playwright.config.mjs',
      nodeFiles,
      mode: 'configuration and finite file metadata only; no test imports, fixture reads, or browser',
    },
    null,
    2,
  ),
);
