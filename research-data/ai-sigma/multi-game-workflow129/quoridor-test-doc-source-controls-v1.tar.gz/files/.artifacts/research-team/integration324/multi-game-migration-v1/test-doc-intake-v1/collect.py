"""Read the fixed handoffs and current integration boundary."""

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent


def run(name, args):
    result = subprocess.run(args, capture_output=True, text=True, check=False)
    (OUT / (name + ".stdout")).write_text(result.stdout)
    (OUT / (name + ".stderr")).write_text(result.stderr)
    assert result.returncode == 0, (name, result.returncode, result.stderr[-1000:])
    return result.stdout


run("ready", ["bash", "scripts/dev/beads.sh", "ready", "--json"])
for leaf in ("", ".5", ".6"):
    data = json.loads(
        run(
            "show" + (leaf or "parent"),
            ["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.324.12.9" + leaf, "--json"],
        )
    )
    print(
        json.dumps([{k: row.get(k) for k in ("id", "status", "assignee", "title")} for row in data])
    )
print(run("head", ["git", "rev-parse", "HEAD"]).strip())
print(run("status", ["git", "status", "--porcelain=v1"]))
for task, sub in (
    ("quoridor-tests-docs129", "quoridor-test-doc129"),
    ("othello-rules129", "othello-rules129"),
):
    own = ROOT / ".worktree" / task / ".artifacts" / sub
    print(task, sorted(p.name for p in own.iterdir() if p.is_file()))
    for name in (
        "manifest.json",
        "common-before.json",
        "source-manifest.json",
        "common-caller-references.json",
        "common-caller-proposal.patch",
        "rename.patch",
    ):
        p = own / name
        if p.exists():
            raw = p.read_bytes()
            (OUT / (task + "-" + name)).write_bytes(raw)
            print(name, len(raw), oct(p.stat().st_mode & 0o777), hashlib.sha256(raw).hexdigest())
