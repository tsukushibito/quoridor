"""Check integrated maintained test discovery and document references only."""

import json
from pathlib import Path
import re
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
ADOPT = OUT.with_name("test-doc-adoption-v2")
commands = []


def run(name, argv):
    result = subprocess.run(argv, capture_output=True, text=True, check=False)
    (OUT / (name + ".log")).write_text(result.stdout + result.stderr)
    commands.append(dict(name=name, argv=argv, code=result.returncode))
    (OUT / "commands.json").write_text(json.dumps(commands, indent=2) + "\n")
    assert result.returncode == 0, (name, result.stderr[-1000:])


common = [
    "package.json",
    "playwright.config.ts",
    "tests/product/playwright.config.mjs",
    "AGENTS.md",
    "docs/README.md",
    "docs/design/multi-game-repository.md",
    "docs/design/ai-sigma-research-goal.md",
    "README.md",
]
prettier = [
    str(ROOT / "tools/research-quality/node_modules/.bin/prettier"),
    "--config",
    "tools/research-quality/.prettierrc.json",
]
run("prettier-write", prettier + ["--write"] + common + [str(ADOPT / "verify-callers.mjs")])
run("prettier-check", prettier + ["--check"] + common + [str(ADOPT / "verify-callers.mjs")])
run(
    "ruff-format",
    [
        "bash",
        "scripts/dev/project-env.sh",
        "ruff",
        "format",
        "--check",
        "--config",
        "tools/research-quality/ruff.toml",
        "scripts/dev/check-research.py",
    ],
)
run(
    "ruff-check",
    [
        "bash",
        "scripts/dev/project-env.sh",
        "ruff",
        "check",
        "--no-cache",
        "--config",
        "tools/research-quality/ruff.toml",
        "scripts/dev/check-research.py",
    ],
)
run(
    "actual-main-discovery",
    ["node", "--experimental-vm-modules", str(ADOPT / "verify-callers.mjs")],
)
links = []
paths = [
    "games/quoridor/docs/quoridor-3d-webapp-design-rust-wasm-v1.md",
    "games/quoridor/crates/quoridor-wasm/README.md",
    "AGENTS.md",
    "docs/README.md",
    "docs/design/multi-game-repository.md",
    "docs/design/ai-sigma-research-goal.md",
    "README.md",
]
for path in paths:
    for target in re.findall(r"\]\(([^)]+)\)", (ROOT / path).read_text()):
        if "quoridor-3d-webapp-design-rust-wasm-v1.md" not in target and path != paths[0]:
            continue
        if "://" in target or target.startswith("#"):
            continue
        resolved = (ROOT / path).parent / target.split("#")[0]
        assert resolved.exists(), (path, target)
        links.append(dict(source=path, target=target))
(OUT / "changed-links.json").write_text(json.dumps(links, indent=2) + "\n")
run("diff-check", ["git", "diff", "--check"])
print(
    json.dumps(
        dict(
            status="PASS",
            command_count=len(commands),
            checked_links=len(links),
            scientific_tests=0,
            browser=0,
            reused_worker_functional_cases=15,
        )
    )
)
