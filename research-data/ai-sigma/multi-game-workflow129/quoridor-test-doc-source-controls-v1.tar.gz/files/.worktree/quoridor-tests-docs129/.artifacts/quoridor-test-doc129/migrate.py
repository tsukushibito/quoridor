"""Finite path relocation; originals are retained only as task evidence."""

import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile

ROOT = Path(os.environ["QUORIDOR_CODE_ROOT"])
OWN = ROOT / ".artifacts/quoridor-test-doc129"
moves = {}
for path in sorted((ROOT / "python/tests").glob("*.py")):
    moves[str(path.relative_to(ROOT))] = "games/quoridor/tests/python/" + path.name
for folder in ("unit", "audio", "render", "e2e"):
    for path in sorted((ROOT / "tests" / folder).iterdir()):
        if path.name in {"ts-fixture.mjs", "web-navigation.test.mjs", "web-shell.spec.ts"}:
            continue
        moves[str(path.relative_to(ROOT))] = f"games/quoridor/tests/{folder}/{path.name}"
for name in ("quoridor-3d-webapp-design-rust-wasm-v1.md", "quoridor-hud-overlay-reference.png"):
    moves[f"docs/design/{name}"] = f"games/quoridor/docs/{name}"
readme = "games/quoridor/crates/quoridor-wasm/README.md"
paths = list(moves) + [readme]
manifest = {
    "git_restore_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "integration_source": "2dfe353c",
    "retained": {
        "tests/unit/ts-fixture.mjs": "Generic explicit-port TS loader; used by web-navigation and game tests",
        "tests/unit/web-navigation.test.mjs": "Common home/hash navigation and cancelled game loading",
        "tests/e2e/web-shell.spec.ts": "Common home/game teardown/lazy shell and base-path navigation",
        "tests/fixtures": "Protected existing test inputs; not read or moved",
        "tests/product": "Not among assigned finite directories; Quoridor bfcache product case reported to Root",
    },
    "files": [],
}
with tarfile.open(OWN / "originals.tar", "x") as archive:
    for old in paths:
        source = ROOT / old
        data = source.read_bytes()
        archive.add(source, arcname=old, recursive=False)
        manifest["files"].append(
            {
                "old": old,
                "new": moves.get(old, old),
                "before_sha256": hashlib.sha256(data).hexdigest(),
                "before_bytes": len(data),
                "mode": f"{stat.S_IMODE(source.stat().st_mode):04o}",
            }
        )
for old, new in moves.items():
    source, target = ROOT / old, ROOT / new
    assert not target.exists(), new
    target.parent.mkdir(parents=True, exist_ok=True)
    source.rename(target)
    if target.suffix in {".mjs", ".ts"}:
        text = target.read_text()
        text = text.replace("../../apps/", "../../../../apps/")
        text = text.replace("../../games/quoridor/bridge/", "../../bridge/")
        text = text.replace("'./ts-fixture.mjs'", "'../../../../tests/unit/ts-fixture.mjs'")
        target.write_text(text)
    elif target.suffix == ".py":
        text = target.read_text().replace("parents[2]", "parents[4]")
        text = text.replace("parents[3]", "parents[5]")
        target.write_text(text)
    elif target.suffix == ".md":
        text = target.read_text().replace("../reports/", "../../../docs/reports/")
        text = text.replace(
            "docs/design/quoridor-3d-webapp-design-rust-wasm-v1.md",
            "games/quoridor/docs/quoridor-3d-webapp-design-rust-wasm-v1.md",
        )
        target.write_text(text)
path = ROOT / readme
path.write_text(path.read_text().replace("../../../../docs/design/", "../../docs/"))
(OWN / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"moved": len(moves), "retained": manifest["retained"]}, ensure_ascii=False))
