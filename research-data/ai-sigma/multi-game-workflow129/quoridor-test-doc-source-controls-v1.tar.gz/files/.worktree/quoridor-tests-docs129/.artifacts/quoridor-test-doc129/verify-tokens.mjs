import { readFileSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import assert from 'node:assert/strict';
import { parsers } from '/workspaces/quoridor/tools/research-quality/node_modules/prettier/plugins/typescript.mjs';

const rows = JSON.parse(readFileSync(0, 'utf8'));
const root = process.env.QUORIDOR_CODE_ROOT;
const details = [];
function normalize(value, inverse) {
  if (Array.isArray(value)) return value.map((item) => normalize(item, inverse));
  if (value && typeof value === 'object')
    return Object.fromEntries(
      Object.entries(value)
        .filter(
          ([key]) =>
            !['loc', 'range', 'start', 'end', 'raw', 'comments', 'tokens', 'extra'].includes(key),
        )
        .map(([key, item]) => [key, normalize(item, inverse)]),
    );
  if (typeof value === 'string' && inverse)
    return value
      .replaceAll('../../../../apps/', '../../apps/')
      .replaceAll('../../bridge/', '../../games/quoridor/bridge/')
      .replaceAll('../../../../tests/unit/ts-fixture.mjs', './ts-fixture.mjs');
  return value;
}
for (const row of rows) {
  const text = readFileSync(resolve(root, row.new), 'utf8');
  const source = parsers.typescript.parse(text);
  assert.deepEqual(
    normalize(source, true),
    normalize(parsers.typescript.parse(row.original), false),
    row.new,
  );
  let tests = 0,
    checks = 0;
  function visit(node, parent = {}) {
    if (!node || typeof node !== 'object') return;
    if (node.type === 'CallExpression') {
      const name = text.slice(...node.callee.range);
      if (name === 'test' || name.startsWith('test.')) tests++;
      if (name === 'expect' || name.startsWith('assert.')) checks++;
    }
    if (node.type === 'Literal' && typeof node.value === 'string' && node.value.startsWith('.')) {
      const value = node.value;
      const isImport = parent.type === 'ImportDeclaration';
      const isURL = parent.type === 'NewExpression' && parent.callee.name === 'URL';
      if (isImport || isURL) {
        const target = resolve(root, dirname(row.new), value);
        assert.ok(
          [target, target + '.ts', target + '.mjs'].some(existsSync),
          `${row.new}: ${value}`,
        );
        assert.ok(target.startsWith(root + '/'), target);
      }
    }
    for (const value of Object.values(node)) {
      if (Array.isArray(value)) value.forEach((child) => visit(child, node));
      else if (value && typeof value === 'object') visit(value, node);
    }
  }
  visit(source);
  details.push({ path: row.new, tests, checks });
}
console.log(JSON.stringify({ fullASTAndParserAndPaths: 'PASS', files: details }, null, 2));
