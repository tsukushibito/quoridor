"""Preservation and path checks only; never import the scientific test suites."""

import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile

ROOT = Path(os.environ["QUORIDOR_CODE_ROOT"])
OWN = ROOT / ".artifacts/quoridor-test-doc129"
manifest = json.loads((OWN / "manifest.json").read_text())
js, python, docs, sparse_links = [], [], [], []
with tarfile.open(OWN / "originals.tar") as archive:
    for row in manifest["files"]:
        path = ROOT / row["new"]
        original = archive.extractfile(row["old"]).read()
        data = path.read_bytes()
        assert hashlib.sha256(original).hexdigest() == row["before_sha256"]
        assert stat.S_IMODE(path.stat().st_mode) == int(row["mode"], 8)
        if row["old"] != row["new"]:
            assert not (ROOT / row["old"]).exists(), row["old"]
        if path.suffix == ".py":
            tree = ast.parse(data)
            normalized = data.decode().replace("parents[4]", "parents[2]")
            normalized = normalized.replace("parents[5]", "parents[3]")
            assert ast.dump(ast.parse(normalized)) == ast.dump(ast.parse(original)), path
            names = [
                n.name
                for n in ast.walk(tree)
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
                and n.name.startswith("test_")
            ]
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name.startswith("test_"):
                            assert (path.parent / (alias.name + ".py")).is_file()
                if isinstance(node, ast.ImportFrom) and (node.module or "").startswith("test_"):
                    assert (path.parent / (node.module + ".py")).is_file()
            python.append({"path": row["new"], "tests": names})
        elif path.suffix in {".mjs", ".ts"}:
            js.append({**row, "original": original.decode()})
        elif path.suffix == ".md":
            expected = original.decode()
            if row["old"].startswith("docs/design/"):
                expected = expected.replace("../reports/", "../../../docs/reports/")
                expected = expected.replace(
                    "docs/design/quoridor-3d-webapp-design-rust-wasm-v1.md",
                    "games/quoridor/docs/quoridor-3d-webapp-design-rust-wasm-v1.md",
                )
            else:
                expected = expected.replace("../../../../docs/design/", "../../docs/")
            assert expected == data.decode(), row["new"]
            for link in re.findall(r"\]\(([^)]+)\)", data.decode()):
                if "://" not in link and not link.startswith("#"):
                    target = (path.parent / link.split("#")[0]).resolve()
                    if not target.exists():
                        relative = str(target.relative_to(ROOT))
                        subprocess.run(["git", "cat-file", "-e", f"HEAD:{relative}"], check=True)
                        sparse_links.append(relative)
            docs.append(row["new"])
        else:
            assert data == original, row["new"]
        row.update(after_sha256=hashlib.sha256(data).hexdigest(), after_bytes=len(data))
result = subprocess.run(
    ["node", str(OWN / "verify-tokens.mjs")],
    input=json.dumps(js),
    text=True,
    capture_output=True,
)
if result.returncode:
    print(result.stderr, flush=True)
result.check_returncode()
print(result.stdout)
before = json.loads((OWN / "common-before.json").read_text())
patch = ""
for path, info in before.items():
    data = (ROOT / path).read_bytes()
    assert hashlib.sha256(data).hexdigest() == info["sha256"], path
    assert stat.S_IMODE((ROOT / path).stat().st_mode) == int(info["mode"], 8)
    proposed = (OWN / "proposal" / path).read_text()
    if path.endswith(".py"):
        ast.parse(proposed)
    patch += "".join(
        difflib.unified_diff(
            data.decode().splitlines(keepends=True),
            proposed.splitlines(keepends=True),
            fromfile="a/" + path,
            tofile="b/" + path,
        )
    )
(OWN / "common-caller-proposal.patch").write_text(patch)
(OWN / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
report = {
    "python_AST_and_local_imports": "PASS",
    "python_files": python,
    "python_test_count": sum(len(row["tests"]) for row in python),
    "js": json.loads(result.stdout),
    "docs_links_and_content": docs,
    "common_files_unchanged": list(before),
    "links_existing_in_Git_but_sparse_missing": sparse_links,
}
(OWN / "preservation.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"python_files": len(python), "python_tests": report["python_test_count"]}))
