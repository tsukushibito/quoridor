"""Freeze exact source handoff without staging, committing, or common writes."""

import difflib
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile

ROOT = Path(os.environ["QUORIDOR_CODE_ROOT"])
OWN = ROOT / ".artifacts/quoridor-test-doc129"
manifest = json.loads((OWN / "manifest.json").read_text())
row = manifest["files"][-1]
with tarfile.open(OWN / "extra-product-original.tar") as archive:
    original = archive.extractfile(row["old"]).read()
assert (ROOT / row["new"]).read_bytes() == original
result = subprocess.run(
    ["node", str(OWN / "verify-tokens.mjs")],
    input=json.dumps([{**row, "original": original.decode()}]),
    text=True,
    check=True,
    capture_output=True,
)
(OWN / "extra-product-preservation.json").write_text(result.stdout)
patch = ""
for path, info in json.loads((OWN / "common-before.json").read_text()).items():
    data = (ROOT / path).read_bytes()
    assert hashlib.sha256(data).hexdigest() == info["sha256"], path
    assert stat.S_IMODE((ROOT / path).stat().st_mode) == int(info["mode"], 8)
    patch += "".join(
        difflib.unified_diff(
            data.decode().splitlines(keepends=True),
            (OWN / "proposal" / path).read_text().splitlines(keepends=True),
            fromfile="a/" + path,
            tofile="b/" + path,
        )
    )
(OWN / "common-caller-proposal.patch").write_text(patch)
patch = ""
with (
    tarfile.open(OWN / "originals.tar") as archive,
    tarfile.open(OWN / "extra-product-original.tar") as extra,
):
    for row in manifest["files"]:
        old, new = row["old"], row["new"]
        data = (ROOT / new).read_bytes()
        assert stat.S_IMODE((ROOT / new).stat().st_mode) == int(row["mode"], 8)
        source = extra if old.startswith("tests/product/") else archive
        original = source.extractfile(old).read()
        assert hashlib.sha256(original).hexdigest() == row["before_sha256"]
        row.update(after_sha256=hashlib.sha256(data).hexdigest(), after_bytes=len(data))
        patch += f"diff --git a/{old} b/{new}\n"
        if old != new:
            assert not (ROOT / old).exists(), old
            if original == data:
                patch += "similarity index 100%\n"
            patch += f"rename from {old}\nrename to {new}\n"
        if original != data:
            patch += "".join(
                difflib.unified_diff(
                    original.decode().splitlines(keepends=True),
                    data.decode().splitlines(keepends=True),
                    fromfile="a/" + old,
                    tofile="b/" + new,
                )
            )
(OWN / "rename.patch").write_text(patch)
(OWN / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"source_files": len(manifest["files"]), "relocations": 42}))
