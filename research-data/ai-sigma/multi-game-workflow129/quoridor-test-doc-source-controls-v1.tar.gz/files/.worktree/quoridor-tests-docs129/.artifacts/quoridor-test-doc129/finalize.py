"""Record the bounded handoff and one affected-storage observation."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

from quoridor_runtime.cycle_process import alive, directory_bytes

ROOT = Path(os.environ["QUORIDOR_CODE_ROOT"])
OWN = ROOT / ".artifacts/quoridor-test-doc129"
manifest = json.loads((OWN / "manifest.json").read_text())
allowed = {row[key] for row in manifest["files"] for key in ("old", "new")}
status = subprocess.check_output(
    ["git", "-c", "core.quotePath=false", "status", "--porcelain=v1", "--untracked-files=all"],
    text=True,
)
for line in status.splitlines():
    assert line[3:] in allowed, line
(OWN / "source-status.txt").write_text(status)
processes = {}
for path in sorted(OWN.glob("*.process.json")):
    if path.name == "finalize.process.json":
        continue
    row = json.loads(path.read_text())
    assert row.get("remaining") == [], path
    assert row.get("direct_child_reaped") is True, path
    assert row.get("process_cleanup_complete") is True, path
    assert row.get("handle_closes_complete") is True, path
    assert row.get("finalization_errors") == [], path
    assert not alive(row["child"]), path
    processes[path.name] = {
        key: row.get(key)
        for key in (
            "status",
            "exit_code",
            "remaining",
            "direct_child_reaped",
            "process_cleanup_complete",
            "handle_closes_complete",
            "signal_mask_restoration",
        )
    }
assert not list(OWN.glob("tmp-*")) or all(
    path.name == Path(os.environ["TMPDIR"]).name for path in OWN.glob("tmp-*")
)
evidence = [
    "originals.tar",
    "extra-product-original.tar",
    "manifest41.json",
    "manifest.json",
    "rename.patch",
    "common-caller-proposal.patch",
    "common-before.json",
    "preservation.json",
    "extra-product-preservation.json",
    "functional.log",
    "typecheck.log",
    "caller-metadata.log",
    "format-check.log",
    "patch-check.log",
    "source-status.txt",
]
hashes = {}
for name in evidence:
    path = OWN / name
    data = path.read_bytes()
    hashes[name] = {
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }
source_B = sum((ROOT / row["new"]).stat().st_blocks * 512 for row in manifest["files"])
storage = {
    "observed_UTC": datetime.now(timezone.utc).isoformat(),
    "affected_current_source_allocated_B": source_B,
    "OWN_allocated_B": directory_bytes(OWN),
    "method": "single affected-files/OWN allocated-block snapshot; no shared asset/RAW scan",
    "shared_global_cap_B": 50_000_000_000,
}
handoff = {
    "issue": "quoridor-4lc.324.12.9.5",
    "parent_issue": "quoridor-4lc.324.12.9",
    "cwd": str(ROOT),
    "source_STOP_UTC": datetime.now(timezone.utc).isoformat(),
    "git_restore_commit": manifest["git_restore_commit"],
    "source_files": len(manifest["files"]),
    "relocations": 42,
    "retained": manifest["retained"],
    "PASS": {
        "original_41_moves": "full Python/JS/TS AST and parser/path/link checks; preserved64 Python methods",
        "extra_product": "byte-identical13166B/0644 and full AST; 48 assertion callsites",
        "functional": "15 source-bound match-controller/Worker cases; reused for extra product",
        "typecheck": "WT bridge and Web tsc PASS; reused for extra product",
        "callers": "actual Playwright matcher, proposed config evaluation, finite E2E15/product1/unit5/audio1/render1 paths; no test imports",
        "formatting": "Ruff100 format/check+lint, existing Prettier write/check on changed code/proposed configs",
        "patches": "common patch git apply --check; rename patch git apply --check --reverse; git diff --check",
        "common_ownership": "all8 common files byte/mode unchanged; one proposal patch only",
        "bound_environment": "project3.14.7 imports exact WT games/quoridor/python+shared/python; no Main bridge/UI fallback",
    },
    "UNRUN": [
        "all scientific/model/training/numeric/simulation suites",
        "renderer/browser suites and product runtime replay",
        "Rust/Cargo/builds/installs",
        "Root common patch application and integration acceptance",
    ],
    "initial_failures_preserved": {
        "bootstrap": "python executable absent; used OS python3 only to verify saved context and plan",
        "preservation.log": "sparse report file existence check failed; HEAD metadata confirms all4 target paths",
        "preservation2.log": "validator TypeScript API unavailable; no scientific tests imported",
        "preservation3.log": "diagnosed version-only TypeScript API; switched validator to existing Prettier TS parser",
        "preservation4.log": "PASS after validator correction; product source assertions unchanged",
        "product_test_failures": "none in executed15 cases; unexecuted suites have no new pass claim",
    },
    "startup_order_deviation": "runtime SKILL.md was read before actual saved turn_context verification; reported in first-read; no product writes before verification",
    "session": {
        "thread": "01a15f01-fe83-7c11-8a55-35cd2764abd8",
        "model": "gpt-6.1-sol",
        "effort": "high",
        "sandbox": "danger-full-access",
        "approval_policy": "never",
        "plan_sha256": "90446edc2d1303686c214d4aa4e54dffc3696fa5f9debeda12c639bb29298548",
        "plan_bytes": 493,
        "plan_mode": "0644",
        "controller_CPU": 18,
        "child_CPU": 2,
        "family_B": 2147483648,
        "controller_B": 67108864,
        "child_max_B": 2080374784,
        "hostreserve_B": 4294967296,
        "GPU": 0,
        "threads": 1,
        "controls": "unchanged CPUPlan.from_record/CycleResources/execute, 300s per-command safety bound, OWN CANCEL/TMP, lifecycle shared lease, direct reap and handle cleanup",
    },
    "scope_protection": "all pauses323/342.17/sealed/newE/oldfits96/model/default/RAWFAILEDNULLUNKNOWN retained; no input reads/moves, Main/Git/index/commit/push/Cargo/common source writes0",
    "sparse_report_links": [
        "docs/reports/tabletop-rendering.md",
        "docs/reports/environment-presets.md",
        "docs/reports/quoridor-ui-ux-research.md",
        "docs/reports/ui-ux-improvement.md",
    ],
    "sparse_handling": "existing HEAD targets confirmed without reading Main content; relative product links rebased; no materialization needed",
    "processes": processes,
    "storage": storage,
    "artifacts": hashes,
    "next_owner_action": "Root accept/apply common proposal and integrate rename patch; no worker selfclose or ACK gate",
}
(OWN / "handoff.json").write_text(json.dumps(handoff, indent=2, ensure_ascii=False) + "\n")
for name in evidence:
    (OWN / name).chmod(0o444)
print(
    json.dumps(
        {
            "source_STOP": handoff["source_STOP_UTC"],
            "storage": storage,
            "patches": {
                name: hashes[name]
                for name in ("rename.patch", "common-caller-proposal.patch", "manifest.json")
            },
        },
        indent=2,
    )
)
