"""Prepare exact common-caller changes without writing shared source."""

import difflib
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(os.environ["QUORIDOR_CODE_ROOT"])
OWN = ROOT / ".artifacts/quoridor-test-doc129"
changes = {}


def replace(path, old, new):
    text = changes.get(path, (ROOT / path).read_text())
    assert old in text, (path, old)
    changes[path] = text.replace(old, new)


replace("package.json", "--test tests/render/", "--test games/quoridor/tests/render/")
replace("package.json", "--test tests/audio/", "--test games/quoridor/tests/audio/")
replace(
    "package.json",
    "--test tests/unit/*.test.mjs",
    "--test tests/unit/*.test.mjs games/quoridor/tests/unit/*.test.mjs",
)
replace("scripts/dev/check-research.py", '"python/tests', '"games/quoridor/tests/python')
replace(
    "playwright.config.ts",
    "import { defineConfig } from '@playwright/test';",
    "import { defineConfig } from '@playwright/test';\n"
    "import { fileURLToPath } from 'node:url';\n"
    "const checkout = fileURLToPath(new URL('.', import.meta.url));",
)
replace(
    "tests/product/playwright.config.mjs",
    "testDir: '.',",
    "testDir: '../../games/quoridor/tests/product',",
)
replace(
    "playwright.config.ts",
    "testDir: './tests/e2e',",
    "testDir: checkout,\n  testMatch: [\n"
    "    fileURLToPath(new URL('./tests/e2e/**/*.spec.ts', import.meta.url)),\n"
    "    fileURLToPath(new URL('./games/quoridor/tests/e2e/**/*.spec.ts', import.meta.url)),\n"
    "  ],",
)
replace(
    "AGENTS.md",
    "docs/design/quoridor-3d-webapp-design-rust-wasm-v1.md",
    "games/quoridor/docs/quoridor-3d-webapp-design-rust-wasm-v1.md",
)
replace(
    "docs/README.md",
    "(design/quoridor-3d-webapp-design-rust-wasm-v1.md)",
    "(../games/quoridor/docs/quoridor-3d-webapp-design-rust-wasm-v1.md)",
)
for path in ("docs/design/multi-game-repository.md", "docs/design/ai-sigma-research-goal.md"):
    replace(
        path,
        "(quoridor-3d-webapp-design-rust-wasm-v1.md)",
        "(../../games/quoridor/docs/quoridor-3d-webapp-design-rust-wasm-v1.md)",
    )
for path, text in changes.items():
    target = OWN / "proposal" / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
(OWN / "common-before.json").write_text(
    json.dumps(
        {
            path: {
                "sha256": hashlib.sha256((ROOT / path).read_bytes()).hexdigest(),
                "bytes": (ROOT / path).stat().st_size,
                "mode": f"{(ROOT / path).stat().st_mode & 0o777:04o}",
            }
            for path in changes
        },
        indent=2,
    )
    + "\n"
)


def freeze():
    patch = ""
    for path in changes:
        patch += "".join(
            difflib.unified_diff(
                (ROOT / path).read_text().splitlines(keepends=True),
                (OWN / "proposal" / path).read_text().splitlines(keepends=True),
                fromfile="a/" + path,
                tofile="b/" + path,
            )
        )
    (OWN / "common-caller-proposal.patch").write_text(patch)


freeze()
