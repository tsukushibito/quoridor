"""Root-authorized single additional current product test relocation."""

import hashlib
import json
import os
from pathlib import Path
import stat
import tarfile

ROOT = Path(os.environ["QUORIDOR_CODE_ROOT"])
OWN = ROOT / ".artifacts/quoridor-test-doc129"
old = "tests/product/product-bfcache-worker.spec.mjs"
new = "games/quoridor/tests/product/product-bfcache-worker.spec.mjs"
data = (ROOT / old).read_bytes()
with tarfile.open(OWN / "extra-product-original.tar", "x") as archive:
    archive.add(ROOT / old, arcname=old, recursive=False)
manifest = json.loads((OWN / "manifest.json").read_text())
(OWN / "manifest41.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
row = {
    "old": old,
    "new": new,
    "before_sha256": hashlib.sha256(data).hexdigest(),
    "before_bytes": len(data),
    "mode": f"{stat.S_IMODE((ROOT / old).stat().st_mode):04o}",
}
(ROOT / new).parent.mkdir(parents=True, exist_ok=True)
(ROOT / old).rename(ROOT / new)
manifest["files"].append(row)
manifest["retained"].pop("tests/product")
manifest["retained"]["tests/product/playwright.config.mjs"] = (
    "Root-owned maintained explicit current product CLI entry; path change proposed only"
)
(OWN / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(row))
