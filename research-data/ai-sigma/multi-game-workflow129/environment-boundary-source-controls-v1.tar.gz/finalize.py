"""Record scoped source, process cleanup, and owned storage evidence."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

from quoridor_training.cycle_process import alive, directory_bytes, process_info

root = Path.cwd()
out = root / ".artifacts/multi-game-env129"
paths = [
    "scripts/dev/project-env.sh",
    "scripts/dev/test_project_env.py",
    "docs/development/rust-python-environment.md",
    "docs/design/multi-game-repository.md",
]
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
diff = subprocess.check_output(["git", "diff", "--no-ext-diff", "--", *paths], env=env)
new_test = subprocess.run(
    ["git", "diff", "--no-index", "--", "/dev/null", paths[1]],
    env=env,
    capture_output=True,
    check=False,
)
assert new_test.returncode == 1
(out / "final-source.diff").write_bytes(diff + new_test.stdout)
sources = {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths}
processes = {}
ancestors = set()
current = process_info(os.getpid())
while current and current["pid"] not in ancestors:
    ancestors.add(current["pid"])
    current = process_info(current["parent"])
for path in sorted(out.glob("*.process.json")):
    record = json.loads(path.read_text())
    returned_path = path.with_name(path.name.replace(".process.json", ".returned.json"))
    returned = json.loads(returned_path.read_text()) if returned_path.exists() else None
    child = record.get("child")
    processes[path.name] = {
        "status": record["status"],
        "child": child,
        "child_alive_now": alive(child) if child else None,
        "remaining": record.get("remaining"),
        "cleanup_complete": record.get("cleanup_complete"),
        "returned_record_exists": returned is not None,
        "returned_signal_mask_restoration": returned.get("signal_mask_restoration")
        if returned
        else "NO_RETURNED_RECORD",
        "returned_handle_closes_complete": returned.get("handle_closes_complete")
        if returned
        else None,
    }
    if child and alive(child):
        assert child["pid"] in ancestors and record["status"] == "running"
        processes[path.name]["collection_ancestor_still_running"] = True
assert not list((root / "python").glob("_quoridor_env129_*.py"))
assert not list((root / "python").glob("_quoridor_project_env_*.py"))
assert not list(out.glob("**/tensorrt-path-*"))
cache = root / ".ruff_cache"
# This cache was created by this task's scoped Ruff commands at 12:15 UTC.
# No shared or pre-existing cache is removed.
cache_info = cache.stat()
assert cache_info.st_mtime >= 1792584900
cache_bytes = directory_bytes(cache)
shutil.rmtree(cache)
context_path = Path(
    "/home/vscode/.codex/sessions/2026/10/21/rollout-2026-10-21T12-08-22-01a15e5c-cbb4-7023-a4bb-97d7be461e8b.jsonl"
)
context = None
for line in context_path.open():
    item = json.loads(line)
    if item["type"] == "turn_context":
        payload = item["payload"]
        context = {
            key: payload[key]
            for key in ("cwd", "model", "effort", "approval_policy", "sandbox_policy")
        }
assert context == {
    "cwd": str(root),
    "model": "gpt-6.1-sol",
    "effort": "high",
    "approval_policy": "never",
    "sandbox_policy": {"type": "danger-full-access"},
}
report = {
    "context": context,
    "source_sha256": sources,
    "processes_before_final_collection": processes,
    "sentinel_and_tensorrt_tmp_cleanup": "COMPLETE",
    "ruff_task_cache_allocated_B_before_cleanup": cache_bytes,
    "ruff_task_cache_removed": not cache.exists(),
    "source_files_allocated_B": sum((root / path).stat().st_blocks * 512 for path in paths),
    "own_output_allocated_B_at_collection": directory_bytes(out),
    "storage_scope": "four changed source/docs files and own new output/cache only; no global walk",
    "initial_notification_failure": "retained unchanged; failed process receipt has no returned success record",
    "no_science_or_dependency_sync": True,
}
(out / "collection.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
