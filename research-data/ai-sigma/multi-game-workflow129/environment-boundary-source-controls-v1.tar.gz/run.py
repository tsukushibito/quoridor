"""Use the assigned CPU plan and existing bounded process execution."""

import hashlib
import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import CPUPlan, CycleResources, execute

root = Path(__file__).resolve().parents[2]
output = root / ".artifacts/multi-game-env129"
plan_file = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/multi-game-migration-v1/environment-v1/cpu-plan.json"
)
info = plan_file.stat()
raw = plan_file.read_bytes()
assert len(raw) == 494 and info.st_mode & 0o777 == 0o644
assert (
    hashlib.sha256(raw).hexdigest()
    == "7f6a5c0d0a01fbf83e19be805d10a5080750902b06b6097ad2a5c194b1b07b52"
)
record = json.loads(raw)
plan = CPUPlan.from_record(record["cpu_plan"])
plan.check_host(os.sched_getaffinity(0))
plan.apply()
assert (
    __import__("quoridor_training.cycle_process", fromlist=["process_info"]).process_info(
        os.getpid()
    )["rss"]
    <= record["controller_B"]
)
env = dict(os.environ)
env.update(
    {
        key: "1"
        for key in (
            "OMP_NUM_THREADS",
            "OPENBLAS_NUM_THREADS",
            "MKL_NUM_THREADS",
            "NUMEXPR_NUM_THREADS",
            "PYTHONDONTWRITEBYTECODE",
        )
    }
)
env["CUDA_VISIBLE_DEVICES"] = ""
deadline = time.monotonic() + 180
guard = CycleResources(
    {"max_memory_bytes": record["child_max_B"], "host_ram_reserve": record["hostreserve_B"]},
    output,
    deadline,
)
name, *command = sys.argv[1:]
try:
    result = execute(
        command,
        output / (name + ".log"),
        deadline,
        resources=guard,
        cwd=root,
        env=env,
        cpu_plan=plan,
        cpu_scope="implementation",
    )
    (output / (name + ".returned.json")).write_text(json.dumps(result, indent=2) + "\n")
finally:
    log = output / (name + ".log")
    if log.exists():
        print(log.read_text(), end="")
