quoridor-4lc.324.12.9.1 ready for Root technical acceptance. Source STOP.

Actual Worktree: /workspaces/quoridor/.worktree/worktree-code-env129; branch codex/worktree-code-env129; base 24a0b7c18dd3ecbf1e54bf8d43c1f30b4cf75e5d. No Main source/Git index/checkout/branch/commit/push/Cargo/manifest/lock mutation commands. Source paths frozen:
- scripts/dev/project-env.sh
- scripts/dev/test_project_env.py (new)
- docs/development/rust-python-environment.md
- docs/design/multi-game-repository.md

Design: entry script's actual Git checkout selects QUORIDOR_CODE_ROOT. Its python directory is required; PYTHONPATH replaces inherited Main paths. PYTHONSAFEPATH=1 prevents a caller cwd or script directory from introducing Main source. Main/common dependency metadata remains QUORIDOR_PROJECT_ROOT; setup-project.sh, verify-python-environment.py and research-lifecycle.py consumers were inspected and their canonical environment/asset semantics retained. Shared regular CPython3.14.7, offline/no-sync uv invocation, existing shared/exclusive setup lock, explicit environment/interpreter refusals, sourced tool-path behavior and explicit TensorRT ordering remain. No verifier edit was necessary.

Final meaningful verification (exact commands in final-checks-v1.returned.json):
- bash scripts/dev/project-env.sh ruff format --check --config tools/research-quality/ruff.toml scripts/dev/test_project_env.py .artifacts/multi-game-env129/run.py
- bash scripts/dev/project-env.sh ruff check --config tools/research-quality/ruff.toml scripts/dev/test_project_env.py .artifacts/multi-game-env129/run.py
- /workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier --config tools/research-quality/.prettierrc.json --check docs/development/rust-python-environment.md docs/design/multi-game-repository.md
- bash -n scripts/dev/project-env.sh
- GIT_OPTIONAL_LOCKS=0 git diff --check -- scripts/dev/project-env.sh docs/development/rust-python-environment.md docs/design/multi-game-repository.md
- QUORIDOR_PROJECT_ENV_TEST_OUTPUT="$PWD/.artifacts/multi-game-env129/project-env-test" bash scripts/dev/project-env.sh python -B -m unittest discover -s scripts/dev -p test_project_env.py -v
- bash scripts/dev/project-env.sh python -B scripts/dev/verify-python-environment.py --output .artifacts/multi-game-env129/environment.json
All PASS. Six final tests ran in 0.404s. Actual Worktree sentinel and package __file__ selected Worktree even from Main/python cwd with inherited Main PYTHONPATH. Main entry selected Main. A real Main snapshot.py import was established at Main/python/quoridor_training cwd; selecting the Worktree entry refused that missing top-level Worktree module with ModuleNotFoundError, without cwd fallback. Source preserves shell PYTHONPATH/PYTHONSAFEPATH and tool-path idempotence. Explicit foreign interpreter/environment and invalid TensorRT roots refused; valid explicit TensorRT/python prefix retained. Metadata-only verifier passed; explicit_imports remained empty. No science/native/build/model/game/train replay.

Root usability repair applied: only the Worktree sentinel case skips explicitly when ROOT==MAIN. Output directory is created in setUpClass for discovery. Permanent sentinel/output naming is project-env-test, with an override used to confine this run to owned output. Main execution of the new integrated script/test has NOT been claimed; Root can exercise Main after acceptance/integration. Current Main stayed untouched.

Formatting applied before checks: Ruff100 config to both authored Python helpers/test; installed scoped Prettier --write for the two Markdown files. shfmt is absent; Bash was manually aligned to existing two-space/quoted style, then bash -n and diff --check passed. No formatter installation. The task-created .ruff_cache (24,576 allocated bytes) was counted once and removed; subsequent helper formatting used --no-cache. No shared/pre-existing cache removed.

Evidence under .artifacts/multi-game-env129:
- final-source.diff and collection.json: frozen source hashes, saved actual turn_context, scoped storage and process observations.
- final-checks-v1.log / .returned.json: final six PASS plus quality/metadata checks; actual direct reap, no remaining descendants, closed handles and completed signal-mask restoration.
- focused-v1.log/.returned.json: original six actual Worktree PASS retained unchanged.
- STOP.json: post-return actual verification and collector child identities no longer alive. Sentinel/TensorRT TMP and task Ruff cache removed. No background jobs.
- collection-v2.returned.json: final collection completed and reaped (collection.json deliberately records its then-live collector ancestor honestly).
- actual-start.json, first-edit.diff and initial first-edit/start-notify failure receipts remain unchanged. First notification failed from an unnecessarily restrictive virtual-address-space limit (SIGTRAP); retry without that limit was actually accepted. Root has already delivered the single policy start notice; no further start notice.
- Drafting shell-quoting failure and collector self-observation assertion failure retained in their original logs/receipts, repaired without changing/overwriting earlier test successes. Failed process receipts have no fabricated returned-success records.

Resource execution used Root FileRef after verifying bytes494/mode0644/SHA2567f6a5c0d0a01fbf83e19be805d10a5080750902b06b6097ad2a5c194b1b07b52; CPUPlan.from_record unchanged; management18 / implementation16; existing CycleResources/execute. Controller RSS checked <=64MiB at launch; conservative <=960MiB whole family monitor leaves the 64MiB controller allowance within 1GiB, host reserve4GiB, CUDA_VISIBLE_DEVICES empty, library threads1, deadline180s per command. Existing execute owns cancellation/TERM/KILL/direct wait/reap/handle closure. No scheduler layer, recursive delegation or science worker.

One scoped storage collection: four changed source/docs files36,864 allocated bytes; own output204,800 allocated bytes at collection (before small collection/STOP/handoff receipts); task Ruff cache24,576 bytes then removed. No old/global traversal or research assets/payload reads.

Source writes and verification helpers STOP. This final handoff notification is transient; its actual returned receipt will be handoff-notify.returned.json. Root must check it before removal. Issue remains in_progress pending technical acceptance; worker does not self-close. Beads note and backup sync follow normally. Ready for same-session causal repairs if needed.
