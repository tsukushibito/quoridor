"""Collect the one original relocation build without replaying its commands."""

import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import stat

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def checked(witness):
    path = Path(witness["path"])
    assert ref(path) == witness
    return path


def main():
    spec = importlib.util.spec_from_file_location(
        "lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lc)
    runtime = BASE / "build-runtime-v1"
    outer_path = runtime / "result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((runtime / "state.json").read_bytes())
    assert outer["job_id"] == state["job_id"] == "20bcf9cd-31e5-4e65-9bd7-96a88342f6a8"
    assert outer["outcome"] == "succeeded" and outer["exit_code"] == 0
    assert outer["cleanup_complete"] and outer["direct_child_reaped"] and not outer["remaining"]
    assert (runtime / "output.log").read_bytes() == b""
    operation = BASE / "operation-release"
    candidate_path = operation / "candidate.json"
    before = ref(candidate_path)
    candidate = json.loads(candidate_path.read_bytes())
    assert candidate["status"] == "PENDING_FINALIZATION"
    assert candidate["primary"] is None and not candidate["secondary"]
    assert candidate["cleanup_complete"] and candidate["process_cleanup_complete"]
    assert candidate["remaining"] == candidate["owed_finalizers"] == []
    intent = json.loads(checked(candidate["intent"]).read_bytes())
    assert intent["source"]["commit"] == "ee35ac749040b57b5b64425889951575715377de"
    checks, known, roles = [], [], []
    for row in candidate["checks"]:
        assert row["status"] == "PASS" and row["capture_complete"]
        assert row["primary"] is None and row["secondary"] == []
        record = row["guardian_return"]
        lc.settled(record)
        assert record["handle_closes_complete"]
        checked(row["persisted_process_receipt"])
        child = record["child"]
        fresh = lc.process.identity(lc.process.process_info(child["pid"]))
        assert fresh != lc.process.identity(child)
        known.append(dict(expected=child, fresh=fresh))
        if row["role"] in {"lint", "build"}:
            report = lc.cargo_report(checked(row["full_log"]).read_bytes())
            assert report["warning_count"] == 0
            roles.append(row["role"])
            if row["role"] == "build":
                artifacts = [
                    a
                    for a in report["artifacts"]
                    if a["target"]["name"] == "quoridor-runner"
                    and a["target"]["kind"] == ["bin"]
                    and not a["profile"]["test"]
                ]
                assert artifacts == [candidate["cargo_artifact"]]
                assert not artifacts[0]["fresh"]
            checks.append(
                dict(
                    name=row["name"],
                    role=row["role"],
                    full_log=row["full_log"],
                    process=row["persisted_process_receipt"],
                    warnings=0,
                )
            )
        else:
            assert row["role"] == "version"
    assert roles == ["lint", "lint", "build"]
    for member in [
        state["child"],
        state["supervisor"],
        state["launch"]["owner"],
        state["launch"]["launcher"],
    ]:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != member
        known.append(dict(expected=member, fresh=fresh))
    assert not (operation / "manifest.json").exists()
    manifest = lc.finalize(operation, ref(outer_path))
    assert manifest["status"] == "PASS" and manifest["artifact"] == candidate["artifact"]
    assert ref(candidate_path) == before
    with lc.lease():
        lc.source_check(intent["source"])
        assert not Path(intent["TMP"]).exists()
    result = dict(
        status="PASS_RELOCATED_WORKSPACE_CLIPPY_AND_RETIRED33_GENUINE_RELEASE_SOURCE_STOP",
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        issue="quoridor-4lc.324.12.9",
        software_manifest=ref(operation / "manifest.json"),
        outer=ref(outer_path),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        checks=checks,
        artifact=manifest["artifact"],
        cargo_artifact=candidate["cargo_artifact"],
        prior_software_scope=json.loads(checked(intent["source_adoption"]).read_bytes())[
            "prior_software_scope"
        ],
        actual_new_test_bodies=0,
        Search=0,
        model_forward=0,
        games=0,
        qualification="Two separate all-target rules/ai Clippy variants and one genuine unmeasured baseline image. Product Wasm builds and optional nnue compile remain separate. No speed, strength or scientific admission.",
        known_exact_processes_absent_or_different=known,
        source_leases=[],
        TMP=[],
        remaining_owned=[],
        whole_build_and_normal_collection_source_STOP=True,
        host_future_quiet=False,
        current_retention_point=ref(operation / "storage-usage.json"),
        fees_globalactual_later_tails="UNKNOWN",
        no_refund_lending=True,
    )
    (OUT / "completion-and-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "outer_seconds_once": outer["wall_seconds"]}))


if __name__ == "__main__":
    main()
