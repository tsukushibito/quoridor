"""Bound one Root maintenance command with the existing process owner."""

import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import CPUPlan, CycleResources, available_cpus, execute

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
plan = CPUPlan([18], {"maintenance": [18]}, library_threads=1)
plan.check_host(available_cpus())
plan.apply()
temporary = OUT / "guard-TMP"
temporary.mkdir()
deadline = time.monotonic() + 300
resources = CycleResources(
    dict(max_memory_bytes=1024**3 - 64 * 1024**2, host_ram_reserve=4 * 1024**3), OUT, deadline
)
returned = None
failure = None
try:
    returned = execute(
        [sys.executable, "-B", str(OUT / "collect.py")],
        OUT / "execution.log",
        deadline,
        resources=resources,
        cpu_plan=plan,
        cpu_scope="maintenance",
        cwd=ROOT,
        env=dict(
            os.environ, TMPDIR=str(temporary), CUDA_VISIBLE_DEVICES="", PYTHONDONTWRITEBYTECODE="1"
        ),
    )
except BaseException as error:
    failure = dict(type=type(error).__name__, message=str(error))
finally:
    process = OUT / "execution.process.json"
    (OUT / "actual-returned-STOP.json").write_text(
        json.dumps(
            dict(
                returned=returned,
                disk=json.loads(process.read_bytes()) if process.exists() else None,
                failure=failure,
                TMP=[str(p) for p in temporary.rglob("*")],
                sourceleases=[],
                host_future_quiet=False,
                scientific_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
print(json.dumps(dict(failure=failure, exit_code=returned.get("exit_code") if returned else None)))
assert failure is None and returned["exit_code"] == 0 and returned["cleanup_complete"]
