"""Compose frozen relocation and purpose-ended33 removal, then stage immutable source."""

from datetime import datetime, timezone
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path("/workspaces/quoridor")
WT = ROOT / ".worktree/quoridor-rust-layout129"
OWN = WT / ".artifacts/quoridor-rust-layout129"
OUT = Path(__file__).resolve().parent
RETIRE = (
    ROOT
    / ".worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1/purpose-end-retirement-v1"
)


def run(args, label=None, checked=True):
    p = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, timeout=120)
    if label:
        (OUT / (label + ".stdout")).write_text(p.stdout)
        (OUT / (label + ".stderr")).write_text(p.stderr)
    if checked:
        assert p.returncode == 0, p.stdout + p.stderr
    return p


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not run(["git", "status", "--porcelain=v1"]).stdout
    stop = json.loads((OWN / "STOP.json").read_bytes())
    returned = json.loads((OWN / "final-source-STOP.return.json").read_bytes())
    assert stop["source_frozen_and_writer_STOP"] and not stop["owned_TMP_remaining"]
    assert returned["normal_return"] and returned["source_lease_returned"]
    assert not returned["record"]["remaining"] and returned["record"]["handle_closes_complete"]
    frozen = json.loads((OWN / "frozen-files.json").read_bytes())
    assert frozen["base_commit"] == "1ed501b771d5c59813a977463a947ba817b276f9"
    patches = [
        ("full.patch", "1b345a643d85ad6b7e9decd8dd7f572439e2a76c1b63f3123339f0476d105ef6", 7116087),
        (
            "common-caller-proposal.patch",
            "7559136981f3a51b13f5d4c8d30b89b6c8fbf6a826af75643b42501593d0ecfd",
            74222,
        ),
    ]
    allowed = set()
    for row in frozen["entries"]:
        assert digest(ROOT / row["old"]) == row["before"]["sha256"], row["old"]
        assert digest(WT / row["new"]) == row["after"]["sha256"], row["new"]
        allowed.update([row["old"], row["new"]])
    for row in frozen["common_proposal_files"]:
        assert digest(ROOT / row["path"]) == row["before_sha256"], row["path"]
        allowed.add(row["path"])
    for name, sha, size in patches:
        p = OWN / name
        assert p.stat().st_size == size and digest(p) == sha
        run(["git", "apply", "--check", str(p)])
    for name, _, _ in patches:
        run(["git", "apply", str(OWN / name)])
    for row in frozen["entries"]:
        assert digest(ROOT / row["new"]) == row["after"]["sha256"]
    for row in frozen["common_proposal_files"]:
        assert digest(ROOT / row["path"]) == row["after_sha256"]
    binding_path = RETIRE / "binding.json"
    assert (
        digest(binding_path) == "0e540a34f9e91f0b2c1ed89e4f81b0da1efb3db3e1c5f538e03fd4f157783ab9"
    )
    binding = json.loads(binding_path.read_bytes())
    composed = []
    for index, row in enumerate(binding["subjects"]):
        old = row["subject"]
        name = "games/quoridor/" + old if old.startswith("crates/") else old
        target = ROOT / name
        allowed.add(name)
        before = Path(row["before"]["path"])
        assert digest(before) == row["before"]["sha256"]
        if row["action"] == "delete_wholly33file":
            assert digest(target) == row["adopted"]["sha256"]
            target.unlink()
            composed.append(
                dict(original=old, current=name, action="delete", before=row["adopted"])
            )
            continue
        after = Path(row["post"]["path"])
        assert digest(after) == row["post"]["sha256"]
        current = OUT / (str(index) + "-layout-current")
        current.write_bytes(target.read_bytes())
        merged = run(
            ["git", "merge-file", "-p", str(current), str(before), str(after)],
            label="merge-" + str(index),
            checked=False,
        )
        assert merged.returncode == 0, (
            "Unresolved sparse composition: "
            + name
            + "; saved merge outputs; no whole-owner overwrite"
        )
        target.write_text(merged.stdout)
        composed.append(
            dict(
                original=old,
                current=name,
                action="three_way_merge",
                layout_current_sha256=digest(current),
                retirement_before=row["before"],
                retirement_post=row["post"],
                actual_sha256=digest(target),
            )
        )
    # Preserve exactly the existing generated product directory by rename; no rebuild/parity claim.
    old_wasm = ROOT / "packages/engine-bridge/wasm"
    new_wasm = ROOT / "games/quoridor/bridge/wasm"
    assert old_wasm.is_dir() and not old_wasm.is_symlink() and not new_wasm.exists()
    inode_before = (old_wasm.stat().st_dev, old_wasm.stat().st_ino)
    old_wasm.rename(new_wasm)
    assert inode_before == (new_wasm.stat().st_dev, new_wasm.stat().st_ino)
    old_bridge = ROOT / "packages/engine-bridge"
    assert not list(old_bridge.iterdir())
    old_bridge.rmdir()
    link = ROOT / "node_modules/@quoridor/engine-bridge"
    assert link.is_symlink()
    old_link = os.readlink(link)
    assert (link.parent / old_link).resolve() == old_bridge
    link.unlink()
    link.symlink_to("../../games/quoridor/bridge", target_is_directory=True)
    assert link.resolve() == ROOT / "games/quoridor/bridge"
    run(["node", "scripts/codegen-protocol.mjs", "--check"], "protocol")
    run(["node", "scripts/check-boundaries.mjs"], "boundaries")
    run(
        ["node", "node_modules/typescript/bin/tsc", "--noEmit", "-p", "apps/web/tsconfig.json"],
        "Main-app-typecheck",
    )
    run(
        [
            "node",
            "node_modules/typescript/bin/tsc",
            "--noEmit",
            "-p",
            "games/quoridor/bridge/tsconfig.json",
        ],
        "Main-bridge-typecheck",
    )
    run(
        [
            "node",
            "node_modules/typescript/bin/tsc",
            "--noEmit",
            "-p",
            "games/quoridor/bridge/tsconfig.worker.json",
        ],
        "Main-worker-typecheck",
    )
    ast.parse((ROOT / "scripts/dev/research-lifecycle.py").read_text())
    run(["git", "diff", "--check"])
    dirty = run(["git", "status", "--porcelain=v1", "--untracked-files=all"]).stdout
    paths = [line[3:] for line in dirty.splitlines()]
    assert set(paths) <= allowed, set(paths) - allowed
    composition = dict(
        at=datetime.now(timezone.utc).isoformat(),
        issue="quoridor-4lc.324.12.9.3",
        worker_frozen_ref=str(OWN / "frozen-files.json"),
        worker_patches=[dict(path=str(OWN / n), sha256=s, bytes=z) for n, s, z in patches],
        source_mapping=frozen["mapping"],
        retirement33_binding=dict(path=str(binding_path), sha256=digest(binding_path)),
        retirement33_composition=composed,
        generated_product_directory=dict(
            original=str(old_wasm),
            current=str(new_wasm),
            same_directory_inode=True,
            source_or_model_qualification=False,
        ),
        workspace_dependency_link=dict(old=old_link, current=os.readlink(link)),
        current_entrychecks=[
            "protocol --check",
            "feature boundary",
            "Main app/bridge/worker tsc",
            "LC AST",
            "diff --check",
        ],
        native_compile="UNRUN; next normal Build",
        source_only_accepted=True,
        software_or_practical_default_claim=False,
        scientific_calls=0,
        all_historical_RAW_fixtures_archives_pauses_seals_preserved=True,
    )
    (OUT / "composition.json").write_text(
        json.dumps(composition, ensure_ascii=False, indent=2) + "\n"
    )
    (OUT / "paths.json").write_text(json.dumps(paths, indent=2) + "\n")
    # A real immutable source commit avoids treating a multi-megabyte rename delta as a control packet.
    # Normal BUILD will qualify this commit; no source-check limit is relaxed and no push occurs yet.
    saved = json.loads(
        run(
            [
                sys.executable,
                "-B",
                "scripts/dev/research-save.py",
                "save",
                "--paths-file",
                str(OUT / "paths.json"),
                "--issue",
                "quoridor-4lc.324.12.9",
                "--actor",
                "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                "--message",
                "Relocate Quoridor Rust/Wasm sources and retire ended ETC diagnostics\n\nPreserve crate/package identities and frozen research evidence. Update maintained workspace/build/source callers and remove only ended ETC33 diagnostic fragments. Source boundary checks pass; affected native/Wasm compiler qualification follows under sole Root Cargo ownership.",
                "--writers-stopped",
            ]
        ).stdout
    )
    assert not run(["git", "status", "--porcelain=v1"]).stdout
    (OUT / "result.json").write_text(
        json.dumps(
            dict(
                local_source_commit=saved["commit"],
                pushed=False,
                Main_clean=True,
                native_software_qualification="PENDING",
            ),
            indent=2,
        )
        + "\n"
    )
    print(
        json.dumps(
            dict(local_source_commit=saved["commit"], pushed=False, software_qualified=False)
        )
    )


if __name__ == "__main__":
    main()
