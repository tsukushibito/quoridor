"""Check actual integrated current callers before starting compiler ownership."""

import ast
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def run(args, name):
    p = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, timeout=120)
    (OUT / (name + ".stdout")).write_text(p.stdout)
    (OUT / (name + ".stderr")).write_text(p.stderr)
    assert p.returncode == 0, p.stdout + p.stderr


def main():
    frozen = json.loads(
        (
            ROOT
            / ".worktree/quoridor-rust-layout129/.artifacts/quoridor-rust-layout129/frozen-files.json"
        ).read_bytes()
    )
    rust = {
        row["new"]
        for row in frozen["entries"]
        if row["new"].endswith(".rs") and row["before"]["sha256"] != row["after"]["sha256"]
    }
    composition = json.loads(
        (OUT.parent / "quoridor-layout-adoption-v1/composition.json").read_bytes()
    )
    rust |= {
        row["current"]
        for row in composition["retirement33_composition"]
        if row["current"].endswith(".rs") and row["action"] == "three_way_merge"
    }
    # v1 Rustfmt already passed; only its extraction's extra final newline failed later.
    assert (OUT.parent / "layout-entrychecks-v1/changed-rustfmt.stderr").read_bytes() == b""
    # All modified Python proposal bytes were formatted by the author; independently check merged functions.
    source = (ROOT / "scripts/dev/research-lifecycle.py").read_text()
    lines = source.splitlines(keepends=True)
    selected = []
    for node in ast.parse(source).body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in {
            "source_check",
            "measurement_config",
            "numerical_check",
        }:
            selected.append("".join(lines[node.lineno - 1 : node.end_lineno]))
    assert len(selected) == 3
    extracted = OUT / "merged-affected-functions.py"
    extracted.write_text("\n\n".join(selected).rstrip() + "\n")
    run(
        [
            "bash",
            "scripts/dev/project-env.sh",
            "ruff",
            "format",
            "--no-cache",
            "--check",
            "--config",
            "tools/research-quality/ruff.toml",
            str(extracted),
        ],
        "merged-python-format",
    )
    run(
        [
            "bash",
            "scripts/dev/project-env.sh",
            "python",
            "-B",
            "scripts/dev/test_wasm_boundaries.py",
        ],
        "current-boundaries",
    )
    run(
        [
            "bash",
            "scripts/dev/project-env.sh",
            "python",
            "-B",
            "-m",
            "unittest",
            "discover",
            "-s",
            "tools/research-session",
            "-p",
            "test_build_provenance.py",
            "-k",
            "standard_git_revision_delta_and_untracked_input",
            "-v",
        ],
        "current-source-input-discriminator",
    )
    run(
        [
            "node",
            "--test",
            "--test-name-pattern",
            "^current scopes omit retired Web roots and require exact root filenames$",
            "tools/research-quality/test_export.mjs",
        ],
        "current-source-export-scope",
    )
    run(["git", "diff", "--exit-code"], "source-still-frozen")
    (OUT / "result.json").write_text(
        json.dumps(
            dict(
                current_Rustfmt=sorted(rust),
                merged_functions_format=True,
                current_feature_boundary_suite=True,
                current_Git_input_discriminator=True,
                current_export_scope=True,
                source_unchanged=True,
                scientific_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    print(json.dumps(dict(current_entrypoints="PASS", source_unchanged=True)))


if __name__ == "__main__":
    main()
