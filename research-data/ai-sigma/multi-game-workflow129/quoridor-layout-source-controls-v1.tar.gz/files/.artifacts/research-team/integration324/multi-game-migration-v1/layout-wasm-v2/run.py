"""Resolve locked missing cache inputs, then build only the unentered Wasm cases."""

import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

from quoridor_training.cycle_process import CPUPlan, CycleResources, available_cpus, execute

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOFTWARE = OUT.parent / "layout-software-v1"


def main():
    intent = json.loads((SOFTWARE / "build-intent-release.json").read_bytes())
    loader = importlib.util.spec_from_file_location(
        "lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    plan = CPUPlan.from_record(
        dict(
            management=[18],
            commands={"compile": [0]},
            allocation=[0, 18],
            resource_CPUs=2,
            worker_CPUs=1,
            library_threads=1,
        )
    )
    plan.check_host(available_cpus())
    plan.apply()
    assert lc.process.process_info(os.getpid())["rss"] <= 64 * 1024**2
    temporary = OUT / "TMP"
    temporary.mkdir()
    env = dict(os.environ, **intent["env"])
    env.update(
        TMPDIR=str(temporary),
        CARGO_NET_OFFLINE="true",
    )
    cargo = intent["tools"]["CARGO"]["file"]["path"]
    commands = [
        ("locked-dependency-metadata", [cargo, "metadata", "--locked", "--format-version", "1"]),
    ]
    for feature in ["rules", "ai"]:
        commands.append(
            (
                f"wasm-{feature}",
                [
                    "/usr/local/cargo/bin/wasm-pack",
                    "build",
                    str(ROOT / "games/quoridor/crates/quoridor-wasm"),
                    "--target",
                    "web",
                    "--dev",
                    "--mode",
                    "no-install",
                    "--out-dir",
                    str(OUT / "wasm" / feature),
                    "--out-name",
                    f"quoridor_{feature}",
                    "--locked",
                    "--offline",
                    "--no-default-features",
                    "--features",
                    feature,
                ],
            )
        )
    rows = []
    failure = None
    try:
        with lc.lease():
            lc.source_check(intent["source"])
            for name, argv in commands:
                deadline = time.monotonic() + 900
                resources = CycleResources(
                    dict(max_memory_bytes=4 * 1024**3 - 64 * 1024**2, host_ram_reserve=4 * 1024**3),
                    OUT,
                    deadline,
                )
                record = execute(
                    argv,
                    OUT / f"{name}.log",
                    deadline,
                    resources=resources,
                    cpu_plan=plan,
                    cpu_scope="compile",
                    cwd=ROOT,
                    env=dict(env, CARGO_NET_OFFLINE="false")
                    if name == "locked-dependency-metadata"
                    else env,
                )
                lc.settled(record)
                assert record["handle_closes_complete"]
                rows.append(dict(name=name, argv=argv, record=record))
                if name == "locked-dependency-metadata":
                    metadata = json.loads((OUT / "locked-dependency-metadata.log").read_text())
                    packages = metadata["packages"]
                    packages = [p for p in packages if p["id"] in metadata["workspace_members"]]
                    assert len(packages) == 7
                    assert all(
                        Path(p["manifest_path"]).is_relative_to(ROOT / "games/quoridor/crates")
                        for p in packages
                    )
                    assert all(
                        Path(t["src_path"]).is_relative_to(ROOT / "games/quoridor/crates")
                        for p in packages
                        for t in p["targets"]
                    )
            lc.source_check(intent["source"])
        assert not list(temporary.iterdir())
        temporary.rmdir()
    except BaseException as error:
        failure = dict(type=type(error).__name__, message=str(error))
        raise
    finally:
        outputs = []
        if failure is None:
            for feature in ["rules", "ai"]:
                p = OUT / "wasm" / feature / f"quoridor_{feature}_bg.wasm"
                body = p.read_bytes()
                outputs.append(
                    dict(path=str(p), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
                )
        (OUT / "result.json").write_text(
            json.dumps(
                dict(
                    at=datetime.datetime.now(datetime.UTC).isoformat(),
                    status="PASS" if failure is None else "FAILED",
                    source=intent["source"],
                    commands=rows,
                    failure=failure,
                    product_scratch_outputs=outputs,
                    no_product_generated_input_overwrite=True,
                    source_leases=[],
                    TMP=[str(p) for p in temporary.rglob("*")] if temporary.exists() else [],
                    scientific_calls=0,
                    model_forward=0,
                    host_future_quiet=False,
                ),
                indent=2,
            )
            + "\n"
        )
    print(json.dumps(dict(status="PASS", commands=[r["name"] for r in rows])))


if __name__ == "__main__":
    main()
