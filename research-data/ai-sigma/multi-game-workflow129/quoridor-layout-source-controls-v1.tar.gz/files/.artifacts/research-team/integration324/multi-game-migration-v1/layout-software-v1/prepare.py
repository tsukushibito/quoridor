"""Prepare only affected compiler qualification for the immutable relocated source."""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import subprocess
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OLD = ROOT / ".artifacts/research-team/integration324/cedar-etc-opportunity-v1/software-v5"
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def ref(p):
    b = p.read_bytes()
    return dict(
        path=str(p),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{stat.S_IMODE(p.stat().st_mode):04o}",
    )


def save(name, value):
    p = OUT / name
    with p.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")
    return ref(p)


def command(args):
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()


def main():
    memory = (
        int(
            next(
                line.split()[1]
                for line in Path("/proc/meminfo").read_text().splitlines()
                if line.startswith("MemAvailable:")
            )
        )
        * 1024
    )
    assert memory >= 12 * 1024**3
    assert not command(["git", "status", "--porcelain=v1"])
    load = importlib.util.spec_from_file_location(
        "relocated_software_owner", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(load)
    sys.modules[load.name] = lc
    load.loader.exec_module(lc)
    template = json.loads((OLD / "build-intent-release.json").read_bytes())
    with lc.lease():
        source = copy.deepcopy(template["source"])
        source.update(
            commit=command(["git", "rev-parse", "HEAD"]),
            patch=None,
            untracked_inputs=[],
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        for row in source["cargo_configs"]:
            p = Path(row["path"])
            row["file"] = ref(p) if p.exists() else None
        composition = ref(OUT.parent / "quoridor-layout-adoption-v1/composition.json")
        prior_manifest = ref(OLD / "operation-release/manifest.json")
        previous = json.loads(Path(prior_manifest["path"]).read_bytes())
        name = "etc33-related-quoridor-runner-1"
        prior = next(row for row in previous["checks"] if row["name"] == name)
        assert prior["status"] == "PASS" and prior["role"] == "test"
        config = ROOT / "games/quoridor/crates/quoridor-runner/src/config.rs"
        old_config = subprocess.check_output(
            ["git", "show", previous["source"]["commit"] + ":crates/quoridor-runner/src/config.rs"],
            cwd=ROOT,
        )
        assert config.read_bytes() == old_config
        previous_delta = Path(previous["source"]["patch"]["path"]).read_bytes()
        assert b"diff --git a/crates/quoridor-runner/src/config.rs " not in previous_delta
        adoption = save(
            "source-adoption.json",
            dict(
                schema="quoridor.research.source-adoption.v1",
                status="ACCEPTED",
                issue="quoridor-4lc.324.12.9",
                source=source,
                actual_composition=composition,
                scope="Frozen197-file relocation and exact purpose-ended33 sparse removal; accepted source only, no software/numerical/default admission.",
                prior_software=dict(
                    subjects=[ref(config)], receipts=[dict(file=prior_manifest, name=name)]
                ),
                prior_software_scope="Actual old Runner1 admission check reused only for retained legacy LMR/Sigma guard assertions/configuration, not whole relocated source. Current config.rs bytes exactly match its qualified source; original33 composition preserves the same legacy admission assertions while moving them into active measurement_ordering394_tests. No test/native Search replay or new function execution is claimed. New relocated caller behavior has fresh actual task-source4+4 Node lifecycle tests, tracked in the task handoff.",
            ),
        )
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=0,
            guardian_cpu=18,
            log_B=2 * 1024**2,
            owned_B=None,
            free_B=None,
        )
        support = save(
            "resources.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.12.9",
                authority=adoption,
                resources=dict(
                    CPU=2,
                    threads=1,
                    GPU=0,
                    worker_cpu=0,
                    guardian_cpu=18,
                    native_threads=1,
                    family_RAM_B=limits["family_B"],
                    controller_included=True,
                    controller_B=limits["controller_B"],
                    host_reserve_B=limits["host_reserve_B"],
                ),
                scope="Two affected workspace all-target Clippy/typing feature variants and one genuine current baseline release only. No executable/model/scientific runtime, Search, new numerical scope or replay. Remaining optional Wasm compile/product build are separate ordinary checks.",
                storage="Ordinary changed source/incremental existing serial Cargo pool; once affected output/cache observation after actual STOP, no microstorage grant or old peak recharge.",
                MemAvailable_at_preparation_B=memory,
            ),
        )
        target = Path(template["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker["writer"] == WRITER
        handover = json.loads((OLD / "target-handover.json").read_bytes())
        handover.update(
            fresh_private_root=str(OUT / "private-image-release"),
            actual_source_adoption=adoption,
            owned_remaining=[],
        )
        handover_ref = save("target-handover.json", handover)
        cargo = template["tools"]["CARGO"]["file"]["path"]
        common = [
            "--offline",
            "--locked",
            "--manifest-path",
            str(ROOT / "Cargo.toml"),
            "-j1",
            "--message-format=json-render-diagnostics",
            "--release",
        ]
        commands = []
        for feature in ["rules", "ai"]:
            commands.append(
                dict(
                    name="layout-alltarget-" + feature + "-Clippy",
                    role="lint",
                    argv=[
                        cargo,
                        "clippy",
                        *common,
                        "--workspace",
                        "--all-targets",
                        "--no-default-features",
                        "--features",
                        "quoridor-wasm/"
                        + feature
                        + ",quoridor-runner/measurement,quoridor-inference/claustrophobia",
                        "--no-deps",
                        "--",
                        "-Dwarnings",
                    ],
                )
            )
        release = copy.deepcopy(next(row for row in template["commands"] if row["role"] == "build"))
        release["name"] = "layout-retired33-genuine-baseline-release"
        commands.append(release)
        spec = copy.deepcopy(template)
        for key in ["admission", "intent_sha256", "test_cpu_cores"]:
            spec.pop(key, None)
        spec.update(
            output=str(OUT / "operation-release"),
            owned_outputs=[str(OUT.parent), str(target)],
            support=support,
            source_adoption=adoption,
            target_handover=handover_ref,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / "private-image-release/quoridor-runner"),
            TMP=str(OUT / "build-TMP"),
            command_timeout_seconds=2400,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        (target / ".research-owner.json").write_text(
            json.dumps(
                dict(writer=WRITER, target=str(target), support_sha256=support["sha256"]), indent=2
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            "admission.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Software only; normal entry owns actual source/CPU/RAM/cancel/cleanup. Not scientific admission.",
            ),
        )
        intent = save("build-intent-release.json", spec)
        job = json.loads((OLD / "job-release.json").read_bytes())
        job.update(
            issue="quoridor-4lc.324.12.9",
            goal_issue="quoridor-4lc.324.12.9",
            thread_id="01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            argv=[
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "build",
                "--intent",
                intent["path"],
                "--sha256",
                intent["sha256"],
            ],
            resource_contract=support["path"],
            max_runtime_seconds=2460,
            end_at=None,
            notify_until=None,
        )
        save("job-release.json", job)
        print(json.dumps(dict(intent=intent, support=support, submitted=False)))


if __name__ == "__main__":
    main()
