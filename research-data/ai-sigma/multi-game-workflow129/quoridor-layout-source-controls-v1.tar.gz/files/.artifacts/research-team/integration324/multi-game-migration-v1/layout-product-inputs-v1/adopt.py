"""Supply only existing unchanged product Wasm inputs for new UI checks."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path("/workspaces/quoridor")
WT = ROOT / ".worktree/quoridor-rust-layout129"
OUT = Path(__file__).resolve().parent


def main():
    assert (WT / "games/quoridor/bridge/package.json").is_file()
    rows = []
    for feature in ["rules", "ai"]:
        name = "quoridor_" + feature
        for suffix in [".js", ".d.ts", "_bg.wasm", "_bg.wasm.d.ts"]:
            rel = Path("packages/engine-bridge/wasm") / feature / (name + suffix)
            source = ROOT / rel
            target = WT / "games/quoridor/bridge/wasm" / feature / (name + suffix)
            assert source.is_file() and not source.is_symlink() and not target.exists()
            before = source.read_bytes()
            sha = hashlib.sha256(before).hexdigest()
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.with_name(target.name + ".Root-copy-TMP")
            shutil.copy2(source, temporary)
            assert temporary.read_bytes() == before
            temporary.replace(target)
            rows.append(
                dict(
                    source=str(source),
                    destination=str(target),
                    bytes=len(before),
                    sha256=sha,
                    mode=oct(source.stat().st_mode & 0o777),
                    source_mtime_ns=source.stat().st_mtime_ns,
                )
            )
    result = dict(
        inputs=rows,
        new_bytes=sum(r["bytes"] for r in rows),
        qualification="Existing Main generated product inputs only, unchanged copy for newly changed moved bridge typecheck/session-lifecycle checks. No Cargo/build/native/scientific source qualification or old experiment replay claimed.",
        Main_Git_changes=False,
    )
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    message = OUT / "supplied.txt"
    message.write_text(
        "Required product Wasm inputs now supplied at exact taskcheckout games/quoridor/bridge/wasm/{rules,ai}, eight generated js/type/Wasm files total "
        + str(result["new_bytes"])
        + "B. Root unchanged Main input copy only, hashes/original mtime/modes preserved in "
        + str(OUT / "result.json")
        + ". No rebuild or current scientific/native qualification; these are existing product artifacts for UI boundary checks, not source aliases. Use taskcheckout bridge TS source/actual path evidence as agreed; continue bounded checks. If generated API mismatch genuinely requires build report exact mismatch; no self Cargo write. No ACK gate or repeated start-policy notice.\n"
    )
    r = subprocess.run(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a15e98-2df8-7af1-ae8e-375b9e4b5198",
            "--issue",
            "quoridor-4lc.324.12.9.3",
            "--cwd",
            str(WT),
            "--body-file",
            str(message),
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=90,
    )
    (OUT / "delivery.stdout").write_text(r.stdout)
    (OUT / "delivery.stderr").write_text(r.stderr)
    assert r.returncode == 0, r.stdout + r.stderr
    print(
        json.dumps(dict(files=len(rows), bytes=result["new_bytes"], delivery=json.loads(r.stdout)))
    )


if __name__ == "__main__":
    main()
