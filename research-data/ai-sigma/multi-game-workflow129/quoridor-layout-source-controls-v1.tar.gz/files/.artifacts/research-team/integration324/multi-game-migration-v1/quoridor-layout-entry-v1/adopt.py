"""Start one disjoint task-scoped Web migration after actual prerequisites."""

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def run(args):
    r = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, timeout=150)
    assert r.returncode == 0, r.stdout + r.stderr
    return r.stdout


def main():
    for issue in ["quoridor-4lc.324.12.6", "quoridor-4lc.324.12.8"]:
        assert (
            json.loads(run(["bash", "scripts/dev/beads.sh", "show", issue, "--json"]))[0]["status"]
            == "closed"
        )
    children = json.loads(
        run(
            [
                "bash",
                "scripts/dev/beads.sh",
                "list",
                "--parent",
                "quoridor-4lc.324.12.9",
                "--all",
                "--brief",
                "--json",
                "--limit",
                "20",
            ]
        )
    )
    assert not any("Quoridor Rust/Wasm配置" in r["title"] for r in children)
    mem = (
        int(
            next(
                s.split()[1]
                for s in Path("/proc/meminfo").read_text().splitlines()
                if s.startswith("MemAvailable:")
            )
        )
        * 1024
    )
    assert mem > 8 * 1024**3
    assert not run(["git", "status", "--porcelain=v1"])
    run(
        [
            "bash",
            "scripts/dev/manage_worktree.sh",
            "create-sparse",
            "quoridor-rust-layout129",
            "codex/quoridor-rust-layout129",
            "HEAD",
            "crates",
            "games/quoridor",
            "configs",
            "docs/design",
            "docs/development",
            "apps/web",
            "packages/engine-bridge",
            "python",
            "scripts/dev",
            "tests",
            "tools/research-quality",
        ]
    )
    wt = ROOT / ".worktree/quoridor-rust-layout129"
    assert not (wt / "node_modules").exists()
    (wt / "node_modules").symlink_to(ROOT / "node_modules", target_is_directory=True)
    plan = json.loads((OUT.parent / "environment-v1/cpu-plan.json").read_bytes())
    plan["group"] = "QUORIDOR_LAYOUT129_IMPLEMENTATION"
    plan["cpu_plan"]["commands"] = {"implementation": [16]}
    plan["cpu_plan"]["allocation"] = [16, 18]
    plan["family_B"] = 2 * 1024**3
    plan["child_max_B"] = 2 * 1024**3 - 64 * 1024**2
    p = OUT / "cpu-plan.json"
    p.write_text(json.dumps(plan, indent=2) + "\n")
    ref = dict(
        path=str(p),
        sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
        bytes=p.stat().st_size,
        mode="0644",
    )
    task = OUT / "task.md"
    task.write_text(
        task.read_text()
        + "\nExact CPUPlan: "
        + json.dumps(ref)
        + "\nObserved MemAvailableB="
        + str(mem)
        + "; ordinaryRoot0/G18, task12/G18 physically distinct from prior task16.\n"
    )
    child = json.loads(
        run(
            [
                "bash",
                "scripts/dev/beads.sh",
                "create",
                "Quoridor Rust/Wasm配置とQuoridor起動終了を分離",
                "--parent",
                "quoridor-4lc.324.12.9",
                "--type",
                "task",
                "--body-file",
                str(task),
                "--json",
            ]
        )
    )
    if isinstance(child, list):
        child = child[0]
    (OUT / "child.json").write_text(
        json.dumps(dict(issue=child["id"], cwd=str(wt), cpu_plan=ref, MemAvailable_B=mem), indent=2)
        + "\n"
    )
    received = run(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "create",
            "--issue",
            child["id"],
            "--cwd",
            str(wt),
            "--body-file",
            str(task),
            "--name",
            "構成移行：Quoridor Rust・Wasm配置",
        ]
    )
    (OUT / "dispatch.json").write_text(received)
    run(
        [
            "bash",
            "scripts/dev/beads.sh",
            "update",
            "quoridor-4lc.324.12.9",
            "--append-notes",
            "Next disjoint task "
            + child["id"]
            + " actualdispatch inmanagedquoridor-rust-layout129: seven Quoridor Rust crates/one bridge layout and maintained caller proposal only; Python/configs/Othello separate. New task context/first useful read remains to verify; first migration-start policy notice already sent exactly once, no repeat. Root owns Main/Git/Cargo/commonmetadata; taskCPU16/G18/F2GiB/host4/G0.",
        ]
    )
    run(["bash", "scripts/dev/beads.sh", "backup", "sync"])
    print(received)


if __name__ == "__main__":
    main()
