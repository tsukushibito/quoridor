"""Compiler-free checks of the exact private proposal and relocated manifests."""

import ast
import difflib
import json
from pathlib import Path
import subprocess
import tomllib
import unittest
import sys

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/quoridor-rust-layout129"
sys.path.insert(0, str(OWN))
from proposal import read_proposal

proposal = read_proposal()
name = "tools/research-session/test_build_provenance.py"
text = subprocess.check_output(["git", "--no-optional-locks", "show", "HEAD:" + name], text=True)
proposal[name] = {
    "before": text,
    "after": text.replace("crates/new_module.rs", "games/quoridor/crates/new_module.rs"),
}
prettier = "/workspaces/quoridor/tools/research-quality/node_modules/prettier/bin/prettier.cjs"
prettier_config = str(ROOT / "tools/research-quality/.prettierrc.json")
ruff_config = str(ROOT / "tools/research-quality/ruff.toml")
for name, pair in proposal.items():
    text = pair["after"]
    if name.endswith(".py"):
        text = subprocess.run(
            ["ruff", "format", "--config", ruff_config, "--stdin-filename", name, "-"],
            input=text,
            text=True,
            capture_output=True,
            check=True,
        ).stdout
        pair["after"] = text
        ast.parse(text, filename=name)
        for command in [
            ["ruff", "format", "--check", "--config", ruff_config, "--stdin-filename", name, "-"],
            ["ruff", "check", "--config", ruff_config, "--stdin-filename", name, "-"],
        ]:
            subprocess.run(command, input=text, text=True, check=True)
    elif name.endswith((".mjs", ".json")):
        subprocess.run(
            ["node", prettier, "--config", prettier_config, "--check", "--stdin-filepath", name],
            input=text,
            text=True,
            check=True,
        )
        if name.endswith(".mjs"):
            subprocess.run(
                ["node", "--check", "--input-type=module"], input=text, text=True, check=True
            )
        else:
            json.loads(text)
    elif name.endswith(".toml"):
        tomllib.loads(text)

# No dependency changes: normalize only the intended workspace package location.
old_lock = json.loads(proposal["package-lock.json"]["before"])
new_lock = json.loads(proposal["package-lock.json"]["after"])
old_lock["packages"]["games/quoridor/bridge"] = old_lock["packages"].pop("packages/engine-bridge")
old_lock["packages"][""]["workspaces"] = ["apps/web", "games/quoridor/bridge"]
old_lock["packages"]["node_modules/@quoridor/engine-bridge"]["resolved"] = "games/quoridor/bridge"
assert old_lock == new_lock
workspace = tomllib.loads(proposal["Cargo.toml"]["after"])
assert len(workspace["workspace"]["members"]) == 7
for member in workspace["workspace"]["members"]:
    manifest = ROOT / member / "Cargo.toml"
    value = tomllib.loads(manifest.read_text())
    for section in ["dependencies", "dev-dependencies", "build-dependencies"]:
        for dep in value.get(section, {}).values():
            if isinstance(dep, dict) and "path" in dep:
                assert (
                    (manifest.parent / dep["path"])
                    .resolve()
                    .is_relative_to(ROOT / "games/quoridor/crates")
                )
                tomllib.loads((manifest.parent / dep["path"] / "Cargo.toml").read_text())

boundary_path = ROOT / "scripts/check-boundaries.py"
boundary = {"__file__": str(boundary_path), "__name__": "proposal_boundary"}
exec(
    compile(proposal["scripts/check-boundaries.py"]["after"], str(boundary_path), "exec"), boundary
)
boundary["check_boundary"](
    tomllib.loads((ROOT / "games/quoridor/crates/quoridor-wasm/Cargo.toml").read_text())
)
suite_path = ROOT / "scripts/dev/test_wasm_boundaries.py"
suite = {"__file__": str(suite_path), "__name__": "proposal_boundary_tests"}
exec(
    compile(proposal["scripts/dev/test_wasm_boundaries.py"]["after"], str(suite_path), "exec"),
    suite,
)
tests = unittest.defaultTestLoader.loadTestsFromTestCase(suite["BoundaryTests"])
result = unittest.TextTestRunner(verbosity=2).run(tests)
assert result.wasSuccessful()
saved_root = suite["ROOT"]
suite["ROOT"] = OWN / "missing-selected-checkout"
try:
    missing = suite["BoundaryTests"]("test_multiline_separation_and_current_source")
    missing.setUp()
    missing.test_multiline_separation_and_current_source()
except FileNotFoundError:
    print("Missing selected-checkout manifest fails closed; no ancestor/Main fallback.")
else:
    raise AssertionError("Missing task source unexpectedly accepted")
finally:
    suite["ROOT"] = saved_root

# Check literal include targets without opening historical/scientific payloads.
import re

include_count = 0
for path in (ROOT / "games/quoridor/crates").rglob("*.rs"):
    for kind, relative in re.findall(
        r'(include(?:_str|_bytes)?!)\("([^"\n]+)"\)', path.read_text()
    ):
        target = (path.parent / relative).resolve()
        assert target.is_relative_to(ROOT), target
        assert target.is_file(), (path, relative)
        include_count += 1
assert (ROOT / "games/quoridor/crates/quoridor-runner").parents[3] == ROOT

parts = []
for name, pair in proposal.items():
    current = (
        (ROOT / name).read_text()
        if (ROOT / name).exists()
        else subprocess.check_output(
            ["git", "--no-optional-locks", "show", "HEAD:" + name],
            text=True,
        )
    )
    assert current == pair["before"], name
    parts.append(f"diff --git a/{name} b/{name}\n")
    parts.extend(
        difflib.unified_diff(
            pair["before"].splitlines(True),
            pair["after"].splitlines(True),
            fromfile="a/" + name,
            tofile="b/" + name,
        )
    )
(OWN / "common-caller-proposal.patch").write_text("".join(parts))
print(
    json.dumps(
        {
            "proposal_files": len(proposal),
            "boundary_tests": result.testsRun,
            "literal_includes": include_count,
            "lock_dependency_equality": True,
            "crate_sibling_boundaries": True,
        }
    )
)
