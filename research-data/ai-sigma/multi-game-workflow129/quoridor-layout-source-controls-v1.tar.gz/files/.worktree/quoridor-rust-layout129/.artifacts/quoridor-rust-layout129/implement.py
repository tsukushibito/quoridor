"""Perform the authorized source renames and prepare the private common proposal."""

import difflib
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/quoridor-rust-layout129"
mapping = {"crates/": "games/quoridor/crates/", "packages/engine-bridge/": "games/quoridor/bridge/"}
before = {}
for old in mapping:
    for path in (ROOT / old).rglob("*"):
        if path.is_file():
            assert not path.is_symlink(), path
            data = path.read_bytes()
            before[str(path.relative_to(ROOT))] = {
                "sha256": hashlib.sha256(data).hexdigest(),
                "bytes": len(data),
                "mode": format(path.stat().st_mode & 0o777, "04o"),
            }
(OWN / "original-files.json").write_text(json.dumps(before, indent=2) + "\n")
(ROOT / "games/quoridor").mkdir(parents=True, exist_ok=True)
assert not (ROOT / "games/quoridor/crates").exists()
shutil.move(ROOT / "crates", ROOT / "games/quoridor/crates")
assert not (ROOT / "games/quoridor/bridge/src").exists()
# Root may already have supplied only generated verification inputs.
bridge = ROOT / "games/quoridor/bridge"
bridge.mkdir(exist_ok=True)
for path in (ROOT / "packages/engine-bridge").iterdir():
    shutil.move(path, bridge / path.name)
(ROOT / "packages/engine-bridge").rmdir()

changed = []


def edit(name, old, new):
    path = ROOT / name
    text = path.read_text()
    assert old in text, (name, old)
    path.write_text(text.replace(old, new))
    if name not in changed:
        changed.append(name)


for name in [
    "apps/web/tsconfig.json",
    "apps/web/vite.config.ts",
    "apps/web/src/games/quoridor/test-support/rules-test-api.ts",
    "tests/e2e/phase1-rules.spec.ts",
    "tests/unit/worker-lifecycle.test.mjs",
    "tests/unit/quoridor-session-lifecycle.test.mjs",
]:
    edit(name, "packages/engine-bridge", "games/quoridor/bridge")

for name in [
    "games/quoridor/crates/quoridor-runner/src/runtime.rs",
    "games/quoridor/crates/quoridor-runner/src/value_search_strength.rs",
    "games/quoridor/crates/quoridor-runner/src/arena_manifest.rs",
    "games/quoridor/crates/quoridor-runner/tests/arena.rs",
]:
    edit(name, "../../../configs/arena/smoke.json", "../../../../../configs/arena/smoke.json")
edit(
    "games/quoridor/crates/quoridor-runner/src/main.rs",
    'PathBuf::from(env!("CARGO_MANIFEST_DIR"))\n                .parent()\n                .unwrap()\n                .parent()\n                .unwrap()\n                .to_owned()',
    'PathBuf::from(env!("CARGO_MANIFEST_DIR"))\n                .ancestors()\n                .nth(4)\n                .expect("Quoridor crate must be inside the repository workspace")\n                .to_owned()',
)
edit(
    "games/quoridor/crates/quoridor-data/tests/terminal_stream.rs",
    "../../python",
    "../../../../python",
)
for path in (ROOT / "games/quoridor/crates").glob("*/README.md"):
    name = str(path.relative_to(ROOT))
    text = path.read_text()
    for directory in [
        "docs/",
        "python/",
        "research-data/",
        "tools/",
        "configs/",
        ".artifacts/",
        "apps/",
    ]:
        if "../../" + directory in text:
            edit(name, "../../" + directory, "../../../../" + directory)
for directory in ["python/", "docs/"]:
    edit("games/quoridor/crates/README.md", "../" + directory, "../../../" + directory)
edit(
    "games/quoridor/bridge/README.md",
    "`crates/quoridor-wasm",
    "`games/quoridor/crates/quoridor-wasm",
)
edit(
    "games/quoridor/bridge/README.md",
    "../../crates/quoridor-wasm/README.md",
    "../crates/quoridor-wasm/README.md",
)
(OWN / "authored-files.json").write_text(json.dumps(changed, indent=2) + "\n")

proposal = {}


def propose(name, transform):
    before_text = (ROOT / name).read_text()
    after_text = transform(before_text)
    assert after_text != before_text, name
    proposal[name] = {"before": before_text, "after": after_text}


for name in [
    "Cargo.toml",
    "package.json",
    "package-lock.json",
    ".gitignore",
    "scripts/build-wasm.mjs",
    "scripts/codegen-protocol.mjs",
    "scripts/doctor.mjs",
    "scripts/check-boundaries.mjs",
    "scripts/check-boundaries.py",
    "scripts/dev/check-research.py",
]:
    propose(
        name,
        lambda text: text.replace("packages/engine-bridge", "games/quoridor/bridge").replace(
            "crates/quoridor-", "games/quoridor/crates/quoridor-"
        ),
    )
propose(
    "scripts/dev/test_wasm_boundaries.py",
    lambda text: text.replace(
        "        # Current maintained manifest remains unchanged by this repair.\n"
        "        main = Path(__file__).resolve()\n"
        '        while not (main / "crates/quoridor-wasm/Cargo.toml").is_file():\n'
        "            parent = main.parent\n"
        "            if parent == main:\n"
        '                self.fail("Current Wasm manifest not found")\n'
        "            main = parent\n"
        '        with (main / "crates/quoridor-wasm/Cargo.toml").open("rb") as source:',
        "        # Bind the maintained manifest to this checkout; missing source must fail.\n"
        '        with (ROOT / "games/quoridor/crates/quoridor-wasm/Cargo.toml").open("rb") as source:',
    ),
)
propose(
    "scripts/dev/research-lifecycle.py",
    lambda text: text.replace('        "crates",\n', '        "games/quoridor/crates",\n'),
)
propose(
    "scripts/export-fresh-source.mjs",
    lambda text: text.replace('    "crates/",', '    "games/quoridor/crates/",').replace(
        '    "packages/",', '    "games/quoridor/bridge/",'
    ),
)
propose(
    "tools/research-quality/test_export.mjs",
    lambda text: text.replace("packages/engine-bridge", "games/quoridor/bridge"),
)
for name in [
    "README.md",
    "scripts/README.md",
    "tools/README.md",
    "docs/README.md",
    "docs/development/ai-research-code.md",
    "docs/development/ai-research-experiments.md",
    "docs/development/rust-ai.md",
    "configs/arena/README.md",
    "docs/design/lightweight-move-ordering-v1.md",
    "docs/research-findings.md",
]:
    propose(
        name,
        lambda text: text.replace("packages/engine-bridge", "games/quoridor/bridge").replace(
            "crates/", "games/quoridor/crates/"
        ),
    )
proposal["scripts/README.md"]["after"] = proposal["scripts/README.md"]["after"].replace(
    "`apps/`・`packages/`・`games/quoridor/crates/`",
    "`apps/`・`games/quoridor/bridge/`・`games/quoridor/crates/`",
)
propose(
    "docs/design/quoridor-3d-webapp-design-rust-wasm-v1.md",
    lambda text: text.replace("packages/engine-bridge", "games/quoridor/bridge")
    .replace("`crates`をRust実装の置き場", "`games/quoridor/crates`をRust実装の置き場")
    .replace("├── packages/\n│   └── engine-bridge/", "├── games/quoridor/bridge/")
    if False
    else text.replace(
        "`apps/web`をWeb製品、`packages/engine-bridge`をWasmとの境界、`crates`をRust実装の置き場にする。",
        "`apps/web`をWeb製品、`games/quoridor/bridge`をWasmとの境界、`games/quoridor/crates`をRust実装の置き場にする。",
    )
    .replace("packages/engine-bridge", "games/quoridor/bridge")
    .replace("├── packages/\n│   └── engine-bridge/", "├── games/quoridor/\n│   └── bridge/")
    .replace("├── crates/", "├── games/quoridor/crates/"),
)
(OWN / "common-proposal-content.json").write_text(json.dumps(proposal, indent=2) + "\n")
parts = []
for name, pair in proposal.items():
    parts.append(f"diff --git a/{name} b/{name}\n")
    parts.extend(
        difflib.unified_diff(
            pair["before"].splitlines(True),
            pair["after"].splitlines(True),
            fromfile="a/" + name,
            tofile="b/" + name,
        )
    )
(OWN / "common-caller-proposal.patch").write_text("".join(parts))
print(
    json.dumps(
        {
            "moved_files": len(before),
            "authored_files": changed,
            "common_proposal_files": list(proposal),
        },
        indent=2,
    )
)
