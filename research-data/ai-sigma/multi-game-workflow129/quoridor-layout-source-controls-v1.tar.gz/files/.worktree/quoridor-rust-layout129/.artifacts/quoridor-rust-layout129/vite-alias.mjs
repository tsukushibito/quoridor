import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import config from '../../apps/web/vite.config.ts';

const actual = config({ command: 'serve', mode: 'development' }).resolve.alias[
  '@quoridor/engine-bridge'
];
assert.equal(actual, resolve('games/quoridor/bridge/src/index.ts'));
console.log(JSON.stringify({ actualBridgeSource: actual }));
