"""Format owned edits and private proposal content with installed project tools."""

import difflib
import json
from pathlib import Path
import subprocess

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/quoridor-rust-layout129"
PRETTIER = "/workspaces/quoridor/tools/research-quality/node_modules/prettier/bin/prettier.cjs"
CONFIG = str(ROOT / "tools/research-quality/.prettierrc.json")
RUFF_CONFIG = str(ROOT / "tools/research-quality/ruff.toml")
changed = json.loads((OWN / "authored-files.json").read_text())
rust = [name for name in changed if name.endswith(".rs")]
web = [name for name in changed if name.endswith((".ts", ".mjs", ".json"))]
subprocess.run(
    ["rustfmt", "--edition", "2024", "--config", "skip_children=true", *rust], check=True
)
subprocess.run(
    ["rustfmt", "--check", "--edition", "2024", "--config", "skip_children=true", *rust], check=True
)
subprocess.run(["node", PRETTIER, "--config", CONFIG, "--write", *web], check=True)
subprocess.run(["node", PRETTIER, "--config", CONFIG, "--check", *web], check=True)
proposal = json.loads((OWN / "common-proposal-content.json").read_text())
name = "tools/research-quality/test_export.mjs"
text = proposal[name]["after"]
text = text.replace(
    "    'games/quoridor/bridge/src/index.ts',\n    'Cargo.toml',",
    "    'games/quoridor/bridge/src/index.ts',\n"
    "    'games/quoridor/crates/quoridor-core/src/lib.rs',\n"
    "    'crates/retired/src/lib.rs',\n"
    "    'packages/engine-bridge/retired.ts',\n"
    "    'Cargo.toml',",
)
text = text.replace(
    "      'package.json',\n      'games/quoridor/bridge/src/index.ts',",
    "      'games/quoridor/bridge/src/index.ts',\n"
    "      'games/quoridor/crates/quoridor-core/src/lib.rs',\n"
    "      'package.json',",
)
text = text.replace(
    "      'README.md',\n      'pyproject.toml',",
    "      'README.md',\n"
    "      'games/quoridor/crates/quoridor-core/src/lib.rs',\n"
    "      'pyproject.toml',",
)
proposal[name]["after"] = text
# Keep the historical planned file tree intact; identify the actual current paths.
name = "docs/design/quoridor-3d-webapp-design-rust-wasm-v1.md"
text = proposal[name]["after"]
text = text.replace("├── games/quoridor/\n│   └── bridge/", "├── packages/\n│   └── engine-bridge/")
text = text.replace("├── games/quoridor/crates/", "├── crates/")
text = text.replace(
    "以下は責務の配置先を示す設計図である。",
    "以下は初期設計時の責務図である。現役配置は `crates/` → "
    "`games/quoridor/crates/`、`packages/engine-bridge/` → `games/quoridor/bridge/` "
    "へ移行した。UIの正本は `apps/web/src/games/quoridor/` とし、"
    "Python・configs・ゲーム文書の移動は後続境界で扱う。",
)
proposal[name]["after"] = text
for name, pair in proposal.items():
    text = pair["after"]
    if name.endswith((".mjs", ".json")):
        text = subprocess.run(
            ["node", PRETTIER, "--config", CONFIG, "--stdin-filepath", name],
            input=text,
            text=True,
            capture_output=True,
            check=True,
        ).stdout
    elif name.endswith(".py"):
        text = subprocess.run(
            ["ruff", "format", "--config", RUFF_CONFIG, "--stdin-filename", name, "-"],
            input=text,
            text=True,
            capture_output=True,
            check=True,
        ).stdout
        subprocess.run(
            ["ruff", "check", "--config", RUFF_CONFIG, "--stdin-filename", name, "-"],
            input=text,
            text=True,
            check=True,
        )
    pair["after"] = text
(OWN / "common-proposal-content.json").write_text(json.dumps(proposal, indent=2) + "\n")
parts = []
for name, pair in proposal.items():
    assert (ROOT / name).read_text() == pair["before"], name
    parts.append(f"diff --git a/{name} b/{name}\n")
    parts.extend(
        difflib.unified_diff(
            pair["before"].splitlines(True),
            pair["after"].splitlines(True),
            fromfile="a/" + name,
            tofile="b/" + name,
        )
    )
(OWN / "common-caller-proposal.patch").write_text("".join(parts))
print("Formatted scoped Rust/TS/config edits and private JS/Python/JSON proposal content.")
