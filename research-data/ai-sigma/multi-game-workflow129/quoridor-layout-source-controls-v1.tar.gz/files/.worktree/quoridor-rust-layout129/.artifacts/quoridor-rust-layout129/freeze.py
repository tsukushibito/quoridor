"""Freeze owned source deltas without staging or changing the task Git index."""

import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/quoridor-rust-layout129"
sys.path.insert(0, str(OWN))
from proposal import read_proposal


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path.relative_to(ROOT)),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


original = json.loads((OWN / "original-files.json").read_text())
mapping = {"crates/": "games/quoridor/crates/", "packages/engine-bridge/": "games/quoridor/bridge/"}
callers = [
    "apps/web/tsconfig.json",
    "apps/web/vite.config.ts",
    "apps/web/src/games/quoridor/test-support/rules-test-api.ts",
    "tests/e2e/phase1-rules.spec.ts",
    "tests/unit/worker-lifecycle.test.mjs",
    "tests/unit/quoridor-session-lifecycle.test.mjs",
]
command = [
    "git",
    "--no-optional-locks",
    "diff",
    "--binary",
    "--no-renames",
    "--no-ext-diff",
    "--no-textconv",
    "HEAD",
    "--",
    "crates",
    "packages/engine-bridge",
    *callers,
]
patch = subprocess.check_output(command).decode()
entries = []
for old, before in sorted(original.items()):
    prefix = next(prefix for prefix in mapping if old.startswith(prefix))
    new = mapping[prefix] + old[len(prefix) :]
    path = ROOT / new
    after = ref(path)
    assert not (ROOT / old).exists()
    assert not path.is_symlink()
    assert before["mode"] == after["mode"]
    text = path.read_text()
    assert text.endswith("\n"), new
    patch += f"diff --git a/{new} b/{new}\nnew file mode 100{after['mode'][-3:]}\n"
    patch += "".join(
        difflib.unified_diff(
            [], text.splitlines(keepends=True), fromfile="/dev/null", tofile="b/" + new
        )
    )
    entries.append(
        {
            "old": old,
            "new": new,
            "before": before,
            "after": after,
            "byte_identical": before["sha256"] == after["sha256"],
        }
    )
for name in callers:
    before = subprocess.check_output(["git", "--no-optional-locks", "show", "HEAD:" + name])
    entries.append(
        {
            "old": name,
            "new": name,
            "before": {"sha256": hashlib.sha256(before).hexdigest(), "bytes": len(before)},
            "after": ref(ROOT / name),
        }
    )
assert "rename from" not in patch and "rename to" not in patch
assert "/wasm/rules/" not in "\n".join(
    line for line in patch.splitlines() if line.startswith("diff --git ")
)
(OWN / "full.patch").write_text(patch)
proposal = read_proposal()
common = []
for name, pair in proposal.items():
    if (ROOT / name).is_file():
        assert (ROOT / name).read_text() == pair["before"], name
    common.append(
        {
            "path": name,
            "before_sha256": hashlib.sha256(pair["before"].encode()).hexdigest(),
            "after_sha256": hashlib.sha256(pair["after"].encode()).hexdigest(),
        }
    )
index = json.loads((OWN / "index-readonly-fingerprint.json").read_text())
assert hashlib.sha256(Path(index["path"]).read_bytes()).hexdigest() == index["sha256"]
input_manifest = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/"
    "multi-game-migration-v1/layout-product-inputs-v1/result.json"
)
inputs = json.loads(input_manifest.read_text())["inputs"]
for item in inputs:
    path = Path(item["destination"])
    actual = ref(path)
    assert path.is_relative_to(ROOT / "games/quoridor/bridge/wasm")
    assert actual["sha256"] == item["sha256"]
    assert actual["bytes"] == item["bytes"]
    assert int(actual["mode"], 8) == int(item["mode"], 8)
    assert path.stat().st_mtime_ns == item["source_mtime_ns"]
bundle_hashes = {ref(path)["sha256"] for path in (OWN / "web-dist/assets").glob("*.wasm")}
assert bundle_hashes == {item["sha256"] for item in inputs if item["destination"].endswith(".wasm")}
record = {
    "issue": "quoridor-4lc.324.12.9.3",
    "base_commit": subprocess.check_output(
        ["git", "--no-optional-locks", "rev-parse", "HEAD"], text=True
    ).strip(),
    "source_root": str(ROOT),
    "mapping": mapping,
    "entries": entries,
    "common_proposal_files": common,
    "patches": [ref(OWN / "full.patch"), ref(OWN / "common-caller-proposal.patch")],
    "generated_product_verification_inputs": {
        "manifest": str(input_manifest),
        "files": len(inputs),
        "bytes": sum(item["bytes"] for item in inputs),
        "unchanged_sha_size_mode_mtime": True,
        "excluded_from_source_patches": True,
    },
    "index_fingerprint_unchanged_during_diff_review_and_freeze": index,
    "historical_evidence": "Original source/FileRefs/RAW/archives/absolute paths/frozen comparisons remain unchanged; historical crates/* map to games/quoridor/crates/* only for the maintained current tree. Old generated paths map to games/quoridor/bridge/wasm/* for unchanged Root-supplied product verification inputs only. No science/native/Cargo qualification is inferred.",
}
(OWN / "frozen-files.json").write_text(json.dumps(record, indent=2) + "\n")
print(
    json.dumps(
        {
            "base_commit": record["base_commit"],
            "moved": len(original),
            "byte_identical_moved": sum(e.get("byte_identical", False) for e in entries),
            "caller_edits": len(callers),
            "common_proposal_files": len(common),
            "patches": record["patches"],
            "generated_input_check": record["generated_product_verification_inputs"],
        },
        indent=2,
    )
)
