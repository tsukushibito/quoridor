"""Check task-checkout TypeScript and record the actual compiler source paths."""

import json
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/quoridor-rust-layout129"
checks = [
    ("bridge-dom", ["-p", "games/quoridor/bridge/tsconfig.json"]),
    ("bridge-worker", ["-p", "games/quoridor/bridge/tsconfig.worker.json"]),
    ("web", ["-p", "apps/web/tsconfig.json"]),
    (
        "e2e-rules-types",
        ["-p", str(OWN / "tsconfig.e2e.json")],
    ),
]
results = []
for name, args in checks:
    if len(sys.argv) > 1 and name != sys.argv[1]:
        continue
    command = ["node", "node_modules/typescript/bin/tsc", "--noEmit", "--listFiles", *args]
    result = subprocess.run(
        command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45
    )
    (OWN / (name + ".list-files.txt")).write_text(result.stdout)
    paths = [line.strip() for line in result.stdout.splitlines() if line.startswith("/")]
    bridge_paths = [p for p in paths if "/bridge/" in p or "/engine-bridge/" in p]
    assert bridge_paths, (name, "No bridge source checked")
    assert all(p.startswith(str(ROOT / "games/quoridor/bridge") + "/") for p in bridge_paths), (
        bridge_paths
    )
    record = {
        "name": name,
        "command": command,
        "returncode": result.returncode,
        "bridge_paths": bridge_paths,
    }
    results.append(record)
    print(json.dumps(record))
    if result.returncode:
        print(result.stdout)
        (OWN / "typechecks.json").write_text(json.dumps(results, indent=2) + "\n")
        raise SystemExit(result.returncode)
if len(sys.argv) > 1:
    earlier = json.loads((OWN / "typechecks.json").read_text())
    results = [r for r in earlier if r["name"] != sys.argv[1]] + results
(OWN / "typechecks.json").write_text(json.dumps(results, indent=2) + "\n")
