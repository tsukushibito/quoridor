"""Task command adapter for the existing CPUPlan/CycleResources/execute controls."""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time

from quoridor_training import cycle_process as process

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
PLAN = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/"
    "multi-game-migration-v1/quoridor-layout-entry-v1/cpu-plan.json"
)
data = PLAN.read_bytes()
assert (hashlib.sha256(data).hexdigest(), len(data), PLAN.stat().st_mode & 0o777) == (
    "8001a9e53f1adb3d16b7e2db170c265e0e41f6464d6dca3ee9911885f5b7b411",
    506,
    0o644,
)
record = json.loads(data)
plan = process.CPUPlan.from_record(record["cpu_plan"])
plan.check_host(process.available_cpus())
plan.apply()
assert process.process_info(os.getpid())["rss"] < record["controller_B"]
spec = importlib.util.spec_from_file_location(
    "task_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
)
lifecycle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lifecycle)
name = sys.argv[1]
assert name.replace("-", "").isalnum()
tmp = OWN / "tmp" / name
tmp.mkdir(parents=True, exist_ok=False)
env = dict(os.environ)
env.update(
    TMPDIR=str(tmp),
    CUDA_VISIBLE_DEVICES="",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    NUMEXPR_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    UV_NO_PROGRESS="1",
)
deadline = time.monotonic() + 180
resources = process.CycleResources(
    {
        "max_memory_bytes": record["child_max_B"],
        "host_ram_reserve": record["hostreserve_B"],
        "pause_file": str(OWN / "CANCEL"),
    },
    OWN,
    deadline,
)
outcome = None
try:
    with process.cancellation_signals(), lifecycle.lease(shared=True):
        returned = process.execute(
            sys.argv[2:],
            OWN / (name + ".log"),
            deadline,
            resources=resources,
            cwd=ROOT,
            env=env,
            cpu_plan=plan,
            cpu_scope="implementation",
            output_sink=lambda chunk: (sys.stdout.buffer.write(chunk), sys.stdout.flush()),
        )
        outcome = {"normal_return": True, "record": returned}
except BaseException as error:
    outcome = getattr(error, "cycle_cleanup_outcome", None)
    raise
finally:
    leftovers = list(tmp.iterdir())
    removed = []
    if outcome is not None and outcome["record"]["cleanup_complete"]:
        assert outcome["record"]["remaining"] == []
        for path in leftovers:
            assert not path.is_symlink()
            if path.name == "node-compile-cache" and path.is_dir():
                shutil.rmtree(path)
            elif path.name.startswith("uv-") and path.name.endswith(".lock") and path.is_file():
                path.unlink()
            else:
                raise RuntimeError(f"Unexpected owned TMP retained: {path}")
            removed.append(str(path))
        leftovers = list(tmp.iterdir())
    (OWN / (name + ".stop.json")).write_text(
        json.dumps(
            {
                "source_lease_returned": True,
                "TMP_remaining": [str(p) for p in leftovers],
                "reaped_command_TMP_removed": removed,
            }
        )
        + "\n"
    )
    if not leftovers:
        tmp.rmdir()
    if outcome is not None:
        outcome["controller_observed_RSS_B"] = process.process_info(os.getpid())["rss"]
        outcome["source_lease_returned"] = True
        (OWN / (name + ".return.json")).write_text(json.dumps(outcome, indent=2) + "\n")
