"""Collect bounded source STOP and one actual affected-storage observation."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

from quoridor_training import cycle_process as process

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/quoridor-rust-layout129"
frozen = json.loads((OWN / "frozen-files.json").read_text())
for item in frozen["patches"]:
    path = ROOT / item["path"]
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == item["sha256"]
    assert len(data) == item["bytes"]
for item in frozen["entries"]:
    path = ROOT / item["new"]
    assert hashlib.sha256(path.read_bytes()).hexdigest() == item["after"]["sha256"]

# The one exact common patch now reconstructs proposal bytes in memory; discard
# this generated intermediate containing duplicate full before/after source text.
intermediate = OWN / "common-proposal-content.json"
assert intermediate.is_relative_to(OWN)
intermediate.unlink(missing_ok=True)
receipts = []
removed_tmp = []
for path in sorted(OWN.glob("*.process.json")):
    if path.name == "final-source-STOP.process.json":
        continue
    record = json.loads(path.read_text())
    assert record["cleanup_complete"] and record["direct_child_reaped"], path
    assert record["remaining"] == [], path
    assert record["handle_closes_complete"], path
    assert record["signal_mask_restoration"] in {"pending", "completed"}, path
    assert record["finalization_errors"] == [], path
    assert not process.alive(record["child"]), path
    returned = json.loads(
        path.with_name(path.name.replace(".process.json", ".stop.json")).read_text()
    )
    assert returned["source_lease_returned"], path
    directory = OWN / "tmp" / path.name.removesuffix(".process.json")
    if directory.exists():
        for item in directory.iterdir():
            assert not item.is_symlink(), item
            if item.name == "node-compile-cache" and item.is_dir():
                shutil.rmtree(item)
            elif item.name.startswith("uv-") and item.name.endswith(".lock") and item.is_file():
                item.unlink()
            else:
                raise AssertionError(f"Unexpected owned TMP retained: {item}")
            removed_tmp.append(str(item.relative_to(ROOT)))
        directory.rmdir()
    receipts.append(
        {
            "path": str(path.relative_to(ROOT)),
            "status": record["status"],
            "child": record["child"],
            "direct_child_reaped": True,
            "remaining": [],
            "cleanup_complete": True,
            "handle_closes_complete": True,
            "source_lease_returned": True,
        }
    )
collector_tmp = Path(os.environ["TMPDIR"])
assert all(
    p.name.startswith("uv-") and p.name.endswith(".lock") and p.is_file()
    for p in collector_tmp.iterdir()
)
assert [p for p in (OWN / "tmp").iterdir() if p != collector_tmp] == []
affected = [
    "games/quoridor",
    ".artifacts/quoridor-rust-layout129",
    "apps/web/tsconfig.json",
    "apps/web/vite.config.ts",
    "apps/web/src/games/quoridor/test-support/rules-test-api.ts",
    "tests/e2e/phase1-rules.spec.ts",
    "tests/unit/worker-lifecycle.test.mjs",
    "tests/unit/quoridor-session-lifecycle.test.mjs",
]
observation = subprocess.check_output(
    ["du", "--summarize", "--block-size=1", "--", *affected], text=True
)
index = frozen["index_fingerprint_unchanged_during_diff_review_and_freeze"]
assert hashlib.sha256(Path(index["path"]).read_bytes()).hexdigest() == index["sha256"]
record = {
    "issue": frozen["issue"],
    "time_UTC": datetime.now(timezone.utc).isoformat(),
    "source_root": str(ROOT),
    "source_frozen_and_writer_STOP": True,
    "completed_receipts": receipts,
    "finalizer_qualification": "final-source-STOP.return.json is the subsequent existing execute() returned cleanup outcome for this collector, including removal of its owned TMP after direct reaping. Old persisted process receipts write signal-mask-restoration=pending before the final restoration; those fields are not silently upgraded. Their direct reaping/handles/remaining-process evidence is preserved. Notification/Beads helpers are control-plane processes and do not consume moved Rust/bridge source.",
    "reaped_command_TMP_removed_now": removed_tmp,
    "owned_TMP_remaining": [],
    "standing_source_leases_for_completed_commands": [],
    "source_patch_and_file_hashes_still_match": True,
    "index_unchanged": True,
    "single_actual_affected_storage_observation": {
        "method": "du --summarize --block-size=1",
        "output": observation,
        "scope": affected,
        "interpretation": "Ordinary moved source, supplied product inputs, frozen text patches, command logs and dedicated frontend bundle; no abnormal growth/capacity problem observed. SharedCargo/dependencies/assets untouched; no whole global usage claim.",
    },
    "generated_intermediate_duplicate_source_removed": str(intermediate.relative_to(ROOT)),
    "Cargo_and_scientific_execution": "UNRUN",
    "Root_acceptance_pending": True,
}
(OWN / "STOP.json").write_text(json.dumps(record, indent=2) + "\n")
summary = {
    "receipts": len(receipts),
    "owned_TMP_remaining": [],
    "source_hashes_match": True,
    "storage": observation,
}
print(json.dumps(summary, indent=2))
