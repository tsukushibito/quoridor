// Exercise the exact proposed current-scope export contract in memory.
import { execFileSync } from 'node:child_process';
import { registerHooks } from 'node:module';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const proposal = JSON.parse(
  execFileSync(
    'bash',
    [
      'scripts/dev/project-env.sh',
      'python',
      '-c',
      'import sys,json;sys.path.insert(0,".artifacts/quoridor-rust-layout129");from proposal import read_proposal;p=read_proposal();print(json.dumps({k:p[k] for k in ["scripts/export-fresh-source.mjs","tools/research-quality/test_export.mjs"]}))',
    ],
    { encoding: 'utf8' },
  ),
);
const sources = new Map(
  ['scripts/export-fresh-source.mjs', 'tools/research-quality/test_export.mjs'].map((name) => [
    pathToFileURL(resolve(name)).href,
    proposal[name].after,
  ]),
);
registerHooks({
  load(url, context, next) {
    const source = sources.get(url.split('?')[0]);
    if (source !== undefined) return { source, format: 'module', shortCircuit: true };
    return next(url, context);
  },
});
await import(pathToFileURL(resolve('tools/research-quality/test_export.mjs')).href);
