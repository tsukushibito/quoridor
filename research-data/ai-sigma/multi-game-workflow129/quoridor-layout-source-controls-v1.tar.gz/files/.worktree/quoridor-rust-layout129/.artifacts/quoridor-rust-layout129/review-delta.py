"""Review exact source deltas and keep the read-only task index fingerprint."""

import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/quoridor-rust-layout129"
original = json.loads((OWN / "original-files.json").read_text())
mapping = {"crates/": "games/quoridor/crates/", "packages/engine-bridge/": "games/quoridor/bridge/"}
parts = []
unchanged = []
changes = []
for old, record in original.items():
    prefix = next(prefix for prefix in mapping if old.startswith(prefix))
    new = mapping[prefix] + old[len(prefix) :]
    after = (ROOT / new).read_bytes()
    current = hashlib.sha256(after).hexdigest()
    assert not (ROOT / old).exists(), old
    if current == record["sha256"]:
        unchanged.append(new)
    else:
        before = subprocess.check_output(["git", "--no-optional-locks", "show", "HEAD:" + old])
        assert hashlib.sha256(before).hexdigest() == record["sha256"], old
        parts.extend(
            difflib.unified_diff(
                before.decode().splitlines(True),
                after.decode().splitlines(True),
                fromfile=old,
                tofile=new,
            )
        )
        changes.append(new)
    assert format((ROOT / new).stat().st_mode & 0o777, "04o") == record["mode"], new
(OWN / "relocation-content-delta.patch").write_text("".join(parts))
index = Path("/workspaces/quoridor/.git/worktrees/quoridor-rust-layout129/index")
(OWN / "index-readonly-fingerprint.json").write_text(
    json.dumps(
        {"path": str(index), "sha256": hashlib.sha256(index.read_bytes()).hexdigest()}, indent=2
    )
    + "\n"
)
print(
    json.dumps(
        {
            "relocated_files": len(original),
            "byte_identical": len(unchanged),
            "changed_moved_files": changes,
        },
        indent=2,
    )
)
print("".join(parts))
