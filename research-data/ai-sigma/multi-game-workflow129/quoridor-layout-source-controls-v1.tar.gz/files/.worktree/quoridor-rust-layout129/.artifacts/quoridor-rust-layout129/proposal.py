"""Reconstruct private proposal text in memory from the single reviewable patch."""

from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent


def read_proposal():
    result = {}
    lines = (OWN / "common-caller-proposal.patch").read_text().splitlines(keepends=True)
    index = 0
    while index < len(lines):
        header = re.fullmatch(r"diff --git a/(.+) b/(.+)\n", lines[index])
        assert header and header[1] == header[2], lines[index]
        name = header[1]
        before = subprocess.check_output(
            ["git", "--no-optional-locks", "-C", str(ROOT), "show", "HEAD:" + name],
            text=True,
        )
        original = before.splitlines(keepends=True)
        after = []
        cursor = 0
        index += 3
        while index < len(lines) and not lines[index].startswith("diff --git "):
            hunk = re.fullmatch(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n", lines[index])
            assert hunk, lines[index]
            start = int(hunk[1]) - 1
            after.extend(original[cursor:start])
            cursor = start
            index += 1
            while index < len(lines) and lines[index][:1] in {" ", "+", "-"}:
                line = lines[index]
                if line[0] in {" ", "-"}:
                    assert original[cursor] == line[1:], (name, cursor)
                    cursor += 1
                if line[0] in {" ", "+"}:
                    after.append(line[1:])
                index += 1
        after.extend(original[cursor:])
        result[name] = {"before": before, "after": "".join(after)}
    return result
