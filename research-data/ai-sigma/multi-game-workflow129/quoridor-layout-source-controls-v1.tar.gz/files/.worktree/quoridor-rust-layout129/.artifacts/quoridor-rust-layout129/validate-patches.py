"""Apply frozen unified hunks in memory against task HEAD; never stage or write source."""

import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/quoridor-rust-layout129"
lines = (OWN / "full.patch").read_text().splitlines(keepends=True)
index = 0
counts = {"deleted": 0, "added": 0, "modified": 0}
while index < len(lines):
    header = re.fullmatch(r"diff --git a/(.+) b/(.+)\n", lines[index])
    assert header, lines[index]
    index += 1
    while not lines[index].startswith("--- "):
        index += 1
    old = lines[index][4:].rstrip("\n")
    new = lines[index + 1][4:].rstrip("\n")
    assert lines[index + 1].startswith("+++ ")
    index += 2
    before = (
        []
        if old == "/dev/null"
        else subprocess.check_output(
            ["git", "--no-optional-locks", "show", "HEAD:" + old[2:]],
            text=True,
        ).splitlines(keepends=True)
    )
    result = []
    cursor = 0
    while index < len(lines) and not lines[index].startswith("diff --git "):
        hunk = re.fullmatch(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n", lines[index])
        assert hunk, lines[index]
        start = max(0, int(hunk[1]) - 1)
        result.extend(before[cursor:start])
        cursor = start
        index += 1
        old_count = new_count = 0
        while index < len(lines) and lines[index][:1] in {" ", "+", "-"}:
            line = lines[index]
            if line[0] in {" ", "-"}:
                assert before[cursor] == line[1:], (old, cursor)
                cursor += 1
                old_count += 1
            if line[0] in {" ", "+"}:
                result.append(line[1:])
                new_count += 1
            index += 1
        assert old_count == int(hunk[2] or 1), (old, hunk[0])
        assert new_count == int(hunk[4] or 1), (new, hunk[0])
    result.extend(before[cursor:])
    after = "".join(result)
    if new == "/dev/null":
        assert not after
        assert not (ROOT / old[2:]).exists()
        counts["deleted"] += 1
    else:
        assert (ROOT / new[2:]).read_text() == after, new
        assert "/bridge/wasm/" not in new
        counts["added" if old == "/dev/null" else "modified"] += 1
assert counts == {"deleted": 197, "added": 197, "modified": 6}, counts
fingerprint = json.loads((OWN / "index-readonly-fingerprint.json").read_text())
assert hashlib.sha256(Path(fingerprint["path"]).read_bytes()).hexdigest() == fingerprint["sha256"]
(OWN / "patch-validation.json").write_text(
    json.dumps(
        {
            "counts": counts,
            "all_hunks_match_task_HEAD_and_working_files": True,
            "index_unchanged": True,
        },
        indent=2,
    )
    + "\n"
)
print(json.dumps(counts))
