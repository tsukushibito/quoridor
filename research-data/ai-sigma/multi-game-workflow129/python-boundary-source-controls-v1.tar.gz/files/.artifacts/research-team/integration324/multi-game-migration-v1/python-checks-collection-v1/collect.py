"""Collect passed subchecks and separately clean the owned late tool cache."""

import datetime
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def main():
    spec = importlib.util.spec_from_file_location(
        "lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lc)
    original = BASE / "python-entrychecks-v2/result.json"
    source = json.loads(original.read_bytes())
    assert source["status"] == "FAILED" and source["failure"]["type"] == "AssertionError"
    assert len(source["commands"]) == 12
    processes = []
    for row in source["commands"]:
        lc.settled(row["record"])
        assert row["record"]["handle_closes_complete"]
        expected = row["record"]["child"]
        fresh = lc.process.identity(lc.process.process_info(expected["pid"]))
        assert fresh != lc.process.identity(expected)
        processes.append(dict(expected=expected, fresh=fresh))
    temporary = BASE / "python-entrychecks-v2/TMP"
    files = list(temporary.iterdir())
    assert {p.name for p in files} == {"uv-cc8f3ad7aa19080a.lock", "node-compile-cache"}
    lock = temporary / "uv-cc8f3ad7aa19080a.lock"
    assert lock.is_file() and not lock.is_symlink() and lock.stat().st_size == 0
    cache = temporary / "node-compile-cache"
    assert cache.is_dir() and not cache.is_symlink()
    for p in cache.rglob("*"):
        assert not p.is_symlink()
    lock.unlink()
    shutil.rmtree(cache)
    temporary.rmdir()
    doc = ROOT / "docs/design/multi-game-repository.md"
    text = doc.read_text()
    old = "Othelloは未実装として表示し、ルートのゲーム固有コード配置とOthello機能は後続工程で段階適用する。"
    new = "QuoridorのRust／bridge・Python・presetは `games/quoridor` へ分離した。Othelloは未実装として表示し、残るゲーム固有テスト・文書の配置とOthello機能は後続工程で段階適用する。"
    assert text.count(old) == 1
    text = text.replace(old, new)
    start = text.index("最初のPython境界では ")
    end = text.index("\n", start)
    text = (
        text[:start]
        + "`scripts/dev/project-env.sh` 自身の所属checkoutを `QUORIDOR_CODE_ROOT` とし、その `games/quoridor/python` と `shared/python` を `PYTHONPATH` に束縛する。共有runtimeは実際に共通運用が使う `quoridor_runtime.cycle_process` と `quoridor_runtime.snapshot` だけで、ゲームの学習package名は `quoridor_training` を保つ。cwdだけの変更やMain入口の呼出しをWorktree側の検証と扱わない。`PYTHONSAFEPATH=1` でcwd・スクリプト所在からの暗黙importを抑え、選択先sourceの欠落時は停止してMainへfallbackしない。Main入口はMainコードを選ぶ。`QUORIDOR_PROJECT_ROOT` はMainの依存metadata・共通配置という既存の意味を維持し、Mainのmanifest/lockと一つの既設環境をoffline/no-syncで消費する。明示setupのwriter lock、別環境・別Pythonの拒否、source時のtool pathと明示TensorRT bindingsを維持する。新しいmanaged sparse checkoutには同じgame/shared sourceと `scripts/dev` を含める。利用手順と実Worktree sentinel/importの限定検証は[共通Python環境](../development/rust-python-environment.md)を参照する。共有環境の再導入・依存版やlockの変更、旧保護Worktreeの一括更新は行わず、モデル・教師・探索方式をこの構成変更から拡張しない。"
        + text[end:]
    )
    doc.write_text(text)
    pretty = str(ROOT / "tools/research-quality/node_modules/.bin/prettier")
    for mode in ["--write", "--check"]:
        subprocess.run(
            [pretty, "--config", "tools/research-quality/.prettierrc.json", mode, str(doc)],
            cwd=ROOT,
            check=True,
            timeout=90,
        )
    result = dict(
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        status="PASS_ACTUAL_ENTRY_AND_AFFECTED_CLIPPY_WITH_SEPARATE_LATE_TMP_CLEANUP",
        original_failed_housekeeping_result=str(original),
        original_failure_preserved=True,
        actual_passed_commands=source["commands"],
        known_commands_absent_or_different=processes,
        cleanup="Only owned zero-byte uv lock and Node compile cache after actual directwait/reap/handles; no shared/foreign cache or failed scientific TMP touched.",
        TMP=[],
        source_leases=[],
        no_old_success_replay=True,
        science_or_model_calls=0,
        qualification="Main5 PASS/1 explicit WT-only skip; actual WT sentinel/import1, sparse fixture1, caller membership1, synthetic no-sync source-layout1, metadata verifier, changed-source format/lint, affected Runner/Data all-target Clippy warnings0. Clippy also supplies compile/type validation; no duplicate cargo check or Cargo test/native execution.",
    )
    (OUT / "completion-and-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(dict(status=result["status"], passed_commands=12, replayed_commands=0)))


if __name__ == "__main__":
    main()
