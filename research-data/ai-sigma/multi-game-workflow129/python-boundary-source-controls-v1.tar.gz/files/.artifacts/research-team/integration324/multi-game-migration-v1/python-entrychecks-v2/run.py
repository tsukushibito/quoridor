"""Exercise actual integrated game/shared entry boundaries and affected compilers."""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus, execute

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
WT = ROOT / ".worktree/quoridor-python-layout129"
OWN = WT / ".artifacts/python-layout129"


def main():
    plan = CPUPlan.from_record(
        dict(
            management=[18],
            commands={"check": [0]},
            allocation=[0, 18],
            resource_CPUs=2,
            worker_CPUs=1,
            library_threads=1,
        )
    )
    plan.check_host(available_cpus())
    plan.apply()
    spec = importlib.util.spec_from_file_location(
        "lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lc)
    assert lc.process.process_info(os.getpid())["rss"] < 64 * 1024**2
    identity = json.loads((OWN / "source-identity.json").read_bytes())
    before = json.loads((OWN / "proposal-before.json").read_bytes())
    authored = (
        {r["new"] for r in identity["files"] if not r["identical"]}
        | set(before)
        | {"shared/python/quoridor_runtime/__init__.py"}
    )
    py = sorted(n for n in authored if n.endswith(".py"))
    md = sorted(n for n in authored if n.endswith(".md"))
    rust = sorted(n for n in authored if n.endswith(".rs"))
    provided = json.loads(
        (OUT.parent / "python-entrychecks-v1/Root-provided-task-entry.json").read_bytes()
    )
    for row in provided:
        assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["after_sha256"]
    env = dict(
        os.environ,
        CUDA_VISIBLE_DEVICES="",
        PYTHONDONTWRITEBYTECODE="1",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
        RAYON_NUM_THREADS="1",
        QUORIDOR_PROJECT_ENV_TEST_OUTPUT=str(OUT / "entry-output"),
    )
    commands = [
        (
            "Ruff-format",
            [
                "bash",
                "scripts/dev/project-env.sh",
                "ruff",
                "format",
                "--check",
                "--config",
                "tools/research-quality/ruff.toml",
                *py,
            ],
            1,
        ),
        (
            "Ruff-lint",
            [
                "bash",
                "scripts/dev/project-env.sh",
                "ruff",
                "check",
                "--no-cache",
                "--config",
                "tools/research-quality/ruff.toml",
                *py,
            ],
            1,
        ),
        (
            "Markdown",
            [
                str(ROOT / "tools/research-quality/node_modules/.bin/prettier"),
                "--config",
                "tools/research-quality/.prettierrc.json",
                "--check",
                *md,
            ],
            1,
        ),
        (
            "Rustfmt",
            [
                "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt",
                "--edition",
                "2024",
                "--config",
                "skip_children=true",
                "--check",
                *rust,
            ],
            1,
        ),
        (
            "shell-syntax",
            [
                "bash",
                "-n",
                "scripts/dev/project-env.sh",
                "scripts/dev/manage_worktree.sh",
                "scripts/dev/setup-project.sh",
            ],
            1,
        ),
        (
            "Main-actual-entry",
            [
                sys.executable,
                "-B",
                "-m",
                "unittest",
                "discover",
                "-s",
                "scripts/dev",
                "-p",
                "test_project_env.py",
                "-v",
            ],
            1,
        ),
        (
            "task-actual-entry",
            [
                "bash",
                str(WT / "scripts/dev/project-env.sh"),
                "python",
                "-B",
                "-m",
                "unittest",
                "discover",
                "-s",
                str(WT / "scripts/dev"),
                "-p",
                "test_project_env.py",
                "-k",
                "test_actual_worktree_sentinel_and_import_file",
                "-v",
            ],
            1,
        ),
        (
            "managed-sparse-boundary",
            [
                sys.executable,
                "-B",
                "-m",
                "unittest",
                "discover",
                "-s",
                "scripts/dev",
                "-p",
                "test_manage_worktree.py",
                "-k",
                "test_sparse_creation_from_linked_checkout",
                "-v",
            ],
            1,
        ),
        (
            "actual-caller-membership",
            [
                sys.executable,
                "-B",
                "-m",
                "unittest",
                "discover",
                "-s",
                "scripts/dev",
                "-p",
                "test_research_lifecycle.py",
                "-k",
                "test_measurement_and_callback_arena_caller_membership",
                "-v",
            ],
            1,
        ),
        (
            "synthetic-entry-layout",
            [
                sys.executable,
                "-B",
                "-m",
                "unittest",
                "discover",
                "-s",
                "tools/research-session",
                "-p",
                "test_project_environment.py",
                "-k",
                "test_main_worktree_arbitrary_cwd_no_sync_and_argument_boundary",
                "-v",
            ],
            1,
        ),
        (
            "metadata-verifier",
            [
                sys.executable,
                "-B",
                "scripts/dev/verify-python-environment.py",
                "--output",
                str(OUT / "environment.json"),
            ],
            1,
        ),
        (
            "affected-runner-data-Clippy",
            [
                "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo",
                "clippy",
                "--locked",
                "--offline",
                "--release",
                "-j1",
                "--message-format=json-render-diagnostics",
                "-p",
                "quoridor-runner",
                "-p",
                "quoridor-data",
                "--all-targets",
                "--features",
                "quoridor-runner/measurement,quoridor-inference/claustrophobia",
                "--no-deps",
                "--",
                "-Dwarnings",
            ],
            4,
        ),
    ]
    prior = json.loads((OUT.parent / "layout-software-v1/build-intent-release.json").read_bytes())
    env.update({k: v for k, v in prior["env"].items() if k not in {"TMPDIR", "PATH"}})
    env["PYTHONPATH"] = os.pathsep.join(
        str(ROOT / p) for p in ["games/quoridor/python", "shared/python"]
    )
    env["PYTHONSAFEPATH"] = "1"
    temporary = OUT / "TMP"
    temporary.mkdir()
    env["TMPDIR"] = str(temporary)
    rows = []
    failure = None
    try:
        with lc.lease():
            for name, argv, family in commands:
                deadline = time.monotonic() + (900 if family == 4 else 180)
                resources = CycleResources(
                    dict(
                        max_memory_bytes=family * 1024**3 - 64 * 1024**2,
                        host_ram_reserve=4 * 1024**3,
                    ),
                    OUT,
                    deadline,
                )
                record = execute(
                    argv,
                    OUT / (name + ".log"),
                    deadline,
                    resources=resources,
                    cpu_plan=plan,
                    cpu_scope="check",
                    cwd=ROOT,
                    env=env,
                )
                lc.settled(record)
                assert record["handle_closes_complete"]
                if family == 4:
                    assert (
                        lc.cargo_report((OUT / (name + ".log")).read_bytes())["warning_count"] == 0
                    )
                rows.append(dict(name=name, argv=argv, record=record))
        assert not list(temporary.iterdir())
        temporary.rmdir()
    except BaseException as error:
        failure = dict(type=type(error).__name__, message=str(error))
        raise
    finally:
        (OUT / "result.json").write_text(
            json.dumps(
                dict(
                    status="PASS" if failure is None else "FAILED",
                    commands=rows,
                    failure=failure,
                    supplied_actual_task_entry=provided,
                    source_leases=[],
                    scientific_calls=0,
                    host_future_quiet=False,
                ),
                indent=2,
            )
            + "\n"
        )
    print(
        json.dumps(
            dict(status="PASS", commands=[r["name"] for r in rows], actual_Cargo_tests_executed=0)
        )
    )


if __name__ == "__main__":
    main()
