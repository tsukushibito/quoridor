"""Apply frozen game/shared Python layout and exact common callers together."""

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/quoridor-python-layout129/.artifacts/python-layout129"


def run(args):
    p = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, timeout=120)
    assert p.returncode == 0, p.stdout + p.stderr
    return p.stdout


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not run(["git", "status", "--porcelain=v1"])
    base = run(["git", "rev-parse", "HEAD"]).strip()
    assert base == "3a9e8b31f1d2983c583bafc39ab072bd24165f81"
    identity = json.loads((OWN / "source-identity.json").read_bytes())
    before = json.loads((OWN / "proposal-before.json").read_bytes())
    for name, content in before.items():
        assert (ROOT / name).read_text() == content, name
    for row in identity["files"]:
        assert sha(ROOT / row["old"]) == row["original_sha256"], row["old"]
    patches = [OWN / "source-migration.patch", OWN / "common-caller-proposal.patch"]
    assert [sha(p) for p in patches] == [
        "27036550a7c87129508a91d7999abd4af0cefe201b1c67bf0b0de7533b93f32d",
        "fbd1572bcb0ef815ecfaa4d403e3a21bc0c7023ded8b524f80c03567dd6e22ac",
    ]
    for patch in patches:
        run(["git", "apply", "--check", str(patch)])
    for patch in patches:
        run(["git", "apply", str(patch)])
    for row in identity["files"]:
        p = ROOT / row["new"]
        assert sha(p) == row["current_sha256"]
        assert (p.stat().st_mode & 0o777) == int(row["current_mode"], 8)
        if row["old"] != row["new"]:
            assert not (ROOT / row["old"]).exists()
    retired = []
    for name in [
        "tools/research-session/stopped_generation_publisher_v2.py",
        "tools/research-session/fixtures/stopped-caller-interface-v2.json",
    ]:
        p = ROOT / name
        assert run(["git", "ls-files", "--", name]).strip() == name
        retired.append(
            dict(path=name, bytes=p.stat().st_size, sha256=sha(p), restore=f"{base}:{name}")
        )
        p.unlink()
    for name in [
        "python/quoridor_training/research355",
        "python/quoridor_training",
        "configs/arena",
        "configs",
    ]:
        p = ROOT / name
        if p.exists() and not list(p.iterdir()):
            p.rmdir()
    run(["git", "diff", "--check"])
    dirty = [
        r[3:]
        for r in run(["git", "status", "--porcelain=v1", "--untracked-files=all"]).splitlines()
    ]
    result = dict(
        base=base,
        worker_identity=identity,
        exact_common_paths=list(before),
        applied_patches=[dict(path=str(p), sha256=sha(p), bytes=p.stat().st_size) for p in patches],
        retired_unreferenced_comparison_fixtures=retired,
        current_caller_search="No filename references in maintained scripts/tools/tests/game/Web sources; original stopped comparison purpose ended. Historical source refs/evidence unchanged.",
        dirty_paths=dirty,
        no_index_commit_push=True,
        source_and_numeric_value_changes=False,
        qualification="Source composition only; actual integrated entry and Rust checks follow. No old module alias or Main fallback.",
    )
    (OUT / "composition.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            dict(
                applied=True,
                source_rows=len(identity["files"]),
                common_paths=len(before),
                dirty_paths=len(dirty),
            )
        )
    )


if __name__ == "__main__":
    main()
