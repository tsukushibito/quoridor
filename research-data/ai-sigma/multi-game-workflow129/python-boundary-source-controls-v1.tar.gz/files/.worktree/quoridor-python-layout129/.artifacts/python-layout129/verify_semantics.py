"""Compare relocated Python ASTs after the explicitly allowed import/path substitutions."""

import ast
import json
from pathlib import Path

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/python-layout129"
original = json.loads((OWN / "source-before.json").read_text())


class WithoutImports(ast.NodeTransformer):
    def visit_Import(self, node):
        return None

    def visit_ImportFrom(self, node):
        return None


checked = []
for old, before in original.items():
    if not old.endswith(".py"):
        continue
    tail = old.removeprefix("python/quoridor_training/")
    base = (
        "shared/python/quoridor_runtime/"
        if tail in ("cycle_process.py", "snapshot.py")
        else "games/quoridor/python/quoridor_training/"
    )
    path = ROOT / (base + tail)
    before = before.replace(
        "from quoridor_training.cycle_process import ",
        "from quoridor_runtime.cycle_process import ",
    )
    before = before.replace(
        "from quoridor_training import cycle_process", "from quoridor_runtime import cycle_process"
    )
    before = before.replace(
        "quoridor_training.snapshot.os.replace", "quoridor_runtime.snapshot.os.replace"
    )
    if tail == "test_lifecycle.py":
        before = before.replace(
            'node.module == "snapshot"', 'node.module == "quoridor_runtime.snapshot"'
        )
    if tail == "static_teacher_heads.py":
        before = before.replace(
            'parents[2] / "tools/model-export/folded_sigma.py"',
            'parents[4] / "tools/model-export/folded_sigma.py"',
        )
    if tail in (
        "research355/test_lifecycle_index355.py",
        "research355/test_lifecycle_arena355.py",
        "research355/test_lifecycle_repair355.py",
    ):
        before = before.replace("parents[3]", "parents[5]")
    expected = WithoutImports().visit(ast.parse(before))
    actual = WithoutImports().visit(ast.parse(path.read_text()))
    assert ast.dump(expected) == ast.dump(actual), old
    checked.append(str(path.relative_to(ROOT)))
print(
    json.dumps(
        dict(
            python_files=len(checked),
            non_import_ast_unchanged_except_declared_paths=True,
            models_and_numerical_definitions_unchanged=True,
        )
    )
)
