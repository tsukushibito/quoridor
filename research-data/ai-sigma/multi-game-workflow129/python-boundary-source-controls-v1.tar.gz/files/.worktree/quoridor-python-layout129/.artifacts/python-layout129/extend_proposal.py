import json
from pathlib import Path

root = Path.cwd()
own = root / ".artifacts/python-layout129"
proposal = own / "proposal"
before = json.loads((own / "proposal-before.json").read_text())


def propose(relative, transform):
    source = root / relative
    if not source.exists():
        source = Path("/workspaces/quoridor") / relative
    text = source.read_text()
    updated = transform(text)
    assert updated != text, relative
    before[relative] = text
    path = proposal / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(updated)


def paths(text):
    text = text.replace(
        "python/quoridor_training/cycle_process.py",
        "shared/python/quoridor_runtime/cycle_process.py",
    ).replace("python/quoridor_training/snapshot.py", "shared/python/quoridor_runtime/snapshot.py")
    return text.replace("python/quoridor_training/", "games/quoridor/python/quoridor_training/")


def current_refs(text):
    text = paths(text)
    lines = text.splitlines(keepends=True)
    result = []
    for line in lines:
        if "shared/python/quoridor_runtime/cycle_process.py" in line:
            result.append(line.replace("cycle_process.py", "__init__.py"))
        result.append(line)
    return "".join(result)


for name in (
    "tools/research-session/test_lifecycle.py",
    "tools/research-session/test_runtime_provenance.py",
    "python/tests/test_claustrophobia_publisher.py",
):
    propose(
        name,
        lambda t: current_refs(t)
        .replace("import quoridor_training", "import quoridor_runtime")
        .replace("quoridor_training.__path__", "quoridor_runtime.__path__"),
    )
propose(
    "tools/research-session/test_lifecycle_storage.py",
    lambda t: t.replace("import quoridor_training", "import quoridor_runtime").replace(
        "quoridor_training.__path__", "quoridor_runtime.__path__"
    ),
)
for name in (
    "tools/research-session/test_observed_cohort_coverage.py",
    "tools/research-session/test_perf_launch_policy.py",
):
    propose(
        name,
        lambda t: paths(t)
        .replace(
            '"quoridor_training.cohort_coverage_process"',
            '"quoridor_runtime.cohort_coverage_process"',
        )
        .replace(
            '"quoridor_training.perf_policy_subject"', '"quoridor_runtime.perf_policy_subject"'
        ),
    )
propose("tools/research-session/test_claustrophobia_publication.py", paths)
for name in (
    "tools/research-session/test_arena_plan.py",
    "tools/research-session/test_selected_abnormal_contract.py",
):
    propose(
        name,
        lambda t: t.replace('str(ROOT / "python")', 'str(ROOT / "shared/python")').replace(
            'str(MAIN / "python")', 'str(SOURCE.resolve().parents[2] / "shared/python")'
        ),
    )


def abnormal(text):
    text = text.replace(
        'str(MAIN / "python")', 'str(SOURCE.resolve().parents[2] / "shared/python")'
    )
    text = text.replace(
        "sys.path.insert(0,'/workspaces/quoridor/python')",
        "sys.path.insert(0,os.environ['QUORIDOR_CODE_ROOT']+'/shared/python')",
    )
    text = text.replace(
        "import json,pathlib,sys,subprocess,time,hashlib",
        "import json,pathlib,sys,subprocess,time,hashlib,os",
    )
    return text.replace(
        "from quoridor_training import cycle_process", "from quoridor_runtime import cycle_process"
    )


propose("tools/research-session/test_lifecycle_abnormal_exit.py", abnormal)
propose(
    "python/tests/test_public_static_prepare.py",
    lambda t: t.replace("quoridor_training.snapshot", "quoridor_runtime.snapshot"),
)
for name in (
    "python/tests/test_claustrophobia_file_request.py",
    "python/tests/test_claustrophobia_arena.py",
    "python/tests/test_static_config_settings.py",
):
    propose(
        name,
        lambda t: t.replace(
            "from quoridor_training import cycle_process",
            "from quoridor_runtime import cycle_process",
        ).replace(
            'Path(__file__).resolve().parents[1] / "quoridor_training/',
            'Path(__file__).resolve().parents[2] / "games/quoridor/python/quoridor_training/',
        ),
    )


def environment_fixture(t):
    t = t.replace(
        'executable(binary / "git", \'#!/bin/sh\\nprintf "%s\\\\n" "$FAKE_MAIN/.git"\\n\')',
        'executable(\n            binary / "git",\n            \'#!/bin/sh\\ncase "$*" in *--show-toplevel*) printf "%s\\\\n" "$FAKE_MAIN";; \'\n            \'*--git-common-dir*) printf "%s\\\\n" "$FAKE_MAIN/.git";; *) exit 2;; esac\\n\',\n        )',
    )
    t = t.replace(
        '        binary = root / "tools"',
        '        for relative in (\n            "games/quoridor/python/quoridor_training/__init__.py",\n            "shared/python/quoridor_runtime/__init__.py",\n            "shared/python/quoridor_runtime/cycle_process.py",\n            "shared/python/quoridor_runtime/snapshot.py",\n        ):\n            source = project / relative\n            source.parent.mkdir(parents=True, exist_ok=True)\n            source.write_text("# synthetic source marker\\n")\n        binary = root / "tools"',
    )
    t = t.replace(
        'str(project / "python")', 'f"{project}/games/quoridor/python:{project}/shared/python"'
    )
    return t.replace(
        "f\"{bindings}:{project / 'python'}\"",
        'f"{bindings}:{project}/games/quoridor/python:{project}/shared/python"',
    )


propose("tools/research-session/test_project_environment.py", environment_fixture)
propose(
    "docs/development/rust-python-environment.md",
    lambda t: t.replace(
        "`PYTHONPATH` はそのcheckoutの `python` 一つへ置き換え",
        "`PYTHONPATH` はそのcheckoutの `games/quoridor/python` と `shared/python` だけへ置き換え",
    )
    .replace("選択先の `python` が欠落", "選択先のgame package又はshared runtimeの実sourceが欠落")
    .replace("この `python` 以下からimport", "このgame/shared source以下からimport"),
)
propose(
    "docs/development/ai-research-code.md",
    lambda t: t.replace(
        "`python/quoridor_training`", "`games/quoridor/python/quoridor_training`"
    ).replace(
        "`configs/arena/distance-control-*`", "`games/quoridor/configs/arena/distance-control-*`"
    ),
)
propose(
    "docs/development/rust-ai.md",
    lambda t: t.replace(
        "../../configs/arena/README.md", "../../games/quoridor/configs/arena/README.md"
    )
    .replace("`python/quoridor_training`", "`games/quoridor/python/quoridor_training`")
    .replace(
        "`configs/arena/best51-book-preparation.json`",
        "`games/quoridor/configs/arena/best51-book-preparation.json`",
    ),
)
propose(
    "games/quoridor/crates/README.md",
    lambda t: t.replace(
        "../../../python/quoridor_training/README.md", "../python/quoridor_training/README.md"
    ),
)
propose(
    "games/quoridor/crates/quoridor-data/README.md",
    lambda t: t.replace(
        "../../../../python/quoridor_training/README.md", "../../python/quoridor_training/README.md"
    ),
)
p = proposal / "scripts/dev/test_project_env.py"
t = (
    p.read_text()
    .replace(
        'main_package = ROOT / "shared/python/quoridor_runtime"',
        'main_package = MAIN / "shared/python/quoridor_runtime"',
    )
    .replace("selected worktree/python", "selected game/shared source")
    .replace(
        'env["PYTHONPATH"] = str(MAIN / "games/quoridor/python")',
        'env["PYTHONPATH"] = f"{MAIN}/games/quoridor/python:{MAIN}/shared/python"',
    )
)
p.write_text(t)
(own / "proposal-before.json").write_text(json.dumps(before))
print(
    json.dumps(
        {
            "proposal_files": sorted(before),
            "files_from_main_not_in_sparse": [p for p in before if not (root / p).exists()],
        }
    )
)
