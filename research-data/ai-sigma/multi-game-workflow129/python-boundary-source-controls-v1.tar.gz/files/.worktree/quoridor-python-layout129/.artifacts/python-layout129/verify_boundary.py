"""Fresh source-boundary checks using owned sentinels and stdlib children only."""

import importlib.abc
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

from quoridor_runtime import cycle_process as process

ROOT = Path("/workspaces/quoridor/.worktree/quoridor-python-layout129")
MAIN = Path("/workspaces/quoridor")
OWN = ROOT / ".artifacts/python-layout129"
ENTRY = OWN / "proposal/scripts/dev/project-env.sh"


def run(*arguments, cwd=MAIN, extra=None):
    environment = dict(os.environ)
    environment.pop("PYTHONSAFEPATH", None)
    environment.pop("QUORIDOR_TENSORRT_ROOT", None)
    environment.update(
        PYTHONPATH=f"{MAIN}/python:{MAIN}/games/quoridor/python:{MAIN}/shared/python",
        QUORIDOR_CODE_ROOT=str(MAIN),
    )
    environment.update(extra or {})
    return subprocess.run(
        ["bash", str(ENTRY), *arguments],
        cwd=cwd,
        env=environment,
        text=True,
        capture_output=True,
        timeout=20,
    )


def okay(result):
    assert result.returncode == 0, (result.returncode, result.stdout, result.stderr)
    return result.stdout


name = "_layout129_" + uuid.uuid4().hex
game = ROOT / "games/quoridor/python" / (name + "_game.py")
shared = ROOT / "shared/python" / (name + "_shared.py")
try:
    game.write_text('TOKEN = "game"\n')
    shared.write_text('TOKEN = "shared"\n')
    code = (
        f"import {name}_game as game, {name}_shared as shared; "
        "import quoridor_training, quoridor_runtime, os, sys, json; "
        "from quoridor_runtime import cycle_process, snapshot; "
        'assert not any(k in sys.modules for k in ("torch","numpy","onnx","onnxruntime")); '
        "print(json.dumps(dict(game=game.__file__, shared=shared.__file__, "
        "training=quoridor_training.__file__, runtime=quoridor_runtime.__file__, "
        "process=cycle_process.__file__, snapshot=snapshot.__file__, "
        'path=os.environ["PYTHONPATH"], safe=sys.flags.safe_path, '
        'metadata=os.environ["QUORIDOR_PROJECT_ROOT"], code=os.environ["QUORIDOR_CODE_ROOT"], '
        "environment=sys.prefix)))"
    )
    report = json.loads(okay(run("python", "-B", "-c", code)))
    expected = dict(
        game=game,
        shared=shared,
        training=ROOT / "games/quoridor/python/quoridor_training/__init__.py",
        runtime=ROOT / "shared/python/quoridor_runtime/__init__.py",
        process=ROOT / "shared/python/quoridor_runtime/cycle_process.py",
        snapshot=ROOT / "shared/python/quoridor_runtime/snapshot.py",
    )
    for key, value in expected.items():
        assert Path(report[key]) == value, (key, report)
    assert report["path"] == f"{ROOT}/games/quoridor/python:{ROOT}/shared/python"
    assert report["safe"] and report["metadata"] == str(MAIN) and report["code"] == str(ROOT)
    assert report["environment"] == sys.prefix
    (OWN / "actual-imports.json").write_text(json.dumps(report, indent=2) + "\n")
finally:
    game.unlink(missing_ok=True)
    shared.unlink(missing_ok=True)

for module in ("quoridor_training.cycle_process", "quoridor_training.snapshot", "snapshot"):
    result = run(
        "python", "-B", "-c", "import " + module, cwd=ROOT / "shared/python/quoridor_runtime"
    )
    assert result.returncode != 0 and "ModuleNotFoundError" in result.stderr, result
for command in ("python3", "/usr/bin/python3"):
    result = run(command, "-c", 'raise AssertionError("foreign executed")')
    assert result.returncode == 2 and "foreign interpreters are refused" in result.stderr, result
result = run("python", extra={"QUORIDOR_PROJECT_ENV": "/foreign/env"})
assert result.returncode == 2 and "per-caller environments are refused" in result.stderr
for path in ("relative", str(OWN / "missing-tensorrt")):
    result = run("python", extra={"QUORIDOR_TENSORRT_ROOT": path})
    assert result.returncode == 2 and "backend Python bindings are missing" in result.stderr
missing = ROOT / "shared/python/quoridor_runtime/__init__.py"
hidden = OWN / "runtime-init-held"
missing.rename(hidden)
try:
    result = run("python", "-c", 'raise AssertionError("missing source executed")')
    assert result.returncode == 2 and "no Main fallback" in result.stderr, result
finally:
    hidden.rename(missing)

# The moved implementation is unchanged; only exercise its new import boundary.
plan_record = json.loads(
    Path(
        "/workspaces/quoridor/.artifacts/research-team/integration324/multi-game-migration-v1/layout-followup-v1/python-cpu-plan.json"
    ).read_text()
)
plan = process.CPUPlan.from_record(plan_record["cpu_plan"])
resources = process.CycleResources(
    dict(
        max_memory_bytes=plan_record["child_max_B"], host_ram_reserve=plan_record["hostreserve_B"]
    ),
    OWN,
    time.monotonic() + 10,
)
child = process.execute(
    [
        sys.executable,
        "-B",
        "-c",
        'import os; assert os.sched_getaffinity(0)=={12}; print("stdlib-child")',
    ],
    OWN / "boundary-child.log",
    resources.deadline,
    resources=resources,
    cpu_plan=plan,
    cpu_scope="implementation",
)
assert child["cleanup_complete"] and child["direct_child_reaped"] and not child["remaining"]
stop = process.CycleResources(
    dict(
        max_memory_bytes=plan_record["child_max_B"], host_ram_reserve=plan_record["hostreserve_B"]
    ),
    OWN,
    time.monotonic() + 0.2,
)
try:
    process.execute(
        [sys.executable, "-B", "-c", "import time; time.sleep(10)"],
        OWN / "cancel-child.log",
        stop.deadline,
        resources=stop,
        cpu_plan=plan,
        cpu_scope="implementation",
    )
except process.CycleStopped as error:
    assert "deadline" in str(error)
else:
    raise AssertionError("deadline cancellation did not fire")
cancelled = json.loads((OWN / "cancel-child.process.json").read_text())
assert (
    cancelled["cleanup_complete"]
    and cancelled["direct_child_reaped"]
    and not cancelled["remaining"]
)

# Reuse one existing stdlib AST test of caller membership; no snapshot/science suite replay.
spec = importlib.util.spec_from_file_location(
    "layout_lifecycle", ROOT / "games/quoridor/python/quoridor_training/test_lifecycle.py"
)
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
tests.LifecycleTests(
    "test_cycle_and_public_progress_use_the_same_owned_snapshot_writer"
).run().wasSuccessful() or sys.exit(1)
print(
    json.dumps(
        dict(
            selected_checkout=True,
            sentinel_pair=True,
            old_modules_refused=True,
            foreign_environment_refused=True,
            missing_source_refused=True,
            stdlib_child_cleanup=True,
            deadline_cancel_cleanup=True,
            science_imports=0,
        )
    )
)
