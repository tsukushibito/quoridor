"""New proposal boundary checks; no lifecycle execution, Git writes or science."""

import ast
import importlib.util
import json
import os
from pathlib import Path
import sys
import unittest

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/python-layout129"
PROPOSAL = OWN / "proposal"

spec = importlib.util.spec_from_file_location(
    "new_environment_fixture", PROPOSAL / "tools/research-session/test_project_environment.py"
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.ENTRY = PROPOSAL / "scripts/dev/project-env.sh"
module.TMP = OWN
suite = unittest.TestSuite(
    [
        module.CommonEnvironmentTests(
            "test_main_worktree_arbitrary_cwd_no_sync_and_argument_boundary"
        )
    ]
)
assert unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful()

# The proposed current caller list must resolve real relocated files, not old modules.
path = PROPOSAL / "scripts/dev/research-lifecycle.py"
tree = ast.parse(path.read_text())
selected = [
    n
    for n in tree.body
    if isinstance(n, ast.FunctionDef)
    and n.name in ("caller_source_refs", "common_training_environment")
    or isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == "FIT_IMPORTS" for t in n.targets)
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


env = dict(
    ROOT=ROOT,
    Path=Path,
    os=os,
    require=require,
    document=lambda value: value,
    project_python=lambda: Path(sys.executable),
)
exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), "exec"), env)
base = [
    ROOT / p
    for p in (
        "scripts/dev/research-lifecycle.py",
        "scripts/dev/research-job.py",
        "shared/python/quoridor_runtime/__init__.py",
        "shared/python/quoridor_runtime/cycle_process.py",
        "shared/python/quoridor_runtime/snapshot.py",
    )
]
for phase, files, config in (
    ("compare", base, {}),
    (
        "fit",
        base
        + [
            ROOT / "games/quoridor/python/quoridor_training" / (p + ".py")
            for p in env["FIT_IMPORTS"]
        ],
        {"experiment": {"study": "fixture"}},
    ),
):
    refs = [dict(path=str(p)) for p in files]
    assert (
        env["caller_source_refs"](
            dict(caller_sources=refs), dict(phase=phase, config=config, argv=["fixture", "measure"])
        )
        == refs
    )
    assert all(p.is_file() for p in files)
    try:
        env["caller_source_refs"](
            dict(caller_sources=refs[:-1]),
            dict(phase=phase, config=config, argv=["fixture", "measure"]),
        )
    except ValueError:
        pass
    else:
        raise AssertionError("missing current source accepted")
current = dict(
    cwd=str(ROOT),
    env=dict(
        PYTHONDONTWRITEBYTECODE="1",
        PYTHONSAFEPATH="1",
        PYTHONPATH=f"{ROOT}/games/quoridor/python:{ROOT}/shared/python",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
    ),
)
env["common_training_environment"](current)
current["env"]["PYTHONPATH"] = str(ROOT / "python")
try:
    env["common_training_environment"](current)
except ValueError:
    pass
else:
    raise AssertionError("legacy training source path accepted")

# Resolve literal includes without compiling or running Rust code.
checked = []
for source in (ROOT / "games/quoridor/crates").rglob("*.rs"):
    text = source.read_text()
    import re

    for relative in re.findall(r'include_str!\("([^\"]*configs/[^\"]+)"\)', text):
        target = (source.parent / relative).resolve()
        assert target.is_file() and target.is_relative_to(ROOT / "games/quoridor/configs"), target
        checked.append(
            dict(caller=str(source.relative_to(ROOT)), target=str(target.relative_to(ROOT)))
        )
print(
    json.dumps(
        dict(
            synthetic_environment_no_sync=True,
            current_source_membership=True,
            legacy_path_refused=True,
            rust_includes=checked,
        )
    )
)
