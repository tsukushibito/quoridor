import json
from pathlib import Path

root = Path.cwd()
own = root / ".artifacts/python-layout129"
original = {}
for directory in ("python/quoridor_training", "configs"):
    for path in sorted((root / directory).rglob("*")):
        if path.is_file():
            assert path.suffix in (".py", ".md", ".json"), path
            original[str(path.relative_to(root))] = path.read_text()
for path in (root / "games/quoridor").rglob("*.rs"):
    text = path.read_text()
    if (
        "../../../../../configs/" in text
        or 'repo.join("python")' in text
        or '.join("../../../../python")' in text
    ):
        original[str(path.relative_to(root))] = text
(own / "source-before.json").write_text(json.dumps(original))
package = root / "games/quoridor/python/quoridor_training"
package.parent.mkdir(parents=True, exist_ok=True)
(root / "python/quoridor_training").rename(package)
(root / "configs").rename(root / "games/quoridor/configs")
shared = root / "shared/python/quoridor_runtime"
shared.mkdir(parents=True)
(shared / "__init__.py").write_text(
    '"""Shared stdlib process ownership and atomic snapshot publication."""\n'
)
for name in ("cycle_process.py", "snapshot.py"):
    (package / name).rename(shared / name)
changed = []
for path in package.rglob("*.py"):
    before = path.read_text()
    after = before.replace(
        "from .cycle_process import ", "from quoridor_runtime.cycle_process import "
    ).replace("from .snapshot import ", "from quoridor_runtime.snapshot import ")
    after = after.replace(
        "from . import cycle_process as processes",
        "from quoridor_runtime import cycle_process as processes",
    )
    after = after.replace(
        "from . import cache, cycle_process, train",
        "from quoridor_runtime import cycle_process\n\nfrom . import cache, train",
    )
    after = (
        after.replace(
            "from quoridor_training.cycle_process import ",
            "from quoridor_runtime.cycle_process import ",
        )
        .replace(
            "from quoridor_training import cycle_process",
            "from quoridor_runtime import cycle_process",
        )
        .replace("quoridor_training.snapshot.os.replace", "quoridor_runtime.snapshot.os.replace")
    )
    if path.name == "static_teacher_heads.py":
        after = after.replace(
            'Path(__file__).resolve().parents[2] / "tools/model-export/folded_sigma.py"',
            'Path(__file__).resolve().parents[4] / "tools/model-export/folded_sigma.py"',
        )
    if after != before:
        path.write_text(after)
        changed.append(str(path.relative_to(root)))
for relative, before in original.items():
    if not relative.endswith(".rs"):
        continue
    after = before.replace("../../../../../configs/", "../../../configs/")
    after = after.replace(
        '.env("PYTHONPATH", repo.join("python"))',
        '.env(\n                    "PYTHONPATH",\n                    std::env::join_paths([\n                        repo.join("games/quoridor/python"),\n                        repo.join("shared/python"),\n                    ])?,\n                )\n                .env("PYTHONSAFEPATH", "1")',
    )
    after = after.replace(
        'Path::new(env!("CARGO_MANIFEST_DIR"))\n                .join("../../../../python")\n                .canonicalize()\n                .unwrap(),',
        'std::env::join_paths([\n                Path::new(env!("CARGO_MANIFEST_DIR"))\n                    .join("../../python")\n                    .canonicalize()\n                    .unwrap(),\n                Path::new(env!("CARGO_MANIFEST_DIR"))\n                    .join("../../../../shared/python")\n                    .canonicalize()\n                    .unwrap(),\n            ])\n            .unwrap(),',
    )
    if relative.endswith("terminal_stream.rs"):
        after = after.replace(
            '        .env("OMP_NUM_THREADS", "1")',
            '        .env("PYTHONSAFEPATH", "1")\n        .env("OMP_NUM_THREADS", "1")',
        )
    (root / relative).write_text(after)
    changed.append(relative)
(own / "content-changed.json").write_text(json.dumps(changed, indent=2) + "\n")
print(
    json.dumps(
        {
            "moved_source_files": len([p for p in original if not p.endswith(".rs")]),
            "content_changed": changed,
        }
    )
)
