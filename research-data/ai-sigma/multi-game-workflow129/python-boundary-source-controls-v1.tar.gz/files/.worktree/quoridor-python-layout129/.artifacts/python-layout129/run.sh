#!/usr/bin/env bash
set -euo pipefail
layout_root=/workspaces/quoridor/.worktree/quoridor-python-layout129
layout_env=/home/vscode/.cache/inference/envs/quoridor-training
export QUORIDOR_CODE_ROOT="$layout_root"
export QUORIDOR_PROJECT_ROOT=/workspaces/quoridor
export QUORIDOR_PROJECT_ENV="$layout_env"
export PYTHONPATH="$layout_root/games/quoridor/python:$layout_root/shared/python"
export PYTHONSAFEPATH=1 PYTHONDONTWRITEBYTECODE=1
exec flock --shared --nonblock "$layout_env.setup.lock" "$layout_env/bin/python" -B "$layout_root/.artifacts/python-layout129/guard.py" "$@"
