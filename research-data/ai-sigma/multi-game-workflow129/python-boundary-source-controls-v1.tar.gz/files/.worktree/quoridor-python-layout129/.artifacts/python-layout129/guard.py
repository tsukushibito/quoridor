import hashlib
import json
import os
from pathlib import Path
import sys
import time

from quoridor_runtime.cycle_process import CPUPlan, CycleResources, available_cpus, execute

root = Path("/workspaces/quoridor/.worktree/quoridor-python-layout129")
own = root / ".artifacts/python-layout129"
path = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/multi-game-migration-v1/layout-followup-v1/python-cpu-plan.json"
)
data = path.read_bytes()
assert len(data) == 513 and path.stat().st_mode & 0o777 == 0o644
assert (
    hashlib.sha256(data).hexdigest()
    == "5b20d122f050f8a31043443765c54fc16f44a1674102dc0ee9b904ae3c925a45"
)
record = json.loads(data)
plan = CPUPlan.from_record(record["cpu_plan"])
assert plan.record() == record["cpu_plan"]
plan.check_host(available_cpus())
plan.apply()
env = dict(os.environ)
for key in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "RAYON_NUM_THREADS",
    "TORCH_NUM_THREADS",
):
    env[key] = "1"
env["CUDA_VISIBLE_DEVICES"] = ""
resources = CycleResources(
    dict(max_memory_bytes=record["family_B"], host_ram_reserve=record["hostreserve_B"]),
    own,
    time.monotonic() + 180,
)
result = execute(
    sys.argv[2:],
    own / (sys.argv[1] + ".log"),
    resources.deadline,
    resources=resources,
    cwd=root,
    env=env,
    cpu_plan=plan,
    cpu_scope="implementation",
)
print(json.dumps(result))
