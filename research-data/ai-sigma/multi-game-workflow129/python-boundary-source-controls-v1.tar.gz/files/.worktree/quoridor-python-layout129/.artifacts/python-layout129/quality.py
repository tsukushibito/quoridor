"""Check only changed code and parse relocated source without importing it."""

import ast
import json
from pathlib import Path
import subprocess

root = Path.cwd()
own = root / ".artifacts/python-layout129"
changed = json.loads((own / "content-changed.json").read_text())
py = [p for p in changed if p.endswith(".py")]
py += [str(p) for p in Path("shared/python").rglob("*.py")]
py += [str(p) for p in (own / "proposal").rglob("*.py")]
py += [str(p) for p in own.glob("*.py")]
ruff = "/home/vscode/.cache/inference/envs/quoridor-training/bin/ruff"
subprocess.run([ruff, "format", "--config", "tools/research-quality/ruff.toml", *py], check=True)
subprocess.run(
    [ruff, "format", "--check", "--config", "tools/research-quality/ruff.toml", *py], check=True
)
subprocess.run([ruff, "check", "--config", "tools/research-quality/ruff.toml", *py], check=True)
for path in [
    *Path("games/quoridor/python").rglob("*.py"),
    *Path("shared/python").rglob("*.py"),
    *(own / "proposal").rglob("*.py"),
]:
    ast.parse(path.read_text(), filename=str(path))
for path in Path("games/quoridor/configs").rglob("*.json"):
    json.loads(path.read_text())
for path in [*(own / "proposal").rglob("*.sh"), own / "run.sh"]:
    subprocess.run(["bash", "-n", str(path)], check=True)
rust = [p for p in changed if p.endswith(".rs")]
subprocess.run(
    ["rustfmt", "--edition", "2024", "--config", "skip_children=true", "--check", *rust], check=True
)
docs = [str(p) for p in (own / "proposal").rglob("*.md")]
docs += ["games/quoridor/configs/arena/README.md"]
subprocess.run(
    [
        "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier",
        "--ignore-path",
        "/dev/null",
        "--config",
        "/workspaces/quoridor/tools/research-quality/.prettierrc.json",
        "--check",
        *docs,
    ],
    check=True,
)
print(
    json.dumps(
        dict(
            ruff100_changed_files=len(py),
            ast_parser=True,
            config_json_parser=True,
            shell_syntax=True,
            rustfmt2024=True,
            prettier=True,
        )
    )
)
