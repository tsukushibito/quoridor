import json
from pathlib import Path

root = Path.cwd()
own = root / ".artifacts/python-layout129"
proposal = own / "proposal"
before = {}


def propose(relative, transform):
    source = root / relative
    text = source.read_text()
    updated = transform(text)
    assert updated != text, relative
    before[relative] = text
    path = proposal / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(updated)


pair = 'os.pathsep.join(str(ROOT / p) for p in ("games/quoridor/python", "shared/python"))'


def env(text):
    return text.replace(
        '[[ -d "$QUORIDOR_CODE_ROOT/python" ]]',
        '[[ -f "$QUORIDOR_CODE_ROOT/games/quoridor/python/quoridor_training/__init__.py" && \\\n     -f "$QUORIDOR_CODE_ROOT/shared/python/quoridor_runtime/__init__.py" && \\\n     -f "$QUORIDOR_CODE_ROOT/shared/python/quoridor_runtime/cycle_process.py" && \\\n     -f "$QUORIDOR_CODE_ROOT/shared/python/quoridor_runtime/snapshot.py" ]]',
    ).replace(
        'export PYTHONPATH="$QUORIDOR_CODE_ROOT/python"',
        'export PYTHONPATH="$QUORIDOR_CODE_ROOT/games/quoridor/python:$QUORIDOR_CODE_ROOT/shared/python"',
    )


propose("scripts/dev/project-env.sh", env)
propose(
    "scripts/dev/setup-project.sh",
    lambda t: t.replace(
        'PYTHONPATH="$QUORIDOR_PROJECT_ROOT/python"',
        'PYTHONSAFEPATH=1 PYTHONPATH="$QUORIDOR_CODE_ROOT/games/quoridor/python:$QUORIDOR_CODE_ROOT/shared/python"',
    ),
)
propose(
    "scripts/dev/manage_worktree.sh",
    lambda t: t.replace(
        '--sparse-index -- "${@:5}"',
        '--sparse-index -- "${@:5}" scripts/dev games/quoridor/python shared/python',
    ),
)
propose(
    "scripts/dev/test_manage_worktree.py",
    lambda t: t.replace(
        'self.run_git("add", "scripts/dev/manage_worktree.sh", ".gitignore")',
        'for directory in ("games/quoridor/python", "shared/python"):\n            source = self.root / directory / "sentinel.py"\n            source.parent.mkdir(parents=True)\n            source.write_text("TOKEN = \'fixture\'\\n")\n        self.run_git("add", "scripts/dev/manage_worktree.sh", ".gitignore", "games", "shared")',
    ).replace(
        'self.helper("verify", checkout=sparse)',
        'self.assertTrue((sparse / "games/quoridor/python/sentinel.py").is_file())\n        self.assertTrue((sparse / "shared/python/sentinel.py").is_file())\n        self.helper("verify", checkout=sparse)',
    ),
)


def lifecycle(t):
    t = t.replace(
        'sys.path.insert(0, str(ROOT / "python"))',
        'sys.path[:0] = [str(ROOT / "games/quoridor/python"), str(ROOT / "shared/python")]',
    ).replace(
        "from quoridor_training import cycle_process", "from quoridor_runtime import cycle_process"
    )
    t = t.replace(
        "python/quoridor_training/cycle_process.py",
        "shared/python/quoridor_runtime/cycle_process.py",
    ).replace("python/quoridor_training/snapshot.py", "shared/python/quoridor_runtime/snapshot.py")
    t = t.replace("python/quoridor_training", "games/quoridor/python/quoridor_training")
    t = t.replace('    "snapshot",\n    "cycle_process",\n', "")
    t = t.replace(
        'spec["env"].get("PYTHONPATH") == str(ROOT / "python")',
        'spec["env"].get("PYTHONPATH") == '
        + pair
        + '\n        and spec["env"].get("PYTHONSAFEPATH") == "1"',
    )
    return t


propose("scripts/dev/research-lifecycle.py", lifecycle)
propose(
    "scripts/dev/test_research_lifecycle.py",
    lambda t: t.replace(
        "python/quoridor_training/cycle_process.py",
        "shared/python/quoridor_runtime/cycle_process.py",
    )
    .replace("python/quoridor_training/snapshot.py", "shared/python/quoridor_runtime/snapshot.py")
    .replace(
        "python/quoridor_training/claustrophobia.py",
        "games/quoridor/python/quoridor_training/claustrophobia.py",
    )
    .replace(
        "python/quoridor_training/static_teacher_heads.py",
        "games/quoridor/python/quoridor_training/static_teacher_heads.py",
    ),
)
propose(
    "scripts/dev/test_research_cpu_plan.py",
    lambda t: t.replace(
        'sys.path.insert(0, str(ROOT / "python"))',
        'sys.path.insert(0, str(ROOT / "shared/python"))',
    ).replace(
        "from quoridor_training import cycle_process", "from quoridor_runtime import cycle_process"
    ),
)
propose(
    "scripts/dev/check-research.py",
    lambda t: t.replace(
        '"python/quoridor_training"',
        '"games/quoridor/python/quoridor_training", "shared/python/quoridor_runtime"',
        1,
    )
    .replace("python/quoridor_training", "games/quoridor/python/quoridor_training")
    .replace("games/quoridor/games/quoridor/", "games/quoridor/")
    .replace(
        '"PYTHONPATH": str(ROOT / "python"),',
        '"PYTHONPATH": ' + pair + ',\n                "PYTHONSAFEPATH": "1",',
    ),
)
propose(
    "README.md",
    lambda t: t.replace(
        "`python/quoridor_training/`", "`games/quoridor/python/quoridor_training/`"
    ),
)


# Preserve all historical fixture paths; update only the current environment boundary test.
def env_tests(t):
    t = t.replace('MAIN / "python"', 'MAIN / "games/quoridor/python"').replace(
        'ROOT / "python"', 'ROOT / "games/quoridor/python"'
    )
    t = t.replace("python/quoridor_training", "games/quoridor/python/quoridor_training").replace(
        'ROOT / "python/snapshot.py"', 'ROOT / "games/quoridor/python/snapshot.py"'
    )
    t = t.replace(
        'f"{backend}/python:{ROOT}/python"',
        'f"{backend}/python:{ROOT}/games/quoridor/python:{ROOT}/shared/python"',
    )
    # Main entry is qualified only after integration, not against its old layout here.
    t = t.replace(
        '"package=quoridor_training.__file__, code=',
        '"runtime=quoridor_runtime.__file__, process=process.__file__, snapshot=snapshot.__file__, "\n                "package=quoridor_training.__file__, code=',
    )
    t = t.replace(
        'f"import {name} as sentinel, quoridor_training, json, os, sys; "',
        'f"import {name} as sentinel, quoridor_training, quoridor_runtime, json, os, sys; "\n                "from quoridor_runtime import cycle_process as process, snapshot; "',
    )
    t = t.replace(
        'self.assertEqual(Path(report["code"]), ROOT)',
        'self.assertEqual(Path(report["runtime"]), ROOT / "shared/python/quoridor_runtime/__init__.py")\n            self.assertEqual(Path(report["process"]), ROOT / "shared/python/quoridor_runtime/cycle_process.py")\n            self.assertEqual(Path(report["snapshot"]), ROOT / "shared/python/quoridor_runtime/snapshot.py")\n            self.assertEqual(Path(report["code"]), ROOT)',
    )
    t = t.replace(
        'main_package = MAIN / "games/quoridor/python/quoridor_training"',
        'main_package = ROOT / "shared/python/quoridor_runtime"',
    )
    return t


propose("scripts/dev/test_project_env.py", env_tests)
(own / "proposal-before.json").write_text(json.dumps(before))
print(json.dumps({"proposal_files": sorted(before)}))
