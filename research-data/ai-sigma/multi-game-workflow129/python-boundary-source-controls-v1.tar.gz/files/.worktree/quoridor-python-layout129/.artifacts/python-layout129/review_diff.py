import difflib
import json
from pathlib import Path

root = Path.cwd()
own = root / ".artifacts/python-layout129"
old = json.loads((own / "source-before.json").read_text())
for name, before in old.items():
    if name.startswith("python/quoridor_training/"):
        tail = name.removeprefix("python/quoridor_training/")
        after_name = (
            "shared/python/quoridor_runtime/"
            if tail in ("cycle_process.py", "snapshot.py")
            else "games/quoridor/python/quoridor_training/"
        ) + tail
    elif name.startswith("configs/"):
        after_name = "games/quoridor/" + name
    else:
        after_name = name
    after = (root / after_name).read_text()
    if after != before:
        diff = list(
            difflib.unified_diff(
                before.splitlines(), after.splitlines(), fromfile=name, tofile=after_name, n=2
            )
        )
        print("\n".join(diff))
for name, before in json.loads((own / "proposal-before.json").read_text()).items():
    after = (own / "proposal" / name).read_text()
    print(
        "\n".join(
            difflib.unified_diff(
                before.splitlines(), after.splitlines(), fromfile=name, tofile=name, n=2
            )
        )
    )
