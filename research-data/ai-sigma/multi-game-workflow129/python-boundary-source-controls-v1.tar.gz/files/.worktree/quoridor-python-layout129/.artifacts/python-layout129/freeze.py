"""Freeze path-only source movement, content evidence and one common caller proposal."""

import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
OWN = ROOT / ".artifacts/python-layout129"
original = json.loads((OWN / "source-before.json").read_text())
proposal = json.loads((OWN / "proposal-before.json").read_text())


def moved(name):
    if name.startswith("python/quoridor_training/"):
        tail = name.removeprefix("python/quoridor_training/")
        base = (
            "shared/python/quoridor_runtime/"
            if tail in ("cycle_process.py", "snapshot.py")
            else "games/quoridor/python/quoridor_training/"
        )
        return base + tail
    return "games/quoridor/" + name if name.startswith("configs/") else name


def patch(old, new, before, after):
    if before == after and old == new:
        return ""
    result = f"diff --git a/{old} b/{new}\n"
    if old != new:
        similarity = int(
            100 * difflib.SequenceMatcher(None, before.splitlines(), after.splitlines()).ratio()
        )
        result += f"similarity index {similarity}%\nrename from {old}\nrename to {new}\n"
    if before != after:
        result += "".join(
            difflib.unified_diff(
                before.splitlines(keepends=True),
                after.splitlines(keepends=True),
                fromfile="a/" + old,
                tofile="b/" + new,
            )
        )
    return result


source_patch = ""
identities = []
for old, before in sorted(original.items()):
    new = moved(old)
    after = (ROOT / new).read_text()
    source_patch += patch(old, new, before, after)
    identities.append(
        dict(
            old=old,
            new=new,
            original_sha256=hashlib.sha256(before.encode()).hexdigest(),
            current_sha256=hashlib.sha256(after.encode()).hexdigest(),
            current_mode=format((ROOT / new).stat().st_mode & 0o7777, "04o"),
            original_bytes=len(before.encode()),
            current_bytes=len(after.encode()),
            identical=before == after,
        )
    )
new = "shared/python/quoridor_runtime/__init__.py"
after = (ROOT / new).read_text()
source_patch += f"diff --git a/{new} b/{new}\nnew file mode 100644\n"
source_patch += "".join(
    difflib.unified_diff(
        [], after.splitlines(keepends=True), fromfile="/dev/null", tofile="b/" + new
    )
)
common_patch = ""
for name, before in sorted(proposal.items()):
    assert (ROOT / name).read_text() == before, ("Root-owned actual path changed", name)
    common_patch += patch(name, name, before, (OWN / "proposal" / name).read_text())
assert not (ROOT / "python/quoridor_training").exists()
assert not (ROOT / "configs").exists()
assert (
    original["python/quoridor_training/snapshot.py"].encode()
    == (ROOT / "shared/python/quoridor_runtime/snapshot.py").read_bytes()
)
assert ast.dump(ast.parse(original["python/quoridor_training/cycle_process.py"])) == ast.dump(
    ast.parse((ROOT / "shared/python/quoridor_runtime/cycle_process.py").read_text())
)
manifest = dict(
    moved_files=sum(p["old"] != p["new"] for p in identities),
    byte_identical_moved_files=sum(p["old"] != p["new"] and p["identical"] for p in identities),
    snapshot_original_bytes=True,
    cycle_process_ast_identical=True,
    root_actual_unchanged=True,
    files=identities,
)
(OWN / "source-identity.json").write_text(json.dumps(manifest, indent=2) + "\n")
(OWN / "source-migration.patch").write_text(source_patch)
(OWN / "common-caller-proposal.patch").write_text(common_patch)
for name in ("source-identity.json", "source-migration.patch", "common-caller-proposal.patch"):
    path = OWN / name
    path.chmod(0o444)
    print(
        json.dumps(
            dict(
                path=str(path),
                sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                bytes=path.stat().st_size,
                mode="0444",
            )
        )
    )
print(json.dumps({key: value for key, value in manifest.items() if key != "files"}))
