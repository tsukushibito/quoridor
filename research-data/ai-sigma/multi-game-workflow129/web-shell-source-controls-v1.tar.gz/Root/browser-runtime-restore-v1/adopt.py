"""Restore only the exact temporary browser config after actual browser/collector STOP."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/web-game-shell129/.artifacts/web-game-shell129"


def main():
    install = json.loads((BASE / "browser-runtime-config-v1/installed.json").read_bytes())
    process = json.loads((OWN / "browser-render-final.process.json").read_bytes())
    stop = json.loads((OWN / "browser-whole-stop.json").read_bytes())
    assert process["exit_code"] == 0 and process["status"] == "complete"
    assert process["direct_child_reaped"] and process["cleanup_complete"]
    assert process["handle_closes_complete"] and not process["remaining"]
    target = Path(install["path"])
    assert install["original"] == "ABSENT"
    assert target.is_file() and not target.is_symlink()
    raw = target.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == install["sha256"]
    assert len(raw) == install["bytes"] and target.stat().st_mode & 0o777 == 0o644
    target.unlink()
    assert not target.exists()
    result = dict(
        at=datetime.now(timezone.utc).isoformat(),
        original_absence_restored=True,
        path=str(target),
        removed_exact_sha256=install["sha256"],
        actual_browser_collector_STOP=stop,
        final_returned_process=process,
        shared_browser_executable_libraries_unchanged=True,
        earlier_failures_or_config_records_not_restamped=True,
        no_future_quiet_or_scientific_success_claim=True,
    )
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(dict(original_absence_restored=True, path=str(target))))


if __name__ == "__main__":
    main()
