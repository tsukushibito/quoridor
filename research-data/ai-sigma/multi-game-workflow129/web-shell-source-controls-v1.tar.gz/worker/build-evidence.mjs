import { build } from 'vite';
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const checkout = '/workspaces/quoridor/.worktree/web-game-shell129';
const output = resolve(checkout, '.artifacts/web-game-shell129');
await build({
  root: resolve(checkout, 'apps/web'),
  configFile: resolve(checkout, 'apps/web/vite.config.ts'),
  build: { outDir: resolve(output, 'dist-root'), manifest: true },
  plugins: [{
    name: 'record-task-source-evidence',
    generateBundle(_options, bundle) {
      const chunks = Object.values(bundle).filter(item => item.type === 'chunk');
      const bridge = [...new Set(chunks.flatMap(chunk => Object.keys(chunk.modules)).filter(id => id.includes('/packages/engine-bridge/')))];
      if (!bridge.length || bridge.some(id => !id.startsWith(checkout + '/packages/engine-bridge/'))) throw new Error('Bridge source escaped task checkout');
      const entry = chunks.find(chunk => chunk.isEntry);
      const entryModules = Object.keys(entry.modules);
      if (entryModules.some(id => id.includes('/games/quoridor/') || id.includes('/engine-bridge/') || id.includes('/three/'))) throw new Error('Game modules included in eager entry');
      writeFileSync(resolve(output, 'bundle-source-evidence.json'), JSON.stringify({ checkout, bridge, entry: entry.fileName, entryModules, imports: entry.imports, dynamicImports: entry.dynamicImports }, null, 2) + '\n');
    },
  }],
});
