import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import stat
import time

ROOT = Path("/workspaces/quoridor/.worktree/web-game-shell129")
sys.path.insert(0, str(ROOT / "python"))
from quoridor_training.cycle_process import CPUPlan, CycleResources, execute, process_info  # noqa: E402

record_path = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/multi-game-migration-v1/web-entry-v1/cpu-plan.json"
)
data = record_path.read_bytes()
assert len(data) == 494 and stat.S_IMODE(record_path.stat().st_mode) == 0o644
assert (
    hashlib.sha256(data).hexdigest()
    == "13b109af84fb435291323d525c8a6a7a2c630e0e31ab49ddb5fd08063e795d86"
)
record = json.loads(data)
plan = CPUPlan.from_record(record["cpu_plan"])
plan.apply()
output = ROOT / ".artifacts/web-game-shell129"
name = sys.argv[1]
tmp = output / (name + "-tmp")
tmp.mkdir()
deadline = time.monotonic() + 240
resources = CycleResources(
    {
        "max_memory_bytes": record["child_max_B"],
        "host_ram_reserve": record["hostreserve_B"],
        "pause_file": str(output / "CANCEL"),
    },
    output,
    deadline,
)
env = dict(
    os.environ,
    TMPDIR=str(tmp),
    TEMP=str(tmp),
    TMP=str(tmp),
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    CUDA_VISIBLE_DEVICES="",
    PYTHONDONTWRITEBYTECODE="1",
)
try:
    assert process_info(os.getpid())["rss"] <= record["controller_B"]
    result = execute(
        sys.argv[2:],
        output / (name + ".log"),
        deadline,
        resources=resources,
        cwd=ROOT,
        env=env,
        cpu_plan=plan,
        cpu_scope="implementation",
    )
    assert process_info(os.getpid())["rss"] <= record["controller_B"]
    print({"status": result["status"], "process_record": str(output / (name + ".process.json"))})
finally:
    shutil.rmtree(tmp)
