# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: web-shell.spec.ts >> home stays lazy, existing slot resumes, game teardown and base-path history work
- Location: tests/e2e/web-shell.spec.ts:26:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('#choose-quoridor')
Expected: visible
Timeout: 20000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('#choose-quoridor') with timeout 20000ms
  - waiting for locator('#choose-quoridor')

```

```yaml
- main:
  - heading "先手・丸い駒の手番" [level=1]
  - text: 0 手目
  - paragraph: 2人で対戦
  - text: ●
  - strong: 先手・丸い駒
  - text: 残りの壁 10 枚 ⬡
  - strong: 後手・六角の駒
  - text: 残りの壁 10 枚
  - navigation "対局":
    - button "すべての音を消す"
    - link "ゲーム一覧":
      - /url: "#/"
    - button "やり直す"
    - button "新しい対局"
    - button "遊び方"
    - button "設定・保存"
  - text: 9 × 9
  - paragraph: 光るマスをクリックして移動。矢印キーとEnterでも操作できます。
  - button "駒を動かす" [pressed]
  - button "壁を置く"
  - 'button "壁の向き: 横向き R"'
  - button "1手戻す" [disabled]
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | 
  3   | async function ready(page: Page): Promise<void> {
  4   |   await expect
  5   |     .poll(() => page.evaluate(() => window.__QUORIDOR_DIAGNOSTICS__?.phase))
  6   |     .toBe('ready');
  7   | }
  8   | async function home(page: Page): Promise<void> {
  9   |   await page.locator('.top-actions .home-link').click();
> 10  |   await expect(page.locator('#choose-quoridor')).toBeVisible();
      |                                                  ^ Error: expect(locator).toBeVisible() failed
  11  | }
  12  | 
  13  | test('home loads no game resources and honestly lists unavailable Othello', async ({ page }) => {
  14  |   const requests: string[] = [];
  15  |   page.on('request', (request) => requests.push(request.url()));
  16  |   await page.goto('./?forceWebGL=1');
  17  |   await expect(page.locator('#choose-quoridor')).toBeVisible();
  18  |   await expect(page.getByRole('button', { name: '準備中' })).toBeDisabled();
  19  |   expect(requests.some((url) => /wasm|quoridor-|ai.worker|three|\.hdr|\.mp3|\.ogg/.test(url))).toBe(
  20  |     false,
  21  |   );
  22  |   expect(await page.evaluate(() => window.__QUORIDOR_DIAGNOSTICS__)).toBeUndefined();
  23  |   await page.screenshot({ path: test.info().outputPath('home.png') });
  24  | });
  25  | 
  26  | test('home stays lazy, existing slot resumes, game teardown and base-path history work', async ({
  27  |   page,
  28  | }) => {
  29  |   const requests: string[] = [];
  30  |   page.on('request', (request) => requests.push(request.url()));
  31  |   await page.goto('./?forceWebGL=1');
  32  |   await expect(page.locator('#choose-quoridor')).toBeVisible();
  33  |   await expect(page.getByRole('button', { name: '準備中' })).toBeDisabled();
  34  |   expect(requests.some((url) => /wasm|quoridor-title|\.hdr|\.mp3|\.ogg/.test(url))).toBe(false);
  35  |   expect(await page.evaluate(() => window.__QUORIDOR_DIAGNOSTICS__)).toBeUndefined();
  36  |   const homeStyle = await page
  37  |     .locator('.home-page')
  38  |     .evaluate((element) => ({
  39  |       font: getComputedStyle(element).fontFamily,
  40  |       position: getComputedStyle(element).position,
  41  |     }));
  42  |   await page.locator('#choose-quoridor').click();
  43  |   await ready(page);
  44  |   await page.locator('#startup-new-game').click();
  45  |   await page.locator('#dialog-start').click();
  46  |   await expect
  47  |     .poll(() => page.evaluate(() => window.__QUORIDOR_APP_TEST_API__?.state().phase))
  48  |     .toBe('humanTurn');
  49  |   const before = await page.evaluate(() => {
  50  |     const api = window.__QUORIDOR_APP_TEST_API__!;
  51  |     // Keep these exact old instance handles to observe disposal after navigation.
  52  |     (window as any).oldGame = api;
  53  |     return api.exportReplay();
  54  |   });
  55  |   await home(page);
  56  |   expect(await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__)).toBeUndefined();
  57  |   expect(await page.evaluate(() => (window as any).oldGame.state().phase)).toBe('disposed');
  58  |   expect(await page.evaluate(() => (window as any).oldGame.audio().status)).toBe('disposed');
  59  |   await expect(page.locator('canvas, dialog')).toHaveCount(0);
  60  |   expect(
  61  |     await page
  62  |       .locator('.home-page')
  63  |       .evaluate((element) => ({
  64  |         font: getComputedStyle(element).fontFamily,
  65  |         position: getComputedStyle(element).position,
  66  |       })),
  67  |   ).toEqual(homeStyle);
  68  |   expect(await page.evaluate(() => localStorage.getItem('quoridor.m1.game.v1'))).toBeTruthy();
  69  |   await page.goBack();
  70  |   await ready(page);
  71  |   await page.locator('#resume-game-choice').click();
  72  |   await expect
  73  |     .poll(() => page.evaluate(() => window.__QUORIDOR_APP_TEST_API__?.state().phase))
  74  |     .toBe('humanTurn');
  75  |   expect(await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.exportReplay())).toEqual(
  76  |     before,
  77  |   );
  78  |   await page.goForward();
  79  |   await expect(page.locator('#choose-quoridor')).toBeVisible();
  80  |   await page.goto('./?forceWebGL=1#/quoridor');
  81  |   await ready(page);
  82  |   await expect(page.locator('#resume-game-choice')).toBeVisible();
  83  |   expect(new URL(page.url()).pathname).toBe('/shell-check/');
  84  |   await page.locator('#resume-game-choice').click();
  85  |   expect(await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.exportReplay())).toEqual(
  86  |     before,
  87  |   );
  88  | });
  89  | 
  90  | test('leaving a pending game import cannot mount or report stale failure', async ({ page }) => {
  91  |   let release!: () => void;
  92  |   const gate = new Promise<void>((resolve) => {
  93  |     release = resolve;
  94  |   });
  95  |   let requested!: () => void;
  96  |   const reached = new Promise<void>((resolve) => {
  97  |     requested = resolve;
  98  |   });
  99  |   await page.route('**/assets/*.js', async (route) => {
  100 |     // The home entry is the only eager script. Hold the selected game chunk.
  101 |     if (route.request().url().includes('/assets/index-')) return route.continue();
  102 |     requested();
  103 |     await gate;
  104 |     await route.continue();
  105 |   });
  106 |   await page.goto('./?forceWebGL=1');
  107 |   await page.locator('#choose-quoridor').click();
  108 |   await reached;
  109 |   await page.locator('.app-loading a').click();
  110 |   await expect(page.locator('#choose-quoridor')).toBeVisible();
```