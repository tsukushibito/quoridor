from pathlib import Path
import subprocess
import json
import hashlib

out = Path(".artifacts/web-game-shell129")
issue = "quoridor-4lc.324.12.9.2"
owner = "codex:01a15e6e-ba7c-7691-b57e-6f57546ec7f2"
assert not (out / "one-normal-own-close.stdout").exists()
reason_path = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/multi-game-migration-v1/web-close-dispatch-v1/exact-close-reason.txt"
)
lines = reason_path.read_text(encoding="utf-8").splitlines()
assert len(lines) == 1 and lines[0]
reason = lines[0]
before = json.loads((out / "close-before-show.log").read_text())
before = before[0] if isinstance(before, list) else before
assert before["id"] == issue and before["status"] == "in_progress" and before["assignee"] == owner
receipt = []


def beads(name, *args):
    result = subprocess.run(
        ["bash", "scripts/dev/beads.sh", *args], text=True, capture_output=True, timeout=60
    )
    (out / (name + ".stdout")).write_text(result.stdout)
    (out / (name + ".stderr")).write_text(result.stderr)
    receipt.append(
        {
            "operation": name,
            "exit_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    )
    (out / "own-close-receipts.json").write_text(
        json.dumps(receipt, indent=2, ensure_ascii=False) + "\n"
    )
    result.check_returncode()
    return result.stdout


note = "Root technical acceptance/Main integration and push completed at 1ed501b771d5c59813a977463a947ba817b276f9; all 80 frozen paths copied exactly. Canonical acceptance: research-data/ai-sigma/multi-game-workflow129/web-shell-acceptance-v1.json. Root Main typecheck/boundary and ordinary production smoke URL syntax PASS. Own administration only: no product source/test/browser/config reads or replay. Shared temporary browser config was restored by Root. Frozen implementation and earlier failures/evidence preserved. Closing only this own issue with original assignee and Root exact UTF-8 reason; parent12.9 continues. Backup-before and backup-after, exact returned status/assignee/reason equality and final notification/STOP receipts recorded in tasklocal .artifacts/web-game-shell129/own-close-result.json and own-close-receipts.json."
beads("accepted-integration-note", "update", issue, "--append-notes", note)
beads("close-backup-before", "backup", "sync")
beads("one-normal-own-close", "close", issue, "--reason", reason)
raw = beads("closed-verification-show", "show", issue, "--json")
after = json.loads(raw)
after = after[0] if isinstance(after, list) else after
checks = {
    "status_CLOSED": after["status"] == "closed",
    "same_original_assignee": after["assignee"] == owner,
    "exact_reason_equality": after["close_reason"] == reason,
}
result = {
    "issue": issue,
    "Main_commit": "1ed501b771d5c59813a977463a947ba817b276f9",
    "one_close_command": True,
    "before_assignee": before["assignee"],
    "returned_status": after["status"],
    "returned_assignee": after["assignee"],
    "returned_close_reason": after["close_reason"],
    "exact_reason_source": str(reason_path),
    "reason_UTF8_sha256": hashlib.sha256(reason.encode("utf-8")).hexdigest(),
    "checks": checks,
}
(out / "own-close-result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
assert all(checks.values()), checks
beads("close-backup-after", "backup", "sync")
result["backup_before"] = "complete"
result["backup_after"] = "complete"
(out / "own-close-result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(result, ensure_ascii=False))
