"""Emit small text-only handoff patches against the original tracked Git blobs."""

import difflib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent
manifest = json.loads((output / "source-manifest.json").read_text())
callers = json.loads((output / "changed-callers.json").read_text())
patch = []
for old, new in [
    *((path, path) for path in callers),
    *((r["old_path"], r["new_path"]) for r in manifest["assets"] if not r["binary"]),
]:
    original = subprocess.check_output(
        ["git", "show", f"{manifest['source_revision']}:{old}"], cwd=root
    ).decode()
    current = (root / new).read_text()
    if original == current:
        continue
    patch.append(f"diff --git a/{new} b/{new}\n")
    patch.extend(
        difflib.unified_diff(
            original.splitlines(keepends=True),
            current.splitlines(keepends=True),
            fromfile=f"a/{new}",
            tofile=f"b/{new}",
        )
    )
(output / "source-text.patch").write_text("".join(patch))
assert sum(line.startswith("diff --git ") for line in patch) == 11
print("20 rename-only entries + 11 small text diffs; common proposal remains separate")
