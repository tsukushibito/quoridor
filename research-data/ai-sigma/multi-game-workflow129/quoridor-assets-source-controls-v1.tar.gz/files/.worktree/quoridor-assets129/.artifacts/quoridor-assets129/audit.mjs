import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync, statSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parsers } from '/workspaces/quoridor/tools/research-quality/node_modules/prettier/plugins/typescript.mjs';

const directory = fileURLToPath(new URL('./', import.meta.url));
const root = resolve(directory, '../..');
const manifest = JSON.parse(readFileSync(resolve(directory, 'source-manifest.json')));
const callers = JSON.parse(readFileSync(resolve(directory, 'changed-callers.json')));
const git = (...args) => execFileSync('git', args, { cwd: root, env: { ...process.env, GIT_OPTIONAL_LOCKS: '0' } });
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const normalize = (value) => value.replace(/assets\/(environments|tabletop|audio|ui)\//g, 'games/quoridor/$1/');
function ast(text, path, normalizeUrls) {
  const file = parsers.typescript.parse(text, { filepath: path });
  return JSON.parse(
    JSON.stringify(file, (key, value) => {
      if (['loc', 'range', 'start', 'end', 'comments', 'tokens'].includes(key)) return undefined;
      return normalizeUrls && typeof value === 'string' ? normalize(value) : value;
    }),
  );
}
const evidence = { sourceRevision: manifest.source_revision, callers: [], assets: [] };
for (const path of callers) {
  const original = git('show', `${manifest.source_revision}:${path}`);
  const current = readFileSync(resolve(root, path));
  assert.deepEqual(ast(original.toString(), path, true), ast(current.toString(), path, false), path);
  if (path.endsWith('/index.ts'))
    assert.equal(current.toString(), original.toString().replace('assets/ui/quoridor-title-logo.png', 'games/quoridor/ui/quoridor-title-logo.png'));
  if (path.endsWith('product-bfcache-worker.spec.mjs')) {
    const lines = (text) => text.split('\n').filter((line) => line.includes('expectedWorkerPath'));
    assert.deepEqual(lines(current.toString()), lines(original.toString()));
  }
  evidence.callers.push({
    path,
    oldSha256: hash(original),
    oldGitBlob: git('rev-parse', `${manifest.source_revision}:${path}`).toString().trim(),
    sha256: hash(current),
    bytes: current.length,
    mode: (statSync(resolve(root, path)).mode & 0o777).toString(8),
    ast: 'identical after only assigned asset URL mapping; whitespace ignored',
  });
}
for (const asset of manifest.assets) {
  const path = resolve(root, asset.new_path);
  const current = readFileSync(path);
  assert.ok(!existsSync(resolve(root, asset.old_path)));
  assert.equal(statSync(path).mode & 0o777, 0o644);
  if (asset.binary || !['environments/README.md', 'tabletop/README.md'].some((suffix) => path.endsWith(suffix))) {
    assert.equal(hash(current), asset.sha256);
    assert.equal(current.length, asset.bytes);
  }
  evidence.assets.push({ ...asset, currentSha256: hash(current), currentBytes: current.length });
}
const modified = git('diff', '--name-only', manifest.source_revision).toString().trim().split('\n');
assert.deepEqual(new Set(modified), new Set([...callers, ...manifest.assets.map((asset) => asset.old_path)]));
const untracked = git('ls-files', '--others', '--exclude-standard', '--', 'apps/web/public/games/quoridor').toString().trim().split('\n');
assert.deepEqual(new Set(untracked), new Set(manifest.assets.map((asset) => asset.new_path)));
const icon = 'apps/web/public/favicon.ico';
const originalIcon = git('show', `${manifest.source_revision}:${icon}`);
assert.deepEqual(readFileSync(resolve(root, icon)), originalIcon);
assert.equal(originalIcon.length, 4286);
evidence.favicon = { path: icon, sha256: hash(originalIcon), bytes: 4286, unchanged: true };
evidence.scope = 'only 20 moves, 9 literal URL callers, 2 moved README links/formatting';
evidence.settingsStorageLifecycleWorkerSemantics = 'unchanged: AST equivalence + complete tracked change allowlist';
writeFileSync(resolve(directory, 'final-source-manifest.json'), JSON.stringify(evidence, null, 2) + '\n');
console.log(JSON.stringify({ scope: evidence.scope, callerASTs: evidence.callers.length, assetIdentities: evidence.assets.length, binaryHashModeUnchanged: 13, otherTextUnchanged: 5, faviconUnchanged: true }));
