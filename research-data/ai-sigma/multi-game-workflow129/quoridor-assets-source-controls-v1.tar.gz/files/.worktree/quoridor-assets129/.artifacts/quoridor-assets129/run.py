"""Finite task commands using the existing CPU/resource/process owner."""

import hashlib
import json
import os
from pathlib import Path
import sys
import time

from quoridor_runtime.cycle_process import (
    CPUPlan,
    CycleResources,
    available_cpus,
    execute,
    identity,
    process_info,
    save_record,
)

root = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent
plan_path = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/"
    "multi-game-migration-v1/quoridor-assets-entry-v1/cpu-plan.json"
)
raw = plan_path.read_bytes()
assert len(raw) == 491 and plan_path.stat().st_mode & 0o777 == 0o644
assert hashlib.sha256(raw).hexdigest() == (
    "9733cfd2c74ae43fe4eedfa4f0829a5605773feb92de5d54f5133b95234d3311"
)
contract = json.loads(raw)
plan = CPUPlan.from_record(contract["cpu_plan"])
plan.check_host(available_cpus())
plan.apply()
label, *command = sys.argv[1:]
assert label and command and not (output / f"{label}.json").exists()
deadline = time.monotonic() + 300
tmp = output / f"tmp-{label}"
tmp.mkdir()
config = dict(
    pause_file=str(output / "CANCEL"),
    host_ram_reserve=contract["hostreserve_B"],
    max_memory_bytes=contract["family_B"],
)
resources = CycleResources(config, output, deadline)
child_resources = CycleResources(
    {**config, "max_memory_bytes": contract["child_max_B"]}, output, deadline
)
controller_resources = CycleResources(
    {**config, "max_memory_bytes": contract["controller_B"]}, output, deadline
)
check = resources.check
peaks = {"family_RSS_B": 0, "controller_RSS_B": 0, "children_RSS_B": 0}


def observe(owned=(), *, include_self=True):
    check(owned, include_self=include_self)
    child_resources.check(owned, include_self=False)
    controller_resources.check()
    controller = process_info(os.getpid())["rss"]
    children = 0
    for member in owned:
        current = process_info(member["pid"])
        if identity(current) == identity(member):
            children += current["rss"]
    for key, value in (
        ("family_RSS_B", controller + children),
        ("controller_RSS_B", controller),
        ("children_RSS_B", children),
    ):
        peaks[key] = max(peaks[key], value)


resources.check = observe
env = {
    **os.environ,
    "TMPDIR": str(tmp),
    "TMP": str(tmp),
    "TEMP": str(tmp),
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1",
    "RAYON_NUM_THREADS": "1",
    "UV_THREADPOOL_SIZE": "1",
    "GOMAXPROCS": "1",
    "CUDA_VISIBLE_DEVICES": "",
    "PYTHONDONTWRITEBYTECODE": "1",
}
receipt = dict(
    command=command,
    cwd=str(root),
    cpu_plan=plan.record(),
    contract=contract,
    source_lease="ACTIVE: this finite command only",
    runtime_source=__import__("quoridor_runtime.cycle_process", fromlist=["__file__"]).__file__,
)
save_record(output / f"{label}.json", receipt)
try:
    execute(
        command,
        output / f"{label}.log",
        deadline,
        resources=resources,
        cwd=root,
        env=env,
        cpu_plan=plan,
        cpu_scope="implementation",
    )
    receipt["status"] = "PASS"
except BaseException as error:
    receipt.update(status="FAILED", error=str(error))
    raise
finally:
    process_path = output / f"{label}.process.json"
    process = json.loads(process_path.read_text()) if process_path.exists() else {}
    stopped = process.get("cleanup_complete", False)
    receipt.update(
        peaks=peaks,
        source_lease="STOP" if stopped else "UNKNOWN",
        source_reader_STOP=stopped,
        tmp_empty=not any(tmp.iterdir()),
    )
    if receipt["tmp_empty"] and stopped:
        tmp.rmdir()
    save_record(output / f"{label}.json", receipt)
    print(json.dumps(receipt))
