"""Collect finite handoff evidence and remove only stopped, task-owned TMP remnants."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import stat

root = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent
cleanup = []
for path in sorted(output.glob("tmp-*")):
    label = path.name.removeprefix("tmp-")
    record = json.loads((output / f"{label}.process.json").read_text())
    assert record["cleanup_complete"] and record["direct_child_reaped"]
    assert record["handle_closes_complete"] and not record["remaining"]
    leftovers = [str(p.relative_to(path)) for p in path.rglob("*") if p.is_file()]
    assert all(p.startswith("node-compile-cache/") or p.endswith(".lock") for p in leftovers)
    shutil.rmtree(path)
    cleanup.append(dict(label=label, files=leftovers, cleanup_complete=True))
old = root / "apps/web/public/assets"
if old.exists():
    assert not any(old.iterdir())
    old.rmdir()


def file_ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path.relative_to(root)),
        bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


wasm = [
    file_ref(root / "games/quoridor/bridge/wasm" / role / (name + suffix))
    for role, name in (("rules", "quoridor_rules"), ("ai", "quoridor_ai"))
    for suffix in (".js", ".d.ts", "_bg.wasm", "_bg.wasm.d.ts")
]
summary = dict(
    source_revision="eb38a0010de1cd30aa0ea0dd583534ef65c4623e",
    issue="quoridor-4lc.324.12.9.8",
    scope="20 same-WT asset moves, 9 URL caller files, 2 relative README links/formatting",
    passed=[
        "typecheck",
        "build-root",
        "build-subpath",
        "url-ports-v2",
        "static-urls",
        "source-audit-v2",
        "prettier-check",
        "helper-ruff-format-check",
        "helper-ruff-check",
    ],
    retained_failed=[
        dict(label="initial context probe", reason="python unavailable; python3 retry verified"),
        dict(
            label="url-ports", reason="fixture missing createImageBitmap binding; no product repair"
        ),
        dict(
            label="source-audit",
            reason="TS7 lacks old compiler JS API; installed Prettier parser used",
        ),
    ],
    unrun=["browser/E2E", "Rust/Cargo/wasm-pack", "renderer/numeric/science/model suites"],
    deviations=["initial runtime SKILL read preceded saved context verification"],
    source_reader_STOP=True,
    helper_STOP="all process receipts complete/reaped/handles closed; no remaining owned children",
    server_STOP="static-urls.log server CLOSED; process cleanup complete",
    cleaned_TMP=cleanup,
    supplied_wasm_inputs=wasm,
    common_files="unchanged; one common-caller-proposal.patch only",
    git_writes="no add/index/branch/checkout/commit/push operations; apply --check only",
    acceptance="frozen for Root; issue not self-closed",
)
processes = []
for path in sorted(output.glob("*.process.json")):
    process = json.loads(path.read_text())
    assert process["cleanup_complete"] and process["direct_child_reaped"]
    assert process["handle_closes_complete"] and not process["remaining"]
    processes.append(dict(path=path.name, status=process["status"], source_reader_STOP=True))
summary["processes"] = processes
receipts = [
    json.loads(path.read_text())
    for path in output.glob("*.json")
    if "peaks" in json.loads(path.read_text())
]
summary["observed_peak_family_RSS_B"] = max(r["peaks"]["family_RSS_B"] for r in receipts)
summary["observed_peak_controller_RSS_B"] = max(r["peaks"]["controller_RSS_B"] for r in receipts)
summary["observed_peak_children_RSS_B"] = max(r["peaks"]["children_RSS_B"] for r in receipts)
(output / "handoff.json").write_text(json.dumps(summary, indent=2) + "\n")
refs = [
    file_ref(path)
    for path in sorted(output.iterdir())
    if path.is_file() and path.suffix in (".json", ".md", ".mjs", ".py", ".patch", ".log")
]
(output / "evidence-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
assert not (output / "affected-storage.json").exists(), "affected storage is measured once"
seen = set()
storage = []
for directory in (root / "apps/web/public/games/quoridor", output):
    allocated = logical = files = 0
    for current, _directories, names in os.walk(directory):
        info = Path(current).lstat()
        allocated += info.st_blocks * 512
        for name in names:
            path = Path(current) / name
            info = path.lstat()
            inode = (info.st_dev, info.st_ino)
            if inode not in seen:
                seen.add(inode)
                files += 1
                logical += info.st_size
                allocated += info.st_blocks * 512
    storage.append(
        dict(
            path=str(directory.relative_to(root)),
            files=files,
            logical_B=logical,
            allocated_B=allocated,
        )
    )
(output / "affected-storage.json").write_text(
    json.dumps(
        dict(
            scope=storage,
            total_affected_allocated_B=sum(r["allocated_B"] for r in storage),
            global_cap_B=50_000_000_000,
            global_current_usage="UNKNOWN; no global walk",
            note="once-after-cleanup snapshot; excludes this record and later notification metadata",
        ),
        indent=2,
    )
    + "\n"
)
print(json.dumps(summary, ensure_ascii=False))
