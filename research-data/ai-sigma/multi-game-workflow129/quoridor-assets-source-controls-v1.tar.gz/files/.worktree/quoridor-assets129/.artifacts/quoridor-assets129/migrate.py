"""Record original Git restoration identities, then move the assigned assets once."""

import difflib
import hashlib
import json
from pathlib import Path
import stat
import subprocess

root = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent
revision = "eb38a0010de1cd30aa0ea0dd583534ef65c4623e"
prefix = "apps/web/public/assets/"
destination = "apps/web/public/games/quoridor/"
source_paths = [prefix + name for name in ("environments", "tabletop", "audio", "ui")]
tracked = subprocess.check_output(
    ["git", "ls-tree", "-r", "-z", revision, "--", *source_paths], cwd=root
)
records = []
for entry in tracked.split(b"\0"):
    if not entry:
        continue
    fields, raw_path = entry.split(b"\t", 1)
    mode, kind, blob = fields.decode().split()
    old = raw_path.decode()
    path = root / old
    data = path.read_bytes()
    assert subprocess.check_output(["git", "cat-file", "blob", blob], cwd=root) == data
    assert mode == "100644" and stat.S_IMODE(path.stat().st_mode) == 0o644
    records.append(
        dict(
            old_path=old,
            new_path=old.replace(prefix, destination, 1),
            git_blob=blob,
            git_mode=mode,
            mode="0644",
            bytes=len(data),
            sha256=hashlib.sha256(data).hexdigest(),
            binary=path.suffix in (".png", ".hdr", ".wav", ".mp3"),
            source_inode=path.stat().st_ino,
            git_restore=["git", "cat-file", "blob", blob],
        )
    )
assert len(records) == 20
assert sum(r["bytes"] for r in records) == 30_511_431
assert sum(r["binary"] for r in records) == 13
manifest = dict(source_revision=revision, assets=records)
(output / "source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
rename_patch = "".join(
    f"diff --git a/{r['old_path']} b/{r['new_path']}\n"
    f"similarity index 100%\nrename from {r['old_path']}\nrename to {r['new_path']}\n"
    for r in records
)
(output / "rename-only.patch").write_text(rename_patch)
# Same filesystem directory renames: no private binary archive or duplicated source.
for source in source_paths:
    old = root / source
    new = root / source.replace(prefix, destination, 1)
    new.parent.mkdir(parents=True, exist_ok=True)
    assert not new.exists()
    old.rename(new)
for record in records:
    new = root / record["new_path"]
    assert new.stat().st_ino == record["source_inode"]
    assert hashlib.sha256(new.read_bytes()).hexdigest() == record["sha256"]
for name in ("environments", "tabletop"):
    path = root / destination / name / "README.md"
    text = path.read_text()
    assert "../../../../../docs/reports/" in text
    path.write_text(text.replace("../../../../../docs/reports/", "../../../../../../docs/reports/"))
callers = [
    "apps/web/src/games/quoridor/environment-presets.ts",
    "apps/web/src/games/quoridor/render/tabletop-assets.ts",
    "apps/web/src/games/quoridor/audio/audio-controller.ts",
    "apps/web/src/games/quoridor/index.ts",
    *[
        f"games/quoridor/tests/e2e/{name}.spec.ts"
        for name in ("tabletop-rendering", "presentation", "audio", "phase4-recovery")
    ],
    "games/quoridor/tests/product/product-bfcache-worker.spec.mjs",
]
for name in callers:
    path = root / name
    text = path.read_text()
    updated = text
    for category in ("environments", "tabletop", "audio", "ui"):
        updated = updated.replace(f"assets/{category}/", f"games/quoridor/{category}/")
    assert text != updated, name
    if name.endswith("/index.ts"):
        assert text.count("assets/ui/quoridor-title-logo.png") == 1
        assert updated == text.replace(
            "assets/ui/quoridor-title-logo.png", "games/quoridor/ui/quoridor-title-logo.png"
        )
    path.write_text(updated)
(output / "changed-callers.json").write_text(json.dumps(callers, indent=2) + "\n")
common = [
    "docs/reports/audio-implementation.md",
    "docs/reports/tabletop-rendering.md",
    "docs/reports/environment-presets.md",
    "docs/reports/title-help-implementation.md",
    "docs/reports/presentation-implementation.md",
    "games/quoridor/docs/quoridor-3d-webapp-design-rust-wasm-v1.md",
]
proposal = []
for name in common:
    text = (root / name).read_text()
    updated = text.replace("apps/web/public/assets/", "apps/web/public/games/quoridor/")
    assert text != updated, name
    proposal.extend(
        difflib.unified_diff(
            text.splitlines(keepends=True),
            updated.splitlines(keepends=True),
            fromfile=f"a/{name}",
            tofile=f"b/{name}",
        )
    )
(output / "common-caller-proposal.patch").write_text("".join(proposal))
print(f"Moved {len(records)} tracked assets / {sum(r['bytes'] for r in records)} bytes")
print("13 binary identities preserved; 9 direct callers updated; 6 common link proposals only")
