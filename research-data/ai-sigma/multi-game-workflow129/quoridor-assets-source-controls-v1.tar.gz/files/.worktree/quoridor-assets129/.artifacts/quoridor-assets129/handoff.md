# Quoridor asset配置・凍結引渡し

Issue: `quoridor-4lc.324.12.9.8`。担当thread: `01a15f31-d1ed-70a1-bb23-7b49f7a92e0d`。
実WT: `/workspaces/quoridor/.worktree/quoridor-assets129`。
開始Git: `eb38a0010de1cd30aa0ea0dd583534ef65c4623e`。
親: `quoridor-4lc.324.12.9` / 現Root `01a1376a-bfd3-75d2-bd64-61e9416b3b13`。

20 tracked assets、元30,511,431Bを `apps/web/public/assets/` から `apps/web/public/games/quoridor/` へ同一WT内でディレクトリrenameした。全20ファイルは移動直後にbyte・mode・inode一致。13画像/HDR/音声は元Git blobとのbyte一致と最終SHA-256・0644一致を確認し、decode・再生成・再圧縮は0。

7 text/configのうち5ファイル（audio README、2 license原文、audio manifest、ui README）はbyte不変。environments/tabletop READMEは報告への相対リンクを1階層補正し、変更MDに既設Prettierを適用した。環境READMEの表は整形のみ。出典・原ハッシュ・サイズ・license・生成promptは保持した。共通favicon.icoは4,286B、元byte不変。

実変更callerは許可されたTS/MJSの9ファイルだけ。`index.ts` はtitle-logo URL一箇所の差分だけ。元ASTの指定asset URLだけを移行先へ対応付けたASTと現在ASTが全9件一致した。設定値・storage key・game lifecycle・Worker semanticsは変更していない。product testの `expectedWorkerPath` 行も元のまま。bundled Worker/Wasm/font/JS/CSSの `/assets/` は維持している。

Root-owned common実ファイルは無変更。唯一の `common-caller-proposal.patch` は、現在もassetを指す5報告文書とゲーム設計文書の6ファイルについて、現役リンク/パスだけを更新する提案である。歴史数値、RAW、FileRef、元worktree記録は変更していない。

## 検証

| 項目 | 結果・証拠 |
| --- | --- |
| actual-WT frontend型検査 | PASS、`typecheck.log` / `typecheck.process.json` |
| actual-WT Vite root build | PASS、`build-root.log`。通常の500kB超chunk警告のみ |
| actual-WT Vite subpath build | PASS、`build-subpath.log`。base `/quoridor-check/` |
| 各buildの20 asset | PASS、`static-urls.log`。各ファイルをHTTP取得し現在sourceとbyte比較、40件200 |
| 旧asset入口・favicon | 各baseで4カテゴリの旧URLは404、共通faviconは200/4,286B |
| 実AudioController URL/404 | PASS、`url-ports-v2.log`。両baseで7音源の新URL、失敗を既存状態で処理 |
| 実TabletopAssets URL/404 | PASS、同log。両baseで4環境/木目の新URL、既存fallback。decode 0 |
| 変更範囲・意味保持 | PASS、`source-audit-v2.log` / `final-source-manifest.json`。9 caller AST一致、20 asset identity、favicon |
| 整形 | 設置済みPrettier write/check、Python helper Ruff line-length100 format/check。最終checkログ参照 |
| patch適用可能性 | `git apply --check --reverse source-text.patch` とrename-only reverse、およびcommon提案forwardがPASS。実applyなし |

ブラウザ/E2E、Rust/Cargo/wasm-pack、旧成功renderer/数値/science/model suiteはUNRUN。実橋渡しコードはこのWT、依存だけRoot供給node_modules、Vite aliasはWT bridge source。変更していないRoot供給8 Wasm入力をそのまま使用し、build Rust/installは0。他課題12.9.7・モデル・inputs・RAW・sealed・shared asset本体はアクセスしていない。

## 原失敗と制限

- 保存context確認前にruntime SKILL文書をreadした順序逸脱を保持。その後の初回 `python` は未導入でexit127、`python3` で保存contextを確認し、製品source read/write前に指定のmodel/effort/cwd/full-access/never一致を確認した。`first-read.md` 参照。
- `url-ports` 初回FAILEDはfixtureの `createImageBitmap` binding不足。fixtureだけ修正してv2 PASS。元log/process/receipt保持。
- `source-audit` 初回FAILEDはTypeScript7の従来JS compiler APIが使えないことによる。設置済みPrettierのTypeScript parserでAST照合しv2 PASS。元log/process/receipt保持。
- runtime skillのenvironment_status toolはこのsessionに公開されていなかった。外部network作業は0、HTTPは自分のbounded localhost serverだけ。

## 復元・統合

`source-manifest.json` は全20件の元→新path、原Git blob、bytes、mode、SHA-256、元inodeを記録する。各 `git_restore` のblobを `git cat-file blob` で取り出し、記録modeを適用すれば原内容を復元できる。バイナリのprivate archiveは作成していない。

Rootは開始版のtracked sourceに `rename-only.patch`、続いて `source-text.patch` を適用できる。共通caller/linkは別の `common-caller-proposal.patch` 一つをレビューして統合する。新実source自体はこのWTの移動先にあり、Git indexへ未登録のためdiff表示は旧path削除と新path未追跡となる。workerからadd/index/branch/checkout/commit/pushを行っていない。

資源は供給FileRefのSHA/491B/0644を照合し、無変更の `CPUPlan.from_record` を使用した。既存 `CycleResources` / `execute` によるCPU16、管理18、family1GiB（controller64MiB・child960MiB）、host reserve4GiB、GPU0、thread1、所有TMP、CANCEL、300秒command deadline、TERM/KILL、direct wait/reap、handle closeを使用した。個々の実RSS peak・command・STOPは各receiptに保存。限定serverはclose済み。全source command/helperの終了後、停止確認済みTMPのuv lock/Node compile cacheだけ除去する。

実affected storageは最後にこのsource配置と所有artifactだけ一度計測し `affected-storage.json` へ記録する。全体50GB・pause・seal・defaults・元FAILED/NULL/UNKNOWNは保持し、全host quietや全体実使用の保証はしない。

実source書込みは凍結。受入れ前self-closeは行わず、Beadsに根拠とSTOPを追記してbackup syncし、親Rootへfrozen handoffを送る。受入れ、Main/Git、commit/push、managed removeはRoot担当。
