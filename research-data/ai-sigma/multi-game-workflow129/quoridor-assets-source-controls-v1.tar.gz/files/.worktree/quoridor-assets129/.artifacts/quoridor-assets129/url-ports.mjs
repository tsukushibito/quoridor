import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { stripTypeScriptTypes } from 'node:module';
import vm from 'node:vm';
import { loadTs } from '../../tests/unit/ts-fixture.mjs';

const source = new URL('../../apps/web/src/games/quoridor/', import.meta.url);
const settings = await loadTs(new URL('audio/audio-settings.ts', source), {});
const presets = await loadTs(new URL('environment-presets.ts', source), {});
const report = [];
for (const base of ['/', '/quoridor-check/']) {
  const audioRequests = [];
  const { AudioController } = await loadTs(
    new URL('audio/audio-controller.ts', source),
    { './audio-settings': { validateAudioSettings: settings.validateAudioSettings } },
    {
      AbortController,
      fetch: async (url) => {
        audioRequests.push(url);
        return { ok: false, status: 404 };
      },
    },
  );
  const context = {
    state: 'running',
    currentTime: 0,
    destination: {},
    createGain: () => ({
      gain: {
        value: 0,
        cancelScheduledValues() {},
        setValueAtTime() {},
        linearRampToValueAtTime() {},
      },
      connect() {},
      disconnect() {},
    }),
    resume: async () => {},
    close: async () => {},
    decodeAudioData() {
      assert.fail('404 URL selection must not decode audio');
    },
  };
  const audio = new AudioController(settings.DEFAULT_AUDIO_SETTINGS, base, () => context);
  try {
    await audio.unlock();
    assert.deepEqual(
      audioRequests.sort(),
      ['pawn.wav', 'wall.wav', 'click.wav', 'undo.wav', 'win.wav', 'lose.wav', 'cozy-puzzle.mp3']
        .map((name) => `${base}games/quoridor/audio/${name}`)
        .sort(),
    );
    assert.equal(audio.status, 'failed');
    assert.equal(audio.diagnostics().pending, 0);
    assert.equal(audio.diagnostics().failures.length, 7);
    assert.equal(audio.settings.sfxVolume, 55);
    assert.equal(audio.settings.bgmVolume, 20);
  } finally {
    audio.dispose();
  }

  const tabletopRequests = [];
  const contextVm = vm.createContext({
    AbortController,
    window: { setTimeout, clearTimeout },
    createImageBitmap() {
      assert.fail('404 URL selection must not decode an image');
    },
    fetch: async (url) => {
      tabletopRequests.push(url);
      return { ok: false };
    },
  });
  const tabletopUrl = new URL('render/tabletop-assets.ts', source);
  const module = new vm.SourceTextModule(
    stripTypeScriptTypes(readFileSync(tabletopUrl, 'utf8'), { mode: 'transform' }),
    {
      context: contextVm,
      identifier: tabletopUrl.href,
      initializeImportMeta: (meta) => {
        meta.env = { BASE_URL: base };
      },
    },
  );
  const imports = {
    'three/webgpu': {},
    'three/addons/loaders/HDRLoader.js': {
      HDRLoader: class {
        parse() {
          assert.fail('404 URL selection must not decode HDR');
        }
      },
    },
    './environment-light': {
      environmentLight() {
        assert.fail('404 URL selection must not compute lighting');
      },
    },
    '../environment-presets': {
      DEFAULT_ENVIRONMENT: presets.DEFAULT_ENVIRONMENT,
      environmentPreset: presets.environmentPreset,
    },
  };
  await module.link((name) => {
    assert.ok(Object.hasOwn(imports, name), name);
    const port = imports[name];
    return new vm.SyntheticModule(
      Object.keys(port),
      function () {
        for (const [key, value] of Object.entries(port)) this.setExport(key, value);
      },
      { context: contextVm },
    );
  });
  await module.evaluate();
  const tabletop = new module.namespace.TabletopAssets({}, [], { intensity: 0 }, { intensity: 1 });
  try {
    await tabletop.load({}, () => {});
    for (const preset of presets.ENVIRONMENT_PRESETS.slice(1))
      await tabletop.setEnvironment(preset.id);
    assert.deepEqual(
      tabletopRequests.sort(),
      [
        'tabletop/comfy-cafe-2k.hdr',
        'tabletop/beech-albedo.png',
        'environments/warm-restaurant-night-2k.hdr',
        'environments/epping-forest-02-2k.hdr',
        'environments/qwantani-noon-2k.hdr',
      ]
        .map((path) => `${base}games/quoridor/${path}`)
        .sort(),
    );
    assert.equal(tabletop.environment, 'fallback');
    assert.equal(tabletop.wood, 'fallback');
  } finally {
    tabletop.dispose();
  }
  report.push({ base, audioRequests, tabletopRequests, failedDownloads: 'handled', decodeCalls: 0 });
}
console.log(JSON.stringify(report, null, 2));
