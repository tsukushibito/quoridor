import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream, readFileSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import { fileURLToPath } from 'node:url';
import { resolve, sep } from 'node:path';

const directory = fileURLToPath(new URL('./', import.meta.url));
const root = resolve(directory, '../..');
const manifest = JSON.parse(readFileSync(resolve(directory, 'source-manifest.json'), 'utf8'));
const results = [];
for (const [name, base] of [
  ['root', '/'],
  ['subpath', '/quoridor-check/'],
]) {
  const build = resolve(directory, `build-${name}`);
  let requests = 0;
  const server = createServer((request, response) => {
    requests++;
    const path = new URL(request.url, 'http://localhost').pathname;
    if (requests > 50 || !path.startsWith(base)) {
      response.writeHead(404).end();
      return;
    }
    const local = resolve(build, path.slice(base.length));
    try {
      assert.ok(local.startsWith(build + sep));
      assert.ok(statSync(local).isFile());
    } catch {
      response.writeHead(404).end();
      return;
    }
    response.writeHead(200);
    createReadStream(local).pipe(response);
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  const deadline = setTimeout(() => server.closeAllConnections(), 15_000);
  try {
    for (const asset of manifest.assets) {
      const relative = asset.new_path.replace('apps/web/public/', '');
      const url = new URL(base + relative, origin);
      const expected = readFileSync(resolve(root, asset.new_path));
      assert.deepEqual(readFileSync(resolve(build, relative)), expected);
      const response = await fetch(url, { signal: AbortSignal.timeout(3000) });
      assert.equal(response.status, 200, url.href);
      const bytes = Buffer.from(await response.arrayBuffer());
      assert.deepEqual(bytes, expected, url.href);
      results.push({
        base,
        url: url.pathname,
        status: response.status,
        bytes: bytes.length,
        sha256: createHash('sha256').update(bytes).digest('hex'),
      });
    }
    for (const category of ['audio', 'ui', 'environments', 'tabletop']) {
      const asset = manifest.assets.find((asset) => asset.old_path.includes(`/assets/${category}/`));
      const old = asset.old_path.replace('apps/web/public/', '');
      const response = await fetch(new URL(base + old, origin), {
        signal: AbortSignal.timeout(3000),
      });
      assert.equal(response.status, 404);
      await response.arrayBuffer();
    }
    const icon = await fetch(new URL(base + 'favicon.ico', origin), {
      signal: AbortSignal.timeout(3000),
    });
    assert.equal(icon.status, 200);
    assert.equal((await icon.arrayBuffer()).byteLength, 4286);
  } finally {
    clearTimeout(deadline);
    server.closeAllConnections();
    await new Promise((resolve, reject) => server.close((error) => (error ? reject(error) : resolve())));
  }
}
console.log(JSON.stringify({ assets: results, server: 'CLOSED', decodeCalls: 0 }, null, 2));
