"""Compose only the frozen asset relocation with the accepted Web product patch."""

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
WT = ROOT / ".worktree/quoridor-assets129"
OWN = WT / ".artifacts/quoridor-assets129"


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run(name, args, env=None):
    p = subprocess.run(args, capture_output=True, text=True, timeout=180, check=False, env=env)
    (OUT / (name + ".log")).write_text(p.stdout + p.stderr)
    assert p.returncode == 0, (name, p.stderr[-2000:])
    return p.stdout


manifest = json.loads((OWN / "final-source-manifest.json").read_bytes())
assert len(manifest["assets"]) == 20 and len(manifest["callers"]) == 9
for row in manifest["assets"]:
    assert digest(ROOT / row["old_path"]) == row["sha256"]
for row in manifest["callers"]:
    assert digest(ROOT / row["path"]) == row["oldSha256"]
patches = []
for name, sha in [
    ("rename-only.patch", "7029de220bc80fc6e75a6c1caea6a81aaa5149a1ccb6d10c6afee9b6b7762228"),
    ("source-text.patch", "3c77bbc888b6d07b1b5c4a94c2b64089a6872c8bc233e11fc71977321cd109b9"),
    (
        "common-caller-proposal.patch",
        "956d88aff258608fa1978ca223c8c5d0e708c8212baa31d7dcc7fdf32054ca87",
    ),
]:
    p = OWN / name
    assert digest(p) == sha
    run(name + "-check", ["git", "apply", "--check", str(p)])
    run(name + "-apply", ["git", "apply", str(p)])
    patches.append(dict(path=str(p), sha256=sha, bytes=p.stat().st_size))
for row in manifest["assets"]:
    p = ROOT / row["new_path"]
    assert not (ROOT / row["old_path"]).exists()
    assert (
        digest(p) == row["currentSha256"]
        and p.stat().st_size == row["currentBytes"]
        and p.stat().st_mode & 0o777 == int(row["mode"], 8)
    )
for row in manifest["callers"]:
    assert digest(ROOT / row["path"]) == row["sha256"]
# Repair only current canonical design links in these already-touched live reports.
common = re.findall(r"^\+\+\+ b/(.+)$", (OWN / "common-caller-proposal.patch").read_text(), re.M)
for path in common:
    if path.startswith("docs/reports/"):
        p = ROOT / path
        t = p.read_text().replace(
            "../design/quoridor-3d-webapp-design-rust-wasm-v1.md",
            "../../games/quoridor/docs/quoridor-3d-webapp-design-rust-wasm-v1.md",
        )
        p.write_text(t)
readme = ROOT / "README.md"
text = readme.read_text()
needle = "| `tests/`"
line = "| `apps/web/public/games/quoridor/` | Quoridor専用の画像・HDRI・音声と出典。共通faviconはpublic直下 |\n"
assert needle in text
text = text.replace(needle, line + needle, 1)
readme.write_text(text)
pretty = str(ROOT / "tools/research-quality/node_modules/.bin/prettier")
for mode in ("--write", "--check"):
    run(
        "common-format-" + mode,
        [pretty, "--config", "tools/research-quality/.prettierrc.json", mode, *common, "README.md"],
    )
env = dict(os.environ, NODE_DISABLE_COMPILE_CACHE="1", APP_OUT_DIR=str(OUT / "web-dist"))
run(
    "actual-combined-build",
    [
        "node",
        "node_modules/vite/bin/vite.js",
        "build",
        "apps/web",
        "--config",
        "apps/web/vite.config.ts",
        "--configLoader",
        "native",
    ],
    env,
)
# Static distribution byte identity for this combined Main bundle; no decode/browser.
for row in manifest["assets"]:
    relative = Path(row["new_path"]).relative_to("apps/web/public")
    p = OUT / "web-dist" / relative
    assert digest(p) == row["currentSha256"] and p.stat().st_size == row["currentBytes"]
assert not (OUT / "web-dist/assets/audio").exists()
links = []
for path in common:
    for target in re.findall(r"\]\(([^)]+)\)", (ROOT / path).read_text()):
        if (
            "public/games/quoridor" not in target
            and "quoridor-3d-webapp-design-rust-wasm-v1.md" not in target
        ) or "://" in target:
            continue
        assert ((ROOT / path).parent / target.split("#")[0]).exists(), (path, target)
        links.append(dict(source=path, target=target))
run("diff-check", ["git", "diff", "--check"])
(OUT / "composition.json").write_text(
    json.dumps(
        dict(
            base="eb38a0010de1cd30aa0ea0dd583534ef65c4623e",
            manifest=manifest,
            applied_patches=patches,
            common_paths=common,
            Root_added_current_design_links=True,
            Root_readme_updated=True,
            checked_links=links,
            actual_Main_combined_build=True,
            actual_Main_bundle20_assets="exact bytes/SHA/size to frozen source manifest; no decode",
            worker_checks_reused="actual-WT TSC/root+subpath builds/40HTTP200/current source byte matches/old404/favicon200; directAudio/Tabletop real URL+404 ports; all9AST identity after only literal URL mapping",
            browser_replay=False,
            semantics_unchanged="settings/storage/lifecycle/Worker algorithms; only nine callers asset paths and20 relocations",
            scientific_calls=0,
        ),
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        dict(
            source20_relocated=True,
            callers9_exact=True,
            current_Main_combined_build=True,
            new_asset_links=len(links),
        )
    )
)
