"""Single accepted-issue close; source and historical evidence remain untouched."""

import hashlib
import json
from pathlib import Path
import subprocess

OWN = Path(".artifacts/quoridor-test-doc129")
ISSUE = "quoridor-4lc.324.12.9.5"
ASSIGNEE = "codex:01a15f01-fe83-7c11-8a55-35cd2764abd8"
reason_path = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/"
    "multi-game-migration-v1/test-doc-close-dispatch-v1/exact-close-reason.txt"
)
reason_bytes = reason_path.read_bytes()
assert len(reason_bytes) == 744
assert hashlib.sha256(reason_bytes).hexdigest() == (
    "4292168d6caded658c078bad300daff335db4f18b9e2d78d6cad76b7a1bd7d7a"
)
reason = reason_bytes.decode("utf-8")
receipt = {"issue": ISSUE, "reason_sha256": hashlib.sha256(reason_bytes).hexdigest(), "calls": []}


def beads(*args):
    result = subprocess.run(["bash", "scripts/dev/beads.sh", *args], text=True, capture_output=True)
    receipt["calls"].append(
        {
            "argv": list(args),
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    )
    (OWN / "admin-close-transaction.json").write_text(
        json.dumps(receipt, indent=2, ensure_ascii=False) + "\n"
    )
    result.check_returncode()
    return result.stdout


before = json.loads(beads("show", ISSUE, "--json"))[0]
assert before["status"] == "in_progress" and before["assignee"] == ASSIGNEE
beads(
    "update",
    ISSUE,
    "--append-notes",
    "Root technical acceptance/push confirmed at68100f946a9c368be2490d04fd9a8e97f520a520; "
    "canonical research-data/ai-sigma/multi-game-workflow129/quoridor-test-doc-acceptance-v1.json. "
    "ADMIN ONLY finalization: saved actual context reverified gpt-6.1-sol/high/exact WT/"
    "danger-full-access/never and unchanged supplied493B/0644 CPUPlan. No source/tests/archive "
    "replay or other issue changes. Original pending signal process disk facts remain untouched; "
    "no inferred restoration proof. Original assignee retained; one normal close follows with "
    "exact UTF8 dispatch reason SHA256 4292168d6caded658c078bad300daff335db4f18b9e2d78d6cad76b7a1bd7d7a, "
    "backup before/after, then one final parent12.9 handoff and admin STOP. "
    "New receipts remain under .artifacts/quoridor-test-doc129/admin-close-*.",
)
beads("backup", "sync")
beads("close", ISSUE, "--reason", reason)
after = json.loads(beads("show", ISSUE, "--json"))[0]
assert after["status"] == "closed"
assert after["assignee"] == ASSIGNEE
assert after["close_reason"].encode("utf-8") == reason_bytes
beads("backup", "sync")
receipt["verified"] = {
    "status": after["status"],
    "assignee": after["assignee"],
    "exact_close_reason": after["close_reason"],
    "reason_bytes": len(reason_bytes),
    "same_original_assignee": True,
    "normal_close_call_count": sum(c["argv"][0] == "close" for c in receipt["calls"]),
    "backup_before_and_after": True,
}
(OWN / "admin-close-transaction.json").write_text(
    json.dumps(receipt, indent=2, ensure_ascii=False) + "\n"
)
print(json.dumps(receipt["verified"], indent=2, ensure_ascii=False))
