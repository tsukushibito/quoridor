"""Task-local adapter around the existing bounded process owner."""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time

from quoridor_runtime.cycle_process import (
    CPUPlan,
    CycleResources,
    cancellation_signals,
    execute,
)

ROOT = Path(os.environ["QUORIDOR_CODE_ROOT"])
OWN = ROOT / ".artifacts/quoridor-test-doc129"
PLAN = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/"
    "multi-game-migration-v1/game-boundaries-entry-v1/quoridor-tests-docs129-cpu-plan.json"
)
raw = PLAN.read_bytes()
assert len(raw) == 493 and PLAN.stat().st_mode & 0o777 == 0o644
assert hashlib.sha256(raw).hexdigest() == (
    "90446edc2d1303686c214d4aa4e54dffc3696fa5f9debeda12c639bb29298548"
)
record = json.loads(raw)
plan = CPUPlan.from_record(record["cpu_plan"])
plan.apply()
spec = importlib.util.spec_from_file_location(
    "task_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
)
lifecycle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lifecycle)
deadline = time.monotonic() + 300
resources = CycleResources(
    {
        "host_ram_reserve": record["hostreserve_B"],
        "max_memory_bytes": record["child_max_B"],
        "pause_file": str(OWN / "CANCEL"),
    },
    OWN,
    deadline,
)
label, *command = sys.argv[1:]
env = dict(os.environ)
env.update(
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    NUMEXPR_NUM_THREADS="1",
    CUDA_VISIBLE_DEVICES="",
    GIT_OPTIONAL_LOCKS="0",
)
with (
    cancellation_signals(),
    lifecycle.lease(shared=True),
    tempfile.TemporaryDirectory(prefix="tmp-", dir=OWN) as temporary,
):
    env.update(TMPDIR=temporary, TMP=temporary, TEMP=temporary)
    returned = execute(
        command,
        OWN / f"{label}.log",
        deadline,
        resources=resources,
        cwd=ROOT,
        env=env,
        cpu_plan=plan,
        cpu_scope="implementation",
        output_sink=lambda chunk: sys.stdout.buffer.write(chunk),
    )
(OWN / f"{label}.returned.json").write_text(
    json.dumps(returned, indent=2, ensure_ascii=False) + "\n"
)
