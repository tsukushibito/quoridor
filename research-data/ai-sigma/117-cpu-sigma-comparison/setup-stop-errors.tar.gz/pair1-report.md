EXPERIMENT_PAIR .117 / pair1 seed1979 initial
2goal/W1L1、134public全合法・late0、startup6別/手NN1514。candidate publicmax422.755/ref423.895ms、両Workerstop upper<=D全134、相手t0<旧ACK78/旧返却discard47/公開後確実新NN0。primarysecondary0/両Modeldropzero/innercontrolled0/outerremainingunknown0、RSSpeak1682190336B。詳細研究Git117のpair1.summary/manifest/archiveへ保存・復元後、自域展開重複を整理し登録pair2asymへ。正式公平性/NI/旧WDL統合0。
