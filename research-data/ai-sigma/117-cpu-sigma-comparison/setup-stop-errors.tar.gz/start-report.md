EXPERIMENT_START .117 / frame8
本人受領10:50:29UTC/claim10:50:59、ready/show goal,self・pauseなし・担当確認。115書込/runtime停止引渡し後に117新scopeへ。処理12:15/newrun12:10/提出12:30。受入れ112/113のC1.5/固定Sigma・browser main/専用2Worker/SAB維持、CPU2/RAM6guard5.5/保存128guard112既entry内。初期候補参照2要求接続→seed1979initial/asym/jump、seed2098同順、各色1→2最大12gameを結果前固定。原版seed1979固定の自域glueを登録seedbindingへ整合し安いmock、探索kernel変更0。正式NI/旧WDL統合0。
