EXPERIMENT_PROGRESS .117
source9eb3510、browser接続2/2通常合法・public413.400/416.625ms/ACK444.590/452.375ms。fixedroot numeric/features/prior支持、startup6別/手NN18。両Modeldropzero/innercontrolled0/outerwaitremainingunknown0、RSSpeak1557512192B。jump合法prefix7/history8/P2非終端を同browserNN0確認。seed2098ABI/owned/cache一致とforeignseed拒否、参照NNinvalid/候補NNloss/同時browser原因優先mock支持。r1キー順検査器失敗はNN前保存、旧結果置換0。
固定6pair12game計画SHAはpreregister.json/sourceGit9eb3510で結果前登録。ここからinitial seed1979候補色1→2(pair1)開始、各pair保存/停止後に報告。CPU2/RAM6guard5.5/保存128guard112/累計3600/12:15処理不変。正式NI/旧WDL統合0。
