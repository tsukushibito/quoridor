"""One fixed forty-CI analysis of344 raw samples; isolated stdlib, no engine."""

import json
import math
from pathlib import Path
import random
import statistics
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import plain_control as C


def percentile(values, q):
    index = (len(values) - 1) * q
    low, high = math.floor(index), math.ceil(index)
    return values[low] + (values[high] - values[low]) * (index - low)


def interval(av, bv, rng, resamples):
    boot = sorted(
        statistics.fmean(rng.choices(bv, k=50)) / statistics.fmean(rng.choices(av, k=50)) - 1
        for _ in range(resamples)
    )
    return percentile(boot, 0.025), percentile(boot, 0.975)


def root_gate(comparisons):
    assert set(comparisons) == set(C.BRACKETS)
    beneficial = sum(all(x["CI95_upper"] < -0.01 for x in rows) for rows in comparisons.values())
    adverse = sum(all(x["CI95_lower"] > 0.01 for x in rows) for rows in comparisons.values())
    return {
        "beneficial_B_of4": beneficial,
        "adverse_B_of4": adverse,
        "robust_benefit": beneficial >= 3,
        "reproducible_adverse": adverse >= 3,
    }


def global_gate(roots):
    assert len(roots) == 5
    return sum(x["robust_benefit"] for x in roots.values()) >= 3 and not any(
        x["reproducible_adverse"] for x in roots.values()
    )


def main():
    assert len(sys.argv) == 1
    p = C.protocol()
    phase = C.OUT / p["phase_directory"]
    receipt = C.read_json(phase / "native-complete.json")
    assert receipt["all8_exact_signatures"] is True
    C.assert_all_signatures(receipt["signatures"])
    for record in receipt["raw_bindings"]:
        assert C.sha(record["path"]) == record["SHA256"]
        assert Path(record["path"]).stat().st_size == record["bytes"]
    inputs = {root: {} for root in C.roots(p)}
    for tag in C.ORDER:
        data, records = C.samples(phase / "raw" / tag, tag, p)
        assert all(x in receipt["raw_bindings"] for x in records)
        log = phase / f"{tag}.log"
        assert C.parse_native(log, p)["signatures"] == receipt["signatures"][tag]
        for root, values in data.items():
            inputs[root][tag] = values
    rng = random.Random(p["CI_seed"])
    rows, roots = [], {}
    for root in sorted(inputs):
        comparisons = {}
        for b, brackets in C.BRACKETS.items():
            comparisons[b] = []
            for a in brackets:
                av, bv = inputs[root][a], inputs[root][b]
                low, high = interval(av, bv, rng, p["CI_resamples"])
                row = {
                    "root": root,
                    "B": b,
                    "A": a,
                    "mean_ratio_minus1": statistics.fmean(bv) / statistics.fmean(av) - 1,
                    "CI95_lower": low,
                    "CI95_upper": high,
                }
                rows.append(row)
                comparisons[b].append(row)
            assert len(comparisons[b]) == 2
        roots[root] = root_gate(comparisons)
    assert len(rows) == 40
    passed = global_gate(roots)
    C.write_json(
        phase / "statistics.json",
        {
            "protocol_SHA256": C.sha(C.OUT / "protocol-v1.json"),
            "native_receipt_SHA256": C.sha(phase / "native-complete.json"),
            "seed": 334,
            "resamples": 100000,
            "comparisons": rows,
            "roots": roots,
            "method": "50 independent normalized samples; meanB/meanA-1 percentile95; no outlier removal",
            "robust_plain_benefit": passed,
            "mixed_retained": True,
            "same_work_all23_Action_valuebits_PV_stop": True,
            "scope": "five fixed completed-depth3 roots only; no strength/games/default adoption",
        },
    )
    print(json.dumps({"comparisons": 40, "robust_plain_benefit": passed}), flush=True)


if __name__ == "__main__":
    main()
