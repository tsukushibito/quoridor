"""One finite fixed ABBAABBA entry plus saved CI; never retry failed phases."""

import fcntl
import json
import os
from pathlib import Path
import shutil
import sys
import time
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).resolve().parent))
import plain_control as C

ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as P

LOCK = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"


def utc():
    return datetime.now(timezone.utc).isoformat()


def quiet():
    ancestors, pid = {os.getpid()}, os.getpid()
    while pid > 1:
        pid = int(
            next(
                x.split()[1]
                for x in Path(f"/proc/{pid}/status").read_text().splitlines()
                if x.startswith("PPid:")
            )
        )
        ancestors.add(pid)
    found = []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdecimal() or int(proc.name) in ancestors:
            continue
        try:
            comm = (proc / "comm").read_text().strip()
            argv = (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
            executable = os.readlink(proc / "exe")
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        payload = (
            executable.startswith(str(ROOT))
            and any(x in executable for x in ("/private/", "/target/"))
            and not comm.startswith("python")
        )
        analysis = (
            comm.startswith("python")
            and str(ROOT) in argv
            and any(
                x in argv
                for x in (
                    "plain_worker",
                    "plain_v",
                    "analyze_v",
                    "analysis_ci",
                    "statistics.py",
                    "software.py",
                    "numeric",
                    "finite-driver",
                    "torch",
                    "pilot-worker",
                    "pilot_worker",
                    "generate_dataset",
                    "qualification_worker",
                    "recovery_worker",
                )
            )
        )
        browser = comm in ("chrome", "chromium", "firefox", "headless_shell")
        if comm in ("cargo", "rustc", "clippy-driver", "perf") or payload or analysis or browser:
            found.append({"pid": int(proc.name), "comm": comm, "argv": argv[:700]})
    if found:
        raise RuntimeError("Actual competitor: refuse/defer, no queue/kill: " + json.dumps(found))
    return {"at": utc(), "named_competitors": []}


def source_check(p):
    binding = C.read_json(C.OUT / p["source_binding"])
    for name, record in binding["bindings"].items():
        path = C.WT / name
        assert C.sha(path) == record["SHA256"], name
        assert path.stat().st_size == record["bytes"], name
        assert path.stat().st_mode & 0o777 == record["mode"], name
    for record in p["private"].values():
        path = Path(record["path"])
        assert C.sha(path) == record["SHA256"]
        assert path.stat().st_size == record["bytes"]
        assert path.stat().st_mode & 0o777 == record["mode"]
    assert C.sha(p["manifest_path"]) == p["manifest_SHA256"]
    assert C.read_json(p["manifest_path"]) == p["manifest_json"]
    assert C.sha(p["weights_path"]) == p["weights_SHA256"]


def entry_check(p):
    source_check(p)
    available = os.sched_getaffinity(0)
    assert {p["CPU"], p["guardian_CPU"]} <= available
    topology = []
    for cpu in (p["CPU"], p["guardian_CPU"]):
        root = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        topology.append(
            [(root / key).read_text().strip() for key in ("physical_package_id", "core_id")]
        )
    assert topology[0] != topology[1]
    assert P.available_memory() > p["family_RAM_B"] + p["host_reserve_B"]
    assert shutil.disk_usage(C.OUT).free > p["whole_storage_B"]
    assert not (C.OUT / p["phase_directory"]).exists()
    assert "LD_PRELOAD" not in os.environ and "LD_AUDIT" not in os.environ
    for key in list(os.environ):
        if key.startswith("QUORIDOR_BENCH_"):
            del os.environ[key]
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "RAYON_NUM_THREADS"):
        os.environ[key] = "1"
    os.environ["QUORIDOR_BENCH_MANIFEST"] = p["manifest_path"]
    os.environ["QUORIDOR_BENCH_FT_MODE"] = "Scalar"
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    return {
        "at": utc(),
        "topology": topology,
        "available_RAM_B": P.available_memory(),
        "free_FS_B": shutil.disk_usage(C.OUT).free,
    }


class Resources(P.CycleResources):
    def __init__(self, p, phase, deadline, settled):
        super().__init__(
            {
                "max_memory_bytes": p["family_RAM_B"] - p["controller_reserve_B"],
                "host_ram_reserve": p["host_reserve_B"],
                "max_output_bytes": p["phase_output_B"],
            },
            phase,
            deadline,
        )
        self.p, self.settled = p, settled
        self.next_storage = 0
        self.sampled_family_RSS_max_B = 0
        self.sampled_new_phase_storage_max_B = 0

    def check(self, owned=()):
        now = time.monotonic()
        if now >= self.deadline or P.available_memory() < self.reserve:
            raise P.CycleStopped("344 deadline or host RAM reserve")
        infos = [P.process_info(os.getpid()), *(P.process_info(x["pid"]) for x in owned)]
        rss = sum(x["rss"] for x in infos if x) + self.p["controller_reserve_B"]
        self.sampled_family_RSS_max_B = max(self.sampled_family_RSS_max_B, rss)
        if rss > self.p["family_RAM_B"]:
            raise P.CycleStopped("344 family RAM cap")
        if now >= self.next_storage:
            amount = C.physical_storage(self.output)
            self.next_storage = now + 1
            self.sampled_new_phase_storage_max_B = max(self.sampled_new_phase_storage_max_B, amount)
            if amount > self.output_limit or self.settled + amount > self.p["whole_storage_B"]:
                raise P.CycleStopped("344 inclusive whole/phase output cap")
            if shutil.disk_usage(self.output).free < 256 * 1024**2:
                raise P.CycleStopped("344 free FS cleanup reserve")


def main():
    assert len(sys.argv) == 1
    p = C.protocol()
    physical = entry_check(p)
    pre = quiet()
    settled = C.physical_storage(C.WT) + p["extra_Git_admin_guard_B"]
    assert settled + p["phase_output_B"] < p["whole_storage_B"]
    # Acquire only for this immediately entering finite interval. No alternate
    # lock, blocking queue, idle slot, new registry, or foreign process signal.
    lock = LOCK.open("a+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        lock.close()
        raise RuntimeError("Actual shared lock owner; defer") from None
    phase = C.OUT / p["phase_directory"]
    records, signatures, raw = [], {}, []
    result = {"status": "failed", "error": None}
    resources = None
    started = time.monotonic()
    try:
        quiet()
        os.sched_setaffinity(0, {p["guardian_CPU"]})
        phase.mkdir()
        C.write_json(
            phase / "START.json",
            {
                "START": utc(),
                "guardian": P.identity(P.process_info(os.getpid())),
                "protocol_SHA256": C.sha(C.OUT / "protocol-v1.json"),
                "target_SHA256": C.sha(C.OUT / "numerical-control-target-v1.json"),
                "pre": pre,
                "physical": physical,
                "settled_with_admin_guard_B": settled,
                "Cargo": 0,
                "shared_lock_owned_actual_interval": True,
            },
        )
        deadline = time.monotonic() + p["whole_deadline_worker_s"]
        resources = Resources(p, phase, deadline, settled)
        for tag in C.ORDER:
            quiet()
            private = p["private"][tag[0]]
            assert C.sha(private["path"]) == private["SHA256"]
            directory = phase / "raw" / tag
            directory.mkdir(parents=True)
            os.environ["QUORIDOR_BENCH_OUTPUT"] = str(directory)
            suffix = [tag if arg == "{TAG}" else arg for arg in p["argv_suffix"]]
            log = phase / f"{tag}.log"
            record = P.execute(
                [p["private"][tag[0]]["path"], *suffix],
                log,
                deadline,
                cpu_core=p["CPU"],
                resources=resources,
            )
            records.append(record)
            parsed = C.parse_native(log, p)
            signatures[tag] = parsed["signatures"]
            if tag != C.ORDER[0]:
                assert signatures[tag] == signatures[C.ORDER[0]], (
                    "same-work requirement refused",
                    tag,
                )
            _, bindings = C.samples(directory, tag, p)
            raw.extend(bindings)
            raw.append({"path": str(log), "SHA256": C.sha(log), "bytes": log.stat().st_size})
        C.assert_all_signatures(signatures)
        C.write_json(
            phase / "native-complete.json",
            {
                "native_STOP": utc(),
                "all8_exact_signatures": True,
                "signatures": signatures,
                "raw_bindings": raw,
                "samples": 2000,
                "native_processes": 8,
                "returned_commands": records,
            },
        )
        quiet()
        records.append(
            P.execute(
                ["/usr/bin/python3", "-I", "-B", str(C.OUT / "analysis_ci.py")],
                phase / "analysis.log",
                deadline,
                cpu_core=p["CPU"],
                resources=resources,
            )
        )
        C.protocol()
        source_check(p)
        result["status"] = "complete"
    except BaseException as error:
        result["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        try:
            if phase.exists():
                result.update(
                    {
                        "worker_STOP": utc(),
                        "whole_worker_s": time.monotonic() - started,
                        "returned_commands": records,
                        "completed_native_processes": len(signatures),
                        "completed_signatures": signatures,
                        "raw_bindings": raw,
                        "sampled_family_RSS_max_B": resources.sampled_family_RSS_max_B
                        if resources
                        else None,
                        "sampled_new_phase_storage_max_B": resources.sampled_new_phase_storage_max_B
                        if resources
                        else None,
                        "continuous_peak": "UNKNOWN",
                        "no_automatic_retry": True,
                        "TMP_created": [],
                        "Cargo": 0,
                        "source_writes": 0,
                    }
                )
                C.write_json(phase / "worker-result.json", result)
        finally:
            try:
                fcntl.flock(lock, fcntl.LOCK_UN)
            finally:
                lock.close()


if __name__ == "__main__":
    with P.cancellation_signals():
        main()
