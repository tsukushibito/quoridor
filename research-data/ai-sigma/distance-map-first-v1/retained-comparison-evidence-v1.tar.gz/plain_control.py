"""Fixed344 admission and raw-data checks; no alternate engine or model loader."""

import hashlib
import json
import math
import os
from pathlib import Path

OUT = Path(__file__).resolve().parent
WT = OUT.parent.parent
ORDER = ("A0", "B1", "B2", "A3", "A4", "B5", "B6", "A7")
BRACKETS = {"B1": ["A0", "A3"], "B2": ["A0", "A3"], "B5": ["A4", "A7"], "B6": ["A4", "A7"]}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    p = Path(path)
    if p.stat().st_size > 1024**2:
        raise ValueError("oversized control/raw JSON")
    return json.loads(p.read_text())


def write_json(path, data):
    with Path(path).open("x") as stream:
        json.dump(data, stream, indent=2, allow_nan=False)
        stream.write("\n")


def protocol():
    target = read_json(OUT / "numerical-control-target-v1.json")
    for name, expected in target["fixed_bindings"].items():
        p = Path(name)
        assert sha(p) == expected["SHA256"], name
        assert p.stat().st_size == expected["bytes"], name
        assert p.stat().st_mode & 0o777 == expected["mode"], name
    p = read_json(OUT / "protocol-v1.json")
    assert p["order"] == list(ORDER) and p["brackets"] == BRACKETS
    assert (p["samples"], p["warmup_s"], p["measurement_s"]) == (50, 1, 3)
    assert (p["CI_seed"], p["CI_resamples"]) == (334, 100000)
    assert p["CI_percentiles"] == [0.025, 0.975]
    assert (p["benefit_upper"], p["adverse_lower"]) == (-0.01, 0.01)
    assert (p["B_per_root_required"], p["roots_required"]) == (3, 3)
    assert p["all_23_counters_required"] and p["no_adverse_roots_required"]
    assert p["argv_suffix"] == [
        "--bench",
        "--sample-size",
        "50",
        "--warm-up-time",
        "1",
        "--measurement-time",
        "3",
        "--save-baseline",
        "{TAG}",
    ]
    c = p["config"]
    assert (c["depth"], c["max_nodes"], c["tt_entries"]) == (3, 100000, 4096)
    assert c["use_pvs"] and c["evaluation_mode"] == "Scalar"
    assert c["rules"] == "research-standard-2p-threefold-goal-first-v1"
    assert len(p["fixtures"]) == 5 and p["fixtures"] == c["fixtures"]
    assert sha(OUT / p["source_binding"]) == p["source_binding_SHA256"]
    assert sha(OUT / "qualified-software-STOP-v1.json") == p["software_receipt_SHA256"]
    return p


def roots(p):
    result = [x["name"] for x in p["fixtures"]]
    assert len(result) == len(set(result)) == 5
    return result


def parse_native(path, p):
    records = []
    for line in Path(path).read_text().splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict) and row.get("kind", "").startswith("map344_"):
            records.append(row)
    scopes = [x for x in records if x["kind"] == "map344_scope"]
    pre = [x for x in records if x["kind"] == "map344_preflight"]
    assert len(records) == 6 and len(scopes) == 1 and len(pre) == 5
    scope = scopes[0]
    assert scope["manifest_path"] == p["manifest_path"]
    assert scope["manifest"] == p["manifest_json"]
    assert scope["config"] == p["config"]
    assert scope["historical_config_weights_placeholder"] == p["historical_placeholder"]
    signatures = {}
    for row in pre:
        name, signature = row["fixture"], row["signature"]
        assert name in roots(p) and name not in signatures
        assert row["parent_restored"] is True and row["PV_legal"] is True
        assert row["counters_reported"] == 23
        assert set(signature) == set(p["signature_fields"])
        assert signature["depth"] == 3 and signature["stop"] == "DepthComplete"
        action, bits = signature["action"], signature["value_bits"]
        assert type(action) is int and 0 <= action < 209
        assert type(bits) is int and 0 <= bits < 2**32 and (bits >> 23) & 255 != 255
        assert isinstance(signature["pv"], list) and signature["pv"]
        assert signature["pv"][0] == action
        assert all(type(a) is int and 0 <= a < 209 for a in signature["pv"])
        counters = signature["counters"]
        assert len(counters) == 23 and all(type(x) is int and x >= 0 for x in counters)
        signatures[name] = signature
    assert set(signatures) == set(roots(p))
    return {"scope": scope, "signatures": signatures}


def normalized_samples(data):
    assert len(data["iters"]) == len(data["times"]) == 50
    result = []
    for iterations, duration in zip(data["iters"], data["times"], strict=True):
        assert not isinstance(iterations, bool) and not isinstance(duration, bool)
        assert math.isfinite(iterations) and iterations > 0
        assert math.isfinite(duration) and duration > 0
        value = duration / iterations
        assert math.isfinite(value) and value > 0
        result.append(value)
    return result


def samples(directory, tag, p):
    # Criterion's `new` copy is not a second measurement. Match the exact full
    # benchmark ID from its named-baseline metadata, never a guessed path slug.
    paths = [x for x in Path(directory).rglob("sample.json") if x.parent.name == tag]
    assert len(paths) == 5
    result, records = {}, []
    expected = {f"search/cold_setup_search_drop/{root}": root for root in roots(p)}
    for sample in sorted(paths):
        metadata = sample.with_name("benchmark.json")
        full_id = read_json(metadata)["full_id"]
        assert full_id in expected
        root = expected[full_id]
        assert root not in result
        result[root] = normalized_samples(read_json(sample))
        for path in (sample, metadata):
            records.append({"path": str(path), "SHA256": sha(path), "bytes": path.stat().st_size})
    assert set(result) == set(roots(p))
    return result, records


def assert_all_signatures(signatures):
    assert set(signatures) == set(ORDER)
    for tag in ORDER[1:]:
        assert signatures[tag] == signatures[ORDER[0]], ("changed or incomplete work", tag)


def physical_storage(path):
    total, seen = 0, set()
    for directory, _, files in os.walk(path):
        for name in files:
            info = (Path(directory) / name).lstat()
            key = (info.st_dev, info.st_ino)
            if key not in seen:
                seen.add(key)
                total += max(info.st_size, info.st_blocks * 512)
    return total
