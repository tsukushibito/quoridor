"""Finite affected software entry; one owned nonblocking canonical Cargo lock."""

import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
from datetime import datetime, timezone

ROOT = Path("/workspaces/quoridor")
WT = ROOT / ".worktree/distance-map-first"
OUT = WT / ".artifacts/distance-map-first-v1"
sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as P


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


def quiet():
    allowed = os.sched_getaffinity(0)
    # The guardian itself is already pinned to CPU2; inspect kernel topology,
    # not its narrowed affinity, before claiming distinct physical workers.
    cores = []
    for cpu in (0, 2):
        topology = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        cores.append(
            (
                (topology / "physical_package_id").read_text().strip(),
                (topology / "core_id").read_text().strip(),
            )
        )
    assert cores[0] != cores[1]
    assert 2 in allowed
    ancestors, pid = {os.getpid()}, os.getpid()
    while pid > 1:
        pid = int(
            next(
                x.split()[1]
                for x in Path(f"/proc/{pid}/status").read_text().splitlines()
                if x.startswith("PPid:")
            )
        )
        ancestors.add(pid)
    found = []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdecimal() or int(proc.name) in ancestors:
            continue
        try:
            comm = (proc / "comm").read_text().strip()
            argv = (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
            executable = os.readlink(proc / "exe")
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        payload = (
            executable.startswith(str(ROOT))
            and ("/private/" in executable or "/target/" in executable)
            and comm not in ("python", "python3")
        )
        analysis = comm.startswith("python") and any(
            x in argv
            for x in (
                "plain_v",
                "analyze_v",
                "/statistics.py",
                "numeric-recovery",
                "finite-driver",
                "torch",
                "pilot-worker",
                "generate_dataset",
            )
        )
        if comm in ("cargo", "rustc", "clippy-driver", "perf") or payload or analysis:
            found.append({"pid": int(proc.name), "comm": comm, "argv": argv[:700]})
    if found:
        raise RuntimeError(
            "Actual compute competitor; refuse/defer, never queue: " + json.dumps(found)
        )
    return {"at": utc(), "named_compute_competitors": []}


def source_check(version="B"):
    binding = json.loads((OUT / "source-stop.json").read_text())
    changed = set(binding["candidate_production_files"])
    for name, record in binding["bindings"].items():
        expected = record["SHA256"]
        if name in changed:
            data = gzip.decompress((OUT / f"{version}-{Path(name).name}.gz").read_bytes())
            expected = hashlib.sha256(data).hexdigest()
        assert sha(WT / name) == expected, name
        assert (WT / name).stat().st_mode & 0o777 == record["mode"], name
    for name, expected in binding["control_bindings"].items():
        assert sha(Path(name)) == expected, name
    assert sha(Path(binding["model_manifest"])) == binding["manifest_SHA256"]
    assert sha(Path(binding["weights_path"])) == binding["weights_SHA256"]
    return binding


class Resources(P.CycleResources):
    def __init__(self, deadline):
        super().__init__(
            {
                "max_memory_bytes": 6 * 1024**3 - 64 * 1024**2,
                "host_ram_reserve": 4 * 1024**3,
                "max_output_bytes": 2 * 1024**3 - 8 * 1024**2,
            },
            WT,
            deadline,
        )
        self.sampled_family_RSS_max = 0

    def check(self, owned=()):
        super().check(owned)
        infos = [P.process_info(os.getpid()), *(P.process_info(x["pid"]) for x in owned)]
        self.sampled_family_RSS_max = max(
            self.sampled_family_RSS_max, sum(x["rss"] for x in infos if x) + 64 * 1024**2
        )


def switch(version, binding):
    for name in binding["candidate_production_files"]:
        path = WT / name
        data = gzip.decompress((OUT / f"{version}-{path.name}.gz").read_bytes())
        path.write_bytes(data)
    source_check(version)


def image(version, deadline, resources, records):
    log = OUT / f"image-{version}.log"
    quiet()
    records.append(
        P.execute(
            [
                shutil.which("cargo"),
                "bench",
                "--profile",
                "release",
                "--offline",
                "--locked",
                "-j",
                "1",
                "-p",
                "quoridor-ai",
                "--features",
                "research",
                "--bench",
                "nnue_search",
                "--no-run",
                "--message-format=json-render-diagnostics",
            ],
            log,
            deadline,
            cpu_core=0,
            resources=resources,
        )
    )
    artifacts = []
    for line in log.read_text().splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if row.get("reason") == "compiler-artifact":
            artifacts.append(row)
    bench = [
        r
        for r in artifacts
        if r.get("target", {}).get("name") == "nnue_search" and r.get("executable")
    ]
    assert len(bench) == 1 and bench[0]["fresh"] is False
    src = Path(bench[0]["executable"])
    destination = OUT / "private" / f"{version}-nnue-search"
    assert not destination.exists()
    shutil.copy2(src, destination)
    return {
        "path": str(destination),
        "SHA256": sha(destination),
        "bytes": destination.stat().st_size,
        "mode": destination.stat().st_mode & 0o777,
        "bench_metadata": bench[0],
        "owned_library_metadata": [
            r
            for r in artifacts
            if r["target"]["name"] in ("quoridor_ai", "quoridor_nnue", "quoridor_core")
        ],
        "production_sources": {
            name: sha(WT / name)
            for name in (
                "crates/quoridor-nnue/src/features.rs",
                "crates/quoridor-nnue/src/lib.rs",
                "crates/quoridor-ai/src/alphabeta.rs",
                "crates/quoridor-core/src/position.rs",
                "crates/quoridor-core/src/research.rs",
            )
        },
        "harness_SHA256": sha(WT / "crates/quoridor-ai/benches/nnue_search.rs"),
        "config_SHA256": sha(WT / "crates/quoridor-ai/benches/nnue_search.json"),
    }


def main():
    os.sched_setaffinity(0, {2})
    binding = source_check()
    pre = quiet()
    assert P.available_memory() > 8 * 1024**3
    assert shutil.disk_usage(OUT).free > 3 * 1024**3
    for name in (
        "RUSTFLAGS",
        "CARGO_ENCODED_RUSTFLAGS",
        "CARGO_PROFILE_RELEASE_DEBUG",
        "CARGO_PROFILE_RELEASE_LTO",
        "CARGO_PROFILE_RELEASE_CODEGEN_UNITS",
    ):
        assert not os.environ.get(name), name
    if "--check-source" in sys.argv:
        print(
            json.dumps(
                {"source_check": "PASS", "physical_quiet": pre, "Cargo_model_tests_Search": 0}
            )
        )
        return
    assert not (OUT / "software-result.json").exists()
    lock_path = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock_path.open("a") as lock, P.cancellation_signals():
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        os.chdir(WT)
        tmp = OUT / "TMP-software"
        assert not tmp.exists()
        tmp.mkdir()
        (OUT / "private").mkdir(exist_ok=True)
        os.environ.update(
            {
                "CARGO_TARGET_DIR": str(OUT / "target"),
                "TMPDIR": str(tmp),
                "CARGO_BUILD_JOBS": "1",
                "RAYON_NUM_THREADS": "1",
                "PYTHONDONTWRITEBYTECODE": "1",
            }
        )
        start, deadline = time.monotonic(), time.monotonic() + 720
        resources, commands = Resources(deadline), []
        receipt = {
            "START": utc(),
            "outcome": "FAILED",
            "before": pre,
            "source_stop_SHA256": sha(OUT / "source-stop.json"),
            "commands": commands,
            "private": {},
            "external_model_weight_loads_plain_perf_games": 0,
            "synthetic_NN0_Search_FT": "Only the prebound affected qualification tests",
            "compiler_logical_CPU": 0,
            "guardian_logical_CPU": 2,
            "distinct_physical_cores_verified": True,
        }
        P.write_json(OUT / "software-start.json", receipt)
        try:
            quiet()
            commands.append(
                P.execute(
                    [shutil.which("rustc"), "-Vv"],
                    OUT / "compiler.log",
                    deadline,
                    cpu_core=0,
                    resources=resources,
                )
            )
            selected = [
                [
                    "test",
                    "-p",
                    "quoridor-nnue",
                    "--features",
                    "research",
                    "--lib",
                    "distance_map_pool",
                ],
                ["test", "-p", "quoridor-nnue", "--features", "research", "--test", "move_buffer"],
                [
                    "test",
                    "-p",
                    "quoridor-ai",
                    "--features",
                    "research",
                    "--test",
                    "distance_map_pool",
                ],
                ["clippy", "-p", "quoridor-nnue", "--features", "research", "--lib", "--no-deps"],
                [
                    "clippy",
                    "-p",
                    "quoridor-ai",
                    "--features",
                    "research",
                    "--lib",
                    "--test",
                    "distance_map_pool",
                    "--bench",
                    "nnue_search",
                    "--no-deps",
                ],
            ]
            for i, args in enumerate(selected):
                source_check()
                quiet()
                command = [
                    shutil.which("cargo"),
                    args[0],
                    "--profile",
                    "release",
                    "--offline",
                    "--locked",
                    "-j",
                    "1",
                    *args[1:],
                ]
                command.extend(
                    ["--", "-D", "warnings"] if args[0] == "clippy" else ["--", "--nocapture"]
                )
                commands.append(
                    P.execute(
                        command,
                        OUT / f"qualification-{i}.log",
                        deadline,
                        cpu_core=0,
                        resources=resources,
                    )
                )
            receipt["private"]["B"] = image("B", deadline, resources, commands)
            switch("A", binding)
            receipt["private"]["A"] = image("A", deadline, resources, commands)
            receipt["outcome"] = "PASS"
        finally:
            switch("B", binding)
            receipt.update(
                {
                    "worker_STOP": utc(),
                    "worker_whole_seconds": time.monotonic() - start,
                    "restored_B_bindings": "PASS",
                    "sampled_family_RSS_max_B": resources.sampled_family_RSS_max,
                    "continuous_peak": "UNKNOWN",
                    "TMP_remaining": sorted(p.name for p in tmp.iterdir()),
                    "failed_fees_retained": True,
                }
            )
            if not receipt["TMP_remaining"]:
                tmp.rmdir()
            P.write_json(OUT / "software-result.json", receipt)
            fcntl.flock(lock, fcntl.LOCK_UN)
    print(
        json.dumps(
            {
                "outcome": receipt["outcome"],
                "worker_STOP": receipt["worker_STOP"],
                "private": list(receipt["private"]),
            }
        )
    )


if __name__ == "__main__":
    main()
