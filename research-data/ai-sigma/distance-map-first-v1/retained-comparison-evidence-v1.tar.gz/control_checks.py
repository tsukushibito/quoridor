"""Tiny counterfeit-data/control refusal checks. No models, ELF, or Search."""

import copy
import json
from pathlib import Path
import random
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analysis_ci as A
import plain_control as C


def refuses(action):
    try:
        action()
    except (AssertionError, ValueError, KeyError):
        return
    raise AssertionError("malformed fixture was accepted")


def main():
    p = C.read_json(C.OUT / "protocol-v1.json")
    scope = {
        "kind": "map344_scope",
        "manifest_path": p["manifest_path"],
        "manifest": p["manifest_json"],
        "config": p["config"],
        "historical_config_weights_placeholder": p["historical_placeholder"],
    }
    rows = [
        scope,
        *[
            {
                "kind": "map344_preflight",
                "fixture": name,
                "parent_restored": True,
                "PV_legal": True,
                "counters_reported": 23,
                "signature": {
                    "action": 13,
                    "value_bits": 0,
                    "depth": 3,
                    "pv": [13],
                    "stop": "DepthComplete",
                    "counters": list(range(23)),
                },
            }
            for name in C.roots(p)
        ],
    ]
    with tempfile.TemporaryDirectory(prefix="control-mock-", dir=C.OUT) as directory:
        path = Path(directory) / "mock.log"

        def parse(data):
            path.write_text("\n".join(json.dumps(x) for x in data) + "\n")
            return C.parse_native(path, p)

        valid = parse(rows)
        signatures = {tag: copy.deepcopy(valid["signatures"]) for tag in C.ORDER}
        C.assert_all_signatures(signatures)
        root = C.roots(p)[0]
        changed = copy.deepcopy(signatures)
        changed["B6"][root]["counters"][22] += 1
        refuses(lambda: C.assert_all_signatures(changed))
        for field, value in (
            ("depth", 2),
            ("stop", "NodeLimit"),
            ("value_bits", 0x7F800000),
            ("pv", [14]),
            ("counters", list(range(22))),
        ):
            bad = copy.deepcopy(rows)
            bad[1]["signature"][field] = value
            refuses(lambda: parse(bad))
        bad = copy.deepcopy(rows)
        bad[1]["parent_restored"] = False
        refuses(lambda: parse(bad))
        bad = copy.deepcopy(rows)
        bad[0]["manifest"]["weights_SHA"] = p["historical_placeholder"]
        refuses(lambda: parse(bad))
        refuses(lambda: parse(rows[:-1]))
        refuses(lambda: parse([*rows, rows[1]]))
        sample = {"iters": [2] * 50, "times": [6] * 50}
        assert C.normalized_samples(sample) == [3] * 50
        for bad in (
            {"iters": [0] * 50, "times": [6] * 50},
            {"iters": [2] * 49, "times": [6] * 49},
            {"iters": [2] * 50, "times": [float("nan")] * 50},
        ):
            refuses(lambda: C.normalized_samples(bad))
        for name in C.roots(p):
            baseline = Path(directory) / name / "A0"
            baseline.mkdir(parents=True)
            (baseline / "sample.json").write_text(json.dumps(sample))
            (baseline / "benchmark.json").write_text(
                json.dumps({"full_id": f"search/cold_setup_search_drop/{name}"})
            )
            duplicate = baseline.parent / "new"
            duplicate.mkdir()
            (duplicate / "sample.json").write_text(json.dumps(sample))
        data, records = C.samples(directory, "A0", p)
        assert len(data) == 5 and len(records) == 10
        first = Path(directory) / C.roots(p)[0] / "A0" / "benchmark.json"
        first.write_text(json.dumps({"full_id": "ft/full_context/initial"}))
        refuses(lambda: C.samples(directory, "A0", p))
    assert A.percentile([0, 1, 2, 3], 0.5) == 1.5
    low, high = A.interval([100] * 50, [98] * 50, random.Random(334), 100)
    assert abs(low + 0.02) < 1e-12 and abs(high + 0.02) < 1e-12
    benefit = {
        b: [{"CI95_upper": -0.02, "CI95_lower": -0.03} for _ in range(2)] for b in C.BRACKETS
    }
    assert A.root_gate(benefit)["robust_benefit"]
    one_flank = copy.deepcopy(benefit)
    for rows in list(one_flank.values())[:2]:
        rows[1]["CI95_upper"] = 0
        assert rows[0]["CI95_upper"] == -0.02
    assert not A.root_gate(one_flank)["robust_benefit"]
    three = copy.deepcopy(benefit)
    three["B6"][1]["CI95_upper"] = 0
    assert A.root_gate(three)["beneficial_B_of4"] == 3
    assert A.root_gate(three)["robust_benefit"]
    adverse = {b: [{"CI95_lower": 0.02, "CI95_upper": 0.03}] * 2 for b in C.BRACKETS}
    assert A.root_gate(adverse)["reproducible_adverse"]
    global_roots = {
        str(i): {"robust_benefit": i < 2, "reproducible_adverse": False} for i in range(5)
    }
    assert not A.global_gate(global_roots)
    global_roots["2"]["robust_benefit"] = True
    assert A.global_gate(global_roots)
    global_roots["4"]["reproducible_adverse"] = True
    assert not A.global_gate(global_roots)
    print(
        json.dumps(
            {
                "status": "PASS",
                "scope": "counterfeit signatures/samples, full benchmark IDs, two-flank and symmetric gates, tiny constant oracle",
                "models_ELF_Search_native_Cargo": 0,
                "production_resampling": 0,
                "TMP": [],
            }
        )
    )


if __name__ == "__main__":
    main()
