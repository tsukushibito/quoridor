CRITIC_INTAKE quoridor-4lc.111 / 契約1・枠7
全文/common/critic/現行枠7/記録規約、ready/show goal/self・pauseなし・本人担当確認後111だけclaim。保守受領08:33:31UTC、処理09:18/newrun09:13/提出09:28。source/binary/schemaを先行照合、最終dataは到着後版をbindする。指定asym baseline→C1、jump C1→baseline各K32の4検索のみ事前固定、外heavy0/headroom/停止入力確認後直列。原110編集/新build/対局holdout/Node毎手審判0。C感度/500ms責任loss/時計成立を分け、正式NI/採用未認定。通常debugは同予算内、原失敗保持。
