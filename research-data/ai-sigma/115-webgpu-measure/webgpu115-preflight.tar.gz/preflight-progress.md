EXPERIMENT_PROGRESS .115
hostRTX3060/VRAM1.5GiB/readmonitor可、compute app表空、/dev/dxg存在。Vulkan ICD設定空/graphics driver非公開の疑い。r1は相対command path不具合(NN0)、r2はChromium起動後launcher AFFINITY_GUARD/回収再検査例外を保存。記録全identity currentabsence0確認、当時outerwait完了ではない。ブラウザログVulkan初期化失敗は環境不足候補だが、このguard停止をGPU/SAB否定にはしない。自域launcher修正と小診断継続、モデルNN/対局0。
