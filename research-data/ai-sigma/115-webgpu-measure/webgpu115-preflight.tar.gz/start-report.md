EXPERIMENT_START quoridor-4lc.115 / frame8
受領10:24:17UTC、ready/show goal/self・pauseなし・担当確認後115のみ本人claim。現契約全文/同版ORT公式asset取得差分受領。処理11:24:17/newrun11:19:17/提出11:34:17。実GPU/VRAM/Chromium compute preflight開始。host NVIDIA RTX3060/VRAM1496MiB・compute apps空は観測のみ、モデルGPU実行証拠ではない。CPU2/RAM6guard5.5/VRAM6/保存128guard112既entry内、旧112/113原write0、対局holdout0。
