//! Private, comparison-only observer. No production API or alternate arithmetic.
use super::*;
use quoridor_core::research::SigmaContext;
use serde_json::json;
use std::{cell::RefCell, time::Instant};
thread_local! { static SPANS: RefCell<([u64;7],[u64;7])> = const { RefCell::new(([0;7],[0;7])) }; }
pub(super) fn record(k: usize, t: Instant) {
    let n = t.elapsed().as_nanos() as u64;
    SPANS.with(|s| {
        let mut s = s.borrow_mut();
        s.0[k] += n;
        s.1[k] += 1;
    });
}
fn take() -> ([u64; 7], [u64; 7]) {
    SPANS.with(|s| std::mem::replace(&mut *s.borrow_mut(), ([0; 7], [0; 7])))
}
#[test]
fn diagnostic277_advance() {
    assert_eq!(std::env::var("ORT_DISABLE_TELEMETRY").as_deref(), Ok("1"));
    let cfg: serde_json::Value =
        serde_json::from_slice(&fs::read(std::env::var("DIAGNOSTIC277_CONFIG").unwrap()).unwrap())
            .unwrap();
    assert_eq!(cfg["task"], "frame22-advance-tt-277-v1");
    let model = Model::load(cfg["model"].as_str().unwrap()).unwrap();
    let mut rows = Vec::new();
    let mut nn = 0;
    for f in cfg["fixtures"].as_array().unwrap() {
        let prefix: Vec<u16> = serde_json::from_value(f["prefix"].clone()).unwrap();
        let c = SigmaContext::from_prefix(&prefix).unwrap();
        let position = c.position();
        let history = c.history_counts();
        let ply = c.total_ply();
        let parent = model.full_context(&c, EvaluationMode::Scalar).unwrap();
        let parent_bits: Vec<_> = parent
            .values
            .iter()
            .flatten()
            .map(|v| v.to_bits())
            .collect();
        for action in c.legal_ids() {
            let mut child = c.clone();
            child.play(action).unwrap();
            take();
            let start = Instant::now();
            let a = model.delta_context(&parent, &child).unwrap();
            let advance_ns = start.elapsed().as_nanos() as u64;
            let start = Instant::now();
            let v = model.evaluate(&a).unwrap();
            let evaluate_ns = start.elapsed().as_nanos() as u64;
            let (spans, calls) = take();
            let fresh = model.full_context(&child, EvaluationMode::Scalar).unwrap();
            let fv = model.evaluate(&fresh).unwrap();
            nn += 2;
            assert_eq!(a.features, fresh.features);
            assert!(v.is_finite() && (v - fv).abs() <= 2e-6);
            assert_eq!(
                parent_bits,
                parent
                    .values
                    .iter()
                    .flatten()
                    .map(|v| v.to_bits())
                    .collect::<Vec<_>>()
            );
            assert_eq!(c.position(), position);
            assert_eq!(c.history_counts(), history);
            assert_eq!(c.total_ply(), ply);
            assert!(spans.iter().sum::<u64>() <= advance_ns);
            rows.push(json!({"fixture":f["name"],"prefix":prefix,"action":action,"side":child.position().turn,"advance_ns":advance_ns,"evaluate_ns":evaluate_ns,"exclusive_ns":spans,"calls":calls,"value_bits":v.to_bits(),"full_value_bits":fv.to_bits(),"abs_delta":(v-fv).abs(),"parent_unchanged":true,"feature_equal":true,"history_ply_restored":true}));
        }
    }
    assert_eq!(rows.len(), 503);
    assert_eq!(nn, 1006);
    let result = json!({"task":"frame22-advance-tt-277-v1","schema":"advance-components-v1","status":"PASS","model_fingerprint":model.fingerprint(),"native_nn":nn,"processed_search_nodes":0,"rows":rows,"exclusive_order":["map_cachehit","two_goal_wallmaps_build","sorted_IDs","STM_distance_lookup","parent_feature_validation","two_values_clone","IDs_difference_plus_FT_arithmetic_and_finite"],"scope":"exclusive nested owned advance spans; advance inclusive, evaluate separate; observer overhead/remainder not an exclusive algorithm cost"});
    fs::write(
        cfg["advance_output"].as_str().unwrap(),
        serde_json::to_vec_pretty(&result).unwrap(),
    )
    .unwrap();
}
