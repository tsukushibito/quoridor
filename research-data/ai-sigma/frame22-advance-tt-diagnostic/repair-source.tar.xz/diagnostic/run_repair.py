"""One joined diagnostic group; never builds or repeats a scientific test."""

import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path("/workspaces/quoridor")
cfg = json.loads((OUT / "preregister-v2.json").read_text())
assert cfg["task"] == "frame22-advance-tt-277-v1"
assert os.environ["ORT_DISABLE_TELEMETRY"] == "1"
assert pathlib.Path.cwd() == ROOT / ".worktree/frame21-search"
for rel, expected in cfg["source_hashes"].items():
    assert hashlib.sha256((pathlib.Path.cwd() / rel).read_bytes()).hexdigest() == expected
bins = {}
for line in (OUT / "compile-r2a/stdout.log").read_text().splitlines():
    record = json.loads(line)
    if record.get("reason") == "compiler-artifact" and record.get("profile", {}).get("test"):
        name = record["target"]["name"]
        if name in ("quoridor_nnue", "quoridor_ai"):
            bins[name] = record["executable"]
assert len(bins) == 2
env = dict(os.environ, DIAGNOSTIC277_CONFIG=str(OUT / "preregister-v2.json"))
rows = []
for name in ("quoridor_nnue", "quoridor_ai"):
    argv = [bins[name], "diagnostic277", "--nocapture", "--test-threads=1"]
    start = time.monotonic()
    child = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stat = pathlib.Path(f"/proc/{child.pid}/stat").read_text().rsplit(")", 1)[1].split()
    tick = stat[19]
    stdout, stderr = child.communicate(timeout=25)
    (OUT / f"repair-{name}-stdout.log").write_bytes(stdout)
    (OUT / f"repair-{name}-stderr.log").write_bytes(stderr)
    p = pathlib.Path(f"/proc/{child.pid}/stat")
    exact = p.exists() and p.read_text().rsplit(")", 1)[1].split()[19] == tick
    row = dict(
        name=name,
        argv=argv,
        binary_sha=hashlib.sha256(pathlib.Path(bins[name]).read_bytes()).hexdigest(),
        pid=child.pid,
        tick=tick,
        exit_code=child.returncode,
        waited=True,
        current_exact_absent=not exact,
        wall_seconds=time.monotonic() - start,
    )
    rows.append(row)
    (OUT / "child-receipts-v2.json").write_text(json.dumps(rows, indent=2) + "\n")
    if child.returncode or exact:
        sys.exit(1)
a = json.loads(pathlib.Path(cfg["advance_output"]).read_text())
b = json.loads(pathlib.Path(cfg["tt_output"]).read_text())
assert a["task"] == b["task"] == cfg["task"] and a["status"] == b["status"] == "PASS"
assert a["native_nn"] + b["native_nn"] <= cfg["repair_native_nn_upper"]
assert b["processed"] <= cfg["repair_processed_upper"]
(OUT / "science-completion-v2.json").write_text(
    json.dumps(
        dict(
            task=cfg["task"],
            schema="advance-tt-diagnostic-completion-v1",
            status="PASS",
            native_nn=a["native_nn"] + b["native_nn"],
            processed=b["processed"],
            children=rows,
            at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        ),
        indent=2,
    )
    + "\n"
)
