import json, os, time
from pathlib import Path
from quoridor_training.cycle_process import CycleResources, execute, cancellation_signals
root=Path('/workspaces/quoridor/.artifacts/research-coordination/main-integration')
os.chdir('/workspaces/quoridor')
os.sched_setaffinity(0,{0,1})
os.environ.update(CARGO_TARGET_DIR='/workspaces/quoridor/.artifacts/rust-migration/target',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',TMPDIR=str(root/'tmp'))
(root/'tmp').mkdir(exist_ok=True)
commands=[
 ('data',['cargo','test','--offline','--locked','--release','-p','quoridor-data','--test','external_outcomes','--','--test-threads=1']),
 ('manifest',['cargo','test','--offline','--locked','--release','-p','quoridor-runner','--lib','arena_manifest::tests','--','--test-threads=1']),
 ('arena-config',['cargo','test','--offline','--locked','--release','-p','quoridor-runner','--test','arena','--test','config','--','--test-threads=1']),
 ('native-undo',['cargo','test','--offline','--locked','--release','-p','quoridor-runner','--bin','nnue-diagnose','qualification_actions_and_inplace_undo_match_immutable_oracle_nn0','--','--test-threads=1']),
 ('build',['cargo','build','--offline','--locked','--release','-p','quoridor-runner','--bin','quoridor-runner','--bin','nnue-diagnose']),
 ('clippy',['cargo','clippy','--offline','--locked','--release','-p','quoridor-runner','--lib','--bin','quoridor-runner','--bin','nnue-diagnose','--test','arena','--','-D','warnings']),
]
begin=time.monotonic();deadline=begin+240;resources=CycleResources({'max_memory_bytes':2*1024**3,'max_output_bytes':8*1024**2,'host_ram_reserve':4*1024**3},root,deadline)
result={'scope':'Root user-authorized main integration qualification; CPU0,1/RAM2GiB/GPU0, offline/shared target sole writer after arena exact STOP','commands':[],'new_model_forward':0,'error':None}
try:
 with cancellation_signals():
  for name,argv in commands:
   t=time.monotonic();r=execute(argv,root/(name+'.log'),deadline,resources=resources);result['commands'].append({'name':name,'argv':argv,'exit':r['exit_code'],'direct_child_waited':r['direct_child_reaped'],'remaining':r['remaining'],'wall_seconds':time.monotonic()-t})
except BaseException as exc:
 result['error']=repr(exc);raise
finally:
 result['whole_seconds']=time.monotonic()-begin;result['status']='PASS' if result['error'] is None else 'FAIL';(root/'rust-validation.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
