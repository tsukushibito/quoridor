"""Finish the selected-RUN reference omitted by the first metadata helper."""

import copy
import datetime
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
BASE = Path(__file__).resolve().parent
OUT = BASE / "binding-v2"
OUT.mkdir()
TRIAL = BASE.parent
ENTRY = (
    ROOT
    / ".artifacts/research-team/integration324/cedar-shallow-main-history-v1/forward64-entry-v1"
)


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def document(reference):
    p = Path(reference["path"])
    assert ref(p) == reference
    return json.loads(p.read_bytes())


def save(name, value):
    p = OUT / name
    with p.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")
    return ref(p)


issued_ref = dict(
    path=str(ENTRY / "issued-inputs.json"),
    sha256="d3d3040339c59b021b70c1801590d67de01581bf488e3f73b346152ff6764a15",
    bytes=963,
    mode="0644",
)
issued = document(issued_ref)
release = document(issued["release"])
support_ref = issued["phase_support"]
support = document(support_ref)
prepared = document(support["book_preparation"])
experiment_ref = ref(BASE / "experiment.json")
experiment = document(experiment_ref)
plan_ref = ref(BASE / "plan.json")
plan = document(plan_ref)
config = document(experiment["config"])
assert plan_ref["sha256"] == experiment["canonical_plan_sha256"]
run = document(prepared["controls"]["run"])
run.update(
    artifact=release["artifact"],
    experiment=experiment_ref,
    support=support_ref,
    owned_outputs=support["roots"],
    limits=support["limits"],
    approved_plan=plan_ref,
    caller_sources=release["current_four_callers"],
    data=[
        dict(
            name="journal",
            path=str(Path(config["output"]) / "completed.jsonl.gz"),
            limit_B=support["archive_B_each"],
        ),
        dict(
            name="result",
            path=str(Path(config["output"]) / "result.json"),
            limit_B=4 * 1024**2,
        ),
        dict(
            name="native_manifest",
            path=str(Path(config["output"]) / "manifest.json"),
            limit_B=4 * 1024**2,
        ),
    ],
    argv=[
        release["artifact"]["path"],
        "arena",
        "--experiment",
        experiment_ref["path"],
        "--experiment-sha256",
        experiment_ref["sha256"],
    ],
)
sequence = document(prepared["controls"]["sequence"])
sequence.update(limits=support["limits"], runs=[run])
settings_ref = save("settings.json", sequence)
selected = copy.deepcopy(run)
selected.update(settings=settings_ref, selection_index=0)
reader = dict(
    path=str(ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"),
    mode="LOCK_SH|LOCK_NB",
    leases_remaining=[],
)
with Path(reader["path"]).open("a") as handle:
    fcntl.flock(handle, fcntl.LOCK_SH | fcntl.LOCK_NB)
    reader["acquired_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for caller in release["current_four_callers"]:
        assert ref(Path(caller["path"])) == caller
    loader = importlib.util.spec_from_file_location(
        "forward64_selected_run_owner", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    sys.modules[loader.name] = lc
    loader.loader.exec_module(lc)
    assert lc.approved_plan(selected, experiment) == plan
    fcntl.flock(handle, fcntl.LOCK_UN)
    reader["released_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
job = document(prepared["controls"]["job"])
job.update(
    resource_contract=settings_ref["path"],
    argv=[
        "/home/vscode/.cache/inference/envs/quoridor-training/bin/python",
        "-B",
        str(ROOT / "scripts/dev/research-lifecycle.py"),
        "sequence",
        "--intent",
        settings_ref["path"],
        "--sha256",
        settings_ref["sha256"],
    ],
)
assert job["max_runtime_seconds"] == 2340 and job["end_at"] is None
job_ref = save("job-template.json", job)
result = save(
    "materialized.json",
    dict(
        status="ACTUAL_NEW25_3_FORWARD64_BOUND_UNENTERED",
        issue=job["issue"],
        issued=issued_ref,
        release=issued["release"],
        support=support_ref,
        capacity=issued["capacity"],
        original_book_bound_preparation=support["book_preparation"],
        settings=settings_ref,
        job_template=job_ref,
        experiment=experiment_ref,
        approved_plan=plan_ref,
        state_dir=str(TRIAL / "forward64-native-v1/parent-runtime-v1"),
        source_reader=reader,
        current_callers=release["current_four_callers"],
        successful_v1_checks_reused="Same immutable config/Plan/Experiment/numerical: canonical apply_comparison_arena identity, arena_plan_check64, numerical_fields+numerical_check, caller_source_refs4, native_cpu_cores[0,12] passed before final helper assertion",
        repaired_metadata_boundary="Canonical approved_plan(selected settings ref +selection_index0) now checked; first failure/partial controls preserved, no source/science change",
        original_native_deadline=config["deadline_unix_ms"],
        native_deadline_reset=False,
        parent_accepted_s=2400,
        command_s=2340,
        RUN_s=1800,
        launch_affinity=[0, 12, 18],
        native_START=None,
        actual_origin_end_at="STAMP_ONCE_AT_DIRECT_SUBMIT",
        normal_remaining_admission="Fresh physicalSMT/peers/RAMhost4/source/env/ownerpausecancel/fullroots/free/serializer/origin/cancel/cleanup remain owning runtime",
    ),
)
print(
    json.dumps(
        dict(
            materialized=result,
            settings=settings_ref,
            job=job_ref,
            source_reader=reader,
        )
    )
)
