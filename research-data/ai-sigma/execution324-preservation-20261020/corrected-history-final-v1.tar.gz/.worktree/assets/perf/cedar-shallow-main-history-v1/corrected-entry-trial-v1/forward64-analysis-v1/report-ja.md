# NEW25.3 shallow-main Half versus Current: final64

固定判定は **RETAIN_CURRENT**。Halfは 34W 0D 30L、point 0.53125。全64局・32 opposite-colour family pairs・UNKNOWN0が元の通常manifest/dataで資格確認された。nativeが既に保存した唯一のfamily95 CIは **[0.453125, 0.609375]**。下限>.5は偽であり、有限の採用基準を満たさなかった。

同じgenuine f686/BUILD84fdを両armに用い、Half engine0 / Current engine1 / N1 / Cedar35cbb / Control / baselineLMR / PVS / path_tail / D64 / perSearch1M / 100ms5 / max200 / strict_unknownを維持した。各engineのN1 search-teamでrequested/effective TT slots1048576が保存されている。A/Bの独立sessionが二つあり、合計常駐tableが一つだけという主張はしない。

最初から固定したnative-book ordinals0..31、両色、original seed43220261018、実book attempt_id+1の母数1..32、全prefix/fullweightedhistoryを使用した。保存された64枠/色/32lineage/typed winnerを固定scheduleと対応付け、native pair scoresと一致した。追加のvalidator/geometry/Search/FINALIZEは実行していない。

CIはmaintained arena_statistics.rs custom Rng、seed3242520261020、10000 resamples、floor(.025*9999)/ceil(.975*9999) endpointsのnative保存値のみ。Python/PCG64/linear95/外部bootstrap・再CIは0。全64資格と実STOPを確認後にこのCIを判定に使った。historical exposureと旧family3件の重なりは残り、IID unseen、lineage補正、book全般/Eloの保証ではない。

操作全体のnative charged nodesは 251,909,565/1,024,000,000（opaque reservationsを含む元の会計名を保持）。accepted-inclusive 300.363615sを一度だけ計上し、outer 298.365672738s、native 292.344728552s、archive 0.447487688sはnestedで加算しない。generic report nn_calls=0からCedar実forward0と推定しない。physical forward/fullfees/globalactual/later tailsはUNKNOWN。

元401b/9786/fourUNKNOWN/100unperformed/old64STOPPEDは変更せず、独立NEW104は既にgatePASSで終了、この別許可NEW64も終了した。未使用上限の返却/貸与、refill、roots/coefficientsの再選択、追加局はしない。Current/default/modelを維持する。sessionカウンタのcancellationsは6件（各engine3）あり、errors/initerrors0、全Search invocationがsuccessful、game failureNoneと併記する。内部原因はUNKNOWNで、局のUNKNOWN/取消へ勝手に変換しない。初回保存解析helperのこの混同によるassertion失敗も保存した。今回の基準未達を一般的なHalf劣位・同等・無効果と解釈しない。Rootが受入れと候補専用code/fixturesの最終保守を担当する。
