"""Serialize this fixed, unadmitted arena draft; never execute its controls."""

import copy
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OWN = ROOT / ".worktree/assets/perf/cedar-shallow-main-history-v1"
TRIAL = OWN / "corrected-entry-trial-v1"
OUT = TRIAL / "forward64-preparation-v1"
GIT = "92fb6faa5463e5d4550244b7fb902e0ab05b5a1d"
ACTOR = "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def frozen(path, sha, size):
    data = path.read_bytes()
    assert len(data) == size and hashlib.sha256(data).hexdigest() == sha
    return json.loads(data)


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    return ref(path)


conditional = frozen(
    TRIAL / "conditional64.draft.json",
    "34ac7f1a3ce8c0477f57f3a95133faa1d5df7decfd5a14415ce4faefdcd51cd5",
    3438,
)
frozen(
    OWN / "protocol-v1/conditional64-conditions.json",
    "dc00319e9c23294a0c0825b3aa4352b3c7b403af4f89572d966ffac7cd3a3785",
    3429,
)
families = frozen(
    OWN / "protocol-v1/conditional64-families.json",
    "65ce20a75f80e16b2ce989d15bfc96f42f0c31fb2806863785a263a7ffa3262a",
    33890,
)
lineage = json.loads(Path(families["lineage_metadata"]["path"]).read_text())
attempts = json.loads((OUT / "family-attempt-metadata.json").read_text())
prior = json.loads((TRIAL / "actual-entry-v1/experiment-000.json").read_text())
prior_settings = json.loads((TRIAL / "actual-entry-v1/settings.json").read_text())
oldrun = prior_settings["runs"][0]
model = conditional["model"][0]
openings = []
pool_receipts = []
for f, a in zip(families["families"], attempts["families"], strict=True):
    i = f["native_family_index"]
    selected = lineage["families"][i]
    assert f["request_id"] == a["request_id"] == selected["request_id"]
    assert a["prefix_matches_frozen"] and selected["prefix"] == f["prefix"]
    accepted = [
        x
        for x in a["attempts"]
        if x["rejection"] is None and x["prefix"] == f["prefix"]
    ]
    assert len(accepted) == 1 and type(accepted[0]["attempt"]) is int
    pool = accepted[0]["attempt"] + 1
    pool_receipts.append(
        dict(family_id=i, attempt_id=pool - 1, candidate_pool_size=pool)
    )
    openings.append(
        dict(
            id=f["request_id"],
            cohort="main",
            lineage=f["canonical_family"],
            siblings=[],
            original_seed=None,
            reference=dict(
                source_sha256=families["native_book"]["sha256"],
                model_sha256=None,
                settings=dict(
                    family_id=i,
                    root_key=selected["root"]["state_key"],
                    history_counts=selected["root"]["history"],
                ),
                q_definition=None,
                q_perspective=None,
                q_aggregation=None,
                q=None,
            ),
            selection_reason="Original pre-result first32 canonical book ordinals; no reselection",
            candidate_pool_size=pool,
            prefix=f["prefix"],
        )
    )
pool_ref = save("candidate-pool-receipt.json", pool_receipts)
engines = []
for key in ("candidate", "reference"):
    engine = copy.deepcopy(conditional[key])
    engine.update(
        model=model["descriptor"]["path"],
        distance_a=0.0,
        distance_b=8.0,
        simd=False,
        search_cpu_cores=[12],
    )
    engines.append(engine)
data_root = TRIAL / "forward64-native-v1/data"
config = dict(
    ruleset=conditional["ruleset"],
    run_id="cedar-shallow-main-history-25-3-forward64-v1",
    output=str(data_root),
    games=64,
    workers=1,
    active_games=1,
    max_batch=1,
    max_plies=200,
    seed=3242520261020,
    opening_plies=0,
    openings=[],
    cpu_cores=[12, 12],
    management_cpu_core=0,
    inference=None,
    inference_cpu_core=None,
    engines=engines,
    wall_seconds=None,
    host_ram_reserve=4294967296,
    max_memory_bytes=None,
    max_output_bytes=167772160,
    pause_file=None,
    deadline_unix_ms=None,
    arena=dict(
        comparison="search_wall_time",
        disable_continuation_static_ordering=False,
        decision_only=False,
        clock_policy="strict_unknown",
        return_reserve_ms=5,
        tt_entries=1048576,
        max_total_nodes=1024000000,
        bootstrap_seed=3242520261020,
        bootstrap_resamples=10000,
        evaluator_sha256=[model["evaluator_sha256"]] * 2,
        search_artifact_sha256=[None, None],
        first_candidate_colors=[
            families["games"][2 * i]["candidate_colour"] for i in range(32)
        ],
        retained_outcome_bytes=1048576,
        book=dict(
            id="original25-3-fixed-first32",
            usage="tuning",
            frozen_before_candidate_results=True,
            independence=conditional["decision"]
            + "; historical exposure YES / three old-family overlaps; not IID unseen",
            openings=openings,
        ),
    ),
)
config_ref = save("arena-config.draft.json", config)
schedule = [
    dict(
        slot=g["original_game_index"],
        batch=0,
        matchup=0,
        local_game=g["original_game_index"],
        family_id=g["family_index"],
        candidate_color=g["candidate_colour"],
    )
    for g in families["games"]
]
schedule_ref = save("schedule.json", schedule)
plan = dict(
    schema="quoridor.research.arena-plan.v1",
    phase="arena",
    comparison="search_wall_time",
    rules=prior["rules"],
    distance_units=prior["distance_units"],
    value_perspective=prior["value_perspective"],
    book=families["native_book"],
    inputs=[families["native_book"]],
    models=conditional["model"],
    schedule=schedule_ref,
    family_ids=list(range(32)),
    matchups=[
        dict(id=0, engines=engines, evaluator_sha256=[model["evaluator_sha256"]] * 2)
    ],
    batches=[dict(batch=0, matchup=0, config=config_ref, slots=list(range(64)))],
    planned_slots=64,
)
plan_ref = save("plan.draft.json", plan)
experiment = dict(
    schema="quoridor.research.experiment.v1",
    phase="arena",
    build_manifest=None,
    config=config_ref,
    inputs=plan["inputs"],
    models=plan["models"],
    dynamic_libraries=prior["dynamic_libraries"],
    schedule=schedule_ref,
    numerical_qualification=None,
    canonical_plan_sha256=None,
    rules=plan["rules"],
    distance_units=plan["distance_units"],
    value_perspective=plan["value_perspective"],
    planned_slots=64,
    batch=0,
    argv=[
        None,
        "arena",
        "--experiment",
        "@EXPERIMENT@",
        "--experiment-sha256",
        "@EXPERIMENT_SHA256@",
    ],
)
experiment_ref = save("experiment.draft.json", experiment)
run = copy.deepcopy(oldrun)
run.update(
    output=str(TRIAL / "forward64-native-v1/run-000/operation"),
    data_root=str(data_root),
    TMP=str(TRIAL / "forward64-native-v1/run-000/TMP"),
    owned_outputs=None,
    artifact=None,
    experiment=experiment_ref,
    approved_plan=None,
    support=None,
    limits=None,
    data=None,
    argv=None,
    caller_sources=None,
    command_timeout_seconds=1800,
    child_cpu_cores=[0, 12],
)
run["env"]["TMPDIR"] = run["TMP"]
run_ref = save("run.draft.json", run)
sequence = dict(
    schema="quoridor.research.sequence.v1",
    kind="sequence",
    cwd=str(ROOT),
    owner=str(ROOT),
    output=str(TRIAL / "forward64-native-v1/execution-v1"),
    measurements=[],
    arena=None,
    limits=None,
    runs=[run],
)
sequence_ref = save("sequence.draft.json", sequence)
job = dict(
    issue="quoridor-4lc.324.25.3",
    goal_issue="quoridor-4lc.324",
    thread_id="01a11062-b120-73a1-8aa3-fe2cb922c7c0",
    cwd=str(ROOT),
    argv=None,
    end_at=None,
    notify_until=None,
    max_runtime_seconds=2340,
    control_interval_seconds=30,
    notify_interval_seconds=10,
    request_timeout_seconds=25,
    log_max_bytes=16384,
    resource_contract=None,
)
job_ref = save("job.draft.json", job)
sources = []
for path in (
    "crates/quoridor-runner/src/arena.rs",
    "crates/quoridor-runner/src/config.rs",
    "crates/quoridor-runner/src/runtime.rs",
    "scripts/dev/research-lifecycle.py",
):
    raw = subprocess.check_output(["git", "show", GIT + ":" + path], cwd=ROOT)
    sources.append(
        dict(git=GIT, path=path, sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
    )
save(
    "prepared.json",
    dict(
        status="NOT_RUNNABLE_UNISSUED_NO_SUBMISSION",
        issue=job["issue"],
        source_change_count=0,
        source_facts=sources,
        admission_finding="Existing search_wall_time accepts same-evaluator/same-artifact Control current-v-half; evaluator comparisons retain equal shallow policy, Half requires N1, functional/unsupported modes refuse",
        no_new_test_needed="No source boundary changed; no test/compiler/native/RNG executed",
        controls=dict(
            config=config_ref,
            plan=plan_ref,
            experiment=experiment_ref,
            run=run_ref,
            sequence=sequence_ref,
            job=job_ref,
            schedule=schedule_ref,
            candidate_pool=pool_ref,
        ),
        frozen_inputs=[
            ref(TRIAL / "conditional64.draft.json"),
            ref(OWN / "protocol-v1/conditional64-conditions.json"),
            ref(OWN / "protocol-v1/conditional64-families.json"),
        ],
        native_seed_mapping=families["native_seed_rule"],
        bootstrap=conditional["bootstrap_owner"],
        result_rule=conditional["decision"],
        future_holding_B=205520896,
        holding="Future native160MiB + LCcontrol4MiB + serialTMP8MiB + logs8MiB + analysis16MiB; ended OWN/images/capture/archive publication union require actual Root serializer/whole resolution, no old480MiB reuse",
        allocation_proposal=dict(
            worker=12,
            main=0,
            outer=18,
            launch=[0, 12, 18],
            family_B=4294967296,
            controller_B=1610612736,
            native_B=2684354560,
            host_reserve_B=4294967296,
            GPU=0,
            threads=1,
        ),
        runtime_proposal=dict(parent_s=2400, command_s=2340, RUN_s=1800),
        unresolved=[
            "Actual issued image/BUILD/currentcallers/sourceSTOP/numerical correspondence/support/fullroot allocation/free/origin/end_at",
            "Original native-book seed values and exact native family/root/history metadata must bind through owning normal input preparation; original_seed is intentionally NULL here, not an authorized runnable null replacement",
            "Actual artifact identity, native memory/deadline/pause and normal archive serializer data specs from current normal factory",
        ],
        preserved="Old401b/9786/fourUNKNOWN/100unperformed/old64STOPPED; independentNEW104 exhausted; only prospectiveNEW64; no outcome/family reselection, no CI/RNG now",
    ),
)
print(json.dumps(ref(OUT / "prepared.json")))
