"""Bind issued first32 book metadata into new, still unadmitted controls."""

import copy
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
TRIAL = OUT.parent
OWN = TRIAL.parent
PRIOR = TRIAL / "forward64-preparation-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def read(reference):
    p = Path(reference["path"])
    assert ref(p) == reference
    return json.loads(p.read_bytes())


def save(name, value):
    p = OUT / name
    with p.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")
    return ref(p)


prior_ref = dict(
    path=str(PRIOR / "prepared.json"),
    sha256="5432a91ff912a62b1528f75a5c668444c0e3b125e855f62fd02e405930220855",
    bytes=6635,
    mode="0644",
)
prior = read(prior_ref)
book_receipt = json.loads((OUT / "book-first32-metadata.json").read_text())
fixed = read(prior["frozen_inputs"][2])
assert fixed["native_book"] == book_receipt["source"]
assert book_receipt["book_header"]["complete"] is True
assert (
    book_receipt["book_header"]["rules"]
    == "research-standard-2p-threefold-goal-first-v1"
)
config = read(prior["controls"]["config"])
old_config = copy.deepcopy(config)
pool = read(prior["controls"]["candidate_pool"])
family_joins = []
for i, (f, original, opening, p) in enumerate(
    zip(
        fixed["families"],
        book_receipt["families"],
        config["arena"]["book"]["openings"],
        pool,
        strict=True,
    )
):
    assert f["native_family_index"] == original["family_id"] == p["family_id"] == i
    assert f["request_id"] == original["id"] == opening["id"]
    assert f["prefix"] == original["prefix"] == opening["prefix"]
    assert type(original["seed"]) is int and 0 <= original["seed"] < 2**64
    assert type(original["attempt_id"]) is int and original["attempt_id"] >= 0
    assert opening["candidate_pool_size"] == p["attempt_id"] + 1
    opening["candidate_pool_size"] = original["attempt_id"] + 1
    settings = dict(
        family_id=original["family_id"],
        root_key=original["root_key"],
        history_counts=original["history_counts"],
    )
    assert opening["reference"]["settings"] == settings
    opening["original_seed"] = original["seed"]
    opening["reference"]["settings"] = settings
    family_joins.append(
        dict(
            ordinal=i,
            canonical_family=f["canonical_family"],
            request_id=original["id"],
            original_seed=original["seed"],
            attempt_id=original["attempt_id"],
            earlier_local_prefix_attempt=p["attempt_id"],
            corrected_canonical_book_pool=opening["candidate_pool_size"]
            != p["candidate_pool_size"],
            candidate_pool_size=opening["candidate_pool_size"],
            exact_prefix_rootkey_fullweightedhistory=True,
        )
    )
assert len(family_joins) == 32
# Bind original seeds and correct local-prefix attempt to issued native-book attempt_id.
check = copy.deepcopy(config)
for opening, p in zip(check["arena"]["book"]["openings"], pool, strict=True):
    opening["original_seed"] = None
    opening["candidate_pool_size"] = p["candidate_pool_size"]
assert check == old_config
config_ref = save("arena-config.draft.json", config)
schedule_ref = prior["controls"]["schedule"]
schedule = read(schedule_ref)
assert len(schedule) == 64
assert [r["candidate_color"] for r in schedule] == [
    g["candidate_colour"] for g in fixed["games"]
]
assert [r["family_id"] for r in schedule] == [g["family_index"] for g in fixed["games"]]
plan = read(prior["controls"]["plan"])
assert plan["inputs"] == [book_receipt["source"]]
plan["batches"][0]["config"] = config_ref
plan_ref = save("plan.draft.json", plan)
qualified = json.loads((TRIAL / "actual-entry-v1/experiment-000.json").read_text())
qualified_run = json.loads((TRIAL / "actual-entry-v1/settings.json").read_text())[
    "runs"
][0]
build = qualified["build_manifest"]
artifact = qualified_run["artifact"]
assert (
    build["sha256"]
    == "84fd79dc4f6b2e756b9f77688cb3b7b46f7d32132cf489802692548273af3695"
)
assert (
    artifact["sha256"]
    == "f68639f78c816b9d590199f43cfccb96f63ed6f1e97e6cb461182a91c66ee3d7"
)
experiment = read(prior["controls"]["experiment"])
experiment.update(config=config_ref, build_manifest=build)
experiment["argv"][0] = artifact["path"]
assert experiment["inputs"] == [book_receipt["source"]]
assert (
    experiment["canonical_plan_sha256"] is None
    and experiment["numerical_qualification"] is None
)
experiment_ref = save("experiment.draft.json", experiment)
run = read(prior["controls"]["run"])
run.update(artifact=artifact, experiment=experiment_ref)
assert run["owner"] == "/workspaces/quoridor" and run["child_cpu_cores"] == [0, 12]
assert all(
    run[k] is None
    for k in [
        "support",
        "owned_outputs",
        "approved_plan",
        "limits",
        "data",
        "argv",
        "caller_sources",
    ]
)
run_ref = save("run.draft.json", run)
sequence = read(prior["controls"]["sequence"])
sequence["runs"] = [run]
sequence_ref = save("sequence.draft.json", sequence)
job = read(prior["controls"]["job"])
assert all(job[k] is None for k in ["end_at", "argv", "resource_contract"])
job_ref = save("job.draft.json", job)
join_ref = save(
    "book-correspondence.json",
    dict(
        issued_native_book=book_receipt["source"],
        original_frozen_family_schedule=prior["frozen_inputs"][2],
        family_joins=family_joins,
        no_family_or_seed_generation=True,
        no_geometry_solver_or_input_qualification_replay=True,
        no_model_or_ELF_payload_read=True,
        book_read_count_this_preparation=1,
    ),
)
analysis = json.loads((PRIOR / "analysis-correspondence.draft.json").read_text())
analysis["book_correspondence"] = join_ref
analysis["config"] = config_ref
analysis_ref = save("analysis-correspondence.draft.json", analysis)
save(
    "prepared.json",
    dict(
        status="BOOK_BOUND_NORMAL_DRAFTS_NOT_RUNNABLE_NO_SUBMISSION",
        issue="quoridor-4lc.324.25.3",
        prior=prior_ref,
        controls=dict(
            config=config_ref,
            plan=plan_ref,
            experiment=experiment_ref,
            run=run_ref,
            sequence=sequence_ref,
            job=job_ref,
            schedule=schedule_ref,
            analysis=analysis_ref,
        ),
        book_correspondence=join_ref,
        image_both_arms=artifact,
        Build_both_arms=build,
        software_binding="Root explicitly matched qualified f686/84fd both arms after26 rollback; no manual payload qualification or new repaired image alias",
        source_delta=0,
        new_tests=0,
        compiler=0,
        native=0,
        RNG=0,
        fixed_science="ONE64/32pairs/max1.024G; Half vsCurrent/N1/Control/Cedar/baselineLMR/PVS/path_tail/TT1M/D64/1M perSearch/100ms5/max200/strict_unknown",
        sole_CI="unchanged maintained arena_statistics customRng/seed3242520261020/10000/floorceil95 native ONLY after whole64 normal qualification+STOP; no PCG64/linear95/externalCI",
        future_holding_B=205520896,
        holding="Original producer proposal retained; no old480 reuse/refund/lending/guessed compression; Root may add ordinary capture custody in issued whole",
        unresolved=[
            "Actual Root source/software release and final currentcaller tuple after push; no premature HEAD binding or Mainreader",
            "Actual canonical normal Plan/factory/numerical/caller/source/serializer/fullroots/support/free/allocation/origin/end_at/fresh admission",
        ],
        metadata_correction="Earlier local prefix attempt differs from issued native-book attempt_id in31 families; original failure and drafts preserved, only new unentered pool metadata corrected",
        retired_unresolved="Original seeds/exact first32 family/root/fullweightedhistory NOW bound from issued book; no runnable null seed/default/fallback",
        historical_exposure="YES / original three-family overlap; no claim of IID unseen",
        old_attempts_preserved="401b/9786/4UNKNOWN/100unperformed/old64STOPPED; independentNEW104 exhausted/gatePASS; defaultCurrent unchanged",
    ),
)
print(json.dumps(ref(OUT / "prepared.json")))
