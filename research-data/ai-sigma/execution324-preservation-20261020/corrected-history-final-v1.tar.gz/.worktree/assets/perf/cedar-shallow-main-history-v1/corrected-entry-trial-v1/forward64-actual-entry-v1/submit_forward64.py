"""One normal submit client outside Cycle.execute; no native-start observation."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
OUT = OWN / "binding-v2"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as out:
        out.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


os.sched_setaffinity(0, {0, 12, 18})
assert sorted(os.sched_getaffinity(0)) == [0, 12, 18]
assert (OUT / "source-admin-STOP.json").is_file()
actual = json.loads((OUT / "materialized.json").read_text())
runtime = Path(actual["state_dir"])
assert (
    not runtime.exists()
    and not Path(json.loads((OUT / "settings.json").read_text())["output"]).exists()
)
job = json.loads((OUT / "job-template.json").read_text())
now = datetime.datetime.now(datetime.timezone.utc)
job["end_at"] = (now + datetime.timedelta(seconds=2400)).isoformat()
assert job["max_runtime_seconds"] == 2340
config = save("job-entry-v1.json", job)
client_dir = OUT / "submit-client-v1"
client_dir.mkdir()
tmp = client_dir / "TMP"
tmp.mkdir()
env = dict(
    os.environ,
    UV_NO_SYNC="1",
    UV_OFFLINE="1",
    PYTHONDONTWRITEBYTECODE="1",
    CUDA_VISIBLE_DEVICES="",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
    TMPDIR=str(tmp),
)
env["PATH"] = (
    "/home/vscode/.local/bin:/home/vscode/.cache/inference/envs/quoridor-training/bin:/usr/bin:/bin"
)
argv = [
    "/bin/bash",
    str(ROOT / "scripts/dev/research-job.sh"),
    "submit",
    "--config",
    config["path"],
    "--state-dir",
    str(runtime),
]
save(
    "submit-intent-v1.json",
    dict(
        at=now.isoformat(),
        config=config,
        argv=argv,
        state_dir=str(runtime),
        launch_affinity=[0, 12, 18],
        outside_Cycle_execute=True,
        source_admin_STOP=ref(OUT / "source-admin-STOP.json"),
        native_START=None,
    ),
)
start = time.monotonic()
with subprocess.Popen(
    argv, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE
) as client:
    identity = dict(
        pid=client.pid,
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    )
    try:
        identity["start_ticks"] = (
            (Path("/proc") / str(client.pid) / "stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19]
        )
    except FileNotFoundError:
        identity["start_ticks"] = None
    stdout, stderr = client.communicate(timeout=120)
    code = client.wait()
    client.stdout.close()
    client.stderr.close()
    handles = client.stdout.closed and client.stderr.closed
(client_dir / "stdout.log").write_bytes(stdout)
(client_dir / "stderr.log").write_bytes(stderr)
response = json.loads(stdout) if code == 0 else None
receipt = save(
    "submit-return-v1.json",
    dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        config=config,
        actual_client_identity=identity,
        returncode=code,
        directwait_reaped=True,
        pipes_closed=handles,
        client_wall_seconds=time.monotonic() - start,
        stdout=ref(client_dir / "stdout.log"),
        stderr=ref(client_dir / "stderr.log"),
        RPC_response=response,
        accepted_RPC_only=code == 0,
        native_START=None,
        scientific_success=None,
        state_dir=str(runtime),
        one_original_forward64_sequence=True,
        source_leases=[],
        TMP_entries=[str(p) for p in tmp.iterdir()],
        TMP_lifetime="Normal submitted environment may retain this own directory until completion; no empty/removal claim",
    ),
)
print(json.dumps(dict(receipt=receipt, response=response, native_START=None)))
raise SystemExit(code)
