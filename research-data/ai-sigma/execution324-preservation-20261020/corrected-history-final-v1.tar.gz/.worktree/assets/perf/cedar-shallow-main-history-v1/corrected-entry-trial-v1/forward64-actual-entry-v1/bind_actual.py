"""Bind the issued one-RUN arena through current canonical normal owners."""

import copy
import datetime
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
TRIAL = OUT.parent
OWN = TRIAL.parent
ENTRY = (
    ROOT
    / ".artifacts/research-team/integration324/cedar-shallow-main-history-v1/forward64-entry-v1"
)


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def document(reference):
    p = Path(reference["path"])
    assert ref(p) == reference
    return json.loads(p.read_bytes())


def save(name, value):
    p = OUT / name
    with p.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")
    return ref(p)


issued_ref = dict(
    path=str(ENTRY / "issued-inputs.json"),
    sha256="d3d3040339c59b021b70c1801590d67de01581bf488e3f73b346152ff6764a15",
    bytes=963,
    mode="0644",
)
issued = document(issued_ref)
release = document(issued["release"])
support_ref = issued["phase_support"]
support = document(support_ref)
prepared = document(support["book_preparation"])
assert prepared["status"] == "BOOK_BOUND_NORMAL_DRAFTS_NOT_RUNNABLE_NO_SUBMISSION"
assert support["whole_B"] == support["limits"]["owned_B"] == 436207616
assert support["limits"]["free_B"] == 33071104
assert support["issue"] == "quoridor-4lc.324.25.3"
manifest = document(release["software_manifest"])
artifact = release["artifact"]
assert manifest["artifact"] == artifact and manifest["status"] == "PASS"
assert manifest["cleanup_complete"] and manifest["remaining"] == []
assert (
    artifact["sha256"]
    == "f68639f78c816b9d590199f43cfccb96f63ed6f1e97e6cb461182a91c66ee3d7"
)
config = document(prepared["controls"]["config"])
plan = document(prepared["controls"]["plan"])
experiment = document(prepared["controls"]["experiment"])
run = document(prepared["controls"]["run"])
sequence = document(prepared["controls"]["sequence"])
job = document(prepared["controls"]["job"])
assert config["games"] == 64 and config["arena"]["max_total_nodes"] == 1024000000
assert [e["shallow_main_history"] for e in config["engines"]] == ["half", "current"]
assert [o["candidate_pool_size"] for o in config["arena"]["book"]["openings"]] == list(
    range(1, 33)
)
assert all(
    o["original_seed"] == 43220261018 for o in config["arena"]["book"]["openings"]
)
future = TRIAL / "forward64-native-v1"
future.mkdir(exist_ok=True)
assert (
    future.resolve(strict=True) == future
    and not (future / "parent-runtime-v1").exists()
)
assert not Path(config["output"]).exists() and not Path(sequence["output"]).exists()
for r in support["roots"]:
    p = Path(r)
    assert p.resolve(strict=True) == p and p.is_relative_to(ROOT)
Path(run["TMP"]).parent.mkdir(parents=True, exist_ok=True)
assert run["owner"] == str(ROOT) and run["child_cpu_cores"] == [0, 12]
config.update(
    max_memory_bytes=support["resources"]["native_B"],
    wall_seconds=1800,
    deadline_unix_ms=int((time.time() + 1800) * 1000),
)
config["arena"]["search_artifact_sha256"] = [artifact["sha256"]] * 2
old_numerical = json.loads((TRIAL / "actual-entry-v1/numerical-000.json").read_text())
reader = dict(
    path=str(ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"),
    mode="LOCK_SH|LOCK_NB",
    leases_remaining=[],
)
with Path(reader["path"]).open("a") as handle:
    fcntl.flock(handle, fcntl.LOCK_SH | fcntl.LOCK_NB)
    reader["acquired_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    callers = release["current_four_callers"]
    assert len(callers) == 4
    for caller in callers:
        assert ref(Path(caller["path"])) == caller
    loader = importlib.util.spec_from_file_location(
        "forward64_current_normal_owner", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    sys.modules[loader.name] = lc
    loader.loader.exec_module(lc)
    common = dict(
        use_tt=True,
        use_pvs=True,
        ruleset=config["ruleset"],
        tt_entries=1048576,
        host_reserve_B=support["resources"]["host_reserve_B"],
        family_B=support["resources"]["family_B"],
        controller_B=support["resources"]["controller_B"],
        arena=dict(
            return_reserve_ms=5,
            management_guardian=0,
            AI_workers=[12, 12],
            max_plies=200,
            depth=64,
            max_nodes=1000000,
            time_ms=100,
        ),
    )
    pair = [
        dict(
            evaluator=e["kind"],
            profile=e["ordering_profile"],
            lmr=e["lmr"],
            lmr_method=e["lmr_method"],
            lmr_parameters=e["lmr_parameters"],
            shallow_main_history=e["shallow_main_history"],
            zero_stock_safe_race=e["zero_stock_safe_race"],
            zero_stock_safe_race_method=e["zero_stock_safe_race_method"],
        )
        for e in config["engines"]
    ]
    before_factory = copy.deepcopy(config)
    lc.apply_comparison_arena(config, common, pair)
    assert config == before_factory
    config_ref = save("arena-config.json", config)
    plan["batches"][0]["config"] = config_ref
    plan["matchups"][0]["engines"] = config["engines"]
    plan_ref = save("plan.json", plan)
    experiment.update(
        build_manifest=release["software_manifest"],
        config=config_ref,
        canonical_plan_sha256=plan_ref["sha256"],
    )
    experiment["argv"][0] = artifact["path"]
    planned, checked_config = lc.arena_plan_check(experiment, plan)
    assert len(planned) == 64 and checked_config == config
    numerical = lc.numerical_fields(experiment, manifest)
    numerical.update(
        original_evidence=old_numerical["original_evidence"],
        correspondence_only=True,
        scope="Inherited641ca structural normal correspondence only; no new model/policy/parity qualification",
        source_owner=callers[0],
        actual_software_Build=release["software_manifest"],
        new_model_or_head_calls=0,
    )
    experiment["numerical_qualification"] = save("numerical.json", numerical)
    experiment_ref = save("experiment.json", experiment)
    data_root = Path(config["output"])
    run.update(
        artifact=artifact,
        experiment=experiment_ref,
        support=support_ref,
        owned_outputs=support["roots"],
        limits=support["limits"],
        approved_plan=plan_ref,
        caller_sources=callers,
        data=[
            dict(
                name="journal",
                path=str(data_root / "completed.jsonl.gz"),
                limit_B=support["archive_B_each"],
            ),
            dict(
                name="result", path=str(data_root / "result.json"), limit_B=4 * 1024**2
            ),
            dict(
                name="native_manifest",
                path=str(data_root / "manifest.json"),
                limit_B=4 * 1024**2,
            ),
        ],
        argv=[
            artifact["path"],
            "arena",
            "--experiment",
            experiment_ref["path"],
            "--experiment-sha256",
            experiment_ref["sha256"],
        ],
    )
    lc.caller_source_refs(run, experiment)
    lc.numerical_check(experiment, manifest)
    assert lc.native_cpu_cores(run) == [0, 12]
    assert lc.approved_plan(run, experiment) == plan
    fcntl.flock(handle, fcntl.LOCK_UN)
    reader["released_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
sequence.update(limits=support["limits"], runs=[run])
settings_ref = save("settings.json", sequence)
job.update(
    resource_contract=settings_ref["path"],
    argv=[
        "/home/vscode/.cache/inference/envs/quoridor-training/bin/python",
        "-B",
        str(ROOT / "scripts/dev/research-lifecycle.py"),
        "sequence",
        "--intent",
        settings_ref["path"],
        "--sha256",
        settings_ref["sha256"],
    ],
)
assert job["max_runtime_seconds"] == 2340 and job["end_at"] is None
job_ref = save("job-template.json", job)
result = save(
    "materialized.json",
    dict(
        status="ACTUAL_NEW25_3_FORWARD64_BOUND_UNENTERED",
        issue=job["issue"],
        issued=issued_ref,
        release=issued["release"],
        support=support_ref,
        capacity=issued["capacity"],
        original_book_bound_preparation=support["book_preparation"],
        settings=settings_ref,
        job_template=job_ref,
        experiment=experiment_ref,
        approved_plan=plan_ref,
        state_dir=str(future / "parent-runtime-v1"),
        source_reader=reader,
        current_callers=callers,
        current_normal_owner_checks="apply_comparison_arena identity; arena_plan_check64/approved_plan; numerical_fields+numerical_check; caller_source_refs4; native_cpu_cores[0,12]",
        parent_accepted_s=2400,
        command_s=2340,
        RUN_s=1800,
        launch_affinity=[0, 12, 18],
        native_START=None,
        actual_origin_end_at="STAMP_ONCE_AT_DIRECT_SUBMIT",
        actual_native_guard="Fresh physicalSMT/peers/RAMhost4/source/env/ownerpausecancel/fullroots/free/serializer/origin/cancel/cleanup remain runtime owned",
        no_manual_book_model_ELF_qualification=True,
    ),
)
print(
    json.dumps(
        dict(
            materialized=result,
            settings=settings_ref,
            job=job_ref,
            source_reader=reader,
        )
    )
)
