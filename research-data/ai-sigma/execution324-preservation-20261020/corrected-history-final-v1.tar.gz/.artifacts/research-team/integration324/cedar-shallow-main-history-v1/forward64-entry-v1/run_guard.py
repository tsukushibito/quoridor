"""Bound the one ordinary current-source/holding issuance helper."""

import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import CycleResources, execute, identity, process_info

out = Path(__file__).resolve().parent
temporary = out / "issuance-TMP"
temporary.mkdir()
deadline = time.monotonic() + 300
resources = CycleResources(
    {"max_memory_bytes": 1024**3 - 64 * 1024**2, "host_ram_reserve": 4 * 1024**3},
    out,
    deadline,
)
environment = dict(os.environ, TMPDIR=str(temporary), CUDA_VISIBLE_DEVICES="")
result = execute(
    [sys.executable, "-B", str(out / "issue_support.py")],
    out / "issuance.execution.log",
    deadline,
    cpu_cores=[2],
    resources=resources,
    cwd="/workspaces/quoridor",
    env=environment,
)
assert identity(process_info(result["child"]["pid"])) != result["child"]
temporary.rmdir()
with (out / "issuance-guard-return.json").open("x") as stream:
    json.dump(
        dict(actual_return=result, TMP=[], source_leases=[], host_future_quiet=False),
        stream,
        indent=2,
    )
    stream.write("\n")
print(
    json.dumps(
        dict(
            exit_code=result["exit_code"],
            cleanup=result["cleanup_complete"],
            seconds=result["wall_seconds"],
        )
    )
)
assert result["exit_code"] == 0 and result["cleanup_complete"]
