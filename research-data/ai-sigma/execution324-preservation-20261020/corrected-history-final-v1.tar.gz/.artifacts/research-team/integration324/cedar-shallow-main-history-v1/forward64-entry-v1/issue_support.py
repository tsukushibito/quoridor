"""Bind the already authorized corrected-entry forward64 at the real push STOP."""

import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-shallow-main-history-v1"
TRIAL = OWN / "corrected-entry-trial-v1"
SOFTWARE = BASE / "timed-rootquality-software-v1"
PUSH = ROOT / ".artifacts/research-team/integration324/git-push-20261020"
MIB = 1024**2


def ref(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def checked(path, digest, size):
    row = ref(path)
    assert (row["sha256"], row["bytes"], row["mode"]) == (digest, size, "0644"), row
    return json.loads(Path(path).read_bytes())


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(OUT / name)


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def point(paths):
    seen = set()
    allocated = entries = logical = 0
    pending = [Path(p) for p in paths]
    while pending:
        path = pending.pop()
        info = path.lstat()
        key = (info.st_dev, info.st_ino)
        if key in seen:
            continue
        seen.add(key)
        assert not stat.S_ISLNK(info.st_mode), path
        allocated += info.st_blocks * 512
        logical += info.st_size
        entries += 1
        if stat.S_ISDIR(info.st_mode):
            pending.extend(path.iterdir())
    return dict(allocated_B=allocated, logical_B=logical, entries=entries)


def main():
    minimum = checked(
        TRIAL / "analysis-v1/minimum-result.json",
        "ea16305f5c2d3bf0467e4c8ddc213426aca8d73328875dd3deb1d1db4972d3b5",
        2207,
    )
    assert minimum["gate_pass"] and minimum["calls_published"] == 104
    assert minimum["errors_missing_cancelled_NodeLimit"] == 0
    checked(
        TRIAL / "analysis-v1/returned-analysis-admin-STOP.json",
        "1e7d9e2171cb7f9e28b3f5f031b7afb603ec761f28a8cd6e0ec038919e17c1f9",
        8772,
    )
    book_prep = TRIAL / "forward64-book-binding-v1"
    prepared = checked(
        book_prep / "prepared.json",
        "f130ff27a87adaf683da74ccf03e40f9b4f44d56702d67954c4eef04d50f4e59",
        5500,
    )
    checked(
        book_prep / "returned-source-control-admin-STOP.json",
        "634c7786cfd4c52d676f89ee0b5851609cf4efc7c70e4350dec76be2caa4caa2",
        6742,
    )
    checked(
        book_prep / "finalizer-v1/return.json",
        "f16743ecae6012ce2fc539b90fcb4329c8fd06a0b1767bb7078dc4ca20285876",
        4204,
    )
    holding26 = (
        ROOT
        / ".worktree/assets/perf/cedar-wall-path-work-v1/analysis-v1/actual-retained-holding.json"
    )
    ended26 = checked(
        holding26, "c2906192c2a47f993b99fda3d06c73e6eb82bce9f561e0c0e36860eec06ff6c3", 550
    )
    assert ended26["allocated_B"] == 12283904
    software_path = SOFTWARE / "release-collection-v1/completion-and-STOP.json"
    software = json.loads(software_path.read_bytes())
    assert software["status"] == "ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP"
    assert software["software_manifest"] == prepared["Build_both_arms"]
    assert software["artifact"] == prepared["image_both_arms"]
    build_ref = software["software_manifest"]
    assert ref(build_ref["path"]) == build_ref
    assert json.loads(Path(build_ref["path"]).read_bytes())["status"] == "PASS"
    intent = json.loads((SOFTWARE / "build-intent-release.json").read_bytes())
    whole = 416 * MIB
    future = 329 * MIB
    previous25_retention = 58155008
    margin = whole - previous25_retention - future
    assert margin >= 24 * MIB
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        head = git("rev-parse", "HEAD")
        assert head == "1dce95b0734770f7da871bafb39bf3a9fa4f0da8"
        remote = git("ls-remote", "origin", "refs/heads/main").split()[0]
        assert remote == head
        assert not git("diff", "--name-only") and not git("diff", "--cached", "--name-only")
        # Actual compiled Rust, manifests and config match the qualified image source.
        # Cargo.lock was already a recorded patch at compilation; compare those exact bytes.
        subprocess.run(
            [
                "git",
                "diff",
                "--exit-code",
                intent["source"]["commit"],
                head,
                "--",
                "crates",
                "Cargo.toml",
                ".cargo",
            ],
            cwd=ROOT,
            check=True,
            stdout=subprocess.DEVNULL,
        )
        assert ref(ROOT / "Cargo.lock") == intent["source"]["lock"]
        for caller in software["current_callers"]:
            assert ref(caller["path"]) == caller
        changed = git("diff", "--name-only", intent["source"]["commit"], head).splitlines()
        assert all(
            p.startswith(("docs/", "research-data/", ".devcontainer/"))
            or p in ("Cargo.lock", ".dockerignore", "scripts/dev/setup-rust.sh")
            for p in changed
        ), changed
        source = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_NEW25_3_FORWARD64_SOURCE_SOFTWARE_RELEASE",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=head,
                current_four_callers=software["current_callers"],
                software_manifest=build_ref,
                artifact=software["artifact"],
                actual_software_STOP=ref(software_path),
                gate_completion=ref(TRIAL / "analysis-v1/completion.json"),
                actual_native_collection_analysis_STOP=ref(
                    TRIAL / "analysis-v1/returned-analysis-admin-STOP.json"
                ),
                source_bridge=dict(
                    compiled_Rust_manifests_config_exact=True,
                    Cargo_lock_exact_actual_build_witness=intent["source"]["lock"],
                    changed_paths=changed,
                    models_libraries_image_copy_B=0,
                    no_rebuild_or_successful_qualification_replay=True,
                ),
                actual_EX_NB_acquired_released=True,
                source_leases_remaining=[],
                numerical_scope="Inherited641ca structural only; actual normal Plan/factory/numerical/caller and fresh admission still mandatory",
                evaluation="NEW25_3_FORWARD64_UNENTERED",
                host_future_quiet=False,
            ),
        )
        fcntl.flock(lock, fcntl.LOCK_UN)
    # One new preservation subtree point and exactly the new reachable loose objects.
    # No old object store / holding / global walk or old credit reapplication.
    object_ids = {
        line.split()[0]
        for line in git(
            "rev-list", "--objects", "298c976601817bfc513192cd9b30aac7b698b689..HEAD"
        ).splitlines()
    }
    common = Path(git("rev-parse", "--git-common-dir"))
    if not common.is_absolute():
        common = ROOT / common
    object_paths = [common / "objects" / oid[:2] / oid[2:] for oid in object_ids]
    assert all(p.is_file() and not p.is_symlink() for p in object_paths)
    new_point = point(
        [ROOT / "research-data/ai-sigma/execution324-preservation-20261020", PUSH, *object_paths]
    )
    push_ref = save(
        "push-and-preservation-actual-point.json",
        dict(
            at=datetime.datetime.now(datetime.UTC).isoformat(),
            commit=head,
            remote_main=remote,
            new_preservation_and_new_git_objects_once=new_point,
            new_git_object_count=len(object_ids),
            legacy_working_files="Preexisting; not recharged. Only new Git objects and new preservation/control subtree counted",
            future_ordinary_tails_B=8 * MIB,
            old_global_walk_refund_lending=0,
        ),
    )
    ended_basis_path = OUT / "ended26-bulk-basis.json"
    ended_basis = json.loads(ended_basis_path.read_bytes())
    settled_cover = (
        ended_basis["known_cover_after_refinement_B"]
        - ended_basis["refined_stored_and_remaining_tail_B"]
        + ended26["allocated_B"]
    )
    assert settled_cover == 49518511104
    settlement = save(
        "ended26-final-holding-settlement.json",
        dict(
            original_interim=ref(ended_basis_path),
            actual_ended_union=ref(holding26),
            replaced_interim_B=40460288,
            actual_ended_B=12283904,
            settled_cover_B=settled_cover,
            source_science_status="INCOMPLETE_RETAIN_BASELINE_NO_SPEEDUP_QUALIFICATION;104 exhausted",
            replacement_once_not_scientific_refund_or_quota_lending=True,
        ),
    )
    cover = settled_cover + new_point["allocated_B"] + 8 * MIB - previous25_retention + whole
    assert cover <= 50000000000 - 16 * MIB, (cover, new_point)
    roots = [
        str(OWN),
        str(BASE / "normal104-entry-v1"),
        str(BASE / "corrected104-entry-v1"),
        str(OUT),
    ]
    assert all(Path(p).is_dir() for p in roots)
    fs = os.statvfs(OWN)
    available = fs.f_bavail * fs.f_frsize
    assert available > future
    capacity = save(
        "capacity-and-holding.json",
        dict(
            roots=roots,
            old25_ended_scope_upper_B_replaced_once=previous25_retention,
            ended26_settlement=settlement,
            new_preservation_actual=push_ref,
            new_whole_B=whole,
            conservative_future_B=future,
            planning_margin_B=margin,
            new_known_cover_B=cover,
            remaining_to_decimal50GB_B=50000000000 - cover,
            filesystem_available_B=available,
            globalactual_fullfees_later_tails="UNKNOWN",
            settlement="One416MiB whole replaces overlapping ended OWN25+both Root104 entries; includes new64 full-root custody. No previous480 grant, unused nodes, quota refund/reset/lending or duplicate charge.",
        ),
    )
    resources = dict(
        search_cpu_cores=[12],
        total_search_threads=1,
        worker_cpu=12,
        main_guardian=0,
        outer_guardian=18,
        launch_affinity=[0, 12, 18],
        family_B=4 * 1024**3,
        controller_B=1536 * MIB,
        native_B=2560 * MIB,
        host_reserve_B=4 * 1024**3,
        GPU=0,
        threads=1,
        CPU=2,
        controller_included=True,
        family_RAM_B=4 * 1024**3,
        controller_RAM_B=1536 * MIB,
    )
    support = save(
        "phase-support.json",
        dict(
            issue="quoridor-4lc.324.25.3",
            status="ISSUED_NEW25_3_FORWARD64_ONE_NORMAL_RUN_ONE_WHOLE",
            fixed_protocol=ref(TRIAL / "trial.json"),
            game_contract=ref(TRIAL / "conditional64.draft.json"),
            gate_completion=ref(TRIAL / "analysis-v1/completion.json"),
            current_source_adoption=source,
            actual_source_STOP=source,
            actual_software_STOP=ref(software_path),
            software_manifest=build_ref,
            artifact=software["artifact"],
            book_preparation=ref(book_prep / "prepared.json"),
            whole_B=whole,
            owned_B=whole,
            free_B=margin,
            roots=roots,
            storage_budget=dict(whole_B=whole, roots=roots),
            capacity_basis=capacity,
            resources=resources,
            limits=dict(
                worker_cpu=12,
                guardian_cpu=0,
                family_B=4 * 1024**3,
                controller_B=1536 * MIB,
                host_reserve_B=4 * 1024**3,
                owned_B=whole,
                free_B=margin,
                log_B=MIB,
            ),
            games=64,
            families=32,
            serial_runs=1,
            total_nodes=1024000000,
            per_move_allworker_nodes=1000000,
            TOTAL_TT_entries=1048576,
            game_concurrency=1,
            RUN_timeout_s=1800,
            parent_accepted_s=2400,
            parent_command_s=2340,
            cleanup_margin_s=60,
            readonly_images_models_copy_B=0,
            native_aggregate_B_each=160 * MIB,
            native_record_B_each=MIB,
            journal_B_each=64 * MIB,
            archive_B_each=64 * MIB,
            perf_RAW_B=0,
            sole_CI="Maintained native customRng paired-family10000/seed3242520261020/floorceil95; only all64qualified32pairsUNKNOWN0+actualSTOP; no external CI or RNG replay",
            normal_remaining_inputs="Actual canonical arena Plan/factory/numerical/currentcaller join, fresh physical SMT-peer/RAMhost4/fullroot/free/ownerpausecancel/currentenv/origin/end_at/serializer/cancel/cleanup at owning runtime. RPC not nativeSTART",
            hold="Main/currentcallers/libs/env/image/Git/Cargo/heavyIO freeze through actual native+normalcollectionSTOP; independent light preparation allowed",
            original401b_9786_fourUNKNOWN_100unperformed_old64STOPPED="IMMUTABLE",
            historical_exposure="YES; three-family overlap, no IID unseen claim",
            science_refund_lending_reset=0,
            pauses_seals_models_defaults_foreign_FAILED_UNKNOWN="PRESERVED",
        ),
    )
    issued = save(
        "issued-inputs.json",
        dict(
            release=source,
            phase_support=support,
            capacity=capacity,
            source_leases=[],
            evaluation="NEW25_3_FORWARD64_UNENTERED",
        ),
    )
    print(
        json.dumps(
            dict(issued=issued, support=support, margin_B=margin, head_B=50000000000 - cover)
        )
    )


if __name__ == "__main__":
    main()
