"""Issue one real normal208 whole using the finalized common aspiration image."""

import datetime
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
SOFTWARE = BASE / "software-v2"
OWN = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1"
MIB = 1024**2


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    h = load("existing_helpers", SOFTWARE / "prefix-collection-v1/collect.py")
    prior = load(
        "existing_point",
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/normal208-entry-v1/issue_support.py",
    )
    ref = h.ref

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return ref(path)

    stop_ref = ref(SOFTWARE / "release-collection-v1/completion-and-STOP.json")
    stop = json.loads(Path(stop_ref["path"]).read_bytes())
    guard_ref = ref(SOFTWARE / "release-collection-v1/actual-returned-STOP.json")
    guard = json.loads(Path(guard_ref["path"]).read_bytes())
    assert (
        stop["status"]
        == "ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP"
    )
    r = guard["actual_return"]
    assert (
        r["exit_code"] == 0
        and r["cleanup_complete"]
        and r["direct_child_reaped"]
        and r["handle_closes_complete"]
        and not r["remaining"]
    )
    build = json.loads(h.checked(stop["software_manifest"]).read_bytes())
    assert build["status"] == "PASS"
    protocol = ref(OWN / "finite-protocol-v1.json")
    assert (
        protocol["sha256"]
        == "2673cc67b107b4a427676f88026261a98a32386e615eea8dac915740097890f6"
    )
    lock = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock.open("a") as stream:
        fcntl.flock(stream, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for caller in stop["current_callers"]:
            assert ref(Path(caller["path"])) == caller
        head = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip()
        assert head == "e0f50bb8cb1a56342b27918bbce7d029105ac34d"
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_SOURCE_SOFTWARE_COLLECTION_RELEASED_SAME_IMAGE_OFF_ON",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=head,
                current_four_callers=stop["current_callers"],
                software_manifest=stop["software_manifest"],
                artifact=stop["artifact"],
                control_build=stop["software_manifest"],
                control_artifact=stop["artifact"],
                candidate_build=stop["software_manifest"],
                candidate_artifact=stop["artifact"],
                actual_software_STOP=stop_ref,
                collector_guard=guard_ref,
                source_adoption=ref(SOFTWARE / "build-source-adoption-release.json"),
                source_patch=ref(SOFTWARE / "actual-foreign-source-release.patch"),
                source_SH_NB_acquired_released=True,
                source_leases_remaining=[],
                qualification="NewAI3/RunnerLIB2 each running1, affectedClippy warning0, priorPython1 retained, genuine release normal finalize PASS; no scientific outcome inferred",
                numerical_scope="Inherited641ca structural only; actual current normal factory and numerical_fields/caller joins remain normal-entry owned",
                evaluation="UNENTERED",
                host_future_quiet=False,
            ),
        )
    roots = [str(OWN), str(OUT)]
    actual = prior.point(roots)
    whole = 352 * MIB
    # Existing normal208 producer forecast152MiB at8MiB native each,
    # replaced with the actual29 20MiB native cap each; no extra calls.
    future = 159383552 + 8 * 12 * MIB
    margin = whole - actual["allocated_B"] - future
    assert margin >= 8 * MIB, (actual, margin)
    cover = stop["current_known_cover_B"]
    assert cover + whole + 16 * MIB <= 50000000000
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize > whole
    capacity = save(
        "capacity-and-holding.json",
        dict(
            roots=roots,
            scope="ONE352MiB full OWN29 plus Root normalentry; includes existing source/control holding once, no globalwalk/oldcredit/refund/loan",
            actual_ended_point=actual,
            conservative_future_B=future,
            whole_B=whole,
            forecast_margin_B=margin,
            prior_known_cover_B=cover,
            new_known_cover_B=cover + whole,
            remaining_to_decimal50GB_B=50000000000 - cover - whole,
            separate_archive_Git_headroom_B=16 * MIB,
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            images_models_libraries_copy_B=0,
            old_credits_refund_loan_reset=0,
            later_tails_globalactual_fullfees="UNKNOWN",
        ),
    )
    template_path = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-followup-v1/replacement-v1/normal208-entry-v1/phase-support-N2.json"
    )
    support = json.loads(template_path.read_bytes())
    support.update(
        issue="quoridor-4lc.324.29",
        status="ISSUED_ORIGINAL29_ASPIRATION_NORMAL208_ONE_SERIAL_LIFETIME",
        fixed_protocol=protocol,
        current_source_adoption=release,
        actual_source_STOP=release,
        actual_software_STOP=stop_ref,
        whole_B=whole,
        roots=roots,
        storage_budget=dict(whole_B=whole, roots=roots),
        owned_B=whole,
        free_B=margin,
        capacity_basis=capacity,
        sessions=48,
        native_aggregate_B_each=20 * MIB,
        total_original_calls=208,
        total_original_nodes=208000000,
        RUN_timeout_s=900,
        parent_accepted_s=7800,
        parent_command_s=7740,
        cleanup_margin_s=60,
        allocation="Same genuine image OFF/ON, N1 worker12/main0/outer18, serial8 RUNs under ONE352MiB whole, child_cpu_cores[0,12], no duplicated grant",
        timing="Main/currentcallers/image/libs/env/Git/Cargo/heavyIO frozen through actualnative+normalcollectionSTOP; optional docs/archive/commit-push afterward",
        conditional128="Original29 only; separate128/64families/2.048G after frozen gates+new actualsupport, no oldquota transfer",
        conditional64="NOT_APPLICABLE; original29 has conditional128 only",
    )
    support["resources"].update(
        search_cpu_cores=[12], total_search_threads=1, launch_affinity=[0, 12, 18]
    )
    support["limits"].update(owned_B=whole, free_B=margin)
    support_ref = save("phase-support-N1.json", support)
    save(
        "issued-inputs.json",
        dict(
            release=release,
            phase_supports=[support_ref],
            capacity=capacity,
            source_leases=[],
            evaluation="UNENTERED",
            same_image_both_arms=True,
        ),
    )
    print(
        json.dumps(
            dict(
                status="ISSUED",
                release=release,
                support=support_ref,
                whole_B=whole,
                margin_B=margin,
                current_cover_B=cover + whole,
            )
        )
    )


if __name__ == "__main__":
    main()
