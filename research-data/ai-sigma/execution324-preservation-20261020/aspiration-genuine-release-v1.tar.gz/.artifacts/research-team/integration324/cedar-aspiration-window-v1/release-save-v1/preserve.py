"""Preserve stopped genuine release and normal208 custody without scientific replay."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
SOFTWARE = BASE / "software-v2"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    paths = []
    for name in [
        "operation-release",
        "release-collection-v1",
        "release-preparation-v1",
    ]:
        paths += old.files_below(SOFTWARE / name)
    for name in [
        "build-intent-release.json",
        "build-source-adoption-release.json",
        "resources-release.json",
        "target-handover-release.json",
        "actual-foreign-source-release.patch",
        "job-release.bound.json",
        "original-release-submit-v2.json",
        "storage-cover-correction-v1.json",
        "prepare_release.py",
        "submit_release.py",
    ]:
        p = SOFTWARE / name
        if p.exists():
            paths.append(p)
    paths += old.files_below(BASE / "normal208-entry-v1")
    paths.append(OUT / "preserve.py")
    paths = [
        p
        for p in paths
        if not any(x in p.name for x in ["backup", "beads"])
        and not p.name.startswith(("show", "ready", "update", "note-"))
    ]
    for p in paths:
        assert (
            p.suffix not in {".onnx", ".pt", ".so", ".bin", ".lock", ".pem", ".key"}
            and not p.is_symlink()
        )
        assert p.stat().st_size < 8 * 1024**2
    name = "aspiration-genuine-release-v1.tar.gz"
    old.DEST = DEST
    old.write_archive(
        name,
        paths,
        "Original3e17722b genuine release once normalfinalize and actualsourceSTOP, preserved affinity refusal beforefinalize, actualpostprefix cache/capacity correction, originalnormal208 real inputs/support and causal CPU2 support derivative. No ELF/models/libs/cache/DB/sealed payload; no test/build/scientific replay. Original208 outcome is not qualified by this archive; separate savedresult follows.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    completion = json.loads(
        (SOFTWARE / "release-collection-v1/completion-and-STOP.json").read_bytes()
    )
    value = dict(
        issue="quoridor-4lc.324.29",
        status=completion["status"],
        software_manifest=completion["software_manifest"],
        artifact=completion["artifact"],
        outer_seconds_once=completion["outer_seconds_once"],
        nested_added=0,
        completed_tests="AI3+RunnerLIB2 each running1 and affectedClippy warning0; priorPython1 retained",
        original_build_job="3e17722b-a816-4e2c-97e3-02302b2ec498",
        original208_job="5112dd76-9b03-47b7-b1e5-82e65802ea4f",
        scientific_outcome="Separate savedanalysis; no strength/adoption inferred",
        archive=dict(
            path=name,
            sha256=manifest["sha256"],
            bytes=manifest["bytes"],
            members=len(manifest["members"]),
            stream_SHA_size_mode_verified=True,
        ),
        fees_global_actual="UNKNOWN",
    )
    with (DEST / "aspiration-genuine-release-v1.json").open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    print(json.dumps(value["archive"]))


if __name__ == "__main__":
    main()
