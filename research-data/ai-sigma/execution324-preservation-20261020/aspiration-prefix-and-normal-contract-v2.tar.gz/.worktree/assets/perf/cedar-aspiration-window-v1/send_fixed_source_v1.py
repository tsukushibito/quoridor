"""Direct fixed source and actual returned author boundary to existing Root324."""

from datetime import datetime, timezone
import json
from pathlib import Path
import sys

from task_utils import OWN, ROOT, command, ref, save

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    stage = OWN / "source-return-guard-v1"
    guard = json.loads((stage / "result.json").read_text())
    assert guard["status"] == "PASS" and guard["TMP_remaining"] == []
    known = []
    for identity in [
        guard["controller"],
        *(r["guardian_return"]["child"] for r in guard["checks"]),
    ]:
        current = process.process_info(identity["pid"])
        assert (current is None and not Path(f"/proc/{identity['pid']}").exists()) or (
            current is not None and process.identity(current) != identity
        )
        known.append(
            dict(expected=identity, now="ABSENT" if current is None else "DIFFERENT")
        )
    receipt = save(
        OWN / "actual-fixed-source-STOP-v1.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            returned_source_admin_guard=ref(stage / "result.json"),
            returned_source=ref(OWN / "fixed-source-return-v1.json"),
            exact_known_fresh=known,
            Main_reader=False,
            source_leases=[],
            owned_native=[],
            TMP_entries=[],
            scope="Only actual original29 source/admin helpers returned; this separate bounded delivery follows. No futurehostquiet or performance/software qualification.",
        ),
    )
    fixed = ref(OWN / "fixed-source-v1/binding.json")
    protocol = ref(OWN / "finite-protocol-v1.json")
    message = OWN / "Root-fixed-source-v1.txt"
    message.write_text(
        "SAME29 FIXED private common-root aspiration source now returned, not sourceclear/software/native. "
        "Actual source CPU2/G18/family1GiB incl64/host4/G0, sameSol6.1high/Main/fullnever/context previously verified. "
        "Immutable1dce95b sparse9subjects only, noMain/Git/index/Cargo/docs or otherOWN writes. "
        "TypedONE width.125/growth2/activation3/max4 failed-side expansions then onefullsame-depth fallback; D1/2full seeds. "
        "Center onlyprevious successful SAME-call iteration; common root/PVS const WINDOWED, OFFdirect originalfull route without retry-counter snapshots, "
        "cumulative nodes/evals/deadline/cancel unchanged, failedBounds no completedroot/PV/callback. Completed child typedTT effects preserved onASPabort, parentrestore failure clears. "
        "Exact shared child/negamax/reduced_child/forced-root/LMR/FT kernels protected; forcedROOT full semantics/SMP refusal preserved. "
        "Important existingAPI fact for relatedboundary: fatal evaluator returns Err, lastcompleted callback/nativecache intact, never fakeOk. FatalErr partial fullSearch stats remain unavailable under existingErr API (UNKNOWN); successful/Stop returns carry actual boundedattempt work. "
        "Please include this precise error/partial-work boundary with rootBounds/TTcommit/cumulative retry/namespace/native consumers in SAME relatedMax confirmation, only viaRoot. Author dispatch/selfclear0. "
        "NewAI3/RunnerLIB2/Python1 exactselectors in packet, ALLUNBUILT_UNTYPED_UNRUN; scopedrustfmt/Ruff/parser PASS only, tests/compiler/native/model/RAW/RNG0. "
        "Thinforward/inverse nofuzz/nooffset byte/mode roundtrip passed before later checker incorrectly assumed8space fixturefield; causal metadata suffix corrected16space checker ONLY, no source/test or patch command replay. "
        "Half retirement overlap ACTUAL alpha namespace/reset + Runner config/runtime/measurement + LCconfig/evidence. New29adds noHalf reference/newHalf test; predecessorHalf sections remainbeforeexact for your thin composition, NEVER wholeoldpost overwrite. NoHigh9OWN read/wait. "
        "Frozen protocol208/208M/48sessions/26genuine6chronologicalseries Current/N1OFF-ON-ON-OFF fixeddepth then100ms5, all1M cumulative. "
        "Conservative savedcommitteddepth-1 capped8 ->root4D5, no pilot; fixeddepthcensor =>timeUNKNOWN/nosubset. "
        "Conditionalnew128games/64canonicalordinals0..63/2.048G nonfungible4x512M, seed3242920261020; solePCG64seed3242920261021/10000/linear95 onlyALL128/64pairsUNKNOWN0+STOP, lower>.5 finitecandidate only. Historical exposureYES/notunseen. "
        "Practical timing/clock/majorregression gates frozen, no integerdepth/CPU-only veto. "
        "Actualfuture BUILD/image/support/currentnormaljoin/whole/origin remainNULL, NOT_RUNNABLE. Nextnecessary stages Root relatedfixedsource sparseadoption/newexactsoftware/currentimage/admission only, noHumanACK/parent/28 gate. "
        + json.dumps(
            dict(
                fixed=fixed,
                protocol=protocol,
                actual_source_STOP=receipt,
                ordinary_affected=ref(OWN / "source-ordinary-affected-point-v1.json"),
            )
        )
        + ". Meaningful own29note+backupPASS/sameassigneeinprogress; original27conditional64/28fixeddesign preserved. Allpauses/seals/models/defaults/foreign/FAILED/NULL/UNKNOWNfees/50GB/consultation8 retained.\n"
    )
    result = command(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--issue",
            "quoridor-4lc.324",
            "--cwd",
            str(ROOT),
            "--body-file",
            str(message),
        ]
    )
    saved = save(OWN / "Root-fixed-source-delivery-v1.json", result)
    print(
        json.dumps(
            dict(
                fixed=fixed,
                actual_source_STOP=receipt,
                delivery=saved,
                delivery_returncode=result["returncode"],
            )
        )
    )


if __name__ == "__main__":
    main()
