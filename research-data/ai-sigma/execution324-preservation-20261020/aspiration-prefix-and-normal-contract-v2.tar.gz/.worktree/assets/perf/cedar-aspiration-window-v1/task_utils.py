"""Small task-owned metadata and direct command helpers for original29."""

import hashlib
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
ACTOR = "codex:01a11004-79f3-7c20-872c-432a2c347664"
ISSUE = "quoridor-4lc.324.29"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def save(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")
    return ref(path)


def command(argv):
    with subprocess.Popen(
        argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate(timeout=60)
        code = child.wait()
    assert child.stdout.closed and child.stderr.closed
    return dict(
        argv=argv,
        returncode=code,
        stdout=stdout.decode(),
        stderr=stderr.decode(),
        directwait_reaped=True,
        handles_closed=True,
    )


def authority(name, args):
    record = command(["bash", "scripts/dev/beads.sh", *args])
    save(OWN / f"authority-{name}.json", record)
    assert record["returncode"] == 0, record
    return json.loads(record["stdout"])
