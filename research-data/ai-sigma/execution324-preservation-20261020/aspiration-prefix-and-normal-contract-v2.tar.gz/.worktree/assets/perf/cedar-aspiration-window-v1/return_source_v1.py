"""Return the fixed original29 author scope and normal own issue note at real STOP."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import sys

from task_utils import ACTOR, ISSUE, OWN, ROOT, authority, ref, save

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def fresh(identity):
    current = process.process_info(identity["pid"])
    assert (current is None and not Path(f"/proc/{identity['pid']}").exists()) or (
        current is not None and process.identity(current) != identity
    ), identity
    return dict(expected=identity, now="ABSENT" if current is None else "DIFFERENT")


def main():
    # Only original29 returned guard identities. No host/process/global audit.
    stages = sorted(OWN.glob("*-guard-v*/result.json"))
    known = {}
    cleanup = []
    for path in stages:
        record = json.loads(path.read_text())
        identities = [record["controller"]]
        for row in record["checks"]:
            actual = row.get("guardian_return")
            if actual is None:
                saved = path.parent / (row["name"] + ".process.json")
                if saved.exists():
                    actual = json.loads(saved.read_text())
            if actual is not None:
                assert actual.get("remaining", []) == [], actual
                if actual.get("child"):
                    identities.append(actual["child"])
        for identity in identities:
            known[(identity["pid"], identity["start_ticks"], identity["boot_id"])] = (
                fresh(identity)
            )
        tmp = path.parent / "TMP"
        if tmp.exists():
            for entry in tmp.iterdir():
                info = entry.lstat()
                assert entry.name.startswith("uv-") and entry.name.endswith(".lock")
                assert (
                    stat.S_ISREG(info.st_mode)
                    and info.st_size == 0
                    and info.st_nlink == 1
                )
                fd = os.open(entry, os.O_RDONLY | os.O_NOFOLLOW)
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    assert (
                        os.fstat(fd).st_ino == info.st_ino and entry.stat().st_size == 0
                    )
                    entry.unlink()
                finally:
                    os.close(fd)
                cleanup.append(str(entry))
            tmp.rmdir()
    authority("fixed-ready-v1", ["ready", "--json"])
    issue = authority("fixed-show-v1", ["show", ISSUE, "--json"])
    issue = issue[0] if isinstance(issue, list) else issue
    assert issue["assignee"] == ACTOR and issue["status"] == "in_progress"
    note = (
        "Original29 private common-root aspiration FIXED against immutable1dce95b; "
        "fixed-source-v1/binding.json 2a899977c5196bc2a1becb129a5c41367622cfdef69a581ba37d3e6f2dc9d984/10483. "
        "ONE .125/growth2/D3/4 expansions+full fallback same depth, seedD1/2. "
        "Same-call completed snapshot only; typed failed Bounds/cumulative nodes/evals/time/cancel, "
        "defaultOFF direct full window, forced-root full/nativeSMP refusal. FatalErr API stillErr, prior callback intact. "
        "Thin forward/inverse zero-fuzz/nooffset byte/mode roundtrip completed before metadata fixture-indentation checker refusal; "
        "causal suffix corrected checker only, source untouched. Protected child/negamax/reduced_child/forced-root/math bodies exact. "
        "Scoped rustfmt/Ruff PASS; AI3/RunnerLIB2/Python1 UNBUILT_UNTYPED_UNRUN, author tests/compiler/Search/model/RAW/RNG0. "
        "New aspiration Half dependencies removed; actual config/runtime/measurement/LC/namespace overlap needs Root sparse composition "
        "with independent retirement, no otherOWN read. finite-protocol-v1.json2673cc67/29992 freezes208calls208M/48sessions "
        "and conditional128games64families2.048G/soleCI; root4depth5, all26 predecessors, Current fixed. "
        "Build/image/support/numerical normaljoin/origin genuine futureNULL. Root related semantic review/software/entry remaining. "
        "Original27conditional64/28fixed design and all pauses/seals/defaults/models/foreign/FAILED/NULL/UNKNOWNfees/50GB preserved."
    )
    authority("fixed-note-v1", ["update", ISSUE, "--append-notes", note, "--json"])
    authority("fixed-backup-v1", ["backup", "sync", "--json"])
    identities = set()
    allocated = logical = files = 0
    for root, _, names in os.walk(OWN):
        for name in names:
            path = Path(root) / name
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode), path
            key = (info.st_dev, info.st_ino)
            if key not in identities:
                identities.add(key)
                allocated += info.st_blocks * 512
                logical += info.st_size
                files += 1
    point = save(
        OWN / "source-ordinary-affected-point-v1.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            root=str(OWN),
            allocated_B=allocated,
            logical_B=logical,
            files=files,
            measurement="OWN29 affected inode union once after source/preparation/admin; later delivery/control tails UNKNOWN",
            not_grant=True,
            global_actual_fullfees="UNKNOWN",
            prior_holding_refund_loan_recharge=0,
        ),
    )
    returned = save(
        OWN / "fixed-source-return-v1.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            fixed_binding=ref(OWN / "fixed-source-v1/binding.json"),
            protocol=ref(OWN / "finite-protocol-v1.json"),
            controls=ref(OWN / "finite-preparation-v1/binding.json"),
            source_guards=[ref(p) for p in stages],
            exact_known_identities_fresh=list(known.values()),
            returned_empty_uv_locks_removed=cleanup,
            source_leases_remaining=[],
            owned_native_helpers=[],
            main_reader_held=False,
            tests_compiler_native_model_RAW_RNG=0,
            status="SOURCE_FIXED_NOT_REVIEWED_NOT_SOFTWARE_NOT_NUMERIC",
            ordinary_affected_point=point,
            own_status="in_progress",
            note_backup="PASS",
            current_admin_lifetime="This helper and its enclosing guard return separately; no futurehostquiet assertion",
        ),
    )
    print(
        json.dumps(
            dict(source_return=returned, affected=point, known_returned=len(known))
        )
    )


if __name__ == "__main__":
    main()
