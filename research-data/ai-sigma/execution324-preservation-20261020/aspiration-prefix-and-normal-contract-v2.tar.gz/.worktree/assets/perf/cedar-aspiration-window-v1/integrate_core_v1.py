"""Connect the one opt-in window to existing root/PVS and cumulative Search state."""

import gzip
import json

from task_utils import OWN, ref, save


def once(text, before, after):
    assert text.count(before) == 1, (text.count(before), before[:100])
    return text.replace(before, after)


def main():
    base = OWN / "source-v1"
    text = gzip.decompress((base / "before/alphabeta.rs.gz").read_bytes()).decode()
    text = once(
        text,
        "pub const TERMINAL_SCORE: f32 = 2.0;",
        """#[path = "aspiration_window.rs"]
mod aspiration_window;
pub use aspiration_window::{AspirationStats, AspirationWindow};

pub const TERMINAL_SCORE: f32 = 2.0;""",
    )
    text = once(
        text,
        "pub struct SearchStats {",
        """pub struct SearchStats {
    /// Root-only research option; None retains the original OFF route.
    pub root_aspiration: Option<AspirationWindow>,
    pub aspiration_work: Option<AspirationStats>,""",
    )
    text = once(
        text,
        "pub struct SearchSession {\n    namespace: SearchNamespace,",
        """pub struct SearchSession {
    namespace: SearchNamespace,
    aspiration: Option<AspirationWindow>,""",
    )
    text = once(
        text,
        "        Ok(Self {\n            namespace,",
        "        Ok(Self {\n            namespace,\n            aspiration: None,",
    )
    text = once(
        text,
        "impl SearchSession {\n    fn detach_safe_race_namespace",
        """impl SearchSession {
    /// Changing the effective window policy clears TT/history. Equal settings warm normally.
    pub fn set_root_aspiration(&mut self, config: Option<AspirationWindow>) -> Result<()> {
        let config = config.map(AspirationWindow::validate).transpose()?;
        #[cfg(not(target_arch = "wasm32"))]
        if config.is_some() && self.native_workers.is_some() {
            return Err(SearchError::Limits("root aspiration requires LOCAL1".into()));
        }
        #[cfg(feature = "research-diagnostics")]
        if config.is_some() && matches!(self.method, SessionMethod::Opportunity(_)) {
            return Err(SearchError::Limits("root aspiration does not admit diagnostic ordering".into()));
        }
        if config == self.aspiration { return Ok(()); }
        if let Some(old) = self.aspiration { old.remove_namespace(&mut self.namespace); }
        self.aspiration = config;
        if let Some(config) = config { config.qualify_namespace(&mut self.namespace); }
        self.table.clear();
        if let Some(history) = self.ordering.as_mut() { history.reset(); }
        Ok(())
    }
    pub fn root_aspiration(&self) -> Option<AspirationWindow> { self.aspiration }

    fn detach_safe_race_namespace""",
    )
    text = once(
        text,
        "        self.score_domain = score_domain;\n        self.table.clear();",
        """        self.score_domain = score_domain;
        if let Some(config) = self.aspiration { config.qualify_namespace(&mut self.namespace); }
        self.table.clear();""",
    )
    text = once(
        text,
        "        if let Some(mut workers) = self.native_workers.take() {",
        """        if self.native_workers.is_some() && self.aspiration.is_some() {
            return Err(SearchError::Limits("root aspiration requires LOCAL1".into()));
        }
        #[cfg(not(target_arch = "wasm32"))]
        if let Some(mut workers) = self.native_workers.take() {""",
    )
    text = once(
        text,
        "    forced_root: Option<u16>,\n    lmr_table:",
        "    forced_root: Option<u16>,\n    aspiration: Option<AspirationWindow>,\n    lmr_table:",
    )
    text = once(
        text,
        "            forced_root: None,\n            lmr_table:",
        "            forced_root: None,\n            aspiration: None,\n            lmr_table:",
    )
    marker = "        invocation.lmr_table = self.lmr_table.as_deref();"
    location = text.index(marker, text.index("    fn search_invocation<'a>("))
    text = (
        text[:location]
        + "        invocation.aspiration = self.aspiration;\n"
        + text[location:]
    )
    text = once(
        text,
        "            lmr_enabled: lmr,",
        """            root_aspiration: invocation.aspiration,
            aspiration_work: invocation.aspiration.map(|_| AspirationStats::default()),
            lmr_enabled: lmr,""",
    )
    start = text.index("    fn root_depth(\n")
    end = text.index("    fn pv(&self,", start)
    root = text[start:end]
    root = once(
        root, "    fn root_depth(\n", "    fn root_depth<const WINDOWED: bool>(\n"
    )
    root = once(
        root,
        "        previous: Option<u16>,\n    )",
        "        previous: Option<u16>,\n        window: [f32; 2],\n    )",
    )
    root = once(
        root,
        "        let mut value = f32::NEG_INFINITY;",
        """        let original_alpha = if WINDOWED { window[0] } else { f32::NEG_INFINITY };
        let beta = if WINDOWED { window[1] } else { f32::INFINITY };
        let mut alpha = original_alpha;
        let mut value = f32::NEG_INFINITY;""",
    )
    root = root.replace("[value, next_up(value)]", "[alpha, next_up(alpha).min(beta)]")
    root = root.replace("[value, f32::INFINITY]", "[alpha, beta]")
    root = root.replace("i > 0 && v > value", "i > 0 && v > alpha && v < beta")
    root = once(
        root,
        """                best = Some(action);
            }
        }
        self.control()?;""",
        """                best = Some(action);
            }
            alpha = alpha.max(v);
            if WINDOWED && alpha >= beta { break; }
        }
        self.control()?;""",
    )
    root = once(
        root,
        "                    bound: Bound::Exact,",
        """                    bound: if WINDOWED {
                        aspiration_window::bound(value, [original_alpha, beta])
                    } else { Bound::Exact },""",
    )
    text = text[:start] + root + text[end:]
    text = once(
        text,
        """                state.root_depth(&mut c, a.as_ref(), depth, result.action)?""",
        """                let mut narrow = invocation.aspiration.and_then(|config| {
                    (depth >= config.activation_depth).then_some(())?;
                    config.start(result.value?, score_domain)
                });
                let mut full_fallback = false;
                loop {
                    let window = narrow.as_ref().filter(|_| !full_fallback)
                        .map_or([f32::NEG_INFINITY, f32::INFINITY], |w| w.bounds);
                    let before = [state.stats.nodes, state.stats.evaluations];
                    let attempt = if narrow.is_some() {
                        state.root_depth::<true>(&mut c, a.as_ref(), depth, result.action, window)
                    } else {
                        state.root_depth::<false>(&mut c, a.as_ref(), depth, result.action, window)
                    };
                    let used = [state.stats.nodes - before[0], state.stats.evaluations - before[1]];
                    if let Some(work) = state.stats.aspiration_work.as_mut() {
                        work.attempts += 1;
                        work.nodes += used[0];
                        work.evaluations += used[1];
                        work.full_seed_searches += u64::from(narrow.is_none());
                    }
                    let (action, value) = attempt?;
                    let bound = aspiration_window::bound(value, window);
                    if !matches!(bound, Bound::Upper | Bound::Lower) { break (action, value); }
                    // Only a completed bound search reaches this point; no depth/callback commit.
                    let work = state.stats.aspiration_work.as_mut().expect("active root window");
                    match bound {
                        Bound::Upper => work.fail_low += 1,
                        Bound::Lower => work.fail_high += 1,
                        _ => unreachable!(),
                    }
                    work.retries += 1;
                    if !narrow.as_mut().expect("narrow window").widen(bound) {
                        full_fallback = true;
                        work.full_fallbacks += 1;
                    }
                    // Completed child/root Bounds remain valid. Same generation, same cumulative
                    // Search state, nodes/evaluations/deadline/cancel budget for every retry.
                    state.table.commit();
                }""",
    )
    text = once(
        text,
        """    if !SMP && run.is_err() {
        state.table.discard_uncommitted();
    }""",
        """    if !SMP && run.is_err() {
        if invocation.aspiration.is_some() && invocation.forced_root.is_none() {
            // Inserts occur only at completed nodes after their final control check.
            // Retain valid typed Bounds; an interrupted root never inserts/completes.
            state.table.commit();
        } else {
            state.table.discard_uncommitted();
        }
    }""",
    )
    post = base / "post/crates/quoridor-ai/src/alphabeta.rs"
    with post.open("x") as stream:
        stream.write(text)
    module = base / "post/crates/quoridor-ai/src/aspiration_window.rs"
    mod = module.read_text()
    mod = once(
        mod,
        "    pub attempts: u64,",
        "    pub attempts: u64,\n    pub full_seed_searches: u64,",
    )
    mod += """

pub(super) fn bound(value: f32, window: [f32; 2]) -> Bound {
    if value <= window[0] { Bound::Upper }
    else if value >= window[1] { Bound::Lower }
    else { Bound::Exact }
}
"""
    module.write_text(mod)
    print(
        json.dumps(
            save(
                base / "core-integration.json",
                dict(
                    alpha=ref(post),
                    window=ref(module),
                    scope="Common root full/narrow monomorphs, typed Bound, cumulative retry state and last-completed authority; consumer integration/tests pending",
                    Main_Cargo_tests_native_model_RNG=0,
                ),
            )
        )
    )


if __name__ == "__main__":
    main()
