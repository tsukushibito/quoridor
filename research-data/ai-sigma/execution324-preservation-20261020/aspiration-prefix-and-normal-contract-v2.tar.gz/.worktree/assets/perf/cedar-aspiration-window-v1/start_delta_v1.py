"""Write the one finite aspiration-window state into private sparse source."""

from collections import Counter
import json
import struct

from task_utils import OWN, ROOT, save


def main():
    path = (
        ROOT
        / ".worktree/assets/perf/cedar-ordering-quality-v1/numeric-v1/analysis-v1/snapshot-rows.json"
    )
    samples = json.loads(path.read_bytes())
    transitions = []
    for index in range(26):
        rows = {row["slot"]: row for row in samples if row["root_index"] == index}
        first, last = rows["first_completed"], rows["last_completed"]

        def decode(bits):
            return struct.unpack("!f", struct.pack("!I", bits))[0]

        before, after = decode(first["value_bits"]), decode(last["value_bits"])
        transitions.append(
            dict(
                root=index,
                first_depth=first["depth"],
                last_depth=last["depth"],
                first=before,
                last=after,
                abs_change=abs(after - before),
                stock=last["stock"],
                session_first=last["session_first"],
                overall_stop=last["overall_stop"],
            )
        )
    selection = save(
        OWN / "window-selection-v1.json",
        dict(
            source="Saved21 first/latest scalar metadata only; no native/RAW/model/input payload replay",
            transitions=transitions,
            abs_first_last_gt_one_eighth=sum(
                r["abs_change"] > 0.125 for r in transitions
            ),
            overall_stops=dict(Counter(r["overall_stop"] for r in transitions)),
            missing="Adjacent completed-iteration transitions between first/latest are NOT saved, so failure/retry frequency at activation cannot be estimated. First/latest may span different TT/history/depth and is not a calibration/performance experiment.",
            candidate=dict(
                half_width=0.125,
                growth=2.0,
                activation_depth=3,
                max_retries=4,
                full_window_seed_depths=[1, 2],
                fallback="Full infinite window after4 failed-side expansions at the same requested depth; no budget reset",
                domain="Cedar legacy tanh nonterminal[-1,1], terminal+/-2. Width1/8 of nonterminal absolute bound is one conservative fixed initial candidate, not learned from outcomes. Declared raw domains remain checked; terminal/nonfinite centers never seed narrow windows.",
            ),
            new29_calls=0,
        ),
    )
    post = OWN / "source-v1/post/crates/quoridor-ai/src/aspiration_window.rs"
    post.parent.mkdir(parents=True)
    with post.open("x") as stream:
        stream.write(SOURCE)
    print(
        json.dumps(
            dict(
                actual_private_delta=str(post),
                selection=selection,
                scope="Typed finite window state implementation; common root/config integration follows, not software/numeric qualification",
            )
        )
    )


SOURCE = """//! Research-only root aspiration. No clock, node budget, or depth ownership here.
use super::{Bound, Result, ScoreDomain, SearchError, SearchNamespace};

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct AspirationWindow {
    pub half_width: f32,
    pub growth: f32,
    pub activation_depth: u16,
    pub max_retries: u8,
}
impl AspirationWindow {
    pub fn validate(self) -> Result<Self> {
        if !self.half_width.is_finite() || self.half_width <= 0.
            || !self.growth.is_finite() || self.growth <= 1.
            || !(2..=64).contains(&self.activation_depth) || self.max_retries > 8 {
            return Err(SearchError::Limits("invalid finite root aspiration settings".into()));
        }
        Ok(self)
    }
    fn prefix(self) -> String {
        format!("root-aspiration-v1:{:08x}:{:08x}:{}:{}:", self.half_width.to_bits(), self.growth.to_bits(), self.activation_depth, self.max_retries)
    }
    /// Prefix avoids interfering with existing trailing LMR/proof/history qualifiers.
    pub fn qualify_namespace(self, namespace: &mut SearchNamespace) {
        namespace.selectivity.insert_str(0, &self.prefix());
    }
    pub(super) fn remove_namespace(self, namespace: &mut SearchNamespace) {
        let prefix = self.prefix();
        debug_assert!(namespace.selectivity.starts_with(&prefix));
        namespace.selectivity.drain(..prefix.len());
    }
    pub(super) fn start(self, center: f32, domain: ScoreDomain) -> Option<Window> {
        if !domain.admits(center) {
            return None;
        }
        let bounds = [center - self.half_width, center + self.half_width];
        if !bounds.iter().all(|v| v.is_finite()) || bounds[0] >= bounds[1] {
            return None;
        }
        Some(Window { bounds, delta: self.half_width, expanded: 0, config: self })
    }
}

pub(super) struct Window {
    pub bounds: [f32; 2],
    delta: f32,
    expanded: u8,
    config: AspirationWindow,
}
impl Window {
    /// None requests the one final full-window attempt, never another depth/cap.
    pub fn widen(&mut self, failure: Bound) -> bool {
        if self.expanded >= self.config.max_retries {
            return false;
        }
        self.delta *= self.config.growth;
        match failure {
            Bound::Upper => self.bounds[0] -= self.delta,
            Bound::Lower => self.bounds[1] += self.delta,
            _ => return false,
        }
        self.expanded += 1;
        self.bounds.iter().all(|v| v.is_finite()) && self.bounds[0] < self.bounds[1]
    }
}

#[derive(Debug, Default, Clone)]
pub struct AspirationStats {
    pub attempts: u64,
    pub fail_low: u64,
    pub fail_high: u64,
    pub retries: u64,
    pub full_fallbacks: u64,
    pub nodes: u64,
    pub evaluations: u64,
}
"""


if __name__ == "__main__":
    main()
