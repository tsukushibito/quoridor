# 原29 固定source境界（software/numeric未実施）

幅0.125、成長2、深さ3から、失敗側4回拡大後に同じ深さの全窓へ一度戻す一候補。Cedar非終端[-1,1]の1/8であり、結果から選択・最適化していない。保存21の26件はfirst/latestのみで、隣接完了反復のscore差はUNKNOWN。速度・retry頻度の予測には使わない。

共通root/PVSをWINDOWED constで一箇所共有し、OFFはretry集計へ入らない。ONだけ根のUpper/Lowerを分類して再探索し、最後に成功した深さのsnapshotだけを公開する。node/eval/clock/取消を再割当しない。正しく完了した子のTT効果は保持し、親復元不一致では既存どおりclearする。fatal evaluator Errは既存のErr APIのまま、直前callback/native cacheは保存する。これを成功SearchResultへ偽装しない。

Root退役担当との実重複はalpha namespace/reset、Runner config/runtime/measurement、LCの型・記録owner。新aspiration部分はHalfを参照せず、新fixtureも切替fieldを省略した。古いHalf既存部分はこのimmutable beforeと同じであり、Rootが別の退役差分を疎結合する。相手OWNは読んでいない。

子/negamax/reduced_child/forced-root/評価・FT・LMR本体はbyte保護。原fixtureにはNone一欄のみ。新AI3/RunnerLIB2/Python1定義はUNBUILT/UNTYPED/UNRUN。rustfmt/変更関数Ruff/構文/薄いpatch正逆だけ実施。old model/FP32/性能の新資格はない。Root限定確認・実software・真正image・normal entryが残る。

原208は26prefix全系列・Current固定・N1OFF/ON同新image・8pass・各1M。depthは保存完了値-1を上限8にし、root4は5。条件付き128局/64families/2.048Gと唯一CIを結果前固定したが、実support/entryは未発行。原27/28、全pause/seal/モデル/default/foreign/FAILED/UNKNOWN/50GBを保持。
