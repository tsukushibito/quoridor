"""Remove only the returned original29 delivery's empty uv lock, no new dispatch."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import sys

from task_utils import OWN, ROOT, ref, save

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    stage = OWN / "fixed-source-delivery-guard-v1"
    result = json.loads((stage / "result.json").read_text())
    assert result["status"] == "PASS"
    identities = [
        result["controller"],
        *(r["guardian_return"]["child"] for r in result["checks"]),
    ]
    fresh = []
    for identity in identities:
        now = process.process_info(identity["pid"])
        assert (now is None and not Path(f"/proc/{identity['pid']}").exists()) or (
            now is not None and process.identity(now) != identity
        )
        fresh.append(
            dict(expected=identity, now="ABSENT" if now is None else "DIFFERENT")
        )
    tmp = stage / "TMP"
    removed = []
    for path in tmp.iterdir():
        info = path.lstat()
        assert path.name.startswith("uv-") and path.name.endswith(".lock")
        assert stat.S_ISREG(info.st_mode) and info.st_size == 0 and info.st_nlink == 1
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            assert os.fstat(fd).st_ino == info.st_ino and path.stat().st_size == 0
            path.unlink()
        finally:
            os.close(fd)
        removed.append(str(path))
    tmp.rmdir()
    saved = save(
        OWN / "delivery-tail-STOP-v1.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            source_STOP=ref(OWN / "actual-fixed-source-STOP-v1.json"),
            returned_delivery_guard=ref(stage / "result.json"),
            delivery=ref(OWN / "Root-fixed-source-delivery-v1.json"),
            fresh_exact_known_ids=fresh,
            removed_returned_empty_locks=removed,
            TMP_entries=[],
            source_leases=[],
            reservations=[],
            native_remaining=[],
            directwait_reap_handles="Actual returned guard records, notification separate from original source; this cleanup guard return follows",
            later_tails_global_actual_fullfees="UNKNOWN",
            source_software_numerical="fixed private source only; no tests/compiler/native/model/RAW/RNG",
        ),
    )
    print(json.dumps(dict(actual_delivery_tail_STOP=saved)))


if __name__ == "__main__":
    main()
