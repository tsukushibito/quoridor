"""Mechanical None/full-window call plumbing only; no tests or compiler."""

import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import command, ref, save  # noqa: E402

OUT = Path(__file__).resolve().parent
RUSTFMT = "/usr/local/cargo/bin/rustfmt"


def raw_ref(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), mode="0644")


def main():
    resume = sys.argv[1:] == ["--after-insert-coordinate-refusal"]
    intake = json.loads((OUT / "intake.json").read_text())
    post = OUT / "post"
    subjects = []
    changes = []
    before_by_path = {}
    allowed = {}
    for item in intake["subjects"]:
        name = item["path"]
        old = gzip.decompress(Path(item["before_gzip"]["path"]).read_bytes()).decode()
        before_by_path[name] = old
        if name.endswith("lmr_observation.rs"):
            needle = "                forced_root: None,\n"
            assert old.count(needle) == 3 and old.count("SearchInvocation {") == 3
            new = old.replace(needle, "                aspiration: None,\n" + needle)
            assert new.replace("                aspiration: None,\n", "") == old
            permitted = [
                (i, i) for i, line in enumerate(old.splitlines(True)) if line == needle
            ]
            changes.append(
                dict(
                    path=name,
                    initializers=3,
                    add="aspiration: None",
                    meaning="diagnostic/trial aspiration OFF; no admission or semantics change",
                )
            )
        else:
            pattern = r"\.root_depth\(c, None, ([13]), None\)"
            found = list(re.finditer(pattern, old))
            assert len(found) == 1, (name, len(found))
            match = found[0]
            new = (
                old[: match.start()]
                + f".root_depth::<false>(c, None, {match[1]}, None, [f32::NEG_INFINITY, f32::INFINITY])"
                + old[match.end() :]
            )
            line_start = old.rfind("\n", 0, match.start()) + 1
            line_end = old.find("\n", match.end()) + 1
            permitted = [(old[:line_start].count("\n"), old[:line_end].count("\n"))]
            changes.append(
                dict(
                    path=name,
                    root_calls=1,
                    depth=match[1],
                    route="root_depth::<false> original full [-inf,+inf], unchanged twofield tuple",
                    old_statement=old[line_start:line_end].rstrip(),
                )
            )
        allowed[name] = permitted
        path = post / name
        if resume:
            assert path.is_file()
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("x") as f:
                f.write(new)
            path.chmod(0o644)
    paths = [str(post / i["path"]) for i in intake["subjects"]]
    if resume:
        formatting = dict(
            original_guard=ref(OUT / "repair-guard-v1/result.json"),
            original_failure=ref(OUT / "repair-guard-v1/private-caller-repair.log"),
            actual_scope="rustfmt and rustfmt --check succeeded before later insertion-coordinate assertion; post unchanged, commands not replayed",
        )
        check = formatting
    else:
        formatting = command(
            [RUSTFMT, "--edition", "2024", "--config", "skip_children=true", *paths]
        )
        assert formatting["returncode"] == 0, formatting
        check = command(
            [
                RUSTFMT,
                "--check",
                "--edition",
                "2024",
                "--config",
                "skip_children=true",
                *paths,
            ]
        )
        assert check["returncode"] == 0, check
    forward = []
    inverse = []
    outside = []
    for item in intake["subjects"]:
        name = item["path"]
        old = before_by_path[name]
        path = post / name
        new = path.read_text()
        # Compare exact lines, avoiding ambiguous indentation alignment in a
        # character diff. All old lines outside the causal statement stay byte exact.
        edits = []
        for tag, i, j, a, b in difflib.SequenceMatcher(
            None, old.splitlines(True), new.splitlines(True), autojunk=False
        ).get_opcodes():
            if tag == "equal":
                continue
            assert any(start <= i <= j <= end for start, end in allowed[name]), (
                name,
                tag,
                i,
                j,
                old.splitlines(True)[i:j],
                new.splitlines(True)[a:b],
            )
            edits.append(dict(kind=tag, old_line_range=[i, j], new_line_range=[a, b]))
        if name.endswith("lmr_observation.rs"):
            assert new.replace("                aspiration: None,\n", "") == old
        else:
            calls = re.findall(r"\.root_depth::<false>\((.*?)\)", new, flags=re.S)
            assert len(calls) == 1
            actual = re.sub(r"\s+", "", calls[0]).rstrip(",")
            depth = next(c["depth"] for c in changes if c["path"] == name)
            assert actual == f"c,None,{depth},None,[f32::NEG_INFINITY,f32::INFINITY]"
            assert ".root_depth(" not in new
        outside.append(
            dict(
                path=name,
                edits=edits,
                allowed_causal_statement_or_insert_ranges=allowed[name],
                outside_causal_bytes_exact=True,
            )
        )
        forward.extend(
            difflib.unified_diff(
                old.splitlines(True),
                new.splitlines(True),
                fromfile="a/" + name,
                tofile="b/" + name,
                n=3,
            )
        )
        inverse.extend(
            difflib.unified_diff(
                new.splitlines(True),
                old.splitlines(True),
                fromfile="a/" + name,
                tofile="b/" + name,
                n=3,
            )
        )
        subjects.append(
            dict(
                path=name,
                before=raw_ref(old.encode()),
                before_gzip=item["before_gzip"],
                post=ref(path),
            )
        )
    for name, lines in [("forward.patch", forward), ("inverse.patch", inverse)]:
        with (OUT / name).open("x") as f:
            f.write("".join(lines))
    temporary = Path(tempfile.mkdtemp(prefix="caller-thin-", dir=os.environ["TMPDIR"]))
    patches = []
    try:
        for item in subjects:
            path = temporary / item["path"]
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(before_by_path[item["path"]])
            path.chmod(0o644)
        for direction in ["forward", "inverse"]:
            result = command(
                [
                    "patch",
                    "--batch",
                    "--fuzz=0",
                    "--no-backup-if-mismatch",
                    "-p1",
                    "-d",
                    str(temporary),
                    "-i",
                    str(OUT / (direction + ".patch")),
                ]
            )
            patches.append(result)
            assert result["returncode"] == 0, result
            assert not any(
                word in (result["stdout"] + result["stderr"]).lower()
                for word in ["offset", "fuzz", "failed", "reversed"]
            )
            for item in subjects:
                path = temporary / item["path"]
                actual = raw_ref(path.read_bytes())
                expected = item["post"] if direction == "forward" else item["before"]
                assert actual == {k: expected[k] for k in actual}
                assert path.stat().st_mode & 0o777 == 0o644
        assert not list(temporary.rglob("*.orig")) and not list(
            temporary.rglob("*.rej")
        )
    finally:
        shutil.rmtree(temporary)
    proof = save(
        OUT / "format-and-thin-check.json",
        dict(
            formatter=formatting,
            formatter_check=check,
            outside_causal_bytes=outside,
            patches=patches,
            strict_GNU_fuzz=0,
            offsets=0,
            full_byte_mode_roundtrip=True,
            compiler_tests_native_model_RAW_RNG=0,
        ),
    )
    binding = save(
        OUT / "binding.json",
        dict(
            issue="quoridor-4lc.324.29",
            status="FIXED_PRIVATE_MECHANICAL_CALLER_REPAIR_NOT_SOFTWARE",
            immutable_before=intake["immutable_commit"],
            correspondence="These seven owners are unchanged by Root13-subject composition per issued authority; sparse adopt only these callsite fields/expressions, no whole old alpha/config post",
            changes=changes,
            subjects=subjects,
            forward=ref(OUT / "forward.patch"),
            inverse=ref(OUT / "inverse.patch"),
            checks=proof,
            signature_reference="Original29 fixedsource2a899977, commonroot const WINDOWED plus fifthwindow. No root/kernel/tuple/signature rewrite.",
            original_failure="Root software9a6d27bf actual libtest type failure before firstAI entered, Python1 alreadyPASS; originalSTOP/log/prefix and costs remain Root immutable",
            necessary_Root_continuation="Only previously unentered AI3/RunnerLIB2 then affectedClippy/genuine release under Root canonical ownership; Python1 and oldsuccess suite not replayed",
            tests_new_definitions_or_source_review_dispatch=0,
            source_protocol_configs_seeds_budgets="Original29 source2a899/protocol2673 and new representation amendment unchanged. Same scope, no scientific reset/new budget.",
            scope="OWN29/caller-repair-v1 only, noMain/Git/index/Cargo/docs writes/otherOWN imports or reads. Source helpers actualSTOP follows return.",
        ),
    )
    print(
        json.dumps(
            dict(
                binding=binding,
                owners=7,
                diagnostic_None=3,
                full_OFF_root_calls=6,
                tests_compiler_native=0,
            )
        )
    )


if __name__ == "__main__":
    main()
