"""Connect typed root aspiration to maintained native consumers and normal LC."""

import gzip
import json

from task_utils import OWN, command, save
from integrate_core_v1 import once


def main():
    base = OWN / "source-v1"
    commit = json.loads((OWN / "intake.json").read_bytes())["immutable_commit"]
    subjects = [
        "crates/quoridor-runner/src/config.rs",
        "crates/quoridor-runner/src/runtime.rs",
        "crates/quoridor-runner/src/measurement.rs",
        "scripts/dev/research-lifecycle.py",
        "crates/quoridor-runner/src/measurement_ordering394_tests.rs",
    ]
    sources = {}
    for subject in subjects:
        saved_before = base / "before" / (subject.rsplit("/", 1)[1] + ".gz")
        if saved_before.exists():
            sources[subject] = gzip.decompress(saved_before.read_bytes()).decode()
            continue
        result = command(["git", "show", f"{commit}:{subject}"])
        assert result["returncode"] == 0
        sources[subject] = result["stdout"]
        with (base / "before" / (subject.rsplit("/", 1)[1] + ".gz")).open(
            "xb"
        ) as stream:
            stream.write(gzip.compress(result["stdout"].encode(), mtime=0))
    config = sources[subjects[0]]
    needle = "#[derive(Debug, Clone, Serialize, Deserialize)]\n#[serde(deny_unknown_fields)]\npub struct Engine {"
    config = once(
        config,
        needle,
        """#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RootAspiration {
    pub half_width: f32,
    pub growth: f32,
    pub activation_depth: u16,
    pub max_retries: u8,
}
impl RootAspiration {
    pub fn resolve(self) -> quoridor_ai::alphabeta::Result<quoridor_ai::alphabeta::AspirationWindow> {
        quoridor_ai::alphabeta::AspirationWindow { half_width:self.half_width, growth:self.growth, activation_depth:self.activation_depth,max_retries:self.max_retries }.validate()
    }
}
impl From<quoridor_ai::alphabeta::AspirationWindow> for RootAspiration {
    fn from(c: quoridor_ai::alphabeta::AspirationWindow) -> Self {
        Self {half_width:c.half_width,growth:c.growth,activation_depth:c.activation_depth,max_retries:c.max_retries}
    }
}
pub(crate) fn deserialize_root_aspiration<'de, D: serde::Deserializer<'de>>(d:D) -> Result<Option<RootAspiration>,D::Error> {
    let config = RootAspiration::deserialize(d)?;
    config.resolve().map_err(serde::de::Error::custom)?;
    Ok(Some(config))
}
"""
        + needle,
    )
    config = once(
        config,
        "pub struct Engine {",
        """pub struct Engine {
    /// Research-only LOCAL1 root window; omission alone retains OFF.
    #[serde(default, deserialize_with="deserialize_root_aspiration", skip_serializing_if="Option::is_none")]
    pub root_aspiration: Option<RootAspiration>,""",
    )
    config = once(
        config,
        "            crate::runtime::arena_shallow_main_history(engine, self.arena.as_ref())",
        "            crate::runtime::arena_root_aspiration(engine, self.arena.as_ref()).map_err(|e| e.to_string())?;\n            crate::runtime::arena_shallow_main_history(engine, self.arena.as_ref())",
    )
    runtime = sources[subjects[1]]
    marker = "pub(crate) fn arena_shallow_main_history("
    runtime = once(
        runtime,
        marker,
        """pub(crate) fn arena_root_aspiration(engine:&Engine, arena:Option<&crate::arena::ArenaConfig>) -> alphabeta::Result<Option<alphabeta::AspirationWindow>> {
    if engine.root_aspiration.is_some() && (
        !matches!(engine.kind.as_str(),"nnue"|"distance")
        || engine.ordering_profile.as_deref()!=Some("control")
        || engine.search_threads.unwrap_or(1)!=1
        || engine.shallow_main_history==Some(crate::config::ShallowMainHistory::Half)
        || arena.is_none_or(|a| a.comparison==crate::arena::Comparison::Functional)
    ) { return Err(alphabeta::SearchError::Limits("root aspiration requires research LOCAL1 Current Control alpha arena".into())); }
    engine.root_aspiration.map(crate::config::RootAspiration::resolve).transpose()
}
"""
        + marker,
    )
    runtime = once(
        runtime,
        "    Ok(namespace)\n}\nfn arena_alpha_session",
        "    if let Some(c)=arena_root_aspiration(engine,arena)? {c.qualify_namespace(&mut namespace);}\n    Ok(namespace)\n}\nfn arena_alpha_session",
    )
    runtime = once(
        runtime,
        "    Ok(session)\n}\n\n/// One TT caller attempt",
        "    session.set_root_aspiration(arena_root_aspiration(engine,arena)?)?;\n    Ok(session)\n}\n\n/// One TT caller attempt",
    )
    runtime = once(
        runtime,
        "    pub actual_shallow_main_history: Option<String>,",
        "    pub actual_shallow_main_history: Option<String>,\n    pub actual_root_aspiration: Option<crate::config::RootAspiration>,",
    )
    runtime = once(
        runtime,
        "        profile.actual_shallow_main_history = Some(session.shallow_main_history().name().into());",
        "        profile.actual_shallow_main_history = Some(session.shallow_main_history().name().into());\n        profile.actual_root_aspiration=session.root_aspiration().map(Into::into);",
    )
    runtime = once(
        runtime,
        '        "actual_shallow_main_history":game.tt_profiles[engine].actual_shallow_main_history,',
        """        "actual_shallow_main_history":game.tt_profiles[engine].actual_shallow_main_history,
        "requested_root_aspiration":config.engines[engine].root_aspiration,
        "actual_root_aspiration":game.tt_profiles[engine].actual_root_aspiration,
        "aspiration_work_completed":selected.and_then(|r| aspiration_work(&r.stats)),
        "aspiration_work_terminal":result.as_deref().and_then(|r| aspiration_work(&r.stats)),""",
    )
    runtime += """

pub(crate) fn aspiration_work(stats:&alphabeta::SearchStats) -> Option<serde_json::Value> {
    stats.aspiration_work.as_ref().map(|w|serde_json::json!({
        "attempts":w.attempts,"full_seed_searches":w.full_seed_searches,
        "fail_low":w.fail_low,"fail_high":w.fail_high,"retries":w.retries,
        "full_fallbacks":w.full_fallbacks,"nodes":w.nodes,"evaluations":w.evaluations,
        "scope":"root attempts including partial interrupted work; one cumulative Search budget, not added to total nodes/evals"
    }))
}
"""
    measurement = sources[subjects[2]]
    measurement = once(
        measurement,
        "    shallow_main_history: Option<crate::config::ShallowMainHistory>,",
        """    shallow_main_history: Option<crate::config::ShallowMainHistory>,
    #[serde(default,deserialize_with="crate::config::deserialize_root_aspiration",skip_serializing_if="Option::is_none")]
    root_aspiration: Option<crate::config::RootAspiration>,""",
    )
    measurement = once(
        measurement,
        "    if settings.shallow_main_history.is_some() && settings.profile != Profile::Control {",
        """    if let Some(c)=settings.root_aspiration {
        c.resolve()?;
        if settings.profile!=Profile::Control || settings.search_threads.unwrap_or(1)!=1
            || settings.shallow_main_history==Some(crate::config::ShallowMainHistory::Half)
            || !settings.use_tt || !settings.use_pvs
            || settings.neighbour_opportunity.is_some() || settings.root_ordering_quality.is_some()
            || settings.history_provenance.is_some()
            || requests.iter().any(|r| r.diagnostic||r.observe_lmr||r.observe_completed_depths||r.warmup) {
            return Err("root aspiration requires ordinary LOCAL1 Current Control measurement".into());
        }
    }
    if settings.shallow_main_history.is_some() && settings.profile != Profile::Control {""",
    )
    measurement = once(
        measurement,
        "        session.set_smp_sharing_provenance(self.settings.smp_sharing_provenance);",
        "        session.set_root_aspiration(self.settings.root_aspiration.map(|c|c.resolve()).transpose()?)?;\n        session.set_smp_sharing_provenance(self.settings.smp_sharing_provenance);",
    )
    measurement = once(
        measurement,
        '        row["actual_selectivity"] = json!(session.namespace().selectivity);',
        """        row["requested_root_aspiration"] = json!(self.settings.root_aspiration);
        row["actual_root_aspiration"] = json!(session.root_aspiration().map(crate::config::RootAspiration::from));
        row["actual_selectivity"] = json!(session.namespace().selectivity);""",
    )
    measurement = once(
        measurement,
        '    result["lmr_rule"] = json!(s.lmr_enabled.then(|| s.lmr_method.id()));',
        """    if let Some(w)=crate::runtime::aspiration_work(s) { result["root_aspiration_work"]=w; }
    result["lmr_rule"] = json!(s.lmr_enabled.then(|| s.lmr_method.id()));""",
    )
    measurement = measurement.replace(
        "shallow_main_history: None,",
        "shallow_main_history: None,\n            root_aspiration: None,",
    )
    fixture = sources[subjects[4]].replace(
        "shallow_main_history: None,",
        "shallow_main_history: None,\n        root_aspiration: None,",
    )
    lc = sources[subjects[3]]
    marker = "def resolved_shallow_main_history(config, profile, *, supported=True):"
    lc = once(
        lc,
        marker,
        """def resolved_root_aspiration(config, profile, *, supported=True):
    if "root_aspiration" not in config:
        return None
    value = config["root_aspiration"]
    require(supported and profile == "control" and config.get("search_threads", 1) == 1
            and resolved_shallow_main_history(config, profile) == "current",
            "root aspiration requires research LOCAL1 Current Control")
    require(isinstance(value, dict) and set(value) == {"half_width", "growth", "activation_depth", "max_retries"}, "typed root aspiration shape")
    require(all(type(value[k]) in (int, float) and math.isfinite(value[k]) for k in ("half_width", "growth"))
            and value["half_width"] > 0 and value["growth"] > 1
            and type(value["activation_depth"]) is int and 2 <= value["activation_depth"] <= 64
            and type(value["max_retries"]) is int and 0 <= value["max_retries"] <= 8,
            "finite bounded root aspiration settings")
    return value


"""
        + marker,
    )
    lc = once(
        lc,
        '            "shallow_main_history",',
        '            "shallow_main_history",\n            "root_aspiration",',
    )
    lc = once(
        lc,
        '    parameters = resolved_lmr_parameters(config, config["profile"])\n    resolved_shallow_main_history(config, config["profile"])',
        """    parameters = resolved_lmr_parameters(config, config["profile"])
    resolved_shallow_main_history(config, config["profile"])
    resolved_root_aspiration(config, config["profile"])
    if "root_aspiration" in config:
        require(config["use_tt"] and config["use_pvs"]
                and all(config.get(k) is None for k in ("neighbour_opportunity", "root_ordering_quality", "history_provenance"))
                and all(not any(r.get(k, False) for k in ("diagnostic", "observe_lmr", "observe_completed_depths", "warmup")) for r in requests),
                "ordinary observer-OFF aspiration measurement")""",
    )
    lc = once(
        lc,
        '    if "shallow_main_history" in config:\n        policy =',
        """    if "root_aspiration" in config:
        aspiration = resolved_root_aspiration(config, config["profile"])
        for row in rows:
            measured = row.get("measurement", {})
            require(measured.get("requested_root_aspiration") == aspiration
                    and measured.get("actual_root_aspiration") == aspiration,
                    "measurement requested/effective root aspiration correspondence")
    if "shallow_main_history" in config:
        policy =""",
    )
    lc = once(
        lc,
        "        resolved_shallow_main_history(\n            engine,",
        """        resolved_root_aspiration(engine, engine.get("ordering_profile"), supported=engine["kind"] in {"nnue", "distance"} and a["comparison"] != "functional")
        resolved_shallow_main_history(
            engine,""",
    )
    lc = once(
        lc,
        '        if engine.get("ordering_profile") is not None:\n            method =',
        """        if "root_aspiration" in engine:
            require(counters.get("requested_root_aspiration") == engine["root_aspiration"]
                    and counters.get("actual_root_aspiration") == resolved_root_aspiration(engine, engine.get("ordering_profile")),
                    "arena requested/effective root aspiration correspondence")
        if engine.get("ordering_profile") is not None:
            method =""",
    )
    for subject, text in zip(
        subjects, [config, runtime, measurement, lc, fixture], strict=True
    ):
        path = base / "post" / subject
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("x") as stream:
            stream.write(text)
    print(
        json.dumps(
            save(
                base / "consumer-integration.json",
                dict(
                    subjects=subjects,
                    old_fixture_update="Only missing None fields, no old test body/assertion or execution",
                    new_tests_native_model_RNG_compiler=0,
                ),
            )
        )
    )


if __name__ == "__main__":
    main()
