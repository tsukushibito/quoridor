"""Finish only the new aspiration owner; keep predecessor policy for sparse composition."""

import ast
import sys

from task_utils import OWN, command, save


def replace(path, before, after):
    text = path.read_text()
    assert text.count(before) == 1, (path, before)
    path.write_text(text.replace(before, after))


def main():
    post = OWN / "source-v1/post"
    runtime = post / "crates/quoridor-runner/src/runtime.rs"
    measurement = post / "crates/quoridor-runner/src/measurement.rs"
    lc = post / "scripts/dev/research-lifecycle.py"
    test = post / "scripts/dev/test_root_aspiration.py"
    alpha = post / "crates/quoridor-ai/src/alphabeta.rs"
    replace(
        runtime,
        "            || engine.shallow_main_history == Some(crate::config::ShallowMainHistory::Half)\n",
        "",
    )
    replace(
        runtime,
        '"ordering_profile":"control","shallow_main_history":"current","root_aspiration"',
        '"ordering_profile":"control","root_aspiration"',
    )
    replace(
        runtime,
        '            ("shallow_main_history", serde_json::json!("half")),\n',
        "",
    )
    replace(
        measurement,
        "            || settings.shallow_main_history == Some(crate::config::ShallowMainHistory::Half)\n",
        "",
    )
    replace(measurement, '        on["shallow_main_history"] = json!("current");\n', "")
    replace(measurement, '            ("shallow_main_history", json!("half")),\n', "")
    replace(
        lc,
        '        and config.get("search_threads", 1) == 1\n        and resolved_shallow_main_history(config, profile) == "current",',
        '        and config.get("search_threads", 1) == 1,',
    )
    replace(
        test,
        '            (dict(root_aspiration=value, shallow_main_history="half"), "control", True),\n',
        "",
    )
    # The default OFF route avoids retry-loop counter snapshots and deltas entirely.
    replace(
        alpha,
        "                state.forced_root_depth(&mut c, a.as_ref(), depth, action)?\n            } else {\n                let mut narrow",
        "                state.forced_root_depth(&mut c, a.as_ref(), depth, action)?\n            } else if invocation.aspiration.is_none() {\n                state.root_depth::<false>(\n                    &mut c, a.as_ref(), depth, result.action,\n                    [f32::NEG_INFINITY, f32::INFINITY],\n                )?\n            } else {\n                let mut narrow",
    )
    initial = lc.read_text()
    node = next(
        n
        for n in ast.parse(initial).body
        if isinstance(n, ast.FunctionDef) and n.name == "resolved_root_aspiration"
    )
    record = command(
        [
            sys.executable,
            "-m",
            "ruff",
            "format",
            "--config",
            "pyproject.toml",
            "--range",
            f"{node.lineno}-{node.end_lineno + 1}",
            str(lc),
        ]
    )
    assert record["returncode"] == 0, record
    assert ast.dump(ast.parse(initial)) == ast.dump(ast.parse(lc.read_text()))
    save(
        OWN / "source-v1/half-independent-composition.json",
        dict(
            base="1dce95b0734770f7da871bafb39bf3a9fa4f0da8",
            new_aspiration_Half_dependencies=0,
            old_preexisting_Half_owners="unchanged for Root sparse composition with separate retirement",
            overlap=[
                "alpha namespace reset",
                "Runner config",
                "runtime session namespace",
                "measurement settings and session",
                "lifecycle config/evidence",
            ],
            default_OFF_counter_snapshot_loop=False,
            tests_compiler_native=0,
            scoped_Python_format=record,
        ),
    )


if __name__ == "__main__":
    main()
