"""Return exact mechanical caller fix and actual bounded author STOP to Root324."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import ACTOR, ISSUE, ROOT, command, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

OUT = Path(__file__).resolve().parent


def beads(name, args):
    result = command(["bash", "scripts/dev/beads.sh", *args])
    save(OUT / (name + ".json"), result)
    assert result["returncode"] == 0, result
    return json.loads(result["stdout"])


def main():
    known = {}
    for stage in ["intake-guard-v1", "repair-guard-v1", "repair-guard-v2"]:
        guard = json.loads((OUT / stage / "result.json").read_text())
        identities = [guard["controller"]]
        for row in guard["checks"]:
            actual = row.get("guardian_return")
            fallback = OUT / stage / (row["name"] + ".process.json")
            if actual is None and fallback.exists():
                actual = json.loads(fallback.read_text())
            if actual:
                assert actual.get("remaining", []) == []
                if actual.get("child"):
                    identities.append(actual["child"])
        assert guard["TMP_remaining"] == [] and not (OUT / stage / "TMP").exists()
        for identity in identities:
            current = process.process_info(identity["pid"])
            assert (
                current is None and not Path(f"/proc/{identity['pid']}").exists()
            ) or (current is not None and process.identity(current) != identity)
            known[str(identity)] = dict(
                expected=identity, now="ABSENT" if current is None else "DIFFERENT"
            )
    own = beads("own-show", ["show", ISSUE, "--json"])
    own = own[0] if isinstance(own, list) else own
    assert own["assignee"] == ACTOR and own["status"] == "in_progress"
    binding = ref(OUT / "binding.json")
    beads(
        "own-note",
        [
            "update",
            ISSUE,
            "--append-notes",
            "Original29 actual first-build missing-caller plumbing repaired privately against immutablee0f50bb8 in caller-repair-v1/binding.json8a73f66d/10005. "
            "Exactly7owners: lmr_observation3 SearchInvocation literals aspiration:None;6 legacyrootcalls explicit root_depth::<false> with full infinitewindow and unchanged tuple. "
            "Every oldassertion/fixture/control/kernel outside causal field/call statement byteexact incl only required localrustfmt. "
            "Scopedrustfmt+check passed; strictGNUforward/inverse fuzz0offset0 byte/mode roundtrip passed. "
            "First newchecker character-indent coordinate refusal preserved after formatter success; causal suffix uses exactline-coordinate check only, source/formatter not replayed. "
            "No sourcealgorithm/API/namespace/admission/config/protocol/selector or budget change; no newtestdefinitions, author tests/compiler/Cargo/native/Search/model/RAW/RNG0. "
            "Rootoriginalsoftware9a6d failure/prefix/log/cleanupFALSE-vs-diskTRUE/cost retained, Python1PASS not replayed. "
            "ActualsourcehelperSTOP/freshidentities/emptyTMP/noMainSH returned; Root solecanonicaladoption and unfinishedAI3/Runner2/Clippy/release. "
            "Sameownerinprogress, all25/27/28/pauses/seals/defaults/models/foreign/FAILED/NULL/UNKNOWNfees/50GB held.",
            "--json",
        ],
    )
    beads("own-backup", ["backup", "sync", "--json"])
    stopped = save(
        OUT / "source-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            binding=binding,
            actual_returned_guard=ref(OUT / "repair-guard-v2/result.json"),
            original_checker_failure=ref(OUT / "repair-guard-v1/result.json"),
            fresh_exact_known_ids=list(known.values()),
            directwait_reap_handles="Actual returned original guards; failed guardian NULL preserved separately from persisted child cleanup",
            TMP_entries=[],
            source_leases=[],
            native_remaining=[],
            Main_reader=False,
            tests_compiler_native_model_RAW_RNG=0,
            note_backup="PASS",
            scope="Own7caller source helpers returned; separate delivery/admin guard follows, no futurehostquiet",
        ),
    )
    message = OUT / "Root-handoff.txt"
    message.write_text(
        "SAME29 requested ACTUAL7caller PRIVATEfix FIXED/returned, sameSol6.1high/Main/fullnever actualturn_context verified before sourcework; CPU2/G18/family1GiBincl64/host4/G0. "
        "Immutablecanonical e0f50bb8 only7necessary owners; noMain/Git/index/Cargo/docs/Rootcomposition or otherOWN writes/read. "
        "lmr_observation3 SearchInvocation literals add aspiration:None diagnostic/trialOFF. Six specified oldrootcallers become root_depth::<false>(..., [f32::NEG_INFINITY,f32::INFINITY]); same2fieldtuple/allassertions/fixtures/control/kernel preserved. "
        "No shim/signature/root/PVS/LMR/math/admission or aspiration29config/sourcecandidate/selector change. "
        "ScopedRustfmt+checkPASS before later ownchecker indentation-coordinate refusal (insert aligns after16spaces); causal checker suffix uses exactline ranges only, samepost/formatter no replay. "
        "Outside causal statement/field alloldlinesbyteexact; strictGNUthinforward+inverse fuzz0/nooffset/allbytes+mode roundtripPASS. "
        "All tests/compiler/Cargo/native/Search/model/RAW/RNG0, no newdefinitions orreviewdispatch. Root originalnewsoftware9a6 failure/log527/prefix/partialcleanupFALSE-vs-diskTRUE/cost kept. Python1 actualPASS retained, remainingAI3/RunnerLIB2/Clippy/release still genuinelyunentered. "
        + json.dumps(
            dict(
                fixed_packet=binding,
                actual_source_STOP=stopped,
                forward=ref(OUT / "forward.patch"),
                inverse=ref(OUT / "inverse.patch"),
            )
        )
        + ". Meaningfulownnote+backupPASS/sameownerinprogress. Separate notification/admin guard returns at caller-repair-v1/return-guard-v1/result.json; one newsubtree affectedpoint follows once, later tails/globalactual/fullfeesUNKNOWN. "
        "Root sparsecanonicalwrite/actualunfinishedsoftware only remains, no reviewerwake/ACK/parentgate. Original2673protocol/representationcontrols/208+conditional128 caps fixed,25/27/28/scopes/seals/pauses/defaults/models/foreign/FAILED/NULL/UNKNOWNfees/50GB/consultation8 held.\n"
    )
    sent = command(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--issue",
            "quoridor-4lc.324",
            "--cwd",
            str(ROOT),
            "--body-file",
            str(message),
        ]
    )
    delivery = save(OUT / "Root-delivery.json", sent)
    inodes = set()
    allocated = logical = files = 0
    for parent, _, names in os.walk(OUT):
        for name in names:
            path = Path(parent) / name
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode), path
            key = (info.st_dev, info.st_ino)
            if key not in inodes:
                inodes.add(key)
                allocated += info.st_blocks * 512
                logical += info.st_size
                files += 1
    point = save(
        OUT / "ordinary-affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            root=str(OUT),
            allocated_B=allocated,
            logical_B=logical,
            files=files,
            scope="Only new caller-repair subtree once after work/admin/direct delivery. Latercontroltails/globalactual/fullfees UNKNOWN; no oldholding/globalwalk/recharge/refund/lending/grant.",
        ),
    )
    print(
        json.dumps(
            dict(
                binding=binding,
                source_STOP=stopped,
                delivery=delivery,
                returncode=sent["returncode"],
                affected=point,
            )
        )
    )


if __name__ == "__main__":
    main()
