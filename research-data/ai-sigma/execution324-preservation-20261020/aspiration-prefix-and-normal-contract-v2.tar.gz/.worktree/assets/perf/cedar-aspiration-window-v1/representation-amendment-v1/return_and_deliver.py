"""One actual amendment return to existing Root324, with normal own note/backup."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import ACTOR, ISSUE, ROOT, command, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

OUT = Path(__file__).resolve().parent


def beads(name, args):
    result = command(["bash", "scripts/dev/beads.sh", *args])
    save(OUT / (name + ".json"), result)
    assert result["returncode"] == 0, result
    return json.loads(result["stdout"])


def main():
    guard = json.loads((OUT / "prepare-guard-v1/result.json").read_text())
    assert guard["status"] == "PASS" and guard["TMP_remaining"] == []
    known = []
    for identity in [
        guard["controller"],
        *(r["guardian_return"]["child"] for r in guard["checks"]),
    ]:
        current = process.process_info(identity["pid"])
        assert (current is None and not Path(f"/proc/{identity['pid']}").exists()) or (
            current is not None and process.identity(current) != identity
        )
        known.append(
            dict(expected=identity, now="ABSENT" if current is None else "DIFFERENT")
        )
    issue = beads("own-show", ["show", ISSUE, "--json"])
    issue = issue[0] if isinstance(issue, list) else issue
    assert issue["assignee"] == ACTOR and issue["status"] == "in_progress"
    binding = ref(OUT / "binding.json")
    amendment = ref(OUT / "amendment.json")
    beads(
        "own-note",
        [
            "update",
            ISSUE,
            "--append-notes",
            "Original29 LIGHT representation-only amendment saved at representation-amendment-v1/binding.json. "
            "Verified issued Root combined binding a3e8d74f/13287 before parse; no source payload/otherOWN read. "
            "All8 original normal208 configs already omit shallow_main_history and stale requested/effective policy assertion; "
            "retain exact8config+8request refs, zero copies/rewrites. Original2673protocol/208208M48sessions/root4D5/width/gates "
            "and prospective12864families4x512M/seeds/soleCI unchanged. Amendment records unconfigurableCurrent100% math, "
            "OFF absentroot_aspiration, ON .125/2/D3/4. Prospective128 keeps exactprotocol/conditional_games pointer only, "
            "no fabricated canonicalPlan. Allnew bindings NOT_RUNNABLE, newBUILD/image/current4/factory/numerical/origin/end_at/whole/support NULL. "
            "ScopedRuff/parser only, author source/tests/Cargo/model/payload/native/RNG/CI/submit0. "
            "Sameownerinprogress; source2a899/protocol2673 and all25/27/28/pause/seal/default/model/foreign/FAILED/UNKNOWN50GB held.",
            "--json",
        ],
    )
    beads("own-backup", ["backup", "sync", "--json"])
    returned = save(
        OUT / "actual-preparation-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            returned_guard=ref(OUT / "prepare-guard-v1/result.json"),
            exact_known_ids_fresh=known,
            directwait_reap_handles="Actual returned guard records",
            TMP_entries=[],
            source_leases=[],
            native_remaining=[],
            Main_reader=False,
            binding=binding,
            amendment=amendment,
            scope="Only scoped preparation returned; this direct metadata/admin delivery lifetime is separate, no futurehostquiet",
        ),
    )
    message = OUT / "Root-handoff.txt"
    message.write_text(
        "SAME29 original actor Sol6.1/high/Main/cwdfullnever actualturn_context readback verified. LIGHT representation-only derivative actually prepared/returnedCPU2/G18/family1GiBincl64/host4/G0; noSource/Cargo/native/CI. "
        "Issued composition binding a3e8d74f/13287 SHA-size-mode verified before smallparse, no referenced source payload or High9OWN read. "
        "All8 original configdrafts ALREADY omit retiredshallow_main_history and allstale requested/effective policy assertions, so retained original exact8config+8request refs (zero recopy/rewrite/proofreplay). "
        "Prospective128 originalprotocol /conditional_games also has no retiredkey/assertion; exact2673protocol ref+pointer retained, no fakearenaPlan/engine. "
        "New separateamendment states unconfigurableCURRENT100% semantics; no policy change/neutralfallback/width selection/reset. "
        "OFF remains absentroot_aspiration, ON exact.125/2/D3/4. All208/208M/48sessions/26prefix6series/root4D5/depth/order/caps/gates and conditional128/64ordinals0..63/4x512M/seeds3242920261020+3242920261021/soleCI unchanged. "
        "Newbinding/controlrefs NOT_RUNNABLE; newBuild/image/current4/source-release/normalfactory/numerical/origin/end_at/whole/support genuineNULL. No oldf686/c797 alias/import/SH/payload/test/native/RNG/requalification/submit. "
        + json.dumps(
            dict(
                binding=binding,
                normal208=ref(OUT / "normal208-controls.binding.json"),
                prospective128=ref(OUT / "prospective128-controls.binding.json"),
                amendment=amendment,
                actual_preparation_STOP=returned,
            )
        )
        + ". Meaningfulownnote+backupPASS, sameassigneeinprogress. Separate returned delivery guard will be representation-amendment-v1/return-guard-v2/result.json; ordinary newsubtree point follows once, later tails/globalfeesUNKNOWN. First helperlint unusedimport refusal beforebody is preserved; causalimport removal only. Source29fixed2a899/protocol2673 unchanged;25/27/28 scopes/recipients/allpauses/seals/defaults/models/foreign/FAILED/NULL/UNKNOWNfees/50GB/consultation8 retained. NoACK/parentgate.\n"
    )
    sent = command(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--issue",
            "quoridor-4lc.324",
            "--cwd",
            str(ROOT),
            "--body-file",
            str(message),
        ]
    )
    delivery = save(OUT / "Root-delivery.json", sent)
    inodes = set()
    allocated = logical = files = 0
    for parent, _, names in os.walk(OUT):
        for name in names:
            path = Path(parent) / name
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode), path
            key = (info.st_dev, info.st_ino)
            if key not in inodes:
                inodes.add(key)
                allocated += info.st_blocks * 512
                logical += info.st_size
                files += 1
    point = save(
        OUT / "ordinary-affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            root=str(OUT),
            allocated_B=allocated,
            logical_B=logical,
            files=files,
            scope="New representation-amendment subtree only, measured once after preparation/admin/direct delivery. Final control tails UNKNOWN; no oldOWN holding/globalwalk/recharge/refund/lending/grant.",
            global_actual_fullfees="UNKNOWN",
        ),
    )
    print(
        json.dumps(
            dict(
                binding=binding,
                actual_preparation_STOP=returned,
                delivery=delivery,
                delivery_returncode=sent["returncode"],
                affected=point,
            )
        )
    )


if __name__ == "__main__":
    main()
