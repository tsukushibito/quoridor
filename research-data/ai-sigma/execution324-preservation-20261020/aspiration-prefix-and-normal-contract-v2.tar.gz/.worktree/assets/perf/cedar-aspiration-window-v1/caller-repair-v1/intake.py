"""Only seven immutable legacy callers; no current Main reader or target import."""

import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import OWN, command, ref, save  # noqa: E402

OUT = Path(__file__).resolve().parent
PATHS = [
    "crates/quoridor-ai/src/lmr_observation.rs",
    "crates/quoridor-ai/src/move_ordering_tests.rs",
    "crates/quoridor-ai/src/tt_first386_tests.rs",
    "crates/quoridor-ai/src/lmr400_tests.rs",
    "crates/quoridor-ai/src/zero_stock411_tests.rs",
    "crates/quoridor-ai/src/zero_stock410_tests.rs",
    "crates/quoridor-ai/src/ordering_work394_tests.rs",
]


def main():
    resolved = command(["git", "rev-parse", "e0f50bb8^{commit}"])
    assert resolved["returncode"] == 0, resolved
    commit = resolved["stdout"].strip()
    before = OUT / "before"
    before.mkdir()
    subjects = []
    snippets = []
    for name in PATHS:
        result = command(["git", "show", commit + ":" + name])
        assert result["returncode"] == 0, result
        raw = result["stdout"].encode()
        path = before / (Path(name).name + ".gz")
        with path.open("xb") as f:
            f.write(gzip.compress(raw, mtime=0))
        subjects.append(dict(path=name, before_gzip=ref(path), mode="0644"))
        lines = raw.decode().splitlines()
        starts = [
            i
            for i, line in enumerate(lines)
            if (
                "SearchInvocation {" in line
                if name.endswith("lmr_observation.rs")
                else ".root_depth(" in line
            )
        ]
        for start in starts:
            snippets.append(
                dict(
                    path=name,
                    line=start + 1,
                    source="\n".join(lines[max(0, start - 2) : start + 23]),
                )
            )
    save(
        OUT / "intake.json",
        dict(
            immutable_commit=commit,
            subjects=subjects,
            context=ref(OWN / "context-effective-caller-repair-v1.json"),
            scope="Only seven immutable owners; production root signature via existing fixed29 reference, no Main/source import/otherOWN",
            compiler_tests_native_model_RAW_RNG=0,
        ),
    )
    save(OUT / "callsite-snippets.json", snippets)
    print(json.dumps(snippets, indent=2))


if __name__ == "__main__":
    main()
