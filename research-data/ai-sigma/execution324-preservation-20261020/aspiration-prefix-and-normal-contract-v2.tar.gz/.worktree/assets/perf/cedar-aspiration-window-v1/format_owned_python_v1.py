"""Format only changed lifecycle functions and parse owned Python without import."""

import ast
import gzip
import json
import sys

from task_utils import OWN, command, save


def functions(text):
    return {
        node.name: node
        for node in ast.parse(text).body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }


def main():
    base = OWN / "source-v1"
    path = base / "post/scripts/dev/research-lifecycle.py"
    before = gzip.decompress(
        (base / "before/research-lifecycle.py.gz").read_bytes()
    ).decode()
    initial = path.read_text()
    old, new = functions(before), functions(initial)
    changed = {
        name
        for name, node in new.items()
        if name not in old or ast.dump(node) != ast.dump(old[name])
    }
    expected = {
        "resolved_root_aspiration",
        "measurement_config",
        "measurement_evidence",
        "arena_plan_check",
        "arena_observation",
    }
    assert changed <= expected, changed
    records = []
    for name in sorted(changed, key=lambda name: new[name].lineno, reverse=True):
        node = functions(path.read_text())[name]
        record = command(
            [
                sys.executable,
                "-m",
                "ruff",
                "format",
                "--config",
                "pyproject.toml",
                "--range",
                f"{node.lineno}-{node.end_lineno + 1}",
                str(path),
            ]
        )
        assert record["returncode"] == 0, record
        records.append(record)
    assert ast.dump(ast.parse(initial)) == ast.dump(ast.parse(path.read_text()))
    for file in [path, base / "post/scripts/dev/test_root_aspiration.py"]:
        ast.parse(file.read_text())
    save(
        base / "python-owned-format.json",
        dict(
            changed_functions=sorted(changed),
            AST_exact_before_after_format=True,
            format_commands=records,
            tests_or_target_imports=0,
        ),
    )
    print(json.dumps(dict(changed_functions=sorted(changed))))


if __name__ == "__main__":
    main()
