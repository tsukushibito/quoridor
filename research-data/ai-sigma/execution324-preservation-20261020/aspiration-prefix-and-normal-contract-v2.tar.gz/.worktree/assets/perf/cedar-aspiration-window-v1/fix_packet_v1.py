"""Freeze sparse source, thin reversible patches and unfinished software recipe."""

import ast
import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile

from task_utils import OWN, command, ref, save


def digest(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), mode="0644")


def rust_method(text, name):
    pattern = re.compile(r"^    (?:pub(?:\([^\n]*\))? )?fn (\w+)", re.M)
    matches = list(pattern.finditer(text))
    found = [i for i, m in enumerate(matches) if m.group(1) == name]
    assert len(found) == 1, (name, found)
    i = found[0]
    return text[
        matches[i].start() : matches[i + 1].start()
        if i + 1 < len(matches)
        else len(text)
    ]


def main():
    source = OWN / "source-v1"
    post = source / "post"
    subjects = []
    forward = []
    inverse = []
    for path in sorted(post.rglob("*")):
        if not path.is_file():
            continue
        relative = str(path.relative_to(post))
        prior = source / "before" / (path.name + ".gz")
        old = gzip.decompress(prior.read_bytes()) if prior.exists() else b""
        new = path.read_bytes()
        assert old != new, relative
        assert (path.stat().st_mode & 0o777) == 0o644
        subjects.append(
            dict(
                path=relative,
                before=digest(old) if prior.exists() else None,
                before_gzip=ref(prior) if prior.exists() else None,
                post=ref(path),
            )
        )
        forward.extend(
            difflib.unified_diff(
                old.decode().splitlines(True),
                new.decode().splitlines(True),
                fromfile="a/" + relative if prior.exists() else "/dev/null",
                tofile="b/" + relative,
                n=3,
            )
        )
        inverse.extend(
            difflib.unified_diff(
                new.decode().splitlines(True),
                old.decode().splitlines(True),
                fromfile="a/" + relative,
                tofile="b/" + relative if prior.exists() else "/dev/null",
                n=3,
            )
        )
    assert len(subjects) == 9
    packet = OWN / "fixed-source-v1"
    resume = sys.argv[1:] == ["--after-fixture-indent-refusal"]
    packet.mkdir(exist_ok=resume)
    for name, lines in [("forward.patch", forward), ("inverse.patch", inverse)]:
        if resume:
            assert (packet / name).read_text() == "".join(lines)
        else:
            with (packet / name).open("x") as f:
                f.write("".join(lines))
    temporary = Path(
        tempfile.mkdtemp(prefix="thin-roundtrip-", dir=os.environ["TMPDIR"])
    )
    records = []
    try:
        if resume:
            # Original helper reached the later fixture assertion after BOTH exact
            # roundtrip assertions. Do not rerun those successful patch commands.
            records.append(
                dict(
                    original_failed_guard=ref(
                        OWN / "source-packet-guard-v1/result.json"
                    ),
                    original_log=ref(OWN / "source-packet-guard-v1/fix-packet.log"),
                    prior_patch_commands="completed before later fixture-indentation assertion; stdout was held in failed helper memory",
                    replayed=False,
                )
            )
        for subject in subjects:
            if resume:
                continue
            path = temporary / subject["path"]
            path.parent.mkdir(parents=True, exist_ok=True)
            if subject["before"] is not None:
                path.write_bytes(
                    gzip.decompress(Path(subject["before_gzip"]["path"]).read_bytes())
                )
                path.chmod(0o644)
        for direction in ["forward", "inverse"]:
            if resume:
                continue
            result = command(
                [
                    "patch",
                    "--batch",
                    "--fuzz=0",
                    "--no-backup-if-mismatch",
                    "-p1",
                    "-d",
                    str(temporary),
                    "-i",
                    str(packet / f"{direction}.patch"),
                ]
            )
            records.append(result)
            assert result["returncode"] == 0, result
            assert not any(
                word in (result["stdout"] + result["stderr"]).lower()
                for word in ("offset", "fuzz", "failed", "reversed")
            ), result
            for subject in subjects:
                path = temporary / subject["path"]
                expected = (
                    subject["post"] if direction == "forward" else subject["before"]
                )
                if expected is None:
                    assert not path.exists()
                else:
                    assert digest(path.read_bytes()) == {
                        k: expected[k] for k in ["sha256", "bytes", "mode"]
                    }
                    assert (path.stat().st_mode & 0o777) == 0o644
        assert not list(temporary.rglob("*.orig")) and not list(
            temporary.rglob("*.rej")
        )
    finally:
        shutil.rmtree(temporary)
    oldalpha = gzip.decompress(
        (source / "before/alphabeta.rs.gz").read_bytes()
    ).decode()
    newalpha = (post / "crates/quoridor-ai/src/alphabeta.rs").read_text()
    protected = [
        "control",
        "enter",
        "ordered",
        "eager_ordered",
        "prepared_moves",
        "child",
        "reduced_child",
        "negamax",
        "negamax_entered",
        "forced_root_depth",
        "pv",
        "zero_stock_approx_value",
    ]
    for name in protected:
        if not resume:
            assert rust_method(oldalpha, name) == rust_method(newalpha, name), name
    oldlc = gzip.decompress(
        (source / "before/research-lifecycle.py.gz").read_bytes()
    ).decode()
    newlc = (post / "scripts/dev/research-lifecycle.py").read_text()

    def functions(text):
        lines = text.splitlines(True)
        return {
            n.name: "".join(lines[n.lineno - 1 : n.end_lineno])
            for n in ast.parse(text).body
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        }

    oldf, newf = functions(oldlc), functions(newlc)
    changes = {n for n in newf if n not in oldf or oldf[n] != newf[n]}
    assert changes == {
        "resolved_root_aspiration",
        "measurement_config",
        "measurement_evidence",
        "arena_plan_check",
        "arena_observation",
    }, changes
    oldfixture = gzip.decompress(
        (source / "before/measurement_ordering394_tests.rs.gz").read_bytes()
    )
    newfixture = (
        post / "crates/quoridor-runner/src/measurement_ordering394_tests.rs"
    ).read_bytes()
    assert (
        newfixture.replace(b"                root_aspiration: None,\n", b"")
        == oldfixture
    )
    proof = save(
        packet / "thin-check.json",
        dict(
            commands=records,
            forward_inverse_byte_mode_exact=True,
            fuzz=0,
            offsets=0,
            protected_alpha_methods_exact=protected,
            unchanged_lifecycle_functions_exact=sorted(set(oldf) - changes),
            changed_lifecycle_functions=sorted(changes),
            oldfixture_assertion_and_body_exact=True,
            compiler_tests_native_model_RAW_RNG=0,
        ),
    )
    names = [
        "aspiration_common_root_matches_fullwidth_oracle_with_fail_sides_and_fallback",
        "aspiration_retry_abort_preserves_completed_snapshot_cumulative_budget_and_parent",
        "aspiration_declared_domains_namespace_reset_and_same_config_warming",
    ]
    recipe = save(
        packet / "software-recipe.json",
        dict(
            status="UNBUILT_UNTYPED_UNRUN",
            AI=[
                dict(
                    selector="alphabeta::aspiration_window::tests::" + name,
                    target="quoridor-ai --lib",
                    features="research-diagnostics",
                    required_running=1,
                    purpose="actual common callee/oracle, cumulative retry interruption, declared domains/session namespace respectively",
                )
                for name in names
            ],
            Runner=[
                dict(
                    selector="runtime::aspiration_arena_boundary_tests::aspiration_arena_typed_control_namespace_and_unused_scope_refusal",
                    target="quoridor-runner --lib",
                    features="measurement,quoridor-inference/claustrophobia",
                    required_running=1,
                ),
                dict(
                    selector="measurement::aspiration_measurement_boundary_tests::aspiration_measurement_default_typed_current_and_record_contract",
                    target="quoridor-runner --lib",
                    features="measurement,quoridor-inference/claustrophobia",
                    required_running=1,
                ),
            ],
            Python=dict(
                path="scripts/dev/test_root_aspiration.py",
                selector="RootAspirationMetadata.test_typed_current_control_only_and_invalid_fields",
                required_running=1,
                route="canonical owner after Root adoption via maintained project-env; author imports/runs0",
            ),
            remaining="Root sparse composition/current caller binding, only these new exact filters, affected AI+Runner Clippy warning0, genuine Runner release, normal finalization/actual image/sourceSTOP. No old suites/proofs/parity/model campaigns.",
            coverage_limits="NN0 oracle/fault definitions do not certify all FT/worker/panic paths or current empirical parity. Fatal evaluator API returns Err; last completed callback/cache remains legal, no fake successful fallback result.",
        ),
    )
    questions = [
        "Root PVS narrow-window fail-low/high classification: no bound/aborted attempt may publish an exact root/completed depth or replace last completed action/PV.",
        "All retries share cumulative Search nodes/evals/deadline/cancel/error and unchanged requested depth; failed side expands finitely then full fallback; center only last completed same-call iteration.",
        "ASP-only aborted generation commits only entries actually inserted at completed nodes; check typed history/context/namespace/leaf qualification and error/parent-restore clearing. Off/forced discard and child bodies are unchanged.",
        "Namespace prefix and config-change/reset versus same-config session warming; restricted forced roots remain full-window and native SMP refusal remains.",
        "Fatal evaluator error still returns Err by original contract, with prior completed callback/cache intact; caller error/authority remains distinct from stop fallback.",
        "Typed native/lifecycle requested/effective configuration and bounded counter correspondence, defaultOFF direct full-window route; no new Half references. Root must sparse-compose old preexisting Half retirement at overlapping namespace/config/runtime/measurement/LC owners, not replace whole posts.",
    ]
    rationale = """# 原29 固定source境界（software/numeric未実施）

幅0.125、成長2、深さ3から、失敗側4回拡大後に同じ深さの全窓へ一度戻す一候補。Cedar非終端[-1,1]の1/8であり、結果から選択・最適化していない。保存21の26件はfirst/latestのみで、隣接完了反復のscore差はUNKNOWN。速度・retry頻度の予測には使わない。

共通root/PVSをWINDOWED constで一箇所共有し、OFFはretry集計へ入らない。ONだけ根のUpper/Lowerを分類して再探索し、最後に成功した深さのsnapshotだけを公開する。node/eval/clock/取消を再割当しない。正しく完了した子のTT効果は保持し、親復元不一致では既存どおりclearする。fatal evaluator Errは既存のErr APIのまま、直前callback/native cacheは保存する。これを成功SearchResultへ偽装しない。

Root退役担当との実重複はalpha namespace/reset、Runner config/runtime/measurement、LCの型・記録owner。新aspiration部分はHalfを参照せず、新fixtureも切替fieldを省略した。古いHalf既存部分はこのimmutable beforeと同じであり、Rootが別の退役差分を疎結合する。相手OWNは読んでいない。

子/negamax/reduced_child/forced-root/評価・FT・LMR本体はbyte保護。原fixtureにはNone一欄のみ。新AI3/RunnerLIB2/Python1定義はUNBUILT/UNTYPED/UNRUN。rustfmt/変更関数Ruff/構文/薄いpatch正逆だけ実施。old model/FP32/性能の新資格はない。Root限定確認・実software・真正image・normal entryが残る。

原208は26prefix全系列・Current固定・N1OFF/ON同新image・8pass・各1M。depthは保存完了値-1を上限8にし、root4は5。条件付き128局/64families/2.048Gと唯一CIを結果前固定したが、実support/entryは未発行。原27/28、全pause/seal/モデル/default/foreign/FAILED/UNKNOWN/50GBを保持。
"""
    (packet / "rationale-ja.md").write_text(rationale)
    binding = save(
        packet / "binding.json",
        dict(
            issue="quoridor-4lc.324.29",
            status="FIXED_PRIVATE_SOURCE_NOT_CLEAR_NOT_SOFTWARE_NOT_NUMERIC",
            immutable_before="1dce95b0734770f7da871bafb39bf3a9fa4f0da8",
            subjects=subjects,
            forward=ref(packet / "forward.patch"),
            inverse=ref(packet / "inverse.patch"),
            thin_check=proof,
            software_recipe=recipe,
            rationale=ref(packet / "rationale-ja.md"),
            questions=questions,
            finite_protocol=ref(OWN / "finite-protocol-v1.json"),
            finite_controls=ref(OWN / "finite-preparation-v1/binding.json"),
            half_independent_correspondence=ref(
                source / "half-independent-composition.json"
            ),
            source_start=ref(OWN / "actual-source-start.json"),
            formatting=ref(OWN / "source-finalization-guard-v1/result.json"),
            scope="Author OWN only, Main/Git/Cargo/docs/otherOWN writes0. Related review only Root dispatch; source helper actualSTOP follows guard return.",
        ),
    )
    print(
        json.dumps(
            dict(
                binding=binding,
                subjects=len(subjects),
                new_definitions="AI3/RunnerLIB2/Python1 UNRUN",
                numerical_calls=0,
            )
        )
    )


if __name__ == "__main__":
    main()
