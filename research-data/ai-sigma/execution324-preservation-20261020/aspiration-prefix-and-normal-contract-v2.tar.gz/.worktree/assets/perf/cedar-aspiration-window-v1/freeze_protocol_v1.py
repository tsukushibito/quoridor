"""Freeze original29 conditions before any numerical result; no executable factory import."""

from copy import deepcopy
import json

from task_utils import OWN, ROOT, ref, save


def main():
    old = ROOT / ".worktree/assets/perf/cedar-root-split-v1"
    prepared = json.loads((old / "finite-protocol-v1.json").read_text())
    template = json.loads((old / "diagnostic-config.draft.json").read_text())
    selection = json.loads((OWN / "window-selection-v1.json").read_text())
    rows = selection["transitions"]
    assert len(rows) == len(prepared["roots"]) == len(template["roots"]) == 26
    depths = [max(1, min(8, row["last_depth"] - 1)) for row in rows]
    assert depths[4] == 5
    config = {
        k: selection["candidate"][k]
        for k in ("half_width", "growth", "activation_depth", "max_retries")
    }
    conditions = OWN / "finite-preparation-v1"
    conditions.mkdir()
    runs = []
    for kind in ["fixeddepth", "clock"]:
        for order, arm in enumerate(["OFF", "ON", "ON", "OFF"]):
            stem = f"{len(runs):02d}-{kind}-{arm}"
            settings = deepcopy(template)
            for key in [
                "neighbour_opportunity",
                "root_ordering_quality",
                "history_provenance",
                "shallow_main_history",
            ]:
                settings.pop(key, None)
            if arm == "ON":
                settings["root_aspiration"] = config
            settings["seed"] = None
            settings["output_bytes"] = 20 * 1024**2
            # Existing normal request shape, no geometry/native fabricated qualification.
            requests = [
                dict(
                    root=i,
                    diagnostic=False,
                    repeat=1,
                    max_depth=depths[i] if kind == "fixeddepth" else 64,
                    max_nodes=1000000,
                    time_ms=None if kind == "fixeddepth" else 100,
                    reserve_ms=0 if kind == "fixeddepth" else 5,
                    warmup=False,
                    observe_lmr=False,
                    observe_completed_depths=False,
                    session_id=r["session_id"],
                    session_first=r["session_first"],
                )
                for i, r in enumerate(prepared["roots"])
            ]
            saved_config = save(conditions / f"{stem}-config.draft.json", settings)
            saved_requests = save(conditions / f"{stem}-requests.draft.json", requests)
            runs.append(
                dict(
                    order=len(runs),
                    phase=kind,
                    arm=arm,
                    repetition=1 if order < 2 else 2,
                    config=saved_config,
                    requests=saved_requests,
                    calls=26,
                    sessions=6,
                    nodes_upper=26000000,
                    command_timeout_seconds=900,
                    child_cpu_cores=[0, 12],
                    status="NOT_RUNNABLE_FACTORY_BIND_PENDING",
                )
            )
    protocol = dict(
        issue="quoridor-4lc.324.29",
        status="RESULT_BEFORE_NOT_RUNNABLE",
        source_base="1dce95b0734770f7da871bafb39bf3a9fa4f0da8",
        one_candidate=config,
        primary_reference="https://github.com/official-stockfish/Stockfish/blob/master/src/search.cpp",
        reference_scope="Bounded failed-side widening idea only. No chess constants, score/depth/pruning or racy publication copied.",
        saved_selection=ref(OWN / "window-selection-v1.json"),
        adjacent_completed_score_transitions="UNKNOWN; saved first/latest across depths/history/TT are not adjacent-iteration calibration",
        depth_rule="max(1,min(8,saved21 actually committed latest depth - 1)); one-depth margin, not a measured completion guarantee. Human root4 requested6/capped5 fact is respected with requested5. No pilot/refill.",
        depths=[
            dict(
                root=i,
                saved_committed_depth=r["last_depth"],
                requested_depth=depths[i],
                saved_overall_stop=r["overall_stop"],
            )
            for i, r in enumerate(rows)
        ],
        roots=prepared["roots"],
        input_refs=prepared["input_refs"],
        stock_bins=[2, 6, 6, 6, 6],
        stock_zero_shortfall=4,
        predecessor_custody="All26 full genuine prefixes; six same-colour chronological sessions; model/TT/history/scratch initialized once per series then retained, all predecessors included. Each pass has independent sessions. No full-game search-state reconstruction claim.",
        common=dict(
            Cedar="35cbb",
            evaluator=template["namespace"]["evaluator"],
            policy="Current fixed; retired switch omitted",
            profile="control",
            search_threads=1,
            lmr=template["lmr_parameters"],
            method="depth_rank",
            use_pvs=True,
            TT_total=1048576,
            path_tail=True,
            approx=False,
            score_domain="legacy Cedar tanh nonterminal[-1,1], terminals+/-2",
        ),
        continuous=dict(
            runs=runs,
            order="fixeddepth OFF ON ON OFF then clock OFF ON ON OFF",
            calls=208,
            sessions=48,
            nodes_upper=208000000,
            per_call_aggregate_nodes=1000000,
            clock_ms=100,
            reserve_ms=5,
            same_future_image_both_arms=True,
            warmups_pilots_refills_extra_seeds=0,
            caps=dict(
                RUN_seconds=900,
                parent_seconds=7800,
                command_seconds=7740,
                cleanup_seconds=60,
            ),
            primary="Continuous Search-body sum; setup/reset/rootprepare/drop/whole/CPU reported separately, nested times not added",
            all104_fixeddepth_complete_required_for_time_ratios=True,
            censoring="Any fixeddepth incomplete => whole completed-time ratio UNKNOWN. No cap-speedup or favourable completed subset. Clock NodeLimit is capped horizon UNKNOWN, returned completed snapshot recorded honestly.",
            correctness="All208 exact normal slots/history/parentrestore/legality/callback main authority/cumulative1M cap/typedBounds/errors/cancel/cleanup qualify; no failed bound or partial retry committed as completed. Small fullwidth LMR-OFF software oracle, not ON selective-tree bit equivalence.",
            clock_safety="All104 main completeddepth>=1 and receipt<=.100s; terminal p95<=.110s and max<=.125s; complete receipt/terminal observability required. Missing/correctness/unsafe/actual major clock failure=>NO_GAMES_UNRESOLVED.",
            serious_fixed_regression="Only if ALL104 requested depths complete: max(two ON Searchsums)/min(two OFF)>1.20 OR any root repeat-median ON/OFF>1.25 AND median extra>.010s blocks automatic games.",
            games_gate="Correct/safe normaldata plus full observed100ms conditions and no actually established serious regression. Fixeddepth censoring alone does not block games; retain speed UNKNOWN. No integerdepth-gain or CPU-only veto.",
            practical_timing_support="Pooled ON/OFF Searchsum<=.95 AND max(two ON sums)<min(two OFF sums), no serious perroot/clock regression and whole-driver ON/OFF<=1.10. Otherwise timing benefit unsupported/unresolved; always report all roots/series/stock/first-v-continued/work/retries/whole/CPU.",
            interpretation="Different aspiration windows under selective LMR may change work/value/PV; no samework/fullwidth speedup, strength or general superiority from NPS/retries/first-window success.",
        ),
        conditional_games=dict(
            status="DORMANT_UNISSUED_ROOT_SUPPORT_AND_REAL_GATE_REQUIRED",
            families=64,
            games=128,
            canonical_book=prepared["input_refs"][0],
            book_ordinals=list(range(64)),
            colours="both consecutive per family; firstcandidatecolour=family_id%2, fixed normal mapping",
            exposure="Historical original432book YES including diagnostic family3; not unseen/IID. No WDL selection or family substitution.",
            engine0="ON",
            engine1="OFF",
            both_N1_same_image=True,
            game_concurrency=1,
            operations=[
                dict(
                    batch=i,
                    games=32,
                    family_ordinals=list(range(16 * i, 16 * i + 16)),
                    nodes_nonfungible=512000000,
                    native_seed=3242920261020 + i,
                )
                for i in range(4)
            ],
            arena_seed=3242920261020,
            nodes_upper=2048000000,
            move_nodes=1000000,
            depth=64,
            time_ms=100,
            reserve_ms=5,
            max_plies=200,
            TT_entries_per_opponent_session=1048576,
            family_prefix_history_seed="Original stored family/fullweightedhistory/seed remains normal owner source; no generated openings",
            sole_final_CI=dict(
                when="ALL128 normalqualified/64 complete pairs/UNKNOWN0 + actualSTOP only",
                method="PCG64 paired-family mean of both colours,10000 bootstrap,linear central95",
                seed=3242920261021,
                iterations=10000,
            ),
            native_chunk_bootstrap="1 diagnostic only; never pool or external resample",
            UNKNOWN="strict/no refill/no false forfeits/no partial favourable CI",
            research_support="Sole lower>.5 plus fixed safe/practical finite evidence supports only this research candidate; otherwise retain OFF. Report strength/timing uncertainty independently. No default/model promotion/Elo/general strength/equivalence/noeffect.",
            runtime_proposal=dict(
                RUN_seconds=900,
                parent_seconds=4200,
                command_seconds=4140,
                cleanup_seconds=60,
            ),
        ),
        runtime_proposal=dict(
            search_cores=[12],
            main=0,
            guardian=18,
            launcher=[0, 12, 18],
            family_B=4294967296,
            management_B=1610612736,
            native_B=2684354560,
            host_reserve_B=4294967296,
            GPU=0,
            threads=1,
        ),
        reporting=[
            "allroot requested/adopted depth/stop/action/PV/valuebits/nodes/evals/TT/history/parentrestore",
            "root-level fail-low/high/retry/fallback cumulative work subset (not additive to total)",
            "main callback receipt vs terminal-allquiet vs arena parent receipt",
            "Search vs setup/reset/drop/endtail/whole/CPU/RAM measured or UNKNOWN",
            "first-v-continued/series/stock distributions/exposure/missingness",
        ],
        measurement_instrumentation="Root-only integer counters; no pernode clocks/trace/new telemetry. Added ON counter cost included in current ON time; CPU/RAM/physical/fullfees UNKNOWN unless actual normal owner measures them.",
        future=dict(
            Build=None,
            artifact=None,
            current_callers=None,
            source_release=None,
            numerical_fields=None,
            support=None,
            whole=None,
            origin=None,
            end_at=None,
        ),
        ordinary_bind="Maintained normal factories/measurement_config/numerical_fields under brief actual SH only after Root source+software release. Measurement approved_plan None/canonical_plan empty retained when canonical. No fake executable Experiment/neutral fallback.",
        scope="Original29 only; no27/28 rights use; all pauses/seals/models/defaults/foreign/FAILED/NULL/UNKNOWNfees/decimal50GB/consultation8 retained",
    )
    saved = save(OWN / "finite-protocol-v1.json", protocol)
    save(
        conditions / "binding.json",
        dict(
            protocol=saved,
            settings=[r["config"] for r in runs],
            requests=[r["requests"] for r in runs],
            actual_factory_imports=0,
            tests_compiler_native_model_RNG=0,
            future=protocol["future"],
        ),
    )
    print(json.dumps(dict(protocol=saved, depths=depths, new_calls=0)))


if __name__ == "__main__":
    main()
