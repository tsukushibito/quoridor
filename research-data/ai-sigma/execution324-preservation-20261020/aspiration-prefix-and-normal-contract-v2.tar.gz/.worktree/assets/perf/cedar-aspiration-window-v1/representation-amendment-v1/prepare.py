"""Representation-only original29 control amendment; no normal factory/source import."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import OWN, ROOT, ref, save  # noqa: E402


OUT = Path(__file__).resolve().parent
RETIRED = {
    "shallow_main_history",
    "requested_shallow_main_history",
    "actual_shallow_main_history",
    "effective_shallow_main_history",
}


def hits(value, pointer=""):
    result = []
    if isinstance(value, dict):
        for key, item in value.items():
            if key in RETIRED:
                result.append(pointer + "/" + key)
            result.extend(hits(item, pointer + "/" + key))
    elif isinstance(value, list):
        for i, item in enumerate(value):
            result.extend(hits(item, pointer + "/" + str(i)))
    return result


def main():
    combined = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/composition-v1/binding.json"
    )
    raw = combined.read_bytes()
    assert len(raw) == 13287 and stat.S_IMODE(combined.stat().st_mode) == 0o644
    assert (
        hashlib.sha256(raw).hexdigest()
        == "a3e8d74f5e10e3028added36ef0f419a2e06320f5118bf01b091a7ddcd487874"
    )
    json.loads(raw)  # Only the issued small binding, never its source payloads.
    original_path = OWN / "finite-preparation-v1/binding.json"
    original = json.loads(original_path.read_text())
    protocol_ref = original["protocol"]
    assert (
        protocol_ref["sha256"]
        == "2673cc67b107b4a427676f88026261a98a32386e615eea8dac915740097890f6"
    )
    observations = []
    for item in original["settings"]:
        path = Path(item["path"])
        assert path.parent == OWN / "finite-preparation-v1"
        config = json.loads(path.read_text())
        found = hits(config)
        assert not found, (
            path,
            found,
        )  # Already omitted in original freeze; no recopy/reproof.
        active = "root_aspiration" in config
        if active:
            assert config["root_aspiration"] == dict(
                half_width=0.125, growth=2.0, activation_depth=3, max_retries=4
            )
        observations.append(
            dict(
                original=item,
                retired_key_paths=found,
                action="RETAIN_ORIGINAL_EXACT_REF",
                arm="ON" if active else "OFF_ABSENT_KEY",
            )
        )
    assert not hits(original)
    protocol = json.loads(Path(protocol_ref["path"]).read_text())
    assert not hits(protocol["conditional_games"])
    # Preserve the future-input NULLs exactly; combined source is not a software release.
    assert all(value is None for value in original["future"].values())
    amendment = save(
        OUT / "amendment.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            issue="quoridor-4lc.324.29",
            kind="REPRESENTATION_ONLY_NO_SCIENCE_CHANGE",
            original_protocol=protocol_ref,
            original_controls=ref(original_path),
            issued_combined_source_binding=ref(combined),
            semantics="CURRENT is unconfigurable retained100% history math after Root Half retirement; not a serialized control or an effective-policy assertion. No neutral fallback or new policy trial.",
            retired_fields=sorted(RETIRED),
            retired_fields_found=0,
            copied_or_rewritten_configs=0,
            rewritten_requests=0,
            settings_observation=observations,
            prospective_games="Existing frozen protocol /conditional_games contains no retired key or stale requested/effective assertion. Retain the exact protocol ref and JSON pointer; no new engine config or fake canonical arena Plan.",
            unchanged="ONEwidth.125/growth2/D3/max4;208/208M/48sessions/26prefix6series/depthmap(root4D5)/order/caps/gates. Conditional128/64ordinals0..63/4x512M/seeds3242920261020+CI3242920261021/10000/linear95 unchanged.",
            OFF="Absent root_aspiration key; no explicit runnable null",
            ON=dict(half_width=0.125, growth=2.0, activation_depth=3, max_retries=4),
            Build_image_callers_factory_numerical_origin_end_at_support_whole="Genuine future NULL; Root composed source is unqualified and Main unapplied, no import/reader/source change or executable experiment.",
            tests_compiler_native_model_payload_RAW_RNG_CI=0,
        ),
    )
    normal = save(
        OUT / "normal208-controls.binding.json",
        dict(
            status="NOT_RUNNABLE",
            representation_amendment=amendment,
            protocol=protocol_ref,
            settings=original["settings"],
            requests=original["requests"],
            future=original["future"],
            ordinary_ownership="Actual measurement canonical_plan empty/approved_plan None only when maintained owner resolves after genuine software release; no fabricated Plan now",
            actual_factory_imports=0,
            source_or_science_change=False,
        ),
    )
    games = save(
        OUT / "prospective128-controls.binding.json",
        dict(
            status="NOT_RUNNABLE_DORMANT_UNISSUED",
            representation_amendment=amendment,
            frozen_recipe=dict(document=protocol_ref, pointer="/conditional_games"),
            future={**original["future"], "canonical_arena_plan": None},
            engine_identity="engine0 ON, engine1 OFF, bothLOCAL1/Cedar/Control/unconfigurableCurrent/baselineLMR/PVS/TT1M/path_tail/approxOFF, same future image",
            retired_config_or_engine_keys=[],
            stale_policy_assertions=[],
            normal_arena_plan="Genuine canonical Plan remains future normal owner work; no engine payload, source, book or model read here",
        ),
    )
    binding = save(
        OUT / "binding.json",
        dict(
            status="NOT_RUNNABLE_REPRESENTATION_ONLY",
            original_protocol=protocol_ref,
            amendment=amendment,
            normal208=normal,
            prospective128=games,
            original_source_unchanged="2a899977c5196bc2a1becb129a5c41367622cfdef69a581ba37d3e6f2dc9d984/10483; no source read/rewrite/proof replay",
            actual_turn_context=ref(
                OWN / "context-effective-metadata-continuation-v1.json"
            ),
            scope="Only OWN29 new metadata; Root issued binding read-only; no otherOWN/SH/Main import/Cargo/tests/model/native/RNG/submit",
        ),
    )
    print(
        json.dumps(
            dict(
                binding=binding,
                amendment=amendment,
                unchanged_original_config_refs=8,
                unchanged_original_request_refs=8,
                new_executable_controls=0,
            )
        )
    )


if __name__ == "__main__":
    main()
