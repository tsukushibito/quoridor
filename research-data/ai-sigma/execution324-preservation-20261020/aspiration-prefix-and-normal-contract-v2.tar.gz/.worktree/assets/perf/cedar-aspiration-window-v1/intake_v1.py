"""Claim29 at returned28 tail and inspect immutable root/score responsibilities."""

from datetime import datetime, timezone
import gzip
import hashlib
import json

from task_utils import ACTOR, ISSUE, OWN, ROOT, authority, command, ref, save


def main():
    prior = (
        ROOT
        / ".worktree/assets/perf/cedar-root-split-v1/normal26-controls-tail-guard-v1/result.json"
    )
    stopped = json.loads(prior.read_bytes())
    assert stopped["status"] == "PASS" and stopped["TMP_remaining"] == []
    authority("ready-v1", ["ready", "--json"])
    row = authority("show-v1", ["show", ISSUE, "--json"])[0]
    assert row["assignee"] == ACTOR and row["status"] == "open"
    row = authority("claim-v1", ["update", ISSUE, "--claim", "--json"])[0]
    assert row["assignee"] == ACTOR and row["status"] == "in_progress"
    git = command(["git", "rev-parse", "HEAD"])
    assert git["returncode"] == 0
    commit = git["stdout"].strip()
    before = OWN / "source-v1/before"
    before.mkdir(parents=True)
    sources = {}
    for subject in [
        "crates/quoridor-ai/src/alphabeta.rs",
        "crates/quoridor-ai/src/score.rs",
    ]:
        result = command(["git", "show", f"{commit}:{subject}"])
        assert result["returncode"] == 0
        raw = result["stdout"]
        sources[subject] = dict(
            sha256=hashlib.sha256(raw.encode()).hexdigest(), bytes=len(raw.encode())
        )
        with (before / (subject.rsplit("/", 1)[1] + ".gz")).open("xb") as stream:
            stream.write(gzip.compress(raw.encode(), mtime=0))
        if subject.endswith("score.rs"):
            print("SCORE", raw)
        else:
            lines = raw.splitlines()
            for i, line in enumerate(lines):
                if any(
                    word in line
                    for word in [
                        "struct SearchSession",
                        "fn root_depth(",
                        "pub struct SearchLimits",
                        "fn qualify_namespace",
                        "fn next_generation",
                        "fn commit(",
                        "fn discard_uncommitted",
                        "pub fn reset",
                        "struct SearchInvocation",
                        "for depth in first_depth",
                        "fn control(",
                    ]
                ):
                    print(
                        "ALPHA_OWNER", i + 1, "\n".join(lines[max(0, i - 3) : i + 60])
                    )
    print(
        json.dumps(
            save(
                OWN / "intake.json",
                dict(
                    at=datetime.now(timezone.utc).isoformat(),
                    issue=ISSUE,
                    assignee=ACTOR,
                    immutable_commit=commit,
                    sources=sources,
                    prior28_tail_STOP=ref(prior),
                    context=dict(
                        model="gpt-6.1-sol",
                        effort="high",
                        cwd=str(ROOT),
                        sandbox="danger-full-access",
                        approvalPolicy="never",
                    ),
                    Main_Git_Cargo_docs_writes=0,
                    tests_native_model_RNG=0,
                ),
            )
        )
    )


if __name__ == "__main__":
    main()
