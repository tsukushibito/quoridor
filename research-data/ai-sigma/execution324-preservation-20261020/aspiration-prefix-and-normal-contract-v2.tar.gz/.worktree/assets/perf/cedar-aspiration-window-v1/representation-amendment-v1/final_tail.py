"""Return only exact known amendment helpers and empty delivery lock after handoff."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import ROOT, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

OUT = Path(__file__).resolve().parent


def main():
    fresh = {}
    removed = []
    for stage in ["prepare-guard-v1", "return-guard-v1", "return-guard-v2"]:
        record = json.loads((OUT / stage / "result.json").read_text())
        identities = [record["controller"]]
        for row in record["checks"]:
            actual = row.get("guardian_return")
            fallback = OUT / stage / (row["name"] + ".process.json")
            if actual is None and fallback.exists():
                actual = json.loads(fallback.read_text())
            if actual:
                assert actual.get("remaining", []) == []
                if actual.get("child"):
                    identities.append(actual["child"])
        for identity in identities:
            current = process.process_info(identity["pid"])
            assert (
                current is None and not Path(f"/proc/{identity['pid']}").exists()
            ) or (current is not None and process.identity(current) != identity)
            fresh[str(identity)] = dict(
                expected=identity, now="ABSENT" if current is None else "DIFFERENT"
            )
        tmp = OUT / stage / "TMP"
        if tmp.exists():
            for path in tmp.iterdir():
                info = path.lstat()
                assert path.name.startswith("uv-") and path.name.endswith(".lock")
                assert (
                    stat.S_ISREG(info.st_mode)
                    and info.st_size == 0
                    and info.st_nlink == 1
                )
                fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    assert (
                        os.fstat(fd).st_ino == info.st_ino and path.stat().st_size == 0
                    )
                    path.unlink()
                finally:
                    os.close(fd)
                removed.append(str(path))
            tmp.rmdir()
    result = save(
        OUT / "final-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            binding=ref(OUT / "binding.json"),
            preparation_STOP=ref(OUT / "actual-preparation-STOP.json"),
            delivery=ref(OUT / "Root-delivery.json"),
            returned_guard=ref(OUT / "return-guard-v2/result.json"),
            failed_prebody_lint_guard=ref(OUT / "return-guard-v1/result.json"),
            fresh_exact_known_ids=list(fresh.values()),
            removed_returned_empty_locks=removed,
            TMP_entries=[],
            source_leases=[],
            native_remaining=[],
            Main_reader=False,
            point=ref(OUT / "ordinary-affected-point.json"),
            point_remeasure_old_holding_globalwalk_refund_loan=0,
            tests_source_compiler_model_payload_native_RAW_RNG_CI_submit=0,
            scope="Only actual amendment prepare/admin/delivery returned. This final bounded cleanup guard return follows; no futurehostquiet. Source/protocol frozen, NOT_RUNNABLE future bindings remain NULL.",
        ),
    )
    print(json.dumps(dict(final_STOP=result)))


if __name__ == "__main__":
    main()
