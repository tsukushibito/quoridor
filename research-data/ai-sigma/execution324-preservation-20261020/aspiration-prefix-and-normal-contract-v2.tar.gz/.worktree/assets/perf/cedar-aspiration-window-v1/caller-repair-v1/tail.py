"""Only returned caller-packet delivery identities and empty uv lock cleanup."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import ROOT, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

OUT = Path(__file__).resolve().parent


def main():
    guard = json.loads((OUT / "return-guard-v1/result.json").read_text())
    assert guard["status"] == "PASS"
    fresh = []
    for identity in [
        guard["controller"],
        *(r["guardian_return"]["child"] for r in guard["checks"]),
    ]:
        actual = process.process_info(identity["pid"])
        assert (actual is None and not Path(f"/proc/{identity['pid']}").exists()) or (
            actual is not None and process.identity(actual) != identity
        )
        fresh.append(
            dict(expected=identity, now="ABSENT" if actual is None else "DIFFERENT")
        )
    removed = []
    tmp = OUT / "return-guard-v1/TMP"
    if tmp.exists():
        for path in tmp.iterdir():
            info = path.lstat()
            assert path.name.startswith("uv-") and path.name.endswith(".lock")
            assert (
                stat.S_ISREG(info.st_mode) and info.st_size == 0 and info.st_nlink == 1
            )
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                assert os.fstat(fd).st_ino == info.st_ino and path.stat().st_size == 0
                path.unlink()
            finally:
                os.close(fd)
            removed.append(str(path))
        tmp.rmdir()
    stopped = save(
        OUT / "delivery-tail-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            source_STOP=ref(OUT / "source-STOP.json"),
            returned_delivery_guard=ref(OUT / "return-guard-v1/result.json"),
            delivery=ref(OUT / "Root-delivery.json"),
            fresh_exact_known_ids=fresh,
            removed_returned_empty_locks=removed,
            source_leases=[],
            TMP_entries=[],
            native_remaining=[],
            Main_reader=False,
            ordinary_affected_point=ref(OUT / "ordinary-affected-point.json"),
            scope="Only actual caller-repair source/admin/directdelivery returned; this cleanup guard return follows. No futurehostquiet, sourceclear, software or scientific claim.",
            tests_compiler_native_model_RAW_RNG=0,
            later_tails_global_actual_fullfees="UNKNOWN",
        ),
    )
    print(json.dumps(dict(actual_delivery_tail_STOP=stopped)))


if __name__ == "__main__":
    main()
