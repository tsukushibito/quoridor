"""One factual source-start handoff after the first actual private delta returned."""

from datetime import datetime, timezone
import json
from pathlib import Path
import sys

from task_utils import OWN, ROOT, command, ref, save

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    stage = OWN / "start-delta-guard-v2"
    g = json.loads((stage / "result.json").read_bytes())
    assert g["status"] == "PASS" and not (stage / "TMP").exists()
    known = []
    for identity in [
        g["controller"],
        *(c["guardian_return"]["child"] for c in g["checks"]),
    ]:
        now = process.process_info(identity["pid"])
        assert (now is None and not Path(f"/proc/{identity['pid']}").exists()) or (
            now is not None and process.identity(now) != identity
        )
        known.append(
            dict(expected=identity, now="ABSENT" if now is None else "DIFFERENT")
        )
    started = save(
        OWN / "actual-source-start.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            intake=ref(OWN / "intake.json"),
            actual_private_delta=ref(
                OWN / "source-v1/post/crates/quoridor-ai/src/aspiration_window.rs"
            ),
            candidate_selection=ref(OWN / "window-selection-v1.json"),
            returned_source_guard=ref(stage / "result.json"),
            known_exact_identities_fresh_absent_or_different=known,
            source_status="ACTUAL_DELTA_NOT_FIXED_COMMON_ROOT_CONFIG_INTEGRATION_FOLLOWS",
            tests_compiler_native_model_RAW_RNG=0,
            source_leases_remaining=[],
            TMP_entries=[],
        ),
    )
    message = OWN / "Root-source-start.txt"
    message.write_text(
        "SAME29 actualready/show/claim sameowner/in_progress after returned28normal26deliverytailSTOP10:20:04.991304, preserved28 and27 controls. ActualSol6.1/high/Main/fullnever verified; immutableGit1dce95b alpha78bace52/score owner only. First substantive private Rustdelta now exists: typedAspirationWindow validation, finite failed-side-only growth and bounded full-window fallback state, namespace qualifier, boundedroot counters; scopedRuff/rustfmtPASS, sourceguardreturned/directreap/handles/freshIDsabsent/TMP/leases[]. CandidateONE halfwidth.125/growth2/activationD3/max4retry thenfullsame-depth; D1/D2full seed. Declared legacy[-1,1]/terminal2 and rawdomain checks retained, terminal/nonfinitepreviousscore cannot seed narrowwindow. Saved21first/latest scalar26 transitions only; adjacent-depth fluctuations/retryfrequency UNKNOWN, no calibration/pilot/RAW/model/Search. "
        + json.dumps(started)
        + ". This is sourceSTART only: commonroot/session/typednormalconsumer connection and necessary NEW boundary definitions INPROGRESS, NOTFIXED/SOURCECLEAR/software/native. Please no premature reviewerdispatch; fixedpacket follows sameactor. No Main/Git/Cargo/docs changes, tests/native/model/RNG0. FirsthelperlintE731 refusal beforedelta retained/causaldef fix only. Existing28normal26 and27conditional64/scopes/recipients unchanged. Continue actual integration now, no reply/ACKgate. Allpauses/seals/defaults/models/foreign/FAILED/NULL/UNKNOWNfees/50GB/consultation8 retained.\n"
    )
    result = command(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--issue",
            "quoridor-4lc.324",
            "--cwd",
            str(ROOT),
            "--body-file",
            str(message),
        ]
    )
    save(OWN / "Root-source-start-delivery.json", result)
    print(
        json.dumps(dict(source_start=started, delivery_returncode=result["returncode"]))
    )


if __name__ == "__main__":
    main()
