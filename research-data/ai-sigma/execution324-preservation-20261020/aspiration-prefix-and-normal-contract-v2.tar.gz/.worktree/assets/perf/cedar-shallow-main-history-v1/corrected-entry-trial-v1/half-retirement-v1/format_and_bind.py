"""Scoped formatting and static patch custody; no import/test/compile of target."""

import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
REV = "b1e965ffa7054dab9aff5c6c8c7037f2edbca89c"
LC = "scripts/dev/research-lifecycle.py"
FILES = json.loads((ROOT / "before-refs.json").read_text())["files"]
EDITS = json.loads((ROOT / "edit-ledger.json").read_text())
log = []
# format-bind-v1 finished target Rust/LC formatting and LC lint before a helper's
# unused import failed. Continue only the repaired helper and unfinished custody.
RESUME_FORMATTED = True


def run(argv, **kwargs):
    result = subprocess.run(argv, capture_output=True, text=True, check=False, **kwargs)
    log.append(
        dict(
            argv=argv,
            code=result.returncode,
            stdout=result.stdout,
            stderr=result.stderr,
        )
    )
    (ROOT / "format-and-patch-log-v2.json").write_text(json.dumps(log, indent=2) + "\n")
    assert result.returncode == 0, log[-1]
    return result.stdout


def digest(data):
    return hashlib.sha256(data).hexdigest()


def functions(text):
    return {n.name: n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef)}


expected = {}
for item in FILES:
    name = item["path"]
    original = (ROOT / "before" / name).read_text()
    assert digest(original.encode()) == item["sha256"]
    value = original
    for edit in EDITS:
        if edit["path"] == name:
            assert value.count(edit["old"]) == edit["occurrences"]
            value = value.replace(edit["old"], edit["new"])
    actual = (ROOT / "post" / name).read_text()
    if name == LC:
        assert ast.dump(ast.parse(value)) == ast.dump(ast.parse(actual))
    else:
        assert "".join(value.split()) == "".join(actual.split())
    expected[name] = value

for name in expected:
    if name.endswith(".rs") and not RESUME_FORMATTED:
        run(
            [
                "/usr/local/cargo/bin/rustfmt",
                "--edition",
                "2024",
                "--config",
                "skip_children=true",
                str(ROOT / "post" / name),
            ]
        )

before_functions = functions((ROOT / "before" / LC).read_text())
after_functions = functions(expected[LC])
changed = {
    name
    for name in before_functions.keys() & after_functions.keys()
    if ast.dump(before_functions[name]) != ast.dump(after_functions[name])
}
assert changed == {
    "measurement_config",
    "measurement_evidence",
    "arena_plan_check",
    "arena_observation",
    "comparison_conditions",
    "apply_comparison_cost",
    "apply_comparison_arena",
}
assert before_functions.keys() - after_functions.keys() == {
    "resolved_shallow_main_history"
}
# Private path discovery used Ruff's 88 default in v1. Correct only this causal
# formatting mismatch to canonical LC's 100-column convention; Rust is carried.
(ROOT / "post" / LC).write_text(expected[LC])
for name in sorted(changed, key=lambda key: after_functions[key].lineno, reverse=True):
    node = after_functions[name]
    run(
        [
            "ruff",
            "format",
            "--line-length",
            "100",
            "--range",
            f"{node.lineno}-{node.end_lineno}",
            str(ROOT / "post" / LC),
        ]
    )
run(["ruff", "check", "--no-cache", str(ROOT / "post" / LC)])
for helper in ["prepare_retirement.py", "format_and_bind.py"]:
    run(["ruff", "format", str(ROOT / helper)])
    run(["ruff", "check", "--no-cache", str(ROOT / helper)])

for name, unformatted in expected.items():
    formatted = (ROOT / "post" / name).read_text()
    if name == LC:
        assert ast.dump(ast.parse(unformatted)) == ast.dump(ast.parse(formatted))
    else:
        assert "".join(unformatted.split()) == "".join(formatted.split()), name
    assert "ShallowMainHistory" not in formatted, name
    if name.endswith(".rs"):
        assert "shallow_main_history" not in formatted, name

# Every unchanged top-level Python function remains byte exact, beyond AST identity.
formatted_lc = (ROOT / "post" / LC).read_text()
final_functions = functions(formatted_lc)
before_lines = (ROOT / "before" / LC).read_text().splitlines(keepends=True)
post_lines = formatted_lc.splitlines(keepends=True)
protected_functions = []
for name in before_functions.keys() & final_functions.keys() - changed:
    a, b = before_functions[name], final_functions[name]
    original = "".join(before_lines[a.lineno - 1 : a.end_lineno])
    final = "".join(post_lines[b.lineno - 1 : b.end_lineno])
    assert original == final, name
    protected_functions.append(name)

forward, inverse = [], []
post_refs, stat = [], []
for item in FILES:
    name = item["path"]
    a = (ROOT / "before" / name).read_text().splitlines(keepends=True)
    b = (ROOT / "post" / name).read_text().splitlines(keepends=True)
    diff = list(difflib.unified_diff(a, b, fromfile="a/" + name, tofile="b/" + name))
    forward.extend(diff)
    inverse.extend(difflib.unified_diff(b, a, fromfile="a/" + name, tofile="b/" + name))
    (ROOT / (name.replace("/", "__") + ".diff")).write_text("".join(diff))
    data = (ROOT / "post" / name).read_bytes()
    post_refs.append(dict(path=name, sha256=digest(data), bytes=len(data), mode="0644"))
    stat.append(
        dict(
            path=name,
            removed=sum(s.startswith("-") for s in diff) - 1,
            added=sum(s.startswith("+") for s in diff) - 1,
        )
    )
(ROOT / "forward.patch").write_text("".join(forward))
(ROOT / "inverse.patch").write_text("".join(inverse))

# Apply and restore only sparse private owner files, without source/Git mutation.
with tempfile.TemporaryDirectory(prefix="half-retirement-", dir=ROOT) as directory:
    tree = Path(directory)
    for item in FILES:
        path = tree / item["path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((ROOT / "before" / item["path"]).read_bytes())
    for kind in ["forward", "inverse"]:
        output = run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "-p1",
                "--input",
                str(ROOT / (kind + ".patch")),
            ],
            cwd=tree,
        )
        assert "offset" not in output.lower() and "fuzz" not in output.lower(), output
        expected_tree = ROOT / ("post" if kind == "forward" else "before")
        for item in FILES:
            assert (tree / item["path"]).read_bytes() == (
                expected_tree / item["path"]
            ).read_bytes()

protected_git_files = [
    "crates/quoridor-ai/src/neighbour_opportunity.rs",
    "crates/quoridor-ai/src/neighbour_opportunity_tests.rs",
    "scripts/dev/research-job.py",
    "python/quoridor_training/cycle_process.py",
    "python/quoridor_training/snapshot.py",
]
protected = [
    dict(
        path=name,
        git_blob=run(["git", "rev-parse", f"{REV}:{name}"]).strip(),
        patch_member=False,
    )
    for name in protected_git_files
]
binding = dict(
    schema="quoridor.private-source-retirement.v1",
    issue="quoridor-4lc.324.25.3",
    git=REV,
    status="PRIVATE_FIXED_ROOT_COMPOSITION_SOFTWARE_UNRUN",
    before=FILES,
    post=post_refs,
    diff_stat=stat,
    removed_python_owners=["resolved_shallow_main_history"],
    changed_python_owners=sorted(changed),
    unchanged_python_functions_byte_exact=sorted(protected_functions),
    protected_git_files=protected,
    static_outside_edit_spans="Exact replay of enumerated byte edits from immutable before; formatter-only whitespace afterwards",
    python_format_ast_exact=True,
    rust_formatter_nonwhitespace_exact=True,
    forward_inverse_fuzz=0,
    forward_inverse_offsets=0,
    exact_reconstruction=True,
    tests_run=0,
    compiler=0,
    native=0,
    rng=0,
    main_writes=0,
    limits="Static source/AST/formatter/patch custody only; no compiler, tests or semantic software qualification claimed",
)
(ROOT / "binding.json").write_text(json.dumps(binding, indent=2) + "\n")
(ROOT / "format-and-patch-log.json").write_text(json.dumps(log, indent=2) + "\n")
print(
    json.dumps(
        dict(
            files=len(FILES),
            diff_stat=stat,
            binding_sha256=digest((ROOT / "binding.json").read_bytes()),
        )
    )
)
