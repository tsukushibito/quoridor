"""Bind actual source-helper return and send the fixed packet only to Root324."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


returned_path = ROOT / "source-finalizer-v1" / "return.json"
returned = json.loads(returned_path.read_text())
assert returned["exit_code"] == 0
assert returned["direct_child_reaped"] and returned["handle_closes_complete"]
assert returned["cleanup_complete"] and returned["remaining"] == []
assert (
    returned["signal_mask_restoration"]
    == returned["final_record_persist"]
    == "completed"
)
controller = json.loads((ROOT / "source-finalizer-v1" / "controller.json").read_text())
identities = []
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
for identity in [controller, returned["child"]]:
    try:
        actual = (
            Path(f"/proc/{identity['pid']}/stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19]
        )
    except FileNotFoundError:
        status = "absent"
    else:
        assert boot != identity["boot_id"] or actual != str(identity["start_ticks"])
        status = "different_identity"
    identities.append(
        dict(
            identity={k: identity[k] for k in ["pid", "start_ticks", "boot_id"]},
            now=status,
        )
    )
compact = dict(
    issue="quoridor-4lc.324.25.3",
    at=datetime.now(timezone.utc).isoformat(),
    packet=ref(ROOT / "packet.json"),
    source_STOP=ref(ROOT / "source-STOP.json"),
    source_finalizer_return=ref(returned_path),
    source_finalizer_identities=identities,
    directwait_reap_handles=True,
    cleanup=True,
    remaining=[],
    TMP=[],
    leases=[],
    affected=ref(ROOT / "actual-affected-point.json"),
    admin=ref(ROOT / "admin-receipt.json"),
    no_Main_read_lease=True,
    no_future_host_quiet_or_resource_lease=True,
    delivery_lifetime="Only this bounded light delivery remains; actual result-delivery-v1/return.json follows normal direct return",
)
(ROOT / "returned-source-STOP.json").write_text(json.dumps(compact, indent=2) + "\n")
stop_ref = ref(ROOT / "returned-source-STOP.json")
binding_ref = ref(ROOT / "binding.json")
forward_ref = ref(ROOT / "forward.patch")
packet_ref = ref(ROOT / "packet.json")
body = f"""SAME High9 own25.3 private candidate-only HALF retirement is fixed and source helpers actually returned. Root finite-result acceptance received; own remains in_progress pending actual canonical retirement/disposition. No29 private read/write, Main/Git/index/Cargo write0, compiler/test/native/model/RAW/input/RNG0, no reviewer dispatch.

Immutable base b1e965ffa7054dab9aff5c6c8c7037f2edbca89c; 10 sparse owners, -592/+19. Remove Half enum/config/setter/namespace, separate main bonus, live propagation/guards/counters and only five candidate Rust test definitions. Main and continuation use the unchanged original signed bonus/gravity. All frozen source/fixtures/results/FAILED are historical and unchanged. Generic timed-rootquality admission and alphabeta::neighbour_opportunity::tests::timed_root_quality_real_callee_admission_isolation_and_error_restore_nn0 remain whole-file outside patch, as do generic original21/23 tests/features.

GNU forward/inverse exact fuzz0/offset0; scoped rustfmt/LC Ruff100/lint and static edit correspondence complete. 87 other LC functions byte exact, common history math/reset/age/score owners byte exact. Static source custody only, not canonical software/source-clear. Initial helper Git typo/exact-match assertion/unused-import/Ruff88-vs100 failure receipts preserved, corrected causal derivatives returned0; no scientific retry.

Potential29 intersections explicitly documented: SearchSession reset/namespace/settings API; Runner Engine/Settings, arena session/namespace/profile/output; LC measurement_config/evidence, arena_plan_check/observation and comparison factories. Root must compose local deletions, NOT overwrite either whole alpha/runtime/measurement/LC postimage. No actual29 interfaces were inspected or invented.

Packet {json.dumps(packet_ref)}
Binding {json.dumps(binding_ref)}
Forward {json.dumps(forward_ref)}
Returned source STOP {json.dumps(stop_ref)}
Inverse/protection/owner notes and actual before/post refs are bound by packet. New-subtree single stat point 3710976 allocatedB/3333397 logicalB/176 inode entries; later delivery/admin tails/globalactual/fullfees UNKNOWN, no old holding recharge/globalwalk/refund/lending. CPU10/G18/family1GiB incl64MiB/host4/G0 guarded children directwait/reaped/handles/TMP/leases[]; source-finalizer0/.031551234s now actual IDs absent/different, all earlier source IDs checked once. Note/backup/show sameowner in_progress PASS. Only this light delivery lifetime remains and its actual result-delivery-v1/return.json owns completion. No idle/future quiet claim or ACK gate. NEW104/64 exhausted/RETAIN_CURRENT, all pauses/seals/defaults/models/foreign/FAILED/UNKNOWN/50GB preserved.
"""
(ROOT / "root-handoff.txt").write_text(body)
argv = [
    "bash",
    "scripts/dev/research-session.sh",
    "send",
    "--thread",
    "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
    "--issue",
    "quoridor-4lc.324",
    "--body-file",
    str(ROOT / "root-handoff.txt"),
]
result = subprocess.run(argv, capture_output=True, text=True, check=False)
(ROOT / "delivery-process.json").write_text(
    json.dumps(
        dict(
            argv=argv,
            code=result.returncode,
            stdout=result.stdout,
            stderr=result.stderr,
        ),
        indent=2,
    )
    + "\n"
)
assert result.returncode == 0, result.stderr
print(
    json.dumps(
        dict(packet=packet_ref, returned_source_STOP=stop_ref, delivery=result.stdout)
    )
)
