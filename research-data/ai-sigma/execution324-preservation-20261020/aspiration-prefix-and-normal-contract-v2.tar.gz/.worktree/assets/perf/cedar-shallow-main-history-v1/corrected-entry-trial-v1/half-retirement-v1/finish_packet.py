"""Close this bounded private source stage, retaining the own issue in progress."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def fn(text, name):
    match = re.search(r"^( *)(?:pub(?:\([^\n]*?\))? )?fn " + name + r"\b", text, re.M)
    assert match, name
    end = re.search(r"^" + match[1] + r"}\n", text[match.start() :], re.M)
    assert end, name
    return text[match.start() : match.start() + end.end()]


protected = []
path = "crates/quoridor-ai/src/continuation_history.rs"
before, post = [(ROOT / tree / path).read_text() for tree in ["before", "post"]]
for name in [
    "main_index",
    "previous",
    "continuation_index",
    "gravity",
    "bonus",
    "score",
    "reset",
    "finish_valid_root",
    "prepare_scores",
]:
    a, b = fn(before, name), fn(post, name)
    assert a == b, name
    protected.append(
        dict(
            owner=path + "::" + name,
            bytes=len(a.encode()),
            sha256=hashlib.sha256(a.encode()).hexdigest(),
            byte_exact=True,
        )
    )
marker = "    #[test]\n    fn control385_prepared_lags"
a, b = before[before.index(marker) :], post[post.index(marker) :]
assert a == b
protected.append(
    dict(
        owner=path + "::all_original_tests_and_work_owners_suffix",
        sha256=hashlib.sha256(a.encode()).hexdigest(),
        byte_exact=True,
    )
)
path = "crates/quoridor-ai/src/history_provenance.rs"
before, post = [(ROOT / tree / path).read_text() for tree in ["before", "post"]]
marker = "#[cfg(test)]\nmod history_provenance_boundary_tests"
a = before[
    before.index(marker) : before.index(
        "\n#[cfg(test)]\nmod shallow_main_provenance_tests"
    )
]
b = post[post.index(marker) :]
assert a.rstrip() == b.rstrip()
protected.append(
    dict(
        owner=path + "::history_provenance_boundary_tests",
        sha256=hashlib.sha256(b.encode()).hexdigest(),
        body_byte_exact=True,
    )
)
(ROOT / "protected-owners.json").write_text(json.dumps(protected, indent=2) + "\n")

binding = json.loads((ROOT / "binding.json").read_text())
summary = """# Private Half retirement against immutable b1e965ff

The finite producer retained Current. This packet removes the candidate API and
restores one existing signed bonus for both main and continuation before the
unchanged gravity owner. It is private source preparation, not Main adoption or
software qualification. No scientific rights remain or are created here.

10 sparse owners, 592 deleted / 19 added lines. forward.patch and inverse.patch
reconstruct the exact before/post files with GNU --fuzz=0 and no offset. Whole
postimages are reference material only; Root must compose the individual changes
onto its current owners, preserving the separate aspiration29 packet.

Removed: ShallowMainHistory enums/resolver/deserialize, the history field and
separate main_amount, SearchSession getter/setter and namespace prefix/reset
qualification, Half SMP guard, Runner Settings/Engine field and propagation,
arena policy equality checks, policy counters, LC policy resolver/evidence and
comparison propagation. LC keeps small retired-key refusals at arena/preparation
owners; strict measurement key set and native deny_unknown_fields reject old
fields. No fallback/compatibility configuration is added.

Removed only these five candidate-only Rust definitions:
- continuation_history::tests::shallow_main_bonus_depth_sign_gravity_continuation_and_age_boundary
- shallow_main_setting_tests::shallow_main_setting_default_refusal_namespace_reset
- history_provenance::shallow_main_provenance_tests::shallow_main_provenance_reports_distinct_main_and_continuation_bonus
- shallow_main_measurement_boundary_tests::shallow_main_measurement_typed_default_clock_observer_and_refusal
- shallow_main_arena_boundary_tests::shallow_main_arena_default_typed_namespace_and_research_refusal

The private Python comparison fixtures and all frozen failed/incorrect fixtures,
old configs/source/results/RAW/images remain historical evidence. They are not
current adoption/test targets and were neither edited nor executed.

Preserved common owners: main/continuation keys and score weights, bonus/gravity,
reset/16-valid-root aging, positive/deeper behavior and all original work counters;
LMR, ordering priorities, NNUE and deadlines. Protected byte receipts cover the
core history functions and original generic tests. All 87 unchanged LC functions
remain byte exact, including authority, caller_source_refs, parameter owners,
cleanup and unrelated consumer branches. The seven changed LC owners retain all
unrelated predicates; only candidate fields/counters/resolution are removed or
refused. Rust formatting adds no nonwhitespace outside the enumerated edits.

Generic rootquality admission/callee test are NOT retirement targets:
neighbour_opportunity.rs and neighbour_opportunity_tests.rs have no patch member.
Retained exact selector:
alphabeta::neighbour_opportunity::tests::timed_root_quality_real_callee_admission_isolation_and_error_restore_nn0
The two original history_provenance_boundary_tests and original ordering tests
remain; no successful tests, compiler, native, model, RAW, input or RNG were run.

Potential aspiration29 intersections (private29 source unread): alphabeta
SearchSession reset/namespace and adjacent settings API; Runner Engine/Settings,
arena_alpha_namespace/session, profile/output metadata; LC measurement_config,
measurement_evidence, arena_plan_check/arena_observation and comparison factories.
lazy_smp::set_search_threads loses only its Half guard. Root should keep29's new
interfaces/guards/math untouched and compose these exact deletions locally.
No claim is made that this beforeimage patch applies unchanged after29 integration.

Validation: private rustfmt(skip_children), scoped LC Ruff100 and lint, Python AST
and unaffected-function byte correspondence, exact GNU forward/inverse restoration.
No new removal-mirroring tests were created. Root owns combined-boundary review,
canonical software and genuine source/control images after actual compatible STOP.

Preserved helper failures: an initial Git hash typo; absent grep pattern; an
ambiguous exact replacement count before correcting indentation anchoring; an
unused helper import; and the Ruff88-vs100 format custody assertion. Each failed
guard returned/reaped/closed handles/TMP. Corrected preparation and format custody
returned0. No failure is software/science PASS; no payload or successful suite replay.
"""
(ROOT / "retirement-notes.md").write_text(summary)
packet = dict(
    schema="quoridor.private-half-retirement-packet.v1",
    issue="quoridor-4lc.324.25.3",
    status="FIXED_PRIVATE_ONLY_ROOT_SPARSE_COMPOSITION_REQUIRED",
    immutable_git=binding["git"],
    binding=ref(ROOT / "binding.json"),
    forward=ref(ROOT / "forward.patch"),
    inverse=ref(ROOT / "inverse.patch"),
    notes=ref(ROOT / "retirement-notes.md"),
    protection=ref(ROOT / "protected-owners.json"),
    format_and_patch_log=ref(ROOT / "format-and-patch-log.json"),
    main_write=False,
    compiler=False,
    tests=False,
    native=False,
    rng=False,
    source23_21_results="retained",
    issue_status="in_progress_same_assignee",
)
(ROOT / "packet.json").write_text(json.dumps(packet, indent=2) + "\n")
note = (
    "Unsupported Half retirement PRIVATE fixed against immutable b1e965ffa7054dab9aff5c6c8c7037f2edbca89c. "
    "10 sparse owners, -592/+19; Current common gravity/positive/deeper/continuation/age and generic timed-rootquality "
    "admission+real callee test preserved. GNU forward/inverse fuzz0/offset0 exact; rustfmt/scoped Ruff100/lint "
    "and outside-owner byte/AST correspondence only. Main/Git/Cargo/test/native/model/RAW/RNG0; no29 private read. "
    "Packet corrected-entry-trial-v1/half-retirement-v1/packet.json; potential29 shared setting/namespace/consumer "
    "intersections documented for Root sparse composition. All failed helpers/history/science/costs retained. "
    "NEW104/64 exhausted; RETAIN_CURRENT producer, no further science. Own stays in_progress pending genuine Root acceptance."
)
env = dict(os.environ, BEADS_ACTOR="codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0")
admin = []
for args in [
    ["update", "quoridor-4lc.324.25.3", "--append-notes", note],
    ["backup", "sync"],
    ["show", "quoridor-4lc.324.25.3", "--json"],
]:
    result = subprocess.run(
        ["bash", "scripts/dev/beads.sh", *args],
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    admin.append(dict(argv=args, code=result.returncode, stderr=result.stderr))
    assert result.returncode == 0, admin[-1]
    if args[0] == "show":
        issue = json.loads(result.stdout)[0]
        assert issue["status"] == "in_progress"
        assert issue["assignee"] == env["BEADS_ACTOR"]
        admin[-1]["verified"] = {k: issue[k] for k in ["id", "status", "assignee"]}
    else:
        admin[-1]["stdout"] = result.stdout
(ROOT / "admin-receipt.json").write_text(json.dumps(admin, indent=2) + "\n")
print(
    json.dumps(
        dict(
            packet=ref(ROOT / "packet.json"),
            admin="note/backup/show PASS",
            at=datetime.now(timezone.utc).isoformat(),
        )
    )
)
