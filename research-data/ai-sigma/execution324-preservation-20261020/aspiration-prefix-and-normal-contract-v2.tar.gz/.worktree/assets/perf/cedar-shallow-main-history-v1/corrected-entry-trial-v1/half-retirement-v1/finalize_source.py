"""One finite check of this source stage's recorded identities and affected tree."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def absent(identity):
    try:
        actual_start = (
            Path(f"/proc/{identity['pid']}/stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19]
        )
    except FileNotFoundError:
        return "absent"
    assert BOOT != identity["boot_id"] or actual_start != str(
        identity["start_ticks"]
    ), identity
    return "different_identity"


phases = []
for controller in sorted(ROOT.glob("*/controller.json")):
    if controller.parent.name == "source-finalizer-v1":
        continue
    identity = json.loads(controller.read_text())
    process_path = controller.parent / "command.process.json"
    process = json.loads(process_path.read_text())
    returned_path = controller.parent / "return.json"
    returned = json.loads(returned_path.read_text())
    assert process["direct_child_reaped"] is True
    assert process["handle_closes_complete"] is True
    assert process["cleanup_complete"] is True and process["remaining"] == []
    tmp = controller.parent / "TMP"
    assert not tmp.exists(), tmp
    phases.append(
        dict(
            phase=controller.parent.name,
            controller={k: identity[k] for k in ["pid", "start_ticks", "boot_id"]},
            controller_now=absent(identity),
            child=process["child"],
            child_now=absent(process["child"]),
            process=ref(process_path),
            returned=ref(returned_path),
            exit_code=process["exit_code"],
            direct_child_reaped=True,
            handles_closed=True,
            remaining=[],
            TMP=[],
            original_process_mask=process["signal_mask_restoration"],
            original_process_persist=process["final_record_persist"],
            actual_returned_mask=returned.get("signal_mask_restoration")
            if returned
            else None,
            actual_returned_persist=returned.get("final_record_persist")
            if returned
            else None,
        )
    )

# This stat-only point is restricted to the newly affected retirement subtree.
seen = set()
allocated = logical = entries = 0
for directory, subdirs, files in os.walk(ROOT):
    for name in [".", *subdirs, *files]:
        path = Path(directory) if name == "." else Path(directory) / name
        stat = path.lstat()
        key = (stat.st_dev, stat.st_ino)
        if key not in seen:
            seen.add(key)
            allocated += stat.st_blocks * 512
            logical += stat.st_size
            entries += 1
point = dict(
    at=datetime.now(timezone.utc).isoformat(),
    scope=str(ROOT),
    allocated_B=allocated,
    logical_B=logical,
    unique_entries=entries,
    method="stat-only device/inode union, new retirement subtree only, once",
    prior_holding_recharged=False,
    global_walk=False,
    quota_refund=False,
    later_delivery_admin_tails_global_actual_full_fees="UNKNOWN",
)
(ROOT / "actual-affected-point.json").write_text(json.dumps(point, indent=2) + "\n")
stop = dict(
    schema="quoridor.private-source-stage-STOP.v1",
    issue="quoridor-4lc.324.25.3",
    at=datetime.now(timezone.utc).isoformat(),
    packet=ref(ROOT / "packet.json"),
    source_scope="Only 10 sparse postimages and evidence under new OWN retirement subtree",
    source_Main_reads="Immutable Git objects only; no live Main SH lease/import",
    directwait_reap_handles=True,
    recorded_known_identities=phases,
    TMP=[],
    owned_leases=[],
    finalizer_current="This bounded source-finalizer-v1 controller/child still executing this receipt; its actual return is separately required",
    finalizer_return_path=str(ROOT / "source-finalizer-v1" / "return.json"),
    future_host_quiet_or_resource_lease=False,
    actual_affected_point=ref(ROOT / "actual-affected-point.json"),
    admin=ref(ROOT / "admin-receipt.json"),
    source_acceptance="NOT_CLAIMED_PRIVATE_ONLY",
    compiler=0,
    tests=0,
    native=0,
    rng=0,
    note="Root finite-result acceptance delivered separately; source retirement remains Root sparse composition/software responsibility",
)
(ROOT / "source-STOP.json").write_text(json.dumps(stop, indent=2) + "\n")
print(json.dumps(dict(source_STOP=ref(ROOT / "source-STOP.json"), affected=point)))
