# Private Half retirement against immutable b1e965ff

The finite producer retained Current. This packet removes the candidate API and
restores one existing signed bonus for both main and continuation before the
unchanged gravity owner. It is private source preparation, not Main adoption or
software qualification. No scientific rights remain or are created here.

10 sparse owners, 592 deleted / 19 added lines. forward.patch and inverse.patch
reconstruct the exact before/post files with GNU --fuzz=0 and no offset. Whole
postimages are reference material only; Root must compose the individual changes
onto its current owners, preserving the separate aspiration29 packet.

Removed: ShallowMainHistory enums/resolver/deserialize, the history field and
separate main_amount, SearchSession getter/setter and namespace prefix/reset
qualification, Half SMP guard, Runner Settings/Engine field and propagation,
arena policy equality checks, policy counters, LC policy resolver/evidence and
comparison propagation. LC keeps small retired-key refusals at arena/preparation
owners; strict measurement key set and native deny_unknown_fields reject old
fields. No fallback/compatibility configuration is added.

Removed only these five candidate-only Rust definitions:
- continuation_history::tests::shallow_main_bonus_depth_sign_gravity_continuation_and_age_boundary
- shallow_main_setting_tests::shallow_main_setting_default_refusal_namespace_reset
- history_provenance::shallow_main_provenance_tests::shallow_main_provenance_reports_distinct_main_and_continuation_bonus
- shallow_main_measurement_boundary_tests::shallow_main_measurement_typed_default_clock_observer_and_refusal
- shallow_main_arena_boundary_tests::shallow_main_arena_default_typed_namespace_and_research_refusal

The private Python comparison fixtures and all frozen failed/incorrect fixtures,
old configs/source/results/RAW/images remain historical evidence. They are not
current adoption/test targets and were neither edited nor executed.

Preserved common owners: main/continuation keys and score weights, bonus/gravity,
reset/16-valid-root aging, positive/deeper behavior and all original work counters;
LMR, ordering priorities, NNUE and deadlines. Protected byte receipts cover the
core history functions and original generic tests. All 87 unchanged LC functions
remain byte exact, including authority, caller_source_refs, parameter owners,
cleanup and unrelated consumer branches. The seven changed LC owners retain all
unrelated predicates; only candidate fields/counters/resolution are removed or
refused. Rust formatting adds no nonwhitespace outside the enumerated edits.

Generic rootquality admission/callee test are NOT retirement targets:
neighbour_opportunity.rs and neighbour_opportunity_tests.rs have no patch member.
Retained exact selector:
alphabeta::neighbour_opportunity::tests::timed_root_quality_real_callee_admission_isolation_and_error_restore_nn0
The two original history_provenance_boundary_tests and original ordering tests
remain; no successful tests, compiler, native, model, RAW, input or RNG were run.

Potential aspiration29 intersections (private29 source unread): alphabeta
SearchSession reset/namespace and adjacent settings API; Runner Engine/Settings,
arena_alpha_namespace/session, profile/output metadata; LC measurement_config,
measurement_evidence, arena_plan_check/arena_observation and comparison factories.
lazy_smp::set_search_threads loses only its Half guard. Root should keep29's new
interfaces/guards/math untouched and compose these exact deletions locally.
No claim is made that this beforeimage patch applies unchanged after29 integration.

Validation: private rustfmt(skip_children), scoped LC Ruff100 and lint, Python AST
and unaffected-function byte correspondence, exact GNU forward/inverse restoration.
No new removal-mirroring tests were created. Root owns combined-boundary review,
canonical software and genuine source/control images after actual compatible STOP.

Preserved helper failures: an initial Git hash typo; absent grep pattern; an
ambiguous exact replacement count before correcting indentation anchoring; an
unused helper import; and the Ruff88-vs100 format custody assertion. Each failed
guard returned/reaped/closed handles/TMP. Corrected preparation and format custody
returned0. No failure is software/science PASS; no payload or successful suite replay.
