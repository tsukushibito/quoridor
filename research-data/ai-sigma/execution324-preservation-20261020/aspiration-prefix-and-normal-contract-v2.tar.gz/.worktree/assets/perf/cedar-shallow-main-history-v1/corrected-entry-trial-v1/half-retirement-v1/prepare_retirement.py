"""Apply the authorized retirement only to immutable task-private postimages."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EDITS = []
for before in (ROOT / "before").rglob("*"):
    if before.is_file():
        (ROOT / "post" / before.relative_to(ROOT / "before")).write_bytes(
            before.read_bytes()
        )


def change(path, old, new="", count=1):
    target = ROOT / "post" / path
    text = target.read_text()
    assert text.count(old) == count, (path, old[:100], text.count(old))
    target.write_text(text.replace(old, new))
    EDITS.append(dict(path=path, old=old, new=new, occurrences=count))


def cut(path, first, following):
    text = (ROOT / "post" / path).read_text()
    start = text.index(first)
    end = text.index(following, start)
    change(path, text[start:end])


def tail(path, marker):
    text = (ROOT / "post" / path).read_text()
    change(path, text[text.index(marker) :])


ai = "crates/quoridor-ai/src/"
runner = "crates/quoridor-runner/src/"
p = ai + "continuation_history.rs"
cut(p, "/// One research setting;", "pub(super) struct ContinuationHistory")
change(p, "    pub(super) shallow_main_history: ShallowMainHistory,\n")
change(p, "            shallow_main_history: ShallowMainHistory::default(),\n")
change(p, "        main_amount: i32,\n")
change(
    p,
    "gravity(&mut self.main[main_index(p, action)], main_amount);",
    "gravity(&mut self.main[main_index(p, action)], amount);",
)
change(
    p,
    "                self.shallow_main_history\n                    .main_bonus(depth, if action == winner { b } else { -b }),\n",
)
cut(
    p,
    "    #[test]\n    fn shallow_main_bonus_depth_sign_gravity_continuation_and_age_boundary()",
    "    #[test]\n    fn control385_prepared_lags",
)

p = ai + "alphabeta.rs"
change(p, "pub use continuation_history::ShallowMainHistory;\n")
cut(
    p,
    "    /// Explicit research Control setting; changing it clears TT and all history.",
    "    pub fn lmr_parameters(&self)",
)
change(
    p,
    "        self.shallow_main_history()\n            .qualify_namespace(&mut self.namespace);\n",
)
tail(p, "\n#[cfg(test)]\nmod shallow_main_setting_tests")

p = ai + "history_provenance.rs"
change(
    p,
    """                bonus: {
                    let signed = if positive {
                        super::bonus(depth)
                    } else {
                        -super::bonus(depth)
                    };
                    if matches!(self.selectors[i], HistoryEntrySelector::Main { .. }) {
                        h.shallow_main_history.main_bonus(depth, signed)
                    } else {
                        signed
                    }
                },""",
    """                bonus: if positive {
                    super::bonus(depth)
                } else {
                    -super::bonus(depth)
                },""",
)
tail(p, "\n#[cfg(test)]\nmod shallow_main_provenance_tests")

p = ai + "lazy_smp.rs"
cut(
    p,
    "        if threads > 1 && self.shallow_main_history()",
    "        if threads == 1 && self.native_workers.is_none()",
)

p = runner + "config.rs"
cut(
    p,
    "/// Typed research setting; absence is current,",
    "#[derive(Debug, Clone, Serialize, Deserialize)]\n#[serde(deny_unknown_fields)]\npub struct Engine",
)
change(
    p,
    """    #[serde(
        default,
        deserialize_with = "deserialize_shallow_main_history",
        skip_serializing_if = "Option::is_none"
    )]
    pub shallow_main_history: Option<ShallowMainHistory>,
""",
)
change(p, "                    || e.shallow_main_history.is_some()\n")
change(
    p,
    """            crate::runtime::arena_shallow_main_history(engine, self.arena.as_ref())
                .map_err(|e| e.to_string())?;
""",
)
change(p, "                    || engine.shallow_main_history.is_some()\n", count=2)

p = runner + "measurement.rs"
change(
    p,
    """    #[serde(
        default,
        deserialize_with = "crate::config::deserialize_shallow_main_history",
        skip_serializing_if = "Option::is_none"
    )]
    shallow_main_history: Option<crate::config::ShallowMainHistory>,
""",
)
cut(
    p,
    "    if settings.shallow_main_history.is_some()",
    "    let lmr_method = LmrMethod::from_name",
)
change(
    p,
    """        session
            .set_shallow_main_history(self.settings.shallow_main_history.map(|p| p.resolve()))?;
""",
)
change(
    p,
    """        row["requested_shallow_main_history"] = json!(self.settings.shallow_main_history);
        row["actual_shallow_main_history"] = json!(session.shallow_main_history().name());
""",
)
tail(p, "\n#[cfg(test)]\nmod shallow_main_measurement_boundary_tests")

p = runner + "measurement_ordering394_tests.rs"
change(p, "                shallow_main_history: None,\n")

p = runner + "runtime.rs"
change(p, "    pub actual_shallow_main_history: Option<String>,\n")
cut(
    p,
    "pub(crate) fn arena_shallow_main_history(",
    "pub(crate) fn arena_lmr_parameters(",
)
change(
    p,
    "    arena_shallow_main_history(engine, arena)?.qualify_namespace(&mut namespace);\n",
)
change(
    p,
    """    arena_shallow_main_history(engine, arena)?;
    session.set_shallow_main_history(engine.shallow_main_history.map(|p| p.resolve()))?;
""",
)
change(
    p,
    "        profile.actual_shallow_main_history = Some(session.shallow_main_history().name().into());\n",
)
change(
    p,
    """        "requested_shallow_main_history":config.engines[engine].shallow_main_history,
        "actual_shallow_main_history":game.tt_profiles[engine].actual_shallow_main_history,
""",
)
tail(p, "\n#[cfg(test)]\nmod shallow_main_arena_boundary_tests")

p = runner + "arena.rs"
change(
    p,
    """            crate::runtime::arena_shallow_main_history(engine, Some(self))
                .map_err(|e| e.to_string())?;
""",
)
change(
    p,
    """                    || crate::runtime::arena_shallow_main_history(a, Some(self)).ok()
                        != crate::runtime::arena_shallow_main_history(b, Some(self)).ok()
""",
    count=2,
)
cut(
    p,
    "            let shallow = crate::runtime::arena_shallow_main_history(engine, Some(a))?;",
    "            let (enabled, method) = crate::runtime::arena_safe_race(engine, Some(a))?;",
)

p = "scripts/dev/research-lifecycle.py"
cut(p, "def resolved_shallow_main_history(", "def resolved_lmr_parameters(")
change(p, '            "shallow_main_history",\n')
change(p, '    resolved_shallow_main_history(config, config["profile"])\n', count=2)
cut(
    p,
    '    config = document(experiment["config"])\n    if "shallow_main_history" in config:',
    '    raw_refs = [ref for ref in files if spec.get("perf")',
)
change(
    p,
    """        resolved_shallow_main_history(
            engine,
            engine.get("ordering_profile"),
            supported=engine["kind"] in {"nnue", "distance", "sigma_value"}
            and a["comparison"] != "functional",
        )
""",
    """        require("shallow_main_history" not in engine, "retired arena setting")
""",
)
change(
    p,
    """            )
            and resolved_shallow_main_history(engines[0], engines[0].get("ordering_profile"))
            == resolved_shallow_main_history(engines[1], engines[1].get("ordering_profile")),
""",
    """            ),
""",
)
change(
    p,
    """                and counters.get("requested_shallow_main_history")
                == engine.get("shallow_main_history")
                and counters.get("actual_shallow_main_history")
                == resolved_shallow_main_history(engine, engine.get("ordering_profile"))
""",
)
change(
    p,
    '    require("history_tie_breaks" not in common, "retired comparison setting")',
    '    require(\n        not {"history_tie_breaks", "shallow_main_history"}.intersection(common),\n        "retired comparison setting",\n    )',
)
change(
    p,
    '        if "shallow_main_history" in common:\n            variant["shallow_main_history"] = common["shallow_main_history"]\n        resolved_shallow_main_history(variant, variant["profile"])\n',
)
change(
    p,
    '\n    require("history_tie_break" not in variant, "retired comparison variant")',
    '\n    require(\n        not {"history_tie_break", "shallow_main_history"}.intersection(variant),\n        "retired comparison variant",\n    )',
)
change(
    p,
    """    if "shallow_main_history" in variant:
        config["shallow_main_history"] = variant["shallow_main_history"]
    else:
        config.pop("shallow_main_history", None)
""",
)
change(
    p,
    '        require("history_tie_break" not in variant, "retired comparison variant")',
    '        require(\n            not {"history_tie_break", "shallow_main_history"}.intersection(variant),\n            "retired comparison variant",\n        )',
)
change(
    p,
    """        if "shallow_main_history" in variant:
            engine["shallow_main_history"] = variant["shallow_main_history"]
        else:
            engine.pop("shallow_main_history", None)
        resolved_shallow_main_history(engine, engine["ordering_profile"])
""",
)

for path in sorted({entry["path"] for entry in EDITS}):
    text = (ROOT / "post" / path).read_text()
    assert "ShallowMainHistory" not in text, path
    assert "shallow-main-negative-half" not in text, path
    if path.endswith(".rs"):
        assert "shallow_main_history" not in text, path
(ROOT / "edit-ledger.json").write_text(json.dumps(EDITS, indent=2) + "\n")
print(json.dumps(dict(files=len({e["path"] for e in EDITS}), edits=len(EDITS))))
