# 16.1 normal-readiness continuation

## Concrete current interface gap and private repair

At immutable Main b1e965ffa7054dab9aff5c6c8c7037f2edbca89c, sequence creates the selected RUN child config with resource_contract equal to the SHA-bound sequence settings path. cohort_job_authority explicitly requires that same settings contract for an inner selected RUN. The selected original intent independently retains settings FileRef aee05236 and support FileRef 5eec625e. Original child config 07b5891a names the settings path, but abnormal_run_failure requires support.path. This is a definite failing metadata predicate in the old "closed original abnormal job/config/owner/argv/directwait join". It does not explain the preceding cycle memory_limit.

The private change is confined to abnormal_run_failure: choose the existing admitted settings FileRef when present, otherwise support; read its exact bound bytes with the existing read_ref; compare resource_contract to that reference's path. No producer or cohort contract changes. All original marker/canonical intent digest, independent original runtime/config/state/job identity, nonzero abnormal exit, stopped lifecycle/native, returned outer cleanup and duplicate checks remain. The returned facts remain FAILED/CANCELLED only, data FAILED, guardian unavailable, capture unproved and inner cleanup false/UNKNOWN.

Only this production function and one genuinely new test file change. The other 99 top-level definitions and all bytes outside this owner are exact. Reversing only the added contract-reference read and the comparison restores the whole owning AST. The common arena, node/RAM limits, rule/model/math, clock, origin/authority, cancellation, collection and final publication bodies are unchanged.

## What actually ran

One new NN0 definition passed once through the actual private abnormal_run_failure on synthetic fixture metadata and explicitly synthetic stopped identities. It checks selected settings and direct support contracts, preservation of CANCELLED/FAILED/UNKNOWN facts, refusal of a wrong contract even with an independently rebound synthetic config, bound-contract content drift refusal, and no candidate/finalizing/manifest creation. No lifecycle FINALIZE was called. No old successful definition, old operation, archive, saved row, model, QF1, head, native, Search or game was executed or requalified.

The actual test used the prepared Python 3.14 environment under a shared environment reader, with immutable snapshot/cycle sources preloaded in memory rather than importing live Main. Guardian wall: 0.16085624904371798 seconds once; nested unittest span is not added. Directwait/reap/handles/cleanup true, remaining []. The identities and process liveness in the metadata fixture are synthetic; this is neither real OS-fault qualification nor a current C normal-pipeline success.

Ruff used the actual project tools/research-quality/ruff.toml from immutable Git (100 columns, py311, F/E9). Only the changed owner snippet and new test were formatted; full private production/test F/E9 lint passed. Thin forward/inverse reconstruction uses zero fuzz/offset and restores the new test's original absence. Root alone may review and sparse-compose the changed owner after the relevant actual 29 source/fair lifetime STOP.

## Preserved historical limitation

Old 45a0/8ply/40 heads remain FAILED and NOT_DATA_VALIDATED. New 54b6583b used 2x4ply and 36 heads; its two PlyCap UNKNOWN rows were accepted separately as SAVED_DATA_VALIDATED via 25917195. The whole original job still has control_error, inner cancellation, operation INCOMPLETE, no operation manifest and no returned lifecycle guardian. No original FINALIZE or original validator was invoked here, no receipt or disk-mask fact was edited, and late empty-directory cleanup remains a separate fact.

Historical RSS, offending role, member snapshot, continuous peak and memory-limit cause are UNRECORDED/UNKNOWN. Current diagnostics already retain a bounded role/RSS/threshold/identity snapshot at the existing manual threshold and preserve exception notes. They can inform a future failure; neither this source repair nor the old native RSS report can reconstruct the missing historical observation. No RAM increase, OOM diagnosis, PID-regression diagnosis or accounting-policy change is proposed.

## Concrete preparation and minimum next factual check

connection-preparation.json retains original Build b588/image d0e, callback 0a34, C champion 821b, Cedar 35cbb/eb0, initial complete-history lineage and the genuine original four-head/math scopes by reference. Current source metadata c797/6749/3b21/ed08 plus helper c9a/head 6c89 come only from immutable b1e965ff. Eleven previously declared runtime-library references are carried by reference as a known subset, not a closed import/GPU-use proof; no payload rehash/import was done. Old numerical741 and original helper/head facts are not retargeted.

The unadmitted native config proposal retains both 5000ms whole-wall clocks, 5ms reserve, C8 simulations/9 heads per turn, original Cedar Control/PVS/depth_rank parameters/path_tail/TT1M/node1M/depth64 and CPU roles. Only run_id, new output path and proposed max_plies=1 differ from the retained 2x4ply template. Current Plan/Experiment/numerical/support/intent/job stay NULL. Nothing has been submitted.

If Root later issues the smallest real normal-connection check, the concrete target is ONE operation, two opposite-colour logical games, max1ply each (at most 2 total plies, one C turn and <=9 new C heads), no standalone probes. The proposal must still pass the genuine current native serializer/typed input admission; it is not itself a preflight or permission. Keep original 180/120+60 envelope and existing 4GiB including 1+3 without inflation. Fresh current source/artifact/callback/library/model/input/loader/Plan/Experiment/origin and physical/SMT/peer/RAM/output/cancel/cleanup bindings must be fixed at a compatible actual boundary after 29.

That minimal real check would observe actual Torch child/RSS/EOF/returned guardian and one complete normal publication lifetime. Synthetic metadata tests cannot observe those facts or prove model-startup resource behavior. Expected ply-cap UNKNOWN is functional coverage only, never full-game/WDL/strength qualification. Original unused head liability is not permission; this is a proposed separate amount, not an automatic continuation or retry. If no new numerical entry is issued, the concrete normal-pipeline limitation remains.

## Root handoff

No Main/Git/index/Cargo/docs/environment/model/image mutation; no author reviewer dispatch or source_clear/adoption claim. This source/config task does not gate 29, other parents or any human/Root ACK.

Only if Root judges the changed failure-admission boundary to need the existing Max: does using the admitted SHA-bound settings contract, while preserving independent original config/marker custody and failure-only output, maintain the intended provenance boundary for selected RUNs? No re-review of C math, old two tests, old numerical scopes or the arena protocol is needed.
