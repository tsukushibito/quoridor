"""Compose only the stopped selected-contract owner into current aspiration source."""

import ast
import fcntl
import hashlib
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/claustrophobia-arena-connection-v1/normal-readiness-v1"


def ref(p):
    b = p.read_bytes()
    return dict(
        path=str(p),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{stat.S_IMODE(p.stat().st_mode):04o}",
    )


def checked(w):
    p = Path(w["path"])
    assert ref(p) == w
    return p


def owner(source):
    node = next(
        x
        for x in ast.parse(source).body
        if isinstance(x, ast.FunctionDef) and x.name == "abnormal_run_failure"
    )
    lines = source.splitlines(keepends=True)
    start = sum(map(len, lines[: node.lineno - 1]))
    end = sum(map(len, lines[: node.end_lineno]))
    return start, end, source[start:end]


def main():
    packet_path = OWN / "packet.json"
    assert (
        ref(packet_path)["sha256"]
        == "9633cdc45f6243d1aa6b47cd1d8663bb78d43803d96ccf459ed7741e37b40808"
    )
    packet = json.loads(packet_path.read_bytes())
    binding = json.loads(checked(packet["binding"]).read_bytes())
    result = json.loads(checked(packet["new_test_result"]).read_bytes())
    assert (
        result["PASS"]
        and result["new_definitions_run"] == 1
        and result["native_model_head_Search_QF1_FINALIZE"] == 0
    )
    before = subprocess.check_output(
        ["git", "show", binding["base_commit"] + ":scripts/dev/research-lifecycle.py"], cwd=ROOT
    ).decode()
    old_owner = owner(before)[2]
    private = checked(binding["postimages"]["scripts/dev/research-lifecycle.py"]).read_text()
    new_owner = owner(private)[2]
    test = checked(
        binding["postimages"]["tools/research-session/test_selected_abnormal_contract.py"]
    )
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        path = ROOT / "scripts/dev/research-lifecycle.py"
        original_ref = ref(path)
        current = path.read_text()
        start, end, body = owner(current)
        assert body == old_owner
        combined = current[:start] + new_owner + current[end:]
        assert (
            combined[:start] == current[:start]
            and combined[start + len(new_owner) :] == current[end:]
        )
        before_ast = ast.parse(current)
        after_ast = ast.parse(combined)
        for tree in [before_ast, after_ast]:
            tree.body = [
                x
                for x in tree.body
                if not isinstance(x, ast.FunctionDef) or x.name != "abnormal_run_failure"
            ]
        assert ast.dump(before_ast, include_attributes=False) == ast.dump(
            after_ast, include_attributes=False
        )
        destination = ROOT / "tools/research-session/test_selected_abnormal_contract.py"
        assert not destination.exists()
        path.write_text(combined)
        destination.write_bytes(test.read_bytes())
        destination.chmod(0o644)
        assert owner(path.read_text())[2] == new_owner
        assert ref(destination) | {"path": str(test)} == ref(test)
        subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
        receipt = dict(
            status="SPARSE_ABNORMAL_CONTRACT_OWNER_ADOPTED_SOURCE_ONLY",
            issue="quoridor-4lc.324.16.1",
            packet=ref(packet_path),
            before=original_ref,
            actual=ref(path),
            test=ref(destination),
            changed_owner="abnormal_run_failure",
            all_other_current_source_bytes_AST_exact=True,
            exact_owner_matches_passed_NN0_definition=True,
            reused_new_test=packet["new_test_result"],
            no_old_or_new_test_replay=True,
            no_Cargo_native_model_head_game_FINALIZE=True,
            source="Preserves current29 aspiration plus Half retirement, no wholeoldpost overwrite",
            normal_pipeline_PASS=False,
            historical_memory_cause="UNKNOWN",
            future2ply9heads="PROPOSAL_ONLY_UNISSUED",
            source_STOP="Separate actual guard returned receipt; no futurehostquiet",
        )
        with (OUT / "actual-adoption.json").open("x") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")
        print(json.dumps(dict(status=receipt["status"], other_current_owners_preserved=True)))


if __name__ == "__main__":
    main()
