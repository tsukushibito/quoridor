"""Apply the source-reviewed sparse composition with its exact one-field repair."""

import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
FIXED = OUT.parent / "r1-factory-repair-v1/binding.json"


def ref(path):
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def check(witness):
    path = Path(witness["path"])
    assert ref(path) == witness
    return path


def patch(directory, witness):
    result = subprocess.run(
        ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(check(witness))],
        cwd=directory,
        capture_output=True,
        text=True,
        check=True,
    )
    assert "offset" not in result.stdout.lower() and "fuzz" not in result.stdout.lower()
    return result.stdout


def main():
    assert (
        ref(FIXED)["sha256"] == "5bff7fde3cf0c5daee7f33297bf010da31ee1cf47ce7ef6027a8cf43e4f0fc3c"
    )
    fixed = json.loads(FIXED.read_bytes())
    original = json.loads(check(fixed["original_binding"]).read_bytes())
    subjects = original["subjects"]
    for row in subjects:
        if row["path"] == fixed["override_subject"]["path"]:
            row["post"] = fixed["override_subject"]["post"]
        check(row["post"])
        if row["before"]:
            check(row["before"])
    acceptance = OUT.parent / "r1-factory-repair-v1/Root-source-acceptance.json"
    assert json.loads(acceptance.read_bytes())["status"] == "ACCEPTED_SOURCE_ONLY"
    assert subprocess.check_output(["git", "diff", "--name-only"], cwd=ROOT) == b""
    assert subprocess.check_output(["git", "diff", "--cached", "--name-only"], cwd=ROOT) == b""
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for row in subjects:
            p = ROOT / row["path"]
            if row["before"]:
                assert ref(p) | {"path": row["before"]["path"]} == row["before"]
            else:
                assert not p.exists()
        temporary = OUT / "patch-TMP"
        temporary.mkdir()
        for row in subjects:
            if row["before"]:
                p = temporary / row["path"]
                p.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(row["before"]["path"], p)
                p.chmod(int(row["before"]["mode"], 8))
        logs = []
        for witness in fixed["canonical_forward_sequence"]:
            logs.append(patch(temporary, witness))
        for row in subjects:
            assert ref(temporary / row["path"]) | {"path": row["post"]["path"]} == row["post"]
        for witness in fixed["canonical_inverse_sequence"]:
            logs.append(patch(temporary, witness))
        for row in subjects:
            p = temporary / row["path"]
            if row["before"]:
                assert ref(p) | {"path": row["before"]["path"]} == row["before"]
            else:
                assert not p.exists()
        shutil.rmtree(temporary)
        for witness in fixed["canonical_forward_sequence"]:
            logs.append(patch(ROOT, witness))
        for row in subjects:
            assert ref(ROOT / row["path"]) | {"path": row["post"]["path"]} == row["post"]
        subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
        receipt = dict(
            status="SPARSE_MAIN_SOURCE_ADOPTED_NEW_SOFTWARE_PENDING",
            issue="quoridor-4lc.324.29",
            fixed_binding=ref(FIXED),
            source_review_acceptance=ref(acceptance),
            canonical_before_git=original["canonical_before_git"],
            actual_before_head=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
            ).strip(),
            subjects=[
                dict(subject=x["path"], before=x["before"], actual=ref(ROOT / x["path"]))
                for x in subjects
            ],
            GNU_forward_inverse_fuzz0_nooffset_allbytes_modes=logs,
            software="AI3/RunnerLIB2/Python1 UNBUILT_UNTYPED_UNRUN; no test/compiler/native/model/RAW/RNG",
            source_STOP="Actual adoption guard returns separately; no native/source reader or futurehostquiet",
            TMP=[],
            owned_remaining=[],
        )
        with (OUT / "actual-adoption.json").open("x") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")
        print(json.dumps(dict(status=receipt["status"], subjects=len(subjects), Main_applied=True)))


if __name__ == "__main__":
    main()
