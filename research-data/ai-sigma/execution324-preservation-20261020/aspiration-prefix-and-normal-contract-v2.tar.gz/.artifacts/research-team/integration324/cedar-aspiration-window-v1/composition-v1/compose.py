"""Compose two fixed sparse subjects with standard git three-way text merging."""

import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
ASP = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1/fixed-source-v1/binding.json"
RET = (
    ROOT
    / ".worktree/assets/perf/cedar-shallow-main-history-v1/corrected-entry-trial-v1/half-retirement-v1"
)


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def main():
    assert ref(ASP)["sha256"] == "2a899977c5196bc2a1becb129a5c41367622cfdef69a581ba37d3e6f2dc9d984"
    assert (
        ref(RET / "binding.json")["sha256"]
        == "72f00524ace92ec1f817920f3c5df4c5e29df2eb4b6cbbe178c88a173c587bba"
    )
    asp = json.loads(ASP.read_bytes())
    ret = json.loads((RET / "binding.json").read_bytes())
    asp_rows = {row["path"]: row for row in asp["subjects"]}
    ret_rows = {row["path"]: row for row in ret["post"]}
    ret_before = {row["path"]: row for row in ret["before"]}
    git = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    assert git == "b1e965ffa7054dab9aff5c6c8c7037f2edbca89c"
    results = []
    for subject in sorted(set(asp_rows) | set(ret_rows)):
        a = asp_rows.get(subject)
        b = ret_rows.get(subject)
        before = a["before"] if a else ret_before[subject]
        current = ROOT / subject
        if before is None:
            assert not current.exists()
            base = b""
        else:
            base = subprocess.check_output(["git", "show", f"{git}:{subject}"], cwd=ROOT)
            assert hashlib.sha256(base).hexdigest() == before["sha256"]
            assert current.read_bytes() == base
        if a and b:
            assert a["before"]["sha256"] == ret_before[subject]["sha256"]
        before_path = OUT / "before" / subject
        before_path.parent.mkdir(parents=True, exist_ok=True)
        before_path.write_bytes(base)
        a_path = Path(a["post"]["path"]) if a else before_path
        b_path = RET / "post" / subject if b else before_path
        if a:
            assert ref(a_path) == a["post"]
        if b:
            row = ref(b_path)
            assert all(row[k] == b[k] for k in ("sha256", "bytes", "mode"))
        result = subprocess.run(
            [
                "git",
                "merge-file",
                "-p",
                "--diff3",
                "-L",
                "aspiration",
                "-L",
                "current",
                "-L",
                "retired-half",
                str(a_path),
                str(before_path),
                str(b_path),
            ],
            cwd=ROOT,
            capture_output=True,
            check=False,
        )
        assert 0 <= result.returncode < 128, (subject, result.returncode, result.stderr)
        destination = OUT / "post" / subject
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as stream:
            stream.write(result.stdout)
        os.chmod(destination, 0o644)
        results.append(
            dict(
                subject=subject,
                before=ref(before_path),
                aspiration=ref(a_path) if a else None,
                retirement=ref(b_path) if b else None,
                merged=ref(destination),
                returncode=result.returncode,
                conflict_markers=result.stdout.count(b"<<<<<<< aspiration"),
            )
        )
    record = dict(
        status="UNFIXED_PRIVATE_COMPOSITION_NO_MAIN_ADOPTION_REVIEW_SOFTWARE",
        canonical_git=git,
        aspiration_binding=ref(ASP),
        retirement_binding=ref(RET / "binding.json"),
        algorithm="git merge-file --diff3, common validated immutable/current source; no Main/index writes or whole old postimage overwrite",
        subjects=results,
        source_review_compiler_tests_native_RNG=0,
    )
    with (OUT / "merge-intake.json").open("x") as stream:
        json.dump(record, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            dict(
                subjects=len(results),
                conflicts=[
                    dict(subject=x["subject"], blocks=x["conflict_markers"])
                    for x in results
                    if x["returncode"]
                ],
            )
        )
    )


if __name__ == "__main__":
    main()
