"""Run only the new replacement-boundary test/lint prefix using maintained software guards.

This stopped prefix is not a BUILD manifest or an executable qualification.
"""

import argparse
import datetime
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path("/workspaces/quoridor")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--intent", required=True)
    parser.add_argument("--sha256", required=True)
    args = parser.parse_args()
    loader = importlib.util.spec_from_file_location(
        "actual_prefix_software", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    spec_ref = lc.artifact_ref(args.intent)
    assert spec_ref["sha256"] == args.sha256
    spec = lc.document(spec_ref)
    runtime = Path(os.environ["QUORIDOR_RESEARCH_JOB_DIR"])
    state = json.loads((runtime / "state.json").read_bytes())
    cfg = json.loads((runtime / "config.json").read_bytes())
    assert state["supervisor"]["pid"] == os.getppid() and lc.process.alive(state["supervisor"])
    assert cfg["argv"] == [
        sys.executable,
        "-B",
        str(Path(__file__).resolve()),
        "--intent",
        args.intent,
        "--sha256",
        args.sha256,
    ]
    assert cfg["cwd"] == spec["cwd"] and state["config_sha256"] == lc.sha(
        json.dumps(cfg, sort_keys=True).encode()
    )
    assert cfg["max_runtime_seconds"] >= spec["command_timeout_seconds"] + 60
    started = time.monotonic()
    out = Path(spec["output"])
    assert not out.exists()
    result = dict(
        status="UNKNOWN",
        checks=[],
        primary=None,
        cleanup_complete=False,
        intent=spec_ref,
        origin_job_id=state["job_id"],
        origin_supervisor=state["supervisor"],
        release_executed=False,
    )
    lc.physical_and_quiet(spec)
    with lc.lease():
        lc.build_check(spec)
        resources = lc.Limits(spec)
        resources.deadline = started + spec["command_timeout_seconds"]
        out.mkdir()
        temporary = Path(spec["TMP"])
        temporary.mkdir()
        try:
            for tool in spec["tools"].values():
                lc.read_ref(tool["file"], max(lc.CONTROL_BYTES, tool["file"]["bytes"]))
            commands = [row for row in spec["commands"] if row["role"] != "build"]
            assert len(commands) == 7 and sum(row["role"] == "test" for row in commands) == 5
            for row in commands:
                _, full = lc.command(spec, row, out, resources, ledger=result["checks"])
                result["checks"][-1]["cargo"] = lc.cargo_report(full.read_bytes())
                if row["role"] == "test":
                    selector = row["argv"][row["argv"].index("--lib") + 1]
                    saved = full.read_text()
                    assert (
                        "running 1 test" in saved
                        and f"test {selector} ... ok" in saved
                        and "test result: ok. 1 passed; 0 failed" in saved
                    )
            lc.source_check(spec["source"])
            temporary.rmdir()
            result.update(
                status="PASS_TEST_LINT_PREFIX_ONLY", cleanup_complete=True, source_leases=[], TMP=[]
            )
        except BaseException as error:
            result.update(status="FAILED", primary=lc.error_fact(error))
            raise
        finally:
            result.update(
                finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                wall_seconds=time.monotonic() - started,
            )
            with (out / "prefix-result.json").open("x") as stream:
                json.dump(result, stream, indent=2)
                stream.write("\n")
            print(
                json.dumps(
                    dict(
                        status=result["status"],
                        checks=[dict(name=x["name"], status=x["status"]) for x in result["checks"]],
                        release_executed=False,
                    )
                )
            )


if __name__ == "__main__":
    main()
