"""Fix only the missing native worker factory field in the fixed private target."""

import difflib
import hashlib
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PARENT = OUT.parent / "composition-v1/binding.json"
SUBJECT = "crates/quoridor-ai/src/lazy_smp.rs"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def save(name, value):
    p = OUT / name
    with p.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(p)


def main():
    assert (
        ref(PARENT)["sha256"] == "a3e8d74f5e10e3028added36ef0f419a2e06320f5118bf01b091a7ddcd487874"
    )
    parent = json.loads(PARENT.read_bytes())
    row = next(x for x in parent["subjects"] if x["path"] == SUBJECT)
    before_path = Path(row["post"]["path"])
    assert ref(before_path) == row["post"]
    before = before_path.read_bytes()
    anchor = b"    fn fork_worker(&self, shared: Arc<SharedTable>, writer: usize) -> Result<Self> {\n        Ok(Self {\n            namespace: self.namespace.clone(),\n"
    assert before.count(anchor) == 1
    after = before.replace(anchor, anchor + b"            aspiration: None,\n", 1)
    path = OUT / "post" / SUBJECT
    path.parent.mkdir(parents=True)
    path.write_bytes(after)
    path.chmod(0o644)
    subprocess.run(
        [
            "/usr/local/cargo/bin/rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            str(path),
        ],
        check=True,
    )
    subprocess.run(
        [
            "/usr/local/cargo/bin/rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            "--check",
            str(path),
        ],
        check=True,
    )
    assert path.read_bytes() == after
    patches = []
    for name, old, new in [("forward.patch", before, after), ("inverse.patch", after, before)]:
        patch = "".join(
            difflib.unified_diff(
                old.decode().splitlines(keepends=True),
                new.decode().splitlines(keepends=True),
                fromfile="a/" + SUBJECT,
                tofile="b/" + SUBJECT,
            )
        )
        p = OUT / name
        p.write_text(patch)
        patches.append(ref(p))
    temporary = OUT / "patch-TMP"
    dest = temporary / SUBJECT
    dest.parent.mkdir(parents=True)
    dest.write_bytes(before)
    dest.chmod(0o644)
    outputs = []
    for patch, expected in zip(patches, [after, before]):
        result = subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "-i", patch["path"]],
            cwd=temporary,
            check=True,
            capture_output=True,
            text=True,
        )
        assert "offset" not in result.stdout.lower() and "fuzz" not in result.stdout.lower()
        assert dest.read_bytes() == expected and stat.S_IMODE(dest.stat().st_mode) == 0o644
        outputs.append(result.stdout)
    dest.unlink()
    for directory in sorted(temporary.rglob("*"), key=lambda p: len(p.parts), reverse=True):
        assert directory.is_dir()
        directory.rmdir()
    temporary.rmdir()
    proof = save(
        "incremental-proof.json",
        dict(
            subject=SUBJECT,
            only_change="fork_worker Self literal adds aspiration: None",
            delta_lines=1,
            outside_bytes_exact=True,
            rustfmt="PASS",
            GNU_forward_inverse_fuzz0_nooffset_roundtrip=outputs,
            unchanged_other12_posts="Parent FileRefs reused, not copied or reproved",
            Main_adoption=False,
            compiler_tests_native_model_RAW_RNG=0,
        ),
    )
    binding = save(
        "binding.json",
        dict(
            status="FIXED_R1_PRIVATE_SOURCE_ONLY_UNBUILT_UNTYPED_UNRUN",
            original_binding=ref(PARENT),
            original_source_verdict="SOURCE_NOT_CLEAR essential1 ordinary0; 38a359f9 retained",
            override_subject=dict(path=SUBJECT, before=row["post"], post=ref(path)),
            unchanged_other12_subjects="Exactly original a3e8d74f post FileRefs",
            canonical_before_git=parent["canonical_before_git"],
            canonical_forward_sequence=[parent["forward"], patches[0]],
            canonical_inverse_sequence=[patches[1], parent["inverse"]],
            proof=proof,
            semantics="Native factory explicitly seeds no aspiration. Existing LOCAL1 search refusal and setter qualifications unchanged; no API/algorithm/namespace/worker behavior change beyond required field initialization.",
            software="Original new AI3/RunnerLIB2/Python1 all UNBUILT_UNTYPED_UNRUN; no added test or old-suite replay",
            source_STOP="Separate actual repair guard returned receipt; no Main lease or host futurequiet",
        ),
    )
    print(json.dumps(dict(binding=binding, post=ref(path), Main_adoption=False)))


if __name__ == "__main__":
    main()
