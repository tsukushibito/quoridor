"""Resolve enumerated adjacent deletion/addition overlaps without changing kernels."""

import json
from pathlib import Path
import re
import shutil

OUT = Path(__file__).resolve().parent
pattern = re.compile(
    r"^<<<<<<< aspiration\n(.*?)^\|\|\|\|\|\|\| current\n(.*?)^=======\n(.*?)^>>>>>>> retired-half\n",
    re.M | re.S,
)
records = []
for path in sorted((OUT / "post").rglob("*")):
    if not path.is_file():
        continue
    text = path.read_text()
    matches = list(pattern.finditer(text))
    if not matches:
        continue
    backup = OUT / "conflicted-input" / path.relative_to(OUT / "post")
    backup.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, backup)
    replacements = []
    for index, match in enumerate(matches, 1):
        a, base, b = match.groups()
        owner = str(path.relative_to(OUT / "post"))
        if not b:
            assert base and a.count(base) == 1, (owner, index)
            resolved = a.replace(base, "", 1)
            reason = "Remove exactly retired base block; retain adjacent aspiration-only addition"
        elif owner == "scripts/dev/research-lifecycle.py" and index == 4:
            assert '    if "shallow_main_history" in config:' in a
            assert b.strip().startswith("raw_refs =")
            resolved = a.split('    if "shallow_main_history" in config:', 1)[0] + b
            reason = "Keep aspiration evidence check and its config load; retain original raw-ref owner after half evidence removal"
        elif owner == "scripts/dev/research-lifecycle.py" and index == 5:
            start = a.index("        resolved_root_aspiration(")
            end = a.index("        resolved_shallow_main_history(", start)
            guard = (
                '        require("shallow_main_history" not in engine, "retired arena setting")\n'
            )
            assert b.count(guard) == 1
            resolved = b.replace(guard, a[start:end] + guard, 1)
            reason = "Keep original unused-Claus check, new aspiration validation, and retired-setting refusal"
        elif owner == "scripts/dev/research-lifecycle.py" and index in (6, 7):
            assert "root_aspiration" not in a and "root_aspiration" not in base
            resolved = b
            reason = "Only old half comparison/effective policy predicates and formatting overlap; retain retirement result"
        else:
            raise AssertionError((owner, index))
        replacements.append((match.start(), match.end(), resolved))
        records.append(dict(subject=owner, block=index, reason=reason))
    for start, end, replacement in reversed(replacements):
        text = text[:start] + replacement + text[end:]
    assert not pattern.search(text) and "<<<<<<< aspiration" not in text
    path.write_text(text)
with (OUT / "resolution-record.json").open("x") as stream:
    json.dump(
        dict(
            status="PRIVATE_RESOLVED_UNFORMATTED_UNREVIEWED_UNRUN",
            blocks=records,
            no_Main_Git_Cargo_write=True,
            compiler_tests_native_RNG=0,
        ),
        stream,
        indent=2,
    )
    stream.write("\n")
print(json.dumps(dict(resolved_blocks=len(records), Main_adoption=False)))
