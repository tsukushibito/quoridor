"""Preserve stopped source and software-prefix evidence without replaying research."""

import importlib.util
import json
import re
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OPS = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    loader = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    old = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(old)
    bases = [
        OWN,
        ROOT / ".worktree/assets/perf/cedar-aspiration-window-review-v1",
        ROOT
        / ".worktree/assets/perf/cedar-shallow-main-history-v1/corrected-entry-trial-v1/half-retirement-v1",
        ROOT / ".worktree/assets/perf/claustrophobia-arena-connection-v1/normal-readiness-v1",
        ROOT
        / ".artifacts/research-team/integration324/claustrophobia-arena-connection-v1/normal-readiness-adoption-v1",
    ]
    bases += [
        OPS / name
        for name in ["composition-v1", "r1-factory-repair-v1", "adoption-v1", "caller-adoption-v1"]
    ]
    files = []
    for base in bases:
        assert base.is_dir() and not base.is_symlink()
        files.extend(old.files_below(base))
    # The original failed software is closed. The passed-prefix folder is closed;
    # the genuine release currently running in software-v2 is outside selection.
    files.extend(old.files_below(OPS / "software-v1"))
    files.extend(old.files_below(OPS / "software-v2/operation-prefix"))
    files.extend(old.files_below(OPS / "software-v2/prefix-collection-v1"))
    for name in [
        "build-intent-prefix.json",
        "build-source-adoption-prefix.json",
        "resources-prefix.json",
        "target-handover-prefix.json",
        "actual-foreign-source-prefix.patch",
        "job-prefix.bound.json",
        "original-prefix-submit-v1.json",
    ]:
        files.append(OPS / "software-v2" / name)
    for name in [
        "source-review-intake-v1.json",
        "representation-amendment-intake.json",
        "review-normal-closure-intake.json",
        "ordinary-Root-source-save-point-v1.json",
        "source-review-task.txt",
        "source-review-delivery.json",
        "caller-repair-task.txt",
        "caller-repair-delivery.json",
    ]:
        files.append(OPS / name)
    files += [OUT / "preserve_v2.py", OUT / "run_guard_v2.py"]
    forbidden = {
        ".onnx",
        ".pt",
        ".pth",
        ".safetensors",
        ".f32",
        ".bin",
        ".so",
        ".npz",
        ".npy",
        ".pem",
        ".key",
        ".lock",
        ".rlib",
        ".rmeta",
        ".o",
        ".a",
    }
    selected = []
    for p in sorted(set(files)):
        lower = p.name.lower()
        if p.suffix in {".json", ".log"} and re.search(
            r"(^|[-_/])(ready|show|update|beads|backup|notes?|admin)([-_./]|$)",
            str(p.relative_to(ROOT)).lower(),
        ):
            continue
        # Task tracking is the shared Beads store, not a published copy of its
        # snapshots/full note stdout. Fixed result/control receipts stay included.
        if any(x in lower for x in ["beads", "backup"]) or lower.startswith(
            ("ready", "show", "update", "note", "admin-", "root-delivery")
        ):
            continue
        if any(
            part.startswith(
                ("return-guard", "root-delivery", "result-root-delivery", "actual-root-delivery")
            )
            for part in p.parts
        ):
            continue
        assert not p.is_symlink() and p.is_file() and not old.excluded(p)
        assert p.suffix not in forbidden and not any(
            x in {".git", ".beads", ".beads-state", "target", "node_modules"} for x in p.parts
        )
        assert p.stat().st_size <= 8 * 1024**2, p
        selected.append(p)
    old.DEST = DEST
    name = "aspiration-prefix-and-normal-contract-v2.tar.gz"
    old.write_archive(
        name,
        selected,
        "Stopped fixed aspiration/Half retirement source and strict composition/R1/caller repair, original source negative and failed compiler prefix, accepted newAI3/RunnerLIB2/affectedClippy + priorPython1, frozen208/conditional128 config/protocol metadata, and ordinary16.1 selected-settings contract repair/newNN0. Genuine release/currentBuild/image/numeric208/128 are NOT qualified by this archive. No model/libs/ELF/cache/DB/sealed payload, no scientific source/RAW/model/native/RNG/validator/test replay.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    prefix = json.loads((OPS / "software-v2/operation-prefix/prefix-result.json").read_bytes())
    assert prefix["status"] == "PASS_TEST_LINT_PREFIX_ONLY" and len(prefix["checks"]) == 7
    summary = dict(
        issue="quoridor-4lc.324.29",
        status="ACCEPTED_NEW_TEST_LINT_PREFIX_ONLY",
        new_AI_tests=3,
        new_Runner_LIB_tests=2,
        required_running_each=1,
        affected_Clippy_packages=2,
        warnings=0,
        prior_Python1="PASS retained, not replayed",
        original_compiler_failure="9a6d27bf FAILED before newtest entry; original source38a359f9 negative and R1-only7a7574c9 sourceclear separately retained",
        caller_repair="8a73f66d, 3aspirationNone +6constfalse/full-window callsites; no newtest definition or oldsuite replay",
        normal16_1="Ordinary abnormal_run_failure selectedsettings else support contract source and one new synthetic NN0PASS; canonical namedowner only, historicalmemorycauseUNKNOWN/wholepipelineINCOMPLETE; new2ply9heads remainsunissued",
        scope="Current-only100%/aspirationOFF versus .125/2/D3/4, original2673 protocol preserved; NEW208/208M and conditional128/2.048G unentered as of this prefix packet",
        genuine_release="Separate active job3e17722b; no BUILD/image/sciencePASS inferred from acceptance",
        archive=dict(
            path=name,
            sha256=manifest["sha256"],
            bytes=manifest["bytes"],
            manifest=name + ".manifest.json",
            members=len(manifest["members"]),
            full_stream_restore_hash_mode_verified=True,
        ),
        fees_globalactual="UNKNOWN; saved bounded wall scopes preserved without nested addition",
    )
    with (DEST / "aspiration-prefix-and-normal-contract-v2.json").open("x") as stream:
        json.dump(summary, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            dict(
                archive=name,
                bytes=manifest["bytes"],
                members=len(manifest["members"]),
                logical_B=manifest["original_logical_B"],
                genuine_release_or_science_qualified=False,
            )
        )
    )


if __name__ == "__main__":
    main()
