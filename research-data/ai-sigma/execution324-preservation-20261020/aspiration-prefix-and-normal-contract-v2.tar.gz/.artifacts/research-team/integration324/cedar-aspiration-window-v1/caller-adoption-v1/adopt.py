"""Adopt only the causal caller plumbing after the original failed compiler STOP."""

import fcntl
import hashlib
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BINDING = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1/caller-repair-v1/binding.json"


def ref(path):
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def main():
    assert (
        ref(BINDING)["sha256"] == "8a73f66d77da93d25d3804ce9bb9a317ae9169237ab813863ffe30000bb26555"
    )
    binding = json.loads(BINDING.read_bytes())
    stop = OUT.parent / "software-v1/original-failure-and-actual-source-STOP.json"
    assert not json.loads(stop.read_bytes())["scientific_entry"]
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for row in binding["subjects"]:
            actual = ref(ROOT / row["path"])
            actual.pop("path")
            assert actual == row["before"]
            assert ref(Path(row["post"]["path"])) == row["post"]
        patch = binding["forward"]
        assert ref(Path(patch["path"])) == patch
        result = subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "-i", patch["path"]],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        assert "offset" not in result.stdout.lower() and "fuzz" not in result.stdout.lower()
        for row in binding["subjects"]:
            assert ref(ROOT / row["path"]) | {"path": row["post"]["path"]} == row["post"]
        subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
        old = json.loads((OUT.parent / "adoption-v1/actual-adoption.json").read_bytes())
        paths = (
            [row["subject"] for row in old["subjects"]]
            + [row["path"] for row in binding["subjects"]]
            + ["tools/research-session/test_selected_abnormal_contract.py"]
        )
        subjects = [dict(subject=p, actual=ref(ROOT / p)) for p in paths]
        receipt = dict(
            status="SPARSE_MAIN_SOURCE_ADOPTED_NEW_SOFTWARE_PENDING",
            issue="quoridor-4lc.324.29",
            subjects=subjects,
            initial_composition_adoption=ref(OUT.parent / "adoption-v1/actual-adoption.json"),
            caller_repair_binding=ref(BINDING),
            ordinary_selected_contract_adoption=ref(
                ROOT
                / ".artifacts/research-team/integration324/claustrophobia-arena-connection-v1/normal-readiness-adoption-v1/actual-adoption.json"
            ),
            actual_failed_software_STOP=ref(stop),
            only_new_caller_semantics="Three aspirationNone diagnostic/trial and six constfalse full-window callers; assertions/fixtures unchanged",
            GNU_forward_fuzz0_nooffset=result.stdout,
            prior_Python1="ActualPASS retained; resolved_root_aspiration/config and test bytes unchanged; no replay",
            remaining="AI3/RunnerLIB2/newRust tests unentered; affectedClippy/release unentered; no native/model/RAW/RNG",
            source_STOP="Separate actual guard return, no Main lease or futurehostquiet",
        )
        with (OUT / "actual-adoption.json").open("x") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")
        print(
            json.dumps(
                dict(status=receipt["status"], current_subjects=len(subjects), caller_subjects=7)
            )
        )


if __name__ == "__main__":
    main()
