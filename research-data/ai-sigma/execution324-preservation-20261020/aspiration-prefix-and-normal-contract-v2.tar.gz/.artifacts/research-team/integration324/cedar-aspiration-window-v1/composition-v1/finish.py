"""Format the exact composed subjects and bind the unrun related-review target."""

import ast
import difflib
import hashlib
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
RUFF = "/home/vscode/.cache/inference/envs/quoridor-training/bin/ruff"
CONFIG = ROOT / "tools/research-quality/ruff.toml"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def functions(text):
    lines = text.splitlines(keepends=True)
    rows = {}
    for node in ast.parse(text).body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            first = min([node.lineno] + [d.lineno for d in node.decorator_list]) - 1
            rows[node.name] = (first, node.end_lineno, "".join(lines[first : node.end_lineno]))
    return rows


def main():
    intake = json.loads((OUT / "merge-intake.json").read_bytes())
    for row in intake["subjects"]:
        path = OUT / "post" / row["subject"]
        assert "<<<<<<< aspiration" not in path.read_text()
        if path.suffix == ".rs":
            subprocess.run(
                [
                    "/usr/local/cargo/bin/rustfmt",
                    "--edition",
                    "2024",
                    "--config",
                    "skip_children=true",
                    str(path),
                ],
                check=True,
            )
            subprocess.run(
                [
                    "/usr/local/cargo/bin/rustfmt",
                    "--edition",
                    "2024",
                    "--config",
                    "skip_children=true",
                    "--check",
                    str(path),
                ],
                check=True,
            )
    lc = OUT / "post/scripts/dev/research-lifecycle.py"
    original = lc.read_text()
    before = (OUT / "before/scripts/dev/research-lifecycle.py").read_text()
    before_functions = functions(before)
    old_functions = functions(original)
    changed = {
        name
        for name, row in old_functions.items()
        if name not in before_functions or row[2] != before_functions[name][2]
    }
    temp = OUT / "formatted-lifecycle.py"
    temp.write_text(original)
    subprocess.run(
        [RUFF, "format", "--config", str(CONFIG), "--line-length", "100", str(temp)], check=True
    )
    formatted = functions(temp.read_text())
    lines = original.splitlines(keepends=True)
    for name in sorted(changed, key=lambda n: old_functions[n][0], reverse=True):
        start, end, _ = old_functions[name]
        lines[start:end] = [formatted[name][2]]
    composed = "".join(lines)
    assert ast.dump(ast.parse(composed), include_attributes=False) == ast.dump(
        ast.parse(original), include_attributes=False
    )
    final_functions = functions(composed)
    protected = []
    for name in set(before_functions) & set(final_functions) - changed:
        assert final_functions[name][2] == before_functions[name][2], name
        protected.append(name)
    lc.write_text(composed)
    subprocess.run(
        [RUFF, "check", "--config", str(CONFIG), "--line-length", "100", str(lc)], check=True
    )
    test = OUT / "post/scripts/dev/test_root_aspiration.py"
    subprocess.run([RUFF, "format", "--config", str(CONFIG), str(test)], check=True)
    subprocess.run([RUFF, "format", "--check", "--config", str(CONFIG), str(test)], check=True)
    subprocess.run([RUFF, "check", "--config", str(CONFIG), str(test)], check=True)
    subjects = []
    forward = []
    inverse = []
    for row in intake["subjects"]:
        name = row["subject"]
        before_path = OUT / "before" / name
        post = OUT / "post" / name
        old = before_path.read_text()
        new = post.read_text()
        existed = (ROOT / name).exists()
        before_label = "a/" + name if existed else "/dev/null"
        post_label = "b/" + name
        forward.extend(
            difflib.unified_diff(
                old.splitlines(True), new.splitlines(True), before_label, post_label
            )
        )
        inverse.extend(
            difflib.unified_diff(
                new.splitlines(True),
                old.splitlines(True),
                "a/" + name,
                "b/" + name if existed else "/dev/null",
            )
        )
        subjects.append(
            dict(path=name, before=ref(before_path) if existed else None, post=ref(post))
        )
    for name, body in (("forward.patch", forward), ("inverse.patch", inverse)):
        with (OUT / name).open("x") as stream:
            stream.write("".join(body))
    record = dict(
        status="FIXED_PRIVATE_COMPOSED_SOURCE_ONLY_UNREVIEWED_UNBUILT_UNTYPED_UNRUN",
        canonical_before_git=intake["canonical_git"],
        aspiration_binding=intake["aspiration_binding"],
        retirement_binding=intake["retirement_binding"],
        subjects=subjects,
        forward=ref(OUT / "forward.patch"),
        inverse=ref(OUT / "inverse.patch"),
        resolution=ref(OUT / "resolution-record.json"),
        formatting=dict(
            Rust="scoped rustfmt/check edition2024 skip_children",
            Python="LC changed named owners Ruff100/parserAST unchanged, all other existing owners protected; new test scoped Ruff",
            LC_changed_owners=sorted(changed),
            LC_other_functions_byte_exact=sorted(protected),
        ),
        main_adoption=False,
        compiler_tests_native_model_RAW_RNG=0,
        required_review="New root aspiration+exact half deletion interactions/namespace/reset/typed consumers and fatalErr stats boundary; no other source audit",
        source_STOP="Final bounded finishing guard returned separately, no Mainlease; no host futurequiet",
    )
    with (OUT / "binding.json").open("x") as stream:
        json.dump(record, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            dict(
                binding=ref(OUT / "binding.json"),
                subjects=len(subjects),
                LC_changed=sorted(changed),
                LC_protected=len(protected),
                software_native="UNRUN",
            )
        )
    )


if __name__ == "__main__":
    main()
