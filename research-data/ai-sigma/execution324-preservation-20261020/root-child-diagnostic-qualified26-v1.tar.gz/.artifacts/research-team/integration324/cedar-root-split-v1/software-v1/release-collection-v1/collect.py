"""Finalize the original diagnostic release once and settle its stopped cache."""

import datetime
import importlib.util
import json
from pathlib import Path
import shutil

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helpers = load(
        "prefix_helpers",
        Path(
            "/workspaces/quoridor/.artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py"
        ),
    )
    lc = load("current_release", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helpers.ref
    runtime = BASE / "build-runtime-v2"
    outer_path = runtime / "result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((runtime / "state.json").read_bytes())
    operation = BASE / "operation-release"
    candidate_path = operation / "candidate.json"
    candidate_ref = ref(candidate_path)
    candidate = json.loads(candidate_path.read_bytes())
    intent = json.loads(helpers.checked(candidate["intent"]).read_bytes())
    submit = json.loads((BASE / "original-release-submit-v1.json").read_bytes())
    assert outer["job_id"] == json.loads(submit["stdout"])["job_id"]
    assert outer["outcome"] == "succeeded" and outer["exit_code"] == 0
    assert (
        outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and not outer["remaining"]
    )
    assert candidate["status"] == "PENDING_FINALIZATION"
    assert candidate["cleanup_complete"] and candidate["process_cleanup_complete"]
    assert not candidate["remaining"] and not candidate["owed_finalizers"]
    known = []
    builds = []
    for check in candidate["checks"]:
        assert check["status"] == "PASS" and check["capture_complete"]
        assert not check["primary"] and not check["secondary"]
        helpers.checked(check["full_log"])
        record = check["guardian_return"]
        lc.settled(record)
        assert record["handle_closes_complete"]
        member = record["child"]
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(name=check["name"], original=member, fresh=fresh))
        if check["role"] == "build":
            builds.append(check)
    assert (
        len(builds) == 1
        and builds[0]["name"] == "root-child-diagnostic-genuine-release"
    )
    cargo = lc.cargo_report(Path(builds[0]["full_log"]["path"]).read_bytes())
    assert cargo["warning_count"] == 0
    artifact = [
        a
        for a in cargo["artifacts"]
        if a["target"]["name"] == "quoridor-runner"
        and a["target"]["kind"] == ["bin"]
        and not a["profile"]["test"]
    ]
    assert (
        len(artifact) == 1
        and artifact[0] == candidate["cargo_artifact"]
        and artifact[0]["fresh"] is False
    )
    member = state["child"]
    fresh = lc.process.identity(lc.process.process_info(member["pid"]))
    assert fresh != lc.process.identity(member)
    known.append(dict(name="lifecycle child", original=member, fresh=fresh))
    manifest = lc.finalize(operation, ref(outer_path))
    assert (
        manifest["status"] == "PASS" and manifest["artifact"] == candidate["artifact"]
    )
    assert ref(candidate_path) == candidate_ref
    with lc.lease():
        lc.source_check(intent["source"])
        assert not Path(intent["TMP"]).exists()
        private = helpers.checked(manifest["artifact"])
        assert private.stat().st_nlink == 1
        target = Path(intent["target"])
        owner = json.loads((target / ".research-owner.json").read_bytes())
        assert owner == dict(
            writer=intent["writer"],
            target=intent["target"],
            support_sha256=intent["support"]["sha256"],
        )
        support = json.loads(Path(intent["support"]["path"]).read_bytes())
        scopes = [Path(p) for p in support["storage_budget"]["roots"]]
        before = helpers.allocated_union(scopes)
        assert not (target / "debug").exists()
        assert (target / "release").is_dir() and not (target / "release").is_symlink()
        shutil.rmtree(target / "release")
        after = helpers.allocated_union(scopes)
        assert ref(private) == manifest["artifact"]
        cover = (
            support["storage_budget"]["prior_base_known_cover_B"] + after["allocated_B"]
        )
        assert (
            cover + support["storage_budget"]["separate_ordinary_save_Git_B"]
            <= 50000000000
        )
        callers = [
            ref(ROOT / name)
            for name in [
                "scripts/dev/research-lifecycle.py",
                "scripts/dev/research-job.py",
                "python/quoridor_training/cycle_process.py",
                "python/quoridor_training/snapshot.py",
            ]
        ]
    packet = dict(
        status="ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP",
        issue="quoridor-4lc.324.28",
        software_manifest=ref(operation / "manifest.json"),
        artifact=manifest["artifact"],
        cargo_artifact=candidate["cargo_artifact"],
        original_candidate=candidate_ref,
        outer=ref(outer_path),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        current_callers=callers,
        known_command_fresh_absence=known,
        notification_supervisor=dict(
            original=state["supervisor"],
            current=lc.process.identity(
                lc.process.process_info(state["supervisor"]["pid"])
            ),
            scope="Finished job notification only; no source lease or timing promise",
        ),
        source_leases=[],
        remaining_owned=[],
        TMP=[],
        affected_point_before=before,
        affected_point_after=after,
        current_known_cover_B=cover,
        global_actual_B=None,
        later_tails_fees="UNKNOWN",
        retired_only="Stopped owned serial target/release cache; qualified private image retained",
        evaluation="Diagnostic image software qualified only; original diagnostic26 remains unentered until genuine current normal inputs/support/admission; no performance or strength qualification",
        host_future_quiet=False,
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        json.dump(packet, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {
                key: packet[key]
                for key in [
                    "status",
                    "software_manifest",
                    "artifact",
                    "current_known_cover_B",
                ]
            }
        )
    )


if __name__ == "__main__":
    main()
