"""Apply only the three returned compatible diagnostic owner deltas."""

import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1/compatible-retirement-v1"


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    binding = OWN / "binding.json"
    assert (
        ref(binding)["sha256"]
        == "b8902a28ca67dbd1b4fc1a0416d7860c7f08997fa60f3a1a3c0f47b8b0900d37"
    )
    document = json.loads(binding.read_bytes())
    assert (
        len(document["subjects"]) == 3
        and document["same_original_changed_fragments_all3"]
    )
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for row in document["subjects"]:
            actual = ref(ROOT / row["subject"])
            before = row["current_before"]
            if "actual_Root_adoption" in before:
                assert actual == before["actual_Root_adoption"]
            else:
                assert actual["sha256"] == before["raw_sha256"]
            assert ref(Path(row["post"]["path"])) == row["post"]
        patch = document["forward"]
        assert ref(Path(patch["path"])) == patch
        result = subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "-i", patch["path"]],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=True,
        )
        assert (
            "offset" not in result.stdout.lower()
            and "fuzz" not in result.stdout.lower()
        )
        actuals = []
        for row in document["subjects"]:
            actual = ref(ROOT / row["subject"])
            assert all(actual[k] == row["post"][k] for k in ["sha256", "bytes", "mode"])
            actuals.append(dict(subject=row["subject"], actual=actual))
        subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
        receipt = dict(
            status="SPARSE_DIAGNOSTIC_SOURCE_ADOPTED_NEW_SOFTWARE_PENDING",
            issue="quoridor-4lc.324.28",
            binding=ref(binding),
            subjects=actuals,
            original_source_clear_scope=document["old_SOURCE_CLEAR_scope"],
            unchanged_fragments=True,
            GNU_zero_fuzz_no_offset=result.stdout,
            Main_source_EX_acquired_released=True,
            software_tests_compiler_native=0,
            source_leases=[],
            baseline="9513/943 is the prior baseline only, not this diagnostic image",
            preserved="Current100%/ordinary root and shared Search kernels, no Half/aspiration restoration",
            source_reconstruction="Git9126a4a plus published compatible28 archive",
            host_future_quiet=False,
        )
        with (OUT / "actual-adoption.json").open("x") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")
    print(json.dumps(dict(status=receipt["status"], subjects=3)))


if __name__ == "__main__":
    main()
