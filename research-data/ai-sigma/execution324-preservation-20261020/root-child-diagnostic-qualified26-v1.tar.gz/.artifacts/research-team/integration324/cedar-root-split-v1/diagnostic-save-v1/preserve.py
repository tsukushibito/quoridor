"""Preserve closed diagnostic software and original26 bytes without replay."""

import importlib.util
import json
import re
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    paths = []
    scopes = [
        BASE / "compatible-adoption-v1",
        BASE / "software-v1",
        BASE / "normal26-entry-v1",
        OWN / "normal26-runtime-v1",
        OWN / "numeric-diagnostic-v1",
    ]
    for base in scopes:
        for path in helper.files_below(base):
            relative = str(path.relative_to(base)).lower()
            if any(part.startswith("analysis") for part in Path(relative).parts):
                continue
            if re.search(
                r"(^|[-_/])(ready|show|beads|backup|notes?|update|admin|authority)([-_./]|$)",
                relative,
            ):
                continue
            if (
                path.name in {"supervisor.log", "state.json", "notification.json"}
                or "delivery" in relative
                or "dispatch" in relative
            ):
                continue
            assert path.suffix not in {".onnx", ".pt", ".so", ".bin", ".pem", ".key"}
            paths.append(path)
    paths.append(OUT / "preserve.py")
    helper.DEST = DEST
    name = "root-child-diagnostic-qualified26-v1.tar.gz"
    helper.write_archive(
        name,
        paths,
        "Closed compatible28 three-owner adoption, exact new AI1/RunnerLIB1 actually running1/pass1, affected2 Clippy and genuine diagnostic BUILD98d8/image96ad byref, actual STOP, original26 controls/normal buffers/NodeLimit25 UNKNOWN+onecomplete. Opaque closed byte preservation only; no source/test/compiler/native/model/validator/RNG replay, no image/model/input payloads. Active saved screen analysis and notification logs excluded. Prototype and312calls remain conditional/unissued; no speed/strength/plausibility inference from normalPASS.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    software = json.loads(
        (
            BASE / "software-v1/release-collection-v1/completion-and-STOP.json"
        ).read_bytes()
    )
    collection = json.loads(
        (OWN / "numeric-diagnostic-v1/collection-v1/summary.json").read_bytes()
    )
    record = dict(
        issue="quoridor-4lc.324.28",
        status="QUALIFIED_DIAGNOSTIC_SOFTWARE_AND_ORIGINAL26_COLLECTED_SCREEN_PENDING",
        source="Git9126a4a plus exact compatibleb890 three-owner source patch; Current100%, no Half/aspiration restoration",
        source_binding="root-child-diagnostic-compatible-source-v1.json",
        tests="AI1/RunnerLIB1 each actualrunning1/pass1; affected all-target AI/Runner Clippy PASS/warnings0; no old suite replay",
        software_manifest=software["software_manifest"],
        artifact=software["artifact"],
        source_STOP=".artifacts/research-team/integration324/cedar-root-split-v1/software-v1/release-collection-v1/completion-and-STOP.json",
        diagnostic=dict(
            job_id=collection["job_id"],
            calls=collection["calls"],
            sessions=collection["sessions"],
            nodes_once=collection["total_nodes"],
            nodes_upper=collection["nodes_upper"],
            stops=collection["actual_stops"],
            horizon_statuses=collection["actual_horizon_statuses"],
            outer_seconds_once=collection["outer_seconds_once"],
            nested_added=0,
        ),
        interpretation="Normalmanifest/dataPASS is distinct from requestedD64 completion and root-split plausibility. Frozen branch-work screen pending. Node fractions are not time fractions/benefit. No prototype or312call admission, games0/default unchanged.",
        software_outer_seconds_once=dict(
            prefix=290.06564124906436, release=159.19368591101374
        ),
        preserved="Original29/29.3/no128 and all oldFAILED/NULL/UNKNOWN fees, pauses/seals/models/defaults/foreign/50GB unchanged",
        archive={
            key: manifest[key]
            for key in [
                "archive",
                "bytes",
                "sha256",
                "full_stream_restore_hash_mode_verified",
            ]
        },
    )
    with (DEST / "root-child-diagnostic-qualified26-v1.json").open("x") as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(record["archive"]))


if __name__ == "__main__":
    main()
