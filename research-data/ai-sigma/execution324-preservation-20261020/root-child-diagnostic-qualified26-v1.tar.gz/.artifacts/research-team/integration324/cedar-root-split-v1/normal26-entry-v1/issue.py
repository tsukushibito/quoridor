"""Join the genuine diagnostic image to the original bounded root-child screen."""

import datetime
import fcntl
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1"
MIB = 1024**2


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper = load(
        "existing_metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py",
    )
    lc = load("current_normal", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helper.ref

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return ref(path)

    stop_path = BASE / "software-v1/release-collection-v1/completion-and-STOP.json"
    stopped = json.loads(stop_path.read_bytes())
    assert (
        stopped["status"]
        == "ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP"
    )
    assert (
        stopped["source_leases"] == stopped["TMP"] == stopped["remaining_owned"] == []
    )
    manifest = json.loads(helper.checked(stopped["software_manifest"]).read_bytes())
    assert manifest["status"] == "PASS" and manifest["artifact"] == stopped["artifact"]
    controls = ref(OWN / "compatible-retirement-v1/binding.json")
    assert (
        controls["sha256"]
        == "b8902a28ca67dbd1b4fc1a0416d7860c7f08997fa60f3a1a3c0f47b8b0900d37"
    )
    protocol = ref(OWN / "finite-protocol-v1.json")
    assert (
        protocol["sha256"]
        == "c87fbc687e812e2975b6f5c542f3a36023375f5d4068c56d471cad2c9abb73bd"
    )
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for caller in stopped["current_callers"]:
            assert ref(Path(caller["path"])) == caller
        lc.source_check(manifest["source"])
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_QUALIFIED_DIAGNOSTIC_IMAGE_SOURCE_STOP",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                source=manifest["source"],
                current_four_callers=stopped["current_callers"],
                software_manifest=stopped["software_manifest"],
                artifact=stopped["artifact"],
                actual_software_STOP=ref(stop_path),
                compatible_source=controls,
                original_protocol=protocol,
                source_SH_NB_acquired_released=True,
                source_leases_remaining=[],
                qualification="New diagnostic AI1/RunnerLIB1 each actually running1 and affected Clippy plus genuine diagnostic release. Baseline9513/943 is not this image. Current normal factory and fresh runtime admission remain required.",
                evaluation="UNENTERED",
                host_future_quiet=False,
            ),
        )
    software_intent = json.loads(
        (BASE / "software-v1/build-intent-release.json").read_bytes()
    )
    software_support = json.loads(
        helper.checked(software_intent["support"]).read_bytes()
    )
    roots = software_support["storage_budget"]["roots"]
    actual = helper.allocated_union([Path(p) for p in roots])
    whole = 256 * MIB
    future = 100 * MIB
    margin = whole - actual["allocated_B"] - future
    assert margin >= 8 * MIB, (actual, margin)
    base_cover = software_support["storage_budget"]["prior_base_known_cover_B"]
    ordinary = software_support["storage_budget"]["separate_ordinary_save_Git_B"]
    assert base_cover + whole + ordinary <= 50000000000
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize > whole
    capacity = save(
        "capacity-and-holding.json",
        dict(
            roots=roots,
            actual_ended_point=actual,
            conservative_future_B=future,
            future_parts_B=dict(
                native=20 * MIB,
                normal_logs=32 * MIB,
                serial_TMP=16 * MIB,
                analysis_controls=32 * MIB,
            ),
            whole_B=whole,
            forecast_margin_B=margin,
            prior_base_known_cover_B=base_cover,
            separate_new_ordinary_save_Git_envelope_B=ordinary,
            new_known_cover_upper_B=base_cover + whole + ordinary,
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            scope="ONE full union replaces ended software holding once; all prior retention preserved, no copies/globalwalk/refund/node lending",
            globalactual_later_tails_fullfees="UNKNOWN",
        ),
    )
    resources = dict(
        search_cpu_cores=[12],
        total_search_threads=1,
        worker_cpu=12,
        main_guardian=0,
        outer_guardian=18,
        launch_affinity=[0, 12, 18],
        family_B=4 * 1024**3,
        controller_B=1610612736,
        native_B=2684354560,
        host_reserve_B=4 * 1024**3,
        GPU=0,
        threads=1,
        CPU=2,
        controller_included=True,
        family_RAM_B=4 * 1024**3,
        controller_RAM_B=1610612736,
    )
    limits = dict(
        worker_cpu=12,
        guardian_cpu=0,
        family_B=4 * 1024**3,
        controller_B=1610612736,
        host_reserve_B=4 * 1024**3,
        owned_B=whole,
        free_B=margin,
        log_B=MIB,
    )
    support = save(
        "phase-support-N1.json",
        dict(
            issue="quoridor-4lc.324.28",
            status="ISSUED_ORIGINAL28_DIAGNOSTIC26_ONE_SERIAL_LIFETIME",
            fixed_protocol=protocol,
            current_source_adoption=release,
            actual_source_STOP=release,
            actual_software_STOP=ref(stop_path),
            whole_B=whole,
            roots=roots,
            owned_B=whole,
            free_B=margin,
            storage_budget=dict(whole_B=whole, roots=roots),
            capacity_basis=capacity,
            resources=resources,
            limits=limits,
            total_original_calls=26,
            total_original_nodes=26000000,
            per_call_aggregate_nodes=1000000,
            TOTAL_TT_entries=1048576,
            serial_runs=1,
            sessions=6,
            RUN_timeout_s=900,
            parent_accepted_s=1200,
            parent_command_s=1140,
            cleanup_margin_s=60,
            readonly_images_models_copy_B=0,
            native_aggregate_B_each=20 * MIB,
            perf_RAW_B=0,
            allocation="Original26 genuine prefixes/six chronological series/full predecessors/D64/timeNone/1M/N1/Control/OffShadow/root_ordering_quality/perf0/Current100%; existing root-child node/eval counters only. Actual incomplete stays UNKNOWN, no refill.",
            normal_remaining_inputs="Current factory/numerical_fields/current caller/env/source binding and fresh physicalSMT-peer/RAM/host4/fullroots/storage/pausecancel/origin/end_at/serializer/cleanup at normal owning entry",
            timing="CurrentMain/callers/image/libs/env/Git/Cargo/heavyIO frozen through exact diagnostic native+normalcollectionSTOP only",
            later_stages="312calls/312M comparison conditional on original branch-work screening and actual separate support; combined ceiling338, not an automatic grant. Prototype/games0.",
            science_refund_lending_reset=0,
            pauses_seals_models_defaults_foreign_FAILED_UNKNOWN="PRESERVED",
        ),
    )
    save(
        "issued-inputs.json",
        dict(
            release=release,
            phase_supports=[support],
            capacity=capacity,
            controls=controls,
            original_protocol=protocol,
            new_diagnostic_usage_before_submit=0,
            evaluation="UNENTERED",
            source_leases=[],
        ),
    )
    print(
        json.dumps(
            dict(
                status="ISSUED_ORIGINAL28_DIAGNOSTIC26",
                support=support,
                release=release,
                whole_B=whole,
                margin_B=margin,
                actual_point_B=actual["allocated_B"],
            )
        )
    )


if __name__ == "__main__":
    main()
