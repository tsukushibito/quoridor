"""Prepare the two new diagnostic boundaries and affected lint/release."""

import argparse
import copy
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/cedar-aspiration-window-v1"
)
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["prefix", "release"], required=True)
    args = parser.parse_args()
    lc = load("current_lifecycle", ROOT / "scripts/dev/research-lifecycle.py")
    helper = load(
        "existing_metadata", BASE / "software-v2/prefix-collection-v1/collect.py"
    )
    ref = helper.ref

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return ref(path)

    template = json.loads((BASE / "software-v2/build-intent-release.json").read_bytes())
    adopted = OUT.parent / "compatible-adoption-v1/actual-adoption.json"
    adoption_fact = json.loads(adopted.read_bytes())
    assert (
        adoption_fact["status"]
        == "SPARSE_DIAGNOSTIC_SOURCE_ADOPTED_NEW_SOFTWARE_PENDING"
    )
    assert len(adoption_fact["subjects"]) == 3
    with lc.lease():
        source = copy.deepcopy(template["source"])
        patch = OUT / f"actual-source-{args.stage}.patch"
        patch.write_bytes(
            subprocess.check_output(
                [
                    "git",
                    "diff",
                    "--binary",
                    "--no-ext-diff",
                    "--no-textconv",
                    "HEAD",
                    "--",
                ],
                cwd=ROOT,
            )
        )
        source.update(
            commit=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
            ).strip(),
            patch=ref(patch),
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        source["untracked_inputs"] = []
        assert not subprocess.check_output(
            [
                "git",
                "ls-files",
                "--others",
                "--exclude-standard",
                "--",
                "crates",
                ".cargo",
                "Cargo.toml",
                "Cargo.lock",
            ],
            cwd=ROOT,
        )
        for witness in source["cargo_configs"]:
            path = Path(witness["path"])
            witness["file"] = ref(path) if path.exists() else None
        subjects = [row["actual"] for row in adoption_fact["subjects"]]
        receipts = []
        if args.stage == "release":
            prefix = OUT / "operation-prefix/prefix-result.json"
            checks = json.loads(prefix.read_bytes())
            assert (
                checks["status"] == "PASS_TEST_LINT_PREFIX_ONLY"
                and checks["cleanup_complete"]
            )
            assert len(checks["checks"]) == 4 and all(
                row["status"] == "PASS" for row in checks["checks"]
            )
            receipts.extend(
                dict(name=row["name"], file=ref(prefix)) for row in checks["checks"]
            )
        adopted_ref = save(
            f"build-source-adoption-{args.stage}.json",
            dict(
                schema="quoridor.research.source-adoption.v1",
                status="ACCEPTED",
                issue="quoridor-4lc.324.28",
                source=source,
                actual_fixed_source_adoption=ref(adopted),
                prior_software=dict(subjects=subjects, receipts=receipts),
                scope="Original diagnostic AI1 and RunnerLIB1 execute once in the existing Cargo release profile with ordinary assertions (no debug-only assertions in these definitions), preserving all project release flags/features. No old suite execution. Each stopped test cache is retired before the next command; affected release-profile Clippy then genuine diagnostic release. No scientific work or baseline-image alias.",
            ),
        )
        target = Path(template["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker["writer"] == WRITER and marker["target"] == str(target)
        assert not (target / "debug").exists() and not (target / "release").exists()
        prior = Path(
            "/workspaces/quoridor/.artifacts/research-team/integration324/cedar-aspiration-window-v1/implementation-cost-review-v1/retirement-software-v2"
        )
        roots = [
            ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1",
            BASE / "normal208-entry-v1",
            prior.parent / "phase1-entry-v1",
            prior.parent / "phase2-entry-v1",
            prior.parent / "phase3-entry-v1",
            prior,
            ROOT / ".worktree/assets/perf/cedar-root-split-v1",
            OUT.parent,
            target,
        ]
        whole = 348 * 1024**2
        base_cover = 49608672256
        ordinary = 24 * 1024**2
        assert base_cover + whole + ordinary <= 50000000000
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
            owned_B=whole,
            free_B=32 * 1024**2,
        )
        support = save(
            f"resources-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.28",
                authority=adopted_ref,
                resources=dict(
                    worker_cpu=12,
                    guardian_cpu=16,
                    test_cpu_cores=[12, 14, 16],
                    native_threads=1,
                    GPU=0,
                    family_RAM_B=4 * 1024**3,
                    controller_included=True,
                    controller_B=64 * 1024**2,
                    host_reserve_B=4 * 1024**3,
                ),
                storage_budget=dict(
                    whole_B=whole,
                    roots=[str(p) for p in roots],
                    scope="One whole includes ended five-root retention, prior qualified baseline image/software, own28 and Root28 source/software, and serial Cargo cache/private output. Forward allocation replaces the ended point once. Separate ordinary save envelope24MiB has observed17,776,640B. Cache of each completed new release-profile NN0 test retires before the next test/lint; lint cache retires before genuine release. No model/library copies/global walk/refund/node lending.",
                    prior_base_known_cover_B=base_cover,
                    separate_ordinary_save_Git_B=ordinary,
                    known_cover_upper_B=base_cover + whole + ordinary,
                    globalactual_fullfees="UNKNOWN",
                ),
                scope="Ordinary software only; no native/scientific grant",
            ),
        )
        handover = save(
            f"target-handover-{args.stage}.json",
            dict(
                schema="research.target-handover.v1",
                status="HANDED_OVER",
                target=str(target),
                target_writer=WRITER,
                fresh_private_root=str(OUT / f"private-image-{args.stage}"),
                shared_serial_pool=True,
                old_target=json.loads(
                    (
                        BASE.parent
                        / "cedar-lazy-smp-followup-v1/replacement-v1/software-v1/target-handover-release.json"
                    ).read_bytes()
                )["old_target"],
                owned_remaining=[],
                test_cpu_cores=[12, 14, 16],
                actual_source_adoption=ref(adopted),
                scope="Same stopped serial pool, not another parallel target",
            ),
        )
        cargo = template["tools"]["CARGO"]["file"]["path"]
        commands = []
        if args.stage == "prefix":
            recipe = json.loads(
                (
                    ROOT
                    / ".worktree/assets/perf/cedar-root-split-v1/compatible-retirement-v1/software-recipe.json"
                ).read_bytes()
            )
            for index, row in enumerate(recipe["new_tests"]):
                commands.append(
                    dict(
                        name=f"root-child-new-boundary-{index + 1}",
                        role="test",
                        selector=row["selector"],
                        argv=[
                            cargo,
                            "test",
                            "--offline",
                            "--locked",
                            "--manifest-path",
                            str(ROOT / "Cargo.toml"),
                            "-j1",
                            "--message-format=json-render-diagnostics",
                            "--release",
                            "-p",
                            row["package"],
                            "--features",
                            ",".join(row["features"]),
                            "--lib",
                            row["selector"],
                            "--",
                            "--exact",
                            "--nocapture",
                            "--test-threads=1",
                        ],
                    )
                )
            for package, features, label in [
                ("quoridor-ai", "research-diagnostics", "AI"),
                (
                    "quoridor-runner",
                    "measurement,quoridor-inference/claustrophobia",
                    "Runner",
                ),
            ]:
                commands.append(
                    dict(
                        name=f"root-child-affected-{label}-Clippy",
                        role="lint",
                        argv=[
                            cargo,
                            "clippy",
                            "--offline",
                            "--locked",
                            "--manifest-path",
                            str(ROOT / "Cargo.toml"),
                            "-j1",
                            "--message-format=json-render-diagnostics",
                            "--release",
                            "-p",
                            package,
                            "--features",
                            features,
                            "--all-targets",
                            "--no-deps",
                            "--",
                            "-Dwarnings",
                        ],
                    )
                )
        build = copy.deepcopy(template["commands"][0])
        build["name"] = "root-child-diagnostic-genuine-release"
        commands.append(build)
        spec = copy.deepcopy(template)
        for key in ["admission", "intent_sha256"]:
            spec.pop(key, None)
        spec.update(
            output=str(OUT / f"operation-{args.stage}"),
            owned_outputs=[str(OUT)],
            support=support,
            source_adoption=adopted_ref,
            target_handover=handover,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / f"private-image-{args.stage}/quoridor-runner"),
            TMP=str(OUT / f"build-TMP-{args.stage}"),
            test_cpu_cores=[12, 14, 16],
            command_timeout_seconds=1800,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        (target / ".research-owner.json").write_text(
            json.dumps(
                dict(
                    writer=WRITER, target=str(target), support_sha256=support["sha256"]
                ),
                indent=2,
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            f"build-admission-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Software binding only, normal runtime admission still required",
            ),
        )
        intent = save(f"build-intent-{args.stage}.json", spec)
        argv = (
            [str(lc.project_python()), "-B", str(OUT / "run_prefix.py")]
            if args.stage == "prefix"
            else [
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "build",
            ]
        )
        argv += ["--intent", intent["path"], "--sha256", intent["sha256"]]
        save(
            f"job-{args.stage}.json",
            dict(
                issue="quoridor-4lc.324",
                goal_issue="quoridor-4lc.324",
                thread_id="01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                cwd=str(ROOT),
                argv=argv,
                end_at=None,
                notify_until=None,
                max_runtime_seconds=1860,
                control_interval_seconds=30,
                notify_interval_seconds=10,
                request_timeout_seconds=25,
                log_max_bytes=16384,
                resource_contract=support["path"],
            ),
        )
        print(json.dumps(dict(stage=args.stage, intent=intent, actual_job=None)))


if __name__ == "__main__":
    main()
