"""Preserve accepted purpose-end cleanup and its actual software results."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.DEST = DEST
    paths = []
    for path in [
        OWN / "retirement-v1",
        ROOT / ".worktree/assets/perf/cedar-root-split-review-v1/final-result-v1",
        BASE / "retirement-adoption-v1",
        BASE / "retirement-software-v1",
        BASE / "retirement-software-v2",
        BASE / "final-review-route-v1",
        BASE / "capacity-repair-v1",
    ]:
        paths += helper.files_below(path)
    # Cached full Beads snapshots remain in their private, verified canonical
    # xz. Publish identities/restore ledgers, not another copy of the DB cache.
    paths = [
        p
        for p in paths
        if p.name not in {"notification.json", "supervisor.log", "state.json"}
        and p.suffix not in {".xz", ".gz"}
        and p.stat().st_size < 512 * 1024
        and not p.name.startswith("Root-metadata")
        and not p.name.startswith("Root-current-metadata")
    ]
    # Compressed frozen before-images are necessary source reconstruction data.
    paths += helper.files_below(OWN / "retirement-v1/before")
    paths += [OUT / "preserve.py", OUT / "preservation-allocation.json"]
    name = "root-split-retirement-qualified-baseline-v1.tar.gz"
    helper.write_archive(
        name,
        paths,
        "Accepted bounded original312 interpretation and exact11 purpose-end retirement; "
        "related SOURCE_CLEAR/CONCLUSION_CLEAR and own review closure; actual Main sparse "
        "adoption, affected all-target Clippy PASS, original57e4 storageFAILED and partial "
        "facts preserved, new4c4c genuine baseline normal finalize/sourceSTOP. Capacity "
        "representation ledgers preserve original raw identities/costs; scientific data "
        "remain in earlier frozen Git archives. Private images/model/input/DB/cache and "
        "canonical admin xz excluded; no scientific/native/test/build/validator/RNG replay.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    software = json.loads(
        (
            BASE
            / "retirement-software-v2/release-collection-v1/completion-and-STOP.json"
        ).read_bytes()
    )
    result = dict(
        issue="quoridor-4lc.324.28",
        status="ACCEPTED_FINITE_UNKNOWN_PURPOSE_END_RETIREMENT_BASELINE_SOFTWARE_PASS",
        measured_source="34b19c9a90b0a44566a0424e6c891979cab03c26",
        cleaned_source="9a37ac522242e528243ec25c55b77e3bdd21ea65 plus exact11 retirement patch; committed with this record",
        retirement_binding="e6f23bfe1bd2e6bdd9e47f8c0b34c9dbc6a07a706e8475e361a27a8444572f35",
        finite_review="a808f524aba77e35f9c794ac3e711bc3dbeee1d5f038e763afbbfcc723105b0c",
        source_review="5747a824b7a12020af6a7775dd74064258723dbb580203f1d7ac467f500058b3",
        comparison=dict(calls=312, sessions=72, actual_nodes_once=101961543),
        with_diagnostic=dict(calls=338, actual_nodes_once=126961736),
        disposition="UNRESOLVED_FIXED_COMPLETED_TIME_CENSORING; default1 retained, no prototype adoption, games, refill or new grant",
        fixed="LOCAL1 and ROOT_SPLIT2 each52DepthComplete; LAZY2 41DepthComplete+11NodeLimitUNKNOWN. Frozen ALL156 completion false; no favourable subset/cap-time speed qualification",
        clock="Finite safety PASS; each mode50TimeLimitUNKNOWN+2DepthComplete, terminalp95linear .09975053175/max .1051407. Different selective work/depth/PV not strength/samework/causal speed",
        cleanup="Eleven subjects, two wholly28 modules removed; ordinary LOCAL/Lazy2 kernels/history/TT/aggregatebudget/drain/reset/drop and generic21/23/timedquality/selected-abnormal NN0 retained. No Half/aspiration revival",
        affected_software="AI and Runner all-target Clippy each PASS warning0, tests executed0; exact unchanged generic NN0 scope reused. Handwritten changes scoped formatted; source review does not prove runtime fault coverage",
        new_baseline_BUILD=software["software_manifest"],
        new_baseline_image=software["artifact"],
        baseline_qualification="Genuine cleaned baseline software only, unmeasured; not9251 alias or empirical oldimage parity",
        software_outer_seconds_once=dict(
            affected_Clippy=66.5625943779014,
            original_storage_failed_release=61.32241108303424,
            new_successful_release=96.48068415897433,
        ),
        nested_added=0,
        capacity="Original57e4 remainsFAILED; after actualSTOP, verified lossless canonical admin xz, existing Git scientific archives and selected newer Git object pack replace redundant working copies. Source/model/image/FAILED/UNKNOWN/costs preserved; no scientific quota refund or loan",
        restoration="Earlier root-split-original312-result and root-child-diagnostic-qualified26 archives are unchanged scientific restoration authorities. This archive includes transformation ledgers and raw member hashes. Closed administrative xz stays private by its exact manifest reference",
        limits="Exposed26roots/3families/6warm correlated series/stock0 shortfall; no general speed/strength/equality/causal/default promotion. PhysicalNN/family peak/fullfees/globalactual UNKNOWN. All pauses/seals/models/foreign preserved",
        archive={
            k: manifest[k]
            for k in (
                "archive",
                "sha256",
                "bytes",
                "full_stream_restore_hash_mode_verified",
            )
        },
    )
    with (DEST / "root-split-retirement-qualified-baseline-v1.json").open(
        "x"
    ) as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
