"""Bind only unfinished baseline release after actual lossless capacity repair."""

import copy
import importlib.util
import json
from pathlib import Path


ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def main():
    loader = importlib.util.spec_from_file_location(
        "current_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return lc.artifact_ref(path)

    old_path = BASE / "retirement-software-v1/build-intent-release.json"
    old = json.loads(old_path.read_bytes())
    capacity_path = BASE / "capacity-repair-v1/actual-capacity-and-retention.json"
    capacity = json.loads(capacity_path.read_bytes())
    stopped_path = (
        BASE
        / "retirement-software-v1/failure-collection-final/completion-and-STOP.json"
    )
    stopped = json.loads(stopped_path.read_bytes())
    assert (
        stopped["source_leases"] == stopped["TMP"] == stopped["remaining_owned"] == []
    )
    assert capacity["known_upper_B"] < 50000000000
    assert capacity["known_ordinary_B"] < capacity["ordinary_envelope_B"]
    assert capacity["headroom_at_current_point_B"] > 64 * 1024**2
    review_path = (
        ROOT
        / ".worktree/assets/perf/cedar-root-split-review-v1/final-result-v1/retirement-source-v1/minimum.json"
    )
    review_ref = lc.artifact_ref(review_path)
    assert (
        review_ref["sha256"]
        == "5747a824b7a12020af6a7775dd74064258723dbb580203f1d7ac467f500058b3"
    )
    with lc.lease():
        lc.source_check(old["source"])
        target = Path(old["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker == dict(
            writer=old["writer"],
            target=str(target),
            support_sha256=old["support"]["sha256"],
        )
        assert (target / "release").is_dir() and not (target / "release").is_symlink()
        assert not (target / "debug").exists()
        adoption = copy.deepcopy(lc.document(old["source_adoption"]))
        adoption.update(
            actual_capacity_derivative=lc.artifact_ref(capacity_path),
            original_failed_release_STOP=lc.artifact_ref(stopped_path),
            related_source_minimum=review_ref,
            scope="Exact eleven-subject purpose-end retirement SOURCE_CLEAR and actual affectedClippyPASS retained, only protected genericNN0 scope reused. Original57e4 FAILED/NULLguardian/pendingmask/costs immutable. Administrative snapshots losslessly compressed, ended numeric extraction duplicates preserved canonically in verified pushedGit archives; selected newerGitobjects standardpacked/verified. No model/image/source/compilerflags or science changed, no oldproof deleted/refund/lending. Reuse partial same-source Cargo cache through normal freshness; unfinished genuine baseline build only, not9251alias or retroPASS.",
        )
        adoption_ref = save("build-source-adoption-release.json", adoption)
        limits = copy.deepcopy(old["limits"])
        limits["owned_B"] = capacity["whole_B"]
        support = copy.deepcopy(lc.document(old["support"]))
        support["authority"] = adoption_ref
        support["storage_budget"].update(
            whole_B=capacity["whole_B"],
            separate_ordinary_save_Git_B=capacity["ordinary_envelope_B"],
            known_cover_upper_B=capacity["known_upper_B"],
            actual_capacity_correction=lc.artifact_ref(capacity_path),
            scope="Same nine-root whole357MiB plus actual packed ordinary16MiB under unchanged50GB. Canonical raw records/images/models/FAILED/fees retained, no globalwalk/usedquota deletion/refund/lending. Stopped same-source partial cache included; normalguards/source/freshness/cancel/cleanup remain authoritative.",
        )
        support_ref = save("resources-release.json", support)
        handover = copy.deepcopy(lc.document(old["target_handover"]))
        handover["fresh_private_root"] = str(OUT / "private-image-release")
        handover["scope"] = (
            "Same stopped serialCargo pool after actualfailedreturn/sourceSTOP; partial source-identical cache is not an artifact qualification"
        )
        handover_ref = save("target-handover-release.json", handover)
        spec = copy.deepcopy(old)
        for name in ["admission", "intent_sha256"]:
            spec.pop(name, None)
        spec.update(
            output=str(OUT / "operation-release"),
            private=str(OUT / "private-image-release/quoridor-runner"),
            TMP=str(OUT / "build-TMP-release"),
            support=support_ref,
            source_adoption=adoption_ref,
            target_handover=handover_ref,
            limits=limits,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        assert len(spec["commands"]) == 1 and spec["commands"][0]["role"] == "build"
        (target / ".research-owner.json").write_text(
            json.dumps(
                dict(
                    writer=spec["writer"],
                    target=str(target),
                    support_sha256=support_ref["sha256"],
                ),
                indent=2,
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            "build-admission-release.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support_ref["sha256"],
                ready=True,
                scope="Software metadata only, actual runtime admission still required",
            ),
        )
        intent = save("build-intent-release.json", spec)
    job = json.loads((BASE / "retirement-software-v1/job-release.json").read_bytes())
    job["argv"] = [
        str(lc.project_python()),
        "-B",
        str(ROOT / "scripts/dev/research-lifecycle.py"),
        "build",
        "--intent",
        intent["path"],
        "--sha256",
        intent["sha256"],
    ]
    job["resource_contract"] = support_ref["path"]
    save("job-release.json", job)
    print(json.dumps(dict(intent=intent, support=support_ref, actual_job=None)))


if __name__ == "__main__":
    main()
