"""Apply only the returned eleven-subject purpose-end deletion patch."""

import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import subprocess


ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1/retirement-v1"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def main():
    binding_path = OWN / "binding.json"
    assert (
        ref(binding_path)["sha256"]
        == "e6f23bfe1bd2e6bdd9e47f8c0b34c9dbc6a07a706e8475e361a27a8444572f35"
    )
    binding = json.loads(binding_path.read_bytes())
    assert len(binding["subjects"]) == 11
    loader = importlib.util.spec_from_file_location(
        "current_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    patch = Path(binding["forward"]["path"])
    assert ref(patch) == binding["forward"]
    with lc.lease():
        for row in binding["subjects"]:
            path = ROOT / row["subject"]
            assert (
                path.is_relative_to(ROOT / "crates")
                or path.parent == ROOT / "scripts/dev"
            )
            actual = ref(path)
            assert actual["sha256"] == row["before_raw_sha256"]
            assert (
                actual["bytes"] == row["before_bytes"] and actual["mode"] == row["mode"]
            )
            if row["post"]:
                assert ref(Path(row["post"]["path"])) == row["post"]
        subprocess.run(["git", "apply", "--check", str(patch)], cwd=ROOT, check=True)
        subprocess.run(["git", "apply", str(patch)], cwd=ROOT, check=True)
        actual_rows = []
        for row in binding["subjects"]:
            path = ROOT / row["subject"]
            if row["post"] is None:
                assert not path.exists()
                actual_rows.append(dict(subject=row["subject"], deleted=True))
            else:
                actual = ref(path)
                assert {key: actual[key] for key in ("sha256", "bytes", "mode")} == {
                    key: row["post"][key] for key in ("sha256", "bytes", "mode")
                }
                actual_rows.append(dict(subject=row["subject"], actual=actual))
        result = dict(
            status="ACTUAL_SPARSE_ELEVEN_SUBJECT_PURPOSE_END_RETIREMENT_APPLIED",
            binding=ref(binding_path),
            patch=ref(patch),
            subjects=actual_rows,
            prior_finite_result="CONCLUSION_CLEAR a808f524; completed-timeUNKNOWN, clockfinitePASS; no science/default change",
            private_source_format_lint="Exact returned formatted post bytes adopted; no wholeowner replacement or oldproof replay",
            related_source_review="ExistingMax28.4 active on exact private packet, separate from type/software",
            software="NOT_TYPED_NEW_BASELINE_NOT_BUILT",
            source_EX_NB_acquired_released=True,
            source_leases_remaining=[],
            host_future_quiet=False,
        )
    with (OUT / "actual-adoption.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            dict(adopted=len(actual_rows), receipt=ref(OUT / "actual-adoption.json"))
        )
    )


if __name__ == "__main__":
    main()
