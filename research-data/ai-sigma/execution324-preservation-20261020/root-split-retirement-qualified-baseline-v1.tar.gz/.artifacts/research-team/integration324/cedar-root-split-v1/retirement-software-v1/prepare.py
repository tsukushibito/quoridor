"""Prepare affected lint or genuine release after finite comparison retirement."""

import argparse
import copy
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = ROOT / ".artifacts/research-team/integration324/cedar-aspiration-window-v1"
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["prefix", "release"], required=True)
    args = parser.parse_args()
    lc = load("current_lifecycle", ROOT / "scripts/dev/research-lifecycle.py")
    helper = load(
        "existing_metadata", BASE / "software-v2/prefix-collection-v1/collect.py"
    )
    ref = helper.ref

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return ref(path)

    template = json.loads(
        (OUT.parent / "prototype-software-v6/build-intent-release.json").read_bytes()
    )
    adopted = OUT.parent / "retirement-adoption-v1/actual-adoption.json"
    adoption_fact = json.loads(adopted.read_bytes())
    assert (
        adoption_fact["status"]
        == "ACTUAL_SPARSE_ELEVEN_SUBJECT_PURPOSE_END_RETIREMENT_APPLIED"
    )
    assert len(adoption_fact["subjects"]) == 11
    with lc.lease():
        source = copy.deepcopy(template["source"])
        patch = OUT / f"actual-source-{args.stage}.patch"
        patch.write_bytes(
            subprocess.check_output(
                [
                    "git",
                    "diff",
                    "--binary",
                    "--no-ext-diff",
                    "--no-textconv",
                    "HEAD",
                    "--",
                ],
                cwd=ROOT,
            )
        )
        source.update(
            commit=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
            ).strip(),
            patch=ref(patch),
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        source["untracked_inputs"] = []
        assert not subprocess.check_output(
            [
                "git",
                "ls-files",
                "--others",
                "--exclude-standard",
                "--",
                "crates",
                ".cargo",
                "Cargo.toml",
                "Cargo.lock",
            ],
            cwd=ROOT,
        )
        for witness in source["cargo_configs"]:
            path = Path(witness["path"])
            witness["file"] = ref(path) if path.exists() else None
        protected = json.loads(
            (
                ROOT
                / ".worktree/assets/perf/cedar-shallow-main-history-v1/timed-rootquality-repair-v1/binding.json"
            ).read_bytes()
        )
        subjects = []
        for owner in protected["owners"]:
            current = ref(ROOT / owner["path"])
            expected = owner["post"]
            assert all(current[k] == expected[k] for k in ["sha256", "bytes", "mode"])
            subjects.append(current)
        old_prefix = (
            ROOT
            / ".artifacts/research-team/integration324/cedar-shallow-main-history-v1/timed-rootquality-software-v1/operation-prefix/prefix-result.json"
        )
        receipts = [dict(name="timed-rootquality-new-Rust-one", file=ref(old_prefix))]
        if args.stage == "release":
            prefix = OUT / "operation-prefix/prefix-result.json"
            checks = json.loads(prefix.read_bytes())
            assert (
                checks["status"] == "PASS_TEST_LINT_PREFIX_ONLY"
                and checks["cleanup_complete"]
            )
            assert len(checks["checks"]) == 2 and all(
                row["status"] == "PASS" for row in checks["checks"]
            )
            receipts.extend(
                dict(name=row["name"], file=ref(prefix)) for row in checks["checks"]
            )
            subjects.extend(
                row["actual"] for row in adoption_fact["subjects"] if "actual" in row
            )
        adopted_ref = save(
            f"build-source-adoption-{args.stage}.json",
            dict(
                schema="quoridor.research.source-adoption.v1",
                status="ACCEPTED",
                issue="quoridor-4lc.324.28",
                source=source,
                actual_fixed_source_adoption=ref(adopted),
                prior_software=dict(subjects=subjects, receipts=receipts),
                scope="Only unchanged generic timed-rootquality NN0 qualification retained; no claim changed alpha/retirement tests executed. Two affected all-target release-profile Clippy compile remaining assertions, no oldsuite replay.",
            ),
        )
        target = Path(template["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker["writer"] == WRITER and marker["target"] == str(target)
        assert not (target / "debug").exists() and not (target / "release").exists()
        roots = [Path(p) for p in template["owned_outputs"]]
        whole = 348 * 1024**2
        base_cover = 49608672256
        ordinary = 24 * 1024**2
        assert base_cover + whole + ordinary <= 50000000000
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
            owned_B=whole,
            free_B=32 * 1024**2,
        )
        support = save(
            f"resources-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.28",
                authority=adopted_ref,
                resources=dict(
                    worker_cpu=12,
                    guardian_cpu=16,
                    test_cpu_cores=[12, 14, 16],
                    native_threads=1,
                    GPU=0,
                    family_RAM_B=4 * 1024**3,
                    controller_included=True,
                    controller_B=64 * 1024**2,
                    host_reserve_B=4 * 1024**3,
                ),
                storage_budget=dict(
                    whole_B=whole,
                    roots=[str(p) for p in roots],
                    scope="One348MiB whole counts allnine actual roots including all priorretention/privateimages/current source/results and serialCargo cache. Separate24MiB ordinarysave/Git, baseknowncover49608672256 underdecimal50GB. Clippy cache reused across twoaffectedpackages then retired afteractualSTOP before genuinebaseline release; no oldholding/globalwalk/modelcopies/refund/lending.",
                    prior_base_known_cover_B=base_cover,
                    separate_ordinary_save_Git_B=ordinary,
                    known_cover_upper_B=base_cover + whole + ordinary,
                    globalactual_fullfees="UNKNOWN",
                ),
                scope="Ordinary software only; no native/scientific grant",
            ),
        )
        handover = save(
            f"target-handover-{args.stage}.json",
            dict(
                schema="research.target-handover.v1",
                status="HANDED_OVER",
                target=str(target),
                target_writer=WRITER,
                fresh_private_root=str(OUT / f"private-image-{args.stage}"),
                shared_serial_pool=True,
                old_target=json.loads(
                    (
                        BASE.parent
                        / "cedar-lazy-smp-followup-v1/replacement-v1/software-v1/target-handover-release.json"
                    ).read_bytes()
                )["old_target"],
                owned_remaining=[],
                test_cpu_cores=[12, 14, 16],
                actual_source_adoption=ref(adopted),
                scope="Same stopped serial pool, not another parallel target",
            ),
        )
        cargo = template["tools"]["CARGO"]["file"]["path"]
        commands = []
        if args.stage == "prefix":
            for package, features, label in [
                ("quoridor-ai", "research-diagnostics", "AI"),
                (
                    "quoridor-runner",
                    "measurement,quoridor-inference/claustrophobia",
                    "Runner",
                ),
            ]:
                commands.append(
                    dict(
                        name=f"retirement-affected-{label}-Clippy",
                        role="lint",
                        argv=[
                            cargo,
                            "clippy",
                            "--offline",
                            "--locked",
                            "--manifest-path",
                            str(ROOT / "Cargo.toml"),
                            "-j1",
                            "--message-format=json-render-diagnostics",
                            "--release",
                            "-p",
                            package,
                            "--features",
                            features,
                            "--all-targets",
                            "--no-deps",
                            "--",
                            "-Dwarnings",
                        ],
                    )
                )
        build = copy.deepcopy(template["commands"][0])
        build["name"] = "root-split-retirement-genuine-baseline-release"
        commands.append(build)
        spec = copy.deepcopy(template)
        for key in ["admission", "intent_sha256"]:
            spec.pop(key, None)
        spec.update(
            output=str(OUT / f"operation-{args.stage}"),
            owned_outputs=[str(p) for p in roots],
            support=support,
            source_adoption=adopted_ref,
            target_handover=handover,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / f"private-image-{args.stage}/quoridor-runner"),
            TMP=str(OUT / f"build-TMP-{args.stage}"),
            test_cpu_cores=[12, 14, 16],
            command_timeout_seconds=1800,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        (target / ".research-owner.json").write_text(
            json.dumps(
                dict(
                    writer=WRITER, target=str(target), support_sha256=support["sha256"]
                ),
                indent=2,
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            f"build-admission-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Software binding only, normal runtime admission still required",
            ),
        )
        intent = save(f"build-intent-{args.stage}.json", spec)
        argv = (
            [str(lc.project_python()), "-B", str(OUT / "run_prefix.py")]
            if args.stage == "prefix"
            else [
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "build",
            ]
        )
        argv += ["--intent", intent["path"], "--sha256", intent["sha256"]]
        save(
            f"job-{args.stage}.json",
            dict(
                issue="quoridor-4lc.324",
                goal_issue="quoridor-4lc.324",
                thread_id="01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                cwd=str(ROOT),
                argv=argv,
                end_at=None,
                notify_until=None,
                max_runtime_seconds=1860,
                control_interval_seconds=30,
                notify_interval_seconds=10,
                request_timeout_seconds=25,
                log_max_bytes=16384,
                resource_contract=support["path"],
            ),
        )
        print(json.dumps(dict(stage=args.stage, intent=intent, actual_job=None)))


if __name__ == "__main__":
    main()
