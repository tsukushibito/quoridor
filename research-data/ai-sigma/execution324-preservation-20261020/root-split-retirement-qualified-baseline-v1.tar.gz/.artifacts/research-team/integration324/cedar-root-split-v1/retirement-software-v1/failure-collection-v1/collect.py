"""Keep the failed release immutable and establish its actual reader STOP."""

import importlib.util
import json
from pathlib import Path


ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def main():
    loader = importlib.util.spec_from_file_location(
        "current_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    outer = json.loads((BASE / "build-runtime-v2/result.json").read_bytes())
    state = json.loads((BASE / "build-runtime-v2/state.json").read_bytes())
    proc_path = (
        BASE
        / "operation-release/root-split-retirement-genuine-baseline-release.process.json"
    )
    proc = json.loads(proc_path.read_bytes())
    spec = json.loads((BASE / "build-intent-release.json").read_bytes())
    output = (BASE / "build-runtime-v2/output.log").read_text()
    partial = json.loads(output.split("lifecycle partial facts: ", 1)[1])
    assert outer["job_id"] == "57e4eb4b-8f18-47cd-8fe3-a645b7191506"
    assert (
        outer["exit_code"] == 1
        and outer["direct_child_reaped"]
        and outer["cleanup_complete"]
    )
    assert outer["remaining"] == []
    assert (
        partial["status"] == "FAILED"
        and partial["checks"][-1]["guardian_return"] is None
    )
    assert partial["primary"]["message"] == proc["error"] == "owned allocation limit"
    assert (
        proc["exit_code"] == -15
        and proc["direct_child_reaped"]
        and proc["cleanup_complete"]
    )
    assert proc["remaining"] == [] and proc["handle_closes_complete"]
    assert not (BASE / "operation-release/candidate.json").exists()
    with (OUT / "original-partial-failed-facts.json").open("x") as stream:
        json.dump(partial, stream, indent=2)
        stream.write("\n")
    members = [proc["child"], state["child"]]
    for row in partial["checks"][:-1]:
        lc.settled(row["guardian_return"])
        members.append(row["guardian_return"]["child"])
    known = []
    for member in members:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, current=fresh))
    with lc.lease():
        lc.source_check(spec["source"])
        assert not Path(spec["TMP"]).exists()
        target = Path(spec["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker == dict(
            writer=spec["writer"],
            target=str(target),
            support_sha256=spec["support"]["sha256"],
        )
        seen = set()
        roots = [
            dict(path=str(p), allocated_B=lc.allocated(p, seen=seen))
            for p in lc.charged_roots(spec)
        ]
        result = dict(
            status="ORIGINAL_RELEASE_FAILED_STORAGE_LIMIT_ACTUAL_SOURCE_STOP_NO_BUILD",
            original_job=lc.artifact_ref(BASE / "build-runtime-v2/result.json"),
            original_failed_process=lc.artifact_ref(proc_path),
            original_partial_facts=lc.artifact_ref(
                OUT / "original-partial-failed-facts.json"
            ),
            outer_seconds_once=outer["wall_seconds"],
            nested_added=0,
            known_exact_fresh_absence=known,
            affected_fullroot_union_once=roots,
            allocated_B=sum(row["allocated_B"] for row in roots),
            issued_whole_B=spec["limits"]["owned_B"],
            cache_retained="Only stopped partial standardCargo cache; no compiler-finished/candidate/BUILD. Future entry requires concrete storage correction, not unchanged automatic retry.",
            original_partial_domain="FAILED/guardianNULL/capturefalse/cleanupfalse/TMPsecondary; diskprocesscleanuptrue/reaped/pendingmask/persistattempted preserved separately",
            source_leases=[],
            TMP=[],
            remaining_owned=[],
            notification_supervisor="Separate endedjob notification lifetime, no source reader or futurequiet claim",
            globalactual_fullfees="UNKNOWN",
        )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(status=result["status"], allocated_B=result["allocated_B"])))


if __name__ == "__main__":
    main()
