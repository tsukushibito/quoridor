"""Collect two affected Clippy checks once and retire their stopped cache."""

import importlib.util
import json
import shutil
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper = load(
        "existing_helpers",
        Path(
            "/workspaces/quoridor/.artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py"
        ),
    )
    lc = load("current_lifecycle", ROOT / "scripts/dev/research-lifecycle.py")
    outer = json.loads((BASE / "check-runtime-v1/result.json").read_bytes())
    prefix = json.loads((BASE / "operation-prefix/prefix-result.json").read_bytes())
    intent = json.loads((BASE / "build-intent-prefix.json").read_bytes())
    assert outer["job_id"] == "3238ef34-1d7c-4a8b-9178-ad1846b4fd69"
    assert outer["outcome"] == "succeeded" and outer["exit_code"] == 0
    assert (
        outer["direct_child_reaped"]
        and outer["cleanup_complete"]
        and not outer["remaining"]
    )
    assert (
        prefix["status"] == "PASS_TEST_LINT_PREFIX_ONLY" and prefix["cleanup_complete"]
    )
    assert len(prefix["checks"]) == 2
    known = []
    state = json.loads((BASE / "check-runtime-v1/state.json").read_bytes())
    for row in prefix["checks"]:
        assert (
            row["role"] == "lint"
            and row["status"] == "PASS"
            and row["cargo"]["warning_count"] == 0
        )
        lc.settled(row["guardian_return"])
        member = row["guardian_return"]["child"]
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    for member in [state["child"]]:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    with lc.lease():
        lc.source_check(intent["source"])
        assert not Path(intent["TMP"]).exists()
        target = Path(intent["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker == dict(
            writer=intent["writer"],
            target=str(target),
            support_sha256=intent["support"]["sha256"],
        )
        assert not (target / "debug").exists()
        cache = target / "release"
        assert cache.is_dir() and not cache.is_symlink()
        retired_B = lc.allocated(cache)
        shutil.rmtree(cache)
        assert not cache.exists()
        seen = set()
        ended = sum(lc.allocated(p, seen=seen) for p in lc.charged_roots(intent))
    packet = dict(
        status="ACTUAL_TWO_AFFECTED_CLIPPY_WARNING0_PASS_SOURCE_STOP",
        outer=helper.ref(BASE / "check-runtime-v1/result.json"),
        prefix=helper.ref(BASE / "operation-prefix/prefix-result.json"),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        known_exact_fresh_absence=known,
        notification_supervisor=dict(
            original=state["supervisor"],
            current=lc.process.identity(
                lc.process.process_info(state["supervisor"]["pid"])
            ),
            scope="Finished job notification only; execute and source leases returned before notification loop, not future host quiet",
        ),
        affected_fullroot_union_allocated_B_once=ended,
        prior_test_scope="Only exact unchanged generic timedrootquality NN0 scope reused; no oldsuite/prototype/test execution",
        retired_stopped_Clippy_cache_B=retired_B,
        source_leases=[],
        TMP=[],
        remaining=[],
        retired_only="Stopped ownedClippy cache retired only after actual bothlint waits/reaps/sourceEXlease. All sources/results/privateimages/models/FAILED retained, no fee refund",
        software="AffectedAI/Runner alltargetClippy warning0/types retainedassertions, no tests executed. Genericunchanged NN0 scope byref. Genuine unmeasured cleanedbaseline opt3/codegen1/LTO=false release pending; no newscience/default/performance qualification.",
        host_future_quiet=False,
    )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        json.dump(packet, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(status=packet["status"], seconds=outer["wall_seconds"])))


if __name__ == "__main__":
    main()
