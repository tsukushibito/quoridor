"""Compact only stopped administrative snapshots and Git-restorable extraction copies."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess


ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    spec = json.loads(
        (BASE / "retirement-software-v1/build-intent-release.json").read_bytes()
    )
    stopped = json.loads(
        (
            BASE
            / "retirement-software-v1/failure-collection-final/completion-and-STOP.json"
        ).read_bytes()
    )
    assert (
        stopped["source_leases"] == stopped["TMP"] == stopped["remaining_owned"] == []
    )
    # Current retirement/admin delivery files are excluded; all selected phase
    # snapshots belong to already returned lifetimes, not the live Beads store.
    candidates = set()
    for base in (Path(p) for p in spec["owned_outputs"] if Path(p).name != "target"):
        for directory, dirs, names in os.walk(base):
            dirs[:] = [
                name
                for name in dirs
                if not name.startswith("private-image")
                and not name.endswith("-TMP")
                and name != "__pycache__"
                and not (Path(directory) / name).is_symlink()
            ]
            for name in names:
                path = Path(directory) / name
                if path.is_relative_to(OWN / "retirement-v1"):
                    continue
                if (
                    path.is_symlink()
                    or path.suffix != ".json"
                    or not 200000 < path.stat().st_size < 4 * 1024**2
                ):
                    continue
                if any(
                    token in name.lower()
                    for token in ("ready", "show", "note", "backup", "own-close")
                ):
                    candidates.add(path)
                elif name in {"Root-update.json", "root-update.json"}:
                    value = json.loads(path.read_bytes())
                    value = (
                        value[0]
                        if isinstance(value, list) and len(value) == 1
                        else value
                    )
                    if (
                        isinstance(value, dict)
                        and value.get("id") == "quoridor-4lc.324"
                    ):
                        candidates.add(path)
    compacted = []
    for path in sorted(candidates):
        before = path.stat()
        original_sha = sha(path)
        # Parse identifies a JSON administrative artifact only; no scientific
        # rows or old analysis/validator is executed.
        json.loads(path.read_bytes())
        destination = path.with_name(path.name + ".gz")
        with (
            destination.open("xb") as raw,
            gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as zipped,
            path.open("rb") as source,
        ):
            for block in iter(lambda: source.read(1024**2), b""):
                zipped.write(block)
        os.chmod(destination, stat.S_IMODE(before.st_mode))
        with gzip.open(destination, "rb") as restored:
            digest = hashlib.sha256()
            size = 0
            for block in iter(lambda: restored.read(1024**2), b""):
                size += len(block)
                digest.update(block)
        assert size == before.st_size and digest.hexdigest() == original_sha
        after = path.stat()
        assert (after.st_ino, after.st_size, after.st_mtime_ns, after.st_mode) == (
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
            before.st_mode,
        )
        row = dict(
            original_path=str(path),
            raw_sha256=original_sha,
            raw_bytes=size,
            raw_mode=f"{stat.S_IMODE(before.st_mode):04o}",
            compressed_path=str(destination),
            compressed_sha256=sha(destination),
            original_allocated_B=before.st_blocks * 512,
            compressed_allocated_B=destination.stat().st_blocks * 512,
            restoration_verified=True,
        )
        # Keep recoverability discoverable before removing the unpacked cache.
        with (OUT / "admin-compaction-ledger.jsonl").open("a") as ledger:
            ledger.write(json.dumps(row) + "\n")
        path.unlink()
        compacted.append(row)
    publication = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"
    archive = publication / "root-split-original312-result-v1.tar.gz"
    manifest_path = publication / (archive.name + ".manifest.json")
    manifest = json.loads(manifest_path.read_bytes())
    assert manifest["full_stream_restore_hash_mode_verified"]
    assert (
        sha(archive)
        == manifest["sha256"]
        == "26d1a06378531b6cecce2e3248d6133c865c7afd3294753e8f65e4293150f975"
    )
    subprocess.run(
        ["git", "diff", "--quiet", "HEAD", "--", str(archive), str(manifest_path)],
        cwd=ROOT,
        check=True,
    )
    # Only ended original312 extraction copies; canonical compressed records,
    # compact summaries/STOP/controls and all FAILED namespaces remain intact.
    extracted = []
    prefixes = [
        str(OWN / name) + "/"
        for name in ("numeric-fixed-depth156-v2", "numeric-clock156-v1")
    ]
    for row in manifest["members"]:
        path = Path(row["source"])
        if not any(str(path).startswith(prefix) for prefix in prefixes):
            continue
        member = str(path.relative_to(ROOT))
        if not (
            "/data/" in member
            or ("/collection-v1/" in member and path.name.startswith("saved-rows-"))
            or path.name.endswith(".full.log")
        ):
            continue
        assert path.is_file() and not path.is_symlink()
        info = path.stat()
        assert sha(path) == row["sha256"] and info.st_size == row["bytes"]
        assert stat.S_IMODE(info.st_mode) == int(row["mode"], 8)
        fact = dict(
            original_path=str(path),
            canonical_archive=str(archive),
            archive_member=row["member"],
            raw_sha256=row["sha256"],
            raw_mode=row["mode"],
            raw_bytes=row["bytes"],
            allocated_extraction_B=info.st_blocks * 512,
            restoration="Verified archive full-stream restore plus unchanged current archive SHA/member/raw identity; Git9a37ac52 remote verified. No active consumer after both native+normal/analysis/review STOP.",
        )
        with (OUT / "ended-extraction-ledger.jsonl").open("a") as ledger:
            ledger.write(json.dumps(fact) + "\n")
        path.unlink()
        extracted.append(fact)
    result = dict(
        status="LOSSLESS_ADMIN_COMPACTION_AND_ENDED_GIT_EXTRACTION_RETIREMENT",
        admin_files=len(compacted),
        admin_before_B=sum(row["original_allocated_B"] for row in compacted),
        admin_after_B=sum(row["compressed_allocated_B"] for row in compacted),
        ended_original312_extraction_files=len(extracted),
        ended_extraction_B=sum(row["allocated_extraction_B"] for row in extracted),
        canonical_archive_sha256=manifest["sha256"],
        scope="No scientific record/RAW bytes or FAILED/NULL/mask/UNKNOWN/cost proof lost or rewritten. Administrative snapshots losslessly compressed locally; original312 canonical normal data retained exactly in pushed Git archive with raw identities/modes. No model/image/source/input/active runtime/DB/lock/cache targeted, no scientific refund/lending or new quota.",
    )
    (OUT / "compaction-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
