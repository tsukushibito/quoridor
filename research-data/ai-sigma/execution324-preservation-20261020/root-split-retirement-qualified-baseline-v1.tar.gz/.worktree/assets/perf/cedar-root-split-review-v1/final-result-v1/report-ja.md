# 28.4 原312比較と目的終了時の撤去境界

原312の有限解釈は **CONCLUSION_CLEAR、essential 0／ordinary 0**。凍結したALL156固定depth完了条件を満たさないため、完了時間の資格とserious fixed regressionはUNKNOWN、実用性はUNRESOLVED_FIXED_COMPLETED_TIME_CENSORINGという保存結論が妥当である。Rootはminimum a808f524を受け入れた。採用・default変更・新しい実験の権利は生じない。

| 固定depthのmode | DepthComplete | NodeLimit UNKNOWN |
| --------------- | ------------: | ----------------: |
| LOCAL1          |            52 |                 0 |
| LAZY2           |            41 |                11 |
| ROOT_SPLIT2     |            52 |                 0 |

c87のALL156条件は偽である。完了したmode同士や有利なrootだけへの置換、capped時間を完了時間へ扱う救済は行わない。保存allcall split／Lazy Search比0.8689977は記述値であり、完了時間による実用性の資格ではない。元root4だけのD6→D5前向きamendmentとtwo6 lifetime groupingを照合し、他25depth・原順序・fullhistory・cap・session・条件を変える結果後選択を認めていない。

clock156件は全main callback completed depth≥1かつreceipt≤.100s、terminal p95 linear .09975053175／max .1051407で、固定.110／.125の有限安全条件を満たす。各modeは50 TimeLimit UNKNOWN＋2 DepthCompleteであり、要求D64の完了を意味しない。split対LOCAL1の深さはhigher 6／equal 45／lower 1、対LAZY2は4／45／3、action差は各3で、PV・value bits差も保存されている。clock Search比1.0017337とwhole比1.0479203は別の時間区分として保持する。selective work・censoring・warm history・scheduleが異なり、同一仕事の速度、棋力、原因の証明へ広げない。

原12 normal manifest/data PASS、312calls／72sessions／101,961,543nodesの保存custodyを再利用した。legal／PV head／weighted-history／parent restore／aggregate 1M cap／worker error／requested-effectiveの観測対応は有限範囲のもので、全faultやfull PV oracleを資格化しない。診断26calls／25,000,193nodesを加え、338calls／126,961,736nodesを一度だけ保持する。comparison outer 177.31060996104497sを一度計上し、nested加算0。未使用分からrefill・loan・返金・Search・game・RNG・CIを発行しない。full fees／global actual／physical NN／family peak／later tailsはUNKNOWN。

26の歴史的露出prefix、3families、6同色時系列warm sessionsは独立な未見標本ではない。stock0は真正2rootで希望6に4不足する。main callback、terminal Search/drain、arena parent receipt、setup/reset/drop/wholeを混同しない。新しい共通qualified tuple d0c804／9251／HEAD34b19c9の保存対応を再利用し、旧imageとのN1 empirical parity／wallはUNMEASUREDのまま残す。

同leafに追加されたpurpose-end撤去の固定binding **e6f23bfe／35,422B／0644**は、別の **SOURCE_CLEAR、essential 0／ordinary 0** と判定した。Rootの追加source受入れ前はown28.4をin_progressで保持する。

11subjectの差分は、wholly28 root_split.rs／専用tests、alphaのexclusive transportとsplit root分岐、Lazyのclient/server／mode setter／command／report、runner／measurement／LC設定・出力・専用tests、元3ownerのchild-work／iteration-work observerおよび必須false fixture fieldを呼出側とともに削除する。復元されたoriginal-rank共通root loopはchild/PVS再探索、Err伝播、final control後のExact TT挿入とmain completionを保つ。Lazy2のowned persistent pool、weighted-root Arc、WorkerBudget、helper drain、fatal Err時clear/drop、shutdown/joinは維持される。

generic21／23のfirst/latest/pending orderingとhistory provenance、実calleeのtimed rootquality／history+time拒否、selected abnormal＋NN0を保護する。generic root_work_knownは既存row workの有無を示す欄として残り、retired shallow-key拒否も意図的に残る。Halfやaspirationを復活させない。9surviving postのSHA／size／modeを読取前に確認し、与えられたpre28 byte対応を必要な静的範囲で再利用した。GNU／source proofを再実行せず、whole old ownerの上書きを承認しない。

このSOURCE_CLEARはtype／software／runtime／performance資格ではない。Rootの疎合成、affected AI＋Runner all-target Clippy、新しい真正baseline releaseは別工程で、旧9251へのaliasを認めない。purpose-end削除は、root splitting全般が無効・有害だという科学結論ではない。

根拠は [有限minimum](minimum.json)、[保存対応](saved-correspondence.json)、[有限reader STOP](reader-STOP.json)、[撤去source minimum](retirement-source-v1/minimum.json)、[撤去source対応](retirement-source-v1/source-correspondence.json)、[撤去reader STOP](retirement-source-v1/reader-STOP.json) に保存した。Root324へそれぞれminimumと実STOPを先に一度送付し、配信acceptedをRootの内容受入れと混同していない。

target import／test／compiler／Cargo／native／model／RAW／archive／geometry／validator／FINALIZE／GNU proof／RNG／CI／Searchの再演0。Main／Git／index／Cargo／docs／他OWN write0。実scope内helperはdirectwait/reap、handles close、既知PID/start/bootのfresh absence/difference、TMP／source leasesなしを保存し、全hostや未来quietは主張しない。USERPAUSE323／342.17、seals／newE／oldfits96、default1／rootSplitOFF／Current、models／foreign、全FAILED／NULL／masks／UNKNOWN fees、decimal50GB、取消consultation actual8、独立27／29／16.1を保全する。

Root最終受入れ52519309／2,561B／0644で有限解釈と撤去SOURCE_ONLYの両scopeが受理された。own28.4は受入れpacketのexact reasonを変更せず一度だけ通常closeし、CLOSED・元assignee・reason完全一致、backup前後を確認した。[closure receipt](admin-v1/closure-receipt.json)を保存した。genuine baseline release57e4eb4bは別工程であり、本reviewはその成功を認定しない。
