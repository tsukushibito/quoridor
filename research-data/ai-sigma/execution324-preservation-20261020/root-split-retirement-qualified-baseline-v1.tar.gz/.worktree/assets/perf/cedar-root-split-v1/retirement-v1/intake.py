"""Read only immutable own28 source custody and current source subjects."""

import json
from pathlib import Path
import sys

sys.path.insert(
    0, str(Path(__file__).resolve().parents[1] / "compatible-retirement-v1")
)
from compose_v2 import command, save  # noqa: E402

own = Path(__file__).resolve().parents[1]
out = Path(__file__).resolve().parent
for name, args in [
    ("ready", ["ready", "--json"]),
    ("show", ["show", "quoridor-4lc.324.28", "--json"]),
]:
    r = command(["bash", "scripts/dev/beads.sh", *args])
    save(out / (name + ".json"), r)
    if name == "show":
        issue = json.loads(r["stdout"])[0]
        assert (
            issue["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
            and issue["status"] == "in_progress"
        )
paths = [
    "prototype-v1/fixed-v1/binding.json",
    "compatible-retirement-v1/binding.json",
    "prototype-v1/fixture-repair-v1/binding.json",
    "prototype-v1/caller-repair-v1/binding.json",
    "prototype-v1/fixed-v1/software-recipe.json",
]
for path in paths:
    d = json.loads((own / path).read_text())
    print(path, json.dumps(d, indent=2)[:42000])
