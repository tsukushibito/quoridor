"""Compose only purpose-end own28 inverse fragments onto immutable current source."""

import ast
from datetime import datetime, timezone
import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

sys.path.insert(
    0, str(Path(__file__).resolve().parents[1] / "compatible-retirement-v1")
)
from compose_v2 import ROOT, ref, save  # noqa: E402

OWN = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
BASE = "34b19c9a90b0a44566a0424e6c891979cab03c26"
LEGACY = "9126a4a1e861afe46c641ac5d13c0b27e2238a84"


def run(argv, cwd=ROOT):
    with subprocess.Popen(
        argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as p:
        out, err = p.communicate(timeout=60)
        code = p.wait()
    result = dict(
        argv=argv,
        cwd=str(cwd),
        returncode=code,
        stdout=out.decode(),
        stderr=err.decode(),
        directwait_reaped=True,
        handles_closed=p.stdout.closed and p.stderr.closed,
    )
    assert code == 0, result
    return result


def reverse_fragments(current, before, post, subject, label):
    aa, bb = post.splitlines(True), before.splitlines(True)
    edits = []
    for group in difflib.SequenceMatcher(
        None, aa, bb, autojunk=False
    ).get_grouped_opcodes(3):
        old = "".join(aa[group[0][1] : group[-1][2]])
        new = "".join(bb[group[0][3] : group[-1][4]])
        assert current.count(old) == 1, (subject, label, old[:200], current.count(old))
        current = current.replace(old, new, 1)
        edits.append(
            dict(
                scope=label,
                removed_fragment_sha256=hashlib.sha256(old.encode()).hexdigest(),
                replacement_fragment_sha256=hashlib.sha256(new.encode()).hexdigest(),
                original_fragment_occurrences=1,
                only_exact_own_fragment=True,
            )
        )
    return current, edits


def main():
    proto = json.loads((OWN / "prototype-v1/fixed-v1/binding.json").read_text())
    diag = json.loads((OWN / "diagnostic-source-v1/fixed-binding.json").read_text())
    subjects = [s["subject"] for s in proto["subjects"]] + [
        "crates/quoridor-ai/src/neighbour_opportunity.rs",
        "crates/quoridor-runner/src/measurement_ordering394_tests.rs",
    ]
    current = {}
    post = {}
    edits = {}
    modes = {}
    listing = run(["git", "ls-tree", BASE, "--", *subjects])
    for line in listing["stdout"].splitlines():
        meta, path = line.split("\t")
        modes[path] = meta.split()[0][-4:]
    assert set(modes) == set(subjects)
    for subject in subjects:
        cached = OUT / "before" / Path(subject + ".gz")
        current[subject] = (
            gzip.decompress(cached.read_bytes()).decode()
            if cached.exists()
            else run(["git", "show", BASE + ":" + subject])["stdout"]
        )
        if not cached.exists():
            cached.parent.mkdir(parents=True, exist_ok=True)
            with cached.open("xb") as f:
                f.write(gzip.compress(current[subject].encode(), mtime=0))
        post[subject] = current[subject]
        edits[subject] = []
    for s in proto["subjects"]:
        subject = s["subject"]
        if s["new"]:
            assert current[subject] == Path(s["post"]["path"]).read_text()
            post[subject] = None
            edits[subject].append(
                dict(
                    scope="Delete wholly28 comparison module/testmodule",
                    all_bytes_owned_by28=True,
                )
            )
            continue
        before = Path(s["before"]["path"]).read_text()
        expected = Path(s["post"]["path"]).read_text()
        if subject == "crates/quoridor-runner/src/config.rs":
            fixed = json.loads(
                (OWN / "prototype-v1/fixture-repair-v1/binding.json").read_text()
            )
            expected = Path(fixed["post"]["path"]).read_text()
        assert current[subject] == expected, subject
        post[subject], ee = reverse_fragments(
            post[subject],
            before,
            expected,
            subject,
            "Remove28 prototype; retain exact before statements only where feature required",
        )
        edits[subject] += ee
    for s in diag["subjects"]:
        subject = s["subject"]
        before = gzip.decompress(Path(s["before_gzip"]["path"]).read_bytes()).decode()
        expected = Path(s["post"]["path"]).read_text()
        post[subject], ee = reverse_fragments(
            post[subject],
            before,
            expected,
            subject,
            "Remove28 root-child/iteration work observer only; retain generic21/23 ordering/timedquality",
        )
        edits[subject] += ee
    subject = "crates/quoridor-runner/src/measurement_ordering394_tests.rs"
    field = "            root_split: false,\n"
    if post[subject].count(field) != 1:
        field = "        root_split: false,\n"
    assert post[subject].count(field) == 1
    post[subject] = post[subject].replace(field, "", 1)
    edits[subject].append(
        dict(
            scope="Remove obsolete boolfalse Settings field only",
            existing_assertions_and_inputs_unchanged=True,
        )
    )
    mapping = []
    for subject in subjects:
        if post[subject] is None:
            path = None
        else:
            path = OUT / "post" / subject
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("x") as f:
                f.write(post[subject])
            path.chmod(int(modes[subject], 8))
        mapping.append(
            dict(
                subject=subject,
                before_gzip=ref(OUT / "before" / Path(subject + ".gz")),
                before_raw_sha256=hashlib.sha256(current[subject].encode()).hexdigest(),
                before_bytes=len(current[subject].encode()),
                mode=modes[subject],
                post_path=str(path) if path else None,
                edits=edits[subject],
            )
        )
    print(
        json.dumps(
            save(
                OUT / "composed-v1.json",
                dict(
                    at=datetime.now(timezone.utc).isoformat(),
                    immutable_current_git=BASE,
                    subjects=mapping,
                    status="PRIVATE_COMPOSED_NOT_FORMATTED_NOT_TYPED_NOT_REVIEWED",
                    no_whole_old_owner_overwrite=True,
                    Main_Git_Cargo_docs_writes=0,
                    tests_compiler_native_model_RAW_RNG=0,
                ),
            )
        )
    )
    rust = [
        str(OUT / "post" / s)
        for s in subjects
        if s.endswith(".rs") and post[s] is not None
    ]
    fmt = run(["rustfmt", "--edition", "2024", "--config", "skip_children=true", *rust])
    check = run(
        [
            "rustfmt",
            "--check",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            *rust,
        ]
    )
    # Format just the two changed normal owners at the canonical100-column boundary.
    lc = OUT / "post/scripts/dev/research-lifecycle.py"
    module = ast.parse(lc.read_text())
    py_format = []
    for name in ["native_cpu_cores", "measurement_config"]:
        node = next(
            n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == name
        )
        before_ast = ast.dump(ast.parse(lc.read_text()), include_attributes=False)
        py_format.append(
            run(
                [
                    sys.executable,
                    "-m",
                    "ruff",
                    "format",
                    "--config",
                    str(ROOT / "pyproject.toml"),
                    "--line-length",
                    "100",
                    "--range",
                    f"{node.lineno}-{node.end_lineno}",
                    str(lc),
                ]
            )
        )
        assert (
            ast.dump(ast.parse(lc.read_text()), include_attributes=False) == before_ast
        )
    tests = OUT / "post/scripts/dev/test_research_lifecycle.py"
    ast.parse(tests.read_text())
    # Deletion adds no handwritten test code; keep every remaining test byte.
    py_lint = run(
        [
            sys.executable,
            "-m",
            "ruff",
            "check",
            "--no-cache",
            "--config",
            str(ROOT / "pyproject.toml"),
            str(lc),
            str(tests),
        ]
    )
    protected = []
    for subject in subjects:
        if post[subject] is None:
            continue
        actual = (OUT / "post" / subject).read_text()
        legacy = run(["git", "show", LEGACY + ":" + subject])["stdout"]
        assert actual == legacy, (
            "Necessary owner differs from protected pre28 canonical source",
            subject,
        )
        assert (
            "root_split" not in actual
            and "RootSplit" not in actual
            and "RootBranch" not in actual
        ), subject
        assert (
            "root_aspiration" not in actual and "shallow_main_history" not in actual
        ), subject
        protected.append(
            dict(
                subject=subject,
                post=ref(OUT / "post" / subject),
                exact_protected_pre28_git=LEGACY,
                legacy_raw_sha256=hashlib.sha256(legacy.encode()).hexdigest(),
                exact_bytes=True,
                scope="Comparison only; finalpost constructed by sparse inverse own28 fragments, never replaced wholesale with old owner. Current100%/generic21/23/16.1/local1/Lazy2 kernels and oldtests preserved.",
            )
        )
    # Preserve the remaining canonical Python test methods exactly, remove only28 method.
    py_subject = "scripts/dev/test_research_lifecycle.py"

    def methods(text):
        lines = text.splitlines(True)
        tree = ast.parse(text)
        return {
            n.name: "".join(lines[n.lineno - 1 : n.end_lineno])
            for n in ast.walk(tree)
            if isinstance(n, ast.FunctionDef)
        }

    before_methods = methods(current[py_subject])
    after_methods = methods((OUT / "post" / py_subject).read_text())
    removed = set(before_methods) - set(after_methods)
    assert removed == {
        "test_root_split_measurement_requires_explicit_two_worker_boolean"
    }
    assert all(before_methods[k] == v for k, v in after_methods.items())
    forward = []
    inverse = []
    for s in mapping:
        subject = s["subject"]
        before = current[subject]
        after = (OUT / "post" / subject).read_text() if s["post_path"] else ""
        forward.extend(
            difflib.unified_diff(
                before.splitlines(True),
                after.splitlines(True),
                fromfile="a/" + subject,
                tofile="b/" + subject if after else "/dev/null",
                n=3,
            )
        )
        inverse.extend(
            difflib.unified_diff(
                after.splitlines(True),
                before.splitlines(True),
                fromfile="a/" + subject if after else "/dev/null",
                tofile="b/" + subject,
                n=3,
            )
        )
        s["post"] = ref(OUT / "post" / subject) if after else None
        s.pop("post_path")
    (OUT / "forward.patch").write_text("".join(forward))
    (OUT / "inverse.patch").write_text("".join(inverse))
    custody = OUT / "roundtrip-v1"
    tree = custody / "tree"
    tree.mkdir(parents=True)
    for s in mapping:
        path = tree / s["subject"]
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(current[s["subject"]])
        path.chmod(int(s["mode"], 8))
    applied = run(
        [
            "patch",
            "--batch",
            "--fuzz=0",
            "--no-backup-if-mismatch",
            "-p1",
            "-i",
            str(OUT / "forward.patch"),
        ],
        tree,
    )
    assert all(
        w not in applied["stdout"].lower()
        for w in ["offset", "fuzz", "reversed", "failed"]
    )
    for s in mapping:
        path = tree / s["subject"]
        if s["post"] is None:
            assert not path.exists()
        else:
            assert (
                path.read_bytes() == Path(s["post"]["path"]).read_bytes()
                and f"{path.stat().st_mode & 0o777:04o}" == s["mode"]
            )
    restored = run(
        [
            "patch",
            "--batch",
            "--fuzz=0",
            "--no-backup-if-mismatch",
            "-p1",
            "-i",
            str(OUT / "inverse.patch"),
        ],
        tree,
    )
    assert all(
        w not in restored["stdout"].lower()
        for w in ["offset", "fuzz", "reversed", "failed"]
    )
    for s in mapping:
        path = tree / s["subject"]
        assert (
            path.read_text() == current[s["subject"]]
            and f"{path.stat().st_mode & 0o777:04o}" == s["mode"]
        )
        path.unlink()
    for parent, dirs, files in os.walk(tree, topdown=False):
        assert not files
        for d in dirs:
            Path(parent, d).rmdir()
    tree.rmdir()
    proof = save(
        OUT / "source-custody-once.json",
        dict(
            forward=applied,
            inverse=restored,
            zero_fuzz_nooffset=True,
            allbytes_modes_roundtrip=True,
            temporary_sparse_tree_removed=True,
            scope="ONE new retirement-packet custody roundtrip, not old successful source/test/native proof replay",
        ),
    )
    correspondence = save(
        OUT / "protected-correspondence.json",
        dict(
            protected=protected,
            all_other_python_test_methods_exact=True,
            removed_python_method=sorted(removed),
            all11_subjects_only=True,
            whole_old_owner_replacement=False,
            generic_tests_retained="Pre-existing LOCAL/Lazy fullhistory/coherentTT/typedbounds/nodebudget/cancel/reset/drop + generic ordering/timedrootquality/NN0 tests remain exactpre28 source. No oldsuite executed.",
            removed_definitions="prototype AI6+RunnerLIB2+Python1, diagnostic rootworkAI1+RunnerLIB1 only. Modules/source evidence/images/results retained in Git/OWN.",
            source_only_no_SOURCE_CLEAR=True,
        ),
    )
    recipe = save(
        OUT / "affected-software-recipe.json",
        dict(
            status="ROOT_ONLY_PENDING_NOT_EXECUTED",
            typecheck="Affected all-target Clippy also types legacy fixture after obsolete boolfield removal; no separate redundant oldsuite.",
            AI_Clippy=[
                "cargo",
                "clippy",
                "-p",
                "quoridor-ai",
                "--all-targets",
                "--features",
                "research-diagnostics",
                "--",
                "-D",
                "warnings",
            ],
            Runner_Clippy=[
                "cargo",
                "clippy",
                "-p",
                "quoridor-runner",
                "--all-targets",
                "--features",
                "measurement,quoridor-inference/claustrophobia",
                "--",
                "-D",
                "warnings",
            ],
            Runner_release=[
                "cargo",
                "build",
                "--release",
                "-p",
                "quoridor-runner",
                "--features",
                "measurement,quoridor-inference/claustrophobia",
                "--bin",
                "quoridor-runner",
            ],
            normal_Build="Root binds actual maintained source/tools/env/currentcallers/serialtarget/resources and fresh genuine baseline image/manifest at compatible actualSTOP; unmeasured baseline, not old9251alias.",
            new_test_definitions=0,
            old_success_tests_to_execute=[],
            generic_old_test_reuse="Only exact protected source scopes; no empirical parity/model/native qualification from source or lint.",
            private_compiler_tests_native_model_RAW_RNG=0,
        ),
    )
    binding = save(
        OUT / "binding.json",
        dict(
            issue="quoridor-4lc.324.28",
            at=datetime.now(timezone.utc).isoformat(),
            status="FIXED_PRIVATE_PURPOSE_END_RETIREMENT_NOT_TYPED_NOT_REVIEWED_NOT_ADOPTED",
            immutable_current_git=BASE,
            source_start=ref(OUT / "actual-source-start.json"),
            prototype_binding=ref(OWN / "prototype-v1/fixed-v1/binding.json"),
            original_diagnostic_binding=ref(
                OWN / "diagnostic-source-v1/fixed-binding.json"
            ),
            subjects=mapping,
            forward=ref(OUT / "forward.patch"),
            inverse=ref(OUT / "inverse.patch"),
            source_custody=proof,
            protected_correspondence=correspondence,
            affected_software_recipe=recipe,
            Rust_format=fmt,
            Rust_format_check=check,
            Python_changed_owner_format=py_format,
            Python_affected_lint=py_lint,
            Python_parser_AST_same_across_format=True,
            purpose="Remove only exhausted28 root_split prototype/transport/config/namespace/output/consumer/dedicatedtests and original28 rootchild-work observer; keep all evidence/Git/images/models/default1/Lazy2/Current100%/generic features.",
            Main_Git_Cargo_docs_otherOWN_writes=0,
            tests_compiler_native_model_inputpayload_RAW_RNG=0,
            review_dispatch_selfclear=False,
        ),
    )
    print(json.dumps(dict(binding=binding, source_custody=proof, recipe=recipe)))


if __name__ == "__main__":
    main()
