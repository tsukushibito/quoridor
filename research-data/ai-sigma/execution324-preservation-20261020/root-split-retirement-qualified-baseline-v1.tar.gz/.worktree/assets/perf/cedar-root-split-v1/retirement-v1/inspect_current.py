"""Trace only own28 deltas against immutable current canonical subjects."""

import difflib
import gzip
import json
from pathlib import Path
import sys

sys.path.insert(
    0, str(Path(__file__).resolve().parents[1] / "compatible-retirement-v1")
)
from compose_v2 import command, save  # noqa: E402

own = Path(__file__).resolve().parents[1]
out = Path(__file__).resolve().parent
base = "34b19c9a90b0a44566a0424e6c891979cab03c26"
p = json.loads((own / "prototype-v1/fixed-v1/binding.json").read_text())
subjects = [s["subject"] for s in p["subjects"]] + [
    "crates/quoridor-ai/src/neighbour_opportunity.rs",
    "crates/quoridor-runner/src/measurement_ordering394_tests.rs",
]
current = {}
for subject in subjects:
    current[subject] = command(["git", "show", base + ":" + subject])["stdout"]
for s in p["subjects"]:
    subject = s["subject"]
    oldpost = Path(s["post"]["path"]).read_text()
    if oldpost != current[subject]:
        print("CURRENT ROOT MECHANICAL DIFF", subject)
        print(
            "".join(
                difflib.unified_diff(
                    oldpost.splitlines(True),
                    current[subject].splitlines(True),
                    fromfile="reviewed-post",
                    tofile="current",
                    n=4,
                )
            )
        )
    if s["before"]:
        before = Path(s["before"]["path"]).read_text()
        print("OWN28 ORIGINAL DELTA", subject)
        print(
            "".join(
                difflib.unified_diff(
                    before.splitlines(True),
                    oldpost.splitlines(True),
                    fromfile="before",
                    tofile="post",
                    n=3,
                )
            )
        )
# First actual private delta: delete only the two wholly own28 prototype modules.
start = []
for subject in [
    "crates/quoridor-ai/src/root_split.rs",
    "crates/quoridor-ai/src/root_split_tests.rs",
]:
    raw = current[subject].encode()
    path = out / "before" / Path(subject + ".gz")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as f:
        f.write(gzip.compress(raw, mtime=0))
    patch = "".join(
        difflib.unified_diff(
            current[subject].splitlines(True),
            [],
            fromfile="a/" + subject,
            tofile="/dev/null",
            n=3,
        )
    )
    pp = out / (Path(subject).name + ".delete.patch")
    pp.write_text(patch)
    start.append(
        dict(
            subject=subject,
            before_gzip=str(path),
            post=None,
            delete_patch=str(pp),
            scope="Wholly own28 comparison-only module; Git/currentimage/evidence retained; no Main deletion",
        )
    )
print(
    json.dumps(
        save(
            out / "actual-source-start.json",
            dict(
                immutable_current_git=base,
                private_actual_delta=start,
                Main_Git_Cargo_docs_writes=0,
                tests_compiler_native_model_RAW_RNG=0,
            ),
        )
    )
)
