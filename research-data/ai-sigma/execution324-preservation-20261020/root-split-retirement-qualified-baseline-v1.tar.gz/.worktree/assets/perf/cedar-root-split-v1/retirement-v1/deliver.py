"""Return the fixed private retirement packet, then ordinary own note and backup."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import stat
import sys

sys.path.insert(
    0, str(Path(__file__).resolve().parents[1] / "compatible-retirement-v1")
)
from compose_v2 import ROOT, ref, save, command  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
ISSUE = "quoridor-4lc.324.28"
ACTOR = "codex:01a11004-79f3-7c20-872c-432a2c347664"


def main():
    gp = OUT / "finish-guard-v4/result.json"
    guard = json.loads(gp.read_text())
    assert guard["status"] == "PASS" and guard["TMP_remaining"] == []
    fresh = []
    for old in [
        guard["controller"],
        *[c["guardian_return"]["child"] for c in guard["checks"]],
    ]:
        info = process.process_info(old["pid"])
        actual = process.identity(info) if info else None
        assert actual != old
        fresh.append(dict(original=old, current=actual, exact_absent_or_different=True))
    binding = json.loads((OUT / "binding.json").read_text())
    assert (
        len(binding["subjects"]) == 11
        and sum(s["post"] is None for s in binding["subjects"]) == 2
    )
    assert all(
        ref(s["post"]["path"]) == s["post"] for s in binding["subjects"] if s["post"]
    )
    proof = json.loads((OUT / "source-custody-once.json").read_text())
    assert (
        proof["zero_fuzz_nooffset"]
        and proof["allbytes_modes_roundtrip"]
        and proof["temporary_sparse_tree_removed"]
    )
    total = logical = 0
    seen = set()
    for parent, _, files in os.walk(OUT):
        for name in files:
            p = Path(parent) / name
            st = p.lstat()
            assert stat.S_ISREG(st.st_mode)
            inode = (st.st_dev, st.st_ino)
            if inode not in seen:
                seen.add(inode)
                total += st.st_blocks * 512
                logical += st.st_size
    point = save(
        OUT / "ordinary-affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            root=str(OUT),
            allocated_B=total,
            logical_B=logical,
            inodes=len(seen),
            scope="ONE new private retirement subtree statpoint after source work; no global/oldholding scan, recharge, deletion or refund. Current bounded delivery/admin tails later UNKNOWN.",
            models_images_inputs_copied_B=0,
            globalactual_fees="UNKNOWN",
        ),
    )
    stop = save(
        OUT / "source-returned-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            actual_source_start=ref(OUT / "actual-source-start.json"),
            actual_source_start_guard=ref(OUT / "source-start-guard-v1/result.json"),
            fixed_source_helper_guard=ref(gp),
            fresh_exact_source_IDs=fresh,
            binding=ref(OUT / "binding.json"),
            source_custody=ref(OUT / "source-custody-once.json"),
            affected_point=point,
            source_leases=[],
            Main_reader=False,
            owned_source_remaining=[],
            TMP=[],
            host_future_quiet=False,
            current_delivery_admin_lifetime="Separate bounded helper; actual retirement-v1/delivery-guard-v1/result.json after body. No standing lease or futurequiet claim.",
        ),
    )
    explanation = OUT / "retirement-notes.md"
    explanation.write_text(
        "# Own28 purpose-end private retirement\n\n11 immutable34b19c9 subjects: delete root_split.rs/root_split_tests.rs; remove prototype config/session/transport/report/LC admissions and dedicated AI6/RunnerLIB2/Python1. Remove original28 root child/iteration work observer and dedicated AI1/RunnerLIB1. Remove now-obsolete Settings root_split:false field, keeping all old fixture assertions.\n\nConstructed through exact inverse own28 fragments, never whole-old-owner replacement. The9 surviving owners happen to match protected pre28 Git9126a4a exactly. LOCAL1/Lazy2/Current100% math, coherent TT/full weightedhistory/bounds/generation, cumulative budget/cancel/drain/reset/drop, ordinary child/LMR/PVS/order/FT and forced-root SMP refusal remain. Generic21/23/timedrootquality/selected-abnormal contract/NN0 tests remain. The generic root_work_known field and existing shallow_main_history retired-key refusal are intentionally retained. No Half/aspiration API restored.\n\nAll7 surviving Rust owners formatted/checked; changed LC2 owners formatted at100 with unchanged AST; affected Python lint/parser passed. A broad token-ban checker initially rejected the required retired-key refusal; corrected only that checker. A flat AST helper initially included the dedicated nested check function; corrected to top-level/class methods and retained all existing method bytes. Failed static/helper receipts preserved; target source was not changed for these checks. One new GNU forward/inverse custody roundtrip, fuzz0/nooffset/bytes+mode exact; temporary sparse tree removed. No old proof/test/native replay.\n\nPrivate source is NOT TYPED, NOT SOURCE_CLEAR, NOT ADOPTED, NOT baseline qualification. Root-only affected all-target AI+Runner Clippy and genuine normal Runner release recipe supplied; old suites execute0. Existing software/test source reuse only exact protected scopes. Important result review28.4/admin is independent. Main/Git/index/Cargo/docs and otherOWN writes0. Frozen results/source/Git/images/models/failed receipts remain.\n"
    )
    refs = dict(
        binding=ref(OUT / "binding.json"),
        forward=ref(OUT / "forward.patch"),
        inverse=ref(OUT / "inverse.patch"),
        protected_correspondence=ref(OUT / "protected-correspondence.json"),
        source_custody=ref(OUT / "source-custody-once.json"),
        software_recipe=ref(OUT / "affected-software-recipe.json"),
        notes=ref(explanation),
        actual_source_STOP=stop,
        ordinary_affected_point=point,
    )
    body = OUT / "Root-fixed-retirement-handoff.txt"
    body.write_text(
        "SAME High28 actualPRIVATE purpose-end retirement FIXED against immutable current34b19c9; no authorMain/Git/Cargo/docs/otherOWN writes, targetcompiler/tests/native/model/input/RAW/RNG0. ActualSOURCESTART at17:05:53.128472Z returned with substantive 2wholly28module deletion deltas; fixedsource/helper actualreturned17:10:01.456289Z. Original338/126961736nodes exhausted/no extra science or quota.\n\n11 exactsubjects: DELETE root_split.rs +root_split_tests.rs; sparseremove prototype alpha/lazy_smp/config/runtime/measurement/LC/Pythonfixture wiring, original3owner diagnostic rootchild/iterationobserver, obsolete measurement394 root_split:false field. Dedicated prototypeAI6+RunnerLIB2+Python1 and diagnosticAI1+RunnerLIB1 removed; old assertions and genericLOCAL/Lazy/coherentTT/history/budget/cancel/reset/drop/21/23/timedquality/selected-abnormal+NN0 retained. Existing root_work_known generic field and explicit retiredshallow-key refusals retained; no Half/asp API restoration. RootSplit exclusivechild entry removed; common child/negamax/reduced/LMR/PVS/rank/FT kernels and forcedSMP refusal preserved.\n\nAll9 surviving privateposts constructed via exact inverse ownfragments happen to equal protectedpre28 Git9126a4a byte-for-byte; usedonlyas correspondence, no wholeoldpost overwrite. All7 survivingRust format/check, LC2ownedfunctionsRuff100/ASTsame, affectedPythonlint/parser PASS. ONE newlynecessary GNUfuzz0/nooffset/bytes+mode roundtrip PASS; temporary sparse tree removed, originalsource/tests/proofs not replayed. Two causalstatic checker problems (retiredkeyrefusal tokenban and nestedtesthelper AST classification) corrected only checker; failed receipts retained/source unchanged. PrivateNOT_TYPED/NOT_SOURCE_CLEAR/not baseline.\n\nRoot-only precise affected all-target AI+RunnerClippy (also typing) + genuine maintained Runner release recipe; no oldsuccesssuite/newselectors needed merely for deletion. Future actualRoot adoption/affectedsoftware/baseline/sourceSTOP + requiredfinalacceptance still real ownclosure inputs, no parent/revieweradmin/ACK runtimegate. Max28.4 finalinterpretation independent, no authorreviewdispatch/reopen/selfclear. SourceCPU2/G18/F1GiB incl64/host4/G0 actualboundedhelpers directwait/reap/handles/freshIDs/TMPleases[]; no MainSH or standingreader. One ordinaryaffectedretirementpoint only, no globalwalk/sourceholdingrecharge/imagecopy/refund/loan. Currentdelivery/admin separate boundedtail/no futurehostquiet. Normalownnote+backup follows this promptfixedhandoff, own28 stayssameownerin_progress. All27/16.1/closed29/USERPAUSE/seals/default1/rootSplitOFF/models/foreign/FAILED/NULL/masks/UNKNOWNfees/50GB held.\n\n"
        + json.dumps(refs, indent=2)
        + "\n"
    )
    sent = command(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--issue",
            "quoridor-4lc.324",
            "--cwd",
            str(ROOT),
            "--body-file",
            str(body),
        ]
    )
    delivery = save(OUT / "Root-fixed-packet-delivery.json", sent)
    shown = command(["bash", "scripts/dev/beads.sh", "show", ISSUE, "--json"])
    issue = json.loads(shown["stdout"])[0]
    assert issue["assignee"] == ACTOR and issue["status"] == "in_progress"
    sr = save(OUT / "own-show-at-sourceSTOP.json", shown)
    note = (
        "Original28 purpose-complete private retirement fixed11subjects/2wholly28modules deleted, exact inverse own28 fragments against immutable34b19c9. Remaining9owners exactprotectedpre28Git9126 correspondence, no wholeoldpost overwrite/halfasp restoration. RemovedprototypeAI6Runner2Python1+diagnosticAI1Runner1 and obsoletefield; all genericLOCAL1/Lazy2/Currentmath/TT/fullhistory/budget/cancel/goal/restore/commonchild/LMR/PVS/ordering/FT/forcedSMP refusal/21/23/timedquality/selectedabnormalNN0 preserved. Format/parser/lint and ONE newGNUfuzz0/nooffset bytesmode roundtrip PASS; temporarytree removed. Staticchecker refusals retained and corrected checkeronly. NOT_TYPED/NOT_SOURCE_CLEAR/NOT_ADOPTED, no tests/compiler/Cargo/native/model/RAW/RNG/sourceproofreplay; RootsoleMain/Git/docs/actualaffectedsoftware+genuinebaseline later. Fixedpacket+actualsourceSTOP sentRoot beforeadmin, own28sameownerin_progress pendingnecessaryacceptance/disposition, Max28.4 independent/no reviewdispatch/force/ACKgate. Original338/noextra rights/allFAILED/UNKNOWN/defaults/models/pauses/seals/foreign/50GB retained. "
        + str(OUT / "binding.json")
        + " "
        + str(OUT / "source-returned-STOP.json")
    )
    nr = save(
        OUT / "own-note.json",
        command(
            ["bash", "scripts/dev/beads.sh", "update", ISSUE, "--append-notes", note]
        ),
    )
    backup = save(
        OUT / "backup-sync.json",
        command(["bash", "scripts/dev/beads.sh", "backup", "sync", "--json"]),
    )
    print(
        json.dumps(
            dict(refs=refs, delivery=delivery, own_show=sr, note=nr, backup=backup)
        )
    )


if __name__ == "__main__":
    main()
