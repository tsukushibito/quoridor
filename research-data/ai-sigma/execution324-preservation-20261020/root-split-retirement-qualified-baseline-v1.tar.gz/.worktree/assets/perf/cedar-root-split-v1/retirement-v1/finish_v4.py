"""Complete the remaining custody checks after correcting an overbroad static assertion.

No source recomposition or successful formatter prefix is repeated.
"""

import ast
from datetime import datetime, timezone
import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
from compose import BASE, LEGACY, OUT, OWN, run, ref, save


def main():
    composed = json.loads((OUT / "composed-v1.json").read_text())
    mapping = composed["subjects"]
    subjects = [s["subject"] for s in mapping]
    post = {s["subject"]: s["post_path"] for s in mapping}
    current = {
        s["subject"]: gzip.decompress(
            Path(s["before_gzip"]["path"]).read_bytes()
        ).decode()
        for s in mapping
    }
    trace = OUT / "compose-guard-v1/compose-format-custody.log"
    assert "AssertionError: scripts/dev/research-lifecycle.py" in trace.read_text()
    recovered = save(
        OUT / "completed-format-prefix-recovery-v2.json",
        dict(
            actual_failed_helper=ref(OUT / "compose-guard-v1/result.json"),
            actual_trace=ref(trace),
            completed_before_static_assertion=[
                "Rustfmt all7 surviving affected Rust owners",
                "Rustfmt --check all7",
                "Ruff format only LC native_cpu_cores/measurement_config at100, moduleASTsame",
                "Ruff affected LC/testmodule lint",
            ],
            reason="Helper uses checked directwait command results and reached later line262 retired-key-token assertion; all preceding calls returned0. Source already formatted and unchanged; no formatter/test/sourceproof replay.",
            causal_static_correction="Retain pre-existing explicit shallow_main_history rejection in LC; removed API is not restored. Exact protected pre28 canonical owner correspondence remains mandatory.",
        ),
    )
    fmt = check = recovered
    py_format = [recovered]
    py_lint = recovered
    protected = []
    for subject in subjects:
        if post[subject] is None:
            continue
        actual = (OUT / "post" / subject).read_text()
        legacy = run(["git", "show", LEGACY + ":" + subject])["stdout"]
        assert actual == legacy, (
            "Necessary owner differs from protected pre28 canonical source",
            subject,
        )
        assert (
            "root_split" not in actual
            and "RootSplit" not in actual
            and "RootBranch" not in actual
        ), subject
        if subject.endswith(".rs"):
            assert (
                "root_aspiration" not in actual and "shallow_main_history" not in actual
            ), subject
        protected.append(
            dict(
                subject=subject,
                post=ref(OUT / "post" / subject),
                exact_protected_pre28_git=LEGACY,
                legacy_raw_sha256=hashlib.sha256(legacy.encode()).hexdigest(),
                exact_bytes=True,
                scope="Comparison only; finalpost constructed by sparse inverse own28 fragments, never replaced wholesale with old owner. Current100%/generic21/23/16.1/local1/Lazy2 kernels and oldtests preserved.",
            )
        )
    # Preserve the remaining canonical Python test methods exactly, remove only28 method.
    py_subject = "scripts/dev/test_research_lifecycle.py"

    def methods(text):
        lines = text.splitlines(True)
        tree = ast.parse(text)
        nodes = [(n.name, n) for n in tree.body if isinstance(n, ast.FunctionDef)]
        nodes += [
            (c.name + "." + n.name, n)
            for c in tree.body
            if isinstance(c, ast.ClassDef)
            for n in c.body
            if isinstance(n, ast.FunctionDef)
        ]
        return {name: "".join(lines[n.lineno - 1 : n.end_lineno]) for name, n in nodes}

    before_methods = methods(current[py_subject])
    after_methods = methods((OUT / "post" / py_subject).read_text())
    removed = set(before_methods) - set(after_methods)
    assert removed == {
        "LifecycleDataAndPaths.test_root_split_measurement_requires_explicit_two_worker_boolean"
    }
    assert all(before_methods[k] == v for k, v in after_methods.items())
    forward = []
    inverse = []
    for s in mapping:
        subject = s["subject"]
        before = current[subject]
        after = (OUT / "post" / subject).read_text() if s["post_path"] else ""
        forward.extend(
            difflib.unified_diff(
                before.splitlines(True),
                after.splitlines(True),
                fromfile="a/" + subject,
                tofile="b/" + subject if after else "/dev/null",
                n=3,
            )
        )
        inverse.extend(
            difflib.unified_diff(
                after.splitlines(True),
                before.splitlines(True),
                fromfile="a/" + subject if after else "/dev/null",
                tofile="b/" + subject,
                n=3,
            )
        )
        s["post"] = ref(OUT / "post" / subject) if after else None
        s.pop("post_path")
    (OUT / "forward.patch").write_text("".join(forward))
    (OUT / "inverse.patch").write_text("".join(inverse))
    custody = OUT / "roundtrip-v1"
    tree = custody / "tree"
    tree.mkdir(parents=True)
    for s in mapping:
        path = tree / s["subject"]
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(current[s["subject"]])
        path.chmod(int(s["mode"], 8))
    applied = run(
        [
            "patch",
            "--batch",
            "--fuzz=0",
            "--no-backup-if-mismatch",
            "-p1",
            "-i",
            str(OUT / "forward.patch"),
        ],
        tree,
    )
    assert all(
        w not in applied["stdout"].lower()
        for w in ["offset", "fuzz", "reversed", "failed"]
    )
    for s in mapping:
        path = tree / s["subject"]
        if s["post"] is None:
            assert not path.exists()
        else:
            assert (
                path.read_bytes() == Path(s["post"]["path"]).read_bytes()
                and f"{path.stat().st_mode & 0o777:04o}" == s["mode"]
            )
    restored = run(
        [
            "patch",
            "--batch",
            "--fuzz=0",
            "--no-backup-if-mismatch",
            "-p1",
            "-i",
            str(OUT / "inverse.patch"),
        ],
        tree,
    )
    assert all(
        w not in restored["stdout"].lower()
        for w in ["offset", "fuzz", "reversed", "failed"]
    )
    for s in mapping:
        path = tree / s["subject"]
        assert (
            path.read_text() == current[s["subject"]]
            and f"{path.stat().st_mode & 0o777:04o}" == s["mode"]
        )
        path.unlink()
    for parent, dirs, files in os.walk(tree, topdown=False):
        assert not files
        for d in dirs:
            Path(parent, d).rmdir()
    tree.rmdir()
    proof = save(
        OUT / "source-custody-once.json",
        dict(
            forward=applied,
            inverse=restored,
            zero_fuzz_nooffset=True,
            allbytes_modes_roundtrip=True,
            temporary_sparse_tree_removed=True,
            scope="ONE new retirement-packet custody roundtrip, not old successful source/test/native proof replay",
        ),
    )
    correspondence = save(
        OUT / "protected-correspondence.json",
        dict(
            protected=protected,
            all_other_python_test_methods_exact=True,
            removed_python_method=sorted(removed),
            all11_subjects_only=True,
            whole_old_owner_replacement=False,
            generic_tests_retained="Pre-existing LOCAL/Lazy fullhistory/coherentTT/typedbounds/nodebudget/cancel/reset/drop + generic ordering/timedrootquality/NN0 tests remain exactpre28 source. No oldsuite executed.",
            removed_definitions="prototype AI6+RunnerLIB2+Python1, diagnostic rootworkAI1+RunnerLIB1 only. Modules/source evidence/images/results retained in Git/OWN.",
            source_only_no_SOURCE_CLEAR=True,
        ),
    )
    recipe = save(
        OUT / "affected-software-recipe.json",
        dict(
            status="ROOT_ONLY_PENDING_NOT_EXECUTED",
            typecheck="Affected all-target Clippy also types legacy fixture after obsolete boolfield removal; no separate redundant oldsuite.",
            AI_Clippy=[
                "cargo",
                "clippy",
                "-p",
                "quoridor-ai",
                "--all-targets",
                "--features",
                "research-diagnostics",
                "--",
                "-D",
                "warnings",
            ],
            Runner_Clippy=[
                "cargo",
                "clippy",
                "-p",
                "quoridor-runner",
                "--all-targets",
                "--features",
                "measurement,quoridor-inference/claustrophobia",
                "--",
                "-D",
                "warnings",
            ],
            Runner_release=[
                "cargo",
                "build",
                "--release",
                "-p",
                "quoridor-runner",
                "--features",
                "measurement,quoridor-inference/claustrophobia",
                "--bin",
                "quoridor-runner",
            ],
            normal_Build="Root binds actual maintained source/tools/env/currentcallers/serialtarget/resources and fresh genuine baseline image/manifest at compatible actualSTOP; unmeasured baseline, not old9251alias.",
            new_test_definitions=0,
            old_success_tests_to_execute=[],
            generic_old_test_reuse="Only exact protected source scopes; no empirical parity/model/native qualification from source or lint.",
            private_compiler_tests_native_model_RAW_RNG=0,
        ),
    )
    binding = save(
        OUT / "binding.json",
        dict(
            issue="quoridor-4lc.324.28",
            at=datetime.now(timezone.utc).isoformat(),
            status="FIXED_PRIVATE_PURPOSE_END_RETIREMENT_NOT_TYPED_NOT_REVIEWED_NOT_ADOPTED",
            immutable_current_git=BASE,
            source_start=ref(OUT / "actual-source-start.json"),
            prototype_binding=ref(OWN / "prototype-v1/fixed-v1/binding.json"),
            original_diagnostic_binding=ref(
                OWN / "diagnostic-source-v1/fixed-binding.json"
            ),
            subjects=mapping,
            forward=ref(OUT / "forward.patch"),
            inverse=ref(OUT / "inverse.patch"),
            source_custody=proof,
            protected_correspondence=correspondence,
            affected_software_recipe=recipe,
            Rust_format=fmt,
            Rust_format_check=check,
            Python_changed_owner_format=py_format,
            Python_affected_lint=py_lint,
            Python_parser_AST_same_across_format=True,
            purpose="Remove only exhausted28 root_split prototype/transport/config/namespace/output/consumer/dedicatedtests and original28 rootchild-work observer; keep all evidence/Git/images/models/default1/Lazy2/Current100%/generic features.",
            Main_Git_Cargo_docs_otherOWN_writes=0,
            tests_compiler_native_model_inputpayload_RAW_RNG=0,
            review_dispatch_selfclear=False,
        ),
    )
    print(json.dumps(dict(binding=binding, source_custody=proof, recipe=recipe)))


if __name__ == "__main__":
    main()
