# Original28: root branch-work screen

26 calls / 25,000,193 nodes。normal manifest/dataは一度回収し、native+normalcollection/sourceSTOPをanalysis前にRootへ返した。25 NodeLimitのrequestedD64到達範囲はUNKNOWN、完了済みlatest snapshotとpendingを分離した。

固定screen: hit 23/26、series 6/6、stockbands 4。PASS=True。eligible latest completed 26/26。

| root | series | stock | latest depth | leading nodes | other nodes | other fraction | largest-other fraction | hit |
|---|---|---:|---:|---:|---:|---:|---:|---|
| 0 | series-0-turn-0 | 18 | 5 | 10005 | 235160 | 0.9591907490873494 | 0.008619663208028577 | True |
| 1 | series-0-turn-0 | 14 | 6 | 25996 | 646056 | 0.9613184694041532 | 0.013556100399965328 | True |
| 2 | series-0-turn-0 | 10 | 6 | 25350 | 471005 | 0.9489276828076679 | 0.011755713845925202 | True |
| 3 | series-1-turn-1 | 19 | 5 | 9900 | 255339 | 0.9626751722031828 | 0.008177364209932678 | True |
| 4 | series-1-turn-1 | 15 | 6 | 29742 | 692448 | 0.9588169318323433 | 0.04766278478672767 | True |
| 5 | series-1-turn-1 | 9 | 6 | 20948 | 412969 | 0.9517234862888525 | 0.016127118500420128 | True |
| 6 | series-2-turn-0 | 20 | 5 | 10295 | 268362 | 0.9630549385086324 | 0.00792958764653714 | True |
| 7 | series-2-turn-0 | 14 | 6 | 25758 | 648201 | 0.9617810578981808 | 0.010853115005993511 | True |
| 8 | series-2-turn-0 | 9 | 6 | 21905 | 467960 | 0.9552835985424556 | 0.011802290794084964 | True |
| 9 | series-2-turn-0 | 4 | 6 | 5500 | 329438 | 0.9835790504511283 | 0.03460135139237125 | True |
| 10 | series-2-turn-0 | 3 | 8 | 7787 | 333197 | 0.97716315135021 | 0.16444325729223253 | True |
| 11 | series-2-turn-0 | 0 | 64 | 1 | 1 | 0.5 | 1.0 | False |
| 12 | series-3-turn-1 | 20 | 5 | 11815 | 269753 | 0.9580385555176725 | 0.008066638739884264 | True |
| 13 | series-3-turn-1 | 15 | 6 | 40009 | 656774 | 0.9425804016458496 | 0.012766948752538925 | True |
| 14 | series-3-turn-1 | 10 | 6 | 21022 | 570289 | 0.964448488189802 | 0.06793748432812136 | True |
| 15 | series-3-turn-1 | 3 | 9 | 97695 | 559737 | 0.8513990800569489 | 0.6989336063186818 | True |
| 16 | series-3-turn-1 | 2 | 14 | 202471 | 70226 | 0.25752391848828554 | 0.4837524563551961 | True |
| 17 | series-4-turn-0 | 20 | 5 | 20230 | 271075 | 0.9305538868196563 | 0.007964585446832057 | True |
| 18 | series-4-turn-0 | 15 | 5 | 19107 | 231204 | 0.92366695830387 | 0.14715575855089014 | True |
| 19 | series-4-turn-0 | 10 | 6 | 31115 | 552158 | 0.9466544825493379 | 0.07669181647282118 | True |
| 20 | series-4-turn-0 | 3 | 8 | 36734 | 43330 | 0.5411920463629096 | 0.8486268174474959 | False |
| 21 | series-4-turn-0 | 0 | 30 | 1 | 211531 | 0.9999952725828716 | 1.0 | False |
| 22 | series-5-turn-1 | 20 | 5 | 9821 | 273332 | 0.9653155714401754 | 0.008001258542724599 | True |
| 23 | series-5-turn-1 | 14 | 5 | 8101 | 191944 | 0.9595041115748957 | 0.013191347476347268 | True |
| 24 | series-5-turn-1 | 9 | 6 | 60848 | 528647 | 0.8967794468146464 | 0.04350350990358406 | True |
| 25 | series-5-turn-1 | 4 | 6 | 9933 | 333264 | 0.9710574393132807 | 0.028280882423544096 | True |

条件は最新の実完了・非numericTT・depth>=2・全child work/return測定のsnapshotだけ。other/(leading+other)>=.25かつlargest-other/other<=.75のrootが8以上、3series以上、2bands以上必要。過去の好都合なdepthへ戻らない。pending/unreturned/unmeasured/TT-only/emptyは別表に残し、0や完了とは扱わない。

判定: STRUCTURAL_WORK_SCREEN_PLAUSIBLE_PRIVATE_ROOT_ONLY_PROTOTYPE_ALLOWED_NOT_PERFORMANCE_QUALIFIED。次は私有root-only prototypeの必要最小実装と新boundary定義へ進める。node fractionは時間比・pruning利得ではなく、実性能は未測定。

全26分母、first/continued、family/series、stock、first/latest/pending、全committed iteration、元rank/frozenkey/fullsignedhistoryとPARENT window/return/childnodes/evalsを保存。fullroot/fullweightedhistory snapshotとfrozen inputselector/STM/ply、既存21のsamehistory contextを対応させた。child scoutの返値はexact oracleではない。

計数・observer込みSearch clockはfair speed資格ではない。work量は有用情報やbranch時間ではない。TT/history warming、露出済み3families/6series、stock0 shortfall、root次元・censoringの限界を残す。main callback receipt/depthは全26でNULL/UNKNOWN。診断の固定work screenは実committed snapshotで判定し、clock安全資格を追加・偽装しない。perchild時間・将来depthのbranch完了/cutoff tree・pruning bénéficeはUNKNOWN。CPU/RSS/whole/setup/reset/dropの費用はsummaryに別保存。

26 diagnosticの元枠は消費済み。prospective312/combined338は独立したsource/software/real supportが必要で未entry、games/RNG/CI0。Main/Git/Cargo/docsはRootのみ。全pauses/seals/default/models/foreign/FAILED/NULL/UNKNOWNfees/50GB維持。
