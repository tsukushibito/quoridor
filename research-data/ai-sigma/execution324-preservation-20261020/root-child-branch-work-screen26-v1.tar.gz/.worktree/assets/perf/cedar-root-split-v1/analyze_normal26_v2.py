"""Apply the frozen leading/other branch screen to saved diagnostic rows only."""

from collections import Counter
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "compatible-retirement-v1"))
from compose_v2 import ref, save  # noqa: E402

OWN = Path(__file__).resolve().parent
COL = OWN / "numeric-diagnostic-v1/collection-v1"
OUT = OWN / "numeric-diagnostic-v1/analysis-v2"


def document(r):
    assert ref(r["path"]) == r
    return json.loads(Path(r["path"]).read_text())


def csvfile(path, rows):
    with path.open("x", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    return ref(path)


def main():
    assert not OUT.exists()
    OUT.mkdir()
    protocol = json.loads((OWN / "finite-protocol-v1.json").read_text())
    recipe = json.loads(
        (OWN / "normal26-control-preparation-v1/analysis-recipe.json").read_text()
    )
    assert (
        recipe["screening_rule"]
        == protocol["diagnostic"]["decision_before_implementation"]
    )
    collection = json.loads((COL / "summary.json").read_text())
    rows = document(collection["rows"])
    block = document(collection["block"])
    metadata = protocol["roots"]
    sessions = json.loads(
        (
            OWN / "normal26-control-preparation-v1/session-correspondence.json"
        ).read_text()
    )["rows"]
    requests = document(protocol["diagnostic"]["requests"])
    old_primary = document(protocol["comparison"]["depth_map"][0]["evidence"])
    assert (
        len(rows)
        == len(metadata)
        == len(sessions)
        == len(requests)
        == len(old_primary)
        == 26
    )
    roots = []
    iterations = []
    snapshots = []
    children = []
    fullroots = []
    all_parent = all_input = all_context = True
    for i, row in enumerate(rows):
        req, m, root = row["request"], row["measurement"], row["root"]
        meta, expected = sessions[i], metadata[i]
        assert (
            req == requests[i]
            and req["session"] == meta["session"]
            and req["root"] == i
        )
        assert (
            root["ply"] == meta["total_ply"] == expected["ply"]
            and not root["synthetic"]
        )
        assert int(root["root_key"].split("|")[2]) == meta["STM"]
        assert m["root_walls_remaining"] == meta["stock"] == expected["stock"]
        assert (
            m["parent_unchanged"]
            and m["returned"] == "Ok"
            and m["action"] in m["root_legal_action_ids"]
        )
        assert m["work"]["nodes"] <= 1000000 and m["work"]["TT_illegal_moves"] == 0
        # This opportunity diagnostic route emitted no callback receipt; retain None.
        # The frozen work screen qualifies actual committed snapshots, not clock safety.

        obs = m["neighbour_opportunity"]
        assert obs["parent_restored"] and obs["root_stock"] == expected["stock"]
        all_parent &= obs["parent_restored"] and m["parent_unchanged"]
        fullroots.append(
            dict(
                root_index=i,
                session=req["session"],
                native_root_fullweighted_snapshot=root,
                saved_prefix_sha256=meta["saved_fullprefix_sha256"],
                input_ref=meta["input_ref"],
                selector=meta["selector"],
                custody="Normalinput qualification and exactsavedselector/request; no payload/history reconstruction",
                parent_restored=True,
            )
        )
        work = obs.get("root_branch_work", {}).get("completed_iterations", [])
        for w in work:
            iterations.append(
                dict(
                    root=i,
                    family=expected["family"],
                    series=req["session"],
                    stock=expected["stock"],
                    band=expected["band"],
                    overall_stop=m["stop"],
                    horizon=m["status"],
                    **w,
                )
            )
        last = next(
            (q for q in obs["root_ordering_quality"] if q["slot"] == "last_completed"),
            None,
        )
        for q in obs["root_ordering_quality"]:
            slot = q["slot"]
            entries = q.get("entries", [])
            attempts = q.get("children", [])
            measured = q.get("child_work_nodes_evaluations", [])
            ranks = {
                entry[0]: (rank, entry[1], entry[2])
                for rank, entry in enumerate(entries)
            }
            snapshots.append(
                dict(
                    root=i,
                    slot=slot,
                    depth=q.get("depth"),
                    completed=q.get("completed"),
                    numeric_tt_return=q.get("numeric_tt_return"),
                    generation=q.get("TT_generation"),
                    context=json.dumps(q.get("context")),
                    window_bits=json.dumps(q.get("window_bits")),
                    candidate_count=len(entries),
                    child_attempts=len(attempts),
                    work_slots=len(measured),
                    unreturned=sum(c[3] is None for c in attempts),
                    unmeasured=sum(v is None for v in measured),
                    selected=q.get("selected"),
                    value_bits=q.get("value_bits"),
                    scope="Actual first/latest completed or pending; pending/unreturned never completed. Childwindows inROOT/PARENT perspective",
                )
            )
            for j, c in enumerate(attempts):
                v = measured[j] if j < len(measured) else None
                r = ranks.get(c[0])
                children.append(
                    dict(
                        root=i,
                        series=req["session"],
                        slot=slot,
                        depth=q.get("depth"),
                        iteration_completed=q.get("completed"),
                        context=json.dumps(q.get("context")),
                        generation=q.get("TT_generation"),
                        attempt=j,
                        action=c[0],
                        original_order_rank=r[0] if r else "UNKNOWN",
                        frozen_key=r[1] if r else "UNKNOWN",
                        fullsigned_history=r[2] if r else "UNKNOWN",
                        leading=bool(entries and c[0] == entries[0][0]),
                        window_alpha_bits=c[1][0],
                        window_beta_bits=c[1][1],
                        PVS_research=c[2],
                        returned_value_bits=c[3] if c[3] is not None else "UNRETURNED",
                        nodes=v[0] if v is not None else "UNMEASURED",
                        evaluations=v[1] if v is not None else "UNMEASURED",
                        return_scope="Parentwindow value may be bound/scout; not exactchild oracle",
                        completion_scope="Completediteration"
                        if q.get("completed")
                        else "Pending/partial; excludedfromscreen",
                    )
                )
        latest = work[-1] if work else None
        context_match = bool(last and last.get("context") == old_primary[i]["context"])
        all_context &= context_match
        reason = []
        consistent = False
        if last is None or latest is None:
            reason.append("MISSING_LATEST_COMMITTED_SAMPLE")
        else:
            if last.get("depth") != m["completed_depth"] or latest["depth"] != last.get(
                "depth"
            ):
                reason.append("LATEST_COMPLETION_DEPTH_MISMATCH")
            if not last.get("completed") or latest["depth"] < 2:
                reason.append("NOT_COMPLETED_DEPTH_GE2")
            if last.get("numeric_tt_return") or latest["numeric_tt_return"]:
                reason.append("NUMERIC_TT_NO_BRANCH_INFORMATION")
            attempts = last.get("children", [])
            measured = last.get("child_work_nodes_evaluations", [])
            entries = last.get("entries", [])
            if (
                not latest["complete_work"]
                or len(attempts) != len(measured)
                or any(c[3] is None for c in attempts)
                or any(v is None for v in measured)
            ):
                reason.append("MISSING_OR_UNRETURNED_WORK")
            elif entries and attempts:
                leading = entries[0][0]
                other = {}
                ln = le = on = oe = rn = re = 0
                for c, v in zip(attempts, measured):
                    if c[0] == leading:
                        ln += v[0]
                        le += v[1]
                    else:
                        on += v[0]
                        oe += v[1]
                        other[c[0]] = other.get(c[0], 0) + v[0]
                    if c[2]:
                        rn += v[0]
                        re += v[1]
                consistent = (
                    ln,
                    le,
                    on,
                    oe,
                    max(other.values(), default=0),
                    rn,
                    re,
                ) == tuple(
                    latest[k]
                    for k in [
                        "leading_nodes",
                        "leading_evaluations",
                        "other_nodes",
                        "other_evaluations",
                        "largest_other_nodes",
                        "research_nodes",
                        "research_evaluations",
                    ]
                )
                if not consistent:
                    reason.append("COMPACT_VS_SNAPSHOT_WORK_MISMATCH")
            else:
                reason.append("EMPTY_BRANCH_WORK_NOT_ZERO_OPPORTUNITY")
            if last.get("window_bits") != [4286578688, 2139095040]:
                reason.append("ROOT_FULL_WINDOW_MISMATCH")
            if not context_match:
                reason.append("SAVED_FULLWEIGHTED_CONTEXT_CORRESPONDENCE_MISMATCH")
        eligible = not reason
        total = (latest["leading_nodes"] + latest["other_nodes"]) if latest else None
        other_fraction = latest["other_nodes"] / total if eligible and total else None
        largest_fraction = (
            latest["largest_other_nodes"] / latest["other_nodes"]
            if eligible and latest["other_nodes"]
            else None
        )
        plausible = bool(
            eligible
            and other_fraction is not None
            and largest_fraction is not None
            and other_fraction >= 0.25
            and largest_fraction <= 0.75
        )
        rootrow = dict(
            root=i,
            family=expected["family"],
            series=req["session"],
            STM=meta["STM"],
            ply=expected["ply"],
            stock=expected["stock"],
            band=expected["band"],
            session_first=expected["session_first"],
            overall_stop=m["stop"],
            horizon=m["status"],
            completed_depth=m["completed_depth"],
            latest_work_depth=latest["depth"] if latest else None,
            candidate_count=latest["candidate_count"] if latest else None,
            leading_nodes=latest["leading_nodes"] if latest else None,
            other_nodes=latest["other_nodes"] if latest else None,
            largest_other_nodes=latest["largest_other_nodes"] if latest else None,
            leading_evals=latest["leading_evaluations"] if latest else None,
            other_evals=latest["other_evaluations"] if latest else None,
            research_nodes=latest["research_nodes"] if latest else None,
            research_evals=latest["research_evaluations"] if latest else None,
            other_fraction=other_fraction,
            largest_other_fraction=largest_fraction,
            eligible_completed_snapshot=eligible,
            unknown_reasons=";".join(reason),
            screen_hit=plausible,
            fullweighted_context_matches_saved21=context_match,
            Search_s=m["Search_call_seconds"],
            receipt_s=m["main_completed_receipt_seconds"],
            completed_snapshot_main_depth=m["main_receipted_completed_depth"],
            CPU_s=m["process_CPU_seconds"],
            process_peak_RSS_B=m["process_peak_RSS_B"],
            total_nodes=m["work"]["nodes"],
            total_evals=m["work"]["evaluations"],
            root_prepare_s=row["preparation_seconds"],
            journal_s=row["journal_seconds"],
            call_teardown_s=row["call_teardown_seconds"],
        )
        roots.append(rootrow)
    hits = [r for r in roots if r["screen_hit"]]
    hit_sessions = sorted({r["series"] for r in hits})
    hit_bands = sorted({r["band"] for r in hits})
    passed = (
        len(hits) >= 8
        and len(hit_sessions) >= 3
        and len(hit_bands) >= 2
        and all_parent
        and all_input
        and all_context
    )
    strata = []
    for group in ["band", "session_first", "family", "series"]:
        for value in sorted({r[group] for r in roots}, key=str):
            rs = [r for r in roots if r[group] == value]
            strata.append(
                dict(
                    stratum=group,
                    value=value,
                    roots=len(rs),
                    eligible=sum(r["eligible_completed_snapshot"] for r in rs),
                    screen_hits=sum(r["screen_hit"] for r in rs),
                    capped_horizons=sum(r["overall_stop"] == "NodeLimit" for r in rs),
                    eligible_leading_nodes=sum(
                        r["leading_nodes"]
                        for r in rs
                        if r["eligible_completed_snapshot"]
                    ),
                    eligible_other_nodes=sum(
                        r["other_nodes"] for r in rs if r["eligible_completed_snapshot"]
                    ),
                    scope="Descriptive complete originaldenominator; no favourablesubset/time benefit claim",
                )
            )
    tables = dict(
        roots=csvfile(OUT / "root-screen.csv", roots),
        iterations=csvfile(OUT / "all-completed-iteration-work.csv", iterations),
        snapshots=csvfile(OUT / "snapshot-coverage.csv", snapshots),
        children=csvfile(OUT / "child-attempts.csv", children),
        strata=csvfile(OUT / "strata.csv", strata),
        fullroots=save(OUT / "full-root-history-custody.json", fullroots),
    )
    disposition = (
        "STRUCTURAL_WORK_SCREEN_PLAUSIBLE_PRIVATE_ROOT_ONLY_PROTOTYPE_ALLOWED_NOT_PERFORMANCE_QUALIFIED"
        if passed
        else "STOP_PROTOTYPE_SCREEN_UNSUPPORTED_OR_UNRESOLVED_NO_REFILL"
    )
    summary = save(
        OUT / "summary.json",
        dict(
            status="ORIGINAL26_SAVED_BRANCH_WORK_SCREEN",
            protocol=ref(OWN / "finite-protocol-v1.json"),
            collection=ref(COL / "summary.json"),
            analysis_recipe=ref(
                OWN / "normal26-control-preparation-v1/analysis-recipe.json"
            ),
            tables=tables,
            calls=26,
            actual_nodes=collection["total_nodes"],
            node_upper=26000000,
            all26_original_slots=True,
            all6_sessions=len({r["series"] for r in roots}) == 6,
            latest_completed_eligible=sum(
                r["eligible_completed_snapshot"] for r in roots
            ),
            screen_hits=len(hits),
            screen_hit_roots=[r["root"] for r in hits],
            screen_sessions=hit_sessions,
            screen_bands=hit_bands,
            screen_PASS=passed,
            denominator=26,
            all_saved_contexts_match=bool(all_context),
            main_callback_receipts="All26 None/UNKNOWN in actualdiagnostic route; no clock/safety/speed qualification or fabricated callback",
            all_parent_restored=bool(all_parent),
            stock_bands=dict(Counter(r["band"] for r in roots)),
            stock_zero_shortfall=protocol["stock_zero_shortfall"]
            if "stock_zero_shortfall" in protocol
            else "Original genuine2vsdesired6; no refill",
            overall_horizons=dict(Counter(r["horizon"] for r in roots)),
            actual_stops=collection["actual_stops"],
            pending_iterations=sum(
                s["slot"] == "pending" and s["depth"] is not None for s in snapshots
            ),
            pending_unreturned_attempts=sum(
                c["slot"] == "pending" and c["returned_value_bits"] == "UNRETURNED"
                for c in children
            ),
            completed_work_rows=len(iterations),
            unknown_latest_roots=[
                dict(root=r["root"], reasons=r["unknown_reasons"])
                for r in roots
                if not r["eligible_completed_snapshot"]
            ],
            disposition=disposition,
            costs=dict(
                outer_seconds_once=collection["outer_seconds_once"],
                nested_added=0,
                observed_Search_seconds=block["Search_seconds"],
                whole_driver_seconds=block["whole_driver_seconds"],
                setup_seconds=block["setup_seconds"],
                target_drop_seconds=block["target_drop_seconds"],
                reset_seconds=sum(
                    x["seconds"]
                    for x in block["session_domains"]
                    if x["domain"] == "reset"
                ),
                session_teardown_seconds=sum(
                    x["seconds"]
                    for x in block["session_domains"]
                    if x["domain"] == "teardown"
                ),
            ),
            next_private_prototype=passed,
            actual_prototype_implementation=False,
            future312_science="UNENTERED separate source/software/support/current normal admission required; combined338upper not quota-consumption target",
            games=0,
            RNG_CI=0,
            native_tests_model_RAW_replays=0,
            limits="Workscreen only, not elapsed balance/CPU speed/pruning/savedwork/strength. NodeLimit pending horizonUNKNOWN despite known priorcompleted snapshot. LatestONLY, no earlier favourableiteration fallback. Original26 exposed3families6samecolourseries/warm TT/history correlation/censoring/rootrank/window effects. ROOT/PARENT childvalues may typedbounds, not exactchild oracle. Fullweightedhistory actualsnapshot + savedroot/STM/PLY/selector/context custody recorded, no inputpayload/solver/history reconstruction. Perchild time/branch completion atfuturedepth/cutoff tree UNKNOWN; CPU includesrender andRSS cumulativeprocess, not family peak.",
        ),
    )
    report = [
        "# Original28: root branch-work screen",
        "",
        f"26 calls / {collection['total_nodes']:,} nodes。normal manifest/dataは一度回収し、native+normalcollection/sourceSTOPをanalysis前にRootへ返した。25 NodeLimitのrequestedD64到達範囲はUNKNOWN、完了済みlatest snapshotとpendingを分離した。",
        "",
        f"固定screen: hit {len(hits)}/26、series {len(hit_sessions)}/6、stockbands {len(hit_bands)}。PASS={passed}。eligible latest completed {sum(r['eligible_completed_snapshot'] for r in roots)}/26。",
        "",
        "| root | series | stock | latest depth | leading nodes | other nodes | other fraction | largest-other fraction | hit |",
        "|---|---|---:|---:|---:|---:|---:|---:|---|",
    ]
    for r in roots:
        report.append(
            f"| {r['root']} | {r['series']} | {r['stock']} | {r['latest_work_depth']} | {r['leading_nodes']} | {r['other_nodes']} | {r['other_fraction']} | {r['largest_other_fraction']} | {r['screen_hit']} |"
        )
    report += [
        "",
        "条件は最新の実完了・非numericTT・depth>=2・全child work/return測定のsnapshotだけ。other/(leading+other)>=.25かつlargest-other/other<=.75のrootが8以上、3series以上、2bands以上必要。過去の好都合なdepthへ戻らない。pending/unreturned/unmeasured/TT-only/emptyは別表に残し、0や完了とは扱わない。",
        "",
        f"判定: {disposition}。"
        + (
            "次は私有root-only prototypeの必要最小実装と新boundary定義へ進める。node fractionは時間比・pruning利得ではなく、実性能は未測定。"
            if passed
            else "prototypeは開始しない。追加Search/補充なし、欠測・支配的leading/偏ったother workをそのまま保持。"
        ),
        "",
        "全26分母、first/continued、family/series、stock、first/latest/pending、全committed iteration、元rank/frozenkey/fullsignedhistoryとPARENT window/return/childnodes/evalsを保存。fullroot/fullweightedhistory snapshotとfrozen inputselector/STM/ply、既存21のsamehistory contextを対応させた。child scoutの返値はexact oracleではない。",
        "",
        "計数・observer込みSearch clockはfair speed資格ではない。work量は有用情報やbranch時間ではない。TT/history warming、露出済み3families/6series、stock0 shortfall、root次元・censoringの限界を残す。main callback receipt/depthは全26でNULL/UNKNOWN。診断の固定work screenは実committed snapshotで判定し、clock安全資格を追加・偽装しない。perchild時間・将来depthのbranch完了/cutoff tree・pruning bénéficeはUNKNOWN。CPU/RSS/whole/setup/reset/dropの費用はsummaryに別保存。",
        "",
        "26 diagnosticの元枠は消費済み。prospective312/combined338は独立したsource/software/real supportが必要で未entry、games/RNG/CI0。Main/Git/Cargo/docsはRootのみ。全pauses/seals/default/models/foreign/FAILED/NULL/UNKNOWNfees/50GB維持。",
    ]
    (OUT / "report-ja.md").write_text("\n".join(report) + "\n")
    completion = save(
        OUT / "completion.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            summary=summary,
            report=ref(OUT / "report-ja.md"),
            screen_PASS=passed,
            actual_calls=26,
            actual_prototype=False,
            source_native_tests_model_RAW_RNG_replay=0,
        ),
    )
    print(
        json.dumps(
            dict(
                completion=completion,
                screen_PASS=passed,
                hit_roots=[r["root"] for r in hits],
                sessions=hit_sessions,
                bands=hit_bands,
                disposition=disposition,
            )
        )
    )


if __name__ == "__main__":
    main()
