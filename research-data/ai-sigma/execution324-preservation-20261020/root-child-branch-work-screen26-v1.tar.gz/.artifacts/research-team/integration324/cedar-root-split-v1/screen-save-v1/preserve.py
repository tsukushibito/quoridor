"""Save the closed producer screen and its causal failed analyzer without rerun."""

import importlib.util
import json
import re
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    paths = []
    for base in [
        OWN / "numeric-diagnostic-v1/analysis-v1",
        OWN / "numeric-diagnostic-v1/analysis-v2",
        OWN / "normal26-analysis-guard-v1",
        OWN / "normal26-analysis-guard-v2",
    ]:
        for path in helper.files_below(base):
            relative = str(path.relative_to(base)).lower()
            if (
                re.search(
                    r"(^|[-_/])(ready|show|beads|backup|notes?|update|admin|authority)([-_./]|$)",
                    relative,
                )
                or "delivery" in relative
            ):
                continue
            paths.append(path)
    paths += [
        OWN / n
        for n in [
            "analyze_normal26.py",
            "analyze_normal26_v2.py",
            "normal26-analysis-guard-v1.json",
            "normal26-analysis-guard-v2.json",
        ]
    ]
    paths.append(OUT / "preserve.py")
    helper.DEST = DEST
    name = "root-child-branch-work-screen26-v1.tar.gz"
    helper.write_archive(
        name,
        paths,
        "Original26 fixed saved-work screen: producer23/26 on latest committed snapshots, all6 correlated series/4stockbands, requestedD64 horizons25cappedUNKNOWN+1complete; NULL diagnostic maincallback and pending work explicit. Failed analyzerv1 extra callback assertion and causalv2 fix preserved. Opaque closed byte preservation only, no analyzer/native/validator/source/model/RNG replay. Related important interpretation review28.2 separately dispatched; no prototype/performance qualification fromarchive.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    summary = json.loads(
        (OWN / "numeric-diagnostic-v1/analysis-v2/summary.json").read_bytes()
    )
    record = dict(
        issue="quoridor-4lc.324.28",
        status="PRODUCER_FIXED_SAVED_WORK_SCREEN_COMPLETE_RELATED_REVIEW_PENDING",
        original_collection="root-child-diagnostic-qualified26-v1.json",
        fixed_protocol=summary["protocol"],
        producer_summary=summary,
        review=dict(
            issue="quoridor-4lc.324.28.2",
            status_at_save="DISPATCHED_TO_EXISTING_MAX_NOT_AN_AUTHOR_SOURCE_GATE",
        ),
        scope="Latest committed root-child work screen permits only the existing bounded private-prototype step. No child-time/parallel finish/pruning/savedwork/speed/strength inference. Scoutreturns typedbounds, all26 callback None/UNKNOWN; pending iterations/capped horizons remainUNKNOWN. Original6 correlated warm series/3families/zero-stock2 shortfall fixed; no refill/newSearch/games/default change.",
        archive={
            k: manifest[k]
            for k in [
                "archive",
                "bytes",
                "sha256",
                "full_stream_restore_hash_mode_verified",
            ]
        },
    )
    with (DEST / "root-child-branch-work-screen26-v1.json").open("x") as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(record["archive"]))


if __name__ == "__main__":
    main()
