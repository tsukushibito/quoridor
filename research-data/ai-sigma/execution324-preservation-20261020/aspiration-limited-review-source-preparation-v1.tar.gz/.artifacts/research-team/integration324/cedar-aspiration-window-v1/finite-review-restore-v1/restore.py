"""Restore only the explicit new finite-review aspiration subjects after stopped retirement."""

import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1/retirement-v1"


def ref(p):
    raw = p.read_bytes()
    return dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 511:04o}",
    )


def main():
    binding = OWN / "binding.json"
    assert (
        ref(binding)["sha256"]
        == "32f54b6dc8d9b8b1235ce7855267618ddbe24b25c65a43b2be2618258af3e2b7"
    )
    b = json.loads(binding.read_bytes())
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for row in b["subjects"]:
            p = ROOT / row["path"]
            if row["after_raw"] is None:
                assert not p.exists()
            else:
                actual = ref(p)
                actual.pop("path")
                assert actual == row["after_raw"]
        inverse = b["inverse"]
        assert ref(Path(inverse["path"])) == inverse
        r = subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "-i", inverse["path"]],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=True,
        )
        assert "fuzz" not in r.stdout.lower() and "offset" not in r.stdout.lower()
        subjects = []
        for row in b["subjects"]:
            actual = ref(ROOT / row["path"])
            raw = dict(actual)
            raw.pop("path")
            assert raw == row["before_raw"]
            subjects.append(actual)
        subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
        receipt = dict(
            status="RESEARCH_OFF_SOURCE_RESTORED_FOR_EXPLICIT_NEW520_FINITE_REVIEW",
            issue="quoridor-4lc.324.29",
            authority="Human2026-10-20 explicit implementation-cost investigation + small typed-config comparison <=520calls/520M, no games",
            subjects=subjects,
            measured_source_equivalence="All17 exactly original302dca2 before-retirement bytes/modes; same19c2/64844 original measured source, no other candidate restored",
            retirement_source_adoption=ref(
                OUT.parent / "retirement-adoption-v1/actual-adoption.json"
            ),
            retirement_compiler_started=False,
            original208_and_failed_metadata="IMMUTABLE; fixed major-root failure and128NO_GAMES unchanged",
            new_science_used=0,
            new_science_upper_calls=520,
            new_science_upper_nodes=520000000,
            source_lease="EX_NB returned by actualguard",
            GNU_inverse_fuzz0_nooffset=r.stdout,
            remaining="Sameauthor limitedaudit+newfiniteprotocol; restore neither newscienceSTART nor speed/defaultqualification",
        )
        with (OUT / "actual-restoration.json").open("x") as f:
            json.dump(receipt, f, indent=2)
            f.write("\n")
    print(
        json.dumps(
            dict(status=receipt["status"], subjects=len(subjects), science_used=0)
        )
    )


if __name__ == "__main__":
    main()
