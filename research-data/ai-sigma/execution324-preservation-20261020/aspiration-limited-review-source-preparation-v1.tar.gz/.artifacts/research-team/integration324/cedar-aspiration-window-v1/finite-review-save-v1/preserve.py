"""Preserve the stopped retirement and exact research-only finite-review restoration."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    paths = old.files_below(OWN / "retirement-v1")
    for name in ["retirement-adoption-v1", "finite-review-restore-v1"]:
        paths += old.files_below(BASE / name)
    paths += [BASE / "implementation-cost-review-task.txt", OUT / "preserve.py"]
    paths = [
        p
        for p in paths
        if not any(
            x in p.name.lower()
            for x in [
                "beads",
                "backup",
                "root-update",
                "root-current-metadata",
                "administration",
                "delivery",
            ]
        )
    ]
    for p in paths:
        assert (
            p.suffix not in {".onnx", ".pt", ".so", ".bin", ".lock", ".pem", ".key"}
            and p.stat().st_size < 8 * 1024**2
        )
    old.DEST = DEST
    name = "aspiration-limited-review-source-preparation-v1.tar.gz"
    old.write_archive(
        name,
        paths,
        "Fixedunsupported17subject retirement and actualsparseadoption, no compilerstarted; subsequentexplicithumanNEW<=520implementation-cost/configreview, ONLY17 exactinverse restoredresearchOFF matching302dca2. Original208failure/128NO_GAMES immutable. No newscience/test/build/model/RAW/native/RNG replay or othercandidate revival. Authoritative factualtaskstatus remainsBeads.",
    )
    m = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    s = dict(
        issue="quoridor-4lc.324.29.3",
        source="Exact measured302dca2/19c2ab68/64844e88 restored for concrete newfinite use; researchOFF",
        retirement_compilation_started=False,
        new_authorized_calls_upper=520,
        new_authorized_nodes_upper=520000000,
        all_new_phases_and_diagnostics_included=True,
        new_calls_used=0,
        original208="Immutable no-games duefrozenmajorroot18/23; no retroactivechange",
        new_games_book_model_default_adoption=False,
        first_axis="width.125/.25/.5; growth2/startdepth3/retry4 fixed; repair samewidth separated ifneeded",
        later_axis="startdepth3/4/5 onlyifpromising; no grid/SPSA/refill",
        archive=dict(
            path=name,
            sha256=m["sha256"],
            bytes=m["bytes"],
            members=len(m["members"]),
            full_stream_SHA_size_mode_verified=True,
        ),
        status_scope="Evidence snapshot only; actualstate/ownership/handoffs Beads",
    )
    with (DEST / "aspiration-limited-review-source-preparation-v1.json").open("x") as f:
        json.dump(s, f, indent=2)
        f.write("\n")
    print(json.dumps(s["archive"]))


if __name__ == "__main__":
    main()
