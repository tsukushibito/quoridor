"""Eliminate now-redundant root alpha alias and only the deleted-helper blank gap."""

import ast
import gzip
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import command, ref, save  # noqa: E402
from finish import CHANGED_LC, functions, method  # noqa: E402

OUT = Path(__file__).resolve().parent


def run(argv):
    result = command(argv)
    assert result["returncode"] == 0, result
    return result


def main():
    record = json.loads((OUT / "formatted-posts.json").read_text())
    path = OUT / "post-minimal"
    assert path.is_dir()
    checks = []
    historical = gzip.decompress(
        (OUT.parent / "source-v1/before/alphabeta.rs.gz").read_bytes()
    ).decode()
    for row in record["subjects"]:
        if row["post"] is None:
            continue
        name = Path(row["path"]).name
        if name not in {"alphabeta.rs", "research-lifecycle.py"}:
            continue
        text = Path(row["post"]["path"]).read_text()
        if name == "alphabeta.rs":
            root = method(text, "root_depth")
            simple = root.replace("        let mut alpha = f32::NEG_INFINITY;\n", "")
            simple = re.sub(r"\balpha\b", "value", simple)
            assert simple.count("            value = value;\n") == 1
            simple = simple.replace("            value = value;\n", "")
            assert simple == method(historical, "root_depth")
            text = text.replace(root, simple, 1)
        else:
            text, count = re.subn(
                r"\n{5,}(?=def resolved_lmr_parameters\()", "\n\n\n", text
            )
            assert count == 1, count
        output = path / name
        already = output.exists()
        if already:
            assert output.read_text() == text
        else:
            output.write_text(text)
        if name.endswith(".rs") and not already:
            checks.append(
                run(
                    [
                        "rustfmt",
                        "--edition",
                        "2024",
                        "--config",
                        "skip_children=true",
                        str(output),
                    ]
                )
            )
            checks.append(
                run(
                    [
                        "rustfmt",
                        "--check",
                        "--edition",
                        "2024",
                        "--config",
                        "skip_children=true",
                        str(output),
                    ]
                )
            )
            assert method(output.read_text(), "root_depth") == method(
                historical, "root_depth"
            )
        elif name.endswith(".py"):
            original = gzip.decompress(
                Path(row["before_gzip"]["path"]).read_bytes()
            ).decode()
            bf, af = functions(original), functions(output.read_text())
            assert all(bf[n] == af[n] for n in af if n not in CHANGED_LC)
            ast.parse(output.read_text())
        row["post"] = ref(output)
    record["ordinary_root_correspondence"] = dict(
        full_window_root_byte_exact_to_preaspiration_function=True,
        narrow_function_only=True,
        current_protected_methods=record["protected_correspondence"],
        half_retirement_and_all_other_current_owner_bytes_preserved=True,
    )
    record["final_minimization_checks"] = save(OUT / "minimization-checks.json", checks)
    save(OUT / "minimal-posts.json", record)
    print(
        json.dumps(
            dict(
                full_window_root_exact=True,
                redundant_alias_removed=True,
                no_aspiration_survives_in_scoped_posts=True,
            )
        )
    )


if __name__ == "__main__":
    main()
