"""One routine fixed retirement handoff to integration324; no actor/review dispatch."""

import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import command, ref, save  # noqa: E402

OUT = Path(__file__).resolve().parent


def main():
    guard = json.loads((OUT / "seal-guard-v1/result.json").read_text())
    assert guard["status"] == "PASS" and guard["TMP_remaining"] == []
    for item in guard["checks"]:
        result = item["guardian_return"]
        assert result["direct_child_reaped"] and result["cleanup_complete"]
        assert result["handle_closes_complete"] and result["remaining"] == []
    refs = {
        name: ref(OUT / name)
        for name in [
            "binding.json",
            "forward.patch",
            "inverse.patch",
            "affected-software-recipe.json",
            "source-STOP.json",
            "seal-guard-v1/result.json",
            "ordinary-affected-point.json",
            "administration.json",
        ]
    }
    body = (
        """Beads issue: quoridor-4lc.324 / SAME original High29 own29.

Unsupported29 retirement PRIVATE fixed against pushed302dca2.17 sparse subjects:
three feature-only files deleted; dedicated AI3/RunnerLIB2/Python1 removed;
window/retry/config/namespace/stats/LC/output and obsolete None/caller plumbing
removed. Ordinary full-window root function byte-exact to pre-aspiration root;
no whole old owner restored. Current100%/Half-retirement,12 alpha kernels,
remaining SMP body, generic timed-rootquality/selected-abnormal+NN0 protected;
LC other90 surviving functions byte-exact. No main.rs aspiration CLI in scoped
reference search; JSON entry removed, historical docs/results/Git/images retained.

GNU fuzz0/nooffset forward+inverse all17 bytes/modes PASS. Scoped Rustfmt,
LC four named-owner Ruff100/parser and helper Ruff PASS; compiler/tests/native/
model/RAW/RNG0. Preparation-only optional-comma/orphan-local/gap locator failures
and their exact cleanup receipts retained. No author SOURCE_CLEAR or dispatch.

Root sparse adoption + affected AI/Runner all-target Clippy (types legacy
assertions, executes no old suite) + genuine release remain PENDING. Exact recipe
below. Cleaned source unbuilt/unmeasured. No new science,128 remains NO_GAMES,
frozen major-root-regression decision unchanged. Own29 normal note+backup PASS,
sameassignee/in_progress; no other status/Main/Git/Cargo/docs writes.

Returned scoped guards all directwait/reap/handles; prior exact IDs fresh absent/
different, TMP/leases/reservations/native remaining[]. Source STOP/sealer actual
return both bound below, delivery helper lifetime separate/no futurehostquiet.
One new retirement-subtree affected point only; oldholding/globalactual/later
tails/fullfees UNKNOWN, no recharge/refund/lending.27/28 scopes and every pause/
seal/default/model/foreign/FAILED/NULL/50GB/consultation8 preserved.

"""
        + json.dumps(refs, indent=2)
        + "\n"
    )
    path = OUT / "handoff.txt"
    path.write_text(body)
    result = command(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--issue",
            "quoridor-4lc.324",
            "--cwd",
            "/workspaces/quoridor",
            "--body-file",
            str(path),
        ]
    )
    save(OUT / "delivery-return.json", result)
    assert result["returncode"] == 0, result
    print(
        json.dumps(
            dict(
                delivered=True,
                binding=refs["binding.json"],
                source_STOP=refs["source-STOP.json"],
            )
        )
    )


if __name__ == "__main__":
    main()
