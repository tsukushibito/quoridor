"""Returned scoped identities and one affected subtree point for the private packet."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent))
sys.path.insert(0, str(ROOT / "python"))
from task_utils import ref, save  # noqa: E402
from quoridor_training import cycle_process as process  # noqa: E402

STAGES = [
    "intake-guard-v1",
    "intake-suffix-guard-v1",
    "edit-guard-v1",
    "edit-guard-v2",
    "format-guard-v1",
    "format-guard-v2",
    "minimal-guard-v1",
    "minimal-guard-v2",
    "packet-guard-v1",
    "admin-guard-v1",
]


def identities(value, found):
    if isinstance(value, dict):
        if {"pid", "start_ticks", "boot_id"} <= value.keys():
            item = {k: value[k] for k in ["pid", "start_ticks", "boot_id"]}
            found[(item["pid"], item["start_ticks"], item["boot_id"])] = item
        for child in value.values():
            identities(child, found)
    elif isinstance(value, list):
        for child in value:
            identities(child, found)


def main():
    known, references, tmp = {}, [], []
    for name in STAGES:
        stage = OUT / name
        result = stage / "result.json"
        document = json.loads(result.read_text())
        references.append(ref(result))
        identities(document, known)
        for path in stage.glob("*.process.json"):
            identities(json.loads(path.read_text()), known)
        if (stage / "TMP").exists():
            tmp.extend(str(p) for p in (stage / "TMP").iterdir())
    assert not tmp, tmp
    fresh = []
    for old in known.values():
        info = process.process_info(old["pid"])
        actual = process.identity(info) if info else None
        assert actual != old, (old, actual)
        fresh.append(
            dict(original=old, current=actual, exact_identity_absent_or_different=True)
        )
    stop = save(
        OUT / "source-STOP.json",
        dict(
            issue="quoridor-4lc.324.29",
            source_and_administration_returned_at=datetime.now(
                timezone.utc
            ).isoformat(),
            binding=ref(OUT / "binding.json"),
            administration=ref(OUT / "administration.json"),
            prior_guards=references,
            fresh_exact_known_IDs=fresh,
            failed_guardian_NULL_vs_persisted_cleanup_retained=True,
            source_leases=[],
            reservations=[],
            native_jobs_remaining=[],
            TMP_entries=tmp,
            Main_Git_Cargo_docs_otherOWN_writes=0,
            compiler_tests_native_model_RAW_RNG=0,
            costs="Each original guard wall/failed receipt retained; fullfees UNKNOWN, no scientific refund/reset/loan.",
            sealer_current_identity=process.identity(process.process_info(os.getpid())),
            sealer_lifetime="This source-STOP gains actual sealer directwait/reap/handle closure only with seal-guard-v1/result.json; delivery lifetime separate.",
            future_hostquiet=False,
        ),
    )
    # Exactly one directed own-retirement-subtree actual point. No old OWN/global walk.
    unique, apparent, allocated, count = set(), 0, 0, 0
    for directory, _, names in os.walk(OUT):
        for name in names:
            path = Path(directory) / name
            if path.is_symlink():
                continue
            st = path.stat()
            inode = st.st_dev, st.st_ino
            if inode not in unique:
                unique.add(inode)
                apparent += st.st_size
                allocated += st.st_blocks * 512
                count += 1
    point = save(
        OUT / "ordinary-affected-point.json",
        dict(
            root=str(OUT),
            scope="new retirement-v1 subtree only",
            inode_union=True,
            files=count,
            apparent_B=apparent,
            allocated_B=allocated,
            at=datetime.now(timezone.utc).isoformat(),
            includes_old_OWN_or_global_walk=False,
            recharges_refunds_loans=0,
            point_itself_and_later_small_guard_delivery_tails="UNKNOWN/excluded from this one point; no replacement of original experiment holdings claimed",
        ),
    )
    print(
        json.dumps(
            dict(source_STOP=stop, affected_point=point, known_exact_IDs=len(fresh))
        )
    )


if __name__ == "__main__":
    main()
