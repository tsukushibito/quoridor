"""Own29 meaningful note and backup at returned native/source boundary; no close."""

import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import ACTOR, ISSUE, command, ref, save  # noqa: E402

OUT = Path(__file__).resolve().parent


def beads(name, args):
    result = command(["bash", "scripts/dev/beads.sh", *args])
    target = OUT / ("beads-" + name + ".json")
    save(target, result)
    assert result["returncode"] == 0, result
    return result


def main():
    beads("ready", ["ready", "--json"])
    before = json.loads(beads("show-before", ["show", ISSUE, "--json"])["stdout"])
    assert len(before) == 1
    assert before[0]["assignee"] == ACTOR and before[0]["status"] == "in_progress"
    note = "Original208 retained OFF/no128: RETAIN_ROOT_ASPIRATION_OFF_NO_GAMES_FIXED_MAJOR_ROOT_REGRESSION. Private retirement against pushed302dca2 now fixed at .worktree/assets/perf/cedar-aspiration-window-v1/retirement-v1/binding.json:17 sparse owners, three feature-only files removed, two dedicated Runner definitions removed; full-window root function restored byte-exact, Current/Half-retirement/SMP/history/kernel/generic timed-rootquality+selected-abnormal/NN0 preserved. GNUfuzz0/nooffset byte+mode forward/inverse PASS; scoped formatter/parser/Ruff PASS. Author compiler/tests/native/model/RAW/RNG0. Root sparse adoption/affected all-target Clippy/genuine release remain pending; cleaned source unbuilt/unmeasured. All old source/result/Git/images/FAILED/NULL/UNKNOWN and pauses/seals/default/models/foreign/50GB retained. No close/status/other-owner mutation;27/28 independent scope preserved. Exact software recipe and actual helperSTOP accompany routine324 handoff. Preparation-only regex/orphan-local/gap locator failures retained; no science retry."
    beads("note", ["update", ISSUE, "--append-notes", note])
    beads("backup", ["backup", "sync"])
    after = json.loads(beads("show-after", ["show", ISSUE, "--json"])["stdout"])
    assert after[0]["assignee"] == ACTOR and after[0]["status"] == "in_progress"
    save(
        OUT / "administration.json",
        dict(
            issue=ISSUE,
            sameowner=ACTOR,
            status="in_progress",
            normal_note_and_backup="PASS",
            status_mutations=0,
            binding=ref(OUT / "binding.json"),
        ),
    )
    print(
        json.dumps(
            dict(
                issue=ISSUE,
                status="in_progress",
                meaningful_note=True,
                backup_sync=True,
            )
        )
    )


if __name__ == "__main__":
    main()
