"""Only immutable current affected owners for original29 retirement."""

import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import OWN, command, ref, save  # noqa: E402

OUT = Path(__file__).resolve().parent
COMMIT = "302dca222cab51141f6fcf61960463f35130bab1"
PATHS = [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-ai/src/aspiration_window.rs",
    "crates/quoridor-ai/src/aspiration_window_tests.rs",
    "crates/quoridor-runner/src/config.rs",
    "crates/quoridor-runner/src/runtime.rs",
    "crates/quoridor-runner/src/measurement.rs",
    "crates/quoridor-runner/src/measurement_ordering394_tests.rs",
    "scripts/dev/research-lifecycle.py",
    "scripts/dev/test_root_aspiration.py",
    "crates/quoridor-ai/src/lmr_observation.rs",
    "crates/quoridor-ai/src/move_ordering_tests.rs",
    "crates/quoridor-ai/src/tt_first386_tests.rs",
    "crates/quoridor-ai/src/lmr400_tests.rs",
    "crates/quoridor-ai/src/zero_stock411_tests.rs",
    "crates/quoridor-ai/src/zero_stock410_tests.rs",
    "crates/quoridor-ai/src/ordering_work394_tests.rs",
]
PROTECTED = [
    "crates/quoridor-ai/src/continuation_history.rs",
    "crates/quoridor-ai/src/lazy_smp.rs",
    "scripts/dev/test_research_lifecycle.py",
    "crates/quoridor-runner/src/main.rs",
    "docs/development/rust-ai.md",
]


def main():
    before = OUT / "before"
    before.mkdir()
    subjects = []
    listing = command(["git", "ls-tree", COMMIT, "--", *PATHS, *PROTECTED])
    assert listing["returncode"] == 0
    save(OUT / "git-mode-objects.json", listing)
    for name in PATHS:
        result = command(["git", "show", COMMIT + ":" + name])
        assert result["returncode"] == 0, result
        path = before / (Path(name).name + ".gz")
        with path.open("xb") as f:
            f.write(gzip.compress(result["stdout"].encode(), mtime=0))
        subjects.append(dict(path=name, before_gzip=ref(path), mode="0644"))
    result = command(
        ["git", "grep", "-n", "-i", "aspiration", COMMIT, "--", *PATHS, *PROTECTED]
    )
    assert result["returncode"] == 0
    grep_ref = save(OUT / "targeted-aspiration-references.json", result)
    evidence = save(
        OUT / "intake.json",
        dict(
            immutable_commit=COMMIT,
            subjects=subjects,
            protected_owner_locator=ref(OUT / "git-mode-objects.json"),
            targeted_references=grep_ref,
            context=ref(OWN / "context-effective-retirement-v1.json"),
            Main_Git_Cargo_docs_otherOWN_writes=0,
            compiler_tests_native_model_RAW_RNG=0,
        ),
    )
    print(json.dumps(dict(intake=evidence)))
    print(result["stdout"])


if __name__ == "__main__":
    main()
