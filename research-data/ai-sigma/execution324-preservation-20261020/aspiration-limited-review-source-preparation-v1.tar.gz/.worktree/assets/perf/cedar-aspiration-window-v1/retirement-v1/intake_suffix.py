"""One necessary native-worker initializer owner discovered in scoped references."""

import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import command, ref, save  # noqa: E402

OUT = Path(__file__).resolve().parent


def main():
    intake = json.loads((OUT / "intake.json").read_text())
    name = "crates/quoridor-ai/src/lazy_smp.rs"
    result = command(["git", "show", intake["immutable_commit"] + ":" + name])
    assert result["returncode"] == 0
    path = OUT / "before/lazy_smp.rs.gz"
    with path.open("xb") as f:
        f.write(gzip.compress(result["stdout"].encode(), mtime=0))
    assert result["stdout"].count("            aspiration: None,") == 1
    intake["subjects"].append(
        dict(
            path=name,
            before_gzip=ref(path),
            mode="0644",
            scope="Only aspiration:None worker SearchInvocation initializer; all remaining SMP body protected",
        )
    )
    save(OUT / "intake-v2.json", intake)
    snippets = []
    for file, ranges in {
        "alphabeta.rs": [(3900, 3940), (4000, 4070), (4492, 4580), (4595, 4620)],
        "config.rs": [(176, 242), (447, 466)],
        "measurement.rs": [(89, 112), (270, 300), (580, 608), (752, 775), (1404, 1423)],
        "runtime.rs": [(665, 686), (7735, 7758)],
    }.items():
        lines = (
            gzip.decompress((OUT / "before" / (file + ".gz")).read_bytes())
            .decode()
            .splitlines()
        )
        for lo, hi in ranges:
            snippets.append(
                dict(file=file, lines=[lo, hi], text="\n".join(lines[lo - 1 : hi]))
            )
    print(json.dumps(snippets, indent=2))


if __name__ == "__main__":
    main()
