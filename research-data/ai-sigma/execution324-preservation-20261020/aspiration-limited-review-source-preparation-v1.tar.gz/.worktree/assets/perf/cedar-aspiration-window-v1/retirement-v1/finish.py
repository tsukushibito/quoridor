"""Format only sparse retirement posts and record protected current-owner bodies."""

import ast
import difflib
import gzip
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import command, ref, save  # noqa: E402

OUT = Path(__file__).resolve().parent
CHANGED_LC = {
    "measurement_config",
    "measurement_evidence",
    "arena_plan_check",
    "arena_observation",
}


def checked(argv):
    result = command(argv)
    assert result["returncode"] == 0, result
    return result


def functions(text):
    lines = text.splitlines(keepends=True)
    return {
        n.name: "".join(
            lines[
                min([n.lineno, *[d.lineno for d in n.decorator_list]])
                - 1 : n.end_lineno
            ]
        )
        for n in ast.parse(text).body
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
    }


def method(text, name):
    match = re.search(r"^    fn " + name + r"(?:<|\()", text, re.M)
    assert match, name
    tail = re.search(r"^    (?:pub(?:\([^)]*\))? )?fn ", text[match.end() :], re.M)
    assert tail, name
    return text[match.start() : match.end() + tail.start()].rstrip()


def main():
    source = json.loads((OUT / "unformatted-posts-v2.json").read_text())
    final = OUT / "post-final"
    final.mkdir()
    checks = []
    subjects = []
    for row in source["subjects"]:
        if row["post"] is None:
            subjects.append(row)
            continue
        name = Path(row["path"]).name
        path = final / name
        path.write_bytes(Path(row["post"]["path"]).read_bytes())
        if path.suffix == ".rs":
            checks.append(
                checked(
                    [
                        "rustfmt",
                        "--edition",
                        "2024",
                        "--config",
                        "skip_children=true",
                        str(path),
                    ]
                )
            )
            checks.append(
                checked(
                    [
                        "rustfmt",
                        "--check",
                        "--edition",
                        "2024",
                        "--config",
                        "skip_children=true",
                        str(path),
                    ]
                )
            )
        else:
            before_format = ast.dump(
                ast.parse(path.read_text()), include_attributes=False
            )
            # Ruff range formatting in descending order avoids shifted later ranges.
            nodes = [
                n
                for n in ast.parse(path.read_text()).body
                if isinstance(n, ast.FunctionDef) and n.name in CHANGED_LC
            ]
            for node in sorted(nodes, key=lambda n: n.lineno, reverse=True):
                checks.append(
                    checked(
                        [
                            sys.executable,
                            "-m",
                            "ruff",
                            "format",
                            "--config",
                            "pyproject.toml",
                            "--line-length",
                            "100",
                            "--range",
                            f"{node.lineno}-{node.end_lineno}",
                            str(path),
                        ]
                    )
                )
            assert (
                ast.dump(ast.parse(path.read_text()), include_attributes=False)
                == before_format
            )
            checks.append(
                checked(
                    [
                        sys.executable,
                        "-m",
                        "ruff",
                        "check",
                        "--no-cache",
                        "--config",
                        "pyproject.toml",
                        str(path),
                    ]
                )
            )
        subjects.append(dict(row, post=ref(path)))
    before = {
        Path(r["path"]).name: gzip.decompress(
            Path(r["before_gzip"]["path"]).read_bytes()
        ).decode()
        for r in source["subjects"]
    }
    after = {
        Path(r["path"]).name: Path(r["post"]["path"]).read_text()
        for r in subjects
        if r["post"]
    }
    for name, text in after.items():
        assert not re.search(r"aspiration|WINDOWED", text, re.I), name
    alpha_methods = [
        "control",
        "enter",
        "ordered",
        "eager_ordered",
        "prepared_moves",
        "child",
        "reduced_child",
        "negamax",
        "negamax_entered",
        "forced_root_depth",
        "pv",
        "zero_stock_approx_value",
    ]
    same = []
    for name in alpha_methods:
        assert method(before["alphabeta.rs"], name) == method(
            after["alphabeta.rs"], name
        ), name
        same.append(name)
    for name, field, count in [
        ("lmr_observation.rs", "                aspiration: None,\n", 3),
        ("lazy_smp.rs", "            aspiration: None,\n", 1),
        (
            "measurement_ordering394_tests.rs",
            "                root_aspiration: None,\n",
            1,
        ),
    ]:
        assert before[name].count(field) == count
        assert before[name].replace(field, "") == after[name], name
    bfunc, afunc = (
        functions(before["research-lifecycle.py"]),
        functions(after["research-lifecycle.py"]),
    )
    assert set(bfunc) - set(afunc) == {"resolved_root_aspiration"}
    assert not (set(afunc) - set(bfunc))
    unchanged = [name for name in afunc if name not in CHANGED_LC]
    for name in unchanged:
        assert bfunc[name] == afunc[name], name
    # Compare only the historical ordinary root function, never restore old owners/Half.
    historical = gzip.decompress(
        (OUT.parent / "source-v1/before/alphabeta.rs.gz").read_bytes()
    ).decode()
    root_before = method(historical, "root_depth")
    root_after = method(after["alphabeta.rs"], "root_depth")
    root_diff = "".join(
        difflib.unified_diff(
            root_before.splitlines(True),
            root_after.splitlines(True),
            fromfile="historical-ordinary-root-only",
            tofile="current-full-window-root-only",
        )
    )
    (OUT / "ordinary-root-correspondence.diff").write_text(root_diff)
    checks_ref = save(OUT / "format-parser-checks.json", checks)
    protected = save(
        OUT / "protected-correspondence.json",
        dict(
            alpha_kernel_methods_byte_equal=same,
            lazy_smp_only_single_None_removed=True,
            lmr_observation_only_three_None_removed=True,
            measurement_legacy_fixture_only_None_removed=True,
            lifecycle_unchanged_function_count=len(unchanged),
            lifecycle_only_changed_functions=sorted(CHANGED_LC),
            lifecycle_removed_function="resolved_root_aspiration",
            old_full_window_root_byte_equal=root_before == root_after,
            ordinary_root_diff=ref(OUT / "ordinary-root-correspondence.diff"),
            immutable_protected_locators=source["subjects"][0]["before_gzip"],
            no_whole_historical_owner_restore=True,
            compiler_tests_native_model_RAW_RNG=0,
        ),
    )
    save(
        OUT / "formatted-posts.json",
        dict(
            base=source["base"],
            subjects=subjects,
            formatter_parser_checks=checks_ref,
            protected_correspondence=protected,
        ),
    )
    print(
        json.dumps(
            dict(
                subjects=len(subjects),
                protected_methods=len(same),
                unchanged_lifecycle_functions=len(unchanged),
                ordinary_root_equal=root_before == root_after,
                ordinary_root_diff=root_diff[:6000],
            )
        )
    )


if __name__ == "__main__":
    main()
