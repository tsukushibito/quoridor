"""Only the returned delivery's exact empty single-link uv lock; no evidence cleanup."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent))
sys.path.insert(0, str(ROOT / "python"))
from task_utils import ref, save  # noqa: E402
from quoridor_training import cycle_process as process  # noqa: E402
from seal import identities  # noqa: E402


def main():
    known = {}
    for name in ["seal-guard-v1", "delivery-guard-v1"]:
        record = json.loads((OUT / name / "result.json").read_text())
        assert record["status"] == "PASS"
        identities(record, known)
    fresh = []
    for old in known.values():
        info = process.process_info(old["pid"])
        current = process.identity(info) if info else None
        assert current != old, (old, current)
        fresh.append(dict(original=old, current=current))
    record = json.loads((OUT / "delivery-guard-v1/result.json").read_text())
    temporary = OUT / "delivery-guard-v1/TMP"
    listed = record["TMP_remaining"]
    assert len(listed) == 1
    path = Path(listed[0])
    assert (
        path.parent == temporary
        and path.name.startswith("uv-")
        and path.suffix == ".lock"
    )
    assert list(temporary.iterdir()) == [path]
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), "rb") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        before = os.fstat(stream.fileno())
        assert (
            stat.S_ISREG(before.st_mode)
            and before.st_size == 0
            and before.st_nlink == 1
        )
        actual = path.lstat()
        assert (actual.st_dev, actual.st_ino) == (before.st_dev, before.st_ino)
        path.unlink()
    temporary.rmdir()
    save(
        OUT / "delivery-tail-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            binding=ref(OUT / "binding.json"),
            source_STOP=ref(OUT / "source-STOP.json"),
            actual_sealer_return=ref(OUT / "seal-guard-v1/result.json"),
            actual_delivery_return=ref(OUT / "delivery-guard-v1/result.json"),
            fresh_known_exact_IDs_absent_or_different=fresh,
            only_removed=str(path),
            removed_bytes=0,
            O_NOFOLLOW_single_link_EXNB_same_inode=True,
            owned_TMP_remaining=[],
            source_leases=[],
            reservations=[],
            native_jobs_remaining=[],
            directwait_reap_handles="source/admin/sealer/delivery actual return records bound; cleanup's own return is cleanup-guard-v1/result.json",
            future_hostquiet=False,
            source_or_science_replay=0,
            ordinary_affected_point=ref(OUT / "ordinary-affected-point.json"),
            later_small_tails="UNKNOWN/no second affected walk",
        ),
    )
    print(
        json.dumps(
            dict(
                returned_delivery_TMP_removed=True,
                source_leases=[],
                native_jobs_remaining=[],
            )
        )
    )


if __name__ == "__main__":
    main()
