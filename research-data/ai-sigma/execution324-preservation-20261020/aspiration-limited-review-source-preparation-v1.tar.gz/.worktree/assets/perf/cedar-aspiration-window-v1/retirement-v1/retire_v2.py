"""Sparse unsupported29 removal from immutable current owners; no live source writes."""

import ast
import gzip
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import ref, save  # noqa: E402

OUT = Path(__file__).resolve().parent
DELETED = {
    "aspiration_window.rs",
    "aspiration_window_tests.rs",
    "test_root_aspiration.py",
}


def once(text, old, new=""):
    assert text.count(old) == 1, (old[:100], text.count(old))
    return text.replace(old, new, 1)


def span(text, start, end, new=""):
    assert text.count(start) == text.count(end) == 1, (start, end)
    a, b = text.index(start), text.index(end)
    assert a < b
    return text[:a] + new + text[b:]


def alpha(text):
    text = once(
        text,
        '#[path = "aspiration_window.rs"]\nmod aspiration_window;\npub use aspiration_window::{AspirationStats, AspirationWindow};\n\n',
    )
    text = once(
        text,
        "    /// Root-only research option; None retains the original OFF route.\n    pub root_aspiration: Option<AspirationWindow>,\n    pub aspiration_work: Option<AspirationStats>,\n",
    )
    # Specialize the current shared root to its existing WINDOWED=false route.
    a, b = text.index("    fn root_depth<"), text.index("    fn pv(")
    root = text[a:b]
    root = once(root, "fn root_depth<const WINDOWED: bool>(", "fn root_depth(")
    root = once(root, "        window: [f32; 2],\n")
    root = once(
        root,
        "        let original_alpha = if WINDOWED {\n            window[0]\n        } else {\n            f32::NEG_INFINITY\n        };\n        let beta = if WINDOWED { window[1] } else { f32::INFINITY };\n        let mut alpha = original_alpha;",
        "        let mut alpha = f32::NEG_INFINITY;",
    )
    root, count = re.subn(
        r"\[\s*alpha,\s*if WINDOWED \{\s*next_up\(alpha\)\.min\(beta\)\s*\} else \{\s*next_up\(alpha\)\s*\},\s*\]",
        "[alpha, next_up(alpha)]",
        root,
    )
    assert count == 2
    root = root.replace("[alpha, beta]", "[alpha, f32::INFINITY]")
    root = once(root, " && (!WINDOWED || v < beta)")
    root = once(
        root,
        "            if WINDOWED {\n                alpha = alpha.max(v);\n                if alpha >= beta {\n                    break;\n                }\n            } else {\n                alpha = value;\n            }",
        "            alpha = value;",
    )
    root = once(
        root,
        "                    bound: if WINDOWED {\n                        aspiration_window::bound(value, [original_alpha, beta])\n                    } else {\n                        Bound::Exact\n                    },",
        "                    bound: Bound::Exact,",
    )
    text = text[:a] + root + text[b:]
    assert text.count("    aspiration: Option<AspirationWindow>,\n") == 2
    text = text.replace("    aspiration: Option<AspirationWindow>,\n", "")
    assert text.count("            aspiration: None,\n") == 2
    text = text.replace("            aspiration: None,\n", "")
    text = span(
        text,
        "    /// Changing the effective window policy clears TT/history. Equal settings warm normally.\n",
        "    fn detach_safe_race_namespace(",
    )
    text = once(
        text,
        "        if let Some(config) = self.aspiration {\n            config.qualify_namespace(&mut self.namespace);\n        }\n",
    )
    text = once(
        text,
        '        #[cfg(not(target_arch = "wasm32"))]\n        if self.native_workers.is_some() && self.aspiration.is_some() {\n            return Err(SearchError::Limits(\n                "root aspiration requires LOCAL1".into(),\n            ));\n        }\n',
    )
    text = once(text, "        invocation.aspiration = self.aspiration;\n")
    text = once(
        text,
        "            root_aspiration: invocation.aspiration,\n            aspiration_work: invocation.aspiration.map(|_| AspirationStats::default()),\n",
    )
    text = span(
        text,
        "            let (action, value) = if let Some(action) = invocation.forced_root {\n",
        "            let pv = if publish_completed {\n",
        "            let (action, value) = if let Some(action) = invocation.forced_root {\n                state.forced_root_depth(&mut c, a.as_ref(), depth, action)?\n            } else {\n                state.root_depth(&mut c, a.as_ref(), depth, result.action)?\n            };\n",
    )
    text = span(
        text,
        "    if !SMP && run.is_err() {\n",
        "    let parent_not_restored =",
        "    if !SMP && run.is_err() {\n        state.table.discard_uncommitted();\n    }\n",
    )
    return text


def config(text):
    text = span(
        text,
        "#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]\n#[serde(deny_unknown_fields)]\npub struct RootAspiration",
        "#[derive(Debug, Clone, Serialize, Deserialize)]\n#[serde(deny_unknown_fields)]\npub struct Engine",
    )
    text = span(
        text,
        "    /// Research-only LOCAL1 root window; omission alone retains OFF.\n",
        "    /// Total search workers INCLUDING main;",
    )
    return once(
        text,
        "            crate::runtime::arena_root_aspiration(engine, self.arena.as_ref())\n                .map_err(|e| e.to_string())?;\n",
    )


def runtime(text):
    text = once(
        text, "    pub actual_root_aspiration: Option<crate::config::RootAspiration>,\n"
    )
    text = span(
        text,
        "pub(crate) fn arena_root_aspiration(",
        "pub(crate) fn arena_lmr_parameters(",
    )
    text = once(
        text,
        "    if let Some(c) = arena_root_aspiration(engine, arena)? {\n        c.qualify_namespace(&mut namespace);\n    }\n",
    )
    text = once(
        text,
        "    session.set_root_aspiration(arena_root_aspiration(engine, arena)?)?;\n",
    )
    text = once(
        text,
        "        profile.actual_root_aspiration = session.root_aspiration().map(Into::into);\n",
    )
    for line in [
        '        "requested_root_aspiration":config.engines[engine].root_aspiration,\n',
        '        "actual_root_aspiration":game.tt_profiles[engine].actual_root_aspiration,\n',
        '        "aspiration_work_completed":selected.and_then(|r| aspiration_work(&r.stats)),\n',
        '        "aspiration_work_terminal":result.as_deref().and_then(|r| aspiration_work(&r.stats)),\n',
    ]:
        text = once(text, line)
    assert text.count("pub(crate) fn aspiration_work(") == 1
    return text[: text.index("pub(crate) fn aspiration_work(")].rstrip() + "\n"


def measurement(text):
    text = once(
        text,
        '    #[serde(\n        default,\n        deserialize_with = "crate::config::deserialize_root_aspiration",\n        skip_serializing_if = "Option::is_none"\n    )]\n    root_aspiration: Option<crate::config::RootAspiration>,\n',
    )
    text = span(
        text,
        "    if let Some(c) = settings.root_aspiration {\n",
        "    let lmr_method = LmrMethod::from_name(",
    )
    text = once(
        text,
        "        session.set_root_aspiration(\n            self.settings\n                .root_aspiration\n                .map(|c| c.resolve())\n                .transpose()?,\n        )?;\n",
    )
    text = span(
        text,
        '        row["requested_root_aspiration"]',
        '        row["actual_selectivity"]',
    )
    text = once(
        text,
        '    if let Some(w) = crate::runtime::aspiration_work(s) {\n        result["root_aspiration_work"] = w;\n    }\n',
    )
    start = "#[cfg(test)]\nmod aspiration_measurement_boundary_tests"
    assert text.count(start) == 1
    return text[: text.index(start)].rstrip() + "\n"


def lifecycle(text):
    tree = ast.parse(text)
    lines = text.splitlines(keepends=True)
    removed = set()
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    helper = functions["resolved_root_aspiration"]
    removed.update(range(helper.lineno - 1, helper.end_lineno))
    counts = {}
    for name in [
        "measurement_config",
        "measurement_evidence",
        "arena_plan_check",
        "arena_observation",
    ]:
        count = 0
        for node in ast.walk(functions[name]):
            is_call = (
                isinstance(node, ast.Expr)
                and isinstance(node.value, ast.Call)
                and isinstance(node.value.func, ast.Name)
                and node.value.func.id == "resolved_root_aspiration"
            )
            is_if = isinstance(node, ast.If) and any(
                isinstance(n, ast.Constant) and n.value == "root_aspiration"
                for n in ast.walk(node.test)
            )
            if is_call or is_if:
                removed.update(range(node.lineno - 1, node.end_lineno))
                count += 1
        counts[name] = count
    assert counts == dict(
        measurement_config=2,
        measurement_evidence=1,
        arena_plan_check=1,
        arena_observation=1,
    ), counts
    literals = [
        i for i, line in enumerate(lines) if line.strip() == '"root_aspiration",'
    ]
    assert len(literals) == 1
    removed.update(literals)
    result = "".join(line for i, line in enumerate(lines) if i not in removed)
    ast.parse(result)
    save(
        OUT / "lifecycle-removed-statements-v2.json",
        dict(functions=counts, lines_deleted=len(removed)),
    )
    return result


def main():
    intake = json.loads((OUT / "intake-v2.json").read_text())
    posts = OUT / "post-v2"
    posts.mkdir()
    subjects = []
    transforms = {
        "alphabeta.rs": alpha,
        "config.rs": config,
        "runtime.rs": runtime,
        "measurement.rs": measurement,
        "research-lifecycle.py": lifecycle,
    }
    for row in intake["subjects"]:
        name = Path(row["path"]).name
        text = gzip.decompress(Path(row["before_gzip"]["path"]).read_bytes()).decode()
        if name in DELETED:
            subjects.append(
                dict(**row, post=None, operation="delete feature-only source")
            )
            continue
        if name in transforms:
            result = transforms[name](text)
        elif name == "lmr_observation.rs":
            assert text.count("                aspiration: None,\n") == 3
            result = text.replace("                aspiration: None,\n", "")
        elif name == "lazy_smp.rs":
            result = once(text, "            aspiration: None,\n")
        elif name == "measurement_ordering394_tests.rs":
            result = once(text, "                root_aspiration: None,\n")
        else:
            result, count = re.subn(
                r"\.root_depth::<false>\(\s*([^,\n]+),\s*None,\s*([13]),\s*None,\s*\[f32::NEG_INFINITY, f32::INFINITY\],?\s*\)",
                r".root_depth(\1, None, \2, None)",
                text,
            )
            assert count == 1, (name, count)
        assert result != text, name
        assert not re.search("aspiration|WINDOWED", result, re.IGNORECASE), name
        post = posts / name
        with post.open("x") as f:
            f.write(result)
        subjects.append(
            dict(**row, post=ref(post), operation="sparse aspiration retirement")
        )
    save(
        OUT / "unformatted-posts-v2.json",
        dict(base=intake["immutable_commit"], subjects=subjects),
    )
    print(
        json.dumps(
            dict(
                subjects=len(subjects),
                deleted=sorted(DELETED),
                private_delta_written=True,
            )
        )
    )


if __name__ == "__main__":
    main()
