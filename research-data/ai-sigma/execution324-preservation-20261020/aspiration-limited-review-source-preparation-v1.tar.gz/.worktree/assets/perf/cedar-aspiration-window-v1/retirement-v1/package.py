"""Thin reversible retirement packet. Static checks only, never Cargo/tests/Search."""

from datetime import datetime, timezone
import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import command, ref, save  # noqa: E402

OUT = Path(__file__).resolve().parent
COMMIT = "302dca222cab51141f6fcf61960463f35130bab1"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def textdiff(a, b, apath, bpath):
    return "".join(
        difflib.unified_diff(
            a.decode().splitlines(True),
            b.decode().splitlines(True),
            fromfile=apath,
            tofile=bpath,
            n=3,
        )
    )


def main():
    record = json.loads((OUT / "minimal-posts.json").read_text())
    forward, inverse, subjects = [], [], []
    temporary = Path(os.environ["TMPDIR"]) / "roundtrip"
    temporary.mkdir()
    # Only exact retired symbol current callers, immutable canonical source.
    symbols = command(
        [
            "git",
            "grep",
            "-n",
            "-e",
            "root_aspiration",
            "-e",
            "AspirationWindow",
            "-e",
            "aspiration_work",
            COMMIT,
            "--",
            "crates/quoridor-ai/src",
            "crates/quoridor-runner/src",
            "scripts/dev",
        ]
    )
    assert symbols["returncode"] == 0
    allowed = {r["path"] for r in record["subjects"]}
    for line in symbols["stdout"].splitlines():
        assert line.split(":", 2)[1] in allowed, line
    symbol_ref = save(OUT / "retired-symbol-currentcallers.json", symbols)
    total_before = total_after = 0
    for row in record["subjects"]:
        name = row["path"]
        before = gzip.decompress(Path(row["before_gzip"]["path"]).read_bytes())
        after = Path(row["post"]["path"]).read_bytes() if row["post"] else b""
        assert not re.search(rb"aspiration|WINDOWED", after, re.I)
        if row["post"]:
            forward.append(textdiff(before, after, "a/" + name, "b/" + name))
            inverse.append(textdiff(after, before, "a/" + name, "b/" + name))
        else:
            forward.append(textdiff(before, after, "a/" + name, "/dev/null"))
            inverse.append(textdiff(after, before, "/dev/null", "b/" + name))
        path = temporary / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(before)
        path.chmod(0o644)
        subjects.append(
            dict(
                row,
                before_raw=dict(sha256=digest(before), bytes=len(before), mode="0644"),
                after_raw=dict(sha256=digest(after), bytes=len(after), mode="0644")
                if row["post"]
                else None,
            )
        )
        total_before += len(before)
        total_after += len(after)
    fpath, ipath = OUT / "forward.patch", OUT / "inverse.patch"
    fpath.write_text("".join(forward))
    ipath.write_text("".join(inverse))
    outcomes = []
    for direction, patch in [("forward", fpath), ("inverse", ipath)]:
        result = command(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "--no-backup-if-mismatch",
                "-p1",
                "-d",
                str(temporary),
                "-i",
                str(patch),
            ]
        )
        assert result["returncode"] == 0, result
        assert not re.search(
            r"offset|fuzz|FAILED|reject", result["stdout"] + result["stderr"], re.I
        ), result
        for row in subjects:
            path = temporary / row["path"]
            expected = row["after_raw"] if direction == "forward" else row["before_raw"]
            if expected is None:
                assert not path.exists()
            else:
                assert path.is_file() and not path.is_symlink()
                assert digest(path.read_bytes()) == expected["sha256"]
                assert f"{stat.S_IMODE(path.stat().st_mode):04o}" == expected["mode"]
        outcomes.append(
            dict(
                direction=direction, all_17_owner_bytes_modes_exact=True, result=result
            )
        )
    shutil.rmtree(temporary)
    roundtrip = save(
        OUT / "roundtrip.json",
        dict(gnu_fuzz=0, offsets=0, outcomes=outcomes, TMP_roundtrip_removed=True),
    )
    # Existing old assertions survive; only each full-root call expression changes.
    legacy = []
    for row in subjects:
        name = Path(row["path"]).name
        if name not in {
            "move_ordering_tests.rs",
            "tt_first386_tests.rs",
            "lmr400_tests.rs",
            "zero_stock411_tests.rs",
            "zero_stock410_tests.rs",
            "ordering_work394_tests.rs",
        }:
            continue
        before = gzip.decompress(Path(row["before_gzip"]["path"]).read_bytes()).decode()
        after = Path(row["post"]["path"]).read_text()
        reduced, count = re.subn(
            r"\.root_depth::<false>\(\s*([^,\n]+),\s*None,\s*([13]),\s*None,\s*\[f32::NEG_INFINITY, f32::INFINITY\],?\s*\)",
            r".root_depth(\1, None, \2, None)",
            before,
        )
        assert count == 1
        assert re.sub(r"\s", "", reduced) == re.sub(r"\s", "", after), name
        legacy.append(
            dict(
                path=row["path"],
                exact_other_tokens=True,
                assertions_preserved=True,
                execution="UNRUN",
            )
        )
    legacy_ref = save(OUT / "legacy-call-correspondence.json", legacy)
    recipe = save(
        OUT / "affected-software-recipe.json",
        dict(
            status="ROOT_ONLY_PENDING_AFTER_SPARSE_ADOPTION",
            tests_to_execute=[],
            reason="Retired dedicated AI3/RunnerLIB2/Python1 are removed; existing assertion bodies are compiled by affected all-target Clippy, never replayed for coverage.",
            commands=[
                [
                    "cargo",
                    "clippy",
                    "-p",
                    "quoridor-ai",
                    "--all-targets",
                    "--features",
                    "research-diagnostics",
                    "--",
                    "-D",
                    "warnings",
                ],
                [
                    "cargo",
                    "clippy",
                    "-p",
                    "quoridor-runner",
                    "--all-targets",
                    "--features",
                    "measurement,quoridor-inference/claustrophobia",
                    "--",
                    "-D",
                    "warnings",
                ],
                [
                    "cargo",
                    "build",
                    "--release",
                    "-p",
                    "quoridor-runner",
                    "--bin",
                    "quoridor-runner",
                    "--features",
                    "measurement,quoridor-inference/claustrophobia",
                ],
            ],
            ordinary_route="Root maintained software/current source/admission/owned serial target/normal Build+release+one collection STOP; author does not run commands.",
            LC="Four changed named-owner functions scoped Ruff100/parser; no old metadata suite or dedicated retired Python selector. Existing generic selected-abnormal-contract/newNN0 test owner unchanged.",
            runtime_tests_or_new_science=0,
            cleaned_source_performance="UNMEASURED",
            exact_before="302dca222cab51141f6fcf61960463f35130bab1",
        ),
    )
    note = """Original29 retirement: RETAIN_ROOT_ASPIRATION_OFF_NO_GAMES_FIXED_MAJOR_ROOT_REGRESSION.

This is a private sparse delta against pushed canonical302dca2. It removes three
feature-only files (two AI modules and dedicated Python test), the two Runner test
definitions, root window/retry/config/namespace/stats, native/LC output wiring,
and obsolete initializer/caller plumbing in17 owners. The ordinary root function
alone is byte-identical to the pre-aspiration full-window function; no whole old
owner was restored. Current protected12 alpha kernel methods, remaining SMP body,
Current-only reset/aging/history math, generic timed-rootquality and selected
abnormal contract/NN0 are retained. LC other90 surviving functions are byte-exact.
No separate aspiration CLI was found in the inspected main owner; its typed JSON
entry is removed. Historical findings/agenda/results, models, images, FAILED and
Git reconstruction remain. Canonical docs are Root-owned and untouched.

Seventeen owner forward/inverse patches apply with GNU fuzz0/no offsets and
byte/mode exact forward+inverse. Scoped formatting/parser/lint are source checks,
not compile/software/numerical qualification. Root affected all-target Clippy
will type remaining legacy fixtures without executing old suites, then normal
genuine release. No author SOURCE_CLEAR, review dispatch, compiler/test/native/
model/RAW/RNG/Search. Cleaned source remains unbuilt/unmeasured.

Preserved preparation failures: initial caller-regex missed an optional trailing
comma; Ruff identified one orphan config read used only by removed evidence;
deleted-helper blank-gap locator was corrected. Successful formatting prefixes
were retained and only unfinished/changed suffixes ran. Bootstrap script failed
before stage creation once; default python executable was absent on context
readback, corrected to python3 before substantive work. None involved science.

Original208/frozen major-root regression decision, no128games, adjacent-depth/
per-attempt missingness, all costs/FAILED/NULL/UNKNOWN, pauses323/342.17, seals,
models/defaults/foreign/decimal50GB/consultation8 remain. Own29 stays in_progress
pending Root adoption/software/conclusion/normal verification; no parent/foreign
status changes or gate for27/28/independent work.
"""
    (OUT / "rationale.txt").write_text(note)
    binding = save(
        OUT / "binding.json",
        dict(
            issue="quoridor-4lc.324.29",
            assignee="codex:01a11004-79f3-7c20-872c-432a2c347664",
            status="PRIVATE_RETIREMENT_FIXED_ROOT_SOFTWARE_PENDING_NOT_SOURCE_CLEAR",
            immutable_before=COMMIT,
            subjects=subjects,
            forward=ref(fpath),
            inverse=ref(ipath),
            roundtrip=roundtrip,
            currentcaller_symbol_scope=symbol_ref,
            protected_correspondence=record["protected_correspondence"],
            final_ordinary_root_correspondence=record["ordinary_root_correspondence"],
            legacy_assertions=legacy_ref,
            scoped_formatter_suffix=record["formatter_parser_checks"],
            formatter_prefix_failure_retained=ref(OUT / "format-guard-v1/result.json"),
            final_minimization_checks=record["final_minimization_checks"],
            necessary_software_recipe=recipe,
            rationale=ref(OUT / "rationale.txt"),
            bytes_before=total_before,
            bytes_after=total_after,
            Main_Git_Cargo_docs_otherOWN_writes=0,
            author_compiler_tests_native_model_RAW_RNG=0,
            future_Build_image_performance=None,
            source_body_return_at=datetime.now(timezone.utc).isoformat(),
        ),
    )
    print(
        json.dumps(
            dict(
                binding=binding,
                forward=ref(fpath),
                inverse=ref(ipath),
                removed_bytes=total_before - total_after,
                roundtrip=roundtrip,
            )
        )
    )


if __name__ == "__main__":
    main()
