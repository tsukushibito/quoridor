"""Finalize the completed release once and retain both genuine new test results."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
BASE = Path(__file__).resolve().parent


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def point(root, seen):
    total = 0
    files = []
    for directory, _, names in os.walk(root, followlinks=False):
        for path in [Path(directory), *[Path(directory) / n for n in names]]:
            s = path.lstat()
            key = s.st_dev, s.st_ino
            if key not in seen:
                seen.add(key)
                total += s.st_blocks * 512
                if path.is_file():
                    files.append(
                        dict(
                            path=str(path),
                            device=s.st_dev,
                            inode=s.st_ino,
                            bytes=s.st_size,
                            allocated_B=s.st_blocks * 512,
                            links=s.st_nlink,
                            mtime_ns=s.st_mtime_ns,
                            mode=s.st_mode,
                        )
                    )
    return dict(path=str(root), allocated_B=total, files=files)


def main():
    out = BASE / "collection-v1"
    out.mkdir(exist_ok=False)
    loader = importlib.util.spec_from_file_location(
        "quality_software_collection_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    outer_path = BASE / "build-runtime-v3/result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((BASE / "build-runtime-v3/state.json").read_bytes())
    spec = json.loads((BASE / "build-intent-v3.json").read_bytes())
    operation = BASE / "operation-v3"
    candidate = json.loads((operation / "candidate.json").read_bytes())
    assert outer["job_id"] == "1c610b43-82cf-49e8-a747-08938eff81fd"
    assert (
        outer["outcome"] == "succeeded"
        and outer["exit_code"] == 0
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and not outer["remaining"]
    )
    assert candidate["status"] == "PENDING_FINALIZATION" and candidate["cleanup_complete"]
    assert (
        candidate["primary"] is None and not candidate["secondary"] and not candidate["remaining"]
    )
    assert [c["role"] for c in candidate["checks"] if c["role"] != "version"] == [
        "test",
        "lint",
        "build",
    ]
    prior = json.loads((BASE / "operation-v1/candidate.json").read_bytes())
    ai = next(c for c in prior["checks"] if c["name"] == "new-root-quality-snapshot-one")
    boundary = next(c for c in candidate["checks"] if c["role"] == "test")
    for check in [ai, boundary]:
        assert check["status"] == "PASS" and check["capture_complete"]
        assert ref(Path(check["full_log"]["path"])) == check["full_log"]
        text = Path(check["full_log"]["path"]).read_text()
        assert "running 1 test" in text and "test result: ok. 1 passed; 0 failed" in text
        assert check["argv"][-5] in text
    adopted = json.loads(Path(candidate["source_adoption"]["path"]).read_bytes())
    for item in adopted["retained_AI_test_evidence"]["current_AI_sources_byte_exact"]:
        assert ref(Path(item["path"])) == item
    known = []
    for check in [ai, *candidate["checks"]]:
        facts = check["guardian_return"]
        assert (
            facts["exit_code"] == 0
            and facts["direct_child_reaped"]
            and facts["cleanup_complete"]
            and facts["handle_closes_complete"]
            and not facts["remaining"]
        )
        member = facts["child"]
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(check=check["name"], original=member, fresh=fresh))
    member = state["child"]
    fresh = lc.process.identity(lc.process.process_info(member["pid"]))
    assert fresh != lc.process.identity(member)
    known.append(dict(check="original lifecycle/source child", original=member, fresh=fresh))
    assert not (operation / "manifest.json").exists() and not (operation / "finalizing").exists()
    completion = lc.finalize(operation, ref(outer_path))
    assert completion["status"] == "PASS" and not (operation / "INCOMPLETE").exists()
    manifest_ref = ref(operation / "manifest.json")
    manifest = lc.accepted_build(manifest_ref)
    assert manifest["artifact"] == candidate["artifact"]
    with lc.LEASE.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lc.source_check(spec["source"])
        assert not Path(spec["TMP"]).exists()
        assert ref(Path(manifest["artifact"]["path"])) == manifest["artifact"]
        target = Path(spec["target"])
        seen = set()
        profiles = [point(target / p, seen) for p in ["debug", "release"]]
        private = point(Path(spec["private"]).parent, seen)
        affected = save(
            out / "affected-target-and-image-once.json",
            dict(
                target_profiles=profiles,
                new_private_image=private,
                ordinary_carry_B_preserved=268 * 1024**2,
                scope="One directed actual profiles/newimage inodeunion after this realsoftware stage, no global/model/scientificwalk, oldholding recharge, peakclaim or oldcredit.",
                later_tails_globalactual_fees="UNKNOWN",
            ),
        )
        baseline = json.loads((BASE / "second-failure-collection-v1/capacity.json").read_bytes())
        actual = sum(p["allocated_B"] for p in profiles)
        cover = (
            baseline["current_known_cover_B"]
            + actual
            - baseline["current_target_B"]
            + private["allocated_B"]
        )
        capacity = save(
            out / "capacity.json",
            dict(
                previous_known_cover_B=baseline["current_known_cover_B"],
                previous_target_B=baseline["current_target_B"],
                current_target_B=actual,
                target_change_B=actual - baseline["current_target_B"],
                new_private_image_B=private["allocated_B"],
                current_known_cover_B=cover,
                remaining_to_decimal50GB_B=50000000000 - cover,
                proposed_normal26_whole_B=80 * 1024**2,
                prospective_with_whole_B=cover + 80 * 1024**2,
                normal26_support="UNISSUED; actualcapacity resolution required",
                affected_point=affected,
                old_cache_credit_reapplied=0,
                science_refund_lending_reset=0,
                globalactual_later_tails_fees="UNKNOWN",
            ),
        )
        combined = save(
            out / "new-definition-evidence.json",
            dict(
                new_AI_actual_one_PASS=dict(
                    original_FAILED_candidate=ref(BASE / "operation-v1/candidate.json"),
                    selected_name=ai["name"],
                    full_log=ai["full_log"],
                    guardian_return=ai["guardian_return"],
                ),
                current_AI_sources_byte_exact=adopted["retained_AI_test_evidence"][
                    "current_AI_sources_byte_exact"
                ],
                new_Runner_actual_one_PASS=dict(
                    normal_current_manifest=manifest_ref,
                    selected_name=boundary["name"],
                    full_log=boundary["full_log"],
                    guardian_return=boundary["guardian_return"],
                ),
                original_binary_wrongtarget_actual_definitions=0,
                original_library_v2_compilefailed_actual_definitions=0,
                new_definitions_actual_PASS=2,
                successful_test_definitions_replayed=0,
                old_source_math_suites_models_heads_RAW_RNG=0,
                scope="Selected facts from original records only; originalFAILED manifests remainFAILED, no new pipeline/parity certificate.",
            ),
        )
        fcntl.flock(lock, fcntl.LOCK_UN)
    result = save(
        out / "completion-and-STOP.json",
        dict(
            status="ACTUAL_NORMAL_BUILD_PASS_AND_SOURCE_COLLECTION_STOP",
            at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            original_job=outer["job_id"],
            outer=ref(outer_path),
            outer_command_seconds_once=outer["wall_seconds"],
            nested_added=0,
            normal_manifest=manifest_ref,
            artifact=manifest["artifact"],
            new_definition_evidence=combined,
            actual_normal_finalize_once=True,
            new_actual_definitions_PASS=2,
            successful_test_replayed=0,
            known_command_fresh_absence=known,
            notification_supervisor=dict(
                original=state["supervisor"],
                fresh=lc.process.identity(lc.process.process_info(state["supervisor"]["pid"])),
                source_domain_separate=True,
            ),
            source_Cargo_EX_NB_acquired_released=True,
            source_leases=[],
            TMP_remaining=[],
            remaining=[],
            host_future_quiet=False,
            capacity=capacity,
            model_head_Search_RAW_RNG=0,
            original_failed_jobs=[
                "b1514246-716a-49a8-8283-c27dca0d3133",
                "18790e52-7176-41b6-86f9-3b59e3db8689",
            ],
            current_four_callers=[
                ref(ROOT / p)
                for p in [
                    "scripts/dev/research-lifecycle.py",
                    "scripts/dev/research-job.py",
                    "python/quoridor_training/cycle_process.py",
                    "python/quoridor_training/snapshot.py",
                ]
            ],
            normal26="UNENTERED",
            quality_science_adoption="NOT_INFERRED",
        ),
    )
    print(
        json.dumps(
            dict(
                STOP=result,
                manifest=manifest_ref,
                artifact=manifest["artifact"],
                new_actual_definitions_PASS=2,
                capacity=capacity,
                known_cover_B=cover,
            )
        )
    )


if __name__ == "__main__":
    main()
