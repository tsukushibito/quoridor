"""Resolve actual cache growth, retaining images, test executables and scientific data."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import stat

ROOT = Path("/workspaces/quoridor")
BASE = Path(__file__).resolve().parent
OUT = BASE / "debug-cache-retirement-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def snapshot(path):
    s = path.lstat()
    return dict(
        path=str(path),
        device=s.st_dev,
        inode=s.st_ino,
        bytes=s.st_size,
        allocated_B=s.st_blocks * 512,
        mtime_ns=s.st_mtime_ns,
        links=s.st_nlink,
        mode=s.st_mode,
    )


def main():
    OUT.mkdir(exist_ok=False)
    loader = importlib.util.spec_from_file_location(
        "quality_cache_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    spec = json.loads((BASE / "build-intent.json").read_bytes())
    target = Path(spec["target"])
    original = json.loads((BASE / "operation-v1/candidate.json").read_bytes())
    manifest = json.loads((BASE / "operation-v1/manifest.json").read_bytes())
    assert manifest["status"] == "FAILED" and original["status"] == "FAILED"
    assert not (BASE / "operation-v1/INCOMPLETE").exists()
    assert not Path(spec["TMP"]).exists()
    helper_receipts = list((BASE / "first-failure-collection-guard-v1").glob("*.process.json"))
    assert len(helper_receipts) == 1
    helper = json.loads(helper_receipts[0].read_bytes())
    assert helper["direct_child_reaped"] and helper["handle_closes_complete"]
    assert helper["cleanup_complete"] and not helper["remaining"]
    known = []
    facts = [helper] + [
        c["guardian_return"]
        or json.loads(Path(c["persisted_process_receipt"]["path"]).read_bytes())
        for c in original["checks"]
    ]
    members = [f["child"] for f in facts] + [original["originating_job"]["child"]]
    for member in members:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    future = set()
    for name in ["new-root-quality-boundary-one", "affected-AI-runner-Clippy"]:
        for line in (BASE / "operation-v1" / (name + ".full.log")).read_text().splitlines():
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if row.get("reason") == "compiler-artifact":
                future.update(row["filenames"])
    with lc.LEASE.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker["writer"] == spec["writer"] and marker["target"] == str(target)
        selected = []
        protected = []
        seen = set()
        for path in (target / "debug/deps").iterdir():
            s = snapshot(path)
            eligible = path.suffix in (".rlib", ".rmeta") and (
                str(path) not in future or path.name.startswith("libquoridor_runner-")
            )
            if eligible:
                assert stat.S_ISREG(s["mode"]) and s["links"] == 1
                assert (s["device"], s["inode"]) not in seen
                seen.add((s["device"], s["inode"]))
                selected.append(s)
            else:
                protected.append(s)
        retired = sum(x["allocated_B"] for x in selected)
        assert retired > 8720384
        intent = save(
            OUT / "intent.json",
            dict(
                at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                original_FAILED_manifest=ref(BASE / "operation-v1/manifest.json"),
                original_failed_capacity=ref(BASE / "first-failure-collection-v1/capacity.json"),
                actual_first_collector_failure=ref(helper_receipts[0]),
                known_process_absence=known,
                target=str(target),
                selected=selected,
                protected=protected,
                reason="Actual first-build target growth243785728B pushes knowncover to50008720384B. Remove only stopped unused/AI-test-only debug .rlib/.rmeta and superseded normalRunner debug libraries. Correct nexttest is Runner --lib, not binary; failedClippy+newrelease remain. Futureclosure compiler filenames protected except explicitly superseded Runner library.",
                reconstruct_from="Retained Git8593752 then mechanical6d1c8af, actual Cargo.lock/foreignpatch/toolchain/offlinecommands and genuine selected test logs; offlineCargo can reconstruct intermediates. No test/compile execution here.",
                source_repair=ref(BASE / "lint-and-target-repair-v1/source-repair.json"),
                scope="debug/deps only. No .so/ELF/test executable/privateimage/release/model/data/RAW/Git/Beads/input deletion.",
                selected_allocated_B=retired,
                old_credit_refund_lending=0,
            ),
        )
        for row in selected:
            path = Path(row["path"])
            assert snapshot(path) == row
            path.unlink()
        for row in protected:
            assert snapshot(Path(row["path"])) == row
        assert all(not Path(row["path"]).exists() for row in selected)
        failed_capacity = json.loads(
            (BASE / "first-failure-collection-v1/capacity.json").read_bytes()
        )
        after = failed_capacity["current_known_cover_B"] - retired
        result = save(
            OUT / "return.json",
            dict(
                at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                intent=intent,
                retired_files=len(selected),
                actual_retired_allocated_B=retired,
                protected_files_unchanged=len(protected),
                remaining_errors=[],
                known_cover_before_B=failed_capacity["current_known_cover_B"],
                known_cover_after_B=after,
                remaining_to_decimal50GB_B=50000000000 - after,
                after_target_B=failed_capacity["current_target_B"] - retired,
                old_credit_refund_lending=0,
                globalactual_later_tails_fees="UNKNOWN",
                source_Cargo_EX_NB_released_at_return=True,
            ),
        )
        fcntl.flock(lock, fcntl.LOCK_UN)
    print(
        json.dumps(
            dict(actual_retired_allocated_B=retired, known_cover_after_B=after, receipt=result)
        )
    )


if __name__ == "__main__":
    main()
