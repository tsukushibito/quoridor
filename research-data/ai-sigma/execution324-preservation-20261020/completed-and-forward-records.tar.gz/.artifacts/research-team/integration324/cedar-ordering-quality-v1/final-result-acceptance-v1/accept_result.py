"""Accept only the completed finite interpretation and publish canonical findings."""

import datetime
import fcntl
import hashlib
import json
import os
import subprocess
from pathlib import Path

from quoridor_training import cycle_process as process

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-ordering-quality-v1"
REVIEW = ROOT / ".worktree/assets/perf/cedar-ordering-quality-review-v1/final-result-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    minimum_path = REVIEW / "minimum-result.json"
    minimum = json.loads(minimum_path.read_bytes())
    assert (
        ref(minimum_path)["sha256"]
        == "d9d65af588eda38f9aeb7058f627eb35a61d09165bed2caa4e27a3a1fb5e8e8f"
    )
    assert minimum["conclusion_clear"] and minimum["essential"] == minimum["ordinary"] == 0
    producer = minimum["producer_completion"]
    assert ref(Path(producer["path"])) == producer
    completion = json.loads(Path(producer["path"]).read_bytes())
    assert completion["calls"] == 26 and completion["original_remaining_calls"] == 0
    assert (
        completion["decision"] == "RETAIN_CONTROL_NO_CONCRETE_IMPLEMENTABLE_NEW_ORDERING_CANDIDATE"
    )
    stop_ref = minimum["actual_private_reader_STOP"]
    assert ref(Path(stop_ref["path"])) == stop_ref
    stop = json.loads(Path(stop_ref["path"]).read_bytes())
    assert (
        not stop["owned_remaining"] and not stop["owned_leases"] and not stop["Main_reader_lease"]
    )
    fresh = []
    for member in stop["fresh_exact_known_identities"]:
        original = member["original"]
        current = process.identity(process.process_info(original["pid"]))
        assert current != process.identity(original)
        fresh.append(dict(original=original, fresh=current))
    accepted = dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        issue="quoridor-4lc.324.21",
        status="ROOT_ACCEPTED_FIXED_FINITE_DIAGNOSIS",
        decision=completion["decision"],
        producer_completion=producer,
        report=completion["report"],
        summary=completion["summary"],
        actual_producer_analysis_STOP=completion["analysis_source_STOP"],
        actual_release_verification=ref(OUT / "actual-release-verification.json"),
        related_minimum=ref(minimum_path),
        related_control=ref(REVIEW / "control.json"),
        actual_related_reader_STOP=stop_ref,
        reviewer_fresh_exact_identities=fresh,
        retained_limits=minimum["constraints"],
        calls=26,
        nodes=25000193,
        fullOWN_actual_retained_B=21381120,
        ended_whole_B=83886080,
        new_known_cover_B=49917400064,
        remaining_to_decimal50GB_B=82599936,
        capacity=ref(OUT / "data-release-and-ended-capacity.json"),
        outer_command_seconds_once=37.34728797903517,
        nested_added=0,
        scientific_calls_remaining=0,
        new_implementation_games_LMR_refill_CI=0,
        future_order="If a concrete ordering candidate is later authorized, decide its finite evidence before additional LMR wide comparison; otherwise use current Control and existing LMR result without waiting for policy.",
        normal_own_closure="Accept SAME Max21.2 own closure, then SAME High21 own closure after actual child closure; no force/transfer or unrelated-work gate.",
        old_closed_LMR_17_18_20="UNCHANGED",
        all_FAILED_NULL_masks_UNKNOWNfees_pauses_seals_models_defaults_foreign_50GB="PRESERVED",
        globalactual_later_tails_fullfees="UNKNOWN",
        source_test_native_model_geometry_RAW_RNG_replay=0,
    )
    target = OUT / "accepted-result.json"
    with target.open("x") as stream:
        json.dump(accepted, stream, indent=2)
        stream.write("\n")
    prettier = ROOT / "tools/research-quality/node_modules/.bin/prettier"
    env = dict(os.environ, NODE_DISABLE_COMPILE_CACHE="1")
    subprocess.run(
        [
            str(prettier),
            "--config",
            str(ROOT / "tools/research-quality/.prettierrc.json"),
            "--ignore-path",
            "/dev/null",
            "--write",
            str(target),
        ],
        check=True,
        env=env,
        stdout=subprocess.DEVNULL,
    )
    text = """

### root順位品質の原26件診断を完了（324.21、2026-10-20）

元26 calls/25,000,193 nodes・6同色時系列sessionsは全件normal manifest/data PASS、parent復元26/26、errors0で完了した。全探索の停止は25 NodeLimit UNKNOWNと1 DepthComplete（D64/193 nodes）。前者の最深実完了iterationは深さ5〜30であり、全件D64完成やoracleではない。3family・両手番・root残壁bins2/6/6/6/6、stock0 shortfall4、既存露出と系列内TT/history依存を保持した。[元保存結果・表・STOP](../.worktree/assets/perf/cedar-ordering-quality-v1/numeric-v1/analysis-v1/completion.json)。

| 比較対象 | 分母 | Control top1 / top3 / top5 | 同点shadow top1 / top3 / top5 | 選択手がdistinct tie | 順位改善 / 悪化 / 不変 |
| --- | ---: | --- | --- | ---: | --- |
| 最深実完了snapshotの選択手 | 26 | 18 / 20 / 23 | 18 / 20 / 23 | 0 | 0 / 0 / 26 |
| 最初の実完了snapshotの選択手 | 26 | 8 / 16 / 20 | 8 / 16 / 20 | 11 | 0 / 1 / 25 |

同じsnapshotのtier＋完全signed historyが一致する群内だけを既存cheap class→ActionIDで並べ替えた比較である。最深の選択手はpromotion18・ordinary8で、promotion18件の全てが先頭のためtop1=18/26を履歴の独立な予測精度にしない。ordinary8件に限るtop1/3/5は0/2/5。最深の選択手が入るdistinct tieの条件付き精度は分母0で未定義であり、0%ではない。全体105 tie groups/78 reordered groupsは選択手の母数ではない。最初snapshotの選択tie11件は全てhistory0で、1件の6位悪化はtop件数一致だけでは見えない。

最初の順序から後の最深選択手を振り返る別比較は両順top1/3/5=8/17/19、選択手自体の変化12/26。異なるTT/history/generation/depthと実child窓を含む記述として分離し、因果比較にしない。root14の選択wall207はordinary/history−858のsingletonで94/97位に残り、同点内変更ではその観測順位を直せない。ただしhistory更新・cutoff・reductionとの対応がなく、history変更の具体案や原因を特定したとはしない。pending25/null1、途中unvisited1516/unreturned25は完了ラベルから除外、numericTT/no-order0、ROOT視点のchild窓/returnを全手のexact値へ変換しない。

限定独立確認essential0/ordinary0の後、**RETAIN_CONTROL_NO_CONCRETE_IMPLEMENTABLE_NEW_ORDERING_CANDIDATE** を受け入れた。この有限証拠では実装へ進める新候補がなく、現Controlと確定したLMR基準維持結果を使う。改善不能・一般無効果・history原因・速度/棋力や「policyしか残らない」という結論はない。将来具体候補が生じれば、その有限採否を追加LMR広域比較より先に扱うが、新実装/追加Search/対局/LMR/sweep/refill/CIは発行しない。policy学習完了を全作業の入口にしない。[Root受入れと適用範囲](../.artifacts/research-team/integration324/cedar-ordering-quality-v1/final-result-acceptance-v1/accepted-result.json)。

実native＋normalcollection＋savedanalysis STOPと記録されたexact PID/start/bootの終了、directwait/reap/handles/TMP/leasesを確認した。観測込みouter37.347287979秒を一度計上し、Search32.307573610秒やdriver/setup/drop等のnested時間を加算しない。80MiBの終了coverだけを実fullOWN21,381,120Bへ一度置換し、既知cover49,917,400,064B、decimal50GBまで82,599,936B。新point再walk・payload削除・科学枠返金/貸与はなく、以後tail/globalactual/fullfeesと旧FAILED/NULL/UNKNOWNを保持する。
"""
    lock_path = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        path = ROOT / "docs/research-findings.md"
        before = path.read_text()
        assert "### root順位品質の原26件診断を完了" not in before
        path.write_text(before + text)
        subprocess.run(
            [
                str(prettier),
                "--config",
                str(ROOT / "tools/research-quality/.prettierrc.json"),
                "--write",
                str(path),
            ],
            check=True,
            env=env,
        )
        subprocess.run(
            [
                str(prettier),
                "--config",
                str(ROOT / "tools/research-quality/.prettierrc.json"),
                "--check",
                str(path),
            ],
            check=True,
            env=env,
        )
        subprocess.run(
            ["git", "diff", "--check", "--", "docs/research-findings.md"], cwd=ROOT, check=True
        )
        assert not subprocess.check_output(
            ["git", "diff", "--cached", "--name-only"], cwd=ROOT
        ).strip()
        subprocess.run(["git", "add", "--", "docs/research-findings.md"], cwd=ROOT, check=True)
        subprocess.run(
            ["git", "commit", "-m", "Record finite root ordering-quality result and limits"],
            cwd=ROOT,
            check=True,
        )
    print(
        json.dumps(
            dict(
                status=accepted["status"],
                accepted_result=ref(target),
                source_lease="released",
                source_change=0,
            )
        )
    )


if __name__ == "__main__":
    main()
