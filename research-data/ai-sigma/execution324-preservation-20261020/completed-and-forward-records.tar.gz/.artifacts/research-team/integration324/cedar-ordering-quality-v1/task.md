# 現行orderingの順位品質を有限診断する（人間直接指示、324）

既存High17/20（01a11004-79f3-7c20-872c-432a2c347664、Sol6.1/high、cwd /workspaces/quoridor）を現在20の実STOP後に順次再用する。元20の182calls結果・通常完了は別scopeとして保持し、終了した17/LMRを再開しない。Main/Git/index/Cargo/docsはsole324、作者は新OWN `.worktree/assets/perf/cedar-ordering-quality-v1` のみ。新actor/worktree/download/Astra/恒常observer/registry/cache/frameworkなし。作成・再開はdanger-full-access/approvalPolicy neverを明示し、実turn_context/model/effort/cwdを最初の通常command前に確認する。

目的は「同点順位変更の機会がある」から先の、より深い完成探索が選んだ手を前へ置けていたかの有限診断である。policyだけが残ると仮定せず、TT優先・保護手・signed-history層と安い採点が決める同点群内順位を分ける。探索全体順位、同点群条件付き順位、駒/壁、残壁層、上位1/3/5・移動量を分母/UNKNOWN付きで示す。深い選択探索はoracleではない。

最初の実作業は保存小metadataと必要な既存sourceの照合。元 `cedar-history-neighbour-opportunity-v1/normal52-input-v1/collection-v2` の保存52/26prefix/6same-colour-series/stock層、元ordering384の保存summary・Control判断、固定入力refsを使う。旧RAW全量/全探索/solver/model再評価/旧成功suite再演をしない。元各arm17D5完成+9NodeLimitUNKNOWN、異木・相関する履歴・stock0不足を保持する。cutoff手/失敗順位が保存されていなければUNKNOWNとし、後の未探索枝、warmTT/historyと打切り偏りから因果や見落とし率を作らない。

保存だけで不足する場合、欠落fieldを先に明記し、同じ合法盤面・完全history・手番・評価器・窓・探索条件を合わせる最小案を結果前に固定する。今回の追加観測の上限は元26真正prefixから最大26calls、各最大1M nodes、合計26M、単一Control探索経路・最大6同色時系列sessions、D64/timeNone、追加対局/候補sweep/perf0。未完成/未探索はUNKNOWNのまま、count不足を補充しない。これは最大枠であり、保存で足りれば追加Search0、必要なsubsetだけをラベル非参照で凍結し、unusedを貸与しない。

必要fieldは既存bounded診断/共通measurement入口へ最小追加する。root/完成iterationのTT・history・窓状態、旧順位と安い同点内shadow順位、後の実完成depthと選択手を対応させ、異なる窓/木を黙って結合しない。hotpath毎leaf時計/全枝深い教師/大量traceなし。新sourceが必要なら作者は固定private sparsepatchと意味のある新境界fixtureだけを提出し、soleRootが既存Maxへ変更境界のみ関連確認・Main/Cargo/admissionを行う。ordinary softwareやreviewに事前micro保存枠を作らない。

saved/source解析はCPU2（物理core1、SMT3未使用）/guardian18共有、family1GiB incl64MiB管理/GPU0/hostreserve4GiB、既存CycleResources+execute・deadline/log/stop/cancel/exactPID-start-boot/directwait/reap/handles/TMP/owned[]。18.2の実ML等は別CPU16/G18の通常guardで独立に進み、この診断の完了を待たない。計時・新native観測/software Buildは実source/他job STOPへ配分し、parentclose/human/Root返信/ACKを入口にしない。追加観測の実artifact/normalconfig/inputs/whole/CPU/RAM/ownerpausecancel/origin/有限run-timeはBeadsとmanifestへ束縛してから一度入場する。暫定数値案はworker12/main0/outer18/family4GiB（1.5管理+2.5native）/host4/GPU0、RUN900/parent1200/command1140、32MiB程度のbounded trace/capture forecastだが、実supportは未発行。必要なbulkだけ50GB内へ実配分する。

受入れは順位比較表・条件/分母/UNKNOWN・具体的一改善案の有無・次の有限検証を保存し、既存findingsへRootが統合すること。明確な弱点がなければControlと既存LMR基準維持結果を利用する。新ordering実装/棋力campaign/追加LMR広域比較はこの診断から自動発行しない。将来の順序は小規模順位品質診断→根拠があれば一候補の有限採否→ordering/評価器固定→必要なLMR調整の具体化。policy導入でも毎回全campaignを必須にしない。

元LMR1920logical=1914qualified+6UNKNOWN、final512=249W263L、唯一CI [.453125,.51953125]、RETAIN_BASELINE、全FAILED/opaque1.536G/費用を確定保存する。USERPAUSE323/342.17、sealed/newE/oldfits96、models/weights/seals/product/generator defaults/foreign、旧RAW/UNKNOWN費/decimal50GB/cancelledconsultation8不変。通常owner report/verification/close/backupまでこのtask内で進め、受領だけを実開始と呼ばない。
