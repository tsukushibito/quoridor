"""Publish this fixed normal26 allocation after the actual software STOP."""

import datetime
import fcntl
import hashlib
import json
import subprocess
from pathlib import Path

from quoridor_training import cycle_process as process

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
BUILD = BASE / "software-v1"
OWN = ROOT / ".worktree/assets/perf/cedar-ordering-quality-v1"
PRETTIER = ROOT / "tools/research-quality/node_modules/.bin/prettier"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    subprocess.run(
        [
            str(PRETTIER),
            "--config",
            str(ROOT / "tools/research-quality/.prettierrc.json"),
            "--ignore-path",
            "/dev/null",
            "--write",
            str(path),
        ],
        check=True,
        stdout=subprocess.DEVNULL,
    )
    return ref(path)


def main():
    stop_path = BUILD / "collection-v1/completion-and-STOP.json"
    stop = json.loads(stop_path.read_bytes())
    assert stop["status"] == "ACTUAL_NORMAL_BUILD_PASS_AND_SOURCE_COLLECTION_STOP"
    assert stop["new_actual_definitions_PASS"] == 2 and stop["successful_test_replayed"] == 0
    capacity_path = BUILD / "collection-v1/capacity.json"
    capacity = json.loads(capacity_path.read_bytes())
    assert capacity["current_known_cover_B"] == 49896018944
    guard_path = BUILD / "success-collection-guard-v1/return.json"
    guard = json.loads(guard_path.read_bytes())
    assert guard["exit_code"] == 0 and guard["direct_child_reaped"]
    assert guard["cleanup_complete"] and guard["handle_closes_complete"] and not guard["remaining"]
    fresh = process.identity(process.process_info(guard["child"]["pid"]))
    assert fresh != process.identity(guard["child"])
    lock_path = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        callers = stop["current_four_callers"]
        assert all(ref(Path(item["path"])) == item for item in callers)
        subprocess.run(
            [
                str(PRETTIER),
                "--config",
                str(ROOT / "tools/research-quality/.prettierrc.json"),
                "--check",
                "docs/research-findings.md",
            ],
            cwd=ROOT,
            check=True,
        )
        subprocess.run(
            ["git", "diff", "--check", "--", "docs/research-findings.md"], cwd=ROOT, check=True
        )
        staged = subprocess.check_output(
            ["git", "diff", "--cached", "--name-only"], cwd=ROOT, text=True
        ).strip()
        assert not staged, staged
        subprocess.run(["git", "add", "--", "docs/research-findings.md"], cwd=ROOT, check=True)
        subprocess.run(
            ["git", "commit", "-m", "Record ordering diagnostic software and finite allocation"],
            cwd=ROOT,
            check=True,
        )
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_SOURCE_SOFTWARE_COLLECTION_RELEASED",
                at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                current_commit=commit,
                current_four_callers=callers,
                source_adoption=ref(BUILD / "sparse-source-adoption.json"),
                software_manifest=stop["normal_manifest"],
                artifact=stop["artifact"],
                new_definition_evidence=stop["new_definition_evidence"],
                actual_software_STOP=ref(stop_path),
                collector_guard=ref(guard_path),
                collector_exact_identity=dict(original=guard["child"], fresh=fresh),
                source_Cargo_EX_NB_acquired_released=True,
                source_leases_remaining=[],
                source_after_Build="Canonical findings only; qualified source bytes unchanged.",
                host_future_quiet=False,
                normal26="UNENTERED",
                quality_strength_speed_model_adoption="NOT_INFERRED",
            ),
        )
    whole = 80 * 1024**2
    forecast = 71569408
    known = capacity["current_known_cover_B"] + whole
    assert known == 49979905024 and known < 50000000000
    resources = dict(
        worker_cpu=12,
        main_guardian=0,
        outer_guardian=18,
        launch_affinity=[0, 12, 18],
        family_B=4 * 1024**3,
        controller_B=1536 * 1024**2,
        native_B=2560 * 1024**2,
        host_reserve_B=4 * 1024**3,
        GPU=0,
        threads=1,
        CPU=2,
        controller_included=True,
        family_RAM_B=4 * 1024**3,
        controller_RAM_B=1536 * 1024**2,
    )
    limits = dict(
        worker_cpu=12,
        guardian_cpu=0,
        family_B=resources["family_B"],
        controller_B=resources["controller_B"],
        host_reserve_B=resources["host_reserve_B"],
        owned_B=whole,
        free_B=whole - forecast,
        log_B=1024**2,
    )
    support = save(
        "phase-support.json",
        dict(
            issue="quoridor-4lc.324.21",
            status="ISSUED_ORIGINAL_NORMAL26_AT_ACTUAL_SOFTWARE_STOP",
            fixed_plan=ref(OWN / "normal26-preparation-v1/fixed-plan-v2.json"),
            result_before_analysis_recipe=ref(
                OWN / "light-control-preparation-v1/analysis-recipe.json"
            ),
            holding_correction=ref(OWN / "normal26-preparation-v1/holding-correction-v1.json"),
            current_source_adoption=release,
            actual_source_STOP=release,
            actual_software_STOP=ref(stop_path),
            whole_B=whole,
            roots=[str(OWN)],
            storage_budget=dict(whole_B=whole, roots=[str(OWN)]),
            owned_B=whole,
            free_B=whole - forecast,
            readonly_images_models_copy_B=0,
            native_aggregate_B=20 * 1024**2,
            perf_RAW_B=0,
            total_original_calls=26,
            total_original_nodes=26000000,
            mode="OffShadow",
            depth=64,
            nodes_per_call=1000000,
            time_ms=None,
            same_colour_sessions=6,
            resources=resources,
            limits=limits,
            RUN_timeout_s=900,
            parent_accepted_s=1200,
            parent_command_s=1140,
            cleanup_margin_s=60,
            timeout_resolution="One900s RUN plus300s standard setup/collection; command cleanup60s. Fresh end_at at actual submit once.",
            holding_forecast=dict(
                retained_source_B=9703424,
                future_native_B=20 * 1024**2,
                future_LC_copy_B=19 * 1024**2,
                serial_TMP_B=8 * 1024**2,
                logs_B=4 * 1024**2,
                future_analysis_control_B=8 * 1024**2,
                total_B=forecast,
                margin_B=whole - forecast,
                scope="Includes actual oldsource once; current full OWN holding/growth checked by normal owner. Not serializerPASS.",
            ),
            capacity_basis=ref(capacity_path),
            prior_known_cover_B=capacity["current_known_cover_B"],
            new_known_cover_B=known,
            remaining_to_decimal50GB_B=50000000000 - known,
            allocation="One normal serial RUN worker12/main0/outer18, launch0,12,18; no simultaneous Cargo/ML/native/perf/heavyIO through actual native+normalcollection STOP.",
            normal_remaining_inputs="Normal numerical_fields inherited641ca only, real current refs/typed Experiment, fresh origin/end_at, physicalSMT/peers/RAM/fullroot holding/free/ownerpausecancel. No placeholder executes.",
            source_quality="Source and software only; quality outcome UNKNOWN; pending/numericTT/unreturned do not become completed teachers.",
            original64_support="Historical proposal only; never issued or reused.",
            ordinary_source_build="One affected point already checked; old cache credits not reapplied.",
            science_refund_lending_reset=0,
            old_closed_LMR_17_18_20="PRESERVED; no reopening/replay",
            global_actual_fees_later_tails="UNKNOWN",
            pauses_seals_models_defaults_foreign_FAILED_UNKNOWN="PRESERVED",
        ),
    )
    bindings = json.loads(
        (OWN / "light-control-preparation-v1/bindings.template.json").read_bytes()
    )
    experiment = json.loads((OWN / "normal26-preparation-v1/experiment.draft.json").read_bytes())
    bindings.update(
        source_adoption=release,
        actual_Root_source_STOP=release,
        actual_software_STOP=ref(stop_path),
        build_manifest=stop["normal_manifest"],
        artifact=stop["artifact"],
        caller_sources=callers,
        dynamic_libraries=experiment["dynamic_libraries"],
        support=support,
        inherited_same_body_scope="Original641ca inherited Cedar structural correspondence only; no new model/head parity.",
        resolved_timeouts=dict(RUN_s=900, parent_accepted_s=1200, command_s=1140, cleanup_s=60),
    )
    result = save("actual-bindings.json", bindings)
    print(
        json.dumps(
            dict(
                status="ISSUED_ACTUAL_INPUTS_NOT_NUMERICAL_ADMISSION",
                support=support,
                bindings=result,
                source_release=release,
                normal26="UNENTERED",
            )
        )
    )


if __name__ == "__main__":
    main()
