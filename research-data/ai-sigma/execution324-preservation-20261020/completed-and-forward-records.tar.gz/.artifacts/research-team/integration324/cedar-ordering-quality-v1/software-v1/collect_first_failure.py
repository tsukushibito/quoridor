"""Collect the original failed software and preserve its distinct cleanup domains."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
BASE = Path(__file__).resolve().parent


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def allocated(root, seen):
    total = count = 0
    for directory, _, files in os.walk(root, followlinks=False):
        for path in [Path(directory), *[Path(directory) / name for name in files]]:
            st = path.lstat()
            key = st.st_dev, st.st_ino
            if key not in seen:
                seen.add(key)
                total += st.st_blocks * 512
                count += 1
    return dict(path=str(root), allocated_B=total, entries=count)


def main():
    out = BASE / "first-failure-collection-v1"
    out.mkdir(exist_ok=False)
    loader = importlib.util.spec_from_file_location(
        "quality_failed_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    process = lc.process
    operation = BASE / "operation-v1"
    candidate_path = operation / "candidate.json"
    original_candidate = ref(candidate_path)
    candidate = json.loads(candidate_path.read_bytes())
    spec = json.loads((BASE / "build-intent.json").read_bytes())
    outer_path = BASE / "build-runtime-v1/result.json"
    outer = json.loads(outer_path.read_bytes())
    assert outer["job_id"] == "b1514246-716a-49a8-8283-c27dca0d3133"
    assert outer["outcome"] == "failed" and outer["exit_code"] == 1
    assert outer["cleanup_complete"] and outer["direct_child_reaped"] and not outer["remaining"]
    assert candidate["status"] == "FAILED" and not candidate["cleanup_complete"]
    checks = candidate["checks"]
    ai = next(c for c in checks if c["name"] == "new-root-quality-snapshot-one")
    boundary = next(c for c in checks if c["name"] == "new-root-quality-boundary-one")
    failed = next(c for c in checks if c["name"] == "affected-AI-runner-Clippy")
    assert ai["status"] == "PASS" and boundary["status"] == "PASS" and failed["status"] == "FAILED"
    for c in [ai, boundary]:
        assert ref(Path(c["full_log"]["path"])) == c["full_log"]
    assert "running 1 test" in Path(ai["full_log"]["path"]).read_text()
    assert "test result: ok. 1 passed; 0 failed" in Path(ai["full_log"]["path"]).read_text()
    assert "running 0 tests" in Path(boundary["full_log"]["path"]).read_text()
    assert failed["guardian_return"] is None and not failed["capture_complete"]
    disk = json.loads(Path(failed["persisted_process_receipt"]["path"]).read_bytes())
    assert (
        ref(Path(failed["persisted_process_receipt"]["path"]))
        == failed["persisted_process_receipt"]
    )
    assert disk["exit_code"] == 101 and disk["direct_child_reaped"]
    assert disk["cleanup_complete"] and disk["handle_closes_complete"] and not disk["remaining"]
    known = []
    for check in checks:
        facts = check["guardian_return"]
        domain = "actual returned guardian"
        if facts is None:
            facts = json.loads(Path(check["persisted_process_receipt"]["path"]).read_bytes())
            domain = "persisted disk only; guardian return remains NULL"
        member = facts["child"]
        fresh = process.identity(process.process_info(member["pid"]))
        assert fresh != process.identity(member)
        known.append(dict(name=check["name"], original=member, fresh=fresh, domain=domain))
    member = candidate["originating_job"]["child"]
    fresh = process.identity(process.process_info(member["pid"]))
    assert fresh != process.identity(member)
    known.append(dict(name="original source/lifecycle child", original=member, fresh=fresh))
    assert not (operation / "manifest.json").exists() and not (operation / "finalizing").exists()
    completion = lc.finalize(operation, ref(outer_path))
    assert completion["status"] == "FAILED"
    assert ref(candidate_path) == original_candidate
    assert not (operation / "INCOMPLETE").exists()
    with lc.LEASE.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lc.source_check(spec["source"])
        tmp = Path(spec["TMP"])
        late_tmp = dict(
            path=str(tmp),
            original_candidate_cleanup=False,
            guardian_return=None,
            disk_receipt=failed["persisted_process_receipt"],
        )
        if tmp.exists():
            fd = os.open(tmp, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                assert not os.listdir(fd)
            finally:
                os.close(fd)
            os.rmdir(tmp)
            late_tmp["late_empty_directory_removed"] = True
        else:
            late_tmp["already_absent"] = True
        target = Path(spec["target"])
        seen = set()
        profiles = [allocated(target / profile, seen) for profile in ["debug", "release"]]
        point = save(
            out / "affected-storage-once.json",
            dict(
                target_profiles=profiles,
                ordinary_controls=allocated(BASE, set()),
                old_profile_baseline_B=545955840,
                scope="One affected first-failed-build point, no global/oldscientific walk; later suffix replaces this current target once.",
                globalactual_later_tails_fees="UNKNOWN",
            ),
        )
        actual = sum(p["allocated_B"] for p in profiles)
        cover = 49764934656 + actual - 545955840
        capacity = save(
            out / "capacity.json",
            dict(
                previous_known_cover_B=49764934656,
                previous_target_B=545955840,
                current_target_B=actual,
                target_change_B=actual - 545955840,
                current_known_cover_B=cover,
                remaining_to_decimal50GB_B=50000000000 - cover,
                affected_point=point,
                refunds_lending_oldcredit=0,
                globalactual_later_fees="UNKNOWN",
            ),
        )
        assert cover <= 50000000000
        fcntl.flock(lock, fcntl.LOCK_UN)
    record = dict(
        status="ORIGINAL_FAILED_NORMAL_MANIFEST_AND_ACTUAL_SOURCE_STOP",
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        job=outer["job_id"],
        outer=ref(outer_path),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        original_candidate=original_candidate,
        normal_failed_manifest=ref(operation / "manifest.json"),
        original_candidate_cleanup=False,
        outer_cleanup=True,
        failed_guardian_return=None,
        failed_disk_cleanup=True,
        failed_disk_mask=disk["signal_mask_restoration"],
        failed_disk_persist=disk["final_record_persist"],
        late_empty_TMP=late_tmp,
        known_original_processes=known,
        source_Cargo_EX_released=True,
        leases=[],
        remaining=[],
        successful_AI_selected_check=dict(
            file=original_candidate, name=ai["name"], full_log=ai["full_log"], actual_definitions=1
        ),
        runner_binary_filter=dict(
            file=original_candidate,
            name=boundary["name"],
            actual_definitions=0,
            status="UNENTERED required definition; target must be lib",
        ),
        failure="Clippy field_reassign_with_default at measurement.rs538..540",
        unentered="correct Runner library definition and genuine release",
        original_success_replay=0,
        native_Search_model_RAW_RNG=0,
        capacity=capacity,
        host_future_quiet=False,
    )
    stop = save(out / "completion-and-STOP.json", record)
    print(
        json.dumps(
            dict(
                STOP=stop,
                normal_failed_manifest=record["normal_failed_manifest"],
                successful_AI_definitions=1,
                runner_definitions=0,
                capacity=capacity,
                current_known_cover_B=cover,
            )
        )
    )


if __name__ == "__main__":
    main()
