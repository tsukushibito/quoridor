"""Collect the actual failed prefix, preserving failed and disk-finalization domains."""

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    loader = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


def main():
    helpers = load("saved_collection_helpers", BASE / "collect_second_failure_once.py")
    lc = load("actual_prefix_collection_lifecycle", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helpers.ref
    outer_path = BASE / "check-runtime-v5/result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((BASE / "check-runtime-v5/state.json").read_bytes())
    spec = json.loads((BASE / "build-intent-v5.json").read_bytes())
    candidate_path = BASE / "operation-v5/prefix-result.json"
    original = ref(candidate_path)
    result = json.loads(candidate_path.read_bytes())
    assert outer["job_id"] == "7cdfd988-9588-4741-8367-d61d5689a395"
    assert (
        outer["outcome"] == "failed"
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and not outer["remaining"]
    )
    assert result["status"] == "FAILED" and result["cleanup_complete"] is False
    assert len(result["checks"]) == 1
    passed = []
    for check in passed:
        assert check["status"] == "PASS" and check["capture_complete"]
        assert ref(Path(check["full_log"]["path"])) == check["full_log"]
        saved_pass = Path(check["full_log"]["path"]).read_text()
        selector = check["argv"][check["argv"].index("--lib") + 1]
        assert "running 1 test" in saved_pass and f"test {selector} ... ok" in saved_pass
        assert "test result: ok. 1 passed; 0 failed" in saved_pass
        assert check["guardian_return"]["exit_code"] == 0
    failed = result["checks"][-1]
    assert (
        failed["name"] == "new-SMP-affected-Clippy"
        and failed["status"] == "FAILED"
        and failed["guardian_return"] is None
        and not failed["capture_complete"]
    )
    assert ref(Path(failed["full_log"]["path"])) == failed["full_log"]
    saved = Path(failed["full_log"]["path"]).read_text()
    assert (
        "this `if` statement can be collapsed" in saved
        and "called `unwrap` on `self.settings.search_threads`" in saved
    )
    assert "running 1 test" not in saved
    assert (
        ref(Path(failed["persisted_process_receipt"]["path"]))
        == failed["persisted_process_receipt"]
    )
    disk = json.loads(Path(failed["persisted_process_receipt"]["path"]).read_bytes())
    assert (
        disk["exit_code"] == 101
        and disk["cleanup_complete"]
        and disk["direct_child_reaped"]
        and disk["handle_closes_complete"]
        and not disk["remaining"]
    )
    known = []
    for member in [
        *[check["guardian_return"]["child"] for check in passed],
        disk["child"],
        state["child"],
        state["supervisor"],
    ]:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    with lc.lease():
        lc.source_check(spec["source"])
        temporary = Path(spec["TMP"])
        assert temporary.is_dir() and not any(temporary.iterdir())
        temporary.rmdir()
        seen = set()
        profiles = [
            helpers.point(Path(spec["target"]) / name, seen) for name in ["debug", "release"]
        ]
        actual = sum(row["allocated_B"] for row in profiles)
        cover = 49744618496 + actual - 494403584
        point_path = OUT / "affected-target-once.json"
        point_path.write_text(
            json.dumps(
                dict(
                    target_profiles=profiles,
                    scope="One directed ended prefix target point only",
                    later_globalactual_fees="UNKNOWN",
                ),
                indent=2,
            )
            + "\n"
        )
        assert cover <= 50000000000
    assert ref(candidate_path) == original
    result = dict(
        status="ORIGINAL_CLIPPY_RUNNER_STYLE_FAILED_ACTUAL_SOURCE_STOP",
        outer=ref(outer_path),
        original_prefix_result=original,
        original_cleanup=False,
        disk_cleanup=True,
        original_returned_guardian=None,
        disk_receipt=failed["persisted_process_receipt"],
        disk_mask=disk["signal_mask_restoration"],
        disk_persist=disk["final_record_persist"],
        actual_new_Rust_definitions=0,
        actual_new_Rust_passed=0,
        passed_Rust_checks=[
            dict(
                name=check["name"],
                full_log=check["full_log"],
                guardian=check["persisted_process_receipt"],
            )
            for check in passed
        ],
        retained_SMP_Rust_pass=6,
        retained_Python_pass=2,
        remaining="Runner Clippy2 equivalent style fixes and genuine release; prior11 Rust/Python2 PASS retained",
        known_fresh_absence=known,
        late_empty_TMP_removed=str(temporary),
        source_leases=[],
        remaining_owned=[],
        target_point=ref(point_path),
        current_target_B=actual,
        current_known_cover_B=cover,
        remaining_to_decimal50GB_B=50000000000 - cover,
        outer_seconds_once=outer["wall_seconds"],
        accepted_inclusive_seconds_once=(
            datetime.datetime.fromisoformat(outer["finished_at"])
            - datetime.datetime.fromisoformat(state["created_at"])
        ).total_seconds(),
        nested_added=0,
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        host_future_quiet=False,
    )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {
                k: result[k]
                for k in [
                    "status",
                    "current_target_B",
                    "current_known_cover_B",
                    "remaining_to_decimal50GB_B",
                    "accepted_inclusive_seconds_once",
                ]
            }
        )
    )


if __name__ == "__main__":
    main()
