"""Collect the actual second compiler failure without replaying any definition."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
BASE = Path(__file__).resolve().parent
OUT = BASE / "second-failure-collection-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def point(root, seen):
    total, files = 0, []
    for directory, _, names in os.walk(root, followlinks=False):
        for path in [Path(directory), *[Path(directory) / name for name in names]]:
            info = path.lstat()
            key = info.st_dev, info.st_ino
            if key in seen:
                continue
            seen.add(key)
            total += info.st_blocks * 512
            if path.is_file():
                files.append(
                    dict(
                        path=str(path),
                        device=info.st_dev,
                        inode=info.st_ino,
                        bytes=info.st_size,
                        allocated_B=info.st_blocks * 512,
                        links=info.st_nlink,
                        mtime_ns=info.st_mtime_ns,
                        mode=info.st_mode,
                    )
                )
    return dict(path=str(root), allocated_B=total, files=files)


def main():
    loader = importlib.util.spec_from_file_location(
        "actual_SMP_failed_collection", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    process = lc.process
    spec = json.loads((BASE / "build-intent-v2.json").read_bytes())
    outer_path = BASE / "build-runtime-v2/result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((BASE / "build-runtime-v2/state.json").read_bytes())
    operation = BASE / "operation-v2"
    candidate_path = operation / "candidate.json"
    candidate_ref = ref(candidate_path)
    candidate = json.loads(candidate_path.read_bytes())
    assert outer["job_id"] == "a2f05281-5642-47f4-b8e3-55797b3a5b58"
    assert outer["outcome"] == "failed" and outer["exit_code"] == 1
    assert outer["cleanup_complete"] and outer["direct_child_reaped"] and not outer["remaining"]
    assert candidate["status"] == "FAILED" and candidate["cleanup_complete"] is False
    tests = [x for x in candidate["checks"] if x["role"] != "version"]
    assert len(tests) == 7
    passed = tests[:6]
    for index, check in enumerate(passed, 1):
        assert check["name"] == f"new-SMP-AI-{index}" and check["status"] == "PASS"
        assert (
            check["capture_complete"] and ref(Path(check["full_log"]["path"])) == check["full_log"]
        )
        saved = Path(check["full_log"]["path"]).read_text()
        selector = check["argv"][check["argv"].index("--lib") + 1]
        assert "running 1 test" in saved and f"test {selector} ... ok" in saved
        assert "test result: ok. 1 passed; 0 failed" in saved
        assert check["guardian_return"]["exit_code"] == 0
    failed = tests[-1]
    assert failed["name"] == "new-SMP-Runner-1" and failed["status"] == "FAILED"
    assert failed["guardian_return"] is None and failed["capture_complete"] is False
    assert ref(Path(failed["full_log"]["path"])) == failed["full_log"]
    text = Path(failed["full_log"]["path"]).read_text()
    assert "could not compile `quoridor-runner` (lib test) due to 1 previous error" in text
    assert "running 1 test" not in text and "test result:" not in text
    errors = []
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith(("error[", "warning: use of deprecated")):
            errors.append("\n".join(lines[i : min(i + 16, len(lines))]))
    compiler = save(
        "actual-compiler-diagnostics.json",
        dict(
            source_commit=spec["source"]["commit"],
            full_log=failed["full_log"],
            actual_Rust_definitions_executed=6,
            diagnostics=errors,
        ),
    )
    known = []
    for check in candidate["checks"]:
        facts = check["guardian_return"]
        domain = "actual returned guardian"
        if facts is None:
            assert (
                ref(Path(check["persisted_process_receipt"]["path"]))
                == check["persisted_process_receipt"]
            )
            facts = json.loads(Path(check["persisted_process_receipt"]["path"]).read_bytes())
            domain = "persisted disk only; original returned guardian remains NULL"
            disk = facts
        member = facts["child"]
        fresh = process.identity(process.process_info(member["pid"]))
        assert fresh != process.identity(member)
        known.append(dict(name=check["name"], original=member, fresh=fresh, domain=domain))
    assert (
        disk["exit_code"] == 101
        and disk["cleanup_complete"]
        and disk["direct_child_reaped"]
        and disk["handle_closes_complete"]
        and disk["remaining"] == []
    )
    for name, member in [
        ("original source/lifecycle child", candidate["originating_job"]["child"]),
        ("original notification supervisor", state["supervisor"]),
    ]:
        fresh = process.identity(process.process_info(member["pid"]))
        assert fresh != process.identity(member)
        known.append(dict(name=name, original=member, fresh=fresh))
    completion = lc.finalize(operation, ref(outer_path))
    assert completion["status"] == "FAILED" and ref(candidate_path) == candidate_ref
    with lc.LEASE.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lc.source_check(spec["source"])
        temporary = Path(spec["TMP"])
        late_tmp = dict(
            original_candidate_cleanup=False,
            failed_returned_guardian=None,
            disk_cleanup=True,
            path=str(temporary),
        )
        if temporary.exists():
            fd = os.open(temporary, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                assert os.listdir(fd) == []
            finally:
                os.close(fd)
            temporary.rmdir()
            late_tmp["late_empty_directory_removed"] = True
        else:
            late_tmp["already_absent"] = True
        seen = set()
        profiles = [point(Path(spec["target"]) / name, seen) for name in ["debug", "release"]]
        actual = sum(x["allocated_B"] for x in profiles)
        affected = save(
            "affected-target-once.json",
            dict(
                target_profiles=profiles,
                scope="One directed actual ended failed-BUILD target profile union; old source/science/model holdings not walked",
                later_tails_globalactual_fees="UNKNOWN",
            ),
        )
        cover = 49663734784 + actual - 413519872
        capacity = save(
            "capacity.json",
            dict(
                previous_known_cover_B=49821549568,
                previous_target_B=571334656,
                current_target_B=actual,
                target_change_B=actual - 571334656,
                current_known_cover_B=cover,
                remaining_to_decimal50GB_B=50000000000 - cover,
                affected_point=affected,
                old_credits_refund_lending_reset=0,
                later_tails_globalactual_fees="UNKNOWN",
            ),
        )
        assert cover <= 50000000000
    inclusive = (
        datetime.datetime.fromisoformat(outer["finished_at"])
        - datetime.datetime.fromisoformat(state["created_at"])
    ).total_seconds()
    stopped = save(
        "completion-and-STOP.json",
        dict(
            status="ORIGINAL_FAILED_COMPILER_AND_ACTUAL_SOURCE_STOP",
            at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            job_id=outer["job_id"],
            outer=ref(outer_path),
            outer_seconds_once=outer["wall_seconds"],
            accepted_inclusive_seconds_once=inclusive,
            nested_added=0,
            original_candidate=candidate_ref,
            normal_failed_manifest=ref(operation / "manifest.json"),
            original_candidate_cleanup=False,
            outer_cleanup=True,
            failed_returned_guardian=None,
            failed_disk_receipt=failed["persisted_process_receipt"],
            failed_disk_cleanup=True,
            failed_disk_mask=disk["signal_mask_restoration"],
            failed_disk_persist=disk["final_record_persist"],
            late_empty_TMP=late_tmp,
            known_original_processes=known,
            actual_compiler_diagnostics=compiler,
            actual_Rust_definitions_executed=6,
            actual_Python_new_two="Prior PASS retained; not replayed",
            retained_passed_Rust=[x["name"] for x in passed],
            still_unentered="Runner2+history3 Rust definitions/Clippy/release/208 scientific calls/conditional64",
            source_Cargo_EX_released=True,
            source_leases=[],
            remaining=[],
            capacity=capacity,
            host_future_quiet=False,
        ),
    )
    print(
        json.dumps(
            dict(
                STOP=stopped,
                current_known_cover_B=cover,
                remaining_B=50000000000 - cover,
                Rust_definitions=6,
                outer_seconds_once=outer["wall_seconds"],
                accepted_inclusive_seconds_once=inclusive,
            )
        )
    )


if __name__ == "__main__":
    main()
