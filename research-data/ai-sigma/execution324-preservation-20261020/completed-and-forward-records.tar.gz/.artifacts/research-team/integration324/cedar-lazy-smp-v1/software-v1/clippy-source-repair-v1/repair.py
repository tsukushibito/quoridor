"""Apply only two compiler-proven Clippy source repairs without changing search work."""

import fcntl
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
FILES = [
    "alphabeta.rs",
    "lazy_smp.rs",
    "lmr400_tests.rs",
    "lmr408_tests.rs",
    "lmr_parameter_settings_tests.rs",
]


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    paths = [ROOT / "crates/quoridor-ai/src" / name for name in FILES]
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        before = [ref(path) for path in paths]
        for path in paths:
            expected = subprocess.run(
                ["git", "show", f"HEAD:{path.relative_to(ROOT)}"],
                cwd=ROOT,
                check=True,
                capture_output=True,
            ).stdout
            assert path.read_bytes() == expected
        lazy = paths[1]
        old = """        if result.is_ok() {
            if let Some(error) = report.workers.iter().skip(1).find_map(|r| r.error.as_ref()) {
                result = Err(SearchError::Evaluation(format!(
                    \"native helper failure: {error}\"
                )));
            }
        }
""".replace('"', '"')
        text = lazy.read_text()
        assert text.count(old) == 1
        new = """        if result.is_ok()
            && let Some(error) = report.workers.iter().skip(1).find_map(|r| r.error.as_ref())
        {
            result = Err(SearchError::Evaluation(format!(
                \"native helper failure: {error}\"
            )));
        }
""".replace('"', '"')
        lazy.write_text(text.replace(old, new, 1))
        counts = []
        for path in [paths[0], *paths[2:]]:
            text = path.read_text()
            pattern = (
                r"(\.reduced_child\(\n(?:[^\n]*\n){3})([ \t]*)(\[[^\n]+\]),\n[ \t]*([^\n]+),\n"
            )
            text, count = re.subn(
                pattern, lambda m: m[1] + m[2] + "(" + m[3] + ", " + m[4] + "),\n", text
            )
            counts.append(dict(path=str(path), callsites=count))
            if path == paths[0]:
                old_params = "        child_depths: [u16; 2],\n        alpha: f32,\n"
                assert text.count(old_params) == 1
                text = text.replace(old_params, "        child_search: ([u16; 2], f32),\n", 1)
                old_let = "        let [child_depth, reduced_depth] = child_depths;"
                assert text.count(old_let) == 1
                text = text.replace(
                    old_let, "        let (child_depths, alpha) = child_search;\n" + old_let, 1
                )
            path.write_text(text)
        assert [row["callsites"] for row in counts] == [2, 3, 1, 1]
        for path in paths:
            subprocess.run(
                ["rustfmt", "--edition", "2024", "--config", "skip_children=true", str(path)],
                check=True,
                cwd=ROOT,
                capture_output=True,
            )
            subprocess.run(
                [
                    "rustfmt",
                    "--edition",
                    "2024",
                    "--config",
                    "skip_children=true",
                    "--check",
                    str(path),
                ],
                check=True,
                cwd=ROOT,
                capture_output=True,
            )
        diff = subprocess.run(
            ["git", "diff", "--", *[str(path.relative_to(ROOT)) for path in paths]],
            check=True,
            cwd=ROOT,
            capture_output=True,
        ).stdout
        (OUT / "actual.patch").write_bytes(diff)
        after = [ref(path) for path in paths]
    result = dict(
        status="ACTUAL_TWO_CLIPPY_SOURCE_REPAIRS_SOFTWARE_SUFFIX_UNRUN",
        before=before,
        after=after,
        patch=ref(OUT / "actual.patch"),
        callsites=counts,
        changes="Short-circuit-equivalent helper error let-chain; private reduced-child depths and alpha passed as one inline Copy tuple and immediately destructured, no allocation/new state/algorithm/control change. Seven calls retain identical scalar expressions, assertions untouched.",
        new_tests=0,
        old_Rust11_and_Python2="saved PASS once, not replayed",
        source_leases=[],
        host_future_quiet=False,
    )
    with (OUT / "actual-repair.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(status=result["status"], callsites=counts, source_leases=[])))


if __name__ == "__main__":
    main()
