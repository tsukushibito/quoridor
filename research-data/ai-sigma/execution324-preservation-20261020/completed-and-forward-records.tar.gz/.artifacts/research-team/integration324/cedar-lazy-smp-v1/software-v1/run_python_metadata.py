"""Run only the two new canonical metadata definitions, retaining a prefix."""

import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import CycleResources, execute, identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def main():
    temporary = OUT / "python-TMP"
    temporary.mkdir()
    deadline = time.monotonic() + 120
    resources = CycleResources(
        dict(max_memory_bytes=1024**3 - 64 * 1024**2, host_ram_reserve=4 * 1024**3), OUT, deadline
    )
    env = dict(os.environ, TMPDIR=str(temporary), CUDA_VISIBLE_DEVICES="")
    commands = [
        (
            "new-SMP-Python-one",
            [
                sys.executable,
                "-B",
                "-m",
                "unittest",
                "scripts.dev.test_research_lifecycle.LifecycleDataAndPaths.test_native_search_team_cpu_family_is_total_not_per_engine",
            ],
        ),
        (
            "new-history-Python-one",
            [
                sys.executable,
                "-B",
                str(
                    ROOT
                    / ".worktree/assets/perf/cedar-history-score-v1/test_history_provenance_config.py"
                ),
                "HistoryProvenanceConfigBoundary.test_selected_entries_are_bounded_typed_and_default_absent",
            ],
        ),
    ]
    results = []
    lock_path = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    try:
        with lock_path.open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
            source_hash = hashlib.sha256(
                (ROOT / "scripts/dev/research-lifecycle.py").read_bytes()
            ).hexdigest()
            for name, command in commands:
                result = execute(
                    command,
                    OUT / (name + ".log"),
                    deadline,
                    cpu_core=0,
                    resources=resources,
                    cwd=ROOT,
                    env=env,
                )
                assert result["exit_code"] == 0 and result["cleanup_complete"]
                assert identity(process_info(result["child"]["pid"])) != result["child"]
                results.append(dict(name=name, actual_return=result))
                with (OUT / (name + "-returned.json")).open("x") as stream:
                    json.dump(results[-1], stream, indent=2)
                    stream.write("\n")
            assert (
                hashlib.sha256(
                    (ROOT / "scripts/dev/research-lifecycle.py").read_bytes()
                ).hexdigest()
                == source_hash
            )
        temporary.rmdir()
        with (OUT / "new-Python-two-STOP.json").open("x") as stream:
            json.dump(
                dict(
                    status="NEW_TWO_METADATA_DEFINITIONS_RETURNED",
                    source_sha256=source_hash,
                    results=results,
                    source_leases=[],
                    TMP=[],
                    old_success_replay=0,
                    model_native_Search_RNG=0,
                ),
                stream,
                indent=2,
            )
            stream.write("\n")
        print(
            json.dumps(
                dict(
                    new_definitions=len(results),
                    source_sha256=source_hash,
                    TMP=[],
                    source_leases=[],
                )
            )
        )
    finally:
        if temporary.exists() and not any(temporary.iterdir()):
            temporary.rmdir()


if __name__ == "__main__":
    main()
