"""Repair only the two compiler-proven equivalent Runner style sites."""

import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    relative = "crates/quoridor-runner/src/measurement.rs"
    path = ROOT / relative
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        before = ref(path)
        prior = subprocess.run(
            ["git", "show", f"HEAD:{relative}"], cwd=ROOT, check=True, capture_output=True
        ).stdout
        assert path.read_bytes() == prior
        old = b"""    if let Some(reserve) = settings.time_reserve_ms {
        if settings.search_threads.is_none()
            || requests
                .iter()
                .any(|r| r.time_limit_ms.is_none_or(|ms| ms <= reserve))
        {
            return Err(\"reserve belongs to explicit positive clock-budget search requests\".into());
        }
    }
"""
        new = b"""    if let Some(reserve) = settings.time_reserve_ms
        && (settings.search_threads.is_none()
            || requests
                .iter()
                .any(|r| r.time_limit_ms.is_none_or(|ms| ms <= reserve)))
    {
        return Err(\"reserve belongs to explicit positive clock-budget search requests\".into());
    }
"""
        assert prior.count(old) == 1
        expected = prior.replace(old, new, 1)
        old_threads = b"""        if self.settings.search_threads.is_some() {
            row[\"search_threads\"] = json!(self.settings.search_threads.unwrap());
"""
        new_threads = b"""        if let Some(search_threads) = self.settings.search_threads {
            row[\"search_threads\"] = json!(search_threads);
"""
        assert expected.count(old_threads) == 1
        expected = expected.replace(old_threads, new_threads, 1)
        path.write_bytes(expected)
        formatted = subprocess.run(
            ["rustfmt", "--edition", "2024", "--config", "skip_children=true", str(path)],
            cwd=ROOT,
            check=True,
            capture_output=True,
        )
        assert path.read_bytes() == expected
        subprocess.run(
            [
                "rustfmt",
                "--edition",
                "2024",
                "--config",
                "skip_children=true",
                "--check",
                str(path),
            ],
            cwd=ROOT,
            check=True,
            capture_output=True,
        )
        patch = subprocess.run(
            ["git", "diff", "--", relative], cwd=ROOT, check=True, capture_output=True
        ).stdout
        (OUT / "actual.patch").write_bytes(patch)
        result = dict(
            status="ACTUAL_TWO_EQUIVALENT_RUNNER_STYLE_REPAIRS_CLIPPY_UNRUN",
            before=before,
            after=ref(path),
            patch=ref(OUT / "actual.patch"),
            runtime_short_circuit_conditions_and_serialized_values_preserved=True,
            scoped_rustfmt_exit=formatted.returncode,
            new_tests_executed=0,
            retained_Rust_pass=11,
            retained_Python_pass=2,
            remaining="Clippy and genuine release only; original11 Rust and Python2 PASS not replayed",
            source_lease_remaining=[],
            host_future_quiet=False,
        )
    with (OUT / "actual-repair.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
