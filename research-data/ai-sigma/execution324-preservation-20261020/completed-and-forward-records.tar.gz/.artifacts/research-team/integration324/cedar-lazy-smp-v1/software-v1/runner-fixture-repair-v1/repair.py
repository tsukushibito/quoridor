"""Repair only the compiler-proven absent diagnostic field in an existing fixture."""

import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    relative = "crates/quoridor-runner/src/measurement_ordering394_tests.rs"
    path = ROOT / relative
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        before = ref(path)
        prior = subprocess.run(
            ["git", "show", f"HEAD:{relative}"], cwd=ROOT, check=True, capture_output=True
        ).stdout
        assert path.read_bytes() == prior
        old = b"                root_ordering_quality: None,\n"
        new = old + b"                history_provenance: None,\n"
        assert prior.count(old) == 1
        path.write_bytes(prior.replace(old, new, 1))
        formatted = subprocess.run(
            ["rustfmt", "--edition", "2024", "--config", "skip_children=true", str(path)],
            cwd=ROOT,
            check=True,
            capture_output=True,
        )
        assert path.read_bytes() == prior.replace(old, new, 1)
        subprocess.run(
            [
                "rustfmt",
                "--edition",
                "2024",
                "--config",
                "skip_children=true",
                "--check",
                str(path),
            ],
            cwd=ROOT,
            check=True,
            capture_output=True,
        )
        patch = subprocess.run(
            ["git", "diff", "--", relative], cwd=ROOT, check=True, capture_output=True
        ).stdout
        (OUT / "actual.patch").write_bytes(patch)
        result = dict(
            status="ACTUAL_ONE_FIXTURE_FIELD_REPAIRED_SOFTWARE_SUFFIX_UNRUN",
            before=before,
            after=ref(path),
            patch=ref(OUT / "actual.patch"),
            old_assertions_and_runtime_sources_unchanged=True,
            scoped_rustfmt_exit=formatted.returncode,
            new_tests_executed=0,
            retained_SMP_Rust_pass=6,
            retained_Python_pass=2,
            remaining="Five Rust definitions and Clippy, then genuine release after capacity settlement",
            source_lease_remaining=[],
            host_future_quiet=False,
        )
    with (OUT / "actual-repair.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
