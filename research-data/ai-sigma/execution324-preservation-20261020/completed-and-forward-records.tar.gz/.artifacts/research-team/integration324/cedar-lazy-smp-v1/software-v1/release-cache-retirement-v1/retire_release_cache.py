"""Retire only stopped rebuildable release library/metadata for real capacity."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path

from quoridor_training import cycle_process as process

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PRIOR = ROOT / ".artifacts/research-team/integration324/cedar-ordering-quality-v1/software-v1"
TARGET = (
    ROOT
    / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/target"
)
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def main():
    point_path = OUT.parent / "second-failure-collection-v1/affected-target-once.json"
    assert (
        ref(point_path)["sha256"]
        == "3b352f491ebdeeb67d3f90f6b9aabf420632fe407747b126fc5910fde0c4f1ed"
    )
    point = json.loads(point_path.read_bytes())
    files = point["target_profiles"][1]["files"]
    selected = []
    skipped_links = []
    for item in files:
        path = Path(item["path"])
        if path.suffix not in {".rlib", ".rmeta"}:
            continue
        assert path.is_relative_to(TARGET / "release")
        if item["links"] != 1:
            skipped_links.append(item)
        else:
            selected.append(item)
    stop = json.loads(
        (OUT.parent / "second-failure-collection-v1/completion-and-STOP.json").read_bytes()
    )
    identities = [item["original"] for item in stop["known_original_processes"]]
    fresh = []
    for item in identities:
        current = process.identity(process.process_info(item["pid"]))
        assert current != process.identity(item)
        fresh.append(dict(original=item, fresh=current))
    released = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with released.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        marker_path = TARGET / ".research-owner.json"
        marker = ref(marker_path)
        assert json.loads(marker_path.read_bytes())["writer"] == WRITER
        assert json.loads(marker_path.read_bytes())["target"] == str(TARGET)
        for item in selected:
            path = Path(item["path"])
            stat = path.lstat()
            assert not path.is_symlink() and path.is_file()
            assert (
                stat.st_dev,
                stat.st_ino,
                stat.st_size,
                stat.st_blocks * 512,
                stat.st_nlink,
                stat.st_mtime_ns,
                stat.st_mode,
            ) == (
                item["device"],
                item["inode"],
                item["bytes"],
                item["allocated_B"],
                item["links"],
                item["mtime_ns"],
                item["mode"],
            )
        intent = save(
            "intent.json",
            dict(
                at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                target=str(TARGET),
                source_point=ref(point_path),
                selected=selected,
                skipped_nonunique_links=skipped_links,
                restoration="Offline Cargo with preserved source/Git, actual toolchain/dependency source/env and recorded build-intent-v2.json. No old test replay; these are compile caches, not runtime artifacts.",
                actual_recipe=ref(OUT.parent / "build-intent-v2.json"),
                target_marker=marker,
                source_writer_and_Cargo_EX_NB=True,
                exact_prior_compilers_fresh_absent=fresh,
                scope="Release .rlib/.rmeta only, currently unused by active Root jobs; release remains genuinely unentered. New release compilation may regenerate these files after remaining tests/Clippy and an actual capacity check. They may be rebuilt for new software; regeneration CPU is not free.",
                preserved="All executable/.so/private images/capturedtest libraries/models/Git/RAW/FAILED/source/logs/Beads/debug cache",
                known_cover_before_B=49986229248,
                prospective_SMP176MiB="UNISSUED",
                no_new_storage_grant_or_science_refund=True,
            ),
        )
        removed = []
        failure = None
        try:
            for item in selected:
                path = Path(item["path"])
                stat = path.lstat()
                assert (stat.st_dev, stat.st_ino, stat.st_nlink, stat.st_mtime_ns) == (
                    item["device"],
                    item["inode"],
                    1,
                    item["mtime_ns"],
                )
                path.unlink()
                removed.append(item)
        except BaseException as error:
            failure = dict(type=type(error).__name__, message=str(error))
            raise
        finally:
            reclaimed = sum(item["allocated_B"] for item in removed)
            assert ref(marker_path) == marker
            result = save(
                "return.json",
                dict(
                    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    intent=intent,
                    status="COMPLETE" if failure is None else "FAILED_PARTIAL_PRESERVED",
                    failure=failure,
                    actually_unlinked=len(removed),
                    actual_unique_allocated_B_removed_once=reclaimed,
                    current_known_cover_B=49986229248 - reclaimed,
                    remaining_to_decimal50GB_B=50000000000 - (49986229248 - reclaimed),
                    target_profile_before_B=736014336,
                    target_profile_after_unlinks_B=736014336 - reclaimed,
                    exact_unlinked_paths=[item["path"] for item in removed],
                    marker_unchanged=True,
                    old192856064_or_prior_credits_reapplied=0,
                    scientific_refund_lending_reset=0,
                    source_lease_remaining=[],
                    host_future_quiet=False,
                    later_tails_globalactual_fullfees="UNKNOWN",
                ),
            )
            print(
                json.dumps(
                    dict(
                        result=result,
                        removed_B=reclaimed,
                        remaining_B=50000000000 - (49986229248 - reclaimed),
                    )
                )
            )


if __name__ == "__main__":
    main()
