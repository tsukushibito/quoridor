"""Bind only the genuinely unfinished software after the compiler repair."""

import copy
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PRIOR = ROOT / ".artifacts/research-team/integration324/cedar-ordering-quality-v1/software-v1"
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def git(*args):
    return subprocess.run(
        ["git", *args], cwd=ROOT, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ).stdout


def main():
    loader = importlib.util.spec_from_file_location(
        "actual_SMP_BUILD_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    old = json.loads((PRIOR / "build-intent-v3.json").read_bytes())
    draft = json.loads((OUT / "software-commands.draft-v2.json").read_bytes())
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert git("diff", "--cached", "--name-only") == b""
        patch = OUT / "actual-foreign-source-v7.patch"
        with patch.open("xb") as stream:
            stream.write(git("diff", "--binary", "--no-ext-diff", "--no-textconv", "HEAD", "--"))
        source = copy.deepcopy(old["source"])
        source.update(
            commit=git("rev-parse", "HEAD").decode().strip(),
            patch=ref(patch),
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        assert source["untracked_inputs"] == []
        assert not git(
            "ls-files",
            "--others",
            "--exclude-standard",
            "--",
            "Cargo.toml",
            "Cargo.lock",
            ".cargo",
            "crates",
        )
        for witness in source["cargo_configs"]:
            path = Path(witness["path"])
            witness["file"] = ref(path) if path.exists() else None
        adoption = save(
            "build-source-adoption-v7.json",
            dict(
                schema="quoridor.research.source-adoption.v1",
                status="ACCEPTED",
                issue="quoridor-4lc.324.22",
                source=source,
                actual_SMP_adoption=ref(OUT.parent / "source-adoption-v1/actual-return.json"),
                actual_history_composition=ref(
                    ROOT
                    / ".artifacts/research-team/integration324/cedar-history-score-v1/source-composition-v1/actual-composition-return.json"
                ),
                source_review=ref(
                    ROOT
                    / ".worktree/assets/perf/cedar-lazy-smp-review-v1/related-r1-o1-v1/minimum-result.json"
                ),
                history_source_review=ref(
                    ROOT / ".worktree/assets/perf/cedar-history-score-review-v1/minimum-result.json"
                ),
                new_Python_two=ref(OUT / "new-Python-two-STOP.json"),
                prior_software=dict(
                    subjects=[
                        ref(ROOT / "crates/quoridor-runner/src/config.rs"),
                        ref(ROOT / "crates/quoridor-runner/src/measurement.rs"),
                        ref(ROOT / "crates/quoridor-ai/src/alphabeta.rs"),
                        ref(ROOT / "crates/quoridor-ai/src/lazy_smp.rs"),
                        ref(ROOT / "crates/quoridor-ai/src/history_provenance.rs"),
                    ],
                    receipts=[
                        dict(
                            name="new-SMP-Runner-1",
                            file=ref(OUT / "operation-v4/prefix-result.json"),
                        ),
                        dict(
                            name="new-SMP-affected-Clippy",
                            file=ref(OUT / "operation-v6/prefix-result.json"),
                        ),
                    ],
                ),
                actual_clippy_PASS=ref(OUT / "clippy-pass-collection-v1/completion-and-STOP.json"),
                actual_runner_clippy_repair=ref(
                    OUT / "runner-clippy-source-repair-v1/actual-repair.json"
                ),
                actual_clippy_source_repair=ref(OUT / "clippy-source-repair-v1/actual-repair.json"),
                retained_Rust11=ref(
                    OUT / "fourth-prefix-failure-collection-v1/completion-and-STOP.json"
                ),
                actual_positive_fixture=ref(
                    OUT.parent / "runner-positive-fixture-adoption-v1/actual-adoption.json"
                ),
                actual_visibility_repair=ref(
                    ROOT
                    / ".artifacts/research-team/integration324/cedar-history-score-v1/visibility-adoption-v1/actual-adoption.json"
                ),
                actual_fixture_repair=ref(OUT / "runner-fixture-repair-v1/actual-repair.json"),
                retained_Rust_six=ref(
                    OUT / "fourth-prefix-failure-collection-v1/completion-and-STOP.json"
                ),
                actual_compile_repair=ref(
                    OUT.parent / "canonical-compile-adoption-v1/actual-adoption.json"
                ),
                original_failed_software_STOP=ref(
                    OUT / "clippy-pass-collection-v1/completion-and-STOP.json"
                ),
                scope="Prior reviewed source plus ordinary canonical19-site compiler/type/API repair. SMP Rust6 and Python2 savedPASS retained; existing absent history field plus failed-positive fixture mode and seven narrow visibility declarations repaired. Genuine release-only suffix after actual Clippy PASS; prior11 Rust/Python2 retained, no test/lint replay, genuine release only after actual capacity settlement. No model/strength/clock qualification.",
            ),
        )
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
        )
        support = save(
            "resources-v7.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.22",
                authority=adoption,
                resources=dict(
                    worker_cpu=12,
                    guardian_cpu=16,
                    test_cpu_cores=[12, 14, 16],
                    native_threads=1,
                    GPU=0,
                    family_RAM_B=4 * 1024**3,
                    controller_included=True,
                    controller_B=64 * 1024**2,
                    host_reserve_B=4 * 1024**3,
                ),
                storage_budget=None,
                scope="Ordinary genuine release-only suffix; Rust11/Python2/affectedClippy actual PASS retained; release stays unentered until actual capacity settlement. Compile j1; actual synthetic SMP tests main/helper12/14, guardian16, outer18. Normal fresh peer/RAM/affinity/source/origin admission remains mandatory. No numerical grant.",
                known_cover_B=49425736704,
                current_ended_target_B=175521792,
                actual_first_failure_capacity=ref(
                    OUT / "fourth-prefix-failure-collection-v1/completion-and-STOP.json"
                ),
                actual_cache_retirement=ref(OUT / "debug-after-clippy-retirement-v2/return.json"),
                SMP176MiB="UNISSUED",
                history32MiB="UNISSUED",
                later_tails_globalactual_fees="UNKNOWN",
            ),
        )
        target = Path(old["target"])
        marker = target / ".research-owner.json"
        prior_marker = json.loads(marker.read_bytes())
        assert prior_marker["writer"] == WRITER and prior_marker["target"] == str(target)
        save("prior-target-marker-v7.json", prior_marker)
        old_handover = json.loads((PRIOR / "target-handover-v3.json").read_bytes())
        assert not Path(old_handover["old_target"]).exists()
        handover = save(
            "target-handover-v7.json",
            dict(
                schema="research.target-handover.v1",
                status="HANDED_OVER",
                target=str(target),
                target_writer=WRITER,
                shared_serial_pool=True,
                old_target=old_handover["old_target"],
                fresh_private_root=str(OUT / "private-image-v7"),
                owned_remaining=[],
                test_cpu_cores=[12, 14, 16],
                actual_last_guard_STOP=ref(
                    OUT / "clippy-pass-collection-v1/completion-and-STOP.json"
                ),
                actual_current_source_guard_STOP=ref(
                    OUT / "debug-after-clippy-retirement-v2/guard-return.json"
                ),
                actual_composition_guard_STOP=ref(
                    ROOT
                    / ".artifacts/research-team/integration324/cedar-history-score-v1/source-composition-v1/apply-guard-return.json"
                ),
                actual_cache_guard_STOP=ref(
                    OUT / "debug-after-clippy-retirement-v2/guard-return.json"
                ),
                scope="Single existing serial Root target; prior compiler/native/source reader lifetimes ended. No hostfuturequiet assertion.",
            ),
        )
        commands = [
            {k: v for k, v in row.items() if k in {"name", "role", "argv"}}
            for row in draft["commands"]
        ]
        cargo = old["tools"]["CARGO"]["file"]["path"]
        for name, package, features, selector in [
            (
                "new-history-AI-identity",
                "quoridor-ai",
                "research-diagnostics",
                "alphabeta::continuation_history::history_provenance::history_provenance_boundary_tests::selected_history_entry_identity_and_exact_gravity_delta",
            ),
            (
                "new-history-AI-ring",
                "quoridor-ai",
                "research-diagnostics",
                "alphabeta::continuation_history::history_provenance::history_provenance_boundary_tests::selected_history_ring_age_and_missing_returns_are_bounded",
            ),
            (
                "new-history-Runner-settings",
                "quoridor-runner",
                "measurement,quoridor-inference/claustrophobia",
                "measurement::history_provenance_settings_tests::history_watch_typed_refusal_and_default_output_absence",
            ),
        ]:
            commands.insert(
                -2,
                dict(
                    name=name,
                    role="test",
                    argv=[
                        cargo,
                        "test",
                        "--offline",
                        "--locked",
                        "--manifest-path",
                        str(ROOT / "Cargo.toml"),
                        "-j1",
                        "--message-format=json-render-diagnostics",
                        "-p",
                        package,
                        "--features",
                        features,
                        "--lib",
                        selector,
                        "--",
                        "--exact",
                        "--nocapture",
                        "--test-threads=1",
                    ],
                ),
            )
        for row in commands:
            if row["role"] == "lint" and "--keep-going" not in row["argv"]:
                row["argv"].insert(2, "--keep-going")
        spec = copy.deepcopy(old)
        for key in ("admission", "intent_sha256"):
            spec.pop(key, None)
        spec.update(
            output=str(OUT / "operation-v7"),
            support=support,
            source_adoption=adoption,
            target_handover=handover,
            source=source,
            limits=limits,
            commands=[row for row in commands if row["role"] == "build"],
            private=str(OUT / "private-image-v7/quoridor-runner"),
            TMP=str(OUT / "build-TMP-v7"),
            test_cpu_cores=[12, 14, 16],
            command_timeout_seconds=2457,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        marker.write_text(
            json.dumps(
                dict(writer=WRITER, target=str(target), support_sha256=support["sha256"]), indent=2
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            "build-admission-v7.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Actual source/normal BUILD bindings. Fresh physical peer/RAM/source/origin authority enforced by normal job at actual entry; ordinary software has no storage microgrant.",
            ),
        )
        intent = save("build-intent-v7.json", spec)
        job = dict(
            issue="quoridor-4lc.324",
            goal_issue="quoridor-4lc.324",
            thread_id="01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            cwd=str(ROOT),
            argv=[
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "build",
                "--intent",
                intent["path"],
                "--sha256",
                intent["sha256"],
            ],
            end_at=None,
            notify_until=None,
            max_runtime_seconds=2577,
            control_interval_seconds=30,
            notify_interval_seconds=10,
            request_timeout_seconds=25,
            log_max_bytes=16384,
            resource_contract=support["path"],
        )
        save("job-release-v7.json", job)
        print(
            json.dumps(
                dict(
                    intent=intent,
                    new_Rust_definitions=0,
                    canonical_Python_definitions_already_PASS=2,
                    actual_job=None,
                    source_leases=[],
                )
            )
        )


if __name__ == "__main__":
    main()
