"""Adopt the reviewed SMP subjects only after exact current-before checks."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-lazy-smp-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def checked(path, sha, size):
    result = ref(path)
    assert result["sha256"] == sha and result["bytes"] == size and result["mode"] == "0644"
    return json.loads(path.read_bytes()), result


def main():
    original, original_ref = checked(
        OWN / "fixed-source-v2/source-binding.json",
        "9fdb8e0ecfe052d313b2c5685ca0571028fdfb3b6d86d215c522615b7c98f749",
        23161,
    )
    repair, repair_ref = checked(
        OWN / "negative-review-repair-v1/source-binding.json",
        "d31f6afb881bf08bc13325197ec52fec979e54ff6485068b048b61fef6426ab2",
        16980,
    )
    review, review_ref = checked(
        ROOT
        / ".worktree/assets/perf/cedar-lazy-smp-review-v1/related-r1-o1-v1/minimum-result.json",
        "adb884b9550532208941da0e31fc2f9d76eea101b79e34609f34dbf10b07b9cc",
        1101,
    )
    assert review["essential"] == review["ordinary"] == 0
    posts = {item["path"]: item["repaired_post"] for item in repair["changed_owners"]}
    rows = []
    lock_path = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for subject in original["subjects"]:
            path = ROOT / subject["path"]
            expected = subject["before"]
            before = ref(path) if path.exists() else None
            if expected is None:
                assert before is None
            else:
                assert all(before[key] == expected[key] for key in ("sha256", "bytes", "mode"))
            post = posts.get(subject["path"], subject["post"])
            assert ref(Path(post["path"])) == post
            rows.append(dict(path=str(path), before=before, accepted_post=post))
        with (OUT / "actual-intent.json").open("x") as stream:
            json.dump(
                dict(
                    original=original_ref,
                    repair=repair_ref,
                    related_review=review_ref,
                    exclusive_current_before_all_PASS=rows,
                ),
                stream,
                indent=2,
            )
            stream.write("\n")
        for row in rows:
            path = Path(row["path"])
            path.write_bytes(Path(row["accepted_post"]["path"]).read_bytes())
            path.chmod(0o644)
            assert {key: ref(path)[key] for key in ("sha256", "bytes", "mode")} == {
                key: row["accepted_post"][key] for key in ("sha256", "bytes", "mode")
            }
            row["actual_after"] = ref(path)
    result = dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status="ACTUAL_REVIEWED_SMP_MAIN_SOURCE_ADOPTED_SOFTWARE_UNRUN",
        subjects=rows,
        source_Cargo_EX_NB_released=True,
        source_leases=[],
        model_or_foreign_writes=0,
        software_or_performance_PASS=False,
        old_negative_preserved=True,
        source23="Not adopted by this operation; separate sparse composition only",
    )
    with (OUT / "actual-return.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(subjects=len(rows), status=result["status"], source_leases=[])))


if __name__ == "__main__":
    main()
