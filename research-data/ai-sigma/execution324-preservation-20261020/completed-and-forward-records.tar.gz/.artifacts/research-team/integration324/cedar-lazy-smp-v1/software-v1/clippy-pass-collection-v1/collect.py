"""Collect the actual completed Clippy prefix and the ended target once."""

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    loader = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


def main():
    helpers = load("saved_metadata_helpers", BASE / "collect_second_failure_once.py")
    lc = load("actual_clippy_collection", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helpers.ref
    runtime = BASE / "check-runtime-v6"
    outer = json.loads((runtime / "result.json").read_bytes())
    state = json.loads((runtime / "state.json").read_bytes())
    spec = json.loads((BASE / "build-intent-v6.json").read_bytes())
    receipt_path = BASE / "operation-v6/prefix-result.json"
    result = json.loads(receipt_path.read_bytes())
    assert outer["job_id"] == "474ba95b-df94-4f62-9c11-909e26588a23"
    assert (
        outer["outcome"] == "succeeded"
        and outer["exit_code"] == 0
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and not outer["remaining"]
    )
    assert (
        result["status"] == "PASS_CLIPPY_PREFIX_ONLY"
        and result["cleanup_complete"]
        and result["TMP"] == []
        and not result["release_executed"]
    )
    assert len(result["checks"]) == 1
    check = result["checks"][0]
    assert (
        check["name"] == "new-SMP-affected-Clippy"
        and check["status"] == "PASS"
        and check["capture_complete"]
        and not check["primary"]
        and not check["secondary"]
    )
    assert ref(Path(check["full_log"]["path"])) == check["full_log"]
    cargo = lc.cargo_report(Path(check["full_log"]["path"]).read_bytes())
    assert cargo["warning_count"] == 0
    guardian = check["guardian_return"]
    lc.settled(guardian)
    assert guardian["handle_closes_complete"]
    known = []
    for member in [guardian["child"], state["child"], state["supervisor"]]:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    with lc.lease():
        lc.source_check(spec["source"])
        assert not Path(spec["TMP"]).exists()
        seen = set()
        profiles = [
            helpers.point(Path(spec["target"]) / name, seen) for name in ["debug", "release"]
        ]
        actual = sum(row["allocated_B"] for row in profiles)
        cover = 49744618496 + actual - 494403584
        point_path = OUT / "affected-target-once.json"
        with point_path.open("x") as stream:
            json.dump(
                dict(
                    target_profiles=profiles,
                    scope="One directed ended Clippy target point; no global/scientific holding walk",
                    later_globalactual_fees="UNKNOWN",
                ),
                stream,
                indent=2,
            )
            stream.write("\n")
        assert cover <= 50000000000
    inclusive = (
        datetime.datetime.fromisoformat(outer["finished_at"])
        - datetime.datetime.fromisoformat(state["created_at"])
    ).total_seconds()
    packet = dict(
        status="CLIPPY_ACTUAL_PASS_RELEASE_UNENTERED_ACTUAL_SOURCE_STOP",
        receipt=ref(receipt_path),
        actual_clippy=check,
        outer=ref(runtime / "result.json"),
        outer_seconds_once=outer["wall_seconds"],
        accepted_inclusive_seconds_once=inclusive,
        nested_added=0,
        retained_Rust11_Python2="PASS once; not replayed",
        release_executed=False,
        known_fresh_absence=known,
        source_leases=[],
        remaining_owned=[],
        TMP=[],
        target_point=ref(point_path),
        current_target_B=actual,
        current_known_cover_B=cover,
        remaining_to_decimal50GB_B=50000000000 - cover,
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        host_future_quiet=False,
    )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        json.dump(packet, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {
                k: packet[k]
                for k in [
                    "status",
                    "current_target_B",
                    "current_known_cover_B",
                    "remaining_to_decimal50GB_B",
                    "accepted_inclusive_seconds_once",
                ]
            }
        )
    )


if __name__ == "__main__":
    main()
