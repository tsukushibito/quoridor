"""Bind the original finite SMP phase at the actual software STOP."""

import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-lazy-smp-v1"
SOFTWARE = OUT.parent / "software-v1"
MIB = 1024**2


def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def checked(path, digest, size):
    result = ref(path)
    assert result["sha256"] == digest and result["bytes"] == size
    assert result["mode"] == "0644"
    return json.loads(Path(path).read_bytes())


def write(name, document):
    with (OUT / name).open("x") as stream:
        json.dump(document, stream, indent=2)
        stream.write("\n")
    return ref(OUT / name)


def point(roots):
    seen = set()
    allocated = logical = entries = 0
    for root in roots:
        pending = [Path(root)]
        while pending:
            path = pending.pop()
            info = path.lstat()
            key = (info.st_dev, info.st_ino)
            if key in seen:
                continue
            seen.add(key)
            allocated += info.st_blocks * 512
            logical += info.st_size
            entries += 1
            if stat.S_ISDIR(info.st_mode):
                pending.extend(path.iterdir())
    return dict(allocated_B=allocated, logical_B=logical, entries=entries)


def main():
    prep = OWN / "normal208-preparation-v1"
    checked(
        prep / "preparation-binding.json",
        "3642ed38952b3264560031441446ac26b407537f65a3d7e00d8dffa7f065dfcf",
        14584,
    )
    checked(
        prep / "preparation-STOP.json",
        "37620284f0fd3ce69ae033abb297b2096d181834c404de8a44a76d2d7ec2438f",
        4125,
    )
    checked(
        OWN / "effect-preparation-v1/protocol.json",
        "83cc4670414107172c3cb1762634e28b67cf9e251a24bec812d211953b7f4163",
        28525,
    )
    software = json.loads((SOFTWARE / "collection-v1/completion-and-STOP.json").read_bytes())
    guard = json.loads((SOFTWARE / "collection-v1/guard-return.json").read_bytes())
    assert software["status"] == "ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP"
    assert guard["actual_return"]["exit_code"] == 0
    assert guard["actual_return"]["direct_child_reaped"]
    assert guard["actual_return"]["handle_closes_complete"]
    assert not guard["TMP"] and not guard["source_leases"]
    lock = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock.open("a+") as stream:
        fcntl.flock(stream, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for caller in software["current_callers"]:
            assert ref(caller["path"]) == caller
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        release = write(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_SOURCE_SOFTWARE_COLLECTION_RELEASED",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=commit,
                current_four_callers=software["current_callers"],
                software_manifest=software["software_manifest"],
                artifact=software["artifact"],
                actual_software_STOP=ref(SOFTWARE / "collection-v1/completion-and-STOP.json"),
                collector_guard=ref(SOFTWARE / "collection-v1/guard-return.json"),
                source_SH_NB_acquired_released=True,
                source_leases_remaining=[],
                numerical_scope="Inherited641ca structural only; actual normal join required at entry",
                qualification="Rust11/Python2/affectedClippy/release PASS once; no new science or oldimage wall qualification",
                evaluation="UNENTERED",
                host_future_quiet=False,
            ),
        )
        fcntl.flock(stream, fcntl.LOCK_UN)
    roots = [str(OWN), str(OUT)]
    actual = point(roots)
    whole = 192 * MIB
    future = 161480704
    margin = whole - actual["allocated_B"] - future
    assert margin >= 8 * MIB, (actual, margin)
    prior = software["current_known_cover_B"]
    assert prior + whole <= 50000000000
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize > whole
    capacity = write(
        "capacity-and-holding.json",
        dict(
            scope="Directed OWN22 plus this entry-control inode union once, for whole-phase admission; not old source recharge or global walk",
            roots=roots,
            actual_ended_point=actual,
            conservative_future_B=future,
            whole_B=whole,
            forecast_margin_B=margin,
            prior_known_cover_B=prior,
            new_known_cover_B=prior + whole,
            remaining_to_decimal50GB_B=50000000000 - prior - whole,
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            original176MiB="Unissued historical proposal retained; actual accumulated source/control growth resolved here",
            image="Existing qualified private image counted in software holding once; reference only, no new copy",
            global_actual_fees_later_tails="UNKNOWN",
            refunds_loans_science_credit=0,
        ),
    )
    supports = []
    for threads, workers in [(1, [12]), (2, [12, 14])]:
        resources = dict(
            search_cpu_cores=workers,
            total_search_threads=threads,
            worker_cpu=12,
            main_guardian=0,
            outer_guardian=18,
            launch_affinity=[0, 12, 14, 18],
            family_B=4 * 1024**3,
            controller_B=1536 * MIB,
            native_B=2560 * MIB,
            host_reserve_B=4 * 1024**3,
            GPU=0,
            threads=1,
            CPU=len(workers) + 1,
            controller_included=True,
            family_RAM_B=4 * 1024**3,
            controller_RAM_B=1536 * MIB,
        )
        supports.append(
            write(
                f"phase-support-N{threads}.json",
                dict(
                    issue="quoridor-4lc.324.22",
                    status="ISSUED_ORIGINAL_NORMAL208_ONE_SERIAL_LIFETIME",
                    fixed_protocol=ref(OWN / "effect-preparation-v1/protocol.json"),
                    normal_preparation=ref(prep / "preparation-binding.json"),
                    current_source_adoption=release,
                    actual_source_STOP=release,
                    actual_software_STOP=ref(SOFTWARE / "collection-v1/completion-and-STOP.json"),
                    whole_B=whole,
                    roots=roots,
                    storage_budget=dict(whole_B=whole, roots=roots),
                    owned_B=whole,
                    free_B=margin,
                    capacity_basis=capacity,
                    resources=resources,
                    limits=dict(
                        worker_cpu=12,
                        guardian_cpu=0,
                        family_B=4 * 1024**3,
                        controller_B=1536 * MIB,
                        host_reserve_B=4 * 1024**3,
                        owned_B=whole,
                        free_B=margin,
                        log_B=MIB,
                    ),
                    total_original_calls=208,
                    total_original_nodes=208000000,
                    per_call_aggregate_nodes=1000000,
                    TOTAL_TT_entries=1048576,
                    serial_runs=8,
                    sessions=48,
                    RUN_timeout_s=900,
                    parent_accepted_s=7800,
                    parent_command_s=7740,
                    cleanup_margin_s=60,
                    readonly_images_models_copy_B=0,
                    native_aggregate_B_each=8 * MIB,
                    perf_RAW_B=0,
                    allocation="N1 and N2 supports are exact CPU-team views of ONE serial 192MiB whole, never additive grants. N1 workers12+main0; N2 workers12,14+main0; outer18. SMT siblings13,15 unused.",
                    normal_remaining_inputs="Actual canonical factory/numerical_fields/current environment/origin/end_at and fresh physical peers/RAM/ownerpausecancel/fullroot/storage/cleanup admission mandatory; RPC is not native entry",
                    timing="No substantial Cargo/ML/history observation/RAW/heavyDB through actual SMP native+normalcollection STOP",
                    conditional64="Dormant and NOT ISSUED. Only original preregistered correctness/practical/usefulness gates may enable later ordinary support",
                    oldimage_N1_wall="UNMEASURED",
                    source_quality="Software qualification only; no speed, strength, default or model promotion",
                    science_refund_lending_reset=0,
                    pauses_seals_models_defaults_foreign_FAILED_UNKNOWN="PRESERVED",
                ),
            )
        )
    write(
        "issued-inputs.json",
        dict(
            release=release,
            phase_supports=supports,
            capacity=capacity,
            source_leases=[],
            evaluation="UNENTERED",
        ),
    )
    print(
        json.dumps(
            dict(
                status="ISSUED",
                whole_B=whole,
                actual_point=actual,
                margin_B=margin,
                release=release,
            )
        )
    )


if __name__ == "__main__":
    main()
