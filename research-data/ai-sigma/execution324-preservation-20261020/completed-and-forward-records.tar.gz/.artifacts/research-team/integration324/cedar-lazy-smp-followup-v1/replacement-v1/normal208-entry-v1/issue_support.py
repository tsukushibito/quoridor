"""Issue the fixed replacement comparison at the actual release/collection STOP."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOFTWARE = OUT.parent / "software-v1"
OWN = ROOT / ".worktree/assets/perf/cedar-lazy-smp-followup-v1"
MIB = 1024**2


def ref(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def checked(reference):
    assert ref(reference["path"]) == reference
    return json.loads(Path(reference["path"]).read_bytes())


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def main():
    loader = importlib.util.spec_from_file_location(
        "existing_phase_metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/normal208-entry-v1/issue_support.py",
    )
    prior = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(prior)
    protocol_path = OWN / "replacement-v1/finite-protocol-v1.json"
    protocol_ref = ref(protocol_path)
    assert (
        protocol_ref["sha256"] == "dcc01585ec4a8cd879415b8744e1b3c01e4a7c99bdf5e6ec875198cffe519d36"
    )
    assert protocol_ref["bytes"] == 17171
    software = json.loads(
        (SOFTWARE / "release-collection-v1/completion-and-STOP.json").read_bytes()
    )
    guard = json.loads((SOFTWARE / "release-collection-v1/guard-return.json").read_bytes())
    assert software["status"] == "ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP"
    assert guard["actual_return"]["exit_code"] == 0 and guard["actual_return"]["cleanup_complete"]
    assert (
        guard["actual_return"]["direct_child_reaped"]
        and guard["actual_return"]["handle_closes_complete"]
    )
    assert not guard["TMP"] and not guard["source_leases"]
    known = []
    for row in software["known_command_fresh_absence"]:
        fresh = identity(process_info(row["original"]["pid"]))
        assert fresh != identity(row["original"])
        known.append(dict(original=row["original"], fresh=fresh))
    control = json.loads((OWN / "current25-control-binding-v1/control-binding.json").read_bytes())
    control_build = checked(control["control_build"])
    candidate_build = checked(software["software_manifest"])
    assert control_build["status"] == candidate_build["status"] == "PASS"
    control_intent = json.loads(
        (
            ROOT
            / ".artifacts/research-team/integration324/cedar-shallow-main-history-v1/software-v1/build-intent-release.json"
        ).read_bytes()
    )
    candidate_intent = json.loads((SOFTWARE / "build-intent-release.json").read_bytes())
    assert control_intent["tools"] == candidate_intent["tools"]
    assert {k: v for k, v in control_intent["env"].items() if k != "TMPDIR"} == {
        k: v for k, v in candidate_intent["env"].items() if k != "TMPDIR"
    }
    assert (
        control_intent["source"]["patch"]["sha256"] == candidate_intent["source"]["patch"]["sha256"]
    )
    lock = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock.open("a+") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for caller in software["current_callers"]:
            assert ref(caller["path"]) == caller
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        assert head == "f2efd18e5c209ed3908b630879a042d66f5b6aac"
        changed = subprocess.check_output(
            ["git", "diff", "--name-only", control["control_source_git"], head], cwd=ROOT, text=True
        ).splitlines()
        assert changed == ["crates/quoridor-ai/src/lazy_smp.rs"]
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_SOURCE_SOFTWARE_COLLECTION_RELEASED_FAIR_O_N_PAIR",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=head,
                current_four_callers=software["current_callers"],
                software_manifest=software["software_manifest"],
                artifact=software["artifact"],
                control_build=control["control_build"],
                control_artifact=control["control_artifact_byref"],
                control_source_git=control["control_source_git"],
                candidate_build=software["software_manifest"],
                candidate_artifact=software["artifact"],
                actual_software_STOP=ref(
                    SOFTWARE / "release-collection-v1/completion-and-STOP.json"
                ),
                collector_guard=ref(SOFTWARE / "release-collection-v1/guard-return.json"),
                common_source_correspondence=dict(
                    changed_subjects=changed,
                    sparse_adoption=ref(OUT.parent / "source-adoption-v1/actual-adoption.json"),
                    tools_and_env_except_owned_TMP_exact=True,
                    foreign_patch_exact=True,
                ),
                source_SH_NB_acquired_released=False,
                source_EX_NB_acquired_released=True,
                source_leases_remaining=[],
                qualification="New replacement boundary running1, affected Clippy warning0 and genuine release normal finalize PASS; fair immutable two-image single-factor comparison, both N2 Current. No measured performance inferred.",
                numerical_scope="Inherited641ca structural only; actual current normal factory/numerical_fields/origin admission required",
                evaluation="UNENTERED",
                host_future_quiet=False,
            ),
        )
        roots = [str(OWN), str(OUT)]
        actual = prior.point(roots)
        whole = 192 * MIB
        future = 159383552
        margin = whole - actual["allocated_B"] - future
        assert margin >= 8 * MIB, (actual, margin)
        cover = software["current_known_cover_B"]
        shortage = max(0, cover + whole + 32 * MIB - 50000000000)
        target = Path(candidate_intent["target"])
        candidates = []
        for path in (target / "debug/deps").iterdir():
            info = path.lstat()
            if (
                path.suffix in {".rlib", ".rmeta"}
                and stat.S_ISREG(info.st_mode)
                and info.st_nlink == 1
            ):
                candidates.append(
                    dict(
                        path=str(path),
                        device=info.st_dev,
                        inode=info.st_ino,
                        mtime_ns=info.st_mtime_ns,
                        bytes=info.st_size,
                        allocated_B=info.st_blocks * 512,
                        mode=info.st_mode,
                        links=info.st_nlink,
                    )
                )
        selected = []
        for row in sorted(candidates, key=lambda x: x["allocated_B"], reverse=True):
            if sum(x["allocated_B"] for x in selected) >= shortage:
                break
            selected.append(row)
        assert sum(x["allocated_B"] for x in selected) >= shortage
        retirement = save(
            "cache-retirement-intent.json",
            dict(
                actual_software_STOP=ref(
                    SOFTWARE / "release-collection-v1/completion-and-STOP.json"
                ),
                known_cover_B=cover,
                concrete_shortage_B=shortage,
                whole_B=whole,
                ordinary_tail_B=32 * MIB,
                selected=selected,
                preserved="Only actual stopped rebuildable debug rlib/rmeta; all qualified images/models/Git/RAW/FAILED/unique evidence retained",
            ),
        )
        removed = []
        try:
            for row in selected:
                path = Path(row["path"])
                info = path.lstat()
                assert (
                    info.st_dev,
                    info.st_ino,
                    info.st_mtime_ns,
                    info.st_size,
                    info.st_blocks * 512,
                    info.st_nlink,
                ) == (
                    row["device"],
                    row["inode"],
                    row["mtime_ns"],
                    row["bytes"],
                    row["allocated_B"],
                    1,
                )
                path.unlink()
                removed.append(row)
        finally:
            retired = sum(x["allocated_B"] for x in removed)
            save(
                "cache-retirement-return.json",
                dict(
                    intent=retirement,
                    actual_removed_B_once=retired,
                    all_selected_removed=len(removed) == len(selected),
                    known_cover_after_B=cover - retired,
                    old_credits_reapplied=0,
                    refund_loan_reset=0,
                    later_tails_globalactual_fullfees="UNKNOWN",
                ),
            )
        cover -= retired
        assert cover + whole <= 50000000000
        fs = os.statvfs(OWN)
        assert fs.f_bavail * fs.f_frsize > whole
        capacity = save(
            "capacity-and-holding.json",
            dict(
                roots=roots,
                scope="ONE directed OWN27 plus Root entry whole; existing ordinary source point included once, no extra old point addition/global walk",
                actual_ended_point=actual,
                conservative_future_B=future,
                whole_B=whole,
                forecast_margin_B=margin,
                prior_known_cover_B=cover,
                new_known_cover_B=cover + whole,
                remaining_to_decimal50GB_B=50000000000 - cover - whole,
                filesystem_available_B=fs.f_bavail * fs.f_frsize,
                images_models_libraries_copy_B=0,
                old_credits_refund_loan_reset=0,
                later_tails_globalactual_fullfees="UNKNOWN",
            ),
        )
        support = save(
            "phase-support-N2.json",
            dict(
                issue="quoridor-4lc.324.27",
                status="ISSUED_NEW27_REPLACEMENT_NORMAL208_ONE_SERIAL_LIFETIME",
                fixed_protocol=protocol_ref,
                current_source_adoption=release,
                actual_source_STOP=release,
                actual_software_STOP=ref(
                    SOFTWARE / "release-collection-v1/completion-and-STOP.json"
                ),
                whole_B=whole,
                roots=roots,
                storage_budget=dict(whole_B=whole, roots=roots),
                owned_B=whole,
                free_B=margin,
                capacity_basis=capacity,
                resources=dict(
                    search_cpu_cores=[12, 14],
                    total_search_threads=2,
                    worker_cpu=12,
                    main_guardian=0,
                    outer_guardian=18,
                    launch_affinity=[0, 12, 14, 18],
                    family_B=4 * 1024**3,
                    controller_B=1536 * MIB,
                    native_B=2560 * MIB,
                    host_reserve_B=4 * 1024**3,
                    GPU=0,
                    threads=1,
                    CPU=3,
                    controller_included=True,
                    family_RAM_B=4 * 1024**3,
                    controller_RAM_B=1536 * MIB,
                ),
                limits=dict(
                    worker_cpu=12,
                    guardian_cpu=0,
                    family_B=4 * 1024**3,
                    controller_B=1536 * MIB,
                    host_reserve_B=4 * 1024**3,
                    owned_B=whole,
                    free_B=margin,
                    log_B=MIB,
                ),
                total_original_calls=208,
                total_original_nodes=208000000,
                per_call_aggregate_nodes=1000000,
                TOTAL_TT_entries=1048576,
                serial_runs=8,
                sessions=48,
                RUN_timeout_s=900,
                parent_accepted_s=7800,
                parent_command_s=7740,
                cleanup_margin_s=60,
                readonly_images_models_copy_B=0,
                native_aggregate_B_each=8 * MIB,
                perf_RAW_B=0,
                allocation="Both O/N are 2thread CPUteam12,14+main0/outer18, serial8 RUNs under ONE192MiB whole, no duplicated grant. child_cpu_cores must include0,12,14 per maintained native_cpu_cores.",
                normal_remaining_inputs="Current factory/numerical_fields/actual environments, fresh physical SMT peers/RAM/host4/fullroots/storage/ownerpausecancel/origin/end_at/serializer/cleanup required; no RPC=native START claim",
                timing="Main/currentcallers/image/libs/env/Cargo/substantial IO frozen through actual native+normalcollection STOP only; independent light25.3/26 allowed",
                conditional64="NEW27 only, remains UNISSUED until frozen gates and its actual separate support; no old22/24 rights transfer",
                science_refund_lending_reset=0,
                pauses_seals_models_defaults_foreign_FAILED_UNKNOWN="PRESERVED",
            ),
        )
        save(
            "issued-inputs.json",
            dict(
                release=release,
                phase_supports=[support],
                capacity=capacity,
                known_fresh_absence=known,
                source_leases=[],
                evaluation="UNENTERED",
            ),
        )
    print(
        json.dumps(
            dict(
                status="ISSUED",
                whole_B=whole,
                margin_B=margin,
                retired_cache_B=retired,
                current_cover_B=cover + whole,
                release=release,
                support=support,
            )
        )
    )


if __name__ == "__main__":
    main()
