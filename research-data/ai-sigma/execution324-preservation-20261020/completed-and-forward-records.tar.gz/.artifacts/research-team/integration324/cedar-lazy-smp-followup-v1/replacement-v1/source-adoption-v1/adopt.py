"""Adopt only the accepted replacement owner after actual25 reader return."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import stat
import subprocess

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-lazy-smp-followup-v1"
SUBJECT = "crates/quoridor-ai/src/lazy_smp.rs"


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def pinned(path, sha, size):
    witness = ref(path)
    assert witness["sha256"] == sha and witness["bytes"] == size and witness["mode"] == "0644"
    return witness, json.loads(path.read_bytes())


def command(*argv):
    return subprocess.check_output(list(argv), cwd=ROOT, stderr=subprocess.STDOUT)


def main():
    stop, returned = pinned(
        ROOT
        / ".worktree/assets/perf/cedar-shallow-main-history-v1/normal104-collection-v1/returned-collection-analysis-admin-STOP.json",
        "9cf33fe729d415f6ce8056000897f75d14fe25b9da85b50a473a1f4cdabbb3dc",
        10413,
    )
    native_ref = returned["native_normal_source_STOP"]
    assert ref(Path(native_ref["path"])) == native_ref
    native = json.loads(Path(native_ref["path"]).read_bytes())
    assert (
        not native["source_leases_remaining"] and not native["remaining_owned_scientific_processes"]
    )
    assert not returned["TMP_remaining"] and not returned["source_leases_remaining"]
    fresh = []
    for row in native["actual_known_identities"] + returned["actual_known_helper_identities"]:
        original = row["identity"]
        current = identity(process_info(original["pid"]))
        assert current != identity(original)
        fresh.append(dict(original=original, fresh=current))
    binding, _ = pinned(
        OWN / "replacement-v1/fixed-source-binding.json",
        "e10f977d1b39eec508c68bf2bdd1a632562209d178236fc0dd357466cded5905",
        4979,
    )
    acceptance, decision = pinned(
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-followup-v1/replacement-review-v1/accepted-source-only.json",
        "e350f8d91d3ec11fb9ea58cd172f6fd5961c269e2f58e190c35105526310a92b",
        2485,
    )
    assert decision["status"] == "ACCEPTED_SOURCE_ONLY" and decision["fixed_binding"] == binding
    locator_ref, locator = pinned(
        OWN / "current25-control-binding-v1/sparse-owner-composition-locator.json",
        "3983fa47429e7dc82bca2b17bbbfae0e1b7f263b5ee6d7712d4b9265af9202b9",
        1877,
    )
    patch = Path(locator["forward"]["path"])
    assert ref(patch) == locator["forward"]
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        head = command("git", "rev-parse", "HEAD").decode().strip()
        assert head == locator["current_control_source_git"]
        assert command("git", "diff", "--cached", "--name-only") == b""
        before = ref(ROOT / SUBJECT)
        assert before["sha256"] == locator["current_immutable_owner_sha256"]
        assert before["bytes"] == locator["current_immutable_owner_bytes"]
        foreign_paths = command("git", "diff", "--name-only", "HEAD").decode().splitlines()
        assert SUBJECT not in foreign_paths
        foreign = [ref(ROOT / name) for name in foreign_paths]
        changes = command("git", "apply", "--numstat", str(patch)).decode().splitlines()
        assert len(changes) == 1 and changes[0].split("\t")[-1] == SUBJECT
        command("git", "apply", "--check", "--whitespace=nowarn", str(patch))
        applied = command("git", "apply", "--verbose", "--whitespace=nowarn", str(patch)).decode()
        assert "offset" not in applied.lower()
        after = ref(ROOT / SUBJECT)
        expected = locator["fixed_post"]
        assert all(after[key] == expected[key] for key in ["sha256", "bytes", "mode"])
        command(
            "/usr/local/cargo/bin/rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            "--check",
            str(ROOT / SUBJECT),
        )
        command("git", "diff", "--check", "--", SUBJECT)
        assert [ref(Path(row["path"])) for row in foreign] == foreign
        command("git", "add", "--", SUBJECT)
        assert command("git", "diff", "--cached", "--name-only").decode().splitlines() == [SUBJECT]
        committed = command(
            "git", "commit", "-m", "Preserve deep shared TT entries across writers"
        ).decode()
        adopted_commit = command("git", "rev-parse", "HEAD").decode().strip()
        assert command(
            "git", "diff", "--name-only", head, adopted_commit
        ).decode().splitlines() == [SUBJECT]
        assert [ref(Path(row["path"])) for row in foreign] == foreign
    document = dict(
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        issue="quoridor-4lc.324.27",
        status="SPARSE_MAIN_SOURCE_ADOPTED_NEW_SOFTWARE_PENDING",
        before_commit=head,
        commit=adopted_commit,
        subjects=[dict(subject=SUBJECT, before=before, post=after)],
        fixed_binding=binding,
        source_only_acceptance=acceptance,
        sparse_locator=locator_ref,
        actual25_native_collection_STOP=stop,
        known_original_processes_fresh=fresh,
        foreign_paths_preserved=foreign,
        actual_patch_output=applied,
        commit_output=committed,
        formatter="Scoped rustfmt check PASS; post exactly equals formatted fixed target",
        changed_algorithm="Only SharedTable writer-neutral same-generation deeper retention; remaining additions are one new unrun boundary definition",
        control_BUILD=locator["current_control_source_git"],
        software_native_model_RAW_RNG_replay=0,
        software="UNBUILT_UNTYPED_UNRUN",
        source_leases=[],
        remaining_owned=[],
        host_future_quiet=False,
        preserved="default1/current history; all oldscience/FAILED/NULL/UNKNOWN fees/pauses/seals/models/foreign/decimal50GB",
    )
    with (OUT / "actual-adoption.json").open("x") as stream:
        json.dump(document, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(status=document["status"], commit=adopted_commit, changed=SUBJECT)))


if __name__ == "__main__":
    main()
