"""Accept the supplied bounded source verdict without replaying its review."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat


OUT = Path(__file__).resolve().parent
REVIEW = Path(
    "/workspaces/quoridor/.worktree/assets/perf/cedar-lazy-smp-followup-review-v1/replacement-v1"
)


def pinned(path, digest, size):
    body = path.read_bytes()
    assert len(body) == size and hashlib.sha256(body).hexdigest() == digest
    assert stat.S_IMODE(path.stat().st_mode) == 0o644
    return {"path": str(path), "sha256": digest, "bytes": size, "mode": "0644"}, json.loads(body)


binding, _ = pinned(
    Path(
        "/workspaces/quoridor/.worktree/assets/perf/cedar-lazy-smp-followup-v1/replacement-v1/fixed-source-binding.json"
    ),
    "e10f977d1b39eec508c68bf2bdd1a632562209d178236fc0dd357466cded5905",
    4979,
)
minimum, verdict = pinned(
    REVIEW / "minimum-source-verdict.json",
    "c18b31f88eadbbad2591d559d7f1a84f19b62154ca9e18cee08b729b3100f90d",
    2196,
)
reader, _ = pinned(
    REVIEW / "reader-STOP.json",
    "430ebc4beb9a6dc770592c36104e70476d8879d5fa84de68550df3e81f436cb4",
    11724,
)
returned, _ = pinned(
    REVIEW / "minimum-returned-STOP.json",
    "6c62d707059fc7d73f0c165b1ff73fc538766a5e5f07736280c907435de2fb54",
    10043,
)
assert verdict["status"] == "SOURCE_CLEAR"
assert verdict["essential_count"] == verdict["ordinary_count"] == 0
assert verdict["fixed_binding"] == binding
reason = (
    "Accepted fixed writer-neutral same-generation deeper-entry retention source-only review: "
    "essential0 ordinary0, existing LOCAL replacement rule and coherent full-entry numeric "
    "qualification preserved; different-generation replacement remains finite. "
    "Sparse integration, new software, fair images and performance remain separately unqualified."
)
accepted = {
    "at": datetime.now(timezone.utc).isoformat(),
    "issue": "quoridor-4lc.324.27.1",
    "status": "ACCEPTED_SOURCE_ONLY",
    "fixed_binding": binding,
    "minimum": minimum,
    "actual_reader_STOP": reader,
    "actual_returned_helpers_STOP": returned,
    "exact_reason": reason,
    "sameowner_normal_close_authorized": True,
    "limits": verdict["important_limits"],
    "entry": "No new scientific entry, quota, software or measured effect granted.",
    "integration": "Root Main/Cargo frozen through actual25 software collection STOP; sparse owner adoption later.",
    "preserved": "default1, all pauses/seals/models/foreign/FAILED/NULL/UNKNOWN fees/decimal50GB",
}
destination = OUT / "accepted-source-only.json"
with destination.open("x") as stream:
    json.dump(accepted, stream, indent=2)
    stream.write("\n")
body = destination.read_bytes()
reference = {
    "path": str(destination),
    "sha256": hashlib.sha256(body).hexdigest(),
    "bytes": len(body),
    "mode": "0644",
}
with (OUT / "same-Max-normal-closure.txt").open("x") as stream:
    stream.write(
        "SAME existing Sol6.1/max/Main01a118a1, cwd /workspaces/quoridor, explicit "
        "danger-full-access / approvalPolicy never. Preserve model/effort/cwd and verify actual "
        "turn_context before the next ordinary command. Root accepts fixed27.1 source-only "
        "verdict below. Finish current helpers naturally, then own meaningful note, backup-before, "
        "normal close once, show CLOSED/same original assignee/exact_reason, backup-after. "
        "No force/foreign mutations/review replay. Already accepted24.2 and25.1/26.1 ordinary "
        "closures may finish at the same compatible boundary if not already closed. "
        "Source/report/admin/close is not a software or numerical entry gate. Root25 software "
        "remains frozen, no Main/Cargo/source writes or payload/test/native/RNG replay. "
        "Root will relay actual24.2 closure to High24. All constraints preserved.\n"
    )
    stream.write(json.dumps(reference, indent=2) + "\n")
print(json.dumps(reference))
