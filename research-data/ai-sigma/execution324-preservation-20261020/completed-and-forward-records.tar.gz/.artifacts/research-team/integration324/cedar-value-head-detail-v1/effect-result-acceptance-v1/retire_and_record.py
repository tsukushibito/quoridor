"""Retire the unsupported comparison using its exact saved inverse target."""

import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import time

from quoridor_training import cycle_process as process

ROOT = Path("/workspaces/quoridor")
BASE = Path(__file__).resolve().parent


def ref(path):
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    out = BASE / "retirement-v1"
    out.mkdir(exist_ok=False)
    target = json.loads((BASE / "retirement-binding.json").read_bytes())
    path = ROOT / "crates/quoridor-nnue/src/residual.rs"
    deadline = time.monotonic() + 180
    resources = process.CycleResources(
        dict(max_memory_bytes=1024**3, host_ram_reserve=4 * 1024**3, max_output_bytes=1024**2),
        out,
        deadline,
    )
    returns = []

    def run(argv):
        result = process.execute(
            argv,
            out / f"command-{len(returns)}.log",
            deadline,
            cpu_core=16,
            resources=resources,
            cwd=ROOT,
            no_new_privs=True,
        )
        returns.append(result)
        return result

    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert ref(path)["sha256"] == target["before"]["sha256"]
        before = Path(target["before"]["path"]).read_bytes()
        after = Path(target["after"]["path"]).read_bytes()
        assert (
            path.read_bytes() == before
            and hashlib.sha256(after).hexdigest() == target["after"]["sha256"]
        )
        assert (
            target["patch"]["sha256"]
            == "4fa14943a12e3e9e4d766d5e947c69ec68c0a62d68a3f968cb71d7ca8c9738c8"
        )
        path.write_bytes(after)
        assert path.read_bytes() == subprocess.check_output(
            ["git", "show", "18a1015^:crates/quoridor-nnue/src/residual.rs"], cwd=ROOT
        )
        findings = ROOT / "docs/research-findings.md"
        agenda = ROOT / "docs/design/ai-nnue-optimization-agenda.md"
        ordering = ROOT / "docs/design/lightweight-move-ordering-v1.md"
        research = ROOT / "docs/design/ai-nnue-research.md"
        with findings.open("a") as stream:
            stream.write("""
### 行参照準備一候補の連続Search比較は保持条件未達（324.20、2026-10-19）

元104 ABBAは4 normal manifest/data PASS、24 sessions/100,000,772nodesで完了した。全26 quadruplesの非時計work・合法root・action/PV/value bits・完全history・parent復元/session事実は一致し、100 NodeLimit UNKNOWNと4 DepthCompleteを保存した。初期化済みTT/history/head/scratchを各系列で再用したSearch合計はA0=26.229012472、B1=26.171770284、B2=25.761431348、A3=25.836631210秒。B/A=0.997456248677（記述的には0.2544%短い）だが、結果前の2%以上改善と厳密な反復分離はともにFALSE、stock guardはTRUEで、元AND条件を満たさず **NOT_SUPPORTED_IN_FIXED_FINITE_COMPARISON_NO_REFILL** とした。速度同等・無効果・一般速度/棋力の結論へ広げない。[元結果・条件・実STOP](../.worktree/assets/perf/cedar-value-head-detail-v1/effect-numeric-v1/analysis-v1/completion.json)。

診断78+比較104の元182calls/175,001,351nodesは終了し、追加Search/候補sweep/再演は行わない。効果工程outer127.683609638秒は一度/nested非加算。比較専用rowviewsと専用cfg fixtureだけを保存inverse/Git18a1015親から撤去し、元indexed loopと既存correctness testsをexact6075760dへ戻した。既存データ・O/N真正image・Git復元元、joint学習接続・Main caller・モデル/既定を保持する。撤去後sourceは新たに性能計測していない。[固定撤去対応](../.artifacts/research-team/integration324/cedar-value-head-detail-v1/effect-result-acceptance-v1/retirement-binding.json)。

### 現行orderingの順位品質を保存証拠から確認する（324.21、2026-10-19人間直接指示）

元52のtie適用機会・実順位変更だけでは、より良い手を先へ置いたかは分からない。同じHigh17/20の新taskで、保存52/旧384 summary/固定26prefix・6series・stock層を先に照合する。TT・保護手・signed history層、同点群内shadow順位と探索全順位を分け、後の完成探索が選んだ手の上位1/3/5・移動量・駒/壁・残壁層と条件/分母/UNKNOWNを示す。深い選択探索はoracleではなく、異木・warmTT/history・打切り偏り・未探索枝を因果/見落とし率へ変換しない。必要fieldが無ければ欠落を先に明示し、既存入口による最大26calls/26M・追加対局0の最小観測だけを結果前固定する。実新観測はまだ未配分/未入場。[範囲・実資源・完成条件](../.artifacts/research-team/integration324/cedar-ordering-quality-v1/task.md)。

将来の追加LMR広域比較は、順位品質診断→根拠があれば一ordering候補の有限採否→ordering/評価器固定→必要なLMR再調整の具体化、の順とする。確定した元1920/final512/RETAIN_BASELINEは再開しない。具体候補なしならControlと既存LMR結果を利用し、policy学習待ちで全作業を止めない。18.2のjoint学習接続とこのsaved診断は独立に継続し、全親close/人間返信を入口にしない。
""")
        with agenda.open("a") as stream:
            stream.write("""
324.20の元104連続Search比較はB/A=0.997456248677で、固定2%条件・反復分離を満たさず候補を保持しない。比較専用行参照差分と新fixtureは元Git/inverseへ戻し、旧13融合や別候補へ置換しない。これは有限条件未達であり同等/無効果の証明ではない。[元結果と撤去](../research-findings.md#行参照準備一候補の連続search比較は保持条件未達324202026-10-19)。
""")
        with ordering.open("a") as stream:
            stream.write("""
## 現行順位の質を確認する有限診断（324.21、2026-10-19人間直接指示）

元52で確認した適用機会/実順位変更から、より深い完成探索が選ぶ手をどこへ置くかの診断へ進む。保存証拠を優先し、TT/保護/符号付きhistory層と安い採点が実際に決める同点群内順位・探索全順位を分離する。同一合法局面/完全history/手番/評価器/窓/条件を対応させ、先頭/上位3・5、移動量、stock、駒/壁、分母/UNKNOWNを報告する。深い選択探索をoracleと呼ばず、warm状態・打切り・未探索枝を因果的な順位品質へ読み替えない。不足fieldを先に特定し、必要な場合だけ共通bounded入口で最大26calls/26Mの小観測を結果前固定する。元52/旧384/終了LMRの再演・上書き、追加対局、候補sweepは行わない。

この診断→根拠があれば一候補の有限比較/採否→ordering/評価器固定→必要な追加LMR調整、の順とする。具体候補なしならControlと既存LMR基準維持結果を使い、policyだけが残ると断定せず、学習完了を全体gateにしない。[契約と実資源](../../.artifacts/research-team/integration324/cedar-ordering-quality-v1/task.md)、[観測と限界の正本](../research-findings.md#現行orderingの順位品質を保存証拠から確認する324212026-10-19人間直接指示)。
""")
        with research.open("a") as stream:
            stream.write("""
2026-10-19の人間直接指示により、今後の追加LMR広域比較は、現行orderingの小規模順位品質診断と具体候補があればその有限採否を先に決めてから具体化する。終了した元1920/final512/249勝263敗/RETAIN_BASELINEは確定保存し再開しない。policy導入後も変更がLMRへ及ぼす影響を見て必要範囲だけ調整し、毎回全campaignを再演しない。18.2の接続環境は並行継続する。[順位品質診断の条件](lightweight-move-ordering-v1.md#現行順位の質を確認する有限診断324212026-10-19人間直接指示)。
""")
        run(
            [
                "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt",
                "--edition",
                "2024",
                "--check",
                str(path),
            ]
        )
        prettier = [
            str(ROOT / "tools/research-quality/node_modules/.bin/prettier"),
            "--config",
            "tools/research-quality/.prettierrc.json",
        ]
        run(prettier + ["--write", str(findings), str(agenda), str(ordering), str(research)])
        run(prettier + ["--check", str(findings), str(agenda), str(ordering), str(research)])
        paths = [str(p) for p in [path, findings, agenda, ordering, research]]
        run(["git", "diff", "--check", "--"] + paths)
        run(["git", "add", "--"] + paths)
        run(
            [
                "git",
                "commit",
                "-m",
                "research: retire unsupported row views and prepare ordering quality diagnosis",
            ]
        )
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        fcntl.flock(lock, fcntl.LOCK_UN)
    result = dict(
        status="COMPARISON_ONLY_SOURCE_RETIRED",
        commit=commit,
        after=ref(path),
        restores_original_607=True,
        saved_inverse=target["patch"],
        protected_other_owners="Unchanged; exact original file restore only. Joint bridge/Python/LC/env/models untouched.",
        returns=returns,
        source_Cargo_EX_lease_acquired_released=True,
        tests_build_model_RAW_RNG_replayed=0,
        cleaned_source_performance="UNMEASURED",
        new_ordering_issue="quoridor-4lc.324.21",
        new_ordering_numerical_entry="UNENTERED",
        original_effect="Finite criterion notmet; limited importantinterpretation relatedreview underway; no strongerclaim.",
    )
    (out / "source-retirement-and-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(dict(status=result["status"], commit=commit, after=result["after"])))


if __name__ == "__main__":
    main()
