"""Issue only the new row-view test, affected lint and a genuine candidate release."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OLD = ROOT / ".artifacts/research-team/integration324/nnue-mcts-foundation-v1/software-v6"


def ref(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    subprocess.run(
        [
            "tools/research-quality/node_modules/.bin/prettier",
            "--config",
            "tools/research-quality/.prettierrc.json",
            "--ignore-path",
            "/dev/null",
            "--write",
            str(path),
        ],
        cwd=ROOT,
        check=True,
        stdout=subprocess.DEVNULL,
    )
    return ref(path)


def main():
    spec = json.loads((OLD / "build-intent.json").read_bytes())
    for key in ("admission", "intent_sha256"):
        spec.pop(key)
    spec.update(
        output=str(OUT / "operation-v1"),
        private=str(OUT / "private-image/quoridor-runner"),
        TMP=str(OUT / "build-TMP-v1"),
    )
    spec["env"]["TMPDIR"] = spec["TMP"]
    spec["source"]["commit"] = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip()
    patch = OUT / "foreign-source.patch"
    with patch.open("xb") as stream:
        stream.write(
            subprocess.check_output(
                ["git", "diff", "--binary", "--no-ext-diff", "--no-textconv", "HEAD", "--"],
                cwd=ROOT,
            )
        )
    spec["source"]["patch"] = ref(patch)
    adoption = save(
        "build-source-adoption.json",
        dict(
            schema="quoridor.research.source-adoption.v1",
            status="ACCEPTED",
            issue="quoridor-4lc.324.20.1",
            source=spec["source"],
            candidate_source=ref(OUT / "candidate-source-adoption.json"),
            source_review=ref(
                ROOT / ".worktree/assets/perf/cedar-value-head-detail-review-v1/completion.json"
            ),
            latest_scientific_STOP=ref(
                ROOT
                / ".worktree/assets/perf/cedar-lmr-five-parameter-tuning-v1/revised-short-v1/completion-v1/STOP.json"
            ),
            scope="Only new synthetic row-view1 test, affectedNNUE/AI/runner Clippy and candidate release; no prior success suites/model/native Search/RAW/RNG.",
        ),
    )
    spec["source_adoption"] = adoption
    support = dict(
        schema="quoridor.research.phase-support.v1",
        issue="quoridor-4lc.324.20.1",
        authority=adoption,
        resources=dict(
            worker_cpu=16,
            guardian_cpu=18,
            native_threads=1,
            GPU=0,
            family_RAM_B=4294967296,
            controller_included=True,
            controller_B=67108864,
            host_reserve_B=4294967296,
        ),
        storage_budget=None,
        scope="Ordinary affected incremental software, no advance microstorage budget; actual new target/image/controls holding once afterward and preserve decimal50GB. Existing canonical serialCargo pool only.",
    )
    spec["support"] = save("resources.json", support)
    marker = Path(spec["target"]) / ".research-owner.json"
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        prior_marker = json.loads(marker.read_bytes())
        assert prior_marker["writer"] == spec["writer"] and prior_marker["target"] == spec["target"]
        save("prior-target-marker.json", prior_marker)
        marker.write_text(
            json.dumps(
                dict(
                    writer=spec["writer"],
                    target=spec["target"],
                    support_sha256=spec["support"]["sha256"],
                ),
                indent=2,
            )
            + "\n"
        )
    handover = json.loads((OLD / "target-handover.json").read_bytes())
    handover.update(
        fresh_private_root=str(OUT / "private-image"),
        actual_last_guard_STOP=ref(OLD / "collection-v1/completion-and-STOP.json"),
        latest_science_STOP=ref(
            ROOT
            / ".worktree/assets/perf/cedar-lmr-five-parameter-tuning-v1/revised-short-v1/completion-v1/STOP.json"
        ),
        scope="SameRoot single serial Cargo target; prior software and originalshort native/collection STOP. No other writer/source reader. No source/model/cachecopy or science replay.",
    )
    spec["target_handover"] = save("target-handover.json", handover)
    cargo = spec["tools"]["CARGO"]["file"]["path"]
    test = dict(
        name="new-row-views-one",
        role="test",
        argv=[
            cargo,
            "test",
            "--offline",
            "--locked",
            "--manifest-path",
            str(ROOT / "Cargo.toml"),
            "-j1",
            "--message-format=json-render-diagnostics",
            "-p",
            "quoridor-nnue",
            "--features",
            "research",
            "--lib",
            "residual::row_views_candidate_tests::row_views_preserve_indexed_bits_capture_and_refusals",
            "--",
            "--exact",
            "--nocapture",
            "--test-threads=1",
        ],
    )
    spec["commands"] = [test, *spec["commands"]]
    spec["intent_sha256"] = hashlib.sha256(
        json.dumps(spec, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    spec["admission"] = save(
        "build-admission.json",
        dict(
            schema="quoridor.research.phase-admission.v1",
            owner=spec["owner"],
            limits=spec["limits"],
            spec_sha256=spec["intent_sha256"],
            support_sha256=spec["support"]["sha256"],
            ready=True,
            scope="Actual ordinary software at returnedshort STOP; no scientific entry.",
        ),
    )
    intent = save("build-intent.json", spec)
    job = json.loads((OLD / "job.json").read_bytes())
    job.update(
        issue="quoridor-4lc.324.20.1",
        goal_issue="quoridor-4lc.324.20.1",
        resource_contract=spec["support"]["path"],
        argv=[
            job["argv"][0],
            "-B",
            str(ROOT / "scripts/dev/research-lifecycle.py"),
            "build",
            "--intent",
            intent["path"],
            "--sha256",
            intent["sha256"],
        ],
    )
    save("job.json", job)
    save(
        "entry.json",
        dict(
            at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            intent=intent,
            source_adoption=adoption,
            limits=spec["limits"],
            commands=[row["name"] for row in spec["commands"]],
            new_definitions=1,
            no_old_success_replay=True,
            native_Search_model_RAW_RNG=0,
            actual_source_Cargo_heavyIO_hold="Through actual originalBuild+normalcollectionSTOP only; High9 final512 light preparation continues. No notification/admin/ACK gate.",
        ),
    )
    print(json.dumps(dict(intent=intent, job=ref(OUT / "job.json"))))


if __name__ == "__main__":
    main()
