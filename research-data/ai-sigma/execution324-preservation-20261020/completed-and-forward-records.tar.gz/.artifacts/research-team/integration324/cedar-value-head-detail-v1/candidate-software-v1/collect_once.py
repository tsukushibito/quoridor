"""Once-only normal finalization of original completed remaining software."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path("/workspaces/quoridor")
BASE = (
    ROOT
    / ".artifacts/research-team/integration324/cedar-value-head-detail-v1/candidate-software-v1"
)
OUT = BASE / "collection-v1"
module = importlib.util.spec_from_file_location(
    "row_views_software_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(module)
module.loader.exec_module(lc)
process = lc.process


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def allocated(root):
    seen = set()
    total = 0
    entries = []
    for directory, dirs, files in os.walk(root, followlinks=False):
        for path in [Path(directory), *[Path(directory) / name for name in files]]:
            info = path.lstat()
            key = info.st_dev, info.st_ino
            if key not in seen:
                seen.add(key)
                total += info.st_blocks * 512
                if path.is_file():
                    entries.append(
                        dict(
                            path=str(path),
                            bytes=info.st_size,
                            allocated_B=info.st_blocks * 512,
                            links=info.st_nlink,
                        )
                    )
    return dict(path=str(root), allocated_B=total, bounded_target_file_metadata=entries)


def main():
    OUT.mkdir(exist_ok=False)
    outer = BASE / "build-runtime-v2/result.json"
    job = lc.document(ref(outer))
    assert job["job_id"] == "e3aa1f90-cfbc-4f31-a046-ed42b6f6e7c8"
    assert (
        job["outcome"] == "succeeded"
        and job["exit_code"] == 0
        and job["cleanup_complete"]
        and not job["remaining"]
    )
    operation = BASE / "operation-v1"
    candidate = lc.document(ref(operation / "candidate.json"))
    assert candidate["status"] == "PENDING_FINALIZATION"
    assert not (operation / "manifest.json").exists() and not (operation / "finalizing").exists()
    known = []
    for check in candidate["checks"]:
        returned = check["guardian_return"]
        assert check["status"] == "PASS" and check["capture_complete"]
        assert (
            returned["direct_child_reaped"]
            and returned["cleanup_complete"]
            and returned["handle_closes_complete"]
            and not returned["remaining"]
        )
        child = returned["child"]
        fresh = process.identity(process.process_info(child["pid"]))
        assert fresh != child
        known.append(dict(check=check["name"], original=child, fresh=fresh))
    for name in ("child",):
        child = candidate["originating_job"][name]
        fresh = process.identity(process.process_info(child["pid"]))
        assert fresh != child
        known.append(dict(check="original-lifecycle-child", original=child, fresh=fresh))
    selected_log = (operation / "new-row-views-one.full.log").read_text()
    assert "running 1 test" in selected_log
    assert "test result: ok. 1 passed; 0 failed" in selected_log
    assert "row_views_preserve_indexed_bits_capture_and_refusals" in selected_log
    assert [row["role"] for row in candidate["checks"] if row["role"] != "version"] == [
        "test",
        "lint",
        "build",
    ]
    deadline = time.monotonic() + 120
    resources = process.CycleResources(
        dict(
            max_memory_bytes=4 * 1024**3, host_ram_reserve=4 * 1024**3, max_output_bytes=4 * 1024**2
        ),
        OUT,
        deadline,
    )
    argv = [
        sys.executable,
        "-B",
        str(ROOT / "scripts/dev/research-lifecycle.py"),
        "finalize",
        "--operation",
        str(operation),
        "--job-result",
        str(outer),
        "--sha256",
        ref(outer)["sha256"],
    ]
    returned = process.execute(
        argv,
        OUT / "finalize-once.log",
        deadline,
        cpu_cores=[16, 18],
        resources=resources,
        cwd=ROOT,
        env=os.environ,
        no_new_privs=True,
    )
    save("finalize-once.returned.json", returned)
    assert returned["exit_code"] == 0 and returned["cleanup_complete"] and not returned["remaining"]
    manifest_ref = ref(operation / "manifest.json")
    manifest = lc.accepted_build(manifest_ref)
    assert manifest["status"] == "PASS" and not (operation / "INCOMPLETE").exists()
    with lc.LEASE.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        spec = lc.document(ref(BASE / "build-intent.json"))
        lc.source_check(spec["source"])
        assert not Path(spec["TMP"]).exists()
        target = Path(spec["target"])
        marker = lc.document(ref(target / ".research-owner.json"))
        assert marker["writer"] == spec["writer"] and marker["target"] == str(target)
        point = save(
            "affected-target-and-new-image-once.json",
            dict(
                target_profiles=[allocated(target / profile) for profile in ("debug", "release")],
                new_private_image=allocated(Path(spec["private"]).parent),
                no_old_cache_credit_or_deletion=True,
                scope="Directed current profiles/new image after actual commands; no globalwalk, oldholding recharge/refund or continuous peak.",
            ),
        )
    supervisor = candidate["originating_job"]["supervisor"]
    completion = dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        original_job=job["job_id"],
        outer=ref(outer),
        outer_wall_once=job["wall_seconds"],
        nested_walls_added=0,
        normal_manifest=manifest_ref,
        normal_status="PASS",
        artifact=manifest["artifact"],
        actual_normal_FINALIZE_once=True,
        known_original_commands=known,
        notification_supervisor=dict(
            original=supervisor,
            fresh=process.identity(process.process_info(supervisor["pid"])),
            source_domain_distinct=True,
        ),
        exact_current_four_callers=[
            ref(ROOT / relative)
            for relative in (
                "scripts/dev/research-lifecycle.py",
                "scripts/dev/research-job.py",
                "python/quoridor_training/cycle_process.py",
                "python/quoridor_training/snapshot.py",
            )
        ],
        current_source=spec["source"],
        canonical_exclusive_NB_acquired_and_released=True,
        source_reader_and_Cargo_commands_stopped=True,
        TMP_remaining=[],
        source_leases_owned=[],
        remaining=[],
        affected_point=point,
        tests_reexecuted=0,
        actual_new_row_views_definition_count=1,
        new_definition_saved_count_PASS=True,
        old_success_tests_replayed=0,
        model_head_Search_games_RAW_RNG=0,
        remaining_original_effect104_UNENTERED=True,
        numerical_pass_or_game_strength_qualification=False,
        already_handled_original_identity_prevents_later_notification_replay=True,
        host_future_quiet=False,
    )
    save("completion-and-STOP.json", completion)
    print(
        json.dumps(
            dict(
                job=job["job_id"],
                status="PASS",
                Build=manifest_ref,
                artifact=manifest["artifact"],
                outer_once=job["wall_seconds"],
            )
        )
    )


if __name__ == "__main__":
    main()
