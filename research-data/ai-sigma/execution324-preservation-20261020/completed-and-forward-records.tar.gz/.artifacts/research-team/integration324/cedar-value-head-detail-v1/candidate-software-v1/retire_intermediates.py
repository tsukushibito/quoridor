"""Retire only identified Cargo intermediates after actual collected software STOP."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
POINT = OUT / "collection-v1/affected-target-and-new-image-once.json"
TARGET = (
    ROOT
    / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/target"
)


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def main():
    stopped = OUT / "collection-v1/completion-and-STOP.json"
    stop = json.loads(stopped.read_bytes())
    assert stop["normal_status"] == "PASS" and stop["source_reader_and_Cargo_commands_stopped"]
    assert stop["remaining"] == stop["TMP_remaining"] == stop["source_leases_owned"] == []
    point = json.loads(POINT.read_bytes())
    files = [
        entry
        for profile in point["target_profiles"]
        for entry in profile["bounded_target_file_metadata"]
    ]
    selected = [
        entry
        for entry in files
        if Path(entry["path"]).suffix in (".rlib", ".rmeta", ".d")
        or ".fingerprint" in Path(entry["path"]).parts
    ]
    protected = [entry for entry in files if entry not in selected]
    assert selected and all(Path(entry["path"]).is_relative_to(TARGET) for entry in selected)
    assert all(entry["links"] == 1 for entry in selected)
    seen = set()
    snapshots = []
    errors = []
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for entry in selected:
            path = Path(entry["path"])
            info = path.lstat()
            identity = info.st_dev, info.st_ino
            assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and identity not in seen
            assert info.st_size == entry["bytes"] and info.st_blocks * 512 == entry["allocated_B"]
            seen.add(identity)
            snapshots.append(
                dict(**entry, device=info.st_dev, inode=info.st_ino, mtime_ns=info.st_mtime_ns)
            )
        intent = save(
            "cache-retirement-intent.json",
            dict(
                at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                actual_software_STOP=ref(stopped),
                source_and_command_restore=stop["normal_manifest"],
                current_source=stop["current_source"],
                target=str(TARGET),
                selected=snapshots,
                reconstruction="Exact retained committed source/Cargo.lock+foreign patch/toolchain/offline Cargo command in just-PASS genuineBuild reproduces compiler intermediates. No rebuild or test replay. These are Cargo .rlib/.rmeta/.d/fingerprint metadata only, not models/data/private images/test executables/shared libraries/input/source.",
                reason="Real cache regrowth361959424B plus newimage9838592B makes originalfinal752MiB nominalcover exceed decimal50GB. Count growth first, retire only current actual intermediates once; original315375616 historical retirement not credited again.",
                allocated_selected_B=sum(entry["allocated_B"] for entry in snapshots),
                protected_nonselected_files=len(protected),
                old_scientific_refund_lending=0,
            ),
        )
        for entry in snapshots:
            path = Path(entry["path"])
            info = path.lstat()
            assert (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_nlink) == (
                entry["device"],
                entry["inode"],
                entry["bytes"],
                entry["mtime_ns"],
                1,
            )
            try:
                path.unlink()
            except OSError as error:
                errors.append(dict(path=str(path), error=repr(error)))
        for entry in protected:
            info = Path(entry["path"]).lstat()
            assert (
                info.st_size == entry["bytes"]
                and info.st_blocks * 512 == entry["allocated_B"]
                and info.st_nlink == entry["links"]
            )
        assert all(not Path(entry["path"]).exists() for entry in snapshots)
        save(
            "cache-retirement-return.json",
            dict(
                at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                intent=intent,
                retired_allocated_B=sum(entry["allocated_B"] for entry in snapshots),
                retired_files=len(snapshots),
                protected_files_unchanged=len(protected),
                errors=errors,
                canonical_EX_NB_acquired_released_on_return=True,
                source_native_model_RAW_RNG_tests=0,
                payload_model_ELF_library_Git_Beads_deletions=0,
                scientific_refund_reset_lending=0,
            ),
        )
    assert not errors
    print(
        json.dumps(
            dict(
                retired_allocated_B=sum(entry["allocated_B"] for entry in snapshots),
                retired_files=len(snapshots),
                protected_files=len(protected),
            )
        )
    )


if __name__ == "__main__":
    main()
