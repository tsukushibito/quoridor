"""Compose the fixed wall-geometry owner after the actual new25.3 collection release."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import stat
import subprocess

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
FIXED = ROOT / ".worktree/assets/perf/cedar-wall-path-work-v1/source-packet-v2"


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def command(*argv):
    return subprocess.check_output(list(argv), cwd=ROOT, stderr=subprocess.STDOUT)


def main():
    # This actual dependency must be collected by Root; preparation creates no fake STOP.
    dependency_path = OUT / "actual25_3-native-collection-release.json"
    dependency = json.loads(dependency_path.read_bytes())
    assert dependency["status"] == "ACTUAL25_3_NATIVE_NORMAL_COLLECTION_STOP_VERIFIED"
    assert dependency["job_id"] == "74bc134a-008b-4b6c-ab9a-98bf5de8da18"
    stop_ref = dependency["actual_native_collection_STOP"]
    assert ref(Path(stop_ref["path"])) == stop_ref
    assert not dependency["source_leases"] and not dependency["remaining_owned"]
    fresh = []
    for original in dependency["known_original_processes"]:
        current = identity(process_info(original["pid"]))
        assert current != identity(original)
        fresh.append(dict(original=original, fresh=current))
    binding_path = FIXED / "binding.json"
    binding_ref = ref(binding_path)
    assert (
        binding_ref["sha256"] == "5e1487a51cb55b4db3fd79ce4e98572aed75507308e9bf74b2c6e7363c4730f1"
        and binding_ref["bytes"] == 2815
    )
    binding = json.loads(binding_path.read_bytes())
    acceptance_path = OUT.parent / "source-review-v1/accepted-source-only.json"
    acceptance = json.loads(acceptance_path.read_bytes())
    assert acceptance["issue"] == "quoridor-4lc.324.26.1"
    assert acceptance["fixed_binding"] == binding_ref
    subjects = [row["subject"] for row in binding["subjects"]]
    assert subjects == [
        "crates/quoridor-core/src/position.rs",
        "crates/quoridor-core/tests/wall_path26.rs",
    ]
    patch = Path(binding["forward"]["path"])
    assert ref(patch) == binding["forward"]
    lock = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock.open("a") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        head = command("git", "rev-parse", "HEAD").decode().strip()
        assert head == "b45f13b64414654a9feaac1003023f7ce593ace2"
        assert command("git", "diff", "--cached", "--name-only") == b""
        foreign_paths = command("git", "diff", "--name-only", "HEAD").decode().splitlines()
        assert not set(subjects).intersection(foreign_paths)
        foreign = [ref(ROOT / name) for name in foreign_paths]
        before = []
        for row in binding["subjects"]:
            path = ROOT / row["subject"]
            if row["before"] is None:
                assert not path.exists() and not path.is_symlink()
                assert command("git", "ls-files", "--", row["subject"]) == b""
                actual = None
            else:
                actual = ref(path)
                assert all(actual[k] == row["before"][k] for k in ["sha256", "bytes", "mode"])
            assert ref(Path(row["post"]["path"])) == row["post"]
            before.append(actual)
        changed = [
            row.split("\t")[-1]
            for row in command("git", "apply", "--numstat", str(patch)).decode().splitlines()
        ]
        assert changed == subjects
        command("git", "apply", "--check", "--whitespace=nowarn", str(patch))
        applied = command("git", "apply", "--verbose", "--whitespace=nowarn", str(patch)).decode()
        assert "offset" not in applied.lower()
        after = []
        for row in binding["subjects"]:
            actual = ref(ROOT / row["subject"])
            assert all(actual[k] == row["post"][k] for k in ["sha256", "bytes", "mode"])
            after.append(actual)
        command(
            "/usr/local/cargo/bin/rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            "--check",
            *[str(ROOT / name) for name in subjects],
        )
        command("git", "diff", "--check", "--", *subjects)
        assert [ref(Path(row["path"])) for row in foreign] == foreign
        command("git", "add", "--", *subjects)
        assert command("git", "diff", "--cached", "--name-only").decode().splitlines() == subjects
        committed = command(
            "git", "commit", "-m", "Reuse candidate wall geometry for both reachability checks"
        ).decode()
        commit = command("git", "rev-parse", "HEAD").decode().strip()
        assert command("git", "diff", "--name-only", head, commit).decode().splitlines() == subjects
        assert [ref(Path(row["path"])) for row in foreign] == foreign
    document = dict(
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        issue="quoridor-4lc.324.26",
        status="SPARSE_MAIN_SOURCE_ADOPTED_NEW_SOFTWARE_PENDING",
        before_commit=head,
        commit=commit,
        subjects=[
            dict(subject=name, before=a, post=b)
            for name, a, b in zip(subjects, before, after, strict=True)
        ],
        fixed_binding=binding_ref,
        source_only_acceptance=ref(acceptance_path),
        actual25_3_native_collection_STOP=stop_ref,
        known_original_processes_fresh=fresh,
        foreign_paths_preserved=foreign,
        actual_patch_output=applied,
        commit_output=committed,
        formatter="Scoped rustfmt check PASS; posts match fixed formatted packet",
        software="UNBUILT_UNTYPED_UNRUN",
        numerical="Original26 Current/Current104 remains UNENTERED; no optional diagnostic or game rights",
        source_leases=[],
        remaining_owned=[],
        host_future_quiet=False,
        preserved="Current default/27 source/26 source and all pauses/seals/models/foreign/FAILED/NULL/UNKNOWNfees/50GB",
    )
    with (OUT / "actual-adoption.json").open("x") as stream:
        json.dump(document, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(status=document["status"], commit=commit, subjects=subjects)))


if __name__ == "__main__":
    main()
