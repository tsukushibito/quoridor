"""Issue the fixed replacement comparison at the actual release/collection STOP."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import shutil
import subprocess

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOFTWARE = OUT.parent / "software-v2"
OWN = ROOT / ".worktree/assets/perf/cedar-wall-path-work-v1"
MIB = 1024**2


def ref(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def checked(reference):
    assert ref(reference["path"]) == reference
    return json.loads(Path(reference["path"]).read_bytes())


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def main():
    loader = importlib.util.spec_from_file_location(
        "existing_phase_metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/normal208-entry-v1/issue_support.py",
    )
    prior = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(prior)
    protocol_path = OWN / "effect-preparation-v2/protocol.json"
    protocol_ref = ref(protocol_path)
    assert (
        protocol_ref["sha256"] == "8a226a7fd5b69a8c4eaf21a3e5c0decad47248c6f8ce3ac08cb7e728aa16289c"
    )
    assert protocol_ref["bytes"] == 8141
    software = json.loads(
        (SOFTWARE / "release-collection-v1/completion-and-STOP.json").read_bytes()
    )
    guard = json.loads((SOFTWARE / "release-collection-v1/guard-return.json").read_bytes())
    assert software["status"] == "ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP"
    assert guard["actual_return"]["exit_code"] == 0 and guard["actual_return"]["cleanup_complete"]
    assert (
        guard["actual_return"]["direct_child_reaped"]
        and guard["actual_return"]["handle_closes_complete"]
    )
    assert not guard["TMP"] and not guard["source_leases"]
    known = []
    for row in software["known_command_fresh_absence"]:
        fresh = identity(process_info(row["original"]["pid"]))
        assert fresh != identity(row["original"])
        known.append(dict(original=row["original"], fresh=fresh))
    control_root = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-shallow-main-history-v1/timed-rootquality-software-v1"
    )
    control_stop = json.loads(
        (control_root / "release-collection-v1/completion-and-STOP.json").read_bytes()
    )
    control = dict(
        control_build=control_stop["software_manifest"],
        control_artifact_byref=control_stop["artifact"],
        control_source_git="8ea599e2fb978fde01f07bc9804ad327c8f85620",
    )
    assert (
        control["control_build"]["sha256"]
        == "84fd79dc4f6b2e756b9f77688cb3b7b46f7d32132cf489802692548273af3695"
    )
    assert (
        control["control_artifact_byref"]["sha256"]
        == "f68639f78c816b9d590199f43cfccb96f63ed6f1e97e6cb461182a91c66ee3d7"
    )
    assert (
        software["software_manifest"]["sha256"]
        == "d7c30af9c800700f4c9383915a695338f106887eaf517311a12765a740c2e4c0"
    )
    control_build = checked(control["control_build"])
    candidate_build = checked(software["software_manifest"])
    assert control_build["status"] == candidate_build["status"] == "PASS"
    control_intent = json.loads((control_root / "build-intent-release.json").read_bytes())
    candidate_intent = json.loads((SOFTWARE / "build-intent-release.json").read_bytes())
    assert control_intent["tools"] == candidate_intent["tools"]
    assert {k: v for k, v in control_intent["env"].items() if k != "TMPDIR"} == {
        k: v for k, v in candidate_intent["env"].items() if k != "TMPDIR"
    }
    assert (
        control_intent["source"]["patch"]["sha256"] == candidate_intent["source"]["patch"]["sha256"]
    )
    lock = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock.open("a+") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for caller in software["current_callers"]:
            assert ref(caller["path"]) == caller
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        assert head == "92fb6faa5463e5d4550244b7fb902e0ab05b5a1d"
        changed = subprocess.check_output(
            ["git", "diff", "--name-only", control["control_source_git"], head], cwd=ROOT, text=True
        ).splitlines()
        assert changed == [
            "crates/quoridor-core/src/position.rs",
            "crates/quoridor-core/tests/wall_path26.rs",
            "docs/design/ai-nnue-optimization-agenda.md",
            "docs/research-findings.md",
        ]
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_SOURCE_SOFTWARE_COLLECTION_RELEASED_FAIR_A_B_WALL_PATH_PAIR",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=head,
                current_four_callers=software["current_callers"],
                software_manifest=software["software_manifest"],
                artifact=software["artifact"],
                control_build=control["control_build"],
                control_artifact=control["control_artifact_byref"],
                control_source_git=control["control_source_git"],
                candidate_build=software["software_manifest"],
                candidate_artifact=software["artifact"],
                actual_software_STOP=ref(
                    SOFTWARE / "release-collection-v1/completion-and-STOP.json"
                ),
                collector_guard=ref(SOFTWARE / "release-collection-v1/guard-return.json"),
                common_source_correspondence=dict(
                    changed_subjects=changed,
                    sparse_adoption=ref(OUT.parent / "source-adoption-v1/actual-adoption.json"),
                    tools_and_env_except_owned_TMP_exact=True,
                    foreign_patch_exact=True,
                ),
                source_SH_NB_acquired_released=False,
                source_EX_NB_acquired_released=True,
                source_leases_remaining=[],
                qualification="New wall-path Rust3 each running1, affected Core/AI/Runner Clippy warning0, genuine release normal finalize PASS. Both N1 Current; production delta Position::legal_wall only, plus new verification file/docs; no measured improvement inferred.",
                numerical_scope="Inherited641ca structural only; actual current normal factory/numerical_fields/origin admission required",
                evaluation="UNENTERED",
                host_future_quiet=False,
            ),
        )
        roots = [str(OWN), str(OUT)]
        actual = prior.point(roots)
        whole = 336 * MIB
        future = 327155712
        margin = whole - actual["allocated_B"] - future
        assert margin >= 8 * MIB, (actual, margin)
        cover = software["current_known_cover_B"]
        shortage = max(0, cover + whole + 32 * MIB - 50000000000)
        target = Path(candidate_intent["target"])
        # Retire only the two actual stopped, reconstructible shared Cargo profiles.
        # All six independent qualified executable copies remain outside the pool.
        affected = checked(software["affected_point"])
        marker_path = target / ".research-owner.json"
        marker = checked(ref(marker_path))
        assert marker["writer"] == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13" and marker[
            "target"
        ] == str(target)
        private_rows = []
        for key in (
            "private_image",
            "unchanged_old_private_image",
            "unchanged_old24_private_image",
            "unchanged_old25_private_image",
            "unchanged_old27_private_image",
            "unchanged_old25_timed_private_image",
        ):
            p = Path(affected[key]["path"]) / "quoridor-runner"
            q = p.lstat()
            assert (
                stat.S_ISREG(q.st_mode)
                and q.st_nlink == 1
                and not p.is_symlink()
                and not p.is_relative_to(target)
            )
            private_rows.append(
                dict(
                    path=str(p),
                    device=q.st_dev,
                    inode=q.st_ino,
                    bytes=q.st_size,
                    mtime_ns=q.st_mtime_ns,
                    mode=q.st_mode,
                    links=q.st_nlink,
                )
            )
        profiles = [target / "debug", target / "release"]
        groups = {}
        directories = []
        for top in profiles:
            assert top.is_dir() and not top.is_symlink()
            pending = [top]
            while pending:
                p = pending.pop()
                q = p.lstat()
                assert not stat.S_ISLNK(q.st_mode)
                if stat.S_ISDIR(q.st_mode):
                    directories.append(dict(path=str(p), allocated_B=q.st_blocks * 512))
                    pending.extend(p.iterdir())
                else:
                    assert stat.S_ISREG(q.st_mode)
                    row = groups.setdefault(
                        (q.st_dev, q.st_ino),
                        dict(
                            paths=[],
                            allocated_B=q.st_blocks * 512,
                            links=q.st_nlink,
                            device=q.st_dev,
                            inode=q.st_ino,
                            bytes=q.st_size,
                            mtime_ns=q.st_mtime_ns,
                            mode=q.st_mode,
                        ),
                    )
                    row["paths"].append(str(p))
                    assert row["links"] == q.st_nlink
        reclaim = sum(
            row["allocated_B"] for row in groups.values() if len(row["paths"]) == row["links"]
        ) + sum(row["allocated_B"] for row in directories)
        assert reclaim >= shortage
        retirement = save(
            "cache-retirement-intent.json",
            dict(
                actual_software_STOP=ref(
                    SOFTWARE / "release-collection-v1/completion-and-STOP.json"
                ),
                fresh_known_ids=known,
                marker=ref(marker_path),
                concrete_shortage_B=shortage,
                profiles=[str(p) for p in profiles],
                regular_inode_groups=list(groups.values()),
                directories=directories,
                expected_reclaim_B=reclaim,
                preserved_private_images=private_rows,
                scope="Actual stopped reconstructible debug/release Cargo profiles only; all source/Git/RAW/FAILED/models/inputs/qualified images retained. No science quota refund/lending.",
            ),
        )
        completed = []
        try:
            for p in profiles:
                shutil.rmtree(p)
                assert not p.exists()
                completed.append(str(p))
        finally:
            save(
                "cache-retirement-return.json",
                dict(
                    intent=retirement,
                    removed_profile_paths=completed,
                    all_selected_removed=len(completed) == 2,
                    actual_removed_B_once=reclaim if len(completed) == 2 else None,
                    known_cover_after_B=cover - reclaim if len(completed) == 2 else None,
                    old_credits_reapplied=0,
                    refund_loan_reset=0,
                    later_tails_globalactual_fullfees="UNKNOWN",
                ),
            )
        assert checked(ref(marker_path)) == marker
        for row in private_rows:
            q = Path(row["path"]).lstat()
            assert (q.st_dev, q.st_ino, q.st_size, q.st_mtime_ns, q.st_mode, q.st_nlink) == (
                row["device"],
                row["inode"],
                row["bytes"],
                row["mtime_ns"],
                row["mode"],
                row["links"],
            )
        retired = reclaim
        cover -= retired
        # These two nonoverlapping prior ordinary OWN26 observations are included
        # inside the new whole, never added as separate new source charges.
        # Unknown prior-cover membership does not justify subtracting a credit.
        old_source_points = [
            ref(OWN / "source-packet-v2/ordinary-affected-point.json"),
            ref(OWN / "current-history-preparation-v1/ordinary-affected-point.json"),
        ]
        old_source_B = sum(checked(row)["allocated_B"] for row in old_source_points)
        assert cover + whole <= 50000000000
        fs = os.statvfs(OWN)
        assert fs.f_bavail * fs.f_frsize > whole
        capacity = save(
            "capacity-and-holding.json",
            dict(
                roots=roots,
                scope="ONE336MiB OWN26 plus Root entry union includes prior ordinary source once; old points are not separately charged. Their inclusion in prior conservative cover is UNKNOWN, so no unproven credit is subtracted; conservative overlap is a capacity upper, not actual global occupancy or fees.",
                prior_source_points_within_whole=old_source_points,
                prior_cover_membership_UNKNOWN_no_unproven_credit=True,
                prior_source_point_B=old_source_B,
                actual_ended_point=actual,
                conservative_future_B=future,
                whole_B=whole,
                forecast_margin_B=margin,
                prior_known_cover_B=cover,
                new_known_cover_B=cover + whole,
                remaining_to_decimal50GB_B=50000000000 - cover - whole,
                filesystem_available_B=fs.f_bavail * fs.f_frsize,
                images_models_libraries_copy_B=0,
                old_credits_refund_loan_reset=0,
                later_tails_globalactual_fullfees="UNKNOWN",
            ),
        )
        support = save(
            "phase-support-N1.json",
            dict(
                issue="quoridor-4lc.324.26",
                status="ISSUED_ORIGINAL26_CURRENT_CURRENT_NORMAL104_ONE_SERIAL_LIFETIME",
                fixed_protocol=protocol_ref,
                current_source_adoption=release,
                actual_source_STOP=release,
                actual_software_STOP=ref(
                    SOFTWARE / "release-collection-v1/completion-and-STOP.json"
                ),
                whole_B=whole,
                roots=roots,
                storage_budget=dict(whole_B=whole, roots=roots),
                owned_B=whole,
                free_B=margin,
                capacity_basis=capacity,
                resources=dict(
                    search_cpu_cores=[12],
                    total_search_threads=1,
                    worker_cpu=12,
                    main_guardian=0,
                    outer_guardian=18,
                    launch_affinity=[0, 12, 18],
                    family_B=4 * 1024**3,
                    controller_B=1536 * MIB,
                    native_B=2560 * MIB,
                    host_reserve_B=4 * 1024**3,
                    GPU=0,
                    threads=1,
                    CPU=2,
                    controller_included=True,
                    family_RAM_B=4 * 1024**3,
                    controller_RAM_B=1536 * MIB,
                ),
                limits=dict(
                    worker_cpu=12,
                    guardian_cpu=0,
                    family_B=4 * 1024**3,
                    controller_B=1536 * MIB,
                    host_reserve_B=4 * 1024**3,
                    owned_B=whole,
                    free_B=margin,
                    log_B=MIB,
                ),
                total_original_calls=104,
                total_original_nodes=104000000,
                per_call_aggregate_nodes=1000000,
                TOTAL_TT_entries=1048576,
                serial_runs=4,
                sessions=24,
                RUN_timeout_s=180,
                parent_accepted_s=1200,
                parent_command_s=1140,
                cleanup_margin_s=60,
                readonly_images_models_copy_B=0,
                native_aggregate_B_each=3 * MIB,
                perf_RAW_B=0,
                allocation="Both A/B N1 Current, worker12/main0/outer18, serial4 RUNs under ONE336MiB whole; child_cpu_cores=[0,12], no duplicated grant.",
                normal_remaining_inputs="Current factory/numerical_fields/actual environments, fresh physical SMT peers/RAM/host4/fullroots/storage/ownerpausecancel/origin/end_at/serializer/cleanup required; no RPC=native START claim",
                timing="Main/currentcallers/image/libs/env/Cargo/substantial IO frozen through actual native+normalcollection STOP only; independent light25.3/27 allowed",
                conditional64="No games/optional diagnostic issued for26;104calls104M only",
                science_refund_lending_reset=0,
                pauses_seals_models_defaults_foreign_FAILED_UNKNOWN="PRESERVED",
            ),
        )
        save(
            "issued-inputs.json",
            dict(
                release=release,
                phase_supports=[support],
                capacity=capacity,
                known_fresh_absence=known,
                source_leases=[],
                evaluation="UNENTERED",
            ),
        )
    print(
        json.dumps(
            dict(
                status="ISSUED",
                whole_B=whole,
                margin_B=margin,
                retired_cache_B=retired,
                current_cover_B=cover + whole,
                release=release,
                support=support,
            )
        )
    )


if __name__ == "__main__":
    main()
