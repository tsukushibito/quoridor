"""Collect original26 new-only software once after its completion event."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import stat

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOFTWARE = OUT.parent


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path), sha256=hashlib.sha256(body).hexdigest(), bytes=len(body), mode="0644"
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def item(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_nlink == 1
    return dict(
        path=str(path),
        device=info.st_dev,
        inode=info.st_ino,
        bytes=info.st_size,
        allocated_B=info.st_blocks * 512,
        links=info.st_nlink,
        mtime_ns=info.st_mtime_ns,
        mode=info.st_mode,
    )


def main():
    outer_path = SOFTWARE / "check-runtime-v1/result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((outer_path.parent / "state.json").read_bytes())
    candidate_path = SOFTWARE / "operation-prefix/prefix-result.json"
    candidate = json.loads(candidate_path.read_bytes())
    assert outer["job_id"] == candidate["origin_job_id"] == "92a4afed-826a-4d5a-a59c-5480d24d6db7"
    assert outer["outcome"] == "succeeded" and outer["exit_code"] == 0
    assert outer["cleanup_complete"] and outer["direct_child_reaped"] and not outer["remaining"]
    assert candidate["status"] == "PASS_TEST_LINT_PREFIX_ONLY" and candidate["cleanup_complete"]
    assert not candidate["release_executed"] and len(candidate["checks"]) == 4
    assert sum(row["role"] == "test" for row in candidate["checks"]) == 3
    known = []
    for row in candidate["checks"]:
        assert row["status"] == "PASS" and row["cargo"]["warning_count"] == 0
        receipt = json.loads(Path(row["persisted_process_receipt"]["path"]).read_bytes())
        assert receipt["cleanup_complete"] and receipt["direct_child_reaped"]
        assert receipt["handle_closes_complete"] and not receipt["remaining"]
        assert identity(process_info(receipt["child"]["pid"])) != receipt["child"]
        if row["role"] == "test":
            log = Path(row["full_log"]["path"]).read_text()
            assert "running 1 test\n" in log
            assert "test result: ok. 1 passed; 0 failed;" in log
            assert row["argv"][row["argv"].index("--test") + 2] + " ... ok" in log
        known.append(
            dict(
                name=row["name"],
                original=receipt["child"],
                fresh=identity(process_info(receipt["child"]["pid"])),
            )
        )
    for name in ["child", "supervisor"]:
        original = state[name]
        current = identity(process_info(original["pid"]))
        if name == "child":
            assert current != original
        known.append(dict(name=name, original=original, fresh=current))
    loader = importlib.util.spec_from_file_location(
        "prior_collection",
        ROOT
        / ".artifacts/research-team/integration324/cedar-shallow-main-history-v1/software-v1/first-prefix-failure-collection-v1/collect.py",
    )
    prior = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(prior)
    spec = json.loads((SOFTWARE / "build-intent-prefix.json").read_bytes())
    basis = json.loads((SOFTWARE / "ended25_3-bulk-and-software-basis.json").read_bytes())
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        temporary = Path(spec["TMP"])
        if temporary.exists():
            assert not list(temporary.iterdir())
            temporary.rmdir()
        assert not temporary.exists()
        target_profiles = [Path(spec["target"]) / name for name in ("debug", "release")]
        absent_profiles = [str(path) for path in target_profiles if not path.exists()]
        roots = [path for path in target_profiles if path.exists()] + [
            ROOT / ".artifacts/research-team/integration324" / name
            for name in [
                "cedar-lazy-smp-v1/software-v1/private-image-v7",
                "cedar-lazy-smp-node-publication-v1/software-v1/private-image-release",
                "cedar-shallow-main-history-v1/software-v1/private-image-release",
                "cedar-lazy-smp-followup-v1/replacement-v1/software-v1/private-image-release",
                "cedar-shallow-main-history-v1/timed-rootquality-software-v1/private-image-release",
            ]
        ]
        actual = prior.point(roots)
        point_ref = save(
            "affected-target-and-retained-image-once.json",
            dict(
                roots=[str(p) for p in roots],
                point=actual,
                absent_target_profiles=absent_profiles,
                scope="Directed ended present target profiles and five retained private images inode union; absent profiles recorded, no global/source/model/RAW walk.",
            ),
        )
        cover = (
            basis["known_cover_after_refinement_B"]
            + actual["allocated_B"]
            - basis["actual_target_and_five_private_images_baseline_B"]
        )
        assert cover <= 50_000_000_000
        save(
            "completion-and-STOP.json",
            dict(
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                status="NEW_WALL_PATH_RUST_THREE_AFFECTED_CLIPPY_PASS_RELEASE_UNENTERED",
                outer=ref(outer_path),
                candidate=ref(candidate_path),
                known_original_processes=known,
                actual_affected_point=point_ref,
                actual_ended25_3_basis=ref(SOFTWARE / "ended25_3-bulk-and-software-basis.json"),
                current_known_cover_B=cover,
                remaining_to_decimal50GB_B=50_000_000_000 - cover,
                outer_seconds_once=outer["wall_seconds"],
                nested_added=0,
                software_command_remaining_s=1740 - math.ceil(outer["wall_seconds"]),
                software_parent_remaining_s=1800 - math.ceil(outer["wall_seconds"]),
                TMP=[],
                source_leases=[],
                remaining_owned=[],
                host_future_quiet=False,
                preserved="Original25 incomplete, new25.3 independent result and all prior failures retained; no old suite/science replay/refund/lending; later tails/globalactual/fullfees UNKNOWN. Basis pending-analysis wording is historical; latest25.3 saved result separately returned.",
            ),
        )
    print(
        json.dumps(
            dict(
                status="CHECKS_PASS_RELEASE_NEXT",
                command_remaining_s=1740 - math.ceil(outer["wall_seconds"]),
                actual_group_B=actual["allocated_B"],
            )
        )
    )


if __name__ == "__main__":
    main()
