"""Restore the qualified baseline after the frozen completion gate failed."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import stat
import subprocess

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-wall-path-work-v1"


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True)


def main():
    minimum = json.loads((OWN / "analysis-v1/minimum-result.json").read_bytes())
    assert minimum["status"] == "INCOMPLETE_RETAIN_BASELINE_NO_SPEEDUP_QUALIFICATION"
    assert minimum["total_calls"] == 104 and minimum["complete"] == 100 and minimum["UNKNOWN"] == 4
    assert not minimum["all_finite_gates_pass"]
    finalizer = json.loads((OWN / "result-finalizer-v1/return.json").read_bytes())
    assert (
        finalizer["exit_code"] == 0
        and finalizer["cleanup_complete"]
        and finalizer["direct_child_reaped"]
        and finalizer["handle_closes_complete"]
        and not finalizer["remaining"]
    )
    assert identity(process_info(finalizer["child"]["pid"])) != identity(finalizer["child"])
    binding = json.loads((OWN / "source-packet-v2/binding.json").read_bytes())
    inverse = binding["inverse"]
    assert ref(Path(inverse["path"])) == inverse
    lock = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock.open("a") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert git("rev-parse", "HEAD").strip() == "92fb6faa5463e5d4550244b7fb902e0ab05b5a1d"
        assert not git("diff", "--cached", "--name-only").strip()
        foreign = git("diff", "--name-only").splitlines()
        assert foreign == [
            ".devcontainer/devcontainer.json",
            ".devcontainer/update-toolchain.sh",
            "Cargo.lock",
            "scripts/dev/setup-rust.sh",
        ]
        before_foreign = [ref(ROOT / name) for name in foreign]
        for row in binding["subjects"]:
            actual = ref(ROOT / row["subject"])
            assert {key: actual[key] for key in ("sha256", "bytes", "mode")} == {
                key: row["post"][key] for key in ("sha256", "bytes", "mode")
            }
        patch = subprocess.run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "--no-backup-if-mismatch",
                "-p1",
                "-i",
                inverse["path"],
            ],
            cwd=ROOT,
            text=True,
            capture_output=True,
        )
        (OUT / "inverse-patch.stdout.txt").write_text(patch.stdout)
        (OUT / "inverse-patch.stderr.txt").write_text(patch.stderr)
        assert (
            patch.returncode == 0
            and "offset" not in patch.stdout.lower()
            and "fuzz" not in patch.stdout.lower()
        )
        position = ROOT / "crates/quoridor-core/src/position.rs"
        before = binding["subjects"][0]["before"]
        assert (
            ref(position)["sha256"] == before["sha256"]
            and ref(position)["bytes"] == before["bytes"]
        )
        assert not (ROOT / "crates/quoridor-core/tests/wall_path26.rs").exists()
        subprocess.run(
            [
                "/usr/local/cargo/bin/rustfmt",
                "--edition",
                "2024",
                "--config",
                "skip_children=true",
                "--check",
                str(position),
            ],
            check=True,
            cwd=ROOT,
        )
        findings = ROOT / "docs/research-findings.md"
        findings.write_text(
            findings.read_text()
            + """

### 独立25.3の新104完了と前向き対局準備（2026-10-20）

新104は全件returnedOk・合法な完成depth>=1・親復元を満たし、error/missing/cancel/NodeLimitは0、6,551,433nodesだった。要求D64は100 TimeLimit UNKNOWNと4 DepthCompleteで、全幅D64完遂とは呼ばない。事前の時計条件はB最大0.106116403秒、p95のB/A比0.9649339787551072でPASSした。[固定結果と実STOP](../.worktree/assets/perf/cedar-shallow-main-history-v1/corrected-entry-trial-v1/analysis-v1/completion.json)。

固定21参照手のlatest順位はB1対A0で改善0/同じ22/悪化4、B2対A3で1/19/6と混在し、同条件反復にも変動がある。TT/PV優先、時刻・warm history・異なるtree、3family/6系列の相関を残し、参照手をoracleや真の最善手にしない。root14の順位8/8/7/7も原23の負historyが有害だった証明にはならない。default Currentを保持し、改善・害・無効果・棋力を認定しない。

元gateに従う前向き新64局の準備は返却済みで、既存SearchWallTime入口が同評価器/同画像のcurrent対halfを扱うため追加source修復・検査は不要だった。[通常準備](../.worktree/assets/perf/cedar-shallow-main-history-v1/corrected-entry-trial-v1/forward64-preparation-v1/prepared.json)。新64/32両色family・最大1.024Gと唯一のnative custom-Rng family CIを維持し、実book seed/current refs/支持/原点/通常入場が必要である。この記録時点でgames/CIは0。原401b/9786の4UNKNOWN/100unperformed/旧64STOPPEDと費用を変更しない。

### 壁合法性一候補の原104は完成条件未達（324.26）

両群Currentの固定ABBA104は全件returnedOk・合法depth>=1・復元、通常4manifest/data PASSだったが、100 DepthCompleteと4 NodeLimit UNKNOWNで全104完成gateを満たさなかった。同じroot4が全四回で要求D6/完成D5/1Mとなり、51,881,168nodesを消化した。[固定minimum](../.worktree/assets/perf/cedar-wall-path-work-v1/analysis-v1/minimum-result.json)、[保存report](../.worktree/assets/perf/cedar-wall-path-work-v1/analysis-v1/report-ja.md)。全26rootの保存action/valuebits/PV/depth/stop/treework/完全履歴は四回で対応したが、内部TT全表やoracleの同等性は主張しない。

capを含む保存時間の比率・反復分離・stock条件が数値上通っても、完了条件失敗を補えない。有限結果は **INCOMPLETE_RETAIN_BASELINE_NO_SPEEDUP_QUALIFICATION** とし、成功subsetやcap時間から完成Search速度を作らない。既存深さ根拠がこの共通warm設定での完成を保証しなかった点は未解決で、原因や新depth試行を推定せず、104は消化済み/追加診断12・refill・再深度・対局は発行しない。関連Max26.2へ解釈だけを限定確認し、その通常管理を他工程のgateにしない。

Rootは採用に足る資格が無い候補の比較専用legal_wall差分とwall_path26 fixtureを撤去し、基準Positionの完全bytesと既定を復元する。[撤去の実記録](../.artifacts/research-team/integration324/cedar-wall-path-work-v1/retirement-v1/baseline-retirement.json)。元Git92fb6faa、私有post/inverse、二つの真正image、全原結果/RAW/FAILEDを保持する。新検査や元成功suiteは再演しない。外側71.502312897秒と受付寿命73.374095秒を区別し、nestedを足さない。

### root先頭手優先の排他的分担を別に調べる（324.28）

人間の新指示により、同じroot全体を重複探索するLazy SMPとは別に、rootの先頭有力手を先に読み、残り候補を排他的に分けるopt-in2thread案を同じSMP作者へ配分した。まず保存候補手別仕事量と共通child経路を限定精査する。先頭手の直列支配、負荷不均衡、枝刈りの変化は未検証で、node比率を時間の比率にせず、見込みが無ければ理由を残して終了できる。[人間指示に基づく境界](../.artifacts/research-team/integration324/root-split-followup-contract.txt)。

必要な不足診断だけ最大26calls/26M、実装する場合は同じ凍結source/Cedar/LMR/PVS/ordering/総TT1MでN1・現Lazy N2・root分担N2の各二反復、固定深さ上限8と100ms/5msを最大312calls/312Mで比較する。計338calls/338Mを上限とし、条件・順序・完成可能な深さは結果前に固定する。元root順位/LMR量、stale-alphaのtyped boundと必要再探索、反復完成、mainだけの最終authority、独立履歴、全worker取消/cap/quietを保つ。現search_forcedのnative SMP拒否を隠さず必要な共通child経路だけを扱い、全木並列・pernode scheduler・新対局/fit/model/teacherやdefault昇格は含まない。実source開始/実計測は予定と区別し、25.3/26/27を変更・中断しない。
"""
        )
        agenda = ROOT / "docs/design/ai-nnue-optimization-agenda.md"
        agenda.write_text(
            agenda.read_text()
            + """

26の原104は100完成+4NodeLimit UNKNOWNで全104完成条件に届かず、速度資格を得なかった。Root4は全四回で同じcapとなり、共通warm設定での深さ根拠の不足を残す。追加試行・成功subsetへの変更をせず、候補だけの壁mask共有差分/fixtureを撤去し、元結果/二image/Git/FAILEDを保持する。25.3は別の新104で時計・機械gateを通り、既存SearchWallTimeのcurrent/half対局入口に追加修復は不要だった。順位変化は混在し改善は未認定で、元条件の前向き64局準備だけを続ける。[最新の有限観測](../research-findings.md)。

## root先頭手優先・排他的分担の限定研究（324.28）

人間の新しい選択はrootだけの枝分担であり、27の四仮説を同時実装する依頼ではない。既存SMP作者の自然なSTOPから、保存候補手別仕事と共通child探索を読み、先頭手の直列部分/他枝の仕事/不足をまず示す。見込みが無ければ実装を義務化しない。必要不足診断は同じ26入力/6系列の最大26/26M、見込みがあればrootだけのopt-in2thread私有差分・意味のあるfullwidth/bound/中断検査・関連限定reviewへ進む。既存search_forcedのnative SMP拒否を調べ、共通loop/永続workerを再用し、全探索copy/新scheduler/pernode通信は作らない。

比較は同じ凍結source・Cedar・LMR/PVS/order・総TT1MのN1/現Lazy N2/root分担N2、各二反復×26入力×固定深さと100ms5で最大312/312M、診断込み338/338Mまで。深さ上限8・順序・採否は結果前固定し、初期化と時系列を再用する。元順位をworker内で振り直さず、stale alphaのboundをexactにせず必要確認探索を行い、全候補処理/正当cutoffの時だけ反復完成、mainだけが最終結果を確定する。完全履歴・typedTT・独立scratch・合算cap・cancel/error/reset/dropと直接join/reapを維持する。

Search/whole/reset/終了、完成深度分布、main/total work/CPU、先頭手と他枝の仕事・待ち/再探索を最小の有界観測で分ける。node増や独立候補数を速度/有効情報量にせず、不足/未完はUNKNOWNのまま補充しない。今回は棋力対局・全木並列・4threads/tuning・policy/value/model/教師/fit未発行。効果が乏しければ保持費を示してprototype/専用observerを撤去し、過去復元はGit、科学データ/FAILEDは保存する。25.3/26/27と時計・重いbuild/IOだけをactualSTOPで調整し、親close/ACKを入口にしない。状態はBeads、[依頼境界](../../.artifacts/research-team/integration324/root-split-followup-contract.txt)と本agenda/findings以外の管理系は追加しない。
"""
        )
        subprocess.run(
            [
                "tools/research-quality/node_modules/.bin/prettier",
                "--config",
                "tools/research-quality/.prettierrc.json",
                "--ignore-path",
                "/dev/null",
                "--write",
                str(findings),
                str(agenda),
            ],
            check=True,
            cwd=ROOT,
        )
        subprocess.run(
            [
                "tools/research-quality/node_modules/.bin/prettier",
                "--config",
                "tools/research-quality/.prettierrc.json",
                "--ignore-path",
                "/dev/null",
                "--check",
                str(findings),
                str(agenda),
            ],
            check=True,
            cwd=ROOT,
        )
        subprocess.run(["git", "diff", "--check"], check=True, cwd=ROOT)
        assert [ref(ROOT / name) for name in foreign] == before_foreign
        paths = [
            "crates/quoridor-core/src/position.rs",
            "crates/quoridor-core/tests/wall_path26.rs",
            "docs/research-findings.md",
            "docs/design/ai-nnue-optimization-agenda.md",
        ]
        subprocess.run(["git", "add", "--", *paths], check=True, cwd=ROOT)
        assert set(git("diff", "--cached", "--name-only").splitlines()) == set(paths)
        subprocess.run(
            [
                "git",
                "commit",
                "-m",
                "Retain baseline after incomplete wall-path comparison and record root split scope",
            ],
            check=True,
            cwd=ROOT,
        )
        current = git("rev-parse", "HEAD").strip()
        assert git(
            "diff", "--name-only", "8ea599e2fb978fde01f07bc9804ad327c8f85620", current
        ).splitlines() == [
            "docs/design/ai-nnue-optimization-agenda.md",
            "docs/research-findings.md",
        ]
        packet = dict(
            at=datetime.datetime.now(datetime.UTC).isoformat(),
            status="BASELINE_RESTORED_AFTER_FIXED_COMPLETION_GATE_FALSE",
            commit=current,
            original_candidate_commit="92fb6faa5463e5d4550244b7fb902e0ab05b5a1d",
            original_minimum=ref(OWN / "analysis-v1/minimum-result.json"),
            actual_finalizer=ref(OWN / "result-finalizer-v1/return.json"),
            inverse=inverse,
            baseline_position=ref(position),
            removed_fixture=paths[1],
            actual_patch_offset_fuzz_zero=True,
            protected_foreign_exact=True,
            prior_qualified_Rust_source="8ea599e2 exact production/tests tree restored; docs only differ",
            compiler_test_native_model_RAW_RNG_replay=0,
            limited_independent_result_review="26.2 separately active, no gate for ordinary baseline restoration or25.3/27/28",
            source_leases=[],
            host_future_quiet=False,
        )
        with (OUT / "baseline-retirement.json").open("x") as file:
            json.dump(packet, file, indent=2)
            file.write("\n")
        print(json.dumps(dict(commit=current, status=packet["status"])))


if __name__ == "__main__":
    main()
