"""Bind the new node-publication software to the maintained serial BUILD path."""

import argparse
import copy
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OLD = ROOT / ".artifacts/research-team/integration324/cedar-lazy-smp-v1/software-v1"
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def git(*args):
    return subprocess.run(
        ["git", *args], cwd=ROOT, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ).stdout


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("prefix", "remaining", "release"), required=True)
    parser.add_argument("--seconds", type=int, default=2400)
    args = parser.parse_args()
    stage = args.stage
    loader = importlib.util.spec_from_file_location(
        "actual_node_publication_BUILD", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    old = json.loads((OLD / "build-intent-v7.json").read_bytes())
    actual_path = OUT.parent / "source-adoption-v1/actual-adoption.json"
    actual = json.loads(actual_path.read_bytes())
    assert actual["status"] == "ACCEPTED_FIXED_SOURCE_ONLY_SOFTWARE_PENDING"
    assert git("diff", "--cached", "--name-only") == b""
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        patch = OUT / f"actual-foreign-source-{stage}.patch"
        with patch.open("xb") as stream:
            stream.write(git("diff", "--binary", "--no-ext-diff", "--no-textconv", "HEAD", "--"))
        source = copy.deepcopy(old["source"])
        source.update(
            commit=git("rev-parse", "HEAD").decode().strip(),
            patch=ref(patch),
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        assert source["untracked_inputs"] == []
        assert not git(
            "ls-files",
            "--others",
            "--exclude-standard",
            "--",
            "Cargo.toml",
            "Cargo.lock",
            ".cargo",
            "crates",
        )
        for witness in source["cargo_configs"]:
            path = Path(witness["path"])
            witness["file"] = ref(path) if path.exists() else None
        adoption = dict(
            schema="quoridor.research.source-adoption.v1",
            status="ACCEPTED",
            issue="quoridor-4lc.324.24",
            source=source,
            actual_fixed_source_adoption=ref(actual_path),
            new_Python_one=ref(OUT / "new-Python-one-STOP.json"),
            limits="Source/static acceptance and necessary new software only; original22 tests and numerical outcomes are not replayed or promoted.",
        )
        if stage in {"remaining", "release"}:
            repair = OUT.parent / "failed-boundary-adoption-v1/actual-repair.json"
            assert json.loads(repair.read_bytes())["status"] == "ADOPTED_FAILED_FIXTURE_ONLY"
            adoption["actual_failed_fixture_repair"] = ref(repair)
            receipt_path = OUT / "operation-prefix/prefix-result.json"
            receipt = json.loads(receipt_path.read_bytes())
            assert [r["status"] for r in receipt["checks"]] == ["PASS", "PASS", "FAILED"]
            adoption["prior_software"] = dict(
                subjects=[ref(ROOT / row["subject"]) for row in actual["subjects"]],
                receipts=[
                    dict(name=row["name"], file=ref(receipt_path)) for row in receipt["checks"][:2]
                ],
            )
            if stage == "release":
                remainder_path = OUT / "operation-remaining/prefix-result.json"
                remainder = json.loads(remainder_path.read_bytes())
                assert (
                    remainder["status"] == "PASS_TEST_LINT_PREFIX_ONLY"
                    and remainder["cleanup_complete"]
                )
                adoption["prior_software"]["receipts"] += [
                    dict(name=row["name"], file=ref(remainder_path)) for row in remainder["checks"]
                ]
        adoption_ref = save(f"build-source-adoption-{stage}.json", adoption)
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
        )
        support = save(
            f"resources-{stage}.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.24",
                authority=adoption_ref,
                resources=dict(
                    worker_cpu=12,
                    guardian_cpu=16,
                    test_cpu_cores=[12, 14, 16],
                    native_threads=1,
                    GPU=0,
                    family_RAM_B=4 * 1024**3,
                    controller_included=True,
                    controller_B=64 * 1024**2,
                    host_reserve_B=4 * 1024**3,
                ),
                storage_budget=None,
                actual_cache_retirement=ref(OUT / "release-cache-retirement-v1/return.json"),
                scope="Ordinary serial software, no micro storage grant or numerical rights. New five Rust definitions and affectedClippy prefix, then genuine release-only suffix; no old successful tests replayed. Fresh normal physical/RAM/source/origin admission remains mandatory.",
            ),
        )
        target = Path(old["target"])
        marker = target / ".research-owner.json"
        previous = json.loads(marker.read_bytes())
        assert previous["writer"] == WRITER and previous["target"] == str(target)
        save(f"prior-target-marker-{stage}.json", previous)
        old_handover = json.loads((OLD / "target-handover-v7.json").read_bytes())
        assert not Path(old_handover["old_target"]).exists()
        handover = save(
            f"target-handover-{stage}.json",
            dict(
                schema="research.target-handover.v1",
                status="HANDED_OVER",
                target=str(target),
                target_writer=WRITER,
                shared_serial_pool=True,
                old_target=old_handover["old_target"],
                fresh_private_root=str(OUT / f"private-image-{stage}"),
                owned_remaining=[],
                test_cpu_cores=[12, 14, 16],
                actual_previous_software_STOP=ref(OLD / "collection-v1/completion-and-STOP.json"),
                actual_source_adoption=ref(actual_path),
                scope="Same serial Root target and actual ended compiler/native/source lifetimes, no future host quiet assertion.",
            ),
        )
        cargo = old["tools"]["CARGO"]["file"]["path"]
        selector_path = (
            ROOT
            / ".worktree/assets/perf/cedar-lazy-smp-node-publication-v1/new-software-selectors.json"
        )
        assert (
            ref(selector_path)["sha256"]
            == "c635528879896abc194f69d4618d5fb84effcfa6bf4e595ba103d5cb35f3cdd9"
        )
        selectors = json.loads(selector_path.read_bytes())
        commands = []
        if stage in {"prefix", "remaining"}:
            for n, row in enumerate(selectors["AI"] + selectors["Runner"], 1):
                if stage == "remaining" and n <= 2:
                    continue
                features = (
                    "research-diagnostics"
                    if row["package"] == "quoridor-ai"
                    else "measurement,quoridor-inference/claustrophobia"
                )
                commands.append(
                    dict(
                        name=f"node-publication-new-Rust-{n}",
                        role="test",
                        argv=[
                            cargo,
                            "test",
                            "--offline",
                            "--locked",
                            "--manifest-path",
                            str(ROOT / "Cargo.toml"),
                            "-j1",
                            "--message-format=json-render-diagnostics",
                            "-p",
                            row["package"],
                            "--features",
                            features,
                            "--lib",
                            row["exact_selector"],
                            "--",
                            "--exact",
                            "--nocapture",
                            "--test-threads=1",
                        ],
                    )
                )
            lint = next(
                copy.deepcopy(row)
                for row in json.loads((OLD / "build-intent-v1.json").read_bytes())["commands"]
                if row["role"] == "lint"
            )
            lint["name"] = "node-publication-affected-Clippy"
            if "--keep-going" not in lint["argv"]:
                lint["argv"].insert(2, "--keep-going")
            commands.append(lint)
        release = copy.deepcopy(old["commands"][0])
        assert release["role"] == "build"
        release["name"] = "node-publication-genuine-release"
        commands.append(release)
        spec = copy.deepcopy(old)
        for key in ("admission", "intent_sha256"):
            spec.pop(key, None)
        spec.update(
            output=str(OUT / f"operation-{stage}"),
            support=support,
            source_adoption=adoption_ref,
            target_handover=handover,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / f"private-image-{stage}/quoridor-runner"),
            TMP=str(OUT / f"build-TMP-{stage}"),
            test_cpu_cores=[12, 14, 16],
            command_timeout_seconds=args.seconds,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        marker.write_text(
            json.dumps(
                dict(writer=WRITER, target=str(target), support_sha256=support["sha256"]), indent=2
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            f"build-admission-{stage}.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Actual source and ordinary software bindings; runtime fresh controls still mandatory.",
            ),
        )
        intent = save(f"build-intent-{stage}.json", spec)
        helper = (
            OLD / "run_prefix_checks.py"
            if stage == "prefix"
            else OUT / "run_remaining_checks.py"
            if stage == "remaining"
            else ROOT / "scripts/dev/research-lifecycle.py"
        )
        argv = [str(lc.project_python()), "-B", str(helper)]
        if stage == "release":
            argv.append("build")
        argv += ["--intent", intent["path"], "--sha256", intent["sha256"]]
        save(
            f"job-{stage}.json",
            dict(
                issue="quoridor-4lc.324",
                goal_issue="quoridor-4lc.324",
                thread_id="01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                cwd=str(ROOT),
                argv=argv,
                end_at=None,
                notify_until=None,
                max_runtime_seconds=args.seconds + 60,
                control_interval_seconds=30,
                notify_interval_seconds=10,
                request_timeout_seconds=25,
                log_max_bytes=16384,
                resource_contract=support["path"],
            ),
        )
        print(json.dumps(dict(intent=intent, stage=stage, actual_job=None, source_leases=[])))


if __name__ == "__main__":
    main()
