"""Retire stopped release metadata to fit the observed debug rebuild demand."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import stat

from quoridor_training import cycle_process as process

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
TARGET = (
    ROOT
    / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/target"
)
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def checked(path, digest, size):
    actual = ref(path)
    assert (actual["sha256"], actual["bytes"], actual["mode"]) == (digest, size, "0644")
    return json.loads(path.read_bytes())


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def item(path):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and not path.is_symlink()
    return dict(
        path=str(path),
        device=value.st_dev,
        inode=value.st_ino,
        bytes=value.st_size,
        allocated_B=value.st_blocks * 512,
        links=value.st_nlink,
        mtime_ns=value.st_mtime_ns,
        mode=value.st_mode,
    )


def main():
    basis_path = (
        ROOT
        / ".artifacts/research-team/integration324/completed22-23-integration-v1/completion-and-retention.json"
    )
    basis = checked(
        basis_path, "b9d5f094a1d07f6b5bd96d26b2cbfbf0d71de9ce35cc0cc2c7374e05b0fcff7e", 4967
    )
    cover = basis["history_whole_settlement"]["known_cover_after_settlement_B"]
    old_stop_path = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-v1/software-v1/collection-v1/completion-and-STOP.json"
    )
    old_stop = json.loads(old_stop_path.read_bytes())
    fresh = []
    for row in old_stop["known_command_fresh_absence"]:
        original = row["original"]
        current = process.identity(process.process_info(original["pid"]))
        assert current != process.identity(original)
        fresh.append(dict(original=original, fresh=current))
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        marker_path = TARGET / ".research-owner.json"
        marker = ref(marker_path)
        owner = json.loads(marker_path.read_bytes())
        assert owner["writer"] == WRITER and owner["target"] == str(TARGET)
        candidates = []
        for suffix in ("*.rlib", "*.rmeta"):
            for path in sorted((TARGET / "release").rglob(suffix)):
                value = item(path)
                if value["links"] == 1:
                    candidates.append(value)
        # The previous affected debug rebuild used 375,336,960B. Current head
        # is 275,841,024B before ordinary tails: this is a concrete shortage.
        demand = 375336960
        margin = 64 * 1024**2
        needed = max(0, demand + margin - (50000000000 - cover))
        selected = []
        for value in sorted(candidates, key=lambda x: x["allocated_B"], reverse=True):
            if sum(row["allocated_B"] for row in selected) >= needed:
                break
            selected.append(value)
        assert sum(row["allocated_B"] for row in selected) >= needed
        intent = save(
            "intent.json",
            dict(
                at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                basis=ref(basis_path),
                target_marker=marker,
                actual_stopped_software=ref(old_stop_path),
                fresh_known_compilers=fresh,
                known_cover_before_B=cover,
                observed_prior_debug_rebuild_B=demand,
                ordinary_tail_margin_B=margin,
                required_reconstructible_retirement_B=needed,
                selected=selected,
                restoration="Preserved Cargo/source/Git/toolchain/env and old build-intent-v7.json; regenerate only for new software, not replaying old tests.",
                recipe=ref(old_stop_path.parent.parent / "build-intent-v7.json"),
                preserved="All executables/shared libraries/private images/models/Git/RAW/FAILED/logs/unique evidence/debug cache",
                scope="Stopped release .rlib/.rmeta only, no native or Cargo lifetime active; no global walk or scientific refund/loan.",
            ),
        )
        removed = []
        failure = None
        try:
            for value in selected:
                path = Path(value["path"])
                assert item(path) == value
                path.unlink()
                removed.append(value)
        except BaseException as error:
            failure = dict(type=type(error).__name__, message=str(error))
            raise
        finally:
            reclaimed = sum(row["allocated_B"] for row in removed)
            assert ref(marker_path) == marker
            result = save(
                "return.json",
                dict(
                    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    status="COMPLETE" if failure is None else "FAILED_PARTIAL_PRESERVED",
                    failure=failure,
                    intent=intent,
                    actual_unlinked_paths=[row["path"] for row in removed],
                    actual_unique_allocated_B_removed_once=reclaimed,
                    known_cover_after_B=cover - reclaimed,
                    head_to_decimal50GB_B=50000000000 - cover + reclaimed,
                    old_credit_reapplied=0,
                    scientific_refund_lending_reset=0,
                    source_leases=[],
                    later_tails_globalactual_fullfees="UNKNOWN",
                    host_future_quiet=False,
                ),
            )
            print(json.dumps(dict(result=result, removed_B=reclaimed)))


if __name__ == "__main__":
    main()
