"""Issue the authorized new64 phase after the original new208 actual STOP."""

import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

from quoridor_training import cycle_process as process

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-lazy-smp-node-publication-v1"
MIB = 1024**2


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def checked(path, digest, size):
    value = ref(path)
    assert (value["sha256"], value["bytes"], value["mode"]) == (digest, size, "0644")
    return json.loads(path.read_bytes())


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(OUT / name)


def item(path):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and not path.is_symlink()
    return dict(
        path=str(path),
        device=value.st_dev,
        inode=value.st_ino,
        bytes=value.st_size,
        allocated_B=value.st_blocks * 512,
        links=value.st_nlink,
        mtime_ns=value.st_mtime_ns,
        mode=value.st_mode,
    )


def main():
    analysis = OWN / "numeric-v1/analysis-v1"
    completion = checked(
        analysis / "completion.json",
        "0f4f5653eb43824dec0f8fd9abfb80966b7cf6671280a73276bf32cf6fc70523",
        3518,
    )
    stop = checked(
        analysis / "native-collection-analysis-STOP.json",
        "72f8783f45ca5d008587de6080db0de392683554c238cdd51603bc6501ad589e",
        6652,
    )
    holding = checked(
        analysis / "actual-retained-roots.json",
        "f608117197b0f90916dc76dcb40fe256410a74b8934fb90a7d3e40f4974f2500",
        642,
    )
    protocol_path = OWN / "finite-preparation-v2/protocol.json"
    protocol = checked(
        protocol_path, "c99be688bf30db8a5c1131b36ddafee628d17af6618d60d86f928b1971a94414", 24845
    )
    assert "NEW24_GATE_PASS_SUPPORT_UNISSUED_NO_GAMES" in json.dumps(completion)
    assert (
        not stop["source_leases_remaining"]
        and not stop["native_jobs_remaining"]
        and not stop["TMP_remaining"]
    )
    software_path = BASE / "software-v1/collection-v1/completion-and-STOP.json"
    software = json.loads(software_path.read_bytes())
    fresh = []
    originals = [x["original"] for x in software["known_command_fresh_absence"]]
    originals += [x["expected"] for x in stop["known_exact_identities_fresh_absent_or_different"]]
    for original in originals:
        now = process.identity(process.process_info(original["pid"]))
        assert now != process.identity(original)
        fresh.append(dict(original=original, fresh=now))
    target = (
        ROOT
        / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/target"
    )
    point_path = BASE / "software-v1/collection-v1/affected-target-and-image-once.json"
    point = json.loads(point_path.read_bytes())
    known_without_24 = software["current_known_cover_B"]
    assert known_without_24 == 49762513920
    whole = 288 * MIB
    shortage = max(0, known_without_24 + whole - 50000000000)
    needed = shortage + 32 * MIB
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        marker_path = target / ".research-owner.json"
        marker = ref(marker_path)
        owner = json.loads(marker_path.read_bytes())
        assert owner["writer"] == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13" and owner[
            "target"
        ] == str(target)
        selected = []
        for profile in point["target_profiles"]:
            if Path(profile["path"]) != target / "release":
                continue
            for row in sorted(profile["files"], key=lambda x: x["allocated_B"], reverse=True):
                path = Path(row["path"])
                if path.suffix not in (".rlib", ".rmeta") or row["links"] != 1:
                    continue
                if sum(x["allocated_B"] for x in selected) >= needed:
                    break
                assert item(path) == row
                selected.append(row)
        assert sum(x["allocated_B"] for x in selected) >= needed
        intent = save(
            "cache-retirement-intent.json",
            dict(
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                concrete_shortage_B=shortage,
                ordinary_tail_margin_B=32 * MIB,
                existing_affected_point=ref(point_path),
                target_marker=marker,
                actual_STOP=ref(analysis / "native-collection-analysis-STOP.json"),
                fresh_known_ids=fresh,
                selected=selected,
                preservation="All images/executables/libraries/models/Git/RAW/FAILED/logs/unique evidence retained; selected stopped rebuildable release rlib/rmeta only. No global walk, scientific refund, old credit or quota lending.",
            ),
        )
        removed = []
        try:
            for row in selected:
                path = Path(row["path"])
                assert item(path) == row
                path.unlink()
                removed.append(row)
        finally:
            reclaimed = sum(x["allocated_B"] for x in removed)
            retirement = save(
                "cache-retirement-return.json",
                dict(
                    intent=intent,
                    selected_count=len(selected),
                    removed_count=len(removed),
                    actual_allocated_B_removed_once=reclaimed,
                    all_selected_removed=len(selected) == len(removed),
                    source_leases=[],
                    host_future_quiet=False,
                ),
            )
        assert len(selected) == len(removed) and ref(marker_path) == marker
        for caller in software["current_callers"]:
            assert ref(Path(caller["path"])) == caller
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_NEW24_INITIAL64_SOURCE_SOFTWARE_RELEASE",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=subprocess.check_output(
                    ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
                ).strip(),
                current_four_callers=software["current_callers"],
                software_manifest=software["software_manifest"],
                artifact=software["artifact"],
                actual_software_STOP=ref(software_path),
                actual_native_collection_analysis_STOP=ref(
                    analysis / "native-collection-analysis-STOP.json"
                ),
                software_bridge="Subsequent docs-only commit; compiled Rust and actual four callers unchanged. No rebuild or successful test replay.",
                actual_EX_NB_acquired_released=True,
                source_leases_remaining=[],
                numerical_scope="Inherited641ca structural only; actual canonical normal join and fresh lifetime admission mandatory",
                evaluation="NEW64_UNENTERED",
                host_future_quiet=False,
            ),
        )
        fcntl.flock(lock, fcntl.LOCK_UN)
    roots = [str(OWN), str(BASE / "normal208-entry-v1"), str(OUT)]
    old_actual = 37294080
    assert old_actual in holding.values() or str(old_actual) in json.dumps(holding)
    # Replace the ended timing whole with this one whole containing that data.
    # This is not old science quota reuse or a second charge of existing roots.
    future = 220 * MIB
    margin = whole - old_actual - future
    assert margin >= 16 * MIB
    known_after = known_without_24 - reclaimed + whole
    assert known_after <= 50000000000 - 32 * MIB
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize > future
    capacity = save(
        "capacity-and-holding.json",
        dict(
            roots=roots,
            ended_two_root_point=ref(analysis / "actual-retained-roots.json"),
            ended_allocated_B_once=old_actual,
            previous_timing_whole_B=192 * MIB,
            new_whole_B=whole,
            conservative_future_B=future,
            planning_margin_B=margin,
            known_cover_without_24_B=known_without_24,
            actual_cache_retirement=retirement,
            actual_retired_B_once=reclaimed,
            new_known_cover_B=known_after,
            remaining_to_decimal50GB_B=50000000000 - known_after,
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            settlement="One replacement 288MiB whole includes ended OWN24+208 controls and new64 controls/data. No actual holding plus whole double-charge; no refund/lending/reset/old22 quota activation.",
            later_tails_globalactual_fees="UNKNOWN",
        ),
    )
    support = save(
        "phase-support.json",
        dict(
            issue="quoridor-4lc.324.24",
            status="ISSUED_NEW24_INITIAL64_TWO_SERIAL_RUNS_ONE_WHOLE",
            fixed_protocol=ref(protocol_path),
            game_contract=protocol["initial64"],
            gate_completion=ref(analysis / "completion.json"),
            actual_source_STOP=release,
            current_source_adoption=release,
            actual_software_STOP=ref(software_path),
            whole_B=whole,
            owned_B=whole,
            free_B=margin,
            roots=roots,
            storage_budget=dict(whole_B=whole, roots=roots),
            capacity_basis=capacity,
            resources=dict(
                search_cpu_cores=[12, 14],
                total_search_threads=2,
                worker_cpu=12,
                main_guardian=0,
                outer_guardian=18,
                launch_affinity=[0, 12, 14, 18],
                family_B=4 * 1024**3,
                controller_B=1536 * MIB,
                native_B=2560 * MIB,
                host_reserve_B=4 * 1024**3,
                GPU=0,
                threads=1,
                CPU=3,
                controller_included=True,
                family_RAM_B=4 * 1024**3,
                controller_RAM_B=1536 * MIB,
            ),
            limits=dict(
                worker_cpu=12,
                guardian_cpu=0,
                family_B=4 * 1024**3,
                controller_B=1536 * MIB,
                host_reserve_B=4 * 1024**3,
                owned_B=whole,
                free_B=margin,
                log_B=MIB,
            ),
            games=64,
            families=32,
            serial_runs=2,
            games_per_RUN=32,
            nonfungible_nodes_each_RUN=250000000,
            total_nodes=500000000,
            per_move_allworker_nodes=1000000,
            TOTAL_TT_entries=1048576,
            game_concurrency=1,
            RUN_timeout_s=900,
            parent_accepted_s=2400,
            parent_command_s=2340,
            cleanup_margin_s=60,
            readonly_images_models_copy_B=0,
            native_aggregate_B_each=80 * MIB,
            native_record_B_each=MIB,
            journal_B_each=33554464,
            archive_B_each=33575013,
            perf_RAW_B=0,
            allocation="One serial game uses up to physical12,14 with SMT13,15 unused; N1 uses12 and N2 uses12,14, never concurrent games. Main0 and outer18; no idle/future lease.",
            normal_remaining_inputs="Actual maintained arena factory/Plan/config/numerical_fields/full current source/model/input/library correspondence; fresh CPU peer/RAM/host4/whole/free/origin/ownerpausecancel/deadline/cleanup at entry. RPC not nativeSTART.",
            hold="Main/current callers/libs/env/Cargo/substantial IO frozen through actual native+normalcollectionSTOP; light independent source allowed.",
            old22_DORMANT64="UNISSUED_UNCHANGED",
            science_refund_lending_reset=0,
            pauses_seals_models_defaults_foreign_FAILED_UNKNOWN="PRESERVED",
        ),
    )
    issued = save(
        "issued-inputs.json",
        dict(
            release=release,
            phase_support=support,
            capacity=capacity,
            source_leases=[],
            evaluation="NEW24_INITIAL64_UNENTERED",
        ),
    )
    print(
        json.dumps(
            dict(
                issued=issued,
                support=support,
                reclaimed_B=reclaimed,
                head_B=50000000000 - known_after,
            )
        )
    )


if __name__ == "__main__":
    main()
