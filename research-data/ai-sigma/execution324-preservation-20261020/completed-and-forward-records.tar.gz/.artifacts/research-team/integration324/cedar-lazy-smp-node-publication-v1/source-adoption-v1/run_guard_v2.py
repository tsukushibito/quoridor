"""Run the reviewed source adoption with the existing bounded child owner."""

import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import CycleResources, execute, identity, process_info

out = Path(__file__).resolve().parent
temporary = out / "TMP-v2"
temporary.mkdir()
deadline = time.monotonic() + 120
config = {"max_memory_bytes": 1024**3 - 64 * 1024**2, "host_ram_reserve": 4 * 1024**3}
resources = CycleResources(config, out, deadline)
environment = dict(os.environ, TMPDIR=str(temporary), CUDA_VISIBLE_DEVICES="")
try:
    result = execute(
        [
            sys.executable,
            "-B",
            str(out / "adopt_sources.py"),
            "--minimum",
            "/workspaces/quoridor/.worktree/assets/perf/cedar-lazy-smp-node-publication-review-v1/related-repr-v1/minimum-result.json",
            "--sha256",
            "26ae8ef6b20002fb675b6c5d28256c0d48406e1835e3e144665054aa8cf4fad1",
            "--bytes",
            "1166",
        ],
        out / "execution-v2.log",
        deadline,
        cpu_core=0,
        resources=resources,
        cwd="/workspaces/quoridor",
        env=environment,
    )
    assert result["exit_code"] == 0 and result["cleanup_complete"]
    assert identity(process_info(result["child"]["pid"])) != result["child"]
    temporary.rmdir()
    with (out / "guard-return-v2.json").open("x") as stream:
        json.dump(
            {"actual_return": result, "TMP": [], "source_leases": [], "host_future_quiet": False},
            stream,
            indent=2,
        )
        stream.write("\n")
    print(
        json.dumps(
            {
                "exit_code": result["exit_code"],
                "seconds": result["wall_seconds"],
                "cleanup": result["cleanup_complete"],
            }
        )
    )
finally:
    if temporary.exists() and not any(temporary.iterdir()):
        temporary.rmdir()
