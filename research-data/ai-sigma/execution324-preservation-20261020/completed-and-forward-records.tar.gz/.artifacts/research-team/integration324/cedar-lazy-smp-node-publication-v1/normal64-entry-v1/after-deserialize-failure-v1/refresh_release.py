"""Refresh normal source bindings after the unentered native metadata failure."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

from quoridor_training import cycle_process as process

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
ENTRY = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-lazy-smp-node-publication-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def checked(path, digest, size):
    actual = ref(path)
    assert (actual["sha256"], actual["bytes"], actual["mode"]) == (digest, size, "0644")
    return json.loads(path.read_bytes())


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(OUT / name)


def main():
    failure_root = OWN / "numeric-games-v1/failure-collection-v1"
    summary = checked(
        failure_root / "summary.json",
        "807ad83bd9e4278ffb6e11c9111d57fda42ec13e2f32440b4450ba3096396645",
        1177,
    )
    stop_path = failure_root / "native-and-normal-collection-STOP.json"
    stop = checked(
        stop_path, "48b97bf7506424fa07db5ed76955f96f9dab66cb3376f3f2e964253edb6a8540", 3115
    )
    assert (
        summary["all64_scientifically_unentered"]
        and summary["Search_model_games_nodes"] == 0
        and summary["CI_executions"] == 0
    )
    assert not stop["source_leases_remaining"] and not stop["native_jobs_remaining"]
    fresh = []
    for row in stop["known_exact_identities_fresh_absent_or_different"]:
        expected = row["expected"]
        current = process.identity(process.process_info(expected["pid"]))
        assert current != process.identity(expected)
        fresh.append(dict(expected=expected, fresh=current))
    original_release = checked(
        ENTRY / "current-source-and-software-release.json",
        "9f3414ce3c6fc73ce0e7ccb9fe1c95824cdb80a241ac41fca55e1a1c079e8e9b",
        2713,
    )
    support = checked(
        ENTRY / "phase-support.json",
        "8897d138fd83b1e3b6bf076cfd5e6daa1e37e33141348bf861fb429036483898",
        7015,
    )
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for caller in original_release["current_four_callers"]:
            assert ref(Path(caller["path"])) == caller
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        assert commit == original_release["current_commit"]
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_SAME_NEW24_INITIAL64_CURRENT_BINDINGS_AFTER_METADATA_FAILURE",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=commit,
                current_four_callers=original_release["current_four_callers"],
                software_manifest=original_release["software_manifest"],
                artifact=original_release["artifact"],
                actual_software_STOP=original_release["actual_software_STOP"],
                actual_native_collection_STOP=ref(stop_path),
                failure_summary=ref(failure_root / "summary.json"),
                fresh_known_identities=fresh,
                source_SH_NB_acquired_released=True,
                source_leases_remaining=[],
                numerical_scope="Inherited641ca structural only; actual normal metadata/current source/environment/origin/resources admission still mandatory",
                same_image_conditions_inputs_seed_quota=True,
                future_host_quiet=False,
                original_failure_cleanup_masks="CandidateFALSE versus persistedTRUE/guardianNULL/captureFALSE/dataFAILED/missing32 preserved; no success inferred",
                science="All64 games/Search/model/nodes unentered; no CI, no quota debit reset/refund/lending",
            ),
        )
        fcntl.flock(lock, fcntl.LOCK_UN)
    original_support = ref(ENTRY / "phase-support.json")
    support.update(
        status="SAME_ISSUED_NEW24_INITIAL64_CONTINUATION_AFTER_UNENTERED_METADATA_FAILURE",
        original_issued_support=original_support,
        actual_source_STOP=release,
        current_source_adoption=release,
        previous_failed_attempt_STOP=ref(stop_path),
        new_storage_or_science_grant=False,
        source_current_refs_refreshed_only=True,
    )
    refreshed_support = save("phase-support.json", support)
    issued = save(
        "issued-inputs.json",
        dict(
            release=release,
            phase_support=refreshed_support,
            capacity=ref(ENTRY / "capacity-and-holding.json"),
            original_issued_inputs=ref(ENTRY / "issued-inputs.json"),
            unchanged_whole_B=301989888,
            no_new_roots=True,
            original_FAILED_immutable=True,
            source_leases=[],
            instruction="Only candidate_pool_size metadata correction in fresh OWN namespace, actual normal admission required. If corrected original64 already submitted, do not duplicate/cancel/rebind; this later fact is not retroactive admission evidence.",
            evaluation="Corrected64 actual admission/execution UNKNOWN to Root; no observer",
        ),
    )
    print(json.dumps(dict(issued=issued, support=refreshed_support, release=release)))


if __name__ == "__main__":
    main()
