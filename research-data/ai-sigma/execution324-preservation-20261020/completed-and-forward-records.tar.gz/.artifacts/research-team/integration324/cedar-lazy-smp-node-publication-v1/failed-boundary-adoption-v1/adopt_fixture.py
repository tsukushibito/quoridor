"""Adopt only the failed same-key history fixture prefix correction."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-lazy-smp-node-publication-v1/same-key-fixture-repair-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def checked(value):
    path = Path(value["path"])
    assert ref(path) == value
    return path.read_bytes()


def git(*args):
    return subprocess.run(
        ["git", *args], cwd=ROOT, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ).stdout


def main():
    binding_ref = dict(
        path=str(OWN / "fixed-binding.json"),
        sha256="8824c72eefff09bf762346942da8851e18ae60c404bf2822e5b4f67c97756b42",
        bytes=4624,
        mode="0644",
    )
    binding = json.loads(checked(binding_ref))
    stop_ref = dict(
        path=str(OWN / "helper-STOP.json"),
        sha256="2fd59a7fee449110d214f618a1534fc37927a36a0459f498ab64f233745a2722",
        bytes=2478,
        mode="0644",
    )
    checked(stop_ref)
    assert (
        binding["unchanged_production_and_outside_owner_bytes"]
        and binding["unchanged_all_original_assertions_and_injection_peer_repetition_bodies"]
    )
    before = checked(binding["before"])
    post = checked(binding["post"])
    delimiter = (
        b"    fn completed_child_publication_survives_interrupted_parent_but_never_publishes_it()"
    )
    old_prefix, old_tail = before.split(delimiter)
    new_prefix, new_tail = post.split(delimiter)
    assert old_prefix == new_prefix
    old_owner, old_suffix = old_tail.split(b"    #[test]", 1)
    new_owner, new_suffix = new_tail.split(b"    #[test]", 1)
    assert old_suffix == new_suffix
    assert old_owner.count(b"assert") == new_owner.count(b"assert")
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert git("diff", "--cached", "--name-only") == b""
        path = ROOT / binding["subject"]
        assert path.read_bytes() == before
        actual_before = ref(path)
        path.write_bytes(post)
        assert {k: ref(path)[k] for k in ["sha256", "bytes", "mode"]} == {
            k: binding["post"][k] for k in ["sha256", "bytes", "mode"]
        }
        git("diff", "--check")
        git("add", "--", binding["subject"])
        assert git("diff", "--cached", "--name-only").decode().splitlines() == [binding["subject"]]
        git("commit", "-m", "Correct equal-ply distinct-history SMP publication fixture")
        result = dict(
            at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            status="ADOPTED_FAILED_FIXTURE_ONLY",
            issue="quoridor-4lc.324.24",
            binding=binding_ref,
            actual_source_STOP=stop_ref,
            actual_before=actual_before,
            actual_post=ref(path),
            commit=git("rev-parse", "HEAD").decode().strip(),
            production_and_successful_test_bodies_unchanged=True,
            old_Rust2_Python1="PASS_RETAINED_NO_REPLAY",
            repaired_and_remaining="UNRUN",
            source_leases=[],
            host_future_quiet=False,
        )
        with (OUT / "actual-repair.json").open("x") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
        print(json.dumps(dict(status=result["status"], commit=result["commit"])))


if __name__ == "__main__":
    main()
