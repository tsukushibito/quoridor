"""Collect actual new checks and retire only stopped rebuildable debug metadata."""

import datetime
import fcntl
import hashlib
import json
import math
from pathlib import Path
import stat

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOFTWARE = OUT.parent


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def snapshot(roots):
    seen = set()
    files = []
    allocated = logical = entries = 0
    pending = list(roots)
    while pending:
        path = pending.pop()
        info = path.lstat()
        key = (info.st_dev, info.st_ino)
        if key in seen:
            continue
        seen.add(key)
        allocated += info.st_blocks * 512
        logical += info.st_size
        entries += 1
        if stat.S_ISDIR(info.st_mode):
            pending.extend(path.iterdir())
        elif stat.S_ISREG(info.st_mode):
            files.append(
                dict(
                    path=str(path),
                    device=info.st_dev,
                    inode=info.st_ino,
                    bytes=info.st_size,
                    allocated_B=info.st_blocks * 512,
                    links=info.st_nlink,
                    mtime_ns=info.st_mtime_ns,
                    mode=info.st_mode,
                )
            )
    return dict(allocated_B=allocated, logical_B=logical, entries=entries, files=files)


def main():
    outer_path = SOFTWARE / "check-runtime-v2/result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((outer_path.parent / "state.json").read_bytes())
    receipt_path = SOFTWARE / "operation-remaining/prefix-result.json"
    receipt = json.loads(receipt_path.read_bytes())
    assert outer["job_id"] == receipt["origin_job_id"] == "c6c2668a-dcdc-49dc-a100-c05e1f95e235"
    assert (
        outer["outcome"] == "succeeded"
        and outer["exit_code"] == 0
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and not outer["remaining"]
    )
    assert (
        receipt["status"] == "PASS_TEST_LINT_PREFIX_ONLY"
        and receipt["cleanup_complete"]
        and receipt["primary"] is None
        and not receipt["release_executed"]
    )
    assert len(receipt["checks"]) == 4
    known = []
    for row in receipt["checks"]:
        actual = row["guardian_return"]
        assert (
            row["status"] == "PASS"
            and row["capture_complete"]
            and row["cargo"]["warning_count"] == 0
            and actual["exit_code"] == 0
            and actual["cleanup_complete"]
            and actual["direct_child_reaped"]
            and actual["handle_closes_complete"]
            and not actual["remaining"]
        )
        current = identity(process_info(actual["child"]["pid"]))
        assert current != actual["child"]
        known.append(dict(name=row["name"], original=actual["child"], fresh=current))
    for name in ["child", "supervisor"]:
        original = state[name]
        current = identity(process_info(original["pid"]))
        assert current != original
        known.append(dict(name=name, original=original, fresh=current))
    spec = json.loads((SOFTWARE / "build-intent-remaining.json").read_bytes())
    assert not Path(spec["TMP"]).exists() and not Path(spec["private"]).exists()
    previous_path = SOFTWARE / "first-prefix-failure-collection-v1/completion-and-STOP.json"
    previous = json.loads(previous_path.read_bytes())
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        target = Path(spec["target"])
        marker_path = target / ".research-owner.json"
        marker = ref(marker_path)
        owner = json.loads(marker_path.read_bytes())
        assert owner["writer"] == spec["writer"] and owner["target"] == str(target)
        roots = [
            target / "debug",
            target / "release",
            ROOT
            / ".artifacts/research-team/integration324/cedar-lazy-smp-v1/software-v1/private-image-v7",
        ]
        point_path = OUT / "affected-target-and-retained-image-once.json"
        if point_path.exists():
            affected = ref(point_path)
            saved = json.loads(point_path.read_bytes())
            assert saved["roots"] == [str(p) for p in roots]
            actual = saved["point"]
        else:
            actual = snapshot(roots)
            affected = save(
                "affected-target-and-retained-image-once.json",
                dict(
                    roots=[str(p) for p in roots],
                    point=actual,
                    scope="One directed ended target/image union, replacing prior group once; no global/source/model/science walk.",
                ),
            )
        cover = (
            previous["current_known_cover_B"]
            + actual["allocated_B"]
            - previous["current_target_and_retained_image_B"]
        )
        # Actual removed release caches must regenerate for the genuine new
        # release. Include the concrete later192MiB forecast, without issuing it.
        release_demand = (
            json.loads((SOFTWARE / "release-cache-retirement-v1/return.json").read_bytes())[
                "actual_unique_allocated_B_removed_once"
            ]
            + 12 * 1024**2
        )
        next_whole = 192 * 1024**2
        needed = max(0, cover + release_demand + next_whole + 32 * 1024**2 - 50000000000)
        eligible = [
            r
            for r in actual["files"]
            if Path(r["path"]).is_relative_to(target / "debug")
            and Path(r["path"]).suffix in {".rlib", ".rmeta"}
            and r["links"] == 1
        ]
        selected = []
        for row in sorted(eligible, key=lambda r: r["allocated_B"], reverse=True):
            if sum(r["allocated_B"] for r in selected) >= needed:
                break
            selected.append(row)
        assert sum(r["allocated_B"] for r in selected) >= needed
        intent = save(
            "cache-intent.json",
            dict(
                source_point=affected,
                marker=marker,
                known_cover_before_B=cover,
                observed_release_cache_regeneration_and_newimage_B=release_demand,
                future_timing_whole_UNISSUED_B=next_whole,
                ordinary_tail_margin_B=32 * 1024**2,
                needed_B=needed,
                selected=selected,
                restore=ref(SOFTWARE / "build-intent-remaining.json"),
                scope="Only stopped unused debug rlib/rmeta; no executable/so/privateimage/models/Git/RAW/FAILED/unique evidence removed. Future debug compile regeneration costs remain real.",
            ),
        )
        removed = []
        failure = None
        try:
            for row in selected:
                path = Path(row["path"])
                value = path.lstat()
                assert not path.is_symlink() and (
                    value.st_dev,
                    value.st_ino,
                    value.st_nlink,
                    value.st_size,
                    value.st_mtime_ns,
                ) == (row["device"], row["inode"], 1, row["bytes"], row["mtime_ns"])
                path.unlink()
                removed.append(row)
        except BaseException as error:
            failure = dict(type=type(error).__name__, message=str(error))
            raise
        finally:
            reclaimed = sum(r["allocated_B"] for r in removed)
            save(
                "cache-return.json",
                dict(
                    status="COMPLETE" if failure is None else "FAILED_PARTIAL_PRESERVED",
                    intent=intent,
                    failure=failure,
                    actually_removed_once_B=reclaimed,
                    paths=[r["path"] for r in removed],
                    known_cover_after_B=cover - reclaimed,
                    old_credit_reapplied=0,
                    science_refund_lending_reset=0,
                    later_tails_globalactual_fullfees="UNKNOWN",
                ),
            )
        assert ref(marker_path) == marker
    result = save(
        "completion-and-STOP.json",
        dict(
            at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            status="NEW_RUST5_PYTHON1_AFFECTED_CLIPPY_PASS_GENUINE_RELEASE_UNENTERED",
            actual_outer=ref(outer_path),
            actual_prefix=ref(receipt_path),
            retained_Rust2=previous["candidate"],
            retained_Python1=ref(SOFTWARE / "new-Python-one-STOP.json"),
            checks=[
                dict(name=r["name"], status=r["status"], warning_count=r["cargo"]["warning_count"])
                for r in receipt["checks"]
            ],
            known_fresh_absence=known,
            actual_affected_point=affected,
            cache_retirement=ref(OUT / "cache-return.json"),
            current_known_cover_B=cover - reclaimed,
            current_target_and_retained_image_B=actual["allocated_B"] - reclaimed,
            remaining_to_decimal50GB_B=50000000000 - cover + reclaimed,
            outer_seconds_once=outer["wall_seconds"],
            accepted_inclusive_seconds_once=(
                datetime.datetime.fromisoformat(outer["finished_at"])
                - datetime.datetime.fromisoformat(state["created_at"])
            ).total_seconds(),
            nested_added=0,
            software_command_remaining_s=2378 - math.ceil(outer["wall_seconds"]),
            remaining_owned=[],
            TMP=[],
            source_leases=[],
            release_executed=False,
            old_success_replay=0,
            host_future_quiet=False,
            later_tails_globalactual_fullfees="UNKNOWN",
        ),
    )
    print(
        json.dumps(
            dict(
                completion=result,
                cache_removed_B=reclaimed,
                current_known_cover_B=cover - reclaimed,
            )
        )
    )


if __name__ == "__main__":
    main()
