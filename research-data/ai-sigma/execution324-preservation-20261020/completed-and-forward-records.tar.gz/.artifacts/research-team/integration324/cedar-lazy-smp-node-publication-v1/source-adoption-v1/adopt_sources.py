"""Apply the fixed reviewed sparse node-publication owners at an actual writer boundary."""

import argparse
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-lazy-smp-node-publication-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def checked(value):
    path = Path(value["path"])
    assert ref(path) == value
    return path.read_bytes()


def git(*args):
    return subprocess.run(
        ["git", *args], cwd=ROOT, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ).stdout


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--minimum", required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--bytes", type=int, required=True)
    args = parser.parse_args()
    verdict_ref = dict(path=args.minimum, sha256=args.sha256, bytes=args.bytes, mode="0644")
    verdict = json.loads(checked(verdict_ref))
    assert (
        verdict["status"] == "SOURCE_CLEAR"
        and verdict["essential"] == 0
        and verdict["ordinary"] == 0
    )
    reader_stop = dict(
        path=str(
            ROOT
            / ".worktree/assets/perf/cedar-lazy-smp-node-publication-review-v1/related-repr-v1/reader-STOP.json"
        ),
        sha256="3cd4dc9ff9bba894f1b3cc8e4731888ee477ef0935d0ea46b19d13f435ec8ee2",
        bytes=3363,
        mode="0644",
    )
    checked(reader_stop)
    binding_ref = dict(
        path=str(OWN / "repr-repair-v1/fixed-binding.json"),
        sha256="af9426a74cbf6a23f65dc656a9a9c90001b7ae6b2ee46cebfa517b332587f5f3",
        bytes=9327,
        mode="0644",
    )
    binding = json.loads(checked(binding_ref))
    assert verdict["fixed_binding"] == binding_ref
    checked(
        dict(
            path=str(OWN / "repr-repair-v1/helper-STOP.json"),
            sha256="87d6d4f20b86bc892eb2c56d77be338c459640407a98b2644e18d4509b43d62c",
            bytes=2460,
            mode="0644",
        )
    )
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert git("diff", "--cached", "--name-only") == b""
        subjects = []
        for row in binding["changed"]:
            current = ref(ROOT / row["subject"])
            assert {k: current[k] for k in ("sha256", "bytes", "mode")} == {
                k: row["before"][k] for k in ("sha256", "bytes", "mode")
            }
            checked(row["post"])
            subjects.append(dict(subject=row["subject"], before=current, post=row["post"]))
        original_commit = git("rev-parse", "HEAD").decode().strip()
        written = []
        try:
            for row in subjects:
                path = ROOT / row["subject"]
                path.write_bytes(checked(row["post"]))
                path.chmod(int(row["post"]["mode"], 8))
                written.append(row)
            git("diff", "--check")
            for row in subjects:
                current = ref(ROOT / row["subject"])
                assert {k: current[k] for k in ("sha256", "bytes", "mode")} == {
                    k: row["post"][k] for k in ("sha256", "bytes", "mode")
                }
                row["actual_current"] = current
            git("add", "--", *[row["subject"] for row in subjects])
            assert set(git("diff", "--cached", "--name-only").decode().splitlines()) == {
                row["subject"] for row in subjects
            }
            git(
                "commit",
                "-m",
                "Share coherent completed SMP node bounds without root epoch publication",
            )
        except BaseException:
            with (OUT / "failed-adoption.json").open("x") as stream:
                json.dump(
                    dict(
                        written=[row["subject"] for row in written],
                        original_commit=original_commit,
                        reason="Partial adoption preserved; no force/reset/foreign mutation",
                    ),
                    stream,
                    indent=2,
                )
            raise
        result = dict(
            at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            status="ACCEPTED_FIXED_SOURCE_ONLY_SOFTWARE_PENDING",
            issue="quoridor-4lc.324.24",
            fixed_binding=binding_ref,
            source_review=verdict_ref,
            actual_reader_STOP=reader_stop,
            subjects=subjects,
            original_commit=original_commit,
            commit=git("rev-parse", "HEAD").decode().strip(),
            format="Author exact fixed formatted post-v7 alpha plus unchanged formatted post-v6 six owners; all actual Main subjects exactly match, no broad formatter/proof/test replay",
            software="NEW_AI4_RUNNER1_PYTHON1_CLIPPY_RELEASE_PENDING",
            old22_23_outcomes="UNCHANGED",
            source_leases=[],
            host_future_quiet=False,
        )
        with (OUT / "actual-adoption.json").open("x") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
        print(
            json.dumps(
                dict(status=result["status"], commit=result["commit"], subjects=len(subjects))
            )
        )


if __name__ == "__main__":
    main()
