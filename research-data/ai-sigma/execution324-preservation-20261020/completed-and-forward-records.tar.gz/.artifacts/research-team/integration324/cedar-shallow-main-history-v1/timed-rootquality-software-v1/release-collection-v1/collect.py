"""Collect the one genuine release through normal finalize and ended-source custody."""

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    loader = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


def main():
    helpers = load(
        "saved_metadata_helpers",
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-v1/software-v1/collect_second_failure_once.py",
    )
    lc = load("actual_release_collection", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helpers.ref
    runtime = BASE / "build-runtime-v2"
    outer_path = runtime / "result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((runtime / "state.json").read_bytes())
    spec = json.loads((BASE / "build-intent-release.json").read_bytes())
    operation = BASE / "operation-release"
    candidate_path = operation / "candidate.json"
    candidate_before = ref(candidate_path)
    candidate = json.loads(candidate_path.read_bytes())
    assert outer["job_id"] == "650db128-1a2e-41bf-b17f-577e28ce57c1"
    assert (
        outer["outcome"] == "succeeded"
        and outer["exit_code"] == 0
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and not outer["remaining"]
    )
    assert (
        candidate["status"] == "PENDING_FINALIZATION"
        and candidate["cleanup_complete"]
        and candidate["process_cleanup_complete"]
        and not candidate["remaining"]
    )
    build = [c for c in candidate["checks"] if c["role"] == "build"]
    assert len(build) == 1 and build[0]["name"] == "timed-rootquality-genuine-release"
    known = []
    for check in candidate["checks"]:
        assert (
            check["status"] == "PASS"
            and check["capture_complete"]
            and not check["primary"]
            and not check["secondary"]
        )
        assert ref(Path(check["full_log"]["path"])) == check["full_log"]
        lc.settled(check["guardian_return"])
        assert check["guardian_return"]["handle_closes_complete"]
        member = check["guardian_return"]["child"]
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(name=check["name"], original=member, fresh=fresh))
    cargo = lc.cargo_report(Path(build[0]["full_log"]["path"]).read_bytes())
    assert cargo["warning_count"] == 0
    artifacts = [
        a
        for a in cargo["artifacts"]
        if a["target"]["name"] == "quoridor-runner"
        and a["target"]["kind"] == ["bin"]
        and not a["profile"]["test"]
    ]
    assert (
        len(artifacts) == 1
        and artifacts[0] == candidate["cargo_artifact"]
        and artifacts[0]["fresh"] is False
    )
    member = state["child"]
    fresh = lc.process.identity(lc.process.process_info(member["pid"]))
    assert fresh != lc.process.identity(member)
    known.append(dict(name="actual lifecycle source child", original=member, fresh=fresh))
    supervisor = dict(
        original=state["supervisor"],
        fresh=lc.process.identity(lc.process.process_info(state["supervisor"]["pid"])),
        role="completed outer controller/notification only, not a compiler/native child",
    )
    manifest = lc.finalize(operation, ref(outer_path))
    assert manifest["status"] == "PASS" and manifest["artifact"] == candidate["artifact"]
    assert ref(candidate_path) == candidate_before
    with lc.lease():
        lc.source_check(spec["source"])
        assert not Path(spec["TMP"]).exists()
        seen = set()
        profiles = [
            helpers.point(Path(spec["target"]) / name, seen) for name in ["debug", "release"]
        ]
        private = helpers.point(Path(spec["private"]).parent, seen)
        old_private = helpers.point(
            ROOT
            / ".artifacts/research-team/integration324/cedar-lazy-smp-v1/software-v1/private-image-v7",
            seen,
        )
        old24_private = helpers.point(
            ROOT
            / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/software-v1/private-image-release",
            seen,
        )
        actual = (
            sum(row["allocated_B"] for row in profiles)
            + private["allocated_B"]
            + old_private["allocated_B"]
            + old24_private["allocated_B"]
        )
        old25_private = helpers.point(
            ROOT
            / ".artifacts/research-team/integration324/cedar-shallow-main-history-v1/software-v1/private-image-release",
            seen,
        )
        old27_private = helpers.point(
            ROOT
            / ".artifacts/research-team/integration324/cedar-lazy-smp-followup-v1/replacement-v1/software-v1/private-image-release",
            seen,
        )
        actual += old25_private["allocated_B"] + old27_private["allocated_B"]
        prior = json.loads((BASE / "prefix-collection-v1/completion-and-STOP.json").read_bytes())
        assert ref(Path(prior["actual_affected_point"]["path"])) == prior["actual_affected_point"]
        retirement = json.loads((BASE / "release-cache-retirement-return.json").read_bytes())
        prior_group_after_retirement = retirement["actual_target_and_four_private_baseline_after_B"]
        cover = retirement["known_cover_after_B"] + actual - prior_group_after_retirement
        point = OUT / "affected-target-and-image-once.json"
        with point.open("x") as stream:
            json.dump(
                dict(
                    target_profiles=profiles,
                    private_image=private,
                    unchanged_old_private_image=old_private,
                    unchanged_old24_private_image=old24_private,
                    unchanged_old25_private_image=old25_private,
                    unchanged_old27_private_image=old27_private,
                    scope="One directed ended release target/image inode union only; no global/source/model/old science walk",
                    later_globalactual_fees="UNKNOWN",
                ),
                stream,
                indent=2,
            )
            stream.write("\n")
        assert cover <= 50000000000
        callers = [
            ref(ROOT / name)
            for name in [
                "scripts/dev/research-lifecycle.py",
                "scripts/dev/research-job.py",
                "python/quoridor_training/cycle_process.py",
                "python/quoridor_training/snapshot.py",
            ]
        ]
    packet = dict(
        status="ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP",
        software_manifest=ref(operation / "manifest.json"),
        artifact=manifest["artifact"],
        actual_cargo_artifact=candidate["cargo_artifact"],
        outer=ref(outer_path),
        original_candidate=candidate_before,
        outer_seconds_once=outer["wall_seconds"],
        accepted_inclusive_seconds_once=(
            datetime.datetime.fromisoformat(outer["finished_at"])
            - datetime.datetime.fromisoformat(state["created_at"])
        ).total_seconds(),
        nested_added=0,
        retained_software="New timed real-callee Rust1 and affectedClippy warning0 PASS retained from original repaired-callee prefix; no old suite replay",
        current_callers=callers,
        known_command_fresh_absence=known,
        notification_supervisor=supervisor,
        source_leases=[],
        remaining_owned=[],
        TMP=[],
        affected_point=ref(point),
        ended_target_and_image_B=actual,
        current_known_cover_B=cover,
        remaining_to_decimal50GB_B=50000000000 - cover,
        evaluation="UNENTERED, no speed/strength claim",
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        host_future_quiet=False,
    )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        json.dump(packet, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {
                k: packet[k]
                for k in [
                    "status",
                    "artifact",
                    "software_manifest",
                    "current_known_cover_B",
                    "remaining_to_decimal50GB_B",
                ]
            }
        )
    )


if __name__ == "__main__":
    main()
