"""Run only the new shallow MAIN canonical metadata definition."""

import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import CycleResources, execute, identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
temporary = OUT / "new-Python-TMP"
temporary.mkdir()
deadline = time.monotonic() + 120
resources = CycleResources(
    {"max_memory_bytes": 1024**3 - 64 * 1024**2, "host_ram_reserve": 4 * 1024**3}, OUT, deadline
)
try:
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        result = execute(
            [
                sys.executable,
                "-B",
                str(
                    ROOT
                    / ".worktree/assets/perf/cedar-shallow-main-history-v1/ordinary-corrections-v1/test_shallow_main_metadata_v2.py"
                ),
                "ShallowMainMetadata.test_shallow_main_normal_measurement_arena_and_actual_record_join",
                "-v",
            ],
            OUT / "new-Python-one.log",
            deadline,
            cpu_core=0,
            resources=resources,
            cwd=str(ROOT),
            env=dict(
                os.environ,
                TMPDIR=str(temporary),
                CUDA_VISIBLE_DEVICES="",
                PYTHONDONTWRITEBYTECODE="1",
            ),
        )
    assert result["exit_code"] == 0 and result["cleanup_complete"] and result["direct_child_reaped"]
    assert identity(process_info(result["child"]["pid"])) != result["child"]
    temporary.rmdir()
    source = ROOT / "scripts/dev/research-lifecycle.py"
    value = dict(
        status="NEW_ONE_CANONICAL_METADATA_DEFINITION_PASS",
        actual_return=result,
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        source_leases=[],
        TMP=[],
        old_success_replay=0,
        native_model_Search_RNG=0,
        host_future_quiet=False,
    )
    with (OUT / "new-Python-one-STOP.json").open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            dict(
                status=value["status"],
                wall_seconds=result["wall_seconds"],
                cleanup_complete=result["cleanup_complete"],
            )
        )
    )
finally:
    if temporary.exists() and not any(temporary.iterdir()):
        temporary.rmdir()
