"""Resolve only concurrent independent test-module appends; leave Main untouched."""

import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
SUBJECT = "crates/quoridor-runner/src/measurement.rs"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    source = OUT / "conflicts" / SUBJECT
    raw = source.read_text()
    assert raw.count("<<<<<<< CURRENT24\n") == raw.count(">>>>>>> CANDIDATE25\n") == 1
    prefix, rest = raw.split("<<<<<<< CURRENT24\n")
    current, rest = rest.split("||||||| BEFORE25\n")
    base, rest = rest.split("=======\n")
    candidate, suffix = rest.split(">>>>>>> CANDIDATE25\n")
    assert not base and not suffix
    assert "mod node_publication_settings_tests" in current
    assert "mod shallow_main_measurement_boundary_tests" in candidate
    assert "mod shallow_main_measurement_boundary_tests" not in current
    assert "mod node_publication_settings_tests" not in candidate
    target = OUT / "post" / SUBJECT
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x") as stream:
        stream.write(prefix + current + candidate)
    with (OUT / "append-conflict-resolution.json").open("x") as stream:
        json.dump(
            dict(
                input=ref(source),
                prepared=ref(target),
                resolution="Empty common base at EOF: retain both entire independent test modules unchanged, current24 first then candidate25. No production choice or test execution.",
                production_bytes_before_conflict_unchanged=True,
                Main_writes=0,
                compiler_tests_native_RAW_RNG=0,
            ),
            stream,
            indent=2,
        )
        stream.write("\n")
    print(json.dumps(dict(status="BOTH_TEST_MODULES_RETAINED", output=ref(target))))


if __name__ == "__main__":
    main()
