"""Resolve the concrete observed debug rebuild shortage with stopped release cache."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import stat

from quoridor_training import cycle_process as process

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OLD24 = ROOT / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(OUT / name)


def item(path):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and not path.is_symlink()
    return dict(
        path=str(path),
        device=value.st_dev,
        inode=value.st_ino,
        bytes=value.st_size,
        allocated_B=value.st_blocks * 512,
        links=value.st_nlink,
        mtime_ns=value.st_mtime_ns,
        mode=value.st_mode,
    )


def main():
    holding_path = (
        ROOT
        / ".worktree/assets/perf/cedar-lazy-smp-node-publication-v1/numeric-games-v2/analysis-v1/actual-retained-roots.json"
    )
    assert (
        ref(holding_path)["sha256"]
        == "c50f7f0b2757d81f6c6207a7eb51ecc840a64f27fe3cfc0f1daf0fac7522c4f7"
    )
    holding = json.loads(holding_path.read_bytes())
    stop_path = holding_path.parent / "native-collection-analysis-STOP.json"
    assert (
        ref(stop_path)["sha256"]
        == "31331e755109d23655f1704d88f560f2a0ed61e0ff9b65052ae238402c23e87c"
    )
    stop = json.loads(stop_path.read_bytes())
    assert (
        not stop["native_jobs_remaining"]
        and not stop["source_leases_remaining"]
        and not stop["TMP_entries"]
    )
    fresh = []
    for row in stop["known_exact_identities_fresh_absent_or_different"]:
        expected = row["expected"]
        current = process.identity(process.process_info(expected["pid"]))
        assert current != process.identity(expected)
        fresh.append(dict(expected=expected, fresh=current))
    prior_retirement = json.loads(
        (OLD24 / "normal64-entry-v1/cache-retirement-return.json").read_bytes()
    )
    assert prior_retirement["actual_allocated_B_removed_once"] == 101642240
    cover = (
        49762513920 - prior_retirement["actual_allocated_B_removed_once"] + holding["allocated_B"]
    )
    assert cover == 49712120832
    demand = 375336960
    margin = 32 * 1024**2
    needed = max(0, demand + margin - (50000000000 - cover))
    point_path = OLD24 / "software-v1/collection-v1/affected-target-and-image-once.json"
    point = json.loads(point_path.read_bytes())
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        candidates = []
        for profile in point["target_profiles"]:
            if not profile["path"].endswith("/target/release"):
                continue
            for row in profile["files"]:
                path = Path(row["path"])
                if path.suffix in (".rlib", ".rmeta") and row["links"] == 1 and path.exists():
                    assert item(path) == row
                    candidates.append(row)
        selected = []
        for row in sorted(candidates, key=lambda x: x["allocated_B"], reverse=True):
            if sum(x["allocated_B"] for x in selected) >= needed:
                break
            selected.append(row)
        assert sum(x["allocated_B"] for x in selected) >= needed
        intent = save(
            "intent.json",
            dict(
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                known_cover_before_B=cover,
                ended24_holding=ref(holding_path),
                previous_actual_retirement=ref(
                    OLD24 / "normal64-entry-v1/cache-retirement-return.json"
                ),
                saved_target_point=ref(point_path),
                observed_debug_rebuild_B=demand,
                ordinary_tail_margin_B=margin,
                concrete_required_reclamation_B=needed,
                fresh_known_ids=fresh,
                selected=selected,
                preservation="Only stopped rebuildable release rlib/rmeta. Every image/executable/sharedlibrary/model/Git/RAW/FAILED/log/unique evidence retained. No global walk or oldcredit/science refund/lending.",
            ),
        )
        removed = []
        try:
            for row in selected:
                path = Path(row["path"])
                assert item(path) == row
                path.unlink()
                removed.append(row)
        finally:
            reclaimed = sum(x["allocated_B"] for x in removed)
            result = save(
                "return.json",
                dict(
                    intent=intent,
                    all_selected_removed=len(selected) == len(removed),
                    actual_removed_B_once=reclaimed,
                    known_cover_after_B=cover - reclaimed,
                    head_to_decimal50GB_B=50000000000 - cover + reclaimed,
                    planned_ordinary_tail_after_observed_debug_demand_B=50000000000
                    - cover
                    + reclaimed
                    - demand,
                    later_tails_globalactual_fees="UNKNOWN",
                    old_credit_reapplied=0,
                    scientific_refund_lending_reset=0,
                    source_leases=[],
                    host_future_quiet=False,
                ),
            )
            print(json.dumps(dict(result=result, removed_B=reclaimed)))


if __name__ == "__main__":
    main()
