"""Issue the independent corrected-entry 104 with actual stopped-cache capacity."""

import fcntl
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
SOFTWARE = BASE / "timed-rootquality-software-v1"
OWN = ROOT / ".worktree/assets/perf/cedar-shallow-main-history-v1"
MIB = 1024**2


def main():
    loader = importlib.util.spec_from_file_location(
        "phase_metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/normal208-entry-v1/issue_support.py",
    )
    prior = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(prior)
    ref = prior.ref

    def save(name, value):
        with (OUT / name).open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return ref(OUT / name)

    trial_path = OWN / "corrected-entry-trial-v1/trial.json"
    trial_ref = ref(trial_path)
    assert (
        trial_ref["sha256"] == "6be8eb1dd6ea4c2f138777ff439eeba4eff9ebbe2b26cefdb11e45415cf02126"
        and trial_ref["bytes"] == 17807
    )
    protocol_path = OWN / "protocol-v1/protocol.json"
    protocol_ref = ref(protocol_path)
    assert (
        protocol_ref["sha256"] == "bcaebc171cbb4662676461be36214ae77e86425e78439ca3ede815a73bb95d02"
    )
    sw_path = SOFTWARE / "release-collection-v1/completion-and-STOP.json"
    sw = json.loads(sw_path.read_bytes())
    g = json.loads((SOFTWARE / "release-collection-v1/guard-return.json").read_bytes())
    assert sw["status"] == "ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP"
    assert (
        sw["software_manifest"]["sha256"]
        == "84fd79dc4f6b2e756b9f77688cb3b7b46f7d32132cf489802692548273af3695"
    )
    assert (
        sw["artifact"]["sha256"]
        == "f68639f78c816b9d590199f43cfccb96f63ed6f1e97e6cb461182a91c66ee3d7"
    )
    assert (
        g["actual_return"]["exit_code"] == 0
        and g["actual_return"]["cleanup_complete"]
        and g["actual_return"]["direct_child_reaped"]
        and g["actual_return"]["handle_closes_complete"]
        and not g["TMP"]
        and not g["source_leases"]
    )
    fresh = []
    for row in sw["known_command_fresh_absence"]:
        now = identity(process_info(row["original"]["pid"]))
        assert now != identity(row["original"])
        fresh.append(dict(original=row["original"], fresh=now))
    intent = json.loads((SOFTWARE / "build-intent-release.json").read_bytes())
    target = Path(intent["target"])
    affected = json.loads(Path(sw["affected_point"]["path"]).read_bytes())
    roots = [str(OWN), str(BASE / "normal104-entry-v1"), str(OUT)]
    actual = prior.point(roots)
    whole = 480 * MIB
    future = 448790528
    free = whole - actual["allocated_B"] - future
    assert free >= 8 * MIB, (actual, free)
    # The old OWN25+old entry retained union is already included in the known cover.
    # The new whole contains that same scope; replace it, never add it twice.
    old_retained = 13705216
    old_basis = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-followup-v1/replacement-v1/software-v1/ended25-holding-and-software-basis.json"
    )
    assert str(old_retained) in json.dumps(json.loads(old_basis.read_bytes()))
    current = sw["current_known_cover_B"]
    needed = max(0, current - old_retained + whole + 32 * MIB - 50000000000)
    lock = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock.open("a") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        marker = ref(target / ".research-owner.json")
        marker_body = json.loads((target / ".research-owner.json").read_bytes())
        assert marker_body[
            "writer"
        ] == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13" and marker_body["target"] == str(target)
        for row in sw["current_callers"]:
            assert ref(row["path"]) == row
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        assert head == "b45f13b64414654a9feaac1003023f7ce593ace2"
        changed = subprocess.check_output(
            ["git", "diff", "--name-only", intent["source"]["commit"], head], cwd=ROOT, text=True
        ).splitlines()
        assert changed == [
            "docs/design/ai-nnue-optimization-agenda.md",
            "docs/research-findings.md",
        ]
        private_rows = []
        for key in [
            "private_image",
            "unchanged_old_private_image",
            "unchanged_old24_private_image",
            "unchanged_old25_private_image",
            "unchanged_old27_private_image",
        ]:
            p = Path(affected[key]["path"]) / "quoridor-runner"
            q = p.lstat()
            assert (
                stat.S_ISREG(q.st_mode)
                and q.st_nlink == 1
                and not p.is_symlink()
                and not p.is_relative_to(target)
            )
            private_rows.append(
                dict(
                    path=str(p),
                    device=q.st_dev,
                    inode=q.st_ino,
                    bytes=q.st_size,
                    mtime_ns=q.st_mtime_ns,
                    mode=q.st_mode,
                    links=q.st_nlink,
                )
            )
        # Only this stopped shared Cargo pool's generated profiles are retired.
        # The qualified executables are independent immutable copies outside it.
        profiles = [target / "debug", target / "release"]
        groups = {}
        directories = []
        for top in profiles:
            assert top.is_dir() and not top.is_symlink()
            pending = [top]
            while pending:
                p = pending.pop()
                q = p.lstat()
                assert not stat.S_ISLNK(q.st_mode)
                if stat.S_ISDIR(q.st_mode):
                    directories.append(dict(path=str(p), allocated_B=q.st_blocks * 512))
                    pending.extend(p.iterdir())
                else:
                    assert stat.S_ISREG(q.st_mode)
                    row = groups.setdefault(
                        (q.st_dev, q.st_ino),
                        dict(
                            paths=[],
                            allocated_B=q.st_blocks * 512,
                            links=q.st_nlink,
                            device=q.st_dev,
                            inode=q.st_ino,
                            bytes=q.st_size,
                            mtime_ns=q.st_mtime_ns,
                            mode=q.st_mode,
                        ),
                    )
                    row["paths"].append(str(p))
                    assert row["allocated_B"] == q.st_blocks * 512 and row["links"] == q.st_nlink
        reclaim = sum(
            q["allocated_B"] for q in groups.values() if len(q["paths"]) == q["links"]
        ) + sum(q["allocated_B"] for q in directories)
        assert reclaim >= needed, (reclaim, needed)
        retirement = save(
            "cache-retirement-intent.json",
            dict(
                actual_software_STOP=ref(sw_path),
                fresh_known_ids=fresh,
                marker=marker,
                profiles=[str(p) for p in profiles],
                concrete_bulk_shortage_B=needed,
                expected_allocated_reclaim_B=reclaim,
                regular_inode_groups=list(groups.values()),
                directories=directories,
                preserved_private_images=private_rows,
                scope="Stopped generated Cargo debug/release profiles only, toolchain and source/Git/models/inputs/RAW/FAILED/qualified private images/unique evidence retained. Rebuild from preserved source/toolchain; no active reader or compiler.",
            ),
        )
        completed = []
        try:
            for p in profiles:
                shutil.rmtree(p)
                assert not p.exists()
                completed.append(str(p))
        finally:
            save(
                "cache-retirement-return.json",
                dict(
                    intent=retirement,
                    removed_profile_paths=completed,
                    all_removed=len(completed) == len(profiles),
                    actual_removed_B_once=reclaim if len(completed) == len(profiles) else None,
                    old_credits_reapplied=0,
                    refund_loan_reset=0,
                    later_tails_globalactual_fullfees="UNKNOWN",
                ),
            )
        assert ref(target / ".research-owner.json") == marker
        for row in private_rows:
            q = Path(row["path"]).lstat()
            assert (q.st_dev, q.st_ino, q.st_size, q.st_mtime_ns, q.st_mode, q.st_nlink) == (
                row["device"],
                row["inode"],
                row["bytes"],
                row["mtime_ns"],
                row["mode"],
                row["links"],
            )
        cover = current - reclaim - old_retained + whole
        assert cover <= 50000000000 - 32 * MIB
        fs = os.statvfs(OWN)
        assert fs.f_bavail * fs.f_frsize > whole
        capacity = save(
            "capacity-and-holding.json",
            dict(
                roots=roots,
                actual_directed_scope_point=actual,
                previous_retained_scope_B=old_retained,
                previous_retained_scope_basis=ref(old_basis),
                whole_B=whole,
                conservative_future_B=future,
                free_B=free,
                prior_known_cover_B=current,
                actual_cache_retired_B_once=reclaim,
                new_known_cover_B=cover,
                remaining_to_decimal50GB_B=50000000000 - cover,
                filesystem_available_B=fs.f_bavail * fs.f_frsize,
                settlement="Replace already-counted ended OWN25+old-entry retention with this ONE new480MiB whole containing it and new25.3 data/control; old fourUNKNOWN/100unperformed remain immutable, no science quota transfer/refund/lending. Later/globalactual/fees UNKNOWN.",
            ),
        )
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_CORRECTED_ENTRY_SOURCE_SOFTWARE_COLLECTION_RELEASED",
                current_commit=head,
                current_four_callers=sw["current_callers"],
                software_manifest=sw["software_manifest"],
                artifact=sw["artifact"],
                actual_software_STOP=ref(sw_path),
                collector_guard=ref(SOFTWARE / "release-collection-v1/guard-return.json"),
                source_adoption=ref(BASE / "timed-rootquality-adoption-v1/actual-adoption.json"),
                source_bridge=dict(
                    compiled_commit=intent["source"]["commit"],
                    subsequent_paths=changed,
                    Rust_currentcallers_exact=True,
                ),
                actual_EX_NB_acquired_released=True,
                source_leases_remaining=[],
                qualification="New actualcallee running1/Clippy warning0/genuine release normal finalize PASS once; no oldsuccessful tests/model/source qualification replay",
                numerical_scope="Structural641ca only, actual current factory/numerical_fields/caller/normal admission mandatory",
                evaluation="NEW25_3_104_UNENTERED",
                host_future_quiet=False,
            ),
        )
        support = save(
            "phase-support-N1.json",
            dict(
                issue="quoridor-4lc.324.25.3",
                status="ISSUED_INDEPENDENT_CORRECTED_ENTRY_NEW104_ONE_WHOLE",
                fixed_protocol=protocol_ref,
                new_trial=trial_ref,
                current_source_adoption=release,
                actual_source_STOP=release,
                actual_software_STOP=ref(sw_path),
                whole_B=whole,
                owned_B=whole,
                free_B=free,
                roots=roots,
                storage_budget=dict(whole_B=whole, roots=roots),
                capacity_basis=capacity,
                resources=dict(
                    search_cpu_cores=[12],
                    total_search_threads=1,
                    worker_cpu=12,
                    main_guardian=0,
                    outer_guardian=18,
                    launch_affinity=[0, 12, 18],
                    family_B=4 * 1024**3,
                    controller_B=1536 * MIB,
                    native_B=2560 * MIB,
                    host_reserve_B=4 * 1024**3,
                    GPU=0,
                    threads=1,
                    CPU=2,
                    controller_included=True,
                    family_RAM_B=4 * 1024**3,
                    controller_RAM_B=1536 * MIB,
                ),
                limits=dict(
                    worker_cpu=12,
                    guardian_cpu=0,
                    family_B=4 * 1024**3,
                    controller_B=1536 * MIB,
                    host_reserve_B=4 * 1024**3,
                    owned_B=whole,
                    free_B=free,
                    log_B=MIB,
                ),
                total_original_calls=104,
                total_original_nodes=104000000,
                per_call_aggregate_nodes=1000000,
                TOTAL_TT_entries=1048576,
                serial_runs=4,
                sessions=24,
                RUN_timeout_s=180,
                parent_accepted_s=1200,
                parent_command_s=1140,
                cleanup_margin_s=60,
                readonly_images_models_copy_B=0,
                binding="SAME genuine f686 image both Current/Half arms, clock100ms5,N1,Control,baselineLMR,rootquality plain bounded OffShadow, historywatch omitted. Corrected realcallee qualified; no observer-OFF substitute.",
                normal_remaining_inputs="Actual current factory/measurement_config/caller_source_refs/numerical_fields/native_cpu_cores expected[0,12]/actualowner/fullroots/positivefree/freshphysicalSMT-peer/RAM/host4/storage/ownerpausecancel/origin/end_at/serializer/cleanup required; emptycanonicalPlan/approvedNone is maintained measurement route",
                science_usage_before_entry=0,
                old_original25="401b/9786 fourUNKNOWN/zero usable/100unperformed/old64 STOPPED immutable; no transfer/refill/reset",
                conditional64="Forward NEW25.3 only under fixed new104 mechanical/clockgate plus future separate actualsupport; not oldSTOPPED64 activation",
                timing="Main/currentcallers/Git/Cargo/libs/env/image/substantial IO held through actualnew104native+normalcollectionSTOP only; independent27gamesprep/Maxreview/26private preparation allowed",
                preserved="all pauses/seals/defaultCurrent/models/foreign/FAILED/NULL/UNKNOWNfees/50GB",
            ),
        )
        save(
            "issued-inputs.json",
            dict(
                release=release,
                phase_supports=[support],
                capacity=capacity,
                source_leases=[],
                evaluation="INDEPENDENT_NEW104_UNENTERED",
            ),
        )
    print(
        json.dumps(
            dict(
                status="ISSUED",
                whole_B=whole,
                actual_source_point_B=actual["allocated_B"],
                free_B=free,
                cache_retired_B_once=reclaim,
                known_cover_B=cover,
                head_B=50000000000 - cover,
            )
        )
    )


if __name__ == "__main__":
    main()
