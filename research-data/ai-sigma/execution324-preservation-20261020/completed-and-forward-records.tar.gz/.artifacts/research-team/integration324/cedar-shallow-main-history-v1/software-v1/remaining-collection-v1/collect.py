"""Collect the original remaining checks, then prepare safe release cache capacity."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import stat

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOFTWARE = OUT.parent


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path), sha256=hashlib.sha256(body).hexdigest(), bytes=len(body), mode="0644"
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def item(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_nlink == 1
    return dict(
        path=str(path),
        device=info.st_dev,
        inode=info.st_ino,
        bytes=info.st_size,
        allocated_B=info.st_blocks * 512,
        links=info.st_nlink,
        mtime_ns=info.st_mtime_ns,
        mode=info.st_mode,
    )


def main():
    outer_path = SOFTWARE / "check-runtime-v2/result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((outer_path.parent / "state.json").read_bytes())
    candidate_path = SOFTWARE / "operation-remaining/prefix-result.json"
    candidate = json.loads(candidate_path.read_bytes())
    assert outer["job_id"] == candidate["origin_job_id"] == "5515f74e-3718-49f0-af59-7cac59f87ead"
    assert outer["outcome"] == "succeeded" and outer["exit_code"] == 0
    assert outer["cleanup_complete"] and outer["direct_child_reaped"] and not outer["remaining"]
    assert candidate["status"] == "PASS_TEST_LINT_PREFIX_ONLY" and candidate["cleanup_complete"]
    assert not candidate["release_executed"] and len(candidate["checks"]) == 3
    known = []
    for row in candidate["checks"]:
        assert row["status"] == "PASS" and row["cargo"]["warning_count"] == 0
        receipt = json.loads(Path(row["persisted_process_receipt"]["path"]).read_bytes())
        assert receipt["cleanup_complete"] and receipt["direct_child_reaped"]
        assert receipt["handle_closes_complete"] and not receipt["remaining"]
        assert identity(process_info(receipt["child"]["pid"])) != receipt["child"]
        if row["role"] == "test":
            log = Path(row["full_log"]["path"]).read_text()
            assert "running 1 test\n" in log
            assert "test result: ok. 1 passed; 0 failed;" in log
            assert row["argv"][row["argv"].index("--lib") + 1] + " ... ok" in log
        known.append(
            dict(
                name=row["name"],
                original=receipt["child"],
                fresh=identity(process_info(receipt["child"]["pid"])),
            )
        )
    for name in ["child", "supervisor"]:
        original = state[name]
        current = identity(process_info(original["pid"]))
        if name == "child":
            assert current != original
        known.append(dict(name=name, original=original, fresh=current))
    loader = importlib.util.spec_from_file_location(
        "prior_collection", SOFTWARE / "first-prefix-failure-collection-v1/collect.py"
    )
    prior = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(prior)
    spec = json.loads((SOFTWARE / "build-intent-remaining.json").read_bytes())
    previous_path = SOFTWARE / "first-prefix-failure-collection-v1/completion-and-STOP.json"
    previous = json.loads(previous_path.read_bytes())
    previous_point = json.loads(Path(previous["actual_affected_point"]["path"]).read_bytes())
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        temporary = Path(spec["TMP"])
        if temporary.exists():
            assert not list(temporary.iterdir())
            temporary.rmdir()
        assert not temporary.exists()
        roots = [Path(p) for p in previous_point["roots"]]
        actual = prior.point(roots)
        point_ref = save(
            "affected-target-and-retained-image-once.json",
            dict(
                roots=[str(p) for p in roots],
                point=actual,
                scope="Directed ended target debug/release and two retained images inode union; no global/source/model/RAW walk.",
            ),
        )
        cover = (
            previous["current_known_cover_B"]
            + actual["allocated_B"]
            - previous["current_target_and_retained_image_B"]
        )
        assert cover <= 50_000_000_000
        stop = save(
            "completion-and-STOP.json",
            dict(
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                status="NEW_RUST5_PYTHON1_AFFECTED_CLIPPY_PASS_RELEASE_UNENTERED",
                outer=ref(outer_path),
                candidate=ref(candidate_path),
                known_original_processes=known,
                actual_affected_point=point_ref,
                current_known_cover_B=cover,
                remaining_to_decimal50GB_B=50_000_000_000 - cover,
                outer_seconds_once=outer["wall_seconds"],
                nested_added=0,
                software_command_remaining_s=2285 - math.ceil(outer["wall_seconds"]),
                software_parent_remaining_s=2345 - math.ceil(outer["wall_seconds"]),
                TMP=[],
                source_leases=[],
                remaining_owned=[],
                host_future_quiet=False,
                preserved="Original prefix failure/PASS receipts retained; no old suite/science replay/refund/lending; later tails/globalactual/fullfees UNKNOWN.",
            ),
        )
        # Use the saved previous release profile and one new private image as a forecast.
        # Resolve only its concrete shortage plus a tail margin, without a global walk.
        saved_release_point = (
            ROOT
            / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/software-v1/collection-v1/affected-target-and-image-once.json"
        )
        saved_release = json.loads(saved_release_point.read_bytes())
        release_output = (
            next(
                row["allocated_B"]
                for row in saved_release["target_profiles"]
                if row["path"].endswith("/target/release")
            )
            + 10234400
        )
        margin = 32 * 1024**2
        needed = max(0, release_output + margin - (50_000_000_000 - cover))
        candidates = [
            item(p)
            for p in (Path(spec["target"]) / "debug/deps").iterdir()
            if p.suffix in {".rlib", ".rmeta"} and p.is_file() and not p.is_symlink()
        ]
        selected = []
        for row in sorted(candidates, key=lambda value: value["allocated_B"], reverse=True):
            if sum(value["allocated_B"] for value in selected) >= needed:
                break
            selected.append(row)
        assert sum(row["allocated_B"] for row in selected) >= needed
        intent = save(
            "release-cache-retirement-intent.json",
            dict(
                actual_software_STOP=stop,
                current_known_cover_B=cover,
                anticipated_release_output_B=release_output,
                ordinary_tail_margin_B=margin,
                concrete_shortage_B=needed,
                selected=selected,
                preservation="Only stopped rebuildable debug rlib/rmeta; all test binaries/images/models/Git/RAW/FAILED/log/unique evidence retained.",
            ),
        )
        removed = []
        try:
            for row in selected:
                path = Path(row["path"])
                assert item(path) == row
                path.unlink()
                removed.append(row)
        finally:
            reclaimed = sum(row["allocated_B"] for row in removed)
            save(
                "release-cache-retirement-return.json",
                dict(
                    intent=intent,
                    all_selected_removed=len(selected) == len(removed),
                    actual_removed_B_once=reclaimed,
                    known_cover_after_B=cover - reclaimed,
                    head_to_decimal50GB_B=50_000_000_000 - cover + reclaimed,
                    old_credit_reapplied=0,
                    science_refund_lending_reset=0,
                    later_tails_globalactual_fullfees="UNKNOWN",
                    host_future_quiet=False,
                ),
            )
    print(
        json.dumps(
            dict(
                status="CHECKS_PASS_RELEASE_NEXT",
                command_remaining_s=2285 - math.ceil(outer["wall_seconds"]),
                removed_rebuildable_B=reclaimed,
            )
        )
    )


if __name__ == "__main__":
    main()
