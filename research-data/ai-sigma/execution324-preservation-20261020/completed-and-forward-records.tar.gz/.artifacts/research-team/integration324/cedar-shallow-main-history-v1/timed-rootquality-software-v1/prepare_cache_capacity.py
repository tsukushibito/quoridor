"""Resolve the concrete ordinary-prefix cache shortage after actual 27 STOP."""

import fcntl
import importlib.util
import json
from pathlib import Path

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PRIOR = ROOT / ".artifacts/research-team/integration324/cedar-lazy-smp-followup-v1/replacement-v1"


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def main():
    loader = importlib.util.spec_from_file_location(
        "prior_cache_metadata", PRIOR / "software-v1/prefix-collection-v1/collect.py"
    )
    prior = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(prior)
    support = json.loads((PRIOR / "normal208-entry-v1/capacity-and-holding.json").read_bytes())
    release = json.loads(
        (PRIOR / "software-v1/release-collection-v1/completion-and-STOP.json").read_bytes()
    )
    point = json.loads(Path(release["affected_point"]["path"]).read_bytes())
    previous_retirement = json.loads(
        (PRIOR / "normal208-entry-v1/cache-retirement-return.json").read_bytes()
    )
    stopped = json.loads(
        (
            OUT.parent / "timed-rootquality-adoption-v1/actual27-native-collection-release.json"
        ).read_bytes()
    )
    assert stopped["status"] == "ACTUAL27_NATIVE_NORMAL_COLLECTION_STOP_VERIFIED"
    for original in stopped["known_original_processes"]:
        assert identity(process_info(original["pid"])) != identity(original)
    spec = json.loads((OUT / "build-intent-prefix.json").read_bytes())
    target = Path(spec["target"])
    saved_debug = next(
        x["allocated_B"] for x in point["target_profiles"] if x["path"] == str(target / "debug")
    )
    # Same toolchain/features and new AI1+Clippy prefix as the saved previous prefix.
    # Only the cache actually removed since that debug point must be reconstructed.
    anticipated_increment = previous_retirement["actual_removed_B_once"]
    assert 0 < anticipated_increment < saved_debug
    cover = support["new_known_cover_B"]
    margin = 32 * 1024**2
    shortage = max(0, anticipated_increment + margin - (50000000000 - cover))
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        candidates = [
            prior.item(p)
            for p in (target / "release/deps").iterdir()
            if p.suffix in {".rlib", ".rmeta"} and p.is_file() and not p.is_symlink()
        ]
        selected = []
        for row in sorted(candidates, key=lambda x: x["allocated_B"], reverse=True):
            if sum(x["allocated_B"] for x in selected) >= shortage:
                break
            selected.append(row)
        assert sum(x["allocated_B"] for x in selected) >= shortage
        save(
            "prefix-cache-retirement-intent.json",
            dict(
                actual27_native_collection_STOP=stopped["actual_native_collection_STOP"],
                source_adoption=prior.ref(
                    OUT.parent / "timed-rootquality-adoption-v1/actual-adoption.json"
                ),
                known_cover_B=cover,
                already_charged_original27_whole_B=support["whole_B"],
                saved_debug_profile_B=saved_debug,
                anticipated_prefix_increment_B=anticipated_increment,
                ordinary_tail_B=margin,
                concrete_shortage_B=shortage,
                selected=selected,
                preserved="Only stopped rebuildable release rlib/rmeta; qualified private images, all models/Git/RAW/FAILED/unique evidence retained. Original27 whole still charged, no forecast release assumed.",
            ),
        )
        removed = []
        try:
            for row in selected:
                p = Path(row["path"])
                assert prior.item(p) == row
                p.unlink()
                removed.append(row)
        finally:
            retired = sum(x["allocated_B"] for x in removed)
            save(
                "prefix-cache-retirement-return.json",
                dict(
                    all_selected_removed=len(removed) == len(selected),
                    actual_removed_B_once=retired,
                    known_cover_after_B=cover - retired,
                    head_to_decimal50GB_B=50000000000 - cover + retired,
                    actual_target_and_four_private_baseline_after_B=release[
                        "ended_target_and_image_B"
                    ]
                    - previous_retirement["actual_removed_B_once"]
                    - retired,
                    old_credits_reapplied=0,
                    refund_loan_reset=0,
                    original27_whole_still_charged=True,
                    later_tails_globalactual_fullfees="UNKNOWN",
                    host_future_quiet=False,
                ),
            )
    print(
        json.dumps(
            dict(
                retired_B=retired,
                head_B=50000000000 - cover + retired,
                ordinary_prefix_increment_forecast_B=anticipated_increment,
            )
        )
    )


if __name__ == "__main__":
    main()
