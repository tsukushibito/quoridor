"""Adopt the prepared sparse history candidate after actual native collection STOP."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

from quoridor_training import cycle_process as process

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PREP = OUT.parent / "composition-preparation-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def checked(value):
    path = Path(value["path"])
    assert ref(path) == value
    return path.read_bytes()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def main():
    minimum = dict(
        path=str(
            ROOT / ".worktree/assets/perf/cedar-shallow-main-history-review-v1/minimum-result.json"
        ),
        sha256="46dfb6c21fbf19dd8c590e33474caed55fef7cf49e783fac7992713000af398a",
        bytes=1687,
        mode="0644",
    )
    verdict = json.loads(checked(minimum))
    assert (
        verdict["status"] == "SOURCE_CLEAR"
        and verdict["essential"] == 0
        and verdict["ordinary"] == 2
    )
    correction = dict(
        path=str(
            ROOT
            / ".worktree/assets/perf/cedar-shallow-main-history-v1/ordinary-corrections-v1/binding.json"
        ),
        sha256="79bf9ef5c848ba26cd1682c4a3e9191f40c6dda11328ab5709bbec473c62ded2",
        bytes=2617,
        mode="0644",
    )
    checked(correction)
    stop_ref = dict(
        path=str(
            ROOT
            / ".worktree/assets/perf/cedar-lazy-smp-node-publication-v1/numeric-games-v2/collection-v1/native-and-normal-collection-STOP.json"
        ),
        sha256="9b64ab796f60eb79736e2a8046ed2bac29be3ee24297599d426753431891e36e",
        bytes=2437,
        mode="0644",
    )
    stop = json.loads(checked(stop_ref))
    assert (
        not stop["native_jobs_remaining"]
        and not stop["TMP_entries"]
        and not stop["source_leases_remaining"]
    )
    fresh = []
    for row in stop["known_exact_identities_fresh_absent_or_different"]:
        expected = row["expected"]
        current = process.identity(process.process_info(expected["pid"]))
        assert current != process.identity(expected)
        fresh.append(dict(expected=expected, fresh=current))
    prepared = json.loads((PREP / "formatted-private-binding.json").read_bytes())
    guard = json.loads((PREP / "finish-guard-v1/guard-return.json").read_bytes())
    assert (
        guard["actual_return"]["exit_code"] == 0
        and guard["actual_return"]["direct_child_reaped"]
        and guard["actual_return"]["handle_closes_complete"]
    )
    assert not guard["TMP"] and not guard["source_leases"]
    foreign_paths = [
        ".devcontainer/devcontainer.json",
        ".devcontainer/update-toolchain.sh",
        "Cargo.lock",
        "scripts/dev/setup-rust.sh",
    ]
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert git("diff", "--cached", "--name-only") == b""
        before_commit = git("rev-parse", "HEAD").decode().strip()
        foreign = [ref(ROOT / name) for name in foreign_paths]
        rows = prepared["subjects"]
        for row in rows:
            actual = ref(ROOT / row["subject"])
            assert (
                actual["sha256"] == row["current_sha256"]
                and actual["bytes"] == row["current_bytes"]
                and actual["mode"] == row["mode"]
            )
            checked(row["post"])
        written = []
        try:
            for row in rows:
                path = ROOT / row["subject"]
                path.write_bytes(checked(row["post"]))
                path.chmod(int(row["post"]["mode"], 8))
                written.append(row["subject"])
                assert ref(path)["sha256"] == row["post"]["sha256"]
            git("diff", "--check", "--", *written)
            assert [ref(ROOT / name) for name in foreign_paths] == foreign
            git("add", "--", *written)
            assert set(git("diff", "--cached", "--name-only").decode().splitlines()) == set(written)
            git("commit", "-m", "Add bounded shallow negative main-history research comparison")
        except BaseException as error:
            (OUT / "failed-adoption.json").write_text(
                json.dumps(
                    dict(
                        before_commit=before_commit,
                        written=written,
                        error=repr(error),
                        action="Preserved partial state; no rollback/reset/foreign mutation",
                    ),
                    indent=2,
                )
                + "\n"
            )
            raise
        result = dict(
            at=datetime.datetime.now(datetime.UTC).isoformat(),
            status="SPARSE_MAIN_SOURCE_ADOPTED_NEW_SOFTWARE_PENDING",
            issue="quoridor-4lc.324.25",
            original_review=minimum,
            ordinary_O1_O2_correction=correction,
            formatted_sparse_composition=ref(PREP / "formatted-private-binding.json"),
            source_reader_STOP=verdict["actual_reader_STOP"]
            if "actual_reader_STOP" in verdict
            else "Pinned previously verified03dc766c/7443",
            actual24_native_collection_STOP=stop_ref,
            fresh_known_native_ids=fresh,
            before_commit=before_commit,
            commit=git("rev-parse", "HEAD").decode().strip(),
            subjects=[
                dict(subject=row["subject"], actual=ref(ROOT / row["subject"])) for row in rows
            ],
            foreign_protected=foreign,
            composition="Nine named subjects from immutablecurrent24 plus original25 and O2 correction; only concurrentEOF independenttestmodule conflict retained both entiremodules. Current24 coherentpublication/generics/sharing/math kept. Default current100; half50 researchN1 only. No oldwholealpha/LC overwrite.",
            format="Prepared8Rust rustfmt+check and8changedLCowner Ruffformat/check+AST/lint exactactualMain bytes; no wholeLCformat",
            software="NewRust5 and correctedPython1 definitions UNRUN; exactnonzero filters/affectedClippy/genuinenewimage next",
            science="Original24 native games exhausted/CI solely sameowner savedanalysis, no RootRNG/model/native/RAW/oldsuccessfulsuite replay",
            source_leases=[],
            host_future_quiet=False,
        )
        (OUT / "actual-adoption.json").write_text(json.dumps(result, indent=2) + "\n")
        print(
            json.dumps(dict(status=result["status"], commit=result["commit"], subjects=len(rows)))
        )


if __name__ == "__main__":
    main()
