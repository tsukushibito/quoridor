"""Run the small acceptance metadata helper through existing resource controls."""

import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import CycleResources, execute, identity, process_info


out = Path(__file__).resolve().parent
temporary = out / "collection-TMP"
temporary.mkdir()
deadline = time.monotonic() + 120
resources = CycleResources(
    {"max_memory_bytes": 1024**3 - 64 * 1024**2, "host_ram_reserve": 4 * 1024**3},
    out,
    deadline,
)
try:
    result = execute(
        [sys.executable, "-B", str(out / "collect.py")],
        out / "execution.log",
        deadline,
        cpu_cores=[18],
        resources=resources,
        cwd="/workspaces/quoridor",
        env=dict(os.environ, TMPDIR=str(temporary), CUDA_VISIBLE_DEVICES=""),
    )
    assert result["exit_code"] == 0 and result["cleanup_complete"]
    assert identity(process_info(result["child"]["pid"])) != result["child"]
    temporary.rmdir()
    with (out / "guard-return.json").open("x") as stream:
        json.dump(
            {"actual_return": result, "TMP": [], "source_leases": [], "host_future_quiet": False},
            stream,
            indent=2,
        )
        stream.write("\n")
    print(json.dumps({"exit_code": 0, "cleanup": True, "seconds": result["wall_seconds"]}))
finally:
    if temporary.exists() and not any(temporary.iterdir()):
        temporary.rmdir()
