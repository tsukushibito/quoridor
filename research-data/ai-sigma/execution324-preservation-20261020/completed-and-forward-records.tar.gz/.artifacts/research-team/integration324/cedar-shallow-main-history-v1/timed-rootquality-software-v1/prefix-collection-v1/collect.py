"""Collect the original remaining checks, then prepare safe release cache capacity."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import stat

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOFTWARE = OUT.parent


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path), sha256=hashlib.sha256(body).hexdigest(), bytes=len(body), mode="0644"
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def item(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_nlink == 1
    return dict(
        path=str(path),
        device=info.st_dev,
        inode=info.st_ino,
        bytes=info.st_size,
        allocated_B=info.st_blocks * 512,
        links=info.st_nlink,
        mtime_ns=info.st_mtime_ns,
        mode=info.st_mode,
    )


def main():
    outer_path = SOFTWARE / "check-runtime-v1/result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((outer_path.parent / "state.json").read_bytes())
    candidate_path = SOFTWARE / "operation-prefix/prefix-result.json"
    candidate = json.loads(candidate_path.read_bytes())
    assert outer["job_id"] == candidate["origin_job_id"] == "a18c7a30-e443-4942-aca7-cb3fa54a32e8"
    assert outer["outcome"] == "succeeded" and outer["exit_code"] == 0
    assert outer["cleanup_complete"] and outer["direct_child_reaped"] and not outer["remaining"]
    assert candidate["status"] == "PASS_TEST_LINT_PREFIX_ONLY" and candidate["cleanup_complete"]
    assert not candidate["release_executed"] and len(candidate["checks"]) == 2
    known = []
    for row in candidate["checks"]:
        assert row["status"] == "PASS" and row["cargo"]["warning_count"] == 0
        receipt = json.loads(Path(row["persisted_process_receipt"]["path"]).read_bytes())
        assert receipt["cleanup_complete"] and receipt["direct_child_reaped"]
        assert receipt["handle_closes_complete"] and not receipt["remaining"]
        assert identity(process_info(receipt["child"]["pid"])) != receipt["child"]
        if row["role"] == "test":
            log = Path(row["full_log"]["path"]).read_text()
            assert "running 1 test\n" in log
            assert "test result: ok. 1 passed; 0 failed;" in log
            assert row["argv"][row["argv"].index("--lib") + 1] + " ... ok" in log
        known.append(
            dict(
                name=row["name"],
                original=receipt["child"],
                fresh=identity(process_info(receipt["child"]["pid"])),
            )
        )
    for name in ["child", "supervisor"]:
        original = state[name]
        current = identity(process_info(original["pid"]))
        if name == "child":
            assert current != original
        known.append(dict(name=name, original=original, fresh=current))
    loader = importlib.util.spec_from_file_location(
        "prior_collection",
        ROOT
        / ".artifacts/research-team/integration324/cedar-shallow-main-history-v1/software-v1/first-prefix-failure-collection-v1/collect.py",
    )
    prior = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(prior)
    spec = json.loads((SOFTWARE / "build-intent-prefix.json").read_bytes())
    basis = json.loads((SOFTWARE / "prefix-cache-retirement-return.json").read_bytes())
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        temporary = Path(spec["TMP"])
        if temporary.exists():
            assert not list(temporary.iterdir())
            temporary.rmdir()
        assert not temporary.exists()
        roots = [Path(spec["target"]) / "debug", Path(spec["target"]) / "release"] + [
            ROOT / ".artifacts/research-team/integration324" / name
            for name in [
                "cedar-lazy-smp-v1/software-v1/private-image-v7",
                "cedar-lazy-smp-node-publication-v1/software-v1/private-image-release",
                "cedar-shallow-main-history-v1/software-v1/private-image-release",
                "cedar-lazy-smp-followup-v1/replacement-v1/software-v1/private-image-release",
            ]
        ]
        actual = prior.point(roots)
        point_ref = save(
            "affected-target-and-retained-image-once.json",
            dict(
                roots=[str(p) for p in roots],
                point=actual,
                scope="Directed ended target debug/release and two retained images inode union; no global/source/model/RAW walk.",
            ),
        )
        settled_path = (
            ROOT
            / ".artifacts/research-team/integration324/cedar-lazy-smp-followup-v1/replacement-v1/normal208-entry-v1/ended-phase-settlement.json"
        )
        settled = json.loads(settled_path.read_bytes())
        assert settled["status"] == "ORIGINAL208_EXHAUSTED_HOLDING_FORECAST_REPLACED_ONCE"
        assert settled["scientific_calls_used"] == 208
        cover = (
            basis["known_cover_after_B"]
            + actual["allocated_B"]
            - basis["actual_target_and_four_private_baseline_after_B"]
            + settled["known_cover_adjustment_B"]
        )
        assert cover <= 50_000_000_000
        save(
            "completion-and-STOP.json",
            dict(
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                status="NEW_TIMED_CALLEE_RUST_ONE_AFFECTED_CLIPPY_PASS_RELEASE_UNENTERED",
                outer=ref(outer_path),
                candidate=ref(candidate_path),
                known_original_processes=known,
                actual_affected_point=point_ref,
                original27_ended_scope_settlement_once=ref(settled_path),
                current_known_cover_B=cover,
                remaining_to_decimal50GB_B=50_000_000_000 - cover,
                outer_seconds_once=outer["wall_seconds"],
                nested_added=0,
                software_command_remaining_s=1740 - math.ceil(outer["wall_seconds"]),
                software_parent_remaining_s=1800 - math.ceil(outer["wall_seconds"]),
                TMP=[],
                source_leases=[],
                remaining_owned=[],
                host_future_quiet=False,
                preserved="Original25 incomplete and prior source/software failures retained; no old suite/science replay/refund/lending; later tails/globalactual/fullfees UNKNOWN.",
            ),
        )
    print(
        json.dumps(
            dict(
                status="CHECKS_PASS_RELEASE_NEXT",
                command_remaining_s=1740 - math.ceil(outer["wall_seconds"]),
                actual_group_B=actual["allocated_B"],
            )
        )
    )


if __name__ == "__main__":
    main()
