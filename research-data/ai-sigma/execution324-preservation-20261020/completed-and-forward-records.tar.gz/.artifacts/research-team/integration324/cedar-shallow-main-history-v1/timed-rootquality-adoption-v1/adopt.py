"""Compose the fixed two-file callee repair after the real 27 collection release."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import stat
import subprocess

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
FIXED = ROOT / ".worktree/assets/perf/cedar-shallow-main-history-v1/timed-rootquality-repair-v1"


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def command(*argv):
    return subprocess.check_output(list(argv), cwd=ROOT, stderr=subprocess.STDOUT)


def main():
    # This actual dependency must be collected by Root; preparation creates no fake STOP.
    dependency_path = OUT / "actual27-native-collection-release.json"
    dependency = json.loads(dependency_path.read_bytes())
    assert dependency["status"] == "ACTUAL27_NATIVE_NORMAL_COLLECTION_STOP_VERIFIED"
    assert dependency["job_id"] == "06ba14af-881f-43d9-9964-3728dea90c08"
    stop_ref = dependency["actual_native_collection_STOP"]
    assert ref(Path(stop_ref["path"])) == stop_ref
    assert not dependency["source_leases"] and not dependency["remaining_owned"]
    fresh = []
    for original in dependency["known_original_processes"]:
        current = identity(process_info(original["pid"]))
        assert current != identity(original)
        fresh.append(dict(original=original, fresh=current))
    binding_path = FIXED / "binding.json"
    binding_ref = ref(binding_path)
    assert (
        binding_ref["sha256"] == "ffc80b082619efaa3e7965a385b384f3b55683114db286aa886bf4d67bec4eb8"
        and binding_ref["bytes"] == 3639
    )
    binding = json.loads(binding_path.read_bytes())
    acceptance_path = OUT.parent / "clock-admission-review-v1/accepted-source-only.json"
    acceptance = json.loads(acceptance_path.read_bytes())
    assert acceptance["status"] == "ACCEPTED_SOURCE_ONLY_REVIEW_CLOSURE"
    assert acceptance["verified"][0] == binding_ref
    subjects = [row["path"] for row in binding["owners"]]
    assert subjects == [
        "crates/quoridor-ai/src/neighbour_opportunity.rs",
        "crates/quoridor-ai/src/neighbour_opportunity_tests.rs",
    ]
    patch = Path(binding["forward"]["path"])
    assert ref(patch) == binding["forward"]
    lock = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock.open("a") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        head = command("git", "rev-parse", "HEAD").decode().strip()
        assert head == "f2efd18e5c209ed3908b630879a042d66f5b6aac"
        assert command("git", "diff", "--cached", "--name-only") == b""
        foreign_paths = command("git", "diff", "--name-only", "HEAD").decode().splitlines()
        assert not set(subjects).intersection(foreign_paths)
        foreign = [ref(ROOT / name) for name in foreign_paths]
        before = []
        for row in binding["owners"]:
            actual = ref(ROOT / row["path"])
            assert all(actual[k] == row["before"][k] for k in ["sha256", "bytes", "mode"])
            assert ref(Path(row["post"]["path"])) == row["post"]
            before.append(actual)
        changed = [
            row.split("\t")[-1]
            for row in command("git", "apply", "--numstat", str(patch)).decode().splitlines()
        ]
        assert changed == subjects
        command("git", "apply", "--check", "--whitespace=nowarn", str(patch))
        applied = command("git", "apply", "--verbose", "--whitespace=nowarn", str(patch)).decode()
        assert "offset" not in applied.lower()
        after = []
        for row in binding["owners"]:
            actual = ref(ROOT / row["path"])
            assert all(actual[k] == row["post"][k] for k in ["sha256", "bytes", "mode"])
            after.append(actual)
        command(
            "/usr/local/cargo/bin/rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            "--check",
            *[str(ROOT / name) for name in subjects],
        )
        command("git", "diff", "--check", "--", *subjects)
        assert [ref(Path(row["path"])) for row in foreign] == foreign
        command("git", "add", "--", *subjects)
        assert command("git", "diff", "--cached", "--name-only").decode().splitlines() == subjects
        committed = command(
            "git", "commit", "-m", "Repair bounded timed root-quality callee admission"
        ).decode()
        commit = command("git", "rev-parse", "HEAD").decode().strip()
        assert command("git", "diff", "--name-only", head, commit).decode().splitlines() == subjects
        assert [ref(Path(row["path"])) for row in foreign] == foreign
    document = dict(
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        issue="quoridor-4lc.324.25.3",
        status="SPARSE_MAIN_SOURCE_ADOPTED_NEW_SOFTWARE_PENDING",
        before_commit=head,
        commit=commit,
        subjects=[
            dict(subject=name, before=a, post=b)
            for name, a, b in zip(subjects, before, after, strict=True)
        ],
        fixed_binding=binding_ref,
        source_only_acceptance=ref(acceptance_path),
        actual27_native_collection_STOP=stop_ref,
        known_original_processes_fresh=fresh,
        foreign_paths_preserved=foreign,
        actual_patch_output=applied,
        commit_output=committed,
        formatter="Scoped rustfmt check PASS; posts match fixed formatted packet",
        software="UNBUILT_UNTYPED_UNRUN",
        numerical="New25.3 independent104 remains UNENTERED; original25 fourUNKNOWN/100unperformed/old64STOPPED immutable",
        source_leases=[],
        remaining_owned=[],
        host_future_quiet=False,
        preserved="Current default/27 source/26 source and all pauses/seals/models/foreign/FAILED/NULL/UNKNOWNfees/50GB",
    )
    with (OUT / "actual-adoption.json").open("x") as stream:
        json.dump(document, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(status=document["status"], commit=commit, subjects=subjects)))


if __name__ == "__main__":
    main()
