"""Collect the original failed prefix and fresh actual process/TMP return once."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import stat

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOFTWARE = OUT.parent


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def point(roots):
    seen = set()
    allocated = logical = entries = 0
    pending = list(roots)
    while pending:
        path = pending.pop()
        info = path.lstat()
        key = (info.st_dev, info.st_ino)
        if key in seen:
            continue
        seen.add(key)
        allocated += info.st_blocks * 512
        logical += info.st_size
        entries += 1
        if stat.S_ISDIR(info.st_mode):
            pending.extend(path.iterdir())
    return dict(allocated_B=allocated, logical_B=logical, entries=entries)


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def main():
    outer_path = SOFTWARE / "check-runtime-v1/result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((outer_path.parent / "state.json").read_bytes())
    candidate_path = SOFTWARE / "operation-prefix/prefix-result.json"
    candidate = json.loads(candidate_path.read_bytes())
    assert outer["job_id"] == candidate["origin_job_id"] == "b51acf36-2c90-48a2-97fd-38f4095d6a73"
    assert (
        outer["outcome"] == "failed"
        and outer["exit_code"] == 1
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and not outer["remaining"]
    )
    assert [row["status"] for row in candidate["checks"]] == ["PASS", "PASS", "PASS", "FAILED"]
    known = []
    for row in candidate["checks"]:
        receipt = json.loads(Path(row["persisted_process_receipt"]["path"]).read_bytes())
        assert (
            receipt["cleanup_complete"]
            and receipt["direct_child_reaped"]
            and receipt["handle_closes_complete"]
            and not receipt["remaining"]
        )
        current = identity(process_info(receipt["child"]["pid"]))
        assert current != receipt["child"]
        known.append(
            dict(
                name=row["name"],
                original=receipt["child"],
                fresh=current,
                disk_receipt=row["persisted_process_receipt"],
                original_candidate_guardian=row["guardian_return"],
            )
        )
    for name in ["child", "supervisor"]:
        original = state[name]
        current = identity(process_info(original["pid"]))
        if name == "child":
            assert current != original
        known.append(dict(name=name, original=original, fresh=current))
    spec = json.loads((SOFTWARE / "build-intent-prefix.json").read_bytes())
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        temporary = Path(spec["TMP"])
        entries = list(temporary.iterdir())
        assert entries == []
        temporary.rmdir()
        target = Path(spec["target"])
        roots = [
            target / "debug",
            target / "release",
            ROOT
            / ".artifacts/research-team/integration324/cedar-lazy-smp-v1/software-v1/private-image-v7",
            ROOT
            / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/software-v1/private-image-release",
        ]
        actual = point(roots)
        affected = save(
            "affected-target-and-retained-image-once.json",
            dict(
                roots=[str(p) for p in roots],
                point=actual,
                scope="One directed ended software target profiles plus unchanged old image inodeunion; no old source/global/model/science walk, no payload hash or copy.",
            ),
        )
    cache = json.loads((SOFTWARE / "cache-retirement-v1/return.json").read_bytes())
    previous_group = 447336448 - 101642240 - cache["actual_removed_B_once"]
    cover = cache["known_cover_after_B"] + actual["allocated_B"] - previous_group
    assert cover <= 50000000000
    receipt = save(
        "completion-and-STOP.json",
        dict(
            at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            status="ORIGINAL_PREFIX_FAILED_RUNNER_LIB_COMPILE_THREE_NEW_AI_RUST_PASS_RETAINED",
            outer=ref(outer_path),
            candidate=ref(candidate_path),
            checks=[dict(name=r["name"], status=r["status"]) for r in candidate["checks"]],
            original_candidate_cleanup_complete=candidate["cleanup_complete"],
            actual_outer_cleanup_complete=outer["cleanup_complete"],
            known_original_processes=known,
            TMP_removed_empty_only=str(temporary),
            TMP=[],
            source_leases=[],
            remaining_owned=[],
            outer_seconds_once=outer["wall_seconds"],
            accepted_inclusive_seconds_once=(
                datetime.datetime.fromisoformat(outer["finished_at"])
                - datetime.datetime.fromisoformat(state["created_at"])
            ).total_seconds(),
            nested_added=0,
            software_command_remaining_s=2340 - 55,
            software_parent_remaining_s=2400 - 55,
            original_failure="Existing measurement_ordering394_tests Settings initializer lacks new optional shallow_main_history. Compile failure before Runner new4 body; add None only, preserve assertions/production. Three AI1/2/3 actualPASS retained; repairedRunner4 and unenteredRunner5/Clippy only next, release notexecuted.",
            retained_Python1="PASS",
            actual_affected_point=affected,
            previous_target_image_group_B=previous_group,
            current_target_and_retained_image_B=actual["allocated_B"],
            current_known_cover_B=cover,
            remaining_to_decimal50GB_B=50000000000 - cover,
            old_credit_reapplied=0,
            science_refund_lending_reset=0,
            later_tails_globalactual_fullfees="UNKNOWN",
            host_future_quiet=False,
        ),
    )
    print(
        json.dumps(
            dict(
                completion=receipt,
                current_known_cover_B=cover,
                retained_Rust=3,
                release_executed=False,
            )
        )
    )


if __name__ == "__main__":
    main()
