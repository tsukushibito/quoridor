"""Bind the original finite SMP phase at the actual software STOP."""

import datetime
import fcntl
import hashlib
import json
import os
import re
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-shallow-main-history-v1"
SOFTWARE = OUT.parent / "software-v1"
MIB = 1024**2


def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def checked(path, digest, size):
    result = ref(path)
    assert result["sha256"] == digest and result["bytes"] == size
    assert result["mode"] == "0644"
    return json.loads(Path(path).read_bytes())


def write(name, document):
    if name == "current-source-and-software-release.json" and (OUT / name).exists():
        prior_document = json.loads((OUT / name).read_bytes())
        assert {k: v for k, v in prior_document.items() if k != "at"} == {
            k: v for k, v in document.items() if k != "at"
        }
        return ref(OUT / name)
    with (OUT / name).open("x") as stream:
        json.dump(document, stream, indent=2)
        stream.write("\n")
    return ref(OUT / name)


def point(roots):
    seen = set()
    allocated = logical = entries = 0
    for root in roots:
        pending = [Path(root)]
        while pending:
            path = pending.pop()
            info = path.lstat()
            key = (info.st_dev, info.st_ino)
            if key in seen:
                continue
            seen.add(key)
            allocated += info.st_blocks * 512
            logical += info.st_size
            entries += 1
            if stat.S_ISDIR(info.st_mode):
                pending.extend(path.iterdir())
    return dict(allocated_B=allocated, logical_B=logical, entries=entries)


def main():
    prep = OWN / "protocol-v1"
    checked(
        prep / "protocol.json",
        "bcaebc171cbb4662676461be36214ae77e86425e78439ca3ede815a73bb95d02",
        9199,
    )
    software = json.loads((SOFTWARE / "collection-v1/completion-and-STOP.json").read_bytes())
    guard = json.loads((SOFTWARE / "collection-v1/guard-return.json").read_bytes())
    assert software["status"] == "ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP"
    assert guard["actual_return"]["exit_code"] == 0
    assert guard["actual_return"]["direct_child_reaped"]
    assert guard["actual_return"]["handle_closes_complete"]
    assert not guard["TMP"] and not guard["source_leases"]
    lock = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock.open("a+") as stream:
        fcntl.flock(stream, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for caller in software["current_callers"]:
            assert ref(caller["path"]) == caller
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        release = write(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_SOURCE_SOFTWARE_COLLECTION_RELEASED",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=commit,
                current_four_callers=software["current_callers"],
                software_manifest=software["software_manifest"],
                artifact=software["artifact"],
                actual_software_STOP=ref(SOFTWARE / "collection-v1/completion-and-STOP.json"),
                collector_guard=ref(SOFTWARE / "collection-v1/guard-return.json"),
                source_SH_NB_acquired_released=True,
                source_leases_remaining=[],
                numerical_scope="Inherited641ca structural only; actual normal join required at entry",
                qualification="NewRust5/Python1/affectedClippy warning0/genuine release PASS once; no new science or oldimage wall qualification",
                evaluation="UNENTERED",
                host_future_quiet=False,
            ),
        )
        fcntl.flock(stream, fcntl.LOCK_UN)
    roots = [str(OWN), str(OUT)]
    actual = point(roots)
    whole = 480 * MIB
    future = 448790528
    margin = whole - actual["allocated_B"] - future
    assert margin >= 8 * MIB, (actual, margin)
    prior = software["current_known_cover_B"]
    # Release is stopped: reclaim only the concrete whole-phase shortage plus tail margin.
    needed = max(0, prior + whole + 8 * MIB - 50000000000)
    affected = json.loads(
        (SOFTWARE / "collection-v1/affected-target-and-image-once.json").read_bytes()
    )
    selected = []
    with lock.open("a+") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        candidates = []
        for profile in affected["target_profiles"]:
            for row in profile["files"]:
                path = Path(row["path"])
                cache = path.suffix in {".rlib", ".rmeta"} and path.parent.name == "deps"
                debug_test = "/target/debug/deps/" in str(path) and re.fullmatch(
                    r"quoridor_[a-z_]+-[0-9a-f]{16}", path.name
                )
                debug_macro = "/target/debug/deps/" in str(path) and re.fullmatch(
                    r"lib(?:[a-z0-9_]*derive[a-z0-9_]*|thiserror_impl|indoc|tracing_attributes)-[0-9a-f]{16}\.so",
                    path.name,
                )
                if not (cache or debug_test or debug_macro) or row["links"] != 1:
                    continue
                info = path.lstat()
                assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
                assert (
                    info.st_dev,
                    info.st_ino,
                    info.st_size,
                    info.st_blocks * 512,
                    info.st_mtime_ns,
                    info.st_nlink,
                    info.st_mode,
                ) == (
                    row["device"],
                    row["inode"],
                    row["bytes"],
                    row["allocated_B"],
                    row["mtime_ns"],
                    row["links"],
                    row["mode"],
                )
                candidates.append((bool(debug_test or debug_macro), row))
        for _, row in sorted(candidates, key=lambda item: (item[0], -item[1]["allocated_B"])):
            if sum(item["allocated_B"] for item in selected) >= needed:
                break
            selected.append(row)
        assert sum(item["allocated_B"] for item in selected) >= needed
        retirement_intent = write(
            "cache-retirement-intent.json",
            dict(
                actual_software_STOP=ref(SOFTWARE / "collection-v1/completion-and-STOP.json"),
                saved_affected_point=ref(
                    SOFTWARE / "collection-v1/affected-target-and-image-once.json"
                ),
                concrete_shortage_B=needed,
                selected=selected,
                preservation="Stopped rebuildable target rlib/rmeta first, then generated debug quoridor crate test executables and derive proc-macro libraries if necessary. All qualified private images/models/Git/RAW/FAILED/process logs/unique evidence preserved; no global walk.",
            ),
        )
        removed = []
        try:
            for row in selected:
                path = Path(row["path"])
                info = path.lstat()
                assert (
                    info.st_dev,
                    info.st_ino,
                    info.st_size,
                    info.st_blocks * 512,
                    info.st_mtime_ns,
                    info.st_nlink,
                    info.st_mode,
                ) == (
                    row["device"],
                    row["inode"],
                    row["bytes"],
                    row["allocated_B"],
                    row["mtime_ns"],
                    row["links"],
                    row["mode"],
                )
                path.unlink()
                removed.append(row)
        finally:
            reclaimed = sum(item["allocated_B"] for item in removed)
            write(
                "cache-retirement-return.json",
                dict(
                    intent=retirement_intent,
                    actual_removed_B_once=reclaimed,
                    all_selected_removed=len(removed) == len(selected),
                    known_cover_after_B=prior - reclaimed,
                    no_science_refund_lending_reset=True,
                    later_globalactual_tails_fees="UNKNOWN",
                ),
            )
        prior -= reclaimed
    assert prior + whole <= 50000000000
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize > whole
    capacity = write(
        "capacity-and-holding.json",
        dict(
            scope="Directed OWN24 plus this entry-control inode union once, for whole-phase admission; not old source recharge or global walk",
            roots=roots,
            actual_ended_point=actual,
            conservative_future_B=future,
            whole_B=whole,
            forecast_margin_B=margin,
            prior_known_cover_B=prior,
            new_known_cover_B=prior + whole,
            remaining_to_decimal50GB_B=50000000000 - prior - whole,
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            original_forecast="New25 proposal is issued only here after actual software and ended OWN point; no old grant reuse",
            image="Existing qualified private image counted in software holding once; reference only, no new copy",
            global_actual_fees_later_tails="UNKNOWN",
            refunds_loans_science_credit=0,
        ),
    )
    supports = []
    for threads, workers in [(1, [12])]:
        resources = dict(
            search_cpu_cores=workers,
            total_search_threads=threads,
            worker_cpu=12,
            main_guardian=0,
            outer_guardian=18,
            launch_affinity=[0, 12, 14, 18],
            family_B=4 * 1024**3,
            controller_B=1536 * MIB,
            native_B=2560 * MIB,
            host_reserve_B=4 * 1024**3,
            GPU=0,
            threads=1,
            CPU=len(workers) + 1,
            controller_included=True,
            family_RAM_B=4 * 1024**3,
            controller_RAM_B=1536 * MIB,
        )
        supports.append(
            write(
                f"phase-support-N{threads}.json",
                dict(
                    issue="quoridor-4lc.324.25",
                    status="ISSUED_NEW25_NORMAL104_ONE_SERIAL_LIFETIME",
                    fixed_protocol=ref(prep / "protocol.json"),
                    normal_preparation=ref(prep / "protocol.json"),
                    current_source_adoption=release,
                    actual_source_STOP=release,
                    actual_software_STOP=ref(SOFTWARE / "collection-v1/completion-and-STOP.json"),
                    whole_B=whole,
                    roots=roots,
                    storage_budget=dict(whole_B=whole, roots=roots),
                    owned_B=whole,
                    free_B=margin,
                    capacity_basis=capacity,
                    resources=resources,
                    limits=dict(
                        worker_cpu=12,
                        guardian_cpu=0,
                        family_B=4 * 1024**3,
                        controller_B=1536 * MIB,
                        host_reserve_B=4 * 1024**3,
                        owned_B=whole,
                        free_B=margin,
                        log_B=MIB,
                    ),
                    total_original_calls=104,
                    total_original_nodes=104000000,
                    per_call_aggregate_nodes=1000000,
                    TOTAL_TT_entries=1048576,
                    serial_runs=4,
                    sessions=24,
                    RUN_timeout_s=900,
                    parent_accepted_s=1200,
                    parent_command_s=1140,
                    cleanup_margin_s=60,
                    readonly_images_models_copy_B=0,
                    native_aggregate_B_each=32 * MIB,
                    perf_RAW_B=0,
                    allocation="ONE480MiB full OWN25+Root entry. N1 main12/controller0/outer18; SMT13 unused; four sequential26-call RUNs ABBA104/104M, 24 chronological sessions. No old science quota reuse.",
                    normal_remaining_inputs="Actual normal measurement factory/numerical_fields/current environment/origin/end_at and fresh physical peers/RAM/ownerpausecancel/fullroot/storage/cleanup admission mandatory; RPC is not native entry",
                    timing="No substantial Cargo/ML/other observations/RAW/heavyDB through actual native+normalcollection STOP",
                    conditional64="New25 only: original pre-result gates and 32 fixed genuine both-colour families; separate later support required, not issued here. No integer-depth-gain veto or refill.",
                    oldimage_N1_wall="UNMEASURED",
                    source_quality="Software qualification only; no speed, strength, default or model promotion",
                    science_refund_lending_reset=0,
                    pauses_seals_models_defaults_foreign_FAILED_UNKNOWN="PRESERVED",
                ),
            )
        )
    write(
        "issued-inputs.json",
        dict(
            release=release,
            phase_supports=supports,
            capacity=capacity,
            source_leases=[],
            evaluation="UNENTERED",
        ),
    )
    print(
        json.dumps(
            dict(
                status="ISSUED",
                whole_B=whole,
                actual_point=actual,
                margin_B=margin,
                release=release,
            )
        )
    )


if __name__ == "__main__":
    main()
