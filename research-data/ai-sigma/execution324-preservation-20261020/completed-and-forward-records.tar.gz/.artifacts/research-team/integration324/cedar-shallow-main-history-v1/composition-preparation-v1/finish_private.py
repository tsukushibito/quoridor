"""Format only prepared source owners and bind the private merged derivative."""

import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
CURRENT = "6cfd9cc7860d66ad568db2431ea7caab8a8a1c55"
RUFF = "/home/vscode/.cache/inference/envs/quoridor-training/bin/ruff"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    prepared = json.loads((OUT / "prepared-merge.json").read_bytes())
    rust = [
        str(OUT / "post" / row["subject"])
        for row in prepared["subjects"]
        if row["subject"].endswith(".rs")
    ]
    for option in [[], ["--check"]]:
        subprocess.run(
            [
                "/usr/local/cargo/bin/rustfmt",
                "--edition",
                "2024",
                "--config",
                "skip_children=true",
                *option,
                *rust,
            ],
            cwd=ROOT,
            check=True,
        )
    lc = OUT / "post/scripts/dev/research-lifecycle.py"
    current = subprocess.check_output(
        ["git", "show", f"{CURRENT}:scripts/dev/research-lifecycle.py"], cwd=ROOT
    ).decode()
    text = lc.read_text()
    old_owners = {
        getattr(node, "name", None): ast.dump(node, include_attributes=False)
        for node in ast.parse(current).body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
    }
    changed = []
    for node in ast.parse(text).body:
        if isinstance(
            node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
        ) and old_owners.get(node.name) != ast.dump(node, include_attributes=False):
            changed.append(node)
    lines = text.splitlines(keepends=True)
    for node in reversed(changed):
        start = min([node.lineno, *[x.lineno for x in node.decorator_list]]) - 1
        source = "".join(lines[start : node.end_lineno])
        formatted = subprocess.run(
            [
                RUFF,
                "format",
                "--config",
                "tools/research-quality/ruff.toml",
                "--stdin-filename",
                "scripts/dev/research-lifecycle.py",
                "-",
            ],
            input=source.encode(),
            stdout=subprocess.PIPE,
            check=True,
            cwd=ROOT,
        ).stdout.decode()
        assert ast.dump(ast.parse(source), include_attributes=False) == ast.dump(
            ast.parse(formatted), include_attributes=False
        )
        lines[start : node.end_lineno] = [formatted]
    formatted = "".join(lines)
    assert ast.dump(ast.parse(text), include_attributes=False) == ast.dump(
        ast.parse(formatted), include_attributes=False
    )
    lc.write_text(formatted)
    for node in ast.parse(formatted).body:
        if getattr(node, "name", None) not in {x.name for x in changed}:
            continue
        start = min([node.lineno, *[x.lineno for x in node.decorator_list]]) - 1
        source = "".join(formatted.splitlines(keepends=True)[start : node.end_lineno])
        subprocess.run(
            [
                RUFF,
                "format",
                "--check",
                "--config",
                "tools/research-quality/ruff.toml",
                "--stdin-filename",
                "scripts/dev/research-lifecycle.py",
                "-",
            ],
            input=source.encode(),
            stdout=subprocess.PIPE,
            check=True,
            cwd=ROOT,
        )
    subprocess.run(
        [RUFF, "check", "--config", "tools/research-quality/ruff.toml", str(lc)],
        check=True,
        cwd=ROOT,
    )
    rows = []
    patch = []
    for row in prepared["subjects"]:
        subject = row["subject"]
        current = subprocess.check_output(["git", "show", f"{CURRENT}:{subject}"], cwd=ROOT)
        post = OUT / "post" / subject
        assert hashlib.sha256(current).hexdigest() == row["current_sha256"]
        patch.extend(
            difflib.unified_diff(
                current.decode().splitlines(keepends=True),
                post.read_text().splitlines(keepends=True),
                fromfile=f"a/{subject}",
                tofile=f"b/{subject}",
            )
        )
        rows.append(
            dict(
                subject=subject,
                current_immutable_commit=CURRENT,
                current_sha256=row["current_sha256"],
                current_bytes=len(current),
                mode="0644",
                post=ref(post),
            )
        )
    target = OUT / "merged-forward.patch"
    target.write_text("".join(patch))
    with (OUT / "formatted-private-binding.json").open("x") as stream:
        json.dump(
            dict(
                issue="quoridor-4lc.324.25",
                status="SPARSE_COMPOSED_FORMATTED_PRIVATE_ONLY_NOT_ADOPTED_NOT_TYPED_NOT_SOFTWARE",
                current_immutable_commit=CURRENT,
                subjects=rows,
                forward=ref(target),
                original_merge=ref(OUT / "prepared-merge.json"),
                append_only_test_resolution=ref(OUT / "append-conflict-resolution.json"),
                LC_changed_formatted_owners=[x.name for x in changed],
                Rust_new5_Python_new1="UNRUN; exact corrected selector and metadata-v2 required only on actual canonical adoption",
                Main_Git_index_Cargo_docs_native_model_RAW_RNG_test_changes_or_replay=0,
                actual_Main_adoption="After original24 actual native+normalcollectionSTOP, EX NB/fresh source correspondence; no wholeoldpost overwrite",
                source_leases=[],
                host_future_quiet=False,
            ),
            stream,
            indent=2,
        )
        stream.write("\n")
    print(
        json.dumps(
            dict(
                status="PRIVATE_FORMATTED", subjects=len(rows), LC_owners=[x.name for x in changed]
            )
        )
    )


if __name__ == "__main__":
    main()
