"""Prepare sparse 25 source composition from immutable Git, without Main mutation."""

import datetime
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-shallow-main-history-v1"
CURRENT = "6cfd9cc7860d66ad568db2431ea7caab8a8a1c55"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def checked(value):
    path = Path(value["path"])
    assert ref(path) == value
    return path.read_bytes()


def main():
    binding_ref = dict(
        path=str(OWN / "source-packet-v1/binding.json"),
        sha256="80d30140d7568f25eb8339149213fbd9cea4338ed3b9d158b5fac40ef2fc5e70",
        bytes=8780,
        mode="0644",
    )
    correction_ref = dict(
        path=str(OWN / "ordinary-corrections-v1/binding.json"),
        sha256="79bf9ef5c848ba26cd1682c4a3e9191f40c6dda11328ab5709bbec473c62ded2",
        bytes=2617,
        mode="0644",
    )
    binding = json.loads(checked(binding_ref))
    correction = json.loads(checked(correction_ref))
    checked(
        dict(
            path=str(OWN / "ordinary-corrections-v1/source-STOP.json"),
            sha256="4782e371d4a9eaf64a184c4bd2e96f167f5dfb972a195fd84d6e6ce7464c9030",
            bytes=7694,
            mode="0644",
        )
    )
    rows = []
    patches = []
    with tempfile.TemporaryDirectory(prefix="sparse-merge-", dir=OUT / "TMP") as temporary:
        temp = Path(temporary)
        for row in binding["files"]:
            subject = row["path"]
            before = checked(row["before"])
            post_ref = (
                correction["new_LC"]
                if subject == "scripts/dev/research-lifecycle.py"
                else row["post"]
            )
            post = checked(post_ref)
            actual_base = subprocess.check_output(
                ["git", "show", f"{binding['base_commit']}:{subject}"], cwd=ROOT
            )
            assert actual_base == before
            current = subprocess.check_output(["git", "show", f"{CURRENT}:{subject}"], cwd=ROOT)
            for name, data in [("current", current), ("base", before), ("candidate", post)]:
                (temp / name).write_bytes(data)
            result = subprocess.run(
                [
                    "git",
                    "merge-file",
                    "--stdout",
                    "--diff3",
                    "-L",
                    "CURRENT24",
                    "-L",
                    "BEFORE25",
                    "-L",
                    "CANDIDATE25",
                    str(temp / "current"),
                    str(temp / "base"),
                    str(temp / "candidate"),
                ],
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            assert 0 <= result.returncode < 128, result.stderr.decode()
            destination = OUT / ("conflicts" if result.returncode else "post") / subject
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("xb") as stream:
                stream.write(result.stdout)
            destination.chmod(0o644)
            rows.append(
                dict(
                    subject=subject,
                    immutable_current_commit=CURRENT,
                    current_sha256=hashlib.sha256(current).hexdigest(),
                    current_bytes=len(current),
                    original_candidate=post_ref,
                    merge_conflicts=result.returncode,
                    prepared=ref(destination),
                )
            )
            if result.returncode == 0:
                patches.extend(
                    difflib.unified_diff(
                        current.decode().splitlines(keepends=True),
                        result.stdout.decode().splitlines(keepends=True),
                        fromfile=f"a/{subject}",
                        tofile=f"b/{subject}",
                    )
                )
    (OUT / "clean-subjects-forward.patch").write_text("".join(patches))
    document = dict(
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        status="PRIVATE_COMPOSITION_PREPARED_NOT_MAIN_NOT_FORMATTED_NOT_TYPED_NOT_SOFTWARE",
        original_binding=binding_ref,
        ordinary_corrections=correction_ref,
        current_immutable_git=CURRENT,
        subjects=rows,
        conflict_subjects=[row["subject"] for row in rows if row["merge_conflicts"]],
        scope="One temporary sparse three-way composition for imminent25 adoption; Git immutable current24 source only, no live Main/caller/source lock/import, no permanent mirror. Any actual adoption must freshly match source under EX after original24 actual native+normalcollectionSTOP.",
        Main_Git_index_Cargo_docs_native_model_RAW_RNG_test_writes_or_replay=0,
        source_leases=[],
        remaining_temporary=[],
        host_future_quiet=False,
    )
    with (OUT / "prepared-merge.json").open("x") as stream:
        json.dump(document, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(subjects=len(rows), conflicts=document["conflict_subjects"])))


if __name__ == "__main__":
    main()
