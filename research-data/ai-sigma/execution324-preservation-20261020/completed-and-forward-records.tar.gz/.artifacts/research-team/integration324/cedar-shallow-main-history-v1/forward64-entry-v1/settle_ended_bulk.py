"""Replace the stopped bulk forecast with actual produced data, retaining an analysis tail."""

import datetime
import fcntl
import importlib.util
import json
from pathlib import Path

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PREVIOUS = ROOT / ".artifacts/research-team/integration324/cedar-wall-path-work-v1"


def main():
    loader = importlib.util.spec_from_file_location(
        "normal_phase_metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/normal208-entry-v1/issue_support.py",
    )
    prior = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(prior)
    capacity = json.loads((PREVIOUS / "normal104-entry-v1/capacity-and-holding.json").read_bytes())
    stop_path = (
        ROOT
        / ".worktree/assets/perf/cedar-wall-path-work-v1/collection-v1/native-normal-source-STOP.json"
    )
    stop = json.loads(stop_path.read_bytes())
    assert (
        stop["job_id"] == "aae9d572-b153-4718-90c1-73f1b1468198"
        and not stop["source_leases_remaining"]
        and not stop["owned_scientific_processes_remaining"]
    )
    assert stop["directwait_reaped"] and stop["handles_complete"]
    for row in stop["actual_native_controllers_parent_submit_identities"]:
        assert identity(process_info(row["identity"]["pid"])) != identity(row["identity"])
    bulk_root = ROOT / ".worktree/assets/perf/cedar-wall-path-work-v1/normal-effect-v1"
    # This was a fresh future namespace at the issue point, created only by the new run.
    # Its four producers and readers have stopped; the separate saved-analysis writer
    # is excluded and remains an ordinary-work tail, not falsely declared finished.
    actual = prior.point([bulk_root])
    ordinary_tail = 32 * 1024**2
    refined = capacity["actual_ended_point"]["allocated_B"] + actual["allocated_B"] + ordinary_tail
    assert refined < capacity["whole_B"]
    cover = capacity["new_known_cover_B"] - capacity["whole_B"] + refined
    target = (
        ROOT
        / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/target"
    )
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert not (target / "debug").exists() and not (target / "release").exists()
        packet = dict(
            at=datetime.datetime.now(datetime.UTC).isoformat(),
            status="ACTUAL26_BULK_STOPPED_HOLDING_REFINED_ANALYSIS_STILL_PENDING",
            actual_native_collection_STOP=prior.ref(stop_path),
            ended_bulk_root=str(bulk_root),
            actual_ended_bulk_point=actual,
            preentry_ordinary_scope_B=capacity["actual_ended_point"]["allocated_B"],
            preentry_capacity=prior.ref(PREVIOUS / "normal104-entry-v1/capacity-and-holding.json"),
            original_whole_B=capacity["whole_B"],
            ordinary_analysis_control_tail_B=ordinary_tail,
            refined_stored_and_remaining_tail_B=refined,
            known_cover_after_refinement_B=cover,
            head_to_decimal50GB_B=50000000000 - cover,
            target_profiles_absent=[str(target / "debug"), str(target / "release")],
            scope="One ended native/normal producer subtree point only, not full OWN/old source/analysis/global walk. Ordinary ongoing saved analysis is NOT complete and not assigned an advance microbudget; tail is conservative accounting only, not an output cap or gate. Later final full-root point replaces overlapping baseline/bulk/tail once, never adds them again.",
            science_calls_USED=104,
            science_census_gate="PENDING saved rows, no custody=usable inference",
            refund_loan_unusednode_reset=0,
            later_tails_globalactual_fullfees="UNKNOWN",
            host_future_quiet=False,
        )
        with (OUT / "ended26-bulk-basis.json").open("x") as stream:
            json.dump(packet, stream, indent=2)
            stream.write("\n")
    print(
        json.dumps(
            {
                k: packet[k]
                for k in [
                    "status",
                    "actual_ended_bulk_point",
                    "known_cover_after_refinement_B",
                    "head_to_decimal50GB_B",
                ]
            }
        )
    )


if __name__ == "__main__":
    main()
