"""Bind only the new history software to the existing serial BUILD owners."""

import argparse
import copy
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OLD = ROOT / ".artifacts/research-team/integration324/cedar-lazy-smp-v1/software-v1"
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(OUT / name)


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["prefix", "remaining", "release"], required=True)
    parser.add_argument("--seconds", type=int, required=True)
    args = parser.parse_args()
    loader = importlib.util.spec_from_file_location(
        "actual_shallow_history_BUILD", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    old = json.loads((OLD / "build-intent-v7.json").read_bytes())
    adopted_path = OUT.parent / "source-adoption-v1/actual-adoption.json"
    actual = json.loads(adopted_path.read_bytes())
    assert actual["status"] == "SPARSE_MAIN_SOURCE_ADOPTED_NEW_SOFTWARE_PENDING"
    python = json.loads((OUT / "new-Python-one-STOP.json").read_bytes())
    assert (
        python["status"] == "NEW_ONE_CANONICAL_METADATA_DEFINITION_PASS"
        and python["actual_return"]["exit_code"] == 0
    )
    assert git("diff", "--cached", "--name-only") == b""
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        source = copy.deepcopy(old["source"])
        patch = OUT / f"actual-foreign-source-{args.stage}.patch"
        with patch.open("xb") as stream:
            stream.write(git("diff", "--binary", "--no-ext-diff", "--no-textconv", "HEAD", "--"))
        source.update(
            commit=git("rev-parse", "HEAD").decode().strip(),
            patch=ref(patch),
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        assert source["untracked_inputs"] == []
        assert not git(
            "ls-files",
            "--others",
            "--exclude-standard",
            "--",
            "Cargo.toml",
            "Cargo.lock",
            ".cargo",
            "crates",
        )
        for witness in source["cargo_configs"]:
            path = Path(witness["path"])
            witness["file"] = ref(path) if path.exists() else None
        adoption = dict(
            schema="quoridor.research.source-adoption.v1",
            status="ACCEPTED",
            issue="quoridor-4lc.324.25",
            source=source,
            actual_fixed_source_adoption=ref(adopted_path),
            new_Python_one=ref(OUT / "new-Python-one-STOP.json"),
            limits="Source-only acceptance and new affected software, not performance or scientific/model qualification; oldsuccessfultests not replayed",
        )
        if args.stage in {"remaining", "release"}:
            repair_path = OUT.parent / "failed-boundary-adoption-v1/actual-repair.json"
            repair = json.loads(repair_path.read_bytes())
            assert repair["status"] == "ADOPTED_COMPILER_PROVEN_OPTIONAL_FIELD_FIXTURE_ONLY"
            adoption["actual_compiler_fixture_repair"] = ref(repair_path)
            receipt_path = OUT / "operation-prefix/prefix-result.json"
            receipt = json.loads(receipt_path.read_bytes())
            assert [x["status"] for x in receipt["checks"]] == ["PASS", "PASS", "PASS", "FAILED"]
            adoption["prior_software"] = dict(
                subjects=[ref(ROOT / row["subject"]) for row in actual["subjects"]]
                + [ref(Path(repair["post"]["path"]))],
                receipts=[
                    dict(name=x["name"], file=ref(receipt_path)) for x in receipt["checks"][:3]
                ],
            )
            if args.stage == "release":
                remaining_path = OUT / "operation-remaining/prefix-result.json"
                remaining = json.loads(remaining_path.read_bytes())
                assert (
                    remaining["status"] == "PASS_TEST_LINT_PREFIX_ONLY"
                    and remaining["cleanup_complete"]
                )
                assert len(remaining["checks"]) == 3 and all(
                    x["status"] == "PASS" for x in remaining["checks"]
                )
                adoption["prior_software"]["receipts"] += [
                    dict(name=x["name"], file=ref(remaining_path)) for x in remaining["checks"]
                ]
        adoption_ref = save(f"build-source-adoption-{args.stage}.json", adoption)
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
        )
        support = save(
            f"resources-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.25",
                authority=adoption_ref,
                resources=dict(
                    worker_cpu=12,
                    guardian_cpu=16,
                    test_cpu_cores=[12, 14, 16],
                    native_threads=1,
                    GPU=0,
                    family_RAM_B=4 * 1024**3,
                    controller_included=True,
                    controller_B=64 * 1024**2,
                    host_reserve_B=4 * 1024**3,
                ),
                storage_budget=None,
                actual_cache_retirement=ref(OUT / "cache-retirement-v1/return.json"),
                scope="Ordinary Rootserial software, no microstorage or numerical grant. Actual newRust5 exactnonzero+affectedClippy prefix, then genuine release-only suffix retaining successfulchecks. Freshmaintained runtimephysical/RAM/source/origin/cancel/cleanup mandatory.",
            ),
        )
        target = Path(old["target"])
        marker = target / ".research-owner.json"
        previous = json.loads(marker.read_bytes())
        assert previous["writer"] == WRITER and previous["target"] == str(target)
        save(f"prior-target-marker-{args.stage}.json", previous)
        old_handover = json.loads((OLD / "target-handover-v7.json").read_bytes())
        assert not Path(old_handover["old_target"]).exists()
        handover = save(
            f"target-handover-{args.stage}.json",
            dict(
                schema="research.target-handover.v1",
                status="HANDED_OVER",
                target=str(target),
                target_writer=WRITER,
                shared_serial_pool=True,
                old_target=old_handover["old_target"],
                fresh_private_root=str(OUT / f"private-image-{args.stage}"),
                owned_remaining=[],
                test_cpu_cores=[12, 14, 16],
                actual_previous_software_STOP=ref(
                    OUT / "first-prefix-failure-collection-v1/completion-and-STOP.json"
                )
                if args.stage in {"remaining", "release"}
                else actual["actual24_native_collection_STOP"],
                actual_source_adoption=ref(adopted_path),
                scope="Rootsingle serial target, actualoldnative/software STOP; no futurehostquiet",
            ),
        )
        selectors_path = (
            ROOT
            / ".worktree/assets/perf/cedar-shallow-main-history-v1/ordinary-corrections-v1/new-test-plan.json"
        )
        selectors = json.loads(selectors_path.read_bytes())
        assert (
            ref(selectors_path)["sha256"]
            == "51bb7da291ba031fba813e548e380eb31ea48d229ccc05dba4c1f0c8460b19ae"
        )
        cargo = old["tools"]["CARGO"]["file"]["path"]
        commands = []
        if args.stage in {"prefix", "remaining"}:
            for number, row in enumerate(selectors["Rust"], 1):
                if args.stage == "remaining" and number <= 3:
                    continue
                commands.append(
                    dict(
                        name=f"shallow-history-new-Rust-{number}",
                        role="test",
                        argv=[
                            cargo,
                            "test",
                            "--offline",
                            "--locked",
                            "--manifest-path",
                            str(ROOT / "Cargo.toml"),
                            "-j1",
                            "--message-format=json-render-diagnostics",
                            "-p",
                            row["package"],
                            "--features",
                            "research-diagnostics"
                            if row["package"] == "quoridor-ai"
                            else "measurement,quoridor-inference/claustrophobia",
                            "--lib",
                            row["selector"],
                            "--",
                            "--exact",
                            "--nocapture",
                            "--test-threads=1",
                        ],
                    )
                )
            lint = next(
                copy.deepcopy(x)
                for x in json.loads((OLD / "build-intent-v1.json").read_bytes())["commands"]
                if x["role"] == "lint"
            )
            lint["name"] = "shallow-history-affected-Clippy"
            if "--keep-going" not in lint["argv"]:
                lint["argv"].insert(2, "--keep-going")
            commands.append(lint)
        release = copy.deepcopy(old["commands"][0])
        assert release["role"] == "build"
        release["name"] = "shallow-history-genuine-release"
        commands.append(release)
        spec = copy.deepcopy(old)
        for key in ("admission", "intent_sha256"):
            spec.pop(key, None)
        spec.update(
            output=str(OUT / f"operation-{args.stage}"),
            support=support,
            source_adoption=adoption_ref,
            target_handover=handover,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / f"private-image-{args.stage}/quoridor-runner"),
            TMP=str(OUT / f"build-TMP-{args.stage}"),
            test_cpu_cores=[12, 14, 16],
            command_timeout_seconds=args.seconds,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        marker.write_text(
            json.dumps(
                dict(writer=WRITER, target=str(target), support_sha256=support["sha256"]), indent=2
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            f"build-admission-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Actualsource/ordinarysoftwarebinding only; fresh runtimecontrols mandatory",
            ),
        )
        intent = save(f"build-intent-{args.stage}.json", spec)
        helper = (
            OLD / "run_prefix_checks.py"
            if args.stage == "prefix"
            else OUT / "run_remaining_checks.py"
            if args.stage == "remaining"
            else ROOT / "scripts/dev/research-lifecycle.py"
        )
        argv = [str(lc.project_python()), "-B", str(helper)]
        if args.stage == "release":
            argv.append("build")
        argv += ["--intent", intent["path"], "--sha256", intent["sha256"]]
        save(
            f"job-{args.stage}.json",
            dict(
                issue="quoridor-4lc.324",
                goal_issue="quoridor-4lc.324",
                thread_id="01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                cwd=str(ROOT),
                argv=argv,
                end_at=None,
                notify_until=None,
                max_runtime_seconds=args.seconds + 60,
                control_interval_seconds=30,
                notify_interval_seconds=10,
                request_timeout_seconds=25,
                log_max_bytes=16384,
                resource_contract=support["path"],
            ),
        )
        print(json.dumps(dict(intent=intent, stage=args.stage, actual_job=None, source_leases=[])))


if __name__ == "__main__":
    main()
