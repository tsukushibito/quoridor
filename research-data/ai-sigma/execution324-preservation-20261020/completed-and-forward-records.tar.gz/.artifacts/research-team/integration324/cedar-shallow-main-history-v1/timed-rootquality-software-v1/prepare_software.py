"""Bind candidate-one software only after actual Root adoption and numerical STOP."""

import argparse
import copy
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
CONTROL = (
    ROOT
    / ".artifacts/research-team/integration324/cedar-lazy-smp-followup-v1/replacement-v1/software-v1"
)
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
SELECTOR = (
    "alphabeta::neighbour_opportunity::tests::"
    "timed_root_quality_real_callee_admission_isolation_and_error_restore_nn0"
)


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def save(name, document):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(document, stream, indent=2)
        stream.write("\n")
    return ref(path)


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["prefix", "release"], required=True)
    parser.add_argument("--seconds", type=int, required=True)
    args = parser.parse_args()
    # This real adoption receipt is deliberately required; no future placeholder intent.
    adopted_path = OUT.parent / "timed-rootquality-adoption-v1/actual-adoption.json"
    adopted = json.loads(adopted_path.read_bytes())
    assert adopted["status"] == "SPARSE_MAIN_SOURCE_ADOPTED_NEW_SOFTWARE_PENDING"
    assert adopted["issue"] == "quoridor-4lc.324.25.3"
    actual27_stop = adopted["actual27_native_collection_STOP"]
    assert ref(Path(actual27_stop["path"])) == actual27_stop
    control_path = CONTROL / "operation-release/manifest.json"
    assert (
        ref(control_path)["sha256"]
        == "982166c75c8fc8c9f6c6dd0ab0840c0cb3e51267bb44949916a1af622c0a3575"
    )
    template = json.loads((CONTROL / "build-intent-release.json").read_bytes())
    loader = importlib.util.spec_from_file_location(
        "timed_rootquality_build", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    assert git("diff", "--cached", "--name-only") == b""
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        source = copy.deepcopy(template["source"])
        patch = OUT / f"actual-foreign-source-{args.stage}.patch"
        with patch.open("xb") as stream:
            stream.write(git("diff", "--binary", "--no-ext-diff", "--no-textconv", "HEAD", "--"))
        source.update(
            commit=git("rev-parse", "HEAD").decode().strip(),
            patch=ref(patch),
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        assert not source["untracked_inputs"]
        assert not git(
            "ls-files",
            "--others",
            "--exclude-standard",
            "--",
            "Cargo.toml",
            "Cargo.lock",
            ".cargo",
            "crates",
        )
        for witness in source["cargo_configs"]:
            path = Path(witness["path"])
            witness["file"] = ref(path) if path.exists() else None
        adoption = dict(
            schema="quoridor.research.source-adoption.v1",
            status="ACCEPTED",
            issue="quoridor-4lc.324.25.3",
            source=source,
            actual_fixed_source_adoption=ref(adopted_path),
            genuine_control_BUILD=ref(control_path),
            limits="New timed-rootquality real-callee boundary only; source-only review is not software/performance qualification. No old successful suite replay.",
        )
        if args.stage == "release":
            prefix_path = OUT / "operation-prefix/prefix-result.json"
            prefix = json.loads(prefix_path.read_bytes())
            assert prefix["status"] == "PASS_TEST_LINT_PREFIX_ONLY" and prefix["cleanup_complete"]
            assert len(prefix["checks"]) == 2 and all(
                row["status"] == "PASS" for row in prefix["checks"]
            )
            adoption["prior_software"] = dict(
                subjects=[ref(ROOT / row["subject"]) for row in adopted["subjects"]],
                receipts=[
                    dict(name=row["name"], file=ref(prefix_path)) for row in prefix["checks"]
                ],
            )
        adoption_ref = save(f"build-source-adoption-{args.stage}.json", adoption)
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
        )
        support = save(
            f"resources-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.25.3",
                authority=adoption_ref,
                resources=dict(
                    worker_cpu=12,
                    guardian_cpu=16,
                    test_cpu_cores=[12, 14, 16],
                    native_threads=1,
                    GPU=0,
                    family_RAM_B=4 * 1024**3,
                    controller_included=True,
                    controller_B=64 * 1024**2,
                    host_reserve_B=4 * 1024**3,
                ),
                storage_budget=None,
                actual27_native_collection_STOP=actual27_stop,
                scope="Ordinary serial software, no microstorage or numerical grant; actual holding/capacity and maintained runtime source/physical/RAM/cancel/cleanup remain mandatory.",
            ),
        )
        target = Path(template["target"])
        marker = target / ".research-owner.json"
        previous = json.loads(marker.read_bytes())
        assert previous["writer"] == WRITER and previous["target"] == str(target)
        save(f"prior-target-marker-{args.stage}.json", previous)
        old_handover = json.loads((CONTROL / "target-handover-release.json").read_bytes())
        assert not Path(old_handover["old_target"]).exists()
        previous_stop = (
            actual27_stop
            if args.stage == "prefix"
            else ref(OUT / "prefix-collection-v1/completion-and-STOP.json")
        )
        handover = save(
            f"target-handover-{args.stage}.json",
            dict(
                schema="research.target-handover.v1",
                status="HANDED_OVER",
                target=str(target),
                target_writer=WRITER,
                shared_serial_pool=True,
                old_target=old_handover["old_target"],
                fresh_private_root=str(OUT / f"private-image-{args.stage}"),
                owned_remaining=[],
                test_cpu_cores=[12, 14, 16],
                actual_previous_software_STOP=previous_stop,
                actual_source_adoption=ref(adopted_path),
                scope="Actual compatible stopped lifetime, not future host quiet",
            ),
        )
        cargo = template["tools"]["CARGO"]["file"]["path"]
        commands = []
        if args.stage == "prefix":
            commands = [
                dict(
                    name="timed-rootquality-new-Rust-one",
                    role="test",
                    argv=[
                        cargo,
                        "test",
                        "--offline",
                        "--locked",
                        "--manifest-path",
                        str(ROOT / "Cargo.toml"),
                        "-j1",
                        "--message-format=json-render-diagnostics",
                        "-p",
                        "quoridor-ai",
                        "--features",
                        "research-diagnostics",
                        "--lib",
                        SELECTOR,
                        "--",
                        "--exact",
                        "--nocapture",
                        "--test-threads=1",
                    ],
                ),
                dict(
                    name="timed-rootquality-affected-Clippy",
                    role="lint",
                    argv=[
                        cargo,
                        "clippy",
                        "--keep-going",
                        "--offline",
                        "--locked",
                        "--manifest-path",
                        str(ROOT / "Cargo.toml"),
                        "-j1",
                        "--message-format=json-render-diagnostics",
                        "-p",
                        "quoridor-ai",
                        "--features",
                        "research-diagnostics",
                        "--all-targets",
                        "--no-deps",
                        "--",
                        "-Dwarnings",
                    ],
                ),
            ]
        release = copy.deepcopy(template["commands"][0])
        assert release["role"] == "build"
        release["name"] = "timed-rootquality-genuine-release"
        commands.append(release)
        spec = copy.deepcopy(template)
        for key in ("admission", "intent_sha256"):
            spec.pop(key, None)
        spec.update(
            output=str(OUT / f"operation-{args.stage}"),
            support=support,
            source_adoption=adoption_ref,
            target_handover=handover,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / f"private-image-{args.stage}/quoridor-runner"),
            TMP=str(OUT / f"build-TMP-{args.stage}"),
            test_cpu_cores=[12, 14, 16],
            command_timeout_seconds=args.seconds,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        marker.write_text(
            json.dumps(
                dict(writer=WRITER, target=str(target), support_sha256=support["sha256"]), indent=2
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            f"build-admission-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Software binding only; genuine runtime guard admission remains mandatory",
            ),
        )
        intent = save(f"build-intent-{args.stage}.json", spec)
        argv = [
            str(lc.project_python()),
            "-B",
            str(OUT / "run_new_boundary.py")
            if args.stage == "prefix"
            else str(ROOT / "scripts/dev/research-lifecycle.py"),
        ]
        if args.stage == "release":
            argv.append("build")
        argv += ["--intent", intent["path"], "--sha256", intent["sha256"]]
        save(
            f"job-{args.stage}.json",
            dict(
                issue="quoridor-4lc.324",
                goal_issue="quoridor-4lc.324",
                thread_id="01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                cwd=str(ROOT),
                argv=argv,
                end_at=None,
                notify_until=None,
                max_runtime_seconds=args.seconds + 60,
                control_interval_seconds=30,
                notify_interval_seconds=10,
                request_timeout_seconds=25,
                log_max_bytes=16384,
                resource_contract=support["path"],
            ),
        )
        print(json.dumps(dict(stage=args.stage, intent=intent, actual_job=None, source_leases=[])))


if __name__ == "__main__":
    main()
