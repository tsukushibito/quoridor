"""Preserve ended comparison evidence byte-exactly without scientific replay."""

import collections
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import tarfile

ROOT = Path("/workspaces/quoridor")
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"
NAMES = [
    "cedar-value-head-detail-v1",
    "cedar-ordering-quality-v1",
    "cedar-lazy-smp-v1",
    "cedar-history-score-v1",
    "cedar-lazy-smp-node-publication-v1",
    "cedar-shallow-main-history-v1",
    "cedar-wall-path-work-v1",
    "cedar-lazy-smp-followup-v1",
]
OWN = ROOT / ".worktree/assets/perf"
OPS = ROOT / ".artifacts/research-team/integration324"
ALLOWED = [base / name for base in (OWN, OPS) for name in NAMES]
BLOCKED_PARTS = {
    "TMP",
    "__pycache__",
    ".git",
    "target",
    "node_modules",
    "collect-TMP",
    "prepare-TMP",
}


def excluded(path):
    return (
        any(
            part in BLOCKED_PARTS or part.startswith("private-image") or part.endswith("-TMP")
            for part in path.parts
        )
        or path.suffix in {".lock", ".tmp", ".pid", ".pyc"}
        or path.name in {"credentials", "config.toml.secret", "quoridor-runner"}
        or path.name.startswith(".env")
    )


def files_below(path):
    if not path.exists():
        return []
    result = []
    for directory, dirs, files in os.walk(path):
        dirs[:] = [
            name
            for name in dirs
            if not excluded(Path(directory) / name) and not (Path(directory) / name).is_symlink()
        ]
        for name in files:
            p = Path(directory) / name
            if not excluded(p) and not p.is_symlink() and p.is_file():
                result.append(p)
    return result


def allowed(path):
    return any(path.is_relative_to(base) for base in ALLOWED) and not excluded(path)


def refs(value):
    if isinstance(value, dict):
        if isinstance(value.get("path"), str) and all(key in value for key in ("sha256", "bytes")):
            yield value
        for item in value.values():
            yield from refs(item)
    elif isinstance(value, list):
        for item in value:
            yield from refs(item)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_archive(name, paths, scope):
    paths = sorted(set(paths))
    rows = []
    logical = sum(p.stat().st_size for p in paths)
    assert logical < 256 * 1024**2, (name, logical)
    archive = DEST / name
    with (
        archive.open("xb") as raw,
        gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=6, mtime=0) as zipped,
        tarfile.open(fileobj=zipped, mode="w|") as tar,
    ):
        for path in paths:
            before = path.stat()
            assert stat.S_ISREG(before.st_mode) and not path.is_symlink()
            member = str(path.relative_to(ROOT))
            info = tar.gettarinfo(str(path), arcname=member)
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            sha = digest(path)
            with path.open("rb") as source:
                tar.addfile(info, source)
            after = path.stat()
            assert (before.st_ino, before.st_size, before.st_mtime_ns, before.st_mode) == (
                after.st_ino,
                after.st_size,
                after.st_mtime_ns,
                after.st_mode,
            ), member
            rows.append(
                dict(
                    member=member,
                    source=str(path),
                    bytes=before.st_size,
                    mode=f"{stat.S_IMODE(before.st_mode):04o}",
                    sha256=sha,
                )
            )
    expected = {row["member"]: row for row in rows}
    verified = 0
    with tarfile.open(archive, "r|gz") as tar:
        for member in tar:
            row = expected[member.name]
            h = hashlib.sha256()
            stream = tar.extractfile(member)
            assert stream is not None
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                h.update(block)
            assert (
                h.hexdigest() == row["sha256"]
                and member.size == row["bytes"]
                and member.mode == int(row["mode"], 8)
            )
            verified += 1
    assert verified == len(rows)
    record = dict(
        archive=name,
        sha256=digest(archive),
        bytes=archive.stat().st_size,
        original_logical_B=logical,
        members=rows,
        full_stream_restore_hash_mode_verified=True,
        scope=scope,
    )
    (DEST / (name + ".manifest.json")).write_text(
        json.dumps(record, ensure_ascii=False, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                key: record[key]
                for key in (
                    "archive",
                    "bytes",
                    "original_logical_B",
                    "full_stream_restore_hash_mode_verified",
                )
            }
        )
    )


def main():
    selected = {
        "cedar-value-head-detail-v1": ["numeric-v2", "effect-numeric-v1"],
        "cedar-ordering-quality-v1": ["numeric-v1"],
        "cedar-lazy-smp-v1": ["numeric-v1", "normal208-runtime-v2"],
        "cedar-history-score-v1": ["normal26-saved-analysis-v1", "normal26-runtime-v2"],
        "cedar-lazy-smp-node-publication-v1": [
            "numeric-v1",
            "numeric-games-v1",
            "numeric-games-v2",
            "normal208-runtime-v1",
            "normal64-runtime-v4",
            "normal64-runtime-v5",
        ],
        "cedar-shallow-main-history-v1": [
            "normal104-collection-v1",
            "corrected-entry-trial-v1",
            "protocol-v1",
        ],
        "cedar-wall-path-work-v1": [
            "normal-effect-v1",
            "collection-v1",
            "analysis-v1",
            "actual-entry-v1",
            "effect-preparation-v2",
            "current-history-preparation-v1",
        ],
        "cedar-lazy-smp-followup-v1": [
            "numeric-v1",
            "normal208-runtime-v1",
            "replacement-v1",
            "current25-control-binding-v1",
        ],
    }
    evidence = set()
    for name, directories in selected.items():
        for directory in directories:
            evidence.update(files_below(OWN / name / directory))
    # Operator code, software commands/qualifiers and failures are historical
    # records; generated executable/cache payloads are deliberately excluded.
    for name in NAMES:
        evidence.update(files_below(OPS / name))
    for name in (
        "cedar-lazy-smp-review-v1",
        "cedar-history-score-review-v1",
        "cedar-lazy-smp-node-publication-review-v1",
        "cedar-shallow-main-history-review-v1",
        "cedar-lazy-smp-followup-review-v1",
    ):
        evidence.update(files_below(OWN / name))
    evidence.update(files_below(OWN / "cedar-wall-path-work-review-v1/final-result-v1"))
    evidence.add(Path(__file__).resolve())
    evidence.add(Path(__file__).resolve().with_name("archive_guard.py"))
    controls = collections.deque(
        p
        for p in evidence
        if p.suffix == ".json"
        and p.stat().st_size <= 4 * 1024**2
        and any(
            token in p.name
            for token in (
                "manifest",
                "blocks",
                "materialized",
                "completion",
                "binding",
                "protocol",
                "intent",
                "settings",
                "source",
                "prepared",
            )
        )
    )
    visited = set()
    while controls:
        path = controls.popleft()
        if path in visited:
            continue
        visited.add(path)
        try:
            value = json.loads(path.read_bytes())
        except (ValueError, UnicodeError):
            continue
        for reference in refs(value):
            target = Path(reference["path"])
            if (
                target.is_absolute()
                and allowed(target)
                and target.is_file()
                and not target.is_symlink()
                and target not in evidence
            ):
                evidence.add(target)
                if (
                    target.suffix == ".json"
                    and target.stat().st_size <= 4 * 1024**2
                    and any(
                        token in target.name
                        for token in (
                            "manifest",
                            "blocks",
                            "materialized",
                            "completion",
                            "binding",
                            "protocol",
                            "intent",
                            "settings",
                            "source",
                            "prepared",
                        )
                    )
                ):
                    controls.append(target)
    # These are ordinary generated public opening inputs, never teacher/model
    # payloads or the sealed NewE/oldfits96 material.
    book = (
        ROOT
        / ".worktree/assets/inputs/nnue-learning-scale432-v1/arena-candidates-v1/native-arena-book.json"
    )
    assert book.stat().st_size == 248299
    evidence.add(book)
    write_archive(
        "completed-and-forward-records.tar.gz",
        evidence,
        "Ended20/21/22/23/24/25.3/26/27 results, conditions and required byte records; forward25.3/27 controls are prospective UNENTERED, not completed science. No RAW/scientific decoder, validator, model, native, compiler or RNG executed; opaque copy and byte restoration only. Models/library/executable/private image payloads excluded, fixed inputs by reference except one shared ordinary opening book.",
    )
    pending = files_below(OWN / "cedar-root-split-v1")
    for name in (
        "minimum-source-result.json",
        "control.json",
        "reader-STOP.json",
        "finalization.json",
        "finalizer-returned-STOP.json",
    ):
        p = OWN / "cedar-root-split-review-v1" / name
        if p.exists():
            pending.append(p)
    for name in (
        "root-split-followup-contract.txt",
        "root-split-actual-task.txt",
        "root-split-diagnostic-review-task.txt",
    ):
        pending.append(OPS / name)
    write_archive(
        "unqualified-root-diagnostic-source.tar.gz",
        pending,
        "Fixed28 root-child work diagnostic source69752f35/sourceclear only, AI1/RunnerLIB1 UNBUILT_UNTYPED_UNRUN; no root-split prototype or native/diagnostic/comparison entry at this preservation boundary. Kept separate from completed science.",
    )
    backup = ROOT / "scripts/dev/research-lifecycle.py.orig"
    write_archive(
        "legacy-untracked-source-backup.tar.gz",
        [backup],
        "Previously foreign untracked .orig is not an active caller. Preserve exact bytes without creating a maintained legacy source path; original local backup left untouched.",
    )
    (DEST / "preservation-status.json").write_text(
        json.dumps(
            dict(
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                issue="quoridor-4lc.324",
                actual_STOP="26 native/normal3521f9cb and analysis/finalizercc8b619f/8224f390 returned before archive IO; no fair native active",
                no_source_or_scientific_replay=True,
                excluded="DB/locks/secrets/private model/weights/executable/build/target/dependency cache and sealed NewE/oldfits96; existing models/libs remain exact external references",
                unfinished="25.3/27 games remain UNENTERED;28 diagnostic source SOURCE_ONLY/new definitions UNRUN; no root prototype or games rights",
                archive_members_use_original_project_relative_paths=True,
                copy_only_no_old_source_data_removed=True,
                archive_restore_checks="All archive member original bytes/mode matched by full stream SHA verification; no scientific parsing/recalculation",
            ),
            ensure_ascii=False,
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
