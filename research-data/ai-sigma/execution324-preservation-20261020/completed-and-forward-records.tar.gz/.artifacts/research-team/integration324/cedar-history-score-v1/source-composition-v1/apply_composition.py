"""Resolve the six concrete merge conflicts and apply the sparse delta once."""

import difflib
import fcntl
import json
import re
import subprocess

from prepare_composition import ROOT, OUT, sections, sha


def resolve(name, ours, theirs):
    if name.endswith("alphabeta.rs"):
        if ours.strip() == "const SMP: bool = false,":
            return ours + theirs
        if ours.startswith("impl<const OBSERVE"):
            return "impl<const OBSERVE: bool, const TRACE: bool, const OPPORTUNITY: bool, const SMP: bool, const HISTORY: bool>\n    Search<'_, OBSERVE, TRACE, OPPORTUNITY, SMP, HISTORY>\n"
        if ours.startswith("fn search_in_table_observed<"):
            return ours.replace(
                "    const SMP: bool,\n", "    const SMP: bool,\n    const HISTORY: bool,\n"
            )
        assert "let first_depth" in ours
        return ours.replace(
            "Search::<OBSERVE, TRACE, OPPORTUNITY, SMP>",
            "Search::<OBSERVE, TRACE, OPPORTUNITY, SMP, HISTORY>",
        )
    if name.endswith("neighbour_opportunity.rs"):
        return theirs.replace(
            "::<false, false, true, true>", "::<false, false, true, false, true>"
        ).replace("::<false, false, true, false>", "::<false, false, true, false, false>")
    assert name.endswith("measurement.rs")
    return ours + theirs


def main():
    preparation = json.loads((OUT / "preparation.json").read_bytes())
    expected = {x["path"]: x for x in preparation["files"]}
    pattern = re.compile(
        r"<<<<<<< adopted-SMP\n(.*?)\|\|\|\|\|\|\| immutable-before\n.*?=======\n(.*?)>>>>>>> reviewed-history\n",
        re.S,
    )
    changes, rows = [], []
    lock_path = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for name, hunks in sections((OUT / "candidate.patch").read_text()):
            path = ROOT / name
            current = path.read_text() if path.exists() else ""
            assert (sha(current.encode()) if path.exists() else None) == expected[name][
                "actual_SMP_before_sha256"
            ]
            base = current.splitlines(keepends=True)
            merged, last = [], 0
            for start, old, new in hunks:
                assert start >= last and base[start : start + len(old)] == old
                merged.extend(base[last:start])
                merged.extend(new)
                last = start + len(old)
            merged.extend(base[last:])
            merged = "".join(merged)
            assert sha(merged.encode()) == expected[name]["proposed_composed_sha256"]
            text, count = pattern.subn(lambda m: resolve(name, m[1], m[2]), merged)
            assert count == expected[name]["conflict_count"]
            assert "<<<<<<<" not in text and ">>>>>>>" not in text
            if name.endswith("alphabeta.rs"):
                assert text.count("search_in_table_observed::<false, false, false, true>(") == 1
                assert text.count("search_in_table_observed::<OBSERVE, TRACE, false, false>(") == 1
                text = text.replace(
                    "search_in_table_observed::<false, false, false, true>(",
                    "search_in_table_observed::<false, false, false, true, false>(",
                ).replace(
                    "search_in_table_observed::<OBSERVE, TRACE, false, false>(",
                    "search_in_table_observed::<OBSERVE, TRACE, false, false, false>(",
                )
                assert text.count("for depth in first_depth..=limits.max_depth") == 1
                assert "o.iteration(depth);" in text
            changes.extend(
                difflib.unified_diff(
                    current.splitlines(keepends=True),
                    text.splitlines(keepends=True),
                    fromfile="a/" + name if path.exists() else "/dev/null",
                    tofile="b/" + name,
                )
            )
            rows.append(
                dict(
                    path=name,
                    actual_before_sha256=sha(current.encode()) if path.exists() else None,
                    composed_after_sha256=sha(text.encode()),
                    resolved_conflicts=count,
                )
            )
        patch = OUT / "actual-composed.patch"
        with patch.open("x") as stream:
            stream.write("".join(changes))
        with (OUT / "actual-composition-intent.json").open("x") as stream:
            json.dump(
                dict(
                    files=rows,
                    generic_order=["OBSERVE", "TRACE", "OPPORTUNITY", "SMP", "HISTORY"],
                    diagnostic_route_SMP=False,
                    main_helper_route_HISTORY=False,
                    worker_first_depth_and_main_authority_preserved=True,
                    new_tail_modules="both retained, no algorithm rewrite",
                    software_status="UNBUILT_UNTYPED_UNRUN",
                ),
                stream,
                indent=2,
            )
            stream.write("\n")
        applied = subprocess.run(
            ["patch", "--batch", "--forward", "--fuzz=0", "-p1", "-i", str(patch)],
            cwd=ROOT,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        with (OUT / "actual-patch-return.json").open("x") as stream:
            json.dump(
                dict(
                    returncode=applied.returncode,
                    stdout=applied.stdout.decode(),
                    stderr=applied.stderr.decode(),
                    directwait_reaped=True,
                    handles_closed=True,
                ),
                stream,
                indent=2,
            )
            stream.write("\n")
        assert (
            applied.returncode == 0
            and b"offset" not in applied.stdout
            and b"fuzz" not in applied.stdout
        )
        for row in rows:
            assert sha((ROOT / row["path"]).read_bytes()) == row["composed_after_sha256"]
        with (OUT / "actual-composition-return.json").open("x") as stream:
            json.dump(
                dict(
                    status="ACTUAL_MAIN_SPARSE_COMPOSITION_APPLIED_SOFTWARE_UNRUN",
                    files=rows,
                    source_leases=[],
                    source_Cargo_EX_NB_released_on_return=True,
                    old_proof_or_test_replayed=0,
                    model_foreign_changes=0,
                ),
                stream,
                indent=2,
            )
            stream.write("\n")
    print(
        json.dumps(
            dict(
                files=len(rows),
                conflicts_resolved=sum(x["resolved_conflicts"] for x in rows),
                actual_Main_sparse_apply=True,
                software_PASS=False,
            )
        )
    )


if __name__ == "__main__":
    main()
