"""Prepare only the sparse history delta against actual adopted SMP source."""

import difflib
import fcntl
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-history-score-v1"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def sections(raw):
    lines = raw.splitlines(keepends=True)
    at = 0
    while at < len(lines):
        assert lines[at].startswith("--- ") and lines[at + 1].startswith("+++ b/")
        name = lines[at + 1][6:].strip()
        at += 2
        hunks = []
        while at < len(lines) and lines[at].startswith("@@ "):
            match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", lines[at])
            assert match is not None
            start, count = int(match[1]), int(match[2] or 1)
            at += 1
            old, new = [], []
            while at < len(lines) and not lines[at].startswith(("@@ ", "--- ")):
                row = lines[at]
                assert row[:1] in {" ", "+", "-"}
                if row[:1] in {" ", "-"}:
                    old.append(row[1:])
                if row[:1] in {" ", "+"}:
                    new.append(row[1:])
                at += 1
            assert len(old) == count and len(new) == int(match[4] or 1)
            hunks.append((max(start - 1, 0), old, new))
        yield name, hunks


def main():
    binding_raw = (OWN / "source-v5/binding.json").read_bytes()
    assert sha(binding_raw) == "c5da01123c36dede1dff32b8e7323820b3c6e15a587680daa34cacfd639b6d74"
    binding = json.loads(binding_raw)
    patch = (OWN / "source-v5/forward.patch").read_bytes()
    assert sha(patch) == "656afd8627fc9315b50455eda86128b4f5ef4039680de48874c65132d15d2cf3"
    results, changes, conflict_sections = [], [], []
    lock_path = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock_path.open("a") as lock, tempfile.TemporaryDirectory(dir=OUT / "TMP") as temporary:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for name, hunks in sections(patch.decode()):
            expected = binding["files"][name]
            if expected["before"] is None:
                before = ""
            else:
                command = subprocess.run(
                    ["git", "show", binding["revision"] + ":" + name],
                    cwd=ROOT,
                    check=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )
                before = command.stdout.decode()
                assert sha(command.stdout) == expected["before"]["sha256"]
            base = before.splitlines(keepends=True)
            their, last = [], 0
            for start, old, new in hunks:
                assert start >= last and base[start : start + len(old)] == old
                their.extend(base[last:start])
                their.extend(new)
                last = start + len(old)
            their.extend(base[last:])
            their = "".join(their)
            assert sha(their.encode()) == expected["post"]["sha256"]
            path = ROOT / name
            current = path.read_text() if path.exists() else ""
            temp = Path(temporary)
            for label, value in (("current", current), ("base", before), ("history", their)):
                (temp / label).write_text(value)
            merged = subprocess.run(
                [
                    "git",
                    "merge-file",
                    "-p",
                    "--diff3",
                    "-L",
                    "adopted-SMP",
                    "-L",
                    "immutable-before",
                    "-L",
                    "reviewed-history",
                    str(temp / "current"),
                    str(temp / "base"),
                    str(temp / "history"),
                ],
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            assert 0 <= merged.returncode < 128, merged.stderr.decode()
            text = merged.stdout.decode()
            conflicts = text.count("<<<<<<< adopted-SMP")
            assert bool(conflicts) == bool(merged.returncode)
            if conflicts:
                conflict_sections.append(
                    dict(
                        path=name,
                        chunks=re.findall(
                            r"<<<<<<< adopted-SMP\n.*?>>>>>>> reviewed-history\n", text, re.S
                        ),
                    )
                )
            changes.extend(
                difflib.unified_diff(
                    current.splitlines(keepends=True),
                    text.splitlines(keepends=True),
                    fromfile="a/" + name if path.exists() else "/dev/null",
                    tofile="b/" + name,
                )
            )
            results.append(
                dict(
                    path=name,
                    actual_SMP_before_sha256=sha(current.encode()) if path.exists() else None,
                    reviewed_history_post_sha256=sha(their.encode()),
                    proposed_composed_sha256=sha(merged.stdout),
                    conflict_count=conflicts,
                    merge_exit=merged.returncode,
                )
            )
    (OUT / "candidate.patch").write_text("".join(changes))
    with (OUT / "conflicts.json").open("x") as stream:
        json.dump(conflict_sections, stream, indent=2)
        stream.write("\n")
    with (OUT / "preparation.json").open("x") as stream:
        json.dump(
            dict(
                status="COMPOSITION_CANDIDATE_ONLY_NOT_MAIN_APPLIED",
                files=results,
                Main_writes=0,
                software_execution=0,
                source_leases=[],
                temporary_copies_retained=0,
            ),
            stream,
            indent=2,
        )
        stream.write("\n")
    print(
        json.dumps(
            dict(
                files=len(results),
                conflicts=sum(x["conflict_count"] for x in results),
                Main_writes=0,
            )
        )
    )


if __name__ == "__main__":
    main()
