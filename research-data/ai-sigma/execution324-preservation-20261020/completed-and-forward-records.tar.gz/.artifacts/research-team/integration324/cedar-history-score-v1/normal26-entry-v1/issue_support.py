"""Issue the original history observation at the completed SMP timing boundary."""

import datetime
import fcntl
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-history-score-v1"
SMP = ROOT / ".worktree/assets/perf/cedar-lazy-smp-v1/numeric-v1"
MIB = 1024**2


def write(name, document):
    with (OUT / name).open("x") as stream:
        json.dump(document, stream, indent=2)
        stream.write("\n")
    return helpers.ref(OUT / name)


loader = importlib.util.spec_from_file_location(
    "root_saved_metadata_helpers",
    ROOT
    / ".artifacts/research-team/integration324/cedar-lazy-smp-v1/normal208-entry-v1/issue_support.py",
)
helpers = importlib.util.module_from_spec(loader)
loader.loader.exec_module(helpers)


def main():
    native_stop = SMP / "collection-v1/native-and-normal-collection-STOP.json"
    helpers.checked(
        native_stop, "40e979d75a3e71de3359190ea5edecddebc5c28c32c7451f6e34545b97d7f63c", 5938
    )
    final_stop = SMP / "analysis-v1/returned-source-analysis-admin-STOP.json"
    helpers.checked(
        final_stop, "ec4bb7f3c21af00209940e6d5f8c3a60a7dfc1935348096cf33b7046ac81aeee", 15016
    )
    holding_path = SMP / "analysis-v1/actual-retained-holding.json"
    holding = helpers.checked(
        holding_path, "f3540fdfcea12a29752c9aee6cea572cba91f4502ac7449607e50407a66f90da", 575
    )
    prep_path = OWN / "normal-observation-preparation-v3/binding.json"
    helpers.checked(
        prep_path, "c5bf35568e38e69bb97d8941a47b91000aa05b01cb9478c402762c256dd0af3d", 3798
    )
    forecast_path = OWN / "normal-observation-preparation-v3/holding-forecast.json"
    forecast = helpers.checked(
        forecast_path, "744931e14aab47a79aa453e8b6160cc50a8bfcc4194df222a554b5fe19b772d5", 1664
    )
    previous_release = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-v1/normal208-entry-v1/current-source-and-software-release.json"
    )
    release = json.loads(previous_release.read_bytes())
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a+"
    ) as stream:
        fcntl.flock(stream, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for caller in release["current_four_callers"]:
            assert helpers.ref(caller["path"]) == caller
        release.update(
            at=datetime.datetime.now(datetime.UTC).isoformat(),
            inherited_source_software_release=helpers.ref(previous_release),
            actual_SMP_native_and_normal_collection_STOP=helpers.ref(native_stop),
            actual_SMP_analysis_admin_STOP=helpers.ref(final_stop),
            evaluation="HISTORY26_UNENTERED; original SMP208 exhausted",
            qualification="Retained Rust11/Python2/affectedClippy/release software; history3Rust/Python1 included, not replayed",
        )
        current_release = write("current-source-and-software-release.json", release)
        fcntl.flock(stream, fcntl.LOCK_UN)
    roots = [str(OWN), str(OUT)]
    actual = helpers.point(roots)
    whole = 160 * MIB
    future = forecast["new_forward_subtotal_B"]
    margin = whole - actual["allocated_B"] - future
    assert margin > 0, (actual, margin)
    prior_cover = 49860523008 - holding["original_whole_B"] + holding["allocated_B"]
    assert prior_cover + whole <= 50000000000
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize > whole
    capacity = write(
        "capacity-and-holding.json",
        dict(
            ended_SMP_holding=helpers.ref(holding_path),
            ended_SMP_whole_B=holding["original_whole_B"],
            actual_SMP_retained_B=holding["allocated_B"],
            prior_known_cover_after_ended_SMP_settlement_B=prior_cover,
            directed_history_roots=roots,
            actual_history_point=actual,
            future_history_B=future,
            whole_B=whole,
            forecast_margin_B=margin,
            new_known_cover_B=prior_cover + whole,
            remaining_to_decimal50GB_B=50000000000 - prior_cover - whole,
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            scope="Replace ONE ended SMP whole with actual retained once, then issue ONE history whole. No scientific refund/loan/recharge/global inventory",
            readonly_model_image_library_copy_B=0,
            later_tails_globalactual_fullfees="UNKNOWN",
        ),
    )
    template = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-ordering-quality-v1/normal26-entry-v1/phase-support.json"
    )
    support = json.loads(template.read_bytes())
    for key in (
        "fixed_plan",
        "result_before_analysis_recipe",
        "holding_correction",
        "original64_support",
        "total_original_nodes",
        "holding_forecast",
        "prior_known_cover_B",
        "new_known_cover_B",
        "remaining_to_decimal50GB_B",
        "timeout_resolution",
        "source_quality",
    ):
        support.pop(key, None)
    support.update(
        issue="quoridor-4lc.324.23",
        status="ISSUED_ORIGINAL_HISTORY26_AT_ACTUAL_SMP_STOP",
        prepared=helpers.ref(prep_path),
        observation_spec=helpers.ref(OWN / "observation-spec-v1.json"),
        current_source_adoption=current_release,
        actual_source_STOP=current_release,
        actual_software_STOP=release["actual_software_STOP"],
        actual_SMP_native_and_collection_STOP=helpers.ref(native_stop),
        actual_SMP_analysis_admin_STOP=helpers.ref(final_stop),
        whole_B=whole,
        roots=roots,
        storage_budget=dict(whole_B=whole, roots=roots),
        owned_B=whole,
        free_B=margin,
        native_aggregate_B=32 * MIB,
        per_record_B=MIB,
        total_original_calls=26,
        total_original_nodes=26000000,
        same_colour_sessions=6,
        search_threads=1,
        capacity_basis=capacity,
        fixed_conditions="Cedar35cbb/ControlOffShadow+rootquality/history selected6main+2continuation; existing gravity/update/age/TT/PVS/LMR unchanged; same26 chronological requests, no omitted predecessor/refill/games",
        output_contract="Native32MiB/record1MiB; LC settings1MiB + measurements32MiB + result32MiB; serialTMP8/log4/analysis16/control8MiB, current real normal serializer preflight required",
        normal_remaining_inputs="Actual canonical factory/Plan/numerical_fields/current4/environment/origin/end_at/fresh physicalSMT-peer/RAM-host4/ownerpausecancel/fullroot/free/storage/native cleanup admission. Source clear is not native qualification",
        source_quality="Selected-entry bounded diagnostic only. Result-aware six cases, ring128+eviction/allmatching deltas; root main and internal continuation distinct, UNKNOWN not imputed",
        allocation="One serial N1 worker12/main0/outer18, launch0,12,18. No overlap with SMP fair clock, which actually ended. No substantial source/Cargo/native/ML/RAW during actual history native+normalcollection STOP",
    )
    support["limits"].update(owned_B=whole, free_B=margin)
    support_ref = write("phase-support.json", support)
    write(
        "issued-inputs.json",
        dict(
            release=current_release,
            phase_support=support_ref,
            capacity=capacity,
            source_leases=[],
            evaluation="HISTORY26_UNENTERED",
        ),
    )
    print(
        json.dumps(
            dict(
                status="ISSUED",
                whole_B=whole,
                actual_point=actual,
                margin_B=margin,
                new_known_cover_B=prior_cover + whole,
            )
        )
    )


if __name__ == "__main__":
    main()
