"""Apply only the concrete compiler repair against current canonical owners."""

import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-history-score-v1/visibility-fix-v1"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    binding_ref = ref(OWN / "binding.json")
    assert (
        binding_ref["sha256"] == "dc3b7f33ecdde56db4bf6a1c099c448e8136143008312cba43850fdf0525bf42"
    )
    binding = json.loads((OWN / "binding.json").read_bytes())
    assert ref(Path(binding["forward"]["path"])) == binding["forward"]
    rows = []
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for subject in [
            dict(path=binding["target"], before=binding["before"], post=binding["post"])
        ]:
            path = ROOT / subject["path"]
            before = ref(path)
            assert all(before[key] == subject["before"][key] for key in ("sha256", "bytes", "mode"))
            assert ref(Path(subject["post"]["path"])) == subject["post"]
            rows.append(
                dict(
                    path=str(path),
                    before=before,
                    accepted_post=subject["post"],
                    affected_sites="Seven method visibility qualifiers and formatter wrapping only; bodies and argument types unchanged",
                )
            )
        py_stop = json.loads(
            (
                ROOT
                / ".artifacts/research-team/integration324/cedar-lazy-smp-v1/software-v1/new-Python-two-STOP.json"
            ).read_bytes()
        )
        assert ref(ROOT / "scripts/dev/research-lifecycle.py")["sha256"] == py_stop["source_sha256"]
        applied = subprocess.run(
            ["patch", "--batch", "--forward", "--fuzz=0", "-p1", "-i", binding["forward"]["path"]],
            cwd=ROOT,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        with (OUT / "actual-patch-return.json").open("x") as stream:
            json.dump(
                dict(
                    returncode=applied.returncode,
                    stdout=applied.stdout.decode(),
                    stderr=applied.stderr.decode(),
                    directwait_reaped=True,
                    handles_closed=True,
                ),
                stream,
                indent=2,
            )
            stream.write("\n")
        assert (
            applied.returncode == 0
            and b"offset" not in applied.stdout
            and b"fuzz" not in applied.stdout
        )
        for row in rows:
            after = ref(Path(row["path"]))
            assert all(
                after[key] == row["accepted_post"][key] for key in ("sha256", "bytes", "mode")
            )
            row["actual_after"] = after
    with (OUT / "actual-adoption.json").open("x") as stream:
        json.dump(
            dict(
                status="ACTUAL_HISTORY_VISIBILITY_REPAIR_ADOPTED_COMPILER_VERIFICATION_UNRUN",
                binding=binding_ref,
                subjects=rows,
                source_Cargo_EX_NB_released=True,
                source_leases=[],
                Python_two_evidence_retained_not_replayed=True,
                outside_added_fixture_line="Saved bodies/type correspondence reused; actual canonical-before/post checked. No type widening or lint allows",
                old_failure_preserved=True,
                additional_review_or_scientific_rights=0,
                model_or_foreign_changes=0,
            ),
            stream,
            indent=2,
        )
        stream.write("\n")
    print(
        json.dumps(
            dict(
                subjects=len(rows),
                exact_sites=sum(len(x["affected_sites"]) for x in rows),
                software_or_new_test_PASS=False,
            )
        )
    )


if __name__ == "__main__":
    main()
