"""Run the one cache retirement with the existing bounded child owner."""

import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import CycleResources, execute, identity, process_info

out = Path(__file__).resolve().parent
temporary = out / "TMP"
temporary.mkdir()
deadline = time.monotonic() + 120
config = {"max_memory_bytes": 1024**3 - 64 * 1024**2, "host_ram_reserve": 4 * 1024**3}
resources = CycleResources(config, out, deadline)
environment = dict(os.environ, TMPDIR=str(temporary), CUDA_VISIBLE_DEVICES="")
try:
    result = execute(
        [sys.executable, "-B", str(out / "adopt.py")],
        out / "execution.log",
        deadline,
        cpu_core=0,
        resources=resources,
        cwd="/workspaces/quoridor",
        env=environment,
    )
    assert result["exit_code"] == 0 and result["cleanup_complete"]
    assert identity(process_info(result["child"]["pid"])) != result["child"]
    temporary.rmdir()
    with (out / "guard-return.json").open("x") as stream:
        json.dump(
            {"actual_return": result, "TMP": [], "source_leases": [], "host_future_quiet": False},
            stream,
            indent=2,
        )
        stream.write("\n")
    print(
        json.dumps(
            {
                "exit_code": result["exit_code"],
                "seconds": result["wall_seconds"],
                "cleanup": result["cleanup_complete"],
            }
        )
    )
finally:
    if temporary.exists() and not any(temporary.iterdir()):
        temporary.rmdir()
