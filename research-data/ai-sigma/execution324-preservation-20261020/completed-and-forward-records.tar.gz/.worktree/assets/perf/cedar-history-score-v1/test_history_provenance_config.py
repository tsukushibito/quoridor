"""New NN0 definition, UNRUN until Root adopts the actual canonical owner."""

import copy
import importlib.util
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent


class HistoryProvenanceConfigBoundary(unittest.TestCase):
    def test_selected_entries_are_bounded_typed_and_default_absent(self):
        spec = importlib.util.spec_from_file_location(
            "history_score_canonical_lifecycle",
            ROOT / "scripts/dev/research-lifecycle.py",
        )
        owner = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = owner
        spec.loader.exec_module(owner)
        config = {
            "roots": [
                {
                    "input": 0,
                    "pointer": "/rows/0",
                    "field": "prefix",
                    "label": "synthetic",
                }
            ],
            "profile": "control",
            "tt_entries": 1048576,
            "use_tt": True,
            "use_pvs": True,
            "lmr": True,
            "lmr_method": "depth_rank",
            "neighbour_opportunity": "off_shadow",
            "root_ordering_quality": True,
            "zero_stock_safe_race": True,
            "zero_stock_safe_race_method": "path_tail",
            "namespace": {
                "evaluator": "synthetic-NN0",
                "rules": "synthetic-rules",
                "selectivity": "synthetic",
            },
            "output_bytes": 1048576,
            "record_bytes": 1048576,
        }
        requests = [
            {"id": "one", "session": "one", "root": 0, "depth": 64, "node_cap": 1000000}
        ]
        experiment = {
            "config": {},
            "schedule": {},
            "rules": "synthetic-rules",
            "inputs": [{}],
        }

        def validate(candidate):
            with patch.object(owner, "document", side_effect=[candidate, requests]):
                return owner.measurement_config(experiment)

        default, _ = validate(config)
        self.assertNotIn("history_provenance", default)
        selected = json.loads((OWN / "observation-spec-v1.json").read_text())[
            "selectors"
        ]
        watch = [
            {k: v for k, v in s.items() if k not in {"case_root", "basis"}}
            for s in selected
        ]
        good = dict(config, history_provenance=watch)
        actual, _ = validate(good)
        self.assertEqual(actual["history_provenance"], watch)
        failures = [None, [], watch + watch[:1], [watch[0], watch[0]]]
        for key, value in [
            ("colour", True),
            ("colour", 2),
            ("action", 209),
            ("from_cell", 0),
            ("extra", 0),
        ]:
            bad = copy.deepcopy(watch)
            bad[0][key] = value
            failures.append(bad)
        bad = copy.deepcopy(watch)
        bad[-1]["lag"] = 5
        failures.append(bad)
        for bad in failures:
            with self.assertRaises(owner.Refused):
                validate(dict(config, history_provenance=bad))
        with self.assertRaises(owner.Refused):
            validate(dict(good, root_ordering_quality=False))
        with self.assertRaises(owner.Refused):
            validate(dict(config, lmr_recipe=None))


if __name__ == "__main__":
    unittest.main()
