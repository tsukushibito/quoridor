"""Bind retained history controls and submit once via maintained normal owners."""

import copy
from datetime import datetime, timedelta, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys


ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
RUNTIME = OWN / "normal26-runtime-v2"
ACTOR = "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0"
ISSUED = (
    ROOT
    / ".artifacts/research-team/integration324/cedar-history-score-v1/normal26-entry-v1/issued-inputs.json"
)


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def read(path):
    return json.loads(path.read_bytes())


def document(reference):
    path = Path(reference["path"])
    assert ref(path) == reference
    return read(path)


def save(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


def prepare():
    assert ref(ISSUED) == dict(
        path=str(ISSUED),
        sha256="956dd33c886f7b20f9b16457c6394a363de91fadc8f8b1f1bd043a146ee8870a",
        bytes=929,
        mode="0644",
    )
    issued = read(ISSUED)
    support = document(issued["phase_support"])
    release = document(issued["release"])
    document(issued["capacity"])
    manifest = document(release["software_manifest"])
    assert manifest["artifact"] == release["artifact"]
    draft = OWN / "post-SMP-bindings-v4"
    assert (
        ref(draft / "binding.json")["sha256"]
        == "eaff9e248eb442229440bc297819d0988811dcbce23a4c4dcc0ce0267333dd86"
    )
    settings = read(draft / "sequence.draft.json")
    run = settings["runs"][0]
    experiment = document(run["experiment"])
    experiment["canonical_plan_sha256"] = ""
    experiment["argv"] = [
        release["artifact"]["path"],
        "measure",
        "--experiment",
        "@EXPERIMENT@",
        "--experiment-sha256",
        "@EXPERIMENT_SHA256@",
    ]
    before = copy.deepcopy(experiment)
    prior_prepared = read(OWN / "observation-preparation-v2/prepared.json")
    prior = document(prior_prepared["original_numerical_qualification"])
    RUNTIME.mkdir(exist_ok=False)
    parent = Path(run["data_root"]).parent
    parent.mkdir(parents=True, exist_ok=True)
    assert all(not os.path.lexists(run[k]) for k in ("output", "data_root", "TMP"))
    callers = release["current_four_callers"]
    fd = os.open(
        ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock",
        os.O_RDONLY | os.O_NOFOLLOW,
    )
    acquired = None
    try:
        fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
        acquired = datetime.now(timezone.utc).isoformat()
        assert all(ref(Path(r["path"])) == r for r in callers)
        loader = importlib.util.spec_from_file_location(
            "history23_normal_owner", callers[0]["path"]
        )
        lc = importlib.util.module_from_spec(loader)
        loader.loader.exec_module(lc)
        numerical = lc.numerical_fields(experiment, manifest)
        for key, value in numerical.items():
            if key not in ("artifact_sha256", "config_sha256"):
                assert value == prior[key], key
        numerical.update(
            original_evidence=prior.get(
                "original_evidence", prior_prepared["original_numerical_qualification"]
            ),
            correspondence_only=True,
            scope="Inherited641ca structural normal correspondence only; no new model/policy/parity qualification",
            source_owner=callers[0],
            actual_software_Build=release["software_manifest"],
            new_model_or_head_calls=0,
        )
        nr = save(RUNTIME / "numerical-000.json", numerical)
        experiment["numerical_qualification"] = nr
        config, requests = lc.measurement_config(experiment)
        spec = document(support["observation_spec"])
        assert config["history_provenance"] == [
            {k: v for k, v in x.items() if k not in ("case_root", "basis")}
            for x in spec["selectors"]
        ]
        assert len(requests) == 26 and len({r["session"] for r in requests}) == 6
        assert (
            config["neighbour_opportunity"] == "off_shadow"
            and config["root_ordering_quality"]
        )
        er = save(RUNTIME / "experiment-000.json", experiment)
        run.update(
            experiment=er,
            artifact=release["artifact"],
            support=issued["phase_support"],
            limits=copy.deepcopy(support["limits"]),
            caller_sources=callers,
            owned_outputs=support["roots"],
            command_timeout_seconds=900,
            approved_plan=None,
        )
        run["argv"] = [
            release["artifact"]["path"],
            "measure",
            "--experiment",
            er["path"],
            "--experiment-sha256",
            er["sha256"],
        ]
        settings["limits"] = copy.deepcopy(support["limits"])
        run["env"]["PATH"] = "/home/vscode/.local/bin:" + run["env"]["PATH"]
        assert lc.caller_source_refs(run, experiment) == callers
        assert lc.issued_family_upper(run, support) == 4294967296
        assert sorted(str(p) for p in lc.charged_roots(run)) == sorted(support["roots"])
        assert list(lc.operation_order(settings)) == [("run", 0)]
        assert {
            k: v for k, v in experiment.items() if k != "numerical_qualification"
        } == {k: v for k, v in before.items() if k != "numerical_qualification"}
        assert all(ref(Path(r["path"])) == r for r in callers)
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)
    released = datetime.now(timezone.utc).isoformat()
    sr = save(RUNTIME / "settings.json", settings)
    job = read(draft / "job.draft.json")
    job.update(
        argv=[
            sys.executable,
            "-B",
            callers[0]["path"],
            "sequence",
            "--intent",
            sr["path"],
            "--sha256",
            sr["sha256"],
        ],
        resource_contract=sr["path"],
    )
    jr = save(RUNTIME / "job-template.json", job)
    result = save(
        RUNTIME / "materialized.json",
        dict(
            status="MATERIALIZED_NOT_ADMITTED",
            issued=ref(ISSUED),
            settings=sr,
            job_template=jr,
            numerical=nr,
            source_adoption=issued["release"],
            support=issued["phase_support"],
            current_callers=callers,
            SH_acquired_at=acquired,
            SH_released_at=released,
            source_leases_remaining=[],
            actual_native_calls=0,
            plan="Existing compare/measure owner uses approved_plan=None/canonical_plan_sha256 empty; fixed observation Plan remains v3/spec byref, no invented arena Plan",
            state_dir=str(OWN / "normal-observation-v1/parent-runtime-v1"),
            launch_affinity=[0, 12, 18],
            parent_accepted_s=1200,
            command_s=1140,
            fresh_admission="Existing originating_job/physical_and_quiet/Limits/experiment_check own actual entry, not this metadata receipt",
        ),
    )
    print(json.dumps(result))


def submit():
    materialized = read(RUNTIME / "materialized.json")
    settings = document(materialized["settings"])
    state = Path(materialized["state_dir"])
    assert not state.exists() and not Path(settings["output"]).exists()
    assert materialized["source_leases_remaining"] == []
    for phase in ("normal26-materialize-v2", "normal26-pre-submit-v1"):
        receipt = read(OWN / phase / "return.json")
        assert (
            receipt["exit_code"] == 0
            and receipt["direct_child_reaped"]
            and receipt["handle_closes_complete"]
            and receipt["remaining"] == []
        )
    run = settings["runs"][0]
    assert all(not os.path.lexists(run[k]) for k in ("output", "data_root", "TMP"))
    job = document(materialized["job_template"])
    at = datetime.now(timezone.utc)
    job["end_at"] = (at + timedelta(seconds=1200)).isoformat()
    job_ref = save(RUNTIME / "job-entry-v1.json", job)
    argv = [
        "taskset",
        "-c",
        "0,12,18",
        "bash",
        "scripts/dev/project-env.sh",
        "bash",
        "scripts/dev/research-job.sh",
        "submit",
        "--config",
        job_ref["path"],
        "--state-dir",
        str(state),
    ]
    intent = save(
        RUNTIME / "submit-intent-v1.json",
        dict(
            at=at.isoformat(),
            argv=argv,
            config=job_ref,
            source=ref(Path(__file__)),
            direct_Popen_outside_Cycle=True,
            source_leases_remaining=[],
            actual_native_START="UNKNOWN",
            support=materialized["support"],
        ),
    )
    env = {**os.environ, **run["env"], "BEADS_ACTOR": ACTOR}
    env.pop("TMPDIR", None)
    with subprocess.Popen(
        argv, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate()
        code = child.wait()
    for name, body in (("submit.stdout", stdout), ("submit.stderr", stderr)):
        with (RUNTIME / name).open("xb") as stream:
            stream.write(body)
    result = save(
        RUNTIME / "submit-return-v1.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            intent=intent,
            returncode=code,
            directwait_reaped=True,
            pipes_closed=child.stdout.closed and child.stderr.closed,
            launcher_pid=child.pid,
            stdout=ref(RUNTIME / "submit.stdout"),
            stderr=ref(RUNTIME / "submit.stderr"),
            actual_native_START="UNKNOWN",
        ),
    )
    print(
        json.dumps(
            dict(
                returned=result,
                returncode=code,
                stdout=stdout.decode(errors="replace"),
                stderr=stderr.decode(errors="replace"),
            )
        )
    )
    assert code == 0


if __name__ == "__main__":
    {"prepare": prepare, "submit": submit}[sys.argv[1]]()
