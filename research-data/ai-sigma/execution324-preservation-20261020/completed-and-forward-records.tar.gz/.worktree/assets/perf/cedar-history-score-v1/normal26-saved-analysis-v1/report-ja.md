# 324.23 選択history entryの構成と更新由来

元26要求を6つの同色・時系列sessionで一度観測した。normal manifest/dataはPASS、26件すべて公開され、parent復元も26/26で成立した。実消費は25,000,193 nodes。Searchの停止内訳はNodeLimit 25件、DepthComplete 1件であり、公開PASSと探索完了を混同しない。外側38.31414707598742秒、受理から終了40.259938秒をそれぞれの意味で保存し、内側native34.21442058397224秒は加算しない。

6例は元21の結果を見て選んだ診断例で、代表的な頻度推定ではない。監視は固定6 main＋2 continuation entryのみ。新規対局・solver・teacher・候補実装・追加Searchはない。元21の結果は置き換えない。

## rootの負scoreと更新は区別して追えた

通常rootのsearch-local pathは空なので、下表の全snapshotでlag1/2/3/4/6はすべてNone、scoreは厳密に2×mainである。main keyは壁ならcolour/wall ID、駒ならcolour/from/toで、盤面や残壁ごとの専用entryではない。rankはそのsnapshotの全保護tier込みの順位。

| root/action | 選択理由              | 呼出し開始main | 最後の完成snapshot: depth / rank / main / score | 呼出し全体の正更新件数・実delta | 負更新件数・実delta | 呼出し終了main |
| ----------- | --------------------- | -------------: | ----------------------------------------------- | ------------------------------: | ------------------: | -------------: |
| 14/壁207    | 元の負main・rank94    |           -144 | 6 / 94 / -429 / -858                            |                        5 / +326 |            7 / -461 |           -279 |
| 15/駒47     | 別の負main・順位変化  |            -32 | 9 / 7 / -32 / -64                               |                     438 / +6000 |            4 / -134 |           5834 |
| 19/壁97     | 正mainのordinary対照  |          12483 | 6 / 4 / 11506 / 23012                           |                     717 / +4990 |         101 / -4420 |          13053 |
| 23/壁206    | 負mainでもTT/PV先頭   |            -32 | 5 / 1 / -48 / -96                               |                     365 / +6455 |          47 / -1627 |           4796 |
| 7/駒20      | 正mainの先頭対照      |          15660 | 6 / 1 / 15660 / 31320                           |                          1 / +1 |            9 / -279 |          15382 |
| 0/駒13      | 初期sessionの先頭対照 |              0 | 5 / 1 / 32 / 64                                 |                   1525 / +13151 |             1 / -27 |          13124 |

呼出し終了値にはpending iteration中の更新も含む。完成snapshotのscoreへ、呼出し全体のdeltaをそのまま割り当てない。たとえばroot14はdepth6開始時のmain−429から、pending depth7開始時−295、呼出し終了時−279へ変化した。完成選択・pending順序・最終entryは別の時点である。

root14/壁207の同session内の履歴は、root12で0→−112、root13で−112→−144、root14で−144→−279だった。root14の負更新7件は深さ1/2/3が3/2/2件、実deltaは−48/−128/−285。更新元nodeの残壁7/8/9/10に対応する実deltaは−96/−64/−285/−16だった。したがって浅い返却済み手への罰則が、この共有main entryの負方向の変化に実際に寄与したことは分かる。どの罰則が棋力上有害だったかは分からない。

gravityのbonusと実deltaは同じではない。保存eventの一例はroot15/駒47でbefore5634、bonus−64、after5548、実delta−86。別の正更新はbefore12612、bonus+16、after12616、実delta+4だった。集計にはbonus総和ではなく実before/after差を用いた。全26×8 entryの呼出し内balanceは保存値で成立し、age由来deltaは0だった。

## reduction・確認・windowの証拠範囲

root14の該当main entryについて、当該呼出しのreduced-and-unconfirmed負更新は0件だった。従って「LMRで浅く返った未確認fail-lowへの罰則がroot14のrank94を作った」という説明は、この観測では支持されない。

一方、固定8 entry全体の負更新2514件中、該当counterが1件あった。root15で壁207のmainへ実delta−246が記録されたもので、root14より後の呼出しである。これを前のroot14の原因にはできない。その個別eventはringから退避しており、before/afterの各値・window・ply・cutoff winnerはUNKNOWNのままにする。

保存された直近eventには、実際のdepth、stock、ply、distinct rank、reduced/reduction、full-depth confirmation、PVS research、親window/最終実window/返却値のbit列、return classとcutoff winnerを保持した。たとえばroot6の壁207罰則はdepth1/ply5/stock18、rank85、bonus−16、before−16→after−32、reduced=false、return_class=fail_low。全8 entryの直近負event279件はreduced=falseで、278件fail_low、1件in_windowだった。full_depth_confirmed=falseを、未減深の手まで「不正な未検証」とは解釈しない。

直近ringは各呼出し128件まで。全体で2461件を保持し、123308件が退避された。totalsにはすべての一致更新の件数・実delta・深さ/stock別罰則が残るが、退避eventのwindow/ply別分類やsnapshot直前までの全event列は復元できない。特にroot14の該当mainの直近eventは0件である。この欠落を0更新とは扱わない。

## interior continuationはroot scoreではない

| 固定entry                           | 対象呼出しのentry開始→終了 | 正/負更新件数と実delta | 実score読取の例                                                                                   |
| ----------------------------------- | -------------------------- | ---------------------- | ------------------------------------------------------------------------------------------------- |
| colour0, lag1, previous207→action20 | root14: 2645→3232          | 正5/+587、負0          | ply1/stock9: 2×main16352＋lag1 2645＝35349。後の別nodeはply5/stock8、2×(−48)+3232−48+0+2886＝5974 |
| colour0, lag2, previous97→action109 | root19: 143→3000           | 正53/+2961、負3/−104   | ply2/stock9: 2×6516−96+143＝13079。後の読取はply2/stock8、2×12282+208+3000＝27772                 |

first/last readは異なるnodeで、同一局面の前後比較ではない。駒のmainはそのnodeのfrom/to keyなので、action IDだけで監視main entryと同一視しない。これらのcontinuationは実際にinterior scoreへ寄与したが、root14/壁207やroot19/壁97のroot scoreへ足されたわけではない。通常rootへ前の対局手をseedする根拠・実装指示にもならない。

## 結論と次の問い

負mainは共有entryの浅い通常罰則と重み付きroot scoreとして説明でき、正mainの対照にも多数の浅い罰則がある。TT/PV保護も負scoreより先に働く。rank94や深い完成選択だけでは誤り・反復バイアス・原因・棋力改善を認定できず、今回から採用できる具体的改善は未確立である。

低費用の次の問いを一つに絞るなら、「実際にreducedかつfull-depth未確認で返った手への負history更新を区別することが、cutoff有用性を保ちながら役立つか」である。今回は該当1件の存在までを確認したにすぎず、頻度の一般化や無罰則化の採用根拠ではない。実装・重み調整・追加観測・対局は発行しない。通常の浅い罰則を一律に消す根拠もない。

有効root数はsession内で最大6、age passは0。16回を強制しない。呼出し内reset eventは0で、session開始に伴う初期化と混同しない。初期化前の個別entry由来、未訪問node、退避eventの詳細、反実仮想の順位/探索費用/棋力はUNKNOWN。observer込み時計は速度認定に用いない。

詳細は[collection](collection.json)、[6ケース](selected-cases.json)、[entry集計](entry-summaries.json)、[呼出しごとのprojection](call-projections.json)、[保存された限定event](retained-selected-events.json)。全26件は消化済みで、refill・新candidate・history/ordering/LMR/model/default変更はない。費用・FAILED・NULL・全pause/seal・外国所有・decimal50GBを維持する。
