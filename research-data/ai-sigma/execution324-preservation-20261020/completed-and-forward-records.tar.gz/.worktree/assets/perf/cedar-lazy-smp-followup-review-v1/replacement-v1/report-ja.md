# 27.1 writer-neutral shared-TT retention：限定source結果

固定binding `e10f977d1b39eec508c68bf2bdd1a632562209d178236fc0dd357466cded5905`、post `4df5ee53e954f961fdea456a5d3ba07a643e2cbc9457675ccebaef1efaa6319a` に対し、SOURCE_CLEAR、essential 0／ordinary 0。

変更は `SharedTable::insert` の same-generation・strictly-deeper 保護からwriter一致条件を外す一点。固定postの66–83行で、LOCAL側の既存generation/depth条件と対応する。64-slot striped trylockで読む／書くwhole entry、拒否時に保持する元writer情報、容量・counter・lock・allocationは変更されない。

保存されたoutside-owner対応を再用し、必要なimmutable Git `dc46543f8e2363a74afbae02470bf17be258beca` のprobeとgeneration callerだけを確認した。full Key不一致はprobeで拒否する。weighted history／context／model-selectivity namespaceのownerは不変。内部の数値利用はlegal best、context一致、同depthとtyped Boundを必要とし、違うcontext／horizonはordering情報に留まる。ApproxLeaf／SafeRaceLeafは既存の別入口・no-best・depth／value条件を保持し、新Bound優先順位を導入しない。

同depthは置換し、別generationなら深いcollisionも置換できる。実iterationは既存の `next_generation` を呼び、root間のworker drain、wrap回避、fatal error時のpool停止・quiet clearは不変。これは永久deep pinを作らない。各writerのgenerationが全体として時間順であるという保証は加えない。default1／LOCAL1、completed-node出版条件、main-only public completion、stagger、PVS／LMR／Cedar／数学／全worker node budgetも保護範囲である。

新single Rust selectorは定義の静的確認だけで、UNBUILT／UNTYPED／UNRUN。5種Bound、別history、同depth、別generation collision、clearの提案coverageを確認したが、実assertionのPASSとは扱わない。旧成功suite、sourceproof、target import、compiler、native、model、RAW、RNGの実行は0。

効果、歴史的原因、性能、棋力、旧image N1 parity、runtime安定性は未資格。公平な2thread control／candidateの真正image、Rootによる現行ownerへの疎合成と実software・normal admission・supportは別工程であり、このsource結果は科学枠を発行しない。native default1を維持する。

固定refs、必要なimmutable ownerのblob／行範囲、minimum、control、実readerSTOPと配送receiptはこの同一OWN内に保存した。既知の本人reader/helperはdirectwait/reap・handles閉鎖・fresh exact PID/start/boot不在を記録し、TMP／source leaseは作成していない。light delivery・後続adminは別lifetimeであり、全hostや未来のquietを主張しない。

全USERPAUSE、seals、models／weights／defaults、foreign、元FAILED／NULL／UNKNOWN費、decimal50GB、取消consultation8を保持する。Root actual acceptanceまでは本人27.1をin_progressとし、report／close／ACKを他工程のgateにしない。
