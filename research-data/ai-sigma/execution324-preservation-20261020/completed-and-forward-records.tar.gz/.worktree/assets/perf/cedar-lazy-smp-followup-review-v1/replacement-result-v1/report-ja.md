# 27.2 原first-factor208：有限解釈とforward64 gate

固定protocol `dcc01585ec4a8cd879415b8744e1b3c01e4a7c99bdf5e6ec875198cffe519d36`、producer completion `0f9bebc633f44482e890b9cb71c124f51812d5624c8da0fa87757edbb3ccc67b` に対し、CONCLUSION_CLEAR、essential 0／ordinary 0。この結果はfirst208と固定forward64 gateの限定確認であり、未実施64局の結論ではない。

保存された8 normal manifest／data PASS、208 calls／48 main sessions、19,159,225 aggregate nodesを資格refsで再用する。fixed-depth104は全てDepthComplete。clock104は100 TimeLimit＋4 DepthCompleteで、horizonのUNKNOWNを消さない。保存されたfull-weighted root history／STM／合法root action／PV先頭対応／finite bits／main-only権限／parent restore／work accounting／quietを有限観測として扱う。後続PV child全ての合法性、cutoff snapshot、D64／fullwidth oracle、全fault／kernel parityやphysical NNを認定しない。

Search sumsはcontrol0.328074833／0.316615910秒、candidate0.340400386／0.356706557秒。保存された合計比1.081304409は約8.1%長く、保守比1.126622339も改善を示さない。fixed whole-driver比1.017708150、publication前whole1.016851270、reset0.979284637、clock whole0.999272183は別の量である。Search、main callback receipt、allworker quiet／drain、setup／reset／journal／drop、whole、arena parent receiptを混ぜず、nestedを足さない。同一requested depthでもtree／work／scheduleが変わり、same-work／NPS／fullwidth speedupとは呼ばない。

事前規約の重大退行は、全104完了時の保守Search比>1.20、または任意rootの比>1.25かつ増分>10ms。保存値ではどちらもFALSE、major-root indicesは空である。全clock104のreceipt／depth条件を満たし、最大main receipt0.088795649秒、terminal Search p95 0.0950422829／max0.095102033秒は固定110／125ms境界内。terminal Searchはquiet後返却を含む保守的な量で、arena parent receiptやquiet単体ではない。

したがって固定された条件付き新27 64局の機械的gateはPASS。ただし改善、採用、実support／normal entryの発行とは別である。規約にないinteger-depth増加やCPU-cost-only vetoを追加しない。main clock median改善roots13／25、悪化23を保存し、好都合なsubsetへ選び直さない。

foreign key／context／numeric-returnやcontention skipはnestedな保存counterである。正確なlock試行分母、PV再構成の全skipや因果的counterfactualはなく、saved nodes、有用な独立情報、主因、棋力、効果不存在、同等性を導かない。26 genuine prefixes／3 families／6同色chronological series、warm状態、stock bins2／6／6／6／6・stock0不足4、歴史的exposureとlineage／schedule依存を保持する。一般速度、strength、Elo、最適性、model／default promotionは扱わない。

fair control Build51379b64／image41701732とcandidate Build982166c7／image8ae3ef74、両arm N2 Current／TT TOTAL1M、Cedar35cbb／Control／baseline LMR／PVS／path_tail／approxOFFという保存tupleを既存資格refsで再用した。旧f2時刻をfair baselineへ流用しない。新25 source repair8eaはこの結果image／protocolの外であり、Main／source／ELF／model／旧27.1を読み直していない。

原208は終了。fixed packet時点でgames0／CI0／supportUNISSUEDである。forwardは事前固定book33..64・両色64局／32 families、2非融通250M、N2対N2、100ms＋5ms、arena seed3242720261020だけ。実support／current caller／fair window等をRootが実際に結んだ場合に限る。全64 normal-qualified／32 pairs／UNKNOWN0と実STOPの後だけ、唯一のfamily PCG64 seed3242720261021／10000／linear95へ進む。lower>0.5なら固定範囲の次研究N2 controlを支持し、その他は現N2 controlを維持する。production default1／modelsを変更せず、旧22 DORMANT64、24の枠や残りnodeを転用しない。

known208 nodesは19,159,225／208M、outer56.144763131秒を一度だけ計上する。accepted-inclusive58.260404秒は別scope、nested added0。保存process CPUはO10.83／N10.92秒でrendering等を含み、physical NNではない。RSSは累積process highwaterでper-root／family continuous peakではない。full fees／physical NN／globalactualのUNKNOWN、全FAILED／NULL／pause／seal／model／default／foreign／decimal50GB／取消consultation8を保持する。

本人readerは128KiB上限が既知140,662B metadataを拒否し、body読取前に一度失敗した。そのexit1／signal-mask pending／persist attemptedを保全し、未完了のcompact metadata抽出だけを続けた。科学計算、validator、source proof、RAW、archive、native、Search、model、test、compiler、RNG／CI、plot再演は0。targetのfindingsとは区別する。

minimumと実readerSTOPはlong report／Beadsより先に324へ返却した。known owned processのactual directwait/reap／handle closureとfresh PID-start-boot不在、TMP／source leaseなしを記録し、light delivery／adminは別lifetimeにする。全hostや未来quietは主張しない。同じ本人27.2をin_progressに保ち、後日真正64 saved resultが届けば同じ有限leafで扱う。監視／statuspoll／author送信／ACK gateは作らない。
