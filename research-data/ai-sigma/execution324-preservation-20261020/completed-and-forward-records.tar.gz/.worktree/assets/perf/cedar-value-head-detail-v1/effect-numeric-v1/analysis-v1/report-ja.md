# Cedar value head：row-view一候補の有限連続探索比較

**事前AND規約を満たさず、この有限比較ではrow-view候補を支持しない。追加計測・補充はしない。** 比較専用候補と新fixtureの撤去はRootへ引き渡す。一般速度・棋力・同等・効果不存在・モデルや製品既定の主張はしない。

原104 calls／24 sessions／100,000,772 nodesを正常保存。26局面のaction・value bits・PV・完了深さ・停止・全保存非時計work・TT／ordering・root合法集合・fullhistory・親復元、およびsessionの非時計factsはABBA全4反復で完全一致。100件NodeLimitはUNKNOWN、4件DepthComplete。要求D64を達成したという資格ではない。

|block|Search合計秒|setup秒|session reset秒|root準備秒|journal秒|session drop秒|target drop秒|driver whole秒|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|A0|26.229012472|0.001508649|0.173087527|0.001501095|0.183371211|0.012307433|0.000011919|26.601448180|
|B1|26.171770284|0.001662703|0.181440042|0.001618232|0.225746628|0.014570850|0.000012641|26.597641316|
|B2|25.761431348|0.001808266|0.232836663|0.001943532|0.259484205|0.020408022|0.000012576|26.278309658|
|A3|25.836631210|0.002060206|0.200897634|0.002765728|0.561986386|0.022810359|0.000011161|26.627367014|

主時計の(B1+B2)/(A0+A3)=0.997456249、記述上の短縮は0.2544%。必要な2%以上を満たさない。反復分離も max(B)=26.171770284 < min(A)=25.836631210 が偽。固定stockbinの両組とも10%以上悪化するguardはPASS。AND規約の内訳はdecision.json。

順序変動：A3/A0=0.985040、B2/B1=0.984321。候補効果と実行順の有限な揺れを分離できる反復数ではない。kernelの命令減少・profileの割合から全Search改善を推定していない。

|固定root残壁|各block根数|B1/A0|B2/A3|pooled B/A|
|---|---:|---:|---:|---:|
|0|2|0.908611|0.992463|0.948729|
|1–4|6|1.001075|1.002201|1.001629|
|5–10|6|1.014138|1.017513|1.015808|
|11–15|6|0.991119|1.003610|0.997342|
|16–20|6|0.993700|0.959206|0.976332|

|同色chronological series|各block根数|B1/A0|B2/A3|pooled B/A|
|---|---:|---:|---:|---:|
|series-0-turn-0|3|0.979591|0.993531|0.986476|
|series-1-turn-1|3|1.010183|0.998713|1.004465|
|series-2-turn-0|6|1.031734|0.989598|1.010713|
|series-3-turn-1|5|0.989191|1.010249|0.999541|
|series-4-turn-0|5|0.982941|0.981002|0.981977|
|series-5-turn-1|4|0.988768|1.010309|0.999491|

26 genuine prefixは3既存family／両手番／6同色時系列。root stockbins=2/6/6/6/6、stock0目標より4不足を保持。同familyの履歴共有があり26独立標本ではない。root別の両比と全work/PV/bits/fullhistoryはroot-times.csv／root-correspondence.json／collection-v1/saved-rows.json、family/手番/series/bin別はgroups.json。悪化rootを除外・再選択していない。

同一Cedar35cbb／Control／DR .7844,2.4696,3,4,3／PVS／path_tail ON／TT1M／approx OFF。O=b588/d0e、N=227c/5b00は別genuine imageで、生産差分はreview済みResidual row iterationだけ。model/targetはoperation単位、TT/history/concrete Residual head inputはsession内再用。generic/geometry/counters/rootchildはper-call。各blockの6 reset/dropを明示し、fullgameの探索state再現とは呼ばない。

診断ではheadの既知inclusive309/1282 samples、self127/1282、AVX2dot109/1282を保存した。ancestor/inline未解像でpacking・境界検査・loop費用の完全分割はUNKNOWN。実装済みReLU/packing/headbuffer再用・AVX2を新規成果としていない。今回の候補はrow-cardinality/zipによる最小loop変更だけで、旧13finite/ReLU融合は復活していない。公開入力拒否・FP32順・scaler/STM・距離入力は保持。残費用にはvalidation/packing/range/dot/FT/特徴ID/copy等があり、ゼロとはしない。

費用：effect outer 127.683609638秒を一度だけ記録。Search/session/native driverはnestedで加算しない。元diagnosis78 calls 75,000,579 nodesとeffect104 calls 100,000,772 nodesで原182 calls／合計175,001,351 nodes≤182M。追加Search/ゲーム/モデルforward資格/validator/RAW再解析/RNG/旧test再演0。physical CPU/RAMpeak／全料金／globalactualはUNKNOWN。

初期のSH EAGAINや全失敗/NULL-vs-disk、元diagnosis/ELF mapping/perf decoder失敗を保全。通常native+collection STOPはcollection.json、collect helperのactualSTOPとretained holdingはcompletion.jsonに別束縛する。Main/currentcallerの将来quietは認定しない。

事前規約と判定: /workspaces/quoridor/.worktree/assets/perf/cedar-value-head-detail-v1/effect-numeric-v1/analysis-v1/decision.json。候補の比較専用code/test撤去後はUNMEASURED、今回の測定imageと同一と呼ばない。
