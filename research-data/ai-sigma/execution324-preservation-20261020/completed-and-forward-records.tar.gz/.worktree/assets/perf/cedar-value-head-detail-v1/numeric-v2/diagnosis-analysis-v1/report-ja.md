# Cedar value-only head：新20の有限診断

今回の78 callsは通常manifest／データ検証PASS、全対応rootのaction・PV・valuebits・depth/stop・全旧work・fullhistory・親復元は3 block間で完全一致した。候補の速度改善はまだ測っていない。

|block|calls|D64完了|NodeLimit/UNKNOWN|nodes|logical evals|continuous Search秒|setup秒|target drop秒|native whole（result公開前）秒|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|plain-before|26|1|25|25000193|18924596|25.928423897|0.004952540|0.000015563|26.464672290|
|profile|26|1|25|25000193|18924596|26.093908907|0.001547581|0.000012290|26.574411107|
|plain-after|26|1|25|25000193|18924596|25.772712242|0.001505888|0.000013034|26.264099654|

各block25件は1M node capで打切り、completed depthは実保存値のまま。NodeLimitをD64達成としない。1件のみDepthComplete、全75,000,579 nodes／78callsは元診断78M／182M内でUSED、残りを補充しない。モデルtargetはoperation、TT/history/concrete headは6同色series、generic geometry/counters/rootcloneはpercall。初回sessionと継続rootを別tableに保持する。

profile Searchは両plain平均より0.941%長い。plain前後にも揺れがあり、この差を純粋なobserver費と因果認定しない。setupはモデル／target一回分、6session reset/dropはsession_domains、rootprepare・journal・callteardownは保存行、wholeは親子nestedを加算しない。per-root／3family／6series／root残壁層の実時計・node・statusはroot-stock-family-series-tables.jsonと元saved-rows.jsonを参照。perfの各root絶対開始時刻が保存されておらず、sampleを個々のrootへ偽分配しない。

## 新profileの全体hotspots

cpu-clock:u49Hz／DWARF8192／ring64、同一native PID/TID、1282 samples、RAW10,844,792B（16MiB未到達）。解析テキスト1,444,693B。sample期間約26.509秒。LOST記録は今回抽出に0、全1282にunknown ancestor、leaf不明100件（7.80%）。全系loss0や完全unwindとは呼ばない。percentはwhole native user samples、Search専用CPU時間ではない。selfとinclusiveは重なり加算不可。

|symbol|leaf self samples/%|inclusive samples/%（同sample内重複除去）|
|---|---:|---:|
|`<quoridor_nnue::residual::ResidualModel>::evaluate_with_scratch`|127 / 9.91%|309 / 24.10%|
|`<quoridor_core::position::Position>::wall_distance_maps_after_addition`|109 / 8.50%|112 / 8.74%|
|`quoridor_nnue::simd::avx2_dot_fast`|109 / 8.50%|109 / 8.50%|
|`<quoridor_nnue::Model>::delta_move_into`|109 / 8.50%|337 / 26.29%|
|`[unknown]`|100 / 7.80%|1282 / 100.00%|
|`<quoridor_core::position::WallEdges>::both_reachable`|92 / 7.18%|92 / 7.18%|
|`<quoridor_core::position::Position>::legal_action_ids`|71 / 5.54%|172 / 13.42%|
|`<quoridor_ai::alphabeta::Table>::probe_hashed`|54 / 4.21%|54 / 4.21%|
|`<quoridor_core::position::Position>::wall_distance`|52 / 4.06%|52 / 4.06%|
|`quoridor_nnue::validate_features`|47 / 3.67%|47 / 3.67%|
|`<quoridor_core::research::SigmaContext>::is_repetition_draw`|47 / 3.67%|47 / 3.67%|
|`<quoridor_nnue::Model>::validate_accumulator`|36 / 2.81%|83 / 6.47%|
|`<quoridor_ai::alphabeta::Search>::child`|33 / 2.57%|1178 / 91.89%|
|`<quoridor_ai::alphabeta::continuation_history::PositionScores>::score`|27 / 2.11%|27 / 2.11%|
|`<quoridor_ai::alphabeta::Search>::negamax_entered`|26 / 2.03%|1177 / 91.81%|
|`<quoridor_ai::alphabeta::Search>::ordering_scores`|23 / 1.79%|65 / 5.07%|
|`<quoridor_ai::alphabeta::ContextFingerprint>::add`|21 / 1.64%|21 / 1.64%|
|`<quoridor_core::research::ContextUndo>::checked_positions`|16 / 1.25%|16 / 1.25%|

全tableはsummary.jsonに保持。maps／wall repair、legal generation/reachability、delta owner、featureID/FT/copy、TT、orderingは実在費用で、headへ重複加算しない。TT-first遅延やLMR/ordering変更の新候補は追加しない。旧320sample/旧imageのprofileは再parseせず、比較可能な新CPUshareとして混ぜない。

## headの五つの問い

head inclusive既知309件（24.10%）、owner leaf127（9.91%）。known head ancestryがあるsample内のleafを分けると、AVX2 dot109（全体8.50%）、validate_features18＋validate_accumulator17（2.73%）、tanh10（0.78%）、unknown27＋PLT1。これ以外のvalidator sampleはdelta等の別callerで、head検査へ足さない。

|問い|今回のsource／実生成コードと保存leaf-PC|分解の限界|
|---|---|---|
|1 検査・call準備|公開accumulator/features検査の既知leaf35。scratch幅・side・entry/packing混合bucket8。|35は完全な検査inclusive費ではない。公開任意入力拒否／優先順位は維持。旧13融合を復活しない。|
|2 二view ReLU/packing|既存一回packing、STM順の二row。entry/shape/packing混合8 sample。|ReLUのみのshareへ切れずUNKNOWN。scratch再用・FT32二row256Bcopyは既実装、無料／新機能としない。|
|3 距離正規化／range|距離2値の元FP32減算・除算。packed finite走査14、f64 abs-max31、rangebound3。|距離normの単独shareはpacking混合。finiteやrange緩和／reciprocal／旧融合は候補にしない。|
|4 dispatch／hidden32 dot／bounds|dot109、dispatch/setup/rowbounds混合17、AVXcall/reload/rowcontrol混合14。行毎の添字／境界確認が実codeに残存。|dotSIMDは既存、feature判定cache読みを重い検出としない。sampleなしscalarfallbackを実頻度0としない。|
|5 aggregate／finite／tanh|output積和＋loopcontrol混合37、final logit/finite/tanh-call混合3、tanh10。|FP32積和順・finite・f64tanhは不変。混合37をすべてループ費／削減可能量としない。|

PCからELF命令への対応は実LOAD segmentでfileoffset→VMA +0x1000を確認。最初の小objdumpはfileoffsetをVMAと誤用した別rangeで、保存して除外した。正しいhead開始2f3a90、dot301f40（前もって保存済448Bのみ再用）。新head codeは4096B限定、全ELF disassembly／symbolbuildなし。各bucketの範囲と全countはhead-breakdown.json。

## 一つの最小候補：row views

`residual-head-row-views-v1` はlinear_head_capture内だけでhead rows／bias／outputのslice境界を一度確定し、chunks_exact＋zipで元j昇順を辿る。各dot_fastへの配列・bias・permit、FP32出力積和、optional hiddenの保存順は変えない。public検査／packing／HeadRange／SIMD intrinsic／FMA／tanh／モデル／session／Searchはbyte exact。既存再用を新最適化と称さず、旧13 finite/ReLU融合とも別の行アクセス境界だけを対象にする。

入力幅2*ft+6は正、rows/biases/outputsの長さは正確にhidden_widthで、zipの短縮は起きない。最大indexのoutputbias readも元位置に残る。新API／unsafe／cache／registry／observerなし。mixed17や14sampleは全部が除去される費用ではなく、効果UNKNOWN。最も小さいこの一候補だけを固定した。

private実装は1subject、production差はrow loop一箇所、旧fixture全部byte exact。新synthetic Rust定義1はwidth/hidden境界・両STM・有限/overflow routing・indexed reference bits・hidden capture・独立固定Err優先順位を対象としUNBUILT/UNTYPED/UNRUN。author Cargo/Rusttest/model qualificationなし。Rootへactualfixedtargetと限定所有問いを渡し、必要な同関連Max／Rootsoftware・imageが成立した後にのみ元ABBA104calls/104Mへ。

元採否は全非時計/bits/history/restoration一致、aggregateB/A<=.98、両B Searchsum<両A、各stock層の二対応がともに>10%悪化しないAND。newroot／warmup／pilot／校正／sweep／反復／RNG／ゲーム／補充なし。現時点は候補UNMEASURED、performance/棋力/default/model採用なし。

保存解析の初回perf decoderはexit0でも既存1MiB保持上限でtailのみだった。断片を分母へ使わず、同じ新20RAWの出力先だけ8MiB有界ファイルへ修正（実1.445MB）、Search/perf採取/通常資格の再実行0。全元RAW/FAILED/NULL/costUNKNOWN保持。外側96.89922605600441秒は一度、native26.492639674/26.702042725/26.281480531はnested非加算。物理NN実回数・CPU/RAMpeak・全料金・全public/sealed/training露出・未知inline/ancestorはUNKNOWN。

original17のordering判断はControl固定のまま。今回の実診断native＋normalcollection＋heavy解析STOPをHigh9／Rootへ返し、元short16→独立heldout512を妨げない。候補のRootsoftware/effectは自然な別公平窓で実資源・新imageを結合する。同actor別turn並行／新role／親close／人間ACKは作らない。

candidate binding: `/workspaces/quoridor/.worktree/assets/perf/cedar-value-head-detail-v1/row-views-candidate-v1/binding.json`。collected inputs/costs/normalmanifestsはdiagnosis-collection-v1/collection.json、profileはdiagnosis-perf-decoded-v2/summary.json、全private guard STOPをcompletionへ束縛する。
