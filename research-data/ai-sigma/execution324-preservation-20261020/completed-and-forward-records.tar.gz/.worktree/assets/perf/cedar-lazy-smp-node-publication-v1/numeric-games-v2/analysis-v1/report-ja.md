# Completed-node Lazy SMP：原24の有限比較結果

候補N2は34勝0分30敗、得点率0.53125。全64局・32両色familyが通常DATA資格を満たし、UNKNOWN0。固定した唯一のfamily bootstrap（PCG64 seed3242420261021、10,000、linear中央95%）は **[0.4375, 0.625]**。下端>0.5はFALSEで、結論は **RETAIN_NATIVE1**。この固定bookの有限証拠であり、同等・無効果・一般棋力・Elo・製品default昇格の結論ではない。

## 入力・資格・停止

事前固定32family indices 0,1,2,4..32を元順で両色、元prefix/full weighted history/seedを保持。historical book exposure YES、unseen/IIDとは呼ばない。Cedar35cbb、Control、baseline LMR .7844/2.4696/3/4/3、PVS/path_tail、同一真正image f2bd、TT TOTAL1M。N1対N2、100ms/5ms reserve、D64/per-move全worker1M、2 serial RUN×32局、各250M非融通。strict_unknown、追加seed/局/refillなし。

全2通常manifest/data PASS。saved normal resultとgames.csvだけを結合し、archive/model/探索/validator/FINALIZEの再実行なし。native all_workers_joined、main/inner/native exact PID-start-bootは新鮮な照合でabsent/different、directwait/reap/handles、TMP/sourceleases/nativejobs remaining[]。normal reader STOP 2026-10-20T06:32:45.851428Z。sole CIは実collection helper返却後に一度だけ実行し、entered/resultと全10,000 drawsを永続化。native2 chunkのbootstrap1は診断専用で混合・再利用しない。

## 時間と費用の範囲

| Scope                                          |                    Result |
| ---------------------------------------------- | ------------------------: |
| Original208 all-worker charged nodes           |                14,747,685 |
| Initial64 batch0 node charge / cap             | 177,118,854 / 250,000,000 |
| Initial64 batch1 node charge / cap             | 186,929,855 / 250,000,000 |
| Initial64 charged total                        |               364,048,709 |
| Original208 outer seconds once                 |              57.310704433 |
| Initial64 successful outer seconds once        |             299.044885751 |
| Initial64 accepted-inclusive alternative scope |                301.097194 |

Nested native/inner/recording/terminal costsは親wholeへ加算しない。失敗job25f20673はnative Config parse 0.018691079s、outer3.918153763s、accepted-inclusive5.957945sを別の実費として永久保持。candidate_pool_size nullの普通metadata修正のみでfresh namespaceへ移り、原FAILED/LCaccepted0/guardianNULL/captureFALSE/cleanupFALSE対diskTRUEを上書きしない。game64のnative process RSS highwaterは232,800,256B/234,471,424B、family peakや全worker CPUの代用にはしない。report nn_calls=0はNNUE無費用を意味せず、physical NN/full fees/total CPU/global actualはUNKNOWN。

## 元208のSearchとwholeを区別

全104 fixed-depthはDepthComplete。max(twoN2 Searchsum)/min(twoN1 Searchsum)=.972579184、2repeat合計Searchsum B/A=.964950716（この有限Search bodyは約3.5%短い）。元reportの「whole」表現は誤りで、原文は保持しRoot補足24c37e4dと本節で訂正。whole_driver B/A=1.391652661、publication前whole=1.373268323、session_reset=2.458790297。**setup/reset込みwhole改善とは主張しない**。

元100ms104callのmain receipt<=.100/depth>=1、terminal p95 .1002203892/max .101531170が安全gateを満たして新24の64局に進んだ。深さ増加自体は条件でない。main/helper foreign numeric再利用は存在するが独立情報量・saved nodes・原因の測定ではない。selective treeが違うためsame-work/full-width speedupではない。old-image N1 empirical wall/parityはUNMEASURED。

## 次の限定質問

shared TTの同generation deeper-entry保護がwriter依存の場合、他workerからの浅い完了entry置換で情報が失われる可能性がある。実原因と確定せず、writer-independent replacementを一要因だけ調べる別issue27へ渡す。原24に実装・追加試行・旧22 dormant64活性化はしない。default1、model、production、pauses/seals/foreign/FAILED/UNKNOWN費用を保持する。

Evidence: /workspaces/quoridor/.worktree/assets/perf/cedar-lazy-smp-node-publication-v1/numeric-games-v2/analysis-v1/summary.json
