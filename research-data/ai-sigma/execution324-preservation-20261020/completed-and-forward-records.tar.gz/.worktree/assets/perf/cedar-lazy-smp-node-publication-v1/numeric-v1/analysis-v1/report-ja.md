# Completed-node Lazy SMP 原208 calls 保存解析

8通常RUN/208 calls/48 sessionsのmanifest/dataは全PASS。使用nodes 14,747,685/208,000,000。保存rowのroot/完全weighted履歴/手番/合法集合/stock/session、親復元、main権限と合算node/eval/capの対応=True。N1固定深さA0/A3のaction/valuebits/PV/depth/stop/work/TT/historyは一致。これは有限の観測資格であり全fault/parityの証明ではない。

| phase/block   | threads | Search合計s | stops                                 | main/helper nodes | CPU s | 累積RSS最大MiB |
| ------------- | ------: | ----------: | ------------------------------------- | ----------------: | ----: | -------------: |
| fixed_depth/0 |       1 |    0.341554 | {'DepthComplete': 26}                 |          365501/0 | 0.350 |          91.11 |
| fixed_depth/1 |       2 |    0.327000 | {'DepthComplete': 26}                 |     355078/354804 | 0.660 |         172.37 |
| fixed_depth/2 |       2 |    0.329216 | {'DepthComplete': 26}                 |     350043/352911 | 0.670 |         172.42 |
| fixed_depth/3 |       1 |    0.338498 | {'DepthComplete': 26}                 |          365501/0 | 0.340 |          91.29 |
| fixed_clock/4 |       1 |    2.477091 | {'TimeLimit': 25, 'DepthComplete': 1} |         2127380/0 | 2.470 |          91.34 |
| fixed_clock/5 |       2 |    2.375738 | {'TimeLimit': 25, 'DepthComplete': 1} |   2116675/2014073 | 4.760 |         172.61 |
| fixed_clock/6 |       2 |    2.375707 | {'TimeLimit': 25, 'DepthComplete': 1} |   2119128/2115859 | 4.790 |         172.85 |
| fixed_clock/7 |       1 |    2.494373 | {'TimeLimit': 25, 'DepthComplete': 1} |         2110732/0 | 2.490 |          91.34 |

固定深さ104すべてDepthComplete=True。whole max(two N2)/min(two N1)=0.972579、重大root退行=[]（規約は比>1.50かつ絶対差>5msのrootが3件超）。完了時計の資格はQUALIFIED_FINITE_COMPLETED_DEPTH_TIME_ONLY。もしcensorがあればwhole速度はUNKNOWNで、cap時間/有利な完了subsetの速度主張を行わない。
100ms/5ms: 全104 main depth>=1/receipt<=100msかつterminal観測=True。terminal Search p95=0.100220389s、max=0.101531170s（固定上限110/125ms）。clock safety=True。NodeLimitのhorizonはUNKNOWNのまま扱い、単独ではgames拒否にしない。
clock root中央値のmain depth改善3/26、悪化0/26。整数depth改善をgames条件にしていない。helper到達はmain完了へ合算しない。

**新24 initial64 gate=True**。固定protocol v2の正しさ・100ms安全性・観測された重大退行条件を通過。新24の32families/64gamesは実normal support/entryがまだ未発行であり実行していない。旧22のDORMANT64は不変で、転用・追加発行・refillはない。

| phase       | worker |   nodes | foreign key/context/numeric | order hints | contention |
| ----------- | -----: | ------: | --------------------------: | ----------: | ---------: |
| fixed_depth |      0 |  705121 |            75395/16156/8454 |       39006 |       7715 |
| fixed_depth |      1 |  707715 |            81606/15876/8651 |       42200 |       7442 |
| fixed_clock |      0 | 4235803 |        417853/182131/147432 |      198143 |      79766 |
| fixed_clock |      1 | 4129932 |        409530/190334/153564 |      190557 |      78590 |

foreign provenanceはnestedな実利用/候補hintで、独立情報量・反実仮想savednodes・棋力の証拠ではない。各entryが未完了root由来かのイベント対応は記録していない。N2は別selective tree/仕事/valueを持つため同仕事/full-width速度へ読まない。原22の別時刻N2時計は公平比較に使わず、旧image N1 wall/parityもUNMEASURED。

helper stop/drain p95=0.000032392s、max=0.000063006s。Search内なので別加算しない。旧root-end TT discard field/処理を再導入・仮定していない。setup/reset/rootprepare/journal/drop/wholeとprocess CPU/RSSはblock表/CSVに分離した。CPUは全thread OS tick、RSSは累積highwater、物理NN回数/fullfees/globalactualはUNKNOWN。
accepted-inclusive 59.320392000sとouter 57.310704433sは別scopeで加算しない。全208logicalcallsはUSED、未使用node ceilingは返金/貸与しない。

全208callと全26root、およびworkerごとのmain/helper/合算nodes/evals/TT、session初回対継続/series/family/手番/stock別の分母と時計をcalls.csv/workers.csv/roots.csv/summary.strataへ保存。stock0は2roots/不足4、同family履歴とwarm sessionの相関を保持し独立標本と呼ばない。旧432/384露出YES、他training/sealed/LMR/interior露出UNKNOWN。一般優越/同等/無効果/棋力/default/model昇格は主張しない。

正常完了後の保存解析のみ。モデル・入力payload・native/Search・旧資格・validator・RAW・RNG・CI・成功suiteは再演していない。FAILED/NULL/費UNKNOWN、pauses/seals/defaults/models/foreign/decimal50GBを保持。次の未解決な問いは、同時間の合法move選択としてこの共有が有限64局で有用か、であり、新source/自動sweepは発行しない。

![元26rootの固定深さ時計比と100ms main depth差](root-comparison.png)
