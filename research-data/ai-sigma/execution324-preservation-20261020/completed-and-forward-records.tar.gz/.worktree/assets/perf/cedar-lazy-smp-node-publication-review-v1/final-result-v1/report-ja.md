# 24.2 completed208／initial64：有限結果の限定確認

固定producer completion `5025ce65c82b3c4ca24056b06067de8065bacdf049dee08e31be47721aecbe9e` に対し、CONCLUSION_CLEAR、essential 0／ordinary 0。Root受入れ `e55a8e988190a13a719cbf62cf052ab53447dedf2e886c78d77032afac38344c` は同じminimum・readerSTOPを結び、有限結論RETAIN_NATIVE1を受け入れている。

元208はnormal manifest／data PASS、48 sessions、14,747,685 nodes。固定depth104は全てDepthComplete。保存された保守的Searchsum比maxN2/minN1は0.972579184、repeat比0.964950716である。一方、whole driver 1.391652661、before-publication 1.373268323、session reset 2.458790297は悪化している。旧208資料のwhole表記は凍結したまま、結果前のRoot wording supplementと最終reportの訂正に従いSearchとwholeを区別する。whole speedupや旧image parityを主張しない。

固定c99 protocolの新64入場はSearchsum／安全性の規則で、最終strength採用や2%基準とは別。保存されたall-root／clock／stop条件に基づく新24の初期64入場PASSと対応し、旧22 DORMANT64は変更しない。恣意的なroot subsetやinteger-depth上昇を条件に加えていない。

新64は全64 normal-qualified、32 complete both-colour families、UNKNOWN 0。N2視点34W0D30L、score 0.53125。保存された唯一のPCG64／seed3242420261021／10000／linear95は[0.4375, 0.625]で、lower > 0.5はFALSE。固定された同重みfamily順と候補視点、normal collection STOP後のpre-entry／entered／result、保存計算bodyと記録Python／NumPyの対応を静的に確認した。再resampling、CI再計算、別interval、資格器の再実行は0。

この有限比較ではRETAIN_NATIVE1。固定のexposed book、同一new image両arm、Cedar／Control／PVS／path_tail／baseline LMR／TT TOTAL 1M、100ms＋5msの条件に限定する。within-campaign frameを保存順に使用し、historical exposure・lineage dependenceを保持する。一般strength、同等性、効果不存在、Elo、最適性、model／product／default promotionへ広げない。

2つの非融通operation chargeは177,118,854と186,929,855 nodes、合計364,048,709。これはmain／helper別内訳ではない。元208を含むknown 24 scienceは378,796,394 nodes。新64 outer 299.044885751秒は一度だけ計上し、nestedを加えない。208＋64の元science枠は終了。helper nodesやsharing counterから独立情報量、saved nodes、因果効果を推定しない。game別worker／TT／CPU／physical NN分布、continuous peak、full fees／global actualの未記録はUNKNOWNのまま。

元metadata failure、FAILED／NULL／diskとcaptureの差、費用UNKNOWNを保全する。本人のmetadata readerにもinputをdictと仮定した失敗があり、そのexit1、signal-mask pending／persist attemptedを保存し、未完了list抽出だけを修正した。target関数／RNG／validator／nativeは実行していない。後続STOPは全てを成功に書き換えず、既知processの実reap／handles閉鎖・fresh identity不在を記録した。

原source24.1は再開しない。source／software／有限性能／strength判断を分ける。明示2thread共通機能は具体的に許可された27 control比較用に保持するが、native default1を変更しない。新科学権利、再選択、refill、refund／lendingは発行しない。

minimum、control、入力refs、保存correspondence、失敗receipt、実readerSTOPとRoot配送receiptを同じOWNに保存した。Root指定reasonで本人24.2だけを通常closeできる。Main／Git／Cargo／canonical docsは324のみ。全pauses／seals／models／defaults／foreign／FAILED／UNKNOWN／decimal50GB／取消consultation8を保持する。
