"""Current/Current dependency amendment and saved-metadata normal drafts."""

import copy
import hashlib
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = OUT.parent
ISSUE = "quoridor-4lc.324.26"
DEPTHS = [5, 6, 6, 5, 6, 6, 5, 6, 6, 6, 8, 8, 5, 6, 6, 8, 8, 5, 5, 6, 8, 8, 5, 5, 6, 6]


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def document(reference):
    path = Path(reference["path"])
    assert ref(path) == reference
    return json.loads(path.read_bytes())


def save(name, value):
    path = OUT / name
    with path.open("x") as output:
        output.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


binding_ref = ref(OWN / "source-packet-v2/binding.json")
assert binding_ref["sha256"].startswith("5e1487a5")
binding = document(binding_ref)
protocol = document(binding["protocol"])
requests = document(protocol["effect"]["schedule"])
assert [request["depth"] for request in requests] == DEPTHS
assert all(
    request["time_limit_ms"] is None
    and request["node_cap"] == 1000000
    and not request["warmup"]
    for request in requests
)
assert len({request["session"] for request in requests}) == 6
envelope = document(protocol["draft"])
config = copy.deepcopy(envelope["measurement_template"])
# Correct the old nonrunnable operational aliases to the maintained measurement
# names already present in saved normal N1 controls; no science tuple changes.
assert config.pop("cpu_cores") == [12]
assert config.pop("max_memory_bytes") == 2684354560
config.update(
    search_cpu_cores=[12],
    native_memory_bytes=2684354560,
    shallow_main_history="current",
)
assert "history_tie_break" not in config
assert config.get("root_ordering_quality") is None
assert config.get("history_provenance") is None
assert config.get("neighbour_opportunity") is None
configs = {arm: save(f"measurement-{arm}.json", config) for arm in ("A", "B")}
assert configs["A"]["sha256"] == configs["B"]["sha256"]

future = OUT / "normal-effect-v1"
assert not future.exists()
resources = dict(
    search_worker=12,
    main_guardian=0,
    outer=18,
    launcher=[0, 12, 18],
    child_cpu_cores=[0, 12],
    family_B=4294967296,
    management_included_B=1610612736,
    native_B=2684354560,
    host_reserve_B=4294967296,
    GPU=0,
    threads=1,
)
experiments = []
runs = []
pass_roles = []
for index, arm in enumerate(("A", "B", "B", "A")):
    experiment = dict(
        schema="quoridor.research.experiment.v1",
        phase="compare",
        build_manifest=None,
        config=configs[arm],
        inputs=protocol["by_reference_only"]["inputs"],
        models=protocol["by_reference_only"]["models"],
        dynamic_libraries=protocol["by_reference_only"]["dynamic_libraries"],
        schedule=protocol["effect"]["schedule"],
        numerical_qualification=None,
        canonical_plan_sha256="",
        rules=config["namespace"]["rules"],
        distance_units="wall-distance/80",
        value_perspective="side-to-move",
        planned_slots=26,
        batch=index,
        argv=[
            None,
            "measure",
            "--experiment",
            "@EXPERIMENT@",
            "--experiment-sha256",
            "@EXPERIMENT_SHA256@",
        ],
    )
    experiment_ref = save(f"experiment-{index:03d}.draft.json", experiment)
    experiments.append(experiment_ref)
    root = future / f"measure-{index:03d}"
    run = dict(
        schema="quoridor.research.lifecycle-intent.v1",
        kind="run",
        owner=str(ROOT),
        writer="codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0",
        cwd=str(ROOT),
        output=str(root / "operation"),
        data_root=str(root / "data"),
        TMP=str(root / "TMP"),
        owned_outputs=None,
        artifact=None,
        experiment=experiment_ref,
        finalizers=[],
        limits=None,
        env=dict(
            PATH="/home/vscode/.local/bin:/home/vscode/.cache/inference/envs/quoridor-training/bin:/usr/bin:/bin",
            PYTHONPATH=str(ROOT / "python"),
            QUORIDOR_PROJECT_ROOT=str(ROOT),
            QUORIDOR_PROJECT_ENV="/home/vscode/.cache/inference/envs/quoridor-training",
            UV_PROJECT_ENVIRONMENT="/home/vscode/.cache/inference/envs/quoridor-training",
            PYTHONDONTWRITEBYTECODE="1",
            CUDA_VISIBLE_DEVICES="",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
            ORT_DISABLE_TELEMETRY="1",
            RAYON_NUM_THREADS="1",
            TMPDIR=str(root / "TMP"),
        ),
        support=None,
        approved_plan=None,
        data=[
            dict(name=name, path=str(root / "data" / filename), limit_B=cap)
            for name, filename, cap in (
                ("settings", "settings.json", 1048576),
                ("measurements", "measurements.jsonl", 33554432),
                ("result", "result.json", 33554432),
            )
        ],
        perf=None,
        argv=[
            None,
            "measure",
            "--experiment",
            experiment_ref["path"],
            "--experiment-sha256",
            experiment_ref["sha256"],
        ],
        caller_sources=None,
        child_cpu_cores=[0, 12],
        command_timeout_seconds=180,
    )
    runs.append(run)
    save(f"run-{index:03d}.draft.json", run)
    pass_roles.append(
        dict(
            index=index,
            arm=arm,
            image_role="common_baseline" if arm == "A" else "wall_path_candidate",
            Current_history=True,
            actual_artifact_BUILD=None,
        )
    )
sequence = save(
    "sequence.draft.json",
    dict(
        schema="quoridor.research.sequence.v1",
        kind="sequence",
        cwd=str(ROOT),
        owner=str(ROOT),
        output=str(future / "execution-v1"),
        measurements=[],
        arena=None,
        runs=runs,
        limits=None,
    ),
)
job = save(
    "job.draft.json",
    dict(
        issue=ISSUE,
        goal_issue="quoridor-4lc.324",
        thread_id="01a11062-b120-73a1-8aa3-fe2cb922c7c0",
        cwd=str(ROOT),
        argv=None,
        end_at=None,
        notify_until=None,
        max_runtime_seconds=1140,
        control_interval_seconds=30,
        notify_interval_seconds=10,
        request_timeout_seconds=25,
        log_max_bytes=16384,
        resource_contract=None,
    ),
)
software = document(binding["new_test_plan"])
feature_metadata = json.loads(
    (OUT / "immutable-owner-correspondence.json").read_text()
)["package_feature_metadata"]
assert "measurement" in feature_metadata["quoridor-runner"]
assert all(
    name in feature_metadata["quoridor-core"] for name in ("research", "profiling")
)
new_software = save(
    "new-only-software-recipe.json",
    dict(
        status="DEFINITIONS_UNRUN_ROOT_CANONICAL_SOFTWARE_ONLY",
        original_test_plan=binding["new_test_plan"],
        target="wall_path26",
        new_only=[
            dict(
                selector=selector,
                expected_running_tests=1,
                argv=[
                    "cargo",
                    "test",
                    "-p",
                    "quoridor-core",
                    "--features",
                    "research,profiling",
                    "--test",
                    "wall_path26",
                    selector,
                    "--",
                    "--exact",
                ],
            )
            for selector in software["new_definitions"]
        ],
        affected_Clippy_argv=[
            "cargo",
            "clippy",
            "-p",
            "quoridor-core",
            "-p",
            "quoridor-ai",
            "-p",
            "quoridor-runner",
            "--all-targets",
            "--features",
            "quoridor-core/research,quoridor-core/profiling,quoridor-ai/research-diagnostics,quoridor-runner/measurement",
            "--",
            "-D",
            "warnings",
        ],
        normal_release_argv=[
            "cargo",
            "build",
            "--release",
            "-p",
            "quoridor-runner",
            "--features",
            "measurement",
        ],
        same_release_configuration_before_after=True,
        actual_normal_BUILD_Image_library_sourceSTOP="Root-owned future, no author compilation or qualification",
        old_successful_tests_replayed=0,
        tests_compiler_Cargo_executed_by_author=0,
    ),
)
amendment = save(
    "policy-dependency-amendment.json",
    dict(
        issue=ISSUE,
        status="PROSPECTIVE_RESULT_BEFORE_CURRENT_CURRENT_FIXED",
        direct_human_instruction="Remove dependency on25 history judgment; Current on BOTH26 arms",
        original_protocol=binding["protocol"],
        original_source_packet=binding_ref,
        original_source_clear="9ebcfa4b /26.1 CLOSED retained; not re-reviewed",
        original_source_STOP=ref(OWN / "source-packet-v2/source-STOP.json"),
        necessary_immutable_owner_correspondence=ref(
            OUT / "immutable-owner-correspondence.json"
        ),
        history_policy=dict(
            A="current",
            B="current",
            Half_selection=False,
            dependency_on25_result=False,
            dependency_on25_64_acceptance_or_parentclose=False,
        ),
        configs=configs,
        operational_alias_correction="Only nonrunnable draft cpu_cores/max_memory_bytes to existing search_cpu_cores/native_memory_bytes; no new source schema or science setting",
        effect=protocol["effect"],
        exact_depth_map=DEPTHS,
        original_requests_unchanged=protocol["effect"]["schedule"],
        exactness_gate=protocol["exactness_gate"],
        finite_retain_gate=protocol["finite_retain_gate"],
        fixed_conditions={
            **protocol["fixed_conditions"],
            "history_policy": "Current explicitly on both arms; human-fixed independent of25",
        },
        intended_internal_difference=protocol["intended_internal_difference"],
        pass_source_roles=pass_roles,
        pair_requirement="Root supplies common qualified baseline and candidate after sparse26 adoption, with all other production source/build/features/Current/model identical. No comparison of old417 timestamps/image against a differently composed candidate.",
        old_concrete_software_context_only=dict(
            control_BUILD="51379b64",
            image="41701732",
            cannot_be_used_as_unmatched_pair=True,
        ),
        normal_drafts=dict(
            sequence=sequence,
            experiments=experiments,
            job=job,
            canonical_measurement_plan_sha256="",
            approved_plan=None,
        ),
        new_only_software=new_software,
        actual_pair_source_adoption_BUILD_images_currentcallers_numerical_support_fullroots_origin=None,
        required_future_inputs=[
            "Root sparse26 adoption and genuine same-common-source before/after BUILD/images/sourceSTOP",
            "new-only Rust3/affected Clippy/release evidence",
            "actual current normal measurement factory/numerical correspondence/caller refs",
            "new supported whole/fullroots/free/capacity/allocation",
            "fresh physicalSMT/peer/RAMhost4/pausecancel/ownedauthority/origin/end_at/cleanup admission",
        ],
        no_dependency_on_25_policy_27_parentclose_or_ACK=True,
        source_changed_by_this_amendment=0,
        old_protocol_files_overwritten=0,
        optional12_diagnosis_used=0,
        new_native_calls_games=0,
        resources=resources,
        runtime_proposal=dict(parent_s=1200, command_s=1140, RUN_s=180),
        normal_job_entry="ONE highestparent outsideCycle, explicit0,12,18, communicate/wait/reap/pipesclose; original completion oncecollection, no poll/observer/refill",
        original_holding_proposal=ref(
            OWN / "source-packet-v2/future-holding-proposal.json"
        ),
        holding="Existing312MiB327155712B finite future bound/336MiB352321536B proposal only; Root actual source+pair images+serializer/ended holdings must join once, no support assumed",
        no_old_sourceproof_tests_native_model_payload_RAW_RNG_replay=True,
    ),
)
prepared = save(
    "prepared.json",
    dict(
        status="CURRENT_CURRENT_FIXED_NORMAL_DRAFT_NOT_RUNNABLE",
        issue=ISSUE,
        amendment=amendment,
        sequence=sequence,
        job=job,
        new_only_software=new_software,
        actual_image_pair_BUILD_currentcallers_support_origin=None,
        calls_used=0,
        Main_reader_or_import=False,
    ),
)
assert not future.exists()
print(
    json.dumps(
        dict(
            prepared=prepared,
            amendment=amendment,
            software_recipe=new_software,
            config_A=configs["A"],
            config_B=configs["B"],
        )
    )
)
