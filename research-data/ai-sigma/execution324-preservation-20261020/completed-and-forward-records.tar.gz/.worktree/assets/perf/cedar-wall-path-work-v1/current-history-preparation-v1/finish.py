"""Return Current-fixed controls and their actual bounded helper STOP."""

import datetime
import hashlib
import json
import os
from pathlib import Path

OUT = Path(__file__).resolve().parent
OWN = OUT.parent


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as output:
        output.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


phases = [
    OWN / "current-policy-intake-v1",
    OWN / "current-policy-correspondence-v1",
    OUT / "prepare-guard-v1",
    OUT / "admin-guard-v1",
]
returned = []
identities = []
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
for phase in phases:
    result = json.loads((phase / "return.json").read_text())
    assert (
        result["exit_code"] == 0
        and result["direct_child_reaped"]
        and result["handle_closes_complete"]
        and result["cleanup_complete"]
        and result["remaining"] == []
    )
    assert not (phase / "TMP").exists()
    returned.append(ref(phase / "return.json"))
    for identity in (
        json.loads((phase / "controller.json").read_text()),
        result["child"],
    ):
        path = Path("/proc") / str(identity["pid"]) / "stat"
        try:
            current = path.read_text().rsplit(")", 1)[1].split()[19]
        except FileNotFoundError:
            current = None
        assert current != str(identity["start_ticks"]) or boot != identity["boot_id"]
        identities.append(
            dict(
                identity={
                    key: identity[key] for key in ("pid", "start_ticks", "boot_id")
                },
                current_start_ticks=current,
                absent_or_different=True,
            )
        )
stop = save(
    "light-preparation-STOP.json",
    dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        prepared=ref(OUT / "prepared.json"),
        actual_returned_helpers=returned,
        known_helper_identities=identities,
        directwait_reaped=True,
        handles_complete=True,
        TMP_remaining=[],
        source_leases_remaining=[],
        owned_processes_remaining=[],
        idle_reservations=[],
        no_live_Main_reader_or_import=True,
        source_delta_proof_review_tests_Cargo_native_model_RAW_RNG=0,
        same26_assignee_in_progress_note_backup="PASS",
        previous25_3_delivery_returned_before_work=True,
        future_host_quiet_not_claimed=True,
        current_finalizer="Actual return follows return-guard-v1/return.json; no self-absence claim",
    ),
)
roots = [OUT, *phases[:2]]
seen = set()
allocated = logical = entries = 0
for root in roots:
    for parent, dirs, files in os.walk(root, followlinks=False):
        for path in [Path(parent), *[Path(parent) / name for name in dirs + files]]:
            info = path.lstat()
            key = (info.st_dev, info.st_ino)
            if key not in seen:
                seen.add(key)
                allocated += info.st_blocks * 512
                logical += info.st_size
                entries += 1
point = save(
    "ordinary-affected-point.json",
    dict(
        roots=[str(root) for root in roots],
        allocated_B=allocated,
        logical_B=logical,
        entries=entries,
        scope="Once new Current-fixed metadata/helper subtree only; fixed old source/proof/data and holding not rewalked or recharged",
        later_tails_globalactual_fees="UNKNOWN",
        refund_lending=0,
    ),
)
completion = save(
    "completion.json",
    dict(
        issue="quoridor-4lc.324.26",
        status="CURRENT_CURRENT_NORMAL_DRAFT_FIXED_NOT_RUNNABLE",
        prepared=ref(OUT / "prepared.json"),
        policy_amendment=ref(OUT / "policy-dependency-amendment.json"),
        new_only_Rust3_Clippy_release=ref(OUT / "new-only-software-recipe.json"),
        immutable_owner_correspondence=ref(OUT / "immutable-owner-correspondence.json"),
        light_STOP=stop,
        affected=point,
        actual_common_pair_BUILD_images_callers_support_origin=None,
        numerical_calls_used=0,
        no_dependency_on25_policy_or_parent_ACK=True,
        source_binding5e1487a5_unchanged=True,
    ),
)
body = (
    "SAME26 Current/Current prospective preparation DONE at actual serial25.3helper/deliverySTOP, "
    "not source/science rerun. Human removed25judgment dependency: both configA/B explicit "
    "shallow_main_history=current, byteidentical SHA33c94ab1. Source5e1487a5/legal_wall+"
    "wall_path26.rs and Rootsourceclear9ebcfa4b/closed26.1 unchanged. One necessary immutable "
    "f2efd18e position.rs hashfaeae19e/21758 exactly matches originalbefore; no wholemirror/"
    "MainSHreader/import/GNUproof/source-review/test/native/model/RAW replay or27private read.\n"
    "Originalprotocol8a226a7f/requests/sessionorder/depthmap5,6,6,5,6,6,5,6,6,6,8,8,5,6,6,8,8,5,5,6,8,8,5,5,6,6 "
    "unchanged, timeNone/1M each/104M/ABBA/104calls/24warmseries, no optional12/games. "
    "All104DepthComplete/UNKNOWN0/bits/action/PV/depth/stop/treework/legal/fullhistory/restore "
    "EXACT required; SearchB/A<=.98 AND max(B1,B2)<min(A0,A3) AND originalstockbadcase guard. "
    "Intended maskwork may differ; BFS/tree unchanged, no kernelshare/generalstrength claim.\n"
    "Four ordinary Experiment/RUN/sequence/job drafts saved with correct measurement "
    "search_cpu_cores/native_memory_bytes names and explicitchild[0,12]. EmptycanonicalPlan/"
    "approvedNone are normalmeasure semantics; no fakearenaPlan. Actual new common before/"
    "candidate BUILD/images/sourceadoption/current4/numerical/factory/support/fullroots/origin "
    "NULL and NOT_RUNNABLE. Rootpair must have all other source/features/Current/model identical; "
    "historical417/513 context is not unmatched baseline qualification. No25policy/64/27parent/ACK gate.\n"
    "Exact NEW Rust3 targetwall_path26/--featuresresearch,profiling selectors/expected1each "
    "and affectedCore+AI+RunnerClippy/normalmeasurement release argv supplied UNRUN; "
    "features read only from immutable Cargo manifests, no Cargoexecution. "
    "Rootnormalwriter/software/currentcalls/capacity/actualtiming/freshphysicalSMT-peer-RAMhost4/"
    "ownedfree/ownerpausecancel/origin/cleanup remain genuine next inputs. "
    "Existing finite312MiB327155712B future/336MiBproposal byref, actualholding/images/"
    "serializer union Root resolves once, no oldgrant/refund/loan/globalwalk.\n"
    f"FileRefs {json.dumps(dict(completion=completion, prepared=ref(OUT / 'prepared.json'), amendment=ref(OUT / 'policy-dependency-amendment.json'), software_recipe=ref(OUT / 'new-only-software-recipe.json'), light_STOP=stop, affected=point))}\n"
    "Own26 sameowner/in_progress meaningfulnote+backupPASS; actualhelpers returned/reaped/"
    "handles/TMP/leases[], final return-guard-v1/return.json follows, deliveryroot-delivery-v1/"
    "return.json. Main/Git/Cargo/docs and otherowners untouched; no idle/futurequiet or nativeSTART. "
    "25.3 independentnew104/newconditional64 and original25 fourUNKNOWN/100unperformed/old64STOPPED "
    "preserved; allpauses/seals/defaultmodels/foreign/FAILED/NULL/feesUNKNOWN/decimal50GB held.\n"
)
with (OUT / "handoff.txt").open("x") as output:
    output.write(body)
print(
    json.dumps(
        dict(
            completion=completion,
            light_STOP=stop,
            affected=point,
            handoff=ref(OUT / "handoff.txt"),
        )
    )
)
