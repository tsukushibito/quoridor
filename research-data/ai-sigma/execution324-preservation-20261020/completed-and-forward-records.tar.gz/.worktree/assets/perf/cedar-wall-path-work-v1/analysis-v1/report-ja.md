# Wall/path26 fixed104 result

固定判定は **INCOMPLETE / RETAIN_BASELINE**。通常4manifest/dataはPASSだが、要求深さが完了したのは100/104件。root4は4passとも要求D6に対しD5でNodeLimit1Mに到達した。4UNKNOWNを埋めず、104枠は終了した。速度改善・無効果・一般的な同等性・棋力の認定はしない。

Current/Current、同一Cedar/Control/LMR/TT1M/PVS/path_tail/N1、固定深さmap、A-B-B-A各26 genuine prefixes / 6 chronological same-colour sessions / 全predecessorsを維持した。A=f686/BUILD84fd、B=ff209/BUILDd7c3。比較は新しい共通sourceに対するlegal_wallの局所変更で、旧画像417を対照にしていない。

全26rootについて4passの記録rootkey/rules/ply/fullweightedhistory、legal IDs、action/PV/valuebits/completeddepth/stop、TT世代、記録された全探索work辞書が一致した。正常返却・合法手・parent_unchangedは104/104、error/missing/cancelは0。内部heuristic table全エントリは直接観測しておらず、記録の一致と区別する。安全raceによるnominalな完了深さはfullwidth保証ではない。

| Pass | 完了/UNKNOWN | nodes | Search合計s | setup s | session reset s | session drop s | whole driver s |
|---|---:|---:|---:|---:|---:|---:|---:|
|A0|25/1|12970292|13.306856060|0.001545662|0.189823728|0.019356159|13.821971673|
|B1|25/1|12970292|13.044728154|0.003017895|0.201196358|0.015679551|13.443446829|
|B2|25/1|12970292|13.098193549|0.001968623|0.186599347|0.015997932|13.526134137|
|A3|25/1|12970292|13.520815551|0.003782964|0.244584354|0.013721579|14.010508566|

全26件を保持した記述的Search比 (B1+B2)/(A0+A3) は0.974475984426。.98条件、両B合計が両Aより小さい条件、stock二反復badcase条件は数値上満たす。しかし同じcapped rootを含むため、全104DepthComplete条件が偽であり、完了探索の速度改善として採用しない。成功subsetのみの昇格もしない。root別・stock別・反復別の比はper-root-correspondence.json、summary.json、per-call.csvに保持した。

意図した内部差は、2pawn legalityの同一wall mask構築/scanの共有。BFS二走査は保持し、実行時mask回数は未観測。saved profile shareを削減可能時間に換算しない。setup/reset/Search/whole/dropは別のnested区間で、合算して追加費用にしない。timeNoneなのでdeadline stop-tailはUNKNOWNとし、call teardown/publication区間を別保存した。

実測nodesは51,881,168/104M。accepted-inclusiveは73.374095sを一度だけ計上し、outer command 71.502312897sはnestedで加算しない。任意12診断/追加呼出し/ゲーム/RNG/CIは0、fees/globalactual/later tailsはUNKNOWN。

保存intake v1は任意result_file=Noneを必須と誤認しjournal0を一度読んだ後に失敗した。元のfailed helper/exit1、signal mask pending/persist attempted、cleanup trueを保持。v2は既に通常ownerがjournal一致を認めたmanifest内resultを再用し、journal再読・validator/FINALIZE/Search再実行は0。v1の失敗はnative結果を変更しない。初回report helperの引用符構文エラーも保持し、ファイル化したrendererのみ修正した。

次の具体的な未解決点は、保存されたD6 feasibility根拠がこのexact common configurationのroot4で再現しなかったこと。原因はこの比較から断定しない。代替深さ・quota・refillは未許可。デフォルト/モデル/orderingは維持し、Rootが受入れ後の候補専用code/fixture撤去を判断する。元Git/data/images/FAILED/UNKNOWNは保存する。
