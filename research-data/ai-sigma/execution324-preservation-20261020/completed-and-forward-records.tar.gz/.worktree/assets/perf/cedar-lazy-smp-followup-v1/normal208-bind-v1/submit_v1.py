"""Submit ONE original27 highest parent with direct Popen outside Cycle."""

from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from start_source_v1 import ACTOR, ISSUE, OWN, ROOT, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def load(path):
    return json.loads(path.read_bytes())


def main():
    runtime = OWN / "normal208-runtime-v1"
    plan = load(runtime / "entry-plan.json")
    assert plan["launch_affinity"] == [0, 12, 14, 18]
    assert (
        plan["parent_accepted_seconds"] == 7800
        and plan["outer_command_seconds"] == 7740
    )
    settings = load(Path(plan["settings"]["path"]))
    assert ref(Path(plan["settings"]["path"])) == plan["settings"]
    state = Path(plan["state_dir"])
    assert not state.exists() and not Path(settings["output"]).exists()
    assert len(settings["runs"]) == 8
    for run in settings["runs"]:
        assert run["command_timeout_seconds"] == 900 and run["child_cpu_cores"] == [
            0,
            12,
            14,
        ]
        assert run["perf"] is None and run["approved_plan"] is None
        assert all(not os.path.lexists(run[k]) for k in ["output", "data_root", "TMP"])
        assert Path(run["data_root"]).parent.is_dir()
    guards = []
    for name in [
        "normal208-intake-g16-v1",
        "normal208-materialize-g16-v1",
        "normal208-pre-submit-g16-v1",
    ]:
        path = OWN / name / "result.json"
        g = load(path)
        assert (
            g["status"] == "PASS"
            and g["TMP_remaining"] == []
            and not (path.parent / "TMP").exists()
        )
        for ident in [
            g["controller"],
            *[c["guardian_return"]["child"] for c in g["checks"]],
        ]:
            now = process.process_info(ident["pid"])
            assert (now is None and not Path(f"/proc/{ident['pid']}").exists()) or (
                now is not None and process.identity(now) != ident
            )
        guards.append(dict(file=ref(path), STOP=g["reader_STOP"]))
    m = load(runtime / "materialized.json")
    assert m["source_leases_remaining"] == []
    job = load(Path(plan["job_template"]["path"]))
    assert ref(Path(plan["job_template"]["path"])) == plan["job_template"]
    assert (
        job["issue"] == ISSUE
        and job["max_runtime_seconds"] == 7740
        and job["end_at"] is None
    )
    at = datetime.now(timezone.utc)
    job["end_at"] = (at + timedelta(seconds=7800)).isoformat()
    job_path = runtime / "job-entry-v1.json"
    jr = save(job_path, job)
    argv = [
        "taskset",
        "-c",
        "0,12,14,18",
        "bash",
        "scripts/dev/project-env.sh",
        "bash",
        "scripts/dev/research-job.sh",
        "submit",
        "--config",
        str(job_path),
        "--state-dir",
        str(state),
    ]
    intent = save(
        runtime / "submit-intent-v1.json",
        dict(
            at=at.isoformat(),
            argv=argv,
            config=jr,
            source=ref(Path(__file__)),
            launch_owner=process.identity(process.process_info(os.getpid())),
            source_guards_returned=guards,
            authority=ref(runtime / "authority-before-submit.json"),
            Root_source_release=m["actual_Root_source_release"],
            current_callers=m["caller_sources"],
            phase_supports=m["phase_supports"],
            source_leases_remaining=[],
            direct_Popen_outside_Cycle=True,
            actual_calls=0,
            RPC_not_native_entry=True,
            freshcontrols="Maintained normal parent/child owns fresh actual physicalSMT-peer/RAM/host/fullroots/free/source/env/ownerpausecancel/origin/deadline/serializer/cleanup admission",
        ),
    )
    env = {**os.environ, **settings["runs"][0]["env"]}
    env.pop("TMPDIR", None)
    env["PATH"] = "/home/vscode/.local/bin:" + env["PATH"]
    env["BEADS_ACTOR"] = ACTOR
    with subprocess.Popen(
        argv, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as p:
        stdout, stderr = p.communicate()
        rc = p.wait()
    for name, raw in [("submit.stdout", stdout), ("submit.stderr", stderr)]:
        path = runtime / name
        assert not path.exists()
        path.write_bytes(raw)
    result = save(
        runtime / "submit-return-v1.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            intent=intent,
            returncode=rc,
            directwait_reaped=True,
            pipes_closed=p.stdout.closed and p.stderr.closed,
            stdout=ref(runtime / "submit.stdout"),
            stderr=ref(runtime / "submit.stderr"),
            launcher_pid=p.pid,
            RPC_not_native_entry=True,
        ),
    )
    print(
        json.dumps(
            dict(
                returned=result,
                returncode=rc,
                stdout=stdout.decode(),
                stderr=stderr.decode(),
            )
        )
    )
    assert rc == 0 and p.stdout.closed and p.stderr.closed


if __name__ == "__main__":
    main()
