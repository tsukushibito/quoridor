# Lazy SMP shared-TT replacement：原27 first factor 保存解析

**速度改善は示していない。** 全104 fixed-depthがDepthCompleteで、2repeat Search合計のcandidate/control比は1.081304409（約8.1%長い）。保守的max(candidate Searchsum)/min(control Searchsum)=1.126622339。宣言した重大退行閾値1.20とroot閾値は超えず、保存された正しさ・100ms安全性を満たしたため、**条件付き新27 64局の機械的gateはPASS**。これは採用・棋力・一般速度の認定ではない。実game supportはUNISSUED、games0/CI0、default1を維持する。

## 比較の固定条件

Genuine control Build51379b64/image41701732とcandidate Build982166c7/image8ae3ef74。両方Current/N2、共通25互換source・tools/env、production差分はshared TTのsamegeneration深さ保護からwriter条件を除く一点のみ。LOCAL1・coherent Entry・typed Bound/full key/weighted history/context/namespaceのprobe資格・main-only snapshot・odd helper depth2・Cedar35cbb/Control/baseline LMR .7844/2.4696/3/4/3・PVS/path_tail/approxOFFは固定。過去f2bdや別時刻のclockをfair controlにしていない。

元26 genuine prefixes/3families/6same-colour chronological seriesを各RUNで元順再用。各arm104calls、O-N-N-O fixeddepth104→O-N-N-O 100ms/5ms104、全208calls/48sessions。TT TOTAL1M/session、allworker1M/call・総208M、perf/warmup/pilot/refill/sweep/newroots/4thread=0。d68 depth mapは原24 all104DepthComplete実績から固定し、censored29を完了時計に流用していない。stock bins2/6/6/6/6、stock0 shortfall4。歴史的book exposure YES、未見/IIDとは呼ばない。

## 全8RUNと時計の区別

| phase/block/arm         | Search sum s | main/helper nodes | whole driver s |  reset s | process CPU s | stops                                 |
| ----------------------- | -----------: | ----------------: | -------------: | -------: | ------------: | ------------------------------------- |
| fixed_depth/0/control   |     0.328075 |     357638/356864 |       0.938726 | 0.476140 |          0.68 | {'DepthComplete': 26}                 |
| fixed_depth/1/candidate |     0.340400 |     358399/362459 |       0.933540 | 0.464186 |          0.67 | {'DepthComplete': 26}                 |
| fixed_depth/2/candidate |     0.356707 |     356261/358236 |       0.957793 | 0.466169 |          0.73 | {'DepthComplete': 26}                 |
| fixed_depth/3/control   |     0.316616 |     347683/344791 |       0.919698 | 0.473895 |          0.62 | {'DepthComplete': 26}                 |
| fixed_clock/4/control   |     2.375802 |   2066665/1921661 |       2.995311 | 0.480778 |          4.76 | {'TimeLimit': 25, 'DepthComplete': 1} |
| fixed_clock/5/candidate |     2.375795 |   2085227/2085766 |       2.999610 | 0.473564 |          4.76 | {'TimeLimit': 25, 'DepthComplete': 1} |
| fixed_clock/6/candidate |     2.375678 |   2049363/2049635 |       2.975885 | 0.455872 |          4.76 | {'TimeLimit': 25, 'DepthComplete': 1} |
| fixed_clock/7/control   |     2.375701 |   2103286/1955291 |       2.984536 | 0.467702 |          4.77 | {'TimeLimit': 25, 'DepthComplete': 1} |

| phase       | Search合計N/O | whole driver N/O | publication前whole N/O | reset N/O |
| ----------- | ------------: | ---------------: | ---------------------: | --------: |
| fixed_depth |      1.081304 |         1.017708 |               1.016851 |  0.979285 |
| fixed_clock |      0.999994 |         0.999272 |               0.998311 |  0.979922 |

Search body、main callback receipt、allworker quiet/drain、setup/reset/rootprepare/journal/drop、whole driver、publication前whole、arena親receiptは異なる。nested値を親wholeへ加算しない。固定深さでsame-requestでも選択的tree/workは変わるためsame-work/fullwidth speedupとは呼ばない。

## 正しさと固定gate

ALL8通常manifest/data PASS、208/208 performed、errors/extra/unperformed/unscheduled0。保存rowの完全weighted履歴・root/手番/stock/session/合法集合が8RUNで対応、非synthetic、parent restored、root action合法、PV先頭対応、finite FP32 bits、N2 Current、main-only depth/receipt権限、合算nodes/evals、TT total容量、worker error無し、quiet/drain対応を確認。後続PV各childの合法性やcutoff時の履歴snapshotは再構成していない。これは有限観測の資格で、全fault・kernel parityの証明ではない。

fixeddepth104/104 DepthComplete。重大root indices=[]。固定規約は全104完了時の保守Search比>1.20、または任意rootの2repeat中央値比>1.25 **かつ** 絶対増分>10ms。もしcensorがあれば完了時間比はUNKNOWNで、有利subset/cap時間をspeedupにせず、固定深さNodeLimitだけでgamesを拒否しない。

clock104: {'TimeLimit': 100, 'DepthComplete': 4}。全main depth>=1/receipt<=100ms、最大receipt=0.088795649s。terminal Search p95=0.095042283s、max=0.095102033s（固定上限110/125ms）。Search_call_secondsはallworker quiet後の返却までを含む保守的terminalとしてgateに使い、直接quiet p95=0.095037461s/max=0.095086946sも別記する。NodeLimit horizonはUNKNOWN、DepthCompleteもsafe-race nominal深さを含みrootゲーム真値/oracleではない。

clock main depth中央値は改善roots=[13, 25]、悪化roots=[23]。整数depth増加をgamesの条件にしていない。fixeddepth candidate action差分roots=[]、value bits差分roots=[]、PV差分roots=[8]。O/O・N/N repeat差も表へ残し、schedule依存差を不正/同一仕事の仮定へ置き換えない。

## 共有TTと分母

| phase/arm/worker        |   nodes |   evals | TT probes | foreign key/context/numeric returns | contention skips |
| ----------------------- | ------: | ------: | --------: | ----------------------------------: | ---------------: |
| fixed_depth/control/0   |  705321 |  582561 |    173397 |                    64665/13389/7263 |             7327 |
| fixed_depth/control/1   |  701655 |  578887 |    173078 |                    80631/14404/7056 |             7308 |
| fixed_depth/candidate/0 |  714660 |  579935 |    197702 |                   102176/16127/8876 |             6332 |
| fixed_depth/candidate/1 |  720695 |  585811 |    198499 |                    71609/16350/8640 |             6532 |
| fixed_clock/control/0   | 4169951 | 3107147 |   1196104 |                399841/147838/116726 |            94912 |
| fixed_clock/control/1   | 3876952 | 2831602 |   1172086 |                387218/177627/145123 |            93817 |
| fixed_clock/candidate/0 | 4134590 | 3065085 |   1196033 |                395624/161741/133908 |            86613 |
| fixed_clock/candidate/1 | 4135401 | 3072752 |   1184257 |                390672/166622/135149 |            84470 |

worker0はmain、worker1はhelper。foreign-key/context/numericはnestedで、ordering hintも実pulled順そのものではない。main clock foreign numeric returnはO116726/N133908だが、独立に有用な情報・saved nodes・性能因果を示さない。contention skipsはprobe/insertの保存counterで、lock試行の正確な分母やPV再構成のskipを網羅せず、正確な競合率とは呼ばない。全root・family/series/stock/first-vs-continuedの分母と悪化をsummary、roots.csv、calls.csv、workers.csvへ保存した。

## 実費・停止・次の範囲

使用allworker nodes **19,159,225 / 208,000,000**。outer **56.144763131s once**、accepted-inclusive 58.260404sは別scope、nested added0。OS process全thread CPUはO10.83s/N10.92s。これはresult renderingを含みphysical NN callsではない。RSSはprocess累積highwaterでper-root/family peakではない。全fees/physical NN/global actualはUNKNOWN。未使用node権の返金・他factorへの貸与・quota resetなし。

実native+normalcollection STOPは93b13c2eでRootへ先行返却。全recorded main/inner/native/source/launcher IDsは新鮮な照合でabsent/different、directwait/reap/handles/TMP/sourceleases[]。現在のanalysis/通知helper lifetimeは別の実guard STOPで扱い、未来host quietを主張しない。

条件付き新27 64局は機械的gateを満たすが、**実support/normal entryは未発行**。Rootが実保持・fair source/currentcaller/資源を解決してからのみ、事前固定book indices33..64・両色64局・2非融通250M・100ms5・arena seed3242720261020、全64資格/32pairs/UNKNOWN0+実STOP後に唯一PCG64 seed3242720261021/10000/linear95へ進む。lower>.5ならこのfactorを次の研究N2 controlとして支持し、それ以外は現N2 controlを維持。default1/model/製品昇格はしない。旧22 dormant64、原24の64、他factorの枠は転用しない。

残るhelper補完性・同期粒度・reset再初期化は未実装で、自動all4実験へ進まない。今回のSearch改善は未観測であり、単純なdeeper保護だけから主因や棋力を確定しない。追加観測/ゲームからretentionの有用性が支持されなければ、Rootが比較専用delta/新fixtureを撤去しGit/画像/RAW/FAILED/unique evidenceを保全する。

全USERPAUSE/seals/defaults/models/weights/foreign/FAILED/NULL/UNKNOWN費用/decimal50GBを維持。

Evidence: /workspaces/quoridor/.worktree/assets/perf/cedar-lazy-smp-followup-v1/numeric-v1/analysis-v1/summary.json
