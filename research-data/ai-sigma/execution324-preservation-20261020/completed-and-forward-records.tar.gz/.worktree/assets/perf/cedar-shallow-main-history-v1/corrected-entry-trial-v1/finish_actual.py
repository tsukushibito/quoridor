"""Return actual binding helpers, then reuse the maintained normal submit client."""

import datetime
import hashlib
import json
from pathlib import Path

TRIAL = Path(__file__).resolve().parent
OUT = TRIAL / "actual-entry-v1"
source = (TRIAL.parent / "submit_actual104.py").read_text()
assert source.count('OUT = OWN / "normal104-actual-v1"') == 1
source = source.replace(
    'OUT = OWN / "normal104-actual-v1"', 'OUT = OWN / "actual-entry-v1"'
)
source = source.replace(
    "one_original104_sequence=True", "one_independent_new104_sequence=True"
)
with (TRIAL / "submit_actual.py").open("x") as output:
    output.write(source)


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


returns = []
known = []
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
for phase in (
    "actual-input-intake-v1",
    "actual-bind-guard-v1",
    "actual-admin-guard-v1",
):
    result = json.loads((TRIAL / phase / "return.json").read_text())
    assert (
        result["exit_code"] == 0
        and result["remaining"] == []
        and result["direct_child_reaped"]
        and result["handle_closes_complete"]
        and result["cleanup_complete"]
    )
    assert not (TRIAL / phase / "TMP").exists()
    returns.append(ref(TRIAL / phase / "return.json"))
    for identity in (
        json.loads((TRIAL / phase / "controller.json").read_text()),
        result["child"],
    ):
        path = Path("/proc") / str(identity["pid"]) / "stat"
        try:
            current = path.read_text().rsplit(")", 1)[1].split()[19]
        except FileNotFoundError:
            current = None
        assert current != str(identity["start_ticks"]) or boot != identity["boot_id"]
        known.append(
            dict(
                identity={
                    key: identity[key] for key in ("pid", "start_ticks", "boot_id")
                },
                current_start_ticks=current,
                absent_or_different=True,
            )
        )
stop = dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    materialized=ref(OUT / "materialized.json"),
    actual_returned_guards=returns,
    known_preparation_identities=known,
    directwait_reaped=True,
    handles_complete=True,
    TMP_remaining=[],
    source_leases_remaining=[],
    owned_processes_remaining=[],
    idle_reservations=[],
    own25_3_sameassignee_in_progress_note_backup="PASS before clock",
    new104_numerical_entry=False,
    compiler_tests_native_model_payload_RAW_RNG_proof_replay=0,
    current_finalizer="Actual return follows actual-finish-guard-v1/return.json; no self-absence claim",
    original_trial_and_failed_namespaces_unchanged=True,
)
with (OUT / "source-admin-STOP.json").open("x") as output:
    output.write(json.dumps(stop, indent=2) + "\n")
print(
    json.dumps(
        dict(
            source_admin_STOP=ref(OUT / "source-admin-STOP.json"),
            submit_client=ref(TRIAL / "submit_actual.py"),
        )
    )
)
