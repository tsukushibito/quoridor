"""Render the fixed-gate result and limitations without new analysis or RNG."""

import hashlib
import json
from pathlib import Path

TRIAL = Path(__file__).resolve().parent
OUT = TRIAL / "analysis-v1"
summary = json.loads((OUT / "summary.json").read_text())
gate = summary["gate"]
passes = summary["per_pass"]
rank_tables = json.loads((OUT / "rank-strata.json").read_text())
case = json.loads((OUT / "root14-wall207-case.json").read_text())
comparisons = json.loads((OUT / "paired-descriptive-comparisons.json").read_text())


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


lines = [
    "# 独立新25.3：浅い負main履歴half、固定104 ABBA比較",
    "",
    "新job74bc134aは4 normal manifest/data PASS。全104呼び出しが公開され、全件returned Ok・parent restore・合法action・completed depth>=1。errors/欠測/取消/NodeLimitは0。固定mechanical/serious-clock gateはPASSで、予告済み新64局の別supportを結べる段階になった。**新64はまだUNISSUED、games0/CI0/RNG0、default Currentは不変**。旧401b/9786の4 UNKNOWN・0 usable・100未実行・旧64 STOPPEDとは別の人間許可単位で、元記録は改変しない。",
    "",
    f"候補B最大Searchは{gate['candidate_max_Search_s'] * 1000:.6f}ms（<=150ms）。全52 A/B標本それぞれのlinear p95はA {gate['current_linear_p95_s'] * 1000:.6f}ms、B {gate['candidate_linear_p95_s'] * 1000:.6f}ms、比B/A {gate['candidate_current_p95_ratio']:.9f}（<=1.20）。これは予告済み安全/大幅時計回帰gateであり、速度・強さ・同一仕事量の改善資格ではない。整数深さ増加はgateに追加しない。",
    "",
    "| pass | setting | calls/合法completed | stop | depth中央値 | Search p95/max ms | nodes |",
    "|---|---|---:|---|---:|---:|---:|",
]
for entry in passes:
    times = entry["Search_call_seconds"]
    lines.append(
        f"| {entry['arm']}{entry['pass_index']} | {entry['setting']} | 26/26 | 25 TimeLimit +1 DepthComplete | {entry['completed_depth']['median']:g} | {times['p95'] * 1000:.6f}/{times['maximum'] * 1000:.6f} | {entry['nodes']:,} |"
    )
lines.extend(
    [
        "",
        "要求D64全体では100 TimeLimit/UNKNOWNと4 DepthComplete/COMPLETEを保つ。UNKNOWNをD64達成へ読み替えない。採用済みcompleted moveの深さと未完了次iterationは別で、safe-race-leaf nominal depthはfull-width保証ではない。今回gateは合法committed depth>=1を要求する定義だった。",
        "",
        "全nodesは6,551,433/新104M上限。A/Bは別の実treeと履歴更新を通る。sourceはbonus-before-gravity以外を保持したが、実node/eval/cutoff/LMR/PVS workは同一でない。API stop-tail=max(0,Search_call_seconds-.095)を各行に保存し、各pass最大はA0 4.942818ms/B1 5.322651ms/B2 11.116403ms/A3 11.723726ms。これはobserver込みAPI returnの超過で、parent arena authorityの受領・全体停止保証はUNMEASURED。main callback receiptはこのOpportunityルートではNULLのまま。",
        "",
        "## 同じ固定21 reference actionの順位",
        "",
        "各policy自身の選択を正解とせず、事前固定した旧21の同じactionを照合。first/latest committed snapshotの各26順位は全て記録済み。旧21 referenceは25 node-capped+1 depth-complete由来でoracleではない。",
        "",
        "| pass | first top1/3/5 | latest top1/3/5 | latest TT/PV priority / ordinary |",
        "|---|---:|---:|---:|",
    ]
)
for index in range(4):
    first = next(
        row
        for row in rank_tables
        if row["pass_index"] == index
        and row["slot"] == "first_completed"
        and row["stratum"] == "all26"
    )
    latest = next(
        row
        for row in rank_tables
        if row["pass_index"] == index
        and row["slot"] == "last_completed"
        and row["stratum"] == "all26"
    )
    lines.append(
        f"| {passes[index]['arm']}{index} | {first['top1']}/{first['top3']}/{first['top5']} | {latest['top1']}/{latest['top3']}/{latest['top5']} | {latest['current_snapshot_tiers'].get('0', 0)}/{latest['current_snapshot_tiers'].get('4', 0)} |"
    )
lines.extend(
    [
        "",
        "firstは全26がordinary tier4。latestのtop1は上表のTT/PV promotionに支配されるため、top1全体をhistory改善と呼ばない。旧21のordinary-reference8件とpromotion-reference18件による層別も別保存し、今回の実snapshot tierの違いを明示している。",
        "",
        "B1−A0のlatest reference順位は改善0/同じ22/悪化4、B2−A3は改善1/同じ19/悪化6。深さ差はB1−A0が増1/同25/減0、B2−A3が増2/同22/減2。action一致は26/26と25/26、PV一致24/26と22/26。これを新しいgateやfamily選別へ転用しない。",
        "",
        "同一policy反復でもA3−A0はlatest順位が改善5/同21/悪化0、depth増1/同23/減2、B2−B1はlatest順位改善3/同23/悪化0、depth増0/同24/減2。時計、warm TT/historyのtree進行、完了/未完了iterationの違いがあり、単一の順位差をpenaltyの因果効果にしない。26 roots/3 families/6 same-colour warm seriesを2反復ずつ見た条件付き記述であり、104独立標本や汎化精度ではない。stock帯・stockそのもの・session-first/continued・family・session別表を全て保存。",
        "",
        "## 動機case：root14/wall207",
        "",
        "| pass | first/latest ref rank | first/latest fullsigned history | actual action/depth |",
        "|---|---:|---:|---:|",
    ]
)
for row in case:
    first = row["reference_snapshots"]["first_completed"]
    latest = row["reference_snapshots"]["last_completed"]
    lines.append(
        f"| {row['arm']}{row['pass_index']} | {first['recorded_rank']}/{latest['recorded_rank']} of97 | {first['fullsigned_history']}/{latest['fullsigned_history']} | {row['action']}/{row['completed_depth']} |"
    )
lines.extend(
    [
        "",
        "このcaseは全passでaction57/depth4。Halfのscoreが高いこととrank7/8の違いは観測できるが、Current反復もrank8→7であり、旧rank94や旧負deltaが誤り・害だったとは言えない。普通のroot continuationは空でmain寄与を読むという既知の適用範囲と、内部continuation/updateの出所は分離する。今回104はupdate provenance ringを増設していないため、実entryのbonus/重力deltaの帰属や浅い未確認penaltyの頻度はUNKNOWN。履歴の目的にはearly cutoff usefulnessがあり、深い参照手の順位のみで誤学習とはしない。",
        "",
        "## 費用・custody・次の有限段階",
        "",
        f"新25.3 accepted-inclusiveは{summary['accepted_inclusive_seconds_once']:.6f}秒を一度だけ計上、outer command {summary['outer_command_seconds_nested']:.9f}秒は内数。各native/iteration/Search/observer/setup/reset/drop等を加算しない。各nativeのsetup/reset/teardown/drop/wholeはnative-summary-custody.json、全workはcompact-rows.json/internal-stock-work.json、actual stopはcollection-v1/native-normal-source-STOP.json。全費用/globalactual/後続tailはUNKNOWN。旧25の費用と科学的使用枠は別で非lendingのまま。",
        "",
        "104に対するbootstrap/CI/RNG・Search・qualifier・旧モデル/RAW・FINALIZEの再実行は0。既存normal qualificationを保ち、今回journal/resultのcustodyと固定saved条件を読むだけ。scout call count・return-rank histogram・欠けた観測window・parent authority receiptは補完しない。",
        "",
        "予告済み新64は同じ候補1つ/32 canonical firstbook families/bothcolours/100ms5/N1/max200ply/独自1.024G、seed3242520261020・既存native family mapping・bootstrap10000/floor-ceil95を不変とする。歴史的exposureと3family overlapは明記済みでIID unseenとは呼ばない。全64/32pairs/UNKNOWN0＋実STOP後だけ唯一のnative family CIを用い、lower>.5の有限支持以外はCurrentを保つ。新support/holding/current source・origin/actual fairwindow/fresh admissionは未発行なので、今回はゲームを投入しない。Rootが実ended holdingを一度結ぶ。",
    ]
)
path = OUT / "report-ja.md"
with path.open("x") as output:
    output.write("\n".join(lines) + "\n")
minimum = dict(
    issue="quoridor-4lc.324.25.3",
    actual_job=summary["actual_job"],
    normal_manifest_data_PASS=4,
    calls_published=104,
    legal_committed_depth_at_least1_restored=104,
    errors_missing_cancelled_NodeLimit=0,
    requested_D64_TimeLimit_UNKNOWN=100,
    requested_D64_DepthComplete=4,
    total_actual_nodes=summary["total_actual_nodes"],
    gate_pass=gate["gate_pass"],
    candidate_max_Search_s=gate["candidate_max_Search_s"],
    A_linear_p95_s=gate["current_linear_p95_s"],
    B_linear_p95_s=gate["candidate_linear_p95_s"],
    p95_B_over_A=gate["candidate_current_p95_ratio"],
    new64_status="GATE_MET_BUT_SUPPORT_UNISSUED_GAMES0",
    native_family_CI_RNG=0,
    Current_default_unchanged=True,
    effect="Mixed descriptive ranks/depth with within-policy variability; no strength/causal harm/noeffect/default adoption claim",
    accepted_inclusive_seconds_once=summary["accepted_inclusive_seconds_once"],
    outer_seconds_nested=summary["outer_command_seconds_nested"],
    summary=ref(OUT / "summary.json"),
    report=ref(path),
    native_normal_source_STOP=ref(
        TRIAL / "collection-v1/native-normal-source-STOP.json"
    ),
    old_original25_4UNKNOWN_100unperformed_STOPPED64_immutable=True,
    forward_conditions=ref(TRIAL / "conditional64.draft.json"),
    future64_holding_bound_B=205520896,
    actual_new64_support_capacity_origin=None,
)
with (OUT / "minimum-result.json").open("x") as output:
    output.write(json.dumps(minimum, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            minimum=ref(OUT / "minimum-result.json"),
            report=ref(path),
            gate_pass=gate["gate_pass"],
            new64="UNISSUED_GAMES0",
        )
    )
)
