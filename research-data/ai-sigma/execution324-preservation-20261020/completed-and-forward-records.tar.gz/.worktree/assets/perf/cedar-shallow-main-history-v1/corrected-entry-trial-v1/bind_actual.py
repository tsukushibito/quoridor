"""Bind issued new-trial metadata through the current canonical normal owners."""

import copy
import datetime
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
TRIAL = Path(__file__).resolve().parent
OWN = TRIAL.parent
OUT = TRIAL / "actual-entry-v1"
OUT.mkdir()
ENTRY = (
    ROOT
    / ".artifacts/research-team/integration324/cedar-shallow-main-history-v1/corrected104-entry-v1"
)


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def document(reference):
    path = Path(reference["path"])
    assert ref(path) == reference
    return json.loads(path.read_bytes())


def save(name, value):
    path = OUT / name
    with path.open("x") as output:
        output.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


issued_ref = dict(
    path=str(ENTRY / "issued-inputs.json"),
    sha256="5d1858a471df16eb1ae949ecb62fbc06c0466525bcb2baa6c554b5eb68e2b35f",
    bytes=995,
    mode="0644",
)
issued = document(issued_ref)
release = document(issued["release"])
support_ref = issued["phase_supports"][0]
support = document(support_ref)
trial = document(support["new_trial"])
protocol = document(support["fixed_protocol"])
assert trial["issue"] == support["issue"] == "quoridor-4lc.324.25.3"
assert trial["new_trial_usage"]["accepted_jobs"] == 0
assert support["whole_B"] == support["limits"]["owned_B"] == 503316480
assert support["limits"]["free_B"] > 0
manifest = document(release["software_manifest"])
assert manifest["artifact"] == release["artifact"]
assert (
    manifest["status"] == "PASS"
    and manifest["cleanup_complete"]
    and manifest["remaining"] == []
)
assert (
    release["artifact"]["sha256"]
    == "f68639f78c816b9d590199f43cfccb96f63ed6f1e97e6cb461182a91c66ee3d7"
)
callers = release["current_four_callers"]
assert len(callers) == 4
sequence = json.loads((TRIAL / "sequence.draft.json").read_text())
future = Path(sequence["output"]).parent
future.mkdir(exist_ok=True)
assert future.resolve(strict=True) == future
assert (
    not Path(sequence["output"]).exists()
    and not (future / "parent-runtime-v1").exists()
)
for root in support["roots"]:
    path = Path(root)
    assert path.resolve(strict=True) == path and path.is_relative_to(ROOT)
for run in sequence["runs"]:
    parent = Path(run["data_root"]).parent
    parent.mkdir(parents=True, exist_ok=True)
    assert parent.resolve(strict=True) == parent
    assert not Path(run["data_root"]).exists()
    assert Path(run["data_root"]).is_relative_to(OWN)
    assert Path(run["owner"]).resolve(strict=True) == ROOT
original_evidence = json.loads(
    (OWN / "normal104-actual-v1/numerical-000.json").read_text()
)["original_evidence"]
assert original_evidence["sha256"].startswith("641ca6c3")
reader = dict(
    path=str(ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"),
    mode="LOCK_SH|LOCK_NB",
    leases_remaining=[],
)
new_experiments = []
owner_checks = []
with Path(reader["path"]).open("a") as handle:
    fcntl.flock(handle, fcntl.LOCK_SH | fcntl.LOCK_NB)
    reader["acquired_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for caller in callers:
        assert ref(Path(caller["path"])) == caller
    loader = importlib.util.spec_from_file_location(
        "corrected104_actual_current_owner", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    sys.modules[loader.name] = lc
    loader.loader.exec_module(lc)
    for index, run in enumerate(sequence["runs"]):
        experiment = document(run["experiment"])
        assert experiment["config"] == protocol["passes"][index]["config"]
        assert experiment["schedule"] == protocol["schedule"]
        assert experiment["canonical_plan_sha256"] == ""
        experiment["build_manifest"] = release["software_manifest"]
        experiment["argv"][0] = release["artifact"]["path"]
        config, requests = lc.measurement_config(experiment)
        assert (
            len(requests) == 26
            and config["shallow_main_history"] == protocol["passes"][index]["setting"]
        )
        assert (
            config["search_cpu_cores"] == [12]
            and config["native_memory_bytes"] == 2684354560
        )
        assert (
            config["root_ordering_quality"] is True
            and config["neighbour_opportunity"] == "off_shadow"
        )
        assert config.get("history_provenance") is None
        numerical = lc.numerical_fields(experiment, manifest)
        numerical.update(
            original_evidence=original_evidence,
            correspondence_only=True,
            scope="Inherited641ca structural normal correspondence only; no new model/policy/parity qualification",
            source_owner=callers[0],
            actual_software_Build=release["software_manifest"],
            new_model_or_head_calls=0,
        )
        experiment["numerical_qualification"] = save(
            f"numerical-{index:03d}.json", numerical
        )
        experiment_ref = save(f"experiment-{index:03d}.json", experiment)
        new_experiments.append(experiment_ref)
        run.update(
            artifact=release["artifact"],
            experiment=experiment_ref,
            caller_sources=callers,
            support=support_ref,
            owned_outputs=support["roots"],
            limits=copy.deepcopy(support["limits"]),
            approved_plan=None,
        )
        run["argv"] = [
            release["artifact"]["path"],
            "measure",
            "--experiment",
            experiment_ref["path"],
            "--experiment-sha256",
            experiment_ref["sha256"],
        ]
        assert run["child_cpu_cores"] == [0, 12]
        lc.caller_source_refs(run, experiment)
        lc.numerical_check(experiment, manifest)
        assert lc.native_cpu_cores(run) == [0, 12]
        owner_checks.append(
            dict(
                index=index,
                native_cpu_cores=[0, 12],
                current_four_callers=True,
                current_measurement_config=True,
                structural_numerical_correspondence=True,
                namespace_owner=str(ROOT),
                owned_outputs=support["roots"],
            )
        )
    fcntl.flock(handle, fcntl.LOCK_UN)
    reader["released_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
sequence["limits"] = support["limits"]
settings = save("settings.json", sequence)
job = json.loads((TRIAL / "job.draft.json").read_text())
assert job["issue"] == "quoridor-4lc.324.25.3" and job["max_runtime_seconds"] == 1140
job["resource_contract"] = settings["path"]
job["argv"] = [
    "/home/vscode/.cache/inference/envs/quoridor-training/bin/python",
    "-B",
    str(ROOT / "scripts/dev/research-lifecycle.py"),
    "sequence",
    "--intent",
    settings["path"],
    "--sha256",
    settings["sha256"],
]
job_ref = save("job-template.json", job)
result = save(
    "materialized.json",
    dict(
        status="ACTUAL_INDEPENDENT_NEW104_BOUND_UNENTERED",
        issue=job["issue"],
        original_new_trial=support["new_trial"],
        issued=issued_ref,
        release=issued["release"],
        support=support_ref,
        capacity=issued["capacity"],
        settings=settings,
        job_template=job_ref,
        experiments=new_experiments,
        state_dir=str(future / "parent-runtime-v1"),
        current_callers=callers,
        source_reader=reader,
        current_normal_owner_checks=owner_checks,
        actual_origin_end_at="STAMP_ONCE_AT_DIRECT_SUBMIT",
        launch_affinity=[0, 12, 18],
        parent_accepted_s=1200,
        command_s=1140,
        RUN_s=180,
        native_START=None,
        new_trial_entered_calls=0,
        historical417_513_fallback=False,
        normal_runtime_fresh_admission="physicalSMT/peer/RAM/host4/fullroots/ownedfree/source/currentcallers/pausecancel/environment/serializer/origin/cancel/cleanup remain actual normal owners",
    ),
)
print(
    json.dumps(
        dict(materialized=result, settings=settings, job=job_ref, source_reader=reader)
    )
)
