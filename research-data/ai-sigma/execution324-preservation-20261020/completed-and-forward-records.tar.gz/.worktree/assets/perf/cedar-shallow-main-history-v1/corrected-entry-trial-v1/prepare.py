"""Independent result-before trial annotation and ordinary nonrunnable drafts."""

import copy
import hashlib
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = OUT.parent
ISSUE = "quoridor-4lc.324.25.3"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def document(reference):
    path = Path(reference["path"])
    assert ref(path) == reference
    return json.loads(path.read_bytes())


def save(name, value):
    path = OUT / name
    with path.open("x") as output:
        output.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


original_ref = ref(OWN / "protocol-v1/protocol.json")
assert (
    original_ref["sha256"]
    == "bcaebc171cbb4662676461be36214ae77e86425e78439ca3ede815a73bb95d02"
)
assert original_ref["bytes"] == 9199 and original_ref["mode"] == "0644"
original = document(original_ref)
schedule = document(original["schedule"])
document(original["reference_actions"])
conditions = document(original["conditional64"])
document(conditions["family_seed_and_colours"])
holding = document(original["holding"])
for phase in original["passes"]:
    config = document(phase["config"])
    assert config["shallow_main_history"] == phase["setting"]
    assert phase["order"] == list(range(26))

future = OUT / "normal-search-abba-v1"
assert not future.exists()
sequence = json.loads((OWN / "normal104-actual-v2/settings.json").read_text())
sequence["output"] = str(future / "execution-v1")
sequence["limits"] = None
experiments = []
scientific_joins = []
for index, run in enumerate(sequence["runs"]):
    prior = document(run["experiment"])
    experiment = copy.deepcopy(prior)
    assert experiment["config"] == original["passes"][index]["config"]
    assert experiment["schedule"] == original["schedule"]
    experiment["build_manifest"] = None
    experiment["numerical_qualification"] = None
    experiment["argv"][0] = None
    assert experiment["canonical_plan_sha256"] == ""
    for key in (
        "config",
        "schedule",
        "inputs",
        "models",
        "dynamic_libraries",
        "rules",
        "distance_units",
        "value_perspective",
        "planned_slots",
        "batch",
    ):
        assert experiment[key] == prior[key]
    experiment_ref = save(f"experiment-{index:03d}.draft.json", experiment)
    experiments.append(experiment_ref)
    run["experiment"] = experiment_ref
    run["artifact"] = None
    run["caller_sources"] = None
    run["support"] = None
    run["limits"] = None
    run["owned_outputs"] = None
    run["approved_plan"] = None
    run["output"] = str(future / f"measure-{index:03d}/operation")
    run["data_root"] = str(future / f"measure-{index:03d}/data")
    run["TMP"] = str(future / f"measure-{index:03d}/TMP")
    run["env"]["TMPDIR"] = run["TMP"]
    for output in run["data"]:
        output["path"] = str(Path(run["data_root"]) / Path(output["path"]).name)
    run["argv"] = [
        None,
        "measure",
        "--experiment",
        experiment_ref["path"],
        "--experiment-sha256",
        experiment_ref["sha256"],
    ]
    run["child_cpu_cores"] = [0, 12]
    assert run["command_timeout_seconds"] == 180
    scientific_joins.append(
        dict(
            index=index,
            config=experiment["config"],
            schedule=experiment["schedule"],
            same_original_scientific_inputs=True,
        )
    )
    save(f"run-{index:03d}.draft.json", run)
settings_ref = save("sequence.draft.json", sequence)
job = json.loads((OWN / "normal104-actual-v1/job-template.json").read_text())
job.update(
    issue=ISSUE,
    argv=None,
    end_at=None,
    resource_contract=None,
    max_runtime_seconds=1140,
)
job_ref = save("job.draft.json", job)
plan = save(
    "normal-bindings.draft.json",
    dict(
        status="DRAFT_NOT_RUNNABLE",
        measurement_canonical_plan_sha256="",
        approved_plan=None,
        reason="Normal measurement owner has empty canonical Plan; no arena Plan fabricated",
        actual_current_measurement_factory_join=None,
        actual_numerical_fields_structural_join=None,
        inherited_structural_evidence="641ca only; not a new model/policy/parity qualification",
        current_RUN_four_callers=None,
        artifact=None,
        BUILD=None,
        phase_support=None,
        actual_source_adoption_STOP=None,
        actual_origins_end_at=None,
        physical_RAM_SMT_peer_free_fullroots_pausecancel="Mandatory normal runtime admission, not this draft's certificate",
    ),
)
conditional = copy.deepcopy(conditions)
conditional.update(
    status="NEW_CHILD_PROSPECTIVE_CONDITIONAL64_UNISSUED_NOT_RUNNABLE",
    same_new_genuine_image_both_arms=None,
    actual_BUILD=None,
    source_revision=None,
    support=None,
    no_game_entry_until="This independent new104 passes frozen gates, then actual separate new64 support/source/allocation/origin/fresh normal admission",
)
conditional_ref = save("conditional64.draft.json", conditional)
forecast_ref = save(
    "future-holding-proposal.json",
    dict(
        status="FUTURE_PRODUCER_BOUND_ONLY_NO_GRANT",
        new104=holding["search"],
        prospective_new64=holding["conditional_arena"],
        original_producer_contract=original["holding"],
        new104_future_B=448790528,
        new64_future_B=205520896,
        previous_source_original_failed_retention_actual_B=None,
        new_image_actual_B=None,
        issued_whole_capacity_allocation=None,
        full_actual_owned_roots=None,
        serial_native_and_TMP_lifetimes=True,
        model_input_library_image_copies=0,
        payload_requalification_or_old_holding_walk=0,
        Root_resolution="Root joins actual ended/current retention once with these finite future bounds and real images, capacity/fullroots/free; original480MiB support is not this child's grant",
        global_cap_decimal_B=50000000000,
        tails_globalactual_fullfees="UNKNOWN",
    ),
)
annotation = save(
    "trial.json",
    dict(
        issue=ISSUE,
        parent_issue="quoridor-4lc.324.25",
        prospective_trial_identity=str(OUT),
        status="FIXED_RESULT_BEFORE_NEW104_UNENTERED_UNADMITTED",
        direct_human_new_authorization="2026-10-20 independent new104/104M plus prospective conditional new64/32families/max1.024G; not old unperformed100 transfer or UNKNOWN4 refill",
        original_protocol=original_ref,
        frozen_passes=original["passes"],
        frozen_schedule=original["schedule"],
        frozen_same_reference_actions=original["reference_actions"],
        new_authorized_limits=dict(
            Search_calls=104,
            Search_node_upper=104000000,
            calls_per_pass=26,
            nodes_per_pass=26000000,
            per_call_nodes=1000000,
            prospective_conditional_games=64,
            prospective_conditional_families=32,
            prospective_conditional_node_upper=1024000000,
        ),
        new_trial_usage=dict(
            accepted_jobs=0,
            native_calls=0,
            Search_attempts=0,
            completed_Search=0,
            games=0,
            node_charges=0,
        ),
        old_attempts_immutable=dict(
            original_jobs=[
                "401bfae3-28c7-4ec7-88e0-1466803a3f53",
                "978638b2-eb02-43eb-89cc-19fd6fc3c900",
            ],
            descriptive_result=ref(OWN / "normal104-collection-v1/minimum-result.json"),
            UNKNOWN_API_slots=4,
            usable_Search=0,
            unperformed=100,
            TT_generation="0->0 in four attempted rows",
            old_conditional64="STOPPED_UNISSUED",
            all_costs_masks_NULL_FAILED_preserved=True,
            rights_refunded_reset_lent=0,
        ),
        warm_state=original["warm_state"],
        search_bound=original["search_bound"],
        observation=original["observation"],
        strata=original["strata"],
        stop_tail=original["stop_tail"],
        nonclock_vs_clock=original["nonclock_vs_clock"],
        mechanical_gate=original["mechanical_gate"],
        serious_clock_gate=original["serious_clock_gate"],
        analysis_recipe=ref(OWN / "normal-control-preparation-v1/analysis-recipe.json"),
        conditional64=conditional_ref,
        exposure_annotation=ref(OWN / "protocol-v1/exposure-annotation.json"),
        historical_exposure="YES; canonical32 are historically exposed, with three clock/tuning family overlaps as frozen original metadata. Not IID/unseen; no success replay or data payload read.",
        bootstrap="Only full new64/32pairs/UNKNOWN0: original native familybootstrap seed3242520261020/resamples10000/custom RNG/floor(.025*9999),ceil(.975*9999); no external RNG, rerun or CI before full qualification",
        new_genuine_same_image_Build_current_source_callers_support_origin=None,
        historical_context_only=dict(
            image="41701732", BUILD="51379b64", cannot_be_used_as_fallback=True
        ),
        required_pending_source=dict(
            private_fixed_binding=ref(OWN / "timed-rootquality-repair-v1/binding.json"),
            source_STOP=ref(OWN / "timed-rootquality-repair-v1/source-STOP.json"),
            related_Max_review="Root-owned25.2; not author SOURCE_CLEAR",
            sparse_adoption=None,
            canonical_new_callee_boundary1=None,
            affected_Clippy=None,
            genuine_release_and_collection_STOP=None,
        ),
        normal_drafts=dict(
            sequence=settings_ref,
            experiments=experiments,
            job=job_ref,
            plan_numerical_bindings=plan,
        ),
        draft_scientific_correspondence=scientific_joins,
        normal_runtime_proposal=dict(
            search_worker=12,
            main_guardian=0,
            outer=18,
            explicit_launcher=[0, 12, 18],
            child_cpu_cores=[0, 12],
            family_B=4294967296,
            controller_B=1610612736,
            native_B=2684354560,
            host_reserve_B=4294967296,
            GPU=0,
            threads=1,
            parent_s=1200,
            command_s=1140,
            perRUN_s=180,
            prospective_new64_parent_s=2400,
            prospective_new64_command_s=2340,
            prospective_new64_RUN_s=1800,
        ),
        whole_proposal=forecast_ref,
        submit="One actual highest parent outside Cycle with explicit affinity; real origin/end_at once after source/software/support. AcceptedRPC is not nativeSTART. Original completion once-only collection; no poll/observer/duplicate.",
        failure_rule="Preserve any future refusal and exact cause; entry-only causal repair, no unchangedretry or automatic UNKNOWN refill/effect inference. Actual source/software repair alone does not license another comparison.",
        interpretation="DefaultCurrent until finite accepted result; no oracle/action correctness or harm/equality/strength/default promotion from descriptive root ranks or failed admission",
        source_Main_Cargo_test_native_RAW_modelpayload_RNG_activity=0,
        other_owner_private_source_reads_writes=0,
        old_namespaces_overwrites=0,
        actual_trial_data_roots_created=False,
    ),
)
prepared = save(
    "prepared.json",
    dict(
        status="NEW_INDEPENDENT_TRIAL_FIXED_DRAFT_NOT_RUNNABLE",
        issue=ISSUE,
        trial=annotation,
        sequence=settings_ref,
        job=job_ref,
        conditional64=conditional_ref,
        holding_proposal=forecast_ref,
        actual_image_BUILD_source_support_origins=None,
        new_calls_games_entered=0,
        metadata_only=True,
        no_Main_reader_or_source_import=True,
    ),
)
assert not future.exists()
assert isinstance(schedule, (dict, list))
print(
    json.dumps(dict(prepared=prepared, trial=annotation, future_holding=forecast_ref))
)
