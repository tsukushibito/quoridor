"""Fixed ABBA descriptive assessment from the completed new-trial records only."""

from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics

TRIAL = Path(__file__).resolve().parent
OWN = TRIAL.parent
COLLECT = TRIAL / "collection-v1"
OUT = TRIAL / "analysis-v1"
OUT.mkdir()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def document(reference):
    path = Path(reference["path"])
    assert ref(path) == reference
    return json.loads(path.read_bytes())


def save(name, value):
    path = OUT / name
    with path.open("x") as output:
        output.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


def linear(values, probability):
    values = sorted(values)
    if not values:
        return None
    index = probability * (len(values) - 1)
    lower, upper = math.floor(index), math.ceil(index)
    return values[lower] + (values[upper] - values[lower]) * (index - lower)


def metrics(values):
    return dict(
        n=len(values),
        minimum=min(values) if values else None,
        median=statistics.median(values) if values else None,
        p95=linear(values, 0.95),
        maximum=max(values) if values else None,
        total=sum(values),
    )


def same_reference_snapshot(snapshot, reference):
    if "depth" not in snapshot:
        return None
    entries = snapshot["entries"]
    position = next(
        (index for index, entry in enumerate(entries) if entry[0] == reference), None
    )
    entry = entries[position] if position is not None else None
    key = entry[1] if entry is not None else None
    # Same rank/decode as the existing saved21 analysis: actual recorded Control
    # order, one-based; no shadow sorting or regenerated action/geometry labels.
    history = 0x7FFFFFFF - ((key >> 8) & 0xFFFFFFFF) if key is not None else None
    tier = key >> 40 if key is not None else None
    return dict(
        slot=snapshot["slot"],
        completed=snapshot["completed"],
        depth=snapshot["depth"],
        reference_action=reference,
        recorded_rank=position + 1 if position is not None else None,
        tier=tier,
        promotion_vs_ordinary="TT_PV_priority"
        if tier == 0
        else "ordinary_history"
        if tier == 4
        else "other_priority"
        if tier is not None
        else "UNKNOWN",
        fullsigned_history=history,
        recorded_full_key=key,
        legal_entries_recorded=len(entries),
        selected=snapshot["selected"],
        value_bits=snapshot["value_bits"],
        promoted=snapshot["promoted"],
        previous_completed=snapshot["previous_completed"],
        numeric_tt_return=snapshot["numeric_tt_return"],
        TT_generation=snapshot["TT_generation"],
        eligible_root_TT=snapshot["eligible_root_TT"],
        window_bits=snapshot["window_bits"],
        children_recorded=len(snapshot["children"]),
        PVS_researches=sum(child[2] for child in snapshot["children"]),
        unreturned_children=sum(child[3] is None for child in snapshot["children"]),
        entry_absent_is_unknown_not_unvisited=True,
    )


protocol = json.loads((OWN / "protocol-v1/protocol.json").read_text())
reference_data = document(protocol["reference_actions"])
reference_by_root = {entry["root"]: entry for entry in reference_data["roots"]}
requests = document(protocol["schedule"])
intake = json.loads((COLLECT / "normal-manifest-intake.json").read_text())
assert len(intake) == 4 and len(requests) == len(reference_by_root) == 26
rows = []
sources = []
native_summaries = []
internal = defaultdict(Counter)
for packet in intake:
    index = packet["index"]
    manifest = packet["manifest"]
    qualified = manifest["data"]["measurement"]
    assert manifest["status"] == manifest["data"]["status"] == "PASS"
    assert (
        qualified["journal_result_rows_agree"]
        and not qualified["journal_partial_tail"]
        and not qualified["unreturned_tail"]
    )
    journal_ref = next(
        item
        for item in manifest["data"]["files"]
        if item["path"].endswith("measurements.jsonl")
    )
    path = Path(journal_ref["path"])
    digest = hashlib.sha256()
    size = count = 0
    with path.open("rb") as source:
        for raw in source:
            digest.update(raw)
            size += len(raw)
            row = json.loads(raw)
            request = row["request"]
            assert request == requests[count]
            root = request["root"]
            meta = reference_by_root[root]
            measurement = row["measurement"]
            assert (
                measurement["actual_shallow_main_history"]
                == protocol["passes"][index]["setting"]
            )
            opportunity = measurement.get("neighbour_opportunity", {})
            snapshots = {
                snapshot["slot"]: same_reference_snapshot(snapshot, meta["action"])
                for snapshot in opportunity.get("root_ordering_quality", [])
            }
            work = measurement.get("work", {})
            for stock in opportunity.get("by_internal_stock") or []:
                internal[(index, stock["stock"])].update(
                    {
                        key: value
                        for key, value in stock.items()
                        if key != "stock" and type(value) is int
                    }
                )
            legal = measurement.get("root_legal_action_ids")
            action = measurement.get("action")
            returned = measurement.get("returned")
            depth = measurement.get("completed_depth")
            usable = (
                returned == "Ok"
                and measurement.get("error") is None
                and measurement.get("parent_unchanged") is True
                and opportunity.get("parent_restored") is True
                and isinstance(depth, int)
                and depth >= 1
                and legal is not None
                and action in legal
            )
            record = dict(
                pass_index=index,
                arm="A" if index in (0, 3) else "B",
                setting=protocol["passes"][index]["setting"],
                root_index=root,
                request_id=request["id"],
                session=request["session"],
                family=meta["family"],
                turn=meta["turn"],
                stock=meta["stock"],
                band=meta["band"],
                session_first=meta["session_first"],
                old_reference_tier=meta["old_tier"],
                same_frozen_reference_action=meta["action"],
                source_journal=journal_ref,
                source_row_sha256=hashlib.sha256(raw).hexdigest(),
                root_identity=row["root"],
                requested_depth=request["depth"],
                requested_ms=request["time_limit_ms"],
                status=row["status"],
                returned=returned,
                error=measurement.get("error"),
                parent_unchanged=measurement.get("parent_unchanged"),
                observer_parent_restored=opportunity.get("parent_restored"),
                legal_count=len(legal) if legal is not None else None,
                returned_action_legal=action in legal
                if legal is not None and action is not None
                else False,
                legal_committed_usable=usable,
                completed_depth=depth,
                action=action,
                PV=measurement.get("PV"),
                value_bits=measurement.get("value_bits"),
                stop=measurement.get("stop"),
                Search_call_seconds=measurement.get("Search_call_seconds"),
                Search_internal_elapsed_seconds=measurement.get(
                    "Search_internal_elapsed_seconds"
                ),
                measured_seconds=row.get("measured_seconds"),
                preparation_seconds=row.get("preparation_seconds"),
                teardown_seconds=row.get("call_teardown_seconds"),
                root_body_before_journal_seconds=row.get(
                    "root_body_before_journal_seconds"
                ),
                stop_tail_API_seconds=max(
                    0.0, measurement["Search_call_seconds"] - 0.095
                )
                if measurement.get("Search_call_seconds") is not None
                else None,
                main_completed_receipt_seconds=measurement.get(
                    "main_completed_receipt_seconds"
                ),
                main_receipted_completed_depth=measurement.get(
                    "main_receipted_completed_depth"
                ),
                process_CPU_seconds=measurement.get("process_CPU_seconds"),
                process_peak_RSS_B=measurement.get("process_peak_RSS_B"),
                TT_generation_before=measurement.get("TT_generation_before"),
                TT_generation_after=measurement.get("TT_generation_after"),
                work=work,
                observed_partial_iteration_work=opportunity.get("partial_work"),
                reference_snapshots=snapshots,
                returned_rank_histogram=None,
                scout_call_count=None,
                missing_counter_policy="UNKNOWN; no value inferred from cutoff/PVS/TT aggregates",
            )
            rows.append(record)
            count += 1
    assert count == qualified["journal_rows"] == 26
    assert size == journal_ref["bytes"] and digest.hexdigest() == journal_ref["sha256"]
    assert f"{path.stat().st_mode & 0o777:04o}" == journal_ref["mode"]
    sources.append(
        dict(
            pass_index=index,
            journal=journal_ref,
            SHA_size_mode=True,
            rows=count,
            record_bound_B=1048576,
        )
    )
    native = document(qualified["result_file"])
    assert native["calls"] == 26 and native["unperformed"] == 0
    native_summaries.append(
        dict(
            pass_index=index,
            source=qualified["result_file"],
            summary={
                key: value for key, value in native.items() if key != "measurements"
            },
        )
    )

assert len(rows) == 104
by_pass = {
    index: [row for row in rows if row["pass_index"] == index] for index in range(4)
}
by_root = {
    root: [
        next(row for row in by_pass[index] if row["root_index"] == root)
        for index in range(4)
    ]
    for root in range(26)
}
identity_match = all(
    all(row["root_identity"] == group[0]["root_identity"] for row in group)
    for group in by_root.values()
)
assert identity_match
per_pass = []
for index, group in by_pass.items():
    per_pass.append(
        dict(
            pass_index=index,
            arm=group[0]["arm"],
            setting=group[0]["setting"],
            census=len(group),
            usable_legal_committed=sum(row["legal_committed_usable"] for row in group),
            stops=dict(Counter(row["stop"] for row in group)),
            requested_depth_status=dict(Counter(row["status"] for row in group)),
            completed_depth=metrics([row["completed_depth"] for row in group]),
            Search_call_seconds=metrics([row["Search_call_seconds"] for row in group]),
            stop_tail_API_seconds=metrics(
                [row["stop_tail_API_seconds"] for row in group]
            ),
            nodes=sum(row["work"].get("nodes", 0) for row in group),
            evaluations=sum(row["work"].get("evaluations", 0) for row in group),
            cutoff_work=sum(row["work"].get("cutoffs", 0) for row in group),
            PVS_researches=sum(row["work"].get("PVS_researches", 0) for row in group),
            LMR_attempts=sum(row["work"].get("LMR_attempts", 0) for row in group),
            LMR_full_depth_confirmations=sum(
                row["work"].get("LMR_full_depth_confirmations", 0) for row in group
            ),
            LMR_full_window_researches=sum(
                row["work"].get("LMR_full_window_researches", 0) for row in group
            ),
        )
    )
A = [row for row in rows if row["arm"] == "A"]
B = [row for row in rows if row["arm"] == "B"]
ap95 = linear([row["Search_call_seconds"] for row in A], 0.95)
bp95 = linear([row["Search_call_seconds"] for row in B], 0.95)
ratio = bp95 / ap95 if ap95 else None
bmax = max(row["Search_call_seconds"] for row in B)
gate_conditions = dict(
    all104_published=len(rows) == 104,
    all104_restored=all(
        row["parent_unchanged"] and row["observer_parent_restored"] for row in rows
    ),
    all104_legal_committed_depth_at_least1=all(
        row["legal_committed_usable"] for row in rows
    ),
    errors_missing_cancelled_zero=all(
        row["error"] is None
        and row["returned"] == "Ok"
        and row["stop"] not in ("Cancelled", "NodeLimit")
        for row in rows
    ),
    NodeLimit_safety_zero=all(row["stop"] != "NodeLimit" for row in rows),
    candidate_max_Search_at_most_150ms=bmax <= 0.150,
    candidate_over_current_linear_p95_at_most1_20=ratio is not None and ratio <= 1.20,
)
gate_pass = all(gate_conditions.values())
gate = dict(
    frozen_rule=protocol["serious_clock_gate"],
    measured_conditions=gate_conditions,
    gate_pass=gate_pass,
    current_linear_p95_s=ap95,
    candidate_linear_p95_s=bp95,
    candidate_current_p95_ratio=ratio,
    candidate_max_Search_s=bmax,
    legal_committed_calls=sum(row["legal_committed_usable"] for row in rows),
    full_requested_depth_D64_COMPLETE=sum(row["status"] == "COMPLETE" for row in rows),
    expected_clock_capped_full_D64_UNKNOWN=sum(
        row["status"] == "UNKNOWN" and row["stop"] == "TimeLimit" for row in rows
    ),
    distinction="TimeLimit D64 UNKNOWN is retained; a legal committed depth>=1 is sufficient for this frozen clock gate, not D64 completion",
    conditional_new64="ELIGIBLE_FOR_SEPARATE_ACTUAL_SUPPORT_ONLY"
    if gate_pass
    else "STOPPED_UNISSUED",
    games_entered=0,
    nativeCI_RNG_performed=0,
    no_integer_depth_gain_requirement=True,
)


def comparison(left, right):
    pairs = list(zip(by_pass[left], by_pass[right], strict=True))
    result = dict(
        left=left,
        right=right,
        root_pairs=len(pairs),
        depth_increase=sum(
            b["completed_depth"] > a["completed_depth"] for a, b in pairs
        ),
        depth_same=sum(b["completed_depth"] == a["completed_depth"] for a, b in pairs),
        depth_decrease=sum(
            b["completed_depth"] < a["completed_depth"] for a, b in pairs
        ),
        action_equal=sum(a["action"] == b["action"] for a, b in pairs),
        PV_equal=sum(a["PV"] == b["PV"] for a, b in pairs),
        value_bits_equal=sum(a["value_bits"] == b["value_bits"] for a, b in pairs),
        node_difference=sum(b["work"]["nodes"] - a["work"]["nodes"] for a, b in pairs),
        same_completed_depth_time_not_claimed_samework=True,
    )
    for slot in ("first_completed", "last_completed"):
        ranked = [
            (a["reference_snapshots"].get(slot), b["reference_snapshots"].get(slot))
            for a, b in pairs
        ]
        known = [
            (a, b)
            for a, b in ranked
            if a
            and b
            and a["recorded_rank"] is not None
            and b["recorded_rank"] is not None
        ]
        result[slot] = dict(
            known_pairs=len(known),
            rank_better=sum(b["recorded_rank"] < a["recorded_rank"] for a, b in known),
            rank_same=sum(b["recorded_rank"] == a["recorded_rank"] for a, b in known),
            rank_worse=sum(b["recorded_rank"] > a["recorded_rank"] for a, b in known),
            unknown_pairs=26 - len(known),
            same_frozen_action=True,
        )
    return result


rank_tables = []
for index, group in by_pass.items():
    for slot in ("first_completed", "last_completed"):
        for stratum, subset in (
            ("all26", group),
            (
                "old21_promotion_reference",
                [row for row in group if row["old_reference_tier"] == 0],
            ),
            (
                "old21_ordinary_reference",
                [row for row in group if row["old_reference_tier"] == 4],
            ),
        ):
            snapshots = [row["reference_snapshots"].get(slot) for row in subset]
            ranked = [
                snapshot
                for snapshot in snapshots
                if snapshot and snapshot["recorded_rank"] is not None
            ]
            rank_tables.append(
                dict(
                    pass_index=index,
                    slot=slot,
                    stratum=stratum,
                    denominator=len(subset),
                    known=len(ranked),
                    unknown=len(subset) - len(ranked),
                    top1=sum(s["recorded_rank"] <= 1 for s in ranked),
                    top3=sum(s["recorded_rank"] <= 3 for s in ranked),
                    top5=sum(s["recorded_rank"] <= 5 for s in ranked),
                    current_snapshot_tiers=dict(
                        Counter(str(s["tier"]) for s in ranked)
                    ),
                )
            )
strata = []
for key in ("stock", "band", "session_first", "session", "family"):
    for value in sorted({str(row[key]) for row in rows}):
        for index in range(4):
            group = [row for row in by_pass[index] if str(row[key]) == value]
            strata.append(
                dict(
                    stratum=key,
                    value=value,
                    pass_index=index,
                    n=len(group),
                    completed_depth=metrics([row["completed_depth"] for row in group]),
                    Search_seconds=metrics(
                        [row["Search_call_seconds"] for row in group]
                    ),
                    nodes=sum(row["work"]["nodes"] for row in group),
                )
            )
rows_ref = save("compact-rows.json", rows)
save("native-summary-custody.json", native_summaries)
save(
    "internal-stock-work.json",
    [
        dict(pass_index=index, stock=stock, events=dict(counts))
        for (index, stock), counts in sorted(internal.items())
    ],
)
save("rank-strata.json", rank_tables)
save("root-stock-session-strata.json", strata)
save("root14-wall207-case.json", by_root[14])
comparison_ref = save(
    "paired-descriptive-comparisons.json",
    [comparison(0, 1), comparison(3, 2), comparison(0, 3), comparison(1, 2)],
)
stop = json.loads((COLLECT / "native-normal-source-STOP.json").read_text())
summary = save(
    "summary.json",
    dict(
        issue="quoridor-4lc.324.25.3",
        actual_job="74bc134a-008b-4b6c-ab9a-98bf5de8da18",
        original_protocol=ref(OWN / "protocol-v1/protocol.json"),
        new_trial=ref(TRIAL / "trial.json"),
        sources=sources,
        current_reference_source=protocol["reference_actions"],
        normal_custody_4PASS=True,
        all104_attempted_published=True,
        full_identity_history_legal_source_correspondence="Normal qualification retained, same full saved root identity across4 passes; no geometry/input/model requalification",
        crosspass_full_root_identity_equal=identity_match,
        per_pass=per_pass,
        gate=gate,
        descriptive_comparisons=comparison_ref,
        rank_tables=ref(OUT / "rank-strata.json"),
        selected_case=ref(OUT / "root14-wall207-case.json"),
        compact_rows=rows_ref,
        total_actual_nodes=sum(row["work"]["nodes"] for row in rows),
        total_evaluations=sum(row["work"].get("evaluations", 0) for row in rows),
        accepted_inclusive_seconds_once=stop["accepted_inclusive_seconds"],
        outer_command_seconds_nested=stop["outer_command_seconds"],
        old25_costs_budgets_separate=True,
        source_math_tests_qualifier_Search_FINALIZE_RNG_replays=0,
        historical_exposure_and_correlated_3families_6series_preserved=True,
        interpretation="Descriptive limited clock/rank comparison only; SAME old21 reference is not oracle. Different actual trees/partial iterations/TT histories and clock variability; no general speed/strength/causal-harm/noeffect/default promotion.",
        unavailable=[
            "parent arena authority receipt/stop-tail",
            "per-return-rank histogram",
            "scout call count",
            "direct main/continuation update provenance in these104",
            "unrecorded observer-window fields",
        ],
    ),
)
with (OUT / "per-call.csv").open("x", newline="") as output:
    fields = [
        "pass_index",
        "arm",
        "root_index",
        "family",
        "session",
        "session_first",
        "stock",
        "completed_depth",
        "action",
        "stop",
        "status",
        "Search_call_seconds",
        "stop_tail_API_seconds",
        "returned_action_legal",
    ]
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    for row in rows:
        writer.writerow({field: row[field] for field in fields})
print(
    json.dumps(
        dict(
            summary=summary,
            gate=gate,
            per_pass=per_pass,
            total_nodes=sum(row["work"]["nodes"] for row in rows),
            root14=[
                dict(
                    pass_index=row["pass_index"],
                    depth=row["completed_depth"],
                    action=row["action"],
                    reference_snapshots=row["reference_snapshots"],
                )
                for row in by_root[14]
            ],
        )
    )
)
