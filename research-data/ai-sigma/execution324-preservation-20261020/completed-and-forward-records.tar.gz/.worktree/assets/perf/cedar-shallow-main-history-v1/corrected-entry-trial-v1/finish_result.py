"""Return saved analysis/admin STOP and the fixed forward-game dependency facts."""

import datetime
import hashlib
import json
import os
from pathlib import Path

TRIAL = Path(__file__).resolve().parent
OUT = TRIAL / "analysis-v1"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as output:
        output.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


phases = [
    "completion-intake-v1",
    "stop-guard-v1",
    "stop-root-delivery-v1",
    "saved-schema-intake-v1",
    "snapshot-shape-intake-v1",
    "saved-rank-decoder-intake-v1",
    "analysis-guard-v1",
    "summary-intake-v1",
    "report-guard-v1",
    "result-admin-guard-v1",
]
returns = []
known = []
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
for phase in phases:
    result = json.loads((TRIAL / phase / "return.json").read_text())
    assert (
        result["exit_code"] == 0
        and result["remaining"] == []
        and result["direct_child_reaped"]
        and result["handle_closes_complete"]
        and result["cleanup_complete"]
    )
    assert not (TRIAL / phase / "TMP").exists()
    returns.append(ref(TRIAL / phase / "return.json"))
    for identity in (
        json.loads((TRIAL / phase / "controller.json").read_text()),
        result["child"],
    ):
        path = Path("/proc") / str(identity["pid"]) / "stat"
        try:
            current = path.read_text().rsplit(")", 1)[1].split()[19]
        except FileNotFoundError:
            current = None
        assert current != str(identity["start_ticks"]) or boot != identity["boot_id"]
        known.append(
            dict(
                identity={
                    key: identity[key] for key in ("pid", "start_ticks", "boot_id")
                },
                current_start_ticks=current,
                absent_or_different=True,
            )
        )
summary = json.loads((OUT / "summary.json").read_text())
assert summary["gate"]["gate_pass"]
stop = save(
    "returned-analysis-admin-STOP.json",
    dict(
        issue="quoridor-4lc.324.25.3",
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        minimum_result=ref(OUT / "minimum-result.json"),
        actual_native_normal_source_STOP=ref(
            TRIAL / "collection-v1/native-normal-source-STOP.json"
        ),
        actual_returned_helpers=returns,
        known_helper_identities=known,
        directwait_reaped=True,
        handles_complete=True,
        TMP_remaining=[],
        source_leases_remaining=[],
        owned_processes_remaining=[],
        idle_reservations=[],
        analysis_or_Main_reader_remaining=False,
        no_heavy_analysis_pending=True,
        new64_games_entered=0,
        source_model_native_qualifier_FINALIZE_RNG_replay=0,
        own25_3_sameassignee_in_progress_note_backup="PASS after savedanalysis return",
        current_finalizer="Actual return follows result-return-guard-v1/return.json; no self-absence claim",
        future_host_quiet_not_claimed=True,
    ),
)
roots = [
    OUT,
    TRIAL / "collection-v1",
    *[TRIAL / phase for phase in phases],
    *[
        TRIAL / name
        for name in (
            "collect_stop.py",
            "analyze_saved.py",
            "report_saved.py",
            "finish_result.py",
        )
    ],
]
seen = set()
allocated = logical = entries = 0
for root in roots:
    paths = [root]
    if root.is_dir():
        for parent, dirs, files in os.walk(root, followlinks=False):
            paths.extend(Path(parent) / name for name in dirs + files)
    for path in paths:
        info = path.lstat()
        key = (info.st_dev, info.st_ino)
        if key not in seen:
            seen.add(key)
            allocated += info.st_blocks * 512
            logical += info.st_size
            entries += 1
point = save(
    "ordinary-affected-point.json",
    dict(
        roots=[str(path) for path in roots],
        allocated_B=allocated,
        logical_B=logical,
        entries=entries,
        scope="Once new collection/savedanalysis/helper controls only; no old full-OWN/data/source/support holding rewalk or recharge",
        later_tails_globalactual_fees="UNKNOWN",
        refund_lending=0,
    ),
)
completion = save(
    "completion.json",
    dict(
        issue="quoridor-4lc.324.25.3",
        status="FIXED_NEW104_CLOCK_GATE_MET_SAVED_DESCRIPTIVE_RESULT",
        minimum_result=ref(OUT / "minimum-result.json"),
        summary=ref(OUT / "summary.json"),
        report=ref(OUT / "report-ja.md"),
        actual_native_normal_source_STOP=ref(
            TRIAL / "collection-v1/native-normal-source-STOP.json"
        ),
        returned_analysis_admin_STOP=stop,
        affected=point,
        forward_new64="GATE_MET_BUT_SEPARATE_SUPPORT_SOURCE_WINDOW_ORIGIN_NULL",
        new64_conditions=ref(TRIAL / "conditional64.draft.json"),
        no_new_game_or_CI=0,
        old_original25_unchanged=True,
    ),
)
body = (
    "SAME25.3 actual NEW104 fixedgate RESULT (separate from original25) + actualanalysis/adminSTOP. "
    "74bc134a four normalmanifest/dataPASS;104/104 returnedOk/legalcompleteddepth>=1/restored, "
    "errors/missing/cancel/NodeLimit0. Newactual6551433nodes/104M. RequestedD64 status remains "
    "100TimeLimitUNKNOWN+4DepthComplete (nominal selective/safe-race, notfullwidth); "
    "expectedTimeLimitUNKNOWN is not mistaken for entry errors or D64 success. "
    "Frozen mechanical/seriousclock gatePASS: Bmax.106116403<=.150s; Alinear_p95.10368441645, "
    "B.1000486165, ratio.9649339787551072<=1.20. No extra depthgain/rank gate or selection.\n"
    "SAME pre-fixed21reference rank diagnostics mixed: latestB1-A0 better0/same22/worse4, "
    "B2-A3 1/19/6; AA latest5/21/0, BB3/23/0. Firsttop1/3/5 A0=6/15/18,B1=6/16/18,"
    "B2=5/16/16,A3=6/14/19; latest17/19/21,17/19/20,18/20/21,18/21/22 with "
    "TT/PVpriority17/17/18/18. Trees/clock/warmhistory differ, oldreference notoracle, "
    "3families/6series correlated; no speed/strength/causal harm/noeffect/default promotion. "
    "Root14/wall207 rank8/8/7/7 and fullsigned2/176/192/-62; actualaction57/depth4all, "
    "not proof originalnegativeentry harmful. Snapshot/work/stock/firstcontinued/AA-BB tables "
    "saved, missing maincallback/parentauthority/scout/returnedrank/updateprovenance UNKNOWN.\n"
    "NEW25.3 forward64 gate is resolved ONLY; actualnewgame support/source/currentbindings/"
    "origin/fairwindow remainUNISSUED, games0/CI0/RNG0. Frozen first32canonicalfamilies/"
    "64bothcolours/N1/100ms5/max200ply/new1.024G/seed3242520261020/nativefamilymapping/"
    "customnativebootstrap10000floorceil95 unchanged; historicalexposure/3familyoverlap "
    "explicit/notIIDunseen. Known futuregameholding205520896B, Root joins actualendedretention "
    "once with newwhole/currentcapacity; no old480grant/unused104node loan/refund/reset. "
    "No newgame/CI before genuine actualsupport+normalfreshentry. DefaultCurrent unchanged.\n"
    "Actualnative+normal/sourceSTOPa129047b already sent IMMEDIATELY beforelonganalysis. "
    "All subsequent savedanalysis/admin/helpers now returned/reaped/handles/TMP/leases[], "
    "no heavyanalysis pending/Mainreader/sourcewriter, no source/model/native/RAW/qualifier/"
    "FINALIZE/RNG replay. Accepted31.955077s once, outer30.026864945nested; old401b/9786costs "
    "and4UNKNOWN/100unperformed/old64STOPPED immutable, fees/globalactual/laterUNKNOWN.\n"
    f"FileRefs {json.dumps(dict(minimum=ref(OUT / 'minimum-result.json'), completion=completion, report=ref(OUT / 'report-ja.md'), returned_STOP=stop, affected=point))}\n"
    "Own25.3 sameassignee/in_progress meaningfulnote+backupPASS at actualreturned boundary. "
    "Finalhelper actualreturn result-return-guard-v1/return.json follows; delivery result-root-"
    "delivery-v1/return.json. Root soleMain/Git/Cargo/docs/currentresource integration; "
    "26Current fixed and27scope untouched, no parent/ACK/revieweradmin gate. Allpauses/seals/"
    "defaults/models/foreign/FAILED/NULL/UNKNOWNfees/50GB/consultation8 held.\n"
)
with (OUT / "handoff.txt").open("x") as output:
    output.write(body)
print(
    json.dumps(
        dict(
            completion=completion,
            returned_STOP=stop,
            affected=point,
            handoff=ref(OUT / "handoff.txt"),
        )
    )
)
