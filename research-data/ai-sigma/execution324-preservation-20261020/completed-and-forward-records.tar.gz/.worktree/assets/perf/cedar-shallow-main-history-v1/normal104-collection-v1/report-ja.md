# 浅い負main履歴ボーナス比較：元104枠の回収

通常sequenceは4 operationを終了し、4 manifest/dataはPASS。ただし各native resultはPARTIALで、各passのroot-00がSEARCH_LIMITS/UNKNOWNを返した。**104中4 API呼び出しが拒否、完了Search標本0、残り100は未実行**。exit0・通常custody PASSを104完了や候補の有効性へ読み替えない。

| pass | 設定 | native結果 | 拒否slot | 完了 | 未実行 |
|---|---|---|---:|---:|---:|
| A0 | current | PARTIAL | 0 | 0 | 25 |
| B1 | half | PARTIAL | 0 | 0 | 25 |
| B2 | half | PARTIAL | 0 | 0 | 25 |
| A3 | current | PARTIAL | 0 | 0 | 25 |

原因はimmutable Git3bf28324のneighbour_opportunity.rs / search_neighbour_opportunity。root_orderingがあるとlimits.time_limit.is_some()を拒否する既存条件と、固定104プロトコルの100msが衝突する。該当エラーはobservation.mode設定・Search本体呼び出しより前に返る。TT generationは4件とも0→0、parent_unchanged=true、first/latest/pending snapshotは全てNone。nativeプロセス・モデルsessionの実入場はあったため、最初の欠落CPUメタデータによるpreownership失敗とは別domain。

同じ固定reference actionの順位、TT/PV昇格とordinary履歴、深さ/action/PV/value、nodes/evals/stock/cutoff/scout/research、stop-tail・p95比・時計ばらつきは全てUNKNOWN。微小なAPI拒否時間をSearch速度標本にしない。3family/6warmseriesの有効な完了系列も0で、効果なし・有害・棋力差とは結論できない。21/23の記述結果と動機は保持。

固定ゲートの全104完了/合法completed depth>=1/errors0を満たさない。**conditional64はSTOPPED_UNISSUED_NO_GAMES、default currentを維持**。4 UNKNOWN slotの補充、100未実行の自動再配分、観測OFFへの変更、再実行・追加試験・CI・RNG・FINALIZEは行わない。将来進めるならbounded clocked root-qualityの入口だけをRootが扱う必要があるが、本回収は新source/新quota/再入場を承認しない。

修正版parentはaccepted→finished 19.048555秒、outer17.155673660秒はその内数。元FAILEDの5.828820秒を合わせaccepted-inclusive 24.877375秒を一度だけ記録。inner/native/setup等を加算しない。全費用/管理費/globalactualはUNKNOWNを保つ。元FAILED/部分cleanupfalseとactual job cleanuptrue、全設定・image・データを変更しない。

正確な参照・4件の元エラー・通常custody・actual native/guardian/parent/source STOPはsummary.jsonとnative-normal-source-STOP.json。元journalは各1回SHA/サイズ確認して読むだけで、qualifier・モデル・geometry・旧RAW・nativeの再演は0。
