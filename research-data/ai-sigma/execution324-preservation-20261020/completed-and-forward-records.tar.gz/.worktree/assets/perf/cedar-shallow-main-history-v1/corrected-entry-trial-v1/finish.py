"""Return independent light-control preparation without observing other jobs."""

import datetime
import hashlib
import json
import os
from pathlib import Path

OUT = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as output:
        output.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


returns = []
identities = []
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
for phase in (
    "own-entry-v1",
    "metadata-intake-v1",
    "prepare-guard-v1",
    "admin-guard-v1",
):
    path = OUT / phase / "return.json"
    result = json.loads(path.read_text())
    assert (
        result["exit_code"] == 0
        and result["direct_child_reaped"]
        and result["handle_closes_complete"]
        and result["cleanup_complete"]
        and result["remaining"] == []
    )
    assert not (OUT / phase / "TMP").exists()
    returns.append(ref(path))
    for identity in (
        json.loads((OUT / phase / "controller.json").read_text()),
        result["child"],
    ):
        path = Path("/proc") / str(identity["pid"]) / "stat"
        try:
            current = path.read_text().rsplit(")", 1)[1].split()[19]
        except FileNotFoundError:
            current = None
        assert current != str(identity["start_ticks"]) or boot != identity["boot_id"]
        identities.append(
            dict(
                identity={
                    key: identity[key] for key in ("pid", "start_ticks", "boot_id")
                },
                current_start_ticks=current,
                absent_or_different=True,
            )
        )
stop = save(
    "light-preparation-STOP.json",
    dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        prepared=ref(OUT / "prepared.json"),
        returns=returns,
        actual_known_helper_identities=identities,
        directwait_reaped=True,
        handles_complete=True,
        TMP_remaining=[],
        source_leases_remaining=[],
        owned_processes_remaining=[],
        idle_reservations=[],
        Main_source_import_reader=False,
        numerical_entry=False,
        new_trial_usage=0,
        other_job_status_observations=0,
        old_namespaces_untouched=True,
        own_child_sameassignee_in_progress_note_backup="PASS",
        current_finalizer="Actual returned receipt return-guard-v1/return.json follows; not self-absence claim",
    ),
)
seen = set()
allocated = logical = entries = 0
for parent, dirs, files in os.walk(OUT, followlinks=False):
    for path in [Path(parent), *[Path(parent) / name for name in dirs + files]]:
        info = path.lstat()
        key = (info.st_dev, info.st_ino)
        if key not in seen:
            seen.add(key)
            allocated += info.st_blocks * 512
            logical += info.st_size
            entries += 1
point = save(
    "ordinary-affected-point.json",
    dict(
        root=str(OUT),
        allocated_B=allocated,
        logical_B=logical,
        entries=entries,
        scope="Once new child corrected-entry-trial-v1 ordinary control subtree only; old holdings not read/charged and no bulk grant inferred",
        later_tails_globalactual_fees="UNKNOWN",
    ),
)
completion = save(
    "completion.json",
    dict(
        issue="quoridor-4lc.324.25.3",
        status="FIXED_LIGHT_DRAFT_NOT_RUNNABLE",
        prepared=ref(OUT / "prepared.json"),
        trial=ref(OUT / "trial.json"),
        holding=ref(OUT / "future-holding-proposal.json"),
        actual_light_STOP=stop,
        affected=point,
        new104_accepted_entered_completed=0,
        prospective_new64_entered=0,
        actual_new_image_BUILD_currentcallers_support_origin=None,
        next_real_inputs=[
            "Root related25.2/source sparse adoption",
            "canonical real-callee new1/affectedClippy/genuine release+collectionSTOP",
            "actual new image/BUILD/current four caller and maintained factory/numerical correspondence",
            "new whole/fullroots/free/capacity/allocation",
            "actual current origin/end_at and normal fresh physicalSMT/peer/RAM/host4/ownerpausecancel/cleanup admission",
        ],
        original25_scientific_INCOMPLETE_unchanged=True,
        no_parent_ACK_human_reply_gate=True,
    ),
)
body = (
    "SAME25.3 new independent corrected-entry trial LIGHT preparation DONE/UNENTERED, "
    "not original100 transfer or fourUNKNOWN refill. Claimed ONLY new ownchild/sameassignee/in_progress; "
    "parent25 and26/27/status/jobs untouched. Newnamespace corrected-entry-trial-v1; "
    "frozen originalbcaebc17/fourconfigs/schedule/same21referenceactions/ABBA104/104M/"
    "24warm chronological sessions, fullpredecessors and all originalgates. "
    "Newusage0/accepted0/native0/games0; original401b/9786/4UNKNOWN/0usable/100unperformed/"
    "old64STOPPED and fees/masks immutable.\n"
    "Four Experiment/RUN+sequence/job+true empty measurementPlan bindings saved as "
    "explicit NOT_RUNNABLE drafts; child_cpu_cores[0,12] explicit. Newimage/BUILD/currentcallers/"
    "sourceadoption/numerical/support/fullroots/origin/end_at NULL. No historical417/513fallback. "
    "No Mainimport/SH/sourcecopy/compiler/test/model/inputpayload/RAW/native/RNG or otherjob "
    "observation. Current-source realfactory/numerical join awaits actual source/softwareSTOP only.\n"
    "Prospective conditionalNEW64/32canonicalfirstfamilies/bothcolours/max1.024G frozen byref, "
    "same seed3242520261020/nativefamilymapping/customnativebootstrap10000/floor-ceil95. "
    "Historical exposure and3family overlap explicit, notIIDunseen. Gate first: all104/restored/"
    "legaldepth>=1/errorsmissingcancelNodeLimit0/Bmax<=150ms/p95B/A<=1.20, no depthgain gate. "
    "Games need actual separate support after passedgate; no extraCI/refill.\n"
    "Future finite producer104448790528B, conditional64205520896B; all copies0/serialTMP8MiB; "
    "Root actualretention/newimage/currentcapacity/whole remain unresolved once, "
    "no old480MiBgrant or retainedholding rewalk/refund/loan. Resourceproposal "
    "worker12/main0/outer18/family4G1.5+2.5/host4/G0/N1/launcher0,12,18, "
    "parent1200/command1140/RUN180 and conditional2400/2340/1800 unchanged.\n"
    f"FileRefs {json.dumps(dict(completion=completion, prepared=ref(OUT / 'prepared.json'), trial=ref(OUT / 'trial.json'), holding=ref(OUT / 'future-holding-proposal.json'), light_STOP=stop, affected=point))}\n"
    "Ruffformat/checkPASS; ownnote+backupPASS at no-clock boundary. All helpers returned/"
    "reaped/handles/TMP/leases[], return-guard-v1/return.json follows; tiny delivery returned "
    "receipt root-delivery-v1/return.json. No idle/futurequiet, no numericalSTART claim. "
    "Real remaining source/software/support/admission facts only, no parent/27close/ACK gate. "
    "Root soleMain/Git/Cargo/docs, allpauses/seals/defaultCurrent/models/foreign/FAILED/"
    "NULL/feesUNKNOWN/50GB preserved.\n"
)
with (OUT / "handoff.txt").open("x") as output:
    output.write(body)
print(
    json.dumps(
        dict(
            completion=completion,
            light_STOP=stop,
            affected=point,
            handoff=ref(OUT / "handoff.txt"),
        )
    )
)
