"""NEW definition: UNRUN until Root's canonical adoption. No model/native input."""

import copy
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

ROOT = Path("/workspaces/quoridor")


class ShallowMainMetadata(unittest.TestCase):
    def test_shallow_main_normal_measurement_arena_and_actual_record_join(self):
        loader = importlib.util.spec_from_file_location(
            "shallow_main_canonical_owner", ROOT / "scripts/dev/research-lifecycle.py"
        )
        lc = importlib.util.module_from_spec(loader)
        loader.loader.exec_module(lc)
        self.assertEqual(lc.resolved_shallow_main_history({}, "control"), "current")
        for bad in [None, 50, 0.5, "", "unknown", {}, True]:
            with self.assertRaises(lc.Refused):
                lc.resolved_shallow_main_history(
                    {"shallow_main_history": bad}, "control"
                )
        for mode in ["current", "half"]:
            for profile, supported in [("cheap", True), ("control", False)]:
                with self.assertRaises(lc.Refused):
                    lc.resolved_shallow_main_history(
                        {"shallow_main_history": mode}, profile, supported=supported
                    )
        config = dict(
            roots=[
                dict(
                    input=0,
                    pointer="/families/0",
                    field="prefix",
                    prefix_len=2,
                    check_history=False,
                    label="synthetic",
                    jsonl_match=None,
                )
            ],
            profile="control",
            tt_entries=1048576,
            use_tt=True,
            use_pvs=True,
            lmr=True,
            lmr_method="depth_rank",
            zero_stock_safe_race=True,
            zero_stock_safe_race_method="path_tail",
            namespace=dict(evaluator="unloaded", rules="standard", selectivity="PVS"),
            output_bytes=33554432,
            record_bytes=1048576,
            neighbour_opportunity="off_shadow",
            root_ordering_quality=True,
            shallow_main_history="half",
            search_threads=1,
            search_cpu_cores=[12],
            management_cpu_core=0,
            native_memory_bytes=2684354560,
            time_reserve_ms=5,
        )
        requests = [
            dict(
                id="r0",
                session="s0",
                root=0,
                depth=64,
                node_cap=1000000,
                time_limit_ms=100,
            )
        ]
        experiment = dict(
            config={"path": "cfg"}, schedule={"path": "requests"}, inputs=[{}]
        )
        documents = dict(cfg=config, requests=requests)
        with patch.object(
            lc, "document", side_effect=lambda r: copy.deepcopy(documents[r["path"]])
        ):
            actual, _ = lc.measurement_config(experiment)
            self.assertEqual(actual["shallow_main_history"], "half")
            documents["cfg"] = dict(config, search_threads=2, search_cpu_cores=[12, 14])
            with self.assertRaises(lc.Refused):
                lc.measurement_config(experiment)
            documents["cfg"] = config
            import json

            row = dict(
                status="UNKNOWN",
                measurement=dict(
                    requested_shallow_main_history="half",
                    actual_shallow_main_history="half",
                ),
            )
            values = dict(
                settings=b"{}",
                result=b'{"errors":[]}',
                measurements=(json.dumps(row) + "\n").encode(),
            )
            lc.measurement_evidence(dict(perf=None, data=[]), experiment, values)
            row["measurement"]["actual_shallow_main_history"] = "current"
            values["measurements"] = (json.dumps(row) + "\n").encode()
            with self.assertRaises(lc.Refused):
                lc.measurement_evidence(dict(perf=None, data=[]), experiment, values)
        common = dict(
            tt_entries=1048576,
            use_tt=True,
            use_pvs=True,
            rules="standard",
            family_B=4294967296,
            controller_B=1610612736,
            host_reserve_B=4294967296,
            ruleset="standard_2p_threefold",
            arena=dict(
                return_reserve_ms=5,
                management_guardian=0,
                AI_workers=[12, 12],
                max_plies=200,
                depth=64,
                max_nodes=1000000,
                time_ms=100,
            ),
        )
        pair = [
            dict(
                evaluator="nnue",
                profile="control",
                lmr=True,
                lmr_method="depth_rank",
                shallow_main_history=m,
                zero_stock_safe_race=True,
                zero_stock_safe_race_method="path_tail",
            )
            for m in ["current", "half"]
        ]
        measured = dict(namespace={})
        lc.apply_comparison_cost(measured, common, pair[1])
        self.assertEqual(measured["shallow_main_history"], "half")
        arena = dict(arena={}, engines=[dict(kind="nnue"), dict(kind="nnue")])
        lc.apply_comparison_arena(arena, common, pair)
        self.assertEqual(
            [e["shallow_main_history"] for e in arena["engines"]], ["current", "half"]
        )

        # NEW O2 boundary: actual normal Plan/config joins stay intact while
        # LMR is OFF; equality of the independently selected main policy remains.
        book_ref = dict(path="book", sha256="0" * 64)
        config_ref = dict(path="arena-cfg")
        schedule_ref = dict(path="arena-schedule")
        rule = "research-standard-2p-threefold-goal-first-v1"
        family = dict(
            family_id=0,
            id="synthetic",
            prefix=[],
            seed=1,
            root_key="unloaded",
            history_counts=[],
        )
        book = dict(complete=True, rules=rule, families=[family])
        slots = [
            dict(
                slot=i, batch=0, matchup=0, local_game=i, family_id=0, candidate_color=i
            )
            for i in range(2)
        ]
        engines = [
            dict(
                kind="distance",
                ordering_profile="control",
                lmr=False,
                shallow_main_history="current",
                depth=4,
                max_nodes=1000,
                simd=False,
                distance_a=1.0,
                distance_b=1.0,
                time_ms=None,
            )
            for _ in range(2)
        ]
        arena_config = dict(
            ruleset="standard_2p_threefold",
            games=2,
            workers=1,
            active_games=1,
            max_batch=1,
            max_output_bytes=1024,
            engines=engines,
            arena=dict(
                evaluator_sha256=["unloaded", "unloaded"],
                comparison="evaluator_fixed_depth",
                clock_policy="strict_unknown",
                tt_entries=1048576,
                retained_outcome_bytes=16,
                search_artifact_sha256=["unloaded", "unloaded"],
                return_reserve_ms=0,
                book=dict(
                    openings=[
                        dict(
                            id=family["id"],
                            prefix=family["prefix"],
                            original_seed=family["seed"],
                            reference=dict(
                                source_sha256=book_ref["sha256"], settings=family
                            ),
                        )
                    ]
                ),
                first_candidate_colors=[0],
            ),
        )
        plan = dict(
            schema="quoridor.research.arena-plan.v1",
            phase="arena",
            comparison="evaluator_fixed_depth",
            rules=rule,
            distance_units="wall-distance/80",
            value_perspective="side-to-move",
            book=book_ref,
            inputs=[book_ref],
            models=[],
            schedule=schedule_ref,
            family_ids=[0],
            matchups=[
                dict(id=0, engines=engines, evaluator_sha256=["unloaded", "unloaded"])
            ],
            batches=[dict(batch=0, matchup=0, config=config_ref, slots=[0, 1])],
            planned_slots=2,
        )
        arena_experiment = dict(
            phase="arena",
            argv=[
                "runner",
                "arena",
                "--experiment",
                "@EXPERIMENT@",
                "--experiment-sha256",
                "@EXPERIMENT_SHA256@",
            ],
            rules=rule,
            distance_units=plan["distance_units"],
            value_perspective=plan["value_perspective"],
            inputs=plan["inputs"],
            models=[],
            schedule=schedule_ref,
            config=config_ref,
            batch=0,
            planned_slots=2,
        )
        arena_docs = {"book": book, "arena-cfg": arena_config, "arena-schedule": slots}
        with (
            patch.object(
                lc,
                "document",
                side_effect=lambda r: copy.deepcopy(arena_docs[r["path"]]),
            ),
            patch.object(lc, "arena_model_check", return_value=None),
        ):
            # Only model qualification is replaced by unloaded synthetic metadata;
            # planned_game_slice, normal joins and changed comparison are real.
            for comparison in ["evaluator_fixed_depth", "evaluator_wall_time"]:
                plan["comparison"] = arena_config["arena"]["comparison"] = comparison
                for engine in engines:
                    engine["time_ms"] = (
                        None if comparison == "evaluator_fixed_depth" else 100
                    )
                arena_config["arena"]["return_reserve_ms"] = (
                    0 if comparison == "evaluator_fixed_depth" else 5
                )
                for equal_policy in ["current", "half"]:
                    for engine in engines:
                        engine["shallow_main_history"] = equal_policy
                        self.assertIs(engine["lmr"], False)
                    selected, actual_config = lc.arena_plan_check(
                        arena_experiment, plan
                    )
                    self.assertEqual(len(selected), 2)
                    self.assertEqual(actual_config["engines"], engines)
                engines[0]["shallow_main_history"] = "current"
                engines[1]["shallow_main_history"] = "half"
                self.assertEqual(plan["matchups"][0]["engines"], engines)
                with self.assertRaisesRegex(
                    lc.Refused,
                    "evaluator comparison keeps effective LMR settings equal",
                ):
                    lc.arena_plan_check(arena_experiment, plan)


if __name__ == "__main__":
    unittest.main()
