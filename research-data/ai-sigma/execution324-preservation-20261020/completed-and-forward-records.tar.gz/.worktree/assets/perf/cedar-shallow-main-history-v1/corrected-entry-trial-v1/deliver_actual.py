"""One accepted-RPC handoff, without status/native-start observation."""

import hashlib
import json
import os
from pathlib import Path

TRIAL = Path(__file__).resolve().parent
OUT = TRIAL / "actual-entry-v1"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


receipt = json.loads((OUT / "submit-return-v1.json").read_text())
assert (
    receipt["returncode"] == 0
    and receipt["directwait_reaped"]
    and receipt["pipes_closed"]
)
response = receipt["RPC_response"]
assert response["issue"] == "quoridor-4lc.324.25.3"
roots = [
    OUT,
    *[
        TRIAL / phase
        for phase in (
            "actual-input-intake-v1",
            "actual-bind-guard-v1",
            "actual-admin-guard-v1",
            "actual-finish-guard-v1",
        )
    ],
    *[
        TRIAL / name
        for name in (
            "bind_actual.py",
            "finish_actual.py",
            "submit_actual.py",
            "deliver_actual.py",
        )
    ],
]
seen = set()
allocated = logical = entries = 0
for root in roots:
    paths = [root]
    if root.is_dir():
        for parent, dirs, files in os.walk(root, followlinks=False):
            paths.extend(Path(parent) / name for name in dirs + files)
    for path in paths:
        info = path.lstat()
        key = (info.st_dev, info.st_ino)
        if key not in seen:
            seen.add(key)
            allocated += info.st_blocks * 512
            logical += info.st_size
            entries += 1
point_path = OUT / "ordinary-affected-point.json"
with point_path.open("x") as output:
    output.write(
        json.dumps(
            dict(
                roots=[str(path) for path in roots],
                allocated_B=allocated,
                logical_B=logical,
                entries=entries,
                scope="Once new actual-binding/submit metadata/helper controls only; no runtime/scientific files observed or old holdings recharged",
                later_tails_globalactual_fees="UNKNOWN",
            ),
            indent=2,
        )
        + "\n"
    )
body = (
    "SAME25.3 INDEPENDENT NEW104 ONE ACTUAL normalRPCaccepted, not nativeSTART/sciencePASS. "
    f"Job{response['job_id']} accepted{response['created_at']}/phaseSTARTING, "
    f"supervisor{response['supervisor']}, configfingerprint{response['config_sha256']}. "
    "Actualnative/operationSTART UNKNOWN, no statuspoll/startobserver. Runtime "
    f"{receipt['state_dir']}. Same originalcompletion owns once4manifest/data+104census collection.\n"
    "Actualnew f68639f7/BUILD84fd79dc samebotharms; current4c797/6749/3b/ed08/support0b854a1d/"
    "issued5d1858a4/releasea1840502 allsmallrefs verified. Canonical measurement_config/"
    "caller_source_refs/numerical_fields+numerical_check/native_cpu_cores four[0,12] "
    "under ONE NB SH08:55:25.561353..626255 released. Inherited641ca structuralonly, "
    "no source/model/parity/test/qualifier/ELFpayload/RAW/RNG/FINALIZE replay. "
    "Actualfull3roots480MiB/free38371328, ownerprojectROOT, positivebounds bound. "
    "Normal physicalSMT-peer/RAMhost4/fullroots/free/ownerpausecancel/currentenv/source/"
    "origin/cancel/serializer/cleanup remains owning fresh admission, not metadataPASS.\n"
    "DirectPopen OUTSIDE Cycle explicit0,12,18; clientreturn0/directwait/reaped/pipesclosed. "
    "Parent1200/command1140/cleanup60/RUN180, neworigin/end_atstampedONCE. "
    "Fouroriginalconfigs/requests/samereferenceactions/newtrial6be8 unchanged, ABBA4x26/"
    "104M/24chronologicalwarmseries/fullpredecessors/Current-Half-Half-Current/100ms5/"
    "N1/Cedar35cbb/Control/baselineLMR/TT1M/PVS/path_tail/plainOffShadowrootquality/"
    "watchNone. Old401b/9786/4UNKNOWN/0usable/100unperformed/old64STOPPED/fees/masks "
    "remainimmutable; this is humanNEWquota, no transfer/refill/reset/loan. "
    "ConditionalforwardNEW64 UNISSUED pending NEWgate and separatesupport.\n"
    f"FileRefs {json.dumps(dict(submit=ref(OUT / 'submit-return-v1.json'), actualsettings=ref(OUT / 'settings.json'), materialized=ref(OUT / 'materialized.json'), source_admin_STOP=ref(OUT / 'source-admin-STOP.json'), actual_finish_guard_return=ref(TRIAL / 'actual-finish-guard-v1/return.json'), affected=ref(point_path)))}\n"
    "Own25.3 sameassignee/in_progress meaningfulnote+backupPASS BEFOREclock, no heavyweightDB "
    "duringclock. All sourcehelpers returned/reaped/handles/TMP/leases[]; submitted client's "
    "ownTMP may retain normaluvlock until actualcompletion, no false emptyclaim. "
    "RootMain/current4/image/libs/env/Git/Cargo/heavyIO HOLD through NEW104actualnative+"
    "normalcollectionSTOP. Author returns that actualrelease immediately before longanalysis/admin. "
    "No ACK/parent/27/26gate or new observer. Tiny delivery return follows actual-root-delivery-v1/"
    "return.json. All USERPAUSE/seals/defaultCurrent/default1/models/foreign/FAILED/NULL/"
    "UNKNOWNfees/50GB/consultation8 held.\n"
)
path = OUT / "accepted-handoff.txt"
with path.open("x") as output:
    output.write(body)
print(
    json.dumps(
        dict(
            handoff=ref(path),
            actual_job=response["job_id"],
            native_START=None,
            affected=ref(point_path),
        )
    )
)
