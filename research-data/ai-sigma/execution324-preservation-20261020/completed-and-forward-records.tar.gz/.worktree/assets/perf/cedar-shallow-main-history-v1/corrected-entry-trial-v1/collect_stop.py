"""Collect normal custody and return the exact native lifetime before analysis."""

import datetime
import fcntl
import hashlib
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
TRIAL = Path(__file__).resolve().parent
BASE = TRIAL / "normal-search-abba-v1"
OUT = TRIAL / "collection-v1"
OUT.mkdir()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def document(reference):
    path = Path(reference["path"])
    assert ref(path) == reference
    return json.loads(path.read_bytes())


def save(name, value):
    path = OUT / name
    with path.open("x") as output:
        output.write(json.dumps(value, indent=2) + "\n")
    return ref(path)


sequence = json.loads((BASE / "execution-v1/result.json").read_text())
outer = json.loads((BASE / "parent-runtime-v1/result.json").read_text())
assert sequence["status"] == "PASS" and sequence["completed_operations"] == 4
assert sequence["cleanup_complete"] and sequence["remaining"] == []
assert (
    outer["outcome"] == "succeeded"
    and outer["cleanup_complete"]
    and outer["direct_child_reaped"]
    and outer["remaining"] == []
)
identities = [sequence["originating_job"][key] for key in ("supervisor", "child")]
records = []
for operation in sequence["operations"]:
    manifest = document(operation["manifest"])
    job = document(operation["job_result"])
    assert manifest["status"] == manifest["data"]["status"] == "PASS"
    assert (
        manifest["cleanup_complete"]
        and manifest["process_cleanup_complete"]
        and manifest["remaining"] == []
    )
    assert (
        job["cleanup_complete"]
        and job["direct_child_reaped"]
        and job["remaining"] == []
    )
    for check in manifest["checks"]:
        returned = check["guardian_return"]
        assert (
            check["status"] == "PASS"
            and returned["exit_code"] == 0
            and returned["direct_child_reaped"]
            and returned["handle_closes_complete"]
            and returned["cleanup_complete"]
            and returned["remaining"] == []
        )
        identities.append(returned["child"])
    identities.extend(
        manifest["originating_job"][key] for key in ("supervisor", "child")
    )
    records.append(
        dict(
            index=operation["index"],
            manifest_ref=operation["manifest"],
            manifest=manifest,
            job_result=operation["job_result"],
        )
    )
manifest_intake = save("normal-manifest-intake.json", records)
receipt = json.loads((TRIAL / "actual-entry-v1/submit-return-v1.json").read_text())
identities.extend(
    receipt["RPC_response"]["launch"][key]
    for key in ("owner", "launcher", "supervisor")
)
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
known = []
seen = set()
for identity in identities:
    key = (identity["pid"], str(identity["start_ticks"]), identity["boot_id"])
    if key in seen:
        continue
    seen.add(key)
    path = Path("/proc") / str(identity["pid"]) / "stat"
    try:
        current = path.read_text().rsplit(")", 1)[1].split()[19]
    except FileNotFoundError:
        current = None
    assert current != str(identity["start_ticks"]) or boot != identity["boot_id"]
    known.append(
        dict(identity=identity, current_start_ticks=current, absent_or_different=True)
    )
reader = dict(
    path=str(ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"),
    mode="LOCK_SH|LOCK_NB",
)
settings = json.loads((TRIAL / "actual-entry-v1/settings.json").read_text())
with Path(reader["path"]).open("a") as handle:
    fcntl.flock(handle, fcntl.LOCK_SH | fcntl.LOCK_NB)
    reader["acquired_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for caller in settings["runs"][0]["caller_sources"]:
        assert ref(Path(caller["path"])) == caller
    fcntl.flock(handle, fcntl.LOCK_UN)
    reader["released_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
tmp = []
for path in [
    *[BASE / f"execution-v1/run-{index:03d}/TMP" for index in range(4)],
    TRIAL / "actual-entry-v1/submit-client-v1/TMP",
]:
    retired = []
    if path.exists():
        if "submit-client-v1" in path.parts:
            for item in path.iterdir():
                info = item.lstat()
                if (
                    item.name.startswith("uv-")
                    and item.name.endswith(".lock")
                    and item.is_file()
                    and not item.is_symlink()
                    and info.st_size == 0
                    and info.st_nlink == 1
                ):
                    retired.append(
                        dict(
                            path=str(item),
                            device=info.st_dev,
                            inode=info.st_ino,
                            size=0,
                        )
                    )
                    item.unlink()
        remaining = [str(item) for item in path.iterdir()]
        if not remaining:
            path.rmdir()
    else:
        remaining = []
    tmp.append(
        dict(path=str(path), remaining=remaining, retired_owned_empty_locks=retired)
    )
assert all(not entry["remaining"] for entry in tmp)
accepted = datetime.datetime.fromisoformat(receipt["RPC_response"]["created_at"])
finished = datetime.datetime.fromisoformat(outer["finished_at"])
stop = save(
    "native-normal-source-STOP.json",
    dict(
        issue="quoridor-4lc.324.25.3",
        job_id=outer["job_id"],
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        outer=ref(BASE / "parent-runtime-v1/result.json"),
        sequence=ref(BASE / "execution-v1/result.json"),
        normal_manifests=manifest_intake,
        native_normal_reader_STOP=sequence["reader_STOP"],
        actual_native_controllers_parent_submit_identities=known,
        current_four_after_STOP=settings["runs"][0]["caller_sources"],
        source_reader=reader,
        directwait_reaped=True,
        handles_complete=True,
        TMP=tmp,
        source_leases_remaining=[],
        owned_scientific_processes_remaining=[],
        accepted_inclusive_seconds=(finished - accepted).total_seconds(),
        outer_command_seconds=outer["wall_seconds"],
        nested_not_added=True,
        science_census_gate_analysis="PENDING_SAVED_ROWS; four normal custodyPASS alone is not104 usablePASS",
        original_old25_unchanged=True,
        future_host_quiet_not_claimed=True,
        current_collector="Actual return follows stop-guard-v1/return.json; no self-absence claim",
    ),
)
body = (
    "SAME25.3 IMMEDIATE ACTUAL native+normalcollection/sourceSTOP release BEFORE longanalysis/admin. "
    f"Job{outer['job_id']} normal4operation manifest/dataPASS and sequencePASS/cleanuptrue/remaining[]. "
    f"Native+normal readerSTOP{sequence['reader_STOP']}, outerfinished{outer['finished_at']}; "
    "known native/guardian/inner/sequence/outer/submit/launcher PID-start-boot absent/different, "
    "directwait/reap/handles/TMP/leases[]. Exactcurrent4c797/6749/3b/ed08 underNB SHacquired/released, "
    "no reader remains. This releases this exact NEW104 lifetime, not futurehostquiet. "
    "Saved104 row census/usable status/gate/ranks still PENDING, not exit0 or custody=sciencePASS. "
    "One bounded saved analysis CPU10/G18/no Mainreader/model/native/oldRAW follows, "
    "no heavyDB until analysis returned; Root may use compatible next source/timing boundary. "
    f"Accepted-inclusive{(finished - accepted).total_seconds():.6f}s once, outer{outer['wall_seconds']:.9f}s nested/fullfeesUNKNOWN. "
    f"FileRefs {json.dumps(dict(actual_STOP=stop, normal_manifests=manifest_intake))}\n"
    "Collector actual return stop-guard-v1/return.json then tiny STOPdelivery stop-root-delivery-v1/"
    "return.json. Original401b/9786/4UNKNOWN/100unperformed/old64STOPPED remain immutable; "
    "NEWconditional64 UNISSUED until NEWgate+actualseparatesupport. No replay/refill/newscope/"
    "poll/observer/RNG. Allpauses/seals/default/models/foreign/FAILED/NULL/UNKNOWNfees/50GB held.\n"
)
with (OUT / "immediate-STOP-handoff.txt").open("x") as output:
    output.write(body)
print(
    json.dumps(
        dict(
            actual_STOP=stop,
            manifest_intake=manifest_intake,
            usable104_status="PENDING_SAVED_ANALYSIS",
        )
    )
)
