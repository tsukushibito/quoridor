# 25.2 timed root-quality admission：限定source確認

固定binding `ffc80b082619efaa3e7965a385b384f3b55683114db286aa886bf4d67bec4eb8`、callee post `57741e74a53d21b49739bb76a4cb8f908fc64bc65286955fee573fc1e9df22d0` に対し、SOURCE_CLEAR、essential 0／ordinary 0。

実差分は `neighbour_opportunity.rs:583` の一条件。旧 `limits.time_limit.is_some()` を `observation.history_provenance.is_some() && limits.time_limit.is_some()` に置き換える。plain rootqualityはclock Someだけを理由に拒否されなくなる。timed history watchは拒否され、history watch without rootも前段574–578行で拒否される。timeNone history watchの既存条件、他のmode／D64／<=1M／TT1M／Control-DR-PVS-path_tailのguardは保持する。

immutable Git `3bf28324b1bbfd33dfd511d42ec8ace56f6d9cde` の必要なcallerだけを確認した。measurement validateはN1の明示rootquality例外、CPU team／management／memory、<=26 distinct roots／<=6 sessions、D64／node上限／TT1M／PVS／DR／path_tailと、clockに対応した正のreserve条件を維持する。Requestのtime minus reserveをSearchLimitsへ渡し、実calleeへ接続する。100ms＋5ms、baseline LMR係数などの元固定input／normal admissionを変更したり、新たに支給したりしない。

calleeは既存のconst SMP=false observed入口を使い、local/shared backendの拒否も不変。defaultOFFや非対象routeの処理・clock・権限は増えない。新しいregistry／validator／サービス／設定枝を追加せず、拒否範囲を既存history-provenance ownerへ限定する最小の修正になっている。

新single Rust定義は、Settings parsingだけではなく、実 `SearchSession::new_neighbour_opportunity` と `search_neighbour_opportunity` を合成したsynthetic callee fixtureである。constant evaluator、空prefix、95ms／8nodeのpositive admission、mode／depth／nodes／TT／PVS／TT-use／timed watch／watch-without-rootの8 refusal、pre-cancelとprepare-errorを扱う。pre-cancel／prepare-errorでfirst／last completedとpendingを捏造せず、parent snapshotを確認する提案である。observerのpublished／final_statsはcompleted rootの成功やDATA_VALIDATEDを意味しない。

この定義はUNBUILT／UNTYPED／UNRUN。errorの一次伝播と観測・parent復元を囲む必要な保存source対応だけを読み、assertionやcompiler／runtime成功を推定しない。作者のformat／outside-owner／roundtrip proofは保存refsを消費し、再実行しなかった。既存score／history／clock数学、旧software／source proof／validator／RAW／model／Search／RNGの再演は0。

元4 first-root slotsはPARTIAL／UNKNOWN、100未実施はそのまま。conditional64はSTOPPED_UNISSUED。このreviewはrefill、追加Search、数値再開、quota、software／runtime／性能資格を発行しない。Rootだけが実current sourceへ疎合成し、必要なnew-only softwareとfresh normal entryを扱う。closed25.1／旧21–24／26–27のscopeは変更しない。

必要な入力・callee／test refs、immutable callerのGit blob／SHA、minimum、control、readerSTOPと実helper returnを同OWNに保存した。全known owned readerはdirectwait/reap・handle closureとfresh exact PID/start/boot不在を確認し、TMP／Main source leaseは作成していない。light delivery・後続adminは別のlifetimeとし、全host／未来quietや実RSS連続peakは主張しない。

全USERPAUSE323／342.17、seals／newE／oldfits96、models／weights／defaults、foreign、FAILED／NULL／UNKNOWN費、decimal50GBと取消consultation8を保持する。minimumとsource STOPはlong reportやBeads administrationより先に324へ返却した。本人note／backup／closureは独立softwareやentryのgateにしない。
