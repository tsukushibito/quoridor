# Cedar root ordering品質：原26件の有限診断

**Controlを維持する。今回、実装へ進める具体的な新ordering改善候補は得られなかった。** 最深の実完了iterationで選択された手は、26件すべてがexact tier＋完全signed main/continuation historyのsingletonだった。同点内だけを変える近傍classでは、その26手の順位は変わらない。この母集団での記述であり、内部nodeや別局面の有効性・一般棋力・無効果の結論ではない。

原job43d701bdの通常manifest/dataはPASS。26/26呼出、25,000,193/26,000,000 nodes、6同色chronological sessions、親復元26/26、追加/欠落/失敗0。D64/1M/timeNoneで、全探索の停止はNodeLimit25件、DepthComplete1件。前者の最深完了iterationは深さ5〜30で、D64完了や正解手ではない。DepthCompleteの1件は残壁0・深さ64・193nodes。新Search/モデル/geometry/validator/RAW/RNG再演は0。

同一snapshotの全体順位はTT/PV等の上位tierを含む。比較shadowは、保存した同じfrozen keyのtier＋完全signed historyが一致するdistinct手だけを既存cheap class→ActionIDで並べ替えたもの。合法集合・key・STM・root/history・windowを固定して順位だけを記述計算し、ゲームstateやNNUEを再計算していない。

| 母集団 | 分母 | Control top1 / top3 / top5 | 同点shadow top1 / top3 / top5 | 選択手がdistinct tie | 改善 / 悪化 / 不変 |
| ------ | ---: | -------------------------- | ----------------------------- | -------------------: | ------------------ |

| 最深実完了snapshot |26|18 / 20 / 23|18 / 20 / 23|0|0 / 0 / 26|

| 最初の実完了snapshotの選択手 |26|8 / 16 / 20|8 / 16 / 20|11|0 / 1 / 25|

最深snapshotの選択tierはpromotion0が18、ordinary4が8、goal/killerは0。promotion18件は全て先頭であり、top1の18/26を独立なhistory精度とは読めない。ordinary8件に限るとtop1/3/5は0/2/5件。pawn20・wall6。最初のsnapshotで選択手が同点群に属した11例は全てhistory0で、tie内top1/3/5は両順とも4/9/10（分母11）。最深snapshotのtie内選択順位分母は0なので精度は算出不能であり、0%ではない。

最深snapshot全体にはdistinct tie group105、class→IDで実際に順が変わる群78がある。しかしそれらの群の存在と、そのsnapshotの選択手を上へ動かせることは別である。最初snapshotでは95群中64群が変化し、選択手のrankは1例だけ6位悪化した。top1/3/5の粗い区切りはこの悪化を隠す。

| root残壁 | roots | 最深Control＝shadow top1 / top3 / top5 | 選択tie |
| -------- | ----: | -------------------------------------- | ------: |

|0|2|2 / 2 / 2|0|

|1..4|6|3 / 3 / 4|0|

|5..10|6|3 / 4 / 5|0|

|11..15|6|4 / 5 / 6|0|

|16..20|6|6 / 6 / 6|0|

stock0は目標6に対して2、shortfall4を維持。入力は3family・両手番・6同色系列で、独立26局面ではない。session先頭6件は最深top1が6/6、継続20件は12/20だが、残壁・局面・完了深さも異なるためwarm効果や因果とは読まない。family/STM/series/選択pawn-wall/深さ/停止別の全分母はsummary.jsonとroot-ranks.csvに残した。既存432/14/15露出あり、public/sealed/training/interior/LMRとの任意重複はUNKNOWN。

最初の順序で後の最深選択手を振り返る別表は、top1/3/5が両順とも8/17/19（分母26）、順位変化0/26。最初と最深で選択手自体は12/26変わった。この別表では同じroot/STM/fullhistoryでもTT generation・promotion・探索中history・depthが異なり、同一window/同一状態の因果実験にはしない。

具体的な外れ例はroot14（433-series-0/STM1、残壁10、NodeLimit、完了深さ6）。選択wall207はordinary tier4、history−858、元順位94/97。同tierでもhistoryが異なるのでsingletonであり、近傍tie-breakでは94位のまま。root10/15もpawnが8位/7位だがsingleton。これらは非同点history側に順位差が残る観察に留まり、historyが誤っている／減衰・ペナルティ変更で改善するという原因は未立証。内部更新・cutoff・reductionとの対応がないため、今回は具体的な最小変更を提案・実装しない。

全26件にfirst＋latest committedが保存され、pendingは25件、1件は明示null。pendingは選択ラベルを供給しない。numericTT/no-orderは今回0。committed rootは全合法候補について試行が返ったが、scoutやfail-soft/boundは全手の正確な評価値を意味しない。childのwindowと返り値は**ROOT/parent視点**でありchild視点へ読み替えない。未探索内部枝、internal cutoff手/rank、failed/unreturned枝の深い真値はUNKNOWN。中間完了iterationもfirst/latest以外は未保存。

pending保存分のunvisited合計1516、unreturned合計25は途中観測であり、完了ラベルに混ぜない。TT/history/context/generation/実window/子試行はsnapshot-rows.jsonと元保存bufferへ結ぶ。

費用は観測込みSearch合計32.307573610s、outer wall37.347287979s。setup0.002783815s、target drop0.000393090s、driver whole32.773423478s。setup/reset/rootprepare/Search/journal/drop/wholeは包含関係を持ち、加算しない。observer clockは速度資格ではない。CPU/RAM peak・physical NN・fullfeesはUNKNOWN、原software失敗費用/NULL/cleanup差異も保持。

旧384局のRETAIN_CONTROL、旧LMR/17/20/18.2の結論・RAW・Git・image・FAILEDは不変。新ordering採用、追加game/LMR/seed/CI/sweep/refill権は発行しない。独立解釈/重要判断は324へ返し、own21は実受入れまでin_progress。

保存表: [root-ranks.csv](root-ranks.csv)、[primary-rows.json](primary-rows.json)、[snapshot-rows.json](snapshot-rows.json)、[cross-iteration-rows.json](cross-iteration-rows.json)、[summary.json](summary.json)。通常資格と元refは[collection](../collection-v1/collection.json)、[native+collection STOP](../collection-v1/native-collection-STOP.json)。
