"""One new pure metadata boundary definition for the proposed owner branch."""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "python"))
loader = importlib.util.spec_from_file_location(
    "private_root_quality_lc", OWN / "root-observation-source-v3/post-03.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


class RootOrderingQualityMetadata(unittest.TestCase):
    def test_bounded_offshadow_only_and_absent_default(self):
        with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as temp:
            parent = Path(temp)

            def write(name, body):
                p = parent / name
                raw = (json.dumps(body) + "\n").encode()
                p.write_bytes(raw)
                return dict(
                    path=str(p),
                    sha256=hashlib.sha256(raw).hexdigest(),
                    bytes=len(raw),
                    mode=f"{p.stat().st_mode & 0o7777:04o}",
                )

            config = dict(
                roots=[dict(input=0, pointer="", field="prefix", label="fake")],
                profile="control",
                tt_entries=1048576,
                use_tt=True,
                use_pvs=True,
                lmr=True,
                lmr_method="depth_rank",
                zero_stock_safe_race=True,
                zero_stock_safe_race_method="path_tail",
                neighbour_opportunity="off_shadow",
                namespace=dict(evaluator="fake", rules="standard", selectivity="fake"),
                output_bytes=20971520,
                record_bytes=262144,
            )
            requests = [
                dict(
                    id="one",
                    session="one",
                    root=0,
                    depth=64,
                    node_cap=1000000,
                    time_limit_ms=None,
                )
            ]
            count = 0

            def resolve(cfg, req):
                nonlocal count
                count += 1
                e = dict(
                    config=write(f"config-{count}.json", cfg),
                    schedule=write(f"requests-{count}.json", req),
                    rules="standard",
                    inputs=[dict(path=str(parent / "not-read"))],
                )
                return lc.measurement_config(e)

            resolved, _ = resolve(config, requests)
            self.assertNotIn("root_ordering_quality", resolved)
            enabled = {**config, "root_ordering_quality": True}
            self.assertTrue(resolve(enabled, requests)[0]["root_ordering_quality"])
            for value in (None, 0, "true"):
                with self.assertRaisesRegex(Exception, "root ordering quality Boolean"):
                    resolve({**config, "root_ordering_quality": value}, requests)
            for key, value in (("neighbour_opportunity", "on"), ("tt_entries", 16)):
                with self.assertRaisesRegex(Exception, "bounded root ordering quality"):
                    resolve({**enabled, key: value}, requests)
            for key, value in (
                ("depth", 5),
                ("node_cap", 1000001),
                ("time_limit_ms", 1),
            ):
                with self.assertRaisesRegex(Exception, "bounded root ordering quality"):
                    resolve(enabled, [{**requests[0], key: value}])
            with self.assertRaisesRegex(Exception, "bounded root ordering quality"):
                resolve(enabled, [])
            duplicate = [requests[0], {**requests[0], "id": "two"}]
            with self.assertRaisesRegex(Exception, "bounded root ordering quality"):
                resolve(enabled, duplicate)


if __name__ == "__main__":
    unittest.main()
