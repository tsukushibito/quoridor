"""ONE original normal208 serial submit, outside the finite source process guard."""

from datetime import datetime, timedelta, timezone
import os
from pathlib import Path
import subprocess
import sys

import json

from intake import BASE, OWN, ROOT, ref, save


def load(path):
    return json.loads(path.read_bytes())


sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    runtime = BASE / "normal208-runtime-v2"
    plan = load(runtime / "entry-plan.json")
    assert plan["launch_affinity"] == [0, 12, 14, 18]
    assert plan["parent_accepted_seconds"] == 7800
    assert plan["outer_command_seconds"] == 7740
    settings = load(Path(plan["settings"]["path"]))
    assert ref(Path(plan["settings"]["path"])) == plan["settings"]
    state = Path(plan["state_dir"])
    assert not state.exists() and not Path(settings["output"]).exists()
    assert len(settings["runs"]) == 8 and all(
        r["perf"] is None for r in settings["runs"]
    )
    for run in settings["runs"]:
        assert run["command_timeout_seconds"] == 900
        assert all(not os.path.lexists(run[k]) for k in ("data_root", "output", "TMP"))
        assert Path(run["data_root"]).parent.is_dir()
    guards = []
    for name in (
        "intake-guard-v1",
        "owner-interface-guard-v1",
        "materialize-guard-v2",
        "pre-submit-guard-v1",
    ):
        p = OWN / name / "result.json"
        g = load(p)
        assert g["status"] == "PASS" and g["TMP_remaining"] == []
        for ident in [
            g["controller"],
            *[c["guardian_return"]["child"] for c in g["checks"]],
        ]:
            now = process.process_info(ident["pid"])
            assert (now is None and not Path(f"/proc/{ident['pid']}").exists()) or (
                now is not None and process.identity(now) != ident
            )
        assert not (p.parent / "TMP").exists()
        guards.append(dict(file=ref(p), STOP=g["reader_STOP"]))
    m = load(runtime / "materialized.json")
    assert m["source_leases_remaining"] == []
    job = load(Path(plan["job_template"]["path"]))
    assert ref(Path(plan["job_template"]["path"])) == plan["job_template"]
    assert job["max_runtime_seconds"] == 7740 and job["end_at"] is None
    at = datetime.now(timezone.utc)
    job["end_at"] = (at + timedelta(seconds=7800)).isoformat()
    path = runtime / "job-entry-v1.json"
    jr = save(path, job)
    argv = [
        "taskset",
        "-c",
        "0,12,14,18",
        "bash",
        "scripts/dev/project-env.sh",
        "bash",
        "scripts/dev/research-job.sh",
        "submit",
        "--config",
        str(path),
        "--state-dir",
        str(state),
    ]
    intent = save(
        runtime / "submit-intent-v1.json",
        dict(
            at=at.isoformat(),
            argv=argv,
            config=jr,
            source=ref(Path(__file__)),
            launch_owner=process.identity(process.process_info(os.getpid())),
            source_guards_returned=guards,
            authority=ref(runtime / "authority-before-submit.json"),
            Root_source_STOP=m["actual_Root_source_STOP"],
            current_callers=m["caller_sources"],
            phase_supports=m["phase_supports"],
            source_leases_remaining=[],
            direct_Popen_outside_Cycle=True,
            actual_SMP_calls=0,
            RPC_not_native_entry=True,
            freshcontrols="Maintained normal entry owns fresh physicalSMT/peer/RAM/host/fullroots/whole/free/origin/currentrefs/ownerpausecancel/deadline/resource cleanup; no preparation certificate",
        ),
    )
    env = {**os.environ, **settings["runs"][0]["env"]}
    env.pop("TMPDIR", None)
    env["PATH"] = "/home/vscode/.local/bin:" + env["PATH"]
    env["BEADS_ACTOR"] = "codex:01a11004-79f3-7c20-872c-432a2c347664"
    with subprocess.Popen(
        argv, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate()
        code = child.wait()
    for name, body in (("submit.stdout", stdout), ("submit.stderr", stderr)):
        p = runtime / name
        assert not p.exists()
        p.write_bytes(body)
    returned = save(
        runtime / "submit-return-v1.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            intent=intent,
            returncode=code,
            directwait_reaped=True,
            pipes_closed=child.stdout.closed and child.stderr.closed,
            stdout=ref(runtime / "submit.stdout"),
            stderr=ref(runtime / "submit.stderr"),
            launcher_pid=child.pid,
            RPC_not_native_entry=True,
        ),
    )
    print(
        dict(
            returned=returned,
            returncode=code,
            stdout=stdout.decode(errors="replace"),
            stderr=stderr.decode(errors="replace"),
        )
    )
    assert code == 0


if __name__ == "__main__":
    main()
