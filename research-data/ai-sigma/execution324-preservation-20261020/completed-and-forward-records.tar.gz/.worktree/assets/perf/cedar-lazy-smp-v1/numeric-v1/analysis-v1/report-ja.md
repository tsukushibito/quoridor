# Lazy SMP 原208 calls 有限比較

通常8 RUN/208 calls/48 sessionsのmanifest/dataは全PASS。使用nodesは40,380,103/208,000,000。parent復元、root/完全weighted履歴/手番/合法集合対応は保存結果で照合。N1固定深さの2反復のaction/valuebits/PV/depth/stop/work/TTは一致。N2は別treeで、同仕事の速度比較ではない。

| phase/block   | threads | Search合計s | DepthComplete/NodeLimit/TimeLimit     |  CPU s | RSS累積最大MiB |
| ------------- | ------: | ----------: | ------------------------------------- | -----: | -------------: |
| fixed_depth/0 |       1 |    5.400490 | {'DepthComplete': 25, 'NodeLimit': 1} |  5.390 |          91.30 |
| fixed_depth/1 |       2 |    5.142967 | {'DepthComplete': 24, 'NodeLimit': 2} | 10.150 |         172.68 |
| fixed_depth/2 |       2 |    4.926335 | {'DepthComplete': 24, 'NodeLimit': 2} |  9.670 |         172.58 |
| fixed_depth/3 |       1 |    5.317496 | {'DepthComplete': 25, 'NodeLimit': 1} |  5.320 |          91.06 |
| fixed_clock/4 |       1 |    2.487277 | {'TimeLimit': 25, 'DepthComplete': 1} |  2.490 |          91.54 |
| fixed_clock/5 |       2 |    2.479777 | {'TimeLimit': 25, 'DepthComplete': 1} |  4.830 |         172.86 |
| fixed_clock/6 |       2 |    2.480193 | {'TimeLimit': 25, 'DepthComplete': 1} |  4.870 |         172.54 |
| fixed_clock/7 |       1 |    2.473081 | {'TimeLimit': 25, 'DepthComplete': 1} |  2.490 |          91.08 |

固定深さ: 全104 DepthComplete=False、max N2/min N1=0.967178（条件<=0.95）、root median非悪化6/26、25%以上悪化2/26。capped rootを除いた採用判定は行わない。
100ms/5ms reserve: root median main depth改善1/26、悪化0/26、差の合計0.5。main receipt<=100ms/depth>=1/NodeLimitなし=True。terminal Search return p95=0.099789s、max=0.105073s。receiptはSearch callbackでありarena親receiptではない。
全native process CPU N2/N1=1.881453（条件<=2.5）。CPUは全threadを含むOS tick差、RSSはprocess累積highwater。追加coreのCPU費単独では不採用にしない。main/helper/aggregate nodes/evals、TT contention、unused tickets、drain/discardとsetup/reset/rootprepare/journal/drop/wholeはCSV/summaryに分離しnestedは加算しない。

実用必須条件=True、固定深さ有用条件=False、同時間深さ有用条件=False。結論: **固定有限比較で実用的有用性を支持せず、conditional64はDORMANT/UNISSUED、補充なし**。

N1の旧imageとの実測parity/実測wall overheadはUNMEASURED。現在source保護対応や同じ新codeのN1反復は旧image実測の代用にしない。main完了深さはsafe-race葉を含むnominalであり、helper reachやfull-width真値ではない。NodeLimit/TimeLimit UNKNOWNを完了depth64へ変換しない。独立root標本ではなく同family履歴/sessionを共有し、stock0は2rootsのみ。棋力、一般速度、同等、無効果、default/model昇格は主張しない。

保存解析のみ。native/Search/旧suite/モデル/RAW資格/validator/CI/RNGを再演していない。原失敗、費UNKNOWN、pause/seals/default/models/foreign/decimal50GBを保持。原208は消費済み、追加gameや科学権を発行していない。

補足する分母と停止費: 固定深さは98 DepthComplete/6 NodeLimit、clockは4 DepthComplete/100 TimeLimit。root16と21に固定深さcensoringがあり、特にroot21の約0.506倍のclock合計でない固定深さ時間比は両版の完了同深さ速度として解釈しない。main/helper到達・全aggregate workは保存CSVを参照。

N2 104callsのhelper stop/drain p95 0.000044378s、max 0.000149696s。quiet後discard p95 0.004833811s、max 0.005429120s。いずれもSearchに含まれ、別加算しない。root/series/stockbin/初回対継続の全表はsummaryのstrataとCSVへ保存した。
