固定producer eda21215389ceb92cbe07c1ec8bd1306a7b58a60f21a77010247dd7536c26b2c、summary16916b45、結果前protocol83cc4670の原22有限結果についてCONCLUSION_CLEAR、essential0・ordinary0。材料となる重大な矛盾・過大主張は認めなかった。

原8 normalmanifest/data PASS、208 logical calls/48sessions/40,380,103nodesの保存対応を再用した。main-only、完全weighted history/STM/legal/親復元/accountingとN1固定深さ2反復の対応は保存資格の範囲であり、通常validatorやsource/softwareを再確認していない。

| 条件                           | 保存結果                      | 結果前条件との対応                                   |
| ------------------------------ | ----------------------------- | ---------------------------------------------------- |
| 固定深さの全call完了           | 98 DepthComplete、6 NodeLimit | 全104 DepthCompleteを満たさない                      |
| 固定深さSearch合計の分離       | maxN2/minN1 = 0.9671783379    | <=0.95を満たさない                                   |
| 固定深さroot中央値             | 非悪化6/26、25%超悪化2/26     | 必要な非悪化>=20/26を満たさない。悪化<=3だけは満たす |
| 同時間main nominal depth中央値 | 改善1/26、悪化0/26、差合計0.5 | 改善>=8/26、差合計>=8を満たさない                    |
| 実用必須条件                   | 保存結果は全PASS              | 必須条件だけでは有用条件の代用にならない             |

clock104のmain完了snapshot depth>=1、callbackreceipt<=100ms、NodeLimitなしを保存結果は満たす。terminal Search returnはp95 0.09978876035s<=0.105、max0.105072504s<=0.125。native process CPU N2/N1は29.52/15.69=1.88145315<=2.5。追加coreのCPU費単独で不採用としていない。結果前の有用性2経路はいずれもFALSEなので、NO_PRACTICAL_USEFULNESS_SUPPORT_IN_FIXED_FINITE_COMPARISON_NO_REFILLとconditional64 DORMANT_UNISSUED_NO_GAMESが対応する。追加208、4thread、refill、新candidate、対局やCIを認めない。

分母は全26 roots・各phase104callsで固定する。root16/21の打切りも残し、良いsubsetで判定し直さない。root21の要求depth29に対して保存main完了深さはN1 27/N2 26であり、固定深さ時間比約0.506を完了同深さ速度と呼べない。clockの100 TimeLimit UNKNOWN＋4 DepthCompleteも、全D64完了へ変換しない。normal DATA_PASSは、全callの要求深さ到達と同義ではない。

main snapshot callbackreceipt、helper quiet/discardを含むterminal Search return、arena親receiptは別である。mainのnominal/selective完了深さはhelper reachやfullwidth/oracleではない。N2 stop/drainとquiet-discardのn104は両phaseのN2全callsであり、clock-return gateのn104とは異なる集団である。drain/discard/setup/reset/rootprepare/journal/drop/wholeはnestedで加算しない。

両armは同じ新image、TT総容量1M、worker総数1対2。N1新image反復一致は旧imageの実測parity/wallを証明せず、旧image比較はUNMEASUREDのまま。仕事・tree/PV/valueが違うのでsamework/NPS speedupとは解釈しない。process CPUは全threads等のOS tick差、RSSはprocess累積highwaterであり、perworker CPUやwhole-family continuous peakへ読み替えない。outer73.69668109097984sは一度だけ、nested加算0、physicalNN/fullfees/globalactualはUNKNOWN。

同26 genuine prefixesは3families/6warm chronological sessionsを共有する。stockbin2,6,6,6,6、stock0不足4と履歴露出・相関を残す。既知432/384 exposure YES、その他training/sealed/LMR/interior exposure UNKNOWNであり、IID・一般heldoutではない。棋力、一般速度、同等、無効果、一般最適性、default/model昇格の結論は出さない。fault coverageも普遍的保証ではない。

固定小参照のSHA/size/modeと保存scalarの対応だけを確認した。native full records/CSV/RAW/archive、collection/normalvalidator/FINALIZE、sourceproof/旧work/tests/compiler/model/payload/geometry/ML/RNG/perf/Searchの再演は0。全FAILED/NULL/masks/UNKNOWN費/pauses/seals/defaults/models/foreign/50GBを保持する。実private readerSTOPと最小結論はreader-STOP.json/minimum-result.jsonに結合済みで324へ返却した。後続のreport/adminは独立23や他工程のentry/ACKgateではない。
