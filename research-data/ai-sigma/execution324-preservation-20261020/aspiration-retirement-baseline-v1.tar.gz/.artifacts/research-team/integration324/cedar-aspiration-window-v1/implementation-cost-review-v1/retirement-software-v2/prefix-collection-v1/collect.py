"""Collect the original lint prefix once and retire only its stopped release cache."""

import importlib.util
import json
from pathlib import Path
import shutil

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper = load(
        "existing_helpers",
        BASE.parents[1] / "software-v2/prefix-collection-v1/collect.py",
    )
    lc = load("current_lifecycle", ROOT / "scripts/dev/research-lifecycle.py")
    outer = json.loads((BASE / "check-runtime-v1/result.json").read_bytes())
    prefix = json.loads((BASE / "operation-prefix/prefix-result.json").read_bytes())
    intent = json.loads((BASE / "build-intent-prefix.json").read_bytes())
    assert outer["job_id"] == "09242ddc-2670-4598-b5b6-edf36b9dbabb"
    assert outer["outcome"] == "succeeded" and outer["exit_code"] == 0
    lc.settled(outer)
    assert (
        prefix["status"] == "PASS_TEST_LINT_PREFIX_ONLY" and prefix["cleanup_complete"]
    )
    assert len(prefix["checks"]) == 2
    known = []
    state = json.loads((BASE / "check-runtime-v1/state.json").read_bytes())
    for row in prefix["checks"]:
        assert (
            row["role"] == "lint"
            and row["status"] == "PASS"
            and row["cargo"]["warning_count"] == 0
        )
        lc.settled(row["guardian_return"])
        member = row["guardian_return"]["child"]
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    for member in [state["child"], state["supervisor"]]:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    with lc.lease():
        lc.source_check(intent["source"])
        assert not Path(intent["TMP"]).exists()
        target = Path(intent["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker == dict(
            writer=intent["writer"],
            target=str(target),
            support_sha256=intent["support"]["sha256"],
        )
        assert (target / "release").is_dir() and not (target / "release").is_symlink()
        # The old private executable and every result/log remain intact.
        shutil.rmtree(target / "release")
    packet = dict(
        status="ACTUAL_TWO_AFFECTED_CLIPPY_PASS_AND_SOURCE_STOP",
        outer=helper.ref(BASE / "check-runtime-v1/result.json"),
        prefix=helper.ref(BASE / "operation-prefix/prefix-result.json"),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        known_exact_fresh_absence=known,
        source_leases=[],
        TMP=[],
        remaining=[],
        retired_only="Stopped owned release-profile Clippy cache; no source/result/image/model deletion or fee refund",
        software="Lint prefix only; genuine baseline release still pending",
        host_future_quiet=False,
    )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        json.dump(packet, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(status=packet["status"], seconds=outer["wall_seconds"])))


if __name__ == "__main__":
    main()
