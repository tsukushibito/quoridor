"""Preserve completed cleanup software and the limited independent review."""

import importlib.util
import json
import re
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    selected = []
    for name in [
        "retirement-software-v1",
        "retirement-software-v2",
        "final-retirement-v1",
    ]:
        for path in helper.files_below(BASE / name):
            relative = str(path.relative_to(ROOT)).lower()
            if re.search(
                r"(^|[-_/])(ready|show|beads|backup|notes?|update|admin)([-_./]|$)",
                relative,
            ):
                continue
            if (
                "notification" in relative
                or "delivery" in relative
                or path.name == "supervisor.log"
            ):
                continue
            assert path.suffix not in {".onnx", ".pt", ".so", ".bin", ".pem", ".key"}
            assert path.stat().st_size < 24 * 1024**2
            selected.append(path)
    review = (
        ROOT
        / ".worktree/assets/perf/cedar-aspiration-window-review-v1/limited-cost-final-v1"
    )
    for name in [
        "source-minimum.json",
        "source-control.json",
        "source-reader-STOP.json",
        "source-returned-STOP.json",
        "final-minimum.json",
        "final-control.json",
        "final-reader-STOP.json",
        "final-returned-STOP.json",
        "final-scalar-correspondence.json",
    ]:
        selected.append(review / name)
    for name in [
        "Root-source-disposition-acceptance.json",
        "Root-final-review-acceptance.json",
        "Root-final-study-and-canonical-cleanup-acceptance.json",
    ]:
        selected.append(BASE / "final-route-v1" / name)
    selected.append(OUT / "preserve.py")
    helper.DEST = DEST
    name = "aspiration-retirement-baseline-v1.tar.gz"
    helper.write_archive(
        name,
        selected,
        "Exact17 end-of-purpose retirement, source/result related independent minima and actual Root acceptance, two affected all-target Clippy and genuine baseline release/normal finalization/sourceSTOP; failed metadata preparation/collection retained, no Cargo/native/test/model/RNG replay. Qualified image retained by reference, not archived. Live notification-only logs excluded; task state Beads.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    stop = (
        BASE / "retirement-software-v2/release-collection-v1/completion-and-STOP.json"
    )
    software = json.loads(stop.read_bytes())
    public = dict(
        issue="quoridor-4lc.324.29.3",
        source_retirement="Exact17 comparison-only subjects, Current100% and generic features preserved",
        source_verdict="SOURCE_CLEAR essential0 ordinary0",
        result_verdict="CONCLUSION_CLEAR essential0 ordinary0",
        affected_Clippy_checks=2,
        executed_old_tests=0,
        retained_test_scope="Unchanged generic timed-rootquality NN0 two source owners; retained qualified test receipt, not replayed",
        software_manifest=software["software_manifest"],
        artifact=software["artifact"],
        baseline_evaluation="UNMEASURED",
        release_outer_seconds_once=software["outer_seconds_once"],
        nested_added=0,
        affected_end_holding_B=software["affected_point_after"]["allocated_B"],
        conservative_current_known_cover_B=software["current_known_cover_B"],
        globalactual_fullfees="UNKNOWN",
        retired_cache="Only stopped owned serial compiler cache; private image and all source/results/failures retained",
        notification_lifetime="Separate live finished-job notifier, no Main reader/future host quiet claim",
        archive={
            key: manifest[key]
            for key in [
                "archive",
                "sha256",
                "bytes",
                "full_stream_restore_hash_mode_verified",
            ]
        },
    )
    with (DEST / "aspiration-retirement-baseline-v1.json").open("x") as stream:
        json.dump(public, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(public["archive"]))


if __name__ == "__main__":
    main()
