"""Save completed normal208 evidence and its frozen no-games decision."""

import importlib.util
import json
import re
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    paths = []
    for name in ["numeric-v3", "normal208-runtime-v3", "normal208-bind-v1"]:
        paths += old.files_below(OWN / name)
    selected = []
    for p in paths:
        relative = str(p.relative_to(OWN)).lower()
        if (
            re.search(
                r"(^|[-_/])(ready|show|beads|backup|notes?|update|admin)([-_./]|$)",
                relative,
            )
            or "delivery" in relative
            or p.name == "notification.json"
        ):
            continue
        assert (
            p.suffix not in {".onnx", ".pt", ".so", ".bin", ".lock", ".pem", ".key"}
            and not p.is_symlink()
        )
        assert p.stat().st_size <= 24 * 1024**2
        selected.append(p)
    selected.append(OUT / "preserve.py")
    old.DEST = DEST
    name = "aspiration-original208-result-v1.tar.gz"
    old.write_archive(
        name,
        selected,
        "One original5112dd76 normal208/48sessions data+savedanalysis and actualSTOP, native originaldata outputs retained byte-exact including failed pre-science metadata namespaces. Frozen2673 protocol remains original. No scientific/validator/native/model/RAW/RNG/test/build replay. Game128 not issued because declared major-root regression18/23. No new default, coefficient or general strength/equivalence/noeffect claim.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    s = json.loads((OWN / "numeric-v3/analysis-v1/summary.json").read_bytes())
    assert (
        s["calls"] == 208
        and s["sessions"] == 48
        and s["total_nodes"] == 23486705
        and s["correctness_observed"]
    )
    assert s["conditional_new29_128_gate"] is False and s["actual_new29_games"] == 0
    summary = dict(
        issue="quoridor-4lc.324.29",
        status="RETAIN_ROOT_ASPIRATION_OFF_NO_GAMES_FIXED_MAJOR_ROOT_REGRESSION",
        original_job="5112dd76-9b03-47b7-b1e5-82e65802ea4f",
        calls=208,
        sessions=48,
        nodes=23486705,
        requested_fixed_depth_complete=104,
        Search_ON_over_OFF=1.0286333008226842,
        whole_driver_ON_over_OFF=s["whole_driver_ON_over_OFF_fixed"],
        major_roots=[18, 23],
        root_rule="repeat-median ON/OFF>1.25 AND extra>.010s; serious aggregate OR any root",
        clock_safe=True,
        practical_timing_support=False,
        games=0,
        CI=0,
        future_width_or_refill_authorized=False,
        interpretation="One finite selective-search configuration; no general harm/noeffect/equivalence/strength/default claim; retry counts and extra work do not establish cause",
        elapsed_outer_seconds_once=67.71593602898065,
        nested_added=0,
        archive=dict(
            path=name,
            sha256=manifest["sha256"],
            bytes=manifest["bytes"],
            members=len(manifest["members"]),
            full_stream_SHA_size_mode_verified=True,
        ),
        model_image_refs="Genuine64844e88/19c2ab68 botharms, original source302dca2 in Git",
        fees_globalactual="UNKNOWN",
    )
    with (DEST / "aspiration-original208-result-v1.json").open("x") as stream:
        json.dump(summary, stream, indent=2)
        stream.write("\n")
    print(json.dumps(summary["archive"]))


if __name__ == "__main__":
    main()
