"""Return bounded metadata helpers and ordinary own administration before timing."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import ACTOR, ISSUE, OWN, ROOT, authority, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

OUT = Path(__file__).resolve().parent
RUNTIME = OWN / "normal208-runtime-v3"


def main():
    materialized = json.loads((RUNTIME / "materialized.json").read_text())
    settings = json.loads(Path(materialized["settings"]["path"]).read_text())
    assert ref(Path(materialized["settings"]["path"])) == materialized["settings"]
    assert (
        materialized["source_leases_remaining"] == []
        and materialized["native_calls_games_RNG"] == 0
    )
    assert len(settings["runs"]) == 8
    for run in settings["runs"]:
        assert (
            run["child_cpu_cores"] == [0, 12] and run["command_timeout_seconds"] == 900
        )
        assert run["approved_plan"] is None and run["perf"] is None
        assert (
            run["limits"]["owned_B"] == 369098752
            and run["limits"]["family_B"] == 4294967296
        )
        assert all(not os.path.lexists(run[k]) for k in ["output", "data_root", "TMP"])
        assert Path(run["data_root"]).parent.is_dir()
    known, guards, removed = [], [], []
    for stage in [
        "materialize-guard-v1",
        "materialize-guard-v2",
        "support-refusal-delivery-guard-v1",
        "materialize-guard-v3",
    ]:
        path = OUT / stage / "result.json"
        g = json.loads(path.read_text())
        if stage == "materialize-guard-v3":
            assert g["status"] == "PASS"
        ids = [g["controller"]]
        for row in g["checks"]:
            actual = row.get("guardian_return")
            fallback = path.parent / (row["name"] + ".process.json")
            if actual is None and fallback.exists():
                actual = json.loads(fallback.read_text())
            if actual:
                assert actual.get("remaining", []) == []
                if actual.get("child"):
                    ids.append(actual["child"])
        for identity in ids:
            current = process.process_info(identity["pid"])
            assert (
                current is None and not Path(f"/proc/{identity['pid']}").exists()
            ) or (current is not None and process.identity(current) != identity)
            known.append(
                dict(
                    expected=identity, now="ABSENT" if current is None else "DIFFERENT"
                )
            )
        tmp = path.parent / "TMP"
        if tmp.exists():
            for item in tmp.iterdir():
                info = item.lstat()
                assert item.name.startswith("uv-") and item.name.endswith(".lock")
                assert (
                    stat.S_ISREG(info.st_mode)
                    and info.st_size == 0
                    and info.st_nlink == 1
                )
                fd = os.open(item, os.O_RDONLY | os.O_NOFOLLOW)
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    assert (
                        os.fstat(fd).st_ino == info.st_ino and item.stat().st_size == 0
                    )
                    item.unlink()
                finally:
                    os.close(fd)
                removed.append(str(item))
            tmp.rmdir()
        guards.append(dict(file=ref(path), STOP=g["reader_STOP"]))
    authority("normal29-ready-v1", ["ready", "--json"])
    own = authority("normal29-show-v1", ["show", ISSUE, "--json"])[0]
    assert own["assignee"] == ACTOR and own["status"] == "in_progress"
    authority(
        "normal29-note-v1",
        [
            "update",
            ISSUE,
            "--append-notes",
            "Original29 actualnewBUILD64844e88/image19c2ab68 sameOFF/ON normal8materialized under currentLCc799+6749/3b/ed08/shortSHNB actuallyreleased. "
            "Python1/AI3/RunnerLIB2/Clippy/release actualPASS retained no replay. Protocol2673/representationCurrent100% fixed,208208M48sessions26genuine6series/root4D5/allpredecessors/time100reserve5/TT1M/N1baselineLMR. "
            "Originaldraftrequest aliases serialized to maintained depth/node_cap/time_limit_ms/session; counts/history/clock exact, full8frozenrefs retained. "
            "Metadata v1 fixeddepth time_reserve_ms:null refusal then v2 supportCPU3vschild2 refusal preserved BEFOREscience0; causalkeyomission and RootactualCPU2support derivative only. "
            "Actual352MiB whole2fullroots/free99295232/family4G1.5+2.5/child[0,12]/worker12main0outer18, forecast240MiB future<=issued260046848B, native20MiB frozen each no copies or grantreset. "
            "Current measurement_config/numerical_fields inherited641caSTRUCTURALonly/callerjoin/nativeCPU and typedrequested-effectiveaspiration contractPASS under owningroute, no payload/parity/model/native/Search/RNG/probe. "
            "Allsource/adminhelpers returned before ONE highestparent directPopen outsideCycle; normalfreshphysicalSMT-peer/RAM/host/free/fullroots/source/env/pausecancel/origin/end_at/serializer remains mandatory. "
            "RUN900/parent7800/command7740/cleanup60/end_atonce, launch[0,12,18]. RPCnotnativeSTART, originalevent once8collection/immediateactualSTOP beforeanalysis. "
            "No commit/push/ACK/parentgate; Rootfreeze throughactualnative+collectionSTOP, conditional128UNISSUED. Allpauses/seals/models/defaults/foreign/FAILED/NULL/UNKNOWNfees/50GB held. "
            + str(RUNTIME / "materialized.json"),
            "--json",
        ],
    )
    authority("normal29-backup-v1", ["backup", "sync", "--json"])
    saved = save(
        RUNTIME / "authority-before-submit.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            issue=ISSUE,
            assignee=ACTOR,
            status="in_progress",
            materialized=ref(RUNTIME / "materialized.json"),
            guards=guards,
            known_exact_fresh=known,
            removed_returned_empty_locks=removed,
            source_leases=[],
            TMP_entries=[],
            actual_calls=0,
            backup=ref(OWN / "authority-normal29-backup-v1.json"),
        ),
    )
    print(json.dumps(saved))


if __name__ == "__main__":
    main()
