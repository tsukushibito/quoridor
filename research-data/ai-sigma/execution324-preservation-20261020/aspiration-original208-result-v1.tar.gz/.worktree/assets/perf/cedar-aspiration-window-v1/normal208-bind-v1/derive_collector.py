"""Reuse saved normal collection shape for original29, without old science execution."""

from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
text = (
    ROOT
    / ".worktree/assets/perf/cedar-lazy-smp-followup-v1/normal208-bind-v1/collect208_v1.py"
).read_text()
text = text.replace(
    "from start_source_v1 import OWN as BASE, ROOT, ref, save",
    "from task_utils import OWN as BASE, ROOT, ref, save",
)
text = text.replace("numeric-v1", "numeric-v3").replace(
    "normal208-runtime-v1", "normal208-runtime-v3"
)
text = text.replace(
    "06ba14af-881f-43d9-9964-3728dea90c08", "5112dd76-9b03-47b7-b1e5-82e65802ea4f"
).replace("quoridor-4lc.324.27", "quoridor-4lc.324.29")
text = text.replace("threads=2", "threads=1").replace(
    '["control", "candidate", "candidate", "control"]', '["OFF", "ON", "ON", "OFF"]'
)
text = text.replace(
    'BASE / "replacement-v1/finite-protocol-v1.json"',
    'BASE / "finite-protocol-v1.json"',
)
text = text.replace(
    "Normal data validity only. Fixed practical/usefulness gates await savedanalysis; N2 schedule-dependent, no samework speedup. Fair current25-compatible control/candidate2thread; new27conditional64GATE_PENDING_UNISSUED; old22/24unchanged.",
    "Normal data validity only. Frozen aspiration29 fixed/clock/practical gates await savedanalysis; selective window trees may differ, not samework speedup. Same genuine image OFF/ON Current LOCAL1, original29 conditional128GATE_PENDING_UNISSUED; old27/28 unchanged.",
)
text = text.replace(
    '    print("MEASUREMENT_FIELDS", json.dumps(allrows[0], indent=2))',
    '    print("MEASUREMENT_FIELDS", json.dumps(allrows[0], indent=2))',
)
with (OUT / "collect.py").open("x") as f:
    f.write(text)
