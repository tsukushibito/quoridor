"""Bind only Root's CPU-count correction in fresh causal metadata namespaces."""

from pathlib import Path

OUT = Path(__file__).resolve().parent
text = (OUT / "materialize_v2.py").read_text()
for before, after in [
    (
        'RUNTIME = OWN / "normal208-runtime-v2"',
        'RUNTIME = OWN / "normal208-runtime-v3"',
    ),
    ('NUMERIC = OWN / "numeric-v2"', 'NUMERIC = OWN / "numeric-v3"'),
    ('AUTH / "issued-inputs.json"', 'AUTH / "issued-inputs-cpu2-v2.json"'),
]:
    assert text.count(before) == 1, before
    text = text.replace(before, after)
with (OUT / "materialize_v3.py").open("x") as f:
    f.write(text)
