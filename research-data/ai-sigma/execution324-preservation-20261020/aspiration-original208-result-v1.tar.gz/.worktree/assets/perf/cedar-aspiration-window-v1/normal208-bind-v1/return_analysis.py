"""Return saved finite29 interpretation, normal own note and bounded analysis STOP."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import ACTOR, ISSUE, OWN, ROOT, authority, command, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

OUT = Path(__file__).resolve().parent
ANALYSIS = OWN / "numeric-v3/analysis-v1"


def main():
    summary = json.loads((ANALYSIS / "summary.json").read_text())
    assert summary["calls"] == 208 and summary["total_nodes"] == 23486705
    assert summary["conditional_new29_128_gate"] is False
    known, removed = {}, []
    for name in [
        "actual-submit-notification-guard-v1",
        "collection-guard-v1",
        "collection-return-guard-v1",
        "analysis-guard-v1",
        "analysis-guard-v2",
    ]:
        path = OUT / name / "result.json"
        g = json.loads(path.read_text())
        identities = [g["controller"]]
        for row in g["checks"]:
            actual = row.get("guardian_return")
            fallback = path.parent / (row["name"] + ".process.json")
            if actual is None and fallback.exists():
                actual = json.loads(fallback.read_text())
            if actual:
                assert actual.get("remaining", []) == []
                if actual.get("child"):
                    identities.append(actual["child"])
        for identity in identities:
            current = process.process_info(identity["pid"])
            assert (
                current is None and not Path(f"/proc/{identity['pid']}").exists()
            ) or (current is not None and process.identity(current) != identity)
            known[str(identity)] = dict(
                expected=identity, now="ABSENT" if current is None else "DIFFERENT"
            )
        tmp = path.parent / "TMP"
        if tmp.exists():
            for item in tmp.iterdir():
                info = item.lstat()
                assert item.name.startswith("uv-") and item.name.endswith(".lock")
                assert (
                    stat.S_ISREG(info.st_mode)
                    and info.st_size == 0
                    and info.st_nlink == 1
                )
                fd = os.open(item, os.O_RDONLY | os.O_NOFOLLOW)
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    assert (
                        os.fstat(fd).st_ino == info.st_ino and item.stat().st_size == 0
                    )
                    item.unlink()
                finally:
                    os.close(fd)
                removed.append(str(item))
            tmp.rmdir()
    own = authority("analysis29-show-v1", ["show", ISSUE, "--json"])[0]
    assert own["assignee"] == ACTOR and own["status"] == "in_progress"
    authority(
        "analysis29-note-v1",
        [
            "update",
            ISSUE,
            "--append-notes",
            "Original29 ONE208 job5112dd76 normalALL8PASS/208calls48sessions/23486705nodes once, outer67.715936s once/nested0; actualnative+normalcollection/sourceSTOP72365474 sentRoot immediately before savedanalysis. "
            "Savedanalysis correctnessobservedTrue/all104fixedDepthComplete/clock104safe receiptviolations0 terminalp95.0993248335 max.107315694; no fullfault or oldimageparity claim. "
            "FixedOFF Searchsums3.971968464/3.830159149 vsON3.98854788/4.0369804, conservative1.0539980828/pooled1.0286333008 (2.8633percent LONGER); whole_driver1.0278935794 distinct. "
            "Predeclared majorroot18 ratio1.2916228274 extra.0167402815s androot23 ratio1.2609372241 extra.0125612265s, so originalconditional128 gateFALSE despiteclockdepthmedianimproved3/regressed0. "
            "RETAIN_ROOT_ASPIRATION_OFF_NO_GAMES_FIXED_MAJOR_ROOT_REGRESSION recommended in fixedfiniteevidence only; no general speed/strength/equality/noeffect/defaultpromotion. "
            "ON fixeddepth eachrepeat69retries(30low39high), fallback0; additionalwork/node/value/PV differences selective, no samework/causal claim. No newgames/CI/refill/width/sweep or quota transfer. "
            "CSV/root/series/stock/first-continuation/workbits/history/PV/parent correspondence, standaloneSVG/Japanese report at numeric-v3/analysis-v1/completion.jsonf5dd7ad2; actualanalysisguard returned. "
            "One helperlint unusedtimezone refusal beforeanalysisbody preserved/causalimportonly; successfulanalysis/plot/collection/native/validators not replayed. ProcessCPU/cumulativeRSS measuredscope only, physicalNN/familyRAMpeak/fullfees/globalactualUNKNOWN. "
            "Root importantinterpretation/acceptance and soleMain unsupportedsource/test/consumer cleanup remain; author reviewerdispatch/Mainwrite0, ownsameownerinprogress. Allpauses/seals/defaults/models/foreign/FAILED/NULL/UNKNOWN/50GB preserved.",
            "--json",
        ],
    )
    authority("analysis29-backup-v1", ["backup", "sync", "--json"])
    inodes = set()
    allocated = logical = files = 0
    for parent, _, names in os.walk(ANALYSIS):
        for name in names:
            p = Path(parent) / name
            info = p.lstat()
            assert stat.S_ISREG(info.st_mode)
            key = info.st_dev, info.st_ino
            if key not in inodes:
                inodes.add(key)
                allocated += info.st_blocks * 512
                logical += info.st_size
                files += 1
    point = save(
        ANALYSIS / "ordinary-analysis-affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            root=str(ANALYSIS),
            allocated_B=allocated,
            logical_B=logical,
            files=files,
            scope="New savedanalysis subtree once, separate from ended two-root holding; no oldholding rewalk/recharge/refund/loan. Latermetadata tails/globalactual/fullfees UNKNOWN",
        ),
    )
    stopped = save(
        ANALYSIS / "analysis-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            completion=ref(ANALYSIS / "completion.json"),
            returned_analysis_guard=ref(OUT / "analysis-guard-v2/result.json"),
            native_normal_STOP=ref(
                OWN / "numeric-v3/collection-v1/returned-collection-STOP.json"
            ),
            fresh_exact_analysis_delivery_ids=list(known.values()),
            removed_returned_empty_locks=removed,
            source_leases=[],
            TMP_entries=[],
            native_remaining=[],
            Main_reader=False,
            affected=point,
            native_model_RAW_validator_FINALIZE_RNG_replays=0,
            own_note_backup="PASS",
            scope="Original native/normalcollection returned earlier and bounded savedanalysis/helpers returned now; separate direct delivery follows, no futurehostquiet",
        ),
    )
    message = OUT / "final208-result-handoff.txt"
    message.write_text(
        "SAME29 ORIGINAL208 finite RESULT fixed/actualsavedanalysisSTOP now, notnewscience. Proposed RETAIN_ROOT_ASPIRATION_OFF_NO_GAMES_FIXED_MAJOR_ROOT_REGRESSION in thisfixedcomparison only. ALL8normalPASS/208calls48sessions/23,486,705nodes once; actualnative+normalcollection/sourceSTOP alreadydelivered beforeanalysis and Root freeze released. Source/candidate/26prefix/fullhistory/predecessors/LMR/TT/math unchanged, no repeatednative/validator/model/RAW/RNG/CI. CorrectnessobservedTRUE (savednormal legal/FP32bits/history/parent/mainauthority/typedconfig/namespace/cumulativecap; not fullfault/oldimageparity). ALL104fixedDepthComplete. OFF Searchsum[3.971968464,3.830159149] vsON[3.98854788,4.0369804]; maxON/minOFF1.0539980828, pooledON/OFF1.0286333008 =>2.8633%LONGER Searchbody, whole_driver1.0278935794 distinct. Root18 (stock15/continued/433series1turn0) medianratio1.2916228274 +.0167402815s;root23(stock14/continued/433series1turn1)1.2609372241 +.0125612265s =>BOTH frozenmajor-root rule>1.25 AND>.010s, so seriousregressionTRUE/conditional128gateFALSE. All104clock receipts<=.100/depth>=1, terminalp95.0993248335/max.107315694 safe; rootclockdepthmedian improved3/regressed0 doesNOT override frozenrootregression gate. FixedON69retry eachrepeat(30low39high)/fallback0, worknodes3,789,912 vsOFF3,641,311 each; correlation not establishedcause or samework speedup. Practical5%/repeatseparationFALSE. No128games/CI/support/refill/newwidth/pilot/sweep/defaultpromotion. SourceONLYimportant limitedquestion for SAMEexistingMax viaRoot: confirm fixedrootANDgate / Search-v-whole distinction / noequivalence-noeffect-generalstrength, then Root soleMain retire unsupported29aspiration module/config/fixtures/counters while protecting Half-retirement/currentmath and genericpriorfeatures; author doesnotdispatch/reopenoldreview. One nextquestion only: do root18/23 retry counts justify a future bounded initial-window change? Adjacent completedscore transitions/per-attempt timings UNKNOWN, noautomaticimplementation or newrights. "
        + json.dumps(
            dict(
                completion=ref(ANALYSIS / "completion.json"),
                summary=ref(ANALYSIS / "summary.json"),
                Japanese_report=ref(ANALYSIS / "report-ja.md"),
                actual_analysis_STOP=stopped,
                actual_analysis_point=point,
            )
        )
        + ". Outer67.71593602898065s ONCE, accepted-inclusive69.77458s alternative/nested0. CPU OSprocessallthread includesrender/cumulativeprocessRSS only, physicalNN/familyactualRAMpeak/fullfees/globalactualUNKNOWN. ActualanalysisSourceCPU2/G18/family1Gincl64/host4/G0/knownIDsfreshabsent/directreap/handles/TMPleases[]; originalpublication and matplotlibcache warning kept, plotvalidsavedvalues only/noRNG. One prebodyhelperlint unusedimport refusal preserved, actualsuccessfulanalysis not rerun. Normalownmeaningfulnote+backupPASS/sameassigneeinprogress; do not closeparent/others, ownnormalclose after actualRootnecessary acceptance/childclosure inputs, notindependenttaskgate. Allpauses/seals/defaults/models/foreign/FAILED/NULL/UNKNOWNfees/50GB/consultation8 and27/28 scopes held.\n"
    )
    sent = command(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--issue",
            "quoridor-4lc.324",
            "--cwd",
            str(ROOT),
            "--body-file",
            str(message),
        ]
    )
    delivery = save(ANALYSIS / "Root-result-delivery.json", sent)
    print(
        json.dumps(
            dict(
                analysis_STOP=stopped,
                point=point,
                delivery=delivery,
                returncode=sent["returncode"],
            )
        )
    )


if __name__ == "__main__":
    main()
