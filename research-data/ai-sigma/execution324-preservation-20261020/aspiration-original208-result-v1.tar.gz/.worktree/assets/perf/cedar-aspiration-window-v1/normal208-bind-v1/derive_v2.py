"""Causal normal-metadata correction, preserving failed v1 namespaces/source."""

from pathlib import Path

OUT = Path(__file__).resolve().parent
old = (OUT / "materialize.py").read_text()
replacements = [
    (
        'RUNTIME = OWN / "normal208-runtime-v1"',
        'RUNTIME = OWN / "normal208-runtime-v2"',
    ),
    ('NUMERIC = OWN / "numeric-v1"', 'NUMERIC = OWN / "numeric-v2"'),
    (
        '        c["time_reserve_ms"] = None if index < 4 else 5',
        '        if index >= 4:\n            c["time_reserve_ms"] = 5',
    ),
    (
        "depth None represents original0 reserve",
        "fixeddepth key absent represents original0 reserve",
    ),
]
for before, after in replacements:
    assert old.count(before) == 1, before
    old = old.replace(before, after)
with (OUT / "materialize_v2.py").open("x") as f:
    f.write(old)
