"""Original29 frozen finite gates, deterministic saved normal buffers only."""

from collections import Counter
import csv
from datetime import datetime
import json
import math
from pathlib import Path
import statistics
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import OWN, ref, save  # noqa: E402

OUT = OWN / "numeric-v3/analysis-v1"
COLLECTED = OWN / "numeric-v3/collection-v1"
METRICS = [
    "Search_s",
    "receipt_s",
    "terminal_s",
    "stop_tail_s",
    "nodes",
    "evals",
    "CPU_s",
    "rootprepare_s",
    "journal_s",
    "call_teardown_s",
]


def describe(values):
    if not values:
        return dict(n=0, sum=None, min=None, median=None, p95_linear=None, max=None)
    xs = sorted(values)
    at = 0.95 * (len(xs) - 1)
    lo, hi = math.floor(at), math.ceil(at)
    return dict(
        n=len(xs),
        sum=sum(xs),
        min=xs[0],
        median=statistics.median(xs),
        p95_linear=xs[lo] + (xs[hi] - xs[lo]) * (at - lo),
        max=xs[-1],
    )


def finite(x):
    return isinstance(x, (float, int)) and math.isfinite(x)


def ratio(a, b):
    return a / b if b > 0 else None


def csvsave(name, rows):
    with (OUT / name).open("x", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    OUT.mkdir()
    collection = json.loads((COLLECTED / "summary.json").read_text())
    rows = json.loads(Path(collection["rows"]["path"]).read_text())
    blocks = json.loads(Path(collection["blocks"]["path"]).read_text())
    protocol = json.loads((OWN / "finite-protocol-v1.json").read_text())
    assert (
        collection["original_protocol"]["sha256"]
        == "2673cc67b107b4a427676f88026261a98a32386e615eea8dac915740097890f6"
    )
    assert len(rows) == 208 and len(blocks) == 8
    metadata = protocol["roots"]
    by = {(r["block"], r["root_index"]): r for r in rows}
    assert len(by) == 208
    checks, calls, repeats = [], [], []
    on_config = protocol["one_candidate"]
    prefix = "root-aspiration-v1:3e000000:40000000:3:4:"
    retry_fields = [
        "attempts",
        "full_seed_searches",
        "fail_low",
        "fail_high",
        "retries",
        "full_fallbacks",
        "nodes",
        "evaluations",
    ]
    for r in rows:
        b, n, x = r["block"], r["root_index"], r["measurement"]
        m = metadata[n]
        on = b in [1, 2, 5, 6]
        expected = on_config if on else None
        w = x.get("root_aspiration_work")
        rootmatch = all(
            by[k, n]["root"] == r["root"]
            and by[k, n]["measurement"]["root_legal_action_ids"]
            == x["root_legal_action_ids"]
            for k in range(8)
        )
        rootmatch = (
            rootmatch
            and not r["root"]["synthetic"]
            and r["root"]["ply"] == m["ply"]
            and x["root_walls_remaining"] == m["stock"]
        )
        rootmatch = rootmatch and r["request"]["session"] == m["session_id"]
        value_ok = (
            finite(x["value"])
            and struct.unpack("<I", struct.pack("<f", x["value"]))[0] == x["value_bits"]
        )
        base_selectivity = (
            x["actual_selectivity"].removeprefix(prefix)
            if on
            else x["actual_selectivity"]
        )
        stat_ok = (
            (
                w is not None
                and all(type(w[k]) is int and w[k] >= 0 for k in retry_fields)
                and w["nodes"] <= x["work"]["nodes"]
                and w["evaluations"] <= x["work"]["evaluations"]
            )
            if on
            else w is None
        )
        check = dict(
            block=b,
            root=n,
            matched_fullweighted_history_legal_stock_session=rootmatch,
            parent_restored=x["parent_unchanged"],
            returned_Ok=x["returned"] == "Ok",
            legal_root_action=x["action"] in x["root_legal_action_ids"],
            PV_head=bool(x["PV"]) and x["PV"][0] == x["action"],
            finite_fp32_valuebits=value_ok,
            typed_requested_effective_aspiration=x["requested_root_aspiration"]
            == x["actual_root_aspiration"]
            == expected,
            namespace_prefix=(
                x["actual_selectivity"].startswith(prefix)
                if on
                else not x["actual_selectivity"].startswith(prefix)
            )
            and base_selectivity == by[0, n]["measurement"]["actual_selectivity"],
            LOCAL1=x["search_threads"] == 1
            and x["search_cpu_cores"] == [12]
            and x["SMP"] is None,
            node_budget=r["request"]["node_cap"] == 1000000
            and x["work"]["nodes"] <= 1000000,
            main_snapshot=x["completed_depth"] == x["main_receipted_completed_depth"],
            aspiration_work_subset=stat_ok,
        )
        checks.append(check)
        calls.append(
            dict(
                block=b,
                arm="ON" if on else "OFF",
                phase=r["phase"],
                root=n,
                family=m["family"],
                series=m["session_id"],
                turn=m["turn"],
                ply=m["ply"],
                stock=m["stock"],
                stockbin=m["band"],
                session_first=m["session_first"],
                requested_depth=r["request"]["depth"],
                completed_depth=x["completed_depth"],
                stop=x["stop"],
                status=x["status"],
                Search_s=x["Search_call_seconds"],
                receipt_s=x["main_completed_receipt_seconds"],
                terminal_s=x["Search_call_seconds"],
                stop_tail_s=x["Search_call_seconds"]
                - x["main_completed_receipt_seconds"],
                nodes=x["work"]["nodes"],
                evals=x["work"]["evaluations"],
                CPU_s=x["process_CPU_seconds"],
                process_peak_RSS_B=x["process_peak_RSS_B"],
                TT_probes=x["work"]["TT_probes"],
                TT_hits=x["work"]["TT_hits"],
                TT_cutoffs=x["work"]["TT_cutoffs"],
                TT_order_only=x["work"]["TT_order_only"],
                TT_replacements=x["work"]["TT_replacements"],
                TT_illegal=x["work"]["TT_illegal_moves"],
                action=x["action"],
                value_bits=x["value_bits"],
                PV=json.dumps(x["PV"]),
                parent_unchanged=x["parent_unchanged"],
                rootprepare_s=r["preparation_seconds"],
                journal_s=r["journal_seconds"],
                call_teardown_s=r["call_teardown_seconds"],
                **{f"asp_{k}": w[k] if w is not None else None for k in retry_fields},
            )
        )
    correctness = all(
        all(v for k, v in c.items() if k not in ["block", "root"]) for c in checks
    )
    root_table = []
    for n, m in enumerate(metadata):
        old = [by[b, n]["measurement"] for b in [0, 3]]
        new = [by[b, n]["measurement"] for b in [1, 2]]
        om = statistics.median(x["Search_call_seconds"] for x in old)
        nm = statistics.median(x["Search_call_seconds"] for x in new)
        old_depth = statistics.median(
            by[b, n]["measurement"]["completed_depth"] for b in [4, 7]
        )
        new_depth = statistics.median(
            by[b, n]["measurement"]["completed_depth"] for b in [5, 6]
        )
        differences = {}
        for arm, xx in [("OFF", old), ("ON", new)]:
            differences[arm] = [
                k
                for k in [
                    "action",
                    "PV",
                    "value_bits",
                    "work",
                    "completed_depth",
                    "stop",
                ]
                if xx[0][k] != xx[1][k]
            ]
        repeats.append(
            dict(
                root=n,
                **differences,
                scope="Fixed requested-depth repetitions; ON vs OFF selective-tree equality is not required. Clock scheduling can differ.",
            )
        )
        root_table.append(
            dict(
                **m,
                requested_depth=protocol["depths"][n]["requested_depth"],
                all4_fixed_DepthComplete=all(
                    by[b, n]["measurement"]["stop"] == "DepthComplete" for b in range(4)
                ),
                OFF_Search_median_s=om,
                ON_Search_median_s=nm,
                ratio=ratio(nm, om),
                extra_s=nm - om,
                declared_major_root_regression=nm > 1.25 * om and nm - om > 0.010,
                OFF_clock_depth_median=old_depth,
                ON_clock_depth_median=new_depth,
                clock_depth_delta=new_depth - old_depth,
                ON_vs_first_OFF_action_diff=sum(
                    x["action"] != old[0]["action"] for x in new
                ),
                ON_vs_first_OFF_PV_diff=sum(x["PV"] != old[0]["PV"] for x in new),
                ON_vs_first_OFF_valuebits_diff=sum(
                    x["value_bits"] != old[0]["value_bits"] for x in new
                ),
                ON_vs_first_OFF_nonclockwork_diff=sum(
                    x["work"] != old[0]["work"] for x in new
                ),
            )
        )
    block_table = []
    for b in blocks:
        xs = [r for r in calls if r["block"] == b["block"]]
        block_table.append(
            dict(
                block=b["block"],
                arm=b["arm"],
                phase=b["phase"],
                calls=len(xs),
                Search_s=b["Search_seconds"],
                setup_s=b["setup_seconds"],
                drop_s=b["target_drop_seconds"],
                whole_driver_s=b["whole_driver_seconds"],
                whole_before_publication_s=b["whole_before_result_publication_seconds"],
                reset_s=sum(
                    d["seconds"] for d in b["session_domains"] if d["domain"] == "reset"
                ),
                session_teardown_s=sum(
                    d["seconds"]
                    for d in b["session_domains"]
                    if d["domain"] == "teardown"
                ),
                nodes=sum(r["nodes"] for r in xs),
                evals=sum(r["evals"] for r in xs),
                CPU_s=sum(r["CPU_s"] for r in xs),
                process_peak_RSS_B=max(r["process_peak_RSS_B"] for r in xs),
                stops=dict(Counter(r["stop"] for r in xs)),
                **{
                    f"asp_{k}": sum(r[f"asp_{k}"] or 0 for r in xs)
                    for k in retry_fields
                },
            )
        )
    fixed = [r for r in calls if r["phase"] == "fixed_depth"]
    clock = [r for r in calls if r["phase"] == "fixed_clock"]
    all_complete = len(fixed) == 104 and all(
        r["stop"] == "DepthComplete" and r["completed_depth"] == r["requested_depth"]
        for r in fixed
    )
    off_sums = [block_table[b]["Search_s"] for b in [0, 3]]
    on_sums = [block_table[b]["Search_s"] for b in [1, 2]]
    conservative = ratio(max(on_sums), min(off_sums)) if all_complete else None
    pooled = ratio(sum(on_sums), sum(off_sums)) if all_complete else None
    major_roots = [
        i for i, r in enumerate(root_table) if r["declared_major_root_regression"]
    ]
    serious = all_complete and (conservative > 1.20 or bool(major_roots))
    failures = [
        dict(
            block=r["block"],
            root=r["root"],
            receipt_s=r["receipt_s"],
            completed_depth=r["completed_depth"],
            terminal_s=r["terminal_s"],
            stop=r["stop"],
        )
        for r in clock
        if not finite(r["receipt_s"])
        or r["receipt_s"] > 0.100
        or r["completed_depth"] < 1
        or not finite(r["terminal_s"])
    ]
    terminal = describe([r["terminal_s"] for r in clock if finite(r["terminal_s"])])
    receipt = describe([r["receipt_s"] for r in clock if finite(r["receipt_s"])])
    clock_safe = (
        len(clock) == 104
        and not failures
        and terminal["n"] == 104
        and terminal["p95_linear"] <= 0.110
        and terminal["max"] <= 0.125
    )
    gate = correctness and clock_safe and not serious
    whole_ratio = (
        ratio(
            sum(block_table[b]["whole_driver_s"] for b in [1, 2]),
            sum(block_table[b]["whole_driver_s"] for b in [0, 3]),
        )
        if all_complete
        else None
    )
    repeat_sep = all_complete and max(on_sums) < min(off_sums)
    practical = (
        all_complete
        and pooled <= 0.95
        and repeat_sep
        and not serious
        and clock_safe
        and whole_ratio <= 1.10
    )
    strata = []
    for dimension in ["family", "series", "turn", "stockbin", "session_first"]:
        for value in sorted({r[dimension] for r in calls}, key=str):
            for phase in ["fixed_depth", "fixed_clock"]:
                for arm in ["OFF", "ON"]:
                    xs = [
                        r
                        for r in calls
                        if r[dimension] == value
                        and r["phase"] == phase
                        and r["arm"] == arm
                    ]
                    strata.append(
                        dict(
                            dimension=dimension,
                            value=value,
                            phase=phase,
                            arm=arm,
                            calls=len(xs),
                            **{k: describe([r[k] for r in xs]) for k in METRICS},
                            main_depth=describe([r["completed_depth"] for r in xs]),
                            stops=dict(Counter(r["stop"] for r in xs)),
                            retry_work={
                                k: sum(r[f"asp_{k}"] or 0 for r in xs)
                                for k in retry_fields
                            },
                        )
                    )
    proof = save(
        OUT / "saved-correspondence.json",
        dict(
            correctness_observed=correctness,
            percall=checks,
            fixed_repeats=repeats,
            scope="Existing normal qualification and saved fields only, not native/validator/parity replay. Full later PV legality/child-history and fault paths not reconstructed.",
        ),
    )
    for name, data in [
        ("calls.csv", calls),
        ("roots.csv", root_table),
        ("blocks.csv", block_table),
    ]:
        csvsave(name, data)
    outer = json.loads((OWN / "numeric-v3/comparison-job-v1/result.json").read_text())
    rpc = json.loads((OWN / "normal208-runtime-v3/submit.stdout").read_text())
    summary = dict(
        status="ORIGINAL29_FIXED_208_SAVED_ANALYSIS_NO_REFILL",
        protocol=collection["original_protocol"],
        collection=ref(COLLECTED / "summary.json"),
        correspondence=proof,
        calls=208,
        sessions=48,
        total_nodes=collection["total_nodes"],
        node_upper=208000000,
        correctness_observed=correctness,
        fixed_depth=dict(
            all104_DepthComplete=all_complete,
            stops=dict(Counter(r["stop"] for r in fixed)),
            OFF_Search_sums=off_sums,
            ON_Search_sums=on_sums,
            max_ON_over_min_OFF_Searchsum=conservative,
            two_repeat_Search_sum_ratio=pooled,
            completed_time_qualification="QUALIFIED_FINITE_SEARCH_TIME_ONLY"
            if all_complete
            else "UNKNOWN_CENSORED_NO_SUBSET_OR_CAP_SPEEDUP",
            major_root_indices=major_roots if all_complete else None,
            observed_serious_regression=serious if all_complete else None,
            repeat_separation=repeat_sep,
        ),
        clock=dict(
            stops=dict(Counter(r["stop"] for r in clock)),
            receipt_failures=failures,
            receipt=receipt,
            terminal_Search=terminal,
            safety_PASS=clock_safe,
            depth_root_median_improved=sum(
                r["clock_depth_delta"] > 0 for r in root_table
            ),
            depth_root_median_regressed=sum(
                r["clock_depth_delta"] < 0 for r in root_table
            ),
            NodeLimit_horizon="CAPPED_UNKNOWN_NOT_D64COMPLETE",
            scope="Main callback receipt distinct from terminal Search return (includes local quiet/discard) and arena parent receipt; no per-attempt timer added",
        ),
        practical_timing_support=practical,
        whole_driver_ON_over_OFF_fixed=whole_ratio,
        conditional_new29_128_gate=gate,
        game_disposition="ELIGIBLE_ONLY_AFTER_SEPARATE_ACTUAL_ROOT128_SUPPORT_NORMAL_BINDINGS"
        if gate
        else "NO_GAMES_FIXED_GATE_FAILED_OR_UNRESOLVED",
        actual_new29_games=0,
        final_family_CI_executions=0,
        blocks=block_table,
        roots=root_table,
        strata=strata,
        costs=dict(
            outer_seconds_once=outer["wall_seconds"],
            accepted_inclusive_seconds_alternative=(
                datetime.fromisoformat(outer["finished_at"])
                - datetime.fromisoformat(rpc["created_at"])
            ).total_seconds(),
            nested_added=0,
            OFF_process_allthread_CPU_s=sum(
                r["CPU_s"] for r in calls if r["arm"] == "OFF"
            ),
            ON_process_allthread_CPU_s=sum(
                r["CPU_s"] for r in calls if r["arm"] == "ON"
            ),
            process_cumulative_peak_RSS_B=max(r["process_peak_RSS_B"] for r in calls),
            physical_NN_family_peak_RSS_fullfees_globalactual="UNKNOWN; processCPU includes rendering, cumulative processRSS is not a family percall peak",
        ),
        limits=[
            "Fixed26 correlated/exposed roots/3families/6samecolourseries;stock2,6,6,6,6 zero4shortfall, not unseen/IID",
            "Selective LMR/window work,value,PV may differ; no samework/fullwidth/general speed/strength/equality/noeffect/default/model promotion",
            "Bounded root retry counters include interrupted attempts and are subsets, never added to totalnodes/evals; no per-attempt clock attribution",
            "Setup/reset/rootprepare/journal/drop/whole and nested Search/receipt/stop tail kept separate; clocks never added twice",
            "Original208 exhausted; no refill/newwidth/pilot/sweep or old27/28/22 quota transfer. Conditional128 requires actual frozen gate and separate support.",
        ],
    )
    summary_ref = save(OUT / "summary.json", summary)
    # Standalone scientific figure, saved values only, no native/perf/CI.
    plot_status = "UNMEASURED"
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(1, 2, figsize=(10, 3.5))
        for ax, key, title in [
            (axes[0], "Search_s", "Search body"),
            (axes[1], "whole_driver_s", "Whole driver"),
        ]:
            ax.bar(
                range(4),
                [block_table[i][key] for i in range(4)],
                color=["#64748b", "#e07a2d", "#e07a2d", "#64748b"],
            )
            ax.set_xticks(range(4), ["OFF", "ON", "ON", "OFF"])
            ax.set_ylabel("seconds")
            ax.set_title(title + " / fixed depth")
        fig.suptitle("Original29 finite ABBA; selective work may differ")
        fig.tight_layout()
        fig.savefig(OUT / "fixed-search-versus-whole.svg")
        plt.close(fig)
        plot_status = "SAVED_VALUES_ONLY"
    except ImportError as error:
        plot_status = "UNAVAILABLE_EXISTING_ENV:" + str(error)
    report = f"""# 原29 root aspiration 有限比較

元208 calls/48 sessionsは全8 normal manifest/data PASS、{collection["total_nodes"]:,} nodes。保存対応確認は{correctness}。exit0と採用は別である。条件付き128局gateは **{gate}**、判断は **{summary["game_disposition"]}**。新game/CI実行0、補充・再試行・幅変更はしない。

固定深さ104件の全要求完了は{all_complete}。OFF Searchsumは{off_sums}秒、ONは{on_sums}秒。max(ON)/min(OFF)は{conservative}、二反復合計ON/OFFは{pooled}。これはSearch-body比でありwhole比ではない。重大root悪化は{major_roots if all_complete else "UNKNOWN（censoring）"}、固定規約の重大回帰判定は{serious if all_complete else "UNKNOWN"}。全件未完了なら全体の完了時間資格はUNKNOWN、都合のよい完了subsetやcap時間を速度改善にしない。

100ms/5ms104件のreceipt違反は{len(failures)}、terminal Search p95={terminal["p95_linear"]}秒/max={terminal["max"]}秒。時計gate={clock_safe}。root別clock完了深さmedianは改善{summary["clock"]["depth_root_median_improved"]}、悪化{summary["clock"]["depth_root_median_regressed"]}。TimeLimit/NodeLimitは実完了snapshotとcapped horizonを分け、D64完了や整数深さ向上を仮定しない。main callback/terminal return/arena parent receiptは別である。

固定深さwhole-driver ON/OFF={whole_ratio}。setup/reset/drop/journal/wholeとSearchは各表に別記し、nested時間を加算しない。5%以上＋反復分離＋whole/回帰条件による実用時間支持は{practical}。ONではfail-low/high・retry/fallback費用を含む。LMRと探索窓で木・work・value・PVが変わり得るため、同一仕事やfullwidthの速度・棋力・原因・等価・無効果の認定はしない。

元26 prefixesは同3family/両手番/6chronological seriesで全predecessorを保存。stock区分2/6/6/6/6、stock0不足4を維持し、family/series/stock/初回vs継続別の分母と値はsummary.strata、全root悪化はroots.csv、全208手/PV/valuebits/work/TT/receipt/parent復元はcalls.csvとcollection refに保存した。同root fullweighted history/合法候補/stock/session対応、typed ON/OFF・namespaceとnodecap・main snapshotを保存値で照合した。後続PVの全子合法性やfault全経路を再構成していない。

CPUはOS process全thread tick（render含む）、peakRSSはprocess累積highwater。family実peak/physical NN calls/fullfees/globalactualはUNKNOWN。outer {outer["wall_seconds"]}秒を一度、accepted-inclusive {summary["costs"]["accepted_inclusive_seconds_alternative"]}秒は代替分母でnested加算0。正常旧suite/model/RAW/native/validator/RNG再演0。図={plot_status}。

Rootへ実native+normalcollection/sourceSTOPを解析前に直接返却済み。original FAILED/NULL/cleanup-vs-disk/費UNKNOWN、pause/seal/default/model/foreign/decimal50GB、27/28独立scopeを保持する。sourceの採否・不要比較code整理・重要結論の限定確認はRootが既存Maxへ扱う。
"""
    (OUT / "report-ja.md").write_text(report)
    completion = save(
        OUT / "completion.json",
        dict(
            summary=summary_ref,
            report=ref(OUT / "report-ja.md"),
            calls=ref(OUT / "calls.csv"),
            roots=ref(OUT / "roots.csv"),
            blocks=ref(OUT / "blocks.csv"),
            figure=ref(OUT / "fixed-search-versus-whole.svg")
            if (OUT / "fixed-search-versus-whole.svg").exists()
            else None,
            plot_status=plot_status,
            native_model_RAW_RNG_CI_executions=0,
        ),
    )
    print(
        json.dumps(
            dict(
                completion=completion,
                correctness=correctness,
                all_depth_complete=all_complete,
                Search_ratio=conservative,
                pooled=pooled,
                major_roots=major_roots,
                clock_safe=clock_safe,
                terminal=terminal,
                game_gate=gate,
                practical=practical,
            )
        )
    )


if __name__ == "__main__":
    main()
