"""Immediate actual normal collection STOP before saved analysis."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import OWN, ROOT, command, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

OUT = Path(__file__).resolve().parent
COLLECTED = OWN / "numeric-v3/collection-v1"


def main():
    path = OUT / "collection-guard-v1/result.json"
    guard = json.loads(path.read_text())
    assert guard["status"] == "PASS" and guard["TMP_remaining"] == []
    fresh = []
    for identity in [
        guard["controller"],
        *(r["guardian_return"]["child"] for r in guard["checks"]),
    ]:
        current = process.process_info(identity["pid"])
        assert (current is None and not Path(f"/proc/{identity['pid']}").exists()) or (
            current is not None and process.identity(current) != identity
        )
        fresh.append(
            dict(expected=identity, now="ABSENT" if current is None else "DIFFERENT")
        )
    materialized = json.loads(
        (OWN / "normal208-runtime-v3/materialized.json").read_text()
    )
    support = json.loads(Path(materialized["phase_supports"][0]["path"]).read_text())
    allocated = logical = files = 0
    known = set()
    for root in support["roots"]:
        for parent, _, names in os.walk(root):
            for name in names:
                item = Path(parent) / name
                info = item.lstat()
                assert stat.S_ISREG(info.st_mode), item
                key = info.st_dev, info.st_ino
                if key not in known:
                    known.add(key)
                    allocated += info.st_blocks * 512
                    logical += info.st_size
                    files += 1
    point = save(
        COLLECTED / "retained-holding.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            roots=support["roots"],
            allocated_B=allocated,
            logical_B=logical,
            files=files,
            scope="Issued two-root inodeunion ONCE at actualnative+normalcollectionSTOP; replaces forecast only by Root accounting. Pending savedanalysis allowance stays originalscope; no refund/quota reset/loan/deletion/globalwalk",
            saved_analysis_future_allowance_within_originalwhole_B=33554432,
            later_tails_global_actual_fees="UNKNOWN",
        ),
    )
    returned = save(
        COLLECTED / "returned-collection-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            native_normal_STOP=ref(
                COLLECTED / "native-and-normal-collection-STOP.json"
            ),
            returned_collection_guard=ref(path),
            fresh_exact_collector_ids=fresh,
            source_leases=[],
            TMP_entries=[],
            native_remaining=[],
            Main_reader=False,
            holding=point,
            scope="Actualnative+normalcollection and collector source helper returned; this separate light delivery follows, no futurehostquiet",
        ),
    )
    summary = json.loads((COLLECTED / "summary.json").read_text())
    body = OUT / "actual-normal-STOP-handoff.txt"
    body.write_text(
        "SAME29 IMMEDIATE ORIGINAL208 actualnative+normalcollection/sourceSTOP BEFORE longsavedanalysis. Originaljob5112dd76 normalALL8manifest/dataPASS/208calls48sessions/23,486,705nodes ONCE of208M, outer67.71593602898065s ONCE/nested0, no FINALIZE/validator/native/model/RAW/RNG replay. Not speed/strength/adoption; frozenclock/practical gates PENDING savedanalysis. Actual8operation/nativeorigin entries now known from owningnormalmanifests (not originalRPC). Source/current4/image/libs/env/Git/Cargo/heavyIO timingfreeze for thisoriginal208 RELEASED by actualSTOP only, optionalstandingpush may proceed; no parent/report/reviewer/ACKgate. "
        + json.dumps(
            dict(
                summary=ref(COLLECTED / "summary.json"),
                actual_native_normal_source_STOP=returned,
                actual_two_root_holding=point,
                outer_seconds=summary["outer_wall_seconds_once"],
            )
        )
        + ". All originalnative/controller/submit/parentexactIDs freshabsent/different inSTOP, all8nativeTMP absent/directwait-reap/handles/TMPleases[]; collector guardianreturnedPASS/freshIDsabsent. Deliverylifetime separate/nofuturehostquiet. SAME29 proceeds savedanalysis CPU2/G18/family1G incl64/host4/G0 withnoMainreader. Conditional128 UNISSUED until frozenrealgate+separateRootsupport;208exhausted/no pilot/refill/extraSearch. Oldnamespace failures andallpauses/seals/defaults/models/foreign/FAILED/NULL/UNKNOWNfees/50GB/consultation8 kept.\n"
    )
    sent = command(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--issue",
            "quoridor-4lc.324",
            "--cwd",
            str(ROOT),
            "--body-file",
            str(body),
        ]
    )
    delivery = save(COLLECTED / "Root-STOP-delivery.json", sent)
    print(
        json.dumps(
            dict(
                STOP=returned,
                holding=point,
                delivery=delivery,
                returncode=sent["returncode"],
            )
        )
    )


if __name__ == "__main__":
    main()
