"""Consume the eight already normal-validated SMP result buffers once."""

from collections import Counter
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from task_utils import OWN as BASE, ROOT, ref, save  # noqa: E402


def document(reference):
    path = Path(reference["path"])
    assert ref(path) == reference
    return json.loads(path.read_bytes())


sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    out = BASE / "numeric-v3/collection-v1"
    assert not out.exists()
    out.mkdir()
    save(
        out / "entry.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            source=ref(Path(__file__)),
            identity=process.identity(process.process_info(os.getpid())),
            affinity=sorted(os.sched_getaffinity(0)),
            scope="Saved normalmanifest/data resultbuffer only. No FINALIZE/collect_data/native/validator/model/Search/geometry/RNG replay",
        ),
    )
    root = BASE / "numeric-v3"
    outer = json.loads((root / "comparison-job-v1/result.json").read_bytes())
    log = (root / "comparison-job-v1/output.log").read_text()
    job = json.loads((root / "comparison-job-v1/config.json").read_bytes())
    sequence = json.loads((root / "execution-v1/result.json").read_bytes())
    assert (
        outer["exit_code"] == 0
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and outer["remaining"] == []
    )
    assert (
        sequence["status"] == "PASS"
        and sequence["primary"] is None
        and sequence["secondary"] == []
        and sequence["completed_operations"] == 8
        and sequence["remaining"] == []
        and sequence["cleanup_complete"]
    )
    assert outer["job_id"] == "5112dd76-9b03-47b7-b1e5-82e65802ea4f"
    assert len(sequence["operations"]) == 8 and job["issue"] == "quoridor-4lc.324.29"
    allrows = []
    blocks = []
    identities = [sequence["originating_job"][k] for k in ("supervisor", "child")]
    for i, op in enumerate(sequence["operations"]):
        m = document(op["manifest"])
        assert (
            op["completed"]
            and m["status"] == "PASS"
            and m["primary"] is None
            and m["secondary"] == []
            and m["cleanup_complete"]
            and m["remaining"] == []
        )
        assert m["data"]["status"] == "PASS" and m["data"]["errors"] == []
        for c in m["checks"]:
            g = c["guardian_return"]
            assert (
                c["status"] == "PASS" and c["primary"] is None and c["capture_complete"]
            )
            assert (
                g["exit_code"] == 0
                and g["direct_child_reaped"]
                and g["cleanup_complete"]
                and g["handle_closes_complete"]
                and g["remaining"] == []
            )
            identities.append(g["child"])
        result_ref = next(
            f for f in m["data"]["files"] if f["path"].endswith("/result.json")
        )
        d = document(result_ref)
        assert d["calls"] == d["attempted"] == 26 and d["errors"] == []
        assert (
            d["extra_calls"] == d["unperformed"] == d["unscheduled"] == 0
            and d["remaining_requests"] == []
        )
        identities.extend(
            v
            for k, v in d["runtime_launch_origin"].items()
            if k in ("native", "guardian", "profiler")
        )
        rows = d["measurements"]
        assert len(rows) == 26
        requests = []
        for n, row in enumerate(rows):
            req = row["request"]
            x = row["measurement"]
            assert req["root"] == n and req["node_cap"] == 1000000 and not req["warmup"]
            assert req["time_limit_ms"] == (None if i < 4 else 100)
            assert (
                x["returned"] == "Ok"
                and x["parent_unchanged"]
                and x["work"]["nodes"] <= 1000000
            )
            requests.append(req)
            allrows.append(
                dict(
                    block=i,
                    phase="fixed_depth" if i < 4 else "fixed_clock",
                    threads=1,
                    arm=["OFF", "ON", "ON", "OFF"][i % 4],
                    root_index=n,
                    **row,
                )
            )
        assert len({r["session"] for r in requests}) == 6
        b = dict(
            block=i,
            phase="fixed_depth" if i < 4 else "fixed_clock",
            threads=1,
            arm=["OFF", "ON", "ON", "OFF"][i % 4],
            calls=d["calls"],
            manifest=op["manifest"],
            native_result=result_ref,
            normal_reader_STOP=op["reader_STOP"],
            statuses=dict(Counter(r["measurement"]["status"] for r in rows)),
            stops=dict(Counter(r["measurement"]["stop"] for r in rows)),
            nodes=sum(r["measurement"]["work"]["nodes"] for r in rows),
            evaluations=sum(r["measurement"]["work"]["evaluations"] for r in rows),
            Search_seconds=sum(r["measurement"]["Search_call_seconds"] for r in rows),
            setup_seconds=d["setup_seconds"],
            target_drop_seconds=d["target_drop_seconds"],
            whole_before_result_publication_seconds=d[
                "whole_before_result_publication_seconds"
            ],
            whole_driver_seconds=d["whole_driver_seconds"],
            session_domains=d["session_domains"],
            normal_checks=m["checks"],
        )
        blocks.append(b)
    assert len(allrows) == 208 and sum(b["nodes"] for b in blocks) <= 208000000
    known = []
    runtime = BASE / "normal208-runtime-v3"
    intent = json.loads((runtime / "submit-intent-v1.json").read_bytes())
    identities.append(intent["launch_owner"])
    for ident in {json.dumps(v, sort_keys=True): v for v in identities}.values():
        now = process.process_info(ident["pid"])
        assert (now is None and not Path(f"/proc/{ident['pid']}").exists()) or (
            now is not None and process.identity(now) != ident
        )
        known.append(
            dict(
                expected=ident,
                now="ABSENT" if now is None else "DIFFERENT_EXACT_IDENTITY",
            )
        )
    tmp_paths = [
        Path(run["TMP"])
        for run in json.loads((runtime / "settings.json").read_bytes())["runs"]
    ]
    assert all(not p.exists() for p in tmp_paths)
    assert not list((root / "execution-v1").glob("run-*/TMP"))
    rr = save(out / "saved-rows.json", allrows)
    br = save(out / "blocks.json", blocks)
    stop = save(
        out / "native-and-normal-collection-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            outer=ref(root / "comparison-job-v1/result.json"),
            output_log=ref(root / "comparison-job-v1/output.log"),
            config=ref(root / "comparison-job-v1/config.json"),
            sequence=ref(root / "execution-v1/result.json"),
            normal_reader_STOPs=[b["normal_reader_STOP"] for b in blocks],
            known_exact_identities_fresh_absent_or_different=known,
            native_TMP_absent=[str(p) for p in tmp_paths],
            source_leases_remaining=[],
            original_job_cleanup_complete=True,
            collection_helper_lifetime="Current helper itself returns via its guarded process receipt; not included in priornativeSTOP",
            host_future_quiet=False,
        ),
    )
    sr = save(
        out / "summary.json",
        dict(
            status="ALL8_NORMAL_MANIFEST_DATA_PASS_SAVED_COLLECTION",
            calls=208,
            sessions=48,
            total_nodes=sum(b["nodes"] for b in blocks),
            nodes_upper=208000000,
            rows=rr,
            blocks=br,
            native_and_normal_STOP=stop,
            outer_wall_seconds_once=outer["wall_seconds"],
            job_id=outer["job_id"],
            original_protocol=ref(BASE / "finite-protocol-v1.json"),
            nested_wall_added=0,
            output_log_bytes=len(log.encode()),
            interpretation="Normal data validity only. Frozen aspiration29 fixed/clock/practical gates await savedanalysis; selective window trees may differ, not samework speedup. Same genuine image OFF/ON Current LOCAL1, original29 conditional128GATE_PENDING_UNISSUED; old27/28 unchanged.",
            all_fees_fullCPU_RSS_globalactual="UNKNOWN unless explicit saved nativefields",
        ),
    )
    print(json.dumps(dict(summary=sr, STOP=stop)))
    print("MEASUREMENT_FIELDS", json.dumps(allrows[0], indent=2))
    print("N2_MEASUREMENT", json.dumps(allrows[26], indent=2))
    print("CLOCK_MEASUREMENT", json.dumps(allrows[104], indent=2))
    print(
        "BLOCK_FIELDS",
        json.dumps(
            {k: v for k, v in blocks[0].items() if k != "normal_checks"}, indent=2
        ),
    )


if __name__ == "__main__":
    main()
