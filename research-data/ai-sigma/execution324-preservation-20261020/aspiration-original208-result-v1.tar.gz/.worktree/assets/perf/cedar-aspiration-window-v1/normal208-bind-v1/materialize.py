"""Original29 normal eight RUNs using current canonical owner and issued resources."""

from copy import deepcopy
from datetime import datetime, timezone
import fcntl
import importlib.util
import inspect
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import ACTOR, ISSUE, OWN, ROOT, ref, save  # noqa: E402

OUT = Path(__file__).resolve().parent
RUNTIME = OWN / "normal208-runtime-v1"
NUMERIC = OWN / "numeric-v1"
TEMPLATES = ROOT / ".worktree/assets/perf/cedar-lazy-smp-v1/normal208-preparation-v1"
AUTH = (
    ROOT
    / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/normal208-entry-v1"
)


def load(path):
    return json.loads(Path(path).read_text())


def document(reference):
    path = Path(reference["path"])
    assert ref(path) == reference, reference
    return load(path)


def main():
    issued_ref = ref(AUTH / "issued-inputs.json")
    issued = load(issued_ref["path"])
    release = document(issued["release"])
    support_ref = issued["phase_supports"][0]
    support = document(support_ref)
    document(issued["capacity"])
    document(release["actual_software_STOP"])
    document(release["collector_guard"])
    manifest = document(release["software_manifest"])
    assert manifest["status"] == "PASS" and manifest["artifact"] == release["artifact"]
    assert (
        release["control_artifact"]
        == release["candidate_artifact"]
        == release["artifact"]
    )
    assert support["whole_B"] == 369098752 and support["free_B"] == 99295232
    assert support["roots"][0] == str(OWN) and len(support["roots"]) == 2
    controls = load(OWN / "representation-amendment-v1/normal208-controls.binding.json")
    protocol = document(controls["protocol"])
    assert (
        controls["protocol"]["sha256"]
        == "2673cc67b107b4a427676f88026261a98a32386e615eea8dac915740097890f6"
    )
    common = load(TEMPLATES / "common-bindings.draft.json")
    inherited = load(
        ROOT
        / ".worktree/assets/perf/cedar-lazy-smp-followup-v1/normal208-runtime-v1/numerical-000.json"
    )
    assert len(common["models"]) == 1 and len(common["dynamic_libraries"]) == 5
    assert not RUNTIME.exists() and not NUMERIC.exists()
    RUNTIME.mkdir()
    NUMERIC.mkdir()
    config_refs, request_refs, correspondence = [], [], []
    for index, (cr, rr) in enumerate(
        zip(controls["settings"], controls["requests"], strict=True)
    ):
        c = deepcopy(document(cr))
        requests = document(rr)
        assert len(requests) == 26 and len(c["roots"]) == 26
        # Mandatory ordinary resource/clock settings only; no scientific change.
        c["native_memory_bytes"] = support["resources"]["native_B"]
        c["time_reserve_ms"] = None if index < 4 else 5
        assert c["search_threads"] == 1 and c["search_cpu_cores"] == [12]
        assert c["output_bytes"] == 20971520 and c["record_bytes"] == 262144
        assert c.get("root_aspiration") == (
            None
            if index in [0, 3, 4, 7]
            else dict(half_width=0.125, growth=2.0, activation_depth=3, max_retries=4)
        )
        assert "shallow_main_history" not in c
        native = []
        for i, r in enumerate(requests):
            assert r["root"] == i and r["repeat"] == 1 and r["max_nodes"] == 1000000
            assert r["session_id"] == protocol["roots"][i]["session_id"]
            assert r["session_first"] == protocol["roots"][i]["session_first"]
            assert r["max_depth"] == (
                protocol["depths"][i]["requested_depth"] if index < 4 else 64
            )
            assert r["time_ms"] == (None if index < 4 else 100)
            assert r["reserve_ms"] == (0 if index < 4 else 5)
            native.append(
                dict(
                    id=f"aspiration29-run-{index:03d}-root-{i:02d}",
                    session=r["session_id"],
                    root=i,
                    depth=r["max_depth"],
                    node_cap=r["max_nodes"],
                    time_limit_ms=r["time_ms"],
                    diagnostic=r["diagnostic"],
                    warmup=r["warmup"],
                    observe_lmr=r["observe_lmr"],
                    observe_completed_depths=r["observe_completed_depths"],
                )
            )
        assert native[4]["depth"] == (5 if index < 4 else 64)
        config_refs.append(save(RUNTIME / f"config-{index:03d}.json", c))
        request_refs.append(save(RUNTIME / f"requests-{index:03d}.json", native))
        correspondence.append(
            dict(
                index=index,
                frozen_config=cr,
                frozen_requests=rr,
                normal_aliases={
                    "max_depth": "depth",
                    "max_nodes": "node_cap",
                    "time_ms": "time_limit_ms",
                    "session_id": "session",
                },
                single_repeat=1,
                session_first="Existing maintained session initialization on first request per id; all six series and every predecessor retained",
                reserve="Frozen reserve lifted to normal config.time_reserve_ms; depth None represents original0 reserve",
                resource_only_additions=["native_memory_bytes", "time_reserve_ms"],
                science_unchanged=True,
            )
        )
        (NUMERIC / f"measure-{index:03d}").mkdir()
    callers = release["current_four_callers"]
    settings = deepcopy(load(TEMPLATES / "settings.draft.json")["normal_fields"])
    settings.update(
        owner=str(OWN),
        output=str(NUMERIC / "execution-v1"),
        runs=[],
        arena=None,
        limits=deepcopy(support["limits"]),
    )
    fd = os.open(
        ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock",
        os.O_RDONLY | os.O_NOFOLLOW,
    )
    acquired = None
    blocks = []
    try:
        fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
        acquired = datetime.now(timezone.utc).isoformat()
        assert all(ref(Path(r["path"])) == r for r in callers)
        loader = importlib.util.spec_from_file_location(
            "aspiration29_current_normal_owner", callers[0]["path"]
        )
        lc = importlib.util.module_from_spec(loader)
        sys.modules[loader.name] = lc
        loader.loader.exec_module(lc)
        for index in range(8):
            e = deepcopy(
                load(TEMPLATES / f"experiment-{index:03d}.draft.json")["normal_fields"]
            )
            e.update(
                build_manifest=release["software_manifest"],
                config=config_refs[index],
                schedule=request_refs[index],
                canonical_plan_sha256="",
                argv=[
                    release["artifact"]["path"],
                    "measure",
                    "--experiment",
                    "@EXPERIMENT@",
                    "--experiment-sha256",
                    "@EXPERIMENT_SHA256@",
                ],
            )
            assert (
                e["models"] == common["models"]
                and e["inputs"] == common["inputs"]
                and e["dynamic_libraries"] == common["dynamic_libraries"]
            )
            numerical = lc.numerical_fields(e, manifest)
            for key, value in numerical.items():
                if key not in {"artifact_sha256", "config_sha256", "schedule_sha256"}:
                    assert value == inherited[key], key
            numerical.update(
                original_evidence=inherited["original_evidence"],
                correspondence_only=True,
                inherited_same_body_scope="Original641ca Cedar structural only; genuine current software and normal numerical_fields do not assert new model/head/FP32 parity",
                source_owner=callers[0],
                actual_software_Build=release["software_manifest"],
                new_model_head_Search_parity_calls=0,
            )
            nr = save(RUNTIME / f"numerical-{index:03d}.json", numerical)
            e["numerical_qualification"] = nr
            config, requests = lc.measurement_config(e)
            assert config == load(config_refs[index]["path"]) and requests == load(
                request_refs[index]["path"]
            )
            er = save(RUNTIME / f"experiment-{index:03d}.json", e)
            run = deepcopy(
                load(TEMPLATES / f"run-{index:03d}.draft.json")["normal_fields"]
            )
            parent = NUMERIC / f"measure-{index:03d}"
            run.update(
                owner=str(ROOT),
                writer=ACTOR,
                output=str(parent / "operation"),
                data_root=str(parent / "data"),
                TMP=str(parent / "TMP"),
                owned_outputs=list(support["roots"]),
                artifact=release["artifact"],
                experiment=er,
                support=support_ref,
                limits=deepcopy(support["limits"]),
                caller_sources=callers,
                env=deepcopy(common["environment_template"]),
                child_cpu_cores=[0, 12],
                argv=[
                    release["artifact"]["path"],
                    "measure",
                    "--experiment",
                    er["path"],
                    "--experiment-sha256",
                    er["sha256"],
                ],
            )
            run["env"]["TMPDIR"] = run["TMP"]
            # Normal capture bound remains within frozen20MiB native aggregate.
            run["data"] = [
                dict(name=name, path=str(parent / "data" / file), limit_B=cap)
                for name, file, cap in [
                    ("settings", "settings.json", 1048576),
                    ("measurements", "measurements.jsonl", 8388608),
                    ("result", "result.json", 10485760),
                ]
            ]
            assert (
                sum(x["limit_B"] for x in run["data"])
                == 19922944
                <= config["output_bytes"]
            )
            assert run["approved_plan"] is None and e["canonical_plan_sha256"] == ""
            assert lc.native_cpu_cores(run) == [0, 12]
            assert lc.issued_family_upper(run, support) == 4294967296
            assert run["command_timeout_seconds"] == 900 and run["perf"] is None
            assert all(
                not os.path.lexists(run[k]) for k in ["output", "data_root", "TMP"]
            )
            lc.charged_roots(run)
            assert lc.caller_source_refs(run, e) == callers
            assert lc.measurement_argv(run, e, run["argv"]) == run["argv"]
            settings["runs"].append(run)
            blocks.append(
                dict(
                    index=index,
                    arm="OFF" if index in [0, 3, 4, 7] else "ON",
                    phase="fixeddepth" if index < 4 else "clock",
                    config=config_refs[index],
                    requests=request_refs[index],
                    experiment=er,
                    numerical=nr,
                    BUILD=release["software_manifest"],
                    image=release["artifact"],
                    support=support_ref,
                    calls=26,
                    sessions=6,
                    aggregate_nodes_upper=26000000,
                )
            )
        assert len(list(lc.operation_order(settings))) == 8
        contract = inspect.getsource(lc.measurement_evidence)
        assert all(
            k in contract
            for k in ["requested_root_aspiration", "actual_root_aspiration"]
        )
        assert all(ref(Path(r["path"])) == r for r in callers)
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)
    released = datetime.now(timezone.utc).isoformat()
    sr = save(RUNTIME / "settings.json", settings)
    job = deepcopy(load(TEMPLATES / "job.draft.json")["normal_fields"])
    job.update(
        issue=ISSUE,
        argv=[
            sys.executable,
            "-B",
            callers[0]["path"],
            "sequence",
            "--intent",
            sr["path"],
            "--sha256",
            sr["sha256"],
        ],
        resource_contract=sr["path"],
    )
    assert job["max_runtime_seconds"] == 7740 and job["end_at"] is None
    jr = save(RUNTIME / "job-template.json", job)
    forecast = save(
        RUNTIME / "holding-forecast.json",
        dict(
            status="SOURCE_BOUND_FORECAST_NOT_NATIVE_ADMISSION",
            whole_issued_B=support["whole_B"],
            frozen_native_aggregate_B_each=20971520,
            native8_B=167772160,
            normal_declared_data_B_each=19922944,
            normal_data_is_within_native_not_added=True,
            normal_LC_metadata_and_logs_allowance_B=33554432,
            serial_TMP_allowance_B=16777216,
            analysis_control_allowance_B=33554432,
            future_total_B=251658240,
            issued_future_B=260046848,
            within_issued_future=True,
            actual_whole_free_storage_serializer="Mandatory fresh normal admission; no forecast PASS",
            models_images_libs_input_payload_copy_B=0,
        ),
    )
    materialized = save(
        RUNTIME / "materialized.json",
        dict(
            status="MATERIALIZED_NOT_ADMITTED",
            issued_inputs=issued_ref,
            actual_Root_source_release=issued["release"],
            actual_software_STOP=release["actual_software_STOP"],
            protocol=controls["protocol"],
            representation_controls=ref(
                OWN / "representation-amendment-v1/normal208-controls.binding.json"
            ),
            settings=sr,
            job_template=jr,
            blocks=blocks,
            caller_sources=callers,
            phase_supports=[support_ref],
            original_request_correspondence=correspondence,
            inherited_numerical_scope="641ca structural only",
            SH_acquired_at=acquired,
            SH_released_at=released,
            source_leases_remaining=[],
            native_calls_games_RNG=0,
            typed_current_record_contract="Canonical LC measurement_evidence requires actual requested/effective root aspiration; actual rows remain future collection",
            canonical_measurement_approved_plan=None,
            canonical_plan_sha256="",
            forecast=forecast,
        ),
    )
    entry = save(
        RUNTIME / "entry-plan.json",
        dict(
            materialized=materialized,
            settings=sr,
            job_template=jr,
            state_dir=str(NUMERIC / "comparison-job-v1"),
            launch_affinity=[0, 12, 18],
            parent_accepted_seconds=7800,
            outer_command_seconds=7740,
            per_RUN_seconds=900,
            calls=208,
            aggregate_nodes_upper=208000000,
            actual_calls=0,
        ),
    )
    print(
        json.dumps(
            dict(
                materialized=materialized,
                entry_plan=entry,
                SH_released_at=released,
                forecast=forecast,
            )
        )
    )


if __name__ == "__main__":
    main()
