"""ONE original29 highestparent submit, direct Popen OUTSIDE Cycle."""

from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task_utils import ACTOR, ISSUE, OWN, ROOT, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

OUT = Path(__file__).resolve().parent
RUNTIME = OWN / "normal208-runtime-v3"


def main():
    plan = json.loads((RUNTIME / "entry-plan.json").read_text())
    assert plan["launch_affinity"] == [0, 12, 18]
    settings = json.loads(Path(plan["settings"]["path"]).read_text())
    assert ref(Path(plan["settings"]["path"])) == plan["settings"]
    assert len(settings["runs"]) == 8
    state = Path(plan["state_dir"])
    assert not state.exists() and not Path(settings["output"]).exists()
    for run in settings["runs"]:
        assert (
            run["child_cpu_cores"] == [0, 12] and run["command_timeout_seconds"] == 900
        )
        assert all(not os.path.lexists(run[k]) for k in ["output", "data_root", "TMP"])
        assert Path(run["data_root"]).parent.is_dir()
    guard_ref = ref(OUT / "pre-submit-guard-v1/result.json")
    guard = json.loads(Path(guard_ref["path"]).read_text())
    assert guard["status"] == "PASS" and guard["TMP_remaining"] == []
    assert not (OUT / "pre-submit-guard-v1/TMP").exists()
    for identity in [
        guard["controller"],
        *(c["guardian_return"]["child"] for c in guard["checks"]),
    ]:
        current = process.process_info(identity["pid"])
        assert (current is None and not Path(f"/proc/{identity['pid']}").exists()) or (
            current is not None and process.identity(current) != identity
        )
    job = json.loads(Path(plan["job_template"]["path"]).read_text())
    assert ref(Path(plan["job_template"]["path"])) == plan["job_template"]
    assert (
        job["issue"] == ISSUE
        and job["max_runtime_seconds"] == 7740
        and job["end_at"] is None
    )
    at = datetime.now(timezone.utc)
    job["end_at"] = (at + timedelta(seconds=7800)).isoformat()
    job_path = RUNTIME / "job-entry-v1.json"
    jr = save(job_path, job)
    argv = [
        "taskset",
        "-c",
        "0,12,18",
        "bash",
        "scripts/dev/project-env.sh",
        "bash",
        "scripts/dev/research-job.sh",
        "submit",
        "--config",
        str(job_path),
        "--state-dir",
        str(state),
    ]
    intent = save(
        RUNTIME / "submit-intent-v1.json",
        dict(
            at=at.isoformat(),
            argv=argv,
            config=jr,
            source=ref(Path(__file__)),
            launch_owner=process.identity(process.process_info(os.getpid())),
            source_guards_returned=guard_ref,
            authority=ref(RUNTIME / "authority-before-submit.json"),
            materialized=plan["materialized"],
            source_leases=[],
            direct_Popen_outside_Cycle=True,
            actual_calls=0,
            RPC_not_native_entry=True,
        ),
    )
    env = {**os.environ, **settings["runs"][0]["env"]}
    env.pop("TMPDIR", None)
    env["PATH"] = "/home/vscode/.local/bin:" + env["PATH"]
    env["BEADS_ACTOR"] = ACTOR
    with subprocess.Popen(
        argv, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate(timeout=60)
        code = child.wait()
    for name, raw in [("submit.stdout", stdout), ("submit.stderr", stderr)]:
        with (RUNTIME / name).open("xb") as f:
            f.write(raw)
    returned = save(
        RUNTIME / "submit-return-v1.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            intent=intent,
            returncode=code,
            directwait_reaped=True,
            pipes_closed=child.stdout.closed and child.stderr.closed,
            stdout=ref(RUNTIME / "submit.stdout"),
            stderr=ref(RUNTIME / "submit.stderr"),
            launcher_pid=child.pid,
            RPC_not_native_entry=True,
        ),
    )
    print(
        json.dumps(
            dict(
                returned=returned,
                returncode=code,
                stdout=stdout.decode(),
                stderr=stderr.decode(),
            )
        )
    )
    assert code == 0 and child.stdout.closed and child.stderr.closed


if __name__ == "__main__":
    main()
