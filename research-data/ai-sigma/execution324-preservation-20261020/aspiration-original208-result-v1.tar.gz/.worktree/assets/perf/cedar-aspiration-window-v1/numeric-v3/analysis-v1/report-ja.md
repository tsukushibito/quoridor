# 原29 root aspiration 有限比較

元208 calls/48 sessionsは全8 normal manifest/data PASS、23,486,705 nodes。保存対応確認はTrue。exit0と採用は別である。条件付き128局gateは **False**、判断は **NO_GAMES_FIXED_GATE_FAILED_OR_UNRESOLVED**。新game/CI実行0、補充・再試行・幅変更はしない。

固定深さ104件の全要求完了はTrue。OFF Searchsumは[3.971968464, 3.830159149]秒、ONは[3.98854788, 4.0369804]秒。max(ON)/min(OFF)は1.053998082835278、二反復合計ON/OFFは1.0286333008226842。これはSearch-body比でありwhole比ではない。重大root悪化は[18, 23]、固定規約の重大回帰判定はTrue。全件未完了なら全体の完了時間資格はUNKNOWN、都合のよい完了subsetやcap時間を速度改善にしない。

100ms/5ms104件のreceipt違反は0、terminal Search p95=0.0993248335秒/max=0.107315694秒。時計gate=True。root別clock完了深さmedianは改善3、悪化0。TimeLimit/NodeLimitは実完了snapshotとcapped horizonを分け、D64完了や整数深さ向上を仮定しない。main callback/terminal return/arena parent receiptは別である。

固定深さwhole-driver ON/OFF=1.0278935793678337。setup/reset/drop/journal/wholeとSearchは各表に別記し、nested時間を加算しない。5%以上＋反復分離＋whole/回帰条件による実用時間支持はFalse。ONではfail-low/high・retry/fallback費用を含む。LMRと探索窓で木・work・value・PVが変わり得るため、同一仕事やfullwidthの速度・棋力・原因・等価・無効果の認定はしない。

元26 prefixesは同3family/両手番/6chronological seriesで全predecessorを保存。stock区分2/6/6/6/6、stock0不足4を維持し、family/series/stock/初回vs継続別の分母と値はsummary.strata、全root悪化はroots.csv、全208手/PV/valuebits/work/TT/receipt/parent復元はcalls.csvとcollection refに保存した。同root fullweighted history/合法候補/stock/session対応、typed ON/OFF・namespaceとnodecap・main snapshotを保存値で照合した。後続PVの全子合法性やfault全経路を再構成していない。

CPUはOS process全thread tick（render含む）、peakRSSはprocess累積highwater。family実peak/physical NN calls/fullfees/globalactualはUNKNOWN。outer 67.71593602898065秒を一度、accepted-inclusive 69.77458秒は代替分母でnested加算0。正常旧suite/model/RAW/native/validator/RNG再演0。図=SAVED_VALUES_ONLY。

Rootへ実native+normalcollection/sourceSTOPを解析前に直接返却済み。original FAILED/NULL/cleanup-vs-disk/費UNKNOWN、pause/seal/default/model/foreign/decimal50GB、27/28独立scopeを保持する。sourceの採否・不要比較code整理・重要結論の限定確認はRootが既存Maxへ扱う。
