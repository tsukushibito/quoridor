# Original28 first fixed-depth156 (interim)

6 normal RUNの156callsを一度回収。145 DepthComplete / 11 NodeLimit UNKNOWN。全体の完了時間比はUNKNOWN。capped時間や有利な完了subsetからspeedを認定しない。

native/normal collection STOPは長い分析の前にRootへ返却済み。clock156はfresh support後の元の通常継続であり、固定深度の成績から新gateを作らない。

|mode|DepthComplete/52|NodeLimit|Search sum seconds (two RUNs)|whole_driver seconds (two RUNs)|nodes|
|---|---:|---:|---|---|---:|
|LOCAL1|52|0|[12.521877031, 12.597170016]|[12.99442733, 12.98712892]|24442848|
|LAZY2|41|11|[8.613459984, 8.933627482]|[9.267175001, 9.637143571]|33288834|
|ROOT_SPLIT2|52|0|[7.604729101, 7.64365032]|[8.364211298, 8.350287059]|24536175|

上表のSearch/wholeは観測された全callのdescriptive集計であり、未完了を含むspeedupの根拠ではない。全52対のsplit-vs-lazy action/PV差は別表に保存。main/helper/aggregate work、CPU、RSS、TT、branch wait/research、stock/first-vs-continuedを表へ保存した。

weighted history/request対応=True; 観測safety違反=0; worker error=0; illegal action/PV head=0。typed-bound等の一般的な正しさや全fault coverageをこのデータだけで証明しない。

helper requested horizonはmain completeddepthではない。branch countersは各反復のnested workであり時間分担・有用情報・saved nodesに置換しない。モデル・評価・LMR・順序・TT資格・defaultsは変更0。

clock156/normal final interpretationは未実行。games/RNG/CI0。後続physics/storage/source admissionはfresh owning normalrouteの実仕事。

{"path": "/workspaces/quoridor/.worktree/assets/perf/cedar-root-split-v1/numeric-fixed-depth156-v2/analysis-v1/summary.json", "sha256": "3c92030d207ceee92201a5cfeb98268a4653c2ac61e1c588e1277e48d487f38c", "bytes": 8951, "mode": "0644"}
