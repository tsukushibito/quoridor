# Root-only split: original312 finite comparison

元の12 RUN / 312calls / 72sessionsを一度だけ通常回収。追加calls・games・RNG・CIは0。最終native/normal collection/source STOPは本分析前にRootへ返却済み。

固定深度はLOCAL1 52/52、ROOT_SPLIT2 52/52がDepthComplete、LAZY2は41/52がDepthComplete、11/52がNodeLimit UNKNOWN。凍結したALL156完了条件を満たさず、全体の完了時間比・practical speed supportはUNKNOWN。cap時間や有利な完了subsetで救済しない。

|条件|mode|DepthComplete /52|UNKNOWN /52|Search total s|reset s|whole_driver total s|nodes|CPU s|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|fixed_depth|LOCAL1|52|0|25.119047|0.375833|25.981556|24442848|25.130|
|fixed_depth|LAZY2|41|11|17.547087|0.908318|18.904319|33288834|35.100|
|fixed_depth|ROOT_SPLIT2|52|0|15.248379|0.968809|16.714498|24536175|26.120|
|clock100ms5|LOCAL1|2|50|4.974836|0.372500|5.639520|4198323|5.000|
|clock100ms5|LAZY2|2|50|4.752245|0.919969|6.129841|8180278|9.490|
|clock100ms5|ROOT_SPLIT2|2|50|4.760485|0.975036|6.423585|7315085|7.940|

上表の全call Search/whole集計はdescriptiveであり、censoredまたは異なる選択探索を含むspeed qualificationではない。Searchはhelper quiet/drainを含む実呼出し時間、callbackはmain completed snapshot、arena parent receiptは別で今回は未計測。

clock全156: callback depth>=1・receipt<=.100 はTrue、terminal p95(linear)=0.099750532s / max=0.105140700s、凍結閾値 .110/.125 に対するsafety=True。観測correctness=True。

full weighted root historyの全12 RUN対応、main action/PV head、parent restore、allworker1M、worker error、root_split requested/effectiveを表とchecksに保存。main/helper/aggregate work/evals/TT、stock band/family/first-vs-continued、全rootのdepth/action/PV/value差、first-child/other/helper/verification/waitは別表。helper到達深度をmain完了へ混ぜない。

setup/reset/teardown/drop/wholeは別集計。TT stripes skipは観測probe/insertの範囲であり全体の正確な競合率ではない。branch nodesはwall balanceやsaved nodesではない。選択木・履歴・TT schedulingが異なるためsamework/fullwidth/因果・一般速度・強さ・同等性は主張しない。stock0の4root不足、既知book露出、OS CPU ticks/RSSの範囲を保持。

判断: 凍結基準による完了時間のpractical supportは未解決。default1を保持し、本試験からprototype採用や追加計測をしない。比較専用sourceの最終処分はRootの重要結論確認後に扱う。

実nodes=101961543; diagnostic込み=126961736; outer秒は177.310609961を各親1回のみ（nested加算0）。残枠・UNKNOWNのrefill/loan/resetは0。

次の問いは既存work/wait/researchと各rootのclock depth tradeoffの対応に限る。これは問いの記録であり、新観測・Search・source変更の自動許可ではない。

{"path": "/workspaces/quoridor/.worktree/assets/perf/cedar-root-split-v1/comparison-final-analysis-v1/summary.json", "sha256": "4c25eb929955a0b93676b897348d8678395bb122eef19ae8df01e9dc00ee3627", "bytes": 19646, "mode": "0644"}

## Matched main-depth/content facts (52 call pairs each)

|条件|比較先|split depth higher/same/lower|action差|PV差|value bits差|
|---|---|---|---:|---:|---:|
|fixed_depth|LOCAL1|0/52/0|0|12|5|
|fixed_depth|LAZY2|11/41/0|3|24|17|
|clock100ms5|LOCAL1|6/45/1|3|11|8|
|clock100ms5|LAZY2|4/45/3|3|12|7|

上の同root対応は各条件52対のdescriptive tally。clockのTimeLimit150/156はD64のUNKNOWNを保持しつつ、返ったmain completed snapshotと実測停止時計を記録する。depth差のみを採用条件にしない。

reset/teardownの実測はsession_domainsから集計済みであり、不明扱いにしない。first156暫定reportで未集計だったresetは本最終report/summaryが補完する。元の暫定記録は保持。

重要結論は凍結ALL156完了条件に従った「完了時間によるpractical support未解決」。clock safety PASSや有限のdepth/work差を一般速度・強さ・default adoptionへ拡張しない。現在defaults維持、不要prototype処分はRootの正本工程。

{"path": "/workspaces/quoridor/.worktree/assets/perf/cedar-root-split-v1/comparison-final-analysis-v1/finite-interpretation-detail-v1.json", "sha256": "c1175272bd2b61b70f477dff101edae9b73c0e99b0749b61844e21b9d0fcb477", "bytes": 3169, "mode": "0644"}
