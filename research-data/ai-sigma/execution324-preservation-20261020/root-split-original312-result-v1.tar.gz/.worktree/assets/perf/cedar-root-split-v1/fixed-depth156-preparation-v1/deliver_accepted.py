"""Deliver only the real submit receipt; do not observe the background job."""

import json
from pathlib import Path
import sys

sys.path.insert(
    0, str(Path(__file__).resolve().parents[1] / "compatible-retirement-v1")
)
from compose_v2 import ROOT, ref, save, command  # noqa: E402

own = Path(__file__).resolve().parents[1]
run = own / "fixed-depth156-runtime-v2"
receipt = json.loads((run / "submit.stdout").read_text())
r = json.loads((run / "submit-return-v1.json").read_text())
assert r["returncode"] == 0 and r["directwait_reaped"] and r["pipes_closed"]
body = own / "fixed-depth156-preparation-v1/Root-actual-accepted-v1.txt"
body.write_text(
    "SAME28 originalFIRST156 ONEhighestparent ACTUALLY accepted "
    + receipt["job_id"]
    + " at "
    + receipt["created_at"]
    + "; RPC phase starting only, actualnativeSTART UNKNOWN/no observer or statuspoll. Runtime "
    + str(own / "numeric-fixed-depth156-v2/comparison-job-v1")
    + ". Corrected immutable packetadd6fe06/N2support8725a157 librarythreads1 ONLY, originalrefusal retained/science0 before this acceptedentry. Actualcommon BUILDd0c804/image9251/HEAD34b19c9/current4a65fe072+6749/3b/ed08. Canonical measurement_config/numerical_fields/nativeCPU/caller_source_refs/measurement_argv/charged_roots passed all6 under shortSHNB released16:50:44.629578Z. N1RUN0,5 child[0,12]/CPU2; N2RUN1..4 child[0,12,14]/CPU3, all9 fullroots EACH RUN. LOCAL1-LAZY2-ROOT_SPLIT2-ROOT_SPLIT2-LAZY2-LOCAL1, fixedtimeNone/reserveabsent/root4D5/other25exact/156calls156M36sessions/TT1M/allworker1M. ONE378535936B whole/free35041280, same6 normaldata bounds. Preclockready/show sameowner/note+backup PASS; preclockguardreturned16:50:59.563808Z/directreap/handles/TMPleases[]. DirectPopen OUTSIDECycle explicit0,12,14,18 client0/reaped/pipesclosed. "
    + json.dumps(ref(run / "submit-return-v1.json"))
    + " Materialized "
    + json.dumps(ref(run / "materialized.json"))
    + ". Originalcompletionevent SAME28 owns onceALL6normalmanifest/data+census and IMMEDIATEactualnative+normalcollection/sourceSTOPtoRoot BEFORElonganalysis/admin. Finalclock156 UNISSUED untilactualendedholding/new support; no fixedperformance/review/parentACK gate. Source/current4/commonimage/libs/env/Git/Cargo/heavyIO freeze through actualnative+normalcollectionSTOP. No test/build/model/input/ELF/RAW/RNG/science replay, observer/poll/duplicate or otherOWN/Mainwrites. AllFAILED/NULL/UNKNOWNfees/defaults/models/pauses/seals/foreign/50GB/27/29/16.1 retained.\n"
)
delivery = command(
    [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--cwd",
        str(ROOT),
        "--body-file",
        str(body),
    ]
)
print(
    json.dumps(
        dict(
            accepted=receipt["job_id"],
            delivery=save(
                own / "fixed-depth156-preparation-v1/actual-accepted-delivery-v1.json",
                delivery,
            ),
        )
    )
)
