"""Consume the issued small authority records, no image/model/input payload."""

import hashlib
import json
from pathlib import Path
import stat

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
AUTH = (
    ROOT
    / ".artifacts/research-team/integration324/cedar-root-split-v1/fixed-depth156-entry-v1"
)


def ref(path):
    path = Path(path)
    s = path.lstat()
    body = path.read_bytes()
    assert stat.S_ISREG(s.st_mode) and len(body) < 1024**2
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(s.st_mode):04o}",
    )


def document(expected):
    assert ref(expected["path"]) == expected
    return json.loads(Path(expected["path"]).read_text())


def main():
    packet_ref = ref(AUTH / "issued-inputs.json")
    assert (
        packet_ref["sha256"]
        == "d31d3a2f266b2cf3350d21a5a0cc62e2e7e66d4e987208ec25444468bc7a0094"
        and packet_ref["bytes"] == 3109
        and packet_ref["mode"] == "0644"
    )
    packet = document(packet_ref)
    release = document(packet["release"])
    supports = [document(r) for r in packet["phase_supports"]]
    capacity = document(packet["capacity"])
    manifest = document(release["software_manifest"])
    print("RELEASE", json.dumps(release, indent=2))
    for support in supports:
        print("SUPPORT", json.dumps(support, indent=2))
    print("CAPACITY", json.dumps(capacity, indent=2))
    print(
        "BUILD_METADATA",
        json.dumps(
            {k: manifest.get(k) for k in ["status", "artifact", "env", "tools"]},
            indent=2,
        ),
    )
    cached = dict(
        issued_ref=packet_ref,
        issued=packet,
        release=release,
        supports=supports,
        capacity=capacity,
        manifest=manifest,
    )
    with (OUT / "authority-metadata.json").open("x") as f:
        json.dump(cached, f, indent=2)
        f.write("\n")


if __name__ == "__main__":
    main()
