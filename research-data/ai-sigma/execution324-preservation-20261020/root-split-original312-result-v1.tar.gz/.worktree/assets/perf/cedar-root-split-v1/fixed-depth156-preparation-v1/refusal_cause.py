"""Capture only the maintained admission predicate responsible for the refusal."""

import fcntl
import json
import os
from pathlib import Path

root = Path("/workspaces/quoridor")
own = root / ".worktree/assets/perf/cedar-root-split-v1"
a = json.loads(
    (own / "fixed-depth156-preparation-v1/authority-metadata.json").read_text()
)
fd = os.open(
    root / ".artifacts/rust-migration/target/arena-software-writer.lock",
    os.O_RDONLY | os.O_NOFOLLOW,
)
try:
    fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
    lines = (
        Path(a["release"]["current_four_callers"][0]["path"]).read_text().splitlines()
    )
    text = "\n".join(f"{i + 1}: {lines[i]}" for i in range(2185, 2225))
finally:
    fcntl.flock(fd, fcntl.LOCK_UN)
    os.close(fd)
print(text)
