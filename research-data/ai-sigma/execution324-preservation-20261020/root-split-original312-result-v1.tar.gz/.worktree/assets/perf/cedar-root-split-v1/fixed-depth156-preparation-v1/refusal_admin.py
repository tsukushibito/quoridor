"""Record the actual causal pre-native refusal and preserve the shared backup."""

import json
from pathlib import Path
import sys

sys.path.insert(
    0, str(Path(__file__).resolve().parents[1] / "compatible-retirement-v1")
)
from compose_v2 import save, command  # noqa: E402

own = Path(__file__).resolve().parents[1]
out = own / "fixed-depth156-preparation-v1"
issue = "quoridor-4lc.324.28"
actor = "codex:01a11004-79f3-7c20-872c-432a2c347664"
records = []
for name, args in [("ready", ["ready", "--json"]), ("show", ["show", issue, "--json"])]:
    r = command(["bash", "scripts/dev/beads.sh", *args])
    records.append(save(out / ("refusal-admin-" + name + ".json"), r))
    if name == "show":
        data = json.loads(r["stdout"])[0]
        assert data["assignee"] == actor and data["status"] == "in_progress"
note = (
    "Original28 first156 pre-native actualnormal binding refused at RUN1 support resources.threads2 versus maintained native_cpu_cores resources.threads1 library-thread contract. CPU3/search2/[0,12,14] scientific team unchanged; RUN0 accepted nativeCPU[0,12]. Original failed namespace/trace retained; actual calls0/submits0, no native retry or source/validator change. Root sent exact causal immutable support correction request with actual bindSTOP16:48:50.543091Z and predicateSHNBreleasedSTOP16:49:04.612146Z, deliveryguardSTOP16:49:30.537685Z. Full9roots propagated everyRUN. Genuine common BUILDd0c804/image9251, first156/156M36sessions/order/root4D5/otherdepths/caps exact; final156 unissued. Only ordinary downstream submit/preclock wrappers prepared; awaiting corrected read-only authority input, no fake support or admission. Evidence: "
    + str(out / "actual-binding-refusal-v1.json")
)
for name, args in [
    ("note", ["update", issue, "--append-notes", note]),
    ("backup", ["backup", "sync", "--json"]),
]:
    records.append(
        save(
            out / ("refusal-admin-" + name + ".json"),
            command(["bash", "scripts/dev/beads.sh", *args]),
        )
    )
print(
    json.dumps(dict(issue=issue, sameowner=True, status="in_progress", records=records))
)
