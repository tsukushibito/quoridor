"""Persist and deliver the concrete pre-native authority-field refusal."""

import json
from pathlib import Path
import sys

sys.path.insert(
    0, str(Path(__file__).resolve().parents[1] / "compatible-retirement-v1")
)
from compose_v2 import ROOT, ref, save, command  # noqa: E402

own = Path(__file__).resolve().parents[1]
a = json.loads(
    (own / "fixed-depth156-preparation-v1/authority-metadata.json").read_text()
)
report = save(
    own / "fixed-depth156-preparation-v1/actual-binding-refusal-v1.json",
    dict(
        issue="quoridor-4lc.324.28",
        status="PRE_NATIVE_CAUSAL_SUPPORT_REFUSAL",
        actual_calls=0,
        submitted_jobs=0,
        original_packet=a["issued_ref"],
        original_N2_support=a["issued"]["phase_supports"][1],
        error="Refused: actual issued native physical-core family, not corpus/source-only authority",
        exact_cause="N2 issued resources.threads=2; canonical native_cpu_cores requires resources.threads==1 (library threading), separately CPU3 and actual search_threads2/team[12,14] remain correct.",
        normal_predicate=ref(own / "fixed-depth156-cause-guard-v1/predicate.log"),
        failed_binding=ref(own / "fixed-depth156-bind-guard-v1/result.json"),
        failed_trace=ref(own / "fixed-depth156-bind-guard-v1/bind.log"),
        actual_predicate_reader_STOP=ref(
            own / "fixed-depth156-cause-guard-v1/result.json"
        ),
        source_leases=[],
        required_causal_derivative="Root immutable N2 support resources.threads2->1 only, preserve original support/refusal. No native/source/validator/science change. Then author fresh namespace finalbind and ONE original156 submit.",
        full_union_per_RUN=True,
        RUN0_native_CPU_passed=True,
        RUN1_failed_before_submit=True,
    ),
)
body = own / "fixed-depth156-preparation-v1/Root-causal-refusal-v1.txt"
body.write_text(
    "SAME28 originalfirst156 actualnormalbind refusal BEFORE any submit/native/Search (science0). RUN0 canonical nativeCPU[0,12] PASS; RUN1 refused actual issued native physical-core family. Exact canonical native_cpu_cores line2203 requires resources.threads==1; issued N2 support f2fe1d74 resources.threads=2 (search_threads2 and CPU3/team[0,12,14] otherwise correct). Please issue immutable causal N2 resources.threads2->1 derivative + packet; no source/validator/science changes, original refs/refusal preserved. Author cannot mutate read-only Root authority. All9 fullroots propagated eachRUN, genuine d0c804/9251 commonimage. Failedbind actualSTOP16:48:50.543091Z; exact predicate shortSHNB actualreleasedSTOP16:49:04.612146Z. No native entry/job/start/observer/retry. Fresh normalbinding namespace follows genuine corrected ref, then ONE original156 highestparent; no ACK gate. Concrete receipt "
    + json.dumps(report)
    + "\n"
)
r = command(
    [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--cwd",
        str(ROOT),
        "--body-file",
        str(body),
    ]
)
print(
    json.dumps(
        dict(
            report=report,
            delivery=save(
                own
                / "fixed-depth156-preparation-v1/Root-causal-refusal-delivery-v1.json",
                r,
            ),
        )
    )
)
