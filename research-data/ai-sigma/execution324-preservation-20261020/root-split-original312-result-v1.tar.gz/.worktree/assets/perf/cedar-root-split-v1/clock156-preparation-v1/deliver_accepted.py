"""Deliver only the real submit receipt; do not observe the background job."""

import json
from pathlib import Path
import sys

sys.path.insert(
    0, str(Path(__file__).resolve().parents[1] / "compatible-retirement-v1")
)
from compose_v2 import ROOT, ref, save, command  # noqa: E402

own = Path(__file__).resolve().parents[1]
run = own / "clock156-runtime-v1"
receipt = json.loads((run / "submit.stdout").read_text())
r = json.loads((run / "submit-return-v1.json").read_text())
assert r["returncode"] == 0 and r["directwait_reaped"] and r["pipes_closed"]
body = own / "clock156-preparation-v1/Root-actual-accepted-v1.txt"
body.write_text(
    "SAME28 ORIGINAL FINALclock156 ONEhighestparent ACTUALLY accepted "
    + receipt["job_id"]
    + " at "
    + receipt["created_at"]
    + "; RPC phase starting only/nativeSTART UNKNOWN, no observer/statuspoll/startprobe. Runtime "
    + str(own / "numeric-clock156-v1/comparison-job-v1")
    + ". Genuine SAMEcommon d0c804/9251/HEAD34b19c9/current4a65fe072+6749/3b/ed08. Fresh issued19a7d084/N1ff642e9d/N27995e133/supportlibrarythreads1 both, nativeCPU2vs3. "
    "Exact frozen clock6 global6..11 LOCAL1-LAZY2-ROOT_SPLIT2-ROOT_SPLIT2-LAZY2-LOCAL1/all26fullhistory+predecessors/6chronologicalsessions each/156calls156M36sessions/D64/100ms authority/explicit5reserve/allworker1M/TTtotal1M/Cedar35cbb-eb0/Current100%/Control/currentLMR/PVS/path_tail/perf0. "
    "Canonical factory/measurement_config/numerical_fields/native_cpu_cores/caller_source_refs/argv/charged_roots all6 PASS, shortSHNB released16:56:38.899417Z. All9fullroots EACHowned_outputs, one378535936B/free18575360/joint32MiB analysis-control across BOTHphases, not additive oldgrant. "
    "Preclockready/show sameowner/note+backup PASS; guardreturned16:56:59.530635Z/directreap/handles/TMPleases[]. DirectPopenOUTSIDECycle launch0,12,14,18/client0/reaped/pipesclosed. Submitreceipt "
    + json.dumps(ref(run / "submit-return-v1.json"))
    + " materialized "
    + json.dumps(ref(run / "materialized.json"))
    + ". Originalcompletion SAME28 onceALL6normalmanifest/data+census and IMMEDIATEactualnative+normalcollection/sourceSTOPtoRoot BEFORElonganalysis/admin. "
    "First156 exhausted82267857nodes/145DepthComplete+11NodeLimitUNKNOWN (all11LAZY2), all156retained; wholecompletedtime qualificationUNKNOWN/no favourable subset/cap-speedup/refill. Firstpartial boundedanalysis exists (newlintunusedimportfailedBEFOREbody thenfixed/runonce), finalanalysis awaitsclockSTOP; notentrygate. "
    "Afterthis final156 original312/312M72sessions (combined338 withdiagnostic26) exhausted/no furtherstage/games/RNGCI/pilot/newgrant/defaultadoption. "
    "Root source/Git/Cargo/current4/commonimage/libs/env/heavyIO freeze through actualfinalnative+normalcollectionSTOP; no futurehostquiet. All oldFAILED/NULL/UNKNOWNfees/default1/rootSplitOFF/models/pauses/seals/foreign/50GB/27/29/16.1 retained.\n"
)
delivery = command(
    [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--cwd",
        str(ROOT),
        "--body-file",
        str(body),
    ]
)
print(
    json.dumps(
        dict(
            accepted=receipt["job_id"],
            delivery=save(
                own / "clock156-preparation-v1/actual-accepted-delivery-v1.json",
                delivery,
            ),
        )
    )
)
