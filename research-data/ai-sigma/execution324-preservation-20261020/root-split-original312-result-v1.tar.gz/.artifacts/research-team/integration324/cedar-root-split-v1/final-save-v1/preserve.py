"""Preserve the ended original312 and genuine build without scientific replay."""

import importlib.util
import json
from pathlib import Path


ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    loader = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(helper)
    helper.DEST = DEST
    paths = []
    for name in (
        "numeric-fixed-depth156-v2",
        "numeric-clock156-v1",
        "fixed-depth156-preparation-v1",
        "fixed-depth156-runtime-v2",
        "fixed-depth156-bind-guard-v1",
        "fixed-depth156-cause-guard-v1",
        "clock156-preparation-v1",
        "clock156-runtime-v1",
        "comparison-final-analysis-v1",
        "final312-analysis-guard-v1",
        "final312-analysis-guard-v2",
        "final312-finalize-guard-v2",
    ):
        paths += helper.files_below(OWN / name)
    for name in (
        "prototype-software-v5/build-runtime-v2",
        "prototype-software-v5/operation-release",
        "prototype-software-v5/release-failure-collection-v1",
        "prototype-software-v5/release-failure-collection-v2",
        "prototype-software-v6",
        "fixed-depth156-entry-v1",
        "clock156-entry-v1",
        "final-clock-STOP-intake-v1",
    ):
        paths += helper.files_below(BASE / name)
    # These are immutable data and returned helper records. Notification-only
    # logs/state and giant duplicated issue snapshots remain in local custody.
    skipped_names = {
        "notification.json",
        "supervisor.log",
        "state.json",
        "own-ready.json",
        "own-show.json",
        "Root-update.json",
        "Root-note-update.json",
    }
    paths = [
        path
        for path in paths
        if path.name not in skipped_names
        and not path.name.startswith("Root-current-metadata")
        and not path.name.startswith("Root-metadata")
    ]
    paths += [OUT / "preserve.py", OUT / "preservation-allocation.json"]
    name = "root-split-original312-result-v1.tar.gz"
    helper.write_archive(
        name,
        paths,
        "Original genuine common BUILDd0c804/image9251 metadata, failed1e85 preserved, actual normal finalize/sourceSTOP; original312 in two156 lifetimes plus pre-native supportthreads refusal and exact correction. All12 normal data/measurements, saved analysis/censoring/work/setup/reset/whole and actualSTOP preserved opaquely. No native/model/RAW decoder/validator/RNG/test/build/scientific analysis replay; model/image/input/library/cache/DB/sealed payloads excluded. Root source34b19c9 in Git. Important finite review and purpose-end retirement pending at this save boundary.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    result = dict(
        issue="quoridor-4lc.324.28",
        status="ORIGINAL312_EXHAUSTED_COMPLETED_TIME_QUALIFICATION_UNKNOWN_CLOCK_SAFETY_OBSERVED_PASS",
        comparison_source="34b19c9a90b0a44566a0424e6c891979cab03c26",
        build="d0c804cd20714750eedf799267bfdbc773675007930d1818c00e1ec233e5b3bb",
        image="9251ae6229414dc29450b39981752eda3cc09f539ccef6f67203e76dc2a8b046",
        calls=312,
        sessions=72,
        actual_nodes_once=101961543,
        with_original_diagnostic=dict(calls=338, actual_nodes_once=126961736),
        fixed_depth=dict(
            LOCAL1="52DepthComplete",
            LAZY2="41DepthComplete+11NodeLimitUNKNOWN",
            ROOT_SPLIT2="52DepthComplete",
            frozen_all156_complete=False,
            completed_time_practical_qualification="UNKNOWN; no favourable subset or cap-time speedup",
        ),
        clock=dict(
            each_mode="50TimeLimitUNKNOWN+2DepthComplete",
            main_callback_safety=True,
            terminal_p95_linear_seconds=0.09975053175,
            terminal_max_seconds=0.1051407,
            split_vs_LOCAL1_depth="6higher/45equal/1lower of52 pairs",
            split_vs_LAZY2_depth="4higher/45equal/3lower of52 pairs",
            qualification="Finite returned depth/work and safeclock observations, not requestedD64 completion, samework throughput or strength",
        ),
        disposition="Keep default1/rootSplitOFF; no prototype adoption or extra calls/games/CI. Important bounded result review and purpose-end canonical cleanup remain separate at save time.",
        limitations="Exposed26roots/3families/6warm samecolour series/stock0 shortfall; selective work/PV/value/scheduling, not independent unseen IID/causal/equivalence/general speed or strength. Process CPU/RSS scopes do not establish physicalNN/family peak/fullfees/globalactual.",
        outer_seconds_once=177.31060996104497,
        nested_added=0,
        prior_failures="All FAILED/NULL/masks/UNKNOWNfees and originalrefusals retained; no retroPASS/refill/refund/lending",
        archive={
            key: manifest[key]
            for key in (
                "archive",
                "bytes",
                "sha256",
                "full_stream_restore_hash_mode_verified",
            )
        },
    )
    with (DEST / "root-split-original312-result-v1.json").open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(result["archive"]))


if __name__ == "__main__":
    main()
