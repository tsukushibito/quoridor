"""Retain failed build facts and reassign only actual stopped Root temp capacity."""

import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def main():
    loader = importlib.util.spec_from_file_location(
        "current_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    outer = json.loads((BASE / "build-runtime-v2/result.json").read_bytes())
    state = json.loads((BASE / "build-runtime-v2/state.json").read_bytes())
    proc = json.loads(
        (
            BASE / "operation-release/root-split-common-genuine-release.process.json"
        ).read_bytes()
    )
    spec = json.loads((BASE / "build-intent-release.json").read_bytes())
    output = (BASE / "build-runtime-v2/output.log").read_text()
    partial = json.loads(output.split("lifecycle partial facts: ", 1)[1])
    assert outer["job_id"] == "1e85afd5-5ce4-4334-9482-d82f761d5a07"
    assert (
        outer["exit_code"] == 1
        and outer["direct_child_reaped"]
        and outer["cleanup_complete"]
        and outer["remaining"] == []
    )
    assert (
        partial["status"] == "FAILED"
        and partial["checks"][-1]["guardian_return"] is None
    )
    assert partial["primary"]["message"] == "owned allocation limit"
    assert proc["reason"] == "Refused" and proc["exit_code"] == -15
    assert (
        proc["direct_child_reaped"]
        and proc["cleanup_complete"]
        and proc["remaining"] == []
        and proc["handle_closes_complete"]
    )
    assert not (BASE / "operation-release/candidate.json").exists()
    with (OUT / "original-partial-failed-facts.json").open("x") as f:
        json.dump(partial, f, indent=2)
        f.write("\n")
    members = [
        proc["child"],
        state["child"],
        *[v for v in state["launch"].values() if isinstance(v, dict) and "pid" in v],
    ]
    for row in partial["checks"][:-1]:
        lc.settled(row["guardian_return"])
        members.append(row["guardian_return"]["child"])
    known = []
    for member in members:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        if member == state["supervisor"] and fresh == lc.process.identity(member):
            continue
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    with lc.lease():
        lc.source_check(spec["source"])
        assert not Path(spec["TMP"]).exists()
        target = Path(spec["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker == dict(
            writer=spec["writer"],
            target=str(target),
            support_sha256=spec["support"]["sha256"],
        )
        seen = set()
        roots = [
            dict(path=str(p), allocated_B=lc.allocated(p, seen=seen))
            for p in lc.charged_roots(spec)
        ]
        binary = target / "release/quoridor-runner"
        assert binary.is_file() and not binary.is_symlink()
        block = os.statvfs(target).f_frsize
        copy_B = ((binary.stat().st_size + block - 1) // block) * block
    cache = Path("/tmp/quoridor324-prettier-save-cache")
    assert (
        cache.is_dir()
        and not cache.is_symlink()
        and cache.resolve() == cache
        and cache.stat().st_uid == os.getuid()
    )
    # npm owns symlink executables in this stopped Root-only cache.
    # Count symlink inodes without following; do not relax scientific namespace checks.
    cache_seen = set()
    retired_B = 0
    for directory, dirs, files in os.walk(cache, followlinks=False):
        for p in [
            Path(directory),
            *[Path(directory) / n for n in files],
            *[Path(directory) / n for n in dirs if (Path(directory) / n).is_symlink()],
        ]:
            info = p.lstat()
            key = (info.st_dev, info.st_ino)
            if key not in cache_seen:
                cache_seen.add(key)
                retired_B += info.st_blocks * 512
        dirs[:] = [n for n in dirs if not (Path(directory) / n).is_symlink()]
    shutil.rmtree(cache)
    assert not cache.exists()

    def git(*args):
        p = subprocess.run(
            ["git", "--no-optional-locks", *args],
            cwd=ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
            timeout=30,
        )
        return p.stdout.decode()

    before = "e9681058"
    publication = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"
    changed = git(
        "diff", "--name-only", before, "HEAD", "--", str(publication)
    ).splitlines()
    pub_B = sum(lc.allocated(ROOT / p) for p in changed)
    objects = {
        line.split()[0]
        for line in git("rev-list", "--objects", before + "..HEAD").splitlines()
    }
    common = Path(git("rev-parse", "--git-common-dir").strip())
    if not common.is_absolute():
        common = ROOT / common
    object_B = 0
    missing = []
    for oid in objects:
        p = common / "objects" / oid[:2] / oid[2:]
        if p.is_file():
            object_B += p.stat().st_blocks * 512
        else:
            missing.append(oid)
    assert not missing
    ordinary = pub_B + object_B
    held = sum(r["allocated_B"] for r in roots)
    result = dict(
        status="ACTUAL_GENUINE_BUILD_STORAGE_FAILURE_SOURCE_STOP_CACHED_BINARY_UNQUALIFIED",
        original_job=lc.artifact_ref(BASE / "build-runtime-v2/result.json"),
        original_failed_process=lc.artifact_ref(
            BASE / "operation-release/root-split-common-genuine-release.process.json"
        ),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        original_partial_status="FAILED, guardianNULL, process_cleanupfalse, TMPsecondary, no candidate/manifest; original logs/partialfacts retained, never retroPASS",
        known_exact_fresh_absence=known,
        affected_fullroot_union_once=roots,
        affected_fullroot_union_allocated_B_once=held,
        cache_retained="Stopped same-source standard Cargo cache includes binary; compiler output build-finished true is not a qualified image because process exit-15/guardian refused",
        prospective_private_copy_B=copy_B,
        Root_formatter_cache_retired=dict(
            path=str(cache),
            allocated_B=retired_B,
            scope="Only Root-owned temporary npm/Prettier cache, last direct formattercommand returned before currentbuild; no model/RAW/source/result/image/FAILED deletion",
        ),
        ordinary_save_git_point=dict(
            base_git=before,
            new_publication_B=pub_B,
            new_loose_git_objects_B=object_B,
            packed_or_missing_object_ids=missing,
            actual_known_B=ordinary,
            scope="Only directed changed publication paths and exactnew looseGitobjects; no repository/raw/global capacitywalk",
        ),
        prospective_common_software=dict(
            base_known_cover_B=49608672256,
            whole_B=361 * 1024**2,
            ordinary_envelope_B=12 * 1024**2,
            known_cover_upper_B=49608672256 + (361 + 12) * 1024**2,
            required_held_plus_copy_B=held + copy_B,
            ordinary_fits=ordinary <= 12 * 1024**2,
            copy_and_512KiB_margin_fit=held + copy_B + 512 * 1024 <= 361 * 1024**2,
        ),
        source_leases=[],
        TMP=[],
        remaining=[],
        host_future_quiet=False,
        globalactual_fullfees_later_tails="UNKNOWN",
        next="If actualpositive capacity fits, new normal unfinished software entry uses unchangedsource/opt3/LTO=false and stoppedCargo cache; original FAILED133.0585s immutable, no tests/solver/native/RAW/RNG replay or sciencegrant.",
    )
    with (OUT / "completion-and-STOP.json").open("x") as f:
        json.dump(result, f, indent=2)
        f.write("\n")
    (BASE / "release-failure-collection-v1/guard-TMP").rmdir()
    print(
        json.dumps(
            dict(
                status=result["status"],
                held_B=held,
                copy_B=copy_B,
                ordinary_B=ordinary,
                allocation=result["prospective_common_software"],
            )
        )
    )


if __name__ == "__main__":
    main()
