"""Issue only original28 fixed-depth156 with the genuine common comparison image."""

import datetime
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1"
MIB = 1024**2


def load(name, path):
    loader = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


def main():
    helper = load(
        "existing_metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py",
    )
    lc = load("current_normal", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helper.ref

    def save(name, value):
        p = OUT / name
        with p.open("x") as f:
            json.dump(value, f, indent=2)
            f.write("\n")
        return ref(p)

    stop_path = (
        BASE / "prototype-software-v6/release-collection-v1/completion-and-STOP.json"
    )
    stopped = json.loads(stop_path.read_bytes())
    assert (
        stopped["status"]
        == "ACTUAL_GENUINE_RELEASE_BUILD_NORMAL_FINALIZE_PASS_AND_SOURCE_STOP"
    )
    assert (
        stopped["source_leases"] == stopped["remaining_owned"] == stopped["TMP"] == []
    )
    manifest = json.loads(helper.checked(stopped["software_manifest"]).read_bytes())
    assert manifest["status"] == "PASS" and manifest["artifact"] == stopped["artifact"]
    assert manifest["source"]["commit"] == "34b19c9a90b0a44566a0424e6c891979cab03c26"
    assert manifest["env"]["CARGO_PROFILE_RELEASE_LTO"] == "false"
    controls = ref(
        OWN
        / "comparison-control-preparation-v1/two-lifetime-v1/group-correspondence.json"
    )
    assert (
        controls["sha256"]
        == "e14df29a7954f2cd0f2b6fb12625c6274baf01ea947408a6d38165b1226753ec"
    )
    original = ref(OWN / "finite-protocol-v1.json")
    assert (
        original["sha256"]
        == "c87fbc687e812e2975b6f5c542f3a36023375f5d4068c56d471cad2c9abb73bd"
    )
    depth = ref(
        OWN / "comparison-control-preparation-v1/depth-correspondence-amendment.json"
    )
    assert (
        depth["sha256"]
        == "951b4232bf0a47df30cc8bbaf49e1f717a1e9dcdc34a7a663739784c426f674e"
    )
    with lc.lease(shared=True):
        for caller in stopped["current_callers"]:
            assert ref(Path(caller["path"])) == caller
        lc.source_check(manifest["source"])
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_QUALIFIED_COMMON_ROOT_SPLIT_COMPARISON_IMAGE_SOURCE_STOP",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                source=manifest["source"],
                current_four_callers=stopped["current_callers"],
                software_manifest=stopped["software_manifest"],
                artifact=stopped["artifact"],
                actual_software_STOP=ref(stop_path),
                fixed_controls=controls,
                original_protocol=original,
                root4_depth_correspondence=depth,
                source_SH_NB_acquired_released=True,
                source_leases_remaining=[],
                compiler="Same genuinely qualifiedopt3/codegen1/LTO=false image for LOCAL1/LAZY2/ROOT_SPLIT2 in bothgroups; no oldimage alias/parity claim. Root source/config/test repairs are committed34b19c9.",
                qualification="OriginalAI6/Python1 source NN0 scope reused; actualnewRunner2+affectedClippy warning0, actualnormalCargo/privatecopy/finalizePASS. RuntimeCPU/normalfactory/numerical/currentrefs/cancel/source/env/serializer still owningentry.",
                freeze="Same source/current4/image/libs/env/HEAD34b19c9 across bothoriginalgroups; no build/heavyIO during actualtiming. Actual sourceSTOP releases individual reader lifetime, not futurequiet; phase2 no newperformance/ACK gate.",
                evaluation="UNENTERED",
                host_future_quiet=False,
            ),
        )
    software_intent = json.loads(
        (BASE / "prototype-software-v6/build-intent-release.json").read_bytes()
    )
    software_support = json.loads(
        helper.checked(software_intent["support"]).read_bytes()
    )
    roots = software_support["storage_budget"]["roots"]
    ended = stopped["affected_point_after"]
    whole = 361 * MIB
    ordinary = 12 * MIB
    future = 192 * MIB
    margin = whole - ended["allocated_B"] - future
    assert margin >= 8 * MIB
    base_cover = software_support["storage_budget"]["prior_base_known_cover_B"]
    assert base_cover + whole + ordinary <= 50000000000
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize > whole
    capacity = save(
        "capacity-and-holding.json",
        dict(
            roots=roots,
            actual_ended_point_once=ended,
            actual_ended_point_source=ref(stop_path),
            future_B=future,
            future_parts_B=dict(
                native_capture_included=120 * MIB,
                normal_metadata=12 * MIB,
                serial_TMP=16 * MIB,
                logs=8 * MIB,
                saved_analysis_controls=32 * MIB,
                new_binding_controls=4 * MIB,
            ),
            whole_B=whole,
            forecast_margin_B=margin,
            prior_base_known_cover_B=base_cover,
            separate_new_ordinary_save_Git_envelope_B=ordinary,
            ordinary_actual_point=ref(
                BASE
                / "prototype-software-v5/release-failure-collection-v2/completion-and-STOP.json"
            ),
            known_cover_upper_B=base_cover + whole + ordinary,
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            scope="Reuse exact ended fullroot union once including genuineimage and allpriorretention. Newfuture192MiB includes actualcurrentbinding/controlgrowth; normal runtime enforces actualfullroots. No oldholding walk/globalinventory/copies/oldquota refund/lending.",
            globalactual_later_tails_fullfees="UNKNOWN",
        ),
    )
    supports = []
    for count, indices in [(1, [0, 5]), (2, [1, 2, 3, 4])]:
        search = [12] if count == 1 else [12, 14]
        child = [0, *search]
        resources = dict(
            search_cpu_cores=search,
            total_search_threads=count,
            native_threads=count,
            threads=count,
            worker_cpu=12,
            main_guardian=0,
            outer_guardian=18,
            launch_affinity=[0, 12, 14, 18],
            native_child_cpu_cores=child,
            CPU=len(child),
            family_B=4 * 1024**3,
            family_RAM_B=4 * 1024**3,
            controller_B=1610612736,
            controller_RAM_B=1610612736,
            native_B=2684354560,
            host_reserve_B=4 * 1024**3,
            GPU=0,
            controller_included=True,
        )
        limits = dict(
            worker_cpu=12,
            guardian_cpu=0,
            family_B=4 * 1024**3,
            controller_B=1610612736,
            host_reserve_B=4 * 1024**3,
            owned_B=whole,
            free_B=margin,
            log_B=MIB,
        )
        supports.append(
            save(
                f"phase-support-N{count}.json",
                dict(
                    issue="quoridor-4lc.324.28",
                    status="ISSUED_ORIGINAL28_FIXED_DEPTH156_OF312_ONE_SHARED_LIFETIME",
                    shared_phase="ORIGINAL28_FIXED_DEPTH156",
                    fixed_protocol=original,
                    fixed_controls=controls,
                    root4_depth_correspondence=depth,
                    current_source_adoption=release,
                    actual_source_STOP=release,
                    actual_software_STOP=ref(stop_path),
                    whole_B=whole,
                    roots=roots,
                    owned_B=whole,
                    free_B=margin,
                    storage_budget=dict(whole_B=whole, roots=roots),
                    capacity_basis=capacity,
                    resources=resources,
                    limits=limits,
                    total_original_calls=312,
                    total_original_nodes=312000000,
                    phase_calls_shared=156,
                    phase_nodes_shared=156000000,
                    applies_only_local_RUN_indices=indices,
                    calls_for_this_CPU_variant=26 * len(indices),
                    per_call_aggregate_nodes=1000000,
                    TOTAL_TT_entries=1048576,
                    serial_runs_shared=6,
                    sessions_shared=36,
                    RUN_timeout_s=900,
                    parent_accepted_s=6000,
                    parent_command_s=5940,
                    cleanup_margin_s=60,
                    readonly_images_models_copy_B=0,
                    native_aggregate_B_each=20 * MIB,
                    perf_RAW_B=0,
                    allocation="Original26/fullpredecessors/6chronologicalseries/correctedroot4D5-other25unchanged/Current100%/Cedar35cbb-eb0/Control/baselineLMR/PVS/TTtotal1M/path_tail/perf0. FixeddepthtimeNone/reserveABSENT. LOCAL1-LAZY2-ROOT_SPLIT2-ROOT_SPLIT2-LAZY2-LOCAL1, all1Maggregatepercall. Root_split absentLOCAL1/LAZY2,trueonlyROOT_SPLIT2. No scope/config/selection/refill/game/RNG/default change.",
                    normal_remaining_inputs="Fresh maintainedfactory/numerical_fields/currentcaller/runtime/source/env/realversionedlibrary/inputrefs, actualphysicalSMT-peer/RAM/host4/pausecancel/fullroot/free/serializer/origin/end_at/cancelcleanup at owningentry. Propagate entire declaredroots into each RUN owned_outputs so actualguard counts sameoneunion.",
                    shared_ceiling="Both CPUvariant supports are views of ONE156call/156M phase, not additive grants. N1RUN0,5=52calls; N2RUN1..4=104calls. No per-support duplication/reset/lending.",
                    timing="Source/currentfour/commonimage/libs/env/GitHEAD34b19c9 fixed acrossbothgroups; onefairtiming lifetime atatime, build/heavyIO held through actualnative+normalcollectionSTOP.",
                    later_stage="Clock156 separately requires genuine phase1actualSTOP and fresh endedholding/support within original312. Ordinarycontinuation unless real safety/correctness/refusal; no newly invented significance/promising/reviewer/admin/ACK gate. No pre-issued second support.",
                    science_refund_lending_reset=0,
                    pauses_seals_models_defaults_foreign_FAILED_UNKNOWN="PRESERVED",
                ),
            )
        )
    issued = save(
        "issued-inputs.json",
        dict(
            release=release,
            phase_supports=supports,
            capacity=capacity,
            controls=controls,
            original_protocol=original,
            root4_depth_correspondence=depth,
            original_controls=ref(
                OWN / "comparison-control-preparation-v1/binding.json"
            ),
            first_group_settings=ref(
                OWN
                / "comparison-control-preparation-v1/two-lifetime-v1/fixed-depth-settings.draft.json"
            ),
            first_group_job=ref(
                OWN
                / "comparison-control-preparation-v1/two-lifetime-v1/fixed-depth-job.draft.json"
            ),
            first_group_calls=156,
            total_comparison_calls=312,
            usage_before_submit=0,
            remaining_clock156_support=None,
            evaluation="UNENTERED",
            source_leases=[],
        ),
    )
    print(
        json.dumps(
            dict(
                status="ISSUED_ORIGINAL28_FIRST_FIXED_DEPTH156",
                issued=issued,
                release=release,
                whole_B=whole,
                margin_B=margin,
                ended_point_B=ended["allocated_B"],
            )
        )
    )


if __name__ == "__main__":
    main()
