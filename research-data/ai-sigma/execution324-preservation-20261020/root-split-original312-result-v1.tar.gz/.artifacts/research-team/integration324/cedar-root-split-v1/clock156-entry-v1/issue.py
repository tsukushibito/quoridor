"""Issue the already-fixed second156 using the first phase's actual STOP."""

import copy
import hashlib
import json
import os
from pathlib import Path
import stat


ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1"
MIB = 1024**2


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def checked(path, sha):
    assert ref(path)["sha256"] == sha
    return json.loads(path.read_bytes())


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def main():
    prior_dir = BASE / "fixed-depth156-entry-v1"
    prior = checked(
        prior_dir / "support-threads-correction-v2/issued-inputs.json",
        "add6fe06c1df2a6ddc62e38d73c71559c35b5f8670fed2b8e89e4f41182368a9",
    )
    collected = OWN / "numeric-fixed-depth156-v2/collection-v1"
    stop = checked(
        collected / "returned-collection-STOP.json",
        "5d31dea4b725b0c40432d90b246ac63e0f8f9798290a5302cf7917f685e40679",
    )
    holding = checked(
        collected / "retained-holding.json",
        "baea05193102e7500427fc042423c3c89fef3b0334dfbb0b58c9d9eb31a9ebbc",
    )
    summary = checked(
        collected / "summary.json",
        "e2b371de6cef5fec02346c2cbbe4bc0f7a80a1548340f2da1c0971278213590f",
    )
    assert stop["TMP"] == stop["source_leases"] == stop["native_remaining"] == []
    assert stop["Main_reader"] is False
    assert all(row["absent_or_different"] for row in stop["fresh_exact_collector_IDs"])
    assert holding["inode_union_once"] is True
    old_capacity = json.loads(Path(prior["capacity"]["path"]).read_bytes())
    whole = old_capacity["whole_B"]
    future = 192 * MIB
    margin = whole - holding["allocated_B"] - future
    assert margin >= 8 * MIB
    assert old_capacity["known_cover_upper_B"] <= 50000000000
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize >= whole
    capacity = save(
        "capacity-and-holding.json",
        dict(
            roots=holding["roots"],
            actual_ended_point_once=holding,
            actual_ended_point_source=ref(collected / "retained-holding.json"),
            actual_prior_native_normal_STOP=ref(
                collected / "returned-collection-STOP.json"
            ),
            future_B=future,
            future_parts_B=old_capacity["future_parts_B"],
            whole_B=whole,
            forecast_margin_B=margin,
            prior_base_known_cover_B=old_capacity["prior_base_known_cover_B"],
            separate_new_ordinary_save_Git_envelope_B=old_capacity[
                "separate_new_ordinary_save_Git_envelope_B"
            ],
            known_cover_upper_B=old_capacity["known_cover_upper_B"],
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            saved_analysis_allowance="32MiB future is joint remaining saved analysis/control allowance for both phases, not an additional prior32MiB. Actual fullroot enforced by eachRUN owned_outputs.",
            scope="Actual ended nine-root union retained once; original192MiB phase forecast, no oldholding rescan/globalwalk/refund/lending/deletion/copies. Later tails/globalactual/fullfees UNKNOWN.",
        ),
    )
    supports = []
    for index, previous in enumerate(prior["phase_supports"], start=1):
        support = checked(Path(previous["path"]), previous["sha256"])
        assert support["resources"]["threads"] == 1
        assert support["roots"] == holding["roots"]
        support = copy.deepcopy(support)
        support.update(
            status="ISSUED_ORIGINAL28_FINAL_CLOCK156_OF312_ONE_SHARED_LIFETIME",
            shared_phase="ORIGINAL28_CLOCK156",
            free_B=margin,
            capacity_basis=capacity,
            actual_prior_native_normal_STOP=ref(
                collected / "returned-collection-STOP.json"
            ),
            original_fixed_depth_usage=dict(calls=156, actual_nodes_once=82267857),
            allocation="Original fixed second6RUNs: LOCAL1-LAZY2-ROOT_SPLIT2-ROOT_SPLIT2-LAZY2-LOCAL1; all26/fullpredecessors/6series/Current100%/Cedar/Control/LMR/PVS/TTtotal1M/path_tail/perf0 unchanged. D64/100ms authority/explicit5ms reserve/allworker1M cumulative. No root/depth/config/order/selection/cap/default change or refill.",
            later_stage="This is final original156. Original312 exhausted after actual completion, combined338 includes spent26. No subsequent stage, games/RNG/CI/pilot/refill or quota refund/lending.",
            saved_analysis_allowance="Joint remaining32MiB for both phases, not additive; full nine-root owned_outputs perRUN.",
        )
        support["limits"]["free_B"] = margin
        supports.append(save(f"phase-support-N{index}.json", support))
    controls_dir = OWN / "comparison-control-preparation-v1/two-lifetime-v1"
    issued = save(
        "issued-inputs.json",
        dict(
            release=prior["release"],
            phase_supports=supports,
            capacity=capacity,
            controls=prior["controls"],
            original_protocol=prior["original_protocol"],
            root4_depth_correspondence=prior["root4_depth_correspondence"],
            original_controls=prior["original_controls"],
            group_settings=ref(controls_dir / "clock-settings.draft.json"),
            group_job=ref(controls_dir / "clock-job.draft.json"),
            group_calls=156,
            total_comparison_calls=312,
            usage_before_submit=156,
            actual_nodes_before_submit=82267857,
            original26_diagnostic_nodes_once=25000193,
            actual_prior_collection=ref(collected / "summary.json"),
            actual_prior_native_normal_STOP=ref(
                collected / "returned-collection-STOP.json"
            ),
            evaluation="UNENTERED_FINAL156",
            source_leases=[],
            further_stage=None,
            selection_gate="None; ordinary fixed continuation after actualSTOP, not conditional on first-phase performance or report/ACK.",
        ),
    )
    print(
        json.dumps(
            dict(
                issued=issued,
                capacity=capacity,
                margin_B=margin,
                prior_summary_keys=list(summary),
            )
        )
    )


if __name__ == "__main__":
    main()
