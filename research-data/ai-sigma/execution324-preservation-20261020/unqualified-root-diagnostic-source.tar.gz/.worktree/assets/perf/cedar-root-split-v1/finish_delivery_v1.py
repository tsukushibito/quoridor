"""Retire the returned sender's one empty owned uv lock after exact-ID checks."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import sys

from intake_v1 import OWN, ROOT, ref, save

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    stage = OWN / "return-packet-guard-v1"
    guard = json.loads((stage / "result.json").read_bytes())
    assert guard["status"] == "PASS"
    known = []
    for identity in [
        guard["controller"],
        *(check["guardian_return"]["child"] for check in guard["checks"]),
    ]:
        now = process.process_info(identity["pid"])
        assert (now is None and not Path(f"/proc/{identity['pid']}").exists()) or (
            now is not None and process.identity(now) != identity
        )
        known.append(
            dict(expected=identity, now="ABSENT" if now is None else "DIFFERENT")
        )
    tmp = stage / "TMP"
    entries = list(tmp.iterdir())
    assert (
        len(entries) == 1 and [str(path) for path in entries] == guard["TMP_remaining"]
    )
    lock = entries[0]
    assert lock.name.startswith("uv-") and lock.suffix == ".lock"
    fd = os.open(lock, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        info = os.fstat(fd)
        assert stat.S_ISREG(info.st_mode) and info.st_size == 0 and info.st_nlink == 1
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fresh = lock.lstat()
        assert (fresh.st_dev, fresh.st_ino, fresh.st_size) == (
            info.st_dev,
            info.st_ino,
            0,
        )
        lock.unlink()
    finally:
        os.close(fd)
    tmp.rmdir()
    print(
        json.dumps(
            save(
                OWN / "delivery-returned-STOP.json",
                dict(
                    at=datetime.now(timezone.utc).isoformat(),
                    returned_guard=ref(stage / "result.json"),
                    source_completion=ref(OWN / "source-completion.json"),
                    source_STOP=ref(OWN / "source-reader-helper-STOP.json"),
                    known_exact_identities_fresh_absent_or_different=known,
                    actual_delivery=ref(OWN / "Root-source-delivery.json"),
                    Root_send_returncode=0,
                    retired_only_empty_unheld_owned_TMP_lock=str(lock),
                    TMP_entries=[],
                    source_leases_remaining=[],
                    owned_native_jobs_remaining=[],
                    source_model_RAW_evidence_deleted=False,
                    later_tails_globalactual_fullfees="UNKNOWN",
                    host_future_quiet=False,
                ),
            )
        )
    )


if __name__ == "__main__":
    main()
