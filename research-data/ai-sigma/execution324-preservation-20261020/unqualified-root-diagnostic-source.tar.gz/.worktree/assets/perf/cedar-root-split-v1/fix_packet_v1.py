"""Freeze only saved coverage, a sparse diagnostic patch, and result-before limits."""

from collections import Counter
import difflib
import gzip
import json
from pathlib import Path
import tempfile
import textwrap

from intake_v1 import OWN, ROOT, ref, save


def checked_document(file_ref):
    path = Path(file_ref["path"])
    assert ref(path) == file_ref
    return json.loads(path.read_bytes())


def patch_command(argv, cwd):
    import subprocess

    with subprocess.Popen(
        argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate(timeout=30)
        code = child.wait()
    assert (
        code == 0 and b"offset" not in stdout.lower() and b"fuzz" not in stdout.lower()
    ), (stdout, stderr)
    assert child.stdout.closed and child.stderr.closed
    return dict(
        argv=argv,
        returncode=code,
        stdout=stdout.decode(),
        stderr=stderr.decode(),
        directwait_reaped=True,
        handles_closed=True,
    )


def main():
    intake = json.loads((OWN / "intake.json").read_bytes())
    base = OWN / "diagnostic-source-v1"
    posts = sorted((base / "post").rglob("*.rs"))
    forward, inverse, subjects = [], [], []
    original = {}
    for post in posts:
        subject = post.relative_to(base / "post").as_posix()
        before_ref = ref(base / "before" / (post.name + ".gz"))
        before = gzip.decompress(Path(before_ref["path"]).read_bytes()).decode()
        after = post.read_text()
        original[subject] = before
        forward.extend(
            difflib.unified_diff(
                before.splitlines(True),
                after.splitlines(True),
                fromfile="a/" + subject,
                tofile="b/" + subject,
            )
        )
        inverse.extend(
            difflib.unified_diff(
                after.splitlines(True),
                before.splitlines(True),
                fromfile="a/" + subject,
                tofile="b/" + subject,
            )
        )
        subjects.append(
            dict(
                subject=subject,
                canonical_git=intake["immutable_commit"],
                before_gzip=before_ref,
                post=ref(post),
                mode="0644",
            )
        )
    for name, lines in [("forward.patch", forward), ("inverse.patch", inverse)]:
        with (base / name).open("x") as stream:
            stream.writelines(lines)
    results = []
    with tempfile.TemporaryDirectory(prefix="root-work-roundtrip-") as directory:
        tree = Path(directory)
        for subject, before in original.items():
            target = tree / subject
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(before)
        for patch, expected in [
            (
                "forward.patch",
                {r["subject"]: Path(r["post"]["path"]).read_text() for r in subjects},
            ),
            ("inverse.patch", original),
        ]:
            results.append(
                patch_command(
                    [
                        "patch",
                        "--batch",
                        "--fuzz=0",
                        "--no-backup-if-mismatch",
                        "-p1",
                        "-i",
                        str(base / patch),
                    ],
                    tree,
                )
            )
            assert all(
                (tree / subject).read_text() == text
                for subject, text in expected.items()
            )
            assert all(
                (tree / subject).stat().st_mode & 0o777 == 0o644 for subject in expected
            )
    alpha_subject = "crates/quoridor-ai/src/alphabeta.rs"
    before = original[alpha_subject]
    after = (base / "post" / alpha_subject).read_text()
    start, end = "    fn root_depth(\n", "    fn pv(&self,"
    assert before.split(start)[0] == after.split(start)[0]
    assert before.split(end)[1] == after.split(end)[1]
    assert '"forced root does not admit native SMP"' in after
    plan_path = (
        ROOT
        / ".worktree/assets/perf/cedar-ordering-quality-v1/normal26-preparation-v1/fixed-plan-v2.json"
    )
    plan_ref = ref(plan_path)
    assert (
        plan_ref["sha256"]
        == "142f8ea28c0baa525bcd84d84cc7b8fda1425cf0caaa37602f7aaa626778aec3"
    )
    plan = checked_document(plan_ref)
    primary_path = (
        ROOT
        / ".worktree/assets/perf/cedar-ordering-quality-v1/numeric-v1/analysis-v1/primary-rows.json"
    )
    snapshots_path = primary_path.with_name("snapshot-rows.json")
    primary = json.loads(primary_path.read_bytes())
    snapshots = json.loads(snapshots_path.read_bytes())
    strata = []
    for band in range(5):
        rows = [r for r in primary if r["band"] == band]
        strata.append(
            dict(
                band=band,
                roots=len(rows),
                legal_candidates=[r["legal_count"] for r in rows],
                child_attempts=[r["child_attempts"] for r in rows],
                completed_depth=[r["depth"] for r in rows],
                leading_child_nodes=None,
                other_branch_nodes=None,
                balance=None,
            )
        )
    coverage = save(
        OWN / "saved-work-coverage.json",
        dict(
            input_population=ref(primary_path),
            snapshots=ref(snapshots_path),
            roots=26,
            sessions=6,
            families=3,
            first_snapshots=sum(r["slot"] == "first_completed" for r in snapshots),
            latest_snapshots=sum(r["slot"] == "last_completed" for r in snapshots),
            pending_snapshots=sum(r["slot"] == "pending" for r in snapshots),
            overall_stops=dict(Counter(r["overall_stop"] for r in primary)),
            session_first=sum(r["session_first"] for r in primary),
            session_continued=sum(not r["session_first"] for r in primary),
            strata=strata,
            actual_candidate_nodes_evaluations_fields_present=False,
            saved27_worker_aggregate_cannot_resolve_root_branches=True,
            leading_serial_fraction=None,
            residual_parallel_balance=None,
            time_fraction=None,
            decision="UNRESOLVED_MISSING_BRANCH_WORK: candidate counts/selected ranks do not establish balance. Need authorized26 diagnostic before root-split prototype; no promised speed or cause.",
        ),
    )
    config = checked_document(plan["actualconfig"])
    config.update(
        search_threads=1,
        search_cpu_cores=[12],
        management_cpu_core=0,
        shallow_main_history="current",
    )
    config_ref = save(OWN / "diagnostic-config.draft.json", config)
    requests = checked_document(plan["requests"])
    requests_ref = save(OWN / "diagnostic-requests.json", requests)
    depth_map = [
        dict(
            root_index=r["root_index"],
            saved_completed_iteration=r["depth"],
            comparison_depth=min(8, max(1, r["depth"])),
            evidence=ref(primary_path),
        )
        for r in primary
    ]
    protocol = save(
        OWN / "finite-protocol-v1.json",
        dict(
            status="RESULT_BEFORE_NOT_RUNNABLE",
            purpose="Root-only leading-child-first exclusive-branch feasibility, not a promised implementation/effect",
            roots=plan["roots"],
            root_order=plan["root_order"],
            input_refs=plan["input_refs"],
            original_input_plan=plan["saved_input_plan"],
            diagnostic=dict(
                calls=26,
                nodes_each=1000000,
                nodes_upper=26000000,
                depth=64,
                time_limit_ms=None,
                sessions_max=6,
                mode="Control LOCAL1/off_shadow/root_ordering_quality",
                config=config_ref,
                requests=requests_ref,
                perf=0,
                required="Original sorted rank/action/frozen key/context/weightedhistory/root/STM; each actual PVS child call nodes/evals delta and returned-vs-pending; all committed iteration work rows plus first/latest/pending aligned children",
                decision_before_implementation="Only latest actually completed nonnumeric-TT depth>=2 samples with all work/returns measured can support structural plausibility. At least8 of original26 roots, >=3sessions and >=2stockbands must have other/(leading+other) nodes>=.25 and largest-other/(other nodes)<=.75. All missing/capped/unreturned/TT-only rows remain named UNKNOWN, not zero or favourable clock subsets. This is a workload screening rule, NOT a time or pruning-benefit estimate. Otherwise stop prototype or report unresolved; no automatic sweep.",
                costs="Observation-inclusive clock never fair speed qualification; work counters do not equal time. Existing per-node counters only read at root-child boundaries; no added node timers.",
            ),
            comparison=dict(
                status="CONDITIONAL_ON_PLAUSIBLE_DIAGNOSTIC_AND_GENUINE_SOFTWARE_ADMISSION",
                calls_upper=312,
                nodes_upper=312000000,
                modes=["LOCAL1", "LAZY2", "ROOT_SPLIT2"],
                phase_orders={
                    "fixed_depth": [
                        "LOCAL1",
                        "LAZY2",
                        "ROOT_SPLIT2",
                        "ROOT_SPLIT2",
                        "LAZY2",
                        "LOCAL1",
                    ],
                    "100ms5": [
                        "LOCAL1",
                        "LAZY2",
                        "ROOT_SPLIT2",
                        "ROOT_SPLIT2",
                        "LAZY2",
                        "LOCAL1",
                    ],
                },
                each_block_calls=26,
                chronological_sessions_each=6,
                depth_map=depth_map,
                fixeddepth_selection="max(1,min(8,saved21 deepest committed iteration depth)), frozen now before any new28 result. Overall NodeLimit is not completed D64 and saved times are not fair speed data.",
                per_call_allworker_cap=1000000,
                TT_total=1048576,
                time_ms=100,
                reserve_ms=5,
                correctness="All original slots qualified, legal main move/PV head, full weightedhistory/root restoration, typed bound and original candidate rank preserved, allworker cap, main-only completed callback; small independent fullwidth/stale-window/research/interruption/error/reset/drop NEW software boundaries before native. No unsafe or partial iteration completion.",
                safety="All156 clock calls main completeddepth>=1 and callback receipt<=.100s; terminal p95<=.110/max<=.125; cleanup/drain/error/cap qualification mandatory. No integer depth-gain or CPU-only veto.",
                serious_regression="Only if ALL156 fixeddepth calls complete, compare conservative max(two ROOT_SPLIT Searchsums)/min(two comparator Searchsums); >1.20 or anyroot repeat-median ratio>1.25 AND >.010s extra is serious. Censoring makes whole completed-time ratio UNKNOWN, no favourable subset/cap speedup/refill.",
                practical_support="Repeated ROOT_SPLIT Searchsum at least5% below LAZY2 pooled and max(two ROOT_SPLIT sums)<min(two LAZY2 sums), no serious safety/regression and whole-driver ratio<=1.10; otherwise finite benefit unsupported/unresolved. LOCAL1 and every root/work/CPU/whole/reset/drop distribution remain reported; no samework/general speed/strength claim.",
            ),
            combined_calls_upper=338,
            combined_nodes_upper=338000000,
            games_issued=0,
            warmup_pilot_refill_newroots_4threads_model_RNG=0,
            common_policy="All future comparison arms use one genuine common source/image/pinned disposition including27 writer retention; current source already writer-neutral. Pending27 games/disposition independent. No historical clock pairing.",
            source_release=None,
            Build=None,
            artifact=None,
            support=None,
            whole=None,
            current_callers=None,
            origin=None,
            end_at=None,
            runtime_proposal=dict(
                search=[12, 14],
                main=0,
                outer=18,
                family_B=4294967296,
                management_B=1610612736,
                native_B=2684354560,
                host4_B=4294967296,
                GPU=0,
            ),
            diagnostic_storage_proposal_only=dict(
                whole_B=83886080,
                native_aggregate_B=20971520,
                record_B=262144,
                normal_copy_B=19922944,
                TMP_B=8388608,
                logs_B=4194304,
                analysis_control_B=8388608,
                models_images_libraries_input_copy_B=0,
                actual_serializer_and_fullholding_required=True,
            ),
        ),
    )
    report = [
        "Root-split28: saved work coverage and first actual diagnostic source delta",
        "Original21 provides26 roots/3families/bothturns/6chronologicalsessions, stockbins2/6/6/6/6, zero-stock shortfall4. It retains26 first+26latest+25pending snapshots. Last completed iteration depth5..64 exists, but overall25 NodeLimit/1DepthComplete is not D64 qualification or oracle. Leading selected rank/topcounts are ordering observations, not leading-child work.",
        "Actual saved candidate schema contains original order/frozen keys and child window/value/PVS-research/return status. Neither its primary nor snapshot work tables has per-child nodes/evals. Original27 has only worker/root sums. Leading-child serial fraction, remaining-branch largest share and time balance are therefore UNKNOWN. Counting many legal candidates cannot justify a root-split speed claim.",
        "Canonical source responsibilities at "
        + intake["immutable_commit"]
        + ": alphabeta::root_depth currently orders all legal root moves, searches the leading child full-window, later children scout then required full-window research and publishes only after the entire iteration succeeds. Original root loop does not call reduced_child, so a future split must preserve this existing root policy and original rank for child/internal LMR rather than call a fresh search_forced loop as a substitute. search_forced explicitly REFUSES native SMP and runs all1..H iterations with restricted parent; it is not a worker-ready branch API. Common child owns make/undo/history/accumulator/restoration; table/history qualification and persistent pool belong to existing owners. No refusal or kernel was weakened.",
        "Actual private delta: extend only existing defaultOFF/root-quality observation. At each root child call read existing nodes/evaluations before and after, including interrupted/error result before propagation. Existing windows/returned label stay distinct; missing work staysNone. Bounded first/latest/pending child arrays plus <=64 compact completed-iteration leading/other/largest-other/research totals; no pernode timer/trace/queue, no new observer setting/framework. Ordinary false monomorph has no observation calls; no empirical overhead claim.",
        "Root-split execution prototype is NOT IMPLEMENTED: the concrete missing work correspondence blocks its plausibility decision. Authorized26 new calls are NOT ENTERED; source review/adoption/new scoped software/current image/support/fair window/normal admission are genuine missing inputs. This is neither old-record replay nor an ACK gate. Original27 conditional64 and25.3/26 remain independent. Two NEW boundary definitions are UNBUILT/UNTYPED/UNRUN; no old suites or native/model/RAW/RNG/compiler execution.",
    ]
    with (OWN / "saved-work-report.txt").open("x") as stream:
        stream.write("\n\n".join(textwrap.fill(p, width=100) for p in report) + "\n")
    binding = save(
        base / "fixed-binding.json",
        dict(
            immutable_canonical_git=intake["immutable_commit"],
            subjects=subjects,
            forward=ref(base / "forward.patch"),
            inverse=ref(base / "inverse.patch"),
            strict_zero_fuzz_nooffset_mode_bytes_roundtrip=results,
            alpha_outside_root_depth_exact=True,
            old_search_forced_SMP_refusal_exact=True,
            changed_boundary="DefaultOFF diagnostic only, nodes/evaluations by actual root child attempt and compact completed iterations, including partial work without converting interruption to return/completion",
            report=ref(OWN / "saved-work-report.txt"),
            coverage=coverage,
            finite_protocol=protocol,
            new_exact_selectors=[
                "alphabeta::neighbour_opportunity::root_child_work_boundary_tests::root_work_distinguishes_returned_research_partial_and_missing",
                "measurement::root_branch_work_output_boundary_tests::root_branch_work_is_absent_by_default_and_explicit_empty_is_not_measured_zero",
            ],
            software_required="Root only: new AI1 with research-diagnostics and new Runner LIBRARY1 with maintained measurement/claustrophobia features, affected Clippy/release. No old successfulsuite replay.",
            author_tests_compiler_native_model_RAW_RNG=0,
            SOURCE_CLEAR=False,
            Main_Git_index_Cargo_docs_writes=0,
        ),
    )
    print(json.dumps(dict(binding=binding, protocol=protocol, coverage=coverage)))


if __name__ == "__main__":
    main()
