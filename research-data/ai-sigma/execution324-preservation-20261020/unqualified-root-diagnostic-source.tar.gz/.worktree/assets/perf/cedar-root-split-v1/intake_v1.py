"""Claim new28 and inspect only saved work schemas and immutable search owners."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
ACTOR = "codex:01a11004-79f3-7c20-872c-432a2c347664"
ISSUE = "quoridor-4lc.324.28"


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def save(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")
    return ref(path)


def command(argv):
    with subprocess.Popen(
        argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate(timeout=60)
        code = child.wait()
    assert child.stdout.closed and child.stderr.closed
    return dict(
        argv=argv,
        returncode=code,
        stdout=stdout.decode(),
        stderr=stderr.decode(),
        directwait_reaped=True,
        handles_closed=True,
    )


def authority(name, argv):
    record = command(["bash", "scripts/dev/beads.sh", *argv])
    save(OWN / f"authority-{name}.json", record)
    assert record["returncode"] == 0, record
    return json.loads(record["stdout"])


def main():
    authority("ready-v1", ["ready", "--json"])
    issue = authority("show-v1", ["show", ISSUE, "--json"])[0]
    assert issue["assignee"] == ACTOR and issue["status"] == "open"
    claimed = authority("claim-v1", ["update", ISSUE, "--claim", "--json"])[0]
    assert claimed["assignee"] == ACTOR and claimed["status"] == "in_progress"
    prior = (
        ROOT
        / ".worktree/assets/perf/cedar-lazy-smp-followup-v1/games64-preparation-tail-guard-v1/result.json"
    )
    prior_stop = json.loads(prior.read_bytes())
    assert prior_stop["status"] == "PASS" and prior_stop["TMP_remaining"] == []
    sources = {}
    git = command(["git", "rev-parse", "HEAD"])
    assert git["returncode"] == 0
    commit = git["stdout"].strip()
    for subject in [
        "crates/quoridor-ai/src/research.rs",
        "crates/quoridor-ai/src/alphabeta.rs",
        "crates/quoridor-ai/src/lazy_smp.rs",
    ]:
        result = command(["git", "show", f"{commit}:{subject}"])
        assert result["returncode"] == 0, result
        raw = result["stdout"]
        lines = raw.splitlines()
        needles = [
            "search_forced",
            "fn ordered",
            "fn reduced_child",
            "fn search",
            "root_ordering_quality",
            "struct Root",
            "first_depth",
            "enum Command",
            "enum Task",
        ]
        locators = [
            dict(line=i + 1, text=line)
            for i, line in enumerate(lines)
            if any(n in line for n in needles)
        ]
        sources[subject] = dict(
            sha256=hashlib.sha256(raw.encode()).hexdigest(),
            bytes=len(raw.encode()),
            locators=locators,
        )
        print("SOURCE", subject, json.dumps(sources[subject]))
    saved = {}
    for task, base in [
        ("21", "cedar-ordering-quality-v1"),
        ("27", "cedar-lazy-smp-followup-v1"),
    ]:
        directory = ROOT / ".worktree/assets/perf" / base / "numeric-v1/analysis-v1"
        for name in ["report-ja.md", "summary.json"] + (
            ["root-ranks.csv", "cross-iteration-rows.json"] if task == "21" else []
        ):
            path = directory / name
            raw = path.read_text()
            saved[f"{task}/{name}"] = ref(path)
            if name.endswith(".json"):
                document = json.loads(raw)
                print(
                    "SAVED_SCHEMA",
                    task,
                    name,
                    json.dumps(
                        dict(
                            type=type(document).__name__,
                            keys=list(document) if isinstance(document, dict) else None,
                            length=len(document),
                            first=(
                                document[:1] if isinstance(document, list) else None
                            ),
                        )
                    ),
                )
            else:
                print("SAVED_TEXT", task, name, raw[:18000])
    record = save(
        OWN / "intake.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            issue=ISSUE,
            assignee=ACTOR,
            actual_model="gpt-6.1-sol",
            effort="high",
            cwd=str(ROOT),
            sandbox="danger-full-access",
            approvalPolicy="never",
            preceding27_actual_returned_STOP=ref(prior),
            immutable_commit=commit,
            source_owners=sources,
            saved_metadata=saved,
            Main_Git_index_Cargo_docs_writes=0,
            native_model_RAW_RNG_tests=0,
            context_launcher_failure="ambient python absent (exit127) before ordinary commands; actual context verified using existing project Python",
            private_source_analysis_started=True,
        ),
    )
    print("INTAKE", json.dumps(record))


if __name__ == "__main__":
    main()
