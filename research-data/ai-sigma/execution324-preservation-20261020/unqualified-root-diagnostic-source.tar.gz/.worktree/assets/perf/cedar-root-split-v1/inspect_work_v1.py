"""Inspect retained candidate-work schemas and only common child/root owners."""

import json

from intake_v1 import OWN, ROOT, command, ref, save


def shape(value):
    if isinstance(value, dict):
        return {key: shape(item) for key, item in value.items()}
    if isinstance(value, list):
        return dict(
            type="list", length=len(value), first=shape(value[0]) if value else None
        )
    return type(value).__name__


def main():
    intake = json.loads((OWN / "intake.json").read_bytes())
    base = (
        ROOT / ".worktree/assets/perf/cedar-ordering-quality-v1/numeric-v1/analysis-v1"
    )
    summary = json.loads((base / "summary.json").read_bytes())
    print("TABLE_REFS", json.dumps(summary["tables"]))
    references = {}
    for name in ["primary-rows.json", "snapshot-rows.json"]:
        path = base / name
        assert path.stat().st_size <= 8 * 1048576
        value = json.loads(path.read_bytes())
        references[name] = ref(path)
        print("SHAPE", name, json.dumps(shape(value)))
        print(
            "EXAMPLE",
            name,
            json.dumps(value[0] if isinstance(value, list) else value)[:14000],
        )
    subject = "crates/quoridor-ai/src/alphabeta.rs"
    result = command(["git", "show", f"{intake['immutable_commit']}:{subject}"])
    assert result["returncode"] == 0
    lines = result["stdout"].splitlines()
    excerpts = {}
    for label, start, end in [
        ("root_observation_types", 1000, 1210),
        ("ordered_entry", 1550, 1635),
        ("reduced_child", 2851, 3060),
        ("session_forced", 3870, 4110),
        ("iteration_root_loop", 4410, 4735),
    ]:
        text = "\n".join(
            f"{i + 1}:{lines[i]}" for i in range(start - 1, min(end, len(lines)))
        )
        excerpts[label] = text
        print("SOURCE_EXCERPT", label, text)
    for i, line in enumerate(lines):
        if (
            "root_observation" in line
            or "RootOrdering" in line
            or "RootCandidate" in line
        ):
            print("ROOT_OBSERVATION_LOCATOR", i + 1, line)
    subject2 = "crates/quoridor-ai/src/lazy_smp.rs"
    result2 = command(["git", "show", f"{intake['immutable_commit']}:{subject2}"])
    assert result2["returncode"] == 0
    lazy = result2["stdout"].splitlines()
    for start, end in [(1, 100), (230, 300), (640, 870)]:
        print(
            "POOL_EXCERPT",
            "\n".join(
                f"{i + 1}:{lazy[i]}" for i in range(start - 1, min(end, len(lazy)))
            ),
        )
    result_ref = save(
        OWN / "saved-work-schema-and-source-excerpts.json",
        dict(
            immutable_commit=intake["immutable_commit"],
            saved_candidate_tables=references,
            source_subject=subject,
            source_excerpts=excerpts,
            source_semantics_modified=False,
            native_model_RAW_RNG_tests=0,
        ),
    )
    print("INSPECTION", json.dumps(result_ref))


if __name__ == "__main__":
    main()
