"""Make one sparse root-work observation delta, without compiling or searching."""

import gzip
import json

from intake_v1 import OWN, command, save


def replace_once(text, before, after):
    assert text.count(before) == 1, before[:100]
    return text.replace(before, after)


def main():
    intake = json.loads((OWN / "intake.json").read_bytes())
    commit = intake["immutable_commit"]
    base = OWN / "diagnostic-source-v1"
    before_dir = base / "before"
    before_dir.mkdir(parents=True)
    subjects = [
        "crates/quoridor-ai/src/alphabeta.rs",
        "crates/quoridor-ai/src/neighbour_opportunity.rs",
        "crates/quoridor-runner/src/measurement.rs",
    ]
    sources = {}
    for subject in subjects:
        result = command(["git", "show", f"{commit}:{subject}"])
        assert result["returncode"] == 0
        text = result["stdout"]
        sources[subject] = text
        with (before_dir / (subject.rsplit("/", 1)[1] + ".gz")).open("xb") as stream:
            stream.write(gzip.compress(text.encode(), mtime=0))
    alpha = sources[subjects[0]]
    alpha = replace_once(
        alpha,
        """                    false,
                );
            }
            let mut v = if self.limits.use_pvs && i > 0 {
                self.child(c, a, action, depth - 1, [value, next_up(value)], 1)?
            } else {
                self.child(c, a, action, depth - 1, [value, f32::INFINITY], 1)?
            };""",
        """                    false,
                );
                q.work_started(self.stats.nodes, self.stats.evaluations);
            }
            let child_result = if self.limits.use_pvs && i > 0 {
                self.child(c, a, action, depth - 1, [value, next_up(value)], 1)
            } else {
                self.child(c, a, action, depth - 1, [value, f32::INFINITY], 1)
            };
            #[cfg(feature = "research-diagnostics")]
            if OPPORTUNITY
                && let Some(q) = self.opportunity.as_deref_mut().and_then(|o| o.root_ordering.as_mut())
            {
                q.work_finished(self.stats.nodes, self.stats.evaluations);
            }
            let mut v = child_result?;""",
    )
    alpha = replace_once(
        alpha,
        """                    q.child_started(action, [value, f32::INFINITY], true);
                }
                v = self.child(c, a, action, depth - 1, [value, f32::INFINITY], 1)?;""",
        """                    q.child_started(action, [value, f32::INFINITY], true);
                    q.work_started(self.stats.nodes, self.stats.evaluations);
                }
                let child_result = self.child(c, a, action, depth - 1, [value, f32::INFINITY], 1);
                #[cfg(feature = "research-diagnostics")]
                if OPPORTUNITY
                    && let Some(q) = self.opportunity.as_deref_mut().and_then(|o| o.root_ordering.as_mut())
                {
                    q.work_finished(self.stats.nodes, self.stats.evaluations);
                }
                v = child_result?;""",
    )
    observer = sources[subjects[1]]
    observer = replace_once(
        observer,
        """    pub pending: Option<RootOrderingSample>,
}""",
        """    pub pending: Option<RootOrderingSample>,
    /// Compact all-completed-iteration work, not a per-node trace.
    pub completed_work: Vec<RootBranchWork>,
    work_start: Option<(u64, u64)>,
}

#[derive(Debug, Default)]
pub struct RootBranchWork {
    pub depth: u16,
    pub child_calls: usize,
    pub complete_work: bool,
    pub leading_nodes: u64,
    pub leading_evaluations: u64,
    pub other_nodes: u64,
    pub other_evaluations: u64,
    pub largest_other_nodes: u64,
    pub research_nodes: u64,
    pub research_evaluations: u64,
}
impl RootBranchWork {
    fn of(sample: &RootOrderingSample) -> Self {
        let leading = sample.entries.first().map(|entry| entry.0);
        let mut work = Self {
            depth: sample.depth,
            child_calls: sample.children.len(),
            complete_work: sample.children.len() == sample.child_work.len(),
            ..Self::default()
        };
        let mut other_by_action = [0u64; 209];
        for (child, measured) in sample.children.iter().zip(&sample.child_work) {
            let Some((nodes, evaluations)) = measured else {
                work.complete_work = false;
                continue;
            };
            work.complete_work &= child.3.is_some();
            if Some(child.0) == leading {
                work.leading_nodes += nodes;
                work.leading_evaluations += evaluations;
            } else {
                work.other_nodes += nodes;
                work.other_evaluations += evaluations;
                other_by_action[usize::from(child.0)] += nodes;
            }
            if child.2 {
                work.research_nodes += nodes;
                work.research_evaluations += evaluations;
            }
        }
        work.largest_other_nodes = other_by_action.into_iter().max().unwrap_or(0);
        work
    }
}""",
    )
    observer = replace_once(
        observer,
        """    pub children: Vec<(u16, [u32; 2], bool, Option<u32>)>,""",
        """    pub children: Vec<(u16, [u32; 2], bool, Option<u32>)>,
    /// Aligned per child call, including partial work before interruption/error.
    /// None is unmeasured, never zero work; returned value remains separately typed.
    pub child_work: Vec<Option<(u64, u64)>>,""",
    )
    observer = replace_once(
        observer,
        """        self.pending = Some(RootOrderingSample {""",
        """        self.work_start = None;
        self.pending = Some(RootOrderingSample {""",
    )
    observer = replace_once(
        observer,
        """            children: Vec::new(),""",
        """            children: Vec::new(),
            child_work: Vec::new(),""",
    )
    observer = replace_once(
        observer,
        """                .push((action, window.map(f32::to_bits), research, None));
        }
    }
    pub(super) fn child_returned""",
        """                .push((action, window.map(f32::to_bits), research, None));
            s.child_work.push(None);
        }
        self.work_start = None;
    }
    pub(super) fn work_started(&mut self, nodes: u64, evaluations: u64) {
        self.work_start = Some((nodes, evaluations));
    }
    pub(super) fn work_finished(&mut self, nodes: u64, evaluations: u64) {
        if let Some((before_nodes, before_evaluations)) = self.work_start.take()
            && let Some(slot) = self.pending.as_mut().and_then(|s| s.child_work.last_mut())
        {
            *slot = nodes.checked_sub(before_nodes).zip(evaluations.checked_sub(before_evaluations));
        }
    }
    pub(super) fn child_returned""",
    )
    observer = replace_once(
        observer,
        """            s.completed = true;
            if self.first_completed.is_none() {""",
        """            s.completed = true;
            self.completed_work.push(RootBranchWork::of(&s));
            if self.first_completed.is_none() {""",
    )
    observer += """

#[cfg(test)]
mod root_child_work_boundary_tests {
    use super::*;

    #[test]
    fn root_work_distinguishes_returned_research_partial_and_missing() {
        let mut q = RootOrderingQuality::default();
        q.begin(3, 1, None, [None; 2], None);
        q.pending.as_mut().unwrap().entries = vec![(3, 0, None), (5, 1, None)];
        q.child_started(3, [f32::NEG_INFINITY, f32::INFINITY], false);
        q.work_started(10, 4);
        q.work_finished(40, 14);
        q.child_returned(0.25);
        q.child_started(5, [0.25, 0.5], false);
        q.work_started(40, 14);
        q.work_finished(45, 16);
        q.child_returned(0.5);
        q.child_started(5, [0.25, f32::INFINITY], true);
        q.work_started(45, 16);
        q.work_finished(65, 21);
        q.child_returned(0.5);
        q.returned(5, 0.5);
        q.commit();
        let w = &q.completed_work[0];
        assert!(w.complete_work);
        assert_eq!((w.leading_nodes, w.other_nodes, w.largest_other_nodes), (30, 25, 25));
        assert_eq!((w.leading_evaluations, w.other_evaluations, w.research_nodes), (10, 7, 20));
        q.begin(4, 2, Some(5), [None; 2], None);
        q.child_started(3, [0.0, 1.0], false);
        q.work_started(65, 21);
        q.work_finished(70, 23);
        let partial = q.pending.as_ref().unwrap();
        assert_eq!(partial.child_work, vec![Some((5, 2))]);
        assert!(partial.children[0].3.is_none() && !partial.completed);
        assert_eq!(q.completed_work.len(), 1);
        q.child_started(5, [0.0, 1.0], false);
        assert!(q.pending.as_ref().unwrap().child_work[1].is_none());
        assert!(!RootBranchWork::of(q.pending.as_ref().unwrap()).complete_work);
    }
}
"""
    runner = sources[subjects[2]]
    runner = replace_once(
        runner,
        '"window_bits":s.window_bits,"entries":s.entries,"children":s.children,',
        '"window_bits":s.window_bits,"entries":s.entries,"children":s.children,\n                        "child_work_nodes_evaluations":s.child_work,',
    )
    marker = "    if let Some(history) = o.history_provenance.as_ref() {"
    runner = replace_once(
        runner,
        marker,
        """    if let Some(q) = o.root_ordering.as_ref() {
        result["root_branch_work"] = json!({
            "unit":"nodes/evaluations per actual root child call, not elapsed time or saved work",
            "missing":"None/unreturned/pending is not zero or completed work; numeric-TT roots may have no branches",
            "completed_iterations":q.completed_work.iter().map(|w| json!({
                "depth":w.depth,"child_calls":w.child_calls,"complete_work":w.complete_work,
                "leading_nodes":w.leading_nodes,"leading_evaluations":w.leading_evaluations,
                "other_nodes":w.other_nodes,"other_evaluations":w.other_evaluations,
                "largest_other_nodes":w.largest_other_nodes,
                "research_nodes":w.research_nodes,"research_evaluations":w.research_evaluations
            })).collect::<Vec<_>>()
        });
    }
"""
        + marker,
    )
    for subject, text in zip(subjects, [alpha, observer, runner], strict=True):
        path = base / "post" / subject
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("x") as stream:
            stream.write(text)
    print(
        json.dumps(
            save(
                base / "actual-delta-start.json",
                dict(
                    immutable_commit=commit,
                    subjects=subjects,
                    source_semantics="Only existing defaultOFF OffShadow root quality observation: root-child stats deltas and bounded committed iteration summaries. Search results/error propagation unchanged; forcedRoot SMP refusal remains.",
                    native_tests_compiler_RNG=0,
                ),
            )
        )
    )


if __name__ == "__main__":
    main()
