"""Return fixed diagnostic boundary and actual stopped scoped helpers to324."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys

from intake_v1 import ISSUE, OWN, ROOT, authority, command, ref, save

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    guards, known = [], []
    names = [
        "intake-guard-v1",
        "inspect-work-guard-v1",
        "diagnostic-delta-guard-v1",
        "diagnostic-delta-guard-v2",
        "diagnostic-format-guard-v1",
        "fix-packet-guard-v1",
    ]
    prior27 = (
        ROOT
        / ".worktree/assets/perf/cedar-lazy-smp-followup-v1/games64-preparation-tail-guard-v1"
    )
    for stage in [*(OWN / name for name in names), prior27]:
        g = json.loads((stage / "result.json").read_bytes())
        assert g["status"] == (
            "FAILED" if stage.name == "diagnostic-delta-guard-v1" else "PASS"
        )
        assert not (stage / "TMP").exists()
        identities = [g["controller"]]
        for check in g["checks"]:
            returned = check["guardian_return"] or json.loads(
                (stage / (check["name"] + ".process.json")).read_bytes()
            )
            assert returned["cleanup_complete"] and returned["remaining"] == []
            assert (
                returned["direct_child_reaped"] and returned["handle_closes_complete"]
            )
            identities.append(returned["child"])
        for identity in identities:
            now = process.process_info(identity["pid"])
            assert (now is None and not Path(f"/proc/{identity['pid']}").exists()) or (
                now is not None and process.identity(now) != identity
            )
            known.append(
                dict(expected=identity, now="ABSENT" if now is None else "DIFFERENT")
            )
        guards.append(
            dict(
                file=ref(stage / "result.json"),
                returned_at=g["reader_STOP"],
                status=g["status"],
            )
        )
    binding = ref(OWN / "diagnostic-source-v1/fixed-binding.json")
    packet = json.loads(Path(binding["path"]).read_bytes())
    stop = save(
        OWN / "source-reader-helper-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            guards=guards,
            known_exact_identities_fresh_absent_or_different=known,
            source_CPU=2,
            guardian_CPU=18,
            family_B=1073741824,
            controller_included_B=67108864,
            host_reserve_B=4294967296,
            GPU=0,
            Main_reader_leases=[],
            source_leases_remaining=[],
            TMP_entries=[],
            owned_native_jobs_remaining=[],
            native_model_RAW_RNG_tests_compiler=0,
            failed_unused_import_lint_preserved="diagnostic-delta-guard-v1 failed before delta; causal removal only; no test/native/source proof replay",
            prior27_status_controls_and_conditional64_unchanged=True,
            current_metadata_delivery_lifetime="Separate bounded helper; no futurequiet or idle lease",
        ),
    )
    authority(
        "source-note-v1",
        [
            "update",
            ISSUE,
            "--append-notes",
            f"Actual saved-work analysis/private diagnostic source started and fixed. {binding['path']} SHA{binding['sha256']}; report {packet['report']['path']}; protocol {packet['finite_protocol']['path']}. Existing21 retains26 first/26latest/25pending root samples but no per-child nodes/evals; 27 worker sums cannot establish first-child dominance or branch balance. Added only defaultOFF existing root-quality child work/partial/error counters plus bounded<=64 committed-iteration summaries in3sparseowners; forcedRoot SMP refusal and kernel retained. NewAI1/RunnerLIB1 UNBUILT/UNTYPED/UNRUN, no tests/compiler/model/native/RAW/RNG. Need Root related boundary confirmation/adoption/software/current genuine image/support/window for original diagnostic26/26M before root-split plausibility. Comparison<=312/312M, combined338, games0. Actual scopedSTOP {stop['path']} SHA{stop['sha256']}. Original27 authority unchanged; no ACK/parent gate.",
            "--json",
        ],
    )
    authority("source-backup-v1", ["backup", "sync", "--json"])
    seen, allocated, logical = set(), 0, 0
    for directory, directories, filenames in os.walk(OWN, followlinks=False):
        for path in [
            Path(directory),
            *(Path(directory) / name for name in directories + filenames),
        ]:
            info = path.lstat()
            inode = (info.st_dev, info.st_ino)
            if inode not in seen:
                seen.add(inode)
                allocated += info.st_blocks * 512
                logical += info.st_size
    point = save(
        OWN / "ordinary-affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            root=str(OWN),
            allocated_B=allocated,
            logical_B=logical,
            inodes=len(seen),
            scope="New OWN28 only once; no oldholding/model/image/target/global walk/recharge",
            later_metadata_tails_globalactual_fullfees="UNKNOWN",
            grant_refund_loan=False,
        ),
    )
    completion = save(
        OWN / "source-completion.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            issue=ISSUE,
            fixed_source=binding,
            coverage=packet["coverage"],
            report=packet["report"],
            protocol=packet["finite_protocol"],
            actual_helper_STOP=stop,
            affected_point=point,
            meaningful_note_backup="PASS0",
            Root_related_source_confirmation_and_software="PENDING; author never SOURCE_CLEAR",
            native_diagnostic_calls=0,
            comparison_calls=0,
            games=0,
            original27_unchanged=True,
        ),
    )
    message = OWN / "Root-source-handoff.txt"
    message.write_text(
        "NEW own28 actualready/show/claim sameactor/in_progress and private source analysis/delta completed at prior27 returnedhelperSTOP (original27 status/64authority unchanged). Actualcontext Sol6.1/high/Main/fullnever verified. Immutable canonical92fb6faa sourceonly3affectedowners. Saved21 coverage26first/26latest/25pending/3families/6series/bins2,6,6,6,6/zero4shortfall; allcandidate work absent, so firstchildserialfraction/otherbranchbalance/timefraction UNKNOWN. Original27 work is workeraggregate only, not branch information. Source trace: root_depth firstchild fullwindow then PVS scout/research/allnecessarychildren; search_forced explicitly REFUSES nativeSMP and restricted parent loops1..H, cannot substitute a fresh forcedsearch for rank-correct commonchild. Kernel/LMR/PVS/history/TT/mainauthority/default1/refusal protected. "
        "Concrete minimal delta ONLY existing defaultOFF/rootquality diagnostic: actualrootchild nodes/evals deltas, including interruption/error before propagation, no false returned/completedlabel; alignedfirst/latest/pending arrays plus bounded64completediteration leading/other/largestother/research totals, TT-only/empty/missing explicit. No pernode timers/scans/queue/newframework. Two NEWAI1/RunnerLIB1 definitions UNBUILT/UNTYPED/UNRUN; Rustfmt/scopedRuff and strict GNUfuzz0/nooffset forward/inverse bytes+mode roundtripPASS, no compiler/native/model/RAW/RNG. "
        "Root-split prototype not yet implemented because concrete missingwork blocks plausibility; authorized26Control diagnostic needs genuine sparseadoption/sourceconfirmation/software/image/currentnormaljoin/support/fairwindow, not ACK. Fixed beforeoutcomes: original26/6series/D64/1M/timeNone/perf0, requiredfields and screening threshold; comparison312 hardupper/combined338, capped8savedcompleteddepthmap frozen now, 3mode2repeat depth+clock order fixed, allunknown/no subset/refill, games0. Default1/27/25.3/26 andclosedresults unchanged. "
        + json.dumps(
            dict(
                completion=completion,
                fixed_source=binding,
                report=packet["report"],
                coverage=packet["coverage"],
                protocol=packet["finite_protocol"],
                actualSTOP=stop,
                affected=point,
            )
        )
        + ". ActualallrecordedscopedIDs freshabsent/different/directreap/handles/TMP/sourceleases[], no futurehostquiet. Ownnote+backupPASS; allpauses/seals/defaultmodels/foreign/FAILED/NULL/UNKNOWNfees/50GB/consultation8 retained. Please route ONLY fixed diagnostic boundary/qualification question to existingMax viaRoot; authordispatch0.\n"
    )
    delivery = command(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--issue",
            "quoridor-4lc.324",
            "--cwd",
            str(ROOT),
            "--body-file",
            str(message),
        ]
    )
    save(OWN / "Root-source-delivery.json", delivery)
    print(
        json.dumps(
            dict(
                completion=completion,
                STOP=stop,
                affected=point,
                delivery_returncode=delivery["returncode"],
            )
        )
    )


if __name__ == "__main__":
    main()
