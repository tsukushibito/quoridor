原29の固定208比較は CONCLUSION_CLEAR、essential 0／ordinary 0。有限結論は RETAIN_ROOT_ASPIRATION_OFF_NO_GAMES_FIXED_MAJOR_ROOT_REGRESSION。Rootはこの限定結論を受入済みであり、source／software／runtime／一般性能や棋力の追加認定ではない。

全8 normal manifest/data PASS、208 calls／48 sessions／23,486,705 nodes（208M上限）を保存custodyとして再用した。固定深さ104件は全てDepthCompleteで、有限の完了時間比を比較できる。任意の完了subsetやcap時間へ置換していない。

Search ON/OFFの二反復合計比は1.0286333008226842（約2.86%長い）。固定whole-driver比1.0278935793678337は別の分母であり、Searchやsetup／reset／dropをnested加算しない。max(ON)/min(OFF)=1.053998082835278が1.20未満でも、次の独立したroot別拒否条件は免除されない。

| root | ON/OFF repeat median比 |     median増分（秒） | 凍結した重大退行条件      |
| ---- | ---------------------: | -------------------: | ------------------------- |
| 18   |     1.2916228274399364 | 0.016740281499999995 | >1.25 AND >0.010 を満たす |
| 23   |     1.2609372240731056 | 0.012561226500000008 | >1.25 AND >0.010 を満たす |

規約は「全104要求完了後、全体max/min>1.20 OR いずれかrootのrepeat中央値比>1.25 AND 増分>0.010s」で自動gamesを拒否する。両rootが後者を満たすため、実測の重大root退行が確立している。保存reportの一般的なNO_GAMESラベルは、本件ではこの具体的な拒否理由に対応する。collectionの旧GATE_PENDINGは解析前の歴史的記録であり、新しい許可を意味しない。

100ms／5msの104件は保存clock-safety PASS、receipt違反0、terminal Search p95=0.0993248335秒／max=0.107315694秒。clockの停止はTimeLimit100件＋DepthComplete4件で、D64完了やoracleを意味しない。root中央値の完了深さは改善3／悪化0だが、重大root退行の拒否を覆さない。5%以上の実用時間支持と反復分離は共にFALSE。

固定深さON各26-call反復のretry69（fail-low30／fail-high39）、fallback0は保存された限定カウンタであり、全208件の合計ではない。窓／LMRによる仕事・PV・valueの違い、retry増やnode増から原因・saved nodes・係数品質を確定しない。隣接完了depthのscore変動とattempt別時間はUNKNOWNのまま。

26 genuine prefixes／3 family／6同色chronological warm series、stock2/6/6/6/6とstock0不足4、既知の歴史的露出・系列依存を保持する。未見IID標本や一般速度／害／棋力／等価／無効果／最適性／default／model採用は主張しない。CPUはrenderを含むOS process全thread、RSSは累積highwaterで、family連続peak／physical NN／fullfees／globalactualはUNKNOWN。outer67.71593602898065秒は一度、accepted-inclusive69.77458秒は代替分母でnested加算0。

原208は使い切り、条件付き128 gamesとfinal CIは0。新しい幅変更／sweep／refill／pilot／科学grantや27／28への枠移動はない。source retirementはRootと同作者の別作業であり、この結果レビューでは再監査しない。閉じた29.1や他ownerを変更しない。

根拠はminimum-result-review.json、saved-scalar-correspondence.json、control.json、reader-helper-STOP.json、returned-reader-STOP.jsonと通常Root配送minimum-delivery.json。producer／protocol／CSV／STOPは必要な保存小参照だけを確認し、source import／test／build／native／model／RAW／archive／geometry／normal validator／FINALIZE／RNG／CI／旧成功suiteを再実行していない。実readerとminimum helperはdirectwait／reap／handles／known PID-start-bootのfresh不在とTMP・owned lease空を伴って返却した。whole hostや未来の静穏は認定しない。通常note／backup／closeは独立suffixであり、ACKやruntimeのgateにしない。全pause／seal／default／model／foreign／FAILED／NULL／UNKNOWN費／decimal50GB／取消consultation8を保持する。
