"""Preserve the bounded original208 conclusion check, without replay."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-aspiration-window-review-v1/finite-result-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    names = [
        "minimum-result-review.json",
        "control.json",
        "reader-helper-STOP.json",
        "returned-reader-STOP.json",
        "saved-scalar-correspondence.json",
        "completion.json",
        "report-ja.md",
        "finalizer-returned-STOP.json",
        "closure-admin-v1/normal-own-closure.json",
    ]
    files = [OWN / n for n in names] + [
        OUT / "Root-finite-result-acceptance.json",
        OUT / "preserve_review.py",
    ]
    closure = json.loads(
        (OWN / "closure-admin-v1/normal-own-closure.json").read_bytes()
    )
    assert (
        old.digest(OWN / "closure-admin-v1/normal-own-closure.json")
        == "145adaaa2444afdd88adb51dc121870403809d294ce0292645d2f50d8c1fec50"
    )
    assert (
        old.digest(OWN / "finalizer-returned-STOP.json")
        == "bcf3d43637f57fe095203c17e1876ebfbcac2fbbb075e13d7606b91ddf460c21"
    )
    assert closure
    old.DEST = DEST
    name = "aspiration-original208-review-v1.tar.gz"
    old.write_archive(
        name,
        files,
        "Exact original29 limited finite208 CONCLUSION_CLEAR e0/o0 and normal sameowner closure. Fixed rootAND seriousregression18/23 blocks128; Search+2.86% distinct fromwhole. No source/native/model/RAW/archive/validator/test/build/RNG/CI replay or newquota/width/refill; no universalstrength/harm/equivalence/noeffect.",
    )
    m = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    summary = dict(
        issue="quoridor-4lc.324.29.2",
        status="CLOSED_CONCLUSION_CLEAR",
        essential=0,
        ordinary=0,
        finite_conclusion="RETAIN_ROOT_ASPIRATION_OFF_NO_GAMES_FIXED_MAJOR_ROOT_REGRESSION",
        fixed_producer="f5dd7ad2/38eb656b/f8b19019 against2673",
        normal_sameowner_closure=True,
        source_retirement="Separate next canonical source stage; no reviewACK gate",
        archive=dict(
            path=name,
            sha256=m["sha256"],
            bytes=m["bytes"],
            members=len(m["members"]),
            full_stream_SHA_size_mode_verified=True,
        ),
        scientific_replay=0,
        newgames=0,
        newwidth_or_refill=0,
    )
    with (DEST / "aspiration-original208-review-v1.json").open("x") as f:
        json.dump(summary, f, indent=2)
        f.write("\n")
    print(json.dumps(summary["archive"]))


if __name__ == "__main__":
    main()
