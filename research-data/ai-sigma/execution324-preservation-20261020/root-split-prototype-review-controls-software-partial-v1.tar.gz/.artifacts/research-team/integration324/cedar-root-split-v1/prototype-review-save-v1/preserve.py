"""Save returned source review, fixed controls and original partial software once."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.DEST = DEST
    helper.ALLOWED.extend(
        [
            BASE,
            ROOT / ".worktree/assets/perf/cedar-root-split-v1",
            ROOT / ".worktree/assets/perf/cedar-root-split-review-v1",
        ]
    )
    review = (
        ROOT / ".worktree/assets/perf/cedar-root-split-review-v1/prototype-source-v1"
    )
    prep = (
        ROOT
        / ".worktree/assets/perf/cedar-root-split-v1/comparison-control-preparation-v1"
    )
    paths = [
        review / n
        for n in [
            "minimum.json",
            "control.json",
            "source-evidence.json",
            "reader-STOP.json",
            "returned-STOP.json",
        ]
    ]
    paths += [
        BASE / "prototype-review-route-v1" / n
        for n in [
            "Root-prototype-source-acceptance.json",
            "Root-depth-and-entry-correspondence-amendment.json",
        ]
    ]
    paths += [
        p
        for p in helper.files_below(prep)
        if not any(
            "deliver" in q or "note" in q or "backup" in q or "admin" in q
            for q in p.relative_to(prep).parts
        )
    ]
    software = BASE / "prototype-software-v1"
    paths += [
        software / "check-runtime-v1" / n
        for n in ["config.json", "result.json", "output.log"]
    ]
    paths += helper.files_below(software / "operation-prefix")
    for n in [
        "failure-collection-v1",
        "failure-collection-v2",
        "failure-collection-v3",
    ]:
        paths += helper.files_below(software / n)
    paths += [OUT / "preserve.py"]
    name = "root-split-prototype-review-controls-software-partial-v1.tar.gz"
    helper.write_archive(
        name,
        paths,
        "Exact8c source review SOURCE_CLEAR, original312 controls with explicit root4D6->D5 amendment and two156-call lifetimes, original4cdfc8ce AI6 PASS and Runner compile E0063 before selector entry. Prefix FAILED/cleanupfalse/guardianNULL versus persisted directreap/cleanuptrue/pendingmask retained. Metadata intake helper v1/v2 failures retained; no scientific replay. New caller repair and unfinished Runner/Clippy/release remain pending at this save. No model/image/input/DB/lock/cache.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    record = dict(
        issue="quoridor-4lc.324.28",
        status="SOURCE_CLEAR_PYTHON1_AI6_PASS_RUNNER_CALLER_TYPE_FAILURE_PENDING_REPAIR",
        source_fixed="8c078ee2 nine subjects preserved separately in root-split-prototype-fixed-source-v1.json",
        source_review="5a8338cb essential0 ordinary0 static source only",
        software="Original4cdfc8ce AI6 passed once; Runner tests not entered due existing measurement_ordering394_tests Settings literal missing root_split. Preserve failure; same author one-field None repair pending. RunnerLIB2/Clippy/genuine common image and312 remain unqualified/unentered. No AI6/Python1 replay.",
        controls="All312/312M72sessions fixed before outcomes. Originalc87 root4D6 immutable; prospective root4D5 sole amendment grounded in original26 allfour cappedD6/completedD5. Two serial sixRUN groups156calls each, fixeddepth then100ms5, no new performance/ACK gate; realfutureinputs NULL.",
        storage="Perphase192MiB forecast only supersedes earlier rough204MiB prose. Failure collector charged-roots222203904B is software outputs/cache scope, not whole historical-support-root union; cache220856320B retained for unfinished standard Cargo. No globalwalk/refund/lending or scientific quota change.",
        limits="Source/Python/AI passes do not certify Runner runtime/performance/default or312 entry. Original26/FAILED/UNKNOWN/fees/defaultOFF/pauses/seals/models/foreign preserved.",
        archive={
            k: manifest[k]
            for k in [
                "archive",
                "bytes",
                "sha256",
                "full_stream_restore_hash_mode_verified",
            ]
        },
    )
    with (DEST / "root-split-prototype-review-controls-software-partial-v1.json").open(
        "x"
    ) as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(json.dumps(record["archive"]))


if __name__ == "__main__":
    main()
