"""Collect original partial software result without replay or rewriting failure."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def main():
    loader = importlib.util.spec_from_file_location(
        "current_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    outer = json.loads((BASE / "check-runtime-v1/result.json").read_bytes())
    state = json.loads((BASE / "check-runtime-v1/state.json").read_bytes())
    prefix = json.loads((BASE / "operation-prefix/prefix-result.json").read_bytes())
    spec = json.loads((BASE / "build-intent-prefix.json").read_bytes())
    assert outer["job_id"] == "4cdfc8ce-8d0d-46c8-8757-417a2c3f4378"
    assert outer["outcome"] == "failed" and outer["exit_code"] == 1
    assert (
        outer["direct_child_reaped"]
        and outer["cleanup_complete"]
        and not outer["remaining"]
    )
    checks = prefix["checks"]
    assert len(checks) == 7 and all(r["status"] == "PASS" for r in checks[:6])
    assert checks[6]["status"] == "FAILED" and checks[6]["guardian_return"] is None
    known = []
    for index, row in enumerate(checks):
        p = Path(row["persisted_process_receipt"]["path"])
        process = json.loads(p.read_bytes())
        if index < 6:
            lc.settled(row["guardian_return"])
        else:
            assert process["direct_child_reaped"] and process["cleanup_complete"]
            assert process["remaining"] == [] and process["handle_closes_complete"]
        assert process["exit_code"] == (0 if index < 6 else 101)
        member = process["child"]
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    for member in [
        state["child"],
        *[v for v in state["launch"].values() if isinstance(v, dict) and "pid" in v],
    ]:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        if member == state["supervisor"] and fresh == lc.process.identity(member):
            continue
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    log = Path(checks[6]["full_log"]["path"]).read_text()
    assert (
        "missing field `root_split`" in log
        and "measurement_ordering394_tests.rs:79:23" in log
    )
    with lc.lease():
        lc.source_check(spec["source"])
        temporary = Path(spec["TMP"])
        assert temporary.is_dir() and not temporary.is_symlink()
        temporary.rmdir()
        failed_temporary = BASE / "failure-collection-v1/guard-TMP"
        failed_temporary.rmdir()
        (BASE / "failure-collection-v2/guard-TMP").rmdir()
        target = Path(spec["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker == dict(
            writer=spec["writer"],
            target=str(target),
            support_sha256=spec["support"]["sha256"],
        )
        cache_B = lc.allocated(target)
        seen = set()
        ended = sum(lc.allocated(p, seen=seen) for p in lc.charged_roots(spec))
    packet = dict(
        status="ACTUAL_AI6_PASS_RUNNER_TYPE_FAILURE_SOURCE_STOP",
        original_job_id=outer["job_id"],
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        passed_AI_selectors=[
            r["argv"][r["argv"].index("--lib") + 1] for r in checks[:6]
        ],
        failure="E0063 root_split field omitted in existing measurement_ordering394_tests.rs Settings literal; Runner selectors never entered",
        pending="RunnerLIB2, AI/Runner affected Clippy, genuine common release. No automatic replay of AI6/Python1; only causal caller repair and unfinished suffix.",
        original_prefix_cleanup_false_retained=True,
        original_failed_guardian_NULL_retained=True,
        persisted_failed_process_cleanup_true=True,
        persisted_signal_mask_pending_and_persist_attempted_retained=True,
        known_exact_fresh_absence=known,
        notification_supervisor=dict(
            original=state["supervisor"],
            current=lc.process.identity(
                lc.process.process_info(state["supervisor"]["pid"])
            ),
            scope="Finished command separate from notification lifetime; no idle/ACK gate",
        ),
        stopped_cache=dict(
            path=str(target),
            allocated_B=cache_B,
            retained_for="Same-source dependencies for unfinished caller-only Runner compilation; marker/support must genuinely bind derivative before reuse",
        ),
        affected_full_issued_union_allocated_B_once=ended,
        source_leases=[],
        TMP=[],
        remaining=[],
        host_future_quiet=False,
        source="No canonical mutation here; original AI core bytes retained, no tests/compiler/native/model/RAW/RNG replay",
        globalactual_fullfees_later_tails="UNKNOWN",
    )
    with (OUT / "completion-and-STOP.json").open("x") as f:
        json.dump(packet, f, indent=2)
        f.write("\n")
    print(
        json.dumps(dict(status=packet["status"], cache_B=cache_B, ended_union_B=ended))
    )


if __name__ == "__main__":
    main()
