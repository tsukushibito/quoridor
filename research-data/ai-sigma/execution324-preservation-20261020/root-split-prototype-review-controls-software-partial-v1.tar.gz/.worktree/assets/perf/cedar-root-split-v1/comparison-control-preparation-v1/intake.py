"""Read existing fixed comparison metadata, never executable/source payloads."""

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1"
OUT = Path(__file__).resolve().parent


def run(argv):
    p = subprocess.Popen(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate(timeout=60)
    code = p.wait()
    p.stdout.close()
    p.stderr.close()
    assert code == 0, (argv, stderr.decode())
    return stdout, dict(
        argv=argv,
        returncode=code,
        stdout_sha256=hashlib.sha256(stdout).hexdigest(),
        stdout_bytes=len(stdout),
        directwait_reaped=True,
        handles_closed=True,
    )


def main():
    ready, ready_return = run(["bash", "scripts/dev/beads.sh", "ready", "--json"])
    json.loads(ready)
    shown, show_return = run(
        ["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.324.28", "--json"]
    )
    row = json.loads(shown)
    if isinstance(row, list):
        row = row[0]
    assert (
        row["status"] == "in_progress"
        and row["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
    )
    receipt = dict(
        ready=ready_return,
        show=show_return,
        issue={k: row[k] for k in ["id", "status", "assignee"]},
    )
    (OUT / "own-ready-show.json").write_text(json.dumps(receipt, indent=2) + "\n")
    for relative in [
        "finite-protocol-v1.json",
        "normal26-control-preparation-v1/prepared.json",
        "normal26-runtime-v1/materialized.json",
        "normal26-runtime-v1/settings.json",
    ]:
        p = OWN / relative
        r = json.loads(p.read_text())
        print("METADATA", relative)
        if relative.endswith("finite-protocol-v1.json") or relative.endswith(
            "prepared.json"
        ):
            print(json.dumps(r, indent=2))
        else:
            print("TOPKEYS", list(r))
    files, _ = run(["rg", "--files", str(OWN)])
    selected = [
        p
        for p in files.decode().splitlines()
        if any(
            x in p
            for x in [
                "comparison",
                "comparison-control",
                "312",
                "finite-protocol",
                "normal26-control",
            ]
        )
        and not any(x in p for x in ["/numeric-", "/TMP/", "/prototype-v1/"])
    ]
    print("EXISTING_NECESSARY_CONTROL_PATHS", json.dumps(selected))


if __name__ == "__main__":
    main()
