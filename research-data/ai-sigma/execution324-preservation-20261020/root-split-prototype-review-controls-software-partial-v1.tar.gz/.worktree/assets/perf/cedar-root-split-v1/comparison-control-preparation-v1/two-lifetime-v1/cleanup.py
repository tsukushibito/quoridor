"""Return the group metadata delivery tail without touching scientific state."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import sys

from prepare_v2 import ref, save

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    path = OUT / "delivery-guard-v1/result.json"
    data = json.loads(path.read_text())
    assert data["status"] == "PASS"
    known = [data["controller"]]
    for check in data["checks"]:
        receipt = check["guardian_return"]
        assert receipt["exit_code"] == 0 and receipt["direct_child_reaped"]
        assert receipt["handle_closes_complete"] and receipt["remaining"] == []
        known.append(receipt["child"])
    fresh = []
    for old in known:
        info = process.process_info(old["pid"])
        current = process.identity(info) if info else None
        assert old != current
        fresh.append(dict(original=old, current=current, absent_or_different=True))
    removed = []
    tmp = path.parent / "TMP"
    if tmp.exists():
        children = list(tmp.iterdir())
        if children:
            assert (
                len(children) == 1
                and [str(p) for p in children] == data["TMP_remaining"]
            )
            p = children[0]
            assert p.name.startswith("uv-") and p.suffix == ".lock"
            with os.fdopen(os.open(p, os.O_RDONLY | os.O_NOFOLLOW), "rb") as f:
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
                a, b = os.fstat(f.fileno()), p.lstat()
                assert stat.S_ISREG(a.st_mode) and a.st_size == 0 and a.st_nlink == 1
                assert (a.st_dev, a.st_ino) == (b.st_dev, b.st_ino)
                p.unlink()
            removed.append(str(p))
        tmp.rmdir()
    admin = json.loads((OUT / "own-note-backup.json").read_text())
    assert admin["note"]["returncode"] == 0 and admin["backup"]["returncode"] == 0
    receipt = save(
        OUT / "returned-delivery-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            actual_delivery_guard=ref(path),
            actual_reader_STOP=data["reader_STOP"],
            correspondence=ref(OUT / "group-correspondence.json"),
            fresh_known_exact=fresh,
            directwait_reap_handles=True,
            removed_only_empty_returned_metadata_lock=removed,
            TMP=[],
            source_leases=[],
            owned_delivery_remaining=[],
            Main_reader=False,
            future_hostquiet=False,
            note_backup="PASS; no subsequentBeadschange",
            new_science_source_tests_build_native_payload_RAW_RNG=0,
            actual_cleanup_guard="cleanup-guard-v1/result.json afterreturn",
        ),
    )
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
