"""Serialize only missing normal comparison drafts; no imports/admission/entry."""

import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path("/workspaces/quoridor")
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1"
OUT = Path(__file__).resolve().parent
MIB = 1024**2


def ref(path):
    path = Path(path)
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode) and metadata.st_size < 1024**2
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(metadata.st_mode):04o}",
    )


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write("\n")
    # Standard JSON serialization/parser integrity only, never normal admission.
    assert json.loads(path.read_text()) == value
    return ref(path)


def load(path):
    return json.loads(Path(path).read_text())


def main():
    protocol_path = OWN / "finite-protocol-v1.json"
    protocol_ref = ref(protocol_path)
    assert (
        protocol_ref["sha256"]
        == "c87fbc687e812e2975b6f5c542f3a36023375f5d4068c56d471cad2c9abb73bd"
    )
    assert protocol_ref["bytes"] == 24941 and protocol_ref["mode"] == "0644"
    protocol = load(protocol_path)
    config_source = OWN / "normal26-runtime-v1/config.json"
    request_source = OWN / "diagnostic-requests.json"
    experiment_source = OWN / "normal26-control-preparation-v1/experiment.draft.json"
    run_source = OWN / "normal26-control-preparation-v1/run.draft.json"
    base_config = load(config_source)
    original_requests = load(request_source)
    assert len(original_requests) == 26 and protocol["root_order"] == list(range(26))
    # The latest explicit human/root instruction says root4 D5. The immutable
    # c87 document actually says D6. Keep that discrepancy visible, never rewrite
    # c87 or select another depth from the new diagnostic/outcomes.
    original_map = protocol["comparison"]["depth_map"]
    depth_map = copy.deepcopy(original_map)
    assert depth_map[4]["root_index"] == 4 and depth_map[4]["comparison_depth"] == 6
    depth_map[4]["comparison_depth"] = 5
    amendment = save(
        OUT / "depth-correspondence-amendment.json",
        dict(
            original_protocol=protocol_ref,
            original_pointer="/comparison/depth_map/4/comparison_depth",
            original_value=6,
            new_control_value=5,
            authority="Latest SAME High28 direct instruction: originaldepthmap inclroot4D5/upper8 retained; NOreselectingdepthfromdiagnostic or partialoutcomes",
            reason="Explicit current D5 instruction takes precedence for these pre-result drafts. c87 itself remains immutable and the mismatch is reported to Root. No saved outcome/diagnostic reselection.",
            only_changed_depth_root=4,
            other25_entries_exact=True,
            all_orders_nodes_calls_inputs_session_history_gates_unchanged=True,
            new_comparison_numerics=0,
        ),
    )
    map_ref = save(
        OUT / "depth-map.draft.json",
        dict(
            original_protocol=protocol_ref,
            amendment=amendment,
            depth_map=depth_map,
            status="NOT_RUNNABLE_PRE_RESULT_METADATA",
        ),
    )
    config = copy.deepcopy(base_config)
    removed = {
        k: config.pop(k) for k in ["neighbour_opportunity", "root_ordering_quality"]
    }
    assert "shallow_main_history" not in config and "root_aspiration" not in config
    # These are ordinary comparison, not diagnostic observer requests.
    config["record_bytes"] = 32768
    config["native_memory_bytes"] = 2684354560
    config["output_bytes"] = 20 * MIB
    assert config["tt_entries"] == 1048576 and config["use_tt"] and config["use_pvs"]
    assert config["lmr_parameters"] == dict(
        intercept=0.7844, log_divisor=2.4696, min_depth=3, min_rank=4, max_extra=3
    )
    assert (
        config["namespace"]["evaluator"]
        == "eb0fbc9357252e916b1c6314bee6f6c76d975828c15cc439cceb9766309fb5b9"
    )
    assert config["zero_stock_safe_race_method"] == "path_tail"
    mode_configs = {}
    for condition in ["fixed_depth", "100ms5"]:
        for mode in ["LOCAL1", "LAZY2", "ROOT_SPLIT2"]:
            c = copy.deepcopy(config)
            threads = 1 if mode == "LOCAL1" else 2
            c["search_threads"] = threads
            c["search_cpu_cores"] = [12] if threads == 1 else [12, 14]
            c["management_cpu_core"] = 0
            assert "root_split" not in c
            if mode == "ROOT_SPLIT2":
                c["root_split"] = True
            if condition == "100ms5":
                c["time_reserve_ms"] = 5
            else:
                assert "time_reserve_ms" not in c
            mode_configs[(condition, mode)] = save(
                OUT / "configs" / f"{condition}-{mode}.draft.json", c
            )
    # Shared schedules are by reference across all three modes and repetitions.
    schedules = {}
    for condition in ["fixed_depth", "100ms5"]:
        requests = copy.deepcopy(original_requests)
        for index, request in enumerate(requests):
            assert request["root"] == index and request["node_cap"] == 1000000
            request["depth"] = (
                depth_map[index]["comparison_depth"]
                if condition == "fixed_depth"
                else 64
            )
            request["time_limit_ms"] = None if condition == "fixed_depth" else 100
            assert not any(
                request.get(key, False)
                for key in [
                    "diagnostic",
                    "warmup",
                    "observe_lmr",
                    "observe_completed_depths",
                ]
            )
            assert request["session"] == protocol["roots"][index]["session_id"]
        assert len({r["session"] for r in requests}) == 6
        schedules[condition] = save(OUT / "requests" / f"{condition}.json", requests)
    experiment_template = load(experiment_source)
    assert experiment_template["inputs"] == protocol["input_refs"]
    assert (
        experiment_template["models"][0]["weights"]["sha256"]
        == "35cbb976be12e24ac6ff8204bf1937fd79673484ddc792065b6aabb6cbb36f0e"
    )
    run_template = load(run_source)
    plans = []
    runs = []
    experiment_refs = []
    run_refs = []
    modes = ["LOCAL1", "LAZY2", "ROOT_SPLIT2", "ROOT_SPLIT2", "LAZY2", "LOCAL1"]
    assert all(
        protocol["comparison"]["phase_orders"][key] == modes
        for key in ["fixed_depth", "100ms5"]
    )
    for condition in ["fixed_depth", "100ms5"]:
        seen = {}
        for mode in modes:
            block = len(plans)
            repetition = seen.get(mode, 0)
            seen[mode] = repetition + 1
            # No actual data/operation/TMP directories are created.
            proposed = OWN / "numeric-comparison-v1" / f"measure-{block:03d}"
            assert not proposed.exists()
            experiment = copy.deepcopy(experiment_template)
            experiment.update(
                build_manifest=None,
                config=mode_configs[(condition, mode)],
                schedule=schedules[condition],
                numerical_qualification=None,
                canonical_plan_sha256="",
                planned_slots=26,
                batch=block,
                argv=None,
            )
            experiment_ref = save(
                OUT / "experiments" / f"block-{block:03d}.draft.json", experiment
            )
            experiment_refs.append(experiment_ref)
            run = copy.deepcopy(run_template)
            run.update(
                output=str(proposed / "operation"),
                data_root=str(proposed / "data"),
                TMP=str(proposed / "TMP"),
                owned_outputs=None,
                artifact=None,
                experiment=experiment_ref,
                env=None,
                support=None,
                approved_plan=None,
                caller_sources=None,
                argv=None,
                child_cpu_cores=[0, 12] if mode == "LOCAL1" else [0, 12, 14],
                command_timeout_seconds=900,
            )
            run["limits"].update(owned_B=None, free_B=None, log_B=MIB)
            for item in run["data"]:
                item["path"] = str(proposed / "data" / Path(item["path"]).name)
            assert sum(x["limit_B"] for x in run["data"]) == 19 * MIB
            assert (
                run["limits"]["log_B"] + sum(x["limit_B"] for x in run["data"])
                == 20 * MIB
            )
            run_ref = save(OUT / "runs" / f"block-{block:03d}.draft.json", run)
            runs.append(run)
            run_refs.append(run_ref)
            plans.append(
                dict(
                    block=block,
                    condition=condition,
                    mode=mode,
                    repetition=repetition,
                    config=mode_configs[(condition, mode)],
                    requests=schedules[condition],
                    experiment=experiment_ref,
                    run=run_ref,
                    logical_calls=26,
                    sessions=6,
                    allworker_nodes_upper=26000000,
                    native_child_CPU=run["child_cpu_cores"],
                    future_support_CPU_required=len(run["child_cpu_cores"]),
                    search_cores=[12] if mode == "LOCAL1" else [12, 14],
                    main_core=0,
                    outer_core_separate=18,
                    relative_root_order=protocol["root_order"],
                    same_custody_session_reference=ref(
                        OWN
                        / "normal26-control-preparation-v1/session-correspondence.json"
                    ),
                )
            )
    assert len(plans) == 12 and sum(x["logical_calls"] for x in plans) == 312
    assert sum(x["sessions"] for x in plans) == 72
    assert sum(x["allworker_nodes_upper"] for x in plans) == 312000000
    sequence = load(OWN / "normal26-control-preparation-v1/settings.draft.json")
    sequence.update(output=str(OWN / "numeric-comparison-v1/execution-v1"), runs=runs)
    sequence["limits"].update(owned_B=None, free_B=None, log_B=MIB)
    sequence_ref = save(OUT / "settings.draft.json", sequence)
    job_ref = save(
        OUT / "job.draft.json",
        dict(
            status="NOT_RUNNABLE",
            issue="quoridor-4lc.324.28",
            cwd=str(ROOT),
            argv=None,
            resource_contract=str(OUT / "settings.draft.json"),
            max_runtime_seconds=None,
            origin=None,
            end_at=None,
            source_release=None,
            support=None,
            whole=None,
            launch_affinity_proposal=[0, 12, 14, 18],
            RUN_seconds_proposal=900,
            parent_accepted_seconds_proposal=11400,
            command_seconds_proposal=11340,
            cleanup_seconds_proposal=60,
            deadline_note="Only an ordinary finite proposal; real Root support/normal admission determines limits and freshorigin/end_at ONCE at submission; nothing is stamped now",
        ),
    )
    future_components = dict(
        native_data_and_native_capture_12x20MiB=12 * 20 * MIB,
        normal_operation_manifests_snapshots_12x2MiB=12 * 2 * MIB,
        serial_TMP_max=16 * MIB,
        outer_and_collection_logs=8 * MIB,
        saved_analysis_derived_tables_and_controls=32 * MIB,
        future_normal_binding_and_input_metadata=4 * MIB,
    )
    forecast = save(
        OUT / "future-output-forecast.json",
        dict(
            status="PROPOSAL_ONLY_NOT_A_GRANT",
            future_components_B=future_components,
            future_total_B=sum(future_components.values()),
            future_total_MiB=sum(future_components.values()) // MIB,
            native_each_B=20 * MIB,
            native_each_breakdown=dict(
                settings=1 * MIB,
                measurements=8 * MIB,
                result=10 * MIB,
                stdout_stderr_native_capture=1 * MIB,
            ),
            normal_capture_is_inside_native_20MiB=True,
            normal_copy_scope="Normal manifest stores bounded settings/result summary and file refs, not another whole native result/journal copy. Reserve2MiB per operation for normalmanifest/snapshot/metadata; existing normal26 manifest35778B is shapeevidence, not a growth certificate.",
            normal_shape_manifest=ref(
                OWN
                / "numeric-diagnostic-v1/execution-v1/run-000/operation/manifest.json"
            ),
            whole_formula="Actual ended full-root inodeunion + this339738624B future + genuinely positive margin decided by Root aftercommonsoftware/image/holding; no oldgrant reused, no authoredwholecap",
            actual_ended_union_B=None,
            actual_common_image_retention_B=None,
            actual_whole_B=None,
            actual_global_cover_B=None,
            models_images_libraries_input_copies_B=0,
            serial_TMP_not_multiplied_by12=True,
            no_globalwalk_refund_loan_compression_credit=True,
            later_tails_and_fees="UNKNOWN",
        ),
    )
    analysis = save(
        OUT / "analysis-correspondence.json",
        dict(
            status="RESULT_BEFORE_NOT_RUNNABLE",
            fixed_protocol=protocol_ref,
            depth_amendment=amendment,
            reuse_rule_pointers=[
                "/comparison/correctness",
                "/comparison/safety",
                "/comparison/serious_regression",
                "/comparison/practical_support",
            ],
            all12_blocks_all312slots_all72sessions_required=True,
            fixeddepth_denominator=156,
            clock_denominator=156,
            complete_time_ratio="ALL156 fixeddepth DepthComplete required; anycapped/unfinished makeswhole completed-time ratioUNKNOWN, no favourable subset/cap-speedup/refill",
            Search_primary="Maintained row.Search_call_seconds summed overall26roots perblock: native Search entry-to-return including helper quiet/drain. Main-before-drain/receipt are distinct nested clocks, never substituted as a favourable Search primary.",
            whole="Maintain setup/reset/drop/whole_driver and before_result_publication separately; do not relabel Search as whole. Whole-driver<=1.10 gate remains original c87.",
            main_callback_and_terminal="row.main_completed_receipt_seconds / main_receipted_completed_depth; SMP main_seconds_before_drain/all_workers_quiet_seconds/stop_drain_seconds if actualreportexists. No NULL callback invented from time/terminal.",
            work="Actual main/helper/aggregate nodes/evals/TT counters and RootSplit bounded work/wait/research fields from genuinelyqualifiedrecord; helper requested horizon is never main completeddepth. Nested counters are not additive or savednodes/time/information.",
            strata="Existing original26 root/family/STM/stock/firstcontinued/session labels and allpredecessors byrefs; stock0 two-rootshortfall stays named, no refill.",
            bounds_and_content="Typed bound/fullweightedhistory/parentrestore/mainauthority/allworker1M/quiet required. Selective trees/actions/PV maydiffer; no fullwidth speed/equality/causal/strength/defaultclaim.",
            missing="Unsupported fields/error/cap/pending/TT-only facts remainUNKNOWN; no observer/native/RAW repair or inferredzero.",
            actual_typed_record_contract_join=None,
            games_RNG_CI=0,
            diagnostic_analysis_reused_byref=ref(
                OWN / "normal26-control-preparation-v1/analysis-recipe.json"
            ),
        ),
    )
    correspondence = save(
        OUT / "normal-correspondence.json",
        dict(
            status="NOT_RUNNABLE_ONLY_SAVED_METADATA",
            blocks=plans,
            original_protocol=protocol_ref,
            depth_map=map_ref,
            depth_amendment=amendment,
            inputs=protocol["input_refs"],
            root_order=protocol["root_order"],
            common_config_source=ref(config_source),
            original_requests=ref(request_source),
            original_experiment_shape=ref(experiment_source),
            original_run_shape=ref(run_source),
            same_full_custody=ref(
                OWN / "normal26-control-preparation-v1/session-correspondence.json"
            ),
            comparison_not_diagnostic=dict(
                removed_observer_keys=removed,
                record_bytes_before=base_config["record_bytes"],
                record_bytes_now=32768,
                reason="Frozen ordinary native comparison, existing diagnostic observer OFF; no additional instrumentation/trace",
            ),
            typed_root_split="absent LOCAL1/LAZY2, true ROOT_SPLIT2 only; no explicit null/false alias needed",
            shallow_main_history="ABSENT/unconfigurable Current100%, noHalf/aspiration",
            smp_sharing_provenance="Original config omission retained/defaultOFF; no extra observer. Existing actual perworker TT counters retained; missing foreign-attribution remainsUNKNOWN.",
            current_factory_import_or_normal_admission=False,
            canonical_measurement_Plan_empty=True,
            approved_plan_None=True,
        ),
    )
    dependencies = {
        key: None
        for key in [
            "new_common_BUILD",
            "new_common_image",
            "actual_software_and_source_STOP",
            "current_source_release",
            "current_four_callers",
            "current_environment",
            "current_tools",
            "current_libraries_join",
            "current_factory_measurement_config_numerical_fields_native_CPU_join",
            "inherited641ca_structural_correspondence_only",
            "actual_typed_output_record_contract",
            "N1_support_CPU2",
            "N2_support_CPU3",
            "actual_one_whole_fullroots_capacity",
            "fresh_physical_SMT_peer_RAM_storage_owner_pause_cancel_admission",
            "origin",
            "end_at",
        ]
    }
    factory = save(
        OUT / "future-factory-join.json",
        dict(
            status="NOT_RUNNABLE_NO_TARGET_IMPORT",
            maintained_route="Existing normal sequence factory + measurement_config + numerical_fields + caller_source_refs + native_cpu_cores underONE short SH_NB finallyreleased afteractualRootsource/software inputs",
            own_prior_binding_shape=ref(OWN / "bind_normal26_v2.py"),
            binding_shape_only_not_rerun=True,
            unqualified_source_binding=ref(OWN / "prototype-v1/fixed-v1/binding.json"),
            native_affinity=dict(
                LOCAL1=[0, 12], LAZY2=[0, 12, 14], ROOT_SPLIT2=[0, 12, 14]
            ),
            support_CPU_counts_actualnativechildren=dict(
                LOCAL1=2, LAZY2=3, ROOT_SPLIT2=3
            ),
            outer18_not_in_native_CPU_count=True,
            resources_proposal=dict(
                family_B=4294967296,
                management_B=1610612736,
                native_B=2684354560,
                hostreserve_B=4294967296,
                GPU=0,
                threads=1,
            ),
            canonical_plan_sha256="",
            approved_plan=None,
            dependencies=dependencies,
            old_diagnostic_or_baseline_image_alias=False,
            no_fake_executable_argv_or_current_tuple=True,
        ),
    )
    binding = save(
        OUT / "binding.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            issue="quoridor-4lc.324.28",
            assignee="codex:01a11004-79f3-7c20-872c-432a2c347664",
            status="NOT_RUNNABLE_FIXED_LIGHT_PREPARATION",
            original_protocol=protocol_ref,
            depth_amendment=amendment,
            depth_map=map_ref,
            configs=list(mode_configs.values()),
            requests=list(schedules.values()),
            experiments=experiment_refs,
            runs=run_refs,
            sequence=sequence_ref,
            job=job_ref,
            correspondence=correspondence,
            analysis=analysis,
            factory_join=factory,
            forecast=forecast,
            original_diagnostic_calls_exhausted=26,
            original_diagnostic_nodes=25000193,
            comparison_calls_upper=312,
            comparison_nodes_upper=312000000,
            comparison_sessions=72,
            combined_calls_upper=338,
            combined_nodes_upper=338000000,
            actual_comparison_calls=0,
            actual_comparison_nodes=0,
            dependencies=dependencies,
            Main_Git_index_Cargo_docs_source_delta_writes=0,
            target_imports_tests_build_native_payload_RAW_RNG_submit=0,
            scope="Only missing normalcomparison metadata and required before-result correspondence; oldprotocol/source/request/evidence immutable; no reviewdispatch/selfclear/newcandidate/rights",
        ),
    )
    print(json.dumps(binding))


if __name__ == "__main__":
    main()
