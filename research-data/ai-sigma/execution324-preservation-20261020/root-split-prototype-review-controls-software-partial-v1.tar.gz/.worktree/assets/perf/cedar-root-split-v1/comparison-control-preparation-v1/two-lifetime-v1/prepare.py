"""Group fixed comparison RUN drafts without changing any individual RUN."""

import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
ORIGINAL = OUT.parent
OWN = ORIGINAL.parent
MIB = 1024**2


def ref(path):
    path = Path(path)
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode) and metadata.st_size < 1024**2
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(metadata.st_mode):04o}",
    )


def load_ref(expected):
    assert ref(expected["path"]) == expected
    return json.loads(Path(expected["path"]).read_text())


def save(path, value):
    path = Path(path)
    with path.open("x") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write("\n")
    assert json.loads(path.read_text()) == value
    return ref(path)


def run(argv):
    p = subprocess.Popen(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate(timeout=60)
    code = p.wait()
    p.stdout.close()
    p.stderr.close()
    assert code == 0, (argv, stderr.decode())
    return stdout, dict(
        argv=argv,
        returncode=code,
        stdout_sha256=hashlib.sha256(stdout).hexdigest(),
        stdout_bytes=len(stdout),
        directwait_reaped=True,
        handles_closed=True,
    )


def main():
    ready, ready_receipt = run(["bash", "scripts/dev/beads.sh", "ready", "--json"])
    json.loads(ready)
    shown, show_receipt = run(
        ["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.324.28", "--json"]
    )
    issue = json.loads(shown)
    if isinstance(issue, list):
        issue = issue[0]
    assert (
        issue["status"] == "in_progress"
        and issue["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
    )
    save(
        OUT / "own-ready-show.json",
        dict(
            ready=ready_receipt,
            show=show_receipt,
            issue={k: issue[k] for k in ["id", "status", "assignee"]},
        ),
    )
    original_binding_ref = ref(ORIGINAL / "binding.json")
    assert (
        original_binding_ref["sha256"]
        == "173d82d915cd4150e08eb0670aa23424e07d5e6314237fec9a2ce76a3235224e"
    )
    assert (
        original_binding_ref["bytes"] == 13173
        and original_binding_ref["mode"] == "0644"
    )
    binding = load_ref(original_binding_ref)
    sequence = load_ref(binding["sequence"])
    job = load_ref(binding["job"])
    correspondence = load_ref(binding["correspondence"])
    all_runs = sequence["runs"]
    assert len(all_runs) == 12 and len(binding["runs"]) == 12
    assert all(
        run == load_ref(reference)
        for run, reference in zip(all_runs, binding["runs"], strict=True)
    )
    root_depth = load_ref(binding["depth_map"])
    assert root_depth["depth_map"][4]["comparison_depth"] == 5
    root_acceptance = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-root-split-v1/prototype-review-route-v1/Root-depth-and-entry-correspondence-amendment.json"
    )
    acceptance_ref = ref(root_acceptance)
    # Root acceptance metadata is retained by reference, no source/proof replay.
    forecast = load_ref(binding["forecast"])
    assert forecast["future_total_B"] == 339738624
    phase_components = dict(
        native_data_and_capture_6x20MiB=6 * 20 * MIB,
        normal_metadata_6x2MiB=6 * 2 * MIB,
        serial_TMP_max=16 * MIB,
        logs=8 * MIB,
        analysis_and_control=32 * MIB,
        future_bind_metadata=4 * MIB,
    )
    assert sum(phase_components.values()) == 201326592
    mode_order = ["LOCAL1", "LAZY2", "ROOT_SPLIT2", "ROOT_SPLIT2", "LAZY2", "LOCAL1"]
    groups = []
    for index, (label, condition, start, end) in enumerate(
        [("fixed-depth", "fixed_depth", 0, 6), ("clock", "100ms5", 6, 12)]
    ):
        entries = correspondence["blocks"][start:end]
        assert [entry["mode"] for entry in entries] == mode_order
        assert all(entry["condition"] == condition for entry in entries)
        assert sum(entry["logical_calls"] for entry in entries) == 156
        assert sum(entry["sessions"] for entry in entries) == 36
        assert sum(entry["allworker_nodes_upper"] for entry in entries) == 156000000
        grouped = copy.deepcopy(sequence)
        grouped["runs"] = copy.deepcopy(all_runs[start:end])
        grouped["output"] = str(OWN / "numeric-comparison-v1" / f"{label}-execution-v1")
        assert not Path(grouped["output"]).exists()
        for local, run in enumerate(grouped["runs"]):
            assert run == all_runs[start + local]
            assert (
                run["artifact"] is None
                and run["argv"] is None
                and run["support"] is None
            )
            assert run["env"] is None and run["caller_sources"] is None
            assert run["limits"]["owned_B"] is None and run["limits"]["free_B"] is None
        seq_ref = save(OUT / f"{label}-settings.draft.json", grouped)
        grouped_job = copy.deepcopy(job)
        grouped_job.update(
            resource_contract=seq_ref["path"],
            max_runtime_seconds=None,
            origin=None,
            end_at=None,
            source_release=None,
            support=None,
            whole=None,
            parent_accepted_seconds_proposal=6000,
            command_seconds_proposal=5940,
            RUN_seconds_proposal=900,
            cleanup_seconds_proposal=60,
        )
        grouped_job["deadline_note"] = (
            "Ordinary6RUN proposal only:6x900+540normalmetadata+60cleanup. ActualRootlimits/origin/end_at bind fresh pergroup once; source/commonimage/env/libs fixed acrossscience; no node/call rights reset."
        )
        job_ref = save(OUT / f"{label}-job.draft.json", grouped_job)
        groups.append(
            dict(
                group=index,
                condition=condition,
                mode_order=mode_order,
                sequence=seq_ref,
                job=job_ref,
                original_global_block_indices=list(range(start, end)),
                local_to_original_global=[
                    dict(
                        local_run=i,
                        original_global_block=start + i,
                        original_run_ref=binding["runs"][start + i],
                        experiment=entries[i]["experiment"],
                        config=entries[i]["config"],
                        requests=entries[i]["requests"],
                    )
                    for i in range(6)
                ],
                calls=156,
                nodes_upper=156000000,
                sessions=36,
                all_individual_RUNs_byte_equivalent=True,
                native_and_operation_paths_preserved=True,
                future_components_B=phase_components,
                future_total_B=201326592,
                actual_whole_B=None,
                actual_source_release=None,
                actual_support_N1_CPU2=None,
                actual_support_N2_CPU3=None,
                actual_origin=None,
                actual_end_at=None,
            )
        )
    assert sum(group["calls"] for group in groups) == 312
    assert sum(group["nodes_upper"] for group in groups) == 312000000
    assert sum(group["sessions"] for group in groups) == 72
    note = save(
        OUT / "group-correspondence.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            issue="quoridor-4lc.324.28",
            status="NOT_RUNNABLE_FIXED_SCIENCE_TWO_SERIAL_NORMAL_LIFETIMES",
            original_binding=original_binding_ref,
            original_all12_sequence=binding["sequence"],
            original_all12_job=binding["job"],
            original_all12_future_forecast=binding["forecast"],
            original_all12_future_B=339738624,
            original_protocol=binding["original_protocol"],
            original_depth_amendment=binding["depth_amendment"],
            actual_Root_depth_acceptance=acceptance_ref,
            depth="Onlyprospective root4D5 as explicitlyaccepted; oldc87root4D6 immutable, other25exact. BasisRootsupplied pre-existingoriginal26 allfourrequested6/completed5/1M, notnewdiagnostic/pilot/outcome reselection.",
            groups=groups,
            unchanged_config_requests_input_session_analysis_refs=dict(
                configs=binding["configs"],
                requests=binding["requests"],
                inputs=correspondence["inputs"],
                custody=correspondence["same_full_custody"],
                depth_map=binding["depth_map"],
                analysis=binding["analysis"],
                factory_join=binding["factory_join"],
            ),
            maintained_owner_shape="Samequoridor.research.sequence.v1 withsix existingRUNobjects. Onlysequenceoutput andRUNlistgrouping changed; eachRUN/config/request/experiment remains exactoriginalreference. Actualmaintainedfactory consumption/admission remainsfuture, no targetimport.",
            continuation="Phase2clock isordinary continuation of all12 alreadyfixedconditions afteractualphase1native+normalcollectionSTOP andfreshholding/support, unless genuine safety/correctness failure. No promising/significance/regression-selection/reviewer/admin/ACK gate introduced; allUNKNOWN/failures/costs retained.",
            immutable_scientific_tuple_across_phases=[
                "commonqualifiedBUILD/image",
                "source/currentfour",
                "model",
                "libraries/environment",
                "allconditions/order/depths/seeds/history/TTtotal/caps/gates",
            ],
            allowed_ordinary_group_differences="Freshowningparent/outerorigin/end_at andsupport/actualholding; ownedTMP/runtimepaths contextual only. No rebuild/modelcopy/scienceselection between groups.",
            budget=dict(
                diagnostic_calls_spent=26,
                diagnostic_nodes_spent=25000193,
                comparison_calls_upper=312,
                comparison_nodes_upper=312000000,
                combined_calls_upper=338,
                combined_nodes_upper=338000000,
                actual_new_comparison_calls=0,
                percall_allworker_cap=1000000,
                no_refill_quota_reset_refund_loan=True,
            ),
            whole_planning=dict(
                original_ended_fullunion_B=114892800,
                old_all12_future_B=339738624,
                old_total_before_newimage_tails_B=454631424,
                available_commonwhole_B=364904448,
                old_shortfall_B=89726976,
                new_perphase_future_B=201326592,
                phase1_ended_plus_future_before_newimage_tails_B=316219392,
                remaining_within_available_before_newimage_tails_B=48685056,
                phase2_actualended_fullunion_B=None,
                new_prototype_image_and_source_tails_B=None,
                actual_whole_support_positive_margin=None,
                scope="Arithmetic fromsuppliedRootplanning only, noactualadmission/grant/globalwalk/deletion/compression/oldcredit. Rootresolvesactualeachendedretention+newimage+margin underdecimal50GB; phase2retainsphase1evidence once.",
            ),
            dependencies={
                k: None
                for k in [
                    "new_common_BUILD",
                    "new_common_image",
                    "software_and_source_STOP",
                    "current_four",
                    "env",
                    "libraries_join",
                    "normalfactory_numerical_source_nativeCPU_join",
                    "whole_and_support_eachgroup",
                    "fresh_physical_SMT_peer_RAM_storage_pause_cancel",
                    "owningorigin_end_at_eachgroup",
                ]
            },
            old_refs_unchanged=True,
            source_review_target_modified=False,
            Main_Git_Cargo_docs_otherOWN_writes=0,
            tests_compiler_native_payload_RAW_RNG_CI_targetimports_submit=0,
        ),
    )
    assert ref(ORIGINAL / "binding.json") == original_binding_ref
    print(json.dumps(note))


if __name__ == "__main__":
    main()
