"""Confirm only returned delivery metadata and remove its exact empty uv lock."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import sys

from prepare import ref, save

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    path = OUT / "deliver-guard-v1/result.json"
    result = json.loads(path.read_text())
    assert result["status"] == "PASS"
    known = [result["controller"]]
    for check in result["checks"]:
        r = check["guardian_return"]
        assert r["exit_code"] == 0 and r["direct_child_reaped"]
        assert r["handle_closes_complete"] and r["remaining"] == []
        known.append(r["child"])
    fresh = []
    for old in known:
        info = process.process_info(old["pid"])
        actual = process.identity(info) if info else None
        assert actual != old
        fresh.append(dict(original=old, current=actual, absent_or_different=True))
    removed = []
    tmp = path.parent / "TMP"
    if tmp.exists():
        children = list(tmp.iterdir())
        if children:
            assert (
                len(children) == 1
                and [str(p) for p in children] == result["TMP_remaining"]
            )
            p = children[0]
            assert p.name.startswith("uv-") and p.suffix == ".lock"
            with os.fdopen(os.open(p, os.O_RDONLY | os.O_NOFOLLOW), "rb") as f:
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
                a, b = os.fstat(f.fileno()), p.lstat()
                assert stat.S_ISREG(a.st_mode) and a.st_size == 0 and a.st_nlink == 1
                assert (a.st_dev, a.st_ino) == (b.st_dev, b.st_ino)
                p.unlink()
            removed.append(str(p))
        tmp.rmdir()
    admin = json.loads((OUT / "own-note-backup.json").read_text())
    assert admin["note"]["returncode"] == 0 and admin["backup"]["returncode"] == 0
    receipt = save(
        OUT / "returned-delivery-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            actual_delivery_guard=ref(path),
            actual_reader_STOP=result["reader_STOP"],
            fresh_known_exact=fresh,
            directwait_reap_handles=True,
            removed_only_exact_returned_empty_lock=removed,
            TMP=[],
            source_leases=[],
            owned_delivery_remaining=[],
            Main_reader=False,
            future_hostquiet=False,
            control_binding=ref(OUT / "binding.json"),
            note_backup="PASS, no subsequentBeadschanges",
            new_science_native_tests_sourcechanges=0,
            actual_cleanup_guard="cleanup-guard-v1/result.json afterreturn",
        ),
    )
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
