"""Preserve exact related result minimum and actual stopped readers."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-review-v1/screen-result-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    minimum = json.loads((OWN / "minimum.json").read_bytes())
    assert (
        minimum["status"] == "CONCLUSION_CLEAR"
        and minimum["essential"] == minimum["ordinary"] == 0
    )
    paths = [
        OWN / n
        for n in [
            "minimum.json",
            "control.json",
            "saved-correspondence.json",
            "reader-STOP.json",
            "returned-STOP.json",
        ]
    ]
    paths += [OUT / "Root-review-acceptance.json", OUT / "preserve.py"]
    helper.DEST = DEST
    name = "root-child-branch-work-screen-review-v1.tar.gz"
    helper.write_archive(
        name,
        paths,
        "Exact60e19c02 CONCLUSION_CLEAR and stopped readers, Root acceptance only. Structural-work screen23/26 over6series/4stockbands is separate from cappedD64/pending UNKNOWN and NULL callback. No source/test/native/model/RAW/RNG replay, no prototype/source/software/312 grant or time/strength qualification. Normal long-report/admin suffix independent and not included as a gate.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    record = dict(
        issue="quoridor-4lc.324.28.2",
        status="ROOT_ACCEPTED_CONCLUSION_CLEAR_ESSENTIAL0_ORDINARY0",
        producer="root-child-branch-work-screen26-v1.json",
        review_minimum=minimum,
        scope="Only frozen structural-work screen permits existing bounded private prototype; no performance/pruning/strength/default or numerical admission. Current partial prototype is NOTFIXED/UNBUILT_UNTYPED_UNRUN and continues independently of own reviewer close/admin.",
        archive={
            k: manifest[k]
            for k in [
                "archive",
                "bytes",
                "sha256",
                "full_stream_restore_hash_mode_verified",
            ]
        },
    )
    with (DEST / "root-child-branch-work-screen-review-v1.json").open("x") as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(record["archive"]))


if __name__ == "__main__":
    main()
