29.3 source-cost review (pre-result)

No concrete correctness/avoidable-reinitialization defect is established. No
source fix or new instrumentation/build is proposed before coarse configuration
comparison. Root's actual restoration receipt matches the necessary measured302dca2
owners. Existing64844/19c2 remains genuine available software, not a new build.

Retry69/narrow143 per fixedON repeat added observed work: nodes+4.08%, evals+2.38%,
Search+2.86%. Root18 ON64933 vs47920 nodes,3 retries; root23 ON58040 vs42967,2 retries.
These are different selective trees, not isolated per-node/implementation cost.
Root clone/context/child storage stay outside retries; commit O(1), same config
does not clear. Failed root bounds keep one cumulative budget and completed
snapshot authority. The retry repeats legality/order and original previous-depth
PV takes precedence over retry TT-best. Legal-candidate caching, failed-action
reseeding or fail-soft widening are possible future factors, not proven defects;
fresh ordering can reflect legitimate history/TT effects and rank affects LMR.
Per-iteration scores/windows/failure sides and per-attempt timing remain UNKNOWN.
No aggregate decomposition or missing-zero trace is invented.

Result-before new config-only schedule:208 fixed calls OFF/.125/.25/.5 forward
then reverse, growth2/activation3/max4 fixed. Only a promising width can advance
to act3/4/5:104 calls for two NEW settings plus52 expressly charged contemporaneous
act3 controls (156 total), avoiding historical-time qualification. Then one
selectedON vsOFF clock ABBA104. Declared maximum468/468M <=human520/520M;52 remains
unallocated/unissued, no automatic diagnostic/growth/refill. All phases use exact
original26/full predecessors/6 same-colour series,3 exposed families,stock2/6/6/6/6
zero-shortfall4,root4D5/map unchanged,1M cumulative per Search. New result-before
gates/ties/missingness and no-games/default limit are in finite-protocol-v1.json.

Phase1 alone has complete typed config/request drafts. Conditional selected
widths/configs and all actual RUN/Experiment/support/whole/source release/origin
remain genuinely absent. Existing model/library/input FileRefs only; no payload
or native/model/test/RNG/old-suite qualification. First whole proposal reuses
existing8 normal output declarations, Root actual capacity/holding/admission
remains required. No parent/reviewer/humanACK/old29close gate.
