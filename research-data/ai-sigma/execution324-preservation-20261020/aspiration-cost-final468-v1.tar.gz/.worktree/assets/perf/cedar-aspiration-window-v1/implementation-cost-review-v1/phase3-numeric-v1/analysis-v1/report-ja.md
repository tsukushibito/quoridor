# NEW29.3 有限aspiration検討の最終報告

実装auditでは、retryごとの全TT/NNUE再初期化という不具合は成立しなかった。root clone・prepare_context・child storageはretry外、commitはO(1)、同config再設定はclearしない。legal/orderの再取得、最後に完了したactionの優先、失敗境界からの拡大は設計選択であり、測定なしに欠陥と断定しない。source修正・observer追加は0。同じqualified64844/19c2で全configを比較。

phase1：width.25だけが固定promising条件を満たした。Search比.9782978985、maxON/minOFF.9969634874、major0。.125は1.0427083815でmajor16+23、.5は.9879324958だが反復分離未達。

phase2：contemporaryactivation3対比でD4=.9964301168、D5=1.0233497798。4は2%/反復分離未達、5はroot15がratio1.2990822245 AND +.0489438095秒。retryは29→18→7に減ってもSearchは改善せず、width.25/D3を維持。

最終clock：OFF-ON-ON-OFF104 calls/24sessions。固定clock gate PASS=True。receipt最大0.089134293秒、terminal p95=0.100212474、最大=0.103092521、completed depth最小=4。

| 条件 | Search合計秒 | whole_driver合計秒 | nodes | evals | completed depth分布 | stop |
|---|---:|---:|---:|---:|---|---|
| OFF | 4.997655517 | 5.628530082 | 4327420 | 3256833 | {4: 40, 5: 4, 64: 2, 6: 2, 9: 2, 22: 2} | {'TimeLimit': 50, 'DepthComplete': 2} |
| ON025_D3 | 4.751996840 | 5.557387003 | 4251914 | 3105347 | {4: 40, 5: 4, 64: 2, 7: 3, 22: 2, 9: 1} | {'TimeLimit': 50, 'DepthComplete': 2} |

同じroot/反復52対：ON depth増2、同49、減1。action差0、PV差27、valuebits差5。nominal/selective depthやaction差は強さを示さない。requestedD64の完遂資格とTimeLimit/NodeLimit UNKNOWNを混同しない。

有限判定：FINITE_WIDTH025_ACT3_RESEARCH_USEFULNESS_ONLY_NO_GAMES_NO_DEFAULT_ADOPTION。固定depthの有望幅と最終clock安全条件の範囲だけ。defaultはOFFのまま、games/CI/新試行は許可されていない。元29の重大root18+23/no128を上書きしない。比較専用sourceの最終retirementはRootが重要解釈後に処理する。

新study全体468calls/60,009,014nodes、上限520calls/520M、宣言468M。52未配分は未発行・未使用。outer合計172.974106693秒を一度計上、accepted-inclusiveは別の代替span、nested加算0。旧29や失敗metadata費用を消さない。

全root/stock/first-continued/family/series、setup/reset/drop/whole/CPU、TT/work/retry/fallback、action/PV/depthと保存分母を表へ残した。Searchの短さとwholeの短さを別々に扱い、100msで異なる選択木のnodesは同仕事速度や有用情報数ではない。retry-inclusive Searchで選びretry数だけで選ばない。

露出済み26roots/3families/6chronological series、sharedcontrol、多段config選択・overfitがある。per-iteration score/window/side、attempt時間、隣接depth scoreはUNKNOWN。追加searchworkと回避可能overheadの分解もUNKNOWN。一般速度・強さ・等価・noeffect・因果・未見IIDは主張しない。processCPUはrender含み、RSSは累積process highwater、family peak/fullfees/globalactualはUNKNOWN。

元の完了eventから4 normalmanifest/dataを一度保存回収し、実native+normalcollection/sourceSTOPを長いanalysis前にRootへ返した。native/test/validator/RAW/model/RNG/build replayなし。全pauses/seals/default/models/foreign/FAILED/NULL/UNKNOWN/50GBを維持。
