# NEW29.3 phase2: activation比較

width .25 / growth2 / maxretry4を固定し、3,4,5,5,4,3の156 callsを比較。保存済みnormal buffersのみを使用。対照は今回のactivation3の52 calls。

| activation | pooled Search / act3 | max candidate / min act3 | major roots | promising |
|---|---:|---:|---|---|
| 4 | 0.9964301167862667 | 1.003689173900271 | [] | False |
| 5 | 1.0233497798191016 | 1.0269677532586883 | [15] | False |

全156 requested DepthComplete: True。次の候補はwidth.25 / activation3。4/5のどちらも固定promising gateを通らず、phase1で選んだ3を維持。

判定は全104対比calls完了、pooled<=.98、max(candidate repeat Searchsum)/min(act3 repeat Searchsum)<1、aggregate>1.20またはroot median比>1.25 AND extra>.010秒の重大回帰0。欠測・censoringなら対比全体UNKNOWN、好都合なsubsetは使わない。

Searchとwhole/setup/reset/drop/CPU、全root/stock/first-continued/family/seriesの分母とaction/PV/value差は表へ保存。選択的な木の比較で、同じ仕事の速度改善・原因分解・一般速度・強さ・default採用は認定しない。retry数の最小化では選ばない。per-iteration window/sideとattempt時間・隣接depth scoreはUNKNOWN。

phase1 208 + phase2 156 =364calls、元520上限内。clock104は条件付き・新support未発行で未entry、52未配分を使わない。games/CI/RNG0。元29の208/major18+23/no128は不変。実native+normalcollection/sourceSTOPは分析より先にRootへ通知済み。
