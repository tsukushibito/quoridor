"""Retire comparison-only aspiration after the explicit finite review."""

import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1/retirement-v1"


def ref(p):
    b = p.read_bytes()
    return dict(
        path=str(p),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{p.stat().st_mode & 511:04o}",
    )


def main():
    review = OUT.parent / "final-route-v1/Root-source-disposition-acceptance.json"
    accepted = json.loads(review.read_bytes())
    assert accepted["source_clear"] and accepted["essential"] == 0
    stopped = (
        ROOT
        / ".worktree/assets/perf/cedar-aspiration-window-v1/implementation-cost-review-v1/phase3-numeric-v1/analysis-v1/returned-analysis-STOP.json"
    )
    assert (
        ref(stopped)["sha256"]
        == "5e73bb1ed234d013ea785faeeb755121777f6960f948338050c0d1364d0b7e9e"
    )
    binding_path = OWN / "binding.json"
    assert (
        ref(binding_path)["sha256"]
        == "32f54b6dc8d9b8b1235ce7855267618ddbe24b25c65a43b2be2618258af3e2b7"
    )
    b = json.loads(binding_path.read_bytes())
    assert len(b["subjects"]) == 17
    for name, sha in [
        (
            "source-STOP.json",
            "145057332173f93188bee20a91f3b7b42e77e0666ed63f51c61445350717c5b0",
        ),
        (
            "seal-guard-v1/result.json",
            "63351c2175c91981966a702279efc18dc978396b2c8883937f1204dff1547bab",
        ),
    ]:
        assert ref(OWN / name)["sha256"] == sha
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for row in b["subjects"]:
            actual = ref(ROOT / row["path"])
            actual.pop("path")
            assert actual == row["before_raw"], row["path"]
            if row["post"] is not None:
                assert ref(Path(row["post"]["path"])) == row["post"]
        patch = b["forward"]
        assert ref(Path(patch["path"])) == patch
        result = subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "-i", patch["path"]],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        assert (
            "offset" not in result.stdout.lower()
            and "fuzz" not in result.stdout.lower()
        )
        actuals = []
        for row in b["subjects"]:
            p = ROOT / row["path"]
            if row["after_raw"] is None:
                assert not p.exists()
                actuals.append(dict(subject=row["path"], deleted=True))
            else:
                r = ref(p)
                raw = dict(r)
                raw.pop("path")
                assert raw == row["after_raw"]
                actuals.append(dict(subject=row["path"], actual=r))
        subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
        receipt = dict(
            status="SPARSE_FINITE_ASPIRATION_COMPARISON_RETIRED_NEW_SOFTWARE_PENDING",
            issue="quoridor-4lc.324.29.3",
            binding=ref(binding_path),
            source_review_acceptance=ref(review),
            actual_final_analysis_STOP=ref(stopped),
            subjects=actuals,
            source_STOP=ref(OWN / "source-STOP.json"),
            seal_return=ref(OWN / "seal-guard-v1/result.json"),
            GNU_zero_fuzz_no_offset=result.stdout,
            protected_original_root=b["final_ordinary_root_correspondence"],
            protected_correspondence=b["protected_correspondence"],
            decision="New468 finite config usefulness only; no default or games adoption. End of explicit comparison purpose; original208/no128 immutable, no general no-effect assertion",
            candidate_reconstruction="Git302dca2 + publishedsource/release/results",
            new_science=0,
            remaining="AffectedAI/Runner all-targetClippy and genuine release, no oldtest execution; actualsourceEX guard return separate",
        )
        with (OUT / "actual-adoption.json").open("x") as f:
            json.dump(receipt, f, indent=2)
            f.write("\n")
    print(json.dumps(dict(status=receipt["status"], subjects=len(actuals))))


if __name__ == "__main__":
    main()
