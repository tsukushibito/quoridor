"""Issue the one frozen OFF versus selected aspiration clock comparison."""

import datetime
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent / "phase2-entry-v1"
BASE = OUT.parents[1]
OWN = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1"
NEW = OWN / "implementation-cost-review-v1"
MIB = 1024**2


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper = load(
        "existing_metadata", BASE / "software-v2/prefix-collection-v1/collect.py"
    )
    point_owner = load(
        "existing_point",
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/normal208-entry-v1/issue_support.py",
    )
    ref = helper.ref

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return ref(path)

    summary_path = NEW / "phase2-numeric-v1/analysis-v1/summary.json"
    summary_ref = ref(summary_path)
    assert (
        summary_ref["sha256"]
        == "39e30f21cacfa8222696356f1e10aa1a87cef0d4fceb11d3bacc53b0df11a940"
    )
    summary = json.loads(summary_path.read_bytes())
    selected = summary["selected"]
    assert selected["half_width"] == 0.25 and selected["activation_depth"] == 3
    assert summary["all156_requested_DepthComplete"] and summary["calls"] == 156
    controls = ref(NEW / "phase3-preparation-v1/controls.binding.json")
    assert (
        controls["sha256"]
        == "5bde2cb84792e3a6e55ea39e91e66c461328d41ed7adfac750243c101d8fdd0c"
    )
    stopped = ref(NEW / "phase2-numeric-v1/analysis-v1/returned-analysis-STOP.json")
    assert (
        stopped["sha256"]
        == "6dcd4d390ee2a8b9be7d8022be3451ace3d17c18eba3944ae450c37b4a36c7eb"
    )
    previous_release = json.loads(
        (PRIOR / "current-source-and-software-release.json").read_bytes()
    )
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for caller in previous_release["current_four_callers"]:
            assert ref(Path(caller["path"])) == caller
        subprocess.run(
            [
                "git",
                "diff",
                "--quiet",
                "HEAD",
                "--",
                "crates",
                "Cargo.toml",
                "Cargo.lock",
                "scripts/dev/research-lifecycle.py",
            ],
            cwd=ROOT,
            check=True,
        )
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_UNCHANGED_QUALIFIED_IMAGE_PHASE3_CONFIG_ONLY",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=subprocess.check_output(
                    ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
                ).strip(),
                prior_source_release=ref(
                    PRIOR / "current-source-and-software-release.json"
                ),
                current_four_callers=previous_release["current_four_callers"],
                software_manifest=previous_release["software_manifest"],
                artifact=previous_release["artifact"],
                actual_software_STOP=previous_release["actual_software_STOP"],
                actual_phase2_analysis_STOP=stopped,
                phase2_result=summary_ref,
                selected=selected,
                source_SH_NB_acquired_released=True,
                source_leases_remaining=[],
                qualification="Same measured source and genuine64844/19c2; config only. No new BUILD or software replay. Owning current normal factory/admission still required.",
                evaluation="UNENTERED",
                host_future_quiet=False,
            ),
        )
    roots = [
        str(OWN),
        str(BASE / "normal208-entry-v1"),
        str(OUT.parent / "phase1-entry-v1"),
        str(PRIOR),
        str(OUT),
    ]
    actual = point_owner.point(roots)
    whole = 320 * MIB
    future = 167772160
    margin = whole - future - actual["allocated_B"]
    assert margin >= 8 * MIB, (actual, margin)
    previous_capacity = json.loads((PRIOR / "capacity-and-holding.json").read_bytes())
    base_cover = previous_capacity["prior_base_known_cover_B"]
    ordinary = previous_capacity["separate_new_ordinary_save_Git_envelope_B"]
    assert base_cover + whole + ordinary <= 50000000000
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize > whole
    capacity = save(
        "capacity-and-holding.json",
        dict(
            roots=roots,
            actual_ended_point=actual,
            conservative_future_B=future,
            whole_B=whole,
            forecast_margin_B=margin,
            prior_base_known_cover_B=base_cover,
            separate_new_ordinary_save_Git_envelope_B=ordinary,
            new_known_cover_upper_B=base_cover + whole + ordinary,
            remaining_to_decimal50GB_B=50000000000 - base_cover - whole - ordinary,
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            scope="ONE phase3 full5root union includes prior ended retention once; replaces ended phase2 holding, no additive grant/refund/node lending/globalwalk",
            globalactual_later_tails_fullfees="UNKNOWN",
        ),
    )
    support = json.loads((PRIOR / "phase-support-N1.json").read_bytes())
    support.update(
        status="ISSUED_NEW29_3_PHASE3_CLOCK104_ONE_SERIAL_LIFETIME",
        current_source_adoption=release,
        actual_source_STOP=release,
        whole_B=whole,
        roots=roots,
        owned_B=whole,
        free_B=margin,
        storage_budget=dict(whole_B=whole, roots=roots),
        capacity_basis=capacity,
        total_original_calls=104,
        total_original_nodes=104000000,
        serial_runs=4,
        sessions=24,
        parent_accepted_s=4200,
        parent_command_s=4140,
        phase3_calls=104,
        phase3_nodes=104000000,
        new_usage_before_submit=364,
        cumulative_calls_after_phase3_upper=468,
        selected_width=0.25,
        condition_order=["OFF", "ON025_D3", "ON025_D3", "OFF"],
        contemporaneous_OFF_control_calls=52,
        allocation="Same64844/19c2 OFF-ON-ON-OFF, width.25/growth2/activation3/retry4, four26call serialRUNs; D64/100ms authority/explicit5ms reserve/full predecessors/Current100%. Physical search12/main0/outer18; nativeCPU2.",
        timing="CurrentMain/callers/image/libs/env/Git/Cargo/heavyIO frozen through exact phase3 actualnative+normalcollectionSTOP only",
        later_phases="Final declared stage. No further calls;52 unallocated UNISSUED, no games/refill/default adoption",
    )
    support["limits"].update(owned_B=whole, free_B=margin)
    phase_support = save("phase-support-N1.json", support)
    save(
        "issued-inputs.json",
        dict(
            release=release,
            phase_supports=[phase_support],
            capacity=capacity,
            controls=controls,
            phase2_result=summary_ref,
            new_phase3_usage_before_submit=0,
            cumulative_calls_used=364,
            evaluation="UNENTERED",
            source_leases=[],
        ),
    )
    print(
        json.dumps(
            dict(
                status="ISSUED_PHASE3",
                support=phase_support,
                release=release,
                whole_B=whole,
                margin_B=margin,
                actual_point_B=actual["allocated_B"],
            )
        )
    )


if __name__ == "__main__":
    main()
