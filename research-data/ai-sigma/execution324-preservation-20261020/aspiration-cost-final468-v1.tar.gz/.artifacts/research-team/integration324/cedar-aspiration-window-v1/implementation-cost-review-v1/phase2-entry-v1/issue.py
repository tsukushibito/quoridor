"""Issue only the frozen activation-depth phase selected by the saved width gate."""

import datetime
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent / "phase1-entry-v1"
BASE = OUT.parents[1]
OWN = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1"
NEW = OWN / "implementation-cost-review-v1"
MIB = 1024**2


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper = load(
        "existing_metadata", BASE / "software-v2/prefix-collection-v1/collect.py"
    )
    point_owner = load(
        "existing_point",
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/normal208-entry-v1/issue_support.py",
    )
    ref = helper.ref

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return ref(path)

    summary_path = NEW / "phase1-numeric-v1/analysis-v1/summary.json"
    summary_ref = ref(summary_path)
    assert (
        summary_ref["sha256"]
        == "62f6dcda54cf6b07ec3fc9d0e7383f0fe7395456b0c460ac3aef0869af6f4d5b"
    )
    summary = json.loads(summary_path.read_bytes())
    selected = summary["selected"]
    assert selected["half_width"] == 0.25 and selected["promising"]
    assert summary["all208_requested_DepthComplete"] and summary["calls"] == 208
    controls = ref(NEW / "phase2-preparation-v1/controls.binding.json")
    assert (
        controls["sha256"]
        == "e787d90e8521718643fa468c6fccb904ff056f774c8479624f04c61bcb3195be"
    )
    stopped = ref(NEW / "phase1-numeric-v1/analysis-v1/returned-analysis-STOP.json")
    assert (
        stopped["sha256"]
        == "a266a802d4fcca10d3aa35a8981c3d17782359f9c2b8a9fc69ddccfdf6e980c2"
    )
    previous_release = json.loads(
        (PRIOR / "current-source-and-software-release.json").read_bytes()
    )
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for caller in previous_release["current_four_callers"]:
            assert ref(Path(caller["path"])) == caller
        subprocess.run(
            [
                "git",
                "diff",
                "--quiet",
                "HEAD",
                "--",
                "crates",
                "Cargo.toml",
                "Cargo.lock",
                "scripts/dev/research-lifecycle.py",
            ],
            cwd=ROOT,
            check=True,
        )
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_UNCHANGED_QUALIFIED_IMAGE_PHASE2_CONFIG_ONLY",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=subprocess.check_output(
                    ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
                ).strip(),
                prior_source_release=ref(
                    PRIOR / "current-source-and-software-release.json"
                ),
                current_four_callers=previous_release["current_four_callers"],
                software_manifest=previous_release["software_manifest"],
                artifact=previous_release["artifact"],
                actual_software_STOP=previous_release["actual_software_STOP"],
                actual_phase1_analysis_STOP=stopped,
                phase1_result=summary_ref,
                selected=selected,
                source_SH_NB_acquired_released=True,
                source_leases_remaining=[],
                qualification="Same measured source and genuine64844/19c2; config only. No new BUILD or software replay. Owning current normal factory/admission still required.",
                evaluation="UNENTERED",
                host_future_quiet=False,
            ),
        )
    roots = [str(OWN), str(BASE / "normal208-entry-v1"), str(PRIOR), str(OUT)]
    actual = point_owner.point(roots)
    whole = 320 * MIB
    future = 209715200
    margin = whole - future - actual["allocated_B"]
    assert margin >= 8 * MIB, (actual, margin)
    previous_capacity = json.loads((PRIOR / "capacity-and-holding.json").read_bytes())
    base_cover = previous_capacity["prior_base_known_cover_B"]
    ordinary = previous_capacity["separate_new_ordinary_save_Git_envelope_B"]
    assert base_cover + whole + ordinary <= 50000000000
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize > whole
    capacity = save(
        "capacity-and-holding.json",
        dict(
            roots=roots,
            actual_ended_point=actual,
            conservative_future_B=future,
            whole_B=whole,
            forecast_margin_B=margin,
            prior_base_known_cover_B=base_cover,
            separate_new_ordinary_save_Git_envelope_B=ordinary,
            new_known_cover_upper_B=base_cover + whole + ordinary,
            remaining_to_decimal50GB_B=50000000000 - base_cover - whole - ordinary,
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            scope="ONE phase2 full4root union includes prior ended retention once; replaces ended phase1 holding, no additive grant/refund/node lending/globalwalk",
            globalactual_later_tails_fullfees="UNKNOWN",
        ),
    )
    support = json.loads((PRIOR / "phase-support-N1.json").read_bytes())
    support.update(
        status="ISSUED_NEW29_3_PHASE2_ACTIVATION156_ONE_SERIAL_LIFETIME",
        current_source_adoption=release,
        actual_source_STOP=release,
        whole_B=whole,
        roots=roots,
        owned_B=whole,
        free_B=margin,
        storage_budget=dict(whole_B=whole, roots=roots),
        capacity_basis=capacity,
        total_original_calls=156,
        total_original_nodes=156000000,
        serial_runs=6,
        sessions=36,
        parent_accepted_s=6000,
        parent_command_s=5940,
        phase2_calls=156,
        phase2_nodes=156000000,
        new_usage_before_submit=208,
        cumulative_calls_after_phase2_upper=364,
        selected_width=0.25,
        activation_order=[3, 4, 5, 5, 4, 3],
        contemporaneous_activation3_controls_calls=52,
        allocation="Same64844/19c2 width.25 activation3/4/5/reverse, six26call serialRUNs; Current100% root4D5 and full predecessors unchanged. Physical search12/main0/outer18; nativeCPU2.",
        timing="CurrentMain/callers/image/libs/env/Git/Cargo/heavyIO frozen through exact phase2 actualnative+normalcollectionSTOP only",
        later_phases="Only frozen phase3 clock104 conditional;52 unallocated UNISSUED, no games/refill/default adoption",
    )
    support["limits"].update(owned_B=whole, free_B=margin)
    phase_support = save("phase-support-N1.json", support)
    save(
        "issued-inputs.json",
        dict(
            release=release,
            phase_supports=[phase_support],
            capacity=capacity,
            controls=controls,
            prior208_result=summary_ref,
            new_phase2_usage_before_submit=0,
            cumulative_calls_used=208,
            evaluation="UNENTERED",
            source_leases=[],
        ),
    )
    print(
        json.dumps(
            dict(
                status="ISSUED_PHASE2",
                support=phase_support,
                release=release,
                whole_B=whole,
                margin_B=margin,
                actual_point_B=actual["allocated_B"],
            )
        )
    )


if __name__ == "__main__":
    main()
