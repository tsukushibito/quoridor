"""Collect actual storage stop and retire only the stopped owned compile cache."""

import importlib.util
import json
from pathlib import Path
import shutil

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def main():
    loader = importlib.util.spec_from_file_location(
        "current_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    outer = json.loads((BASE / "check-runtime-v1/result.json").read_bytes())
    state = json.loads((BASE / "check-runtime-v1/state.json").read_bytes())
    prefix = json.loads((BASE / "operation-prefix/prefix-result.json").read_bytes())
    proc = json.loads(
        (BASE / "operation-prefix/root-split-new-boundary-7.process.json").read_bytes()
    )
    spec = json.loads((BASE / "build-intent-prefix.json").read_bytes())
    assert outer["job_id"] == "ff814b40-582f-46ae-a40e-8edd895510b2"
    assert (
        outer["exit_code"] == 1
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and outer["remaining"] == []
    )
    assert len(prefix["checks"]) == 1 and prefix["checks"][0]["status"] == "FAILED"
    assert proc["reason"] == "Refused" and proc["error"] == "owned allocation limit"
    assert (
        proc["cleanup_complete"]
        and proc["direct_child_reaped"]
        and proc["remaining"] == []
        and proc["handle_closes_complete"]
    )
    known = []
    for member in [
        proc["child"],
        state["child"],
        *[v for v in state["launch"].values() if isinstance(v, dict) and "pid" in v],
    ]:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        if member == state["supervisor"] and fresh == lc.process.identity(member):
            continue
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    log = (BASE / "operation-prefix/root-split-new-boundary-7.full.log").read_text()
    assert "running 1 test" not in log and "test result:" not in log
    with lc.lease():
        lc.source_check(spec["source"])
        seen = set()
        roots = []
        for p in lc.charged_roots(spec):
            roots.append(dict(path=str(p), allocated_B=lc.allocated(p, seen=seen)))
        target = Path(spec["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker == dict(
            writer=spec["writer"],
            target=str(target),
            support_sha256=spec["support"]["sha256"],
        )
        cached = lc.allocated(target / "release")
        assert (target / "release").is_dir() and not (target / "release").is_symlink()
        shutil.rmtree(target / "release")
        Path(spec["TMP"]).rmdir()
    result = dict(
        status="ACTUAL_STORAGE_STOP_SOURCE_RELEASED_OWNED_COMPILER_CACHE_RETIRED",
        original_job=lc.artifact_ref(BASE / "check-runtime-v1/result.json"),
        original_prefix=lc.artifact_ref(BASE / "operation-prefix/prefix-result.json"),
        original_failed_process=lc.artifact_ref(
            BASE / "operation-prefix/root-split-new-boundary-7.process.json"
        ),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        actual_guard="Existing whole348MiB charged-root union refused compiler allocation; no failed assertion/type error or Runner selector execution",
        affected_full_root_union_once=roots,
        affected_full_root_union_allocated_B_once=sum(r["allocated_B"] for r in roots),
        retired_only=dict(
            path=str(target / "release"),
            allocated_B=cached,
            scope="Stopped owned replaceable Cargo compile cache only; exact marker/source/child cleanup verified. All source/RAW/FAILED/log/result/model/qualifiedimages retained; no scientific refund/lending or50GB increase",
        ),
        known_exact_fresh_absence=known,
        original_prefix_cleanup_false_guardian_NULL_preserved=True,
        persisted_mask_pending_persist_attempted_preserved=True,
        prior_AI6_Python1="Source NN0 PASS retained, not same-new-image empirical qualification",
        next="Common opt3/codegen1 release with LTO false frozen for all3 modes before312 outcomes, necessary unentered RunnerLIB2/Clippy then genuine image; actualsame-source runtime/admission separate",
        source_leases=[],
        TMP=[],
        remaining=[],
        host_future_quiet=False,
    )
    with (OUT / "completion-and-STOP.json").open("x") as f:
        json.dump(result, f, indent=2)
        f.write("\n")
    print(
        json.dumps(
            dict(
                status=result["status"],
                ended_union_B=result["affected_full_root_union_allocated_B_once"],
                cache_B=cached,
            )
        )
    )


if __name__ == "__main__":
    main()
