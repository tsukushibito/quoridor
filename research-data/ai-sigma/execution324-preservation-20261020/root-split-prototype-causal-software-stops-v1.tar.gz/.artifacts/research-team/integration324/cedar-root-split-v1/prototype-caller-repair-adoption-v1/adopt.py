"""Apply only the required default-OFF field in the existing test caller."""

import fcntl
import hashlib
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1/prototype-v1/caller-repair-v1"


def ref(p):
    b = p.read_bytes()
    return dict(
        path=str(p),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{p.stat().st_mode & 511:04o}",
    )


def main():
    p = OWN / "binding.json"
    binding = ref(p)
    assert (
        binding["sha256"]
        == "05a9faed47f9890127dfe043da5db119f0b6fa9339b03a79443204887bda4db2"
    )
    fixed = json.loads(p.read_bytes())
    stop = ref(OWN / "source-helper-STOP.json")
    assert (
        stop["sha256"]
        == "ebec959a082c2e991236a671bd1dab78e7eb3f50931c9e3caa9f152c492f5ca2"
    )
    subject = ROOT / fixed["subject"]
    for k in ["before", "post"]:
        assert ref(Path(fixed[k]["path"])) == fixed[k]
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        before = subject.read_bytes()
        actual = ref(subject)
        assert all(actual[k] == fixed["before"][k] for k in ["sha256", "bytes", "mode"])
        needle = b"                search_threads: None,\n"
        assert before.count(needle) == 1
        post = before.replace(needle, needle + b"                root_split: None,\n")
        assert post == Path(fixed["post"]["path"]).read_bytes()
        subject.write_bytes(post)
        actual = ref(subject)
        assert all(actual[k] == fixed["post"][k] for k in ["sha256", "bytes", "mode"])
    result = dict(
        status="SPARSE_CALLER_ONLY_ROOT_SPLIT_NONE_REPAIR_APPLIED",
        binding=binding,
        source_helper_STOP=stop,
        subjects=[dict(subject=fixed["subject"], actual=actual)],
        delta="One explicit root_split: None in existing diagnostic-OFF Settings; every other byte unchanged. No shared algorithm/default/fixture/assertion changes.",
        prior_AI6_Python1="PASS retained, no replay",
        unfinished="RunnerLIB2 plus affected AI/Runner Clippy then genuine common image; no312 entry/default qualification",
        source_leases=[],
        TMP=[],
        host_future_quiet=False,
    )
    with (OUT / "actual-adoption.json").open("x") as f:
        json.dump(result, f, indent=2)
        f.write("\n")
    print(json.dumps(dict(status=result["status"], post=actual["sha256"])))


if __name__ == "__main__":
    main()
