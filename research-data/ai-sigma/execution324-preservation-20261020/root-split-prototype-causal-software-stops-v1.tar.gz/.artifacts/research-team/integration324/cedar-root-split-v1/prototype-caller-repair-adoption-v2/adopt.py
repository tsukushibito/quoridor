"""Collect the causal caller type failure and correct only its bool OFF value."""

import fcntl
import hashlib
import json
from pathlib import Path

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent / "prototype-software-v2"


def ref(p):
    b = p.read_bytes()
    return dict(
        path=str(p),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{p.stat().st_mode & 511:04o}",
    )


def main():
    outer = json.loads((BASE / "check-runtime-v1/result.json").read_bytes())
    state = json.loads((BASE / "check-runtime-v1/state.json").read_bytes())
    prefix = json.loads((BASE / "operation-prefix/prefix-result.json").read_bytes())
    proc = json.loads(
        (BASE / "operation-prefix/root-split-new-boundary-7.process.json").read_bytes()
    )
    spec = json.loads((BASE / "build-intent-prefix.json").read_bytes())
    assert outer["job_id"] == "98999785-6fa2-4354-964f-4b42cd692343"
    assert (
        outer["exit_code"] == 1
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and not outer["remaining"]
    )
    assert len(prefix["checks"]) == 1 and prefix["checks"][0]["status"] == "FAILED"
    assert (
        proc["exit_code"] == 101
        and proc["cleanup_complete"]
        and proc["direct_child_reaped"]
        and proc["remaining"] == []
        and proc["handle_closes_complete"]
    )
    log = (BASE / "operation-prefix/root-split-new-boundary-7.full.log").read_text()
    assert (
        "expected `bool`, found `Option<_>`" in log
        and "measurement_ordering394_tests.rs:81:29" in log
    )
    known = []
    for member in [
        proc["child"],
        state["child"],
        *[v for v in state["launch"].values() if isinstance(v, dict) and "pid" in v],
    ]:
        fresh = identity(process_info(member["pid"]))
        if member == state["supervisor"] and fresh == identity(member):
            continue
        assert fresh != identity(member)
        known.append(dict(original=member, fresh=fresh))
    subject = ROOT / "crates/quoridor-runner/src/measurement_ordering394_tests.rs"
    before = ref(subject)
    assert (
        before["sha256"]
        == "9f3212009866eb50da607d05eaa7205561d097dd95fea30232609805c2ec4d70"
    )
    data = subject.read_bytes()
    needle = b"                root_split: None,\n"
    assert data.count(needle) == 1
    post = data.replace(needle, b"                root_split: false,\n")
    (OUT / "before.rs").write_bytes(data)
    (OUT / "post.rs").write_bytes(post)
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert subject.read_bytes() == data
        subject.write_bytes(post)
        Path(spec["TMP"]).rmdir()
        assert subject.read_bytes() == post
    result = dict(
        status="SPARSE_CALLER_ONLY_ROOT_SPLIT_FALSE_REPAIR_APPLIED",
        original_job=ref(BASE / "check-runtime-v1/result.json"),
        original_prefix=ref(BASE / "operation-prefix/prefix-result.json"),
        original_failed_process=ref(
            BASE / "operation-prefix/root-split-new-boundary-7.process.json"
        ),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        subject=str(subject),
        before=before,
        subjects=[dict(subject=str(subject.relative_to(ROOT)), actual=ref(subject))],
        delta="Root corrected its own prior None instruction: typed bool OFF is false. One existing Settings literal only; all other bytes unchanged. No API/default/algorithm/fixture/assertion change.",
        prior_AI6_Python1="Actual PASS reused without replay; original Runner tests still unentered",
        original_failures_preserved="4cdf E0063 plus9899 E0308, prefix false/guardianNULL versus persisted process cleanuptrue and maskpending/persistattempted; metadata intake failures retained",
        known_exact_fresh_absence=known,
        notification_supervisor=dict(
            original=state["supervisor"],
            current=identity(process_info(state["supervisor"]["pid"])),
            scope="Separate finished command versus notification lifetime, no ACK gate",
        ),
        cache="Stopped dependency cache retained for unfinished standard Cargo suffix; no previous science/code/result/model deletion",
        source_leases=[],
        TMP=[],
        remaining=[],
        host_future_quiet=False,
    )
    with (OUT / "actual-adoption.json").open("x") as f:
        json.dump(result, f, indent=2)
        f.write("\n")
    print(json.dumps(dict(status=result["status"], post=ref(subject)["sha256"])))


if __name__ == "__main__":
    main()
