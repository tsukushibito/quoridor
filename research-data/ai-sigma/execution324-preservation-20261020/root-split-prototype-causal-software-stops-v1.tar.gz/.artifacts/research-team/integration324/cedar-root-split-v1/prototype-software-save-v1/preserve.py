"""Save stopped causal software failures and caller repair without replay."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    loader = importlib.util.spec_from_file_location(
        "existing_save",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(helper)
    helper.DEST = DEST
    helper.ALLOWED.extend([BASE, ROOT / ".worktree/assets/perf/cedar-root-split-v1"])
    paths = []
    for name in [
        "prototype-software-v2",
        "prototype-software-v3",
        "prototype-software-v4",
    ]:
        scope = BASE / name
        paths += [
            scope / "check-runtime-v1" / n
            for n in ["result.json", "config.json", "output.log"]
        ]
        paths += helper.files_below(scope / "operation-prefix")
        paths += [
            p
            for p in scope.glob("*.json")
            if not p.name.startswith(("Root-current", "Root-note"))
        ]
        paths += helper.files_below(scope / "failure-collection-v1")
        paths += [
            scope / n for n in ["prepare.py", "run_prefix.py", "submit_prefix.py"]
        ]
    for name in [
        "prototype-caller-repair-adoption-v1",
        "prototype-caller-repair-adoption-v2",
    ]:
        paths += [
            p
            for p in helper.files_below(BASE / name)
            if not p.name.startswith(("Root-current", "Root-note", "backup"))
        ]
    own = (
        ROOT / ".worktree/assets/perf/cedar-root-split-v1/prototype-v1/caller-repair-v1"
    )
    paths += [
        own / n
        for n in [
            "binding.json",
            "before.rs",
            "post.rs",
            "forward.patch",
            "source-helper-STOP.json",
        ]
    ]
    paths += [OUT / "preserve.py"]
    name = "root-split-prototype-causal-software-stops-v1.tar.gz"
    helper.write_archive(
        name,
        paths,
        "Immutable9899 None/bool E0308, ff814b40 actual348MiB storage stop, d6f8e0d1 LTO=false compile success and Runner7 fixtureCPU assertion failure. Root boolfalse correction and commonopt3/codegen1 LTO=false pre-outcome amendment. OldAI6/Python1 source NN0 reuse, noRunnerPASS/genuineimage/312/default qualification. All failure and cleanup-mask scope differences preserved; only stopped owned compile cache retired afterstorageSTOP, noRAW/model/image/globalwalk/refund/lending.",
    )
    m = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    result = dict(
        issue="quoridor-4lc.324.28",
        status="AI6_PYTHON1_SOURCE_NN0_PASS_RUNNER_FIXTURE_CPU_REPAIR_PENDING",
        original="Original4cdfc8ce E0063 and AI6 PASS are preserved in prior partial-software archive. No old result or original26 replay.",
        failures=[
            dict(
                job="98999785",
                outer_seconds_once=3.6233546499861404,
                cause="Root incorrectly requested None for bool field; explicitfalse fixes onlyexistingdiagnostic caller",
            ),
            dict(
                job="ff814b40",
                outer_seconds_once=64.60840385500342,
                cause="Whole348MiB storage refusal during thin-LTO compile; actualSTOP cache retirement only",
            ),
            dict(
                job="d6f8e0d1",
                outer_seconds_once=133.41258075099904,
                cause="CommonLTO=false compiledsuccessfully, Runner7 actuallyran1/failed1: positivefixturecpu_cores[0] conflicts withteam[12,14],management0. Existingvalidator correctlyrefused; sameHigh fixture-only mainCPU12repairpending",
            ),
        ],
        compiler="All3 prospective modes useone genuineopt3/codegen1 release LTO=false image. Explicit shared compiler input fixedbeforeany312outcome; Cargo.toml productdefaults untouched. OldAI6/Python1 retain sourceNN0scope only, no new-image/oldimage empiricalparity claim.",
        source="Exact8c production changes remain accepted source-only; Rootfalse caller and pending positivefixtureCPUsetup are separate. No validator/assertion/root/kernel/TT/budget/default relaxations.",
        storage="Only stopped owned Cargo cache retired after actual fullroot refusal; actualguardovershoot/failure preserved, no retroPASS/globalactual/fullfee claim/RAW deletion/refund/lending. Next compiler envelope unchanged348MiB/50GB.",
        science="312calls/338combined notentered, no games/default promotion; two serial156groups and explicitroot4D6->D5amendment unchanged.",
        archive={
            k: m[k]
            for k in [
                "archive",
                "bytes",
                "sha256",
                "full_stream_restore_hash_mode_verified",
            ]
        },
    )
    with (DEST / "root-split-prototype-causal-software-stops-v1.json").open("x") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(json.dumps(result["archive"]))


if __name__ == "__main__":
    main()
