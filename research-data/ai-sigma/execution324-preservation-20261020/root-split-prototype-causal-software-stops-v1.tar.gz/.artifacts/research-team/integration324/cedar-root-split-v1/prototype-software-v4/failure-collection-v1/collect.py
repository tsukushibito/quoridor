"""Collect actual storage stop and retire only the stopped owned compile cache."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def main():
    loader = importlib.util.spec_from_file_location(
        "current_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    outer = json.loads((BASE / "check-runtime-v1/result.json").read_bytes())
    state = json.loads((BASE / "check-runtime-v1/state.json").read_bytes())
    prefix = json.loads((BASE / "operation-prefix/prefix-result.json").read_bytes())
    proc = json.loads(
        (BASE / "operation-prefix/root-split-new-boundary-7.process.json").read_bytes()
    )
    spec = json.loads((BASE / "build-intent-prefix.json").read_bytes())
    assert outer["job_id"] == "d6f8e0d1-cd9c-4264-bcf5-effdbbe3d9b6"
    assert (
        outer["exit_code"] == 1
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and outer["remaining"] == []
    )
    assert len(prefix["checks"]) == 1 and prefix["checks"][0]["status"] == "FAILED"
    assert proc["reason"] == "CycleStopped" and proc["exit_code"] == 101
    assert (
        proc["cleanup_complete"]
        and proc["direct_child_reaped"]
        and proc["remaining"] == []
        and proc["handle_closes_complete"]
    )
    known = []
    for member in [
        proc["child"],
        state["child"],
        *[v for v in state["launch"].values() if isinstance(v, dict) and "pid" in v],
    ]:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        if member == state["supervisor"] and fresh == lc.process.identity(member):
            continue
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    log = (BASE / "operation-prefix/root-split-new-boundary-7.full.log").read_text()
    assert "running 1 test" in log and "test result: FAILED. 0 passed; 1 failed" in log
    assert "search team count/main/unique CPU allocation" in log
    with lc.lease():
        lc.source_check(spec["source"])
        seen = set()
        roots = []
        for p in lc.charged_roots(spec):
            roots.append(dict(path=str(p), allocated_B=lc.allocated(p, seen=seen)))
        target = Path(spec["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker == dict(
            writer=spec["writer"],
            target=str(target),
            support_sha256=spec["support"]["sha256"],
        )
        cached = lc.allocated(target / "release")
        assert (target / "release").is_dir() and not (target / "release").is_symlink()
        # Retain stopped dependency/test cache for the necessary fixture-only repair.
        Path(spec["TMP"]).rmdir()
    result = dict(
        status="ACTUAL_RUNNER_TYPED_TEST_FIXTURE_CPU_FAILURE_SOURCE_STOP_CACHE_RETAINED",
        original_job=lc.artifact_ref(BASE / "check-runtime-v1/result.json"),
        original_prefix=lc.artifact_ref(BASE / "operation-prefix/prefix-result.json"),
        original_failed_process=lc.artifact_ref(
            BASE / "operation-prefix/root-split-new-boundary-7.process.json"
        ),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        actual_guard="Common LTO=false compilation completed inside unchanged whole348MiB; exactRunner7 executed once and failed because synthetic positive fixture retained cpu_cores[0] while explicit team[12,14] and management0. Existing validator correctly refused inconsistent allocation. Not a type or storage failure.",
        affected_full_root_union_once=roots,
        affected_full_root_union_allocated_B_once=sum(r["allocated_B"] for r in roots),
        retained_stopped_cache=dict(
            path=str(target / "release"),
            allocated_B=cached,
            scope="Stopped owned standard dependency cache retained after exact marker/source/child cleanup for necessary one-line synthetic fixture repair. No cache/source/RAW/FAILED/log/result/model/image deletion or scientific refund/lending/50GB increase",
        ),
        known_exact_fresh_absence=known,
        original_prefix_cleanup_false_guardian_NULL_preserved=True,
        persisted_mask_pending_persist_attempted_preserved=True,
        prior_AI6_Python1="Source NN0 PASS retained, not same-new-image empirical qualification",
        next="SameHigh private positive-fixture cpu_cores vec[12] repair only, validator/default/root code unchanged; only failing Runner7 after actual fix and unenteredRunner8/Clippy then genuine image. AI6/Python1 reuse; original FAILED/costs retained.",
        source_leases=[],
        TMP=[],
        remaining=[],
        host_future_quiet=False,
    )
    with (OUT / "completion-and-STOP.json").open("x") as f:
        json.dump(result, f, indent=2)
        f.write("\n")
    print(
        json.dumps(
            dict(
                status=result["status"],
                ended_union_B=result["affected_full_root_union_allocated_B_once"],
                cache_B=cached,
            )
        )
    )


if __name__ == "__main__":
    main()
