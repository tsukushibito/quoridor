"""Bind new prototype boundaries and affected lint using the maintained owner."""

import argparse
import copy
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/cedar-aspiration-window-v1"
)
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["prefix", "release"], required=True)
    args = parser.parse_args()
    lc = load("current_lifecycle", ROOT / "scripts/dev/research-lifecycle.py")
    helper = load(
        "existing_metadata", BASE / "software-v2/prefix-collection-v1/collect.py"
    )
    ref = helper.ref

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return ref(path)

    template = json.loads((BASE / "software-v2/build-intent-release.json").read_bytes())
    adopted = OUT.parent / "prototype-adoption-v1/actual-adoption.json"
    adoption_fact = json.loads(adopted.read_bytes())
    assert (
        adoption_fact["status"]
        == "SPARSE_ROOT_ONLY_PROTOTYPE_SOURCE_APPLIED_REVIEW_AND_NEW_SOFTWARE_PENDING"
    )
    assert len(adoption_fact["subjects"]) == 9
    repair_path = (
        OUT.parent / "prototype-caller-repair-adoption-v2/actual-adoption.json"
    )
    repair = json.loads(repair_path.read_bytes())
    assert repair["status"] == "SPARSE_CALLER_ONLY_ROOT_SPLIT_FALSE_REPAIR_APPLIED"
    old_prefix_path = (
        OUT.parent / "prototype-software-v1/operation-prefix/prefix-result.json"
    )
    old_prefix = json.loads(old_prefix_path.read_bytes())
    assert len(old_prefix["checks"]) == 7
    assert all(r["status"] == "PASS" for r in old_prefix["checks"][:6])
    assert old_prefix["checks"][6]["status"] == "FAILED"
    with lc.lease():
        source = copy.deepcopy(template["source"])
        patch = OUT / f"actual-source-{args.stage}.patch"
        patch.write_bytes(
            subprocess.check_output(
                [
                    "git",
                    "diff",
                    "--binary",
                    "--no-ext-diff",
                    "--no-textconv",
                    "HEAD",
                    "--",
                ],
                cwd=ROOT,
            )
        )
        source.update(
            commit=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
            ).strip(),
            patch=ref(patch),
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        untracked = (
            subprocess.check_output(
                [
                    "git",
                    "ls-files",
                    "--others",
                    "--exclude-standard",
                    "--",
                    "crates",
                    ".cargo",
                    "Cargo.toml",
                    "Cargo.lock",
                ],
                cwd=ROOT,
            )
            .decode()
            .splitlines()
        )
        assert set(untracked) == {
            "crates/quoridor-ai/src/root_split.rs",
            "crates/quoridor-ai/src/root_split_tests.rs",
        }
        source["untracked_inputs"] = [ref(ROOT / p) for p in sorted(untracked)]
        review = (
            ROOT
            / ".worktree/assets/perf/cedar-root-split-review-v1/prototype-source-v1/minimum.json"
        )
        reviewed = json.loads(review.read_bytes())
        assert (
            reviewed["status"] == "SOURCE_CLEAR"
            and reviewed["essential"] == reviewed["ordinary"] == 0
        )
        for witness in source["cargo_configs"]:
            path = Path(witness["path"])
            witness["file"] = ref(path) if path.exists() else None
        subjects = [
            row["actual"] for row in adoption_fact["subjects"] + repair["subjects"]
        ]
        receipts = [
            dict(name=r["name"], file=ref(old_prefix_path))
            for r in old_prefix["checks"][:6]
        ]
        if args.stage == "release":
            prefix = OUT / "operation-prefix/prefix-result.json"
            checks = json.loads(prefix.read_bytes())
            assert (
                checks["status"] == "PASS_TEST_LINT_PREFIX_ONLY"
                and checks["cleanup_complete"]
            )
            assert len(checks["checks"]) == 4 and all(
                row["status"] == "PASS" for row in checks["checks"]
            )
            receipts.extend(
                dict(name=row["name"], file=ref(prefix)) for row in checks["checks"]
            )
        adopted_ref = save(
            f"build-source-adoption-{args.stage}.json",
            dict(
                schema="quoridor.research.source-adoption.v1",
                status="ACCEPTED",
                issue="quoridor-4lc.324.28",
                source=source,
                actual_fixed_source_adoption=ref(adopted),
                actual_caller_repair=ref(repair_path),
                related_source_minimum=ref(review),
                prior_software=dict(subjects=subjects, receipts=receipts),
                scope="Original AI6 and Python1 PASS reused: sole caller root_split false repair leaves all AI owners unchanged. Only unentered RunnerLIB2 and affected2Clippy execute now, preserving release flags/features. Original missing-field and Root-induced None/bool compile failures remain immutable with original costs; no algorithm/source-core or selector change. Same-package test compilation is reused; only stopped dedicated test/lint cache is retired at package boundaries. Related SOURCE_CLEAR is static only. No old suite, model, scientific calls, baseline or diagnostic image alias.",
            ),
        )
        target = Path(template["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker["writer"] == WRITER and marker["target"] == str(target)
        assert not (target / "debug").exists()
        if args.stage == "prefix":
            previous_intent = json.loads(
                (
                    OUT.parent / "prototype-software-v2/build-intent-prefix.json"
                ).read_bytes()
            )
            assert marker["support_sha256"] == previous_intent["support"]["sha256"]
            assert (target / "release").is_dir() and not (
                target / "release"
            ).is_symlink()
        else:
            assert not (target / "release").exists()
        prior = Path(
            "/workspaces/quoridor/.artifacts/research-team/integration324/cedar-aspiration-window-v1/implementation-cost-review-v1/retirement-software-v2"
        )
        roots = [
            ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1",
            BASE / "normal208-entry-v1",
            prior.parent / "phase1-entry-v1",
            prior.parent / "phase2-entry-v1",
            prior.parent / "phase3-entry-v1",
            prior,
            ROOT / ".worktree/assets/perf/cedar-root-split-v1",
            OUT.parent,
            target,
        ]
        whole = 348 * 1024**2
        base_cover = 49608672256
        ordinary = 24 * 1024**2
        assert base_cover + whole + ordinary <= 50000000000
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
            owned_B=whole,
            free_B=32 * 1024**2,
        )
        support = save(
            f"resources-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.28",
                authority=adopted_ref,
                resources=dict(
                    worker_cpu=12,
                    guardian_cpu=16,
                    test_cpu_cores=[12, 14, 16],
                    native_threads=1,
                    GPU=0,
                    family_RAM_B=4 * 1024**3,
                    controller_included=True,
                    controller_B=64 * 1024**2,
                    host_reserve_B=4 * 1024**3,
                ),
                storage_budget=dict(
                    whole_B=whole,
                    roots=[str(p) for p in roots],
                    scope="One whole is enforced over actual owned_outputs full support-root union, including ended five-root retention, prior qualified baseline image/software, own28/Root28 source/software and serial Cargo cache/private output. Prior v1 charged_roots222203904B scope was software/cache only, not all historical roots; no retrospective relabel. Forward allocation replaces the ended point once. Separate ordinary save/Git envelope24MiB retained. New NN0 package test cache is reused for exact selectors then retired after the last selector in that package. Each stopped affected lint cache retires before the next package/release. No model/library copies/global walk/refund/node lending.",
                    prior_base_known_cover_B=base_cover,
                    separate_ordinary_save_Git_B=ordinary,
                    known_cover_upper_B=base_cover + whole + ordinary,
                    globalactual_fullfees="UNKNOWN",
                ),
                scope="Ordinary software only; no native/scientific grant",
            ),
        )
        handover = save(
            f"target-handover-{args.stage}.json",
            dict(
                schema="research.target-handover.v1",
                status="HANDED_OVER",
                target=str(target),
                target_writer=WRITER,
                fresh_private_root=str(OUT / f"private-image-{args.stage}"),
                shared_serial_pool=True,
                old_target=json.loads(
                    (
                        BASE.parent
                        / "cedar-lazy-smp-followup-v1/replacement-v1/software-v1/target-handover-release.json"
                    ).read_bytes()
                )["old_target"],
                owned_remaining=[],
                test_cpu_cores=[12, 14, 16],
                actual_source_adoption=ref(adopted),
                scope="Same stopped serial pool, not another parallel target",
            ),
        )
        cargo = template["tools"]["CARGO"]["file"]["path"]
        commands = []
        if args.stage == "prefix":
            recipe = json.loads(
                (
                    ROOT
                    / ".worktree/assets/perf/cedar-root-split-v1/prototype-v1/fixed-v1/software-recipe.json"
                ).read_bytes()
            )
            new_tests = [
                dict(package=package, features=recipe[feature_key], selector=selector)
                for package, feature_key, selector_key in [
                    ("quoridor-ai", "AI_features", "AI_exact"),
                    ("quoridor-runner", "Runner_features", "Runner_library_exact"),
                ]
                for selector in recipe[selector_key]
            ]
            assert len(new_tests) == 8
            for index, row in enumerate(new_tests[6:], start=6):
                commands.append(
                    dict(
                        name=f"root-split-new-boundary-{index + 1}",
                        role="test",
                        selector=row["selector"],
                        argv=[
                            cargo,
                            "test",
                            "--offline",
                            "--locked",
                            "--manifest-path",
                            str(ROOT / "Cargo.toml"),
                            "-j1",
                            "--message-format=json-render-diagnostics",
                            "--release",
                            "-p",
                            row["package"],
                            "--features",
                            ",".join(row["features"]),
                            "--lib",
                            row["selector"],
                            "--",
                            "--exact",
                            "--nocapture",
                            "--test-threads=1",
                        ],
                    )
                )
            for package, features, label in [
                ("quoridor-ai", "research-diagnostics", "AI"),
                (
                    "quoridor-runner",
                    "measurement,quoridor-inference/claustrophobia",
                    "Runner",
                ),
            ]:
                commands.append(
                    dict(
                        name=f"root-split-affected-{label}-Clippy",
                        role="lint",
                        argv=[
                            cargo,
                            "clippy",
                            "--offline",
                            "--locked",
                            "--manifest-path",
                            str(ROOT / "Cargo.toml"),
                            "-j1",
                            "--message-format=json-render-diagnostics",
                            "--release",
                            "-p",
                            package,
                            "--features",
                            features,
                            "--all-targets",
                            "--no-deps",
                            "--",
                            "-Dwarnings",
                        ],
                    )
                )
        build = copy.deepcopy(template["commands"][0])
        build["name"] = "root-split-common-genuine-release"
        commands.append(build)
        spec = copy.deepcopy(template)
        for key in ["admission", "intent_sha256"]:
            spec.pop(key, None)
        spec.update(
            output=str(OUT / f"operation-{args.stage}"),
            owned_outputs=[str(p) for p in roots],
            support=support,
            source_adoption=adopted_ref,
            target_handover=handover,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / f"private-image-{args.stage}/quoridor-runner"),
            TMP=str(OUT / f"build-TMP-{args.stage}"),
            test_cpu_cores=[12, 14, 16],
            command_timeout_seconds=1800,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        (target / ".research-owner.json").write_text(
            json.dumps(
                dict(
                    writer=WRITER, target=str(target), support_sha256=support["sha256"]
                ),
                indent=2,
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            f"build-admission-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Software binding only, normal runtime admission still required",
            ),
        )
        intent = save(f"build-intent-{args.stage}.json", spec)
        argv = (
            [str(lc.project_python()), "-B", str(OUT / "run_prefix.py")]
            if args.stage == "prefix"
            else [
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "build",
            ]
        )
        argv += ["--intent", intent["path"], "--sha256", intent["sha256"]]
        save(
            f"job-{args.stage}.json",
            dict(
                issue="quoridor-4lc.324",
                goal_issue="quoridor-4lc.324",
                thread_id="01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                cwd=str(ROOT),
                argv=argv,
                end_at=None,
                notify_until=None,
                max_runtime_seconds=1860,
                control_interval_seconds=30,
                notify_interval_seconds=10,
                request_timeout_seconds=25,
                log_max_bytes=16384,
                resource_contract=support["path"],
            ),
        )
        print(json.dumps(dict(stage=args.stage, intent=intent, actual_job=None)))


if __name__ == "__main__":
    main()
