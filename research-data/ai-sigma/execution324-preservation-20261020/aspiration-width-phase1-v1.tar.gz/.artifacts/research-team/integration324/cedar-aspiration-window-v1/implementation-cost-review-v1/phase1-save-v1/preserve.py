"""Preserve closed width-screen evidence without repeating scientific analysis."""

import importlib.util
import json
import re
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = (
    ROOT
    / ".worktree/assets/perf/cedar-aspiration-window-v1/implementation-cost-review-v1"
)
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    paths = [
        OWN / name
        for name in [
            "fixed-binding.json",
            "source-audit-findings.json",
            "finite-protocol-v1.json",
            "normal-controls-v1.json",
            "source-STOP.json",
            "report-ja.md",
            "finish-guard-v1/result.json",
        ]
    ]
    for directory in ["phase1-numeric-v1", "phase1-normal-runtime-v1"]:
        paths += old.files_below(OWN / directory)
    paths += old.files_below(OUT.parent / "phase1-entry-v1")
    selected = []
    for path in paths:
        relative = str(path.relative_to(ROOT)).lower()
        if (
            re.search(
                r"(^|[-_/])(ready|show|beads|backup|notes?|update|admin)([-_./]|$)",
                relative,
            )
            or "delivery" in relative
            or path.name == "notification.json"
        ):
            continue
        assert path.suffix not in {
            ".onnx",
            ".pt",
            ".so",
            ".bin",
            ".lock",
            ".pem",
            ".key",
        }
        assert path.stat().st_size <= 24 * 1024**2 and not path.is_symlink()
        selected.append(path)
    selected.append(OUT / "preserve.py")
    old.DEST = DEST
    old.write_archive(
        "aspiration-width-phase1-v1.tar.gz",
        selected,
        "New29.3 implementation-cost audit, frozen config-only width screen and one original4367525b normal208/48sessions; original29 failed-support208/no128 unchanged. Byte custody only: no source/software/native/model/validator/analysis/RNG replay. Actual task state remains Beads; no promotion or rights from this archive.",
    )
    manifest = json.loads(
        (DEST / "aspiration-width-phase1-v1.tar.gz.manifest.json").read_bytes()
    )
    print(json.dumps({key: manifest[key] for key in ["archive", "bytes", "sha256"]}))


if __name__ == "__main__":
    main()
