"""Issue the first new width screen on the unchanged genuinely qualified image."""

import datetime
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parents[1]
OWN = ROOT / ".worktree/assets/perf/cedar-aspiration-window-v1"
NEW = OWN / "implementation-cost-review-v1"
MIB = 1024**2


def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


def main():
    h = load("existing_metadata", BASE / "software-v2/prefix-collection-v1/collect.py")
    prior = load(
        "existing_point",
        ROOT
        / ".artifacts/research-team/integration324/cedar-lazy-smp-node-publication-v1/normal208-entry-v1/issue_support.py",
    )
    ref = h.ref

    def save(name, value):
        p = OUT / name
        with p.open("x") as f:
            json.dump(value, f, indent=2)
            f.write("\n")
        return ref(p)

    protocol = ref(NEW / "finite-protocol-v1.json")
    assert (
        protocol["sha256"]
        == "5986cf82bbdd67f3c5dad73a813c7a6e35ca5b83fe67180b6c411ec3a7ba2276"
    )
    p = json.loads(Path(protocol["path"]).read_bytes())
    assert (
        p["phase1"]["calls"] == 208
        and p["budget"]["declared_max_calls"] == 468
        and p["budget"]["human_upper_calls"] == 520
    )
    software_stop = BASE / "software-v2/release-collection-v1/completion-and-STOP.json"
    software = json.loads(software_stop.read_bytes())
    assert (
        software["software_manifest"]["sha256"]
        == "64844e886bb279338143043404b38db8cd6ccd48fd1f383fd5066e3a77035c49"
    )
    restore = BASE / "finite-review-restore-v1/actual-restoration.json"
    restored = json.loads(restore.read_bytes())
    assert (
        restored["new_science_used"] == 0
        and not restored["retirement_compiler_started"]
    )
    audit = ref(NEW / "source-STOP.json")
    assert (
        audit["sha256"]
        == "6ea5ef921330812467c6615840841104a2fda32e37772f80bc6cc7f30da79a54"
    )
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for r in restored["subjects"] + software["current_callers"]:
            assert ref(Path(r["path"])) == r
        subprocess.run(
            [
                "git",
                "diff",
                "--quiet",
                "HEAD",
                "--",
                "crates",
                "Cargo.toml",
                "Cargo.lock",
                "scripts/dev/research-lifecycle.py",
                "scripts/dev/test_root_aspiration.py",
                "tools/research-session/test_selected_abnormal_contract.py",
            ],
            cwd=ROOT,
            check=True,
        )
        head = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip()
        release = save(
            "current-source-and-software-release.json",
            dict(
                status="ACTUAL_UNCHANGED_QUALIFIED_IMAGE_NEW_CONFIG_ONLY_WIDTH_SCREEN",
                at=datetime.datetime.now(datetime.UTC).isoformat(),
                current_commit=head,
                current_four_callers=software["current_callers"],
                software_manifest=software["software_manifest"],
                artifact=software["artifact"],
                control_build=software["software_manifest"],
                control_artifact=software["artifact"],
                candidate_build=software["software_manifest"],
                candidate_artifact=software["artifact"],
                actual_software_STOP=ref(software_stop),
                actual_restoration=ref(restore),
                actual_restoration_guard=ref(
                    BASE / "finite-review-restore-v1/actual-returned-STOP.json"
                ),
                actual_source_audit_STOP=audit,
                source_binding=ref(NEW / "fixed-binding.json"),
                source_findings=ref(NEW / "source-audit-findings.json"),
                source_qualification="No new source fix or observer; restored17 exact measured302dca2 and currentcaller bytes. Existing genuine BUILD64844/image19c2 reused within scope, not replayed or newly rebuilt.",
                source_SH_NB_acquired_released=True,
                source_leases_remaining=[],
                numerical_scope="Inherited641ca structural only, currentfactory/numerical_fields/check/env/normal admission required",
                evaluation="UNENTERED",
                host_future_quiet=False,
            ),
        )
    roots = [str(OWN), str(BASE / "normal208-entry-v1"), str(OUT)]
    actual = prior.point(roots)
    whole = 320 * MIB
    future = 260046848
    margin = whole - future - actual["allocated_B"]
    assert margin >= 8 * MIB, (actual, margin)
    base_cover = software["current_known_cover_B"]
    ordinary_envelope = 32 * MIB
    assert base_cover + whole + ordinary_envelope <= 50000000000
    fs = os.statvfs(OWN)
    assert fs.f_bavail * fs.f_frsize > whole
    capacity = save(
        "capacity-and-holding.json",
        dict(
            roots=roots,
            scope="ONE fresh320MiB full3root union includes original29 ended retention/source and newphase1 once. Replaces original208 endedpoint+savedanalysisallowance with newfullwhole, not additive oldquota/grant or unproven credit.",
            actual_ended_point=actual,
            conservative_future_B=future,
            whole_B=whole,
            forecast_margin_B=margin,
            prior_base_known_cover_B=base_cover,
            separate_new_ordinary_save_Git_envelope_B=ordinary_envelope,
            new_known_cover_upper_B=base_cover + whole + ordinary_envelope,
            remaining_to_decimal50GB_B=50000000000
            - base_cover
            - whole
            - ordinary_envelope,
            filesystem_available_B=fs.f_bavail * fs.f_frsize,
            images_models_libraries_copy_B=0,
            old_credits_refund_loan_reset=0,
            globalactual_later_tails_fullfees="UNKNOWN",
        ),
    )
    support = json.loads(
        (BASE / "normal208-entry-v1/phase-support-N1-cpu2-v2.json").read_bytes()
    )
    support.update(
        issue="quoridor-4lc.324.29.3",
        status="ISSUED_NEW29_3_PHASE1_WIDTH_SCREEN208_ONE_SERIAL_LIFETIME",
        fixed_protocol=protocol,
        current_source_adoption=release,
        actual_source_STOP=release,
        actual_software_STOP=ref(software_stop),
        whole_B=whole,
        roots=roots,
        storage_budget=dict(whole_B=whole, roots=roots),
        owned_B=whole,
        free_B=margin,
        capacity_basis=capacity,
        total_original_calls=208,
        total_original_nodes=208000000,
        total_new_human_upper_calls=520,
        total_new_human_upper_nodes=520000000,
        declared_all_phase_calls=468,
        declared_all_phase_nodes=468000000,
        phase1_calls=208,
        phase1_nodes=208000000,
        new_usage_before_submit=0,
        unallocated_calls_not_issued=52,
        allocation="Same genuine image N1 OFF/.125/.25/.5 then reverse;8serialRUN underfresh320MiB full3roots, search12/main0/outer18/launch0,12,18; childCPU0,12/nativeCPUbudget2; no duplicate standing grant",
        conditional128="NOT_AUTHORIZED_FOR29_3; original29 128NO_GAMES immutable",
        conditional64="NOT_APPLICABLE",
        later_phases="Only fixedpromising criteria; phase2 new156 andphase3 new104 require real endedholding/newphase supports, no humanACK or oldquota transfer",
        timing="CurrentMain/callers/image/libs/env/Git/Cargo/heavyIO frozen onlythrough actualphase1native+normalcollectionSTOP. Independentlightwork allowed.",
    )
    support["limits"].update(owned_B=whole, free_B=margin)
    assert support["resources"]["CPU"] == 2
    phase_support = save("phase-support-N1.json", support)
    save(
        "issued-inputs.json",
        dict(
            release=release,
            phase_supports=[phase_support],
            capacity=capacity,
            original208_unchanged=True,
            new_phase1_usage_before_submit=0,
            source_leases=[],
            evaluation="UNENTERED",
        ),
    )
    print(
        json.dumps(
            dict(
                status="ISSUED",
                support=phase_support,
                release=release,
                whole_B=whole,
                margin_B=margin,
                actual_point_B=actual["allocated_B"],
                cover_upper_B=base_cover + whole + ordinary_envelope,
            )
        )
    )


if __name__ == "__main__":
    main()
