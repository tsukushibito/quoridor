29.3 phase1 幅比較の保存分析

全208 calls・48 sessionsがnormal PASSかつrequested DepthComplete。実nodes29,464,280、outer76.12700728408527秒を一度計上。保存bufferだけを使用し、native/validator/RAW/model/RNGは再実行していない。

| 幅 | pooled Search ON/OFF | max ON / min OFF | major roots | promising |
|---|---:|---:|---|---|
| 0.125 | 1.042708381 | 1.070336683 | [16, 23] | False |
| 0.25 | 0.978297899 | 0.996963487 | [] | True |
| 0.5 | 0.987932496 | 1.015455720 | [] | False |

固定ルールは全104対比calls完了、pooled<=.98、max(candidate repeats)/min(OFF repeats)<1、aggregate>1.20またはroot比>1.25 AND extra>.010秒の重大回帰0。retry数の最小化では選ばない。

判定: ON025。開始depth3/4/5の固定156 callsへ進める有限screen上の根拠のみ。新support/current bindingは未発行で、phase2の実callsは0。

Search bodyとwhole/setup/reset/drop/CPUは別々に表へ保存した。nodes/evals/TT/typed windowが変える選択的な木の時間であり、同一仕事の速度改善や実装overheadの分離測定ではない。OFFは複数対比で共用、26 rootsは3 exposed families/6 chronological sessionsの小標本。CI/一般速度/強さ/採用は主張しない。per-iteration中心/window/side、attempt時間はUNKNOWN。旧29の重大root回帰・no128を変更しない。

全rootの入力snapshot/weighted history一致、parent restore、合法手、requested/effective config、main completed receipt depthを保存行から確認。ONでのaction/PV/value変化は表に記録し、LMR ONのbit一致を採否条件にしない。clockは未実施。

phase1の実native+normalcollection/sourceSTOPは分析前にRootへ通知済み。phase2は新normal support/whole/source-release・fresh owning admissionが揃うまで未entry。52calls未配分、games/CI0、unused node枠貸与/補充なし。
