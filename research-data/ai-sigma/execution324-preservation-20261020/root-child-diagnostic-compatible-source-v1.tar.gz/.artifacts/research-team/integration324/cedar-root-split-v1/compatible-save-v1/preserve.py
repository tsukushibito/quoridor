"""Save fixed, unbuilt diagnostic preparation independently of completed29."""

import importlib.util
import json
import re
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1/compatible-retirement-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    paths = []
    for path in helper.files_below(OWN):
        relative = str(path.relative_to(OWN)).lower()
        if re.search(
            r"(^|[-_/])(ready|show|beads|backup|notes?|update|admin)([-_./]|$)",
            relative,
        ):
            continue
        if "delivery" in relative or "accepted-prior-closures" in relative:
            continue
        assert path.suffix not in {".onnx", ".pt", ".so", ".bin", ".pem", ".key"}
        paths.append(path)
    binding = json.loads((OWN / "binding.json").read_bytes())
    paths += [Path(row["post"]["path"]) for row in binding["subjects"]]
    paths.append(OUT / "preserve.py")
    helper.DEST = DEST
    name = "root-child-diagnostic-compatible-source-v1.tar.gz"
    helper.write_archive(
        name,
        paths,
        "Fixed private28 compatible source/representation only, exact original reviewed fragments on retired Current100% source. Three owners, two new posts and original neighbour post byreference. No Main adoption/compiler/tests/native/model/RAW/RNG or new source-clear claim; original selectors UNBUILT_UNTYPED_UNRUN. No prototype/extra science. Beads authoritative.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    record = dict(
        issue="quoridor-4lc.324.28",
        status="PRIVATE_FIXED_UNBUILT_UNTYPED_UNRUN_NOT_RUNNABLE",
        current_Main="Qualified retired baseline9513/943 unchanged",
        source_binding=binding,
        source_clear_scope="Original596ded7d applies to identical diagnostic fragments; no software or performance qualification from archive",
        diagnostic_calls=0,
        prototype_implemented=False,
        future="Root sparse adoption, original AI1/RunnerLIB1 and affected software/genuine diagnostic release, then real normal26 join/holding/admission; no ACK or29 closure gate",
        archive={
            key: manifest[key]
            for key in [
                "archive",
                "bytes",
                "sha256",
                "full_stream_restore_hash_mode_verified",
            ]
        },
    )
    with (DEST / "root-child-diagnostic-compatible-source-v1.json").open("x") as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(record["archive"]))


if __name__ == "__main__":
    main()
