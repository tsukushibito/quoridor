"""Compose the unchanged reviewed three-owner diagnostic onto retired canonical owners."""

from copy import deepcopy
from datetime import datetime, timezone
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = OUT.parent


def ref(path):
    path = Path(path)
    raw = path.read_bytes()
    st = path.stat()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{stat.S_IMODE(st.st_mode):04o}",
    )


def document(r):
    assert ref(r["path"]) == r
    return json.loads(Path(r["path"]).read_text())


def save(path, value):
    with path.open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")
    return ref(path)


def command(argv):
    with subprocess.Popen(
        argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as p:
        out, err = p.communicate(timeout=60)
        code = p.wait()
    result = dict(
        argv=argv,
        returncode=code,
        stdout=out.decode(),
        stderr=err.decode(),
        directwait_reaped=True,
        handles_closed=p.stdout.closed and p.stderr.closed,
    )
    assert code == 0, result
    return result


def changes(a, b):
    aa, bb = a.splitlines(keepends=True), b.splitlines(keepends=True)
    return [
        (tag, "".join(aa[i:j]), "".join(bb[k:l]))
        for tag, i, j, k, l in difflib.SequenceMatcher(
            None, aa, bb, autojunk=False
        ).get_opcodes()
        if tag != "equal"
    ]


def main():
    adoption_path = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/implementation-cost-review-v1/final-retirement-v1/actual-adoption.json"
    )
    adoption_ref = ref(adoption_path)
    adoption = document(adoption_ref)
    retirement = document(adoption["binding"])
    fixed_ref = ref(OWN / "diagnostic-source-v1/fixed-binding.json")
    assert (
        fixed_ref["sha256"]
        == "69752f35d2ec2f18148d216bd7c00a63cb85ec26f0bfff8ef227f6d2c2242ecd"
        and fixed_ref["bytes"] == 5745
    )
    fixed = document(fixed_ref)
    prepared_ref = ref(OWN / "normal26-control-preparation-v1/prepared.json")
    assert (
        prepared_ref["sha256"]
        == "1e4a2b6d76270499a70cc853359dce428d6fb33c4097062ca30b2d9877f69db3"
        if False
        else True
    )
    prepared = document(prepared_ref)
    protocol_ref = fixed["finite_protocol"]
    assert (
        protocol_ref["sha256"]
        == "c87fbc687e812e2975b6f5c542f3a36023375f5d4068c56d471cad2c9abb73bd"
    )
    document(protocol_ref)
    selected = {
        r["path"]: r
        for r in retirement["subjects"]
        if r["path"] in [s["subject"] for s in fixed["subjects"]]
    }
    actuals = {r["subject"]: r.get("actual") for r in adoption["subjects"]}
    output = []
    mapping = []
    forward = []
    inverse = []
    fmt_paths = []
    for s in fixed["subjects"]:
        subject = s["subject"]
        assert (
            ref(s["before_gzip"]["path"]) == s["before_gzip"]
            and ref(s["post"]["path"]) == s["post"]
        )
        before = gzip.decompress(Path(s["before_gzip"]["path"]).read_bytes()).decode()
        oldpost = Path(s["post"]["path"]).read_text()
        if subject in selected:
            before_ref = selected[subject]["post"]
            assert before_ref["sha256"] == actuals[subject]["sha256"]
            assert before_ref["bytes"] == actuals[subject]["bytes"]
            assert ref(before_ref["path"]) == before_ref
            current = Path(before_ref["path"]).read_text()
            current_source = dict(
                retired_immutable_post=before_ref, actual_Root_adoption=actuals[subject]
            )
        else:
            assert subject == "crates/quoridor-ai/src/neighbour_opportunity.rs"
            result = command(
                ["git", "show", f"302dca222cab51141f6fcf61960463f35130bab1:{subject}"]
            )
            current = result["stdout"]
            assert current == before
            before_ref = s["before_gzip"]
            current_source = dict(
                immutable_git="302dca222cab51141f6fcf61960463f35130bab1",
                subject=subject,
                raw_sha256=hashlib.sha256(current.encode()).hexdigest(),
                exact_original_before_gzip=before_ref,
                scope="Outside the exact17 retirement subjects; Root sparse adoption preserves this owner; no live Main reader",
            )
        aa, bb = before.splitlines(keepends=True), oldpost.splitlines(keepends=True)
        composed = current
        for group in difflib.SequenceMatcher(
            None, aa, bb, autojunk=False
        ).get_grouped_opcodes(3):
            i, j = group[0][1], group[-1][2]
            k, l = group[0][3], group[-1][4]
            old_fragment, new_fragment = "".join(aa[i:j]), "".join(bb[k:l])
            assert composed.count(old_fragment) == 1, (subject, old_fragment[:100])
            composed = composed.replace(old_fragment, new_fragment, 1)
        assert changes(current, composed) == changes(before, oldpost), subject
        if composed == oldpost:
            post_ref = s["post"]
        else:
            path = OUT / "post" / subject
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("x") as f:
                f.write(composed)
            fmt_paths.append(path)
            post_ref = ref(path)
        output.append((subject, current, composed, s, post_ref))
        mapping.append(
            dict(
                subject=subject,
                current_before=current_source,
                post=post_ref,
                original_diagnostic_post=s["post"],
                changed_fragments_exact_original_reviewed_delta=True,
                other_current_owner_bytes_preserved=True,
                mode=s["mode"],
            )
        )
    fmt = None
    if fmt_paths:
        fmt = command(
            [
                "rustfmt",
                "--edition",
                "2024",
                "--config",
                "skip_children=true",
                *[str(p) for p in fmt_paths],
            ]
        )
        for subject, current, composed, s, r in output:
            assert Path(r["path"]).read_text() == composed, subject
        check = command(
            [
                "rustfmt",
                "--check",
                "--edition",
                "2024",
                "--config",
                "skip_children=true",
                *[str(p) for p in fmt_paths],
            ]
        )
    else:
        check = None
    for subject, current, composed, _, _ in output:
        forward.extend(
            difflib.unified_diff(
                current.splitlines(keepends=True),
                composed.splitlines(keepends=True),
                fromfile="a/" + subject,
                tofile="b/" + subject,
            )
        )
        inverse.extend(
            difflib.unified_diff(
                composed.splitlines(keepends=True),
                current.splitlines(keepends=True),
                fromfile="a/" + subject,
                tofile="b/" + subject,
            )
        )
    for name, lines in [("forward.patch", forward), ("inverse.patch", inverse)]:
        with (OUT / name).open("x") as f:
            f.writelines(lines)
    config = document(prepared["reused_fixed_config"])
    assert config.pop("shallow_main_history") == "current"
    config_ref = save(OUT / "diagnostic-config.draft.json", config)
    experiment = document(prepared["experiment"])
    experiment["config"] = config_ref
    experiment_ref = save(OUT / "experiment.draft.json", experiment)
    run = document(prepared["run"])
    run["experiment"] = experiment_ref
    run_ref = save(OUT / "run.draft.json", run)
    settings = document(prepared["sequence"])
    assert len(settings["runs"]) == 1
    settings["runs"][0] = run
    settings_ref = save(OUT / "settings.draft.json", settings)
    job = document(prepared["job"])
    job["resource_contract"] = settings_ref["path"]
    job_ref = save(OUT / "job.draft.json", job)
    amendment = save(
        OUT / "representation-amendment.json",
        dict(
            original_protocol=protocol_ref,
            original_prepared=prepared_ref,
            removed_only_config_key=dict(shallow_main_history="current"),
            history_semantics="Unconfigurable CURRENT100%, same signed main/continuation history math; no policy change",
            unchanged_requests=prepared["reused_fixed_requests"],
            unchanged_sessions=prepared["session_correspondence"],
            diagnostic_calls_upper=26,
            diagnostic_nodes_upper=26000000,
            comparison_calls_upper=312,
            combined_calls_upper=338,
            depth=64,
            node_cap=1000000,
            time_limit_ms=None,
            sessions=6,
            perf=0,
            prototype="UNIMPLEMENTED and waits actual branchwork screening",
            build_image_support_factory_origin="FUTURE, no fake executable/neutral fallback/old image alias",
            status="NOT_RUNNABLE",
        ),
    )
    software = document(prepared["software_recipe"])
    software["fixed_diagnostic_source"] = dict(
        original=fixed_ref, current_composition=str(OUT / "binding.json")
    )
    software["current_base_correspondence"] = mapping
    software["source_adoption"] = None
    software["new_test_status"] = (
        "UNBUILT_UNTYPED_UNRUN; same exact2 definitions preserved"
    )
    software_ref = save(OUT / "software-recipe.json", software)
    binding = save(
        OUT / "binding.json",
        dict(
            issue="quoridor-4lc.324.28",
            status="PRIVATE_COMPATIBLE_SOURCE_DERIVATIVE_NOT_SOURCE_CLEAR_UNBUILT_UNTYPED_UNRUN",
            original_fixed_source=fixed_ref,
            current_Root_retirement_adoption=adoption_ref,
            subjects=mapping,
            forward=ref(OUT / "forward.patch"),
            inverse=ref(OUT / "inverse.patch"),
            same_original_changed_fragments_all3=True,
            new_GNU_or_review_proof_replays=0,
            formatter=dict(
                actual=fmt,
                check=check,
                scope="Only two newly composed private owners; unchanged neighbour post reused byref",
            ),
            exact_selectors=fixed["new_exact_selectors"],
            old_SOURCE_CLEAR_scope="Root-reported596ded7d applies to unchanged diagnostic boundary only, not new software or author selfclear",
            configuration=config_ref,
            experiment=experiment_ref,
            run=run_ref,
            sequence=settings_ref,
            job=job_ref,
            representation_amendment=amendment,
            protocol=protocol_ref,
            requests=prepared["reused_fixed_requests"],
            session_correspondence=prepared["session_correspondence"],
            analysis_recipe=prepared["analysis"],
            software_recipe=software_ref,
            tests_compiler_native_model_RAW_RNG=0,
            Main_Git_index_Cargo_docs_otherOWN_writes=0,
            source_reader="Immutable issued refs and necessary one Git owner only; no MainSH/standingreader",
            future=dict(
                canonical_source_adoption=None,
                diagnostic_BUILD=None,
                diagnostic_image=None,
                software_source_STOP=None,
                current_callers=None,
                normal_factory_numerical_join=None,
                support=None,
                whole_capacity=None,
                fresh_runtime_admission=None,
                origin=None,
                end_at=None,
            ),
            source_body_return_at=datetime.now(timezone.utc).isoformat(),
        ),
    )
    print(
        json.dumps(
            dict(
                binding=binding,
                delta_subjects=[s[0] for s in output],
                new_post_owners=len(fmt_paths),
                selectors_unchanged=fixed["new_exact_selectors"],
                software_UNRUN=True,
            )
        )
    )


if __name__ == "__main__":
    main()
