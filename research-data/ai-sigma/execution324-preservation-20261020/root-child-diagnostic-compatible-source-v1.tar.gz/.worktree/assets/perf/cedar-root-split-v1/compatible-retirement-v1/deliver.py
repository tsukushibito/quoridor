"""One returned fixed diagnostic-source handoff to integration324."""

from datetime import datetime, timezone
import json
import sys
from compose_v2 import ROOT, OUT, ref, save, command

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    fresh = []
    guards = []
    for name in ["finish-guard-v1", "finish-guard-v2"]:
        p = OUT / name / "result.json"
        g = json.loads(p.read_text())
        assert g["TMP_remaining"] == []
        assert g["status"] == ("FAILED" if name.endswith("v1") else "PASS")
        ids = [g["controller"]]
        for c in g["checks"]:
            r = c["guardian_return"]
            if r is None:
                r = json.loads((p.parent / (c["name"] + ".process.json")).read_text())
            assert (
                r["direct_child_reaped"]
                and r["cleanup_complete"]
                and r["handle_closes_complete"]
                and r["remaining"] == []
            )
            ids.append(r["child"])
        for old in ids:
            info = process.process_info(old["pid"])
            actual = process.identity(info) if info else None
            assert actual != old
            fresh.append(
                dict(original=old, current=actual, exact_absent_or_different=True)
            )
        guards.append(ref(p))
    returned = save(
        OUT / "returned-source-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            source_STOP=ref(OUT / "source-helper-STOP.json"),
            actual_finish_guards=guards,
            fresh_known_exact_IDs=fresh,
            source_leases=[],
            TMP=[],
            native_remaining=[],
            Main_reader=False,
            future_hostquiet=False,
            scope="Actual private source/helper/admin returned. Current bounded delivery lifetime separate; no standing lease",
        ),
    )
    binding = json.loads((OUT / "binding.json").read_text())
    refs = dict(
        binding=ref(OUT / "binding.json"),
        completion=ref(OUT / "completion.json"),
        forward=ref(OUT / "forward.patch"),
        inverse=ref(OUT / "inverse.patch"),
        source_STOP=returned,
        ordinary_point=ref(OUT / "ordinary-affected-point.json"),
        config=binding["configuration"],
        software_recipe=binding["software_recipe"],
        amendment=binding["representation_amendment"],
        future=binding["future"],
    )
    text = (
        """Beads issue: quoridor-4lc.324 / SAME High28 actual compatible diagnostic source + normalrepresentation derivative returned.

Original source69752/protocolc87f/prepared1e4a2 IMMUTABLE. Applied the EXACT
original reviewed diagnostic change fragments to retired Current100%/noasp
canonical owners: alpha3a17->89b9,measurement305f->d0a7. Neighbour5774baseline
immutableGit302dca equals originalbefore, e473 diagnosticpost REUSED byreference.
Only2newpostowners, no fulloldalpha/measurement overwrite and no source mirror.
All outside currentowner bytes remain intact; no Half/aspiration restoration.
Three owner patches contain only identical original rootchild nodes/evals
before/after accounting + bounded completediteration/partialwork output. No
newsemanticcounter/testdefinition or Search/NNhook. Runtime.rs untouched.
No oldGNU/sourceproof/review replay; scoped2ownerRustfmt+checkPASS. ExistingMax
596ded7d SOURCE_CLEARscope unchanged where identical, authorNOTselfclearing
newsource/software. Original2exactAI1/RunnerLIB1 selectors/assertions preserved
UNBUILT_UNTYPED_UNRUN. Sourceerrors v1 helperlint only(neverbodyentered) retained;
v2causalhelpernames/importfixes do not alterdiagnostic. No compiler/tests/native/
model/inputpayload/RAW/RNG/GitMain/Cargo write. Rootnewbaseline9513/943 is actual
BASELINE only, not this diagnostic software and not performancequalification.

ConfigONLY representation derivative: removed shallow_main_history=current,
CURRENT100% remains unconfigurable/same signed main+continuationmath. Newconfig
5e3b; causalExperiment/RUN/settings/jobrefs updated only, existingrequests/session/
analysisrecipe/protocol/gates retainedbyref. NOT_RUNNABLE, no fabricatedPlan/
executable/support/currentfactory. Original26genuineprefix6chronologicalseries/
D64/1M/timeNone/N1/Control/OffShadow/root_ordering_quality/perf0/fullpredecessors/
stockbins andscreen rule unchanged; actualdiagnostic0. No prototype beforeactual
branchwork screening. Prospective312/combined338upper/games0 unchanged; no29
calls loan/27conditionalgrant change/newobserver/sourceframework/newactor.

Specific genuine nextinputs only: Root sparseadoption ofthese3owners atactual
compatiblewrite boundary, onlyexistingAI1+RunnerLIB1 exact-running1/newaffected
Clippy/genuineDIAGNOSTICrelease+Build/image/sourceSTOP, currentnormalfactory/
numerical641caSTRUCTURAL/currentfour/env/libs/inputsbyref, freshissued whole/support/
physicalSMTpeer/RAM/host4/pausecancel/storage/origin/end_at/serializer. Baseline
software hold is not an authorprep gate; no oldimagealias/fakepair/oldmodelproof.
No ACK/parent/29close/reviewadmin gate forRootordinarynextstage.

ActualsourceCPU2/core1 sibling3unused/G18/F1GiB incl64management/host4/G0 guards
returned/directwaitreap/handles/freshknownIDs absent-different/TMP/sourceleases[]/
noMainreader/no futurequiet. Meaningfulown28note+backupPASS/sameownerin_progress.
One newcompatible subtree affectedpoint only; oldholding/globalwalk/refund/loan0,
later tails/globalactual/fullfees UNKNOWN. RootsoleMain/Git/index/Cargo/docs.
Own29.3+29 normalacceptedclosure follows this actualsource/deliveryhelperSTOP
sequentially, independentfrom28. Allpauses/seals/default/models/foreign/FAILED/
NULL/UNKNOWNfees/50GB/27/16.1/consultation8 preserved.

"""
        + json.dumps(refs, indent=2)
        + "\n"
    )
    p = OUT / "Root-compatible-source-handoff.txt"
    p.write_text(text)
    r = command(
        [
            "bash",
            "scripts/dev/research-session.sh",
            "send",
            "--thread",
            "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--issue",
            "quoridor-4lc.324",
            "--cwd",
            str(ROOT),
            "--body-file",
            str(p),
        ]
    )
    delivery = save(OUT / "Root-delivery-return.json", r)
    print(
        json.dumps(
            dict(
                delivered=True,
                binding=ref(OUT / "binding.json"),
                source_STOP=returned,
                delivery=delivery,
            )
        )
    )


if __name__ == "__main__":
    main()
