"""Seal returned private source correspondence and one ordinary affected point."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import stat
import sys
from compose_v2 import ROOT, OUT, ref, save, command

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

ACTOR = "codex:01a11004-79f3-7c20-872c-432a2c347664"
ISSUE = "quoridor-4lc.324.28"


def beads(label, args):
    r = command(["bash", "scripts/dev/beads.sh", *args])
    save(OUT / ("authority-" + label + ".json"), r)
    return r


def main():
    fixed = json.loads((OUT / "binding.json").read_text())
    guards = []
    fresh = []
    for name in ["source-guard-v1", "source-guard-v2"]:
        p = OUT / name / "result.json"
        g = json.loads(p.read_text())
        assert g["TMP_remaining"] == []
        assert g["status"] == ("FAILED" if name.endswith("v1") else "PASS")
        ids = [g["controller"]]
        for c in g["checks"]:
            r = c["guardian_return"]
            if r is None:
                r = json.loads((p.parent / (c["name"] + ".process.json")).read_text())
            assert (
                r["direct_child_reaped"]
                and r["handle_closes_complete"]
                and r["cleanup_complete"]
                and r["remaining"] == []
            )
            ids.append(r["child"])
        for old in ids:
            info = process.process_info(old["pid"])
            actual = process.identity(info) if info else None
            assert actual != old
            fresh.append(
                dict(original=old, current=actual, exact_absent_or_different=True)
            )
        guards.append(ref(p))
    beads("ready", ["ready", "--json"])
    own = json.loads(beads("show", ["show", ISSUE, "--json"])["stdout"])[0]
    assert own["assignee"] == ACTOR and own["status"] == "in_progress"
    note = (
        "OWN28 compatible-retirement-v1 actualprivate sparse composition onto Root17retired Current100%/noasp source. Original reviewed69752 diagnostic changed fragments EXACT for alpha/neighbour/measurement, no newsemanticobserver/testdefinition. Currentalpha3a17->89b9/currentmeasurement305f->d0a7; neighbour5774 before/e473 post reusedexact byref, no mirror. Only2new privatepostowners, alloutsidecurrentownerbytes preserved; sourcebefore refs from actualRootadoption/immutable302dca oneowner, no liveMainSH. ScopedRustfmt/checkPASS; oldGNU/review/sourceproof notrerun. Configrepresentation removesONLYretiredshallow_main_history=current, Current100%math unchanged; newconfig5e3b andcausalExperiment/RUN/settings/job derivativeNOT_RUNNABLE. Frozenprotocolc87f/requests/fullhistory/sessions/26D64/1M/timeNone/perf0/Control/N1/fullpredecessors/screen gates unchanged, prototypeUNIMPLEMENTEDpendingactualbranchwork plausibility. Original2exactAI1/RunnerLIB1 selectors retainedUNBUILT_UNTYPED_UNRUN; authorcompiler/tests/native/model/inputpayload/RAW/RNG0. Rootbaseline9513/943 unmeasuredbaseline isNOTnewdiagnostic image. ActualfutureRootadoption/newAI1RunnerLIB1+affectedClippy/genuineBUILDimage/softwareSTOP/currentfactory/numerical/current4/env/libs/support/whole/freshphysicalRAMcancelstorage/origin/end_at remain genuine inputs, no fakealiases/newgrant. Sourcehelperv1 lint unusedimport/ambiguousnames FAILED BEFOREbody, v2causalhelper-onlyfixPASS/oldfailuresimmutable. Actualreturnedhelpersdirectwait/reap/handles/freshIDs/TMPleases[]/no Mainreader, one newOWNcompatible subtreeaffectedpoint only. Sameownerin_progress/note+backupactualmanagementboundary. RootsoleMain/Git/index/Cargo/docs/otherOWNwrites0, no selfclear/reviewdispatch/newactor/noACKgate. Original29.3 finite468exhausted/no morecalls;27conditional64/28combined338/16.1/pauses/seals/defaultmodels/foreign/FAILED/NULL/UNKNOWNfees/50GBheld. Binding: "
        + str(OUT / "binding.json")
    )
    beads("note", ["update", ISSUE, "--append-notes", note])
    beads("backup", ["backup", "sync", "--json"])
    stop = save(
        OUT / "source-helper-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            binding=ref(OUT / "binding.json"),
            returned_guards=guards,
            fresh_exact_IDs=fresh,
            source_leases=[],
            TMP=[],
            native_remaining=[],
            Main_reader=False,
            native_tests_compiler=0,
            normal_note_backup="PASS",
            current_finisher_identity=process.identity(
                process.process_info(os.getpid())
            ),
            actual_finisher_return="finish-guard-v2/result.json after this body",
            future_hostquiet=False,
        ),
    )
    total = logical = count = 0
    seen = set()
    for parent, _, files in os.walk(OUT):
        for name in files:
            p = Path(parent) / name
            st = p.lstat()
            assert stat.S_ISREG(st.st_mode)
            key = st.st_dev, st.st_ino
            if key not in seen:
                seen.add(key)
                total += st.st_blocks * 512
                logical += st.st_size
                count += 1
    point = save(
        OUT / "ordinary-affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            roots=[str(OUT)],
            allocated_B=total,
            logical_B=logical,
            files=count,
            one_new_subtree_only=True,
            old_OWN_holding_rewalk_recharge=False,
            globalactual_later_tails_fees="UNKNOWN",
            scope="Only new compatible-retirement-v1 ordinary source/config subtree ONCE, later finisher/message tails UNKNOWN; no globalwalk/refund/loan",
        ),
    )
    completion = save(
        OUT / "completion.json",
        dict(
            binding=ref(OUT / "binding.json"),
            source_STOP=stop,
            ordinary_point=point,
            status="PRIVATE_COMPATIBLE_FIXED_SOURCE_AND_NORMAL_DRAFTS_SOFTWARE_UNENTERED",
            same_original_diagnostic_delta=True,
            future=fixed["future"],
            actual_new_diagnostic_calls=0,
        ),
    )
    print(json.dumps(dict(completion=completion, source_STOP=stop, point=point)))


if __name__ == "__main__":
    main()
