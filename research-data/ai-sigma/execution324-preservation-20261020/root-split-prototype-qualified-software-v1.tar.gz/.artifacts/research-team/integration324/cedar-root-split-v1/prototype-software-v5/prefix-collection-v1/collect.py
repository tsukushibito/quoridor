"""Collect the two new diagnostic tests and affected lint once; retire stopped cache."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper = load(
        "existing_helpers",
        Path(
            "/workspaces/quoridor/.artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py"
        ),
    )
    lc = load("current_lifecycle", ROOT / "scripts/dev/research-lifecycle.py")
    outer = json.loads((BASE / "check-runtime-v1/result.json").read_bytes())
    prefix = json.loads((BASE / "operation-prefix/prefix-result.json").read_bytes())
    intent = json.loads((BASE / "build-intent-prefix.json").read_bytes())
    assert outer["job_id"] == "61c9a06f-d0f2-447b-b9b7-abcf8cf41d12"
    assert outer["outcome"] == "succeeded" and outer["exit_code"] == 0
    assert (
        outer["direct_child_reaped"]
        and outer["cleanup_complete"]
        and not outer["remaining"]
    )
    assert (
        prefix["status"] == "PASS_TEST_LINT_PREFIX_ONLY" and prefix["cleanup_complete"]
    )
    assert len(prefix["checks"]) == 4
    known = []
    state = json.loads((BASE / "check-runtime-v1/state.json").read_bytes())
    for row in prefix["checks"]:
        assert (
            row["role"] in {"test", "lint"}
            and row["status"] == "PASS"
            and row["cargo"]["warning_count"] == 0
        )
        if row["role"] == "test":
            selector = row["argv"][row["argv"].index("--lib") + 1]
            saved = helper.checked(row["full_log"]).read_text()
            assert (
                "running 1 test" in saved
                and f"test {selector} ... ok" in saved
                and "test result: ok. 1 passed; 0 failed" in saved
            )
            assert row.get("retired_stopped_cache") or row == prefix["checks"][0]
        lc.settled(row["guardian_return"])
        member = row["guardian_return"]["child"]
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    for member in [state["child"]]:
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
    with lc.lease():
        lc.source_check(intent["source"])
        assert not Path(intent["TMP"]).exists()
        target = Path(intent["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker == dict(
            writer=intent["writer"],
            target=str(target),
            support_sha256=intent["support"]["sha256"],
        )
        assert not (target / "release").exists() and not (target / "debug").exists()
        seen = set()
        ended = sum(lc.allocated(p, seen=seen) for p in lc.charged_roots(intent))
    packet = dict(
        status="ACTUAL_NEW_RUNNERLIB2_AND_TWO_AFFECTED_CLIPPY_PASS_SOURCE_STOP",
        outer=helper.ref(BASE / "check-runtime-v1/result.json"),
        prefix=helper.ref(BASE / "operation-prefix/prefix-result.json"),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        known_exact_fresh_absence=known,
        notification_supervisor=dict(
            original=state["supervisor"],
            current=lc.process.identity(
                lc.process.process_info(state["supervisor"]["pid"])
            ),
            scope="Finished job notification only; execute and source leases returned before notification loop, not future host quiet",
        ),
        affected_fullroot_union_allocated_B_once=ended,
        previous_AI6_Python1="Actual source NN0 PASS reused without replay; not empirical new-image or oldimage parity",
        source_leases=[],
        TMP=[],
        remaining=[],
        retired_only="Stopped test-package and affected lint caches already retired by original prefix after each actual wait/reap; no source/result/image/model deletion or fee refund",
        software="Two new exact Runner library boundaries and affectedAI/Runner Clippy, warning0. PriorAI6/Python1 source NN0 scope reused. Genuine common opt3/codegen1/LTO=false release pending; no312 native/default/performance qualification.",
        host_future_quiet=False,
    )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        json.dump(packet, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(status=packet["status"], seconds=outer["wall_seconds"])))


if __name__ == "__main__":
    main()
