"""Save the new successful software suffix and exact fixture-only correction."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    loader = importlib.util.spec_from_file_location(
        "existing_save",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(helper)
    helper.DEST = DEST
    helper.ALLOWED.extend([BASE, ROOT / ".worktree/assets/perf/cedar-root-split-v1"])
    own = (
        ROOT
        / ".worktree/assets/perf/cedar-root-split-v1/prototype-v1/fixture-repair-v1"
    )
    paths = [
        own / n
        for n in [
            "binding.json",
            "before.rs",
            "post.rs",
            "forward.patch",
            "source-helper-STOP.json",
        ]
    ]
    paths += helper.files_below(BASE / "prototype-fixture-repair-adoption-v1")
    software = BASE / "prototype-software-v5"
    paths += [
        software / "check-runtime-v1" / n
        for n in ["result.json", "config.json", "output.log"]
    ]
    paths += helper.files_below(software / "operation-prefix")
    paths += helper.files_below(software / "prefix-collection-v1")
    paths += [
        software / n
        for n in [
            "build-intent-prefix.json",
            "build-source-adoption-prefix.json",
            "resources-prefix.json",
            "target-handover-prefix.json",
            "prepare.py",
            "run_prefix.py",
        ]
    ]
    paths += [OUT / "preserve.py"]
    name = "root-split-prototype-qualified-software-v1.tar.gz"
    helper.write_archive(
        name,
        paths,
        "SameHigh71699512 positive fixture mainCPU12 only, Root sparseadoption, original61c9a06f newRunnerLIB2 and affectedAI/RunnerClippy actualPASS warning0, exactwaitreap/sourceSTOP. AI6/Python1 source NN0 PASS reused without replay, oldimage/newimage empirical parity unqualified. Common opt3/codegen1 LTO=false; genuine common image/native312/performance/default qualification pending. Earlier failures immutable in earlier archives; no model/input/image/cache/DB payload or old suite replay.",
    )
    m = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    result = dict(
        issue="quoridor-4lc.324.28",
        status="SOURCE_CLEAR_PRODUCTION_BOUNDARIES_NEW_AI6_RUNNER2_PYTHON1_AND_AFFECTED_CLIPPY_PASS_WITH_SCOPE",
        source="Original8c production code static review retained. Only oldcaller typedfalse and new syntheticpositivefixture mainCPU12 repaired, novalidator/assertion/default/root/history/TT/budget relaxation. Main code is comparison-only/defaultOFF for planned finite312; retire purpose-only path after results with Git/evidence restoration.",
        software="AI6 and Python1 original sourceNN0PASS reused; newRunner2 actually1test each and affectedAI/Runner all-targetClippy warning0 in61c9a06f. Rootcollector sourcecheck/exactchildrenabsent/directwait/reap/handles/TMPleases complete. NewSettings fixture covers admission/serialization, not actualsession/requested-effective native record. No universal fault/oldimage parity/hardstoplag proof.",
        compiler="Frozen samecommonrelease opt3/codegen1/LTO=false for all3 prospective modes. OriginalAI6sourceNN0 scope is not same-new-image empirical qualification.",
        cost=dict(
            job="61c9a06f-d0f2-447b-b9b7-abcf8cf41d12",
            outer_seconds_once=117.71832553797867,
            nested_added=0,
            prior_failed_costs="Kept in original failed archives, never reset/refunded or added as nested cost",
        ),
        future="Genuine common BUILD/image and actualnormal currentinput/resource/admission remain unqualified/unissued. No312calls, games/defaultpromotion or foreignscope changes.",
        archive={
            k: m[k]
            for k in [
                "archive",
                "bytes",
                "sha256",
                "full_stream_restore_hash_mode_verified",
            ]
        },
    )
    with (DEST / "root-split-prototype-qualified-software-v1.json").open("x") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(json.dumps(result["archive"]))


if __name__ == "__main__":
    main()
