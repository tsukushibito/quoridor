"""Apply only the required default-OFF field in the existing test caller."""

import fcntl
import hashlib
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1/prototype-v1/fixture-repair-v1"


def ref(p):
    b = p.read_bytes()
    return dict(
        path=str(p),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{p.stat().st_mode & 511:04o}",
    )


def main():
    p = OWN / "binding.json"
    binding = ref(p)
    assert (
        binding["sha256"]
        == "71699512d7604c7f0111da4f672ed9202cfd6a22fd3703b182dfe3b7e024a93e"
    )
    fixed = json.loads(p.read_bytes())
    stop = ref(OWN / "source-helper-STOP.json")
    assert (
        stop["sha256"]
        == "dd65030af3d420e06c3cdb80f9992682ee50524559c92c9a07603f13cc3a0d64"
    )
    subject = ROOT / fixed["subject"]
    for k in ["before", "post"]:
        assert ref(Path(fixed[k]["path"])) == fixed[k]
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        before = subject.read_bytes()
        actual = ref(subject)
        assert all(actual[k] == fixed["before"][k] for k in ["sha256", "bytes", "mode"])
        at = before.index(b"mod root_split_consumer_boundary_tests")
        leading, body = before[:at], before[at:]
        needle = b"        c.management_cpu_core = Some(0);\n"
        assert body.count(needle) == 1
        post = leading + body.replace(
            needle, b"        c.cpu_cores = vec![12];\n" + needle
        )
        assert post == Path(fixed["post"]["path"]).read_bytes()
        subject.write_bytes(post)
        actual = ref(subject)
        assert all(actual[k] == fixed["post"][k] for k in ["sha256", "bytes", "mode"])
    result = dict(
        status="SPARSE_POSITIVE_FIXTURE_CPU_SETUP_ONLY_REPAIR_APPLIED",
        binding=binding,
        source_helper_STOP=stop,
        subjects=[dict(subject=fixed["subject"], actual=actual)],
        delta="Only new positive syntheticfixture main CPU12 set to match team[12,14]; all production validators/root/defaults and all existing assertions/negative cases unchanged.",
        prior_AI6_Python1="PASS retained, no replay",
        unfinished="RunnerLIB2 plus affected AI/Runner Clippy then genuine common image; no312 entry/default qualification",
        source_leases=[],
        TMP=[],
        host_future_quiet=False,
    )
    with (OUT / "actual-adoption.json").open("x") as f:
        json.dump(result, f, indent=2)
        f.write("\n")
    print(json.dumps(dict(status=result["status"], post=actual["sha256"])))


if __name__ == "__main__":
    main()
