"""Preserve fixed unqualified prototype separately from completed diagnostic results."""

import importlib.util
import json
import re
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1/prototype-v1/fixed-v1"
DEST = ROOT / "research-data/ai-sigma/execution324-preservation-20261020"


def main():
    spec = importlib.util.spec_from_file_location(
        "existing_preservation",
        ROOT
        / ".artifacts/research-team/integration324/git-push-20261020/preserve_evidence.py",
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    paths = []
    for base in [OWN, BASE / "prototype-adoption-v1", BASE / "prototype-python-v1"]:
        for path in helper.files_below(base):
            relative = str(path.relative_to(base)).lower()
            if (
                re.search(
                    r"(^|[-_/])(ready|show|beads|backup|notes?|update|admin|authority)([-_./]|$)",
                    relative,
                )
                or "delivery" in relative
            ):
                continue
            paths.append(path)
    first = OWN.parent / "first-delta-v1"
    paths += [
        first / "source-start.json",
        first / "returned-source-STOP.json",
        OUT / "preserve.py",
    ]
    helper.DEST = DEST
    name = "root-split-prototype-fixed-source-v1.tar.gz"
    helper.write_archive(
        name,
        paths,
        "Exact private8c078ee2 nine-owner prototype source before/post/forward/inverse/recipe/source STOP, Root actual sparseapply and one new Python1 PASS only. Rust AI6/RunnerLIB2/Clippy/genuine common release UNENTERED; source review28.3 pending, no default/performance/312 admission. Closed byte preservation/restore only; no sourceproof/test/compiler/native/model/RAW/RNG replay. Beads/rawadmin/privateimage/model payloads excluded.",
    )
    manifest = json.loads((DEST / (name + ".manifest.json")).read_bytes())
    binding = json.loads((OWN / "binding.json").read_bytes())
    record = dict(
        issue="quoridor-4lc.324.28",
        status="FIXED_PRIVATE_SOURCE_AND_MAIN_SPARSE_APPLY_SOURCE_REVIEW_PENDING_RUST_UNBUILT_UNTYPED_UNRUN",
        source_binding=binding,
        Main="Exact9candidate subjects sparsely applied, Main source commit deferred until related correctness and necessary software; no wholeoldowner overwrite",
        Python1="Actual once PASS1 under normal NN0 guard, other newAI6/RunnerLIB2/Clippy/genuine release genuinelyunentered",
        review="Existing same Max28.3 dispatched only fixed relatedsemanticquestions, no sourceclear yet",
        independent_ready_work="Same High28 received original312 config/request/current typed consumer representation preparation; source fixes have priority. Genuine commonBUILD/image/currenttuple/support/whole/origin remain NULL until realfacts, no olddiag alias",
        usage="Original26spent25000193nodes.312/312M comparison unentered/unissued; combined338, no newDiag/refill/game/default/model change",
        limits="Local/defaultOFF source path retained statically, empirical oldimageparity UNMEASURED. Typed stalebound/originalrank/maincommit/fullweightedhistory/sharedTT/cancel/drain/reset/drop need related source and actualsoftware qualification.",
        archive={
            k: manifest[k]
            for k in [
                "archive",
                "bytes",
                "sha256",
                "full_stream_restore_hash_mode_verified",
            ]
        },
    )
    with (DEST / "root-split-prototype-fixed-source-v1.json").open("x") as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(record["archive"]))


if __name__ == "__main__":
    main()
