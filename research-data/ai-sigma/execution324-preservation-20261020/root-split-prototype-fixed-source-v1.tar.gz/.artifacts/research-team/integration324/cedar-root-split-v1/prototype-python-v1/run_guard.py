"""Bound the one-field private source repair using the existing process owner."""

import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import (
    CycleResources,
    execute,
    identity,
    process_info,
)

out = Path(__file__).resolve().parent
temporary = out / "guard-TMP"
temporary.mkdir()
deadline = time.monotonic() + 120
resources = CycleResources(
    {"max_memory_bytes": 1024**3 - 64 * 1024**2, "host_ram_reserve": 4 * 1024**3},
    out,
    deadline,
)
result = execute(
    [
        sys.executable,
        "-B",
        "/workspaces/quoridor/scripts/dev/test_research_lifecycle.py",
        "LifecycleDataAndPaths.test_root_split_measurement_requires_explicit_two_worker_boolean",
        "-v",
    ],
    out / "new-Python-one.log",
    deadline,
    cpu_cores=[10],
    resources=resources,
    cwd="/workspaces/quoridor",
    env=dict(os.environ, TMPDIR=str(temporary), CUDA_VISIBLE_DEVICES=""),
)
assert identity(process_info(result["child"]["pid"])) != result["child"]
temporary.rmdir()
with (out / "actual-returned-STOP.json").open("x") as stream:
    json.dump(
        dict(actual_return=result, TMP=[], source_leases=[], host_future_quiet=False),
        stream,
        indent=2,
    )
    stream.write("\n")
print(
    json.dumps(
        dict(
            exit_code=result["exit_code"],
            cleanup=result["cleanup_complete"],
            seconds=result["wall_seconds"],
        )
    )
)
assert result["exit_code"] == 0 and result["cleanup_complete"]
