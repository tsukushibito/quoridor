"""Sparse-apply the fixed prototype to the exact current nine owners."""

import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OWN = ROOT / ".worktree/assets/perf/cedar-root-split-v1/prototype-v1/fixed-v1"


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    binding = ref(OWN / "binding.json")
    assert (
        binding["sha256"]
        == "8c078ee255e8d8d5c2949f2e5f9cfd65ca62392d9ab98fa02a20a386ceb5d7ae"
    )
    fixed = json.loads((OWN / "binding.json").read_bytes())
    assert (
        len(fixed["subjects"]) == 9
        and ref(Path(fixed["correspondence"]["path"])) == fixed["correspondence"]
    )
    correspondence = json.loads(Path(fixed["correspondence"]["path"]).read_bytes())
    patch = correspondence["forward"]
    assert ref(Path(patch["path"])) == patch
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for row in fixed["subjects"]:
            path = ROOT / row["subject"]
            if row["before"] is None:
                assert not path.exists()
            else:
                actual = ref(path)
                assert all(
                    actual[k] == row["before"][k] for k in ["sha256", "bytes", "mode"]
                )
            assert ref(Path(row["post"]["path"])) == row["post"]
        result = subprocess.run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "--no-backup-if-mismatch",
                "--reject-file=-",
                "-p1",
                "-i",
                patch["path"],
            ],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        assert (
            "fuzz" not in result.stdout.lower()
            and "offset" not in result.stdout.lower()
        )
        subjects = []
        for row in fixed["subjects"]:
            actual = ref(ROOT / row["subject"])
            assert all(actual[k] == row["post"][k] for k in ["sha256", "bytes", "mode"])
            subjects.append(dict(subject=row["subject"], actual=actual))
        subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
        receipt = dict(
            issue="quoridor-4lc.324.28",
            status="SPARSE_ROOT_ONLY_PROTOTYPE_SOURCE_APPLIED_REVIEW_AND_NEW_SOFTWARE_PENDING",
            binding=binding,
            subjects=subjects,
            forward=patch,
            actual_patch_output=result.stdout,
            EX_NB_returned=True,
            source_leases=[],
            new_tests_compiler_native=0,
            source_selfclear=False,
            default="OFF/LOCAL1 unchanged; no Half/aspiration revival",
            qualification="Source correspondence only, not SOURCE_CLEAR/software/runtime/performance or312 entry",
            host_future_quiet=False,
        )
        with (OUT / "actual-adoption.json").open("x") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")
    print(json.dumps(dict(status=receipt["status"], subjects=9)))


if __name__ == "__main__":
    main()
