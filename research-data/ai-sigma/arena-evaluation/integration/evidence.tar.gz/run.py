"""Bound the two allocated operational slots and their read-only audit/recovery."""

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = Path("/workspaces/quoridor/.worktree/arena-evaluation")
OUT = ROOT / ".artifacts/arena-operational"
EVIDENCE = Path("/workspaces/quoridor/research-data/ai-sigma/arena-evaluation")
SPEC = importlib.util.spec_from_file_location(
    "canonical_cycle_process", "/workspaces/quoridor/python/quoridor_training/cycle_process.py"
)
PROCESS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PROCESS)
PROCESS.LOG_MAX_BYTES = 131072
INVENTORY_RACES = []


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def inventory(root):
    for attempt in range(3):
        result, pending = {}, [root]
        try:
            while pending:
                with os.scandir(pending.pop()) as entries:
                    for entry in entries:
                        info = entry.stat(follow_symlinks=False)
                        if stat.S_ISDIR(info.st_mode):
                            pending.append(Path(entry.path))
                        elif stat.S_ISREG(info.st_mode):
                            result[entry.path] = (info.st_dev, info.st_ino, info.st_blocks * 512)
            return result
        except FileNotFoundError as error:
            INVENTORY_RACES.append(
                {"at": timestamp(), "attempt": attempt + 1, "path": error.filename}
            )
    raise PROCESS.CycleStopped("owned inventory uncertain after three complete attempts")


def allocated(roots):
    files = {}
    for root in roots:
        for device, inode, size in inventory(root).values():
            files[(device, inode)] = size
    return sum(files.values())


class Resources(PROCESS.CycleResources):
    def __init__(self, control, deadline):
        super().__init__(
            {"max_memory_bytes": 2 * 1024**3 - 64 * 1024**2, "max_output_bytes": 512 * 1024},
            control,
            deadline,
        )
        self.peak_rss = 0
        self.peak_evidence = 0
        self.peak_inclusive = 0

    def check(self, owned=()):
        super().check(owned)
        infos = [
            PROCESS.process_info(os.getpid()),
            *(PROCESS.process_info(i["pid"]) for i in owned),
        ]
        rss = sum(i["rss"] for i in infos if i) + 64 * 1024**2
        self.peak_rss = max(self.peak_rss, rss)
        if rss > 2 * 1024**3:
            raise PROCESS.CycleStopped("family RSS plus controller reserve exceeds 2GiB")
        private_bytes = allocated([OUT / "immutable-native"])
        inclusive = (
            allocated(
                [ROOT, EVIDENCE, Path("/workspaces/quoridor/.artifacts/arena-evaluation-launch")]
            )
            + 32473088
        )
        evidence = allocated([ROOT / ".artifacts", EVIDENCE]) - private_bytes
        self.peak_evidence = max(self.peak_evidence, evidence)
        self.peak_inclusive = max(self.peak_inclusive, inclusive)
        if private_bytes + 32473088 > 40 * 1024**2:
            raise PROCESS.CycleStopped("original build peak plus private copy exceeds 40MiB")
        if inclusive > 64 * 1024**2 or evidence > 8 * 1024**2:
            raise PROCESS.CycleStopped("owned inclusive/evidence reservation exceeded")


def main():
    os.chdir(ROOT)
    os.sched_setaffinity(0, {0, 1})
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    stage = sys.argv[1]
    if stage not in ("smoke", "cancel"):
        raise ValueError("only the two allocated stages are supported")
    control = OUT / f"{stage}-control"
    prelaunch = json.loads((control / "prelaunch.json").read_text())
    for item in prelaunch["frozen_files"]:
        if hashlib.sha256(Path(item["path"]).read_bytes()).hexdigest() != item["sha256"]:
            raise ValueError("bound file changed: " + item["path"])
    for member in prelaunch["learning_final_identities"]:
        if PROCESS.alive(member):
            raise ValueError("learning final exact child remains")
    native = json.loads((OUT / "immutable-native-receipt.json").read_text())
    binary = Path(native["private_path"])
    if not os.access(binary, os.X_OK) or stat.S_IMODE(binary.stat().st_mode) != 0o755:
        raise ValueError("private binary execute mode mismatch")
    config_path = OUT / f"{stage}.json"
    config = json.loads(config_path.read_text())
    output = Path(config["output"])
    if output.exists():
        raise ValueError("operational output already exists; no repeated slots")
    if stage == "cancel":
        Path(config["pause_file"]).write_text("pre-existing functional cancellation\n")
    started, begin = timestamp(), time.monotonic()
    resources = Resources(control, begin + 70)
    result = {"stage": stage, "started": started, "commands": [], "NN": 0, "GPU": 0}
    failure = None
    try:
        with PROCESS.cancellation_signals():
            try:
                record = PROCESS.execute(
                    [str(binary), "arena", "--config", str(config_path)],
                    control / "arena.log",
                    resources.deadline,
                    resources=resources,
                )
            except PROCESS.CycleStopped:
                record = json.loads((control / "arena.process.json").read_text())
                if (
                    stage != "cancel"
                    or record.get("exit_code") != 1
                    or not record["cleanup_complete"]
                ):
                    raise
                result["native_nonzero_preserved"] = (
                    "expected pre-cancel exit1; typed outcomes checked below"
                )
            result["commands"].append(record)
            report = json.loads((output / "result.json").read_text())
            manifest = json.loads((output / "manifest.json").read_text())
            slots = json.loads((output / "planned.json").read_text())
            assert report["planned"] == 2 and len(report["outcomes"]) == 2
            assert report["nn_calls"] == 0 and report["rows"] == 0 and report["dataset"] is None
            assert report["model_sha"] is None and report["all_workers_joined"]
            assert manifest["cleanup"] == {"all_workers_joined": True, "gzip_child_reaped": True}
            assert [s["candidate_color"] for s in slots] == [0, 1]
            assert slots[0]["opening"] == slots[1]["opening"]
            assert slots[0]["replay"] == slots[1]["replay"]
            assert slots[0]["family"] == slots[1]["family"]
            assert {o["game"] for o in report["outcomes"]} == {0, 1}
            summary = report["arena_summary"]
            if stage == "smoke":
                assert report["stopped"] is None
                assert all(o["status"] == "goal" and o["winner"] == 0 for o in report["outcomes"])
                assert all(len(o["moves"]) == 1 for o in report["outcomes"])
                assert summary["census"]["complete_pairs"] == 1
                assert summary["complete_pair_mean"] == 0.5
            else:
                assert report["stopped"] == "paused"
                assert all(
                    o["status"] == "unknown" and o["failure"] == "cancelled"
                    for o in report["outcomes"]
                )
                assert summary["census"]["unknown_games"] == 2
                assert summary["census"]["incomplete_pairs"] == 1
                assert summary["complete_pair_mean"] is None
                assert summary["planned_score_range"] == [0.0, 1.0]
            for command in ("audit", "recover"):
                record = PROCESS.execute(
                    [str(binary), "arena", "--" + command, str(output)],
                    control / f"{command}.log",
                    resources.deadline,
                    resources=resources,
                )
                result["commands"].append(record)
                observed = json.loads((control / f"{command}.log").read_text())
                if command == "audit":
                    assert observed == summary
                else:
                    assert observed["summary"]["census"]["planned_games"] == 2
                    assert len(observed["observed_outcomes"]) + len(observed["missing_slots"]) == 2
                result[command] = observed
            result["summary"] = summary
            result["operational_checks"] = (
                "PASS; same-prefix color pair, typed terminal/cancel, full census, journal recovery/audit"
            )
    except BaseException as error:
        failure = error
    finally:
        records = [json.loads(p.read_text()) for p in control.glob("*.process.json")]
        result.update(
            ended=timestamp(),
            wall_seconds=time.monotonic() - begin,
            error=repr(failure) if failure else None,
            all_direct_children_reaped=all(r["direct_child_reaped"] for r in records),
            cleanup_complete=all(r["cleanup_complete"] for r in records),
            remaining=[i for r in records for i in r["remaining"]],
            peak_family_RSS_plus_controller_reserve=resources.peak_rss,
            peak_evidence_bytes=resources.peak_evidence,
            peak_inclusive_bytes_with_original_build_peak=resources.peak_inclusive,
            inventory_races=INVENTORY_RACES,
            limitation="Functional D/D only; strict_unknown provisional; no fair clock/strength/Elo claim",
        )
        (control / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    if failure:
        raise failure


if __name__ == "__main__":
    main()
