# Conditional processing follow-up for task351

This is separate planning text, not a candidate or executable admission. The
fixed report0a5257b3, handoff8be5860f and interpretation bindingda498ce8 remain
immutable for reviewer351.1. Selection follows that review's actual reader STOP
and Root's bounded intake. No compiler, native call, replay or source change is
authorized by this plan. It neither resumes deferred349 nor chooses N.

## Separate the four questions

| Question | Existing evidence | What it does not establish |
| --- | --- | --- |
| Capacity and admission | Retained1MiB, zero hits/replacements and skips equal probes in161 completed suffix moves; direct-slot byte test in supplied source | Occupied-slot count, physical heap peak, time fraction, benefit of more bytes |
| Age and replacement usefulness | Two per-colour persistent sessions; iterative-depth generations; same-generation deeper protection; no capacity-driven global eviction in supplied source | Benefit of clearing, age/depth victim selection, or different cross-turn reuse policy |
| Key/history construction, copy and hashing | Full-history keys; game00027743662 instrumented key builds and622307747 counted items; probe/insert hash requests in the source lead | Whether allocation, copying, sorting or hashing dominates wall time |
| Ordinary probe/insert processing | Direct-mapped index, full-key comparison, depth/bound/move checks, byte admission and overwrites | Cache/memory hardware cost, profiler shares or alternative-table advantage |

The admission interpretation is still pending independent confirmation. All four
games have long no-hit/all-skip suffixes, including very cheap searches. The158s
game's much larger positive-stock work and the fixed worker assignment remain
separate explanatory observations; they do not price a TT optimization.

## A possible exact-processing route to assess after review

If review confirms the relevant compiled probe/insert boundaries, the first
semantics-preserving opportunity to assess is **reusing a hash already computed
for the same immutable owned key between its probe and result insertion**. This
is a conditional option, not a selected implementation. It should be ruled out
if the actual maintained boundary cannot guarantee ownership and equality safely.

The intended change would compute the identical DefaultHasher result once for
that key and pass the hash alongside the key. It would leave the Key and Entry
layout, full counted-history vector, its allocation/capacity, equality,4096 slots,
1MiB accounting, target index, replacement/admission decisions, generations and
namespaces unchanged. Keeping the hash outside Entry avoids adding stored bytes
and unintentionally changing byte admission. PV lookups and paths without a paired
insertion need explicit treatment; they must not silently inherit another key's
hash. This does not solve capacity pressure or introduce a new eviction policy.

The meaningful expected effect is removing a redundant traversal/hash of a key's
full history on paths that both probe and insert. The saved counters and source
lead show many such requests, so this is more concrete than assuming resizing
will help. **No wall-time speedup is measured or predicted.** Some probes return
from TT and do not insert; those paths have less opportunity. Total eligible
paired-hash requests must be derived at the verified current boundary before
choosing or pricing execution, rather than halving every counter blindly.

Counter definitions also need an explicit decision. Existing `tt_hashes` excludes
uninstrumented PV lookups and currently counts probe/insert hash requests. If the
maintained definition becomes actual computations, its decrease is an intended
processing metric and must be documented; it cannot be presented as unchanged
work or a speed result. If its old request-count meaning is retained, actual
computation savings need a separately named scoped qualification observation.
Do not forge legacy counter values or change serialized consumer meaning silently.

## Unchanged obligations and finite qualification boundary

Any selected route must preserve genuine full threefold/path history, absolute
ply/side/stocks/rules/winner/synthetic key identity, score/terminal/model/view
namespaces, goal-first terminals, TT full-key collision checking, depth/bound
soundness, PVS windows and legal-move checks. No history dropping, short-key
admission, repetition weakening, table clearing, teacher depth/node/time/label
change, model change or default adoption is proposed.

Preparation should specify the exact before/after owned source, consumers, affected
filters and logical-versus-physical counter contract. Affected discriminating
qualification would cover:

- Hash reuse gives the same index/hash and full-key equality for paired operations,
  including different full histories with equal board geometry and direct-slot
  mismatches. No fabricated chronology or new rules implementation is needed.
- Admission/refusal and deeper same-generation protection leave identical entries,
  retained bytes, generations, TT probes/hits/collisions/replacements/skips and
  namespace reset behaviour on an independently enumerated small tree.
- Root/recursive/PVS/PV paths preserve selected action, value bits and legal PV,
  completed depth and all unaffected work, with only explicitly defined hash-work
  metrics allowed to differ. No weaker output comparison may be substituted after
  a failure. Cancellation, evaluator errors, partial-generation discard and parent
  make/unmake ownership must retain their original obligations.

These are future affected tests to define, not executed tests or a request to
replay old successful rules/math/private/native suites. Existing unchanged proof
should be reused. A meaningful independent changed-boundary review and affected
current-main feature closure would be required before adoption by sole324.

If a later finite cost comparison is justified, its question would be the cost of
the same completed work under original and selected processing. A prospective
minimum is two prebound expensive genuine prefixes, depth6 and identical limits,
two configurations with one return each: four completed returns, plus setup/
serialization/audit/waits/cleanup. This is a proposal only; repeated timing samples,
ABBA blocks, sweeps or whole games would require their own explicit supported
finite contract. Four times the saved maximum is28.257s of original search scale,
not a bound, full-job cost or prediction for a modified build. Actual build and
whole comparison cost remain UNKNOWN until a supported plan is fixed.

## Whole support before any affected write

The current analysis8MiB contains no build/private runtime allocation. A candidate
must not consume that allowance as an implicit Cargo budget or use old target
deletions/cache reuse as credit. The following is a **prospective upper proposal**,
not an allocation, worktree creation or claim of measured disk usage:

| Candidate component | Proposed upper MiB | Binding needed before growth |
| --- | ---: | --- |
| Exclusive checkout/source and controls | 32 | Sole324 assigns actual writer/baseline/paths; measure retained checkout; no foreign-source edit |
| New target, dependencies and metadata | 512 | Exact toolchain/offline/no-install, named target and incremental/dependency forecast |
| Qualified private binaries | 16 | Required original/current payload sizes and provenance; no blind source retarget |
| Temporary files | 32 | Named paths, prewrite, directwait and cleanup retention |
| Affected qualification | 8 | Exact filters/fixtures, stdout/process/cost receipts |
| Finite comparison raw/output | 8 | Exact input/call count and output caps; unexecuted until admitted |
| Failures/finalization/rounding | 8 | Retain primary errors, failed attempts and UNKNOWNs |
| Related review | 4 | Narrow fixed changed boundary, stopped source/readers |
| Root/Git/retention/cleanup | 4 | Sole324 integration and restoration verification |
| **Additional prospective whole** | **624** | **654311424B; currently unsupported for execution** |

No old348 target/private/raw or analysis allocation is reduced or transferred.
The dated resource file's global held39598288896B plus this proposal is
40252600320B, below50GB, but that arithmetic is not a current allocator proof.
Root must check its actual current typed whole classifications and all retained
components; any larger observed checkout/dependency/private/TMP estimate requires
an explicit coherent gap before further growth. Shared dependencies may be
classified once only where actual ownership and support justify it, never assumed
free. Source/build/setup/qualification/failure/review/Git time costs are UNKNOWN
until observed; nested spans would not be added to whole fees.

Once review and bounded intake are available, choose a supported useful route or
state why this option is unsupported. If the only useful alternative changes
eviction/admission policy, history semantics, teacher policy or another important
method, return the evidence, competing options, decision effect and whole cost to
policy before implementation. No forced patch or endless repeated analysis is
required. Sigma genuine readiness has priority; any actual job retains natural
STOP and no speculative idle lock is held.

## This planning text's own scope

This file and its stopped hash receipt have a prospective32KiB increment inside
the existing analysis source/control2MiB. They use only already supplied facts
and conditional wording; no new frozen-source/raw read, aggregate, candidate,
compiler or runtime call. The original report/binding/handoff and reviewer target
remain unchanged. Markdown is manually scoped CommonMark with LF/blank lines/
tables; original RAW, failed fees, masks, assets and UNKNOWNs stay held. N, full
schedule, pilot inclusion, full generation/fits96, defaults, seals and323pause are
unchanged.
