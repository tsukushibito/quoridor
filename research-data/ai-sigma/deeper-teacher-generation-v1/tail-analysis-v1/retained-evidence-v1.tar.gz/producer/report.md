# Why the saved depth6 game took 158 seconds

Game000 took **157.588321221 seconds for 60 moves**, from an accepted four-ply
prefix to a goal at ply64. It was not a 158-second move. Its slowest returned
search was 7.064288343 seconds. All four planned games completed, and all178
accepted search returns completed depth6; no game or move was dropped from this
analysis.

Returned search timers account for 157.568024898 seconds, or99.9871% of this
game's native timer. That identifies where the recorded time sits, not which
internal operation caused it. The long game did much more search work than the
other games, while wall stocks remained available. Its TT also stopped admitting
entries early under its retained-history byte budget. The latter is a concrete
source mechanism consistent with the counters, **pending narrow independent
interpretation review**; its time cost and any resizing benefit are unmeasured.

## Four-game denominator and clocks

| Game | Prefix | New moves | Nodes | Native game s | Returned search sum s | Native minus search ms | Nodes/search-second |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 000 | 4 | 60 | 110665955 | 157.588321221 | 157.568024898 | 20.296323 | 702338 |
| 001 | 8 | 48 | 33861675 | 39.192802560 | 39.177045716 | 15.756844 | 864324 |
| 002 | 12 | 38 | 13268996 | 17.456011954 | 17.443357000 | 12.654954 | 760691 |
| 003 | 16 | 32 | 465219 | 0.519101456 | 0.508703505 | 10.397951 | 914519 |

The178 returns total158261845 nodes. NPS divides nodes by the corresponding
returned search timer; it is an observation across different positions and
histories, not a controlled implementation-speed comparison. The original policy
is depth6/PVS/TT4096, no time limit, explicit u64::MAX node ceiling, fixed original
D(0,8), goal-first/legal-threefold and operational200-UNKNOWN. No neural model,
contact candidate, solver or ordering variant was introduced.

The compiled timing definitions differ:

- `SearchResult.elapsed` starts inside `search_in_table`, before root validation,
  clone/scratch preparation and iterative depths1..6. It ends before returning
  the result and implicit local destruction. It includes key/history construction,
  TT probes, move ordering, search, evaluations and PVS work together.
- `GameRecord.wall_ns` starts in `play_using_policy`, after the two sessions were
  constructed. It includes prefix audit, search calls, return/PV checks, row
  construction, actual moves, terminal classification and final target attachment
  up to its elapsed read. Later local/session destruction is outside this timer.
- The indexed scheduler timer wraps worker pinning and `play_with_policy` until
  the game value returns, before channel send, coordinator audit and serialization.
  Its four seconds are157.588765090/39.193174579/17.456158531/0.519246641. Differences
  from native game timers are0.443869/0.372019/0.146577/0.145185ms respectively.
- Native pipeline175.159873507s begins before resource admission/output/prefix
  scheduling and includes parallel games, ordered writes, joins, sync and a saved
  stream read/summarization. Its elapsed read precedes footer append and CLI return.
- External controller175.884201586s includes the generation process, separate
  saved audit, waits and cleanup. Its0.724328079s difference from the native timer
  is a mixed envelope, not an isolated setup, serialization or audit measurement.

The20.296323ms native-minus-search residual in game000 is also a mixed timer
difference, not a profiler measurement of saving or labels. Actual per-game
serialization durations, TT-only/hash/BFS/history/PVS time shares, allocation peaks,
worker timestamps and startup-only costs were not recorded. No overlapping game
timers are added to the external whole.

## Concentration and wall stocks

Game000's top5/10/20 returned searches consume32.944066732/61.475523455/
111.767099706s:20.908%/39.015%/70.933% of its search sum. Its median move is
3.678627810s; the tail is many expensive moves, not one exceptional158s search.

| Game000 ply | P1/P2 stocks | Nodes | Search s | TT probes | Key hits | Capacity skips |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 18 | 5/6 | 5759692 | 7.064288343 | 1073821 | 0 | 1073821 |
| 4 | 8/8 | 6915688 | 6.855282274 | 1491533 | 1515 | 631527 |
| 11 | 6/7 | 6562265 | 6.782210303 | 1292999 | 0 | 1292999 |
| 17 | 5/6 | 3799682 | 6.197076065 | 991686 | 0 | 991686 |
| 5 | 7/8 | 5079288 | 6.045209747 | 1362721 | 1370 | 687490 |

These stock-total bins are descriptive groupings of saved parents, not a new
generator policy or an independently sampled stage comparison. Every actual stock
pair, ply, player, time, NPS and counter is in `per-ply.csv`.

| Game | Stocks11+ moves / search s | Stocks1..10 moves / search s | Stocks0 moves / search s |
| --- | ---: | ---: | ---: |
| 000 | 17 / 97.099139277 | 25 / 60.455692173 | 18 / 0.013193448 |
| 001 | 2 / 9.350925976 | 23 / 29.812437426 | 23 / 0.013682314 |
| 002 | 0 / 0 | 22 / 17.435329856 | 16 / 0.008027144 |
| 003 | 0 / 0 | 6 / 0.494872620 | 26 / 0.013830885 |

Game000 has42 positive-stock moves and110660112 nodes before both stocks reach
zero, versus only5843 nodes on its last18 moves. Its first17 high-stock searches
already account for78.10million nodes and97.10s. The shortest case starts from a
16-ply prefix with stocks2/2, reaches zero stocks after six searches, and has only
465219 nodes overall. This is an observed work/stage association. Legal branching
counts, wall-map geometry costs and the causal effect of stock removal were not
separately measured; stock numbers alone do not measure legal wall placements.

## TT mechanism and trajectory

The source map is the stream's actual compiled map, independently matched to the
supplied privatea45 software handoff. It is not assumed to be current Main. The
selected source files total235881B; exact paths, SHA/mode/size and line mechanisms
are in `input-binding.json` and `source-mechanisms.json`.

`play_with_policy` constructs **two per-game SearchSessions**, selected by native
side0/1, before the move loop. Their tables persist across that colour's actual
turns and are not reset each turn. Each has4096 direct-mapped slots and a1MiB
accounted retained-byte limit. New games get new sessions; there is no cross-game
or cross-colour sharing. Search stats start at zero each call. Each completed
depth increments table generation; saved generations advance6 per same-colour
turn, from6 upward, while the retained table survives.

The key includes ruleset, board/pawns/stocks/side/winner, absolute ply, synthetic
flag and the complete counted history (including history stocks). History is
collected and hashed for each key construction. Strict key equality protects
history-dependent semantics; no position-only key or history deletion is proposed.

The source's admission formula is:

```text
retained = size_of(Table) + slots.capacity * size_of(Option<Entry>) + heap_bytes
new accounted payload = key.history.capacity * size_of(accounting history tuple)
prospective = retained - target_slot_old_payload + new_payload
if prospective > 1048576: capacity_skips += 1; keep old slot; return
```

Same-generation deeper entries may be protected before that test. Otherwise an
accepted replacement subtracts that one slot's old history payload and installs
the new entry. There is no global age eviction, budget-driven clear or second-slot
fallback. Generation advance alone does not clear old committed entries. Explicit
reset clears; interrupted generations are discarded; wraparound also clears.
None of those paths is indicated by the completed, monotone saved trajectories.

Accounting is not total process heap: namespace/evaluator metadata, temporary keys,
allocator overhead and other search storage are outside this1MiB number. Exact
slot/header physical ABI sizes and live occupied-slot counts were not saved. A
byte-limit refusal must not be relabeled "all4096 slots filled."

| Game | First recorded1MiB P1/P2 ply | First all-skip,zero-hit P1/P2 ply | Such remaining moves P1/P2 |
| --- | --- | --- | --- |
| 000 | 6 / 7 | 10 / 9 | 27 / 28 |
| 001 | 8 / 9 | 12 / 13 | 22 / 22 |
| 002 | 14 / 13 | 16 / 17 | 17 / 17 |
| 003 | 16 / 17 | 20 / 21 | 14 / 14 |

In each listed same-colour suffix, every saved move has retained bytes1048576,
key hits0, replacements0 and capacity skips equal probes; bound cutoffs/order-only
hits are zero as well. There are161 such moves among178. For these completed
returns, the inspected root/recursive paths probe each positive-horizon
nonterminal node and then attempt to insert its result; leaves/terminals have
neither. With no TT hits causing early returns, the equality supports the specific
interpretation that those attempted result insertions all reach the byte refusal,
rather than an inference based only on a high skip ratio. This source/counter
interpretation awaits narrow independent confirmation before adoption.

Game000 fills early: ply4/P1 and5/P2 retain1048264/1048528B. At ply6/7 both reach
1048576B but some replacements still occur; being at the byte ceiling is not by
itself proof that every replacement refuses. By ply9/P2 and10/P1 the all-skip
suffix starts. The root distinct-history size grows from5 at ply4 to19 at ply18
and64 at ply63. Mean built-key history size grows9.90→23.88→66.52; mean accounted
key capacity grows308.96→763.04→2120.36B. Those are per-key observations, not an
assertion of vector growth policy or exact slot occupancy. The fixed direct-mapped
old entries can remain while later, larger-history candidate keys fail admission.

### Counter meanings

`tt_probes` counts calls to instrumented `Table::probe`, not all nodes or all
lookups. `tt_key_hits` requires full-key equality in the selected occupied slot;
`tt_collisions` is an occupied-slot key mismatch, not a proven64-bit hash collision.
Empty-slot misses are not collisions. `tt_capacity_skips` counts failed insertions
at the byte test; it has a different event denominator from probes. `tt_replacements`
counts accepted overwrites of occupied slots, not all successful admissions.
`tt_exact_hits` is the stored bound kind; usable-depth and bound cutoffs are narrower
events, with legal best move and matching horizon requirements. `tt_order_only`
retains an otherwise usable move from another horizon. PV `Table::get` lookups
and their hashes are outside the instrumented probe/hit counters.

`tt_history_items` and `tt_key_history_capacity_bytes` accumulate constructed-key
work during each whole iterative search, not retained memory. Game000 constructs
27743662 keys, processing622307747 counted items and summing19.687950984GB of
accounted key-vector capacities. That is repeated work across successive keys,
not a19.7GB peak allocation. `tt_retained_bytes` and `tt_generation` are final-call
gauges, and are not summed as events. All retained counters, including null
physical/leaf counters, remain in the CSV/summary.

The four games' PVS re-search totals are1067/584/447/239, general cutoffs are
26748562/7441999/3466289/139981, and TT bound cutoffs are115/220/1/244. Their wall
time shares are unknown. Identical no-hit/all-skip behaviour also occurs in the
very short late searches and in game003. Therefore this mechanism alone neither
explains the inter-game time gap nor proves that changing TT size would make the
158-second game faster. No alternate budget/reset/key design was run.

## Parallel tail and volume limits

The compiled scheduler assigns indices0,2 to worker0 and1,3 to worker1, with a
one-result bounded queue per worker and index-ordered consumption. The saved
indexed game-time sums are175.044923621s versus39.712421220s. These are per-worker
work sums, not a sum of overlapping workers. Native pipeline time is only
0.114949886s above worker0's sum; that difference is a mixed residual, not an
exclusive measured scheduler overhead.

A one-slot queue allows worker1 to send game001 and proceed to game003, then its
next send can wait behind index0. This provides a source explanation for a long
critical path and possible queued/idle time without inventing exact worker
timestamps. Exact start offsets, send-block durations, idle utilisation and an
alternative assignment's benefit remain UNKNOWN. There were only two games per
worker, so later workload balance and scalability cannot be inferred.

The accepted81.872 completed games/hour and3643.306 rows/hour use the full
175.884201586s external interval. The retained failed entry makes charged rates
81.119/3609.816. Four selected prefix lengths4/8/12/16 and correlated within-game
moves do not guarantee these rates for a full volume or a different prefix mix.
No N, schedule, pilot inclusion, teacher or default decision is made here.

## Unexecuted diagnostic options and whole cost

The actionable result now is to preserve the measured distributions and the
history-byte admission question for human volume planning. It does not recommend
resizing or clearing a TT on the basis of a shorthand skip count.

1. A future source-only accounting audit could expose attempted/admitted insertions,
   occupied slots, payload sizes and refusal reasons, preserving existing key and
   search semantics. Purpose: separate byte pressure, direct-slot replacement and
   temporary-key work. No native run is authorized here; source/build/private/input/
   raw/review/TMP/cleanup support and affected qualification would have to be priced.
2. If a consequential TT alternative is selected later, a finite same-prefix,
   same-depth6 matched comparison could use two prebound expensive positions and
   two configurations, four completed returns, retaining work/value/action changes.
   Four times this observed maximum is28.257s of baseline search scale, **not a
   completion bound or a prediction for the alternative**. Compile, qualification,
   materialization, initialization, output/audit, review and cleanup costs and the
   full incremental/retained storage forecast are currently UNKNOWN. They must be
   supported as a coherent whole before any entry; old caps/assets are not credits.

Both options are NOT_RUN, are not optimization instructions or a new experiment
grant, and require the existing research decision rules. The current analysis
itself is supported within8MiB: source/control2MiB, report/CSV1MiB, related review
2MiB, Root/Git/cleanup2MiB, TMP/failure1MiB inside unchanged348 review128MiB and
parent1.5GiB/global50GB. No old source/raw/private/model assets were copied or
deleted. Historic failed fees/masks/transient and continuous UNKNOWN remain held.

## Evidence and stopped review boundary

`input-binding.json` binds the accepted receipt8b5248c4, packetf9a3db1f, helperadcf,
stream891ccfd1/906362B, selected exact compiled sources and saved metadata. The
finite stdlib aggregation ran CPU3/AS512MiB/GPU0 under a fresh named-quiet and
nonblocking canonical lease: START06:03:11.575202, reader STOP06:03:12.259058 UTC,
whole0.689218067s including scoped Ruff format/check/lint and one saved aggregate.
The aggregate's internal arithmetic span was0.006203077s, process VmHWM21159936B;
direct-child whole0.032612364s. Nested spans are not added. Continuous family
peak remains UNKNOWN; sampled family and individual process metrics are separate.

All four owned commands directly returned exit0, handles closed, exact direct
identities absent, selected inputs hash/size/mode matched before/after, TMP0 and
lease closed. No native, geometry, Search, model, audit, build, game or prior
successful suite executed. Markdown uses scoped manual CommonMark tables/LF/
blank-line formatting and a stdlib check: V8-based Prettier is not invoked under
the required512MiB address-space envelope. Final formatting, arithmetic
cross-checks, artifact hashes and exact final reader/writer STOP are in the frozen
handoff/receipt. Source/admin reasoning and uninstrumented read costs remain
UNKNOWN rather than zero. Only the named TT interpretation goes to a stopped
independent review; ordinary arithmetic need not replay the accepted engine proof.
