"""Bounded fixed-revision NPZ acquisition and header inspection; never loads labels."""

import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import struct
import urllib.request
import zipfile


def header(stream):
    if stream.read(6) != b"\x93NUMPY":
        raise ValueError("NPY magic")
    version = tuple(stream.read(2))
    size_format = "<H" if version == (1, 0) else "<I"
    size_bytes = struct.calcsize(size_format)
    size = struct.unpack(size_format, stream.read(size_bytes))[0]
    if size > 8192 or version not in {(1, 0), (2, 0), (3, 0)}:
        raise ValueError("NPY header bound/version")
    info = ast.literal_eval(stream.read(size).decode("utf-8"))
    if set(info) != {"descr", "fortran_order", "shape"} or info["fortran_order"]:
        raise ValueError("NPY schema/order")
    return dict(info, header_bytes=8 + size_bytes + size)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True)
    cfg = json.loads(Path(parser.parse_args().plan).read_text())
    directory = Path(cfg["raw"])
    directory.mkdir(parents=True, exist_ok=True)
    source = cfg["source_commit"]
    rows = []
    downloaded = 0
    for item in cfg["cycles"]:
        name = f"cycle_{item['cycle']:04d}.npz"
        target = directory / name
        if target.exists():
            raise ValueError("immutable raw output already exists; no automatic overwrite")
        git = hashlib.sha1(b"blob " + str(item["size"]).encode() + b"\0")
        sha = hashlib.sha256()
        actual = 0
        url = f"https://raw.githubusercontent.com/bartolomeo3000/SigmaQuoridor/{source}/runs/data_9x9_fix/{name}"
        with urllib.request.urlopen(url, timeout=45) as response, target.open("xb") as out:
            while chunk := response.read(256 * 1024):
                actual += len(chunk)
                downloaded += len(chunk)
                if actual > item["size"] or downloaded > 96 * 1024**2:
                    raise ValueError("download cap")
                out.write(chunk)
                git.update(chunk)
                sha.update(chunk)
        if actual != item["size"] or git.hexdigest() != item["Gitblob"]:
            raise ValueError("fixed Gitblob/length mismatch")
        members = []
        with zipfile.ZipFile(target) as archive:
            if len(archive.infolist()) > 8 or len(set(archive.namelist())) != len(
                archive.namelist()
            ):
                raise ValueError("ZIP member count/duplicates")
            for member in archive.infolist():
                if member.filename not in {
                    "states.npy",
                    "policies.npy",
                    "values.npy",
                    "plies_to_end.npy",
                }:
                    raise ValueError("unexpected member")
                if member.file_size > 2 * 1024**3 or member.compress_size > item["size"]:
                    raise ValueError("member size bound")
                with archive.open(member) as stream:
                    info = header(stream)
                members.append(
                    dict(
                        name=member.filename,
                        compressed=member.compress_size,
                        expanded=member.file_size,
                        CRC=member.CRC,
                        header=info,
                    )
                )
        rows.append(
            dict(
                cycle=item["cycle"],
                split=item["split"],
                path=str(target),
                bytes=actual,
                Gitblob=git.hexdigest(),
                SHA256=sha.hexdigest(),
                members=members,
            )
        )
    result = dict(
        task="sigma-public-z-import-289-v1",
        schema="public-npz-header-v1",
        UTC=datetime.now(timezone.utc).isoformat(),
        source_commit=source,
        NPZ=rows,
        downloaded_bytes=downloaded,
        decoded_rows=0,
        label_payloads_opened=0,
        NN=0,
        future_labels="producer sealed; header only",
        raw_modified=False,
    )
    Path(cfg["header_out"]).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
