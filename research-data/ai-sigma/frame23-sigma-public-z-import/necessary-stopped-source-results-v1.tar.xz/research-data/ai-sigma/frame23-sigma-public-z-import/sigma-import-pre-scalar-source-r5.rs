//! Generic fixed-source Sigma original-plane stream to canonical external-z data.
use quoridor_data::{
    OutcomeImportConfig, import_sigma_outcomes, write_input_references, write_tensor_cache,
};
use std::{
    fs::File,
    io::{BufWriter, Write},
    path::PathBuf,
};
fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() == 5 && args[1] == "--config" && args[3] == "--receipt" {
        let config: OutcomeImportConfig = serde_json::from_reader(File::open(&args[2])?)?;
        let result = import_sigma_outcomes(std::io::stdin().lock(), &config)?;
        let path = PathBuf::from(&args[4]);
        let mut out = BufWriter::new(File::options().write(true).create_new(true).open(path)?);
        serde_json::to_writer_pretty(&mut out, &result)?;
        out.flush()?;
        return Ok(());
    }
    if (args.len() == 6 || args.len() == 7) && args[2] == "--input" && args[4] == "--output" {
        let allow = args.len() == 7 && args[6] == "--allow-test";
        let input = PathBuf::from(&args[3]);
        let output = PathBuf::from(&args[5]);
        match args[1].as_str() {
            "cache" => {
                println!(
                    "{}",
                    serde_json::to_string(&write_tensor_cache(&input, &output, allow)?)?
                );
            }
            "references" => {
                println!("{}", write_input_references(&input, &output, allow)?);
            }
            _ => return Err("unknown subcommand".into()),
        }
        return Ok(());
    }
    Err("sigma-import --config CONFIG --receipt NEW_RECEIPT (framed stdin); sigma-import <cache|references> --input DATASET --output NEWPATH [--allow-test]".into())
}
