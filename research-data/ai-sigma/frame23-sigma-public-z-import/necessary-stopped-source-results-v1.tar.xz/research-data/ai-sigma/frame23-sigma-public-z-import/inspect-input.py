"""Bounded target-free plane range diagnostic; no NPZ labels are opened."""

import argparse
import json
import os
from pathlib import Path
import time
import zipfile

os.environ["ORT_DISABLE_TELEMETRY"] = "1"
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = json.loads(Path(parser.parse_args().config).read_text())
    began = time.monotonic()
    results = []
    for item in cfg["cycles"]:
        with zipfile.ZipFile(item["path"]) as archive, archive.open("states.npy") as stream:
            version = np.lib.format.read_magic(stream)
            reader = {
                (1, 0): np.lib.format.read_array_header_1_0,
                (2, 0): np.lib.format.read_array_header_2_0,
            }.get(version)
            if reader is None:
                raise ValueError("unsupported NPY header version")
            shape, fortran, dtype = reader(stream, max_header_size=8192)
            assert not fortran and dtype == np.dtype("<f4") and shape[1:] == (8, 9, 9)
            count = (
                shape[0] // 2 if cfg.get("scan_all_original") else min(cfg["rows"], shape[0] // 2)
            )
            planes = [
                {
                    "channel": channel,
                    "finite_min": None,
                    "finite_max": None,
                    "nonfinite": 0,
                    "below_zero": 0,
                    "above_one": 0,
                    "outside_0_1": 0,
                    "first_invalid_original": None,
                    "witnesses": [],
                }
                for channel in range(8)
            ]
            first_remaining = None
            invalid_rows = set()
            for offset in range(0, count, 512):
                batch = min(512, count - offset)
                payload = stream.read(batch * 648 * 4)
                assert len(payload) == batch * 648 * 4
                states = np.frombuffer(payload, dtype="<f4").reshape(batch, 8, 9, 9)
                if first_remaining is None:
                    first_remaining = [float(states[0, channel, 0, 0]) for channel in (4, 5)]
                for channel in range(8):
                    part = states[:, channel]
                    finite = np.isfinite(part)
                    invalid = np.argwhere(~finite | (part < 0) | (part > 1))
                    invalid_rows.update(offset + int(row) for row in invalid[:, 0])
                    witnesses = [
                        {
                            "original_row": offset + int(row),
                            "channel": channel,
                            "y": int(y),
                            "x": int(x),
                            "flat_index": channel * 81 + int(y) * 9 + int(x),
                            "value": float(part[row, y, x]) if finite[row, y, x] else None,
                            "f32bits": int(part.view(np.uint32)[row, y, x]),
                        }
                        for row, y, x in invalid[:8]
                    ]
                    record = planes[channel]
                    values = part[finite]
                    if len(values):
                        lo, hi = float(values.min()), float(values.max())
                        record["finite_min"] = (
                            lo if record["finite_min"] is None else min(lo, record["finite_min"])
                        )
                        record["finite_max"] = (
                            hi if record["finite_max"] is None else max(hi, record["finite_max"])
                        )
                    record["nonfinite"] += int(np.count_nonzero(~finite))
                    record["below_zero"] += int(np.count_nonzero(part < 0))
                    record["above_one"] += int(np.count_nonzero(part > 1))
                    record["outside_0_1"] += len(invalid)
                    if witnesses and record["first_invalid_original"] is None:
                        record["first_invalid_original"] = witnesses[0]
                    record["witnesses"].extend(witnesses[: 8 - len(record["witnesses"])])
            firsts = [
                record["first_invalid_original"]
                for record in planes
                if record["first_invalid_original"]
            ]
            results.append(
                {
                    "cycle": item["cycle"],
                    "shape": shape,
                    "bounded_original_rows": count,
                    "planes": planes,
                    "original_rows_violating_range": len(invalid_rows),
                    "invalid_original_indices": sorted(invalid_rows),
                    "first_violation": min(
                        firsts, key=lambda r: (r["original_row"], r["channel"], r["flat_index"])
                    )
                    if firsts
                    else None,
                    "first_row_remaining_planes": first_remaining,
                }
            )
    Path(cfg["out"]).write_text(
        json.dumps(
            {
                "task": "sigma-public-z-import-289-v1",
                "schema": "target-free-plane-range-v1",
                "cycles": results,
                "labels_read": 0,
                "NN": 0,
                "wall_s": time.monotonic() - began,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
