"""Reuse source-bound integration artifacts; avoid another whole library LTO build."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = json.loads(Path(parser.parse_args().config).read_text())
    steps = []
    began = time.monotonic()
    for step in cfg["steps"]:
        start = time.monotonic()
        environment = dict(os.environ, CARGO_TARGET_DIR=cfg["target"], CARGO_BUILD_JOBS="1")
        result = subprocess.run(step["argv"], env=environment, check=False, timeout=step["hard"])
        steps.append(dict(step, exit=result.returncode, wall_s=time.monotonic() - start))
        if result.returncode:
            Path(cfg["failure_out"]).write_text(
                json.dumps(dict(steps=steps, NN=0), indent=2) + "\n"
            )
            raise ValueError("owned quality check failed")
    binary = Path(cfg["binary"])
    result = dict(
        task="sigma-public-z-import-289-v1",
        schema="importer-quality-v2",
        UTC=datetime.now(timezone.utc).isoformat(),
        steps=steps,
        wall_s=time.monotonic() - began,
        binary=str(binary),
        binary_SHA=hashlib.sha256(binary.read_bytes()).hexdigest(),
        previous_cargo_test="timeout during library-test LTO; completed owned integration executables reused with exact hashes",
        NN=0,
    )
    Path(cfg["receipt_out"]).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
