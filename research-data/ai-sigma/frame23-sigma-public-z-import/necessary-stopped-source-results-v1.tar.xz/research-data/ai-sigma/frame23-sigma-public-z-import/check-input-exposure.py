"""Target-free raw reference exposure; not a final actual-trained-seen mask."""

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import struct
import time


def rows(path):
    with gzip.open(path, "rt") as source:
        for line in source:
            row = json.loads(line)
            if any(key in row for key in ("z", "rootmean", "value", "winner", "primary_eligible")):
                raise ValueError("target-free whitelist contains targets")
            ids = row["actualSTM_ids"]
            bits = row["STM_distance_f32bits"]
            payload = b""
            for view in ids:
                payload += struct.pack("<H", len(view))
                payload += b"".join(struct.pack("<H", item) for item in view)
            payload += struct.pack("<2I", *bits)
            if hashlib.sha256(payload).hexdigest() != row["input_signature"]:
                raise ValueError("actual STM sparse-input/distance signature mismatch")
            yield row


def keysets(path):
    states, inputs = set(), set()
    count = 0
    for row in rows(path):
        states.add(row["state_key"])
        inputs.add(row["input_signature"])
        count += 1
    return states, inputs, count


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = json.loads(Path(parser.parse_args().config).read_text())
    began = time.monotonic()
    for path, digest in cfg["input_SHAs"].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != digest:
            raise ValueError("reference SHA mismatch")
    train, val, future = cfg["references"]
    trainstates, traininputs, nt = keysets(train)
    valstates, valinputs, nv = keysets(val)
    counts = {"future": 0, "future_OR_rawval": 0, "future_OR_rawtrain": 0}
    for row in rows(future):
        counts["future"] += 1
        counts["future_OR_rawval"] += int(
            row["state_key"] in valstates or row["input_signature"] in valinputs
        )
        counts["future_OR_rawtrain"] += int(
            row["state_key"] in trainstates or row["input_signature"] in traininputs
        )
    counts["train_OR_rawval"] = sum(
        row["state_key"] in valstates or row["input_signature"] in valinputs for row in rows(train)
    )
    result = {
        "task": "sigma-public-z-import-289-v1",
        "schema": "target-free-input-exposure-v1",
        "reference_SHAs": cfg["input_SHAs"],
        "raw_input_qualified_rows": {"train": nt, "validation": nv, "future": counts["future"]},
        "distinct_STM_inputs": {"train": len(traininputs), "validation": len(valinputs)},
        "counts": counts,
        "history": "UNAVAILABLE; null/empty history not treated as a shared history proof",
        "predicate": "OR nonempty state literal / verified actual STM sparse-input+f32distance signature",
        "trained_seen": "NOT_MEASURED; rawtrain conservative diagnostic, actual eligible/used train mask is learner-owned",
        "labels_read": 0,
        "NN": 0,
        "wall_s": time.monotonic() - began,
    }
    Path(cfg["out"]).write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
