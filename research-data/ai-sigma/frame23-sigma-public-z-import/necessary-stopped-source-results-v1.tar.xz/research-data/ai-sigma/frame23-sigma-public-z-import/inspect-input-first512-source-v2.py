"""Bounded target-free plane range diagnostic; no NPZ labels are opened."""

import argparse
import json
import os
from pathlib import Path
import time
import zipfile

os.environ["ORT_DISABLE_TELEMETRY"] = "1"
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = json.loads(Path(parser.parse_args().config).read_text())
    began = time.monotonic()
    results = []
    for item in cfg["cycles"]:
        with zipfile.ZipFile(item["path"]) as archive, archive.open("states.npy") as stream:
            version = np.lib.format.read_magic(stream)
            reader = {
                (1, 0): np.lib.format.read_array_header_1_0,
                (2, 0): np.lib.format.read_array_header_2_0,
            }.get(version)
            if reader is None:
                raise ValueError("unsupported NPY header version")
            shape, fortran, dtype = reader(stream, max_header_size=8192)
            assert not fortran and dtype == np.dtype("<f4") and shape[1:] == (8, 9, 9)
            count = min(cfg["rows"], shape[0])
            payload = stream.read(count * 648 * 4)
            assert len(payload) == count * 648 * 4
            states = np.frombuffer(payload, dtype="<f4").reshape(count, 8, 9, 9)
            planes = []
            for channel in range(8):
                part = states[:, channel]
                finite = np.isfinite(part)
                invalid = np.argwhere(~finite | (part < 0) | (part > 1))
                witnesses = [
                    {
                        "original_row": int(row),
                        "channel": channel,
                        "y": int(y),
                        "x": int(x),
                        "flat_index": channel * 81 + int(y) * 9 + int(x),
                        "value": float(part[row, y, x]) if finite[row, y, x] else None,
                        "f32bits": int(part.view(np.uint32)[row, y, x]),
                    }
                    for row, y, x in invalid[:8]
                ]
                values = part[finite]
                planes.append(
                    {
                        "channel": channel,
                        "finite_min": float(values.min()) if len(values) else None,
                        "finite_max": float(values.max()) if len(values) else None,
                        "nonfinite": int(np.count_nonzero(~finite)),
                        "below_zero": int(np.count_nonzero(part < 0)),
                        "above_one": int(np.count_nonzero(part > 1)),
                        "outside_0_1": len(invalid),
                        "first_invalid_original": witnesses[0] if witnesses else None,
                        "witnesses": witnesses,
                    }
                )
            results.append(
                {
                    "cycle": item["cycle"],
                    "shape": shape,
                    "bounded_first_rows": count,
                    "planes": planes,
                    "first_row_remaining_planes": [
                        float(states[0, channel, 0, 0]) for channel in (4, 5)
                    ],
                }
            )
    Path(cfg["out"]).write_text(
        json.dumps(
            {
                "task": "sigma-public-z-import-289-v1",
                "schema": "target-free-plane-range-v1",
                "cycles": results,
                "labels_read": 0,
                "NN": 0,
                "wall_s": time.monotonic() - began,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
