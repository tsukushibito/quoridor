"""Producer-only original-group NPZ decoder and native canonical-z import pipeline."""

import argparse
from datetime import datetime, timezone
import gc
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import time
import zipfile

# No framework telemetry, model import, or numerical forward in this importer.
os.environ["ORT_DISABLE_TELEMETRY"] = "1"
import numpy as np


def write(path, data):
    Path(path).write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def allocated(roots):
    seen = set()
    total = 0
    for root in roots:
        for base, _, names in os.walk(root):
            for name in names:
                stat = (Path(base) / name).stat()
                key = (stat.st_dev, stat.st_ino)
                if key not in seen:
                    seen.add(key)
                    total += stat.st_blocks * 512
    return total


def complete_groups(states, cap):
    counts = {}
    keys = []
    for row in states:
        key = hashlib.sha256(row.tobytes(order="C")).digest()
        keys.append(key)
        counts[key] = counts.get(key, 0) + 1
    selected = set()
    total = 0
    for key, count in counts.items():
        if total + count > cap:
            break
        selected.add(key)
        total += count
    indices = [index for index, key in enumerate(keys) if key in selected]
    return indices, len(counts), len(selected)


def array(archive, name):
    with archive.open(name + ".npy") as stream:
        result = np.lib.format.read_array(stream, allow_pickle=False, max_header_size=8192)
    if result.dtype != np.dtype("<f4"):
        raise ValueError("dtype not bound f32")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = json.loads(Path(parser.parse_args().config).read_text())
    quality = json.loads(Path(cfg["quality_receipt"]).read_text())
    if quality["schema"] != "importer-quality-v2" or sha(cfg["binary"]) != quality["binary_SHA"]:
        raise ValueError("qualified current native binary binding")
    assets = Path(cfg["assets"])
    assets.mkdir(parents=True, exist_ok=True)
    results = []
    began = time.monotonic()
    for item in cfg["cycles"]:
        cycle = item["cycle"]
        folder = assets / f"cycle_{cycle:04d}"
        folder.mkdir(exist_ok=False)
        source = Path(item["path"])
        if sha(source) != item["SHA256"]:
            raise ValueError("immutable NPZ SHA")
        started = time.monotonic()
        with zipfile.ZipFile(source) as archive:
            states = array(archive, "states")
            n = states.shape[0]
            if states.shape != (n, 8, 9, 9) or n % 2:
                raise ValueError("state shape/halves")
            half = n // 2
            for start in range(0, half, 512):
                original = states[start : min(start + 512, half)]
                mirror = states[half + start : half + min(start + 512, half)]
                if not np.isfinite(original).all() or np.any(original < 0) or np.any(original > 1):
                    raise ValueError("source input finite/range")
                if not np.array_equal(
                    original[:, :, :, ::-1].view(np.uint32), mirror.view(np.uint32)
                ):
                    raise ValueError("actual full-plane LR byte correspondence unavailable")
            indices, raw_groups, selected_groups = complete_groups(
                states[:half], item["complete_group_row_cap"]
            )
            selection = dict(
                schema="original-complete-input-group-prefix-v2",
                source_SHA=item["SHA256"],
                original_rows=half,
                original_input_groups=raw_groups,
                selected_groups=selected_groups,
                selected_original_indices=indices,
                cap=item["complete_group_row_cap"],
                label_payloads_read_at_freeze=0,
                group_key="SHA256 original full8plane STM f32bytes; LR sibling excluded",
                selection_rule="groups in first-original-index order; stop before whole group crosses row cap",
                all_augmented_rows_excluded=half,
                actual_full_LR_bytes="PASS",
            )
            selection_path = folder / "input-selection-frozen.json"
            write(selection_path, selection)
            # Selection is immutable and label-free before this first value read.
            values = array(archive, "values")
            if (
                values.shape != (n,)
                or not np.isfinite(values).all()
                or not np.isin(values, [-1, 0, 1]).all()
            ):
                raise ValueError("recorded z shape/finite/outcome range")
            if not np.array_equal(values[:half].view(np.uint32), values[half:].view(np.uint32)):
                raise ValueError("LR sibling recorded-z mismatch")
            write(
                folder / "private-values-summary.json",
                dict(
                    raw_rows=n,
                    raw_zero=int(np.count_nonzero(values == 0)),
                    original_rows=half,
                    original_zero=int(np.count_nonzero(values[:half] == 0)),
                    raw_positive=int(np.count_nonzero(values == 1)),
                    raw_negative=int(np.count_nonzero(values == -1)),
                    zero_status="EXCLUDED_TERMINATION_REASON_UNAVAILABLE",
                    provenance="recorded source outcomes, terminal reason/game ID unavailable",
                    future_label_summary="producer only"
                    if item["split"] == "test"
                    else "authorized training/selection",
                ),
            )
            native_cfg = dict(
                source="bartolomeo3000/SigmaQuoridor",
                revision=cfg["source_commit"],
                shard=f"runs/data_9x9_fix/cycle_{cycle:04d}.npz",
                split=item["split"],
                records=len(indices),
                output=str(folder / "dataset"),
            )
            native_plan = folder / "native-import.json"
            write(native_plan, native_cfg)
            receipt_path = folder / "native-import-receipt.json"
            child = subprocess.Popen(
                [cfg["binary"], "--config", str(native_plan), "--receipt", str(receipt_path)],
                stdin=subprocess.PIPE,
            )
            try:
                for index in indices:
                    child.stdin.write(struct.pack("<Q", index))
                    child.stdin.write(states[index].tobytes(order="C"))
                    child.stdin.write(values[index].tobytes())
                child.stdin.close()
                exit_code = child.wait(timeout=240)
                if exit_code:
                    raise ValueError(f"native source-input qualification/import exit{exit_code}")
            finally:
                if child.poll() is None:
                    child.terminate()
                    try:
                        child.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait()
            del states, values
        del indices
        gc.collect()
        allow = ["--allow-test"] if item["split"] == "test" else []
        dataset = folder / "dataset"
        # Exact dense tensor size; metadata/canonical/raw/requiredGit stay in own guard.
        native = json.loads(receipt_path.read_text())
        needed = native["records"] * (624 * 4 + 16) + native["records"] * 1100
        if (
            allocated(cfg["retained_roots"]) + needed + cfg["remaining_Git_temp_reserve"]
            > cfg["storage_cap"]
        ):
            raise ValueError("next canonicalcache footprint+necessaryGit/temp guard")
        with (folder / "cache-command.json").open("xb") as out:
            subprocess.run(
                [
                    cfg["binary"],
                    "cache",
                    "--input",
                    str(dataset),
                    "--output",
                    str(folder / "cache"),
                    *allow,
                ],
                stdout=out,
                check=True,
                timeout=120,
            )
        refs = folder / "input-references.jsonl"
        subprocess.run(
            [cfg["binary"], "references", "--input", str(dataset), "--output", str(refs), *allow],
            check=True,
            timeout=90,
        )
        cache = json.loads((folder / "cache/cache.json").read_text())
        for name, expected in cache["sha256"].items():
            if sha(folder / "cache" / name) != expected:
                raise ValueError("canonical cache member SHA")
        if (
            allocated(cfg["retained_roots"]) + cfg["remaining_Git_temp_reserve"]
            > cfg["storage_cap"]
        ):
            raise ValueError("actual own allocated+necessaryGit/temp guard")
        row = dict(
            cycle=cycle,
            partition=item["split"],
            NPZ_SHA=item["SHA256"],
            original_rows=half,
            selected_rows=native["records"],
            groups=selected_groups,
            native_dataset=str(dataset),
            manifest_SHA=sha(dataset / "manifest.json"),
            cache=str(folder / "cache"),
            cache_SHA=sha(folder / "cache/cache.json"),
            target_free_refs=str(refs),
            refs_SHA=sha(refs),
            input_selection_SHA=sha(selection_path),
            raw_LR_bytes="PASS, entire secondhalf excluded",
            wall_distance_check="native all648planes including all81 maps each selected original",
            source_math="unchanged native QF1/STM + recorded z only, rootmean absent",
            eligibility="z0 excluded termination-reason-unavailable, raw preserved",
            labels="PRODUCER_SEALED" if item["split"] == "test" else "authorized train/selection",
            NN=0,
            wall_s=time.monotonic() - started,
        )
        if item["split"] != "test":
            row.update(
                positive=native["positive"],
                negative=native["negative"],
                zero=native["zero"],
                eligible_rows=native["positive"] + native["negative"],
            )
        results.append(row)
        write(
            cfg["partial_out"],
            dict(
                task="sigma-public-z-import-289-v1",
                schema="public-canonical-handoff-v2",
                cycles=results,
                NN=0,
            ),
        )
    write(
        cfg["result_out"],
        dict(
            task="sigma-public-z-import-289-v1",
            schema="public-canonical-handoff-v2",
            UTC=datetime.now(timezone.utc).isoformat(),
            cycles=results,
            source_commit=cfg["source_commit"],
            wall_s=time.monotonic() - began,
            NN=0,
            future="labels and z counts producer sealed; target-free references only before freeze",
            independent_game_history="UNAVAILABLE; input-groups not games",
            binary_SHA=quality["binary_SHA"],
        ),
    )


if __name__ == "__main__":
    main()
