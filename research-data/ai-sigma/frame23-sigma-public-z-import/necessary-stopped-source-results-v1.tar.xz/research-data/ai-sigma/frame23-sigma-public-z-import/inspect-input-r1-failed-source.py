"""Bounded target-free plane range diagnostic; no NPZ labels are opened."""

import argparse
import json
import os
from pathlib import Path
import time
import zipfile

os.environ["ORT_DISABLE_TELEMETRY"] = "1"
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = json.loads(Path(parser.parse_args().config).read_text())
    began = time.monotonic()
    results = []
    for item in cfg["cycles"]:
        with zipfile.ZipFile(item["path"]) as archive, archive.open("states.npy") as stream:
            version = np.lib.format.read_magic(stream)
            shape, fortran, dtype = np.lib.format._read_array_header(
                stream, version, max_header_size=8192
            )
            assert not fortran and dtype == np.dtype("<f4") and shape[1:] == (8, 9, 9)
            count = min(cfg["rows"], shape[0])
            payload = stream.read(count * 648 * 4)
            assert len(payload) == count * 648 * 4
            states = np.frombuffer(payload, dtype="<f4").reshape(count, 8, 9, 9)
            planes = []
            for channel in range(8):
                part = states[:, channel]
                invalid = np.argwhere(~np.isfinite(part) | (part < 0) | (part > 1))
                witnesses = [
                    {"row": int(row), "y": int(y), "x": int(x), "value": float(part[row, y, x])}
                    for row, y, x in invalid[:8]
                ]
                planes.append(
                    {
                        "channel": channel,
                        "min": float(part.min()),
                        "max": float(part.max()),
                        "outside_0_1": len(invalid),
                        "witnesses": witnesses,
                    }
                )
            results.append(
                {
                    "cycle": item["cycle"],
                    "shape": shape,
                    "bounded_first_rows": count,
                    "planes": planes,
                    "first_row_remaining_planes": [
                        float(states[0, channel, 0, 0]) for channel in (4, 5)
                    ],
                }
            )
    Path(cfg["out"]).write_text(
        json.dumps(
            {
                "task": "sigma-public-z-import-289-v1",
                "schema": "target-free-plane-range-v1",
                "cycles": results,
                "labels_read": 0,
                "NN": 0,
                "wall_s": time.monotonic() - began,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
