"""Join native original scalar labels to the already frozen old287 canonical IDs."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = json.loads(Path(parser.parse_args().config).read_text())
    began = time.monotonic()
    for path, expected in cfg["input_SHAs"].items():
        if sha(path) != expected:
            raise ValueError("old287 frozen input SHA mismatch")
    release = json.loads(Path(cfg["release"]).read_text())
    blocks = []
    for block in release["blocks"]:
        number = block["block"]
        aliases = {r["native_family"]: r["canonical_family"] for r in block["aliases"]}
        public = Path(block["public_input_projection"]["path"])
        planned = {
            (r["canonical_family"], r["id"])
            for r in map(json.loads, public.read_text().splitlines())
        }
        raw = Path(cfg["out_dir"]) / f"old287-block{number}-native-scalars.jsonl"
        subprocess.run(
            [
                cfg["binary"],
                "labels",
                "--input",
                block["dataset_directory"],
                "--output",
                str(raw),
                "--allow-test",
            ],
            check=True,
            timeout=15,
        )
        output = raw.with_name(f"old287-block{number}-canonical-scalars.jsonl")
        seen = set()
        with raw.open() as source, output.open("x") as writer:
            for line in source:
                row = json.loads(line)
                family = aliases[row["native_family"]]
                key = (family, row["id"])
                if key not in planned or key in seen:
                    raise ValueError("canonical family/row join mismatch or duplicate")
                if any(
                    not isinstance(row[k], (float, int))
                    or not math.isfinite(row[k])
                    or abs(row[k]) > 1
                    for k in ("rootmean", "z")
                ):
                    raise ValueError("stored scalar missing/nonfinite or out of range")
                seen.add(key)
                writer.write(
                    json.dumps(
                        {
                            "canonical_family": family,
                            "id": row["id"],
                            "rootmean": row["rootmean"],
                            "z": row["z"],
                        },
                        allow_nan=False,
                    )
                    + "\n"
                )
        if seen != planned:
            raise ValueError("missing old287 row IDs")
        blocks.append(
            {
                "block": number,
                "rows": len(seen),
                "path": str(output),
                "SHA": sha(output),
                "native_raw_SHA": sha(raw),
                "source_dataset_manifest_SHA": block["manifest"]["SHA256"],
            }
        )
    result = {
        "task": "sigma-public-z-import-289-v1",
        "schema": "old287-frozen-scalar-handoff-v1",
        "blocks": blocks,
        "rows": sum(r["rows"] for r in blocks),
        "planned_families": 96,
        "release_SHA": sha(cfg["release"]),
        "rootmean_z": "original native serialized f32 values, unchanged, old287 one frozen evaluation only",
        "public0043": "SEALED; not read",
        "NN": 0,
        "wall_s": time.monotonic() - began,
    }
    Path(cfg["out"]).write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
