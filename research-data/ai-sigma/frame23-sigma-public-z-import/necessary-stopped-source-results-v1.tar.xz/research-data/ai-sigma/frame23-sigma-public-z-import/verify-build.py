"""Sequential offline owned-crate quality checks with a shared-build growth bound."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def allocated(root):
    seen = set()
    total = 0
    for base, _, names in os.walk(root):
        for name in names:
            try:
                stat = (Path(base) / name).stat()
            except FileNotFoundError:
                continue
            key = (stat.st_dev, stat.st_ino)
            if key not in seen:
                seen.add(key)
                total += stat.st_blocks * 512
    return total


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = json.loads(Path(parser.parse_args().config).read_text())
    environment = dict(os.environ, CARGO_TARGET_DIR=cfg["target"], CARGO_BUILD_JOBS="1")
    before = allocated(cfg["target"])
    steps = []
    start = time.monotonic()
    for argv, hard in cfg["steps"]:
        if time.monotonic() - start + hard > 180:
            raise ValueError("verification aggregate 180s reserve unavailable")
        began = time.monotonic()
        result = subprocess.run(argv, env=environment, timeout=hard, check=False)
        steps.append(
            dict(argv=argv, hard=hard, exit=result.returncode, wall_s=time.monotonic() - began)
        )
        growth = max(0, allocated(cfg["target"]) - before)
        if result.returncode != 0 or growth > cfg["growth_cap_bytes"]:
            Path(cfg["failure_out"]).write_text(
                json.dumps(dict(steps=steps, growth=growth, NN=0), indent=2) + "\n"
            )
            raise ValueError("quality failure or shared-build growth cap")
    binary = Path(cfg["binary"])
    receipt = dict(
        task="sigma-public-z-import-289-v1",
        schema="importer-build-quality-v1",
        UTC=datetime.now(timezone.utc).isoformat(),
        steps=steps,
        command_wall_s=time.monotonic() - start,
        target_before=before,
        target_after=allocated(cfg["target"]),
        binary=str(binary),
        binary_SHA=hashlib.sha256(binary.read_bytes()).hexdigest(),
        NN=0,
    )
    Path(cfg["receipt_out"]).write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
