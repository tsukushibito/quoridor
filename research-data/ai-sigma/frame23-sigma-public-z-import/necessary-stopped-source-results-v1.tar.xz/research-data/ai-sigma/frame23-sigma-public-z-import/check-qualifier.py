"""NN0 framing/schema rejection checks for the generic input-only reader."""

import argparse
import json
from pathlib import Path
import struct
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    output = Path(args.out)
    planes = [0.0] * 648
    payload = struct.pack("<Q648f", 7, *planes)
    planes[0] = float("nan")
    payload += struct.pack("<Q648f", 9, *planes)
    subprocess.run(
        [args.binary, "--qualify-inputs", "2", "--output", str(output)],
        input=payload,
        check=True,
        timeout=1,
    )
    rows = [json.loads(line) for line in output.read_text().splitlines()]
    assert [row["original_index"] for row in rows] == [7, 9]
    assert all(row["input_valid"] is False and row["reason"] for row in rows)
    assert all(set(row) == {"original_index", "input_valid", "reason"} for row in rows)
    result = subprocess.run(
        [args.binary, "--qualify-inputs", "1", "--output", str(output) + ".truncated"],
        input=b"partial",
        timeout=1,
        check=False,
    )
    assert result.returncode != 0
    print(json.dumps({"NN": 0, "labels_read": 0, "schema_and_truncation": "PASS"}))


if __name__ == "__main__":
    main()
