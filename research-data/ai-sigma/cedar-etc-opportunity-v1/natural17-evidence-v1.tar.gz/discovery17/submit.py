"""Submit discovery17 once via the normal direct Popen client outside Cycle."""

from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path("/workspaces/quoridor")
PHASE = Path(__file__).resolve().parent
SOURCE = ROOT / ".worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1"
B = ROOT / ".worktree/search-optimization/.artifacts/worktree-retirement-v1/group-B"
OUT = PHASE / "submission-v1"
OUT.mkdir(exist_ok=False)


def ref(path):
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def save(name, value):
    p = OUT / name
    with p.open("x") as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write("\n")
    return ref(p)


materialized_path = PHASE / "binding-v3/materialized.json"
materialized = json.loads(materialized_path.read_text())
assert (
    ref(materialized_path)["sha256"]
    == "8d2bf1734b11dc4f9b0b9fa84975030a249e6f3089f7a5fb2bfc58b35c4a228f"
)
for key in ["settings", "job_template", "RUN", "experiment", "numerical", "config", "requests"]:
    assert ref(Path(materialized[key]["path"])) == materialized[key]
affinity = materialized["configured_job_cpu_plan"]["allocation"]
assert os.sched_getaffinity(0) == set(affinity)
assert materialized["source_NB_SH"]["remaining"] == []
assert (PHASE / "preclock-admin-v1/admin.json").is_file()
assert not (SOURCE / "CANCEL").exists()
run = json.loads(Path(materialized["RUN"]["path"]).read_text())
data = Path(run["data_root"])
assert data.parent.resolve(strict=True) == PHASE / "native"
assert data.parent.is_relative_to(ROOT) and not data.parent.is_symlink()
assert not data.exists() and not data.is_symlink()
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def current_identity(original):
    try:
        text = Path(f"/proc/{original['pid']}/stat").read_text()
    except FileNotFoundError:
        return "ABSENT"
    assert boot != original["boot_id"] or text.rsplit(")", 1)[1].split()[19] != str(
        original["start_ticks"]
    )
    return "DIFFERENT_IDENTITY"


helpers = []
for base, name in [
    (B, "first-read-helper-v1"),
    (B, "first-read-delivery-helper-v1"),
    (B, "six-candidate-intake-helper-v1"),
    (SOURCE, "discovery17-materialize-helper-v1"),
    (SOURCE, "discovery17-materialize-helper-v2"),
    (SOURCE, "discovery17-materialize-helper-v3"),
    (SOURCE, "discovery17-preclock-admin-helper-v1"),
    (SOURCE, "discovery17-submit-format-helper-v1"),
]:
    directory = base / name
    returned = json.loads((directory / "return.json").read_text())
    process = returned or json.loads((directory / "command.process.json").read_text())
    assert process["direct_child_reaped"] and process["process_cleanup_complete"]
    assert process["handle_closes_complete"] and process["remaining"] == []
    assert not (directory / "TMP").exists()
    controller = json.loads((directory / "controller.json").read_text())["identity"]
    helpers.append(
        dict(
            phase=str(directory),
            normal_return=returned,
            persisted_process=None if returned else ref(directory / "command.process.json"),
            child_now=current_identity(process["child"]),
            controller_now=current_identity(controller),
            remaining=[],
            TMP=[],
            sourceleases=[],
        )
    )
stop_ref = save(
    "actual-preentry-source-STOP.json",
    dict(
        at=datetime.now(timezone.utc).isoformat(),
        helpers=helpers,
        source_shared_lease=materialized["source_NB_SH"],
        sourceleases=[],
        Main_reader=False,
        native_entry="UNKNOWN_NOT_OBSERVED",
        groupB_heavy_archive_IO_entered=False,
        failed_metadata_and_B_partial_refusal_preserved=True,
        no_returned_cleanup_promotion=True,
        current_tail="This submit client only; normal job owns actual admission/timing/collection; no futurequiet",
    ),
)
template = json.loads(Path(materialized["job_template"]["path"]).read_text())
now = datetime.now(timezone.utc)
job = dict(
    template,
    end_at=(now + timedelta(seconds=1200)).isoformat(),
    notify_until=(now + timedelta(days=2)).isoformat(),
)
config_ref = save("job-entry.json", job)
state = PHASE / "parent-runtime-v1"
assert not state.exists()
env = dict(os.environ)
env["PATH"] = "/home/vscode/.local/bin:" + env["PATH"]
env.update(UV_NO_SYNC="1", UV_OFFLINE="1", PYTHONDONTWRITEBYTECODE="1")
assert shutil.which("uv", path=env["PATH"]) == "/home/vscode/.local/bin/uv"
command = [
    "/usr/bin/taskset",
    "-c",
    ",".join(map(str, affinity)),
    "/bin/bash",
    str(ROOT / "scripts/dev/research-job.sh"),
    "submit",
    "--config",
    config_ref["path"],
    "--state-dir",
    str(state),
]
save(
    "submit-once.json",
    dict(
        at=now.isoformat(),
        command=command,
        config=config_ref,
        state=str(state),
        affinity=affinity,
        direct_Popen_outside_Cycle=True,
        automatic_retry=False,
        acceptance_not_native_START=True,
    ),
)
process = subprocess.Popen(
    command,
    cwd=ROOT,
    env=env,
    stdin=subprocess.DEVNULL,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
)
timed_out = False
try:
    try:
        stdout, stderr = process.communicate(timeout=90)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.terminate()
        try:
            stdout, stderr = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate(timeout=5)
    process.wait(timeout=0)
finally:
    for pipe in [process.stdout, process.stderr]:
        if pipe:
            pipe.close()
(OUT / "submit.stdout").write_bytes(stdout)
(OUT / "submit.stderr").write_bytes(stderr)
receipt = dict(
    at=datetime.now(timezone.utc).isoformat(),
    config=config_ref,
    state_dir=str(state),
    command=command,
    client_returncode=process.returncode,
    directwait_reaped=process.returncode is not None,
    handles_closed=True,
    timed_out=timed_out,
    stdout=ref(OUT / "submit.stdout"),
    stderr=ref(OUT / "submit.stderr"),
    actual_native_entry="UNKNOWN_NOT_OBSERVED",
)
if process.returncode == 0 and not timed_out:
    receipt["accepted_RPC"] = json.loads(stdout)
else:
    receipt["status"] = "CLIENT_FAILED_OR_UNCERTAIN_NO_AUTOMATIC_RETRY"
receipt_ref = save("submit-return.json", receipt)
print(json.dumps(receipt), flush=True)
body = (
    "SAME33 original discovery17 ONE normalhighestparent actualsubmit receipt, RPC ONLY/nativeSTART UNKNOWN.\n"
    "Receipt "
    + json.dumps(receipt_ref)
    + "\nMaterialized "
    + json.dumps(ref(materialized_path))
    + "\nActual preentry helpers/sourceSTOP "
    + json.dumps(stop_ref)
    + f"\nClientreturn{process.returncode}/timedout{timed_out}, directPopen/communicate/wait/reap/pipesclosed "
    "OUTSIDECycle, actualuvPATH and current common-derived launcher[0,12,18]. Current factory actual "
    "RUNcpu2/sequence+jobcpu3 verified against v2ONLYsupport12e5f2bd/release9d20528e/newBUILDbfe83000/"
    "image87ea4af1/current4 exact. Input/model/library/ELF qualification belongs normal entry only. "
    "One17/D5/timeNone/reserveABSENT/fullindices0..16/fourchronologicalsessions/allpredecessors/"
    "1M each17M/CurrentCedarControlbaselineLMRPVS/safeRaceONpath_tail/TT1048576/MPCparams+samplerABSENT/"
    "aspOFF. Empty measurementPlan/approvedNone; dataPARENTcanonicalexisting/outputrootabsent. "
    "F4GiB incl1.5+2.5/host4/G0/threads1/onewhole2240MiB exact21rootunion. Parent1200/command1140/"
    "RUN900/cleanup60, freshend_at once. Ownnote+backup beforeclock, all helpers returned including "
    "GroupB partialmetadata failure (noarchive/heavyIO); preserved both preentry metadataerrors, "
    "no scientificentry reset/refill. Runtime owns fresh source/ownerpausecancel/physicalSMT/peer/"
    "RAM/free/fullroot/serializer/origin/cleanup; acceptance not admission. Originalcompletion "
    "owns onceALL17native+normalcollection immediate wholeSTOP+endedholdingRoot BEFORE longanalysis; "
    "no observer/statuspoll/startprobe/duplicate/refinalize. CandidateNULL/confirmation72/games "
    "UNISSUED. Cumulative8softwareSearch<=400kupper actualNOT_EXTRACTED separate, independenthard512/"
    "512M; no old31quota. AllFAILED/NULL/masks/costUNKNOWN/pauses/seals/defaults/models/foreign preserved.\n"
)
path = OUT / "accepted-handoff.txt"
path.write_text(body)
delivery = subprocess.run(
    [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--body-file",
        str(path),
    ],
    cwd=ROOT,
    env=env,
    capture_output=True,
    text=True,
    timeout=60,
)
save(
    "Root-delivery.json",
    dict(exit_code=delivery.returncode, stdout=delivery.stdout, stderr=delivery.stderr),
)
assert delivery.returncode == 0
assert process.returncode == 0 and not timed_out, receipt
