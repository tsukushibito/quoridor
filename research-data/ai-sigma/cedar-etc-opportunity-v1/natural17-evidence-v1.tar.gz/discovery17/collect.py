"""Collect original saved normal receipts once; never execute a qualifier or Search."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

PHASE = Path(__file__).resolve().parent
OUT = PHASE / "collection-v1"
OUT.mkdir(exist_ok=False)


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def read(path):
    return json.loads(path.read_text())


def load(descriptor):
    path = Path(descriptor["path"])
    assert ref(path) == descriptor
    return read(path)


def save(name, value):
    path = OUT / name
    with path.open("x") as handle:
        handle.write(json.dumps(value, indent=2, allow_nan=False) + "\n")
    return ref(path)


outer = read(PHASE / "parent-runtime-v1/result.json")
seq = read(PHASE / "sequence/result.json")
assert outer["job_id"] == "2de83f6d-90d8-4940-9578-a03adadf8242"
assert outer["outcome"] == "succeeded" and outer["cleanup_complete"]
assert outer["direct_child_reaped"] and outer["remaining"] == []
assert seq["status"] == "PASS" and seq["primary"] is None and seq["secondary"] == []
assert seq["completed_operations"] == seq["selected_operations"] == 1
assert seq["cleanup_complete"] and seq["remaining"] == []
entry = seq["operations"][0]
manifest = load(entry["manifest"])
inner = load(entry["job_result"])
assert manifest["status"] == manifest["data"]["status"] == "PASS"
assert manifest["primary"] is None and manifest["secondary"] == []
assert manifest["cleanup_complete"] and manifest["remaining"] == []
assert inner["cleanup_complete"] and inner["direct_child_reaped"] and inner["remaining"] == []
check = manifest["checks"][0]
returned = check["guardian_return"]
assert check["status"] == "PASS" and check["capture_complete"]
assert returned["exit_code"] == 0 and returned["direct_child_reaped"]
assert returned["handle_closes_complete"] and returned["cleanup_complete"]
assert returned["remaining"] == []
measure = manifest["data"]["measurement"]
assert measure["journal_rows"] == 17 and measure["journal_result_rows_agree"]
assert not measure["journal_partial_tail"]
result = measure["result"]
assert result["planned"] == result["calls"] == 17
assert result["complete"] + result["uncompleted"] == 17
assert result["unperformed"] == result["extra_calls"] == 0 and result["errors"] == []
assert not (PHASE / "sequence/run-000/operation/INCOMPLETE").exists()
assert not (PHASE / "sequence/run-000/TMP").exists()
assert measure["runtime_launch_origin"]["native"] == returned["child"]
identities = [
    seq["originating_job"]["child"],
    manifest["originating_job"]["child"],
    returned["child"],
    measure["runtime_launch_origin"]["guardian"],
]
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def fresh(identity):
    try:
        stat = Path(f"/proc/{identity['pid']}/stat").read_text()
    except FileNotFoundError:
        return dict(identity=identity, state="absent")
    same = boot == identity["boot_id"] and stat.rsplit(")", 1)[1].split()[19] == str(
        identity["start_ticks"]
    )
    return dict(identity=identity, state="same_identity_live" if same else "different_identity")


records = [fresh(i) for i in {tuple(i.values()): i for i in identities}.values()]
assert all(r["state"] != "same_identity_live" for r in records)
storage_path = PHASE / "sequence/run-000/operation/storage-usage.json"
storage = read(storage_path)
bound = read(PHASE / "binding-v3/materialized.json")
assert set(storage["roots"]) == set(bound["charged_roots"])
assert storage["storage_budget_B"] == bound["whole_B"] == 2348810240
holding = save(
    "ended-holding.json",
    dict(
        original_normal_point=ref(storage_path),
        allocated_B=storage["allocated_B"],
        roots=len(storage["roots"]),
        observed_at=storage["observed_at"],
        method="Reuse actual owning terminal directed inodeunion once; no rewalk/recharge/refund/lending",
        later_tails_globalactual_fullfees="UNKNOWN",
    ),
)
collection = save(
    "collection.json",
    dict(
        issue="quoridor-4lc.324.33",
        original_job=outer["job_id"],
        outer=ref(PHASE / "parent-runtime-v1/result.json"),
        sequence=ref(PHASE / "sequence/result.json"),
        manifest=entry["manifest"],
        inner=entry["job_result"],
        normal_manifest="PASS",
        normal_data="PASS",
        published_calls=17,
        driver_complete=result["complete"],
        driver_uncompleted=result["uncompleted"],
        native_files=manifest["data"]["files"],
        original_guardian_return=returned,
        journal_rows_agree=True,
        reader_STOP=seq["reader_STOP"],
        source_leases=[],
        TMP=[],
        costs=dict(outer_seconds_once=outer["wall_seconds"], nested_added=0, fullfees="UNKNOWN"),
        opportunity_eligibility="PENDING saved witness analysis; normal custody is separate",
    ),
)
stop = save(
    "native-normal-source-STOP.json",
    dict(
        at=datetime.now(timezone.utc).isoformat(),
        issue="quoridor-4lc.324.33",
        original_job=outer["job_id"],
        whole17_lifetime_complete=True,
        collection=collection,
        ended_holding=holding,
        scientific_identities_fresh=records,
        supervisor_fresh=fresh(seq["originating_job"]["supervisor"]),
        supervisor_scope="Finished original supervisor may only deliver notifications; no future quiet claim",
        directwait_reap_handles="Original native/inner/outer receipts bound unchanged",
        TMP=[],
        remaining=[],
        source_leases=[],
        collector_tail="Bounded saved metadata collector only; helper return bound by delivery after return",
        no_Search_validator_FINALIZE_model_input_ELF_RNG_replay=True,
    ),
)
print(json.dumps(dict(collection=collection, STOP=stop, ended_holding=holding)))
