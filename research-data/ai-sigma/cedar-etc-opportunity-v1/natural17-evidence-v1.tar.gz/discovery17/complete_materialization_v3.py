"""Complete the descriptor-based CPU projection after a pre-native metadata refusal."""

from copy import deepcopy
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
PHASE = Path(__file__).resolve().parent
OUT = PHASE / "binding-v3"
OUT.mkdir(exist_ok=False)
SOURCE = ROOT / ".worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1"
ENTRY = (
    ROOT / ".artifacts/research-team/integration324/cedar-etc-opportunity-v1/discovery17-entry-v1"
)


def ref(path):
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def save(name, value):
    p = OUT / name
    with p.open("x") as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write("\n")
    return ref(p)


support_ref = dict(
    path=str(ENTRY / "support-v2/phase-support-discovery17-v2.json"),
    sha256="12e5f2bdb94eb20d5050fae12da15ad2360462e8ee7afa84233e0d1f23378029",
    bytes=12784,
    mode="0644",
)
assert ref(Path(support_ref["path"])) == support_ref
support = json.loads(Path(support_ref["path"]).read_text())
release_ref = support["source_release"]
assert ref(Path(release_ref["path"])) == release_ref
release = json.loads(Path(release_ref["path"]).read_text())
run_ref = ref(PHASE / "controls/RUN-template.json")
run = json.loads(Path(run_ref["path"]).read_text())
assert run["support"] == support_ref and run["artifact"] == release["image"]
assert run["caller_sources"] == release["current_callers"]
DATA = Path(run["data_root"])
assert DATA.parent.resolve(strict=True) == PHASE / "native"
assert not DATA.exists() and not DATA.is_symlink()
settings = dict(
    schema="quoridor.research.sequence-settings.v1",
    kind="sequence",
    owner=str(ROOT),
    cwd=str(ROOT),
    output=str(PHASE / "sequence"),
    runs=[run],
    limits=deepcopy(support["parent_sequence_limits"]),
    support=support_ref,
    command_timeout_seconds=1140,
    pause_file=str(SOURCE / "CANCEL"),
    caller_sources=release["current_callers"],
    source_release=release_ref,
    actual_software_STOP=release["actual_software_STOP"],
    protocol=support["protocol"],
    indexed_split=support["indexed_split"],
    total_calls=17,
    total_aggregate_nodes=17000000,
)
settings_ref = save("settings.json", settings)
started = datetime.now(timezone.utc).isoformat()
with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a+b") as lease:
    fcntl.flock(lease, fcntl.LOCK_SH | fcntl.LOCK_NB)
    try:
        for caller in release["current_callers"]:
            assert ref(Path(caller["path"])) == caller
        sys.path.insert(0, str(ROOT / "scripts/dev"))
        module = importlib.util.spec_from_file_location(
            "etc33_actual_normal_lifecycle_v3", ROOT / "scripts/dev/research-lifecycle.py"
        )
        lc = importlib.util.module_from_spec(module)
        sys.modules[module.name] = lc
        module.loader.exec_module(lc)
        native_cpus = lc.native_cpu_cores(run)
        operation_plan = lc.operation_cpu_plan(run)
        sequence_plan = lc.sequence_cpu_plan(settings_ref)
        assert operation_plan.record() == support["native_operation_plan"]
        assert sequence_plan.record() == support["parent_sequence_plan"]
        assert native_cpus == operation_plan.record()["allocation"]
        assert list(lc.operation_order(settings)) == [("run", 0)]
        charged = lc.charged_roots(run)
        assert set(charged) == {Path(p) for p in support["roots"]}
        lc.Limits(run).check()
        job = dict(
            issue="quoridor-4lc.324.33",
            goal_issue="quoridor-4lc.324",
            thread_id="01a11062-b120-73a1-8aa3-fe2cb922c7c0",
            cwd=str(ROOT),
            argv=[
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "sequence",
                "--intent",
                settings_ref["path"],
                "--sha256",
                settings_ref["sha256"],
            ],
            resource_contract=settings_ref["path"],
            end_at=None,
            notify_until=None,
            max_runtime_seconds=1200,
            control_interval_seconds=30,
            notify_interval_seconds=10,
            request_timeout_seconds=25,
            log_max_bytes=1048576,
        )
        job_plan = lc.configured_job_cpu_plan(job)
        assert job_plan is not None, "actual project interpreter/entry did not bind job CPU plan"
        assert job_plan.record() == sequence_plan.record()
        assert set(job_plan.record()["allocation"]) == set(
            support["declared_role_pool"]["allocation"]
        )
        job_ref = save("job-template.json", job)
        for caller in release["current_callers"]:
            assert ref(Path(caller["path"])) == caller
    finally:
        fcntl.flock(lease, fcntl.LOCK_UN)
ended = datetime.now(timezone.utc).isoformat()
result = save(
    "materialized.json",
    dict(
        status="ACTUAL_NORMAL_METADATA_BOUND_NOT_SUBMITTED",
        issue="quoridor-4lc.324.33",
        settings=settings_ref,
        job_template=job_ref,
        RUN=run_ref,
        experiment=ref(PHASE / "controls/experiment.json"),
        numerical=ref(PHASE / "controls/numerical.json"),
        config=ref(PHASE / "controls/config.json"),
        requests=ref(PHASE / "controls/requests.json"),
        source_release=release_ref,
        support=support_ref,
        operation_cpu_plan=operation_plan.record(),
        sequence_cpu_plan=sequence_plan.record(),
        configured_job_cpu_plan=job_plan.record(),
        native_cpu_cores=native_cpus,
        launcher_affinity=job_plan.record()["allocation"],
        charged_roots=[str(p) for p in charged],
        whole_B=support["whole_B"],
        image=release["image"],
        BUILD=release["genuine_BUILD"],
        current_callers=release["current_callers"],
        source_NB_SH=dict(started=started, ended=ended, acquired_released=True, remaining=[]),
        canonical_Plan="",
        approved_plan=None,
        calls=17,
        sessions=4,
        nodes_upper=17000000,
        native_parent_canonical_existing=True,
        native_output_root_absent=True,
        prior_preentry_failure="discovery17-materialize-helper-v1 descriptor refusal before job template/native; immutable controls/failure retained; sequence plan now consumes saved settings FileRef; binding-v2 imported wrong configured-job owner before native; binding-v3 uses actual lifecycle configured_job_cpu_plan",
        first_factory_checks="Current measurement_config/numerical_fields/numerical_check/experiment_phase_check/caller_source_refs/measurement_argv completed before original descriptor failure; same unchanged bound controls reused",
        admission_certificate=False,
        origin_end_at="Stamp once actualsubmit; runtime owns fresh physical/peer/RAM/pause/cancel/source/serializer checks",
        manual_model_input_library_ELF_payload_qualification=0,
        new_Search_native_tests_compiler_RNG=0,
    ),
)
print(json.dumps(result))
