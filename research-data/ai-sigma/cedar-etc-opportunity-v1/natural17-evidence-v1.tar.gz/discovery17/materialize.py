"""Bind original discovery17 through the current normal measurement and CPU owners."""

from copy import deepcopy
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
PHASE = Path(__file__).resolve().parent
SOURCE = ROOT / ".worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1"
ENTRY = (
    ROOT / ".artifacts/research-team/integration324/cedar-etc-opportunity-v1/discovery17-entry-v1"
)
CONTROLS = PHASE / "controls"
CONTROLS.mkdir(exist_ok=False)
NATIVE_PARENT = PHASE / "native"
NATIVE_PARENT.mkdir(exist_ok=False)
DATA = NATIVE_PARENT / "run-000"
assert PHASE.resolve(strict=True) == PHASE and NATIVE_PARENT.resolve(strict=True) == NATIVE_PARENT
assert PHASE.is_relative_to(ROOT) and not DATA.exists() and not DATA.is_symlink()
assert DATA.parent.resolve(strict=True) == NATIVE_PARENT


def ref(path):
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def document(r):
    p = Path(r["path"])
    assert ref(p) == r, p
    return json.loads(p.read_text())


def save(name, value):
    p = PHASE / name
    with p.open("x") as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write("\n")
    return ref(p)


release_ref = dict(
    path=str(ENTRY / "current-source-and-software-release.json"),
    sha256="9d20528e380691ee81b6e28481367d39cf1ba3f208a53038361e9f344e7a6f24",
    bytes=10565,
    mode="0644",
)
support_ref = dict(
    path=str(ENTRY / "support-v2/phase-support-discovery17-v2.json"),
    sha256="12e5f2bdb94eb20d5050fae12da15ad2360462e8ee7afa84233e0d1f23378029",
    bytes=12784,
    mode="0644",
)
release = document(release_ref)
support = document(support_ref)
prepared = document(support["prepared"])
config = document(prepared["config"])
requests = document(prepared["requests"])
exp_draft = document(prepared["Experiment"])["experiment"]
split = document(support["indexed_split"])
assert [r["root"] for r in requests] == support["root_indices"] == list(range(17))
assert len(requests) == 17 and len({r["session"] for r in requests}) == 4
assert all(
    r["depth"] == 5
    and r["node_cap"] == 1000000
    and r.get("time_limit_ms") is None
    and not r["warmup"]
    for r in requests
)
assert config["etc_opportunity"] == "before_first_v1" and config["search_threads"] == 1
assert config["tt_entries"] == 1048576 and config["zero_stock_safe_race"]
assert config["zero_stock_safe_race_method"] == "path_tail"
assert all(
    k not in config
    for k in ["time_reserve_ms", "probcut", "probcut_parameters", "probcut_samples", "aspiration"]
)
assert config["roots"] == [x["fullprefix_history_selector"] for x in split["discovery"]]
config_ref = save("controls/config.json", config)
requests_ref = save("controls/requests.json", requests)
lease_started = datetime.now(timezone.utc).isoformat()
with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a+b") as lease:
    fcntl.flock(lease, fcntl.LOCK_SH | fcntl.LOCK_NB)
    try:
        for caller in release["current_callers"]:
            assert ref(Path(caller["path"])) == caller
        sys.path.insert(0, str(ROOT / "scripts/dev"))
        module = importlib.util.spec_from_file_location(
            "etc33_actual_normal_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
        )
        lc = importlib.util.module_from_spec(module)
        sys.modules[module.name] = lc
        module.loader.exec_module(lc)
        manifest = lc.document(release["genuine_BUILD"])
        assert manifest["status"] == "PASS" and manifest["artifact"] == release["image"]
        experiment = dict(
            exp_draft,
            build_manifest=release["genuine_BUILD"],
            config=config_ref,
            schedule=requests_ref,
            numerical_qualification=None,
            canonical_plan_sha256="",
            planned_slots=17,
            batch=0,
            argv=[
                release["image"]["path"],
                "measure",
                "--experiment",
                "@EXPERIMENT@",
                "--experiment-sha256",
                "@EXPERIMENT_SHA256@",
            ],
        )
        lc.measurement_config(experiment)
        numerical = lc.numerical_fields(experiment, manifest)
        numerical.update(
            correspondence_only=True,
            inherited_same_body_scope="641ca structural correspondence only; same frozen Cedar35cbb/eb0, no new model/head/math/parity qualification",
            source_owner=release["current_callers"][0],
            actual_software_Build=release["genuine_BUILD"],
            new_model_head_Search_parity_calls=0,
        )
        numerical_ref = save("controls/numerical.json", numerical)
        experiment["numerical_qualification"] = numerical_ref
        lc.numerical_check(experiment, manifest)
        lc.experiment_phase_check(experiment)
        experiment_ref = save("controls/experiment.json", experiment)
        argv = [
            arg.replace("@EXPERIMENT@", experiment_ref["path"]).replace(
                "@EXPERIMENT_SHA256@", experiment_ref["sha256"]
            )
            for arg in experiment["argv"]
        ]
        tmp = PHASE / "unused-template-TMP"
        environment = dict(
            PATH=os.environ["PATH"],
            HOME="/home/vscode",
            LANG="C.UTF-8",
            CUDA_VISIBLE_DEVICES="",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
            RAYON_NUM_THREADS="1",
            PYTHONDONTWRITEBYTECODE="1",
            UV_NO_SYNC="1",
            UV_OFFLINE="1",
            TMPDIR=str(tmp),
        )
        run = dict(
            schema="quoridor.research.lifecycle-intent.v1",
            kind="run",
            owner=str(ROOT),
            cwd=str(ROOT),
            output=str(PHASE / "unused-template"),
            TMP=str(tmp),
            env=environment,
            limits=deepcopy(support["limits"]),
            support=support_ref,
            finalizers=[],
            approved_plan=None,
            experiment=experiment_ref,
            artifact=release["image"],
            argv=argv,
            data_root=str(DATA),
            data=[
                dict(name=n, path=str(DATA / f), limit_B=b)
                for n, f, b in [
                    ("settings", "settings.json", 1048576),
                    ("measurements", "measurements.jsonl", 33554432),
                    ("result", "result.json", 33554432),
                ]
            ],
            owned_outputs=[*support["roots"], str(tmp)],
            caller_sources=release["current_callers"],
            child_cpu_cores=support["native_operation_plan"]["commands"]["run"],
            command_timeout_seconds=900,
            pause_file=str(SOURCE / "CANCEL"),
        )
        assert lc.caller_source_refs(run, experiment) == release["current_callers"]
        assert lc.measurement_argv(run, experiment, argv) == argv
        native_cpus = lc.native_cpu_cores(run)
        operation_plan = lc.operation_cpu_plan(run)
        assert operation_plan.record() == support["native_operation_plan"]
        assert native_cpus == operation_plan.record()["allocation"]
        charged = lc.charged_roots(run)
        assert set(charged) == {Path(p) for p in support["roots"]}
        lc.Limits(run).check()
        run["intent_sha256"] = lc.canonical_sha(run)
        run_ref = save("controls/RUN-template.json", run)
        settings = dict(
            schema="quoridor.research.sequence-settings.v1",
            kind="sequence",
            owner=str(ROOT),
            cwd=str(ROOT),
            output=str(PHASE / "sequence"),
            runs=[run],
            limits=deepcopy(support["parent_sequence_limits"]),
            support=support_ref,
            command_timeout_seconds=1140,
            pause_file=str(SOURCE / "CANCEL"),
            caller_sources=release["current_callers"],
            source_release=release_ref,
            actual_software_STOP=release["actual_software_STOP"],
            protocol=support["protocol"],
            indexed_split=support["indexed_split"],
            total_calls=17,
            total_aggregate_nodes=17000000,
        )
        assert list(lc.operation_order(settings)) == [("run", 0)]
        sequence_plan = lc.sequence_cpu_plan(settings)
        assert sequence_plan.record() == support["parent_sequence_plan"]
        settings_ref = save("settings.json", settings)
        job = dict(
            issue="quoridor-4lc.324.33",
            goal_issue="quoridor-4lc.324",
            thread_id="01a11062-b120-73a1-8aa3-fe2cb922c7c0",
            cwd=str(ROOT),
            argv=[
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "sequence",
                "--intent",
                settings_ref["path"],
                "--sha256",
                settings_ref["sha256"],
            ],
            resource_contract=settings_ref["path"],
            end_at=None,
            notify_until=None,
            max_runtime_seconds=1200,
            control_interval_seconds=30,
            notify_interval_seconds=10,
            request_timeout_seconds=25,
            log_max_bytes=1048576,
        )
        job_module = importlib.util.spec_from_file_location(
            "etc33_actual_normal_job", ROOT / "scripts/dev/research-job.py"
        )
        job_owner = importlib.util.module_from_spec(job_module)
        sys.modules[job_module.name] = job_owner
        job_module.loader.exec_module(job_owner)
        job_plan = job_owner.configured_job_cpu_plan(job)
        assert job_plan.record() == sequence_plan.record()
        assert set(job_plan.record()["allocation"]) == set(
            support["declared_role_pool"]["allocation"]
        )
        job_ref = save("job-template.json", job)
        for caller in release["current_callers"]:
            assert ref(Path(caller["path"])) == caller
    finally:
        fcntl.flock(lease, fcntl.LOCK_UN)
lease_ended = datetime.now(timezone.utc).isoformat()
result_ref = save(
    "materialized.json",
    dict(
        status="ACTUAL_NORMAL_METADATA_BOUND_NOT_SUBMITTED",
        issue="quoridor-4lc.324.33",
        settings=settings_ref,
        job_template=job_ref,
        RUN=run_ref,
        experiment=experiment_ref,
        numerical=numerical_ref,
        config=config_ref,
        requests=requests_ref,
        source_release=release_ref,
        support=support_ref,
        operation_cpu_plan=operation_plan.record(),
        sequence_cpu_plan=sequence_plan.record(),
        configured_job_cpu_plan=job_plan.record(),
        native_cpu_cores=native_cpus,
        launcher_affinity=job_plan.record()["allocation"],
        charged_roots=[str(p) for p in charged],
        whole_B=support["whole_B"],
        image=release["image"],
        BUILD=release["genuine_BUILD"],
        current_callers=release["current_callers"],
        source_NB_SH=dict(
            started=lease_started, ended=lease_ended, acquired_released=True, remaining=[]
        ),
        canonical_Plan="",
        approved_plan=None,
        calls=17,
        sessions=4,
        nodes_upper=17000000,
        native_parent_canonical_existing=True,
        native_output_root_absent=True,
        admission_certificate=False,
        origin_end_at="Stamp once actualsubmit; runtime owns fresh physical/peer/RAM/pause/cancel/source/serializer checks",
        manual_model_input_library_ELF_payload_qualification=0,
        new_Search_native_tests_compiler_RNG=0,
    ),
)
print(json.dumps(result_ref))
