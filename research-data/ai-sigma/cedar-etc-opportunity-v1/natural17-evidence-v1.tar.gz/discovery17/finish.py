"""Publish finite saved result and normal own administration after all timing stopped."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

PHASE = Path(__file__).resolve().parent
SOURCE = Path(
    "/workspaces/quoridor/.worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1"
)
OUT = PHASE / "final-v1"
OUT.mkdir(exist_ok=False)
ACTOR = "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def save(name, value):
    p = OUT / name
    p.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    return ref(p)


records = []


def beads(args):
    p = subprocess.run(
        ["bash", "scripts/dev/beads.sh", *args],
        env=dict(os.environ, BEADS_ACTOR=ACTOR),
        capture_output=True,
        text=True,
        timeout=60,
    )
    records.append(dict(args=args, returncode=p.returncode, stdout=p.stdout, stderr=p.stderr))
    assert p.returncode == 0
    return p.stdout


summary = json.loads((PHASE / "analysis-v1/summary.json").read_text())
assert summary["eligible"] is False and summary["witnesses"] == 1
minimum = save(
    "minimum.json",
    dict(
        issue="quoridor-4lc.324.33",
        decision=summary["decision"],
        candidate=None,
        normal_manifest_data="PASS",
        D5_DepthComplete=17,
        UNKNOWN=0,
        calls=17,
        sessions=4,
        nodes=summary["nodes"],
        selected_parents=130,
        child_lookups=12867,
        occupied_slots=4094,
        witnessed_true_TT_cuts=1,
        distinct_cut_roots=[16],
        required_cuts=2,
        required_roots=2,
        confirmation72="UNISSUED",
        games="UNISSUED",
        original_native_result=summary["result"],
        summary=ref(PHASE / "analysis-v1/summary.json"),
        witness=ref(PHASE / "analysis-v1/true-cut-witnesses.json"),
        report=ref(PHASE / "analysis-v1/report-ja.md"),
        actual_whole_STOP=ref(PHASE / "collection-v1/native-normal-source-STOP.json"),
        ended_holding=ref(PHASE / "collection-v1/ended-holding.json"),
        interpretation="One natural strict Upper cut establishes finite possibility; insufficient preregistered eligibility, no new candidate/performance/games. No impossibility/strength/default claim.",
        outer_seconds_once=23.97606525500305,
        nested_added=0,
        fullfees="UNKNOWN",
    ),
)
beads(["ready", "--json"])
issue = json.loads(beads(["show", "quoridor-4lc.324.33", "--json"]))[0]
assert issue["assignee"] == ACTOR and issue["status"] == "in_progress"
beads(
    [
        "update",
        "quoridor-4lc.324.33",
        "--append-notes",
        "Original natural discovery17 job2de83f6d collected ONCE; normalmanifest/dataPASS/17D5DepthComplete/4chronologicalsessions/3,185,895nodes/2,786,653evals/parentrestore17/errorsmissingcancel0. Whole native+normal/source STOP0aeb96d7 and collectorreturn sent Root BEFORE analysis. Actual normal terminal21root inodeunion796385280B reused once/no rewalk/recharge/refund/lending. 130 selected parents/136slots,12867lookups/4094occupied, trueTTcut1 onroot16 only (Upper D1 atparentD2ply1 child31/normalrank0), qualifiednoncut0/terminalproof0. Strictsign/depth/context/legal/finite witness saved, no cutoffreturns/TTwrites/historyupdates/extraevals. Overlap mismatchcounts board215/context593/depth4009/excludedBound3977/legal191, not disjoint causes. Fixed >=2witnesses on>=2roots FAILED -> FINITE_OPPORTUNITY_INSUFFICIENT_STOP_NO_CANDIDATE; candidateNULL/confirmation72/gamesUNISSUED, no newSearch/RNG/CI/refill. Summarya8ce0321/report9cb40dda/witness00c35014 at .worktree/assets/perf/cedar-etc-opportunity-v1/discovery17-v1/analysis-v1; final minimum links exact. Search2.943525199s descriptive shadow-inclusive, outer23.97606525500305s ONCE/nested0/fullfeesUNKNOWN; no speed/strength/ETCimpossibility/default claim. Software8Search<=400kupper actualnodesNOT_EXTRACTED distinct, old31CLOSED208/oldMPC/failuresNULLcosts immutable. All source/analysis helpers returned, no Mainreader or newnative pending. Own33 remains sameowner in_progress for Root finite acceptance/disposition. GroupB12.6.2 separate six-only preservation can continue serially now timingSTOP; no otherstatus touched.",
    ]
)
beads(["backup", "sync"])
issue = json.loads(beads(["show", "quoridor-4lc.324.33", "--json"]))[0]
assert issue["assignee"] == ACTOR and issue["status"] == "in_progress"
admin = save(
    "admin.json",
    dict(
        records=records, status=issue["status"], assignee=issue["assignee"], other_issue_mutations=0
    ),
)
stop = save(
    "returned-analysis-STOP.json",
    dict(
        at=datetime.now(timezone.utc).isoformat(),
        analysis_return=ref(SOURCE / "discovery17-analysis-v1/return.json"),
        analysis_controller=ref(SOURCE / "discovery17-analysis-v1/controller.json"),
        native_whole_STOP=ref(PHASE / "collection-v1/native-normal-source-STOP.json"),
        TMP=[],
        source_leases=[],
        Main_reader=False,
        final_admin_tail="This bounded finish helper returns; exact return path supplied separately",
        finalizer_return=str(SOURCE / "discovery17-finish-v1/return.json"),
        no_future_quiet=True,
    ),
)
print(json.dumps(dict(minimum=minimum, admin=admin, STOP=stop)))
