"""Record actual normal binding and back up own33 before its native clock."""

import hashlib
import json
import os
from pathlib import Path
import subprocess

PHASE = Path(__file__).resolve().parent
OUT = PHASE / "preclock-admin-v1"
OUT.mkdir(exist_ok=False)
ACTOR = "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0"
records = []


def beads(args):
    p = subprocess.run(
        ["bash", "scripts/dev/beads.sh", *args],
        env=dict(os.environ, BEADS_ACTOR=ACTOR),
        capture_output=True,
        text=True,
        timeout=60,
    )
    records.append(dict(args=args, exit_code=p.returncode, stdout=p.stdout, stderr=p.stderr))
    assert p.returncode == 0, records[-1]
    return p.stdout


x = json.loads(beads(["show", "quoridor-4lc.324.33", "--json"]))[0]
assert x["status"] == "in_progress" and x["assignee"] == ACTOR
beads(
    [
        "update",
        "quoridor-4lc.324.33",
        "--append-notes",
        (
            "Original discovery17 actual normal bound in .worktree/assets/perf/cedar-etc-opportunity-v1/"
            "discovery17-v1/binding-v3/materialized.json8d2bf173/8185, supportv2ONLY12e5f2bd/release9d20528e/"
            "genuineNEWBUILDbfe83000/image87ea4af1/currentLC61715131+job13a2/cyclee88f/snapshoted08. "
            "Current measurement_config/numerical_fields+check/experiment_phase/caller_source_refs/argv "
            "bound under NB SH/released; no manual model/input/library/ELF qualifier/read/copy. Current "
            "operation_cpu_plan native[0,12]/CPU2, sequence_cpu_plan+configured_job_cpu_plan[0,12,18]/CPU3 "
            "actualderived/verified against Rootsupport; no oldresolver/handcopiedCPUselector. RUNguardian0/"
            "worker12/outersequenceguardian18/F4GiB1.5controller+2.5native/host4/G0/threads1. One2240MiB "
            "whole exact21rootunion/free1127936000B/no doublegrant/refund. Current normalLimits fullroots/"
            "RAM/free checked; runtime owns actualfreshphysicalSMT/peers/source/env/pausecancel/origin/"
            "serializer/cleanup, no admissioncertificate. Canonical native DATA PARENT exists, run000 "
            "outputroot freshABSENT; empty measurementPlan/approvedNone. D5/timeNone/reserveABSENT/17indices"
            "0..16/fourwholechronologicalsessions/fullpredecessors/1M each17M, TT1048576/CurrentCedarControl/"
            "baselineLMR/PVS/safeRaceONpath_tail/MPCparams+samplerABSENT/aspOFF. CandidateNULL/confirmation72/"
            "gamesUNISSUED; software8Search<=400kupper actualNOT_EXTRACTED separate, newhard512/512M only. "
            "Two causal pre-native metadata errors retained: sequence_cpu_plan needs FileRef not settings "
            "dict, configured_job_cpu_plan actualowner is LC not jobmodule; v1/v2 guards NULLreturn vs disk "
            "actualcleanup facts preserved, science/native0 and no reset/refill. One outsideCycle explicit"
            "derivedaffinity0,12,18 directPopen next; end_at/origin freshONCE/parent1200/command1140/RUN900/"
            "cleanup60. Originalcompletion owns onceALL17normalcollection+immediateactualSTOP/holdingRoot "
            "beforelonganalysis; no poll/startobserver/duplicate. GroupB12.6.2 ownclaim/firstreadSTOP delivered, "
            "no heavyarchive or livehelper; its bounded firstintake arena-evaluation12000entry refusal "
            "preserved/sourcecleanup actual, other5 metadata work remains independent, not a 33gate. "
            "All oldsource/software failures/NULL/masks/costUNKNOWN/pauses/seals/defaults/models/foreign/"
            "old31CLOSED208 untouched; sameown33 in_progress. No heavyDB during upcoming nativeclock."
        ),
    ]
)
beads(["backup", "sync"])
x = json.loads(beads(["show", "quoridor-4lc.324.33", "--json"]))[0]
assert x["status"] == "in_progress" and x["assignee"] == ACTOR
p = OUT / "admin.json"
p.write_text(
    json.dumps(
        dict(records=records, sameowner=ACTOR, status=x["status"], other_status_mutations=0),
        indent=2,
    )
    + "\n"
)
b = p.read_bytes()
print(
    json.dumps(dict(path=str(p), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b), mode="0644"))
)
