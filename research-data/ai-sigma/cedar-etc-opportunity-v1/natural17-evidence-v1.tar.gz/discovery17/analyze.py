"""Descriptive saved-only analysis of the frozen natural opportunity sample."""

from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import struct

PHASE = Path(__file__).resolve().parent
OUT = PHASE / "analysis-v1"
OUT.mkdir(exist_ok=False)


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def save(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    return ref(path)


def fp(bits):
    return struct.unpack("!f", struct.pack("!I", bits))[0]


def stock(value):
    return "0" if value == 0 else "1..4" if value <= 4 else "5..10" if value <= 10 else "11..20"


result_path = PHASE / "native/run-000/result.json"
result = json.loads(result_path.read_text())
collection = json.loads((PHASE / "collection-v1/collection.json").read_text())
fields = [
    "lookups",
    "slot_absent",
    "board_mismatch",
    "context_mismatch",
    "depth_mismatch",
    "excluded_bound",
    "illegal_or_missing_best",
    "nonfinite_value",
    "qualified_noncut",
    "true_tt_cuts",
    "terminal_proofs",
    "terminal_cuts",
]
total = Counter()
strata = defaultdict(Counter)
stock_bins = defaultdict(Counter)
roots = []
parents = []
witnesses = []
occupied_witness_patterns = Counter()
capacity = Counter()
infinite = Counter()
for index, row in enumerate(result["measurements"]):
    m = row["measurement"]
    report = m["work"]["etc_opportunity"]
    assert m["returned"] == "Ok" and m["parent_unchanged"]
    assert m["action"] in m["root_legal_action_ids"] and m["PV"][0] == m["action"]
    assert m["stop"] == "DepthComplete" and m["completed_depth"] == 5
    assert report["shadow_only"] and report["protocol"] == "before-first-all-legal-v1"
    assert all(
        report[k] == 0
        for k in ["TT_writes", "history_updates", "extra_evaluations", "cutoff_returns"]
    )
    assert report["child_lookups"] == report["child_transitions"]
    assert sum(p["lookups"] for p in report["parents"]) == report["child_lookups"]
    assert (
        report["actual_namespace"]["evaluator"]
        == "eb0fbc9357252e916b1c6314bee6f6c76d975828c15cc439cceb9766309fb5b9"
    )
    counts = Counter()
    for slot, p in enumerate(report["parents"]):
        capacity[slot] += report["capacity_unready"][slot]
        infinite[slot] += report["infinite_window"][slot]
        counts.update({k: p[k] for k in fields})
        key = f"D{p['depth']}/ply{p['ply']}/slot{slot}"
        strata[key].update({k: p[k] for k in fields})
        strata[key]["selected"] += int(p["selected"])
        strata[key]["complete"] += int(p["complete"])
        stock_bins[stock(p["stock"])].update({k: p[k] for k in fields})
        stock_bins[stock(p["stock"])]["selected"] += int(p["selected"])
        parents.append(dict(root=index, session=row["request"]["session"], **p))
        first = p["witnesses"][0]
        if first:
            rejected = [
                k
                for k in [
                    "board_match",
                    "context_match",
                    "depth_match",
                    "finite_value",
                    "legal_best",
                    "numeric_bound",
                ]
                if not first[k]
            ]
            occupied_witness_patterns["+".join(rejected) or "all_entry_predicates_pass"] += 1
        cut = p["witnesses"][1]
        if p["true_tt_cuts"]:
            assert cut and cut["true_tt_cut"]
        if cut:
            assert cut["stored_bound"] in [0, 2] and cut["stored_depth"] == p["depth"] - 1
            assert all(
                cut[k]
                for k in [
                    "board_match",
                    "context_match",
                    "depth_match",
                    "finite_value",
                    "legal_best",
                    "numeric_bound",
                    "satisfies_window",
                ]
            )
            value, beta = fp(cut["stored_value_bits"]), fp(p["beta_bits"])
            assert value <= -beta
            witnesses.append(
                dict(
                    root=index,
                    request=row["request"],
                    root_descriptor=row["root"],
                    parent=p,
                    child_value=value,
                    parent_beta=beta,
                    child_upper_le_negative_beta=True,
                    source_result=ref(result_path),
                    qualification="Native live TT shadow; read-only witness, not executed cutoff",
                )
            )
    total.update(counts)
    roots.append(
        dict(
            index=index,
            session=row["request"]["session"],
            root_stock=m["root_walls_remaining"],
            stop=m["stop"],
            depth=m["completed_depth"],
            action=m["action"],
            PV=m["PV"],
            value_bits=m["value_bits"],
            nodes=m["work"]["nodes"],
            evaluations=m["work"]["evaluations"],
            Search_seconds=m["Search_call_seconds"],
            CPU_seconds=m["process_CPU_seconds"],
            parent_restored=m["parent_unchanged"],
            selected_parents=sum(int(p["selected"]) for p in report["parents"]),
            **counts,
        )
    )
cut_roots = sorted({w["root"] for w in witnesses})
eligible = len(witnesses) >= 2 and len(cut_roots) >= 2
assert not eligible
with (OUT / "roots.csv").open("x") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(roots[0]))
    writer.writeheader()
    writer.writerows(roots)
summary = save(
    "summary.json",
    dict(
        issue="quoridor-4lc.324.33",
        result=ref(result_path),
        normal_collection=ref(PHASE / "collection-v1/collection.json"),
        calls=17,
        sessions=4,
        requested_D5_DepthComplete=17,
        requested_unknown=0,
        errors_missing_cancel=0,
        nodes=sum(r["nodes"] for r in roots),
        evaluations=sum(r["evaluations"] for r in roots),
        selected_parents=sum(r["selected_parents"] for r in roots),
        parent_strata_slots=136,
        totals=dict(total),
        occupied_slots=total["lookups"] - total["slot_absent"],
        strata=dict(strata),
        stock_bins=dict(stock_bins),
        capacity_unready=dict(capacity),
        infinite_window=dict(infinite),
        first_occupied_witness_rejection_patterns=dict(occupied_witness_patterns),
        rejection_denominator="Each entry condition may overlap; not disjoint cause or unique-state frequency",
        witnesses=len(witnesses),
        true_cut_roots=cut_roots,
        eligibility_required="At least2 witnessed trueTTcuts on at least2 discoveryroots",
        eligible=eligible,
        decision="FINITE_OPPORTUNITY_INSUFFICIENT_STOP_NO_CANDIDATE",
        candidate=None,
        confirmation72="UNISSUED_NOT_ENTERED",
        games="UNISSUED_NOT_ENTERED",
        no_new_native_Search_RNG_or_CI=True,
        costs=dict(
            Search_seconds=sum(r["Search_seconds"] for r in roots),
            CPU_seconds=sum(r["CPU_seconds"] for r in roots),
            setup_seconds=result["setup_seconds"],
            target_drop_seconds=result["target_drop_seconds"],
            driver_whole_seconds=result["whole_driver_seconds"],
            outer_seconds_once=collection["costs"]["outer_seconds_once"],
            nested_added=0,
            fullfees="UNKNOWN",
        ),
        limits="Result-aware strata bounded first parents, correlated sessions, no representative rate/no ETC impossibility/performance/strength/default claim; software8Search separate actualnodesNOT_EXTRACTED <=400kupper",
    ),
)
save("parents.json", parents)
save("true-cut-witnesses.json", witnesses)
save("root-rows.json", roots)
text = "# ETC33 有限機会調査\n\n"
text += "通常manifest/data PASS、元の17 callsは全てD5 DepthComplete、4つの時系列sessionの先行局面を保持した。エラー・欠損・cancelは0。全体native/通常collection STOPは分析前にRootへ配送済み。\n\n"
text += f"合法子のbefore-first shadowで{total['lookups']:,}回のTT参照、occupied slotは{total['lookups'] - total['slot_absent']:,}。正しいTT cutは1件・root16の1局面だけだった。固定条件の2件以上・2root以上を満たさず、FINITE_OPPORTUNITY_INSUFFICIENT、candidate NULL、確認72とgamesは未発行のまま停止する。\n\n"
text += "|保存条件|件数|\n|---|---:|\n"
for k in fields:
    text += f"|{k}|{total[k]}|\n"
text += "\n不一致条件は重複する。slot_absentは参照全体の分母、各entry不一致はoccupied slot条件であり、合計して原因割合にしない。qualified_noncut/terminal_proofs/terminal_cutsは全て0。有限値違反0。first occupiedの少数witnessと集計全体を混同しない。\n\n"
w = witnesses[0]
p = w["parent"]
text += f"唯一のtrue cut: root16、parent path={p['path']}、residualD={p['depth']}、ply={p['ply']}、両者stock合計={p['stock']}。子31のUpper、storedD={p['witnesses'][1]['stored_depth']}がD−1に一致し、child上界{w['child_value']} <= −beta ({-w['parent_beta']})。board/context/有限値/legal best/namespaceが一致。これは本来の通常Searchで生成されたTTの保存観測であり、shadowは実cutを返していない。normal_rank0のTT先頭情報なので、通常先頭展開を越えた追加便益はこの1件から示せない。\n\n"
text += f"実ノード{sum(r['nodes'] for r in roots):,}、評価{sum(r['evaluations'] for r in roots):,}。Search合計{sum(r['Search_seconds'] for r in roots):.9f}sはshadow仕事込みで、対照比較のspeedupではない。outer23.97606525500305sを一度記録し、nested費用を加算しない。software8Search <=400k上限/実nodes未抽出は自然17と分離し、過去31の208も混ぜない。\n\n"
text += "全shadowのTT writes/history updates/extra evaluations/cutoff returnsは0、子遷移数とlookups一致、親復元17/17。root0..16の選択・strata・同一sessionは有限で相関があり、一般的な機会率やETC不可能性、強さ、同等性、default採用を示さない。浅い前回反復entryの深さ不一致、excluded Bound、context不一致が多いが、strict horizonや履歴条件を緩める根拠にはしない。追加採取・warmup・refill・比較・games・CIは行っていない。\n\n"
text += f"保存根拠: summary `{summary['sha256']}`、`roots.csv`、`parents.json`、`true-cut-witnesses.json`。元のRAW/FAILED/NULL/費UNKNOWN、全pauses/seals/models/defaultsを保持。\n"
(OUT / "report-ja.md").write_text(text)
print(
    json.dumps(
        dict(
            summary=summary,
            report=ref(OUT / "report-ja.md"),
            witnesses=ref(OUT / "true-cut-witnesses.json"),
        )
    )
)
