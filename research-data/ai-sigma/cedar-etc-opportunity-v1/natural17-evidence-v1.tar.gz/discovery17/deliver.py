"""Deliver fixed finite result after actual saved-analysis/admin helper returns."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

PHASE = Path(__file__).resolve().parent
SOURCE = Path(
    "/workspaces/quoridor/.worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1"
)
OUT = PHASE / "final-v1"


def ref(p):
    data = p.read_bytes()
    return dict(
        path=str(p),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{p.stat().st_mode & 0o777:04o}",
    )


boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
records = []
for phase in ["discovery17-analysis-v1", "discovery17-finish-v1"]:
    directory = SOURCE / phase
    returned = json.loads((directory / "return.json").read_text())
    assert returned["exit_code"] == 0 and returned["direct_child_reaped"]
    assert (
        returned["handle_closes_complete"]
        and returned["cleanup_complete"]
        and not returned["remaining"]
    )
    assert not (directory / "TMP").exists()
    identities = [
        returned["child"],
        json.loads((directory / "controller.json").read_text())["identity"],
    ]
    for identity in identities:
        try:
            stat = Path(f"/proc/{identity['pid']}/stat").read_text()
            same = boot == identity["boot_id"] and stat.rsplit(")", 1)[1].split()[19] == str(
                identity["start_ticks"]
            )
        except FileNotFoundError:
            same = False
        assert not same
    records.append(
        dict(
            phase=phase,
            returned=ref(directory / "return.json"),
            identities_absent_different=identities,
        )
    )
stop = OUT / "actual-returned-finalizer-STOP.json"
stop.write_text(
    json.dumps(
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            records=records,
            directwait_reap_handles=True,
            TMP=[],
            leases=[],
            Main_reader=False,
            native_STOP=ref(PHASE / "collection-v1/native-normal-source-STOP.json"),
            future_quiet=False,
        ),
        indent=2,
    )
    + "\n"
)
body = "SAME33 fixed original natural17 RESULT: FINITE_OPPORTUNITY_INSUFFICIENT_STOP_NO_CANDIDATE. Normalmanifest/dataPASS, all17 D5DepthComplete/4sessions/3,185,895nodes. 130 selected parents/136slots,12867lookups/4094occupied. One natural strict Upper TTcut witness atroot16/parentD2ply1/pathsaved/child31/storedD1/contextlegalfinitecorrect; normalrank0. 1cut/1root < frozen2cuts/2roots. This establishes one natural correctbefore-first possibility but no practicalcandidate or benefit beyond ordinaryfirst child, no horizon/context relaxation. CandidateNULL, confirmation72 and gamesUNISSUED; no newSearch/RNG/CI/refill. Terminalproofs0/qualifiednoncut0. Overlapping depth4009/excludedBound3977/context593/board215/legal191 facts, not disjoint causes/representative rates. Full source/normal/analysis/admin helpers actually returned/reaped/handles/TMPleases[], ownnote+backupPASS/sameownerin_progress. Whole STOP/endedholding already sent beforeanalysis; no Mainreader/native/heavyanalysis left. Outer23.97606525500305s ONCE/nested0, Search2.943525199s descriptive shadow-inclusive/no speedclaim, software8Search<=400kupper actualnodesNOT_EXTRACTED separate. Old31/oldMPC/failuresNULLfeesUNKNOWN/pauses/seals/defaults/models/foreign/50GB untouched. Root sole importantinterpretation/canonicaldisposition; author no dispatch/selfclear/source retirement yet. GroupB six-only finite preservation remains independent and may proceed serially after this actualSTOP, no science rights.\n"
for p in [
    OUT / "minimum.json",
    PHASE / "analysis-v1/report-ja.md",
    PHASE / "analysis-v1/summary.json",
    PHASE / "analysis-v1/true-cut-witnesses.json",
    stop,
]:
    body += json.dumps(ref(p)) + "\n"
body += (
    "This bounded light delivery tail return: "
    + str(SOURCE / "discovery17-result-delivery-v1/return.json")
    + "\n"
)
handoff = OUT / "result-handoff.txt"
handoff.write_text(body)
sent = subprocess.run(
    [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--body-file",
        str(handoff),
    ],
    capture_output=True,
    text=True,
    timeout=60,
)
(OUT / "result-delivery.json").write_text(
    json.dumps(dict(returncode=sent.returncode, stdout=sent.stdout, stderr=sent.stderr), indent=2)
    + "\n"
)
assert sent.returncode == 0
print(json.dumps(dict(STOP=ref(stop), delivery=sent.stdout)))
