# ETC33 有限機会調査

通常manifest/data PASS、元の17 callsは全てD5 DepthComplete、4つの時系列sessionの先行局面を保持した。エラー・欠損・cancelは0。全体native/通常collection STOPは分析前にRootへ配送済み。

合法子のbefore-first shadowで12,867回のTT参照、occupied slotは4,094。正しいTT cutは1件・root16の1局面だけだった。固定条件の2件以上・2root以上を満たさず、FINITE_OPPORTUNITY_INSUFFICIENT、candidate NULL、確認72とgamesは未発行のまま停止する。

|保存条件|件数|
|---|---:|
|lookups|12867|
|slot_absent|8773|
|board_mismatch|215|
|context_mismatch|593|
|depth_mismatch|4009|
|excluded_bound|3977|
|illegal_or_missing_best|191|
|nonfinite_value|0|
|qualified_noncut|0|
|true_tt_cuts|1|
|terminal_proofs|0|
|terminal_cuts|0|

不一致条件は重複する。slot_absentは参照全体の分母、各entry不一致はoccupied slot条件であり、合計して原因割合にしない。qualified_noncut/terminal_proofs/terminal_cutsは全て0。有限値違反0。first occupiedの少数witnessと集計全体を混同しない。

唯一のtrue cut: root16、parent path=[113]、residualD=2、ply=1、両者stock合計=1。子31のUpper、storedD=1がD−1に一致し、child上界-0.9747174382209778 <= −beta (-0.7199136018753052)。board/context/有限値/legal best/namespaceが一致。これは本来の通常Searchで生成されたTTの保存観測であり、shadowは実cutを返していない。normal_rank0のTT先頭情報なので、通常先頭展開を越えた追加便益はこの1件から示せない。

実ノード3,185,895、評価2,786,653。Search合計2.943525199sはshadow仕事込みで、対照比較のspeedupではない。outer23.97606525500305sを一度記録し、nested費用を加算しない。software8Search <=400k上限/実nodes未抽出は自然17と分離し、過去31の208も混ぜない。

全shadowのTT writes/history updates/extra evaluations/cutoff returnsは0、子遷移数とlookups一致、親復元17/17。root0..16の選択・strata・同一sessionは有限で相関があり、一般的な機会率やETC不可能性、強さ、同等性、default採用を示さない。浅い前回反復entryの深さ不一致、excluded Bound、context不一致が多いが、strict horizonや履歴条件を緩める根拠にはしない。追加採取・warmup・refill・比較・games・CIは行っていない。

保存根拠: summary `a8ce03211b0e391d1cb742fff9dee9643bd8b65c5f1763cf3015461482f1d5e5`、`roots.csv`、`parents.json`、`true-cut-witnesses.json`。元のRAW/FAILED/NULL/費UNKNOWN、全pauses/seals/models/defaultsを保持。
