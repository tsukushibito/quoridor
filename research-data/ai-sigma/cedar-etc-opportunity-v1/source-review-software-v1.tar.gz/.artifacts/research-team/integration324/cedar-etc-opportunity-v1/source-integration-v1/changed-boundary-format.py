def etc_opportunity_setting(config, requests):
    if "etc_opportunity" not in config:
        return None
    require(
        type(config["etc_opportunity"]) is str and config["etc_opportunity"] == "before_first_v1",
        "typed ETC opportunity setting",
    )
    require(
        config.get("profile") == "control"
        and type(config.get("search_threads")) is int
        and config["search_threads"] == 1
        and config.get("use_tt") is True
        and config.get("use_pvs") is True
        and config.get("lmr_method", "depth_rank") == "depth_rank"
        and config.get("probcut") is None
        and config.get("probcut_samples", 0) == 0
        and config.get("zero_stock_approx_min_root_walls") is None
        and all(
            config.get(k) is None
            for k in (
                "neighbour_opportunity",
                "root_ordering_quality",
                "history_provenance",
                "time_reserve_ms",
            )
        ),
        "ETC shadow exclusive plain N1 Control/TT/PVS, MPC/observers/approximation OFF",
    )
    require(
        all(
            r.get("time_limit_ms") is None
            and type(r.get("depth")) is int
            and 1 <= r["depth"] <= 5
            and type(r.get("node_cap")) is int
            and 0 < r["node_cap"] <= 1000000
            and all(
                not r.get(k, False)
                for k in ("diagnostic", "observe_lmr", "observe_completed_depths", "warmup")
            )
            for r in requests
        ),
        "ETC shadow bounded fixed-depth requests",
    )
    return config["etc_opportunity"]


def etc_opportunity_correspondence(config, measured):
    work = measured.get("work", {})
    report = work.get("etc_opportunity") if isinstance(work, dict) else None
    if "etc_opportunity" not in config:
        require(
            "etc_opportunity_requested" not in measured and report is None,
            "no hidden ETC shadow on ordinary invocation",
        )
        return None
    require(
        measured.get("etc_opportunity_requested") == config["etc_opportunity"],
        "actual ETC shadow request correspondence",
    )
    if measured.get("returned") != "Ok":
        require(report is None, "unreturned ETC shadow cannot invent complete data")
        return None
    require(
        isinstance(report, dict)
        and report.get("protocol") == "before-first-all-legal-v1"
        and report.get("shadow_only") is True
        and report.get("parent_limit") == 8
        and report.get("child_limit") == 1672,
        "actual bounded ETC shadow report",
    )
    for key in ("cutoff_returns", "TT_writes", "history_updates", "extra_evaluations"):
        require(
            type(report.get(key)) is int and report[key] == 0, "ETC shadow immutable work " + key
        )
    require(
        isinstance(measured.get("actual_selectivity"), str) and measured["actual_selectivity"],
        "actual ordinary namespace retained by shadow",
    )
    namespace = report.get("actual_namespace")
    require(
        isinstance(namespace, dict)
        and set(namespace) == {"evaluator", "rules", "selectivity"}
        and all(type(value) is str and value for value in namespace.values())
        and namespace["selectivity"] == measured["actual_selectivity"]
        and namespace["rules"] == config["namespace"]["rules"],
        "actual single-owner TT namespace correspondence",
    )
    parents = report.get("parents")
    require(isinstance(parents, list) and len(parents) == 8, "eight fixed ETC parent strata")
    capacity = report.get("capacity_unready")
    require(
        isinstance(capacity, list)
        and len(capacity) == 8
        and all(type(n) is int and n >= 0 for n in capacity),
        "ETC unready retained-slot counts",
    )
    windows = report.get("infinite_window")
    require(
        isinstance(windows, list)
        and len(windows) == 8
        and all(type(n) is int and n >= 0 for n in windows),
        "ETC preselection infinite-window counts",
    )
    strata = [(3, 0), (4, 0), (2, 1), (3, 1), (4, 1), (2, 2), (3, 2), (2, 3)]
    counts = (
        "attempted_children",
        "legal_count",
        "children",
        "terminal_proofs",
        "terminal_cuts",
        "lookups",
        "slot_absent",
        "board_mismatch",
        "context_mismatch",
        "depth_mismatch",
        "excluded_bound",
        "nonfinite_value",
        "illegal_or_missing_best",
        "qualified_noncut",
        "true_tt_cuts",
    )
    for index, parent in enumerate(parents):
        require(
            isinstance(parent, dict)
            and type(parent.get("selected")) is bool
            and type(parent.get("complete")) is bool
            and parent.get("slot") == index
            and all(type(parent.get(k)) is int and parent[k] >= 0 for k in counts),
            "typed ETC parent counts",
        )
        require(
            parent["children"] <= parent["attempted_children"] <= parent["legal_count"] <= 209,
            "all-legal ETC parent bounds",
        )
        require(
            parent["terminal_proofs"] + parent["lookups"] == parent["children"]
            and parent["terminal_cuts"] <= parent["terminal_proofs"]
            and parent["slot_absent"] <= parent["lookups"]
            and parent["qualified_noncut"] + parent["true_tt_cuts"]
            <= parent["lookups"] - parent["slot_absent"],
            "ETC count identities",
        )
        require(
            all(
                parent[k] <= parent["lookups"] - parent["slot_absent"]
                for k in (
                    "board_mismatch",
                    "context_mismatch",
                    "depth_mismatch",
                    "excluded_bound",
                    "nonfinite_value",
                    "illegal_or_missing_best",
                )
            ),
            "overlapping ETC rejection denominators",
        )
        if parent["selected"]:
            require(
                (parent.get("depth"), parent.get("ply")) == strata[index]
                and type(parent.get("stock")) is int
                and 0 <= parent["stock"] <= 20,
                "predeclared ETC parent depth/ply and actual both-stock sum",
            )
            if parent["complete"]:
                require(
                    parent["children"] == parent["legal_count"],
                    "whole all-child ETC parent observation",
                )
        else:
            require(
                not parent["complete"] and all(parent[k] == 0 for k in counts),
                "unobserved ETC parent stays absent",
            )
        require(
            isinstance(parent.get("witnesses"), list) and len(parent["witnesses"]) == 2,
            "bounded ETC witnesses",
        )
    for key in ("child_transitions", "child_lookups", "parent_returns"):
        require(
            type(report.get(key)) is int and 0 <= report[key] <= 1672,
            "typed actual ETC total " + key,
        )
    require(
        sum(p["children"] for p in parents)
        <= report["child_transitions"]
        <= sum(p["attempted_children"] for p in parents)
        and sum(p["lookups"] for p in parents)
        <= report["child_lookups"]
        <= report["child_transitions"]
        and report["parent_returns"] == sum(p["complete"] for p in parents),
        "ETC completed/partial transition correspondence",
    )
    return report


def measurement_config(experiment):
    """Functional shapes only; settings and input order belong to the run."""
    config = document(experiment["config"])
    requests = document(experiment["schedule"])
    require(
        isinstance(config, dict)
        and set(config)
        <= {
            "inference",
            "probcut",
            "probcut_samples",
            "etc_opportunity",
            "search_threads",
            "smp_sharing_provenance",
            "search_cpu_cores",
            "management_cpu_core",
            "native_memory_bytes",
            "time_reserve_ms",
            "roots",
            "profile",
            "tt_entries",
            "use_tt",
            "use_pvs",
            "namespace",
            "output_bytes",
            "record_bytes",
            "seed",
            "lmr",
            "lmr_method",
            "lmr_parameters",
            "neighbour_opportunity",
            "root_ordering_quality",
            "history_provenance",
            "zero_stock_approx_min_root_walls",
            "zero_stock_approx_method",
            "zero_stock_safe_race",
            "zero_stock_safe_race_method",
        }
        and {
            "roots",
            "profile",
            "tt_entries",
            "use_tt",
            "use_pvs",
            "namespace",
            "output_bytes",
            "record_bytes",
        }
        <= set(config),
        "measurement settings shape",
    )
    etc_opportunity_setting(config, requests)
    if "probcut" in config or "probcut_samples" in config:
        p = config.get("probcut")
        samples = config.get("probcut_samples", 0)
        require(type(samples) is int and 0 <= samples <= 8, "ProbCut first sample bound")
        require(
            config.get("search_threads", 1) == 1
            and config["profile"] == "control"
            and config["use_pvs"]
            and config["use_tt"]
            and config.get("zero_stock_approx_min_root_walls") is None
            and "neighbour_opportunity" not in config
            and "root_ordering_quality" not in config
            and "history_provenance" not in config,
            "ProbCut is N1 Control/PVS with no other observer or approximation",
        )
        require(
            not (p is not None or samples != 0)
            or all(not r.get("observe_lmr", False) for r in requests),
            "ProbCut or sampling cannot enter the OFF-only LMR observation path",
        )
        if "probcut" in config:
            require(
                isinstance(p, dict)
                and set(p)
                == {
                    "shallow_depth",
                    "deep_depth",
                    "slope",
                    "intercept",
                    "margin",
                    "nonterminal_abs_bound",
                    "terminal_utility",
                    "calibration_sha256",
                },
                "complete calibrated ProbCut object; absence is OFF",
            )
            require(
                samples == 0
                and type(p["shallow_depth"]) is int
                and p["shallow_depth"] == 1
                and type(p["deep_depth"]) is int
                and p["deep_depth"] == 3,
                "exact1/3 only; calibration references are OFF",
            )
            require(
                all(
                    type(p[k]) in (int, float) and math.isfinite(p[k])
                    for k in (
                        "slope",
                        "intercept",
                        "margin",
                        "nonterminal_abs_bound",
                        "terminal_utility",
                    )
                )
                and p["slope"] > 0
                and p["margin"] >= 0
                and p["nonterminal_abs_bound"] > 0
                and p["terminal_utility"] > p["nonterminal_abs_bound"]
                and isinstance(p["calibration_sha256"], str)
                and len(p["calibration_sha256"]) == 64
                and all(c in "0123456789abcdefABCDEF" for c in p["calibration_sha256"]),
                "finite calibrated domain and provenance; actual domain checked by native owner",
            )
    if "search_threads" in config:
        threads = config["search_threads"]
        team = config.get("search_cpu_cores")
        main = config.get("management_cpu_core")
        require(
            type(threads) is int
            and threads > 0
            and isinstance(team, list)
            and len(team) == threads
            and all(type(c) is int and c >= 0 for c in team)
            and len(set(team)) == threads
            and type(main) is int
            and main >= 0
            and main not in team
            and type(config.get("native_memory_bytes")) is int
            and config["native_memory_bytes"] >= 64 * 1024**2
            and config["profile"] == "control"
            and config["use_tt"]
            and config.get("zero_stock_approx_min_root_walls") is None
            and (
                ("neighbour_opportunity" not in config and "root_ordering_quality" not in config)
                or (
                    threads == 1
                    and config.get("root_ordering_quality") is True
                    and config.get("neighbour_opportunity") == "off_shadow"
                )
            )
            and all(
                not any(
                    r.get(k, False)
                    for k in (
                        "diagnostic",
                        "observe_lmr",
                        "observe_completed_depths",
                        "warmup",
                    )
                )
                for r in requests
            ),
            "positive admitted ordinary native search team; no observer/approximation",
        )
    else:
        require(
            not any(
                k in config
                for k in (
                    "search_cpu_cores",
                    "management_cpu_core",
                    "native_memory_bytes",
                )
            ),
            "unused search-team resources",
        )
    if "smp_sharing_provenance" in config:
        require(
            type(config["smp_sharing_provenance"]) is bool
            and (not config["smp_sharing_provenance"] or "search_threads" in config),
            "sharing provenance is an explicit Boolean opt-in for a configured native team",
        )
    if "time_reserve_ms" in config:
        reserve = config["time_reserve_ms"]
        require(
            ("search_threads" in config or config.get("root_ordering_quality") is True)
            and type(reserve) is int
            and reserve >= 0
            and all(
                type(r.get("time_limit_ms")) is int and r["time_limit_ms"] > reserve
                for r in requests
            ),
            "explicit clock requests retain a positive budget after reserve",
        )
    require(
        config["profile"] in {"control", "cheap", "coverage"},
        "configured ordering target",
    )
    for key in ("tt_entries", "output_bytes", "record_bytes"):
        require(type(config[key]) is int and config[key] > 0, "measurement positive " + key)
    require(
        config["record_bytes"] <= config["output_bytes"],
        "measurement record/output limit",
    )
    require(
        all(type(config[key]) is bool for key in ("use_tt", "use_pvs")),
        "measurement Boolean switches",
    )
    require(type(config.get("lmr", False)) is bool, "measurement LMR switch")
    require(
        type(config.get("zero_stock_safe_race", True)) is bool,
        "measurement safe-race switch",
    )
    safe_method = config.get("zero_stock_safe_race_method")
    require(
        safe_method is None
        or (
            type(safe_method) is str
            and safe_method
            in {
                "manhattan",
                "path_tail",
                "path_tail_future",
            }
        ),
        "measurement safe-race method",
    )
    root_quality = config.get("root_ordering_quality", False)
    require(type(root_quality) is bool, "root ordering quality Boolean switch")
    if "history_provenance" in config:
        watch = config["history_provenance"]
        require(
            root_quality and type(watch) is list and 0 < len(watch) <= 8,
            "bounded selected history entries require root quality",
        )
        seen_watch = set()
        for entry in watch:
            require(
                type(entry) is dict and entry.get("kind") in {"main", "continuation"},
                "history entry kind",
            )
            require(
                type(entry.get("colour")) is int
                and entry["colour"] in {0, 1}
                and type(entry.get("action")) is int
                and 0 <= entry["action"] < 209,
                "history entry colour/action",
            )
            if entry["kind"] == "main":
                require(
                    set(entry) == {"kind", "colour", "from_cell", "action"}
                    and (
                        (
                            entry["action"] < 81
                            and type(entry["from_cell"]) is int
                            and 0 <= entry["from_cell"] < 81
                        )
                        or (entry["action"] >= 81 and entry["from_cell"] is None)
                    ),
                    "history main entry key",
                )
            else:
                require(
                    set(entry) == {"kind", "colour", "lag", "previous", "action"}
                    and type(entry["lag"]) is int
                    and entry["lag"] in {1, 2, 3, 4, 6}
                    and type(entry["previous"]) is int
                    and 0 <= entry["previous"] < 209,
                    "history continuation entry key",
                )
            identity = tuple(sorted(entry.items()))
            require(identity not in seen_watch, "duplicate history entry")
            seen_watch.add(identity)
    opportunity = config.get("neighbour_opportunity")
    if "neighbour_opportunity" in config:
        require(
            type(opportunity) is str
            and opportunity in {"off_shadow", "on"}
            and config["profile"] == "control"
            and config["use_tt"]
            and config["use_pvs"]
            and config.get("lmr", False)
            and config.get("lmr_method", "depth_rank") == "depth_rank"
            and config.get("zero_stock_safe_race", True)
            and config.get("zero_stock_safe_race_method") in {None, "path_tail"}
            and config.get("zero_stock_approx_min_root_walls") is None,
            "isolated neighbour opportunity diagnostic",
        )
    lmr_method = config.get("lmr_method", "depth_rank")
    require(
        type(lmr_method) is str
        and lmr_method
        in (
            "fixed_one",
            "depth_rank",
        ),
        "measurement LMR method",
    )
    parameters = resolved_lmr_parameters(config, config["profile"])
    method = config.get("zero_stock_approx_method", "race")
    require(
        type(method) is str and method in {"race", "fixed_d"},
        "measurement zero-stock approximation method",
    )
    threshold = config.get("zero_stock_approx_min_root_walls")
    require(
        threshold is None or (type(threshold) is int and 0 <= threshold <= 20),
        "measurement zero-stock threshold must be an integer0..20 or null",
    )
    require(
        not config.get("lmr", False)
        or (config["use_pvs"] and config["profile"] in {"control", "cheap"}),
        "measurement LMR requires PVS and Control/Cheap",
    )
    require(
        config.get("seed") is None or (type(config["seed"]) is int and 0 <= config["seed"] < 2**64),
        "measurement seed metadata",
    )
    namespace = config["namespace"]
    require(
        isinstance(namespace, dict)
        and set(namespace) == {"evaluator", "rules", "selectivity"}
        and all(isinstance(v, str) and v for v in namespace.values())
        and namespace["rules"] == experiment["rules"],
        "measurement namespace",
    )
    inference = config.get("inference")
    if inference is not None:
        require(
            isinstance(inference, dict)
            and {"backend", "model", "model_sha", "library", "logical_row_limit"} <= set(inference)
            and set(inference)
            <= {
                "backend",
                "model",
                "model_sha",
                "library",
                "logical_row_limit",
                "device",
                "cuda_graph",
            }
            and inference["backend"] == "ort"
            and type(inference["logical_row_limit"]) is int
            and inference["logical_row_limit"] > 0
            and type(inference.get("device", 0)) is int
            and inference.get("device", 0) == 0
            and inference.get("cuda_graph", False) is False
            and all(
                type(inference[k]) is str and inference[k].startswith("/")
                for k in ("model", "library")
            )
            and type(inference["model_sha"]) is str
            and len(inference["model_sha"]) == 64
            and all(c in "0123456789abcdef" for c in inference["model_sha"]),
            "measurement native CPU inference shape/budget",
        )
        require(
            config["profile"] == "control"
            and not config.get("lmr", False)
            and config.get("zero_stock_approx_min_root_walls") is None
            and not config.get("zero_stock_safe_race", True)
            and experiment.get("models") == []
            and any(
                r["path"] == inference["model"] and r["sha256"] == inference["model_sha"]
                for r in experiment["inputs"]
            )
            and any(
                r["file"]["path"] == inference["library"]
                for r in experiment.get("dynamic_libraries", [])
            )
            and namespace["evaluator"].startswith("sigma-value-onnx-cpu:sha256:")
            and len(namespace["evaluator"].rsplit(":", 1)[-1]) == 64
            and all(c in "0123456789abcdef" for c in namespace["evaluator"].rsplit(":", 1)[-1]),
            "measurement closed Sigma inputs and native-owned identity",
        )
    require(isinstance(config["roots"], list) and config["roots"], "measurement roots")
    for root in config["roots"]:
        require(
            isinstance(root, dict)
            and {"input", "pointer", "field", "label"} <= set(root)
            and set(root)
            <= {
                "input",
                "pointer",
                "field",
                "label",
                "prefix_len",
                "jsonl_match",
                "check_history",
            }
            and type(root["input"]) is int
            and 0 <= root["input"] < len(experiment["inputs"])
            and all(isinstance(root[k], str) for k in ("pointer", "field", "label"))
            and (not root["pointer"] or root["pointer"].startswith("/"))
            and bool(root["field"]),
            "measurement root selector",
        )
        require(
            root.get("prefix_len") is None
            or (type(root["prefix_len"]) is int and root["prefix_len"] >= 0),
            "chronological prefix length",
        )
        require(
            root.get("jsonl_match") is None or isinstance(root["jsonl_match"], dict),
            "JSONL selection",
        )
        require(type(root.get("check_history", False)) is bool, "history check switch")
    require(isinstance(requests, list), "measurement request array")
    ids, closed, active = set(), set(), None
    for request in requests:
        require(
            isinstance(request, dict)
            and {"id", "session", "root", "depth", "node_cap"} <= set(request)
            and set(request)
            <= {
                "id",
                "session",
                "root",
                "depth",
                "node_cap",
                "time_limit_ms",
                "diagnostic",
                "warmup",
                "observe_completed_depths",
                "observe_lmr",
            }
            and all(isinstance(request[k], str) and request[k] for k in ("id", "session"))
            and request["id"] not in ids
            and type(request["root"]) is int
            and 0 <= request["root"] < len(config["roots"])
            and type(request["depth"]) is int
            and 0 < request["depth"] < 2**16
            and type(request["node_cap"]) is int
            and 0 < request["node_cap"] < 2**64,
            "measurement request type/range/identity",
        )
        require(
            request.get("time_limit_ms") is None
            or (type(request["time_limit_ms"]) is int and 0 < request["time_limit_ms"] < 2**64),
            "measurement optional deadline",
        )
        require(
            all(
                type(request.get(k, False)) is bool
                for k in (
                    "diagnostic",
                    "warmup",
                    "observe_completed_depths",
                    "observe_lmr",
                )
            ),
            "measurement request switches",
        )
        ids.add(request["id"])
        if active != request["session"]:
            require(request["session"] not in closed, "session reused after teardown")
            if active is not None:
                closed.add(active)
            active = request["session"]
    if opportunity is not None:
        require(
            all(
                not any(
                    r.get(k, False)
                    for k in (
                        "observe_lmr",
                        "diagnostic",
                        "observe_completed_depths",
                        "warmup",
                    )
                )
                for r in requests
            ),
            "opportunity diagnostic has no mixed observers/warmup",
        )
    if any(r.get("observe_lmr", False) for r in requests):
        require(
            len(requests) <= 12
            and len({r["session"] for r in requests}) == len(requests)
            and len({r["root"] for r in requests}) == len(requests)
            and config["profile"] == "control"
            and config["tt_entries"] == 1048576
            and config["use_tt"]
            and config["use_pvs"]
            and config.get("lmr", False)
            and lmr_method == "depth_rank"
            and parameters == resolved_lmr_parameters({}, "control")
            and threshold is None
            and not config.get("zero_stock_safe_race", True)
            and all(
                r.get("observe_lmr", False)
                and r["depth"] == 5
                and r["node_cap"] == 1000000
                and r.get("time_limit_ms") is None
                and not r.get("diagnostic", False)
                and not r.get("warmup", False)
                and not r.get("observe_completed_depths", False)
                for r in requests
            ),
            "bounded LMR observation cold Control/depth_rank D5/1M TT1M scope",
        )
        require(
            all(
                r["field"] == "prefix"
                and r.get("prefix_len") is None
                and r.get("jsonl_match") is None
                and not r.get("check_history", False)
                for r in config["roots"]
            ),
            "LMR observation complete-prefix selectors",
        )
    if root_quality:
        require(
            opportunity == "off_shadow"
            and config["tt_entries"] == 1048576
            and 0 < len(requests) <= 26
            and len({r["root"] for r in requests}) == len(requests)
            and len({r["session"] for r in requests}) <= 6
            and all(
                r["depth"] == 64
                and r["node_cap"] <= 1000000
                and (r.get("time_limit_ms") is None or config.get("time_reserve_ms") is not None)
                for r in requests
            ),
            "bounded root ordering quality OffShadow/TT1M/26roots/6sessions/D64/1M/optional-clock-with-reserve",
        )
    return config, requests


def measurement_evidence(spec, experiment, values, *, files=()):
    """Read the actual result; partial counts are facts, not a plan-equality gate."""
    snapshot = json.loads(values["settings"]) if "settings" in values else None
    result = json.loads(values["result"]) if "result" in values else None
    journal = values.get("measurements", b"")
    prefix, separator, tail = journal.rpartition(b"\n")
    complete = prefix + separator if separator else b""
    rows = [json.loads(line) for line in complete.splitlines()]
    require(
        snapshot is None or isinstance(snapshot, dict),
        "measurement settings snapshot shape",
    )
    if result is not None:
        require(
            isinstance(result, dict)
            and ("measurements" not in result or isinstance(result["measurements"], list)),
            "measurement result shape",
        )
        for key in ("planned", "calls", "complete", "uncompleted", "unperformed"):
            if key in result:
                require(
                    type(result[key]) is int and result[key] >= 0,
                    "measurement count type: " + key,
                )
        require(isinstance(result.get("errors"), list), "measurement errors array")
    shadow_config = document(experiment["config"])
    for row in rows:
        etc_opportunity_correspondence(shadow_config, row.get("measurement", {}))
    raw_refs = [ref for ref in files if spec.get("perf") and ref["path"] == spec["perf"]["output"]]
    if result is not None and spec.get("perf"):
        result = {**result, "perf_RAW": raw_refs}
    result_rows = result.get("measurements") if result is not None else None
    result_inline = result
    result_file = None
    if result is not None and len(values["result"]) > CONTROL_BYTES // 4:
        result_path = next(item["path"] for item in spec["data"] if item["name"] == "result")
        result_file = next(ref for ref in files if ref["path"] == result_path)
        result_inline = {
            key: result[key]
            for key in (
                "schema",
                "status",
                "planned",
                "calls",
                "complete",
                "uncompleted",
                "unperformed",
                "errors",
                "census",
                "runtime_launch_origin",
            )
            if key in result
        }
        result_inline["records_embedded"] = False
    recorded_prefix = rows if not isinstance(result_rows, list) else None
    recorded_prefix_file = None
    if recorded_prefix is not None and len(journal) > CONTROL_BYTES // 4:
        journal_path = next(item["path"] for item in spec["data"] if item["name"] == "measurements")
        recorded_prefix_file = next(ref for ref in files if ref["path"] == journal_path)
        recorded_prefix = None
    return {
        "settings": snapshot,
        "result": result_inline,
        "result_file": result_file,
        "journal_rows": len(rows),
        "journal_partial_tail": bool(tail),
        "journal_tail_bytes": len(tail),
        "journal_tail_sha256": sha(tail) if tail else None,
        "observed_complete": sum(row.get("status") == "COMPLETE" for row in rows),
        "journal_result_rows_agree": len(rows) == len(result_rows)
        if isinstance(result_rows, list)
        else None,
        "unreturned_tail": result is None,
        "recorded_prefix": recorded_prefix,
        "recorded_prefix_file": recorded_prefix_file,
        "runtime_launch_origin": result.get("runtime_launch_origin")
        if result
        else snapshot.get("runtime_launch_origin")
        if snapshot
        else None,
        "perf_RAW": raw_refs,
        "scope": "Actual settings plus result. Missing counters remain absent; partial/error/UNKNOWN are retained. No scientific adoption or original qualification claim.",
    }
