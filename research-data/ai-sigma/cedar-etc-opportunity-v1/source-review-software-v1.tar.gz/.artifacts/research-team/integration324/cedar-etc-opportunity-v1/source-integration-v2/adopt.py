"""Apply the two compiler-required type annotations to the new fixture only."""

import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = ROOT / ".worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    refs = load("etc33_composition_refs", OUT.parent / "source-integration-v1/adopt.py")
    owner = load("etc33_type_fix_owner", ROOT / "scripts/dev/research-lifecycle.py")
    binding_path = BASE / "sum-type-repair-v1/binding.json"
    assert (
        refs.ref(binding_path)["sha256"]
        == "8cf4ad17c882821ccf2b4ad23fc3fba3911b182ed1fbb9483eebc3421ccf1a72"
    )
    binding = json.loads(binding_path.read_bytes())
    before, post = refs.checked(binding["before"]), refs.checked(binding["post"])
    assert before.count(b".sum()") == 2
    assert before.replace(b".sum()", b".sum::<u64>()") == post
    original_path = OUT.parent / "source-integration-v1/composition.json"
    composition = json.loads(original_path.read_bytes())
    with owner.lease():
        for row in composition["subjects"]:
            assert refs.ref(Path(row["path"])) == row["actual"]
        path = ROOT / binding["owner"]
        assert path.read_bytes() == before
        path.write_bytes(post)
        for row in composition["subjects"]:
            if row["path"] == str(path):
                row["actual"] = refs.ref(path)
        composition.update(
            status="TWO_FIXTURE_TYPE_ANNOTATIONS_COMPOSED_SOFTWARE_PENDING",
            original_composition=refs.ref(original_path),
            causal_fixture_only=refs.ref(binding_path),
            production_unchanged=True,
            test_body_Search_entered_before_repair=0,
            post_sha256=hashlib.sha256(post).hexdigest(),
        )
        (OUT / "composition.json").write_text(json.dumps(composition, indent=2) + "\n")
    print(json.dumps(dict(status=composition["status"], production_unchanged=True)))


if __name__ == "__main__":
    main()
