"""Bind the current ETC33 source to new-only tests, affected Clippy and release."""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import subprocess
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
BASE = ROOT / ".worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1"
OLD = ROOT / ".artifacts/research-team/integration324/cedar-etc-v1/retirement-software-v1"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")
    return ref(path)


def main():
    load = importlib.util.spec_from_file_location(
        "etc33_build_owner", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(load)
    sys.modules[load.name] = lc
    load.loader.exec_module(lc)
    template = json.loads((OLD / "build-intent-release.json").read_bytes())
    plan = json.loads((BASE / "fixed-source-v2/new-test-plan.json").read_bytes())
    with lc.lease():
        composition_path = OUT.parent / "source-integration-v6/composition.json"
        composition = json.loads(composition_path.read_bytes())
        for row in composition["subjects"]:
            assert ref(Path(row["path"])) == row["actual"], row["path"]
        patch = OUT / "actual-source.patch"
        with patch.open("xb") as stream:
            stream.write(
                subprocess.check_output(
                    ["git", "diff", "--binary", "--no-ext-diff", "--no-textconv", "HEAD", "--"],
                    cwd=ROOT,
                )
            )
        source = copy.deepcopy(template["source"])
        untracked = subprocess.check_output(
            [
                "git",
                "ls-files",
                "--others",
                "--exclude-standard",
                "-z",
                "--",
                "Cargo.toml",
                "Cargo.lock",
                ".cargo",
                "crates",
            ],
            cwd=ROOT,
        )
        source.update(
            commit=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
            ).strip(),
            patch=ref(patch),
            untracked_inputs=[ref(ROOT / p.decode()) for p in untracked.split(b"\0") if p],
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        for row in source["cargo_configs"]:
            p = Path(row["path"])
            row["file"] = ref(p) if p.exists() else None
        adoption = save(
            "source-adoption.json",
            dict(
                schema="quoridor.research.source-adoption.v1",
                status="ACCEPTED",
                issue="quoridor-4lc.324.33",
                source=source,
                actual_composition=ref(composition_path),
                combined_target=ref(BASE / "related-review-repair-v2/binding.json"),
                original_combined=ref(BASE / "source-admin-v1/combined-target.json"),
                prior_AI3_original_failed_parent=ref(
                    OUT.parent / "software-v2/operation-release/candidate.json"
                ),
                prior_AI3_collection=ref(
                    OUT.parent / "software-v2/collection-v1/completion-and-STOP.json"
                ),
                prior_AI3_scope="Unchanged successful AI1/2/3 bodies reused; only witness collection helper changed and covered by new no-Search owner regression. No successful body replay.",
                changed_Python1=ref(OUT.parent / "python-software-v2/result.json"),
                independent_review_issue="quoridor-4lc.324.33.1",
                independent_review_status="ACCEPTED_SOURCE_ONLY_df324f04",
                independent_review_acceptance=ref(
                    OUT.parent / "source-review-v1/Root-source-acceptance.json"
                ),
                prior_no_Search_witness_regression=ref(
                    OUT.parent / "software-v3/collection-v1/completion-and-STOP.json"
                ),
                scope="Root accepts exact sparse working source for software qualification only. Related source-only review is accepted; this is not native/scientific admission. No old qualified software bodies replayed.",
            ),
        )
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
            owned_B=None,
            free_B=None,
        )
        support = save(
            "resources.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.33",
                authority=adoption,
                resources=dict(
                    CPU=2,
                    threads=1,
                    GPU=0,
                    worker_cpu=12,
                    guardian_cpu=16,
                    native_threads=1,
                    family_RAM_B=limits["family_B"],
                    controller_included=True,
                    controller_B=limits["controller_B"],
                    host_reserve_B=limits["host_reserve_B"],
                ),
                scope="Only failed Runner1 plus affected Clippy/release. Successful no-Search witness regression retained without replay. Prior AI3 PASS and 8 entered software Search/400000 upper preserved without replay; zero additional Search. No natural diagnostic/game/model grant.",
                storage="Ordinary affected source/software usage checked once after STOP; existing sole serial target, no advance microstorage gate or quota transfer.",
            ),
        )
        target = Path(template["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker["writer"] == WRITER
        handover = json.loads((OLD / "target-handover.json").read_bytes())
        handover.update(
            fresh_private_root=str(OUT / "private-image-release"),
            actual_source_adoption=adoption,
            owned_remaining=[],
        )
        handover.pop("test_cpu_cores", None)
        handover_ref = save("target-handover.json", handover)
        cargo = template["tools"]["CARGO"]["file"]["path"]
        common = [
            "--offline",
            "--locked",
            "--manifest-path",
            str(ROOT / "Cargo.toml"),
            "-j1",
            "--message-format=json-render-diagnostics",
            "--release",
        ]
        commands = []
        for package, features, selectors in [
            (
                "quoridor-runner",
                "measurement,quoridor-inference/claustrophobia",
                [plan["Runner"]["selector"]],
            ),
        ]:
            for index, selector in enumerate(selectors, 1):
                commands.append(
                    dict(
                        name=f"etc33-related-{package}-{index}",
                        role="test",
                        selector=selector,
                        argv=[
                            cargo,
                            "test",
                            *common,
                            "-p",
                            package,
                            "--features",
                            features,
                            "--lib",
                            selector,
                            "--",
                            "--exact",
                            "--nocapture",
                            "--test-threads=1",
                        ],
                    )
                )
        for package, features in [
            ("quoridor-core", "research-diagnostics"),
            ("quoridor-ai", "research-diagnostics"),
            ("quoridor-runner", "measurement,quoridor-inference/claustrophobia"),
        ]:
            commands.append(
                dict(
                    name=f"etc33-affected-{package}-Clippy",
                    role="lint",
                    argv=[
                        cargo,
                        "clippy",
                        *common,
                        "-p",
                        package,
                        "--features",
                        features,
                        "--all-targets",
                        "--no-deps",
                        "--",
                        "-Dwarnings",
                    ],
                )
            )
        build = copy.deepcopy(next(c for c in template["commands"] if c["role"] == "build"))
        build["name"] = "etc33-genuine-common-diagnostic-release"
        commands.append(build)
        spec = copy.deepcopy(template)
        for key in ("admission", "intent_sha256", "test_cpu_cores"):
            spec.pop(key, None)
        spec.update(
            output=str(OUT / "operation-release"),
            owned_outputs=[str(OUT.parent), str(target)],
            support=support,
            source_adoption=adoption,
            target_handover=handover_ref,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / "private-image-release/quoridor-runner"),
            TMP=str(OUT / "build-TMP"),
            command_timeout_seconds=2400,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        (target / ".research-owner.json").write_text(
            json.dumps(
                dict(writer=WRITER, target=str(target), support_sha256=support["sha256"]), indent=2
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            "admission.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Software-only; actual normal current CPU/source/RAM/cancel/cleanup admission required. Independent review before any scientific entry.",
            ),
        )
        intent = save("build-intent-release.json", spec)
        job = json.loads((OLD / "job-release.json").read_bytes())
        job.update(
            argv=[
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "build",
                "--intent",
                intent["path"],
                "--sha256",
                intent["sha256"],
            ],
            resource_contract=support["path"],
            max_runtime_seconds=2460,
            end_at=None,
            notify_until=None,
        )
        save("job-release.json", job)
        print(json.dumps(dict(intent=intent, support=support, submitted=False)))


if __name__ == "__main__":
    main()
