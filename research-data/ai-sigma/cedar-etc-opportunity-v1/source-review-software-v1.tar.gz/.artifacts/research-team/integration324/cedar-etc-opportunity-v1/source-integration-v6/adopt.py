"""Apply two explicit safe-race false settings only in the failed Runner fixture."""

import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    refs = load("etc33_safe_race_refs", OUT.parent / "source-integration-v1/adopt.py")
    lc = load("etc33_safe_race_current", ROOT / "scripts/dev/research-lifecycle.py")
    binding_path = (
        ROOT
        / ".worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1/runner-safe-race-fixture-repair-v1/binding.json"
    )
    assert (
        refs.ref(binding_path)["sha256"]
        == "420e94680f1b193336cc9546be5520848bd5ba198fdd4c37b4ff8b0e7d131a58"
    )
    binding = json.loads(binding_path.read_bytes())
    before, post = refs.checked(binding["before"]), refs.checked(binding["post"])
    actual = before
    for row in binding["exact_replacements"]:
        anchor, replacement = row["before"].encode(), row["after"].encode()
        assert actual.count(anchor) == 1
        actual = actual.replace(anchor, replacement)
    assert actual == post
    original = OUT.parent / "source-integration-v5/composition.json"
    composition = json.loads(original.read_bytes())
    with lc.lease():
        for row in composition["subjects"]:
            assert refs.ref(Path(row["path"])) == row["actual"]
        path = ROOT / binding["owner"]
        assert path.read_bytes() == before
        path.write_bytes(post)
        for row in composition["subjects"]:
            if row["path"] == str(path):
                row["actual"] = refs.ref(path)
        composition.update(
            status="ACCEPTED_SOURCE_UNCHANGED_FAILED_RUNNER_FIXTURE_SAFE_RACE_CORRECTED_SOFTWARE_PENDING",
            original_composition=refs.ref(original),
            failed_Runner_fixture_only=refs.ref(binding_path),
            production_change=False,
            accepted_source_review_unchanged=True,
            extra_Search_calls=0,
        )
        (OUT / "composition.json").write_text(json.dumps(composition, indent=2) + "\n")
    print(json.dumps(dict(status=composition["status"], production_change=False)))


if __name__ == "__main__":
    main()
