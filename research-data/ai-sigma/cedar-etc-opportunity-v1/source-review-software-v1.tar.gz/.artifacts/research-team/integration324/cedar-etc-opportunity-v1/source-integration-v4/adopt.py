"""Compose only the six related ETC repair owners into the current source."""

import ast
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = ROOT / ".worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def bodies(data):
    lines = data.splitlines(keepends=True)
    return {
        node.name: b"".join(lines[node.lineno - 1 : node.end_lineno])
        for node in ast.parse(data).body
        if isinstance(node, ast.FunctionDef)
    }


def main():
    refs = load("etc33_related_refs", OUT.parent / "source-integration-v1/adopt.py")
    owner = load("etc33_related_owner", ROOT / "scripts/dev/research-lifecycle.py")
    binding_path = BASE / "related-review-repair-v2/binding.json"
    assert (
        refs.ref(binding_path)["sha256"]
        == "f6904d9bf0f9eb9d2965a5abea5bfedf058b046aa9d1fb0d2d6914cec6f9553b"
    )
    binding = json.loads(binding_path.read_bytes())
    selectors = json.loads(refs.checked(binding["fragment_selectors"]))
    original = OUT.parent / "source-integration-v3/composition.json"
    composition = json.loads(original.read_bytes())
    pending = []
    with owner.lease():
        for row in composition["subjects"]:
            assert refs.ref(Path(row["path"])) == row["actual"]
        for row in binding["subjects"]:
            path = ROOT / row["subject"]
            before, post = refs.checked(row["before"]), refs.checked(row["post"])
            actual = path.read_bytes()
            if row["subject"] == "scripts/dev/research-lifecycle.py":
                selector = selectors["LC"]
                old, new = selector["exact_before"].encode(), selector["exact_after"].encode()
                expected, current = bodies(before), bodies(actual)
                name = selector["owner"]
                assert expected[name] == current[name]
                assert current[name].count(old) == 1 and actual.count(old) == 1
                candidate = actual.replace(old, new, 1)
                changed = bodies(candidate)
                assert changed[name] == bodies(post)[name]
                assert all(current[key] == changed[key] for key in current if key != name)
            else:
                assert actual == before, path
                candidate = post
            if row["subject"] == "crates/quoridor-ai/src/etc_opportunity_tests.rs":
                assert candidate.startswith(before), "original AI1/2/3 bodies must remain exact"
            pending.append((path, actual, candidate))
        for path, before, post in pending:
            saved = OUT / "current-before" / path.relative_to(ROOT)
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(before)
            assert path.read_bytes() == before
            path.write_bytes(post)
            for row in composition["subjects"]:
                if row["path"] == str(path):
                    row["actual"] = refs.ref(path)
        composition.update(
            status="RELATED_R1_R2_O1_COMPOSED_SOURCE_REVIEW_SOFTWARE_PENDING",
            original_composition=refs.ref(original),
            related_target=refs.ref(binding_path),
            production_unchanged=False,
            production_delta="Witness retention, exact report evaluator, restore original unrelated admissions; no Search/TT/cut math changes",
            current_CPU_and_MPC_functions_preserved=True,
            extra_Search_calls=0,
        )
        (OUT / "composition.json").write_text(json.dumps(composition, indent=2) + "\n")
    print(json.dumps(dict(status=composition["status"], changed_subjects=len(pending))))


if __name__ == "__main__":
    main()
