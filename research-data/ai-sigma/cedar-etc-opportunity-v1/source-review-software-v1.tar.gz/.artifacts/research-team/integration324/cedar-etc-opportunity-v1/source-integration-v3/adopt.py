"""Apply the two compiler-required type annotations to the new fixture only."""

import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = ROOT / ".worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    refs = load("etc33_composition_refs", OUT.parent / "source-integration-v1/adopt.py")
    owner = load("etc33_type_fix_owner", ROOT / "scripts/dev/research-lifecycle.py")
    binding_path = BASE / "witness-type-repair-v2/binding.json"
    assert (
        refs.ref(binding_path)["sha256"]
        == "5c4a02233cad64ece5b09e72c839dd45a2511ae1ba414f4f6e1fbb43edaede0c"
    )
    binding = json.loads(binding_path.read_bytes())
    before, post = refs.checked(binding["before"]), refs.checked(binding["post"])
    assert before.count(binding["exact_old"].encode()) == 1
    assert before.replace(binding["exact_old"].encode(), binding["exact_new"].encode()) == post
    original_path = OUT.parent / "source-integration-v2/composition.json"
    composition = json.loads(original_path.read_bytes())
    with owner.lease():
        for row in composition["subjects"]:
            assert refs.ref(Path(row["path"])) == row["actual"]
        path = ROOT / binding["owner"]
        assert path.read_bytes() == before
        path.write_bytes(post)
        for row in composition["subjects"]:
            if row["path"] == str(path):
                row["actual"] = refs.ref(path)
        composition.update(
            status="WITNESS_OPTION_TYPE_COMPOSED_RELATED_SOURCE_REPAIR_PENDING",
            original_composition=refs.ref(original_path),
            causal_serializer_type_only=refs.ref(binding_path),
            search_math_protocol_unchanged=True,
            synthetic_Search_entered_before_repair=8,
            post_sha256=hashlib.sha256(post).hexdigest(),
        )
        (OUT / "composition.json").write_text(json.dumps(composition, indent=2) + "\n")
    print(json.dumps(dict(status=composition["status"], search_math_protocol_unchanged=True)))


if __name__ == "__main__":
    main()
