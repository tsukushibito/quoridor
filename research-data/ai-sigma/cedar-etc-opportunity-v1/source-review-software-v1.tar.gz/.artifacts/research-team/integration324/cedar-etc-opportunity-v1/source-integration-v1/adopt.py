"""Compose fixed ETC33 fragments into current owners; preserve current CPU bodies."""

import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = ROOT / ".worktree/search-optimization/.artifacts/cedar-etc-opportunity-v1"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def checked(row):
    path = Path(row["path"])
    assert ref(path) == row, path
    return path.read_bytes()


def spans(data):
    lines = data.splitlines(keepends=True)
    return {
        node.name: b"".join(lines[node.lineno - 1 : node.end_lineno])
        for node in ast.parse(data).body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
    }


def main():
    combined_path = BASE / "source-admin-v1/combined-target.json"
    assert (
        ref(combined_path)["sha256"]
        == "3199bf8ab9bf42a5d28eb6e608b60ec210329b668b416623acde041127fd7e6f"
    )
    combined = json.loads(combined_path.read_bytes())
    binding = json.loads(checked(combined["base_binding"]))
    delta = json.loads(checked(combined["new_Runner_fixture_override"]))
    checked(combined["source_STOP"])
    selectors = json.loads(checked(binding["selectors"]))["selectors"]
    protection = json.loads(checked(binding["protection"]))
    spec = importlib.util.spec_from_file_location(
        "etc33_current_owner", ROOT / "scripts/dev/research-lifecycle.py"
    )
    owner = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = owner
    spec.loader.exec_module(owner)
    prepared = []
    with owner.lease():
        for row in binding["files"]:
            path = ROOT / row["path"]
            post = checked(row["post"])
            fragments = [f for f in selectors if f["path"] == row["path"]]
            if row["before"] is None:
                assert not path.exists(), path
                before = None
                candidate = post
            else:
                original = checked(row["before"])
                before = path.read_bytes()
                if row["path"] == "scripts/dev/research-lifecycle.py":
                    assert (
                        hashlib.sha256(before).hexdigest()
                        == "9a044d44d678c60d556b480354c3d39527596587cbf6c730eb4d303ddbfca41e"
                    )
                else:
                    assert before == original, path
                candidate = before
                check_original = original
                for fragment in fragments:
                    assert fragment["action"] == "exact_unique_fragment"
                    prefix, old, new, suffix = (
                        fragment[k].encode() for k in ("prefix", "before", "after", "suffix")
                    )
                    match = prefix + old + suffix
                    assert check_original.count(match) == 1, (
                        path,
                        fragment["before_line"],
                        "original",
                    )
                    assert candidate.count(match) == 1, (path, fragment["before_line"], "current")
                    check_original = check_original.replace(match, prefix + new + suffix, 1)
                    candidate = candidate.replace(match, prefix + new + suffix, 1)
                assert check_original == post, (path, "post custody")
                if row["path"] == "scripts/dev/research-lifecycle.py":
                    old_spans, new_spans = spans(before), spans(candidate)
                    for name in old_spans.keys() - set(protection["LC_changed_functions"]):
                        assert old_spans[name] == new_spans[name], name
                    assert new_spans.keys() - old_spans.keys() == set(
                        protection["LC_new_functions"]
                    )
            if row["path"] == "crates/quoridor-runner/src/etc_opportunity_consumer_tests.rs":
                assert candidate == checked(delta["before"])
                candidate = checked(delta["post"])
            prepared.append((path, before, candidate))
        assert len(selectors) == 34 and len(prepared) == 10
        records = []
        for path, before, candidate in prepared:
            if before is not None:
                saved = OUT / "current-before" / path.relative_to(ROOT)
                saved.parent.mkdir(parents=True, exist_ok=True)
                saved.write_bytes(before)
                before_ref = ref(saved)
            else:
                before_ref = None
            if before is None:
                with path.open("xb") as stream:
                    stream.write(candidate)
            else:
                assert path.read_bytes() == before
                path.write_bytes(candidate)
            os.chmod(path, 0o644)
            records.append(dict(path=str(path), before=before_ref, actual=ref(path)))
        result = dict(
            status="SPARSE_COMPOSED_UNQUALIFIED_SOFTWARE_PENDING",
            combined=ref(combined_path),
            subjects=records,
            current_CPU_and_MPC_functions_preserved=True,
            whole_old_owner_overwrite=False,
            scientific_execution=0,
        )
        (OUT / "composition.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(dict(status=result["status"], subjects=len(records))))


if __name__ == "__main__":
    main()
