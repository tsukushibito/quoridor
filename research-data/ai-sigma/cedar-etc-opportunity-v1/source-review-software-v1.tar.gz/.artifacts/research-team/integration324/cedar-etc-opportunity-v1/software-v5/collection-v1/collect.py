"""Collect the actual post-retirement build and finalize its new manifest once."""

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper = load(
        "metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py",
    )
    lc = load("current", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helper.ref
    runtime = BASE / "build-runtime-v1"
    outer_path = runtime / "result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((runtime / "state.json").read_bytes())
    submitted = json.loads((BASE / "original-release-submit-v1.json").read_bytes())
    assert (
        outer["job_id"]
        == json.loads(submitted["stdout"])["job_id"]
        == "ff989b7d-debf-409e-a8dc-66b74d84c982"
    )
    assert outer["outcome"] == "succeeded" and outer["exit_code"] == 0
    assert outer["cleanup_complete"] and outer["direct_child_reaped"] and outer["remaining"] == []
    operation = BASE / "operation-release"
    candidate_path = operation / "candidate.json"
    candidate_ref = ref(candidate_path)
    candidate = json.loads(candidate_path.read_bytes())
    assert candidate["status"] == "PENDING_FINALIZATION"
    assert candidate["cleanup_complete"] and candidate["process_cleanup_complete"]
    assert candidate["remaining"] == candidate["owed_finalizers"] == []
    intent = json.loads(helper.checked(candidate["intent"]).read_bytes())
    known, lints, builds, tests = [], [], [], []
    for row in candidate["checks"]:
        assert row["status"] == "PASS" and row["capture_complete"]
        assert row["primary"] is None and row["secondary"] == []
        record = row["guardian_return"]
        lc.settled(record)
        assert record["handle_closes_complete"]
        member = record["child"]
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
        if row["role"] in {"lint", "build"}:
            report = lc.cargo_report(helper.checked(row["full_log"]).read_bytes())
            assert report["warning_count"] == 0
            if row["role"] == "lint":
                assert "--all-targets" in row["argv"] and "-Dwarnings" in row["argv"]
                lints.append(dict(log=row["full_log"], process=row["persisted_process_receipt"]))
            else:
                builds.append((row, report))
        elif row["role"] == "test":
            body = helper.checked(row["full_log"]).read_text()
            assert "running 1 test" in body and "test result: ok. 1 passed" in body
            tests.append(row)
        else:
            assert row["role"] == "version"
    assert len(lints) == 3 and len(builds) == 1 and len(tests) == 1
    row, report = builds[0]
    assert row["name"] == "etc33-genuine-common-diagnostic-release"
    artifacts = [
        a
        for a in report["artifacts"]
        if a["target"]["name"] == "quoridor-runner"
        and a["target"]["kind"] == ["bin"]
        and not a["profile"]["test"]
    ]
    assert len(artifacts) == 1 and artifacts[0] == candidate["cargo_artifact"]
    for member in (
        state["child"],
        state["supervisor"],
        state["launch"]["owner"],
        state["launch"]["launcher"],
    ):
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != member
        known.append(dict(original=member, fresh=fresh))
    assert not (operation / "manifest.json").exists()
    manifest = lc.finalize(operation, ref(outer_path))
    assert manifest["status"] == "PASS" and manifest["artifact"] == candidate["artifact"]
    assert ref(candidate_path) == candidate_ref
    with lc.lease():
        lc.source_check(intent["source"])
        assert not Path(intent["TMP"]).exists()
        callers = [
            ref(ROOT / p)
            for p in [
                "scripts/dev/research-lifecycle.py",
                "scripts/dev/research-job.py",
                "python/quoridor_training/cycle_process.py",
                "python/quoridor_training/snapshot.py",
            ]
        ]
        affected = helper.allocated_union([Path(p) for p in intent["owned_outputs"]])
    result = dict(
        status="ACTUAL_ETC33_RUNNER_CORE_AI_RUNNER_CLIPPY_TYPE_GENUINE_DIAGNOSTIC_RELEASE_PASS_SOURCE_STOP",
        issue="quoridor-4lc.324.33",
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        software_manifest=ref(operation / "manifest.json"),
        artifact=manifest["artifact"],
        cargo_artifact=artifacts[0],
        actual_cached_Cargo_fresh=artifacts[0]["fresh"],
        outer=ref(outer_path),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        test_bodies_executed=1,
        actual_Runner_test=tests[0],
        prior_AI3_reused_without_replay=ref(
            BASE.parent / "software-v2/collection-v1/completion-and-STOP.json"
        ),
        prior_no_Search_R1_reused_without_replay=ref(
            BASE.parent / "software-v3/collection-v1/completion-and-STOP.json"
        ),
        current_Python1=ref(BASE.parent / "python-software-v2/result.json"),
        accepted_source_review=ref(BASE.parent / "source-review-v1/Root-source-acceptance.json"),
        cumulative_software_Search=8,
        software_nodes_upper=400000,
        actual_software_nodes="NOT_EXTRACTED",
        new_Search=0,
        natural_diagnostic_calls=0,
        games=0,
        affected_alltarget_Clippy=lints,
        cpu_launch=state["cpu_launch"],
        current_callers=callers,
        known_exact_commands_fresh_absent_or_different=known,
        source_EX_NB_acquired_released=True,
        source_leases=[],
        remaining_owned=[],
        TMP=[],
        affected_current_union_point_once=affected,
        no_new_charge_credit_refund_lending=True,
        retained_serial_target=True,
        Search_model_RAW_RNG_replay=0,
        qualification="Software/type/new diagnostic image only. Controlled ordinary-Search TT positive remains separate from natural opportunity; natural17 and practical candidate/game admission unentered. Old ETC31 and MPC failures/UNKNOWN/defaults unchanged; no performance/strength claim.",
        host_future_quiet=False,
        fees_globalactual_later_tails="UNKNOWN",
    )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            dict(
                status=result["status"],
                manifest=result["software_manifest"],
                artifact=result["artifact"],
            )
        )
    )


if __name__ == "__main__":
    main()
