"""Apply only the failed legacy-observer fixture setup and record source acceptance."""

import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PRIVATE = ROOT / ".worktree/search-optimization/.artifacts"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    refs = load("etc33_fixture_refs", OUT.parent / "source-integration-v1/adopt.py")
    lc = load("etc33_fixture_current", ROOT / "scripts/dev/research-lifecycle.py")
    binding_path = (
        PRIVATE / "cedar-etc-opportunity-v1/runner-observer-fixture-repair-v1/binding.json"
    )
    assert (
        refs.ref(binding_path)["sha256"]
        == "75cda04fe3e4983d31d2085418fdc8e5cb471cc86be549bfca9f390308ee64d6"
    )
    binding = json.loads(binding_path.read_bytes())
    before, post = refs.checked(binding["before"]), refs.checked(binding["post"])
    anchor, added = binding["exact_anchor"].encode(), binding["exact_added"].encode()
    assert before.count(anchor) == 1 and before.replace(anchor, anchor + added) == post
    review = PRIVATE / "cedar-etc-opportunity-review-v1/related-v1/minimum.json"
    assert (
        refs.ref(review)["sha256"]
        == "df324f042f13e3a7a0bdf07096c48b7dffda60235bf328963b01fa46dab5a319"
    )
    minimum = json.loads(review.read_bytes())
    assert minimum["verdict"] == "SOURCE_CLEAR" and minimum["essential"] == minimum["ordinary"] == 0
    original = OUT.parent / "source-integration-v4/composition.json"
    composition = json.loads(original.read_bytes())
    with lc.lease():
        for row in composition["subjects"]:
            assert refs.ref(Path(row["path"])) == row["actual"]
        path = ROOT / binding["owner"]
        assert path.read_bytes() == before
        path.write_bytes(post)
        for row in composition["subjects"]:
            if row["path"] == str(path):
                row["actual"] = refs.ref(path)
        composition.update(
            status="RELATED_SOURCE_ACCEPTED_FAILED_RUNNER_FIXTURE_CORRECTED_SOFTWARE_PENDING",
            original_composition=refs.ref(original),
            failed_Runner_fixture_only=refs.ref(binding_path),
            accepted_related_source_review=refs.ref(review),
            extra_Search_calls=0,
        )
        (OUT / "composition.json").write_text(json.dumps(composition, indent=2) + "\n")
        accepted = OUT.parent / "source-review-v1"
        accepted.mkdir()
        reason = (
            "Root accepted df324f04 SOURCE_CLEAR e0/o0 for exactf6904d9b related R1/R2/O1, "
            "reusing bounded original nonfindings. Current sparse CPU32/MPC composition preserved. "
            "New no-Search R1 and changed Python1 actualPASS; Runner fixture/software/Clippy/release "
            "remain separate Root qualifications. No natural diagnostic, practical cut candidate, "
            "performance/game/default/newrights claim; original negatives/failures/UNKNOWN retained. "
            "Root acceptance .artifacts/research-team/integration324/cedar-etc-opportunity-v1/source-review-v1/Root-source-acceptance.json"
        )
        record = dict(
            issue="quoridor-4lc.324.33.1",
            status="ACCEPTED_SOURCE_ONLY",
            minimum=refs.ref(review),
            target=minimum["target"],
            original_negative=minimum["original_negative_refs"],
            actual_reader_STOP=minimum["actual_reader_STOP"],
            actual_returned_STOP=refs.ref(review.parent / "returned-STOP.json"),
            actual_composition=refs.ref(OUT / "composition.json"),
            ordinary_failed_fixture=refs.ref(binding_path),
            source_only=True,
            actual_software_and_native_admission_separate=True,
            exact_close_reason=reason,
        )
        (accepted / "Root-source-acceptance.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(dict(status=composition["status"], source_verdict="ACCEPTED_SOURCE_ONLY")))


if __name__ == "__main__":
    main()
