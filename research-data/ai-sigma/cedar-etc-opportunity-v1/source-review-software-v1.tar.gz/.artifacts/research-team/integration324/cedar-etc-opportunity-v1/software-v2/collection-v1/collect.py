"""Collect the original compile failure without refinalizing or replaying it."""

import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def main():
    spec = importlib.util.spec_from_file_location(
        "etc33_failed_collection", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = lc
    spec.loader.exec_module(lc)
    runtime = BASE / "build-runtime-v1"
    outer = json.loads((runtime / "result.json").read_bytes())
    state = json.loads((runtime / "state.json").read_bytes())
    candidate_path = BASE / "operation-release/candidate.json"
    candidate_ref = ref(candidate_path)
    candidate = json.loads(candidate_path.read_bytes())
    assert outer["job_id"] == state["job_id"] == "840930c6-b5e5-4c7e-b5f4-2addbcad526f"
    assert outer["outcome"] == "failed" and outer["exit_code"] == 1
    assert outer["cleanup_complete"] and outer["direct_child_reaped"] and outer["remaining"] == []
    assert candidate["status"] == "FAILED"
    failed = [row for row in candidate["checks"] if row["status"] == "FAILED"]
    assert len(failed) == 1 and failed[0]["name"] == "etc33-new-quoridor-runner-1"
    command = failed[0]
    assert command["guardian_return"] is None and not command["capture_complete"]
    exception = command["guardian_exception_outcome"]
    assert exception["normal_return"] is False
    record = exception["record"]
    assert record["exit_code"] == 101
    assert (
        record["cleanup_complete"]
        and record["direct_child_reaped"]
        and record["handle_closes_complete"]
    )
    assert record["remaining"] == [] and record["finalization_errors"] == []
    assert record["signal_mask_restoration"] == record["final_record_persist"] == "completed"
    log = Path(command["full_log"]["path"])
    assert ref(log) == command["full_log"]
    data = log.read_text()
    assert "error[E0277]" in data and "running 1 test" not in data
    assert "measurement.rs:3395:13" in data
    passed_AI = [
        row for row in candidate["checks"] if row["role"] == "test" and row["status"] == "PASS"
    ]
    assert len(passed_AI) == 3
    for row in passed_AI:
        assert row["capture_complete"] and row["primary"] is None and row["secondary"] == []
        body = Path(row["full_log"]["path"]).read_text()
        assert "running 1 test" in body and "test result: ok. 1 passed" in body
        actual = row["guardian_return"]
        assert (
            actual["exit_code"] == 0
            and actual["cleanup_complete"]
            and actual["handle_closes_complete"]
            and actual["remaining"] == []
        )
    known = []
    for row in candidate["checks"]:
        process = row.get("guardian_return") or row["guardian_exception_outcome"]["record"]
        member = process["child"]
        current = lc.process.identity(lc.process.process_info(member["pid"]))
        assert current != member
        known.append(dict(original=member, fresh=current))
    for member in [state["child"], state["launch"]["owner"], state["launch"]["launcher"]]:
        current = lc.process.identity(lc.process.process_info(member["pid"]))
        assert current != member
        known.append(dict(original=member, fresh=current))
    supervisor = state["supervisor"]
    supervisor_fresh = lc.process.identity(lc.process.process_info(supervisor["pid"]))
    intent = json.loads(Path(candidate["intent"]["path"]).read_bytes())
    with lc.lease():
        lc.source_check(intent["source"])
        temporary = Path(intent["TMP"])
        contents = [str(p) for p in temporary.rglob("*")] if temporary.exists() else []
        assert not contents
    result = dict(
        status="ORIGINAL_RUNNER_COMPILER_FAILED_AI3_PASS_SOURCE_STOP",
        issue="quoridor-4lc.324.33",
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        outer=ref(runtime / "result.json"),
        config=ref(runtime / "config.json"),
        outer_log=ref(runtime / "output.log"),
        original_candidate=candidate_ref,
        original_INCOMPLETE=ref(BASE / "operation-release/INCOMPLETE"),
        passed_new_AI=passed_AI,
        failed_full_log=command["full_log"],
        failed_process=command["persisted_process_receipt"],
        guardian_return=None,
        capture_complete=False,
        candidate_cleanup_complete=candidate["cleanup_complete"],
        actual_after_finally_exception_cleanup=exception,
        known_payload_controller_submit_IDs_fresh_absent_or_different=known,
        finished_supervisor=dict(
            original=supervisor, fresh=supervisor_fresh, possible_notification_only=True
        ),
        actual_source_EX_NB_acquired_released=True,
        sourceleases=[],
        old_failed_TMP_retained=str(temporary) if temporary.exists() else None,
        old_failed_TMP_contents=contents,
        refinalize=False,
        test_bodies_entered=3,
        synthetic_Search_entered=8,
        synthetic_nodes_upper=400000,
        synthetic_actual_nodes="NOT_EXTRACTED",
        natural_diagnostic_calls=0,
        Runner_test_body="UNENTERED",
        later_Clippy_release="UNENTERED",
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        full_fees="UNKNOWN",
        host_future_quiet=False,
    )
    assert ref(candidate_path) == candidate_ref
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            dict(
                status=result["status"],
                outer_seconds_once=outer["wall_seconds"],
                synthetic_Search_entered=8,
                synthetic_nodes_upper=400000,
                synthetic_actual_nodes="NOT_EXTRACTED",
                sourceleases=[],
            )
        )
    )


if __name__ == "__main__":
    main()
