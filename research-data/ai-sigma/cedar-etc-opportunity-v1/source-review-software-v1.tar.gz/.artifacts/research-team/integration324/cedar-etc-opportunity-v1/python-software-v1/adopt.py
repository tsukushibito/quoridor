"""Execute only the new ETC33 canonical Python boundary definition."""

import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts/dev"))
spec = importlib.util.spec_from_file_location(
    "etc33_software_lease", ROOT / "scripts/dev/research-lifecycle.py"
)
owner = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = owner
spec.loader.exec_module(owner)
with owner.lease(shared=True):
    suite = unittest.defaultTestLoader.loadTestsFromName(
        "test_research_lifecycle_etc_opportunity.EtcOpportunityMetadata.test_typed_request_and_actual_multirow_measurement_evidence"
    )
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    (OUT / "result.json").write_text(
        json.dumps(
            dict(
                testsRun=result.testsRun,
                failures=len(result.failures),
                errors=len(result.errors),
                skipped=len(result.skipped),
                successful=result.wasSuccessful(),
                scientific_calls=0,
                old_test_bodies_replayed=0,
            ),
            indent=2,
        )
        + "\n"
    )
    assert result.testsRun == 1 and result.wasSuccessful()
