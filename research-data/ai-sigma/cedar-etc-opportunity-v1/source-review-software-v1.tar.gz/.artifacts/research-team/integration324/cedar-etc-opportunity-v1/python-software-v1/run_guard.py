"""Own bounded ETC source composition and preserve the actual cleanup record."""

import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import CycleResources, execute

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
temporary = OUT / "guard-TMP"
temporary.mkdir()
deadline = time.monotonic() + 180
resources = CycleResources(
    dict(max_memory_bytes=1024**3 - 64 * 1024**2, host_ram_reserve=4 * 1024**3), OUT, deadline
)
returned = None
failure = None
try:
    returned = execute(
        [sys.executable, "-B", str(OUT / "adopt.py")],
        OUT / "adopt.execution.log",
        deadline,
        cpu_cores=[10],
        resources=resources,
        cwd=ROOT,
        env=dict(
            os.environ, TMPDIR=str(temporary), CUDA_VISIBLE_DEVICES="", PYTHONDONTWRITEBYTECODE="1"
        ),
    )
except BaseException as error:
    failure = dict(type=type(error).__name__, message=str(error))
finally:
    process_path = OUT / "adopt.execution.process.json"
    actual = json.loads(process_path.read_bytes()) if process_path.exists() else None
    (OUT / "actual-returned-STOP.json").write_text(
        json.dumps(
            dict(
                actual_return=returned,
                actual_disk_record=actual,
                failure=failure,
                TMP_retained=[str(p) for p in temporary.rglob("*")],
                host_future_quiet=False,
                scientific_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
print(json.dumps(dict(failure=failure, exit_code=returned.get("exit_code") if returned else None)))
assert failure is None and returned["exit_code"] == 0 and returned["cleanup_complete"]
