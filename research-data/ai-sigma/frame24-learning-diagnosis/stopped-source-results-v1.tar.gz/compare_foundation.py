"""Compare stopped saved CPU/CUDA results and conserve whole-attempt accounting."""

import base64
import gzip
import hashlib
import json
import math
from pathlib import Path
import struct
import time

HERE = Path(__file__).resolve().parent
ASSETS = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/frame24-learning-diagnosis"
)


def read(path):
    if not path.exists():
        path = path.with_suffix(path.suffix + ".gz")
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)


def main():
    began = time.monotonic()
    outputs = {case: ASSETS / f"case-{case}-r1" for case in ("CPU", "CUDA")}
    runs = {case: read(HERE / f"case-{case}-entry-v2/result.json") for case in outputs}
    for run in runs.values():
        assert run["waited"] and not run["current_exact"] and not run["current_pgrp"]
    curves = {case: read(root / "curves.json") for case, root in outputs.items()}
    configs = {case: read(root / "config.json") for case, root in outputs.items()}
    for case in configs:
        configs[case]["training"].pop("device")
        configs[case]["limits"].pop("seconds")
    assert configs["CPU"] == configs["CUDA"]
    sample = {case: read(root / "sampling.json") for case, root in outputs.items()}
    assert sample["CPU"]["row_counts"] == sample["CUDA"]["row_counts"]
    assert sample["CPU"]["training_indices"] == sample["CUDA"]["training_indices"]
    assert all(sample[case]["seen"] == 65536 for case in outputs)
    assert read(outputs["CPU"] / "diagnostic-subsets.json") == read(
        outputs["CUDA"] / "diagnostic-subsets.json"
    )
    freeze = {case: read(root / "freeze.json") for case, root in outputs.items()}
    assert freeze["CPU"]["initial_weights_sha"] == freeze["CUDA"]["initial_weights_sha"]
    assert [c["step"] for c in curves["CPU"]] == [c["step"] for c in curves["CUDA"]]
    errors = {}
    for scope in ("train", "validation"):
        for field in (
            "target_mse",
            "target_game_equal_mse",
            "bias",
            "z_sign_accuracy",
            "saturation_fraction",
        ):
            errors[f"{scope}.{field}"] = max(
                abs(a[scope][field] - b[scope][field])
                for a, b in zip(curves["CPU"], curves["CUDA"])
            )
    vectors = {
        case: [
            json.loads(line)
            for line in gzip.decompress(
                (root / "observations.jsonl.gz").read_bytes()
            ).splitlines()
        ]
        for case, root in outputs.items()
    }
    group_error, missing = 0.0, 0
    for a, b in zip(vectors["CPU"], vectors["CUDA"]):
        assert a["step"] == b["step"] and a["kind"] == b["kind"]
        for scope in ("train", "validation"):
            assert a[scope]["groups"]["order_ref"] == b[scope]["groups"]["order_ref"]
            for field in a[scope]["groups"]["fields"]:
                aa = base64.b64decode(a[scope]["groups"]["fields"][field])
                bb = base64.b64decode(b[scope]["groups"]["fields"][field])
                assert len(aa) == len(bb)
                for av, bv in zip(
                    struct.unpack("<" + "f" * (len(aa) // 4), aa),
                    struct.unpack("<" + "f" * (len(bb) // 4), bb),
                ):
                    if math.isnan(av) or math.isnan(bv):
                        assert math.isnan(av) and math.isnan(bv)
                        missing += 1
                    else:
                        group_error = max(group_error, abs(av - bv))
    weights = {
        case: list(
            struct.unpack(
                "<" + "f" * ((root / "last-model/weights.f32").stat().st_size // 4),
                (root / "last-model/weights.f32").read_bytes(),
            )
        )
        for case, root in outputs.items()
    }
    difference = [a - b for a, b in zip(weights["CPU"], weights["CUDA"])]
    gpu_bg = read(HERE / "background-foundation-CUDA-r1/result.json")
    charge = max(gpu_bg["wall_seconds"], runs["CUDA"]["inclusive_command_wall"])
    gpu_accounting = {
        "schema": "new-gpu-all-attempt-authoritative-overlay-v1",
        "namespace": "frame24-new-GPU-training-3600",
        "cap_seconds": 3600,
        "attempts": [
            {
                "job_id": gpu_bg["job_id"],
                "case": "CUDA",
                "model_child_started": True,
                "background_outcome": gpu_bg["outcome"],
                "controller_exit": runs["CUDA"]["exit"],
                "controller_failed": (
                    HERE / "case-CUDA-entry-v2/failure.json"
                ).exists(),
                "controller_seconds": runs["CUDA"]["inclusive_command_wall"],
                "background_seconds": gpu_bg["wall_seconds"],
                "charged_seconds": charge,
                "all_components": "admission/init/transfer/fit/fullval/sync/export/parity/record/reap",
            }
        ],
        "consumed_seconds": charge,
        "remaining_seconds": 3600 - charge,
        "no_nested_sum": True,
        "raw_finally_ledger": "preserved, earlier partial observation not overwritten",
        "prePopen_or_controller_exception_policy": "planned GPU attempt charged max available whole span even actualGPU0; controllerfailure counted independently of childexit0",
        "old7200_unknown_lower0": "UNCHANGED",
        "new_science_from_remaining_seconds": False,
    }
    (HERE / "new-GPU-all-attempt-accounting-v1.json").write_text(
        json.dumps(gpu_accounting, indent=2) + "\n"
    )
    result = {
        "schema": "samebatch-foundation-comparison-v1",
        "task": "frame24-learning-foundation-310-v1",
        "points": [c["step"] for c in curves["CPU"]],
        "seen_each": 65536,
        "same_config_except_device_and_wallcap": True,
        "same_initial_weights": freeze["CPU"]["initial_weights_sha"],
        "same_sampling_histogram_subset_and_input_order": True,
        "sampler_sequence": "NOT_RECORDED; histogram equality alone not a sequence proof",
        "metric_maxabs": errors,
        "group_vector_f32_maxabs": group_error,
        "paired_missing_values": missing,
        "last_weight_Linf": max(map(abs, difference)),
        "last_weight_L2": math.sqrt(sum(v * v for v in difference)),
        "rowwise_prediction_maxabs": "NOT_RECORDED; no extra forward",
        "NN_total": 293864,
        "CPU_trainer_seconds": read(outputs["CPU"] / "run-status.json")["wall_seconds"],
        "CUDA_trainer_seconds": read(outputs["CUDA"] / "run-status.json")[
            "wall_seconds"
        ],
        "CPU_guard_seconds": runs["CPU"]["inclusive_command_wall"],
        "CUDA_guard_seconds": runs["CUDA"]["inclusive_command_wall"],
        "peak_RSS_CPU": runs["CPU"]["peak_RSS"],
        "peak_RSS_CUDA": runs["CUDA"]["peak_RSS"],
        "sampled_VRAM_upper_B": runs["CUDA"]["GPU_peak"],
        "VRAM_scope": runs["CUDA"]["GPU_memory_scope"],
        "conclusion": "This small model/batch128/512step single cold comparison does not support GPU time savings; not a general GPU or playing-strength conclusion",
        "whole_cost_limitations": "sequential CPU-first order/cold initialization/no repeats; phases nested, not summed",
        "NN_new_forward_model_import": 0,
        "input_bindings": {
            str(root / name): hashlib.sha256((root / name).read_bytes()).hexdigest()
            for root in outputs.values()
            for name in (
                "config.json",
                "curves.json",
                "sampling.json",
                "freeze.json",
                "last-model/weights.f32",
            )
        },
        "wall_seconds": time.monotonic() - began,
    }
    (HERE / "foundation-comparison-v1.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                "NN": 0,
                "total_measured_NN": 293864,
                "GPU_charged_s": charge,
                "metric_maxabs": errors,
                "group_maxabs": group_error,
                "wall_s": result["wall_seconds"],
            }
        )
    )


if __name__ == "__main__":
    main()
