"""Saved-only dense trajectory diagnosis; no model/framework imports or forwards."""

import base64
import gzip
import hashlib
import json
import math
from pathlib import Path
import statistics
import struct
import time

HERE = Path(__file__).resolve().parent
ASSETS = Path("/workspaces/quoridor/.worktree/assets/checkpoints")


def read(path):
    if not path.exists():
        path = path.with_suffix(path.suffix + ".gz")
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)


def vector(encoded):
    raw = base64.b64decode(encoded)
    return list(struct.unpack("<" + "f" * (len(raw) // 4), raw))


def main():
    start = time.monotonic()
    output = {
        "schema": "saved-dense-trajectory-diagnosis-v1",
        "NN_new_forward": 0,
        "cases": {},
    }
    sampling = []
    for case in ["A", "B"]:
        root = ASSETS / "frame24-learning-diagnosis" / f"case-{case}-r1"
        old = ASSETS / "frame23-native-z-lr-contrast" / f"case-{case}-r1"
        curves = read(root / "curves.json")
        freeze = read(root / "freeze.json")
        sample = read(root / "sampling.json")
        sampling.append(sample)
        assert len(curves) == 200 and curves[-1]["step"] == 4000
        assert sample["seen"] == 512000 and len(sample["training_indices"]) == 14803
        minima = {}
        for field in ["target_game_equal_mse", "target_mse"]:
            ix = min(range(len(curves)), key=lambda i: curves[i]["validation"][field])
            point = curves[ix]
            minima[field] = {
                "step": point["step"],
                "seen": point["training_seen"],
                "value": point["validation"][field],
                "adjacent_actual_steps": [
                    curves[i]["step"]
                    for i in [max(0, ix - 1), min(len(curves) - 1, ix + 1)]
                ],
            }
        assert minima["target_game_equal_mse"]["step"] == freeze["best_step"]
        oldcurves = read(old / "curves.json")
        oldmap = {point["step"]: point for point in oldcurves}
        common = [point for point in curves if point["step"] in oldmap]
        metric_max = max(
            abs(
                point["validation"]["target_game_equal_mse"]
                - oldmap[point["step"]]["validation"]["target_game_equal_mse"]
            )
            for point in common
        )
        weight_matches = {}
        for role in ["initial-model", "last-model"]:
            ma, mb = (
                read(root / role / "manifest.json"),
                read(old / role / "manifest.json"),
            )
            a, b = (
                (root / role / ma["weights"]).read_bytes(),
                (old / role / mb["weights"]).read_bytes(),
            )
            weight_matches[role] = {
                "SHA": hashlib.sha256(a).hexdigest(),
                "old_SHA": hashlib.sha256(b).hexdigest(),
                "bytes_equal": a == b,
            }
        selected = None
        with gzip.open(root / "observations.jsonl.gz", "rt") as stream:
            for line in stream:
                row = json.loads(line)
                if (
                    row["kind"] == "full_selector"
                    and row["step"] == freeze["best_step"]
                ):
                    selected = row["validation"]["groups"]
                    break
        assert selected is not None
        refs = read(root / "reference-metrics.json")
        learned = vector(selected["fields"]["target_mse"])
        distance = refs[selected["order_ref"]]["group_distance_mse_f32"]
        pairs = [
            (a, b)
            for a, b in zip(learned, distance)
            if math.isfinite(a) and math.isfinite(b)
        ]
        assert len(pairs) == 144
        diffs = [a - b for a, b in pairs]
        count = sample["row_counts"]
        train_counts = [count[i] for i in sample["training_indices"]]
        outside = [
            count[i]
            for i in range(len(count))
            if i not in set(sample["training_indices"])
        ]
        first, last = curves[0], curves[-1]
        output["cases"][case] = {
            "LR": read(root / "config.json")["optimizer"]["lr"],
            "points": len(curves),
            "minima": minima,
            "initial": {scope: first[scope] for scope in ["train", "validation"]},
            "last": {scope: last[scope] for scope in ["train", "validation"]},
            "early_recorded_steps": [p["step"] for p in curves if p["step"] <= 200],
            "full_train_steps": [
                p["step"] for p in curves if p["train_scope"] == "full_train"
            ],
            "high_frequency_train_scope": "target-blind fixed2048 subset, 420/432 families; not fullT",
            "sampling": {
                "seen": sample["seen"],
                "min": min(train_counts),
                "max": max(train_counts),
                "row_CV": statistics.pstdev(train_counts)
                / statistics.mean(train_counts),
                "validation_sample_count": sum(outside),
                "equivalent_row_passes": 512000 / 14803,
                "completed_epochs": None,
            },
            "old302_common_points": len(common),
            "common_family_MSE_maxabs": metric_max,
            "initial_final_native_bytes": weight_matches,
            "best_recorded_family_D_differences": {
                "groups": len(pairs),
                "mean_f32_delta": statistics.mean(diffs),
                "improved_groups": sum(v < 0 for v in diffs),
                "worse_groups": sum(v > 0 for v in diffs),
                "range": [min(diffs), max(diffs)],
                "interpretation": "reused selection exploratory; group f32 values, no independent evaluation CI or playing-strength claim",
            },
            "input_bindings": {
                "curves_uncompressed_SHA": hashlib.sha256(
                    gzip.decompress((root / "curves.json.gz").read_bytes())
                ).hexdigest(),
                "freeze_SHA": hashlib.sha256(
                    (root / "freeze.json").read_bytes()
                ).hexdigest(),
            },
        }
    output["same_sample_histogram_and_row_order"] = all(
        sampling[0][key] == sampling[1][key]
        for key in ["row_counts", "training_indices", "family_counts"]
    )
    output["sample_sequence"] = "NOT_RECORDED; equal histogram is not sequence proof"
    output["scientific_NN"] = 3787468
    output["competitive_causes"] = [
        "LR and finite exposure change where fitting/selection deterioration occurs; lower LR preserves later selection quality in this corpus.",
        "Representativeness, finite family diversity, teacher-to-leaf meaning, calibration/regularization and QF1 relational bias remain unresolved. No architecture or teacher intervention from this analysis.",
    ]
    output["not_measured"] = [
        "continuous optimum between observations",
        "new heldout transfer or same-wall playing strength",
        "millions of distinct input coverage",
        "batch or wider-model GPU performance",
    ]
    output["wall_seconds"] = time.monotonic() - start
    (HERE / "dense-saved-diagnosis-v1.json").write_text(
        json.dumps(output, indent=2, allow_nan=False) + "\n"
    )
    print(
        json.dumps(
            {
                "minima": {k: v["minima"] for k, v in output["cases"].items()},
                "old302_common_max": {
                    k: v["common_family_MSE_maxabs"] for k, v in output["cases"].items()
                },
                "NN": 0,
                "wall_seconds": output["wall_seconds"],
            }
        )
    )


if __name__ == "__main__":
    main()
