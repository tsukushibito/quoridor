"""Scientific figures from completed saved observations; no models or forward calls."""

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
os.environ["MPLCONFIGDIR"] = str(HERE / ".mpl-cache")
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"


def read(path):
    if not path.exists():
        path = path.with_suffix(path.suffix + ".gz")
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", nargs="+", required=True)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()
    began = time.monotonic()
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(13, 8), constrained_layout=True)
    colors = ["#2166ac", "#b2182b", "#1b7837", "#762a83"]
    bindings = {}
    for number, case in enumerate(args.cases):
        output = (
            Path(
                "/workspaces/quoridor/.worktree/assets/checkpoints/frame24-learning-diagnosis"
            )
            / f"case-{case}-r1"
        )
        curves = read(output / "curves.json")
        status = read(output / "run-status.json")
        freeze = read(output / "freeze.json")
        references = read(output / "reference-metrics.json")
        config = read(output / "config.json")
        assert status["status"] == "COMPLETED"
        xs = [c["step"] for c in curves]
        color = colors[number]
        label = f"{case}, LR={config['optimizer']['lr']:g}"
        for ax, weighting, title in [
            (axes[0, 0], "target_game_equal_mse", "Family-equal selection MSE"),
            (axes[0, 1], "target_mse", "Row-equal selection MSE"),
        ]:
            ys = [c["validation"][weighting] for c in curves]
            ax.plot(
                xs,
                ys,
                marker="o",
                markersize=3,
                linewidth=1,
                color=color,
                label=label + " full V4733",
            )
            diag = [
                (c["step"], c["train"][weighting])
                for c in curves
                if c["train_scope"] == "fixed_diagnostic_subset"
            ]
            full = [
                (c["step"], c["train"][weighting])
                for c in curves
                if c["train_scope"] == "full_train"
            ]
            if diag:
                ax.plot(
                    *zip(*diag),
                    linestyle="--",
                    marker=".",
                    linewidth=0.8,
                    color=color,
                    alpha=0.65,
                    label=case + " fixed T2048",
                )
            if full:
                ax.scatter(
                    *zip(*full),
                    marker="s",
                    facecolors="none",
                    edgecolors=color,
                    s=45,
                    label=case + " full T14803 at0/end",
                )
            if number == 0:
                baseline = references[curves[0]["validation"]["distance_ref"]][
                    "distance"
                ]
                ax.axhline(
                    baseline[weighting],
                    color="#238b45",
                    linestyle=":",
                    label="D fixed, full V",
                )
                constant_key = (
                    "constant_game_equal_mse"
                    if weighting == "target_game_equal_mse"
                    else "constant_mse"
                )
                ax.axhline(
                    baseline[constant_key],
                    color="#555555",
                    linestyle="-.",
                    label="train-only constant, full V",
                )
            if weighting == "target_game_equal_mse":
                best = next(c for c in curves if c["step"] == freeze["best_step"])
                ax.scatter(
                    [best["step"]],
                    [best["validation"][weighting]],
                    marker="*",
                    s=110,
                    color=color,
                    edgecolors="black",
                    linewidths=0.4,
                    zorder=10,
                    label=case + " best recorded",
                )
            ax.set_title(title)
            ax.set_ylabel("z MSE; lower is better")
        quality = axes[1, 0]
        quality.plot(
            xs,
            [c["validation"]["saturation_fraction"] for c in curves],
            marker="o",
            color=color,
            markersize=3,
            label=case + " V saturation",
        )
        quality.plot(
            xs,
            [c["validation"]["z_sign_accuracy"] for c in curves],
            marker=".",
            linestyle="--",
            color=color,
            alpha=0.65,
            label=case + " V sign (z0 excluded)",
        )
        quality.set_title("Validation output diagnostics")
        quality.set_ylabel("row fraction")
        quality.set_ylim(0, 1.05)
        entry_version = "v3" if case == "B" else "v2"
        job = read(HERE / f"case-{case}-entry-{entry_version}/result.json")
        timing = axes[1, 1]
        names = [
            "guardian whole",
            "trainer whole",
            "initialization",
            "update",
            "full selector",
            "logging",
        ]
        phases = status["phase_seconds_inclusive"]
        values = [
            job["inclusive_command_wall"],
            status["wall_seconds"],
            phases["initialization"],
            phases["update"],
            phases["full_selector"],
            phases["logging"],
        ]
        offset = (number - (len(args.cases) - 1) / 2) * 0.18
        timing.bar(
            [i + offset for i in range(len(names))],
            values,
            width=0.18,
            color=color,
            label=case,
        )
        timing.set_xticks(range(len(names)), names, rotation=20, ha="right")
        timing.set_ylabel("seconds; inclusive phases overlap")
        timing.set_title("Recorded cost (do not sum nested phases)")
        bindings[case] = {
            "curves_uncompressed_SHA": hashlib.sha256(
                (output / "curves.json").read_bytes()
                if (output / "curves.json").exists()
                else gzip.decompress((output / "curves.json.gz").read_bytes())
            ).hexdigest(),
            "freeze_SHA": hashlib.sha256(
                (output / "freeze.json").read_bytes()
            ).hexdigest(),
            "step": status["step"],
            "seen": status["training_seen"],
            "rows_T": 14803,
            "rows_V": 4733,
        }
    for ax in (axes[0, 0], axes[0, 1], axes[1, 0]):
        ax.set_xlabel("completed optimizer step (seen = step ×128)")
        secondary = ax.secondary_xaxis(
            "top",
            functions=(
                lambda step: step * 128 / 14803,
                lambda equivalent: equivalent * 14803 / 128,
            ),
        )
        secondary.set_xlabel("equivalent row passes — replacement sampling, not epochs")
    for ax in axes.flat:
        ax.grid(alpha=0.18)
        ax.legend(fontsize=6.5, loc="best")
    fig.suptitle(
        "Fixed-condition learning observations: actual points; lines are guides only",
        fontsize=12,
    )
    for suffix in ("png", "svg"):
        fig.savefig(HERE / f"{args.name}.{suffix}", dpi=115)
    plt.close(fig)
    proof = {
        "schema": "saved-curve-figure-v1",
        "cases": bindings,
        "NN_new_forward_modelimports": 0,
        "opened_targets": False,
        "plot_lines": "guides only; no interpolated measurements or unobserved optimum",
        "timings": "inclusive phases nested, not additive; single cold-run observations",
        "wall_seconds": time.monotonic() - began,
    }
    (HERE / f"{args.name}-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
    print(
        json.dumps(
            {
                "figures": [str(HERE / f"{args.name}.{s}") for s in ("png", "svg")],
                "wall_seconds": proof["wall_seconds"],
                "NN": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
