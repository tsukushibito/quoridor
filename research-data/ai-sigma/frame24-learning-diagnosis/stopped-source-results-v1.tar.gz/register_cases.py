"""NN0 source/input/argv registration around the single maintained trainer."""

import argparse
import ast
import copy
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--storage", required=True)
    parser.add_argument("--loaded", required=True)
    parser.add_argument("--version", default="v1", choices=["v1", "v2"])
    args = parser.parse_args()
    plan = json.loads((HERE / "fixed-input-observation-plan-v1.json").read_text())
    source_stop = (
        ROOT
        / "research-data/ai-sigma/frame24-trainer-observation/compact-source-stop-v2.json"
    )
    stop = json.loads(source_stop.read_text())
    assert (
        stop["code_writer_STOP"] and stop["modelreader_STOP"] and stop["selector_STOP"]
    )
    for binding in stop["bindings"]:
        assert sha(ROOT / binding["path"]) == binding["sha256"]
    tree = ast.parse((ROOT / "python/quoridor_training/common.py").read_text())
    defaults = next(
        n
        for n in tree.body
        if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "DEFAULTS" for t in n.targets)
    )
    resolve = next(
        n
        for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name == "resolve_config"
    )
    env = {"copy": copy, "math": math, "json": json, "Path": Path}
    exec(
        compile(
            ast.Module(body=[defaults, resolve], type_ignores=[]),
            "metadata_config",
            "exec",
        ),
        env,
    )
    configs = {}
    for case in plan["cases"]:
        p = HERE / f"config-{case}-v1.json"
        cfg = env["resolve_config"](p)
        assert (
            cfg["training"]["batch_size"] == 128
            and cfg["training"]["sampling"] == "game"
        )
        assert (
            cfg["training"]["loss_weighting"] == "row"
            and cfg["training"]["target"] == "z"
        )
        assert cfg["evaluation"]["early_stopping_patience"] == 0
        assert (
            cfg["artifacts"]["mode"] == "native"
            and not cfg["artifacts"]["save_scheduled"]
        )
        assert cfg["artifacts"]["checkpoint_steps"] == []
        configs[case] = p
    storage = Path(args.storage)
    st = json.loads(storage.read_text())
    assert st["dense_storage_item_admitted"] and st["cap_B"] == 9 * 1024**2
    asset = ROOT / ".worktree/assets/checkpoints/frame24-learning-diagnosis"
    assert asset.is_dir()
    bindings = {str(ROOT / b["path"]): b["sha256"] for b in stop["bindings"]}
    paths = [
        HERE / "run_case.py",
        HERE / "post_case.py",
        HERE / "fixed-input-observation-plan-v1.json",
        Path(plan["cache"]),
        ROOT / "python/quoridor_training/cache.py",
        ROOT / "python/quoridor_training/residual_model.py",
        ROOT / "python/quoridor_training/scaled_model.py",
        ROOT / ".worktree/assets/checkpoints/frame22-teacher-transfer-B-r1/scale.json",
        source_stop,
        ROOT
        / "research-data/ai-sigma/frame24-coordinator/observer-metadata-independent-result-v1.json",
        ROOT
        / "research-data/ai-sigma/frame24-trainer-observation/closed304-frame24-donor-v1.json",
        ROOT
        / "research-data/ai-sigma/frame23-sigma-public-z-import/frame24-recipient-binding-addendum-v1.json",
        ROOT / ".artifacts/rust-migration/target/release/nnue-diagnose",
    ]
    bindings.update({str(p): sha(p) for p in paths})
    bindings.update({str(p): sha(p) for p in configs.values()})
    helper = ROOT / "research-data/ai-sigma/frame23-independent-teachers/control-v1.py"
    python = "/home/vscode/.cache/inference/envs/quoridor-training/bin/python"
    assert Path(python).is_file()
    for allocation, cases in [("foundation", ["CPU", "CUDA"]), ("dense", ["A", "B"])]:
        reg = {
            "task": f"frame24-learning-{allocation}-310-v1",
            "schema": "learning-diagnosis-registration-v1",
            "issue": "quoridor-4lc.310",
            "owner": "codex:01a0f31d-6d15-7620-bb63-4b4f878e4746",
            "UTC": datetime.now(timezone.utc).isoformat(),
            "allocation": allocation,
            "root": str(HERE),
            "roots": [str(HERE), str(asset)],
            "python": python,
            "python_path": str(ROOT / "python"),
            "helper": str(helper),
            "helper_SHA": sha(helper),
            "post_source": str(HERE / "post_case.py"),
            "cache": plan["cache"],
            "scale": str(
                ROOT
                / ".worktree/assets/checkpoints/frame22-teacher-transfer-B-r1/scale.json"
            ),
            "initial_SHA": "ec4167ccb5042cfe937b23850a1b52d1cd9cf6c3fb1d348627bfe6cc7d023cc5",
            "registry": str(ROOT / ".artifacts/research-team/registry.json"),
            "loaded": args.loaded,
            "storage": {
                "path": str(storage),
                "SHA": sha(storage),
                "owner_forecast_accepted": True,
            },
            "science_stop": "2026-10-06T01:40:00Z",
            "source_stop": "2026-10-06T01:45:00Z",
            "RAM_guard": 1879048192,
            "data_cap_B": 9 * 1024**2,
            "NN_total_cap": 300000 if allocation == "foundation" else 3900000,
            "MAX": 2,
            "bindings": bindings,
            "native_binary": str(
                ROOT / ".artifacts/rust-migration/target/release/nnue-diagnose"
            ),
            "qualification": "STOP308 plus independent NN0 metadata; original live3PASS1ERROR/120NN preserved",
            "same_original_replacement_sampler_no_patience": True,
            "no_opened_holdout_or_method_change": True,
            "cases": {},
        }
        for i, name in enumerate(cases):
            planned = plan["cases"][name]
            output = asset / f"case-{name}-r1"
            reg["cases"][name] = {
                **planned,
                "config": str(configs[name]),
                "output": str(output),
                "cpu": 1,
                "entry_dir": str(HERE / ("case-" + name + "-entry-" + args.version)),
                "hard_seconds": 300 if name == "CUDA" else 90,
                "NN_upper": planned["total_with_parity_upper"],
                "previous": cases[i - 1] if i else None,
                "remaining_B": 7985672 - 131072 if name == "CPU" else 5 * 1024**2,
                "argv": [
                    python,
                    "-B",
                    "-m",
                    "quoridor_training.train",
                    "train",
                    "--cache",
                    plan["cache"],
                    "--output",
                    str(output),
                    "--config",
                    str(configs[name]),
                    "--scale",
                    reg["scale"],
                ],
            }
            job = {
                "issue": "quoridor-4lc.310",
                "goal_issue": "quoridor-4lc",
                "registry": reg["registry"],
                "role": "experiment",
                "cwd": str(ROOT),
                "argv": [
                    "/usr/bin/taskset",
                    "-c",
                    "1",
                    "/usr/bin/python3",
                    "-B",
                    str(HERE / "run_case.py"),
                    "--registration",
                    str(HERE / f"registration-{allocation}-{args.version}.json"),
                    "--case",
                    name,
                ],
                "end_at": reg["science_stop"],
                "notify_until": "2026-10-06T01:50:00Z",
                "max_runtime_seconds": reg["cases"][name]["hard_seconds"] + 10,
                "control_interval_seconds": 30,
                "notify_interval_seconds": 10,
                "request_timeout_seconds": 25,
                "log_max_bytes": 8192,
                "resource_contract": str(
                    ROOT
                    / "research-data/ai-sigma/frame24-coordinator/saved-learning-analysis-and-dense-observation-contract.md"
                ),
            }
            save(f"job-{name}-{args.version}.json", job)
        save(f"registration-{allocation}-{args.version}.json", reg)
    print(
        json.dumps(
            {
                "registered": ["CPU", "CUDA", "A", "B"],
                "NN": 0,
                "model_import": False,
                "storage_SHA": sha(storage),
                "source_STOP_SHA": sha(source_stop),
            }
        )
    )


if __name__ == "__main__":
    main()
