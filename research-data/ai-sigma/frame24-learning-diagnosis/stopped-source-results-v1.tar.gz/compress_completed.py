"""Lossless completed own JSON compaction after scientific readers have stopped."""

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
ASSETS = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/frame24-learning-diagnosis"
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", nargs="+", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--entry-version", default="v2")
    args = parser.parse_args()
    begin = time.monotonic()
    proofs = []
    for case in args.cases:
        receipt = HERE / f"case-{case}-entry-{args.entry_version}/result.json"
        result = json.loads(receipt.read_text())
        assert (
            result["waited"]
            and not result["current_exact"]
            and not result["current_pgrp"]
        )
        output = ASSETS / f"case-{case}-r1"
        for name in (
            "sampling.json",
            "curves.json",
            "diagnostic-curves.json",
            "measurement-sets.json",
            "reference-metrics.json",
        ):
            original = output / name
            if not original.exists():
                continue
            raw = original.read_bytes()
            json.loads(raw)
            packed = original.with_suffix(original.suffix + ".gz")
            assert not packed.exists(), "do not overwrite retained compression"
            compressed = gzip.compress(raw, compresslevel=6, mtime=0)
            packed.write_bytes(compressed)
            assert gzip.decompress(packed.read_bytes()) == raw
            proofs.append(
                {
                    "original_path": str(original),
                    "compressed_path": str(packed),
                    "original_B": len(raw),
                    "compressed_B": len(compressed),
                    "uncompressed_SHA": hashlib.sha256(raw).hexdigest(),
                    "compressed_SHA": hashlib.sha256(compressed).hexdigest(),
                    "restore_PASS": True,
                    "reader_STOP_receipt": str(receipt),
                    "reader_STOP_SHA": hashlib.sha256(receipt.read_bytes()).hexdigest(),
                    "models_nativeweights_inputcache_raw_archives": "unchanged",
                }
            )
            original.unlink()
    record = {
        "schema": "completed-own-JSON-lossless-compression-v1",
        "proofs": proofs,
        "NN_new_model_forward": 0,
        "wall_seconds": time.monotonic() - begin,
    }
    (HERE / f"{args.name}.json").write_text(json.dumps(record, indent=2) + "\n")
    print(
        json.dumps(
            {
                "restored_files": len(proofs),
                "raw_B": sum(p["original_B"] for p in proofs),
                "compressed_B": sum(p["compressed_B"] for p in proofs),
                "NN": 0,
                "wall_seconds": record["wall_seconds"],
            }
        )
    )


if __name__ == "__main__":
    main()
