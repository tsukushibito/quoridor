"""Counted finite exported-weight parity and saved metadata collection."""

import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess

os.environ["ORT_DISABLE_TELEMETRY"] = "1"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", required=True)
    parser.add_argument("--case", required=True)
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    case = reg["cases"][args.case]
    output = Path(case["output"])
    run = Path(case["entry_dir"])
    freeze = json.loads((output / "freeze.json").read_text())
    status = json.loads((output / "run-status.json").read_text())
    sample = json.loads((output / "sampling.json").read_text())
    assert freeze["initial_weights_sha"] == reg["initial_SHA"]
    assert status["step"] == case["steps"] and sample["seen"] == case["steps"] * 128
    assert freeze["evaluation_checkpoints"] == case["points"]
    assert freeze["samples"] <= case["fit_NN_upper"]
    native_config = {
        "mode": "diagnose",
        "output": str(run / "native-parity.json"),
        "counter": str(run / "native-parity-counter.json"),
        "prefixes": [[], [13]],
        "engines": [
            {
                "id": args.case,
                "kind": "distance_residual",
                "manifest": str(output / "best-model/manifest.json"),
            }
        ],
        "depths": [],
        "max_nodes": 500,
        "nn_cap": 120,
        "processed_cap": 1000,
        "wall_seconds": 5.0,
        "max_plies": 200,
        "cpu_core": case["cpu"],
        "ram_limit": reg["RAM_guard"],
        "host_ram_reserve": 1073741824,
    }
    cfgpath = run / "native-parity-config.json"
    cfgpath.write_text(json.dumps(native_config, indent=2) + "\n")
    spec = importlib.util.spec_from_file_location(
        "readonly_parity_process_helper", reg["helper"]
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    native_process = subprocess.Popen(
        [reg["native_binary"], "--config", str(cfgpath)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    native_identity = helper.proc(native_process.pid)
    try:
        stdout, stderr = native_process.communicate(timeout=7)
    except BaseException:
        native_process.kill()
        native_process.wait()
        raise
    finally:
        helper.write(
            run / "native-child-wait.json",
            {
                "identity": native_identity,
                "exit": native_process.returncode,
                "waited": native_process.returncode is not None,
                "current_exact": helper.exact(native_identity)
                if native_identity
                else "UNKNOWN",
            },
        )
    (run / "native-parity-stdout.log").write_text(stdout)
    (run / "native-parity-stderr.log").write_text(stderr)
    assert native_identity is not None and not helper.exact(native_identity)
    assert native_process.returncode == 0, "finite native witness; no retry"
    native = json.loads((run / "native-parity.json").read_text())
    assert native["schema"] == "native-nnue-diagnosis-v1" and not native["searches"]
    assert native["parent_history_preserved"]
    import numpy as np
    import torch
    from quoridor_training.train import build_model

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    saved = torch.load(output / "best.pt", map_location="cpu", weights_only=True)
    model = build_model(saved["model_config"], saved["scale"])
    model.load_state_dict(saved["model"])
    model.eval()
    checked, maxabs, sides = 0, 0.0, set()
    for row in native["predictions"]:
        if "values" not in row:
            continue
        feature = row["feature"]
        x = np.zeros((1, 2, 312), dtype=np.float32)
        for side, ids in enumerate(feature["ids"]):
            x[0, side, ids] = 1.0
        with torch.inference_mode():
            value = float(
                model(
                    torch.from_numpy(x),
                    torch.tensor([feature["distance"]], dtype=torch.float32),
                    torch.tensor([feature["side"] + 1], dtype=torch.long),
                )[0]
            )
        error = abs(value - row["values"][0]["value"])
        assert error <= 1e-5 + 1e-4 * abs(value), "exported value finite parity"
        sides.add(feature["side"])
        maxabs = max(maxabs, error)
        checked += 1
    assert checked == 2 and sides == {0, 1}
    parity = native["NN"] + checked
    assert parity <= 500
    result = {
        "task": reg["task"],
        "schema": "dense-learning-case-parity-v1",
        "case": args.case,
        "status": "FINITE_FIT_AND_PARITY",
        "fit_NN": status["samples"],
        "native_NN": native["NN"],
        "Torch_NN": checked,
        "total_NN": status["samples"] + parity,
        "parity_maxabs": maxabs,
        "native_parent_preserved": True,
        "seen": sample["seen"],
        "selected_exposure": freeze["selected_exposure"],
        "phase_seconds_inclusive": status["phase_seconds_inclusive"],
        "extra_validation_forward": 0,
        "opened_evaluation_targets": False,
    }
    (run / "case-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {"case": args.case, "total_NN": result["total_NN"], "parity_maxabs": maxabs}
        )
    )


if __name__ == "__main__":
    main()
