"""Finite task entry around the canonical trainer; no training implementation."""

import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", required=True)
    parser.add_argument("--case", required=True)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    regpath = Path(args.registration)
    reg = json.loads(regpath.read_text())
    case = reg["cases"][args.case]
    spec = importlib.util.spec_from_file_location(
        "readonly_process_helper", reg["helper"]
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    assert reg["issue"] == "quoridor-4lc.310"
    assert reg["schema"] == "learning-diagnosis-registration-v1"
    assert reg["allocation"] in ("dense", "foundation")
    assert reg["NN_total_cap"] <= (3900000 if reg["allocation"] == "dense" else 300000)
    assert case["hard_seconds"] <= (300 if case["device"] == "cuda" else 90)
    expected = [
        reg["python"],
        "-B",
        "-m",
        "quoridor_training.train",
        "train",
        "--cache",
        reg["cache"],
        "--output",
        case["output"],
        "--config",
        case["config"],
        "--scale",
        reg["scale"],
    ]
    assert case["argv"] == expected, "canonical CLI/mandatory arguments"
    assert helper.sha(reg["helper"]) == reg["helper_SHA"]
    for path, digest in reg["bindings"].items():
        assert helper.sha(path) == digest, "input/source mutation:" + path
    loaded_fixture = helper.read(reg["loaded"])
    operation_fixture = helper.read(reg["registry"])["current_operation"]
    assert operation_fixture["frame"] == 24
    assert loaded_fixture["checks"]["running"]
    assert loaded_fixture["checks"]["current24_hash"]
    assert loaded_fixture["checks"]["current6_digest"]
    assert (
        loaded_fixture["new_GPU_authority"]["namespace"]
        == "frame24-new-GPU-training-3600"
    )
    assert all(
        k in loaded_fixture
        for k in ("scheduler", "monitor", "config_SHA", "contract_SHA")
    )
    if args.check:
        print(
            json.dumps(
                {
                    "task": reg["task"],
                    "case": args.case,
                    "schema": reg["schema"],
                    "argv_bound": True,
                    "NN": 0,
                    "model_import": False,
                }
            )
        )
        return
    root = Path(reg["root"])
    run = Path(case["entry_dir"])
    for prior in root.glob("case-" + args.case + "-entry-*/result.json"):
        assert not helper.read(prior)["model_child_started"], (
            "case already started; no scientific retry"
        )
    assert not run.exists(), "preserve all attempts/no directory reuse"
    assert not Path(case["output"]).exists(), "output collision"
    assert Path(case["output"]).parent.is_dir(), "output parent before framework import"
    deadline = datetime.fromisoformat(reg["science_stop"].replace("Z", "+00:00"))
    assert (deadline - datetime.now(timezone.utc)).total_seconds() >= case[
        "hard_seconds"
    ] + 5
    if case.get("previous"):
        prev = helper.read(
            Path(reg["cases"][case["previous"]]["entry_dir"]) / "result.json"
        )
        assert prev["waited"] and not prev["current_exact"] and not prev["current_pgrp"]
    os.sched_setaffinity(0, {case["cpu"]})
    run.mkdir()

    def interrupted(signum, frame):
        raise InterruptedError("owned guardian signal " + str(signum))

    signal.signal(signal.SIGTERM, interrupted)
    child, identity, reason = None, None, None
    recorded, peak, gpu_peak = {}, 0, 0
    begin = time.monotonic()
    try:
        for issue in (reg["issue"], "quoridor-4lc"):
            answer = subprocess.run(
                [
                    "bash",
                    "/workspaces/quoridor/scripts/dev/beads.sh",
                    "show",
                    issue,
                    "--json",
                ],
                capture_output=True,
                text=True,
                timeout=10,
                check=True,
            )
            item = json.loads(answer.stdout)[0]
            assert item["status"] == "in_progress"
            assert not any("pause" in label for label in item.get("labels", []))
            if issue == reg["issue"]:
                assert item["assignee"] == reg["owner"]
        operation = helper.read(reg["registry"])["current_operation"]
        loaded = helper.read(reg["loaded"])
        state = helper.read(Path(operation["state_dir"]) / "state.json")
        expected_hashes = helper.read(operation["expectations_path"])["input_hashes"]
        assert operation["frame"] == 24 and loaded["checks"]["running"]
        assert state["phase"] == "running"
        assert state["process"]["pid"] == loaded["scheduler"]["pid"]
        assert str(state["process"]["start_ticks"]) == str(
            loaded["scheduler"]["start_ticks"]
        )
        assert all(helper.exact(loaded[k]) for k in ("scheduler", "monitor"))
        six_digest = loaded.get("six_digest_current")
        assert (
            all(six_digest.values())
            if six_digest
            else loaded["checks"]["current6_digest"]
        )
        config_sha = loaded.get("loaded_config_sha", loaded.get("config_SHA"))
        contract_sha = loaded.get("loaded_contract_sha", loaded.get("contract_SHA"))
        assert state["config_sha256"] == config_sha
        assert state["contract_sha256"] == contract_sha
        assert helper.sha(operation["config_path"]) == config_sha
        assert helper.sha(state["binding"]["contract_file"]) == contract_sha
        assert len(expected_hashes) == 24
        for path, digest in expected_hashes.items():
            assert helper.sha(path) == digest, "current24:" + path
        storage = helper.read(reg["storage"]["path"])
        assert helper.sha(reg["storage"]["path"]) == reg["storage"]["SHA"]
        assert (
            not storage.get("errors", []) and reg["storage"]["owner_forecast_accepted"]
        )
        assert (
            storage["dense_storage_item_admitted"]
            and storage["cap_B"] == reg["data_cap_B"]
        )
        ps = helper.snapshot()
        own = helper.ancestors(os.getpid(), ps)

        def compute(p):
            return helper.science(p) or any(
                "quoridor_training" in a or Path(a).name.startswith("test_")
                for a in p["argv"][1:]
            )

        time.sleep(0.15)
        ps = helper.snapshot()
        foreign = [p for p in ps if p["pid"] not in own and compute(p)]
        assert not foreign, "actual foreign computation"
        gpu = helper.gpu_state()
        assert not gpu, "foreign GPU process"
        available = next(
            int(line.split()[1]) * 1024
            for line in Path("/proc/meminfo").read_text().splitlines()
            if line.startswith("MemAvailable:")
        )
        assert available >= reg["RAM_guard"]
        actual = sum(
            p.stat().st_blocks * 512
            for d in reg["roots"]
            for p in Path(d).rglob("*")
            if p.is_file()
        )
        assert actual + case["remaining_B"] <= reg["data_cap_B"], (
            "inclusive output forecast"
        )
        helper.write(
            run / "admission.json",
            {
                "UTC": datetime.now(timezone.utc).isoformat(),
                "scheduler": loaded["scheduler"],
                "monitor": loaded["monitor"],
                "current24": 24,
                "six_digest": six_digest or loaded["checks"]["current6_digest"],
                "owned": state["owned"],
                "foreign": foreign,
                "GPU": gpu,
                "available": available,
                "current_B": actual,
                "remaining_B": case["remaining_B"],
                "CPU": [case["cpu"]],
                "registration_SHA": helper.sha(regpath),
                "future_free": False,
            },
        )
        env = dict(
            os.environ,
            PYTHONPATH=reg["python_path"],
            ORT_DISABLE_TELEMETRY="1",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
            CUBLAS_WORKSPACE_CONFIG=":4096:8",
            NVIDIA_TF32_OVERRIDE="0",
        )
        started = time.monotonic()

        def run_phase(argv, phase):
            nonlocal child, identity, reason, peak, gpu_peak
            log = (run / (phase + ".log")).open("wb")
            child = subprocess.Popen(
                argv,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            identity = helper.proc(child.pid)
            assert identity is not None
            recorded[(identity["pid"], identity["start_ticks"])] = identity
            helper.write(
                run / (phase + "-process.json"),
                {
                    "identity": identity,
                    "argv": argv,
                    "UTC": datetime.now(timezone.utc).isoformat(),
                    "NN_reserved": case["NN_upper"],
                },
            )
            while child.poll() is None:
                ps = helper.snapshot()
                family = [p for p in ps if p["pgrp"] == child.pid]
                recorded.update({(p["pid"], p["start_ticks"]): p for p in family})
                peak = max(
                    peak,
                    helper.proc(os.getpid())["rss"] + sum(p["rss"] for p in family),
                )
                if peak > reg["RAM_guard"] or any(
                    p["cpus"] != [case["cpu"]] for p in family
                ):
                    reason = "RAM_OR_CPU_GUARD"
                if any(
                    p["pid"] not in own and p["pgrp"] != child.pid and compute(p)
                    for p in ps
                ):
                    reason = "FOREIGN_COMPUTE_STARTED"
                if time.monotonic() - started >= case["hard_seconds"]:
                    reason = "HARD_TIMEOUT"
                allocated = sum(
                    p.stat().st_blocks * 512
                    for d in reg["roots"]
                    for p in Path(d).rglob("*")
                    if p.is_file()
                )
                if allocated > reg["data_cap_B"]:
                    reason = "ACTUAL_STORAGE_GUARD"
                if case["device"] == "cuda" and int(
                    time.monotonic() - started
                ) != getattr(run_phase, "gpu_second", -1):
                    apps = helper.gpu_state()
                    own_gpu = {p["pid"] for p in family}
                    if any(app["pid"] not in own_gpu for app in apps):
                        reason = "FOREIGN_GPU_STARTED"
                    gpu_peak = max(gpu_peak, sum(app["bytes"] for app in apps))
                    if gpu_peak > 6 * 1024**3:
                        reason = "VRAM_GUARD"
                    helper.write(
                        run / "GPU-current.json",
                        {
                            "elapsed": time.monotonic() - started,
                            "apps": apps,
                            "peak_upper_B": gpu_peak,
                        },
                    )
                    run_phase.gpu_second = int(time.monotonic() - started)
                if reason:
                    break
                time.sleep(0.1)
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=3)
            log.close()
            helper.write(
                run / (phase + "-wait.json"),
                {
                    "exit": child.returncode,
                    "waited": True,
                    "current_exact": [p for p in recorded.values() if helper.exact(p)],
                    "phase": phase,
                    "wall_since_first_child": time.monotonic() - started,
                },
            )
            return child.returncode == 0 and reason is None

        fit_complete = run_phase(case["argv"], "fit")
        if fit_complete:
            for path, digest in reg["bindings"].items():
                assert helper.sha(path) == digest, "source changed before saved parity"
            fit_complete = run_phase(
                [
                    reg["python"],
                    "-B",
                    reg["post_source"],
                    "--registration",
                    str(regpath),
                    "--case",
                    args.case,
                ],
                "saved-parity",
            )
        status_path = Path(case["output"]) / "run-status.json"
        status = helper.read(status_path) if status_path.exists() else None
        freeze_path = Path(case["output"]) / "freeze.json"
        freeze = helper.read(freeze_path) if freeze_path.exists() else None
        success = (
            fit_complete
            and reason is None
            and status is not None
            and freeze is not None
        )
        if success:
            assert (
                status["step"] == case["steps"]
                and status["training_seen"] == case["steps"] * 128
            )
            assert freeze["initial_weights_sha"] == reg["initial_SHA"]
            assert freeze["evaluation_checkpoints"] == case["points"]
            assert freeze["samples"] <= case["fit_NN_upper"]
            parity = helper.read(run / "case-result.json")
            assert parity["total_NN"] <= case["NN_upper"]
            assert status["completed_epochs"] is None, (
                "replacement is not an epoch sampler"
            )
        helper.write(
            run / "scientific-result.json",
            {
                "task": reg["task"],
                "schema": "dense-learning-case-v1",
                "case": args.case,
                "purpose_complete": success,
                "status": status,
                "freeze": freeze,
                "NN": parity["total_NN"]
                if success
                else (status["samples"] if status else "UNKNOWN"),
                "unknown_upper": case["NN_upper"],
                "extra_science": False,
            },
        )
    except BaseException as error:
        helper.write(
            run / "failure.json",
            {
                "error": repr(error),
                "model_child_started": child is not None,
                "NN": "UNKNOWN" if child else 0,
                "upper": case["NN_upper"] if child else 0,
            },
        )
        raise
    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        exact = [p for p in recorded.values() if helper.exact(p)]
        group = [p for p in helper.snapshot() if child and p["pgrp"] == child.pid]
        helper.write(
            run / "result.json",
            {
                "task": reg["task"],
                "case": args.case,
                "waited": child is not None,
                "model_child_started": child is not None,
                "exit": child.returncode if child else None,
                "reason": reason,
                "current_exact": exact,
                "current_pgrp": group,
                "recorded": list(recorded.values()),
                "peak_RSS": peak,
                "GPU_peak": gpu_peak,
                "GPU_memory_scope": "per-process sample or whole-device conservative upper, see GPU-current.json",
                "inclusive_command_wall": time.monotonic() - begin,
            },
        )
        assert not exact and not group, "owned child recovery incomplete"
        if case["device"] == "cuda" and child is not None:
            ledger = root / "new-GPU-3600-attempt-ledger.jsonl"
            with ledger.open("a") as stream:
                stream.write(
                    json.dumps(
                        {
                            "namespace": "frame24-new-GPU-training-3600",
                            "case": args.case,
                            "identity": identity,
                            "inclusive_elapsed_seconds": time.monotonic() - begin,
                            "components": "admission/init/transfer/fit/eval/sync/export/parity/record/wait; nested timings not additive",
                            "new_cap_seconds": 3600,
                            "old7200_UNKNOWN": "UNCHANGED",
                            "failed_attempt_included": reason is not None
                            or child.returncode != 0,
                        }
                    )
                    + "\n"
                )
    raise SystemExit(0 if success else 1)


if __name__ == "__main__":
    main()
