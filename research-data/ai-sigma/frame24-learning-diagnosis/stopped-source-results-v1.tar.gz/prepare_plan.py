"""Register fixed observation schedules and target-blind input subsets without models."""

import gzip
import hashlib
import json
import math
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def main():
    old = ROOT / ".worktree/assets/checkpoints/frame23-native-z-lr-contrast/case-A-r1"
    baseline = json.loads((old / "config.json").read_text())
    cache = (
        ROOT
        / "research-data/ai-sigma/frame23-native-outcome-z-learning/sharded-cache-v1.json"
    )
    manifest = json.loads(cache.read_text())
    row_ids = [
        f"{s['namespace']}:{r['id']}" for s in manifest["shards"] for r in s["rows"]
    ]
    train = json.loads(gzip.decompress((old / "train-order.json.gz").read_bytes()))
    validation = json.loads(
        gzip.decompress((old / "validation-order.json.gz").read_bytes())
    )
    assert len(train) == 14803 and len(validation) == 4733
    assert not set(train) & set(validation)
    positions = {value: i for i, value in enumerate(row_ids)}
    indices = [positions[value] for value in train]
    ranked = sorted(
        indices,
        key=lambda i: (hashlib.sha256(f"19080311:{row_ids[i]}".encode()).digest(), i),
    )
    subset = sorted(ranked[:2048])
    subset_SHA = hashlib.sha256(
        json.dumps(subset, separators=(",", ":")).encode()
    ).hexdigest()
    dense = sorted(
        {0, 1, 2, 5, 10, 20}
        | set(range(25, 4001, 25))
        | {math.ceil(k * 14803 / 128) for k in range(1, 512000 // 14803 + 1)}
    )
    assert len(dense) == 200 and dense[-1] == 4000
    foundation = [0, 1, 2, 5, 10, 20, 50, 100, 200, 300, 400, 512]
    cases = {}
    for name, rate, steps, device, points in [
        ("A", 1e-4, 4000, "cpu", dense),
        ("B", 3e-5, 4000, "cpu", dense),
        ("CPU", 1e-4, 512, "cpu", foundation),
        ("CUDA", 1e-4, 512, "cuda", foundation),
    ]:
        config = json.loads(json.dumps(baseline))
        config["optimizer"]["lr"] = rate
        config["training"].update(steps=steps, device=device, loss_weighting="row")
        config["evaluation"].update(
            checkpoints=points,
            full_train=False,
            diagnostic_rows=2048,
            diagnostic_checkpoints=[0, 4000] if steps == 4000 else [],
            full_train_checkpoints=[0, 4000] if steps == 4000 else [],
            early_stopping_patience=0,
        )
        config["artifacts"].update(
            mode="native", save_scheduled=False, checkpoint_steps=[]
        )
        fit_upper = (
            steps * 128 + len(points) * (2048 + 4733) + (29606 if steps == 4000 else 0)
        )
        config["limits"] = {
            "seconds": 82.0 if device == "cpu" else 285.0,
            "samples": fit_upper,
        }
        save(f"config-{name}-v1.json", config)
        cases[name] = {
            "LR": rate,
            "steps": steps,
            "seen": steps * 128,
            "device": device,
            "points": points,
            "fit_NN_upper": fit_upper,
            "total_with_parity_upper": fit_upper + 500,
        }
    assert (
        cases["A"]["total_with_parity_upper"] + cases["B"]["total_with_parity_upper"]
        == 3796612
    )
    assert (
        cases["CPU"]["total_with_parity_upper"]
        + cases["CUDA"]["total_with_parity_upper"]
        == 294816
    )
    save(
        "fixed-input-observation-plan-v1.json",
        {
            "task": "frame24-learning-diagnosis-310-v1",
            "schema": "fixed-observation-input-plan-v1",
            "cases": cases,
            "cache": str(cache),
            "cache_SHA": sha(cache),
            "global_rows": len(row_ids),
            "train_rows": len(train),
            "validation_rows": len(validation),
            "train_order_uncompressed_SHA": hashlib.sha256(
                gzip.decompress((old / "train-order.json.gz").read_bytes())
            ).hexdigest(),
            "validation_order_uncompressed_SHA": hashlib.sha256(
                gzip.decompress((old / "validation-order.json.gz").read_bytes())
            ).hexdigest(),
            "diagnostic_indices": subset,
            "diagnostic_compact_indices_SHA": subset_SHA,
            "subset_selection": "SHA256(seed:immutable-cache-row-id), index tie, indices sorted",
            "target_read_for_selection": False,
            "full_train_initial_final": "charged; saved exact reuse only separately proved",
            "source_version": "prospective; no model until qualified STOP308/current bindings",
            "NN_MAX_model_import": 0,
        },
    )
    print(
        json.dumps(
            {
                "dense_points": len(dense),
                "dense_upper": 3796612,
                "foundation_upper": 294816,
                "model_import": False,
            }
        )
    )


if __name__ == "__main__":
    main()
