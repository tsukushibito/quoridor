//! Generic fixed-root MCTS budget sensitivity. No game generation or seed variance.
use quoridor_ai::sigma_mcts::{Limits, Progress, Search};
use quoridor_core::research::{SigmaContext, features};
use quoridor_data::{Result, Teacher, TeacherRow, read_dataset};
use quoridor_inference::{InferenceBackend, NetworkOutput, OrtBackend, TensorRtBackend};
use serde::Deserialize;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{fs::File, path::PathBuf, time::Instant};

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Root {
    id: String,
    group: String,
    phase: String,
    split: String,
    ply: u16,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Config {
    task: String,
    schema: String,
    mode: String,
    dataset: PathBuf,
    output: PathBuf,
    model: PathBuf,
    library: PathBuf,
    engine: PathBuf,
    model_sha: String,
    roots: Vec<Root>,
    ks: Vec<u32>,
    nn_cap: usize,
    allocated_cap: usize,
}
fn main() {
    unsafe {
        std::env::set_var("ORT_DISABLE_TELEMETRY", "1");
    }
    if let Err(e) = run() {
        eprintln!("{e}");
        std::process::exit(1);
    }
}
fn replay(r: &TeacherRow) -> Result<SigmaContext> {
    let c = SigmaContext::from_prefix(&r.prefix).map_err(|e| format!("{e:?}"))?;
    let check = TeacherRow::from_context(
        r.id.clone(),
        r.game.clone(),
        r.family.clone(),
        r.split.clone(),
        r.prefix.clone(),
        &c,
        None,
        Teacher::InputOnly,
        r.model_sha.clone(),
    )?;
    if check.state_key != r.state_key
        || check.history_key != r.history_key
        || check.ids != r.ids
        || check.distance.map(f32::to_bits) != r.distance.map(f32::to_bits)
        || check.side != r.side
        || check.ply != r.ply
        || check.feature_signature != r.feature_signature
    {
        return Err("REPLAY_INPUT_HISTORY_MISMATCH".into());
    }
    if c.terminal_value().is_some() {
        return Err("TERMINAL_REGISTERED_ROOT".into());
    }
    Ok(c)
}
fn search(
    c: &SigmaContext,
    backend: &mut dyn InferenceBackend,
    k: u32,
    calls: &mut usize,
    cap: usize,
) -> Result<Value> {
    let start = Instant::now();
    let mut s = Search::with_limits(
        c.clone(),
        1,
        k,
        Limits {
            max_nodes: 250000,
            max_depth: 200,
            max_bytes: 512 * 1024 * 1024,
        },
    )
    .map_err(|e| format!("{e:?}"))?;
    let mut advances = 0usize;
    let mut first = None;
    let mut fault = None;
    loop {
        if *calls >= cap {
            fault = Some("NN_CAP".to_string());
            break;
        }
        advances += 1;
        match s.advance() {
            Ok(Progress::Advanced) => (),
            Ok(Progress::Complete) => break,
            Ok(Progress::NeedInference { token, features }) => {
                let NetworkOutput { logits, value } = backend.infer(&[*features])?.remove(0);
                *calls += 1;
                if first.is_none() {
                    first = Some(value);
                }
                s.supply(token, &logits, value)
                    .map_err(|e| format!("{e:?}"))?;
            }
            Err(e) => {
                fault = Some(e);
                break;
            }
        }
    }
    let v = s.snapshot();
    let legal = c.legal_ids();
    let complete =
        fault.is_none() && v.root_visits == k && v.action.is_some_and(|a| legal.contains(&a));
    let edges:Vec<_>=v.edges.iter().map(|e|json!({"action":e.action,"prior":e.prior,"visits":e.visits,"value_sum":e.value_sum})).collect();
    if !v.root_mean.is_finite() {
        return Err("NONFINITE_MEAN".into());
    }
    Ok(
        json!({"K":k,"status":if complete {"COMPLETE"}else{"CENSORED"},"fault":fault,"action":v.action,"rootmean":v.root_mean,"root_nn":first,"root_visits":v.root_visits,"logical_NN":v.nn_calls,"terminal_no_NN":v.terminal_no_nn,"allocated_nodes":v.nodes,"max_depth":v.max_depth,"advance_invocations_not_processed_nodes":advances,"terminal_origin":v.terminal_value,"legal":legal,"edges":edges,"seconds":start.elapsed().as_secs_f64(),"generation":1,"generation_is_not_seed":true}),
    )
}
fn run() -> Result<()> {
    let cfg: Config = serde_json::from_reader(File::open(
        std::env::args().nth(1).ok_or("config required")?,
    )?)?;
    if cfg.output.exists()
        || !matches!(cfg.mode.as_str(), "prepare" | "qualify" | "measure")
        || cfg.roots.len() > 36
        || cfg.ks.iter().any(|k| !matches!(k, 64 | 256 | 1024))
    {
        return Err("INVALID_CONFIG_OR_EXISTING_OUTPUT".into());
    }
    let start = Instant::now();
    let rows = read_dataset(&cfg.dataset, false)?;
    let mut inputs = Vec::new();
    for root in &cfg.roots {
        let r = rows
            .iter()
            .find(|r| r.id == root.id)
            .ok_or("REGISTERED_ROOT_MISSING")?;
        if r.family != root.group
            || r.ply != root.ply
            || !r.eligible
            || format!("{:?}", r.split).to_lowercase() != root.split
        {
            return Err("ROOT_IDENTITY_SPLIT".into());
        }
        inputs.push((r, replay(r)?));
    }
    let replay_s = start.elapsed().as_secs_f64();
    let input_records: Vec<_> = inputs.iter().map(|(r,_)|json!({"id":r.id,"group":r.family,"ply":r.ply,"side":r.side,"prefix":r.prefix,"prefix_SHA":format!("{:x}",Sha256::digest(serde_json::to_vec(&r.prefix).unwrap())),"state_key":r.state_key,"history_key":r.history_key,"ids":r.ids,"distance":r.distance,"feature_signature":r.feature_signature,"replay":"PASS"})).collect();
    if cfg.mode == "prepare" {
        serde_json::to_writer_pretty(
            File::create(cfg.output)?,
            &json!({"task":cfg.task,"schema":cfg.schema,"mode":cfg.mode,"records":input_records,"NN":0,"replay_seconds":replay_s}),
        )?;
        return Ok(());
    }
    let backend_start = Instant::now();
    let mut gpu = TensorRtBackend::new(&cfg.engine, &cfg.model_sha, 8, 0, true)?;
    let mut calls = 0usize;
    let mut cpu_calls = 0usize;
    let warm_nn = 36usize;
    let init_s = backend_start.elapsed().as_secs_f64();
    let mut records = Vec::new();
    let mut allocated = 0usize;
    if cfg.mode == "qualify" {
        if inputs.len() > 2 {
            return Err("QUALIFICATION_MAX_TWO_ROOT".into());
        }
        let mut cpu = OrtBackend::new(&cfg.model, &cfg.library, &cfg.model_sha)?;
        for (r, c) in &inputs {
            let input = features(c.position());
            let a = cpu.infer(&[input])?.remove(0);
            let b = gpu.infer(&[input])?.remove(0);
            cpu_calls += 1;
            calls += 1;
            let mut maxabs = 0f32;
            for (x, y) in a
                .logits
                .iter()
                .chain([&a.value])
                .zip(b.logits.iter().chain([&b.value]))
            {
                maxabs = maxabs.max((x - y).abs());
                if !x.is_finite() || !y.is_finite() || (x - y).abs() > 1e-4 + 1e-4 * x.abs() {
                    return Err("CPU_GPU_FINITE_PARITY".into());
                }
            }
            let a = search(c, &mut cpu, 64, &mut cpu_calls, cfg.nn_cap - warm_nn)?;
            let b = search(
                c,
                &mut gpu,
                64,
                &mut calls,
                cfg.nn_cap - warm_nn - cpu_calls,
            )?;
            if a["status"] != "COMPLETE" || b["status"] != "COMPLETE" {
                return Err("QUALIFICATION_SEARCH_INCOMPLETE".into());
            }
            allocated += a["allocated_nodes"].as_u64().unwrap() as usize
                + b["allocated_nodes"].as_u64().unwrap() as usize;
            records.push(json!({"id":r.id,"prefix":r.prefix,"side":r.side,"input_history_replay":"PASS","maxabs":maxabs,"cpu":a,"gpu":b}));
        }
    } else {
        for (index, ((r, c), root)) in inputs.iter().zip(&cfg.roots).enumerate() {
            for j in 0..cfg.ks.len() {
                let k = cfg.ks[(index + j) % cfg.ks.len()];
                if allocated >= cfg.allocated_cap {
                    records.push(json!({"id":r.id,"K":k,"status":"NOT_STARTED_ALLOCATED_CAP"}));
                    continue;
                }
                let result = search(c, &mut gpu, k, &mut calls, cfg.nn_cap - warm_nn)?;
                allocated += result["allocated_nodes"].as_u64().unwrap() as usize;
                let d = (8.0f32 * (r.distance[1] - r.distance[0])).tanh();
                records.push(json!({"id":r.id,"group":r.family,"phase":root.phase,"split":root.split,"ply":r.ply,"prefix":r.prefix,"state_key":r.state_key,"history_key":r.history_key,"feature_signature":r.feature_signature,"side":r.side,"distance":r.distance,"D0_8":d,"saved_teacher":r.teacher,"result":result}));
                serde_json::to_writer(
                    File::create(cfg.output.with_extension("partial.json"))?,
                    &json!({"task":cfg.task,"schema":cfg.schema,"partial":true,"records":records,"logical_NN":calls,"warm_NN":warm_nn,"allocated_nodes":allocated}),
                )?;
            }
        }
    }
    if calls + cpu_calls + warm_nn > cfg.nn_cap || allocated > cfg.allocated_cap {
        return Err("TOTAL_COUNTER_CAP".into());
    }
    serde_json::to_writer_pretty(
        File::create(cfg.output)?,
        &json!({"task":cfg.task,"schema":cfg.schema,"mode":cfg.mode,"status":"RECORDED","records":records,"model_SHA":cfg.model_sha,"backend":gpu.metadata().backend,"logical_GPU_NN":calls,"CPU_reference_NN":cpu_calls,"warm_NN":warm_nn,"physical_NN":calls+cpu_calls+warm_nn,"allocated_nodes":allocated,"replay_seconds":replay_s,"backend_init_seconds":init_s,"whole_seconds":start.elapsed().as_secs_f64(),"rootnoise":false,"RNG_seed_variance_measured":false,"new_games":0,"highK_is_truth":false}),
    )?;
    Ok(())
}
