use serde_json::{Value, json};
use std::fs::File;
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
fn write_json(path: &std::path::Path, value: &Value) -> Result<()> {
    let mut writer = std::io::BufWriter::new(File::create(path)?);
    serde_json::to_writer(&mut writer, value)?;
    std::io::Write::flush(&mut writer)?;
    Ok(())
}
fn main() -> Result<()> {
    let path = std::env::args().nth(1).unwrap();
    let v = json!({"partial":true,"records":[{"id":"game-0-ply-8","K":64,"v":-0.21036740225827089,"zero":-0.0,"legal":[3,5,13],"edges":[{"visits":1,"prior":0.000001,"value_sum":0.2}],"fault":null}],"task":"teacher-budget-282-v1"});
    let mut old = Vec::new();
    serde_json::to_writer(&mut old, &v)?;
    write_json(std::path::Path::new(&path), &v)?;
    let new = std::fs::read(path)?;
    assert_eq!(old, new);
    let decoded: Value = serde_json::from_slice(&new)?;
    assert_eq!(decoded, v);
    println!("BYTE_EXACT_DECODE_PASS {}", new.len());
    Ok(())
}
