"""Bounded 291 target-free reference audit; no model, NPZ, cache, or label reader."""

import argparse
from collections import Counter
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import runpy
import signal
import struct
import subprocess
import sys
import time

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame23-sigma-public-z-review"
TASK = "frame23-public-reference-exposure-291-v1"
KEYS = {
    "STM_distance_f32bits",
    "actualSTM_ids",
    "distance_order",
    "external_input_provenance",
    "family",
    "history_format",
    "history_key",
    "id",
    "ids_order",
    "input_signature",
    "partition",
    "schema",
    "side",
    "side_frame",
    "state_key",
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def signature(row):
    assert row["ids_order"] == "STM_then_opponent"
    assert row["distance_order"] == "STM_then_opponent"
    raw = bytearray()
    for ids in row["actualSTM_ids"]:
        assert ids == sorted(set(ids)) and all(0 <= v < 312 for v in ids)
        raw.extend(struct.pack("<H", len(ids)))
        raw.extend(struct.pack("<" + "H" * len(ids), *ids))
    bits = row["STM_distance_f32bits"]
    raw.extend(struct.pack("<II", *bits))
    calculated = hashlib.sha256(raw).hexdigest()
    assert calculated == row["input_signature"]
    return calculated


def load_rows(block):
    path = Path(block["target_free_refs"])
    assert sha(path) == block["refs_SHA"]
    stream_sha = hashlib.sha256()
    rows = []
    with gzip.open(path, "rb") as stream:
        for line in stream:
            stream_sha.update(line)
            row = json.loads(line)
            assert set(row) == KEYS
            assert row["history_key"] is None and row["history_format"] == "UNAVAILABLE"
            assert row["side"] == 1
            row["_sig"] = signature(row)
            rows.append(row)
    assert stream_sha.hexdigest() == block["refs_uncompressed_SHA"]
    assert len({r["id"] for r in rows}) == len(rows)
    return rows


def stats(rows):
    family = Counter(r["family"] for r in rows)
    sigs = Counter(r["_sig"] for r in rows)
    states = Counter(r["state_key"] for r in rows)
    return {
        "rows": len(rows),
        "inputgroups": len(family),
        "unique_actualSTM_inputs": len(sigs),
        "unique_available_state_literals": len(states),
        "repeated_input_rows_beyond_first": len(rows) - len(sigs),
        "largest_input_multiplicity": max(sigs.values(), default=0),
        "per_inputgroup": dict(family),
        "actual_game_count": "UNAVAILABLE",
        "absolute_side_and_ply_phase": "UNAVAILABLE; side1 is virtual STM, not original P1",
    }


def payload(register):
    started = time.monotonic()
    handoff = json.loads(Path(register["handoff"]).read_text())
    train = load_rows(handoff["train_validation"][0])
    val = load_rows(handoff["train_validation"][1])
    future = load_rows(handoff["future_target_free"])
    assert (len(train), len(val), len(future)) == (79769, 19965, 19359)
    references = {}
    for name, rows in (("allraw_train", train), ("ALLraw_qualified_validation", val)):
        references[name] = ({r["_sig"] for r in rows}, {r["state_key"] for r in rows})
    full_stats = {}
    masks = {}
    for name, (inputs, states) in references.items():
        selected = []
        count = Counter()
        for row in future:
            input_match = row["_sig"] in inputs
            state_match = row["state_key"] in states
            count["input"] += input_match
            count["state"] += state_match
            count["both"] += input_match and state_match
            count["OR"] += input_match or state_match
            if not (input_match or state_match):
                selected.append(row)
        full_stats[name] = {
            "shared_rows": dict(count),
            "remaining": stats(selected),
            "zeroeligible_groups": len({r["family"] for r in future})
            - len({r["family"] for r in selected}),
        }
        masks[name] = {r["id"] for r in selected}
    keep_val = masks["ALLraw_qualified_validation"]
    keep_allraw = keep_val & masks["allraw_train"]
    after_both = [r for r in future if r["id"] in keep_allraw]
    val_inputs, val_states = references["ALLraw_qualified_validation"]
    train_match = Counter()
    for row in train:
        train_match["input"] += row["_sig"] in val_inputs
        train_match["state"] += row["state_key"] in val_states
        train_match["OR"] += row["_sig"] in val_inputs or row["state_key"] in val_states
    with gzip.open(OUT / "future-input-only-mask-bound-v1.jsonl.gz", "wt") as stream:
        for row in future:
            stream.write(
                json.dumps(
                    {
                        "id": row["id"],
                        "family": row["family"],
                        "after_ALLraw_validation_OR": row["id"] in keep_val,
                        "after_allraw_train_plus_ALLraw_validation_OR": row["id"] in keep_allraw,
                    },
                    separators=(",", ":"),
                )
                + "\n"
            )
    result = {
        "task": TASK,
        "schema": "public-input-only-exposure-audit-v1",
        "PASS": True,
        "at": stamp(),
        "NN": 0,
        "model_NPZ_label_reader": False,
        "source_reference_rows": len(train) + len(val) + len(future),
        "input_signature_independent_reconstruction": True,
        "populations": {
            "train": stats(train),
            "ALLrawvalidation": stats(val),
            "original_future": stats(future),
        },
        "future_exposure": full_stats,
        "train_raw_against_ALLrawval": dict(train_match),
        "after_allrawtrain_and_ALLrawval": stats(after_both),
        "final_Tactual": "PENDING actual-used union/freeze; allrawtrain is a conservative superset bound, not a claim of actual exposure",
        "history_OR": "UNAVAILABLE and null never treated as literal samehistory",
        "phase": "NOT_AVAILABLE; no actual ply/prefix in public projection; no phase inferred from order/plies_to_end",
        "independent_game_CI": "UNDEFINED: original gameUID/history missing, inputgroups are not game families",
        "original_protocol_or_labels_changed": False,
        "mask_SHA": sha(OUT / "future-input-only-mask-bound-v1.jsonl.gz"),
        "command_body_seconds": time.monotonic() - started,
    }
    (OUT / "public-reference-exposure-result-v1.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                k: result[k]
                for k in [
                    "task",
                    "schema",
                    "PASS",
                    "future_exposure",
                    "after_allrawtrain_and_ALLrawval",
                    "NN",
                ]
            }
        )
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", required=True)
    parser.add_argument("--payload", action="store_true")
    args = parser.parse_args()
    regpath = Path(args.registration)
    reg = json.loads(regpath.read_text())
    assert reg["task"] == TASK and reg["entry_SHA"] == sha(__file__)
    for path, expected in reg["bindings"].items():
        assert sha(path) == expected
    if args.payload:
        payload(reg)
        return 0
    job = OUT / "exposure-source-r1"
    job.mkdir(exist_ok=False)
    helper = runpy.run_path(
        str(ROOT / "research-data/ai-sigma/frame23-independent-evaluation/score_guard.py")
    )
    before = helper["snapshot"]()
    ancestors = {os.getpid()}
    current = os.getpid()
    while current in before and before[current]["ppid"] not in ancestors:
        current = before[current]["ppid"]
        ancestors.add(current)
    foreign = [p for pid, p in before.items() if pid not in ancestors and helper["compute"](p)]
    loaded = json.loads(Path(reg["runtime_loaded"]).read_text())
    expected = json.loads(Path(reg["current_expectations"]).read_text())
    state = json.loads(
        (ROOT / ".artifacts/research-team/frame22-extension23/scheduler/state.json").read_text()
    )
    runtime = []
    for ident in (loaded["scheduler"], loaded["monitor"]):
        actual = helper["proc"](ident["pid"])
        assert (
            actual
            and actual["tick"] == str(ident["start_ticks"])
            and actual["boot"] == ident["boot_id"]
        )
        runtime.append(actual)
    current24 = {p: sha(p) == h for p, h in expected["input_hashes"].items()}
    assert len(current24) == 24 and all(current24.values()) and state["phase"] == "running"
    assert state["process"]["pid"] == loaded["scheduler"]["pid"]
    assert sha(state["binding"]["config_path"]) == state["config_sha256"] == loaded["config_sha256"]
    assert (
        sha(state["binding"]["contract_file"])
        == state["contract_sha256"]
        == loaded["contract_sha256"]
    )
    keeper = json.loads(Path(reg["storage_point"]).read_text())
    assert (
        not keeper["errors"] and keeper["current_plus_unused_unknown_bytes"] < keeper["cap_bytes"]
    )
    allocated = sum(p.stat().st_blocks * 512 for p in OUT.rglob("*") if p.is_file())
    assert allocated + 524288 < 2097152
    argv = [
        "/usr/bin/taskset",
        "-c",
        "3",
        reg["python"],
        "-B",
        str(Path(__file__).resolve()),
        "--registration",
        str(regpath.resolve()),
        "--payload",
    ]
    (job / "admission.json").write_text(
        json.dumps(
            {
                "task": TASK,
                "at": stamp(),
                "argv": argv,
                "entry_SHA": sha(__file__),
                "register_SHA": sha(regpath),
                "runtime": runtime,
                "current24": current24,
                "owned": state.get("owned"),
                "foreign": foreign,
                "allocated": allocated,
                "forecast": 524288,
                "storage_point_SHA": sha(reg["storage_point"]),
                "expected_schema": "public-input-only-exposure-audit-v1",
                "point_only": True,
            },
            indent=2,
        )
        + "\n"
    )
    if foreign:
        (job / "process.json").write_text(
            json.dumps(
                {
                    "status": "NOT_STARTED_FOREIGN_CPU",
                    "NN": 0,
                    "science_MAX_consumed": 0,
                    "foreign": foreign,
                },
                indent=2,
            )
            + "\n"
        )
        return 78
    start = time.monotonic()
    cause = None
    peak = 0
    seen = {}
    with (job / "stdout.log").open("w") as out, (job / "stderr.log").open("w") as err:
        child = subprocess.Popen(argv, stdout=out, stderr=err, start_new_session=True)
        while child.poll() is None:
            snap = helper["snapshot"]()
            owned = {pid for pid, p in snap.items() if p["pgid"] == child.pid}
            seen.update({pid: snap[pid] for pid in owned})
            peak = max(peak, sum(snap[pid]["rss"] for pid in owned))
            active = [
                p
                for pid, p in snap.items()
                if pid not in ancestors and pid not in owned and helper["compute"](p)
            ]
            if active:
                cause = "FOREIGN_CPU"
            if peak > 1792 * 1024**2:
                cause = "RSS_GUARD"
            if time.monotonic() - start > 60:
                cause = "SOURCE_WALL_GUARD"
            if cause:
                os.killpg(child.pid, signal.SIGTERM)
                break
            time.sleep(0.05)
        try:
            code = child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait()
    remaining = [
        p for pid, old in seen.items() if (p := helper["proc"](pid)) and p["tick"] == old["tick"]
    ]
    result_path = OUT / "public-reference-exposure-result-v1.json"
    result = json.loads(result_path.read_text()) if code == 0 and result_path.exists() else None
    valid = bool(
        result
        and result["task"] == TASK
        and result["schema"] == "public-input-only-exposure-audit-v1"
        and result["PASS"]
    )
    (job / "process.json").write_text(
        json.dumps(
            {
                "task": TASK,
                "exit_code": code,
                "waited": True,
                "current_exact_remaining": remaining,
                "cause": cause,
                "command_wall_s": time.monotonic() - start,
                "peak_RSS": peak,
                "identities": list(seen.values()),
                "NN": 0,
                "classification": "source-preparation target-free metadata arithmetic",
                "science_MAX_consumed": 0,
                "output_identity_PASS": valid,
            },
            indent=2,
        )
        + "\n"
    )
    print(
        json.dumps(
            {
                "PASS": valid,
                "exit": code,
                "NN": 0,
                "wall_s": time.monotonic() - start,
                "cause": cause,
                "remaining": remaining,
            }
        )
    )
    return 0 if valid and not remaining else 1


if __name__ == "__main__":
    sys.exit(main())
