"""291 one frozen v3 candidate, with analytic baselines; no future label reader."""

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import time

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[variable] = "1"
os.environ["ORT_DISABLE_TELEMETRY"] = "1"

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame23-sigma-public-z-review/prediction-r1"
TASK = "public-rulea-frozen-prediction-291-v1"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_jsonlines(path):
    with gzip.open(path, "rt") as stream:
        return [json.loads(line) for line in stream]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", required=True)
    parser.add_argument("--mock", action="store_true")
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    assert reg["task"] == TASK and reg["entry_SHA"] == sha(__file__)
    if args.mock:
        import sys

        assert sys.argv.count(str(Path(args.registration))) == 1
        print(
            json.dumps(
                {"task": TASK, "argument_registration_PASS": True, "NN": 0, "labels_read": False}
            )
        )
        return
    OUT.mkdir(exist_ok=False)
    start = time.monotonic()
    for path, expected in reg["inputs"].items():
        assert sha(path) == expected
    freeze = json.loads(Path(reg["evaluation_freeze"]).read_text())
    public = json.loads(Path(reg["public_handoff"]).read_text())
    rulea = json.loads(Path(reg["rulea_handoff"]).read_text())
    rows = []
    for domain, ref, family_key in (
        ("public0043", public["future_target_free"]["target_free_refs"], "family"),
        ("RuleA48", rulea["target_free_refs"], "canonical_family"),
    ):
        mask = {
            (r["family"], r["id"]): r for r in read_jsonlines(freeze["masks"][domain]["mask_path"])
        }
        for row in read_jsonlines(ref):
            match = mask.pop((row[family_key], row["id"]))
            assert match["input_signature"] == row["input_signature"]
            if match["eligible_input"]:
                rows.append(
                    {
                        "domain": domain,
                        "family": row[family_key],
                        "id": row["id"],
                        "input_signature": row["input_signature"],
                        "ids": row["actualSTM_ids"],
                        "bits": row["STM_distance_f32bits"],
                        "side": row["side"],
                        "cohort": row.get("cohort"),
                        "ply": row.get("ply"),
                        "absolute_side_known": domain == "RuleA48",
                    }
                )
        assert not mask
    assert len(rows) == reg["input_rows"] == 5257
    import numpy as np

    binding = freeze["candidate"]["native_manifest"]
    manifest_path = Path(binding["path"])
    manifest = json.loads(manifest_path.read_text())
    assert manifest["schema"] == "quoridor-nnue-distance-residual-v3"
    assert manifest["feature"] == "QF1-route4-f32-STM-scaled-residual-v3"
    assert manifest["route_mode"] == "zero4" and manifest["topology"] == {
        "ft_width": 32,
        "hidden_width": 32,
    }
    assert manifest["value_perspective"] == "side-to-move"
    assert manifest["value_parameterization"] == "fixed-distance-logit-plus-linear-residual-tanh"
    assert manifest["distance_fit"] == {"a": 0.0, "b": 8.0}
    weights_path = manifest_path.parent / manifest["weights"]
    assert (
        sha(weights_path) == manifest["weights_SHA"] == freeze["candidate"]["native_weights"]["SHA"]
    )
    flat = np.frombuffer(weights_path.read_bytes(), dtype="<f4")
    assert len(flat) == 12321 and np.isfinite(flat).all()
    weights = []
    offset = 0
    for shape in ((32, 312), (32,), (32, 70), (32,), (32,), (1,)):
        count = int(np.prod(shape))
        weights.append(flat[offset : offset + count].reshape(shape))
        offset += count
    assert offset == len(flat)
    x = np.zeros((len(rows), 2, 312), dtype="<f4")
    distances = np.empty((len(rows), 2), dtype="<f4")
    for index, row in enumerate(rows):
        for view in (0, 1):
            ids = row["ids"][view]
            assert ids == sorted(set(ids)) and all(0 <= k < 312 for k in ids)
            x[index, view, ids] = 1
        distances[index] = struct.unpack("<ff", struct.pack("<II", *row["bits"]))
    ft, ft_bias, hidden, hidden_bias, head, head_bias = weights
    mu = np.asarray(manifest["mu_f32"], dtype="<f4")
    sigma = np.asarray(manifest["sigma_f32"], dtype="<f4")
    assert np.isfinite(mu).all() and np.isfinite(sigma).all() and (sigma > 0).all()
    transformed = np.maximum(x @ ft.T + ft_bias, np.float32(0))
    columns = np.concatenate(
        (
            transformed[:, 0],
            transformed[:, 1],
            (distances - mu) / sigma,
            np.zeros((len(rows), 4), dtype="<f4"),
        ),
        axis=1,
    )
    residual = np.maximum(columns @ hidden.T + hidden_bias, np.float32(0)) @ head + head_bias[0]
    logit = np.float32(8) * (distances[:, 1] - distances[:, 0])
    candidate = np.tanh(logit + residual).astype("<f4")
    baseline_D = np.tanh(logit.astype("<f8")).astype("<f4")
    constant = float(freeze["baselines"]["constant"]["value"])
    assert np.isfinite(candidate).all() and (np.abs(candidate) <= 1).all()
    # The native CLI executes scalar, SIMD, and delta evaluation for each input.
    # Count all three; the earlier two-call prospective forecast remains historical.
    selected = {}
    for index in sorted(
        range(len(rows)), key=lambda i: (rows[i]["domain"], rows[i]["family"], rows[i]["id"])
    ):
        row = rows[index]
        if row["domain"] == "RuleA48":
            selected.setdefault((row["cohort"], row["side"]), index)
    witnesses = list(selected.values())[:24]
    assert len(witnesses) == reg["native_witnesses"] == 24
    native_rows = []
    for index in witnesses:
        row = rows[index]
        native_rows.append(
            {
                "id": row["family"] + ":" + row["id"],
                "side": row["side"],
                "ids": row["ids"] if row["side"] == 1 else row["ids"][::-1],
                "distance": distances[index].tolist(),
            }
        )
    binary = freeze["model_settings"]["native_binary"]
    assert sha(binary["path"]) == binary["SHA"]
    argv = ["/usr/bin/taskset", "-c", "3", binary["path"], "model", str(manifest_path)]
    child = subprocess.Popen(
        argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    )
    tick = (Path("/proc") / str(child.pid) / "stat").read_text().rsplit(")", 1)[1].split()[19]
    (OUT / "native-start.json").write_text(
        json.dumps({"pid": child.pid, "tick": tick, "argv": argv}, indent=2) + "\n"
    )
    try:
        stdout, stderr = child.communicate(
            "".join(json.dumps(r) + "\n" for r in native_rows), timeout=20
        )
    except BaseException:
        child.kill()
        child.wait()
        raise
    assert child.returncode == 0, stderr
    parsed = [json.loads(line) for line in stdout.splitlines()]
    assert len(parsed) == len(witnesses)
    errors = []
    for item, expected, index in zip(parsed, native_rows, witnesses):
        assert item["id"] == expected["id"]
        value = float(candidate[index])
        tolerance = 1e-5 + 1e-4 * abs(value)
        error = abs(value - item["value"])
        assert error <= tolerance
        assert abs(item["value"] - item["delta_value"]) <= tolerance
        assert abs(item["value"] - item["simd_value"]) <= tolerance
        errors.append(error)
    native = {
        "argv": argv,
        "pid": child.pid,
        "tick": tick,
        "exit_code": child.returncode,
        "waited": True,
        "current_exact_absent": not (Path("/proc") / str(child.pid)).exists(),
        "samples": 3 * len(witnesses),
        "calls_per_sample": "scalar/SIMD/delta",
        "max_abs_numpy_native": max(errors),
        "output": parsed,
    }
    (OUT / "native-receipt.json").write_text(json.dumps(native, indent=2) + "\n")
    with gzip.open(OUT / "predictions-v1.jsonl.gz", "wt") as stream:
        for index, row in enumerate(rows):
            stream.write(
                json.dumps(
                    {k: v for k, v in row.items() if k not in ("ids", "bits")}
                    | {
                        "prediction": {
                            "candidate": float(candidate[index]),
                            "D": float(baseline_D[index]),
                            "constant": constant,
                        }
                    },
                    separators=(",", ":"),
                )
                + "\n"
            )
    NN = len(rows) + native["samples"]
    assert NN == reg["physicalNN_upper"] == 5329
    result = {
        "task": TASK,
        "schema": "frozen-public-rulea-predictions-291-v1",
        "PASS": True,
        "NN": NN,
        "numpyNN": len(rows),
        "nativeNN": native["samples"],
        "oneuniqueNNUE": True,
        "D_constantNN": 0,
        "rows": len(rows),
        "labels_read": False,
        "body_seconds": time.monotonic() - start,
        "native_max_abs": max(errors),
        "predictions_SHA": sha(OUT / "predictions-v1.jsonl.gz"),
        "entry_SHA": sha(__file__),
        "registration_SHA": sha(args.registration),
    }
    (OUT / "result-v1.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
