"""291 label-blind RuleA/public input exposure bound; never opens targets or models."""

import argparse
from collections import Counter
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import runpy
import signal
import struct
import time

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame23-sigma-public-z-review/rulea-input-review"
TASK = "rulea-public-input-bound-291-v1"
KEYS = {
    "STM_distance_f32bits",
    "actualSTM_ids",
    "canonical_family",
    "cohort",
    "distance_order",
    "history_key",
    "history_key_format",
    "history_literal",
    "id",
    "ids_order",
    "input_signature",
    "native_family_alias",
    "opening_side",
    "partition",
    "ply",
    "prefix",
    "producer_schema",
    "producer_source_SHA",
    "side",
    "state_key",
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def signature(row):
    assert row["ids_order"] == "STM_then_opponent"
    assert row["distance_order"] in ("STM_then_opponent", "STM_then_opponent_f32_le")
    data = bytearray()
    for ids in row["actualSTM_ids"]:
        assert ids == sorted(set(ids)) and all(0 <= i < 312 for i in ids)
        data.extend(struct.pack("<H", len(ids)))
        data.extend(struct.pack("<" + "H" * len(ids), *ids))
    data.extend(struct.pack("<II", *row["STM_distance_f32bits"]))
    result = hashlib.sha256(data).hexdigest()
    assert result == row["input_signature"]
    return result


def reference(path, compressed_sha, uncompressed_sha, keys):
    assert sha(path) == compressed_sha
    digest = hashlib.sha256()
    with gzip.open(path, "rb") as stream:
        for line in stream:
            digest.update(line)
            row = json.loads(line)
            assert set(row) == keys
            signature(row)
            yield row
    assert digest.hexdigest() == uncompressed_sha


def main():
    signal.alarm(30)
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", required=True)
    args = parser.parse_args()
    register = json.loads(Path(args.registration).read_text())
    assert register["task"] == TASK and register["entry_SHA"] == sha(__file__)
    OUT.mkdir(exist_ok=False)
    point_helper = runpy.run_path(str(Path(__file__).with_name("sigma_input_review.py")))
    point_helper["admit"].__globals__["OUT"] = OUT
    point_helper["admit"].__globals__["TASK"] = TASK
    point_helper["admit"]()
    allocated = sum(p.stat().st_blocks * 512 for p in OUT.parent.rglob("*") if p.is_file())
    assert allocated + 524288 < 2097152
    coverage = json.loads(Path(register["coverage"]).read_text())
    assert sha(register["coverage"]) == register["coverage_SHA"]
    assert not coverage["errors"]
    assert coverage["total_current_unused_unknown_bytes"] < coverage["cap_bytes"]
    start = time.monotonic()
    public = json.loads(Path(register["public_handoff"]).read_text())
    rulea = json.loads(Path(register["rulea_handoff"]).read_text())
    assert sha(register["public_handoff"]) == register["public_handoff_SHA"]
    assert sha(register["rulea_handoff"]) == register["rulea_handoff_SHA"]
    public_keys = set(
        runpy.run_path(str(Path(__file__).with_name("public_metadata_exposure_guard.py")))["KEYS"]
    )
    sets = {}
    for name, ref in zip(("allrawT", "ALLrawV"), public["train_validation"]):
        states, inputs = set(), set()
        for row in reference(
            ref["target_free_refs"], ref["refs_SHA"], ref["refs_uncompressed_SHA"], public_keys
        ):
            assert row["history_key"] is None
            states.add(row["state_key"])
            inputs.add(row["input_signature"])
        sets[name] = (states, inputs)
    rows = list(
        reference(
            rulea["target_free_refs"],
            rulea["projection_proof"]["SHA"],
            rulea["projection_proof"]["uncompressed_SHA"],
            KEYS,
        )
    )
    assert len(rows) == rulea["row_count"] == 1668
    families = Counter(r["canonical_family"] for r in rows)
    assert len(families) == rulea["planned_family_count"] == 48
    assert dict(families) == rulea["rows_by_family"]
    assert len({(r["canonical_family"], r["id"]) for r in rows}) == len(rows)
    bounds = {}
    mask_rows = []
    for name, reference_names in (
        ("ALLrawV", ("ALLrawV",)),
        ("allrawT_plus_ALLrawV", ("allrawT", "ALLrawV")),
    ):
        states = set().union(*(sets[k][0] for k in reference_names))
        inputs = set().union(*(sets[k][1] for k in reference_names))
        keep = [
            r for r in rows if r["state_key"] not in states and r["input_signature"] not in inputs
        ]
        per_family = Counter(r["canonical_family"] for r in keep)
        bounds[name] = {
            "excluded_rows": len(rows) - len(keep),
            "remaining_rows": len(keep),
            "remaining_families": len(per_family),
            "zeroeligible_families": len(families) - len(per_family),
            "per_family_remaining": dict(per_family),
            "unique_STM_inputs": len({r["input_signature"] for r in keep}),
        }
        if name == "allrawT_plus_ALLrawV":
            keep_ids = {(r["canonical_family"], r["id"]) for r in keep}
            mask_rows = [
                {
                    "family": r["canonical_family"],
                    "id": r["id"],
                    "conservative_allrawT_ALLrawV_keep": (r["canonical_family"], r["id"])
                    in keep_ids,
                }
                for r in rows
            ]
    with gzip.open(OUT / "input-only-mask-bound-v1.jsonl.gz", "wt") as stream:
        for row in mask_rows:
            stream.write(json.dumps(row, separators=(",", ":")) + "\n")
    result = {
        "task": TASK,
        "PASS": True,
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "planned_families": 48,
        "obtained_rows": 1668,
        "bounds": bounds,
        "NN": 0,
        "targets_read": False,
        "science_MAX_consumed": 0,
        "body_wall_seconds": time.monotonic() - start,
        "actualTseen_final": "PENDING learner frozen union; allrawT is only a conservative superset",
        "history_cross_public": "UNAVAILABLE; no null literal matching/nonexposure guarantee",
        "prefix_legal_terminal_proof": "producer/sharedRuleA dependency; not independently replayed here",
        "original_public_first10_protocol_unchanged": True,
        "mask_not_final": True,
        "source_SHA": sha(__file__),
        "registration_SHA": sha(args.registration),
    }
    (OUT / "result-v1.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {k: v for k, v in result.items() if k != "bounds"}
            | {
                "bounds": {
                    k: {n: v for n, v in b.items() if n != "per_family_remaining"}
                    for k, b in bounds.items()
                }
            }
        )
    )


if __name__ == "__main__":
    main()
