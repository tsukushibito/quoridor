"""Freeze 291 input-only masks and evaluation rules before any future target read."""

import argparse
from collections import Counter
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import runpy
import signal
import struct
import time

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame23-sigma-public-z-review/final-input-freeze"
TASK = "public-rulea-evaluation-freeze-291-v1"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def learner_signature(row):
    views = [struct.pack("<" + "H" * len(ids), *ids) for ids in row["actualSTM_ids"]]
    raw = b"QF1-f32-STM-v1\0" + struct.pack("<HH", *map(len, views)) + b"".join(views)
    raw += struct.pack("<II", *row["STM_distance_f32bits"])
    return hashlib.sha256(raw).hexdigest()


def read_refs(ref):
    assert sha(ref["path"]) == ref["SHA"]
    digest = hashlib.sha256()
    rows = []
    with gzip.open(ref["path"], "rb") as stream:
        for line in stream:
            digest.update(line)
            row = json.loads(line)
            assert set(row) == {"id", "input_signature", "producer_group", "group", "group_basis"}
            rows.append(row)
    assert digest.hexdigest() == ref["uncompressed_SHA"]
    assert len(rows) == ref["rows"] == len({r["id"] for r in rows})
    return rows


def main():
    signal.alarm(30)
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", required=True)
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    assert reg["task"] == TASK and sha(__file__) == reg["entry_SHA"]
    OUT.mkdir(exist_ok=False)
    helper = runpy.run_path(str(Path(__file__).with_name("sigma_input_review.py")))
    helper["admit"].__globals__["OUT"] = OUT
    helper["admit"].__globals__["TASK"] = TASK
    helper["admit"]()
    assert (
        sum(f.stat().st_blocks * 512 for f in OUT.parent.rglob("*") if f.is_file()) + 524288
        < 2097152
    )
    started = time.monotonic()
    candidate = json.loads(Path(reg["candidate_freeze"]).read_text())
    assert sha(reg["candidate_freeze"]) == reg["candidate_freeze_SHA"]
    assert not candidate["future_labels_opened"]
    for binding in candidate["candidate"].values():
        if isinstance(binding, dict) and "path" in binding and "SHA" in binding:
            assert sha(binding["path"]) == binding["SHA"]
    for binding in candidate["source_SHA"].items():
        assert sha(binding[0]) == binding[1]
    public = json.loads(Path(reg["public_handoff"]).read_text())
    rulea = json.loads(Path(reg["rulea_handoff"]).read_text())
    assert sha(reg["public_handoff"]) == reg["public_handoff_SHA"]
    assert sha(reg["rulea_handoff"]) == reg["rulea_handoff_SHA"]
    reader = runpy.run_path(str(Path(__file__).with_name("public_metadata_exposure_guard.py")))
    raw_train, raw_val, raw_future = [
        reader["load_rows"](ref)
        for ref in (*public["train_validation"], public["future_target_free"])
    ]
    by_id = {r["id"]: r for r in raw_train}
    seen = read_refs(candidate["references"]["Tseen"]["canonical"])
    seen2 = read_refs(candidate["references"]["Tseen"]["same_stream_second_condition"])
    val = read_refs(candidate["references"]["Vraw"]["canonical"])
    val2 = read_refs(candidate["references"]["Vraw"]["same_stream_second_condition"])
    assert seen == seen2 and val == val2
    assert len(seen) == 67937 and len(val) == 19965
    assert {r["id"] for r in val} == {r["id"] for r in raw_val}
    for refs, originals in ((seen, by_id), (val, {r["id"]: r for r in raw_val})):
        for row in refs:
            raw = originals[row["id"]]
            assert learner_signature(raw) == row["input_signature"]
            assert raw["family"] == row["producer_group"]
    seen_ids = {r["id"] for r in seen}
    reference_rows = [r for r in raw_train if r["id"] in seen_ids] + raw_val
    reference_state = {r["state_key"] for r in reference_rows}
    reference_input = {r["input_signature"] for r in reference_rows}
    rule_reader = runpy.run_path(str(Path(__file__).with_name("rulea_targetfree_mask_review.py")))
    raw_rulea = list(
        rule_reader["reference"](
            rulea["target_free_refs"],
            rulea["projection_proof"]["SHA"],
            rulea["projection_proof"]["uncompressed_SHA"],
            rule_reader["KEYS"],
        )
    )
    mask_summary = {}
    for name, rows, family_key in (
        ("public0043", raw_future, "family"),
        ("RuleA48", raw_rulea, "canonical_family"),
    ):
        keep = [
            r
            for r in rows
            if r["state_key"] not in reference_state and r["input_signature"] not in reference_input
        ]
        per_group = Counter(r[family_key] for r in keep)
        mask_path = OUT / (name + "-input-mask-v1.jsonl.gz")
        with gzip.open(mask_path, "wt") as stream:
            for row in rows:
                stream.write(
                    json.dumps(
                        {
                            "id": row["id"],
                            "family": row[family_key],
                            "input_signature": row["input_signature"],
                            "eligible_input": row["state_key"] not in reference_state
                            and row["input_signature"] not in reference_input,
                        },
                        separators=(",", ":"),
                    )
                    + "\n"
                )
        mask_summary[name] = {
            "planned_groups": len({r[family_key] for r in rows}),
            "raw_rows": len(rows),
            "input_eligible_rows": len(keep),
            "input_eligible_groups": len(per_group),
            "zeroeligible_groups": len({r[family_key] for r in rows}) - len(per_group),
            "per_group_remaining": dict(per_group),
            "mask_path": str(mask_path),
            "mask_SHA": sha(mask_path),
            "target_filter": "public recorded +/-1 only; RuleA verified terminal +/-1 and provenance-proved rule draw0; fault/cap/unknown excluded without refill",
        }
    rules = {
        "task": TASK,
        "schema": "independent-public-rulea-evaluation-freeze-291-v1",
        "UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "candidate_freeze": reg["candidate_freeze"],
        "candidate_freeze_SHA": reg["candidate_freeze_SHA"],
        "candidate": candidate["candidate"],
        "model_settings": candidate["model_settings"],
        "baselines": candidate["baselines"],
        "Tactual_rows": len(seen),
        "Tactual_union_both_stages_equal": True,
        "ALLrawV_rows": len(val),
        "ALLrawV_includes_z0": True,
        "reference_bindings": candidate["references"],
        "signature_versions_independently_reconciled_via_rowID_actualSTMids_f32": True,
        "OR_predicate": "state literal OR compatible history literal OR actual STM IDs/rawf32 input; public history absent so null never matches and history independence remains UNVERIFIED",
        "masks": mask_summary,
        "public_primary": "inputgroup-equal MSE of decisive recorded +/-1; original first10 only; all planned/eligible/zero/exposed counts retained",
        "public_secondary": "rowweighted MSE/sign/bias/saturation/calibration per cycle/inputgroup; absolute P2/ply phase/gameUID unavailable",
        "public_independent_game_CI": "UNDEFINED; input groups are not independently identified games",
        "RuleA_primary": "equal-family terminal-z MSE with all48 planned denominator and per-game counts; true RuleA draw0 only with termination-reason provenance",
        "RuleA_secondary": "rowweighted MSE/sign/bias/saturation/calibration/plyphase/cohort/side",
        "RuleA_paired_bootstrap": {
            "seed": 29180311,
            "repetitions": 2000,
            "percentiles": [0.025, 0.975],
            "fixed_fits": True,
            "unit": "family",
            "cohort_lineage_correlation_limit": True,
        },
        "prediction": "one frozen NNUE unique weights; D and train-only frozen constant analytic NN0; max24 label-blind native full/delta witnesses including P2 from RuleA first family/side/cohort grid",
        "native_parity_tolerance": {"abs": 1e-5, "rtol": 1e-4},
        "physicalNN_upper": 19359 + 1668 + 1000,
        "science_MAX_total": 2,
        "science_command_total_seconds": 600,
        "no_reselection_no_refill_no_added_model": True,
        "future_labels_opened": False,
        "NN": 0,
        "body_seconds": time.monotonic() - started,
        "entry_SHA": sha(__file__),
        "registration_SHA": sha(args.registration),
        "teachertruth_or_samewall_strength": False,
        "original_old287_protocol_unchanged": True,
    }
    (OUT / "evaluation-freeze-v1.json").write_text(json.dumps(rules, indent=2) + "\n")
    print(
        json.dumps(
            {
                "task": TASK,
                "PASS": True,
                "NN": 0,
                "labels_read": False,
                "mask_summary": mask_summary,
                "freeze_SHA": sha(OUT / "evaluation-freeze-v1.json"),
                "body_seconds": rules["body_seconds"],
            }
        )
    )


if __name__ == "__main__":
    main()
