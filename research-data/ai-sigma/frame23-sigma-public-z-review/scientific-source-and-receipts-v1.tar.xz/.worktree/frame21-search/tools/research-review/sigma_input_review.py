"""Independent, synthetic Sigma plane/edge witnesses; no NPZ or model import."""

import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import struct
import sys
import time

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame23-sigma-public-z-review"
TASK = "frame23-sigma-public-z-review-291-v1"
N = 9


def f32(value):
    return struct.unpack("<f", struct.pack("<f", value))[0]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def edge(a, b):
    return tuple(sorted((a, b)))


def wall_edges(horizontal, vertical):
    blocked = set()
    for y, x in horizontal:
        for c in (x, x + 1):
            blocked.add(edge(y * N + c, (y + 1) * N + c))
    for y, x in vertical:
        for r in (y, y + 1):
            blocked.add(edge(r * N + x, r * N + x + 1))
    return blocked


def distances(blocked, goal):
    values = [N * N] * (N * N)
    queue = collections.deque(range(goal * N, (goal + 1) * N))
    for cell in queue:
        values[cell] = 0
    while queue:
        cell = queue.popleft()
        y, x = divmod(cell, N)
        for yy, xx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)):
            if 0 <= yy < N and 0 <= xx < N:
                other = yy * N + xx
                if values[other] == N * N and edge(cell, other) not in blocked:
                    values[other] = values[cell] + 1
                    queue.append(other)
    return values


def source_planes(horizontal, vertical, pawns, remaining, side):
    """Source-bound encoder oracle, separate from the plane geometry decoder."""
    blocked = wall_edges(horizontal, vertical)
    maps = [distances(blocked, 8), distances(blocked, 0)]
    planes = [[0.0] * 81 for _ in range(8)]
    for view, player in enumerate((side, side ^ 1)):
        y, x = divmod(pawns[player], N)
        planes[view][(8 - y if side else y) * N + x] = 1.0
        planes[4 + view] = [f32(remaining[player] / 10)] * 81
        for cell in range(81):
            yy, xx = divmod(cell, N)
            source = (8 - yy if side else yy) * N + xx
            distance = maps[player][source]
            planes[6 + view][cell] = f32(distance / 80) if distance < 81 else 1.0
    for y, x in horizontal:
        for xx in (x, x + 1):
            planes[2][(7 - y if side else y) * N + xx] = 1.0
    for y, x in vertical:
        for yy in (y, y + 1):
            planes[3][(8 - yy if side else yy) * N + x] = 1.0
    return planes


def literal_lr(planes):
    return [[row[(cell // N) * N + 8 - cell % N] for cell in range(81)] for row in planes]


def correct_lr(planes):
    """Reflect undirected edge endpoints, rather than a plane's anchor cell."""
    result = literal_lr(planes)
    result[3] = [0.0] * 81
    for cell, value in enumerate(planes[3]):
        if value:
            y, x = divmod(cell, N)
            assert x < 8
            result[3][y * N + 7 - x] = value
    return result


def decode_edges(planes):
    """Read cell adjacency directly, independent of the source encoder formula."""
    if any(planes[2][72:]) or any(planes[3][r * N + 8] for r in range(N)):
        return None, "NONZERO_WALL_PADDING"
    blocked = set()
    for plane in (2, 3):
        for cell, value in enumerate(planes[plane]):
            if value not in (0.0, 1.0):
                return None, "NONBINARY_WALL"
            if value:
                blocked.add(edge(cell, cell + (N if plane == 2 else 1)))
    return blocked, None


def check_maps(planes):
    blocked, failure = decode_edges(planes)
    if failure:
        return {"PASS": False, "cause": failure, "distance_mismatches": None}
    mismatches = []
    maps = [distances(blocked, 8), distances(blocked, 0)]
    for player in range(2):
        for cell, distance in enumerate(maps[player]):
            expected = f32(distance / 80) if distance < 81 else 1.0
            if planes[6 + player][cell] != expected:
                mismatches.append((player, cell, planes[6 + player][cell], expected))
    return {"PASS": not mismatches, "cause": None, "distance_mismatches": mismatches}


def proc(pid):
    try:
        base = Path("/proc") / str(pid)
        stat = (base / "stat").read_text().rsplit(")", 1)[1].split()
        argv = (base / "cmdline").read_bytes().decode(errors="replace").split("\0")[:-1]
        return {"pid": int(pid), "ppid": int(stat[1]), "tick": stat[19], "argv": argv}
    except (OSError, IndexError, ValueError):
        return None


def admit():
    """A current point, not a promise that no foreign computation can start."""
    state = json.loads(
        (ROOT / ".artifacts/research-team/frame22-extension23/scheduler/state.json").read_text()
    )
    monitor = json.loads(
        (
            ROOT
            / ".artifacts/ai-sigma/continuation-20261001/SIGMA-RESUME-OPERATIONS-92"
            / "frame22-extension23/monitor-process.json"
        ).read_text()
    )
    expectations = json.loads(
        (
            ROOT
            / ".artifacts/ai-sigma/continuation-20261001/SIGMA-RESUME-OPERATIONS-92"
            / "frame22-extension23/expectations.json"
        ).read_text()
    )
    hashes = {p: digest(p) == h for p, h in expectations["input_hashes"].items()}
    identities = []
    for registered in (state["process"], monitor["process"]):
        actual = proc(registered["pid"])
        assert actual and actual["tick"] == str(registered["start_ticks"])
        identities.append(actual)
    assert monitor["owned_scheduler"] == state["process"]
    assert state["phase"] == "running" and all(hashes.values())
    assert digest(state["binding"]["config_path"]) == state["config_sha256"]
    assert digest(state["binding"]["contract_file"]) == state["contract_sha256"]
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    assert all(r["boot_id"] == boot for r in (state["process"], monitor["process"]))
    memory = {
        row.split(":")[0]: int(row.split()[1]) * 1024
        for row in Path("/proc/meminfo").read_text().splitlines()
    }
    own_rss = int(Path("/proc/self/status").read_text().split("VmRSS:")[1].split()[0]) * 1024
    storage = ROOT / "research-data/ai-sigma/frame23-steward/storage-public-z-v2-admission.json"
    keeper = json.loads(storage.read_text())
    assert not keeper["errors"]
    assert keeper["current_plus_unused_unknown_bytes"] < keeper["cap_bytes"]
    allocated = sum(p.stat().st_blocks * 512 for p in OUT.rglob("*") if p.is_file())
    assert allocated + 512 * 1024 < 2 * 1024**2
    assert memory["MemAvailable"] > 2 * 1024**3 and own_rss < 1792 * 1024**2
    own = {os.getpid()}
    current = proc(os.getpid())
    while current and current["ppid"] not in own:
        own.add(current["ppid"])
        current = proc(current["ppid"])
    foreign = []
    for path in Path("/proc").iterdir():
        actual = proc(path.name) if path.name.isdigit() else None
        if not actual or actual["pid"] in own or not actual["argv"]:
            continue
        executable = Path(actual["argv"][0]).name
        script = next((a for a in actual["argv"][1:] if a.endswith(".py")), "")
        is_compute = executable in ("cargo", "rustc", "quoridor-runner", "nnue-diagnose")
        is_compute |= (
            executable.startswith("python")
            and any(name in script for name in ("frame23", "quoridor_training", "guard.py"))
            and not any(name in script for name in ("research-job", "research-team"))
        )
        if is_compute:
            foreign.append(actual)
    admission = {
        "task": TASK,
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "identity": proc(os.getpid()),
        "argv": sys.argv,
        "entry_SHA": digest(__file__),
        "current24": hashes,
        "runtime": identities,
        "config_SHA": state["config_sha256"],
        "contract_SHA": state["contract_sha256"],
        "boot": boot,
        "current_RSS": own_rss,
        "MemAvailable": memory["MemAvailable"],
        "storage_point_SHA": digest(storage),
        "storage_point_at": keeper["at"],
        "own_allocated": allocated,
        "own_Git_temp_metadata_forecast": 512 * 1024,
        "model_GPU_or_asset_reader": False,
        "owned": state.get("owned"),
        "foreign_compute": foreign,
        "point_only": True,
        "NN": 0,
        "synthetic_only_no_label_or_model_reader": True,
    }
    (OUT / "fixture-admission-v1.json").write_text(json.dumps(admission, indent=2) + "\n")
    assert not foreign, "FOREIGN_COMPUTE; fixture NOT_RUN"


def main():
    admit()
    started = time.monotonic()
    fixtures = [
        ("empty", [], []),
        ("asymmetric-border", [(2, 0), (5, 3)], [(0, 0), (2, 5), (6, 7)]),
        ("midboard", [(1, 2), (4, 5), (6, 0)], [(2, 1), (5, 6)]),
    ]
    result = []
    for name, horizontal, vertical in fixtures:
        for side in (0, 1):
            planes = source_planes(horizontal, vertical, [28, 61], [7, 6], side)
            original = check_maps(planes)
            proper = check_maps(correct_lr(planes))
            naive = check_maps(literal_lr(planes))
            assert original["PASS"] and proper["PASS"]
            if name == "asymmetric-border":
                assert naive["cause"] == "NONZERO_WALL_PADDING"
            # Undo source P2 vertical canonicalization with edge-aware geometry.
            blocked, _ = decode_edges(planes)
            flip = lambda c: (8 - c // N) * N + c % N
            restored = {edge(flip(a), flip(b)) for a, b in blocked} if side else blocked
            assert restored == wall_edges(horizontal, vertical)
            result.append(
                {
                    "name": name,
                    "known_synthetic_side": side,
                    "original": original,
                    "correct_edge_LR": proper,
                    "naive_allplane_LR": naive,
                    "both_goal_all81": True,
                    "original_geometry_restore": True,
                }
            )
    payload = {
        "task": TASK,
        "schema": "sigma-synthetic-edge-fixture-v1",
        "PASS": True,
        "fixtures": result,
        "checked_goal_distance_values": 6 * 2 * 81 * 2,
        "NN": 0,
        "model_or_npz_import": False,
        "actual_shard_original_augmented_byte_match": "NOT_RUN producer public refs pending",
        "native_QF1_full_delta_PARITY": "NOT_RUN; no new model forward",
        "actual_absolute_side_recovery": "UNAVAILABLE; synthetic side known only",
        "wall_seconds": time.monotonic() - started,
    }
    (OUT / "fixture-result-v1.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({k: v for k, v in payload.items() if k != "fixtures"}))


if __name__ == "__main__":
    main()
