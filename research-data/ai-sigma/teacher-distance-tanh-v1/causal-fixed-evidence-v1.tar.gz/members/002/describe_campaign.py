"""One finite saved-JSON hierarchy/census check, using the maintained direct-child lifetime."""

import argparse
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import time

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("causal_numeric_guard", HERE / "numeric_worker.py")
WORKER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WORKER)
GUARD = WORKER.GUARD
RAW = HERE / "raw/campaign-v1"


def engine_name(name):
    return "D" if name.startswith("fixed-D") else "NNUE"


def observation(row):
    return row.get("reused", row.get("observed", {}))


def child():
    resource.setrlimit(resource.RLIMIT_AS, (512 * GUARD.MIB, 512 * GUARD.MIB))
    source = HERE / "saved-extraction-v1.json"
    before = GUARD.file_record(source)
    saved = json.loads(source.read_bytes())
    refs = saved["saved_hash_mode_map"]
    GUARD.verify_rows(refs)
    parents = []
    natural_total = forced_total = nodes = 0
    matched_natural = matched_forced = 0
    tree_nodes = terminal_traces = nonterminal_traces = unknown_traces = 0
    all_callers = []
    for i, p in enumerate(saved["parents"]):
        raw = json.loads((RAW / f"parent-{i}.json").read_bytes())
        natural = []
        for row in p["natural"]:
            o = observation(row)
            r = o.get("result", {})
            natural_total += 1
            nodes += r.get("work", {}).get("nodes", 0)
            matched = r.get("matched_complete", False)
            matched_natural += int(matched)
            natural.append(
                {
                    "engine": engine_name(row["engine"]),
                    "requested_depth": row["depth"],
                    "action": r.get("action"),
                    "value": r.get("value_stm") if matched else None,
                    "status": "MATCHED_COMPLETE" if matched else "UNKNOWN_REQUESTED_DEPTH",
                    "completed_depth_saved": r.get("completed_depth"),
                    "stop": r.get("stop"),
                    "nodes": r.get("work", {}).get("nodes"),
                    "whole_setup_search_seconds": o.get("whole_setup_search_seconds"),
                    "TT_entries": o.get("TT_entries"),
                    "TT_byte_cap": o.get("TT_byte_cap"),
                }
            )
        forced = []
        for row in p["forced"]:
            o = row["observed"]
            r = o.get("child_search", {}).get("result", {})
            forced_total += 1
            nodes += r.get("work", {}).get("nodes", 0)
            matched = o.get("matched_complete", False)
            matched_forced += int(matched)
            if not o.get("parent_restored") or not o.get("child_search", {}).get("parent_restored"):
                raise RuntimeError("forced parent restoration not confirmed")
            if o["parent_value_stm"] != -r["value_stm"]:
                raise RuntimeError("saved forced child/parent sign mismatch")
            forced.append(
                {
                    "action": row["action"],
                    "depth": row["depth"],
                    "engine": engine_name(row["engine"]),
                    "matched_complete": matched,
                    "parent_value": o["parent_value_stm"] if matched else None,
                    "child_stop": r["stop"],
                    "child_depth": r["completed_depth"],
                    "nodes": r["work"]["nodes"],
                }
            )
        tree = raw["common_complete_depth2_tree"]
        if tree["status"] != "COMPLETE":
            raise RuntimeError("common complete tree is incomplete")
        moves = tree["all_legal_firstmoves_and_responses"]
        if len(set(m["action"] for m in moves)) != len(moves):
            raise RuntimeError("duplicate common first move")
        computed_nodes = 1 + len(moves)
        leaves = 0
        for move in moves:
            replies = move["legal_responses"]
            computed_nodes += len(replies)
            if len(set(r["action"] for r in replies)) != len(replies):
                raise RuntimeError("duplicate common legal reply")
            if replies:
                for engine in [0, 1]:
                    if move["values_stm"][engine] != -max(r["values_stm"][engine] for r in replies):
                        raise RuntimeError("saved minimax hierarchy mismatch")
                if move["leaf_count"] != sum(r["leaf_count"] for r in replies):
                    raise RuntimeError("saved reply leaf census mismatch")
            else:
                if move["terminal"] is None or move["values_stm"] != [-2 * move["terminal"]] * 2:
                    raise RuntimeError("terminal firstmove bypass mismatch")
            leaves += move["leaf_count"]
        best = [max(m["values_stm"][engine] for m in moves) for engine in [0, 1]]
        if (
            best != tree["value_stm"]
            or leaves != tree["leaf_count"]
            or computed_nodes != tree["expanded_or_leaf_nodes"]
        ):
            raise RuntimeError("root minimax or complete-tree counts mismatch")
        tree_nodes += computed_nodes
        candidates = p["freeze"]["candidate_union"]
        if len(p["forced"]) != len(candidates) * 6:
            raise RuntimeError("exact deduplicated frozen forced schedule mismatch")
        original = candidates[0]
        rankings = []
        for engine in [0, 1]:
            best_moves = [m["action"] for m in moves if m["values_stm"][engine] == best[engine]]
            first = next(m for m in moves if m["action"] == original)
            for row in natural:
                if (
                    row["requested_depth"] == 2
                    and row["engine"] == ["D", "NNUE"][engine]
                    and row["value"] != best[engine]
                ):
                    raise RuntimeError("same-depth natural/common reference mismatch")
            rankings.append(
                {
                    "engine": ["D", "NNUE"][engine],
                    "depth2_value": best[engine],
                    "all_tied_best_actions": best_moves,
                    "original_action": original,
                    "original_depth2_value": first["values_stm"][engine],
                    "original_is_tied_best": original in best_moves,
                }
            )
        callers = []
        for row in p["caller100ms"]:
            o = row["observed"]
            if o.get("accepted") and (
                o["authority_receipt_ns"] > 100000000
                or not o["legal"]
                or not o["matching_reply_drained"]
                or o["original_engine_error"] is not None
            ):
                raise RuntimeError(
                    "accepted receipt violates saved clock/legal/drain/error boundary"
                )
            profile = o["TT_and_whole_work"]
            callers.append(
                {
                    "engine": engine_name(row["engine"]),
                    "accepted": o["accepted"],
                    "action": o["immutable_action"],
                    "authority_receipt_ns": o["authority_receipt_ns"],
                    "legality_ns": o["legality_ns"],
                    "drain_ns": o["drain_ns"],
                    "full_caller_ns": o["full_caller_ns"],
                    "matching_reply_drained": o["matching_reply_drained"],
                    "completed_depth": None,
                    "nodes": None,
                    "depth_nodes_gap": "returned SearchResult was not saved; no TT usabledepth substitution",
                    "search_invocations": profile["search_invocations"],
                    "successful_results": profile["successful_results"],
                    "session_initialization_seconds": profile["session_initialization_seconds"],
                    "search_invocation_seconds": profile["search_invocation_seconds"],
                    "TT_work": profile,
                }
            )
            all_callers.append(callers[-1])
        traces = []
        for trace in p["traces"]:
            if trace.get("terminal_bypass"):
                terminal_traces += 1
                if trace["head_calls"] != 0 or trace["utility"] != 2 * trace["terminal"]:
                    raise RuntimeError("terminal trace neural bypass or utility mismatch")
            elif trace.get("status") == "OBSERVED":
                nonterminal_traces += 1
                if not trace["same_parent_bits_and_history"] or not trace["full_delta_head_match"]:
                    raise RuntimeError("new leaf qualification predicate failed")
            else:
                unknown_traces += 1
            traces.append(
                {k: v for k, v in trace.items() if k not in {"identity", "ids", "delta_components"}}
            )
        parents.append(
            {
                "id": p["id"],
                "original_action": original,
                "candidate_union": candidates,
                "natural": natural,
                "forced": forced,
                "common_tree": {
                    "status": "COMPLETE",
                    "saved_hierarchy_and_count_check": "PASS",
                    "expanded_or_leaf_nodes": computed_nodes,
                    "leaves": leaves,
                    "legal_firstmoves": len(moves),
                    "rankings": rankings,
                },
                "callers": callers,
                "traces": traces,
            }
        )
    counts = saved["counts"]
    if (
        natural_total + forced_total != counts["actual_natural_forced_search_invocations"]
        or natural_total != 36
        or forced_total != 66
        or tree_nodes != counts["common_tree_nodes"]
    ):
        raise RuntimeError("exact saved invocation/tree counter domains mismatch")
    if (
        terminal_traces + nonterminal_traces != counts["trace_paths"]
        or nonterminal_traces * 3 != counts["standalone_scores"]
    ):
        raise RuntimeError("trace/component scores counter domain mismatch")
    GUARD.verify_rows(refs)
    if GUARD.file_record(source) != before:
        raise RuntimeError("extraction changed during saved check")
    summary = {
        "schema": "quoridor.nnue-causal.descriptive-summary.v1",
        "target_sha256": saved["target_sha256"],
        "plan_sha256": saved["plan_sha256"],
        "input_extraction": before,
        "source_raw_map": refs,
        "counts": {
            "natural": natural_total,
            "forced": forced_total,
            "matched_natural": matched_natural,
            "requested_natural_UNKNOWN": natural_total - matched_natural,
            "matched_forced": matched_forced,
            "caller_admitted": len(all_callers),
            "caller_actual_invocations": sum(c["search_invocations"] for c in all_callers),
            "caller_accepted": sum(c["accepted"] for c in all_callers),
            "natural_forced_nodes": nodes,
            "combined_actual_node_settlement_or_liability": counts["deeper_node_liability"],
            "caller_aggregate_node_settlement": counts["deeper_node_liability"] - nodes,
            "caller_individual_nodes": "UNKNOWN",
            "common_tree_nodes": tree_nodes,
            "terminal_traces": terminal_traces,
            "nonterminal_traces": nonterminal_traces,
            "missing_requested_D6_NN6_traces": unknown_traces,
        },
        "receipt_range_ns": [
            min(c["authority_receipt_ns"] for c in all_callers),
            max(c["authority_receipt_ns"] for c in all_callers),
        ],
        "parents": parents,
        "source_after_unchanged": True,
        "reader_STOP": GUARD.now(),
        "ru_maxrss_KiB_reported": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "current_proc_status": {
            line.split(":")[0]: line.split(":")[1].strip()
            for line in Path("/proc/self/status").read_text().splitlines()
            if line.startswith(("VmHWM:", "VmRSS:", "VmSize:"))
        },
        "native_model_Search_calls": 0,
        "scientific_limits": "descriptive only; no cause/strength/optimaltruth/historicalgradient/FP32bitidenticalhead claim",
    }
    with (HERE / "descriptive-summary-v1.json").open("x") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "counts": summary["counts"],
                "receipt_range_ns": summary["receipt_range_ns"],
                "proc_status": summary["current_proc_status"],
                "STOP": summary["reader_STOP"],
            }
        )
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", action="store_true")
    args = parser.parse_args()
    if args.child:
        child()
        return
    GUARD.named_quiet()
    WORKER.physical()
    lease = os.open(GUARD.LOCK, os.O_RDWR | os.O_NOFOLLOW)
    try:
        GUARD.fcntl.flock(lease, GUARD.fcntl.LOCK_EX | GUARD.fcntl.LOCK_NB)
        GUARD.named_quiet()
        WORKER.physical()
        cp = GUARD.load_lifetime()
        os.sched_setaffinity(0, {4})
        resources = cp.CycleResources(
            {
                "max_memory_bytes": 512 * GUARD.MIB - 64 * GUARD.MIB,
                "host_ram_reserve": 4 * GUARD.GIB,
                "max_output_bytes": 2 * GUARD.GIB,
            },
            HERE,
            time.monotonic() + 120,
        )
        original_check = resources.check
        sampled = 0

        def check(owned=()):
            nonlocal sampled
            original_check(owned)
            infos = [cp.process_info(os.getpid()), *(cp.process_info(p["pid"]) for p in owned)]
            rss = sum(info["rss"] for info in infos if info)
            sampled = max(sampled, rss)
            if rss + 64 * GUARD.MIB > 512 * GUARD.MIB:
                raise RuntimeError(
                    "saved-analysis family plus64MiB controller reserve exceeds512MiB"
                )

        resources.check = check
        start = GUARD.now()
        record = cp.execute(
            [sys.executable, "-B", str(Path(__file__).resolve()), "--child"],
            HERE / "saved-check-v1.log",
            time.monotonic() + 120,
            cpu_core=3,
            resources=resources,
        )
        receipt = {
            "START": start,
            "STOP": GUARD.now(),
            "direct_record": record,
            "sampled_family_B_including64MiB_reserve": sampled + 64 * GUARD.MIB,
            "continuous_peak": "UNKNOWN",
            "readers_children_TMP_remaining": [],
            "scope": "new saved hierarchy/census/forced summaries only, no oldNN0/numeric/model replay",
            "TT_prior_dated_runtime_RELEASE": "c41aeb90 finished14:12:40.287309/cleanuptrue/remaining[], fresh namedquiet and nonblockingguard repeated",
        }
        with (HERE / "saved-check-STOP-v1.json").open("x") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")
        print(json.dumps(receipt))
    finally:
        os.close(lease)


if __name__ == "__main__":
    main()
