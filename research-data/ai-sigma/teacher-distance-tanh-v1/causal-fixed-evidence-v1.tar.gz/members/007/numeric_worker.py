"""One fixed diagnostic campaign; canonical lifetime helper owns the sole native child."""

import argparse
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import time

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("causal_software_guard", HERE / "software_worker.py")
GUARD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GUARD)


def validate(plan):
    if plan["schema"] != "quoridor.nnue-causal.numeric-entry.v1":
        raise RuntimeError("one fixed diagnostic entry schema")
    if plan["runtime"] != str(HERE / "control/numeric-runtime-v1"):
        raise RuntimeError("exact fresh numeric runtime")
    if plan["private"] != str(HERE / "private/software-v2/quoridor-runner"):
        raise RuntimeError("qualified current private only")
    if (
        plan["software_STOP"]["path"] != str(HERE / "qualified-software-STOP-v2.json")
        or plan["software_STOP"]["SHA256"]
        != "10431422b8744072705e5ed3916c378d8c44cf1e18ca9fc86815098ead032c7c"
    ):
        raise RuntimeError("software STOP coupling")
    expected = [
        plan["private"],
        "causal-diagnostic",
        "--control",
        plan["campaign"]["path"],
        "--control-sha256",
        plan["campaign"]["SHA256"],
    ]
    if plan["argv"] != expected or plan["CPU"] != 1 or plan["guardian_CPU"] != 4:
        raise RuntimeError("exact one campaign/CPU, no repeat/warmup/probe")
    if plan["whole_B"] != 2 * GUARD.GIB or plan["max_runtime_seconds"] is not None:
        raise RuntimeError("fixed resource support and no invented scientific horizon")


def physical():
    affinity = os.sched_getaffinity(0)
    identities = []
    for cpu in [1, 4]:
        if cpu not in affinity:
            raise RuntimeError("numeric CPU outside current affinity")
        base = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        identities.append(
            (
                (base / "physical_package_id").read_text().strip(),
                (base / "core_id").read_text().strip(),
            )
        )
    if identities[0] == identities[1]:
        raise RuntimeError("numeric/guardian logical siblings refused")
    memory = (
        int(
            next(
                line.split()[1]
                for line in Path("/proc/meminfo").read_text().splitlines()
                if line.startswith("MemAvailable:")
            )
        )
        * 1024
    )
    free = shutil.disk_usage(HERE).free
    quota = Path("/sys/fs/cgroup/cpu.max").read_text().split()
    ceiling = Path("/sys/fs/cgroup/memory.max").read_text().strip()
    if (quota[0] != "max" and int(quota[0]) < int(quota[1])) or (
        ceiling != "max" and int(ceiling) < 2 * GUARD.GIB
    ):
        raise RuntimeError("numeric quota/family2GiB unsupported")
    if memory < 6 * GUARD.GIB or free < 2 * GUARD.GIB:
        raise RuntimeError("fresh native family2GiB plus host4GiB/FS prerequisites")
    return {
        "at": GUARD.now(),
        "MemAvailable_B": memory,
        "FS_free_B": free,
        "physical_cores": list(zip([1, 4], identities)),
        "quota": quota,
        "memory_max": ceiling,
        "WSL_P_E_scheduler_isolation": "NOT_CERTIFIED",
    }


def execute(plan):
    validate(plan)
    GUARD.named_quiet()
    before_physics = physical()
    lease = os.open(GUARD.LOCK, os.O_RDWR | os.O_NOFOLLOW)
    try:
        GUARD.fcntl.flock(lease, GUARD.fcntl.LOCK_EX | GUARD.fcntl.LOCK_NB)
    except BaseException:
        os.close(lease)
        raise
    primary = None
    secondary = []
    runtime = Path(plan["runtime"])
    tmp = HERE / "TMP/numeric-v1"
    cp = None
    result = None
    allocation = GUARD.Allocation()
    sampled_family_max = 0
    source_after = None
    start = time.monotonic()
    try:
        GUARD.named_quiet()
        fresh = physical()
        GUARD.verify_rows(plan["inputs"])
        campaign = GUARD.bounded_json(plan["campaign"]["path"])
        if (
            campaign["output"] != str(HERE / "raw/campaign-v1")
            or campaign["target"]["sha256"]
            != "685afad305b9df49240453ff596e3e853f7a68f7c915c6e5aaf7a6d1fe3acb5f"
        ):
            raise RuntimeError("sole target/output binding")
        if campaign["limits"] != {
            "per_call_nodes": 8000000,
            "aggregate_nodes": 256000000,
            "shallow_nodes": 1000000,
            "search_calls": 144,
            "caller_windows": 12,
            "trace_paths": 18,
            "standalone_scores": 54,
        } or campaign["depths"] != [2, 4, 6]:
            raise RuntimeError("fixed exact smaller schedule and node/counter domains")
        software = GUARD.bounded_json(plan["software_STOP"]["path"])
        if (
            software["readers_children_TMP_remaining"]
            or software["private"]["SHA256"] != campaign["current_executable_sha256"]
            or software["compiled_sources_sha256"] != campaign["current_compiled_sources_sha256"]
        ):
            raise RuntimeError("actual stopped software/current image/source coupling")
        for path in [runtime, tmp, Path(campaign["output"])]:
            if path.exists():
                raise RuntimeError("one fresh named output/runtime/TMP; no overwrite/retry")
        GUARD.seed_allocation(allocation, software["positive_charges_B"])
        cp = GUARD.load_lifetime()
        os.sched_setaffinity(0, {4})
        runtime.mkdir(parents=True, exist_ok=False)
        tmp.mkdir(parents=True, exist_ok=False)
        Path(campaign["output"]).parent.mkdir(parents=True, exist_ok=True)
        os.environ.update(plan["environment"])
        os.environ["TMPDIR"] = str(tmp)
        resources = cp.CycleResources(
            {
                "max_memory_bytes": 2 * GUARD.GIB - 64 * GUARD.MIB,
                "host_ram_reserve": 4 * GUARD.GIB,
                "max_output_bytes": 2 * GUARD.GIB,
            },
            HERE,
            math.inf,
        )
        controller = cp.identity(cp.process_info(os.getppid()))
        original_check = resources.check

        def check(owned=()):
            nonlocal sampled_family_max
            original_check(owned)
            extra = (
                cp.process_info(controller["pid"]) if controller and cp.alive(controller) else None
            )
            infos = [cp.process_info(os.getpid()), *(cp.process_info(p["pid"]) for p in owned)]
            rss = sum(info["rss"] for info in infos if info) + (extra["rss"] if extra else 0)
            sampled_family_max = max(sampled_family_max, rss)
            if rss > 2 * GUARD.GIB:
                raise RuntimeError("native family plus controller exceeds2GiB")
            allocation.scan()

        resources.check = check
        cp.save_record(
            runtime / "actual-START.json",
            {
                "at": GUARD.now(),
                "identity": cp.identity(cp.process_info(os.getpid())),
                "physics": fresh,
                "before_physics": before_physics,
                "lease_inode": os.fstat(lease).st_ino,
                "campaign": plan["campaign"],
                "scope": "one same-target144inclusive/12windows/6trees/18paths/54scores native campaign, no retry/warmup",
            },
        )
        with cp.cancellation_signals():
            result = cp.execute(
                plan["argv"], runtime / "campaign.log", math.inf, cpu_core=1, resources=resources
            )
        report = GUARD.bounded_json(Path(campaign["output"]) / "campaign-result.json")
        if report["target_sha256"] != campaign["target"]["sha256"]:
            raise RuntimeError("result sole target provenance mismatch")
    except BaseException as error:
        primary = error
    finally:
        try:
            GUARD.verify_rows(plan["inputs"])
            source_after = {"at": GUARD.now(), "all_hash_size_mode_unchanged": True}
        except BaseException as error:
            secondary.append(
                {"stage": "source_after", "type": type(error).__name__, "error": str(error)}
            )
        if tmp.exists():
            try:
                shutil.rmtree(tmp)
            except BaseException as error:
                secondary.append(
                    {
                        "stage": "owned_TMP_cleanup",
                        "type": type(error).__name__,
                        "error": str(error),
                    }
                )
        try:
            charges = allocation.scan()
        except BaseException as error:
            charges = dict(allocation.charges)
            secondary.append(
                {"stage": "allocation_final", "type": type(error).__name__, "error": str(error)}
            )
        disk = None
        if runtime.exists():
            try:
                disk = GUARD.bounded_json(runtime / "campaign.process.json")
            except BaseException as error:
                secondary.append(
                    {
                        "stage": "direct_receipt_read",
                        "type": type(error).__name__,
                        "error": str(error),
                    }
                )
        stopped = {
            "at": GUARD.now(),
            "status": "PASS" if primary is None and not secondary else "FAILED",
            "whole_seconds": time.monotonic() - start,
            "nested_not_added": True,
            "primary_error": None
            if primary is None
            else {"type": type(primary).__name__, "error": str(primary)},
            "secondary_errors": secondary,
            "returned_command_record": result,
            "persisted_direct_record": disk,
            "source_after": source_after,
            "owned_TMP_remaining": [str(tmp)] if tmp.exists() else [],
            "positive_sampled_charges_B": charges,
            "sampled_family_max_B": sampled_family_max,
            "continuous_peak": "UNKNOWN",
            "prior_software_fees_held": 163.01345297694206,
            "prior_admin_overrun_held": 1.6539379729656503,
        }
        if cp and runtime.exists():
            try:
                cp.save_record(runtime / "owner-STOP.json", stopped)
            except BaseException as error:
                secondary.append(
                    {"stage": "STOP_persist", "type": type(error).__name__, "error": str(error)}
                )
        try:
            os.close(lease)
        except BaseException as error:
            secondary.append(
                {
                    "stage": "canonical_lease_close",
                    "type": type(error).__name__,
                    "error": str(error),
                }
            )
    if primary is not None:
        if secondary:
            primary.add_note("individual finalization facts: " + json.dumps(secondary))
        raise primary
    if secondary:
        raise RuntimeError("numeric finalization errors: " + json.dumps(secondary))
    return stopped


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha256", required=True)
    args = parser.parse_args()
    if GUARD.file_record(args.plan)["SHA256"] != args.plan_sha256:
        raise RuntimeError("immutable numeric control SHA")
    print(json.dumps(execute(GUARD.bounded_json(args.plan)), allow_nan=False))


if __name__ == "__main__":
    main()
