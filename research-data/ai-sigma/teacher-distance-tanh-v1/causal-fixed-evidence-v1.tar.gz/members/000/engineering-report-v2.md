# Fixed-position NNUE causal campaign: stopped evidence and interpretation limits

Task: quoridor-4lc.342.10. This is the one approved fixed campaign, not a strength evaluation or new training dataset. Saved hierarchy/census/forced-field verification is now complete. Independent combined causal interpretation review remains pending. The per-window caller instrumentation gap remains UNKNOWN; it cannot be filled from this stopped run.

The actual native campaign finished successfully, published its complete planned-stage packet, and released its hardware lease. All six original whole-history parents mapped to the current standard two-player plus automatic threefold convention with their original geometry and QF1+D bits. Historical RuleA outcomes remain historical. No replacement cases, labels, model changes, retries, warmup, calibration, depth rescue, games or fits were used.

Target SHA256: `685afad305b9df49240453ff596e3e853f7a68f7c915c6e5aaf7a6d1fe3acb5f`. Campaign SHA256: `7a2e85cd3813d6e11ea1e73aac95d290fe7eed1e95e869e520cf974a3d95f4f5`. Private image SHA256: `97c112388168b8a587c9f42c098373b34bf23e986794f52256208ad8f5113218`; 8,675,216 bytes, mode0755. Compiled-source digest: `eea393ff4480f18bcfb205d103b4e94f3c97554ea884669f6322de7a9e14b757`. BEST51 weights9ca438, manifestc471 and the historical D/80 logit parameterization remain unchanged. Core source clearance5492/cd844 and the earlier native/input/scale proofs are reused within their recorded scope.

## What the six cases currently show

Values below are search utility in the parent's side-to-move perspective. Terminal utility is ±2; nonterminal legacy predictions lie in [-1,1]. These are not new definitive research labels. Each `D / NN` pair uses identical requested depth, full history, PVS,4096 TT slots and the existing1MiB byte cap, with fresh identically defined sessions.

| Parent | Frozen original/D2/NN2 unique union | Depth2 action, value: D / NN | Depth4 action, value: D / NN | Depth6 status | Complete common depth2 tree value: D / NN | Timely caller actions: D / NN |
| --- | --- | --- | --- | --- | --- | --- |
| R3 |151,48|48,-2 /151,-2|48,-2 /151,-2|Both complete; same actions,-2| -2 / -2 |48 /151|
| R6 |21,169|21,-0.379949 /169,0.999780|21,-2 /21,-2|Both complete;21,-2| -0.379949 /0.999780 |21 /21|
| C1 |97,13|13,0 /13,0.0553334|13,0 /13,0.0375692|Both capped at8M nodes, completed5: requested6 UNKNOWN|0 /0.0553334|13 /97|
| C2 |58|58,0.291313 /58,1|58,0.291313 /58,1|Both complete;58,+2|0.291313 /1|58 /58|
| G1 |75|75,+2 /75,+2|75,+2 /75,+2|Both complete;75,+2|+2 /+2|75 /75|
| T1 |13,140,23|140,0.0996680 /23,0.224078|140,0.0996680 /23,0.167048|Both capped at8M nodes, completed5: requested6 UNKNOWN|0.0996680 /0.224078|140 /89|

R3 offers no rescuing legal first move at the common depth2 terminal-loss frontier. The two selected actions differ while their terminal value agrees; this parent cannot by itself demonstrate that a worse NNUE-selected move caused its historical defeat. Earlier decisions were not selected or reconstructed for this campaign.

R6 supplies a concrete horizon contrast: the NNUE depth2 score is close to +1 and prefers169; both completed depth4 searches report terminal loss and choose21. The D depth2 score is less optimistic, but neither D nor deeper consensus is a general truth oracle. This is a fixed-case observation, not a population calibration or strength estimate.

C2 supplies a counterexample to treating saturation alone as failure: its original-action child has a finite pre-tanh logit near-15.3964 and FP32 value-1 from the child's STM, while both depth6 searches return a parent terminal-win value+2. The child/parent perspectives must not be confused. C1 and T1 do not support depth6 matched comparisons; the saved completed5 values are not substituted for requested6.

G1 verifies the original legal immediate goal action75. T1 verifies the original legal third occurrence action13 with true terminal draw0, though the natural nonterminal evaluators prefer other moves. The fixed goal/draw traces bypass the neural head; they are anchors, not training labels or newly sampled outcomes.

## Forced alternatives, common trees and leaf components

The twelve initial depth2 proposal results were reused. Candidate unions were written and fsynced before deeper, forced or timed observations. Unique unions total11 moves, yielding36 natural plus66 forced invocations=102, below the144 upper ceiling. The unused42 ceiling slots arise from deduplicated smaller unions, not replacement runs. All102 invocations returned Ok; each of the66 forced rows is marked matched-complete, with terminal children qualifying independently of requested child depth. All66 saved forced rows have now passed child/parent sign and parent-restoration checks. Saved scope/census verification confirms32/36 natural requested depths complete, four requested6 results UNKNOWN,66/66 forced comparisons complete, and12/12 actual caller invocations/accepted receipts. No fresh Search was used.

All six common trees are reported COMPLETE, with58,679 expanded-or-leaf nodes and all legal first moves/responses evaluated by BOTH unchanged evaluators in one walk. Their depth2 minimax values agree with the completed depth2 natural results. Saved-JSON hierarchy checks now confirm negamax sign/max relationships, unique first moves/responses, terminal first-move utilities, root values and leaf/node counts. Every depth2 natural value matches its common-tree root value. This verifies the saved hierarchy; complete legal enumeration itself remains tied to the reviewed canonical source rather than a second geometry execution. Finite common-tree reference values compare these evaluators; nonterminal values do not prove optimal play.

Four requested D6/NN6 PV traces remain UNKNOWN because C1/T1 did not complete depth6. The other14 trace paths consist of eight terminal bypasses and six nonterminal component observations, using18 standalone scores. Nonterminal traces report preserved parent bits/history and the existing tolerance-based full/delta head predicate; this is not bit-identical full/delta output. Observed maximum FT difference reaches5.7220458984375e-6. Source predicate: `abs(full_post-delta_post) <= 1e-5 + 1e-4*abs(full_post)`.

The six nonterminal traces retain canonical D, residual, pre-tanh and post-tanh values. R3's original child has D≈+0.664037 versus NN≈-0.685730 from that child STM; R6's original child has D≈+0.291313 versus NN≈-0.992794. These are residual-driven sign differences in the actual legacy logit units, not evidence that tanh alone reverses exact ordering. FP32 ties/saturation and current objective gradients are separate questions. The artificial `1-v²` proxy in these traces is not an actual loss gradient. No historical training gradients were recovered or fabricated. The learner's separate stopped current32 singleton-MSE gradients can inform the combined review only within their own known-label, original-objective scope.

Observer setup/update and single-head spans remain intrusive measurements. They do not identify plain caller CPU shares or arithmetic throughput. Different node/TT histories are expected under changed evaluator rankings; they do not establish speed of arithmetic or strength.

## Authority receipts and a real instrumentation gap

All twelve immutable action receipts are legal and accepted, around95.069..95.350ms. The100ms thinking allowance ends at authority receipt; legality is outside it. Each recorded matching reply was drained before the next caller. No late receipt, error, timeout forfeit or legal-draw reinterpretation occurred in these windows.

However, the current caller record saves action/receipt/legality/drain/fullcaller and TT/initialization/invocation spans, but drops the returned SearchResult after its aggregate node settlement. Per-window actual completed depth, nodes, root value and PV are therefore UNKNOWN in the saved evidence. TT `usable_depth` is not substituted for completed depth, and setup/head/delta shares are not inferred. The C1/T1 timed action differences do not establish a matched-depth disadvantage. There will be no replay of these twelve windows to fill this gap. A future ordinary logging repair can retain the returned result without changing its ordered body or policy, but any new measurements require their own explicit finite workload.

## Lifetime, resources and retained failures

Controller START14:01:43.786889; guardian START14:01:44.021678; sourceSTOP14:02:42.197494; guardianSTOP14:02:42.204378; controllerSTOP14:02:42.232075 UTC. Native child2756856/start80774013 and guardian2756831/start80773988 are freshly absent after exact directwait and handle/process cleanup[]. Source151 hashes/modes/sizes matched afterward. Owned TMP is gone, publication INCOMPLETE is absent, and current-next Cargo/model/Search/fair reservation is NONE. Returned signal-mask restoration is completed while the persisted record still says pending; both are retained distinctly.

Native controller whole58.457688516s; child57.999586009s is nested and not added. Prior software whole163.013452977s includes the original failed32.899164621s. Joined known controller fees221.471141493s; guard and saved-extraction fees remain separate. Earlier budgets/errors/raw/UNKNOWN are not refunded. The release's121.653937973s command lifetime exceeded its120s administrative bound by1.653937973s: retained FAILED cap history, not retroactively Within, and not erased by successful software proofs.

Native sampled family97,226,752B is below the admitted2GiB; continuous peak is UNKNOWN. Positive retained charges: target746,287,104/private8,687,616/raw6,889,472/control3,399,680/TMP13,619,200B, plus held source/Git floor18,333,696B, all within the engineering2GiB support a380. Vanished TMP gives no credit.

The first saved extraction ran under AS512MiB and completed in0.074123775s, but reported `ru_maxrss825768KiB`, above the practical512MiB allowance. Its actual continuous family peak and timing extent are UNKNOWN; no current-RSS family sample was retained. This is held as a reported memory-budget gap, not a compliance certificate or a scientific diagnosis. Future substantive saved checks must use the maintained lifetime helper with an actual family512MiB guard. No numerical or model replay is needed.

Other retained preparation gaps: an unused-import Ruff refusal was mistakenly followed by metadata preparation, corrected by scoped Ruff and a unique unrun-control rebind; initial software-result private hashing occurred before a fresh quiet guard. Neither is relabelled as zero cost or blanket compliant. All subsequent substantive campaign preparation and the numeric worker repeated source/proof/physical/quiet/nonblocking lifetime guards.

Exact native STOP receipt: `numeric-STOP-v1.json`. Exact before/after saved raw maps and extracted fields: `saved-extraction-v1.json` (476,216B), with completed selected-field/hierarchy/census checks in `descriptive-summary-v1.json`; raw/result and candidate freeze remain immutable. The v1 extraction mistakenly used a nonexistent historical action key and therefore contains null in that convenience field. The corrected descriptive summary takes the original action from the reviewed original-first frozen union and binds the original target; no original source/action was changed. Software proof: `qualified-software-STOP-v2.json`. No source/main/Git/model/TT/PVS/teacher/default/seal/N/323pause changes were made during collection.


### Completed forced alternatives and tie observations

R6 action21 has parent-depth2 D=-0.379949 and NN=+0.998592; action169 has D=-0.462117 and NN=+0.999780. Both alternatives at parent-depth4/6 return-2 for BOTH evaluators. The common tree gives D a21/29 tie and NN a unique169 best move. This distinguishes a shallow evaluator preference from the deeper terminal loss; it is not evidence that21 rescues the selected parent.

C1 forced13 beats the original97 under BOTH evaluators at each requested parent-depth2/4/6: D(13)=0 versus D(97)=-0.099668; NN(13)=0.0553334/0.0375693/-0.160731 versus NN(97)=-0.453678/-0.352490/-0.252497. These forced subtrees complete even though the full natural depth6 roots do not. Thus the100ms NN action97 differs from its completed fixed-depth candidate preference, but missing caller depth makes a matched-depth/time-budget explanation unavailable.

T1 original13 is a legal terminal draw0 at all three forced parent depths. D forced140=0.0996680/0.0996680/0 and23≈0.0996680 at2/4/6. NN forced140=-0.373075/-0.259558/-0.297804 versus23=+0.224079/+0.167048/+0.198251. These are different learned candidate rankings, not adjudicated outcomes for the nonterminal alternatives. The depth2 common D140 and D23 values differ at FP32 precision; exact ties are not invented. C2's common NN tree has three exact+1 tied moves40/48/58, while D uniquely prefers58. Its actual selected58 still wins in the deeper search; saturation/ties alone do not prove bad choice or learning failure.

The complete common trees confirm all90 R3 legal first moves tie at-2 for both evaluators. The frozen union contains only151/48 because selecting additional moves after seeing that fact was forbidden. G1 forced75 and T1 forced13 report terminal stop,0 child nodes and neural bypass at every nominal parent depth; no extra terminal Search computation was generated.

Natural/forced actual nodes total59,420,281. The settled combined domain is60,636,762, and all12 callers returned successful results with no errors; subtracting the natural/forced domain gives1,216,481 caller nodes in aggregate. Individual window allocations/depths/values/PVs remain UNKNOWN. This aggregate is not a per-window speed estimate.

The final saved check ran START14:25:09.521817..STOP14:25:09.702824, one direct child exit0/reaped/handle+processcleanup[],0 model/native/Search calls. Child lifetime0.166344730s; outer interval is separate, not added as an additional scientific run. Sampled child+guardian+64MiB controller reserve121,040,896B<512MiB; child VmRSS34,420KiB/VmHWM36,268KiB/AS512MiB, continuous family peak UNKNOWN. The prior825,768KiB report is not erased or reclassified by this later sample. Exact receipt: `saved-check-STOP-v1.json`.

## What remains and the next decision

The saved per-action/hierarchy/counter checks are complete. TT351 named runtime c41aeb90 recorded completion14:12:40.287309/cleanuptrue/remaining[]; the new check repeated its own fresh quiet/physical/nonblocking canonical lease predicates before its direct child, without a whole-owner or Root reply gate. Request the appropriate existing independent reviewer through324 for the fixed combined causal interpretation, including learner current-gradient evidence and the two explicit instrumentation/resource gaps. Source model/algorithm proofs and passed suites are reused, not replayed.

The evidence distinguishes terminally lost selected parents, horizon-sensitive optimistic estimates, legitimate saturation and incomplete deeper searches. It does not isolate a universal failure cause or certify training changes. The immediate useful action is to review these limited observations and the remaining fields before selecting any new workload or learning change. Human N/fullschedule/pilotmix/fourfits96/defaults/seals/USERPAUSE323 remain unchanged.
