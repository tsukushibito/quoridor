Diagnostic-only .77 current version2. No independent acceptance or coordinator freeze issued. NN0/Chromium0/holdout0.
