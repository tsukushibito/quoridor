EXPERIMENT_REPORT SIGMA-FAIR-STREAMING quoridor-4lc.65 暫定

17:20:23UTC受領/本人claim/開始。処理18:45:23、新job18:40:23、提出19:00:23。親版2と契約全文確認。両側caller T500/reserve89/cutoff402/seal411固定、原探索係数/NN/model不変、新copyのみ。actual_go=false/game0/holdout0。初期stop JSON先保存、CPU2/RAM4/新128guard112既entry予約内・追加予約0。原.63は限定受入れ理由と旧340秒等を保持し本人close、.64他者変更0。
