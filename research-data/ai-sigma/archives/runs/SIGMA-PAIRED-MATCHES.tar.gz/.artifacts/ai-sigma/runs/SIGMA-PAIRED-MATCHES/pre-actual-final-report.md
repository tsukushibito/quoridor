# SIGMA-PAIRED-MATCHES / 試行1 / 版2 準備報告

quoridor-4lc.21 experiment → coordinator。critic .20 no-goを受け、隔離copyへ実producer transaction echo/caller照合・per-hand無応答watchdog・共通game/pair loopを実装。独立gateへの準備提出であり、accepted/採用/対局goではない。holdout送信・正式game・勝敗観測0。T500/g91は候補、旧事前登録v1を保持しv2のseed抽出8index/16block/32gameを独立再計算一致。.15は.19/統括の限定受入れ理由で本人close、.7採用保留。.21は受入れ待ちin_progress。

producerが実処理したrequest ID/generationをechoし、callerがpending identityを照合してから合法Actionを確認。一意IDがimmutable prefixへbind、同gen foreign-ID/wrong-gen/unknown/null/exit/late/旧応答を拒否。T watchdogは世代を無効化し即structured discard、自己backend停止/waitは別cleanupとしreuse禁止。timer早起きはmonotonic期限を再確認。再起動は旧cleanup完了後のstartup/load/warmが必要。NN/kernel/Wasm/PUCT/weights不変、native main差分はechoのみ、新lockは旧134packageの全version/checksum保持、offline/locked build。参照transport/NN失敗分類を分け、原因未詳無応答を都合よくinvalidへ変えない。

最終mock42件通過（3engine取引/無応答/exit/late、cleanup未応答でもtimeout、SIGTERM回収、既知goal先後score、人工draw/goal優先、terminal prefix拒否、timeout/illegal loss、同prefix pair retry）。実native/両Worker固定golden warm1+sample1×3case計18＋合法goal3=21要求は合法期限内/fallback0、終端NN0。goldenのみ4ply loopはoutcome未観測で停止。3case features1944f32bitsはnative/Wasm/参照exact、NN/prior1594比較失敗0（abs1e-4+rtol1e-4、最大8.822e-6）。実native T10/500ms遅延注入は10.654msでdiscard、Action公開0。

未完了/失敗を保持: build監視の一時directory消滅例外で自己group停止、修正build1回exit0。runtime初回は成功診断後network callback ReferenceError、修正retryでもSIGTERM済みnativeのexit再待機で停止処理が停滞し自己NodeをSIGTERM/reap、exit143。signalCode条件を修正、第三NN反復0。実T10 watchdogのtimerは早起きしており、最終recheck/即discardとcleanup修正はmockのみ確認。**新criticは最終sourceで実境界を再実行する必要あり。全面runtime成功や時計安全を主張しない。** 32game schedule実行/restart統合未実行、adapter/game/pair exportsのみ。旧深部overlay/arena/実200/no-legal/rawview/entropy/学習重複不明も保持。

全自己NN/build/Node/Chrome/helper PID0をruntime-stopped.jsonに先保存、197旧入力hash不変。観測RSS最大2,299,367,424B、追加logical669,597,674B/allocated674,217,984B、所有保守3,591,921,664B（提出小文書増分別）、guard内。準備CPU2,4/jobs2、runtime CPU2、観測affinity訂正0、GPU/取得/学習/他者kill0。初回build例外以降のpeak欠測・50ms瞬間peak欠測を保持、背景SMT/host負荷を保存し正式無競合とは呼ばない。

詳細source/patch/binaryhash/raw/limits/clock/PIDstarttick/exit/資源は `.artifacts/ai-sigma/runs/SIGMA-PAIRED-MATCHES/ready-for-independent-gate.json`、再現は `tools/ai-sigma-arena-matches/README.md`。新native SHA9a7e768af5e6fdc58c16b5cc1e7c42df16372ff1654fef3503f410b402635b68。A共通Rust/B分離ORT/C B0を残す。書込停止/backup/report後、**新critic受入れと統括actual run/freeze steer両方まで対局開始0**。処理00:45/提出01:00/全体01:17:58延長0。

追補: 32game entry/restartをmock-onlyで実装確認。今回source版と旧.22入力を区別するentry-ready.json / entry-ready-report.md参照。実NN境界/復旧未再検証、実対局0。
