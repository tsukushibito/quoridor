# SIGMA-PAIRED-MATCHES / 契約版2 / entry準備追補

quoridor-4lc.21 experiment → coordinator / critic .22。先23:09 frozen版をentry-prior-snapshot/sourceとhashes.jsonへ不変保存。今回版はentry-source-final/entry-ready.json。現在の.22旧入力gateと新版を混同しない。

match-entry.cjsを追加。importではengine起動0、require(main)の--runと統括freeze tokenを必須にし、coordinator/critic .22受入れ証拠・preregister-v2/最終manifest SHA・T500/g91・00:45停止を照合。token未提供/既存run directoryでは起動拒否。予定16block32game全採番、同prefix先後・seed1979固定、pair retry1/global retry2、各ply request/raw/judge/attempt/results JSONL・atomic checkpoint・結果table・platform別完成mを保存。無応答/engine crashはreason付きloss、model/IPC infrastructureはpair invalid。partial mを正式成功にしない。Beads pause/PAUSE file・signal・deadlineを確認し着手開始に1.5s停止reserve。

復旧は旧cleanup完了と自己descendant PID0を確認してからstartup/load/warm/再時計校正。各sessionのstartup/clock/stderrは別path。参照warmは固定initial golden1件、native/candidateは既存load warm。pipe.abort/closeは既終了signalCodeも確認しidempotent、abortには自己child SIGKILL escalationも持つ。source/kernel/NNbinary/weights変更0。

mock wireだけで32game全採番/同prefix/先後/seed、二つのpair infrastructure fault→globalretry2、無応答loss後restart、retry exhausted、pause/deadline、既SIGTERMへの反復abort/closeをassert、最終dry pass。mock数値は人工scoreであり実勝敗0。初回dryのInfinity deadlineによるDate表記例外、次のmock log相対path例外を別attempt証拠に保持し修正。NN/build/実holdout engine送信/実対局0。実cleanup/restart/warm/校正の新版runtimeは未実行、新critic確認が必要。

全自己dry child回収/PID0、旧snapshot hash不変。詳細gate/採番/復旧/全ply mock/資源/exitはentry-dry-gate.jsonと各entry-dry-*/process.json。23:20目安のentry-ready提出、書込停止・Beads backup後送信。新critic受入れ＋統括actual run/freeze steerまで勝敗0。.21 in_progress、期限/予算延長0。先報告の失敗/未完了/限定受入れを保持。
