# SIGMA-PAIRED-MATCHES / 契約版2 / revision3

quoridor-4lc.21 experiment → coordinator。.22報告全文/summaryを読みno-go継承。候補native/WasmのMODEL_HASH・NNerror・nonzero fallbackは候補loss、fixed referenceの同障害だけpair invalid。実wrapper response.engineをpending transactionに結び付け、runGameが選択engineとの一致を検査。identity/referee IPCは共通infra invalid、deadline/無応答/crash/lateはlossを保持。参照sourceのmodel_not_ready/feature_shape_finite/output_shape/output_finite_value/nn_empty_legal/ORT run例外を確認、deadline/guard/no_checkpoint/cancelledとは区別。固定分類mock33件pass、旧誤分類source/証拠をrevision3/source-before等へ保存。

同じmatch-entry realBackendを固定initial専用diagnostic exportで使用し、1回だけ2sessionsのload/warm/reclock→三engine各1 T500/g91→nativeT10/stepdelay500→stop/wait/PID0→fresh三engine各1を完遂。6/6合法期限内/fallback0、fresh3/3。elapsed(ms):初420.326/446.213/418.783、fresh414.497/447.694/413.043（native/Wasm/reference順）。T10は13.491msでNO_RESPONSE_TIMEOUT、Action0、超過救済0。両session own descendant PID0をstop proofで確認、startup/clock/stderr/transport/rawは別path。tail保証・無競合・性能改善・棋力達成ではない。.22元fresh failure/期限guard停止は不変保持。

独立entry export executeからmock-only32採番/同prefix先後/seed/retry1-global2/停止を新版sourceで1回pass。NNkernel/model/nativebinary/Wasm/PUCT/T500g91/preregister不変、compile/取得/GPU/holdout実送信/実対局0。runtime90秒cap/CPU2/RAM4、job正常終了。観測peak2,013,110,272B、affinity訂正0、50ms瞬間peak欠測限界を保持。

旧entry-ready.json SHA74504e…db22と旧snapshotを保持。main/verifyTokenは固定entry-ready-revision3.jsonのみを検証、actual coordinator freeze tokenのentry_manifest_sha256を新版実bytesSHAへ結ぶ。新criticは.23固定、旧.22受入れhashで新source起動不可、token未提供/既run directory拒否を保持。実integration後のmain差分はこのmanifest/critic固定だけ、realBackend/診断body同一性と実行時hashへ一致する復元sourceを保存。

詳細revision3/input-before.json/classify-gate/integration.json/integration-summary/entry-dry-gate/runtime-stopped/source-finalとrev3 process/log、entry-ready-revision3.json。自己NN/Chrome/native/helper全PID0を先保存、以降新runtime0。新source write停止/backup/report、.21 in_progress。統括＋新critic最終gate/actual freeze steerまで実run禁止、処理23:36/提出23:40・全体deadline延長0。
