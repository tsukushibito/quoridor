# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase3-ai.spec.ts >> undo and new game cancel the AI result animation without stale completion
- Location: tests/e2e/phase3-ai.spec.ts:180:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Object {
-   "phase": "animating",
+   "phase": "humanTurn",
    "ply": 2,
  }

Call Log:
- Timeout 20000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - main:
    - generic:
      - generic [ref=e3]:
        - generic [ref=e4]:
          - heading "先手・丸い駒の手番" [level=1] [ref=e6]
          - generic [ref=e7]: 2 手目
          - paragraph [ref=e8]: AIと対戦 · 先手
        - generic [ref=e9]:
          - generic [ref=e10]:
            - generic [ref=e11]: ●
            - generic [ref=e12]:
              - strong [ref=e13]: 先手・丸い駒
              - generic [ref=e14]: 残りの壁 10 枚
          - generic [ref=e15]:
            - generic [ref=e16]: ⬡
            - generic [ref=e17]:
              - strong [ref=e18]: 後手・六角の駒
              - generic [ref=e19]: 残りの壁 10 枚
      - navigation "対局" [ref=e20]:
        - button "すべての音を消す" [ref=e21] [cursor=pointer]:
          - generic [aria-hidden]: すべての音を消す
        - button "やり直す" [ref=e25] [cursor=pointer]:
          - generic [aria-hidden]: やり直す
        - button "新しい対局" [ref=e28] [cursor=pointer]:
          - generic [aria-hidden]: 新しい対局
        - button "遊び方" [ref=e32] [cursor=pointer]:
          - generic [aria-hidden]: 遊び方
        - button "設定・保存" [active] [ref=e36] [cursor=pointer]:
          - generic [aria-hidden]: 設定・保存
    - generic:
      - generic:
        - generic "3Dコリドール盤" [ref=e40]
        - generic:
          - generic: 9 × 9
          - paragraph: 光るマスをクリックして移動。矢印キーとEnterでも操作できます。
      - generic [ref=e42]:
        - generic [ref=e43]:
          - generic [ref=e44]:
            - button "駒を動かす" [pressed] [ref=e45] [cursor=pointer]
            - button "壁を置く" [ref=e46] [cursor=pointer]
          - 'button "壁の向き: 横向き R" [ref=e47] [cursor=pointer]'
        - button "1手戻す" [ref=e48] [cursor=pointer]
```

# Test source

```ts
  96  |   await clickCell(page, 75);
  97  |   expect((await state(page)).view?.positionKey).toBe(key);
  98  |   await page.getByRole('button', { name: '1手戻す' }).click();
  99  |   expect((await state(page)).phase).toBe('humanTurn');
  100 |   expect((await state(page)).view?.ply).toBe(final.view!.ply - 2);
  101 |   await restartMatch(page);
  102 |   await waitHuman(page);
  103 |   expect((await state(page)).view?.ply).toBe(1);
  104 |   mkdirSync('artifacts', { recursive: true });
  105 |   await page.screenshot({ path: `artifacts/phase3-${process.env.E2E_MODE || 'dev'}-desktop.png`, fullPage: true });
  106 |   await page.setViewportSize({ width: 390, height: 844 });
  107 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  108 |   await page.locator('#new-game').click();
  109 |   await expect(page.locator('#match-mode')).toBeVisible();
  110 |   await expect(page.locator('#human-side')).toBeVisible();
  111 |   await expect(page.locator('#ai-budget')).toBeVisible();
  112 |   await page.screenshot({ path: `artifacts/phase3-${process.env.E2E_MODE || 'dev'}-narrow.png`, fullPage: true });
  113 | });
  114 | 
  115 | test('human first and AI second complete a standard game through pointer input', async ({ page }) => {
  116 |   test.setTimeout(120_000);
  117 |   await configure(page, 0, '48');
  118 |   await openMenu(page);
  119 |   await page.locator('#no-animation').check();
  120 |   await closeMenu(page);
  121 |   for (let i = 0; i < 100; i++) {
  122 |     const current = await state(page);
  123 |     if (current.phase === 'finished') break;
  124 |     expect(current.phase).toBe('humanTurn');
  125 |     const pawn = current.view!.pawns[0]!;
  126 |     const legal = current.view!.legalMask;
  127 |     const target = [3, 4, pawn + 1, pawn - 1, pawn + 9, pawn - 9]
  128 |       .find(id => id >= 0 && id <= 80 && id !== pawn && legal[id] === 1);
  129 |     expect(target).toBeDefined();
  130 |     await clickCell(page, target!);
  131 |     await expect.poll(() => state(page).then(s => s.phase), { timeout: 20000 }).toMatch(/humanTurn|finished/);
  132 |   }
  133 |   const final = await state(page);
  134 |   expect(final.phase).toBe('finished');
  135 |   expect(final.view?.winner).toBe(1);
  136 |   expect(final.view?.legalMask.every(bit => bit === 0)).toBe(true);
  137 | });
  138 | 
  139 | test('cancel, retry, undo, and PvP fallback during real AI thought preserve the board', async ({ page }) => {
  140 |   await configure(page, 0, '4096');
  141 |   await openMenu(page);
  142 |   await page.locator('#no-animation').check();
  143 |   await closeMenu(page);
  144 |   await clickCell(page, 13);
  145 |   const first = await state(page);
  146 |   expect(first.view?.ply).toBe(1);
  147 |   expect(first.phase).toBe('aiThinking');
  148 |   await page.getByRole('button', { name: '1手戻す' }).click();
  149 |   expect((await state(page)).view?.ply).toBe(0);
  150 |   await page.waitForTimeout(350);
  151 |   expect((await state(page)).view?.ply).toBe(0);
  152 |   await clickCell(page, 13);
  153 |   expect((await state(page)).phase).toBe('aiThinking');
  154 |   // Deliver the user's cancel click promptly, before a fast local Worker finishes.
  155 |   await page.locator('#cancel-ai').evaluate((button: HTMLButtonElement) => button.click());
  156 |   expect((await state(page)).phase).toBe('recoverableError');
  157 |   const key = (await state(page)).view?.positionKey;
  158 |   await page.waitForTimeout(350);
  159 |   expect((await state(page)).view?.positionKey).toBe(key);
  160 |   await page.getByRole('button', { name: 'AIを再試行' }).click();
  161 |   expect((await state(page)).phase).toBe('aiThinking');
  162 |   await page.locator('#cancel-ai').evaluate((button: HTMLButtonElement) => button.click());
  163 |   await page.getByRole('button', { name: '2人対戦に切り替える' }).click();
  164 |   expect((await state(page)).matchMode).toBe('pvp');
  165 |   expect((await state(page)).phase).toBe('humanTurn');
  166 |   await configure(page, 0, '4096');
  167 |   await clickCell(page, 13);
  168 |   expect((await state(page)).phase).toBe('aiThinking');
  169 |   await restartMatch(page);
  170 |   await page.waitForTimeout(350);
  171 |   expect((await state(page)).view?.ply).toBe(0);
  172 |   await clickCell(page, 13);
  173 |   expect((await state(page)).phase).toBe('aiThinking');
  174 |   await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.disposeForTest());
  175 |   await page.waitForTimeout(350);
  176 |   expect((await state(page)).phase).toBe('disposed');
  177 |   expect(await page.locator('#board canvas').count()).toBe(0);
  178 | });
  179 | 
  180 | test('undo and new game cancel the AI result animation without stale completion', async ({ page }) => {
  181 |   test.setTimeout(60_000);
  182 |   await page.clock.install();
  183 |   await configure(page, 0, '4096');
  184 |   await openMenu(page);
  185 |   await page.locator('#no-animation').check();
  186 |   await closeMenu(page);
  187 |   const opening = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.exportReplay());
  188 |   for (const operation of ['undo', 'new', 'load'] as const) {
  189 |     await clickCell(page, 13);
  190 |     expect((await state(page)).phase).toBe('aiThinking');
  191 |     await openMenu(page);
  192 |     await page.locator('#no-animation').uncheck();
  193 |     await closeMenu(page);
  194 |     await page.clock.pauseAt(await page.evaluate(() => Date.now() + 10_000));
  195 |     await expect.poll(() => state(page).then(s => ({ phase: s.phase, ply: s.view?.ply })), { timeout: 20000 })
> 196 |       .toEqual({ phase: 'animating', ply: 2 });
      |        ^ Error: expect(received).toEqual(expected) // deep equality
  197 |     expect(await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.resources().animating)).toBe(true);
  198 |     if (operation === 'undo') await page.getByRole('button', { name: '1手戻す' }).click();
  199 |     else if (operation === 'new') await restartMatch(page);
  200 |     else await page.evaluate(async replay => window.__QUORIDOR_APP_TEST_API__!.restoreReplay(replay, 'pvp', 0), opening);
  201 |     await page.clock.resume();
  202 |     await page.waitForTimeout(260);
  203 |     expect((await state(page)).view?.ply).toBe(0);
  204 |     expect(await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.resources().animating)).toBe(false);
  205 |     if (operation === 'load') break;
  206 |     await openMenu(page);
  207 |     await page.locator('#no-animation').check();
  208 |     await closeMenu(page);
  209 |   }
  210 | });
  211 | 
```