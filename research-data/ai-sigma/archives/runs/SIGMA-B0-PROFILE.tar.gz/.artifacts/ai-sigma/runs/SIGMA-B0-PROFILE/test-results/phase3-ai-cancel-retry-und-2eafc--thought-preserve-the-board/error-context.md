# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase3-ai.spec.ts >> cancel, retry, undo, and PvP fallback during real AI thought preserve the board
- Location: tests/e2e/phase3-ai.spec.ts:139:1

# Error details

```
Test timeout of 30000ms exceeded while running "beforeEach" hook.
```

```
TypeError: Cannot read properties of null (reading 'newPage')
```