# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase3-ai.spec.ts >> AI first opening, responsive controls, and full UI game
- Location: tests/e2e/phase3-ai.spec.ts:65:1

# Error details

```
Test timeout of 30000ms exceeded while running "beforeEach" hook.
```

```
TypeError: Cannot read properties of null (reading 'newPage')
```