# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase3-transport.spec.ts >> transport resolves ready/search on restart and dispose, rejects current corruption, ignores stale tags
- Location: tests/e2e/phase3-transport.spec.ts:11:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Target page, context or browser has been closed
Call log:
  - waiting for locator('#startup-new-game')
    - locator resolved to <button type="button" class="accent" id="startup-new-game">新しく遊ぶ</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed

```

```
Error: write EPIPE
```