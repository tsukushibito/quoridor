# SIGMA-ORT-SEARCH 暫定報告

quoridor-4lc.26 / 試行1 / 契約版1 / experiment。claim済み、pauseなし。旧.15/.21入力をhash固定し新workspaceで着手。共有製品ソース変更0・追加対局0。初期自己NN/build PID0を initial-stopped.json に保存。

設計: 元Rust kernelをコピーし、leaf/path/context/legalを所有するpending継続を追加。beginは評価完了前visits/backupを進めず、resumeで検証済み出力を一度だけ適用。cap fallbackも同境界、error/cancel/stale/duplicateはdiscard。同期spyとの厳密一致を最初のgateとする。競合A tract/B分離ORT/C B0を保持。処理01:35/提出01:45、親04:00延長で過去逸脱の遡及成功なし。
