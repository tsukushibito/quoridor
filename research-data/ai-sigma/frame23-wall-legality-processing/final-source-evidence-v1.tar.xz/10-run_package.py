"""Frozen binary fixed-work package: micro, forward order, then reverse order."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path("/workspaces/quoridor")
DATA = ROOT / "research-data/ai-sigma/frame23-wall-legality-processing"
TARGET = ROOT / ".artifacts/rust-migration/target"
OUT = DATA / "package-r1"
OUT.mkdir(exist_ok=False)
REG = json.loads((DATA / "preregister-v4.json").read_text())
assert REG["task"] == "frame23-wall-legality-288-v1"
assert os.environ.get("ORT_DISABLE_TELEMETRY") == "1"
for path, wanted in REG["fixed_payload_SHA"].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == wanted, path
records = []
nn = processed = 0
micro_work = quality_children = 0
start = time.monotonic()
for name, variant, cfg, mode in REG["package_order"]:
    binary = str(TARGET / f"release/examples/wall_work_{variant}288")
    argv = [binary, str(DATA / cfg), mode]
    before = time.monotonic()
    with (OUT / f"{name}.jsonl").open("w") as out, (OUT / f"{name}.stderr").open("w") as err:
        child = subprocess.Popen(argv, stdout=out, stderr=err)
        stat = (Path("/proc") / str(child.pid) / "stat").read_text().rsplit(")", 1)[1].split()
        identity = {"pid": child.pid, "tick": stat[19]}
        (OUT / f"{name}-start.json").write_text(
            json.dumps(
                {
                    "identity": identity,
                    "argv": argv,
                    "binary_SHA": hashlib.sha256(Path(binary).read_bytes()).hexdigest(),
                },
                indent=2,
            )
            + "\n"
        )
        rc = child.wait(timeout=max(0.1, 110 - (before - start)))
    record = {
        "name": name,
        "variant": variant,
        "mode": mode,
        "argv": argv,
        "identity": identity,
        "exit": rc,
        "waited": True,
        "wall_s": time.monotonic() - before,
    }
    records.append(record)
    (OUT / "all-attempts.json").write_text(json.dumps(records, indent=2) + "\n")
    if rc:
        raise RuntimeError(f"{name} exited{rc}; no success substitution")
    rows = [json.loads(line) for line in (OUT / f"{name}.jsonl").read_text().splitlines()]
    assert all(row["task"] == REG["task"] for row in rows)
    summary = rows[-1]
    assert summary["schema"] == "wall-work-summary-v1" and summary["mode"] == mode
    nn += summary["NN"]
    processed += summary["processed"]
    for row in rows:
        if row.get("kind") == "micro":
            micro_work += row["singleplay_count"] + sum(v["iterations"] for v in row["cost"])
        if row.get("kind") == "quality":
            quality_children += row["legal_count"]
    assert processed + micro_work + quality_children <= 250000
    assert nn <= REG["NN_upper"] <= 50000 and processed <= 250000
    record["NN"] = summary["NN"]
    record["processed"] = summary["processed"]
    (OUT / "all-attempts.json").write_text(json.dumps(records, indent=2) + "\n")


def rows(name, kind):
    return [
        r
        for r in map(json.loads, (OUT / f"{name}.jsonl").read_text().splitlines())
        if r["kind"] == kind
    ]


matches = []
for stage, b, c in [
    ("forward", "baseline-main", "candidate-main"),
    ("reverse", "baseline-reverse", "candidate-reverse"),
]:
    br, cr = rows(b, "ab"), rows(c, "ab")
    assert len(br) == len(cr)
    for x, y in zip(br, cr):
        identity = ["name", "engine", "sample", "key"]
        meaning = [
            "action",
            "value_bits",
            "depth",
            "stop",
            "pv",
            "nodes",
            "evaluations",
            "native_NN",
            "TT_hits",
            "TT_cutoffs",
            "terminal",
            "delta_updates",
        ]
        assert all(x[k] == y[k] for k in identity + meaning), (x, y)
        matches.append(
            {
                "stage": stage,
                "name": x["name"],
                "engine": x["engine"],
                "sample": x["sample"],
                "warmup": x["warmup"],
                "baseline_ns": x["elapsed_ns"],
                "candidate_ns": y["elapsed_ns"],
                "ratio": y["elapsed_ns"] / x["elapsed_ns"],
                "depth": x["depth"],
                "nodes": x["nodes"],
                "native_NN": x["native_NN"],
                "meaning_same": True,
            }
        )
result = {
    "task": REG["task"],
    "schema": "wall-work-package-result-v1",
    "PASS": True,
    "NN": nn,
    "processed_search_nodes": processed,
    "processed_total_charged": processed + micro_work + quality_children,
    "micro_caller_iterations_and_play_calls": micro_work,
    "quality_children": quality_children,
    "science_jobs": 1,
    "planned_prefixes": 4,
    "search_pairs": matches,
    "all_attemps": records,
    "model_forward_recertification": False,
    "fullteacher_Rjoint": "NOT_MEASURED",
    "whole_production_gain": "NOT_MEASURED",
    "future_labels_read": False,
    "wall_s": time.monotonic() - start,
}
(OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in ["search_pairs", "all_attemps"]}))
