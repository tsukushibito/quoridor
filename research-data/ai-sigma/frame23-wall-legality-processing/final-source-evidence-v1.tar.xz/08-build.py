"""Bounded offline two-binary build; restore candidate even after compiler failure."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path("/workspaces/quoridor")
WT = ROOT / ".worktree/frame21-search"
DATA = ROOT / "research-data/ai-sigma/frame23-wall-legality-processing"
TARGET = ROOT / ".artifacts/rust-migration/target"
CORE = WT / "crates/quoridor-core/src/position.rs"
CANDIDATE = gzip.decompress((DATA / "core-candidate-v2.rs.gz").read_bytes())
BASELINE = gzip.decompress((DATA / "core-baseline-v1.rs.gz").read_bytes())
assert CORE.read_bytes() == CANDIDATE
os.environ["CARGO_TARGET_DIR"] = str(TARGET)
os.environ["ORT_DISABLE_TELEMETRY"] = "1"
start = time.monotonic()
records = []


def run(args):
    before = time.monotonic()
    child = subprocess.Popen(["cargo", *args], cwd=WT)
    p = Path("/proc") / str(child.pid)
    tick = p.joinpath("stat").read_text().rsplit(")", 1)[1].split()[19]
    rc = child.wait(timeout=max(0.1, 115 - (before - start)))
    records.append(
        {
            "argv": ["cargo", *args],
            "pid": child.pid,
            "tick": tick,
            "waited": True,
            "exit": rc,
            "wall_s": time.monotonic() - before,
            "core_SHA": hashlib.sha256(CORE.read_bytes()).hexdigest(),
        }
    )
    (DATA / "build-steps-v1.json").write_text(json.dumps(records, indent=2) + "\n")
    if rc:
        raise RuntimeError(f"compiler/test failure {rc}")


try:
    run(
        [
            "test",
            "--release",
            "--offline",
            "-j1",
            "-p",
            "quoridor-core",
            "--features",
            "research",
            "--test",
            "wall_legality",
            "--",
            "--nocapture",
        ]
    )
    run(
        [
            "test",
            "--release",
            "--offline",
            "-j1",
            "-p",
            "quoridor-core",
            "--features",
            "research",
            "--lib",
            "registered_wall_caller_counts",
            "--",
            "--nocapture",
        ]
    )
    for name, source in [("baseline", BASELINE), ("candidate", CANDIDATE)]:
        CORE.write_bytes(source)
        run(
            [
                "build",
                "--release",
                "--offline",
                "-j1",
                "-p",
                "quoridor-runner",
                "--example",
                "wall_work",
            ]
        )
        src = TARGET / "release/examples/wall_work"
        dst = TARGET / f"release/examples/wall_work_{name}288"
        shutil.copy2(src, dst)
        records.append(
            {
                "binary": str(dst),
                "bytes": dst.stat().st_size,
                "SHA": hashlib.sha256(dst.read_bytes()).hexdigest(),
                "core_SHA": hashlib.sha256(source).hexdigest(),
            }
        )
        (DATA / "build-steps-v1.json").write_text(json.dumps(records, indent=2) + "\n")
finally:
    CORE.write_bytes(CANDIDATE)
