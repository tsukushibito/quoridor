//! Same-information wall legality caller/search diagnostic; no teacher/game generation.
use quoridor_ai::alphabeta as ab;
use quoridor_core::{Position, research::SigmaContext};
use quoridor_nnue::{EvaluationMode, Model};
use serde_json::{Value, json};
use std::{
    hint::black_box,
    sync::{Arc, atomic::AtomicBool},
    time::Instant,
};

fn exact_legal(p: Position) -> Vec<u16> {
    if p.winner.is_some() {
        return vec![];
    }
    let mut ids: Vec<u16> = p
        .legal_pawn_mask()
        .into_iter()
        .enumerate()
        .filter_map(|(i, v)| (v != 0).then_some(i as u16))
        .collect();
    for h in [true, false] {
        for a in 0..64 {
            if p.legal_wall(h, a) {
                ids.push(if h { 81 } else { 145 } + a as u16);
            }
        }
    }
    ids
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().collect();
    assert_eq!(args.len(), 3, "wall_work CONFIG mode(micro|search)");
    assert_eq!(std::env::var("ORT_DISABLE_TELEMETRY").as_deref(), Ok("1"));
    let cfg: Value = serde_json::from_slice(&std::fs::read(&args[1])?)?;
    assert_eq!(cfg["task"], "frame23-wall-legality-288-v1");
    assert_eq!(cfg["schema"], "wall-work-config-v1");
    let fixtures = cfg["fixtures"].as_array().unwrap();
    assert_eq!(fixtures.len(), 4);
    let job = Instant::now();
    let mut nn = 0u64;
    let mut processed = 0u64;
    if args[2] == "micro" {
        for fixture in fixtures {
            let prefix: Vec<u16> = serde_json::from_value(fixture["prefix"].clone())?;
            let c = SigmaContext::from_prefix(&prefix)?;
            let p = c.position();
            let oracle = exact_legal(p);
            assert_eq!(p.legal_action_ids(), oracle);
            for sample in 0..5 {
                let mut cost = Vec::new();
                let order = if sample % 2 == 0 {
                    ["exact", "caller"]
                } else {
                    ["caller", "exact"]
                };
                for mode in order {
                    let start = Instant::now();
                    for _ in 0..128 {
                        let legal = if mode == "exact" {
                            exact_legal(black_box(p))
                        } else {
                            black_box(p).legal_action_ids()
                        };
                        assert_eq!(legal.len(), oracle.len());
                        black_box(legal);
                    }
                    cost.push(json!({"mode":mode,"iterations":128,"elapsed_ns":start.elapsed().as_nanos()}));
                }
                let start = Instant::now();
                for _ in 0..16 {
                    for &action in &oracle {
                        black_box(p.play(action)?);
                    }
                }
                println!(
                    "{}",
                    json!({"task":cfg["task"],"schema":"wall-work-row-v1","kind":"micro",
                    "name":fixture["name"],"key":p.position_key(),"walls":p.horizontal.count_ones()+p.vertical.count_ones(),
                    "legal":oracle,"sample":sample,"warmup":sample==0,"cost":cost,
                    "singleplay_count":16*oracle.len(),"singleplay_ns":start.elapsed().as_nanos()})
                );
            }
        }
    } else {
        assert_eq!(args[2], "search");
        let model = Arc::new(Model::load(cfg["nnue_manifest"].as_str().unwrap())?);
        let startup_ns = job.elapsed().as_nanos();
        let d = ab::DistanceEvaluator::new(0., 8.);
        let l = ab::NnueEvaluator::new(model.clone());
        let limits = ab::SearchLimits {
            max_depth: 2,
            max_nodes: 1200,
            time_limit: None,
            tt_entries: 16384,
            use_pvs: true,
            use_tt: true,
        };
        let samples = cfg["samples"].as_u64().unwrap();
        assert!((1..=2).contains(&samples));
        for fixture in fixtures {
            let prefix: Vec<u16> = serde_json::from_value(fixture["prefix"].clone())?;
            let root = SigmaContext::from_prefix(&prefix)?;
            let p = root.position();
            let legal = root.legal_ids();
            assert_eq!(p.legal_action_ids(), exact_legal(p));
            if cfg["quality"].as_bool().unwrap() {
                let parent = model.full_context(&root, EvaluationMode::Scalar)?;
                let simd = model.full_context(&root, EvaluationMode::Simd)?;
                let parent_values = parent.values.clone();
                let scalar_value = model.evaluate(&parent)?;
                let simd_value = model.evaluate(&simd)?;
                nn += 2;
                assert!((scalar_value - simd_value).abs() <= 1e-5);
                let mut max_error = 0f32;
                for &action in &legal {
                    let mut child = root.clone();
                    let undo = child.make_move(action)?;
                    for (mode, parent) in [
                        (EvaluationMode::Scalar, &parent),
                        (EvaluationMode::Simd, &simd),
                    ] {
                        let full = model.full_context(&child, mode)?;
                        let delta = model.delta_context(parent, &child)?;
                        let error = (model.evaluate(&full)? - model.evaluate(&delta)?).abs();
                        nn += 2;
                        max_error = max_error.max(error);
                        assert!(error <= 1e-5);
                    }
                    child.unmake_move(undo)?;
                    assert_eq!(child.position(), root.position());
                    assert_eq!(child.history_counts(), root.history_counts());
                    assert_eq!(child.total_ply(), root.total_ply());
                }
                assert_eq!(parent.values, parent_values);
                assert_eq!(model.evaluate(&parent)?.to_bits(), scalar_value.to_bits());
                assert_eq!(model.evaluate(&simd)?.to_bits(), simd_value.to_bits());
                nn += 2;
                println!(
                    "{}",
                    json!({"task":cfg["task"],"schema":"wall-work-row-v1","kind":"quality",
                    "name":fixture["name"],"legal_count":legal.len(),"max_full_delta_error":max_error,
                    "scalar_simd_error":(scalar_value-simd_value).abs(),"root_restored":true})
                );
            }
            for sample in 0..samples {
                for (engine, evaluator) in [
                    ("D", &d as &dyn ab::StaticEvaluator),
                    ("L", &l as &dyn ab::StaticEvaluator),
                ] {
                    let start = Instant::now();
                    let r = ab::search(&root, evaluator, &limits, &AtomicBool::new(false))?;
                    let elapsed_ns = start.elapsed().as_nanos();
                    processed += r.stats.nodes;
                    if engine == "L" {
                        nn += r.stats.evaluations;
                    }
                    assert_eq!(root.position(), p);
                    assert_eq!(
                        root.history_counts(),
                        SigmaContext::from_prefix(&prefix)?.history_counts()
                    );
                    assert!(nn <= 25000 && processed <= 50000);
                    println!(
                        "{}",
                        json!({"task":cfg["task"],"schema":"wall-work-row-v1","kind":"ab",
                        "name":fixture["name"],"engine":engine,"sample":sample,
                        "warmup":sample<cfg["warmup"].as_u64().unwrap(),"elapsed_ns":elapsed_ns,
                        "key":p.position_key(),"action":r.action,"value_bits":r.value.map(f32::to_bits),
                        "depth":r.completed_depth,"stop":format!("{:?}",r.stop),"pv":r.pv,
                        "nodes":r.stats.nodes,"evaluations":r.stats.evaluations,
                        "native_NN":if engine=="L" {r.stats.evaluations} else {0},"TT_hits":r.stats.tt_hits,
                        "TT_cutoffs":r.stats.tt_cutoffs,"terminal":r.stats.terminal,"delta_updates":r.stats.delta_updates})
                    );
                }
            }
        }
        println!(
            "{}",
            json!({"task":cfg["task"],"schema":"wall-work-row-v1","kind":"startup","elapsed_ns":startup_ns})
        );
    }
    println!(
        "{}",
        json!({"task":cfg["task"],"schema":"wall-work-summary-v1","kind":"summary",
        "mode":args[2],"NN":nn,"processed":processed,"wall_ns":job.elapsed().as_nanos()})
    );
    Ok(())
}
