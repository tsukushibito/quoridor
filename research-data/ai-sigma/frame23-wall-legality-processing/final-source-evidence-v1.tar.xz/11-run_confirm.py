"""Same registered roots, two steady repeats; reversed binary order confirmation."""

import hashlib
import json
from pathlib import Path
import subprocess
import time

DATA = Path("/workspaces/quoridor/research-data/ai-sigma/frame23-wall-legality-processing")
REG = json.loads((DATA / "confirm-registration-v1.json").read_text())
OUT = DATA / "confirmation-r1"
OUT.mkdir(exist_ok=False)
for path, sha in REG["inputs"].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == sha
records = []
rows = []
start = time.monotonic()
for name, binary in REG["order"]:
    argv = [binary, str(DATA / "confirm-config-v1.json"), "search"]
    before = time.monotonic()
    with (OUT / f"{name}.jsonl").open("w") as out, (OUT / f"{name}.stderr").open("w") as err:
        child = subprocess.Popen(argv, stdout=out, stderr=err)
        tick = (Path("/proc") / str(child.pid) / "stat").read_text().rsplit(")", 1)[1].split()[19]
        rc = child.wait(timeout=20)
    records.append(
        {
            "name": name,
            "argv": argv,
            "pid": child.pid,
            "tick": tick,
            "exit": rc,
            "waited": True,
            "wall_s": time.monotonic() - before,
        }
    )
    (OUT / "all-attempts.json").write_text(json.dumps(records, indent=2) + "\n")
    assert rc == 0
    rr = [json.loads(x) for x in (OUT / f"{name}.jsonl").read_text().splitlines()]
    assert all(r["task"] == REG["task"] for r in rr)
    rows.append(rr)
summary = [rr[-1] for rr in rows]
nn = sum(r["NN"] for r in summary)
processed = sum(r["processed"] for r in summary)
assert nn + REG["previous_NN"] <= 50000 and processed + REG["previous_processed"] <= 250000
pairs = []
meaning = [
    "name",
    "engine",
    "sample",
    "key",
    "action",
    "value_bits",
    "depth",
    "stop",
    "pv",
    "nodes",
    "evaluations",
    "native_NN",
    "TT_hits",
    "TT_cutoffs",
    "terminal",
    "delta_updates",
]
for stage, baseline, candidate in [("forward", rows[0], rows[1]), ("reverse", rows[3], rows[2])]:
    b = [r for r in baseline if r["kind"] == "ab"]
    c = [r for r in candidate if r["kind"] == "ab"]
    assert len(b) == len(c) == 16
    for x, y in zip(b, c):
        assert all(x[k] == y[k] for k in meaning), (x, y)
        pairs.append(
            {
                "stage": stage,
                "name": x["name"],
                "engine": x["engine"],
                "sample": x["sample"],
                "baseline_ns": x["elapsed_ns"],
                "candidate_ns": y["elapsed_ns"],
                "ratio": y["elapsed_ns"] / x["elapsed_ns"],
                "meaning_same": True,
            }
        )
result = {
    "task": REG["task"],
    "schema": "wall-confirm-result-v1",
    "PASS": True,
    "NN": nn,
    "processed": processed,
    "search_pairs": pairs,
    "wall_s": time.monotonic() - start,
    "old_results_unchanged": True,
    "whole_production_MCTS_strength": "NOT_MEASURED",
}
(OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
