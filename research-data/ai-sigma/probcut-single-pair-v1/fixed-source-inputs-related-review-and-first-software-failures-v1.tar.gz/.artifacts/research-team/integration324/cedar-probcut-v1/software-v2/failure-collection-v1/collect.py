"""Collect the original Runner typed-value fixture failure without replay."""

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    helper = load(
        "metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py",
    )
    lc = load("current", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helper.ref
    outer_path = BASE / "check-runtime-v1/result.json"
    outer = json.loads(outer_path.read_bytes())
    prefix_path = BASE / "operation-prefix/prefix-result.json"
    prefix = json.loads(prefix_path.read_bytes())
    intent = json.loads(helper.checked(prefix["intent"]).read_bytes())
    submit = json.loads((BASE / "original-prefix-submit-v1.json").read_bytes())
    started = json.loads(submit["stdout"])
    assert (
        outer["job_id"]
        == prefix["origin_job_id"]
        == started["job_id"]
        == "ab695a89-fef8-40ee-8b6e-fa8e497e2315"
    )
    assert (
        outer["outcome"] == "failed"
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and not outer["remaining"]
    )
    assert [row["status"] for row in prefix["checks"]] == ["PASS"] * 5 + ["FAILED"]
    known = [started["launch"]["owner"], submit["client"]]
    checks = []
    for row in prefix["checks"]:
        log = helper.checked(row["full_log"]).read_text()
        process = json.loads(
            helper.checked(row["persisted_process_receipt"]).read_bytes()
        )
        assert (
            process["direct_child_reaped"]
            and process["cleanup_complete"]
            and process["handle_closes_complete"]
            and not process["remaining"]
        )
        known.append(process["child"])
        if row["status"] == "PASS":
            lc.settled(row["guardian_return"])
            assert "test result: ok. 1 passed; 0 failed" in log
        else:
            assert (
                "0.10000000149011612" in log
                and "test result: FAILED. 0 passed; 1 failed" in log
            )
        checks.append(
            dict(
                name=row["name"],
                status=row["status"],
                full_log=row["full_log"],
                process=row["persisted_process_receipt"],
            )
        )
    fresh = []
    for original in known:
        actual = lc.process.identity(lc.process.process_info(original["pid"]))
        assert original != actual
        fresh.append(dict(original=original, fresh=actual))
    with lc.lease():
        lc.source_check(intent["source"])
        temporary = Path(intent["TMP"])
        assert temporary.is_dir() and not list(temporary.iterdir())
        temporary.rmdir()
        affected = helper.allocated_union(intent["owned_outputs"])
    notifications = []
    for role in ("launcher", "supervisor"):
        original = started["launch"][role]
        notifications.append(
            dict(
                role=role,
                original=original,
                fresh=lc.process.identity(lc.process.process_info(original["pid"])),
                scope="Separate finished-job notification only",
            )
        )
    receipt = dict(
        status="ACTUAL_RUNNER_FP32_JSON_FIXTURE_FAILED_AI5_PASS_SOURCE_STOP",
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        outer=ref(outer_path),
        original_prefix=ref(prefix_path),
        checks=checks,
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        source_EX_NB_acquired_released=True,
        source_leases=[],
        TMP=[],
        remaining_source_compiler=[],
        exact_known_fresh=fresh,
        notification_lifetime=notifications,
        affected_issued_union_B_once=affected["allocated_B"],
        failed_guardian_NULL_and_disk_mask_pending_persist_attempted_retained=True,
        failure="Runner first fixture raw JSON0.1 differs actual typed FP32 serialized0.10000000149011612; no algorithm/default/coefficients tuned; AI5 actualPASS retained",
        pending="Sameauthor minimal typed expected-value fixture fix; failedRunner1 plus unenteredRunner2-3/Clippy/release only",
        science_calls=0,
        host_future_quiet=False,
        globalactual_fullfees_later_tails="UNKNOWN",
    )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            dict(
                receipt=ref(OUT / "completion-and-STOP.json"),
                affected=affected,
                outer_seconds_once=outer["wall_seconds"],
            )
        )
    )


if __name__ == "__main__":
    main()
