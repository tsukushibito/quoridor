"""Adopt the exact returned sparse ProbCut subjects without type qualification."""

import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PACKET = ROOT / ".worktree/assets/perf/cedar-probcut-v1/fixed-source-v1/binding.json"


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def main():
    assert ref(PACKET) == dict(
        path=str(PACKET),
        sha256="d3cb0bf7a48db451f3c2a7d2a6b044595359b252732f9666c9f4c680839f4a89",
        bytes=11127,
        mode="0644",
    )
    binding = json.loads(PACKET.read_bytes())
    spec = importlib.util.spec_from_file_location(
        "lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lc)
    patch = Path(binding["forward"]["path"])
    assert ref(patch) == binding["forward"]
    with lc.lease():
        for row in binding["subjects"]:
            path = ROOT / row["subject"]
            assert path.is_relative_to(ROOT / "crates") or path == (
                ROOT / "scripts/dev/research-lifecycle.py"
            )
            if row["new"]:
                assert row["before"] is None and not path.exists()
            else:
                actual = ref(path)
                assert all(
                    actual[k] == row["before"][k] for k in ("sha256", "bytes", "mode")
                )
            assert ref(Path(row["post"]["path"])) == row["post"]
        subprocess.run(["git", "apply", "--check", str(patch)], cwd=ROOT, check=True)
        subprocess.run(["git", "apply", str(patch)], cwd=ROOT, check=True)
        rows = []
        for row in binding["subjects"]:
            actual = ref(ROOT / row["subject"])
            assert all(actual[k] == row["post"][k] for k in ("sha256", "bytes", "mode"))
            rows.append(dict(subject=row["subject"], actual=actual))
    receipt = dict(
        status="ACTUAL_SPARSE_TEN_SUBJECT_PROBCUT_SOURCE_APPLIED_REVIEW_SOFTWARE_PENDING",
        binding=ref(PACKET),
        patch=ref(patch),
        subjects=rows,
        constructor_factory_repair="Root static missing native fork_worker fields returned to same author; causal override pending before compiler entry",
        software="AI4/RunnerLIB2/Clippy/release UNBUILT_UNTYPED_UNRUN",
        source_EX_NB_acquired_released=True,
        source_leases=[],
        science_calls=0,
        host_future_quiet=False,
    )
    with (OUT / "actual-adoption.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(dict(applied=len(rows), receipt=ref(OUT / "actual-adoption.json")))
    )


if __name__ == "__main__":
    main()
