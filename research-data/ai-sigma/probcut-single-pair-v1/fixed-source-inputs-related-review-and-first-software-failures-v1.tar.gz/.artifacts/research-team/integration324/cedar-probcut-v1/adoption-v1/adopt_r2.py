"""Adopt the exact returned sparse ProbCut subjects without type qualification."""

import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PACKET = (
    ROOT
    / ".worktree/assets/perf/cedar-probcut-v1/observation-refusal-repair-v1/binding.json"
)


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def main():
    assert ref(PACKET) == dict(
        path=str(PACKET),
        sha256="5f4ef6829e8d530bfb4579af45587b0b38b167eb4dd8fbb1d77b795dbd53a948",
        bytes=8373,
        mode="0644",
    )
    binding = json.loads(PACKET.read_bytes())
    spec = importlib.util.spec_from_file_location(
        "lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lc)
    patch = Path(binding["forward"]["path"])
    assert ref(patch) == binding["forward"]
    with lc.lease():
        for row in binding["subjects"]:
            path = ROOT / row["subject"]
            assert path.is_relative_to(ROOT / "crates") or path == (
                ROOT / "scripts/dev/research-lifecycle.py"
            )
            actual = ref(path)
            assert all(
                actual[k] == row["actual_before"][k]
                for k in ("sha256", "bytes", "mode")
            )
            assert ref(Path(row["post"]["path"])) == row["post"]
        subprocess.run(["git", "apply", "--check", str(patch)], cwd=ROOT, check=True)
        subprocess.run(["git", "apply", str(patch)], cwd=ROOT, check=True)
        rows = []
        for row in binding["subjects"]:
            actual = ref(ROOT / row["subject"])
            assert all(actual[k] == row["post"][k] for k in ("sha256", "bytes", "mode"))
            rows.append(dict(subject=row["subject"], actual=actual))
    previous = OUT / "fixture-combined-adoption.json"
    receipt = json.loads(previous.read_bytes())
    replacements = {row["subject"]: row for row in rows}
    receipt["subjects"] = [
        replacements.get(row["subject"], row) for row in receipt["subjects"]
    ]
    assert len(receipt["subjects"]) == 14
    for row in receipt["subjects"]:
        assert ref(ROOT / row["subject"]) == row["actual"]
    receipt.update(
        status="ACTUAL_SPARSE_PROBCUT_R2_AND_LITERAL_REPAIRS_APPLIED_SOURCE_CLEAR_SOFTWARE_PENDING",
        previous_adoption=ref(previous),
        R2_binding=ref(PACKET),
        R2_forward=ref(patch),
        review="SameMax SOURCE_CLEAR 6e6a9e62; original negative and original compiler failure retained",
        software="AI5 RunnerLIB3 and affected Clippy unentered; prior compile failed before test bodies",
    )
    with (OUT / "R2-combined-adoption.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            dict(applied=len(rows), receipt=ref(OUT / "R2-combined-adoption.json"))
        )
    )


if __name__ == "__main__":
    main()
