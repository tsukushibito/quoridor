"""Bind the six new NN0 definitions and affected lint to the adopted source."""

import argparse
import copy
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
OPS = OUT.parent
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["prefix", "release"], required=True)
    args = parser.parse_args()
    lc = load("lifecycle", ROOT / "scripts/dev/research-lifecycle.py")
    helper = load(
        "metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py",
    )
    ref = helper.ref

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return ref(path)

    template = json.loads(
        (
            ROOT
            / ".artifacts/research-team/integration324/cedar-root-split-v1/retirement-software-v2/build-intent-release.json"
        ).read_bytes()
    )
    adoption = OPS / "adoption-v1/combined-adoption.json"
    adopted = json.loads(adoption.read_bytes())
    assert len(adopted["subjects"]) == 11
    with lc.lease():
        for row in adopted["subjects"]:
            assert ref(ROOT / row["subject"]) == row["actual"]
        source = copy.deepcopy(template["source"])
        patch = OUT / f"actual-source-{args.stage}.patch"
        patch.write_bytes(
            subprocess.check_output(
                [
                    "git",
                    "diff",
                    "--binary",
                    "--no-ext-diff",
                    "--no-textconv",
                    "HEAD",
                    "--",
                ],
                cwd=ROOT,
            )
        )
        untracked = subprocess.check_output(
            [
                "git",
                "ls-files",
                "--others",
                "--exclude-standard",
                "--",
                "crates",
                ".cargo",
            ],
            cwd=ROOT,
            text=True,
        ).splitlines()
        assert set(untracked) == {
            "crates/quoridor-ai/src/probcut.rs",
            "crates/quoridor-ai/src/probcut_tests.rs",
        }
        source.update(
            commit=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
            ).strip(),
            patch=ref(patch),
            untracked_inputs=[ref(ROOT / p) for p in sorted(untracked)],
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        for witness in source["cargo_configs"]:
            path = Path(witness["path"])
            witness["file"] = ref(path) if path.exists() else None
        receipts = []
        if args.stage == "release":
            prefix = OUT / "operation-prefix/prefix-result.json"
            data = json.loads(prefix.read_bytes())
            assert (
                data["status"] == "PASS_TEST_LINT_PREFIX_ONLY"
                and data["cleanup_complete"]
            )
            assert len(data["checks"]) == 8 and all(
                row["status"] == "PASS" for row in data["checks"]
            )
            receipts = [
                dict(name=row["name"], file=ref(prefix)) for row in data["checks"]
            ]
        authority = save(
            f"build-source-adoption-{args.stage}.json",
            dict(
                schema="quoridor.research.source-adoption.v1",
                status="ACCEPTED",
                issue="quoridor-4lc.324.30",
                source=source,
                actual_fixed_source_adoption=ref(adoption),
                prior_software=dict(
                    subjects=[row["actual"] for row in adopted["subjects"]],
                    receipts=receipts,
                ),
                scope="Root accepted exact sparse source for new NN0/type qualification. Related SAME Max source review separate; no scientific/source-clear claim from BUILD preparation. Only new AI4/RunnerLIB2 and affected Clippy, no old successful suite replay.",
            ),
        )
        target = Path(template["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker["writer"] == WRITER and marker["target"] == str(target)
        roots = list(
            dict.fromkeys(
                template["owned_outputs"]
                + [
                    str(OPS),
                    str(ROOT / ".worktree/assets/perf/cedar-probcut-v1"),
                    str(ROOT / ".worktree/assets/perf/cedar-probcut-review-v1"),
                ]
            )
        )
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
            owned_B=348 * 1024**2,
            free_B=32 * 1024**2,
        )
        support = save(
            f"resources-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.30",
                authority=authority,
                resources=dict(
                    worker_cpu=12,
                    guardian_cpu=16,
                    test_cpu_cores=[12, 14, 16],
                    native_threads=1,
                    GPU=0,
                    family_RAM_B=4 * 1024**3,
                    controller_included=True,
                    controller_B=64 * 1024**2,
                    host_reserve_B=4 * 1024**3,
                ),
                storage_budget=dict(
                    whole_B=limits["owned_B"],
                    roots=roots,
                    prior_base_known_cover_B=49608672256,
                    separate_ordinary_save_Git_B=24 * 1024**2,
                    known_cover_upper_B=49998742528,
                    globalactual_fullfees="UNKNOWN",
                    scope="One whole reuses ended retention plus new ProbCut source/review/software and sole serial Cargo target; no per-file micro gate or global audit. Same-package exact NN0 cache reused, only stopped reproducible cache retired at package boundaries; no RAW/model/image/FAILED deletion/refund/lending.",
                ),
                scope="Ordinary software only; no Cedar Search/calibration/scientific entry grant",
            ),
        )
        handover = save(
            f"target-handover-{args.stage}.json",
            dict(
                schema="research.target-handover.v1",
                status="HANDED_OVER",
                target=str(target),
                target_writer=WRITER,
                fresh_private_root=str(OUT / f"private-image-{args.stage}"),
                shared_serial_pool=True,
                old_target=json.loads(
                    (
                        ROOT
                        / ".artifacts/research-team/integration324/cedar-root-split-v1/retirement-software-v2/target-handover-release.json"
                    ).read_bytes()
                )["old_target"],
                owned_remaining=[],
                test_cpu_cores=[12, 14, 16],
                actual_source_adoption=ref(adoption),
            ),
        )
        recipe = json.loads(
            (
                ROOT
                / ".worktree/assets/perf/cedar-probcut-v1/fixed-source-v1/software-recipe.json"
            ).read_bytes()
        )
        cargo = template["tools"]["CARGO"]["file"]["path"]
        commands = []
        if args.stage == "prefix":
            for package, key, feature in [
                ("quoridor-ai", "AI_exact_selectors", "features_AI"),
                ("quoridor-runner", "Runner_LIB_exact_selectors", "features_Runner"),
            ]:
                for selector in recipe[key]:
                    commands.append(
                        dict(
                            name=f"probcut-new-boundary-{len(commands) + 1}",
                            role="test",
                            selector=selector,
                            argv=[
                                cargo,
                                "test",
                                "--offline",
                                "--locked",
                                "--manifest-path",
                                str(ROOT / "Cargo.toml"),
                                "-j1",
                                "--message-format=json-render-diagnostics",
                                "--release",
                                "-p",
                                package,
                                "--features",
                                ",".join(recipe[feature]),
                                "--lib",
                                selector,
                                "--",
                                "--exact",
                                "--nocapture",
                                "--test-threads=1",
                            ],
                        )
                    )
            assert len(commands) == 6
            for package, features, label in [
                ("quoridor-ai", "research-diagnostics", "AI"),
                (
                    "quoridor-runner",
                    "measurement,quoridor-inference/claustrophobia",
                    "Runner",
                ),
            ]:
                commands.append(
                    dict(
                        name=f"probcut-affected-{label}-Clippy",
                        role="lint",
                        argv=[
                            cargo,
                            "clippy",
                            "--offline",
                            "--locked",
                            "--manifest-path",
                            str(ROOT / "Cargo.toml"),
                            "-j1",
                            "--message-format=json-render-diagnostics",
                            "--release",
                            "-p",
                            package,
                            "--features",
                            features,
                            "--all-targets",
                            "--no-deps",
                            "--",
                            "-Dwarnings",
                        ],
                    )
                )
        build = copy.deepcopy(template["commands"][0])
        build["name"] = "probcut-common-genuine-release"
        commands.append(build)
        spec = copy.deepcopy(template)
        for key in ["admission", "intent_sha256"]:
            spec.pop(key, None)
        spec.update(
            output=str(OUT / f"operation-{args.stage}"),
            owned_outputs=roots,
            support=support,
            source_adoption=authority,
            target_handover=handover,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / f"private-image-{args.stage}/quoridor-runner"),
            TMP=str(OUT / f"build-TMP-{args.stage}"),
            test_cpu_cores=[12, 14, 16],
            command_timeout_seconds=1800,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        (target / ".research-owner.json").write_text(
            json.dumps(
                dict(
                    writer=WRITER, target=str(target), support_sha256=support["sha256"]
                ),
                indent=2,
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            f"build-admission-{args.stage}.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Software binding; genuine normal runtime admission remains required",
            ),
        )
        intent = save(f"build-intent-{args.stage}.json", spec)
        argv = (
            [str(lc.project_python()), "-B", str(OUT / "run_prefix.py")]
            if args.stage == "prefix"
            else [
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "build",
            ]
        )
        argv += ["--intent", intent["path"], "--sha256", intent["sha256"]]
        save(
            f"job-{args.stage}.json",
            dict(
                issue="quoridor-4lc.324",
                goal_issue="quoridor-4lc.324",
                thread_id="01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                cwd=str(ROOT),
                argv=argv,
                end_at=None,
                notify_until=None,
                max_runtime_seconds=1860,
                control_interval_seconds=30,
                notify_interval_seconds=10,
                request_timeout_seconds=25,
                log_max_bytes=16384,
                resource_contract=support["path"],
            ),
        )
        print(json.dumps(dict(stage=args.stage, intent=intent, actual_job=None)))


if __name__ == "__main__":
    main()
