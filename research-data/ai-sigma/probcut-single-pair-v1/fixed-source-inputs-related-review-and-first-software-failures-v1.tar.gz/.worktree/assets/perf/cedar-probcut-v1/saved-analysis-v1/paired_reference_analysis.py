"""One calibration-only fit or locked confirmation, from owning collected small rows.

Never launches search, loads a model, chooses replacement rows, or performs RNG.
Inputs must be normal-collected records with parent/input/family custody already joined.
"""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import struct


def reference(path):
    p = Path(path)
    b = p.read_bytes()
    return dict(
        path=str(p.resolve()), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b)
    )


def f32(value):
    return struct.unpack("!f", struct.pack("!f", value))[0]


def upward32(value):
    rounded = f32(value)
    if rounded < value:
        bits = struct.unpack("!I", struct.pack("!f", rounded))[0]
        # Here only nonnegative margins are rounded upward.
        assert rounded >= 0
        rounded = struct.unpack("!f", struct.pack("!I", bits + 1))[0]
    if not math.isfinite(rounded):
        raise ValueError("nonfinite rounded margin; no candidate")
    return rounded


def admit(value, bound):
    return type(value) in (int, float) and math.isfinite(value) and abs(value) <= bound


def beta_side(row):
    if not row.get("complete"):
        return None
    value, beta, kind = (
        row.get("deep_OFF_reference"),
        row.get("beta"),
        row.get("deep_bound"),
    )
    if type(value) not in (int, float) or type(beta) not in (int, float):
        return None
    if not math.isfinite(value) or not math.isfinite(beta):
        return None
    if kind == "Exact":
        return value >= beta
    if kind == "Lower" and value >= beta:
        return True
    if kind == "Upper" and value < beta:
        return False
    return None


def dump_new(path, value):
    with path.open("x") as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write("\n")


def calibration(rows, domain, input_ref, output):
    bound = domain["nonterminal_abs_bound"]
    chosen = [r for r in rows if r["split"] == "calibration"]
    complete = [
        r
        for r in chosen
        if r.get("complete")
        and r.get("deep_bound") == "Exact"
        and admit(r.get("shallow"), bound)
        and admit(r.get("deep_OFF_reference"), bound)
    ]
    families = {r["canonical_family"] for r in complete}
    report = dict(
        input=input_ref,
        rows_ALL=len(chosen),
        complete_finite_nonterminal_pairs=len(complete),
        distinct_families=len(families),
        unknown_or_non_exact_or_terminal=len(chosen) - len(complete),
        source="full-window local OFF selective references at sampled actual nonPV positions",
        IID_or_error_free_guarantee=False,
        domain=domain,
    )
    if len(complete) < 64 or len(families) < 8:
        report["decision"] = "STOP_INSUFFICIENT_CALIBRATION_NO_REFILL"
        dump_new(output / "calibration-evidence.json", report)
        return
    xs = [r["shallow"] for r in complete]
    ys = [r["deep_OFF_reference"] for r in complete]
    mx, my = math.fsum(xs) / len(xs), math.fsum(ys) / len(ys)
    variance = math.fsum((x - mx) ** 2 for x in xs)
    if variance <= 0:
        report["decision"] = "STOP_UNIDENTIFIABLE_PAIR"
        dump_new(output / "calibration-evidence.json", report)
        return
    slope = f32(
        math.fsum((x - mx) * (y - my) for x, y in zip(xs, ys, strict=True)) / variance
    )
    intercept = f32(my - slope * mx)
    if not math.isfinite(slope) or slope <= 0 or not math.isfinite(intercept):
        report["decision"] = "STOP_UNSUPPORTED_PAIR"
        dump_new(output / "calibration-evidence.json", report)
        return
    # Recompute residuals AFTER rounding coefficients actually consumed by native f32 config.
    overprediction = max(
        0.0, max(slope * x + intercept - y for x, y in zip(xs, ys, strict=True))
    )
    margin = upward32(overprediction + 0.02 * bound)
    report.update(
        decision="ONE_CALIBRATION_CANDIDATE_FROZEN_NOT_ADOPTED",
        slope=slope,
        intercept=intercept,
        margin=margin,
        maximum_calibration_overprediction=overprediction,
        mean_squared_residual=math.fsum(
            (slope * x + intercept - y) ** 2 for x, y in zip(xs, ys, strict=True)
        )
        / len(xs),
        confirmation_used_for_fit=False,
        uncertainty="small correlated finite calibration, no tail guarantee",
    )
    evidence = output / "calibration-evidence.json"
    dump_new(evidence, report)
    parameters = dict(
        shallow_depth=1,
        deep_depth=3,
        slope=slope,
        intercept=intercept,
        margin=margin,
        nonterminal_abs_bound=domain["nonterminal_abs_bound"],
        terminal_utility=domain["terminal_utility"],
        calibration_sha256=reference(evidence)["sha256"],
    )
    dump_new(output / "parameters.json", parameters)


def confirmation(rows, domain, parameters, input_ref, parameter_ref, output):
    bound = domain["nonterminal_abs_bound"]
    assert parameters["shallow_depth"] == 1 and parameters["deep_depth"] == 3
    assert parameters["nonterminal_abs_bound"] == bound
    assert parameters["terminal_utility"] == domain["terminal_utility"]
    assert parameters["slope"] > 0 and parameters["margin"] >= 0
    totals = Counter()
    groups = defaultdict(Counter)
    wrong = []
    predicted_families = set()
    chosen = [r for r in rows if r["split"] == "confirmation"]
    for r in chosen:
        totals["samples_ALL"] += 1
        strata = [
            ("family", r["canonical_family"]),
            ("stock", r.get("stock_total", "UNKNOWN")),
            ("ply", r.get("ply", "UNKNOWN")),
            ("contact", r.get("contact_manhattan_le2", "UNKNOWN")),
            ("goal_near", r.get("goal_near_geometric_le2", "UNKNOWN")),
        ]
        for group in strata:
            groups[str(group)]["samples_ALL"] += 1
        shallow, beta = r.get("shallow"), r.get("beta")
        if not admit(shallow, bound) or not admit(beta, bound):
            totals["prediction_UNOBSERVABLE"] += 1
            continue
        threshold = (
            beta - parameters["intercept"] + parameters["margin"]
        ) / parameters["slope"]
        # Native rounds threshold upward; comparison of two f32 inputs against this real threshold
        # has the same lower-bound meaning. Native actual probe counters are a separate distribution.
        if not admit(threshold, bound):
            totals["threshold_outside_domain"] += 1
            continue
        predicted = (
            shallow >= threshold
            and parameters["slope"] * shallow
            + parameters["intercept"]
            - parameters["margin"]
            >= beta
        )
        if not predicted:
            totals["not_predicted"] += 1
            continue
        totals["predicted_ALL"] += 1
        predicted_families.add(r["canonical_family"])
        side = beta_side(r)
        label = (
            "predicted_UNKNOWN"
            if side is None
            else ("decidable_falsecut" if not side else "decidable_supported")
        )
        totals[label] += 1
        for group in strata:
            groups[str(group)]["predicted_ALL"] += 1
            groups[str(group)][label] += 1
        if side is False:
            wrong.append(
                dict(
                    parent_id=r.get("parent_id"),
                    canonical_family=r["canonical_family"],
                    beta=beta,
                    reference=r["deep_OFF_reference"],
                    kind=r["deep_bound"],
                    beta_gap=beta - r["deep_OFF_reference"],
                    beta_gap_semantics="exact local-reference difference"
                    if r["deep_bound"] == "Exact"
                    else "lower bound only",
                )
            )
    predicted = totals["predicted_ALL"]
    decidable = totals["decidable_supported"] + totals["decidable_falsecut"]
    unknown_fraction = totals["predicted_UNKNOWN"] / predicted if predicted else None
    gate = (
        decidable >= 32
        and len(predicted_families) >= 8
        and totals["decidable_falsecut"] == 0
        and unknown_fraction <= 0.10
    )
    dump_new(
        output / "confirmation.json",
        dict(
            input=input_ref,
            parameters=parameter_ref,
            counts=dict(totals),
            predicted_distinct_families=len(predicted_families),
            decidable_denominator=decidable,
            falsecut_fraction_decidable=totals["decidable_falsecut"] / decidable
            if decidable
            else None,
            unknown_fraction_ALL_predicted=unknown_fraction,
            groups={k: dict(v) for k, v in groups.items()},
            falsecut_rows=wrong,
            confirmation_refit=False,
            decision="ELIGIBLE_FOR_OWNING_TIMING_ADMISSION_ONLY"
            if gate
            else "STOP_NO_RESELECT_NO_REFILL",
            limitation="zero observed errors is not error-free; local selective reference and sample correlation; ON tree/TT distribution differs",
        ),
    )


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=["calibrate", "confirm"])
    p.add_argument("--samples", required=True, type=Path)
    p.add_argument("--actual-domain", required=True, type=Path)
    p.add_argument("--parameters", type=Path)
    p.add_argument("--output", required=True, type=Path)
    args = p.parse_args()
    own = Path(__file__).resolve().parents[1]
    args.output.resolve().relative_to(own)
    data = json.loads(args.samples.read_text())
    domain = json.loads(args.actual_domain.read_text())
    assert 0 < domain["nonterminal_abs_bound"] < domain["terminal_utility"]
    assert all(r["remaining_depth"] == 3 for r in data["samples"])
    # The owning collection must provide the actual call/node census, not approved maxima as spend.
    assert (
        data["counted_calls"] <= 2048
        and data["unique_cumulative_parent_nodes"] <= 2048000000
    )
    assert data["source_normal_collection_STOP"] and data["normal_manifest_refs"]
    cal = {
        r["canonical_family"] for r in data["samples"] if r["split"] == "calibration"
    }
    conf = {
        r["canonical_family"] for r in data["samples"] if r["split"] == "confirmation"
    }
    assert not cal & conf
    args.output.mkdir(parents=True, exist_ok=False)
    if args.mode == "calibrate":
        calibration(data["samples"], domain, reference(args.samples), args.output)
    else:
        if args.parameters is None:
            raise ValueError(
                "confirmation needs frozen calibration parameters; no fit fallback"
            )
        confirmation(
            data["samples"],
            domain,
            json.loads(args.parameters.read_text()),
            reference(args.samples),
            reference(args.parameters),
            args.output,
        )


if __name__ == "__main__":
    main()
