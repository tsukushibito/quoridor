"""Retire only reconstructible private source copies from closed28/29."""

import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper = load(
        "metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py",
    )
    lc = load("current", ROOT / "scripts/dev/research-lifecycle.py")
    plan_path = OUT / "closed-source-copy-candidates.json"
    plan = json.loads(plan_path.read_bytes())
    intent = json.loads((OUT.parent / "build-intent-prefix.json").read_bytes())
    for archive in plan["canonical_archives"]:
        path = Path(archive["path"])
        assert helper.ref(path)["sha256"] == archive["sha256"]
        git_bytes = subprocess.check_output(
            ["git", "cat-file", "blob", "HEAD:" + str(path.relative_to(ROOT))], cwd=ROOT
        )
        assert hashlib.sha256(git_bytes).hexdigest() == archive["sha256"]
    with lc.lease():
        lc.source_check(intent["source"])
        for row in plan["candidates"]:
            path = Path(row["source"])
            assert row["full_stream_restore_hash_mode_verified"] is True
            assert (
                hashlib.sha256(path.read_bytes()).hexdigest() == row["sha256"]
                and path.stat().st_size == row["bytes"]
            )
            assert (
                f"{stat.S_IMODE(path.stat().st_mode):04o}" == row["mode"]
                and not path.is_symlink()
            )
        before = helper.allocated_union(intent["owned_outputs"])
        for row in plan["candidates"]:
            Path(row["source"]).unlink()
        after = helper.allocated_union(intent["owned_outputs"])
    assert before["allocated_B"] - after["allocated_B"] == plan["allocated_B"]
    receipt = dict(
        status="EXACT_GIT_ARCHIVED_CLOSED28_29_SOURCE_COPIES_RETIRED",
        candidates=helper.ref(plan_path),
        canonical_archives=plan["canonical_archives"],
        source_copies=len(plan["candidates"]),
        before=before,
        after=after,
        freed_reconstructible_source_copy_B=plan["allocated_B"],
        original_restoration_proof_reused_not_reexecuted=True,
        source_EX_NB_acquired_released=True,
        source_leases=[],
        model_input_RAW_FAILED_results_deleted=False,
        scientific_spent_calls_nodes_costs_and_rights_unchanged=True,
        no_Main_or_current30_owner_source_deleted=True,
        scope="Manifest-selected raw source copies only after closed28/29 actual source/closureSTOP; exact raw hash/size/mode and unchanged pushed canonical archive identity checked. Operators and all scientific/failed evidence kept. No global asset inventory, quota refund or loan.",
        host_future_quiet=False,
    )
    with (OUT / "closed-source-retirement.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            dict(
                copies=receipt["source_copies"], freed=plan["allocated_B"], after=after
            )
        )
    )


if __name__ == "__main__":
    main()
