"""Accept the saved new test/lint prefix and retire only its stopped debug cache."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOFTWARE = OUT.parent


def ref(path):
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def checked(w):
    p = Path(w["path"])
    assert ref(p) == w
    return p


def allocated_union(bases):
    seen = set()
    total = 0
    debug = 0
    count = 0
    for base in bases:
        for directory, dirs, files in os.walk(base):
            for name in files:
                p = Path(directory) / name
                if p.is_symlink():
                    continue
                s = p.stat()
                key = (s.st_dev, s.st_ino)
                if key in seen:
                    continue
                seen.add(key)
                n = s.st_blocks * 512
                total += n
                count += 1
                if "target/debug/" in str(p):
                    debug += n
    return dict(allocated_B=total, inodes=count, stopped_debug_B=debug)


def main():
    outer = json.loads((SOFTWARE / "check-runtime-v1/result.json").read_bytes())
    prefix_path = SOFTWARE / "operation-prefix/prefix-result.json"
    prefix = json.loads(prefix_path.read_bytes())
    intent = json.loads(checked(prefix["intent"]).read_bytes())
    submit = json.loads((SOFTWARE / "original-prefix-submit-v1.json").read_bytes())
    started = json.loads(submit["stdout"])
    assert (
        outer["job_id"]
        == prefix["origin_job_id"]
        == started["job_id"]
        == "c33848ce-d169-400c-a0d7-b01ad2090013"
    )
    assert (
        outer["exit_code"] == 0
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and not outer["remaining"]
    )
    assert (
        prefix["status"] == "PASS_TEST_LINT_PREFIX_ONLY"
        and prefix["cleanup_complete"]
        and not prefix["release_executed"]
        and prefix["source_leases"] == prefix["TMP"] == []
    )
    assert len(prefix["checks"]) == 5
    known = [
        started["launch"]["owner"],
        submit["client"],
    ]
    checks = []
    for row in prefix["checks"]:
        assert row["status"] == "PASS"
        record = row["guardian_return"]
        assert (
            record["exit_code"] == 0
            and record["cleanup_complete"]
            and record["direct_child_reaped"]
            and record["handle_closes_complete"]
            and not record["remaining"]
        )
        assert (
            record["signal_mask_restoration"] == "completed"
            and record["final_record_persist"] == "completed"
        )
        known.append(record["child"])
        log = checked(row["full_log"]).read_text()
        assert row["cargo"]["warning_count"] == 0
        checked(row["persisted_process_receipt"])
        if row["role"] == "test":
            selector = row["argv"][row["argv"].index("--lib") + 1]
            assert (
                "running 1 test" in log
                and f"test {selector} ... ok" in log
                and "test result: ok. 1 passed; 0 failed" in log
            )
        checks.append(
            dict(
                name=row["name"],
                role=row["role"],
                status="PASS",
                required_running=1 if row["role"] == "test" else None,
                full_log=row["full_log"],
                process=row["persisted_process_receipt"],
            )
        )
    fresh = []
    for expected in known:
        actual = identity(process_info(expected["pid"]))
        assert actual != expected
        fresh.append(dict(expected=expected, actual=actual, absent_or_different=True))
    marker = Path(intent["target"]) / ".research-owner.json"
    loader = importlib.util.spec_from_file_location(
        "collected_source", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "a"
    ) as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lc.source_check(intent["source"])
        assert not Path(intent["TMP"]).exists()
        owner = json.loads(marker.read_bytes())
        assert owner == dict(
            writer=intent["writer"],
            target=intent["target"],
            support_sha256=intent["support"]["sha256"],
        )
        target = Path(intent["target"])
        assert not (target / "release").exists()
        assert not (target / "debug").exists()
        affected = allocated_union(intent["owned_outputs"])
    notification_lifetime = []
    for role in ("launcher", "supervisor"):
        original = started["launch"][role]
        notification_lifetime.append(
            dict(
                role=role,
                original=original,
                current=identity(process_info(original["pid"])),
                scope="Separate finished-job delivery only, no source/compiler lifetime or ACK gate",
            )
        )

    receipt = dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status="PASS_NEW_TEST_LINT_PREFIX_ONLY_ACTUAL_STOP",
        issue="quoridor-4lc.324.30",
        job_id=outer["job_id"],
        prefix_result=ref(prefix_path),
        outer_result=ref(SOFTWARE / "check-runtime-v1/result.json"),
        checks=checks,
        fresh_exact_known_identities=fresh,
        source_lease="EX_NB_source_check_then_returned",
        remaining=[],
        TMP=[],
        outer_seconds_once=outer["wall_seconds"],
        nested_prefix_seconds_not_added=prefix["wall_seconds"],
        release_executed=False,
        native_scientific_entry=False,
        affected_issued_union_once=affected,
        notification_lifetime=notification_lifetime,
        globalactual_fullfees_later_tails="UNKNOWN",
        prior_AI5_PASS_reused=dict(
            original_failed_prefix=ref(
                SOFTWARE.parent / "software-v2/operation-prefix/prefix-result.json"
            ),
            actual_STOP=ref(
                SOFTWARE.parent
                / "software-v2/failure-collection-v1/completion-and-STOP.json"
            ),
            scope="Exact unchanged AI source verified in new build-source-adoption; only Runner fixture expectation changed; no AI test replay",
        ),
        typed_fixture_adoption_literal_amendment="The inherited software prose in8e059c57 incorrectly says AI5 unentered. Actual AI5 PASS from ab695a89 is reused, as bound in software-v3 prior_software receipts; Runner3/Clippy actual current prefix only. No original values changed.",
        host_future_quiet=False,
    )
    with (OUT / "completion-and-STOP.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            dict(
                status=receipt["status"],
                AI=5,
                RunnerLIB=3,
                Clippy=2,
                outer_seconds_once=outer["wall_seconds"],
                affected=affected,
            )
        )
    )


if __name__ == "__main__":
    main()
