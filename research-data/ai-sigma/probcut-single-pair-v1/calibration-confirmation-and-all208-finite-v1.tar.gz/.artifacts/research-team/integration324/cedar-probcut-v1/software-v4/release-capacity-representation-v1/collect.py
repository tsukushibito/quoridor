"""Retain four ended images losslessly for the actual genuine-build peak."""

import hashlib
import importlib.util
import json
import lzma
from pathlib import Path
import stat

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
STOPS = [
    "cedar-aspiration-window-v1/software-v2/release-collection-v1/completion-and-STOP.json",
    "cedar-root-split-v1/software-v1/release-collection-v1/completion-and-STOP.json",
    "cedar-root-split-v1/prototype-software-v6/release-collection-v1/completion-and-STOP.json",
    "cedar-aspiration-window-v1/implementation-cost-review-v1/retirement-software-v2/release-collection-v1/completion-and-STOP.json",
]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    helper = load(
        "metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py",
    )
    lc = load("current", ROOT / "scripts/dev/research-lifecycle.py")
    rows = []
    for name in STOPS:
        stop = ROOT / ".artifacts/research-team/integration324" / name
        data = json.loads(stop.read_bytes())
        assert data["source_leases"] == data["remaining_owned"] == data["TMP"] == []
        raw = helper.checked(data["artifact"])
        assert raw.stat().st_nlink == 1
        rows.append(dict(raw=raw, original=data["artifact"], stop=helper.ref(stop)))
    readers = []
    for process in Path("/proc").iterdir():
        if process.name.isdigit():
            try:
                exe = (process / "exe").resolve()
                maps = (process / "maps").read_text()
                readers += [
                    process.name
                    for row in rows
                    if exe == row["raw"] or str(row["raw"]) in maps
                ]
            except OSError:
                pass
    assert readers == []
    intent = json.loads((OUT.parent / "build-intent-prefix.json").read_bytes())
    transformed = []
    with lc.lease():
        lc.source_check(intent["source"])
        before = helper.allocated_union(intent["owned_outputs"])
        for row in rows:
            raw = row["raw"]
            original = row["original"]
            packed = raw.with_name("quoridor-runner.lossless.xz")
            with raw.open("rb") as source, packed.open("xb") as target:
                with lzma.LZMAFile(target, "w", preset=1) as zipped:
                    for block in iter(lambda: source.read(1024**2), b""):
                        zipped.write(block)
            digest = hashlib.sha256()
            size = 0
            with lzma.open(packed, "rb") as stream:
                for block in iter(lambda: stream.read(1024**2), b""):
                    digest.update(block)
                    size += len(block)
            assert (
                digest.hexdigest() == original["sha256"] and size == original["bytes"]
            )
            assert f"{stat.S_IMODE(raw.stat().st_mode):04o}" == original["mode"]
            assert helper.ref(raw) == original
            raw.unlink()
            transformed.append(
                dict(
                    original=original,
                    compressed=helper.ref(packed),
                    original_STOP=row["stop"],
                    fullstream_raw_SHA_bytes_mode_restoration_verified=True,
                )
            )
        after = helper.allocated_union(intent["owned_outputs"])
    peak = after["allocated_B"] + 232067072 + 20 * 1024**2
    receipt = dict(
        status="LOSSLESS_ENDED28_29_IMAGES_RETAINED_FOR_ACTUAL_SOFTWARE_PEAK",
        transformations=transformed,
        restoration="xz decompress each exact original path and restore original0755; original manifest identities unchanged, fullstream verified before unlink",
        actual_targeted_exe_maps_readers=readers,
        before=before,
        after=after,
        allocated_saved_B=before["allocated_B"] - after["allocated_B"],
        projected_genuine_peak_B=peak,
        whole_B=intent["limits"]["owned_B"],
        source_EX_NB_acquired_released=True,
        source_leases=[],
        model_RAW_FAILED_results_or_used_quota_deleted=False,
        spent_science_calls_nodes_costs_unchanged=True,
        refund_loan_cap_increase=False,
        scope="Only four named purpose-ended28/29 genuine images, including used comparison images, kept losslessly; no scientific execution/revalidation or oldimage alias/global asset inventory. Prior7fe representation separate.",
        host_future_quiet=False,
    )
    with (OUT / "lossless-ended-images-representation.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            dict(
                saved=receipt["allocated_saved_B"],
                after=after,
                projected_peak=peak,
                whole=receipt["whole_B"],
            )
        )
    )
    assert peak <= receipt["whole_B"]


if __name__ == "__main__":
    main()
