# ProbCut 1/3 校正32件の有限結果

校正だけから1候補を凍結した。確認側は未読・未実行であり、速度・棋力・誤cut安全性・既定採用は未成立。

|項目|実績|
|---|---:|
|親Search / 明示浅深参照 / counted calls|32 / 392 / 424|
|累積親nodes（参照を一度だけ含む）|2,628,972|
|参照nodes内数|241,810|
|完成・有限・非terminal Exact組 / families|196 / 17|
|実remaining3 nonPV/TT後の機会counter|3,339|
|傾き / 切片 / margin|1.000012993812561 / -0.021842867136001587 / 0.7459650039672852|
|校正MSE|0.012151842597618426|

事前のOLS一回、FP32係数への丸め後の最大過大予測＋0.02×非terminal域、marginのFP32上向き丸めをそのまま使用した。196組・17familiesは最低64組・8familiesを満たす。margin約0.746は大きく、確認で実betaの予測cutが十分得られるかは未測定。相関/MSEだけでは採用しない。

参照は同じ内部局面・全weighted historyの局所的LMR/PVS OFF-method探索であり、WDL oracleではない。最初の最大8組、family内・継続sessionの相関、参照によるTT/history warmingを保持する。根のstock/contact/goal帯は実内部節点の層ではなく、その内部層とrankはUNKNOWN。

Search総費2.587851853s、whole driver 3.287048795s、setup 0.002131774s、reset合計0.465865777s、drop 0.000270611s。診断参照込みの記述であり比較速度ではない。元outer12.448142946930602sを一度だけ計上し、nested/native秒を加算しない。

係数SHA `c31f98961da0bd66bde223d07c3a46274c7c012912ff19dd4b1de83296e6d032`、校正evidence SHA `3d001c4d08a000b32509e84b7b809d7a5ba9ebc4cfe693e45a580ca8a3b70d0f`。確認32件の結果検査・送信より前に凍結済み。次は実supportが届いた場合だけ同じ係数のまま確認し、ALL predicted／decidable／false／UNKNOWNを別分母で判定する。再fit・refill・別pair・既定変更はない。

通常manifestは元sequenceが一度finalize済み。collector初回のjournal時刻欄完全一致拒否は保存し、最終resultだけに追加される2時刻欄の表現差のみ修正した。fit helper初回lintの未使用import拒否はfit開始前で、実fitは一度。元FAILED/NULL/mask/費/pauses/seals/models/foreignを保持する。

根別・層別の全32件、費用、復元・呼出しcensusは [summary.json](/workspaces/quoridor/.worktree/assets/perf/cedar-probcut-v1/numeric-calibration-v1/analysis-v1/summary.json) と収集manifestを参照。
