# MPC30 固定深さ104件（最終clock前の記述）

全104件が要求深さまで完成し、全件を分母へ残した。元順序OFF–ON–ON–OFF、各26根・6 chronological sessions。同image、Current100%/Cedar/Control/基準LMR/PVS/path_tail/TT1M、凍結c31f係数はONだけ。

|両repeat総和 ON / OFF|比|
|---|---:|
|Search_seconds|0.954221285|
|nodes|0.984311484|
|evaluations|1.019390917|
|CPU_seconds|0.953396524|
|whole_driver_seconds|0.956282098|
|whole_before_result_publication_seconds|0.956417781|
|session_reset_seconds|1.117353726|

Search比はprobeを含む全Search時間の総和比。whole/resetの比とは別であり、max/minの比に読み替えない。凍結major根（minON/maxOFF>1.20かつ差>.002秒）は[]、totalSearch<=1.10はTrue。

実48,502,224nodes・39,939,768evals、38,034内部probe、probe1,282,708nodes/1,244,538evalsは内数、native predicted-cut counter22,656。probeやcut数は情報の独立性・有用性・誤cut率を示さない。LMR/PVSと選択cutにより木・値・手・PVが変わり得るため、同仕事fullwidth速度比や棋力・原因認定ではない。

matched-repeat action変更0/52、PV変更12/52。根別の全4観測・depth/手/PV/値bit/work、first/continuedとroot_walls_remaining帯をJSONへ保存。clock完成depth/receipt/terminal安全性は最終104前でPENDING。

元outer87.32741166499909秒を一度だけ保存し、4 nested/native秒は加算しない。通常manifestは元sequenceが各一度finalizeし、collectorは再finalize/実行0。実STOPと終了時holdingを長解析より先にRootへ返した。最終clock104は同じ全8controlの普通の継続であり、このreport/成績/reviewer/ACKを入口gateにしない。実終了holding/supportと本当の安全・正しさblockerだけを保持し、新設定・refill・fit・pair・既定変更はない。games256は未発行。

[全104対応・根別・層別・費用](/workspaces/quoridor/.worktree/assets/perf/cedar-probcut-v1/numeric-timing-fixed104-v1/analysis-v1/summary.json)。旧FAILED/NULL/mask/UNKNOWN/費/pauses/seals/defaultOFF/models/foreignは不変。
