# ProbCut 1/3 凍結確認32件

事前基準を満たしたため、同じ1候補の通常費用比較へ進む資格だけを記録する。速度・棋力・既定採用は未成立。

|分母・判定|実績|
|---|---:|
|全標本|234|
|予測cut ALL|47|
|参照側を判定可能|47|
|観測false cut / 判定可能|0 / 47|
|予測UNKNOWN / ALL predicted|0 / 47|
|予測family数|9|
|予測しない / 閾値が域外|93 / 94|

最低32判定可能・8予測families・false0・UNKNOWN予測割合<=.1を満たす。234件をすべて上の区分へ残した。0/47は誤りなしの保証や独立node IIDを示さず、予測47件はroot-relative ply1に集中する。局所同一選択探索のOFF参照でありWDL oracleではない。実ON-treeのnarrow probe、TT/history warming、probe込み費用、時計退行は次段階で未測定のまま。

校正196組/17familiesの一回OLS係数 c31f9896（傾き1.000012993812561、切片-.021842867136001587、margin.7459650039672852）を変更せず使用。校正・確認familiesは非重複。再fit・閾値変更・不利標本除外・追加Search/RNGは0。

確認32親+468明示参照=500calls、親nodes3,145,182（参照288,827は内数）。校正込み924calls/5,774,154nodes。確認Search総費3.071917016s、whole_driver3.819475892s、outer12.871572802891023sは一度だけ保存。nested8.837230099947192sを加算しない。これらは診断参照込みの記述であり、公平なOFF/ON速度比ではない。

次208は同じ26prefix/6chronological sessions、固定深さ（既存root4D5/upper8）と100ms5を各OFF-ON-ON-OFF、48sessions/208M。ONだけ凍結params、両arm診断samplesなし。全8config/requestを固定し、実support・現行join・fresh admissionは未発行。全8将来出力見積り247463936B、容量上必要なら同じ科学を4RUNずつ2寿命（各将来155189248B、analysis allowanceは共同）で扱える。再設計・新たな有意性gate・quota貸与はない。games256は費用/時計等の条件と実support前で未発行。

原FAILED/mask/UNKNOWN/費/pauses/seals/defaultOFF/models/foreignを保持。STOP配送helper初回はcollection-guard-v2という古い参照名でbody冒頭に拒否、v1への一箇所修正後に実STOPを返した。再native/finalizeなし。

全分母・層別は [locked confirmation](/workspaces/quoridor/.worktree/assets/perf/cedar-probcut-v1/numeric-confirmation-v1/analysis-v1/locked-confirmation-v1/confirmation.json)、[summary](/workspaces/quoridor/.worktree/assets/perf/cedar-probcut-v1/numeric-confirmation-v1/analysis-v1/summary.json)、[次control](/workspaces/quoridor/.worktree/assets/perf/cedar-probcut-v1/timing208-preparation-v1/binding.json) を参照。
