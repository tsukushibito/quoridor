# 単一深さ組ProbCutの有限検証

Root324への2026-10-20直接指示「MPCの検証を進めて」による新しい具体仕事。一般棋力改善は仮説。初回は単一pairから実装・校正・関連確認・有限比較・保存解析まで進める。立案だけで停止しない。

作者は既存Sol6.1/high `01a11004-79f3-7c20-872c-432a2c347664`、cwd `/workspaces/quoridor`を再用する。再開時にdanger-full-access／approvalPolicy neverを明示し、saved model／effort／cwdを維持、実turn_contextを通常command前に確認する。作者の唯一のwriter範囲は`.worktree/assets/perf/cedar-probcut-v1/`。immutable Gitの必要ownerのみ読み、薄いbefore/post/patchを返す。Main／Git／index／Cargo／docsは324のみ。新session／常設役／Astra／再帰委譲なし。変更した選択探索／TT／解釈境界の重要確認は既存Sol6.1/max `01a118a1-aef1-7252-b21b-42f07dd5b1e6`へRootが固定packetを必要な時点で配送する。未固定sourceのreviewやACK待ちを入口にしない。

最初の実作業を今開始する。現Git0955e9bdのnegamax／child／TT／PVS／LMR／累積予算／history／namespaceと、既存合法full-prefixのcompact索引・saved metricsの必要箇所だけを読む。元28/29 private sourceや旧RAWを再走査せず、source共通実装と校正入力を具体化する。現sourceのterminal優先、同depth TT意味、raw有限域を確認し、nonPVの適用根拠を明示する。窓幅だけでPV資格を偽装しない。pair候補はshallow1/deep3から実機会を考え一つ選び、2/4等ならprobe費と実depth分布の事前理由を残す。typed configへpair／残深さ／margin／領域／ONOFF／少数係数を集約。別engine、experiment literal分岐、新manager／DSL／恒常mirror／旧shimは作らない。

対照はCURRENT通常baseline、aspirationOFF、Current100% history、既定LMR、path_tail、Control、PVS、TTtotal1M、N1、Cedar C BEST58305。原29/29.3の小標本観測・no128・撤去／費は不変で、aspirationを復活させない。教師／model／NNUE数学／LMR係数／ordering／terminal／threefoldを同時変更しない。新baseline BUILD2e6e6dcd/image7fe55b62はsoftware資格のみ・未計測で、今後変更sourceには真正共通imageが必要。旧image aliasや成功suite再演はしない。

一次資料はJiang/Buro https://www.cs.ubc.ca/~jiang/papers/mpc_main.pdf 、原MPC https://skatgame.net/mburo/ps/improve.pdf 、official Stockfish https://github.com/official-stockfish/Stockfish/blob/master/src/search.cpp 。深さpair／phase校正／probe内MPC再帰禁止を参考にする。チェスcapture/qsearch条件・数値定数を移植しない。過去frame23のMPCはOFF計画/schemaのみであり、校正済み係数や現実装ではない。

校正入力は既存unsealed真正full-prefixから結果に依存せずfamily分割を先に固定。校正と最終確認はfamily非重複。元26rootsだけへ合わせ続けず、壁の多い序中盤／少壁／零壁／接触／goal近傍の実数を残す。索引と既存バージョン付き入力を再用し、新自己対局／NPZ／封印読取／model取得／学習を入口にしない。最大512浅深対応標本を初回上限の目安に、必要量だけ選ぶ。実際のnonPV内部節点・実窓の先頭固定標本が可能なら使い、root coldのみなら分布差と小さい実発動確認を明記。深い参照はMPC OFF・同じ固定LMR探索の完成値／typed boundで、WDL oracleや数学的最善と呼ばない。未完をexact校正へ混ぜずUNKNOWN、cap／depth／refillを勝手に増やさない。

同じ人間指示の補足：校正pair shallow d／deep Dは適用時の実negamax残深さDへ厳密一致させる。1/3ならdepth==3だけで、depth>=3全般や暗黙のdepth-2可変pairへ流用しない。typed configの最小条件で表し、追加framework／pair／許可枠はない。MPC-OFFの局所参照boundが実betaのどちら側か決められない場合と未完了はUNKNOWN。予測cut全分母・判定可能分母・誤cut分母を分け、少数確認の誤cut0を無誤り保証にしない。返信や旧issuecloseを工程gateにしない。

回帰＋誤差幅または経験的marginの簡素な一候補を校正だけで凍結。相関/MSEだけで採用せず、実beta境界の誤跨ぎ率・大きさ・層・分母と、発動しない機会・probe込み仕事を調べる。層はまず報告用、小標本99.9%保証や独立node IID、多数専用係数を作らない。初回はroot/PVを避けたnonPV片側高margin cutoff。確認で再選択しない。

goal／threefold／fullweighted history、親Position／accumulator／scratch復元、有限score／terminal sentinel、累積node／deadline／reserve／cancel／errorとlast-completed snapshotを守る。probe内MPC再帰は禁止。浅い探索／推測cutを深いExact／solver値にしない。TT格納depth／bound／config-evaluator namespaceは既存共通経路へ整え、別TT/state frameworkを足さない。OFF hot pathにscan／clone／clockを追加しない。誤cutのdeep referenceは診断ONだけ、timingでは無効。observerは必要少数のply／残深さ／順位／試行仕事counterのみ、pernode時計／大traceなし。

意味ある新境界だけの限定softwareを準備：誤cut回帰、PV/対象外、budget中断と完全復元、probe再帰禁止、TT型／分離／実config。scoped formatter/lint、必要newtests、affectedClippy、真正共通imageをRootが行う。係数値ごとにsuite/reviewを繰り返さない。固定source packetに新boundary質問・exact selectors・normalconsumer対応・before/post/薄patch・実sourceSTOPを付けRootへ直接返す。作者自身のSOURCE_CLEARやreview dispatchはしない。

非対局の新科学は全段階合計2048 top-level/明示child Search calls、各通常1Mnode以内、aggregate2.048Gまで。収集親Search、浅深probe/参照、校正／確認、補助診断、連続／100ms比較を実行ledgerへ全部数える。既存標本の引用は再実行ではない。内部MPC probeのnodes/evalsは同じtop-level累積枠に含め、probe回数と明示child Searchを区別し、隠れたcollector/参照callを作らない。どの呼出しを数えるか実入場前のprotocolに明示し曖昧ならRootへ具体的に返す。2048を埋める目標にせず、pair不足・機会不足・多数誤cut・大幅退行なら有限結果で止める。未使用quotaの貸与／refund／自動refillなし。

実入場前に入力／family split／深さ／設定／順序／主要指標・gateを既存config/manifestへ凍結。速度は同真正imageのOFF対凍結ON、連続SearchSession再用、serial順序反転／二反復。Search総費probe込み／whole／setup／reset／drop、通常木／probe／全nodes/evals/TT、ply／残深さ機会／予測cut／実cut／誤cut、100ms/5ms完成depth／action／PVと主要退行を残す。異なる木を同仕事speedupと呼ばず、単なるcut数／nominaldepth／2%差を採用根拠にしない。局所誤cutを対局敗因へ直結しない。

適用機会とprobe込み費用に見込みがあり、機械的誤実装／時計／不正手／復元の未解決blockerがなければ、一候補を凍結して最大256局／128真正開始family両色、同100ms/5ms／max200ply等現役rulesでvsOFFを今回承認。normal8局parallel inlet、実物理非競合／hostreserve／色・lane平衡と許容条件ゆらぎを記録。足りなければ実成立する並列数を選ぶ。新parallel pilot／旧batch再演／CI合算なし。非対局node枠を対局に貸さず、対局は元per-search safety/clockと有限局数で止め、根拠ないaggregate capで完走を妨げない。失敗／UNKNOWNを保持、成功局replay/refillなし。family不確実性・得点／depth／node分布を保存し、重要解釈は同Maxの関連確認。最初のpair支持時だけ小さい複数pair拡張案まで、今回は無制限MPC sweepなし。

今のsource作業は候補CPU2の一logical CPU（core1／sibling3を使わない）、guardian18、family1GiB管理込み、hostreserve4GiB、GPU0を既存sourceguardで実snapshot・affinity・directwait/reap/handles/TMP/停止に結び付ける。固定idleleaseなし、競合時は実空きの一CPUへ明記して解決。reviewも一CPU／family1GiB。serial nativeはworker12/main0/guardian18候補、family4GiB管理込み／host4/G0。arenaは現役parallel inlet／実core、family最大8GiB／host4/G0でRootが実空きから解決。作者による今のnative/model/Search/build/RNG submitは未発行：現source/校正準備は直ちに実施し、固定source→関連review→Root疎合成/software→通常fresh science entryをそのまま継続する。これは人間ACK／parentclose gateではなく真正source/image/入力の依存である。

通常source／限定tests／incremental build／reviewにadvance microstorage gateなし、終了後affectedを一度観測。大きいscience出力だけRootが現保持／圧縮／serialTMPを一wholeで50,000,000,000B内に解決。旧used／RAW／model削除、旧枠貸与／refund、全域audit／tiny output capで開始を遅らせない。native/perf時計と重いbuild/ML/RAWIOはactualSTOPで直列、light prep／他独立readyを止めない。研究job既存通知／取消／directwait-reap/handles/TMPを再用。

実source開始の時刻・最初の実delta/校正入力freezeを通常Beadsと一回の内容報告でRoot324へ直接届け、その後固定packetまで独立継続する。受付／sourceSTART／compiler／nativeSTARTを区別する。最終成果は短い日本語report／条件表／実STOP／失敗／費／Git復元元、Rootが正本findingsと既存agendaへ統合し意味あるcommit/push。用途終了の比較専用sourceは保全後整理。全USERPAUSE323/342.17、封印newE/oldfits96、models/weights/defaults、foreign、旧FAILED/NULL/UNKNOWN/費は不変。28/29のcloseやRootの返信を再開条件にしない。
