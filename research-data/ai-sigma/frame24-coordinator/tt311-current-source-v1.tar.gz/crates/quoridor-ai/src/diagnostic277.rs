//! Private snapshots observe the existing table. They never reuse it in search.
use super::*;
use serde_json::json;
use std::cell::RefCell;
thread_local! { static SNAPSHOT: RefCell<Option<Vec<Entry>>> = const { RefCell::new(None) }; }
pub(super) fn capture(t: &Table) {
    SNAPSHOT.with(|s| {
        if s.borrow().is_some() {
            *s.borrow_mut() = Some(
                t.slots
                    .iter()
                    .flatten()
                    .map(|e| Entry {
                        key: e.key.clone(),
                        depth: e.depth,
                        value: e.value,
                        bound: e.bound,
                        best: e.best,
                    })
                    .collect(),
            );
        }
    });
}
struct Owned(NnueEvaluator);
impl StaticEvaluator for Owned {
    fn prepare_context(&self, c: &SigmaContext) -> Result<Option<EvalAccumulator>> {
        self.0.prepare_context(c)
    }
    fn advance_context(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
    ) -> Result<Option<EvalAccumulator>> {
        self.0.advance_context(a, c)
    }
    fn evaluate(&self, c: &SigmaContext, a: Option<&EvalAccumulator>) -> Result<f32> {
        self.0.evaluate(c, a)
    }
}
fn describe(r: &SearchResult) -> serde_json::Value {
    json!({"action":r.action,"value_bits":r.value.map(f32::to_bits),"completed_depth":r.completed_depth,"pv":r.pv,"nodes":r.stats.nodes,"native_nn":r.stats.evaluations,"delta_updates":r.stats.delta_updates,"tt_hits":r.stats.tt_hits,"tt_cutoffs":r.stats.tt_cutoffs,"stop":format!("{:?}",r.stop)})
}
#[test]
fn diagnostic277_tt_sequence() {
    assert_eq!(std::env::var("ORT_DISABLE_TELEMETRY").as_deref(), Ok("1"));
    let cfg: serde_json::Value = serde_json::from_slice(
        &std::fs::read(std::env::var("DIAGNOSTIC277_CONFIG").unwrap()).unwrap(),
    )
    .unwrap();
    assert_eq!(cfg["task"], "frame22-advance-tt-277-v1");
    let model = Arc::new(Model::load(cfg["model"].as_str().unwrap()).unwrap());
    let generation = model.fingerprint();
    let eval = Owned(NnueEvaluator::new(model));
    let mut rows = Vec::new();
    let mut nn = 0;
    let mut nodes = 0;
    for name in ["initial"] {
        let f = cfg["fixtures"]
            .as_array()
            .unwrap()
            .iter()
            .find(|f| f["name"] == name)
            .unwrap();
        let prefix: Vec<u16> = serde_json::from_value(f["prefix"].clone()).unwrap();
        let root = SigmaContext::from_prefix(&prefix).unwrap();
        let original = Key::of(&root);
        SNAPSHOT.with(|s| *s.borrow_mut() = Some(Vec::new()));
        let limits = SearchLimits {
            max_depth: 3,
            max_nodes: 2500,
            time_limit: None,
            ..SearchLimits::default()
        };
        let old = search(&root, &eval, &limits, &AtomicBool::new(false)).unwrap();
        let saved = SNAPSHOT.with(|s| s.borrow_mut().take().unwrap());
        nn += old.stats.evaluations;
        nodes += old.stats.nodes;
        assert_eq!(Key::of(&root), original);
        if old.completed_depth < 2 || old.pv.len() < 2 {
            rows.push(json!({"fixture":name,"prefix":prefix,"old_search":describe(&old),"retained_entries":saved.len(),"steps_status":"NOT_RECORDED_SHORT_COMPLETED_PV","steps":[]}));
            continue;
        }
        let mut next = root.clone();
        let mut steps = Vec::new();
        for (i, &action) in old.pv.iter().take(2).enumerate() {
            assert!(next.legal_ids().contains(&action));
            next = next.play(action).unwrap();
            let key = Key::of(&next);
            let entry = saved.iter().find(|e| e.key == key);
            let root_before = key.clone();
            let fresh = search(
                &next,
                &eval,
                &SearchLimits {
                    max_depth: 1,
                    max_nodes: 1000,
                    time_limit: None,
                    ..SearchLimits::default()
                },
                &AtomicBool::new(false),
            )
            .unwrap();
            nn += fresh.stats.evaluations;
            nodes += fresh.stats.nodes;
            assert_eq!(Key::of(&next), root_before);
            let exact_horizon = entry.is_some_and(|e| {
                matches!(e.bound, Bound::Exact) && e.depth == fresh.completed_depth
            });
            let value_diff = entry.and_then(|e| fresh.value.map(|v| (v - e.value).abs()));
            steps.push(json!({"legal_step":i+1,"action_played":action,"same_side_as_initial":next.position().turn==root.position().turn,"ply":key.ply,"history_records":key.history.len(),"full_key_hash":key.hash(),"matched_entry":entry.map(|e|json!({"depth":e.depth,"bound":format!("{:?}",e.bound),"value_bits":e.value.to_bits(),"best":e.best,"usable_depth1":e.depth>=1,"usable_depth2":e.depth>=2,"usable_depth3":e.depth>=3,"best_is_legal":e.best.is_none_or(|a|next.legal_ids().contains(&a))})),"fresh_depth1":describe(&fresh),"same_exact_horizon":exact_horizon,"same_exact_horizon_abs_delta":if exact_horizon {value_diff} else {None},"same_exact_horizon_action_equal":if exact_horizon {entry.map(|e|e.best==fresh.action)} else {None},"root_unchanged":true,"root_consults_table":false}));
        }
        rows.push(json!({"fixture":name,"prefix":prefix,"root_side":root.position().turn,"initial_key_hash":original.hash(),"old_search":describe(&old),"retained_entries":saved.len(),"entries_after_one_ply":saved.iter().filter(|e|e.key.ply==original.ply+1).count(),"entries_after_two_ply":saved.iter().filter(|e|e.key.ply==original.ply+2).count(),"steps":steps}));
    }
    assert!(nn + 1006 <= 5506 && nodes <= 4500);
    let result = json!({"task":"frame22-advance-tt-277-v1","schema":"fullhistory-tt-opportunity-v1","status":"PASS","model_fingerprint":generation,"native_nn":nn,"processed":nodes,"rows":rows,"scratch_reuse_enabled":false,"actual_cross_search_reuse":false,"scope":"potential exact fullhistory key matches only; table captured after possibly partial depth3; legal completed PV states; different-depth bounds not exact truth; fresh-root vs delta float paths can differ; model generation/schema external to current search-local key"});
    std::fs::write(
        cfg["tt_output"].as_str().unwrap(),
        serde_json::to_vec_pretty(&result).unwrap(),
    )
    .unwrap();
}

/// NN0 API-contract verification; no model construction, search, or timing profile.
#[test]
fn cursor_contract277_nn0() {
    let prefixes: &[&[u16]] = &[
        &[],
        &[13, 67, 81, 66, 14, 65],
        &[13, 67, 81, 66, 14, 65, 143, 126, 150, 64, 141, 151],
        &[13, 67, 22, 58, 31, 49, 40],
    ];
    let mut counts = [0usize; 3];
    for prefix in prefixes {
        let parent = SigmaContext::from_prefix(prefix).unwrap();
        let before = Key::of(&parent);
        for action in parent.legal_ids() {
            let child = parent.play(action).unwrap();
            child.validate_normal().unwrap();
            assert_eq!(Key::of(&parent), before);
            assert_eq!(child.total_ply(), parent.total_ply() + 1);
            assert_ne!(child.position(), parent.position());
            counts[0] += 1;
            if child.position().horizontal != parent.position().horizontal
                || child.position().vertical != parent.position().vertical
            {
                counts[1] += 1;
            } else {
                counts[2] += 1;
            }
        }
    }
    assert_eq!(counts[0], 503);
    assert!(counts[1] > 0 && counts[2] > 0);
    println!(
        "cursor_contract277 NN0 legalChildren={} wallChanged={} wallUnchanged={}",
        counts[0], counts[1], counts[2]
    );
}
