"""Bounded, single-owner build/science entry with fresh runtime and proc receipts."""

import argparse
import ctypes
import hashlib
import json
import os
import pathlib
import signal
import subprocess
import time
from datetime import datetime, timezone

ROOT = pathlib.Path("/workspaces/quoridor")
WT = ROOT / ".worktree/frame21-search"
OUT = WT / "research-data/ai-sigma/frame24-persistent-tt"
TARGET = ROOT / ".artifacts/rust-migration/target"


def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def proc(pid):
    try:
        p = pathlib.Path("/proc") / str(pid)
        v = (p / "stat").read_text().rsplit(")", 1)[1].split()
        cmd = (p / "cmdline").read_bytes().split(b"\0")
        return {
            "pid": int(pid),
            "tick": v[19],
            "ppid": int(v[1]),
            "pgrp": int(v[2]),
            "state": v[0],
            "cpu_ticks": int(v[11]) + int(v[12]),
            "rss": int(v[21]) * os.sysconf("SC_PAGE_SIZE"),
            "argv": [a.decode(errors="replace") for a in cmd if a],
        }
    except (OSError, ValueError, IndexError):
        return None


def snapshot():
    return {
        x["pid"]: x
        for p in pathlib.Path("/proc").iterdir()
        if p.name.isdecimal() and (x := proc(p.name)) and x["argv"]
    }


def heavy(p):
    # Inspect real executable/argument positions, never shell -c body text.
    a = p["argv"]
    name = pathlib.Path(a[0]).name
    if name in ("cargo", "rustc", "clippy-driver", "sccache", "quoridor-run", "quoridor_run"):
        return True
    if name.startswith("quoridor_ai-"):
        return True
    if name.startswith("python") and len(a) > 1 and not a[1].startswith("-"):
        script = a[1]
        return any(
            k in script
            for k in (
                "guard",
                "train",
                "fit",
                "science",
                "quality",
                "import",
                "predict",
                "evaluate",
                "research-job",
            )
        )
    return False


def allocated(path):
    seen = set()
    total = 0
    for p in pathlib.Path(path).rglob("*"):
        if p.is_file():
            s = p.stat()
            k = (s.st_dev, s.st_ino)
            if k not in seen:
                seen.add(k)
                total += s.st_blocks * 512
    return total


def admit(reg):
    runtime = ROOT / "research-data/ai-sigma/frame24-steward/running-loaded-v1.json"
    loaded = json.loads(runtime.read_text())
    operation = loaded["operation"]
    state = json.loads((pathlib.Path(operation["state_dir"]) / "state.json").read_text())
    ex = json.loads(pathlib.Path(operation["expectations_path"]).read_text())
    mismatch = [p for p, s in ex["input_hashes"].items() if sha(p) != s]
    assert len(ex["input_hashes"]) == 24 and not mismatch, mismatch
    assert state["phase"] == "running" and not state["recovery_required"]
    assert sha(operation["config_path"]) == state["config_sha256"] == loaded["loaded_config_sha"]
    assert (
        sha(state["binding"]["contract_file"])
        == state["contract_sha256"]
        == loaded["loaded_contract_sha"]
    )
    for key in ("scheduler", "monitor"):
        identity = loaded[key]
        current = proc(identity["pid"])
        assert current and current["tick"] == identity["start_ticks"]
    assert (
        pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        == loaded["scheduler"]["boot_id"]
    )
    bound = {p: sha(p) for p in reg["source_bindings"]}
    assert bound == reg["source_bindings"], bound
    assert reg["issue"] == "quoridor-4lc.311" and reg["task"] == "frame24-persistent-tt-311-v1"
    assert datetime.now(timezone.utc).isoformat() < "2026-10-06T01:40:00"
    before = snapshot()
    time.sleep(0.15)
    current = snapshot()
    me = os.getpid()
    ancestors = {me}
    cursor = me
    while cursor in current and current[cursor]["ppid"] not in ancestors:
        cursor = current[cursor]["ppid"]
        ancestors.add(cursor)
    foreign = [p for pid, p in current.items() if pid not in ancestors and heavy(p)]
    assert not foreign, foreign
    mem = pathlib.Path("/proc/meminfo").read_text()
    available = (
        int(next(x.split()[1] for x in mem.splitlines() if x.startswith("MemAvailable:"))) * 1024
    )
    assert available > 2 * 1024**3
    gpu = subprocess.run(
        ["nvidia-smi", "--query-compute-apps=pid,used_memory", "--format=csv,noheader"],
        capture_output=True,
        text=True,
        timeout=3,
    )
    assert not gpu.stdout.strip(), gpu.stdout
    overlay = ROOT / "research-data/ai-sigma/frame24-steward/storage-311-category-overlay-v2.json"
    assert json.loads(overlay.read_text())["TT_new_reserved_B"] == 2097152
    own = allocated(OUT) + sum((WT / p).stat().st_blocks * 512 for p in reg["owned_sources"])
    assert own + reg["remaining_save_forecast_B"] < 2097152
    return {
        "UTC": datetime.now(timezone.utc).isoformat(),
        "runtime_SHA": sha(runtime),
        "current24": bound,
        "runtime_inputs_24": ex["input_hashes"],
        "state": state,
        "exact2": {k: proc(loaded[k]["pid"]) for k in ("scheduler", "monitor")},
        "foreign": foreign,
        "sample_ticks": {
            pid: p["cpu_ticks"] - before.get(pid, p)["cpu_ticks"]
            for pid, p in current.items()
            if p["cpu_ticks"] != before.get(pid, p)["cpu_ticks"]
        },
        "mem_available": available,
        "gpu": gpu.stdout,
        "overlay_SHA": sha(overlay),
        "own_allocated_B": own,
        "save_forecast_B": reg["remaining_save_forecast_B"],
        "target_before_B": allocated(TARGET),
        "future_free_guaranteed": False,
    }


def run_commands(reg, phase):
    entry = OUT / reg.get("entry_label", phase)
    entry.mkdir(exist_ok=True)
    commands = reg[phase + "_commands"]
    cap = (120 - reg.get("previous_compile_commandwall_s", 0)) if phase == "compile" else 60
    receipt = {
        "task": reg["task"],
        "phase": phase,
        "admission": admit(reg),
        "commands": [],
        "MAX1_science": phase == "science",
    }
    (entry / "admission.json").write_text(json.dumps(receipt["admission"], indent=2) + "\n")
    ctypes.CDLL(None).prctl(36, 1, 0, 0, 0)  # PR_SET_CHILD_SUBREAPER: reap own orphan descendants.
    if phase == "science":
        with (OUT / "science-attempt-consumed.json").open("x") as mark:
            json.dump(
                {"task": reg["task"], "MAX": 1, "UTC": datetime.now(timezone.utc).isoformat()}, mark
            )
    started = time.monotonic()
    all_ids = {}
    for index, argv in enumerate(commands):
        remaining = cap - (time.monotonic() - started)
        assert remaining > 0
        env = os.environ.copy()
        env.update(CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS="1", ORT_DISABLE_TELEMETRY="1")
        with (entry / f"command-{index}.log").open("w") as log:
            child = subprocess.Popen(
                ["/usr/bin/taskset", "-c", "3", *argv],
                cwd=WT,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            identity = proc(child.pid)
            (entry / f"actual-start-{index}.json").write_text(
                json.dumps(
                    {
                        "UTC": datetime.now(timezone.utc).isoformat(),
                        "argv": argv,
                        "identity": identity,
                        "source_SHA": reg["source_bindings"],
                    },
                    indent=2,
                )
                + "\n"
            )
            t = time.monotonic()
            reason = None
            peak = 0
            while child.poll() is None:
                ps = snapshot()
                ours = [p for p in ps.values() if p["pgrp"] == child.pid]
                for p in ours:
                    all_ids[(p["pid"], p["tick"])] = p
                peak = max(peak, sum(p["rss"] for p in ours))
                foreign = [
                    p
                    for p in ps.values()
                    if heavy(p) and p["pgrp"] != child.pid and p["pid"] != os.getpid()
                ]
                if time.monotonic() - started > cap:
                    reason = "COMMANDWALL_CAP"
                elif peak > 1792 * 1024**2:
                    reason = "RSS_GUARD"
                elif foreign:
                    reason = "FOREIGN_MEASUREMENT"
                    receipt["foreign_during"] = foreign
                if reason:
                    os.killpg(child.pid, signal.SIGTERM)
                    break
                time.sleep(0.1)
            try:
                code = child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                code = child.wait()
            receipt["commands"].append(
                {
                    "argv": argv,
                    "identity": identity,
                    "exit": code,
                    "reason": reason,
                    "wall_s": time.monotonic() - t,
                    "RSS_peak_B": peak,
                    "wait": True,
                }
            )
            if code != 0 or reason:
                break
    for _ in range(20):
        try:
            while os.waitpid(-1, os.WNOHANG)[0]:
                pass
        except ChildProcessError:
            break
        time.sleep(0.05)
    receipt["commandwall_s"] = time.monotonic() - started
    receipt["recorded_identities"] = list(all_ids.values())
    receipt["current_exact_remaining"] = [
        p for p in all_ids.values() if (q := proc(p["pid"])) and q["tick"] == p["tick"]
    ]
    receipt["current_source_matches_registration"] = all(
        sha(p) == s for p, s in reg["source_bindings"].items()
    )
    receipt["target_after_B"] = allocated(TARGET)
    receipt["nativeNN"] = 0  # This registered fixture uses analytical Distance only.
    (entry / "process.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(
        json.dumps(
            {
                "phase": phase,
                "wall_s": receipt["commandwall_s"],
                "commands": receipt["commands"],
                "remaining": receipt["current_exact_remaining"],
            }
        )
    )
    return (
        0
        if len(receipt["commands"]) == len(commands)
        and all(x["exit"] == 0 and x["reason"] is None for x in receipt["commands"])
        and not receipt["current_exact_remaining"]
        else 1
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", required=True)
    parser.add_argument("--phase", choices=["compile", "science"], required=True)
    args = parser.parse_args()
    reg = json.loads(pathlib.Path(args.registration).read_text())
    raise SystemExit(run_commands(reg, args.phase))


if __name__ == "__main__":
    main()
