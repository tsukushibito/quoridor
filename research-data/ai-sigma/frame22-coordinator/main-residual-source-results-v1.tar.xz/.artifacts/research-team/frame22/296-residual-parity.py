"""Fixed retained-weight check of the maintained export/native search boundary."""

import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

import numpy as np
import torch
from quoridor_training.common import resolve_config
from quoridor_training.train import build_model, export

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame22-coordinator/main-residual-functional-r2"
OUT.mkdir(exist_ok=False)
freeze_path = (
    ROOT
    / "research-data/ai-sigma/frame23-public-sigma-z-learning/final-saved-freeze-v1/candidate-freeze-v1.json"
)
freeze = json.loads(freeze_path.read_text())
assert (
    hashlib.sha256(freeze_path.read_bytes()).hexdigest()
    == "49dbc1ec576bd7ccd97d4dc17d744a5153ff1de18b43716a6330542302c39706"
)
for key in ("checkpoint", "native_manifest", "native_weights", "config"):
    value = freeze["candidate"][key]
    assert hashlib.sha256(Path(value["path"]).read_bytes()).hexdigest() == value["SHA"]
scale_ref = freeze["model_settings"]["scale"]
assert hashlib.sha256(Path(scale_ref["path"]).read_bytes()).hexdigest() == scale_ref["SHA"]
scale = json.loads(Path(scale_ref["path"]).read_text())
cfg = resolve_config(freeze["candidate"]["config"]["path"])
cfg["model"]["architecture"] = "distance_residual"
cfg["evaluation"]["monitor"] = "row"
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
model = build_model(cfg["model"], scale)
model.load_state_dict(
    torch.load(freeze["candidate"]["checkpoint"]["path"], map_location="cpu", weights_only=True)[
        "model"
    ]
)
model.eval()
with tempfile.TemporaryDirectory(dir=OUT) as temporary:
    manifest = export(model, cfg, scale, {"a": 0.0, "b": 8.0}, Path(temporary) / "export")
    exported = json.loads(manifest.read_text())
    assert exported["weights_SHA"] == freeze["candidate"]["native_weights"]["SHA"]
    assert "training_target" not in exported and "target_semantics" not in exported
    target_metadata = json.loads((manifest.parent / "training-target.json").read_text())
    assert target_metadata["training_target"] == "z"
    (OUT / "export-manifest-proof.json").write_text(json.dumps(exported, indent=2) + "\n")
    native_cfg = {
        "mode": "diagnose",
        "output": str(OUT / "native.json"),
        "counter": str(OUT / "counter.json"),
        "prefixes": [[], [13]],
        "engines": [
            {"id": "fixed-public-z", "kind": "distance_residual", "manifest": str(manifest)}
        ],
        "depths": [],
        "max_nodes": 500,
        "nn_cap": 38,
        "processed_cap": 1500,
        "wall_seconds": 5.0,
        "max_plies": 200,
        "cpu_core": 3,
        "ram_limit": 1792 * 1024**2,
        "host_ram_reserve": 1024**3,
    }
    config = OUT / "native-config.json"
    config.write_text(json.dumps(native_cfg, indent=2) + "\n")
    cli_source = (ROOT / "crates/quoridor-runner/src/bin/nnue-diagnose.rs").read_text()
    assert 'args[1] != "--config"' in cli_source
    assert native_cfg["depths"] == [] and native_cfg["nn_cap"] == 38
    run = subprocess.run(
        [
            str(ROOT / ".artifacts/rust-migration/target/release/nnue-diagnose"),
            "--config",
            str(config),
        ],
        text=True,
        capture_output=True,
        timeout=7,
    )
    (OUT / "native-stdout.log").write_text(run.stdout)
    (OUT / "native-stderr.log").write_text(run.stderr)
    assert run.returncode == 0, run.stderr
    native = json.loads((OUT / "native.json").read_text())
    maximum = 0.0
    count = 0
    for row in native["predictions"]:
        if "values" not in row:
            continue
        features = row["feature"]
        x = np.zeros((1, 2, 312), dtype=np.float32)
        for side, ids in enumerate(features["ids"]):
            x[0, side, ids] = 1.0
        d = np.array([features["distance"]], dtype=np.float32)
        side = torch.tensor([int(features["side"]) + 1], dtype=torch.long)
        with torch.inference_mode():
            value = float(model(torch.from_numpy(x), torch.from_numpy(d), side)[0])
        actual = row["values"][0]["value"]
        error = abs(value - actual)
        assert error <= 1e-5 + 1e-4 * abs(value)
        maximum = max(maximum, error)
        count += 1
    assert count == 2
    (OUT / "native-summary.json").write_text(
        json.dumps(
            {
                "native_keys": list(native),
                "native_NN": native.get("NN", native.get("nn")),
                "torch_NN": count,
                "max_abs": maximum,
                "fixed_weights_export_byteSHA_PASS": True,
                "old_frozen_model_changed": False,
                "new_fit": False,
                "retained_temp_weights": False,
            },
            indent=2,
        )
        + "\n"
    )
print("Maintained residual export, native diagnostic and Torch value parity PASS")
