"""Bounded main data/CLI validation, using the remaining coordinator NN0 window."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame22-coordinator/main-residual-validation"
OUT.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def proc(pid):
    try:
        p = Path("/proc") / str(pid)
        st = (p / "stat").read_text().rsplit(")", 1)[1].split()
        status = (p / "status").read_text()
        return {
            "pid": int(pid),
            "ppid": int(st[1]),
            "group": int(st[2]),
            "tick": st[19],
            "cpu": int(st[11]) + int(st[12]),
            "rss": int(status.split("VmRSS:")[1].split()[0]) * 1024 if "VmRSS:" in status else 0,
            "argv": (p / "cmdline").read_bytes().decode(errors="replace").split("\0")[:-1],
        }
    except (OSError, ValueError, IndexError):
        return None


def snapshot():
    return {
        int(p.name): item
        for p in Path("/proc").iterdir()
        if p.name.isdigit() and (item := proc(p.name))
    }


def compute(item):
    if not item["argv"]:
        return False
    exe = Path(item["argv"][0]).name
    if exe in {
        "cargo",
        "rustc",
        "clippy-driver",
        "teacher-qualify",
        "sigma-import",
        "nnue-diagnose",
        "route-feature-diagnose",
        "route-feature-diagnose-public-z-290-v1",
    }:
        return True
    if exe.startswith("python"):
        script = next((a for a in item["argv"][1:] if a.endswith(".py")), "")
        return any(
            x in script
            for x in ("frame23", "quoridor_training", "guard.py", "parity", "score_saved")
        ) and not any(x in script for x in ("research-job", "research-team", "research-scheduler"))
    return False


def main():
    ops = (
        ROOT
        / ".artifacts/ai-sigma/continuation-20261001/SIGMA-RESUME-OPERATIONS-92/frame22-extension23"
    )
    state = json.loads(
        (ROOT / ".artifacts/research-team/frame22-extension23/scheduler/state.json").read_text()
    )
    monitor = json.loads((ops / "monitor-process.json").read_text())
    expected = json.loads((ops / "expectations.json").read_text())
    hashes = {p: sha(p) == h for p, h in expected["input_hashes"].items()}
    assert len(hashes) == 24 and all(hashes.values()) and state["phase"] == "running"
    identities = [state["process"], monitor["process"]]
    assert all((p := proc(i["pid"])) and p["tick"] == str(i["start_ticks"]) for i in identities)
    assert sha(state["binding"]["config_path"]) == state["config_sha256"]
    assert sha(state["binding"]["contract_file"]) == state["contract_sha256"]
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    assert all(i["boot_id"] == boot for i in identities)
    before = snapshot()
    ancestors = {os.getpid()}
    pid = os.getpid()
    while pid in before and before[pid]["ppid"] not in ancestors:
        pid = before[pid]["ppid"]
        ancestors.add(pid)
    foreign = [p for pid, p in before.items() if pid not in ancestors and compute(p)]
    storage_path = ROOT / "research-data/ai-sigma/frame23-steward/storage-294-295-admission.json"
    storage = json.loads(storage_path.read_text())
    assert (
        not storage["errors"]
        and storage["total_current_unused_unknown_bytes"] < storage["cap_bytes"]
    )
    admission = {
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "current24": hashes,
        "runtime": identities,
        "foreign": foreign,
        "storage_SHA": sha(storage_path),
        "NN": 0,
        "CPU": 3,
        "compile_cap": 70.717306332,
        "main_source_SHA": {
            p: sha(ROOT / p)
            for p in [
                "crates/quoridor-nnue/src/residual.rs",
                "crates/quoridor-nnue/src/lib.rs",
                "crates/quoridor-ai/src/alphabeta.rs",
                "crates/quoridor-runner/src/bin/nnue-diagnose.rs",
                "crates/quoridor-nnue/tests/residual.rs",
            ]
        },
    }
    (OUT / "admission.json").write_text(json.dumps(admission, indent=2) + "\n")
    if foreign:
        print("NOT_STARTED_FOREIGN_COMPUTE")
        return 78
    plan = json.loads(Path(sys.argv[1]).read_text())
    assert plan["task"] == "quoridor-4lc.294"
    assert plan["hard_seconds"] <= plan["remaining_compile_seconds"] <= 70.717306332
    admission["registration"] = plan
    (OUT / (plan["name"] + "-admission.json")).write_text(json.dumps(admission, indent=2) + "\n")
    argv = ["/usr/bin/taskset", "-c", "3", *plan["argv"]]
    env = dict(
        os.environ,
        CARGO_TARGET_DIR=str(ROOT / ".artifacts/rust-migration/target"),
        CARGO_BUILD_JOBS="1",
    )
    start = time.monotonic()
    seen = {}
    peak = 0
    cause = None
    with (
        (OUT / (plan["name"] + "-stdout.log")).open("w") as out,
        (OUT / (plan["name"] + "-stderr.log")).open("w") as err,
    ):
        child = subprocess.Popen(
            argv, cwd=ROOT, env=env, stdout=out, stderr=err, start_new_session=True
        )
        while child.poll() is None:
            now = snapshot()
            owned = {pid for pid, p in now.items() if p["group"] == child.pid}
            seen.update({pid: now[pid] for pid in owned})
            peak = max(peak, sum(now[pid]["rss"] for pid in owned))
            active_foreign = [
                p
                for pid, p in now.items()
                if pid not in ancestors
                and pid not in owned
                and compute(p)
                and (
                    pid not in before
                    or p["tick"] != before[pid]["tick"]
                    or p["cpu"] - before[pid]["cpu"] >= 2
                )
            ]
            if active_foreign:
                cause = "FOREIGN_CPU"
            if peak > 1792 * 1024**2:
                cause = "RSS_GUARD"
            if time.monotonic() - start > plan["hard_seconds"]:
                cause = "WALL_GUARD"
            if (
                json.loads(
                    (
                        ROOT / ".artifacts/research-team/frame22-extension23/scheduler/state.json"
                    ).read_text()
                )["phase"]
                != "running"
            ):
                cause = "RUNTIME_STOP"
            if cause:
                os.killpg(child.pid, signal.SIGTERM)
                break
            before = now
            time.sleep(0.1)
        try:
            code = child.wait(timeout=1)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait()
    remaining = [p for pid, old in seen.items() if (p := proc(pid)) and p["tick"] == old["tick"]]
    receipt = {
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "exit": code,
        "cause": cause,
        "seconds": time.monotonic() - start,
        "peakRSS": peak,
        "argv": argv,
        "waited": True,
        "recorded": list(seen.values()),
        "current_exact_remaining": remaining,
        "NN": plan["NN_charge"],
        "task": plan["task"],
        "whole_suite": "NOT_RUN",
        "original_science_sources": "preserved separately",
    }
    (OUT / (plan["name"] + "-result.json")).write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))
    return 0 if code == 0 and not remaining else 1


if __name__ == "__main__":
    sys.exit(main())
