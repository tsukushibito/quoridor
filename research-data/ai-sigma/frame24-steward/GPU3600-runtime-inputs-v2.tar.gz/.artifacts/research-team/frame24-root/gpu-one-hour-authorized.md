# GPU学習 最大1時間の新明示割当 — 実行依頼

ユーザー明示「見積もりも必要無く、一旦1時間と大きくみてから結果を見てから最適な時間を考えよう。」を2026-10-06T00:32:01Zに受領。本指示はGPU学習に新たに3600秒を前向き許可する。Root旧5分案は撤回のまま、見積もりの完成や過去7200秒の残量復元を新GPU実測の開始gateにしない。旧7200のUNKNOWN/失敗/費/原receiptは変更せず、新3600を別namespace/ledgerとして所有・実attempt・elapsed・残を記録する。今回枠内だけ有効、時間を使い切る義務や結果後の自動追加/旧残の回復ではない。

親frame24開始00:08:46/終了02:08:46UTC、新heavy01:58:46、Sup02:03:46/monitor02:06:46は不変更。GPU学習の累積3600秒と親終了の早い方まで、GPUjobのinit/転送/学習/validation/同期/記録/回収・失敗/timeoutを含めて課金する。準備後に親時計を取り直さない。CPU4logical/RAM8GiB/VRAM6GiB/保存12GiBを増額せず、GPU推論非競合・fresh物理/保存と所有を維持。既神経forward/source/MAXの新科学は統括が確認unusedから前向き配分し、旧failed/UNKNOWN/capsをresetせず、細かな見積もり/精密な時間配分の完成は不要。

統括は310又は既所有に整合した個別Beads契約へ今回GPU3600秒を反映し、必要な実行bodyを本人へ実配送する。最初は同データ/初期/model/FP32/optimizer/旧sampler/同batch128のCPU対CUDA、全step/seen/epoch相当・曲線・飽和/符号・row/group指標・init/update/validation/transfer/同期/保存込み総費/RSS/VRAMを記録する。既512stepの基盤案は使えるが、本体の密な早期曲線診断との比較に必要な同露出範囲を予算内で具体化する。CPU保存済み同重み/同入力/同source観測は再用し、追加NNを同じ用途で二重消費しない。新GPU枠があるからarchitecture/teacher/データ規模/大batch/LR変更を自動追加しない。観測点・検証可能な出力を確保し、同batch実結果から今後の時間・batch設計を判断する。小比較成立を学習/最高棋力成功にしない。

308記録・中断契約のcanonicalsolewriter停止/機能資格と310同条件source固定を維持。TT311は別scope/CPU窓で継続可能。今回GPUbudget更新のための92sole親/runtime期待hash変更は自然安全窓で行い、他owner研究jobをinterruptせず二重role起動せず、Root/coorがsourceを重複編集しない。Rootは今回budgetの指示/手元証拠だけwriter、index/研究源/registry0。

GPU残復元は必要な旧account引渡しとして保持できるが、今回許可3600の実行を完了待ちにしない。事前見積もり/追加承認/全役ACKを求めず許可内の実測を進め、最初actualstart・結果/消費・残・次判断を短くRootへ報告する。現重要手法変更は分析結果と競合理由を提示してユーザーへ相談する境界を維持する。
