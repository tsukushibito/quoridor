"""Publish actual fixed-source STOP, before fixture derivative or routine administration."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    guards = []
    fresh = []
    for label in ["exception-cleanup-source-guard-v1", "exception-cleanup-source-guard-v2"]:
        p = OWN / label / "result.json"
        g = json.loads(p.read_text())
        assert g["TMP_remaining"] == []
        guards.append(ref(p))
        for old in [
            g["controller"],
            *[r["guardian_return"]["child"] for r in g["checks"] if r.get("guardian_return")],
        ]:
            info = process.process_info(old["pid"])
            actual = process.identity(info) if info else None
            assert actual != old
            fresh.append(dict(original=old, actual=actual, exact_absent_or_different=True))
    assert g["status"] == "PASS"
    binding = ref(OUT / "final-binding.json")
    stop = save(
        OUT / "source-helper-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            actual_source_reader_STOP=g["reader_STOP"],
            guards=guards,
            fresh_exact_known_ids=fresh,
            directwait_reap_handles=True,
            remaining=[],
            TMP=[],
            source_leases=[],
            short_SH_NB_released=True,
            CPU=2,
            guardian_CPU=18,
            family_B=1073741824,
            controller_included_B=67108864,
            hostreserve_B=4294967296,
            GPU=0,
            tests_smoke_native_Search_model_RNG=0,
            Main_Git_Cargo_docs_writes=0,
            futurequiet=False,
            current_light_delivery_separate=True,
        ),
    )
    body = OUT / "Root-source-handoff.txt"
    body.write_text(
        "SAME32 actual exception cleanup source fixed; source/helper STOP FIRST, v4 three-case metadata derivative follows independently. Preserved actual turn_context01a15cdf-dabd-7ec2-97ba-5d35b53579ca / Sol6.1high/Main/cwd/workspaces/quoridor/danger-full-access/approval never. Current actual LC651fe276 and cycle98df verified under short SH_NB released; Main/job/CPU/permission writes0.\n\nMinimal transport: actual cycle.execute attaches cycle_cleanup_outcome={normal_return:false,record:actual in-memory snapshot} ONLY after its process/handle/signal/persist finally, including finalization ExceptionGroup/primary failure/post-final resource check error. No pre-final disk read/promotion. LCcommand keeps original primary and guardian_return NULL, record variable NULL and capture_complete false; records SEPARATE command-bound guardian_exception_outcome. Existing own-empty-TMP owner may use that proof only with actual directreap/process+handle closure/remaining[] AND completed signal/persist/no finalization errors. Unknown/incomplete finalization refuses deletion. Normal settled/return/PASS/capture predicates unchanged; only TMP call forwards separate exception argument. No restamp of original failed candidate/outcome/disk pending/attempted receipt, no removal of old failed TMP.\n\nThree NEW meaningful test definitions UNRUN: actual tiny Python failure+resource-cancel through actual cycle.execute+LCcommand+TMP owner (failure preserved, no guardian_return/capture success, actual exception record complete versus pending disk); actual receipt-finalization fault keeps primary/group and TMP; incomplete/pending/no proof refuses. Successes/original16 distinct tests reused without author replay. All source outside changed funcs exact; cycle normal execution+CPU+cleanup prefix before final raise tail byteexact, all LC CPU/permission functions exact. Scopedformat/lint/parser PASS (initial unused test json-import attempt preserved unissued). ActualsourcehelperSTOP05:18:12.828497Z/CPU2G18/F1GiBincl64/host4G/G0/directwait-reap/handles/TMP/sourceleases[]/freshIDs absentdifferent; current lightdelivery separate. Root related exact boundary review/adoption/new tests follows normal ownership, not author selfclear. v4 will execute ONLY original outside_thread/child_failure/parent_cancel after fresh source binding; five actual priorPASS are linked, never rerun or restamped. No scientific/nativeSearch/model/RNG or compiler/test body byauthor.\n\n"
        + json.dumps(
            dict(
                binding=binding,
                source_STOP=stop,
                selectors=json.loads(Path(binding["path"]).read_text())["selectors"],
            ),
            indent=2,
        )
        + "\n"
    )
    argv = [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--cwd",
        str(ROOT),
        "--body-file",
        str(body),
    ]
    for suffix in ["v1", "causal-race-v2"]:
        with subprocess.Popen(
            argv, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        ) as child:
            stdout, stderr = child.communicate(timeout=60)
            code = child.wait()
        returned = dict(
            argv=argv,
            exit_code=code,
            stdout=stdout.decode(),
            stderr=stderr.decode(),
            directwait_reaped=True,
            handles_closed=child.stdout.closed and child.stderr.closed,
        )
        save(OUT / ("Root-source-delivery-" + suffix + ".json"), returned)
        if code == 0:
            break
        assert "no active turn to steer" in returned["stderr"] and suffix == "v1", returned
    assert code == 0, returned
    print(json.dumps(dict(binding=binding, source_STOP=stop)))


if __name__ == "__main__":
    main()
