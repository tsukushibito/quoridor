"""Freeze executable fixture source and the exact unique pre-main text delta only."""

import ast
import difflib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
OWN = HERE.parent
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402


def main():
    files = [
        "science_fixture.py",
        "materialize.py",
        "mask_payload.py",
        "assess.py",
        "coordinator.py",
    ]
    for name in files:
        ast.parse((HERE / name).read_text())
    source = ref(OWN / "fixed-v3/source-binding.json")
    assert source["sha256"] == "62d5fabf1030ebe55ccda9d8c46683f470d2edf9c4213ad416ae9a9f4bb33d81"
    package = save(
        HERE / "package-binding.json",
        dict(
            schema="quoridor.cpu-plan-smoke.fixture-package.v1",
            source_binding=source,
            files={name: ref(HERE / name) for name in files},
            author_executed_tests_smoke=0,
        ),
    )
    loader = importlib.util.spec_from_file_location(
        "own_text_emitter_only", HERE / "science_fixture.py"
    )
    emitter = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(emitter)  # Pure own stdlib text emitter; no LC/job/control imports.
    before = b'if __name__ == "__main__":\n    sys.exit(main())\n'
    after = emitter.entry_bytes(before, package)
    assert emitter.definitions(before) == emitter.definitions(after) == {}
    for name, raw in [("entry-before.py", before), ("entry-after.py", after)]:
        with (HERE / name).open("xb") as stream:
            stream.write(raw)
    for name, left, right in [
        ("entry-forward.footer.patch", before, after),
        ("entry-inverse.footer.patch", after, before),
    ]:
        with (HERE / name).open("x") as stream:
            stream.writelines(
                difflib.unified_diff(
                    left.decode().splitlines(True),
                    right.decode().splitlines(True),
                    fromfile="a/scripts/dev/research-lifecycle.py",
                    tofile="b/scripts/dev/research-lifecycle.py",
                )
            )
    finding = save(
        HERE / "inherited-progress-finding.json",
        dict(
            status="STATIC_CONCRETE_INHERITED_SCIENTIFIC_CENSUS_ASSUMPTION_NOT_REPAIRED",
            source=next(
                x["post"]
                for x in json.loads(Path(source["path"]).read_text())["subjects"]
                if x["subject"] == "scripts/dev/research-lifecycle.py"
            ),
            owner="arena_cohort_progress",
            evidence=[
                "planned_games=3072",
                "terminal/inflight/unentered +=32 per operation",
                "requires terminal+inflight+unentered==3072",
            ],
            fixture_shape="two lanes x two operations, no scientific games or native report",
            observed_runtime_failure=False,
            expected_static_consequence="progress() records a Refused census mismatch; observer not replaced; assessment retains error and forbids full-normal-PASS",
            production_fix=None,
            fixed_CPU_target_unchanged=True,
        ),
    )
    binding = save(
        HERE / "fixture-binding.json",
        dict(
            issue="quoridor-4lc.324.32",
            status="CONCRETE_EXECUTABLE_ROOT_ONLY_FIXTURE_UNRUN",
            package=package,
            unique_entry_before=ref(HERE / "entry-before.py"),
            unique_entry_after=ref(HERE / "entry-after.py"),
            forward_footer=ref(HERE / "entry-forward.footer.patch"),
            inverse_footer=ref(HERE / "entry-inverse.footer.patch"),
            hunk_semantics="exact unique EOF anchor replacement; Root runtime generates canonical full-line-number forward/inverse under EX_NB from actual current before, not an old wholepost overwrite",
            Root_current_lifecycle="actual future FileRef required; Root reports current7d40d9dbb5bd1504e74b031abb2b5470b48062baa024b31a818629e840e3e132 after ETC removal; do not bind9d837 as current",
            readme=ref(HERE / "README-ja.md"),
            future_allocation_template=ref(HERE / "allocation-template.json"),
            inherited_progress_finding=finding,
            cases=[
                "two_lane",
                "single_lane",
                "bad_unavailable",
                "bad_smt",
                "bad_overlap",
                "outside_thread",
                "child_failure",
                "parent_cancel",
            ],
            science_substitutions=[
                "experiment_check",
                "collect_data",
                "existing sequence prepare keyword only",
            ],
            observation="bounded read-only profile, no control function wrapper/return mutation",
            protected_controls="all actual current LC function/class bytes unchanged by temporary footer; all16 CPU functions additionally join62d5; job13a2/cycle98df unchanged",
            restoration="actual current before snapshot under EX_NB, finally on exceptions/cancel; explicit restore-only after settled hard-failure cleanup, foreign drift refuses overwrite",
            no_prod_testmode_or_env_exemption=True,
            no_forged_Build_model_or_arenaPlan=True,
            tests_realprocess_native_Search_model_RNG_run=0,
            Main_Git_Cargo_docs_writes=0,
            claims="UNRUN, no real-parallel/source-clear/runtime qualification",
        ),
    )
    print(json.dumps(binding))


if __name__ == "__main__":
    main()
