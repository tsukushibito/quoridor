def test_job_supervisor_resource_callback_covers_pre_spawn_and_wait(self):
    from contextlib import ExitStack
    import signal
    import subprocess

    source = Path(__file__).resolve().parents[2] / "scripts/dev/research-job.py"
    tree = ast.parse(source.read_text())
    execute = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "execute")
    parent_command = next(
        n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "cohort_parent_command"
    )
    for refusal_at in (1, 3):
        directory = self.root / f"job-case-{refusal_at}"
        directory.mkdir()
        state = dict(phase="queued", job_id="unit-new-job", thread_id="unit-thread")
        events = []
        process = SimpleNamespace(returncode=None)
        process.poll = lambda: process.returncode
        process.wait = lambda timeout: setattr(process, "returncode", -15)
        process.stdout = SimpleNamespace(close=lambda: events.append("pipe-close"))
        process.pid = 770077  # Inert metadata; no actual PID or fd is opened/signalled.

        class Resource:
            count = 0

            def check(self):
                self.count += 1
                events.append("resource-check")
                if self.count == refusal_at:
                    raise RuntimeError("actual common RSS envelope refusal")

        guard = Resource()

        @contextmanager
        def configured(directory, config, root, resource):
            yield resource

        def publish(directory, name, value):
            if name == "state.json":
                state.update(value)
            self.save(directory / name, value)

        def popen(*args, **kwargs):
            events.append("Popen")
            return process

        def stop(fd, sig):
            events.append("exact-pidfd-stop")
            process.returncode = -15

        tail = SimpleNamespace(
            thread=SimpleNamespace(
                start=lambda: None, join=lambda timeout: None, is_alive=lambda: False
            ),
            bytes_seen=0,
            data=b"",
        )
        namespace = dict(
            read=lambda directory, name: state,
            write=publish,
            stamp=lambda: "unit-time",
            authority=lambda *args, **kwargs: dict(thread_id="unit-thread"),
            deadline_reached=lambda value: False,
            runtime=SimpleNamespace(
                process_identity=lambda pid: dict(pid=pid, start_ticks="fixed", boot_id="unit"),
                alive=lambda member: process.returncode is None,
            ),
            os=SimpleNamespace(
                environ={},
                getpid=lambda: 880088,
                pidfd_open=lambda pid: 55,
                close=lambda fd: events.append("pidfd-close"),
            ),
            subprocess=SimpleNamespace(
                Popen=popen,
                DEVNULL=subprocess.DEVNULL,
                PIPE=subprocess.PIPE,
                STDOUT=subprocess.STDOUT,
                TimeoutExpired=subprocess.TimeoutExpired,
            ),
            signal=SimpleNamespace(
                SIGTERM=signal.SIGTERM, SIGKILL=signal.SIGKILL, pidfd_send_signal=stop
            ),
            TailLog=lambda *args: tail,
            track_descendants=lambda child, known: [child],
            descendants_in_group=lambda pid, child: [],
            signal_members=lambda *args: None,
            time=SimpleNamespace(monotonic=lambda: 0.0, sleep=lambda seconds: None),
            ExitStack=ExitStack,
            configured_arena_resources=configured,
            configured_cpu_control=lambda *args: (None, False),
            sys=sys,
            json=json,
            JobError=ValueError,
        )
        exec(
            compile(
                ast.Module(body=[parent_command, execute], type_ignores=[]), str(source), "exec"
            ),
            namespace,
        )
        config = dict(
            argv=["UNIT-NOT-EXECUTED"],
            cwd=str(self.root),
            end_at=None,
            max_runtime_seconds=None,
            log_max_bytes=1024,
            thread_id="unit-thread",
            control_interval_seconds=30,
        )
        result = namespace["execute"](directory, config, self.root, None, resources=guard)
        self.assertEqual(guard.count, refusal_at)
        self.assertTrue(result["cleanup_complete"])
        if refusal_at == 1:
            self.assertEqual(result["outcome"], "not_started")
            self.assertNotIn("Popen", events)
        else:
            self.assertEqual(result["outcome"], "control_error")
            self.assertTrue(result["direct_child_reaped"])
            self.assertIn("exact-pidfd-stop", events)
            self.assertIn("pipe-close", events)
            self.assertIn("pidfd-close", events)
