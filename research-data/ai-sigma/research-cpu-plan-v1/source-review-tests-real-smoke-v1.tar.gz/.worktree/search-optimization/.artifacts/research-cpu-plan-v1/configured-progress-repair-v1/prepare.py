"""Private configured progress count custody; no target imports or test execution."""

import ast
import difflib
import fcntl
import os
from pathlib import Path
import sys
import textwrap

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

LC = "scripts/dev/research-lifecycle.py"
TEST = "tools/research-session/test_lifecycle_arena_cohort_repair.py"
NAME = "arena_cohort_progress"


def parts(text, name):
    node = next(
        n for n in ast.walk(ast.parse(text)) if isinstance(n, ast.FunctionDef) and n.name == name
    )
    lines = text.splitlines(True)
    return (
        "".join(lines[: node.lineno - 1]),
        "".join(lines[node.lineno - 1 : node.end_lineno]),
        "".join(lines[node.end_lineno :]),
    )


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as f:
        f.write(text)


def intake():
    assert os.sched_getaffinity(0) == {2}
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        current = ref(ROOT / LC)
        assert (
            current["sha256"] == "7d40d9dbb5bd1504e74b031abb2b5470b48062baa024b31a818629e840e3e132"
        )
        assert current["bytes"] == 388500 and current["mode"] == "0644"
        write(OUT / "before" / LC, (ROOT / LC).read_text())
        fcntl.flock(lock, fcntl.LOCK_UN)
    source = OWN / "test-fixture-repair-v2/post" / TEST
    assert ref(source)["sha256"].startswith("e8f6d19e")
    write(OUT / "before" / TEST, source.read_text())
    save(
        OUT / "intake.json",
        dict(
            current=current,
            private_before=ref(OUT / "before" / LC),
            test_before=ref(OUT / "before" / TEST),
            short_SH_NB_released=True,
            target_imports=0,
            tests_smoke=0,
        ),
    )


def edit():
    before = (OUT / "before" / LC).read_text()
    _, body, _ = parts(before, NAME)
    assert body.count("lanes = []") == 1
    body = body.replace("    lanes = []\n", "    lanes = []\n    planned_games = 0\n", 1)
    old = "        settings = document(settings_ref)\n"
    addition = """        configs = [document(document(run["experiment"])["config"]) for run in settings["runs"]]
        require(
            all(type(config.get("games")) is int and config["games"] > 0 for config in configs),
            "configured positive-int games per operation",
        )
        planned_games += sum(config["games"] for config in configs)
"""
    assert body.count(old) == 1
    body = body.replace(old, old + addition, 1)
    body = body.replace(
        "                settings=settings,\n",
        "                settings=settings,\n                configs=configs,\n",
        1,
    )
    body = body.replace("planned_games=3072,", "planned_games=planned_games,")
    body = body.replace(
        'for index, template in enumerate(settings["runs"]):',
        'for index, config in enumerate(lane["configs"]):\n                games = config["games"]',
    )
    body = body.replace(
        '                config = document(document(template["experiment"])["config"])\n', ""
    )
    body = (
        body.replace(" += 32", " += games")
        .replace("== 32", "== games")
        .replace("<= 32", "<= games")
    )
    body = body.replace("3072", "planned_games")
    body = body.replace(
        '            member, settings = lane["member"], lane["settings"]\n',
        '            member = lane["member"]\n',
    )
    assert "3072" not in body and "32" not in body
    write(OUT / "progress.scoped.py", body)
    test_before = (OUT / "before" / TEST).read_text()
    old_name = "test_R3_pre_inner_refusal_settles_pairs_retained_unknown_and_unentered"
    _, old_body, _ = parts(test_before, old_name)
    old = 'config.update(run_id=f"unit-lane-{lane}", output=str(self.root / f"lane-{lane}/data"))'
    assert old_body.count(old) == 1
    old_body = old_body.replace(
        old,
        'config.update(games=32, run_id=f"unit-lane-{lane}", output=str(self.root / f"lane-{lane}/data"))',
    )
    write(OUT / "legacy_fixture.scoped.py", textwrap.dedent(old_body))


def bind():
    rows = []
    before = (OUT / "before" / LC).read_text()
    head, body, tail = parts(before, NAME)
    post_body = (OUT / "progress.scoped.py").read_text().rstrip("\n") + "\n"
    post = head + post_body + tail
    assert parts(post, NAME)[::2] == (head, tail)
    write(OUT / "post" / LC, post)
    test_before = (OUT / "before" / TEST).read_text()
    old_name = "test_R3_pre_inner_refusal_settles_pairs_retained_unknown_and_unentered"
    h, b, t = parts(test_before, old_name)
    replacement = (
        textwrap.indent((OUT / "legacy_fixture.scoped.py").read_text().rstrip("\n"), "    ") + "\n"
    )
    revised = h + replacement + t
    h, b, t = parts(revised, "rebind_settings")
    new_test = textwrap.indent((OUT / "regression.scoped.py").read_text().rstrip("\n"), "    ")
    test_post = h + new_test + "\n\n" + b + t
    write(OUT / "post" / TEST, test_post)
    for subject in (LC, TEST):
        a = (OUT / "before" / subject).read_text()
        b = (OUT / "post" / subject).read_text()
        ast.parse(b)
        for direction, left, right in [("forward", a, b), ("inverse", b, a)]:
            path = OUT / (direction + ".patch")
            with path.open("a") as f:
                f.writelines(
                    difflib.unified_diff(
                        left.splitlines(True),
                        right.splitlines(True),
                        fromfile="a/" + subject,
                        tofile="b/" + subject,
                    )
                )
        rows.append(
            dict(
                subject=subject,
                before=ref(OUT / "before" / subject),
                post=ref(OUT / "post" / subject),
            )
        )
    # The existing fixture changes ONLY its missing bound games field (format local to definition).
    a = ast.parse(textwrap.dedent(parts(test_before, old_name)[1]))
    b = ast.parse((OUT / "legacy_fixture.scoped.py").read_text())
    target = next(
        n
        for n in ast.walk(b)
        if isinstance(n, ast.Call)
        and isinstance(n.func, ast.Attribute)
        and n.func.attr == "update"
        and any(k.arg == "games" for k in n.keywords)
    )
    target.keywords = [k for k in target.keywords if k.arg != "games"]
    assert ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False)
    # All other existing functions remain byteexact.
    for n in ast.walk(ast.parse(test_before)):
        if isinstance(n, ast.FunctionDef) and n.name != old_name:
            assert parts(test_before, n.name)[1] == parts(test_post, n.name)[1], n.name
    save(
        OUT / "binding.json",
        dict(
            issue="quoridor-4lc.324.32",
            status="PRIVATE_PRODUCTION_COUNT_MAINTENANCE_UNRUN",
            subjects=rows,
            forward=ref(OUT / "forward.patch"),
            inverse=ref(OUT / "inverse.patch"),
            changed_production_function=NAME,
            outside_production_function_bytes_exact=True,
            old_CPU_target62d5="immutable; all other LC functions byteexact to current7d40",
            test_definition="CohortRepairBoundary.test_configured_progress_counts_and_missing_native_census",
            legacy_fixture_change="only explicit games=32; assertions and old AST otherwise unchanged",
            tests_run=0,
            smoke_run=0,
            target_imports=0,
            Main_writes=0,
            selectors=[
                "test_lifecycle_arena_cohort_repair.CohortRepairBoundary.test_configured_progress_counts_and_missing_native_census"
            ],
        ),
    )


if __name__ == "__main__":
    globals()[sys.argv[1]]()
