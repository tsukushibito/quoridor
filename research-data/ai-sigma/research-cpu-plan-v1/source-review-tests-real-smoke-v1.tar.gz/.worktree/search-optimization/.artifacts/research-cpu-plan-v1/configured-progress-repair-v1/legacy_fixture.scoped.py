def test_R3_pre_inner_refusal_settles_pairs_retained_unknown_and_unentered(self):
    self.current = 200
    member = self.cohort["members"][0]
    self.save(
        Path(member["output"]) / "result.json",
        dict(
            settings=self.settings_refs[0],
            originating_job=self.origins[0],
            status="FAILED",
            completed_operations=0,
            operations=[],
        ),
    )
    for lane in range(3):
        member = self.cohort["members"][lane]
        config_ref = lc.document(self.specs[lane]["experiment"])["config"]
        config = lc.document(config_ref)
        config.update(
            games=32, run_id=f"unit-lane-{lane}", output=str(self.root / f"lane-{lane}/data")
        )
        config["arena"]["book"] = dict(
            openings=[
                dict(
                    id=f"request-{2 * i + 7}",
                    lineage=f"lineage-{2 * i + 7}",
                    reference=dict(
                        settings=dict(family_id=2 * i + 7, canonical_family=f"canonical-{i}")
                    ),
                )
                for i in range(16)
            ]
        )
        self.save(Path(config_ref["path"]), config)
        experiment_path = Path(self.specs[lane]["experiment"]["path"])
        experiment = lc.document(self.specs[lane]["experiment"])
        experiment["config"] = lc.bound(config_ref["path"])[0]
        self.save(experiment_path, experiment)
        # Rebind this changed unit fixture before any mocked observation.
        for template in self.settings[lane]["runs"]:
            template["experiment"] = lc.bound(experiment_path)[0]
        self.specs[lane]["experiment"] = lc.bound(experiment_path)[0]
    self.rebind_settings()
    for lane in (1, 2):
        member = self.cohort["members"][lane]
        config = lc.document(lc.document(self.specs[lane]["experiment"])["config"])
        publication = self.save(
            Path(config["output"]) / "result.json",
            dict(
                outcome_count=32,
                report=dict(
                    run_id=config["run_id"],
                    planned=32,
                    arena_summary=dict(
                        census=dict(
                            planned_games=32,
                            started_games=32,
                            completed_games=31,
                            unknown_games=1,
                            complete_pairs=15,
                        ),
                        pairs=[
                            dict(family=f"native-{i}", lineage=f"lineage-{2 * i + 7}")
                            for i in range(15)
                        ],
                    ),
                ),
            ),
        )
        self.save(
            Path(member["output"]) / "run-000/operation/manifest.json",
            dict(
                status="PASS",
                cleanup_complete=True,
                data=dict(files=[publication]),
            ),
        )
    with (
        self.kernel(),
        patch.object(lc.process, "execute", side_effect=RuntimeError("one send failure")) as send,
    ):
        lc.arena_cohort_progress(self.specs[0])
        packet = json.loads((self.shared / "first-progress.json").read_text())
        counts = packet["counts"]
        self.assertEqual(counts["completed_games_known"], 62)
        self.assertEqual(counts["retained_games_known"], 64)
        self.assertEqual(counts["unknown_games_known"], 2)
        self.assertEqual(counts["complete_pairs_known"], 30)
        self.assertEqual(counts["unentered_slots"], 3008)
        self.assertEqual(counts["terminal_planned_games"], 64)
        self.assertEqual(counts["inflight_slots"], 0)
        self.assertIsNone(packet["conditional_remaining_seconds"])
        self.assertEqual(packet["launch_to_pre_publication_snapshot_seconds"], 10.0)
        self.assertNotIn("inclusive_elapsed_seconds", packet)
        self.assertEqual(len(lc.document(packet["complete_pair_identities"])), 30)
        lc.arena_cohort_progress(self.specs[1])
        self.assertEqual(send.call_count, 1)
