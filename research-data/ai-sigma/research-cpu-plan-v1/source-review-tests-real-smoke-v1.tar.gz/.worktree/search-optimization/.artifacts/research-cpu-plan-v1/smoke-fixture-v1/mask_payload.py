"""Finite mask-only test payload. No scientific engine, model, Search or RNG."""

import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

SCHEMA = "quoridor.cpu-plan-smoke.synthetic.v1"


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def main():
    if sys.argv[1:] == ["leaf"]:
        time.sleep(30)
        return 0
    assert sys.argv[1] == "mask"
    config = json.loads(Path(sys.argv[2]).read_text())
    marker = config["synthetic_cpu_smoke"]
    assert marker["schema"] == SCHEMA
    python = marker["python"]
    output = Path(config["output"])
    output.mkdir()
    launch = sorted(os.sched_getaffinity(0))
    assert launch == sorted(set(config["cpu_cores"] + [config["management_cpu_core"]]))
    os.sched_setaffinity(0, {config["cpu_cores"][0]})
    identity = process.identity(process.process_info(os.getpid()))
    fact = dict(
        synthetic=SCHEMA,
        operation=marker["operation"],
        local_index=marker["local_index"],
        lane=marker["lane"],
        identity=identity,
        parent=os.getppid(),
        launch_mask=launch,
        worker_mask=sorted(os.sched_getaffinity(0)),
        started_monotonic=time.monotonic(),
        behavior=marker["behavior"],
    )
    write(output / "mask.json", fact)
    signal_path = Path(marker["signals"]) / f"lane-{marker['lane']}-op-{marker['local_index']}.json"
    write(signal_path, fact)
    print(json.dumps(fact), flush=True)
    behavior = marker["behavior"]
    if behavior == "outside_thread" and marker["local_index"] == 0:
        ready = threading.Event()

        def outside():
            os.sched_setaffinity(0, {marker["outside_cpu"]})
            write(
                output / "outside-thread.json",
                dict(tid=threading.get_native_id(), mask=sorted(os.sched_getaffinity(0))),
            )
            ready.set()
            time.sleep(8)

        thread = threading.Thread(target=outside)
        thread.start()
        assert ready.wait(2)
        thread.join()
        return 0  # Test must reject this outcome: actual scope monitor should terminate us.
    if behavior == "child_failure" and marker["local_index"] == 0:
        leaf = subprocess.Popen([python, "-B", str(Path(__file__)), "leaf"])
        write(
            output / "failure-descendant.json",
            dict(identity=process.identity(process.process_info(leaf.pid))),
        )
        time.sleep(1)
        return 7  # The normal guardian owns and reaps this session's remaining leaf.
    if behavior == "parent_cancel" and marker["local_index"] == 0:
        if marker["lane"] == 0:
            argv = [
                python,
                "-B",
                str(ROOT / "scripts/dev/research-job.py"),
                "cancel",
                "--state-dir",
                marker["parent_runtime"],
            ]
            with subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE) as child:
                out, err = child.communicate(timeout=5)
                code = child.wait()
            write(
                output / "actual-parent-cancel.json",
                dict(
                    argv=argv,
                    exit_code=code,
                    stdout=out.decode(),
                    stderr=err.decode(),
                    directwait=True,
                    handles_closed=child.stdout.closed and child.stderr.closed,
                ),
            )
            assert code == 0
        time.sleep(20)  # Actual parent/delegated cancellation must stop this body.
        return 0
    if marker["local_index"] == 0 and marker["lane_count"] == 2:
        until = time.monotonic() + 10
        while not all(
            (Path(marker["signals"]) / f"lane-{lane}-op-0.json").exists() for lane in range(2)
        ):
            assert time.monotonic() < until, "second real lane did not enter"
            time.sleep(0.02)
    state_path = Path(marker["parent_runtime"]) / "state.json"
    initial = json.loads(state_path.read_text()).get("authority_valid_until_monotonic")
    final = initial
    if marker["lane_count"] == 2:
        assert isinstance(initial, (int, float))
        until = time.monotonic() + 8
        while final == initial:
            assert time.monotonic() < until, (
                "no real parent CPU/authority renewal during named dummy"
            )
            time.sleep(0.05)
            final = json.loads(state_path.read_text()).get("authority_valid_until_monotonic")
        assert final > initial
    else:
        time.sleep(3)
    write(
        output / "finished.json",
        dict(
            identity=identity,
            finished_monotonic=time.monotonic(),
            parent_authority_before=initial,
            parent_authority_after=final,
        ),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
