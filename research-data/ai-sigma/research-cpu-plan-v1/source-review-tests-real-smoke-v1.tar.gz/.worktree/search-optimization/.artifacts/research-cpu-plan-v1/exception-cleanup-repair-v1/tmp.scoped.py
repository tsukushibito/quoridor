def remove_empty_owned_tmp(path, owner, guardian_return, *, exception_outcome=None):
    """Remove only empty owned directories after the actual child and handles closed."""
    path = owned(path, owner)
    if guardian_return is None:
        require(
            isinstance(exception_outcome, dict) and exception_outcome.get("normal_return") is False,
            "owned TMP cleanup requires actual exception cleanup transport",
        )
        guardian_return = exception_outcome.get("record")
        require(
            isinstance(guardian_return, dict)
            and guardian_return.get("signal_mask_restoration") == "completed"
            and guardian_return.get("final_record_persist") == "completed"
            and guardian_return.get("finalization_errors", []) == [],
            "exception guardian finalization incomplete",
        )
    require(
        isinstance(guardian_return, dict)
        and guardian_return.get("direct_child_reaped") is True
        and guardian_return.get("process_cleanup_complete") is True
        and guardian_return.get("handle_closes_complete") is True
        and guardian_return.get("remaining") == [],
        "owned TMP cleanup requires returned child/handle closure",
    )
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW

    def drain(directory):
        for name in os.listdir(directory):
            child = os.open(name, flags, dir_fd=directory)
            try:
                drain(child)
            finally:
                os.close(child)
            os.rmdir(name, dir_fd=directory)

    parent = os.open(path.parent, flags)
    try:
        directory = os.open(path.name, flags, dir_fd=parent)
        try:
            drain(directory)
        finally:
            os.close(directory)
        os.rmdir(path.name, dir_fd=parent)
    finally:
        os.close(parent)
