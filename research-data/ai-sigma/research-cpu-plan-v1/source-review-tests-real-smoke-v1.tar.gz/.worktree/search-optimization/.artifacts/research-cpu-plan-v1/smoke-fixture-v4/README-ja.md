これはRootが採用済み共通sourceへ一時的なTEST-ONLY pre-main挿入を行って実行する非科学fixtureである。作者はformat/lint/parserとpacket生成だけを実行し、job、dummy payload、test body、Search、model、arena、RNGを実行していない。恒久testmodeや環境変数による免除は追加しない。

Rootは現在のLCの実FileRef、実Beads caller、fresh CPU/RAM、既知の終了済みsource-user identitiesをallocation JSONへ束縛する。allocation-template.jsonは未束縛で実行不可。候補0/18 management・8/10 lanesは過去の提案であり、このfixtureは固定割当て・予約・未来host quietを主張しない。familyはcommon+2laneで4GiB以内、host reserveは4GiB以上、GPU0。実Planのphysical/SMT/availability、元のnormal authority/resource/cancel checksを通す。

Rootによる実行例（実allocation/outputはRootの新しい名前を使う）:

```bash
taskset -c ROOT_ISSUED_POOL bash scripts/dev/project-env.sh python -B \
  .worktree/search-optimization/.artifacts/research-cpu-plan-v1/smoke-fixture-v4/coordinator.py \
  --allocation ROOT_ISSUED_ALLOCATION.json \
  --output /workspaces/quoridor/.worktree/search-optimization/.artifacts/research-cpu-plan-v1/smoke-fixture-v4/runs/ROOT_NEW_NAMESPACE
```

実行は8caseを固定順で一度ずつ扱う。2lane×2operation、現役single-lane sequence×2operation、unavailable CPU、SMT、role overlap、childの割当外thread、child failure、parent cancelである。coordinatorは既存job.submitを使うだけで、lane scheduling、process group、ancestor判定、cancel/drain/wait、cohort/sequence、command、finalizeは置換しない。通常jobの有限max_runtime_secondsを使い、通知期限だけを普通の期限機構で終了させる。Beads authorityは実AppBackendでありsyntheticではない。

dummyはshell/Pythonでありqualified scientific runnerではない。明示したquoridor-runner-cpu-smoke argv0を使い、維持されているnamed-compute peer判定にも実際に入る。2laneの両payload開始と区間重なりを確認し、各operation中に実parent authority windowが更新されるまで有限待機する。この更新は変更していないresearch-job.executeのcpu_control→authority→publish経路を通る。snapshot直後のspawnという特定raceを決定的に発生させる主張ではない。

唯一のscience置換はexperiment_check、collect_data、sequenceの既存prepare keywordである。synthetic schemaを明記し、実maskファイルとそのidentityだけを作る。approved_planはNoneであり架空のarenaPlan/qualified Build/modelは作らない。CPU構成を読む既存_native_cpu_cores/arena_cohort/selected_run/Limits等はそのまま実行する。finalize/_prepare_completion/settledや実job state/config/argv/PID-start-boot/capture/directwaitの照合は置換しない。

test-onlyのread-only profile callbackが、実LC関数へのcall/return時のmaskをboundedに記録する。関数本体やreturn値を変更するwrapperではない。fresh canonical child、prepare/next、collect、実finalize/_prepare_completion、terminal maskを回収する。直接子のwait/handle closureは通常receiptを使い、子孫の残存判定は既存alive()/remainingの意味に従う。grandchildのdirectwaitを偽って主張しない。

挿入はentry-before.pyの一意なEOF anchorからentry-after.pyへの変換だけ。固定9d837全体postをMainへ戻す処理はない。Rootの現在LC（ETC撤去後7d40…または新たに実発行されたcurrent ref）をEX_NB下で確認し、実before snapshot/patch/inverse/obligationを保存して挿入する。固定62d5の16 CPU関数だけはcurrentとbyteexactに対応させる。その他のcurrent関数も挿入前後で全byteを保持する。job13a2/cycle98dfは元の固定postと一致させる。source users/EX_NB/実peer条件に反すればpayload前に拒否する。

通常例外・SIGINT/SIGTERMはnormal cancel/drainとfinallyによるexact bytes/mode復元を通す。foreign source drift、別reader、未解決cleanupがあれば安全でない上書きをせずRESTORATION-REQUIRED.jsonを残す。hard kill等でfinallyが実行されなかった場合も、Rootは元のnormal jobをcancel/drainして全stateのfinishedと実identity停止を確認してから次だけを実行できる。科学/通常payloadを再実行する入口ではない。

```bash
bash scripts/dev/project-env.sh python -B \
  .worktree/search-optimization/.artifacts/research-cpu-plan-v1/smoke-fixture-v4/coordinator.py \
  --restore-only --output ROOT_ORIGINAL_RUN_NAMESPACE
```

v1の固定3072/32進捗集計findingと元packetは不変で保持する。別のproduction修正packet configured-progress-repair-v1は束縛済みconfig.gamesから予定数を導く。Rootが採用した後の実current LC/hashをallocationへ束縛し、v2には各operationでgames=1というsynthetic予定slotだけを宣言する。これは対局の実行や完了を意味しない。native publicationが無ければcompleted_games_knownは0、全予定slotの科学結果はUNKNOWNのままであり、native censusを捏造しない。実progress_errorsとTMP残存は引き続き全体PASSを阻む。8固定caseとCPU/authority/resources/finalize/restore処理はv1とbyteexact。

standalone finalize CLIにも同じscience-only entryを適用できるようにしたが、本fixtureのcollection実行は通常sequence内の実finalizeである。独立collector job全体の実成功を未実行のまま主張しない。初回から科学タイミング、対局、モデル、生成、学習、CI、RNGは一切含まない。


v3は実parent configを先にexclusive publishし、その正確なFileRefをlaunch.parent_configへ束縛する。monotonicは同じ実pre-submit生成時計であり、既存のcohort/lane config/runtime対応を変更しない。隣接する実進捗通知に必要なcohort.notifyには同じ実allocation issue/threadのみを指定する。v2最初のNOT_STARTEDと全旧packet/namespaceを保持し、作者によるcase実行は0。Rootの新しいcurrent sourceとfresh resource binding後にのみ失敗/未入場caseを実行する。


v4の実行対象は元のcleanup未完了3case（outside_thread/child_failure/parent_cancel）のみ。2lane/single/invalid CPUの既存5PASSは保存済みassessmentへの固定参照であり再実行しない。元の全8coordinator exit1/fullnormalPASSfalseと6空TMPは書き換え・削除しない。今回の出力はrepaired_cleanup_cases_PASSのみを示し、full_normal_parallel_PASSはfalseのまま。全体の受入れはRootが5旧receiptと3実修復出力・現在source対応を評価する。

source-binding-cleanup-composition.jsonは固定62d5+実651権限修正へ今回のexception cleanup postを疎に合わせたソース対応であり、actual adoption/software/SOURCE_CLEARの捏造ではない。Rootが採用したLCとcycleの正確なcurrent ref、fresh実resourceをallocationへ束縛した後だけ実行する。CPU/permission/authority/resource/peer/Popen/cancel/normal finalize/assessment/science置換は同じ実経路であり、例外outcomeを通常guardian return/capture成功へ昇格しない。
