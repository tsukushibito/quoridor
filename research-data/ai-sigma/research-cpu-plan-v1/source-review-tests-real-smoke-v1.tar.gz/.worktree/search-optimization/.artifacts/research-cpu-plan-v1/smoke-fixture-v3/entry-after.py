if __name__ == "__main__":
    _cpu_smoke_source = {
        "path": "/workspaces/quoridor/.worktree/search-optimization/.artifacts/research-cpu-plan-v1/smoke-fixture-v3/science_fixture.py",
        "sha256": "7a0e48bd10ae4bb1f8c5035e57dfe1fee7cb1e6b4688e05b0a99c3662878b752",
        "bytes": 8801,
        "mode": "0644",
    }
    read_ref(_cpu_smoke_source)
    _cpu_smoke_loader = importlib.util.spec_from_file_location(
        "cpu_smoke_science", _cpu_smoke_source["path"]
    )
    _cpu_smoke_module = importlib.util.module_from_spec(_cpu_smoke_loader)
    _cpu_smoke_loader.loader.exec_module(_cpu_smoke_module)
    _cpu_smoke_module.install(
        globals(),
        {
            "path": "/workspaces/quoridor/.worktree/search-optimization/.artifacts/research-cpu-plan-v1/smoke-fixture-v3/package-binding.json",
            "sha256": "2bebcd42b6c7819e48d6cc158b6df9d5348d499df232c22844d9223610a57aea",
            "bytes": 2425,
            "mode": "0644",
        },
    )
    sys.exit(main())
