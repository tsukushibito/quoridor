def test_partial_depth_nonfinite_illegal_timing_and_actual_guardian_cleanup_refuse(self):
    with tempfile.TemporaryDirectory() as t:
        self.tmp = type("TMP", (), {"name": t})()
        _, _, _, c, _ = self.fixture(2, 4)
        obs = {
            "engine_index": 0,
            "accepted": True,
            "failure": None,
            "engine_error": None,
            "action": 13,
            "pv": [13],
            "accepted_ns": 12,
            "admission_checked_ns": 11,
            "returned_ns": 10,
            "caller_seconds": 0.1,
            "thinking_seconds": 0.1,
            "value_stm": 0.2,
            "completed_depth": 4,
            "stop": "depth_cap",
            "deadline_ns": None,
            "counters": {
                "completed_snapshot_validation_failed": False,
                "authority_receipt_ns": 10,
                "drain_finished_ns": 10,
                "actual_zero_stock_safe_race_enabled": True,
                "requested_zero_stock_safe_race_method": "path_tail",
                "actual_zero_stock_safe_race_method_id": "zero-stock431-one-path-tail-E-two-keys-v1",
            },
        }
        row = {"game": 0, "moves": [13, 13], "observations": [obs]}
        lc.arena_observation(c, row)
        for key, value in (
            ("completed_depth", 3),
            ("value_stm", float("inf")),
            ("failure", "illegal_move"),
            ("pv", [22]),
        ):
            bad = copy.deepcopy(row)
            bad["observations"][0][key] = value
            with self.assertRaises(lc.Refused):
                lc.arena_observation(c, bad)
        partial = copy.deepcopy(row)
        partial["observations"][0].update(
            accepted=False, completed_depth=3, failure="incomplete_depth"
        )
        partial["moves"] = [13]
        lc.arena_observation(c, partial)
        c["arena"]["comparison"] = "evaluator_wall_time"
        obs["deadline_ns"] = 100
        lc.arena_observation(c, row)
        obs["counters"]["drain_finished_ns"] = 9
        with self.assertRaises(lc.Refused):
            lc.arena_observation(c, row)
        record = {
            "exit_code": 0,
            "remaining": [],
            "cleanup_complete": False,
            "direct_child_reaped": True,
        }
        directory = self.root / "command"
        directory.mkdir()
        ledger = []
        with self.assertRaises(lc.Refused):
            lc.command(
                {
                    "kind": "build",
                    "limits": {"log_B": 128, "worker_cpu": 4, "guardian_cpu": 6},
                    "cwd": str(self.root),
                    "env": {},
                },
                {"name": "fake-guardian", "argv": ["NOT_EXECUTED"]},
                directory,
                None,
                executor=lambda *_a, **_kw: record,
                ledger=ledger,
            )
        self.assertIs(ledger[0]["guardian_return"], record)
        self.assertEqual(ledger[0]["guardian_return"]["cleanup_complete"], False)
