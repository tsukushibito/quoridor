"""Return configured-data maintenance and fixture v2, then ordinary own note/backup."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
V2 = OWN / "smoke-fixture-v2"
ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def run(argv):
    with subprocess.Popen(
        argv, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate(timeout=60)
        code = child.wait()
    result = dict(
        argv=argv,
        exit_code=code,
        stdout=stdout.decode(),
        stderr=stderr.decode(),
        directwait_reaped=True,
        handles_closed=child.stdout.closed and child.stderr.closed,
    )
    assert code == 0, result
    return result


def main():
    progress = json.loads((OUT / "binding.json").read_text())
    for row in progress["subjects"]:
        for key in ("before", "post"):
            assert ref(row[key]["path"]) == row[key]
    fixture = json.loads((V2 / "fixture-binding.json").read_text())
    package = json.loads(Path(fixture["package"]["path"]).read_text())
    for file_ref in package["files"].values():
        assert ref(file_ref["path"]) == file_ref
    guards, fresh = [], []
    for label in (
        "configured-progress-intake-guard-v1",
        "configured-progress-source-guard-v1",
        "configured-progress-source-guard-v2",
        "configured-progress-fixture-v2-guard-v1",
    ):
        path = OWN / label / "result.json"
        g = json.loads(path.read_text())
        assert g["TMP_remaining"] == []
        guards.append(ref(path))
        for old in [
            g["controller"],
            *[r["guardian_return"]["child"] for r in g["checks"] if r.get("guardian_return")],
        ]:
            info = process.process_info(old["pid"])
            actual = process.identity(info) if info else None
            assert actual != old
            fresh.append(dict(original=old, actual=actual, exact_absent_or_different=True))
    assert g["status"] == "PASS"
    points = []
    for root in (OUT, V2):
        inodes = {}
        for path in [root, *root.rglob("*")]:
            st = path.lstat()
            inodes[(st.st_dev, st.st_ino)] = st.st_blocks * 512
        points.append(dict(root=str(root), allocated_B=sum(inodes.values()), inodes=len(inodes)))
    affected = save(
        OUT / "affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            points=points,
            scope="two new affected OWN32 subtrees once only; no old charge/global walk/refund/grant",
        ),
    )
    stop = save(
        OUT / "source-helper-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            actual_source_guards=guards,
            actual_source_reader_STOP="2026-10-21T04:41:39.292033+00:00",
            actual_fixture_reader_STOP=g["reader_STOP"],
            fresh_exact_known_ids=fresh,
            directwait_reap_handles=True,
            remaining=[],
            TMP=[],
            source_leases=[],
            CPU=2,
            guardian_CPU=18,
            family_B=1073741824,
            controller_included_B=67108864,
            hostreserve_B=4294967296,
            GPU=0,
            affected_point=affected,
            source_short_SH_NB_released=True,
            Main_target_imports=0,
            tests_smoke_native_Search_model_RNG=0,
            Main_Git_Cargo_docs_writes=0,
            futurequiet=False,
            current_light_delivery_separate=True,
        ),
    )
    handoff = save(
        OUT / "handoff.json",
        dict(
            issue="quoridor-4lc.324.32",
            progress_binding=ref(OUT / "binding.json"),
            fixture_v2_binding=ref(V2 / "fixture-binding.json"),
            package=ref(V2 / "package-binding.json"),
            actual_source_STOP=stop,
            Root_next="sparse-adopt only arena_cohort_progress + new regression/test field, execute one new selector; bind actual adopted LC to fresh real allocation then actual normal dummy once, no author entry",
            actual_tests_smoke="UNRUN",
            old62d5_original_fixture_old_finding="immutable",
            qualifications="format/lint/parser/outside-function correspondence only; no SOURCE_CLEAR/runtime/parallel PASS claim",
        ),
    )
    body = OUT / "Root-fixed-handoff.txt"
    body.write_text(
        "SAME32 configured-data-owner causal packet fixed. Actual preserved turn_context 01a15cc1-8b33-70e3-9c61-d9d2cf5b9b51 / Sol6.1-high / cwd Main / danger-full-access / approval never. CurrentLC7d40/388500 verified under one short SH_NB and released; no standing reader. Only arena_cohort_progress production function changed; outside bytes including everyCPU/control function exact. Config bound once per RUN, games positive exact int (bool/null/nonpositive/coercion refused), configured sum replaces ALL3072/32 slot constants, exact same terminal/native/inflight/unentered domains, actualrun_id/census/retained checks, pair identities/missing native UNKNOWN, actual PID/authority/RAM/cancel/send/finalize unchanged. No plan-derived started/completed outcomes. Forward/inverse + exact before/post/modes attached.\n\n"
        "One NEW meaningful regression definition uses existing fixture seams: heterogeneous1,2/3,4/5 sum15, terminal9/inflight2/unentered4, missingcensus3 separately, knowncompleted5/scientificUNKNOWN10, then ALL missingnative means knowncompleted0/UNKNOWN15. Invalid typedcounts and wrongplanned/census/retained/run_id refuse. Existing R3 fixture only adds its formerly implicit games=32 (AST otherwise identical; unchanged assertions), no successful suite replay. Author tests0. Root exact selector in binding.\n\n"
        "Fixturev2 representation amendment before ANY outputs: materialize adds ONLY games=1 per synthetic operation. No game executes or fake native report; no publication implies scientificUNKNOWN, knowncompleted0. Other FOUR executable owners byteexact to originalv1; same8 cases, CPU/authority/resources/directwait/finalize/cancel/assessment/restore unchanged. New package/footer/inverse refs consistent, currentLC/hash intentionally future until actualproduction adoption and Root allocation. Originalb3ae/v1/finding immutable. No Main temporary install or case run by author.\n\n"
        "Scoped Ruffformat100/lint/parser PASS; initial scope-only missing-global lint attempt and unused helper import preserved FAILED, fixed by linting actual assembled owners, not guard relaxation. Exact outside production function and outsideadded games field proved statically. SourcehelperSTOP04:42:07.715164Z, fresh exactIDs absent/different, directwait-reap/handles/TMP/sourceleases[], CPU2/G18/F1GiBincl64/host4/G0; current delivery separate. Actual Root adoption/test/smoke still pending, no selfclear. No new grant, Search/native/model/RNG/test/oldproof/source-review replay. All MPCFAILED/ETC208/no games/costs/pauses/seals/defaults/models/foreign50GB held.\n\n"
        + json.dumps(
            dict(
                handoff=handoff,
                source_STOP=stop,
                progress=ref(OUT / "binding.json"),
                fixture_v2=ref(V2 / "fixture-binding.json"),
                delivery_guard=str(OWN / "configured-progress-delivery-guard-v1/result.json"),
            ),
            indent=2,
        )
        + "\n"
    )
    save(
        OUT / "Root-delivery.json",
        run(
            [
                "bash",
                "scripts/dev/research-session.sh",
                "send",
                "--thread",
                "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                "--issue",
                "quoridor-4lc.324",
                "--cwd",
                str(ROOT),
                "--body-file",
                str(body),
            ]
        ),
    )
    show = run(["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.324.32", "--json"])
    issue = json.loads(show["stdout"])
    issue = issue[0] if isinstance(issue, list) else issue
    assert (
        issue["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
        and issue["status"] == "in_progress"
    )
    save(OUT / "beads-show.json", show)
    save(
        OUT / "beads-note.json",
        run(
            [
                "bash",
                "scripts/dev/beads.sh",
                "update",
                "quoridor-4lc.324.32",
                "--append-notes",
                "Configured-data-owner sparse repair: only arena_cohort_progress derives slot counts from bound positive-int config.games and actual RUN sum, preserving native missing UNKNOWN and all CPU/authority/control predicates. One new small heterogeneous/missingcensus/refusal regression UNRUN; old R3 fixture adds explicit games32 only. Fixturev2 adds synthetic games1 only, 4other executable owners exact. Scopedformat/lint/parser PASS, author tests/smoke/Main0, sourcehelper STOP04:42:07.715164Z/directwait-reap/handles/TMPleases[]/freshIDs. Original62d5/b3ae/finding immutable. Packet "
                + str(OUT / "handoff.json"),
            ]
        ),
    )
    save(
        OUT / "beads-backup.json", run(["bash", "scripts/dev/beads.sh", "backup", "sync", "--json"])
    )
    removed = []
    for path in Path(os.environ["TMPDIR"]).iterdir():
        assert (
            path.is_file()
            and path.stat().st_size == 0
            and path.name.startswith("uv-")
            and path.name.endswith(".lock")
        )
        with path.open("rb") as f:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            path.unlink()
        removed.append(str(path))
    save(OUT / "delivery-TMP-cleanup.json", dict(removed=removed))
    print(json.dumps(dict(handoff=handoff, source_STOP=stop)))


if __name__ == "__main__":
    main()
