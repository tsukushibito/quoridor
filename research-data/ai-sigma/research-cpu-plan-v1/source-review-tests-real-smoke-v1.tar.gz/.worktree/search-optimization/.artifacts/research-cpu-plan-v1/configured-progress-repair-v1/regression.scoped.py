def test_configured_progress_counts_and_missing_native_census(self):
    """Configured slots never imply entry, completion, retained outcomes or native census."""
    self.current = 200
    counts = ((1, 2), (3, 4), (5,))
    config_paths = []
    for lane, planned in enumerate(counts):
        templates = []
        for index, games in enumerate(planned):
            template = copy.deepcopy(self.settings[lane]["runs"][0])
            config = lc.document(lc.document(template["experiment"])["config"])
            config.update(
                games=games,
                run_id=f"small-{lane}-{index}",
                output=str(self.root / f"native-{lane}-{index}"),
            )
            config["arena"]["book"] = dict(openings=[])
            config_path = self.root / f"config-{lane}-{index}.json"
            config_ref = self.save(config_path, config)
            experiment = lc.document(template["experiment"])
            experiment["config"] = config_ref
            template["experiment"] = self.save(
                self.root / f"experiment-{lane}-{index}.json", experiment
            )
            templates.append(template)
            config_paths.append(config_path)
        self.settings[lane]["runs"] = templates
        self.specs[lane]["experiment"] = templates[0]["experiment"]
        self.save(
            Path(self.cohort["members"][lane]["output"]) / "run-000/operation/manifest.json",
            dict(status="PASS", cleanup_complete=True),
        )
    # A real phase directory is inflight, while the other configured second RUN is unentered.
    (Path(self.cohort["members"][0]["output"]) / "run-001").mkdir(parents=True)
    self.rebind_settings()
    publications = []
    for lane, games, completed, unknown in ((0, 1, 1, 0), (2, 5, 4, 1)):
        config = lc.document(lc.document(self.settings[lane]["runs"][0]["experiment"])["config"])
        path = Path(config["output"]) / "result.json"
        value = dict(
            outcome_count=games,
            report=dict(
                run_id=config["run_id"],
                planned=games,
                arena_summary=dict(
                    census=dict(
                        planned_games=games,
                        started_games=games,
                        completed_games=completed,
                        unknown_games=unknown,
                        complete_pairs=0,
                    ),
                    pairs=[],
                ),
            ),
        )
        self.save(path, value)
        publications.append((path, value))

    def remove_packet():
        for name in (
            "first-progress.json",
            "first-progress-pairs.json",
            "first-progress-retained.json",
            "first-progress.txt",
            "first-progress-notification.json",
            "first-progress-notification.full.log",
        ):
            (self.shared / name).unlink(missing_ok=True)

    with (
        self.kernel(),
        patch.object(lc.process, "execute", side_effect=RuntimeError("unit notification failure")),
    ):
        # Bound config counts must be positive integers, never bool, omitted or coerced.
        original = lc.document(lc.bound(config_paths[0])[0])
        for invalid in (None, True, 0, -1, 1.0, "1"):
            with self.subTest(games=invalid):
                changed = {**original, "games": invalid}
                self.save(config_paths[0], changed)
                experiment_path = Path(self.settings[0]["runs"][0]["experiment"]["path"])
                experiment = json.loads(experiment_path.read_text())
                experiment["config"] = lc.bound(config_paths[0])[0]
                self.settings[0]["runs"][0]["experiment"] = self.save(experiment_path, experiment)
                self.specs[0]["experiment"] = self.settings[0]["runs"][0]["experiment"]
                self.rebind_settings()
                with self.assertRaisesRegex(lc.Refused, "configured positive-int games"):
                    lc.arena_cohort_progress(self.specs[0])
        self.save(config_paths[0], original)
        experiment = json.loads(experiment_path.read_text())
        experiment["config"] = lc.bound(config_paths[0])[0]
        self.settings[0]["runs"][0]["experiment"] = self.save(experiment_path, experiment)
        self.specs[0]["experiment"] = self.settings[0]["runs"][0]["experiment"]
        self.rebind_settings()
        path, good = publications[0]
        for mutate in ("planned", "census", "retained", "run_id"):
            with self.subTest(publication=mutate):
                bad = copy.deepcopy(good)
                if mutate == "planned":
                    bad["report"]["planned"] += 1
                elif mutate == "census":
                    bad["report"]["arena_summary"]["census"]["planned_games"] += 1
                elif mutate == "retained":
                    bad["outcome_count"] += 1
                else:
                    bad["report"]["run_id"] = "other-run"
                self.save(path, bad)
                with self.assertRaisesRegex(lc.Refused, "actual saved local native census"):
                    lc.arena_cohort_progress(self.specs[0])
                self.assertFalse((self.shared / "first-progress.json").exists())
        self.save(path, good)
        lc.arena_cohort_progress(self.specs[0])
        packet = json.loads((self.shared / "first-progress.json").read_text())
        actual = packet["counts"]
        for key, value in dict(
            planned_games=15,
            terminal_planned_games=9,
            inflight_slots=2,
            unentered_slots=4,
            native_started_games_known=6,
            completed_games_known=5,
            unknown_games_known=1,
            retained_games_known=6,
            terminal_native_census_unknown_slots=3,
            retained_count_unknown_slots=3,
            scientific_outcome_UNKNOWN_slots=10,
            complete_pairs_known=0,
        ).items():
            self.assertEqual(actual[key], value, key)
        self.assertEqual(packet["overall_target"], 15)
        self.assertEqual(packet["conditional_remaining_seconds"], 12.0)
        remove_packet()
        # Without ANY native publication, no zero-completion inference from the configured plan.
        for path, _ in publications:
            path.unlink()
        lc.arena_cohort_progress(self.specs[0])
        missing = json.loads((self.shared / "first-progress.json").read_text())["counts"]
        self.assertEqual(missing["completed_games_known"], 0)
        self.assertEqual(missing["terminal_native_census_unknown_slots"], 9)
        self.assertEqual(missing["scientific_outcome_UNKNOWN_slots"], 15)
