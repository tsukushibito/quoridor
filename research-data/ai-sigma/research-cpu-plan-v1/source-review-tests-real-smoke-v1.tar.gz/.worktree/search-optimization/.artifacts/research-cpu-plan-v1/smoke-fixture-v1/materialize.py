"""Small normal metadata fixtures; all scientific identities explicitly synthetic."""

import os
from pathlib import Path
import shlex
import sys
import time

from science_fixture import SCHEMA, ROOT, canonical, publish, reference

MiB = 1024**2
CASES = (
    "two_lane",
    "single_lane",
    "bad_unavailable",
    "bad_smt",
    "bad_overlap",
    "outside_thread",
    "child_failure",
    "parent_cancel",
)


def job_config(settings_ref, allocation, *, lane=None, cohort_ref=None):
    kind = "sequence" if lane is not None or cohort_ref is None else "cohort"
    value = dict(
        issue=allocation["issue"],
        goal_issue=allocation["goal_issue"],
        thread_id=allocation["thread_id"],
        cwd=str(ROOT),
        argv=[
            sys.executable,
            "-B",
            str(ROOT / "scripts/dev/research-lifecycle.py"),
            kind,
            "--intent",
            settings_ref["path"],
            "--sha256",
            settings_ref["sha256"],
        ],
        resource_contract=settings_ref["path"],
        end_at=None,
        max_runtime_seconds=allocation["case_timeout_seconds"],
        # Supported normal notification horizon, expired after this smoke body.
        # Execution remains bounded by max_runtime_seconds, not an env exemption.
        notify_until=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        control_interval_seconds=2,
        notify_interval_seconds=1,
        request_timeout_seconds=5,
        log_max_bytes=65536,
    )
    if cohort_ref is not None and lane is not None:
        value["authority_parent"] = dict(cohort=cohort_ref, lane=lane)
    return value


def case(root, label, allocation, contract_ref, lc):
    """No authority/CPU/RAM validation is stubbed; actual common owners consume this."""
    root.mkdir()
    shared = root / "shared"
    shared.mkdir()
    (shared / "signals").mkdir()
    serial = label == "single_lane"
    count = 1 if serial else 2
    managers = allocation["management_cpu_pool"]
    workers = allocation["lane_cpu_cores"][:count]
    pool = [*managers, *workers]
    common = allocation["common_family_B"]
    lane_family = allocation["lane_family_B"]
    parallel = dict(
        parallel_games=count,
        physical_cpu_pool=list(pool),
        operation_ids=list(range(2 * count)),
        lane_family_B=lane_family,
        lane_storage_B=16 * MiB,
        common_family_B=common,
        shared_storage_B=16 * MiB,
    )
    resolved = lc.resolve_arena_parallel(parallel)
    if label == "bad_unavailable":
        pool[2] = max(lc.process.available_cpus()) + 1
    elif label == "bad_smt":
        siblings = (
            Path(f"/sys/devices/system/cpu/cpu{managers[0]}/topology/thread_siblings_list")
            .read_text()
            .strip()
        )
        candidates = {
            int(cpu)
            for part in siblings.split(",")
            for cpu in (range(int(part.split("-")[0]), int(part.split("-")[-1]) + 1))
        }
        pool[2] = next(cpu for cpu in sorted(candidates) if cpu != managers[0])
    elif label == "bad_overlap":
        pool[2] = managers[0]
    whole = (count + 1) * 16 * MiB
    source_refs = [
        reference(ROOT / name)
        for name in (
            "scripts/dev/research-lifecycle.py",
            "scripts/dev/research-job.py",
            "python/quoridor_training/cycle_process.py",
        )
    ]
    # The explicit test prefix exercises the maintained named-compute peer path.
    # It is a shell/Python dummy, never a qualified scientific runner image.
    wrapper = shared / "quoridor-runner-cpu-smoke"
    payload = Path(__file__).with_name("mask_payload.py")
    wrapper.write_text(
        "#!/bin/bash\nexec -a "
        + shlex.quote(str(wrapper))
        + " "
        + shlex.quote(sys.executable)
        + " -B "
        + shlex.quote(str(payload))
        + ' "$@"\n'
    )
    os.chmod(wrapper, 0o755)
    artifact = reference(wrapper)
    synthetic_owner = publish(
        shared / "synthetic-data-owner.json",
        dict(schema=SCHEMA, not_a_qualified_build=True, artifact=artifact),
    )
    lane_roots = [root / f"lane-{lane}" for lane in range(count)]
    for lane_root in lane_roots:
        lane_root.mkdir()
    family = common + count * lane_family
    resources = dict(
        CPU=len(pool),
        GPU=0,
        threads=1,
        family_RAM_B=family,
        host_reserve_B=allocation["host_reserve_B"],
        controller_included=True,
    )
    if serial:
        resources["CPU"] = 2  # Exact native team; parent plan separately includes outer manager.
    support = publish(
        shared / "support.json",
        dict(
            schema=SCHEMA,
            Root_allocation=contract_ref,
            resources=resources,
            storage_budget=dict(whole_B=whole, roots=[str(p) for p in [*lane_roots, shared]]),
        ),
    )
    settings_values = []
    members = []
    for lane, lane_root in enumerate(lane_roots):
        assigned = resolved["members"][lane]
        main = assigned["main_cpu"]
        worker = pool[2 + lane]
        output = lane_root / "sequence"
        settings_path = lane_root / "settings.json"
        events = lane_root / "events"
        marker = dict(schema=SCHEMA, contract=contract_ref, events=str(events))
        limits = dict(
            family_B=family if serial else lane_family,
            controller_B=common if serial else 64 * MiB,
            host_reserve_B=allocation["host_reserve_B"],
            log_B=65536,
            owned_B=16 * MiB,
            free_B=None,
            worker_cpu=worker,
            guardian_cpu=main,
        )
        runs = []
        for local in range(2):
            operation = local if serial else lane + count * local
            phase = output / f"run-{local:03d}"
            data_root = phase / "mask-data"
            config = dict(
                synthetic_cpu_smoke=dict(
                    **marker,
                    lane=lane,
                    lane_count=count,
                    operation=operation,
                    local_index=local,
                    behavior=label,
                    outside_cpu=managers[1 - lane % 2],
                    parent_runtime=str(shared / "parent-runtime"),
                    signals=str(shared / "signals"),
                    python=sys.executable,
                ),
                arena=dict(comparison="whole_wall_time"),
                cpu_cores=[worker, worker],
                management_cpu_core=main,
                workers=1,
                active_games=1,
                max_batch=1,
                max_memory_bytes=limits["family_B"] - limits["controller_B"],
                engines=[dict(kind="distance", ordering_profile="control", search_threads=1)] * 2,
                output=str(data_root),
            )
            config_ref = publish(lane_root / f"config-{local}.json", config)
            argv = [str(wrapper), "mask", config_ref["path"]]
            experiment = publish(
                lane_root / f"synthetic-experiment-{local}.json",
                dict(
                    schema=SCHEMA,
                    synthetic_cpu_smoke=marker,
                    phase="arena",
                    batch=operation,
                    planned_slots=1,
                    build_manifest=synthetic_owner,
                    config=config_ref,
                    argv=argv,
                ),
            )
            runs.append(
                dict(
                    schema="quoridor.research.lifecycle-intent.v1",
                    kind="run",
                    synthetic_cpu_smoke=marker,
                    owner=str(root),
                    cwd=str(ROOT),
                    output=str(phase / "operation"),
                    TMP=str(phase / "TMP"),
                    limits=limits,
                    support=support,
                    artifact=artifact,
                    caller_sources=source_refs,
                    approved_plan=None,
                    experiment=experiment,
                    data_root=str(data_root),
                    data=[
                        dict(name="actual_mask", path=str(data_root / "mask.json"), limit_B=65536)
                    ],
                    finalizers=[],
                    argv=argv,
                    child_cpu_cores=sorted({main, worker}),
                    command_timeout_seconds=20,
                    env={
                        **{
                            k: os.environ[k]
                            for k in (
                                "PATH",
                                "HOME",
                                "QUORIDOR_PROJECT_ROOT",
                                "QUORIDOR_PROJECT_ENV",
                                "VIRTUAL_ENV",
                                "PYTHONPATH",
                                "LD_LIBRARY_PATH",
                            )
                            if k in os.environ
                        },
                        "CUDA_VISIBLE_DEVICES": "",
                        "OMP_NUM_THREADS": "1",
                        "MKL_NUM_THREADS": "1",
                        "OPENBLAS_NUM_THREADS": "1",
                        "ORT_DISABLE_TELEMETRY": "1",
                        "PYTHONDONTWRITEBYTECODE": "1",
                        "TMPDIR": str(phase / "TMP"),
                    },
                )
            )
        settings = dict(
            kind="sequence",
            owner=str(root),
            cwd=str(ROOT),
            output=str(output),
            runs=runs,
            synthetic_cpu_smoke=marker,
        )
        if serial:
            settings["limits"] = {**limits, "guardian_cpu": managers[1]}
        else:
            settings["arena_lane"] = lane
        settings_values.append(settings)
        members.append(
            dict(
                **{k: v for k, v in assigned.items() if k not in {"operation_ids", "AI_workers"}},
                AI_workers=[worker, worker],
                roots=[str(lane_root)],
                settings_path=str(settings_path),
                settings_body_sha256=canonical(settings),
                output=str(output),
                job_runtime=str(lane_root / "outer-runtime"),
            )
        )
    if serial:
        settings_ref = publish(Path(members[0]["settings_path"]), settings_values[0])
        cfg = job_config(settings_ref, allocation)
        parent_config = publish(shared / "parent-job.json", cfg)
        return dict(
            label=label,
            root=str(root),
            parent_config=parent_config,
            runtime=str(shared / "parent-runtime"),
            members=members,
            settings=[settings_ref],
            sources=source_refs,
        )
    parent = dict(
        runtime=str(shared / "parent-runtime"),
        output=str(shared / "parent"),
        intent_path=str(shared / "parent-settings.json"),
        config_path=str(shared / "parent-job.json"),
    )
    cohort = dict(
        schema="quoridor.research.arena-cohort.v1",
        owner=str(root),
        issue=allocation["issue"],
        thread_id=allocation["thread_id"],
        artifact=artifact,
        support=support,
        management_cpu_pool=managers,
        global_controller_cpu=managers[0],
        global_controller_B=common,
        shared_storage_B=16 * MiB,
        shared_roots=[str(shared)],
        control_root=str(shared),
        members=members,
        authority_parent=parent,
        parallel={**parallel, "physical_cpu_pool": pool},
    )
    cohort_ref = publish(shared / "cohort.json", cohort)
    settings_refs, job_refs = [], []
    for member, value in zip(members, settings_values, strict=True):
        value["arena_cohort"] = cohort_ref
        settings_ref = publish(Path(member["settings_path"]), value)
        settings_refs.append(settings_ref)
        job_refs.append(
            publish(
                Path(member["settings_path"]).parent / "outer-job.json",
                job_config(settings_ref, allocation, lane=member["lane"], cohort_ref=cohort_ref),
            )
        )
    parent_settings = publish(
        Path(parent["intent_path"]),
        dict(
            kind="cohort",
            owner=str(root),
            cwd=str(ROOT),
            output=parent["output"],
            arena_cohort=cohort_ref,
            synthetic_cpu_smoke=dict(
                schema=SCHEMA, contract=contract_ref, events=str(shared / "events")
            ),
        ),
    )
    publish(
        shared / "launch.json",
        dict(
            cohort=cohort_ref,
            monotonic=time.monotonic(),
            job_configs=job_refs,
            job_runtimes=[m["job_runtime"] for m in members],
        ),
    )
    parent_config = publish(
        Path(parent["config_path"]), job_config(parent_settings, allocation, cohort_ref=cohort_ref)
    )
    return dict(
        label=label,
        root=str(root),
        parent_config=parent_config,
        runtime=parent["runtime"],
        members=members,
        settings=settings_refs,
        sources=source_refs,
        cohort=cohort_ref,
    )
