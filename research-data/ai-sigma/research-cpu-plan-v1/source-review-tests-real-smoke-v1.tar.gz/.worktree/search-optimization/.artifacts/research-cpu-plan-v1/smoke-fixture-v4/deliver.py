"""Return the fixed three-case continuation, then one own note/backup."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
REPAIR = OWN / "exception-cleanup-repair-v1"
ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def run(argv):
    with subprocess.Popen(
        argv, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate(timeout=60)
        code = child.wait()
    return dict(
        argv=argv,
        exit_code=code,
        stdout=stdout.decode(),
        stderr=stderr.decode(),
        directwait_reaped=True,
        handles_closed=child.stdout.closed and child.stderr.closed,
    )


def main():
    guard_path = OWN / "exception-cleanup-fixture-v4-guard-v1/result.json"
    guard = json.loads(guard_path.read_text())
    assert guard["status"] == "PASS" and guard["TMP_remaining"] == []
    fresh = []
    for old in [
        guard["controller"],
        *[r["guardian_return"]["child"] for r in guard["checks"] if r.get("guardian_return")],
    ]:
        info = process.process_info(old["pid"])
        actual = process.identity(info) if info else None
        assert actual != old
        fresh.append(dict(original=old, actual=actual, exact_absent_or_different=True))
    package = json.loads((OUT / "package-binding.json").read_text())
    for r in package["files"].values():
        assert ref(r["path"]) == r
    for r in package["prior_successful_case_receipts"].values():
        assert ref(r["path"]) == r
    points = []
    for root in (REPAIR, OUT):
        seen = {}
        for path in [root, *root.rglob("*")]:
            st = path.lstat()
            seen[(st.st_dev, st.st_ino)] = st.st_blocks * 512
        points.append(dict(root=str(root), allocated_B=sum(seen.values()), inodes=len(seen)))
    affected = save(
        OUT / "affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            points=points,
            scope="new cleanup source and fixture derivative subtrees once, no old run/holding charge/global walk",
        ),
    )
    stop = save(
        OUT / "source-helper-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            guard=ref(guard_path),
            actual_fixture_reader_STOP=guard["reader_STOP"],
            source_STOP=ref(REPAIR / "source-helper-STOP.json"),
            fresh_exact_known_ids=fresh,
            directwait_reap_handles=True,
            remaining=[],
            TMP=[],
            source_leases=[],
            CPU=2,
            guardian_CPU=18,
            family_B=1073741824,
            controller_included_B=67108864,
            hostreserve_B=4294967296,
            GPU=0,
            affected_point=affected,
            tests_smoke_native_Search_model_RNG=0,
            Main_Git_Cargo_docs_writes=0,
            futurequiet=False,
            current_light_delivery_separate=True,
        ),
    )
    handoff = save(
        OUT / "handoff.json",
        dict(
            issue="quoridor-4lc.324.32",
            source_binding=ref(REPAIR / "final-binding.json"),
            source_STOP=ref(REPAIR / "source-helper-STOP.json"),
            fixture_binding=ref(OUT / "fixture-binding.json"),
            fixture_STOP=stop,
            package=ref(OUT / "package-binding.json"),
            prior5_receipts=package["prior_successful_case_receipts"],
            original8_failed=package["original_all8_failure"],
            selected_only=package["selected_original_failed_cleanup_cases"],
            Root_future="adopt/review and run only new source definitions + original3 cleanup cases with fresh actual current LC/cycle/resource refs; no rerun of five PASS cases; Root combined acceptance separately",
            actual_author_execution="UNRUN",
        ),
    )
    body = OUT / "Root-fixed-handoff.txt"
    body.write_text(
        "SAME32 fixed fixturev4 ONLY original3 failed cleanup cases is now returned, after earlier fixed-source delivery/STOP. Source final-binding remains immutable; no new production change since source return.\n\nV4 coordinator changes ONLY selected case tuple outside_thread/child_failure/parent_cancel and truthful selected-scope return metadata/assertion. All other FOUR executable owners byteexact to originalv3; normal CPU/authority/resource/session/Popen/cancel/drain/finalize/assessment/restore + synthetic science paths unchanged. Prior5 actual PASS assessments and originalALL8 failed coordinator-return are fixed byref; no replay/restamp/deletion. V4 reports repaired_cleanup_cases_PASS, full_normal_parallel_PASS=false because this invocation alone is only3. Root assesses combined current source correspondence + actual repaired3 outputs; not a green subset of science.\n\nNew thin source-binding-cleanup-composition updates only expected LC/cycle post refs for current exact source custody; original62d5 and original actual651/job13a2/old source bindings preserved. This is NOT actualadoption/qualification: Root must bind real adopted new LC/cycle currentrefs and fresh resources. Candidate common source actualcycle execute now carries only exception after-finally outcome; normal guardian return/PASS/capture semantics untouched, old failed outcomes/disks/TMP never rewritten. New three source test definitions remain UNRUN byauthor; successes/original16 distinct definitions not replayed.\n\nSourcehelperSTOP05:18:12.828497Z alreadydelivered first; actual fixturehelperSTOP05:19:33.279175Z, formatter/lint/parser and footer check PASS. CPU2/G18/F1GiBincl64/host4/G0/directwait-reap/handles/TMP/sourceleases[]/freshIDs stopped, no idlelease/futurequiet; current lightdelivery separate. One new source+fixture affectedpoint, no old holding recharge. No author tests/realSmoke/Search/model/RNG/compiler/Main writes/reviewdispatch/selfclear. All originalMPCFAILED/ETC208/no games/caps/pauses/seals/defaults/models/foreign/50GB/feesUNKNOWN held.\n\n"
        + json.dumps(
            dict(
                handoff=handoff,
                source_binding=ref(REPAIR / "final-binding.json"),
                fixture_binding=ref(OUT / "fixture-binding.json"),
                fixture_STOP=stop,
                delivery_guard=str(OWN / "exception-cleanup-final-delivery-guard-v1/result.json"),
            ),
            indent=2,
        )
        + "\n"
    )
    argv = [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--cwd",
        str(ROOT),
        "--body-file",
        str(body),
    ]
    delivered = run(argv)
    save(OUT / "Root-delivery.json", delivered)
    if delivered["exit_code"] != 0 and "no active turn to steer" in delivered["stderr"]:
        delivered = run(argv)
        save(OUT / "Root-delivery-causal-race-v2.json", delivered)
    assert delivered["exit_code"] == 0, delivered
    show = run(["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.324.32", "--json"])
    assert show["exit_code"] == 0, show
    issue = json.loads(show["stdout"])
    issue = issue[0] if isinstance(issue, list) else issue
    assert (
        issue["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
        and issue["status"] == "in_progress"
    )
    save(OUT / "beads-show.json", show)
    note = run(
        [
            "bash",
            "scripts/dev/beads.sh",
            "update",
            "quoridor-4lc.324.32",
            "--append-notes",
            "Actual exception TMP cleanup maintenance fixed privately: actual cycle.execute after-finally snapshot on exception, LCcommand separate guardian_exception_outcome (guardian_returnNULL/capturefalse/primary failure preserved), own-empty-TMP deletion only with true final cleanup evidence, unknown/pending/incomplete refuses. Three new boundary definitions UNRUN. SourcehelperSTOP05:18:12.828497Z. Fixturev4 only original3 cleanup-failed cases, fourother executableowners exact; old5 actualPASS receipts and oldALL8exit1 preserved, no full8PASS claim. Format/lint/parser PASS, fixtureSTOP05:19:33.279175Z/directwait-reap/handles/TMPleases[]/freshIDs CPU2G18/F1Gincl64/host4G/G0. Author Main/test/smoke0; no old TMP/outcome edits. Packet "
            + str(OUT / "handoff.json"),
        ]
    )
    save(OUT / "beads-note.json", note)
    assert note["exit_code"] == 0, note
    backup = run(["bash", "scripts/dev/beads.sh", "backup", "sync", "--json"])
    save(OUT / "beads-backup.json", backup)
    assert backup["exit_code"] == 0, backup
    removed = []
    for path in Path(os.environ["TMPDIR"]).iterdir():
        assert (
            path.is_file()
            and path.stat().st_size == 0
            and path.name.startswith("uv-")
            and path.name.endswith(".lock")
        )
        with path.open("rb") as f:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            path.unlink()
        removed.append(str(path))
    save(OUT / "delivery-TMP-cleanup.json", dict(removed=removed))
    print(json.dumps(handoff))


if __name__ == "__main__":
    main()
