"""Return one fixture suffix with its conservative source-only global audit."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
sys.path.insert(0, str(OWN))
from intake import ROOT, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    guards, identities = [], []
    for name in (
        "test-fixture-repair-guard-v2",
        "test-fixture-repair-guard-v3",
        "test-fixture-repair-guard-v4",
    ):
        path = OWN / name / "result.json"
        g = json.loads(path.read_text())
        assert g["TMP_remaining"] == []
        guards.append(ref(path))
        for old in [
            g["controller"],
            *[r["guardian_return"]["child"] for r in g["checks"] if r.get("guardian_return")],
        ]:
            info = process.process_info(old["pid"])
            current = process.identity(info) if info else None
            assert current != old
            identities.append(dict(original=old, current=current, absent_or_different=True))
    assert g["status"] == "PASS"
    stop = save(
        OUT / "source-helper-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            actual_guards=guards,
            reader_STOP=g["reader_STOP"],
            fresh_known_ids=identities,
            directwait_reap_handles=True,
            remaining=[],
            TMP=[],
            source_leases=[],
            Main_reader=False,
            CPU=2,
            guardian18=True,
            family_B=1073741824,
            management_included_B=67108864,
            hostreserve_B=4294967296,
            GPU=0,
            new_subtree_affected_B=sum(p.lstat().st_blocks * 512 for p in [OUT, *OUT.rglob("*")]),
            tests_smoke_native_Search_model_RNG=0,
            futurequiet=False,
            current_light_delivery_separate=True,
        ),
    )
    body = OUT / "Root-handoff.txt"
    body.write_text(
        "SAME32 one remaining RSS TEST-ONLY suffix versus actuald86bb27c/28541 first6428 post, fixed62d5/prod source unchanged. Actual cohort_parent_command + internal_cohort_failure + now AST helpers are compiled with actual execute; noncohort predicate returnsNone normally. Actual CONTROL_READ_SECONDS literal, Path/datetime/timezone supplied. Unexpected lifecycle loader explicitly raises (CPU/cohort excluded), not permission/constantFalse; original CPU None/False isolation and RSS/cancel/directwait/cleanup assertions unchanged. Conservative recursive symtable global audit of execute+all3helpers leaves0missing names, beyond only the immediately reached line854. Outside named definition bytes exact.\n"
        "Scopedformat100/lint/parser finalPASS, no author test/import/realSmoke/native/Search. Own preparation F401-unused-helper and missing-newline outside-correspondence refusal retained; no product/test-body result inferred. Root runs ONLY remaining RSSselector; original11+arenaPASS retained.\n"
        "ActualhelperSTOP04:21:54.605167Z, fresh exact known helpers absent/different/directreap/handles/TMPleases[], CPU2/G18/F1GiBincl64/host4/G0. Return before admin; executable normalfixture work continues, not another ACK gate.\n"
        + json.dumps(
            dict(
                binding=ref(OUT / "binding.json"),
                source_STOP=stop,
                delivery_guard=str(OWN / "test-fixture-repair-delivery-guard-v2/result.json"),
            ),
            indent=2,
        )
        + "\n"
    )
    argv = [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--cwd",
        str(ROOT),
        "--body-file",
        str(body),
    ]
    with subprocess.Popen(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE) as child:
        out, err = child.communicate(timeout=60)
        code = child.wait()
    receipt = dict(
        exit_code=code,
        stdout=out.decode(),
        stderr=err.decode(),
        directwait_reaped=True,
        handles_closed=child.stdout.closed and child.stderr.closed,
    )
    save(OUT / "Root-delivery.json", receipt)
    assert code == 0, receipt


if __name__ == "__main__":
    main()
