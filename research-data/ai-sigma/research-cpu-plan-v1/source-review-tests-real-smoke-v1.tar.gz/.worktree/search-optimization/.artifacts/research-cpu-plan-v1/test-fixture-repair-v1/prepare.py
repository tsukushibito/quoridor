"""Two causal test-definition repairs only; no import or execution of targets."""

import ast
import difflib
import hashlib
import json
from pathlib import Path
import sys
import textwrap

OWN = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

TARGETS = {
    "tools/research-session/test_arena_plan.py": "test_partial_depth_nonfinite_illegal_timing_and_actual_guardian_cleanup_refuse",
    "tools/research-session/test_lifecycle_arena_cohort_repair.py": "test_job_supervisor_resource_callback_covers_pre_spawn_and_wait",
}


def span(text, name):
    node = next(
        n for n in ast.walk(ast.parse(text)) if isinstance(n, ast.FunctionDef) and n.name == name
    )
    lines = text.splitlines(keepends=True)
    return (
        "".join(lines[: node.lineno - 1]),
        "".join(lines[node.lineno - 1 : node.end_lineno]),
        "".join(lines[node.end_lineno :]),
    )


def main():
    if sys.argv[1] == "edit":
        for subject, name in TARGETS.items():
            original = (OWN / "post-v3" / subject).read_text()
            _, body, _ = span(original, name)
            if subject.endswith("test_arena_plan.py"):
                old = '                    "drain_finished_ns": 10,\n'
                assert body.count(old) == 1
                body = body.replace(
                    old,
                    old
                    + '                    "actual_zero_stock_safe_race_enabled": True,\n                    "requested_zero_stock_safe_race_method": "path_tail",\n                    "actual_zero_stock_safe_race_method_id": "zero-stock431-one-path-tail-E-two-keys-v1",\n',
                )
            else:
                old = "        for refusal_at in (1, 3):\n"
                assert body.count(old) == 1
                body = body.replace(
                    old,
                    '        parent_command = next(\n            n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "cohort_parent_command"\n        )\n'
                    + old,
                )
                old = "ast.Module(body=[execute], type_ignores=[])"
                assert body.count(old) == 1
                body = body.replace(
                    old, "ast.Module(body=[parent_command, execute], type_ignores=[])"
                )
            path = OUT / "scoped" / Path(subject).name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("x") as stream:
                stream.write(textwrap.dedent(body))
        return
    assert sys.argv[1] == "bind"
    subjects, forward, inverse = [], [], []
    binding = json.loads((OWN / "fixed-v3/source-binding.json").read_text())
    for subject, name in TARGETS.items():
        before_path = OWN / "post-v3" / subject
        expected = next(r["post"] for r in binding["subjects"] if r["subject"] == subject)
        assert ref(before_path) == expected
        original = before_path.read_text()
        head, old, tail = span(original, name)
        scoped = (OUT / "scoped" / Path(subject).name).read_text()
        replacement = textwrap.indent(scoped, "    ").rstrip("\n")
        if old.endswith("\n"):
            replacement += "\n"
        post = head + replacement + tail
        ast.parse(post)
        assert span(post, name)[::2] == (head, tail)
        path = OUT / "post" / subject
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("x") as stream:
            stream.write(post)
        path.chmod(int(expected["mode"], 8))
        forward += difflib.unified_diff(
            original.splitlines(True),
            post.splitlines(True),
            fromfile="a/" + subject,
            tofile="b/" + subject,
        )
        inverse += difflib.unified_diff(
            post.splitlines(True),
            original.splitlines(True),
            fromfile="a/" + subject,
            tofile="b/" + subject,
        )
        subjects.append(
            dict(
                subject=subject,
                before=expected,
                post=ref(path),
                definition=name,
                outside_definition_bytes_exact=True,
                original_assertions_and_negative_cases="unchanged",
                unchanged_prefix_sha256=hashlib.sha256(head.encode()).hexdigest(),
                unchanged_suffix_sha256=hashlib.sha256(tail.encode()).hexdigest(),
            )
        )
    for name, lines in [("forward.patch", forward), ("inverse.patch", inverse)]:
        with (OUT / name).open("x") as stream:
            stream.writelines(lines)
    selectors = [
        "test_arena_plan.ArenaPlanTests." + TARGETS["tools/research-session/test_arena_plan.py"],
        "test_lifecycle_arena_cohort_repair.CohortRepairBoundary."
        + TARGETS["tools/research-session/test_lifecycle_arena_cohort_repair.py"],
    ]
    save(
        OUT / "binding.json",
        dict(
            issue="quoridor-4lc.324.32",
            status="PRIVATE_TEST_ONLY_UNRUN",
            fixed_62d5_unchanged=True,
            subjects=subjects,
            forward=ref(OUT / "forward.patch"),
            inverse=ref(OUT / "inverse.patch"),
            selectors=selectors,
            executed_tests=0,
            production_changes=0,
            safe_race_ID_basis="immutable Git22d23276 crates/quoridor-ai/src/alphabeta.rs ZeroStockSafeRaceMethod::PathTail.id",
            parent_predicate="compile actual current cohort_parent_command beside actual isolated execute; no constant-False predicate",
            retained_CPU_stub="configured_cpu_control None/False isolates RSS/cancel; not CPU qualification",
        ),
    )


if __name__ == "__main__":
    main()
