"""Complete the isolated RSS fixture's actual helper/global closure, source only."""

import ast
import builtins
import difflib
from pathlib import Path
import symtable
import sys
import textwrap

OWN = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

SUBJECT = "tools/research-session/test_lifecycle_arena_cohort_repair.py"
NAME = "test_job_supervisor_resource_callback_covers_pre_spawn_and_wait"


def split(text):
    node = next(
        n for n in ast.walk(ast.parse(text)) if isinstance(n, ast.FunctionDef) and n.name == NAME
    )
    lines = text.splitlines(keepends=True)
    return (
        "".join(lines[: node.lineno - 1]),
        "".join(lines[node.lineno - 1 : node.end_lineno]),
        "".join(lines[node.end_lineno :]),
    )


def global_names(table):
    names = {s.get_name() for s in table.get_symbols() if s.is_global() and s.is_referenced()}
    for child in table.get_children():
        names.update(global_names(child))
    return names


def main():
    before_path = OWN / "test-fixture-repair-v1/post" / SUBJECT
    before = ref(before_path)
    assert before["sha256"].startswith("d86bb27c") and before["bytes"] == 28541
    original = before_path.read_text()
    head, body, tail = split(original)
    if sys.argv[1] == "edit":
        body = body.replace(
            "        import signal\n",
            "        from datetime import datetime, timezone\n        import signal\n",
            1,
        )
        old = "        for refusal_at in (1, 3):\n"
        assert body.count(old) == 1
        body = body.replace(
            old,
            '        helpers = [\n            next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)\n            for name in ("now", "internal_cohort_failure")\n        ]\n        read_seconds = ast.literal_eval(\n            next(n.value for n in tree.body if isinstance(n, ast.Assign) and any(\n                isinstance(t, ast.Name) and t.id == "CONTROL_READ_SECONDS" for t in n.targets\n            ))\n        )\n\n        def unentered_lifecycle(*args):\n            raise AssertionError("isolated RSS/cancel fixture must not enter CPU/cohort loader")\n\n'
            + old,
        )
        old = "                ExitStack=ExitStack,\n"
        assert body.count(old) == 1
        body = body.replace(
            old,
            old
            + "                datetime=datetime,\n                timezone=timezone,\n                CONTROL_READ_SECONDS=read_seconds,\n                lifecycle_module=unentered_lifecycle,\n                Path=Path,\n",
        )
        old = "ast.Module(body=[parent_command, execute], type_ignores=[])"
        assert body.count(old) == 1
        body = body.replace(
            old, "ast.Module(body=[parent_command, *helpers, execute], type_ignores=[])"
        )
        with (OUT / "scoped.py").open("x") as stream:
            stream.write(textwrap.dedent(body))
        return
    assert sys.argv[1] == "bind"
    post_body = textwrap.indent((OUT / "scoped.py").read_text().rstrip("\n"), "    ")
    if body.endswith("\n"):
        post_body += "\n"
    post = head + post_body + tail
    assert split(post)[::2] == (head, tail)
    ast.parse(post)
    post_path = OUT / "post" / SUBJECT
    post_path.parent.mkdir(parents=True, exist_ok=True)
    with post_path.open("x") as stream:
        stream.write(post)
    post_path.chmod(int(before["mode"], 8))
    for name, a, b in [("forward.patch", original, post), ("inverse.patch", post, original)]:
        with (OUT / name).open("x") as stream:
            stream.writelines(
                difflib.unified_diff(
                    a.splitlines(True),
                    b.splitlines(True),
                    fromfile="a/" + SUBJECT,
                    tofile="b/" + SUBJECT,
                )
            )
    job = OWN / "post-v3/scripts/dev/research-job.py"
    symbols = symtable.symtable(job.read_text(), str(job), "exec")
    helpers = ("execute", "cohort_parent_command", "internal_cohort_failure", "now")
    referenced = {
        name: sorted(global_names(next(c for c in symbols.get_children() if c.get_name() == name)))
        for name in helpers
    }
    parsed = ast.parse(textwrap.dedent(post_body))
    namespace = next(
        n
        for n in ast.walk(parsed)
        if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "namespace" for t in n.targets)
    )
    supplied = {k.arg for k in namespace.value.keywords} | set(helpers) | set(dir(builtins))
    missing = set().union(*(set(v) for v in referenced.values())) - supplied
    assert missing == set(), missing
    save(
        OUT / "binding.json",
        dict(
            issue="quoridor-4lc.324.32",
            status="PRIVATE_TEST_ONLY_UNRUN",
            subject=SUBJECT,
            before=before,
            post=ref(post_path),
            forward=ref(OUT / "forward.patch"),
            inverse=ref(OUT / "inverse.patch"),
            definition=NAME,
            outside_definition_bytes_exact=True,
            global_closure_source=ref(job),
            conservative_referenced_globals=referenced,
            missing_free_globals=[],
            actual_helpers_compiled=[
                "cohort_parent_command",
                "now",
                "internal_cohort_failure",
                "execute",
            ],
            explicit_loader_seam="unexpected lifecycle loader raises AssertionError, never returns permission or resource exemption",
            actual_exercised_paths=[
                "RSS refusal at pre-payload resource check1",
                "RSS refusal at wait resource check3 then exact pidfd TERM/directwait/handles/result+state+notification publication",
                "noncohort internal_cohort_failure short-circuits actual predicate and returns None",
            ],
            tests_run=0,
            original_resource_assertions_and_CPU_isolation="unchanged",
            selectors=["test_lifecycle_arena_cohort_repair.CohortRepairBoundary." + NAME],
        ),
    )


if __name__ == "__main__":
    main()
