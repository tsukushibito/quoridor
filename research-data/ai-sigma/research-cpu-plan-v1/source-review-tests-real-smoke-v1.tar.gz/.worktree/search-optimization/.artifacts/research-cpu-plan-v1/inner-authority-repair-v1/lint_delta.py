"""Keep inherited diagnostics explicit; require no new diagnostic in the sparse test delta."""

import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
SUBJECT = "tools/research-session/test_cohort_control.py"


def inspect(path):
    with subprocess.Popen(
        [
            sys.executable,
            "-m",
            "ruff",
            "check",
            "--no-cache",
            "--config",
            "pyproject.toml",
            "--output-format",
            "json",
            str(path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ) as child:
        stdout, stderr = child.communicate(timeout=20)
        code = child.wait()
    assert code in (0, 1), stderr.decode()
    rows = json.loads(stdout)
    return [{k: v for k, v in row.items() if k not in {"filename"}} for row in rows]


def main():
    before = inspect(OUT / "before" / SUBJECT)
    post = inspect(OUT / "post" / SUBJECT)
    assert before == post, (before, post)
    assert len(post) == 1 and post[0]["code"] == "E731" and post[0]["location"]["row"] == 376
    report = dict(
        status="PASS_NO_NEW_DIAGNOSTIC",
        inherited_unchanged_diagnostics=post,
        scoped_new_errors=0,
        tests_executed=0,
        source_imports=0,
    )
    with (OUT / "scoped-lint.json").open("x") as f:
        json.dump(report, f, indent=2)
        f.write("\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
