if __name__ == "__main__":
    _cpu_smoke_source = {
        "path": "/workspaces/quoridor/.worktree/search-optimization/.artifacts/research-cpu-plan-v1/smoke-fixture-v1/science_fixture.py",
        "sha256": "7a0e48bd10ae4bb1f8c5035e57dfe1fee7cb1e6b4688e05b0a99c3662878b752",
        "bytes": 8801,
        "mode": "0644",
    }
    read_ref(_cpu_smoke_source)
    _cpu_smoke_loader = importlib.util.spec_from_file_location(
        "cpu_smoke_science", _cpu_smoke_source["path"]
    )
    _cpu_smoke_module = importlib.util.module_from_spec(_cpu_smoke_loader)
    _cpu_smoke_loader.loader.exec_module(_cpu_smoke_module)
    _cpu_smoke_module.install(
        globals(),
        {
            "path": "/workspaces/quoridor/.worktree/search-optimization/.artifacts/research-cpu-plan-v1/smoke-fixture-v1/package-binding.json",
            "sha256": "4eb54c25c85a52a11da56b23fe77412d800a642d34a53e25d45b96a15da5c819",
            "bytes": 1836,
            "mode": "0644",
        },
    )
    sys.exit(main())
