"""Root-run, finite NON-scientific normal-job fixture; author must not execute it."""

import argparse
from contextlib import contextmanager
import difflib
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import sys
import tempfile
import time

from assess import assess
from materialize import CASES, case
from science_fixture import ROOT, SCHEMA, definitions, entry_bytes, publish, read, reference

HERE = Path(__file__).resolve().parent
SOURCE = ROOT / "scripts/dev/research-lifecycle.py"
LEASE = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"


def module(name, path):
    loader = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(loader)
    sys.modules[name] = value
    loader.loader.exec_module(value)
    return value


def replace_source(raw, mode):
    """Root-only temporary source write, same-directory atomic replace and fsync."""
    fd, temporary = tempfile.mkstemp(prefix=".cpu-smoke-entry-", dir=SOURCE.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
            os.fchmod(stream.fileno(), mode)
        os.replace(temporary, SOURCE)
        directory = os.open(SOURCE.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if Path(temporary).exists():
            Path(temporary).unlink()


def restore_only(output):
    """Root's explicit crash-cleanup entry; never submit/retry a payload."""
    assert output.resolve() == output and output.is_relative_to(HERE / "runs")
    ledger = read(reference(output / "restoration-obligation.json"))
    before = ledger["restoration_source"]
    assert reference(before["path"]) == before
    with LEASE.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lc = module("cpu_smoke_restore_lc", SOURCE)
        for path in output.glob("**/state.json"):
            state = json.loads(path.read_text())
            assert state["phase"] == "finished", "settle original normal job first; no replay"
            for identity in (
                state.get("supervisor"),
                state.get("child"),
                state.get("launch", {}).get("launcher"),
            ):
                assert identity is None or not lc.process.alive(identity), (
                    "known source user still live"
                )
        current = SOURCE.read_bytes()
        assert lc.sha(current) in {before["sha256"], ledger["instrumented_sha256"]}, (
            "foreign source drift"
        )
        replace_source(Path(before["path"]).read_bytes(), int(before["mode"], 8))
        assert reference(SOURCE) == {**before, "path": str(SOURCE)}
        publish(
            output / "explicit-restoration-return.json",
            dict(
                at=lc.stamp(),
                actual=reference(SOURCE),
                exact_bytes_mode=True,
                normal_jobs_replayed=0,
                source_EX_NB=True,
            ),
        )


@contextmanager
def temporary_entry(lc, package_ref, output, allocation):
    binding = read(read(package_ref)["source_binding"])
    before = allocation["current_lifecycle"]
    assert before["path"] == str(SOURCE)
    original = SOURCE.read_bytes()
    mode = int(before["mode"], 8)
    instrumented = entry_bytes(original, package_ref)
    installed = False
    snapshot = {**before, "path": str(output / "canonical-entry-before.py")}
    publish(
        output / "restoration-obligation.json",
        dict(
            schema=SCHEMA,
            entry=str(SOURCE),
            original=before,
            restoration_source=snapshot,
            package=package_ref,
            instrumented_sha256=lc.sha(instrumented),
            original_mode=f"{mode:04o}",
            purpose="temporary science-only fixture entry, never production testmode",
        ),
    )
    try:
        with lc.lease():  # EX_NB: another maintained source reader/writer refuses installation.
            assert reference(SOURCE) == before and SOURCE.read_bytes() == original
            for row in binding["subjects"]:
                if row["subject"] in {
                    "scripts/dev/research-job.py",
                    "python/quoridor_training/cycle_process.py",
                }:
                    assert reference(ROOT / row["subject"]) == {
                        **row["post"],
                        "path": str(ROOT / row["subject"]),
                    }
            cpu = next(
                p
                for p in binding["protected_correspondence"]
                if p["subject"] == "scripts/dev/research-lifecycle.py"
            )
            old = next(
                p["post"]
                for p in binding["subjects"]
                if p["subject"] == "scripts/dev/research-lifecycle.py"
            )
            assert reference(old["path"]) == old
            fixed_definitions = definitions(Path(old["path"]).read_bytes())
            current_definitions = definitions(original)
            assert all(
                current_definitions[n] == fixed_definitions[n]
                for n in {*cpu["changed"].values(), *cpu["added"]}
            )
            for old in allocation["known_ended_source_users"]:
                assert not lc.process.alive(old), "another exact source user remains active"
            lc.process.compute_peers(
                lc.process.identity(lc.process.process_info(os.getpid())),
                [*allocation["management_cpu_pool"], *allocation["lane_cpu_cores"]],
                {"cargo", "rustc", "cc1plus", "quoridor-runner", "terminal-cache"},
            )
            with Path(snapshot["path"]).open("xb") as stream:
                stream.write(original)
                stream.flush()
                os.fsync(stream.fileno())
                os.fchmod(stream.fileno(), mode)
            assert reference(snapshot["path"]) == snapshot
            for name, left, right in (
                ("entry-forward.patch", original, instrumented),
                ("entry-inverse.patch", instrumented, original),
            ):
                with (output / name).open("x") as stream:
                    stream.writelines(
                        difflib.unified_diff(
                            left.decode().splitlines(True),
                            right.decode().splitlines(True),
                            fromfile="a/scripts/dev/research-lifecycle.py",
                            tofile="b/scripts/dev/research-lifecycle.py",
                        )
                    )
            installed = True
            replace_source(instrumented, mode)
            publish(
                output / "actual-installed.json",
                dict(
                    schema=SCHEMA,
                    actual=reference(SOURCE),
                    source_EX_NB=True,
                    other_source_readers_admitted=False,
                    futurequiet=False,
                ),
            )
        yield
    finally:
        if installed:
            # Coordinator cleanup/directwait precedes leaving this context.
            # Block a second TERM only across the atomic restore, never ignore a stop.
            mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
            try:
                with lc.lease():
                    current = SOURCE.read_bytes()
                    assert current in (original, instrumented), (
                        "foreign entry drift; never overwrite it"
                    )
                    if current != original:
                        replace_source(original, mode)
                    assert (
                        SOURCE.read_bytes() == original
                        and stat.S_IMODE(SOURCE.stat().st_mode) == mode
                    )
                    publish(
                        output / "actual-restored.json",
                        dict(
                            schema=SCHEMA,
                            at=lc.stamp(),
                            exact_bytes=True,
                            exact_mode=True,
                            actual=reference(SOURCE),
                            source_EX_NB=True,
                        ),
                    )
            except BaseException as error:
                publish(
                    output / "RESTORATION-REQUIRED.json",
                    dict(
                        schema=SCHEMA,
                        error=repr(error),
                        obligation=reference(output / "restoration-obligation.json"),
                        no_foreign_overwrite=True,
                    ),
                )
                raise
            finally:
                signal.pthread_sigmask(signal.SIG_SETMASK, mask)


def wait_normal(handles, runtime, job, lc, resource, timeout):
    """Only normal job submit schedules work. This is its owning finite directwait."""
    until = time.monotonic() + timeout
    self_id = lc.process.identity(lc.process.process_info(os.getpid()))
    try:
        for child in handles:
            while True:
                try:
                    child.wait(timeout=0.2)
                    break
                except job.subprocess.TimeoutExpired:
                    resource.check([p for p in lc.process.members(self_id, []) if p != self_id])
                    if time.monotonic() >= until:
                        raise TimeoutError("normal smoke owner deadline; no retry")
    except BaseException:
        if runtime.is_dir():
            job.write(
                runtime,
                "cancel.json",
                dict(requested_at=job.stamp(), reason="fixture owner stopped"),
            )
        try:
            for child in handles:
                child.wait(timeout=60)  # Existing delegated/parent drain, no private scheduler.
        except BaseException:
            # Existing exact-identity helper, only our observed descendants, no host kill.
            owned = [p for p in lc.process.members(self_id, []) if p != self_id]
            job.signal_members(owned, signal.SIGTERM)
            time.sleep(2)
            job.signal_members(owned, signal.SIGKILL)
            for child in handles:
                child.wait(timeout=5)
        raise
    finally:
        for child in handles:
            for name in ("stdin", "stdout", "stderr"):
                stream = getattr(child, name, None)
                if stream is not None:
                    stream.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--allocation", type=Path, help="fresh Root-issued fixture allocation, not a standing grant"
    )
    parser.add_argument(
        "--output", required=True, type=Path, help="new directory under this fixture's runs/"
    )
    parser.add_argument(
        "--restore-only",
        action="store_true",
        help="Root-only exact source restoration after settled crash cleanup, no submit",
    )
    args = parser.parse_args()
    if args.restore_only:
        restore_only(args.output.absolute())
        return
    assert args.allocation is not None
    allocation_ref = reference(args.allocation)
    allocation = read(allocation_ref)
    assert allocation["schema"] == "quoridor.cpu-plan-smoke.allocation.v1"
    assert allocation["goal_issue"] == "quoridor-4lc.324"
    assert (allocation["issue"], allocation["thread_id"]) in {
        ("quoridor-4lc.324.32", "01a11004-79f3-7c20-872c-432a2c347664"),
        ("quoridor-4lc.324", "01a1376a-bfd3-75d2-bd64-61e9416b3b13"),
    }  # Actual normal Beads authority still decides; no reassignment/owner exemption.
    assert allocation["host_reserve_B"] >= 4 * 1024**3 and allocation["GPU"] == 0
    assert len(allocation["management_cpu_pool"]) == len(allocation["lane_cpu_cores"]) == 2
    assert not set(allocation["management_cpu_pool"]).intersection(allocation["lane_cpu_cores"])
    assert 64 * 1024**2 < allocation["lane_family_B"]
    assert 64 * 1024**2 <= allocation["common_family_B"]
    family = allocation["common_family_B"] + 2 * allocation["lane_family_B"]
    assert family <= 4 * 1024**3 and 120 <= allocation["case_timeout_seconds"] <= 300
    output = args.output.absolute()
    assert (
        output.resolve() == output and output.is_relative_to(HERE / "runs") and not output.exists()
    )
    package_ref = reference(HERE / "package-binding.json")
    package = read(package_ref)
    for file_ref in package["files"].values():
        assert reference(file_ref["path"]) == file_ref
    binding = read(package["source_binding"])
    for row in binding["subjects"]:
        if row["subject"] in {
            "scripts/dev/research-job.py",
            "python/quoridor_training/cycle_process.py",
        }:
            assert reference(ROOT / row["subject"]) == {
                **row["post"],
                "path": str(ROOT / row["subject"]),
            }
    assert allocation["current_lifecycle"]["path"] == str(SOURCE)
    with LEASE.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        assert reference(SOURCE) == allocation["current_lifecycle"]
        lc = module("cpu_smoke_canonical_lc", SOURCE)
        job = module("cpu_smoke_canonical_job", ROOT / "scripts/dev/research-job.py")
    assert Path(sys.executable) == lc.project_python()
    plan = lc.process.CPUPlan(
        allocation["management_cpu_pool"], {"lanes": allocation["lane_cpu_cores"]}
    )
    plan.check_host(lc.process.available_cpus())
    assert set(plan.all) <= os.sched_getaffinity(0)
    assert lc.process.available_memory() >= family + allocation["host_reserve_B"]
    output.mkdir(parents=True)
    resource = lc.process.CycleResources(
        dict(max_memory_bytes=family, host_ram_reserve=allocation["host_reserve_B"]), output, None
    )
    contract_ref = publish(
        output / "runtime-contract.json",
        dict(
            schema=SCHEMA,
            output=str(output),
            package=package_ref,
            Root_allocation=allocation_ref,
            current_lifecycle=allocation["current_lifecycle"],
            canonical_before={
                **allocation["current_lifecycle"],
                "path": str(output / "canonical-entry-before.py"),
            },
            actual_available_B=lc.process.available_memory(),
            planned_cpu_roles=plan.record(),
            no_scientific_calls=True,
        ),
    )
    records = []
    active = None
    previous = {}

    def cancel(signum, frame):
        if active is not None and active.is_dir():
            job.write(active, "cancel.json", dict(requested_at=job.stamp(), signal=signum))
        raise KeyboardInterrupt("fixture coordinator cancelled")

    try:
        for sig in (signal.SIGTERM, signal.SIGINT):
            previous[sig] = signal.signal(sig, cancel)
        with temporary_entry(lc, package_ref, output, allocation):
            backend = job.runtime.AppBackend(ROOT)  # Actual Beads authority; never synthetic.
            for label in CASES:
                fixture = case(output / label, label, allocation, contract_ref, lc)
                publish(Path(fixture["root"]) / "fixture.json", fixture)
                handles, submit_error = [], None
                active = Path(fixture["runtime"])
                try:
                    accepted = job.submit(
                        Path(fixture["parent_config"]["path"]),
                        active,
                        ROOT,
                        backend,
                        supervisor_handles=handles,
                    )
                    publish(
                        Path(fixture["root"]) / "actual-submit.json",
                        dict(accepted=accepted, native_or_payload_START="not inferred from RPC"),
                    )
                except Exception as error:
                    submit_error = str(error)
                    publish(
                        Path(fixture["root"]) / "actual-submit-refusal.json",
                        dict(type=type(error).__name__, error=submit_error),
                    )
                finally:
                    wait_normal(
                        handles, active, job, lc, resource, allocation["case_timeout_seconds"] + 60
                    )
                value = assess(fixture, allocation, lc, submit_error)
                publish(Path(fixture["root"]) / "assessment.json", value)
                records.append(value)
                active = None
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
        publish(
            output / "coordinator-return.json",
            dict(
                schema=SCHEMA,
                records=records,
                all_cases=len(records) == len(CASES),
                restored=(output / "actual-restored.json").exists(),
                full_normal_parallel_PASS=len(records) == len(CASES)
                and all(r["qualification"] == "PASS" for r in records),
                Search_model_arena_RNG=0,
                no_retry=True,
            ),
        )
    assert len(records) == len(CASES) and all(r["qualification"] == "PASS" for r in records), (
        "inspect real cases/progress defects; no mocked or subset parallel qualification"
    )


if __name__ == "__main__":
    main()
