"""Return the two unrun fixture overrides before continuing separate real-smoke work."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

OWN = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OWN))
from intake import ROOT, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def main():
    guard_path = OWN / "test-fixture-repair-guard-v1/result.json"
    guard = json.loads(guard_path.read_text())
    assert guard["status"] == "PASS" and guard["TMP_remaining"] == []
    fresh = []
    for old in [guard["controller"], *[r["guardian_return"]["child"] for r in guard["checks"]]]:
        info = process.process_info(old["pid"])
        current = process.identity(info) if info else None
        assert current != old
        fresh.append(dict(original=old, current=current, absent_or_different=True))
    allocated = sum(p.lstat().st_blocks * 512 for p in [OUT, *OUT.rglob("*")])
    stop = save(
        OUT / "source-helper-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            actual_source_guard=ref(guard_path),
            reader_STOP=guard["reader_STOP"],
            fresh_known_ids=fresh,
            remaining=[],
            TMP=[],
            source_leases=[],
            Main_reader=False,
            directwait_reap_handles=True,
            CPU=2,
            guardian18=True,
            family_B=1073741824,
            controller_included_B=67108864,
            hostreserve_B=4294967296,
            GPU=0,
            new_subtree_affected_B=allocated,
            tests_smoke_native_Search_model_RNG=0,
            futurequiet=False,
            current_light_delivery_separate=True,
        ),
    )
    body = OUT / "Root-handoff.txt"
    body.write_text(
        "SAME32 causal TEST-ONLY2definition override, fixed62d5 source+SOURCE_CLEAR unchanged. No production/cpu/resource/reader changes, tests0.\n"
        "Arena cleanpositive local counters now include actual safeRace enabled=True/requested path_tail/typed methodID zero-stock431-one-path-tail-E-two-keys-v1 (immutable22d23276 native id), preserving all original negatives/assertions. AST-isolated RSS/cancel test now compiles actual current cohort_parent_command alongside actual execute, not constantFalse; original CPU None/False stub remains explicitly non-CPU qualification. Outside the two named definitions all bytes exact. ScopedRuffformat100/lint/parser PASS; no GNU/oldproof/test replay.\n"
        "Root runs ONLY these2 failed selectors; 11PASS retained. This packet is separate from immutable8source and ongoing executable realfixture, which continues next. HelperSTOP04:18:38.079227Z, freshknownIDs absent/different, directreap/handles/TMP/leases[], CPU2/G18/F1GiBincl64/host4/G0. No Main/Git/docs/Cargo write or reviewdispatch/selfclear.\n"
        + json.dumps(
            dict(
                binding=ref(OUT / "binding.json"),
                source_STOP=stop,
                delivery_guard=str(OWN / "test-fixture-repair-delivery-guard-v1/result.json"),
            ),
            indent=2,
        )
        + "\n"
    )
    argv = [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--cwd",
        str(ROOT),
        "--body-file",
        str(body),
    ]
    with subprocess.Popen(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE) as child:
        out, err = child.communicate(timeout=60)
        code = child.wait()
    receipt = dict(
        exit_code=code,
        stdout=out.decode(),
        stderr=err.decode(),
        directwait_reaped=True,
        handles_closed=child.stdout.closed and child.stderr.closed,
    )
    save(OUT / "Root-delivery.json", receipt)
    assert code == 0, receipt
    print(json.dumps(dict(binding=ref(OUT / "binding.json"), STOP=stop)))


if __name__ == "__main__":
    main()
