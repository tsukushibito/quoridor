"""Finish rejected-race handoff and own administration without repeating source work."""

import fcntl
import json
import os
from pathlib import Path

from deliver import run
from intake import save

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")


def main():
    save(
        OUT / "Root-delivery-original-refusal.json",
        dict(
            status="NOT_DELIVERED",
            original_guard=str(OUT.parent / "configured-progress-delivery-guard-v1/result.json"),
            exact_reason="research-session: turn/steer: {'code': -32600, 'message': 'no active turn to steer'}",
            source_packet_reexecuted=False,
        ),
    )
    save(
        OUT / "Root-delivery-v2.json",
        run(
            [
                "bash",
                "scripts/dev/research-session.sh",
                "send",
                "--thread",
                "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                "--issue",
                "quoridor-4lc.324",
                "--cwd",
                str(ROOT),
                "--body-file",
                str(OUT / "Root-fixed-handoff.txt"),
            ]
        ),
    )
    show = run(["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.324.32", "--json"])
    issue = json.loads(show["stdout"])
    issue = issue[0] if isinstance(issue, list) else issue
    assert (
        issue["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
        and issue["status"] == "in_progress"
    )
    save(OUT / "beads-show.json", show)
    save(
        OUT / "beads-note.json",
        run(
            [
                "bash",
                "scripts/dev/beads.sh",
                "update",
                "quoridor-4lc.324.32",
                "--append-notes",
                "Configured-data-owner sparse repair: only arena_cohort_progress derives slot counts from bound positive-int config.games and actual RUN sum, preserving native missing UNKNOWN and all CPU/authority/control predicates. One new small heterogeneous/missingcensus/refusal regression UNRUN; old R3 fixture adds explicit games32 only. Fixturev2 adds synthetic games1 only, 4other executable owners exact. Scopedformat/lint/parser PASS, author tests/smoke/Main0, sourcehelper STOP04:42:07.715164Z/directwait-reap/handles/TMPleases[]/freshIDs. Original62d5/b3ae/finding immutable. Packet "
                + str(OUT / "handoff.json"),
            ]
        ),
    )
    save(
        OUT / "beads-backup.json", run(["bash", "scripts/dev/beads.sh", "backup", "sync", "--json"])
    )
    removed = []
    for path in Path(os.environ["TMPDIR"]).iterdir():
        assert (
            path.is_file()
            and path.stat().st_size == 0
            and path.name.startswith("uv-")
            and path.name.endswith(".lock")
        )
        with path.open("rb") as f:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            path.unlink()
        removed.append(str(path))
    save(OUT / "delivery-TMP-cleanup.json", dict(removed=removed))
    print(json.dumps(dict(handoff=str(OUT / "handoff.json"), delivered=True)))


if __name__ == "__main__":
    main()
