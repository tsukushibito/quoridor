"""Temporary synthetic DATA owner. No replacement of normal control or finalization."""

import ast
import atexit
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

SCHEMA = "quoridor.cpu-plan-smoke.synthetic.v1"
ROOT = Path("/workspaces/quoridor")


def reference(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def read(reference_value):
    assert reference(reference_value["path"]) == reference_value
    return json.loads(Path(reference_value["path"]).read_text())


def publish(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    return reference(path)


def canonical(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def definitions(raw):
    """Exact all-function/class bytes, including control function defaults."""
    lines = raw.splitlines(keepends=True)
    return {
        node.name: b"".join(lines[node.lineno - 1 : node.end_lineno])
        for node in ast.parse(raw).body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
    }


def entry_bytes(original, package_ref):
    package = read(package_ref)
    source = package["files"]["science_fixture.py"]
    tail = b'if __name__ == "__main__":\n    sys.exit(main())\n'
    assert original.endswith(tail) and original.count(tail) == 1
    # No environment selector, alternate argv, production schema or control hook.
    source_lines = json.dumps(source, indent=4).splitlines()
    source_lines[-2] += ","
    source_literal = "\n".join(source_lines).replace("\n", "\n    ")
    package_lines = json.dumps(package_ref, indent=4).splitlines()
    package_lines[-2] += ","
    package_literal = "\n".join(package_lines).replace("\n", "\n        ")
    insert = (
        'if __name__ == "__main__":\n'
        f"    _cpu_smoke_source = {source_literal}\n"
        "    read_ref(_cpu_smoke_source)\n"
        "    _cpu_smoke_loader = importlib.util.spec_from_file_location(\n"
        '        "cpu_smoke_science", _cpu_smoke_source["path"]\n'
        "    )\n"
        "    _cpu_smoke_module = importlib.util.module_from_spec(_cpu_smoke_loader)\n"
        "    _cpu_smoke_loader.loader.exec_module(_cpu_smoke_module)\n"
        "    _cpu_smoke_module.install(\n"
        "        globals(),\n"
        f"        {package_literal},\n"
        "    )\n"
        "    sys.exit(main())\n"
    ).encode()
    result = original[: -len(tail)] + insert
    assert definitions(original) == definitions(result)
    return result


def install(g, package_ref):
    """Called only by the temporary canonical __main__, never by job's LC import."""
    package = read(package_ref)
    for file_ref in package["files"].values():
        assert reference(file_ref["path"]) == file_ref
    argv = sys.argv
    if argv[1] == "finalize":
        assert len(argv) in {8, 12} and argv[2] == "--operation"
        directory = Path(argv[3])
        origin = g["document"](
            g["bound"](
                directory
                / ("candidate.json" if (directory / "candidate.json").exists() else "INCOMPLETE")
            )[0]
        )
        intent_ref = origin["intent"]
    else:
        assert len(argv) == 6 and argv[2] == "--intent" and argv[4] == "--sha256"
        intent_ref = g["bound"](Path(argv[3]))[0]
        assert intent_ref["sha256"] == argv[5]
    intent = g["document"](intent_ref)
    marker = intent["synthetic_cpu_smoke"]
    assert marker["schema"] == SCHEMA
    contract = read(marker["contract"])
    assert contract["schema"] == SCHEMA and contract["package"] == package_ref
    root = Path(contract["output"])
    assert root.is_relative_to(Path(__file__).parent / "runs")
    assert Path(intent_ref["path"]).is_relative_to(root)
    original = contract["canonical_before"]
    assert reference(original["path"]) == original
    assert all(original[k] == contract["current_lifecycle"][k] for k in ("sha256", "bytes", "mode"))
    before = Path(original["path"]).read_bytes()
    assert Path(g["__file__"]).read_bytes() == entry_bytes(before, package_ref)
    events = Path(marker["events"])
    assert events.is_relative_to(root)
    events.mkdir(parents=True, exist_ok=True)
    stream = (events / f"{os.getpid()}.jsonl").open("x", buffering=1)
    count = 0

    def snapshot(stage):
        nonlocal count
        count += 1
        assert count <= 128, "bounded test observer, not a production telemetry route"
        value = dict(
            synthetic=SCHEMA,
            stage=stage,
            at=datetime.now(timezone.utc).isoformat(),
            monotonic=time.monotonic(),
            identity=g["process"].identity(g["process"].process_info(os.getpid())),
            parent=os.getppid(),
            mask=sorted(os.sched_getaffinity(0)),
            threads={
                p.name: sorted(os.sched_getaffinity(int(p.name)))
                for p in Path("/proc/self/task").iterdir()
            },
        )
        stream.write(json.dumps(value) + "\n")
        stream.flush()
        return value

    def checked(spec):
        assert spec["synthetic_cpu_smoke"]["schema"] == SCHEMA
        assert spec["synthetic_cpu_smoke"]["contract"] == marker["contract"]
        assert Path(spec["owner"]).is_relative_to(root)
        experiment = g["document"](spec["experiment"])
        assert experiment["synthetic_cpu_smoke"] == spec["synthetic_cpu_smoke"]
        assert experiment["schema"] == SCHEMA  # Explicitly NOT a scientific Experiment/BUILD.
        owner = read(experiment["build_manifest"])
        assert owner["schema"] == SCHEMA and owner["not_a_qualified_build"] is True
        assert owner["artifact"] == spec["artifact"]
        assert reference(spec["artifact"]["path"]) == spec["artifact"]
        for source_ref in spec["caller_sources"]:
            assert reference(source_ref["path"]) == source_ref
        return experiment, owner

    def prepare(settings_ref, kind, index):
        settings = g["document"](settings_ref)
        assert kind == "run" and settings["synthetic_cpu_smoke"]["contract"] == marker["contract"]
        snapshot("parent_prepare" if index == 0 else "next_operation_prepare")
        spec = json.loads(json.dumps(settings["runs"][index]))
        phase = Path(settings["output"]) / f"run-{index:03d}"
        assert not phase.exists()
        phase.mkdir()
        spec.update(settings=settings_ref, selection_index=index)
        if settings.get("arena_cohort") is not None:
            spec["arena_cohort"] = settings["arena_cohort"]
        spec["intent_sha256"] = canonical(spec)
        return publish(phase / "intent.json", spec)

    def experiment_check(spec):
        snapshot("synthetic_science_check")
        experiment, owner = checked(spec)
        return (
            experiment,
            owner,
            [spec["experiment"], experiment["config"], spec["artifact"], *spec["caller_sources"]],
        )

    def collect_data(spec, experiment):
        snapshot("synthetic_collect_actual_mask_file")
        assert checked(spec)[0] == experiment
        path = Path(spec["data_root"]) / "mask.json"
        data = json.loads(path.read_text())
        assert data["synthetic"] == SCHEMA and data["operation"] == experiment["batch"]
        assert data["launch_mask"] == spec["child_cpu_cores"]
        return dict(status="PASS", errors=[], files=[g["bound"](path)[0]], synthetic=SCHEMA)

    # These are the ONLY science substitutions. All control callables stay actual.
    g["experiment_check"] = experiment_check
    g["collect_data"] = collect_data
    g["sequence"].__kwdefaults__["prepare"] = prepare

    # Read-only test observations, no wrapper/replacement of finalize or controls.
    assert sys.getprofile() is None
    watched = {"finalize", "_prepare_completion", "sequence", "cohort_sequence", "execute"}

    def observe(frame, event, arg):
        if (
            event in {"call", "return"}
            and frame.f_code.co_filename == g["__file__"]
            and frame.f_code.co_name in watched
        ):
            snapshot(frame.f_code.co_name + ":" + event)

    sys.setprofile(observe)
    snapshot("fresh_canonical_child_entry")

    def close_observer():
        sys.setprofile(None)
        stream.flush()
        os.fsync(stream.fileno())
        stream.close()

    atexit.register(close_observer)
