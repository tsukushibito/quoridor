def cohort_job_authority(config, directory=None):
    """Only registered normal jobs inherit control from their assigned live parent."""
    delegated = config["authority_parent"]
    require(set(delegated) == {"cohort", "lane"}, "exact delegated cohort/member declaration")
    cohort_ref, lane = delegated["cohort"], delegated["lane"]
    binding = cohort_parent_binding(cohort_ref)
    cohort = document(cohort_ref)
    require(type(lane) is int and 0 <= lane < len(cohort["members"]), "declared lane index")
    member = cohort["members"][lane]
    launch = document(bound(Path(cohort["control_root"]) / "launch.json")[0])
    declared = document(launch["job_configs"][lane])
    require(
        launch["cohort"] == cohort_ref
        and declared.get("authority_parent") == delegated
        and config["issue"] == declared["issue"] == cohort["issue"]
        and config["thread_id"] == declared["thread_id"] == cohort["thread_id"]
        and config["goal_issue"] == declared["goal_issue"],
        "assigned member and issue/thread roster",
    )
    own = process.identity(process.process_info(os.getpid()))
    if own == binding["origin"]["child"]:
        require(
            config == declared and (directory is None or str(directory) == member["job_runtime"]),
            "parent submits only its declared normal lane job",
        )
    else:
        runtime = Path(member["job_runtime"])
        state = json.loads(bound(runtime / "state.json")[1])
        registered = state["launch"]
        require(
            registered["owner"] == binding["origin"]["child"]
            and registered["supervisor"] == state["supervisor"]
            and registered["job_id"] == state["job_id"]
            and registered["config_sha256"] == state["config_sha256"],
            "normal submit registered this actual supervisor/job to its owner",
        )
        binding["launchers"].append(registered["launcher"])
        require(
            process.alive(registered["launcher"]), "assigned lane environment-reader launcher lost"
        )
        if own == state["supervisor"]:
            require(
                config == declared and (directory is None or Path(directory) == runtime),
                "registered supervisor executes its own declared lane",
            )
        else:
            sequence = state.get("child")
            require(state["phase"] == "running", "registered running lane sequence required")
            if config == declared:
                require(
                    own == sequence,
                    "inner operation caller is the registered running lane sequence",
                )
            if config != declared:
                # The sequence contract stays settings; the selected RUN spec is
                # the maintained --intent argument, as in sequence's child_config.
                require(
                    isinstance(config["argv"], list)
                    and len(config["argv"]) == 8
                    and config["argv"][:5]
                    == [
                        sys.executable,
                        "-B",
                        str(ROOT / "scripts/dev/research-lifecycle.py"),
                        "run",
                        "--intent",
                    ]
                    and config["argv"][6] == "--sha256",
                    "inner operation uses the canonical registered run caller",
                )
                settings_ref = bound(Path(member["settings_path"]))[0]
                intent_ref = bound(Path(config["argv"][5]))[0]
                intent = document(intent_ref)
                index = intent["selection_index"]
                require(
                    config["resource_contract"] == settings_ref["path"]
                    and intent_ref["sha256"] == config["argv"][7]
                    and intent["kind"] == "run"
                    and intent["arena_cohort"] == cohort_ref
                    and intent["settings"] == settings_ref
                    and type(index) is int
                    and 0 <= index < len(document(settings_ref)["runs"]),
                    "inner normal admission belongs to assigned selected RUN",
                )
                selected = Path(member["output"]) / f"run-{index:03d}"
                require(
                    intent_ref["path"] == str(selected / "intent.json"),
                    "inner intent is the maintained selected operation",
                )
                inner_runtime = selected / "runtime"
                inner = json.loads(bound(inner_runtime / "state.json")[1])
                require(
                    (directory is None or Path(directory) == inner_runtime)
                    and inner["supervisor"] == sequence
                    and inner["config_sha256"] == sha(json.dumps(config, sort_keys=True).encode()),
                    "assigned inner originating job",
                )
                if own != sequence:
                    # The command child is distinct from the sequence that
                    # executes its normal job. Admit only that registered child,
                    # never an arbitrary descendant or an environment claim.
                    require(
                        directory is not None
                        and Path(directory) == inner_runtime
                        and document(bound(runtime / "config.json")[0]) == declared
                        and state["config_sha256"]
                        == sha(json.dumps(declared, sort_keys=True).encode())
                        and document(bound(inner_runtime / "config.json")[0]) == config
                        and inner["issue"] == config["issue"]
                        and inner["thread_id"] == config["thread_id"]
                        and inner["phase"] == "running"
                        and inner.get("child") == own
                        and sequence is not None
                        and process.alive(sequence)
                        and process.alive(state["supervisor"])
                        and process.alive(own)
                        and process.process_info(sequence["pid"])["parent"]
                        == state["supervisor"]["pid"]
                        and process.process_info(own["pid"])["parent"] == sequence["pid"]
                        and not (runtime / "cancel.json").exists()
                        and not (inner_runtime / "cancel.json").exists(),
                        "registered inner child/config/live ancestry and uncancelled lane",
                    )
    binding["delegated_config_sha256"] = canonical_sha(config)
    binding["delegated_lane"] = lane
    return binding
