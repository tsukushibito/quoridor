"""Keep the original unissued lint failure; freeze only the unused-import correction."""

import ast
import difflib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent))
from intake import ref, save  # noqa: E402


def main():
    old = json.loads((OUT / "binding.json").read_text())
    original = OUT / "post/tools/research-session/test_exception_cleanup_outcome.py"
    final = OUT / "final-post/tools/research-session/test_exception_cleanup_outcome.py"
    final.parent.mkdir(parents=True, exist_ok=True)
    raw = original.read_text()
    assert raw.count("import json\n") == 1
    with final.open("x") as f:
        f.write(raw.replace("import json\n", "", 1))
    ast.parse(final.read_text())
    rows = [{**r} for r in old["subjects"]]
    rows[-1] = {**rows[-1], "post": ref(final)}
    for direction in ["forward", "inverse"]:
        with (OUT / (direction + "-final.patch")).open("x") as f:
            for row in rows:
                a = Path(row["before"]["path"]).read_text() if row["before"] else ""
                b = Path(row["post"]["path"]).read_text()
                left, right = (a, b) if direction == "forward" else (b, a)
                f.writelines(
                    difflib.unified_diff(
                        left.splitlines(True),
                        right.splitlines(True),
                        fromfile="a/" + row["subject"] if left else "/dev/null",
                        tofile="b/" + row["subject"] if right else "/dev/null",
                    )
                )
    old.update(
        subjects=rows,
        forward=ref(OUT / "forward-final.patch"),
        inverse=ref(OUT / "inverse-final.patch"),
        unissued_lint_failure_preserved=ref(OUT / "binding.json"),
        only_typing_suffix="remove unused json import from new test definition; production pair unchanged",
    )
    binding = save(OUT / "final-binding.json", old)
    print(json.dumps(binding))


if __name__ == "__main__":
    main()
