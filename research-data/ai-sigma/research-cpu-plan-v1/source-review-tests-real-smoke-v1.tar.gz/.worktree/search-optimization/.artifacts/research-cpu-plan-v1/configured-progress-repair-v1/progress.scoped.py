def arena_cohort_progress(spec):
    """One natural snapshot, including pre-inner refusals and retained native facts."""
    selected = arena_cohort(spec)
    if selected is None:
        return
    cohort, _ = selected
    control = Path(cohort["control_root"])
    packet_path = control / "first-progress.json"
    if packet_path.exists():
        return
    lifetime = arena_cohort_lifetime(spec)
    lanes = []
    planned_games = 0
    for member in cohort["members"]:
        output = Path(member["output"])
        settings_ref = bound(member["settings_path"])[0]
        settings = document(settings_ref)
        configs = [document(document(run["experiment"])["config"]) for run in settings["runs"]]
        require(
            all(type(config.get("games")) is int and config["games"] > 0 for config in configs),
            "configured positive-int games per operation",
        )
        planned_games += sum(config["games"] for config in configs)
        terminal = None
        if (output / "result.json").exists():
            terminal_ref = bound(output / "result.json")[0]
            terminal = document(terminal_ref)
            require(
                terminal["settings"] == settings_ref
                and terminal["originating_job"] == lifetime["origins"].get(member["lane"]),
                "terminal lane result joins its actual declared original submission",
            )
        first = output / "run-000"
        settled = (first / "operation/manifest.json").exists() and not (
            first / "operation/INCOMPLETE"
        ).exists()
        inner = first / "runtime/result.json"
        inner_failed = False
        if inner.exists():
            result = document(bound(inner)[0])
            settled |= result.get("cleanup_complete") is True
            inner_failed = result["outcome"] != "succeeded"
        outer = Path(member["job_runtime"]) / "result.json"
        outer_failure = None
        if outer.exists():
            original_state = json.loads(bound(Path(member["job_runtime"]) / "state.json")[1])
            outer_result = document(bound(outer)[0])
            require(
                original_state["job_id"] == outer_result["job_id"],
                "outer terminal result joins its original runtime/job_id",
            )
            if outer_result["outcome"] != "succeeded" and outer_result.get("cleanup_complete"):
                outer_failure = bound(outer)[0]
        failed = (
            inner_failed
            or (terminal is not None and terminal["status"] != "PASS")
            or outer_failure is not None
        )
        if not (settled or failed):
            return
        lanes.append(
            dict(
                member=member,
                settings=settings,
                configs=configs,
                terminal=terminal,
                terminal_ref=terminal_ref if terminal is not None else None,
                outer_failure=outer_failure,
                initial_failed=bool(failed),
            )
        )
    with (control / "progress.lock").open("a") as progress_lock:
        fcntl.flock(progress_lock, fcntl.LOCK_EX)
        if packet_path.exists():
            return
        counts = dict(
            planned_games=planned_games,
            terminal_planned_games=0,
            inflight_slots=0,
            unentered_slots=0,
            native_started_games_known=0,
            completed_games_known=0,
            unknown_games_known=0,
            retained_games_known=0,
            retained_count_unknown_slots=0,
            terminal_native_census_unknown_slots=0,
            complete_pairs_known=0,
        )
        evidence, pairs, initial_failures = [], [], []
        for lane in lanes:
            member = lane["member"]
            if lane["initial_failed"]:
                initial_failures.append(
                    dict(
                        lane=member["lane"],
                        terminal=lane["terminal_ref"],
                        outer_failure=lane["outer_failure"],
                    )
                )
            for index, config in enumerate(lane["configs"]):
                games = config["games"]
                phase = Path(member["output"]) / f"run-{index:03d}"
                operation = phase / "operation"
                manifest_path = operation / "manifest.json"
                inner_path = phase / "runtime/result.json"
                manifest = None
                if manifest_path.exists() and not (operation / "INCOMPLETE").exists():
                    manifest = document(bound(manifest_path)[0])
                inner_result = document(bound(inner_path)[0]) if inner_path.exists() else None
                terminal = manifest is not None or (
                    inner_result is not None and inner_result.get("cleanup_complete") is True
                )
                lane_terminal = lane["terminal"] is not None or lane["outer_failure"] is not None
                publication_path = Path(config["output"]) / "result.json"
                native_owned = operation.exists()
                if terminal and not native_owned:
                    counts["unentered_slots"] += games
                elif terminal or (lane_terminal and native_owned):
                    counts["terminal_planned_games"] += games
                    if publication_path.exists():
                        publication_ref = bound(publication_path)[0]
                        publication = document(publication_ref)
                        native = publication["report"]
                        summary = native["arena_summary"]
                        census = summary["census"]
                        require(
                            native["run_id"] == config["run_id"]
                            and native["planned"] == census["planned_games"] == games
                            and 0 <= publication["outcome_count"] <= games,
                            "actual saved local native census/config and retained outcomes",
                        )
                        counts["native_started_games_known"] += census["started_games"]
                        counts["completed_games_known"] += census["completed_games"]
                        counts["unknown_games_known"] += census["unknown_games"]
                        counts["retained_games_known"] += publication["outcome_count"]
                        counts["complete_pairs_known"] += census["complete_pairs"]
                        require(
                            len(summary["pairs"]) == census["complete_pairs"],
                            "actual complete pairs",
                        )
                        openings = config["arena"]["book"]["openings"]
                        for pair in summary["pairs"]:
                            joined = [o for o in openings if o["lineage"] == pair["lineage"]]
                            require(len(joined) == 1, "complete pair joins exact family lineage")
                            source = joined[0]["reference"]["settings"]
                            pairs.append(
                                dict(
                                    lane=member["lane"],
                                    operation=index,
                                    family_id=source["family_id"],
                                    request_id=joined[0]["id"],
                                    canonical_family=source["canonical_family"],
                                    candidate_colors=[0, 1],
                                    native_family=pair["family"],
                                    lineage=pair["lineage"],
                                    publication=publication_ref,
                                )
                            )
                        evidence.append(
                            dict(
                                lane=member["lane"],
                                operation=index,
                                publication=publication_ref,
                                manifest=bound(manifest_path)[0] if manifest is not None else None,
                                inner_result=bound(inner_path)[0]
                                if inner_result is not None
                                else None,
                            )
                        )
                    else:
                        counts["terminal_native_census_unknown_slots"] += games
                        counts["retained_count_unknown_slots"] += games
                elif lane_terminal:
                    # No operation ownership marker and no inner job means no native entry.
                    counts["unentered_slots"] += games
                elif phase.exists():
                    counts["inflight_slots"] += games
                else:
                    counts["unentered_slots"] += games
        require(
            counts["terminal_planned_games"] + counts["inflight_slots"] + counts["unentered_slots"]
            == planned_games,
            "disjoint terminal/inflight/unentered planned slot domains",
        )
        counts["scientific_outcome_UNKNOWN_slots"] = planned_games - counts["completed_games_known"]
        elapsed = time.monotonic() - lifetime["clock"]
        require(elapsed > 0, "actual common launch-to-pre-publication snapshot clock")
        pair_path = control / "first-progress-pairs.json"
        require(
            len(json.dumps(pairs).encode()) <= CONTROL_BYTES, "bounded lossless pair identity facts"
        )
        new_json(pair_path, pairs)
        evidence_path = control / "first-progress-retained.json"
        require(
            len(json.dumps(evidence).encode()) <= CONTROL_BYTES, "bounded lossless retained facts"
        )
        new_json(evidence_path, evidence)
        now = datetime.now(timezone.utc)
        packet = dict(
            cohort=spec["arena_cohort"],
            at=now.isoformat(),
            at_JST=now.astimezone(timezone(timedelta(hours=9))).isoformat(),
            counts=counts,
            overall_target=planned_games,
            launch_to_pre_publication_snapshot_seconds=elapsed,
            clock_endpoint="Snapshot before packet/body/sender publication; no publication-complete clock claimed",
            completed_games_per_second=counts["completed_games_known"] / elapsed,
            conditional_remaining_seconds=(planned_games - counts["terminal_planned_games"])
            * elapsed
            / counts["completed_games_known"]
            if counts["completed_games_known"] > 0 and not initial_failures
            else None,
            initial_lane_failures=initial_failures,
            retained_publications=bound(evidence_path)[0],
            complete_pair_identities=bound(pair_path)[0],
            UNKNOWN_scope="Future/inflight/unentered and missing terminal native facts are separate; retained unknown counts are never fabricated0",
            condition="Same observed composition/contention/holding only; no ideal3x, CI, strength, refill or replay",
            overlapping_lane_native_spans_summed=False,
        )
        require(len(json.dumps(packet).encode()) <= 65536, "small first cohort packet")
        new_json(packet_path, packet)
    body = control / "first-progress.txt"
    body.write_text(
        "First natural configured-lane snapshot: " + json.dumps(bound(packet_path)[0]) + "\n"
    )
    capture = Capture(control / "first-progress-notification.full.log", 65536)
    returned = primary = None
    secondary = []
    try:
        resources = ArenaCohortResources(spec)
        returned = process.execute(
            [
                "bash",
                str(ROOT / "scripts/dev/research-session.sh"),
                "send",
                "--thread",
                cohort["notify"]["thread_id"],
                "--issue",
                cohort["notify"]["issue"],
                "--body-file",
                str(body),
            ],
            control / "first-progress-notification.log",
            time.monotonic() + 30,
            cpu_core=cohort["global_controller_cpu"],
            resources=resources,
            cwd=spec["cwd"],
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
            output_sink=capture,
            no_new_privs=True,
        )
        settled(returned)
    except BaseException as error:
        primary = error
    finally:
        try:
            capture.close()
        except BaseException as error:
            secondary.append(error)
        try:
            new_json(
                control / "first-progress-notification.json",
                dict(
                    returned=returned,
                    failure=error_fact(primary) if primary is not None else None,
                    secondary=[error_fact(e) for e in secondary],
                    one_shot=True,
                    producer_ack_required=False,
                ),
            )
        except BaseException as error:
            raise BaseExceptionGroup(
                "first progress notification publication",
                [*([primary] if primary is not None else []), *secondary, error],
            )
    if (
        primary is not None
        and isinstance(primary, process.CycleStopped)
        and any(k in str(primary) for k in ("signal", "pause"))
    ):
        raise primary
