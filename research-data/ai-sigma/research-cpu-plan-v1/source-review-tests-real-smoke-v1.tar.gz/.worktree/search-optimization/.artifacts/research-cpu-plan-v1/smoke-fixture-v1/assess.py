"""Assess actual normal receipts and test-only masks; never manufacture qualification."""

import json
from pathlib import Path

from science_fixture import read, reference


def assess(case, allocation, lc, submit_error=None):
    root = Path(case["root"])
    negative = case["label"].startswith("bad_")
    masks, events, identities, receipts, progress_errors = [], [], [], [], []
    for member in case["members"]:
        for local in range(2):
            phase = Path(member["output"]) / f"run-{local:03d}"
            path = phase / "mask-data/mask.json"
            if path.exists():
                mask = json.loads(path.read_text())
                assert mask["launch_mask"] == sorted({member["main_cpu"], member["AI_workers"][0]})
                assert mask["worker_mask"] == [member["AI_workers"][0]]
                masks.append(mask)
                identities.append(mask["identity"])
                leaf = phase / "mask-data/failure-descendant.json"
                if leaf.exists():
                    identities.append(json.loads(leaf.read_text())["identity"])
        for path in (Path(member["settings_path"]).parent / "events").glob("*.jsonl"):
            for line in path.read_text().splitlines():
                event = json.loads(line)
                assert set(event["mask"]) <= set(allocation["management_cpu_pool"]), event
                assert all(
                    set(v) <= set(allocation["management_cpu_pool"])
                    for v in event["threads"].values()
                ), event
                if event["stage"] in {
                    "parent_prepare",
                    "next_operation_prepare",
                    "sequence:return",
                }:
                    assert event["mask"] == sorted(allocation["management_cpu_pool"]), event
                if event["stage"] == "_prepare_completion:call":
                    assert event["mask"] == [member["main_cpu"]], event
                events.append(event)
                identities.append(event["identity"])
        terminal = Path(member["output"]) / "result.json"
        if terminal.exists():
            value = json.loads(terminal.read_text())
            progress_errors.extend(value.get("progress_errors", []))
    runtimes = [Path(case["runtime"])]
    if "cohort" in case:
        runtimes += [Path(m["job_runtime"]) for m in case["members"]]
    runtimes += [
        Path(m["output"]) / f"run-{local:03d}/runtime"
        for m in case["members"]
        for local in range(2)
    ]
    for runtime in runtimes:
        state_path = runtime / "state.json"
        if not state_path.exists():
            continue
        state = json.loads(state_path.read_text())
        for field in ("supervisor", "child"):
            if state.get(field):
                identities.append(state[field])
        for field in ("launcher", "supervisor"):
            value = state.get("launch", {}).get(field)
            if isinstance(value, dict) and {"pid", "start_ticks", "boot_id"} <= value.keys():
                identities.append(value)
        result = read(reference(runtime / "result.json"))
        assert result["cleanup_complete"] is True and result.get("remaining", []) == [], result
        if state.get("child"):
            assert result["direct_child_reaped"] is True, result
        receipts.append(reference(runtime / "result.json"))
    remaining = [p for p in identities if lc.process.alive(p)]
    assert not remaining, remaining
    tmp_remaining = [
        str(Path(m["output"]) / f"run-{local:03d}/TMP")
        for m in case["members"]
        for local in range(2)
        if (Path(m["output"]) / f"run-{local:03d}/TMP").exists()
    ]
    if negative:
        expected = {
            "bad_unavailable": ("assigned CPUs unavailable",),
            "bad_smt": ("physical/SMT",),
            "bad_overlap": ("cannot overlap", "explicit search CPUs"),
        }[case["label"]]
        assert (
            submit_error
            and any(message in submit_error for message in expected)
            and not masks
            and not (Path(case["runtime"]) / "state.json").exists()
        )
    elif case["label"] in {"outside_thread", "child_failure", "parent_cancel"}:
        assert masks and not any(m["local_index"] == 1 for m in masks), masks
        assert all(not (Path(m["output"]) / "run-001").exists() for m in case["members"]), (
            "unauthorized next preparation"
        )
        top = read(reference(Path(case["runtime"]) / "result.json"))
        assert top["outcome"] != "succeeded"
        if case["label"] == "outside_thread":
            assert any(
                (Path(m["output"]) / "run-000/mask-data/outside-thread.json").exists()
                for m in case["members"]
            )
            errors = "\n".join(
                p.read_text() for p in root.glob("lane-*/sequence/run-000/operation/candidate.json")
            )
            assert "outside assigned command CPU scope" in errors
        if case["label"] == "parent_cancel":
            cancel = root / "lane-0/sequence/run-000/mask-data/actual-parent-cancel.json"
            assert read(reference(cancel))["exit_code"] == 0
    else:
        assert not submit_error and len(masks) == 2 * len(case["members"])
        top = read(reference(Path(case["runtime"]) / "result.json"))
        assert top["outcome"] == "succeeded"
        for path in (root / "shared/events").glob("*.jsonl"):
            for line in path.read_text().splitlines():
                event = json.loads(line)
                assert set(event["mask"]) <= set(allocation["management_cpu_pool"])
                events.append(event)
        for member in case["members"]:
            for local in range(2):
                manifest = read(
                    reference(Path(member["output"]) / f"run-{local:03d}/operation/manifest.json")
                )
                assert manifest["status"] == "PASS" and manifest["cleanup_complete"] is True
        stages = {e["stage"] for e in events}
        assert {
            "fresh_canonical_child_entry",
            "parent_prepare",
            "next_operation_prepare",
            "finalize:call",
            "_prepare_completion:call",
            "sequence:return",
        } <= stages
        if case["label"] == "two_lane":
            starts, ends = [], []
            for member in case["members"]:
                first = Path(member["output"]) / "run-000/mask-data"
                starts.append(read(reference(first / "mask.json"))["started_monotonic"])
                ends.append(read(reference(first / "finished.json"))["finished_monotonic"])
            assert max(starts) < min(ends), "two actual payload intervals did not overlap"
            assert {"cohort_sequence:call", "cohort_sequence:return"} <= {
                e["stage"] for e in events
            }
            for member in case["members"]:
                for local in range(2):
                    finished = read(
                        reference(
                            Path(member["output"]) / f"run-{local:03d}/mask-data/finished.json"
                        )
                    )
                    assert finished["parent_authority_after"] > finished["parent_authority_before"]
    # A concrete inherited scientific-census assumption is NOT silently greened.
    # Keep its exact errors separate from exercised CPU/process/collection facts.
    return dict(
        label=case["label"],
        actual_control_cases_checked=True,
        normal_process_receipts=receipts,
        mask_count=len(masks),
        event_count=len(events),
        known_identities=identities,
        remaining=remaining,
        inherited_scientific_progress_errors=progress_errors,
        TMP_remaining=tmp_remaining,
        qualification="BLOCKED_ACTUAL_TMP_CLEANUP"
        if tmp_remaining
        else ("BLOCKED_INHERITED_PROGRESS_ASSUMPTION" if progress_errors else "PASS"),
        scientific_qualification=False,
        submit_error=submit_error,
    )
