"""Return executable private fixture and actual source STOP before own administration."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
sys.path.insert(0, str(OWN))
from intake import ROOT, ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def run(argv):
    with subprocess.Popen(
        argv, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate(timeout=60)
        code = child.wait()
    result = dict(
        argv=argv,
        exit_code=code,
        stdout=stdout.decode(),
        stderr=stderr.decode(),
        directwait_reaped=True,
        handles_closed=child.stdout.closed and child.stderr.closed,
    )
    assert code == 0, result
    return result


def main():
    binding = json.loads((OUT / "fixture-binding.json").read_text())
    package = json.loads(Path(binding["package"]["path"]).read_text())
    for file_ref in package["files"].values():
        assert ref(file_ref["path"]) == file_ref
    assert ref(OUT / "package-binding.json") == binding["package"]
    guards, fresh = [], []
    for label in (
        "executable-smoke-source-guard-v1",
        "executable-smoke-source-guard-v2",
        "executable-smoke-source-guard-v3",
    ):
        path = OWN / label / "result.json"
        g = json.loads(path.read_text())
        assert g["TMP_remaining"] == []
        guards.append(ref(path))
        for old in [
            g["controller"],
            *[r["guardian_return"]["child"] for r in g["checks"] if r.get("guardian_return")],
        ]:
            info = process.process_info(old["pid"])
            current = process.identity(info) if info else None
            assert current != old
            fresh.append(dict(original=old, current=current, exact_absent_or_different=True))
    assert g["status"] == "PASS"
    seen = {}
    for path in [OUT, *OUT.rglob("*")]:
        st = path.lstat()
        seen[(st.st_dev, st.st_ino)] = st.st_blocks * 512
    affected = save(
        OUT / "affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            root=str(OUT),
            allocated_B=sum(seen.values()),
            inodes=len(seen),
            scope="one new OWN32 fixture subtree only, including unissued WIP; no old holding recharge/global walk/grant",
        ),
    )
    stop = save(
        OUT / "source-helper-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            actual_source_guards=guards,
            actual_reader_STOP=g["reader_STOP"],
            fresh_exact_known_ids=fresh,
            directwait_reap_handles=True,
            remaining=[],
            TMP=[],
            source_leases=[],
            Main_reader=False,
            CPU=2,
            guardian_CPU=18,
            family_B=1073741824,
            controller_included_B=67108864,
            hostreserve_B=4294967296,
            GPU=0,
            affected_point=affected,
            author_tests_smoke_native_Search_model_RNG=0,
            production_target_imports=0,
            pure_own_text_emitter_import_only=True,
            Main_Git_Cargo_docs_writes=0,
            futurequiet=False,
            current_light_delivery_separate=True,
        ),
    )
    handoff = save(
        OUT / "handoff.json",
        dict(
            issue="quoridor-4lc.324.32",
            fixture_binding=ref(OUT / "fixture-binding.json"),
            package=binding["package"],
            source_STOP=stop,
            actual_execution="UNRUN_ROOT_ONLY",
            current_LC_binding="Root actual current7d40/388500+future exact mode/ref, not9d837 wholepost",
            source_review_target62d5="immutable",
            actual13distinct_limited_tests="Root reported PASS, author replay0",
            inherited_progress_finding=binding["inherited_progress_finding"],
            unresolved_qualification="fresh Root source/allocation/admission plus actual normal process smoke; static finding forbids fabricated fullPASS",
        ),
    )
    body = OUT / "Root-fixed-handoff.txt"
    body.write_text(
        "SAME32 CONCRETE executable private fixture fixed, not another option/readiness report. Source62d5+Rootaccepted16CPU bodies remain immutable; author Main/Git/Cargo/docs/test/smoke/native/Search/model/RNG0.\n\n"
        "Five executable fixture owners: coordinator (one fixed-case loop using actual normal job.submit/directwait, no lane scheduler), normal metadata materializer reusing actual resolve_arena_parallel, mask-only shell/Python payload, synthetic SCIENCE owner, receipt assessment. Exact TEST-ONLY pre-main footer/inverse are attached. Only experiment_check/collect_data/existing sequence prepare keyword are substituted; CPUPlan/configured_job_cpu_plan/current_cpu_owner/physical and peer ancestry/actual job authority+Popen+session/cohort+sequence+resources+cancel+settled/finalize/_prepare_completion execute unchanged. Read-only bounded profile snapshots actual function entry/return masks, not wrapper return/permission changes.\n\n"
        "Cases fixed: actual2lanes×2ops, singlelane×2ops, unavailable/SMT/roleoverlap prepayload refusals, actual out-of-scope child thread, child failure, actual parent cancel CLI with no next operation/retry/live descendants. Named quoridor-runner-cpu-smoke argv0 deliberately enters real named-peer classification; artifact/schema explicit synthetic, no forged qualified Build/model/Plan. Positive2lane requires actual overlapping bodies and parent CPU/authority renewal while each operation's named body lives. Actual normal manifests, identities/directwait/handles and TMP are checked, not mocked.\n\n"
        "CurrentRootLC7d40/388500 after ETCretirement is bound by fresh Root allocation; no author liveMain read/copy/import. Installation uses only unique EOF insertion, creates actual CURRENT before snapshot/actual-line forward+inverse under EX_NB, verifies16CPU correspondence+unchanged job13a2/cycle98df, rejects live known sourceusers/other maintained reader+external named compute. All current LC function/class bytes are unchanged by entry insertion. Finally exact bytes/mode restore on test exception/cancel; explicit restore-only after settled hard-failure normal cleanup, no payload rerun/foreign overwrite. Old9d837 wholepost is never restored over currentMain.\n\n"
        "Concrete SEPARATE static finding: inherited arena_cohort_progress fixes3072 slots and32/operation; 2×2 dummy cannot satisfy that scientific census. Production was NOT changed; actual progress_errors are retained and full-normal-PASS is blocked, not greened with fake census or guard exemption. TMP residuals also block PASS. This finding is not an observed runtime result. Root can handle this narrow inherited data-owner assumption if an actual execution requires it; no author selfclear/reviewdispatch or new permission stage. Standalone collector CLI transport supported, but fixture collection uses actual sequence-finalize; no unexecuted standalonecollector success claim.\n\n"
        "All handwritten fixture code scopedRuffformat100/lint/parser +generatedfooter formatcheck PASS. ActualsourcehelperSTOP04:35:25.082432Z, fresh exact IDs absent/different/directwait-reap/handles/TMP/leases[], CPU2/G18/F1GiBincl64/host4/G0, one affected subtree point. Initial F841 WIP negative/unissued-v1 metadata preserved. This is source/helper STOP, NOT job/native START; current lightdelivery separate. Actual Root buildSTOP66dbfa supplied, no replay; Root13distinct syntheticPASS retained. Fresh actual allocation/current tuple still required, template NULL intentionally nonrunnable. No report/ACK/oldclose gate. All prior MPCFAILED/ETC208/no-games/costs/pauses/models/seals/defaults/foreign/50GB unchanged.\n\n"
        + json.dumps(
            dict(
                handoff=handoff,
                source_STOP=stop,
                fixture_binding=ref(OUT / "fixture-binding.json"),
                delivery_guard=str(OWN / "executable-smoke-delivery-guard-v1/result.json"),
            ),
            indent=2,
        )
        + "\n"
    )
    save(
        OUT / "Root-delivery.json",
        run(
            [
                "bash",
                "scripts/dev/research-session.sh",
                "send",
                "--thread",
                "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
                "--issue",
                "quoridor-4lc.324",
                "--cwd",
                str(ROOT),
                "--body-file",
                str(body),
            ]
        ),
    )
    for label, args in (
        ("ready", ["ready", "--json"]),
        ("show", ["show", "quoridor-4lc.324.32", "--json"]),
    ):
        result = run(["bash", "scripts/dev/beads.sh", *args])
        if label == "show":
            issue = json.loads(result["stdout"])
            issue = issue[0] if isinstance(issue, list) else issue
            assert (
                issue["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
                and issue["status"] == "in_progress"
            )
        save(OUT / f"beads-{label}.json", result)
    save(
        OUT / "beads-note.json",
        run(
            [
                "bash",
                "scripts/dev/beads.sh",
                "update",
                "quoridor-4lc.324.32",
                "--append-notes",
                "Concrete Root-only executable normalprocess fixture fixed: actual normal job/cohort/sequence/Popen/CPU/authority/resource/cancel/finalize; only explicit synthetic science entry, exact sparse EOF/current-before restoration. Root13 distinct limited tests PASS reported, no author test/smoke/native/Search. Source helper STOP04:35:25.082432Z/CPU2G18/F1G incl64/host4G/G0, directwait handles TMPleases[] freshIDs. Current RootLC7d40 binding future; no9d wholepost overwrite. Separate inherited3072 progress-census assumption retained, errors/TMP block fullPASS. Packet "
                + str(OUT / "handoff.json"),
            ]
        ),
    )
    save(
        OUT / "beads-backup.json", run(["bash", "scripts/dev/beads.sh", "backup", "sync", "--json"])
    )
    removed = []
    for path in Path(os.environ["TMPDIR"]).iterdir():
        assert (
            path.is_file()
            and path.stat().st_size == 0
            and path.name.startswith("uv-")
            and path.name.endswith(".lock")
        )
        with path.open("rb") as stream:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            path.unlink()
        removed.append(str(path))
    save(OUT / "delivery-TMP-cleanup.json", dict(removed=removed))
    print(json.dumps(dict(handoff=handoff, source_STOP=stop)))


if __name__ == "__main__":
    main()
