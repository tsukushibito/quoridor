def execute(
    command,
    log,
    deadline,
    cpu_core=None,
    resources=None,
    *,
    cwd=None,
    env=None,
    output_sink=None,
    cpu_cores=None,
    no_new_privs=False,
    cpu_plan=None,
    cpu_scope="run",
):
    """Always TERM→KILL→wait; retain a bounded tail plus exact cleanup evidence."""
    if type(no_new_privs) is not bool:
        raise ValueError("no_new_privs must be a boolean")
    if cpu_plan is not None:
        if cpu_core is not None or cpu_cores is not None:
            raise ValueError("one resolved CPU plan, not competing command CPU arrays")
        cpu_plan.check_host(available_cpus())
        cpu_cores = list(cpu_plan.commands[cpu_scope])
    if resources:
        resources.check()
    elif deadline is not None and time.monotonic() >= deadline:
        raise CycleStopped("cycle deadline before child launch")
    log = Path(log)
    record_path = log.with_suffix(".process.json")
    record = {
        "command": [str(arg) for arg in command],
        "status": "starting",
        "child": None,
        "launch_policy": {
            "no_new_privs_requested": no_new_privs,
            "verified_before_exec": None,
        },
        "cpu_plan": cpu_plan.record() if cpu_plan is not None else None,
        "command_cpu_scope": cpu_scope if cpu_plan is not None else None,
        "log_bytes_seen": 0,
        "scope": "session group and periodically recorded descendants; no daemon adoption",
    }
    tail = bytearray()
    selector = selectors.DefaultSelector()
    child, root, owned = (None, None, [])
    direct_fd = None
    pipe_open = False
    failure = None
    started = time.monotonic()
    stream, mask = (None, None)
    final_errors, handle_closes = ([], [])

    def error_fact(error):
        try:
            message = str(error)
        except BaseException:
            message = "<exception stringification failed>"
        return {"type": type(error).__name__, "message": message}

    def final_error_facts():
        return [{"stage": stage, **error_fact(error)} for stage, error in final_errors]

    def attempt_final(stage, action):
        if stage.endswith("_close"):
            handle_closes.append(stage)
        try:
            return action()
        except BaseException as error:
            final_errors.append((stage, error))

    try:
        stream = log.open("xb")
        # Initialize libc in the parent; the existing child callback only calls it.
        prctl = None
        if no_new_privs:
            prctl = ctypes.CDLL(None, use_errno=True).prctl
            prctl.argtypes = [ctypes.c_int, *([ctypes.c_ulong] * 4)]
            prctl.restype = ctypes.c_int
        launch_mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
        try:

            def prepare_child():
                signal.pthread_sigmask(signal.SIG_SETMASK, launch_mask)
                if no_new_privs:
                    if prctl(38, 1, 0, 0, 0) != 0:  # PR_SET_NO_NEW_PRIVS
                        error = ctypes.get_errno()
                        raise OSError(error, "PR_SET_NO_NEW_PRIVS failed")
                    if prctl(39, 0, 0, 0, 0) != 1:  # PR_GET_NO_NEW_PRIVS
                        raise OSError("PR_GET_NO_NEW_PRIVS did not return 1")
                if cpu_cores is not None:
                    if (
                        cpu_core is not None
                        or not isinstance(cpu_cores, (list, tuple))
                        or not cpu_cores
                        or any(type(c) is not int or c < 0 for c in cpu_cores)
                        or len(set(cpu_cores)) != len(cpu_cores)
                    ):
                        raise ValueError("one explicit nonempty unique child CPU allocation")
                    os.sched_setaffinity(0, set(cpu_cores))
                elif cpu_core is not None:
                    os.sched_setaffinity(0, {cpu_core})

            child = subprocess.Popen(
                command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                preexec_fn=prepare_child,
                cwd=cwd,
                env=env,
            )
            if no_new_privs:
                # Popen returned only after the callback and exec succeeded.
                record["launch_policy"]["verified_before_exec"] = 1
            direct_fd = os.pidfd_open(child.pid)
            root = identity(process_info(child.pid))
            if root is None:
                raise CycleStopped("cannot record child identity")
            owned = [root]
            record.update(status="running", child=root)
            save_record(record_path, record)
            os.set_blocking(child.stdout.fileno(), False)
            selector.register(child.stdout, selectors.EVENT_READ)
            pipe_open = True

            def drain(timeout=0):
                nonlocal pipe_open
                for key, _event in selector.select(timeout):
                    data = os.read(key.fd, 65536)
                    if not data:
                        selector.unregister(key.fileobj)
                        pipe_open = False
                        continue
                    record["log_bytes_seen"] += len(data)
                    tail.extend(data)
                    del tail[: max(0, len(tail) - LOG_MAX_BYTES)]
                    if output_sink is not None:
                        output_sink(data)
        finally:
            signal.pthread_sigmask(signal.SIG_SETMASK, launch_mask)
        next_log = 0
        while child.poll() is None:
            owned = members(root, owned)
            if cpu_plan is not None:
                for member in owned:
                    if not alive(member):
                        continue
                    try:
                        for task in Path(f"/proc/{member['pid']}/task").iterdir():
                            if not os.sched_getaffinity(int(task.name)) <= set(cpu_cores):
                                raise CycleStopped(
                                    "owned child/thread outside assigned command CPU scope"
                                )
                    except (FileNotFoundError, ProcessLookupError):
                        continue
            if resources:
                resources.check(owned)
            elif deadline is not None and time.monotonic() >= deadline:
                raise CycleStopped("cycle child deadline: " + str(command[0]))
            drain(POLL_SECONDS)
            if time.monotonic() >= next_log:
                stream.seek(0)
                stream.write(tail)
                stream.truncate()
                stream.flush()
                next_log = time.monotonic() + 0.25
        if child.returncode:
            raise CycleStopped(f"cycle child failed: {command}: {child.returncode}")
        record["status"] = "complete"
    except BaseException as error:
        failure = error
        record.update(status="failed", error=str(error), reason=type(error).__name__)
    finally:
        try:
            mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
        except BaseException as error:
            final_errors.append(("signal_mask_block", error))
        try:

            def stop_direct(sig, stage):
                def send_owned(action):
                    try:
                        action()
                    except ProcessLookupError:
                        pass
                    return True

                if direct_fd is not None and attempt_final(
                    stage + "_pidfd",
                    lambda: send_owned(lambda: signal.pidfd_send_signal(direct_fd, sig)),
                ):
                    return
                attempt_final(stage + "_popen", lambda: send_owned(lambda: child.send_signal(sig)))

            def observe():
                return [member for member in owned if alive(member)]

            def discover():
                nonlocal owned
                if root:
                    owned = members(root, owned)

            if child:
                attempt_final("descendant_discovery", discover)
                direct_running = [True]
                attempt_final(
                    "direct_poll",
                    lambda: direct_running.__setitem__(0, child.poll() is None),
                )
                live = True
                try:
                    live = bool(observe())
                except BaseException as error:
                    final_errors.append(("descendant_observation", error))
                if live or direct_running[0]:
                    if record["status"] == "complete":
                        failure = CycleStopped("cycle child left running descendants")
                        record.update(status="failed", error=str(failure))
                    for member in owned:
                        attempt_final(
                            "descendant_term",
                            lambda member=member: signal_members([member], signal.SIGTERM),
                        )
                    if direct_running[0]:
                        attempt_final(
                            "direct_term",
                            lambda: stop_direct(signal.SIGTERM, "direct_term"),
                        )
                    until = time.monotonic() + TERM_SECONDS
                    while time.monotonic() < until:
                        try:
                            if child.poll() is not None and not observe():
                                break
                        except BaseException as error:
                            final_errors.append(("cleanup_observation", error))
                            break
                        attempt_final("descendant_discovery", discover)
                        if pipe_open:
                            attempt_final("pipe_drain", lambda: drain(POLL_SECONDS))
                        else:
                            time.sleep(POLL_SECONDS)
                    attempt_final("descendant_discovery", discover)
                    for member in owned:
                        attempt_final(
                            "descendant_kill",
                            lambda member=member: signal_members([member], signal.SIGKILL),
                        )
                    # Signal the owned direct pidfd independently even if discovery failed.
                    attempt_final(
                        "direct_kill",
                        lambda: stop_direct(signal.SIGKILL, "direct_kill"),
                    )
                attempt_final("direct_wait", lambda: child.wait(timeout=3))
                until = time.monotonic() + 1
                while time.monotonic() < until:
                    try:
                        if not pipe_open and not observe():
                            break
                    except BaseException as error:
                        final_errors.append(("remaining_observation", error))
                        break
                    if pipe_open:
                        before = len(final_errors)
                        attempt_final("pipe_drain", lambda: drain(POLL_SECONDS))
                        if len(final_errors) != before:
                            break
                    else:
                        time.sleep(POLL_SECONDS)
                record["exit_code"] = child.returncode
                record["remaining"] = list(owned)  # Retain UNKNOWN members if observation fails.
                attempt_final("remaining_observation", lambda: record.update(remaining=observe()))
            direct_reaped = child is None or child.returncode is not None
            record.update(
                direct_child_reaped=direct_reaped,
                descendant_visibility="unavailable" if child and root is None else "observed",
                cleanup_complete=direct_reaped
                and (child is None or root is not None)
                and (not record.get("remaining"))
                and (not pipe_open)
                and not final_errors,
                log_bytes_retained=len(tail),
                wall_seconds=time.monotonic() - started,
            )
            if not record["cleanup_complete"]:
                record["cleanup_error"] = "cycle cleanup incomplete"
                if failure is None:
                    failure = CycleStopped("cycle cleanup incomplete")
            if failure:
                record.update(status="failed", error=str(failure))
        except BaseException as error:
            final_errors.append(("process_cleanup", error))
        finally:
            if stream is not None:
                for stage, action in (
                    ("log_seek", lambda: stream.seek(0)),
                    ("log_write", lambda: stream.write(tail)),
                    ("log_truncate", stream.truncate),
                    ("log_flush", stream.flush),
                ):
                    attempt_final(stage, action)
            attempt_final("selector_close", selector.close)
            if child and child.stdout:
                attempt_final("pipe_close", child.stdout.close)
            if direct_fd is not None:
                attempt_final("pidfd_close", lambda: os.close(direct_fd))
            if stream is not None:
                attempt_final("log_close", stream.close)
            record["handle_closes_attempted"] = handle_closes
            record["primary_error"] = error_fact(failure) if failure else None
            record["process_cleanup_complete"] = record.get("cleanup_complete", False)
            record["handle_closes_complete"] = not any(
                (stage.endswith("_close") for stage, _ in final_errors)
            )
            record["cleanup_complete"] = (
                record["process_cleanup_complete"] and record["handle_closes_complete"]
            )
            if final_errors:
                record.update(status="failed", finalization_failed_stage=final_errors[0][0])
            record["signal_mask_restoration"] = "pending"
            if stream is not None:
                record["final_record_persist"] = "attempted"
                record["finalization_errors"] = final_error_facts()
                attempt_final("receipt_persist", lambda: save_record(record_path, record))
                record["final_record_persist"] = (
                    "failed_or_partial_UNKNOWN"
                    if any((stage == "receipt_persist" for stage, _ in final_errors))
                    else "completed"
                )
            else:
                record["final_record_persist"] = "unavailable; new log ownership not acquired"
            if mask is not None:
                attempt_final(
                    "signal_mask_restore",
                    lambda: signal.pthread_sigmask(signal.SIG_SETMASK, mask),
                )
                record["signal_mask_restoration"] = (
                    "failed_UNKNOWN"
                    if any((stage == "signal_mask_restore" for stage, _ in final_errors))
                    else "completed"
                )
            else:
                record["signal_mask_restoration"] = "unavailable; block did not return"
    if final_errors:
        record.update(status="failed", finalization_errors=final_error_facts())
        errors = ([failure] if failure is not None else []) + [error for _, error in final_errors]
        group = BaseExceptionGroup("cycle primary/finalization failures", errors)
        group.add_note("nonrecursive cycle fallback facts: " + json.dumps(record, allow_nan=False))
        group.cycle_cleanup_outcome = {"normal_return": False, "record": dict(record)}
        raise group
    if failure:
        failure.cycle_cleanup_outcome = {"normal_return": False, "record": dict(record)}
        raise failure
    if resources:
        try:
            resources.check()
        except BaseException as error:
            error.cycle_cleanup_outcome = {"normal_return": False, "record": dict(record)}
            raise
    return record
