"""Return the causal materializer package before ordinary own administration."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def run(argv):
    with subprocess.Popen(
        argv, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate(timeout=60)
        code = child.wait()
    return dict(
        argv=argv,
        exit_code=code,
        stdout=stdout.decode(),
        stderr=stderr.decode(),
        directwait_reaped=True,
        handles_closed=child.stdout.closed and child.stderr.closed,
    )


def main():
    guard_path = OWN / "smoke-materializer-v3-guard-v1/result.json"
    guard = json.loads(guard_path.read_text())
    assert guard["status"] == "PASS" and guard["TMP_remaining"] == []
    fresh = []
    for old in [
        guard["controller"],
        *[r["guardian_return"]["child"] for r in guard["checks"] if r.get("guardian_return")],
    ]:
        info = process.process_info(old["pid"])
        actual = process.identity(info) if info else None
        assert actual != old
        fresh.append(dict(original=old, actual=actual, exact_absent_or_different=True))
    package = json.loads((OUT / "package-binding.json").read_text())
    for file_ref in package["files"].values():
        assert ref(file_ref["path"]) == file_ref
    seen = {}
    for path in [OUT, *OUT.rglob("*")]:
        st = path.lstat()
        seen[(st.st_dev, st.st_ino)] = st.st_blocks * 512
    affected = save(
        OUT / "affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            root=str(OUT),
            allocated_B=sum(seen.values()),
            inodes=len(seen),
            scope="one new OWN32 v3 subtree point only, no old FAILED/run charge or global walk",
        ),
    )
    stop = save(
        OUT / "source-helper-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            guard=ref(guard_path),
            actual_source_reader_STOP=guard["reader_STOP"],
            fresh_exact_known_ids=fresh,
            directwait_reap_handles=True,
            remaining=[],
            TMP=[],
            source_leases=[],
            Main_source_imports_copies_reads_writes=0,
            CPU=2,
            guardian_CPU=18,
            family_B=1073741824,
            controller_included_B=67108864,
            hostreserve_B=4294967296,
            GPU=0,
            affected_point=affected,
            tests_smoke_native_Search_model_RNG=0,
            futurequiet=False,
            current_delivery_separate=True,
        ),
    )
    handoff = save(
        OUT / "handoff.json",
        dict(
            issue="quoridor-4lc.324.32",
            fixture_v3_binding=ref(OUT / "fixture-binding.json"),
            package=ref(OUT / "package-binding.json"),
            forward=ref(OUT / "materialize-forward.patch"),
            inverse=ref(OUT / "materialize-inverse.patch"),
            actual_source_STOP=stop,
            Root_first_failure=ref(
                ROOT
                / ".artifacts/research-team/integration324/research-cpu-plan-v1/real-smoke-v1/actual-returned-STOP.json"
            ),
            Root_exact_restoration=ref(
                OWN / "smoke-fixture-v2/runs/Root-normal-smoke-v1/actual-restored.json"
            ),
            current_LC="Root actual58f6007e/388905/0644 required by fresh allocation",
            future="Root real case execution still required; no production source mutation, no selfclear",
            old_v2_failure_namespace="immutable",
        ),
    )
    body = OUT / "Root-fixed-handoff.txt"
    body.write_text(
        "SAME32 causal materializer-only v3 fixed. Preserved actual turn_context01a15ccc-4959-7510-ac7b-57b4b411975d / gpt-6.1-sol/high/Main/cwd/workspaces/quoridor/danger-full-access/approval never. Only materialize execution source changes: exclusive-publish actual immutable parent_config BEFORE launch; bind same exact FileRef as launch.parent_config. Cohort/lane runtime/config ordering and actual pre-submit monotonic stay unchanged.\n\nAdjacent actual mandatory correspondence inspected narrowly using current immutable58f privatepost: parent intent kind/cohort/path, canonical argv/resource_contract, all lane issue/goal/thread equal parent, exact ordered runtimes/settings-body/config refs and finite positive launch clock. Those fields already correspond. A SECOND concrete missing materializer field was found: arena_cohort_progress actual sender reads cohort.notify.thread_id/issue, so v3 binds notify to SAME real allocation caller (no forged identity or notification bypass). This is the only additional field; producer/guard/CPU/authority/notification/finalize implementation untouched.\n\nFOUR other executable owners byteexact to v2; all8 fixed cases, games1 synthetic slot/no native publication means completed0/UNKNOWN, originalschema and source/restore control unchanged. New consistent package/footer/forward/inverse; actualRoot current58f/newresource binding remains owning entry. v2 NOT_STARTED c9b00f35/no masks or payload and original failure/restoration receipts retained immutable. Author case/test/native/Search/model/RNG/Main writes0.\n\nScoped Ruffformat/lint/parser +generated footer formatcheck PASS. ActualsourcehelperSTOP04:52:43.145930Z CPU2/G18/F1GiBincl64/host4/G0/directwait-reap/handles/TMP/sourceleases[]/freshIDs stopped. Current light delivery separate, no futurequiet. Root can rerun failed/unentered cases only after actualfresh source/resource binding; no new science, role, review/ACK gate or qualifier claim. Original14 distinct syntheticPASS reported retained no replay; MPCFAILED/ETC208/no games/costs/pauses/seals/defaults/models/foreign50GB held.\n\n"
        + json.dumps(
            dict(
                handoff=handoff,
                binding=ref(OUT / "fixture-binding.json"),
                source_STOP=stop,
                delivery_guard=str(OWN / "smoke-materializer-v3-delivery-guard-v1/result.json"),
            ),
            indent=2,
        )
        + "\n"
    )
    argv = [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--cwd",
        str(ROOT),
        "--body-file",
        str(body),
    ]
    delivery = run(argv)
    save(OUT / "Root-delivery.json", delivery)
    if delivery["exit_code"] != 0 and "no active turn to steer" in delivery["stderr"]:
        delivery = run(
            argv
        )  # Exact rejected delivery race only; not a scientific retry/status loop.
        save(OUT / "Root-delivery-causal-race-v2.json", delivery)
    assert delivery["exit_code"] == 0, delivery
    shown = run(["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.324.32", "--json"])
    assert shown["exit_code"] == 0, shown
    issue = json.loads(shown["stdout"])
    issue = issue[0] if isinstance(issue, list) else issue
    assert (
        issue["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
        and issue["status"] == "in_progress"
    )
    save(OUT / "beads-show.json", shown)
    note = run(
        [
            "bash",
            "scripts/dev/beads.sh",
            "update",
            "quoridor-4lc.324.32",
            "--append-notes",
            "Causal synthetic materializer v3: actual parent-config exclusive publish precedes launch, exact launch.parent_config FileRef; adjacent missing cohort.notify binds same real allocation issue/thread. Four other executable owners/8 cases/CPU authority finalize restore byteexact. Scopedformat/lint/parser PASS; author tests/case/Main0. ActualsourcehelperSTOP04:52:43.145930Z/CPU2G18/F1Gincl64/host4G/G0/directwait-reap/handles/TMPleases[] freshIDs. Original v2 NOT_STARTED failure/normal restoration and14 distinct unitPASS retained. Packet "
            + str(OUT / "handoff.json"),
        ]
    )
    save(OUT / "beads-note.json", note)
    assert note["exit_code"] == 0, note
    backup = run(["bash", "scripts/dev/beads.sh", "backup", "sync", "--json"])
    save(OUT / "beads-backup.json", backup)
    assert backup["exit_code"] == 0, backup
    removed = []
    for path in Path(os.environ["TMPDIR"]).iterdir():
        assert (
            path.is_file()
            and path.stat().st_size == 0
            and path.name.startswith("uv-")
            and path.name.endswith(".lock")
        )
        with path.open("rb") as stream:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            path.unlink()
        removed.append(str(path))
    save(OUT / "delivery-TMP-cleanup.json", dict(removed=removed))
    print(json.dumps(handoff))


if __name__ == "__main__":
    main()
