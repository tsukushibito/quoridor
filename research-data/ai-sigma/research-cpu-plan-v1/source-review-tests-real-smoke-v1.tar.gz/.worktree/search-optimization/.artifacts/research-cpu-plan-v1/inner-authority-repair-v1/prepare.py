"""Exact current authority-only custody, with independent new test definitions UNRUN."""

import ast
import difflib
import fcntl
import os
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

LC = "scripts/dev/research-lifecycle.py"
TEST = "tools/research-session/test_cohort_control.py"
NAME = "cohort_job_authority"


def part(text, name):
    n = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == name)
    lines = text.splitlines(True)
    return (
        "".join(lines[: n.lineno - 1]),
        "".join(lines[n.lineno - 1 : n.end_lineno]),
        "".join(lines[n.end_lineno :]),
    )


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as f:
        f.write(text)


def intake():
    assert os.sched_getaffinity(0) == {2}
    before = OWN / "configured-progress-repair-v1/post" / LC
    assert (
        ref(before)["sha256"] == "58f6007e2c72373ccaa44d50451f0373ad0bc16c4233a210cf8fbb2fe7c48024"
    )
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        current = ref(ROOT / LC)
        assert all(current[k] == ref(before)[k] for k in ("sha256", "bytes", "mode"))
        test_ref = ref(ROOT / TEST)
        write(OUT / "before" / TEST, (ROOT / TEST).read_text())
        fcntl.flock(lock, fcntl.LOCK_UN)
    write(OUT / "before" / LC, before.read_text())
    save(
        OUT / "intake.json",
        dict(
            current=current,
            test_current=test_ref,
            private_LC_before=ref(OUT / "before" / LC),
            short_SH_NB_released=True,
            Main_writes=0,
            target_imports=0,
            tests_smoke=0,
        ),
    )


def edit():
    _, body, _ = part((OUT / "before" / LC).read_text(), NAME)
    old = """            require(
                own == state.get("child") and state["phase"] == "running",
                "inner operation caller is the registered running lane sequence",
            )
"""
    new = """            sequence = state.get("child")
            require(state["phase"] == "running", "registered running lane sequence required")
            if config == declared:
                require(
                    own == sequence,
                    "inner operation caller is the registered running lane sequence",
                )
"""
    assert body.count(old) == 1
    body = body.replace(old, new, 1)
    old = """                settings_ref = bound(Path(member["settings_path"]))[0]
                intent_ref = bound(Path(config["argv"][5]))[0]
"""
    new = """                require(
                    isinstance(config["argv"], list)
                    and len(config["argv"]) == 8
                    and config["argv"][:5]
                    == [
                        sys.executable,
                        "-B",
                        str(ROOT / "scripts/dev/research-lifecycle.py"),
                        "run",
                        "--intent",
                    ]
                    and config["argv"][6] == "--sha256",
                    "inner operation uses the canonical registered run caller",
                )
                settings_ref = bound(Path(member["settings_path"]))[0]
                intent_ref = bound(Path(config["argv"][5]))[0]
"""
    assert body.count(old) == 1
    body = body.replace(old, new, 1)
    old = """                    and inner["supervisor"] == own
"""
    assert body.count(old) == 1
    body = body.replace(
        old,
        """                    and inner["supervisor"] == sequence
""",
        1,
    )
    anchor = """                    "assigned inner originating job",
                )
"""
    assert body.count(anchor) == 1
    addition = """                if own != sequence:
                    # The command child is distinct from the sequence that
                    # executes its normal job. Admit only that registered child,
                    # never an arbitrary descendant or an environment claim.
                    require(
                        directory is not None
                        and Path(directory) == inner_runtime
                        and document(bound(runtime / "config.json")[0]) == declared
                        and state["config_sha256"]
                        == sha(json.dumps(declared, sort_keys=True).encode())
                        and document(bound(inner_runtime / "config.json")[0]) == config
                        and inner["issue"] == config["issue"]
                        and inner["thread_id"] == config["thread_id"]
                        and inner["phase"] == "running"
                        and inner.get("child") == own
                        and sequence is not None
                        and process.alive(sequence)
                        and process.alive(state["supervisor"])
                        and process.alive(own)
                        and process.process_info(sequence["pid"])["parent"]
                        == state["supervisor"]["pid"]
                        and process.process_info(own["pid"])["parent"] == sequence["pid"]
                        and not (runtime / "cancel.json").exists()
                        and not (inner_runtime / "cancel.json").exists(),
                        "registered inner child/config/live ancestry and uncancelled lane",
                    )
"""
    body = body.replace(anchor, anchor + addition, 1)
    write(OUT / "authority.scoped.py", body)


def bind():
    before = (OUT / "before" / LC).read_text()
    h, b, t = part(before, NAME)
    changed = (OUT / "authority.scoped.py").read_text().rstrip("\n") + "\n"
    post = h + changed + t
    assert part(post, NAME)[::2] == (h, t)
    write(OUT / "post" / LC, post)
    original = (OUT / "before" / TEST).read_text()
    # Add one new test class, preserving every pre-existing test/helper/import byte.
    anchor = 'if __name__ == "__main__":\n    unittest.main()\n'
    assert original.count(anchor) == 1 and original.endswith(anchor)
    newclass = (OUT / "new-tests.scoped.py").read_text().rstrip("\n") + "\n\n\n"
    test_post = original[: -len(anchor)] + newclass + anchor
    write(OUT / "post" / TEST, test_post)
    assert test_post.replace(newclass, "", 1) == original
    subjects = []
    for subject in (LC, TEST):
        a = (OUT / "before" / subject).read_text()
        b = (OUT / "post" / subject).read_text()
        ast.parse(b)
        for direction, left, right in [("forward", a, b), ("inverse", b, a)]:
            with (OUT / (direction + ".patch")).open("a") as f:
                f.writelines(
                    difflib.unified_diff(
                        left.splitlines(True),
                        right.splitlines(True),
                        fromfile="a/" + subject,
                        tofile="b/" + subject,
                    )
                )
        subjects.append(
            dict(
                subject=subject,
                before=ref(OUT / "before" / subject),
                post=ref(OUT / "post" / subject),
            )
        )
    save(
        OUT / "binding.json",
        dict(
            issue="quoridor-4lc.324.32",
            status="PRIVATE_CHANGED_PERMISSION_BOUNDARY_UNRUN",
            subjects=subjects,
            forward=ref(OUT / "forward.patch"),
            inverse=ref(OUT / "inverse.patch"),
            production_function=NAME,
            outside_production_function_bytes_exact=True,
            old_test_definitions_bytes_exact=True,
            fixture_v3_unchanged=ref(OWN / "smoke-fixture-v3/fixture-binding.json"),
            selectors=[
                "test_cohort_control.RegisteredInnerAuthorityTests.test_registered_sequence_supervisor_and_inner_child_share_actual_binding",
                "test_cohort_control.RegisteredInnerAuthorityTests.test_foreign_sibling_config_ancestry_phase_and_cancel_refuse",
            ],
            new_authority="only exact registered running inner child with same canonical intent/config/settings/index/runtime + live exact parent chain + local no-cancel; parent authority/deadline check unchanged",
            startup="no implicit starting/unregistered-child permission added; current_cpu_owner unchanged",
            tests_smoke=0,
            target_imports=0,
            Main_Git_Cargo_docs_writes=0,
        ),
    )


if __name__ == "__main__":
    globals()[sys.argv[1]]()
