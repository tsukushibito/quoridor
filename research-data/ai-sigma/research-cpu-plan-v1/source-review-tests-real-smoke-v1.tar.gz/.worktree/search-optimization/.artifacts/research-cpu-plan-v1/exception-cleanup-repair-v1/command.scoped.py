def command(spec, row, directory, resources, executor=process.execute, *, ledger=None):
    check = {
        "name": row["name"],
        "role": row.get("role", "run"),
        "argv": row["argv"],
        "status": "ATTEMPTED",
        "guardian_return": None,
        "full_log": None,
        "persisted_process_receipt": None,
        "capture_complete": False,
        "secondary": [],
    }
    if ledger is not None:
        ledger.append(check)
    primary, record, capture = None, None, None
    try:
        budget = spec.get("command_timeout_seconds")
        if budget is not None:
            require(type(budget) is int and budget > 0, "positive admitted command timeout")
            if getattr(resources, "deadline", None) is None:
                # Start at the first actual command, never during source preparation.
                # All commands in this operation share this deadline and cleanup reserve.
                resources.deadline = time.monotonic() + budget
        capture = Capture(directory / (row["name"] + ".full.log"), spec["limits"]["log_B"])
        plan = getattr(resources, "cpu_plan", None) or operation_cpu_plan(spec)
        scope = "test" if row.get("role") == "test" else "run"
        cpu_args = {"cpu_plan": plan, "cpu_scope": scope}
        if spec.get("perf") is not None and row.get("role", "run") == "run":
            require(
                spec["kind"] == "run" and row["argv"] == spec["argv"],
                "actual configured profiler launch",
            )
            cpu_args["no_new_privs"] = True
        record = executor(
            row["argv"],
            directory / (row["name"] + ".log"),
            getattr(resources, "deadline", None),
            resources=resources,
            cwd=spec["cwd"],
            env=spec["env"],
            output_sink=capture,
            **cpu_args,
        )
        check["guardian_return"] = record
        settled(record)
    except BaseException as error:
        primary = error
        # This is an actual exception after execute's finally, not a normal
        # guardian return or evidence reconstructed from a pre-final disk record.
        outcome = getattr(error, "cycle_cleanup_outcome", None)
        if outcome is not None:
            if (
                isinstance(outcome, dict)
                and outcome.get("normal_return") is False
                and isinstance(outcome.get("record"), dict)
                and outcome["record"].get("command") == [str(arg) for arg in row["argv"]]
            ):
                check["guardian_exception_outcome"] = outcome
            else:
                check["secondary"].append(
                    {
                        "stage": "guardian_exception_outcome",
                        "type": "Refused",
                        "message": "exception cleanup does not join this actual command",
                    }
                )
    if capture is not None:
        try:
            capture.close()
        except BaseException as error:
            check["secondary"].append({"stage": "capture_close", **error_fact(error)})
            if primary is not None:
                primary.add_note("capture secondary: " + repr(error))
            else:
                primary = error
        try:
            check["full_log"] = bound(capture.path, spec["limits"]["log_B"])[0]
            check["capture_complete"] = (
                record is not None
                and record.get("log_bytes_seen") == check["full_log"]["bytes"]
                and not check["secondary"]
            )
            if primary is None:
                require(check["capture_complete"], "full returned capture missing/partial")
        except BaseException as error:
            check["secondary"].append({"stage": "capture_identity", **error_fact(error)})
            if primary is not None:
                primary.add_note("capture identity secondary: " + repr(error))
            else:
                primary = error
    persisted = (directory / (row["name"] + ".log")).with_suffix(".process.json")
    if persisted.exists():
        try:
            check["persisted_process_receipt"] = bound(persisted)[0]
        except BaseException as error:
            check["secondary"].append({"stage": "persisted_process_identity", **error_fact(error)})
            if primary is not None:
                primary.add_note("persisted process secondary: " + repr(error))
            else:
                primary = error
    check["status"] = "FAILED" if primary is not None else "PASS"
    check["primary"] = error_fact(primary) if primary is not None else None
    if primary is not None:
        raise primary
    return record, capture.path
