"""Freeze the representation-only games=1 derivative; never execute the smoke."""

import ast
import difflib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
OWN = HERE.parent
OLD = OWN / "smoke-fixture-v1"
REPAIR = OWN / "configured-progress-repair-v1"
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402


def main():
    original = ref(OLD / "fixture-binding.json")
    assert original["sha256"] == "b3aebf4f748e96d0abb9cba9e3927fa901dab32028c056223592c7a167742306"
    old_binding = json.loads((OLD / "fixture-binding.json").read_text())
    files = [
        "science_fixture.py",
        "materialize.py",
        "mask_payload.py",
        "assess.py",
        "coordinator.py",
    ]
    unchanged = []
    for name in files:
        before = (OLD / name).read_bytes()
        after = (HERE / name).read_bytes()
        ast.parse(after)
        if name != "materialize.py":
            assert before == after
            unchanged.append(name)
        else:
            added = b"                games=1,\n"
            assert after.count(added) == 1 and after.replace(added, b"", 1) == before
            for direction, left, right in [("forward", before, after), ("inverse", after, before)]:
                with (HERE / ("materialize-" + direction + ".patch")).open("x") as stream:
                    stream.writelines(
                        difflib.unified_diff(
                            left.decode().splitlines(True),
                            right.decode().splitlines(True),
                            fromfile="a/materialize.py",
                            tofile="b/materialize.py",
                        )
                    )
    package = save(
        HERE / "package-binding.json",
        dict(
            schema="quoridor.cpu-plan-smoke.fixture-package.v1",
            source_binding=old_binding["package"]
            and json.loads(Path(old_binding["package"]["path"]).read_text())["source_binding"],
            files={name: ref(HERE / name) for name in files},
            author_executed_tests_smoke=0,
            representation_derivative_of=original,
            required_progress_adoption=ref(REPAIR / "binding.json"),
        ),
    )
    loader = importlib.util.spec_from_file_location(
        "own_text_emitter_only_v2", HERE / "science_fixture.py"
    )
    emitter = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(emitter)  # Pure stdlib source emitter, no normal owner import.
    before = (OLD / "entry-before.py").read_bytes()
    after = emitter.entry_bytes(before, package)
    assert emitter.definitions(before) == emitter.definitions(after) == {}
    for name, raw in [("entry-before.py", before), ("entry-after.py", after)]:
        with (HERE / name).open("xb") as stream:
            stream.write(raw)
    for name, left, right in [
        ("entry-forward.footer.patch", before, after),
        ("entry-inverse.footer.patch", after, before),
    ]:
        with (HERE / name).open("x") as stream:
            stream.writelines(
                difflib.unified_diff(
                    left.decode().splitlines(True),
                    right.decode().splitlines(True),
                    fromfile="a/scripts/dev/research-lifecycle.py",
                    tofile="b/scripts/dev/research-lifecycle.py",
                )
            )
    binding = save(
        HERE / "fixture-binding.json",
        dict(
            issue="quoridor-4lc.324.32",
            status="CONCRETE_EXECUTABLE_ROOT_ONLY_FIXTURE_V2_UNRUN",
            original_immutable_fixture=original,
            old_finding_immutable=old_binding["inherited_progress_finding"],
            package=package,
            required_production_count_repair=ref(REPAIR / "binding.json"),
            materialize_before=ref(OLD / "materialize.py"),
            materialize_post=ref(HERE / "materialize.py"),
            materialize_forward=ref(HERE / "materialize-forward.patch"),
            materialize_inverse=ref(HERE / "materialize-inverse.patch"),
            representation_only="one synthetic configured slot (games=1) per operation; zero scientific games executed, missing native publication remains UNKNOWN, no fabricated report/census",
            outside_added_field_bytes_exact=True,
            unchanged_executable_owners=unchanged,
            cases=old_binding["cases"],
            science_substitutions=old_binding["science_substitutions"],
            unique_entry_before=ref(HERE / "entry-before.py"),
            unique_entry_after=ref(HERE / "entry-after.py"),
            forward_footer=ref(HERE / "entry-forward.footer.patch"),
            inverse_footer=ref(HERE / "entry-inverse.footer.patch"),
            hunk_semantics=old_binding["hunk_semantics"],
            restoration=old_binding["restoration"],
            Root_current_lifecycle="NULL until actual production progress delta adoption; Root must bind genuine adopted current hash/size/mode in allocation before any temporary entry install",
            future_allocation_template=ref(HERE / "allocation-template.json"),
            readme=ref(HERE / "README-ja.md"),
            protected_controls="CPU/authority/resources/directwait/finalize/cancel/assessment/restore byteexact to original fixture; production outside arena_cohort_progress byteexact to current7d40",
            errors_or_TMP_remaining_block_PASS=True,
            tests_realprocess_native_Search_model_RNG_run=0,
            Main_Git_Cargo_docs_writes=0,
            claims="no execution/qualification, no source selfclear",
        ),
    )
    print(json.dumps(binding))


if __name__ == "__main__":
    main()
