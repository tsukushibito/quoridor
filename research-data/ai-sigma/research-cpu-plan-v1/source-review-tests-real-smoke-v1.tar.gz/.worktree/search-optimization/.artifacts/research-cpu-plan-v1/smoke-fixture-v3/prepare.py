"""Sparse synthetic materializer custody only; no target import or case execution."""

import ast
import difflib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
OWN = HERE.parent
OLD = OWN / "smoke-fixture-v2"
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

FILES = ("science_fixture.py", "materialize.py", "mask_payload.py", "assess.py", "coordinator.py")
PARENT = """    parent_config = publish(
        Path(parent["config_path"]), job_config(parent_settings, allocation, cohort_ref=cohort_ref)
    )
"""


def corrected(raw):
    text = raw.decode()
    assert text.count(PARENT) == 1
    text = text.replace(PARENT, "", 1)
    anchor = '    publish(\n        shared / "launch.json",\n'
    assert text.count(anchor) == 1
    text = text.replace(anchor, PARENT + anchor, 1)
    anchor = "            cohort=cohort_ref,\n            monotonic=time.monotonic(),\n"
    assert text.count(anchor) == 1
    text = text.replace(
        anchor,
        "            cohort=cohort_ref,\n            parent_config=parent_config,\n            monotonic=time.monotonic(),\n",
        1,
    )
    anchor = "        control_root=str(shared),\n        members=members,\n"
    assert text.count(anchor) == 1
    text = text.replace(
        anchor,
        '        control_root=str(shared),\n        notify=dict(thread_id=allocation["thread_id"], issue=allocation["issue"]),\n        members=members,\n',
        1,
    )
    return text.encode()


def edit():
    assert (
        ref(OLD / "fixture-binding.json")["sha256"]
        == "8ac10135b5654cae50e256675c9a25681f2259bff124dafc3e4c78fc08ae9f61"
    )
    for name in FILES:
        raw = (OLD / name).read_bytes()
        if name == "materialize.py":
            raw = corrected(raw)
        with (HERE / name).open("xb") as stream:
            stream.write(raw)
    with (HERE / "allocation-template.json").open("xb") as stream:
        stream.write((OLD / "allocation-template.json").read_bytes())
    readme = (OLD / "README-ja.md").read_text().replace("smoke-fixture-v2/", "smoke-fixture-v3/")
    readme += "\n\nv3は実parent configを先にexclusive publishし、その正確なFileRefをlaunch.parent_configへ束縛する。monotonicは同じ実pre-submit生成時計であり、既存のcohort/lane config/runtime対応を変更しない。隣接する実進捗通知に必要なcohort.notifyには同じ実allocation issue/threadのみを指定する。v2最初のNOT_STARTEDと全旧packet/namespaceを保持し、作者によるcase実行は0。Rootの新しいcurrent sourceとfresh resource binding後にのみ失敗/未入場caseを実行する。\n"
    with (HERE / "README-ja.md").open("x") as stream:
        stream.write(readme)


def bind():
    prior = ref(OLD / "fixture-binding.json")
    previous = json.loads((OLD / "fixture-binding.json").read_text())
    old_package = json.loads(Path(previous["package"]["path"]).read_text())
    for name in FILES:
        before = (OLD / name).read_bytes()
        post = (HERE / name).read_bytes()
        ast.parse(post)
        assert post == (corrected(before) if name == "materialize.py" else before), name
    before = (OLD / "materialize.py").read_text()
    post = (HERE / "materialize.py").read_text()
    for direction, left, right in [("forward", before, post), ("inverse", post, before)]:
        with (HERE / ("materialize-" + direction + ".patch")).open("x") as stream:
            stream.writelines(
                difflib.unified_diff(
                    left.splitlines(True),
                    right.splitlines(True),
                    fromfile="a/materialize.py",
                    tofile="b/materialize.py",
                )
            )
    # AST-only exact publication dependency: the actual FileRef variable dominates launch.
    tree = ast.parse(post)
    case = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "case")
    parent = next(
        n
        for n in case.body
        if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "parent_config" for t in n.targets)
    )
    launch = next(
        n
        for n in case.body
        if isinstance(n, ast.Expr)
        and isinstance(n.value, ast.Call)
        and any(isinstance(c, ast.Constant) and c.value == "launch.json" for c in ast.walk(n))
    )
    assert case.body.index(parent) < case.body.index(launch)
    launch_dict = launch.value.args[1]
    expected = next(k.value for k in launch_dict.keywords if k.arg == "parent_config")
    assert isinstance(expected, ast.Name) and expected.id == "parent_config"
    package = save(
        HERE / "package-binding.json",
        dict(
            schema=old_package["schema"],
            source_binding=old_package["source_binding"],
            files={name: ref(HERE / name) for name in FILES},
            author_executed_tests_smoke=0,
            causal_derivative_of=prior,
            required_progress_adoption=old_package["required_progress_adoption"],
        ),
    )
    loader = importlib.util.spec_from_file_location(
        "own_text_emitter_v3_only", HERE / "science_fixture.py"
    )
    emitter = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(emitter)  # Pure stdlib text emission, no LC/job imports.
    before = (OLD / "entry-before.py").read_bytes()
    after = emitter.entry_bytes(before, package)
    for name, raw in [("entry-before.py", before), ("entry-after.py", after)]:
        with (HERE / name).open("xb") as stream:
            stream.write(raw)
    for name, left, right in [
        ("entry-forward.footer.patch", before, after),
        ("entry-inverse.footer.patch", after, before),
    ]:
        with (HERE / name).open("x") as stream:
            stream.writelines(
                difflib.unified_diff(
                    left.decode().splitlines(True),
                    right.decode().splitlines(True),
                    fromfile="a/scripts/dev/research-lifecycle.py",
                    tofile="b/scripts/dev/research-lifecycle.py",
                )
            )
    joined = save(
        HERE / "adjacent-metadata-correspondence.json",
        dict(
            production_owner=ref(
                OWN / "configured-progress-repair-v1/post/scripts/dev/research-lifecycle.py"
            ),
            exact_checks=[
                "arena_cohort_lifetime: parent_config equals bound(authority_parent.config_path)",
                "actual parent immutable caller/input: kind cohort, same arena_cohort, canonical argv+intent FileRef, resource_contract==intent_path",
                "complete declared lane issue/goal_issue/thread_id equal actual parent config",
                "launch cohort/member configs/runtime list and finite positive pre-submit monotonic",
                "lane settings canonical body excluding cohort self-ref, job argv/resource_contract and exact lane runtime partition",
            ],
            unchanged_fields=[
                "cohort FileRef",
                "job_configs FileRefs",
                "job_runtimes ordered member list",
                "parent/lane same actual caller",
                "fresh actual pre-submit monotonic clock",
            ],
            additional_concrete_missing_field="arena_cohort_progress send accesses cohort.notify.thread_id/issue; supply same real allocation caller, no notification/control code change",
            actual_runtime_or_test_execution=False,
        ),
    )
    binding = save(
        HERE / "fixture-binding.json",
        dict(
            issue="quoridor-4lc.324.32",
            status="PRIVATE_CAUSAL_MATERIALIZER_V3_UNRUN",
            original_v2=prior,
            package=package,
            before=ref(OLD / "materialize.py"),
            post=ref(HERE / "materialize.py"),
            forward=ref(HERE / "materialize-forward.patch"),
            inverse=ref(HERE / "materialize-inverse.patch"),
            outside_exact_reorder_and_added_fields_bytes_exact=True,
            unchanged_executable_owners=[name for name in FILES if name != "materialize.py"],
            cases=previous["cases"],
            science_substitutions=previous["science_substitutions"],
            adjacent_metadata=joined,
            unique_entry_before=ref(HERE / "entry-before.py"),
            unique_entry_after=ref(HERE / "entry-after.py"),
            forward_footer=ref(HERE / "entry-forward.footer.patch"),
            inverse_footer=ref(HERE / "entry-inverse.footer.patch"),
            restoration=previous["restoration"],
            future_allocation_template=ref(HERE / "allocation-template.json"),
            readme=ref(HERE / "README-ja.md"),
            current_source="Root must bind actual LC58f6007e/388905/0644+fresh resource at entry; no author Main import/read/write",
            previous_failed_original_namespace="v2/runs/Root-normal-smoke-v1 retained immutable, parent NOT_STARTED/no payload",
            tests_smoke_native_Search_model_RNG=0,
            Main_Git_Cargo_docs_writes=0,
            qualifications="source format/lint/parser/custody only; Root actual smoke still required",
        ),
    )
    print(json.dumps(binding))


if __name__ == "__main__":
    globals()[sys.argv[1]]()
