"""Return exact changed permission target and actual source STOP before admin."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402


def run(argv):
    with subprocess.Popen(
        argv, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ) as child:
        stdout, stderr = child.communicate(timeout=60)
        code = child.wait()
    return dict(
        argv=argv,
        exit_code=code,
        stdout=stdout.decode(),
        stderr=stderr.decode(),
        directwait_reaped=True,
        handles_closed=child.stdout.closed and child.stderr.closed,
    )


def main():
    binding = json.loads((OUT / "binding.json").read_text())
    for row in binding["subjects"]:
        for key in ("before", "post"):
            assert ref(row[key]["path"]) == row[key]
    assert ref(binding["fixture_v3_unchanged"]["path"]) == binding["fixture_v3_unchanged"]
    guards, fresh = [], []
    for label in ("inner-authority-source-guard-v1", "inner-authority-source-guard-v2"):
        path = OWN / label / "result.json"
        g = json.loads(path.read_text())
        assert g["TMP_remaining"] == []
        guards.append(ref(path))
        for old in [
            g["controller"],
            *[r["guardian_return"]["child"] for r in g["checks"] if r.get("guardian_return")],
        ]:
            info = process.process_info(old["pid"])
            actual = process.identity(info) if info else None
            assert actual != old
            fresh.append(dict(original=old, actual=actual, exact_absent_or_different=True))
    assert g["status"] == "PASS"
    seen = {}
    for path in [OUT, *OUT.rglob("*")]:
        st = path.lstat()
        seen[(st.st_dev, st.st_ino)] = st.st_blocks * 512
    affected = save(
        OUT / "affected-point.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            root=str(OUT),
            allocated_B=sum(seen.values()),
            inodes=len(seen),
            scope="one new OWN32 authority subtree only, no old run/evidence charge/global walk",
        ),
    )
    stop = save(
        OUT / "source-helper-STOP.json",
        dict(
            at=datetime.now(timezone.utc).isoformat(),
            guards=guards,
            actual_source_reader_STOP=g["reader_STOP"],
            fresh_exact_known_ids=fresh,
            directwait_reap_handles=True,
            remaining=[],
            TMP=[],
            source_leases=[],
            short_SH_NB_released=True,
            CPU=2,
            guardian_CPU=18,
            family_B=1073741824,
            controller_included_B=67108864,
            hostreserve_B=4294967296,
            GPU=0,
            affected_point=affected,
            tests_smoke_native_Search_model_RNG=0,
            Main_Git_Cargo_docs_writes=0,
            target_imports=0,
            futurequiet=False,
            current_light_delivery_separate=True,
        ),
    )
    handoff = save(
        OUT / "handoff.json",
        dict(
            issue="quoridor-4lc.324.32",
            binding=ref(OUT / "binding.json"),
            source_STOP=stop,
            scoped_lint=ref(OUT / "scoped-lint.json"),
            actual_failure_evidence=ref(
                ROOT
                / ".artifacts/research-team/integration324/research-cpu-plan-v1/real-smoke-v2/failure-collection.json"
            ),
            fixture_v3_unchanged=binding["fixture_v3_unchanged"],
            review_questions=[
                "Only registered normal inner command child admitted, same canonical config/intent/settings/index/runtime hash and exact live ancestry; sibling/foreign/stale/reforged caller refused",
                "Parent running/exact identity/authority deadline/cancel checks and old sequence/supervisor callers retained; no startup/environment-only or arbitrary-descendant exemption",
            ],
            software_selectors=binding["selectors"],
            future="Root related sameMax permission-boundary check + sparse canonical adoption + two new selectors + fresh currentLC/resource smoke entry; original14 successful tests not replayed",
            author_qualification="format/lint/parser/exact source correspondence only, no SOURCE_CLEAR/runtime claim",
        ),
    )
    body = OUT / "Root-fixed-handoff.txt"
    body.write_text(
        "SAME32 actual inner authority mismatch fixed privately, not another materializer guess. Preserved turn_context01a15cd0-8667-77b1-9ce6-56539aee148e / Sol6.1high/Main/cwd/workspaces/quoridor/danger-full-access/approval never. Source exact58f6007e/388905/0644, short SH_NB verified/released; only cohort_job_authority production function changed, all outside bytes exact incl current_cpu_owner/CPU/parent cancel/peer/resource/notification/finalize. Job/cycle and fixturev3 byteexact unchanged.\n\nCommon proof retains registered lane/job owner+launcher and parent binding/phase/liveness/authority-deadline/cancel. Sequence and registered inner child share canonical RUN argv, bound intent SHA/settings/cohort/index, exact selected intent path/runtime and cumulative config fingerprint proof. New child additionally MUST be exact inner.state.child in running phase, same actual inner config + lane actual config/hash, actual live sequence-supervisor-command parent chain with PID/start/boot and local lane+inner cancel absent. No directory-none child route or env-only permission, arbitrary descendant, sibling, stale child, foreign config/ancestry, implicit starting-unregistered child acceptance. Existing parent/outer supervisor/sequence callers remain; no production guard removed.\n\nTwo new meaningful definitions reuse existing metadata fixture, invoke actual common cohort_job_authority AND current_cpu_owner. Positive actual registered child plus existing caller routes; negatives foreign/sibling, runtime/config/argv/hash/settings/index/intent path, registration/ancestry/stale identity, running phase, parent authority expiry, parent/lane/inner cancel. They remain UNRUN (no mocks-as-parallel claim). Old test/helper/import bytes untouched; original14 distinct PASS retained without replay. Exact selectors attached for Root narrow verification.\n\nScoped formatter/parser/source custody PASS, production+helper Ruff clean. Whole existing test owner has inherited unchanged E731 at line376; strict before/post diagnostic comparison proves no new lint, baseline not changed/ignored. Initial helper unused-import and inherited-lint attempt preserved FAILED; no test executed. Actual sourcehelperSTOP04:59:37.482700Z CPU2/G18/F1GiBincl64/host4/G0/directwait-reap/handles/TMP/sourceleases[]/fresh IDs stopped. Current lightdelivery separate. Source before/post/forward/inverse/modes + two new UNRUN selectors fixed, no selfclear/authorreviewdispatch.\n\nActualRoot f1f51960 normal lanes/inner startup FAILED-before-mask and complete58f restoration/evidence immutable, no replay or source mutation. Root may route only exact changed permission boundary to SAME Max new related leaf (old32.1 staysclosed), then sparseadopt/test and futurecurrentLC allocation for actual smoke. No scientific Search/model/RNG/game/build/oldproof or oldtest replay; all MPCFAILED/ETC208/no games/costs/pauses/seals/defaults/models/foreign50GB held.\n\n"
        + json.dumps(
            dict(
                handoff=handoff,
                binding=ref(OUT / "binding.json"),
                source_STOP=stop,
                delivery_guard=str(OWN / "inner-authority-delivery-guard-v1/result.json"),
            ),
            indent=2,
        )
        + "\n"
    )
    argv = [
        "bash",
        "scripts/dev/research-session.sh",
        "send",
        "--thread",
        "01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "--issue",
        "quoridor-4lc.324",
        "--cwd",
        str(ROOT),
        "--body-file",
        str(body),
    ]
    delivered = run(argv)
    save(OUT / "Root-delivery.json", delivered)
    if delivered["exit_code"] != 0 and "no active turn to steer" in delivered["stderr"]:
        delivered = run(argv)
        save(OUT / "Root-delivery-causal-race-v2.json", delivered)
    assert delivered["exit_code"] == 0, delivered
    shown = run(["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.324.32", "--json"])
    assert shown["exit_code"] == 0, shown
    issue = json.loads(shown["stdout"])
    issue = issue[0] if isinstance(issue, list) else issue
    assert (
        issue["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
        and issue["status"] == "in_progress"
    )
    save(OUT / "beads-show.json", shown)
    note = run(
        [
            "bash",
            "scripts/dev/beads.sh",
            "update",
            "quoridor-4lc.324.32",
            "--append-notes",
            "Actual normal inner child permission mismatch private sparse repair fixed against58f: only cohort_job_authority changes; registered exact running inner child joins canonical intent/settings/index/runtime/config hash + live sequence/supervisor ancestry, no local cancel, parent authority unchanged. Fixturev3 and other source exact; two new meaningful actualcallee boundary definitions UNRUN, original14 PASS no replay. Scopedformat/parser/productionlint PASS, inherited test E731 unchanged/no new diagnostics. Actual sourcehelper STOP04:59:37.482700Z/CPU2G18/F1Gincl64/host4G/G0/directwait-reap/handles/TMPleases[]/freshIDs. Author Main/test/smoke0, no selfclear. Packet "
            + str(OUT / "handoff.json"),
        ]
    )
    save(OUT / "beads-note.json", note)
    assert note["exit_code"] == 0, note
    backup = run(["bash", "scripts/dev/beads.sh", "backup", "sync", "--json"])
    save(OUT / "beads-backup.json", backup)
    assert backup["exit_code"] == 0, backup
    removed = []
    for path in Path(os.environ["TMPDIR"]).iterdir():
        assert (
            path.is_file()
            and path.stat().st_size == 0
            and path.name.startswith("uv-")
            and path.name.endswith(".lock")
        )
        with path.open("rb") as stream:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            path.unlink()
        removed.append(str(path))
    save(OUT / "delivery-TMP-cleanup.json", dict(removed=removed))
    print(json.dumps(handoff))


if __name__ == "__main__":
    main()
