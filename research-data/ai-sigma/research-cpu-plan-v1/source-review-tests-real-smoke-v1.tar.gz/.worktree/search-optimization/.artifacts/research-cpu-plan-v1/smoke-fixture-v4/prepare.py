"""Exactly the three original cleanup-failed cases; preserve all original eight evidence."""

import ast
import difflib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
OWN = HERE.parent
OLD = OWN / "smoke-fixture-v3"
REPAIR = OWN / "exception-cleanup-repair-v1"
PRIOR = OLD / "runs/Root-normal-smoke-v2"
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

FILES = ("science_fixture.py", "materialize.py", "mask_payload.py", "assess.py", "coordinator.py")
REPAIR_CASES = ("outside_thread", "child_failure", "parent_cancel")
PRIOR_PASS = ("two_lane", "single_lane", "bad_unavailable", "bad_smt", "bad_overlap")


def coordinator_v4(raw):
    text = raw.decode()
    anchor = "HERE = Path(__file__).resolve().parent\n"
    assert text.count(anchor) == 1
    text = text.replace(
        anchor, anchor + 'REPAIR_CASES = ("outside_thread", "child_failure", "parent_cancel")\n', 1
    )
    anchor = "            for label in CASES:\n"
    assert text.count(anchor) == 1
    text = text.replace(anchor, "            for label in REPAIR_CASES:\n", 1)
    anchor = """                all_cases=len(records) == len(CASES),
                restored=(output / "actual-restored.json").exists(),
                full_normal_parallel_PASS=len(records) == len(CASES)
                and all(r["qualification"] == "PASS" for r in records),
"""
    replacement = """                all_original_eight_cases=False,
                original_case_order=CASES,
                selected_cleanup_cases=REPAIR_CASES,
                all_selected_cases=len(records) == len(REPAIR_CASES),
                original_all8_failure=package["original_all8_failure"],
                prior_successful_case_receipts=package["prior_successful_case_receipts"],
                restored=(output / "actual-restored.json").exists(),
                repaired_cleanup_cases_PASS=len(records) == len(REPAIR_CASES)
                and all(r["qualification"] == "PASS" for r in records),
                full_normal_parallel_PASS=False,
                combined_acceptance="Root assesses preserved prior5 plus actual repaired3/source correspondence; never restamp original8 exit1",
"""
    assert text.count(anchor) == 1
    text = text.replace(anchor, replacement, 1)
    anchor = """    assert len(records) == len(CASES) and all(r["qualification"] == "PASS" for r in records), (
"""
    assert text.count(anchor) == 1
    text = text.replace(
        anchor,
        """    assert len(records) == len(REPAIR_CASES) and all(r["qualification"] == "PASS" for r in records), (
""",
        1,
    )
    return text.encode()


def edit():
    assert (
        ref(OLD / "fixture-binding.json")["sha256"]
        == "c2a440e5a7fac476e105c4ad655ff87d709d9ed360da25384795d5c3c82414cc"
    )
    for name in FILES:
        raw = (OLD / name).read_bytes()
        if name == "coordinator.py":
            raw = coordinator_v4(raw)
        with (HERE / name).open("xb") as f:
            f.write(raw)
    with (HERE / "allocation-template.json").open("xb") as f:
        f.write((OLD / "allocation-template.json").read_bytes())
    text = (OLD / "README-ja.md").read_text().replace("smoke-fixture-v3/", "smoke-fixture-v4/")
    text += "\n\nv4の実行対象は元のcleanup未完了3case（outside_thread/child_failure/parent_cancel）のみ。2lane/single/invalid CPUの既存5PASSは保存済みassessmentへの固定参照であり再実行しない。元の全8coordinator exit1/fullnormalPASSfalseと6空TMPは書き換え・削除しない。今回の出力はrepaired_cleanup_cases_PASSのみを示し、full_normal_parallel_PASSはfalseのまま。全体の受入れはRootが5旧receiptと3実修復出力・現在source対応を評価する。\n\nsource-binding-cleanup-composition.jsonは固定62d5+実651権限修正へ今回のexception cleanup postを疎に合わせたソース対応であり、actual adoption/software/SOURCE_CLEARの捏造ではない。Rootが採用したLCとcycleの正確なcurrent ref、fresh実resourceをallocationへ束縛した後だけ実行する。CPU/permission/authority/resource/peer/Popen/cancel/normal finalize/assessment/science置換は同じ実経路であり、例外outcomeを通常guardian return/capture成功へ昇格しない。\n"
    # The original description is retained as provenance; this amendment governs the selected run.
    with (HERE / "README-ja.md").open("x") as f:
        f.write(text)


def bind():
    old_binding = json.loads((OLD / "fixture-binding.json").read_text())
    old_package = json.loads(Path(old_binding["package"]["path"]).read_text())
    source = json.loads(Path(old_package["source_binding"]["path"]).read_text())
    repaired = json.loads((REPAIR / "final-binding.json").read_text())
    replacements = {r["subject"]: r["post"] for r in repaired["subjects"]}
    for row in source["subjects"]:
        if row["subject"] in replacements:
            row["post"] = replacements[row["subject"]]
    source.update(
        status="PRIVATE_THIN_CLEANUP_SOURCE_CORRESPONDENCE_NOT_CURRENT_ADOPTION",
        original_frozen_CPU_binding=old_package["source_binding"],
        causal_cleanup_binding=ref(REPAIR / "final-binding.json"),
        actual_adoption_software="Root only; no author qualification claim",
    )
    source_ref = save(HERE / "source-binding-cleanup-composition.json", source)
    receipts = {}
    for label in PRIOR_PASS:
        r = ref(PRIOR / label / "assessment.json")
        data = json.loads(Path(r["path"]).read_text())
        assert data["label"] == label and data["qualification"] == "PASS"
        receipts[label] = r
    original = ref(PRIOR / "coordinator-return.json")
    assert json.loads(Path(original["path"]).read_text())["full_normal_parallel_PASS"] is False
    for name in FILES:
        before = (OLD / name).read_bytes()
        after = (HERE / name).read_bytes()
        ast.parse(after)
        if name == "coordinator.py":
            # Ruff may line-wrap the new selected-scope reporting; compare complete AST to exact intended derivative.
            assert ast.dump(ast.parse(after), include_attributes=False) == ast.dump(
                ast.parse(coordinator_v4(before)), include_attributes=False
            )
        else:
            assert before == after, name
    for direction, left, right in [
        ("forward", (OLD / "coordinator.py").read_text(), (HERE / "coordinator.py").read_text()),
        ("inverse", (HERE / "coordinator.py").read_text(), (OLD / "coordinator.py").read_text()),
    ]:
        with (HERE / ("coordinator-" + direction + ".patch")).open("x") as f:
            f.writelines(
                difflib.unified_diff(
                    left.splitlines(True),
                    right.splitlines(True),
                    fromfile="a/coordinator.py",
                    tofile="b/coordinator.py",
                )
            )
    package = save(
        HERE / "package-binding.json",
        dict(
            schema=old_package["schema"],
            source_binding=source_ref,
            files={name: ref(HERE / name) for name in FILES},
            author_executed_tests_smoke=0,
            causal_derivative_of=ref(OLD / "fixture-binding.json"),
            original_all8_failure=original,
            prior_successful_case_receipts=receipts,
            selected_original_failed_cleanup_cases=REPAIR_CASES,
        ),
    )
    loader = importlib.util.spec_from_file_location(
        "own_v4_text_emitter_only", HERE / "science_fixture.py"
    )
    emitter = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(emitter)
    before = (OLD / "entry-before.py").read_bytes()
    after = emitter.entry_bytes(before, package)
    for name, raw in [("entry-before.py", before), ("entry-after.py", after)]:
        with (HERE / name).open("xb") as f:
            f.write(raw)
    for name, left, right in [
        ("entry-forward.footer.patch", before, after),
        ("entry-inverse.footer.patch", after, before),
    ]:
        with (HERE / name).open("x") as f:
            f.writelines(
                difflib.unified_diff(
                    left.decode().splitlines(True),
                    right.decode().splitlines(True),
                    fromfile="a/scripts/dev/research-lifecycle.py",
                    tofile="b/scripts/dev/research-lifecycle.py",
                )
            )
    binding = save(
        HERE / "fixture-binding.json",
        dict(
            issue="quoridor-4lc.324.32",
            status="PRIVATE_ONLY_ORIGINAL3_CLEANUP_CASES_UNRUN",
            original_v3=ref(OLD / "fixture-binding.json"),
            package=package,
            source_composition=source_ref,
            required_cleanup=ref(REPAIR / "final-binding.json"),
            selected_cases=REPAIR_CASES,
            prior5_receipts=receipts,
            original8_failed_receipt=original,
            coordinator_before=ref(OLD / "coordinator.py"),
            coordinator_post=ref(HERE / "coordinator.py"),
            coordinator_forward=ref(HERE / "coordinator-forward.patch"),
            coordinator_inverse=ref(HERE / "coordinator-inverse.patch"),
            unchanged_executable_owners=[name for name in FILES if name != "coordinator.py"],
            only_coordinator_changes="fixed 3case selection+truthful scoped reporting/reference links, actual job/control/wait/restore unchanged",
            footer_forward=ref(HERE / "entry-forward.footer.patch"),
            footer_inverse=ref(HERE / "entry-inverse.footer.patch"),
            readme=ref(HERE / "README-ja.md"),
            Root_current_refs="NULL until actual new LC/cycle adoption and fresh allocation, no testmode/control exemption",
            fullnormal="this invocation only3, never full8 green; Root combined assessment separately",
            tests_smoke_native_Search_model_RNG=0,
            Main_Git_Cargo_docs_writes=0,
        ),
    )
    print(json.dumps(binding))


if __name__ == "__main__":
    globals()[sys.argv[1]]()
