"""Only actual post-finally exception cleanup transport, private and UNRUN."""

import ast
import difflib
import fcntl
import os
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
ROOT = Path("/workspaces/quoridor")
sys.path.insert(0, str(OWN))
from intake import ref, save  # noqa: E402

LC = "scripts/dev/research-lifecycle.py"
CYCLE = "python/quoridor_training/cycle_process.py"
TEST = "tools/research-session/test_exception_cleanup_outcome.py"


def part(text, name):
    n = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == name)
    lines = text.splitlines(True)
    return (
        "".join(lines[: n.lineno - 1]),
        "".join(lines[n.lineno - 1 : n.end_lineno]),
        "".join(lines[n.end_lineno :]),
    )


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as f:
        f.write(text)


def intake():
    assert os.sched_getaffinity(0) == {2}
    sources = {LC: OWN / "inner-authority-repair-v1/post" / LC, CYCLE: OWN / "post-v3" / CYCLE}
    assert (
        ref(sources[LC])["sha256"]
        == "651fe276e6e155768520c45d078fb27a93af849f61d3f68f07f3351fc7e7645f"
    )
    assert (
        ref(sources[CYCLE])["sha256"]
        == "98dfd2cc8f2cf6eef4d3dabd450f5b3d0308da5771f2fe32ad2af1583494dff3"
    )
    current = []
    with (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        for subject, source in sources.items():
            r = ref(ROOT / subject)
            assert all(r[k] == ref(source)[k] for k in ("sha256", "bytes", "mode"))
            write(OUT / "before" / subject, source.read_text())
            current.append(r)
        assert not (ROOT / TEST).exists()
        fcntl.flock(lock, fcntl.LOCK_UN)
    save(
        OUT / "intake.json",
        dict(
            current=current,
            short_SH_NB_released=True,
            Main_writes=0,
            target_imports=0,
            tests_smoke=0,
        ),
    )


def edit():
    _, body, _ = part((OUT / "before" / CYCLE).read_text(), "execute")
    old = """        raise group
    if failure:
        raise failure
    if resources:
        resources.check()
    return record
"""
    new = """        group.cycle_cleanup_outcome = {"normal_return": False, "record": dict(record)}
        raise group
    if failure:
        failure.cycle_cleanup_outcome = {"normal_return": False, "record": dict(record)}
        raise failure
    if resources:
        try:
            resources.check()
        except BaseException as error:
            error.cycle_cleanup_outcome = {"normal_return": False, "record": dict(record)}
            raise
    return record
"""
    assert body.count(old) == 1
    write(OUT / "cycle-execute.scoped.py", body.replace(old, new))
    original = (OUT / "before" / LC).read_text()
    _, body, _ = part(original, "command")
    old = """    except BaseException as error:
        primary = error
    if capture is not None:
"""
    new = """    except BaseException as error:
        primary = error
        # This is an actual exception after execute's finally, not a normal
        # guardian return or evidence reconstructed from a pre-final disk record.
        outcome = getattr(error, "cycle_cleanup_outcome", None)
        if outcome is not None:
            if (
                isinstance(outcome, dict)
                and outcome.get("normal_return") is False
                and isinstance(outcome.get("record"), dict)
                and outcome["record"].get("command") == [str(arg) for arg in row["argv"]]
            ):
                check["guardian_exception_outcome"] = outcome
            else:
                check["secondary"].append(
                    {"stage": "guardian_exception_outcome", "type": "Refused", "message": "exception cleanup does not join this actual command"}
                )
    if capture is not None:
"""
    assert body.count(old) == 1
    write(OUT / "command.scoped.py", body.replace(old, new))
    _, body, _ = part(original, "remove_empty_owned_tmp")
    old = "def remove_empty_owned_tmp(path, owner, guardian_return):\n"
    new = "def remove_empty_owned_tmp(path, owner, guardian_return, *, exception_outcome=None):\n"
    assert body.count(old) == 1
    body = body.replace(old, new)
    old = "    path = owned(path, owner)\n"
    new = """    path = owned(path, owner)
    if guardian_return is None:
        require(
            isinstance(exception_outcome, dict)
            and exception_outcome.get("normal_return") is False,
            "owned TMP cleanup requires actual exception cleanup transport",
        )
        guardian_return = exception_outcome.get("record")
        require(
            isinstance(guardian_return, dict)
            and guardian_return.get("signal_mask_restoration") == "completed"
            and guardian_return.get("final_record_persist") == "completed"
            and guardian_return.get("finalization_errors", []) == [],
            "exception guardian finalization incomplete",
        )
"""
    assert body.count(old) == 1
    write(OUT / "tmp.scoped.py", body.replace(old, new))
    _, body, _ = part(original, "execute")
    old = """                            if result["checks"]
                            else None,
                        )
"""
    new = """                            if result["checks"]
                            else None,
                            exception_outcome=result["checks"][-1].get("guardian_exception_outcome")
                            if result["checks"]
                            else None,
                        )
"""
    assert body.count(old) == 1
    write(OUT / "lifecycle-execute.scoped.py", body.replace(old, new))


def bind():
    subjects = []
    changes = {
        CYCLE: {"execute": "cycle-execute.scoped.py"},
        LC: {
            "command": "command.scoped.py",
            "remove_empty_owned_tmp": "tmp.scoped.py",
            "execute": "lifecycle-execute.scoped.py",
        },
    }
    for subject, names in changes.items():
        original = (OUT / "before" / subject).read_text()
        post = original
        for name, source in names.items():
            h, b, t = part(post, name)
            post = h + (OUT / source).read_text().rstrip("\n") + "\n" + t
        for n in ast.parse(original).body:
            if isinstance(n, ast.FunctionDef) and n.name not in names:
                assert part(original, n.name)[1] == part(post, n.name)[1], n.name
        # Remove changed functions exactly: all imports/classes/inter-function/outside bytes stay equal.
        left = original
        right = post
        for name in names:
            h, b, t = part(left, name)
            left = h + f"def {name}():\n    pass\n" + t
            h, b, t = part(right, name)
            right = h + f"def {name}():\n    pass\n" + t
        assert left == right
        write(OUT / "post" / subject, post)
        subjects.append(
            dict(
                subject=subject,
                before=ref(OUT / "before" / subject),
                post=ref(OUT / "post" / subject),
            )
        )
    write(OUT / "post" / TEST, (OUT / "new-tests.py").read_text())
    subjects.append(dict(subject=TEST, before=None, post=ref(OUT / "post" / TEST)))
    for subject in [CYCLE, LC, TEST]:
        a = (OUT / "before" / subject).read_text() if (OUT / "before" / subject).exists() else ""
        b = (OUT / "post" / subject).read_text()
        ast.parse(b)
        for direction, left, right in [("forward", a, b), ("inverse", b, a)]:
            with (OUT / (direction + ".patch")).open("a") as f:
                f.writelines(
                    difflib.unified_diff(
                        left.splitlines(True),
                        right.splitlines(True),
                        fromfile="a/" + subject if left else "/dev/null",
                        tofile="b/" + subject if right else "/dev/null",
                    )
                )
    # Actual normal-return success path statements remain unchanged (plus only an exception wrapper for post-check failure).
    before = (OUT / "before" / CYCLE).read_text()
    after = (OUT / "post" / CYCLE).read_text()
    assert (
        part(before, "execute")[1].split("    if final_errors:\n")[:-1]
        == part(after, "execute")[1].split("    if final_errors:\n")[:-1]
    )
    save(
        OUT / "binding.json",
        dict(
            issue="quoridor-4lc.324.32",
            status="PRIVATE_EXCEPTION_CLEANUP_TRANSPORT_UNRUN",
            subjects=subjects,
            forward=ref(OUT / "forward.patch"),
            inverse=ref(OUT / "inverse.patch"),
            changed_functions=changes,
            outside_changed_functions_bytes_exact=True,
            normal_success_admission="guardian_return/settled/record/capture_complete unchanged; no exception outcome used for PASS",
            exception_transport="actual in-memory after-finally snapshot only, separate guardian_exception_outcome, never inferred from disk/pending receipt",
            TMP="only own empty directories after exact command-bound exception cleanup with reap/handles/remaining plus final signal/persist/no finalization errors",
            permission_CPU_peer_bodies="byteexact to actual651/job13a2/cycle98df except execute failure tail and TMP channel",
            selectors=[
                "test_exception_cleanup_outcome.ExceptionCleanupOutcomeTests.test_failed_and_cancelled_execute_transports_after_finally_without_success",
                "test_exception_cleanup_outcome.ExceptionCleanupOutcomeTests.test_finalization_failure_keeps_tmp_and_preserves_primary",
                "test_exception_cleanup_outcome.ExceptionCleanupOutcomeTests.test_pending_disk_and_incomplete_exception_proof_refuse_tmp_removal",
            ],
            tests_smoke_native_Search_model_RNG=0,
            Main_Git_Cargo_docs_writes=0,
        ),
    )


if __name__ == "__main__":
    globals()[sys.argv[1]]()
