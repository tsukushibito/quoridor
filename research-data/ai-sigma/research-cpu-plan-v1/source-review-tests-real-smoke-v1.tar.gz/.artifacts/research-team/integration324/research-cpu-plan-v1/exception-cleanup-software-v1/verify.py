"""Run only three new cleanup tests in a fresh interpreter after adoption."""

import hashlib
import json
from pathlib import Path
import sys
import unittest

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOURCE = (
    ROOT
    / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/exception-cleanup-repair-v1"
)
sys.path.insert(0, str(ROOT / "tools/research-session"))
binding = json.loads((SOURCE / "final-binding.json").read_bytes())
for row in binding["subjects"]:
    raw = (ROOT / row["subject"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row["post"]["sha256"]
suite = unittest.defaultTestLoader.loadTestsFromNames(binding["selectors"])
with (OUT / "unittest.log").open("x") as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
value = dict(
    selectors=binding["selectors"],
    tests=result.testsRun,
    failures=len(result.failures),
    errors=len(result.errors),
    success=result.wasSuccessful(),
    prior16_not_replayed=True,
    qualification="New tiny real Python guardian failure/cancel plus injected finalization/unknown proof; not normal parallel smoke",
    Search_model_arena_RNG=0,
)
(OUT / "result.json").write_text(json.dumps(value, indent=2) + "\n")
print(json.dumps(value))
assert result.wasSuccessful() and result.testsRun == 3
