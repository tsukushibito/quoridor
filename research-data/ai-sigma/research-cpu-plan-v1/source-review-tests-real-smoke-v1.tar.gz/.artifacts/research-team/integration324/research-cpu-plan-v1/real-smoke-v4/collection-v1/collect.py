"""Collect actual stopped dummy receipts, without replaying normal operations."""

import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
RUN = (
    ROOT
    / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/smoke-fixture-v4/runs/Root-normal-cleanup-v1"
)


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    loader = importlib.util.spec_from_file_location(
        "cpu_collect_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    with lc.lease():
        result = json.loads((RUN / "coordinator-return.json").read_bytes())
        assert result["repaired_cleanup_cases_PASS"] and result["restored"]
        assert not result["full_normal_parallel_PASS"]
        package = json.loads((RUN.parents[1] / "package-binding.json").read_bytes())
        prior = package["prior_successful_case_receipts"]
        cases = []
        identities = {}
        for label, value in prior.items():
            assert ref(Path(value["path"])) == value
            row = json.loads(Path(value["path"]).read_bytes())
            assert row["qualification"] == "PASS"
            cases.append(dict(label=label, assessment=value, invocation="original5_not_replayed"))
            for identity in row["known_identities"]:
                identities[(identity["pid"], identity["start_ticks"], identity["boot_id"])] = (
                    identity
                )
        for row in result["records"]:
            assert row["qualification"] == "PASS" and row["remaining"] == row["TMP_remaining"] == []
            assert not row["inherited_scientific_progress_errors"]
            cases.append(
                dict(
                    label=row["label"],
                    assessment=ref(RUN / row["label"] / "assessment.json"),
                    invocation="repaired3",
                )
            )
            for identity in row["known_identities"]:
                identities[(identity["pid"], identity["start_ticks"], identity["boot_id"])] = (
                    identity
                )
        outer_path = OUT.parent / "actual-returned-STOP.json"
        outer = json.loads(outer_path.read_bytes())["actual_return"]
        assert (
            outer["exit_code"] == 0
            and outer["direct_child_reaped"]
            and outer["cleanup_complete"]
            and not outer["remaining"]
        )
        identity = outer["child"]
        identities[(identity["pid"], identity["start_ticks"], identity["boot_id"])] = identity
        assert all(not lc.process.alive(identity) for identity in identities.values())
        restored = json.loads((RUN / "actual-restored.json").read_bytes())
        assert restored["exact_bytes"] and restored["exact_mode"]
        assert ref(ROOT / "scripts/dev/research-lifecycle.py") == restored["actual"]
        assert (
            restored["actual"]["sha256"]
            == "9a044d44d678c60d556b480354c3d39527596587cbf6c730eb4d303ddbfca41e"
        )
        assert (
            ref(ROOT / "python/quoridor_training/cycle_process.py")["sha256"]
            == "e88f019cb86f0738ec2f50af8c5cc54e3ce668cd011d936d0f48aff23b2d3f55"
        )
        value = dict(
            issue="quoridor-4lc.324.32",
            status="ALL8_NORMAL_CPU_PROCESS_CASES_QUALIFIED_WITH_CAUSAL_CORRESPONDENCE",
            normal_parallel_qualification=True,
            cases=cases,
            original5_not_replayed=True,
            original_all8_failure=package["original_all8_failure"],
            repaired3_return=ref(RUN / "coordinator-return.json"),
            actual_outer=ref(outer_path),
            repaired3_outer_seconds_once=outer["wall_seconds"],
            original8_outer_seconds_once=69.45413811889011,
            earlier_failed_outer_seconds_once=[1.0011086580343544, 5.064095334033482],
            nested_not_added=True,
            full_fees="UNKNOWN",
            source_restored=restored,
            all_saved_exact_identities_fresh_absent_or_different=list(identities.values()),
            remaining=[],
            TMP_remaining=[],
            source_leases=[],
            host_future_quiet=False,
            original_failed_records_and_empty_TMP_unchanged=True,
            Search_model_arena_RNG=0,
            limits="Real dummy controls/ownership/process collection; not scientific/native engine or full historical MPC cause proof",
        )
        (OUT / "normal-source-STOP.json").write_text(json.dumps(value, indent=2) + "\n")
    print(
        json.dumps(
            {
                k: value[k]
                for k in ["status", "normal_parallel_qualification", "repaired3_outer_seconds_once"]
            }
        )
    )


if __name__ == "__main__":
    main()
