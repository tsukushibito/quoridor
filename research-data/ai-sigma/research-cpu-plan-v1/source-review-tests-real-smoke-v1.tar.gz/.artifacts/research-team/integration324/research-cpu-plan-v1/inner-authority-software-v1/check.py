"""Adopt strict registered inner authority and run its two new boundary tests."""

import ast
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOURCE = (
    ROOT / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/inner-authority-repair-v1"
)
sys.path.insert(0, str(ROOT / "tools/research-session"))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def definitions(raw):
    lines = raw.splitlines(keepends=True)
    return {
        n.name: b"".join(lines[n.lineno - 1 : n.end_lineno])
        for n in ast.parse(raw).body
        if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name != "cohort_job_authority"
    }


def main():
    refs = load("refs", OUT.parents[1] / "cedar-etc-v1/adoption-v1/adopt.py")
    lc = load("lc_progress", ROOT / "scripts/dev/research-lifecycle.py")
    packet = SOURCE / "binding.json"
    assert (
        refs.ref(packet)["sha256"]
        == "33c3eefed70eaf7bb9898d709a7ff13b0b166dba87e19526f408d48c19d048f0"
    )
    binding = json.loads(packet.read_bytes())
    with lc.lease():
        before = (ROOT / "scripts/dev/research-lifecycle.py").read_bytes()
        for row in binding["subjects"]:
            actual = refs.ref(ROOT / row["subject"])
            assert all(actual[k] == row["before"][k] for k in ("sha256", "bytes", "mode"))
            lc.read_ref(row["post"])
        lc.read_ref(binding["forward"])
        subprocess.run(
            ["git", "apply", "--check", binding["forward"]["path"]],
            cwd=ROOT,
            check=True,
        )
        subprocess.run(["git", "apply", binding["forward"]["path"]], cwd=ROOT, check=True)
        for row in binding["subjects"]:
            assert all(
                refs.ref(ROOT / row["subject"])[k] == row["post"][k]
                for k in ("sha256", "bytes", "mode")
            )
        assert definitions(before) == definitions(
            (ROOT / "scripts/dev/research-lifecycle.py").read_bytes()
        )
        with (OUT / "adoption.json").open("x") as stream:
            stream.write(
                json.dumps(
                    dict(
                        binding=refs.ref(packet),
                        post=[refs.ref(ROOT / r["subject"]) for r in binding["subjects"]],
                        all_other_control_functions_byteexact=True,
                        source_leases=[],
                    ),
                    indent=2,
                )
                + "\n"
            )
    with lc.lease(shared=True):
        suite = unittest.defaultTestLoader.loadTestsFromNames(binding["selectors"])
        with (OUT / "unittest.log").open("x") as stream:
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
        record = dict(
            selectors=binding["selectors"],
            tests=result.testsRun,
            failures=len(result.failures),
            errors=len(result.errors),
            success=result.wasSuccessful(),
            qualification="Two new synthetic actual-helper authority definitions; prior14 retained, actual normal parallel smoke still unqualified",
            source_leases=[],
            native_Search_model_RNG=0,
        )
        with (OUT / "result.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))
    assert result.wasSuccessful() and result.testsRun == 2


if __name__ == "__main__":
    main()
