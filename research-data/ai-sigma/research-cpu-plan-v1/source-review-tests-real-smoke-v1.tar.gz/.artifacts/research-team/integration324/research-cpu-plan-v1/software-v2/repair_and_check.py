"""Adopt the two fixture repairs and rerun only their failed selectors."""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOURCE = (
    ROOT
    / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/test-fixture-repair-v1"
)
sys.path[:0] = [str(ROOT / "scripts/dev"), str(ROOT / "tools/research-session")]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    refs = load("refs", OUT.parents[1] / "cedar-etc-v1/adoption-v1/adopt.py")
    lc = load("lc_fixture", ROOT / "scripts/dev/research-lifecycle.py")
    packet = SOURCE / "binding.json"
    assert (
        refs.ref(packet)["sha256"]
        == "64282aaae684de2886a8c6411c5cdb49c348c545c38ef663a21493b044af0b80"
    )
    binding = json.loads(packet.read_bytes())
    stop = SOURCE / "source-helper-STOP.json"
    assert (
        refs.ref(stop)["sha256"]
        == "c5b3ab7cd24a5aece2186598f74680b2be6da4dcd6a07e9a6a01f1227a1ae1a2"
    )
    with lc.lease():
        for row in binding["subjects"]:
            actual = refs.ref(ROOT / row["subject"])
            assert all(
                actual[k] == row["before"][k] for k in ("sha256", "bytes", "mode")
            )
            lc.read_ref(row["post"])
        lc.read_ref(binding["forward"])
        subprocess.run(
            ["git", "apply", "--check", binding["forward"]["path"]],
            cwd=ROOT,
            check=True,
        )
        subprocess.run(
            ["git", "apply", binding["forward"]["path"]], cwd=ROOT, check=True
        )
        for row in binding["subjects"]:
            actual = refs.ref(ROOT / row["subject"])
            assert all(actual[k] == row["post"][k] for k in ("sha256", "bytes", "mode"))
        with (OUT / "adoption.json").open("x") as stream:
            stream.write(
                json.dumps(
                    dict(
                        binding=refs.ref(packet),
                        actual_source_STOP=refs.ref(stop),
                        adopted=[
                            refs.ref(ROOT / r["subject"]) for r in binding["subjects"]
                        ],
                        production_changes=0,
                        source_leases=[],
                    ),
                    indent=2,
                )
                + "\n"
            )
    with lc.lease(shared=True):
        suite = unittest.defaultTestLoader.loadTestsFromNames(binding["selectors"])
        with (OUT / "unittest.log").open("x") as stream:
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
        original = OUT.parent / "software-v1/result.json"
        prior = json.loads(original.read_bytes())
        assert prior["tests"] == 13 and prior["errors"] == 2 and prior["failures"] == 0
        record = dict(
            selectors=binding["selectors"],
            tests=result.testsRun,
            errors=len(result.errors),
            failures=len(result.failures),
            success=result.wasSuccessful(),
            prior_11_PASS_reused=refs.ref(original),
            prior_failure_preserved=True,
            qualification="13 distinct limited synthetic tests:11 prior PASS plus actual two repaired selectors. Not real normal parallel smoke.",
            source_leases=[],
            native_Search_model_RNG=0,
        )
        with (OUT / "result.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))
    assert result.wasSuccessful() and result.testsRun == 2


if __name__ == "__main__":
    main()
