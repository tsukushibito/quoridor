"""Apply the exact cleanup suffix, then exec fresh Python for its new tests."""

import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOURCE = (
    ROOT
    / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/exception-cleanup-repair-v1"
)


def ref(path):
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def definitions(raw, excluded):
    lines = raw.splitlines(keepends=True)
    return {
        node.name: b"".join(lines[node.lineno - 1 : node.end_lineno])
        for node in ast.parse(raw).body
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name not in excluded
    }


def main():
    path = SOURCE / "final-binding.json"
    assert ref(path)["sha256"] == "acb1c9c6e282d420e719f8e5d05356c5843889ad8a91b258f834f34f258fc492"
    binding = json.loads(path.read_bytes())
    spec = importlib.util.spec_from_file_location(
        "cleanup_adopt_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lc)
    before = {}
    with lc.lease():
        for row in binding["subjects"]:
            subject = ROOT / row["subject"]
            if row["before"] is None:
                assert not subject.exists()
            else:
                assert all(ref(subject)[k] == row["before"][k] for k in ("sha256", "bytes", "mode"))
                before[row["subject"]] = subject.read_bytes()
            assert ref(Path(row["post"]["path"])) == row["post"]
        assert ref(Path(binding["forward"]["path"])) == binding["forward"]
        subprocess.run(
            ["git", "apply", "--check", binding["forward"]["path"]], cwd=ROOT, check=True
        )
        subprocess.run(["git", "apply", binding["forward"]["path"]], cwd=ROOT, check=True)
        for row in binding["subjects"]:
            subject = ROOT / row["subject"]
            assert all(ref(subject)[k] == row["post"][k] for k in ("sha256", "bytes", "mode"))
            if row["subject"] in before:
                excluded = binding["changed_functions"][row["subject"]]
                assert definitions(before[row["subject"]], excluded) == definitions(
                    subject.read_bytes(), excluded
                )
        (OUT / "adoption.json").write_text(
            json.dumps(
                dict(
                    binding=ref(path),
                    current=[ref(ROOT / r["subject"]) for r in binding["subjects"]],
                    all_other_functions_byteexact=True,
                    source_leases=[],
                ),
                indent=2,
            )
            + "\n"
        )
    # No cached pre-adoption cycle module may qualify the new cleanup transport.
    os.execv(sys.executable, [sys.executable, "-B", str(OUT / "verify.py")])


if __name__ == "__main__":
    main()
