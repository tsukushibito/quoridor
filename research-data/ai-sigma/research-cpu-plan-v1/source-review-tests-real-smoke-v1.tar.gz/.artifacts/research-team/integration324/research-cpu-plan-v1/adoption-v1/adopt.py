"""Apply the exact reviewed CPU source packet under the common source lease."""

import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/fixed-v3"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    refs = load("refs", OUT.parents[1] / "cedar-etc-v1/adoption-v1/adopt.py")
    lc = load("lc", ROOT / "scripts/dev/research-lifecycle.py")
    packet = SOURCE / "source-binding.json"
    assert (
        refs.ref(packet)["sha256"]
        == "62d5fabf1030ebe55ccda9d8c46683f470d2edf9c4213ad416ae9a9f4bb33d81"
    )
    binding = json.loads(packet.read_bytes())
    acceptance = json.loads(
        (OUT.parent / "source-review-v1/Root-source-acceptance.json").read_bytes()
    )
    assert acceptance["status"] == "SOURCE_CLEAR_ACCEPTED_SOFTWARE_UNRUN"
    assert acceptance["binding"] == refs.ref(packet)
    with lc.lease():
        before = []
        for row in binding["subjects"]:
            path = ROOT / row["subject"]
            if row["before"] is None:
                assert not path.exists()
                actual = None
            else:
                actual = refs.ref(path)
                assert all(
                    actual[k] == row["before"][k] for k in ("sha256", "bytes", "mode")
                )
            lc.read_ref(row["post"])
            before.append(dict(subject=row["subject"], actual=actual))
        lc.read_ref(binding["forward"])
        subprocess.run(
            ["git", "apply", "--check", binding["forward"]["path"]],
            cwd=ROOT,
            check=True,
        )
        subprocess.run(
            ["git", "apply", binding["forward"]["path"]], cwd=ROOT, check=True
        )
        after = []
        for row in binding["subjects"]:
            actual = refs.ref(ROOT / row["subject"])
            assert all(actual[k] == row["post"][k] for k in ("sha256", "bytes", "mode"))
            after.append(dict(subject=row["subject"], actual=actual))
        record = dict(
            binding=refs.ref(packet),
            status="ADOPTED_SOFTWARE_AND_REAL_SMOKE_UNRUN",
            before=before,
            after=after,
            source_leases=[],
            native_Search_model_RNG=0,
        )
        with (OUT / "adoption.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2) + "\n")
    print("Exact CPU-plan sparse source adopted; tests and real smoke unrun")


if __name__ == "__main__":
    main()
