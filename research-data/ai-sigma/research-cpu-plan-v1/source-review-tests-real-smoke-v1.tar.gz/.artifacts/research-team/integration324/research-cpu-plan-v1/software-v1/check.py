"""Run only changed CPU boundaries; synthetic tests are separate from real smoke."""

import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / "scripts/dev"), str(ROOT / "tools/research-session")]


def main():
    spec = importlib.util.spec_from_file_location(
        "lc_check", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lc)
    recipe_path = (
        ROOT
        / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/fixed-v3/software-recipe.json"
    )
    assert (
        lc.bound(recipe_path)[0]["sha256"]
        == "e8e625142170dd78bd56d0b014ccab8d1aa90d3be2f7400a37522b583eeab046"
    )
    recipe = json.loads(recipe_path.read_bytes())
    selectors = recipe["selectors"] + [
        "test_arena_plan.ArenaPlanTests.test_partial_depth_nonfinite_illegal_timing_and_actual_guardian_cleanup_refuse",
        "test_lifecycle_arena_cohort_repair.CohortRepairBoundary.test_job_supervisor_resource_callback_covers_pre_spawn_and_wait",
        "test_lifecycle_arena_cohort_repair.CohortRepairBoundary.test_sequence_publishes_pre_inner_terminal_before_notice_and_keeps_pause",
    ]
    with lc.lease(shared=True):
        suite = unittest.defaultTestLoader.loadTestsFromNames(selectors)
        with (OUT / "unittest.log").open("x") as stream:
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
        record = dict(
            selectors=selectors,
            tests=result.testsRun,
            failures=len(result.failures),
            errors=len(result.errors),
            success=result.wasSuccessful(),
            qualification="Synthetic CPU/owner/caller/sequence boundaries only; real parallel smoke unrun",
            native_Search_model_RNG=0,
            source_leases=[],
        )
        with (OUT / "result.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))
    assert result.wasSuccessful()


if __name__ == "__main__":
    main()
