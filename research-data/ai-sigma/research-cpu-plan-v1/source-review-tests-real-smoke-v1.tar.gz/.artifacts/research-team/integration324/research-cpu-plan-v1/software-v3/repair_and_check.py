"""Adopt and run only the remaining RSS/cancel fixture boundary."""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOURCE = (
    ROOT
    / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/test-fixture-repair-v2"
)
sys.path[:0] = [str(ROOT / "scripts/dev"), str(ROOT / "tools/research-session")]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    refs = load("refs", OUT.parents[1] / "cedar-etc-v1/adoption-v1/adopt.py")
    lc = load("lc_fixture", ROOT / "scripts/dev/research-lifecycle.py")
    packet = SOURCE / "binding.json"
    assert (
        refs.ref(packet)["sha256"]
        == "3e22ef2138b39473562942198cae6b83a003561df88698d26bef22d335329750"
    )
    binding = json.loads(packet.read_bytes())
    stop = SOURCE / "source-helper-STOP.json"
    assert (
        refs.ref(stop)["sha256"]
        == "e33a9d289576a21a1854153f3265e45dd38db732ed69cb77dcc66e214de44a44"
    )
    path = ROOT / binding["subject"]
    with lc.lease():
        assert all(
            refs.ref(path)[k] == binding["before"][k]
            for k in ("sha256", "bytes", "mode")
        )
        lc.read_ref(binding["post"])
        lc.read_ref(binding["forward"])
        subprocess.run(
            ["git", "apply", "--check", binding["forward"]["path"]],
            cwd=ROOT,
            check=True,
        )
        subprocess.run(
            ["git", "apply", binding["forward"]["path"]], cwd=ROOT, check=True
        )
        assert all(
            refs.ref(path)[k] == binding["post"][k] for k in ("sha256", "bytes", "mode")
        )
        with (OUT / "adoption.json").open("x") as stream:
            stream.write(
                json.dumps(
                    dict(
                        binding=refs.ref(packet),
                        actual_source_STOP=refs.ref(stop),
                        post=refs.ref(path),
                        production_changes=0,
                        source_leases=[],
                    ),
                    indent=2,
                )
                + "\n"
            )
    with lc.lease(shared=True):
        suite = unittest.defaultTestLoader.loadTestsFromNames(binding["selectors"])
        with (OUT / "unittest.log").open("x") as stream:
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
        previous = [
            OUT.parent / p / "result.json" for p in ["software-v1", "software-v2"]
        ]
        record = dict(
            selectors=binding["selectors"],
            tests=result.testsRun,
            errors=len(result.errors),
            failures=len(result.failures),
            success=result.wasSuccessful(),
            prior_12_PASS_reused=[refs.ref(p) for p in previous],
            original_failures_preserved=True,
            qualification="13 distinct synthetic CPU/caller/sequence/RSS tests; actual real normal parallel smoke remains unrun",
            source_leases=[],
            native_Search_model_RNG=0,
        )
        with (OUT / "result.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))
    assert result.wasSuccessful() and result.testsRun == 1


if __name__ == "__main__":
    main()
