"""Bind actual current source and physical roles for the finite dummy smoke."""

import hashlib
import json
from pathlib import Path

from quoridor_training import cycle_process as process

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
FIXTURE = ROOT / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/smoke-fixture-v4"


def reference(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 511:04o}",
    )


def main():
    expected = [
        (
            "fixture-binding.json",
            "189ade933d1412f007f3e99ef16e17e8484e58c1a28222b4425e4271a443aaab",
            5863,
        ),
        (
            "package-binding.json",
            "35ac86484da9d4ec02b0dd0a8dd167f707e993eb0bf194af54a60c65e36e00ce",
            4246,
        ),
    ]
    for name, sha, length in expected:
        actual = reference(FIXTURE / name)
        assert (actual["sha256"], actual["bytes"], actual["mode"]) == (
            sha,
            length,
            "0644",
        )
    package = json.loads((FIXTURE / "package-binding.json").read_bytes())
    for row in package["files"].values():
        assert reference(Path(row["path"])) == row
    current = reference(ROOT / "scripts/dev/research-lifecycle.py")
    assert current["sha256"] == "9a044d44d678c60d556b480354c3d39527596587cbf6c730eb4d303ddbfca41e"
    roles = process.CPUPlan([0, 18], {"lanes": [8, 10]})
    roles.check_host(process.available_cpus())
    common = 2 * 1024**3 - 64 * 1024**2
    lane = 1024**3
    assert process.available_memory() >= common + 2 * lane + 4 * 1024**3
    ended = json.loads(
        (OUT.parent / "exception-cleanup-software-v1/smoke.execution.process.json").read_bytes()
    )["child"]
    assert not process.alive(ended)
    build = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-etc-v1/retirement-software-v1/collection-v1/completion-and-STOP.json"
    )
    old = json.loads(build.read_bytes())
    identities = [r["original"] for r in old["known_exact_commands_fresh_absent_or_different"]] + [
        ended
    ]
    prior = json.loads((OUT.parent / "real-smoke-v3/collection-and-source-STOP.json").read_bytes())
    identities += prior["all_exact_known_identities_fresh_absent_or_different"]
    assert all(not process.alive(p) for p in identities)
    allocation = dict(
        schema="quoridor.cpu-plan-smoke.allocation.v1",
        issue="quoridor-4lc.324",
        goal_issue="quoridor-4lc.324",
        thread_id="01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        current_lifecycle=current,
        management_cpu_pool=[0, 18],
        lane_cpu_cores=[8, 10],
        common_family_B=common,
        lane_family_B=lane,
        host_reserve_B=4 * 1024**3,
        GPU=0,
        case_timeout_seconds=180,
        known_ended_source_users=identities,
    )
    with (OUT / "allocation.json").open("x") as stream:
        stream.write(json.dumps(allocation, indent=2) + "\n")
    with (OUT / "binding.json").open("x") as stream:
        stream.write(
            json.dumps(
                dict(
                    allocation=reference(OUT / "allocation.json"),
                    fixture=reference(FIXTURE / "fixture-binding.json"),
                    package=reference(FIXTURE / "package-binding.json"),
                    plan=roles.record(),
                    available_memory_B=process.available_memory(),
                    admission="Prospective binding; actual normal job/lifetime and coordinator enforce fresh source/CPU/RAM/owner/cancel on entry",
                    Root_total_including_outer64MiB_B=4 * 1024**3,
                    output=str(FIXTURE / "runs/Root-normal-cleanup-v1"),
                    Search_model_arena_RNG=0,
                ),
                indent=2,
            )
            + "\n"
        )
    print(json.dumps(allocation))


if __name__ == "__main__":
    main()
