"""Accept a bounded static CPU source finding; software and smoke stay unqualified."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
REVIEW = (
    ROOT
    / ".worktree/search-optimization/.artifacts/research-cpu-plan-review-v1/source-v1"
)


def main():
    loader = importlib.util.spec_from_file_location(
        "refs", OUT.parents[1] / "cedar-etc-v1/adoption-v1/adopt.py"
    )
    refs = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(refs)
    expected = {
        "minimum.json": (
            "d3c932bd128c584740266d883b509387bca8f76df82f894b69bd9d73b6593a05",
            3253,
        ),
        "control.json": (
            "6dbcada6021c88fecd41a78345120f5e353b7d55f37a4b5ff493699bc457f47a",
            867,
        ),
        "source-correspondence.json": (
            "d522c9d455f4fff0a84b22a6c50b8c60db760ebc9fd4b67516e65d5128240ab9",
            8810,
        ),
        "reader-STOP.json": (
            "be6ba846ddebee4fedb06737f9abc0da2a139f32725ec1d35f09882bf4820fb9",
            8266,
        ),
        "returned-STOP.json": (
            "3ad74cc9f5f6f7848ee8cafc22c027530d5b25f3d4e1cf57749d2c4a7b6db8f0",
            942,
        ),
    }
    evidence = {}
    for name, (sha, length) in expected.items():
        actual = refs.ref(REVIEW / name)
        assert (actual["sha256"], actual["bytes"], actual["mode"]) == (
            sha,
            length,
            "0644",
        )
        evidence[name] = actual
    minimum = json.loads((REVIEW / "minimum.json").read_bytes())
    assert minimum["verdict"] == "SOURCE_CLEAR"
    assert minimum["essential"] == minimum["ordinary"] == 0
    binding = minimum["fixed_binding"]
    assert refs.ref(Path(binding["path"])) == binding
    assert (
        binding["sha256"]
        == "62d5fabf1030ebe55ccda9d8c46683f470d2edf9c4213ad416ae9a9f4bb33d81"
    )
    result = dict(
        issue="quoridor-4lc.324.32.1",
        status="SOURCE_CLEAR_ACCEPTED_SOFTWARE_UNRUN",
        binding=binding,
        evidence=evidence,
        scope="Exact common CPU source boundary only; Root sparse adoption, actual tests and normal real dummy2lane/singlelane/cancel/failure qualification remain required. No historical MPC parallel repair or scientific/default claim.",
        native_Search_model_RNG_replay=0,
        author_normal_close_reason="Root accepted d3c932bd SOURCE_CLEAR e0/o0 for exact62d5fabf CPU plan source boundary only. Root integration/software/real non-scientific smoke remain separate, no runtime or historical MPC success claim. Root acceptance .artifacts/research-team/integration324/research-cpu-plan-v1/source-review-v1/Root-source-acceptance.json",
    )
    with (OUT / "Root-source-acceptance.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
