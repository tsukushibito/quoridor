"""Own one finite real-process dummy smoke and preserve every cleanup outcome."""

import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import CycleResources, execute

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
FIXTURE = ROOT / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/smoke-fixture-v3"
temporary = OUT / "guard-TMP"
temporary.mkdir()
deadline = time.monotonic() + 2200
resources = CycleResources(
    dict(max_memory_bytes=4 * 1024**3 - 64 * 1024**2, host_ram_reserve=4 * 1024**3),
    OUT,
    deadline,
)
failure = None
returned = None
try:
    returned = execute(
        [
            sys.executable,
            "-B",
            str(FIXTURE / "coordinator.py"),
            "--allocation",
            str(OUT / "allocation.json"),
            "--output",
            str(FIXTURE / "runs/Root-normal-smoke-v1"),
        ],
        OUT / "smoke.execution.log",
        deadline,
        cpu_cores=[0, 8, 10, 18],
        resources=resources,
        cwd=ROOT,
        env=dict(
            os.environ,
            TMPDIR=str(temporary),
            CUDA_VISIBLE_DEVICES="",
            PYTHONDONTWRITEBYTECODE="1",
        ),
    )
except BaseException as error:
    failure = dict(type=type(error).__name__, message=str(error))
finally:
    path = OUT / "smoke.execution.process.json"
    actual = json.loads(path.read_bytes()) if path.exists() else None
    with (OUT / "actual-returned-STOP.json").open("x") as stream:
        stream.write(
            json.dumps(
                dict(
                    actual_return=returned,
                    actual_disk_record=actual,
                    failure=failure,
                    TMP_retained=[str(p) for p in temporary.rglob("*")],
                    host_future_quiet=False,
                    scientific_calls=0,
                ),
                indent=2,
            )
            + "\n"
        )
print(json.dumps(dict(failure=failure, exit_code=returned.get("exit_code") if returned else None)))
assert failure is None and returned["exit_code"] == 0 and returned["cleanup_complete"]
