import pathlib,json,gzip,time,datetime,os,resource,hashlib,collections,struct
os.sched_setaffinity(0,{0});resource.setrlimit(resource.RLIMIT_AS,(234881024,234881024));resource.setrlimit(resource.RLIMIT_CPU,(30,30));t=time.monotonic()
D=pathlib.Path('research-data/ai-sigma/frame16-throughput-independent/fresh96-stage');S=pathlib.Path('research-data/ai-sigma/frame16-teacher-throughput/fresh96-stage');L=lambda p:json.loads(p.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=L(D/'record.json')
loaded=L(pathlib.Path('.artifacts/ai-sigma/continuation-20261001/SIGMA-RESUME-OPERATIONS-92/frame16-turn-unbounded/running-loaded.json'));m=L(pathlib.Path(loaded['run'])/'monitor-observation.json');sch=L(pathlib.Path('/workspaces/quoridor/.artifacts/research-team/scheduler-sigma-continuation-20261001/state.json'));assert (datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(m['at'])).total_seconds()<30
for pid,tick in [(6049,'35765166'),(6062,'35765187')]:assert pathlib.Path('/proc',str(pid),'stat').read_text().split()[21]==tick
assert sch['owned']is None and sch['next_at']-time.time()>90
stop=L(S/'science-stop.json');assert stop['scientific_source_writer_stopped']and stop['all_science_children_wait']and stop['current_exact_absent']
for p,h in stop['source_SHA'].items():
 if pathlib.Path(p).name not in ['pack.py','scenarios.py','save_git.py']:assert H(pathlib.Path(p))==h
p=L(S/'jobs/fresh96-firstscience/process.json');assert p['exit']==0 and p['all_child_waited']and p['current_exact_absent']and not p['remaining']
for z in [dict(pid=p['runner_pid'],tick=p['runner_tick'])]+p['tracked']:
 q=pathlib.Path('/proc',str(z['pid']),'stat');assert not q.exists()or q.read_text().split()[21]!=str(z['tick'])
assert sum(x.stat().st_blocks*512 for x in D.iterdir())+max(0,pathlib.Path('docs/reports/ai-sigma-critic-teacher-throughput.md').stat().st_blocks*512-r['old_report_allocated'])+32768+4096<=51200
r['admission']={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monitor_at':m['at'],'owned':None,'next_at':sch['next_at'],'PID':os.getpid(),'tick':pathlib.Path('/proc/self/stat').read_text().split()[21]}
d=L(S/'fresh96-firstscience-summary.json');c=L(S/'costs.json');o=L(S/'openings.json')['games'];assert len(o)==len({x['game_id']for x in o})==len({x['family']for x in o})==96;assert collections.Counter(x['target_ply']for x in o)=={8:16,12:16,16:16,20:16,24:16,28:16}
slots=d['all_slot_plies'];assert len(slots)==96 and {x['id']for x in slots}=={x['game_id']for x in o};assert collections.Counter(x['status']for x in slots)==d['status_counts'];assert sum(x['new_rows']for x in slots)==d['Rjoint']==d['Rz']==d['Rpolicy']==d['qualification_replay_rows'];assert all(x['terminal']and not x['unknown_z']for x in slots)
b=d['batch'];nn=sum(i*n for i,n in enumerate(b['batch_histogram']));assert nn==b['started']==b['returned']==b['resumed']==d['logical_worker_NN'];assert d['actual_NN']==nn+d['providerStop']['graph_startup_samples']==p['sample_equivalent'];assert d['startup']==0 and d['providerStop']['graph_startup_samples']==108;assert d['discarded']==d['unknown_z_rows']==0
# OR on label-free supplied keys only, not source-transform/deep truth recertification.
e=L(S/'exposure-summary.json');refs=[set(),set(),set()];fields=['state_key','history_key','QF1_input_sha256']; key=lambda a:(a['state_key'],a['history_key'],(tuple(sorted(a['ids'][0])),tuple(sorted(a['ids'][1])),struct.pack('<ff',*a['distance'])))
for ref in e['refs']:
 q=pathlib.Path(ref['path']);assert 'metadata' in q.name and H(q)==ref['SHA']
 with gzip.open(q,'rt')as f:
  for line in f:
   a=json.loads(line)
   for i,v in enumerate(key(a)):refs[i].add(v)
seen=[set(),set(),set()];shared=prior=rows=0;games=collections.Counter()
manifest=L(S/'dataset-manifest.json');meta=pathlib.Path(manifest['metadata']);assert H(meta)==manifest['metadata_sha256']
with gzip.open(meta,'rt')as f:
 for line in f:
  a=json.loads(line);assert not any(k in a for k in ['z','target','rootmean','winner','loss']);rows+=1;games[a['game_id']]+=1;shared+=any(v in refs[i]for i,v in enumerate(key(a)));prior+=any(v in seen[i]for i,v in enumerate(key(a)))
  for i,v in enumerate(key(a)):seen[i].add(v)
assert rows==d['Rjoint']==e['rows']and len(games)==96 and shared==e['old_reference_exposure_OR_rows']and prior==e['within_new_prior_row_any_signature_shared'];assert sum(x['rows']for x in e['games'])==rows and not e['zero_row_games'];assert not manifest['auto_training_mix']and manifest['familygroups']==96
first=L(S/'jobs/fresh96-r1/process.json');proof=L(S/'jobs/fresh96-r1/before-model-proof.json');assert first['sample_equivalent']is None and proof['model_NN_samples']==0 and not proof['model_science_started']
wall=d['allattempt_jobwall_s'];assert wall==p['jobwall_seconds']==c['jobwall_s'];density=rows/96
r['result']={'GOAL':d['status_counts'],'slots':96,'Rjoint':rows,'density':density,'joint_s':rows/wall,'wall':wall,'allattempt_wall':wall+first['jobwall_seconds'],'logicalNN':nn,'physicalNN':p['sample_equivalent'],'totalNN':569460+p['sample_equivalent'],'terminal_noNN':d['terminal_noNN'],'meanB':nn/sum(b['batch_histogram']),'pending_games':b['max_pending_games'],'derived_UTC_active_not_handle_count':c['approx_active_peak'],'cold_s':c['cold_until_first_game_s'],'tail8_s':c['last8_completion_tail_s'],'tail24_s':c['last24_completion_tail_s'],'oldreferenceOR':shared,'newpriorOR':prior,'zero_row_games':0,'jobonly1000min':wall/96*1000/60,'required_joint_s60':density*1000/3600,'required_joint_s30':density*1000/1800,'qualification_s':d['qualify_wall_s'],'firstentry':'processNN UNKNOWN retained; owner source-order proof0NN/model before provider; exact offender unknown','wholepipeline':'pack/Git/management pending at independent arithmetic snapshot; no actual1000','limits':'old-reference supplied label-free signatures; shared canonical/opaquehistory/RuleA; no labels/raw/deep or forward; distribution not pure codec cause'}
r['stopSHA']=H(S/'science-stop.json');r['summarySHA']=H(S/'fresh96-firstscience-summary.json');r['costSHA']=H(S/'costs.json');r['sourcegzipSHA']=H(D/'check.py.gz');r['calc_actual_s']=time.monotonic()-t;r['calc_RSS']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;r['phase_charge']=50;r['total_charge']=260;r['science_stopped']=True;assert r['calc_RSS']<234881024
(D/'record.json').write_text(json.dumps(r,separators=(',',':'))+'\n');print(json.dumps(r['result']));print('calcwall/RSS',r['calc_actual_s'],r['calc_RSS'])
