import json,pathlib,hashlib,os,time,resource,datetime,struct
os.sched_setaffinity(0,{0});resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(234881024,234881024));t=time.monotonic()
D=pathlib.Path('research-data/ai-sigma/frame16-throughput-independent/codec-control');S=pathlib.Path('research-data/ai-sigma/frame16-teacher-throughput/codec-control')
load=lambda p:json.loads(p.read_text()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=load(D/'record.json');L=load(pathlib.Path(r['runtime_loaded_path']));M=load(pathlib.Path(L['run'])/'monitor-observation.json');state=load(pathlib.Path('/workspaces/quoridor/.artifacts/research-team/scheduler-sigma-continuation-20261001/state.json'))
assert (datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(M['at'])).total_seconds()<30
assert state['owned'] is None and state['next_at']-time.time()>150
for pid,tick in [(6049,'35765166'),(6062,'35765187')]:assert pathlib.Path('/proc',str(pid),'stat').read_text().split()[21]==tick
stop=load(S/'science-stop.json');assert stop['scientific_source_writer_stopped'] and stop['science_child_all_wait'] and stop['current_exact_absent']
core=['provider.py','broker.cjs','wire.cjs','generate.cjs','runner.py','parity.cjs','compare.py']
for n in core:
 p=pathlib.Path('tools/ai-sigma-teacher-throughput/codec-control')/n;assert sha(p)==stop['source_SHA'][str(p)]
for p,h in stop['payload_SHA'].items():assert sha(pathlib.Path(p))==h
for job in ['parity-r2','codec-r1','codec-confirmation']:
 p=load(S/'jobs'/job/'process.json');assert p['exit']==0 and p['all_child_waited'] and p['current_exact_absent'] and not p['remaining']
 for ident in [dict(pid=p['runner_pid'],tick=p['runner_tick'])]+p['tracked']:
  q=pathlib.Path('/proc',str(ident['pid']),'stat');assert not q.exists() or q.read_text().split()[21]!=str(ident['tick'])
foreign=[]
for p in pathlib.Path('/proc').iterdir():
 if p.name.isdigit() and int(p.name)!=os.getpid():
  try:
   cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()
   if ('provider.py' in cmd or 'codec-control/generate.cjs' in cmd or 'regression' in cmd) and 'python3 -B -' not in cmd:foreign.append(int(p.name))
  except OSError:pass
assert not foreign,foreign
assert sum(p.stat().st_blocks*512 for p in D.iterdir())+max(0,pathlib.Path('docs/reports/ai-sigma-critic-teacher-throughput.md').stat().st_blocks*512-r['old_report_allocated'])+28672+8192<=51200
r['admission']={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monitor_at':M['at'],'owned':None,'next_at':state['next_at'],'foreign_heavy':foreign,'PID':os.getpid(),'tick':pathlib.Path('/proc/self/stat').read_text().split()[21],'RSS':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
C=load(S/'comparison.json');P=load(S/'parity-pass.json');assert {(x['B'],x['fixture']) for x in P['checks']}=={(b,f)for b in range(1,9)for f in range(2)}
assert all(x['bitexact_graph_codec'] and x['ID'] and x['f32finite'] and x['CPUmaxratio']<=1 for x in P['checks']);assert sum(x['stop']['result']['single_sample_equivalent']for x in P['stops'])==P['NN_samples']==432
out=[]
for mode in ['codec-r1','codec-confirmation']:
 d=load(S/(mode+'-summary.json'));slots=d['all_slot_plies'];assert len(slots)==len({x['id']for x in slots})==48 and all(x['status']=='GOAL'and x['terminal']and not x['unknown_z']for x in slots)
 assert sum(x['new_rows']for x in slots)==d['Rpolicy']==d['Rz']==d['Rjoint']==d['qualification_replay_rows']==1554
 B=d['batch'];ps=d['providerStop'];assert sum(i*n for i,n in enumerate(B['batch_histogram']))==B['started']==B['returned']==B['resumed']==d['logical_worker_NN']==81096
 assert d['actual_NN']==ps['single_sample_equivalent']==81096+ps['graph_startup_samples']==81204 and ps['graph_startup_samples']==108 and d['startup']==0
 assert d['discarded']==d['unknown_z_rows']==0 and d['terminal_noNN']==18360 and d['providerCost']['JSON_firstpass_NOT_APPLICABLE']
 assert not d['mixed_into_learner'] and not d['formal_holdout_read'];cc=C['conditions'][mode];assert abs(cc['jobwall_s']-d['allattempt_jobwall_s'])<1e-10
 out.append({'mode':mode,'slots':48,'joint':1554,'wall':d['allattempt_jobwall_s'],'qualification':d['qualify_wall_s'],'responseBytes':ps['pipe']['responseBytes'],'encode_once_ms':ps['wire_totals_ms']['json_encode_once'],'write_ms':ps['wire_totals_ms']['actual_stdout_write']})
assert len(C['roots'])==48 and all(x['visit_vector_equal']and x['action_equal']for x in C['roots'])
assert len(C['paired_prefixes'])==48 and sum(x['same_state_prefix_rows']for x in C['paired_prefixes'])==1554 and all(x['first_action_divergence_ply']is None for x in C['paired_prefixes'])
assert len(C['whole_qualified_row_correspondence'])==2 and all(x['same_action_count']==x['same_visit_count']==1554 for x in C['whole_qualified_row_correspondence'])
mean=sum(x['wall']for x in out)/2;base=85.7270649910206;measured=sum(x['jobwall_seconds']for x in C['allattempt']['statuses']if x['exit']==0);fail=[x for x in C['allattempt']['statuses']if x['exit']!=0]
assert measured==stop['phase3_measured_heavy_s'];assert sum(x['sample_equivalent']for x in C['allattempt']['statuses'])==162840;assert C['totalNN']==569460
assert len(fail)==1 and fail[0]['sample_equivalent']==0 and fail[0]['jobwall_seconds']==5
# Separate oracle arithmetic for representative uint32 to f32: no NN and no shared decoder.
for bits in [0,0x80000000,1,0x007fffff,0x3f800000,0xbf800000]:assert struct.unpack('<I',struct.pack('<f',struct.unpack('<f',struct.pack('<I',bits))[0]))[0]==bits
for v in [-1,2**32,.5,True,None]:assert not(type(v)is int and 0<=v<2**32)
r['result']={'modes':out,'codec_meanwall':mean,'vs_graph_wallratio':mean/base,'rate_ratio':base/mean,'response_ratio':sum(x['responseBytes']for x in out)/sum(C['conditions'][x]['provider_pipe']['responseBytes']for x in ['graph-r1','graph-confirmation']),'jobonly_1000_minutes':mean/48*1000/60,'qualonly_1000_minutes':sum(x['wall']+x['qualification']for x in out)/2/48*1000/60,'phase3_measuredwall':measured,'failedwall':'UNKNOWN; conservative5 not measured','phase3_NN':162840,'total_NN':569460,'parity432':True,'samework':True,'limits':'source and owner RuleA/whole-row receipts; no raw/deep replay or model forward; fixed sequential hostwarm; package not component cause'}
r['stop_SHA']=sha(S/'science-stop.json');r['comparison_SHA']=sha(S/'comparison.json');r['parity_SHA']=sha(S/'parity-pass.json');r['calc_actualwall']=time.monotonic()-t;r['calc_RSS']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;r['phase_charge']=60;r['total_charge']=210;r['calc_remaining']=0;r['source_science_stopped']=True;r['source_gz_SHA']=sha(D/'check.py.gz')
assert r['calc_RSS']<234881024
(D/'record.json').write_text(json.dumps(r,separators=(',',':'))+'\n');print(json.dumps(r['result']));print('wall/RSS',r['calc_actualwall'],r['calc_RSS'])
