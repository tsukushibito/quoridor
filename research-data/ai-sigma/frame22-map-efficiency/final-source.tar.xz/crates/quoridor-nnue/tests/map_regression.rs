use quoridor_core::{Position, research::SigmaContext};
use quoridor_nnue::{EvaluationMode, Features, Model};
use std::collections::VecDeque;
fn queue(p: Position, player: usize) -> [u8; 81] {
    let mut d = [81; 81];
    let mut q = VecDeque::new();
    for x in 0..9 {
        let c = if player == 0 { 72 + x } else { x };
        d[c as usize] = 0;
        q.push_back(c);
    }
    while let Some(c) = q.pop_front() {
        for n in 0..81 {
            if d[n as usize] == 81 && p.is_edge_open(c, n) {
                d[n as usize] = d[c as usize] + 1;
                q.push_back(n);
            }
        }
    }
    d
}
fn oracle_features(p: Position) -> Features {
    let ids = std::array::from_fn(|player| {
        let rot = |c: u8| if player == 1 { 80 - c } else { c };
        let mut v = vec![
            u16::from(rot(p.pawns[player])),
            81 + u16::from(rot(p.pawns[player ^ 1])),
            290 + u16::from(p.walls_remaining[player]),
            301 + u16::from(p.walls_remaining[player ^ 1]),
        ];
        for anchor in 0..64 {
            let key = if player == 1 { 63 - anchor } else { anchor };
            if p.horizontal & (1 << anchor) != 0 {
                v.push(162 + key);
            }
            if p.vertical & (1 << anchor) != 0 {
                v.push(226 + key);
            }
        }
        v.sort_unstable();
        v
    });
    let side = p.turn as usize;
    let distances = [queue(p, side), queue(p, side ^ 1)];
    Features {
        ids,
        side: p.turn,
        distance: std::array::from_fn(|i| {
            (f64::from(distances[i][p.pawns[side ^ i] as usize]) / 80.) as f32
        }),
    }
}
#[test]
fn queue_features_scalar_simd_delta_full_parent() {
    assert_eq!(std::env::var("ORT_DISABLE_TELEMETRY").as_deref(), Ok("1"));
    let model = Model::load(std::env::var("MAP279_MODEL").unwrap()).unwrap();
    let prefixes: &[&[u16]] = &[
        &[],
        &[13, 67, 81, 66, 14, 65],
        &[13, 67, 81, 66, 14, 65, 143, 126, 150, 64, 141, 151],
        &[13, 67, 22, 58, 31, 49, 40],
    ];
    let mut nn = 0;
    let mut comparisons = 0;
    let mut maxabs = 0f32;
    let mut advance_ns = [0u128; 2];
    let mut cache_counts = [0usize; 2];
    for mode in [EvaluationMode::Scalar, EvaluationMode::Simd] {
        for prefix in prefixes {
            let parent = SigmaContext::from_prefix(prefix).unwrap();
            let a = model.full_context(&parent, mode).unwrap();
            let before = a.values.clone();
            let before_features = a.features.clone();
            for action in parent.legal_ids() {
                let child = parent.play(action).unwrap();
                let input = oracle_features(child.position());
                let full = model.full_context(&child, mode).unwrap();
                let wall_changed = usize::from(
                    parent.position().horizontal != child.position().horizontal
                        || parent.position().vertical != child.position().vertical,
                );
                let started = std::time::Instant::now();
                let delta = model.delta_context(&a, &child).unwrap();
                advance_ns[wall_changed] += started.elapsed().as_nanos();
                cache_counts[wall_changed] += 1;
                let oracle = model.full_features(input.clone(), mode).unwrap();
                assert_eq!(full.features, input);
                assert_eq!(delta.features, input);
                let fv = model.evaluate(&full).unwrap();
                let dv = model.evaluate(&delta).unwrap();
                let ov = model.evaluate(&oracle).unwrap();
                nn += 3;
                assert_eq!(fv.to_bits(), ov.to_bits());
                maxabs = maxabs.max((fv - dv).abs());
                assert!((fv - dv).abs() <= 2e-6 && dv.is_finite());
                assert_eq!(a.values, before);
                assert_eq!(a.features, before_features);
                assert_eq!(child.total_ply(), parent.total_ply() + 1);
                comparisons += 1;
            }
        }
    }
    println!(
        "CACHECOST279 pawn_count={} wall_count={} pawn_advance_ns={} wall_advance_ns={} scope=inclusive-delta-advance",
        cache_counts[0], cache_counts[1], advance_ns[0], advance_ns[1]
    );
    assert_eq!(comparisons, 1006);
    assert_eq!(nn, 3018);
    println!(
        "MAP279 task=frame22-map-efficiency-279-v1 nativeNN={nn} comparisons={comparisons} full_queue_bits=equal delta_maxabs={maxabs}"
    );
}
