//! Fixed-work map-caller costs; same-work observations do not certify strength.
use quoridor_ai::alphabeta::{self as ab, EvalAccumulator, StaticEvaluator};
use quoridor_core::research::SigmaContext;
use quoridor_nnue::Model;
use serde_json::{Value, json};
use std::{
    sync::{Arc, atomic::AtomicBool},
    time::Instant,
};
struct Owned(ab::NnueEvaluator);
impl StaticEvaluator for Owned {
    fn prepare_context(&self, c: &SigmaContext) -> ab::Result<Option<EvalAccumulator>> {
        self.0.prepare_context(c)
    }
    fn advance_context(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
    ) -> ab::Result<Option<EvalAccumulator>> {
        self.0.advance_context(a, c)
    }
    fn evaluate(&self, c: &SigmaContext, a: Option<&EvalAccumulator>) -> ab::Result<f32> {
        self.0.evaluate(c, a)
    }
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    assert_eq!(std::env::var("ORT_DISABLE_TELEMETRY").as_deref(), Ok("1"));
    let cfg: Value = serde_json::from_slice(&std::fs::read(std::env::args().nth(1).unwrap())?)?;
    assert_eq!(cfg["task"], "frame22-map-efficiency-279-v1");
    let start = Instant::now();
    let model = Arc::new(Model::load(cfg["model"].as_str().unwrap())?);
    let load_ns = start.elapsed().as_nanos();
    let d =
        ab::DistanceEvaluator::new(model.distance_fit().a as f32, model.distance_fit().b as f32);
    let l = Owned(ab::NnueEvaluator::new(model));
    let limits = ab::SearchLimits {
        max_depth: 2,
        max_nodes: 3000,
        time_limit: None,
        ..ab::SearchLimits::default()
    };
    let mut nodes = 0;
    let mut nn = 0;
    for sample in 0..cfg["samples"].as_u64().unwrap() {
        for f in cfg["fixtures"].as_array().unwrap() {
            let prefix: Vec<u16> = serde_json::from_value(f["prefix"].clone())?;
            let root = SigmaContext::from_prefix(&prefix)?;
            let board = root.position();
            let history = root.history_counts();
            let ply = root.total_ply();
            for (engine, eval) in [
                ("D", &d as &dyn StaticEvaluator),
                ("L", &l as &dyn StaticEvaluator),
            ] {
                let t = Instant::now();
                let result = ab::search(&root, eval, &limits, &AtomicBool::new(false))?;
                let ns = t.elapsed().as_nanos();
                assert_eq!(root.position(), board);
                assert_eq!(root.history_counts(), history);
                assert_eq!(root.total_ply(), ply);
                nodes += result.stats.nodes;
                nn += if engine == "L" {
                    result.stats.evaluations
                } else {
                    0
                };
                println!(
                    "{}",
                    json!({"task":cfg["task"],"schema":"map-work-row-v1","sample":sample,"warm":sample==0,"fixture":f["name"],"prefix":prefix,"engine":engine,"elapsed_ns":ns,"completed_depth":result.completed_depth,"action":result.action,"value_bits":result.value.map(f32::to_bits),"pv":result.pv,"nodes":result.stats.nodes,"NN":if engine == "L" { result.stats.evaluations } else { 0 },"leaf_evaluations":result.stats.evaluations,"delta_updates":result.stats.delta_updates,"tt_hits":result.stats.tt_hits,"tt_cutoffs":result.stats.tt_cutoffs,"stop":format!("{:?}",result.stop),"root_history_restored":true})
                );
            }
        }
    }
    println!(
        "{}",
        json!({"task":cfg["task"],"schema":"map-work-total-v1","nodes":nodes,"NN":nn,"model_load_ns":load_ns,"whole_ns":start.elapsed().as_nanos(),"scratch":false,"root_nodecap":3000})
    );
    Ok(())
}
