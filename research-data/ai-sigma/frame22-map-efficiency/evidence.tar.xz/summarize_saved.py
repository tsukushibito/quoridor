"""Summarize frozen 279 outputs; never executes model or search."""

import datetime
import json
import pathlib
import re
import statistics

OUT = pathlib.Path(__file__).resolve().parent
TASK = "frame22-map-efficiency-279-v1"
results = {}
all_native = 3018
all_nodes = 0
for mode in ("forward", "reverse"):
    saved = json.loads((OUT / f"{mode}-result.json").read_text())
    assert saved["task"] == TASK and saved["status"] == "PASS"
    rows = {}
    totals = {}
    for variant in ("queue", "bit"):
        data = [
            json.loads(line)
            for line in (OUT / f"{mode}-{variant}-stdout.log").read_text().splitlines()
        ]
        rows[variant] = data[:-1]
        totals[variant] = data[-1]
        assert sum(r["NN"] for r in data[:-1]) == totals[variant]["NN"]
        assert sum(r["nodes"] for r in data[:-1]) == totals[variant]["nodes"]
        assert all(
            r["root_history_restored"]
            and r["completed_depth"] == 2
            and r["stop"] == "DepthComplete"
            for r in rows[variant]
        )
    names = sorted({r["fixture"] for r in rows["queue"]})
    engine = {}
    for name in ("D", "L"):
        medians = {
            v: {
                fi: statistics.median(
                    r["elapsed_ns"]
                    for r in rows[v]
                    if r["engine"] == name and r["fixture"] == fi and not r["warm"]
                )
                for fi in names
            }
            for v in rows
        }
        sums = {v: sum(medians[v].values()) for v in medians}
        engine[name] = dict(
            steady_prefix_medians_ns=medians,
            median_sum_ns=sums,
            bit_over_queue=sums["bit"] / sums["queue"],
            per_prefix_ratio={fi: medians["bit"][fi] / medians["queue"][fi] for fi in names},
        )
    all_native += saved["native_NN"]
    all_nodes += saved["processed"]
    results[mode] = dict(
        order=saved["order"],
        matched_rows=saved["matched_rows"],
        total_rows=saved["total_rows"],
        snapshots_and_counters_equal=saved["snapshots_and_counters_equal"],
        engines=engine,
        whole_ns={v: totals[v]["whole_ns"] for v in totals},
        whole_bit_over_queue=totals["bit"]["whole_ns"] / totals["queue"]["whole_ns"],
        model_load_ns={v: totals[v]["model_load_ns"] for v in totals},
        whole_scope="internal process includes load/setup/rootwork/printing; external child+guardian separate inclusive spans",
    )
map_rows = []
for match in re.finditer(
    r"MAPCOST279 sample=(\d+) warm=(\w+) variant=(\w+) maps=(\d+) elapsed_ns=(\d+)",
    (OUT / "quality-whole_maps-stdout.log").read_text(),
):
    sample, warm, variant, count, ns = match.groups()
    map_rows.append(
        dict(
            sample=int(sample),
            warm=warm == "true",
            variant=variant,
            maps=int(count),
            elapsed_ns=int(ns),
        )
    )
map_medians = {
    v: statistics.median(r["elapsed_ns"] for r in map_rows if r["variant"] == v and not r["warm"])
    for v in ("queue", "bit")
}
cache_match = re.search(
    r"CACHECOST279 pawn_count=(\d+) wall_count=(\d+) pawn_advance_ns=(\d+) wall_advance_ns=(\d+)",
    (OUT / "quality-map_regression-stdout.log").read_text(),
)
assert cache_match
pawn, wall, pawn_ns, wall_ns = map(int, cache_match.groups())
processes = {str(p.relative_to(OUT)): json.loads(p.read_text()) for p in OUT.glob("*/process.json")}
compile_wall = sum(
    p.get("wall_seconds", 0) for p in processes.values() if p.get("kind") == "compile"
)
science_wall = sum(
    p.get("wall_seconds", 0) for p in processes.values() if p.get("kind") == "science"
)
science = [p for p in processes.values() if p.get("kind") == "science"]
assert len(science) == 3 and all(
    p["exit_code"] == 0 and p["waited"] and p["current_exact_absent"] for p in science
)
assert all_native <= 150000 and all_nodes <= 500000 and science_wall <= 180 and compile_wall <= 180
failed = {
    path: {k: p.get(k) for k in ("exit_code", "cause", "wall_seconds", "status")}
    for path, p in processes.items()
    if p.get("exit_code", 0) != 0 or p.get("status")
}
summary = dict(
    task=TASK,
    schema="map-efficiency-summary-v1",
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    comparisons=results,
    quality="PASS finite graph and 1006 Scalar/Simd child feature/value comparisons; full/delta maxabs1.1920929e-7",
    map_micro=dict(
        rows=map_rows,
        steady_medians_ns=map_medians,
        bit_over_queue=map_medians["bit"] / map_medians["queue"],
        scope="489 changed-wall child maps; includes masks+both81 materialization; excludes Arc/cache and inference; timer instrumented micro not search speed",
    ),
    cache_observer=dict(
        pawn_count=pawn,
        wall_count=wall,
        pawn_advance_ns=pawn_ns,
        wall_advance_ns=wall_ns,
        scope="inclusive actual delta_context; map/IDs/FT/validation mixed, cannot add to whole search",
    ),
    counters=dict(
        native_NN=all_native,
        processed=all_nodes,
        science_jobs=len(science),
        scientific_wall_seconds=science_wall,
        compile_test_wall_seconds=compile_wall,
    ),
    management_failures=dict(
        processes=failed,
        other=[
            "build-bit-r1 prestart stale runtime; no child/model/NN",
            "pre-science controller artifact allowlist omitted quoridor_nnue, corrected before any child",
            "saved-stat scratch snippet numeric fixture selector produced empty median; no NN/forward/science attempt",
            "initial communication dispatch lock and later coordinator role refresh rejection held",
        ],
    ),
    limits=[
        "4 fixed roots/depth2/old width32 model, short steady samples; host/order drift",
        "owned old275/277 comparison scaffold; scratch disabled; normal main end-to-end not measured",
        "same rules core oracle dependency outside independent queue graph; no deep teacher/model truth",
        "Sigma648 caller unmodified; MCTS/fullgameRjoint/samewall strength unknown",
        "source and evidence self-verification requires separate coordinator adoption review",
    ],
)
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(
    json.dumps(
        dict(
            counters=summary["counters"],
            ratios={
                m: {e: results[m]["engines"][e]["bit_over_queue"] for e in ("D", "L")}
                for m in results
            },
            map_micro_ratio=summary["map_micro"]["bit_over_queue"],
        ),
        indent=2,
    )
)
