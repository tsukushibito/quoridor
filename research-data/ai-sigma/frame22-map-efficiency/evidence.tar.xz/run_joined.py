"""One guard-owned group; quality or a frozen two-binary comparison."""

import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path("/workspaces/quoridor")
cfg = json.loads((OUT / "preregister.json").read_text())
mode = sys.argv[1]
assert mode in ("quality", "forward", "reverse")
assert pathlib.Path.cwd() == ROOT / ".worktree/frame21-search"
assert cfg["task"] == "frame22-map-efficiency-279-v1"
assert os.environ["ORT_DISABLE_TELEMETRY"] == "1"
receipts = []
env = dict(os.environ, MAP279_MODEL=cfg["model"])


def run(name, argv):
    start = time.monotonic()
    child = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    tick = pathlib.Path(f"/proc/{child.pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
    stdout, stderr = child.communicate(timeout=50)
    (OUT / f"{mode}-{name}-stdout.log").write_bytes(stdout)
    (OUT / f"{mode}-{name}-stderr.log").write_bytes(stderr)
    path = pathlib.Path(f"/proc/{child.pid}/stat")
    exact = path.exists() and path.read_text().rsplit(")", 1)[1].split()[19] == tick
    record = dict(
        name=name,
        argv=argv,
        entry_sha256=hashlib.sha256(pathlib.Path(argv[0]).read_bytes()).hexdigest(),
        pid=child.pid,
        tick=tick,
        exit_code=child.returncode,
        waited=True,
        current_exact_absent=not exact,
        wall_seconds=time.monotonic() - start,
    )
    receipts.append(record)
    (OUT / f"{mode}-children.json").write_text(json.dumps(receipts, indent=2) + "\n")
    if child.returncode or exact:
        sys.exit(1)
    return stdout.decode()


if mode == "quality":
    bins = {}
    for folder in ("build-coretests-r2", "build-nnuetests-r2"):
        for line in (OUT / folder / "stdout.log").read_text().splitlines():
            row = json.loads(line)
            if row.get("reason") == "compiler-artifact" and row.get("profile", {}).get("test"):
                if row["target"]["name"] in (
                    "whole_maps",
                    "context_undo",
                    "rules",
                    "map_regression",
                    "quoridor_nnue",
                ):
                    bins[row["target"]["name"]] = row["executable"]
    assert set(bins) == {"whole_maps", "context_undo", "rules", "map_regression", "quoridor_nnue"}
    for name in ("whole_maps", "context_undo", "rules", "map_regression", "quoridor_nnue"):
        argv = [bins[name]]
        if name == "quoridor_nnue":
            argv.append("map_cache279")
        output = run(name, [*argv, "--test-threads=1", "--nocapture"])
        assert "test result: ok." in output
        if name == "map_regression":
            assert "nativeNN=3018 comparisons=1006" in output
    result = dict(
        task=cfg["task"],
        schema="map-quality-receipt-v1",
        status="PASS",
        native_NN=3018,
        processed=0,
        shared_RuleA_dependency=True,
        queue_graph_oracle_independent=True,
        model_truth_independent=False,
    )
else:
    assert json.loads((OUT / "quality-result.json").read_text())["status"] == "PASS"
    order = ("queue", "bit") if mode == "forward" else ("bit", "queue")
    run_cfg = dict(cfg, samples=4 if mode == "forward" else 2)
    input_path = OUT / f"{mode}-config.json"
    input_path.write_text(json.dumps(run_cfg, indent=2) + "\n")
    totals = []
    outputs = {}
    for name in order:
        binding = json.loads((OUT / f"{name}-binary.json").read_text())
        assert (
            hashlib.sha256(pathlib.Path(binding["path"]).read_bytes()).hexdigest()
            == binding["sha256"]
        )
        text = run(name, [binding["path"], str(input_path)])
        rows = [json.loads(line) for line in text.splitlines()]
        assert all(r["task"] == cfg["task"] for r in rows)
        assert rows[-1]["schema"] == "map-work-total-v1"
        assert len(rows) - 1 == run_cfg["samples"] * len(cfg["fixtures"]) * 2
        totals.append(rows[-1])
        outputs[name] = rows[:-1]
    a, b = outputs["queue"], outputs["bit"]
    keys = (
        "sample",
        "fixture",
        "prefix",
        "engine",
        "completed_depth",
        "action",
        "value_bits",
        "pv",
        "nodes",
        "NN",
        "leaf_evaluations",
        "delta_updates",
        "tt_hits",
        "tt_cutoffs",
        "stop",
        "root_history_restored",
    )
    for left, right in zip(a, b):
        assert all(left[k] == right[k] for k in keys)
    result = dict(
        task=cfg["task"],
        schema="map-fixed-work-receipt-v1",
        status="PASS",
        order=order,
        native_NN=sum(t["NN"] for t in totals),
        processed=sum(t["nodes"] for t in totals),
        total_rows=len(a) + len(b),
        matched_rows=len(a),
        snapshots_and_counters_equal=True,
        whole_ns=[t["whole_ns"] for t in totals],
        model_load_ns=[t["model_load_ns"] for t in totals],
    )
(OUT / f"{mode}-result.json").write_text(
    json.dumps(
        dict(
            result, children=receipts, at=datetime.datetime.now(datetime.timezone.utc).isoformat()
        ),
        indent=2,
    )
    + "\n"
)
