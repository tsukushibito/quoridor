"""Bind stopped public train/selection caches and preflight assets before Torch.

Run only in the owner's current NN0 preparation window. No cycle0043 container,
model, optimizer or inference is opened by this preparation.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import tempfile


ROOT = Path("/workspaces/quoridor")
SCOPE = ROOT / "research-data/ai-sigma/frame23-public-sigma-z-learning"
WT = ROOT / ".worktree/frame21-features"
ASSETS = ROOT / ".worktree/assets/checkpoints/frame23-public-sigma-z-learning"


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for body in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(body)
    return h.hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def allocated(roots):
    seen, total = set(), 0
    for root in roots:
        root = Path(root)
        for path in [root] if root.is_file() else root.rglob("*"):
            if path.is_file():
                s = path.stat()
                key = (s.st_dev, s.st_ino)
                if key not in seen:
                    seen.add(key)
                    total += s.st_blocks * 512
    return total


def main():
    parser = argparse.ArgumentParser()
    for name in ("handoff", "producer-stop", "loaded", "storage"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    os.sched_setaffinity(0, {1})
    handoff = json.loads(Path(args.handoff).read_text())
    if handoff.get("schema") != "public-z-immutable-handoff-v3":
        raise ValueError("producer purpose/schema does not match public input contract")
    # Deliberately select the two authorized cycles before calling any loader.
    chosen = [c for c in handoff["train_validation"] if c["cycle"] in (41, 42)]
    if len(chosen) != 2 or {c["cycle"] for c in chosen} != {41, 42}:
        raise ValueError("both authorized stopped caches required")
    if handoff["finite_stop"]["path"] != args.producer_stop or handoff["finite_stop"]["SHA"] != sha(
        args.producer_stop
    ):
        raise ValueError("immutable producer stop binding differs")
    producer_stop = json.loads(Path(args.producer_stop).read_text())
    if (
        not producer_stop["source_stopped"]
        or not producer_stop["allwait"]
        or producer_stop["currentexact"]
    ):
        raise ValueError("producer source/wait/exact stop incomplete")
    caches = []
    source_denominators = []
    for c in sorted(chosen, key=lambda c: c["cycle"]):
        expected = "train" if c["cycle"] == 41 else "validation"
        if c["partition"] != expected or c["selected_rows"] > (
            100000 if expected == "train" else 25000
        ):
            raise ValueError("fixed public cycle/partition/row bound differs")
        caches.append(
            dict(cycle=c["cycle"], split=expected, path=c["cache"], manifest_SHA=c["cache_SHA"])
        )
        selection_path = Path(c["cache"]).parent / "input-selection-frozen.json"
        if sha(selection_path) != c["input_selection_SHA"]:
            raise ValueError("producer before-label input selection changed")
        selection = json.loads(selection_path.read_text())
        if (
            selection["label_payloads_read_at_freeze"] != 0
            or len(selection["selected_original_indices"]) != c["selected_rows"]
            or selection["schema"] != "qualified-original-complete-input-group-prefix-v3"
        ):
            raise ValueError("geometry-qualified original prefix denominator/schema differs")
        source_denominators.append(
            dict(
                cycle=c["cycle"],
                original_rows=c["original_rows"],
                actual_qualified_rows=c["selected_rows"],
                qualified_input_groups=c["groups"],
                input_qualification=c["input_qualification"],
                qualified_z_positive=c["positive"],
                qualified_z_negative=c["negative"],
                qualified_z_zero=c["zero"],
                input_selection=dict(path=str(selection_path), SHA=c["input_selection_SHA"]),
                cache_raw_denominator="all geometry-qualified original input rows including recorded z0",
                skipped_invalid_groups_not_refilled=True,
            )
        )
    from public_inputs import load_inputs

    provenance = {
        "source": "bartolomeo3000/SigmaQuoridor",
        "revision": handoff["source_commit"],
        "handoff": {"path": args.handoff, "SHA": sha(args.handoff)},
        "producer_stop": {"path": args.producer_stop, "SHA": sha(args.producer_stop)},
        "primary": "decisive recorded outcomes conditional on available +/-1; zero reason unavailable",
        "source_denominators": source_denominators,
    }
    inputs = load_inputs(dict(public_caches=caches, source_provenance=provenance))
    binding, rows, _, _, _ = inputs
    counts = binding["masks"]["counts"]
    tr, va = (counts[s]["eligible"] for s in ("train", "validation"))
    write(SCOPE / "actual-input-binding-v1.json", binding)
    scale = ROOT / ".worktree/assets/checkpoints/frame22-teacher-transfer-B-r1/scale.json"
    if sha(scale) != "175f07713409994d0d4c99768267695b0a91ec100baabf202fb4518b56cbdfed":
        raise ValueError("old scale changed")
    ASSETS.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryFile(dir=ASSETS) as probe:
        probe.write(b"registered checkpoint parent preflight\n")
        probe.flush()
        os.fsync(probe.fileno())
    paths = list((WT / "python/quoridor_training").glob("*.py"))
    paths += [
        SCOPE / name
        for name in (
            "run_public_fit.py",
            "public_inputs.py",
            "manage_public.py",
            "prepare_public.py",
        )
    ]
    paths += [scale, Path(args.loaded), Path(args.producer_stop), Path(args.handoff)]
    binary = (
        ROOT / ".artifacts/rust-migration/target/release/route-feature-diagnose-public-z-290-v1"
    )
    paths.append(binary)
    for cache in caches:
        folder = Path(cache["path"])
        manifest = json.loads((folder / "cache.json").read_text())
        paths.append(folder / "cache.json")
        paths.append(folder.parent / "input-selection-frozen.json")
        paths.extend(folder / name for name in manifest["sha256"])
    hashes = {str(p): sha(p) for p in paths}
    roots = [
        ROOT / "research-data/ai-sigma/frame23-independent-teacher-learning",
        ROOT / ".worktree/assets/checkpoints/frame23-independent-teacher-learning",
        SCOPE,
        ASSETS,
        ROOT / "docs/reports/ai-sigma-hypothesis-frame23-data-scale-learning.md",
        ROOT / "docs/reports/ai-sigma-hypothesis-frame23-public-z-learning.md",
    ]
    global_storage = json.loads(Path(args.storage).read_text())
    if (
        global_storage.get("errors")
        or global_storage["current_plus_unused_unknown_bytes"] > global_storage["cap_bytes"]
        or global_storage["shared_learning"]["reserved_bytes"] != 64 * 1024**2
    ):
        raise ValueError("parent same64 coverage/current+unknown invalid")
    roots.extend(Path(p) for p in global_storage["shared_learning"]["scope_paths"])
    measured_current = allocated(roots)
    # Keep the keeper's prior retained quantity as a floor; a planned absent path
    # is never used to reduce unknown or historical ownership accounting.
    current = max(
        measured_current, global_storage["shared_learning"]["fresh_current_allocated_bytes"]
    )
    # Shared native build growth is accounted in the existing shared build pool.
    forecast = 16 * 1024**2 + 6 * 1024**2 + 2 * 1024**2
    storage = dict(
        UTC=datetime.now(timezone.utc).isoformat(),
        admission="within",
        errors=[],
        old286_and_new290_same64=True,
        retained_roots=[str(p) for p in roots],
        current_allocated=current,
        measured_actual_roots_allocated=measured_current,
        keeper_retained_floor=global_storage["shared_learning"]["fresh_current_allocated_bytes"],
        future_science_peak=16 * 1024**2,
        uniqueGit_temp=6 * 1024**2,
        remaining_metadata=2 * 1024**2,
        current_plus_forecast=current + forecast,
        cap=64 * 1024**2,
        global_evidence={"path": args.storage, "SHA": sha(args.storage)},
        unknown_retained=True,
        global_future_free_guarantee=False,
    )
    if current + forecast > storage["cap"]:
        raise ValueError("current+science+uniqueGit/temp+remaining metadata exceeds same64MiB")
    write(SCOPE / "storage-public-current-v1.json", storage)
    points = [0, 1, 5, 20, 50, 100, 200, 1000, 4000, 7813]
    total_nn, total_processed = 0, 0
    for name, steps, pts in (
        ("public-z-1m", 7813, points),
        ("public-z-2m", 15625, points + [10000, 12000, 15625]),
    ):
        output = ASSETS / (name + "-r1")
        if output.exists():
            raise ValueError("existing output cannot be replaced")
        fit_nn = steps * 128 + len(pts) * (tr + va)
        sample_upper = fit_nn + 306
        total_nn += sample_upper
        total_processed += sample_upper + len(rows)
        config = dict(
            model=dict(feature_version="QF1", transformer_width=32, hidden_width=32, dropout=0),
            optimizer=dict(name="adam", lr=1e-4, weight_decay=0, momentum=0.0),
            training=dict(
                steps=steps,
                batch_size=128,
                seed=19080311,
                target="z",
                sampling="row",
                scheduler="none",
                device="cpu",
                threads=1,
            ),
            evaluation=dict(
                interval=100,
                batch_size=1024,
                monitor="game",
                early_stopping_patience=0,
                min_delta=0,
            ),
            limits=dict(seconds=590, samples=fit_nn),
            data=dict(overlap_policy="error"),
        )
        config_path = SCOPE / (name + "-config-v1.json")
        write(config_path, config)
        regpath = SCOPE / (name + "-registration-v1.json")
        reg = dict(
            task=name,
            scope=str(SCOPE),
            output=str(output),
            config=str(config_path),
            public_caches=caches,
            source_provenance=provenance,
            input_SHA=dict(hashes),
            train_rows=tr,
            selection_rows=va,
            raw_rows=len(rows),
            fit_NN=fit_nn,
            sample_upper=sample_upper,
            processed_upper=sample_upper + len(rows),
            points=pts,
            parity_step=200,
            native_binary=str(binary),
            initial_weights_SHA="ec4167ccb5042cfe937b23850a1b52d1cd9cf6c3fb1d348627bfe6cc7d023cc5",
            fixed_scale={"path": str(scale), "SHA": sha(scale)},
            process_helpers=str(
                ROOT / "research-data/ai-sigma/frame23-independent-teachers/control-v1.py"
            ),
            loaded=args.loaded,
            registry=str(ROOT / ".artifacts/research-team/registry.json"),
            owner="codex:01a0f31c-2e4b-7170-82c5-69e1428c2418",
            python_path=str(WT / "python"),
            storage_evidence={
                "path": str(SCOPE / "storage-public-current-v1.json"),
                "SHA": sha(SCOPE / "storage-public-current-v1.json"),
            },
            hard_seconds=600,
            end_at="2026-10-05T22:30:00Z",
            argv=[
                "/home/vscode/.cache/inference/envs/quoridor-training/bin/python",
                "-B",
                str(SCOPE / "run_public_fit.py"),
                str(regpath),
            ],
            expected_output=str(output / "result.json"),
            expected_task="frame23-public-z-290-" + name,
        )
        reg["input_SHA"][str(config_path)] = sha(config_path)
        write(regpath, reg)
    if total_nn > 6000000 or total_processed > 8000000:
        raise ValueError("actual two-fit counters exceed new290 cap")
    write(
        SCOPE / "actual-registration-summary-v1.json",
        dict(
            status="REGISTERED_NOT_SPAWNED",
            NN0=True,
            modelNN=0,
            counts=counts,
            raw_rows=len(rows),
            total_two_fit_NN=total_nn,
            total_two_fit_processed=total_processed,
            storage=storage,
            future_labels_opened=False,
            independent_game_history="UNAVAILABLE",
        ),
    )


if __name__ == "__main__":
    main()
