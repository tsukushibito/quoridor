"""CPU1 public learning guardian; readonly process/binding helpers are reused."""

import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import time


def scientific_process(h, process):
    if h.science(process):
        return True
    argv = process["argv"]
    if not argv:
        return False
    executable = Path(argv[0]).name
    if "/rust-migration/target/" in argv[0]:
        return True
    if executable.startswith("python"):
        script = next((s for s in argv[1:] if not s.startswith("-")), "")
        return "/research-data/ai-sigma/" in script
    return executable.startswith(("route-feature-diagnose", "public-sigma", "teacher-"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration")
    regpath = Path(parser.parse_args().registration)
    reg = json.loads(regpath.read_text())
    spec = importlib.util.spec_from_file_location(
        "readonly_process_helpers", reg["process_helpers"]
    )
    h = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(h)
    os.sched_setaffinity(0, {1})
    scope = Path(reg["scope"])
    ledgerpath = scope / "science-ledger.json"
    ledger = h.read(ledgerpath) if ledgerpath.exists() else []
    if any(r["task"] == reg["task"] for r in ledger):
        raise ValueError("condition already entered; no automatic supplementary fit")
    if len(ledger) >= 4 or sum(r["charged_NN"] for r in ledger) + reg["sample_upper"] > 6000000:
        raise ValueError("MAX4 / modelNN6m refusal")
    if sum(r["charged_processed"] for r in ledger) + reg["processed_upper"] > 8000000:
        raise ValueError("processed8m refusal")
    if (
        not 0 < reg["hard_seconds"] <= 600
        or sum(r["wall_s"] for r in ledger) + reg["hard_seconds"] > 2400
    ):
        raise ValueError("individual600 / science2400 refusal")
    out = scope / (reg["task"] + "-management")
    out.mkdir(exist_ok=False)
    record = {
        "task": reg["task"],
        "spawned": False,
        "charged_NN": reg["sample_upper"],
        "charged_processed": reg["processed_upper"],
        "wall_s": reg["hard_seconds"],
    }
    child, recorded, reason, peak = None, {}, None, 0
    try:
        for path, digest in reg["input_SHA"].items():
            if h.sha(path) != digest:
                raise ValueError("registered source/input changed: " + path)
        binding = h.binding(reg)
        if datetime.now(timezone.utc) >= datetime.fromisoformat(
            reg["end_at"].replace("Z", "+00:00")
        ):
            raise ValueError("science deadline already reached")
        for issue in ("quoridor-4lc", "quoridor-4lc.290"):
            read = subprocess.run(
                ["bash", "/workspaces/quoridor/scripts/dev/beads.sh", "show", issue, "--json"],
                capture_output=True,
                text=True,
                timeout=20,
                check=True,
            )
            value = json.loads(read.stdout)[0]
            if value["status"] not in ("open", "in_progress") or any(
                "pause" in label for label in value.get("labels", [])
            ):
                raise ValueError("pause/status refusal")
            if issue.endswith(".290") and value["assignee"] != reg["owner"]:
                raise ValueError("different owner")
        point = h.snapshot()
        own = h.ancestors(os.getpid(), point)
        foreign = [p for p in point if scientific_process(h, p) and p["pid"] not in own]
        if foreign:
            raise ValueError("foreign compute present: " + json.dumps(foreign))
        gpu_apps = h.gpu_state()
        if gpu_apps:
            raise ValueError("GPU generation present: " + json.dumps(gpu_apps))
        available = next(
            int(line.split()[1]) * 1024
            for line in Path("/proc/meminfo").read_text().splitlines()
            if line.startswith("MemAvailable:")
        )
        if (
            available < 2 * 1024**3
            or sum(p["rss"] for p in foreign) + 1879048192 + 1024**3 > 8 * 1024**3
        ):
            raise ValueError("RAM/headroom refusal")
        storage = h.read(reg["storage_evidence"]["path"])
        if (
            h.sha(reg["storage_evidence"]["path"]) != reg["storage_evidence"]["SHA"]
            or storage.get("admission") != "within"
            or storage.get("errors")
        ):
            raise ValueError("storage admission refusal")
        global_ref = storage["global_evidence"]
        global_storage = h.read(global_ref["path"])
        if (
            h.sha(global_ref["path"]) != global_ref["SHA"]
            or global_storage.get("errors")
            or global_storage["current_plus_unused_unknown_bytes"] > global_storage["cap_bytes"]
        ):
            raise ValueError("parent current+unused+unknown admission refusal")
        h.write(
            out / "admission.json",
            {
                "UTC": datetime.now(timezone.utc).isoformat(),
                "binding": binding,
                "foreign": foreign,
                "available": available,
                "CPU": [1],
                "GPU": 0,
                "GPU_apps": gpu_apps,
                "storage": reg["storage_evidence"],
                "owner_checked": True,
                "future_free_guarantee": False,
            },
        )
        env = dict(
            os.environ,
            PYTHONPATH=reg["python_path"],
            ORT_DISABLE_TELEMETRY="1",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
        )
        with (out / "command.log").open("wb") as stream:
            child = subprocess.Popen(
                reg["argv"],
                cwd="/workspaces/quoridor",
                env=env,
                stdout=stream,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            record.update(
                spawned=True,
                identity=h.proc(child.pid),
                actualstart=datetime.now(timezone.utc).isoformat(),
                argv=reg["argv"],
                state="RUNNING",
            )
            ledger.append(record)
            h.write(ledgerpath, ledger)
            h.write(out / "start.json", record)
            start = time.monotonic()
            previous = {p["pid"]: p for p in point}
            checkat = start
            while child.poll() is None:
                point = h.snapshot()
                family = [p for p in point if p["pgrp"] == child.pid]
                recorded.update({(p["pid"], p["start_ticks"]): p for p in family})
                manager = h.proc(os.getpid())
                peak = max(peak, sum(p["rss"] for p in family) + manager["rss"])
                if peak > 1879048192 or any(p["cpus"] != [1] for p in family):
                    reason = "RAM_OR_AFFINITY_GUARD"
                excluded = own | {p["pid"] for p in family}
                progressing = [
                    p
                    for p in point
                    if scientific_process(h, p)
                    and p["pid"] not in excluded
                    and p["cpu_ticks"] > previous.get(p["pid"], {}).get("cpu_ticks", p["cpu_ticks"])
                ]
                if progressing:
                    reason = "FOREIGN_COMPUTE_STARTED"
                if time.monotonic() - start >= reg["hard_seconds"]:
                    reason = "TIME_GUARD"
                if datetime.now(timezone.utc) >= datetime.fromisoformat(
                    reg["end_at"].replace("Z", "+00:00")
                ):
                    reason = "DEADLINE"
                if time.monotonic() - checkat > 5:
                    h.binding(reg)
                    checkat = time.monotonic()
                if reason:
                    break
                previous = {p["pid"]: p for p in point}
                time.sleep(0.1)
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
            child.wait()
            record.update(exit=child.returncode, reason=reason, wall_s=time.monotonic() - start)
        result = h.read(reg["expected_output"])
        if (
            child.returncode
            or reason
            or result["task"] != reg["expected_task"]
            or result["schema"] != "public-z-learning-v1"
            or result["status"] != "PASS"
        ):
            raise ValueError("scientific purpose/output incomplete")
        if result["total_NN"] > reg["sample_upper"] or result["processed"] > reg["processed_upper"]:
            raise ValueError("actual sample exceeded admitted bound")
        record.update(charged_NN=result["total_NN"], charged_processed=result["processed"])
    except Exception as error:
        h.write(
            out / "failure.json",
            {
                "type": type(error).__name__,
                "message": str(error),
                "spawned": record["spawned"],
                "reserved_sample_retained_if_spawned": True,
            },
        )
        raise
    finally:
        if child is not None:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
            # Also inspect the current group: a short orphan could fall between
            # samples and must not be treated as absent just because unrecorded.
            for p in h.snapshot():
                if p["pgrp"] == child.pid:
                    recorded[(p["pid"], p["start_ticks"])] = p
            left = [p for p in recorded.values() if h.exact(p)]
            record.update(
                state="STOPPED",
                waited=True,
                currentexact_remaining=left,
                peak_RSS=peak,
                recorded_children=list(recorded.values()),
                stopped_at=datetime.now(timezone.utc).isoformat(),
            )
            h.write(ledgerpath, ledger)
            h.write(out / "stop.json", record)
            if left:
                raise ValueError("recorded children remain")


if __name__ == "__main__":
    main()
