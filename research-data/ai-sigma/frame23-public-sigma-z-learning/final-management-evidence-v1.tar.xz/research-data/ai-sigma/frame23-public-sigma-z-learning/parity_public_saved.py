"""One budgeted parity job on retained 1m checkpoints; training is absent."""

import argparse
import json
import os
from pathlib import Path

os.environ["ORT_DISABLE_TELEMETRY"] = "1"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration")
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    from run_public_fit import parity_saved, sha

    if reg["task"] != "public-z-1m-parity":
        raise ValueError("saved parity purpose differs")
    for path, digest in reg["input_SHA"].items():
        if sha(path) != digest:
            raise ValueError("registered source or retained input changed: " + path)
    output = Path(reg["output"])
    output.mkdir(exist_ok=False)
    from public_inputs import load_inputs
    from quoridor_training.common import resolve_config

    inputs = load_inputs(reg)
    cfg = resolve_config(reg["config"])
    scale = json.loads(Path(reg["fixed_scale"]["path"]).read_text())
    import torch

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    nn = parity_saved(reg, output, cfg, scale, inputs)
    if nn != reg["sample_upper"]:
        raise ValueError("saved parity NN formula differs")
    result = {
        "task": reg["expected_task"],
        "schema": "public-z-learning-v1",
        "status": "PASS",
        "total_NN": nn,
        "processed": len(inputs[1]) + nn,
        "source_output": reg["source_output"],
        "fit_repeated": False,
        "original_first_entry": "FAILED_NATIVE_PARITY_RESERVED_COST_RETAINED",
        "future_labels_opened": False,
    }
    (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
