"""Read only stopped 0041/0042 native caches; no future labels or model import.

Public source is STM-normalized. A canonical side value is not the unavailable
absolute side, and shard/group names do not establish independent games.
"""

import hashlib
import json
from pathlib import Path
import struct


def decisive(value):
    """Reason-unavailable recorded zero is excluded without rewriting its value."""
    if value == 0:
        return False, "EXCLUDED_TERMINATION_REASON_UNAVAILABLE"
    if value not in (-1, 1):
        raise ValueError("public z must be a recorded -1/0/+1 outcome")
    return True, None


def input_key(features, distance):
    import numpy as np

    if features.shape != (2, 312) or distance.shape != (2,):
        raise ValueError("public QF1 shape")
    if not np.isin(features, (0, 1)).all() or not np.isfinite(distance).all():
        raise ValueError("public sparse input/finite f32 distance")
    ids = [np.flatnonzero(view).astype("<u2").tobytes() for view in features]
    return (
        b"QF1-f32-STM-v1\0"
        + struct.pack("<HH", len(ids[0]), len(ids[1]))
        + b"".join(ids)
        + distance.astype("<f4").tobytes()
    )


def apply_masks(rows, x, distance, labels):
    """All raw validation inputs are the train reference; target never sets exposure."""
    from quoridor_training.common import validate_target_tensor

    validate_target_tensor(rows, labels[:, 1], "z")
    if len(rows) != len(x) or len(rows) != len(distance):
        raise ValueError("cache lengths differ")
    if len({r["id"] for r in rows}) != len(rows):
        raise ValueError("public row identity duplicated")
    if any(r["split"] not in ("train", "validation") for r in rows):
        raise ValueError("future/unknown labels forbidden")
    keys = [input_key(xx, dd) for xx, dd in zip(x, distance)]
    validation_keys = {key for key, row in zip(keys, rows) if row["split"] == "validation"}
    counts = {
        s: {
            "raw": 0,
            "decisive": 0,
            "zero": 0,
            "producer_ineligible": 0,
            "input_exposure": 0,
            "eligible": 0,
        }
        for s in ("train", "validation")
    }
    selected = []
    for row, key in zip(rows, keys):
        if row.get("rootmean") is not None:
            raise ValueError("external public z must not invent a search rootmean")
        r = dict(row)
        c = counts[r["split"]]
        c["raw"] += 1
        valid, reason = decisive(r["z"])
        c["decisive" if valid else "zero"] += 1
        producer_eligible = bool(r["primary_eligible"])
        c["producer_ineligible"] += not producer_eligible
        exposed = r["split"] == "train" and key in validation_keys
        c["input_exposure"] += exposed
        r["primary_eligible"] = producer_eligible and valid and not exposed
        c["eligible"] += r["primary_eligible"]
        r["exclusion_reason"] = reason or (
            "EXCLUDED_ACTUAL_STM_INPUT_EXPOSURE" if exposed else None
        )
        r["input_signature"] = hashlib.sha256(key).hexdigest()
        selected.append(r)
    if not all(c["eligible"] for c in counts.values()):
        raise ValueError("nonempty decisive unexposed train/selection required")
    return (
        selected,
        {
            "counts": counts,
            "predicate": "actual STM QF1 IDs plus rawdistance f32 bits; unavailable state/history not reconstructed",
            "history_coverage": "UNAVAILABLE",
            "independent_game_count": "UNAVAILABLE",
            "raw_validation_input_reference_used": True,
        },
        keys,
    )


def validate_input_metadata(rows, x, rawdistance):
    import numpy as np

    if len(rows) != len(x) or len(rows) != len(rawdistance):
        raise ValueError("metadata/tensor row denominator differs")
    for row, features, distance in zip(rows, x, rawdistance):
        if (
            row.get("ids_order") != "P1_then_P2"
            or row.get("distance_order") != "STM_then_opponent_f32"
            or row.get("tensor_view_order") != "STM_then_opponent"
            or row.get("side") not in (1, 2)
        ):
            raise ValueError("producer canonical input/order metadata missing")
        ids = row["ids"] if row["side"] == 1 else row["ids"][::-1]
        if len(ids) != 2 or any(
            sorted(view) != np.flatnonzero(tensor).tolist() for view, tensor in zip(ids, features)
        ):
            raise ValueError("metadata P1/P2 to actual STM sparse tensor differs")
        if np.asarray(row["distance"], dtype="<f4").tobytes() != distance.astype("<f4").tobytes():
            raise ValueError("metadata STM rawdistance f32 differs")


def load_inputs(reg):
    import numpy as np
    from quoridor_training.cache import load, sha

    parts = []
    for source in reg["public_caches"]:
        if (source["cycle"], source["split"]) not in ((41, "train"), (42, "validation")):
            raise ValueError("only fixed 0041 train/0042 selection allowlist")
        path = Path(source["path"])
        if sha(path / "cache.json") != source["manifest_SHA"]:
            raise ValueError("public native cache manifest changed")
        part = load(path)
        if any(r["split"] != source["split"] for r in part[1]):
            raise ValueError("public native split differs from registered cycle")
        validate_input_metadata(part[1], part[2], part[3])
        parts.append(part)
    if len(parts) != 2 or {p["cycle"] for p in reg["public_caches"]} != {41, 42}:
        raise ValueError("exactly two fixed source caches required")
    rows = []
    for source, part in zip(reg["public_caches"], parts):
        for row in part[1]:
            r = dict(row)
            r["producer_group"] = r.get("group")
            r["group"] = f"public-cycle-{source['cycle']:04}"
            r["group_basis"] = "cycle shard; independent game identity unavailable"
            rows.append(r)
    x = np.concatenate([p[2] for p in parts])
    rawdistance = np.concatenate([p[3] for p in parts])
    labels = np.concatenate([p[4] for p in parts])
    rows, masks, keys = apply_masks(rows, x, rawdistance, labels)
    d = np.column_stack([rawdistance, np.zeros((len(rows), 4), dtype=np.float32)])
    binding = {
        "public_caches": reg["public_caches"],
        "source_provenance": reg["source_provenance"],
        "masks": masks,
        "input_frame": "canonical STM; original absolute side/game/history/ply unavailable",
        "future_labels_opened": False,
        "metadata_tensor_order_parity": "all authorized cache rows, exact activeIDs/f32 distance bits",
    }
    binding["dataset_sha"] = hashlib.sha256(
        json.dumps(binding, sort_keys=True).encode()
        + b"".join(hashlib.sha256(k).digest() for k in keys)
    ).hexdigest()
    return binding, rows, x, d, labels
