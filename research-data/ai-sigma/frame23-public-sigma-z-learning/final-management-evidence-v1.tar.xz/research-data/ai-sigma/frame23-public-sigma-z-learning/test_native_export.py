"""Check real export manifest framing with no model/framework or inference."""

import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

from quoridor_training import route_training


class NativeExportTests(unittest.TestCase):
    def test_native_schema_and_training_provenance_separate(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model"
            original = b"unchanged-f32-weight-witness"

            def fake_export(_model, config, _statistics, _distance_fit, out):
                out.mkdir()
                (out / "weights.f32").write_bytes(original)
                manifest = {
                    "weights": "weights.f32",
                    "training_target": config["training"]["target"],
                    "target_semantics": "recorded-outcome",
                    "transformer_width": 32,
                    "hidden_width": 32,
                    "source_kind": "test-export",
                }
                file = out / "manifest.json"
                file.write_text(json.dumps(manifest))
                return file

            constants = types.ModuleType("quoridor_training.residual_model")
            constants.FEATURE_VERSION = "QF1-route4-f32-STM-scaled-residual-v3"
            constants.ROUTE_VERSION = "shortest-dag4-f32-STM-v1"
            with (
                patch.object(route_training, "export", fake_export),
                patch.dict(
                    sys.modules, {"quoridor_training.residual_model": constants}
                ),
            ):
                result = route_training.export_residual(
                    None,
                    {
                        "model": {"transformer_width": 32, "hidden_width": 32},
                        "training": {"target": "z"},
                    },
                    {},
                    {},
                    path,
                    route_mode="zero4",
                    route_statistics={"mu_f32": [0.0] * 4, "sigma_f32": [1.0] * 4},
                )
            manifest = json.loads(result.read_text())
            self.assertNotIn("training_target", manifest)
            self.assertNotIn("target_semantics", manifest)
            self.assertEqual(manifest["schema"], "quoridor-nnue-distance-residual-v3")
            self.assertEqual((path / "weights.f32").read_bytes(), original)
            self.assertEqual(
                json.loads((path / "training-target.json").read_text()),
                {"training_target": "z", "target_semantics": "recorded-outcome"},
            )
            self.assertNotIn("torch", sys.modules)


if __name__ == "__main__":
    unittest.main()
