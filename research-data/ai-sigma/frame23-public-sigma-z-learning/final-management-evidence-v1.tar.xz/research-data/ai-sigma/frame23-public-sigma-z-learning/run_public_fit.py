"""Registered public-z fit through the maintained QF1 residual trainer.

All forwards, parity calls and native children belong to its admitted guardian.
This entry does not fetch a model, decode NPZ or open cycle0043 labels.
"""

import argparse
from functools import partial
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

os.environ["ORT_DISABLE_TELEMETRY"] = "1"


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for body in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(body)
    return digest.hexdigest()


def parity_saved(reg, output, cfg, scale, inputs):
    """Fixed saved checkpoints; no training or condition replacement."""
    import numpy as np
    import torch
    from quoridor_training.residual_model import DistanceResidualModel
    from quoridor_training.train import write

    route_stats = {"mu_f32": [0.0] * 4, "sigma_f32": [1.0] * 4}
    _, rows, x, d, _ = inputs
    tr = [i for i, r in enumerate(rows) if r["split"] == "train" and r["primary_eligible"]]
    va = [i for i, r in enumerate(rows) if r["split"] == "validation" and r["primary_eligible"]]
    # Fixed original prefix witnesses: first six eligible train and selection,
    # each with the equivalent P2 canonical view. This is not original side data.
    witness = tr[:6] + va[:6]
    if len(witness) != 12:
        raise ValueError("fixed witness denominator differs")
    canonical = []
    for i in witness:
        ids = [np.flatnonzero(view).tolist() for view in x[i]]
        for side in (1, 2):
            canonical.append(
                {
                    "id": rows[i]["id"] + f"-virtualP{side}",
                    "side": side,
                    "ids": ids if side == 1 else ids[::-1],
                    "distance": d[i, :2].tolist(),
                }
            )
    native_body = "".join(json.dumps(r) + "\n" for r in canonical)
    model = DistanceResidualModel(
        cfg["model"], scale, a=0, b=8, routes=False, route_statistics=route_stats
    )
    reports = []
    for step in (0, reg["parity_step"], cfg["training"]["steps"]):
        cp = torch.load(
            Path(reg.get("source_output", output)) / f"step{step}.pt",
            map_location="cpu",
            weights_only=True,
        )
        model.load_state_dict(cp["model"])
        model.eval()
        with torch.inference_mode():
            expected = model(
                torch.from_numpy(x[witness]),
                torch.from_numpy(d[witness]),
                torch.ones(12, dtype=torch.long),
            ).numpy()
        cmd = [
            reg["native_binary"],
            "model",
            str(Path(reg.get("native_manifest_root", output)) / f"step{step}-model/manifest.json"),
        ]
        run = subprocess.run(
            cmd,
            input=native_body,
            text=True,
            capture_output=True,
            timeout=30,
            check=False,
        )
        if run.returncode:
            (output / f"native-step{step}.stderr").write_text(run.stderr)
            raise ValueError("native parity CLI failed: " + run.stderr)
        actual = [json.loads(line) for line in run.stdout.splitlines()]
        if len(actual) != 24 or [v["id"] for v in actual] != [r["id"] for r in canonical]:
            raise ValueError("native purpose/order parity differs")
        errors = [
            abs(float(expected[i // 2]) - v[key])
            for i, v in enumerate(actual)
            for key in ("value", "delta_value", "simd_value")
        ]
        if any(
            error > 1e-6 + 1e-6 * abs(float(expected[i // 6])) for i, error in enumerate(errors)
        ):
            raise ValueError("native P2/full/delta parity differs")
        returns = [canonical[i] for i in (0, 2, 0, 12, 14, 12)]
        returned = subprocess.run(
            cmd,
            input="".join(json.dumps(r) + "\n" for r in returns),
            text=True,
            capture_output=True,
            timeout=30,
            check=True,
        )
        rv = [json.loads(line) for line in returned.stdout.splitlines()]
        if len(rv) != 6 or any(
            abs(rv[a][key] - rv[b][key]) > 1e-6 + 1e-6 * abs(rv[a][key])
            for a, b in ((0, 2), (3, 5))
            for key in ("value", "delta_value", "simd_value")
        ):
            raise ValueError("native input parent return differs")
        reports.append({"step": step, "max_abs": max(errors), "rows": actual, "parent_return": rv})
    parity_nn = 3 * (12 + 24 * 3 + 6 * 3)
    write(
        output / "parity.json",
        {
            "reports": reports,
            "NN": parity_nn,
            "absolute_tolerance": 1e-6,
            "relative_tolerance": 1e-6,
            "scope": "virtualP2/scalar-SIMD/full-delta/input-return; original absolute side unknown; finite witnesses only",
        },
    )
    return parity_nn


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration")
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    if reg["task"] not in ("public-z-1m", "public-z-2m"):
        raise ValueError("unregistered public learning condition")
    for path, digest in reg["input_SHA"].items():
        if sha(path) != digest:
            raise ValueError("registered source/input changed: " + path)
    output = Path(reg["output"])
    if output.exists() or not output.parent.is_dir():
        raise ValueError("checkpoint parent preflight/previous-output protection")
    import numpy as np
    from public_inputs import load_inputs
    from quoridor_training.common import resolve_config

    cfg = resolve_config(reg["config"])
    if cfg["training"]["target"] != "z" or cfg["training"]["sampling"] != "row":
        raise ValueError("public z/row sampling differs")
    inputs = load_inputs(reg)
    binding, rows, x, d, labels = inputs
    tr = [i for i, r in enumerate(rows) if r["split"] == "train" and r["primary_eligible"]]
    va = [i for i, r in enumerate(rows) if r["split"] == "validation" and r["primary_eligible"]]
    count = cfg["training"]["steps"] * 128 + len(reg["points"]) * (len(tr) + len(va))
    if (len(tr), len(va), count) != (
        reg["train_rows"],
        reg["selection_rows"],
        reg["fit_NN"],
    ):
        raise ValueError("actual mask denominators/sample formula differs")
    if min(len(tr), len(va)) < 6:
        raise ValueError("registered twelve witness denominator unavailable before model")
    # Release the temporary original cache mappings/row dictionaries before
    # framework import; keep only the admitted concatenated corpus in memory.
    import torch
    from quoridor_training.residual_model import DistanceResidualModel
    from quoridor_training.route_training import export_residual
    from quoridor_training.train import train, write

    scale = json.loads(Path(reg["fixed_scale"]["path"]).read_text())
    route_stats = {"mu_f32": [0.0] * 4, "sigma_f32": [1.0] * 4}

    def build(config, statistics):
        model = DistanceResidualModel(
            config, statistics, a=0, b=8, routes=False, route_statistics=route_stats
        )
        vector = np.concatenate(
            [
                p.detach().numpy().astype("<f4").reshape(-1)
                for p in (
                    model.ft.weight,
                    model.ft.bias,
                    model.h.weight,
                    model.h.bias,
                    model.out.weight,
                    model.out.bias,
                )
            ]
        )
        if hashlib.sha256(vector.tobytes()).hexdigest() != reg["initial_weights_SHA"]:
            raise ValueError("common initial tensor SHA differs")
        if torch.count_nonzero(model.out.weight) or torch.count_nonzero(model.out.bias):
            raise ValueError("D-holding zero head differs")
        return model

    def observer(step, trainrows, ptrain, valrows, pval):
        if step == 0:
            ref = torch.tanh(torch.from_numpy(np.float32(8) * (d[:, 1] - d[:, 0]))).numpy()
            if not np.array_equal(ptrain, ref[tr]) or not np.array_equal(pval, ref[va]):
                raise ValueError("initial D bit parity differs")
            write(output / "validation-order.json", [r["id"] for r in valrows])
            write(output / "input-binding.json", binding)
            for name, selected in (
                ("Tseen", trainrows),
                ("Vraw", [r for r in rows if r["split"] == "validation"]),
            ):
                with gzip.open(output / (name + "-references.jsonl.gz"), "wt") as stream:
                    for r in selected:
                        stream.write(
                            json.dumps(
                                {
                                    key: r.get(key)
                                    for key in (
                                        "id",
                                        "input_signature",
                                        "producer_group",
                                        "group",
                                        "group_basis",
                                    )
                                },
                                separators=(",", ":"),
                            )
                            + "\n"
                        )
        np.asarray(pval, dtype="<f4").tofile(output / f"validation-step{step}.f32")

    freeze = train(
        "registered-public-caches",
        output,
        reg["config"],
        model_builder=build,
        model_export=partial(export_residual, route_mode="zero4", route_statistics=route_stats),
        cache_loader=lambda _: inputs,
        export_onnx=False,
        evaluation_points=reg["points"],
        checkpoint_steps=reg["points"],
        statistics_override=scale,
        distance_fit_override={"a": 0, "b": 8},
        evaluation_observer=observer,
    )
    parity_nn = parity_saved(reg, output, cfg, scale, inputs)
    if count + parity_nn != reg["sample_upper"]:
        raise ValueError("final charged NN formula differs")
    write(
        output / "result.json",
        {
            "task": "frame23-public-z-290-" + reg["task"],
            "schema": "public-z-learning-v1",
            "status": "PASS",
            "total_NN": count + parity_nn,
            "processed": count + parity_nn + len(rows),
            "freeze": freeze,
            "input_binding_SHA": sha(output / "input-binding.json"),
            "source_reg_SHA": sha(args.registration),
            "future_labels_opened": False,
            "strength": "NOT_ESTABLISHED",
        },
    )


if __name__ == "__main__":
    main()
