"""Bounded target/exposure fixtures; no public corpus labels or model import."""

import unittest
import numpy as np
from public_inputs import apply_masks, decisive, input_key, validate_input_metadata


class PublicInputsTests(unittest.TestCase):
    def fixture(self):
        rows = [
            {
                "id": str(i),
                "split": split,
                "primary_eligible": True,
                "rootmean": None,
                "z": z,
                "group": split,
            }
            for i, (split, z) in enumerate(
                [("train", 1), ("train", -1), ("validation", 1), ("validation", 0)]
            )
        ]
        x = np.zeros((4, 2, 312), dtype=np.float32)
        for i in range(4):
            x[i, :, i] = 1
        d = np.full((4, 2), 0.1, dtype=np.float32)
        y = np.column_stack(
            [np.full(4, np.nan, dtype=np.float32), np.array([1, -1, 1, 0], dtype=np.float32)]
        )
        return rows, x, d, y

    def test_zero_is_excluded_with_denominator(self):
        rows, masks, _ = apply_masks(*self.fixture())
        self.assertFalse(rows[-1]["primary_eligible"])
        self.assertEqual(rows[-1]["z"], 0)
        self.assertEqual(rows[-1]["exclusion_reason"], "EXCLUDED_TERMINATION_REASON_UNAVAILABLE")
        self.assertEqual(
            masks["counts"]["validation"],
            {
                "raw": 2,
                "decisive": 1,
                "zero": 1,
                "producer_ineligible": 0,
                "input_exposure": 0,
                "eligible": 1,
            },
        )

    def test_raw_validation_zero_input_still_excludes_train(self):
        rows, x, d, y = self.fixture()
        x[0] = x[3]
        selected, masks, _ = apply_masks(rows, x, d, y)
        self.assertFalse(selected[0]["primary_eligible"])
        self.assertEqual(masks["counts"]["train"]["input_exposure"], 1)
        rows[3]["z"] = -1
        y[3, 1] = -1
        self.assertEqual(apply_masks(rows, x, d, y)[1]["counts"]["train"]["input_exposure"], 1)

    def test_input_key_uses_f32_and_order(self):
        _, x, d, _ = self.fixture()
        self.assertEqual(input_key(x[0], d[0]), input_key(x[0], d[0].astype(np.float64)))
        changed = x[0].copy()
        changed[1, 7] = 1
        self.assertNotEqual(input_key(x[0], d[0]), input_key(changed, d[0]))

    def test_future_partition_and_invalid_outcome_rejected(self):
        rows, x, d, y = self.fixture()
        rows[0]["split"] = "test"
        with self.assertRaises(ValueError):
            apply_masks(rows, x, d, y)
        with self.assertRaises(ValueError):
            decisive(0.5)

    def test_p2_metadata_is_ordered_once_distance_already_stm(self):
        x = np.zeros((1, 2, 312), dtype=np.float32)
        x[0, 0, 3] = x[0, 1, 7] = 1
        d = np.array([[0.1, 0.2]], dtype=np.float32)
        row = dict(
            side=2,
            ids=[[7], [3]],
            ids_order="P1_then_P2",
            distance=d[0].tolist(),
            distance_order="STM_then_opponent_f32",
            tensor_view_order="STM_then_opponent",
        )
        validate_input_metadata([row], x, d)
        row["distance"] = d[0, ::-1].tolist()
        with self.assertRaises(ValueError):
            validate_input_metadata([row], x, d)

    def test_incomplete_or_wrong_sparse_metadata_rejected(self):
        x = np.zeros((1, 2, 312), dtype=np.float32)
        d = np.zeros((1, 2), dtype=np.float32)
        with self.assertRaises(ValueError):
            validate_input_metadata([{}], x, d)
        row = dict(
            side=1,
            ids=[[3], []],
            ids_order="P1_then_P2",
            distance=[0, 0],
            distance_order="STM_then_opponent_f32",
            tensor_view_order="STM_then_opponent",
        )
        with self.assertRaises(ValueError):
            validate_input_metadata([row], x, d)


if __name__ == "__main__":
    unittest.main()
