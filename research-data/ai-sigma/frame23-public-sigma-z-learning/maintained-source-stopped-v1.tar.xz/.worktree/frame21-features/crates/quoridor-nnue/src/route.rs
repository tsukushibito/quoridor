//! Compressed shortest-path information; wall-only maps are shared by pawn moves.
//! Counts are capped path counts, not vertex-disjoint paths or wall robustness.
use crate::{Error, Features, Result, features};
use quoridor_core::Position;
use std::sync::Arc;
pub const ROUTE_VERSION: &str = "shortest-dag4-f32-STM-v1";
#[derive(Debug)]
pub(crate) struct RouteMaps {
    counts: [[u8; 81]; 2],
    goals: [[u16; 81]; 2],
}
impl RouteMaps {
    fn build(m: &features::WallMaps) -> Self {
        let p = Position {
            horizontal: m.horizontal,
            vertical: m.vertical,
            ..Position::default()
        };
        let mut counts = [[0u8; 81]; 2];
        let mut goals = [[0u16; 81]; 2];
        for player in 0..2 {
            let mut order: [usize; 81] = std::array::from_fn(|i| i);
            order.sort_by_key(|&i| m.distances[player][i]);
            for cell in order {
                let d = m.distances[player][cell];
                if d == 81 {
                    continue;
                }
                if d == 0 {
                    counts[player][cell] = 1;
                    goals[player][cell] = 1 << (cell % 9);
                    continue;
                }
                for n in neighbors(cell as u8) {
                    if p.is_edge_open(cell as u8, n) && m.distances[player][n as usize] + 1 == d {
                        counts[player][cell] =
                            counts[player][cell].saturating_add(counts[player][n as usize]);
                        goals[player][cell] |= goals[player][n as usize];
                    }
                }
            }
        }
        Self { counts, goals }
    }
}
fn neighbors(c: u8) -> impl Iterator<Item = u8> {
    [
        if c / 9 < 8 { Some(c + 9) } else { None },
        if c / 9 > 0 { Some(c - 9) } else { None },
        if c % 9 < 8 { Some(c + 1) } else { None },
        if c % 9 > 0 { Some(c - 1) } else { None },
    ]
    .into_iter()
    .flatten()
}
pub(crate) fn from_maps(p: Position, m: &features::WallMaps) -> Result<[f32; 4]> {
    let r = m.routes.get_or_init(|| Box::new(RouteMaps::build(m)));
    let side = p.turn as usize;
    let mut result = [0.; 4];
    for (i, player) in [side, side ^ 1].into_iter().enumerate() {
        let cell = p.pawns[player] as usize;
        if m.distances[player][cell] > 80
            || r.counts[player][cell] == 0
            || r.goals[player][cell] == 0
        {
            return Err(Error::Input("unreachable route input".into()));
        }
        result[2 * i] = ((1. + f64::from(r.counts[player][cell])).ln() / 256f64.ln()) as f32;
        result[2 * i + 1] = (f64::from(r.goals[player][cell].count_ones()) / 9.) as f32;
    }
    Ok(result)
}
#[derive(Debug, Default)]
pub struct RouteEncoder {
    maps: Option<Arc<features::WallMaps>>,
}
impl RouteEncoder {
    pub fn encode(&mut self, p: Position) -> Result<(Features, [f32; 4])> {
        self.encode_mode(p, true)
    }
    pub fn encode_mode(&mut self, p: Position, routes: bool) -> Result<(Features, [f32; 4])> {
        p.checked().map_err(|e| Error::Input(e.to_string()))?;
        let (f, m) = features::encode_cached(p, self.maps.as_ref())?;
        let r = if routes { from_maps(p, &m)? } else { [0.; 4] };
        self.maps = Some(m);
        Ok((f, r))
    }
    pub fn clear(&mut self) {
        self.maps = None;
    }
}
/// Recover only the position represented by QF1. Never fabricate history.
/// Both fixed views and the distance bits must round-trip exactly.
fn decode_position(f: &Features) -> Result<Position> {
    crate::validate_features(f)?;
    let one = |start: u16, end: u16| -> Result<u16> {
        let v: Vec<_> = f.ids[0]
            .iter()
            .copied()
            .filter(|&k| k >= start && k < end)
            .collect();
        if v.len() != 1 {
            return Err(Error::Input("one-hot QF1 position field".into()));
        }
        Ok(v[0] - start)
    };
    let mut p = Position {
        pawns: [one(0, 81)? as u8, one(81, 162)? as u8],
        walls_remaining: [one(290, 301)? as u8, one(301, 312)? as u8],
        horizontal: 0,
        vertical: 0,
        turn: f.side,
        winner: None,
    };
    for &k in &f.ids[0] {
        if (162..226).contains(&k) {
            p.horizontal |= 1 << (k - 162);
        }
        if (226..290).contains(&k) {
            p.vertical |= 1 << (k - 226);
        }
    }
    if p.pawns[0] / 9 == 8 {
        p.winner = Some(0);
    }
    if p.pawns[1] / 9 == 0 {
        p.winner = Some(1);
    }
    Ok(p)
}
pub fn position_from_qf1(f: &Features) -> Result<Position> {
    let p = decode_position(f)?;
    p.checked().map_err(|e| Error::Input(e.to_string()))?;
    let encoded = features::encode_qf1(p)?;
    if encoded.ids != f.ids
        || encoded.side != f.side
        || encoded
            .distance
            .iter()
            .zip(f.distance)
            .any(|(a, b)| a.to_bits() != b.to_bits())
    {
        return Err(Error::Input("QF1 position exact round-trip".into()));
    }
    Ok(p)
}
pub fn encode_routes(p: Position) -> Result<[f32; 4]> {
    Ok(RouteEncoder::default().encode(p)?.1)
}

pub(crate) fn cached_from_features(f: &Features, m: &Arc<features::WallMaps>) -> Result<[f32; 4]> {
    let p = decode_position(f)?;
    if p.horizontal != m.horizontal || p.vertical != m.vertical {
        return Err(Error::Input("route wall cache mismatch".into()));
    }
    let (expected, _) = features::encode_cached(p, Some(m))?;
    if expected.ids != f.ids
        || expected
            .distance
            .iter()
            .zip(f.distance)
            .any(|(a, b)| a.to_bits() != b.to_bits())
    {
        return Err(Error::Input(
            "route cached position/side/distance mismatch".into(),
        ));
    }
    from_maps(p, m)
}
