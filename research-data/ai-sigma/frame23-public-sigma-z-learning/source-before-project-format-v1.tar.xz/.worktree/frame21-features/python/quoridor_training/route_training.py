"""Maintained trainer adapter for hash-bound QF1 route input.

No hot-loop JSON/replay. The source train/validation input is decoded once into
bulk tensors; test is neither accepted nor opened.
"""

import argparse
import gzip
import hashlib
import json
import struct
from pathlib import Path
import numpy as np
from .cache import sha
from .cache import load as load_native_cache
from .train import train, export, write, metrics


def model_input_key(features, distance):
    """Actual STM inputs, independent of labels, target and JSON formatting."""
    if features.shape != (2, 312) or distance.shape != (2,):
        raise ValueError("QF1 STM input dimensions")
    if not np.isin(features, [0, 1]).all() or not np.isfinite(distance).all():
        raise ValueError("binary QF1/finite distance")
    return (
        tuple(np.flatnonzero(features[0])),
        tuple(np.flatnonzero(features[1])),
        struct.pack("<ff", *distance),
    )


def select_cache_partition(cache, split, groups=None):
    """Select before fit/statistics; a native train+val cache stays readonly."""
    binding, rows, x, d, y = cache
    if split not in ("train", "validation") or any(
        r["split"] not in ("train", "validation") for r in rows
    ):
        raise ValueError("only registered train/selection-val partitions permitted")
    train_groups = {r["group"] for r in rows if r["split"] == "train"}
    val_groups = {r["group"] for r in rows if r["split"] == "validation"}
    if train_groups & val_groups:
        raise ValueError("cache family crosses partitions")
    available = train_groups if split == "train" else val_groups
    if groups is not None and (
        len(set(groups)) != len(groups) or not set(groups) <= available
    ):
        raise ValueError("registered group selection unavailable/duplicate")
    selected = available if groups is None else set(groups)
    indices = [
        i for i, r in enumerate(rows) if r["split"] == split and r["group"] in selected
    ]
    if not indices:
        raise ValueError("empty requested cache partition")
    selected_binding = dict(binding)
    selected_binding["partition_selection"] = {
        "split": split,
        "groups": sorted(selected),
        "rows": len(indices),
        "source_rows": len(rows),
        "selection_by_target": False,
    }
    selected_binding["dataset_sha"] = hashlib.sha256(
        json.dumps(
            [binding, selected_binding["partition_selection"]], sort_keys=True
        ).encode()
    ).hexdigest()
    return (
        selected_binding,
        [dict(rows[i]) for i in indices],
        x[indices],
        d[indices],
        y[indices],
    )


def read_input_metadata(path):
    """Read existing row metadata; labels in a shared cache are not used for masks."""
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt") as stream:
        rows = [json.loads(line) for line in stream]
    if any(r["split"] not in ("train", "validation") for r in rows):
        raise ValueError("test/unknown metadata forbidden")
    if len({r["id"] for r in rows}) != len(rows):
        raise ValueError("duplicate metadata IDs")
    return rows


def extra_train_inputs(args):
    groups = (
        json.loads(Path(args.extra_train_groups).read_text())
        if args.extra_train_groups
        else None
    )
    extra = select_cache_partition(
        load_native_cache(args.extra_train_cache), "train", groups
    )
    ids = {r["id"] for r in extra[1]}
    metadata = {
        r["id"]: r
        for r in read_input_metadata(args.extra_train_metadata)
        if r["id"] in ids
    }
    required = {
        "state_key",
        "history_key",
        "ply",
        "side",
        "ids",
        "distance",
        "feature_signature",
    }
    if set(metadata) != ids or any(not required <= set(r) for r in metadata.values()):
        raise ValueError("producer input metadata required before fit")
    if any(not r["state_key"] or not r["history_key"] for r in metadata.values()):
        raise ValueError("empty state/history signature")
    orders = {
        "metadata_schema": "quoridor-tensor-row-v2",
        "ids_order": "P1_then_P2",
        "distance_order": "STM_then_opponent_f32",
        "tensor_view_order": "STM_then_opponent",
    }
    if any(
        any(r.get(k) != value for k, value in orders.items()) for r in metadata.values()
    ):
        raise ValueError("advertised native metadata schema/view orders differ")
    return extra, metadata


def append_train_inputs(original, extra, original_validation, extra_metadata):
    """Keep fixed old validation; mask exposed new train rows, retain counts."""
    binding, rows, x, d, y = original
    extra_binding, extra_rows, ex, ed, ey = extra
    if any(r["split"] != "train" for r in extra_rows):
        raise ValueError("extra corpus must be train-only; evaluation is sealed")
    if {r["id"] for r in rows} & {r["id"] for r in extra_rows}:
        raise ValueError("duplicate original/extra row")
    if {r["group"] for r in rows} & {r["group"] for r in extra_rows}:
        raise ValueError("family overlap original/extra")
    if any(
        r["primary_eligible"] and not np.isfinite(ey[i, 0])
        for i, r in enumerate(extra_rows)
    ):
        raise ValueError("eligible extra rootmean missing")
    if set(extra_metadata) != {r["id"] for r in extra_rows}:
        raise ValueError("extra label-free metadata coverage")
    validation_ids = {r["id"] for r in rows if r["split"] == "validation"}
    if {r["id"] for r in original_validation} != validation_ids:
        raise ValueError("original validation metadata coverage")
    state_keys = {r["state_key"] for r in original_validation}
    history_keys = {r["history_key"] for r in original_validation}
    input_keys = {
        model_input_key(x[i], d[i, :2])
        for i, r in enumerate(rows)
        if r["split"] == "validation"
    }
    masked, family_counts = [], {}
    matches = {"state": 0, "history_string": 0, "actual_input": 0, "OR": 0}
    for i, row in enumerate(extra_rows):
        meta = extra_metadata[row["id"]]
        if meta["split"] != "train" or meta["group"] != row["group"]:
            raise ValueError("extra metadata split/family")
        if "ids" in meta or "side" in meta or "distance" in meta:
            if meta.get("side") not in (1, 2) or len(meta.get("ids", [])) != 2:
                raise ValueError("new metadata P1P2 views/side")
            mapped = np.zeros((2, 312), dtype=np.float32)
            for v, ids in enumerate(meta["ids"]):
                if (
                    not ids
                    or ids != sorted(set(ids))
                    or min(ids) < 0
                    or max(ids) >= 312
                ):
                    raise ValueError("new metadata sparse IDs")
                mapped[v, ids] = 1
            side = meta["side"] - 1
            if model_input_key(
                mapped[[side, 1 - side]], np.asarray(meta["distance"], dtype=np.float32)
            ) != model_input_key(ex[i], ed[i]):
                raise ValueError("new metadata/cache actual STM input differs")
        hits = {
            "state": meta["state_key"] in state_keys,
            "history_string": meta["history_key"] in history_keys,
            "actual_input": model_input_key(ex[i], ed[i]) in input_keys,
        }
        exposed = any(hits.values())
        for kind, hit in hits.items():
            matches[kind] += int(hit)
        matches["OR"] += int(exposed)
        row = dict(row)
        row["primary_eligible"] = bool(row["primary_eligible"] and not exposed)
        row["cohort"] = meta.get("cohort", "new-independent-train")
        row["ply"] = meta.get("ply")
        group = family_counts.setdefault(row["group"], {"all": 0, "eligible": 0})
        group["all"] += 1
        group["eligible"] += int(row["primary_eligible"])
        masked.append(row)
    combined = dict(binding)
    combined["extra_train_binding"] = extra_binding
    combined["extra_exposure_mask"] = {
        "rule": "state OR history OR actual STM-f32 QF1 input; new train excluded, old val fixed",
        "groups": family_counts,
        "planned_rows": len(masked),
        "eligible_rows": sum(r["primary_eligible"] for r in masked),
        "zeroeligible_groups": sum(g["eligible"] == 0 for g in family_counts.values()),
        "rows": {r["id"]: r["primary_eligible"] for r in masked},
        "labels_used_for_mask": False,
        "matches_by_rule": matches,
        "history_cross_format_coverage": "UNVERIFIED; literal equality only, no full-history nonexposure guarantee",
    }
    combined["dataset_sha"] = hashlib.sha256(
        json.dumps(
            [
                binding["dataset_sha"],
                extra_binding["dataset_sha"],
                combined["extra_exposure_mask"],
            ],
            sort_keys=True,
        ).encode()
    ).hexdigest()
    extra_dense = np.column_stack([ed, np.zeros((len(masked), 4), dtype=np.float32)])
    return (
        combined,
        rows + masked,
        np.concatenate([x, ex]),
        np.concatenate([d, extra_dense]),
        np.concatenate([y, ey]),
    )


def load_route_cache(path):
    path = Path(path)
    binding = json.loads((path / "cache.json").read_text())
    if binding["schema"] != "quoridor-qf1-route-cache-v1" or binding["allow_test"]:
        raise ValueError("route cache version/test policy")
    source = binding["sources"]
    for name in ["train", "validation", "labels", "mask"]:
        item = source[name]
        if sha(item["path"]) != item["sha256"]:
            raise ValueError("source binding changed: " + name)
    if sha(path / "routes.f32") != binding["routes_sha256"]:
        raise ValueError("route input SHA changed")
    mask = json.loads(Path(source["mask"]["path"]).read_text())
    labels = {}
    with gzip.open(source["labels"]["path"], "rt") as stream:
        for line in stream:
            row = json.loads(line)
            if row["split"] not in ("train", "validation") or row["id"] in labels:
                raise ValueError("training label split/duplicate")
            labels[row["id"]] = row
    n = binding["rows"]
    x = np.zeros((n, 2, 312), dtype=np.float32)
    d = np.empty((n, 6), dtype=np.float32)
    y = np.empty((n, 2), dtype=np.float32)
    routes = np.memmap(path / "routes.f32", dtype="<f4", mode="r", shape=(n, 4))
    rows = []
    digest = hashlib.sha256()
    seen = set()
    groups = {"train": set(), "validation": set()}
    for split in ("train", "validation"):
        with gzip.open(source[split]["path"], "rt") as stream:
            for line in stream:
                r = json.loads(line)
                if r["split"] != split or r["id"] in seen or r["side"] not in (1, 2):
                    raise ValueError("canonical split/id/side")
                seen.add(r["id"])
                index = len(rows)
                if index >= n:
                    raise ValueError("cache row count")
                digest.update((r["id"] + "\n").encode())
                mark = mask["rows"][r["id"]]
                if mark["split"] != split or mark["group"] != r["group"]:
                    raise ValueError("registered mask identity")
                if r["id"] not in labels or labels[r["id"]]["split"] != split:
                    raise ValueError("missing/mismatched training label")
                label = labels[r["id"]]
                for v, view in enumerate((r["side"] - 1, 2 - r["side"])):
                    ids = r["ids"][view]
                    if (
                        not ids
                        or ids != sorted(set(ids))
                        or min(ids) < 0
                        or max(ids) >= 312
                    ):
                        raise ValueError("QF1 sparse input")
                    x[index, v, ids] = 1
                d[index, :2] = r["distance"]
                d[index, 2:] = routes[index]
                y[index] = [
                    label["rootmean"],
                    np.nan if label["z"] is None else label["z"],
                ]
                rows.append(
                    {
                        "id": r["id"],
                        "group": r["group"],
                        "game": r["game_id"],
                        "split": split,
                        "primary_eligible": bool(mark["primary_eligible"]),
                        "teacher_type": "mcts",
                        "rootmean": label["rootmean"],
                        "z": label["z"],
                        "cohort": r["cohort"],
                        "ply": r["ply"],
                    }
                )
                groups[split].add(r["group"])
    if (
        len(rows) != n
        or seen != set(labels)
        or digest.hexdigest() != binding["row_order_sha256"]
    ):
        raise ValueError("cache/source row identity")
    if groups["train"] & groups["validation"]:
        raise ValueError("family leakage")
    if not np.isfinite(d).all() or not np.isfinite(y[:, 0]).all():
        raise ValueError("nonfinite route/target")
    return binding, rows, x, d, y


def detailed_metrics(rows, prediction, target, constant):
    out = metrics(rows, prediction, target, constant)
    groups = {}
    phases = {}
    for r, p in zip(rows, prediction):
        g = groups.setdefault(
            r["group"],
            {
                "rows": 0,
                "rootmean_sse": 0.0,
                "rootmean_rows": 0,
                "z_sse": 0.0,
                "z_rows": 0,
                "sign_correct": 0,
                "sign_rows": 0,
                "saturated": 0,
            },
        )
        g["rows"] += 1
        if r["rootmean"] is not None:
            g["rootmean_sse"] += (float(p) - r["rootmean"]) ** 2
            g["rootmean_rows"] += 1
        if r["z"] is not None:
            g["z_sse"] += (float(p) - r["z"]) ** 2
            g["z_rows"] += 1
            if r["z"] != 0:
                g["sign_rows"] += 1
                g["sign_correct"] += float(p) * r["z"] > 0
        g["saturated"] += abs(float(p)) >= 0.9
        ply = r.get("ply")
        phase = (
            "NOT_RECORDED"
            if ply is None
            else ("opening" if ply < 20 else ("middle" if ply < 60 else "late"))
        )
        a = phases.setdefault(
            phase, {"rows": 0, "rootmean_rows": 0, "rootmean_sse": 0.0}
        )
        a["rows"] += 1
        if r["rootmean"] is not None:
            a["rootmean_rows"] += 1
            a["rootmean_sse"] += (float(p) - r["rootmean"]) ** 2
    cohorts = {}
    for i, r in enumerate(rows):
        cohorts.setdefault(r.get("cohort", "NOT_RECORDED"), []).append(i)
    out["groups"] = groups
    out["phase"] = phases
    out["cohorts"] = {
        name: metrics([rows[i] for i in indices], prediction[indices], target, constant)
        for name, indices in cohorts.items()
    }
    return out


def export_residual(
    model, config, statistics, _distance_fit, path, *, route_mode, route_statistics
):
    """Maintained native v3 export for an explicitly bound route feature view."""
    from .residual_model import FEATURE_VERSION, ROUTE_VERSION

    if route_mode not in ("zero4", "enabled"):
        raise ValueError("explicit route mode required")
    manifest_path = export(model, config, statistics, {"a": 0.0, "b": 8.0}, path)
    manifest = json.loads(manifest_path.read_text())
    # The native v3 loader rejects unknown fields. Training provenance belongs
    # beside the inference manifest, without changing its math or weight bytes.
    training_metadata = {
        name: manifest.pop(name) for name in ("training_target", "target_semantics")
    }
    write(manifest_path.parent / "training-target.json", training_metadata)
    for name in ("transformer_width", "hidden_width", "source_kind"):
        manifest.pop(name, None)
    manifest.update(
        {
            "schema": "quoridor-nnue-distance-residual-v3",
            "feature": FEATURE_VERSION,
            "value_perspective": "side-to-move",
            "value_parameterization": "fixed-distance-logit-plus-linear-residual-tanh",
            "dense_feature_version": ROUTE_VERSION,
            "route_mode": route_mode,
            "route_mu_f32": route_statistics["mu_f32"],
            "route_sigma_f32": route_statistics["sigma_f32"],
            "topology": {
                "ft_width": config["model"]["transformer_width"],
                "hidden_width": config["model"]["hidden_width"],
            },
        }
    )
    write(manifest_path, manifest)
    return manifest_path


def parity(
    args, build, freeze, receipt_path=None, checkpoints=("initial", "best", "last")
):
    """24 preselected rows, initial/BEST/LAST; explicit additional sample charge."""
    import subprocess
    import torch

    binding, rows, x, d, _ = load_route_cache(args.cache)
    chosen = [i for i, r in enumerate(rows) if r["split"] == "train"][:12] + [
        i for i, r in enumerate(rows) if r["split"] == "validation"
    ][:12]
    if len(chosen) != 24:
        raise ValueError("parity fixed witness count")
    ids = {rows[i]["id"] for i in chosen}
    canonical = []
    for split in ("train", "validation"):
        with gzip.open(binding["sources"][split]["path"], "rt") as stream:
            for line in stream:
                r = json.loads(line)
                if r["id"] in ids:
                    canonical.append(r)
    if [r["id"] for r in canonical] != [rows[i]["id"] for i in chosen]:
        raise ValueError("parity order")
    if getattr(args, "extra_train_cache", None):
        extra, metadata = extra_train_inputs(args)
        _, extra_rows, ex, ed, _ = extra
        extra_chosen = []
        for side in (1, 2):
            candidates = [
                i
                for i, row in enumerate(extra_rows)
                if metadata[row["id"]]["side"] == side
            ][:6]
            if len(candidates) != 6:
                raise ValueError("new train parity needs six fixed witnesses per side")
            extra_chosen.extend(candidates)
        # The readonly native diagnostic accepts at most24 rows:12old+12new.
        old_take = chosen[:6] + chosen[12:18]
        old_canonical = canonical[:6] + canonical[12:18]
        new_canonical = [metadata[extra_rows[i]["id"]] for i in extra_chosen]
        for i, row in zip(extra_chosen, new_canonical):
            p = row["side"] - 1
            check_x = np.zeros((2, 312), dtype=np.float32)
            check_x[0, row["ids"][p]] = 1
            check_x[1, row["ids"][1 - p]] = 1
            if model_input_key(ex[i], ed[i]) != model_input_key(
                check_x, np.asarray(row["distance"], dtype=np.float32)
            ):
                raise ValueError("new native cache/canonical STM mapping")
        x = np.concatenate([x[old_take], ex[extra_chosen]])
        d = np.concatenate(
            [
                d[old_take],
                np.column_stack(
                    [ed[extra_chosen], np.zeros((12, 4), dtype=np.float32)]
                ),
            ]
        )
        chosen = list(range(24))
        canonical = old_canonical + new_canonical
    source = "".join(json.dumps(r, separators=(",", ":")) + "\n" for r in canonical)
    cfg = json.loads((Path(args.output) / "config.json").read_text())
    stats = json.loads((Path(args.output) / "scale.json").read_text())
    model = build(cfg["model"], stats)
    reports = []
    for name in checkpoints:
        cp = torch.load(
            Path(args.output) / (name + ".pt"), map_location="cpu", weights_only=True
        )
        model.load_state_dict(cp["model"])
        model.eval()
        with torch.inference_mode():
            pred = model(
                torch.from_numpy(x[chosen]),
                torch.from_numpy(d[chosen]),
                torch.ones(24, dtype=torch.long),
            ).numpy()
        run = subprocess.run(
            [
                args.native_binary,
                "model",
                str(Path(args.output) / (name + "-model") / "manifest.json"),
            ],
            input=source,
            text=True,
            capture_output=True,
            timeout=30,
            check=False,
        )
        if run.returncode:
            raise RuntimeError("native parity child failed: " + run.stderr[:1000])
        native = [json.loads(line) for line in run.stdout.splitlines()]
        if len(native) != 24 or [r["id"] for r in native] != [
            r["id"] for r in canonical
        ]:
            raise ValueError("native parity rows")
        error = [abs(float(p) - r["value"]) for p, r in zip(pred, native)]
        if any(e > 1e-6 + 1e-6 * abs(float(p)) for e, p in zip(error, pred)):
            raise ValueError("Torch/native numeric parity")
        if name == "initial":
            reference = torch.tanh(
                torch.from_numpy(np.float32(8) * (d[chosen, 1] - d[chosen, 0]))
            ).numpy()
            if not np.array_equal(pred, reference):
                raise ValueError("initial D bit parity")
        reports.append(
            {
                "checkpoint": name,
                "weights_sha": sha(
                    Path(args.output) / (name + "-model") / "weights.f32"
                ),
                "max_abs": max(error),
                "rows": native,
                "torch_prediction": pred.tolist(),
            }
        )
    write(
        receipt_path or Path(args.output) / "parity.json",
        {
            "status": "PASS",
            "task": getattr(args, "task", "frame21-route-control-268-v1"),
            "schema": "route-control-parity-v1",
            "witness_ids": [r["id"] for r in canonical],
            "reports": reports,
            "additional_Torch_samples": 24 * len(checkpoints),
            "nativeNN_samples": 48 * len(checkpoints),
            "learning_samples": freeze["samples"],
            "all_NN_samples": freeze["samples"] + 72 * len(checkpoints),
        },
    )


def main(
    *,
    objective=None,
    checkpoint_steps=(),
    evaluation_observer=None,
    measure=detailed_metrics,
    parity_checkpoints=("initial", "best", "last"),
):
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--routes", choices=["zero4", "enabled"], required=True)
    parser.add_argument("--native-binary", required=True)
    parser.add_argument("--repair-existing-A")
    parser.add_argument("--extra-train-cache")
    parser.add_argument("--extra-train-metadata")
    parser.add_argument("--extra-train-groups")
    parser.add_argument("--fixed-scale")
    parser.add_argument("--evaluation-points")
    parser.add_argument("--task", default="frame21-route-control-268-v1")
    args = parser.parse_args()
    from functools import partial
    from .residual_model import DistanceResidualModel

    enabled = args.routes == "enabled"
    route_statistics = json.loads((Path(args.cache) / "cache.json").read_text())[
        "route_statistics"
    ]

    def build(config, statistics):
        return DistanceResidualModel(
            config,
            statistics,
            a=0.0,
            b=8.0,
            routes=enabled,
            route_statistics=route_statistics,
        )

    def load_inputs(cache):
        binding, rows, x, d, y = load_route_cache(cache)
        if not args.extra_train_cache:
            return binding, rows, x, d, y
        if enabled:
            raise ValueError("extra native cache supports explicit zero4 only")
        if not args.extra_train_metadata:
            raise ValueError("label-free extra metadata required before fit")
        extra, metadata = extra_train_inputs(args)
        with gzip.open(binding["sources"]["validation"]["path"], "rt") as stream:
            validation = [json.loads(line) for line in stream]
        return append_train_inputs(
            (binding, rows, x, d, y),
            extra,
            validation,
            metadata,
        )

    freeze = train(
        args.cache,
        args.output,
        args.config,
        model_builder=build,
        cache_loader=load_inputs,
        model_export=partial(
            export_residual, route_mode=args.routes, route_statistics=route_statistics
        ),
        export_onnx=False,
        evaluation_points=(
            json.loads(Path(args.evaluation_points).read_text())
            if args.evaluation_points
            else [0, 1, 2, 5, 10, 20, 50, 100, 200, 400]
        ),
        measure=measure,
        objective=objective,
        checkpoint_steps=checkpoint_steps,
        evaluation_observer=evaluation_observer,
        distance_fit_override={"a": 0.0, "b": 8.0},
        statistics_override=(
            json.loads(Path(args.fixed_scale).read_text()) if args.fixed_scale else None
        ),
    )
    parity(args, build, freeze, checkpoints=parity_checkpoints)
    if args.repair_existing_A:
        if not enabled:
            raise ValueError("existing A repair is only in the B family")
        import copy

        old = copy.copy(args)
        old.output = args.repair_existing_A
        old.routes = "zero4"
        old_freeze = json.loads((Path(old.output) / "freeze.json").read_text())

        def build_A(config, statistics):
            return DistanceResidualModel(
                config,
                statistics,
                a=0.0,
                b=8.0,
                routes=False,
                route_statistics=route_statistics,
            )

        parity(old, build_A, old_freeze, Path(args.output) / "parity-existing-A.json")


if __name__ == "__main__":
    main()
