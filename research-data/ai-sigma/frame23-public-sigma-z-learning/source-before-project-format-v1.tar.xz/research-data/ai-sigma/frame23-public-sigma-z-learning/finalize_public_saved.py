"""Freeze one candidate from saved scalars only; no framework or new forward."""

import argparse
from array import array
from collections import defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for body in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(body)
    return digest.hexdigest()


def read_json(path):
    path = Path(path)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt") as stream:
        return json.load(stream)


def member(path):
    return {"path": str(path), "SHA": sha(path), "B": Path(path).stat().st_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration")
    args = parser.parse_args()
    reg = read_json(args.registration)
    if reg["task"] != "public-z-final-saved-freeze":
        raise ValueError("saved scalar freeze purpose mismatch")
    for path, digest in reg["input_SHA"].items():
        if sha(path) != digest:
            raise ValueError("saved scientific source/input changed: " + path)
    output = Path(reg["output"])
    output.mkdir(exist_ok=False)
    source = [Path(p) for p in reg["fit_outputs"]]
    curves = [read_json(p / "curves.json") for p in source]
    freezes = [read_json(p / "freeze.json") for p in source]
    data = [read_json(p / "data.json") for p in source]
    if data[0] != data[1]:
        raise ValueError("same-corpus/data/constant/scale binding differs")
    orders = [
        read_json(
            p / ("validation-order.json.gz" if i == 0 else "validation-order.json")
        )
        for i, p in enumerate(source)
    ]
    if orders[0] != orders[1] or len(orders[0]) != 19846:
        raise ValueError("same complete selection order differs")
    processed = sum(map(len, orders))
    metadata = {}
    with Path(reg["selection_metadata"]).open() as stream:
        for line in stream:
            row = json.loads(line)
            processed += 1
            if row["split"] != "validation" or row["rootmean"] is not None:
                raise ValueError("selection-only external outcome expected")
            metadata[row["id"]] = row
    selected = [metadata[i] for i in orders[0]]
    if any(r["z"] not in (-1, 1) or not r["primary_eligible"] for r in selected):
        raise ValueError("decisive primary denominator differs")
    targets = [r["z"] for r in selected]
    groups = defaultdict(list)
    for i, row in enumerate(selected):
        groups[row["group"]].append(i)
    processed += len(selected)
    constant = data[0]["constant"]
    points = []
    prefixes = []
    saved_arrays = {}
    for condition, (directory, curve) in enumerate(zip(source, curves)):
        for item in curve:
            step = item["step"]
            file = directory / f"validation-step{step}.f32"
            prediction = array("f")
            prediction.frombytes(file.read_bytes())
            if sys.byteorder != "little":
                prediction.byteswap()
            if len(prediction) != len(targets) or any(
                not math.isfinite(p) for p in prediction
            ):
                raise ValueError("saved scalar shape/finite mismatch")
            processed += len(prediction)
            mse = math.fsum((p - z) ** 2 for p, z in zip(prediction, targets)) / len(
                targets
            )
            if abs(mse - item["validation"]["target_mse"]) > 1e-12:
                raise ValueError("saved scalar MSE does not match the scientific curve")
            grouped = []
            for key, indices in groups.items():
                ymean = math.fsum(targets[i] for i in indices) / len(indices)
                grouped.append(
                    {
                        "input_group": key,
                        "rows": len(indices),
                        "mse": math.fsum(
                            (prediction[i] - targets[i]) ** 2 for i in indices
                        )
                        / len(indices),
                        "z_mean": ymean,
                        "empirical_label_variance": 1 - ymean**2,
                    }
                )
            points.append(
                {
                    "condition": condition,
                    "step": step,
                    "seen": item["training_seen"],
                    "row_epoch": item["row_epoch"],
                    "train_mse": item["train"]["target_mse"],
                    "selection_mse": mse,
                    "constant_mse": item["validation"]["constant_mse"],
                    "sign_accuracy": item["validation"]["z_sign_accuracy"],
                    "saturation": item["validation"]["saturation_fraction"],
                    "source_input_group_equal_mse_secondary": math.fsum(
                        g["mse"] for g in grouped
                    )
                    / len(grouped),
                    "input_groups": grouped,
                    "scalar": member(file),
                }
            )
            saved_arrays[(condition, step)] = prediction
            if condition == 1 and str(step) in freezes[0]["batch_prefix_sha256"]:
                p0 = source[0] / f"validation-step{step}.f32"
                if (
                    p0.read_bytes() != file.read_bytes()
                    or freezes[0]["batch_prefix_sha256"][str(step)]
                    != freezes[1]["batch_prefix_sha256"][str(step)]
                ):
                    raise ValueError("common batch/scalar prefix differs")
                processed += 2 * len(targets)
                prefixes.append(
                    {
                        "step": step,
                        "scalar_bytes_equal": True,
                        "batch_prefix_SHA_equal": True,
                    }
                )
    # All visible points were fixed before results. Preserve the original
    # operational cycle/row metric, rather than selecting on a new group weight.
    best = min(
        points,
        key=lambda p: (
            p["selection_mse"],
            (1000064, 2000000)[p["condition"]],
            p["step"],
        ),
    )
    if (best["condition"], best["step"]) != (0, 7813):
        raise ValueError("registered minimum/tie fewer-work candidate differs")
    references = {}
    for kind in ("Tseen", "Vraw"):
        streams = []
        for directory in source:
            file = directory / f"{kind}-references.jsonl.gz"
            digest, count = hashlib.sha256(), 0
            ids, signatures, producer_groups = set(), set(), set()
            with gzip.open(file, "rb") as stream:
                for body in stream:
                    digest.update(body)
                    row = json.loads(body)
                    ids.add(row["id"])
                    signatures.add(row["input_signature"])
                    producer_groups.add(row["producer_group"])
                    count += 1
            processed += count
            streams.append(
                member(file)
                | {
                    "uncompressed_SHA": digest.hexdigest(),
                    "rows": count,
                    "unique_ids": len(ids),
                    "unique_inputs": len(signatures),
                    "source_input_groups": len(producer_groups),
                }
            )
        if streams[0]["uncompressed_SHA"] != streams[1]["uncompressed_SHA"]:
            raise ValueError("actual all-stage seen/input-reference union differs")
        references[kind] = {
            "canonical": streams[0],
            "same_stream_second_condition": streams[1],
            "union_is_canonical": True,
        }
    if (
        references["Tseen"]["canonical"]["rows"],
        references["Vraw"]["canonical"]["rows"],
    ) != (67937, 19965):
        raise ValueError("final exposure denominators differ")
    candidate_manifest = Path(reg["candidate_manifest"])
    manifest = read_json(candidate_manifest)
    weights = candidate_manifest.parent / manifest["weights"]
    if (
        sha(weights) != freezes[0]["weights_sha"]
        or sha(weights) != freezes[1]["weights_sha"]
    ):
        raise ValueError("candidate native weights differ from both saved BEST tensors")
    if {"training_target", "target_semantics"} & set(manifest):
        raise ValueError("v3 native manifest has unexpected training fields")
    if processed > reg["processed_upper"]:
        raise ValueError("saved analysis processed cap exceeded")
    freeze = {
        "schema": "public-sigma-z-candidate-freeze-v1",
        "UTC": datetime.now(timezone.utc).isoformat(),
        "selection_rule": "minimum registered cycle/row-weighted decisive-z selection MSE; equal weights/value favors fewer full-run seen samples; then earliest step",
        "candidate": {
            "condition": "public-z-1m",
            "step": 7813,
            "training_seen": 1000064,
            "selection_mse": best["selection_mse"],
            "checkpoint": member(source[0] / "step7813.pt"),
            "native_manifest": member(candidate_manifest),
            "native_weights": member(weights),
            "target_metadata": member(
                candidate_manifest.parent / "training-target.json"
            ),
            "weights_tensor_SHA": manifest["weights_SHA"],
            "config": member(Path(reg["candidate_config"])),
        },
        "baselines": {
            "initial_equals_D": True,
            "initial_weights_SHA": freezes[0]["initial_weights_sha"],
            "D": {
                "a_f32": 0.0,
                "b_f32": 8.0,
                "formula": "tanh(f32(8*f32(raw_d_opponent-raw_d_self))); native tanh f64 result cast f32",
                "selection_mse": points[0]["selection_mse"],
            },
            "constant": {
                "value": constant,
                "fitted_on_train_only": True,
                "selection_mse": points[0]["constant_mse"],
            },
        },
        "model_settings": {
            "feature": manifest["feature"],
            "schema": manifest["schema"],
            "value_perspective": "canonical STM; absolute source side unavailable",
            "route4": "off",
            "scale": member(Path(reg["fixed_scale"]["path"])),
            "native_binary": member(Path(reg["native_binary"])),
            "native_source": member(Path(reg["native_source"])),
            "unique_NN_candidate": 1,
            "D_initial_prediction_reuse": True,
        },
        "references": references,
        "source_public_references": reg["source_public_references"],
        "future_exposure": "actual QF1 STM IDs+rawdistance f32 input against Tactual union ALLrawV (including source z0); history/fullgame/absolute-side unavailable, not a guarantee of history nonexposure",
        "signature_source": member(Path(reg["signature_source"])),
        "reference_serialization": "input_key: QF1-f32-STM-v1\\0 + <HH byte lengths of the two sorted <u2 ID streams> + ID streams + <ff raw STM distances>; SHA256",
        "future_protocol": "original sealed0043 subset and producer input qualification unchanged; separate critic one opening after this freeze plus final input-only mask; decisive recorded +/-1 primary; zero reason unavailable excluded and counts retained; no candidate reselection",
        "future_labels_opened": False,
        "selection_input_groups": len(groups),
        "independent_games": "UNAVAILABLE",
        "selection_stage": "reused selection; not independent test or samewall strength",
        "science_stops": [member(Path(p)) for p in reg["science_stops"]],
        "parity": [member(Path(p)) for p in reg["parity_outputs"]],
        "first_entry": "original failure retained; saved weights parity separately passed; no repeated fit",
        "source_SHA": {
            p: digest for p, digest in reg["input_SHA"].items() if p.endswith(".py")
        },
    }
    summary = {
        "points": points,
        "common_prefix": prefixes,
        "empirical_selection_input_group_variance_floor": math.fsum(
            len(indices)
            * (1 - (math.fsum(targets[i] for i in indices) / len(indices)) ** 2)
            for indices in groups.values()
        )
        / len(targets),
        "variance_floor_status": "label-derived in-sample lower bound for deterministic input-group prediction only; not a trained baseline, Bayes truth, independent estimate or selection criterion",
        "strength": "NOT_ESTABLISHED",
    }
    for name, value in (
        ("candidate-freeze-v1.json", freeze),
        ("saved-curve-summary-v1.json", summary),
    ):
        (output / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    result = {
        "task": reg["expected_task"],
        "schema": "public-z-learning-v1",
        "status": "PASS",
        "total_NN": 0,
        "processed": processed,
        "candidate_freeze": member(output / "candidate-freeze-v1.json"),
        "future_labels_opened": False,
        "new_fit_or_forward": False,
    }
    (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
