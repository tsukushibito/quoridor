"""Apply the exact one-import typing repair to current canonical ETC source."""

import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def main():
    loader = importlib.util.spec_from_file_location(
        "refs", OUT.parent / "adoption-v1/adopt.py"
    )
    refs = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(refs)
    loader = importlib.util.spec_from_file_location(
        "current_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    packet = (
        ROOT
        / ".worktree/search-optimization/.artifacts/cedar-etc-v1/ai3-fixture-source-v1/binding.json"
    )
    assert (
        refs.ref(packet)["sha256"]
        == "c6e941db633e7906445105c717417bbd1e3d51599bce64111e7e5a21c1e76e75"
    )
    binding = json.loads(packet.read_bytes())
    path = ROOT / "crates/quoridor-ai/src/etc_tests.rs"
    with lc.lease():
        before = refs.ref(path)
        assert before["sha256"] == binding["before"]["sha256"]
        old = path.read_text()
        post = lc.read_ref(binding["post"]).decode()
        selector = "fn etc31_actual_ordered_lookahead_cuts_beyond_first_without_head_or_history_training() {"
        assert old.split(selector)[0] == post.split(selector)[0]
        tail = "    let calls = Arc::new(AtomicUsize::new(0));"
        assert (
            old.split(selector)[1].split(tail)[1]
            == post.split(selector)[1].split(tail)[1]
        )
        forward = binding["patches"]["forward.patch"]
        lc.read_ref(forward)
        subprocess.run(
            ["git", "apply", "--check", forward["path"]], cwd=ROOT, check=True
        )
        subprocess.run(["git", "apply", forward["path"]], cwd=ROOT, check=True)
        after = refs.ref(path)
        assert all(after[k] == binding["post"][k] for k in ("sha256", "bytes", "mode"))
        (OUT / "adoption.json").write_text(
            json.dumps(
                dict(
                    status="EXACT_CAUSAL_AI3_FIXTURE_ROOT_ONLY_ADOPTED_UNRUN",
                    packet=refs.ref(packet),
                    before=before,
                    after=after,
                    preserved_original_failure=binding["actual_failure"],
                    source_leases=[],
                    native_Search_RNG=0,
                    AI1_AI2_helpers_and_all_AI3_assertions_unchanged=True,
                ),
                indent=2,
            )
            + "\n"
        )
    print(json.dumps(after))


if __name__ == "__main__":
    main()
