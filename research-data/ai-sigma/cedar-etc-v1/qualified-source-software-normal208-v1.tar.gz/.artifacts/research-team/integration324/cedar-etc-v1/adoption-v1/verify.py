"""Format only sequence and run the two new Python owner boundaries once."""

import ast
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from quoridor_training.cycle_process import execute

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def main():
    loader = importlib.util.spec_from_file_location("adopt_refs", OUT / "adopt.py")
    helper = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(helper)
    loader = importlib.util.spec_from_file_location(
        "lc_verify", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    path = ROOT / "scripts/dev/research-lifecycle.py"
    with lc.lease():
        text = path.read_text()
        lines = text.splitlines(keepends=True)
        node = next(
            n
            for n in ast.parse(text).body
            if isinstance(n, ast.FunctionDef) and n.name == "sequence"
        )
        fragment = "".join(lines[node.lineno - 1 : node.end_lineno])
        result = subprocess.run(
            [
                "ruff",
                "format",
                "--line-length",
                "100",
                "--stdin-filename",
                str(path),
                "-",
            ],
            input=fragment,
            text=True,
            capture_output=True,
            check=True,
        )
        assert ast.dump(ast.parse(fragment)) == ast.dump(ast.parse(result.stdout))
        path.write_text(
            "".join(lines[: node.lineno - 1])
            + result.stdout
            + "".join(lines[node.end_lineno :])
        )
        (OUT / "controller-sequence-before.py").write_text(fragment)
        (OUT / "controller-sequence-after.py").write_text(result.stdout)
    selectors = [
        "test_research_lifecycle_etc.EtcMetadataBoundary.test_etc31_typed_mixed_custody_and_namespace_correspondence",
        "test_research_lifecycle_cohort_affinity.CohortControllerAffinity.test_sequence_keeps_declared_management_pool_through_inner_and_finalization",
    ]
    receipt = execute(
        [sys.executable, "-B", "-m", "unittest", "-v", *selectors],
        OUT / "Python2.log",
        time.monotonic() + 120,
        cpu_cores=[16],
        cwd=str(ROOT / "scripts/dev"),
        env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
    )
    (OUT / "Python2-result.json").write_text(json.dumps(receipt, indent=2) + "\n")
    assert receipt["exit_code"] == 0 and receipt["cleanup_complete"]
    for name in (
        "scripts/dev/research-lifecycle.py",
        "scripts/dev/test_research_lifecycle_etc.py",
        "scripts/dev/test_research_lifecycle_cohort_affinity.py",
    ):
        print(json.dumps(helper.ref(ROOT / name)))


if __name__ == "__main__":
    main()
