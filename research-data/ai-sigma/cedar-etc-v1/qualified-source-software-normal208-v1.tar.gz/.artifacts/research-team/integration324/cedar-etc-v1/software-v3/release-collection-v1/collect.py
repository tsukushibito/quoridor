"""Collect actual new ETC software and finalize its genuine image once."""

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    loader = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


def main():
    helper = load(
        "metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py",
    )
    lc = load("current", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helper.ref
    runtime = BASE / "build-runtime-v1"
    outer_path = runtime / "result.json"
    outer = json.loads(outer_path.read_bytes())
    state = json.loads((runtime / "state.json").read_bytes())
    submitted = json.loads((BASE / "original-release-submit-v1.json").read_bytes())
    assert outer["job_id"] == json.loads(submitted["stdout"])["job_id"]
    assert outer["outcome"] == "succeeded" and outer["exit_code"] == 0
    assert (
        outer["cleanup_complete"]
        and outer["direct_child_reaped"]
        and outer["remaining"] == []
    )
    operation = BASE / "operation-release"
    candidate_path = operation / "candidate.json"
    candidate_ref = ref(candidate_path)
    candidate = json.loads(candidate_path.read_bytes())
    assert candidate["status"] == "PENDING_FINALIZATION"
    assert candidate["cleanup_complete"] and candidate["process_cleanup_complete"]
    assert candidate["remaining"] == candidate["owed_finalizers"] == []
    intent = json.loads(helper.checked(candidate["intent"]).read_bytes())
    known = []
    test_rows = []
    lint_rows = []
    build_rows = []
    for row in candidate["checks"]:
        assert row["status"] == "PASS" and row["capture_complete"]
        assert row["primary"] is None and row["secondary"] == []
        record = row["guardian_return"]
        lc.settled(record)
        assert record["handle_closes_complete"]
        member = record["child"]
        fresh = lc.process.identity(lc.process.process_info(member["pid"]))
        assert fresh != lc.process.identity(member)
        known.append(dict(original=member, fresh=fresh))
        log = helper.checked(row["full_log"]).read_bytes()
        if row["role"] == "test":
            selector = row["argv"][row["argv"].index("--lib") + 1]
            text = log.decode()
            assert "running 1 test" in text
            assert f"test {selector} ... ok" in text
            assert "test result: ok. 1 passed; 0 failed" in text
            assert lc.cargo_report(log)["warning_count"] == 0
            test_rows.append(
                dict(
                    selector=selector,
                    log=row["full_log"],
                    process=row["persisted_process_receipt"],
                )
            )
        elif row["role"] == "lint":
            assert lc.cargo_report(log)["warning_count"] == 0
            lint_rows.append(row["full_log"])
        elif row["role"] == "build":
            build_rows.append(row)
    assert len(test_rows) == 3 and len(lint_rows) == 2 and len(build_rows) == 1
    prefix_path = BASE / "accepted-prior-AI1-AI2-prefix.json"
    prefix = json.loads(prefix_path.read_bytes())
    assert len(prefix["checks"]) == 2
    for row in prefix["checks"]:
        assert row["status"] == "PASS"
        lc.settled(row["guardian_return"])
        text = helper.checked(row["full_log"]).read_text()
        assert (
            "running 1 test" in text and "test result: ok. 1 passed; 0 failed" in text
        )
    assert len(test_rows) + len(prefix["checks"]) == 5
    assert build_rows[0]["name"] == "etc-genuine-common-release"
    cargo = lc.cargo_report(Path(build_rows[0]["full_log"]["path"]).read_bytes())
    assert cargo["warning_count"] == 0
    artifacts = [
        a
        for a in cargo["artifacts"]
        if a["target"]["name"] == "quoridor-runner"
        and a["target"]["kind"] == ["bin"]
        and not a["profile"]["test"]
    ]
    assert len(artifacts) == 1 and artifacts[0] == candidate["cargo_artifact"]
    child = state["child"]
    fresh = lc.process.identity(lc.process.process_info(child["pid"]))
    assert fresh != lc.process.identity(child)
    known.append(dict(original=child, fresh=fresh))
    assert not (operation / "manifest.json").exists()
    manifest = lc.finalize(operation, ref(outer_path))
    assert (
        manifest["status"] == "PASS" and manifest["artifact"] == candidate["artifact"]
    )
    assert ref(candidate_path) == candidate_ref
    with lc.lease():
        lc.source_check(intent["source"])
        assert not Path(intent["TMP"]).exists()
        callers = [
            ref(ROOT / p)
            for p in [
                "scripts/dev/research-lifecycle.py",
                "scripts/dev/research-job.py",
                "python/quoridor_training/cycle_process.py",
                "python/quoridor_training/snapshot.py",
            ]
        ]
        affected = helper.allocated_union([Path(p) for p in intent["owned_outputs"]])
    result = dict(
        status="ACTUAL_GENUINE_ETC_SOFTWARE_AND_IMAGE_PASS_NATIVE_UNENTERED_SOURCE_STOP",
        issue="quoridor-4lc.324.31",
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        software_manifest=ref(operation / "manifest.json"),
        artifact=manifest["artifact"],
        cargo_artifact=artifacts[0],
        actual_cached_Cargo_fresh=artifacts[0]["fresh"],
        outer=ref(outer_path),
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        new_tests=test_rows,
        prior_actual_AI1_AI2_reused_without_replay=ref(prefix_path),
        original_AI3_fixture_failure=ref(
            BASE.parent / "software-v2/failure-collection-v1/completion-and-STOP.json"
        ),
        affected_Clippy=lint_rows,
        actual_Python2_reused=ref(BASE.parent / "adoption-v1/Python2-result.json"),
        original_compiler_failure=ref(
            BASE.parent / "software-v1/failure-collection-v1/completion-and-STOP.json"
        ),
        current_callers=callers,
        known_command_fresh_absence=known,
        source_EX_NB_acquired_released=True,
        source_leases=[],
        remaining_owned=[],
        TMP=[],
        affected_point_once=affected,
        retained_target_cache=True,
        no_native_Search_model_RAW_RNG_replay=True,
        globalactual_later_tails_fullfees="UNKNOWN",
        qualification="New AI4/RunnerLIB1 actual1 each, affectedAI/Runner all-target Clippy zero warnings, genuine opt3/codegen1/LTO=false common image. Python2 reused. Not source/runtime/performance/default/science grant; current normal binding/resources/physical admission remain.",
        host_future_quiet=False,
    )
    (OUT / "completion-and-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            dict(
                status=result["status"],
                manifest=result["software_manifest"],
                artifact=result["artifact"],
            )
        )
    )


if __name__ == "__main__":
    main()
