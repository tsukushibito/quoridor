"""Apply the exact one-import typing repair to current canonical ETC source."""

import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def main():
    loader = importlib.util.spec_from_file_location(
        "refs", OUT.parent / "adoption-v1/adopt.py"
    )
    refs = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(refs)
    loader = importlib.util.spec_from_file_location(
        "current_lc", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    packet = (
        ROOT
        / ".worktree/search-optimization/.artifacts/cedar-etc-v1/first-compiler-import-v2/binding.json"
    )
    assert (
        refs.ref(packet)["sha256"]
        == "4e6ed3f5a87c93677cdb442f571a139e9a67eed4199e8731bf4274cffa2e28eb"
    )
    binding = json.loads(packet.read_bytes())
    path = ROOT / "crates/quoridor-ai/src/lazy_smp.rs"
    with lc.lease():
        before = refs.ref(path)
        assert before["sha256"] == binding["before"]["sha256"]
        forward = binding["patches"]["forward.patch"]
        lc.read_ref(forward)
        subprocess.run(
            ["git", "apply", "--check", forward["path"]], cwd=ROOT, check=True
        )
        subprocess.run(["git", "apply", forward["path"]], cwd=ROOT, check=True)
        after = refs.ref(path)
        assert all(after[k] == binding["post"][k] for k in ("sha256", "bytes", "mode"))
        (OUT / "adoption.json").write_text(
            json.dumps(
                dict(
                    status="EXACT_CAUSAL_ETCMODE_IMPORT_ADOPTED_UNTYPED",
                    packet=refs.ref(packet),
                    before=before,
                    after=after,
                    preserved_original_failure=binding["actual_first_failure"],
                    source_leases=[],
                    native_Search_RNG=0,
                    outside_import_bytes_unchanged=True,
                ),
                indent=2,
            )
            + "\n"
        )
    print(json.dumps(after))


if __name__ == "__main__":
    main()
