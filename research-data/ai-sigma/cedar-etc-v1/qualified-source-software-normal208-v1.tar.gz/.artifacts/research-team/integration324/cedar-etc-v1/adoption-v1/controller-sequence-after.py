def sequence(
    settings_ref,
    *,
    job_module=None,
    backend=None,
    prepare=prepare_selected_operation,
    complete=finalize,
):
    """One finite controller; inner execute/directwait/finalize never dispatch a turn."""
    settings = document(settings_ref)
    require(settings["kind"] == "sequence", "selected finite settings")
    require(sys.executable == str(project_python()), "current common-entry interpreter")
    origin = originating_job(settings_ref, settings)
    config = document(origin["config"])
    order = list(operation_order(settings))
    output = owned(settings["output"], settings["owner"])
    require(not output.exists(), "finite controller already entered; no automatic restart")
    if job_module is None:
        loader = importlib.util.spec_from_file_location(
            "sequence_job", ROOT / "scripts/dev/research-job.py"
        )
        job_module = importlib.util.module_from_spec(loader)
        loader.loader.exec_module(job_module)
    if backend is None:
        backend = job_module.runtime.AppBackend(ROOT)
    output.mkdir(parents=True)
    if settings.get("arena_cohort") is not None:
        new_json(output / "lane-origin.json", dict(settings=settings_ref, originating_job=origin))
    initial_affinity = os.sched_getaffinity(0)
    if settings.get("arena_cohort") is not None:
        cohort, _ = arena_cohort(arena_cohort_spec(settings_ref))
        management = set(cohort.get("management_cpu_pool", [cohort["global_controller_cpu"]]))
        require(management <= initial_affinity, "cohort management CPUs outside launch affinity")
        initial_affinity = management
        os.sched_setaffinity(0, initial_affinity)
    active = None
    active_spec = None
    stopped = False
    result = {
        "settings": settings_ref,
        "originating_job": origin,
        "operations": [],
        "primary": None,
        "secondary": [],
    }

    def cancel(signum, frame):
        nonlocal stopped
        stopped = True
        if active is not None:
            job_module.write(active, "cancel.json", {"requested_at": stamp(), "signal": signum})

    def cohort_spec():
        if active_spec is not None:
            return active_spec
        if settings.get("arena_cohort") is None:
            return None
        return arena_cohort_spec(settings_ref)

    def progress():
        nonlocal stopped
        projected = cohort_spec()
        if projected is None:
            return
        try:
            arena_cohort_progress(projected)
        except (KeyboardInterrupt, SystemExit):
            raise
        except BaseException as error:
            result.setdefault("progress_errors", []).append(error_fact(error))
            cancellation = (
                error.subgroup(process.CycleStopped)
                if isinstance(error, BaseExceptionGroup)
                else error
                if isinstance(error, process.CycleStopped)
                else None
            )
            if cancellation is not None and any(
                k in json.dumps(error_fact(cancellation)) for k in ("signal", "pause")
            ):
                stopped = True

    previous = {sig: signal.signal(sig, cancel) for sig in (signal.SIGTERM, signal.SIGINT)}
    cohort_resources = None
    try:
        if settings.get("arena_cohort") is not None:
            cohort_resources = ArenaCohortResources(cohort_spec())
        for kind, index in order:
            if cohort_resources is not None:
                cohort_resources.check(admit=True)
            require(not stopped, "finite controller cancelled; remaining work UNKNOWN")
            job_module.authority(config, ROOT, backend, horizon=config["end_at"])
            read_ref(settings_ref)
            os.sched_setaffinity(0, initial_affinity)
            spec_ref = prepare(settings_ref, kind, index)
            spec = document(spec_ref)
            active_spec = spec
            physical_and_quiet(spec)
            os.sched_setaffinity(0, initial_affinity)
            active = Path(spec_ref["path"]).parent / "runtime"
            active.mkdir()
            child_config = job_module.validate(
                {
                    **config,
                    "cwd": spec["cwd"],
                    "resource_contract": settings_ref["path"],
                    "log_max_bytes": spec["limits"]["log_B"],
                    "argv": [
                        sys.executable,
                        "-B",
                        str(ROOT / "scripts/dev/research-lifecycle.py"),
                        "run",
                        "--intent",
                        spec_ref["path"],
                        "--sha256",
                        spec_ref["sha256"],
                    ],
                },
                active,
            )
            job_module.write(active, "config.json", child_config)
            job_module.write(
                active,
                "state.json",
                {
                    "schema_version": 1,
                    "job_id": str(uuid.uuid4()),
                    "issue": child_config["issue"],
                    "thread_id": child_config["thread_id"],
                    "phase": "queued",
                    "created_at": stamp(),
                    "config_sha256": sha(json.dumps(child_config, sort_keys=True).encode()),
                },
            )
            entry = {
                "kind": kind,
                "index": index,
                "launch_affinity": sorted(os.sched_getaffinity(0)),
            }
            result["operations"].append(entry)
            require(not stopped, "finite controller cancelled before child entry")
            with job_module.lock(active, "process.lock"):
                if cohort_resources is None:
                    returned = job_module.execute(active, child_config, ROOT, backend)
                else:
                    returned = job_module.execute(
                        active, child_config, ROOT, backend, resources=cohort_resources
                    )
            entry["job_result"] = bound(active / "result.json")[0]
            operation = Path(spec["output"])
            if (operation / "INCOMPLETE").exists():
                os.sched_setaffinity(0, initial_affinity)
                completion = complete(operation, entry["job_result"])
                entry["manifest"] = bound(operation / "manifest.json")[0]
                require(
                    completion["status"] == "PASS"
                    and completion["cleanup_complete"] is True
                    and completion["remaining"] == [],
                    "owning operation failed or not cleaned",
                )
            else:
                raise Refused("operation refused before ownership; remaining work UNKNOWN")
            require(
                returned["outcome"] == "succeeded"
                and returned.get("direct_child_reaped") is True
                and returned.get("cleanup_complete") is True
                and returned.get("remaining") == [],
                "original child failed or not cleaned",
            )
            require(not Path(spec["TMP"]).exists(), "owned child TMP remains")
            read_ref(settings_ref)
            entry["completed"] = True
            entry["reader_STOP"] = stamp()
            active = None
            os.sched_setaffinity(0, initial_affinity)
            progress()
        require(not stopped, "finite controller cancelled after terminal collection")
    except BaseException as error:
        result["primary"] = error_fact(error)
    finally:
        for sig, handler in previous.items():
            try:
                signal.signal(sig, handler)
            except BaseException as error:
                result["secondary"].append({"stage": "signal_restore", **error_fact(error)})
        try:
            os.sched_setaffinity(0, initial_affinity)
        except BaseException as error:
            result["secondary"].append({"stage": "affinity_restore", **error_fact(error)})
        child_results = []
        for entry in result["operations"]:
            try:
                child_results.append(document(entry["job_result"]))
            except BaseException as error:
                child_results.append(None)
                result["secondary"].append({"stage": "job_result", **error_fact(error)})
        result.update(
            status="CANCELLED"
            if stopped
            else ("FAILED" if result["primary"] or result["secondary"] else "PASS"),
            completed_operations=sum(x.get("completed") is True for x in result["operations"]),
            selected_operations=len(order),
            reader_STOP=stamp(),
            launch_affinity_restored=sorted(os.sched_getaffinity(0)),
            cleanup_complete=all(
                child is not None and child.get("cleanup_complete") is True
                for child in child_results
            ),
            remaining=None
            if any(child is None or child.get("remaining") is None for child in child_results)
            else [member for child in child_results for member in child["remaining"]],
        )
        new_json(output / "result.json", result)
        previous_errors = len(result.get("progress_errors", []))
        progress()  # Other lanes can now observe a genuine pre-inner terminal refusal.
        if len(result.get("progress_errors", [])) > previous_errors:
            try:
                new_json(
                    output / "terminal-progress-errors.json",
                    dict(
                        result=bound(output / "result.json")[0],
                        errors=result["progress_errors"][previous_errors:],
                    ),
                )
            except BaseException as error:
                print(
                    json.dumps(dict(terminal_notice_publication_error=error_fact(error))),
                    file=sys.stderr,
                )
    if settings.get("arena_cohort") is not None:
        require(not stopped, "cancelled at terminal notification; saved execution result retained")
    require(result["status"] == "PASS", "finite execution stopped; see its original result")
    return result
