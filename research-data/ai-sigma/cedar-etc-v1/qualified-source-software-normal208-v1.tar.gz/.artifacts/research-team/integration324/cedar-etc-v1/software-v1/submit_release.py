"""Submit the genuinely unfinished cleaned baseline release through the normal job owner."""

import datetime
import json
import os
from pathlib import Path
import subprocess

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
draft = json.loads((OUT / "job-release.json").read_bytes())
now = datetime.datetime.now(datetime.timezone.utc)
draft["end_at"] = (
    now + datetime.timedelta(seconds=draft["max_runtime_seconds"])
).isoformat()
draft["notify_until"] = (
    now + datetime.timedelta(seconds=draft["max_runtime_seconds"] + 900)
).isoformat()
config = OUT / "job-release.bound.json"
with config.open("x") as stream:
    json.dump(draft, stream, indent=2)
    stream.write("\n")
command = [
    "taskset",
    "-c",
    "12,14,16,18",
    "bash",
    "scripts/dev/research-job.sh",
    "submit",
    "--config",
    str(config),
    "--state-dir",
    str(OUT / "build-runtime-v1"),
]
environment = dict(
    os.environ,
    UV_NO_SYNC="1",
    UV_OFFLINE="1",
    PYTHONDONTWRITEBYTECODE="1",
    PATH="/home/vscode/.local/bin:" + os.environ["PATH"],
)
child = subprocess.Popen(
    command, cwd=ROOT, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE
)
original = identity(process_info(child.pid))
try:
    stdout, stderr = child.communicate(timeout=120)
    status = child.wait()
finally:
    if child.poll() is None:
        child.terminate()
        stdout, stderr = child.communicate(timeout=30)
        child.wait()
    child.stdout.close()
    child.stderr.close()
receipt = dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    command=command,
    exit_code=status,
    stdout=stdout.decode(),
    stderr=stderr.decode(),
    directwait_reaped=True,
    pipes_closed=True,
    client=original,
    fresh=identity(process_info(child.pid)),
    OUTSIDE_Cycle=True,
    phase="RPC_ONLY_NOT_NATIVE_ADMISSION",
    source_leases=[],
    host_future_quiet=False,
)
with (OUT / "original-release-submit-v1.json").open("x") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(
    json.dumps(
        dict(
            exit_code=status,
            stdout=receipt["stdout"],
            stderr=receipt["stderr"],
            directwait_reaped=True,
        )
    )
)
assert status == 0
