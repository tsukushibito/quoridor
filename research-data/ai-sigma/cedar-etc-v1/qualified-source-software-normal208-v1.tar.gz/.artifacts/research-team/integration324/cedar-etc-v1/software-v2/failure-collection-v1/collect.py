"""Collect the original ETC typing failure; preserve all failure facts."""

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    loader = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


def main():
    helper = load(
        "metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py",
    )
    lc = load("current", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helper.ref
    runtime = BASE / "build-runtime-v1"
    outer = json.loads((runtime / "result.json").read_bytes())
    state = json.loads((runtime / "state.json").read_bytes())
    candidate_path = BASE / "operation-release/candidate.json"
    candidate = json.loads(candidate_path.read_bytes())
    intent = json.loads(helper.checked(candidate["intent"]).read_bytes())
    assert outer["job_id"] == "7ced576a-cd73-4730-8e41-635d35a7a636"
    assert outer["outcome"] == "failed" and outer["exit_code"] == 1
    assert (
        outer["direct_child_reaped"]
        and outer["cleanup_complete"]
        and outer["remaining"] == []
    )
    rows = candidate["checks"]
    assert [r["status"] for r in rows] == ["PASS"] * 9 + ["FAILED"]
    known = [state["child"]]
    for row in rows:
        process = json.loads(
            helper.checked(row["persisted_process_receipt"]).read_bytes()
        )
        assert process["direct_child_reaped"] and process["handle_closes_complete"]
        assert process["cleanup_complete"] and process["remaining"] == []
        known.append(process["child"])
    failed = rows[-1]
    assert failed["guardian_return"] is None and failed["capture_complete"] is False
    log = helper.checked(failed["full_log"]).read_text()
    assert "running 1 test" in log and "etc_tests.rs:280:18" in log
    assert "small fixture has ordered third" in log
    assert "test result: FAILED. 0 passed; 1 failed" in log
    prior = []
    for row in rows[7:9]:
        passed_log = helper.checked(row["full_log"]).read_text()
        assert "running 1 test" in passed_log
        assert "test result: ok. 1 passed; 0 failed" in passed_log
        prior.append(
            dict(
                name=row["name"],
                file=ref(candidate_path),
                full_log=row["full_log"],
                process=row["persisted_process_receipt"],
            )
        )
    fresh = []
    for member in known:
        now = lc.process.identity(lc.process.process_info(member["pid"]))
        assert now != lc.process.identity(member)
        fresh.append(dict(original=member, fresh=now))
    with lc.lease():
        lc.source_check(intent["source"])
        temporary = Path(intent["TMP"])
        if temporary.exists():
            assert (
                temporary.is_dir()
                and not temporary.is_symlink()
                and not list(temporary.iterdir())
            )
            temporary.rmdir()
        affected = helper.allocated_union([Path(p) for p in intent["owned_outputs"]])
    result = dict(
        status="ACTUAL_ETC_AI3_FIXTURE_FAILURE_AI1_AI2_PASS_SOURCE_STOP",
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        outer=ref(runtime / "result.json"),
        candidate=ref(candidate_path),
        failed_log=failed["full_log"],
        failed_process=failed["persisted_process_receipt"],
        failed_guardian_NULL_capture_false_cleanup_false_retained=True,
        disk_cleanup_true_mask_pending_persist_attempted_retained=True,
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        failure="AI3 fixture expected a third already-ordered legal move but small_root supplied none; no numerical/science failure established",
        prior_actual_PASS=prior,
        compiler_tests_qualification="AI1/AI2 actual1PASS each; AI3 failed after body entry, AI4/Runner1/Clippy/release unentered",
        known_fresh_absence=fresh,
        source_EX_NB_acquired_released=True,
        source_leases=[],
        TMP=[],
        remaining_owned=[],
        affected_point_once=affected,
        source_Git_native_Search_games_model_RAW_RNG_replay=0,
        globalactual_later_tails_fullfees="UNKNOWN",
        host_future_quiet=False,
    )
    (OUT / "completion-and-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            dict(receipt=ref(OUT / "completion-and-STOP.json"), affected=affected)
        )
    )


if __name__ == "__main__":
    main()
