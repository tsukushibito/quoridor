"""Retain collector affinity refusals and remove only their empty stopped TMPs."""

import importlib.util
import json
from pathlib import Path

from quoridor_training.cycle_process import identity, process_info

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def main():
    loader = importlib.util.spec_from_file_location(
        "refs", OUT.parent.parent / "adoption-v1/adopt.py"
    )
    refs = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(refs)
    rows = []
    for name, tmp in [
        ("prepare.execution.process.json", "guard-TMP"),
        ("collection-v2.execution.process.json", "guard-v2-TMP"),
    ]:
        path = OUT / name
        result = json.loads(path.read_bytes())
        assert result["status"] == "failed" and result["exit_code"] == 1
        assert result["direct_child_reaped"] and result["handle_closes_complete"]
        assert result["cleanup_complete"] and result["remaining"] == []
        now = identity(process_info(result["child"]["pid"]))
        assert now != result["child"]
        directory = OUT / tmp
        assert (
            directory.is_dir()
            and not directory.is_symlink()
            and not list(directory.iterdir())
        )
        directory.rmdir()
        rows.append(
            dict(
                original=refs.ref(path),
                fresh=now,
                preserved_mask=result["signal_mask_restoration"],
                preserved_persist=result["final_record_persist"],
                empty_owned_TMP_removed=True,
            )
        )
    target = OUT / "causal-collection-controls.json"
    target.write_text(
        json.dumps(
            dict(
                status="TWO_PRE_FINALIZATION_AFFINITY_REFUSALS_PRESERVED_ONE_REAL_FINALIZATION",
                failures=rows,
                actual_completed_manifest=refs.ref(
                    OUT.parent / "operation-release/manifest.json"
                ),
                software_STOP=refs.ref(OUT / "completion-and-STOP.json"),
                actual_collector_return=refs.ref(OUT / "actual-returned-STOP.json"),
                cause="Collector allowed CPU10 then12/16 while original build_test_cpu_cores requires12/14/16. Both normal guard refusals before operation lock/finalizing/manifests. Corrected collector uses declared test pool; no predicate bypass or test/build/Search replay.",
                native_Search_test_build_RNG_replay=0,
                source_leases=[],
                host_future_quiet=False,
            ),
            indent=2,
        )
        + "\n"
    )
    print(json.dumps(refs.ref(target)))


if __name__ == "__main__":
    main()
