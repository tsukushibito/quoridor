"""Adopt the reviewed sparse ETC composition and pin normal cohort controllers."""

import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
PREP = OUT.parent / "composition-preparation-v3"


def ref(path):
    return dict(
        path=str(path),
        sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        bytes=path.stat().st_size,
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def main():
    loader = importlib.util.spec_from_file_location(
        "lc_adoption", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    composition = json.loads((PREP / "composition.json").read_bytes())
    patch = PREP / "forward-composed.patch"
    assert ref(patch)["sha256"] == composition["forward_sha256"]
    with lc.lease():
        before = []
        for row in composition["subjects"]:
            path = ROOT / row["subject"]
            if row["before_sha256"] is None:
                assert not path.exists()
                prior = None
            else:
                prior = ref(path)
                assert prior["sha256"] == row["before_sha256"]
            before.append(dict(subject=row["subject"], before=prior))
        subprocess.run(["git", "apply", "--check", str(patch)], cwd=ROOT, check=True)
        subprocess.run(["git", "apply", str(patch)], cwd=ROOT, check=True)
        for row in composition["subjects"]:
            actual = ref(ROOT / row["subject"])
            assert all(actual[k] == row["post"][k] for k in ("sha256", "bytes", "mode"))
        lc_path = ROOT / "scripts/dev/research-lifecycle.py"
        etc_lc = ref(lc_path)
        text = lc_path.read_text()
        anchor = "    initial_affinity = os.sched_getaffinity(0)\n"
        assert text.count(anchor) == 1
        replacement = (
            anchor
            + """    if settings.get("arena_cohort") is not None:
        cohort, _ = arena_cohort(arena_cohort_spec(settings_ref))
        management = set(cohort.get("management_cpu_pool", [cohort["global_controller_cpu"]]))
        require(management <= initial_affinity, "cohort management CPUs outside launch affinity")
        initial_affinity = management
        os.sched_setaffinity(0, initial_affinity)
"""
        )
        lc_path.write_text(text.replace(anchor, replacement))
        fixture = (
            ROOT
            / ".worktree/search-optimization/.artifacts/cedar-etc-v1/r1-repair-v1/test_etc_metadata_r1.py"
        )
        assert (
            ref(fixture)["sha256"]
            == "bc25ff48fa6f29a600145ed852a7fb99b32f40353d89cf81f316746e95b298e8"
        )
        destination = ROOT / "scripts/dev/test_research_lifecycle_etc.py"
        assert not destination.exists()
        shutil.copyfile(fixture, destination)
        after = [
            dict(subject=r["subject"], actual=ref(ROOT / r["subject"]))
            for r in composition["subjects"]
        ]
        (OUT / "adoption.json").write_text(
            json.dumps(
                dict(
                    at=datetime.datetime.now(datetime.UTC).isoformat(),
                    composition=ref(PREP / "composition.json"),
                    sparse_patch=ref(patch),
                    subjects=before,
                    adopted=after,
                    ETC_LC_before_controller_pin=etc_lc,
                    Python_ETC_fixture=ref(destination),
                    scope="Sparse ETC + declared cohort management affinity; strict peer predicate unchanged. UNTYPED/UNRUN.",
                    native_Search_model_RAW_RNG=0,
                    source_leases=[],
                    host_future_quiet=False,
                ),
                indent=2,
            )
            + "\n"
        )
    print("Sparse ETC and cohort controller affinity adopted; software unentered")


if __name__ == "__main__":
    main()
