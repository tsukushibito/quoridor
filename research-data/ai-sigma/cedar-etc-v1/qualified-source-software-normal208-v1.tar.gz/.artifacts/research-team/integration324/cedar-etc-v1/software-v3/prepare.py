"""Freeze genuinely new ETC boundary software and one common release."""

import copy
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def load(name, path):
    loader = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


def main():
    helper = load("etc_refs", OUT.parent / "adoption-v1/adopt.py")
    ref = helper.ref
    lc = load("etc_lifecycle", ROOT / "scripts/dev/research-lifecycle.py")
    old = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-probcut-v1/software-arena-v2"
    )
    template = json.loads((old / "build-intent-release.json").read_bytes())

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return ref(path)

    with lc.lease():
        source = copy.deepcopy(template["source"])
        patch = OUT / "actual-source.patch"
        patch.write_bytes(
            subprocess.check_output(
                [
                    "git",
                    "diff",
                    "--binary",
                    "--no-ext-diff",
                    "--no-textconv",
                    "HEAD",
                    "--",
                ],
                cwd=ROOT,
            )
        )
        used = subprocess.check_output(
            [
                "git",
                "ls-files",
                "--others",
                "--exclude-standard",
                "-z",
                "--",
                "Cargo.toml",
                "Cargo.lock",
                ".cargo",
                "crates",
            ],
            cwd=ROOT,
        )
        source.update(
            commit=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
            ).strip(),
            patch=ref(patch),
            untracked_inputs=[ref(ROOT / p.decode()) for p in used.split(b"\0") if p],
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        assert len(source["untracked_inputs"]) == 3
        fixture_adoption = json.loads(
            (OUT.parent / "fixture-adoption-v1/adoption.json").read_bytes()
        )
        assert (
            ref(ROOT / "crates/quoridor-ai/src/etc_tests.rs")
            == fixture_adoption["after"]
        )
        prior_path = OUT.parent / "software-v2/operation-release/candidate.json"
        prior = json.loads(prior_path.read_bytes())
        assert [row["status"] for row in prior["checks"]] == ["PASS"] * 9 + ["FAILED"]
        passed = prior["checks"][7:9]
        assert [r["name"] for r in passed] == ["etc-new-AI-1", "etc-new-AI-2"]
        prefix_ref = save(
            "accepted-prior-AI1-AI2-prefix.json",
            dict(
                status="PASS_TWO_PRIOR_TESTS_ONLY_ORIGINAL_PARENT_FAILED",
                checks=passed,
                primary=None,
                origin_job_id=prior["originating_job"]["job_id"],
                original_failed_candidate=ref(prior_path),
                original_parent_primary=prior["primary"],
                fixture_correspondence=ref(
                    OUT.parent / "fixture-adoption-v1/adoption.json"
                ),
                scope="Actual2PASS retained; only AI3 synthetic fixture setup changed; common production/helpers/AI1/AI2 bodies exact. No replay or parent success.",
            ),
        )
        composition = json.loads(
            (OUT.parent / "composition-preparation-v3/composition.json").read_bytes()
        )
        prior_subjects = []
        for row in composition["subjects"]:
            name = row["subject"]
            if not name.startswith("crates/quoridor-ai/") or name.endswith(
                "etc_tests.rs"
            ):
                continue
            witness = ref(ROOT / name)
            expected = row["post"]["sha256"]
            if name.endswith("lazy_smp.rs"):
                expected = (
                    "4e5044797ae8d4339382665592eb8e10c0f0f7f16a8046cdd1a33ef5140d6144"
                )
            assert witness["sha256"] == expected
            prior_subjects.append(witness)
        for row in source["cargo_configs"]:
            path = Path(row["path"])
            row["file"] = ref(path) if path.exists() else None
        authority = save(
            "source-adoption.json",
            dict(
                schema="quoridor.research.source-adoption.v1",
                status="ACCEPTED",
                issue="quoridor-4lc.324.31",
                source=source,
                sparse_adoption=ref(OUT.parent / "adoption-v1/adoption.json"),
                causal_import_repair=ref(
                    OUT.parent / "import-adoption-v1/adoption.json"
                ),
                causal_fixture_repair=ref(
                    OUT.parent / "fixture-adoption-v1/adoption.json"
                ),
                prior_software=dict(
                    subjects=prior_subjects,
                    receipts=[dict(name=r["name"], file=prefix_ref) for r in passed],
                ),
                original_failed_compiler_STOP=ref(
                    OUT.parent
                    / "software-v1/failure-collection-v1/completion-and-STOP.json"
                ),
                actual_Python2=ref(OUT.parent / "adoption-v1/Python2-result.json"),
                scope="Reviewed ETC source + R1 sparse composition retains MPC transport; controller affinity pin is Python-only, separately reviewed. New AI4/Runner1 and affected Clippy/release; no old success replay.",
            ),
        )
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
            owned_B=None,
            free_B=None,
        )
        support = save(
            "resources.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.31",
                authority=authority,
                resources=dict(
                    worker_cpu=12,
                    guardian_cpu=16,
                    test_cpu_cores=[12, 14, 16],
                    native_threads=1,
                    GPU=0,
                    family_RAM_B=limits["family_B"],
                    controller_included=True,
                    controller_B=limits["controller_B"],
                    host_reserve_B=limits["host_reserve_B"],
                ),
                scope="Ordinary new-only software; actual physics/source/host/cancel admission belongs to normal job. No Search or game grant.",
                storage="No ordinary microstorage gate; affected actual once after STOP; decimal50GB and unique evidence retained.",
            ),
        )
        target = Path(template["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker["writer"] == WRITER
        handover = json.loads((old / "target-handover.json").read_bytes())
        handover.update(
            fresh_private_root=str(OUT / "private-image-release"),
            actual_source_adoption=authority,
            owned_remaining=[],
        )
        handover_ref = save("target-handover.json", handover)
        cargo = template["tools"]["CARGO"]["file"]["path"]
        base = [
            "--offline",
            "--locked",
            "--manifest-path",
            str(ROOT / "Cargo.toml"),
            "-j1",
            "--message-format=json-render-diagnostics",
            "--release",
        ]
        plan = json.loads(
            (
                ROOT
                / ".worktree/search-optimization/.artifacts/cedar-etc-v1/new-test-plan.json"
            ).read_bytes()
        )
        commands = []
        for index, selector in enumerate(plan["AI"]["exact_selectors"][2:], start=2):
            commands.append(
                dict(
                    name=f"etc-new-AI-{index + 1}",
                    role="test",
                    selector=selector,
                    argv=[
                        cargo,
                        "test",
                        *base,
                        "-p",
                        "quoridor-ai",
                        "--features",
                        "research-diagnostics",
                        "--lib",
                        selector,
                        "--",
                        "--exact",
                        "--nocapture",
                        "--test-threads=1",
                    ],
                )
            )
        selector = plan["Runner"]["exact_selector"]
        commands.append(
            dict(
                name="etc-new-Runner-1",
                role="test",
                selector=selector,
                argv=[
                    cargo,
                    "test",
                    *base,
                    "-p",
                    "quoridor-runner",
                    "--features",
                    "measurement,quoridor-inference/claustrophobia",
                    "--lib",
                    selector,
                    "--",
                    "--exact",
                    "--nocapture",
                    "--test-threads=1",
                ],
            )
        )
        for package, features in [
            ("quoridor-ai", "research-diagnostics"),
            ("quoridor-runner", "measurement,quoridor-inference/claustrophobia"),
        ]:
            commands.append(
                dict(
                    name=f"etc-affected-{package}-Clippy",
                    role="lint",
                    argv=[
                        cargo,
                        "clippy",
                        *base,
                        "-p",
                        package,
                        "--features",
                        features,
                        "--all-targets",
                        "--no-deps",
                        "--",
                        "-Dwarnings",
                    ],
                )
            )
        build = copy.deepcopy(template["commands"][-1])
        assert build["role"] == "build"
        build["name"] = "etc-genuine-common-release"
        commands.append(build)
        spec = copy.deepcopy(template)
        for key in ("admission", "intent_sha256"):
            spec.pop(key, None)
        spec.update(
            output=str(OUT / "operation-release"),
            owned_outputs=[str(OUT.parent), str(target)],
            support=support,
            source_adoption=authority,
            target_handover=handover_ref,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / "private-image-release/quoridor-runner"),
            TMP=str(OUT / "build-TMP"),
            test_cpu_cores=[12, 14, 16],
            command_timeout_seconds=2400,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        (target / ".research-owner.json").write_text(
            json.dumps(
                dict(
                    writer=WRITER, target=str(target), support_sha256=support["sha256"]
                ),
                indent=2,
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            "admission.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="New ordinary software; actual normal admission remains owning runtime.",
            ),
        )
        intent = save("build-intent-release.json", spec)
        job = json.loads((old / "job-release.json").read_bytes())
        job.update(
            argv=[
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "build",
                "--intent",
                intent["path"],
                "--sha256",
                intent["sha256"],
            ],
            resource_contract=support["path"],
            max_runtime_seconds=2460,
            end_at=None,
            notify_until=None,
        )
        save("job-release.json", job)
        print(json.dumps(dict(intent=intent, support=support, submitted=False)))


if __name__ == "__main__":
    main()
