"""Collect the original ETC typing failure; preserve all failure facts."""

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def load(name, path):
    loader = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


def main():
    helper = load(
        "metadata",
        ROOT
        / ".artifacts/research-team/integration324/cedar-aspiration-window-v1/software-v2/prefix-collection-v1/collect.py",
    )
    lc = load("current", ROOT / "scripts/dev/research-lifecycle.py")
    ref = helper.ref
    runtime = BASE / "build-runtime-v1"
    outer = json.loads((runtime / "result.json").read_bytes())
    state = json.loads((runtime / "state.json").read_bytes())
    candidate_path = BASE / "operation-release/candidate.json"
    candidate = json.loads(candidate_path.read_bytes())
    intent = json.loads(helper.checked(candidate["intent"]).read_bytes())
    assert outer["job_id"] == "240577fb-e839-439e-8837-4c016df8e03f"
    assert outer["outcome"] == "failed" and outer["exit_code"] == 1
    assert (
        outer["direct_child_reaped"]
        and outer["cleanup_complete"]
        and outer["remaining"] == []
    )
    rows = candidate["checks"]
    assert [r["status"] for r in rows] == ["PASS"] * 7 + ["FAILED"]
    known = [state["child"]]
    for row in rows:
        process = json.loads(
            helper.checked(row["persisted_process_receipt"]).read_bytes()
        )
        assert process["direct_child_reaped"] and process["handle_closes_complete"]
        assert process["cleanup_complete"] and process["remaining"] == []
        known.append(process["child"])
    failed = rows[-1]
    assert failed["guardian_return"] is None and failed["capture_complete"] is False
    log = helper.checked(failed["full_log"]).read_text()
    assert log.count("error[E0433]") == 2
    assert "lazy_smp.rs:283:39" in log and "lazy_smp.rs:349:18" in log
    assert "running 1 test" not in log
    fresh = []
    for member in known:
        now = lc.process.identity(lc.process.process_info(member["pid"]))
        assert now != lc.process.identity(member)
        fresh.append(dict(original=member, fresh=now))
    with lc.lease():
        lc.source_check(intent["source"])
        temporary = Path(intent["TMP"])
        if temporary.exists():
            assert (
                temporary.is_dir()
                and not temporary.is_symlink()
                and not list(temporary.iterdir())
            )
            temporary.rmdir()
        affected = helper.allocated_union([Path(p) for p in intent["owned_outputs"]])
    result = dict(
        status="ACTUAL_FIRST_ETC_TYPING_FAILURE_BEFORE_ANY_TEST_BODY_SOURCE_STOP",
        at=datetime.datetime.now(datetime.UTC).isoformat(),
        outer=ref(runtime / "result.json"),
        candidate=ref(candidate_path),
        failed_log=failed["full_log"],
        failed_process=failed["persisted_process_receipt"],
        failed_guardian_NULL_capture_false_cleanup_false_retained=True,
        disk_cleanup_true_mask_pending_persist_attempted_retained=True,
        outer_seconds_once=outer["wall_seconds"],
        nested_added=0,
        failure="E0433 EtcMode missing from explicit lazy_smp import; 0 test bodies, no science",
        compiler_tests_qualification="AI4/Runner1/Clippy/release all genuinely unfinished",
        known_fresh_absence=fresh,
        source_EX_NB_acquired_released=True,
        source_leases=[],
        TMP=[],
        remaining_owned=[],
        affected_point_once=affected,
        source_Git_native_Search_games_model_RAW_RNG_replay=0,
        globalactual_later_tails_fullfees="UNKNOWN",
        host_future_quiet=False,
    )
    (OUT / "completion-and-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            dict(receipt=ref(OUT / "completion-and-STOP.json"), affected=affected)
        )
    )


if __name__ == "__main__":
    main()
