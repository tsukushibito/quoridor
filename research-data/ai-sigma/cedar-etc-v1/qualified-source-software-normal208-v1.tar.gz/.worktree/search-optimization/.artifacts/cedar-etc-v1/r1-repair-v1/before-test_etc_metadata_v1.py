"""New ETC-only metadata definition. UNRUN here; Root canonical import only."""

import importlib.util
from pathlib import Path
import sys
import unittest


class EtcMetadataBoundary(unittest.TestCase):
    def test_etc31_typed_mixed_custody_and_namespace_correspondence(self):
        root = Path("/workspaces/quoridor")
        spec = importlib.util.spec_from_file_location(
            "etc31_canonical_lifecycle", root / "scripts/dev/research-lifecycle.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        self.assertEqual(module.resolved_etc({}, "control"), "off")
        config = dict(etc="depth3_top2", search_threads=1, lmr_method="depth_rank")
        self.assertEqual(module.resolved_etc(config, "control"), "depth3_top2")
        for patch in [
            dict(etc=None),
            dict(etc=True),
            dict(etc="on"),
            dict(search_threads=2),
            dict(probcut={}),
            dict(probcut_samples=8),
            dict(root_ordering_quality=True),
            dict(neighbour_opportunity="off_shadow"),
            dict(history_provenance=[]),
            dict(lmr_method="fixed_one"),
        ]:
            with self.assertRaises(module.Refused):
                module.resolved_etc({**config, **patch}, "control")
        with self.assertRaises(module.Refused):
            module.resolved_etc(config, "cheap")
        with self.assertRaises(module.Refused):
            module.resolved_etc(config, "control", supported=False)
        record = dict(etc_requested="depth3_top2", etc_effective="depth3_top2")
        namespace = "etc-depth3-top2-v1:actual-normal-Control"
        module.etc_correspondence(
            config, record, profile="control", namespace=namespace
        )
        for bad in [
            {**record, "etc_effective": "off"},
            {**record, "etc_requested": None},
        ]:
            with self.assertRaises(module.Refused):
                module.etc_correspondence(
                    config, bad, profile="control", namespace=namespace
                )
        with self.assertRaises(module.Refused):
            module.etc_correspondence(
                config, record, profile="control", namespace="ordinary-Control"
            )
        with self.assertRaises(module.Refused):
            module.etc_correspondence(
                {}, record, profile="control", namespace=namespace
            )


if __name__ == "__main__":
    unittest.main()
