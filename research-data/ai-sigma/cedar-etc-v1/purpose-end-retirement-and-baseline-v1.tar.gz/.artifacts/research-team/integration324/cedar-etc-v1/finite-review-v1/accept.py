"""Accept only the fixed ETC finite interpretation and record its exact evidence."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
REVIEW = ROOT / ".worktree/assets/perf/cedar-etc-review-v1/finite-result-v1"


def main():
    loader = importlib.util.spec_from_file_location(
        "refs", OUT.parent / "adoption-v1/adopt.py"
    )
    refs = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(refs)
    expected = {
        "minimum.json": (
            "d5ac41b787d6c5d67780a182d2e34c3942f5949756dfe8a7f755017292873b8c",
            4344,
        ),
        "control.json": (
            "4655555c934a4142de0ef8770abccb8df0de6e2077c364bdb27d246a4c61ad16",
            846,
        ),
        "saved-correspondence.json": (
            "358260d1292f4382a8b655f9a8fa9864622c73086ab92343652763de52326772",
            4577,
        ),
        "reader-STOP.json": (
            "e65dceafafb144a98f8b6dbb7cd72c3dcffbddfcd10842699fdca186acabdb3e",
            3272,
        ),
        "returned-STOP.json": (
            "4c580f9a7365011d8eb7d6e132474301505c11379c51995c2ebc3935a345ddaf",
            920,
        ),
    }
    evidence = {}
    for name, (sha, length) in expected.items():
        actual = refs.ref(REVIEW / name)
        assert (actual["sha256"], actual["bytes"], actual["mode"]) == (
            sha,
            length,
            "0644",
        )
        evidence[name] = actual
    minimum = json.loads((REVIEW / "minimum.json").read_bytes())
    assert minimum["verdict"] == "CONCLUSION_CLEAR"
    assert minimum["essential"] == minimum["ordinary"] == 0
    target = (
        ROOT
        / ".worktree/assets/perf/cedar-etc-v1/normal208-v2/analysis-v1/minimum-result.json"
    )
    assert (
        refs.ref(target)["sha256"]
        == "7c7b1bcf183dde8488f3fb9f65735899f90ce0dc9f86e4a102f57a834b9f7c19"
    )
    result = dict(
        issue="quoridor-4lc.324.31.2",
        status="CONCLUSION_CLEAR_ACCEPTED",
        target=refs.ref(target),
        evidence=evidence,
        decision="RETAIN_OFF_NO_FINITE_SUPPORT",
        conditional_games="INELIGIBLE_UNISSUED_NO_GAMES",
        default="OFF retained",
        scope="Exact original208 finite interpretation only; not CPU source/software/retirement acceptance or general strength claim",
        native_Search_model_RAW_RNG_replay=0,
        author_normal_close_reason="Root accepted d5ac41b7 CONCLUSION_CLEAR e0/o0 for exact7c7b1bcf original208 finite interpretation: RETAIN_OFF_NO_FINITE_SUPPORT, conditional256 INELIGIBLE_UNISSUED. Original failures/censoring/costs retained; no game/default/newrights. Root acceptance .artifacts/research-team/integration324/cedar-etc-v1/finite-review-v1/Root-final-acceptance.json",
    )
    with (OUT / "Root-final-acceptance.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    public = ROOT / "research-data/ai-sigma/cedar-etc-v1/finite208-result-v1.json"
    record = json.loads(public.read_bytes())
    record["status"] = "INDEPENDENT_CONCLUSION_CLEAR_ACCEPTED"
    record["independent_review"] = evidence
    record["Root_acceptance"] = refs.ref(OUT / "Root-final-acceptance.json")
    public.write_text(json.dumps(record, indent=2) + "\n")
    findings = ROOT / "docs/research-findings.md"
    text = findings.read_text()
    old = "同Maxへ限定した重要解釈確認中で、3元family"
    new = "同Maxの限定した重要解釈確認は指摘0件で受け入れた。3元family"
    assert text.count(old) == 1
    findings.write_text(text.replace(old, new))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
