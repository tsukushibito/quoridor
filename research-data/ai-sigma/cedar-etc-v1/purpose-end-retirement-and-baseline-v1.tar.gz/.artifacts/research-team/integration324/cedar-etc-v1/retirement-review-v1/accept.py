"""Accept the exact retirement source boundary; new software is still required."""

import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
REVIEW = ROOT / ".worktree/assets/perf/cedar-etc-review-v1/retirement-source-v1"


def main():
    loader = importlib.util.spec_from_file_location(
        "refs", OUT.parent / "adoption-v1/adopt.py"
    )
    refs = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(refs)
    expected = {
        "minimum.json": (
            "602294f8d631d36a839bf0a9b944516e027bdcebce6cd3e29ec83b29f44de0c8",
            3242,
        ),
        "control.json": (
            "b1992d99d641bc32809f30f791318f414762f0edfd4352b2b856f41efffd0657",
            873,
        ),
        "source-correspondence.json": (
            "7e83026ce0afa811b7f717e50dc75041de56fbff28dc43e7f426e70955117f20",
            8448,
        ),
        "reader-STOP.json": (
            "9464fbc84e42607987ee593138ce1beac805074a7017e768d827d50cf3ed80cb",
            5447,
        ),
        "returned-STOP.json": (
            "5be4f97c7ef43cfd0b8161ea94c80fc3cb27941141cc6cdbc0bced6dddc8c084",
            933,
        ),
    }
    evidence = {}
    for name, (sha, length) in expected.items():
        actual = refs.ref(REVIEW / name)
        assert (actual["sha256"], actual["bytes"], actual["mode"]) == (
            sha,
            length,
            "0644",
        )
        evidence[name] = actual
    minimum = json.loads((REVIEW / "minimum.json").read_bytes())
    assert (
        minimum["verdict"] == "SOURCE_CLEAR"
        and minimum["essential"] == minimum["ordinary"] == 0
    )
    binding = (
        ROOT
        / ".worktree/search-optimization/.artifacts/cedar-etc-v1/purpose-end-retirement-v2/binding.json"
    )
    assert (
        refs.ref(binding)["sha256"]
        == "e7244674d025ffc1ace8f6232314ce7e400eb4f755100cb0df23c81bc7b2e86a"
    )
    record = dict(
        issue="quoridor-4lc.324.31.3",
        status="SOURCE_CLEAR_ACCEPTED_SOFTWARE_UNRUN",
        binding=refs.ref(binding),
        evidence=evidence,
        reconstruction_commit="22d23276a0651004059b741f69901d8b7188317f",
        scope="Only19subject ETC purpose-end source retirement. Root composes9LCfragments preserving16CPU functions; affectedAI+RunnerClippy/type and genuinelynewbaseline remain required. No software/parity/performance/science/default grant.",
        native_Search_model_RNG_replay=0,
        author_normal_close_reason="Root accepted 602294f8 SOURCE_CLEAR e0/o0 for exacte7244674 ETC purpose-end retirement source only; originalfinite d5ac retained and no games. Root sparse composition/new software/baseline remain separate. Root acceptance .artifacts/research-team/integration324/cedar-etc-v1/retirement-review-v1/Root-source-acceptance.json",
    )
    with (OUT / "Root-source-acceptance.json").open("x") as stream:
        stream.write(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
