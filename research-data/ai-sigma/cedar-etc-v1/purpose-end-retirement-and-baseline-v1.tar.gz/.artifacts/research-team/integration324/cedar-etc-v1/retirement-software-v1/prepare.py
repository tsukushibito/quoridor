"""Freeze affected all-target typing/lint and a genuine post-retirement release."""

import copy
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
WRITER = "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    refs = load("refs", OUT.parent / "adoption-v1/adopt.py")
    ref = refs.ref
    lc = load("lc_release", ROOT / "scripts/dev/research-lifecycle.py")
    old = (
        ROOT
        / ".artifacts/research-team/integration324/cedar-probcut-v1/software-arena-v2"
    )
    template = json.loads((old / "build-intent-release.json").read_bytes())

    def save(name, value):
        path = OUT / name
        with path.open("x") as stream:
            stream.write(json.dumps(value, indent=2) + "\n")
        return ref(path)

    with lc.lease():
        adopted = OUT.parent / "retirement-adoption-v1/adoption.json"
        assert (
            json.loads(adopted.read_bytes())["status"]
            == "ETC_RETIRED_SPARSELY_SOFTWARE_AND_NEW_BASELINE_UNRUN"
        )
        source = copy.deepcopy(template["source"])
        patch = OUT / "actual-source.patch"
        patch.write_bytes(
            subprocess.check_output(
                [
                    "git",
                    "diff",
                    "--binary",
                    "--no-ext-diff",
                    "--no-textconv",
                    "HEAD",
                    "--",
                ],
                cwd=ROOT,
            )
        )
        untracked = subprocess.check_output(
            [
                "git",
                "ls-files",
                "--others",
                "--exclude-standard",
                "-z",
                "--",
                "Cargo.toml",
                "Cargo.lock",
                ".cargo",
                "crates",
            ],
            cwd=ROOT,
        )
        assert not untracked
        source.update(
            commit=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
            ).strip(),
            patch=ref(patch),
            untracked_inputs=[],
            manifest=ref(ROOT / "Cargo.toml"),
            lock=ref(ROOT / "Cargo.lock"),
        )
        for row in source["cargo_configs"]:
            path = Path(row["path"])
            row["file"] = ref(path) if path.exists() else None
        original_adoption = old / "source-adoption.json"
        prior = copy.deepcopy(
            json.loads(original_adoption.read_bytes())["prior_software"]
        )
        # All eight current AI owners match their genuine pre-ETC qualified bytes.
        # This reuses completed checks; it does not rerun tests or restore old posts.
        for expected in prior["subjects"]:
            assert ref(Path(expected["path"])) == expected
        authority = save(
            "source-adoption.json",
            dict(
                schema="quoridor.research.source-adoption.v1",
                status="ACCEPTED",
                issue="quoridor-4lc.324.31",
                source=source,
                retirement=ref(adopted),
                source_review=ref(
                    OUT.parent / "retirement-review-v1/Root-source-acceptance.json"
                ),
                CPU_source_review=ref(
                    OUT.parents[1]
                    / "research-cpu-plan-v1/source-review-v1/Root-source-acceptance.json"
                ),
                CPU_limited_tests=ref(
                    OUT.parents[1] / "research-cpu-plan-v1/software-v3/result.json"
                ),
                prior_software=prior,
                original_prior_adoption=ref(original_adoption),
                scope="Actual ETC-only retirement preserves current MPC and common AI owners byteexact to qualified pre-ETC. Actual prior AI5 reused without replay; affected AI/Runner all-target Clippy/type and genuine current baseline release now required. CPU real dummy parallel smoke remains separate.",
            ),
        )
        limits = dict(
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            worker_cpu=12,
            guardian_cpu=16,
            log_B=2 * 1024**2,
            owned_B=None,
            free_B=None,
        )
        support = save(
            "resources.json",
            dict(
                schema="quoridor.research.phase-support.v1",
                issue="quoridor-4lc.324.31",
                authority=authority,
                resources=dict(
                    CPU=2,
                    threads=1,
                    GPU=0,
                    worker_cpu=12,
                    guardian_cpu=16,
                    native_threads=1,
                    family_RAM_B=limits["family_B"],
                    controller_included=True,
                    controller_B=limits["controller_B"],
                    host_reserve_B=limits["host_reserve_B"],
                ),
                scope="Ordinary required post-retirement typing/lint/release; actual source/physical/host/cancel/cleanup admission belongs to owning normal job. No Search/test-body/model/game grant.",
                storage="Existing whole2240MiB and shared sole-Root target; ordinary affected point once after STOP, no new microstorage gate/refund/lending.",
            ),
        )
        target = Path(template["target"])
        marker = json.loads((target / ".research-owner.json").read_bytes())
        assert marker["writer"] == WRITER
        handover = json.loads((old / "target-handover.json").read_bytes())
        handover.update(
            fresh_private_root=str(OUT / "private-image-release"),
            actual_source_adoption=authority,
            owned_remaining=[],
        )
        handover.pop("test_cpu_cores", None)
        handover_ref = save("target-handover.json", handover)
        cargo = template["tools"]["CARGO"]["file"]["path"]
        base = [
            "--offline",
            "--locked",
            "--manifest-path",
            str(ROOT / "Cargo.toml"),
            "-j1",
            "--message-format=json-render-diagnostics",
            "--release",
        ]
        commands = [
            dict(
                name=f"retirement-{package}-all-target-Clippy",
                role="lint",
                argv=[
                    cargo,
                    "clippy",
                    *base,
                    "-p",
                    package,
                    "--features",
                    features,
                    "--all-targets",
                    "--no-deps",
                    "--",
                    "-Dwarnings",
                ],
            )
            for package, features in [
                ("quoridor-ai", "research-diagnostics"),
                ("quoridor-runner", "measurement,quoridor-inference/claustrophobia"),
            ]
        ]
        build = copy.deepcopy(
            next(c for c in template["commands"] if c["role"] == "build")
        )
        build["name"] = "retirement-genuine-current-baseline-release"
        commands.append(build)
        spec = copy.deepcopy(template)
        for key in ("admission", "intent_sha256", "test_cpu_cores"):
            spec.pop(key, None)
        spec.update(
            output=str(OUT / "operation-release"),
            owned_outputs=[str(OUT.parent), str(target)],
            support=support,
            source_adoption=authority,
            target_handover=handover_ref,
            source=source,
            limits=limits,
            commands=commands,
            private=str(OUT / "private-image-release/quoridor-runner"),
            TMP=str(OUT / "build-TMP"),
            command_timeout_seconds=2400,
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        (target / ".research-owner.json").write_text(
            json.dumps(
                dict(
                    writer=WRITER, target=str(target), support_sha256=support["sha256"]
                ),
                indent=2,
            )
            + "\n"
        )
        lc.build_check(spec)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        spec["admission"] = save(
            "admission.json",
            dict(
                schema="quoridor.research.phase-admission.v1",
                owner=str(ROOT),
                limits=limits,
                spec_sha256=spec["intent_sha256"],
                support_sha256=support["sha256"],
                ready=True,
                scope="Ordinary software only; runtime admission/cancel/source owns actual entry.",
            ),
        )
        intent = save("build-intent-release.json", spec)
        job = json.loads((old / "job-release.json").read_bytes())
        job.update(
            argv=[
                str(lc.project_python()),
                "-B",
                str(ROOT / "scripts/dev/research-lifecycle.py"),
                "build",
                "--intent",
                intent["path"],
                "--sha256",
                intent["sha256"],
            ],
            resource_contract=support["path"],
            max_runtime_seconds=2460,
            end_at=None,
            notify_until=None,
        )
        save("job-release.json", job)
        print(json.dumps(dict(intent=intent, support=support, submitted=False)))


if __name__ == "__main__":
    main()
