"""Compose only ETC-owned LC fragments with the fixed CPU candidate."""

import ast
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
ETC = (
    ROOT
    / ".worktree/search-optimization/.artifacts/cedar-etc-v1/purpose-end-retirement-v2"
)
CPU = ROOT / ".worktree/search-optimization/.artifacts/research-cpu-plan-v1/fixed-v3"


def functions(text):
    lines = text.splitlines(keepends=True)
    return {
        n.name: "".join(lines[n.lineno - 1 : n.end_lineno])
        for n in ast.parse(text).body
        if isinstance(n, (ast.FunctionDef, ast.ClassDef))
    }


def main():
    loader = importlib.util.spec_from_file_location(
        "refs", OUT.parent / "adoption-v1/adopt.py"
    )
    refs = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(refs)
    cpu_binding = CPU / "source-binding.json"
    etc_binding = ETC / "binding.json"
    assert (
        refs.ref(cpu_binding)["sha256"]
        == "62d5fabf1030ebe55ccda9d8c46683f470d2edf9c4213ad416ae9a9f4bb33d81"
    )
    assert (
        refs.ref(etc_binding)["sha256"]
        == "e7244674d025ffc1ace8f6232314ce7e400eb4f755100cb0df23c81bc7b2e86a"
    )
    cpu = json.loads(cpu_binding.read_bytes())
    etc = json.loads(etc_binding.read_bytes())
    selector_ref = etc["fragments"]
    assert refs.ref(Path(selector_ref["path"])) == selector_ref
    selectors = json.loads(Path(selector_ref["path"]).read_bytes())["selectors"]
    name = "scripts/dev/research-lifecycle.py"
    cpu_lc = next(r for r in cpu["subjects"] if r["subject"] == name)
    assert refs.ref(Path(cpu_lc["post"]["path"])) == cpu_lc["post"]
    original = Path(cpu_lc["post"]["path"]).read_text()
    spans = []
    for row in selectors:
        if row["path"] != name:
            continue
        assert row["action"] == "exact_unique_fragment"
        needle = row["prefix"] + row["before"] + row["suffix"]
        assert original.count(needle) == 1, row["before_line"]
        start = original.index(needle) + len(row["prefix"])
        spans.append(
            (start, start + len(row["before"]), row["after"], row["before_line"])
        )
    spans.sort()
    assert all(a[1] <= b[0] for a, b in zip(spans, spans[1:]))
    composed = original
    for start, end, replacement, _ in reversed(spans):
        composed = composed[:start] + replacement + composed[end:]
    before_funcs, after_funcs = functions(original), functions(composed)
    owners = cpu["protected_correspondence"][0]
    protected = list(owners["changed"].values()) + owners["added"]
    for name in protected:
        assert before_funcs[name] == after_funcs[name], name
    target = OUT / "research-lifecycle-composed.py"
    with target.open("x") as stream:
        stream.write(composed)
    record = dict(
        status="PRIVATE_COMPOSED_CPU_AND_ETC_RETIREMENT_NOT_ADOPTED_UNRUN",
        cpu_binding=refs.ref(cpu_binding),
        etc_binding=refs.ref(etc_binding),
        cpu_LC=cpu_lc["post"],
        selectors=selector_ref,
        exact_ETC_fragments=len(spans),
        protected_CPU_functions_byteexact=protected,
        post=refs.ref(target),
        source_leases=[],
        native_Search_model_RNG=0,
    )
    with (OUT / "composition.json").open("x") as stream:
        stream.write(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
