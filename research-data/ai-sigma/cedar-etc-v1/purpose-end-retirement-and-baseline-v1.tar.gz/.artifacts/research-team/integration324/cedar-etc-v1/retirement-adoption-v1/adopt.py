"""Apply reviewed ETC retirement while preserving the adopted CPU functions."""

import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
SOURCE = (
    ROOT
    / ".worktree/search-optimization/.artifacts/cedar-etc-v1/purpose-end-retirement-v2"
)
COMPOSITION = OUT.parent / "retirement-composition-v1"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def same(actual, expected):
    return all(actual[k] == expected[k] for k in ("sha256", "bytes", "mode"))


def main():
    refs = load("refs", OUT.parent / "adoption-v1/adopt.py")
    lc = load("lc_retire", ROOT / "scripts/dev/research-lifecycle.py")
    packet = SOURCE / "binding.json"
    assert (
        refs.ref(packet)["sha256"]
        == "e7244674d025ffc1ace8f6232314ce7e400eb4f755100cb0df23c81bc7b2e86a"
    )
    binding = json.loads(packet.read_bytes())
    acceptance = json.loads(
        (OUT.parent / "retirement-review-v1/Root-source-acceptance.json").read_bytes()
    )
    assert acceptance["status"] == "SOURCE_CLEAR_ACCEPTED_SOFTWARE_UNRUN"
    assert acceptance["binding"] == refs.ref(packet)
    composition = json.loads((COMPOSITION / "composition.json").read_bytes())
    lc.read_ref(composition["post"])
    lc.read_ref(binding["forward"])
    before, after = [], []
    with lc.lease():
        for row in binding["files"]:
            actual = refs.ref(ROOT / row["path"])
            expected = (
                composition["cpu_LC"]
                if row["path"] == "scripts/dev/research-lifecycle.py"
                else row["before"]
            )
            assert same(actual, expected), row["path"]
            before.append(dict(subject=row["path"], actual=actual))
        command = ["git", "apply", "--exclude=scripts/dev/research-lifecycle.py"]
        subprocess.run(
            [*command, "--check", binding["forward"]["path"]], cwd=ROOT, check=True
        )
        subprocess.run([*command, binding["forward"]["path"]], cwd=ROOT, check=True)
        (ROOT / "scripts/dev/research-lifecycle.py").write_bytes(
            Path(composition["post"]["path"]).read_bytes()
        )
        for row in binding["files"]:
            path = ROOT / row["path"]
            if row["delete"]:
                assert not path.exists()
                actual = None
            else:
                actual = refs.ref(path)
                expected = (
                    composition["post"]
                    if row["path"] == "scripts/dev/research-lifecycle.py"
                    else row["post"]
                )
                assert same(actual, expected), row["path"]
            after.append(dict(subject=row["path"], actual=actual))
        result = dict(
            status="ETC_RETIRED_SPARSELY_SOFTWARE_AND_NEW_BASELINE_UNRUN",
            binding=refs.ref(packet),
            composition=refs.ref(COMPOSITION / "composition.json"),
            before=before,
            after=after,
            protected_CPU_functions_byteexact=composition[
                "protected_CPU_functions_byteexact"
            ],
            reconstruction_commit="22d23276a0651004059b741f69901d8b7188317f",
            source_leases=[],
            native_Search_model_RNG=0,
            performance_parity_strength="UNQUALIFIED",
        )
        with (OUT / "adoption.json").open("x") as stream:
            stream.write(json.dumps(result, indent=2) + "\n")
    print(json.dumps(dict(status=result["status"], subjects=len(after))))


if __name__ == "__main__":
    main()
