"""One admitted saved-model validation job, never a training or test entry.

Old B LAST2000 is the fixed same-seen primary baseline; BEST200 is secondary.
Both are immutable weights. Planned validation forwards are reused for parity.
"""

import argparse
import json
import os
from pathlib import Path
import subprocess

os.environ["ORT_DISABLE_TELEMETRY"] = "1"

from inputs import bound_json, combined_inputs, sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration")
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    for path, digest in reg["input_SHA"].items():
        if sha(path) != digest:
            raise ValueError("baseline source/input SHA changed")
    output = Path(reg["output"])
    if output.exists() or not output.parent.is_dir():
        raise ValueError("baseline output parent/collision preflight missing")
    import numpy as np
    import torch
    from quoridor_training.residual_model import DistanceResidualModel

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    combined, canonical = combined_inputs(reg["dataset"])
    _, rows, x, d, _ = combined
    ix = [i for i, row in enumerate(rows) if row["split"] == "validation"]
    if len(ix) != reg["validation_rows"]:
        raise ValueError("baseline must cover ALL raw Vraw before finalmask")
    expected_ids = json.loads(Path(reg["validation_order"]["path"]).read_text())
    if sha(reg["validation_order"]["path"]) != reg["validation_order"]["SHA"]:
        raise ValueError("planned validation order bytes changed")
    if [rows[i]["id"] for i in ix] != [row["id"] for row in expected_ids]:
        raise ValueError("saved baseline prediction order differs")
    meta = {row["id"]: row for row in canonical}
    val_index = {rows[i]["id"]: j for j, i in enumerate(ix)}
    witness = reg["witness_ids"]
    if len(witness) != 24 or len(set(witness)) != 24 or not set(witness) <= val_index.keys():
        raise ValueError("24 fixed validation input witnesses required")
    stats = bound_json(reg["fixed_scale"])
    config = bound_json(reg["baseline_config"])
    route_stats = json.loads(
        Path(reg["dataset"]["old_inputs"]["route_cache"]).joinpath("cache.json").read_text()
    )["route_statistics"]
    formula = len(reg["models"]) * (len(ix) + 48)
    if formula != reg["sample_upper"] or len(reg["models"]) != 2:
        raise ValueError("two saved baseline models/formula not bound")
    output.mkdir()
    reports = {}
    for item in reg["models"]:
        if item["name"] not in ("oldB_LAST2000", "oldB_BEST200"):
            raise ValueError("unregistered baseline checkpoint")
        checkpoint = torch.load(item["checkpoint"]["path"], map_location="cpu", weights_only=True)
        model = DistanceResidualModel(
            config["model"], stats, a=0, b=8, routes=False, route_statistics=route_stats
        )
        model.load_state_dict(checkpoint["model"])
        vector = np.concatenate(
            [
                p.detach().numpy().astype("<f4").reshape(-1)
                for p in (
                    model.ft.weight,
                    model.ft.bias,
                    model.h.weight,
                    model.h.bias,
                    model.out.weight,
                    model.out.bias,
                )
            ]
        )
        import hashlib

        if hashlib.sha256(vector.tobytes()).hexdigest() != item["native_weights"]["SHA"]:
            raise ValueError("saved PT/native baseline tensor binding differs")
        model.eval()
        chunks = []
        with torch.inference_mode():
            for first in range(0, len(ix), 1024):
                ids = ix[first : first + 1024]
                chunks.append(
                    model(
                        torch.from_numpy(x[ids]),
                        torch.from_numpy(d[ids]),
                        torch.ones(len(ids), dtype=torch.long),
                    ).numpy()
                )
        prediction = np.concatenate(chunks)
        if not np.isfinite(prediction).all():
            raise ValueError("nonfinite saved baseline predictions")
        path = output / (item["name"] + ".f32")
        prediction.astype("<f4").tofile(path)
        native = subprocess.run(
            [reg["native_binary"], "model", item["native_manifest"]["path"]],
            input="".join(json.dumps(meta[row_id]) + "\n" for row_id in witness),
            text=True,
            capture_output=True,
            timeout=30,
            check=True,
        )
        values = [json.loads(line) for line in native.stdout.splitlines()]
        if [row["id"] for row in values] != witness:
            raise ValueError("saved baseline native witness order differs")
        errors = [
            abs(float(prediction[val_index[row_id]]) - value["value"])
            for row_id, value in zip(witness, values)
        ]
        if any(
            e > 1e-6 + 1e-6 * abs(float(prediction[val_index[row_id]]))
            for e, row_id in zip(errors, witness)
        ):
            raise ValueError("saved baseline native/Torch parity failed")
        if any(
            abs(value["value"] - value["delta_value"]) > 1e-6 + 1e-6 * abs(value["value"])
            for value in values
        ):
            raise ValueError("saved baseline full/delta parity failed")
        reports[item["name"]] = {
            "predictions": {"path": str(path), "SHA": sha(path)},
            "native_weights": item["native_weights"],
            "max_parity_abs": max(errors),
            "native_parity": values,
        }
    result = {
        "task": "frame23-learning-286-saved-baseline-validation",
        "schema": "saved-baseline-validation-v1",
        "status": "PASS",
        "total_NN": formula,
        "processed": formula + 5901 + len(rows),
        "validation_rows": len(ix),
        "model_unique": 2,
        "training": 0,
        "future_labels_opened": False,
        "baselines": reports,
        "selection_use": "fixed baselines only; oldB LAST2000 primary, BEST200 secondary",
    }
    (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"total_NN": formula, "status": "PASS"}))


if __name__ == "__main__":
    main()
