"""Fake arithmetic checks, without labels from an actual dataset or model."""

import copy
import unittest

from aggregate import measure, merge_references


def reference(name, group, target):
    return {
        "id": name,
        "group": group,
        "split": "train",
        "side": 1,
        "ids": [[1, 82], [2, 83]],
        "distance": [0.1, 0.2],
        "state_key": name + "-state",
        "history_key": name + "-history",
        "data_origin": "fake",
        "rootmean": target,
        "z": 1,
    }


class AggregateTest(unittest.TestCase):
    def test_group_weighting_and_residual_decomposition(self):
        rows = [reference("a", "g1", 1), reference("b", "g1", 1), reference("c", "g2", 0)]
        mask = {row["id"]: {"eligible": True} for row in rows}
        baseline = [0.0, 0.0, 0.0]
        prediction = [0.5, 0.5, 0.5]
        actual = measure(rows, prediction, mask, origin="fake", baseline=baseline)
        initial = measure(rows, baseline, mask, origin="fake", baseline=baseline)
        self.assertAlmostEqual(initial["gameequal_rootmean_MSE"], 0.5)
        self.assertAlmostEqual(initial["rowweighted_rootmean_MSE"], 2 / 3)
        self.assertAlmostEqual(actual["gameequal_rootmean_MSE"], 0.25)
        self.assertAlmostEqual(
            actual["gameequal_rootmean_MSE"] - initial["gameequal_rootmean_MSE"],
            actual["gameequal_displacement"] + actual["gameequal_alignment"],
        )

    def test_excluded_group_stays_in_denominator(self):
        rows = [reference("a", "g1", 1), reference("b", "g2", 0)]
        mask = {"a": {"eligible": False}, "b": {"eligible": True}}
        result = measure(rows, [0, 0], mask, origin="fake", baseline=[0, 0])
        self.assertEqual((result["planned_groups"], result["eligible_groups"]), (2, 1))
        self.assertEqual((result["planned_rows"], result["eligible_rows"]), (2, 1))
        self.assertEqual(result["zeroeligible_groups"], 1)

    def test_no_eligible_group_is_unknown(self):
        rows = [reference("a", "g1", 1)]
        result = measure(rows, [0], {"a": {"eligible": False}}, origin="fake", baseline=[0])
        self.assertIsNone(result["gameequal_rootmean_MSE"])
        self.assertEqual(result["zeroeligible_groups"], 1)

    def test_union_deduplicates_but_rejects_changed_reference(self):
        a = reference("a", "g1", 1)
        self.assertEqual(len(merge_references([[a], [copy.deepcopy(a)]])), 1)
        changed = copy.deepcopy(a)
        changed["state_key"] = "different"
        with self.assertRaises(ValueError):
            merge_references([[a], [changed]])


if __name__ == "__main__":
    unittest.main()
