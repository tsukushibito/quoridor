"""Reaggregate saved validation forwards on one final label-free exposure mask.

No Torch, model, native forward or future labels. Required input paths are an
explicit stopped allowlist. Saved model selection stays exploratory validation.
"""

import argparse
import gzip
import json
import math
from pathlib import Path
import statistics
import struct

from exposure import canonical_input, mask, validate_rows
from inputs import bound_json, sha
from planning import CONDITIONS


def read_rows(path):
    with gzip.open(path, "rt") as stream:
        rows = [json.loads(line) for line in stream]
    validate_rows(rows)
    return rows


def merge_references(parts):
    result = {}
    for rows in parts:
        for row in rows:
            previous = result.setdefault(row["id"], row)
            if (
                canonical_input(previous) != canonical_input(row)
                or previous["state_key"] != row["state_key"]
                or previous["history_key"] != row["history_key"]
                or previous["group"] != row["group"]
            ):
                raise ValueError("same reference ID changed between saved runs")
    return list(result.values())


def floats(path, rows):
    body = Path(path).read_bytes()
    if len(body) != 4 * rows:
        raise ValueError("saved prediction row denominator changed")
    values = struct.unpack("<" + "f" * rows, body)
    if any(not math.isfinite(value) for value in values):
        raise ValueError("nonfinite saved prediction")
    return values


def measure(rows, prediction, eligible, *, origin, baseline):
    all_groups = {r["group"] for r in rows if r["data_origin"] == origin}
    indices = [
        i
        for i, row in enumerate(rows)
        if row["data_origin"] == origin and eligible[row["id"]]["eligible"]
    ]
    groups = {}
    for i in indices:
        row = rows[i]
        values = groups.setdefault(row["group"], [])
        values.append((row, prediction[i], baseline[i]))
    report = {
        "planned_rows": sum(r["data_origin"] == origin for r in rows),
        "eligible_rows": len(indices),
        "planned_groups": len(all_groups),
        "eligible_groups": len(groups),
        "zeroeligible_groups": len(all_groups - groups.keys()),
        "groups": {},
    }
    for group, values in groups.items():
        root, zerrors, correct, displacement, alignment = [], [], [], [], []
        for row, value, base in values:
            if row["rootmean"] is not None and math.isfinite(row["rootmean"]):
                root.append((value - row["rootmean"]) ** 2)
                residual = value - base
                displacement.append(residual**2)
                alignment.append(-2 * residual * (row["rootmean"] - base))
            if row["z"] is not None and math.isfinite(row["z"]):
                zerrors.append((value - row["z"]) ** 2)
                if row["z"] != 0:
                    correct.append(float(value * row["z"] > 0))
        report["groups"][group] = {
            "rows": len(values),
            "rootmean_rows": len(root),
            "z_rows": len(zerrors),
            "rootmean_MSE": statistics.fmean(root) if root else None,
            "z_MSE": statistics.fmean(zerrors) if zerrors else None,
            "z_sign_accuracy": statistics.fmean(correct) if correct else None,
            "displacement": statistics.fmean(displacement) if displacement else None,
            "alignment": statistics.fmean(alignment) if alignment else None,
            "saturation_fraction": statistics.fmean(float(abs(v) >= 0.9) for _, v, _ in values),
        }
    for name in ("rootmean_MSE", "z_MSE", "z_sign_accuracy", "displacement", "alignment"):
        values = [g[name] for g in report["groups"].values() if g[name] is not None]
        report["gameequal_" + name] = statistics.fmean(values) if values else None
    root_rows = [
        (prediction[i] - rows[i]["rootmean"]) ** 2
        for i in indices
        if rows[i]["rootmean"] is not None and math.isfinite(rows[i]["rootmean"])
    ]
    report["rowweighted_rootmean_MSE"] = statistics.fmean(root_rows) if root_rows else None
    report["saturation_threshold"] = 0.9
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    output = Path(args.output)
    output.mkdir(exist_ok=False)
    refs = bound_json(reg["reference_sets"])
    for key in ("Vraw", "Told"):
        if sha(refs[key]["path"]) != refs[key]["SHA"]:
            raise ValueError("fixed reference bytes changed")
    rawval, told = read_rows(refs["Vraw"]["path"]), read_rows(refs["Told"]["path"])
    parts = [told]
    for item in reg["runs"]:
        result = bound_json(item["result"])
        if result["status"] != "PASS" or result["future_labels_opened"]:
            raise ValueError("only stopped successful registered models allowed")
        path = Path(item["result"]["path"]).parent
        if sha(path / "train-used-references.jsonl.gz") != item["train_reference_SHA"]:
            raise ValueError("used train reference changed")
        parts.append(read_rows(path / "train-used-references.jsonl.gz"))
    tseen = merge_references(parts)
    finalmask = mask(rawval, tseen, label="final-all-saved-used-train-union")
    (output / "final-validation-mask.json").write_text(json.dumps(finalmask, indent=2) + "\n")
    for name, rows in (("Tseen_final", tseen), ("Vraw", rawval)):
        with gzip.open(output / (name + ".jsonl.gz"), "wt") as stream:
            for row in rows:
                stream.write(json.dumps(row, separators=(",", ":")) + "\n")
    summaries, candidates, baseline, fixed_order = [], [], None, None
    freezes = {}
    condition_order = list(CONDITIONS)
    for item in reg["runs"]:
        path = Path(item["result"]["path"]).parent
        result = bound_json(item["result"])
        condition = item["condition"]
        if condition in freezes:
            raise ValueError("duplicate condition would double count selected models")
        freezes[condition] = result["freeze"]
        order_path = path / "validation-prediction-order.json"
        if sha(order_path) != item["validation_order_SHA"]:
            raise ValueError("saved validation order changed")
        rows = json.loads(order_path.read_text())
        ids = [r["id"] for r in rows]
        if set(ids) != {r["id"] for r in rawval} or len(ids) != len(rawval):
            raise ValueError("every run must cover the same complete raw Vraw")
        if fixed_order is None:
            fixed_order = ids
        elif fixed_order != ids:
            raise ValueError("planned validation order differs; explicit mapping required")
        if result["freeze"]["initial_weights_sha"] != reg["initial_weights_SHA"]:
            raise ValueError("fresh conditions do not share registered initial weights")
        for step in CONDITIONS[condition][1]:
            prediction_path = path / f"validation-step{step}.f32"
            if sha(prediction_path) != item["prediction_SHA"][str(step)]:
                raise ValueError("saved planned prediction changed")
            prediction = floats(prediction_path, len(rows))
            if baseline is None:
                if step != 0:
                    raise ValueError("initial distance baseline missing")
                baseline = prediction
            elif step == 0 and prediction != baseline:
                raise ValueError("initial raw D predictions differ between fresh runs")
            metrics = {
                origin: measure(
                    rows, prediction, finalmask["rows"], origin=origin, baseline=baseline
                )
                for origin in ("old-fixed", "old-selection392", "new-v2")
            }
            point = {
                "condition": condition,
                "step": step,
                "training_seen": 128 * step,
                "full_run_training_seen": result["freeze"]["training_seen"],
                "metrics": metrics,
                "prediction_SHA": sha(prediction_path),
            }
            summaries.append(point)
            value = metrics["new-v2"]["gameequal_rootmean_MSE"]
            if value is not None:
                candidates.append(
                    (
                        value,
                        result["freeze"]["training_seen"],
                        condition_order.index(condition),
                        step,
                        path,
                        point,
                    )
                )
    if not candidates:
        raise ValueError("no eligible newselection groups; candidate selection UNKNOWN")
    workcontrol = "NOT_AVAILABLE"
    if {"stage2-256k", "stage2-512k"} <= freezes.keys():
        shorter, longer = freezes["stage2-256k"], freezes["stage2-512k"]
        if (
            shorter["dataset_sha"] != longer["dataset_sha"]
            or shorter["batch_prefix_sha256"]["2000"] != longer["batch_prefix_sha256"]["2000"]
        ):
            raise ValueError("work contrast has different dataset or first2000 batch order")
        workcontrol = "SAME_DATA_AND_FIRST2000_BATCH_PREFIX"
    chosen = min(candidates, key=lambda c: c[:4])
    _, _, _, step, path, point = chosen
    manifest = path / f"step{step}-model/manifest.json"
    checkpoint = path / f"step{step}.pt"
    weights = manifest.parent / "weights.f32"
    baseline_metrics = {
        "D_initial": {
            origin: measure(rows, baseline, finalmask["rows"], origin=origin, baseline=baseline)
            for origin in ("old-fixed", "old-selection392", "new-v2")
        }
    }
    if reg.get("saved_baselines"):
        baseline_reg = bound_json(reg["saved_baseline_registration"])
        baseline_order = bound_json(baseline_reg["validation_order"])
        if [row["id"] for row in baseline_order] != fixed_order:
            raise ValueError("saved baseline prediction order differs from final validation")
        saved = bound_json(reg["saved_baselines"])
        if saved["status"] != "PASS" or saved["future_labels_opened"]:
            raise ValueError("saved baseline evaluation incomplete")
        for name, record in saved["baselines"].items():
            if sha(record["predictions"]["path"]) != record["predictions"]["SHA"]:
                raise ValueError("saved baseline scalar predictions changed")
            prediction = floats(record["predictions"]["path"], len(rows))
            baseline_metrics[name] = {
                origin: measure(
                    rows, prediction, finalmask["rows"], origin=origin, baseline=baseline
                )
                for origin in ("old-fixed", "old-selection392", "new-v2")
            }
    (output / "all-finalmask-curves.json").write_text(json.dumps(summaries, indent=2) + "\n")
    selection = {
        "task": "frame23-learning-286-finalmask-selection",
        "schema": "finalmask-selection-v1",
        "modelNN": 0,
        "future_labels_opened": False,
        "candidate": point,
        "criterion": "minimum newselection gameequal rootmean MSE; tie full-run work then condition order then earlier step",
        "checkpoint": {"path": str(checkpoint), "SHA": sha(checkpoint)},
        "native_manifest": {"path": str(manifest), "SHA": sha(manifest)},
        "native_weights": {"path": str(weights), "SHA": sha(weights)},
        "finalmask": {
            "path": str(output / "final-validation-mask.json"),
            "SHA": sha(output / "final-validation-mask.json"),
        },
        "future_reference": "Tseen_final union ALL raw Vraw; reviewer target-free filter before sealed labels",
        "reference_sets": {
            name: {
                "path": str(output / (name + ".jsonl.gz")),
                "SHA": sha(output / (name + ".jsonl.gz")),
            }
            for name in ("Tseen_final", "Vraw")
        },
        "run_and_baseline_bindings": reg,
        "adoption_strength": "not established; selected validation is not independent evaluation",
        "history_crossformat": "UNVERIFIED",
        "baselines": baseline_metrics,
        "validation_D_better": point["metrics"]["new-v2"]["gameequal_rootmean_MSE"]
        < baseline_metrics["D_initial"]["new-v2"]["gameequal_rootmean_MSE"],
        "external_evaluation_not_skipped_if_D_unbeaten": True,
        "workcontrol": workcontrol,
    }
    (output / "selection.json").write_text(json.dumps(selection, indent=2) + "\n")
    print(
        json.dumps(
            {
                "selected": point["condition"],
                "step": step,
                "new_gameMSE": point["metrics"]["new-v2"]["gameequal_rootmean_MSE"],
            }
        )
    )


if __name__ == "__main__":
    main()
