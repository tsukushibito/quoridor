"""Losslessly compact stopped owner-generated bulky diagnostic JSON.

Curves, row prediction order, all weights and scalar predictions remain directly
readable. Original diagnostic bytes are verified through gzip before removing
only their redundant uncompressed copies. Inputs and other owners are untouched.
"""

import argparse
import gzip
import hashlib
import json
from pathlib import Path

NAMES = ("data.json", "exposure-masks.json", "gradients.json")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint_directory")
    args = parser.parse_args()
    directory = Path(args.checkpoint_directory).resolve()
    root = Path(
        "/workspaces/quoridor/.worktree/assets/checkpoints/frame23-independent-teacher-learning"
    )
    if directory.parent != root or not (directory / "result.json").exists():
        raise ValueError("only stopped successful current-task outputs may be compacted")
    result = json.loads((directory / "result.json").read_text())
    if result["status"] != "PASS" or result["future_labels_opened"]:
        raise ValueError("scientific output has not completed successfully")
    receipt = directory / "metadata-compression.json"
    if receipt.exists():
        raise ValueError("compression receipt already exists; no replacement")
    records = []
    for name in NAMES:
        source = directory / name
        target = directory / (name + ".gz")
        if target.exists():
            raise ValueError("existing compressed evidence is never overwritten")
        body = source.read_bytes()
        digest = hashlib.sha256(body).hexdigest()
        with target.open("xb") as stream:
            with gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as compressor:
                compressor.write(body)
        with gzip.open(target, "rb") as stream:
            restored = stream.read()
        if restored != body or hashlib.sha256(source.read_bytes()).hexdigest() != digest:
            raise ValueError("lossless byte restoration verification failed")
        records.append(
            {
                "member": name,
                "original_bytes": len(body),
                "original_SHA": digest,
                "compressed_path": str(target),
                "compressed_bytes": target.stat().st_size,
                "compressed_SHA": hashlib.sha256(target.read_bytes()).hexdigest(),
                "roundtrip_exact": True,
            }
        )
        source.unlink()
    receipt.write_text(
        json.dumps(
            {
                "source_stopped": True,
                "NN": 0,
                "members": records,
                "scientific_numbers_changed": False,
            },
            indent=2,
        )
        + "\n"
    )
    print(
        json.dumps(
            {
                "original_bytes": sum(r["original_bytes"] for r in records),
                "retained_bytes": sum(r["compressed_bytes"] for r in records),
            }
        )
    )


if __name__ == "__main__":
    main()
