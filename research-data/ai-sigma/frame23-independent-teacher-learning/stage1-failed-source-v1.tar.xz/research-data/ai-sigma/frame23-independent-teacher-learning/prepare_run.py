"""Bind actual stopped inputs and sample formula before a model job is started.

This is a NumPy-only preparation entry. It never imports Torch or a model, never
fits statistics, never opens sealed paths, and writes no dense cache copy.
"""

import argparse
import copy
import json
from pathlib import Path
import time

from inputs import bound_json, combined_inputs, sha
from planning import CONDITIONS, sample_formula, validate_config


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("specification")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    specification = Path(args.specification)
    spec = json.loads(specification.read_text())
    out = Path(args.output)
    out.mkdir(exist_ok=False)
    started = time.monotonic()
    import numpy as np

    reg = copy.deepcopy(spec)
    task = reg["task"]
    steps, points = CONDITIONS[task]
    reg.update(steps=steps, points=list(points))
    data, canonical = combined_inputs(reg["dataset"])
    binding, rows, _, _, labels = data
    tr = [
        i
        for i, r in enumerate(rows)
        if r["split"] == "train" and r["primary_eligible"] and np.isfinite(labels[i, 0])
    ]
    va = [
        i
        for i, r in enumerate(rows)
        if r["split"] == "validation" and r["primary_eligible"] and np.isfinite(labels[i, 0])
    ]
    formula = sample_formula(task, len(tr), len(va))
    metadata_rows = 5901 + len(rows)
    reg["sample_upper"] = formula["total_NN"]
    reg["processed_upper"] = formula["total_NN"] + metadata_rows
    reg["actual_bound"] = {
        "train_rows": len(tr),
        "evaluation_val_rows": len(va),
        "fit_NN": formula["train_NN"] + formula["evaluation_NN"],
        "metadata_tensor_rows": metadata_rows,
    }
    config = bound_json(reg["baseline_config"])
    config["training"]["steps"] = steps
    config["limits"] = {"seconds": 110, "samples": reg["actual_bound"]["fit_NN"]}
    validate_config(config, reg)
    config_path = out / "config.json"
    config_path.write_text(json.dumps(config, indent=2) + "\n")
    reg["config"] = str(config_path.resolve())
    eligible_ids = {rows[i]["id"] for i in tr}
    candidates = [r for r in canonical if r["id"] in eligible_ids]
    old_ids = {r["id"] for r in rows if r["data_origin"] == "old-fixed" and r["split"] == "train"}
    witnesses = []
    for origin in ("old", "new"):
        for side in (1, 2):
            chosen = sorted(
                [
                    r["id"]
                    for r in candidates
                    if r["side"] == side and (r["id"] in old_ids) == (origin == "old")
                ]
            )[:6]
            if len(chosen) != 6:
                raise ValueError("six target-blind old/new witnesses per side unavailable")
            witnesses.extend(chosen)
    reg["witness_ids"] = witnesses
    reg["return_pairs"] = [[witnesses[first], witnesses[first + 1]] for first in (0, 6, 12, 18)]
    reg["input_SHA"][str(config_path.resolve())] = sha(config_path)
    reg["input_SHA"][str(specification.resolve())] = sha(specification)
    (out / "registration.json").write_text(json.dumps(reg, indent=2) + "\n")
    summary = {
        "task": "frame23-learning-286-input-preparation",
        "schema": "learning-input-preparation-v1",
        "model_NN": 0,
        "Torch_imported": False,
        "labels": "train/selection only",
        "formula": formula,
        "processed_before_model": metadata_rows,
        "dataset_SHA": binding["dataset_sha"],
        "actual_bound": reg["actual_bound"],
        "actual_train_families": len({rows[i]["group"] for i in tr}),
        "scope_witness_rule": "first six lexicographic eligible IDs per old/new and P1/P2, target magnitude unused",
        "masks": binding["masks"],
        "wall_s": time.monotonic() - started,
        "registration_SHA": sha(out / "registration.json"),
        "complete_labels_before_fit": True,
        "future_labels_opened": False,
    }
    (out / "input-preparation.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(
        json.dumps({"formula": formula, "rows": reg["actual_bound"], "wall_s": summary["wall_s"]})
    )


if __name__ == "__main__":
    main()
