"""Small fake-data checks; no real labels, frameworks or model forward."""

import copy
import struct
import unittest

from exposure import (
    PUBLIC_FIELDS,
    canonical_input,
    mask,
    nested_masks,
    public_reference,
    validate_rows,
)
from planning import sample_formula


def row(name, split="train", side=1):
    return {
        "id": name,
        "group": name + "-family",
        "split": split,
        "side": side,
        "ids": [[1, 82, 301], [2, 83, 302]],
        "distance": [0.1, 0.2],
        "state_key": name + "-state",
        "history_key": name + "-history",
        "primary_eligible": True,
    }


class ExposureTest(unittest.TestCase):
    def test_side_swap_same_network_input(self):
        a, b = row("a"), row("b", side=2)
        b["ids"] = b["ids"][::-1]
        self.assertEqual(canonical_input(a), canonical_input(b))

    def test_f32_not_json(self):
        a, b = row("a"), row("b")
        b["distance"][0] = 0.1000000001
        self.assertEqual(canonical_input(a), canonical_input(b))

    def test_target_unused(self):
        a, b = row("a"), row("b")
        b.update(rootmean=-1, z=1, loss=500)
        self.assertEqual(canonical_input(a), canonical_input(b))

    def test_or_not_and(self):
        a, b = row("a"), row("b", "validation")
        b["ids"] = [[3, 84], [4, 85]]
        b["state_key"] = a["state_key"]
        m = mask([a], [b], label="test")
        self.assertFalse(m["rows"]["a"]["eligible"])
        self.assertEqual(
            m["matches"], {"state": 1, "history_literal": 0, "actual_input": 0, "OR": 1}
        )

    def test_zeroeligible_retained(self):
        m = mask([row("a")], [row("b", "validation")], label="test")
        self.assertEqual((m["planned_groups"], m["zeroeligible_groups"]), (1, 1))

    def test_family_crossing_rejected(self):
        a, b = row("a"), row("b", "validation")
        b["group"] = a["group"]
        with self.assertRaises(ValueError):
            validate_rows([a, b])

    def test_test_partition_rejected(self):
        with self.assertRaises(ValueError):
            validate_rows([row("sealed", "test")])

    def test_duplicate_id_rejected(self):
        a = row("a")
        with self.assertRaises(ValueError):
            validate_rows([a, copy.deepcopy(a)])

    def test_non_circular_priority(self):
        old, val, new, selection = (
            row("old"),
            row("v", "validation"),
            row("new"),
            row("s", "validation"),
        )
        old["ids"] = [[6], [7]]
        val["ids"] = [[8], [9]]
        result = nested_masks([old], [val], [new], [selection])
        self.assertFalse(result["new_train"]["rows"]["new"]["eligible"])
        self.assertTrue(result["validation"]["rows"]["s"]["eligible"])

    def test_projection_stm_not_rotated_twice(self):
        a, b = row("a"), row("b", side=2)
        b["ids_order"] = "STM_then_opponent"
        self.assertEqual(canonical_input(a), canonical_input(b))

    def test_raw_old_selection_masks_train(self):
        old, val, new, selection = (
            row("old"),
            row("v", "validation"),
            row("new"),
            row("s", "validation"),
        )
        old["ids"] = [[6], [7]]
        selection["ids"] = [[8], [9]]
        result = nested_masks([old], [val], [new], [selection])
        self.assertFalse(result["new_train"]["rows"]["new"]["eligible"])

    def test_validation_against_old_seen(self):
        old, val, new, selection = (
            row("old"),
            row("v", "validation"),
            row("new"),
            row("s", "validation"),
        )
        val["ids"] = [[8], [9]]
        new["ids"] = [[6], [7]]
        result = nested_masks([old], [val], [new], [selection])
        self.assertFalse(result["validation"]["rows"]["s"]["eligible"])

    def test_history_literal_only(self):
        a, b = row("a"), row("b", "validation")
        b["ids"] = [[5], [6]]
        b["history_key"] = a["history_key"]
        self.assertEqual(mask([a], [b], label="test")["matches"]["history_literal"], 1)

    def test_public_projection_rejects_label(self):
        public = dict.fromkeys(PUBLIC_FIELDS)
        public["rootmean"] = 0.5
        with self.assertRaises(ValueError):
            public_reference(public, native_run_id="v2")

    def test_public_projection_f32_and_p2(self):
        public = dict.fromkeys(PUBLIC_FIELDS)
        public.update(
            id="r",
            canonical_family="g",
            partition="train",
            side=2,
            actualSTM_ids=[[1, 82, 301], [2, 83, 302]],
            ids_order="STM_then_opponent",
            STM_distance_f32bits=list(struct.unpack("<II", struct.pack("<ff", 0.1, 0.2))),
            distance_order="STM_then_opponent_f32_le",
            state_key="s",
            history_key="h",
            native_family_alias="native-g",
            history_key_format="declared-format",
            producer_schema="quoridor-teacher-v1",
            producer_source_SHA="a" * 64,
            input_signature="b" * 64,
            prefix=[3],
        )
        got = public_reference(public, native_run_id="v2")
        self.assertEqual(canonical_input(got), canonical_input(row("a")))
        public["partition"] = "selection"
        self.assertEqual(public_reference(public, native_run_id="v2")["split"], "validation")
        public["partition"] = "sealed_futureevaluation"
        with self.assertRaises(ValueError):
            public_reference(public, native_run_id="v2")

    def test_actual_sample_denominators(self):
        got = sample_formula("stage1-256k", 10000, 1640 + 1720)
        self.assertEqual(got["total_NN"], 256000 + 10 * 13360 + 288)

    def test_work_samples_and_all13_points(self):
        got = sample_formula("stage2-512k", 30000, 3360)
        self.assertEqual(got["total_NN"], 512000 + 13 * 33360 + 288)

    def test_unknown_rows_cannot_be_forecast_pass(self):
        with self.assertRaises(ValueError):
            sample_formula("stage1-256k", 0, 3360)


if __name__ == "__main__":
    unittest.main()
