"""One registered fresh fit using the maintained D-holding QF1 trainer.

Invoke only inside the admitted science family. No model is imported by --help.
All evaluation snapshots are prospective; final mask aggregation is separate.
"""

import argparse
from functools import partial
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

os.environ["ORT_DISABLE_TELEMETRY"] = "1"

from inputs import bound_json, combined_inputs, sha
from planning import sample_formula, validate_config


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration")
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    for path, digest in reg["input_SHA"].items():
        if sha(path) != digest:
            raise ValueError("bound input changed: " + path)
    if reg["task"] not in ("stage1-256k", "stage2-256k", "stage2-512k"):
        raise ValueError("unregistered learning condition")
    output = Path(reg["output"])
    if output.exists():
        raise ValueError("previous success/failure output must not be replaced")
    validate_config(json.loads(Path(reg["config"]).read_text()), reg)
    import numpy as np
    import torch
    from quoridor_training.residual_model import DistanceResidualModel
    from quoridor_training.route_training import detailed_metrics, export_residual
    from quoridor_training.train import train, write

    combined, canonical = combined_inputs(reg["dataset"])
    binding, rows, x, d, labels = combined
    stats = bound_json(reg["fixed_scale"])
    route_stats = json.loads(
        Path(reg["dataset"]["old_inputs"]["route_cache"]).joinpath("cache.json").read_text()
    )["route_statistics"]
    eligible_train = [
        i
        for i, r in enumerate(rows)
        if r["split"] == "train" and r["primary_eligible"] and np.isfinite(labels[i, 0])
    ]
    eligible_val = [
        i
        for i, r in enumerate(rows)
        if r["split"] == "validation" and r["primary_eligible"] and np.isfinite(labels[i, 0])
    ]
    expected = reg["actual_bound"]
    if (
        len(eligible_train) != expected["train_rows"]
        or len(eligible_val) != expected["evaluation_val_rows"]
    ):
        raise ValueError("actual row denominator differs from preregistered formula")
    sample_fit = reg["steps"] * 128 + len(reg["points"]) * (len(eligible_train) + len(eligible_val))
    if sample_fit != expected["fit_NN"]:
        raise ValueError("evaluation/training sample formula differs")
    formula = sample_formula(reg["task"], len(eligible_train), len(eligible_val))
    if formula["total_NN"] != reg["sample_upper"]:
        raise ValueError("registered science upper differs from actual formula")
    metadata_tensor_rows = 5901 + 7621 + len(rows) - 7621
    if expected["metadata_tensor_rows"] != metadata_tensor_rows:
        raise ValueError("cache metadata/tensor verification denominator differs")
    initial_checked = False

    def build(config, statistics):
        nonlocal initial_checked
        model = DistanceResidualModel(
            config, statistics, a=0, b=8, routes=False, route_statistics=route_stats
        )
        vector = np.concatenate(
            [
                p.detach().cpu().numpy().astype("<f4").reshape(-1)
                for p in (
                    model.ft.weight,
                    model.ft.bias,
                    model.h.weight,
                    model.h.bias,
                    model.out.weight,
                    model.out.bias,
                )
            ]
        )
        if hashlib.sha256(vector.tobytes()).hexdigest() != reg["initial_native_weights_SHA"]:
            raise ValueError("same initial native weights not preserved")
        if (
            torch.count_nonzero(model.out.weight).item()
            or torch.count_nonzero(model.out.bias).item()
        ):
            raise ValueError("D-holding head is not zero")
        initial_checked = True
        return model

    def measure(mrows, prediction, target, constant):
        result = detailed_metrics(mrows, prediction, target, constant)
        if mrows[0]["split"] == "validation":
            for origin in ("old-fixed", "old-selection392", "new-v2"):
                keep = [i for i, r in enumerate(mrows) if r["data_origin"] == origin]
                result[origin] = (
                    detailed_metrics([mrows[i] for i in keep], prediction[keep], target, constant)
                    if keep
                    else None
                )
            result["raw_all_selection_diagnostic_mse"] = result["target_game_equal_mse"]
            # This is a provisional old-validation BEST only. Final candidate is
            # selected from all saved steps against the largest final new mask.
            result["target_game_equal_mse"] = result["old-fixed"]["target_game_equal_mse"]
            result["checkpoint_selection_scope"] = "provisional oldval; not final candidate"
        return result

    def observe(step, trows, trainpred, vrows, valpred):
        if step == 0:
            ref = torch.tanh(torch.from_numpy(np.float32(8) * (d[:, 1] - d[:, 0]))).numpy()
            by_id = {r["id"]: ref[i] for i, r in enumerate(rows)}
            if any(
                np.float32(p).view("u4") != np.float32(by_id[r["id"]]).view("u4")
                for r, p in zip(trows + vrows, np.concatenate([trainpred, valpred]))
            ):
                raise ValueError("initial D forward bit parity differs")
            write(output / "validation-prediction-order.json", vrows)
            write(output / "exposure-masks.json", binding["masks"])
            used_ids = {r["id"] for r in trows}
            reference_fields = (
                "id",
                "group",
                "split",
                "side",
                "ids",
                "distance",
                "state_key",
                "history_key",
                "history_key_format",
            )
            with gzip.open(output / "train-used-references.jsonl.gz", "wt") as stream:
                for row in canonical:
                    if row["id"] in used_ids:
                        ref = {key: row.get(key) for key in reference_fields}
                        ref["history_key_format"] = row.get(
                            "history_key_format", "UNVERIFIED-old-format"
                        )
                        ref["primary_eligible"] = True
                        stream.write(json.dumps(ref, separators=(",", ":")) + "\n")
            with gzip.open(output / "validation-raw-references.jsonl.gz", "wt") as stream:
                for row in canonical:
                    if row["split"] == "validation":
                        ref = {key: row.get(key) for key in reference_fields}
                        ref["history_key_format"] = row.get(
                            "history_key_format", "UNVERIFIED-old-format"
                        )
                        ref["primary_eligible"] = True
                        stream.write(json.dumps(ref, separators=(",", ":")) + "\n")
            write(
                output / "used-reference-semantics.json",
                {
                    "train_reference": "all eligible inputs actually passed to this run's fit/statistics/full train-evaluation; conservative superset of gradient-sampled rows",
                    "actual_sampling_counts": "sampling.json records each family's sample count and row exposure min/max/zero",
                    "saved_runs_union_required": True,
                    "labels_in_reference_file": False,
                    "dataset_SHA": binding["dataset_sha"],
                },
            )
        np.asarray(valpred, dtype="<f4").tofile(output / f"validation-step{step}.f32")

    freeze = train(
        reg["dataset"],
        output,
        reg["config"],
        cache_loader=lambda _: combined,
        model_builder=build,
        model_export=partial(export_residual, route_mode="zero4", route_statistics=route_stats),
        export_onnx=False,
        evaluation_points=reg["points"],
        measure=measure,
        objective=None,
        checkpoint_steps=reg["points"],
        evaluation_observer=observe,
        distance_fit_override={"a": 0, "b": 8},
        statistics_override=stats,
    )
    if (
        not initial_checked
        or freeze["samples"] != sample_fit
        or freeze["training_seen"] != reg["steps"] * 128
    ):
        raise ValueError("initial/actual sample ledger differs")
    by_id = {r["id"]: i for i, r in enumerate(rows)}
    witness = reg["witness_ids"]
    if len(witness) != 24 or len(set(witness)) != 24:
        raise ValueError("fixed 24 old/new witnesses required")
    chosen = [by_id[r] for r in witness]
    meta_by_id = {r["id"]: r for r in canonical}
    native_rows = []
    for row_id in witness:
        row = dict(meta_by_id[row_id])
        row["id"] = row_id
        native_rows.append(row)
    source = "".join(json.dumps(r, separators=(",", ":")) + "\n" for r in native_rows)
    parity = []
    return_parity = []
    cfg = json.loads((output / "config.json").read_text())
    # No fresh random initialization is an extra learning condition: weights
    # are replaced from saved checkpoints before these charged parity forwards.
    model = DistanceResidualModel(
        cfg["model"], stats, a=0, b=8, routes=False, route_statistics=route_stats
    )
    for step in (0, 200, reg["steps"]):
        checkpoint = torch.load(output / f"step{step}.pt", map_location="cpu", weights_only=True)
        model.load_state_dict(checkpoint["model"])
        model.eval()
        with torch.inference_mode():
            pred = model(
                torch.from_numpy(x[chosen]),
                torch.from_numpy(d[chosen]),
                torch.ones(24, dtype=torch.long),
            ).numpy()
        native = subprocess.run(
            [reg["native_binary"], "model", str(output / f"step{step}-model/manifest.json")],
            input=source,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if native.returncode:
            raise RuntimeError("native parity child failed: " + native.stderr[:1000])
        values = [json.loads(line) for line in native.stdout.splitlines()]
        if [r["id"] for r in values] != witness:
            raise ValueError("native witness order differs")
        if any(abs(r["value"] - r["delta_value"]) > 1e-6 + 1e-6 * abs(r["value"]) for r in values):
            raise ValueError("native full/delta numeric parity")
        errors = [abs(float(p) - r["value"]) for p, r in zip(pred, values)]
        if any(e > 1e-6 + 1e-6 * abs(float(p)) for e, p in zip(errors, pred)):
            raise ValueError("Torch/native numeric parity")
        parity.append(
            {"step": step, "max_abs": max(errors), "native": values, "Torch": pred.tolist()}
        )
        # Fixed feature A->B->A accumulator returns. This is not board/RuleA
        # make-unmake;12full+12delta native evaluations per checkpoint are charged.
        return_rows = []
        for a, b in reg["return_pairs"]:
            for row_id in (a, b, a):
                row = dict(meta_by_id[row_id])
                row["id"] = row_id
                return_rows.append(row)
        if len(return_rows) != 12:
            raise ValueError("four fixed accumulator return pairs required")
        returned = subprocess.run(
            [reg["native_binary"], "model", str(output / f"step{step}-model/manifest.json")],
            input="".join(json.dumps(r) + "\n" for r in return_rows),
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        values_return = [json.loads(line) for line in returned.stdout.splitlines()]
        if returned.returncode or len(values_return) != 12:
            raise ValueError("native accumulator return child failed")
        if [r["id"] for r in values_return] != [r["id"] for r in return_rows]:
            raise ValueError("accumulator return IDs differ")
        for first in range(0, 12, 3):
            before, after = values_return[first], values_return[first + 2]
            if any(
                abs(before[key] - after[key]) > 1e-6 + 1e-6 * abs(before[key])
                for key in ("value", "delta_value")
            ):
                raise ValueError("native accumulator return not restored")
        return_parity.append({"step": step, "rows": values_return})
    write(
        output / "parity.json",
        {
            "reports": parity,
            "witness_ids": witness,
            "additional_Torch_NN": 72,
            "native_NN": 216,
            "return_pairs": return_parity,
            "return_scope": "input accumulator only; no RuleA board undo claim",
        },
    )
    write(
        output / "result.json",
        {
            "task": "frame23-learning-286-" + reg["task"],
            "schema": "independent-teacher-learning-v1",
            "status": "PASS",
            "fit_NN": sample_fit,
            "parity_NN": 288,
            "total_NN": sample_fit + 288,
            "processed": sample_fit + 288 + metadata_tensor_rows,
            "processed_definition": "charged model NN equivalents plus actual cache-metadata tensor correspondence rows; OR mask arithmetic is separately recorded preparation",
            "metadata_tensor_rows": metadata_tensor_rows,
            "actual_train_rows": len(eligible_train),
            "actual_validation_rows": len(eligible_val),
            "future_labels_opened": False,
            "final_selection": "pending final largest mask aggregation",
            "freeze": freeze,
            "registration_SHA": sha(args.registration),
        },
    )
    print(json.dumps({"task": reg["task"], "status": "PASS", "total_NN": sample_fit + 288}))


if __name__ == "__main__":
    main()
