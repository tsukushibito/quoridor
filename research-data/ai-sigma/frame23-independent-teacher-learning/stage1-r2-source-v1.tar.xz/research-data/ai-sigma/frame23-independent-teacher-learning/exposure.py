"""Label-independent QF1 exposure rules for the registered v2 partitions.

This module does not import numerical frameworks or open any dataset. Callers
must first bind the producer's immutable, train/selection-only allowlist.
"""

import hashlib
import math
import struct

PUBLIC_FIELDS = {
    "id",
    "canonical_family",
    "native_family_alias",
    "partition",
    "side",
    "ply",
    "cohort",
    "state_key",
    "history_key",
    "history_key_format",
    "actualSTM_ids",
    "ids_order",
    "STM_distance_f32bits",
    "distance_order",
    "input_signature",
    "prefix",
    "producer_schema",
    "producer_source_SHA",
}


def public_reference(row, *, native_run_id):
    """Strict producer target-free projection; no label-container inference."""
    if set(row) != PUBLIC_FIELDS:
        raise ValueError("public projection missing/extra field; labels are forbidden")
    if row["partition"] not in ("train", "selection"):
        raise ValueError("sealed/future projection is outside this learner interface")
    text_fields = (
        "id",
        "canonical_family",
        "native_family_alias",
        "state_key",
        "history_key",
        "history_key_format",
        "producer_schema",
        "producer_source_SHA",
        "input_signature",
    )
    if any(not isinstance(row[k], str) or not row[k] for k in text_fields):
        raise ValueError("public reference identity/source fields missing")
    if not isinstance(row["prefix"], list) or any(
        type(a) is not int or not 0 <= a <= 208 for a in row["prefix"]
    ):
        raise ValueError("literal action prefix required; no inferred history")
    if (
        row["ids_order"] != "STM_then_opponent"
        or row["distance_order"] != "STM_then_opponent_f32_le"
    ):
        raise ValueError("actual STM projection input order")
    bits = row["STM_distance_f32bits"]
    if len(bits) != 2 or any(type(v) is not int or not 0 <= v < 2**32 for v in bits):
        raise ValueError("two literal little-endian f32 bits required")
    out = {
        "id": native_run_id + ":" + row["id"],
        "group": row["canonical_family"],
        "split": "validation" if row["partition"] == "selection" else "train",
        "side": row["side"],
        "ids": row["actualSTM_ids"],
        "ids_order": row["ids_order"],
        "distance": list(struct.unpack("<ff", struct.pack("<II", *bits))),
        "state_key": row["state_key"],
        "history_key": row["history_key"],
        "history_key_format": row["history_key_format"],
        "primary_eligible": True,
    }
    canonical_input(out)
    return out


def canonical_input(row):
    """P1/P2 sparse IDs become STM/opponent; distances are already STM f32."""
    if row.get("side") not in (1, 2):
        raise ValueError("P1/P2 side required")
    ids = row.get("ids")
    distance = row.get("distance")
    if not isinstance(ids, list) or len(ids) != 2 or len(distance or []) != 2:
        raise ValueError("QF1 two views and raw distance2 required")
    for view in ids:
        if (
            not view
            or any(type(v) is not int or not 0 <= v < 312 for v in view)
            or view != sorted(set(view))
        ):
            raise ValueError("sorted unique QF1 active IDs required")
    if any(type(v) not in (int, float) or not math.isfinite(v) for v in distance):
        raise ValueError("finite raw distances required")
    order = row.get("ids_order", "P1_then_P2")
    if order == "P1_then_P2":
        side = row["side"] - 1
        ordered = (ids[side], ids[1 - side])
    elif order == "STM_then_opponent":
        ordered = ids
    else:
        raise ValueError("explicit input view order unsupported")
    body = b"QF1-f32-STM-v1\0"
    for view in ordered:
        body += struct.pack("<H", len(view)) + struct.pack("<" + "H" * len(view), *view)
    body += struct.pack("<ff", *distance)
    return hashlib.sha256(body).hexdigest()


def validate_rows(rows):
    ids, groups = set(), {}
    for row in rows:
        if row.get("split") not in ("train", "validation"):
            raise ValueError("sealed test/future evaluation not accepted")
        if not row.get("id") or row["id"] in ids or not row.get("group"):
            raise ValueError("missing/duplicate row ID or family")
        ids.add(row["id"])
        previous = groups.setdefault(row["group"], row["split"])
        if previous != row["split"]:
            raise ValueError("family crosses partitions")
        if not row.get("state_key") or not row.get("history_key"):
            raise ValueError("missing state/history literal; no invented history")
        canonical_input(row)
    return groups


def index(rows):
    validate_rows(rows)
    return {
        "state": {r["state_key"] for r in rows},
        "history_literal": {r["history_key"] for r in rows},
        "actual_input": {canonical_input(r) for r in rows},
    }


def mask(query, reference, *, label):
    """All planned rows/families remain in denominators, including zero eligible."""
    validate_rows(query)
    validate_rows(reference)
    if {r["id"] for r in query} & {r["id"] for r in reference}:
        raise ValueError("query/reference row identity overlaps")
    if {r["group"] for r in query} & {r["group"] for r in reference}:
        raise ValueError("query/reference family overlaps")
    lookup = index(reference)
    marked, groups = {}, {}
    counts = {k: 0 for k in lookup} | {"OR": 0}
    for row in query:
        hits = {
            "state": row["state_key"] in lookup["state"],
            "history_literal": row["history_key"] in lookup["history_literal"],
            "actual_input": canonical_input(row) in lookup["actual_input"],
        }
        exposed = any(hits.values())
        for kind, hit in hits.items():
            counts[kind] += int(hit)
        counts["OR"] += int(exposed)
        eligible = bool(row.get("primary_eligible", True) and not exposed)
        marked[row["id"]] = {"eligible": eligible, "matches": hits}
        group = groups.setdefault(row["group"], {"planned": 0, "eligible": 0})
        group["planned"] += 1
        group["eligible"] += int(eligible)
    return {
        "label": label,
        "predicate": "state OR history_literal OR actual QF1 STM f32 input",
        "labels_used": False,
        "history_cross_format": "UNVERIFIED; literal comparisons only",
        "rows": marked,
        "groups": groups,
        "planned_rows": len(query),
        "eligible_rows": sum(r["eligible"] for r in marked.values()),
        "planned_groups": len(groups),
        "zeroeligible_groups": sum(g["eligible"] == 0 for g in groups.values()),
        "matches": counts,
    }


def nested_masks(old_train, old_val, new_train, new_val):
    """Raw all-val masks new train; old all-train + used-train union masks val.

    old_val includes old fixed1248 and previously selected392. new_train is the
    union of eligible inputs used by the saved runs, not an assumed largest-run
    equivalent. No filtered validation ever becomes the training reference.
    """
    validate_rows(old_train + old_val + new_train + new_val)
    new_train_mask = mask(new_train, old_val + new_val, label="new-train-fixed-val")
    eligible_new = [r for r in new_train if new_train_mask["rows"][r["id"]]["eligible"]]
    final_val = mask(
        old_val + new_val, old_train + eligible_new, label="all-raw-validation-used-train-union"
    )
    return {"new_train": new_train_mask, "validation": final_val}
