"""Result-independent conditions and sample accounting; no data labels opened."""

POINTS = (0, 1, 5, 20, 50, 100, 200, 400, 1000, 2000)
CONDITIONS = {
    "stage1-256k": (2000, POINTS),
    "stage2-256k": (2000, POINTS),
    "stage2-512k": (4000, POINTS + (2500, 3000, 4000)),
}


def validate_config(config, registration):
    steps, points = CONDITIONS[registration["task"]]
    if registration["steps"] != steps or registration["points"] != list(points):
        raise ValueError("registered condition/curve points differ")
    required = {
        "model": {
            "feature_version": "QF1",
            "transformer_width": 32,
            "hidden_width": 32,
            "dropout": 0,
        },
        "optimizer": {"name": "adam", "lr": 0.0001, "weight_decay": 0},
        "training": {
            "steps": steps,
            "batch_size": 128,
            "seed": 19080311,
            "target": "rootmean",
            "sampling": "game",
            "scheduler": "none",
            "device": "cpu",
            "threads": 1,
        },
        "evaluation": {"early_stopping_patience": 0, "min_delta": 0},
    }
    for section, fields in required.items():
        if any(config[section].get(key) != value for key, value in fields.items()):
            raise ValueError("fixed method changed: " + section)
    if not 0 < config["limits"]["seconds"] <= 120:
        raise ValueError("individual fit time exceeds contract")


def sample_formula(name, train_rows, validation_rows, parity=288):
    if (
        type(train_rows) is not int
        or type(validation_rows) is not int
        or min(train_rows, validation_rows) <= 0
    ):
        raise ValueError("positive actual row denominators required")
    steps, points = CONDITIONS[name]
    training = steps * 128
    evaluation = len(points) * (train_rows + validation_rows)
    return {
        "train_NN": training,
        "evaluation_NN": evaluation,
        "parity_NN": parity,
        "total_NN": training + evaluation + parity,
    }
