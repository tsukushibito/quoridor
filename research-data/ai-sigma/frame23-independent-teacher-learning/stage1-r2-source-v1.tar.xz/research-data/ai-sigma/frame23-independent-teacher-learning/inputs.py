"""Immutable train/selection-only input adapter for the maintained trainer.

No framework import at module load. The private run interface binds advertised
cache manifests, canonical family aliases and a complete registered prefix.
Future-evaluation paths are never part of this interface.
"""

import gzip
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

from exposure import canonical_input, nested_masks, public_reference, validate_rows


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound_json(item):
    if sha(item["path"]) != item["SHA"]:
        raise ValueError("immutable manifest changed: " + item["path"])
    return json.loads(Path(item["path"]).read_text())


def read_canonical(path):
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt") as stream:
        rows = [json.loads(line) for line in stream]
    validate_rows(rows)
    return rows


def check_tensor_metadata(metadata, x, d):
    """Compare actual forward STM input to P1/P2 metadata, without labels."""
    import numpy as np

    if len(metadata) != len(x) or x.shape[1:] != (2, 312) or d.shape[1] < 2:
        raise ValueError("metadata/tensor dimensions")
    for row, features, distances in zip(metadata, x, d):
        side = row["side"] - 1
        expected = [row["ids"][side], row["ids"][1 - side]]
        if (
            not np.isin(features, [0, 1]).all()
            or expected != [np.flatnonzero(view).tolist() for view in features]
            or np.asarray(row["distance"], dtype="<f4").tobytes()
            != np.asarray(distances[:2], dtype="<f4").tobytes()
        ):
            raise ValueError("actual STM f32 tensor differs: " + row["id"])
        canonical_input(row)


def old_inputs(spec):
    """The original 4653 + canonical 273 train1328; old val remains fixed."""
    import numpy as np
    from quoridor_training.route_training import (
        append_train_inputs,
        extra_train_inputs,
        load_route_cache,
        read_input_metadata,
        select_cache_partition,
    )
    from quoridor_training.cache import load

    if sha(Path(spec["route_cache"]) / "cache.json") != spec["route_manifest_SHA"]:
        raise ValueError("old route cache manifest changed")
    route = load_route_cache(spec["route_cache"])
    binding, rows, x, d, _ = route
    canonical = []
    for split in ("train", "validation"):
        canonical.extend(read_canonical(binding["sources"][split]["path"]))
    if [r["id"] for r in canonical] != [r["id"] for r in rows]:
        raise ValueError("old route canonical order")
    check_tensor_metadata(canonical, x, d)
    extra, metadata = extra_train_inputs(SimpleNamespace(**spec["extra_args"]))
    extra_ordered = [metadata[r["id"]] for r in extra[1]]
    combined = append_train_inputs(
        route, extra, [r for r in canonical if r["split"] == "validation"], metadata
    )
    canonical.extend(extra_ordered)
    if len(combined[1]) != 7229:
        raise ValueError("old base must be 5981 train + 1248 fixed val")
    # Previously selected273 validation392 belongs to Vraw too. It never enters
    # fit/statistics; adding it to evaluation does not refit baseline B.
    selection = select_cache_partition(load(spec["extra_args"]["extra_train_cache"]), "validation")
    _, sel_rows, sx, sd, sy = selection
    selection_metadata = {
        r["id"]: r
        for r in read_input_metadata(spec["extra_args"]["extra_train_metadata"])
        if r["split"] == "validation"
    }
    if len(sel_rows) != 392 or set(selection_metadata) != {r["id"] for r in sel_rows}:
        raise ValueError("fixed old selection392 metadata differs")
    canonical.extend(selection_metadata[r["id"]] for r in sel_rows)
    combined = (
        combined[0] | {"old_selection_binding": selection[0]},
        combined[1] + sel_rows,
        np.concatenate([combined[2], sx]),
        np.concatenate([combined[3], np.column_stack([sd, np.zeros((392, 4), dtype=np.float32)])]),
        np.concatenate([combined[4], sy]),
    )
    check_tensor_metadata(canonical, combined[2], combined[3])
    enriched = []
    for meta, row in zip(canonical, combined[1]):
        enriched.append(meta | {"primary_eligible": row["primary_eligible"]})
    return combined, enriched


def producer_inputs(spec, registered):
    """Only explicitly stopped, advertised cache partitions; no glob loading."""
    import numpy as np
    from quoridor_training.cache import load
    from quoridor_training.route_training import read_input_metadata

    xs, ds, ys, all_rows, all_meta, bindings = [], [], [], [], [], []
    allowed = {
        r["canonical_family"]: r
        for r in registered["families"]
        if r["split_purpose"] in ("train", "selection")
    }
    for item in spec:
        if item["partition"] not in ("train", "validation"):
            raise ValueError("future-evaluation cache forbidden")
        manifest = bound_json({"path": str(Path(item["path"]) / "cache.json"), "SHA": item["SHA"]})
        if manifest.get("allow_test") is not False:
            raise ValueError("advertised cache has no train/selection-only policy")
        # Producer must advertise the shard as train/selection-only *before* any
        # labels are loaded. The manifest alone is not a partition certificate.
        if not item.get("producer_stop_SHA") or not item.get("producer_only_train_selection"):
            raise ValueError("producer stopped partition allowlist missing")
        binding, rows, x, d, y = load(item["path"])
        metadata = read_input_metadata(Path(item["path"]) / "rows.jsonl")
        orders = {
            "metadata_schema": "quoridor-tensor-row-v2",
            "ids_order": "P1_then_P2",
            "distance_order": "STM_then_opponent_f32",
            "tensor_view_order": "STM_then_opponent",
        }
        if any(any(r.get(k) != v for k, v in orders.items()) for r in metadata):
            raise ValueError("new producer schema/view order differs from bound v2")
        if [r["id"] for r in metadata] != [r["id"] for r in rows]:
            raise ValueError("cache metadata row order differs")
        check_tensor_metadata(metadata, x, d)
        for row, meta in zip(rows, metadata):
            if row["split"] != item["partition"]:
                raise ValueError("advertised partition differs from row")
            native_group = row["group"]
            canonical_group = item["group_aliases"].get(native_group)
            if canonical_group not in allowed:
                raise ValueError("unknown/sealed/v1 canonical family")
            family = allowed[canonical_group]
            expected = "train" if family["split_purpose"] == "train" else "validation"
            if expected != row["split"] or family["native_family"] != native_group:
                raise ValueError("v2 immutable split/native alias differs")
            # Native game-local IDs repeat across blocks. Namespace each once;
            # keep its native ID for the native witness's exact correspondence.
            native_id = row["id"]
            canonical_id = family["native_run_id"] + ":" + native_id
            row = dict(row)
            row.update(id=canonical_id, native_id=native_id, group=canonical_group)
            meta = dict(meta)
            meta.update(id=canonical_id, native_id=native_id, group=canonical_group)
            meta["cohort"] = family["cohort"]
            all_rows.append(row)
            all_meta.append(meta)
        xs.append(x)
        ds.append(np.column_stack([d, np.zeros((len(rows), 4), dtype=np.float32)]))
        ys.append(y)
        bindings.append(binding)
        if item.get("public_metadata"):
            public_item = item["public_metadata"]
            if sha(public_item["path"]) != public_item["SHA"]:
                raise ValueError("public target-free projection changed")
            with Path(public_item["path"]).open() as stream:
                projected = [json.loads(line) for line in stream]
            public_map = {}
            for public_row in projected:
                family = allowed.get(public_row["canonical_family"])
                expected_public_partition = (
                    "selection" if item["partition"] == "validation" else "train"
                )
                if not family or public_row["partition"] != expected_public_partition:
                    raise ValueError("projection family/partition differs")
                normalized = public_reference(public_row, native_run_id=family["native_run_id"])
                if normalized["id"] in public_map:
                    raise ValueError("duplicate projection row")
                public_map[normalized["id"]] = normalized
            private = all_meta[-len(rows) :]
            if set(public_map) != {r["id"] for r in private}:
                raise ValueError("public/private row coverage differs")
            for private_row in private:
                public_row = public_map[private_row["id"]]
                if canonical_input(public_row) != canonical_input(private_row) or any(
                    public_row[k] != private_row[k] for k in ("group", "state_key", "history_key")
                ):
                    raise ValueError("public target-free/cache input correspondence differs")
                private_row["history_key_format"] = public_row["history_key_format"]
    if not all_rows:
        raise ValueError("producer immutable complete prefix not yet available")
    validate_rows(all_meta)
    return bindings, all_rows, np.concatenate(xs), np.concatenate(ds), np.concatenate(ys), all_meta


def combined_inputs(registration):
    """Build a fixed eligible train and complete raw selection evaluation view."""
    import numpy as np

    registered = bound_json(registration["family_map"])
    if registered["namespace"] != "frame23-285-v2":
        raise ValueError("v1 or unregistered domain is forbidden")
    base, old_meta = old_inputs(registration["old_inputs"])
    bindings, rows, x, d, y, meta = producer_inputs(registration["producer_caches"], registered)
    requested = registration["train_prefix_groups"]
    if len(requested) != len(set(requested)) or len(requested) % 48:
        raise ValueError("complete registered 48-family train blocks required")
    train_available = {r["group"] for r in rows if r["split"] == "train"}
    if set(requested) != train_available:
        raise ValueError("actual train does not match immutable complete prefix")
    planned = [
        r["canonical_family"] for r in registered["families"] if r["split_purpose"] == "train"
    ]
    if requested != planned[: len(requested)]:
        raise ValueError("non-prefix family selection forbidden")
    old_train = [r for r in old_meta if r["split"] == "train"]
    old_val = [r for r in old_meta if r["split"] == "validation"]
    new_train = [r for r in meta if r["split"] == "train"]
    new_val = [r for r in meta if r["split"] == "validation"]
    if len({r["group"] for r in new_val}) != 48:
        raise ValueError("fixed all48 selection groups must be advertised")
    masks = nested_masks(old_train, old_val, new_train, new_val)
    for row, metadata in zip(rows, meta):
        row.update(cohort=metadata.get("cohort", "v2-opening"), ply=metadata["ply"])
        if row["split"] == "train":
            row["primary_eligible"] = masks["new_train"]["rows"][row["id"]]["eligible"]
        else:
            # Save all qualified raw selection predictions in planned forwards;
            # the final exposure mask is applied during arithmetic aggregation.
            row["primary_eligible"] = bool(metadata.get("primary_eligible", True))
    binding = {
        "old": base[0],
        "producer": bindings,
        "family_map_SHA": registration["family_map"]["SHA"],
        "train_prefix": requested,
        "masks": masks,
        "final_mask": registration["final_mask"],
        "labels_opened": "train/selection only; future labels never opened",
    }
    binding["dataset_sha"] = hashlib.sha256(
        json.dumps(binding, sort_keys=True).encode()
    ).hexdigest()
    result = (
        binding,
        base[1] + rows,
        np.concatenate([base[2], x]),
        np.concatenate([base[3], d]),
        np.concatenate([base[4], y]),
    )
    for row in result[1]:
        row["data_origin"] = (
            "new-v2"
            if row["id"].startswith("frame23-285-v2-")
            else (
                "old-selection392"
                if row["group"].startswith("frame22-273") and row["split"] == "validation"
                else "old-fixed"
            )
        )
    return result, old_meta + meta
