"""Freeze explicit target-free Vraw/Told references before model selection.

This NumPy-only preparation accepts the train/selection allowlist, not future
label containers. It never fits statistics or evaluates a model.
"""

import argparse
import gzip
import json
from pathlib import Path

from inputs import combined_inputs, sha

FIELDS = (
    "id",
    "group",
    "split",
    "side",
    "ids",
    "ids_order",
    "distance",
    "state_key",
    "history_key",
    "history_key_format",
)


def reference(row):
    value = {key: row.get(key) for key in FIELDS}
    value["ids_order"] = row.get("ids_order", "P1_then_P2")
    value["history_key_format"] = row.get("history_key_format", "UNVERIFIED-old-format")
    value["primary_eligible"] = bool(row.get("primary_eligible", True))
    return value


def save_rows(path, rows):
    with gzip.open(path, "wt") as stream:
        for row in rows:
            stream.write(json.dumps(reference(row), separators=(",", ":")) + "\n")
    return {
        "path": str(path.resolve()),
        "SHA": sha(path),
        "rows": len(rows),
        "families": len({r["group"] for r in rows}),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    output = Path(args.output)
    output.mkdir(exist_ok=False)
    combined, canonical = combined_inputs(reg["dataset"])
    binding, rows, *_ = combined
    by_id = {r["id"]: r for r in rows}
    raw_val = [r for r in canonical if r["split"] == "validation"]
    old_train = [
        r for r in canonical if r["split"] == "train" and not r["id"].startswith("frame23-285-v2-")
    ]
    new_train = [
        r
        for r in canonical
        if r["split"] == "train"
        and r["id"].startswith("frame23-285-v2-")
        and by_id[r["id"]]["primary_eligible"]
    ]
    if len(old_train) != 5981:
        raise ValueError("Told must preserve all original 5981 train inputs")
    result = {
        "task": "frame23-learning-286-reference-freeze",
        "schema": "learning-reference-sets-v1",
        "Vraw": save_rows(output / "Vraw.jsonl.gz", raw_val),
        "Told": save_rows(output / "Told.jsonl.gz", old_train),
        "stage_eligible_train": save_rows(output / "new-train-eligible.jsonl.gz", new_train),
        "dataset_SHA": binding["dataset_sha"],
        "modelNN": 0,
        "predicate": "state literal OR history literal OR actual STM f32 input",
        "history_crossformat": "UNVERIFIED; no fullhistory nonexposure claim",
        "Tseen_final": "pending explicit union of all saved run train references plus Told",
        "future_reference": "Tseen_final plus ALL raw Vraw; no future labels opened",
    }
    (output / "reference-sets.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("Vraw", "Told", "stage_eligible_train")}))


if __name__ == "__main__":
    main()
