"""Single-core science guardian with fresh binding and a cumulative ledger.

Process/binding inspection is reused readonly from the producer guardian. This
entry never imports a numerical framework and never automatically retries.
"""

import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import time


def load_helpers(path):
    spec = importlib.util.spec_from_file_location("producer_process_helpers", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def scientific_process(helper, process):
    if helper.science(process):
        return True
    argv = process.get("argv", [])
    if not argv or not Path(argv[0]).name.startswith("python"):
        return False
    script = next((a for a in argv[1:] if not a.startswith("-")), "")
    # Saved arithmetic/metadata jobs also consume a physical slot. Operational
    # helpers are excluded by their separate scripts/dev allocation, not by role
    # active/idle counts. Unclassified research-data Python is conservatively busy.
    return "/research-data/" in script


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration")
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    helper = load_helpers(reg["process_helpers"])
    os.sched_setaffinity(0, {1})
    scope = Path(reg["scope"])
    run_id = reg.get("run_id", reg["task"])
    out = scope / (run_id + "-management")
    out.mkdir(exist_ok=False)
    ledger_path = scope / "science-ledger.json"
    ledger = helper.read(ledger_path) if ledger_path.exists() else []
    previous_attempts = [r for r in ledger if r.get("spawned")]
    prior_condition = [r for r in previous_attempts if r.get("condition", r["task"]) == reg["task"]]
    if reg["kind"] == "fit" and prior_condition:
        # One explicit prospective exception: coordinator allocated r2 after
        # r1 failed at output.mkdir before its first evaluation or train step.
        # The failed entry/reservation stays in this same cumulative ledger.
        repair = reg.get("checkpoint_parent_repair_authority")
        permitted = (
            reg["task"] == "stage1-256k"
            and run_id == "stage1-256k-r2"
            and len(prior_condition) == 1
            and prior_condition[0]["task"] == "stage1-256k"
            and prior_condition[0].get("exit") == 1
            and repair
            and helper.sha(repair["path"]) == repair["SHA"]
        )
        if not permitted:
            raise ValueError("one fit per condition; no supplemental fit/retry")
    if any(r["task"] == run_id for r in previous_attempts):
        raise ValueError("registered run already consumed; second repair is forbidden")
    charge = sum(r.get("actual_NN", r["reserved_NN"]) for r in previous_attempts)
    if len(previous_attempts) >= 5 or charge + reg["sample_upper"] > 3000000:
        raise ValueError("cumulative MAX5 / NN budget refusal")
    if (
        sum(r.get("actual_processed", r["reserved_processed"]) for r in previous_attempts)
        + reg["processed_upper"]
        > 3100000
    ):
        raise ValueError("cumulative processed budget refusal")
    if (
        sum(r.get("wall_s", r["hard_seconds"]) for r in previous_attempts) + reg["hard_seconds"]
        > 1800
    ):
        raise ValueError("cumulative science time refusal")
    if not 0 < reg["hard_seconds"] <= (120 if reg["kind"] == "fit" else 180):
        raise ValueError("individual job budget refusal")
    record = {
        "task": run_id,
        "condition": reg["task"],
        "spawned": False,
        "reserved_NN": reg["sample_upper"],
        "hard_seconds": reg["hard_seconds"],
        "reserved_processed": reg["processed_upper"],
    }
    child, recorded, peak, reason = None, {}, 0, None
    began = time.monotonic()
    try:
        for path, digest in reg["input_SHA"].items():
            if helper.sha(path) != digest:
                raise ValueError("registered source/input changed: " + path)
        binding = helper.binding(reg)
        for issue in ("quoridor-4lc", "quoridor-4lc.286"):
            command = subprocess.run(
                ["bash", "/workspaces/quoridor/scripts/dev/beads.sh", "show", issue, "--json"],
                capture_output=True,
                text=True,
                timeout=20,
                check=True,
            )
            value = json.loads(command.stdout)[0]
            if value["status"] not in ("open", "in_progress") or any(
                "pause" in label for label in value.get("labels", [])
            ):
                raise ValueError("owner/pause authority refusal")
            if (
                issue.endswith(".286")
                and value["assignee"] != "codex:01a0f31c-2e4b-7170-82c5-69e1428c2418"
            ):
                raise ValueError("different actual owner")
        point = helper.snapshot()
        own = helper.ancestors(os.getpid(), point)
        foreign = [p for p in point if scientific_process(helper, p) and p["pid"] not in own]
        if foreign:
            raise ValueError("foreign science not stopped: " + json.dumps(foreign))
        memory = next(
            int(line.split()[1]) * 1024
            for line in Path("/proc/meminfo").read_text().splitlines()
            if line.startswith("MemAvailable:")
        )
        rss = sum(p["rss"] for p in point if scientific_process(helper, p))
        if memory < 2 * 1024**3 or rss + 1879048192 + 1024**3 > 8 * 1024**3:
            raise ValueError("fresh RAM/headroom refusal")
        storage = helper.read(reg["storage_evidence"]["path"])
        if (
            helper.sha(reg["storage_evidence"]["path"]) != reg["storage_evidence"]["SHA"]
            or storage.get("admission") != "within"
            or storage.get("errors")
        ):
            raise ValueError("storage fresh forecast refusal")
        if not reg["storage_learning64_present"]:
            raise ValueError("64MiB learner allocation not bound")
        if datetime.now(timezone.utc) >= datetime.fromisoformat(
            reg["end_at"].replace("Z", "+00:00")
        ):
            raise ValueError("science deadline reached")
        helper.write(
            out / "admission.json",
            {
                "at": datetime.now(timezone.utc).isoformat(),
                "binding": binding,
                "current_foreign": foreign,
                "current_RSS": rss,
                "MemAvailable": memory,
                "storage_evidence": reg["storage_evidence"],
                "CPU": [1],
                "GPU": 0,
                "owner_checked": True,
                "point_only": True,
            },
        )
        environment = dict(
            os.environ,
            ORT_DISABLE_TELEMETRY="1",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
            PYTHONPATH=reg["python_path"],
        )
        with (out / "command.log").open("wb") as log:
            child = subprocess.Popen(
                reg["argv"],
                cwd=reg["cwd"],
                env=environment,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            identity = helper.proc(child.pid)
            if identity is None:
                raise ValueError("started child identity unavailable")
            record.update(
                spawned=True,
                state="RUNNING",
                identity=identity,
                actualstart=datetime.now(timezone.utc).isoformat(),
            )
            ledger.append(record)
            helper.write(ledger_path, ledger)
            helper.write(
                out / "start.json", record | {"argv": reg["argv"], "current_ancestors": sorted(own)}
            )
            start, previous, last_binding = time.monotonic(), {p["pid"]: p for p in point}, 0.0
            while child.poll() is None:
                point = helper.snapshot()
                own_group = {child.pid, os.getpid()}
                for _ in range(20):
                    added = {p["pid"] for p in point if p["ppid"] in own_group} - own_group
                    if not added:
                        break
                    own_group |= added
                family = [p for p in point if p["pid"] in own_group or p["pgrp"] == child.pid]
                if any(p["cpus"] != [1] for p in family):
                    reason = "CPU_AFFINITY_CHANGED"
                recorded.update(
                    {(p["pid"], p["start_ticks"]): p for p in family if p["pid"] != os.getpid()}
                )
                peak = max(peak, sum(p["rss"] for p in family))
                if peak > 1879048192:
                    reason = "RAM_GUARD"
                if time.monotonic() - start >= reg["hard_seconds"]:
                    reason = "TIME_GUARD"
                if any(
                    scientific_process(helper, p)
                    and p["pid"] not in own | own_group
                    and p["cpu_ticks"] > previous.get(p["pid"], {}).get("cpu_ticks", -1)
                    for p in point
                ):
                    reason = "FOREIGN_COMPUTE_STARTED"
                if datetime.now(timezone.utc) >= datetime.fromisoformat(
                    reg["end_at"].replace("Z", "+00:00")
                ):
                    reason = "DEADLINE"
                if time.monotonic() - last_binding > 5:
                    helper.binding(reg)
                    last_binding = time.monotonic()
                if reason:
                    break
                previous = {p["pid"]: p for p in point}
                time.sleep(0.1)
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
            child.wait()
            record.update(exit=child.returncode, wall_s=time.monotonic() - start, reason=reason)
        result = helper.read(reg["expected_output"])
        if result["task"] != reg["expected_task"] or result["schema"] != reg["expected_schema"]:
            raise ValueError("exit/output task identity mismatch")
        if result["total_NN"] > reg["sample_upper"]:
            raise ValueError("actual NN over registered budget")
        record["actual_NN"] = result["total_NN"]
        if result["processed"] > reg["processed_upper"]:
            raise ValueError("actual processed exceeds registered upper")
        record["actual_processed"] = result["processed"]
    except Exception as error:
        record["error"] = str(error)
        if child and child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        if child:
            record.update(exit=child.returncode, wall_s=time.monotonic() - began)
    finally:
        remaining = [p for p in recorded.values() if helper.exact(p)]
        record.update(
            state="STOPPED" if child else "NOT_STARTED",
            waited=child is not None,
            current_exact_remaining=remaining,
            peak_family_RSS=peak,
            stopped_at=datetime.now(timezone.utc).isoformat(),
        )
        if not record["spawned"]:
            ledger.append(record)
        helper.write(out / "stop.json", record)
        helper.write(ledger_path, ledger)
        print(json.dumps(record))
    if record.get("error") or record.get("exit") != 0 or reason or remaining:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
