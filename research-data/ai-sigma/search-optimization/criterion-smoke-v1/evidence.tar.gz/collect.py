"""Read standard Criterion evidence without executing models or new statistics."""

import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text())


def main():
    plan = read(OUT / "plan.json")
    control = read(OUT / "runtime/result.json")
    qualification = read(OUT / "qualification.json")
    assert len(qualification) == 5
    logs = {
        name: (OUT / f"{name}.log").read_text()
        for name in ["smoke", "canonical-a0", "canonical-a1"]
    }
    assert logs["smoke"].count("\nSuccess\n") == 30
    for raw in logs.values():
        rows = [json.loads(line) for line in raw.splitlines() if line.startswith("{")]
        assert [r for r in rows if r.get("kind") == "qualification"] == qualification
    # Four cold depth3, one cold target, two warm target searches per root in
    # each startup, with two extra head calls. --test runs every body once:
    # the same search multiplicities, plus one head call per root.
    setup_per_process = sum(
        4 * r["cold"]["counters"][1]
        + r["target_cold"]["counters"][1]
        + 2 * r["target_warm"]["counters"][1]
        + 2
        for r in qualification
    )
    smoke_bodies = setup_per_process - 5
    measured_work = 0
    startup_delta = sum(
        4 * r["cold"]["counters"][21]
        + r["target_cold"]["counters"][21]
        + 2 * r["target_warm"]["counters"][21]
        for r in qualification
    )
    statistical_delta = 0
    timings = []
    initial_evaluations = qualification[0]["cold"]["counters"][1]
    for directory, bench_id, multiplier in [
        ("nnue_evaluate_initial", "nnue/evaluate/initial", 1),
        (
            "search_cold_setup_search_drop_initial",
            "search/cold_setup_search_drop/initial",
            initial_evaluations,
        ),
    ]:
        home = OUT / "criterion" / directory
        iterations = {}
        estimates = {}
        for run, subdirectory in [
            ("canonical-a0", "canonical-a0"),
            ("canonical-a1", "new"),
        ]:
            sample = read(home / subdirectory / "sample.json")
            assert len(sample["iters"]) == len(sample["times"]) == 50
            assert all(n > 0 and n.is_integer() for n in sample["iters"])
            measurements = int(sum(sample["iters"]))
            pattern = (
                rf"Benchmarking {re.escape(bench_id)}: Warming up.*?"
                r"Completed (\d+) iterations"
            )
            matches = re.findall(pattern, logs[run], flags=re.DOTALL)
            assert len(matches) == 1
            warmup = int(matches[0])
            iterations[run] = {
                "warmup": warmup,
                "measurement": measurements,
                "head_calls_per_iteration": multiplier,
                "head_calls": (warmup + measurements) * multiplier,
                "sampling_mode": sample["sampling_mode"],
                "samples": 50,
            }
            measured_work += (warmup + measurements) * multiplier
            if multiplier != 1:
                statistical_delta += (warmup + measurements) * qualification[0]["cold"][
                    "counters"
                ][21]
            est = read(home / subdirectory / "estimates.json")
            estimator = "slope" if est.get("slope") else "mean"
            estimates[run] = {
                "displayed_estimator": estimator,
                "estimate_ns": est[estimator],
            }
        timings.append(
            {
                "benchmark": bench_id,
                "absolute": estimates,
                "iterations": iterations,
                "relative_standard_Criterion_mean": read(
                    home / "change/estimates.json"
                )["mean"],
                "interpretation": (
                    "No change in performance detected (Criterion printed p=0.25)"
                    if multiplier == 1
                    else "Change within noise threshold; confidence interval crosses +1% threshold. Printed p=0.00 is rounded, not exact zero."
                ),
            }
        )
    summary = {
        "job_id": control["job_id"],
        "result": "PASS_LIMITED CLI/standard statistics and deterministic startup semantics",
        "CLI_ids_passed": 30,
        "startup_qualified_roots": 5,
        "startup_repetitions": 3,
        "typed_results": "head valuebits, Action/PV/depth/stop/all23 work counters/parent-history and retained memory exact",
        "model": plan["manifest"],
        "weights_SHA256": plan["weights_SHA256"],
        "binary_SHA256": plan["binary_SHA256"],
        "timings": timings,
        "head_forward_accounting": {
            "startup_per_process": setup_per_process,
            "startup_all3": setup_per_process * 3,
            "smoke_body_calls": smoke_bodies,
            "statistical_warmup_plus_measurement": measured_work,
            "total": setup_per_process * 3 + smoke_bodies + measured_work,
            "basis": "frozen driver multiplicities, exported preflight evaluations, Criterion warmup DEBUG iterations and exact sample.json iteration counts",
            "unexported_internal_neuron_operations": None,
        },
        "whole_job_seconds": control["wall_seconds"],
        "exported_delta_updates_accounting": {
            "startup_all3": startup_delta * 3,
            "smoke_bodies": startup_delta,
            "statistical_warmup_plus_measurement": statistical_delta,
            "total": startup_delta * 4 + statistical_delta,
            "basis": "driver multiplicities and preflight delta_updates counter; timed bodies uninstrumented",
            "internal_fullFT_feature_operations": None,
        },
        "statistical_method": plan["statistical_method"],
        "limits": plan["limits"],
        "scope": "head excludes precomputed fullFT; cold includes player/TT setup, normal rootFT preparation, search and table destruction. Models/replay/preflight outside samples, inside whole job",
        "interpretation": "same-binary sequential control only; cannot estimate candidate speed, causally attribute allocations/dispatch, certify stability or playing strength",
        "limitations": [
            "50 samples within each process are not 50 independent process runs",
            "two sequential processes only; five roots qualified, initial root timed",
            "each timed search body uses fresh TT; per-iteration full counters not instrumented",
            "substantial learner curve analysis stopped before entry; light text/source work may co-run",
            "head slope estimate and relative mean estimate differ; do not equate their ratios",
            "prior unfavorable optimization results, failures and UNKNOWN costs unchanged",
        ],
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")

    # Keep all original logs and standard raw sample/estimate files unchanged.
    def sha(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    files = [p for p in OUT.rglob("*") if p.is_file() and p.name != "artifact-SHA.json"]
    (OUT / "artifact-SHA.json").write_text(
        json.dumps({str(p.relative_to(OUT)): sha(p) for p in files}, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                "head_calls": summary["head_forward_accounting"],
                "whole_s": control["wall_seconds"],
            }
        )
    )


if __name__ == "__main__":
    main()
