"""Execute the frozen canonical Criterion smoke and two standard statistical runs."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def identity(pid):
    try:
        fields = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        return {"pid": pid, "start_ticks": fields[19], "boot_id": BOOT}
    except FileNotFoundError:
        return {"pid": pid, "start_ticks": None, "boot_id": BOOT}


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


def main():
    os.sched_setaffinity(0, {0, 1})
    plan = json.loads((OUT / "plan.json").read_text())
    for path, digest in plan["main_source"].items():
        assert sha(path) == digest, path
    assert sha(ROOT / "Cargo.lock") == plan["lock_SHA256"]
    assert sha(plan["binary"]) == plan["binary_SHA256"]
    assert sha(plan["manifest"]) == plan["manifest_SHA256"]
    manifest = json.loads(Path(plan["manifest"]).read_text())
    assert (
        sha(Path(plan["manifest"]).parent / manifest["weights"])
        == plan["weights_SHA256"]
    )
    env = dict(
        os.environ,
        QUORIDOR_BENCH_MANIFEST=plan["manifest"],
        CRITERION_HOME=str(OUT / "criterion"),
        CRITERION_DEBUG="1",
        CUDA_VISIBLE_DEVICES="",
        PYTHONDONTWRITEBYTECODE="1",
    )
    child = None
    cancelled = False

    def cancel(_signal, _frame):
        nonlocal cancelled
        cancelled = True
        if child is not None and child.poll() is None:
            child.terminate()

    signal.signal(signal.SIGTERM, cancel)
    signal.signal(signal.SIGINT, cancel)
    result = {"status": "RUNNING", "commands": [], "qualification": None}
    expected = None
    subset = "^(nnue/evaluate|search/cold_setup_search_drop)/initial$"
    commands = [
        ("smoke", ["--test"]),
        ("canonical-a0", ["--bench", subset, "--save-baseline", "canonical-a0"]),
        ("canonical-a1", ["--bench", subset, "--baseline", "canonical-a0"]),
    ]
    try:
        for name, args in commands:
            assert not cancelled, "explicit cancellation"
            argv = [plan["binary"], *args]
            receipt = {
                "argv": argv,
                "started": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "direct_child_reaped": False,
            }
            with (OUT / f"{name}.log").open("wb") as log:
                child = subprocess.Popen(
                    argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT
                )
                receipt["child"] = identity(child.pid)
                write(f"{name}.process.json", receipt)
                rc = child.wait()
            receipt.update(
                exit_code=rc,
                direct_child_reaped=True,
                ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            )
            write(f"{name}.process.json", receipt)
            child = None
            result["commands"].append(receipt)
            write("numeric-result.json", result)
            assert rc == 0 and not cancelled, f"{name} failed; no automatic repeat"
            rows = []
            for line in (OUT / f"{name}.log").read_text().splitlines():
                if line.startswith("{"):
                    row = json.loads(line)
                    if row.get("kind") == "qualification":
                        rows.append(row)
            assert len(rows) == 5, "five complete root qualifications required"
            if expected is None:
                expected = rows
                write("qualification.json", rows)
            assert rows == expected, "typed results or exported work changed"
            result["qualification"] = "all5 exact across completed processes"
            write("numeric-result.json", result)
        assert sha(plan["binary"]) == plan["binary_SHA256"]
        result["status"] = "COMPLETED"
        result["speed_adoption"] = "NOT_APPLICABLE same-binary control"
    except BaseException as exc:
        result["status"] = "FAILED"
        result["error"] = repr(exc)
        raise
    finally:
        if child is not None:
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    child.kill()
            child.wait()
        write("numeric-result.json", result)


if __name__ == "__main__":
    main()
