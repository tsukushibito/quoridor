"""Own the finite Criterion worker; enforce RAM/output, never a research time cap."""

import datetime
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
UTILITY = ROOT / ".artifacts/search-optimization/criterion-v1/guard-r6.py"
SPEC = importlib.util.spec_from_file_location("process_utility", UTILITY)
UTILITY_MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(UTILITY_MODULE)
proc = UTILITY_MODULE.proc
descendants = UTILITY_MODULE.descendants


def footprint():
    # Only this small, exclusively owned numerical namespace, never Cargo/target.
    total = 0
    for base, _, names in os.walk(OUT):
        for name in names:
            try:
                total += (Path(base) / name).stat().st_blocks * 512
            except FileNotFoundError:
                pass  # An atomic replacement in owned output; final receipt below.
    return total


def main():
    os.sched_setaffinity(0, {0, 1})
    assert footprint() < 524288
    interrupted = False

    def cancel(_signal, _frame):
        nonlocal interrupted
        interrupted = True

    signal.signal(signal.SIGTERM, cancel)
    signal.signal(signal.SIGINT, cancel)
    identities = {}
    peak_rss = peak_output = 0
    reason = None
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT / "worker.log").open("wb") as log:
        child = subprocess.Popen(
            [sys.executable, "-B", str(OUT / "worker.py")],
            cwd=ROOT,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        leader = proc(child.pid)
        if leader:
            identities[child.pid] = leader
        while child.poll() is None:
            owned = descendants(child.pid)
            identities.update(owned)
            own = proc(os.getpid())
            peak_rss = max(
                peak_rss,
                sum(p["rss"] for p in owned.values())
                + (own["rss"] if own else 0)
                + 64 * 1024**2,
            )
            peak_output = max(peak_output, footprint())
            if interrupted:
                reason = "explicit_owned_cancel"
            elif peak_rss > 2 * 1024**3:
                reason = "family_RSS"
            elif peak_output > 524288:
                reason = "owned_output_limit"
            if reason:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                break
            time.sleep(0.05)
        rc = child.wait()
    remaining = [
        value
        for pid, value in identities.items()
        if (actual := proc(pid)) and actual["tick"] == value["tick"]
    ]
    # Stop only recorded descendants of this job; no foreign ownership.
    for value in remaining:
        os.kill(value["pid"], signal.SIGTERM)
    if remaining:
        time.sleep(0.1)
    remaining = [
        value
        for pid, value in identities.items()
        if (actual := proc(pid)) and actual["tick"] == value["tick"]
    ]
    receipt = {
        "started": start,
        "ended": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "exit_code": rc,
        "reason": reason,
        "direct_child_reaped": True,
        "leader": leader,
        "identities": list(identities.values()),
        "remaining": remaining,
        "cleanup_complete": not remaining,
        "family_RSS_sampled_peak_including_controller_B": peak_rss,
        "owned_output_sampled_peak_B": peak_output,
        "owned_output_final_B": footprint(),
        "shared_target_growth_peak_B": None,
        "CPU": [0, 1],
        "GPU": 0,
        "max_runtime_seconds": None,
        "forward_cap": None,
        "scope": "only owned namespace footprint; no sharedtarget/registry inventory",
    }
    (OUT / "process.json").write_text(json.dumps(receipt, indent=2) + "\n")
    if rc or reason or remaining:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
