//! Native iterative deepening / PVS over the history-correct Sigma rule cursor.
//! No speculative pruning. A result is published only after a whole root depth.
use quoridor_core::{Position, RulesError, research::SigmaContext};
use quoridor_nnue::residual::{ResidualModel, ResidualScratch};
use quoridor_nnue::{Accumulator, EvaluationMode, Model, QuantizedAccumulator, QuantizedModel};
use std::{
    collections::hash_map::DefaultHasher,
    fmt,
    hash::{Hash, Hasher},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};

use crate::score::{ScoreDomain, TerminalOutcome};
use web_time::Instant;

pub const TERMINAL_SCORE: f32 = 2.0;
#[derive(Debug)]
pub enum SearchError {
    Limits(String),
    Root(String),
    Evaluation(String),
    Rules(RulesError),
}
impl fmt::Display for SearchError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Limits(s) => write!(f, "SEARCH_LIMITS: {s}"),
            Self::Root(s) => write!(f, "SEARCH_ROOT: {s}"),
            Self::Evaluation(s) => write!(f, "SEARCH_EVALUATION: {s}"),
            Self::Rules(e) => write!(f, "SEARCH_RULES: {e}"),
        }
    }
}
impl std::error::Error for SearchError {}
impl From<quoridor_nnue::Error> for SearchError {
    fn from(e: quoridor_nnue::Error) -> Self {
        Self::Evaluation(e.to_string())
    }
}
impl From<RulesError> for SearchError {
    fn from(e: RulesError) -> Self {
        Self::Rules(e)
    }
}
pub type Result<T> = std::result::Result<T, SearchError>;
#[derive(Debug, Clone)]
pub enum EvalAccumulator {
    Float(Accumulator),
    Quantized(QuantizedAccumulator),
    DistanceStep(quoridor_nnue::distance_step::StepAccumulator),
}
/// Owned by one search invocation, not by shared model weights or parents.
#[derive(Debug, Default)]
pub enum EvalScratch {
    #[default]
    None,
    Residual(ResidualScratch),
}
/// Immutable evaluators share weights; accumulator state belongs to one search.
/// Hooks support a cached per-child delta and exact rollback by retaining parent.
pub trait StaticEvaluator: Send + Sync {
    /// Optional setup-owned child storage, separate for every invocation.
    fn create_child_storage(&self, _slots: usize) -> Vec<Option<EvalAccumulator>> {
        Vec::new()
    }
    fn advance_move_context(
        &self,
        parent: Option<&EvalAccumulator>,
        context: &SigmaContext,
        _transition: &quoridor_core::research::ContextUndo,
        storage: &mut Option<EvalAccumulator>,
    ) -> Result<()> {
        *storage = self.advance_context(parent, context)?;
        Ok(())
    }
    fn create_scratch(&self) -> EvalScratch {
        EvalScratch::None
    }
    fn evaluate_with_scratch(
        &self,
        context: &SigmaContext,
        accumulator: Option<&EvalAccumulator>,
        _scratch: &mut EvalScratch,
    ) -> Result<f32> {
        self.evaluate(context, accumulator)
    }
    fn evaluate(
        &self,
        context: &SigmaContext,
        accumulator: Option<&EvalAccumulator>,
    ) -> Result<f32>;
    fn prepare_context(&self, context: &SigmaContext) -> Result<Option<EvalAccumulator>> {
        self.prepare(context.position())
    }
    fn advance_context(
        &self,
        parent: Option<&EvalAccumulator>,
        context: &SigmaContext,
    ) -> Result<Option<EvalAccumulator>> {
        self.advance(parent, context.position())
    }
    fn prepare(&self, _position: Position) -> Result<Option<EvalAccumulator>> {
        Ok(None)
    }
    fn advance(
        &self,
        _parent: Option<&EvalAccumulator>,
        position: Position,
    ) -> Result<Option<EvalAccumulator>> {
        self.prepare(position)
    }
}

/// Optional local policy/history ranking. Scores cover every legal action in
/// the supplied order; they affect ordering only and never exclude a move.
pub trait MoveOrderer: Send + Sync {
    fn scores(&self, context: &SigmaContext, legal: &[u16]) -> Result<Vec<f32>>;
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DistanceMode {
    Tanh,
    Clip,
}
#[derive(Debug, Clone, Copy)]
pub struct DistanceEvaluator {
    pub a: f32,
    pub b: f32,
    pub mode: DistanceMode,
}
impl DistanceEvaluator {
    pub fn new(a: f32, b: f32) -> Self {
        Self {
            a,
            b,
            mode: DistanceMode::Tanh,
        }
    }
    pub fn clipped(a: f32, b: f32) -> Self {
        Self {
            a,
            b,
            mode: DistanceMode::Clip,
        }
    }
}
impl StaticEvaluator for DistanceEvaluator {
    fn evaluate(&self, c: &SigmaContext, _a: Option<&EvalAccumulator>) -> Result<f32> {
        let p = c.position();
        let side = p.turn as usize;
        let d0 = (f64::from(
            p.wall_distance(side)
                .ok_or_else(|| SearchError::Evaluation("unreachable pawn".into()))?,
        ) / 80.) as f32;
        let d1 = (f64::from(
            p.wall_distance(side ^ 1)
                .ok_or_else(|| SearchError::Evaluation("unreachable pawn".into()))?,
        ) / 80.) as f32;
        let raw = self.a + self.b * (d1 - d0);
        if !raw.is_finite() {
            return Err(SearchError::Evaluation(
                "distance overflow or nonfinite coefficients".into(),
            ));
        }
        Ok(match self.mode {
            DistanceMode::Tanh => f64::from(raw).tanh() as f32,
            DistanceMode::Clip => raw.clamp(-1., 1.),
        })
    }
}
#[derive(Debug, Clone)]
pub struct NnueEvaluator {
    pub model: Arc<Model>,
    pub mode: EvaluationMode,
}
impl NnueEvaluator {
    pub fn new(model: Arc<Model>) -> Self {
        Self {
            model,
            mode: EvaluationMode::Scalar,
        }
    }
    pub fn with_mode(mut self, mode: EvaluationMode) -> Self {
        self.mode = mode;
        self
    }
}
impl StaticEvaluator for NnueEvaluator {
    fn prepare_context(&self, c: &SigmaContext) -> Result<Option<EvalAccumulator>> {
        Ok(Some(EvalAccumulator::Float(
            self.model.full_context(c, self.mode)?,
        )))
    }
    fn advance_context(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
    ) -> Result<Option<EvalAccumulator>> {
        match a {
            Some(EvalAccumulator::Float(a)) => Ok(Some(EvalAccumulator::Float(
                self.model.delta_context(a, c)?,
            ))),
            _ => self.prepare_context(c),
        }
    }

    fn prepare(&self, p: Position) -> Result<Option<EvalAccumulator>> {
        Ok(Some(EvalAccumulator::Float(
            self.model.full_mode(p, self.mode)?,
        )))
    }
    fn advance(&self, a: Option<&EvalAccumulator>, p: Position) -> Result<Option<EvalAccumulator>> {
        match a {
            Some(EvalAccumulator::Float(a)) => {
                Ok(Some(EvalAccumulator::Float(self.model.delta(a, p)?)))
            }
            _ => self.prepare(p),
        }
    }
    fn evaluate(&self, _c: &SigmaContext, a: Option<&EvalAccumulator>) -> Result<f32> {
        match a {
            Some(EvalAccumulator::Float(a)) => Ok(self.model.evaluate(a)?),
            _ => Err(SearchError::Evaluation("missing float accumulator".into())),
        }
    }
}
#[derive(Debug, Clone)]
pub struct ResidualEvaluator {
    pub model: Arc<ResidualModel>,
    /// FT accumulation mode. The residual head independently selects guarded
    /// runtime AVX2 or its ordered scalar fallback.
    pub mode: EvaluationMode,
}
impl ResidualEvaluator {
    pub fn new(model: Arc<ResidualModel>) -> Self {
        Self {
            model,
            mode: EvaluationMode::Scalar,
        }
    }
    pub fn with_mode(mut self, mode: EvaluationMode) -> Self {
        self.mode = mode;
        self
    }
}
impl StaticEvaluator for ResidualEvaluator {
    fn create_child_storage(&self, slots: usize) -> Vec<Option<EvalAccumulator>> {
        (0..slots)
            .map(|_| Some(EvalAccumulator::Float(self.model.child_buffer(self.mode))))
            .collect()
    }
    fn advance_move_context(
        &self,
        parent: Option<&EvalAccumulator>,
        context: &SigmaContext,
        transition: &quoridor_core::research::ContextUndo,
        storage: &mut Option<EvalAccumulator>,
    ) -> Result<()> {
        match (parent, storage.as_mut()) {
            (Some(EvalAccumulator::Float(parent)), Some(EvalAccumulator::Float(child))) => {
                self.model
                    .delta_move_into(parent, transition, context, child)?;
            }
            _ => *storage = self.advance_context(parent, context)?,
        }
        Ok(())
    }
    fn create_scratch(&self) -> EvalScratch {
        EvalScratch::Residual(self.model.evaluation_scratch())
    }
    fn evaluate_with_scratch(
        &self,
        _c: &SigmaContext,
        a: Option<&EvalAccumulator>,
        scratch: &mut EvalScratch,
    ) -> Result<f32> {
        let Some(EvalAccumulator::Float(a)) = a else {
            return Err(SearchError::Evaluation(
                "missing residual accumulator".into(),
            ));
        };
        let EvalScratch::Residual(scratch) = scratch else {
            return Err(SearchError::Evaluation("missing residual scratch".into()));
        };
        Ok(self.model.evaluate_with_scratch(a, scratch)?)
    }
    fn prepare_context(&self, c: &SigmaContext) -> Result<Option<EvalAccumulator>> {
        Ok(Some(EvalAccumulator::Float(
            self.model.full_context(c, self.mode)?,
        )))
    }
    fn advance_context(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
    ) -> Result<Option<EvalAccumulator>> {
        match a {
            Some(EvalAccumulator::Float(a)) => Ok(Some(EvalAccumulator::Float(
                self.model.delta_context(a, c)?,
            ))),
            _ => self.prepare_context(c),
        }
    }

    fn prepare(&self, p: Position) -> Result<Option<EvalAccumulator>> {
        Ok(Some(EvalAccumulator::Float(
            self.model.full_mode(p, self.mode)?,
        )))
    }
    fn advance(&self, a: Option<&EvalAccumulator>, p: Position) -> Result<Option<EvalAccumulator>> {
        match a {
            Some(EvalAccumulator::Float(a)) => {
                Ok(Some(EvalAccumulator::Float(self.model.delta(a, p)?)))
            }
            _ => self.prepare(p),
        }
    }
    fn evaluate(&self, _c: &SigmaContext, a: Option<&EvalAccumulator>) -> Result<f32> {
        match a {
            Some(EvalAccumulator::Float(a)) => Ok(self.model.evaluate(a)?),
            _ => Err(SearchError::Evaluation(
                "missing residual accumulator".into(),
            )),
        }
    }
}
#[derive(Debug, Clone)]
pub struct QuantizedEvaluator {
    pub model: Arc<QuantizedModel>,
}
impl QuantizedEvaluator {
    pub fn new(model: Arc<QuantizedModel>) -> Self {
        Self { model }
    }
}
impl StaticEvaluator for QuantizedEvaluator {
    fn prepare_context(&self, c: &SigmaContext) -> Result<Option<EvalAccumulator>> {
        Ok(Some(EvalAccumulator::Quantized(
            self.model.full_context(c)?,
        )))
    }
    fn advance_context(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
    ) -> Result<Option<EvalAccumulator>> {
        match a {
            Some(EvalAccumulator::Quantized(a)) => Ok(Some(EvalAccumulator::Quantized(
                self.model.delta_context(a, c)?,
            ))),
            _ => self.prepare_context(c),
        }
    }

    fn prepare(&self, p: Position) -> Result<Option<EvalAccumulator>> {
        Ok(Some(EvalAccumulator::Quantized(self.model.full(p)?)))
    }
    fn advance(&self, a: Option<&EvalAccumulator>, p: Position) -> Result<Option<EvalAccumulator>> {
        match a {
            Some(EvalAccumulator::Quantized(a)) => {
                Ok(Some(EvalAccumulator::Quantized(self.model.delta(a, p)?)))
            }
            _ => self.prepare(p),
        }
    }
    fn evaluate(&self, _c: &SigmaContext, a: Option<&EvalAccumulator>) -> Result<f32> {
        match a {
            Some(EvalAccumulator::Quantized(a)) => Ok(self.model.evaluate(a)?),
            _ => Err(SearchError::Evaluation(
                "missing integer accumulator".into(),
            )),
        }
    }
}
#[derive(Debug, Clone)]
pub struct SearchLimits {
    pub max_depth: u16,
    pub max_nodes: u64,
    pub time_limit: Option<Duration>,
    pub tt_entries: usize,
    pub use_pvs: bool,
    pub use_tt: bool,
}
impl Default for SearchLimits {
    fn default() -> Self {
        Self {
            max_depth: 64,
            max_nodes: 1_000_000,
            time_limit: Some(Duration::from_millis(500)),
            tt_entries: 16384,
            use_pvs: true,
            use_tt: true,
        }
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StopReason {
    DepthComplete,
    Terminal,
    NodeLimit,
    TimeLimit,
    Cancelled,
}
#[derive(Debug, Default, Clone)]
pub struct SearchStats {
    pub nodes: u64,
    pub evaluations: u64,
    pub terminal: u64,
    pub cutoffs: u64,
    pub tt_hits: u64,
    pub tt_probes: u64,
    pub tt_exact_hits: u64,
    pub tt_key_builds: u64,
    pub tt_history_items: u64,
    pub tt_key_history_capacity_bytes: u64,
    pub tt_hashes: u64,
    pub tt_usable_depth: u64,
    pub tt_order_only: u64,
    pub tt_collisions: u64,
    pub tt_replacements: u64,
    pub tt_capacity_skips: u64,
    pub tt_illegal_moves: u64,
    pub tt_retained_bytes: usize,
    pub tt_generation: u64,
    pub tt_cutoffs: u64,
    pub pvs_researches: u64,
    pub delta_updates: u64,
    pub policy_calls: u64,
}
#[derive(Debug, Clone)]
pub struct SearchResult {
    pub action: Option<u16>,
    pub value: Option<f32>,
    pub completed_depth: u16,
    pub pv: Vec<u16>,
    pub stats: SearchStats,
    pub stop: StopReason,
    pub elapsed: Duration,
}

// Verify full state on hash hits, including all repetition counts and total ply.
// Position-only keys/hashes are insufficient for the repetition exclusion rule.
type CountedHistoryEntry = ([u8; 2], [u8; 2], u8, u64, u64, u16);

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct Key {
    ruleset: quoridor_core::research::Ruleset,
    pawns: [u8; 2],
    walls: [u8; 2],
    horizontal: u64,
    vertical: u64,
    turn: u8,
    winner: Option<u8>,
    ply: u16,
    synthetic: bool,
    history: Vec<CountedHistoryEntry>,
}
impl Key {
    fn of(c: &SigmaContext) -> Self {
        let p = c.position();
        Self {
            ruleset: c.ruleset(),
            pawns: p.pawns,
            walls: p.walls_remaining,
            horizontal: p.horizontal,
            vertical: p.vertical,
            turn: p.turn,
            winner: p.winner,
            ply: c.total_ply(),
            synthetic: c.is_synthetic(),
            history: c
                .history_counts()
                .into_iter()
                .map(|(k, n)| (k.pawns, k.stocks, k.turn, k.horizontal, k.vertical, n))
                .collect(),
        }
    }
    fn hash(&self) -> u64 {
        let mut h = DefaultHasher::new();
        Hash::hash(self, &mut h);
        h.finish()
    }
}
#[derive(Debug, Clone, Copy)]
enum Bound {
    Exact,
    Lower,
    Upper,
}
struct Entry {
    generation: u64,
    key: Key,
    depth: u16,
    value: f32,
    bound: Bound,
    best: Option<u16>,
}
// Invocation-owned proof that this exact immutable key was hashed by probe.
// Never stored in the table/session, and never detached from its owned key.
type ProbeHit = (u16, f32, Bound, Option<u16>);
struct ProbedKey {
    key: Key,
    hash: Option<u64>,
}
struct NodeValue {
    depth: u16,
    value: f32,
    bound: Bound,
    best: Option<u16>,
}
struct Table {
    slots: Vec<Option<Entry>>,
    generation: u64,
    committed: u64,
    heap_bytes: usize,
    byte_limit: usize,
}
impl Table {
    fn new(n: usize) -> Result<Self> {
        Self::with_limit(n, usize::MAX)
    }
    fn persistent(n: usize) -> Result<Self> {
        Self::with_limit(n.min(4096), 1024 * 1024)
    }
    fn with_limit(n: usize, byte_limit: usize) -> Result<Self> {
        let mut slots = Vec::new();
        slots
            .try_reserve_exact(n)
            .map_err(|_| SearchError::Limits("transposition table allocation".into()))?;
        slots.resize_with(n, || None);
        Ok(Self {
            slots,
            generation: 0,
            committed: 0,
            heap_bytes: 0,
            byte_limit,
        })
    }
    fn get(&self, key: &Key) -> Option<&Entry> {
        if self.slots.is_empty() {
            None
        } else {
            self.slots[(key.hash() % self.slots.len() as u64) as usize]
                .as_ref()
                .filter(|e| e.key == *key)
        }
    }
    fn retained_bytes(&self) -> usize {
        std::mem::size_of::<Self>()
            + self.slots.capacity() * std::mem::size_of::<Option<Entry>>()
            + self.heap_bytes
    }
    fn clear(&mut self) {
        for slot in &mut self.slots {
            *slot = None;
        }
        self.heap_bytes = 0;
        self.generation = 0;
        self.committed = 0;
    }
    fn next_generation(&mut self) {
        if self.generation == u64::MAX {
            self.clear();
        }
        self.generation += 1;
    }
    fn discard_uncommitted(&mut self) {
        for slot in &mut self.slots {
            if slot.as_ref().is_some_and(|e| e.generation > self.committed) {
                self.heap_bytes -= slot.as_ref().unwrap().key.history.capacity()
                    * std::mem::size_of::<([u8; 2], u8, u64, u64, u16)>();
                *slot = None;
            }
        }
    }
    fn probe(&self, key: &Key, stats: &mut SearchStats) -> Option<ProbeHit> {
        stats.tt_probes += 1;
        if self.slots.is_empty() {
            return None;
        }
        stats.tt_hashes += 1;
        self.probe_hashed(key, key.hash(), stats)
    }
    fn probe_owned(&self, key: Key, stats: &mut SearchStats) -> (ProbedKey, Option<ProbeHit>) {
        stats.tt_probes += 1;
        let hash = if self.slots.is_empty() {
            None
        } else {
            stats.tt_hashes += 1;
            Some(key.hash())
        };
        let hit = hash.and_then(|hash| self.probe_hashed(&key, hash, stats));
        (ProbedKey { key, hash }, hit)
    }
    fn probe_hashed(&self, key: &Key, hash: u64, stats: &mut SearchStats) -> Option<ProbeHit> {
        let entry = self.slots[(hash % self.slots.len() as u64) as usize].as_ref()?;
        if entry.key != *key {
            stats.tt_collisions += 1;
            return None;
        }
        stats.tt_hits += 1;
        stats.tt_exact_hits += u64::from(matches!(entry.bound, Bound::Exact));
        Some((entry.depth, entry.value, entry.bound, entry.best))
    }
    fn insert_probed(&mut self, probe: ProbedKey, node: NodeValue, stats: &mut SearchStats) {
        // Search never resizes its table during a node. No key may be supplied
        // separately: insertion consumes the same key whose hash was computed.
        let Some(hash) = probe.hash else {
            debug_assert!(self.slots.is_empty());
            return;
        };
        debug_assert!(!self.slots.is_empty());
        self.insert_hashed(
            Entry {
                generation: 0,
                key: probe.key,
                depth: node.depth,
                value: node.value,
                bound: node.bound,
                best: node.best,
            },
            hash,
            stats,
        );
    }
    fn insert(&mut self, e: Entry, stats: &mut SearchStats) {
        if self.slots.is_empty() {
            return;
        }
        stats.tt_hashes += 1;
        let hash = e.key.hash();
        self.insert_hashed(e, hash, stats);
    }
    fn insert_hashed(&mut self, mut e: Entry, hash: u64, stats: &mut SearchStats) {
        let i = (hash % self.slots.len() as u64) as usize;
        if self.slots[i]
            .as_ref()
            .is_some_and(|old| old.generation == self.generation && old.depth > e.depth)
        {
            return;
        }
        let item_bytes = |e: &Entry| {
            e.key.history.capacity() * std::mem::size_of::<([u8; 2], u8, u64, u64, u16)>()
        };
        let old = self.slots[i].as_ref().map_or(0, item_bytes);
        let new = item_bytes(&e);
        if self.retained_bytes() - old + new > self.byte_limit {
            stats.tt_capacity_skips += 1;
            return;
        }
        stats.tt_replacements += u64::from(self.slots[i].is_some());
        self.heap_bytes = self.heap_bytes - old + new;
        e.generation = self.generation;
        self.slots[i] = Some(e);
    }
}
enum Interrupted {
    Stop(StopReason),
    Error(SearchError),
}
impl From<SearchError> for Interrupted {
    fn from(e: SearchError) -> Self {
        Self::Error(e)
    }
}
impl From<RulesError> for Interrupted {
    fn from(e: RulesError) -> Self {
        Self::Error(SearchError::Rules(e))
    }
}
type NodeResult<T> = std::result::Result<T, Interrupted>;
struct Search<'a> {
    eval: &'a dyn StaticEvaluator,
    score_domain: ScoreDomain,
    eval_scratch: EvalScratch,
    child_buffers: Vec<Option<EvalAccumulator>>,
    orderer: Option<&'a dyn MoveOrderer>,
    limits: &'a SearchLimits,
    cancel: &'a AtomicBool,
    start: Instant,
    deadline: Option<Instant>,
    table: &'a mut Table,
    stats: SearchStats,
    killers: Vec<[Option<u16>; 2]>,
    history: [u64; 209],
}
impl Search<'_> {
    fn key(&mut self, c: &SigmaContext) -> Key {
        let key = Key::of(c);
        self.stats.tt_key_builds += 1;
        self.stats.tt_history_items += key.history.len() as u64;
        self.stats.tt_key_history_capacity_bytes +=
            (key.history.capacity() * std::mem::size_of::<([u8; 2], u8, u64, u64, u16)>()) as u64;
        key
    }

    fn control(&self) -> NodeResult<()> {
        if self.cancel.load(Ordering::Relaxed) {
            return Err(Interrupted::Stop(StopReason::Cancelled));
        }
        if self.deadline.is_some_and(|d| Instant::now() >= d) {
            return Err(Interrupted::Stop(StopReason::TimeLimit));
        }
        Ok(())
    }
    fn enter(&mut self) -> NodeResult<()> {
        self.control()?;
        if self.stats.nodes >= self.limits.max_nodes {
            return Err(Interrupted::Stop(StopReason::NodeLimit));
        }
        self.stats.nodes += 1;
        Ok(())
    }
    fn ordered(&mut self, c: &SigmaContext, pv: Option<u16>, ply: usize) -> NodeResult<Vec<u16>> {
        let mut ids = c.legal_ids();
        let mut policy = [0f32; 209];
        if let Some(orderer) = self.orderer {
            self.control()?;
            let scores = orderer.scores(c, &ids)?;
            if scores.len() != ids.len() || scores.iter().any(|v| !v.is_finite()) {
                return Err(Interrupted::Error(SearchError::Evaluation(
                    "ordering scores must be finite and cover all legal moves".into(),
                )));
            }
            for (&action, &score) in ids.iter().zip(&scores) {
                policy[action as usize] = score;
            }
            self.stats.policy_calls += 1;
            self.control()?;
        }
        let killers = self.killers.get(ply).copied().unwrap_or([None; 2]);
        let priority = |id: u16| {
            if Some(id) == pv {
                0
            } else if Some(id) == killers[0] {
                1
            } else if Some(id) == killers[1] {
                2
            } else {
                3
            }
        };
        // TT/PV and killers first, then optional policy and history. Every legal
        // action survives. Numeric Action order is the final deterministic tie.
        ids.sort_by(|a, b| {
            priority(*a)
                .cmp(&priority(*b))
                .then_with(|| policy[*b as usize].total_cmp(&policy[*a as usize]))
                .then_with(|| self.history[*b as usize].cmp(&self.history[*a as usize]))
                .then_with(|| a.cmp(b))
        });
        Ok(ids)
    }
    fn child(
        &mut self,
        c: &mut SigmaContext,
        parent: Option<&EvalAccumulator>,
        action: u16,
        depth: u16,
        window: [f32; 2],
        ply: usize,
    ) -> NodeResult<f32> {
        self.control()?;
        let undo = c.make_move(action)?;
        // Taking the slot keeps payloads on the heap and the parent borrow local;
        // deeper recursion can never alias this active child.
        let pooled = ply < self.child_buffers.len();
        let mut a = self.child_buffers.get_mut(ply).and_then(Option::take);
        // The restore happens even when evaluation, budget or cancellation fails.
        let result = (|| {
            // True goal/threefold leaves bypass FT and head evaluation as well.
            if c.terminal_value().is_none() {
                self.eval.advance_move_context(parent, c, &undo, &mut a)?;
                if a.is_some() {
                    self.stats.delta_updates += 1;
                }
            }
            self.control()?;
            self.negamax(c, a.as_ref(), depth, -window[1], -window[0], ply)
        })();
        if pooled {
            self.child_buffers[ply] = a;
        }
        c.unmake_move(undo)?;
        result.map(|v| -v)
    }
    fn negamax(
        &mut self,
        c: &mut SigmaContext,
        a: Option<&EvalAccumulator>,
        depth: u16,
        mut alpha: f32,
        mut beta: f32,
        ply: usize,
    ) -> NodeResult<f32> {
        self.enter()?;
        if let Some(v) = c.terminal_value() {
            self.stats.terminal += 1;
            self.control()?;
            return Ok(v * self.score_domain.terminal_utility());
        }
        if depth == 0 {
            self.stats.evaluations += 1;
            let value = self
                .eval
                .evaluate_with_scratch(c, a, &mut self.eval_scratch)?;
            self.control()?;
            if !self.score_domain.admits(value) {
                return Err(Interrupted::Error(SearchError::Evaluation(
                    "nonterminal value must be finite within the declared score domain".into(),
                )));
            }
            return Ok(value);
        }
        let alpha_original = alpha;
        let beta_original = beta;
        let (key, hit) = if self.limits.use_tt {
            let key = self.key(c);
            let (key, hit) = self.table.probe_owned(key, &mut self.stats);
            (Some(key), hit)
        } else {
            (None, None)
        };
        let mut tt_move = None;
        if let Some((stored_depth, value, bound, best)) = hit {
            if best.is_some_and(|action| c.legal_ids().contains(&action)) {
                tt_move = best;
                // A different horizon is ordering information, not this depth's exact value.
                if stored_depth == depth {
                    self.stats.tt_usable_depth += 1;
                    match bound {
                        Bound::Exact => {
                            self.stats.tt_cutoffs += 1;
                            return Ok(value);
                        }
                        Bound::Lower => alpha = alpha.max(value),
                        Bound::Upper => beta = beta.min(value),
                    }
                    if alpha >= beta {
                        self.stats.tt_cutoffs += 1;
                        return Ok(value);
                    }
                } else {
                    self.stats.tt_order_only += 1;
                }
            } else {
                self.stats.tt_illegal_moves += 1;
            }
        }
        let moves = self.ordered(c, tt_move, ply)?;
        self.control()?;
        if moves.is_empty() {
            return Err(Interrupted::Error(SearchError::Rules(
                RulesError::InvalidPosition,
            )));
        }
        let mut value = f32::NEG_INFINITY;
        let mut best = None;
        for (i, action) in moves.into_iter().enumerate() {
            let mut v = if self.limits.use_pvs && i > 0 && alpha.is_finite() {
                self.child(c, a, action, depth - 1, [alpha, next_up(alpha)], ply + 1)?
            } else {
                self.child(c, a, action, depth - 1, [alpha, beta], ply + 1)?
            };
            if self.limits.use_pvs && i > 0 && v > alpha && v < beta {
                self.stats.pvs_researches += 1;
                v = self.child(c, a, action, depth - 1, [alpha, beta], ply + 1)?;
            }
            if v > value {
                value = v;
                best = Some(action);
            }
            alpha = alpha.max(v);
            if alpha >= beta {
                self.stats.cutoffs += 1;
                if let Some(k) = self.killers.get_mut(ply)
                    && k[0] != Some(action)
                {
                    k[1] = k[0];
                    k[0] = Some(action);
                }
                self.history[action as usize] = self.history[action as usize]
                    .saturating_add(u64::from(depth) * u64::from(depth));
                break;
            }
        }
        self.control()?;
        if let Some(key) = key {
            self.table.insert_probed(
                key,
                NodeValue {
                    depth,
                    value,
                    bound: if value <= alpha_original {
                        Bound::Upper
                    } else if value >= beta_original {
                        Bound::Lower
                    } else {
                        Bound::Exact
                    },
                    best,
                },
                &mut self.stats,
            );
        }
        Ok(value)
    }
    fn root_depth(
        &mut self,
        c: &mut SigmaContext,
        a: Option<&EvalAccumulator>,
        depth: u16,
        previous: Option<u16>,
    ) -> NodeResult<(u16, f32)> {
        self.enter()?;
        let mut previous = previous;
        if self.limits.use_tt {
            let key = self.key(c);
            if let Some((stored_depth, value, bound, best)) =
                self.table.probe(&key, &mut self.stats)
            {
                if best.is_some_and(|action| c.legal_ids().contains(&action)) {
                    previous = previous.or(best);
                    if stored_depth == depth && matches!(bound, Bound::Exact) {
                        self.stats.tt_usable_depth += 1;
                        self.stats.tt_cutoffs += 1;
                        return Ok((best.unwrap(), value));
                    }
                    self.stats.tt_order_only += 1;
                } else {
                    self.stats.tt_illegal_moves += 1;
                }
            }
        }
        let moves = self.ordered(c, previous, 0)?;
        self.control()?;
        let mut value = f32::NEG_INFINITY;
        let mut best = None;
        for (i, action) in moves.into_iter().enumerate() {
            let mut v = if self.limits.use_pvs && i > 0 {
                self.child(c, a, action, depth - 1, [value, next_up(value)], 1)?
            } else {
                self.child(c, a, action, depth - 1, [value, f32::INFINITY], 1)?
            };
            if self.limits.use_pvs && i > 0 && v > value {
                self.stats.pvs_researches += 1;
                v = self.child(c, a, action, depth - 1, [value, f32::INFINITY], 1)?;
            }
            if v > value {
                value = v;
                best = Some(action);
            }
        }
        self.control()?;
        let best = best.ok_or(Interrupted::Error(SearchError::Root(
            "no legal root actions".into(),
        )))?;
        if self.limits.use_tt {
            let key = self.key(c);
            self.table.insert(
                Entry {
                    generation: 0,
                    key,
                    depth,
                    value,
                    bound: Bound::Exact,
                    best: Some(best),
                },
                &mut self.stats,
            );
        }
        Ok((best, value))
    }
    fn pv(&self, c: &SigmaContext, action: u16, depth: u16) -> Vec<u16> {
        let mut c = c.clone();
        let mut pv = vec![action];
        if let Ok(next) = c.play(action) {
            c = next;
        } else {
            return Vec::new();
        }
        for remaining in (1..depth).rev() {
            if c.terminal_value().is_some() {
                break;
            }
            let Some(action) = self
                .table
                .get(&Key::of(&c))
                .filter(|e| e.depth == remaining && matches!(e.bound, Bound::Exact))
                .and_then(|e| e.best)
            else {
                break;
            };
            let Ok(next) = c.play(action) else {
                break;
            };
            pv.push(action);
            c = next;
        }
        pv
    }
}
fn next_up(x: f32) -> f32 {
    if x == f32::INFINITY {
        return x;
    }
    if x == 0. {
        return f32::from_bits(1);
    }
    let b = x.to_bits();
    f32::from_bits(if x > 0. { b + 1 } else { b - 1 })
}

/// Synchronous convenience API. Use search_with_updates for a worker-owned
/// completed-depth snapshot cache; publication does not wait for the next depth.
pub fn search(
    root: &SigmaContext,
    evaluator: &dyn StaticEvaluator,
    limits: &SearchLimits,
    cancel: &AtomicBool,
) -> Result<SearchResult> {
    search_with_updates(root, evaluator, limits, cancel, &mut |_| {})
}
/// Reports immutable snapshots only after validation and a complete root depth.
/// The owner can copy this compact result into shared memory under its own
/// generation guard. Callbacks are outside per-node/per-evaluation hot paths.
pub fn search_with_updates(
    root: &SigmaContext,
    evaluator: &dyn StaticEvaluator,
    limits: &SearchLimits,
    cancel: &AtomicBool,
    on_completed: &mut dyn FnMut(&SearchResult),
) -> Result<SearchResult> {
    search_with_orderer(root, evaluator, limits, cancel, None, on_completed)
}
/// Optional policy ranking is a separately selected search profile. The default
/// search API has no learned policy and requires no policy model/provider.
pub fn search_with_orderer(
    root: &SigmaContext,
    evaluator: &dyn StaticEvaluator,
    limits: &SearchLimits,
    cancel: &AtomicBool,
    orderer: Option<&dyn MoveOrderer>,
    on_completed: &mut dyn FnMut(&SearchResult),
) -> Result<SearchResult> {
    let mut table = Table::new(if limits.use_tt { limits.tt_entries } else { 0 })?;
    search_in_table(
        root,
        evaluator,
        limits,
        cancel,
        orderer,
        on_completed,
        (&mut table, ScoreDomain::LEGACY),
    )
}

/// Numerical entries belong to this explicit immutable evaluation/rule/profile namespace.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SearchNamespace {
    pub evaluator: String,
    pub rules: String,
    pub selectivity: String,
}
/// A player/game owns this bounded table across its real move sequence.
/// New games explicitly reset or create a session; namespace switches clear all entries.
pub struct SearchSession {
    namespace: SearchNamespace,
    evaluator: Arc<dyn StaticEvaluator>,
    table: Table,
    score_domain: ScoreDomain,
}
impl SearchSession {
    /// An immutable evaluator is owned by the session, so unchanged namespace
    /// text cannot accidentally substitute different weights between moves.
    pub fn new(
        evaluator: Arc<dyn StaticEvaluator>,
        namespace: SearchNamespace,
        capacity: usize,
    ) -> Result<Self> {
        Self::new_with_score_domain(evaluator, namespace, capacity, ScoreDomain::LEGACY)
    }
    /// Research callers freeze one common score domain for both opponents/views.
    /// `namespace.evaluator` must identify actual model/parameter SHA, deployed
    /// view, units, scale and bypass. The exact domain is added automatically.
    /// Original D's nonterminal formula can use this adapter without rescaling.
    pub fn new_with_score_domain(
        evaluator: Arc<dyn StaticEvaluator>,
        mut namespace: SearchNamespace,
        capacity: usize,
        score_domain: ScoreDomain,
    ) -> Result<Self> {
        if score_domain != ScoreDomain::LEGACY {
            namespace.evaluator.push(':');
            namespace
                .evaluator
                .push_str(&score_domain.namespace_suffix());
        }
        Ok(Self {
            namespace,
            evaluator,
            table: Table::persistent(capacity)?,
            score_domain,
        })
    }
    /// Table accounting includes its header, slot storage and retained history.
    /// Metadata is outside that bound; shared evaluator/model allocation is unknown here.
    pub fn retained_memory_bytes(&self) -> (usize, usize) {
        let metadata = std::mem::size_of::<Self>() - std::mem::size_of::<Table>()
            + self.namespace.evaluator.capacity()
            + self.namespace.rules.capacity()
            + self.namespace.selectivity.capacity();
        (self.table.retained_bytes(), metadata)
    }
    /// Live persistent slot count and byte limit; no table or history mutation.
    pub fn tt_capacity(&self) -> (usize, usize) {
        (self.table.slots.len(), self.table.byte_limit)
    }
    pub fn namespace(&self) -> &SearchNamespace {
        &self.namespace
    }
    pub fn score_domain(&self) -> ScoreDomain {
        self.score_domain
    }
    /// No search/NN work. Terminal classification uses the supplied real cursor.
    pub fn root_terminal(root: &SigmaContext) -> Option<TerminalOutcome> {
        TerminalOutcome::from_context(root)
    }
    /// New game, model, evaluation mode or rules/profile changes clear values,
    /// even if a caller reuses the same namespace string.
    pub fn reset(&mut self, evaluator: Arc<dyn StaticEvaluator>, namespace: SearchNamespace) {
        self.reset_with_score_domain(evaluator, namespace, ScoreDomain::LEGACY);
    }
    pub fn reset_with_score_domain(
        &mut self,
        evaluator: Arc<dyn StaticEvaluator>,
        mut namespace: SearchNamespace,
        score_domain: ScoreDomain,
    ) {
        if score_domain != ScoreDomain::LEGACY {
            namespace.evaluator.push(':');
            namespace
                .evaluator
                .push_str(&score_domain.namespace_suffix());
        }
        self.evaluator = evaluator;
        self.namespace = namespace;
        self.score_domain = score_domain;
        self.table.clear();
    }
    pub fn search(
        &mut self,
        root: &SigmaContext,
        limits: &SearchLimits,
        cancel: &AtomicBool,
    ) -> Result<SearchResult> {
        self.search_with_updates(root, limits, cancel, &mut |_| {})
    }
    /// Same persistent table and search; callback publishes complete depths only.
    pub fn search_with_updates(
        &mut self,
        root: &SigmaContext,
        limits: &SearchLimits,
        cancel: &AtomicBool,
        on_completed: &mut dyn FnMut(&SearchResult),
    ) -> Result<SearchResult> {
        search_in_table(
            root,
            self.evaluator.as_ref(),
            limits,
            cancel,
            None,
            on_completed,
            (&mut self.table, self.score_domain),
        )
    }
}
fn search_in_table(
    root: &SigmaContext,
    evaluator: &dyn StaticEvaluator,
    limits: &SearchLimits,
    cancel: &AtomicBool,
    orderer: Option<&dyn MoveOrderer>,
    on_completed: &mut dyn FnMut(&SearchResult),
    table_and_domain: (&mut Table, ScoreDomain),
) -> Result<SearchResult> {
    let (table, score_domain) = table_and_domain;
    let start = Instant::now();
    if limits.max_depth == 0 || limits.max_nodes == 0 || limits.max_depth > 200 {
        return Err(SearchError::Limits(
            "depth must be 1..=200 and nodes >0".into(),
        ));
    }
    if limits.use_tt && limits.tt_entries == 0 {
        return Err(SearchError::Limits("enabled TT requires capacity".into()));
    }
    if root.is_synthetic() {
        return Err(SearchError::Root(
            "synthetic histories are not search inputs".into(),
        ));
    }
    root.validate_normal()
        .map_err(|e| SearchError::Root(e.to_string()))?;
    let deadline = limits
        .time_limit
        .map(|t| {
            start
                .checked_add(t)
                .ok_or_else(|| SearchError::Limits("deadline overflow".into()))
        })
        .transpose()?;
    let mut state = Search {
        eval: evaluator,
        score_domain,
        eval_scratch: evaluator.create_scratch(),
        child_buffers: Vec::new(),
        orderer,
        limits,
        cancel,
        start,
        deadline,
        table,
        stats: SearchStats::default(),
        killers: vec![[None; 2]; limits.max_depth as usize + 1],
        history: [0; 209],
    };
    let mut result = SearchResult {
        action: None,
        value: None,
        completed_depth: 0,
        pv: Vec::new(),
        stats: SearchStats::default(),
        stop: StopReason::DepthComplete,
        elapsed: Duration::ZERO,
    };
    let mut c = root.clone();
    let run = (|| -> NodeResult<()> {
        state.control()?;
        if let Some(v) = c.terminal_value() {
            result.value = Some(v * score_domain.terminal_utility());
            result.stop = StopReason::Terminal;
            return Ok(());
        }
        let a = evaluator.prepare_context(&c)?;
        state.control()?;
        state.child_buffers = evaluator.create_child_storage(limits.max_depth as usize + 1);
        for depth in 1..=limits.max_depth {
            state.table.next_generation();
            let (action, value) = state.root_depth(&mut c, a.as_ref(), depth, result.action)?;
            let pv = state.pv(&c, action, depth);
            state.control()?;
            result.action = Some(action);
            result.value = Some(value);
            result.completed_depth = depth;
            result.pv = pv;
            state.stats.tt_retained_bytes = state.table.retained_bytes();
            state.stats.tt_generation = state.table.generation;
            result.stats = state.stats.clone();
            result.elapsed = state.start.elapsed();
            state.table.committed = state.table.generation;
            on_completed(&result);
        }
        Ok(())
    })();
    if run.is_err() {
        state.table.discard_uncommitted();
    }
    if c.position() != root.position()
        || c.total_ply() != root.total_ply()
        || c.history_counts() != root.history_counts()
    {
        state.table.clear();
        return Err(SearchError::Root(
            "search did not restore root history".into(),
        ));
    }
    match run {
        Ok(()) => {}
        Err(Interrupted::Stop(s)) => result.stop = s,
        Err(Interrupted::Error(e)) => return Err(e),
    }
    state.stats.tt_retained_bytes = state.table.retained_bytes();
    state.stats.tt_generation = state.table.generation;
    result.stats = state.stats;
    result.elapsed = state.start.elapsed();
    Ok(result)
}

#[cfg(test)]
mod persistent_tt_tests {
    use super::*;
    use quoridor_core::research::HistoryKey;
    use std::sync::atomic::AtomicU64;

    static PROCESSED: AtomicU64 = AtomicU64::new(0);
    fn charge(n: u64) {
        assert!(PROCESSED.fetch_add(n, Ordering::Relaxed) + n <= 10_000);
    }
    fn ns(name: &str) -> SearchNamespace {
        SearchNamespace {
            evaluator: name.into(),
            rules: "research-standard-2p-threefold-goal-first-v1".into(),
            selectivity: "fullwidth-PVS-MPC-OFF-v1".into(),
        }
    }
    fn limits(depth: u16, tt: bool, capacity: usize) -> SearchLimits {
        SearchLimits {
            max_depth: depth,
            max_nodes: 400,
            time_limit: None,
            tt_entries: capacity,
            use_pvs: false,
            use_tt: tt,
        }
    }
    fn legal_wall_sequence() -> (SigmaContext, Vec<u16>) {
        let mut c = SigmaContext::from_prefix(&[]).unwrap();
        let mut prefix = Vec::new();
        for _ in 0..20 {
            let a = c.legal_ids().into_iter().find(|a| *a >= 81).unwrap();
            prefix.push(a);
            c = c.play(a).unwrap();
        }
        assert_eq!(c.position().walls_remaining, [0, 0]);
        (c, prefix)
    }
    fn run(session: &mut SearchSession, c: &SigmaContext, depth: u16) -> SearchResult {
        let before = Key::of(c);
        let r = session
            .search(c, &limits(depth, true, 4096), &AtomicBool::new(false))
            .unwrap();
        charge(r.stats.nodes);
        assert_eq!(before, Key::of(c));
        assert!(r.stats.tt_retained_bytes <= 1024 * 1024);
        r
    }
    fn oracle(c: &SigmaContext, e: &dyn StaticEvaluator, depth: u16) -> f32 {
        charge(1);
        if let Some(v) = c.terminal_value() {
            return v * TERMINAL_SCORE;
        }
        if depth == 0 {
            return e.evaluate(c, None).unwrap();
        }
        c.legal_ids()
            .into_iter()
            .map(|a| -oracle(&c.play(a).unwrap(), e, depth - 1))
            .fold(f32::NEG_INFINITY, f32::max)
    }
    fn vector(c: &SigmaContext, e: &dyn StaticEvaluator, depth: u16) -> Vec<(u16, f32)> {
        c.legal_ids()
            .into_iter()
            .map(|a| (a, -oracle(&c.play(a).unwrap(), e, depth - 1)))
            .collect()
    }
    fn verify(c: &SigmaContext, e: &dyn StaticEvaluator, r: &SearchResult) -> Vec<(u16, u32)> {
        assert!(r.completed_depth > 0);
        let values = vector(c, e, r.completed_depth);
        let best = values
            .iter()
            .map(|(_, v)| *v)
            .fold(f32::NEG_INFINITY, f32::max);
        assert_eq!(r.value.unwrap().to_bits(), best.to_bits());
        assert_eq!(
            values
                .iter()
                .find(|(a, _)| Some(*a) == r.action)
                .unwrap()
                .1
                .to_bits(),
            best.to_bits()
        );
        values.into_iter().map(|(a, v)| (a, v.to_bits())).collect()
    }
    fn emit(label: &str, r: &SearchResult) {
        println!(
            "TT311 {}",
            serde_json::json!({"label":label,"depth":r.completed_depth,
            "action":r.action,"value_bits":r.value.map(f32::to_bits),"pv":r.pv,
            "nodes":r.stats.nodes,"D_evaluations":r.stats.evaluations,"native_NN":0,
            "seconds":r.elapsed.as_secs_f64(),"probes":r.stats.tt_probes,"hits":r.stats.tt_hits,
            "exact_hits":r.stats.tt_exact_hits,"usable":r.stats.tt_usable_depth,
            "cutoffs":r.stats.tt_cutoffs,"order_only":r.stats.tt_order_only,
            "collisions":r.stats.tt_collisions,"replacements":r.stats.tt_replacements,
            "retained_B":r.stats.tt_retained_bytes,"capacity_skips":r.stats.tt_capacity_skips,
            "key_builds":r.stats.tt_key_builds,"history_items":r.stats.tt_history_items,"hashes":r.stats.tt_hashes,"key_history_capacity_B_sum":r.stats.tt_key_history_capacity_bytes})
        );
    }
    struct Failing;
    impl StaticEvaluator for Failing {
        fn evaluate(&self, _: &SigmaContext, _: Option<&EvalAccumulator>) -> Result<f32> {
            Err(SearchError::Evaluation("fixture injected error".into()))
        }
    }

    #[test]
    fn persistent_tt_contract_and_cost() {
        // Full-key equality, independent of index hashing and board equality.
        let p = Position::default();
        let a = SigmaContext::from_counts(
            p,
            4,
            vec![
                (p.into(), 1),
                (
                    HistoryKey {
                        turn: 0,
                        ..HistoryKey::from(p.play(5).unwrap())
                    },
                    2,
                ),
                (HistoryKey::from(p.play(13).unwrap()), 2),
            ],
        )
        .unwrap();
        let b = SigmaContext::from_counts(
            p,
            4,
            vec![
                (p.into(), 1),
                (
                    HistoryKey {
                        turn: 0,
                        ..HistoryKey::from(p.play(5).unwrap())
                    },
                    2,
                ),
                (HistoryKey::from(p.play(3).unwrap()), 2),
            ],
        )
        .unwrap();
        a.validate_normal().unwrap();
        b.validate_normal().unwrap();
        assert_ne!(Key::of(&a), Key::of(&b));
        assert!(a.legal_ids().contains(&13));
        assert_eq!(a.play(13).unwrap().terminal_value(), Some(0.));
        assert!(b.legal_ids().contains(&13));
        let mut t = Table::persistent(1).unwrap();
        t.next_generation();
        let mut stats = SearchStats::default();
        t.insert(
            Entry {
                generation: 0,
                key: Key::of(&a),
                depth: 1,
                value: 0.75,
                bound: Bound::Exact,
                best: Some(3),
            },
            &mut stats,
        );
        assert!(t.probe(&Key::of(&b), &mut stats).is_none());
        assert_eq!(stats.tt_collisions, 1);
        t.insert(
            Entry {
                generation: 0,
                key: Key::of(&b),
                depth: 1,
                value: 0.25,
                bound: Bound::Exact,
                best: Some(13),
            },
            &mut stats,
        );
        assert_eq!(stats.tt_replacements, 1);
        let mut changed = Key::of(&b);
        changed.ply += 2;
        assert!(t.probe(&changed, &mut stats).is_none());
        // Artificial keys here exercise allocation ceiling, not rule validity.
        let mut capped = Table::persistent(65536).unwrap();
        assert_eq!(capped.slots.len(), 4096);
        capped.next_generation();
        for i in 0..512u16 {
            let mut key = Key::of(&a);
            key.ply = i;
            key.history = vec![key.history[0]; 201];
            capped.insert(
                Entry {
                    generation: 0,
                    key,
                    depth: 1,
                    value: 0.,
                    bound: Bound::Exact,
                    best: Some(3),
                },
                &mut stats,
            );
        }
        assert!(capped.retained_bytes() <= 1024 * 1024);
        assert!(stats.tt_capacity_skips > 0);
        assert_eq!(Table::new(65536).unwrap().slots.len(), 65536);

        let (root, prefix) = legal_wall_sequence();
        println!(
            "TT311 {}",
            serde_json::json!({"fixture_prefix":prefix,"root_legal":root.legal_ids(),"history":root.history_counts().len()})
        );
        let e: Arc<dyn StaticEvaluator> = Arc::new(DistanceEvaluator::new(0., 8.));
        let mut session = SearchSession::new(e.clone(), ns("D0,8:tanh"), 65536).unwrap();
        let seed = run(&mut session, &root, 3);
        emit("seed-depth3", &seed);
        assert_eq!(seed.completed_depth, 3);
        let seed_vector = verify(&root, e.as_ref(), &seed);
        println!(
            "TT311 {}",
            serde_json::json!({"seed_full_child_vector":seed_vector})
        );
        let truth = oracle(&root, e.as_ref(), 1);
        let best = vector(&root, e.as_ref(), 1)
            .into_iter()
            .find(|(_, v)| v.to_bits() == truth.to_bits())
            .unwrap()
            .0;
        for (bound, window) in [
            (Bound::Exact, [-f32::INFINITY, f32::INFINITY]),
            (Bound::Lower, [truth - 0.2, truth - 0.1]),
            (Bound::Upper, [truth + 0.1, truth + 0.2]),
        ] {
            let mut table = Table::persistent(4096).unwrap();
            table.next_generation();
            table.insert(
                Entry {
                    generation: 0,
                    key: Key::of(&root),
                    depth: 1,
                    value: truth,
                    bound,
                    best: Some(best),
                },
                &mut SearchStats::default(),
            );
            table.committed = table.generation;
            let l = limits(1, true, 4096);
            let cancel = AtomicBool::new(false);
            let mut state = Search {
                eval: e.as_ref(),
                score_domain: ScoreDomain::LEGACY,
                eval_scratch: e.create_scratch(),
                child_buffers: Vec::new(),
                orderer: None,
                limits: &l,
                cancel: &cancel,
                start: Instant::now(),
                deadline: None,
                table: &mut table,
                stats: SearchStats::default(),
                killers: vec![[None; 2]; 2],
                history: [0; 209],
            };
            let mut child = root.clone();
            let value = state
                .negamax(&mut child, None, 1, window[0], window[1], 0)
                .unwrap_or_else(|_| panic!("bound fixture failed"));
            charge(state.stats.nodes);
            assert_eq!(value.to_bits(), truth.to_bits());
            assert_eq!(state.stats.tt_cutoffs, 1);
            assert_eq!(Key::of(&root), Key::of(&child));
        }
        // Illegal cached moves are neither ordering candidates nor numerical cuts.
        let mut illegal = SearchSession::new(e.clone(), ns("D0,8:tanh"), 4096).unwrap();
        illegal.table.next_generation();
        illegal.table.insert(
            Entry {
                generation: 0,
                key: Key::of(&root),
                depth: 1,
                value: 0.99,
                bound: Bound::Exact,
                best: Some(208),
            },
            &mut SearchStats::default(),
        );
        illegal.table.committed = illegal.table.generation;
        let r = run(&mut illegal, &root, 1);
        verify(&root, e.as_ref(), &r);
        assert_eq!(r.stats.tt_illegal_moves, 1);
        // A higher/deeper value can order a shallower request but never cut it.
        let shallow = run(&mut session, &root, 1);
        verify(&root, e.as_ref(), &shallow);
        assert!(shallow.stats.tt_order_only > 0);
        assert!(shallow.stats.nodes > 1);
        emit("different-horizon-order-only", &shallow);
        // Owning immutable evaluator + explicit reset prevents model/mode aliasing.
        let clip: Arc<dyn StaticEvaluator> = Arc::new(DistanceEvaluator::clipped(0.25, 0.));
        for label in [
            "newgame",
            "model-content-change",
            "mode-change",
            "rules-change",
            "MPC-namespace-only-not-enabled",
        ] {
            let mut namespace = ns(label);
            if label.starts_with("MPC") {
                namespace.selectivity = "future-calibration-isolated-no-MPC-algorithm".into();
            }
            session.reset(clip.clone(), namespace.clone());
            assert_eq!(session.namespace(), &namespace);
            assert_eq!(session.table.heap_bytes, 0);
            let r = run(&mut session, &root, 1);
            verify(&root, clip.as_ref(), &r);
            assert_eq!(r.stats.tt_hits, 0);
        }
        // Errors/cancellation discard partial generation and preserve parent.
        let mut cancel_table = Table::persistent(4096).unwrap();
        let cancel = AtomicBool::new(false);
        let before = Key::of(&root);
        let r = search_in_table(
            &root,
            e.as_ref(),
            &limits(3, true, 4096),
            &cancel,
            None,
            &mut |_| cancel.store(true, Ordering::Relaxed),
            (&mut cancel_table, ScoreDomain::LEGACY),
        )
        .unwrap();
        charge(r.stats.nodes);
        assert_eq!(r.completed_depth, 1);
        assert_eq!(r.stop, StopReason::Cancelled);
        assert!(
            cancel_table
                .slots
                .iter()
                .flatten()
                .all(|x| x.generation <= cancel_table.committed)
        );
        assert_eq!(before, Key::of(&root));
        let mut fail = SearchSession::new(Arc::new(Failing), ns("injected-error"), 4096).unwrap();
        assert!(
            fail.search(&root, &limits(1, true, 4096), &AtomicBool::new(false))
                .is_err()
        );
        charge(2);
        assert_eq!(before, Key::of(&root));
        assert_eq!(fail.table.heap_bytes, 0);
        let mut limited = SearchSession::new(e.clone(), ns("D0,8"), 4096).unwrap();
        let mut l = limits(3, true, 4096);
        l.max_nodes = 2;
        let r = limited.search(&root, &l, &AtomicBool::new(false)).unwrap();
        charge(r.stats.nodes);
        assert_eq!(r.completed_depth, 0);
        assert_eq!(r.action, None);
        assert_eq!(limited.table.heap_bytes, 0);
        // P2 jump/defense and a genuine completed terminal child, no forward model.
        for prefix in [
            vec![13, 67, 22, 58, 31, 49, 40],
            vec![13, 67, 22, 58, 31, 49, 40, 31],
        ] {
            let c = SigmaContext::from_prefix(&prefix).unwrap();
            let mut s = SearchSession::new(e.clone(), ns("P2-jump"), 4096).unwrap();
            let r = run(&mut s, &c, 1);
            verify(&c, e.as_ref(), &r);
            emit("jump-P1P2", &r);
        }
        let p = Position {
            pawns: [67, 13],
            walls_remaining: [10, 10],
            horizontal: 0,
            vertical: 0,
            turn: 0,
            winner: None,
        };
        let c = SigmaContext::from_counts(
            p,
            2,
            vec![
                (Position::default().into(), 1),
                (Position { turn: 1, ..p }.into(), 1),
                (p.into(), 1),
            ],
        )
        .unwrap();
        let mut s = SearchSession::new(e.clone(), ns("terminal"), 4096).unwrap();
        let r = run(&mut s, &c, 1);
        verify(&c, e.as_ref(), &r);
        assert_eq!(r.action, Some(76));
        let terminal = c.play(76).unwrap();
        let r = run(&mut s, &terminal, 1);
        assert_eq!(r.stop, StopReason::Terminal);
        assert_eq!(r.stats.evaluations, 0);
        assert_eq!(r.value, Some(-TERMINAL_SCORE));
        // Real two-sided legal history advances, no history/ply stripping.
        // Short PV is recorded as insufficient, never filled with invented moves.
        if seed.pv.len() >= 2 {
            let next = root.play(seed.pv[0]).unwrap().play(seed.pv[1]).unwrap();
            assert_eq!(next.position().turn, root.position().turn);
            assert_eq!(next.total_ply(), root.total_ply() + 2);
            println!(
                "TT311 {}",
                serde_json::json!({"sequence":&seed.pv[..2],"new_ply":next.total_ply()})
            );
            for round in 0..4 {
                let mut warm = SearchSession::new(e.clone(), ns("D0,8:tanh"), 4096).unwrap();
                let seed_round = run(&mut warm, &root, 3);
                emit("warm-sequence-setup", &seed_round);
                let depth = if round % 2 == 0 { 1 } else { 2 };
                let order = if round < 2 {
                    vec![0, 1, 2]
                } else {
                    vec![2, 1, 0]
                };
                for variant in order {
                    let wall = std::time::Instant::now();
                    let r = match variant {
                        0 => search(
                            &next,
                            e.as_ref(),
                            &limits(depth, true, 65536),
                            &AtomicBool::new(false),
                        )
                        .unwrap(),
                        1 => {
                            let mut cold =
                                SearchSession::new(e.clone(), ns("D0,8:tanh"), 4096).unwrap();
                            run(&mut cold, &next, depth)
                        }
                        _ => run(&mut warm, &next, depth),
                    };
                    let whole = wall.elapsed().as_secs_f64();
                    if variant == 0 {
                        charge(r.stats.nodes);
                    }
                    emit(&format!("round{round}-variant{variant}"), &r);
                    let v = verify(&next, e.as_ref(), &r);
                    println!(
                        "TT311 {}",
                        serde_json::json!({"round":round,"variant":variant,"whole_including_table_creation_s":whole,"full_child_vector":v})
                    );
                }
            }
        } else {
            println!(
                "TT311 {}",
                serde_json::json!({"legal_sequence_cost":"NOT_RECORDED_SHORT_COMPLETED_PV"})
            );
        }
        println!(
            "TT311 {}",
            serde_json::json!({"purpose":"frame24-persistent-tt-311-v1","PASS":true,"native_NN":0,"processed_including_oracle":PROCESSED.load(Ordering::Relaxed),"MPC":"OFF","runtime_pergame_execution":"NOT_RUN"})
        );
    }
}
#[cfg(test)]
mod input_scratch_error_tests {
    use super::*;
    use std::sync::atomic::AtomicU64;

    struct Probe {
        inner: ResidualEvaluator,
        cancel: Arc<AtomicBool>,
        inject_error: bool,
        prepares: AtomicU64,
        deltas: AtomicU64,
        heads: AtomicU64,
        setups: AtomicU64,
    }
    impl StaticEvaluator for Probe {
        fn create_scratch(&self) -> EvalScratch {
            self.setups.fetch_add(1, Ordering::Relaxed);
            self.inner.create_scratch()
        }
        fn evaluate_with_scratch(
            &self,
            c: &SigmaContext,
            a: Option<&EvalAccumulator>,
            scratch: &mut EvalScratch,
        ) -> Result<f32> {
            self.heads.fetch_add(1, Ordering::Relaxed);
            let value = self.inner.evaluate_with_scratch(c, a, scratch)?;
            if self.inject_error {
                return Err(SearchError::Evaluation(
                    "injected after borrowed head".into(),
                ));
            }
            self.cancel.store(true, Ordering::Relaxed);
            Ok(value)
        }
        fn prepare_context(&self, c: &SigmaContext) -> Result<Option<EvalAccumulator>> {
            self.prepares.fetch_add(1, Ordering::Relaxed);
            self.inner.prepare_context(c)
        }
        fn advance_context(
            &self,
            parent: Option<&EvalAccumulator>,
            c: &SigmaContext,
        ) -> Result<Option<EvalAccumulator>> {
            self.deltas.fetch_add(1, Ordering::Relaxed);
            self.inner.advance_context(parent, c)
        }
        fn evaluate(&self, c: &SigmaContext, a: Option<&EvalAccumulator>) -> Result<f32> {
            self.heads.fetch_add(1, Ordering::Relaxed);
            self.inner.evaluate(c, a)
        }
    }
    #[test]
    #[ignore = "requires an explicitly supplied frozen model and legal replay config"]
    fn input_scratch_head_error_cancel_restore_parent() {
        let config: serde_json::Value = serde_json::from_slice(
            &std::fs::read(std::env::var("QUORIDOR_NNUE_REFERENCE_CONFIG").unwrap()).unwrap(),
        )
        .unwrap();
        let model = Arc::new(ResidualModel::load(config["manifest"].as_str().unwrap()).unwrap());
        let limits = SearchLimits {
            max_depth: 2,
            max_nodes: 100_000,
            time_limit: None,
            tt_entries: 4096,
            use_pvs: true,
            use_tt: true,
        };
        let mut heads = 0;
        let mut prepares = 0;
        let mut deltas = 0;
        for fixture in config["fixtures"].as_array().unwrap() {
            let prefix: Vec<u16> = serde_json::from_value(fixture["prefix"].clone()).unwrap();
            let root = SigmaContext::from_prefix(&prefix).unwrap();
            let before = (root.position(), root.history_counts(), root.total_ply());
            for mode in [EvaluationMode::Scalar, EvaluationMode::Simd] {
                let parent = model.full_context(&root, mode).unwrap();
                prepares += 1;
                let before_value = model.evaluate(&parent).unwrap().to_bits();
                heads += 1;
                for inject_error in [true, false] {
                    let cancel = Arc::new(AtomicBool::new(false));
                    let probe = Arc::new(Probe {
                        inner: ResidualEvaluator::new(model.clone()).with_mode(mode),
                        cancel: cancel.clone(),
                        inject_error,
                        prepares: AtomicU64::new(0),
                        deltas: AtomicU64::new(0),
                        heads: AtomicU64::new(0),
                        setups: AtomicU64::new(0),
                    });
                    let mut session = SearchSession::new(
                        probe.clone(),
                        SearchNamespace {
                            evaluator: format!("fixedBEST:{mode:?}"),
                            rules: "Sigma-fullhistory-ply200".into(),
                            selectivity: "fullwidth-PVS".into(),
                        },
                        4096,
                    )
                    .unwrap();
                    let result = session.search(&root, &limits, &cancel);
                    assert_eq!(probe.setups.load(Ordering::Relaxed), 1);
                    if inject_error {
                        assert!(matches!(result, Err(SearchError::Evaluation(_))));
                    } else {
                        let result = result.unwrap();
                        assert_eq!(result.stop, StopReason::Cancelled);
                        assert_eq!(result.completed_depth, 0);
                        assert!(result.action.is_none());
                    }
                    assert_eq!(
                        (root.position(), root.history_counts(), root.total_ply()),
                        before
                    );
                    assert_eq!(model.evaluate(&parent).unwrap().to_bits(), before_value);
                    heads += 1 + probe.heads.load(Ordering::Relaxed);
                    prepares += probe.prepares.load(Ordering::Relaxed);
                    deltas += probe.deltas.load(Ordering::Relaxed);
                }
            }
        }
        println!("INPUT_SCRATCH_ERROR_HEADS={heads};FT_PREPARES={prepares};FT_DELTAS={deltas}");
    }

    #[test]
    #[ignore = "requires an explicitly supplied frozen model and legal replay config"]
    fn borrowed_scratch_search_is_reentrant_after_completed_depth() {
        let config: serde_json::Value = serde_json::from_slice(
            &std::fs::read(std::env::var("QUORIDOR_NNUE_REFERENCE_CONFIG").unwrap()).unwrap(),
        )
        .unwrap();
        let model = Arc::new(ResidualModel::load(config["manifest"].as_str().unwrap()).unwrap());
        let evaluator = ResidualEvaluator::new(model);
        let prefix: Vec<u16> =
            serde_json::from_value(config["fixtures"][0]["prefix"].clone()).unwrap();
        let root = SigmaContext::from_prefix(&prefix).unwrap();
        let before = (root.position(), root.history_counts(), root.total_ply());
        let limits = SearchLimits {
            max_depth: 1,
            max_nodes: 100_000,
            use_tt: false,
            ..SearchLimits::default()
        };
        let cancel = AtomicBool::new(false);
        let mut nested = None;
        let outer = search_with_updates(&root, &evaluator, &limits, &cancel, &mut |_| {
            assert!(nested.is_none());
            nested = Some(search(&root, &evaluator, &limits, &cancel).unwrap());
        })
        .unwrap();
        let inner = nested.unwrap();
        assert_eq!(outer.action, inner.action);
        assert_eq!(outer.value.map(f32::to_bits), inner.value.map(f32::to_bits));
        assert_eq!(outer.pv, inner.pv);
        assert_eq!(outer.completed_depth, inner.completed_depth);
        assert_eq!(outer.stats.nodes, inner.stats.nodes);
        assert_eq!(
            (root.position(), root.history_counts(), root.total_ply()),
            before
        );
        println!(
            "INPUT_SCRATCH_REENTRANT_HEADS={}",
            outer.stats.evaluations + inner.stats.evaluations
        );
    }
}

#[cfg(all(test, feature = "research"))]
mod fast_head_search_tests {
    use super::*;
    use serde_json::{Value, json};
    use std::sync::Mutex;

    // Independent test-only original scalar head. Production search, FT,
    // history, move ordering and TT are reused, never copied here.
    struct Reference {
        inner: ResidualEvaluator,
        weights: Vec<f32>,
        manifest: Value,
        scalar: bool,
        deltas: Mutex<Vec<f64>>,
    }
    impl Reference {
        fn scalar_head(&self, a: &Accumulator) -> f32 {
            let width = self.manifest["topology"]["ft_width"].as_u64().unwrap() as usize;
            let hidden = self.manifest["topology"]["hidden_width"].as_u64().unwrap() as usize;
            let input = 2 * width + 6;
            let side = usize::from(a.features.side);
            let mut x = Vec::with_capacity(input);
            for p in [side, side ^ 1] {
                x.extend(a.values[p].iter().map(|v| v.max(0.)));
            }
            for i in 0..2 {
                let mu = self.manifest["mu_f32"][i].as_f64().unwrap() as f32;
                let sigma = self.manifest["sigma_f32"][i].as_f64().unwrap() as f32;
                x.push((a.features.distance[i] - mu) / sigma);
            }
            x.extend([0.; 4]);
            let h = (quoridor_nnue::FEATURE_COUNT + 1) * width;
            let b = h + input * hidden;
            let o = b + hidden;
            let mut r = self.weights[o + hidden];
            for j in 0..hidden {
                let mut v = self.weights[b + j];
                for (k, &x) in x.iter().enumerate() {
                    v += self.weights[h + j * input + k] * x;
                }
                r += self.weights[o + j] * v.max(0.);
            }
            let da = self.manifest["distance_fit"]["a"].as_f64().unwrap() as f32;
            let db = self.manifest["distance_fit"]["b"].as_f64().unwrap() as f32;
            let logit = da + db * (a.features.distance[1] - a.features.distance[0]) + r;
            assert!(logit.is_finite());
            f64::from(logit).tanh() as f32
        }
    }
    impl StaticEvaluator for Reference {
        fn create_scratch(&self) -> EvalScratch {
            self.inner.create_scratch()
        }
        fn prepare_context(&self, c: &SigmaContext) -> Result<Option<EvalAccumulator>> {
            self.inner.prepare_context(c)
        }
        fn advance_context(
            &self,
            a: Option<&EvalAccumulator>,
            c: &SigmaContext,
        ) -> Result<Option<EvalAccumulator>> {
            self.inner.advance_context(a, c)
        }
        fn evaluate(&self, c: &SigmaContext, a: Option<&EvalAccumulator>) -> Result<f32> {
            self.evaluate_with_scratch(c, a, &mut self.create_scratch())
        }
        fn evaluate_with_scratch(
            &self,
            c: &SigmaContext,
            a: Option<&EvalAccumulator>,
            s: &mut EvalScratch,
        ) -> Result<f32> {
            let fast = self.inner.evaluate_with_scratch(c, a, s)?;
            let Some(EvalAccumulator::Float(acc)) = a else {
                panic!("float accumulator")
            };
            let scalar = self.scalar_head(acc);
            self.deltas
                .lock()
                .unwrap()
                .push((f64::from(fast) - f64::from(scalar)).abs());
            Ok(if self.scalar { scalar } else { fast })
        }
    }
    fn sig(r: &SearchResult) -> Value {
        let s = &r.stats;
        json!({"action":r.action,"value":r.value,"value_bits":r.value.map(f32::to_bits),
            "depth":r.completed_depth,"pv":r.pv,"stop":format!("{:?}",r.stop),
            "counters":[s.nodes,s.evaluations,s.terminal,s.cutoffs,s.tt_hits,s.tt_probes,
            s.tt_exact_hits,s.tt_key_builds,s.tt_history_items,s.tt_key_history_capacity_bytes,
            s.tt_hashes,s.tt_usable_depth,s.tt_order_only,s.tt_collisions,s.tt_replacements,
            s.tt_capacity_skips,s.tt_illegal_moves,s.tt_retained_bytes as u64,s.tt_generation,
            s.tt_cutoffs,s.pvs_researches,s.delta_updates,s.policy_calls]})
    }
    #[test]
    #[ignore = "requires fixed model/fixture paths and explicit finite numeric admission"]
    fn fast_head_actual_bounded_search_outcomes() {
        let cfg: Value = serde_json::from_slice(
            &std::fs::read(std::env::var("QUORIDOR_NNUE_REFERENCE_CONFIG").unwrap()).unwrap(),
        )
        .unwrap();
        let path = std::path::PathBuf::from(cfg["manifest"].as_str().unwrap());
        let manifest: Value = serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
        let raw = std::fs::read(
            path.parent()
                .unwrap()
                .join(manifest["weights"].as_str().unwrap()),
        )
        .unwrap();
        let weights: Vec<f32> = raw
            .as_chunks::<4>()
            .0
            .iter()
            .map(|x| f32::from_le_bytes(*x))
            .collect();
        let model = Arc::new(ResidualModel::load(&path).unwrap());
        let limits = SearchLimits {
            max_depth: 3,
            max_nodes: 100_000,
            time_limit: None,
            tt_entries: 4096,
            use_pvs: true,
            use_tt: true,
        };
        let cancel = AtomicBool::new(false);
        let mut rows = vec![];
        let mut all_errors = vec![];
        for fixture in cfg["fixtures"].as_array().unwrap() {
            let prefix: Vec<u16> = serde_json::from_value(fixture["prefix"].clone()).unwrap();
            let root = SigmaContext::from_prefix(&prefix).unwrap();
            let mut roots = vec![(None, root.clone())];
            for action in root.legal_ids() {
                roots.push((Some(action), root.play(action).unwrap()));
            }
            for (action, c) in roots {
                let before = (c.position(), c.history_counts(), c.total_ply());
                let mut results = vec![];
                for scalar in [true, false] {
                    let evaluator = Arc::new(Reference {
                        inner: ResidualEvaluator::new(model.clone()),
                        weights: weights.clone(),
                        manifest: manifest.clone(),
                        scalar,
                        deltas: Mutex::new(vec![]),
                    });
                    let mut session = SearchSession::new(
                        evaluator.clone(),
                        SearchNamespace {
                            evaluator: format!("head-qualification:scalar={scalar}"),
                            rules: "Sigma-fullhistory-ply200".into(),
                            selectivity: "fullwidth-PVS".into(),
                        },
                        4096,
                    )
                    .unwrap();
                    let result = session.search(&c, &limits, &cancel).unwrap();
                    if c.terminal_value().is_none() {
                        assert!(matches!(
                            result.stop,
                            StopReason::DepthComplete | StopReason::NodeLimit
                        ));
                        assert!(result.value.unwrap().is_finite());
                        assert!(c.legal_ids().contains(&result.action.unwrap()));
                        let mut pv = c.clone();
                        for &a in &result.pv {
                            assert!(pv.legal_ids().contains(&a));
                            pv = pv.play(a).unwrap();
                        }
                    } else {
                        assert_eq!(result.stop, StopReason::Terminal);
                    }
                    assert_eq!((c.position(), c.history_counts(), c.total_ply()), before);
                    results.push(sig(&result));
                    all_errors.extend(evaluator.deltas.lock().unwrap().iter().copied());
                }
                rows.push(json!({"fixture":fixture["name"],"child_action":action,"scalar":results[0],"fast":results[1]}));
            }
        }
        all_errors.sort_by(f64::total_cmp);
        let q = |p: f64| all_errors[((all_errors.len() - 1) as f64 * p).ceil() as usize];
        let changed = rows
            .iter()
            .filter(|r| r["scalar"]["action"] != r["fast"]["action"])
            .count();
        let result = json!({"roots":rows,"changed_actions":changed,"visited_head_pairs":all_errors.len(),
            "absolute_error":{"mean":all_errors.iter().sum::<f64>()/all_errors.len() as f64,
                "p50":q(0.5),"p90":q(0.9),"p99":q(0.99),"p999":q(0.999),"max":all_errors.last()},
            "scope":"production search; each visited input compared, probe allocating scalar diagnostic is NOT performance data",
            "parent_history_legal_PV_exact":true,"adoption":false});
        std::fs::write(
            std::env::var("QUORIDOR_HEAD_SEARCH_OUT").unwrap(),
            serde_json::to_vec(&result).unwrap(),
        )
        .unwrap();
        println!(
            "FAST_HEAD_BOUNDED_ROOTS={};VISITED_PAIRS={};CHANGED_ACTIONS={changed}",
            rows.len(),
            all_errors.len()
        );
    }
}

#[cfg(test)]
mod child_buffer_tests {
    use super::*;
    use quoridor_nnue::{DistanceFit, Topology, residual::RouteMode};

    struct Probe {
        inner: ResidualEvaluator,
        cancel: Arc<AtomicBool>,
        failure: u8,
    }
    impl StaticEvaluator for Probe {
        fn create_child_storage(&self, n: usize) -> Vec<Option<EvalAccumulator>> {
            self.inner.create_child_storage(n)
        }
        fn create_scratch(&self) -> EvalScratch {
            self.inner.create_scratch()
        }
        fn prepare_context(&self, c: &SigmaContext) -> Result<Option<EvalAccumulator>> {
            self.inner.prepare_context(c)
        }
        fn evaluate(&self, c: &SigmaContext, a: Option<&EvalAccumulator>) -> Result<f32> {
            self.inner.evaluate(c, a)
        }
        fn evaluate_with_scratch(
            &self,
            c: &SigmaContext,
            a: Option<&EvalAccumulator>,
            s: &mut EvalScratch,
        ) -> Result<f32> {
            self.inner.evaluate_with_scratch(c, a, s)
        }
        fn advance_move_context(
            &self,
            p: Option<&EvalAccumulator>,
            c: &SigmaContext,
            u: &quoridor_core::research::ContextUndo,
            storage: &mut Option<EvalAccumulator>,
        ) -> Result<()> {
            self.inner.advance_move_context(p, c, u, storage)?;
            if self.failure == 1 {
                self.cancel.store(true, Ordering::Relaxed);
            }
            if self.failure == 2 {
                return Err(SearchError::Evaluation("after-child fixture".into()));
            }
            Ok(())
        }
    }
    fn evaluator(width: usize) -> ResidualEvaluator {
        let t = Topology {
            ft_width: width,
            hidden_width: 1,
        };
        let model = ResidualModel::from_parts(
            t,
            vec![0.; ResidualModel::parameter_count(t).unwrap()],
            [0.; 2],
            [1.; 2],
            DistanceFit::default(),
            RouteMode::Zero4,
            [0.; 4],
            [1.; 4],
        )
        .unwrap();
        ResidualEvaluator::new(Arc::new(model))
    }
    #[test]
    fn slot_return_and_history_restore_after_success_cancel_or_error() {
        for failure in 0..=2 {
            let cancel = Arc::new(AtomicBool::new(false));
            let e = Probe {
                inner: evaluator(32),
                cancel: cancel.clone(),
                failure,
            };
            let limits = SearchLimits {
                max_depth: 3,
                max_nodes: 100000,
                time_limit: None,
                tt_entries: 4096,
                use_pvs: true,
                use_tt: true,
            };
            let mut table = Table::new(4096).unwrap();
            let mut c = SigmaContext::from_prefix(&[]).unwrap();
            let position = c.position();
            let history = c.history_counts();
            let parent = e.prepare_context(&c).unwrap();
            let mut state = Search {
                eval: &e,
                score_domain: ScoreDomain::LEGACY,
                eval_scratch: e.create_scratch(),
                child_buffers: e.create_child_storage(4),
                orderer: None,
                limits: &limits,
                cancel: &cancel,
                start: Instant::now(),
                deadline: None,
                table: &mut table,
                stats: SearchStats::default(),
                killers: vec![[None; 2]; 4],
                history: [0; 209],
            };
            let result = state.child(
                &mut c,
                parent.as_ref(),
                13,
                0,
                [f32::NEG_INFINITY, f32::INFINITY],
                1,
            );
            assert_eq!(c.position(), position);
            assert_eq!(c.history_counts(), history);
            assert!(state.child_buffers[1].is_some());
            if failure == 0 {
                assert!(result.is_ok());
            } else {
                assert!(result.is_err());
            }
        }
    }
    #[test]
    fn maxdepth_maxwidth_per_invocation_slots_have_distinct_payloads() {
        let e = evaluator(2048);
        let one = e.create_child_storage(201);
        let two = e.create_child_storage(201);
        let mut pointers = std::collections::HashSet::new();
        for a in one.iter().chain(&two) {
            let Some(EvalAccumulator::Float(a)) = a else {
                panic!("float slot missing")
            };
            for values in &a.values {
                assert_eq!(values.len(), 2048);
                assert!(pointers.insert(values.as_ptr()));
            }
        }
        assert!(
            DistanceEvaluator::new(0., 8.)
                .create_child_storage(201)
                .is_empty()
        );
    }
    #[test]
    fn cancelled_before_entry_does_not_request_child_storage() {
        struct Never;
        impl StaticEvaluator for Never {
            fn create_child_storage(&self, _: usize) -> Vec<Option<EvalAccumulator>> {
                panic!("cancelled allocation")
            }
            fn evaluate(&self, _: &SigmaContext, _: Option<&EvalAccumulator>) -> Result<f32> {
                panic!("cancelled evaluation")
            }
        }
        let root = SigmaContext::from_prefix(&[]).unwrap();
        let limits = SearchLimits {
            max_depth: 200,
            max_nodes: 1,
            time_limit: None,
            tt_entries: 1,
            use_pvs: false,
            use_tt: false,
        };
        let result = search(&root, &Never, &limits, &AtomicBool::new(true)).unwrap();
        assert_eq!(result.stop, StopReason::Cancelled);
    }
    #[test]
    fn nested_search_has_its_own_pool_and_exact_parent_history() {
        let e = evaluator(7);
        let root = SigmaContext::from_prefix(&[]).unwrap();
        let before = root.history_counts();
        let limits = SearchLimits {
            max_depth: 2,
            max_nodes: 100000,
            time_limit: None,
            tt_entries: 4096,
            use_pvs: true,
            use_tt: true,
        };
        let mut callbacks = 0;
        let outer = search_with_updates(&root, &e, &limits, &AtomicBool::new(false), &mut |_| {
            let inner_limits = SearchLimits {
                max_depth: 1,
                ..limits.clone()
            };
            let inner = search(&root, &e, &inner_limits, &AtomicBool::new(false)).unwrap();
            assert_eq!(inner.completed_depth, 1);
            assert_eq!(root.history_counts(), before);
            callbacks += 1;
        })
        .unwrap();
        assert_eq!(outer.completed_depth, 2);
        assert_eq!(callbacks, 2);
        assert_eq!(root.history_counts(), before);
    }
}

#[cfg(test)]
mod merged_session_pool_tests {
    use super::*;
    use std::sync::atomic::AtomicUsize;

    #[derive(Default)]
    struct Probe {
        pools: AtomicUsize,
        advances: AtomicUsize,
        fail: AtomicBool,
    }
    impl StaticEvaluator for Probe {
        fn create_child_storage(&self, slots: usize) -> Vec<Option<EvalAccumulator>> {
            self.pools.fetch_add(1, Ordering::SeqCst);
            vec![None; slots]
        }
        fn advance_move_context(
            &self,
            _: Option<&EvalAccumulator>,
            _: &SigmaContext,
            _: &quoridor_core::research::ContextUndo,
            child: &mut Option<EvalAccumulator>,
        ) -> Result<()> {
            self.advances.fetch_add(1, Ordering::SeqCst);
            if self.fail.load(Ordering::SeqCst) {
                return Err(SearchError::Evaluation("merged-pool-probe".into()));
            }
            *child = None;
            Ok(())
        }
        fn evaluate(&self, context: &SigmaContext, _: Option<&EvalAccumulator>) -> Result<f32> {
            DistanceEvaluator::new(0., 8.).evaluate(context, None)
        }
    }
    fn namespace() -> SearchNamespace {
        SearchNamespace {
            evaluator: "merged-pool-NN0".into(),
            rules: "research-standard-2p-threefold-goal-first-v1".into(),
            selectivity: "fullwidth-PVS-MPC-OFF-v1".into(),
        }
    }
    fn legal_completion(root: &SigmaContext, result: &SearchResult) {
        assert!(result.completed_depth > 0);
        assert_eq!(result.action, result.pv.first().copied());
        let mut replay = root.clone();
        for action in &result.pv {
            replay = replay.play(*action).unwrap();
        }
    }
    #[test]
    fn persistent_completed_callback_with_pool_error_cancel_and_nested_search_nn0() {
        let root = SigmaContext::from_prefix(&[13]).unwrap();
        let history = root.history_counts();
        let position = root.position();
        let limits = SearchLimits {
            max_depth: 2,
            max_nodes: 100000,
            time_limit: None,
            tt_entries: 64,
            use_pvs: true,
            use_tt: true,
        };
        let error = Arc::new(Probe::default());
        let mut session = SearchSession::new(error.clone(), namespace(), 64).unwrap();
        let mut completions = 0;
        let failed =
            session.search_with_updates(&root, &limits, &AtomicBool::new(false), &mut |result| {
                legal_completion(&root, result);
                completions += 1;
                error.fail.store(true, Ordering::SeqCst);
            });
        assert!(matches!(failed, Err(SearchError::Evaluation(_))));
        assert_eq!(completions, 1);
        assert_eq!(root.history_counts(), history);
        assert_eq!(root.position(), position);
        assert!(error.advances.load(Ordering::SeqCst) > 0);

        let cancelled = Arc::new(Probe::default());
        let mut session = SearchSession::new(cancelled.clone(), namespace(), 64).unwrap();
        let cancel = AtomicBool::new(false);
        let stopped = session
            .search_with_updates(&root, &limits, &cancel, &mut |result| {
                legal_completion(&root, result);
                cancel.store(true, Ordering::SeqCst);
            })
            .unwrap();
        assert_eq!(stopped.stop, StopReason::Cancelled);
        assert_eq!(stopped.completed_depth, 1);
        assert_eq!(root.history_counts(), history);
        assert_eq!(root.position(), position);
        assert_eq!(cancelled.pools.load(Ordering::SeqCst), 1);

        let nested = Arc::new(Probe::default());
        let mut session = SearchSession::new(nested.clone(), namespace(), 64).unwrap();
        let inner_limits = SearchLimits {
            max_depth: 1,
            ..limits.clone()
        };
        let mut completions = 0;
        let done = session
            .search_with_updates(&root, &limits, &AtomicBool::new(false), &mut |result| {
                legal_completion(&root, result);
                let mut inner = SearchSession::new(nested.clone(), namespace(), 64).unwrap();
                let inner_done = inner
                    .search_with_updates(&root, &inner_limits, &AtomicBool::new(false), &mut |_| {})
                    .unwrap();
                legal_completion(&root, &inner_done);
                assert_eq!(inner_done.completed_depth, 1);
                assert_eq!(inner_done.stats.policy_calls, 0);
                completions += 1;
                assert_eq!(root.history_counts(), history);
            })
            .unwrap();
        assert_eq!(done.completed_depth, 2);
        assert_eq!(done.stats.policy_calls, 0);
        assert_eq!(completions, 2);
        assert_eq!(nested.pools.load(Ordering::SeqCst), 3);
        assert_eq!(root.history_counts(), history);
        assert_eq!(root.position(), position);
        assert_eq!(session.tt_capacity(), (64, 1048576));
    }
}

#[cfg(test)]
mod research_threefold_tests {
    use super::*;
    use std::sync::atomic::AtomicU64;
    include!("../../quoridor-core/tests/fixtures/research_threefold.rs");
    struct Probe {
        calls: AtomicU64,
        fail: bool,
    }
    impl StaticEvaluator for Probe {
        fn prepare_context(&self, c: &SigmaContext) -> Result<Option<EvalAccumulator>> {
            assert!(c.terminal_value().is_none(), "terminal FT setup forbidden");
            Ok(None)
        }
        fn evaluate(&self, c: &SigmaContext, _: Option<&EvalAccumulator>) -> Result<f32> {
            assert!(
                c.terminal_value().is_none(),
                "terminal evaluation forbidden"
            );
            self.calls.fetch_add(1, Ordering::Relaxed);
            if self.fail {
                Err(SearchError::Evaluation("controlled fixture".into()))
            } else {
                Ok(0.5)
            }
        }
    }
    fn limits() -> SearchLimits {
        SearchLimits {
            max_depth: 1,
            max_nodes: 1000,
            time_limit: None,
            tt_entries: 128,
            use_pvs: true,
            use_tt: true,
        }
    }
    #[test]
    fn research_threefold_terminal_bypass_and_reversible_error_cancel() {
        let parent = SigmaContext::from_prefix(&[13, 67, 4, 76, 13, 67, 4]).unwrap();
        let before = (
            parent.position(),
            parent.history_counts(),
            parent.total_ply(),
        );
        let eval = Probe {
            calls: AtomicU64::new(0),
            fail: false,
        };
        let result = search(&parent, &eval, &limits(), &AtomicBool::new(false)).unwrap();
        assert_eq!(result.action, Some(76));
        assert_eq!(result.value, Some(0.));
        assert!(result.stats.terminal > 0);
        let terminal = parent.play(76).unwrap();
        let old_calls = eval.calls.load(Ordering::Relaxed);
        let result = search(&terminal, &eval, &limits(), &AtomicBool::new(false)).unwrap();
        assert_eq!(result.stop, StopReason::Terminal);
        assert_eq!(result.value, Some(0.));
        assert_eq!(eval.calls.load(Ordering::Relaxed), old_calls);
        let failed = Probe {
            calls: AtomicU64::new(0),
            fail: true,
        };
        assert!(search(&parent, &failed, &limits(), &AtomicBool::new(false)).is_err());
        let cancelled = search(&parent, &eval, &limits(), &AtomicBool::new(true)).unwrap();
        assert_eq!(cancelled.stop, StopReason::Cancelled);
        assert_eq!(
            (
                parent.position(),
                parent.history_counts(),
                parent.total_ply()
            ),
            before
        );
    }
    #[test]
    fn research_threefold_tt_full_history_and_true_boundary_terminals() {
        let root = SigmaContext::from_prefix(&[]).unwrap();
        let second = SigmaContext::from_prefix(&[13, 67, 4, 76]).unwrap();
        assert_eq!(root.position(), second.position());
        assert_ne!(Key::of(&root), Key::of(&second));
        assert_eq!(
            Key::of(&second).ruleset.id(),
            "research-standard-2p-threefold-goal-first-v1"
        );
        let probe = Probe {
            calls: AtomicU64::new(0),
            fail: false,
        };
        for (prefix, terminal) in [
            (&NONREPEAT_CAP200, false),
            (&REPEAT_BOUNDARY200, true),
            (&GOAL_BOUNDARY200, true),
        ] {
            let c = SigmaContext::from_prefix(prefix).unwrap();
            let old_calls = probe.calls.load(Ordering::Relaxed);
            let r = search(&c, &probe, &limits(), &AtomicBool::new(false)).unwrap();
            assert_eq!(r.stop == StopReason::Terminal, terminal);
            if terminal {
                assert_eq!(probe.calls.load(Ordering::Relaxed), old_calls);
            } else {
                assert!(r.action.is_some());
            }
        }
    }
}

#[cfg(test)]
#[path = "tt_hash_reuse351_tests.rs"]
mod tt_hash_reuse351_tests;
