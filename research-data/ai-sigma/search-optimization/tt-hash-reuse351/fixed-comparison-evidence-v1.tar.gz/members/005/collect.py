"""One bounded saved-only collection; no native, geometry, or model execution."""

from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import time

H = Path(__file__).resolve().parent
R = H.parent.parent


def utc():
    return datetime.now(timezone.utc).isoformat()


def row(p):
    p = Path(p)
    s = p.stat()
    digest = hashlib.sha256()
    with p.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            digest.update(block)
    return {
        "path": str(p),
        "SHA256": digest.hexdigest(),
        "bytes": s.st_size,
        "mode": stat.S_IMODE(s.st_mode),
    }


def load(p):
    return json.loads(Path(p).read_text())


def identity_absent(identity):
    assert identity["boot_id"] == Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    try:
        text = Path(f"/proc/{identity['pid']}/stat").read_text()
    except FileNotFoundError:
        return True
    return text[text.rindex(")") + 2 :].split()[19] != identity["start_ticks"]


def main():
    started = time.monotonic()
    resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
    result = {
        "START": utc(),
        "scope": "saved-only exact owner collection",
        "CPU": 3,
        "AS_B": 536870912,
        "GPU": 0,
        "runtime_native_model_Search_game_calls": 0,
    }
    lease = None
    primary = None
    try:
        lease = Path(
            "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
        ).open("a+b")
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        result["lease_START"] = utc()
        assert (
            row(H / "worker.py")["SHA256"]
            == "312c3c0f62231981756e5ef05b761798444a2bd2b3a3c02f02bced621c492b28"
        )
        spec = importlib.util.spec_from_file_location("stopped_numeric_guard", H / "worker.py")
        w = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(w)
        parent = w.inherited()
        base = w.base_module(parent)
        g = base.guard_module()
        result["quiet"] = base.quiet(g)
        result["physical"] = w.physical()
        os.sched_setaffinity(0, {3})
        a = json.loads(gzip.decompress((H / "actual-admission.json.gz").read_bytes()))
        w.validate(a)
        outer = load(H / "runtime-v1/result.json")
        state = load(H / "runtime-v1/state.json")
        worker = load(H / "worker-result.json")
        assert outer["job_id"] == state["job_id"] == "c41aeb90-5a04-469b-942d-a5132877298c"
        assert outer["exit_code"] == 0 and outer["direct_child_reaped"] is True
        assert (
            outer["cleanup_complete"] is True
            and outer["remaining"] == []
            and outer["cleanup_errors"] == []
        )
        assert worker["status"] == "PASS_FIXED_KEY_PROCESSING" and worker["attempts"] == 1
        assert (
            worker["source_control_private_packet_after_exact"] is True
            and worker["finalization_errors"] == []
        )
        assert (
            worker["canonical_lease_released"] is True
            and worker["component_cleanup_complete"] is True
            and worker["remaining"] == []
        )
        record = worker["commands"][0]["returned_record"]
        assert record["direct_child_reaped"] is True and record["process_cleanup_complete"] is True
        assert (
            record["handle_closes_complete"] is True
            and record["remaining"] == []
            and record["finalization_errors"] == []
        )
        identities = [record["child"], state["child"], state["supervisor"]]
        result["exact_owned_identities_absent"] = [
            {**ident, "absent": identity_absent(ident)} for ident in identities
        ]
        assert all(x["absent"] for x in result["exact_owned_identities_absent"][:2])
        result["finished_supervisor_scope"] = (
            "finished controller/notifier metadata; presence does not establish computation or justify kill"
        )
        output = R / "raw/caller-software-recovery-v2/comparison.json"
        before_output = row(output)
        validation = w.validate_output()
        assert before_output == worker["validated_processing"]["output"] == validation["output"]
        data = load(output)
        methods = data["methods"]
        assert sum(len(m["captures"]) for m in methods) == 6144
        catalog = data["workload"]["observed_context_catalog"]
        assert len(catalog) == 24
        # Repeated cycle captures must use the same frozen full-key identity/hash.
        for method in methods:
            for c in range(24):
                rows = [x for x in method["captures"] if x[0] == c]
                assert len(rows) == 64 and {x[1] for x in rows} == set(range(64))
                assert len({(x[2], x[3], x[8], x[9], x[10], x[11]) for x in rows}) == 1
        ref, reuse, full, inc = [m["captures"] for m in methods]
        assert all(x[2] == y[2] for x, y in zip(ref, reuse, strict=True))
        assert all(x[2] == y[2] == x[3] for x, y in zip(full, inc, strict=True))
        # Select cycle0 independently for all four roots, not just the first root.
        first = [
            [next(x for x in m["captures"] if x[0] == c and x[1] == 0) for c in range(24)]
            for m in methods
        ]
        changing_indices = sum(
            x[2] % 4096 != y[2] % 4096 for x, y in zip(first[0], first[2], strict=True)
        )
        wall = [m["whole_state_processing_wall_ns"] for m in methods]
        persisted = load(R / "qualification/numeric-entry-v1/native.process.json")
        result.update(
            status="QUALIFIED_SAVED_FIXED_COMPARISON",
            output=before_output,
            private=a["private"],
            packet=a["packet"],
            source_compiler_control_records=[
                len(a[k]) for k in ("source_records", "compiler_records", "control_records")
            ],
            method_summary=validation["methods"],
            observations=6144,
            distinct_catalog=24,
            repeated_cycles_per_catalog=64,
            same_DefaultHash_all1536=True,
            full_incremental_Z_all1536_equal=True,
            Default_vs_Z_catalog_index_differences=changing_indices,
            sum_nested_method_wall_ns=sum(wall),
            descriptive_wall_ratios_to_reference={
                m["name"]: n / wall[0] for m, n in zip(methods, wall, strict=True)
            },
            same_key_body_entries_eliminated=1536,
            native_CPU=worker["native_CPU"],
            controller_START=state["started_at"],
            controller_STOP=outer["finished_at"],
            native_workerSTOP=worker["native_workerSTOP"],
            source_cleanup_STOP=worker["source_cleanup_STOP"],
            whole_controller_s=outer["wall_seconds"],
            nested_worker_s=worker["whole_worker_s"],
            nested_native_s=record["wall_seconds"],
            returned_finalization={
                k: record.get(k) for k in ("signal_mask_restoration", "final_record_persist")
            },
            persisted_finalization={
                k: persisted.get(k) for k in ("signal_mask_restoration", "final_record_persist")
            },
            sampled_family_RSS_B=worker["sampled"]["family_RSS_B"],
            continuous_peaks="UNKNOWN",
            TMP_absent=not w.TMP.exists(),
            fixed_nonrandom_block_count=1,
            physical_hash_instructions_per_method_CPU="UNKNOWN",
            adoption="No production Zobrist, capacity fix, measured full-Search speed or158s causal attribution; short-key descriptive wall only. Incremental path includes additional parent fullZ oracle and materialization work.",
        )
        assert result["TMP_absent"] is True
        w.validate(a)
        assert row(output) == before_output
        charges, unknown = base.charges()
        held = {
            name: max(value, w.FLOORS[name], worker["sampled"].get(name, 0))
            for name, value in charges.items()
        }
        assert all(value <= base.COMPONENTS[name] for name, value in held.items())
        assert sum(held.values()) <= 922746880
        result.update(
            current_components_B=charges,
            held_components_B=held,
            held_component_sum_B=sum(held.values()),
            transient_UNKNOWN=unknown,
            old_fees_RAW_masks_UNKNOWN="held without credit/refund",
            current_next_reservation="NONE",
            remaining=[],
        )
        selected = [
            H / "worker.py",
            H / "ports.py",
            H / "ports-result.json",
            H / "ports-guardian.json",
            H / "source-STOP.json",
            H / "actual-admission.json.gz",
            H / "job.json",
            H / "worker-result.json",
            H / "runtime-v1/state.json",
            H / "runtime-v1/config.json",
            H / "runtime-v1/result.json",
            H / "runtime-v1/output.log",
            R / "qualification/numeric-entry-v1/native.log",
            R / "qualification/numeric-entry-v1/native.process.json",
            Path(__file__).resolve(),
        ]
        result["fixed_refs"] = [row(p) for p in selected]
    except BaseException as error:
        primary = error
        result.update(
            status="COLLECTION_REFUSED_OR_FAILED",
            error={"type": type(error).__name__, "message": str(error)},
        )
    finally:
        if lease:
            try:
                lease.close()
                result["lease_released"] = True
            except BaseException as error:
                result["lease_close_error"] = repr(error)
                if primary is None:
                    primary = error
                else:
                    primary.add_note("canonical close: " + repr(error))
        result.update(
            reader_STOP=utc(),
            whole_collection_s=time.monotonic() - started,
            VmHWM=next(
                l.strip()
                for l in Path("/proc/self/status").read_text().splitlines()
                if l.startswith("VmHWM:")
            ),
        )
        encoded = (json.dumps(result, indent=2, allow_nan=False) + "\n").encode()
        assert len(encoded) <= 24576
        with (H / "collection-STOP.json").open("xb") as stream:
            stream.write(encoded)
        print(
            json.dumps(
                {
                    k: result.get(k)
                    for k in (
                        "status",
                        "reader_STOP",
                        "whole_collection_s",
                        "observations",
                        "Default_vs_Z_catalog_index_differences",
                        "held_component_sum_B",
                        "error",
                    )
                }
            ),
            flush=True,
        )
    if primary is not None:
        raise primary


if __name__ == "__main__":
    main()
