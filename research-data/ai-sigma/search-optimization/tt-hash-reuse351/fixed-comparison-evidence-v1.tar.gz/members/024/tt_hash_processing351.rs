// Compare-only task351 inlet; remove after comparison preservation/reader STOP.
// Included inside the reviewed private prototype; no production export/dispatch.
mod processing {
    use super::*;
    use serde_json::{Value, json};
    use std::{
        fs::OpenOptions,
        hint::black_box,
        io::{Read, Write},
        path::Path,
        time::Instant,
    };

    const PREFIXES: [&[u16]; 4] = [&[], &[13, 75], &[13, 75, 14, 76], &[81]];
    const CYCLES: usize = 64;
    const WORK_CAP: usize = 32_768;
    const RESULT_CAP: usize = 983_040;
    const SCHEMA: &str = "tt351-full-key-processing-v1";

    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    enum Method {
        Reference,
        Reuse,
        FullZ,
        IncrementalZ,
    }
    const METHODS: [Method; 4] = [
        Method::Reference,
        Method::Reuse,
        Method::FullZ,
        Method::IncrementalZ,
    ];
    impl Method {
        fn name(self) -> &'static str {
            match self {
                Self::Reference => "reference",
                Self::Reuse => "reuse",
                Self::FullZ => "fullZ",
                Self::IncrementalZ => "incrementalZ",
            }
        }
    }
    struct Branch {
        child: u16,
        grandchildren: [u16; 2],
    }
    struct Root {
        prefix: Vec<u16>,
        key: Key,
        branches: [Branch; 2],
        offset: usize,
    }
    struct Work {
        roots: Vec<Root>,
        keys: Vec<Key>,
        packet: Value,
    }

    fn encoded_key(k: &Key) -> Value {
        json!({"ruleset":k.ruleset.id(), "pawns":k.pawns,"stocks":k.walls,
            "horizontal":k.horizontal,"vertical":k.vertical,"STM":k.turn,
            "winner":k.winner,"total_ply":k.ply,"synthetic":k.synthetic,"counted_history":k.history})
    }
    fn first_two(c: &SigmaContext) -> std::result::Result<[u16; 2], String> {
        let ids = c.legal_ids();
        ids.get(..2)
            .map(|v| [v[0], v[1]])
            .ok_or_else(|| "fewer than two canonical legal children; no substitution".into())
    }
    fn workload() -> std::result::Result<Work, String> {
        let mut roots = Vec::new();
        let mut keys = Vec::new();
        let mut catalog = Vec::new();
        for prefix in PREFIXES {
            let c = SigmaContext::from_prefix(prefix)
                .map_err(|e| format!("fixed prefix refused: {prefix:?}: {e:?}"))?;
            c.validate_normal()
                .map_err(|e| format!("normal root: {e:?}"))?;
            let root_key = Key::of(&c);
            let children = first_two(&c)?;
            let offset = keys.len();
            let mut branches = Vec::new();
            for child in children {
                let next = c.play(child).map_err(|e| format!("catalog child: {e:?}"))?;
                let grandchildren = first_two(&next)?;
                keys.push(Key::of(&next));
                for grandchild in grandchildren {
                    keys.push(Key::of(
                        &next
                            .play(grandchild)
                            .map_err(|e| format!("catalog grandchild: {e:?}"))?,
                    ));
                }
                branches.push(Branch {
                    child,
                    grandchildren,
                });
            }
            catalog.push(json!({"prefix":prefix,"root":encoded_key(&root_key),
                "children":branches.iter().map(|b| json!([b.child,b.grandchildren])).collect::<Vec<_>>(),
                "observation_indices":(offset..keys.len()).collect::<Vec<_>>()}));
            roots.push(Root {
                prefix: prefix.to_vec(),
                key: root_key,
                branches: branches.try_into().map_err(|_| "branch count")?,
                offset,
            });
        }
        let packet = json!({"schema":SCHEMA,"cycles":CYCLES,"observations_per_method":1536,
            "total_method_observations":6144,"method_order":METHODS.map(Method::name),
            "root_catalog":catalog,"observed_context_catalog":keys.iter().map(encoded_key).collect::<Vec<_>>(),
            "Z_version":Z_VERSION,"Z_seed":Z_SEED,"Z_domain":Z_DOMAIN,
            "direct_index_slots":4096,"numeric_entry_authority":"external guardian required",
            "counter_version":"wrapper-body-entries-v1; not physical instructions",
            "reference_default_requests":3072,"reuse_default_requests":1536,"fullZ_requests":1536,
            "incremental_setup_requests":256,"forward_and_reverse_each_per_method":1536});
        Ok(Work {
            roots,
            keys,
            packet,
        })
    }
    fn accept_packet(w: &Work, supplied: &Value) -> std::result::Result<(), String> {
        if supplied != &w.packet {
            return Err("exact workload packet mismatch (including unknown/missing fields)".into());
        }
        Ok(())
    }

    #[derive(Default)]
    struct Metrics {
        observations: u64,
        default_requests: u64,
        default_body_entries: u64,
        full_z_requests: u64,
        full_z_body_entries: u64,
        incremental_reads: u64,
        incremental_setup_entries: u64,
        forward: u64,
        reverse: u64,
        independent_key_constructions: u64,
        independent_z_oracles: u64,
        exact_key_checks: u64,
        parent_checks: u64,
        parent_key_constructions: u64,
        parent_z_oracles: u64,
        context_from_prefix: u64,
        cursor_clones: u64,
        prefix_replay_actions: u64,
        output_key_constructions: u64,
        output_key_clones: u64,
        requested_full_z_feature_terms: u64,
    }
    impl Metrics {
        fn json(&self) -> Value {
            json!({"observations":self.observations,"default_requests":self.default_requests,
                "instrumented_default_body_entries":self.default_body_entries,
                "fullZ_requests":self.full_z_requests,"instrumented_fullZ_body_entries":self.full_z_body_entries,
                "incremental_hash_reads":self.incremental_reads,"incremental_constructor_entries":self.incremental_setup_entries,
                "forward":self.forward,"reverse":self.reverse,
                "independent_key_constructions":self.independent_key_constructions,
                "independent_fullZ_oracles":self.independent_z_oracles,"exact_key_checks":self.exact_key_checks,
                "parent_checks":self.parent_checks,
                "parent_key_constructions":self.parent_key_constructions,"parent_fullZ_oracles":self.parent_z_oracles,
                "context_from_prefix":self.context_from_prefix,"explicit_cursor_clones":self.cursor_clones,"prefix_replay_actions":self.prefix_replay_actions,"output_key_constructions":self.output_key_constructions,
                "output_key_clones":self.output_key_clones,
                "requested_fullZ_feature_terms":self.requested_full_z_feature_terms,
                "feature_terms_scope":"source-formula for observed fullZ calls only; excludes scratch setup/update/oracle",
                "physical_hash_computations_instructions":"UNKNOWN"})
        }
    }
    // Each instrumented body delegates the SAME existing algorithm. Counts are
    // these no-inline body entries and requests, not a hardware instruction proof.
    #[inline(never)]
    fn default_body(k: &Key, m: &mut Metrics) -> u64 {
        m.default_body_entries += 1;
        black_box(black_box(k).hash())
    }
    #[inline(never)]
    fn full_z_body(k: &Key, m: &mut Metrics) -> u64 {
        m.full_z_body_entries += 1;
        black_box(full_hash(black_box(k)))
    }
    #[inline(never)]
    fn scratch_body(
        c: &SigmaContext,
        m: &mut Metrics,
    ) -> std::result::Result<ZScratch, &'static str> {
        m.incremental_setup_entries += 1;
        // The shared constructor contains one full initial hash; this counter
        // observes constructor entries, not its feature calls/instructions.
        ZScratch::new(black_box(c), 2)
    }
    #[derive(Clone)]
    struct Capture {
        catalog: usize,
        cycle: usize,
        hash: u64,
        oracle: u64,
        owned_cap: usize,
        owned_bytes: usize,
        path_bytes: usize,
        scratch_cap: Option<usize>,
        history_items: usize,
        total_counts: u64,
        ply: u16,
        stm: u8,
    }
    impl Capture {
        fn json(&self) -> Value {
            json!([
                self.catalog,
                self.cycle,
                self.hash,
                self.oracle,
                self.owned_cap,
                self.owned_bytes,
                self.path_bytes,
                self.scratch_cap,
                self.history_items,
                self.total_counts,
                self.ply,
                self.stm
            ])
        }
    }
    struct Run {
        method: Method,
        metrics: Metrics,
        captures: Vec<Capture>,
        whole_ns: Option<u64>,
    }

    struct Observation<'a> {
        method: Method,
        cursor: &'a SigmaContext,
        scratch: Option<&'a ZScratch>,
        expected: &'a Key,
        catalog: usize,
        cycle: usize,
    }
    fn observe(
        o: Observation<'_>,
        m: &mut Metrics,
        out: &mut Vec<Capture>,
    ) -> std::result::Result<(), BranchError> {
        let Observation {
            method,
            cursor: c,
            scratch,
            expected,
            catalog,
            cycle,
        } = o;
        let owned = if let Some(z) = scratch {
            m.output_key_clones += 1;
            black_box(z.key.clone())
        } else {
            m.output_key_constructions += 1;
            black_box(Key::of(black_box(c)))
        };
        // Independent catalog construction used play, not this make/unmake walk.
        m.independent_key_constructions += 1;
        let canonical = Key::of(c);
        m.exact_key_checks += 2;
        if owned != *expected || owned != canonical {
            return Err(BranchError::primary("full Key/context mismatch"));
        }
        m.independent_z_oracles += 1;
        let oracle = black_box(full_oracle(&owned));
        let hash = match method {
            Method::Reference => {
                m.default_requests += 2;
                let first = default_body(&owned, m);
                let second = default_body(&owned, m);
                if first != second {
                    return Err(BranchError::primary("same-owned hash mismatch"));
                }
                first
            }
            Method::Reuse => {
                m.default_requests += 1;
                default_body(&owned, m)
            }
            Method::FullZ => {
                m.full_z_requests += 1;
                m.requested_full_z_feature_terms += 11
                    + u64::from(owned.horizontal.count_ones() + owned.vertical.count_ones())
                    + 9 * owned.history.len() as u64;
                let h = full_z_body(&owned, m);
                if h != oracle {
                    return Err(BranchError::primary("fullZ oracle mismatch"));
                }
                h
            }
            Method::IncrementalZ => {
                m.incremental_reads += 1;
                let h = black_box(
                    scratch
                        .ok_or_else(|| BranchError::primary("missing owned scratch"))?
                        .hash,
                );
                if h != oracle {
                    return Err(BranchError::primary("incremental oracle mismatch"));
                }
                h
            }
        };
        let cap = owned.history.capacity();
        let path_bytes = c.path_allocated_bytes();
        let scratch_cap = scratch.map(|z| z.key.history.capacity());
        // Output budget predicates, not a replacement for canonical history or
        // a search/path policy. Refuse an unexpected representation, don't clip.
        if cap > 1024 || path_bytes > 65535 || scratch_cap.is_some_and(|n| n > 1024) {
            return Err(BranchError::primary("output capacity representation"));
        }
        out.push(Capture {
            catalog,
            cycle,
            hash,
            oracle,
            owned_cap: cap,
            owned_bytes: cap * std::mem::size_of::<([u8; 2], u8, u64, u64, u16)>(),
            path_bytes,
            scratch_cap,
            history_items: owned.history.len(),
            total_counts: owned.history.iter().map(|e| u64::from(e.5)).sum(),
            ply: owned.ply,
            stm: owned.turn,
        });
        m.observations += 1;
        drop(canonical);
        drop(owned);
        Ok(())
    }
    fn canonical_child<T>(
        c: &mut SigmaContext,
        id: u16,
        m: &mut Metrics,
        f: impl FnOnce(&mut SigmaContext, &mut Metrics) -> std::result::Result<T, BranchError>,
    ) -> std::result::Result<T, BranchError> {
        let parent_depth = usize::from(c.total_ply());
        let undo = c
            .make_move(id)
            .map_err(|_| BranchError::primary("canonical make"))?;
        m.forward += 1;
        let result = f(c, m);
        let restored = c.unmake_move(undo);
        if restored.is_ok() {
            m.reverse += 1;
        }
        match (result, restored) {
            (Err(mut primary), Err(_)) => {
                primary.restorations.push(RestorationFailure {
                    stage: "canonical unmake (absolute ply)",
                    requested_parent_depth: parent_depth,
                    observed_depth: usize::from(c.total_ply()),
                    cause: "canonical unmake",
                });
                Err(primary)
            }
            (Ok(_), Err(_)) => {
                let mut e = BranchError::primary("canonical unmake");
                e.restorations.push(RestorationFailure {
                    stage: "canonical unmake (absolute ply)",
                    requested_parent_depth: parent_depth,
                    observed_depth: usize::from(c.total_ply()),
                    cause: "canonical unmake",
                });
                Err(e)
            }
            (Err(e), Ok(())) => Err(e),
            (Ok(v), Ok(())) => Ok(v),
        }
    }
    fn normal_cycle(
        method: Method,
        c: &mut SigmaContext,
        root: &Root,
        work: &Work,
        cycle: usize,
        m: &mut Metrics,
        out: &mut Vec<Capture>,
    ) -> std::result::Result<(), BranchError> {
        for (branch_id, branch) in root.branches.iter().enumerate() {
            let base = root.offset + branch_id * 3;
            canonical_child(c, branch.child, m, |child, m| {
                observe(
                    Observation {
                        method,
                        cursor: child,
                        scratch: None,
                        expected: &work.keys[base],
                        catalog: base,
                        cycle,
                    },
                    m,
                    out,
                )?;
                for (n, id) in branch.grandchildren.iter().enumerate() {
                    canonical_child(child, *id, m, |grand, m| {
                        observe(
                            Observation {
                                method,
                                cursor: grand,
                                scratch: None,
                                expected: &work.keys[base + n + 1],
                                catalog: base + n + 1,
                                cycle,
                            },
                            m,
                            out,
                        )
                    })?;
                    m.parent_checks += 1;
                    m.parent_key_constructions += 1;
                    if Key::of(child) != work.keys[base] {
                        return Err(BranchError::primary("grandparent restoration"));
                    }
                }
                Ok(())
            })?;
            m.parent_checks += 1;
            m.parent_key_constructions += 1;
            if Key::of(c) != root.key {
                return Err(BranchError::primary("root restoration"));
            }
        }
        Ok(())
    }
    fn incremental_cycle(
        z: &mut ZScratch,
        root: &Root,
        work: &Work,
        cycle: usize,
        m: &mut Metrics,
        out: &mut Vec<Capture>,
    ) -> std::result::Result<(), BranchError> {
        for (branch_id, branch) in root.branches.iter().enumerate() {
            let base = root.offset + branch_id * 3;
            z.with_child(branch.child, |child| {
                m.forward += 1;
                observe(
                    Observation {
                        method: Method::IncrementalZ,
                        cursor: &child.cursor,
                        scratch: Some(child),
                        expected: &work.keys[base],
                        catalog: base,
                        cycle,
                    },
                    m,
                    out,
                )?;
                for (n, id) in branch.grandchildren.iter().enumerate() {
                    child.with_child(*id, |grand| {
                        m.forward += 1;
                        observe(
                            Observation {
                                method: Method::IncrementalZ,
                                cursor: &grand.cursor,
                                scratch: Some(grand),
                                expected: &work.keys[base + n + 1],
                                catalog: base + n + 1,
                                cycle,
                            },
                            m,
                            out,
                        )
                    })?;
                    m.reverse += 1;
                    m.parent_checks += 1;
                    m.parent_key_constructions += 1;
                    m.parent_z_oracles += 1;
                    if child.key != work.keys[base]
                        || Key::of(&child.cursor) != work.keys[base]
                        || child.hash != full_oracle(&child.key)
                    {
                        return Err(BranchError::primary("incremental parent restoration"));
                    }
                }
                Ok(())
            })?;
            m.reverse += 1;
            m.parent_checks += 1;
            m.parent_key_constructions += 1;
            m.parent_z_oracles += 1;
            if z.depth != 0
                || z.key != root.key
                || Key::of(&z.cursor) != root.key
                || z.hash != full_oracle(&z.key)
            {
                return Err(BranchError::primary("incremental root restoration"));
            }
        }
        Ok(())
    }
    fn run_method(
        method: Method,
        work: &Work,
        cycles: usize,
        measure: bool,
    ) -> std::result::Result<Run, BranchError> {
        let clock = measure.then(Instant::now);
        let mut metrics = Metrics::default();
        let mut captures = Vec::with_capacity(work.roots.len() * cycles * 6);
        for root in &work.roots {
            for cycle in 0..cycles {
                // No retained context/scratch between cycles. Whole spans include
                // genuine prefix, context clone, setup and ephemeral state drop.
                metrics.context_from_prefix += 1;
                metrics.cursor_clones += 1;
                metrics.prefix_replay_actions += root.prefix.len() as u64;
                let c = SigmaContext::from_prefix(&root.prefix)
                    .map_err(|_| BranchError::primary("fixed prefix"))?;
                if method == Method::IncrementalZ {
                    let mut z = scratch_body(&c, &mut metrics).map_err(BranchError::primary)?;
                    incremental_cycle(&mut z, root, work, cycle, &mut metrics, &mut captures)?;
                    drop(z);
                } else {
                    let mut cursor = c.clone();
                    normal_cycle(
                        method,
                        &mut cursor,
                        root,
                        work,
                        cycle,
                        &mut metrics,
                        &mut captures,
                    )?;
                    drop(cursor);
                }
                drop(c);
            }
        }
        // Charge local capture allocation/copy/drop here. The transferred
        // evidence copy's serialization/final drop belongs to the whole process.
        let preserved = captures.clone();
        drop(black_box(captures));
        let whole_ns = clock
            .map(|t| u64::try_from(t.elapsed().as_nanos()).expect("finite method nanoseconds"));
        Ok(Run {
            method,
            metrics,
            captures: preserved,
            whole_ns,
        })
    }
    fn validate_runs(runs: &[Run], cycles: usize) -> std::result::Result<(), String> {
        let n = 4 * cycles * 6;
        if runs.len() != 4 {
            return Err("four methods required".into());
        }
        for (index, run) in runs.iter().enumerate() {
            if run.method != METHODS[index]
                || run.captures.len() != n
                || run.metrics.observations != n as u64
                || run.metrics.forward != n as u64
                || run.metrics.reverse != n as u64
            {
                return Err("observation/update census".into());
            }
            for (a, b) in runs[0].captures.iter().zip(&run.captures) {
                if (
                    a.catalog,
                    a.cycle,
                    a.oracle,
                    a.history_items,
                    a.total_counts,
                    a.ply,
                    a.stm,
                ) != (
                    b.catalog,
                    b.cycle,
                    b.oracle,
                    b.history_items,
                    b.total_counts,
                    b.ply,
                    b.stm,
                ) {
                    return Err("cross-method observation identity".into());
                }
                if index == 1 && a.hash != b.hash {
                    return Err("existing hash equality".into());
                }
                if index >= 2 && b.hash != b.oracle {
                    return Err("Zobrist oracle equality".into());
                }
            }
        }
        if runs[0].metrics.default_requests != 2 * n as u64
            || runs[0].metrics.default_body_entries != 2 * n as u64
            || runs[1].metrics.default_requests != n as u64
            || runs[1].metrics.default_body_entries != n as u64
            || runs[2].metrics.full_z_requests != n as u64
            || runs[2].metrics.full_z_body_entries != n as u64
            || runs[3].metrics.incremental_reads != n as u64
            || runs[3].metrics.incremental_setup_entries != (4 * cycles) as u64
        {
            return Err("instrumented processing census".into());
        }
        Ok(())
    }
    struct Limited {
        bytes: Vec<u8>,
        limit: usize,
    }
    impl Write for Limited {
        fn write(&mut self, b: &[u8]) -> std::io::Result<usize> {
            if self.bytes.len().saturating_add(b.len()) > self.limit {
                return Err(std::io::Error::other("inclusive output cap"));
            }
            self.bytes.extend_from_slice(b);
            Ok(b.len())
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }
    fn output(value: &Value, path: &Path, limit: usize) -> std::result::Result<(), String> {
        let mut bytes = Limited {
            bytes: Vec::new(),
            limit,
        };
        serde_json::to_writer(&mut bytes, value)
            .map_err(|e| format!("bounded serialization: {e}"))?;
        bytes.write_all(b"\n").map_err(|e| e.to_string())?;
        // Unique output only; an IO failure retains its possibly partial bytes.
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(path)
            .map_err(|e| e.to_string())?;
        file.write_all(&bytes.bytes).map_err(|e| e.to_string())?;
        file.sync_all().map_err(|e| e.to_string())
    }
    fn decode_reader(
        reader: impl Read,
        reported_len: u64,
        expected: &Value,
    ) -> std::result::Result<Value, String> {
        if reported_len > WORK_CAP as u64 {
            return Err("input metadata cap".into());
        }
        let mut bytes = Vec::new();
        reader
            .take(WORK_CAP as u64 + 1)
            .read_to_end(&mut bytes)
            .map_err(|e| e.to_string())?;
        if bytes.len() > WORK_CAP {
            return Err("input growth cap".into());
        }
        let mut encoded = Limited {
            bytes: Vec::new(),
            limit: WORK_CAP,
        };
        serde_json::to_writer(&mut encoded, expected).map_err(|e| e.to_string())?;
        encoded.write_all(b"\n").map_err(|e| e.to_string())?;
        if bytes != encoded.bytes {
            return Err(
                "exact frozen serialization mismatch; duplicates/format changes refused".into(),
            );
        }
        serde_json::from_slice(&bytes).map_err(|e| e.to_string())
    }
    fn input(path: &Path, expected: &Value) -> std::result::Result<Value, String> {
        let file = std::fs::File::open(path).map_err(|e| e.to_string())?;
        let reported_len = file.metadata().map_err(|e| e.to_string())?.len();
        decode_reader(file, reported_len, expected)
    }
    fn require_absence(metadata: std::io::Result<()>) -> std::result::Result<(), String> {
        match metadata {
            Ok(()) => Err("output entry exists".into()),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
            Err(e) => Err(format!("output metadata refusal: {e}")),
        }
    }
    fn inlet(mode: &str, packet: Option<&Path>, result: &Path) -> std::result::Result<(), String> {
        if !matches!(mode, "freeze-workload" | "compare") {
            return Err("explicit fixed mode required".into());
        }
        if !result.is_absolute() || packet.is_some_and(|p| !p.is_absolute()) {
            return Err("absolute unique output and absolute frozen packet required".into());
        }
        // Inspect the final ENTRY, including a dangling symlink. Only an
        // affirmative NotFound permits work; create_new still guards races.
        require_absence(std::fs::symlink_metadata(result).map(|_| ()))?;
        let work = workload()?;
        if mode == "freeze-workload" {
            if packet.is_some() {
                return Err("freeze accepts no packet".into());
            }
            return output(&work.packet, result, WORK_CAP);
        }
        accept_packet(
            &work,
            &input(packet.ok_or("missing frozen packet")?, &work.packet)?,
        )?;
        let mut runs = Vec::new();
        for method in METHODS {
            runs.push(
                run_method(method, &work, CYCLES, true)
                    .map_err(|e| format!("processing failure: {e:?}"))?,
            );
        }
        validate_runs(&runs, CYCLES)?;
        let value = json!({"schema":SCHEMA,"status":"all_methods_completed_validated",
            "workload":work.packet,"method_order":METHODS.map(Method::name),
            "capture_columns":["catalog","cycle","hash","independent_Z_oracle","owned_history_capacity",
                "owned_TT_history_charge_B","canonical_overlay_B","scratch_history_capacity","history_items","count_sum","ply","STM"],
            "direct_index":"hash % 4096; derive per capture, no Table/Search instantiated",
            "methods":runs.iter().map(|run| json!({"name":run.method.name(),"whole_state_processing_wall_ns":run.whole_ns,
                "metrics":run.metrics.json(),"captures":run.captures.iter().map(Capture::json).collect::<Vec<_>>()})).collect::<Vec<_>>(),
            "measurement":"state setup/clone/update/materialization/oracles/capture included; retained capture buffers, workload/output JSON/validation and final drop charged to whole external process",
            "per_method_CPU":"UNKNOWN; wall only, external process accounting required",
            "compiled_image_source_resources_identity":"external guardian must bind exact executable/source/packet/env; not self-certified",
            "search_model_game_calls":0,"production_Zobrist":false,"physical_hash_computations":"UNKNOWN"});
        output(&value, result, RESULT_CAP)
    }

    #[test]
    #[ignore = "explicit guardian-owned freeze or one fixed compare; never ordinary suite execution"]
    fn tt351_compare_only_full_key() {
        let mode = std::env::var("TT351_MODE").expect("explicit mode");
        let packet = std::env::var_os("TT351_PACKET").map(std::path::PathBuf::from);
        let result = std::env::var_os("TT351_OUTPUT")
            .map(std::path::PathBuf::from)
            .expect("unique output");
        inlet(&mode, packet.as_deref(), &result)
            .expect("fixed inlet refused; retain raw/partial IO, no retry");
    }
    #[test]
    fn tt351_caller_packet_exactness() {
        let work = workload().unwrap();
        assert_eq!(work.keys.len(), 24);
        accept_packet(&work, &work.packet).unwrap();
        let mut altered = work.packet.clone();
        altered["unknown"] = json!(true);
        assert!(accept_packet(&work, &altered).is_err());
        altered = work.packet.clone();
        altered["cycles"] = json!(65);
        assert!(accept_packet(&work, &altered).is_err());
        altered = work.packet.clone();
        altered["observed_context_catalog"][0]["counted_history"][0][5] = json!(3);
        assert!(accept_packet(&work, &altered).is_err());
        // Exercise the SAME bounded reader/byte decoder delegated to by input.
        let canonical = format!("{}\n", work.packet).into_bytes();
        assert_eq!(
            decode_reader(
                std::io::Cursor::new(&canonical),
                canonical.len() as u64,
                &work.packet
            )
            .unwrap(),
            work.packet
        );
        let whitespace = serde_json::to_vec_pretty(&work.packet).unwrap();
        assert_eq!(
            serde_json::from_slice::<Value>(&whitespace).unwrap(),
            work.packet
        );
        assert!(
            decode_reader(
                std::io::Cursor::new(&whitespace),
                whitespace.len() as u64,
                &work.packet
            )
            .is_err()
        );
        let expected = json!({"marker": 1});
        let duplicate = b"{\"marker\":1,\"marker\":1}\n";
        assert_eq!(
            serde_json::from_slice::<Value>(duplicate).unwrap(),
            expected
        );
        assert!(
            decode_reader(
                std::io::Cursor::new(duplicate),
                duplicate.len() as u64,
                &expected
            )
            .is_err()
        );
        struct MustNotRead;
        impl Read for MustNotRead {
            fn read(&mut self, _: &mut [u8]) -> std::io::Result<usize> {
                panic!("metadata refusal must precede reads");
            }
        }
        assert_eq!(
            decode_reader(MustNotRead, WORK_CAP as u64 + 1, &expected).unwrap_err(),
            "input metadata cap"
        );
        let growing = vec![b' '; WORK_CAP + 1];
        assert_eq!(
            decode_reader(std::io::Cursor::new(growing), 0, &expected).unwrap_err(),
            "input growth cap"
        );
    }
    #[test]
    fn tt351_caller_counts_identity_and_restore() {
        let work = workload().unwrap();
        // Exactly one untimed qualification cycle; never the64-cycle campaign.
        let runs = METHODS.map(|m| run_method(m, &work, 1, false).unwrap());
        validate_runs(&runs, 1).unwrap();
        assert!(runs.iter().all(|r| r.whole_ns.is_none()));
        assert_eq!(runs[0].metrics.default_body_entries, 48);
        assert_eq!(runs[1].metrics.default_body_entries, 24);
        assert_eq!(runs[2].metrics.full_z_body_entries, 24);
        assert_eq!(runs[3].metrics.incremental_setup_entries, 4);
    }
    #[test]
    fn tt351_caller_mode_and_output_guard() {
        assert!(inlet("other", None, Path::new("must-not-write")).is_err());
        let mut bounded = Limited {
            bytes: vec![0; WORK_CAP - 1],
            limit: WORK_CAP,
        };
        assert!(bounded.write_all(&[1, 2]).is_err());
        assert_eq!(bounded.bytes.len(), WORK_CAP - 1);
        assert!(require_absence(Ok(())).is_err());
        assert!(require_absence(Err(std::io::Error::from(std::io::ErrorKind::NotFound))).is_ok());
        for kind in [
            std::io::ErrorKind::PermissionDenied,
            std::io::ErrorKind::Other,
        ] {
            assert!(
                require_absence(Err(std::io::Error::from(kind)))
                    .unwrap_err()
                    .contains("output metadata refusal")
            );
        }
        // The guardian provides this bounded owned TMP namespace. If an
        // assertion/IO fails, leave owned partial fixtures for its census.
        let tmp = std::path::PathBuf::from(std::env::var_os("TMPDIR").expect("owned TMPDIR"));
        assert!(tmp.is_absolute());
        let fixture = tmp.join(format!("tt351-output-guard-{}", std::process::id()));
        std::fs::create_dir(&fixture).unwrap();
        let file = fixture.join("existing");
        std::fs::write(&file, b"owned").unwrap();
        for existing in [&file, &fixture] {
            assert_eq!(
                inlet("compare", None, existing).unwrap_err(),
                "output entry exists"
            );
        }
        #[cfg(unix)]
        {
            let dangling = fixture.join("dangling");
            std::os::unix::fs::symlink(fixture.join("absent-owned-target"), &dangling).unwrap();
            assert_eq!(
                inlet("compare", None, &dangling).unwrap_err(),
                "output entry exists"
            );
            std::fs::remove_file(dangling).unwrap();
        }
        std::fs::remove_file(file).unwrap();
        std::fs::remove_dir(fixture).unwrap();
    }
}
