"""New guardian boundary ports only; no native/process/runtime imports."""

import ast
import hashlib
import json
import math
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def helper(name, namespace):
    tree = ast.parse((HERE / "worker.py").read_text())
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    exec(
        compile(ast.Module(body=[node], type_ignores=[]), str(HERE / "worker.py"), "exec"),
        namespace,
    )
    return namespace[name]


def main():
    started = time.monotonic()
    outcomes = []
    cpu = helper("cpu_account", {"math": math})
    before = {"user_s": 3.0, "system_s": 1.0, "ru_maxrss_KiB": 900}
    after = {"user_s": 3.25, "system_s": 1.125, "ru_maxrss_KiB": 900}
    good = {
        "child": {"pid": 10},
        "direct_child_reaped": True,
        "cleanup_complete": True,
        "remaining": [],
    }
    accepted = cpu(before, after, good, 1, [], [])
    assert accepted["status"] == "BOUNDED_ONE_CHILD_DELTA"
    assert accepted["total_s"] == 0.375 and "ru_maxrss_KiB" not in accepted
    outcomes.append("exact-one-reaped delta and nonsubtracted highwater")
    cases = [
        (good, 0, [], [], after),
        (good, 2, [], [], after),
        (good, 1, [11], [], after),
        (good, 1, [], [11], after),
        ({**good, "direct_child_reaped": False}, 1, [], [], after),
        ({**good, "cleanup_complete": False}, 1, [], [], after),
        ({**good, "remaining": [11]}, 1, [], [], after),
        ({}, 1, [], [], after),
        (good, 1, [], [], {**after, "user_s": float("nan")}),
        (good, 1, [], [], {**after, "system_s": 0.0}),
    ]
    for i, (record, attempts, initial, final, end) in enumerate(cases):
        assert cpu(before, end, record, attempts, initial, final)["status"] == "UNKNOWN"
        outcomes.append(f"CPU-refusal-{i}")

    # Execute the actual prepare function with fake ports. All three secondary
    # failures must retain the original flock exception object; no real open.
    primary = PermissionError("original lease refusal")
    closed = []
    emitted = []

    class Lease:
        def close(self):
            closed.append(True)
            raise OSError("close refusal")

    class Lock:
        def open(self, _mode):
            return Lease()

    class Fcntl:
        LOCK_EX = 1
        LOCK_NB = 2

        @staticmethod
        def flock(*_args):
            raise primary

    def save(*_args):
        raise OSError("persistence refusal")

    def printing(value, **_kwargs):
        emitted.append(json.loads(value))
        raise OSError("stdout refusal")

    prepare = helper(
        "prepare",
        {
            "utc": lambda: "PORT",
            "LOCK": Lock(),
            "fcntl": Fcntl,
            "save": save,
            "print": printing,
            "json": json,
        },
    )
    try:
        prepare()
    except BaseException as error:
        assert error is primary
        assert len(error.__notes__) == 3
        assert all(
            any(stage in note for note in error.__notes__)
            for stage in ("canonical close", "preentry result persistence", "preentry stdout")
        )
    else:
        raise AssertionError("primary disappeared")
    assert closed == [True] and len(emitted) == 1
    assert emitted[0]["entry_ready"] is False and emitted[0].get("lease_released") is not True
    outcomes.append("primary-object and independent close/persist/stdout attempts")

    # Exact admitted control rows must retain inherited identities before live
    # checking; an omitted/altered/duplicate row must not be legitimized by row().
    parent = {
        "source_records": [],
        "compiler_records": [],
        "control_records": [{"path": "old", "SHA256": "fixed", "bytes": 4, "mode": 420}],
        "Cargo_configs_absent": [],
    }
    private, packet = Path("private"), Path("packet")
    old = parent["control_records"][0]
    contract = {"argv": ["fake"], "unset_env": []}
    rows = {"old": old, "private": {"path": "private"}, "packet": {"path": "packet"}}
    live = []

    def row(path):
        live.append(str(path))
        return rows[str(path)]

    validate = helper(
        "validate",
        {
            "inherited": lambda: parent,
            "controls": lambda _p: [Path("old")],
            "FLOORS": {},
            "load": lambda _p: contract,
            "CONTRACT": None,
            "planned_env": lambda: {},
            "PRIVATE": private,
            "PACKET": packet,
            "row": row,
            "static_conditions": lambda: None,
            "Path": Path,
        },
    )
    admission = {
        "entry_ready": True,
        "source_records": [],
        "compiler_records": [],
        "control_records": [old],
        "floors_B": {},
        "worker_seconds": 180,
        "argv": ["fake"],
        "env": {},
        "unset_env": [],
        "private": rows["private"],
        "packet": rows["packet"],
    }
    assert validate(admission) is parent
    outcomes.append("matching exact control map")
    for records in ([], [old, old], [{**old, "SHA256": "changed"}], [old, {"path": "extra"}]):
        live.clear()
        try:
            validate({**admission, "control_records": records})
        except AssertionError:
            assert live == []
        else:
            raise AssertionError("invalid map accepted")
        outcomes.append("map-refusal-before-live-read")
    status = next(
        l.strip()
        for l in Path("/proc/self/status").read_text().splitlines()
        if l.startswith("VmHWM:")
    )
    result = {
        "scope": "actual helper AST new fake CPU/map/preentry ports; no real Popen/native/model/runtime/library/geometry",
        "PASS": len(outcomes),
        "cases": outcomes,
        "whole_s": time.monotonic() - started,
        "VmHWM": status,
        "owned_runtime_children": [],
        "source_SHA256": hashlib.sha256((HERE / "worker.py").read_bytes()).hexdigest(),
    }
    encoded = (json.dumps(result, indent=2) + "\n").encode()
    assert len(encoded) <= 8192
    with (HERE / "ports-result.json").open("xb") as stream:
        stream.write(encoded)
    sys.stdout.write(json.dumps(result) + "\n")


if __name__ == "__main__":
    main()
