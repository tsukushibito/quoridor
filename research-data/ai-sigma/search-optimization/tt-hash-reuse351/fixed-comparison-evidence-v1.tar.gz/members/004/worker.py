"""One fixed full-Key comparison; maintained lifetime controls, no replay."""

from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import importlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import stat
import sys
import time


W = Path("/workspaces/quoridor/.worktree/tt-hash-reuse351")
ROOT = W / ".artifacts/tt-hash-reuse351"
HERE = Path(__file__).resolve().parent
SOFTWARE = ROOT / "controls/caller-software-entry-v1/recovery-v2"
BASE = ROOT / "controls/caller-software-entry-v1/worker.py"
INHERITED = SOFTWARE / "actual-admission.json.gz"
CONTRACT = ROOT / "source-control/numeric-entry-preparation-v1/entry-contract.json"
NOTE = CONTRACT.parent / "accounting-scope-note.json"
CANON = Path("/workspaces/quoridor/research-data/ai-sigma/search-optimization/tt-hash-reuse351")
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
PRIVATE = ROOT / "private/tt351-processing"
PACKET = ROOT / "raw/caller-software-recovery-v2/workload.json"
OUTPUT = PACKET.parent / "comparison.json"
TMP = ROOT / "TMP/key-comparison-v1"
QUAL = ROOT / "qualification/numeric-entry-v1"
SUPPORT_SHA = "1b8716fc08d7c13ad93ddaa3bbaf835d09626086ffc42a0c057aba8cf8eb45c3"
SOURCE_ADMISSION_SHA = "d1510bc323b7483ecaca389cfed17e6213354b67b2e89328113df5976c4a1559"
RECEIPT_SHA = "de7b9982b42a7d30c04b178a50f5daaf5bfa71ac0ea4fa9e5c9900ce1fcda256"
PRIVATE_SHA = "77280319cb5716b5c5b6159675cfb61fdfe95d4541397ad98d02fe0da356ae7c"
PACKET_SHA = "69b926ebedb0959ede3ae433ffea6abf202d868873809f5edd8ffadfbdea0916"
FLOORS = {
    "source": 4014080,
    "target": 695840768,
    "private": 10485760,
    "TMP": 1138688,
    "qualification": 180224,
    "raw": 24576,
    "failures": 0,
    "review": 0,
    "RootGitcleanup": 0,
}
COLUMNS = [
    "catalog",
    "cycle",
    "hash",
    "independent_Z_oracle",
    "owned_history_capacity",
    "owned_TT_history_charge_B",
    "canonical_overlay_B",
    "scratch_history_capacity",
    "history_items",
    "count_sum",
    "ply",
    "STM",
]
METHODS = ["reference", "reuse", "fullZ", "incrementalZ"]


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(p):
    h = hashlib.sha256()
    with Path(p).open("rb") as f:
        for chunk in iter(lambda: f.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()


def row(p):
    p = Path(p)
    s = p.stat()
    return {"path": str(p), "SHA256": sha(p), "bytes": s.st_size, "mode": stat.S_IMODE(s.st_mode)}


def load(p):
    return json.loads(Path(p).read_text())


def save(name, value):
    data = (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()
    assert len(data) <= 32768, "bounded control receipt"
    with (HERE / name).open("xb") as f:
        f.write(data)


def inherited():
    assert sha(INHERITED) == SOURCE_ADMISSION_SHA
    return json.loads(gzip.decompress(INHERITED.read_bytes()))


def base_module(a):
    expected = next(v for v in a["control_records"] if v["path"] == str(BASE))
    assert row(BASE) == expected
    spec = importlib.util.spec_from_file_location("stopped_owned_guard", BASE)
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    return base


def physical():
    available = next(
        int(l.split()[1]) * 1024
        for l in Path("/proc/meminfo").read_text().splitlines()
        if l.startswith("MemAvailable:")
    )
    cgroup = Path("/sys/fs/cgroup")
    limit = (cgroup / "memory.max").read_text().strip()
    if limit != "max":
        available = min(
            available, max(0, int(limit) - int((cgroup / "memory.current").read_text()))
        )
    assert available >= 2147483648 + 4294967296, "family2GiB+host4GiB unsupported"
    assert {0, 2} <= os.sched_getaffinity(0)
    topology = {}
    for cpu in (0, 2):
        p = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        topology[str(cpu)] = {
            k: (p / k).read_text().strip()
            for k in ("physical_package_id", "core_id", "thread_siblings_list")
        }
    assert (topology["0"]["physical_package_id"], topology["0"]["core_id"]) != (
        topology["2"]["physical_package_id"],
        topology["2"]["core_id"],
    )
    quota = (cgroup / "cpu.max").read_text().split()
    assert quota[0] == "max" or int(quota[0]) >= int(quota[1])
    return {
        "UTC": utc(),
        "available_B": available,
        "CPU": topology,
        "cpu.max": " ".join(quota),
        "kernel": os.uname().release,
    }


def controls(a):
    paths = [Path(v["path"]) for v in a["control_records"]]
    paths += [
        Path(__file__).resolve(),
        HERE / "ports.py",
        HERE / "ports-result.json",
        HERE / "prewrite.json",
        INHERITED,
        CONTRACT,
        NOTE,
        SOFTWARE / "qualified-software-STOP.json",
        SOFTWARE / "software-handoff.json",
        CANON / "numeric-controls-resources-v4.json",
    ]
    # Bind named effective system loaders without executing a dependency tool.
    paths += [
        Path("/usr/lib/x86_64-linux-gnu") / n
        for n in ("libc.so.6", "libm.so.6", "libgcc_s.so.1", "ld-linux-x86-64.so.2")
    ]
    return list(dict.fromkeys(paths))


def static_conditions():
    assert sha(CANON / "numeric-controls-resources-v4.json") == SUPPORT_SHA
    assert sha(CONTRACT) == "fc1fe6451c6a654d5a229eb25fc8a69a6adbd089ecd4fb57c67df411076a22b2"
    assert sha(NOTE) == "21e0a67e3cedfabc19add391b48fa1b88cab6b16a443adaed0c7022cab257fbd"
    assert sha(SOFTWARE / "qualified-software-STOP.json") == RECEIPT_SHA
    assert sha(PRIVATE) == PRIVATE_SHA and sha(PACKET) == PACKET_SHA
    assert not PRIVATE.is_symlink() and not PACKET.is_symlink()
    assert row(PRIVATE)["bytes"] == 2159568
    for name in (
        "LD_PRELOAD",
        "LD_AUDIT",
        "LD_LIBRARY_PATH",
        "RUSTFLAGS",
        "CARGO_ENCODED_RUSTFLAGS",
    ):
        assert not os.environ.get(name), "unbound effective environment: " + name


def planned_env():
    contract = load(CONTRACT)
    env = dict(contract["env"])
    assert (
        env["TT351_MODE"] == "compare"
        and env["TT351_PACKET"] == str(PACKET)
        and env["TT351_OUTPUT"] == str(OUTPUT)
        and env["TMPDIR"] == str(TMP)
    )
    return env


def validate(a):
    parent = inherited()
    assert (
        a["entry_ready"] is True
        and a["source_records"] == parent["source_records"]
        and a["compiler_records"] == parent["compiler_records"]
    )
    required = {str(p) for p in controls(parent)}
    actual = [v["path"] for v in a["control_records"]]
    assert len(actual) == len(set(actual)) and set(actual) == required, "exact control set"
    by_path = {v["path"]: v for v in a["control_records"]}
    for expected in parent["control_records"]:
        assert by_path[expected["path"]] == expected, "unchanged qualified control binding"
    assert a["floors_B"] == FLOORS and a["worker_seconds"] == 180
    contract = load(CONTRACT)
    assert a["argv"] == contract["argv"] and a["env"] == planned_env()
    assert a["unset_env"] == contract["unset_env"]
    assert a["private"] == row(PRIVATE) and a["packet"] == row(PACKET)
    static_conditions()
    for expected in a["source_records"] + a["compiler_records"] + a["control_records"]:
        assert row(expected["path"]) == expected, expected["path"]
    for path in parent["Cargo_configs_absent"]:
        assert not Path(path).exists(), "unbound Cargo config"
    return parent


def require_absent(path):
    try:
        path.lstat()
    except FileNotFoundError:
        return
    raise RuntimeError("owned unique path occupied: " + str(path))


def charges(base):
    values, unknown = base.charges()
    value, u = base.allocated(HERE)
    assert value <= 524288, "numeric controls subclass gap"
    unknown += u
    caps = {
        "guardian": 65536,
        "snapshots": 196608,
        "runtime": 131072,
        "collection": 65536,
        "failure_admin": 65536,
    }
    classes = {
        "guardian": {"worker.py", "ports.py"},
        "snapshots": {"actual-admission.json.gz", "job.json", "source-STOP.json"},
        "runtime": {"runtime-v1"},
        "collection": {
            "ports-result.json",
            "preentry-result.json",
            "actual-START.json",
            "worker-result.json",
            "late-finalization.json",
        },
    }
    sampled = {name: 0 for name in caps}
    sampled["failure_admin"] = HERE.lstat().st_blocks * 512
    for path in HERE.iterdir():
        category = next(
            (name for name, names in classes.items() if path.name in names), "failure_admin"
        )
        size, transient = base.allocated(path)
        unknown += transient
        sampled[category] += size
    for name, size in sampled.items():
        assert size <= caps[name], f"numeric {name} contained component gap {size - caps[name]}B"
    assert base.allocated(CONTRACT.parent)[0] <= 32768
    assert base.allocated(ROOT / "controls/caller-software-entry-v1")[0] <= 1048576
    return values, unknown


def children():
    # Fresh single-thread guardian uses the maintained synchronous execute path.
    found = set()
    for task in Path("/proc/self/task").iterdir():
        found.update(int(n) for n in (task / "children").read_text().split())
    return sorted(found)


def usage():
    r = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {"user_s": r.ru_utime, "system_s": r.ru_stime, "ru_maxrss_KiB": r.ru_maxrss}


def cpu_account(before, after, record, attempts, initial_children, final_children):
    value = {
        "before": before,
        "after": after,
        "source": "RUSAGE_CHILDREN",
        "status": "UNKNOWN",
        "scope": "exactly one assigned native libtest child plus any kernel-accounted reaped descendants; launch/preexec included, not method CPU or a universal daemon certificate",
    }
    if (
        attempts != 1
        or initial_children != []
        or final_children != []
        or not record
        or not record.get("child")
    ):
        return value
    if not (
        record.get("direct_child_reaped") is True
        and record.get("cleanup_complete") is True
        and record.get("remaining") == []
    ):
        return value
    deltas = {name: after[name] - before[name] for name in ("user_s", "system_s")}
    if not all(math.isfinite(n) and n >= 0 for n in deltas.values()):
        return value
    value.update(status="BOUNDED_ONE_CHILD_DELTA", **deltas, total_s=sum(deltas.values()))
    value["kernel_maxrss_scope"] = (
        "cumulative child lifetime high water; never subtract/max-sum; continuous family peak UNKNOWN"
    )
    return value


def integer(value, maximum=None):
    assert type(value) is int and value >= 0
    assert maximum is None or value <= maximum


def unique_object(pairs):
    d = {}
    for name, value in pairs:
        assert name not in d, "duplicate result object key"
        d[name] = value
    return d


def validate_output():
    assert OUTPUT.is_file() and not OUTPUT.is_symlink() and OUTPUT.stat().st_size <= 983040
    data = OUTPUT.read_bytes()
    out = json.loads(data, object_pairs_hook=unique_object)
    packet = load(PACKET)
    assert out["schema"] == packet["schema"] == "tt351-full-key-processing-v1"
    assert out["status"] == "all_methods_completed_validated" and out["method_order"] == METHODS
    assert out["workload"] == packet and out["capture_columns"] == COLUMNS
    assert (
        out["search_model_game_calls"] == 0
        and out["production_Zobrist"] is False
        and out["physical_hash_computations"] == "UNKNOWN"
    )
    assert out["per_method_CPU"] == "UNKNOWN; wall only, external process accounting required"
    assert len(out["methods"]) == 4
    contexts = packet["observed_context_catalog"]
    reference = None
    summary = []
    numeric_keys = [
        "observations",
        "default_requests",
        "instrumented_default_body_entries",
        "fullZ_requests",
        "instrumented_fullZ_body_entries",
        "incremental_hash_reads",
        "incremental_constructor_entries",
        "forward",
        "reverse",
        "independent_key_constructions",
        "independent_fullZ_oracles",
        "exact_key_checks",
        "parent_checks",
        "parent_key_constructions",
        "parent_fullZ_oracles",
        "context_from_prefix",
        "explicit_cursor_clones",
        "prefix_replay_actions",
        "output_key_constructions",
        "output_key_clones",
        "requested_fullZ_feature_terms",
    ]
    for method_index, method in enumerate(out["methods"]):
        assert method["name"] == METHODS[method_index]
        integer(method["whole_state_processing_wall_ns"])
        m = method["metrics"]
        for name in numeric_keys:
            integer(m[name])
        assert m["physical_hash_computations_instructions"] == "UNKNOWN"
        expected = {k: 0 for k in numeric_keys}
        expected.update(
            observations=1536,
            forward=1536,
            reverse=1536,
            independent_key_constructions=1536,
            independent_fullZ_oracles=1536,
            exact_key_checks=3072,
            parent_checks=1536,
            parent_key_constructions=1536,
            context_from_prefix=256,
            explicit_cursor_clones=256,
            prefix_replay_actions=448,
        )
        if method_index == 0:
            expected.update(
                default_requests=3072,
                instrumented_default_body_entries=3072,
                output_key_constructions=1536,
            )
        elif method_index == 1:
            expected.update(
                default_requests=1536,
                instrumented_default_body_entries=1536,
                output_key_constructions=1536,
            )
        elif method_index == 2:
            expected.update(
                fullZ_requests=1536,
                instrumented_fullZ_body_entries=1536,
                output_key_constructions=1536,
            )
            expected["requested_fullZ_feature_terms"] = 64 * sum(
                11
                + c["horizontal"].bit_count()
                + c["vertical"].bit_count()
                + 9 * len(c["counted_history"])
                for c in contexts
            )
        else:
            expected.update(
                incremental_hash_reads=1536,
                incremental_constructor_entries=256,
                output_key_clones=1536,
                parent_fullZ_oracles=1536,
            )
        assert {name: m[name] for name in numeric_keys} == expected, "complete instrumented census"
        captures = method["captures"]
        assert len(captures) == 1536
        for position, c in enumerate(captures):
            assert isinstance(c, list) and len(c) == 12
            catalog = (position // 384) * 6 + position % 6
            cycle = (position % 384) // 6
            assert c[:2] == [catalog, cycle]
            for index, value in enumerate(c):
                if index == 7:
                    assert (
                        (value is None)
                        if method_index < 3
                        else (type(value) is int and 0 <= value <= 1024)
                    )
                else:
                    integer(value, (1 << 64) - 1)
            k = contexts[catalog]
            assert c[8] == len(k["counted_history"]) and c[9] == sum(
                h[5] for h in k["counted_history"]
            )
            assert c[10:12] == [k["total_ply"], k["STM"]]
            assert c[4] >= c[8] and c[4] <= 1024 and c[6] <= 65535
            if method_index == 0:
                continue
            previous = reference[position]
            assert [c[i] for i in (0, 1, 3, 8, 9, 10, 11)] == [
                previous[i] for i in (0, 1, 3, 8, 9, 10, 11)
            ]
            if method_index == 1:
                assert c[2] == previous[2]
            else:
                assert c[2] == c[3]
        if method_index == 0:
            reference = captures
        summary.append(
            {
                "method": method["name"],
                "wall_ns": method["whole_state_processing_wall_ns"],
                "metrics": m,
                "hash_index_unique": len({c[2] % 4096 for c in captures}),
                "owned_capacity_min_max": [
                    min(c[4] for c in captures),
                    max(c[4] for c in captures),
                ],
                "charged_history_B_min_max": [
                    min(c[5] for c in captures),
                    max(c[5] for c in captures),
                ],
                "overlay_B_min_max": [min(c[6] for c in captures), max(c[6] for c in captures)],
            }
        )
    return {
        "output": row(OUTPUT),
        "all4_6144_complete": True,
        "methods": summary,
        "per_method_CPU": "UNKNOWN",
        "physical_instructions": "UNKNOWN",
    }


def prepare():
    result = {"START": utc(), "entry_ready": False, "current_reservation": "NONE"}
    lease, primary = None, None
    try:
        lease = LOCK.open("a+b")
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        parent = inherited()
        base = base_module(parent)
        g = base.guard_module()
        result["quiet"] = base.quiet(g)
        result["physical"] = physical()
        os.sched_setaffinity(0, {2})
        static_conditions()
        for path in (TMP, QUAL, OUTPUT):
            require_absent(path)
        assert (ROOT / "target").is_dir() and PACKET.parent.is_dir()
        before, unknown = charges(base)
        result.update(charges=before, transient_UNKNOWN=unknown)
        # Native-only: keep all prior peaks, zero new build/private allowance.
        assert before["target"] <= FLOORS["target"]
        assert before["private"] <= FLOORS["private"]
        assert max(before["raw"], FLOORS["raw"]) + 983040 + 16384 <= 1048576, (
            "combined raw1MiB forward gap"
        )
        assert (
            max(before["qualification"], FLOORS["qualification"]) + 131072
            <= base.COMPONENTS["qualification"]
        )
        a = {
            "entry_ready": True,
            "source_records": parent["source_records"],
            "compiler_records": parent["compiler_records"],
            "control_records": [row(p) for p in controls(parent)],
            "private": row(PRIVATE),
            "packet": row(PACKET),
            "argv": load(CONTRACT)["argv"],
            "env": planned_env(),
            "unset_env": load(CONTRACT)["unset_env"],
            "floors_B": FLOORS,
            "worker_seconds": 180,
            "initial_component_records": before,
        }
        validate(a)
        encoded = gzip.compress((json.dumps(a, separators=(",", ":")) + "\n").encode(), mtime=0)
        assert len(encoded) + 8192 <= 196608
        with (HERE / "actual-admission.json.gz").open("xb") as f:
            f.write(encoded)
        digest = sha(HERE / "actual-admission.json.gz")
        save(
            "job.json",
            {
                "issue": "quoridor-4lc.351",
                "goal_issue": "quoridor-4lc",
                "thread_id": "01a11004-79f3-7c20-872c-432a2c347664",
                "cwd": str(W),
                "argv": [
                    "/usr/bin/python3",
                    "-B",
                    str(HERE / "worker.py"),
                    "run",
                    str(HERE / "actual-admission.json.gz"),
                    digest,
                ],
                "end_at": None,
                "notify_until": None,
                "max_runtime_seconds": 210,
                "control_interval_seconds": 30,
                "notify_interval_seconds": 10,
                "request_timeout_seconds": 25,
                "log_max_bytes": 16384,
                "resource_contract": str(CANON / "numeric-controls-resources-v4.json"),
            },
        )
        result.update(entry_ready=True, admission_SHA256=digest)
    except BaseException as error:
        primary = error
        result["error"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        try:
            if lease:
                lease.close()
            result["lease_released"] = True
        except BaseException as error:
            result["lease_close_error"] = repr(error)
            if primary is None:
                primary = error
            else:
                primary.add_note("canonical close: " + repr(error))
        result["STOP"] = utc()
        for stage, action in (
            ("preentry result persistence", lambda: save("preentry-result.json", result)),
            ("preentry stdout", lambda: print(json.dumps(result), flush=True)),
        ):
            try:
                action()
            except BaseException as error:
                result.setdefault("finalization_errors", []).append(
                    {"stage": stage, "type": type(error).__name__, "message": str(error)}
                )
                if primary is None:
                    primary = error
                else:
                    primary.add_note(stage + ": " + repr(error))
    if primary:
        raise primary


def run(path, expected):
    started = time.monotonic()
    result = {
        "status": "STARTING",
        "commands": [],
        "attempts": 0,
        "finalization_errors": [],
        "primary_error": None,
    }
    lease, a, base, watch, record = None, None, None, None, None
    primary = None
    before_cpu, before_children = None, None
    tmp_owned = False

    def attempt(stage, action):
        nonlocal primary
        try:
            return action()
        except BaseException as error:
            result["finalization_errors"].append(
                {"stage": stage, "type": type(error).__name__, "message": str(error)}
            )
            if primary is None:
                primary = error
            else:
                primary.add_note(stage + ": " + repr(error))

    try:
        assert sha(path) == expected
        a = json.loads(gzip.decompress(Path(path).read_bytes()))
        lease = LOCK.open("a+b")
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        result["lease_START"] = utc()
        parent = inherited()
        base = base_module(parent)
        g = base.guard_module()
        result["quiet"] = base.quiet(g)
        result["physical"] = physical()
        os.sched_setaffinity(0, {2})
        validate(a)
        for p in (TMP, QUAL, OUTPUT):
            require_absent(p)
        initial, unknown = charges(base)
        result.update(initial_charges=initial, initial_UNKNOWN=unknown)
        for p in (TMP, QUAL):
            p.mkdir(parents=True, exist_ok=False)
        tmp_owned = True
        for key in a["unset_env"]:
            os.environ.pop(key, None)
        os.environ.update(a["env"])
        sys.path.insert(0, "/workspaces/quoridor/python")
        process = importlib.import_module("quoridor_training.cycle_process")
        deadline = started + a["worker_seconds"]

        class Watch:
            def __init__(self):
                self.peaks = dict(FLOORS)
                self.unknown = []
                self.next = 0

            def check(self, owned=()):
                if time.monotonic() >= deadline:
                    raise process.CycleStopped("finite ordinary comparison horizon")
                if process.available_memory() < 4294967296:
                    raise process.CycleStopped("host4GiB reserve")
                base.quiet(g, owned)
                rss = sum(
                    info["rss"]
                    for pid in g.ancestors()
                    if pid != 1 and (info := process.process_info(pid))
                )
                rss += sum(
                    info["rss"] for member in owned if (info := process.process_info(member["pid"]))
                )
                self.peaks["family_RSS_B"] = max(self.peaks.get("family_RSS_B", 0), rss + 67108864)
                if rss + 67108864 > 2147483648:
                    raise process.CycleStopped("family2GiB includes64MiB controller")
                if time.monotonic() >= self.next:
                    d, u = charges(base)
                    self.unknown.extend(u)
                    self.next = time.monotonic() + 0.5
                    for name, value in d.items():
                        growth = max(0, value - initial[name])
                        inclusive = max(value, FLOORS[name] + growth)
                        self.peaks[name] = max(self.peaks.get(name, 0), inclusive)
                        assert inclusive <= base.COMPONENTS[name], (
                            f"{name} whole/component unsupported gap"
                        )
                    assert (
                        d["target"] <= initial["target"] and d["private"] <= initial["private"]
                    ), "unplanned build/private growth"
                    assert d["raw"] <= 1048576, "combined raw1MiB cap"
                    assert base.allocated(TMP)[0] <= 4194304
                    assert base.allocated(QUAL)[0] <= 1048576

        watch = Watch()
        watch.check()
        result["actual_guard_START"] = utc()
        result["identity"] = g.identity(os.getpid())
        save(
            "actual-START.json",
            {
                "UTC": result["actual_guard_START"],
                "identity": result["identity"],
                "admission_SHA256": expected,
                "native_attempts_planned": 1,
                "observations_planned": 6144,
            },
        )
        before_children = children()
        assert before_children == [], "unexpected owned child before native"
        before_cpu = usage()
        result["attempts"] = 1
        with process.cancellation_signals():
            try:
                record = process.execute(
                    a["argv"], QUAL / "native.log", deadline, cpu_core=0, resources=watch
                )
                result["commands"].append({"returned_record": record})
            except BaseException as execute_error:
                primary = execute_error
                p = QUAL / "native.process.json"

                def failed_record():
                    nonlocal record
                    try:
                        p.lstat()
                    except FileNotFoundError:
                        return
                    record = load(p)
                    result["commands"].append({"persisted_record": record})

                attempt("failed native persisted record collection", failed_record)
                raise execute_error
        result["native_CPU"] = cpu_account(
            before_cpu, usage(), record, result["attempts"], before_children, children()
        )
        assert record["log_bytes_seen"] <= process.LOG_MAX_BYTES
        assert "1 passed; 0 failed" in (QUAL / "native.log").read_text()
        result["validated_processing"] = validate_output()
        result["status"] = "PASS_FIXED_KEY_PROCESSING"
    except BaseException as error:
        primary = error
        result["status"] = "FAILED_PARTIAL_UNKNOWN"
        result["primary_error"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        result["native_workerSTOP"] = utc()
        if before_cpu is not None and "native_CPU" not in result:
            attempt(
                "CPU scope collection",
                lambda: result.update(
                    native_CPU=cpu_account(
                        before_cpu, usage(), record, result["attempts"], before_children, children()
                    )
                ),
            )
        if a is not None:

            def source_after():
                validate(a)
                result["source_control_private_packet_after_exact"] = True

            attempt("source/control/private/packet after", source_after)
        if base is not None:
            attempt("whole/component census", lambda: result.update(final_charges=charges(base)))
        if watch:
            result["sampled"] = watch.peaks
            result["transient_UNKNOWN"] = watch.unknown
        result["continuous_peaks"] = "UNKNOWN"
        result["component_cleanup_complete"] = (
            bool(record)
            and record.get("direct_child_reaped") is True
            and record.get("cleanup_complete") is True
            and record.get("remaining") == []
        )
        result["remaining"] = (
            record.get("remaining", []) if record else "UNKNOWN; no returned child record"
        )

        def finish_tmp():
            if (
                tmp_owned
                and result["component_cleanup_complete"]
                and TMP.exists()
                and not any(TMP.iterdir())
            ):
                TMP.rmdir()
                result["owned_empty_TMP_removed"] = True
            elif tmp_owned:
                result["owned_TMP_retained"] = True

        attempt("owned TMP after verified directwait", finish_tmp)
        if lease:

            def close_lease():
                lease.close()
                result["canonical_lease_released"] = True

            attempt("canonical lock close", close_lease)
        result["source_cleanup_STOP"] = utc()
        result["whole_worker_s"] = time.monotonic() - started
        if primary is not None and result["status"] == "PASS_FIXED_KEY_PROCESSING":
            result["status"] = "FAILED_FINALIZATION"
        attempt("worker result persistence", lambda: save("worker-result.json", result))
        if any(x["stage"] == "worker result persistence" for x in result["finalization_errors"]):
            result["status"] = "FAILED_FINALIZATION"
            attempt("late finalization facts", lambda: save("late-finalization.json", result))
    print(
        json.dumps(
            {
                "status": result["status"],
                "STOP": result["source_cleanup_STOP"],
                "attempts": result["attempts"],
                "error": result["primary_error"],
            }
        ),
        flush=True,
    )
    if primary is not None:
        raise primary


if __name__ == "__main__":
    if sys.argv[1:] == ["prepare"]:
        prepare()
    elif len(sys.argv) == 4 and sys.argv[1] == "run":
        run(sys.argv[2], sys.argv[3])
    else:
        raise SystemExit("prepare or run exact-admission SHA")
