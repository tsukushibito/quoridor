# Same-owned-key hash reuse: stopped source and support contract

This completes the delegated finite preparation, not implementation. The saved
analysis was accepted at Main2cf15b58, receiptacca71d4; review480e8dcf/a1137b76
confirms the bounded admission interpretation. Original proposal978c244e and all
accepted evidence remain immutable. No candidate patch, compilation, native call,
model, Search, test, game or timing comparison has run in this phase.

## Selected boundary: recursive pairs only

The next justified direction is to reuse the hash of the **same immutable owned
Key** across a recursive non-leaf probe and its subsequent result insertion.
In the current source, `negamax` already constructs one owned Key before probing,
holds it through child traversal, then moves it into Entry. Its history vector is
independent of the mutable game cursor. No extra key copy, allocation, retained
key or changed vector capacity is needed to keep a local hash alongside it.

Do **not** extend this first change to root keys. `root_depth` currently constructs
separate owned keys for its probe and insertion. Merely assuming they are equal
would violate the same-owned-key boundary; retaining the first one longer would
also change key-construction work/lifetime. Keep both root constructions and
hashes unchanged. PV `Table::get`, standalone/unpaired table operations and their
fresh keys also remain unchanged. This deliberately narrower route avoids a
second allocation/lifetime optimization disguised as hash reuse.

Private implementation interface to fix after actual resource support:

- The paired probe computes the existing `Key::hash` once, obtains the unchanged
  modulo index and returns its result plus a local hash token tied to that owned
  key. The token has no external/public constructor or consumer API.
- A subsequent insertion uses that token with the very same key moved into Entry.
  No mutation, replacement key, cloned key, context-only key or another sibling's
  token can enter this branch. The hash is invocation-local, never stored in Key,
  Entry, Table, SearchStats, SearchSession or per-entry caches.
- The unpaired probe/insert path still computes its own hash. A shared private
  index/check body may avoid duplicating logic; this is two live processing paths,
  not a compatibility shim or permanent A/B implementation switch.
- Empty tables preserve the existing probe event and zero hash computations;
  disabled TT, leaf and terminal paths remain unchanged. TT cutoffs return without
  insertion. Cancellation/errors discard unused local state and preserve existing
  partial-generation/root restoration and primary-error handling.

No `Key::hash` algorithm, seed, derivation or full-key equality is reimplemented.
No sorting/counting shortcut, global hash memo, age eviction, resize, clearing,
history dropping or repetition relaxation is part of this boundary. The stale
1MiB admission problem remains as observed: this change removes repeated hash
processing without changing which entries are admitted.

## Storage, output and counter invariants

Key, Entry, Table/header and SearchStats field/type definitions must be byte-exact
to the frozen baseline. Their compiled `size_of` values and alignments must match
under the same installed toolchain/target. No persistent hash or new counter bytes
are permitted: Table size participates in retained-byte admission. Key/history
vector capacities, slot capacity4096, accounted limit1MiB, target index, full-key
comparison, deeper same-generation protection, byte-refusal test, replacement,
generation/reset/interrupt rules and all retained entries must match.

Public SearchSession/search/reset/callback/result interfaces and serialized field
names/types stay unchanged. Goal-first/true-threefold/path history, absolute ply,
stocks/side/rules/synthetic provenance, terminal/score/model/view namespaces, PVS
windows, move ordering and teacher depth6/no-time/u64::MAX/200-UNKNOWN policy stay
unchanged. Parent restoration, ownership and cancellation/error obligations are
not weakened. Hash differences never identify terminals or bypass full equality.

Pin `tt_hashes` **before outcomes** as the count of actual full-key hash computations
on the instrumented probe/insert paths; PV get hashes remain excluded in both
versions. In the old code every instrumented request computes a hash, so request
and computation counts coincide. With reuse, an insertion requesting an index
does not perform another hash and must not increment this computation counter.
No new Stats field is added. Logical probe counts and result-insertion/admission
behaviour remain independently checked. Provenance must explicitly document the
processing variant; do not silently call a smaller hash count identical work.

On matched fixed-work completed returns, action/value bits (including signed zero),
legal PV, completed depth/
stop, nodes/evaluations/cutoffs/PVS and all unaffected counters must be exact.
`tt_key_builds`, history-item/capacity counters and Table retained bytes remain
exact because root/owned-key construction is unchanged. Only `tt_hashes` may
decrease by the proven number of reused recursive insertion hashes. If any other
output/work differs, retain the failure and stop; do not lower the comparison gate.

## Expected processing benefit, not wall benefit

The independently confirmed161 completed zero-hit suffix calls have P probes and
I=P attempted result insertions. Six completed iterative depths each have one
unoptimized root probe/insertion. Every other pair is recursive and already shares
one owned Key. Thus the selected route can eliminate **P-6 hashes per such call**,
conditional on correct implementation and exact equivalence.

| Saved game | Verified suffix calls | Sum of P | Eligible recursive insertion hashes |
| --- | ---: | ---: | ---: |
| 000 | 55 | 21476435 | 21476105 |
| 001 | 44 | 4293042 | 4292778 |
| 002 | 34 | 1447919 | 1447715 |
| 003 | 28 | 9568 | 9400 |
| Total | 161 | 27226964 | **27225998** |

These are eliminated full-history traversal/hash computations on saved work, not
nanoseconds, a speed ratio or a guaranteed158s improvement. The initial source
fact file's27226964 is the raw suffix probe sum, not the final recursive-only
elimination count; six root hashes per call are deliberately excluded. Other
calls, early TT returns and interrupted paths require their own exact accounting;
no savings are extrapolated to them here. Capacity refusal, usefulness of old
entries, key construction/copy and ordinary table work remain distinct and mostly
unchanged. This is a supported rationale for a finite exact-processing test, not
a profiler attribution or a full-N throughput promise.

## Affected qualification and one current build

Only future affected definitions under a new `tt_hash_reuse351_` filter are needed:

1. Same owned key/index/full equality, including empty/disabled tables, occupied
   unequal-key indices, different histories and stocks, and unpaired/root/PV paths.
2. Byte admission/refusal, occupied versus empty insertion and deeper current-
   generation protection: compare every retained logical entry, payload capacity,
   generation and all storage sizes with an independent frozen baseline trace.
3. A nonconstant small genuine-history tree through PVS/TT: exact action/valuebits/
   PV/depth/stop, all unaffected work, and independently counted actual hashes.
   Baseline and candidate fixture traces are new affected qualification, not a
   replay of old whole rule/math/native suites.
4. Cancellation/error/after-child paths: parent make/unmake and partial-generation
   discard, namespace reset and borrowed/owned lifetime; no unused hash token can
   publish an entry or replace an originating error.

Existing unchanged rules/score/math/model/backend proof is reused. New filters
must typecheck other retained definitions without running successful old suites.
One narrow stopped related review covers the private same-key token, accounting,
layout and truthful counter boundary after actual source STOP; Root assigns an
appropriate existing reviewer, not automatically the current analysis reviewer.

Proposed software closure: filtered AI research tests, owned no-deps Clippy,
necessary AI no-default/endgame/research type closure, **one** release runner build
and its zero-backend config-only source/private binding. Record actual commands,
source/compiler/dependency proof, waits and failures before any invocation. Stable
Rust1.99 is prior qualified provenance; only installed executable metadata was
observed now, and no compiler/version command was replayed. Actual executable SHA,
target and effective environment must be fixed at future admission. Release opt3/
thinLTO/codegen1 and debug0, dev opt0/debug0/incremental0 are explicit; j1, offline,
no auto-install, absolute stable RUSTC/RUSTDOC and empty rustc wrappers are required
before every child. C++ compilation for runner's unchanged inference stub remains
inside build cost even with GPU/model backends disabled.

The maintained teacher-pilot CLI produces full games, not a four-return fixed-
prefix timing interface. The accepted old privatea45 is retained with its original
compiled source map and must not be relabeled current Main/candidate. A proposed
four-return comparison is **NOT admitted** by this preparation. Its measurement
interface, exact comparable original/current private and any additionally necessary
baseline build must be explicitly priced and bound later; no blind native call or
new full game is substituted. Original28.257s baseline scale is not a completion
bound or whole-job cost. Compile/setup/qualification/audit/cleanup time remains
UNKNOWN, and failed/nested fees retain their normal accounting.

## Actual source and offline dependency preparation

`current-support-facts.json` binds Main manifests/lock/selected bodies, canonical
resource chain and old held receipts. Main alpha and affected maintained teacher
caller/serialization bodies were read directly and remain fixed by SHA/mode/size
before/after. Initial light reads preceded the sweep and are disclosed rather
than called retroactive hash-before-first-read. No source copies were made.

Proposed exclusive source path is `.worktree/tt-hash-reuse351`, absent at the
observed snapshot. Root alone creates the managed sparse checkout and edits Git/
index. Preserve the current root workspace with its seven members, including
`quoridor-inference` and `quoridor-wasm`; runner has a direct inference path
dependency and its build.rs needs native sources/headers. The six-prefix sparse
estimate therefore needs amendment before Cargo. `crates/quoridor-training` does
not exist; Python training sources are not a Rust workspace member. Root may
include the correct Python path as a directed consumer reference, without creating
a fake crate or silently altering workspace/lock resolution.

Root's dated107-file estimate6033408B was not rerun as a broad Git audit. Required
extra prefixes must be included in an updated sparse forecast within source32MiB.
Necessary root Cargo files and package/toolchain/build configuration must be
present and bound. No unsupported source mirror, stub or foreign-worktree edit is
used to bypass missing members.

The conservative lock graph reached105 registry packages, including optional and
other-target paths. Seventeen package names/eighteen versioned entries lack source
or archives. Exact immediate manifest edges show non-Linux Windows/wasm/WASI/UEFI/
SPIR-V dependencies or dependency crates' own dev tests; e.g. crunchy is half's
dev/spirv dependency, not a required Linux dependency for the proposed filter.
All105 reachable registry index metadata entries are present. Installed native
stdlib and `/usr/bin/c++` metadata exist. This is a directed
offline presence/edge check, **not Cargo resolution/build or checksum integrity
qualification**. Future target/features must be frozen; no missing optional
package authorizes a download. No Cargo, rustc, cache/library/model import ran.

## Coherent whole resource contract and exact missing support

All old parents remain held: legacy/pre50GB13.4GB coverage, original tasks
including337,342 prep/compiler recovery,3474GiB and3481.5GiB. Their raw/private/
model/target/TMP/failure/mask/UNKNOWN floors are not deleted or credited. Named
348 target currently samples254869504B over887 metadata entries, while its higher
held255602688B remains; privatea45 metadata7832584B and private held7839744B remain
distinct. TMP1150976B/raw8388608B/control8388608B floors remain. No ELF/model payload
was read, copied or moved. Shared registry source/archive paths are referenced
under prior dependency/legacy holds, not claimed as free new cache.

Latest published typed chain68f→44c71/9a489/1ed487→a70b→ba845 holds39598288896B
under50000000000B. The prospective624MiB adds654311424B, giving40252600320B and
9747399680B arithmetic headroom. These bound canonical proofs establish the old
coverage; they **do not allocate the new candidate** or certify current filesystem
retention/continuous peaks. Root must issue a coherent current named candidate
classification against that held global total before any affected source/build/
private growth. That missing654311424B support is precise, not a wholeSigma/N or
reply-only ACK dependency. Current8MiB has no build/private numerical allowance.

| Proposed component | MiB | New named destination / retained obligations |
| --- | ---: | --- |
| Sparse source/checkout/control | 32 | `.worktree/tt-hash-reuse351`; amended member/config forecast, no old source refund |
| Target/dependencies/build/link | 512 | New source WT `.artifacts/tt-hash-reuse351/target`; dev/test/release/C++ all included |
| Current private | 16 | Same namespace `/private`; one future current qualified image, olda45 remains old |
| TMP | 32 | `/TMP`; phase paths, serial maxima only when exact stopped proof permits |
| Qualification | 8 | `/qualification`; new filters, traces/layout/counter/source/private receipts |
| Raw/proposed later outputs | 8 | `/raw`; no four-return admission now, original stream remains read-only |
| Failure/finalization/rounding | 8 | `/failures`; original failed/unknown facts never refunded |
| Related review | 4 | `/review`; Root-directed fixed question and reader STOP |
| Root/Git/retention/cleanup | 4 | Canonical research-data intake plus managed Git/restoration work, sole324 |
| **Prospective additional whole** | **624** | **654311424B; NOT_ALLOCATED** |

Source32MiB and target512MiB are upper proposals, not measurements or promises:
latest sparse estimate is6.03MiB; old related target observations255.6MiB and
other maintained caller histories motivate room, but exact new dev/release/C++/
dependency growth remains UNKNOWN. Fail closed on an unsupported revised whole
or component forecast, retain the precise gap and continue unaffected preparation.
No installer, old target reuse, early deletion or hypothetical cleanup fills it.
The prospective raw bucket is storage planning only, not a numerical grant.

## Stopped deliverable

This new preparation namespace has a forward inclusive262144B upper inside the
existing source/control2MiB and analysis8MiB, with directories/failure/format/admin
included. Old own observed282624B plus that upper is544768B. Actual namespace
allocation, selected references, source/dependency before/after checks, cost and
reader/writer STOP are in the frozen handoff. Source arithmetic/metadata blocks
used CPU3/AS512MiB/GPU0 with fresh named quiet and a nonblocking lifetime canonical
lease; light writing has no hardware reservation. All owned synchronous commands
returned; no TMP/child/compiler/model/science job remains. Continuous peaks and
unrecorded source/admin costs stay UNKNOWN; nested spans are not added.

Root receives this actual source/interface/support preparation, not a request to
repeat analysis or wait for an approval-only reply. The necessary next fact is
issued current whole component coverage and a managed source owner/baseline, not
human N, finished Sigma tasks or another old review. Genuine ready Sigma D16 then
NNUE16 and any actually entered job retain priority and natural STOP. Original
323pause, seals, defaults, N/fullschedule/pilotmix/fullgen/fits96 remain unchanged.
