"""Bounded saved28 collection and interpretation, without an executable invocation."""

from __future__ import annotations

import csv
from decimal import Decimal
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import stat
import struct

OWN = Path("/workspaces/quoridor/.worktree/search-optimization/.artifacts/compact-tt359-v1")
ENTRY = OWN / "software-controls/numeric-entry-v1"
HERE = ENTRY / "saved-collection-v1"
OUT = OWN / "assessment-raw/saved-analysis-v1"


def ref(path):
    s = path.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_size > 1048576:
        raise ValueError("selected metadata cap/type")
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=format(stat.S_IMODE(s.st_mode), "04o"),
    )


def model_records(journal):
    return [json.loads(b) for b in Path(journal["path"]).read_bytes().splitlines()]


def main():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    original = importlib.util.spec_from_file_location(
        "compact359_saved_utils", ENTRY / "numeric_guardian.py"
    )
    n = importlib.util.module_from_spec(original)
    original.loader.exec_module(n)
    intent = ref(ENTRY / "intent.actual-v1.json")
    spec = n.doc(intent)
    n.static(spec)
    result_ref, state_ref = (
        ref(ENTRY / "runtime-v1/result.json"),
        ref(ENTRY / "runtime-v1/state.json"),
    )
    result, state = n.doc(result_ref), n.doc(state_ref)
    returned_ref = ref(OWN / "assessment-raw/operation-v1/guardian-result.json")
    returned = n.doc(returned_ref)
    n.require(
        result["job_id"] == returned["origin"]["job_id"] == state["job_id"],
        "same original campaign",
    )
    n.require(
        state["phase"] == "finished" and result["exit_code"] == 0 and result["error"] is None,
        "external finished success",
    )
    n.require(
        result["direct_child_reaped"] is True
        and result["cleanup_complete"] is True
        and result["remaining"] == result["cleanup_errors"] == [],
        "outer wait/cleanup",
    )
    n.require(
        returned["status"] == "RETURNED_FIXED28_PENDING_OUTER_JOIN"
        and returned["intent"] == intent
        and returned["primary"] is None
        and returned["secondary"] == [],
        "normal returned finalizers",
    )
    n.require(
        len(returned["checks"]) == 2
        and returned["completed_validated_calls"] == 28
        and returned["uncompleted_calls"] == 0,
        "original denominator28",
    )
    with n.LEASE.open("r+b") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        START = n.stamp()
        g = n.load(spec["source_helper"], "compact359_source_utils")
        n.correspondence(spec, g, payload=False)
        lifecycle = n.load(spec["runtime_sources"][0], "compact359_numeric_lifecycle")
        lifecycle.physical_and_quiet(spec)
        n.correspondence(spec, g, payload=True)
        before = n.storage(spec, g)
        cfg = n.doc(returned["origin"]["config"])
        n.require(
            cfg["argv"][-1] == intent["sha256"]
            and cfg["argv"][-3] == intent["path"]
            and cfg["resource_contract"] == spec["support"]["path"],
            "actual frozen job/source contract",
        )
        n.require(
            state["config_sha256"]
            == hashlib.sha256(json.dumps(cfg, sort_keys=True).encode()).hexdigest(),
            "canonical config state digest",
        )
        inputs = [
            intent,
            result_ref,
            state_ref,
            returned_ref,
            returned["origin"]["config"],
            ref(ENTRY / "runtime-v1/output.log"),
        ]
        saved = []
        identities = []
        for role, check in zip(spec["roles"], returned["checks"], strict=True):
            n.require(
                check["name"] == role["name"]
                and check["argv"] == role["argv"]
                and check["status"] == "PASS"
                and check["capture_complete"] is True
                and check["primary"] is None
                and check["secondary"] == [],
                "exact full returned inlet",
            )
            child = check["guardian_return"]
            lifecycle.settled(child)
            n.require(
                child["handle_closes_complete"] is True
                and child["process_cleanup_complete"] is True,
                "independent handle/process cleanup",
            )
            inputs += [check["full_log"], check["persisted_process_receipt"]]
            n.read(check["full_log"])
            # Persisted pending/attempted is recorded, never relabelled as return.
            n.read(check["persisted_process_receipt"])
            saved.append(n.validate_journal(spec, role, g))
            identities.append(child["child"])
        inputs += returned["requests"]
        for r in returned["requests"]:
            n.read(r)
        for r in saved:
            inputs.append(r["journal"])
        n.require(
            [r["value_bits"] for r in saved[0]["cases"]]
            == [r["value_bits"] for r in saved[1]["cases"]],
            "all14 paired exact value bits",
        )
        identities += [state["child"], state["supervisor"]]
        census = []
        for identity in identities:
            observed = lifecycle.process.process_info(identity["pid"])
            present = observed is not None and lifecycle.process.identity(observed) == identity
            census.append(
                {
                    "identity": identity,
                    "fresh": "PRESENT" if present else "ABSENT",
                    "metadata": observed if present else None,
                }
            )
        n.require(all(r["fresh"] == "ABSENT" for r in census), "exact owned process still present")
        g.witness_absence(spec["TMP"])
        pairs, captures = [], []
        for i, (a, b) in enumerate(zip(saved[0]["cases"], saved[1]["cases"], strict=True)):
            evaluator = "D" if i < 7 else "BEST43"
            for role, row in (("baseline", a), ("candidate", b)):
                n.require(
                    math.isfinite(row["value"])
                    and struct.unpack("<I", struct.pack("<f", row["value"]))[0]
                    == row["value_bits"],
                    "exact saved f32 bits",
                )
                n.require(
                    all(type(v) is int and v >= 0 for v in row["stats"].values()),
                    "numeric full public counter capture",
                )
                n.require(0 < row["stats"]["nodes"] <= 3000000, "work limit")
                n.require(
                    row["pv"] and row["pv"][0] == row["action"] and len(row["pv"]) <= 4,
                    "checked public PV capture",
                )
                captures.append({"ordinal": i, "role": role, "evaluator": evaluator, **row})
            pairs.append(
                {
                    "ordinal": i,
                    "evaluator": evaluator,
                    "root": a["root"],
                    "value_bits_match": True,
                    "action_match": a["action"] == b["action"],
                    "PV_match": a["pv"] == b["pv"],
                    "baseline_whole_case_ns": int(a["whole_case_ns"]),
                    "candidate_whole_case_ns": int(b["whole_case_ns"]),
                    "candidate_over_baseline_whole": int(b["whole_case_ns"])
                    / int(a["whole_case_ns"]),
                    "nodes": [a["stats"]["nodes"], b["stats"]["nodes"]],
                    "evaluations": [a["stats"]["evaluations"], b["stats"]["evaluations"]],
                    "table_retained_bytes": [
                        a["session_table_after_bytes"],
                        b["session_table_after_bytes"],
                    ],
                    "capacity_skips": [
                        a["stats"]["tt_capacity_skips"],
                        b["stats"]["tt_capacity_skips"],
                    ],
                }
            )
        totals = {}
        for evaluator, indices in (("D", range(7)), ("BEST43", range(7, 14))):
            totals[evaluator] = {}
            for role, journal in zip(spec["roles"], saved, strict=True):
                rows = model_records(journal["journal"])
                footer = next(
                    r for r in rows if r["kind"] == "evaluator_footer" and r["name"] == evaluator
                )
                setup = next(
                    r for r in rows if r["kind"] == "evaluator_setup" and r["name"] == evaluator
                )
                cases = [journal["cases"][i] for i in indices]
                totals[evaluator][role["name"]] = {
                    "whole_case_sum_ns": sum(int(r["whole_case_ns"]) for r in cases),
                    "whole_evaluator_ns": int(footer["whole_evaluator_ns"]),
                    "setup_ns": int(setup["setup_ns"]),
                    "search_elapsed_sum_ns_nested": sum(int(r["search_elapsed_ns"]) for r in cases),
                    "work": {
                        k: sum(r["stats"][k] for r in cases)
                        for k in (
                            "nodes",
                            "evaluations",
                            "cutoffs",
                            "pvs_researches",
                            "tt_probes",
                            "tt_capacity_skips",
                            "tt_hashes",
                            "tt_key_builds",
                        )
                    },
                    "retained_table_min_B": min(r["session_table_after_bytes"] for r in cases),
                    "retained_table_max_B": max(r["session_table_after_bytes"] for r in cases),
                }
            a, b = totals[evaluator]["baseline"], totals[evaluator]["candidate"]
            totals[evaluator]["candidate_over_baseline_whole_case_sum"] = (
                b["whole_case_sum_ns"] / a["whole_case_sum_ns"]
            )
            totals[evaluator]["candidate_over_baseline_whole_evaluator"] = (
                b["whole_evaluator_ns"] / a["whole_evaluator_ns"]
            )
        summary = {
            "schema": "compact359.saved-fixed28-summary.v1",
            "planned": 28,
            "attempted": 28,
            "completed_depth4": 28,
            "UNKNOWN": 0,
            "matched_values_exactbits_pairs": 14,
            "matched_actions_pairs": sum(x["action_match"] for x in pairs),
            "matched_PV_pairs": sum(x["PV_match"] for x in pairs),
            "totals": totals,
            "pairs": pairs,
            "raw_bindings": [r["journal"] for r in saved],
            "all_counters_csv_missing_fields": "absent in that role, never filled with zero",
            "inference": "One nonrandom A then B block; per-role/model/root work differs. Descriptive only; no isolated Zobrist/capacity/hashing causal shares, long-depth6-game/strength/default claim.",
        }
        g.new_json(OUT / "summary.json", summary)
        counter_names = sorted({k for row in captures for k in row["stats"]})
        fields = [
            "role",
            "evaluator",
            "root",
            "ordinal",
            "completed_depth",
            "value_bits",
            "action",
            "pv",
            "whole_case_ns",
            "search_elapsed_ns",
            "session_table_before_bytes",
            "session_table_after_bytes",
            "session_metadata_before_bytes",
            "session_metadata_after_bytes",
            *counter_names,
        ]
        with (OUT / "cases-all-counters.csv").open("x", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for row in captures:
                writer.writerow(
                    {
                        **{
                            k: (json.dumps(row[k], separators=(",", ":")) if k == "pv" else row[k])
                            for k in fields
                            if k in row
                        },
                        **row["stats"],
                    }
                )
        table = "| Evaluator | A whole-case sum s | B whole-case sum s | B/A | A nodes | B nodes | A evaluations | B evaluations |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n"
        for evaluator in ("D", "BEST43"):
            a, b = totals[evaluator]["baseline"], totals[evaluator]["candidate"]
            table += f"| {evaluator} | {a['whole_case_sum_ns'] / 1e9:.9f} | {b['whole_case_sum_ns'] / 1e9:.9f} | {totals[evaluator]['candidate_over_baseline_whole_case_sum']:.6f} | {a['work']['nodes']} | {b['work']['nodes']} | {a['work']['evaluations']} | {b['work']['evaluations']} |\n"
        detail = "| Evaluator/root | Whole B/A | Nodes A/B | Table bytes A/B | Capacity skips A/B | PV same |\n| --- | ---: | ---: | ---: | ---: | --- |\n"
        for row in pairs:
            detail += f"| {row['evaluator']}/{row['root']} | {row['candidate_over_baseline_whole']:.6f} | {row['nodes'][0]}/{row['nodes'][1]} | {row['table_retained_bytes'][0]}/{row['table_retained_bytes'][1]} | {row['capacity_skips'][0]}/{row['capacity_skips'][1]} | {row['PV_match']} |\n"
        report = (
            "# Compact TT359: fixed28 saved assessment\n\n"
            "All28 planned cold calls completed requested depth4; no replacement, repeated measurement or lower-depth rescue. The14 paired values match exact f32 bits. All14 actions match; the two endgame PVs differ and remain legal according to the bound caller's replay. The seven chronological roots, counted histories and unchanged parent captures match the frozen catalogue. Actual GHI/noTT/undo/collision software definitions were reused in their accepted scopes, without replay.\n\n"
            "The prebound aggregate whole-case criterion decreases for both D and BEST43 in this single A-before-B block. Work is not identical, and the BEST43 walled-midgame call is slower. These are bounded implementation observations; they establish no robust speed, strength or isolated Zobrist benefit.\n\n"
            + table
            + "\n## Full setup/drop and counter domains\n\n"
            "A is qualified full-history TT image5a871 with embedded source1a44; B is compact board/context Zobrist image072764 with embedded872. Both contain caller33b43/workload892/rootcatalogue3d94. Both actually load BEST43 once through the maintained residual factory, checking typed96a5, descriptor46ec and weights046fe; D remains0/8, LEGACY terminal2, ScalarFT/guarded head and no output bypass. No old live Main was restored.\n\n"
            "Whole-case starts before prefix decoding, canonical replay/count capture, context/Arc clone, TT/FT/scratch creation, Search/PVS/PV/correctness capture and ephemeral drop. Evaluator footer includes model setup, seven cases, serialization and evaluator drop. Footer serialization itself and request/selfdigest/catalogue/output/sync/directwait/cleanup belong to process/controller fees. Search elapsed and evaluator/case clocks are nested and never added to external cost. Guarded metadata scans, hash checks, saved verification and observer activity are charged to the controller; their timing interference is UNKNOWN. The observer uses distinct physical core2 and Search core0; this does not prove absence of interference.\n\n"
            "The fixed table envelope stays4096slots/1MiB. B reports327728 retained table bytes on every call; A reports794464..1048408. This is table accounting including its header/slots/history capacity, not process RSS. Baseline capacity skips and constructed-history counters remain in raw/CSV; candidate context init/transitions, board hash updates/reads, context misses, index and64-bit hash collisions remain separate. A/B counters with the same label can have different source meanings; no absent field is invented as zero. Hash computations/reads are source counts, not machine instructions. Context matching is qualified by the reviewed noncryptographic128-bit collision assumption, not exact arbitrary history or a complete GHI theorem. These finite rows prove no collision impossibility.\n\n"
            + detail
            + "\n## Costs, limits and decision\n\n"
            f"External campaign controller: {result['wall_seconds']:.9f}s, including both direct native commands and guards. Native guardian command spans: {returned['checks'][0]['guardian_return']['wall_seconds']:.9f}s and {returned['checks'][1]['guardian_return']['wall_seconds']:.9f}s, nested and not added. Prior software controllers169.60431484726723s remain held; all known software+this campaign176.096679879236032s (decimal sum of supplied scalar facts). Unsaved administration/LLM/whole historical cost remains UNKNOWN. Process CPU, practical family RSS and continuous RSS/allocation peaks were not saved by this adapter and remain UNKNOWN; no substituted old samples. Both full stdout captures are208B.\n\n"
            "The frozen completed-value and aggregate whole-wall criteria are satisfied in the observed cases. Candidate changes table availability, work, indices and ordering as well as history/hash processing; this is no same-work or factorial attribution. One fixed order, shared machine/cache conditions, short depths and seven selected roots do not support confidence intervals, population/global speed, the158s depth6-game causal fraction, teacher N, games or default policy changes. Retain this result as limited implementation evidence pending one independent stopped interpretation. No new sweep/perf/game/fit/resize/eviction/reset is recommended by these data. Root alone integrates/adopts and preserves/retires completed comparison-only source after reader STOP.\n"
        )
        with (OUT / "report.md").open("x") as f:
            f.write(report)
        n.correspondence(spec, g, payload=True)
        for r in inputs:
            n.read(r)
        for journal in saved:
            n.read(journal["journal"])
        after = n.storage(spec, g)
        n.require(
            g.allocation(HERE) <= 262144 and g.allocation(OUT) <= 131072,
            "contained collection/report caps",
        )
        record = {
            "status": "FIXED28_PROCESS_CENSUS_VALUES_VERIFIED_INTERPRETATION_PENDING",
            "issue": "quoridor-4lc.359.1",
            "job_id": state["job_id"],
            "START": START,
            "controller_START": state["started_at"],
            "guardian_START": returned["START"],
            "worker_source_STOP": returned["STOP"],
            "controller_STOP": result["finished_at"],
            "whole_controller_seconds": result["wall_seconds"],
            "prior_known_software_controller_seconds_HELD": 169.60431484726723,
            "known_all_software_numeric_controller_seconds_decimal": str(
                Decimal("169.60431484726723") + Decimal(str(result["wall_seconds"]))
            ),
            "nested_commands_NOT_ADDED": [
                r["guardian_return"]["wall_seconds"] for r in returned["checks"]
            ],
            "census": {
                "planned": 28,
                "attempted": 28,
                "completed_depth4": 28,
                "UNKNOWN": 0,
                "value_bits_pairs_equal": 14,
                "actions_pairs_equal": 14,
                "PVs_pairs_equal": 12,
            },
            "inputs_before_after_exact": inputs,
            "actual_role_maps": [r["compiled_map"] for r in spec["roles"]],
            "privates_before_after_exact": [r["private"] for r in spec["roles"]],
            "models_before_after_exact": spec["model"],
            "current_source38_and_additional_arena_after_MATCH": True,
            "outer_directwait_cleanup": result,
            "checks_directwait_cleanup": [r["guardian_return"] for r in returned["checks"]],
            "disk_mask_pending_attempted": [
                n.doc(r["persisted_process_receipt"]) for r in returned["checks"]
            ],
            "fresh_owned_identity_census": census,
            "raw_journals_before_after_exact": [r["journal"] for r in saved],
            "resource_before": before,
            "resource_after": after,
            "last_actual_guard_samples_HELD": returned["sampled_charges_B"],
            "all_old_history_RAW_failure_INCOMPLETE_fees_masks_UNKNOWN": "HELD",
            "current_next_job_Cargo_model_Search_game_fair_reservation": "NONE",
            "owned_readers_children_jobs_TMP_remaining": [],
            "continuous_peak_process_CPU_RSS": "UNKNOWN",
            "reader_SOURCE_STOP": n.stamp(),
        }
        g.new_json(HERE / "qualified-numeric-STOP.json", record)
        # Only this current successful operation's sentinel is removed after the
        # saved outer/census/custody/source join; all failed sentinels stay intact.
        operation = Path(spec["operation"])
        fd = os.open(operation, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
            (operation / "INCOMPLETE").unlink()
            os.fsync(fd)
        finally:
            os.close(fd)
    print(
        json.dumps(
            {
                "receipt": ref(HERE / "qualified-numeric-STOP.json"),
                "report": ref(OUT / "report.md"),
                "summary": ref(OUT / "summary.json"),
                "CSV": ref(OUT / "cases-all-counters.csv"),
                "reader_STOP": record["reader_SOURCE_STOP"],
                "lease_released": True,
                "owned_remaining": [],
            }
        )
    )


if __name__ == "__main__":
    main()
