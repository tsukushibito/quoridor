# Compact TT359: fixed28 saved assessment

All28 planned cold calls completed requested depth4; no replacement, repeated measurement or lower-depth rescue. The14 paired values match exact f32 bits. All14 actions match; the two endgame PVs differ and remain legal according to the bound caller's replay. The seven chronological roots, counted histories and unchanged parent captures match the frozen catalogue. Actual GHI/noTT/undo/collision software definitions were reused in their accepted scopes, without replay.

The prebound aggregate whole-case criterion decreases for both D and BEST43 in this single A-before-B block. Work is not identical, and the BEST43 walled-midgame call is slower. These are bounded implementation observations; they establish no robust speed, strength or isolated Zobrist benefit.

| Evaluator | A whole-case sum s | B whole-case sum s |      B/A | A nodes | B nodes | A evaluations | B evaluations |
| --------- | -----------------: | -----------------: | -------: | ------: | ------: | ------------: | ------------: |
| D         |        0.505641185 |        0.371370462 | 0.734455 |  432362 |  433024 |        314018 |        314694 |
| BEST43    |        1.018620914 |        0.902005050 | 0.885516 |  569714 |  569744 |        442158 |        442190 |

## Full setup/drop and counter domains

A is qualified full-history TT image5a871 with embedded source1a44; B is compact board/context Zobrist image072764 with embedded872. Both contain caller33b43/workload892/rootcatalogue3d94. Both actually load BEST43 once through the maintained residual factory, checking typed96a5, descriptor46ec and weights046fe; D remains0/8, LEGACY terminal2, ScalarFT/guarded head and no output bypass. No old live Main was restored.

Whole-case starts before prefix decoding, canonical replay/count capture, context/Arc clone, TT/FT/scratch creation, Search/PVS/PV/correctness capture and ephemeral drop. Evaluator footer includes model setup, seven cases, serialization and evaluator drop. Footer serialization itself and request/selfdigest/catalogue/output/sync/directwait/cleanup belong to process/controller fees. Search elapsed and evaluator/case clocks are nested and never added to external cost. Guarded metadata scans, hash checks, saved verification and observer activity are charged to the controller; their timing interference is UNKNOWN. The observer uses distinct physical core2 and Search core0; this does not prove absence of interference.

The fixed table envelope stays4096slots/1MiB. B reports327728 retained table bytes on every call; A reports794464..1048408. This is table accounting including its header/slots/history capacity, not process RSS. Baseline capacity skips and constructed-history counters remain in raw/CSV; candidate context init/transitions, board hash updates/reads, context misses, index and64-bit hash collisions remain separate. A/B counters with the same label can have different source meanings; no absent field is invented as zero. Hash computations/reads are source counts, not machine instructions. Context matching is qualified by the reviewed noncryptographic128-bit collision assumption, not exact arbitrary history or a complete GHI theorem. These finite rows prove no collision impossibility.

| Evaluator/root                    | Whole B/A |     Nodes A/B | Table bytes A/B | Capacity skips A/B | PV same |
| --------------------------------- | --------: | ------------: | --------------: | -----------------: | ------- |
| D/initial                         |  0.820285 |   68313/68486 |   797632/327728 |                0/0 | True    |
| D/opening                         |  0.934244 |   65647/65622 |  1048168/327728 |             5641/0 | True    |
| D/walled-midgame                  |  0.861235 |   48860/49367 |  1048384/327728 |             6975/0 | True    |
| D/jump-p2                         |  0.830197 |   69549/69487 |  1048408/327728 |             6978/0 | True    |
| D/endgame                         |  0.746741 |   61062/61025 |  1048096/327728 |            10126/0 | False   |
| D/genuine-second-occurrence       |  0.853722 |   68311/68413 |  1048360/327728 |             1541/0 | True    |
| D/genuine-nonterminal-ply200      |  0.455256 |   50620/50624 |  1047856/327728 |            16227/0 | True    |
| BEST43/initial                    |  0.954626 | 114095/115741 |   794464/327728 |                0/0 | True    |
| BEST43/opening                    |  0.899460 |   75278/75151 |  1048384/327728 |             6089/0 | True    |
| BEST43/walled-midgame             |  1.060071 |   53374/53393 |  1047952/327728 |             7317/0 | True    |
| BEST43/jump-p2                    |  0.905598 |   86815/87454 |  1048408/327728 |             7329/0 | True    |
| BEST43/endgame                    |  0.914941 |   72969/69251 |  1047904/327728 |            10658/0 | False   |
| BEST43/genuine-second-occurrence  |  0.955952 | 114169/115322 |  1048312/327728 |             1745/0 | True    |
| BEST43/genuine-nonterminal-ply200 |  0.622118 |   53014/53432 |  1048408/327728 |            16187/0 | True    |

## Costs, limits and decision

External campaign controller: 6.492365032s, including both direct native commands and guards. Native guardian command spans: 1.540610229s and 1.318439223s, nested and not added. Prior software controllers169.60431484726723s remain held; all known software+this campaign176.096679879236032s (decimal sum of supplied scalar facts). Unsaved administration/LLM/whole historical cost remains UNKNOWN. Process CPU, practical family RSS and continuous RSS/allocation peaks were not saved by this adapter and remain UNKNOWN; no substituted old samples. Both full stdout captures are208B.

The frozen completed-value and aggregate whole-wall criteria are satisfied in the observed cases. Candidate changes table availability, work, indices and ordering as well as history/hash processing; this is no same-work or factorial attribution. One fixed order, shared machine/cache conditions, short depths and seven selected roots do not support confidence intervals, population/global speed, the158s depth6-game causal fraction, teacher N, games or default policy changes. Retain this result as limited implementation evidence pending one independent stopped interpretation. No new sweep/perf/game/fit/resize/eviction/reset is recommended by these data. Root alone integrates/adopts and preserves/retires completed comparison-only source after reader STOP.
