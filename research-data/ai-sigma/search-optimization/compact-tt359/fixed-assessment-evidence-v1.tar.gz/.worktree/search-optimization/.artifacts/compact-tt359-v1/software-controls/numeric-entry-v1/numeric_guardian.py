"""One fixed A/B public Search campaign; maintained lifecycle owns both children.

Retire this compare-only adapter after accepted preservation and reader STOP.
No compiler, source/target writes, model probe, replacement runs or TT mode switch.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import time

ROOT = Path("/workspaces/quoridor")
OWN = ROOT / ".worktree/search-optimization/.artifacts/compact-tt359-v1"
LEASE = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
THREAD = "01a11004-79f3-7c20-872c-432a2c347664"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def read(ref):
    require(set(ref) == {"path", "sha256", "bytes", "mode"}, "exact FileRef")
    require(type(ref["bytes"]) is int and 0 <= ref["bytes"] <= 16777216, "input cap")
    with os.fdopen(os.open(ref["path"], os.O_RDONLY | os.O_NOFOLLOW), "rb") as f:
        s = os.fstat(f.fileno())
        require(stat.S_ISREG(s.st_mode) and s.st_size == ref["bytes"], "input size/type")
        b = f.read(ref["bytes"] + 1)
        require(
            len(b) == ref["bytes"]
            and hashlib.sha256(b).hexdigest() == ref["sha256"]
            and format(stat.S_IMODE(s.st_mode), "04o") == ref["mode"],
            "input drift: " + ref["path"],
        )
    return b


def doc(ref):
    return json.loads(read(ref))


def load(ref, name):
    read(ref)
    module = importlib.util.spec_from_file_location(name, ref["path"])
    value = importlib.util.module_from_spec(module)
    module.loader.exec_module(value)
    return value


def packet_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def static(spec):
    require(spec["prepared"] is True and spec["planned_calls"] == 28, "fixed admission")
    support = doc(spec["support"])
    require(
        support["phase"] == "original-28-public-search-assessment"
        and support["funded_union_B"] == 4294967296
        and support["global_increment_B"] == 0
        and support["raw_projection_B"] == 6946816
        and support["components_B"]["controls"] == 8388608,
        "actual contained numerical support",
    )
    require(
        spec["controls_forward_B"] == 2228224
        and spec["target_floor_B"] == support["target_retained_effective_floor_B"]
        and spec["private_floor_B"] == support["private_retained_inclusive_floor_B"],
        "held floors and inclusive forward",
    )
    require(
        spec["limits"]
        == {
            "family_B": 6442450944,
            "controller_B": 67108864,
            "host_reserve_B": 4294967296,
            "worker_cpu": 0,
            "guardian_cpu": 2,
            "log_B": 262144,
        }
        and spec["worker_seconds"] == 1800,
        "finite operational guard, not a predicted benchmark duration",
    )
    require(spec["raw"] == str(OWN / "assessment-raw"), "literal fixed raw inlet")
    require(
        spec["TMP"] == str(OWN / "TMP-supported/numeric-entry-v1")
        and spec["operation"] == str(OWN / "assessment-raw/operation-v1"),
        "exclusive owned phase paths",
    )
    require(spec["env"] == spec["fixed_env"], "exact runtime environment")
    require(
        spec["env"]["TMPDIR"] == spec["TMP"]
        and all(
            spec["env"][n] == "1"
            for n in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")
        )
        and spec["env"]["CUDA_VISIBLE_DEVICES"] == "",
        "one CPU thread and no GPU",
    )
    plan = doc(spec["software_plan"])
    require(plan["caller_sha256"] == spec["caller"]["sha256"], "qualified same public caller")
    require(plan["workload_sha256"] == spec["workload"]["sha256"], "original workload")
    require(len(spec["roles"]) == 2, "only two images")
    for role, expected in zip(spec["roles"], ("baseline", "candidate"), strict=True):
        require(role["name"] == expected, "fixed A then B")
        image = role["private"]
        require(
            image["path"] == str(OWN / "private-images-v1" / (expected + "-v1"))
            and image["mode"] == "0755",
            "exact qualified image",
        )
        source = doc(role["compiled_map"])
        require(
            source["role"] == expected
            and len(source["records"]) == 38
            and source["caller_sha256"] == spec["caller"]["sha256"]
            and source["workload_sha256"] == spec["workload"]["sha256"],
            "role-specific immutable embedded compiler inputs",
        )
        custody = doc(role["qualified_release"])
        require(
            custody["bound_compiled_map"] == role["compiled_map"]
            and custody["only_preserved_private"] == image
            and custody["owned_readers_children_jobs_TMP_remaining"] == [],
            "genuine qualified build/private custody, not numerical proof",
        )
        require(
            role["argv"] == [image["path"], *plan["runtime_interface"]["private_argv"][1:]],
            "exact maintained ignored inlet argv",
        )
        require(
            role["request"]
            == {
                "schema": "compact359-public-search-request.v1",
                "source_map_sha256": role["compiled_map"]["sha256"],
                "workload_sha256": spec["workload"]["sha256"],
                "image_sha256": image["sha256"],
                "catalog_sha256": spec["catalogue"]["sha256"],
                "output": str(Path(spec["raw"]) / (expected + ".jsonl")),
            },
            "fixed canonical request",
        )
        b = packet_bytes(role["request"])
        require(
            len(b) <= 65536 and hashlib.sha256(b).hexdigest() == role["request_sha256"],
            "packet bytes",
        )
    require(
        spec["model"]["descriptor"]["sha256"]
        == "46ec2c4708f96dcf9fad579c2fb0d1299c6663df27412f0faac98267467715e1"
        and spec["model"]["weights"]["sha256"]
        == "046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841"
        and spec["model"]["typed_sha256"]
        == "96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875",
        "frozen BEST43 identity",
    )
    return support


def correspondence(spec, g, *, payload):
    read(spec["current_source_contract"])
    current = doc(spec["current_source_contract"])
    require(current["source_map"] == spec["roles"][1]["compiled_map"], "current Main candidate map")
    g.source_check(current)
    for ref in [
        spec["caller"],
        spec["workload"],
        spec["catalogue"],
        spec["correspondence"],
        *spec["runtime_sources"],
    ]:
        read(ref)
    proof = doc(spec["correspondence"])
    for ref in proof["selected_metadata_source_refs"]:
        read(ref)
    for role in spec["roles"]:
        doc(role["compiled_map"])
        doc(role["qualified_release"])
        if payload:
            read(role["private"])
        else:
            s = Path(role["private"]["path"]).lstat()
            require(
                stat.S_ISREG(s.st_mode) and s.st_size == role["private"]["bytes"], "image metadata"
            )
    for ref in (spec["model"]["descriptor"], spec["model"]["weights"]):
        if payload:
            read(ref)  # Identity bytes only; never instantiate a model in Python.
        else:
            s = Path(ref["path"]).lstat()
            require(
                stat.S_ISREG(s.st_mode)
                and s.st_size == ref["bytes"]
                and format(stat.S_IMODE(s.st_mode), "04o") == ref["mode"],
                "retained model metadata",
            )
    read(spec["marker"])


def storage(spec, g, *, entering=False):
    roots = {
        "target": (Path(spec["target"]), 1073741824, spec["target_floor_B"]),
        "private": (OWN / "private-images-v1", 16777216, spec["private_floor_B"]),
        "controls": (OWN / "software-controls", 8388608, spec["controls_floor_B"]),
        "TMP": (OWN / "TMP-supported", 33554432, spec["TMP_floor_B"]),
    }
    charges = {}
    for name, (path, cap, floor) in roots.items():
        charges[name] = max(floor, g.allocation(path))
        require(charges[name] <= cap, name + " held whole cap")
    raw = Path(spec["raw"])
    if raw.exists():
        charges["raw"] = g.allocation(raw)
        require(charges["raw"] <= 8388608, "raw inclusive cap")
    total = g.allocation(OWN)
    excluded = sum(
        g.allocation(p)
        for p in (OWN / "software-controls", OWN / "private-images-v1", OWN / "TMP-supported")
    )
    if raw.exists():
        excluded += g.allocation(raw)
    charges["selected_source"] = total - excluded
    require(
        charges["selected_source"] <= 20971520 and total <= 134217728,
        "owned source/whole component cap",
    )
    if entering:
        prep = g.allocation(Path(__file__).parent)
        require(prep <= 131072, "contained new preparation")
        outside = g.allocation(OWN / "software-controls") - prep
        require(
            max(spec["controls_floor_B"], outside) + spec["controls_forward_B"] <= 8388608,
            "whole control forward",
        )
        require(spec["raw_forward_B"] == 6946816, "full raw forward")
    require(shutil.disk_usage(OWN).free >= 134217728, "physical FS reserve, not allocation credit")
    return charges


def validate_journal(spec, role, g):
    ref, data = g.bound(role["request"]["output"], 2097152)
    rows = [json.loads(b) for b in data.splitlines()]
    require(rows and rows[0]["kind"] == "header" and rows[-1]["kind"] == "footer", "journal bounds")
    header, footer = rows[0], rows[-1]
    require(
        header["source"] == doc(role["compiled_map"])
        and all(
            header[k] == role["request"][k]
            for k in ("source_map_sha256", "workload_sha256", "image_sha256", "catalog_sha256")
        )
        and header["planned_returns_this_image"] == 14
        and header["planned_returns_whole"] == 28,
        "actual embedded role/image/model-root journal binding",
    )
    require(
        footer["success"] is True
        and footer["completed"] == 14
        and footer["Search_invocations_attempted"] == 14
        and footer["primary"] is None,
        "all14 genuine completed returns",
    )
    cases = [r for r in rows if r["kind"] == "case"]
    attempts = [r for r in rows if r["kind"] == "case_attempt"]
    require(len(cases) == len(attempts) == 14, "case/attempt denominator")
    work, catalog = doc(spec["workload"]), doc(spec["catalogue"])
    setups = [r for r in rows if r["kind"] == "evaluator_setup"]
    require([r["name"] for r in setups] == ["D", "BEST43"], "once per-image evaluator order")
    require(
        [r["identity"] for r in setups] == spec["evaluator_identities"],
        "actual typed evaluator/frame identity",
    )
    for i, (case, attempt) in enumerate(zip(cases, attempts, strict=True)):
        fixture, root = work["roots"][i % 7], catalog["roots"][i % 7]
        require(
            case["root"] == attempt["root"] == fixture["name"]
            and case["prefix"] == attempt["prefix"] == fixture["prefix"]
            and case["root_identity"] == root["identity"]
            and attempt["evaluator"] == ("D" if i < 7 else "BEST43")
            and case["evaluator_identity"] == setups[i // 7]["identity"]
            and case["completed_depth"] == case["requested_depth"] == 4
            and case["stop"] == "DepthComplete"
            and case["root_restored"] is True
            and case["session_table_after_bytes"] <= 1048576
            and case["stats"]["tt_retained_bytes"] <= 1048576,
            "fixed completed root/evaluator/cap/correctness correspondence",
        )
    return {"journal": ref, "completed": 14, "cases": cases, "footer": footer}


def run(intent_ref):
    spec = doc(intent_ref)
    static(spec)  # No dynamic imports, TMP, target read or Popen before NB lease.
    with LEASE.open("r+b") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        g = load(spec["source_helper"], "compact359_source_utils")
        correspondence(spec, g, payload=False)
        lifecycle = load(spec["runtime_sources"][0], "compact359_numeric_lifecycle")
        lifecycle.physical_and_quiet(spec)
        correspondence(spec, g, payload=True)
        storage(spec, g, entering=True)
        runtime = Path(os.environ.get("QUORIDOR_RESEARCH_JOB_DIR", ""))
        require(runtime.is_absolute(), "actual originating job")
        cfg_ref, b = g.bound(runtime / "config.json")
        cfg, state = json.loads(b), json.loads((runtime / "state.json").read_bytes())
        require(
            cfg["argv"]
            == [
                sys.executable,
                "-B",
                str(Path(__file__)),
                "--intent",
                intent_ref["path"],
                "--sha256",
                intent_ref["sha256"],
            ]
            and cfg["issue"] == "quoridor-4lc.359.1"
            and cfg["thread_id"] == THREAD
            and cfg["goal_issue"] == "quoridor-4lc.359"
            and cfg["cwd"] == str(ROOT)
            and cfg["resource_contract"] == spec["support"]["path"]
            and cfg["max_runtime_seconds"] == 1860
            and state["phase"] in {"starting", "running"}
            and state["config_sha256"]
            == hashlib.sha256(json.dumps(cfg, sort_keys=True).encode()).hexdigest()
            and state["supervisor"]["pid"] == os.getppid()
            and lifecycle.process.alive(state["supervisor"]),
            "actual single originating campaign",
        )
        raw, tmp, operation = Path(spec["raw"]), Path(spec["TMP"]), Path(spec["operation"])
        for path in (raw, tmp):
            g.witness_absence(path)
        raw.mkdir()
        operation.mkdir()
        deadline = time.monotonic() + spec["worker_seconds"]

        class Limits(lifecycle.process.CycleResources):
            def __init__(self):
                super().__init__(
                    {
                        "host_ram_reserve": 4294967296,
                        "max_memory_bytes": 6442450944 - 67108864,
                        "max_output_bytes": 8388608,
                    },
                    raw,
                    deadline,
                )
                self.next_storage, self.sampled = 0, {}

            def check(self, children=()):
                super().check(children)
                if time.monotonic() >= self.next_storage:
                    for name, value in storage(spec, g).items():
                        self.sampled[name] = max(self.sampled.get(name, 0), value)
                    self.next_storage = time.monotonic() + 1

        ledger, completed, secondary, requests = [], [], [], []
        result = dict(
            status="ATTEMPTED",
            START=stamp(),
            intent=intent_ref,
            origin={
                "config": cfg_ref,
                "job_id": state["job_id"],
                "supervisor": state["supervisor"],
            },
            checks=ledger,
            journals=completed,
            requests=requests,
            planned_calls=28,
            primary=None,
            secondary=secondary,
            continuous_peak="UNKNOWN",
        )
        resources, primary = None, None
        try:
            tmp.mkdir()
            g.new_json(operation / "INCOMPLETE", {"intent": intent_ref})
            resources = Limits()
            with lifecycle.process.cancellation_signals():
                for role in spec["roles"]:
                    correspondence(spec, g, payload=True)
                    resources.check()
                    request = raw / (role["name"] + "-request.json")
                    with request.open("xb") as f:
                        f.write(packet_bytes(role["request"]))
                        f.flush()
                        os.fsync(f.fileno())
                    request_ref, _ = g.bound(request, 65536)
                    require(
                        request_ref["sha256"] == role["request_sha256"],
                        "actual request identity before child",
                    )
                    requests.append(request_ref)
                    child_spec = {
                        **spec,
                        "env": {**spec["env"], "QUORIDOR_TT359_REQUEST": str(request)},
                    }
                    row = {
                        "name": role["name"],
                        "role": "original14 cold calls only",
                        "argv": role["argv"],
                    }
                    lifecycle.command(child_spec, row, operation, resources, ledger=ledger)
                    completed.append(validate_journal(spec, role, g))
                require(
                    [r["value_bits"] for r in completed[0]["cases"]]
                    == [r["value_bits"] for r in completed[1]["cases"]],
                    "prebound baseline/candidate completed value bits differ; no normalization or speed claim",
                )
                result["status"] = "RETURNED_FIXED28_PENDING_OUTER_JOIN"
        except BaseException as error:
            primary = error
            result["status"], result["primary"] = "FAILED", lifecycle.error_fact(error)
        finally:
            for stage, action in (
                ("source_private_model_after", lambda: correspondence(spec, g, payload=True)),
                ("request_after", lambda: [read(ref) for ref in requests]),
                ("charges_after", lambda: resources.check() if resources else None),
                ("empty_TMP_rmdir", tmp.rmdir),
            ):
                try:
                    action()
                except BaseException as error:
                    secondary.append({"stage": stage, **lifecycle.error_fact(error)})
            result["STOP"] = stamp()
            result["sampled_charges_B"] = resources.sampled if resources else {}
            result["returned_cleanup"] = (
                all(
                    (r.get("guardian_return") or {}).get("cleanup_complete") is True for r in ledger
                )
                if ledger
                else None
            )
            result["completed_validated_calls"] = sum(r["completed"] for r in completed)
            result["uncompleted_calls"] = (
                0
                if result["completed_validated_calls"] == 28
                else "UNKNOWN; denominator28 retained, saved partial rows not erased, no refill"
            )
            try:
                g.new_json(operation / "guardian-result.json", result)
            except BaseException as error:
                secondary.append({"stage": "result_publication", **lifecycle.error_fact(error)})
                if primary is None:
                    primary = error
            if primary is not None:
                for error in secondary:
                    primary.add_note(str(error))
                raise primary
            require(not secondary, "independent finalization failed")
            # Owner joins saved outer result/private/source/cleanup before removing
            # this operation's INCOMPLETE; disk masks are never relabelled.


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--intent", required=True)
    parser.add_argument("--sha256", required=True)
    args = parser.parse_args()
    s = Path(args.intent).lstat()
    require(stat.S_ISREG(s.st_mode) and s.st_size <= 65536, "intent cap/type")
    ref = {
        "path": args.intent,
        "sha256": args.sha256,
        "bytes": s.st_size,
        "mode": format(stat.S_IMODE(s.st_mode), "04o"),
    }
    run(ref)


if __name__ == "__main__":
    main()
