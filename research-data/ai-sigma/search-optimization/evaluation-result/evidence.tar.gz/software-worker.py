"""One fixed evaluation candidate: serial offline builds and correctness only."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
OUT = ROOT / ".artifacts/search-optimization/evaluation-v1"
TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized(rows):
    def clean(v):
        if isinstance(v, dict):
            return {
                k: clean(x) for k, x in v.items() if k not in ("elapsed_ns", "whole_ns")
            }
        if isinstance(v, list):
            return [clean(x) for x in v]
        return v

    return clean(rows)


def main():
    os.sched_setaffinity(0, {0, 1})
    started = time.monotonic()
    env = dict(
        os.environ,
        CARGO_TARGET_DIR=str(TARGET),
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        CARGO_INCREMENTAL="0",
        TMPDIR=str(OUT / "tmp"),
    )
    (OUT / "tmp").mkdir(exist_ok=True)
    plan = json.loads((OUT / "plan.json").read_text())
    for path, expected in plan["source_and_dependency_SHA"].items():
        assert sha(Path(path)) == expected, path
    commands = []

    def run(name, argv):
        assert time.monotonic() - started < 80, "phase deadline before next child"
        start = time.monotonic()
        with (OUT / (name + ".log")).open("wb") as log:
            child = subprocess.Popen(
                argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT
            )
            rc = child.wait()
        commands.append(
            {
                "name": name,
                "argv": argv,
                "exit": rc,
                "wall_s": time.monotonic() - start,
                "direct_child_waited": True,
            }
        )
        (OUT / "software-commands.json").write_text(
            json.dumps(commands, indent=2) + "\n"
        )
        if rc:
            raise RuntimeError(f"{name} failed: {rc}; no retry")

    cargo = ["/usr/local/cargo/bin/cargo"]
    common = ["--release", "--offline", "--locked", "-j", "2"]
    source = ROOT / "crates/quoridor-nnue/src/residual.rs"
    try:
        shutil.copyfile(OUT / "baseline-residual.rs", source)
        run(
            "build-baseline",
            cargo
            + ["build"]
            + common
            + [
                "-p",
                "quoridor-ai",
                "--features",
                "research",
                "--example",
                "search_profile",
            ],
        )
        shutil.copyfile(
            TARGET / "release/examples/search_profile", OUT / "baseline-plain"
        )
    finally:
        shutil.copyfile(OUT / "candidate-residual.rs", source)
    run(
        "build-candidate",
        cargo
        + ["build"]
        + common
        + [
            "-p",
            "quoridor-ai",
            "--features",
            "research",
            "--example",
            "search_profile",
        ],
    )
    shutil.copyfile(TARGET / "release/examples/search_profile", OUT / "candidate-plain")
    run(
        "unit-oracle",
        cargo
        + ["test"]
        + common
        + [
            "-p",
            "quoridor-nnue",
            "--features",
            "research",
            "--lib",
            "inline_and_heap_inputs_match_allocating_reference_bits",
            "--",
            "--test-threads=1",
        ],
    )
    run(
        "residual-full-delta",
        cargo
        + ["test"]
        + common
        + [
            "-p",
            "quoridor-nnue",
            "--features",
            "research",
            "--test",
            "residual",
            "residual_full_delta_simd_and_parent_return",
            "--",
            "--test-threads=1",
        ],
    )
    run(
        "ai-semantic",
        cargo
        + ["test"]
        + common
        + [
            "-p",
            "quoridor-ai",
            "--features",
            "research",
            "--test",
            "alphabeta_search",
            "--",
            "--test-threads=1",
        ],
    )
    run(
        "clippy",
        cargo
        + ["clippy"]
        + common
        + [
            "-p",
            "quoridor-ai",
            "-p",
            "quoridor-nnue",
            "--features",
            "research",
            "--lib",
            "--example",
            "search_profile",
            "--",
            "-D",
            "warnings",
        ],
    )
    oracle = {}
    forward = 786
    for variant in ["baseline", "candidate"]:
        run(
            variant + "-oracle",
            [str(OUT / (variant + "-plain")), str(OUT / "config.json"), "oracle"],
        )
        rows = [
            json.loads(x)
            for x in (OUT / (variant + "-oracle.log")).read_text().splitlines()
        ]
        assert rows[-1]["kind"] == "job" and rows[-1]["oracle"]
        forward += rows[-1]["forwards"]
        oracle[variant] = normalized(rows)
    assert oracle["baseline"] == oracle["candidate"], "fixedBEST oracle results differ"
    for path, expected in plan["source_and_dependency_SHA"].items():
        assert sha(Path(path)) == expected, path
    receipt = {
        "status": "PASS",
        "actual_forward": forward,
        "unit_reference_forward": 768,
        "residual_fixture_forward": 18,
        "baseline_candidate_oracle_equal": True,
        "private_binary_SHA": {
            v: sha(OUT / (v + "-plain")) for v in ["baseline", "candidate"]
        },
        "whole_s": time.monotonic() - started,
        "commands": commands,
        "comparative_clocks": False,
        "no_retry": True,
    }
    (OUT / "software-result.json").write_text(json.dumps(receipt, indent=2) + "\n")


if __name__ == "__main__":
    main()
