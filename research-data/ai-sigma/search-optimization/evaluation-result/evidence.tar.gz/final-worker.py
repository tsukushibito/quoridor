"""Final allocated oracle plus alternating plain comparison; no build or retry."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

OUT = Path(
    "/workspaces/quoridor/.worktree/search-optimization/.artifacts/search-optimization/evaluation-v1"
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def clean(v):
    if isinstance(v, dict):
        return {
            k: clean(x) for k, x in v.items() if k not in ("elapsed_ns", "whole_ns")
        }
    if isinstance(v, list):
        return [clean(x) for x in v]
    return v


def identity(pid):
    p = Path("/proc") / str(pid)
    fields = (p / "stat").read_text().rsplit(")", 1)[1].split()
    return {
        "pid": pid,
        "start_ticks": fields[19],
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    }


def main():
    os.sched_setaffinity(0, {0})
    started = time.monotonic()
    logs = OUT / "final-logs"
    logs.mkdir(exist_ok=False)
    plan = json.loads((OUT / "final-plan.json").read_text())
    for path, expected in plan["SHA"].items():
        assert sha(path) == expected, path
    records = []
    forwards = 786

    def run(name, variant, mode, forward_upper):
        nonlocal forwards
        assert time.monotonic() - started < 84, "worker deadline before Popen"
        assert forwards + forward_upper <= 8000000, "new forward cap before Popen"
        binary = OUT / (variant + "-plain")
        assert os.access(binary, os.X_OK)
        with (
            (logs / (name + ".jsonl")).open("wb") as stdout,
            (logs / (name + ".stderr")).open("wb") as stderr,
        ):
            begin = time.monotonic_ns()
            child = subprocess.Popen(
                [str(binary), str(OUT / "config.json"), mode],
                stdout=stdout,
                stderr=stderr,
            )
            proc = identity(child.pid)
            state = {
                "name": name,
                "mode": mode,
                "variant": variant,
                "status": "running",
                "child": proc,
            }
            (logs / (name + ".process.json")).write_text(
                json.dumps(state, indent=2) + "\n"
            )
            rc = child.wait()
            elapsed = time.monotonic_ns() - begin
        state.update(
            status="complete",
            exit_code=rc,
            direct_child_waited=True,
            process_wall_ns=elapsed,
        )
        (logs / (name + ".process.json")).write_text(json.dumps(state, indent=2) + "\n")
        assert rc == 0, f"{name} failed {rc}; no retry"
        rows = [
            json.loads(x) for x in (logs / (name + ".jsonl")).read_text().splitlines()
        ]
        assert rows[-1]["kind"] == ("micro" if mode == "micro" else "job")
        actual = rows[-1]["forwards"]
        assert actual <= forward_upper, "forward upper violated"
        forwards += actual
        record = {
            "name": name,
            "variant": variant,
            "mode": mode,
            "process_wall_ns": elapsed,
            "actual_forward": actual,
            "binary_summary": rows[-1],
            "direct_child_waited": True,
            "exit": rc,
        }
        if mode == "plain":
            work = [x for x in rows if x["kind"] in ("seed", "search")]
            assert len(work) == 30
            for row in work:
                assert row["result"]["depth"] == (3 if row["kind"] == "seed" else 2)
                assert row["result"]["stop"] == "DepthComplete"
            record.update(
                target_whole_ns=sum(
                    x["whole_ns"] for x in work if x["kind"] == "search"
                ),
                seed_whole_ns=sum(x["whole_ns"] for x in work if x["kind"] == "seed"),
            )
        records.append(record)
        (logs / "records.json").write_text(json.dumps(records, indent=2) + "\n")
        return rows

    oracle = {}
    oracle_start = time.monotonic()
    for variant in ["baseline", "candidate"]:
        rows = run(variant + "-oracle", variant, "oracle", 200000)
        assert rows[-1]["oracle"]
        oracle[variant] = clean(rows)
    assert oracle["baseline"] == oracle["candidate"], (
        "fixedBEST oracle bits/action/PV/depth/nodes/exported counters differ"
    )
    oracle_s = time.monotonic() - oracle_start
    assert oracle_s < 43.01537555793766, "remaining software allocation"
    (logs / "oracle-PASS.json").write_text(
        json.dumps(
            {
                "status": "PASS",
                "same_frozenBEST": True,
                "exact_all_exported_oracle_fields_equal": True,
                "software_oracle_s": oracle_s,
            },
            indent=2,
        )
        + "\n"
    )
    comparison_start = time.monotonic()
    reference = None
    micro_checksum = None
    for pair in range(4):
        order = (
            ["baseline", "candidate"] if pair % 2 == 0 else ["candidate", "baseline"]
        )
        for variant in order:
            assert time.monotonic() - comparison_start < 55, (
                "plain allocation before next Popen"
            )
            rows = run(f"pair{pair}-{variant}", variant, "plain", 3001000)
            semantic = clean(
                [
                    {k: v for k, v in x.items() if k not in ("profile", "clock_active")}
                    for x in rows
                    if x["kind"] in ("fixture", "seed", "search")
                ]
            )
            if reference is None:
                reference = semantic
            assert reference == semantic, (
                "plain action/valuebits/PV/depth/nodes/exported counters differ"
            )
            records[-1].update(pair=pair, order=order, exact_semantic_equal=True)
        for variant in order:
            rows = run(f"micro{pair}-{variant}", variant, "micro", 50000)
            value = rows[-1]["checksum"]
            if micro_checksum is None:
                micro_checksum = value
            assert value == micro_checksum, "micro checksum mismatch"
            records[-1].update(pair=pair, order=order, checksum_equal=True)
        (logs / "records.json").write_text(json.dumps(records, indent=2) + "\n")
    assert time.monotonic() - comparison_start <= 60, "plain allocation exceeded"
    for path, expected in plan["SHA"].items():
        assert sha(path) == expected, path
    summary = {
        "status": "PASS",
        "oracle_exact_equal": True,
        "plain_exact_equal": True,
        "pairs": 4,
        "plain_runs": 8,
        "micro_runs": 8,
        "records": records,
        "actual_forward_total_including_786_prior": forwards,
        "actual_forward_this_job": forwards - 786,
        "oracle_wall_s": oracle_s,
        "comparison_wall_s": time.monotonic() - comparison_start,
        "worker_wall_s": time.monotonic() - started,
        "shared_target_reads_writes": 0,
        "no_profile": True,
        "no_retry": True,
    }
    (logs / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
