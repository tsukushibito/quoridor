//! Bounded fixed-history NNUE diagnostic. No games, training or strength claims.
use quoridor_ai::alphabeta::{self as ab, StaticEvaluator};
use quoridor_core::research::SigmaContext;
use quoridor_nnue::{EvaluationMode, residual::ResidualModel};
use serde_json::{Value, json};
use std::{
    sync::{Arc, atomic::AtomicBool},
    time::Instant,
};

fn namespace(weights: &str) -> ab::SearchNamespace {
    ab::SearchNamespace {
        evaluator: format!("residual-v3:scalar:{weights}"),
        rules: "Sigma:history-complete:ply200".into(),
        selectivity: "full-width:PVS:no-MPC:no-LMR".into(),
    }
}
fn record(r: &ab::SearchResult) -> Value {
    let s = &r.stats;
    json!({"action":r.action,"value_bits":r.value.map(f32::to_bits),"pv":r.pv,
        "depth":r.completed_depth,"stop":format!("{:?}",r.stop),"elapsed_ns":r.elapsed.as_nanos(),
        "nodes":s.nodes,"evaluations":s.evaluations,"terminal":s.terminal,"cutoffs":s.cutoffs,
        "pvs_researches":s.pvs_researches,"delta_updates":s.delta_updates,
        "tt_probes":s.tt_probes,"tt_hits":s.tt_hits,"tt_exact_hits":s.tt_exact_hits,
        "tt_usable_depth":s.tt_usable_depth,"tt_cutoffs":s.tt_cutoffs,"tt_order_only":s.tt_order_only,
        "tt_key_builds":s.tt_key_builds,"tt_history_items":s.tt_history_items,"tt_hashes":s.tt_hashes,
        "tt_retained_bytes":s.tt_retained_bytes,"tt_capacity_skips":s.tt_capacity_skips,
        "tt_illegal_moves":s.tt_illegal_moves})
}
fn clocks(active: bool) {
    #[cfg(feature = "profiling")]
    if active {
        quoridor_core::profiling::reset(false);
    }
    #[cfg(not(feature = "profiling"))]
    let _ = active;
}
fn snapshot(active: bool) -> Value {
    #[cfg(feature = "profiling")]
    if active {
        use quoridor_core::profiling::{self, COUNT, NAMES};
        let s = profiling::snapshot();
        let mut rows = Vec::new();
        for (kind, name) in NAMES.iter().enumerate() {
            for (parent, parent_name) in NAMES.iter().enumerate().take(COUNT) {
                let m = s.metrics[kind][parent];
                if m.calls > 0 {
                    rows.push(json!({"kind":name,"parent":parent_name,"calls":m.calls,
                    "inclusive_ns":m.inclusive_ns,"exclusive_ns":m.exclusive_ns}));
                }
            }
        }
        return json!(rows);
    }
    let _ = active;
    Value::Null
}
fn full_oracle(c: &SigmaContext, model: &ResidualModel, depth: u16, forwards: &mut u64) -> f32 {
    if let Some(v) = c.terminal_value() {
        return v * ab::TERMINAL_SCORE;
    }
    if depth == 0 {
        *forwards += 1;
        return model
            .evaluate(&model.full_context(c, EvaluationMode::Scalar).unwrap())
            .unwrap();
    }
    c.legal_ids()
        .into_iter()
        .map(|id| -full_oracle(&c.play(id).unwrap(), model, depth - 1, forwards))
        .fold(f32::NEG_INFINITY, f32::max)
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().collect();
    assert_eq!(
        args.len(),
        3,
        "search_profile CONFIG MODE(profile|plain|oracle)"
    );
    let config: Value = serde_json::from_slice(&std::fs::read(&args[1])?)?;
    let active = args[2] == "profile";
    let oracle = args[2] == "oracle";
    assert!(active || oracle || args[2] == "plain");
    let job = Instant::now();
    let model = Arc::new(ResidualModel::load(config["manifest"].as_str().unwrap())?);
    let evaluator: Arc<dyn StaticEvaluator> = Arc::new(ab::ResidualEvaluator::new(model.clone()));
    let ns = namespace(config["weights_sha"].as_str().unwrap());
    let limits = ab::SearchLimits {
        max_depth: 2,
        max_nodes: 100_000,
        time_limit: None,
        tt_entries: 4096,
        use_pvs: true,
        use_tt: true,
    };
    let cancel = AtomicBool::new(false);
    let mut forwards = 0u64;
    let mut nodes = 0u64;
    for fixture in config["fixtures"].as_array().unwrap() {
        let prefix: Vec<u16> = serde_json::from_value(fixture["prefix"].clone())?;
        let root = SigmaContext::from_prefix(&prefix)?;
        root.validate_normal()?;
        let before = (root.position(), root.history_counts(), root.total_ply());
        println!(
            "{}",
            json!({"kind":"fixture","name":fixture["name"],"prefix":prefix,
            "key":root.position().position_key(),"history":format!("{:?}",root.history_counts()),
            "ply":root.total_ply(),"legal":root.legal_ids()})
        );
        if oracle {
            let parent = model.full_context(&root, EvaluationMode::Scalar)?;
            for id in root.legal_ids() {
                let mut c = root.clone();
                let undo = c.make_move(id)?;
                let full = model.full_context(&c, EvaluationMode::Scalar)?;
                let delta = model.delta_context(&parent, &c)?;
                assert!((model.evaluate(&full)? - model.evaluate(&delta)?).abs() <= 1e-5);
                forwards += 2;
                c.unmake_move(undo)?;
                assert_eq!((c.position(), c.history_counts(), c.total_ply()), before);
            }
            let expected = full_oracle(&root, &model, 2, &mut forwards);
            let r = ab::search(&root, evaluator.as_ref(), &limits, &cancel)?;
            nodes += r.stats.nodes;
            forwards += r.stats.evaluations;
            assert!((r.value.unwrap() - expected).abs() <= 1e-5);
            assert_eq!(r.completed_depth, 2);
            println!(
                "{}",
                json!({"kind":"oracle","name":fixture["name"],"value":expected,"result":record(&r)})
            );
            continue;
        }
        // Fixed next action from a preserved legal replay, independent of measured outputs.
        let next = root.play(fixture["next"].as_u64().unwrap() as u16)?;
        assert_eq!(next.total_ply(), root.total_ply() + 1);
        for round in 0..4 {
            let mut warm = ab::SearchSession::new(evaluator.clone(), ns.clone(), 4096)?;
            let mut seed_limits = limits.clone();
            seed_limits.max_depth = 3;
            let seed_start = Instant::now();
            let seed = warm.search(&root, &seed_limits, &cancel)?;
            nodes += seed.stats.nodes;
            forwards += seed.stats.evaluations;
            println!(
                "{}",
                json!({"kind":"seed","name":fixture["name"],"round":round,
                "whole_ns":seed_start.elapsed().as_nanos(),"result":record(&seed)})
            );
            let variants = if round % 2 == 0 {
                ["cold", "warm"]
            } else {
                ["warm", "cold"]
            };
            for variant in variants {
                clocks(active);
                let start = Instant::now();
                let (r, memory) = if variant == "warm" {
                    let r = warm.search(&next, &limits, &cancel)?;
                    (r, warm.retained_memory_bytes())
                } else {
                    let mut cold = ab::SearchSession::new(evaluator.clone(), ns.clone(), 4096)?;
                    let r = cold.search(&next, &limits, &cancel)?;
                    (r, cold.retained_memory_bytes())
                };
                let whole = start.elapsed().as_nanos();
                let profile = snapshot(active);
                nodes += r.stats.nodes;
                forwards += r.stats.evaluations;
                assert_eq!(r.completed_depth, 2);
                assert!(next.legal_ids().contains(&r.action.unwrap()));
                println!(
                    "{}",
                    json!({"kind":"search","name":fixture["name"],"round":round,
                    "variant":variant,"clock_active":active,"whole_ns":whole,"result":record(&r),
                    "table_bytes":memory.0,"metadata_bytes":memory.1,"profile":profile})
                );
            }
        }
        assert_eq!(
            (root.position(), root.history_counts(), root.total_ply()),
            before
        );
    }
    println!(
        "{}",
        json!({"kind":"job","forwards":forwards,"nodes":nodes,"whole_ns":job.elapsed().as_nanos(),
        "profile_compiled":cfg!(feature="profiling"),"clock_active":active,"oracle":oracle})
    );
    Ok(())
}
