"""Finite current-BEST caller/allocation/plain comparison; whole-job accounting."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
OUT = ROOT / ".artifacts/search-optimization/caller-cost-v1"
TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")
RESIDUAL = ROOT / "crates/quoridor-nnue/src/residual.rs"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + "\n")


def semantic(rows):
    results = []
    for row in rows:
        if row["kind"] == "search":
            result = dict(row["result"])
            result.pop("elapsed_ns")
            results.append(
                {"name": row["name"], "prefix": row["prefix"], "result": result}
            )
        elif row["kind"] == "micro":
            results.append({k: row[k] for k in ("name", "checksum", "forwards")})
    return results


def main():
    os.sched_setaffinity(0, {0, 1})
    plan = json.loads((OUT / "plan.json").read_text())
    for path, expected in plan["SHA"].items():
        assert sha(path) == expected, path
    assert sha(plan["baseline_residual"]) == plan["baseline_SHA"]
    assert sha(plan["candidate_residual"]) == plan["candidate_SHA"]
    assert sha(plan["model"]["manifest"]) == plan["model"]["manifest_SHA"]
    manifest = json.loads(Path(plan["model"]["manifest"]).read_text())
    weights = Path(plan["model"]["manifest"]).parent / manifest["weights"]
    assert sha(weights) == plan["model"]["weights_SHA"]
    env = dict(
        os.environ,
        CARGO_TARGET_DIR=str(TARGET),
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        CARGO_INCREMENTAL="0",
    )
    commands = []
    runs = []
    binaries = {}
    numeric_forwards = 0
    result = {
        "status": "RUNNING",
        "commands": commands,
        "runs": runs,
        "model": plan["model"],
        "shared_target_growth_peak_B": None,
    }
    (OUT / "private").mkdir()

    def command(name, argv, scientific=False):
        nonlocal numeric_forwards
        begin = time.perf_counter_ns() if scientific else None
        with (OUT / (name + ".log")).open("wb") as log:
            child = subprocess.Popen(
                argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT
            )
            rc = child.wait()
        elapsed = time.perf_counter_ns() - begin if scientific else None
        commands.append(
            {"name": name, "argv": argv, "exit": rc, "direct_child_waited": True}
        )
        write("commands.json", commands)
        text = (OUT / (name + ".log")).read_text()
        rows = [json.loads(line) for line in text.splitlines() if line.startswith("{")]
        completed = [row for row in rows if row.get("kind") == "complete"]
        if completed:
            numeric_forwards += completed[-1]["forwards"]
        else:
            # Partial/failure calls outside published search records remain UNKNOWN.
            numeric_forwards += sum(
                row["result"]["evaluations"]
                for row in rows
                if row.get("kind") == "search"
            )
            numeric_forwards += sum(
                row["forwards"] for row in rows if row.get("kind") == "micro"
            )
        result["numeric_forwards_recorded"] = numeric_forwards
        write("result.json", result)
        assert rc == 0, name + " failed; affected job stops, no blind retry"
        if scientific:
            assert len(completed) == 1
        return rows, elapsed

    try:
        for variant in ("baseline", "candidate"):
            RESIDUAL.write_bytes(Path(plan[variant + "_residual"]).read_bytes())
            assert sha(RESIDUAL) == plan[variant + "_SHA"]
            for observed in (False, True):
                name = variant + ("-observed" if observed else "-plain")
                features = "research,profiling" if observed else "research"
                command(
                    "build-" + name,
                    [
                        "/usr/local/cargo/bin/cargo",
                        "build",
                        "--release",
                        "--offline",
                        "--locked",
                        "-j",
                        "2",
                        "-p",
                        "quoridor-ai",
                        "--features",
                        features,
                        "--example",
                        "search_cost",
                    ],
                )
                source = TARGET / "release/examples/search_cost"
                data = source.read_bytes()
                private = OUT / "private" / name
                private.write_bytes(data)
                private.chmod(0o555)
                compressed = OUT / "private" / (name + ".gz")
                compressed.write_bytes(gzip.compress(data, compresslevel=6, mtime=0))
                binaries[name] = {
                    "path": str(private),
                    "SHA": sha(private),
                    "source_SHA": sha(RESIDUAL),
                    "features": features,
                    "bytes": len(data),
                    "compressed_bytes": compressed.stat().st_size,
                }
                write("binary-binding.json", binaries)
                assert (
                    sum(p.stat().st_blocks * 512 for p in (OUT / "private").iterdir())
                    <= 6291456
                ), "private artifact forecast exceeded"
        assert sha(RESIDUAL) == plan["candidate_SHA"]
        command(
            "clippy-entry",
            [
                "/usr/local/cargo/bin/cargo",
                "clippy",
                "--release",
                "--offline",
                "--locked",
                "-j",
                "2",
                "-p",
                "quoridor-ai",
                "--features",
                "research,profiling",
                "--example",
                "search_cost",
                "--",
                "-D",
                "warnings",
            ],
        )
        reference = None
        micro_reference = None

        def run(name, binary, mode):
            nonlocal reference, micro_reference
            rows, elapsed = command(
                name,
                [binaries[binary]["path"], str(OUT / "config.json"), mode],
                scientific=True,
            )
            fields = semantic(rows)
            if mode == "micro":
                if micro_reference is None:
                    micro_reference = fields
                assert fields == micro_reference, "micro numeric mismatch"
            else:
                if reference is None:
                    reference = fields
                assert fields == reference, (
                    "exact action/value/PV/depth/nodes/stats mismatch"
                )
            runs.append(
                {
                    "name": name,
                    "binary": binary,
                    "mode": mode,
                    "process_wall_ns": elapsed,
                    "whole_ns": rows[-1]["whole_ns"],
                    "search_ns": sum(
                        r["search_ns"] for r in rows if r["kind"] == "search"
                    ),
                    "micro_ns": sum(
                        r["evaluate_ns"] for r in rows if r["kind"] == "micro"
                    ),
                    "forwards": rows[-1]["forwards"],
                    "semantic_parity": True,
                }
            )
            write("result.json", result)

        for i, variant in enumerate(plan["plain_order"]):
            run("plain-" + str(i), variant + "-plain", "plain")
        for i, spec in enumerate(plan["calibration_order"]):
            binary, mode = spec.split(":")
            run("calibration-" + str(i), binary, mode)
        for i, variant in enumerate(plan["micro_order"]):
            run("micro-" + str(i), variant + "-plain", "micro")
        result.update(
            status="PASS_LIMITED_PARITY; COST_SPEED_RESULT_PENDING_AGGREGATION",
            frozen_five_root_depth=3,
            numeric_forwards=numeric_forwards,
            allocation_memory_principle_distinct_from_speed=True,
            finite_list_complete=True,
        )
    except BaseException as error:
        result.update(
            status="FAILED_PRESERVED",
            error=repr(error),
            numeric_forwards_recorded=numeric_forwards,
            uncompleted_stage_forward="UNKNOWN",
        )
        raise
    finally:
        # Restore stopped candidate math before returning shared-target/source ownership.
        RESIDUAL.write_bytes(Path(plan["candidate_residual"]).read_bytes())
        result["stopped_residual_SHA"] = sha(RESIDUAL)
        result["binaries"] = binaries
        write("result.json", result)


if __name__ == "__main__":
    main()
