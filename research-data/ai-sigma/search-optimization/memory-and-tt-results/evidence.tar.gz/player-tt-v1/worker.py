"""Fixed real-player TT series and current bounded-head clock calibration."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
OUT = ROOT / ".artifacts/search-optimization/player-tt-v1"
TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    os.sched_setaffinity(0, {0, 1})
    plan = json.loads((OUT / "plan.json").read_text())
    for path, expected in plan["source_SHA"].items():
        assert sha(path) == expected, path
    assert sha(plan["model_manifest"]) == plan["model_manifest_SHA"]
    manifest = json.loads(Path(plan["model_manifest"]).read_text())
    assert (
        sha(Path(plan["model_manifest"]).parent / manifest["weights"])
        == plan["weights_SHA"]
    )
    for b in plan["existing_bounded_binding"].values():
        assert sha(b["path"]) == b["SHA"]
    env = dict(
        os.environ,
        CARGO_TARGET_DIR=str(TARGET),
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        CARGO_INCREMENTAL="0",
    )
    result = {
        "status": "RUNNING",
        "commands": [],
        "runs": [],
        "forwards": 0,
        "shared_target_growth_peak_B": None,
    }

    def save():
        (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    def command(name, argv, numeric=False):
        start = time.perf_counter_ns() if numeric else None
        with (OUT / (name + ".log")).open("wb") as log:
            child = subprocess.Popen(
                argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT
            )
            rc = child.wait()
        elapsed = time.perf_counter_ns() - start if numeric else None
        result["commands"].append(
            {"name": name, "argv": argv, "exit": rc, "direct_child_waited": True}
        )
        save()
        rows = [
            json.loads(line)
            for line in (OUT / (name + ".log")).read_text().splitlines()
            if line.startswith("{")
        ]
        complete = [r for r in rows if r.get("kind") == "complete"]
        if complete:
            result["forwards"] += complete[-1]["forwards"]
            result["runs"].append(
                {
                    "name": name,
                    "process_wall_ns": elapsed,
                    "forwards": complete[-1]["forwards"],
                }
            )
        save()
        assert rc == 0, name + " failed; preserve result, no blind repeat"
        if numeric:
            assert len(complete) == 1
        return rows

    try:
        common = [
            "--release",
            "--offline",
            "--locked",
            "-j",
            "2",
            "-p",
            "quoridor-ai",
            "--features",
            "research",
            "--example",
            "search_cost",
        ]
        command("build", ["/usr/local/cargo/bin/cargo", "build"] + common)
        command(
            "clippy",
            ["/usr/local/cargo/bin/cargo", "clippy"]
            + common
            + ["--", "-D", "warnings"],
        )
        data = (TARGET / "release/examples/search_cost").read_bytes()
        binary = OUT / "private-search-cost"
        binary.write_bytes(data)
        binary.chmod(0o555)
        assert binary.stat().st_blocks * 512 <= 1572864
        result["binary"] = {
            "path": str(binary),
            "SHA": sha(binary),
            "source": plan["source_SHA"],
        }
        rows = command(
            "real-player-tt",
            [str(binary), str(OUT / "config.json"), "tt"],
            numeric=True,
        )
        assert len([r for r in rows if r.get("kind") == "tt_fixture"]) == 5
        assert len([r for r in rows if r.get("kind") == "tt_target"]) == 20
        result["all_tt_pair_action_valuebits_PV_equal"] = all(
            r["action_valuebits_PV_equal"] for r in rows if r.get("kind") == "tt_pair"
        )
        baseline_rows = [
            json.loads(line)
            for line in Path(plan["prior_plain_semantic_log"]).read_text().splitlines()
        ]

        def signatures(data):
            rows = []
            for row in data:
                if row.get("kind") == "search":
                    fields = dict(row["result"])
                    fields.pop("elapsed_ns")
                    rows.append({"name": row["name"], "result": fields})
            return rows

        expected = signatures(baseline_rows)
        for index, (binding, mode) in enumerate(
            (
                ("bounded-plain", "plain"),
                ("bounded-observed", "profile"),
                ("bounded-observed", "profile"),
                ("bounded-plain", "plain"),
            )
        ):
            b = plan["existing_bounded_binding"][binding]
            rows = command(
                "calibration-" + str(index),
                [b["path"], str(OUT / "config.json"), mode],
                numeric=True,
            )
            assert signatures(rows) == expected, "calibration exact result mismatch"
        for path, expected_sha in plan["source_SHA"].items():
            assert sha(path) == expected_sha, path
        result.update(
            status="PASS_LIMITED_REFERENCE_AND_LEGAL_HISTORY; TT_EFFECT_PENDING_AGGREGATION",
            source_writer_STOP=True,
            shared_target_writer_STOP=True,
        )
    except BaseException as error:
        result.update(
            status="FAILED_PRESERVED",
            error=repr(error),
            incomplete_numeric_stage_forwards="UNKNOWN",
        )
        raise
    finally:
        save()


if __name__ == "__main__":
    main()
