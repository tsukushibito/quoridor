"""318 single-job guardian; family/log monitoring on CPU0,1, no compute deadline."""

import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
OUT = ROOT / ".artifacts/search-optimization/bounded-input-v1"
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def proc(pid):
    try:
        p = Path("/proc") / str(pid)
        fields = (p / "stat").read_text().rsplit(")", 1)[1].split()
        if fields[0] == "Z":
            return None
        text = (p / "status").read_text()
        rss = int(text.split("VmRSS:")[1].split()[0]) * 1024 if "VmRSS:" in text else 0
        return {"pid": pid, "tick": fields[19], "boot": BOOT, "rss": rss}
    except (OSError, ValueError, IndexError):
        return None


def descendants(pid):
    ids = {pid}
    todo = [pid]
    while todo:
        current = todo.pop()
        try:
            children = (
                Path(f"/proc/{current}/task/{current}/children").read_text().split()
            )
        except OSError:
            children = []
        for child in children:
            child = int(child)
            if child not in ids:
                ids.add(child)
                todo.append(child)
    return {pid: value for pid in ids if (value := proc(pid))}


def main():
    os.sched_setaffinity(0, {0, 1})
    name, *argv = sys.argv[1:]
    out = OUT / name
    out.mkdir(exist_ok=False)
    identities = {}
    peak = 0
    reason = None
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    with (
        (out / "stdout.log").open("wb") as stdout,
        (out / "stderr.log").open("wb") as stderr,
    ):
        child = subprocess.Popen(
            argv, cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True
        )
        leader = proc(child.pid)
        while child.poll() is None:
            owned = descendants(child.pid)
            identities.update(owned)
            peak = max(
                peak,
                sum(v["rss"] for v in owned.values())
                + proc(os.getpid())["rss"]
                + 32 * 1024**2,
            )
            if peak > 2 * 1024**3:
                reason = "family_RSS_guard"
            if sum(p.stat().st_size for p in (OUT).glob("*.log")) > 1048576:
                reason = "log_guard"
            if reason:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                break
            time.sleep(0.05)
        rc = child.wait()
    remaining = [
        v
        for pid, v in identities.items()
        if (actual := proc(pid)) and actual["tick"] == v["tick"]
    ]
    for v in remaining:
        os.kill(v["pid"], signal.SIGTERM)
    if remaining:
        time.sleep(0.1)
    remaining = [
        v
        for pid, v in identities.items()
        if (actual := proc(pid)) and actual["tick"] == v["tick"]
    ]
    receipt = {
        "started": started,
        "ended": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "wall_s": time.monotonic() - start,
        "exit_code": rc,
        "reason": reason,
        "direct_child_reaped": True,
        "remaining": remaining,
        "cleanup_complete": not remaining,
        "leader": leader,
        "identities": list(identities.values()),
        "family_peak_RSS_plus_controller_reserve_B": peak,
        "CPU": {"guardian": [0, 1], "binary": [0, 1]},
        "finite_plain_comparison": True,
    }
    (out / "process.json").write_text(json.dumps(receipt, indent=2) + "\n")
    if rc or reason or remaining:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
