"""Finite qualified bounded-input refinement; no time or forward budget guard."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
OUT = ROOT / ".artifacts/search-optimization/bounded-input-v1"
TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def semantic(path, micro=False):
    result = []
    for line in Path(path).read_text().splitlines():
        if not line.startswith("{"):
            continue
        row = json.loads(line)
        if row["kind"] == "search" and not micro:
            fields = dict(row["result"])
            fields.pop("elapsed_ns")
            result.append(
                {"name": row["name"], "prefix": row["prefix"], "result": fields}
            )
        if row["kind"] == "micro" and micro:
            result.append({key: row[key] for key in ("name", "checksum", "forwards")})
    return result


def main():
    os.sched_setaffinity(0, {0, 1})
    plan = json.loads((OUT / "plan.json").read_text())
    assert sha(plan["source_path"]) == plan["candidate_SHA"]
    for binding in plan["existing_binary"].values():
        assert sha(binding["path"]) == binding["SHA"]
    env = dict(
        os.environ,
        CARGO_TARGET_DIR=str(TARGET),
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        CARGO_INCREMENTAL="0",
        QUORIDOR_NNUE_REFERENCE_CONFIG=plan["oracle_config"],
    )
    commands = []
    runs = []
    result = {
        "status": "RUNNING",
        "commands": commands,
        "runs": runs,
        "candidate_source_SHA": plan["candidate_SHA"],
        "numeric_forwards": 0,
    }

    def save():
        (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    def command(name, argv, numeric=False):
        start = time.perf_counter_ns() if numeric else None
        with (OUT / (name + ".log")).open("wb") as log:
            child = subprocess.Popen(
                argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT
            )
            rc = child.wait()
        elapsed = time.perf_counter_ns() - start if numeric else None
        commands.append(
            {"name": name, "argv": argv, "exit": rc, "direct_child_waited": True}
        )
        save()
        assert rc == 0, name + " failed; retain failure, no blind repeat"
        return elapsed

    try:
        common = ["--release", "--offline", "--locked", "-j", "2"]
        command(
            "oracle",
            ["/usr/local/cargo/bin/cargo", "test"]
            + common
            + [
                "-p",
                "quoridor-nnue",
                "--features",
                "research",
                "--lib",
                "heap_avoidance_",
                "--",
                "--include-ignored",
                "--nocapture",
                "--test-threads=1",
            ],
        )
        text = (OUT / "oracle.log").read_text()
        synthetic = re.search(r"HEAP_SYNTHETIC_FORWARDS=(\d+)", text)
        frozen = re.search(r"HEAP_FROZEN_FORWARDS=(\d+);CHILDREN=(\d+);ROOTS=5", text)
        assert synthetic and frozen
        result["oracle_forwards"] = int(synthetic[1]) + int(frozen[1])
        result["numeric_forwards"] += result["oracle_forwards"]
        result["oracle_children"] = int(frozen[2])
        save()
        command(
            "clippy-model",
            ["/usr/local/cargo/bin/cargo", "clippy"]
            + common
            + [
                "-p",
                "quoridor-nnue",
                "--features",
                "research",
                "--lib",
                "--tests",
                "--",
                "-D",
                "warnings",
            ],
        )
        binaries = {}
        (OUT / "private").mkdir()
        for observed in (False, True):
            name = "bounded-observed" if observed else "bounded-plain"
            command(
                "build-" + name,
                ["/usr/local/cargo/bin/cargo", "build"]
                + common
                + [
                    "-p",
                    "quoridor-ai",
                    "--features",
                    "research,profiling" if observed else "research",
                    "--example",
                    "search_cost",
                ],
            )
            data = (TARGET / "release/examples/search_cost").read_bytes()
            private = OUT / "private" / name
            private.write_bytes(data)
            private.chmod(0o555)
            (OUT / "private" / (name + ".gz")).write_bytes(gzip.compress(data, mtime=0))
            binaries[name] = {
                "path": str(private),
                "SHA": sha(private),
                "source_SHA": sha(plan["source_path"]),
            }
            assert (
                sum(p.stat().st_blocks * 512 for p in (OUT / "private").iterdir())
                <= 3145728
            )
        (OUT / "binary-binding.json").write_text(json.dumps(binaries, indent=2) + "\n")
        reference = semantic(plan["frozen_baseline_semantic_log"])
        micro_reference = semantic(plan["frozen_micro_log"], micro=True)
        baseline = plan["existing_binary"]["baseline-plain"]["path"]

        def run(name, variant, mode):
            binary = (
                baseline if variant == "baseline" else binaries["bounded-plain"]["path"]
            )
            if variant == "observed":
                binary = binaries["bounded-observed"]["path"]
            elapsed = command(name, [binary, plan["config"], mode], numeric=True)
            micro = mode == "micro"
            assert semantic(OUT / (name + ".log"), micro=micro) == (
                micro_reference if micro else reference
            ), "exact result fields mismatch"
            rows = [
                json.loads(line)
                for line in (OUT / (name + ".log")).read_text().splitlines()
            ]
            assert rows[-1]["kind"] == "complete"
            result["numeric_forwards"] += rows[-1]["forwards"]
            runs.append(
                {
                    "name": name,
                    "variant": variant,
                    "mode": mode,
                    "process_wall_ns": elapsed,
                    "whole_ns": rows[-1]["whole_ns"],
                    "search_ns": sum(
                        r["search_ns"] for r in rows if r["kind"] == "search"
                    ),
                    "micro_ns": sum(
                        r["evaluate_ns"] for r in rows if r["kind"] == "micro"
                    ),
                    "forwards": rows[-1]["forwards"],
                    "exact_parity": True,
                }
            )
            save()

        for i, variant in enumerate(plan["plain_order"]):
            run("plain-" + str(i), variant, "plain")
        run("allocation", "observed", "alloc")
        for i, variant in enumerate(plan["micro_order"]):
            run("micro-" + str(i), variant, "micro")
        assert sha(plan["source_path"]) == plan["candidate_SHA"]
        result.update(
            status="PASS_LIMITED_ORACLE_PARITY; ADOPTION_PENDING_AGGREGATION",
            source_writer_STOP=True,
            shared_target_writer_STOP=True,
            shared_target_growth_peak_B=None,
        )
    except BaseException as error:
        result.update(
            status="FAILED_PRESERVED",
            error=repr(error),
            uncompleted_stage_forward="UNKNOWN",
        )
        raise
    finally:
        save()


if __name__ == "__main__":
    main()
