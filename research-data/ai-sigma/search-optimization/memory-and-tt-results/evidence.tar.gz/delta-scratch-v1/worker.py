"""One coherent depth-owned accumulator/feature reuse qualification/comparison."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
OUT = ROOT / ".artifacts/search-optimization/delta-scratch-v1"
TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def signature(rows):
    fields = []
    for row in rows:
        if row.get("kind") == "search":
            s = dict(row["result"])
            s.pop("elapsed_ns")
            fields.append({"name": row["name"], "prefix": row["prefix"], "result": s})
    return fields


def main():
    os.sched_setaffinity(0, {0, 1})
    plan = json.loads((OUT / "plan.json").read_text())
    for path, binding in plan["source_bindings"].items():
        assert sha(path) == binding["candidate_SHA"], path
    for baseline in ("baseline_canonical", "baseline_bounded"):
        b = plan[baseline]
        assert sha(b["path"]) == b["SHA"]
    config = json.loads(Path(plan["config"]).read_text())
    manifest_path = Path(config["manifest"])
    assert sha(manifest_path) == config["manifest_sha"]
    manifest = json.loads(manifest_path.read_text())
    assert sha(manifest_path.parent / manifest["weights"]) == config["weights_sha"]
    env = dict(
        os.environ,
        CARGO_TARGET_DIR=str(TARGET),
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        CARGO_INCREMENTAL="0",
        QUORIDOR_NNUE_REFERENCE_CONFIG=plan["oracle_config"],
    )
    result = {
        "status": "RUNNING",
        "commands": [],
        "runs": [],
        "head_forwards": 0,
        "FT_prepares_recorded": 0,
        "FT_updates_recorded": 0,
        "shared_target_growth_peak_B": None,
    }

    def save():
        (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    def command(name, argv, numeric=False):
        start = time.perf_counter_ns() if numeric else None
        with (OUT / (name + ".log")).open("wb") as log:
            child = subprocess.Popen(
                argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT
            )
            rc = child.wait()
        elapsed = time.perf_counter_ns() - start if numeric else None
        result["commands"].append(
            {"name": name, "argv": argv, "exit": rc, "direct_child_waited": True}
        )
        save()
        text = (OUT / (name + ".log")).read_text()
        rows = [json.loads(line) for line in text.splitlines() if line.startswith("{")]
        completed = [r for r in rows if r.get("kind") == "complete"]
        if completed:
            result["head_forwards"] += completed[-1]["forwards"]
            result["FT_updates_recorded"] += sum(
                r["result"]["delta_updates"] for r in rows if r.get("kind") == "search"
            )
            result["FT_prepares_recorded"] += len(
                [r for r in rows if r.get("kind") == "search"]
            )
        save()
        assert rc == 0, name + " failed; preserved, no blind repeat"
        if numeric:
            assert len(completed) == 1
        return rows, elapsed, text

    try:
        common = ["--release", "--offline", "--locked", "-j", "2"]
        for name, package, selector, include_ignored in (
            (
                "topology",
                "quoridor-nnue",
                "heap_avoidance_reusable_ft_buffers_across_topologies",
                False,
            ),
            (
                "frozen",
                "quoridor-nnue",
                "heap_avoidance_frozen_model_contexts_and_parent_return",
                True,
            ),
            (
                "ownership",
                "quoridor-ai",
                "scratch_owned_depth_slots_match_legacy_and_restore_after_error_cancel",
                True,
            ),
            ("default-callbacks-TT", "quoridor-ai", "persistent_tt_tests", False),
            (
                "map-reference",
                "quoridor-nnue",
                "map_cache_pawn_share_wall_replace_and_unreachable",
                False,
            ),
        ):
            argv = (
                ["/usr/local/cargo/bin/cargo", "test"]
                + common
                + ["-p", package, "--features", "research", "--lib", selector, "--"]
            )
            if include_ignored:
                argv += ["--include-ignored"]
            argv += ["--nocapture", "--test-threads=1"]
            _, _, text = command(name, argv)
            if name == "topology":
                m = re.search(
                    r"SCRATCH_TOPOLOGY_FORWARDS=(\d+);FT_PREPARES=(\d+);FT_UPDATES=(\d+)",
                    text,
                )
                assert m
                result["head_forwards"] += int(m[1])
                result["FT_prepares_recorded"] += int(m[2])
                result["FT_updates_recorded"] += int(m[3])
            elif name == "frozen":
                m = re.search(
                    r"HEAP_FROZEN_FORWARDS=(\d+);CHILDREN=(\d+);ROOTS=5", text
                )
                assert m and int(m[2]) == 635
                result["head_forwards"] += int(m[1])
                result["frozen_children"] = int(m[2])
                result["frozen_FT_update_full_counts"] = (
                    "partial UNKNOWN; headcalls exact marker, fullminimax+635full/Simd/delta/reuse FT work included inwholejob, no NN0 claim"
                )
            elif name == "ownership":
                m = re.search(
                    r"SCRATCH_SEARCH_HEADS=(\d+);FT_PREPARES=(\d+);FT_UPDATES=(\d+)",
                    text,
                )
                assert m
                result["head_forwards"] += int(m[1])
                result["FT_prepares_recorded"] += int(m[2])
                result["FT_updates_recorded"] += int(m[3])
            save()
        for package, extra in (
            ("quoridor-nnue", ["--lib", "--tests"]),
            ("quoridor-ai", ["--lib", "--example", "search_cost"]),
        ):
            command(
                "clippy-" + package,
                ["/usr/local/cargo/bin/cargo", "clippy"]
                + common
                + ["-p", package, "--features", "research"]
                + extra
                + ["--", "-D", "warnings"],
            )
        binaries = {}
        (OUT / "private").mkdir()
        for observed in (False, True):
            name = "candidate-observed" if observed else "candidate-plain"
            command(
                "build-" + name,
                ["/usr/local/cargo/bin/cargo", "build"]
                + common
                + [
                    "-p",
                    "quoridor-ai",
                    "--features",
                    "research,profiling" if observed else "research",
                    "--example",
                    "search_cost",
                ],
            )
            private = OUT / "private" / name
            data = (TARGET / "release/examples/search_cost").read_bytes()
            private.write_bytes(data)
            private.chmod(0o555)
            (OUT / "private" / (name + ".gz")).write_bytes(gzip.compress(data, mtime=0))
            binaries[name] = {
                "path": str(private),
                "SHA": sha(private),
                "source": plan["source_bindings"],
            }
            assert (
                sum(p.stat().st_blocks * 512 for p in (OUT / "private").iterdir())
                <= 3145728
            )
        (OUT / "binary-binding.json").write_text(json.dumps(binaries, indent=2) + "\n")
        reference = signature(
            [
                json.loads(line)
                for line in Path(plan["reference_search_log"]).read_text().splitlines()
            ]
        )
        for category, baseline in (
            ("intervention", "baseline_bounded"),
            ("cumulative", "baseline_canonical"),
        ):
            for index, variant in enumerate(plan["finite_plain_order"]):
                binary = (
                    plan[baseline]["path"]
                    if variant == "baseline"
                    else binaries["candidate-plain"]["path"]
                )
                name = category + "-" + str(index)
                rows, elapsed, _ = command(
                    name, [binary, plan["config"], "plain"], numeric=True
                )
                assert signature(rows) == reference, (
                    "valuebits/Action/PV/depth/nodes/stats mismatch"
                )
                result["runs"].append(
                    {
                        "name": name,
                        "category": category,
                        "variant": variant,
                        "process_wall_ns": elapsed,
                        "whole_ns": rows[-1]["whole_ns"],
                        "search_ns": sum(
                            r["search_ns"] for r in rows if r["kind"] == "search"
                        ),
                        "head_forwards": rows[-1]["forwards"],
                        "exact_parity": True,
                    }
                )
                save()
        rows, _, _ = command(
            "allocation",
            [binaries["candidate-observed"]["path"], plan["config"], "alloc"],
            numeric=True,
        )
        assert signature(rows) == reference
        for path, binding in plan["source_bindings"].items():
            assert sha(path) == binding["candidate_SHA"]
        result.update(
            status="PASS_LIMITED_INDEPENDENT_FT_OWNERSHIP_AND_WHOLE_PARITY; AGGREGATION_PENDING",
            source_writer_STOP=True,
            shared_target_writer_STOP=True,
        )
    except BaseException as error:
        result.update(
            status="FAILED_PRESERVED",
            error=repr(error),
            incomplete_stage_numeric_counts="UNKNOWN",
        )
        raise
    finally:
        save()


if __name__ == "__main__":
    main()
