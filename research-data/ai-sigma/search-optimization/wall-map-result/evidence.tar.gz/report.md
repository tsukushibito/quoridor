# Wall-map storage qualification and plain comparison

The measured ResidualEvaluator hot path now allocates/reallocates zero times in 94,533 accumulator updates and 88,727 head evaluations per five-root search. Whole-search allocation requests fell from 118,447 in delta-scratch-v1 to 27,692, with requested bytes from 27,636,493 to 9,489,173. Whole search still allocates for other operations. Scratch setup requested 14,352 bytes instead of 10,672: depth slots include the owned integer maps.

Canonical whole-speed benefit was not supported. Four AB/BA pairs all increased cumulative whole time compared with the canonical allocating residual60d. The isolated map intervention is mixed and close to equal in search time.

Ratios are candidate/baseline, so values above 1 take longer:

| Contrast | Process | Whole | Search |
| --- | ---: | ---: | ---: |
| intervention | 1.048794 | 1.005275 | 0.996841 |
| cumulative | 1.099487 | 1.062009 | 1.055018 |

The primary cumulative baseline is canonical60d with immutable ELF SHA 6c18d786109ee422a653c5278b2b8ccf48844e5b222d6dede7b5c12970b40348. The isolated baseline is the previously qualified delta-scratch-v1. Neither comparison substitutes the rejected streamed AA35 version. Fixed BEST weights c0ec9bf3..., five prerecorded legal roots, depth3/node100k/TT4096/PVS and scalar operation order were unchanged. All sixteen complete action/value bits/PV/depth/nodes/exported counters agreed. The plain diagnostic prints one extra geometry field as null; short process/startup and serialization costs remain included and are separated from search-only time. No fragmentation/latency/strength/general倍率 claim.

Seven selected tests passed: default map/error; default residual full/delta/Simd/parent; seven accepted FT widths 1..2048; fixed BEST full/delta/parent and unpruned minimax; AI scratch error/cancel/restore; independent explicit-edge queue maps on all81 cells, 635 legal children and terminal/P1P2/history/undo; existing quantized full/delta/roundtrip/checked-overflow caller. Scoped NN and AI Clippy passed. Integer/float arithmetic, weight/format/layout/scale/feature meaning and TT/action order were not changed.

There were 1,712,573 model evaluations, including 253 source-bound default quantized/float synthetic calls and18 default residual calls. Some full/minimax FT counts are partialUNKNOWN and remain distinct from exact model-call markers. This is actual numeric work, not NN0.

The initial compile failure 87e7c512 from an unaligned quantized Arc caller cost2.388451752 seconds and remains failed with its source/log/STOP. Repair jobff938fe8 succeeded with controller whole60.245093783 seconds, inclusive of build/tests/init/comparison/cleanup; same-question all-attempt62.633545535 seconds. Do not sum nested clocks. Twenty-eight command logs are gzip members, each restored to its raw SHA; both immutable image snapshots also restore byte-for-byte (plain400319B, observed426597B), executed from sole-owner sharedtarget with before/after SHA checks. Original artifacts are retained.

Source and target writer/reader STOP17:28:43.433791Z. Guardian reaped its direct worker, all28 commands were directly waited, 37 sampled descendants and guardian exact identities are absent; both remaining lists empty. Sampled family+controller RSS126722048B, isolated output peak1077248B; sharedtarget growth peak UNKNOWN. Root alone chooses source acceptance and main/Git integration. Memory-principle success and performance adoption remain separate.

Current stopped4NNsource/test paths+SHA are in plan.json and stopped-source; cumulative main diff is candidate-vs-main.patch. The source snapshot contains no new searcher copy. Reproduction uses frozen plan/worker/config with canonical main research-job.sh, actual quiet numeric slot and142MiB footprint admission. Raw command offsets/SHA are in result.json.

Possible same-meaning refinement: setup-owned map buffers behind small pointers could avoid the expanded accumulator return/move size while retaining normal allocation zero. Copy/ABI causality is a hypothesis, not established by this measurement. No next job has started or been reserved; current slot was returned directly to323/Root.
