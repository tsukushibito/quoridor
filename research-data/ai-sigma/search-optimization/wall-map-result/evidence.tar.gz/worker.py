"""Bounded owned wall-map qualification and unchanged plain search comparison."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
OUT = ROOT / ".artifacts/search-optimization/map-storage-r2"
TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def signature(rows):
    fields = []
    for row in rows:
        if row.get("kind") == "search":
            s = dict(row["result"])
            s.pop("elapsed_ns")
            fields.append({"name": row["name"], "prefix": row["prefix"], "result": s})
    return fields


def main():
    os.sched_setaffinity(0, {0, 1})
    plan = json.loads((OUT / "plan.json").read_text())
    for path, binding in plan["source_bindings"].items():
        assert sha(path) == binding["candidate_SHA"], path
    for baseline in ("baseline_canonical", "baseline_intervention"):
        b = plan[baseline]
        assert sha(b["path"]) == b["SHA"]
    config = json.loads(Path(plan["config"]).read_text())
    manifest_path = Path(config["manifest"])
    assert sha(manifest_path) == config["manifest_sha"]
    manifest = json.loads(manifest_path.read_text())
    assert sha(manifest_path.parent / manifest["weights"]) == config["weights_sha"]
    env = dict(
        os.environ,
        CARGO_TARGET_DIR=str(TARGET),
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        CARGO_INCREMENTAL="0",
        QUORIDOR_NNUE_REFERENCE_CONFIG=plan["oracle_config"],
    )
    (OUT / "tmp").mkdir(exist_ok=True)
    env["TMPDIR"] = str(OUT / "tmp")
    result = {
        "status": "RUNNING",
        "commands": [],
        "runs": [],
        "head_forwards": 0,
        "FT_prepares_recorded": 0,
        "FT_updates_recorded": 0,
        "shared_target_growth_peak_B": None,
    }

    def save():
        (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    def command(name, argv, numeric=False):
        start = time.perf_counter_ns() if numeric else None
        with (OUT / (name + ".log")).open("wb") as log:
            child = subprocess.Popen(
                argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT
            )
            rc = child.wait()
        elapsed = time.perf_counter_ns() - start if numeric else None
        result["commands"].append(
            {"name": name, "argv": argv, "exit": rc, "direct_child_waited": True}
        )
        log_path = OUT / (name + ".log")
        raw = log_path.read_bytes()
        compressed = gzip.compress(raw, compresslevel=6, mtime=0)
        assert gzip.decompress(compressed) == raw
        archive = OUT / "command-logs.gz"
        offset = archive.stat().st_size if archive.exists() else 0
        with archive.open("ab") as stored:
            stored.write(compressed)
        result["commands"][-1]["raw_log"] = {
            "archive": str(archive),
            "compressed_offset": offset,
            "compressed_bytes": len(compressed),
            "raw_bytes": len(raw),
            "raw_SHA": hashlib.sha256(raw).hexdigest(),
            "fully_restored_verified": True,
        }
        # Temporary command output is removed only after exact lossless storage.
        log_path.unlink()
        save()
        text = raw.decode()
        rows = [json.loads(line) for line in text.splitlines() if line.startswith("{")]
        completed = [r for r in rows if r.get("kind") == "complete"]
        if completed:
            result["head_forwards"] += completed[-1]["forwards"]
            result["FT_updates_recorded"] += sum(
                r["result"]["delta_updates"] for r in rows if r.get("kind") == "search"
            )
            result["FT_prepares_recorded"] += len(
                [r for r in rows if r.get("kind") == "search"]
            )
        save()
        assert rc == 0, name + " failed; preserved, no blind repeat"
        if numeric:
            assert len(completed) == 1
        return rows, elapsed, text

    try:
        common = ["--release", "--offline", "--locked", "-j", "2"]
        _, _, default_text = command(
            "default-map",
            ["/usr/local/cargo/bin/cargo", "test"]
            + common
            + [
                "-p",
                "quoridor-nnue",
                "--lib",
                "owned_maps_pawn_copy_wall_replace_and_unreachable",
                "--",
                "--test-threads=1",
            ],
        )
        assert "test result: ok. 1 passed" in default_text
        _, _, default_residual_text = command(
            "default-residual",
            ["/usr/local/cargo/bin/cargo", "test"]
            + common
            + [
                "-p",
                "quoridor-nnue",
                "--test",
                "residual",
                "residual_full_delta_simd_and_parent_return",
                "--",
                "--exact",
                "--test-threads=1",
            ],
        )
        assert "test result: ok. 1 passed" in default_residual_text
        # Existing fixed source fixture explicitly asserts 18 functional calls.
        result["head_forwards"] += 18
        result["FT_prepares_recorded"] += 10
        result["FT_updates_recorded"] += 4
        save()
        for name, package, selector, include_ignored in (
            (
                "topology",
                "quoridor-nnue",
                "heap_avoidance_reusable_ft_buffers_across_topologies",
                False,
            ),
            (
                "frozen",
                "quoridor-nnue",
                "heap_avoidance_frozen_model_contexts_and_parent_return",
                True,
            ),
            (
                "ownership",
                "quoridor-ai",
                "scratch_owned_depth_slots_match_legacy_and_restore_after_error_cancel",
                True,
            ),
            (
                "map-reference",
                "quoridor-nnue",
                "owned_maps_all_cells_legal_children_and_parent_restore",
                False,
            ),
        ):
            argv = (
                ["/usr/local/cargo/bin/cargo", "test"]
                + common
                + ["-p", package, "--features", "research", "--lib", selector, "--"]
            )
            if include_ignored:
                argv += ["--include-ignored"]
            argv += ["--nocapture", "--test-threads=1"]
            _, _, text = command(name, argv)
            assert "test result: ok. 1 passed" in text, "fixture selector not executed"
            if name == "topology":
                m = re.search(
                    r"SCRATCH_TOPOLOGY_FORWARDS=(\d+);FT_PREPARES=(\d+);FT_UPDATES=(\d+)",
                    text,
                )
                assert m
                result["head_forwards"] += int(m[1])
                result["FT_prepares_recorded"] += int(m[2])
                result["FT_updates_recorded"] += int(m[3])
            elif name == "frozen":
                m = re.search(
                    r"HEAP_FROZEN_FORWARDS=(\d+);CHILDREN=(\d+);ROOTS=5", text
                )
                assert m and int(m[2]) == 635
                result["head_forwards"] += int(m[1])
                result["frozen_children"] = int(m[2])
                result["frozen_FT_update_full_counts"] = (
                    "partial UNKNOWN; headcalls exact marker, fullminimax+635full/Simd/delta/reuse FT work included inwholejob, no NN0 claim"
                )
            elif name == "ownership":
                m = re.search(
                    r"SCRATCH_SEARCH_HEADS=(\d+);FT_PREPARES=(\d+);FT_UPDATES=(\d+)",
                    text,
                )
                assert m
                result["head_forwards"] += int(m[1])
                result["FT_prepares_recorded"] += int(m[2])
                result["FT_updates_recorded"] += int(m[3])
            save()
        _, _, quantized_text = command(
            "quantized-default-caller",
            ["/usr/local/cargo/bin/cargo", "test"]
            + common
            + [
                "-p",
                "quoridor-nnue",
                "--features",
                "research",
                "--test",
                "float_parity",
                "scalable_topology_and_quantized_roundtrip_checked_overflow",
                "--",
                "--exact",
                "--nocapture",
                "--test-threads=1",
            ],
        )
        assert "test result: ok. 1 passed" in quantized_text
        marker = re.search(
            r"QUANTIZED_MAP_MODEL_FORWARDS=(\d+);LEGAL_CHILDREN=(\d+)", quantized_text
        )
        assert marker and int(marker[1]) == 5 + 2 * int(marker[2])
        result["head_forwards"] += int(marker[1])
        result["quantized_float_default_fixture_model_calls"] = int(marker[1])
        result["quantized_float_default_fixture_FT_work"] = (
            "source-bound prepares3+L, deltaattemptsL+1 including explicit overflow rejection; modelcalls counted, no NN0 claim"
        )
        save()
        for package, extra in (
            ("quoridor-nnue", ["--lib", "--tests"]),
            ("quoridor-ai", ["--lib", "--example", "search_cost"]),
        ):
            command(
                "clippy-" + package,
                ["/usr/local/cargo/bin/cargo", "clippy"]
                + common
                + ["-p", package, "--features", "research"]
                + extra
                + ["--", "-D", "warnings"],
            )
        reference = signature(
            [
                json.loads(line)
                for line in Path(plan["reference_search_log"]).read_text().splitlines()
            ]
        )
        binaries = {}
        image_path = TARGET / "release/examples/search_cost"
        archived_allocated = 0
        for observed in (False, True):
            name = "candidate-observed" if observed else "candidate-plain"
            command(
                "build-" + name,
                ["/usr/local/cargo/bin/cargo", "build"]
                + common
                + [
                    "-p",
                    "quoridor-ai",
                    "--features",
                    "research,profiling" if observed else "research",
                    "--example",
                    "search_cost",
                ],
            )
            data = image_path.read_bytes()
            checksum = hashlib.sha256(data).hexdigest()
            compressed = gzip.compress(data, compresslevel=6, mtime=0)
            allocated = ((len(compressed) + 4095) // 4096) * 4096
            assert archived_allocated + allocated <= 1048576, (
                "two image allocation forecast exceeded"
            )
            archive = OUT / (name + ".gz")
            archive.write_bytes(compressed)
            archive.chmod(0o444)
            assert (
                hashlib.sha256(gzip.decompress(archive.read_bytes())).hexdigest()
                == checksum
            )
            archived_allocated += allocated
            binaries[name] = {
                "path": str(image_path),
                "SHA": checksum,
                "compressed_snapshot": str(archive),
                "compressed_bytes": len(compressed),
                "allocated_bytes": archive.stat().st_blocks * 512,
                "fully_restored_SHA_verified": True,
                "source": plan["source_bindings"],
                "execution_ownership": "sole target writer/reader; SHA before/after each run; gzip restore preserves immutable version",
            }
            (OUT / "binary-binding.json").write_text(
                json.dumps(binaries, indent=2) + "\n"
            )
            if not observed:
                for category, baseline in (
                    ("intervention", "baseline_intervention"),
                    ("cumulative", "baseline_canonical"),
                ):
                    for index, variant in enumerate(plan["finite_plain_order"]):
                        assert sha(image_path) == checksum
                        base = plan[baseline]
                        assert sha(base["path"]) == base["SHA"]
                        binary = (
                            base["path"] if variant == "baseline" else str(image_path)
                        )
                        run_name = category + "-" + str(index)
                        rows, elapsed, _ = command(
                            run_name, [binary, plan["config"], "plain"], numeric=True
                        )
                        assert signature(rows) == reference, (
                            "exact valuebits/Action/PV/depth/nodes/stats mismatch"
                        )
                        assert sha(image_path) == checksum
                        result["runs"].append(
                            {
                                "name": run_name,
                                "category": category,
                                "variant": variant,
                                "process_wall_ns": elapsed,
                                "whole_ns": rows[-1]["whole_ns"],
                                "search_ns": sum(
                                    r["search_ns"]
                                    for r in rows
                                    if r["kind"] == "search"
                                ),
                                "head_forwards": rows[-1]["forwards"],
                                "exact_parity": True,
                            }
                        )
                        save()
            else:
                rows, _, _ = command(
                    "allocation",
                    [str(image_path), plan["config"], "alloc"],
                    numeric=True,
                )
                assert signature(rows) == reference
                assert sha(image_path) == checksum
                metrics = []
                for row in rows:
                    if row.get("kind") != "search":
                        continue
                    advance = next(
                        m
                        for m in row["evaluator_components"]
                        if m["name"] == "advance_context"
                    )
                    assert (
                        advance["alloc_calls"] == 0 and advance["realloc_calls"] == 0
                    ), "normal evaluator scratch/map heap remained"
                    metrics.append(
                        {
                            "name": row["name"],
                            "evaluator_components": row["evaluator_components"],
                            "search_allocation": row["search_allocation"],
                            "session_setup_allocation": row["session_setup_allocation"],
                            "geometry_reuse_potential": row["geometry_reuse_potential"],
                        }
                    )
                result["allocation_observation"] = metrics
                save()
        for path, binding in plan["source_bindings"].items():
            assert sha(path) == binding["candidate_SHA"]
        result.update(
            status="PASS_LIMITED_INDEPENDENT_MAP_FT_OWNERSHIP_AND_WHOLE_PARITY; AGGREGATION_PENDING",
            source_writer_STOP=True,
            shared_target_writer_STOP=True,
        )
    except BaseException as error:
        result.update(
            status="FAILED_PRESERVED",
            error=repr(error),
            incomplete_stage_numeric_counts="UNKNOWN",
        )
        raise
    finally:
        save()


if __name__ == "__main__":
    main()
