//! QF1 uses a full 180 degree rotation for P2 (distinct from Sigma's NN input).
use crate::{Error, Result};
use quoridor_core::Position;

pub const FEATURE_COUNT: usize = 312;
#[derive(Debug, Clone, PartialEq)]
pub struct Features {
    pub ids: [Vec<u16>; 2],
    /// Wall-only distance / 80, STM first. Compute the division in f64 before f32.
    pub distance: [f32; 2],
    /// Zero-based side to move.
    pub side: u8,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct WallMaps {
    horizontal: u64,
    vertical: u64,
    distances: [[u8; 81]; 2],
}

pub fn encode_qf1(position: Position) -> Result<Features> {
    position
        .checked()
        .map_err(|e| Error::Input(e.to_string()))?;
    Ok(encode_cached(position, None)?.0)
}
/// Contexts are created only by checked core constructors/moves. A whole
/// bounded wall-only map is copied across pawn moves; a wall change constructs
/// a new owned map without a heap allocation. Parent contexts stay immutable.
pub(crate) fn encode_cached(
    p: Position,
    previous: Option<&WallMaps>,
) -> Result<(Features, WallMaps)> {
    encode_cached_reusing(p, previous, None)
}

/// Reuses exclusively owned ID buffers; the parent maps stay immutable.
pub(crate) fn encode_cached_reusing(
    p: Position,
    previous: Option<&WallMaps>,
    reusable: Option<[Vec<u16>; 2]>,
) -> Result<(Features, WallMaps)> {
    let maps = match previous {
        Some(m) if m.horizontal == p.horizontal && m.vertical == p.vertical => *m,
        _ => WallMaps {
            horizontal: p.horizontal,
            vertical: p.vertical,
            distances: p.wall_distance_maps(),
        },
    };
    let mut ids = reusable.unwrap_or_else(|| std::array::from_fn(|_| Vec::with_capacity(24)));
    for (player, out) in ids.iter_mut().enumerate() {
        let rotate = player == 1;
        let square = |cell: u8| if rotate { 80 - cell } else { cell };
        out.clear();
        out.push(u16::from(square(p.pawns[player])));
        out.push(81 + u16::from(square(p.pawns[player ^ 1])));
        for (bits, base) in [(p.horizontal, 162), (p.vertical, 226)] {
            for anchor in 0..64u16 {
                if bits & (1u64 << anchor) != 0 {
                    out.push(base + if rotate { 63 - anchor } else { anchor });
                }
            }
        }
        out.push(290 + u16::from(p.walls_remaining[player]));
        out.push(301 + u16::from(p.walls_remaining[player ^ 1]));
        out.sort_unstable();
    }
    let side = p.turn as usize;
    let mut distance = [0.; 2];
    for (i, player) in [side, side ^ 1].into_iter().enumerate() {
        let d = maps.distances[player][p.pawns[player] as usize];
        if d > 80 {
            return Err(Error::Input("unreachable pawn".into()));
        }
        distance[i] = (f64::from(d) / 80.) as f32;
    }
    Ok((
        Features {
            ids,
            distance,
            side: p.turn,
        },
        maps,
    ))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn owned_maps_pawn_copy_wall_replace_and_unreachable() {
        let p = Position::default();
        let (_, maps) = encode_cached(p, None).unwrap();
        let (_, pawn_maps) = encode_cached(p.play(13).unwrap(), Some(&maps)).unwrap();
        assert_eq!(maps, pawn_maps);
        let (_, wall_maps) = encode_cached(p.play(81).unwrap(), Some(&maps)).unwrap();
        assert_ne!(maps, wall_maps);
        let isolated = Position {
            horizontal: 255,
            ..p
        };
        assert!(matches!(
            encode_cached(isolated, None),
            Err(Error::Input(_))
        ));
        let (_, original_again) = encode_cached(p, Some(&maps)).unwrap();
        assert_eq!(maps, original_again);
        assert_eq!(maps.distances, p.wall_distance_maps());
    }

    #[cfg(feature = "research")]
    #[test]
    fn owned_maps_all_cells_legal_children_and_parent_restore() {
        use quoridor_core::research::SigmaContext;
        use std::collections::VecDeque;

        // A queue over explicit edges is independent of the bit-frontier maps.
        fn oracle(p: Position, player: usize) -> [u8; 81] {
            let mut distances = [81; 81];
            let row = if player == 0 { 8 } else { 0 };
            let mut queue = VecDeque::new();
            for x in 0..9 {
                let cell = row * 9 + x;
                distances[cell as usize] = 0;
                queue.push_back(cell);
            }
            while let Some(cell) = queue.pop_front() {
                for next in 0..81 {
                    if distances[next as usize] == 81 && p.is_edge_open(cell, next) {
                        distances[next as usize] = distances[cell as usize] + 1;
                        queue.push_back(next);
                    }
                }
            }
            distances
        }
        fn check(p: Position, maps: &WallMaps) {
            for (player, distances) in maps.distances.iter().enumerate() {
                assert_eq!(*distances, oracle(p, player));
            }
            assert_eq!((maps.horizontal, maps.vertical), (p.horizontal, p.vertical));
        }

        let prefixes: &[&[u16]] = &[
            &[],
            &[13, 67, 81, 66, 14, 65],
            &[13, 67, 81, 66, 14, 65, 143, 126, 150, 64, 141, 151],
            &[13, 67, 22, 58, 31, 49, 40],
            &[13, 67, 22, 58, 31, 49, 40, 48, 49, 39, 58, 30],
            &[13, 67, 22, 58, 31, 49, 40, 48, 49, 39, 58, 30, 67, 21, 76],
        ];
        let mut children = 0;
        for prefix in prefixes {
            let mut context = SigmaContext::from_prefix(prefix).unwrap();
            let before = (
                context.position(),
                context.history_counts(),
                context.total_ply(),
            );
            let (_, parent_maps) = encode_cached(context.position(), None).unwrap();
            check(context.position(), &parent_maps);
            let unchanged_parent = parent_maps;
            for action in context.legal_ids() {
                let undo = context.make_move(action).unwrap();
                let (child_features, child_maps) =
                    encode_cached(context.position(), Some(&parent_maps)).unwrap();
                check(context.position(), &child_maps);
                let (full_features, full_maps) = encode_cached(context.position(), None).unwrap();
                assert_eq!(child_features, full_features);
                assert_eq!(child_maps, full_maps);
                assert_eq!(parent_maps, unchanged_parent);
                context.unmake_move(undo).unwrap();
                assert_eq!(
                    (
                        context.position(),
                        context.history_counts(),
                        context.total_ply()
                    ),
                    before
                );
                check(context.position(), &parent_maps);
                children += 1;
            }
        }
        assert_eq!(children, 635);
        // At most 192 bytes of owned integer map storage, independent of NN width.
        assert!(std::mem::size_of::<WallMaps>() <= 192);
    }
}
