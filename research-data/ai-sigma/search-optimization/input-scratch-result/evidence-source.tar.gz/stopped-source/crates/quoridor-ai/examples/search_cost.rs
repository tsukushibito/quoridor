//! Single-thread research measurement around the production search/session.
//! Comparison-only entry: remove after this task's caller/TT measurements.
use quoridor_ai::alphabeta::{self as ab, EvalAccumulator, StaticEvaluator};
use quoridor_core::research::SigmaContext;
use quoridor_nnue::{EvaluationMode, residual::ResidualModel};
use serde_json::{Value, json};
use std::{
    sync::{Arc, atomic::AtomicBool},
    time::Instant,
};

#[cfg(feature = "profiling")]
mod allocations {
    use std::{
        alloc::{GlobalAlloc, Layout, System},
        sync::atomic::{AtomicBool, AtomicU64, Ordering::Relaxed},
    };
    pub struct Counter;
    static ACTIVE: AtomicBool = AtomicBool::new(false);
    static CALLS: AtomicU64 = AtomicU64::new(0);
    static BYTES: AtomicU64 = AtomicU64::new(0);
    static REALLOCS: AtomicU64 = AtomicU64::new(0);
    static FREES: AtomicU64 = AtomicU64::new(0);
    // Each operation delegates its original pointer/layout contract to System.
    // Counters never read allocated storage or allocate recursively.
    unsafe impl GlobalAlloc for Counter {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            if ACTIVE.load(Relaxed) {
                CALLS.fetch_add(1, Relaxed);
                BYTES.fetch_add(layout.size() as u64, Relaxed);
            }
            unsafe { System.alloc(layout) }
        }
        unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
            if ACTIVE.load(Relaxed) {
                CALLS.fetch_add(1, Relaxed);
                BYTES.fetch_add(layout.size() as u64, Relaxed);
            }
            unsafe { System.alloc_zeroed(layout) }
        }
        unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
            if ACTIVE.load(Relaxed) {
                FREES.fetch_add(1, Relaxed);
            }
            unsafe { System.dealloc(ptr, layout) }
        }
        unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
            if ACTIVE.load(Relaxed) {
                REALLOCS.fetch_add(1, Relaxed);
                BYTES.fetch_add(size as u64, Relaxed);
            }
            unsafe { System.realloc(ptr, layout, size) }
        }
    }
    pub fn enable(enabled: bool) {
        ACTIVE.store(enabled, Relaxed);
    }
    pub fn snapshot() -> [u64; 4] {
        [
            CALLS.load(Relaxed),
            BYTES.load(Relaxed),
            REALLOCS.load(Relaxed),
            FREES.load(Relaxed),
        ]
    }
}
#[cfg(feature = "profiling")]
#[global_allocator]
static ALLOCATOR: allocations::Counter = allocations::Counter;

fn allocation_start(enabled: bool) -> [u64; 4] {
    #[cfg(feature = "profiling")]
    {
        let before = allocations::snapshot();
        allocations::enable(enabled);
        before
    }
    #[cfg(not(feature = "profiling"))]
    {
        let _ = enabled;
        [0; 4]
    }
}
fn allocation_delta(before: [u64; 4]) -> [u64; 4] {
    #[cfg(feature = "profiling")]
    {
        std::array::from_fn(|i| allocations::snapshot()[i] - before[i])
    }
    #[cfg(not(feature = "profiling"))]
    {
        let _ = before;
        [0; 4]
    }
}
fn allocation_stop(before: [u64; 4], enabled: bool) -> Value {
    #[cfg(feature = "profiling")]
    allocations::enable(false);
    if enabled {
        let delta = allocation_delta(before);
        json!({"alloc_calls":delta[0],"requested_bytes_including_realloc":delta[1],
            "realloc_calls":delta[2],"dealloc_calls":delta[3],
            "retained_or_peak_memory":null})
    } else {
        Value::Null
    }
}

#[cfg(feature = "profiling")]
#[derive(Clone, Copy, Default)]
struct Metric {
    calls: u64,
    ns: u128,
    allocations: [u64; 4],
}
#[cfg(feature = "profiling")]
#[derive(Default)]
struct Geometry {
    wall_updates: u64,
    layouts: std::collections::HashSet<(u64, u64)>,
}
struct Observed {
    inner: ab::ResidualEvaluator,
    #[cfg(feature = "profiling")]
    enabled: bool,
    #[cfg(feature = "profiling")]
    metrics: std::sync::Mutex<[Metric; 4]>,
    #[cfg(feature = "profiling")]
    geometry: std::sync::Mutex<Geometry>,
}
impl Observed {
    fn new(model: Arc<ResidualModel>, enabled: bool) -> Self {
        #[cfg(not(feature = "profiling"))]
        let _ = enabled;
        Self {
            inner: ab::ResidualEvaluator::new(model),
            #[cfg(feature = "profiling")]
            enabled,
            #[cfg(feature = "profiling")]
            metrics: std::sync::Mutex::new([Metric::default(); 4]),
            #[cfg(feature = "profiling")]
            geometry: std::sync::Mutex::new(Geometry::default()),
        }
    }
    fn measure<T>(&self, index: usize, operation: impl FnOnce() -> T) -> T {
        #[cfg(feature = "profiling")]
        if self.enabled {
            let before = allocations::snapshot();
            let start = Instant::now();
            let value = operation();
            let ns = start.elapsed().as_nanos();
            let delta = allocation_delta(before);
            let mut metrics = self.metrics.lock().unwrap();
            let metric = &mut metrics[index];
            metric.calls += 1;
            metric.ns += ns;
            for (total, n) in metric.allocations.iter_mut().zip(delta) {
                *total += n;
            }
            return value;
        }
        let _ = index;
        operation()
    }
    fn snapshot(&self) -> Value {
        #[cfg(feature = "profiling")]
        if self.enabled {
            let metrics = self.metrics.lock().unwrap();
            return json!(
                [
                    "prepare_context",
                    "advance_context",
                    "evaluate",
                    "scratch_setup"
                ]
                .into_iter()
                .zip(metrics.iter())
                .map(|(name, m)| json!({"name":name,"calls":m.calls,
                "inclusive_ns":m.ns,"alloc_calls":m.allocations[0],
                "requested_bytes_including_realloc":m.allocations[1],
                "realloc_calls":m.allocations[2],"dealloc_calls":m.allocations[3]}))
                .collect::<Vec<_>>()
            );
        }
        Value::Null
    }
    fn observe_geometry(&self, parent: Option<&EvalAccumulator>, c: &SigmaContext) {
        #[cfg(feature = "profiling")]
        if self.enabled {
            let Some(EvalAccumulator::Float(parent)) = parent else {
                return;
            };
            let previous_walls = parent.features.ids[0]
                .iter()
                .filter(|&&id| (162..290).contains(&id))
                .count();
            let p = c.position();
            if previous_walls != (p.horizontal.count_ones() + p.vertical.count_ones()) as usize {
                // Exclude diagnostic HashSet requests from raw caller counts.
                // Its CPU/RAM cost remains inside the instrumented whole sample.
                allocations::enable(false);
                let mut geometry = self.geometry.lock().unwrap();
                geometry.wall_updates += 1;
                geometry.layouts.insert((p.horizontal, p.vertical));
                allocations::enable(true);
            }
        }
        let _ = (parent, c);
    }
    fn geometry_snapshot(&self) -> Value {
        #[cfg(feature = "profiling")]
        if self.enabled {
            let g = self.geometry.lock().unwrap();
            return json!({"wall_updates":g.wall_updates,"distinct_wall_layouts":g.layouts.len(),
                "unbounded_cache_hit_upper":g.wall_updates-g.layouts.len() as u64,
                "bounded_cache_hits":null,"diagnostic_heap_excluded_from_raw_counts":true});
        }
        Value::Null
    }
}
impl StaticEvaluator for Observed {
    fn create_scratch(&self) -> ab::EvalScratch {
        self.measure(3, || self.inner.create_scratch())
    }
    fn evaluate_with_scratch(
        &self,
        c: &SigmaContext,
        a: Option<&EvalAccumulator>,
        scratch: &mut ab::EvalScratch,
    ) -> ab::Result<f32> {
        self.measure(2, || self.inner.evaluate_with_scratch(c, a, scratch))
    }
    fn prepare_context(&self, c: &SigmaContext) -> ab::Result<Option<EvalAccumulator>> {
        self.measure(0, || self.inner.prepare_context(c))
    }
    fn advance_context(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
    ) -> ab::Result<Option<EvalAccumulator>> {
        self.measure(1, || self.inner.advance_context(a, c))
    }
    fn evaluate(&self, c: &SigmaContext, a: Option<&EvalAccumulator>) -> ab::Result<f32> {
        self.measure(2, || self.inner.evaluate(c, a))
    }
}
fn record(r: &ab::SearchResult) -> Value {
    let s = &r.stats;
    json!({"action":r.action,"value_bits":r.value.map(f32::to_bits),"pv":r.pv,
        "depth":r.completed_depth,"stop":format!("{:?}",r.stop),"elapsed_ns":r.elapsed.as_nanos(),
        "nodes":s.nodes,"evaluations":s.evaluations,"terminal":s.terminal,"cutoffs":s.cutoffs,
        "pvs_researches":s.pvs_researches,"delta_updates":s.delta_updates,
        "tt_probes":s.tt_probes,"tt_hits":s.tt_hits,"tt_exact_hits":s.tt_exact_hits,
        "tt_usable_depth":s.tt_usable_depth,"tt_cutoffs":s.tt_cutoffs,"tt_order_only":s.tt_order_only,
        "tt_key_builds":s.tt_key_builds,"tt_history_items":s.tt_history_items,"tt_hashes":s.tt_hashes,
        "tt_key_history_capacity_bytes":s.tt_key_history_capacity_bytes,
        "tt_retained_bytes":s.tt_retained_bytes,"tt_collisions":s.tt_collisions,
        "tt_replacements":s.tt_replacements,"tt_capacity_skips":s.tt_capacity_skips,
        "tt_illegal_moves":s.tt_illegal_moves,"tt_generation":s.tt_generation})
}
fn namespace(weights: &str) -> ab::SearchNamespace {
    ab::SearchNamespace {
        evaluator: format!("residual-v3:scalar:{weights}"),
        rules: "Sigma:history-complete:ply200".into(),
        selectivity: "full-width:PVS:no-MPC:no-LMR".into(),
    }
}
fn core_start(enabled: bool) {
    #[cfg(feature = "profiling")]
    if enabled {
        quoridor_core::profiling::reset(false);
    }
    let _ = enabled;
}
fn core_stop(enabled: bool) -> Value {
    #[cfg(feature = "profiling")]
    if enabled {
        use quoridor_core::profiling::{self, NAMES};
        let s = profiling::snapshot();
        let mut rows = Vec::new();
        for (k, name) in NAMES.iter().enumerate() {
            for (p, parent) in NAMES.iter().enumerate() {
                let m = s.metrics[k][p];
                if m.calls > 0 {
                    rows.push(json!({"name":name,"parent":parent,"calls":m.calls,
                        "inclusive_ns":m.inclusive_ns,"exclusive_ns":m.exclusive_ns}));
                }
            }
        }
        return json!(rows);
    }
    let _ = enabled;
    Value::Null
}

fn full_reference(c: &SigmaContext, model: &ResidualModel, depth: u16, calls: &mut u64) -> f32 {
    if let Some(value) = c.terminal_value() {
        return value * ab::TERMINAL_SCORE;
    }
    if depth == 0 {
        *calls += 1;
        return model
            .evaluate(&model.full_context(c, EvaluationMode::Scalar).unwrap())
            .unwrap();
    }
    c.legal_ids()
        .into_iter()
        .map(|action| -full_reference(&c.play(action).unwrap(), model, depth - 1, calls))
        .fold(f32::NEG_INFINITY, f32::max)
}

fn tt_sequence(config: &Value, model: Arc<ResidualModel>) -> ab::Result<u64> {
    let evaluator: Arc<dyn StaticEvaluator> = Arc::new(ab::ResidualEvaluator::new(model.clone()));
    let namespace = namespace(config["weights_sha"].as_str().unwrap());
    let target = ab::SearchLimits {
        max_depth: 2,
        max_nodes: 100_000,
        time_limit: None,
        tt_entries: 4096,
        use_pvs: true,
        use_tt: true,
    };
    let mut seed = target.clone();
    seed.max_depth = 3;
    let cancel = AtomicBool::new(false);
    let mut forwards = 0;
    for fixture in config["fixtures"].as_array().unwrap() {
        let prefix: Vec<u16> = serde_json::from_value(fixture["prefix"].clone()).unwrap();
        let root = SigmaContext::from_prefix(&prefix)?;
        let next_id = fixture["next"].as_u64().unwrap() as u16;
        let reply_id = fixture["reply"].as_u64().unwrap() as u16;
        let next = root.play(next_id)?.play(reply_id)?;
        assert_eq!(root.position().turn, next.position().turn);
        assert_eq!(root.total_ply() + 2, next.total_ply());
        let before = (next.position(), next.history_counts(), next.total_ply());
        let root_before = (root.position(), root.history_counts(), root.total_ply());
        let expected = full_reference(&next, &model, 2, &mut forwards);
        println!(
            "{}",
            json!({"kind":"tt_fixture","name":fixture["name"],
            "prefix":prefix,"next":next_id,"reply":reply_id,
            "root_ply":root.total_ply(),"target_ply":next.total_ply(),
            "same_player":true,"target_full_reference_bits":expected.to_bits()})
        );
        for round in 0..config["tt_rounds"].as_u64().unwrap() {
            let pair = Instant::now();
            let setup = Instant::now();
            let mut warm = ab::SearchSession::new(evaluator.clone(), namespace.clone(), 4096)?;
            let setup_ns = setup.elapsed().as_nanos();
            let start = Instant::now();
            let seeded = warm.search(&root, &seed, &cancel)?;
            let seed_ns = start.elapsed().as_nanos();
            assert_eq!(seeded.completed_depth, 3);
            forwards += seeded.stats.evaluations;
            println!(
                "{}",
                json!({"kind":"tt_seed","name":fixture["name"],"round":round,
                "session_setup_ns":setup_ns,"search_ns":seed_ns,"result":record(&seeded),
                "retained_table_metadata_bytes":warm.retained_memory_bytes()})
            );
            let mut outcomes = Vec::new();
            for variant in if round % 2 == 0 {
                ["cold", "warm"]
            } else {
                ["warm", "cold"]
            } {
                let whole = Instant::now();
                let (r, search_ns, memory, cold_drop_ns) = if variant == "cold" {
                    let mut cold =
                        ab::SearchSession::new(evaluator.clone(), namespace.clone(), 4096)?;
                    let start = Instant::now();
                    let r = cold.search(&next, &target, &cancel)?;
                    let search_ns = start.elapsed().as_nanos();
                    let memory = cold.retained_memory_bytes();
                    let drop_start = Instant::now();
                    drop(cold);
                    (r, search_ns, memory, drop_start.elapsed().as_nanos())
                } else {
                    let start = Instant::now();
                    let r = warm.search(&next, &target, &cancel)?;
                    (
                        r,
                        start.elapsed().as_nanos(),
                        warm.retained_memory_bytes(),
                        0,
                    )
                };
                let whole_ns = whole.elapsed().as_nanos();
                assert_eq!(r.completed_depth, 2);
                assert_eq!(r.stop, ab::StopReason::DepthComplete);
                assert!((r.value.unwrap() - expected).abs() <= 1e-5);
                let mut pv = next.clone();
                for &action in &r.pv {
                    pv = pv.play(action)?;
                }
                assert_eq!(r.action, r.pv.first().copied());
                assert_eq!(
                    (next.position(), next.history_counts(), next.total_ply()),
                    before
                );
                forwards += r.stats.evaluations;
                outcomes.push((r.action, r.value.map(f32::to_bits), r.pv.clone()));
                println!(
                    "{}",
                    json!({"kind":"tt_target","name":fixture["name"],"round":round,
                    "variant":variant,"whole_ns":whole_ns,"search_ns":search_ns,
                    "cold_drop_ns":cold_drop_ns,"result":record(&r),
                    "retained_table_metadata_bytes":memory,"parent_restore":true,
                    "full_reference_error":(r.value.unwrap()-expected).abs()})
                );
            }
            let drop_start = Instant::now();
            drop(warm);
            let warm_drop_ns = drop_start.elapsed().as_nanos();
            let pair_ns = pair.elapsed().as_nanos();
            assert_eq!(
                (root.position(), root.history_counts(), root.total_ply()),
                root_before
            );
            println!(
                "{}",
                json!({"kind":"tt_pair","name":fixture["name"],"round":round,
                "seed_setup_both_targets_and_drop_ns":pair_ns,"warm_drop_ns":warm_drop_ns,
                "action_valuebits_PV_equal":outcomes[0]==outcomes[1],
                "whole_pair_includes_seed_and_both_variants":true})
            );
        }
    }
    Ok(forwards)
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().collect();
    assert_eq!(
        args.len(),
        3,
        "search_cost CONFIG MODE(plain|alloc|profile|micro|tt)"
    );
    let config: Value = serde_json::from_slice(&std::fs::read(&args[1])?)?;
    let mode = args[2].as_str();
    assert!(["plain", "alloc", "profile", "micro", "tt"].contains(&mode));
    let count = matches!(mode, "alloc" | "profile");
    assert!(!count || cfg!(feature = "profiling"));
    let whole_start = Instant::now();
    let before = allocation_start(count);
    let start = Instant::now();
    let model = Arc::new(ResidualModel::load(config["manifest"].as_str().unwrap())?);
    let load_ns = start.elapsed().as_nanos();
    let load_alloc = allocation_stop(before, count);
    println!(
        "{}",
        json!({"kind":"model_load","elapsed_ns":load_ns,"allocation":load_alloc})
    );
    if mode == "tt" {
        let forwards = tt_sequence(&config, model)?;
        println!(
            "{}",
            json!({"kind":"complete","whole_ns":whole_start.elapsed().as_nanos(),
            "forwards":forwards,"mode":mode,"coldwarm_key_clock":"UNKNOWN",
            "limits":"same seed3,target2,node100000,TT4096,PVS;fullhistory+ply+immutablemodelnamespace"})
        );
        return Ok(());
    }
    let mut forwards = 0u64;
    for fixture in config["fixtures"].as_array().unwrap() {
        let prefix: Vec<u16> = serde_json::from_value(fixture["prefix"].clone())?;
        let root = SigmaContext::from_prefix(&prefix)?;
        let parent = (root.position(), root.history_counts(), root.total_ply());
        if mode == "micro" {
            let accumulator = model.full_context(&root, EvaluationMode::Scalar)?;
            let mut input_scratch = model.evaluation_scratch();
            let n = config["micro_forwards_per_root"].as_u64().unwrap();
            let mut checksum = 0u64;
            let start = Instant::now();
            for _ in 0..n {
                checksum = checksum.wrapping_add(u64::from(std::hint::black_box(
                    model
                        .evaluate_with_scratch(
                            std::hint::black_box(&accumulator),
                            &mut input_scratch,
                        )?
                        .to_bits(),
                )));
            }
            let elapsed = start.elapsed().as_nanos();
            forwards += n;
            println!(
                "{}",
                json!({"kind":"micro","name":fixture["name"],
                "evaluate_ns":elapsed,"checksum":checksum,"forwards":n,"setup_outside_timer":true})
            );
            continue;
        }
        let observed = Arc::new(Observed::new(model.clone(), count));
        let before = allocation_start(count);
        let start = Instant::now();
        let mut session = ab::SearchSession::new(
            observed.clone(),
            namespace(config["weights_sha"].as_str().unwrap()),
            4096,
        )?;
        let setup_ns = start.elapsed().as_nanos();
        let setup_alloc = allocation_stop(before, count);
        let limits = ab::SearchLimits {
            max_depth: config["depth"].as_u64().unwrap() as u16,
            max_nodes: 100_000,
            time_limit: None,
            tt_entries: 4096,
            use_pvs: true,
            use_tt: true,
        };
        core_start(mode == "profile");
        let before = allocation_start(count);
        let start = Instant::now();
        let r = session.search(&root, &limits, &AtomicBool::new(false))?;
        let search_ns = start.elapsed().as_nanos();
        let search_alloc = allocation_stop(before, count);
        let core = core_stop(mode == "profile");
        assert_eq!(r.completed_depth, limits.max_depth);
        assert_eq!(
            (root.position(), root.history_counts(), root.total_ply()),
            parent
        );
        let memory = session.retained_memory_bytes();
        forwards += r.stats.evaluations;
        let before = allocation_start(count);
        let start = Instant::now();
        drop(session);
        let drop_ns = start.elapsed().as_nanos();
        let drop_alloc = allocation_stop(before, count);
        println!(
            "{}",
            json!({"kind":"search","name":fixture["name"],"prefix":prefix,
            "result":record(&r),"search_ns":search_ns,"search_allocation":search_alloc,
            "session_setup_ns":setup_ns,"session_setup_allocation":setup_alloc,
            "session_drop_ns":drop_ns,"session_drop_allocation":drop_alloc,
            "retained_table_metadata_bytes":memory,"evaluator_components":observed.snapshot(),
            "core_nested_metrics":core,"geometry_reuse_potential":observed.geometry_snapshot(),
            "parent_restore":true})
        );
    }
    println!(
        "{}",
        json!({"kind":"complete","whole_ns":whole_start.elapsed().as_nanos(),
        "forwards":forwards,"mode":mode,"profiling_compiled":cfg!(feature="profiling"),
        "isolated_feature_accumulator_sort_key_hash_clock":"UNKNOWN",
        "clocks":"core inclusive overlaps evaluator composite; do not add those clocks",
        "fragmentation_latency_strength_claim":false})
    );
    Ok(())
}
