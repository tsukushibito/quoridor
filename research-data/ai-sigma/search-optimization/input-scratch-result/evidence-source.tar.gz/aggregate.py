"""Recompute frozen raw results only: no Rust execution, model forward or clock."""

import gzip
import hashlib
import json
from pathlib import Path
import re
import statistics

OUT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rows(text):
    return [json.loads(line) for line in text.splitlines() if line.startswith("{")]


def signature(values):
    signatures = []
    for row in values:
        if row.get("kind") == "search":
            fields = dict(row["result"])
            fields.pop("elapsed_ns")
            signatures.append(
                {"name": row["name"], "prefix": row["prefix"], "result": fields}
            )
    return signatures


def main():
    plan = json.loads((OUT / "numeric-plan.json").read_text())
    data = json.loads((OUT / "numeric-result.json").read_text())
    controller = json.loads((OUT / "numeric-runtime/result.json").read_text())
    assert (
        controller["exit_code"] == 0
        and controller["cleanup_complete"]
        and not controller["remaining"]
    )
    archive = (OUT / "numeric-command-logs.gz").read_bytes()
    restored = {}
    for command in data["commands"]:
        assert command["exit"] == 0 and command["direct_child_waited"]
        log = command["raw_log"]
        raw = gzip.decompress(
            archive[
                log["compressed_offset"] : log["compressed_offset"]
                + log["compressed_bytes"]
            ]
        )
        assert (
            len(raw) == log["raw_bytes"]
            and hashlib.sha256(raw).hexdigest() == log["raw_SHA"]
        )
        restored[command["name"]] = raw.decode()
    assert len(restored) == 35
    reference = signature(rows(Path(plan["reference_search_log"]).read_text()))
    fixture_names = (
        "topology",
        "frozen",
        "error-cancel",
        "reentrant",
        "default-residual",
        "counted-adapter-NN0",
    )
    markers = {}
    for name in fixture_names:
        assert re.search(r"test result: ok\. 1 passed; 0 failed", restored[name])
        markers[name] = [
            line
            for line in restored[name].splitlines()
            if "FORWARDS=" in line or "HEADS=" in line
        ]
    unit_heads = (
        sum(
            int(re.search(pattern, restored[name])[1])
            for name, pattern in (
                ("topology", r"INPUT_SCRATCH_ORACLE_FORWARDS=(\d+)"),
                ("frozen", r"CANONICAL_FT_FROZEN_FORWARDS=(\d+)"),
                ("error-cancel", r"INPUT_SCRATCH_ERROR_HEADS=(\d+)"),
                ("reentrant", r"INPUT_SCRATCH_REENTRANT_HEADS=(\d+)"),
            )
        )
        + 18
    )
    macro_heads = sum(
        values[-1]["forwards"]
        for text in restored.values()
        if (values := rows(text)) and values[-1].get("kind") == "complete"
    )
    assert unit_heads + macro_heads == data["head_forwards"]
    per_root = {}
    comparisons = {}
    for category, order, key in (
        ("primary_canonical", plan["finite_plain_order"], "search_ns"),
        ("secondary_micro", plan["finite_micro_order"], "evaluate_ns"),
    ):
        runs = [run for run in data["runs"] if run["category"] == category]
        assert [run["variant"] for run in runs] == order
        micro_reference = None
        for run in runs:
            name = ("plain-" if category == "primary_canonical" else "micro-") + str(
                run["index"]
            )
            values = rows(restored[name])
            assert (
                values[-1]["whole_ns"] == run["whole_ns"]
                and values[-1]["forwards"] == run["head_forwards"]
            )
            if category == "primary_canonical":
                assert signature(values) == reference
                assert run[key] == sum(
                    row[key] for row in values if row.get("kind") == "search"
                )
                for row in values:
                    if row.get("kind") == "search":
                        per_root.setdefault(
                            row["name"], {"baseline": [], "candidate": []}
                        )[run["variant"]].append(row[key])
            else:
                values = [row for row in values if row.get("kind") == "micro"]
                current = [
                    {k: row[k] for k in ("name", "checksum", "forwards")}
                    for row in values
                ]
                if micro_reference is None:
                    micro_reference = current
                assert current == micro_reference and len(values) == 5
                assert run[key] == sum(row[key] for row in values)
        keys = ("process_wall_ns", "whole_ns", key)
        totals = {
            variant: {
                field: sum(run[field] for run in runs if run["variant"] == variant)
                for field in keys
            }
            for variant in ("baseline", "candidate")
        }
        pairs = []
        for index in range(0, len(runs), 2):
            pair = {run["variant"]: run for run in runs[index : index + 2]}
            pairs.append(
                {
                    field: pair["candidate"][field] / pair["baseline"][field]
                    for field in keys
                }
            )
        comparisons[category] = {
            "totals_ns": totals,
            "candidate_over_baseline": {
                field: totals["candidate"][field] / totals["baseline"][field]
                for field in keys
            },
            "adjacent_pairs": pairs,
            "whole_pairs_faster": sum(pair["whole_ns"] < 1 for pair in pairs),
            "whole_pair_median": statistics.median(pair["whole_ns"] for pair in pairs),
            "whole_pair_range": [
                min(pair["whole_ns"] for pair in pairs),
                max(pair["whole_ns"] for pair in pairs),
            ],
        }
    allocation = rows(restored["allocation"])
    assert signature(allocation) == reference
    historical = OUT.parent / "caller-cost-v1"
    historical_plan = json.loads((historical / "plan.json").read_text())
    historical_binding = json.loads((historical / "binary-binding.json").read_text())[
        "baseline-observed"
    ]
    assert (
        historical_binding["source_SHA"]
        == historical_plan["baseline_SHA"]
        == sha(historical_plan["baseline_residual"])
    )
    assert sha(historical_binding["path"]) == historical_binding["SHA"]
    assert (
        historical_plan["model"]["weights_SHA"]
        == "c0ec9bf3f8f221c2a2d2db6bf70857fa55647e7c7fd15b38786ef941baa079cd"
    )
    old = rows((historical / "calibration-2.log").read_text())
    assert signature(old) == reference
    counts = {}
    for variant, values in (("historical_baseline", old), ("candidate", allocation)):
        roots = {}
        for row in values:
            if row.get("kind") != "search":
                continue
            component = {item["name"]: item for item in row["evaluator_components"]}
            head = component["evaluate"]
            setup = component.get("scratch_setup")
            assert head["calls"] == row["result"]["evaluations"]
            if variant == "candidate":
                assert setup["calls"] == setup["alloc_calls"] == 1
                assert setup["requested_bytes_including_realloc"] == 280
                assert (
                    setup["realloc_calls"]
                    == head["alloc_calls"]
                    == head["realloc_calls"]
                    == 0
                )
                assert head["requested_bytes_including_realloc"] == 0
            else:
                assert head["alloc_calls"] == head["calls"]
                assert head["requested_bytes_including_realloc"] == head["calls"] * 280
            roots[row["name"]] = {
                "evaluate": head,
                "scratch_setup": setup,
                "whole_search": row["search_allocation"],
            }
        counts[variant] = {
            "head_calls": sum(root["evaluate"]["calls"] for root in roots.values()),
            "normal_head_allocations": sum(
                root["evaluate"]["alloc_calls"] for root in roots.values()
            ),
            "normal_head_requested_B": sum(
                root["evaluate"]["requested_bytes_including_realloc"]
                for root in roots.values()
            ),
            "whole_search_allocations": sum(
                root["whole_search"]["alloc_calls"] for root in roots.values()
            ),
            "whole_search_requested_B": sum(
                root["whole_search"]["requested_bytes_including_realloc"]
                for root in roots.values()
            ),
            "per_root": roots,
        }
    software_cost = {
        phase: json.loads(
            (
                OUT
                / ("software-runtime" + ("-" + phase if phase != "r1" else ""))
                / "result.json"
            ).read_text()
        )["wall_seconds"]
        for phase in ("r1", "r2", "r3")
    }
    summary = {
        "status": "LIMITED_NUMERICAL_PARENT_ERROR_NONALIAS_AND_NORMAL_INPUT_HEAP_AVOIDANCE_PASS; ROBUST_SPEED_BENEFIT_NOT_SUPPORTED; ROOT_ADOPTION_PENDING",
        "job_id": controller["job_id"],
        "numeric_whole_s": controller["wall_seconds"],
        "software_whole_s": software_cost,
        "same_candidate_all_attempt_s": sum(software_cost.values())
        + controller["wall_seconds"],
        "head_forwards": unit_heads + macro_heads,
        "unit_head_calls": unit_heads,
        "macro_head_calls": macro_heads,
        "numeric_error_head_attempts": data["numeric_error_head_attempts"],
        "fingerprint_rejects": data["fingerprint_rejects"],
        "FT_prepares_recorded": data["FT_prepares_recorded"],
        "FT_updates_recorded": data["FT_updates_recorded"],
        "FT_full_oracle_detail": data["frozen_full_FT_work"],
        "six_fixture_markers": markers,
        "all35_raw_member_restore_SHA_and_directwait": True,
        "all24_plain_full_result_and_parent_parity": True,
        "micro_checksum_exact": True,
        "comparisons": comparisons,
        "per_root_primary_search_ratio": {
            name: sum(samples["candidate"]) / sum(samples["baseline"])
            for name, samples in per_root.items()
        },
        "allocation_counts": counts,
        "historical_allocator_provenance": {
            "path": str(historical / "calibration-2.log"),
            "SHA": sha(historical / "calibration-2.log"),
            "binding": historical_binding,
            "scope": "Prior same canonical60d/model/roots/depth/counters allocation evidence; NOT a new paired timing result",
        },
        "baseline": plan["baseline_canonical"],
        "model_weights_SHA": "c0ec9bf3f8f221c2a2d2db6bf70857fa55647e7c7fd15b38786ef941baa079cd",
        "decision": "Normal input temporary allocation removed with setup-owned borrowed storage. No automatic speed adoption: whole total2.50percent slower,6of12 faster/median0.996752, short correlated samples. Root weighs explicit memory principle and source ownership separately; no general fragmentation/latency/copy/strength claim.",
        "limitations": "Five fixed genuine roots/depth3/node100k/TT4096/sameBEST;24plain processes/12pairs,4micro processes/2pairs. Single shortseries, no confidence/power inference. Whole includes initialization/drop, process differs; nested clocks not added. Other FT/legal/TT allocations remain. Default Float/Quantized branch compile/delegation proof separate from actual Residual caller qualification; no new unrelated numeric proof claimed.",
        "source_target_writer_STOP": True,
        "shared_target_growth_B": None,
        "old_fees_failures_UNKNOWN": "All preserved; no refunds/new timers/history audit; three pure compile attempts co-ran learnerd105 and are workcost only",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(
        json.dumps(
            {
                "comparisons": {
                    k: v["candidate_over_baseline"] for k, v in comparisons.items()
                },
                "all_attempt_s": summary["same_candidate_all_attempt_s"],
                "heads": summary["head_forwards"],
                "allocation_totals": {
                    k: {
                        field: value
                        for field, value in v.items()
                        if field != "per_root"
                    }
                    for k, v in counts.items()
                },
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
