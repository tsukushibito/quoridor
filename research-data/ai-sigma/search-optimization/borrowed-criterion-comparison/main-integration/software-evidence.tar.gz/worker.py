"""Verify reviewed main integration: no model, benchmark, or FT execution."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
CARGO = "/usr/local/cargo/bin/cargo"


def write(data):
    (OUT / "result.json").write_text(json.dumps(data, indent=2) + "\n")


def main():
    env = dict(
        os.environ,
        CARGO_TARGET_DIR=str(ROOT / ".artifacts/rust-migration/target"),
        CARGO_BUILD_JOBS="2",
        CARGO_INCREMENTAL="0",
        CARGO_NET_OFFLINE="true",
        CUDA_VISIBLE_DEVICES="",
        TMPDIR=str(OUT / "tmp"),
        CRITERION_HOME=str(OUT / "unused-criterion"),
    )
    env.pop("QUORIDOR_BENCH_MANIFEST", None)
    (OUT / "tmp").mkdir(exist_ok=True)
    binding = json.loads((OUT / "binding.json").read_text())
    for path, expected in binding["source_SHA256"].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
    result = {
        "started": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "physical_NN_FT_GPU_forwards": 0,
        "mock_accounting_calls": 2,
        "status": "RUNNING",
        "commands": [],
        "source_binding": binding,
    }
    write(result)

    def command(name, argv):
        receipt = {
            "name": name,
            "argv": argv,
            "started": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
        with (OUT / (name + ".log")).open("wb") as log:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
            receipt["pid"] = child.pid
            try:
                receipt["start_ticks"] = (
                    Path(f"/proc/{child.pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
                )
            except FileNotFoundError:
                receipt["start_ticks"] = None
            receipt["exit_code"] = child.wait()
        receipt.update(
            ended=datetime.datetime.now(datetime.timezone.utc).isoformat(), direct_child_reaped=True
        )
        result["commands"].append(receipt)
        write(result)
        assert receipt["exit_code"] == 0, name

    base = ["--offline", "--locked", "-j", "2"]
    try:
        command(
            "counted-nn0",
            [
                CARGO,
                "test",
                "--release",
                *base,
                "-p",
                "quoridor-runner",
                "--bin",
                "nnue-diagnose",
                "borrowed_input_counter_tests::counted_adapter_forwards_workspace_and_charges_each_call_once_nn0",
                "--",
                "--exact",
            ],
        )
        log = (OUT / "counted-nn0.log").read_text()
        assert "1 passed; 0 failed" in log
        command(
            "bench-no-run",
            [
                CARGO,
                "bench",
                *base,
                "-p",
                "quoridor-ai",
                "--features",
                "research",
                "--bench",
                "nnue_search",
                "--no-run",
                "--message-format=json",
            ],
        )
        artifacts = [
            json.loads(line)
            for line in (OUT / "bench-no-run.log").read_text().splitlines()
            if line.startswith("{")
        ]
        images = [
            x["executable"]
            for x in artifacts
            if x.get("reason") == "compiler-artifact"
            and x.get("executable")
            and x["target"]["name"] == "nnue_search"
        ]
        assert len(images) == 1
        command("bench-early-help", [images[0], "--help"])
        result["bench_image"] = {
            "path": images[0],
            "SHA256": hashlib.sha256(Path(images[0]).read_bytes()).hexdigest(),
        }
        command(
            "nnue-ai-clippy",
            [
                CARGO,
                "clippy",
                "--release",
                *base,
                "-p",
                "quoridor-nnue",
                "-p",
                "quoridor-ai",
                "--features",
                "quoridor-ai/research",
                "--lib",
                "--",
                "-D",
                "warnings",
            ],
        )
        command(
            "runner-clippy",
            [
                CARGO,
                "clippy",
                "--release",
                *base,
                "-p",
                "quoridor-runner",
                "--bin",
                "nnue-diagnose",
                "--",
                "-D",
                "warnings",
            ],
        )
        command(
            "bench-clippy",
            [
                CARGO,
                "clippy",
                "--release",
                *base,
                "-p",
                "quoridor-ai",
                "--features",
                "research",
                "--bench",
                "nnue_search",
                "--",
                "-D",
                "warnings",
            ],
        )
        result["status"] = "SCOPED_SOFTWARE_AND_MOCK_PASS_NO_MODEL_FORWARD"
    except BaseException as exc:
        result["status"] = "FAILED"
        result["error"] = repr(exc)
        raise
    finally:
        result["ended"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(result)


if __name__ == "__main__":
    main()
