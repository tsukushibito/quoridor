"""Reuse the frozen owner/RSS/output guardian for this main software namespace."""

import importlib.util
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
SOURCE = (
    ROOT
    / ".worktree/search-optimization/.artifacts/search-optimization/criterion-smoke-v1/guard.py"
)
SPEC = importlib.util.spec_from_file_location("owned_guard", SOURCE)
GUARD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GUARD)
GUARD.OUT = Path(__file__).resolve().parent
GUARD.ROOT = ROOT

if __name__ == "__main__":
    GUARD.main()
