"""Finite bound Criterion ABBA comparison; preserve raw and restore shared ELF."""

import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tarfile
import time

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + "\n")


def install(packed, target, digest):
    raw = gzip.decompress(Path(packed).read_bytes())
    assert hashlib.sha256(raw).hexdigest() == digest
    Path(target).write_bytes(raw)
    Path(target).chmod(0o755)
    assert sha(target) == digest


def restore():
    plan = json.loads((OUT / "plan.json").read_text())
    a = plan["canonical"]
    install(plan["canonical_compressed"], a["binary"], a["binary_SHA256"])
    for path, digest in a["main_source"].items():
        assert sha(path) == digest, path
    write("restoration.json", {"canonical_ELF_and_source_restored": True})
    return {"restored": True}


def archive_block(home, name):
    # This exclusively owned generated working directory has a declared block
    # lifetime. Preserve every byte/SHA before recycling it; never old assets.
    files = sorted(p for p in home.rglob("*") if p.is_file())
    members = {str(p.relative_to(home)): sha(p) for p in files}
    archive = OUT / f"{name}-criterion-raw.tar.gz"
    with tarfile.open(archive, "w:gz") as tar:
        for p in files:
            tar.add(p, arcname=str(p.relative_to(home)), recursive=False)
    with tarfile.open(archive, "r:gz") as tar:
        restored = {}
        for member in tar.getmembers():
            raw = tar.extractfile(member).read()
            restored[member.name] = hashlib.sha256(raw).hexdigest()
    assert restored == members
    write(
        f"{name}-archive.json",
        {
            "archive_SHA": sha(archive),
            "members": members,
            "all_byte_SHA_roundtrip": True,
        },
    )
    shutil.rmtree(home)


def main():
    os.sched_setaffinity(0, {0, 1})
    plan = json.loads((OUT / "plan.json").read_text())
    a = plan["canonical"]
    proof = json.loads(Path(plan["candidate_software_proof"]).read_text())
    for path, digest in a["main_source"].items():
        assert sha(path) == digest, path
    assert sha(ROOT / "Cargo.lock") == a["lock_SHA256"]
    assert sha(a["binary"]) == a["binary_SHA256"]
    assert sha(a["manifest"]) == a["manifest_SHA256"]
    manifest = json.loads(Path(a["manifest"]).read_text())
    assert sha(Path(a["manifest"]).parent / manifest["weights"]) == a["weights_SHA256"]
    assert sha(proof["compressed_path"]) == proof["compressed_SHA256"]
    for key in ["residual", "alphabeta", "native_diagnose"]:
        item = plan["candidate"][key]
        assert sha(item["stopped_path"]) == item["candidate_SHA"]
    for path, item in plan["candidate"]["dependency_math_alignment"].items():
        assert sha(path) == item["candidate_SHA"]
    assert (
        proof["source_SHA"][str(ROOT / "crates/quoridor-nnue/src/residual.rs")]
        == plan["candidate"]["residual"]["candidate_SHA"]
    )
    assert (
        proof["source_SHA"][str(ROOT / "crates/quoridor-ai/src/alphabeta.rs")]
        == plan["candidate"]["alphabeta"]["candidate_SHA"]
    )
    assert (
        proof["source_SHA"][str(ROOT / "crates/quoridor-ai/benches/nnue_search.rs")]
        == plan["candidate"]["prepared_bench_SOURCE_SHA256"]
    )
    expected = json.loads(Path(plan["expected_qualification"]).read_text())
    versions = {
        "A": (plan["canonical_compressed"], a["binary_SHA256"]),
        "B": (proof["compressed_path"], proof["ELF_SHA256"]),
    }
    home = OUT / "criterion-working"
    env = dict(
        os.environ,
        QUORIDOR_BENCH_MANIFEST=a["manifest"],
        CRITERION_HOME=str(home),
        CRITERION_DEBUG="1",
        CUDA_VISIBLE_DEVICES="",
        PYTHONDONTWRITEBYTECODE="1",
    )
    child = None
    cancelled = False
    result = {"status": "RUNNING", "commands": [], "profile": "UNADMITTED_NOT_RUN"}
    subset = "^(nnue/evaluate|search/cold_setup_search_drop)/(initial|opening|walled-midgame|jump-p2|endgame)$"

    def cancel(_signal, _frame):
        nonlocal cancelled
        cancelled = True
        if child is not None and child.poll() is None:
            child.terminate()

    signal.signal(signal.SIGTERM, cancel)
    signal.signal(signal.SIGINT, cancel)

    def command(name, version, args, purpose):
        nonlocal child
        assert not cancelled
        packed, digest = versions[version]
        install(packed, a["binary"], digest)
        argv = [a["binary"], *args]
        receipt = {
            "argv": argv,
            "version": version,
            "ELF_SHA256": digest,
            "purpose": purpose,
            "started": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "direct_child_reaped": False,
        }
        start = time.monotonic()
        with (OUT / f"{name}.log").open("wb") as log:
            child = subprocess.Popen(
                argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT
            )
            try:
                ticks = (
                    Path(f"/proc/{child.pid}/stat")
                    .read_text()
                    .rsplit(")", 1)[1]
                    .split()[19]
                )
            except FileNotFoundError:
                ticks = None
            receipt["child"] = {"pid": child.pid, "start_ticks": ticks, "boot_id": BOOT}
            write(f"{name}.process.json", receipt)
            rc = child.wait()
        receipt.update(
            exit_code=rc,
            direct_child_reaped=True,
            process_whole_seconds=time.monotonic() - start,
            ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        )
        write(f"{name}.process.json", receipt)
        result["commands"].append(receipt)
        child = None
        write("numeric-result.json", result)
        assert rc == 0 and not cancelled, f"{name} failed; no automatic repeat"
        rows = [
            json.loads(line)
            for line in (OUT / f"{name}.log").read_text().splitlines()
            if line.startswith("{")
        ]
        typed = [r for r in rows if r.get("kind") == "qualification"]
        assert typed == expected, f"{name} arithmetic/work/history differs"
        assert sha(a["binary"]) == digest
        return receipt

    try:
        # Only the changed actual adapter caller is requalified. Old frozen
        # all-topology/full-delta/error/cancel/allocation proofs are retained.
        command(
            "qualify-A",
            "A",
            ["--test", subset],
            "changed driver/production caller oracle",
        )
        command(
            "qualify-B",
            "B",
            ["--test", subset],
            "borrowed head allocating bits and production caller oracle",
        )
        write(
            "caller-qualification.json",
            {
                "all5_typed_exact": True,
                "reusable_borrowed_head_matches_allocating_bits": True,
                "prior_allwidth_parent_error_cancel_allocation_evidence": plan[
                    "exact_source_old_oracle_receipt"
                ],
            },
        )
        if home.exists():
            archive_block(home, "qualification")
        for block, names in enumerate(
            [["A0", "B0", "B1", "A1"], ["A2", "B2", "B3", "A3"]]
        ):
            for name in names:
                command(
                    name,
                    name[0],
                    ["--bench", subset, "--save-baseline", name],
                    "plain measured process,50samples/1swarmup/3starget",
                )
            comparisons = []
            for b in names[1:3]:
                for baseline in [names[0], names[3]]:
                    label = f"{b}-versus-{baseline}"
                    command(
                        label,
                        "B",
                        [
                            "--bench",
                            subset,
                            "--load-baseline",
                            b,
                            "--baseline",
                            baseline,
                        ],
                        "standard loaded Criterion analysis; actual startup forwards included",
                    )
                    changes = {}
                    for scope in ["nnue/evaluate", "search/cold_setup_search_drop"]:
                        for root in plan["frozen_workload"]["fixtures"]:
                            key = f"{scope}/{root['name']}"
                            folder = home / key.replace("/", "_")
                            changes[key] = {
                                "estimates": json.loads(
                                    (folder / "change/estimates.json").read_text()
                                ),
                                "standard_test_classification_log": f"{label}.log",
                            }
                    write(f"{label}-changes.json", changes)
                    comparisons.append(label)
            write(f"block{block}-comparisons.json", comparisons)
            archive_block(home, f"block{block}")
        result["status"] = "COMPLETED_NO_AUTOMATIC_ADOPTION"
    except BaseException as exc:
        result["status"] = "FAILED"
        result["error"] = repr(exc)
        raise
    finally:
        if child is not None:
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    child.kill()
            child.wait()
        restore()
        write("numeric-result.json", result)


if __name__ == "__main__":
    main()
