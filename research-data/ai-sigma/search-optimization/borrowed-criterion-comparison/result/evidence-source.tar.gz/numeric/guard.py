"""Bound owned output/RSS and restore canonical source/ELF after exact owned cleanup."""

import datetime
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from worker import restore

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor/.worktree/search-optimization")
UTILITY = ROOT / ".artifacts/search-optimization/criterion-smoke-v1/guard.py"
SPEC = importlib.util.spec_from_file_location("process_utility", UTILITY)
UTILITY_MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(UTILITY_MODULE)
proc = UTILITY_MODULE.proc
descendants = UTILITY_MODULE.descendants


def footprint():
    total = 0
    for base, _, names in os.walk(OUT):
        for name in names:
            try:
                total += (Path(base) / name).stat().st_blocks * 512
            except FileNotFoundError:
                pass
    return total


def main():
    os.sched_setaffinity(0, {0, 1})
    interrupted = False

    def cancel(_signal, _frame):
        nonlocal interrupted
        interrupted = True

    signal.signal(signal.SIGTERM, cancel)
    signal.signal(signal.SIGINT, cancel)
    identities = {}
    peak_rss = peak_output = 0
    reason = None
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT / "worker.log").open("wb") as log:
        child = subprocess.Popen(
            [sys.executable, "-B", str(OUT / "worker.py")],
            cwd=ROOT,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        leader = proc(child.pid)
        if leader:
            identities[child.pid] = leader
        while child.poll() is None:
            owned = descendants(child.pid)
            identities.update(owned)
            own = proc(os.getpid())
            peak_rss = max(
                peak_rss,
                sum(p["rss"] for p in owned.values())
                + (own["rss"] if own else 0)
                + 64 * 1024**2,
            )
            peak_output = max(peak_output, footprint())
            if interrupted:
                reason = "explicit_owned_cancel"
            elif peak_rss > 2 * 1024**3:
                reason = "family_RSS"
            elif peak_output > 2097152:
                reason = "phase_aggregate_owned_output"
            if reason:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                break
            time.sleep(0.05)
        rc = child.wait()
    remaining = [
        value
        for pid, value in identities.items()
        if (actual := proc(pid)) and actual["tick"] == value["tick"]
    ]
    for value in remaining:
        os.kill(value["pid"], signal.SIGTERM)
    if remaining:
        time.sleep(0.1)
    remaining = [
        value
        for pid, value in identities.items()
        if (actual := proc(pid)) and actual["tick"] == value["tick"]
    ]
    # A second restoration owner covers worker termination during its finally.
    # Do not release the target while any recorded compiler may still write it.
    restored = False
    restoration_error = None
    if not remaining:
        try:
            restored = restore()["restored"]
        except (OSError, ValueError, AssertionError) as exc:
            restoration_error = repr(exc)
    receipt = {
        "started": started,
        "ended": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "exit_code": rc,
        "reason": reason,
        "direct_child_reaped": True,
        "leader": leader,
        "identities": list(identities.values()),
        "remaining": remaining,
        "cleanup_complete": not remaining,
        "canonical_source_and_ELF_restored": restored,
        "restoration_error": restoration_error,
        "family_RSS_sampled_peak_including_controller_B": peak_rss,
        "owned_output_sampled_peak_B": peak_output,
        "owned_output_final_B": footprint(),
        "shared_target_growth_peak_B": None,
        "capacity_method": "Root admitted finite artifact-lifetime forecast; only owned namespace sampled, no live sharedtarget/registry inventory",
        "CPU": [0, 1],
        "GPU": 0,
        "NN_FT_statistics": "all model/FT/head counts to be collected from exact warmup/sample/startup logs",
        "learner_context": "8b672b9d exactSTOP02:35:31.861342; substantial metadata collection serialized before numeric",
        "max_runtime_seconds": None,
    }
    (OUT / "process.json").write_text(json.dumps(receipt, indent=2) + "\n")
    if rc or reason or remaining or not restored:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
