"""Collect saved Criterion statistics/counters without new numerical work."""

from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import statistics
import tarfile

OUT = Path(__file__).resolve().parent


def read(name):
    return json.loads((OUT / name).read_text())


def main():
    plan = read("plan.json")
    expected = json.loads(Path(plan["expected_qualification"]).read_text())
    archive = {}
    for block in range(2):
        proof = read(f"block{block}-archive.json")
        path = OUT / f"block{block}-criterion-raw.tar.gz"
        assert hashlib.sha256(path.read_bytes()).hexdigest() == proof["archive_SHA"]
        with tarfile.open(path, "r:gz") as tar:
            contents = {m.name: tar.extractfile(m).read() for m in tar.getmembers()}
        assert {k: hashlib.sha256(v).hexdigest() for k, v in contents.items()} == proof[
            "members"
        ]
        archive[block] = contents

    def member(block, key):
        return json.loads(archive[block][key])

    bases = ["A0", "B0", "B1", "A1", "A2", "B2", "B3", "A3"]
    pairs = [
        ("B0", ["A0", "A1"]),
        ("B1", ["A0", "A1"]),
        ("B2", ["A2", "A3"]),
        ("B3", ["A2", "A3"]),
    ]
    scopes = ["nnue/evaluate", "search/cold_setup_search_drop"]
    classifications = []
    for scope in scopes:
        for fixture in plan["frozen_workload"]["fixtures"]:
            key = f"{scope}/{fixture['name']}"
            comparisons = []
            per_process = []
            for b, refs in pairs:
                adverse = []
                favorable = []
                for a in refs:
                    label = f"{b}-versus-{a}"
                    change = read(f"{label}-changes.json")[key]["estimates"]["mean"]
                    log = (OUT / f"{label}.log").read_text()
                    start = log.index(f"Benchmarking {key}: Analyzing")
                    end = log.find("\nBenchmarking ", start + 1)
                    segment = log[start : end if end >= 0 else len(log)]
                    standard = next(
                        text
                        for text in [
                            "Performance has regressed.",
                            "Performance has improved.",
                            "Change within noise threshold.",
                            "No change in performance detected.",
                        ]
                        if text in segment
                    )
                    ci = change["confidence_interval"]
                    adverse.append(
                        standard == "Performance has regressed."
                        and ci["lower_bound"] > 0.01
                    )
                    favorable.append(
                        standard == "Performance has improved."
                        and ci["upper_bound"] < -0.01
                    )
                    comparisons.append(
                        {
                            "B": b,
                            "A_reference": a,
                            "relative_mean_change": change,
                            "standard_Criterion_classification": standard,
                        }
                    )
                per_process.append(
                    {
                        "B": b,
                        "both_brackets_adverse": all(adverse),
                        "both_brackets_favorable_descriptive_only": all(favorable),
                    }
                )
            adverse_count = sum(x["both_brackets_adverse"] for x in per_process)
            classifications.append(
                {
                    "ID": key,
                    "comparisons": comparisons,
                    "B_processes": per_process,
                    "adverse_processes_of4": adverse_count,
                    "locked_clear_regression": adverse_count >= 3,
                    "median_relative_point_descriptive": statistics.median(
                        x["relative_mean_change"]["point_estimate"] for x in comparisons
                    ),
                    "favorable_processes_of4_descriptive": sum(
                        x["both_brackets_favorable_descriptive_only"]
                        for x in per_process
                    ),
                }
            )

    startup_head_a = sum(
        4 * q["cold"]["counters"][1]
        + q["target_cold"]["counters"][1]
        + 2 * q["target_warm"]["counters"][1]
        + 2
        for q in expected
    )
    startup_delta = sum(
        4 * q["cold"]["counters"][21]
        + q["target_cold"]["counters"][21]
        + 2 * q["target_warm"]["counters"][21]
        for q in expected
    )
    # The changed adapter executes one additional reusable-head vs allocating
    # bits check for each root. Loaded analyses still execute these preflights.
    startup_head_b = startup_head_a + len(expected)
    totals = {"head_calls": 0, "exported_delta_updates": 0}
    iterations = []
    process_cost = []
    commands = read("numeric-result.json")["commands"]
    assert len(commands) == 18
    for c in commands:
        name = Path(c["argv"][0]).name
        # Receipts are uniquely identified by their persisted argv/version and
        # finite plan rather than reconstructing any scientific run.
        if "--test" in c["argv"]:
            name = f"qualify-{c['version']}"
        elif "--load-baseline" in c["argv"]:
            name = (
                c["argv"][c["argv"].index("--load-baseline") + 1]
                + "-versus-"
                + c["argv"][c["argv"].index("--baseline") + 1]
            )
        else:
            name = c["argv"][c["argv"].index("--save-baseline") + 1]
        log = (OUT / f"{name}.log").read_text()
        typed = [json.loads(line) for line in log.splitlines() if line.startswith("{")]
        assert [q for q in typed if q.get("kind") == "qualification"] == expected
        head = startup_head_a if c["version"] == "A" else startup_head_b
        delta = startup_delta
        if "--test" in c["argv"]:
            head += sum(q["cold"]["counters"][1] + 1 for q in expected)
            delta += sum(q["cold"]["counters"][21] for q in expected)
        elif "--save-baseline" in c["argv"]:
            block = 0 if name in bases[:4] else 1
            for q in expected:
                for scope in scopes:
                    key = f"{scope}/{q['fixture']}"
                    folder = key.replace("/", "_")
                    sample = member(block, f"{folder}/{name}/sample.json")
                    estimates = member(block, f"{folder}/{name}/estimates.json")
                    assert len(sample["iters"]) == len(sample["times"]) == 50
                    measured = int(sum(sample["iters"]))
                    matches = re.findall(
                        rf"Benchmarking {re.escape(key)}: Warming up.*?Completed (\d+) iterations",
                        log,
                        re.DOTALL,
                    )
                    assert len(matches) == 1
                    warm = int(matches[0])
                    per_head = (
                        1 if scope == "nnue/evaluate" else q["cold"]["counters"][1]
                    )
                    per_delta = (
                        0 if scope == "nnue/evaluate" else q["cold"]["counters"][21]
                    )
                    head += (warm + measured) * per_head
                    delta += (warm + measured) * per_delta
                    iterations.append(
                        {
                            "process": name,
                            "ID": key,
                            "warmup_iterations": warm,
                            "sample_iterations": measured,
                            "sample_timer_sum_ns": sum(sample["times"]),
                            "sampling_mode": sample["sampling_mode"],
                            "standard_mean_estimate_ns": estimates["mean"],
                            "standard_displayed_estimator": "slope"
                            if estimates.get("slope")
                            else "mean",
                            "standard_displayed_estimate_ns": estimates.get("slope")
                            or estimates["mean"],
                        }
                    )
        else:
            assert "--load-baseline" in c["argv"] and "Completed " not in log
        totals["head_calls"] += head
        totals["exported_delta_updates"] += delta
        process_cost.append(
            {
                "process": name,
                "version": c["version"],
                "whole_seconds": c["process_whole_seconds"],
                "head_calls": head,
                "exported_delta_updates": delta,
                "scope": c["purpose"],
            }
        )
    adverse = [
        x["ID"]
        for x in classifications
        if x["ID"].startswith("search/") and x["locked_clear_regression"]
    ]
    control = read("runtime/result.json")
    total_known = Decimal("237.642484780051743") + Decimal(str(control["wall_seconds"]))
    summary = {
        "job_id": control["job_id"],
        "classification": "NO_REPRODUCIBLE_REGRESSION_NO_SPEED_ADOPTION"
        if not adverse
        else "LOCKED_REGRESSION_TRIGGERED",
        "qualification": "PASS_LIMITED all5 typed across18 processes; original frozen alltopology/error/cancel/allocation evidence reused",
        "classification_by_ID": classifications,
        "iterations": iterations,
        "process_costs": process_cost,
        "actual_exported_work": totals,
        "unexported_internal_FT_operations": None,
        "global_adverse": len(adverse) >= 4,
        "conditional_profile_trigger_roots": adverse,
        "profile_admission": False,
        "profile_execution": "NOT_RUN",
        "whole_controller_seconds": control["wall_seconds"],
        "known_Criterion11_controller_s": str(total_known),
        "old_failed_jobs_and_UNKNOWN": "preserved; nested process/statistics clocks never added to controller total",
        "limits": [
            "50 samples per ID/process are not50 independent processes",
            "descriptive medians across correlated bracket comparisons have no pooled CI",
            "Criterion processes choose adaptive repetition counts, so whole process wall is workcost rather than a fixed-work speed ratio",
            "head excludes FT/setup; coldsearch includes normal root FT, scratch/session/table setup and drop",
            "no speed, causal profiler, fragmentation, latency, strength or main API adoption",
            "old negative smallsample source/results remain intact; this result does not retroactively validate them",
        ],
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(
        json.dumps(
            {
                "adverse_roots": adverse,
                "work": totals,
                "known_controller_s": str(total_known),
            }
        )
    )


if __name__ == "__main__":
    main()
