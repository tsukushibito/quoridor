"""Custodian dataset assembly; sealed test labels never join the training artifact."""
from pathlib import Path
import collections,datetime,gzip,hashlib,json,subprocess,sys,time
R=Path.cwd();D=R/'research-data/ai-sigma/frame18-data-learning';OLD=R/'research-data/ai-sigma/frame16-teacher-throughput/fresh96-stage'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:[json.loads(l)for l in gzip.open(p,'rt')if l.strip()]
out=D/'dataset-v1';assert not out.exists(),'IMMUTABLE_DATASET_EXISTS';out.mkdir()
plan={'kind':'QF1-dynamic-plan','games':[],'stages':[],'old96_alias_reason':'previous evaluation-only candidate reassigned to train in this new dataset; original version/IDs/groups remain immutable'}
metadata_paths=[OLD/'canonical-metadata.jsonl.gz'];labels=[];test_files=[];qualified_train=[];planned_safe=[]
oldmeta=read(metadata_paths[0]);oldcounts=collections.Counter(r['game_id']for r in oldmeta)
oldspec=json.loads((OLD/'openings.json').read_text())['games']
for i,g in enumerate(oldspec,1):
    plan['games'].append(dict(game_id=g['game_id'],family=g['family'],split='train',source_split='evaluation',
      cohort='opening-'+str(g['target_ply']),expected_rows=oldcounts[g['game_id']],train_slot=i))
    qualified_train.append(g['family'])
for r in read(OLD/'labels.jsonl.gz'):labels.append(dict(r,split='train'))
for name in ['val96','test96','train01','train02','train03','train04','train05']:
    specs=json.loads((D/f'{name}-openings.json').read_text())['games'];counts=collections.Counter();completed=set()
    for k in [1,2]:
        cfg=json.loads((D/f'{name}-chunk{k}-config.json').read_text());O=Path(cfg['job_out'])
        if not (O/'metadata.jsonl.gz').exists():continue
        metadata_paths.append(O/'metadata.jsonl.gz');counts.update(r['game_id']for r in read(O/'metadata.jsonl.gz'))
        summary=json.loads((O/'summary.json').read_text());status=json.loads((O/'all-status.json').read_text())
        completed.update(g['game_id']for g in status if g['status']in ['GOAL','DRAW200','DRAW_NOLEGAL'])
        if name=='test96':test_files.append(O/'labels.jsonl.gz')
        else:labels.extend(read(O/'labels.jsonl.gz'))
    for g in specs:
        row=dict(game_id=g['game_id'],family=g['family'],split=g['split'],cohort='opening-'+str(g['target_ply']),expected_rows=counts[g['game_id']])
        if g['split']=='train':row['train_slot']=g['train_slot']
        plan['games'].append(row)
        planned_safe.append(dict(game_id=g['game_id'],family=g['family'],split=g['split'],rows=counts[g['game_id']],completed=g['game_id']in completed))
        if g['split']=='train'and g['game_id']in completed and counts[g['game_id']]>0:qualified_train.append(g['family'])
# Planned zero-row families stay in the full ledger; only completed families carry effective labels.
max_positive=len(qualified_train);small_positive=len([f for f in qualified_train if f in {g['family']for g in plan['games']if g['split']=='train'and g['train_slot']<=192}])
planned_train=sum(g['split']=='train'for g in plan['games'])
assert planned_train==576
plan['stages']=[192,576]  # Family slots include typed zero-row missing slots; stage reports retain G+.
training_labels=out/'training-labels.jsonl.gz'
with gzip.open(training_labels,'wt')as f:
    for lab in labels:
        assert lab['split']in ['train','validation'];f.write(json.dumps(lab)+'\n')
sealed=D/'test-sealed'/'test-labels-combined-v1.jsonl.gz';assert not sealed.exists()
with gzip.open(sealed,'wb')as f:
    for p in test_files:
        # Owner-only byte concatenation. Label values are not decoded or used for selection.
        with gzip.open(p,'rb')as source:
            while b:=source.read(1024*1024):f.write(b)
plan['training_labels_advertised']={'path':str(training_labels),'sha256':sha(training_labels)}
plan['sealed_test_advertised']={'path':str(sealed),'sha256':sha(sealed)}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(out/'quantity-freeze.json').write_text(json.dumps({'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'planned_new_games':672,'train_planned':576,'train_positive':max_positive,'small_positive':small_positive,
 'val_positive':sum(g['split']=='validation'and g['expected_rows']>0 for g in plan['games']),
 'test_positive':sum(g['split']=='test'and g['expected_rows']>0 for g in plan['games']),
 'secondary_nonselection':{'small_step':400,'large_step':min([0,1,2,5,10,20,50,100,200,400,800,1200,2000],key=lambda s:(abs(s/max_positive-400/small_positive),s))if small_positive and max_positive else None,
 'G_small':small_positive,'G_large':max_positive,'rule':'argmin abs(step/G_large-400/G_small), tie early, before curves'},
 'all_slot_ledger':planned_safe,'test_label_values_decoded':False},indent=2)+'\n')
cmd=['/usr/bin/python3','-B',str(R/'tools/ai-sigma-frame18-learning/manifest_adapter.py'),'--plan',str(out/'plan.json'),'--out',str(out/'adapter')]
for p in metadata_paths:cmd.extend(['--metadata',str(p)])
subprocess.run(cmd,check=True)
print(json.dumps({'dataset':str(out),'train_positive':max_positive,'small_positive':small_positive,'NN':0,'testlabels_joined':False}))
