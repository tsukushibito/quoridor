"""Curves-before-selection immutable learning settings and train-only baselines."""
from pathlib import Path
import argparse,collections,hashlib,json,math,struct,sys
R=Path.cwd();D=R/'research-data/ai-sigma/frame18-data-learning';T=R/'tools/ai-sigma-frame18-data-learning'
sys.path.insert(0,str(R/'tools/ai-sigma-frame18-learning'));sys.path.insert(0,str(R/'tools/nnue-training'))
from loader import load_training_stage
from common import resolve_config,measurements
from frame14_data import canonical_model_input
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]

def distance_fit(rows):
    groups=collections.Counter(r['group']for r in rows);G=len(groups)
    assert G and all(r['split']=='train'for r in rows)
    points=[(1/(G*groups[r['group']]),f32(r['distance'][1]-r['distance'][0]),r['rootmean'])for r in rows]
    mx=sum(w*x for w,x,y in points);my=sum(w*y for w,x,y in points)
    variance=sum(w*(x-mx)**2 for w,x,y in points);covariance=sum(w*(x-mx)*(y-my)for w,x,y in points)
    b=covariance/variance if variance else 0.;a=my-b*mx
    return {'a':a,'b':b,'a_f32':f32(a),'b_f32':f32(b),'constant':my,'train_games':G,'train_rows':len(rows),
      'zero_input_variance':not variance,'fit_rule':'train-only gameequal WLS, unpenalized a+b*(f32 opp-self), predictions f32 clamp',
      'weight_rule':'1/(G*n_game)','input_mean':mx,'input_variance':variance,'labels_partitions':['train']}

def distance_prediction(row,fit):
    s=f32(row['distance'][1]-row['distance'][0]);return max(-1.,min(1.,f32(fit['a_f32']+f32(fit['b_f32']*s))))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--dataset',required=True);a=p.parse_args();dataset=Path(a.dataset);out=D/'learning-plan-v1';assert not out.exists();out.mkdir()
    master=json.loads((dataset/'quantity-freeze.json').read_text());source_paths=list(T.glob('*.py'))+[R/'tools/nnue-training/train.py',R/'tools/nnue-training/model.py',R/'tools/nnue-training/common.py',R/'tools/nnue-training/frame14_data.py',R/'tools/ai-sigma-frame18-learning/loader.py',R/'research-data/ai-sigma/frame15-input-scale-control/scale.json']
    sources={str(p):sha(p)for p in source_paths}
    stages=[]
    for planned in [192,576]:
        stage=dataset/'adapter'/f'{planned}.stage.json';rows,verification=load_training_stage(stage)
        train=[r for r in rows if r['split']=='train'];val=[r for r in rows if r['split']=='validation'];positive=len({r['group']for r in train})
        fitted=distance_fit(train);baseline={s:measurements([r for r in rows if r['split']==s and(s=='train'or r.get('primary_eligible',True))],
            [distance_prediction(r,fitted)for r in rows if r['split']==s and(s=='train'or r.get('primary_eligible',True))],'rootmean',fitted['constant'])for s in['train','validation']}
        (out/f'baseline-{planned}.json').write_text(json.dumps({'fit':fitted,'metrics':baseline,'stage_SHA':sha(stage),'testlabels_read':False},indent=2)+'\n')
        upper=256000+14*len(rows)
        cfg=resolve_config(overrides=['optimizer.lr=0.0001','optimizer.weight_decay=0','training.steps=2000','training.batch_size=128','training.seed=19080311','training.sampling="game"','training.target="rootmean"','training.threads=1','training.device="cpu"','evaluation.interval=100','evaluation.early_stopping_patience=0','data.overlap_policy="report"','limits.seconds=280','limits.samples='+str(upper)])
        config=out/f'config-{planned}.json';config.write_text(json.dumps(cfg,indent=2)+'\n')
        run_id=f'frame18-growth228-planned{planned}-positive{positive}-r1'
        settings={'run_id':run_id,'stage':str(stage),'config':str(config),'output':str(D/'learning-runs'),'checkpoints':str(D/'learning-checkpoints'),
          'guardian_out':str(D/'learning-guardian'/run_id),'entry':'train.py','sources':sources,'hard_s':300,'sample_upper':upper,
          'counter_file':str(D/'learning-runs'/run_id/'summary.json'),'newscience_deadline':'2026-10-04T13:40:00Z','stop_deadline':'2026-10-04T13:50:00Z',
          'runtime_loaded':str(R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-RESUME-OPERATIONS-92/frame18/running-loaded.json'),
          'planned_train_G':planned,'positive_train_G':positive,'val_rows':len(val),'test_joined':False,'fixed_scale_SHA':sha(R/'research-data/ai-sigma/frame15-input-scale-control/scale.json')}
        settings['sources'][str(config)]=sha(config);settings['sources'][str(stage)]=sha(stage)
        path=out/f'settings-{planned}.json';path.write_text(json.dumps(settings,indent=2)+'\n');stages.append(settings)
    assert sum(s['sample_upper']for s in stages)<2000000
    (out/'before-curves-selection-rule.json').write_text(json.dumps({'primary':'same256000 training samples; fixed shared maximumtrain mask; compare best/LAST validation',
      'candidate':'min validation primary gameMSE among stage BEST; ties smaller positiveG, then earlier beststep; no test selection',
      'secondary_nonselection':master['secondary_nonselection'],'fixed_points':[0,1,2,5,10,20,50,100,200,400,800,1200,2000],
      'stages':[{'planned':s['planned_train_G'],'positive':s['positive_train_G'],'sample_upper':s['sample_upper']}for s in stages],
      'test_labels_read':False,'training_checkpoint_payload_scope':'private necessary small checkpoints within authorized data scope, archived to research Git; shared model directories unmodified'},indent=2)+'\n')
    print(json.dumps({'settings':str(out),'sample_upper':sum(s['sample_upper']for s in stages),'NN':0}))
