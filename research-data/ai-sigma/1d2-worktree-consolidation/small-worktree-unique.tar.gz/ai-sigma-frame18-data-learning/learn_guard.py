"""Owned CPU training/test guardian, with task cumulative counters and recovery."""
from pathlib import Path
import argparse,ctypes,datetime,hashlib,json,os,signal,subprocess,time
R=Path.cwd();D=R/'research-data/ai-sigma/frame18-data-learning';T=R/'tools/ai-sigma-frame18-data-learning'
p=argparse.ArgumentParser();p.add_argument('settings');a=p.parse_args();c=json.loads(Path(a.settings).read_text())
out=Path(c['guardian_out']);assert out.is_relative_to(D)and not out.exists();out.mkdir(parents=True)
os.sched_setaffinity(0,{2});ctypes.CDLL(None).prctl(36,1,0,0,0)
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
save=lambda n,x:(out/n).write_text(json.dumps(x,indent=2)+'\n')
def table():
    result={}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            z=(p/'stat').read_text().rsplit(')',1)[1].split()
            result[int(p.name)]=dict(pid=int(p.name),ppid=int(z[1]),tick=int(z[19]),state=z[0],RSS=int(z[21])*4096)
        except(OSError,ValueError):pass
    return result
for issue in ['quoridor-4lc','quoridor-4lc.228']:
    q=json.loads(subprocess.check_output(['bash','scripts/dev/beads.sh','show',issue,'--json'],text=True,timeout=10))[0]
    assert q['status']=='in_progress'and'paused-by-user'not in q.get('labels',[])
    if issue.endswith('.228'):assert q['assignee']=='codex:01a0f31d-6d15-7620-bb63-4b4f878e4746'
for f,h in c['sources'].items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
assert time.time()<datetime.datetime.fromisoformat(c['newscience_deadline'].replace('Z','+00:00')).timestamp()
sch=json.loads(Path('/workspaces/quoridor/.artifacts/research-team/scheduler-sigma-continuation-20261001/state.json').read_text())
assert sch['phase']=='running'and not sch.get('recovery_required')
# Natural owned turn is checked at the actual point, independently of LLM session count.
assert sch['owned']is None
quiet=sch['next_at']-time.time();assert quiet>=c['hard_s']+30
loaded=json.loads(Path(c['runtime_loaded']).read_text());monitor=Path(loaded['run'])/'monitor-observation.json'
assert time.time()-monitor.stat().st_mtime<120
assert loaded['parent_sha']==hashlib.sha256((R/'docs/design/ai-sigma-continuation-20261001.md').read_bytes()).hexdigest()
tab=table()
for role in ['scheduler','monitor']:
    z=loaded[role].get('process',loaded[role]);assert str(tab[z['pid']]['tick'])==str(z['start_ticks'])
foreign=[];rss=0
for pid,z in tab.items():
    if pid==os.getpid()or z['state']=='Z':continue
    try:args=Path(f'/proc/{pid}/cmdline').read_bytes().decode().split('\0')
    except(OSError,UnicodeError):continue
    script=next((s for s in args[1:5]if s.endswith(('.py','.cjs','.js'))and' 'not in s and Path(s).is_file()),'')
    if any(k in script for k in ['tools/ai-sigma-','tools/nnue-training/','research-data/ai-sigma/'])or'faithful-native'in args[0]:
        rss+=z['RSS'];foreign.append(dict(z,script=script))
assert not foreign,foreign
assert rss+6*1024**3<8*1024**3
gpu=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader'],text=True,timeout=5).strip();assert not gpu
prior=[json.loads(p.read_text())for p in(D/'learning-guardian').glob('*/process.json')]
assert sum(p['samples_charge']for p in prior)+c['sample_upper']<=2000000
assert sum(p['wall_s']for p in prior)+c['hard_s']<=900
current=sum(p.stat().st_size for root in[D,T]for p in root.rglob('*')if p.is_file())
assert current+128*1024**2+32*1024**2<448*1024**2
save('admission.json',dict(UTC=utc(),scheduler=sch,quiet_s=quiet,runtime_loaded=c['runtime_loaded'],monitor=str(monitor),foreign=[],GPU=[],current_RSS=rss,storage_current_B=current,allhost_guarantee=False))
env=os.environ.copy();env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',BLIS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',UV_NO_SYNC='1',UV_OFFLINE='1')
cmd=['/home/vscode/.cache/inference/envs/quoridor-training/bin/python','-B',str(T/c['entry']),'--settings',str(Path(a.settings).resolve())]
start=time.monotonic();startUTC=utc();tracked={};reason=None;peak=0
with(out/'stdout.txt').open('w')as f:
    child=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,start_new_session=True);tracked[child.pid]=table()[child.pid]['tick']
    def group():
        tab=table();members={p for p,t in tracked.items()if tab.get(p,{}).get('tick')==t};members|={p for p,z in tab.items()if z['ppid']==os.getpid()}
        while True:
            added={p for p,z in tab.items()if z['ppid']in members}
            if added<=members:break
            members|=added
        for p in members:
            if p in tab:tracked[p]=tab[p]['tick']
        return[tab[p]for p in members if p in tab]
    while child.poll()is None:
        members=group();peak=max(peak,sum(z['RSS']for z in members)+table()[os.getpid()]['RSS'])
        if peak>=5.5*1024**3:reason='RAM_GUARD'
        if time.monotonic()-start>=c['hard_s']or time.time()>=datetime.datetime.fromisoformat(c['stop_deadline'].replace('Z','+00:00')).timestamp():reason='TIME_GUARD'
        if (out/'PAUSE').exists():reason='PAUSED'
        if reason:
            for z in members:
                if z['state']!='Z':
                    try:os.kill(z['pid'],signal.SIGTERM)
                    except ProcessLookupError:pass
            break
        time.sleep(.1)
    try:code=child.wait(timeout=2)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=2)
    for z in group():
        if z['state']!='Z':
            try:os.kill(z['pid'],signal.SIGKILL)
            except ProcessLookupError:pass
    for _ in range(200):
        try:
            pid,_=os.waitpid(-1,os.WNOHANG)
            if pid==0:time.sleep(.005)
        except ChildProcessError:break
remaining=group();counter=Path(c['counter_file']);receipt=json.loads(counter.read_text())if counter.exists()else{}
samples=receipt.get('all_samples',receipt.get('samples'))
save('process.json',dict(UTC=utc(),startUTC=startUTC,endUTC=utc(),command=cmd,runner_pid=os.getpid(),runner_tick=table()[os.getpid()]['tick'],
 tracked=tracked,remaining=remaining,all_child_waited=not remaining,current_exact_absent=not remaining,wall_s=time.monotonic()-start,
 samples_actual=samples,samples_charge=samples if samples is not None else c['sample_upper'],original_unknown=samples is None,
 exit=code,reason=reason,peak_family_RSS=peak))
print(json.dumps({'exit':code,'reason':reason,'samples':samples,'wall_s':time.monotonic()-start,'allwait':not remaining}))
raise SystemExit(0 if code==0 and not reason and not remaining else 1)
