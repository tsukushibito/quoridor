"""Single frozen test pass. Test targets can be opened only after immutable freeze."""
from pathlib import Path
import argparse,collections,gzip,hashlib,json,sys,time
R=Path.cwd();sys.path.insert(0,str(R/'tools/nnue-training'))
p=argparse.ArgumentParser();p.add_argument('--settings',required=True);a=p.parse_args();settings=json.loads(Path(a.settings).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(settings['freeze'])==settings['freeze_SHA'];freeze=json.loads(Path(settings['freeze']).read_text());out=Path(settings['output']);assert not out.exists();out.mkdir()
for k,b in freeze['artifacts'].items():assert sha(b['path'])==b['SHA'],k
from frame14_data import read_rows
meta=read_rows(freeze['artifacts']['metadata']['path']);mask=json.loads(Path(freeze['artifacts']['mask']['path']).read_text())
rows=[r for r in meta if r['split']=='test'];assert len(rows)>0
ad=freeze['test_label_advertisement'];assert sha(ad['path'])==ad['sha256']
# The first test target decoding follows the verified candidate/selection/evaluator freeze.
labels=read_rows(ad['path']);assert all(r['split']=='test'for r in labels)
by={r['id']:r for r in labels};assert len(by)==len(labels)and set(by)=={r['id']for r in rows}
rows=[dict(r,rootmean=by[r['id']]['rootmean'],z=by[r['id']]['z'],primary_eligible=mask['rows'][r['id']]['primary_eligible'])for r in rows]
import torch
torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
from model import inputs
from scaled_model import ScaleModel
from common import measurements
from learning_plan import distance_prediction
config=json.loads(Path(freeze['artifacts']['config']['path']).read_text());baseline=json.loads(Path(freeze['artifacts']['baseline']['path']).read_text())['fit']
tensor_inputs=inputs(rows);pred={};samples=0;reused={};tensor_hashes={}
for name in freeze['models']:
    cp=torch.load(freeze['artifacts'][name]['path'],map_location='cpu',weights_only=True)
    h=hashlib.sha256(b''.join(v.numpy().tobytes()for v in cp['model'].values())).hexdigest();tensor_hashes[name]=h
    old=next((k for k,v in tensor_hashes.items()if k!=name and v==h),None)
    if old:pred[name]=pred[old];reused[name]=old;continue
    mdl=ScaleModel(config['model']);mdl.load_state_dict(cp['model']);mdl.train_step=-1;mdl.eval();values=[]
    with torch.inference_mode():
        for b in range(0,len(rows),1024):
            stop=min(b+1024,len(rows));values.extend(mdl(*(v[b:stop]for v in tensor_inputs)).tolist());samples+=stop-b
            assert samples<=settings['sample_upper']
    pred[name]=values
pred['distance']=[distance_prediction(r,baseline)for r in rows];pred['constant']=[baseline['constant']]*len(rows)
eligible=[i for i,r in enumerate(rows)if r['primary_eligible']]
result={'samples':samples,'models_unique_NN':len(freeze['models'])-len(reused),'prediction_reused':reused,
        'freeze_SHA':settings['freeze_SHA'],'planned_test_games':96,'actual_test_games':len({r['group']for r in rows}),
        'all_rows':len(rows),'primary_rows':len(eligible),'excluded_rows':len(rows)-len(eligible),
        'zero_eligible_games':sorted(g for g,z in mask['games'].items()if z['split']=='test'and not z['eligible']),
        'primary':{},'secondary_all':{},'pergame':{},'tensor_SHA':tensor_hashes,'test_reselection':False,'oldtest_read':False,'strength_claim':False}
for name,values in pred.items():
    result['primary'][name]=measurements([rows[i]for i in eligible],[values[i]for i in eligible],'rootmean',baseline['constant'])
    result['secondary_all'][name]=measurements(rows,values,'rootmean',baseline['constant'])
    result['pergame'][name]={g:measurements([r for r in rows if r['group']==g and r['primary_eligible']],
        [v for r,v in zip(rows,values)if r['group']==g and r['primary_eligible']],'rootmean',baseline['constant'])for g in sorted({r['group']for r in rows})}
with gzip.open(out/'per-row-predictions.jsonl.gz','wt')as f:
    for i,r in enumerate(rows):f.write(json.dumps({'id':r['id'],'group':r['group'],'primary_eligible':r['primary_eligible'],'predictions':{k:v[i]for k,v in pred.items()}})+'\n')
(out/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'samples':samples,'primary':result['primary'],'zero_eligible_games':result['zero_eligible_games']}))
