"""Validation-only immutable candidate/evaluator freeze, before sealed target access."""
from pathlib import Path
import argparse,hashlib,json
R=Path.cwd();D=R/'research-data/ai-sigma/frame18-data-learning';T=R/'tools/ai-sigma-frame18-data-learning'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=D/'candidate-freeze-v1.json';assert not out.exists()
plan=D/'learning-plan-v1';candidates=[]
for planned in[192,576]:
    settings=json.loads((plan/f'settings-{planned}.json').read_text());run=Path(settings['output'])/settings['run_id'];stop=Path(settings['guardian_out'])/'process.json'
    if not stop.exists():continue
    pr=json.loads(stop.read_text());assert pr['all_child_waited']and pr['current_exact_absent']
    summary=json.loads((run/'summary.json').read_text())
    if pr['exit']!=0 or summary['status']!='max_steps':continue
    candidates.append((summary['best_validation_mse'],settings['positive_train_G'],summary['best_step'],settings))
assert candidates,'NO_SUCCESSFUL_LEARNING_CANDIDATE'
score,G,step,s=min(candidates,key=lambda x:x[:3]);weights=Path(s['checkpoints'])/s['run_id']
paths={'candidate':weights/'best.pt','initial':weights/'initial.pt','config':Path(s['config']),
       'selection':plan/'before-curves-selection-rule.json','baseline':plan/f'baseline-{s["planned_train_G"]}.json',
       'mask':D/'dataset-v1/adapter/fixed-maximum-mask.json','metadata':D/'dataset-v1/adapter/canonical.jsonl.gz',
       'quantity':D/'dataset-v1/quantity-freeze.json','learning_stop':Path(s['guardian_out'])/'process.json',
       'evaluator':T/'test.py','scaled_model':T/'scaled_model.py','shared_model':R/'tools/nnue-training/model.py'}
ad=json.loads((D/'dataset-v1/plan.json').read_text())['sealed_test_advertised']
f={'UTC':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'candidate_stage':s['planned_train_G'],
   'candidate_positive_G':G,'candidate_step':step,'validation_primary_gameMSE':score,
   'artifacts':{k:{'path':str(p),'SHA':sha(p)}for k,p in paths.items()},'test_label_advertisement':ad,
   'test_labels_values_read_for_selection':False,'selection_rule':'minimum stage BEST validation gameMSE, tie smaller positiveG then earlier step',
   'planned_test_games':96,'models':['candidate','initial'],'baseline':['selected-stage train-only distance','selected-stage train-only constant'],
   'oldtest_read':False,'strength_claim':False}
out.write_text(json.dumps(f,indent=2)+'\n')
testout=D/'test-evaluation-r1';sources={str(T/'test.py'):sha(T/'test.py'),str(T/'scaled_model.py'):sha(T/'scaled_model.py'),str(out):sha(out)}
settings=dict(freeze=str(out),freeze_SHA=sha(out),output=str(testout),sources=sources,guardian_out=str(D/'learning-guardian/test-r1'),
    entry='test.py',hard_s=300,sample_upper=20000,counter_file=str(testout/'result.json'),
    newscience_deadline='2026-10-04T14:05:00Z',stop_deadline='2026-10-04T14:15:00Z',runtime_loaded=s['runtime_loaded'])
(D/'test-settings-r1.json').write_text(json.dumps(settings,indent=2)+'\n')
print(json.dumps({'candidate_stage':s['planned_train_G'],'step':step,'freeze_SHA':sha(out),'sealed_label_hash_recomputed':False}))
