import pathlib,json,hashlib,sys,datetime
O=pathlib.Path(__file__).resolve().parent
old=json.loads(pathlib.Path('.artifacts/ai-sigma/analysis/SIGMA-MATCH-HYPOTHESES/input-before.json').read_text());expected={x['path']:x['sha256']for x in old}
names=['.artifacts/ai-sigma/analysis/SIGMA-MATCH-HYPOTHESES/'+f for f in ['request-records.json','analysis.json','matched-records.json','manifest.json']]
names+=['.artifacts/ai-sigma/runs/SIGMA-RULE-FEATURE-PARITY/final-source/crates/quoridor-ai/src/lib.rs','.artifacts/ai-sigma/reference/SIGMA-WEB-REFERENCE/mcts_worker.original.js','.artifacts/ai-sigma/reference/SIGMA-WEB-REFERENCE/game.js']
names+=['.artifacts/ai-sigma/runs/SIGMA-PAIRED-MATCHES/execution-SIGMA-P32-V2-R3-01/'+f for f in ['judge-ply.jsonl','all-ply.jsonl','results.jsonl']]
names+=['.artifacts/ai-sigma/runs/SIGMA-PAIRED-MATCHES/revision3/source-final/'+f for f in ['game.js','context.js','judge.cjs','Cargo.lock','src/main.rs']]
names+=['AGENTS.md','.agents/research-team/common.md','.agents/research-team/roles/hypothesis.md','.agents/research-team/templates/handoff.md','.devcontainer/storage-policy.md','docs/design/ai-sigma-research-goal.md','docs/design/ai-sigma-contract-hypothesis-root-ablation.md','docs/design/ai-research-team.md','docs/design/ai-sigma-comparison-protocol.md','docs/design/quoridor-3d-webapp-design-rust-wasm-v1.md','docs/reports/ai-sigma-hypothesis-match-analysis.md','docs/reports/ai-sigma-coordinator-match-hypotheses-review.md']
oldmanifest=json.loads(pathlib.Path('.artifacts/ai-sigma/analysis/SIGMA-MATCH-HYPOTHESES/manifest.json').read_text())
for name in ['request-records.json','analysis.json','matched-records.json']:expected[str(pathlib.Path('.artifacts/ai-sigma/analysis/SIGMA-MATCH-HYPOTHESES/'+name).resolve())]=oldmanifest['files'][name]['sha256']
expected[str(pathlib.Path('docs/reports/ai-sigma-hypothesis-match-analysis.md').resolve())]='2f50be3549581c51999a61d51376c1a4ddd2e296b86f2fa613be5fd138698610'
out=[]
for name in names:
 p=pathlib.Path(name);h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(1024**2):h.update(b)
 e=expected.get(str(p.resolve()));assert e is None or e==h.hexdigest(),name
 out.append({'path':str(p.resolve()),'sha256':h.hexdigest(),'bytes':p.stat().st_size,'previous_accepted_sha256':e})
result={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':out,'phase':sys.argv[1],'provenance_note':'First export/compile/baseline ran before this local hash ledger; previously accepted pinned hashes are also checked. Final diagnostic rerun occurs after before ledger. Do not claim initial read was preceded by local hash capture.'}
(O/('input-'+sys.argv[1]+'.json')).write_text(json.dumps(result,indent=2))
if sys.argv[1]=='after':assert out==json.loads((O/'input-before.json').read_text())['files']
print('hashes',len(out),'phase',sys.argv[1],'all accepted expectations and phase hashes agree')
