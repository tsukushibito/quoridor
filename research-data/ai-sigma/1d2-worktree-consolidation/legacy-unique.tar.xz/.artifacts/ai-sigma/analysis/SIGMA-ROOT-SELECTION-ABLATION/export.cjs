const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const O=__dirname,B=path.resolve('.artifacts/ai-sigma/runs/SIGMA-PAIRED-MATCHES'),J=require(path.join(B,'revision3/source-final/judge.cjs'));
const records=JSON.parse(fs.readFileSync('.artifacts/ai-sigma/analysis/SIGMA-MATCH-HYPOTHESES/request-records.json'));
const R=new Map(records.map(r=>[r.game+':'+r.ply,r]));const roots=[],states=new Map(),prefixes=new Map();
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
for(const line of fs.readFileSync(path.join(B,'execution-SIGMA-P32-V2-R3-01/judge-ply.jsonl'),'utf8').trim().split('\n')){
 const d=JSON.parse(line),r=d.response;let s=states.get(d.game);if(!s){s=J.state(d.prefix);prefixes.set(d.game,d.prefix.slice());}
 if(hash(prefixes.get(d.game))!==hash(d.prefix))throw Error('prefix progression');
 const row=R.get(d.game+':'+d.ply);if(row.prefix_key!==hash(d.prefix))throw Error('old record prefix');
 const p=r.raw?.payload,dat=d.engine==='native'?p?.data:p?.payload?.data,cp=dat?.checkpoint;
 if(row.root_edges){if(JSON.stringify(cp?.root_edges)!==JSON.stringify(row.root_edges)||cp.action!==row.action)throw Error('edge/Action mismatch');
  const refOrder=s.getLegalActions().map(a=>J.rustAction(s,a)),actions=cp.root_edges.map(e=>e[0]);
  if(refOrder.length!==actions.length||new Set(actions).size!==actions.length||actions.some(a=>!refOrder.includes(a)))throw Error('legal edges');
  roots.push({id:d.game+':'+d.ply,game:d.game,ply:d.ply,engine:row.engine,accepted:r.accepted,private_late:!r.accepted&&r.late,expected_action:cp.action,seed:r.request.seed,simulations:cp.simulations,parentQ:null,root_edges:cp.root_edges,reference_legal_order:refOrder});
 }
 if(r.accepted){const a=J.validate(d.prefix,r.action);s=s.next(a);prefixes.get(d.game).push(a)}states.set(d.game,s);
}
if(roots.length!==765)throw Error('denominator');
fs.writeFileSync(path.join(O,'roots.json'),JSON.stringify(roots));console.log(JSON.stringify({roots:roots.length,native:roots.filter(r=>r.engine==='native').length,wasm:roots.filter(r=>r.engine==='wasm').length,accepted:roots.filter(r=>r.accepted).length,private_late:roots.filter(r=>r.private_late).map(r=>r.id),missing:1,parentQ_available:0,NN:0}));
