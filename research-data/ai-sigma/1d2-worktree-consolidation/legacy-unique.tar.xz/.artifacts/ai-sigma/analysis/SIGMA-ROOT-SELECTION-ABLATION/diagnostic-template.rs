use std::{fs,env};
#[derive(Clone)]struct Edge{action:u16,prior:f32,visits:u32,value_sum:f32,rank:u32}
struct Root{id:String,synthetic:bool,seed:u64,expected:u16,n:u32,parent:Option<f32>,edges:Vec<Edge>}
/*ORIGINAL_TIE*/
fn finish(edges:&[Edge],seed:u64,mode:u8,ref_order:bool)->u16{
 let mut es:Vec<&Edge>=edges.iter().collect();if ref_order{es.sort_by_key(|e|e.rank)}
 if mode==0{return es.into_iter().max_by(|a,b|a.visits.cmp(&b.visits).then_with(||a.prior.total_cmp(&b.prior)).then_with(||tie(seed,b.action).cmp(&tie(seed,a.action)))).unwrap().action}
 let mut best=es[0];for e in es.into_iter().skip(1){let ord=e.visits.cmp(&best.visits);let better=if ord.is_eq(){match mode{1=>e.prior.total_cmp(&best.prior).is_gt(),2=>tie(seed,e.action)<tie(seed,best.action),3=>false,_=>panic!()}}else{ord.is_gt()};if better{best=e}}best.action
}
fn select(r:&Root,c:f32,plus:bool,first:bool,fpu:bool,ref_order:bool)->(u16,f32,f32,u32,u32,u32){
 let root=(r.n as f32+if plus{1.0}else{0.0}).sqrt();let visited=r.edges.iter().filter(|e|e.visits>0).fold(0f32,|v,e|v+e.prior);
 let mut es:Vec<&Edge>=r.edges.iter().collect();if ref_order{es.sort_by_key(|e|e.rank)}
 let mut scores=Vec::new();let mut best=0usize;let mut best_score=f32::NEG_INFINITY;
 for(i,e)in es.iter().enumerate(){let q=if e.visits==0{if fpu{r.parent.expect("artificial parent required")-0.2*visited.sqrt()}else{0.0}}else{e.value_sum/e.visits as f32};
 let score=q+c*e.prior*root/(e.visits+1)as f32;assert!(score.is_finite());scores.push(score);
 if score>best_score||(score==best_score&&!first&&tie(r.seed,e.action)<tie(r.seed,es[best].action)){best=i;best_score=score}}
 let second=scores.iter().enumerate().filter(|(i,_)|*i!=best).map(|(_,x)|*x).fold(f32::NEG_INFINITY,f32::max);
 let equal=scores.iter().filter(|x|**x==best_score).count()as u32;let near=scores.iter().filter(|x|(best_score-**x).abs()<=1e-6).count()as u32;
 (es[best].action,best_score,best_score-second,equal,near,es[best].visits)
}
fn next<T:std::str::FromStr>(t:&mut std::str::SplitWhitespace)->T{t.next().unwrap().parse().ok().unwrap()}
fn main(){let arg:Vec<String>=env::args().collect();let input=fs::read_to_string(&arg[1]).unwrap();let mut t=input.split_whitespace();let count:usize=next(&mut t);let mut rs=Vec::new();
 for _ in 0..count{let id=t.next().unwrap().to_owned();let synthetic=next::<u8>(&mut t)!=0;let seed=next(&mut t);let expected=next(&mut t);let n=next(&mut t);let parent_known=next::<u8>(&mut t)!=0;let parent_bits=next(&mut t);let len:usize=next(&mut t);let mut edges=Vec::new();
  for _ in 0..len{let action=next(&mut t);let prior=f32::from_bits(next(&mut t));let visits=next(&mut t);let value_sum=f32::from_bits(next(&mut t));let rank=next(&mut t);assert!(prior.is_finite()&&value_sum.is_finite());edges.push(Edge{action,prior,visits,value_sum,rank})}
  assert_eq!(edges.iter().map(|e|e.visits).sum::<u32>(),n);rs.push(Root{id,synthetic,seed,expected,n,parent:parent_known.then(||f32::from_bits(parent_bits)),edges})
 }
 let mut gate=0;for r in &rs{if !r.synthetic{let a=finish(&r.edges,r.seed,0,false);if a!=r.expected{eprintln!("FINISH_GATE {} {} {}",r.id,a,r.expected);gate+=1}}}assert_eq!(gate,0,"baseline finish must pass before ablation");
 println!("id\tkind\taction\tscore_bits\tmargin_bits\texact_ties\tnear_ties\tchosen_visits");
 for r in &rs{
  for(kind,c,plus,first,ref_order,fpu)in [("select_base",1.5,true,false,false,false),("select_C1",1.,true,false,false,false),("select_sqrtN",1.5,false,false,false,false),("select_score_first",1.5,true,true,false,false),("select_score_first_reforder",1.5,true,true,true,false)]{
   let(a,s,m,e,n,v)=select(r,c,plus,first,fpu,ref_order);println!("{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",r.id,kind,a,s.to_bits(),m.to_bits(),e,n,v);
  }
  if r.synthetic{let(a,s,m,e,n,v)=select(r,1.5,true,false,true,false);println!("{}\tselect_FPU_only\t{}\t{}\t{}\t{}\t{}\t{}",r.id,a,s.to_bits(),m.to_bits(),e,n,v)}
  for(kind,mode,order)in [("finish_base",0,false),("finish_prior_first",1,false),("finish_seed",2,false),("finish_first",3,false),("finish_prior_first_reforder",1,true),("finish_first_reforder",3,true)]{println!("{}\t{}\t{}\t0\t0\t0\t0\t0",r.id,kind,finish(&r.edges,r.seed,mode,order))}
 }
 eprintln!("FINISH_GATE_OK measured={} artificial={} NN=0 MCTS=0",rs.iter().filter(|r|!r.synthetic).count(),rs.iter().filter(|r|r.synthetic).count());
}
