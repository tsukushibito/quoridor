import pathlib,json,struct,statistics,collections,difflib,math
O=pathlib.Path(__file__).resolve().parent
roots=json.loads((O/'roots.json').read_text());oracle=json.loads((O/'oracles.json').read_text())['roots'];byid={r['id']:r for r in roots+oracle}
rows={}
def f32(b):return struct.unpack('<f',struct.pack('<I',int(b)))[0]
for line in (O/'diagnostic-final.log').read_text().splitlines()[1:]:
 if line.startswith('FINISH_GATE'):continue
 rid,kind,action,score,margin,ties,near,visits=line.split('\t');rows[rid,kind]={'action':int(action),'score':f32(score),'score_bits':int(score),'margin':f32(margin) if math.isfinite(f32(margin)) else None,'margin_bits':int(margin),'exact_ties':int(ties),'near_ties':int(near),'chosen_visits':int(visits)}
assert all(rows[r['id'],'finish_base']['action']==r['expected_action']for r in roots)
matched=[m for m in json.loads(pathlib.Path('.artifacts/ai-sigma/analysis/SIGMA-MATCH-HYPOTHESES/matched-records.json').read_text())if m['comparison']=='native-wasm'];assert len(matched)==97
matched_ids={str(g)+':'+str(p)for m in matched for g,p in [m['A'],m['B']]};assert len(matched_ids)==194
contrasts=[
 ('C_only','select_base','select_C1'),('sqrt_only_contract_N','select_base','select_sqrtN'),('score_tie_only_candidate_order','select_base','select_score_first'),
 ('score_order_only_given_first','select_score_first','select_score_first_reforder'),
 ('finish_seed_to_first_given_prior','finish_base','finish_prior_first'),('finish_remove_prior_given_seed','finish_base','finish_seed'),
 ('finish_seed_to_first_given_no_prior','finish_seed','finish_first'),('finish_remove_prior_given_first','finish_prior_first','finish_first'),
 ('finish_order_only_given_prior_first','finish_prior_first','finish_prior_first_reforder'),('finish_order_only_given_visits_first','finish_first','finish_first_reforder')]
def stats(v):
 total=len(v);v=[x for x in v if x is not None and math.isfinite(x)];return {'n':len(v),'missing_single_edge_or_nonfinite':total-len(v),'median':statistics.median(v)if v else None,'min':min(v)if v else None,'max':max(v)if v else None}
groups={'all765':roots,'accepted764':[r for r in roots if r['accepted']],'private_late1':[r for r in roots if r['private_late']],'native371':[r for r in roots if r['engine']=='native'],'wasm394':[r for r in roots if r['engine']=='wasm'],'matched97pairs_194roots':[r for r in roots if r['id']in matched_ids],'matched_native97':[r for r in roots if r['id']in matched_ids and r['engine']=='native'],'matched_wasm97':[r for r in roots if r['id']in matched_ids and r['engine']=='wasm'],'synthetic8':oracle}
out={};detail=[]
for name,rs in groups.items():
 d={'denominator':len(rs),'contrasts':{},'select_metrics':{}}
 for cname,base,var in contrasts:
  changed=[r for r in rs if rows[r['id'],base]['action']!=rows[r['id'],var]['action']]
  z={'changed_argmax':len(changed),'denominator':len(rs),'base':base,'variant':var,'changed_ids':[r['id']for r in changed]}
  if base.startswith('select'):
   z['max_score_difference_variant_minus_base']=stats([rows[r['id'],var]['score']-rows[r['id'],base]['score']for r in rs]);z['unvisited_base']=sum(rows[r['id'],base]['chosen_visits']==0 for r in rs);z['unvisited_variant']=sum(rows[r['id'],var]['chosen_visits']==0 for r in rs)
  d['contrasts'][cname]=z
 for kind in ['select_base','select_C1','select_sqrtN','select_score_first','select_score_first_reforder']:
  d['select_metrics'][kind]={'margin':stats([rows[r['id'],kind]['margin']for r in rs]),'exact_score_tied_roots':sum(rows[r['id'],kind]['exact_ties']>1 for r in rs),'near_tied_roots_abs1e_6':sum(rows[r['id'],kind]['near_ties']>1 for r in rs),'unvisited_selected':sum(rows[r['id'],kind]['chosen_visits']==0 for r in rs)}
 d['finish_top_visit_tied']=sum(sum(e[2]==max(x[2]for x in r['root_edges'])for e in r['root_edges'])>1 for r in rs)
 out[name]=d
for r in roots+oracle:
 for key,z in rows.items():
  if key[0]==r['id']:detail.append({'id':r['id'],'kind':key[1],'synthetic':r.get('synthetic',False),'engine':r.get('engine'),'accepted':r.get('accepted'),**z})
pair_agreement={kind:sum(rows[f"{m['A'][0]}:{m['A'][1]}",kind]['action']==rows[f"{m['B'][0]}:{m['B'][1]}",kind]['action']for m in matched)for kind in ['select_base','select_C1','select_sqrtN','select_score_first','select_score_first_reforder','finish_base','finish_prior_first','finish_seed','finish_first','finish_prior_first_reforder','finish_first_reforder']}
summary={'experiment':'SIGMA-ROOT-SELECTION-ABLATION','issue':'quoridor-4lc.28','gate':{'original_finish_exact_matches':765,'mismatches':0,'accepted':764,'private_late':1,'noresponse_missing':1,'prior_value_f32_roundtrip_exact':True,'legal_actions_exact_set_and_reference_order_replayed':True,'sum_edge_visits_equals_sim_minus1':765,'parentQ_raw_observed':0},'groups':out,'matched97_pair_action_agreement':pair_agreement,'artificial_FPU':json.loads((O/'precision-and-FPU.json').read_text())['oracles'],'meaning':['Only one frozen snapshot next-select/finish; no tree update/NN/backup/fullMCTS/counterfactualgame.','N=sumedgevisits required by contract. Original node.visits includes root evaluation (sumedge+1 in these roots); original select sqrt(node.visits+1) thus uses another unit. ContractN diagnostic is not actual original next selection.','Actual baseline select not logged, reference rootedges/PV and actualparentQ absent.','First candidate order and first replayed reference legal order are separate controlled factors.','Finish visits-only-first removes bothprior andseed from original; it is not labeled a one-factor contrast. Nested one-factor contrasts separately reported.','Score differences are arithmetic argmax diagnostics, not value improvement; near tie abs1e-6 defined before results.','No effect on finalsnapshot does not refute allH2; any changedargmax is not strength/adoption/NI evidence.'],'baseline_next_select_observed':False,'NN_fullMCTS_games_download_GPUTRAIN_delegation':0,'precision':json.loads((O/'precision-and-FPU.json').read_text())}
(O/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False));(O/'detailed-results.json').write_text(json.dumps(detail,separators=(',',':'),allow_nan=False))
original=(O/'select-original.rs.txt').read_text();adapted=(O/'diagnostic.rs').read_text();(O/'source-adapter.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),adapted.splitlines(True),fromfile='fixed-original-select-function',tofile='std-only-diagnostic-all-functions')))
print(json.dumps({'gate':summary['gate'],'all_changes':{k:v['changed_argmax']for k,v in out['all765']['contrasts'].items()},'accepted_changes':{k:v['changed_argmax']for k,v in out['accepted764']['contrasts'].items()},'matched_changes':{k:v['changed_argmax']for k,v in out['matched97pairs_194roots']['contrasts'].items()},'all_select_metrics':out['all765']['select_metrics'],'pair_agreement':pair_agreement,'FPU':summary['artificial_FPU']},indent=2))
