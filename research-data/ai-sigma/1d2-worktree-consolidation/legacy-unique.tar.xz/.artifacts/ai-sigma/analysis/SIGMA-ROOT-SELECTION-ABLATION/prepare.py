import pathlib,json,hashlib,struct,difflib,datetime
O=pathlib.Path(__file__).resolve().parent
K=pathlib.Path('.artifacts/ai-sigma/runs/SIGMA-RULE-FEATURE-PARITY/final-source/crates/quoridor-ai/src/lib.rs')
s=K.read_text();assert hashlib.sha256(K.read_bytes()).hexdigest()=='5ab5eca5c23814dbaa0162b25e8fe710e58cdb7139c0fa4e3e2f794dc041555a'
def function(src,start):
 i=src.index(start);beg=src.index('{',i);level=1;j=beg+1
 while level:
  level+=(src[j]=='{')-(src[j]=='}');j+=1
 return src[i:j]
tie=function(s,'fn tie(');sel=function(s,'fn select(');fin=function(s,'pub fn finish(')
for name,txt in [('tie',tie),('select',sel),('finish',fin)]: (O/(name+'-original.rs.txt')).write_text(txt)
def bits(v):return struct.unpack('<I',struct.pack('<f',v))[0]
def f32(v):return struct.unpack('<f',struct.pack('<f',v))[0]
oracles=[
 ('equal-score-order',0.,[[13,.5,1,0.],[5,.5,1,0.]], [5,13]),
 ('zero-visits',0.,[[81,.6,0,0.],[13,.4,0,0.]], [13,81]),
 ('signed-zero-prior',0.,[[13,-0.,0,-0.],[81,0.,0,0.]], [81,13]),
 ('near-score',0.,[[13,0.,1,.25],[5,0.,1,.25000003]], [5,13]),
 ('negative-value',-.4,[[3,.9,4,-3.6],[13,.1,0,0.]], [13,3]),
 ('positive-parent-FPU',.8,[[3,.7,4,2.8],[13,.3,0,0.]], [3,13]),
 ('negative-parent-FPU',-.8,[[3,.7,4,1.2],[13,.3,0,0.]], [3,13]),
 ('all-visited',.6,[[13,.5,2,-.4],[5,.5,3,-.6]], [5,13])]
oracle=[]
for name,p,edges,order in oracles:
 oracle.append({'id':'oracle-'+name,'synthetic':True,'seed':1979,'parentQ':f32(p),'root_edges':[[a,f32(pr),v,f32(val)]for a,pr,v,val in edges],'reference_legal_order':order,'order_note':'Artificial explicit order, not a legally replayed Sigma board','N':sum(e[2]for e in edges)})
(O/'oracles.json').write_text(json.dumps({'fixed_before_results_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'near_tie_abs_threshold':1e-6,'roots':oracle},indent=2))
roots=json.loads((O/'roots.json').read_text());lines=[str(len(roots)+len(oracle))]
for r in roots+oracle:
 edges=r['root_edges'];n=sum(e[2]for e in edges)
 if not r.get('synthetic'):assert n==r['simulations']-1
 parent=r['parentQ'];lines.append(f"{r['id']} {int(r.get('synthetic',False))} {r['seed']} {r.get('expected_action',0)} {n} {int(parent is not None)} {bits(parent or 0.)} {len(edges)}")
 for action,prior,visits,value in edges:
  assert f32(prior)==prior and f32(value)==value
  rank=r['reference_legal_order'].index(action);lines.append(f'{action} {bits(prior)} {visits} {bits(value)} {rank}')
(O/'roots-input.txt').write_text('\n'.join(lines)+'\n')
template=(O/'diagnostic-template.rs').read_text();rust=template.replace('/*ORIGINAL_TIE*/',tie)
(O/'diagnostic.rs').write_text(rust)
(O/'source-adapter.json').write_text(json.dumps({'kernel_sha256':hashlib.sha256(K.read_bytes()).hexdigest(),'tie_function_verbatim':True,'finish_comparator_verbatim':'visits.cmp.then(prior.total_cmp).then(tie(seed,b.action).cmp(tie(seed,a.action)))','select_adapter':'Node replaced with immutable edge slice; contract N=sum(edge.visits), C/sqrt/tie supplied one at a time. Original node.visits generally includes root evaluation; contract N substitution is not a recovered actual next selection.','parentQ_raw_missing':True,'synthetic_FPU_only':True,'precision':'Rustf32 native; rootedge bits retained; JSf32 check separate from SigmaNumber oracle'},indent=2))
print('fixed roots',len(roots),'oracle',len(oracle),'std-only source generated')
