import subprocess,os,sys,time,json,pathlib,datetime,signal,resource
O=pathlib.Path(__file__).resolve().parent
C=pathlib.Path('/home/vscode/.cache/inference/research/ai-sigma/root-ablation')
name=sys.argv[1]; cmd=sys.argv[2:]; budget=120 if name=='compile' else 45
if datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat('2026-10-01T01:22:00+00:00'):raise SystemExit('new job deadline')
env=dict(os.environ,TMPDIR=str(C/'tmp'),XDG_CACHE_HOME=str(C/'xdg'),PYTHONDONTWRITEBYTECODE='1')
start=time.monotonic();log=(O/(name+'.log')).open('w');p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
ticks=None; samples=[];why=None;peak=0;tracked={}
while p.poll() is None:
 try:
  rss=0;affinities=[]
  for proc in pathlib.Path('/proc').iterdir():
   if not proc.name.isdigit():continue
   try:
    stat=(proc/'stat').read_text().split(') ')[1].split()
    if int(stat[2])!=p.pid:continue
    pid=int(proc.name);tracked[pid]=stat[19]
    if pid==p.pid:ticks=stat[19]
    rss+=int(stat[21])*os.sysconf('SC_PAGE_SIZE')
    affinities.extend(sorted(os.sched_getaffinity(int(t.name))) for t in (proc/'task').iterdir())
   except (FileNotFoundError,ProcessLookupError):pass
  peak=max(peak,rss)
  size=sum(f.stat().st_size for root in [O,C] for f in root.rglob('*') if f.is_file())
  samples.append({'dt':time.monotonic()-start,'rss':rss,'TID_affinity':affinities,'storage':size})
  if rss>939524096:why='RSS_GUARD'
  if size>29360128:why='STORAGE_GUARD'
  if any(a!=[0] for a in affinities):why='AFFINITY_GUARD'
 except FileNotFoundError:pass
 if time.monotonic()-start>budget:why='TIMEOUT'
 if why:os.killpg(p.pid,signal.SIGTERM);break
 time.sleep(.05)
try:p.wait(timeout=2)
except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
log.close();r=resource.getrusage(resource.RUSAGE_CHILDREN);live=[]
for pid,t in tracked.items():
 try:
  if pathlib.Path(f'/proc/{pid}/stat').read_text().split(') ')[1].split()[19]==t:live.append(pid)
 except FileNotFoundError:pass
assert not live, live
(O/(name+'.process.json')).write_text(json.dumps({'command':cmd,'UTC_end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'PID':p.pid,'start_ticks':ticks,'exit':p.returncode,'stop_reason':why,'tracked_PID_start_ticks':tracked,'samples':samples,'sampled_RSS_peak':peak,'ru_maxrss_bytes':r.ru_maxrss*1024,'CPU_seconds':r.ru_utime+r.ru_stime,'known_children_alive':0,'waited':True,'TMPDIR':str(C/'tmp'),'XDG_CACHE_HOME':str(C/'xdg'),'instantaneous_peak_not_guaranteed':True},indent=2))
print(name,p.returncode,why,'peak',peak,'CPU',r.ru_utime+r.ru_stime)
sys.exit(p.returncode or (1 if why else 0))
