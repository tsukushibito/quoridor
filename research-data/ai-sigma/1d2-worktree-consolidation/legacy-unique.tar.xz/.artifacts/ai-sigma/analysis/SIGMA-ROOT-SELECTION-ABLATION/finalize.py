import pathlib,json,datetime,os,hashlib,math
O=pathlib.Path(__file__).resolve().parent;C=pathlib.Path('/home/vscode/.cache/inference/research/ai-sigma/root-ablation')
def strict(name):return json.loads((O/name).read_text(),parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
s=strict('summary.json');d=strict('detailed-results.json');r=strict('roots.json');precision=strict('precision-and-FPU.json')
assert s['gate']['original_finish_exact_matches']==765 and s['gate']['mismatches']==0
assert len(r)==765 and len(d)==773*11+8
assert not precision['errors'] and precision['Rust_JSf32_checked']==3873
assert all(x['seed']==1979 for x in r)
assert sum(len(x['root_edges'])==1 for x in r)==3
assert all(x['margin']is not None or len(next(y['root_edges']for y in r+strict('oracles.json')['roots']if y['id']==x['id']))==1 for x in d if x['kind'].startswith('select'))
assert sum(x['id']=='5:34' and x['private_late']for x in r)==1
jobs=[json.loads(p.read_text())for p in O.glob('*.process.json')];live=[]
for job in jobs:
 for pid,t in job.get('tracked_PID_start_ticks',{}).items():
  try:
   if pathlib.Path('/proc',pid,'stat').read_text().split(') ')[1].split()[19]==t:live.append(pid)
  except FileNotFoundError:pass
assert not live
size=sum(p.stat().st_size for root in [O,C]for p in root.rglob('*')if p.is_file());assert size<29360128
stopped={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'issue':'quoridor-4lc.28','own_runtime_PID_count':0,'live_tracked':live,'all_child_groups_exited_waited':True,'jobs':[{'cmd':j['command'],'PID':j['PID'],'start_ticks':j['start_ticks'],'tracked':j.get('tracked_PID_start_ticks',{}),'exit':j['exit'],'stop_reason':j['stop_reason']}for j in jobs],'CPU_seconds_supervised_sum':sum(j['CPU_seconds']for j in jobs),'sampled_group_RSS_peak':max(j['sampled_RSS_peak']for j in jobs),'conservative_with_supervisor32MiB':max(j['sampled_RSS_peak']for j in jobs)+32*1024**2,'storage_logical_bytes_at_stop':size,'remaining_32MiB_at_stop':33554432-size,'RAM_guard':939524096,'storage_guard':29360128,'compile_count':1,'NN_fullMCTS_games_download_dependency_GPU_training_delegation':0,'tracked_observed_all_TID_CPU0':all(all(a==[0]for a in sample['TID_affinity'])for j in jobs for sample in j['samples']),'private_TMP_real':str((C/'tmp').resolve()),'private_XDG_real':str((C/'xdg').resolve()),'temp_files':[str(p)for p in(C/'tmp').rglob('*')if p.is_file()],'limitations':['50ms samples miss very short PIDs/TIDs/instantaneousRSS; peak0 for very short job is not actualzero.','Initial bounded source/Beads reads before supervision not sampled; no complete lifetimeRSS claim.','First baseline preceded local hash ledger; accepted pinned input expectations checked, final rerun bracketed by localbefore/after.','RSS sums shared pages conservatively; helper/compiler descendants sampled PGID, inheritedCPU0; observed window only.','CPU rusage covers supervised children, not all initialreads/wrappers/parent monitor cost. Concurrent .26; no performance claim.'],'retained_failures':['DerivedmarginInfinity on3 singleedge roots encodednull after one correction; originalsource/summary retained.','Past .27 schema/character guards and all historical deadline/RSS/TMP/affinity/provenance/clock/deep/legal200/no-legal/entropy/license limits preserved.'],'other_kills_deletions':0,'report_not_yet_generated':True,'research_processing_stopped':True}
(O/'runtime-stopped.json').write_text(json.dumps(stopped,indent=2));print(json.dumps({k:stopped[k]for k in ['UTC','own_runtime_PID_count','CPU_seconds_supervised_sum','sampled_group_RSS_peak','storage_logical_bytes_at_stop']}))
