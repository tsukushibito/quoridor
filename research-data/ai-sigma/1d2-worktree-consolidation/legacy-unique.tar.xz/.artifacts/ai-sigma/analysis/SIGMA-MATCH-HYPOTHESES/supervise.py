import subprocess,os,sys,time,json,pathlib,datetime,signal,resource
O=pathlib.Path(__file__).resolve().parent
C=pathlib.Path('/home/vscode/.cache/inference/research/ai-sigma/match-hypotheses')
name=sys.argv[1]; cmd=sys.argv[2:]
if datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat('2026-10-01T00:52:00+00:00'):raise SystemExit('new job deadline')
env=dict(os.environ,TMPDIR=str(C/'tmp'),XDG_CACHE_HOME=str(C/'xdg'),PYTHONDONTWRITEBYTECODE='1')
start=time.monotonic();log=(O/(name+'.log')).open('w');p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
ticks=None; samples=[];why=None;peak=0
while p.poll() is None:
 try:
  stat=pathlib.Path(f'/proc/{p.pid}/stat').read_text().split(') ')[1].split();ticks=stat[19]
  rss=int(stat[21])*os.sysconf('SC_PAGE_SIZE');peak=max(peak,rss)
  affinities=[sorted(os.sched_getaffinity(int(t.name))) for t in pathlib.Path(f'/proc/{p.pid}/task').iterdir()]
  size=sum(f.stat().st_size for root in [O,C] for f in root.rglob('*') if f.is_file())
  samples.append({'dt':time.monotonic()-start,'rss':rss,'TID_affinity':affinities,'storage':size})
  if rss>939524096:why='RSS_GUARD'
  if size>29360128:why='STORAGE_GUARD'
  if any(a!=[0] for a in affinities):why='AFFINITY_GUARD'
 except FileNotFoundError:pass
 if time.monotonic()-start>45:why='TIMEOUT45'
 if why:os.killpg(p.pid,signal.SIGTERM);break
 time.sleep(.05)
try:p.wait(timeout=2)
except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
log.close();r=resource.getrusage(resource.RUSAGE_CHILDREN)
(O/(name+'.process.json')).write_text(json.dumps({'command':cmd,'UTC_end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'PID':p.pid,'start_ticks':ticks,'exit':p.returncode,'stop_reason':why,'samples':samples,'sampled_RSS_peak':peak,'ru_maxrss_bytes':r.ru_maxrss*1024,'CPU_seconds':r.ru_utime+r.ru_stime,'known_children_alive':0,'waited':True,'TMPDIR':str(C/'tmp'),'XDG_CACHE_HOME':str(C/'xdg'),'instantaneous_peak_not_guaranteed':True},indent=2))
print(name,p.returncode,why,'peak',peak,'CPU',r.ru_utime+r.ru_stime)
sys.exit(p.returncode or (1 if why else 0))
