const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const O=__dirname,BASE=path.resolve('.artifacts/ai-sigma/runs/SIGMA-PAIRED-MATCHES'),R=path.join(BASE,'execution-SIGMA-P32-V2-R3-01');
const J=require(path.join(BASE,'revision3/source-final/judge.cjs'));
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const results=new Map(fs.readFileSync(path.join(R,'results.jsonl'),'utf8').trim().split('\n').map(s=>{const x=JSON.parse(s);return[x.game,x]}));
const states=new Map(),prefixes=new Map(),rows=[];
for(const line of fs.readFileSync(path.join(R,'judge-ply.jsonl'),'utf8').trim().split('\n')){
 const d=JSON.parse(line),r=d.response,g=results.get(d.game);let s=states.get(d.game);
 if(!s){s=J.state(d.prefix);prefixes.set(d.game,d.prefix.slice());}
 if(hash(prefixes.get(d.game))!==hash(d.prefix))throw Error('prefix progression '+d.game);
 const ctx=J.context(s);if(ctx.turn!==d.color||ctx.total_ply!==d.ply||ctx.terminal)throw Error('root context');
 const raw=r.raw||{},payload=raw.payload||{},dat=d.engine==='native'?payload.data:payload.payload?.data;
 const cp=dat?.checkpoint,stats=payload.stats,sim=dat?.simulations_completed??stats?.simulations??null;
 const edges=cp?.root_edges??null;let edgeSum=edges?edges.reduce((a,e)=>a+e[2],0):null;
 const maxv=edges?Math.max(...edges.map(e=>e[2])):null;
 const board={pawns:[s.player1pos,s.player2pos],h:[...s.hwall_anchors].sort(),v:[...s.vwall_anchors].sort(),walls:ctx.walls};
 const req=r.request||{};if(hash(req.legal_prefix)!==hash(d.prefix)||req.seed!==1979||r.T_ms!==500||r.g_ms!==91)throw Error('request frozen conditions');
 rows.push({game:d.game,block:g.block,platform:g.platform,engine:d.engine==='candidate'?'wasm':d.engine,color:d.color,ply:d.ply,remaining_ply:ctx.remaining_total_ply,prefix_length:d.prefix.length,pool_index:g.pool_index,
 board_key:hash(board),board_side_key:hash([board,ctx.turn]),context_key:hash([board,ctx.turn,ctx.history,ctx.remaining_total_ply]),history_key:hash(ctx.history),prefix_key:hash(d.prefix),seed:req.seed,T_ms:r.T_ms,g_ms:r.g_ms,
 limits:{simulations:req.simulations,max_nodes:req.max_nodes,max_depth:req.max_depth,reference:req.limits},t0:r.t0_ms,clock_error:r.clock_error_ms,
 elapsed:r.elapsed_ms,accepted:r.accepted,error:r.error,late:r.late,nn_calls:r.nn_calls??null,nn_ms:r.nn_calls==null?null:(r.nn_ms??null),step_ms:r.step_ms??null,root_ms:r.root_ms??null,finish_ms:r.finish_ms??null,transport_ms:r.transport_ms??null,
 simulations:sim,root_visits:stats?.rootVisits??null,cap:cp?.cap??null,nodes:cp?.nodes??null,max_depth:cp?.max_depth??null,arena_bytes:cp?.arena_bytes??null,action:r.action??null,edge_count:edges?.length??null,edge_visit_sum:edgeSum,edge_max_visit:maxv,edge_ties:edges?edges.filter(e=>e[2]===maxv).length:null,root_edges:edges,reference_stopped:stats?.stopped??null,
 generation:r.generation,request_id:r.request_id,source_line:rows.length+1});
 if(r.accepted){const a=J.validate(d.prefix,r.action);s=s.next(a);prefixes.get(d.game).push(a)}
 states.set(d.game,s);
}
fs.writeFileSync(path.join(O,'request-records.json'),JSON.stringify(rows));
console.log(JSON.stringify({requests:rows.length,games:results.size,engines:Object.fromEntries(['native','wasm','reference'].map(e=>[e,rows.filter(r=>r.engine===e).length])),root_edges_present:rows.filter(r=>r.root_edges).length,reference_root_edges_present:rows.filter(r=>r.engine==='reference'&&r.root_edges).length,NN_execution:0}));
