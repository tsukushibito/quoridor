import pathlib,json,hashlib,sys
O=pathlib.Path(__file__).resolve().parent
ref=json.loads(pathlib.Path('.artifacts/ai-sigma/verification/CRITIC-MATCH-RESULTS/input-before.json').read_text())
paths={x['path']:x['sha256'] for x in ref}
for p in pathlib.Path('.artifacts/ai-sigma/runs/SIGMA-PAIRED-MATCHES/revision3/source-final').rglob('*'):
 if p.is_file():paths[str(p.resolve())]=None
for p in pathlib.Path('.artifacts/ai-sigma/runs/SIGMA-NN-SEARCH/final-source').rglob('*'):
 if p.is_file():paths[str(p.resolve())]=None
for name in ['AGENTS.md','.agents/research-team/common.md','.agents/research-team/roles/hypothesis.md','.agents/research-team/templates/handoff.md','.devcontainer/storage-policy.md','docs/design/ai-sigma-research-goal.md','docs/design/ai-sigma-contract-hypothesis-match-analysis.md','docs/design/ai-sigma-comparison-protocol.md','docs/design/ai-research-team.md','docs/reports/ai-sigma-experiment-matches.md','docs/reports/ai-sigma-critic-match-results.md','docs/reports/ai-sigma-coordinator-match-results-acceptance.md','.artifacts/ai-sigma/verification/CRITIC-MATCH-RESULTS/summary.json','.artifacts/ai-sigma/runs/SIGMA-RULE-FEATURE-PARITY/final-source/crates/quoridor-ai/src/research.rs']:
 paths[str(pathlib.Path(name).resolve())]=None
out=[]
for name,expected in sorted(paths.items()):
 p=pathlib.Path(name);h=hashlib.sha256()
 with p.open('rb') as f:
  while block:=f.read(1024*1024):h.update(block)
 out.append({'path':name,'bytes':p.stat().st_size,'sha256':h.hexdigest(),'critic_expected':expected,'critic_agrees':expected is None or expected==h.hexdigest()})
(O/('input-'+sys.argv[1]+'.json')).write_text(json.dumps(out,indent=2))
assert all(x['critic_agrees'] for x in out)
if sys.argv[1]=='after':assert [(x['path'],x['sha256']) for x in out]==[(x['path'],x['sha256']) for x in json.loads((O/'input-before.json').read_text())]
print('inputs',len(out),'76 critic inputs included','unchanged' if sys.argv[1]=='after' else 'before captured')
