import pathlib,json,statistics,collections,itertools,math
O=pathlib.Path(__file__).resolve().parent
rows=json.loads((O/'request-records.json').read_text())
def summary(v):
 v=sorted(x for x in v if x is not None and math.isfinite(x))
 return {'n':len(v),'p50':statistics.median(v) if v else None,'p95_nearest_rank':v[math.ceil(.95*len(v))-1] if v else None,'min':v[0] if v else None,'max':v[-1] if v else None}
def group_pairs(a,b,key):
 aa=collections.defaultdict(list);bb=collections.defaultdict(list)
 for r in a:aa[r[key]].append(r)
 for r in b:bb[r[key]].append(r)
 return [(x,y) for k in aa.keys()&bb.keys() for x in aa[k] for y in bb[k]]
matching={};matches=[]
for name,a,b in [('native-reference',[r for r in rows if r['engine']=='native'],[r for r in rows if r['engine']=='reference' and r['platform']=='native-local']),('wasm-reference',[r for r in rows if r['engine']=='wasm'],[r for r in rows if r['engine']=='reference' and r['platform']=='browser']),('native-wasm',[r for r in rows if r['engine']=='native'],[r for r in rows if r['engine']=='wasm'])]:
 d={'requests_A':len(a),'requests_B':len(b),'all_possible_request_pairs':len(a)*len(b),'layers':{}}
 for key in ['board_key','board_side_key','context_key','prefix_key']:
  ps=group_pairs(a,b,key);d['layers'][key]={'pair_count':len(ps),'unique_matching_groups':len(set(x[key]for x,y in ps)),'participating_A':len(set((x['game'],x['ply'])for x,y in ps)),'participating_B':len(set((y['game'],y['ply'])for x,y in ps))}
 ps=[(x,y) for x,y in group_pairs(a,b,'context_key') if x['prefix_key']==y['prefix_key'] and x['seed']==y['seed'] and (x['T_ms'],x['g_ms'],x['limits'])==(y['T_ms'],y['g_ms'],y['limits'])]
 d['full_input_and_clock_configuration_matched']=len(ps)
 d['exact_t0_matched']=sum(x['t0']==y['t0'] for x,y in ps)
 d['same_search_configuration']=len(ps) if name=='native-wasm' else 0
 d['backend_only_interventions']=0
 d['effective_control_reason']='Native/Wasm same kernel limits but backend/host/clock-offset/load differ; no intervention' if name=='native-wasm' else 'Serialized envelope matches; reference effective cap100000/no candidate node512 depth24, PUCT1 FPU.2 vs candidate1.5 Q0, root/tie differ'
 d['conditional_descriptives']={}
 for engine,selected in [('A',[x for x,y in ps]),('B',[y for x,y in ps])]:
  # cartesian matches may repeat requests; retain pairweighted and unique denominators.
  u=list({(r['game'],r['ply']):r for r in selected}.values())
  d['conditional_descriptives'][engine]={'unique_requests':len(u),'elapsed':summary([r['elapsed']for r in u]),'nn_calls':summary([r['nn_calls']for r in u]),'simulations':summary([r['simulations']for r in u]),'per_request_NN_median':summary([statistics.median(r['nn_ms']) if r['nn_ms'] else None for r in u])}
 d['same_action_pairs']=sum(x['action']==y['action']for x,y in ps)
 d['board_match_history_diff_pairs']=sum(x['history_key']!=y['history_key'] for x,y in group_pairs(a,b,'board_key'))
 d['board_match_remaining_ply_diff_pairs']=sum(x['remaining_ply']!=y['remaining_ply'] for x,y in group_pairs(a,b,'board_key'))
 d['same_actual_clock_error_pairs']=sum(x['clock_error']==y['clock_error']for x,y in ps)
 for x,y in ps:matches.append({'comparison':name,'A':[x['game'],x['ply']],'B':[y['game'],y['ply']],'same_context_prefix':True,'same_action':x['action']==y['action'],'sims':[x['simulations'],y['simulations']],'nn_calls':[x['nn_calls'],y['nn_calls']],'remaining_ply':x['remaining_ply']})
 matching[name]=d
engines={}
for e in ['native','wasm','reference']:
 r=[x for x in rows if x['engine']==e];edges=[x for x in r if x['root_edges'] is not None];observed=[x for x in r if x['simulations']is not None and x['nn_calls']is not None]
 engines[e]={'requests':len(r),'accepted':sum(x['accepted']for x in r),'missing_NN_requests':sum(x['nn_calls']is None for x in r),'metrics':{k:summary([x[k]for x in r])for k in ['elapsed','nn_calls','simulations','root_ms','finish_ms','transport_ms','nodes','max_depth','arena_bytes']},'NN_call_ms':summary([t for x in r for t in x['nn_ms'] or []]),'step_ms':summary([t for x in r for t in x['step_ms'] or []]),'nn_time_per_request':summary([sum(x['nn_ms'])if x['nn_ms']is not None else None for x in r]),'non_NN_residual_elapsed':summary([x['elapsed']-sum(x['nn_ms'])if x['nn_ms']is not None else None for x in r]),'cap_true':sum(x['cap'] is True for x in r),'sim4096':sum(x['simulations']==4096 for x in r),'sims_greater_than_NN_calls':sum(x['simulations']>x['nn_calls']for x in observed),'sims_equal_NN_calls':sum(x['simulations']==x['nn_calls']for x in observed),'root_edges_requests':len(edges),'PV_recorded':False,'root_edge_sum_minus_simulations':dict(collections.Counter(x['edge_visit_sum']-x['simulations']for x in edges)),'root_visit_minus_simulations':dict(collections.Counter(x['root_visits']-x['simulations']for x in r if x['root_visits']is not None)),'final_topvisit_tied_requests':sum(x['edge_ties']>1 for x in edges),'reference_stopped':dict(collections.Counter(x['reference_stopped']for x in r)),'color_requests':dict(collections.Counter(x['color']for x in r))}
results=[json.loads(s)for s in pathlib.Path('.artifacts/ai-sigma/runs/SIGMA-PAIRED-MATCHES/execution-SIGMA-P32-V2-R3-01/results.jsonl').read_text().splitlines()]
out={'analysis':'SIGMA-MATCH-HYPOTHESES','requests':len(rows),'matched':matching,'engines':engines,'failures':[{k:r[k]for k in ['game','ply','engine','elapsed','error','late','nn_calls','simulations','action']}for r in rows if not r['accepted']],'outcomes_by_platform_color':{p:{str(c):{'n':len(v:=[r for r in results if r['platform']==p and r['candidate_color']==c]),'scores':[r['result']['score']for r in v],'W':sum(r['result']['score']==1 for r in v),'L':sum(r['result']['score']==0 for r in v)}for c in [1,2]}for p in ['native-local','browser']},'initial_pool_indices':{p:sorted(set(r['pool_index']for r in results if r['platform']==p))for p in ['native-local','browser']},'causal_claim':False,'seed':1979,'NN_build_games_executed':0,'notes':['Matched records are observational repeated visits, not interventions; pair counts are cartesian, not independent samples.','Full context includes board+wall stock+side+entire sorted position-count history+remaining200ply; ordered legal prefix checked separately.','Same T/g/serialized limits does not imply same actual effective caps or clock stamp; abs t0 deliberately differs for separate sequential requests.','NN span residual includes feature/legal/search/checkpoint/yield/IPC; not isolated host overhead.','Top visit ties are final candidate statistics, not proof of tie-caused divergence.']}
(O/'analysis.json').write_text(json.dumps(out,indent=2));(O/'matched-records.json').write_text(json.dumps(matches,indent=2))
print(json.dumps({'matching':matching,'failures':out['failures'],'outcomes':out['outcomes_by_platform_color'],'pools':out['initial_pool_indices']},indent=2))
