import datetime, hashlib, json, os, re, resource, stat, time
from pathlib import Path
os.sched_setaffinity(0,{0})
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
UTC=datetime.timezone.utc
START=datetime.datetime.now(UTC)
CUTOFF=datetime.datetime(2026,10,1,3,35,tzinfo=UTC)
def check():
    if datetime.datetime.now(UTC)>=CUTOFF: raise TimeoutError('New read cutoff reached')
roots=[]
for parent,pattern in [(ROOT/'tools','ai-sigma-*'),(ROOT/'.artifacts/ai-sigma','*')]:
    for p in sorted(parent.glob(pattern)):
        if p==ROOT/'.artifacts/ai-sigma/closeout':continue
        roots.append(p)
roots += [ROOT/'models/experiments/ai-sigma',ROOT/'node_modules',ROOT/'packages/engine-bridge/wasm',ROOT/'apps/web/dist',ROOT/'target',ROOT/'artifacts',Path('/home/vscode/.cache/inference/research/ai-sigma'),Path('/workspaces/quoridor/.artifacts/research-team/sigma-launch')]
expanded=[]
split_names={'analysis','build','dispatch','plans','reference','reference-fixtures','runs','verification','ai-sigma'}
for p in roots:
    if p.is_dir() and p.name in split_names and p!=ROOT/'models/experiments/ai-sigma':
        expanded.extend(sorted(p.iterdir()))
    else:expanded.append(p)
roots=expanded
seen={};sums=[];links=[];errors=[];ledgerpaths=[];json_names=[]
for root in roots:
    check(); row={'root':str(root),'exists':root.exists(),'logical_file_bytes':0,'allocated_unique_within_root_bytes':0,'union_first_assigned_allocated_bytes':0,'regular_files':0,'directories':0,'overlap_inodes':0,'symlinks':0}; local=set();stack=[root]
    while stack:
        check();p=stack.pop()
        try:
            s=p.lstat();key=(s.st_dev,s.st_ino)
            if stat.S_ISLNK(s.st_mode):
                row['symlinks']+=1; links.append({'path':str(p),'link':os.readlink(p),'link_bytes':s.st_size,'followed':False})
            elif stat.S_ISDIR(s.st_mode):
                row['directories']+=1
                with os.scandir(p) as entries: stack.extend(Path(e.path) for e in entries if e.name!='.git')
            elif stat.S_ISREG(s.st_mode):
                row['regular_files']+=1;row['logical_file_bytes']+=s.st_size
                if s.st_size<2*1024**2 and p.suffix=='.json' and re.search(r'(resource|usage|ledger|execution|process|stop|storage-process)',p.name,re.I) and ('node_modules' not in p.parts) and ('target' not in p.parts):ledgerpaths.append(p)
                if p.suffix=='.json' and ('stop' in p.name or 'ledger' in p.name):json_names.append(str(p))
            if key not in local:row['allocated_unique_within_root_bytes']+=s.st_blocks*512;local.add(key)
            if key not in seen:seen[key]={'size':s.st_size if stat.S_ISREG(s.st_mode) else 0,'allocated':s.st_blocks*512,'first_root':str(root)};row['union_first_assigned_allocated_bytes']+=s.st_blocks*512
            else:row['overlap_inodes']+=1
        except FileNotFoundError:
            if p!=root:errors.append({'path':str(p),'error':'vanished'})
        except OSError as exc:errors.append({'path':str(p),'error':repr(exc)})
    sums.append(row)
summary={'observed_utc':datetime.datetime.now(UTC).isoformat(),'roots':sums,'unique_inode_count':len(seen),'union_logical_regular_bytes':sum(v['size'] for v in seen.values()),'union_allocated_bytes':sum(v['allocated'] for v in seen.values()),'symlinks':links,'errors':errors,'new_storage_limit_bytes':12*1024**3,'method':'lstat; no symlink traversal; global unique(dev,ino); directories/link metadata counted; first-root allocation is accounting convention, not ownership proof','exclusions':['shared .git','shared training/environment/cache walk','main/other worktree except sigma-launch','own new closeout bookkeeping added with guard later'],'not_exact_since_launch_delta':True,'unmeasured':['initial17:17 inode baseline','shared cache/framework side effects not identified by owner','temporary outside-owned-root writes removed before scan','transient allocated peak','critic .35 writes after snapshot'],'stop_candidate_paths':json_names}
fs=os.statvfs(ROOT);summary['filesystem_available_bytes']=fs.f_bavail*fs.f_frsize
global_cache=Path('/usr/local/cargo/.global-cache')
if global_cache.exists():
    s=global_cache.stat();summary['shared_cargo_metadata']={'path':str(global_cache),'logical_bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'charge_full_before_missing':True,'inside_owner_union':(s.st_dev,s.st_ino) in seen}
for n in ['cpu.max','memory.max','memory.current']:
    p=Path('/sys/fs/cgroup')/n
    if p.exists():summary[n]=p.read_text().strip()
(OUT/'storage.json').write_text(json.dumps(summary,indent=2)+'\n')
reports=[]
for p in sorted((ROOT/'docs/reports').glob('ai-sigma-*.md')):
    check();text=p.read_text();lines=[]
    for i,line in enumerate(text.splitlines(),1):
        if re.search(r'RSS|CPU|GPU|学習|逸脱|停止|保存|欠測|timeout|user|sys',line,re.I):lines.append({'line':i,'evidence_excerpt':line[:700]})
    reports.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'resource_evidence':lines,'is_source_copy':False})
(OUT/'report-resources.json').write_text(json.dumps({'references':reports,'interpretation':'Reported values by source/run; CPU lower bounds and sampled RSS are not full cumulative or simultaneous team maxima; no missing value imputed zero'},ensure_ascii=False,indent=2)+'\n')
jobs=[];identities=[];selected=sorted(set(ledgerpaths))[:300]
for p in selected:
    check()
    try:d=json.loads(p.read_text())
    except Exception as exc:jobs.append({'path':str(p),'parse_error':repr(exc)});continue
    metrics=[];ids=[]
    def extract(v,path=''):
        if len(metrics)>150 or len(ids)>500:return
        if isinstance(v,dict):
            if isinstance(v.get('pid'),int):
                item={'pid':v['pid'],'record_path':path,'identity_fields':{k:x for k,x in v.items() if re.search(r'^(start|exit|wait|reap|alive|running|remain|stop)',k,re.I) and isinstance(x,(str,int,float,bool,type(None)))}}
                ids.append(item)
            for k,x in v.items():
                q=path+'.'+k
                if isinstance(x,(int,float,str,bool,type(None))) and re.search(r'(user|system|sys_|cpu|rss|peak|gpu|train|exit|wait|stopp|remain)',k,re.I):metrics.append({'field':q,'value':x})
                elif isinstance(x,(dict,list)) and not re.search(r'samples|history|inputs|outputs|rows',k,re.I):extract(x,q)
        elif isinstance(v,list):
            for i,x in enumerate(v[:500]):extract(x,path+f'[{i}]')
    extract(d)
    if metrics or ids:jobs.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'metrics':metrics,'identities':ids,'truncation_limits':{'metrics':150,'identities':500,'list':500}})
    if 'stop' in p.name.lower():
        for item in ids:
            pid=item['pid'];q=Path('/proc')/str(pid)/'stat';now=None
            try:now=q.read_text().rsplit(')',1)[1].split()[19]
            except OSError:pass
            identities.append({'source':str(p),**item,'proc_present_now':now is not None,'current_starttick':now,'interpretation':'PID alone is insufficient; compare recorded starttick; absent old identity does not cover new critic runtime'})
(OUT/'job-ledger.json').write_text(json.dumps({'records':jobs,'selected_files':len(selected),'candidate_files':len(set(ledgerpaths)),'scope_cap':300,'unread_candidates':max(0,len(set(ledgerpaths))-300),'no_aggregate_cpu_due_to_overlap_and_missing':True,'no_sum_of_peak_rss':True},indent=2)+'\n')
(OUT/'old-identity-observations.json').write_text(json.dumps({'observed_utc':datetime.datetime.now(UTC).isoformat(),'records':identities,'all_research_pid_zero_claimed':False,'critic_35_future_or_active':True},indent=2)+'\n')
usage=resource.getrusage(resource.RUSAGE_SELF)
(OUT/'scan-execution.json').write_text(json.dumps({'pid':os.getpid(),'starttick':Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],'started_utc':START.isoformat(),'ended_utc':datetime.datetime.now(UTC).isoformat(),'affinity':list(os.sched_getaffinity(0)),'maxrss_kib':usage.ru_maxrss,'user_cpu_s':usage.ru_utime,'sys_cpu_s':usage.ru_stime,'exit_code_if_normal':0,'rss_guard_bytes':1024**3,'storage_guard_bytes':28*1024**2,'new_read_cutoff_utc':CUTOFF.isoformat(),'nn_build_gpu_training_games':0},indent=2)+'\n')
print(json.dumps({'allocated':summary['union_allocated_bytes'],'logical':summary['union_logical_regular_bytes'],'roots':len(sums),'ledger_candidates':len(set(ledgerpaths)),'ledger_selected':len(selected),'old_identities':len(identities),'report_count':len(reports),'maxrss_kib':usage.ru_maxrss,'pid':os.getpid()}))
