研究継続の実依頼75。新契約/親全文を読みready/show/pause確認、自75claim/受領開始を記録してください。最初はphaseA NN0のみ。critic74は72最終版と73計画の独立裁定中、新75を混ぜず、74重NN停止＋統括steerまで新NN/Chromium0。原72は有限支持/準備factory await lateというnegativeを保持。

# SIGMA-STREAMING-STARTUP-WATCHDOG / quoridor-4lc.75 / 試行1・契約1

experiment 01a0f31d-6d15-7620-bb63-4b4f878e4746 → coordinator。親継続版2 SHA6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f全文継承。終了Oct2 01:00UTC/重job00:50/監督00:55、CPU4/RAM8/global3/cum12GiB/製品範囲不変。受領から処理25分/提出35分と絶対22:00/22:10UTCの早い方、新jobは処理5分前停止。旧72の期限・失敗/標本は不変。

## 入力と問い

72 final SHA73098ca0000d8bce335390ebede2b541e2272b94035e48ce1087478879fd3005、entry c06293774b4c318bb5877db11efa246bd5c6087f0efa21bdc99871e7f32098a8、source-frozen3de57bea803b1573c248c8164b362d4d644debb4fe1b24dbcb575a6b1effe3db。全11応答/engine別順検査/回収は有限支持、fresh候補6196.343ms late/nullとstartup12/全分母を保持。統括108identity現在不在とhashを確認済み。74 criticはこの凍結72＋73計画を独立裁定中で、新75を同窓へ混ぜない。

問いは手の公共watchdogがcleanup/oldACK/factory待ちより内側のためready待ちで期限を超える不足と、actualMainの許可purpose配列mock/goldenからactualが漏れ常時NO_FACTORY_IN_ACTUAL_CLIとなる未結線を最小修正できるか。再起動費を時計外へ除いてfresh正常と装うのではなく、間に合わない要求は早いseal又はTの公共discardにし、late factoryと回収を別owned責任で管理する。

write ownerは新tools/ai-sigma-streaming-startup-watchdog/、.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-STARTUP-WATCHDOG/、docs/reports/ai-sigma-experiment-streaming-startup-watchdog.mdだけ。旧72/73/原モデル/kernel/製品/rootlock/全raw/失敗はread-only。必要sourceだけcopy、旧全歴史raw/cache複製0。両AIのNN/PUCT/FPU/order/tie/finish/RuleA/限界/clock数値/6root-ready規約と最終Judgeencoding境界は不変。

## phaseA NN0 実同経路

immutable入力供給可能/adapter前t0を取った時点で外側の公共seal/deadline・世代/request/prefix bindingをarmし、旧cleanup/oldstopACK/factory-await/変換を全てその下へ入れる。保存cacheがないready待ちはnull/falseで一度だけ確定し、pending作業の完了awaitを公共返却の条件にしない。T500/reserve89/commit9/cutoff402/seal411を両者保持。NodeOS timer遅延/encoding費を含む最終stampは測定し、deadline超過はlate/nullを保持し救済0。

公共discard後もstartup/factory/cleanupは所有責任が消えない。旧世代のfactory返却・通知は受理せず、遅れて生成したbackendのdrop/stop/controlledPID0を同identityにより確認する。Promiseを忘れてprocessが残らないよう追跡し、未回収/unknownownershipならfresh禁止・run停止。既mainのpublic timeoutとcleanup permanently pendingの区別を保持する。次t0=前最終publicstampから残work/ready/reloadを全課金、時計reset0。同期NN/ORT/model.loadを強制中断できるとは主張しない。次NNは前handles/activeNN/live0または物理PID0の証拠後だけ、単logicalのCPU競合を避ける。

再起動に数秒必要ならその要求の責任lossを残す。fresh正常という実装検査条件が本質的目標条件と矛盾する場合は、timeout公開/残処理課金/所有回収とready後の合法応答を別条件として報告する。期限超過を無効pairや時計外準備へ付け替えない。待ち続けるPromise/遅着ready/guardpause/signal・D前/同時/後・generation変更を小mockで同choose→finalJudgeencoding→classifier経路へ注入し、公開一回/late0採用/旧backend reuse禁止を反証する。

新73 preregister126f5a6dade5e44f69f007dc57580772193c809cba8ff08e2a99f162d204db1d・辞書86397a79530ad722ab58831d130fde7e40d95ff747b3e88ec290c21f23c577efをread-only結線する。m32/64/0501-0503/search1979/clock/6rootstartup/retry1-global2/責任/Xi/参考L/8600+1.5/最遅22:06:38.500は変更0。必要bindingは別controlとして保存しpreregister元bytesを変更しない。

actual経路は正しいcoordinator freeze/最終preregister辞書/source/model/独立受入れissueとSHA/既run・期限・予算の検証後に同execute/create/submit/finish/stop/分類/最終時計を通れる設計へ結線する。actualで外部から任意factoryやmockfactoryを注入できる公開CLIは作らない。診断目的の同executeではprogrammatic mockだけを使い、新schema/dictionary/64採番/色/score/retry/partial停止をcompact要約で検査する。dry/actual記録を偽装せず、inputpoolのNN/実engine送信0。

本contractのactual_go=false/independent_acceptance=falseを維持、coordinator本freeze/critic本proof自己発行0。正actual verifierには診断用proof環境を隔離し、診断の正経路/falsego/missing/foreignhash/旧issue/既runを同CLI子で反証できるようにする。診断正proofを研究受入れと呼ばない。今回74は72の裁定であり75本proofとして再利用禁止、新75の独立裁定が別に必要。falsegoが先に拒否した場合と正proof時既run拒否を区別し、単なるsource接続を実runtime成功と呼ばない。

小NN0 phaseAだけ開始し、全gate/保存headroom/他重NN不在を固定してcoordinatorへ提出。74が重NNを終え停止記録とPID0を報告し、coordinatorの明示phaseB steerを受けるまでは新NN/Chromium0。等待期限延長0、同CPU2に重NNを重ねない。

## 条件成立後だけphaseB別一窓

明示steer後、NN前の一最終source・固定順をpreregister。共通startup6rootを別計上後、両正常2・候補完成cp後cancel1・両legalgoal2・同runGame4ply（outcome前停止）・準備factory人工delay/無応答最大2、public最大11の新一窓。この窓は準備watchdogの公共返却と全時計を判別し、6秒reload費をT外へ除いてfresh正常を作る試験ではない。工夫してよい部分はownership/free/late factory回収をどう証明するかで、T/順/数値gate/失敗分母は結果後変更0。旧72全11の成功付替えや新標本統合0、救済NN再試行0。

最終Judge合法性/必要UTF8 encoding後stamp/finish/次t0・NN0 terminal・実hostfault/producer prefix echo/identity/numeric/strict[-1,1]/engine別合法順/Action別prior/fallback0を保持。648featuresbits/137NN・合法mask/P2/209↔136を先に型finite検査し固定abs<=1e-4+1e-4abs(ref)、動的4plyと固定golden NNの分母を分ける。最後のModeldrop/全searchACK0/innerforced controlledPID0/outerkernel adoptionwaitを別記する。型や数値helper失敗でもcleanupを省略しない。

NN0/mock/候補単手を正式公平性/対局/棋力/Sigma到達/任意tree一般証明にしない。旧m48は21:13:18.500過ぎ未適格no-go、旧32局非統合/NI未立証。新m32も独立gateと予算が22:06:38.500まで揃わなければno-go、m/T/CIを救済縮小0。

## 資源と終了

staticCPU0/runtimeCPU2単logical/threads1、RAM4GiBguard3.5/new128MiBguard112は既entry2GiB内/追加予約0、旧68peak/旧予約/台帳/cum12GiBリセット0。phaseA準備8MiB以内目安、profile/temp/raw/停止metadataに保守headroomを先算、不足はNN0停止。job180秒/sole-root空child/singlethread/subreaper/kernel adoption/bootPIDstarttick限定signalwait/TMPXDG専用。unknownsignal/wait0、他者kill0。

source/NN停止・hashafter/全分母/clock/typederrors/primarysecondary/commandhash/UTCmonotonic/PIDwait/affinity/RSS/保存peakを本文前manifestへ固定。小helper一原因一NN0修正は失敗保存しguardなら終了。build/取得/製品/学習/GPU/対局holdout/追加委譲0。瞬間peak/全CPU背景/通常native/深部/rawview/entropy/true合法200/no-legal/training未確認を保持。backup/report→coordinator、本人受入れ待ち/goal他者close0。


# Sigma自律研究・継続枠 2026-10-01

契約版2。目標quoridor-4lc。統括01a0f31b-3409-75f2-a30e-453a50484f94。根拠はユーザーの明示継続/詳細委任（root入力01a0f2e9-357d-7ef3-a2fe-b16f80accda5）。開始2026-10-01T09:03:36.459834+00:00、終了2026-10-02T01:00:00Z（2026-10-02 10:00 JST）。本書は新しい実行枠であり、旧目標契約版2の初期04:00終了/未達/過去逸脱を保持する。旧文書・旧preregister・成績は変更しない。目標/比較A/通常製品規約維持/独立検証/権限は旧目標契約を継承する。

固定Sigmaと同計算資源・思考時間でnative/localおよびbrowserの非劣性を実測する。旧32局m8のnative.5625/browser.1875と両下限未達を保持。今回の新比較はcode/model/config/pool/T/g/m/CI/停止/責任分類を結果前に別事前登録し、旧結果へ後付け条件変更/標本統合をしない。未使用m10計画は参考として残すが、実入口/共通時計/資源gateと新deadlineを独立freezeするまで対局禁止。

予算はCPU全計4logical、RAM全計8GiB、LLM最大3（統括と新supervisorを含む）、正式CPU比較はCPU2単logical/推論threads1/GPU推論0/他の重い研究job停止。GPU研究は旧上限6GiB・1job30分・累積2h以内を保持し、今回は別配分前GPU/学習0。成果/依存は旧枠から累積12GiBを維持、リセット/12GiB追加ではない。旧限定保守課金6,588,000,723B・条件付き残6,296,901,165Bを開始時再確認する。初回新規予約: entry2GiB（guard1.75GiB）、steward128MiB、監督32MiB、統括文書32MiB。未配分は基準再確認後に統括が同12GiB内で配分。副次cache/途中展開/一時profileも計上。既存共有training/cacheは読取のみ、削除はこの枠が所有する再生成物だけを証拠保持の上で別に判断。

既存五役saved sessionを維持、新supervisorは既存App Serverに永続登録して観測専用で追加。App Server/toolchain再起動やモデル/effort変更をしない。新有料API/クラウド/第三者オンライン対局なし。主checkout製品/UI/描画/M2/commit/push/公開は対象外。研究worktreecodex/ai-sigmaで新copyに実装し旧入力をhashで固定。スケジューラーは主checkoutのpush済み操作入口を利用し、運用role定義/registry/専用configだけを用意する。

監督issuequoridor-4lc.40、20分周期/1turn180秒（新job120秒で停止し報告へ）、終了2026-10-02 00:55UTC、観測のみ。globalは3だがschedulerの起動閾値max_active_sessions=2として統括報告の起動1枠を残す。枠使用中はskipしsteerしない。変化なしは保存のみで静かに終了、意味ある停滞/失敗/期限資源/完了時にだけ統括へreportする。監督が設定や課題配分を変更しない。pause/終了はownedturnだけinterrupt確認し、外部jobは各ownerが回収する。dispatcherや監督の停止だけでNN停止を認定しない。

初回はquoridor-4lc.38stewardがscheduler準備/実運用/容量/資源台帳、quoridor-4lc.39experimentがORT入口・復旧gateを担当。途中から競合A共通tract/B分離ORT/C B0とH1backend/H2探索/H3時計・checkpoint/H4標本を更新し、通常判断は統括が実依頼する。別の選択が有望ならこの枠内で契約を作り替えるが、結果を見た正式判定緩和は行わない。

終了: 目標達成、ユーザーpause、上限/guard/異常、2026-10-02 01:00UTC。2026-10-02 00:50UTCまでに新重jobを止め、終了処理を確保する。全ownerはPID/starttick/command/hash/exit/資源/失敗/stopを先保存、報告は簡潔に詳細JSONへリンク。達成なら独立根拠で目標close、未達なら次の継続/停止理由を記録。予算を自動延長しない。各実行deadlineは本枠以下。担当へ実送信/受領をBeadsとdispatchに記録する。

継続委任は目標へ向けて継続する指示である。未達の場合は本枠終了前に統括が次枠の必要性/予算/検証を判断し、ユーザーへ通常詳細の再承認を求めず別契約として具体化できる。同一枠の期限や累積12GiBを黙って拡張しない。

## 契約版2の期限変更根拠

2026-10-01、操作元root 01a0f2e9-357d-7ef3-a2fe-b16f80accda5からユーザー明示指示を受領。「明日午前10:00」は2026-10-02T10:00:00+09:00 = 2026-10-02T01:00:00Z。開始時刻は維持し、旧継続枠終了2026-10-01T17:00:00Zから終了時刻だけ変更する。重い処理停止00:50UTC（09:50JST）、監督運用停止00:55UTC（09:55JST）、monitor回収00:58UTC、枠終了01:00UTC（10:00JST）。目標達成・pause・guard停止条件と時間以外のCPU/RAM/LLM/累積容量・許可範囲・独立検証は変更しない。

旧版SHA859bb777836cc0683e1ad7d1763a71fda60c75d2d6391290cef28771589a81a2を.artifacts/ai-sigma/continuation-20261001/DEADLINE-20261002-1000/continuation-version1.mdへ保全。閉じた実験や旧個別契約の処理/提出期限、事前登録、旧失敗/逸脱を遡及延長しない。新実験・比較は別契約で結果前に固定する。統括.52が正本/Beads、steward.53が既存所有範囲の運用契約/config/reload/monitor更新と実反映を担当する。


# 新m32静的計画と.72接続診断の受領

2026-10-01 21:33UTC。新対局0、actual_go=false、Sigma未達/正式NI未立証。

.73の固定preregister126f5a6dade5e44f69f007dc57580772193c809cba8ff08e2a99f162d204db1d、辞書86397a79530ad722ab58831d130fde7e40d95ff747b3e88ec290c21f23c577efを静的計画として限定受入れする。統括37manifest checks実hash、6自己identity現在不在、独自Pythonのselection/order/color/64採番・参考幅・8600+1.5秒/最遅22:06:38.500を再算し一致した。根拠 READY32-INDEPENDENT-HANDOFF/plan73-review.json。旧m48/96は固定最遅を越えて未適格no-go、旧32局と新計画は統合しない。本人.73はこの限定受入れとnull source/proof/actualgo falseを保持してclose可。

m32の参考Hoeffding幅.216352297825、平均.5ならL=.283647702175であり、同等近傍を正式NIとして認定する精度はない。browserのみではnative目標未達。CI/mの結果後変更、有限母集団の一般化、未使用文書根拠の全host監査への格上げはしない。

.72は元engine固有の合法順/Action別prior検査を修正し、最大11公開を一窓で完了、通常7採用/1fresh late・取消1・goal2NN0、startup12は別分母。検査器・最終Judge後stamp・所有回収は有限支持だが、factoryの再起動待ちを手時計へ課金したfresh候補が6196.343ms lateとなり、全時計/対局no-goを保持する。旧71の3公開/ERR_ASSERTIONを救済しない。統括は72final/entryhash一致・108記録identity現在不在を確認した（input72-review.json）。独立実NNはまだ別契約.74。

次.74 criticへ73静的計画と凍結72の同main/数値/clock/ownership/責任を独立に裁定させる。再起動費を時計から除外してfresh正常を装わず、同じ最大11一窓に失敗も残す。原72 actualMainはpurpose actualが許可配列mock/goldenに含まれず、go/proofが成立してもNO_FACTORY_IN_ACTUAL_CLIとなる静的枝が残る。falsego拒否の成功だけを正actual入口の検証とはしない。

.75 experimentは新copyへ外側手watchdogをfactory/oldACK/cleanupのawaitより前に置き、公共discardと回収責任を分ける。常時purpose拒否も新73結線と同mainで修正し、実freeze未発行を維持する。まずNN0、.74の重NN停止＋統括steer後のみ少数golden、手費用/旧失敗/m/T/CIを変更しない。仮に再起動がTを超えるならその要求はlossのまま、回収/ready後の安全な次要求とは別条件にする。モデルreload6rootをT外へ付け替えない。

CPU4/RAM8/global3/cum12GiB/Oct2 01:00・旧peak/課金/予約/欠測を保持。64局の入場予算と独立gateが揃わなければ実比較もno-go。対局開始が目標達成や製品採用ではない。


EXPERIMENT_REPORT SIGMA-STREAMING-NUMERIC-ORDER quoridor-4lc.72 / trial1 / contract1

判定: 数値検査器/全11接続/所有回収の有限支持、fresh正常・全時計/実比較no-go。actual_go=false/entry_ready=false。受領21:10:05・本人claim21:10:54、全文/親版2/ready/show/pauseなし、開始report accepted。処理21:35・新job21:30・提出21:45、旧71/69期限・失敗を延長/救済0。

必要sourceだけ新copy。固定Rust legal_action_idsのpawn cell→Hanchor→Vanchor昇順とSigma原getLegalActions順を別期待値とし、実cpの順序/重複/集合を厳密照合。Action→canonical136/P2縦反転で安定softmax/priorへ対応し、異engineの列挙位置同一を仮定しない。検査器の期待値だけ整列しproducer/tree/tie/finishは並べ替え0。18重要producer/caller/最終Judge/encoding/分類/ownership/startup sourceは71と実bytes一致、real-backendはhelper呼出しのみ、mainは新issue/proofpath binding。NN0 P1/P2各engineの普通/VM正常と集合欠落/重複/非法/順変更・prior取り違え・648bits/137shape/finite/strict±1境界を反証。別分母の旧6controlも順/Actionごとprior通過、実NN0。

同mainの実host→pending→最終public→classifierとtoken拒否を維持。false-go/未token/旧hash/旧issue・既mockdir存在時のfalse-goを実actual CLI子で拒否、backend0。正actual proofは自己発行0/未実検証、false-goが既runチェックより先に拒否する分岐と正proof時の既run gate未検証を区別。診断existing-runは同main APIで拒否済み。旧m48/preregister bytesは変更0/実pool送信0、73まだbind/freeze0。

一最終source/一窓 2026-10-01T21:19:15.789146+00:00 → 2026-10-01T21:19:34.455789+00:00、exit0/guard停止0/NN再試行0。11/最大11全応答: 通常8中cp7、fresh候補1 late/null、取消1 null、合法goal2 NN0、golden4plyはoutcome前停止。startupはsession1/2各6root=12を別計上、木/history/cache再利用0、手内成功に混合0。accepted通常7 median412.703/max419.325ms。freshはModel/session/Chrome processをdrop・controlled回収後再起動し、6root/load/reclock等を前最終stamp始点へ全課金したため候補6196.343ms/LATE_RESPONSE/null。未送信/数値missingも保存し分母から除外0、fresh両正常条件は不成立。factory await後の公開となる遅延をdeadline内成功にしない。

手内5184features bits/1096NN/919prior、各engine順/集合/P2・finite/strictvalue・固定abs1e-4+rtol1e-4支持。動的4plyのNNには対応固定golden NN参照がなく、特徴/合法mask/Actionごとprior検査と固定golden参照の分母を区別。新cp一般treeの安全証明ではない。final Judge/Action clone/UTF8 encoding後t1、public/finish/elapsed/次t0=前t1を照合。null/late/terminalも同境界、sealにWorker照会/NNawait0。診断classifiedラベルは成功にも無条件付与する既存枝でありWDLにしない、実runGameはaccepted=false時だけ分類。

数値例外0、2 Model drop ACK handles/activeNN0、10実search ACK handles/activeNN/live0＋1未送信zero proof、inner forced controlledPID0→freshとouter sole-root/subreaper/adoption同identity waitを別保存。本文前21:22:10 source/runtime-stop/hashafter、記録108identity現在不在。自然停止/全期間保証ではない。観測全TID CPU2/NNthreads1、RSSpeak1537363968B、保存peak26841088B<112MiB、TMP込み・終了減少で課金減額0。new128MiBは既entry2GiB内追加0、旧68peak/旧予約/cum12GiB不変。瞬間peak/背景/一部短static PIDRSS欠測保持。

原42参照と71最終sourceを含む新before/after91checks全一致。entry manifest SHA c06293774b4c318bb5877db11efa246bd5c6087f0efa21bdc99871e7f32098a8、source-frozen SHA 3de57bea803b1573c248c8164b362d4d644debb4fe1b24dbcb575a6b1effe3db。詳細 [handoff](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-NUMERIC-ORDER/handoff-summary.json)、runtime-source-stopped-before-report、runtime-denominators-and-clock、unchanged-producer-caller-kernel-boundary、numeric-gates/saved-control-gates/cli-refusals、real-GOLDEN72-ONCE-session1/2、golden72-once.process/log、input-after/copy-patches。独立別binding/新比較登録/統括freeze前の実runは禁止。

旧71公開3/ERR_ASSERTION/未実施8と69保存監査を今回成功へ付替え0。旧m48最遅21:13:18.500は未適格のまま過ぎたため当該比較no-go、11800+1.5/m/T縮小0。73別計画は別登録・旧32局と標本統合0。Sigma未達/NI未立証、Atract/BORT/CB0・H1〜H4、g287/62+82/340秒/2.26秒、旧容量/期限/scope/affinity/RSS・真合法200/no-legal/deep/rawview/entropy/training不明保持。build/取得/学習/GPU/製品/対局holdout/追加委譲0。72は独立受入れ待ちin_progress/目標他者close0、backup/report後待機。


# SIGMA-STREAMING-COMPARISON32-PLAN / quoridor-4lc.73

試行1・契約1、hypothesis 01a0f31c-2e4b-7170-82c5-69e1428c2418 → coordinator。受領/claim21:11:01 UTC、処理21:31:01・新job21:26:01・提出21:41:01（絶対期限との早い方）。親版2を継承。**新m32静的計画と二言語検算は成立。実go/entry_ready/freezeはfalse、NN/Chromium/engine/実holdout送信/対局/build/取得/委譲0。** 本人.73は受入れ待ちin_progress、close0。

新preregister SHA `126f5a6dade5e44f69f007dc57580772193c809cba8ff08e2a99f162d204db1d`、辞書SHA `86397a79530ad722ab58831d130fde7e40d95ff747b3e88ec290c21f23c577ef`。旧pool64の実送信8indicesを除く56からselection2026100501/order0502/color0503で32抽出、同prefix色交換64採番、search seed1979を結果前固定。全prefix辞書は1個、pairは参照だけ。NodeとPythonの別実装が抽出/順序/色/採番/PRNG traceまで完全一致。旧m48/96と旧初期.48 SHA9e05356a…dc27／05cf461e…1002は不変、旧mや期限を縮小・延長0。新32中27は旧未実行48計画と重複、旧未実行m10と6重複（10,45,43,33,32,27）。これは旧32実対局とは別で統合0。全host送信/未知training重複は未監査、既送信反証なら全計画無効・補充0。

固定J/game/context copyでpool64の合法replay/Action写像/context/hash/history/turn/remainingply、非終端・一意性・golden除外を検査、selected32も一致。人工contextを棋力prefixへ混ぜない。旧source・モデル・.72・entry・rootlockは編集せず、読み取った16重要入力afterhash一致。HEAD1482df8…c76・codex/ai-sigma、HEADだけで未コミット入力を同定せずhashを正本とする。

候補ORT pending対固定Sigma-Web、同Node/T500/reserve89/commit9/cutoff402/seal411。新startup initial/asym-P2/jump-P2×両側root1NN=6/session、warm木/historycache破棄・ACK0でready。初期startupは手t0外だがwall/RSSへ課金、holdoutはready/freeze後。以後t0は前最終Judge/clone/UTF8後stamp、残NN/stop/審判/log/reloadreadyを全課金しresetしない。両thread1/CPU2単logical、fallback0、候補PUCT1.5/Q0/4096sim/512node/depth24・参照C1/FPU.2/temp0/first合法順/bestAction/100000sim/root展開sim外/uncapped nullを維持。root NN value対root qValue、訪問sim−1対sim/root sim＋1は別規約。receive-orderfault政策と未知遅延故障時刻を全知にしない条件を登録。

source finalSHA/entry/binary/ORT runtime hashはnull・accepted=false。placeholderを実受入れとせず、.72停止＋独立契約裁定後の統括別bindingを必要条件とした。schema/control-planの9接続表とstd-only検査を保存。新main用schedule/dictionary/clock/startup/classification/stop/retry/score/予算の必要gateを示したが、同main/実backend/別mock分類器を実検証したとは呼ばない。

compact11 scenarioのscore/Xi/L・invalid retry1/global2・同prefix/seed・pause/guard/deadline/signal partialがPython/Nodeで完全一致。共有辞書とattempt差分のみ、原prefix複製0。candidate NN/model/fallbackはloss、reference同障害はpair invalid、共通identity/referee infra invalid、両timeout/late/crash/noCP/未知無応答は責任engine lossを事前分類する。これらscenarioは所与のcontrol記号を算術に流しただけで、実障害の分類器gateは今後。全attempt/invalid/停止保持、補充0・retryを独立sample扱い0・未完了Lなし。

m32の95%Hoeffding片側参考幅 `0.216352298`、平均0.5のL `0.283647702`、threshold .45へ届く観測平均は約 `0.666352298` 必要。人工scenarioの得点は棋力データではない。正式NI/母集団一般化には適用仮定の独立裁定が必要、browserだけでnative+browser目標を達成しない。許容差.05/CI/mを結果後変更0。

将来案（今回の評価器へ追加しない）: 固定Hoeffding幅.05なら600pair/1200game、worst思考120000s以上。真平均.5で一側α.05・80%powerをHoeffding両尾で十分保証する保守案は1800pair/3600game、worst思考360000s以上（最小標本数ではない）。有限56母集団限定Serflingやcoverageを別検証したpaired empirical-Bernstein/離散法等を競合案として条件/費用/相関・clock順序・小標本risk付きでpython-verification.jsonに保存。現在の32のCIを後付けで有利に変更しない。現在pool/時間では正式NI精度は未達。

Node/Python双方でworst6400+startup400+retry1200+保存600=8600s、停止reserve1.5、最遅Oct1 22:06:38.500 UTCを再算。直後1msでは不足を検査。match stopOct2 00:30/save00:50/監督00:55/global01:00。minimum入場条件で完遂/tail保証ではない。実freeze残量不足/独立gate未成立ならno-go、旧短平均でworst減額0。

3監視付きstd jobはexit0・guard違反0。20ms観測launcher+child RSS最大93,892,608B、全観測TID CPU0、監視jobのparent+child CPU累計0.306496s、jobwall約0.292s。短読取/生成commandを含む全CPU累計と瞬間/短命TIDpeakは未保証・欠測を0補完しない。終了前6 launcher/child PID/starttick現在不在、source停止/hashafter/runtime-source-stoppedを本文前保存。新保存約0.35MiB（最終文書/metadataを含む値はmanifest）、guard28MiB/予約32MiB内。条件付き残3,559,487,021Bは全owner実現在量証明ではなく、旧67peak/旧課金/cum12GiBを減額・reset0。失敗した探索readの契約候補filenameは訂正したが、検算job失敗0・旧証拠削除0。

再現: `UV_NO_SYNC=1 UV_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1 timeout 50s taskset -c 0 python3 tools/ai-sigma-streaming-comparison32-plan/supervise.py <newjob> node --max-old-space-size=192 --max-semi-space-size=4 --no-node-snapshot tools/ai-sigma-streaming-comparison32-plan/generate-node.cjs`。Pythonはverify-python.py、schemaはvalidate-schema.py。新生成は既preregisterを上書きするので、この固定成果へ再実行せず別scope/新契約で再現する。source/command hash・UTC/monotonic・boot/PIDstarttick・affinity/RSS/exitは*.started/process/log。preregister/prefix-dictionary/extraction-trace/prefix-validation/compact-scenarios/node-verification/python-verification/schema-control-verification/control-plan/handoff-controlに詳細。

書込/自己プロセス停止後backup/report。通信/静的成功は対局freezeではない。次は.72新source停止・独立実main/clock/ownership/責任/ready/outer watchdog/実pause/cleanup/fresh gateと統括freeze。Atract/BORT/CB0・H1/H2/H3/H4、束変更から棋力差原因を断定0、旧69独立実NN0・旧71public3/fresh未成立・旧失敗/容量/期限/scope/RSS/affinity・g287/62+82/340秒/2.26秒、旧32局/NI未立証/Sigma未達、真合法200/no-legal/deep/rawview/entropy/training未確認を保持。
