'use strict';const fs=require('fs'),path=require('path'),CP=require('child_process'),assert=require('assert'),{OwnedProcesses,boundedStop}=require('./cleanup.cjs'),{createMonitor}=require('./pause-check.cjs'),N=require('./numeric.cjs');const BASE=path.resolve(__dirname,'../../.artifacts/ai-sigma/continuation-20261001/SIGMA-ISOLATED-NN-COST');
async function main(){const owner=new OwnedProcesses({tracePath:BASE+'/phase0-owned.jsonl'});let monitor;try{monitor=createMonitor({out:BASE,subjectIssue:'quoridor-4lc.80',deadlineUTC:'2026-10-01T23:07:27Z'});await monitor.start();monitor.check();const root=owner.rootIdentity;assert.equal(root.ppid,process.ppid);const tmp=process.env.TMPDIR;const child=owner.observeChild(CP.spawn('python3',['-c',`import os,time,pathlib
p=pathlib.Path(os.environ['TMPDIR'])
for i in range(50):
 f=p/('race'+str(i));f.write_bytes(b'x'*4096);f.unlink()
if os.fork()==0:
 os.setsid()
 if os.fork()==0:time.sleep(.25);os._exit(0)
 os._exit(0)
time.sleep(.05)`]));await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',resolve)});await new Promise(r=>setTimeout(r,450));await owner.registrationReceipt();const vm=require('vm');for(const v of [[1,2],new Float32Array([1,2]),new Uint32Array([1,2]),vm.runInNewContext('[1,2]')])assert.deepEqual(N.arr(v,2,'ARRAY'),[1,2]);for(const v of [[1],[1,NaN],[1,Infinity]])assert.throws(()=>N.arr(v,2,'ARRAY'));assert.throws(()=>N.close(1.1,1,'MISMATCH'));const numeric={validated_real_NN:false,realm_arrays:4,invalid_arrays:3};fs.writeFileSync(BASE+'/phase0-inner.json',JSON.stringify({pass:true,NN:0,Chromium:0,monitor_READY:true,child_ppid:root.pid,kernel_registration:true,numeric})+'
');}finally{if(monitor)await monitor.stop();const proof=await boundedStop({owner,stop:async()=>({remaining_pids:0})});fs.writeFileSync(BASE+'/phase0-cleanup.json',JSON.stringify(proof)+'
')}}main().catch(e=>{fs.writeFileSync(BASE+'/phase0-primary.json',JSON.stringify({name:e.name,message:e.message,stack:e.stack})+'
');console.error(e);process.exitCode=1});
