import json, pathlib, math, hashlib, datetime
P=pathlib.Path(__file__).resolve().parent.parent
read=lambda n:json.loads((P/n).read_text())
p=read('preregister.json');pool=read('snapshot/pool64.json');old=read('snapshot/old21-preregister.json')
def rng(seed):
 s=seed
 def choose(n):
  nonlocal s
  limit=(2**32//n)*n
  while True:
   s=(s^(s<<13))&0xffffffff;s=(s^(s>>17))&0xffffffff;s=(s^(s<<5))&0xffffffff
   if s<limit:return s%n
 return choose
def fy(a,seed):
 a=list(a);r=rng(seed)
 for i in range(len(a)-1,0,-1):
  j=r(i+1);a[i],a[j]=a[j],a[i]
 return a
excluded=old['selected_indices'];assert excluded==[25,4,51,0,47,44,56,31];assert fy(range(64),2026100202)[:8]==excluded
eligible=[i for i in range(64) if i not in excluded];selected=fy(eligible,2026100301)[:48];order=fy(selected,2026100302);r=rng(2026100303)
assert p['selected_indices']==selected and p['ordered_indices']==order and len(set(selected))==48
numbers=read('all-game-numbers.json');assert len(numbers)==96 and [g['game'] for g in numbers]==list(range(1,97))
for index,pair in enumerate(p['pairs']):
 i=order[index];f=pool['pool'][i];colors=[2,1] if r(2) else [1,2]
 assert pair['candidate_color_order']==colors and pair['pool_index']==i and pair['legal_prefix']==f['legal_prefix'] and pair['context']==f['context']
 assert pair['context_sha256']==f['context_sha256'] and pair['rust_prefix']==f['rust_prefix']
 assert pair['context']['remaining_total_ply']==200-len(f['legal_prefix'])
 assert [g['game'] for g in pair['games']]==[2*index+1,2*index+2]
 assert all(g['seed']==1979 and g['status']=='scheduled-unexecuted' for g in pair['games'])
for logname in ['selection','order','color']:
 for draw in read('extraction-trace.json')['trace'][logname]:
  assert draw['limit']==(2**32//draw['n'])*draw['n'] and draw['u32']<draw['limit'] and draw['index']==draw['u32']%draw['n']
  assert all(x>=draw['limit'] for x in draw['rejected'])
for name in ['all96','one_retry','pair_exhausted','global_exhausted','pause','deadline','candidate_loss','reference_timeout']:
 s=read('mock-'+name+'.json');assert s['retries']<=2
 valid=[]
 for attempt in s['attempts']:
  original=p['pairs'][attempt['pair']-1]
  assert attempt['prefix_sha256']==original['prefix_sha256'] and attempt['context_sha256']==original['context_sha256'] and attempt['seed']==1979 and attempt['attempt']<=1
  assert all(g['game'] in [x['game'] for x in original['games']] for g in attempt['games'])
  if attempt['valid']:assert len(attempt['games'])==2;valid.extend(g['score'] for g in attempt['games'])
 assert len(valid)==s['valid_score_count'];pairscore=[sum(valid[i:i+2])/2 for i in range(0,len(valid),2)]
 assert len(pairscore)==s['score']['completed_pairs'];mean=sum(pairscore)/len(pairscore) if pairscore else None
 assert mean==s['score']['mean'];expected=max(0,mean-math.sqrt(math.log(20)/96)) if len(pairscore)==48 else None
 assert expected==s['score']['L'];assert s['real_holdout_sends']==0 and s['entry_invocations']==0
stop=datetime.datetime.fromisoformat(p['run_budget']['processing_stop_UTC'].replace('Z','+00:00'));latest=datetime.datetime.fromisoformat(p['run_budget']['latest_conservative_start_UTC'].replace('Z','+00:00'))
assert (stop-latest).total_seconds()==11801.5 and p['run_budget']['total_minimum_s']==11800
assert p['actual_go'] is False and p['freeze_issued'] is False
out={'independent_implementation':'Python masked xorshift/rejection/Fisher-Yates; no JS generator import','selection_order_colors_match':True,'scheduled_pairs':48,'scheduled_games':96,'eight_mock_scenarios_recalculated':True,'reference_width':math.sqrt(math.log(20)/96),'L_at_hypothetical_mean_half':max(0,.5-math.sqrt(math.log(20)/96)),'latest_conservative_start_UTC':latest.isoformat(),'actual_go':False,'actual_games':0,'entry_runtime_verified':False}
(P/'independent-arithmetic.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
