新実依頼 SIGMA-STREAMING-MATCH-ENTRY-PLAN .67。計画と同入口mockの実装・実検査を始めてください。NN/Chromium/実engine/実holdout送信/game0。現在 .66 critic が最終共通callerを独立検証中、旧 .48 pristineの48未使用prefix/96採番を結果前の別preregisterへ固定し、実backend未成立をfail-closedにした同main mockを作ります。global3はcoordinator/critic/hypothesisの3役で許可範囲、役から追加委譲0。最初に受領claim開始/相対deadlineを保存。
契約SHA 80729b9f6b9e1b2b5b157250a520366379fbed088d7ee076204e63ff34c8298e

# SIGMA-STREAMING-MATCH-ENTRY-PLAN / quoridor-4lc.67 / 試行1・契約1

hypothesis 01a0f31c-2e4b-7170-82c5-69e1428c2418 → coordinator。親継続版2 SHA6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f 全文継承。Oct2 01:00UTC/重job00:50/監督00:55、global3、累積12GiB・許可範囲不変。受領から処理30分/提出40分、新jobは処理5分前停止。CPU0、RAM1GiB、std-only既Node/Python。新32MiB guard28を未配分から予約、条件付き残3,626,595,885−33,554,432=3,593,041,453B。範囲外共有増分/全owner peak未監査の旧条件付き値であり正確な全使用量証明ではない。GPU/NN/Chromium/実engine/holdout送信/game/build/取得/依存同期/追加委譲0。

## 所有・入力

新 `tools/ai-sigma-streaming-matches/`、`.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-MATCH-PLAN/`、`docs/reports/ai-sigma-hypothesis-streaming-match-entry.md` のみ書込。.48/旧pool/.65/.66・モデル/kernel/全旧source/preregister/報告はread-only。元main/pair/game/judgeをコピー利用し元hashと差分を保存、保存rawを上書きしない。実backend境界が不足ならfail-closed、旧成功を新96入口受入れへ流用しない。

旧 .48 `SIGMA-CONTINUATION-MATCH-PLAN/preregister.json` SHA05cf461e23998e7e230c05b280a16f4105723cd1b5d4604f28f5374272961002、未使用48prefix/96採番/selection2026100301/order0302/color0303/m48・browserのみは再現しそのまま維持する。旧m48/T500g91の契約・preregisterは不変、新方式に別preregisterを作る。pool64の最初に実送信された8を除く未使用文書根拠・全host送信/未知学習重複未監査を明記し、送信済みの反証があれば新全計画不成立、補充0。新根生成・有利局面選別0。

新方式は固定 .65最終revision3 source-frozen SHAb66988de59787c3b955d54fe15a894887b237b7430ceae1710db827880a698b1、manifest8778edbf1638772b072b0b9deb5bf07b7dad61c2fe8982987c5ceec5a56e5132、同Node caller/完成通知/残処理課金/T500/reserve89/commit9/cutoff402/seal411。.66独立検証中でまだ受入れ未成立。参照C1/FPU.2/temp0/first合法順/元bestAction/root展開sim外/100000sim・候補PUCT1.5/Q0/seed1979/原tie/finish/4096sim/512node/depth24を保持。参照root qValueと候補root NN value/各訪問分母は別規約、receiverが新着手を再選択しない。

## 新事前登録・同入口mockの実装

新preregisterは結果前に選択順色・48pair/96gameの全採番、engine/model/source/ORT/hash/資源/時計/通知/初回なし/故障政策/責任/停止/retry/scoreを固定する。Xiは同prefix色交換2局の候補得点平均、scoreはwin1/draw.5/loss0、完成m48固定、参考下限L=max(0,meanXi−sqrt(log20/(2*48)))を維持。旧32局へ統合0。m48でも同等付近に広いCIが残ることと、browserだけでnative目標を達成しないことを明記。結果によるm/閾値/分母変更0、未完了は完成/予定mを分け正式Lなし、timeout/faultlossを落とさない。

pair retry最大1/global2/同prefix同seed・補充なし、各attemptとinvalid原因を保存。候補model/NN/fallback faultは候補loss、参照同faultはpair invalid、参照timeout/crash/no-completed-cp/lateは参照loss、共通identity/referee IPCはpair invalid。公開前fault/cancel全discard・公開後既公開不変の受信順政策を両側同じに固定し、遅延故障生成時刻の全知は主張しない。

入口は同一execute/mainをmock専用factory経由で実行できるようにする。importでbackend起動0、正token/同固定manifest/preregister/新critic受入れ＋coordinator freezeを照合し、未token/旧proof/既run/mismatchは拒否。実goは .66と今後の実backend/game-loop入口gateが揃うまで常にfalse。通常のCLIからmockfactoryを実runへ注入する経路は作らない。実backend未結線ならmanifestに明記し、未実行をentry_ready扱いしない。

std-only mockで96採番/同prefix先後/seed/identity/generation/合法prefix/goal先後/draw優先/score/Xi-L/invalid再試行上限/partial checkpoint・pause/deadline/signal・正token/既run拒否を実検査。無応答は一手Tで公開discardしcleanup pendingを待たない、次の実NNは旧activeNN/handle/live0またはcontrolledPID0→freshreadyの証拠まで禁止。cleanup永久待ち/fresh禁止、既signalCode/idempotenceはmockとして保存。実dummy/Browser/NNを今回起動しない。backend interfaceは新 .65 callerのcreate/通知/finish/stopに明確に接続できる形とし、任意prefixの供給・producer echo/最終postvalidationstampの必要gateを実装チェックリストにする。

初期startup-ready/load/warm/reclockは両側同ルールで手t0外でもwall/RSSに課金。最初のholdoutはready/freeze後に供給。以後t0はimmutable次入力供給可能時（直前公開stampを保守的な起点にできる場合はそのまま）、adapter/審判更新/序列化/ログ/pause監視・旧API残処理/stopACK/必要reload-readyを含め、都合よくresetしない。OS schedulingによるlateは救済0、CPU2単logical/両NNthread1/合計RAM8GiBと同caller費用を両者維持する。mainの長い同期Beads読取・全trace保存を手の直前に新導入せず、所有非同期pause監視/公開後private保存と必要安全チェックを設計する。費用を時計外へ逃がさない。

予算を再計算: worst思考48×2×200×.5=9600秒、startup400/retry1200/保存600=合計11800秒、停止reserve1.5。試合停止Oct2 00:30UTC、保存00:50/監督00:55/枠01:00、最遅開始Oct1 21:13:18.500UTC。これは完遂/tail保証でなくminimum入場条件、残不足ならno-go。元平均時間で縮小しない。実game-loop/public timerが超過した場合の外側guard停止とpartialを明示する。

## 受入れ・停止

同担当のPythonとNode別実装でPRNG/採番/score/retry/予算を再計算しても他役独立受入れではない。全mock成功・source停止/hash/自己PID0を本文前保存し、.66未完/実結線・実pause・終了回収・boundedwatchdog未検証を明記。明示runtime契約/独立実入口/新freeze前はactual_go=false、実送信・対局0。source/preregisterをいじって go を自己発行しない。重大な不足は役割・手段を区別して統括へ渡し、.66 writerや外部jobを直接steer/killしない。

旧 .49g287/62+82、.63元340秒、.65原2.26秒と検証max9.686>余裕9・公開後追加NN、旧32局/NI未立証/Sigma未達、深部/真合法200/no-legal/来歴配布・training overlap/一般rawview/entropy・容量/期限/scope/瞬間RSS欠測を保持。Atract/BORT/CB0とH1/H2/H3/H4を残す。受領claim開始を先記録、短い暫定報告・stopを先保存、backup/report。.67受入れ待ち、goal/他者close0。


親継続全文
# Sigma自律研究・継続枠 2026-10-01

契約版2。目標quoridor-4lc。統括01a0f31b-3409-75f2-a30e-453a50484f94。根拠はユーザーの明示継続/詳細委任（root入力01a0f2e9-357d-7ef3-a2fe-b16f80accda5）。開始2026-10-01T09:03:36.459834+00:00、終了2026-10-02T01:00:00Z（2026-10-02 10:00 JST）。本書は新しい実行枠であり、旧目標契約版2の初期04:00終了/未達/過去逸脱を保持する。旧文書・旧preregister・成績は変更しない。目標/比較A/通常製品規約維持/独立検証/権限は旧目標契約を継承する。

固定Sigmaと同計算資源・思考時間でnative/localおよびbrowserの非劣性を実測する。旧32局m8のnative.5625/browser.1875と両下限未達を保持。今回の新比較はcode/model/config/pool/T/g/m/CI/停止/責任分類を結果前に別事前登録し、旧結果へ後付け条件変更/標本統合をしない。未使用m10計画は参考として残すが、実入口/共通時計/資源gateと新deadlineを独立freezeするまで対局禁止。

予算はCPU全計4logical、RAM全計8GiB、LLM最大3（統括と新supervisorを含む）、正式CPU比較はCPU2単logical/推論threads1/GPU推論0/他の重い研究job停止。GPU研究は旧上限6GiB・1job30分・累積2h以内を保持し、今回は別配分前GPU/学習0。成果/依存は旧枠から累積12GiBを維持、リセット/12GiB追加ではない。旧限定保守課金6,588,000,723B・条件付き残6,296,901,165Bを開始時再確認する。初回新規予約: entry2GiB（guard1.75GiB）、steward128MiB、監督32MiB、統括文書32MiB。未配分は基準再確認後に統括が同12GiB内で配分。副次cache/途中展開/一時profileも計上。既存共有training/cacheは読取のみ、削除はこの枠が所有する再生成物だけを証拠保持の上で別に判断。

既存五役saved sessionを維持、新supervisorは既存App Serverに永続登録して観測専用で追加。App Server/toolchain再起動やモデル/effort変更をしない。新有料API/クラウド/第三者オンライン対局なし。主checkout製品/UI/描画/M2/commit/push/公開は対象外。研究worktreecodex/ai-sigmaで新copyに実装し旧入力をhashで固定。スケジューラーは主checkoutのpush済み操作入口を利用し、運用role定義/registry/専用configだけを用意する。

監督issuequoridor-4lc.40、20分周期/1turn180秒（新job120秒で停止し報告へ）、終了2026-10-02 00:55UTC、観測のみ。globalは3だがschedulerの起動閾値max_active_sessions=2として統括報告の起動1枠を残す。枠使用中はskipしsteerしない。変化なしは保存のみで静かに終了、意味ある停滞/失敗/期限資源/完了時にだけ統括へreportする。監督が設定や課題配分を変更しない。pause/終了はownedturnだけinterrupt確認し、外部jobは各ownerが回収する。dispatcherや監督の停止だけでNN停止を認定しない。

初回はquoridor-4lc.38stewardがscheduler準備/実運用/容量/資源台帳、quoridor-4lc.39experimentがORT入口・復旧gateを担当。途中から競合A共通tract/B分離ORT/C B0とH1backend/H2探索/H3時計・checkpoint/H4標本を更新し、通常判断は統括が実依頼する。別の選択が有望ならこの枠内で契約を作り替えるが、結果を見た正式判定緩和は行わない。

終了: 目標達成、ユーザーpause、上限/guard/異常、2026-10-02 01:00UTC。2026-10-02 00:50UTCまでに新重jobを止め、終了処理を確保する。全ownerはPID/starttick/command/hash/exit/資源/失敗/stopを先保存、報告は簡潔に詳細JSONへリンク。達成なら独立根拠で目標close、未達なら次の継続/停止理由を記録。予算を自動延長しない。各実行deadlineは本枠以下。担当へ実送信/受領をBeadsとdispatchに記録する。

継続委任は目標へ向けて継続する指示である。未達の場合は本枠終了前に統括が次枠の必要性/予算/検証を判断し、ユーザーへ通常詳細の再承認を求めず別契約として具体化できる。同一枠の期限や累積12GiBを黙って拡張しない。

## 契約版2の期限変更根拠

2026-10-01、操作元root 01a0f2e9-357d-7ef3-a2fe-b16f80accda5からユーザー明示指示を受領。「明日午前10:00」は2026-10-02T10:00:00+09:00 = 2026-10-02T01:00:00Z。開始時刻は維持し、旧継続枠終了2026-10-01T17:00:00Zから終了時刻だけ変更する。重い処理停止00:50UTC（09:50JST）、監督運用停止00:55UTC（09:55JST）、monitor回収00:58UTC、枠終了01:00UTC（10:00JST）。目標達成・pause・guard停止条件と時間以外のCPU/RAM/LLM/累積容量・許可範囲・独立検証は変更しない。

旧版SHA859bb777836cc0683e1ad7d1763a71fda60c75d2d6391290cef28771589a81a2を.artifacts/ai-sigma/continuation-20261001/DEADLINE-20261002-1000/continuation-version1.mdへ保全。閉じた実験や旧個別契約の処理/提出期限、事前登録、旧失敗/逸脱を遡及延長しない。新実験・比較は別契約で結果前に固定する。統括.52が正本/Beads、steward.53が既存所有範囲の運用契約/config/reload/monitor更新と実反映を担当する。


writer .65最終報告（独立受入れまだ）
EXPERIMENT_REPORT SIGMA-FAIR-STREAMING quoridor-4lc.65 / trial1 / contract1 / final

候補・固定Sigma-Webを同Node caller／完成通知／検証終了cutoff／早いsealへ実接続した。最終revision3の一窓は通常24/24合法checkpoint、NN0終端4、取消・初回無し・cutoff跨ぎ・busyを含む計36要求を完了した。原revision2の23/24・2263.488msの失敗を別分母で保持する。候補単手診断の有限支持であり、正式公平性・tail保証・棋力・採用・NI・目標達成を認定しない。actual_go=false、game/holdout/build/取得/GPU/学習/委譲0。受入れ待ちin_progress。

17:20:23UTC受領、親版2／自契約全文・ready/show/pause後本人claim/開始。処理18:45:23、新job18:40:23、提出19:00:23。.63は統括の限定受入れ理由で本人closeし、元340210.191ms・取消ACK欠測・時計no-goを保持。.64他者close0。暫定報告と初期stopを先保存した。

同一owned Worker/ORT sessionでengineを切り替え、完成root展開またはbackup完了ごとにimmutable cpをpostMessage→Playwright binding→Nodeへ通知する。Nodeはproducer echoとengine/ID/gen/epoch/prefix/key/history/model/schema/limits/token/sequence、合法集合、型/finite/strict value/prior/statsを検査し、copy/freeze後の検証終了時刻がcutoff以上ならcommitしない。seal時はNN/Worker照会・追加finishを行わず、保存cacheの必要な検査・encoding後にNode stampを取る。大きいtree/traceは公開後のprivate保存。

T500/reserve89/commit余裕9/cutoff402/seal411は両側固定、再選定0。各版NN0校正30件（warm10/steady20、推論成功と区別）のsteady最大は原59.747／最終70.186msで89ms内。最終検証最大9.686msは9msを上回るため、固定余裕の全期間保証へ格上げしない。page/Worker開始終了ping各12、時計区間・drift・早側換算を保存した。

| 最終一窓の通常要求 | 候補 | 参照 |
| --- | ---: | ---: |
| 合法・期限内 / 分母 | 12/12 | 12/12 |
| steady | 9/9 | 9/9 |
| p50 ms | 412.603 | 414.072 |
| p95（nearest rank）/ max ms | 416.982 | 419.441 |
| 公開時session.run API区間内 | 6/12 | 10/12 |
| 取消→次要求の停止待ち ms | 31.835 | 28.320 |

参照C1/FPU.2/temp0/合法順/first tie/元bestAction/100000sim・root展開sim外、候補PUCT1.5/Q0/seed1979/原finish/4096sim/512node/depth24を保持した。参照はuncapped node/depthをnullと明示。参照root visits=sim+1／edge visits=sim、候補edge visits=sim−1を別規約で検査し、公開Actionをreceiverで再選択しない。公開valueは候補root NN手番value、参照root qValueであり、同statsに偽装しない。

各版の参照原instrumented対照と完成通知wrapperは3golden×8sim＝6検索。最終cp・全root visits/prior/value・全tree backup値・root context一致、通知はroot込み9回。upstream原文と.16/.18/.21移入元のMCTSNode/backup/selectLeaf/pickFromVisitsは原文一致を確認し、clock/RuleA/transport patchはpristineと区別した。保存候補24cpの独立算術も一致、control NN再実行0。新candidate root3件＋reference control6件の648bits/137NN/prior gateを通常診断前に通した。最終主要求の保存rootは20736features bits／4384NN要素／公開prior3088、失敗0、最大NN差3.576279e−6／prior差1.594364e−6。

最終境界12件は各engineのcancel→次通常・legal goal／人工200・初回無し・cutoff跨ぎ・caller busy。終端NN0は411.319–414.059ms。初回無し／検証跨ぎはnull、busyは510.422／510.127ms late/null。fault・遅配・旧世代・偽binding・未完成・fallback・参照訪問規約の反証はNN0 mockで分離（両側26・分類16・入口拒否5）。preseal受信fault/cancelは全discard、postseal通知は既公開不変の受信順政策。未知／遅延したProducer故障生成時刻の全知を主張しない。

原一窓の失敗はreference N22がadapter前に2263.488msを消費してNN未開始。前公開stampはリセットせず、原candidate公開後の旧処理stop ACK最大2257.769msも保持した。同期Beads読取を含む経路の残差は完全な専用spanを欠くため、全遅延をBeads単独へ断定しない。一原因修正でowned非同期監視へ移し、uncapped参照metadataも一原因修正、T/条件/順序/分母は不変で修正版を別一窓にした。原36件を成功へ付け替えず、標本統合0。算術helperが「未dispatchのexpired要求にもWorker ACK必須」と誤認した失敗も保存し、既実行NN再測定0で訂正した。

最終全NNは前探索の実ACK後（時計誤差込み最小slack1.933ms）、handles/activeNN/live_searches=0を確認して次NNへ。最終45 ACK、Model dropも0。公開後のAPI残処理上限は候補50.725／参照34.344ms、stop ACKまで最大60.428／50.619msを隠さず次t0＝前公開stampへ課金した。caller無効化はWorker同期NNの割込みを保証せず、公開後も旧NN開始が候補3／参照1件あった。API await区間はinner kernel命令時刻ではない。

本文前runtime/source-stop・hashafterを保存。旧入力675 checks／最終source62 checks一致、最終source SHA `b66988de59787c3b955d54fe15a894887b237b7430ceae1710db827880a698b1`。sole-root/subreaper/boot-PID-starttickの限定回収、4 browser窓forced、追跡243identity不在（停止JSONの更新後は追加NN0 helperも含む）。自然終了・全期間証明へ格上げしない。全観測TID CPU2／NNthreads1、RAM観測最大1,939,025,920B、保存約61.4MB＋最終metadata、112MiB guard内・既entry2GiB予約内／追加予約0。監視子も同CPU/RSS/保存へ課金し、正式無競合速度としない。瞬間peak・背景負荷時系列・初期短command PID/RSS・全CPU累積は欠測を保持。12GiB台帳は減額／リセット0、全ownerの現在量を独立再測定したとはしない。

次は独立最終main／数値／時計／ownership／責任分類gateと、新比較preregister・統括freeze。参照のCPU渡し・残処理も共通callerへ課金する実装を示したが、有限3goldenを正式公平対戦へ外挿しない。A tract/B ORT/C B0、H1 backend/H2探索/H3時計・cp/H4標本、旧32局NI未立証・g287・62+82・元340秒・容量／期限／scope逸脱、真合法200/no-legal・一般rawview/任意deep tree/entropy/training overlap未確認を保持する。

詳細: [preregister](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/preregister.json)、[修正登録](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/repair-preregister.json)、[両窓analysis](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/analysis.json)、[原公開raw](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/SUITE65-01/public-requests.json)、[最終公開raw](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/SUITE65-02/public-requests.json)、[source-stop](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/source-stop.json)、[runtime-stop](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/runtime-stop-final-before-document.json)、[final-manifest](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/final-manifest.json)。再現command/source snapshot/PID/resources/exitは各 *.started.json/*.process.json/job-source、最終実入口はtools/ai-sigma-fair-streaming/entry.cjs。書込み停止、追加NN0、独立受入れ待ち。

締切受領: 追加NN0 saved-control65-finalはNEW_JOB_CUTOFFで起動前拒否、再起動0。追加保存control数値再確認helperは未実行。既完了の保存24cp equality gateと、新root数値／prior gateを分離する。runtime/source-stopを再保存後に本文を固定した。詳細deadline-job-refusal.json。


統括hash/currentPID/算術
{
  "UTC": "2026-10-01T18:49:20.690186+00:00",
  "hash_checks": {
    "final-manifest.json": {
      "count": 771,
      "mismatches": []
    },
    "source-frozen.json": {
      "count": 62,
      "mismatches": []
    },
    "input-before.json": {
      "count": 675,
      "mismatches": []
    }
  },
  "recorded_identities": 243,
  "same_identity_live": [],
  "windows": {
    "SUITE65-01": {
      "candidate": {
        "n": 12,
        "eligible": 12,
        "median_ms": 412.2898014932871,
        "max_ms": 415.0111670047045
      },
      "reference": {
        "n": 12,
        "eligible": 11,
        "median_ms": 413.2548154965043,
        "max_ms": 2263.4878479987383
      }
    },
    "SUITE65-02": {
      "candidate": {
        "n": 12,
        "eligible": 12,
        "median_ms": 412.6031375005841,
        "max_ms": 416.9822230041027
      },
      "reference": {
        "n": 12,
        "eligible": 12,
        "median_ms": 414.0716419965029,
        "max_ms": 419.4414120018482
      }
    }
  },
  "raw_windows_not_pooled": true,
  "actual_go": false,
  "independent_runtime_done_by_coordinator": false,
  "critical_hashes": {
    ".artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/final-manifest.json": "8778edbf1638772b072b0b9deb5bf07b7dad61c2fe8982987c5ceec5a56e5132",
    ".artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/source-frozen.json": "b66988de59787c3b955d54fe15a894887b237b7430ceae1710db827880a698b1",
    ".artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/runtime-stop-final-before-document.json": "c437f48ae7d7f84a5b18c1d4366df429de75d86e3e5f23a7d90fad923be80fc2",
    ".artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/source-stop.json": "1ae79d14bbdc3d9c0ff1243b760719fc09365c3cc8fa07651d11969504831a3b",
    ".artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/preregister.json": "9da324299911c87e7e40b877092defcec6755f01a34326c68c1bd5bbbf199bab",
    ".artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/repair-preregister.json": "aa517cb6f2d2599fe6d86e48e79de1bbe81e646d5f0736630e8615315e822a82",
    "docs/reports/ai-sigma-experiment-fair-streaming.md": "2fda64fe0652fd0f0b5037f0405856b46d3819ed7a2dc6504bb5410f91a33e4a"
  }
}

報告先coordinator、communication --issue quoridor-4lc。preregister/sourceを更新して自己actual freezeを発行しない。