import json, math, pathlib, datetime
P=pathlib.Path(__file__).parent
S=P.parent/'SIGMA-STREAMING-COMPARISON32-PLAN'
load=lambda p:json.loads(p.read_text())
reg=load(S/'preregister.json'); dictionary=load(S/'prefix-dictionary.json')
def draws(seed):
    state=seed
    while True:
        state ^= (state<<13)&0xffffffff
        state ^= state>>17
        state ^= (state<<5)&0xffffffff
        yield state
def integer(stream,n):
    ceiling=4294967296-4294967296%n
    for value in stream:
        if value<ceiling:return value%n
def permute(values,seed):
    result=list(values); stream=draws(seed)
    for length in range(len(result),1,-1):
        j=integer(stream,length); result[length-1],result[j]=result[j],result[length-1]
    return result
selected=permute([i for i in range(64) if i not in reg['excluded_sent8']],2026100501)[:32]
ordered=permute(selected,2026100502); colors=draws(2026100503)
assert selected==reg['selected_indices'] and ordered==reg['ordered_indices']
games=[]
for ordinal,(index,pair) in enumerate(zip(ordered,reg['pairs']),1):
    color=1+integer(colors,2)
    assert pair['pair']==ordinal and pair['pool_index']==index and pair['candidate_color_order']==[color,3-color]
    assert dictionary[pair['prefix_ref']]['pool_index']==index
    for side,game in enumerate(pair['games']):
        assert game['game']==2*ordinal-1+side and game['candidate_color']==[color,3-color][side]
        assert game['reference_color']==3-game['candidate_color'] and game['seed']==1979
        games.append(game['game'])
assert games==list(range(1,65)) and len(set(ordered))==32
width=math.sqrt(math.log(20)/(2*32)); scenarios=[]
for name,case in load(S/'compact-scenarios.json').items():
    completed=[]; counts={}; invalid=0
    for attempt in case['attempts']:
        pair=reg['pairs'][attempt['pair']-1]
        assert attempt['prefix_ref']==pair['prefix_ref'] and attempt['seed']==1979
        assert attempt['game_numbers']==[g['game'] for g in pair['games']][:len(attempt['game_numbers'])]
        assert attempt['attempt']==counts.get(attempt['pair'],0); counts[attempt['pair']]=attempt['attempt']+1
        if attempt['invalid']:invalid+=1
        elif len(attempt['scores'])==2:completed.append(sum(attempt['scores'])/2)
        assert all(x in (0,.5,1) for x in attempt['scores'])
    assert max(counts.values())<=2 and case['retries']<=2
    score=case['score'];mean=sum(completed)/len(completed) if completed else None
    assert score['completed_pairs']==len(completed) and score['mean']==mean
    assert score['complete']==(len(completed)==32)
    assert score['L']==(max(0,mean-width) if len(completed)==32 else None)
    if name in ('pause','guard','deadline','signal'):assert case['stop']==name and score['L'] is None
    if name=='one_invalid':assert invalid==1 and case['retries']==1 and score['complete']
    if name=='global_exhausted':assert case['retries']==2 and case['stop']=='retry_exhausted'
    if name=='pair_exhausted':assert invalid==2 and case['stop']=='retry_exhausted'
    if name in ('all64','all_draw'):assert mean==.5
    if name=='candidate_loss':assert mean==0
    if name=='reference_loss':assert mean==1
    scenarios.append({'scenario':name,'completed':len(completed),'retries':case['retries'],'stop':case['stop'],'L':score['L']})
stop=datetime.datetime.fromisoformat('2026-10-02T00:30:00+00:00')
worst=64*200*.5+400+1200+600
latest=stop-datetime.timedelta(seconds=worst+1.5)
assert latest.isoformat()=='2026-10-01T22:06:38.500000+00:00'
assert (stop-(latest+datetime.timedelta(milliseconds=1))).total_seconds()<worst+1.5
out={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selected':selected,'ordered':ordered,'numbered_games':64,'scenarios':scenarios,'width':width,'L_mean_half':.5-width,'mean_required_strictly_greater':.45+width,'worst_seconds':worst,'reserve':1.5,'latest_entry':latest.isoformat(),'NI_supported':False,'native_goal_supported':False,'control_symbol_arithmetic_not_fault_classifier':True,'full_host_unused_not_audited':True,'source_binding':reg['source_binding'],'actual_go':False}
(P/'independent-plan.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'plan':True,'scenarios':len(scenarios),'width':width,'latest':latest.isoformat()}))
