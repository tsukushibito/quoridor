from pathlib import Path
import json,hashlib,datetime,difflib,shutil,os
R=Path('/workspaces/quoridor/.worktree/ai-sigma');O=Path(__file__).resolve().parent;A=O.parent/'SIGMA-STREAMING-NUMERIC-ORDER';P=O.parent/'SIGMA-STREAMING-COMPARISON32-PLAN';T=R/'tools/ai-sigma-streaming-numeric-order';S=O/'source';S.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();checks={};hashes={}
fixed={A/'entry-manifest.json':'c06293774b4c318bb5877db11efa246bd5c6087f0efa21bdc99871e7f32098a8',A/'source-frozen-before-runtime.json':'3de57bea803b1573c248c8164b362d4d644debb4fe1b24dbcb575a6b1effe3db',A/'final-manifest.json':'73098ca0000d8bce335390ebede2b541e2272b94035e48ce1087478879fd3005',P/'preregister.json':'126f5a6dade5e44f69f007dc57580772193c809cba8ff08e2a99f162d204db1d',P/'prefix-dictionary.json':'86397a79530ad722ab58831d130fde7e40d95ff747b3e88ec290c21f23c577ef'}
for f,h in fixed.items():assert sha(f)==h;hashes[str(f)]=h
for f in [A/'final-manifest.json',A/'entry-manifest.json',A/'input-before.json',P/'final-manifest.json',P/'input-before.json']:
 x=json.loads(f.read_text());rows=x['checks'] if isinstance(x,dict) else x;bad=[]
 for q in rows:
  h=sha(q['path']);hashes[q['path']]=h
  if h!=q.get('sha256',q.get('expected')):bad.append(q['path'])
 assert not bad;checks[str(f)]={'count':len(rows),'mismatch':bad}
tracked={}
def scan(x):
 if isinstance(x,dict):
  pid=x.get('pid',x.get('runner_pid'));tick=x.get('start_ticks',x.get('starttick',x.get('runner_starttick')))
  if isinstance(pid,int) and isinstance(tick,int):tracked[(pid,tick)]=x
  for v in x.values():scan(v)
 elif isinstance(x,list):
  for v in x:scan(v)
for base in [A,P]:
 for f in base.glob('*.process.json'):scan(json.loads(f.read_text()))
live=[]
for pid,tick in tracked:
 try:
  st=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
  if int(st[19])==tick:live.append({'pid':pid,'starttick':tick})
 except OSError:pass
assert not live
# Only current observation; no cross-owner signals.
heavy=[]
for d in Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:
  raw=(d/'cmdline').read_bytes().split(b'\0');exe=Path(raw[0].decode()).name;cmd=b' '.join(raw).decode(errors='replace')
  if exe in ['chrome','chromium','chrome-headless-shell'] or exe=='node' and ('/tools/ai-sigma-' in cmd or '/CRITIC-' in cmd):heavy.append({'pid':int(d.name),'cmd':cmd})
 except (OSError,ValueError):pass
assert not heavy
(O/'independent-input-before.json').write_text(json.dumps({'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'input_hashes':hashes,'identity_count':len(tracked),'same_live':live,'other_heavy_candidates':heavy,'current_only_not_global_history':True},indent=2)+'\n')
# Only path/deadline/guard/run identity patches; core protocol and algorithms immutable.
patches=[]
for f in T.iterdir():
 if not f.is_file():continue
 old=f.read_text();new=old
 new=new.replace("path.resolve(__dirname,'../..')",json.dumps(str(R)))
 new=new.replace("path.resolve(__dirname,'../../.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-NUMERIC-ORDER')",json.dumps(str(O)))
 new=new.replace("ROOT+'/.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-NUMERIC-ORDER'",json.dumps(str(O)))
 if f.name=='runner.py':
  new=new.replace("OUT=TOOL.parents[1]/'.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-NUMERIC-ORDER'",f"OUT=Path({str(O)!r})").replace("2026-10-01T21:35:00+00:00","2026-10-01T22:00:00+00:00").replace('3758096384','2684354560').replace('STORAGE_GUARD=117440512','STORAGE_GUARD=37748736').replace("'21:35:00Z'","'22:00:00Z'").replace("'21:30:00Z'","'21:55:00Z'")
 if f.name=='budget.cjs':new=new.replace('GUARD=117440512','GUARD=37748736')
 if f.name=='golden-driver.cjs':
  new=new.replace('GOLDEN72-ONCE','CRITIC74-ONCE').replace('2026-10-01T21:35:00Z','2026-10-01T22:00:00Z').replace("diagnosticRequests:pr.requests","forecast:{profile_temp:25165824,trace_log:1048576,public_private_raw_clock:4194304,ending:1048576},diagnosticRequests:pr.requests")
 # Fixed source absolute numeric reference path (no changing fixtures/limits).
 new=new.replace("path.resolve(__dirname,'../../.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json')",json.dumps(str(R/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json')))
 (S/f.name).write_text(new)
 if old!=new:patches.append({'file':f.name,'original_sha256':sha(f),'copy_sha256':sha(S/f.name),'diff':''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(f),tofile=str(S/f.name)))})
for name in ['preregister.json','entry-manifest.json','phaseA-gates.json','golden-preregister.json']:shutil.copyfile(A/name,O/name)
pr=json.loads((O/'golden-preregister.json').read_text());pr['independent_issue']='quoridor-4lc.74';pr['run_id']='CRITIC74-ONCE';pr['source_frozen_sha256']=fixed[A/'source-frozen-before-runtime.json'];pr['forecast']={'profile_temp':25165824,'trace_log':1048576,'public_private_raw_clock':4194304,'ending':1048576};pr['retry']=0;pr['one_window_only']=True;(O/'golden-preregister.json').write_text(json.dumps(pr,indent=2)+'\n')
tok={'purpose':'golden','actual_go':False,'issue':'quoridor-4lc.72','goal':'quoridor-4lc','freeze_token':'critic74-diagnostic-only-no-actual-authority','run_id':'CRITIC74-ONCE','preregister_sha256':sha(O/'preregister.json'),'entry_manifest_sha256':sha(O/'entry-manifest.json'),'phaseA_sha256':sha(O/'phaseA-gates.json'),'golden_preregister_sha256':sha(O/'golden-preregister.json')};(O/'golden-token.json').write_text(json.dumps(tok,indent=2)+'\n');(O/'copy-patches.json').write_text(json.dumps(patches,indent=2)+'\n')
size=sum(f.stat().st_blocks*512 for f in O.rglob('*') if f.is_file());dirs=sorted([p for p in (R/'.artifacts/ai-sigma').rglob('*') if p.is_dir() and p.name.startswith('CRITIC-')],key=lambda p:len(p.parts));tops=[]
for p in dirs:
 if not any(q in p.parents for q in tops):tops.append(p)
combined=sum(f.stat().st_blocks*512 for p in tops for f in p.rglob('*') if f.is_file())+sum(f.stat().st_blocks*512 for f in (R/'docs/reports').glob('ai-sigma-critic*.md'));forecast=sum(pr['forecast'].values());assert size<8*2**20 and size+forecast<36*2**20 and combined+forecast<112*2**20
(O/'headroom-before-NN.json').write_text(json.dumps({'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prepare':size,'detected_combined':combined,'forecast':pr['forecast'],'forecast_total':forecast,'new_guard':36*2**20,'combined_guard':112*2**20,'remaining0':not live,'other_heavy0':not heavy,'no75input':True,'not_instant_peak_guarantee':True},indent=2)+'\n');print(json.dumps({'checks':checks,'identity_count':len(tracked),'patches':len(patches),'prep':size,'combined':combined,'forecast':forecast,'ready_for_once':True}))
