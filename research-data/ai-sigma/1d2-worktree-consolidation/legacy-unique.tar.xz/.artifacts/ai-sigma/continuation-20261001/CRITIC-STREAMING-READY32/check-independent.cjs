'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto');
const O=__dirname,ROOT='/workspaces/quoridor/.worktree/ai-sigma',J=require('./source/judge.cjs'),read=p=>JSON.parse(fs.readFileSync(p)),same=(a,b)=>assert.equal(JSON.stringify(a),JSON.stringify(b));
const S=path.join(O,'../SIGMA-STREAMING-COMPARISON32-PLAN'),dict=read(S+'/prefix-dictionary.json'),pool=read(ROOT+'/.artifacts/ai-sigma/continuation-20261001/SIGMA-CONTINUATION-MATCH-PLAN/snapshot/pool64.json').pool;
let prefixCount=0;const keys=new Set();
for(const d of Object.values(dict)){
 let state=J.state([]),ids=[];for(const a of d.legal_prefix){assert.equal(J.terminalResult(state),null);assert(state.getLegalActions().some(b=>J.sameAction(a,b)));ids.push(J.rustAction(state,a));state=state.next(a);}
 same(ids,d.rust_prefix);same(J.context(state),d.context);same(d.legal_prefix,pool[d.pool_index].legal_prefix);assert(!keys.has(d.context.key));keys.add(d.context.key);prefixCount++;
}
const fixture=read(ROOT+'/.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json').fixtures,refs=read(ROOT+'/.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json');
let featureCount=0,NNCount=0,priorCount=0,maxDiff=0;const rows=[];
function checkNumeric(n,state,fid,engine,cp){
 assert.equal(n.features_bits.length,648);assert.equal(n.policy_logits.length,136);assert(Number.isFinite(n.value)&&Math.abs(n.value)<=1);assert(n.policy_logits.every(Number.isFinite));
 const feat=state.toNNInput(),bits=Array.from(new Uint32Array(feat.buffer,feat.byteOffset,648));same(n.features_bits,bits);featureCount+=648;
 const ref=refs.find(r=>r.id===fid);assert(ref);for(const [x,y] of [...n.policy_logits.map((x,i)=>[x,ref.policy_logits[i]]),[n.value,ref.value]]){assert(Math.abs(x-y)<=1e-4+1e-4*Math.abs(y));maxDiff=Math.max(maxDiff,Math.abs(x-y));NNCount++;}
 if(cp){
  const actions=Array.from(state.getLegalActions()),unsorted=actions.map(a=>J.rustAction(state,a)),expected=engine==='candidate'?[...unsorted].sort((a,b)=>a-b):unsorted;
  same(cp.root_edges.map(e=>e[0]),expected);assert.equal(new Set(expected).size,expected.length);
  const entries=actions.map(a=>{let k=J.actionToIndex(a,9);if(!state.isPlayer1Turn()){if(k<8)k=[1,0,2,3,6,7,4,5][k];else {let v=k-8;k=8+(v>=64?64:0)+(7-Math.floor((v%64)/8))*8+v%8;}}return [J.rustAction(state,a),n.policy_logits[k]];});
  const max=Math.max(...entries.map(x=>x[1])),den=entries.reduce((s,x)=>s+Math.exp(x[1]-max),0),map=new Map(entries);
  for(const [id,p,visits,value]of cp.root_edges){let q=Math.exp(map.get(id)-max)/den;assert(Number.isFinite(p)&&p>=0);assert(Math.abs(p-q)<=1e-4+1e-4*Math.abs(q));assert(Number.isInteger(visits)&&visits>=0&&Number.isFinite(value));priorCount++;}
  const edgeVisits=cp.root_edges.reduce((s,e)=>s+e[2],0);
  if(engine==='candidate'){assert.equal(edgeVisits,cp.simulations-1);assert.equal(cp.policy_fallbacks,0);assert.equal(cp.value_fallbacks,0);}
  else {assert.equal(edgeVisits,cp.simulations);assert.equal(cp.root_visits,cp.simulations+1);}
 }
 rows.push({fid,engine,cp:!!cp,P2:!state.isPlayer1Turn()});
}
const R=O+'/real-CRITIC74-ONCE-session1',priv=read(R+'/private-after-public.json');
for(const [id,p]of Object.entries(priv)){const raw=read(R+'/public-'+id+'.json');checkNumeric(p.numeric[0],J.state(raw.identity.legal_prefix),raw.identity.fixture_id,raw.identity.engine,raw.private_cp?.owned?.cp);if(raw.identity.engine==='candidate'&&raw.response.accepted)assert(Math.abs(raw.response.value-p.numeric[0].value)<=1e-4+1e-4*Math.abs(p.numeric[0].value));}
const handCounts={features:featureCount,NN:NNCount,prior:priorCount};
for(const f of fs.readdirSync(R).filter(x=>x.startsWith('startup-root-'))){const row=read(R+'/'+f);const state=J.referenceState(fixture.find(x=>x.id===row.fixture_id));checkNumeric(row.row,state,row.fixture_id,row.engine,null);assert.equal(row.handles,0);assert.equal(row.activeNN,0);assert.equal(row.live_searches,0);assert.equal(row.active,false);}
fs.writeFileSync(O+'/independent-replay-numeric.json',JSON.stringify({UTC:new Date().toISOString(),prefixCount,legal_history_context:true,handCounts,startup_separate:{features:featureCount-handCounts.features,NN:NNCount-handCounts.NN},rows,maxNNdiff:maxDiff,NN_reexecuted:0,all_passed:true},null,2));
async function mocks(){
 const E=require('./source/match-entry.cjs'),M=require('./source/mock-factory.cjs'),F=require('./source/final-envelope.cjs');let count=0;
 for(const delay of [88,89,90]){const c=M.virtualClock(),t=c.now(),id={engine:'candidate',request_id:'CUT74',generation:1,epoch:1,legal_prefix:[],history:J.context(J.state([])).history,fixture_id:'initial-p1',model:'M',schema:'S',limits:{},t0_ms:t,deadline_ms:t+500};c.advance(411);const x=F.finalize({echo:id,accepted:true,checkpoint:true,action:13,value:0,fallback:0},id,c,{encodingDelay:delay});assert.equal(x.accepted,delay===88);assert.equal(x.stamp_ms-t,411+delay);assert.equal(x.elapsed_ms,x.stamp_ms-t);count++;}
 const token={...read(O+'/golden-token.json'),purpose:'mock',run_id:'INDEPENDENT74-MOCK'};fs.writeFileSync(O+'/independent-mock-token.json',JSON.stringify(token));
 const requests=['OUTPUT_FINITE_RANGE','OUTPUT_SHAPE','FEATURE_FINITE','FEATURE_SHAPE','STRICT_VALUE','FINAL_IDENTITY'].flatMap(error=>['candidate','reference'].map(engine=>({id:error,engine,error,legal_prefix:[]})));
 const r=await E.diagnosticMockMain({argv:['--diagnostic',O+'/independent-mock-token.json'],createBackend:M.factory('host_fault',[]),clock:M.virtualClock(),deadline:Infinity,forecast:{NN0_mock_raw:2097152},diagnosticRequests:requests,diagnosticFaultGames:true});
 const games=r.events.filter(x=>x.kind==='fault_game');assert.equal(games.length,12);for(let i=0;i<12;i++)assert.equal(games[i].result.kind,requests[i].engine==='reference'||requests[i].error==='FINAL_IDENTITY'?'invalid_pair':'engine_loss');
 fs.writeFileSync(O+'/independent-mock-gate.json',JSON.stringify({UTC:new Date().toISOString(),encoding_deadline_cases:count,actual_host_pending_classifier_cases:12,NN:0,all_passed:true,actual_go:false},null,2));
}
mocks().then(()=>console.log(JSON.stringify({prefixCount,handCounts,maxDiff,all_passed:true}))).catch(e=>{fs.writeFileSync(O+'/independent-check-failure.json',JSON.stringify({error:e.message,stack:e.stack}));throw e;});
