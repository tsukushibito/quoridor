import pathlib,json,datetime,hashlib
P=pathlib.Path(__file__).parent
load=lambda p:json.loads(p.read_text())
R=P/'real-CRITIC74-ONCE-session1'
start=load(R/'browser/clock-start.json');end=load(R/'clock-end-bound.json')
clocks={}
for name in ['page','worker']:
    for label,data in [('start',start[name]),('end',end[name])]:
        lo=max(s['remote']-s['end']-.1 for s in data['samples']);hi=min(s['remote']-s['start']+.1 for s in data['samples'])
        assert len(data['samples'])==12 and lo<=hi
        assert abs(lo-data['lo_ms'])<1e-6 and abs(hi-data['hi_ms'])<1e-6
    assert end[name]['lo_ms']<=start[name]['hi_ms'] and end[name]['hi_ms']>=start[name]['lo_ms']
    clocks[name]={'start_lo':start[name]['lo_ms'],'start_hi':start[name]['hi_ms'],'end_overlap':True,'samples_each':12}
rows=[];previous=None;prior_ack=None
priv=load(R/'private-after-public.json')
for f in sorted(R.glob('public-*.json')):
    d=load(f);id=d['identity'];r=d['response']; elapsed=r['stamp_ms']-id['t0_ms']
    assert abs(elapsed-r['elapsed_ms'])<1e-6
    if previous is not None:assert id['t0_ms']==previous
    previous=r['stamp_ms']
    assert type(r['accepted']) is bool and type(r['checkpoint']) is bool
    assert id['deadline_ms']-id['t0_ms']==500 and id['seal_ms']-id['t0_ms']==411 and id['commit_cutoff_ms']-id['t0_ms']==402
    assert r['referee_verified'] is True
    if r['accepted']:assert r['action'] is not None and r['checkpoint'] and elapsed<500 and -1<=r['value']<=1 and r['fallback']==0
    else:assert r['action'] is None
    for b in d['bindings']:
        if b['accepted'] and b['kind']=='snapshot':assert b['node_validation_finished_ms']<id['commit_cutoff_ms']
    spans=[{'start':s['session_run_start_ms'],'end':s['session_run_end_ms']} for s in priv[id['request_id']]['NN']]
    start_early=min(s['start'] for s in spans)-start['worker']['hi_ms']
    slack=start_early-prior_ack if prior_ack is not None else None
    if slack is not None:assert slack>=0
    ack=load(R/('stopACK-'+id['request_id']+'.json'))
    assert ack['identity']==id and ack['stop']['handles']==ack['stop']['activeNN']==ack['stop']['live_searches']==0 and ack['stop']['active'] is False
    prior_ack=ack['node_received_ms']
    rows.append({'engine':id['engine'],'id':id['request_id'],'elapsed_ms':elapsed,'accepted':r['accepted'],'error':r['error'],'next_clock_exact':True,'NN_API_calls':len(spans),'old_ACK_to_first_API_start_early_slack_ms':slack,'stop_ACK0':True})
trace=[json.loads(s) for s in (R/'browser/cleanup.jsonl').read_text().splitlines()]
observer=load(P/'pause-monitor-stop.json');failed=[s for s in observer['rows'] if s.get('signalCode')=='SIGTERM']
signals=[s for s in trace if s['kind']=='signal_sent']
matches=[]
for child in failed:
    for signal in signals:
        identity=signal.get('identity',{})
        if identity.get('pid')==child['PID']:
            matches.append({'observer':child,'cleanup_signal':signal['signal'],'cleanup_UTC':signal['UTC'],'identity':identity})
assert matches
old=P.parent/'SIGMA-STREAMING-NUMERIC-ORDER'
oldrows=[]
for session in sorted(old.glob('real-GOLDEN72-ONCE-session*')):
    for f in session.glob('public-*.json'):
        d=load(f);id=d['identity'];r=d['response'];oldrows.append({'id':id['request_id'],'fixture':id['fixture_id'],'engine':id['engine'],'elapsed_ms':r['stamp_ms']-id['t0_ms'],'accepted':r['accepted'],'error':r['error'],'request_was_never_submitted':d.get('request_was_never_submitted')})
assert len(oldrows)==11
out={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'independent_public':3,'planned_public':11,'not_executed':8,'independent_rows':rows,'clock_intervals':clocks,'observer_SIGTERM_matches_owned_cleanup':matches,'root_cause_scope':'observed owned cleanup signaled own async metadata child; startup/model/NN succeeded. Not a user pause or intrinsic NN failure. No retry.','old72_rows':oldrows,'old72_public':len(oldrows),'old72_late':[r for r in oldrows if r['elapsed_ms']>=500],'old72_success_not_replaced_by_this_window':True,'actual_go':False}
(P/'independent-clock-denominators.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'public':3,'old72':11,'matched_own_observer_signal':len(matches),'old72_late':out['old72_late']}))
