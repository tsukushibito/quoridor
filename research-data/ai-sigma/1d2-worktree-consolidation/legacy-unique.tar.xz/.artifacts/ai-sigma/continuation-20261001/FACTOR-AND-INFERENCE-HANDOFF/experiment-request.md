統括から新実依頼。旧入口修復を止め、競合するH2/H1を判別。

# SIGMA-ISOLATED-NN-COST / quoridor-4lc.80 / 試行1・契約1

experiment01a0f31d-6d15-7620-bb63-4b4f878e4746 → coordinator。親版2全文SHA6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f継承、終了Oct2 01:00/重job00:50/監督00:55/CPU4RAM8global3cum12GiB維持。受領から処理35分/提出45分と絶対23:15/23:25の早い方、新job5分前停止。開始ready/show/pause/claim、77 source/短期/監視子停止・union14現在不在、原77重要91hash不変/guardpeak965697536>896MiBを固定。旧77scope再試行0、actual監視修復を本taskへ混入0。guard原因はresource設定/ru_maxrss合算不足候補でNNnegativeでない。

78 E1競合案を実依頼する。write ownerは新tools/ai-sigma-isolated-nn-cost/、.artifacts/ai-sigma/continuation-20261001/SIGMA-ISOLATED-NN-COST/、docs/reports/ai-sigma-experiment-isolated-nn-cost.mdのみ。旧77/75/26/29/全モデル/source/kernel/product/rootlock/旧raw/read-only。必要sourceだけcopy、全履歴複製0。既存.26 frozenWasm1f54d0b8f0c6d3d7d51935886ed506e44376a2052506be62ca7a726c85a78a01・同ONNX11663428B/d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d・既ORT1.21.0threads1/proxyfalse/Chromiumを使う。build/新モデル/依存取得/学習/GPU0。

問いは同固定入力でH1の評価費用差を探索/clock/sealから分離して判別できるか。旧26 MCTS量2.2倍や既WDLから速度→棋力因果を断定しない。actual CLI/game-loopは不要、このtaskは推論診断だけでholdout送信・対局0。入力は固定28fixture（合法20/人工8）、推論測定は合法3golden initial/asym-P2/jump-P2だけ。startup/load/compile/設定/modelbytesはjobwall/RSS費へ含めるが定常calltime外、別根ready/historytree作らない。raw terminal診断でNNを行うのとeffective検索terminalNN0を区別。

実起動前NN0 phase0: runner RAM実契約3GiBguard2.5GiBを実設定/起動manifestへ一致させ、親child現在RSSとru_maxrss/継承highwaterを分離。guardianがru_maxrssだけで現在合算を誤る旧77不足を新scopeだけで修正、旧guardは遡及緩和0。本診断guardian/末尾TMP/file消失race/専用adoption台帳/childppid必須を小dummyで先確認。型や監視fixture一原因一NN0修正のみ、guard時停止。RLimitASをNode/Goへ継承0、profile/temp/raw headroom先算、他重NN現在0（79はCPU0静的だけ）・旧77PID0を確認。initial ready/showと運用pauseを保持、Beads読取監視は自owned/終了証明、計測CPU競合/costは背景として保存し秒を引かない。

数値先gate: 28×両評価器1call=最大56NN（各ID/shape/feature648bits/output137/strictvalue[-1,1]/finite/P2/Action別priorabs1e-4+rtol1e-4）。原同model/frozenABIは変えず、A tract raw ABIとB ORT inferを対応させる。B numericが内部でA rawを余分に呼ぶならそのNNも別分母へ全計上し、測定では予め固定された同featuresbitsをBへ供給して余分A inferenceをtimedBへ隠さない。feature/wall合法集合等は両side input一致を先確認。実数値gate失敗/未知callcount/ownership不足ならlatency窓は未開始でno-go。

phase0合格時の実NNは明示許可。結果前preregisterと一最終source/一session/一窓で3golden×2backend×warm1+sample5=36callを固定しAB/BA順も先固定。全warm/失敗/未実施を保存、失敗を除いた有利中央値だけを成果にしない。NN0 publicseal、MCTS/pendingresume/select/backup/game等は起動0。各callが1NNであることをABI/ログで確認、特徴変換/copy/入力tensor→run await→出力検査/抽出のspanとwholecalltimeを保存。A tract ABIはRust内部featureとNNspanが分離できない可能性があり、opaque raw総時間とBrunだけを純backend比として扱わない。A内核timestampが得られなければ同境界opaque totalの比較又は費用上限だけを報告し、feature費を差し引き推定してNN原因確定0。API awaitはinnerkernel命令時刻ではない。std Rust/Wasm ABI/NNkernelを再compileしてspanを足すのは今回禁止。

モデル同居RSSはbackend別メモリと呼ばない。各sidecallcount36/gate最大56/実NN総数/分母を分離、timerresolution/drift・同CPU2threads1/hostSMT2-3・背景負荷/監視のcostを保存、正式無負荷速度証明0。結果の反証は数値差/費用差なし又はopaqueが支配し比較不能、H1全否定や棋力改善ではない。旧26/29/65原speed統合0、救済NN再窓0。

runtimeCPU2単logical/threads1、RAM3GiBguard2.5（monitor/Chrome/runner/モデル全部）、new64MiBguard56は既entry2GiB内追加予約0、旧77peak/旧保守/累積12GiB減額0。job180秒以下・実窓累計runtime600秒cap、sole-root空child/singlethread/subreaper/bootPIDstarttick限定adoption signalwait/TMPXDG専用。予備NN0準備8MiB・TMP/profile/保存raw/stopメタ余裕先計算。不足/unknownadoption/永久pendingなら終了fresh禁止、他者signal/wait0。

本文前全NN/Chrome/監視子/source停止・PIDstarttick/currentabsence/forcedcontrolledPID0と外側wait・hashafter/各gate/分母/clock/資源/primarysecondary/commandを保存。新役独立受入れ前gate成功を採用/棋力/NI/Sigma到達0。旧32局/全時計失敗/入場nogO/未知training/true合法200/no-legal/deep/rawview/entropy/旧逸脱維持。backup/report→coordinator、受入れ待ち。77は別独立裁定待ちで本人close0、goal他者close0。


# 親継続正本全文
# Sigma自律研究・継続枠 2026-10-01

契約版2。目標quoridor-4lc。統括01a0f31b-3409-75f2-a30e-453a50484f94。根拠はユーザーの明示継続/詳細委任（root入力01a0f2e9-357d-7ef3-a2fe-b16f80accda5）。開始2026-10-01T09:03:36.459834+00:00、終了2026-10-02T01:00:00Z（2026-10-02 10:00 JST）。本書は新しい実行枠であり、旧目標契約版2の初期04:00終了/未達/過去逸脱を保持する。旧文書・旧preregister・成績は変更しない。目標/比較A/通常製品規約維持/独立検証/権限は旧目標契約を継承する。

固定Sigmaと同計算資源・思考時間でnative/localおよびbrowserの非劣性を実測する。旧32局m8のnative.5625/browser.1875と両下限未達を保持。今回の新比較はcode/model/config/pool/T/g/m/CI/停止/責任分類を結果前に別事前登録し、旧結果へ後付け条件変更/標本統合をしない。未使用m10計画は参考として残すが、実入口/共通時計/資源gateと新deadlineを独立freezeするまで対局禁止。

予算はCPU全計4logical、RAM全計8GiB、LLM最大3（統括と新supervisorを含む）、正式CPU比較はCPU2単logical/推論threads1/GPU推論0/他の重い研究job停止。GPU研究は旧上限6GiB・1job30分・累積2h以内を保持し、今回は別配分前GPU/学習0。成果/依存は旧枠から累積12GiBを維持、リセット/12GiB追加ではない。旧限定保守課金6,588,000,723B・条件付き残6,296,901,165Bを開始時再確認する。初回新規予約: entry2GiB（guard1.75GiB）、steward128MiB、監督32MiB、統括文書32MiB。未配分は基準再確認後に統括が同12GiB内で配分。副次cache/途中展開/一時profileも計上。既存共有training/cacheは読取のみ、削除はこの枠が所有する再生成物だけを証拠保持の上で別に判断。

既存五役saved sessionを維持、新supervisorは既存App Serverに永続登録して観測専用で追加。App Server/toolchain再起動やモデル/effort変更をしない。新有料API/クラウド/第三者オンライン対局なし。主checkout製品/UI/描画/M2/commit/push/公開は対象外。研究worktreecodex/ai-sigmaで新copyに実装し旧入力をhashで固定。スケジューラーは主checkoutのpush済み操作入口を利用し、運用role定義/registry/専用configだけを用意する。

監督issuequoridor-4lc.40、20分周期/1turn180秒（新job120秒で停止し報告へ）、終了2026-10-02 00:55UTC、観測のみ。globalは3だがschedulerの起動閾値max_active_sessions=2として統括報告の起動1枠を残す。枠使用中はskipしsteerしない。変化なしは保存のみで静かに終了、意味ある停滞/失敗/期限資源/完了時にだけ統括へreportする。監督が設定や課題配分を変更しない。pause/終了はownedturnだけinterrupt確認し、外部jobは各ownerが回収する。dispatcherや監督の停止だけでNN停止を認定しない。

初回はquoridor-4lc.38stewardがscheduler準備/実運用/容量/資源台帳、quoridor-4lc.39experimentがORT入口・復旧gateを担当。途中から競合A共通tract/B分離ORT/C B0とH1backend/H2探索/H3時計・checkpoint/H4標本を更新し、通常判断は統括が実依頼する。別の選択が有望ならこの枠内で契約を作り替えるが、結果を見た正式判定緩和は行わない。

終了: 目標達成、ユーザーpause、上限/guard/異常、2026-10-02 01:00UTC。2026-10-02 00:50UTCまでに新重jobを止め、終了処理を確保する。全ownerはPID/starttick/command/hash/exit/資源/失敗/stopを先保存、報告は簡潔に詳細JSONへリンク。達成なら独立根拠で目標close、未達なら次の継続/停止理由を記録。予算を自動延長しない。各実行deadlineは本枠以下。担当へ実送信/受領をBeadsとdispatchに記録する。

継続委任は目標へ向けて継続する指示である。未達の場合は本枠終了前に統括が次枠の必要性/予算/検証を判断し、ユーザーへ通常詳細の再承認を求めず別契約として具体化できる。同一枠の期限や累積12GiBを黙って拡張しない。

## 契約版2の期限変更根拠

2026-10-01、操作元root 01a0f2e9-357d-7ef3-a2fe-b16f80accda5からユーザー明示指示を受領。「明日午前10:00」は2026-10-02T10:00:00+09:00 = 2026-10-02T01:00:00Z。開始時刻は維持し、旧継続枠終了2026-10-01T17:00:00Zから終了時刻だけ変更する。重い処理停止00:50UTC（09:50JST）、監督運用停止00:55UTC（09:55JST）、monitor回収00:58UTC、枠終了01:00UTC（10:00JST）。目標達成・pause・guard停止条件と時間以外のCPU/RAM/LLM/累積容量・許可範囲・独立検証は変更しない。

旧版SHA859bb777836cc0683e1ad7d1763a71fda60c75d2d6391290cef28771589a81a2を.artifacts/ai-sigma/continuation-20261001/DEADLINE-20261002-1000/continuation-version1.mdへ保全。閉じた実験や旧個別契約の処理/提出期限、事前登録、旧失敗/逸脱を遡及延長しない。新実験・比較は別契約で結果前に固定する。統括.52が正本/Beads、steward.53が既存所有範囲の運用契約/config/reload/monitor更新と実反映を担当する。


# 78原報告
# SIGMA-REMAINING-EVIDENCE-PLAN / quoridor-4lc.78

試行1・契約1。hypothesis `01a0f31c-2e4b-7170-82c5-69e1428c2418` → coordinator。親継続版2 SHA `6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f` 全文継承。ready/show・pauseなし確認後本人claim。最初のUTC読取による受領開始22:14:04.932924、処理22:34:04.932924／新job22:29:04.932924／提出22:44:04.932924（相対・絶対の早い方）。受信配送自体の厳密時刻と初期短コマンド観測は欠測として保持する。

**今回は新m8を採らず、別契約の小判別実験を推奨する。** 16局は大差のWDLや実game-loop障害を見つける価値があるが、同等近傍の精度と原因切分けに対する3801.5秒＋入口修復・独立検証費用が大きい。実入口gateは未成立で、今のno-goはNN/backend仮説のnegativeではない。m8結果を一件も見ずに判断した。新抽出・PRNG・prefix辞書・16採番・match preregisterは作成していない。条件付きのm8採択ルートへ進まないための判断であり、旧m32の縮小ではない。NN/Chromium/engine/対局/holdout送信/build/取得/委譲0、actual_go=false／entry_ready=false／実source/proof=null・accepted=false。

旧.73のwrite-stop markerとmanifest37実hashを照合し、afterでも不変。旧.48/.67/.73、m48/96とm32/64のm/T/CI/期限・no-goを変更0。今回23重要入力のhash前後一致。HEAD `1482df8da6dd91c95db211aeaa914af775b2bc76` の既worktreeで作業し、HEADだけで未コミット入力を同定しない。旧pool64の実送信8除外56は文書根拠であり、旧未実行計画の重複は送信の証拠ではない。新選択なしなので新計画の重複数はnull。全host送信／未知training重複は未監査、送信反証があれば将来の全計画を無効・補充0とする。

.75/.76原報告と旧actual-driver／pause-check／match-entryを限定読取した。actual経路のstartMonitor未起動、旧22:00期限、purpose非依存dry/実カウント、subject/review結合の不足はコード読取でも支持する。.76の独立NN/Chromiumは0で、.75 public11/11を独立runtimeへ付け替えない。準備Promise未回収/fresh禁止も保持する。公平CPU・全手時計・完成cpの合法性/世代・残NN/stop/審判/encoding費の次t0課金・責任分類は測定の必須条件である。特定CLI名/dry欄/subreaper実装の成功自体は棋力条件ではないが、監査の誤記録やcleanup欠測がある測定を目標達成証拠にすることもできない。

次の最小案は[evidence-choice-plan.json](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-REMAINING-EVIDENCE-PLAN/evidence-choice-plan.json)へ予測・反証・固定条件・費用・依存を保存した。費用は提案見積りであり実績ではない。いずれも今回未実行、統括の別issue／writer／資源配分／明示契約を必要とする。

| 案 | 最小の対照・分かること | 反証／成立不能 | writer＋独立検証見積り |
| --- | --- | --- | --- |
| E0 入口契約 | 新一版の同actual mainをNN0で監視初期化・typed audit・subject/review束縛・無応答/取消に流す。準備経路の不成立を判別 | 正readyを拒否／未readyでbackend生成／誤カウント／旧proof受入れなら停止 | 12＋8分、CPU0/RAM1GiB |
| E3 時計・残処理 H3 | E0/ownership受入れ後、固定3golden×両engine×warm1/sample2＝18正常要求、境界4要求。T500/89/9/402/411を保持し、前finalstamp→準備/NN/通知/検証/Judge/UTF8→公開/ACK→次t0のspanを分離 | 時間境界・ACK欠測、late、fresh未成立はそのまま失敗。NN区間だけが支配なら残処理説はこの範囲で弱まる | 20＋15分、CPU2単logical/RAM3GiB、runtime計600秒上限・各job180秒以下 |
| E2 保存根 H2 | 旧765根のfinish765/765を再gateし、N=sim=edge和+1とsqrt(N+1)を明示。Cとscoretieを一因子ずつ再集計、採用764/late private1/欠測1は別分母 | 正N入力gate失敗／argmax不変なら有限snapshot効果を支持しない。parentQ欠測をedge平均へ埋めない | 15＋10分、CPU0/RAM1GiB、NN0/std-only新checker |
| E1 推論単独 H1 | 同648bits/137出力、既存ORT/tractの固定28 numeric gate後、3golden×両backend×warm1/sample5＝36call、CPU2/thread1で逐次。変換/run/抽出を分離 | numeric不一致／時計・背景誤差で差を区別できない／既runtime未成立 | 20＋15分、RAM3GiB、build/downloadなしが依存条件 |
| E2b 固定sim H2 | 必要なら同engine/backend/seed/order/valueを固定しCだけ1.5→1、3golden×2×32completed sim。root分布/Actionを比較 | baseline parity失敗／有限局面で不変。全探索/棋力改善へ外挿しない | 20＋15分、別実行契約・数値/ownership gate必須 |
| E4 標本 H4 | native/browser別母集団・pair単位・順序依存・CI coverageを結果前裁定 | 検証されたCI/power設計が実際に残予算で精度を満たせれば現保守案の必要性を再検討 | 設計20＋独立15分、今の対局は0 |

優先案はE0を一凍結版・20分に限定し、通ればE3、通らなければNN0のE2へ切り替える。修復は入口成立の情報を増やす一方、同じ枝の再修復と大きな全auditは独立検証負荷を増す。新観測・一因子対照が増えない再試行へ自動投資しない。.28v2は正node.visitsを許さない旧binaryの入力assertで停止しており、効果ゼロというnegativeではない。E2には入力検査を分離した別checkerが必要で、旧契約や失敗を修正しない。E1/E2bは代替枝として保持し、一度に重いNNを起動しない。startup6/rootvalue/訪問規約/参照C1-FPU.2-temp0-order/候補PUCT1.5-Q0-caps/RuleAを実比較時に黙って変えない。API awaitはkernel実行時刻ではなく、非分割op/公開後残NN/OS schedulingの観測を別にする。

時間だけの実行可能案はE0 20＋E3 35＋E2 25＝80分。例えば新契約が22:30から成立すれば22:50／23:25／23:50に各提出、00:50重job停止まで60分reserveとなる。実受入れ・無競合・成功を仮定したgoではなく、失敗時は次NNを開始しない。監督00:55・全体01:00、親CPU4/RAM8/global3/cum12GiBは維持する。

未採択m8案の静的算術はNode/Python別実装で保存した。pair Xiの単位は同prefix色交換2局平均、16局を16独立Xiとしない。幅 `sqrt(log20/16)=0.43270459565057134`、平均.5なら下限 `0.06729540434942866`／上限 `0.9327045956505713`、参考下限.45に届く観測平均は `.8827045956505714`。各95%片側参考境界であり、両側を同時95%と呼ばない。Bonferroni同時95%なら幅 `.48016139565996035`、.5で `[.019838604340039645,.9801613956599604]`。下限が.45未満というだけでは劣位の証明ではない。極端な全8pair勝ちなら片側参考Lは.45を超え得るが、正式NIの独立性/母集団/coverage仮定は未裁定で、browser結果だけでnative+browser目標を達成しない。

固定Hoeffding幅.05の600pair/1200gameはworst思考120000秒、真平均.5・一側α.05・80%powerの保守十分案1800pair/3600gameは360000秒。最小必要標本ではなく残枠で未立証見込みを示す。paired離散CI/empirical-Bernstein/finite56母集団補正はcoverage・相関・停止規則を別検証する競合案。有限固定potential outcomesの仮定や、小m8bootstrapのtailを未確認のまま精度改善と呼ばない。許容差.05、旧32実結果非統合、WDL差をbackend/時計bundleの因果へ断定0。

m8の継承式は1600think＋400startup＋1200retry＋600save＝3800秒＋停止1.5。match stopOct2 00:30から最遅Oct1 **23:26:38.500 UTC**、+1ms不足を両言語で確認。minimum入場条件で完遂/tail保証ではない。旧短平均でworstを減額0、gate不成立はno-go。人工11scenarioでXi/attempt/invalid retry1/global2/partial分母・Lなしが両言語一致。候補NN/model/fallback loss、参照同障害pair invalid、shared identity/referee invalid、双方timeout/crash/late/noCP/未知無応答の責任lossを所与のcontrol記号として流しただけで、実分類器/同main/runtimeの検査とは呼ばない。最終計画の追記はm8不採択の費用/知見と将来時間案、境界をT500へ明記した文面で、検算入力は不変。検算時revisionを原hash通り復元・別保存し、最終binding検査で一致を確認した。

3監視付き静的jobはexit0/guard0。20ms観測parent+child RSS最大65,458,176B、全観測TID CPU0、監視範囲CPU累計.1616秒/jobwall約.1563秒。Nodeheap192MiB＋RSSguard896MiB、AS1GiBは渡していない。22:22:54 UTCに本文前のhashafter/自己source-runtime-stopを保存、6記録identity現在不在。瞬間peak・初期短読取/claim/生成command PID/RSS・全CPU・Beads副次量は欠測で0補完しないため、全command/全期間資源遵守の証明ではない。誤った初期role/template/report filename読取は正pathへ訂正、静的検算失敗0。旧失敗資料削除0。停止前保存172,032B、最終文書/manifest増分は最終manifestに記録。予約16MiB/guard14MiB、旧32MiB返却0、条件付き残3,542,709,805Bは旧既知残からの算術で全owner現在量証明ではなく、cum12GiBを減額/reset0。

再現は新scope/別契約で、既固定成果へ上書きしない。`timeout 50s taskset -c 0 env UV_NO_SYNC=1 UV_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1 python3 tools/ai-sigma-remaining-evidence-plan/supervise.py <newname> node --max-old-space-size=192 --max-semi-space-size=4 --no-node-snapshot tools/ai-sigma-remaining-evidence-plan/check-node.cjs`、続けて別jobのcheck-python.py/check-binding.py。旧scope/source/entry/registry/model/kernel/product/rootlockはread-only。詳細はnode-static-check/python-static-check/final-binding-check/tested-plan-revision1、input-before/after、old73-fixed-check、*.started/process/log、runtime-source-stopped-before-reportへ保存。同担当二言語一致は他役独立受入れではない。

書込み/自己runtime停止後show/pause再確認・backup/report。.78は受入れ待ち、goal/他者close0。Atract/BORT/CB0とH1/H2/H3/H4、旧32局/NI未立証/Sigma未達、旧g287/62+82/340秒/2.26秒/6196ms/公開後追加NN/容量・期限・scope・affinity/RSS欠測、true合法200/no-legal/deep/rawview/entropy/来歴配布/training未確認を保持。今回の静的成功/通信受付は対局freeze/実go/NN/棋力成功ではない。
