import asyncio, importlib.util, json
from pathlib import Path
s=importlib.util.spec_from_file_location('team','/workspaces/quoridor/scripts/dev/research-team.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
out=Path(__file__).resolve().parent
async def main():
    host=m.command_json(['codex','app-server','daemon','version'])
    async with m.AppServer(host,timeout=20) as server:
        page=await server.request('thread/turns/list',{'threadId':'01a0f6b5-b1bd-7752-b0bb-74a336e459a4','limit':5,'itemsView':'full','sortDirection':'desc'})
        targets=['01a0f6d1-38bb-72c3-bc6d-cb21aaca219a','01a0f6b5-b4a3-71b0-8241-aa3161ac3daf']
        turns=[x for x in page['data'] if x['id'] in targets]
        assert len(turns)==2 and all(x['status']=='completed' for x in turns)
        (out/'exact-turns-full.json').write_text(json.dumps(turns,ensure_ascii=False,indent=2)+'\n')
        states={}
        for role,e in m.load_registry(Path('/workspaces/quoridor/.artifacts/research-team/registry.json'),Path('/workspaces/quoridor')).get('roles',{}).items():
            t=await server.read_thread(e['thread_id']);states[role]={k:t.get(k) for k in ('id','status','cwd','model','reasoningEffort')}
        (out/'sessions-live.json').write_text(json.dumps(states,indent=2)+'\n')
        print(json.dumps({'turns':[{k:x.get(k) for k in ('id','status','itemsView','durationMs')} for x in turns],'states':states}))
asyncio.run(main())
