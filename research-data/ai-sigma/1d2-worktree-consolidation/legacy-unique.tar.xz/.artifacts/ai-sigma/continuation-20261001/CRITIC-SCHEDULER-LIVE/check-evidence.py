import json,hashlib,os,resource,datetime
from pathlib import Path
ROOT=Path('/workspaces/quoridor/.worktree/ai-sigma')
BASE=ROOT/'.artifacts/ai-sigma/continuation-20261001'
OUT=Path(__file__).resolve().parent
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
start=utc();ownpid=os.getpid();tick=Path(f'/proc/{ownpid}/stat').read_text().rsplit(')',1)[1].split()[19]
prep=BASE/'SIGMA-SCHEDULER-LIVE';sup=BASE/'supervisor/e2819cb9-98ed-4873-b521-e016263153e5'
inp=json.loads((prep/'inputs.json').read_text());checks=[]
for row in inp['references']:
 p=Path(row['path']);checks.append({'path':str(p),'expected':row['sha256'],'actual':sha(p),'matches':sha(p)==row['sha256']})
assert all(x['matches'] for x in checks)
registry=json.loads(Path('/workspaces/quoridor/.artifacts/research-team/registry.json').read_text());definitions=[]
for role,e in registry['roles'].items():
 base=Path(registry['definitions_root'])/'.agents/research-team';digest=hashlib.sha256(((base/'common.md').read_text()+'\n\n'+(base/f'roles/{role}.md').read_text()).encode()).hexdigest()
 assert digest==e['definition_sha256'];definitions.append({'role':role,'thread':e['thread_id'],'sha256':digest})
first=json.loads((prep/'first-live-turn.json').read_text());assert sha(prep/'first-live-turn.json')=='48c3d0eb733348fe47138397f94b91c1e93f3c6ffedcfee983b513897d3e115e'
manifest=json.loads((prep/'preparation-report-manifest.json').read_text())
assert sha(Path(manifest['report_path']))==manifest['report_sha256']
assert sha(prep/'preparation-stopped.json')==manifest['preparation_stopped_sha256']
turns=json.loads((OUT/'exact-turns-full.json').read_text());turn=next(x for x in turns if x['id']==first['dispatched']['turn_id'])
assert turn['status']=='completed' and turn['itemsView']=='full' and turn['durationMs']<=180000
boot=next(x for x in turns if x['id']=='01a0f6b5-b4a3-71b0-8241-aa3161ac3daf');assert boot['status']=='completed'
assert [x['text'] for x in boot['items'] if x['type']=='agentMessage']==['BOOTSTRAP_READY supervisor']
prompt=next(x for x in turn['items'] if x['type']=='userMessage')['content'][0]['text']
cfg=json.loads((BASE/'scheduler/scheduler.json').read_text());contract=json.loads((BASE/'scheduler/contract.json').read_text())
expected=f"SCHEDULER_RUN_ID={first['dispatched']['run_id']}\n定期点検。Beads {cfg['dispatch_issue']}。運用契約: {cfg['contract_file']}。\n観測専用。研究・委譲・環境変更・研究再開は禁止。\n"+(BASE/'scheduler/prompt.md').read_text()
assert prompt==expected and registry['roles']['supervisor']['thread_id']=='01a0f6b5-b1bd-7752-b0bb-74a336e459a4'
assert cfg['interval_seconds']==1200 and cfg['max_active_sessions']==2 and contract['max_active_sessions']==3 and cfg['max_turn_seconds']==180
eventsPath=Path(first['source_events']);evbytes=eventsPath.read_bytes();events=[json.loads(x) for x in evbytes.decode().splitlines()]
assert first['dispatched'] in events and first['finished'] in events
assert [x for x in events if x['event']=='dispatched'][0]==first['dispatched']
skips=[x for x in events if x['event']=='skipped'];assert skips[0]['reason']=='active_limit'
commands=[x for x in turn['items'] if x['type']=='commandExecution'];assert len(commands)==9 and all(x['exitCode']==0 and x['status']=='completed' for x in commands)
obs=json.loads((sup/'observation.json').read_text());sessions=json.loads(json.loads((sup/'sessions.json').read_text())['stdout']);issues=json.loads(json.loads((sup/'issues.json').read_text())['stdout'])
active=[k for k,v in sessions.items() if v['status']['type']=='active'];assert active==obs['active_sessions']==['experiment','supervisor']
ids={x['id']:x for x in issues};assert all('paused-by-user' not in (x.get('labels') or []) for x in issues)
assert ids['quoridor-4lc.39']['status']=='in_progress' and ids['quoridor-4lc.41']['status']=='blocked'
assert obs['notification']['sent']==False and obs['goal_reached']==False
state=json.loads((sup/'scheduler-state.json').read_text());assert state['owned']['run_id']==first['dispatched']['run_id'] and state['owned']['turn_id']==turn['id'] and not state['recovery_required']
for rel,digest in json.loads((sup/'inputs.json').read_text()).items():assert sha(ROOT/rel)==digest
stop=json.loads((sup/'self-stop.json').read_text());assert stop['read_jobs_stopped'] and stop['persistent_self_jobs_started']==0 and all(x.get('exit_code')==0 for x in stop['operations'])
# Full command text confirms observed writes are confined to own dir and own .40 notes.
assert not any('research-team.sh report' in x['command'] or 'turn/start' in x['command'] or 'turn/interrupt' in x['command'] for x in commands)
commandsEvidence=[{'id':x['id'],'command':x['command'],'exitCode':x['exitCode'],'durationMs':x['durationMs']} for x in commands]
immutablePaths=[Path(x['path']) for x in checks]+list(sup.glob('*.json'))+[prep/'first-live-turn.json',prep/'preparation-stopped.json',prep/'preparation-report-manifest.json',ROOT/'docs/reports/ai-sigma-steward-scheduler-live.md',ROOT/'docs/design/ai-sigma-contract-critic-scheduler-live.md']
immutable=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in immutablePaths]
live={}
for name,p in [('state',eventsPath.parent/'state.json'),('events',eventsPath),('monitor',prep/'monitor-observation.json')]:
 b=p.read_bytes();(OUT/f'live-{name}-snapshot.json').write_bytes(b);live[name]={'source':str(p),'snapshot_at':utc(),'sha256':hashlib.sha256(b).hexdigest(),'mutable':True}
alive=[]
for pid,want in [(1000963,'9899975'),(1005388,'9934546')]:
 p=Path(f'/proc/{pid}');s=(p/'stat').read_text().rsplit(')',1)[1].split();alive.append({'pid':pid,'start_ticks':s[19],'same_identity':s[19]==want,'state':s[0],'rss':int(s[21])*4096,'affinity':list(os.sched_getaffinity(pid))})
r={'issue':'quoridor-4lc.41','start':start,'end':utc(),'immutable_inputs':immutable,'references':checks,'definitions':definitions,'live_snapshots':live,'events':{'count':len(events),'skip':skips,'first':first,'current_sha':hashlib.sha256(evbytes).hexdigest(),'initial_sha_matches_snapshot_now':hashlib.sha256(evbytes).hexdigest()==first['source_events_sha256']},'exact_turn':{k:turn[k] for k in ['id','status','itemsView','startedAt','completedAt','durationMs']},'bootstrap_exact':True,'full_commands':commandsEvidence,'semantic_active_snapshot':active,'saved_issue_snapshot':[{k:x.get(k) for k in ['id','status','assignee','labels','updated_at']} for x in issues],'notification_supported':True,'owned_runtime_alive_snapshot':alive,'LLM_entire_interval_guarantee':False,'source_review':'threshold2 + dispatch lock + target idle; exact owned reconcile with itemsView full, no blind resend; monotonic180s; deadline and pause recheck; stop pending retained','old_gaps':['initial no explicit UV_OFFLINE/UV_NO_SYNC and missing affinity/RSS','Go RLIMIT_AS failure and recovery retained','side DB/cache writes unmeasured'],'checker_self':{'pid':ownpid,'start_ticks':tick,'affinity':list(os.sched_getaffinity(0)),'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'self_failure':'initial issues.json printer assumed list of dict but wrapper envelope contained strings; read-only error, corrected parsing once'}
(OUT/'evidence-check.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'reference_count':len(checks),'definitions':len(definitions),'commands':len(commands),'turn_ms':turn['durationMs'],'runtime_alive':alive,'immutable_count':len(immutable)}))
