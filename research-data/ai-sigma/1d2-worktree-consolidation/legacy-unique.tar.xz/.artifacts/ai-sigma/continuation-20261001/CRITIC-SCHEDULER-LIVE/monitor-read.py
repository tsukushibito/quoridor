import subprocess,os,time,json,signal,datetime
from pathlib import Path
out=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def proc(pid):
    try:
        d=Path('/proc')/str(pid);s=(d/'stat').read_text().rsplit(')',1)[1].split()
        return {'pid':pid,'start_ticks':s[19],'state':s[0],'rss':int(s[21])*4096,'affinity':list(os.sched_getaffinity(pid)),'tids':{p.name:list(os.sched_getaffinity(int(p.name))) for p in (d/'task').iterdir()}}
    except (OSError,ValueError):return None
cmd=['/home/vscode/.cache/inference/envs/quoridor-research-team/bin/python','-B',str(out/'read-exact.py')]
start=now();tracked={};peak=0;reason=None
with (out/'read-exact.stdout').open('w') as a,(out/'read-exact.stderr').open('w') as b:
    child=subprocess.Popen(cmd,stdout=a,stderr=b,start_new_session=True)
    deadline=time.monotonic()+55
    while child.poll() is None:
        stack=[child.pid];seen=set();rss=0
        while stack:
            pid=stack.pop()
            if pid in seen:continue
            seen.add(pid);v=proc(pid)
            if v:
                key=(pid,v['start_ticks']);old=tracked.get(key,v);old['rss']=max(old['rss'],v['rss']);tracked[key]=old;rss+=v['rss']
            try:stack.extend(int(x) for x in Path(f'/proc/{pid}/task/{pid}/children').read_text().split())
            except OSError:pass
        me=proc(os.getpid());peak=max(peak,rss+(me['rss'] if me else 0))
        if time.monotonic()>deadline or peak>=1024**3:
            reason='timeout_or_RSS_guard';os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=2)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=2)
            break
        time.sleep(.02)
    code=child.wait()
remaining=[v for (pid,tick),v in tracked.items() if (x:=proc(pid)) and x['start_ticks']==tick and x['state']!='Z']
r={'command':cmd,'start':start,'end':now(),'exit':code,'stop_reason':reason,'sample_interval_ms':20,'sampled_peak_group_plus_monitor_RSS':peak,'tracked':list(tracked.values()),'remaining':remaining,'monitor_identity':proc(os.getpid()),'instant_short_lived_peak_not_guaranteed':True}
(out/'read-process.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ('exit','stop_reason','sampled_peak_group_plus_monitor_RSS','remaining')}))
