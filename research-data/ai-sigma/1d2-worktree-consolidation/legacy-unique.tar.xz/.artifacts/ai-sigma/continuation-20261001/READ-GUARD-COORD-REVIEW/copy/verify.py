"""Small deterministic boundary checks plus real owned-child cleanup diagnostics."""
import datetime as dt
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import time
import uuid

HERE=Path(__file__).resolve().parent
OUT=Path('/workspaces/quoridor/.worktree/ai-sigma/.artifacts/ai-sigma/continuation-20261001/READ-GUARD-COORD-REVIEW/outputs')
spec=importlib.util.spec_from_file_location('readguard',HERE/'guard.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
os.sched_setaffinity(0,{0});os.environ.update(g.ENV)
os.environ['PYTHONDONTWRITEBYTECODE']='1'
START=g.stamp();results=[]
W=dt.datetime(2026,10,1,10,0,tzinfo=dt.timezone.utc)
RUN=str(uuid.uuid4());TURN=str(uuid.uuid4())
owned={'run_id':RUN,'turn_id':TURN,'thread_id':g.THREAD,'started_at':W.isoformat(),'max_turn_seconds':180}
b=g.binding(owned,RUN,TURN,wall=W,mono=1000,boot='mock-boot')
def case(name,fn,reject=False):
    try:v=fn()
    except g.Rejected as e:
        assert reject,(name,str(e));results.append({'name':name,'passed':True,'rejected':str(e)});return
    assert not reject,name
    results.append({'name':name,'passed':True,'value':v})
for phase,limit in [('read_start',90),('read_finish',120),('finish',180)]:
    for delta,rej in [(-0.001,False),(0,True),(0.001,True)]:
        age=limit+delta
        case(f'{phase}:{age}',lambda phase=phase,age=age:g.admit(b,phase,wall=W+dt.timedelta(seconds=age),mono=1000+age),rej)
case('wrong-run',lambda:g.binding(owned,str(uuid.uuid4()),TURN,wall=W,mono=1000,boot='mock-boot'),True)
case('wrong-turn',lambda:g.binding(owned,RUN,str(uuid.uuid4()),wall=W,mono=1000,boot='mock-boot'),True)
case('unknown-start',lambda:g.binding({**owned,'started_at':None},RUN,TURN,wall=W,mono=1000,boot='mock-boot'),True)
case('future-start',lambda:g.binding(owned,RUN,TURN,wall=W-dt.timedelta(seconds=1),mono=1000,boot='mock-boot'),True)
case('changed-start',lambda:g.binding({**owned,'started_at':(W+dt.timedelta(seconds=1)).isoformat()},RUN,TURN,prior=b,wall=W+dt.timedelta(seconds=5),mono=1005,boot='mock-boot'),True)
case('reboot',lambda:g.binding(owned,RUN,TURN,prior=b,wall=W+dt.timedelta(seconds=5),mono=1005,boot='other-boot'),True)
case('rerun-same-deadline',lambda:g.binding(owned,RUN,TURN,prior=b,wall=W+dt.timedelta(seconds=20),mono=1020,boot='mock-boot')==b)
case('wall-backward-does-not-extend',lambda:g.admit(b,'read_start',wall=W+dt.timedelta(seconds=10),mono=1090),True)
case('monotonic-backward',lambda:g.admit(b,'read_start',wall=W+dt.timedelta(seconds=10),mono=999),True)
now=g.utc_now();live=g.binding({**owned,'started_at':(now-dt.timedelta(seconds=1)).isoformat()},RUN,TURN)
path=OUT/'environment-diagnostic.json'
code="import os,json,datetime;print(json.dumps({'affinity':list(os.sched_getaffinity(0)),'env':{k:os.getenv(k) for k in ('UV_NO_SYNC','UV_OFFLINE','PYTHONDONTWRITEBYTECODE')},'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}))"
v=g.run_child([sys.executable,'-B','-c',code],path,live,timeout=2)
assert v['affinity']==[0] and all(v['env'][k]=='1' for k in g.ENV)
row=json.loads(path.read_text());assert row['started']['utc'] and row['finished']['utc'] and row['reaped']
results.append({'name':'real-environment-affinity-stamps','passed':True,'result':v})
path=OUT/'timeout-diagnostic.json'
code="import subprocess,sys,json,time,os;child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(10)']);print(json.dumps({'parent_pid':os.getpid(),'child_pid':child.pid}),flush=True);time.sleep(10)"
case('real-timeout-owned-group-cleanup',lambda:g.run_child([sys.executable,'-B','-c',code],path,live,timeout=0.15),True)
ids=json.loads(path.with_suffix('.stdout').read_text());row=json.loads(path.read_text())
states=[]
for k,pid in ids.items():
    p=g.proc(pid);assert p is None or p['state']=='Z',(k,p)
    states.append({'name':k,'pid':pid,'observed':p,'running':False})
assert row['reaped'] and row['cause']=='timeout/deadline'
results.append({'name':'timeout-parent-and-descendant-not-running','passed':True,'identities':states,
                'zombie_if_any_is_not_running_and_not_claimed_reaped_by_us':True})
# An expired invocation must not execute a diagnostic at all.
expired={**live,'mapped_start_monotonic':time.monotonic()-90,
         'started_at':(g.utc_now()-dt.timedelta(seconds=90)).isoformat()}
never=OUT/'expired-child.json'
case('expired-launch-blocked',lambda:g.run_child([sys.executable,'-B','-c','raise SystemExit(99)'],never,expired),True)
assert not never.exists() and not never.with_suffix('.stdout').exists()
original_live=g.live_owned;original_child=g.run_child
commands=[]
cached_owned={**owned,'started_at':g.utc_now().isoformat()}
batch_bound=g.binding(cached_owned,RUN,TURN)
batch_state={'process':{'pid':1000963,'start_ticks':'9899975'},'owned':cached_owned}
def mock_live(run,turn,prior):
    assert run==RUN and turn in (None,TURN)
    g.admit(batch_bound,'read_start');return batch_bound,batch_state
def mock_child(args,path,bound,**kw):
    g.admit(bound,'read_start' if kw.get('phase','read')=='read' else 'finish')
    commands.append(args)
    if 'ready' in args:return [{'id':'quoridor-4lc.42'}]
    if 'show' in args:return [{'id':'quoridor-4lc.40','status':'in_progress','assignee':'codex:'+g.THREAD,'labels':[]},
                             {'id':'quoridor-4lc','status':'in_progress','labels':[]}]
    if 'status' in args:return {'supervisor':{'status':{'type':'active'}}}
    return {'reaped':True,'mock':True,'started':g.stamp(),'finished':g.stamp()}
try:
    g.live_owned=mock_live;g.run_child=mock_child
    batchdir=OUT/('mock-batch-'+RUN);batchdir.mkdir(exist_ok=False)
    observed=g.observe(batchdir,RUN,TURN);assert observed['read_command_count']==3 and len(commands)==3
    observed2=g.observe(batchdir,RUN,TURN);assert observed2['cached'] and len(commands)==3
    def forbidden_live(*args,**kwargs):raise AssertionError('finish must not refresh runtime metadata')
    g.live_owned=forbidden_live
    finalized=g.finish(batchdir,RUN,TURN,'mock bookkeeping only')
    assert finalized['owned_command_children_reaped'] and len(commands)==5
    assert commands[-2][2]=='update' and commands[-1][2]=='backup'
    results.append({'name':'mock-batch-once-cached-repeat-finish-no-fresh-runtime','passed':True,
                    'commands_recorded':len(commands),'live_Beads_mutation':False})
finally:g.live_owned=original_live;g.run_child=original_child
u=resource.getrusage(resource.RUSAGE_SELF);c=resource.getrusage(resource.RUSAGE_CHILDREN)
result={'started':START,'finished':g.stamp(),'results':results,'passed':len(results),'failed':0,
        'self':g.proc(os.getpid()),'self_maxrss_kib':u.ru_maxrss,'child_maxrss_kib':c.ru_maxrss,
        'self_user_cpu_s':u.ru_utime,'self_sys_cpu_s':u.ru_stime,'child_user_cpu_s':c.ru_utime,'child_sys_cpu_s':c.ru_stime,
        'live_supervisor_dispatch_or_steer':False,'NN_build_download':False,'side_DB_cache_write_test':False}
g.write(OUT/'verification.json',result)
print(json.dumps({'passed':len(results),'failed':0,'pid':os.getpid(),'self_maxrss_kib':u.ru_maxrss,'child_maxrss_kib':c.ru_maxrss}))
