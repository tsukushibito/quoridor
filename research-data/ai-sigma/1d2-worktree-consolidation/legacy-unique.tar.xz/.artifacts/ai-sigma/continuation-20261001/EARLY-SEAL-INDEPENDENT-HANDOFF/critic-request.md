新実依頼 SIGMA-EARLY-SEAL-INDEPENDENT / quoridor-4lc.64。通常委任内、対局no-go。旧 .60 blocked維持、旧 .56/.60のNN再試行ではありません。現在idleを確認して新課題を送付します。受領/claim/開始を先記録、最終writer停止・immutable入力を照合後に、この契約の独立runtimeを実行してください。保存した同model/effort維持、capacity再発時は停止報告。
契約SHA bc74e6f69f88e595af16c3328a955a041fbd31b9d5efe47a8ba6f42803ccaec5

# SIGMA-EARLY-SEAL-INDEPENDENT / quoridor-4lc.64 / 試行1・契約1

critic 01a0f31d-8227-7e03-a7e6-915b4918c11b → coordinator。親継続版2 `docs/design/ai-sigma-continuation-20261001.md` SHA6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f 全文継承。終了Oct2 01:00UTC、重job停止00:50、監督終了00:55、global LLM3、CPU/RAM/累積12GiB・許可範囲不変。受領から処理35分/提出45分、新jobは処理期限5分前まで。絶対全体期限との早い方。通常の自律研究の独立検証依頼であり、旧 .56/.60 の再試行や期限延長ではない。容量障害再発なら保存・自己job停止・報告し、この契約から盲目的な再start/model変更/server再起動をしない。

## 入力・所有

writer .63 はsource/runtime停止済み。統括のread-only照合では旧688入力、最終451payload、source58 checks一致、記録77 PID/starttick現在不在。新NNを行わず正常12件の算術と予約reserve89/cutoff402/seal411を確認した。独立受入れ前の読み取り支持であり、全期間回収証明ではない。固定入力は次の実bytes。

- `.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL/final-manifest.json` SHA c877e781d72d1a71cc8c667a7298ffd245058a011a7beb56640490155235a4d9。
- 同 `source-frozen.json` SHA c5381302d6573605242d06ede2f173e8fb68102c3ad9121a6d68e4070a5b411d、最終revision3。
- `docs/reports/ai-sigma-experiment-streaming-early-seal.md` SHA58996b0567e1688fd1336bdae39a55f7503581ba386fb0f07cbe471fe9f769a3。
- 同 `all-public-requests-combined.json` SHA e568c46084c12f7a52404575af52c9e17302476efa5ae5a549cbce47470f5da8、`preregister.json` SHA22d2fa771906345eae0c06f7b8c6bacd2daf62e5e0a68c1607eb28800df3a654。

自己書込は `.artifacts/ai-sigma/continuation-20261001/CRITIC-STREAMING-EARLY-SEAL/` と `docs/reports/ai-sigma-critic-streaming-early-seal.md` のみ。原 .63/.62/.59、model/immutable Wasm/ORT、製品/rootlockはread-only。元新toolは `tools/ai-sigma-streaming-early-seal/`。必要copyは自己域、絶対入力/output/temp/deadline/guard・結果前の指定診断選択だけpatch、方式/誤分類/時計条件を修正しない。原最終版・過去失敗版を区別する。新checker/注入は自己copy、差分保存。入力前後hashとwriter停止・旧自己外部job停止を確認後だけruntime。

## 判別と結果前固定

「推論を待たず完成cacheを返せる」ことと「全体T内の合法配送・取消後の次手資源公平」を別に反証する。T500、reserve89、commit余裕9、seal411、cutoff402を固定し、この独立試験で再選定しない。NN最大値へreserveを広げて救済しない。

保存20要求を独立再集計。正常12、steady9（warm sample=-1、steady0/1/2）、NN0終端2、境界6。全正常p95/max340210.191msの元warm失敗、条件付き11、steady9を別列で保持。元原cancel ACK欠測/誤分類修正、未実行19のみ継続、均一一版一窓の20完遂でないこと、初回control文書追記hash拒否と3618byte期待原文固定を保管する。文書の原期待SHAと保存prefix/fullcurrentの一致は監査するが、実コード入力へ任意prefix切取りを許す根拠にしない。統括checkerの最初のsteady6誤集計→sample>=0で9への訂正も保存済み。

最終revision3の実ブラウザ診断は結果前に固定して一窓・一版のみ。先に完成cp後cancel→次要求の連続時計を一度実施し、その後正常3golden各warm1+sample2（計9上限）。重要境界は各一度、上限6（NN0合法goal/人工200、初回無し、検証完了cutoff跨ぎ、受信fault、caller busyまたは遅延通知は静的知見で選択して実行前に列挙）。固定8sim direct24cpは元保存rawの独立照合を基本とし、新全control実NN再試行はしない。未成立前提は未成立のまま記録し、同一suiteを救済再測定しない。startup/warm/通常/境界/取消を別分母にし、NN0校正payloadをNN成果にしない。

各runtimeの正しい `fixture.legal_prefix`、ID・長さ・型・finite・strict value[-1,1]・合法Action/prior/stats/完成owned cp、request/gen/epoch/prefix/history/key/model/schema/limits/token/sequenceを先に検査。固定参照の数値はabs<=1e-4+1e-4*abs(ref)、不正shapeを切り詰めて比較しない。モデル/ORT threads1とrootP2対応を保存。完成backup後からcp不変性、受信検証終了とcopy/freeze終了時刻でcutoff再確認、遅配/partial/foreign/逆順・重複/世代を反証。主側sealにWorker query/NN awaitがないことをsourceと実経路で確認。

t0はimmutable入力供給可能・変換前、合法性/identity/format/encoding後Node stampまで。page/Workerの時計区間/drift/end包含、timer wake遅延、cp完了→受信→検証完了→seal→配送の鮮度/費用を記録。実 `session.run` のAPI await区間とexact kernel命令時刻を区別し、人工busyだけの成功を実ORT跨ぎへ格上げしない。全配送lateはreject/nullで救済0、初回cp無しnull/fallback0、NN0終端を人工到達証明へ格上げしない。

cancel/fault後は旧探索handle/activeNN/live_searches=0を実ACKで確認してから次NN、次t0は先のpublic stampで固定しcleanup/free/必要freshloadを時計外へ逃がさない。取消自体は成功Actionではない。seal前受信fault全discard、seal後faultは公開不変という受信順政策の限界を明記し、故障生成時刻の全知を主張しない。旧PID0→fresh・最後の自己回収はboot/PID/starttickとkernel sole-root/adoption/waitの来歴で確認、forcedと自然停止、現在不在と当時controlled回収を別列にする。未知identityへsignal/wait禁止。参照AIにも同caller/時計/通知頻度/残処理課金を適用できるかは静的レビューまで、参照C1/FPU.2/temp0/order/root展開sim外は変更しない。

## 資源・停止・受入れ

CPU静的0/runtime2単logical、NNthreads1、RAM3GiB guard2.5、各重job最大180秒。新64MiB guard56は既critic128MiB内、combined112MiBを維持し不足なら停止、追加予約0。累積12GiBをリセットせず、条件付き未配分3,626,595,885Bは範囲外共有増分/peak欠測付きの旧予約値として保持。専用TMP/XDG、PID/starttick/command/hash/UTC/monotonic/exit/RSS/affinity/保存量を記録。静的重読取を自己NNと重ねず、他重NN停止を確認。瞬間peak/背景負荷保証をしない。

build/compile/download/依存更新/共有更新/製品/学習/GPU/対局/holdout/追加委譲/他者kill0。actual_go=false、独立通過だけで試合開始・棋力達成・採用を認定しない。Atract/BORT/CB0とH1backend/H2探索・故障/H3IPC-checkpoint/H4標本を維持、旧32局/NI未立証/旧g287/過去容量・期限・scope逸脱を消さない。文書より先にruntime-stop/hashafter、短い暫定報告を先保存して提出時間を確保。受領・claim・実開始をBeadsに記録、終了時backup/report。自issueは受入れ待ち、goal/他者close0。.60blockedや .56旧期限は変更しない。


親継続契約全文
# Sigma自律研究・継続枠 2026-10-01

契約版2。目標quoridor-4lc。統括01a0f31b-3409-75f2-a30e-453a50484f94。根拠はユーザーの明示継続/詳細委任（root入力01a0f2e9-357d-7ef3-a2fe-b16f80accda5）。開始2026-10-01T09:03:36.459834+00:00、終了2026-10-02T01:00:00Z（2026-10-02 10:00 JST）。本書は新しい実行枠であり、旧目標契約版2の初期04:00終了/未達/過去逸脱を保持する。旧文書・旧preregister・成績は変更しない。目標/比較A/通常製品規約維持/独立検証/権限は旧目標契約を継承する。

固定Sigmaと同計算資源・思考時間でnative/localおよびbrowserの非劣性を実測する。旧32局m8のnative.5625/browser.1875と両下限未達を保持。今回の新比較はcode/model/config/pool/T/g/m/CI/停止/責任分類を結果前に別事前登録し、旧結果へ後付け条件変更/標本統合をしない。未使用m10計画は参考として残すが、実入口/共通時計/資源gateと新deadlineを独立freezeするまで対局禁止。

予算はCPU全計4logical、RAM全計8GiB、LLM最大3（統括と新supervisorを含む）、正式CPU比較はCPU2単logical/推論threads1/GPU推論0/他の重い研究job停止。GPU研究は旧上限6GiB・1job30分・累積2h以内を保持し、今回は別配分前GPU/学習0。成果/依存は旧枠から累積12GiBを維持、リセット/12GiB追加ではない。旧限定保守課金6,588,000,723B・条件付き残6,296,901,165Bを開始時再確認する。初回新規予約: entry2GiB（guard1.75GiB）、steward128MiB、監督32MiB、統括文書32MiB。未配分は基準再確認後に統括が同12GiB内で配分。副次cache/途中展開/一時profileも計上。既存共有training/cacheは読取のみ、削除はこの枠が所有する再生成物だけを証拠保持の上で別に判断。

既存五役saved sessionを維持、新supervisorは既存App Serverに永続登録して観測専用で追加。App Server/toolchain再起動やモデル/effort変更をしない。新有料API/クラウド/第三者オンライン対局なし。主checkout製品/UI/描画/M2/commit/push/公開は対象外。研究worktreecodex/ai-sigmaで新copyに実装し旧入力をhashで固定。スケジューラーは主checkoutのpush済み操作入口を利用し、運用role定義/registry/専用configだけを用意する。

監督issuequoridor-4lc.40、20分周期/1turn180秒（新job120秒で停止し報告へ）、終了2026-10-02 00:55UTC、観測のみ。globalは3だがschedulerの起動閾値max_active_sessions=2として統括報告の起動1枠を残す。枠使用中はskipしsteerしない。変化なしは保存のみで静かに終了、意味ある停滞/失敗/期限資源/完了時にだけ統括へreportする。監督が設定や課題配分を変更しない。pause/終了はownedturnだけinterrupt確認し、外部jobは各ownerが回収する。dispatcherや監督の停止だけでNN停止を認定しない。

初回はquoridor-4lc.38stewardがscheduler準備/実運用/容量/資源台帳、quoridor-4lc.39experimentがORT入口・復旧gateを担当。途中から競合A共通tract/B分離ORT/C B0とH1backend/H2探索/H3時計・checkpoint/H4標本を更新し、通常判断は統括が実依頼する。別の選択が有望ならこの枠内で契約を作り替えるが、結果を見た正式判定緩和は行わない。

終了: 目標達成、ユーザーpause、上限/guard/異常、2026-10-02 01:00UTC。2026-10-02 00:50UTCまでに新重jobを止め、終了処理を確保する。全ownerはPID/starttick/command/hash/exit/資源/失敗/stopを先保存、報告は簡潔に詳細JSONへリンク。達成なら独立根拠で目標close、未達なら次の継続/停止理由を記録。予算を自動延長しない。各実行deadlineは本枠以下。担当へ実送信/受領をBeadsとdispatchに記録する。

継続委任は目標へ向けて継続する指示である。未達の場合は本枠終了前に統括が次枠の必要性/予算/検証を判断し、ユーザーへ通常詳細の再承認を求めず別契約として具体化できる。同一枠の期限や累積12GiBを黙って拡張しない。

## 契約版2の期限変更根拠

2026-10-01、操作元root 01a0f2e9-357d-7ef3-a2fe-b16f80accda5からユーザー明示指示を受領。「明日午前10:00」は2026-10-02T10:00:00+09:00 = 2026-10-02T01:00:00Z。開始時刻は維持し、旧継続枠終了2026-10-01T17:00:00Zから終了時刻だけ変更する。重い処理停止00:50UTC（09:50JST）、監督運用停止00:55UTC（09:55JST）、monitor回収00:58UTC、枠終了01:00UTC（10:00JST）。目標達成・pause・guard停止条件と時間以外のCPU/RAM/LLM/累積容量・許可範囲・独立検証は変更しない。

旧版SHA859bb777836cc0683e1ad7d1763a71fda60c75d2d6391290cef28771589a81a2を.artifacts/ai-sigma/continuation-20261001/DEADLINE-20261002-1000/continuation-version1.mdへ保全。閉じた実験や旧個別契約の処理/提出期限、事前登録、旧失敗/逸脱を遡及延長しない。新実験・比較は別契約で結果前に固定する。統括.52が正本/Beads、steward.53が既存所有範囲の運用契約/config/reload/monitor更新と実反映を担当する。


writer報告全文
EXPERIMENT_REPORT SIGMA-STREAMING-EARLY-SEAL quoridor-4lc.63 final / trial1

新copyで最終Node callerへの先行cache、検証終了cutoff、早いsealを実装した。有限診断で通常12要求中11要求、steady9/9とNN0終端2/2がT500内に配送された。一方、取消後の停止判定失敗と次要求の期限超過を保持するため、全suite時計適格・actual_goはfalse。独立受入れ待ちin_progress。対局・holdout・build・取得・GPU・学習・委譲0。.59は統括の有限cache支持／時計late反証の限定理由で本人close済み、旧失敗は不変。

15:50:24UTC受領、親版2と自契約全文確認、ready/show/pause後claim。処理16:55:24／新job16:50:24／提出17:10:24。実runtime終了16:28:46、source-stop16:36:37、文書前に停止証拠保存。最終source revision3 manifest SHA256 `c5381302d6573605242d06ede2f173e8fb68102c3ad9121a6d68e4070a5b411d`。旧入力688／最終source58 checksを再照合した。

Worker完成resume/backup後のimmutable cpをpostMessage→Playwright bindingでNodeへ先行通知する。Nodeは正しいfixture.legal_prefixから局面・履歴・合法集合を作り、identity/世代/model/schema/limits/token/単調sequence/型/finite/strict value/合法手/statsを検証する。copy/freezeと検証が終了した時刻でcutoffを再確認し、同時刻以上はcommit拒否、旧cacheを破壊しない。最終callerはWorker問い合わせをせず、保存cacheをsealし必要な合法性・identity・encoding・stampを完了する。大きいtree/traceは公開後のprivate保存に分離。t0は変換前、次要求は前公開stampから旧探索停止待ちも課金する。

NN結果前にNN0代表payload30件（warm5/steady25）、固定算式と全20要求を登録した。reserve=ceil(steady最大62.374＋時計誤差×2＋25)=89ms、commit余裕9ms。T500、seal411ms、cutoff402msを一回選定し変更なし。reserveはNN最大値に依存しない。page/Worker開始終了pingとdriftを保存し早側へ変換した。

通常12件全分母のp50=413.711ms、p95/max=340210.191ms。期限内11件に条件を限定するとp50=413.581、p95/max=423.042ms。steady9件のp50=413.581、p95/max=416.299ms。最初のwarmは旧取消要求のstampを維持し、原因修正・物理回収・fresh loadの待ちを課金してlate/null、NN未開始。除外や時計リセットはしていない。8件で最終配送が時計誤差込みのsession.run API開始終了区間内にある。これはJS await API区間であり、内核命令実行の正確な時刻やhard realtime保証ではない。

goal/人工ply200は413.769/412.162ms、NN0、終端checkpoint保持。人工200を真の合法到達証明としない。検証跨ぎはVALIDATION_FINISHED_AFTER_CUTOFFでcommit拒否、初回無し・遅配はNO_COMPLETED_SNAPSHOT/null、主側busyは511.057ms late/null、受信済み故障・取消は全discard。mockのD前/同時/後9組、世代/fault/seal変更・偽binding/partial/mutable/逆順・prefix不正、最終入口のtoken無し／実run／既run拒否も通過した。seal前に受信したfaultを破棄、seal後通知は既公開を変更しない受信順政策を固定し、Producer故障生成時刻の全知とは区別する。

実測前の固定8sim対照では3局面の24完成cpが直呼びとtree/history/stats/action一致。648features×6=3888bits一致、137output×6=822要素と合法prior772の混合gate失敗0、strict[-1,1]。root数値・完全cp・輸送bindingを保存したが、任意深部partial treeの一般証明はしていない。

失敗保全は二件。初回校正は統括の可変control報告追記でhash拒否しNN0、元3618bytesのSHA一致prefixを自己域へ固定して一原因修正。原NN jobは取消のsearch errorをownership errorと混同して停止。原失敗/source/rawを保存し、旧物理PID0を確認後、error分類だけ一原因修正した。元取消stop ACKのraw欠測は残る。完成済み1要求とcontrolを再測定せず、未実行19要求のみ継続し、前述の次warm期限超過も保存した。

新18停止ACKはhandle/activeNN/live_searches=0、Model dropも0。browser回収は3窓ともforced、外側subreaperはsole-root/起動child空/boot-PID-starttick限定waitでremaining0。77追跡identity不在、最終拒否テスト3子もwait済み。自然終了へ付け替えない。観測全TID CPU2、NNthreads1、最大RSS1,589,903,360B、新保存ピーク15,106,048B、128MiB枠／112MiB guard内、追加予約0。40ms目標観測のinstant peak・全CPU累積・背景負荷時系列は保証せず、正式無競合速度を主張しない。

参照比較は同T/t0/caller cache-seal/通知頻度/CPU2/thread1/RAM/残処理課金を両者へ適用し、Sigma-Web C1/FPU.2/temp0/order/root展開sim外を保持する別独立gateが必要。今回は候補単手のみ。旧32局NI未立証、.60容量障害、真合法200/no-legal、一般rawview/深部/entropy/training overlapと旧逸脱は保持。棋力・採用・目標達成は認定しない。

詳細: [analysis.json](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL/analysis.json)、[preregister.json](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL/preregister.json)、[全20公開要求](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL/all-public-requests-combined.json)、[最終manifest](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL/final-manifest.json)、[source-stop](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL/source-stop.json)、[runtime-stop](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL/runtime-stop-before-document.json)。source/runtime書込停止、次検証配分は統括へ。


統括読み取り/算術（独立runtime未実施）
{
  "UTC": "2026-10-01T16:50:01.305825+00:00",
  "checks": {
    "final-manifest.json": {
      "count": 451,
      "mismatches": []
    },
    "source-frozen.json": {
      "count": 58,
      "mismatches": []
    },
    "input-before.json": {
      "count": 688,
      "mismatches": []
    }
  },
  "hashes": {
    "final-manifest.json": "c877e781d72d1a71cc8c667a7298ffd245058a011a7beb56640490155235a4d9",
    "source-frozen.json": "c5381302d6573605242d06ede2f173e8fb68102c3ad9121a6d68e4070a5b411d",
    "source-stop.json": "0c39dd917c0df230a2cb7e2b24ab2f084acb34c776f169d3611335c3c5d67ebc",
    "runtime-stop-before-document.json": "ca6443bd3486c435fac811084aaf9c83bc378239c876ab18fa237f7cd4c65e3d",
    "analysis.json": "7c02c769f673a0b0413369343d8ef6c6d3a25e931ed333413d5929e290e965cd",
    "all-public-requests-combined.json": "e568c46084c12f7a52404575af52c9e17302476efa5ae5a549cbce47470f5da8",
    "preregister.json": "22d2fa771906345eae0c06f7b8c6bacd2daf62e5e0a68c1607eb28800df3a654"
  },
  "report_sha256": "58996b0567e1688fd1336bdae39a55f7503581ba386fb0f07cbe471fe9f769a3",
  "observed_identities": 77,
  "same_identity_live": [],
  "normal_all": {
    "n": 12,
    "median": 413.71066450327635,
    "p95": 340210.1907200068,
    "max": 340210.1907200068,
    "eligible": 11
  },
  "steady": {
    "n": 9,
    "median": 413.58052399754524,
    "p95": 416.29945899546146,
    "max": 416.29945899546146,
    "eligible": 9
  },
  "public_distinct": 20,
  "reserve": 89,
  "cutoff": 402,
  "seal": 411,
  "all_runtime_and_gate_success": false,
  "actual_go": false,
  "comparison_no_go": true,
  "verification": "coordinator read-only hash/current identity/independent arithmetic; no new NN",
  "coordinator_checker_correction": "warm sample=-1, steady=0/1/2; initial sample>0 filter undercounted6, corrected once; preserved initial output; original raw unchanged"
}

報告先coordinator、通信--issue quoridor-4lc。担当自己closeは統括受入れ後。