研究継続の実依頼。ready/show/pause・自身issueを確認しclaim/受領開始を記録してください。親/新契約全文と統括判断は以下。通常判断は委任、ユーザー承認再要求不要、予算を拡張しません。開始報告と最終停止hashをcoordinatorへ送ってください。

# SIGMA-STREAMING-NUMERIC-ORDER / quoridor-4lc.72 / 試行1・契約1

experiment 01a0f31d-6d15-7620-bb63-4b4f878e4746 → coordinator。親継続版2 SHA6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987fを全文継承。終了Oct2 01:00UTC、重job00:50/監督00:55、global3/CPU4/RAM8GiB/累積12GiB/製品範囲不変。受領から処理25分/提出35分と絶対21:35/21:45UTCの早い方、新jobは処理5分前停止。

## 問い・凍結入力

原71の共通startup-ready/最終Judge後時計/Modeldropの有限支持を維持し、数値検査器がengine固有の合法順を混同する具体的誤りだけを修正して必須fresh/両goal/4plyを確認できるか。原71の一窓public3/max11・helperERR_ASSERTION・未実施8は救済しない。69の保存監査は独立実NN成功ではない。

入力71: entrymanifest SHA39f0bb98e7889754d67043c3fd613326dbd0c88e1e2aa7b414c46d6463a17d9f、source-frozen SHA5b509ce5c881e77a2c415aa54bc33deff1cd729b4f222865d5adf7b2f97f4ae0、finalmanifest SHA5b1a9d70d690537ef05566c3f4299cdc73c87779fbd64deacb31137fd4f8ef72、report SHA6d3995eb8a453ced609dcd982a88744a8d7b788a93b777f94dc93e51d950b901。原source/保存cp/control/kernel/model/lockはread-only、元42参照と最終sourceを開始・終了に照合。原62 PID/starttick現在不在と停止証拠を確認し、未知所有へのsignal/wait禁止。

write ownerは新tools/ai-sigma-streaming-numeric-order/、.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-NUMERIC-ORDER/、docs/reports/ai-sigma-experiment-streaming-numeric-order.mdだけ。必要sourceだけcopy、旧全raw/cache複製0。最小helper修正以外のNN/kernel/producer/caller/最終Judge/encoding/時計/分類/所有境界を変更しない。追加の必要差分が判明した場合は別原因・新bindingとして報告し、元窓への成功付替え0。

## 数値検査器だけの修正

checkNumericは候補root_edgesの順序をSigma getLegalActions順と同一と仮定していた。候補は固定Rust Action生成順、参照は元Sigma合法順を維持する。検査器はまずengine別の期待順を各固定生成器/controlから検証し、両者の合法集合はAction対応で厳密に一致させる。Action→136索引/P2canonical変換の対応によってsoftmax/priorを照合する。同じiの列挙位置を異なるengineの同じActionだと誤認しない。正しい集合だけなら順序検査を省略してよいとはしない。探索/finish/tie/orderを並べ替えない。

NN0で普通/VM配列・P1/P2・engine固有順正常、集合欠落/重複/非法Action、priorの別Actionへの入替え、featuresbit/137shape/NaN/Inf/strictvalue±1境界、期待順の不正変更を反証する。受信numeric helperと独立保存control照合の分母を分離。数値閾値abs<=1e-4+1e-4abs(ref)、finite/value[-1,1]、648features bits/P2/合法209↔136は不変。primary helper失敗でもdrop/clock/所有回収をfinally等で実行し、必須失敗は検索成功ではない。

## 固定一窓・実入口

小NN0 gate/保存headroom/他重NN停止を確認後、同最終main・正診断tokenの一窓をNN結果前登録する。startup固定initial-p1/asym-hv-p2/straight-jump-p2各engine1rootNN計6/sessionは木/history/cache破棄・handle/activeNN/live0でready、手標本と別計上。fresh時の同readyも別6、入力供給後の費用は次t0=前公開stampへ課金し時計をリセットしない。

fixedinitial5: 候補通常/参照通常→候補完成cp後cancel→旧ACK0/Modeldrop/controlledPID0→fresh両正常。両合法goal2はNN0、golden同runGame4plyはoutcome前停止、public最大11/最終source一窓。全初回無し/late/取消/未実施/失敗を分母に残す。既71の3件再測定・標本追加と呼ばず新修正契約の窓として保存する。NN窓救済再試行0。

Judge合法検証+必要UTF8 encoding後stamp、public/finish/次t0を同body時刻に統一し、game-loopにstamp後の再Judge/encodingを追加しない。全t0はimmutable入力供給可能時/adapter前。NN/Worker照会なしcache seal、postvalidation cutoff402/seal411、T500/reserve89/commit9、fault受信順政策/fallback0、strictboolean/identity/gen/prefix/seed/model/schema/limits/tokensequence、旧応答拒否を保持。成功・null・lateのfinal encoding/stampを別検査。終端値・履歴はRuleA/goal優先/200ply/no-legal draw、人工診断を実到達証明にしない。

実actual --runは新coordinator freeze/独立proof/新preregister/全sourcehash/既run・期限予算を同factory/classifier/public時計へ接続する条件付き経路のみ。この契約はactual_go=false、正proof自己発行0、pool/対局送信0。falsego/未token/旧hash/既runの小実CLI拒否を確認。正診断入口から実backend一窓を確認し、fake proofを正式受入れとはしない。比較scheduleは旧m48のままread-only/mock資料、別73の計画はまだfreezeしない。

固定ONNX d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d、Wasm1f54d0b8f0c6d3d7d51935886ed506e44376a2052506be62ca7a726c85a78a01/ORT1.21wasm/threads1/proxyfalse。候補PUCT1.5Q0/seed1979/原tie-finish4096/512/24、参照C1/FPU.2/temp0/first/legal順/bestAction100000/root展開sim外/uncappednull、rootNNvalue対q・edgesim−1対simを区別。参照対照/候補cpはそれぞれ固定controlへ照合、受信側Action再選択0。

## 資源・引渡し

staticCPU0/runtimeCPU2単logical/両NNthreads1、RAM4GiBguard3.5/new128MiBguard112は既entry2GiB内/新予約追加0。profile/temp/log/全診断/endingのheadroomを起動前に保存、不足はNN0停止。旧予約/68peak/cum12GiBをリセット0。job180秒、sole-root/childempty/singlethread/subreaper/kernel adoption/bootPIDstarttick限定wait、TMP/XDG専用。Modeldrop/ACK0/innerforced/outercontrolled/currentabsenceを別根拠で保存、自然停止・全期間/tail保証へ格上げ0。

source/runtime停止・hashafter・primary/secondary・model/ACK/全public/startup/未実施分母・command/resources/PID/waitの最終manifestを本文前に保存し早くcoordinatorへ渡す。小helper失敗は一原因一NN0修正、窓再測定0/guard停止。独立別契約＋新比較登録＋freezeまでentry_ready/actual_go=false。旧69個別期限を延長せず、旧m48最遅21:13:18.500/11800+1.5を縮めない。旧32局NI未立証/Sigma未達、旧g287/62+82/340秒/2.26秒、容量/期限/scope/affinity/RSS欠測・deep/rawview/entropy/training未確認保持。build/取得/学習/GPU/製品/対局holdout/追加委譲0。backup/report→coordinator、本人受入れ待ち、他者goalclose0。


# Sigma自律研究・継続枠 2026-10-01

契約版2。目標quoridor-4lc。統括01a0f31b-3409-75f2-a30e-453a50484f94。根拠はユーザーの明示継続/詳細委任（root入力01a0f2e9-357d-7ef3-a2fe-b16f80accda5）。開始2026-10-01T09:03:36.459834+00:00、終了2026-10-02T01:00:00Z（2026-10-02 10:00 JST）。本書は新しい実行枠であり、旧目標契約版2の初期04:00終了/未達/過去逸脱を保持する。旧文書・旧preregister・成績は変更しない。目標/比較A/通常製品規約維持/独立検証/権限は旧目標契約を継承する。

固定Sigmaと同計算資源・思考時間でnative/localおよびbrowserの非劣性を実測する。旧32局m8のnative.5625/browser.1875と両下限未達を保持。今回の新比較はcode/model/config/pool/T/g/m/CI/停止/責任分類を結果前に別事前登録し、旧結果へ後付け条件変更/標本統合をしない。未使用m10計画は参考として残すが、実入口/共通時計/資源gateと新deadlineを独立freezeするまで対局禁止。

予算はCPU全計4logical、RAM全計8GiB、LLM最大3（統括と新supervisorを含む）、正式CPU比較はCPU2単logical/推論threads1/GPU推論0/他の重い研究job停止。GPU研究は旧上限6GiB・1job30分・累積2h以内を保持し、今回は別配分前GPU/学習0。成果/依存は旧枠から累積12GiBを維持、リセット/12GiB追加ではない。旧限定保守課金6,588,000,723B・条件付き残6,296,901,165Bを開始時再確認する。初回新規予約: entry2GiB（guard1.75GiB）、steward128MiB、監督32MiB、統括文書32MiB。未配分は基準再確認後に統括が同12GiB内で配分。副次cache/途中展開/一時profileも計上。既存共有training/cacheは読取のみ、削除はこの枠が所有する再生成物だけを証拠保持の上で別に判断。

既存五役saved sessionを維持、新supervisorは既存App Serverに永続登録して観測専用で追加。App Server/toolchain再起動やモデル/effort変更をしない。新有料API/クラウド/第三者オンライン対局なし。主checkout製品/UI/描画/M2/commit/push/公開は対象外。研究worktreecodex/ai-sigmaで新copyに実装し旧入力をhashで固定。スケジューラーは主checkoutのpush済み操作入口を利用し、運用role定義/registry/専用configだけを用意する。

監督issuequoridor-4lc.40、20分周期/1turn180秒（新job120秒で停止し報告へ）、終了2026-10-02 00:55UTC、観測のみ。globalは3だがschedulerの起動閾値max_active_sessions=2として統括報告の起動1枠を残す。枠使用中はskipしsteerしない。変化なしは保存のみで静かに終了、意味ある停滞/失敗/期限資源/完了時にだけ統括へreportする。監督が設定や課題配分を変更しない。pause/終了はownedturnだけinterrupt確認し、外部jobは各ownerが回収する。dispatcherや監督の停止だけでNN停止を認定しない。

初回はquoridor-4lc.38stewardがscheduler準備/実運用/容量/資源台帳、quoridor-4lc.39experimentがORT入口・復旧gateを担当。途中から競合A共通tract/B分離ORT/C B0とH1backend/H2探索/H3時計・checkpoint/H4標本を更新し、通常判断は統括が実依頼する。別の選択が有望ならこの枠内で契約を作り替えるが、結果を見た正式判定緩和は行わない。

終了: 目標達成、ユーザーpause、上限/guard/異常、2026-10-02 01:00UTC。2026-10-02 00:50UTCまでに新重jobを止め、終了処理を確保する。全ownerはPID/starttick/command/hash/exit/資源/失敗/stopを先保存、報告は簡潔に詳細JSONへリンク。達成なら独立根拠で目標close、未達なら次の継続/停止理由を記録。予算を自動延長しない。各実行deadlineは本枠以下。担当へ実送信/受領をBeadsとdispatchに記録する。

継続委任は目標へ向けて継続する指示である。未達の場合は本枠終了前に統括が次枠の必要性/予算/検証を判断し、ユーザーへ通常詳細の再承認を求めず別契約として具体化できる。同一枠の期限や累積12GiBを黙って拡張しない。

## 契約版2の期限変更根拠

2026-10-01、操作元root 01a0f2e9-357d-7ef3-a2fe-b16f80accda5からユーザー明示指示を受領。「明日午前10:00」は2026-10-02T10:00:00+09:00 = 2026-10-02T01:00:00Z。開始時刻は維持し、旧継続枠終了2026-10-01T17:00:00Zから終了時刻だけ変更する。重い処理停止00:50UTC（09:50JST）、監督運用停止00:55UTC（09:55JST）、monitor回収00:58UTC、枠終了01:00UTC（10:00JST）。目標達成・pause・guard停止条件と時間以外のCPU/RAM/LLM/累積容量・許可範囲・独立検証は変更しない。

旧版SHA859bb777836cc0683e1ad7d1763a71fda60c75d2d6391290cef28771589a81a2を.artifacts/ai-sigma/continuation-20261001/DEADLINE-20261002-1000/continuation-version1.mdへ保全。閉じた実験や旧個別契約の処理/提出期限、事前登録、旧失敗/逸脱を遡及延長しない。新実験・比較は別契約で結果前に固定する。統括.52が正本/Beads、steward.53が既存所有範囲の運用契約/config/reload/monitor更新と実反映を担当する。


# .69保存裁定と.71部分成立の統括受領

2026-10-01 21:06UTC。目標は未達、actual_go=false、新対局0。

.69はphaseAの同実経路分類・有限cache・PRNG/96採番を限定支持し、.70のready/保存1944feature bits・411NN/参照cp1件/ACK3を独立保存監査した。独立NN/Chromiumは0である。審判/encodingがcaller stamp後の不足、fresh/goal/4ply未実施を採択し、実接続全体no-goを保持する。元.69の期限は延長しない。この限定根拠で本人がcloseできるが、対局go・製品採用・旧失敗の救済ではない。

.71では新共通startup6rootとJudge/clone/UTF8 encoding後の最終stamp、finish/次t0の接続、失敗後Model dropを実装した。一窓の通常候補・参照と取消3公開は保存支持、fresh以前の数値helperが候補固有の合法順をSigma順と同一と仮定して停止した。これはNN不一致の証拠ではない。runtime検査失敗/fresh・両goal・4ply未実行を保存し、entry_ready/actual_go=falseを維持する。

統括は424 unique参照の実hash一致を確認した（COMPLETE-CLOCK-REVIEW-NEXT/hash-review.json）。.71の62、.69自身の25記録identityは現在不在を別途照合し、現在不在を当時の自然停止・全期間遵守にはしない。保存数値の照合を旧実gate成功に付け替えない。

次は.72 experimentに新copyの検査器だけをengine別Action対応へ修正する契約を渡す。候補/参照それぞれの順序と集合を独立に検査し、Actionごとのsoftmax/priorを照合する。探索の順序や期待値は変えず、一つの凍結窓で最大11公開/fresh/goal/4plyを確認する。独立実検証とfreezeを経るまで対局しない。

.73 hypothesisには新startup/public時計版の別m32/64browser計画を勝敗前固定させる。旧m48条件は変更せず、最遅21:13:18.500まで未完成なら当該計画はno-go。新m32は8600+1.5秒/最遅22:06:38.500の別登録、旧32局非統合、探索的精度と正式NI未立証を明記する。標本数の結果後調整はしない。

旧容量・期限・scope・RSS/affinity欠測、旧g287/62+82/340秒/2.26秒、真合法200/no-legal/deep/rawview/entropy/training overlap未確認を保持。親Oct2 01:00UTC、終了余裕、CPU4/RAM8/global3/累積12GiB、製品許可範囲は不変。


固定入力報告全文
EXPERIMENT_REPORT SIGMA-STREAMING-COMPLETE-CLOCK quoridor-4lc.71 / trial1 / contract1

部分成立/no-go、actual_go=false/entry_ready=false。受領20:49:38・claim20:50:16、全文/親版2/ready/show/pauseなし、開始report accepted。処理21:09:38・新job21:04:38・提出21:19:38の早い方を維持。旧70公開3/VMhelper失敗/Modeldrop欠測・69後stamp不足は別入力として不変。

新copyのみ。array要素/長さ/finite/bit/rangeをrealm非依存で検査。VM/普通/Float32/Uint32と要素差/長さ/NaN/Inf/rangeをNN0で反証。Judge.validateとAction clone/UTF8 body encodingをfinal-envelope内の最終Node stamp前へ統合し、game-loopは既判定Actionを消費して再Judge/encodingしない。null/late再encoding後再stamp、public/finish/次t0を同t1へ接続、初回入力もready後・審判replay前の始点を保存。Judge/encodeのD前/同時/後とgame-loop後検査無し、実host→pending→final→分類12件/既run拒否/actualfalse子拒否を小NN0で確認。actual正経路は同factory/時計/分類へ接続し固定coordinator freeze/独立acceptance SHA/期限/予算を要求するが、正proofは自己発行0/未実検証。未token/旧hashはAPI拒否で、全actual CLI子組合せは未完了。

新事前登録の同initial/asym-P2/jump-P2各engine root1NN・計6startup/sessionを実施。features/137NN/strictvalue/固定gate、handle/activeNN/live0を確認してready、木/history/cache再利用0。startup6は手内標本でなくjobwall/RAMへ課金、旧readyへ遡及0。

実一窓 2026-10-01T20:57:55.754576+00:00 → 2026-10-01T20:58:06.044879+00:00、exit0/guard停止0。public3/最大11: 候補Action13・417.698ms、参照Action13・413.477ms、候補完成cp後取消/null・93.726ms。final stampとelapsed一致、次t0=前最終stamp、finishも同body保存。startup以外の原NN/PUCT/FPU/limits/rules/T500-89-9-402-411不変。

fresh前numeric helperが候補native順[3,5,13,81,…]を参照Sigma順[13,3,5,81,145,…]へ同順期待してERR_ASSERTION、CLEANUP_PENDING_FRESH_FORBIDDENで停止。これは新helper期待値の誤りで、順変更やNN失敗と断定しない。凍結実source修正/NN再試行0、fresh両正常/goal両側/4plyは未実行。保存だけの算術では候補sim3/参照sim5のcpを各自旧controlへ照合し、action/全root visits/prior/value/各native順が一致、手内1944bits/411NNも固定gate支持。原runtime検査失敗を救済しない。

数値helperからdrop/clock/所有回収を分離したため、失敗後もModel drop ACK handles0/activeNN0、3search stopACK handles/activeNN/live0、inner forced controlledPID0とouter sole-root/subreaper/kernel-adoption同identity waitを保存。本文前source/runtime stop/hashafter、62記録identity現在不在。自然終了/全期間保証へ格上げ0。観測TID CPU2/threads1、RSSpeak1527848960B、保存peak3305472B<112MiB、TMP込み/新予約追加0・旧peak/課金減額0。瞬間peak/背景/短い非guard静的PIDRSS欠測を保持。NN0はfirstinput/finish接続修正に応じ3版の小gateを分離、最初phaseA exact UTC bytesの上書き欠測はlog/job-sourceと区別。停止観測が短い自己NN0子と重なったfalseを保存し、その終了後再確認してgate成立、NN中static並行0。

42原入力hash不変。entry manifest SHA 39f0bb98e7889754d67043c3fd613326dbd0c88e1e2aa7b414c46d6463a17d9f、source-frozen SHA 5b509ce5c881e77a2c415aa54bc33deff1cd729b4f222865d5adf7b2f97f4ae0。詳細 [handoff](../../.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-COMPLETE-CLOCK/handoff-summary.json)、runtime-source-stopped-before-report、copy-patches/input-after、real-GOLDEN71-ONCE-session1、golden71-once.process/log、offline-saved-arithmetic。独立は同最終版へ新binding/別契約が必要、旧69期限を延長しない。

対局/holdout/build/取得/学習/GPU/追加委譲0。71受入れ待ちin_progress/目標他者close0。公平性/時計tail/棋力/NI/Sigma達成未認定、A/B/C・H1〜H4、旧32局/g287/62+82/340秒/2.26秒、旧容量/期限/scope/affinity/RSS/deep/rawview/entropy/training不明不変。m48最遅21:13:18.500/11800+1.5秒条件を縮めず未完成ならno-go。


.71元契約全文（旧期限の履歴、今回延長ではない）
# SIGMA-STREAMING-COMPLETE-CLOCK / quoridor-4lc.71 / 試行1・契約1

experiment 01a0f31d-6d15-7620-bb63-4b4f878e4746 → coordinator。親継続版2 SHA6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f 全文継承。終了Oct2 01:00UTC/10:00JST、重job00:50/監督00:55、global3/CPU4logical/総RAM8GiB/累積12GiB/製品範囲不変。受領から処理20分/提出30分と絶対処理21:10/提出21:20UTCの早い方、新jobは処理5分前停止。旧.70/.69の個別期限を延長しない。

問いは既.70の二つの具体的失敗（VM realm配列の検査で回収が止まる、審判/encodingがcaller stamp後）を最小修正し、両AI同じstartup-readyから同じ最終public境界を成立させられるか。別の新試行とし、原.70公開3/予定最大11、model.ready成立、candidate初回noCP/refAction13/cancelnull、fresh/goal/4ply未実行を救済しない。元3件のstamp443.203/413.065/244.406ms、embedded elapsed差・Model drop欠測・forcedと内側失敗を保持。

## 入力・owner

原.70 entrymanifest SHA8885a9b3daedf296e810e6282b65f76d23b3c02d8a6f684184cc244ff2dac2a3、source-frozen-before-runtime SHA02139e9cf3b2cf91661298e7afcd7d00675e9f92e8058e5c051419466e99160b、finalmanifest SHA8b496a7d38eb4ac2523ae3ed1b3b318603434efb3d25e49623372dedeb7ac043、report SHAfe8530afea9f02f50027aa86fd5f0736a1ee9525546443b9ea1385c7f993491e。統括138checks/36旧sourcehash一致、runtime tracked36現在不在を確認済み（owner50と別分母）。根拠 `COMPLETE-CLOCK-HANDOFF/input70-review.json`。旧.69phaseA固定報告SHA336c027f9fd369d16276a936fdc3935d551a62ac44150da3348c40562e23d044と統括phaseA判断を読む。

write ownerは新 `tools/ai-sigma-streaming-complete-clock/`、`.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-COMPLETE-CLOCK/`、`docs/reports/ai-sigma-experiment-streaming-complete-clock.md` のみ。既source/raw/preregister/model/rootlock/製品/registryはread-only。必要sourceだけcopy、旧全raw/cache・全歴史複製0。原.68/.70の失敗/guard超過と予算を上書きしない。

NN/kernel/ONNX11,663,428B SHA d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d、.26 immutable Wasm1f54d0b8f0c6d3d7d51935886ed506e44376a2052506be62ca7a726c85a78a01、ORT1.21wasm/threads1/proxyfalseを維持。候補PUCT1.5Q0/seed1979/原tie-finish/4096-512-24、参照C1/FPU.2/temp0/first/order/bestAction/100000/root展開sim外/uncappednull、RuleA/history/終端は不変。T500/reserve89/commit9/cutoff402/seal411、fault受信順policy/初回無しnull/fallback0も固定。公開rootNNvalueとrefrootq、edge sim−1とsim/root sim＋1を区別。

## 最小修正・同public境界

配列のprototype/realmを同一性と誤認せず、長さ/型/finite/f32bitsと要素順で同値を検査する。期待値や数値閾値を緩めない。VM返却/普通配列/Float32/Uint32、要素一つの不一致・長さ/NaN/範囲はNN0で反証する。数値helperの例外がModel drop/所有回収を省略させないようfinally等で両責任を分離し、元primary exceptionとcleanup secondaryを保全、必須数値不成立は検索成功にしない。

game-loop/J.validate/必要なAction/body UTF8 encodingを**同じ最終public判定の前**へ統合し、その後Node t1を取り、public保存・finish・次t0がこのt1を参照する。方式の詳細は担当判断。stamp後の二重検査/再encodingを残してcaller stampを最終と呼ばない。late/null枝の再encoding後にも再stampが必要。審判の決定自体は変更0。直接診断とrunGameのpublic経路を共通化し、Judge/encode遅延注入D前/同時/後で採用/破棄と次時計をNN0で実検査する。旧NNを待ってDにWorker問い合わせる方式へ戻さない。private大tree/logは後保存でも次t0=前最終public stampから課金する。

実hostFault→完成cache caller→pending照合→最終public→実classifierの7修正を維持。referenceNN/model/fallbackだけpair invalid、candidate同障害loss、reference timeout/crash/noCP/lateはloss、FINAL_IDENTITY両側/sharedinfraはinvalid。typedboolean/strict[-1,1]/finite/P2/合法/prior/identity/gen/prefix/seed/limitsと古い応答拒否は実同経路を使い、別人工分類器を追加しない。今回の差分に関係する小NN0 gateだけを実行し、元14suite全反復/全raw複製は不要。

## readiness・新結果前登録・実一窓

新startup規則をNN前preregisterする。load/hash/schema/thread確認後、固定initial-p1/asym-hv-p2/straight-jump-p2のroot NNを両engine同じ規則で各1回（計6root/session）だけ実行し、各shape/finite/strictvalue/固定数値gateを確認する。完成木/history/cacheを破棄しhandles/activeNN/live0を確認してreadyとする。startup6は手入力供給前だけ時計外、jobwall/RSS/再起動費には全課金し、手内warm/思考成功/統計標本に混ぜない。match poolは送らない。入力供給後の再load/warmは次t0から課金、黙ってリセットしない。startup規則は旧.70readyへ遡及適用しない。

同最終main正診断token、fixedinitial5（candidate/reference正常→candidate完成cp後cancel→旧ACK0→fresh両正常）、両合法goal2、golden4plyをoutcome前停止、public最大11/一最終source一窓を事前固定する。初回無し・遅配・warm・取消・未実行・失敗を分母に残し、救済NN窓再試行0。新startup6は別分母、Model/session/processのfresh種別を明記。fresh以前の数値検査とdrop/ACK/外側controlled PID0が成立しないならfreshを開始しない。原.70のmasked/VM failureは元証拠のまま残す。

同mainの実backendが一般合法prefix/審判/取引/公共watchdog/最終時計へ結線されることを確認する。actual --run経路はcoordinator freeze token・preregister/source manifest・独立critic受入れの指定SHA・期限/予算/既run拒否を必要とする接続を実装し、**この契約で本番token/proofを自己発行しない**。backend前のfalse-go/未token/旧hash/既run拒否を実CLI子で検査する。実際のbackend正経路は診断用の同mainで最大11のみ。mockとactualが別の分類・時計・create/finish/stopを使わないことを示す。予定48/96・m/抽出/order/色は登録のまま、poolへの実送信/試合は0。新方式の比較は新受入れ/結果前登録/統括freezeまで禁止。

数値648features bits/137NN/合法priorをshape/finite/strict[-1,1]/P2先検査→abs<=1e-4+1e-4|ref|、保存fixedgoldenへのgateを保持。公開完成cp/統計は固定対照へ照合、receiverでAction再選択0。終端NN0を推論成功にせず、任意finite tree/真合法200/no-legal一般性を証明しない。

## 資源・終了

staticCPU0/runtimeCPU2単logical/NNthreads1、RAM4GiBguard3.5/new128MiBguard112は既entry2GiB内・追加予約0。起動前profile/temp/log/raw/時計/endingの保守headroomを保存、不足ならNN0で停止。旧peak/予約/cum12GiB/条件付き未配分3,593,041,453Bは減額/リセット0。重job180秒上限、他重NN停止・sole-root空child/subreaper/kernel adoption/boot-PID-starttick限定wait、TMP/XDG専用。runtime sourceは凍結し正確command/hash/UTC-monotonic/RSS/TID/保存量/PPID/wait/欠測を保持する。強制回収を自然終了へ格上げ0、未知所有signal/wait禁止。

本文前runtime/source停止・hashafter/manifest/全primary-secondary/数値/時計/分母を固定。最終source停止/hash/PID0を早く報告し独立担当へ渡せるようにするが、期限遵守を省略しない。helper一原因一修正は旧証拠保持・NN0/窓救済反復0、guardなら停止。独立実検証が未完了ならentry_ready/actual_go=false。69の既期限に間に合わない場合は別独立契約を統括が判断し、旧69を延長しない。backup/report→coordinator、本人受入れ待ち/goal他者close0。

build/取得/依存同期/製品/学習/GPU/対局/holdout/追加委譲0。最遅m48入場21:13:18.500/11800+1.5秒を縮めず、未完成なら当該比較no-go。別比較は新事前登録であり旧成績やCIに混ぜない。Atract/BORT/CB0・H1〜H4、旧32局/NI未立証/Sigma未達、g287/62+82/340秒/2.26秒・旧容量/期限/scope/affinity/RSS欠測・deep/rawview/entropy/training不明を保持する。
