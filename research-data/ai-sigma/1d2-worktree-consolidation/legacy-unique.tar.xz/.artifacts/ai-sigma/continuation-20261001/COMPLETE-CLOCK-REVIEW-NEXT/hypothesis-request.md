研究継続の実依頼。ready/show/pause確認・自.73 claim/受領開始を記録し、通常判断は契約内で進めてください。NN/engine/対局送信0、全契約は以下。

# SIGMA-STREAMING-COMPARISON32-PLAN / quoridor-4lc.73 / 試行1・契約1

hypothesis 01a0f31c-2e4b-7170-82c5-69e1428c2418 → coordinator。親継続版2 SHA6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f全文継承、Oct2 01:00終了/00:50重job/00:55監督・global3/CPU4/RAM8/cum12GiB/許可範囲不変。受領から処理20分/提出30分と絶対21:35/21:45UTCの早い方、新jobは処理5分前停止。静的計画のみ、NN/Chromium/engine/holdout実送信/対局/build/取得/委譲0。

## 新計画を設ける根拠

旧.67のm48/96は固定のまま保持し、最遅21:13:18.500までgate未完成ならno-go。結果を見て旧mを縮めない。今回の新比較は新startup6root/sessionと審判+encoding完了最終public時計版に対する独立の探索的browser m32/64game計画であり、新方式の完了可能性と未評価の棋力を見る。新source最終binding/独立実入口/clock/ownership/責任gate/統括freezeがない限りactual_go=false。旧32game/nativebrowserと統合しない。browserだけでnative+browser目標達成としない。

write ownerは .artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-COMPARISON32-PLAN/、tools/ai-sigma-streaming-comparison32-plan/、docs/reports/ai-sigma-hypothesis-streaming-comparison32-plan.mdだけ。旧48preregister SHA9e05356a42dd79cc8c5ec3427c1e0937c81bf6c82773bffd9c257d238c69dc27/.48初期SHA05cf461e23998e7e230c05b280a16f4105723cd1b5d4604f28f5374272961002/旧rawは不変。旧source/entry/72実装owner/モデル/rootlockはread-only。新計画は旧pool64を使い、旧実送信8indices除外56から新selection2026100501/order0502/color0503を別PRNGで32抽出/色交換64採番する。旧未実行計画との重複は明示、未知全host送信/過去training重複は未監査。送信済の反証があれば計画全体無効/補充0。

## 結果前固定・算術

browser候補ORT pending対固定Sigma-Web同Node caller/T500/reserve89/commit9/cutoff402/seal411。startup固定initial/asym-P2/jump-P2各側root1NN計6/session、木historycache破棄/ACK0でready、startupoutsidehandだけjobwallRAMへ課金。次t0は前最終Judge/UTF8後stamp、残NN/stop/審判/log/reloadreadyは次時計から引かず全課金。両threads1/CPU2単logical/同RAM/通知頻度、rootvalue意味/visit規約別、receive-orderfault policy/fallback0を明示。source最終SHAはplaceholderを実受入れとせず、72停止＋独立契約裁定の後にcoordinatorが固定する。hypothesisは実入口/設定へ書かない。

候補PUCT1.5Q0/seed1979/原tie-finish4096sim/512node/depth24、参照C1/FPU.2/temp0/legal順first/bestAction100000sim/root展開sim外/uncappednullを保持。RuleA合法history/反復/goal優先/200plydraw/no-legal。全prefix合法replay/history/turn/remainingply/uniqueness/golden除外を検算。終端はNN0、人工は棋力prefixにしない。

各pair同prefix先後、固定順/seed、candidateNN/model/fallbackはloss、fixedreference同NN/model障害だけpairinvalid、sharedidentity/refereeinfra invalid、両timeout/late/crash/noCP/未知無応答は責任engine loss。pairretry1/globalretry2、同prefix/seed全pair再試行、補充0/有利sample選択0/複製を独立sampleにしない。未完了は完成/予定mを分離しLなし。全attempt/invalid/rejected・停止理由を保持。pause/guard/deadline/signalで停止・欠測を成功にしない。

scoreはpair Xi=(candidate2gamesの勝ち1/引分.5/負け0の平均)、m32平均。事前参考L=max(0,meanXi−sqrt(log20/(2m)))を固定、95%Hoeffding片側参考下限と正式NI判定/母集団一般化を区別。許容差.05/threshold.45の正式NIにこのmで同等近傍なら精度不足となることを算術で示す。mやCIを結果後変更しない。将来の有効CI/power/必要mは競合する次案として別費用付き提案、今回評価器に後付けしない。

worst wall=64×200ply×.5s+startup400+retry1200+保存600=8600s、停止reserve1.5s、match stopOct2 00:30/save00:50/監督00:55/global01:00。最遅開始Oct1 22:06:38.500UTCを別Python/Nodeで再算する。実freeze時の残量不足/独立gate不成立ならno-go、旧短平均や好成績でworstを減らさない。これはminimum入場条件で完遂/tail保証ではない。

同main用のpreregister schema/control-planへの接続表を作り、prefix/order/colour/採番/score/retry/budgetのcompact NN0 scenarioを検算する。実backend/別mock分類器の検証と呼ばず、PythonとNodeの独立PRNG+算術を実行する。旧67の各scenario raw重複でguard超過を再現しない。共有prefix辞書/差分scenario要約を使い、中間原資料/失敗は削除しない。保存上限が近ければ小summaryで停止し追加runしない。

## 資源・保持

CPU0/RAM1GiB（NodeAS1GiB制限を渡さずheap192+RSS896MiB監視）、新32MiBguard28を未配分3,593,041,453Bから予約し条件付き残3,559,487,021B。全owner実現在量の証明ではなく旧課金/旧67peak/予約/cum12GiBを減額・リセット0。全jobcommand/hash/UTC/monotonic/PIDstarttick/exit/affinity/RSS/保存量を記録、短命/instant欠測は0補完しない。終了前hashafter/自己PID0/source停止/manifest→backup/report。coordinator受入れ待ち、自他goalclose0。

Atract/BORT/CB0・H1backend/H2探索/H3clockcp/H4標本を維持。束変更と旧32局差から改善原因を断定しない。旧失敗・旧69独立実NN0・旧71public3/fresh未成立・NI未立証/Sigma未達、true合法200/no-legal/deep/rawview/entropy/training未確認保持。実実装72の進行を止めず静的計画を作る。今回の通信受付・静的成功は対局freezeではない。


# Sigma自律研究・継続枠 2026-10-01

契約版2。目標quoridor-4lc。統括01a0f31b-3409-75f2-a30e-453a50484f94。根拠はユーザーの明示継続/詳細委任（root入力01a0f2e9-357d-7ef3-a2fe-b16f80accda5）。開始2026-10-01T09:03:36.459834+00:00、終了2026-10-02T01:00:00Z（2026-10-02 10:00 JST）。本書は新しい実行枠であり、旧目標契約版2の初期04:00終了/未達/過去逸脱を保持する。旧文書・旧preregister・成績は変更しない。目標/比較A/通常製品規約維持/独立検証/権限は旧目標契約を継承する。

固定Sigmaと同計算資源・思考時間でnative/localおよびbrowserの非劣性を実測する。旧32局m8のnative.5625/browser.1875と両下限未達を保持。今回の新比較はcode/model/config/pool/T/g/m/CI/停止/責任分類を結果前に別事前登録し、旧結果へ後付け条件変更/標本統合をしない。未使用m10計画は参考として残すが、実入口/共通時計/資源gateと新deadlineを独立freezeするまで対局禁止。

予算はCPU全計4logical、RAM全計8GiB、LLM最大3（統括と新supervisorを含む）、正式CPU比較はCPU2単logical/推論threads1/GPU推論0/他の重い研究job停止。GPU研究は旧上限6GiB・1job30分・累積2h以内を保持し、今回は別配分前GPU/学習0。成果/依存は旧枠から累積12GiBを維持、リセット/12GiB追加ではない。旧限定保守課金6,588,000,723B・条件付き残6,296,901,165Bを開始時再確認する。初回新規予約: entry2GiB（guard1.75GiB）、steward128MiB、監督32MiB、統括文書32MiB。未配分は基準再確認後に統括が同12GiB内で配分。副次cache/途中展開/一時profileも計上。既存共有training/cacheは読取のみ、削除はこの枠が所有する再生成物だけを証拠保持の上で別に判断。

既存五役saved sessionを維持、新supervisorは既存App Serverに永続登録して観測専用で追加。App Server/toolchain再起動やモデル/effort変更をしない。新有料API/クラウド/第三者オンライン対局なし。主checkout製品/UI/描画/M2/commit/push/公開は対象外。研究worktreecodex/ai-sigmaで新copyに実装し旧入力をhashで固定。スケジューラーは主checkoutのpush済み操作入口を利用し、運用role定義/registry/専用configだけを用意する。

監督issuequoridor-4lc.40、20分周期/1turn180秒（新job120秒で停止し報告へ）、終了2026-10-02 00:55UTC、観測のみ。globalは3だがschedulerの起動閾値max_active_sessions=2として統括報告の起動1枠を残す。枠使用中はskipしsteerしない。変化なしは保存のみで静かに終了、意味ある停滞/失敗/期限資源/完了時にだけ統括へreportする。監督が設定や課題配分を変更しない。pause/終了はownedturnだけinterrupt確認し、外部jobは各ownerが回収する。dispatcherや監督の停止だけでNN停止を認定しない。

初回はquoridor-4lc.38stewardがscheduler準備/実運用/容量/資源台帳、quoridor-4lc.39experimentがORT入口・復旧gateを担当。途中から競合A共通tract/B分離ORT/C B0とH1backend/H2探索/H3時計・checkpoint/H4標本を更新し、通常判断は統括が実依頼する。別の選択が有望ならこの枠内で契約を作り替えるが、結果を見た正式判定緩和は行わない。

終了: 目標達成、ユーザーpause、上限/guard/異常、2026-10-02 01:00UTC。2026-10-02 00:50UTCまでに新重jobを止め、終了処理を確保する。全ownerはPID/starttick/command/hash/exit/資源/失敗/stopを先保存、報告は簡潔に詳細JSONへリンク。達成なら独立根拠で目標close、未達なら次の継続/停止理由を記録。予算を自動延長しない。各実行deadlineは本枠以下。担当へ実送信/受領をBeadsとdispatchに記録する。

継続委任は目標へ向けて継続する指示である。未達の場合は本枠終了前に統括が次枠の必要性/予算/検証を判断し、ユーザーへ通常詳細の再承認を求めず別契約として具体化できる。同一枠の期限や累積12GiBを黙って拡張しない。

## 契約版2の期限変更根拠

2026-10-01、操作元root 01a0f2e9-357d-7ef3-a2fe-b16f80accda5からユーザー明示指示を受領。「明日午前10:00」は2026-10-02T10:00:00+09:00 = 2026-10-02T01:00:00Z。開始時刻は維持し、旧継続枠終了2026-10-01T17:00:00Zから終了時刻だけ変更する。重い処理停止00:50UTC（09:50JST）、監督運用停止00:55UTC（09:55JST）、monitor回収00:58UTC、枠終了01:00UTC（10:00JST）。目標達成・pause・guard停止条件と時間以外のCPU/RAM/LLM/累積容量・許可範囲・独立検証は変更しない。

旧版SHA859bb777836cc0683e1ad7d1763a71fda60c75d2d6391290cef28771589a81a2を.artifacts/ai-sigma/continuation-20261001/DEADLINE-20261002-1000/continuation-version1.mdへ保全。閉じた実験や旧個別契約の処理/提出期限、事前登録、旧失敗/逸脱を遡及延長しない。新実験・比較は別契約で結果前に固定する。統括.52が正本/Beads、steward.53が既存所有範囲の運用契約/config/reload/monitor更新と実反映を担当する。


# .69保存裁定と.71部分成立の統括受領

2026-10-01 21:06UTC。目標は未達、actual_go=false、新対局0。

.69はphaseAの同実経路分類・有限cache・PRNG/96採番を限定支持し、.70のready/保存1944feature bits・411NN/参照cp1件/ACK3を独立保存監査した。独立NN/Chromiumは0である。審判/encodingがcaller stamp後の不足、fresh/goal/4ply未実施を採択し、実接続全体no-goを保持する。元.69の期限は延長しない。この限定根拠で本人がcloseできるが、対局go・製品採用・旧失敗の救済ではない。

.71では新共通startup6rootとJudge/clone/UTF8 encoding後の最終stamp、finish/次t0の接続、失敗後Model dropを実装した。一窓の通常候補・参照と取消3公開は保存支持、fresh以前の数値helperが候補固有の合法順をSigma順と同一と仮定して停止した。これはNN不一致の証拠ではない。runtime検査失敗/fresh・両goal・4ply未実行を保存し、entry_ready/actual_go=falseを維持する。

統括は424 unique参照の実hash一致を確認した（COMPLETE-CLOCK-REVIEW-NEXT/hash-review.json）。.71の62、.69自身の25記録identityは現在不在を別途照合し、現在不在を当時の自然停止・全期間遵守にはしない。保存数値の照合を旧実gate成功に付け替えない。

次は.72 experimentに新copyの検査器だけをengine別Action対応へ修正する契約を渡す。候補/参照それぞれの順序と集合を独立に検査し、Actionごとのsoftmax/priorを照合する。探索の順序や期待値は変えず、一つの凍結窓で最大11公開/fresh/goal/4plyを確認する。独立実検証とfreezeを経るまで対局しない。

.73 hypothesisには新startup/public時計版の別m32/64browser計画を勝敗前固定させる。旧m48条件は変更せず、最遅21:13:18.500まで未完成なら当該計画はno-go。新m32は8600+1.5秒/最遅22:06:38.500の別登録、旧32局非統合、探索的精度と正式NI未立証を明記する。標本数の結果後調整はしない。

旧容量・期限・scope・RSS/affinity欠測、旧g287/62+82/340秒/2.26秒、真合法200/no-legal/deep/rawview/entropy/training overlap未確認を保持。親Oct2 01:00UTC、終了余裕、CPU4/RAM8/global3/累積12GiB、製品許可範囲は不変。


旧.67報告全文（旧失敗/期限を延長しない）
# SIGMA-STREAMING-MATCH-ENTRY-PLAN / quoridor-4lc.67

試行1・契約1、hypothesis 01a0f31c-2e4b-7170-82c5-69e1428c2418 → coordinator。契約80729b9f…98e、親版2を全文継承。受領/claim18:56:57 UTC、処理19:26:57・新job19:21:57・提出19:36:57。計画・同入口mockのみ、NN/Chromium/実engine/対局/holdout送信/build/取得/委譲0。

**提出は部分成立・no-go。** 旧48prefix/色交換/96採番を保持した別preregisterと、同execute/main経由のmockを実装・実検査した。一方、最終再検査中に保存28MiB guardを超過したため処理停止。exit0と13検査ログを契約成功へ格上げしない。Python/Node別PRNG・score/retry/予算検算はscript生成済み・未実行。entry_ready=false/actual_go=false。.66受入れ・実入口結線・独立game-loop・freezeは未成立扱い。

旧pristine .48 SHA05cf461e…1002不変。新preregister SHA9e05356a42dd79cc8c5ec3427c1e0937c81bf6c82773bffd9c257d238c69dc27、48pair全内容が旧と厳密一致（selection2026100301/order0302/color0303/seed1979、除外8も保持）。新pool/補充/有利選別0。未使用は旧pool64から初回送信8を除いた文書根拠であり全host送信・未知training重複未監査。送信反証があれば全計画無効。旧T500g91、旧32局、旧m10は変更・統合0。

新登録はbrowserのみ探索的m48/96、T500/reserve89/commit9/cutoff402/seal411と同Node caller・受信順故障政策。candidate PUCT1.5/Q0/4096sim/512node/depth24、reference C1/FPU.2/temp0/first/legal順/bestAction/100000sim/root展開sim外を維持。root NN value対root qValue、edge訪問sim−1対sim・root sim＋1を別規約として登録し再選択0。.65最終revision3 source b66988de…698b1、manifest8778edbf…5132を固定し、元80入力afterhash一致。copy/diffは各patch、entry-manifestに全sourceと旧入力binding。モデル等はread-only。

元main/game-loop/judgeをcopyし、mainInternal→execute→同runGameでprogrammatic mockfactoryだけを投入。importでbackend開始0、実CLIにmockfactory注入経路なし。未token/旧issue・旧critic proof/hash mismatch/既runを拒否、正しい診断tokenはmockのみ。実backendは常に拒否し、critic66/new-entry/coordinator実freezeを自己発行しない。startup-ready後の最初prefix、次t0=前公開stamp、旧stop待ち/審判/ログ/監視/必要reloadを含む設計。無応答は手Tでpublic discard、cleanup pendingを待たず次のfresh禁止。実pause/外側guard/ownership/任意prefix echoは未実検査。

有限mockは14scenario・13checkが最初/最終別版で通過。全96採番/色交換/score Xi/L、candidate fault loss・reference timeout loss保持、reference NN/model→pair invalid、pair retry1/global2・同prefix/seed・補充0、pause/deadline/signalのpartial/Lなし、no-response/public timeout、cleanup永久待ち/fresh禁止、既signalCode/idempotent mock、identity invalid/partial cp拒否、goal優先/200draw、同game-loop合法goal、正token・既run拒否を確認した。mock全96のXi=.5、参考L=.323349…は人工結果で棋力データではない。実pre/postseal fault通知の包括反証・深い履歴/真合法200/no-legal一般性は未成立。

m48の幅sqrt(log20/96)=約.176651で、同等付近でも広い区間。browserだけでnative目標を達成せず正式NIなし。完成48のみL、未完了は完成/予定分母を分ける。cleanup失敗scenarioはscore欄が完了でも運用適格ではなくno-go。最悪思考9600+startup400+retry1200+保存600=11800秒＋停止1.5、match stop Oct2 00:30・save00:50・監督00:55・global01:00、最遅開始Oct1 21:13:18.500を登録。これはminimum入場条件で完遂/tail保証ではない。

失敗: 初回NodeはRLIMIT_AS1GiBでCodeRange予約失敗/exit−5。証拠を保持し、heap192MiB＋RSS896MiB監視/20ms、RLIMIT_RSSはadvisoryに一原因修正。最初のmockはexit0。nested identity freezeとfinal legality/encoding補強後の別mockも13checkログを保存したが、raw/table/prefixを各scenarioに重複保存してguardを超え、supervisorは停止要求。最終exit0はguard適合を意味しない。旧/失敗raw削除0。追加再試験0。残余reserveで停止/hash/文書のみ保存。

停止証拠runtime-source-stopped.jsonを本文より先保存。記録3Node PID/starttick現在不在、wrapper各exec終了。Node TID全CPU0、観測parent+child RSS最大106,672,128B、Node累計CPU約8.676s（全短command/wrapper CPUは欠測）。launcher PID/starttick各jobは未保存、瞬間peakは未保証。停止時新allocated31,309,824B、28MiB guard超過・32MiB ceiling未超過、文書/最終manifestもceiling内で保存。予約後条件付き残3,593,041,453Bは全owner独立容量証明ではなく累積12GiBリセット0。

backend-interface-and-gates.mdに .65 create/notify/finish/stop接続表と実prefix/producer echo/postvalidation stamp必要gateを記録。mockにstamp後の追加encodingが残り、実結線時に最終encoding後stampへ直す必要がある。この欠陥はguard後に修正せず保持。副作用なしimportはcode/同main検査の有限支持、実runtime保証ではない。

再現: `python3 <scope>/supervise.py <newname> node --max-old-space-size=192 --max-semi-space-size=4 --no-node-snapshot tools/ai-sigma-streaming-matches/mock-gates.cjs <newphase>`。現枠はguard停止済みなので再実行しない。未実行scriptはverify-plan.py/cjs。rawはmock-*/summary/checkpoint、final-mock-summary、各*.process/log、input-before/after、preregister/readiness。次は別契約で保存重複を避けた小mock/二言語検算/encoding境界修正と独立gateを先に行い、実backend・.66受入れ・統括freeze前に対局へ進まない。

書込停止・自己runtime停止、backup/report予定。.67受入れ待ちin_progress、本人close0・goal/他者close0。Atract/BORT/CB0、H1/H2/H3/H4、旧g287/62+82/.63元340秒/.65原2.26秒・検証9.686>9・公開後追加NN、旧32局/NI未立証/Sigma未達、来歴配布/training overlap/rawview/entropy/容量・期限・scope・RSS欠測を保持する。
