import asyncio, datetime, hashlib, importlib.util, json, pathlib, sys

ROOT=pathlib.Path('/workspaces/quoridor')
CWD=ROOT/'.worktree/ai-sigma'
OUT=CWD/'.artifacts/ai-sigma/continuation-20261001/STREAMING-ENTRY-REPAIR-HANDOFF'
SPEC=importlib.util.spec_from_file_location('team', ROOT/'scripts/dev/research-team.py')
m=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(m)
ROOT_THREAD='01a0f2e9-357d-7ef3-a2fe-b16f80accda5'
def save(name, value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

async def main():
    mode=sys.argv[1]
    assert mode in ('experiment','root','observe')
    host=m.command_json(['codex','app-server','daemon','version'])
    with m.dispatch_lock(ROOT):
        m.require_issue('quoridor-4lc',ROOT)
        registry=m.load_registry(ROOT/'.artifacts/research-team/registry.json',ROOT)
        async with m.AppServer(host,timeout=20) as s:
            states={}
            threads={}
            for role in registry['roles']:
                ent=m.role_entry(registry,role)
                threads[role]=await s.read_thread(ent['thread_id'] if 'thread_id' in ent else ent['id'])
                states[role]=threads[role]['status']['type']
            threads['root']=await s.read_thread(ROOT_THREAD)
            states['root']=threads['root']['status']['type']
            if mode=='observe':
                tid=threads['experiment']['id']
                turns=await s.request('thread/turns/list',{'threadId':tid,'limit':1,'sortDirection':'desc','itemsView':'full'})
                save('experiment-start-observed.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'states':states,'turns':turns})
                print(json.dumps({'states':states,'turns':[{'id':t['id'],'status':t['status'],'error':t.get('error'),'items':len(t.get('items',[]))} for t in turns['data']]}))
                return
            role=mode
            if mode=='experiment':m.require_issue('quoridor-4lc.68',ROOT)
            target=threads[role]['id']
            if sum(v=='active' for v in states.values())>=3 and states[role]!='active':
                save(mode+'-admission-deferred.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'states':states})
                print('DEFERRED_GLOBAL3');return
            body=(OUT/(mode+'-request.md')).read_text()
            save(mode+'-dispatch-intent.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':target,'states':states,'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'single_delivery_attempt':True})
            response=await s.deliver(target,body,str(CWD) if mode=='experiment' else None)
            response.update(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),states_before=states)
            save(mode+'-delivery.json',response)
            print(json.dumps(response))

asyncio.run(main())
