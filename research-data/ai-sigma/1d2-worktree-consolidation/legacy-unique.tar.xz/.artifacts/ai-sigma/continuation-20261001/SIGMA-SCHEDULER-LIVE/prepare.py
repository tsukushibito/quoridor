import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import resource
import stat
import subprocess
import sys
import time

ROOT = Path('/workspaces/quoridor/.worktree/ai-sigma')
MAIN = Path('/workspaces/quoridor')
OUT = Path(__file__).resolve().parent
CFG = ROOT / '.artifacts/ai-sigma/continuation-20261001/scheduler/scheduler.json'
RUNTIME = MAIN / '.artifacts/research-team/scheduler-sigma-continuation-20261001'
OLD = ROOT / '.artifacts/ai-sigma/closeout/SIGMA-RESOURCE-CLOSEOUT'
UTC = dt.timezone.utc
START = dt.datetime.now(UTC)
CUTOFF = dt.datetime(2026, 10, 1, 9, 50, tzinfo=UTC)
os.sched_setaffinity(0, {0})
if sys.argv[1] == 'baseline':
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
# RAM is resident memory. A Go/cgo Beads child needs more virtual address space;
# do not pass the metadata scanner's AS limit into communication operations.
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
os.environ.update(UV_NO_SYNC='1', UV_OFFLINE='1', PYTHONDONTWRITEBYTECODE='1')

def now():
    return dt.datetime.now(UTC).isoformat()

def guard():
    if dt.datetime.now(UTC) >= CUTOFF:
        raise TimeoutError('Preparation cutoff 09:50 UTC')

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def identity(pid):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return {'pid': pid, 'start_ticks': fields[19], 'state': fields[0],
                'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
    except OSError:
        return None

def command(name, args, timeout=30):
    guard()
    started = now()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    child = subprocess.Popen(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    ident = identity(child.pid)
    try:
        stdout, stderr = child.communicate(timeout=min(timeout, (CUTOFF-dt.datetime.now(UTC)).total_seconds()))
    except subprocess.TimeoutExpired:
        child.terminate()
        try:
            stdout, stderr = child.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            child.kill()
            stdout, stderr = child.communicate(timeout=3)
        save(name + '-timeout.json', {'process': ident, 'reaped': True, 'exit_code': child.returncode,
                                     'stdout': stdout, 'stderr': stderr, 'ended_utc': now()})
        raise
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    row = {'command': args, 'started_utc': started, 'ended_utc': now(), 'process': ident,
           'exit_code': child.returncode, 'reaped': True, 'stdout': stdout, 'stderr': stderr,
           'user_cpu_s': usage.ru_utime-before.ru_utime, 'sys_cpu_s': usage.ru_stime-before.ru_stime,
           'children_maxrss_kib_cumulative_peak': usage.ru_maxrss,
           'peak_not_an_additive_metric': True}
    save(name + '.json', row)
    print(name, child.returncode, stdout.strip(), flush=True)
    if child.returncode:
        raise RuntimeError(name + ' failed; retained output')
    return json.loads(stdout)

def scheduler(name, action):
    args = ['bash', str(MAIN / 'scripts/dev/research-scheduler.sh'), action,
            '--state-dir', str(RUNTIME)]
    if action in ('validate', 'start'):
        args += ['--config', str(CFG)]
    return command(name, args)

def references():
    names = [ROOT / 'docs/design/ai-sigma-continuation-20261001.md',
             ROOT / 'docs/design/ai-sigma-contract-steward-scheduler-live.md',
             ROOT / 'docs/design/ai-sigma-research-goal.md',
             MAIN / 'docs/development/research-scheduler.md',
             MAIN / 'docs/reports/research-scheduler-implementation.md',
             MAIN / 'scripts/dev/research-scheduler.sh', MAIN / 'scripts/dev/research-scheduler.py',
             MAIN / 'scripts/dev/research-team.py', MAIN / 'scripts/dev/research-team.sh',
             MAIN / 'tools/research-team/uv.lock', MAIN / 'tools/research-team/pyproject.toml',
             MAIN / '.artifacts/research-team/registry.json', CFG, CFG.parent / 'contract.json',
             CFG.parent / 'prompt.md', OLD / 'storage.json', OLD / 'retention-and-charge.json']
    refs = []
    for p in names:
        guard(); b = p.read_bytes()
        refs.append({'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
    data = json.loads((MAIN / '.artifacts/research-team/registry.json').read_text())
    definitions = []
    for role, entry in data['roles'].items():
        p = MAIN / '.agents/research-team'
        b = ((p/'common.md').read_text()+'\n\n'+(p/'roles'/f'{role}.md').read_text()).encode()
        actual = hashlib.sha256(b).hexdigest()
        definitions.append({'role': role, 'thread_id': entry['thread_id'],
                            'definition_sha256': actual, 'registered_sha256': entry['definition_sha256'],
                            'matches': actual == entry['definition_sha256']})
    assert all(v['matches'] for v in definitions)
    head = subprocess.run(['git','rev-parse','HEAD'], cwd=ROOT, capture_output=True, text=True,
                          timeout=5, check=True).stdout.strip()
    branch = subprocess.run(['git','branch','--show-current'], cwd=ROOT, capture_output=True,
                            text=True, timeout=5, check=True).stdout.strip()
    save('inputs.json', {'observed_utc': now(), 'head': head, 'branch': branch,
                        'references': refs, 'definition_checks': definitions,
                        'original_documents_registry_database_copied': False})

def snapshot():
    guard()
    roots = []
    for parent, pattern in [(ROOT/'tools', 'ai-sigma-*'), (ROOT/'.artifacts/ai-sigma', '*')]:
        for p in sorted(parent.glob(pattern)):
            if p.name != 'closeout': roots.append(p)
    roots += [ROOT/'models/experiments/ai-sigma', ROOT/'node_modules', ROOT/'packages/engine-bridge/wasm',
              ROOT/'apps/web/dist', ROOT/'target', ROOT/'artifacts',
              Path('/home/vscode/.cache/inference/research/ai-sigma'),
              MAIN/'.artifacts/research-team/sigma-launch']
    expanded = []
    split = {'analysis','build','dispatch','plans','reference','reference-fixtures','runs','verification','ai-sigma'}
    for p in roots:
        if p.is_dir() and not p.is_symlink() and p.name in split and p != ROOT/'models/experiments/ai-sigma':
            expanded += sorted(p.iterdir())
        else: expanded.append(p)
    # Previously excluded closeout evidence and new runtime are separate additions.
    expanded += [OLD, RUNTIME]
    seen = {}; rows = []; errors = []; links = []
    for root in expanded:
        local = set(); stack = [root]
        row = {'root': str(root), 'exists': root.exists(), 'logical_file_bytes': 0,
               'allocated_unique_within_root_bytes': 0, 'union_first_assigned_allocated_bytes': 0,
               'regular_files': 0, 'symlinks': 0}
        while stack:
            guard(); p = stack.pop()
            try:
                s = p.lstat(); key = (s.st_dev, s.st_ino)
                if stat.S_ISLNK(s.st_mode):
                    row['symlinks'] += 1
                    links.append({'path': str(p), 'target': os.readlink(p), 'followed': False})
                elif stat.S_ISDIR(s.st_mode):
                    with os.scandir(p) as entries:
                        stack.extend(Path(e.path) for e in entries if e.name != '.git')
                elif stat.S_ISREG(s.st_mode):
                    row['regular_files'] += 1; row['logical_file_bytes'] += s.st_size
                if key not in local:
                    row['allocated_unique_within_root_bytes'] += s.st_blocks*512; local.add(key)
                if key not in seen:
                    seen[key] = {'allocated': s.st_blocks*512,
                                 'logical': s.st_size if stat.S_ISREG(s.st_mode) else 0}
                    row['union_first_assigned_allocated_bytes'] += s.st_blocks*512
            except FileNotFoundError:
                if p != root: errors.append({'path': str(p), 'error': 'vanished'})
            except OSError as e: errors.append({'path': str(p), 'error': str(e)})
        rows.append(row)
    old_storage = json.loads((OLD/'storage.json').read_text())
    old_charge = json.loads((OLD/'retention-and-charge.json').read_text())
    allocated = sum(v['allocated'] for v in seen.values())
    logical = sum(v['logical'] for v in seen.values())
    path_charge = sum(v['logical_file_bytes'] for v in rows)
    delta = max(0, allocated-old_storage['union_allocated_bytes'],
                path_charge-old_charge['path_logical_charge_upper_covered_roots'])
    cargo = Path('/usr/local/cargo/.global-cache').stat()
    cargo_full = max(cargo.st_size, cargo.st_blocks*512)
    cargo_delta = max(0, cargo_full-old_charge['shared_cargo_metadata_current_full_charge_bytes'])
    docs = [p for folder in ('docs/design','docs/reports') for p in (ROOT/folder).glob('ai-sigma-*.md')]
    docs_full = sum(max(p.stat().st_size, p.stat().st_blocks*512) for p in docs)
    docs_delta = max(0, docs_full-old_charge['owned_design_report_full_charge_bytes'])
    old_bound = old_charge['covered_scope_conservative_charge_bytes']
    baseline_charge = old_bound+delta+cargo_delta+docs_delta
    reservations = {'entry_guarded_2GiB': 2*1024**3, 'steward_128MiB': 128*1024**2,
                    'supervisor_32MiB': 32*1024**2, 'coordinator_32MiB': 32*1024**2}
    after_reservations = baseline_charge+sum(reservations.values())
    fs = os.statvfs(ROOT)
    cgroup = {}
    for name in ('cpu.max','memory.max','memory.current','cpuset.cpus.effective'):
        p = Path('/sys/fs/cgroup')/name
        if p.exists(): cgroup[name] = p.read_text().strip()
    proc = {}
    for name in ('status','stat','cgroup'):
        p = Path('/proc/self')/name
        if name=='status': proc[name]=[line for line in p.read_text().splitlines() if line.startswith(('VmRSS:','VmHWM:','VmPeak:','Cpus_allowed_list:','Threads:'))]
        else: proc[name]=p.read_text().strip()
    load = Path('/proc/loadavg').read_text().strip()
    meminfo = [line for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemTotal:','MemAvailable:'))]
    row = {'observed_utc':now(), 'roots':rows, 'unique_inode_count':len(seen),
           'union_allocated_bytes':allocated, 'union_logical_regular_bytes':logical,
           'path_logical_charge_bytes':path_charge,
           'old_union_allocated_bytes':old_storage['union_allocated_bytes'],
           'union_allocated_change_bytes':allocated-old_storage['union_allocated_bytes'],
           'old_conservative_charge_bytes':old_bound, 'covered_positive_growth_charge_bytes':delta,
           'cargo_full_charge_current_bytes':cargo_full, 'cargo_positive_growth_bytes':cargo_delta,
           'owned_ai_sigma_docs_full_charge_bytes':docs_full, 'docs_positive_growth_bytes':docs_delta,
           'continued_conservative_baseline_charge_bytes':baseline_charge,
           'conditional_remaining_before_reservations_bytes':12*1024**3-baseline_charge,
           'new_reservations_bytes':reservations, 'charge_plus_new_reservations_bytes':after_reservations,
           'conditional_unallocated_after_reservations_bytes':12*1024**3-after_reservations,
           'budget_bytes':12*1024**3, 'filesystem_available_bytes':fs.f_bavail*fs.f_frsize,
           'affinity':list(os.sched_getaffinity(0)), 'rlimit_as_bytes':resource.getrlimit(resource.RLIMIT_AS),
           'cgroup':cgroup,'self_proc':proc,'host_loadavg':load,'host_memory':meminfo,
           'errors':errors,'symlinks':links,
           'method':'lstat/unique(dev,ino), no symlink targets; same old owner patterns + old closeout + new runtime; metadata-only',
           'ownership_hints_not_proof':True, 'old_reserves_not_released':True,
           'new_reservations_added_in_full_no_credit_for_already_written_bytes':True,
           'excluded':['shared full training/inference cache walk','shared .git','shared DB','other worktrees'],
           'exact_global_new_delta_verified':False,'formal_uncontended_environment_verified':False,
           'gaps':['initial inode baseline','outside-owned-root shared increments/temp peaks','concurrent writes/sample RSS','unobserved GPU/external host work'],
           'retention':'old retention-and-charge.json, old deviations/missing/raw/checkpoints unchanged; delete zero'}
    save('storage-and-resources.json',row)
    print(json.dumps({k:row[k] for k in ('observed_utc','union_allocated_bytes','union_allocated_change_bytes',
                      'continued_conservative_baseline_charge_bytes','conditional_unallocated_after_reservations_bytes')}) ,flush=True)

mode = sys.argv[1]
if mode == 'baseline':
    references(); snapshot()
elif mode == 'start':
    pre = scheduler('runtime-before-recovery','status')
    assert not pre['running'] and not pre.get('owned'), 'Do not start over old runtime ownership'
    v = scheduler('validate','validate'); assert v['valid'] and not v['expired']
    scheduler('recovery-start','start')
    scheduler('runtime-after-recovery','status')
elif mode == 'status':
    scheduler('runtime-observed','status')
else:
    raise ValueError(mode)
usage = resource.getrusage(resource.RUSAGE_SELF)
save(mode+'-execution-'+str(os.getpid())+'.json', {'started_utc':START.isoformat(),'ended_utc':now(),
     'process':identity(os.getpid()),'affinity':list(os.sched_getaffinity(0)),
     'user_cpu_s':usage.ru_utime,'sys_cpu_s':usage.ru_stime,'maxrss_kib':usage.ru_maxrss,
     'exit_code_if_normal':0,'nn_gpu_training_build_download_delete':0,
     'preparation_deadline_utc':CUTOFF.isoformat()})
