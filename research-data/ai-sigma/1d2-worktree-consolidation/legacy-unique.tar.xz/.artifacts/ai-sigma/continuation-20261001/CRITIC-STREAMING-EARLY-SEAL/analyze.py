import json,math,statistics,struct,hashlib,datetime
from pathlib import Path
R=Path('/workspaces/quoridor/.worktree/ai-sigma');O=R/'.artifacts/ai-sigma/continuation-20261001/CRITIC-STREAMING-EARLY-SEAL';OLD=O.parent/'SIGMA-STREAMING-EARLY-SEAL';N=O/'NN-SUITE-64-ONCE'
def load(p):return json.loads(Path(p).read_text())
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def quant(rows):
 x=sorted(r['public']['elapsed_ms'] for r in rows)
 return {'n':len(x),'median':statistics.median(x),'p95_nearest_rank':x[math.ceil(.95*len(x))-1],'max':max(x)} if x else {'n':0}
raw=load(OLD/'all-public-requests-combined.json');assert len(raw)==20 and len({r['spec']['request_id'] for r in raw})==20
normal=[r for r in raw if r['spec']['kind']=='normal'];steady=[r for r in normal if r['spec']['sample']>=0];eligible=[r for r in normal if r['public']['checkpoint'] and not r['public']['late']];term=[r for r in raw if r['spec']['kind']=='terminal'];boundary=[r for r in raw if r['spec']['kind'] not in ['normal','terminal']]
assert [len(normal),len(steady),len(eligible),len(term),len(boundary)]==[12,9,11,2,6]
reserve=load(OLD/'reserve.json');assert reserve['reserve_ms']==math.ceil(reserve['max_steady_ms']+2*reserve['max_clock_error_ms']+25)==89;assert reserve['commit_margin_ms']==math.ceil(reserve['max_validation_ms']+2*reserve['max_clock_error_ms']+5)==9
save('upstream-independent-arithmetic.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'normal_all':quant(normal),'conditional_eligible':quant(eligible),'steady':quant(steady),'terminal':2,'boundary_including_cancel':6,'distinct':20,'reserve':89,'cutoff':402,'seal':411,'old_cancel_missing_ACK':True,'uniform_single_revision_window':False,'do_not_rescue_warm340210ms':True,'runtime_new_control':0})
fixtures={f['id']:f for f in load(R/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json')['fixtures']};refs={x['id']:x for x in load(R/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json')}
bits=nn=priors=0;maxnn=maxprior=0;numeric_rows=[]
def numeric(f,q,public_cp=None):
 global bits,nn,priors,maxnn,maxprior
 nums=q['numeric'];assert len(nums)==1;v=nums[0];ref=refs[f['id']]
 expected=[struct.unpack('<I',struct.pack('<f',x))[0] for x in f['raw_features_float32']];assert len(expected)==648 and len(v['features_bits'])==648 and v['features_bits']==expected;bits+=648
 logits=v['policy_logits'];assert len(logits)==136 and len(ref['policy_logits'])==136;assert type(v['value']) in [int,float] and -1<=v['value']<=1
 for x,y in zip(logits+[v['value']],ref['policy_logits']+[ref['value']]):assert math.isfinite(x) and math.isfinite(y) and abs(x-y)<=1e-4+1e-4*abs(y);nn+=1;maxnn=max(maxnn,abs(x-y))
 cp=public_cp if public_cp is not None else q['result']['cp'];P2=f['board']['total_ply']%2==1
 if cp is None:
  numeric_rows.append({'id':f['id'],'features':648,'NN':137,'prior':None,'reason':'discarded private final cp; no fabricated prior','P2':P2});return
 pmap={e[0]:e[1] for e in cp['root_edges']};canon_pr={x['canonical136']:x['prior'] for x in ref['canonical_legal_priors']}
 assert set(pmap)=={a['rust209'] for a in f['legal_actions']};assert abs(sum(pmap.values())-1)<=1e-4
 for a in f['legal_actions']:
  idx=a['sigma136']
  if P2:
   if idx<8:idx={0:1,1:0,2:2,3:3,4:6,5:7,6:4,7:5}[idx]
   else:offset=8 if idx<72 else 72;local=idx-offset;idx=offset+(7-local//8)*8+local%8
  x,y=pmap[a['rust209']],canon_pr[idx];assert math.isfinite(x) and abs(x-y)<=1e-4+1e-4*abs(y);priors+=1;maxprior=max(maxprior,abs(x-y))
 numeric_rows.append({'id':f['id'],'features':648,'NN':137,'prior':len(pmap),'P2':P2})
controls=[]
for fid in ['initial-p1','asym-hv-p2','straight-jump-p2']:
 x=load(OLD/'NN-SUITE-63-01'/('control-'+fid+'.json'));d,s=x['direct'],x['stream'];assert len(d['result']['trace'])==len(s['result']['trace'])==8;assert d['result']['cp']==s['result']['cp'];assert all(a['cp']==b['cp'] for a,b in zip(d['result']['trace'],s['result']['trace']));numeric(fixtures[fid],d);numeric(fixtures[fid],s);controls.append({'id':fid,'all8_complete_cp_equal':True,'final_tree_history_stats_action_equal':True})
save('saved-control24-independent.json',{'controls':controls,'completed_cp_pairs':24,'numeric_rows':numeric_rows,'features_bits':bits,'NN_elements':nn,'prior_elements':priors,'NN_max_abs':maxnn,'prior_max_abs':maxprior,'new_control_NN':0,'mixed_gate_abs':1e-4,'mixed_gate_rtol':1e-4})
rows=load(N/'public-requests.json');private=load(N/'private-diagnostics-after-public.json');stops=load(N/'search-stop-events.json');stopmap={x['identity']['request_id']:x for x in stops};clock=load(N/'browser/clock-start.json');endclock=load(N/'browser/clock-end.json');assert len(rows)==16 and len(private)==16 and len(stops)==16
new_checks=[];crossings=[];before=(bits,nn,priors,maxnn,maxprior);numeric_rows=[];maxnn=maxprior=0
for i,r in enumerate(rows):
 spec,p=r['spec'],r['public'];q=private[spec['request_id']];ident=q['identity'];f=fixtures[spec['fixture']];stop=stopmap[spec['request_id']]
 assert ident['request_id']==p['request_id']==spec['request_id'];assert type(p['checkpoint']) is bool and type(p['late']) is bool;assert p['generation']==ident['generation']==spec['generation'];assert p['epoch']==p['generation'];assert p['model']=='d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d';assert p['schema']=='8x9x9-f32/136logits/value1/rust209'
 assert ident['limits']==p['limits']=={'simulations':4096,'max_nodes':512,'max_depth':24,'seed':1979}
 assert ident['seal_ms']-ident['t0_ms']==411 and ident['commit_cutoff_ms']-ident['t0_ms']==402 and ident['deadline_ms']-ident['t0_ms']==500
 if f['classification']=='legal-replay':assert ident['legal_prefix']==f['legal_prefix'];assert ident['history']==sorted(f['history_counts'],key=lambda x:x[0])
 assert stop['identity']==ident and stop['ownership_error'] is None;assert stop['raw_stop']['handles']==stop['raw_stop']['activeNN']==stop['raw_stop']['live_searches']==0;assert stop['raw_stop']['active'] is False
 if i:assert ident['t0_ms']==rows[i-1]['public']['stamp_ms'];assert r['root_context_started_ms']>=stopmap[rows[i-1]['spec']['request_id']]['node_received_ms']
 for e in r['cache_events']:
  if e['accepted'] and e['kind']=='snapshot':assert e['validation_finished_ms']<ident['commit_cutoff_ms'];assert e['received_ms']<=e['validation_finished_ms']
 if p['late']:assert p['action'] is None and p['checkpoint'] is False and p['error']=='LATE_FINAL_STAMP'
 if p['checkpoint']:
  assert p['stamp_ms']<ident['deadline_ms'];assert type(p['value']) in [int,float] and math.isfinite(p['value']) and -1<=p['value']<=1;cp=r['private_cache']['owned']['cp'];assert cp['generation']==p['generation'];assert cp['policy_fallbacks']==cp['value_fallbacks']==p['fallback']==0
  if spec['kind']=='normal':assert p['action'] in {a['rust209'] for a in f['legal_actions']};assert p['completed_simulations']==cp['simulations'];assert sum(e[2] for e in cp['root_edges'])==max(0,cp['simulations']-1);assert {e[0] for e in cp['root_edges']}=={a['rust209'] for a in f['legal_actions']}
  if spec['kind']=='terminal':assert p['action'] is None and p['completed_NN']==q['result']['calls']==0 and q['numeric']==[]
 if q['numeric']:numeric(f,q,r['private_cache']['owned']['cp'] if r['private_cache'] else None)
 spans=q['NN'];guaranteed=[]
 for a in spans:
  assert a['session_run_start_ms']<=a['session_run_end_ms'];lo=a['session_run_start_ms']-clock['worker']['lo_ms'];hi=a['session_run_end_ms']-clock['worker']['hi_ms']
  if lo<=p['stamp_ms']<=hi:guaranteed.append({'start_upper_Node':lo,'end_lower_Node':hi,'stamp':p['stamp_ms']})
 if guaranteed:crossings.append({'id':spec['request_id'],'kind':spec['kind'],'intervals':guaranteed})
 new_checks.append({'id':spec['request_id'],'kind':spec['kind'],'sample':spec['sample'],'checkpoint':p['checkpoint'],'late':p['late'],'elapsed':p['elapsed_ms'],'action':p['action'],'error':p['error'],'simulations':p['completed_simulations'],'published_completed_NN':p['completed_NN'],'actual_NN_attempts':q['result']['calls'],'actual_completed_NN':q['result']['completed_NN'],'NN_span_records':len(spans),'old_wait_ms':r['old_search_wait_ms'],'owned_stop_handlesNNlive0':True,'API_crossing':bool(guaranteed)})
assert rows[0]['public']['error']=='CANCELLED' and rows[0]['public']['action'] is None
cancel=private[rows[0]['spec']['request_id']];nextq=private[rows[1]['spec']['request_id']];assert nextq['NN'][0]['session_run_start_ms']>=stopmap[rows[0]['spec']['request_id']]['raw_stop']['at_ms']
norm=[r for r in rows if r['spec']['kind']=='normal'];steady=[r for r in norm if r['spec']['sample']>=0];terminal=[r for r in rows if r['spec']['kind']=='terminal']
assert len(norm)==9 and len(steady)==6 and all(r['public']['checkpoint'] and not r['public']['late'] for r in norm)
for kind,err in [('before-first','NO_COMPLETED_SNAPSHOT'),('validation-cross','NO_COMPLETED_SNAPSHOT'),('caller-busy','LATE_FINAL_STAMP'),('fault','INJECTED_HARDFAULT')]:
 r=next(r for r in rows if r['spec']['kind']==kind);assert r['public']['error']==err and r['public']['action'] is None
save('independent-runtime-summary.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planned':16,'completed':16,'rows':new_checks,'normal9':quant(norm),'steady6':quant(steady),'terminal2':quant(terminal),'cancel_stop_then_next_NN':True,'cancel_wait_charged_ms':rows[1]['old_search_wait_ms'],'cancel_next_t0_is_public_stamp':True,'strict_shape_finite_value_mixed_numeric':True,'new_features_bits':bits-before[0],'new_NN_elements':nn-before[1],'new_prior_elements':priors-before[2],'new_NN_max_abs':maxnn,'new_prior_max_abs':maxprior,'API_crossing_rows':crossings,'API_crossing_normal_count':sum(x['kind']=='normal' for x in crossings),'exact_ORT_kernel_instruction_timing':False,'limits':{'T':500,'reserve':89,'seal':411,'cutoff':402},'fallback':0,'late_reject_preserved':True,'all_end_to_end_delivery_withinT':False,'candidate_finite_supported':True,'reference_runtime':False,'clock_gate':False,'actual_go':False,'new_games':0})
print(json.dumps({'normal9':quant(norm),'steady6':quant(steady),'normal_API_crossing':sum(x['kind']=='normal' for x in crossings),'NN_elements':nn-before[1],'features':bits-before[0],'oldwaitcancel':rows[1]['old_search_wait_ms']}))
