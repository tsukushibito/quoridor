import json,hashlib,datetime,os,shutil,difflib
from pathlib import Path
R=Path('/workspaces/quoridor/.worktree/ai-sigma'); S=R/'tools/ai-sigma-streaming-early-seal'; OLD=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL'; O=R/'.artifacts/ai-sigma/continuation-20261001/CRITIC-STREAMING-EARLY-SEAL'; T=O/'copy'; T.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
expected={'docs/design/ai-sigma-contract-critic-streaming-early-seal.md':'bc74e6f69f88e595af16c3328a955a041fbd31b9d5efe47a8ba6f42803ccaec5','docs/design/ai-sigma-continuation-20261001.md':'6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f','docs/reports/ai-sigma-experiment-streaming-early-seal.md':'58996b0567e1688fd1336bdae39a55f7503581ba386fb0f07cbe471fe9f769a3'}
expected.update({str(OLD/n):h for n,h in {'final-manifest.json':'c877e781d72d1a71cc8c667a7298ffd245058a011a7beb56640490155235a4d9','source-frozen.json':'c5381302d6573605242d06ede2f173e8fb68102c3ad9121a6d68e4070a5b411d','all-public-requests-combined.json':'e568c46084c12f7a52404575af52c9e17302476efa5ae5a549cbce47470f5da8','preregister.json':'22d2fa771906345eae0c06f7b8c6bacd2daf62e5e0a68c1607eb28800df3a654'}.items()})
inputs={str(R/p):h for p,h in expected.items()}
counts={}
for n in ['final-manifest.json','source-frozen.json','input-before.json']:
 d=json.loads((OLD/n).read_text()); counts[n]=len(d['checks'])
 for c in d['checks']:
  assert c['path'] not in inputs or inputs[c['path']]==c['sha256'];inputs[c['path']]=c['sha256']
checks=[{'path':p,'sha256':h,'observed':sha(p)} for p,h in inputs.items()]
save('input-before.json',{'UTC':now,'counts':counts,'checks':checks});assert all(c['sha256']==c['observed'] for c in checks)
st=json.loads((OLD/'runtime-stop-before-document.json').read_text()); ids=st['identities']; current=[]
for x in ids:
 try:z=Path(f"/proc/{x['pid']}/stat").read_text().rsplit(')',1)[1].split(); tick=int(z[19])
 except FileNotFoundError:tick=None
 current.append({**x,'current_starttick':tick,'same_identity_live':tick==x['starttick']})
save('writer-identities-current.json',{'UTC':now,'count':len(current),'checks':current,'same_live':[x for x in current if x['same_identity_live']]});assert not any(x['same_identity_live'] for x in current)
assert json.loads((OLD/'source-stop.json').read_text())['source_write_stopped'];assert not st['remaining']
# No identity from a prior critic job may remain live. Read saved evidence only.
prior=json.loads((R/'.artifacts/ai-sigma/continuation-20261001/CRITIC-STREAMING-SNAPSHOT/previous56-preserved-evidence.json').read_text())
save('prior-critic-stop-reference.json',{'UTC':now,'saved_summary':prior,'new_NN_retry':False})
for p in S.iterdir():
 if p.is_file():shutil.copyfile(p,T/p.name)
for n in ['source-frozen.json','input-before.json','reserve.json','representative-payloads-NN0.json']:shutil.copyfile(OLD/n,O/n)
pr=json.loads((OLD/'preregister.json').read_text());normal=[x for x in pr['cases'] if x['kind']=='normal' and x['sample'] in [-1,0,1]];bound=[x for x in pr['cases'] if x['kind'] not in ['normal','cancel-next','late-notification']];cancel=[x for x in pr['cases'] if x['kind']=='cancel-next'];assert len(normal)==9 and len(bound)==6 and len(cancel)==1
pr['cases']=cancel+normal+bound;pr['fixed_control']['fixtures']=[]
for i,c in enumerate(pr['cases']):c['request_id']=f'EARLY64-{i+1:02d}';c['generation']=6400+i
save('preregister.json',pr);save('diagnostic-selection-before-NN.json',{'UTC':now,'one_window_one_revision':3,'cases':pr['cases'],'normal':9,'warm':3,'steady':6,'boundaries':6,'cancel':1,'T':500,'reserve':89,'seal':411,'cutoff':402,'direct24':'saved raw only','retry':0})
patches=[]
def patch(name,pairs):
 p=T/name;before=p.read_text();after=before
 for a,b in pairs:assert a in after,(name,a);after=after.replace(a,b)
 p.write_text(after);patches.append({'name':name,'original_sha256':sha(S/name),'patched_sha256':sha(p),'diff':''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='original/'+name,tofile='copy/'+name))})
root="'/workspaces/quoridor/.worktree/ai-sigma'";out=json.dumps(str(O))
patch('browser.cjs',[("ROOT=path.resolve(__dirname,'../..')",'ROOT='+root),("BASE=ROOT+'/.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL'",'BASE='+out)])
patch('entry.cjs',[("['NN-SUITE-63-01','NN-SUITE-63-02-REMAINDER']","['NN-SUITE-64-ONCE']"),("t.issue!=='quoridor-4lc.63'","t.issue!=='quoridor-4lc.64'"),("2026-10-01T16:50:24Z","2026-10-01T17:23:50Z")])
patch('pause-check.cjs',[("ROOT=path.resolve(__dirname,'../..')",'ROOT='+root),("RUN=ROOT+'/.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL'",'RUN='+out),("16:55:24Z","17:28:50Z"),("quoridor-4lc.63","quoridor-4lc.64")])
patch('unit-gates.cjs',[("path.resolve(__dirname,'../../.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL')",out)])
patch('runner.py',[("OUT=TOOL.parents[1]/'.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL'",'OUT=Path('+out+')'),("2026-10-01T16:55:24+00:00","2026-10-01T17:28:50+00:00"),("time.time()+240","time.time()+180"),("3758096384","2684354560"),("117440512","58720256"),(".04-",".02-"),("'sample_interval_ms':40","'sample_interval_ms':20"),("16:55:24Z","17:28:50Z"),("16:50:24Z","17:23:50Z")])
save('copy-patches.json',patches)
token={'issue':'quoridor-4lc.64','actual_go':False,'mode':'suite','run_id':'NN-SUITE-64-ONCE','freeze_token':'CRITIC64-INDEPENDENT-ONCE','source_manifest_sha256':sha(O/'source-frozen.json'),'preregister_sha256':sha(O/'preregister.json'),'reserve_sha256':sha(O/'reserve.json')};save('token.json',token)
save('receipt-start.json',{'UTC':now,'process_deadline':'2026-10-01T17:28:50Z','newjob_cutoff':'2026-10-01T17:23:50Z','report_deadline':'2026-10-01T17:38:50Z','self_pid':os.getpid(),'CPU':list(os.sched_getaffinity(0)),'newNN':0,'gate':'pending'})
(R/'docs/reports/ai-sigma-critic-streaming-early-seal.md').write_text('SIGMA-EARLY-SEAL-INDEPENDENT quoridor-4lc.64 intake\n契約全文・親版2確認、ready/show/pauseなし後claim。自己copy/inputhash/停止を照合中。runtime未実施、gate保留、actual_go=false。旧.60blocked/.56期限不変。詳細CRITIC-STREAMING-EARLY-SEAL/receipt-start.json。\n')
print(json.dumps({'checks':len(checks),'counts':counts,'writer_identities':len(current),'cases':len(pr['cases']),'patch_files':len(patches)}))
