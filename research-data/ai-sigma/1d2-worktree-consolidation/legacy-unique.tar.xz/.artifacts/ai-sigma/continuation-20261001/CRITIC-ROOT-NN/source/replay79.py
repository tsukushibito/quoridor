import struct,math,json,pathlib,collections,hashlib
B=pathlib.Path('/workspaces/quoridor/.worktree/ai-sigma/.artifacts/ai-sigma/continuation-20261001/SIGMA-ROOT-FACTOR-CORRECT-N'); O=pathlib.Path(__file__).resolve().parents[1]
def f(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def val(x):return struct.unpack('<f',struct.pack('<I',x))[0]
def bits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
def tie(a):
 x=1979^a;x=((x^(x>>30))*0xbf58476d1ce4e5b9)&((1<<64)-1);x=((x^(x>>27))*0x94d049bb133111eb)&((1<<64)-1);return x^(x>>31)
def tc(b):return (~b)&0xffffffff if b>>31 else b|0x80000000
w=iter((B/'roots-input.txt').read_text().split()); n=int(next(w)); assert n==765
rows={};counts=collections.Counter(); allscore=0;diffnumber=0;actionnumber=0;finish=0; choices={}; mismatches=[]
orig={}
for l in (B/'factors.log').read_text().splitlines():
 if l.startswith(('BOUNDARY','FINISH','id\t')) or not l:continue
 x=l.split('\t');orig[(x[0],x[1])]=x
meta=json.loads((B/'root-metadata.json').read_text()); mm={x['id']:x for x in meta['roots']}; matched=set(meta['matched_ids'])
for z in range(n):
 rid=next(w);seed=int(next(w));expected=int(next(w));es=int(next(w));N=int(next(w));k=int(next(w)); assert seed==1979 and N==es+1 and mm[rid]['simulations']==N
 edges=[]
 for j in range(k):
  a,p,v,q,rank=[int(next(w)) for _ in range(5)]; edges.append((a,p,v,q,rank));assert 0<=a<=208 and math.isfinite(val(p)) and 0<=val(p)<=1 and math.isfinite(val(q))
 assert sum(e[2] for e in edges)==es and len(set(e[0] for e in edges))==k and sorted(e[4] for e in edges)==list(range(k))
 bestfinish=max(edges,key=lambda e:(e[2],tc(e[1]),-tie(e[0])))[0];assert bestfinish==expected;finish+=1
 out={}
 for mode,c,plus,first,order in [('base',1.5,1,False,False),('C1',1.,1,False,False),('sqrtN',1.5,0,False,False),('score_first',1.5,1,True,False),('first_reforder',1.5,1,True,True)]:
  ee=sorted(edges,key=lambda e:e[4]) if order else edges; root=f(math.sqrt(f(f(N)+plus))); scores=[]; numbers=[]
  for a,p,v,q,rank in ee:
   prior=val(p);vs=val(q);qv=f(vs/f(v)) if v else 0.; score=f(qv+f(f(f(c*prior)*root)/f(v+1)));scores.append(score)
   numbers.append((vs/v if v else 0.)+c*prior*math.sqrt(N+plus)/(v+1))
  def choose(ss):
   mx=max(ss); idx=[i for i,s in enumerate(ss) if s==mx];return idx[0] if first else min(idx,key=lambda i:tie(ee[i][0]))
  ix=choose(scores); nx=choose(numbers);ordered=sorted(scores,reverse=True);margin=f(ordered[0]-ordered[1]) if k>1 else None
  x=orig[(rid,mode)];assert int(x[2])==ee[ix][0];assert int(x[3])==bits(scores[ix]);assert x[4]==('null' if margin is None else str(bits(margin)))
  assert int(x[5])==sum(s==scores[ix] for s in scores);assert int(x[6])==sum(f(scores[ix]-s)<=f(1e-6) for s in scores);assert int(x[7])==ee[ix][2]
  ob=[int(t) for t in x[8].split(',')]; assert ob==[bits(s) for s in scores];allscore+=k
  diffnumber+=bits(numbers[nx])!=bits(scores[ix]);actionnumber+=ee[nx][0]!=ee[ix][0];out[mode]=ee[ix][0]
 choices[rid]=out
 for name,a,b in [('C_only','base','C1'),('sqrt_only','base','sqrtN'),('score_tie_only','base','score_first'),('order_only_given_first','score_first','first_reforder'),('tie_plus_order_bundle','base','first_reforder')]:
  if out[a]!=out[b]:
   for group in ['all',mm[rid]['engine']]+(['accepted'] if mm[rid]['accepted'] else ['private_late'])+(['matched194'] if rid in matched else []):counts[(name,group)]+=1
try:next(w);raise AssertionError('trailing tokens')
except StopIteration:pass
result={'roots':n,'finish_matches':finish,'selected_modes':n*5,'all_edge_score_bits_compared':allscore,'all_edge_bit_mismatch':0,'selected_field_mismatch':0,'JSNumber_equivalent_unrounded_scorebits_diff':diffnumber,'unrounded_actiondiff':actionnumber,'factor_changes':{name:{g:counts[(name,g)] for g in ['all','accepted','native','wasm','matched194','private_late']} for name in ['C_only','sqrt_only','score_tie_only','order_only_given_first','tie_plus_order_bundle']},'arithmetic':'independent Python struct binary32 rounding after each operation; no original Rust/JS checker executed; sqrt double then binary32, all saved bits checked','N':'conditional fresh-root source reconstruction; input edge_sum+1=sim checked; not direct raw node visits','NN':0,'rust_compile':0}
(O/'replay79-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
