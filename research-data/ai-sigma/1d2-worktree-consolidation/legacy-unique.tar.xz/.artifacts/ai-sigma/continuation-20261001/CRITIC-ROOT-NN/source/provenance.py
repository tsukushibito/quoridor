import pathlib,json,struct,hashlib,datetime,collections
R=pathlib.Path('/workspaces/quoridor/.worktree/ai-sigma');O=pathlib.Path(__file__).resolve().parents[1];B=O.parent/'SIGMA-ROOT-FACTOR-CORRECT-N';C=O.parent/'SIGMA-ISOLATED-NN-COST'
bits=lambda x:struct.unpack('<I',struct.pack('<f',x))[0]
old=json.loads((R/'.artifacts/ai-sigma/analysis/SIGMA-ROOT-SELECTION-ABLATION/roots.json').read_text());t=iter((B/'roots-input.txt').read_text().split());assert int(next(t))==len(old)==765;parentmissing=0
for r in old:
 rid=next(t);seed,action,es,N,num=[int(next(t)) for _ in range(5)];assert (rid,seed,action,N,num)==(r['id'],r['seed'],r['expected_action'],r['simulations'],len(r['root_edges']));parentmissing+=r['parentQ'] is None
 for a,p,n,v in r['root_edges']:
  inp=[int(next(t)) for _ in range(5)];assert inp==[a,bits(p),n,bits(v),r['reference_legal_order'].index(a)]
 assert es==sum(e[2] for e in r['root_edges']) and N==es+1
proof=json.loads((B/'source-count-proof.json').read_text());p=R/proof['source'];assert hashlib.sha256(p.read_bytes()).hexdigest()==proof['source_sha256']
# Collect process identities independently; registry or names are never ownership proof.
def ids_from(x,bag):
 if isinstance(x,dict):
  pid=x.get('pid',x.get('PID'));tick=x.get('starttick',x.get('start_ticks',x.get('starttick_ticks')))
  if isinstance(pid,int) and isinstance(tick,int):bag.add((pid,tick))
  for k,v in x.items():
   if k in ['runner_pid','child_pid']:
    tk=x.get(k.replace('_pid','_starttick'))
    if isinstance(v,int) and isinstance(tk,int):bag.add((v,tk))
   ids_from(v,bag)
 elif isinstance(x,list):
  for v in x:ids_from(v,bag)
def current(bag):
 live=[]
 for pid,tick in sorted(bag):
  try:
   s=pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
   if int(s[19])==tick:live.append({'pid':pid,'starttick':tick,'state':s[0],'ppid':int(s[1])})
  except FileNotFoundError:pass
 return live
processes={}
for name,base in [('79',B),('80',C)]:
 bag=set();per={}
 for p in sorted(base.glob('*.process.json')):
  x=json.loads(p.read_text());one=set();ids_from(x,one);bag|=one;per[p.name]={'identities':len(one),'exit':x.get('exit'),'guard_or_stop_reason':x.get('guard_error',x.get('stop_reason'))}
 stop=json.loads((base/'runtime-source-stopped-before-report.json').read_text());decl=set();ids_from(stop.get('recorded_identities',stop.get('identities',[])),decl)
 processes[name]={'process_extracted_count':len(bag),'declared_stop_count':len(decl),'process_minus_stop':sorted(bag-decl),'stop_minus_process':sorted(decl-bag),'current_same_identity_live':current(bag|decl),'process_files':per,'historical_current_distinct':True,'identities':sorted(bag|decl)}
q=json.loads((C/'nn80-once.process.json').read_text());ctrl=json.loads((C/'controlled-stop.json').read_text());drop=json.loads((C/'drop.json').read_text());ack=json.loads((C/'nn80-once.owned-ack.json').read_text());runtime={'exit':q['exit'],'stop_reason':q['stop_reason'],'current_RSS_peak':q['peak_group_plus_runner_RSS'],'guardRSS':q['guardRSS'],'contractRAM':q['contractRAM'],'ru_maxrss_separate':q['runner_ru_maxrss_bytes'],'peak_allocated':q['peak_allocated_bytes'],'affinity_all_CPU':q['all_observed_TIDs_at_assigned_CPU'],'kernel_adoptions':q['kernel_adoptions'],'outer_remaining':q['remaining'],'unknown_adopted':q['unknown_adopted'],'inner_forced':ctrl['forced'],'inner_remaining':ctrl['remaining_pids'],'Modeldrop_ACK':drop,'owner_ledger_unknown':ack['unknown_adopted'],'natural_or_whole_period_guarantee':False}
result={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root_input_vs_saved_oldroots':765,'parentQ_missing':parentmissing,'input_order_and_reference_ranks_exact':True,'source_count_proof_sha_match':True,'source_root_N':'fresh root visits0; simulate either root leaf+1 or root path parent+1, stats completed+1; N conditional sim=edge_sum+1, not raw node-visits','processes':processes,'80runtime_resources_ownership_saved_only':runtime,'80numeric_independent_full46':'incomplete: independent80 corrected once then B policy_logits KeyError; first A full gate passed, remainder not independently certified','NN_new':0}
(O/'provenance-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['processes','80runtime_resources_ownership_saved_only']}));print({n:{k:v for k,v in x.items() if k not in ['identities','process_files']} for n,x in processes.items()})
