import pathlib,json,math,struct,collections,hashlib,datetime
R=pathlib.Path('/workspaces/quoridor/.worktree/ai-sigma');B=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-ISOLATED-NN-COST';O=pathlib.Path(__file__).resolve().parents[1]
F={f['id']:f for f in json.loads((R/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json').read_text())['fixtures']};REF={r['id']:r for r in json.loads((R/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json').read_text())};P=json.loads((B/'prepared-inputs.json').read_text());rows=[json.loads(l) for l in (B/'calls.jsonl').read_text().splitlines()];assert len(rows)==46
bits=lambda x:struct.unpack('<I',struct.pack('<f',x))[0]
maxdiff=0.;maxprior=0.;np=0;count=collections.Counter();classify=collections.Counter();ids=set()
def close(a,b):assert math.isfinite(a) and math.isfinite(b) and abs(a-b)<=1e-4+1e-4*abs(b)
for ident,p in P.items():
 f=F[ident];assert p['features_bits']==[bits(x) for x in f['raw_features_float32']] and len(p['features_bits'])==648;assert p['raw_legal']==sorted(x['rust209'] for x in f['legal_actions'])
assert len(P)==28
for r in rows:
 f=F[r['id']];ref=REF[r['id']];count[r['backend']]+=1;classify[f['classification']]+=1;assert r['phase']=='numeric';ids.add((r['id'],r['backend']));assert len(r['features_bits'])==648 and r['features_bits']==P[r['id']]['features_bits'];assert ('search' in r and r['search']==[]) if r['backend']=='A' else ('search' not in r)
 a=r['policy_logits'];assert len(a)==136 and all(type(x) in [int,float] and math.isfinite(x) for x in a);v=r['value'];assert type(v) in [int,float] and math.isfinite(v) and -1<=v<=1
 for x,y in zip(a+[v],ref['policy_logits']+[ref['value']]):close(x,y);maxdiff=max(maxdiff,abs(x-y))
 legal=r['raw_legal'];assert legal==sorted(x['rust209'] for x in f['legal_actions']) and len(set(legal))==len(legal);prior=r['raw_prior'];assert len(prior)==len(legal) and all(type(x) in [int,float] and math.isfinite(x) and 0<=x<=1 for x in prior);np+=len(prior)
 if legal:
  mapping={x['rust209']:(f['P2_permutation136'][x['sigma136']] if f['board']['turn']==1 else x['sigma136']) for x in f['legal_actions']};vals=[a[mapping[i]] for i in legal];mx=max(vals);ww=[math.exp(x-mx) for x in vals];ss=sum(ww);pp={x['canonical136']:x['prior'] for x in ref['canonical_legal_priors']}
  for i,x,w in zip(legal,prior,ww):close(x,w/ss);close(x,pp[mapping[i]]);maxprior=max(maxprior,abs(x-pp[mapping[i]]))
  close(sum(prior),1)
assert len(ids)==46 and count=={'A':23,'B':23}
failure=json.loads((B/'failures.jsonl').read_text());drop=json.loads((B/'drop.json').read_text());assert failure['ordinal']==47 and failure['id']=='synthetic-total-ply-200';c=drop['after']['count'];assert (c['A_complete'],c['B_complete'],c['raw_feature_calls'],c['raw_policy_calls'],c['search_calls'])==(24,23,28,23,0)
assert drop['after']['A_handles']==0 and drop['after']['active']==0 and drop['after']['models_dropped'] is True
result={'saved_gate_rows':len(rows),'backends_saved':dict(count),'classification_rows':dict(classify),'features_bits':len(rows)*648,'outputs':len(rows)*137,'priors':np,'max_NN_abs_diff':maxdiff,'max_prior_abs_diff':maxprior,'prepared28_bits':len(P)*648,'fixed_numeric_gate':'shape finite strict[-1,1] and Action/P2 mapping first, abs<=1e-4+1e-4abs(ref)','counts':c,'planned56':56,'rawNN47':47,'helper_failure_after_NN':1,'failed47th_output_missing':True,'unexecuted9':9,'latency_planned36':36,'latency_started':sum(r['phase']!='numeric' for r in rows),'Modeldrop_saved_ACK':drop,'raw_vs_effective_terminal':'synthetic200 rawlegal131 and effective prior null, not legitimate200 replay','NN_new':0,'clock_or_backend_ratio_accepted':False}
(O/'audit80-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
