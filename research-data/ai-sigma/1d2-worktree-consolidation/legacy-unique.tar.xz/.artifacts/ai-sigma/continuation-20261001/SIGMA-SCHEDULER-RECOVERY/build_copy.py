from pathlib import Path
import hashlib
import json
import difflib

ROOT=Path('/workspaces/quoridor/.worktree/ai-sigma')
OLD=ROOT/'.artifacts/ai-sigma/continuation-20261001/SIGMA-SCHEDULER-LIVE/watch.py'
OUT=Path(__file__).resolve().parent
NEW=ROOT/'tools/ai-sigma-scheduler-monitor-recovery/watch.py'
original=OLD.read_text();src=original
src=src.replace('OUT=Path(__file__).resolve().parent', '''import argparse
import safe_state
parser=argparse.ArgumentParser()
parser.add_argument('--run-dir',required=True)
parser.add_argument('--expectations',required=True)
args=parser.parse_args()
OUT=Path(args.run_dir).resolve()
ALLOWED=ROOT/'.artifacts/ai-sigma/continuation-20261001/SIGMA-SCHEDULER-RECOVERY'
if ALLOWED not in OUT.parents:raise ValueError('Run output outside owned recovery namespace')
OUT.mkdir(parents=True,exist_ok=True)
EXPECTED=json.loads(Path(args.expectations).read_text())
EXPECTED_PROCESS=EXPECTED['process']
EXPECTED_BINDING=EXPECTED['binding']
EVENT_EPOCH=EXPECTED['operation_epoch_utc']
LAST_GOOD=None''')
src=src.replace('def readstate(): return json.loads((STATE/\'state.json\').read_text())', '''def read_failure(event):
    with (OUT/'bounded-read-events.jsonl').open('a') as f:
        f.write(json.dumps({'observed_utc':now(),**event},ensure_ascii=False)+'\\n')
def readstate():
    global LAST_GOOD
    value=safe_state.read_bounded(STATE/'state.json',
          lambda v:safe_state.validate_state(v,EXPECTED_BINDING,EXPECTED_PROCESS),log=read_failure)
    LAST_GOOD=value
    return value''')
begin=src.index('def stop_owned(reason):')
end=src.index('\nboot=',begin)
src=src[:begin]+'''def signal_exact_owned(expected):
    fd=os.pidfd_open(expected['pid'])
    try:
        observed=proc(expected['pid'])
        if not matches(expected,observed):raise safe_state.Unavailable('PID identity changed after pidfd open')
        signal.pidfd_send_signal(fd,signal.SIGUSR1)
    finally:os.close(fd)
    return {'signal':'SIGUSR1','process':expected,'scope':'only stored owned scheduler, which interrupts its exact owned turn'}
def stop_owned(reason):
    state=None;read_error=None
    try:state=readstate()
    except safe_state.Unavailable as e:read_error=str(e)
    observed=proc(EXPECTED_PROCESS['pid'])
    if matches(EXPECTED_PROCESS,observed):
        if state is not None:
            result=command(['bash',str(MAIN/'scripts/dev/research-scheduler.sh'),'stop',
                            '--state-dir',str(STATE),'--interrupt-owned-turn'],50)
        else:
            # A missing/unknown state must never select some newer process from it.
            result=safe_state.signal_identity(EXPECTED_PROCESS,observed,
                   Path('/proc/sys/kernel/random/boot_id').read_text().strip(),signal_exact_owned)
            until=min(time.monotonic()+45,time.monotonic()+max(0,(FINAL-dt.datetime.now(UTC)).total_seconds()))
            while matches(EXPECTED_PROCESS,proc(EXPECTED_PROCESS['pid'])) and time.monotonic()<until:time.sleep(.05)
    elif state is not None and state.get('owned') and dt.datetime.now(UTC)>=END:
        result=command(['bash',str(MAIN/'scripts/dev/research-scheduler.sh'),'run',
                        '--state-dir',str(STATE),'--config',str(CFG)],60)
    else:result={'command_not_needed':True,'reason':'stored scheduler not alive; retain unknown/pending ownership'}
    final=None
    try:final=readstate()
    except safe_state.Unavailable as e:read_error=str(e)
    alive=matches(EXPECTED_PROCESS,proc(EXPECTED_PROCESS['pid']))
    pending=bool(final.get('owned')) if final is not None else 'unknown'
    row={'at':now(),'reason':reason,'command_result':result,'state':final,
         'read_error':read_error,'last_valid_state':LAST_GOOD if final is None else None,
         'scheduler_identity_alive':alive,'owned_turn_pending':pending,
         'external_NN_processes_stopped':False,'scope':'stored owned scheduler/turn only',
         'read_failure_not_hidden':True,'no_automatic_restart_or_blind_send':True}
    write('scheduler-end-stop.json',row)
    notify('scheduler-end-report','quoridor-4lc.38 / .44 recovery scheduler停止。\\n'+
           '詳細 '+str(OUT/'scheduler-end-stop.json')+'。owned_turn_pending='+str(pending)+
           '、scheduler_identity_alive='+str(alive)+'。原因/読取欠測を保持、外部NN停止認定0。')
''' +src[end:]
src=src.replace("for root in (OUT,CFG.parent,STATE,ROOT/'docs/reports/ai-sigma-steward-scheduler-live.md'):","""for root in (OUT.parent,CFG.parent,STATE,
                 ROOT/'.artifacts/ai-sigma/continuation-20261001/SIGMA-SCHEDULER-LIVE',
                 ROOT/'.artifacts/ai-sigma/continuation-20261001/SIGMA-SUPERVISOR-READ-GUARD',
                 ROOT/'tools/ai-sigma-supervisor-read-guard',ROOT/'tools/ai-sigma-scheduler-monitor-recovery',
                 ROOT/'docs/reports/ai-sigma-steward-scheduler-live.md',
                 ROOT/'docs/reports/ai-sigma-steward-supervisor-read-guard.md',
                 ROOT/'docs/reports/ai-sigma-steward-scheduler-recovery.md'):""")
src=src.replace("if events.exists() and events.stat().st_size<=3*1024**2:\n            for line in events.read_text().splitlines():", """event_text=safe_state.read_bounded(events,parse=lambda text:text,log=read_failure)
        if event_text:
            for line in event_text.splitlines():""")
src=src.replace("if e.get('event')=='dispatched' and first is None:first=e", "if e.get('event')=='dispatched' and e.get('at','')>=EVENT_EPOCH and first is None:first=e")
src=src.replace("'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),", "'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'operation_epoch_utc':EVENT_EPOCH,'recovery_issue':'quoridor-4lc.44','owned_scheduler_expected':EXPECTED_PROCESS,")
src=src.replace("'scope':'state/events metadata; first ownedturn report; owned scheduler deadline/guard stop',", "'scope':'bounded state/events; first new epoch ownedturn report; exact owned scheduler deadline/guard stop',")
assert src!=original and 'def readstate(): return' not in src
compile(src,str(NEW),'exec')
NEW.write_text(src)
(OUT/'watch-copy.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),src.splitlines(True),fromfile=str(OLD),tofile=str(NEW))))
(OUT/'copy-lineage.json').write_text(json.dumps({'old_source':str(OLD),'old_sha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),'new_source':str(NEW),'new_sha256':hashlib.sha256(NEW.read_bytes()).hexdigest(),'old_source_unchanged':OLD.read_text()==original,'only_owned_copy_modified':True},indent=2)+'\n')
print('COPY',len(src),hashlib.sha256(NEW.read_bytes()).hexdigest())
