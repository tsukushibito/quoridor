from pathlib import Path
import json,math,datetime,hashlib
R=Path('/workspaces/quoridor/.worktree/ai-sigma');O=Path(__file__).resolve().parent;A=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-ENTRY-REPAIR';p=json.loads((A/'preregister.json').read_text())
def draw(seed):
 x=seed
 while True:
  for n,fn in [(13,lambda a,b:a^b),(17,lambda a,b:a^b),(5,lambda a,b:a^b)]:
   x=(x^((x>>n) if n==17 else (x<<n)))&0xffffffff
  yield x

def rnd(seed):
 g=draw(seed)
 def next_(k):
  lim=2**32-2**32%k
  while True:
   v=next(g)
   if v<lim:return v%k
 return next_
def shuffle(a,s):
 a=list(a);g=rnd(s)
 for i in range(len(a)-1,0,-1):j=g(i+1);a[j],a[i]=a[i],a[j]
 return a
exclude={25,4,51,0,47,44,56,31};sel=shuffle((i for i in range(64) if i not in exclude),2026100301)[:48];order=shuffle(sel,2026100302);g=rnd(2026100303)
assert sel==p['selected_indices'];assert order==p['ordered_indices'];assert [[2,1] if g(2) else [1,2] for i in range(48)]==[q['candidate_color_order'] for q in p['pairs']]
width=math.sqrt(math.log(20)/(2*48));out={}
paths=list(A.glob('diag-final5-*/summary.json'))+list((O/'upstream').glob('diag-CRITIC69-*/summary.json'))
for f in paths:
 r=json.loads(f.read_text());table=r['table'];Xi=[]
 for b in p['pairs']:
  q=[table[g['game']-1] for g in b['games']]
  if all(x['status']=='completed' for x in q):Xi.append(sum(x['result']['score'] for x in q)/2)
 mean=sum(Xi)/len(Xi) if Xi else None;L=max(0,mean-width) if len(Xi)==48 else None
 assert Xi==r['score']['Xi'];assert mean==r['score']['mean'];assert L==r['score']['L'];assert r['retries']<=2
 attempts={}
 for a in r['attempts']:
  attempts[a['pair']]=attempts.get(a['pair'],0)+1;assert a['seed']==1979 and a['prefix_sha256']==p['pairs'][a['pair']-1]['prefix_sha256']
 assert max(attempts.values(),default=0)<=2
 out[str(f)]={'m':len(Xi),'mean':mean,'L':L,'retry':r['retries'],'mock_not_strength':True}
saved=json.loads((A/'diag-GOLDEN68-ONCE/summary.json').read_text());proc=json.loads((A/'golden68-once.process.json').read_text());public=[v for v in saved['events'] if v['kind']=='public'];ready=[v for v in saved['events'] if v['kind']=='startup'];assert not public and not ready;assert saved['stopReason']=='OWN_CLEANUP_FAILED';assert proc['stop_reason']=='STORAGE_GUARD'
peak=proc['peak_allocated_bytes'];assert peak==38535168
r={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'independent_python_PRNG':True,'selected':sel,'order':order,'Xi_width':width,'minimum_success_mean_for_L45':.45+width,'saved_and_independent_scores':out,'total_budget_s':48*2*200*.5+400+1200+600+1.5,'latest_admission_UTC':'2026-10-01T21:13:18.500Z','phaseB':{'public':len(public),'backend_ready_events':len(ready),'planned_max':11,'inner_error':saved['stopReason'],'outer_error':proc['stop_reason'],'exit':proc['exit'],'peak_storage':peak,'guard_excess':peak-28*2**20,'ceiling_excess':peak-32*2**20,'final_storage':proc['final_allocated_bytes'],'peak_not_discounted':True,'missing_primary_load_exception':True,'Model_ACK_missing':True,'actual_go':False},'NN':0,'Chromium':0,'games':0}
assert r['total_budget_s']==11801.5
(O/'independent-arithmetic.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'saved_and_self_summary_count':len(out),'PRNG':True,'phaseB':r['phaseB'],'width':width}))
