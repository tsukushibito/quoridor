import os,sys,json,time,subprocess,hashlib,datetime,signal
from pathlib import Path
O=Path(__file__).resolve().parent;phase=sys.argv[1];script=O/('supplement.cjs' if phase=='supplement' else 'check-independent.cjs');cmd=['node','--max-old-space-size=256',str(script)]
if phase=='actual-refusal':cmd=['node','--max-old-space-size=256',str(O/'source/match-entry.cjs'),'--run',str(O/'actual-refusal-token.json')]
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity(pid):
 try:
  stat=Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split();status=Path(f'/proc/{pid}/status').read_text();vals=dict(l.split(':',1) for l in status.splitlines() if ':' in l)
  return {'pid':pid,'starttick':int(stat[19]),'ppid':int(stat[1]),'state':stat[0],'RSS':int(vals.get('VmRSS','0 kB').split()[0])*1024,'affinity':vals.get('Cpus_allowed_list','').strip()}
 except (FileNotFoundError,ProcessLookupError):return None
start=time.monotonic();tracked={};peak=0;storagepeak=0;tids=set();env=dict(os.environ,UV_NO_SYNC='1',UV_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(O/'tmp'),TMP=str(O/'tmp'),TEMP=str(O/'tmp'),XDG_CACHE_HOME=str(O/'xdg'))
(O/'tmp').mkdir(exist_ok=True);(O/'xdg').mkdir(exist_ok=True)
with (O/(phase+'.log')).open('w') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);started={'UTC':stamp(),'command':cmd,'command_sha256':hashlib.sha256(json.dumps(cmd).encode()).hexdigest(),'pid':p.pid,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'identity':identity(p.pid),'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest()};(O/(phase+'.started.json')).write_text(json.dumps(started,indent=2)+'\n');reason='exit'
 while p.poll() is None:
  cur=identity(p.pid)
  if cur:
   tracked[(cur['pid'],cur['starttick'])]=cur;peak=max(peak,cur['RSS'])
   for t in Path(f'/proc/{p.pid}/task').glob('*'):
    z=identity(int(t.name))
    if z:tids.add(z['affinity']);tracked[(z['pid'],z['starttick'])]=z
  size=sum(q.stat().st_blocks*512 for q in O.rglob('*') if q.is_file());storagepeak=max(storagepeak,size)
  if time.monotonic()-start>120 or peak>2.5*2**30 or size>36*2**20:
   reason='TIMEOUT_OR_GUARD';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)
   break
  time.sleep(.02)
 p.wait()
remaining=[]
for (pid,tick),x in tracked.items():
 y=identity(pid)
 if y and y['starttick']==tick:remaining.append(y)
result={'UTC':stamp(),'start':started,'exit':p.returncode,'reason':reason,'duration_s':time.monotonic()-start,'peak_RSS':peak,'storage_peak':storagepeak,'TID_affinities':sorted(tids),'identities':list(tracked.values()),'current_same_identity_remaining':remaining,'remaining0':not remaining,'sample_target_ms':20,'instant_peak_not_guaranteed':True,'NN':0,'Chromium':0}
(O/(phase+'.process.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['start','identities']}));sys.exit(p.returncode if phase!='actual-refusal' else 0)
