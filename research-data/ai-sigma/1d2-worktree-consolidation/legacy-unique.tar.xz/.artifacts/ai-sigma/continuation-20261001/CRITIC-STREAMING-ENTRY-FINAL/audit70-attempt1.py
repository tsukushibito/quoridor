from pathlib import Path
import json,hashlib,math,struct,datetime,sys,collections
R=Path('/workspaces/quoridor/.worktree/ai-sigma');O=Path(__file__).resolve().parent;A=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-RUNTIME-FINAL';S=A/'real-GOLDEN70-ONCE-session1'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();UTC=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
expected={'entry-manifest.json':'8885a9b3daedf296e810e6282b65f76d23b3c02d8a6f684184cc244ff2dac2a3','source-frozen-before-runtime.json':'02139e9cf3b2cf91661298e7afcd7d00675e9f92e8058e5c051419466e99160b','final-manifest.json':'8b496a7d38eb4ac2523ae3ed1b3b318603434efb3d25e49623372dedeb7ac043'};hashes={};checks={}
for f,h in expected.items():assert sha(A/f)==h;hashes[str(A/f)]=h
report=R/'docs/reports/ai-sigma-experiment-streaming-runtime-final.md';assert sha(report)=='fe8530afea9f02f50027aa86fd5f0736a1ee9525546443b9ea1385c7f993491e';hashes[str(report)]=sha(report)
for f in ['final-manifest.json','entry-manifest.json','source-input-after.json']:
 rows=read(A/f)['checks'];bad=[]
 for row in rows:
  h=sha(row['path']);hashes[row['path']]=h
  if h!=row['sha256']:bad.append(row['path'])
 assert not bad;checks[f]={'count':len(rows),'mismatches':bad}
# Add fixed numeric dependencies actually used independently, not mutate upstream manifest.
fxp=R/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json';refp=R/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json';ctlp=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/SUITE65-02/control-initial-p1.json'
for f in [fxp,refp,ctlp]:hashes[str(f)]=sha(f)
assert sha(fxp)=='206f46e0763177f138317ba49dc82875fd49a4d2c4ac2844d7fc06911e30bffb';assert sha(refp)=='060ba1a3f7647adb7c0ac968eb2834d966665920f72eeee2b3798ce9864b382a'
proc=read(A/'golden70-once.process.json');ids={(v['pid'],v['start_ticks']) for v in proc['tracked']};live=[]
for pid,tick in ids:
 try:
  st=Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()
  if int(st[19])==tick:live.append({'pid':pid,'starttick':tick,'state':st[0]})
 except FileNotFoundError:pass
assert not live
bound={'UTC':UTC(),'checks':checks,'input_hashes':hashes,'runtime_tracked_identities':len(ids),'same_identity_current':live,'source_snapshot_only70':True,'NN':0,'Chromium':0}
(O/('input70-'+sys.argv[1]+'.json')).write_text(json.dumps(bound,indent=2)+'\n')
if sys.argv[1]=='after':assert hashes==read(O/'input70-before.json')['input_hashes'];print(json.dumps({'hashes_unchanged':True,'checks':checks,'identities':len(ids),'live':live}));sys.exit()
ready=read(S/'ready-state.json');assert ready['kind']=='ready' and ready['digest']=='d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d' and ready['threads']==1 and ready['proxy'] is False and ready['handles']==0 and ready['activeNN']==0
fixture=next(v for v in read(fxp)['fixtures'] if v['id']=='initial-p1');ref=next(v for v in read(refp) if v['id']=='initial-p1');features=[struct.unpack('<I',struct.pack('<f',v))[0] for v in fixture['raw_features_float32']];priv=read(S/'private-after-public.json');assert len(priv)==3
numeric=[];NNcount=0;maxdiff=0
for rid,v in priv.items():
 assert v['identity']['legal_prefix']==[] and v['identity']['fixture_id']=='initial-p1';n=v['numeric'];assert len(n)==1;n=n[0];assert len(n['features_bits'])==648 and all(type(x)==int and 0<=x<2**32 for x in n['features_bits']);assert n['features_bits']==features
 assert len(n['policy_logits'])==136 and all(type(x) in [int,float] and math.isfinite(x) for x in n['policy_logits']);assert type(n['value']) in [int,float] and math.isfinite(n['value']) and -1<=n['value']<=1
 for a,b in zip(n['policy_logits']+[n['value']],ref['policy_logits']+[ref['value']]):assert abs(a-b)<=1e-4+1e-4*abs(b);maxdiff=max(maxdiff,abs(a-b))
 NNcount+=len(v['NN']);numeric.append({'id':rid,'featurebits':648,'numeric':137,'NN_API_calls':len(v['NN']),'result_error':v['result'].get('error'),'not_public_success':True})
public=[];ACK=[];previous=None;slacks=[]
clock=read(S/'ready.json')['clock']['worker']
for j in range(1,4):
 rid='GOLDEN70-ONCE-'+str(j);raw=read(S/('public-'+rid+'.json'));i=raw['identity'];r=raw['response'];assert type(r['accepted'])==bool and type(r['checkpoint'])==bool and type(r['fallback'])==int and r['fallback']==0
 for k in ['engine','request_id','generation','epoch','fixture_id','model','schema','limits']:assert r[k]==i[k]
 assert i['request_id']==rid and i['generation']==j and i['epoch']==j and i['prefix']==[] and i['legal_prefix']==[] and i['fixture_id']=='initial-p1'
 assert r['prefix_sha256']==hashlib.sha256(b'[]').hexdigest();assert i['deadline_ms']==i['t0_ms']+500 and i['seal_ms']==i['t0_ms']+411 and i['commit_cutoff_ms']==i['t0_ms']+402
 if previous is not None:assert i['t0_ms']==previous;start=priv[rid]['NN'][0]['session_run_start_ms']-clock['hi_ms'];oldACK=ACK[-1]['node_received_ms'];slacks.append(start-oldACK);assert start>=oldACK
 previous=r['stamp_ms'];elapsed=r['stamp_ms']-i['t0_ms'];assert math.isfinite(elapsed) and elapsed<500
 if j==2:
  assert r['accepted'] and r['checkpoint'] and r['action']==13 and -1<=r['value']<=1;assert r['echo']==i;assert raw['private_cp']['producer_identity']==i and raw['private_cp']['identity']==i
 else:assert r['accepted'] is False and r['checkpoint'] is False and r['action'] is None
 public.append({'id':rid,'engine':r['engine'],'accepted':r['accepted'],'checkpoint':r['checkpoint'],'action':r['action'],'error':r['error'],'actual_elapsed_ms':elapsed,'embedded_elapsed_ms':r['elapsed_ms'],'elapsed_delta':elapsed-r['elapsed_ms'],'stamp_ms':r['stamp_ms'],'t0_ms':i['t0_ms']})
 z=read(S/('stopACK-'+rid+'.json'));assert z['identity']==i and z['stop']['handles']==0 and z['stop']['activeNN']==0 and z['stop']['live_searches']==0 and z['stop']['active'] is False;ACK.append(z)
raw=read(S/'public-GOLDEN70-ONCE-2.json');owned=raw['private_cp']['owned'];cp=owned['cp'];assert cp['action']==13 and cp['simulations']==0 and cp['root_visits']==1 and cp['nn_calls']==1 and cp['policy_fallbacks']==0 and cp['value_fallbacks']==0
assert owned['completed_token']==1 and owned['pending_token'] is None and owned['completed_NN']==owned['NN_attempts']==1
edges=cp['root_edges'];leg=fixture['legal_actions'];assert len(edges)==len(leg)==131 and [v[0] for v in edges]==[v['rust209'] for v in leg];assert sum(v[2] for v in edges)==cp['simulations']
logits=[ref['policy_logits'][v['sigma136']] for v in leg];mx=max(logits);ex=[math.exp(v-mx) for v in logits];probs=[v/sum(ex) for v in ex];md=0
for edge,q in zip(edges,probs):assert len(edge)==4 and all(math.isfinite(x) for x in edge);assert type(edge[2])==int and edge[2]>=0 and abs(edge[3])<=edge[2]+1e-5;assert abs(edge[1]-q)<=1e-4+1e-4*abs(q);md=max(md,abs(edge[1]-q))
assert abs(sum(v[1] for v in edges)-1)<1e-4
control=read(ctlp)['stream']['result']['trace'][0]['cp'];fields=['action','simulations','nn_calls','root_visits','root_edges','terminal_value','policy_fallbacks','value_fallbacks'];assert all(cp[k]==control[k] for k in fields)
validation=raw['bindings'][0];assert validation['accepted'] is True and validation['last_gate']['validation_finished_ms']<raw['identity']['commit_cutoff_ms']
primary=read(S/'primary-exception-stop.json');assert primary['code']=='ERR_ASSERTION';cleanup=read(S/'cleanup-after-stop.json');assert datetime.datetime.fromisoformat(primary['UTC'].replace('Z','+00:00'))<datetime.datetime.fromisoformat(cleanup['UTC'].replace('Z','+00:00'));assert not (S/'secondary-cleanup-stop.json').exists()
proof=cleanup['proof'];assert proof['remaining_pids']==0 and proof['forced'] is True and proof['waited'] is True and proof['zombie_identities_absent'] is True;assert not (S/'model-drop.json').exists();assert not (A/'real-GOLDEN70-ONCE-session2').exists()
monitor=[json.loads(v) for v in (A/'golden70-once.monitor.jsonl').read_text().splitlines()];waits=[v for v in monitor if v['kind']=='adopted_wait'];waitinfo=[v for v in monitor if v['kind']=='kernel_waitid' and v.get('info')];assert len(waits)==len(waitinfo)==8
boundary=proc['kernel_boundary'];assert boundary['valid'] and boundary['initial_children']==[] and boundary['single_thread_initial'] and boundary['spawn_count']==1 and boundary['sole_explicit_root'];assert boundary['root']['pid']==proc['child_pid'] and boundary['root']['start_ticks']==proc['child_starttick']
assert proc['subreaper_set_rc']==proc['subreaper_get_rc']==0 and proc['subreaper_value']==1 and not proc['remaining'] and not proc['unknown_adopted'] and not proc['ledger_rejected'];assert len(proc['kernel_adoptions'])==2
# Same identity adopted waits are kept as raw references, not extrapolated into natural shutdown.
result={'UTC':UTC(),'support':'saved raw finite only; independent NN/runtime NOT executed','ready':ready,'featurebits':1944,'numeric':411,'NN_calls_all3':NNcount,'maxNNdifference':maxdiff,'numeric_rows':numeric,'public_requests':public,'planned_max':11,'unexecuted_maximum':8,'successful_public_cp':1,'reference_prior_count':131,'max_prior_difference':md,'reference_cp_control_fields_equal':fields,'ACK3':ACK,'nextNN_after_old_node_ACK_slacks_ms':slacks,'same_next_t0':True,'primary':primary,'secondary_actual_present':False,'cleanup':proof,'outer':{'runtime_start':proc['start'],'runtime_end':proc['end'],'exit':proc['exit'],'guard_stop':proc['stop_reason'],'tracked_count':len(ids),'current_absent':not live,'kernel_adoptions':proc['kernel_adoptions'],'nonempty_waitid':waitinfo,'adopted_wait':waits,'boundary':boundary},'NN_helper_failure_not_rescued':True,'Model_drop_ACK':False,'fresh_goal_fourply':'not executed','candidate_public_NN_success':False,'judge_final_stamp':False,'actual_go':False,'own_NN':0,'own_Chromium':0,'own_game':0}
(O/'audit70-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['featurebits','numeric','NN_calls_all3','maxNNdifference','planned_max','unexecuted_maximum','reference_prior_count','max_prior_difference','same_next_t0','nextNN_after_old_node_ACK_slacks_ms','Model_drop_ACK','fresh_goal_fourply','judge_final_stamp','actual_go','own_NN']}));print(json.dumps({'checks':checks,'tracked':len(ids),'live':live,'public':public}))
