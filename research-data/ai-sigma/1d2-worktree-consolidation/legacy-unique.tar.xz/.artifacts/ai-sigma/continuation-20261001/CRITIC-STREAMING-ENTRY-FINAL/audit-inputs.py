from pathlib import Path
import json,hashlib,datetime,sys,os,shutil,difflib
R=Path('/workspaces/quoridor/.worktree/ai-sigma');O=R/'.artifacts/ai-sigma/continuation-20261001/CRITIC-STREAMING-ENTRY-FINAL';A=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-ENTRY-REPAIR'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected={'final-manifest.json':'830e2da512ebb9a2069e5907332b7c277c0787b982bf90dc74641ddb7c0fa1a3','entry-manifest.json':'cf0983dee003a81f333d1802d83367cf4ab62e08462900bc902c8ca86e11be21','preregister.json':'9e05356a42dd79cc8c5ec3427c1e0937c81bf6c82773bffd9c257d238c69dc27'}
checks={};allrows={};critical={}
for f in ['final-manifest.json','entry-manifest.json','old-input-after.json']:
 p=A/f;x=json.loads(p.read_text());rows=x['checks'];bad=[]
 for row in rows:
  v=sha(row['path']);allrows[row['path']]=v
  if v!=row['sha256']:bad.append({'path':row['path'],'actual':v,'expected':row['sha256']})
 checks[f]={'count':len(rows),'mismatches':bad}
 assert not bad, f
for f,h in expected.items():critical[str(A/f)]=sha(A/f);assert critical[str(A/f)]==h
report=R/'docs/reports/ai-sigma-experiment-streaming-entry-repair.md';critical[str(report)]=sha(report);assert critical[str(report)]=='641ef6c38a5ec4113cd36f5662e75c3db7bbd2a5bacb61dbd59e2930ca8e0aab'
# Observe current identities without signals. Process history is separate evidence.
identities={}
def scan(x):
 if isinstance(x,dict):
  pid=x.get('pid',x.get('PID'));tick=x.get('starttick',x.get('start_ticks',x.get('starttime',x.get('start_tick'))))
  if isinstance(pid,int) and tick is not None:
   try:identities[(pid,int(tick))]=x
   except (ValueError,TypeError):pass
  for v in x.values():scan(v)
 elif isinstance(x,list):
  for v in x:scan(v)
for p in A.glob('*.process.json'):
 try:scan(json.loads(p.read_text()))
 except Exception:pass
for p in A.glob('*.monitor.jsonl'):
 for line in p.read_text().splitlines():
  try:scan(json.loads(line))
  except Exception:pass
live=[]
for pid,tick in identities:
 try:
  s=Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()
  if int(s[19])==tick:live.append({'pid':pid,'starttick':tick,'state':s[0]})
 except (FileNotFoundError,ProcessLookupError):pass
out={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'critical_hashes':critical,'input_hashes':allrows,'current_identity_count':len(identities),'same_identity_live':live,'identity_scan_scope':'top-level process and monitor; not full historical controlled recovery','NN':0,'Chromium':0}
(O/('independent-input-'+sys.argv[1]+'.json')).write_text(json.dumps(out,indent=2)+'\n')
if sys.argv[1]=='before':
 U=O/'upstream';U.mkdir(exist_ok=True);S=O/'source';S.mkdir(exist_ok=True);patches=[]
 for p in (R/'tools/ai-sigma-streaming-entry-repair').iterdir():
  if p.is_file():
   old=p.read_text();new=old
   if p.name=='match-entry.cjs':new=new.replace("const ROOT=path.resolve(__dirname,'../..'),BASE=ROOT+'/.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-ENTRY-REPAIR'",f"const ROOT={json.dumps(str(R))},BASE={json.dumps(str(U))}")
   if p.name=='caller.cjs':pass
   (S/p.name).write_text(new)
   if old!=new:patches.append({'file':p.name,'original':sha(p),'copy':sha(S/p.name),'diff':''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(p),tofile=str(S/p.name)))})
 for f in ['preregister.json','entry-manifest.json','phaseA-gates.json']:shutil.copyfile(A/f,U/f)
 (O/'copy-patches.json').write_text(json.dumps(patches,indent=2)+'\n')
 print(json.dumps({'checks':checks,'identities':len(identities),'live':live,'copy_patches':len(patches)}))
else:
 b=json.loads((O/'independent-input-before.json').read_text());assert b['input_hashes']==allrows;assert b['critical_hashes']==critical
 print(json.dumps({'checks':checks,'unchanged':True,'identities':len(identities),'live':live}))
