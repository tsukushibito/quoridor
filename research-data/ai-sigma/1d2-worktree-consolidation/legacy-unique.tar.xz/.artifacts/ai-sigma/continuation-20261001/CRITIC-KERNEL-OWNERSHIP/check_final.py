from pathlib import Path
import json,hashlib,math,struct,datetime,os
O=Path(__file__).resolve().parent;R=Path('/workspaces/quoridor/.worktree/ai-sigma');U=O/'helper-correction-once';P=U/'diagnostic/golden-execution-GOLDEN-SEAL-01';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
rows=load(P/'requests.json');assert len(rows)==5;assert [x['engine'] for x in rows]==['candidate','reference','candidate','candidate','reference']
ref=next(x for x in load(R/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json') if x['id']=='initial-p1');fv=ref['value']
while isinstance(fv,list):assert len(fv)==1;fv=fv[0]
fixture=next(x for x in load(R/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json')['fixtures'] if x['id']=='initial-p1');assert fixture['classification']=='legal-replay' and fixture['legal_prefix']==[]
legal={x['rust209']:x['sigma136'] for x in fixture['legal_actions']};mx=max(ref['policy_logits'][i] for i in legal.values());exps={a:math.exp(ref['policy_logits'][i]-mx) for a,i in legal.items()};den=sum(exps.values());expected_prior={a:v/den for a,v in exps.items()}
results=[];bits=nn=prior_count=0;maxnn=maxprior=0;rootvalues=[]
for i,r in enumerate(rows):
 assert r['id']=='initial-p1';req=r['request'];assert req['seed']==1979 and req['simulations']==4096 and req['max_nodes']==512 and req['max_depth']==24
 for k in ['accepted','checkpoint','transaction_bound','late','final_validation_and_serialization_before_stamp']:assert type(r[k]) is bool
 assert r['final_validation_and_serialization_before_stamp'] is True
 assert isinstance(r['request_id'],str) and r['request_id']==req['request_id'];assert type(r['generation']) is int and r['generation']==req['generation']
 assert type(r['fallback']) is int and r['fallback']==0
 assert math.isfinite(r['received_after_validation_ms']) and math.isfinite(r['t0_ms']);elapsed=r['received_after_validation_ms']-r['t0_ms'];assert abs(elapsed-r['elapsed_ms'])<1e-6
 if i==2:
  assert r['T_ms']==10 and r['g_ms']==0 and req['diagnostic_step_delay_ms']==500
  assert r['accepted'] is False and r['action'] is None and r['checkpoint'] is False and r['transaction_bound'] is False and r['late'] is True
  assert r['nn_calls'] is None;assert r['error']=='NO_RESPONSE_TIMEOUT'
  results.append({'i':i,'type':'deadline_rejected','elapsed_ms':elapsed,'overshoot_ms':r['overshoot_ms'],'NN_calls':None,'missing_NN_not_zero':True,'published_action':None});continue
 assert r['T_ms']==500 and r['g_ms']==91 and req['T_ms']==500 and req['g_ms']==91
 for k,w in [('accepted',True),('legal',True),('illegal',False),('stale',False),('late',False),('owned_binding',True),('transaction_bound',True),('checkpoint',True)]:assert type(r[k]) is bool and r[k] is w,(i,k)
 assert type(r['action']) is int and r['action'] in legal and r['error'] is None and 0<elapsed<500
 nr=r['diagnostic_numeric_root'];assert len(nr['policy_logits'])==136 and type(nr['value']) in (int,float) and math.isfinite(nr['value']) and -1<=nr['value']<=1
 if r['engine']=='candidate':
  assert len(nr['features_bits'])==648 and all(type(v) is int and 0<=v<=0xffffffff for v in nr['features_bits']);blob=b''.join(struct.pack('<I',v) for v in nr['features_bits']);features=struct.unpack('<648f',blob)
 else:
  features=nr['features'];assert len(features)==648 and all(type(v) in (int,float) for v in features);blob=b''.join(struct.pack('<f',v) for v in features)
 assert all(math.isfinite(v) for v in features);assert hashlib.sha256(blob).hexdigest()==ref['input_float32_sha256'];assert blob==b''.join(struct.pack('<f',v) for v in fixture['raw_features_float32']);bits+=648
 for a,b in zip(nr['policy_logits']+[nr['value']],ref['policy_logits']+[fv]):
  assert type(a) in (int,float) and math.isfinite(a) and abs(a-b)<=1e-4+1e-4*abs(b);maxnn=max(maxnn,abs(a-b));nn+=1
 rootvalues.append(struct.pack('<f',nr['value']).hex());q=r['raw']['payload'];q=q.get('payload',q);d=q.get('data',q);prsum=None
 if r['engine']=='candidate':
  assert d['owned']['cp']==d['original_checkpoint'];cp=d['checkpoint'];assert type(cp['policy_fallbacks']) is int and cp['policy_fallbacks']==0 and type(cp['value_fallbacks']) is int and cp['value_fallbacks']==0
  assert len(cp['root_edges'])==len(legal);assert {x[0] for x in cp['root_edges']}==set(legal);assert len({x[0] for x in cp['root_edges']})==len(legal)
  for action,prior,visits,value in cp['root_edges']:
   assert type(action) is int and type(visits) is int and visits>=0 and math.isfinite(value) and math.isfinite(prior) and prior>=0
   expected=expected_prior[action];assert abs(prior-expected)<=1e-4+1e-4*abs(expected);maxprior=max(maxprior,abs(prior-expected));prior_count+=1
  prsum=sum(x[1] for x in cp['root_edges']);assert abs(prsum-1)<=1e-4+1e-4*abs(1)
  b=d['owned']['identity'];assert b['prefix']==[] and b['seed']==1979 and b['request_id']==r['request_id'] and b['generation']==r['generation'] and b['simulations']==4096 and b['max_nodes']==512 and b['max_depth']==24
 else:assert d['fallback']==0 and type(d['fallback']) is int
 results.append({'i':i,'engine':r['engine'],'accepted':True,'action':r['action'],'elapsed_ms':elapsed,'NN_calls':r['nn_calls'],'root_value_f32bits':rootvalues[-1],'owned_cp_exact':r['engine']=='candidate','root_prior_sum':prsum,'postvalidation_stamp':True})
assert bits==2592 and nn==548 and len(set(rootvalues))==1
proc=load(U/'fixed-initial5-once.process.json');assert proc['exit']==0 and proc['stop_reason'] is None and not proc['remaining'] and not proc['unknown_adopted'] and not proc['ledger_rejected'];assert proc['subreaper_set_rc']==0 and proc['subreaper_get_rc']==0 and proc['subreaper_value']==1
boundary=proc['kernel_boundary'];assert boundary['valid'] is True and boundary['single_thread_initial'] is True and boundary['initial_children']==[] and boundary['sole_explicit_root'] is True and boundary['spawn_count']==1
assert boundary['boot_id']==Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert boundary['launcher']['pid']==proc['runner_pid'] and boundary['root']['pid']==proc['child_pid']
events=[json.loads(x) for x in (U/'fixed-initial5-once.monitor.jsonl').read_text().splitlines()];adopt={(a['observed']['pid'],a['observed']['start_ticks']) for a in proc['kernel_adoptions']};waits={(a['identity']['pid'],a['identity']['start_ticks']) for a in events if a['kind']=='adopted_wait' and a['outcome'][0]};wn={(a['identity']['pid'],a['identity']['start_ticks']) for a in events if a['kind']=='kernel_waitid' and a['info']};assert adopt<=waits and adopt<=wn
for a in proc['kernel_adoptions']:
 assert a['kind']=='kernel_adopted_direct_child' and a['observed']['ppid']==proc['runner_pid'] and a['boot_id']==boundary['boot_id'];assert a['launcher_identity']==boundary['launcher'] and a['sole_jobroot_identity']==boundary['root']
main=load(U/'seal-main-proof.json');assert main['same_main'] is True and main['positive_token'] is True and main['existing_run_refused'] is True and main['missing_token_refused'] is True
proof=load(P/'summary.json');assert proof['actual_go'] is False and proof['holdout_sends']==0 and proof['games']==0 and proof['requests']==5 and proof['accepted']==4 and len(proof['stops'])==2
cleanup=[]
for session in [1,2]:
 s=proof['stops'][session-1];assert type(s['remaining_pids']) is int and s['remaining_pids']==0 and s['forced'] is True and s['registration_ack'] is True and s['zombie_identities_absent'] is True
 e=[json.loads(x) for x in (P/f'session-{session}/cleanup-trace.jsonl').read_text().splitlines()];success=[x for x in e if x['kind']=='cleanup_success'];assert len(success)==1 and success[0]['remaining']==[];assert not any(x['kind']=='cleanup_failure' for x in e)
 for x in e:
  if x['kind']=='signal_sent':assert x['identity']['pid'] in {z['pid'] for z in s['tracked']} and x['identity']['starttick']==next(z['starttick'] for z in s['tracked'] if z['pid']==x['identity']['pid'])
 drain=next(x for x in e if x['kind']=='drain_after')['monotonic_ms']-next(x for x in e if x['kind']=='drain_before')['monotonic_ms'];absence=next(x for x in e if x['kind']=='absence_wait_end')['monotonic_ms']-next(x for x in e if x['kind']=='absence_wait_start')['monotonic_ms']
 cleanup.append({'session':session,'cleanup_success_UTC':success[0]['UTC'],'forced':True,'absent_all_tracked_at_success':True,'drain_ms':drain,'absence_observation_ms':absence,'tracked_count':len(s['tracked'])})
firststop=datetime.datetime.fromisoformat(cleanup[0]['cleanup_success_UTC'].replace('Z','+00:00'));secondstart=load(P/'session-2/startup.json');assert (P/'clock-start-2.json').exists() and (P/'session-2/reference-warm.json').exists()
ack=load(U/'fixed-initial5-once.owned-ack.json');assert ack['kernel_boundary']['valid'] is True and ack['unknown_adopted']==[];assert ack['registered_live']==[]
summary={'UTC':now(),'issue':'quoridor-4lc.56','verdict':'limited_finite_ownership_supported','fixed5_once_NN':True,'responses':results,'numeric':{'feature_f32bits':bits,'NN_elements':nn,'NN_max_abs':maxnn,'candidate_prior_elements':prior_count,'candidate_prior_max_abs_to_fixed_softmax':maxprior,'mixed_gate':'abs <= 1e-4 + 1e-4 abs(ref)','root_value_f32bit_equal':True},'first_final_cleanup':cleanup,'kernel_adoptions':proc['kernel_adoptions'],'same_identity_wait':sorted(list(waits)),'same_identity_waitid_WNOWAIT':sorted(list(wn)),'root_Popen_exit':proc['exit'],'finite_dummy_gate':load(O/'dummy-independent-gate.json'),'input_copy_helper_failure':load(O/'helper-failure-and-scope-correction.json'),'resources':{'runner_peak_RSS':proc['peak_group_plus_runner_RSS'],'outer_peak_RSS':load(O/'fixed5-corrected-outer-outer.json')['RSS_sampled_peak_bytes'],'all_runtime_observed_TIDs_CPU2':proc['all_observed_TIDs_CPU2'],'sample_ms':20,'instant_short_lifetime_peaks_unproven':True,'initial_static_reads_PID_RSS_missing':True,'static_preparation_CPU0_deviation':True},'global_no_go':{'clock_gate':False,'entry_ready':False,'actual_go':False,'old49_g287_gt91_and_split62plus82_retained':True,'old51_negative_not_rescued':True,'games':0,'holdout_sends':0},'limitations':['trusted childless single-thread launcher with one root, no untrusted ctypes/ptrace/namespace safety proof','T10 overshoot kept and NN count missing, no clock-tail guarantee','old dummy callback failure/birth starttick gaps/forced dependence remain','initial own input-copy outside write scope corrected; all-scope compliance false','all initial resource monitoring/deep real NN revisit/true legal200/nolegal/rawview entropy/model distribution provenance unverified','.55 corrected stored unique path count49, earlier51 wording unsupported; full/OS timing independent support unchanged']}
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'verdict':summary['verdict'],'featurebits':bits,'NN':nn,'maxNN':maxnn,'prior_n':prior_count,'maxprior':maxprior,'adopted':len(adopt),'waited':len(waits),'cleanup':cleanup},ensure_ascii=False))
