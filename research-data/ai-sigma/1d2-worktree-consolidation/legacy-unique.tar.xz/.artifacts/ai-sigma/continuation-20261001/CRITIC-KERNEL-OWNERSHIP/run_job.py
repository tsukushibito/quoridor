import os,sys,time,json,pathlib,datetime,subprocess,signal,hashlib,resource
O=pathlib.Path(__file__).resolve().parent;name=sys.argv[1];cmd=sys.argv[2:];assert not (O/(name+'-outer.json')).exists();os.sched_setaffinity(0,{2});start=time.monotonic();utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();end=datetime.datetime.fromisoformat('2026-10-01T14:15:00+00:00').timestamp();assert time.time()<end-300
for x in ['outer-t','outer-xdg-cache','outer-xdg-config']:(O/x).mkdir(exist_ok=True)
def table():
 d={}
 for f in pathlib.Path('/proc').iterdir():
  if f.name.isdigit():
   try:s=(f/'stat').read_text().rsplit(')',1)[1].split();d[int(f.name)]={'pid':int(f.name),'ppid':int(s[1]),'starttick':int(s[19]),'state':s[0],'rss':int(s[21])*4096}
   except (OSError,IndexError,ValueError):pass
 return d
env=dict(os.environ,UV_NO_SYNC='1',UV_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(O/'outer-t'),TMP=str(O/'outer-t'),TEMP=str(O/'outer-t'),XDG_CACHE_HOME=str(O/'outer-xdg-cache'),XDG_CONFIG_HOME=str(O/'outer-xdg-config'),OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',BLIS_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='')
selfid=table()[os.getpid()];known={};peak=0;storagepeak=0;reason=None;deadline=min(end,time.time()+(180 if name=='fixed5-outer' else 60));tick=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (O/(name+'-outer.log')).open('wb') as log:
 p=subprocess.Popen(cmd,cwd=O/'copy',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);root=table().get(p.pid);assert root
 (O/(name+'-outer-start.json')).write_text(json.dumps({'at':tick,'identity':selfid,'root':root,'command':cmd,'commandhash':hashlib.sha256(json.dumps(cmd).encode()).hexdigest(),'monitorhash':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'timeout_deadline':deadline,'private_temp':str(O/'outer-t')},indent=2)+'\n')
 while p.poll() is None:
  t=table();live={p.pid} if t.get(p.pid,{}).get('starttick')==root['starttick'] else set();live|={pid for pid,tick in known if t.get(pid,{}).get('starttick')==tick}
  more=True
  while more:
   new={pid for pid,v in t.items() if v['ppid'] in live};more=not new<=live;live|=new
  for pid in live:
   if pid not in t:continue
   v=t[pid];k=(pid,v['starttick']);r=known.setdefault(k,{**v,'affinities':[],'maxrss':0,'TID_samples':0});r['maxrss']=max(r['maxrss'],v['rss']);r['last_state']=v['state'];r['last_ppid']=v['ppid']
   try:
    for tid in pathlib.Path(f'/proc/{pid}/task').iterdir():
     affinity=sorted(os.sched_getaffinity(int(tid.name)));r['TID_samples']+=1
     if affinity not in r['affinities']:r['affinities'].append(affinity)
     if affinity!=[2]:reason='AFFINITY_GUARD'
   except (FileNotFoundError,ProcessLookupError):pass
  rss=sum(t[pid]['rss'] for pid in live if pid in t)+resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;peak=max(peak,rss);allocated=sum(f.stat().st_blocks*512 for f in O.rglob('*') if f.is_file());storagepeak=max(storagepeak,allocated)
  if rss>=2684354560:reason='RSS_GUARD'
  if allocated>=58720256:reason='STORAGE_GUARD'
  if time.time()>=deadline:reason='JOB_DEADLINE'
  if reason:
   if table().get(p.pid,{}).get('starttick')==root['starttick']:p.send_signal(signal.SIGTERM)
   try:p.wait(timeout=4)
   except subprocess.TimeoutExpired:
    if table().get(p.pid,{}).get('starttick')==root['starttick']:p.kill()
    p.wait(timeout=2)
   break
  time.sleep(.02)
 code=p.wait()
 t=table();remaining=[v for (pid,tick),v in known.items() if t.get(pid,{}).get('starttick')==tick]
 result={'name':name,'startUTC':tick,'endUTC':utc(),'identity':selfid,'command':cmd,'exit':code,'stop_reason':reason,'root':root,'tracked':list(known.values()),'remaining':remaining,'RSS_sampled_peak_bytes':peak,'storage_sampled_peak_bytes':storagepeak,'all_observed_TIDs_CPU2':all(a==[2] for x in known.values() for a in x['affinities']),'sample_ms':20,'instant_peak_unproved':True,'duration':time.monotonic()-start}
 (O/(name+'-outer.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['name','exit','stop_reason','remaining','RSS_sampled_peak_bytes','duration']}));sys.exit(code)
