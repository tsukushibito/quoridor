from pathlib import Path
import json,hashlib,os,datetime,resource
O=Path(__file__).resolve().parent;R=Path('/workspaces/quoridor/.worktree/ai-sigma');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=json.loads((O/'input-before.json').read_text());after={p:sha(Path(p)) for p in before['hashes']};changed=[{'path':p,'before':v,'after':after[p]} for p,v in before['hashes'].items() if v!=after[p]]
(O/'input-after.json').write_text(json.dumps({'UTC':now(),'hashes':after,'unique_count':len(after),'reference_rows_count':before['checks'],'changed':changed},ensure_ascii=False,indent=2)+'\n')
ids={};jobs=[]
for p in O.rglob('*.process.json'):
 x=json.loads(p.read_text());jobs.append({'path':str(p),'exit':x['exit'],'stop_reason':x['stop_reason'],'remaining':x['remaining'],'RSS':x['peak_group_plus_runner_RSS'],'storage':x['peak_allocated_bytes'],'affinity_all_TIDs_CPU2':x['all_observed_TIDs_CPU2']})
 ids[(x['runner_pid'],x['runner_starttick'])]=True;ids[(x['child_pid'],x['child_starttick'])]=True
 for y in x['tracked']:ids[(y['pid'],y['start_ticks'])]=True
for p in O.glob('*-outer.json'):
 x=json.loads(p.read_text());ids[(x['identity']['pid'],x['identity']['starttick'])]=True
 for y in x['tracked']:ids[(y['pid'],y['starttick'])]=True
current=[]
for pid,tick in ids:
 try:s=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split();same=int(s[19])==tick;state=s[0];ppid=int(s[1])
 except FileNotFoundError:same=False;state=None;ppid=None
 current.append({'pid':pid,'starttick':tick,'same_identity_present':same,'current_state':state,'current_ppid':ppid})
remaining=[x for x in current if x['same_identity_present']];assert not remaining,remaining;assert not changed,changed
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();writer=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-KERNEL-OWNERSHIP';original_proc=json.loads((writer/'fixed-initial5-once.process.json').read_text());assert boot==original_proc['kernel_boundary']['boot_id'];wids=json.loads((O/'writer-identities.json').read_text())['checks'];wremain=[]
for x in wids:
 try:s=Path(f"/proc/{x['pid']}/stat").read_text().rsplit(')',1)[1].split();same=s[19]==x['start_ticks']
 except FileNotFoundError:same=False
 if same:wremain.append(x)
assert not wremain
seen=set();allocated=logical=0
for p in O.rglob('*'):
 if p.is_file():
  s=p.stat();k=(s.st_dev,s.st_ino)
  if k not in seen:seen.add(k);allocated+=s.st_blocks*512;logical+=s.st_size
combined=0;continuation=O.parent
for d in continuation.iterdir():
 if d.is_dir() and (d.name.startswith('CRITIC-') or d.name=='CRITIC-SCHEDULER-LIVE'):
  for p in d.rglob('*'):
   if p.is_file():combined+=p.stat().st_blocks*512
assert allocated<58720256 and combined<117440512
sources=[]
for p in (O/'helper-correction-once/copy').iterdir():
 if p.is_file():sources.append({'path':str(p),'sha256':sha(p)})
summary=json.loads((O/'summary.json').read_text());summary['immutable_input_current_checks']={'unique_count':len(after),'reference_rows':before['checks'],'changed':changed};summary['runtime_stop']={'at':now(),'observed_own_identity_count':len(current),'remaining':remaining,'writer63_current_remaining':wremain,'boot_id':boot};summary['storage']={'unique_allocated':allocated,'logical':logical,'combined_continuation_critic_allocated':combined,'new_guard':58720256,'combined_guard':117440512};summary['final_self_sourcehashes']=sources
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
stop={'UTC':now(),'issue':'quoridor-4lc.56','source_write_stopped':True,'runtime_stopped':True,'last_NN_end':json.loads((O/'helper-correction-once/fixed-initial5-once.process.json').read_text())['end'],'own_identity_count':len(current),'identities':current,'remaining':remaining,'owned_PID0':True,'all_own_jobs_exit_observed':jobs,'writer63_boot_same_current_absence':True,'immutable_hash_count':len(after),'input_changes':changed,'storage':summary['storage'],'NN_real_fixed5_once':True,'first_helper_before_NN_failure_preserved':True,'helper_scope_violation_preserved':True,'no_runtime_retries':True,'after_this_document_and_Beads_report_only':True,'guard_sampled_not_instant_guarantee':True,'processing_deadline':'2026-10-01T14:15:00Z','submission_deadline':'2026-10-01T14:25:00Z'}
(O/'runtime-stopped.json').write_text(json.dumps(stop,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'stopUTC':stop['UTC'],'own_identities':len(current),'input_unique':len(after),'remaining':remaining,'storage':summary['storage'],'numeric':summary['numeric'],'adoptions':len(summary['kernel_adoptions'])},ensure_ascii=False))
