import pathlib,json,hashlib,shutil,difflib,datetime,os
R=pathlib.Path('/workspaces/quoridor/.worktree/ai-sigma');O=pathlib.Path(__file__).resolve().parent;T=R/'tools/ai-sigma-kernel-ownership';S=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-KERNEL-OWNERSHIP';C=O/'copy';C.mkdir();(O/'diagnostic').mkdir()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda n,x:(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
(R/'docs/reports/ai-sigma-critic-kernel-ownership.md').write_text('# SIGMA-KERNEL-OWNERSHIP-CRITIC / quoridor-4lc.56\n\n暫定: 専用所有境界/実fixed5は検証中。clock_gate/entry_ready/actual_go=false。新対局0。旧失敗/欠測を保持。\n')
expected={S/'manifest-final.json':'3d5650e5934ebf1d8b6ee0eb1050b454c8596cb11adb95421957a59b92e27c91',R/'docs/reports/ai-sigma-experiment-kernel-ownership.md':'0e77fd34e6078e8ad70bee4305bbfe90bfbb2b1c13b2e88b2150b788f3736dc8',S/'runtime-stopped.json':'7f450a0cacfe218c7796339c12ee69df38ce37043c553558cfc602fd9d1cb639',R/'docs/design/ai-sigma-contract-critic-kernel-ownership.md':'669845a5c1adc5f20564225750e35934845b65220e4c3cb1fc775e5ed0c81bd9',R/'docs/design/ai-sigma-continuation-20261001.md':'6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f'}
for p,v in expected.items():assert h(p)==v,(str(p),h(p),v)
m=json.loads((S/'manifest-final.json').read_text());inp=json.loads((S/'input-before.json').read_text());checks=m['checks']+m['source_checks']+inp['checks'];before={str(p):h(p) for p in expected};bad=[]
for x in checks:
 p=pathlib.Path(x['path']);actual=h(p);before[str(p)]=actual
 if actual!=x['sha256']:bad.append({'path':str(p),'expected':x['sha256'],'actual':actual})
assert not bad,bad
write('input-before.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':len(checks),'hashes':before,'mismatches':bad})
stop=json.loads((S/'runtime-stopped.json').read_text());ids=stop['identities'];print('identityschema',ids[:1]);current=[]
for v in ids:
 pid=v['pid'];tick=str(v.get('start_ticks',v.get('starttick')))
 try:z=pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split();match=z[19]==tick;state=z[0]
 except FileNotFoundError:match=False;state=None
 current.append({'pid':pid,'start_ticks':tick,'current_same_identity':match,'state':state})
assert not any(v['current_same_identity'] for v in current)
write('writer-identities.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boot_id_current':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'checks':current,'count':len(current)})
for x in m['source_checks']:shutil.copyfile(x['path'],C/pathlib.Path(x['path']).name)
for n in ['plan-bind.json','diagnostic-preregister.json','input-before.json']:shutil.copyfile(S/n,O/n if n!='input-before.json' else 'frozen-backend-input.json')
# Token and arena consume frozen backend input from a separate immutable self copy.
patch=[];mapping=[]
for p in C.iterdir():
 old=p.read_text();new=old
 new=new.replace("ROOT=path.resolve(__dirname,'../..')","ROOT='/workspaces/quoridor/.worktree/ai-sigma'")
 new=new.replace("ROOT+'/.artifacts/ai-sigma/continuation-20261001/SIGMA-KERNEL-OWNERSHIP'",repr(str(O)))
 new=new.replace("ROOT+'/.artifacts/ai-sigma/continuation-20261001/SIGMA-KERNEL-OWNERSHIP/diagnostic/default'",repr(str(O/'diagnostic/default')))
 new=new.replace("path.join(__dirname,'../../.artifacts/ai-sigma/continuation-20261001/SIGMA-KERNEL-OWNERSHIP/diagnostic/default')",repr(str(O/'diagnostic/default')))
 new=new.replace("path.resolve(__dirname,'../../.artifacts/ai-sigma/continuation-20261001/SIGMA-KERNEL-OWNERSHIP')",repr(str(O)))
 new=new.replace("TOOL.parents[1]/'.artifacts/ai-sigma/continuation-20261001/SIGMA-KERNEL-OWNERSHIP'","Path("+repr(str(O))+")")
 new=new.replace("Path(__file__).resolve().parents[2]/'.artifacts/ai-sigma/continuation-20261001/SIGMA-KERNEL-OWNERSHIP'","Path("+repr(str(O))+")")
 new=new.replace("ROOT+'/.artifacts/ai-sigma/continuation-20261001/SIGMA-KERNEL-OWNERSHIP/input-before.json'",repr(str(O/'frozen-backend-input.json')))
 if p.name=='token-helper.cjs':new=new.replace("'input-before.json'","'frozen-backend-input.json'")
 new=new.replace('2026-10-01T14:06:05','2026-10-01T14:15:00').replace("'14:06:05Z'","'14:15:00Z'").replace("'14:01:05Z'","'14:10:00Z'")
 if p.name=='runner.py':new=new.replace('3758096384','2684354560').replace('117440512','58720256')
 if new!=old:patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(T/p.name),tofile=str(p)));p.write_text(new)
 mapping.append({'source':str(T/p.name),'source_sha256':h(T/p.name),'copy':str(p),'copy_sha256':h(p),'changed':new!=old})
(O/'source.patch').write_text(''.join(patch));write('source-copy-hashes.json',mapping)
prev=R/'tools/ai-sigma-detached-ownership';same=[];diff=[]
for x in m['source_checks']:
 p=pathlib.Path(x['path']);q=prev/p.name
 if q.exists():
  (same if h(p)==h(q) else diff).append(p.name)
write('old-new-source-comparison.json',{'unchanged':same,'changed':diff,'original_source_patch_sha256':h(S/'source.patch')});shutil.copyfile(S/'source.patch',O/'writer-source.patch')
assert '180 if name==\'fixed-initial5-once\' else 30' in (C/'runner.py').read_text()
write('prepared.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_input_checks':len(checks),'source_count':len(mapping),'changed_copy_files':[x['copy'] for x in mapping if x['changed']],'process_deadline':'2026-10-01T14:15:00Z','submit_deadline':'2026-10-01T14:25:00Z','newjob_cutoff':'2026-10-01T14:10:00Z','CPU':[2],'RSS_guard':2684354560,'storage_guard':58720256,'build_download_games':0})
print(json.dumps({'checks':len(checks),'source48':len(mapping),'writer_identities':len(current),'copychanges':[pathlib.Path(x['copy']).name for x in mapping if x['changed']],'oldunchanged':same,'oldchanged':diff}))
