import os,sys,time,json,signal,subprocess,resource,datetime,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent;os.sched_setaffinity(0,{0});deadline=min(time.time()+30,datetime.datetime.fromisoformat('2026-10-01T12:55:00+00:00').timestamp());assert time.time()<datetime.datetime.fromisoformat('2026-10-01T12:50:00+00:00').timestamp()
for d in ['temp','xdg-cache','xdg-config']:(O/d).mkdir(exist_ok=True)
env={**os.environ,'TMPDIR':str(O/'temp'),'TMP':str(O/'temp'),'TEMP':str(O/'temp'),'XDG_CACHE_HOME':str(O/'xdg-cache'),'XDG_CONFIG_HOME':str(O/'xdg-config'),'UV_NO_SYNC':'1','UV_OFFLINE':'1','PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','CUDA_VISIBLE_DEVICES':''};name=sys.argv[1];cmd=sys.argv[2:];utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def tab():
 t={}
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   try:
    s=(p/'stat').read_text().rsplit(')',1)[1].split();t[int(p.name)]={'pid':int(p.name),'ppid':int(s[1]),'starttick':int(s[19]),'state':s[0],'rss':int(s[21])*4096}
   except (OSError,ValueError,IndexError):pass
 return t
start=utc();tracked={};peak=0;peakstorage=0;reason=None;selftick=tab()[os.getpid()]['starttick']
with (O/(name+'.log')).open('wb') as log:
 c=subprocess.Popen(cmd,env=env,cwd=O,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);ctick=tab().get(c.pid,{}).get('starttick')
 while c.poll() is None:
  t=tab();known={c.pid}|{pid for pid,tick in tracked if t.get(pid,{}).get('starttick')==tick}
  for _ in range(5):known|={pid for pid,v in t.items() if v['ppid'] in known}
  members=[t[p] for p in known if p in t]
  for v in members:
   a=[]
   try:
    for z in Path('/proc/'+str(v['pid'])+'/task').iterdir():a.append(sorted(os.sched_getaffinity(int(z.name))))
   except (OSError,ProcessLookupError):pass
   tracked[(v['pid'],v['starttick'])]={**v,'observed_affinities':a};
   if any(x!=[0] for x in a):reason='AFFINITY_GUARD'
  rss=sum(x['rss'] for x in members)+resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;used=sum(p.stat().st_blocks*512 for p in O.rglob('*') if p.is_file());combined=sum(p.stat().st_blocks*512 for d in O.parent.glob('CRITIC-*') for p in d.rglob('*') if p.is_file());peak=max(peak,rss);peakstorage=max(peakstorage,used)
  if rss>=1073741824:reason='RAM_GUARD'
  if used>=29360128 or combined>=117440512:reason='STORAGE_GUARD'
  if time.time()>=deadline:reason='TIMEOUT30'
  if reason:
   for v in members:
    if tab().get(v['pid'],{}).get('starttick')==v['starttick']:os.kill(v['pid'],signal.SIGTERM)
   try:c.wait(timeout=1)
   except subprocess.TimeoutExpired:c.kill();c.wait(timeout=1)
   break
  time.sleep(.02)
 code=c.wait()
t=tab();remaining=[v for (pid,tick),v in tracked.items() if t.get(pid,{}).get('starttick')==tick]
r={'name':name,'command':cmd,'UTC_start':start,'UTC_end':utc(),'runner_pid':os.getpid(),'runner_starttick':selftick,'child_pid':c.pid,'child_starttick':ctick,'tracked':list(tracked.values()),'remaining':remaining,'exit':code,'stop_reason':reason,'peak_RSS_bytes':peak,'peak_allocated_bytes':peakstorage,'affinity':[0],'sample_ms':20,'instant_peak_and_short_lived_TID_not_guaranteed':True,'TMP_XDG_inside_owned':True,'NN_build_download_games':0,'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};(O/(name+'.process.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['name','exit','stop_reason','peak_RSS_bytes','remaining']}));sys.exit(code)
