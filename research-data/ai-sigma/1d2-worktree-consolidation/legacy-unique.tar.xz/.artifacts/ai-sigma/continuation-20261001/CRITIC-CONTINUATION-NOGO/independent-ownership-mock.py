from pathlib import Path
import json,hashlib,datetime,difflib,os
R=Path('/workspaces/quoridor/.worktree/ai-sigma');P=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-CONTINUATION-ENTRY';O=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda n,x:(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
ids={};process_ids=set();trace_ids=set();runners=set();jobs=[]
def add(pid,tick,origin):
 if type(pid) is not int or type(tick) is not int:return
 ids.setdefault((pid,tick),{'pid':pid,'starttick':tick,'origins':set()})['origins'].add(origin)
for p in sorted(P.glob('*.process.json')):
 d=load(p);jobs.append({'path':str(p),'sha256':sha(p),'name':d['name'],'exit':d['exit'],'stop_reason':d['stop_reason'],'remaining':d['remaining'],'runner_pid':d['runner_pid'],'runner_starttick':d['runner_starttick']});add(d['runner_pid'],d['runner_starttick'],p.name+':runner');runners.add((d['runner_pid'],d['runner_starttick']))
 for x in d['tracked']:add(x['pid'],x['start_ticks'],p.name+':monitor');process_ids.add((x['pid'],x['start_ticks']))
tracefiles=list(P.rglob('cleanup-trace.jsonl'));allTraceRows=[]
def recurse(x,origin):
 if isinstance(x,dict):
  if 'pid' in x:
   tick=x.get('starttick',x.get('start_ticks'));add(x['pid'],tick,origin)
   if type(tick) is int:trace_ids.add((x['pid'],tick))
  for v in x.values():recurse(v,origin)
 elif isinstance(x,list):
  for v in x:recurse(v,origin)
for p in tracefiles:
 for line in p.read_text().splitlines():
  e=json.loads(line);recurse(e,str(p.relative_to(P)));allTraceRows.append((p,e))
remaining=[]
for (pid,tick),v in ids.items():
 try:
  s=Path('/proc/'+str(pid)+'/stat').read_text().rsplit(')',1)[1].split()
  if int(s[19])==tick:remaining.append({'pid':pid,'starttick':tick,'state':s[0],'PPID':int(s[1])})
 except FileNotFoundError:pass
known=(1158490,10958079);assert known in ids and known in trace_ids and known not in process_ids and not remaining
seal=P/'diagnostic/golden-execution-GOLDEN-SEAL-01';failure=load(seal/'failure.json');responses=load(seal/'requests.json');stops=load(seal/'stop-before-document.json');assert failure['error']=='OWN_CLEANUP_FAILED';assert len(responses)==5 and [r['accepted'] for r in responses]==[True,True,False,True,True];assert len(stops)==1 and stops[0]['session']==1 and stops[0]['remaining_pids']==0
trace=seal/'session-2/cleanup-trace.jsonl';events=[json.loads(line) for line in trace.read_text().splitlines()];evidence=[]
for e in events:
 for v in e.get('remaining',[]):
  if (v['pid'],v['starttick'])==known:evidence.append({'kind':e['kind'],'UTC':e['UTC'],'monotonic_ms':e['monotonic_ms'],'identity':v})
end=next(e for e in events if e['kind']=='absence_wait_end');start=next(e for e in events if e['kind']=='absence_wait_start');assert any(x['identity']['state']=='Z' for x in evidence if x['kind']=='cleanup_failure');assert end['remaining_count']>0
monitor=P/'final-source-seal.monitor.jsonl';waits=[]
for line in monitor.read_text().splitlines():
 e=json.loads(line)
 if e['kind'].startswith('adopted_wait'):waits.append(e)
assert not any((e.get('identity',{}).get('pid'),e.get('identity',{}).get('start_ticks'))==known for e in waits)
runner=(O/'source-copy/runner.py').read_text();cleanup=(O/'source-copy/cleanup.cjs').read_text();assert "if v['pid']==child.pid or v['ppid']!=os.getpid():continue" in runner and "os.waitpid(v['pid'],os.WNOHANG)" in runner;assert sha(O/'source-copy/cleanup.cjs')=='15d119c20eee2bf6516b8563bbaa3285f715a8c9f323c2f3d3512a1dc9dfb247'
serialize=[{**v,'origins':sorted(v['origins'])} for v in ids.values()]
save('ownership-independent.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'identities_count':len(ids),'producer_claim':866,'monitor_identities':len(process_ids),'runner_identities':len(runners),'ownertrace_identities':len(trace_ids),'identity_match866':len(ids)==866,'identities':serialize,'currently_remaining':remaining,'known_crashpad':{'pid':known[0],'starttick':known[1],'owner_known':True,'python_tracked':False,'adopted_wait_logged':False,'current_absent':True,'trace':evidence,'absence_wait_ms':end['monotonic_ms']-start['monotonic_ms']},'jobs':jobs,'seal_final_failure':'OWN_CLEANUP_FAILED','session1_PID0_proved_before_fresh':True,'session2_controlled_cleanup_NOT_proved':True,'all_current_absence_is_not_historical_cleanup_success':True,'unknown43_cause_not_generalized':True,'newNN':0})
# Read only saved artificial mock outputs. No module importing/entry execution.
ms=load(P/'mock-summary.json');assert ms['passed']==len(ms['checks'])==9 and ms['synthetic_only'] is True and ms['real_NN']==ms['real_holdout_sends']==ms['real_games']==0
bind=load(P/'plan-bind.json');plan=load(Path(bind['preregister_path']));positive=load(P/'diagnostic/mock-execution-MOCK96-01/summary.json');table=positive['table'];assert positive['dry'] is True and positive['scheduled']==positive['completed']==96 and len(table)==96;assert [x['game'] for x in table]==list(range(1,97));assert len(plan['pairs'])==48 and len({x['pool_index'] for x in plan['pairs']})==48
for i in range(48):
 pair=plan['pairs'][i];a,b=table[2*i:2*i+2];assert a['prefix_sha256']==b['prefix_sha256']==pair['prefix_sha256'];assert a['candidate_color']+b['candidate_color']==3;assert a['seed']==b['seed']==1979;assert a['attempt']==b['attempt']==0
scenarios={p.parent.name:load(p) for p in (P/'diagnostic').glob('mock-*/summary.json')};assert scenarios['mock-retry']['globalRetry']==1 and scenarios['mock-retry']['completed']==96;assert scenarios['mock-global']['globalRetry']==2 and scenarios['mock-global']['completed']<96;assert scenarios['mock-pair-exhausted']['completed']==0
for k in ['mock-pause','mock-expired','mock-signal']:assert scenarios[k]['completed']==0
failed=scenarios['mock-cleanup-failed'];assert failed['cleanup_complete'] is False and failed['remaining_pids'] is None and 'OWN_CLEANUP_FAILED' in failed['stopReason'];assert failed['restarts']==1
snap=P/'job-source/entry-mock';diffs=[]
for p in snap.iterdir():
 q=O/'source-copy'/p.name
 if q.exists() and p.read_bytes()!=q.read_bytes():diffs.append({'name':p.name,'mock_run_sha':sha(p),'final_sha':sha(q)})
main=(O/'source-copy/match-entry.cjs').read_text();classification=(O/'source-copy/game-loop.cjs').read_text();assert 'ACTUAL_RUN_NOT_AUTHORIZED_THIS_CONTRACT' in main and "if(fs.existsSync(out))throw Error('RUN_ALREADY_EXISTS_NO_SILENT_RESUME')" in main and "purpose==='mock'?options.createBackend:realBackend" in main;assert "r.engine==='reference'&&referenceNNFailure" in classification and "kind:'invalid_pair'" in classification and "kind:'engine_loss'" in classification
save('mock-saved-independent.json',{'saved_nine_summary':ms,'positive_artificial_games':96,'registered_pairs':48,'number_prefix_color_seed_verified':True,'scenarios':[{k:v[k] for k in ['runId','dry','completed','globalRetry','restarts','remaining_pids','cleanup_complete','stopReason']} for v in scenarios.values()],'entry_mock_job_source_differences_from_final':diffs,'prior_source_saved_mock_only':True,'final_source_mock_complete':False,'real_positive_token_path_not_runtime_reverified':True,'newNN_entry_game_execution':0,'main_token_and_classification_read':True})
# Source timing boundary and readiness review. Save exact references/diffs rather than modifying code.
copy=O/'source-copy';arena=(copy/'arena.cjs').read_text();delivery=(copy/'delivery.cjs').read_text();page=(copy/'arena-page.js').read_text();assert 'inputAvailable??now()' in arena and 't0+c.offset_ms-c.error_ms' in arena and 'received_after_validation_ms=stamp' in delivery and 'JSON.stringify(response);const stamp=clock()' in delivery
save('source-boundary-review.json',{'startup':'loadArena readiness threads1/proxyfalse/canonical/model hash; native loaded:false, Chromium runtime','warm_classes':['startup candidate load warm outside hand','reference initial numeric startup warm outside hand','calibration each fixture/engine sample=-1 in request T','pilot each fixture/engine sample=-1 in request T'],'operational_t0':'diagnosticRealBackend takes hrtime before golden validation/submit; arena converts early deadline before prefix serialization/replay','postvalidation':'producer identity + owned binding + legality + response JSON.stringify precede final stamp; late/stale/timeout null','limits':'full actual game-loop/entry positive token not executed; final source different from 62/82/mock; startup outside requestT does not imply free work during game restart','minimal_future_contract_suggestions':['explicit startup-ready model/schema/strictvalue/warm complete gate per fresh session and private trace ownership registration before child can detach','uniform frozen source/job, predeclared case warmup and steady samples with start+end reclock; pick T/g before matches by same declared formula','budget jobtimeout from total readiness+warm+pause polls+calibration+cleanup, keeping per-hand T fixed; bounded async metadata reads outside hand','handoff Python monitor exact owner-discovered PID/starttick or full subreaper adopted child registry; self-adopted-only wait and bounded absence; fail closed when cleanup missing','gate original clock g=287 and final cleanup fail independently; no historical rescue/no .48 plan change now'],'no_new_freeze_or_settings':True})
print(json.dumps({'identities':len(ids),'current_remaining':remaining,'known_crashpad_monitor_missing':True,'saved_mock9':True,'saved96_numbering':True,'seal_final_cleanup':False,'newNN':0}))
