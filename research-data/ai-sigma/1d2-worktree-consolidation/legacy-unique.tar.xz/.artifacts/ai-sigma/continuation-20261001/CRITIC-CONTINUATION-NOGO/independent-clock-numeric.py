from pathlib import Path
import json,math,struct,hashlib,datetime,os,difflib
R=Path('/workspaces/quoridor/.worktree/ai-sigma');P=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-CONTINUATION-ENTRY';O=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda n,d:(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');finite=lambda v:type(v) in (int,float) and math.isfinite(v);mixed=lambda x,y:abs(x-y)<=1e-4+1e-4*abs(y);bits=lambda x:struct.unpack('<I',struct.pack('<f',x))[0]
fixtures={f['id']:f for f in load(R/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json')['fixtures']};refs={r['id']:r for r in load(R/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json')};pr=load(P/'diagnostic-preregister.json');versions=['GOLDEN-CALIBRATION-01','GOLDEN-CALIBRATION-CONTINUATION-01','GOLDEN-PILOT-01','GOLDEN-FINAL-01','GOLDEN-FINAL-BOUNDARY-REPAIR-01','GOLDEN-SEAL-01'];dirs={v:P/'diagnostic'/('golden-execution-'+v) for v in versions};rows={v:load(d/'requests.json') for v,d in dirs.items()}
expected=[(f,e,s) for f in pr['calibration']['fixtures'] for e in pr['calibration']['engine_order'] for s in pr['calibration']['sample_order']];cal=rows[versions[0]]+rows[versions[1]];assert len(rows[versions[0]])==62 and len(rows[versions[1]])==82;assert [(x['id'],x['engine'],x['sample']) for x in cal]==expected and len(set(expected))==144
request_checks=[];numeric=[];featureN=nnN=priorN=0;nnmax=pmax=0;missing_tensor_shapes=0
for version,rr in rows.items():
 accepted=0;reject=[]
 for i,r in enumerate(rr):
  assert type(r['accepted']) is bool and type(r['final_validation_and_serialization_before_stamp']) is bool and r['final_validation_and_serialization_before_stamp']
  req=r['request'];assert r['request_id']==req['request_id'] and r['generation']==req['generation'];assert req['seed']==1979 and req['T_ms']==r['T_ms'] and req['g_ms']==r['g_ms'];assert all(finite(r[k]) for k in ['elapsed_ms','t0_ms','received_after_validation_ms']);assert r['elapsed_ms']==r['received_after_validation_ms']-r['t0_ms'];f=fixtures[r['id']];assert req['legal_prefix']==f['legal_prefix']
  if r['accepted']:
   accepted+=1;assert r['error'] is None and r['fallback']==0 and r['checkpoint'] is True and r['legal'] is True and r['illegal'] is False and r['stale'] is False and r['owned_binding'] is True and r['received_after_validation_ms']<r['t0_ms']+r['T_ms']
   env=r['raw']['payload'];tx=env['transaction'];assert env['generation']==r['generation']
   for k in ['request_id','generation','prefix','legal_prefix','seed','simulations','max_nodes','max_depth','T_ms','g_ms']:assert tx[k]==req[k]
   assert tx['engine']==r['engine']
   if r['terminal'] is not None:assert r['action'] is None and r['nn_calls']==0
   else:assert type(r['action']) is int and r['action'] in [a['rust209'] for a in f['legal_actions']]
  else:
   assert r['action'] is None and r['checkpoint'] is False;reject.append({k:r.get(k) for k in ['engine','id','error','elapsed_ms','T_ms','late','nn_calls']})
  n=r.get('diagnostic_numeric_root')
  if not n:continue
  assert set(n)>= {'policy_logits','value'};vec=n['policy_logits'];assert type(vec) is list and len(vec)==136 and all(finite(x) for x in vec);assert finite(n['value']) and -1<=n['value']<=1
  actual=n.get('features_bits')
  if actual is not None:assert len(actual)==648 and all(type(x) is int and 0<=x<=0xffffffff for x in actual)
  else:assert len(n['features'])==648 and all(finite(x) for x in n['features']);actual=[bits(x) for x in n['features']]
  assert actual==[bits(x) for x in f['raw_features_float32']];oracle=refs[r['id']];assert len(oracle['policy_logits'])==136 and finite(oracle['value']) and -1<=oracle['value']<=1
  for x,y in zip(vec+[n['value']],oracle['policy_logits']+[oracle['value']]):assert finite(y) and mixed(x,y);nnmax=max(nnmax,abs(x-y))
  featureN+=648;nnN+=137;count=0;missing_tensor_shapes+= 'shapes' not in n
  if r['engine']=='candidate':
   data=r['raw']['payload']['payload']['data'];cp=data['checkpoint'];assert {k:v for k,v in cp.items() if k!='spans'}==data['owned']['cp']==data['original_checkpoint'];edges=cp['root_edges'];assert all(len(e)==4 and all(finite(x) for x in e) and type(e[0]) is int for e in edges)
   got={e[0]:e[1] for e in edges};assert len(got)==len(edges);legal=f['legal_actions'];assert set(got)=={a['rust209'] for a in legal};assert f['board']['turn'] in (0,1)
   perm=f['P2_permutation136'];assert sorted(perm)==list(range(136)) and all(perm[perm[j]]==j for j in range(136))
   indices=[perm[a['sigma136']] if f['board']['turn']==1 else a['sigma136'] for a in legal];assert indices==f['canonical_legal_indices']
   reference_priors={a['canonical136']:a['prior'] for a in oracle['canonical_legal_priors']};assert set(reference_priors)==set(indices)
   for a,idx in zip(legal,indices):
    x=got[a['rust209']];y=reference_priors[idx];assert finite(x) and finite(y) and x>=0 and y>=0 and mixed(x,y);pmax=max(pmax,abs(x-y));count+=1
   assert abs(sum(got.values())-1)<1e-5
  priorN+=count;numeric.append({'version':version,'row':i,'id':r['id'],'engine':r['engine'],'features':648,'NN':137,'candidate_priors':count})
 request_checks.append({'version':version,'rows':len(rr),'accepted':accepted,'rejected':reject,'raw_sha256':sha(dirs[version]/'requests.json'),'warmup_minus1':sum(r['warmup'] for r in rr),'sample_nonwarm':sum(not r['warmup'] for r in rr)})
assert (featureN,nnN,priorN)==(124416,26304,12198);assert len(numeric)==192;assert all(r['nn_calls']==1 for r in cal);assert len(rows['GOLDEN-PILOT-01'])==36 and all(r['accepted'] for r in rows['GOLDEN-PILOT-01'])
save('numeric-independent.json',{'features_bits':featureN,'NN_elements':nnN,'candidate_prior_comparisons':priorN,'numeric_rows':len(numeric),'NN_max_abs':nnmax,'prior_max_abs':pmax,'finite_strict_value_shapes_lengths_first':True,'tensor_dimension_metadata_missing_from_root_rows':missing_tensor_shapes,'tensor_dims_checked_by_original_source_not_raw_root':True,'threshold':'abs<=1e-4+1e-4*abs(ref)','cases':numeric,'reference_paths':[str(R/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json'),str(R/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json')],'raw_canonical_P2_rust209_distinct':True,'newNN':0})
# Reconstruct declared clock denominator independently from sessions and spans, retaining every startup warm.
opKinds={'root','begin_feature_request','NN','resume_policy_backup','root_restore','legal','feature','NN_validate'};finishKinds={'finish_owned_copy','finish'};ops=[];tails=[];errors=[];windows=[]
for v,d in dirs.items():
 for session in sorted(d.glob('session-*')):
  cp=session/'clock-calibration.json'
  if not cp.exists():continue
  start=load(cp);endpath=session/'clock-calibration-end.json';end=load(endpath) if endpath.exists() else None
  for engine in ['page','candidate','reference']:
   a=start[engine];assert finite(a['error_ms']) and a['error_ms']>=0;errors.append({'version':v,'session':session.name,'phase':'start','engine':engine,'ms':a['error_ms']})
   if end:
    b=end[engine];errors.append({'version':v,'session':session.name,'phase':'end','engine':engine,'ms':b['error_ms']})
   windows.append({'version':v,'session':session.name,'engine':engine,'end_saved':bool(end),'mid_delta_ms':end[engine]['offset_ms']-a['offset_ms'] if end else None,'offset_interval_overlap':max(a['lo_ms'],end[engine]['lo_ms'])<=min(a['hi_ms'],end[engine]['hi_ms']) if end else None})
  startup=load(session/'startup.json');warm=load(session/'reference-warm.json')['response'];assert startup['browser']['reference']['threads']==startup['browser']['candidate']['threads']==1
  for engine,spans in [('candidate',startup['browser']['candidate'].get('startup_warm_spans',[])),('reference',warm.get('telemetry',[]))]:
   for x in spans:
    if engine=='candidate' and x['kind'] not in opKinds:continue
    duration=x['end']-x['start'];assert finite(duration) and duration>=0;ops.append({'version':v,'session':session.name,'sample_class':'startup_warm','engine':engine,'kind':x['kind'],'ms':duration})
for v in versions[:2]:
 start=load(dirs[v]/'session-1/clock-calibration.json')
 for i,r in enumerate(rows[v]):
  finish=0
  for x in r.get('diagnostic_spans',[]):
   duration=x['end']-x['start'];assert finite(duration) and duration>=0
   if x['kind'] in opKinds:ops.append({'version':v,'sample_index':i,'id':r['id'],'sample_class':'case_warmup' if r['warmup'] else 'calibration_sample','engine':r['engine'],'kind':x['kind'],'ms':duration})
   if x['kind'] in finishKinds:finish=max(finish,duration)
  env=r['raw']['payload'];remote_finish=env['time']['finish'] if r['engine']=='reference' else env['payload']['data']['adapter_end_ms'];tail=max(0,r['received_after_validation_ms']-(remote_finish-start[r['engine']]['offset_ms']));tails.append({'version':v,'row':i,'finish_ms':finish,'delivery_ms':tail,'ms':finish+tail})
maxop=max(ops,key=lambda x:x['ms']);maxtail=max(tails,key=lambda x:x['ms']);maxerr=max(errors,key=lambda x:x['ms']);g=math.ceil(maxop['ms']+maxtail['ms']+maxerr['ms']+5);assert g==287 and g>91 and g>500/4
originalJob=load(P/'golden-calibration.process.json');assert originalJob['exit']==1 and originalJob['stop_reason']=='deadline';assert not (dirs[versions[0]]/'clock-end.json').exists();assert not (dirs[versions[0]]/'session-1/clock-calibration-end.json').exists()
segments=[];jobs=['golden-calibration','golden-calibration-resume-one','golden-pilot','final-same-main-golden','final-boundary-repair-one','final-source-seal'];
for v,job in zip(versions,jobs):
 snap=P/'job-source'/job;final=O/'source-copy';differences=[]
 for p in snap.iterdir():
  q=final/p.name
  if q.exists() and p.read_bytes()!=q.read_bytes():differences.append({'name':p.name,'run_hash':sha(p),'final_hash':sha(q)})
 data=load(P/(job+'.process.json'));segments.append({'version':v,'job':job,'exit':data['exit'],'start':data['start'],'end':data['end'],'stop_reason':data['stop_reason'],'requests':len(rows[v]),'source_differences_from_final':differences})
for name in ['pause-check.cjs','match-entry.cjs','arena.cjs','golden-gates.cjs']:
 a=P/'job-source/golden-calibration'/name;b=P/'job-source/golden-calibration-resume-one'/name
 if a.read_bytes()!=b.read_bytes():(O/('calibration62-to82-'+name+'.patch')).write_text(''.join(difflib.unified_diff(a.read_text().splitlines(True),b.read_text().splitlines(True),fromfile='segment62/'+name,tofile='segment82/'+name)))
save('clock-validation-independent.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request_checks':request_checks,'calibration_index_exact_0_143':True,'duplicates':0,'saved62':62,'saved82':82,'case_warmup24_separate':sum(r['warmup'] for r in cal),'calibration_nonwarm120':sum(not r['warmup'] for r in cal),'pilot_warm6_separate':sum(r['warmup'] for r in rows['GOLDEN-PILOT-01']),'pilot_nonwarm30':sum(not r['warmup'] for r in rows['GOLDEN-PILOT-01']),'g_formula':{'max_operation':maxop,'max_finish_delivery':maxtail,'max_error':maxerr,'margin':5,'g_needed':g,'fixed_g':91,'T_over4':125,'gate':False},'ops':ops,'tails':tails,'clock_errors':errors,'windows':windows,'segments':segments,'original_job120_failure_preserved':True,'end_clock_first_missing':True,'unknown_unfinished_NN_not_success':True,'uniform_final144':False,'tail_guarantee':False,'NN':0})
print(json.dumps({'numeric':(featureN,nnN,priorN),'maxNN':nnmax,'maxPrior':pmax,'g':g,'maxop':maxop['ms'],'maxfinish':maxtail['ms'],'maxerror':maxerr['ms'],'versions':[(v,len(rows[v])) for v in versions]}))
