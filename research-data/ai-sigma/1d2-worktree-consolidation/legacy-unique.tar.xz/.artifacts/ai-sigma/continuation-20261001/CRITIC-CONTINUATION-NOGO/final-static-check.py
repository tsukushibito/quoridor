from pathlib import Path
import json,hashlib,struct,math,datetime
R=Path('/workspaces/quoridor/.worktree/ai-sigma');O=Path(__file__).resolve().parent;P=O.parent/'SIGMA-CONTINUATION-ENTRY';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();versions=['GOLDEN-CALIBRATION-01','GOLDEN-CALIBRATION-CONTINUATION-01','GOLDEN-PILOT-01','GOLDEN-FINAL-01','GOLDEN-FINAL-BOUNDARY-REPAIR-01','GOLDEN-SEAL-01'];count=0
for v in versions:
 rows=load(P/'diagnostic'/('golden-execution-'+v)/'requests.json')
 for r in rows:
  n=r.get('diagnostic_numeric_root')
  if not n:continue
  features=[struct.unpack('<f',struct.pack('<I',x))[0] for x in n['features_bits']] if 'features_bits' in n else n['features'];assert len(features)==648 and all(type(x) in (int,float) and math.isfinite(x) for x in features);count+=len(features)
assert count==124416
b=load(O/'input-before.json');checks=[]
for c in b['checks']:
 p=Path(c['path']);h=sha(p);assert h==c['sha256'],c['path'];checks.append({'path':c['path'],'sha256':h})
(O/'input-after.json').write_text(json.dumps({'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original425':b['original425'],'final89':b['final89'],'checks':checks,'unchanged':True,'no51_inputs':True},indent=2)+'\n')
(O/'feature-finite-check.json').write_text(json.dumps({'features_decoded_finite':count,'threshold_changed':False,'source_stop_49':load(P/'source-write-stopped-final.json'),'new_runtime_NN':0},indent=2)+'\n')
print(json.dumps({'inputs_unchanged':len(checks),'original425':b['original425'],'final89':b['final89'],'decoded_feature_finite':count}))
