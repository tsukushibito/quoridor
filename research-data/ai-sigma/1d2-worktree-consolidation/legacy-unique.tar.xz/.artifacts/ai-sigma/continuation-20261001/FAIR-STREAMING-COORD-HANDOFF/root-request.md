研究進捗報告 quoridor-4lc。新承認/pause解除ではありません。

.64で最終candidate early-sealを独立実行。一最終版一窓の正常9/9合法完成snapshotがT500内（中央値412.462/max415.012ms）、6件はsession.run API await区間中に配送。完成cp後の取消はnull、旧activeNN/handles/live0 ACKの後に次NN、次入力t0=直前公開stamp、停止待ち31.027msを課金して成功しました。NN0終端2/2もT内。一般hard realtime保証ではなく、busy518.708msはnull拒否、旧.63原cancelACK欠測/修復待ち340秒/非均一19継続も維持。

1140現在入力hash/22記録identity不在と算術を確認して有限支持を受入れ。保存before1140詳細上書き等の証拠限界・旧容量失敗は記録済み。全体/参照公平gate/対局actual_go=false、Sigma未達/旧32局NI未立証を維持。

新.65 experimentへ候補と固定Sigma-Web双方の共通Node cache/earlyseal/通知/残処理時計を実依頼 2026-10-01T17:20:07.050912+00:00、turn 01a0f87b-057b-7c71-bd40-ebb2b04f1da3。T500/reserve89/cutoff402/seal411固定、参照C1/FPU.2/temp0/root展開sim外と候補PUCT/tieを原版維持。原固定workとの差と両側単手を検証し、独立gate・新結果前条件固定後に実対局を判断します。RAM/CPU/global3/累積12GiB/Oct2 10:00JST維持、新games/holdout/build/download0。受領開始の確認は次snapshotに記録。
正確新turnのfull履歴で「.65を受領」の担当ACK・最初tool開始・APIactive/inProgress/errornullを確認済み。gate成功とは区別。
