新実依頼 SIGMA-FAIR-STREAMING / quoridor-4lc.65。既存許可内、計画のみで終わらず両側共通callerを実装・少数検証してください。原 .63は限定受入れ理由を残し本人close可、旧全時計失敗/元340秒は保持。原 .64他者close0。受領/本人claim/開始を先記録、source/run ownerは新範囲のみ。T500/reserve89/cutoff402/seal411の両側経路、参照C/FPU/tie/root分母を原版維持。actual_go=false/ゲームとholdout0。
契約SHA cadc47b2bcfc34a3566035ad8775fdfd3d245fc4726753379acdf89e2ecd3def

# SIGMA-FAIR-STREAMING / quoridor-4lc.65 / 試行1・契約1

experiment 01a0f31d-6d15-7620-bb63-4b4f878e4746 → coordinator。親継続版2 SHA6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f 全文継承、Oct2 01:00UTC終了/新重job00:50/監督00:55・global3・CPU/RAM/累積12GiB・製品範囲不変。受領から処理85分/提出100分、新jobは処理5分前停止、全体deadlineとの早い方。短い暫定報告・停止JSONを文書より先に保存する。

## 対象・所有・固定入力

新 `tools/ai-sigma-fair-streaming/` と `.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING/`、`docs/reports/ai-sigma-experiment-fair-streaming.md` のみ書込。 .63/.64・固定Sigma原文/ORT・ONNX・immutable Wasm/製品/rootlockはread-only。コピーは自己域、初期/最終hash・patch・元期待bytesを保管。入力の可変報告追記と実sourceを区別し、元hashを任意prefix切取りで満たすsource処理は禁止。

元候補 .63 revision3 source-frozen SHA c5381302d6573605242d06ede2f173e8fb68102c3ad9121a6d68e4070a5b411d、manifest c877e781d72d1a71cc8c667a7298ffd245058a011a7beb56640490155235a4d9。独立 .64報告SHA3d52108f2ef0a9b5e51cf8898012e639589b1a6253d1edfc779707b0a1f78f25、manifest d367887e70ebe091f3c0f7c66832d2fbe086e59cffe055e1e3e3eba6ea9e9611。統括受入れ `docs/reports/ai-sigma-coordinator-early-seal-independent-acceptance.md` を読んで .63を限定理由で本人closeしてよい。原 source/raw/reportは編集0。 .64他者close0。

参照は固定Sigma commit751186344fc52ad0c29bc65922e62c6fa915f006 のgame.js/MCTSと既 .16/.18/.21参照worker来歴を照合して利用。`tools/ai-sigma-streaming-early-seal/reference-worker.js` 等は移入元であり、上流原文・clock/transport patchとの関係を記録する。ONNX11663428B/SHA d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d、ORT-Web1.21.0 wasm/threads1/proxyfalse、同bytesを実検査後sessionへ。両者同モデル・同RuleA/history/終端優先/手t0・資源、各探索アルゴリズムは原版を維持する。

## 実装と判別

候補と固定Sigma-Webを同Node caller cache/validation-finish cutoff/早いsealへ接続する。固定T500ms/reserve89/commit余裕9/cutoff402/seal411、通知頻度は双方「完成root展開または一simulateのbackup完了ごと」、同期NN中sealが問い合わせ/awaitしない。根展開前未完成をcp扱いしない。完成root展開時に原finishが返せる合法bestActionがある場合だけ完成root cpとして可、NN0暫定手/fallback新導入0。初回無しnull、NN0終端はeffective goal優先/draw0。

候補NN/kernel/ownedpending/PUCT1.5/Q0/seed1979/原合法順/tie/finish/4096sim/512node/depth24は変更0。参照C1/FPU.2/temp0/原合法順/first tie/元bestAction/root展開sim外/100000simを維持。参考に同機能を無理に同statsに正規化しない。共通receiverはshape/type/finite/value[-1,1]・合法集合/prior/依頼局面model/schema/engine/prefix/history/key/limits/ID/gen/epoch/token/単調sequence・完成所有境界・検証終了cutoffを検査し、engine固有のvisit/NN/sim関係は原規約のまま明示する。候補edge和sim−1を参照へ適用しない。単にedgeから任意の勝ち手を再選択せず、参照原finishのbestActionを保存する。

通知はimmutable clone、完成backup後/現rootの一貫したactionとstatsのみ。実NN/推論エラーはstructural fault、preseal受信fault/cancel全discard、postseal通知は既公開を変更しない受信順政策を両者共通にし、故障生成時刻の全知/一般任意tree安全性は主張しない。候補faultは候補loss、参照NN/model障害はpair invalid、参照deadline/crashは参照loss、共通identity/referee IPCはinfra invalidという将来分類を保持。今回は分類mockであり勝敗0。

両producerが実処理した全identity/prefix/seed/limitsをechoしcallerと選択engineを照合。主側t0はimmutable入力供給可能・adapter前、t1はidentity/legal/numeric/format/encoding後Node stamp。ページ・Workerの開始/終了ping各12とclock区間/driftを固定、早側換算/end包含。最終deadline外は公開null/lateで救済0、全private診断は公開後、追加finish/NNでtimer結果を作らない。

次入力供給時は直前公開stampをt0として旧activeNN/探索handle停止待ち・必要cleanup/load/warm/reclockを含める。自分の旧探索が実ACKでactiveNN/handles/live_searches=0となるまで次NN開始0。相手にCPUを渡す前にも旧単threadの停止ACK/所有回収を確認、待ちを時計外の無課金sleepへ逃がさない。session/plan再利用は同ownership条件を満たす場合可、キャンセル同期割込やhard realtime保証ではない。既kernel sole-root/boot/PID/starttick/adoption waitを維持、未知PIDへsignal/wait0、forced/current absence/当時controlled回収を分離。

## 結果前登録・少数実行

全校正/固定work/通常/境界のorder・分母・source hashをNN前に自己preregisterへ保存。reserve再選定なし。共通NN0代表payloadは3golden+goal/人工200各engine×warm1/steady2（計30）で経路/型/cutoff/encodingを確認し、89ms内に収まらないなら不適格として新条件に変えず提出する。NN0模擬cpは推論成功に混ぜない。

fixed-workは参照原instrumented対照と新完成通知wrapperを同3golden×8simで比較（計6検索）。root展開sim外を保持し、手/全root visits/prior/value/context/backupが一致するか検査。診断時は締切を十分長くして固定workを終えるが、通常T500成績へ流用しない。候補24保存cp/controlも独立算術、元とrootfeatures/prior/actionが一致することを照合。新3golden root648f32/137NN/priorは両側固定参照とabs<=1e-4+1e-4|ref|、長さ/finite/strict値先検査。

通常は3golden×各engine×warm1/steady3=24要求、AB/BA順を結果前固定して一最終版一窓。境界は各engine完成cp後cancel→次通常、NN0合法goal/人工200、初回無し、検証cutoff跨ぎ、caller busy、遅延通知・旧世代・faultから上限12要求を結果前列挙（必要時mockを併用）。全体t0/分母・sim/完成NN/attempt/鮮度/API await区間/stopACK待ち・post-validation配送stampを保存。source修正や原因別一回retryが必要なら原失敗保持・別run/version、新均一suiteと元未完成を混同せず合格へ救済0。初期guardやdelay injectionを正常速度結果に混ぜない。実対局/game-loop/holdout入力送信0。

## 資源・handoff

準備/静的CPU0または2、重NN/runtime/監視はCPU2単logical・推論thread1、重jobは一系列・他重研究NN停止確認。RAM4GiB guard3.5、new128MiB guard112は既entry2GiB予約内・追加予約0、累積12GiB旧課金を減額しない。各重job最大180秒（固定分母の最悪wallに足りないなら事前に自己jobを区切り結果前窓を固定、metadata/開始終了clockの欠測を隠さない）。ORT/cache/Wasmは読取共有・重複大規模copy0。所有量/RSS/affinity/clock/boot-PID-starttick/command/hash/exit/失敗/TMP-XDGと瞬間欠測を保存。文書前runtime-stop/hashafter/manifest/source-stop。

build/compile/download/依存同期/共有環境変更/製品/学習/GPU/実対局/holdout/追加委譲/他者kill0。actual_go=false、独立次gate・新比較事前登録・統括freeze前の実run拒否を保持。旧32局と標本統合0、NI未立証/Sigma未達/旧g287・62+82・元340秒・容量/期限/scope逸脱を保持。Atract/BORT/CB0とH1backend/H2探索/H3時計・cp/H4標本を維持。同じcallerの成立は棋力優位の因果証明ではない。受領/本人claim/開始を先記録、停止後backup/report、.65受入れ待ち、goal/他者close0。


親継続全文
# Sigma自律研究・継続枠 2026-10-01

契約版2。目標quoridor-4lc。統括01a0f31b-3409-75f2-a30e-453a50484f94。根拠はユーザーの明示継続/詳細委任（root入力01a0f2e9-357d-7ef3-a2fe-b16f80accda5）。開始2026-10-01T09:03:36.459834+00:00、終了2026-10-02T01:00:00Z（2026-10-02 10:00 JST）。本書は新しい実行枠であり、旧目標契約版2の初期04:00終了/未達/過去逸脱を保持する。旧文書・旧preregister・成績は変更しない。目標/比較A/通常製品規約維持/独立検証/権限は旧目標契約を継承する。

固定Sigmaと同計算資源・思考時間でnative/localおよびbrowserの非劣性を実測する。旧32局m8のnative.5625/browser.1875と両下限未達を保持。今回の新比較はcode/model/config/pool/T/g/m/CI/停止/責任分類を結果前に別事前登録し、旧結果へ後付け条件変更/標本統合をしない。未使用m10計画は参考として残すが、実入口/共通時計/資源gateと新deadlineを独立freezeするまで対局禁止。

予算はCPU全計4logical、RAM全計8GiB、LLM最大3（統括と新supervisorを含む）、正式CPU比較はCPU2単logical/推論threads1/GPU推論0/他の重い研究job停止。GPU研究は旧上限6GiB・1job30分・累積2h以内を保持し、今回は別配分前GPU/学習0。成果/依存は旧枠から累積12GiBを維持、リセット/12GiB追加ではない。旧限定保守課金6,588,000,723B・条件付き残6,296,901,165Bを開始時再確認する。初回新規予約: entry2GiB（guard1.75GiB）、steward128MiB、監督32MiB、統括文書32MiB。未配分は基準再確認後に統括が同12GiB内で配分。副次cache/途中展開/一時profileも計上。既存共有training/cacheは読取のみ、削除はこの枠が所有する再生成物だけを証拠保持の上で別に判断。

既存五役saved sessionを維持、新supervisorは既存App Serverに永続登録して観測専用で追加。App Server/toolchain再起動やモデル/effort変更をしない。新有料API/クラウド/第三者オンライン対局なし。主checkout製品/UI/描画/M2/commit/push/公開は対象外。研究worktreecodex/ai-sigmaで新copyに実装し旧入力をhashで固定。スケジューラーは主checkoutのpush済み操作入口を利用し、運用role定義/registry/専用configだけを用意する。

監督issuequoridor-4lc.40、20分周期/1turn180秒（新job120秒で停止し報告へ）、終了2026-10-02 00:55UTC、観測のみ。globalは3だがschedulerの起動閾値max_active_sessions=2として統括報告の起動1枠を残す。枠使用中はskipしsteerしない。変化なしは保存のみで静かに終了、意味ある停滞/失敗/期限資源/完了時にだけ統括へreportする。監督が設定や課題配分を変更しない。pause/終了はownedturnだけinterrupt確認し、外部jobは各ownerが回収する。dispatcherや監督の停止だけでNN停止を認定しない。

初回はquoridor-4lc.38stewardがscheduler準備/実運用/容量/資源台帳、quoridor-4lc.39experimentがORT入口・復旧gateを担当。途中から競合A共通tract/B分離ORT/C B0とH1backend/H2探索/H3時計・checkpoint/H4標本を更新し、通常判断は統括が実依頼する。別の選択が有望ならこの枠内で契約を作り替えるが、結果を見た正式判定緩和は行わない。

終了: 目標達成、ユーザーpause、上限/guard/異常、2026-10-02 01:00UTC。2026-10-02 00:50UTCまでに新重jobを止め、終了処理を確保する。全ownerはPID/starttick/command/hash/exit/資源/失敗/stopを先保存、報告は簡潔に詳細JSONへリンク。達成なら独立根拠で目標close、未達なら次の継続/停止理由を記録。予算を自動延長しない。各実行deadlineは本枠以下。担当へ実送信/受領をBeadsとdispatchに記録する。

継続委任は目標へ向けて継続する指示である。未達の場合は本枠終了前に統括が次枠の必要性/予算/検証を判断し、ユーザーへ通常詳細の再承認を求めず別契約として具体化できる。同一枠の期限や累積12GiBを黙って拡張しない。

## 契約版2の期限変更根拠

2026-10-01、操作元root 01a0f2e9-357d-7ef3-a2fe-b16f80accda5からユーザー明示指示を受領。「明日午前10:00」は2026-10-02T10:00:00+09:00 = 2026-10-02T01:00:00Z。開始時刻は維持し、旧継続枠終了2026-10-01T17:00:00Zから終了時刻だけ変更する。重い処理停止00:50UTC（09:50JST）、監督運用停止00:55UTC（09:55JST）、monitor回収00:58UTC、枠終了01:00UTC（10:00JST）。目標達成・pause・guard停止条件と時間以外のCPU/RAM/LLM/累積容量・許可範囲・独立検証は変更しない。

旧版SHA859bb777836cc0683e1ad7d1763a71fda60c75d2d6391290cef28771589a81a2を.artifacts/ai-sigma/continuation-20261001/DEADLINE-20261002-1000/continuation-version1.mdへ保全。閉じた実験や旧個別契約の処理/提出期限、事前登録、旧失敗/逸脱を遡及延長しない。新実験・比較は別契約で結果前に固定する。統括.52が正本/Beads、steward.53が既存所有範囲の運用契約/config/reload/monitor更新と実反映を担当する。


統括限定受入れ（固定入力）
# .64 有限early-seal検証の受入れと共通参照経路

2026-10-01 17:16UTC、quoridor-4lc.64を限定受入れ。完成snapshotの候補側配送・取消後の同時計/旧CPU停止を支持する。全体時計gate・参照接続・実対局・棋力・Sigma同等到達は未成立、actual_go=false。

報告SHA3d52108f2ef0a9b5e51cf8898012e639589b1a6253d1edfc779707b0a1f78f25、manifest d367887e70ebe091f3c0f7c66832d2fbe086e59cffe055e1e3e3eba6ea9e9611を固定。1140原入力の現在hash一致・記録22 PID/starttick現在不在を統括確認し、正常9件の中央値412.462ms/max415.012msを再計算した。完全before1140詳細snapshotは688入力copyの上書きで未保存、当初stdoutとsource58/copy差分/688beforeを区別し、前後完全監査へ格上げしない。

最終revision3の一窓16要求は取消1・正常9（warm3/steady6）・境界6。正常9/9合法cp、NN0終端2、取消ACK後に次NN、次t0=前公開stamp、停止待ち31.027ms課金を支持する。6正常配送はsession.run API区間内でありexact kernel命令時刻ではない。busy518.708msはnull拒否、初回無し/cutoff跨ぎ/faultもnull、fault政策は受信順に限定。原任意treeの一般的検証ではなく、信頼した完成producer境界である。

元 .63の正常12/steady9/境界6/終端2、最初warm340210.191ms、原取消ACK欠測と未実行19のみ継続、forced回収・helper失敗・瞬間peak/背景欠測を保持する。独立成功で元失敗を救済しない。 .63と.64の担当は、今回の限定受入れと全no-go/未確認をnotesへ残して本人closeしてよい。目標/旧.60blocked/旧.56期限は変更しない。

次 .65 experimentは両AIへ同T500/reserve89/cutoff402/seal411のNode caller・完成通知・旧CPU残処理課金を接続する。参照C1/FPU.2/temp0/order/root展開sim外と候補PUCT1.5/Q0/seed/tie/finish/capsを維持、参照のroot訪問数を候補sim−1へ偽装しない。原固定work対照と両側少数単手の実検証を結果前登録する。新copyのみ、実対局/holdout/build/取得0、独立次gateと新結果前比較契約までactual_go=false。

詳細は `.artifacts/ai-sigma/continuation-20261001/FAIR-STREAMING-COORD-HANDOFF/independent64-review.json`。本書は新入力として固定し、worker動作中に追記しない。資源/Oct2 01:00UTCは不変、旧32局NI未立証/Sigma未達とA/B/C・H1〜H4を保持する。


 .64独立報告全文
EXPERIMENT_REVIEW SIGMA-EARLY-SEAL-INDEPENDENT quoridor-4lc.64 / trial1 / contract1

受領16:53:54UTC、全文契約/親版2・ready/show/pause確認後自.64のみclaim。保守起点16:53:50、処理17:28:50/新job17:23:50/提出17:38:50を固定。旧.60blocked/.56期限変更0、追加委譲/対局/holdout/build/取得0、actual_go=false。

限定支持: 最終revision3の自己copy一窓16:58:59.078→16:59:13.047、exit0、16要求を固定順で完了（取消1、正常9=warm3+steady6、境界6=終端2+初回無し/検証跨ぎ/busy/fault）。正常9/9合法checkpoint、median412.462/max415.012ms、steady6 median412.714/max414.564ms。NN0合法goal/人工200は414.096/416.631ms。人工200を合法到達証明にしない。

取消はAction=null/CANCELLED。handle/activeNN/live_searches=0のACK後に次NN、次t0は前公開stampと厳密一致し、停止待ち31.027msも課金。全後続NNも前停止ACK後。正常6/9の最終stampが時計誤差込みのsession.run API await区間内。内核命令時刻/hard deadline保証とは区別する。初回無し・cutoff跨ぎ・受信faultはnull、busy518.708msはLATE_FINAL_STAMP/null、遅配救済0。通知遅延境界は静的選択で今回は未実行。

数値/完成cache: 新9072特徴bits、1918 NN要素、保存prior1289をshape/finite/strict[-1,1]/合法集合先確認後、固定abs1e-4+rtol1e-4で照合。NN最大差3.576279e-6、prior1.594364e-6。公開完成NN68と実attempt/完了104を混同せず、取消後棄却cpのpriorは捏造0。保存control24cp全tree/history/stats/action一致、3888bits/822NN/772priorも通過、control実NN再実行0。resume/backup→copy/freeze→通知→Node検証終了cutoff402→seal411→最終合法性/encoding/stampを独立照合。sealにWorker問い合わせ/NN awaitなし。33注入・8token gate、重複/逆順/foreign/partial必須欄/非finite/範囲/faultを拒否し、seal後不変を確認。

保留/no-go: 任意有限tree内容はreceiverで一般検証せず、信頼した完成producer境界に限定。faultは受信順政策、取消同期割込不可、参照AIへの同caller/通知/残処理課金は静的提案のみ。全体時計適格/entry/対局/棋力採用は未成立。旧20分母を再集計し、正常12のmax340210.191ms、条件付き11、steady9を分離。旧取消ACK欠測、誤分類修正、未実行19の継続は均一一版一窓20完遂ではない。3618byte原期待SHAと保存全文prefix一致を確認したが、実コードの任意prefix許可にしない。

停止/資源: 本文前16:59:40停止JSON、追跡22identity現在不在、kernel sole-root/boot/PPID/starttick、adopted2件同identity waitとNode controlled PID0、forced=true。writer77/旧critic72も現在不在、全期間証明ではない。全観測TID CPU2/NNthreads1、RSS peak2152026112B<2.5GiB、保存約3.6MiB/検出critic合計約51.6MiB、TMP残0・XDG小残保存、routingのみport0。40→20ms guardでも瞬間peak/背景負荷を保証しない。

失敗/証拠限界: NN前helperのschema誤認・境界選択7→6と、取消cp=nullを誤認した算術helperを保存し訂正。1140入力before実照合stdoutはあるが詳細snapshotがupstream688copyで上書きされたため、完全before1140保存を主張しない。原58source/copypatchと688before、全1140現在一致を別証拠にする。初期短shellのPID/RSS欠測保持、旧容量/期限/scope/CPU逸脱・旧32局/NI未立証不変。

詳細はCRITIC-STREAMING-EARLY-SEAL/independent-runtime-summary.json、upstream-independent-arithmetic.json、saved-control24-independent.json、pipeline-clock-nextrequest-independent.json、ownership-independent.json、full-input-after.json、own-helper-failures-and-evidence-limits.json。再現command/patch/hashはnn-suite-64-once.process.json/copy-patches.json。自己runtime停止後新NN0、backup/report後受入れ待ちin_progress。goal/他者close0。


統括1140hash/current22PID/算術確認
{
  "UTC": "2026-10-01T17:16:35.768409+00:00",
  "original_current_checks": 1140,
  "mismatches": [],
  "recorded_identities": 22,
  "same_identity_live": [],
  "normal9": {
    "n": 9,
    "median": 412.4616699963808,
    "max": 415.01248501241207
  },
  "cancel_next_t0_equal": true,
  "cancel_wait_ms": 31.026630997657776,
  "reference_runtime": false,
  "limited_acceptance": true,
  "all_clock_gate": false,
  "actual_go": false,
  "complete_before1140_snapshot_not_claimed": true,
  "critical_hashes": {
    "docs/reports/ai-sigma-critic-streaming-early-seal.md": "3d52108f2ef0a9b5e51cf8898012e639589b1a6253d1edfc779707b0a1f78f25",
    ".artifacts/ai-sigma/continuation-20261001/CRITIC-STREAMING-EARLY-SEAL/report-manifest.json": "d367887e70ebe091f3c0f7c66832d2fbe086e59cffe055e1e3e3eba6ea9e9611",
    ".artifacts/ai-sigma/continuation-20261001/CRITIC-STREAMING-EARLY-SEAL/processing-stopped-before-report.json": "af3724cb4bff19d6a91b0f4803e152de1556a8464248827fd208311d98d9cefd",
    ".artifacts/ai-sigma/continuation-20261001/CRITIC-STREAMING-EARLY-SEAL/independent-runtime-summary.json": "3283d898c2f630aa0e9d1964e4430c4f19c58e228562112ae139102d6eb5daac",
    ".artifacts/ai-sigma/continuation-20261001/CRITIC-STREAMING-EARLY-SEAL/pipeline-clock-nextrequest-independent.json": "def718e1762a030fd1ccfd98509db9c01f6d7965d6e4eb83708c09acacaf47b0",
    ".artifacts/ai-sigma/continuation-20261001/CRITIC-STREAMING-EARLY-SEAL/full-input-after.json": "85fc1021b9e6feebcb1aa520370b65eb80d0ce0717e188861a57657bec09d43c"
  }
}
