const fs=require('fs'),vm=require('vm'),path=require('path'),crypto=require('crypto'),A=require('assert/strict');
const ROOT='/workspaces/quoridor/.worktree/ai-sigma',OUT=path.resolve(__dirname,'..'),load=p=>JSON.parse(fs.readFileSync(p)),hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const game=__dirname+'/game.js',context=__dirname+'/context.js';A.equal(hash(game),'dfa438a500d6808e21bf8fef72a299cd762ac5e8be25251dd38607abb2d046c5');
const scope=vm.createContext({console});vm.runInContext(fs.readFileSync(game,'utf8')+'\n'+fs.readFileSync(context,'utf8')+'\nglobalThis.independent={referenceState,vertPolicyPermutation,actionToIndex,rustAction,terminalResult};',scope);
const api=scope.independent,fixtures=load(ROOT+'/.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json'),raw=load(ROOT+'/.artifacts/ai-sigma/runs/SIGMA-ORT-ENTRY-CONTINUE/diagnostic/real-golden/numeric-raw.json');
A.equal(fixtures.fixtures.length,28);A.equal(fixtures.fixtures.filter(f=>f.classification==='legal-replay').length,20);
const bits=x=>{const b=Buffer.alloc(4);b.writeFloatLE(x);return b.readUInt32LE()},softmax=(logits,ids)=>{const m=Math.max(...ids.map(i=>logits[i])),e=ids.map(i=>Math.exp(logits[i]-m)),sum=e.reduce((a,b)=>a+b,0);return e.map(x=>x/sum)},rows=[];
for(let n=0;n<3;n++){
 const c=raw.wasm[n],r=raw.reference[n],f=fixtures.fixtures.find(x=>x.id===c.id);A.equal(c.id,r.id);A.equal(f.classification,'legal-replay');
 const s=api.referenceState(f),actions=s.getLegalActions(),perm=Array.from(api.vertPolicyPermutation(9));A.deepEqual(perm,f.P2_permutation136);
 const rawids=actions.map(a=>api.actionToIndex(a,9)),canonical=rawids.map(i=>s.isPlayer1Turn()?i:perm[i]),rustids=actions.map(a=>api.rustAction(s,a));
 A.deepEqual(Array.from(rawids),f.legal_actions.map(a=>a.sigma136));A.deepEqual(Array.from(canonical),r.indices);A.deepEqual(Array.from(rustids),f.legal_actions.map(a=>a.rust209));A.equal(new Set(rustids).size,rustids.length);
 A.equal(s.getCurrentPlayer()-1,c.turn);A.deepEqual(Array.from(s.toNNInput(),bits),c.features_bits);A.deepEqual(Array.from(s.toNNInput()),r.features);A.deepEqual(api.terminalResult(s),null);
 const p=softmax(r.policy_logits,r.indices);let maxPrior=0;for(let i=0;i<p.length;i++){A(Math.abs(p[i]-r.priors[i])<=1e-4+1e-4*Math.abs(r.priors[i]));const j=c.raw_legal.indexOf(rustids[i]);A(j>=0);A(Math.abs(p[i]-c.raw_prior[j])<=1e-4+1e-4*Math.abs(p[i]));maxPrior=Math.max(maxPrior,Math.abs(p[i]-c.raw_prior[j]))}
 rows.push({id:c.id,legal:actions.length,raw_sigma136_matches_fixedJS:true,canonical_indices_matches_P2_permutation:true,rust209_injective:true,features648_matches_fixedJS:true,prior_softmax_checked:p.length,max_prior_abs:maxPrior,raw_canonical_equal:JSON.stringify(rawids)===JSON.stringify(canonical)});
}
fs.writeFileSync(OUT+'/independent-sigma-numeric.json',JSON.stringify({UTC:new Date().toISOString(),PID:process.pid,game_sha256:hash(game),context_sha256:hash(context),cases:rows,golden28_read_hash_only_no28NN_repeat:true,NN:0,extra_games:0},null,2));console.log(JSON.stringify({cases:rows.length,legal_priors:rows.reduce((a,x)=>a+x.legal,0),NN:0}));
