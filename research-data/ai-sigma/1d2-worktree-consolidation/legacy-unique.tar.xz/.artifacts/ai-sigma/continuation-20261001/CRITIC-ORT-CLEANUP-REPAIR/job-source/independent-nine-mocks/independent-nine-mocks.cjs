const fs=require('fs'),path=require('path'),A=require('assert/strict'),{spawn}=require('child_process');
const {OwnedProcesses,boundedStop,table}=require('./cleanup.cjs'),{pipe}=require('./pipe.cjs'),{guardTransaction,now}=require('./transaction.cjs'),E=require('./match-entry.cjs');
const OUT=path.resolve(__dirname,'..'),checks=[],owned=[],delay=ms=>new Promise(r=>setTimeout(r,ms));
const save=()=>fs.writeFileSync(OUT+'/independent-mock-summary.json',JSON.stringify({UTC:new Date().toISOString(),checks,passed:checks.length,owned,NN:0,games:0},null,2));
const check=(name,detail)=>{checks.push({name,pass:true,...detail});save()};
const owner=name=>new OwnedProcesses({tracePath:OUT+'/mock-'+name+'-trace.jsonl'});
(async()=>{
 // 1: starttick must bind signals. Foreign parent intentionally uses mismatching identity; signal spy proves no call.
 const mismatch=owner('identity'),parent=table().get(process.ppid);mismatch.ids.set(parent.pid,parent.starttick+1);
 const actualKill=process.kill,calls=[];process.kill=(pid,sig)=>{calls.push({pid,sig});throw Error('NO_KILL_ALLOWED_IN_MISMATCH_CASE')};
 try{mismatch.signal('SIGTERM');A.equal(mismatch.scan(true).length,0);A.equal(calls.length,0)}finally{process.kill=actualKill;mismatch.finish()}
 check('PID-starttick mismatch excludes foreign parent',{calls:0});
 // 2: actual detached TERM-ignoring child must require KILL; repeated stop returns same Promise.
 const det=owner('detached');const child=det.observeChild(det.register(spawn(process.execPath,['-e','process.on("SIGTERM",()=>{});console.log("READY");setInterval(()=>{},1000)'],{detached:true,stdio:['ignore','pipe','pipe']})));
 await new Promise(r=>child.stdout.once('data',r));const bt={owner:det,stop:()=>new Promise(()=>{})},promise=boundedStop(bt);A.equal(promise,boundedStop(bt));const dp=await promise;
 A.equal(dp.remaining_pids,0);A.equal(dp.forced,true);A.equal(child.signalCode,'SIGKILL');A.equal(det.scan(true).length,0);owned.push(...dp.tracked);check('detached TERM-ignore KILL exit idempotent PID0',{proof:dp,exitCode:child.exitCode,signalCode:child.signalCode});
 // 3: an already signalled direct handle must never wait for a second exit.
 const p=pipe(process.execPath,['-e','console.log("{}");setInterval(()=>{},1000)'],OUT+'/mock-pipe.stderr');await p.next();p.child.kill('SIGTERM');await new Promise(r=>p.child.once('exit',r));A.equal(p.child.exitCode,null);A.equal(p.child.signalCode,'SIGTERM');
 await Promise.race([Promise.all([p.close(),p.abort(),p.close(),p.abort()]),delay(300).then(()=>{throw Error('SIGNALLED_HANDLE_HUNG')})]);check('already signalCode exited repeated close abort bounded',{signalCode:p.child.signalCode});
 // 4: naturally exited handle drains correctly; forced=false.
 const no=owner('natural'),nc=no.observeChild(spawn(process.execPath,['-e','process.exit(0)']));await new Promise(r=>nc.once('exit',r));const np=await boundedStop({owner:no,stop:async()=>({remaining_pids:0})});A.equal(np.remaining_pids,0);A.equal(np.forced,false);check('naturally exited handle',{proof:np,exitCode:nc.exitCode});
 // 5: real Z must be included until the self runner adopts and waits it; state absent is required.
 const zo=owner('zombie'),zp=zo.observeChild(zo.register(spawn('python3',['-B','-c','import os,time\np=os.fork()\nif p==0: os._exit(0)\nprint(p,flush=True)\ntime.sleep(60)'],{stdio:['ignore','pipe','pipe']})));
 const zpid=Number(await new Promise(r=>zp.stdout.once('data',x=>r(x.toString().trim()))));await delay(60);zo.scan();const before=table().get(zpid);A.equal(before.state,'Z');A(zo.scan(true).some(x=>x.pid===zpid));
 const proof=await boundedStop({owner:zo,stop:()=>new Promise(()=>{})});A.equal(proof.remaining_pids,0);A.equal(table().has(zpid),false);owned.push(...proof.tracked);check('actual zombie tracked then adopted-only wait absence',{zombie_before:before,proof});
 // 6: synthetic permanent Z is a negative; no process is signalled and no fresh start allowed.
 let fresh=0;const residual={record:()=>{},scan:incl=>incl?[{pid:0,starttick:0,synthetic:true,state:'Z'}]:[],signal:()=>{throw Error('FAKE_SIGNAL')},drain:async()=>{},finish:()=>{}};
 await A.rejects(boundedStop({owner:residual,stop:async()=>({remaining_pids:0})}).then(()=>fresh++),/OWN_CLEANUP_FAILED/);A.equal(fresh,0);check('permanent residual rejects fresh',{fresh:0,synthetic:true});
 // 7: a pending cleanup with no ownership proof cannot claim PID0.
 await A.rejects(boundedStop({stop:()=>new Promise(()=>{})}),/BOUNDED_CLEANUP_NO_OWNERSHIP_PROOF/);check('pending no-ownership stop rejected');
 // 8: public watchdog responds while cleanup remains pending; no checkpoint or rescued action.
 let abortCalls=0;const start=now(),r=await guardTransaction({engine:'candidate',req:{request_id:'self-mock-watchdog',generation:1},t0:start,T:5,send:()=>new Promise(()=>{}),abort:()=>{abortCalls++;return new Promise(()=>{})}});
 A.equal(r.transaction_error,'NO_RESPONSE_TIMEOUT');A.equal(r.discarded,true);A.equal(abortCalls,1);A.equal(r.cleanup_status,'pending; reuse forbidden');check('public watchdog refuses while cleanup pending',{result:r});
 // 9: original actual_go=false manifest rejects before real backend; no acceptance mock is authority.
 const token={issue:'quoridor-4lc.47',actual_run:true,critic_accepted:true,coordinator_thread:'01a0f31b-3409-75f2-a30e-453a50484f94',critic_issue:'quoridor-4lc.9999',freeze_token:'self-no-go'};process.env.SIGMA_MATCH_FREEZE_TOKEN=token.freeze_token;
 A.throws(()=>E.verifyToken(token,OUT+'/old-preregister.json',OUT+'/entry-manifest.json'),/ACTUAL_RUN_NOT_AUTHORIZED/);delete process.env.SIGMA_MATCH_FREEZE_TOKEN;check('actual_go false refuses backend entry');A.equal(checks.length,9);save();console.log(JSON.stringify({passed:9,NN:0,games:0}));
})().catch(e=>{fs.writeFileSync(OUT+'/independent-mock-failure.json',JSON.stringify({error:e.message,stack:e.stack,checks},null,2));console.error(e);process.exitCode=1});
