'use strict';const fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto'),CP=require('child_process');
const O=__dirname,E=require('./source/match-entry.cjs'),M=require('./source/mock-factory.cjs'),sha=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex'),save=(n,x)=>fs.writeFileSync(O+'/'+n+'.json',JSON.stringify(x,null,2));
process.env.SIGMA75_DIAGNOSTIC_TOKEN='critic76-diagnostic-only-no-freeze';
function base(id,purpose='mock'){return {purpose,issue:'quoridor-4lc.75',goal:'quoridor-4lc',freeze_token:process.env.SIGMA75_DIAGNOSTIC_TOKEN,run_id:id,actual_go:purpose==='actual',preregister_sha256:sha(O+'/preregister.json'),entry_manifest_sha256:sha(O+'/entry-manifest.json')}}
function token(name,x){const f=O+'/'+name+'.json';fs.writeFileSync(f,JSON.stringify(x));return f;}
async function main(){
 const cases=[];
 for(const d of [400,411,800]){
  const clock=M.virtualClock(),ledger=[],factory=async o=>{if(o.session===2)await new Promise(r=>clock.delay(d,r));return M.factory('reference_timeout',ledger)(o)},file=token('factory-'+d,base('CRITIC76-FACTORY-'+d));
  const r=await E.diagnosticMockMain({argv:['--diagnostic',file],createBackend:factory,clock,deadline:Infinity,forecast:{NN0mock:2097152},diagnosticRequests:[{id:'first',engine:'candidate',legal_prefix:[]},{id:'second',engine:'reference',legal_prefix:[],fresh:true}]});
  const pub=r.events.filter(x=>x.kind==='public');assert.equal(pub.length,2);assert.equal(pub[1].response.t0_ms,pub[0].response.stamp_ms);assert.equal(pub[1].response.elapsed_ms,pub[1].response.stamp_ms-pub[1].response.t0_ms);
  if(d>411){assert.equal(pub[1].response.action,null);assert.equal(pub[1].response.elapsed_ms,411);assert(r.events.some(x=>x.kind==='late_factory_cleanup'&&x.value?.handles===0));}
  cases.push({delay:d,publics:pub.map(x=>({elapsed:x.response.elapsed_ms,accepted:x.response.accepted,error:x.response.error})),lateCleanup:r.events.filter(x=>x.kind==='late_factory_cleanup'),unrecovered:r.unrecovered_preparations});
 }
 const dir=O+'/diagnostic-verifier';fs.mkdirSync(dir);const t=base('CRITIC76-ACTUAL-DIAGNOSTIC','actual');
 fs.writeFileSync(dir+'/acceptance.json',JSON.stringify({diagnostic_only:true,real_acceptance:false,subject_issue:'quoridor-4lc.75',review_issue:'quoridor-4lc.76'}));
 const proof={actual_go:true,issued_by:'diagnostic-only-not-acceptance',entry_manifest_sha256:sha(O+'/entry-manifest.json'),preregister_sha256:sha(O+'/preregister.json'),dictionary_sha256:sha(O+'/prefix-dictionary.json'),critic_acceptance_sha256:sha(dir+'/acceptance.json'),independent_issue:'quoridor-4lc.75',run_id:t.run_id};fs.writeFileSync(dir+'/freeze.json',JSON.stringify(proof));t.coordinator_freeze_sha256=sha(dir+'/freeze.json');const file=token('positive-diag-actual',t),entry=O+'/source/match-entry.cjs';
 const run=args=>CP.spawnSync(process.execPath,[entry,...args],{env:process.env,encoding:'utf8',timeout:15000});const positive=run(['--diagnostic-verifier',file]);save('positive-diag-CLI',{status:positive.status,stdout:positive.stdout,stderr:positive.stderr,NN:0});assert.equal(positive.status,0,positive.stderr);
 const sum=JSON.parse(fs.readFileSync(O+'/diag-'+t.run_id+'/summary.json'));assert.equal(sum.table.length,64);assert.equal(sum.score.completed_pairs,32);assert.equal(sum.dry,true);assert.equal(sum.actual_go,false);assert.equal(sum.actual_games,0);assert.equal(sum.holdout_sends,0);
 const again=run(['--diagnostic-verifier',file]);assert.equal(again.status,1);assert(again.stderr.includes('RUN_ALREADY_EXISTS'));
 const actual=run(['--run',file]);assert.equal(actual.status,1);assert(actual.stderr.includes('ACTUAL_GO_FALSE_NEW_FREEZE_REQUIRED'));
 const missing=run(['--run']);assert.equal(missing.status,1);save('CLI-negatives',{existing:again.stderr,diagnostic_proof_real_actual:actual.stderr,missing:missing.stderr,NN:0});
 const actualDriver=fs.readFileSync(O+'/source/actual-driver.cjs','utf8'),pause=require('./source/pause-check.cjs');assert(!actualDriver.includes('startMonitor'));let observed;try{pause.checkPause()}catch(e){observed=e.message;}assert.equal(observed,'UNREADY');
 let creates=0;const rejected=await E.diagnosticMockMain({argv:['--diagnostic',token('actual-control-diag',base('CRITIC76-ACTUAL-CONTROL'))],createBackend:async()=>{creates++;throw Error('SHOULD_NOT_START')},clock:M.virtualClock(),control:{pause:()=>{try{pause.checkPause();return false;}catch{return true;}}},deadline:Infinity,forecast:{NN0mock:2097152}}).catch(e=>({verifier_error:e.message}));
 // Same execute guard and exact actual-driver pause callback, isolated NN0 mock token.
 assert.equal(rejected.stopReason,'PAUSED');assert.equal(creates,0);
 const source=fs.readFileSync(O+'/source/match-entry.cjs','utf8');assert(source.includes('dry:true,actual_go:false')&&source.includes('actual_games:0,holdout_sends:0'));
 save('phaseA-independent-summary',{UTC:new Date().toISOString(),watchdog_cases:cases,diagnostic_actual_CLI_64_complete:true,positive_existing_refused:true,real_actual_diagnostic_proof_refused:true,actual_result_flags_unconditional:true,actual_source_pause_monitor_not_initialized:true,pause_module_initial_error:observed,actual_driver_failclosed_guard_expected:'PAUSED before factory',actual_real_positive_freeze_not_issued_or_executed:true,proof_subject_fixed75_review_semantic_field_not_validated:true,NN:0,Chromium:0,actual_go:false,go:false,reason:'mandatory actual audit flags and monitor initialization not suitable for actual run; positive diagnostic is not real acceptance'});
 console.log(JSON.stringify({watchdog:cases.length,diagnostic64:sum.score.completed_pairs,no_go:true,NN:0}));
}
main().catch(e=>{save('own-check-failure',{error:e.message,stack:e.stack});console.error(e);process.exitCode=1});
