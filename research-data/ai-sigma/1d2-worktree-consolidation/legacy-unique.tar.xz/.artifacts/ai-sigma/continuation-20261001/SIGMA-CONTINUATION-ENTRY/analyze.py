import json,math,struct,hashlib
from pathlib import Path
R=Path('/workspaces/quoridor/.worktree/ai-sigma');B=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-CONTINUATION-ENTRY'
def read(p):return json.loads(p.read_text())
def write(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
fx={f['id']:f for f in read(R/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json')['fixtures']};refs={f['id']:f for f in read(R/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json')};pr=read(B/'diagnostic-preregister.json')
versions=['GOLDEN-CALIBRATION-01','GOLDEN-CALIBRATION-CONTINUATION-01','GOLDEN-PILOT-01','GOLDEN-FINAL-01','GOLDEN-FINAL-BOUNDARY-REPAIR-01','GOLDEN-SEAL-01'];runs={v:B/'diagnostic'/('golden-execution-'+v) for v in versions};rows={v:read(d/'requests.json') for v,d in runs.items()};cal=rows[versions[0]]+rows[versions[1]]
expected=[(f,e,s) for f in pr['calibration']['fixtures'] for e in ['candidate','reference'] for s in [-1,0,1,2,3,4]]
assert [(r['id'],r['engine'],r['sample']) for r in cal]==expected
assert all(r['accepted'] is True and r['nn_calls']==1 for r in cal)
# Exact feature bits and pre-fixed mixed NN gate. No NN execution in this checker.
fails=[];cases=[];nn_count=feature_bits=prior_count=0;nn_max=prior_max=0
pawn_perm=[1,0,2,3,6,7,4,5]
def perm(i):
 if i<8:return pawn_perm[i]
 b=8 if i<72 else 72;a=i-b;return b+(7-a//8)*8+a%8
for version,rr in rows.items():
 for k,r in enumerate(rr):
  n=r.get('diagnostic_numeric_root')
  if not n:continue
  f=fx[r['id']];ref=refs[r['id']];fb=[struct.unpack('<I',struct.pack('<f',x))[0] for x in f['raw_features_float32']];actual=n.get('features_bits') or [struct.unpack('<I',struct.pack('<f',x))[0] for x in n['features']]
  if actual!=fb:fails.append({'v':version,'k':k,'gate':'feature bits'})
  logits=n['policy_logits'];value=n['value'];expected_nn=ref['policy_logits']+[ref['value']];actual_nn=logits+[value]
  if len(logits)!=136 or not math.isfinite(value) or not -1<=value<=1:fails.append({'v':version,'k':k,'gate':'shape/range'})
  for i,(a,e) in enumerate(zip(actual_nn,expected_nn)):
   delta=abs(a-e);nn_max=max(nn_max,delta)
   if not math.isfinite(a) or delta>1e-4+1e-4*abs(e):fails.append({'v':version,'k':k,'i':i,'gate':'mixed NN','delta':delta})
  nn_count+=len(actual_nn);feature_bits+=len(actual);pcomp=0
  if r['engine']=='candidate':
   cp=r['raw']['payload']['payload']['data']['checkpoint'];got={e[0]:e[1] for e in cp['root_edges']};expected_priors={x['canonical136']:x['prior'] for x in ref['canonical_legal_priors']};legal={a['rust209']:a for a in f['legal_actions']}
   if set(got)!=set(legal):fails.append({'v':version,'k':k,'gate':'root legal set','got':list(got),'expected':list(legal)})
   for aid,p in got.items():
    a=legal[aid];idx=perm(a['sigma136']) if f['board']['turn']==1 else a['sigma136'];e=expected_priors[idx];delta=abs(p-e);prior_max=max(prior_max,delta);pcomp+=1
    if not math.isfinite(p) or p<0 or delta>1e-4+1e-4*abs(e):fails.append({'v':version,'k':k,'gate':'prior','action':aid,'delta':delta})
   if abs(sum(got.values())-1)>1e-5:fails.append({'v':version,'k':k,'gate':'prior normalization'})
  cases.append({'version':version,'sample_index':k,'id':r['id'],'engine':r['engine'],'features':len(actual),'NN':len(actual_nn),'prior':pcomp});prior_count+=pcomp
write('numeric-summary.json',{'cases':cases,'feature_f32bit_comparisons':feature_bits,'NN_elements':nn_count,'candidate_prior_comparisons':prior_count,'NN_max_abs':nn_max,'prior_max_abs':prior_max,'failures':fails,'threshold':'abs<=1e-4+1e-4*abs(ref)','no_new_NN':True,'source/calibration_versions_separate':True})
assert not fails, fails[:3]
# One operation means the measured synchronous/non-divided API or NN interval;
# never a simulation count or global inclusive total. Preserve warm samples too.
op_kinds={'root','begin_feature_request','NN','resume_policy_backup','root_restore','legal','feature','NN_validate'};finish_kinds={'finish_owned_copy','finish'};ops=[];finish_transport=[];clock_errors=[];drift=[];warm=[]
for version,d in runs.items():
 for p in d.glob('session-*/clock-calibration.json'):
  start=read(p);ep=p.parent/'clock-calibration-end.json';end=read(ep) if ep.exists() else None
  for e in ['page','candidate','reference']:
   clock_errors.append(start[e]['error_ms'])
   if end:
    clock_errors.append(end[e]['error_ms']);a=start[e];b=end[e];drift.append({'version':version,'session':p.parent.name,'engine':e,'mid_delta_ms':b['offset_ms']-a['offset_ms'],'interval_overlap':max(a['lo_ms'],b['lo_ms'])<=min(a['hi_ms'],b['hi_ms']),'start':a,'end':b})
  startup=read(p.parent/'startup.json');sp=startup['browser']['candidate'].get('startup_warm_spans',[])
  for x in sp:
   if x['kind'] in op_kinds:ops.append({'version':version,'sample':'startup_warm','engine':'candidate','kind':x['kind'],'ms':x['end']-x['start']})
  w=read(p.parent/'reference-warm.json')['response'];
  for x in w.get('telemetry',[]):ops.append({'version':version,'sample':'startup_warm','engine':'reference','kind':x['kind'],'ms':x['end']-x['start']})
for version in versions[:2]:
 d=runs[version];start=read(d/'session-1/clock-calibration.json')
 for k,r in enumerate(rows[version]):
  ss=r.get('diagnostic_spans') or [];fin=0
  for x in ss:
   duration=x['end']-x['start']
   if x['kind'] in op_kinds:ops.append({'version':version,'sample_index':k,'id':r['id'],'engine':r['engine'],'warmup':r['warmup'],'kind':x['kind'],'ms':duration})
   if x['kind'] in finish_kinds:fin=max(fin,duration)
  raw=r['raw']['payload'];engine_end=raw['time']['finish'] if r['engine']=='reference' else raw['payload']['data']['adapter_end_ms'];tail=max(0,r['received_after_validation_ms']-(engine_end-start[r['engine']]['offset_ms']));finish_transport.append({'version':version,'sample_index':k,'finish_max_ms':fin,'delivery_transport_ms':tail,'total_ms':fin+tail})
maxop=max(ops,key=lambda x:x['ms']);maxtail=max(finish_transport,key=lambda x:x['total_ms']);maxerr=max(clock_errors);g=math.ceil(maxop['ms']+maxtail['total_ms']+maxerr+5)
# A resource-deadline truncated first segment is not a completed uniform calibration.
clock_candidate_numerical=g<=91<=125;uniform=False;eligible=False
write('clock-summary.json',{'fixed_formula':'ceil(max_nondivided_op + maxfinish_transport + maxclockerror +5)','max_nondivided_op':maxop,'max_finish_transport':maxtail,'max_clock_error_ms':maxerr,'g_needed_ms':g,'fixed_g_ms':91,'fixed_T_ms':500,'numerical_formula_gate':clock_candidate_numerical,'uniform_full_run_gate':uniform,'clock_eligible':eligible,'reason':'first calibration job120 failed; 62 original +82 fixed remaining different monitoring/t0 source; no completed uniform final-source 144 gate; no large repeat authorized','warm_included':True,'operation_observations':ops,'finish_transport_observations':finish_transport,'start_end_drift':drift,'missing_end_windows':[v for v in versions[:2] if not (runs[v]/'session-1/clock-calibration-end.json').exists()],'unknown_at_cutoff_NN_calls':True,'finite_tail_guarantee':False})
pilot=rows['GOLDEN-PILOT-01'];assert len(pilot)==36 and all(r['accepted'] is True and r['fallback']==0 and not r['late'] for r in pilot)
final=rows['GOLDEN-FINAL-BOUNDARY-REPAIR-01'];assert len(final)==9 and sum(r['accepted'] for r in final)==6
assert all(r['action'] is None and r['checkpoint'] is False for r in final if r['accepted'] is False)
assert final[5]['nn_calls']==final[6]['nn_calls']==0
assert final[7]['elapsed_ms']>=500 and final[8]['elapsed_ms']>=500
write('validation-summary.json',{'calibration_saved_planned144':144,'original_source_saved':62,'remaining_final_source_saved':82,'original_job_failed_preserved':True,'pilot_requests':36,'pilot_accepted':36,'pilot_max_elapsed_ms':max(r['elapsed_ms'] for r in pilot),'final_requests':9,'final_accepted':6,'final_rejects':[{k:r.get(k) for k in ['engine','error','action','checkpoint','elapsed_ms','overshoot_ms','nn_calls']} for r in final if not r['accepted']],'goal_NN0':True,'cleanup_PID0_fresh_prior_boundary_source':True,'final_seal5_cleanup_complete':False,'final_seal5_response_count':5,'final_seal_final_cleanup_error':'OWN_CLEANUP_FAILED','clock_eligible':eligible,'actual_go':False,'all_new_actual_games_holdout':0})
print(json.dumps({'numeric_failures':len(fails),'g_needed':g,'maxop':maxop['ms'],'maxtail':maxtail['total_ms'],'maxerr':maxerr,'clock_eligible':eligible,'pilot36':True,'final9':True}))
