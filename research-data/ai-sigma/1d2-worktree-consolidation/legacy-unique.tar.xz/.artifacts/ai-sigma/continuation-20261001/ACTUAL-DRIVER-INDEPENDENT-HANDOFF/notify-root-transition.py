import asyncio,importlib.util,pathlib,json,datetime
ROOT=pathlib.Path('/workspaces/quoridor');OUT=ROOT/'.worktree/ai-sigma/.artifacts/ai-sigma/continuation-20261001/ACTUAL-DRIVER-INDEPENDENT-HANDOFF'
spec=importlib.util.spec_from_file_location('team',ROOT/'scripts/dev/research-team.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
async def main():
 with m.dispatch_lock(ROOT):
  m.require_issue('quoridor-4lc',ROOT)
  host=m.command_json(['codex','app-server','daemon','version'])
  async with m.AppServer(host,timeout=20) as s:
   tid='01a0f2e9-357d-7ef3-a2fe-b16f80accda5';t=await s.read_thread(tid)
   if t['status']['type']!='active':
    print('METADATA_PENDING_ROOT_NOT_ACTIVE');return
   r=await s.deliver(tid,(OUT/'root-phase2-admission.md').read_text(),None)
   r['UTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['scope']='metadata-only coordination with active external root; no research-role start'
   (OUT/'root-transition-metadata-delivery.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
asyncio.run(main())
