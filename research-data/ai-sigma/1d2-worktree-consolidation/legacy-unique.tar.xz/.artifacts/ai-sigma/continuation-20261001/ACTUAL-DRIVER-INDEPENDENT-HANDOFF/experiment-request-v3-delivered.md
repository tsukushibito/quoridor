現行77版3の実依頼。87独立NN0有限支持を受入れ、停止版2を保全したまま、同課題の診断NN接続を次の現在許可枠で確認する。新評価/WDL/holdout/go許可ではない。

# SIGMA-ACTUAL-BOUNDARY-REPAIR / quoridor-4lc.77 / 現行契約版3

担当experiment 01a0f31d-6d15-7620-bb63-4b4f878e4746。未完了の同課題を現在の許可枠でNN0デバッグする実依頼。親正本 docs/design/ai-sigma-continuation-20261001.md/common/docs/development/ai-research-experiments.md全文を継承。終了Oct2 01:00UTC/重job00:50/監督00:55/watch00:58、CPU4/RAM8/globalLLM3/cum12GiB/GPU0不変。旧77各runの期限/guard965697536>896MiB/失敗/NN未実施は保持し、当時を成功や延長へ書き換えない。同じ課題/コード/入力を新runとして再確認できる。

問い: 旧76に拒否されたactual監視未開始/typed期限/purpose監査/proof意味結合の最小経路を、旧77のguard設定不足を修正して同actual-driver経由で確認できるか。許可write ownerは既tools/ai-sigma-actual-boundary-repair/、既SIGMA-ACTUAL-BOUNDARY-REPAIR/の新run出力、docs/reports/ai-sigma-experiment-actual-boundary-repair.md。旧ログ/結果は保持、コード/文書版はローカルGitで管理。全sourcecopy/新issue/全履歴hash/一原因一修正/一窓を標準にしない。必要な既83 guardian/currentRSS/PPID/race処理を参照/必要差分で再利用可、83 source自体は変更しない。製品main/push/共有role/registry/config/model/workerNNkernel/探索規約編集0。

現在の追加配分（契約版3、版2NN0 runは停止/87独立受入れ済）: CPU2単logical/NNthreads1、RAM3GiB/currentRSSguard2.5GiB、run180秒/新NN実job累計最大300秒、NN以外の安い設定確認はCPU0。新配分の処理は受領15分と00:40UTC早い方、新jobは処理5分前まで、提出は受領25分と00:45早い方。版2受領/期限/NN0/結果は不変、新しい現在の許可で新runを管理する。既77 entry2GiB内128MiB/guard112予約のみ、今回追加run保存は16MiB以下を目安・追加予約0。run前にheadroom/current他重NN0/guardian/currentRSS/必要schemaを確認。旧peak/累積課金減額0。所有根拠/boot/PIDstarttick/TMP/XDG/UV3変数/unknown拒否は維持。Chromiumと固定ORT/tract/model-loadをgolden診断に必要な範囲で許可する。build/取得/学習/GPU/実対局/holdout送信/製品/モデル変更/委譲は0。

最初にNN0 guardian currentRSS/PPID/TMP消失race/owned child停止を安く確認。既sourceの誤りを修正し、同actual-driver→startMonitor→READY→execute→factory/mock public→stopを一貫した最小診断にする。monitorと全読取callback/子の停止を保存、UNREADY/PAUSED/PROCESSING_DEADLINE/BEADS_READ_ERRORをtypedに区別。real時のpurpose/dry/actual_go/counterは送信事実に基づき、人工診断はdiagnostic=trueと実NN/game/holdout0を明記。subject77/別review/coordinator issuer/bundleのtyped意味検査、旧/foreign/expired/diagnostic proofのreal CLI拒否を確認する。正人工proofはdiagnostic namespaceだけ、realのfreeze/acceptanceを自己発行しない。

必須検査は小さいsame-driver正診断と拒否枝・typed理由/停止/counter/proofbindingに限定。旧64全mock/全項目/全history auditを機械的反復しない。検査器/設定/通信の普通の修復はこの総予算内で反復可、版/run/失敗と修正版結果を分ける。原因不明で情報が増えない反復は追加診断/別案/中止を担当が判断する。最小経路が動いたら停止してGit版と必要結果を固定し、主張に必要な独立確認へ渡す。完了しなければ未完了として次判断を返す。版3の診断NN接続を許可する。最初に同actual-driverのgolden modeが、この契約/診断controlのNN許可・preregisterとbundleを検査する最小修正を行う。NN0契約のproofでgolden起動できず、real --runは診断proofを拒否することを小NN0で確認する。実評価用real freeze/acceptanceを自分で発行しない。モードはdiagnostic=true/actual_go=false、実backend dispatch/NN呼出しと実games/holdout0を正確に分ける。NN0-only拒否を無条件削除して任意実行を許可しない。

新runの結果前条件を保存して、固定golden最大5publicをsame actual-driver→監視READY→実factory→caller→final Judge/UTF8/stamp→stopへ通す: initial candidate正常、initial reference正常、candidate完成cp後cancel、合法goal candidate、合法goal reference。この順序/全5分母を保持し、初回無し/late/null/停止失敗/未実施を記録する。両engineのstartup initial/asym-P2/jump-P2 root1NN×2=6/sessionを別分母で記録し木/history/cacheを持ち込まない。pool/m48/m32/holdoutを一切送らない。固定5上限は残時間と必要経路の診断範囲による。普通の設定/検査器/接続修復を同許可総予算内で再確認できるが、修正版run・失敗を別に記録し良い結果だけを正式成績へ採用しない。成功した最小版を停止して独立87へ渡す。

T500/89/9/402/411、両thread1/CPU2、candidate PUCT1.5Q0/既caps/RuleA/seed1979/tie/finish、reference C1FPU.2/temp0/order/root sim規約は不変。最終Judge/UTF8後stamp/finish/次t0=前stamp、旧ACK/準備/stop費は逃がさない。rootの数値/特徴/合法順/P2/Action prior/finite/strict[-1,1]は固定混合閾値。共有NN/Kernelの探索・モデルを改変しない。終端NN0とstartup/深部呼出しを分ける。同期NN割込み/OS硬締切や棋力を主張しない。回収欠測はfresh禁止、モデルdrop/全監視callback/owned子の停止を保存。actual_go=false/entry_ready未認定。

ready/show goal/self・pauseと本人割当確認、受領/開始を記録。全文権限は現在の本文が正本。本文前に自己runtime/monitor/子停止を保存、再現command・Git/run・開始終了・必要結果/エラーとログ参照、各currentRSSとcurrentabsenceの限界を記録。backup/report→coordinator。83はdocs/reports/ai-sigma-coordinator-nn83-84-acceptance.mdの有限支持と残未確認を本人notesに残してclose可。77/goalは受入れ前close0。他者close0。旧32局/NI未立証/棋力/Sigma未達、旧WDL/prereg/m48m32no-go/深いtree等の未確認は不変。
