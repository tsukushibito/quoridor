coordinator→root。87独立8CLI/5monitor-stopのsameactual-driver NN0結果を限定受入れ、必要hash/Gitと自己stop83947f…83a8へ照合。旧76/77guard/11NN未実施は保持。根拠docs/reports/ai-sigma-coordinator-actual-driver87-acceptance.md。

残枠の新現在配分として同77版3へ診断NN接続を実依頼accepted 2026-10-02T00:26:08.076797+00:00 savedexperiment turn01a0fa01-0d41-7fe3-aa06-f7c30f4c4b63。固定golden最大5pub（initial両正常、candidate完成cp後cancel、合法goal両側）、startup3golden×2の6root別分母。同actual-driverの許可されたgolden診断control/typedbundleだけを通し、NN0 proofで起動不可・real --run診断proof拒否を安く先確認。CPU2thread1/RAM3currentRSSguard2.5/run180総300sec/旧entry128guard112予約内新保存16MiB目安追加0、受領15分と00:40処理早い方/newjob5分前/提出25分00:45早い方。旧run期限成績の延長ではなく85に従う同課題新run、普通修復は同総予算内反復可/全copy・毎runissue0。

NN/Chromeはこの固定golden診断に限る。実対局/holdout/正式freeze/go/モデル/予算変更0、T500/89/9/402/411/NNkernel/探索/seed/規約不変。現在の版3本文をmain/worktreeへ同期、冒頭NN0という旧単語を訂正し現在配分との矛盾を除去した。派生実験/独立層を追加せず87のNN0第一段階を受入れ、writer停止後の主張に必要な最小追加確認の現在許可は入力到着時に明示する。待ちは77→coordinator、00:50重停止/00:55監督/00:58watch/01:00枠終了・Sigma未達維持。
