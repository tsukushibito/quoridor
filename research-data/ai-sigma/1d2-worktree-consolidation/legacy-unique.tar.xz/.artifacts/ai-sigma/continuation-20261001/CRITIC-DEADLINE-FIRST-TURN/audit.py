import asyncio,importlib.util,json,hashlib,os,time,datetime,resource
from pathlib import Path
base=Path('/workspaces/quoridor/.worktree/ai-sigma'); out=Path(__file__).resolve().parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x): (out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
report=base/'docs/reports/ai-sigma-critic-deadline-first-turn.md'
report.write_text('# SIGMA-DEADLINE-TURN-CRITIC / quoridor-4lc.55\n\n暫定: 正確turn・本文・90/120/180 gateは検証中。新turn/NN/運用変更0。受入れは保留。\n')
start=now(); selfstat=Path('/proc/self/stat').read_text().split(); identity={'pid':os.getpid(),'start_ticks':selfstat[21],'affinity':sorted(os.sched_getaffinity(0)),'command_sha256':sha(Path(__file__)),'started_at':start}
save('command-start.json',identity)
root=base/'.artifacts/ai-sigma/continuation-20261001'; sd=root/'SIGMA-DEADLINE-UPDATE'; run=root/'supervisor/f765f753-b6b0-4200-887d-bb5c1353eac2/read-guard'
paths=list(sd.glob('*.json'))+list(sd.glob('before-*'))+list(run.glob('*'))
paths += [base/'docs/design/ai-sigma-contract-critic-deadline-first-turn.md',base/'docs/design/ai-sigma-continuation-20261001.md',base/'docs/reports/ai-sigma-steward-deadline-20261002.md',root/'scheduler/scheduler.json',root/'scheduler/contract.json',root/'scheduler/prompt.md',base/'tools/ai-sigma-scheduler-deadline-update/watch.py',root/'DEADLINE-20261002-1000/actual-reflection-root-check.json',root/'DEADLINE-20261002-1000/nogo-evidence-receipt.json',Path('/workspaces/quoridor/scripts/dev/research-team.py')]
paths=[p for p in paths if p.is_file()]; before={str(p):sha(p) for p in paths}; save('input-before.json',before)
contents={str(p.relative_to(base)) if p.is_relative_to(base) else str(p):p.read_text() for p in paths if p.suffix in ('.json','.jsonl')}
save('saved-input-snapshots.json',contents)
for n in ['state.json','events.jsonl']:
 p=root/'scheduler'/n
 if p.exists():save('live-'+n.replace('.jsonl','.json'),{'snapshot_at':now(),'path':str(p),'contents':p.read_text()})
s=importlib.util.spec_from_file_location('team','/workspaces/quoridor/scripts/dev/research-team.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
async def rpc():
 host=m.command_json(['codex','app-server','daemon','version'])
 async with m.AppServer(host,timeout=15) as server:
  page=await server.request('thread/turns/list',{'threadId':'01a0f6b5-b1bd-7752-b0bb-74a336e459a4','limit':5,'itemsView':'full','sortDirection':'desc'})
  exact=[t for t in page['data'] if t['id']=='01a0f7a6-2a74-7261-b384-b0b4f707b9ed'];assert len(exact)==1
  save('exact-turn-full.json',exact[0]);return {k:exact[0].get(k) for k in ['id','status','itemsView','durationMs','startedAt','completedAt']}
try: result=asyncio.run(rpc());save('rpc-result.json',result)
except Exception as e:result={'error':str(e)};save('rpc-result.json',result)
manifest=json.loads((sd/'report-manifest.json').read_text());checks=[]
for name,expected in manifest.get('evidence',{}).items():
 p=sd/name;checks.append({'path':str(p),'expected':expected,'actual':sha(p) if p.exists() else None})
checks += [{'path':p,'expected':v,'actual':sha(Path(p))} for p,v in json.loads((sd/'after.json').read_text())['input_hashes'].items()]
save('manifest-checks.json',checks)
procobs=[]
for pid in [1209155,1209164]:
 try:
  st=Path(f'/proc/{pid}/stat').read_text().split();procobs.append({'pid':pid,'at':now(),'start_ticks':st[21],'state':st[2],'affinity':sorted(os.sched_getaffinity(pid))})
 except FileNotFoundError:procobs.append({'pid':pid,'at':now(),'absent':True})
save('live-identities.json',procobs)
after={str(p):sha(p) for p in paths};save('input-after.json',after)
stop={'at':now(),'identity':identity,'exit_code':0,'remaining_owned_children':[],'persistent_children_started':0,'rss_peak_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'changed_inputs':[p for p in before if before[p]!=after[p]],'scope_bytes':sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'source_write_stopped':True,'processing_stopped':True,'later_work':'saved evidence analysis/report only','initial_shell_reads_pid_rss_missing':True}
save('runtime-stopped.json',stop); print(json.dumps({'rpc':result,'files':len(paths),'manifest_checks':len(checks),'mismatches':sum(c['actual']!=c['expected'] for c in checks),'stop':stop},ensure_ascii=False))
