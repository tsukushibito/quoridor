from pathlib import Path
import json,hashlib,math,struct,datetime,resource,os
ROOT=Path('/workspaces/quoridor/.worktree/ai-sigma');RUN=ROOT/'.artifacts/ai-sigma/runs/SIGMA-ORT-ENTRY-CONTINUE';OUT=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
def bits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
def finite(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)
def mixed(a,b):return abs(a-b)<=1e-4+1e-4*abs(b)
fixtures={f['id']:f for f in load(ROOT/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json')['fixtures']}
refPath=ROOT/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json';ref={x['id']:x for x in load(refPath)}
assert hashlib.sha256(refPath.read_bytes()).hexdigest()=='060ba1a3f7647adb7c0ac968eb2834d966665920f72eeee2b3798ce9864b382a'
num=load(RUN/'diagnostic/real-golden/numeric-raw.json');result={'feature_bits':0,'NN_elements':0,'prior_elements':0,'max_NN_abs':0,'max_prior_abs':0,'cases':[]}
assert len(num['wasm'])==len(num['reference'])==3
for c,r in zip(num['wasm'],num['reference']):
 assert c['id']==r['id'];f=fixtures[c['id']];oracle=ref[c['id']]
 assert len(c['features_bits'])==len(r['features'])==648
 expected=[bits(x) for x in f['raw_features_float32']];assert c['features_bits']==[bits(x) for x in r['features']]==expected
 assert all(finite(x) for x in r['features']);result['feature_bits']+=1296
 assert len(c['logits'])==len(r['policy_logits'])==136 and len(oracle['policy_logits'])==136
 assert finite(c['value']) and finite(r['value']) and -1<=c['value']<=1 and -1<=r['value']<=1
 for values in [c['logits']+[c['value']],r['policy_logits']+[r['value']]]:
  for a,b in zip(values,oracle['policy_logits']+[oracle['value']]):assert finite(a) and finite(b) and mixed(a,b);result['max_NN_abs']=max(result['max_NN_abs'],abs(a-b));result['NN_elements']+=1
 assert r.get('fallback')==0 and not r.get('error');assert len(r['priors'])==len(r['indices'])==len(f['legal_actions'])
 mapped={a['rust209']:r['priors'][i] for i,a in enumerate(f['legal_actions'])}
 assert c['effective_legal']==c['raw_legal'] and set(c['raw_legal'])==set(mapped)
 for a,b in zip(c['raw_legal'],c['raw_prior']):assert finite(b) and b>=0 and mixed(b,mapped[a]);result['max_prior_abs']=max(result['max_prior_abs'],abs(b-mapped[a]));result['prior_elements']+=1
 result['prior_elements']+=len(r['priors']);result['cases'].append(c['id'])
assert (result['feature_bits'],result['NN_elements'],result['prior_elements'])==(3888,822,386)
groups=[('original32',RUN/'diagnostic/real-golden/all-responses.json',32),('supplement5',RUN/'diagnostic/golden-execution-FIXED-GOLDEN-MAIN-01/requests.json',5),('final5',RUN/'diagnostic/golden-execution-FIXED-GOLDEN-MAIN-OWNED-WAIT-01/requests.json',5),('critic-incomplete3',OUT/'diagnostic/golden-execution-FIXED-GOLDEN-MAIN-OWNED-WAIT-01/requests.json',3)]
counts=[]
for name,p,n in groups:
 rows=load(p);assert len(rows)==n;accepted=0;errors=[];summary=[]
 for r in rows:
  assert type(r['accepted']) is bool and r['engine'] in ('candidate','reference') and r['request']['seed']==1979
  assert r['request_id']==r['request']['request_id'] and r['generation']==r['request']['generation']
  assert finite(r['received_after_validation_ms']) and finite(r['t0_ms']) and finite(r['T_ms'])
  assert r['elapsed_ms']==r['received_after_validation_ms']-r['t0_ms'];assert r['final_validation_and_serialization_before_stamp'] is True
  if r['accepted']:
   accepted+=1;assert r['error'] is None and r['fallback']==0 and r['checkpoint'] is True and r['legal'] is True and r['owned_binding'] is True
   assert r['received_after_validation_ms']<r['t0_ms']+r['T_ms']
   env=r['raw']['payload'];tx=env['transaction'];req=r['request']
   for k in ['request_id','generation','engine','prefix','legal_prefix','seed','simulations','max_nodes','max_depth','T_ms','g_ms']:assert tx[k]==(r['engine'] if k=='engine' else req[k])
   assert env['generation']==r['generation']
   f=fixtures[r['id']];assert r['request']['legal_prefix']==f['legal_prefix']
   if r['terminal'] is not None:assert r['action'] is None and r['nn_calls']==0
   else:assert r['action'] in [a['rust209'] for a in f['legal_actions']]
   if r['engine']=='candidate':
    data=env['payload']['data'];cp=data['checkpoint'];base={k:v for k,v in cp.items() if k!='spans'};assert base==data['owned']['cp']==data['original_checkpoint']
    edges=cp['root_edges'];assert all(len(e)==4 and all(finite(v) for v in e) and e[1]>=0 and type(e[2]) is int and e[2]>=0 and abs(e[3])<=e[2]+1e-4*max(1,e[2]) for e in edges)
    if r['terminal'] is None:assert abs(sum(e[1] for e in edges)-1)<1e-5
  else:assert r['action'] is None and r['checkpoint'] is False;errors.append(r['error'])
  summary.append({k:r.get(k) for k in ['engine','id','accepted','action','nn_calls','error','elapsed_ms','T_ms','g_ms']})
 counts.append({'version':name,'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'requests':n,'accepted':accepted,'rejected':n-accepted,'errors':errors,'rows':summary})
assert [(x['requests'],x['accepted']) for x in counts]==[(32,28),(5,4),(5,4),(3,2)]
result.update(groups=counts,threshold_unchanged=True,gate='abs<=1e-4+1e-4abs(ref)',source_versions_not_pooled=True,failures=0,UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),checker_PID=os.getpid(),checker_maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
(OUT/'independent-arithmetic.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['feature_bits','NN_elements','prior_elements','max_NN_abs','max_prior_abs','failures']}))
