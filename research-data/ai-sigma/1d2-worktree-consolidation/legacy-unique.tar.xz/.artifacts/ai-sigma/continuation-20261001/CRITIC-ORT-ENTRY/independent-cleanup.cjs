'use strict';
const fs=require('fs'),A=require('assert/strict'),{spawn}=require('child_process'),{OwnedProcesses,boundedStop}=require('./stage/cleanup.cjs'),{pipe}=require('./stage/pipe.cjs');
const O=__dirname,rows=[];
(async()=>{
 const owner=new OwnedProcesses(),child=owner.register(spawn(process.execPath,['-e','process.on("SIGTERM",()=>{});console.log("ready");setInterval(()=>{},100)'],{stdio:['ignore','pipe','ignore'],detached:true}));
 await new Promise(r=>child.stdout.once('data',r));const backend={owner,stop:()=>new Promise(()=>{})};const proof=await boundedStop(backend);A.equal(proof.remaining_pids,0);A.equal(await boundedStop(backend),proof);A.equal(child.signalCode,'SIGKILL');rows.push({gate:'own detached TERM-ignore→KILL/wait/idempotent',proof,signalCode:child.signalCode});
 const p=pipe(process.execPath,['-e','setInterval(()=>{},100)'],O+'/dummy-pipe.stderr');await p.abort();await p.abort();await p.close();A(p.child.signalCode);rows.push({gate:'already signalCode exited abort/close repeated',pid:p.child.pid,signal:p.child.signalCode});
 const child2=spawn(process.execPath,['-e','console.log("finished")'],{stdio:'ignore'});await new Promise(r=>child2.once('exit',r));A.equal(child2.exitCode,0);rows.push({gate:'natural completion contrast',pid:child2.pid,exit:child2.exitCode});
 fs.writeFileSync(O+'/independent-cleanup-summary.json',JSON.stringify({rows,synthetic_only:true,real_backend_fresh_still_unverified:true,real_NN:0},null,2)+'\n');console.log(JSON.stringify({gates:rows.length,real_NN:0}));
})().catch(e=>{fs.writeFileSync(O+'/independent-cleanup-failure.json',JSON.stringify({error:e.message,stack:e.stack,rows}));console.error(e);process.exitCode=1});
