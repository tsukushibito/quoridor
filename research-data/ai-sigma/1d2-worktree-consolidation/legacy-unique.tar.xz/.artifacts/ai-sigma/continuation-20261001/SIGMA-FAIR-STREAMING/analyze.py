
from pathlib import Path
import json,math,statistics,datetime,struct
B=Path(__file__).resolve().parent;ROOT=B.parents[3];fixtures={f['id']:f for f in json.load(open(ROOT/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json'))['fixtures']};refs={r['id']:r for r in json.load(open(ROOT/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json'))}
def summary(xs):
 z=sorted(xs);return {'n':len(z),'p50':statistics.median(z) if z else None,'p95_nearest_rank':z[math.ceil(.95*len(z))-1] if z else None,'max':max(z) if z else None,'min':min(z) if z else None}
def canon(k,p2):
 if not p2:return k
 if k<8:return [1,0,2,3,6,7,4,5][k]
 off=8 if k<72 else 72;z=k-off;return off+(7-z//8)*8+z%8
windows={}
for name in ['SUITE65-01','SUITE65-02']:
 rows=json.load(open(B/name/'public-requests.json'));assert len(rows)==36;private=json.load(open(B/name/'private-diagnostics-after-public.json'));stops=json.load(open(B/name/'search-stop-events.json'));sm={s['identity']['request_id']:s for s in stops};clock=json.load(open(B/name/'browser/clock-start.json'));out=[];numeric_n=feature_n=prior_n=0;max_num=max_prior=0;minimum_NN_after_ACK=None
 for i,r in enumerate(rows):
  p=r['public'];ident=p['request_id'];e=r['spec']['engine'];f=fixtures[r['spec']['fixture']];q=private.get(ident);cache=r['private_cache'];pub=json.loads(p['public_json']);assert pub['engine']==e and pub['action']==p['action'] and pub['checkpoint']==p['checkpoint'];assert p['fallback']==0
  if i:assert p['t0_ms']==rows[i-1]['public']['stamp_ms']
  if p['late']:assert p['action'] is None and not p['checkpoint']
  for bind in r['bindings']:
   if bind['accepted'] and bind['kind']=='snapshot':assert bind['last_gate']['validation_finished_ms']<p['t0_ms']+402
  inrun=0;slack=None
  if q:
   assert q['identity']['engine']==e
   if cache:assert q['identity']['key']==cache['identity']['key'] and q['identity']['history']==cache['identity']['history']
   for n in q.get('numeric',[]):
    bits=[struct.unpack('<I',struct.pack('<f',v))[0] for v in f['raw_features_float32']];assert n['features_bits']==bits;feature_n+=648;assert len(n['policy_logits'])==136
    for a,z in list(zip(n['policy_logits'],refs[f['id']]['policy_logits']))+[(n['value'],refs[f['id']]['value'])]:assert math.isfinite(a) and abs(a-z)<=1e-4+1e-4*abs(z);max_num=max(max_num,abs(a-z));numeric_n+=1
    assert abs(n['value'])<=1
   for span in q.get('NN',[]):
    start=span['session_run_start_ms']-clock['worker']['lo_ms'];end=span['session_run_end_ms']-clock['worker']['hi_ms'];inrun+=start<=p['stamp_ms']<end
   if i and q.get('NN'):
    j=i-1
    while rows[j]['spec']['request_id'] not in sm:
     prev=rows[j];assert prev['public']['late'] and prev['spec']['request_id'] not in private and not prev['bindings'];j-=1
    predecessor=rows[j]['spec']['request_id'];nnstart=q['NN'][0]['awaiter_start_ms']-clock['worker']['hi_ms'];slack=nnstart-sm[predecessor]['node_received_ms'];assert slack>=0,(ident,slack);minimum_NN_after_ACK=slack if minimum_NN_after_ACK is None else min(minimum_NN_after_ACK,slack)
  if p['checkpoint']:
   assert cache and cache['identity']['engine']==e and cache['producer_identity']==cache['identity'];c=cache['owned']['cp'];assert c['policy_fallbacks']==0 and c['value_fallbacks']==0 and abs(cache['value'])<=1
   if c['terminal_value'] is None:
    assert p['action'] in [a['rust209'] for a in f['legal_actions']];assert sum(x[2] for x in c['root_edges'])==(c['simulations'] if e=='reference' else c['simulations']-1)
    if e=='reference':assert c['root_visits']==c['simulations']+1 and p['action']==max(c['root_edges'],key=lambda x:x[2])[0]
    pm={a['canonical136']:a['prior'] for a in refs[f['id']]['canonical_legal_priors']};am={a['rust209']:a['sigma136'] for a in f['legal_actions']}
    for a,pr,vis,val in c['root_edges']:
     z=pm[canon(am[a],f['board']['total_ply']%2==1)];assert math.isfinite(pr) and abs(pr-z)<=1e-4+1e-4*abs(z);prior_n+=1;max_prior=max(max_prior,abs(pr-z))
   else:assert p['action'] is None and p['completed_NN']==0 and (not q or not q.get('NN'))
  out.append({'id':ident,'engine':e,'kind':r['spec']['kind'],'fixture':f['id'],'sample':r['spec'].get('sample'),'elapsed_ms':p['elapsed_ms'],'late':p['late'],'action':p['action'],'checkpoint':p['checkpoint'],'error':p['error'],'public_completed_sims':p['completed_simulations'],'public_completed_NN':p['completed_NN'],'actual_NN_attempts':q.get('result',{}).get('calls') if q else 0,'actual_completed_NN':len(q.get('NN',[])) if q else 0,'API_run_in_progress_at_delivery':bool(inrun),'snapshot_age_ms':p['snapshot_age_ms'],'stop_wait_ms':r['old_search_wait_ms'],'adapter_start_gap_ms':r['root_context_started_ms']-p['t0_ms'],'NN_after_ACK_conservative_slack_ms':slack,'validation_encoding_ms':p['final_validation_encoding_ms'],'public_bytes':p['public_bytes']})
 stats={}
 for e in ['candidate','reference']:
  n=[r for r in out if r['engine']==e and r['kind']=='normal'];steady=[r for r in n if r['sample']>=0];stats[e]={'normal':summary([r['elapsed_ms'] for r in n]),'normal_eligible':sum(r['checkpoint'] and not r['late'] for r in n),'steady':summary([r['elapsed_ms'] for r in steady]),'steady_eligible':sum(r['checkpoint'] and not r['late'] for r in steady),'normal_API_in_progress':sum(r['API_run_in_progress_at_delivery'] for r in n),'public_completed_simulations':summary([r['public_completed_sims'] for r in n]),'actual_NN_complete_normal':sum(r['actual_completed_NN'] for r in n),'normal_snapshot_age':summary([r['snapshot_age_ms'] for r in n if r['snapshot_age_ms'] is not None]),'cancel_next_wait_ms':[r['stop_wait_ms'] for j,r in enumerate(out) if j and out[j-1]['kind']=='cancel-next' and r['engine']==e]}
 windows[name]={'rows':out,'stats':stats,'normal_planned':24,'boundary_planned':12,'normal_eligible':sum(v['normal_eligible'] for v in stats.values()),'numeric_features_bits':feature_n,'numeric_output_elements':numeric_n,'public_prior_elements':prior_n,'numeric_max_abs':max_num,'prior_max_abs':max_prior,'root_numeric_gate_failures':0,'all_receiver_commit_before_cutoff':True,'NN_nonoverlap_ACK_gate':True,'min_conservative_NN_after_ACK_slack_ms':minimum_NN_after_ACK,'stop_ACKs':len(stops),'clock_drift':json.load(open(B/name/'clock-drift.json')),'model_drop':json.load(open(B/name/'handle-drop.json')),'normal_finite_clock_gate':sum(v['normal_eligible'] for v in stats.values())==24,'actual_go':False}
(B/'analysis.json').write_text(json.dumps({'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'windows':windows,'no_window_pooling':True,'original_normal_failure_retained':True,'whole_period_or_tail_guarantee':False,'formal_no_contention':False,'API_interval_not_kernel_instruction_interval':True,'all_gates_independent_acceptance_pending':True,'games':0,'holdout_send':0,'actual_go':False},indent=2)+'\n');print(json.dumps({w:{'stats':d['stats'],'numeric_bits':d['numeric_features_bits'],'numeric_elements':d['numeric_output_elements'],'priors':d['public_prior_elements'],'stopACKs':d['stop_ACKs'],'NN_after_ACK_slack':d['min_conservative_NN_after_ACK_slack_ms']} for w,d in windows.items()},indent=2))
