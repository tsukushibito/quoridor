
from pathlib import Path
import subprocess,json,os,datetime,resource
B=Path(__file__).resolve().parent;T=B.parents[3]/'tools/ai-sigma-fair-streaming';p=B/'suite-token-repair.json';tok=json.load(open(p));rows=[]
for name,args,value,want in [('actual_run',['--run',str(p)],None,'EXPLICIT_DIAGNOSTIC_TOKEN_REQUIRED'),('missing',['--diagnostic','suite',str(p)],None,'EXPLICIT_FROZEN_TOKEN_REQUIRED'),('wrong',['--diagnostic','suite',str(p)],'WRONG','EXPLICIT_FROZEN_TOKEN_REQUIRED'),('existing',['--diagnostic','suite',str(p)],tok['freeze_token'],'RUN_ALREADY_EXISTS'),('old-source-token',['--diagnostic','suite',str(B/'suite-token-revision2.json')],json.load(open(B/'suite-token-revision2.json'))['freeze_token'],'EXPLICIT_FROZEN_TOKEN_REQUIRED')]:
 e=os.environ.copy();e.pop('SIGMA_FAIR_DIAGNOSTIC_TOKEN',None)
 if value:e['SIGMA_FAIR_DIAGNOSTIC_TOKEN']=value
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();q=subprocess.Popen(['node',str(T/'entry.cjs'),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=e)
 try:z=Path('/proc')/str(q.pid)/'stat';s=z.read_text().rsplit(')',1)[1].split();tick=int(s[19])
 except FileNotFoundError:tick=None
 out,err=q.communicate(timeout=15);assert q.returncode!=0 and want in err,(name,q.returncode,err);rows.append({'name':name,'PID':q.pid,'starttick':tick,'startUTC':start,'endUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':q.returncode,'stderr':err,'expected':want,'NN':0,'waited':True})
(B/'entry-refusal-gates.json').write_text(json.dumps({'pass':True,'NN':0,'actual_go':False,'rows':rows,'child_maxRSS_KiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss},indent=2)+'\n');print('entry refusal5 passed')
