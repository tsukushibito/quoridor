
from pathlib import Path
import json,struct,math
B=Path(__file__).resolve().parent;R=B.parents[3];old=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL/NN-SUITE-63-01';F={f['id']:f for f in json.load(open(R/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json'))['fixtures']};ref={r['id']:r for r in json.load(open(R/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json'))};rows=[];cp=bits=nn=prior=0
for name in ['initial-p1','asym-hv-p2','straight-jump-p2']:
 q=json.load(open(old/('control-'+name+'.json')));d=q['direct'];s=q['stream'];f=F[name];assert d['identity']['key']==s['identity']['key'] and d['identity']['history']==s['identity']['history'];assert d['result']['cp']==s['result']['cp'];assert len(s['result']['trace'])==8
 for a,z in zip(d['result']['trace'],s['result']['trace']):assert a['cp']==z['cp'];cp+=1
 expected=[struct.unpack('<I',struct.pack('<f',v))[0] for v in f['raw_features_float32']];maxn=maxp=0
 for x in [d,s]:
  n=x['numeric'][0];assert n['features_bits']==expected;bits+=648;assert len(n['policy_logits'])==136 and abs(n['value'])<=1
  for a,z in list(zip(n['policy_logits'],ref[name]['policy_logits']))+[(n['value'],ref[name]['value'])]:assert math.isfinite(a) and abs(a-z)<=1e-4+1e-4*abs(z);maxn=max(maxn,abs(a-z));nn+=1
  values={a[0]:a[1] for a in x['result']['cp']['root_edges']};pm={a['canonical136']:a['prior'] for a in ref[name]['canonical_legal_priors']}
  for a in f['legal_actions']:
   k=a['sigma136']
   if f['board']['total_ply']%2:
    if k<8:k=[1,0,2,3,6,7,4,5][k]
    else:off=8 if k<72 else 72;z=k-off;k=off+(7-z//8)*8+z%8
   z=pm[k];v=values[a['rust209']];assert math.isfinite(v) and 0<=v<=1 and abs(v-z)<=1e-4+1e-4*abs(z);maxp=max(maxp,abs(v-z));prior+=1
 rows.append({'fixture':name,'saved_cp8_exact':True,'history_key_exact':True,'max_numeric_abs':maxn,'max_prior_abs':maxp})
(B/'saved-candidate24-control-gate.json').write_text(json.dumps({'pass':True,'exact_cp_tree_history_stats':cp,'features_bits':bits,'NN_elements':nn,'prior_elements':prior,'rows':rows,'control_NN_rerun':0},indent=2)+'\n');print('saved24 '+str(bits)+' bits/'+str(nn)+' NN/'+str(prior)+' priors passed')
