研究統括から新 .63 の実装・判別実依頼。独立 .62 の有限完成cache支持/全体時計late反証を受入れ、現方式は対局no-go。.59は docs/reports/ai-sigma-coordinator-streaming-independent-acceptance.md の限定理由で本人close可、旧失敗/未成立/時計no-goは保持。新copyで最終callerへの先行cacheと早いseal、検証終了cutoffを具体化して実測してください。通常詳細判断は担当に委任します。NN最大guardだけの対応に限定せず、配送に必要な検証は省略しません。

# SIGMA-STREAMING-EARLY-SEAL / quoridor-4lc.63 / 試行1・契約1

experiment 01a0f31d-6d15-7620-bb63-4b4f878e4746 → coordinator。親継続版2 docs/design/ai-sigma-continuation-20261001.md SHA6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f 全文継承。終了Oct2 01:00UTC/重job00:50/監督00:55、CPU4/RAM8GiB/LLM3/累積12GiBを維持。ユーザーの随時snapshot経路実装・独立検証要求と通常詳細委任に基づく新実依頼。ready/show/pause後本人claim、受領起点処理65分/提出80分、新job処理締切5分前に打切り、親期限の早い方。旧期限/失敗/事前登録を遡及延長しない。

問いは、完成cpの検証終了cutoffと最終callerへの先行公開・早いsealにより、推論完了を待たずに全時計T内へ着手を配送できるか。独立.62は最終revision5の正常9/9が受信時点で既late（median572.419/max659.396ms）、NN0終端もlate、検証開始D−.1/終了D＋.1でもcache受理を再現した。単に全NN最大値をguardへ足す経路には限定しない。旧.59 revision2/5と.62はread-only、原方式のnegativeを修正後成功へ付け替えない。

write ownerはexperimentのみ。新 tools/ai-sigma-streaming-early-seal/、.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-EARLY-SEAL/、docs/reports/ai-sigma-experiment-streaming-early-seal.md。元.59/.62/Wasm/model/NNkernel/PUCT1.5/Q0/seed1979/RuleA/tie/finish/caps/通常製品/rootlock/共有環境/旧報告は編集しない。新copyは最終.59 revision5と独立.62の反証を入力としてhash固定。追加compile/build/依存取得/モデル取得/学習/GPU/対局/holdout送信/委譲/未知他者killは禁止。

実装の要件は次の二点。まず検証を完了した時刻で再確認し、cutoff後のcpをcacheへcommitしない。検証途中に期限/世代/faultが変わった枝、旧結果の破壊、partial/mutable/out-of-orderの反証を行う。次に着手を消費する最終callerが完成cacheを保持し、NN/Worker照会や大きい診断trace配送を待たずにseal/合法性・identity・型確認/必要なencoding/最終stampを完了する。Nodeを共通審判callerに使う診断なら、browser内のsealだけを最終配送とせず、先行snapshot通知でNode側にも検証済み結果を置く等の方式を具体化する。postMessage/Playwright binding等の方式と必要な小さい公開payloadは担当判断で選び、原cpとの整合を独立に検査可能な証拠を残す。必要な検証費を時計外へ追い出して速度を作らない。大きいtree/trace等の診断専用出力は最終着手の公開後に別保存してよいが、公開に必要な検証は省略しない。

immutable入力供給可能・変換前の共通t0から、最終callerで合法性/依頼・局面世代/型・finite/strictvalue/encodingを完了したstampまでをTとする。page/Worker別時計は開始/終了pingと誤差・driftを保存、早側deadlineへ変換する。T500msを本診断に固定。timer早起きは再確認、lateは公開Action=null/checkpoint=false、救済0。caller timer/通知/copy/検証/輸送/encodingに余裕を残す早いseal/cutoffを選び、NN0代表payloadの校正方法・warm/steady分母・reserve算式・固定margin・選定一回・失敗時停止をNN結果の前に事前登録する。reserveはNN最大値に依存させず、結果を見て追加変更しない。reserve>=Tや時計校正欠測はno-go。旧g91/.57のg<=T/4等は旧対照規約として保持し、特定方式の効率基準と目標必須条件を混同しない。本診断の新reserveで旧対局や旧計画を実行しない。

初回完成cp無しはNO_COMPLETED_SNAPSHOT/null/false、新fallback0。終端はgoal優先/200ply/no-legal draw・NN0。seal前に受信したhardfault/cancelは要求全discard。seal後の遅延通知/旧epoch/faultで既sealを遡及変更しない.59の受信順政策を明示し、その政策とProducer内faultの時刻を区別する。未知の生成時刻を正常だったと主張しない。返却NNerror→fault通知、取消/期限後の旧結果拒否、全identity/prefix/key/history/model/schema/limits/token/sequenceのbinding、完成resume/backup後のimmutable cpだけ公開する条件を保持する。

先にNN0の単位/mocked-clockで検証D跨ぎ（開始前/同時/後・終了前/同時/後）、caller deadline中の不正/遅配/先後fault・busy、初回無し、偽binding/token、既run/token拒否を検査。mockの合法な暫定手を本NN成功へ混ぜない。実Node合法検証は正しいfixture.legal_prefixを使用し、missing field/array/非合法prefix/Actionをfail-closedにする。.62の実gate失敗をoffline修正で遡及成功扱いにしない。

実NN前に固定反復と全分母を登録。候補の通常固定3golden（initial-p1/asym-hv-p2/straight-jump-p2）各warm1+steady3の12要求、goal/人工ply200のNN0終端2、重要境界を各一度・最大6（初回無し/検証跨ぎ/主側busy/遅配/故障/取消と次要求）を上限とする。厳密な要求一覧と前提を結果前固定し、全suite/成立標本の救済再試行0。cpと固定direct controlのaction/tree/history/stats対応・648features/137NN・prior混合gateabs1e-4+rtol1e-4/strict[-1,1]は先に検査。可能な実ORT session.run開始/終了（出力検証を除く）を追加計測し、awaiter spanと内核実行の正確な時刻を区別する。実ORTが進行中のcaller seal/配送と人工busyは別集計、前提未成立は未成立とする。terminal含む全t0→最終stamp、cp完了/送信/受信/検証完了/decisionの鮮度、public/private、実NN完了/sim/fallback/late/欠測を全件保存する。

seal後は旧世代を直ちに無効化。旧NN残処理と次手の同CPU競合・停止費を隠さない。次入力が利用可能なら次t0をcleanup終了まで遅らせず、旧処理待ちも課金する。次NNは旧探索停止/handle解放の明示証拠後だけ開始し、同Worker/Modelを保持するならNN非重複・旧context不使用を検査する。Worker強制終了/再起動が必要なら旧所有PID/starttickのcontrolled回収後にfresh、load/warm/reclock費は別欄と該当時計へ記録。sole-root/subreaper/kernel adoption・自己identityのみwait/signal・absence1000ms/共有drain100msは維持し、未知所有/回収失敗時freshは禁止。forcedと自然終了、Nodeと外側scopeの回収を分ける。

参照と比較する場合には両AIへ同じt0/T/caller cache-seal/CPU2/thread1/RAM/通知頻度・残処理費を適用する案を具体化する。固定Sigma-WebのC1/FPU.2/temp0/列挙順/root展開sim外を変えず、候補の自己結果だけで公平性を認定しない。本契約は候補単手診断まで。参照の実NN探索/公開方式変更は次契約の独立gate対象、対局は新事前登録/統括freeze以前禁止。

CPU準備/静的0または2（NN中の並行静的処理なし）、runtime2単logical/NNthreads1、RAM4GiB guard3.5、新128MiB guard112は既entry2GiB予約内、追加予約0。旧hyp/critic/entry台帳/累積12GiBを減額/リセットしない。既cache/モデルは読取参照、専用TMP/XDG、全job<=240秒、PID/starttick/command/hash/exit/20-50ms RSS/storage/affinityを保存。今回RAM全体8GiB/global3/CPU4維持、他重NN停止を確認。失敗は原因別一修正を許すが、既結果の再測定/有利試行は追加しない。

runtime/source-stop/hashafter/資源を文書より先に保存。受入れはcaller機構・全時計適格・政策・所有回収を分け、独立受入れ前actual_go=false。重要原入力/旧失敗/未成立・.60容量障害・真合法200/no-legal/一般rawview/entropy/深部/来歴/training overlap/旧32局NI未立証を保持。書込停止後pause/backup/report、受入れ待ちin_progress、goal/他者close0。通常の配分・詳細は委任内で進めるが採用/棋力/正式速度/目標達成を認定しない。


親全文:
# Sigma自律研究・継続枠 2026-10-01

契約版2。目標quoridor-4lc。統括01a0f31b-3409-75f2-a30e-453a50484f94。根拠はユーザーの明示継続/詳細委任（root入力01a0f2e9-357d-7ef3-a2fe-b16f80accda5）。開始2026-10-01T09:03:36.459834+00:00、終了2026-10-02T01:00:00Z（2026-10-02 10:00 JST）。本書は新しい実行枠であり、旧目標契約版2の初期04:00終了/未達/過去逸脱を保持する。旧文書・旧preregister・成績は変更しない。目標/比較A/通常製品規約維持/独立検証/権限は旧目標契約を継承する。

固定Sigmaと同計算資源・思考時間でnative/localおよびbrowserの非劣性を実測する。旧32局m8のnative.5625/browser.1875と両下限未達を保持。今回の新比較はcode/model/config/pool/T/g/m/CI/停止/責任分類を結果前に別事前登録し、旧結果へ後付け条件変更/標本統合をしない。未使用m10計画は参考として残すが、実入口/共通時計/資源gateと新deadlineを独立freezeするまで対局禁止。

予算はCPU全計4logical、RAM全計8GiB、LLM最大3（統括と新supervisorを含む）、正式CPU比較はCPU2単logical/推論threads1/GPU推論0/他の重い研究job停止。GPU研究は旧上限6GiB・1job30分・累積2h以内を保持し、今回は別配分前GPU/学習0。成果/依存は旧枠から累積12GiBを維持、リセット/12GiB追加ではない。旧限定保守課金6,588,000,723B・条件付き残6,296,901,165Bを開始時再確認する。初回新規予約: entry2GiB（guard1.75GiB）、steward128MiB、監督32MiB、統括文書32MiB。未配分は基準再確認後に統括が同12GiB内で配分。副次cache/途中展開/一時profileも計上。既存共有training/cacheは読取のみ、削除はこの枠が所有する再生成物だけを証拠保持の上で別に判断。

既存五役saved sessionを維持、新supervisorは既存App Serverに永続登録して観測専用で追加。App Server/toolchain再起動やモデル/effort変更をしない。新有料API/クラウド/第三者オンライン対局なし。主checkout製品/UI/描画/M2/commit/push/公開は対象外。研究worktreecodex/ai-sigmaで新copyに実装し旧入力をhashで固定。スケジューラーは主checkoutのpush済み操作入口を利用し、運用role定義/registry/専用configだけを用意する。

監督issuequoridor-4lc.40、20分周期/1turn180秒（新job120秒で停止し報告へ）、終了2026-10-02 00:55UTC、観測のみ。globalは3だがschedulerの起動閾値max_active_sessions=2として統括報告の起動1枠を残す。枠使用中はskipしsteerしない。変化なしは保存のみで静かに終了、意味ある停滞/失敗/期限資源/完了時にだけ統括へreportする。監督が設定や課題配分を変更しない。pause/終了はownedturnだけinterrupt確認し、外部jobは各ownerが回収する。dispatcherや監督の停止だけでNN停止を認定しない。

初回はquoridor-4lc.38stewardがscheduler準備/実運用/容量/資源台帳、quoridor-4lc.39experimentがORT入口・復旧gateを担当。途中から競合A共通tract/B分離ORT/C B0とH1backend/H2探索/H3時計・checkpoint/H4標本を更新し、通常判断は統括が実依頼する。別の選択が有望ならこの枠内で契約を作り替えるが、結果を見た正式判定緩和は行わない。

終了: 目標達成、ユーザーpause、上限/guard/異常、2026-10-02 01:00UTC。2026-10-02 00:50UTCまでに新重jobを止め、終了処理を確保する。全ownerはPID/starttick/command/hash/exit/資源/失敗/stopを先保存、報告は簡潔に詳細JSONへリンク。達成なら独立根拠で目標close、未達なら次の継続/停止理由を記録。予算を自動延長しない。各実行deadlineは本枠以下。担当へ実送信/受領をBeadsとdispatchに記録する。

継続委任は目標へ向けて継続する指示である。未達の場合は本枠終了前に統括が次枠の必要性/予算/検証を判断し、ユーザーへ通常詳細の再承認を求めず別契約として具体化できる。同一枠の期限や累積12GiBを黙って拡張しない。

## 契約版2の期限変更根拠

2026-10-01、操作元root 01a0f2e9-357d-7ef3-a2fe-b16f80accda5からユーザー明示指示を受領。「明日午前10:00」は2026-10-02T10:00:00+09:00 = 2026-10-02T01:00:00Z。開始時刻は維持し、旧継続枠終了2026-10-01T17:00:00Zから終了時刻だけ変更する。重い処理停止00:50UTC（09:50JST）、監督運用停止00:55UTC（09:55JST）、monitor回収00:58UTC、枠終了01:00UTC（10:00JST）。目標達成・pause・guard停止条件と時間以外のCPU/RAM/LLM/累積容量・許可範囲・独立検証は変更しない。

旧版SHA859bb777836cc0683e1ad7d1763a71fda60c75d2d6391290cef28771589a81a2を.artifacts/ai-sigma/continuation-20261001/DEADLINE-20261002-1000/continuation-version1.mdへ保全。閉じた実験や旧個別契約の処理/提出期限、事前登録、旧失敗/逸脱を遡及延長しない。新実験・比較は別契約で結果前に固定する。統括.52が正本/Beads、steward.53が既存所有範囲の運用契約/config/reload/monitor更新と実反映を担当する。


独立根拠/競合仮説全文:
{
  "issue": "quoridor-4lc.62",
  "trial": 1,
  "contract": 1,
  "independent_actor": "hypothesis/01a0f31c-2e4b-7170-82c5-69e1428c2418",
  "actual_go": false,
  "finite_support": [
    "revision5 cache can seal a previously completed immutable snapshot without awaiting pending host inference",
    "24 saved fixed cps match direct control cp/tree/history; final receiver offline parity26/26",
    "real revised Worker publishes returned generation-cancel fault after seal; observed retained sealed cache uses new policy",
    "strict host mock10 and cache mock30 pass; numeric9*137=1233 failures0; features9*648 exact"
  ],
  "refutations": [
    {
      "claim": "all-clock T500 delivery is eligible",
      "observation": "old6/6 and new normal9/9 late; receipt already late9/9; terminals late2/2 despite NN0"
    },
    {
      "claim": "receiver only commits fully validated cp before deadline",
      "observation": "controlled-clock receive at D-.1 and validation at D+.1 accepted=true"
    },
    {
      "claim": "final revised method retains old all-hardfault discard semantics",
      "observation": "after-seal returned cancel/error notification is ignored, cp retained; normative change must be separately frozen"
    }
  ],
  "unestablished": [
    "exact model.run start/end timestamps; nn_ms includes output checking",
    "new Node real-time legal acceptance (checker wrong prefix field); offline legality16/16, no retrospective timing acceptance",
    "formal fair match single CPU/no external load/tail guarantee",
    "deep arbitrary partial tree correctness from root-only checks; saved producer control equality finite only",
    "general hidden preseal producer fault with delayed notification; policy accepts receipt order, not omniscient producer fault order"
  ],
  "failures": [
    "static checker import API, expected.legal schema, mock digest corrected per distinct cause once; original files unchanged",
    "runtime driver legal_prefix_sigma missing: preserved, no established-NN replay",
    "preregister UTC_before_runtime literal15:22 differs actual job start15:20:10; tool call order and prereg digest establish content saved first; do not use literal as actual creation evidence",
    "CPU0 brief static reads overlapped CPU2 runtime; runtime TIDs allCPU2 but whole task simultaneous single logical compliance not established",
    "each static command PID/RSS and cumulative CPU ticks were not recorded; no fabricated zero"
  ],
  "cleanup": {
    "inner_forced": 16,
    "inner_natural_success": 0,
    "outer_exit0": 2,
    "current_PID0": true,
    "identities": 168,
    "historical_old_inner_missing_kept": true
  },
  "hypotheses": [
    {
      "id": "H3-caller-clock",
      "evidence": "seal timer waits until D then nonzero browser/Node delivery; NN0 terminals late",
      "prediction": "moving immutable cp seal to preregistered earlier budget leaves measurable delivery slack",
      "refutation": "same clock/preregistered earlier seal still late in NN0 path or measured transport larger than reserved guard",
      "minimum_next": "new contract fixes early seal/time budget and validation-end gate, then fixed golden and NN0 terminal single-hand only; no holdout",
      "cost": "small caller patch + bounded <=12 diagnostic requests, model ready; clock error included",
      "risk": "normative discard/fault policy and guard cannot be changed after outcomes"
    },
    {
      "id": "H1-nondivisible-host-infer",
      "evidence": "old wrapper crossings4/6, guaranteed host infer interval crossings3/6; new normal wrapper crossings8/9",
      "prediction": "checkpoint cache remains selectable while pending NN continues until generation observed",
      "refutation": "identity/ownership corruption or no completed cp under fixed ready workload",
      "minimum_next": "instrument exact model.run endpoints in separate frozen diagnostic copy, same cases, no search coefficient change",
      "cost": "small timing instrumentation, <=3 cases; NN execution must be newly authorized",
      "risk": "instrument overhead and same-CPU Worker scheduling, nn_ms not exact ORT interval"
    },
    {
      "id": "H2-notification-semantics",
      "evidence": "fault received before seal discards; delayed/postseal faults do not; validation straddle accepted",
      "prediction": "fault created before seal but notified after seal may leave public cp under new receipt-order policy",
      "refutation": "strict validation-finish cutoff and predeclared hardfault policy reject all such cp under adversarial queue",
      "minimum_next": "static arbitrary-clock and delayed fault mock, no NN, policy decided before runtime",
      "cost": "<45s Node mock plus separate policy decision",
      "risk": "cancellation vs genuine backend fault must stay distinct"
    },
    {
      "id": "H4-sampling",
      "evidence": "finite9 normal/7 boundaries, warm+steady included; old32 uncombined",
      "prediction": "tails and fair paired strength remain unknown",
      "refutation": "separately frozen uniform clock gates and formal NI sample support",
      "minimum_next": "only after independent clock/ownership gate, new preregistered native/browser contracts",
      "cost": "new deadline/sample/CI resources required",
      "risk": "cannot use diagnostics to alter m, old scores or NI margin"
    }
  ],
  "competitive_paths": [
    "A common tract",
    "B separate ORT streaming candidate under test",
    "C preserve B0"
  ],
  "games": 0,
  "holdout_send": 0,
  "goal_achievement": false,
  "adoption": false
}
