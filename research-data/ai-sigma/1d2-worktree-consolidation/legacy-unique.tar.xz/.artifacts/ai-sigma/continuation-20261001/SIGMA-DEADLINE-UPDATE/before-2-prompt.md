定期研究監督 quoridor-4lc.40 / goal quoridor-4lc。継続枠 docs/design/ai-sigma-continuation-20261001.md、supervisor role、docs/design/ai-sigma-contract-steward-supervisor-read-guard.md の90/120/180 gateを継承。旧32局・初回120秒gate不足・欠測・逸脱・目標未達を保持。観測専用、研究/配分/他issue/registry/role/config編集・NN/対局/取得/build/kill他者/委譲0。

最初の運用toolは下記の一括observeだけ。SCHEDULER_RUN_IDはこの依頼の先頭行の実UUIDへ置換する。既存契約は保存済み文脈を使い、先に別読取を増やさない。
UV_NO_SYNC=1 UV_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1 timeout 80s taskset -c 0 python3 -B /workspaces/quoridor/.worktree/ai-sigma/tools/ai-sigma-supervisor-read-guard/guard.py observe --run-id <SCHEDULER_RUN_ID>

guardは現在のscheduler-ownedのrun/turn/開始に固定、turn IDは自動照合（任意指定の不一致も拒否）。owned開始から90秒以降は新metadata command開始禁止、処理120秒前に自己child回収、180秒turn以内に終了。再呼出しで時計をresetしない。時刻/環境/affinity/PID/RSS標本/exitを supervisor/<runID>/read-guard/ に保存する。Go/cgoへ1GiB AS制限を継承しない。失敗/開始不明/期限拒否なら新規読取の迂回や再試行をせず、保存済み証拠で未成立として終了する。自己failure/stopの記録だけ可。

observeの保存済みready/issues（goal/.40/.38/.39/.41/.42）/sessions/runtimeから停滞・担当集中・期限資源・引渡しを点検する。追加ready/show/status、終盤の資料再取得、別toolでの新metadataは禁止。正常な実依頼/報告待ち・変化なしは保存のみで静かに終了しcoordinator通知0。意味ある停滞/失敗/期限資源/完了だけ保存済み根拠と次判断をcoordinatorへ返す。accepted、点検内容、全期間遵守、棋力達成は区別。

保存済み観測を基に短いnotesを用意し、できれば150秒前に下記finishを一度実行して自己.40 notes/backup/self-stopを保存する。新metadataを取得せず、guardの固定180秒締切と子timeoutを守る。自己.40は既claimなら維持、未claim/ownership異常時はguard失敗を保持し、遅いclaim/読取で回復しない。
UV_NO_SYNC=1 UV_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1 timeout 25s taskset -c 0 python3 -B /workspaces/quoridor/.worktree/ai-sigma/tools/ai-sigma-supervisor-read-guard/guard.py finish --run-id <SCHEDULER_RUN_ID>
必要なら --note に短い具体的な観測/判断を渡す（最大4096字）。finish失敗も自己command/回収証拠を保持、終了時刻やwhole-turn完了は外部App Server照合待ちとする。同期Beads内部読取/副次書込の限界を保持。

意味ある通知時だけ UV_NO_SYNC=1 UV_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1 を明示し、既存research-team.sh report --to coordinator --issue quoridor-4lc --body-file <自己runIDの報告絶対path> で180秒内に送る。報告は保存済み観測を使い、現在のpause確認は通信入口の検証に委ねる。報告枠不足/応答不明は未配送として保存、盲目的再送0。CPU0/RAM1GiB/新32MiB/global3維持、瞬間peakや他tool経路の強制隔離は未証明。

16:40以降は保存観測から終了責任/次枠契約の有無を統括へ一度通知。scheduler/watchの16:55停止はsteward .38、目標枠17:00。自動延長なし、次枠は統括が別契約にする。自身turn停止を外部研究job停止と認定しない。自.40/goal close0、終了後追加研究0。
