import os,sys,subprocess,json,time,resource,datetime,signal
from pathlib import Path
ROOT=Path('/workspaces/quoridor/.worktree/ai-sigma');OUT=ROOT/'.artifacts/ai-sigma/continuation-20261001/SIGMA-STREAMING-MATCH-PLAN';TOOL=ROOT/'tools/ai-sigma-streaming-matches';intake=json.loads((OUT/'intake.json').read_text());now=time.time();assert now<datetime.datetime.fromisoformat(intake['newjob_stop']).timestamp();name=sys.argv[1];assert not (OUT/(name+'.process.json')).exists();os.sched_setaffinity(0,{0});resource.setrlimit(resource.RLIMIT_RSS,(1073741824,1073741824));resource.setrlimit(resource.RLIMIT_CORE,(0,0));tmp=OUT/'temp';tmp.mkdir(exist_ok=True);env=os.environ.copy();env.update(TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),XDG_CACHE_HOME=str(tmp),XDG_CONFIG_HOME=str(tmp),UV_NO_SYNC='1',UV_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1');start=time.time();peak=0;identities={};error=None;stop=False
with (OUT/(name+'.log')).open('wb') as log:
 child=subprocess.Popen(sys.argv[2:],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while child.poll() is None:
  try:
   st=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split();tick=int(st[19]);rss=int(st[21])*4096+resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;peak=max(peak,rss);a=[]
   for t in Path(f'/proc/{child.pid}/task').iterdir():a.append(sorted(os.sched_getaffinity(int(t.name))))
   assert all(x==[0] for x in a),'AFFINITY';identities[child.pid]={'PID':child.pid,'starttick':tick,'TID_affinities':a,'command':sys.argv[2:]}
   used=sum(p.stat().st_blocks*512 for b in [OUT,TOOL] for p in b.rglob('*') if p.is_file());assert used<29360128,'STORAGE';assert rss<939524096,'RSS_GUARD';assert time.time()<min(start+45,datetime.datetime.fromisoformat(intake['processing_stop']).timestamp()),'DEADLINE'
  except Exception as e:error=str(e);child.terminate();stop=True;break
  time.sleep(.02)
 try:code=child.wait(timeout=2)
 except subprocess.TimeoutExpired:child.kill();code=child.wait(timeout=2);stop=True
remaining=[]
for pid,d in identities.items():
 try:
  s=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
  if int(s[19])==d['starttick']:remaining.append(d)
 except FileNotFoundError:pass
r={'startUTC':datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),'endUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':code,'guard_error':error,'forced':stop,'peak_observed_child_RSS':peak,'monitor_interval_ms':20,'instant_peak_not_guaranteed':True,'identities':list(identities.values()),'remaining':remaining,'PID0':not remaining,'CPU':0,'child_CPU_seconds_cumulative':resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime,'NN':0,'browser':0,'games':0};(OUT/(name+'.process.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(code)
