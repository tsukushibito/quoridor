quoridor-4lc.92 deadline scheduler停止。
詳細 /workspaces/quoridor/.worktree/ai-sigma/.artifacts/ai-sigma/continuation-20261001/SIGMA-RESUME-OPERATIONS-92/live-frame8-role120-5a468918-2139-4bcd-bed4-c4c19592da68/scheduler-end-stop.json。owned_turn_pending=True、scheduler_identity_alive=False。原因/読取欠測を保持、外部NN停止認定0。
