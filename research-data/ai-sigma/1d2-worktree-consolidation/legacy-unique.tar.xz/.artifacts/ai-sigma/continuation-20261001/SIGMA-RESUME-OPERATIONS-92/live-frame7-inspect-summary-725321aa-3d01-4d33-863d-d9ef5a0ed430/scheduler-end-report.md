quoridor-4lc.92 deadline scheduler停止。
詳細 /workspaces/quoridor/.worktree/ai-sigma/.artifacts/ai-sigma/continuation-20261001/SIGMA-RESUME-OPERATIONS-92/live-frame7-inspect-summary-725321aa-3d01-4d33-863d-d9ef5a0ed430/scheduler-end-stop.json。owned_turn_pending=False、scheduler_identity_alive=False。原因/読取欠測を保持、外部NN停止認定0。
