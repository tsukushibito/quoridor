quoridor-4lc.92 deadline scheduler停止。
詳細 /workspaces/quoridor/.worktree/ai-sigma/.artifacts/ai-sigma/continuation-20261001/SIGMA-RESUME-OPERATIONS-92/live-frame8-b03a3825-b373-4f4c-8e19-2390bdd141ea/scheduler-end-stop.json。owned_turn_pending=False、scheduler_identity_alive=False。原因/読取欠測を保持、外部NN停止認定0。
