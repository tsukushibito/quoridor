import json,pathlib,math,copy,datetime
P=pathlib.Path(__file__).resolve().parent.parent
p=json.loads((P/'preregister.json').read_text());s=p['calibration']['schedule'];checks=[];results=[]
assert len(s)==144 and [x['index'] for x in s]==list(range(144));assert sum(x['sample']=='case-warm' for x in s)==24 and sum(x['sample']=='steady' for x in s)==120
assert len(p['pilot']['schedule'])==24 and sum(x['sample']=='case-warm' for x in p['pilot']['schedule'])==6
for case in p['calibration']['fixture_ids']:
 for engine in ['candidate','reference']:
  a=[x for x in s if x['case_id']==case and x['engine']==engine];assert len(a)==6 and [x['repeat'] for x in a]==list(range(6))
checks.append('uniform144/warm24/steady120 and separate pilot24/warm6 exact denominators')
def synthetic_rows(O,F):
 return [dict(index=x['index'],sample=x['sample'],bundle='SYNTHETIC-ONLY-A',session=1,O=O,F=F,complete=True,late=False,error=None,started=1,completed=1,inflight=0) for x in s]
def select(rows,C,clock_complete=True):
 if len(rows)!=144 or sorted(x['index'] for x in rows)!=list(range(144)):return {'status':'NO-GO','reason':'missing/duplicate index','g_math':None,'T_math':None}
 if len({x['bundle'] for x in rows})!=1 or len({x['session'] for x in rows})!=1:return {'status':'NO-GO','reason':'nonuniform bundle/session','g_math':None,'T_math':None}
 if not clock_complete or C is None or not math.isfinite(C) or C<0:return {'status':'NO-GO','reason':'clock incomplete','g_math':None,'T_math':None}
 for x in rows:
  if not x['complete'] or x['late'] or x['error'] or any(x[k] is None for k in ['O','F','started','completed','inflight']):return {'status':'NO-GO','reason':'normal sample failed or count/metadata missing','g_math':None,'T_math':None}
  if not all(math.isfinite(x[k]) and x[k]>=0 for k in ['O','F']):return {'status':'NO-GO','reason':'negative/nonfinite duration','g_math':None,'T_math':None}
 g=math.ceil(max(x['O'] for x in rows)+max(x['F'] for x in rows)+C+5)
 T=next((T for T in [500,1000] if g<=T/4),None)
 return {'status':'MATHEMATICAL-CANDIDATE-ONLY' if T else 'NO-GO','g_math':g,'T_math':T,'actual_go':False}
for O,g,T in [(117,125,500),(118,126,1000),(242,250,1000),(243,251,None)]:
 rows=synthetic_rows(O,1);r=select(rows,2);assert (r['g_math'],r['T_math'])==(g,T);results.append({'name':'guard-boundary-'+str(g),'synthetic_O':O,'synthetic_F':1,'synthetic_C':2,'result':r})
rows=synthetic_rows(10,1);rows[0]['O']=242;r=select(rows,2);assert r['g_math']==250 and r['T_math']==1000;results.append({'name':'case-warm-outlier-included','synthetic_only':True,'result':r});checks.append('warm outlier included in maxima; g125/126/250/251 boundaries')
for name,change in [('missing',lambda a:a.pop()),('duplicate',lambda a:a[0].update(index=1)),('split62+82',lambda a:[x.update(bundle='SYNTHETIC-ONLY-B') for x in a[62:]]),('fresh-resume',lambda a:a[-1].update(session=2)),('unknown-NN',lambda a:a[0].update(completed=None)),('late',lambda a:a[0].update(late=True)),('unfinished',lambda a:a[0].update(complete=False)),('F-null',lambda a:a[0].update(F=None)),('negative-tail',lambda a:a[0].update(F=-1)),('nan-op',lambda a:a[0].update(O=float('nan'))),('NN-fault',lambda a:a[0].update(error='NN_ERROR'))]:
 rows=synthetic_rows(10,1);change(rows);r=select(rows,2);assert r['T_math'] is None;results.append({'name':name,'synthetic_only':True,'result':r})
assert select(synthetic_rows(10,1),2,False)['T_math'] is None;checks.append('missing/source62+82/session/late/partial/count/negative/nonfinite/error/endclock fail closed')
# No actual future acceptance inferred from purely mathematical scenarios.
assert p['actual_go'] is False and p['critic56_acceptance']['accepted'] is False and p['freeze']['complete_final_run_bundle_sha256'] is None
checks.append('real protocol stays pending/no-go despite synthetic positive arithmetic')
old=p['old_negative'];assert math.ceil(old['max_nondivided_op']['ms']+old['max_finish_transport']['total_ms']+old['max_clock_error_ms']+5)==287 and old['g_needed_ms']==287 and old['uniform_full_run_gate'] is False
checks.append('old g287/startup denominator and negative preserved, not recomputed without startup')
# Local interval algebra: nested NN included once in O, finish included once in final tail.
O=max([20,12,5]);F=3+7;C=2;assert math.ceil(O+F+C+5)==37;assert math.ceil(sum([20,12,5])+F+C+5)!=37
checks.append('inclusive atomic maximum and disjoint pre+tail; no NN/finish double count')
lo,hi=100,102;drift=1;nodeD=500;early=nodeD+lo-drift;assert early<=nodeD+lo and early<=nodeD+hi
assert 99<=lo-drift and 103>=hi+drift;end_inside=lambda a,b:a>=lo-drift and b<=hi+drift
assert end_inside(100.5,102.5) and not end_inside(100.5,103.1);assert 2*((hi-lo)/2+drift)==4
checks.append('early-side deadline and end-drift containment/clock uncertainty algebra')
for v in [1.00005,float('nan'),float('inf'),None]:assert not (isinstance(v,(int,float)) and math.isfinite(v) and -1<=v<=1)
for bad in ['late','cancel','stale','hardfault','unfinished']:
 public={'action':None,'checkpoint':False};assert public['action'] is None and not public['checkpoint']
checks.append('strictvalue rejects1.00005/NaN/Infinity/missing; discard types distinct from private stats')
u=p['phase_budgets']['uniform'];assert u['outer_wall_timeout_s']==1032 and sum(v for k,v in u.items() if k!='outer_wall_timeout_s')==1032
pilot=p['phase_budgets']['pilot'];assert pilot['outer_wall_timeout_s']==558 and math.ceil(sum(v for k,v in pilot.items() if k!='outer_wall_timeout_s'))==558
checks.append('uniform1032 and pilot558 include startup/warm/metadata/endclock/current cleanup reserves')
f=p['future_match_arithmetic'];stop=datetime.datetime.fromisoformat(f['example_match_processing_stop_UTC'].replace('Z','+00:00'))
for T,n,key in [(500,11800,'latest_T500_start_UTC'),(1000,21800,'latest_T1000_start_UTC')]:
 start=datetime.datetime.fromisoformat(f[key].replace('Z','+00:00'));assert (stop-start).total_seconds()==n+1.5
checks.append('new00:30-stop latest starts21:13:18.5 /18:26:38.5 and fixed minimum reserve')
# Failure after selected T pilot cannot select a different T as salvage.
frozen={'T':500,'g':125};pilot_failure='NO-GO';assert frozen=={'T':500,'g':125} and pilot_failure=='NO-GO'
checks.append('one selection before pilot; pilot failure cannot refreeze T/g')
(P/'static-check-summary.json').write_text(json.dumps({'scope':'static synthetic checks only, no NN/readiness acceptance or entry runtime','checks':checks,'synthetic_selection_scenarios':results,'actual_go':False,'critic56_accepted':False,'NN_browser_entry_build_actual_games_holdout_sends':0},indent=2));print(json.dumps({'checks':len(checks),'synthetic_scenarios':len(results),'actual_go':False}))
