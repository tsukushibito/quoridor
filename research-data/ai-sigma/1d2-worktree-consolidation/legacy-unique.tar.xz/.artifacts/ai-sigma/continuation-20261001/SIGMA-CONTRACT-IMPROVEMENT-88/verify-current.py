import importlib.util,datetime as dt,json,os,sys,time,uuid,resource
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/workspaces/quoridor/.worktree/ai-sigma');OUT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('g',ROOT/'tools/ai-sigma-supervisor-read-guard/guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
os.sched_setaffinity(0,{0});os.environ.update(g.ENV);start=g.stamp();tests=[]
def test(name,fn,reject=False):
 try: value=fn()
 except g.Rejected as e:
  assert reject,(name,str(e));tests.append({'name':name,'rejected':str(e)});return
 assert not reject,name
 tests.append({'name':name,'passed':True})
wall=g.utc_now();mono=time.monotonic();run=str(uuid.uuid4());turn=str(uuid.uuid4());owned={'run_id':run,'turn_id':turn,'thread_id':g.THREAD,'started_at':wall.isoformat(),'max_turn_seconds':180};bound=g.binding(owned,run,turn,wall=wall,mono=mono)
core=[{'id':g.GOAL,'status':'in_progress'},{'id':g.SELF,'status':'in_progress','assignee':'codex:'+g.THREAD}]
test('read-after90-with-enough-time',lambda:g.admit(bound,'read_start',wall=wall+dt.timedelta(seconds=125),mono=mono+125,required_seconds=14))
test('insufficient-time-does-not-start',lambda:g.admit(bound,'read_start',wall=wall+dt.timedelta(seconds=140),mono=mono+140,required_seconds=14),True)
test('hard180-refusal',lambda:g.admit(bound,'finish',wall=wall+dt.timedelta(seconds=180),mono=mono+180),True)
test('repeat-keeps-original-clock',lambda:None if g.binding(owned,run,turn,prior=bound,wall=wall+dt.timedelta(seconds=20),mono=mono+20)==bound else (_ for _ in ()).throw(AssertionError()))
test('owner-change-refusal',lambda:g.binding({**owned,'thread_id':'other'},run,turn,prior=bound),True)
test('pause-refusal',lambda:g.require_unpaused([{**core[0],'labels':['paused-by-user']},core[1]]),True)
test('unknown-owner-refusal',lambda:g.require_unpaused([core[0],{**core[1],'assignee':'other'}]),True)
mock=[{'id':g.GOAL+'.84','status':'open','updated_at':'1'},{'id':g.GOAL+'.87','status':'in_progress','assignee':'critic','updated_at':'2'},{'id':g.GOAL+'.41','status':'closed'}]
assert g.select_current(mock)==[g.GOAL+'.87',g.GOAL+'.84'];tests.append({'name':'dynamic84-87-discovery-excludes-closed','passed':True})
calls=[]
def temporary(*a,**kw):
 calls.append(a)
 if len(calls)==1:raise g.ReadFailed('temporary lock',transient=True)
 return {'ok':True}
with patch.object(g,'run_child',temporary):assert g.read_retry(['mock'],OUT,'retry',bound)=={'ok':True}
assert len(calls)==2;tests.append({'name':'one-transient-retry-same-clock','passed':True})
calls=[]
def hard(*a,**kw):calls.append(a);raise g.Rejected('pause or deadline')
with patch.object(g,'run_child',hard):test('hard-refusal-no-retry',lambda:g.read_retry(['mock'],OUT,'hard',bound),True)
assert len(calls)==1
# Few real wrapper reads, with the same child-timeout/cleanup runner. This is a
# steward NN0 diagnostic, not a forged live supervisor turn.
base=['bash',str(g.MAIN/'scripts/dev/beads.sh')]
rows=g.run_child(base+['list','--parent',g.GOAL,'--status','open,in_progress,blocked','--sort','updated','--limit','24','--json'],OUT/'real-current-list.json',bound)
selected=g.select_current(rows,limit=8);assert g.GOAL+'.87' in selected,'Latest active critic must be discovered'
actual=g.run_child(base+['show',g.GOAL,g.SELF,*selected,'--json'],OUT/'real-current-show.json',bound)
tests.append({'name':'real-wrapper-dynamic-current','passed':True,'list_ids':[x.get('id') for x in rows],'selected':selected,'summary':g.issue_summary(actual)})
# Synthetic long child and descendant only; no live fault injection.
code="import subprocess,sys,time,json,os;p=subprocess.Popen([sys.executable,'-c','import time;time.sleep(10)']);print(json.dumps({'parent':os.getpid(),'child':p.pid}),flush=True);time.sleep(10)"
test('own-child-timeout-collected',lambda:g.run_child([sys.executable,'-B','-c',code],OUT/'own-timeout.json',bound,timeout=.2),True)
ids=json.loads((OUT/'own-timeout.stdout').read_text());states={k:g.proc(v) for k,v in ids.items()};assert all(v is None or v['state']=='Z' for v in states.values());tests.append({'name':'parent-descendant-not-running','passed':True,'processes':states})
# Mock the current batch/inspect/finish without mutating live state or Beads.
mockdir=OUT/('mock-'+run);mockdir.mkdir(exist_ok=True)
mockstate={'process':{'pid':99999999,'start_ticks':'0'}}
mock_calls=[]
def live(*a,**kw):return bound,mockstate
def child(args,path,*a,**kw):
 mock_calls.append(args)
 if 'show' in args:
  value=core+[{'id':g.GOAL+'.87','status':'in_progress','assignee':'critic','dependencies':[{'id':g.GOAL+'.77'}]}]
 elif 'ready' in args:value=[{'id':g.GOAL+'.84'}]
 elif 'list' in args:value=mock if args[args.index('--parent')+1]==g.GOAL else []
 elif 'status' in args:value={'mock_sessions':True}
 else:value={'mock_bookkeeping':True}
 if kw.get('phase')=='finish':
  path.with_suffix('.stdout').write_text(json.dumps(value));return {'mock':True,'reaped':True}
 return value
with patch.object(g,'live_owned',live),patch.object(g,'run_child',child):
 observed=g.observe(mockdir,run,turn)
 assert g.GOAL+'.87' in observed['current_issue_ids'] and g.GOAL+'.84' in observed['current_issue_ids']
 assert g.observe(mockdir,run,turn)['cached']
 add=g.inspect(mockdir,run,turn,[g.GOAL+'.87']);assert add['binding']==bound and add['issues']
 stopped=g.finish(mockdir,run,turn,'mock only');assert stopped['owned_command_children_reaped']
 tests.append({'name':'snapshot-additional-read-finish-sharing-clock','passed':True,'live_Beads_write':False})
result={'started':start,'finished':g.stamp(),'tests':tests,'passed':len(tests),'failed':0,'NN_build_download':False,'live_fault_injection':False,'self_maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};g.write(OUT/'nn0-verification.json',result);print(json.dumps({'passed':len(tests),'failed':0,'selected_current':selected}))
