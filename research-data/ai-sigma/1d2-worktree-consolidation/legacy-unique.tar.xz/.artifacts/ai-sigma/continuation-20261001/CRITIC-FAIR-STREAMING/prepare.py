import json,hashlib,datetime,os,shutil,difflib,resource
from pathlib import Path
R=Path('/workspaces/quoridor/.worktree/ai-sigma');S=R/'tools/ai-sigma-fair-streaming';B=R/'.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING';O=R/'.artifacts/ai-sigma/continuation-20261001/CRITIC-FAIR-STREAMING';T=O/'copy';T.mkdir(exist_ok=False);U=O/'upstream'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
expected={R/'docs/design/ai-sigma-contract-critic-fair-streaming.md':'9949d84da44988ef3d1227ad4d6a372e54be133c5cdb72221a7d3fd4808de720',R/'docs/design/ai-sigma-continuation-20261001.md':'6766deb7b6588c702ba1516558952fb1e6c6d09def7dd155c174f44eb5d3987f',R/'docs/reports/ai-sigma-experiment-fair-streaming.md':'2fda64fe0652fd0f0b5037f0405856b46d3819ed7a2dc6504bb5410f91a33e4a'}
expected.update({B/n:h for n,h in {'final-manifest.json':'8778edbf1638772b072b0b9deb5bf07b7dad61c2fe8982987c5ceec5a56e5132','source-frozen.json':'b66988de59787c3b955d54fe15a894887b237b7430ceae1710db827880a698b1','preregister.json':'9da324299911c87e7e40b877092defcec6755f01a34326c68c1bd5bbbf199bab','repair-preregister.json':'aa517cb6f2d2599fe6d86e48e79de1bbe81e646d5f0736630e8615315e822a82'}.items()});inputs={str(p):h for p,h in expected.items()};counts={}
for n in ['final-manifest.json','source-frozen.json','input-before.json']:
 d=json.loads((B/n).read_text());counts[n]=len(d['checks'])
 for c in d['checks']:assert c['path'] not in inputs or inputs[c['path']]==c['sha256'];inputs[c['path']]=c['sha256']
checks=[{'path':p,'sha256':h,'actual':sha(p)} for p,h in inputs.items()];save('independent-input-before.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'checks':checks});assert all(x['actual']==x['sha256'] for x in checks)
st=json.loads((B/'runtime-stop-final-before-document.json').read_text());assert st['runtime_stopped'] and not st['remaining'];assert json.loads((B/'source-stop.json').read_text())['source_write_stopped']
current=[]
for x in st['identities']:
 pid=x['pid'];tick=x.get('starttick',x.get('start_ticks'));assert tick is not None
 try:v=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split();now=int(v[19])
 except FileNotFoundError:now=None
 current.append({'pid':pid,'starttick':tick,'current':now,'same_live':now==tick})
save('writer-identities-current.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'count':len(current),'checks':current});assert not any(x['same_live'] for x in current)
old=json.loads((O.parent/'CRITIC-STREAMING-EARLY-SEAL/runtime-stopped.json').read_text());prior=[]
for x in old['identities']:
 try:now=int(Path(f"/proc/{x['pid']}/stat").read_text().rsplit(')',1)[1].split()[19])
 except FileNotFoundError:now=None
 prior.append({**x,'current':now,'same_live':now==x['starttick']})
save('old-self-identities-current.json',{'checks':prior,'new_job_not_old_retry':True});assert not any(x['same_live'] for x in prior)
for p in S.iterdir():
 if p.is_file():shutil.copyfile(p,T/p.name)
for n in ['source-frozen.json','input-before.json','preregister.json','reserve.json','preregister-repair-runtime.json','representative-payloads-NN0.json','repair-preregister.json']:
 shutil.copyfile(B/n,U/n)
for n in ['source-frozen.json','input-before.json','reserve.json','preregister-repair-runtime.json','representative-payloads-NN0.json']:shutil.copyfile(U/n,O/n)
(O/'CAL65-02').mkdir();shutil.copyfile(B/'CAL65-02/calibration-gate.json',O/'CAL65-02/calibration-gate.json')
pr=json.loads((B/'preregister.json').read_text());allcases=pr['cases'];normal=[x for x in allcases if x['kind']=='normal' and x['sample'] in [-1,0,1]];cancel=[x for x in allcases if x['kind']=='cancel-next'];assert len(normal)==18 and len(cancel)==2
# First handoff is candidate cancel -> reference warm, then reference cancel -> candidate warm.
warmR=next(x for x in normal if x['engine']=='reference' and x['fixture']=='initial-p1' and x['sample']==-1);warmC=next(x for x in normal if x['engine']=='candidate' and x['fixture']=='initial-p1' and x['sample']==-1)
selected=[next(x for x in cancel if x['engine']=='candidate'),warmR,next(x for x in cancel if x['engine']=='reference'),warmC]+[x for x in normal if x is not warmR and x is not warmC]
selected += [x for x in allcases if x['kind'] in ['terminal','validation-cross'] or x['kind']=='before-first' and x['engine']=='reference' or x['kind']=='caller-busy' and x['engine']=='candidate'];assert len(selected)==28
for i,c in enumerate(selected):c['request_id']=f'FAIR66-{i+1:02d}';c['generation']=6600+i
pr['cases']=selected;pr['fixed_control']['fixtures']=['initial-p1'];pr['candidate_numeric_fixtures']=[]
save('preregister.json',pr);save('selection-before-NN.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'normal':18,'boundary':10,'cases':selected,'fixed_work_reference_original_wrapper':'initial-p1 each8 simulations exactly2 searches','extra_candidate_numeric':0,'T':500,'reserve':89,'commit':9,'cutoff':402,'seal':411,'retry':0,'one_revision_one_window':3})
patches=[]
def patch(n,pairs):
 p=T/n;a=p.read_text();b=a
 for x,y in pairs:assert x in b,(n,x);b=b.replace(x,y)
 p.write_text(b);patches.append({'path':n,'before':sha(S/n),'after':sha(p),'diff':''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='original/'+n,tofile='copy/'+n))})
root=json.dumps(str(R));out=json.dumps(str(O))
patch('browser.cjs',[("ROOT=path.resolve(__dirname,'../..')",'ROOT='+root),("BASE=ROOT+'/.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING'",'BASE='+out)])
patch('entry.cjs',[("['SUITE65-01','SUITE65-02']","['SUITE66-ONCE']"),("'SUITE65-02'","'SUITE66-ONCE'"),("t.issue!=='quoridor-4lc.65'","t.issue!=='quoridor-4lc.66'"),("2026-10-01T18:40:23Z","2026-10-01T19:22:00Z"),("const candidateNumeric=[];for(const id of pr.fixed_control.fixtures)","const candidateNumeric=[];for(const id of pr.candidate_numeric_fixtures)")])
patch('pause-check.cjs',[("ROOT=path.resolve(__dirname,'../..')",'ROOT='+root),("RUN=ROOT+'/.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING'",'RUN='+out),("2026-10-01T18:45:23Z","2026-10-01T19:27:00Z"),("quoridor-4lc.65","quoridor-4lc.66")])
patch('runner.py',[("OUT=TOOL.parents[1]/'.artifacts/ai-sigma/continuation-20261001/SIGMA-FAIR-STREAMING'",'OUT=Path('+out+')'),("2026-10-01T18:45:23+00:00","2026-10-01T19:27:00+00:00"),("3758096384","2684354560"),("117440512","58720256"),(".04-",".02-"),("'sample_interval_ms':40","'sample_interval_ms':20"),("18:45:23Z","19:27:00Z"),("18:40:23Z","19:22:00Z")])
save('copy-patches.json',patches)
token={'issue':'quoridor-4lc.66','run_id':'SUITE66-ONCE','actual_go':False,'mode':'suite','freeze_token':'CRITIC66-FAIR-INDEPENDENT-ONCE','source_manifest_sha256':sha(O/'source-frozen.json'),'preregister_sha256':sha(O/'preregister.json'),'repair_preregister_sha256':sha(O/'preregister-repair-runtime.json'),'calibration_gate_sha256':sha(O/'CAL65-02/calibration-gate.json'),'reserve_sha256':sha(O/'reserve.json')};save('token.json',token)
save('prepare-process.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'PID':os.getpid(),'starttick':int(Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]),'CPU':list(os.sched_getaffinity(0)),'RSS':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'exit_planned':0,'NN':0,'command':'python -B prepare.py'})
print(json.dumps({'input_union':len(checks),'counts':counts,'writer243':len(current),'old_self_absent':len(prior),'primary_selected':28,'additional_fixed_work':2,'patches':len(patches)}))
