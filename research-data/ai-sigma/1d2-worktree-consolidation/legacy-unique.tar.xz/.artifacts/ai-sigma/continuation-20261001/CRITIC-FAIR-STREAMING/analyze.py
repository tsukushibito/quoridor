import json,math,statistics,struct,hashlib,datetime
from pathlib import Path
R=Path('/workspaces/quoridor/.worktree/ai-sigma');O=R/'.artifacts/ai-sigma/continuation-20261001/CRITIC-FAIR-STREAMING';B=O.parent/'SIGMA-FAIR-STREAMING';N=O/'SUITE66-ONCE'
def load(p):return json.loads(Path(p).read_text())
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def stats(rows):
 vals=sorted(r['public']['elapsed_ms'] for r in rows);return {'n':len(vals),'eligible':sum(r['public']['checkpoint'] and not r['public']['late'] for r in rows),'median':statistics.median(vals),'p95':vals[math.ceil(.95*len(vals))-1],'max':max(vals)} if vals else {'n':0}
windows={};cal={}
for win in ['SUITE65-01','SUITE65-02']:
 rs=load(B/win/'public-requests.json');assert len(rs)==36;private=load(B/win/'private-diagnostics-after-public.json');stops=load(B/win/'search-stop-events.json');windows[win]={e:{'all_normal':stats([r for r in rs if r['spec']['kind']=='normal' and r['spec']['engine']==e]),'steady':stats([r for r in rs if r['spec']['kind']=='normal' and r['spec']['engine']==e and r['spec']['sample']>=0])} for e in ['candidate','reference']};windows[win]['boundary']=12;windows[win]['max_stop_after_public_ms']=max(s['node_received_ms']-r['public']['stamp_ms'] for r in rs for s in stops if s['identity']['request_id']==r['spec']['request_id'])
 if win=='SUITE65-01':
  bad=next(r for r in rs if r['public']['late'] and r['spec']['kind']=='normal');windows[win]['expired_before_dispatch']={'id':bad['spec']['request_id'],'elapsed':bad['public']['elapsed_ms'],'private_worker_record_exists':bad['spec']['request_id'] in private,'no_NN_missing_not_fabricated':True,'old_wait':bad['old_search_wait_ms']}
for win in ['CAL65-01','CAL65-02']:
 rs=load(B/win/'samples.json');assert len(rs)==30 and all(r['mock_NN0'] and r['real_NN']==0 for r in rs);steady=[r for r in rs if r['sample']>=0];val=[x['node_validation_finished_ms']-x['node_received_ms'] for r in steady for x in r['bindings'] if x['accepted']];cal[win]={'total':30,'warm':10,'steady':20,'max_steady':max(r['public']['elapsed_ms'] for r in steady),'max_validation':max(val),'commit9_guarantee':False,'NN':0};assert cal[win]['max_steady']<=89
assert cal['CAL65-02']['max_validation']>9
save('upstream-both-windows-independent.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'windows':windows,'not_pooled':True,'calibration':cal,'original_delay_all_Beads_attribution_proved':False,'saved_control_helper_deadline_refusal_preserved':True})
fixtures={f['id']:f for f in load(R/'.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json')['fixtures']};refs={x['id']:x for x in load(R/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json')}
def check_numeric(f,q,cp=None):
 assert len(q['numeric'])==1;v=q['numeric'][0];ref=refs[f['id']];bits=[struct.unpack('<I',struct.pack('<f',x))[0] for x in f['raw_features_float32']];assert len(v['features_bits'])==648 and v['features_bits']==bits;assert len(v['policy_logits'])==len(ref['policy_logits'])==136;assert type(v['value']) in [int,float] and math.isfinite(v['value']) and -1<=v['value']<=1
 diffs=[]
 for x,y in zip(v['policy_logits']+[v['value']],ref['policy_logits']+[ref['value']]):assert math.isfinite(x) and math.isfinite(y) and abs(x-y)<=1e-4+1e-4*abs(y);diffs.append(abs(x-y))
 r={'features':648,'NN':137,'NNmax':max(diffs),'prior':0,'priormax':0}
 if cp is not None:
  pmap={e[0]:e[1] for e in cp['root_edges']};assert set(pmap)=={a['rust209'] for a in f['legal_actions']};assert abs(sum(pmap.values())-1)<=1e-4;canon={x['canonical136']:x['prior'] for x in ref['canonical_legal_priors']};P2=f['board']['total_ply']%2==1
  for a in f['legal_actions']:
   k=a['sigma136']
   if P2:
    if k<8:k=[1,0,2,3,6,7,4,5][k]
    else:off=8 if k<72 else 72;z=k-off;k=off+8*(7-z//8)+z%8
   x,y=pmap[a['rust209']],canon[k];assert math.isfinite(x) and abs(x-y)<=1e-4+1e-4*abs(y);r['prior']+=1;r['priormax']=max(r['priormax'],abs(x-y))
 return r
def control(p):
 x=load(p);d,s=x['direct'],x['stream'];assert d['result']['cp']==s['result']['cp'];assert len(s['result']['trace'])==9 and len(d['result']['trace'])==1;assert d['result']['trace'][-1]['tree']==s['result']['trace'][-1]['tree'];assert d['identity']['history']==s['identity']['history'] and d['identity']['key']==s['identity']['key'];cp=d['result']['cp'];assert cp['root_visits']==9 and cp['simulations']==8 and sum(e[2] for e in cp['root_edges'])==8
 return {'path':str(p),'all_tree_values_exact':True,'cp_context_exact':True,'notifications':9,'numeric':[check_numeric(fixtures[d['identity']['fixture_id']],q,q['result']['cp']) for q in [d,s]]}
saved=[control(B/'SUITE65-02'/('control-'+fid+'.json')) for fid in ['initial-p1','asym-hv-p2','straight-jump-p2']];added=control(N/'control-initial-p1.json')
oldcand=O.parent/'SIGMA-STREAMING-EARLY-SEAL/NN-SUITE-63-01';eq24=[]
for fid in ['initial-p1','asym-hv-p2','straight-jump-p2']:
 x=load(oldcand/('control-'+fid+'.json'));a,b=x['direct']['result'],x['stream']['result'];assert len(a['trace'])==len(b['trace'])==8 and a['cp']==b['cp'];assert all(u['cp']==v['cp'] for u,v in zip(a['trace'],b['trace']));eq24.append({'id':fid,'all8cp_tree_history_stats_equal':True})
save('fixed-work-control-independent.json',{'saved_reference3x2':saved,'new_reference1x2':added,'saved_candidate24cp':eq24,'candidate_control_newNN':0,'original_control_helper_refused_not_rescued':True})
rs=load(N/'public-requests.json');priv=load(N/'private-diagnostics-after-public.json');stops={x['identity']['request_id']:x for x in load(N/'search-stop-events.json')};clock=load(N/'browser/clock-start.json');end=load(N/'browser/clock-end.json');assert len(rs)==28
clockcheck={}
for label,v in [('start',clock),('end',end)]:
 for key,z in v.items():
  assert len(z['samples'])==12;lo=max(x['remote']-x['end']-.1 for x in z['samples']);hi=min(x['remote']-x['start']+.1 for x in z['samples']);assert abs(lo-z['lo_ms'])<1e-9 and abs(hi-z['hi_ms'])<1e-9 and lo<=hi;clockcheck[label+'-'+key]={'lo':lo,'hi':hi,'error':z['error_ms']}
for key in ['page','worker']:assert end[key]['lo_ms']<=clock[key]['hi_ms'] and end[key]['hi_ms']>=clock[key]['lo_ms']
out=[];nums=[];poststarts={'candidate':0,'reference':0};api={'candidate':0,'reference':0};tails={'candidate':[],'reference':[]};acktails={'candidate':[],'reference':[]};attempts={'candidate':0,'reference':0};completed={'candidate':0,'reference':0};published={'candidate':0,'reference':0};nextslack=[]
for i,r in enumerate(rs):
 spec,p=r['spec'],r['public'];rid=spec['request_id'];q=priv[rid];ident=q['identity'];e=spec['engine'];f=fixtures[spec['fixture']];ref=e=='reference';stop=stops[rid];raw=stop['raw_stop'];assert ident==stop['identity'];assert all(raw[k]==0 for k in ['handles','activeNN','live_searches']) and raw['active'] is False and stop['ownership_error'] is None
 assert ident['engine']==p['engine']==e and ident['request_id']==p['request_id']==rid and ident['epoch']==ident['generation']==spec['generation']==p['generation'];assert type(p['checkpoint']) is bool and type(p['late']) is bool and p['fallback']==0;assert ident['model']==p['model']=='d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d';assert ident['schema']==p['schema']=='8x9x9-f32/136logits/value1/rust209';assert ident['limits']==p['limits']=={'simulations':100000 if ref else 4096,'max_nodes':None if ref else 512,'max_depth':None if ref else 24,'seed':1979}
 assert ident['deadline_ms']-ident['t0_ms']==500 and ident['seal_ms']-ident['t0_ms']==411 and ident['commit_cutoff_ms']-ident['t0_ms']==402
 if f['classification']=='legal-replay':assert ident['legal_prefix']==f['legal_prefix'] and ident['history']==sorted(f['history_counts'],key=lambda x:x[0])
 if i:assert ident['t0_ms']==rs[i-1]['public']['stamp_ms'];assert r['root_context_started_ms']>=stops[rs[i-1]['spec']['request_id']]['node_received_ms']
 cp=r['private_cache']['owned']['cp'] if r['private_cache'] else None
 if cp:
  m=r['private_cache'];assert m['producer_identity']==m['identity']==ident;assert m['owned']['pending_token'] is None;assert type(m['value']) in [int,float] and math.isfinite(m['value']) and -1<=m['value']<=1;assert cp['generation']==p['generation'];assert cp['policy_fallbacks']==cp['value_fallbacks']==0;assert m['owned']['completed_NN']==cp['nn_calls'];assert m['owned']['NN_attempts']==m['owned']['completed_NN'];assert not p['checkpoint'] or p['completed_simulations']==cp['simulations'];assert sum(x[2] for x in cp['root_edges'])==(cp['simulations'] if ref else max(0,cp['simulations']-1));assert cp.get('root_visits')==(0 if spec['kind']=='terminal' else cp['simulations']+1) if ref else True
  for ev in r['cache_events']:
   if ev['accepted'] and ev['kind']=='snapshot':assert ev['validation_finished_ms']<ident['commit_cutoff_ms']
  if spec['kind']=='normal':assert p['action'] in {x['rust209'] for x in f['legal_actions']} and p['checkpoint'] and not p['late'];assert p['stamp_ms']<ident['deadline_ms']
 if q['numeric']:nums.append(check_numeric(f,q,cp))
 if spec['kind']=='terminal':assert q['result']['calls']==0 and p['completed_NN']==0 and p['action'] is None and q['numeric']==[]
 if p['late']:assert p['action'] is None and p['checkpoint'] is False and p['error']=='LATE_FINAL_STAMP'
 if p['checkpoint']:assert p['value']==r['private_cache']['value'] and -1<=p['value']<=1
 guaranteed=False;lateStarts=0;tail=0
 for x in q['NN']:
  assert x['session_run_start_ms']<=x['session_run_end_ms'];startlo=x['session_run_start_ms']-clock['worker']['hi_ms'];startupper=x['session_run_start_ms']-clock['worker']['lo_ms'];endlo=x['session_run_end_ms']-clock['worker']['hi_ms'];endupper=x['session_run_end_ms']-clock['worker']['lo_ms'];guaranteed|=startupper<=p['stamp_ms']<=endlo
  if startlo>p['stamp_ms']:lateStarts+=1
  tail=max(tail,max(0,endupper-p['stamp_ms']))
 if i and q['NN']:
  previous=stops[rs[i-1]['spec']['request_id']];slack=q['NN'][0]['session_run_start_ms']-clock['worker']['hi_ms']-previous['node_received_ms'];assert slack>=0;nextslack.append(slack)
 if guaranteed and spec['kind']=='normal':api[e]+=1
 poststarts[e]+=lateStarts;tails[e].append(tail);acktails[e].append(stop['node_received_ms']-p['stamp_ms']);attempts[e]+=raw['NN_attempts'];completed[e]+=raw['completed_NN'];published[e]+=p['completed_NN']
 out.append({'id':rid,'engine':e,'kind':spec['kind'],'sample':spec.get('sample'),'elapsed':p['elapsed_ms'],'checkpoint':p['checkpoint'],'error':p['error'],'action':p['action'],'API_crossing':guaranteed,'post_public_new_API_starts':lateStarts,'old_stop_wait':r['old_search_wait_ms'],'stop_ACK_after_public':stop['node_received_ms']-p['stamp_ms'],'API_remaining_upper':tail,'timer_late':p['seal_timer_lateness_ms'],'encoding_validation_ms':p['final_validation_encoding_ms'],'snapshot_age':p['snapshot_age_ms'],'published_simulations':p['completed_simulations'],'actual_attempts':raw['NN_attempts'],'actual_completedNN':raw['completed_NN'],'published_completedNN':p['completed_NN']})
normalstats={e:{'normal':stats([r for r in rs if r['spec']['kind']=='normal' and r['spec']['engine']==e]),'steady':stats([r for r in rs if r['spec']['kind']=='normal' and r['spec']['engine']==e and r['spec']['sample']>=0])} for e in ['candidate','reference']};assert all(x['normal']['n']==x['normal']['eligible']==9 for x in normalstats.values())
assert [rs[0]['spec']['engine'],rs[1]['spec']['engine'],rs[2]['spec']['engine'],rs[3]['spec']['engine']]==['candidate','reference','reference','candidate'];assert rs[0]['public']['error']==rs[2]['public']['error']=='CANCELLED'
totals={k:sum(v[k] for v in nums) for k in ['features','NN','prior']};totals['NNmax']=max(v['NNmax'] for v in nums);totals['priormax']=max(v['priormax'] for v in nums)
save('independent-runtime-summary.json',{'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'primary_planned_completed':28,'normal':normalstats,'boundary':10,'numerical':totals,'API_crossing_normal':api,'post_public_API_starts':poststarts,'API_remaining_upper_max':{k:max(v) for k,v in tails.items()},'ACK_after_public_max':{k:max(v) for k,v in acktails.items()},'attempts':attempts,'completedNN':completed,'published_completedNN':published,'minimum_nextNN_after_old_ACK_slack_ms':min(nextslack),'engine_switch_cancel_wait_ms':[rs[1]['old_search_wait_ms'],rs[3]['old_search_wait_ms']],'clock_intervals':clockcheck,'rows':out,'same_seed_caps_and_value_views_distinct':True,'finite_cpu_handoff_support':True,'exact_kernel_timing':False,'all_delivery_hard_deadline_guarantee':False,'actual_go':False})
print(json.dumps({'normal':normalstats,'numeric':totals,'API_crossing':api,'post_public_starts':poststarts,'minslack':min(nextslack)}))
