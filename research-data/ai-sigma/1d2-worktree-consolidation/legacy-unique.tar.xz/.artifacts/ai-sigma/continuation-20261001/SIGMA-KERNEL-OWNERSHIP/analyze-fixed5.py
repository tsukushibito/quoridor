from pathlib import Path
import json,struct,math,hashlib,datetime,subprocess
r=Path('/workspaces/quoridor/.worktree/ai-sigma');b=r/'.artifacts/ai-sigma/continuation-20261001/SIGMA-KERNEL-OWNERSHIP';p=b/'diagnostic/golden-execution-GOLDEN-SEAL-01'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((p/'requests.json').read_text());proof=json.loads((p/'summary.json').read_text());proc=json.loads((b/'fixed-initial5-once.process.json').read_text());ref=next(x for x in json.loads((r/'.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json').read_text()) if x['id']=='initial-p1')
assert len(rows)==5
rv=ref['value']
while isinstance(rv,list):assert len(rv)==1;rv=rv[0]
checks=[];values=[];maxerr=0;elements=0;features_checked=0
for i,x in enumerate(rows):
 if i==2:
  assert x['accepted'] is False and x['action'] is None and x['checkpoint'] is False and x['T_ms']==10 and x['g_ms']==0
  checks.append({'index':i,'engine':x['engine'],'action':None,'checkpoint':False,'error':x.get('error'),'elapsed_ms':x['elapsed_ms'],'overshoot_ms':x['overshoot_ms'],'NN_count':x.get('nn_calls'),'NN_count_missing':'nn_calls' not in x});continue
 assert x['accepted'] is True and x['legal'] is True and x['illegal'] is False and x['late'] is False and x['owned_binding'] is True and x['transaction_bound'] is True and x['final_validation_and_serialization_before_stamp'] is True
 assert type(x['fallback']) is int and x['fallback']==0 and x['T_ms']==500 and x['g_ms']==91 and x['elapsed_ms']<500
 nr=x['diagnostic_numeric_root'];assert len(nr['policy_logits'])==136 and type(nr['value']) in [int,float] and math.isfinite(nr['value']) and -1<=nr['value']<=1
 if 'features_bits' in nr:
  assert len(nr['features_bits'])==648 and all(type(v) is int and 0<=v<=0xffffffff for v in nr['features_bits']);fb=b''.join(struct.pack('<I',v) for v in nr['features_bits'])
 else:assert len(nr['features'])==648;fb=b''.join(struct.pack('<f',v) for v in nr['features'])
 assert hashlib.sha256(fb).hexdigest()==ref['input_float32_sha256'];features_checked+=648
 for actual,expected in zip(nr['policy_logits']+[nr['value']],ref['policy_logits']+[rv]):
  assert math.isfinite(actual) and abs(actual-expected)<=1e-4+1e-4*abs(expected);maxerr=max(maxerr,abs(actual-expected));elements+=1
 vb=struct.pack('<f',nr['value']).hex();values.append(vb);q=x['raw']['payload'];q=q.get('payload',q);d=q.get('data',q);prior_sum=None
 if x['engine']=='candidate':
  assert d['owned']['cp']==d['original_checkpoint'];cp=d['checkpoint'];assert type(cp['policy_fallbacks']) is int and cp['policy_fallbacks']==0 and type(cp['value_fallbacks']) is int and cp['value_fallbacks']==0
  for action,prior,visits,total in cp['root_edges']:assert type(action) is int and type(visits) is int and visits>=0 and math.isfinite(prior) and prior>=0 and math.isfinite(total)
  prior_sum=sum(edge[1] for edge in cp['root_edges'])
 else:assert type(d['fallback']) is int and d['fallback']==0
 checks.append({'index':i,'engine':x['engine'],'accepted':True,'action':x['action'],'fallback':0,'elapsed_ms':x['elapsed_ms'],'NN_count':x['nn_calls'],'root_value':nr['value'],'root_value_f32bits':vb,'owned_checkpoint_exact':x['engine']=='candidate','post_validation_stamp':True,'candidate_root_prior_sum':prior_sum})
assert len(set(values))==1
trace=[json.loads(line) for line in (b/'fixed-initial5-once.monitor.jsonl').read_text().splitlines()];adoptions=proc['kernel_adoptions'];ids={(a['observed']['pid'],a['observed']['start_ticks']) for a in adoptions};waited={(a['identity']['pid'],a['identity']['start_ticks']) for a in trace if a['kind']=='adopted_wait' and a['outcome'][0]};assert ids<=waited
assert len(proof['stops'])==2 and all(s['remaining_pids']==0 and s['registration_ack'] is True and s['zombie_identities_absent'] is True for s in proof['stops'])
assert not proc['remaining'] and not proc['unknown_adopted'] and not proc['ledger_rejected'] and proc['kernel_boundary']['valid']
cleanup=[]
for session in [1,2]:
 a=[json.loads(line) for line in (p/f'session-{session}/cleanup-trace.jsonl').read_text().splitlines()];success=[x for x in a if x['kind']=='cleanup_success'];assert len(success)==1 and not success[0]['remaining'];start=next(x for x in a if x['kind']=='absence_wait_start');end=next(x for x in a if x['kind']=='absence_wait_end');drain_start=next(x for x in a if x['kind']=='drain_before');drain_end=next(x for x in a if x['kind']=='drain_after');cleanup.append({'session':session,'UTC':success[0]['UTC'],'owned_remaining':success[0]['remaining'],'forced':proof['stops'][session-1]['forced'],'absence_observed_ms':end['monotonic_ms']-start['monotonic_ms'],'drain_observed_ms':drain_end['monotonic_ms']-drain_start['monotonic_ms'],'scope_ids':proof['stops'][session-1]['tracked']})
summary={'UTC':now(),'issue':'quoridor-4lc.54','finite_kernel_ownership_gate_supported':True,'fixed5_complete':True,'responses':checks,'normal4_accepted':True,'features_f32bits_checked':features_checked,'root_NN_elements_checked':elements,'root_NN_max_abs_error':maxerr,'root_value_f32bit_exact_across4':True,'NN_gate_unchanged':'abs<=1e-4+1e-4*abs(reference)','kernel_adoptions':adoptions,'adopted_same_identity_waited':sorted([list(x) for x in waited]),'first_final_cleanup':cleanup,'monitor_group_remaining':proc['remaining'],'monitor_unknown_adopted':proc['unknown_adopted'],'finite_scope_consistency':True,'clock_gate':False,'entry_ready':False,'actual_go':False,'old49_g287_gt91_split62plus82_unaltered':True,'old51_negative_not_rescued':True,'new_uniform_calibration':False,'formal_adoption_or_strength':False,'real_games':0,'holdout_sends':0,'initial_dummy_logger_failure_preserved':True,'limits':['trusted single-thread childless dedicated launcher with one explicit root; no arbitrary hostile ctypes/ptrace/system mutation proof','initial helper exception escaped original stop; separately recovered root and private birth-attested leaf with PIDfd; original birth starttick missing and controlled stop not proved','external dummy driver historical RSS/birth fields incomplete','20ms monitoring does not prove instant peak or whole-period compliance','T10 NN count absent, no hard real-time tail guarantee']}
(b/'validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'elements':elements,'feature_bits':features_checked,'maxNNabs':maxerr,'adopted_count':len(adoptions),'responses':checks,'cleanup_durations':[{'session':a['session'],'absence_ms':a['absence_observed_ms'],'drain_ms':a['drain_observed_ms']} for a in cleanup]}))
