'use strict';
const fs=require('fs'),path=require('path');
const ROOT=path.resolve(__dirname,'../../../..'),N=require(ROOT+'/tools/ai-sigma-nn-schema-cost/numeric.cjs');
const fixtures=JSON.parse(fs.readFileSync(ROOT+'/.artifacts/ai-sigma/reference-fixtures/SIGMA-PARITY-PLAN/fixtures.json')).fixtures;
const refs=JSON.parse(fs.readFileSync(ROOT+'/.artifacts/ai-sigma/runs/SIGMA-INFERENCE-PROBE/ort-a.outputs.json'));
const rows=fs.readFileSync(__dirname+'/runs/v2-r1/calls.jsonl','utf8').trim().split('\n').map(JSON.parse);
let prior=0,nn=0,features=0,maxNN=0,maxPrior=0;
for(const r of rows){
 const f=fixtures.find(x=>x.id===r.id),ref=refs.find(x=>x.id===r.id);N.validate(f,r,ref,r.backend);
 const logits=r.backend==='A'?r.policy_logits:r.logits;
 logits.concat(r.value).forEach((x,i)=>maxNN=Math.max(maxNN,Math.abs(x-ref.policy_logits.concat(ref.value)[i])));
 const target=N.rawPriors(f,ref.policy_logits);r.raw_prior.forEach((x,i)=>maxPrior=Math.max(maxPrior,Math.abs(x-target[i])));
 prior+=r.raw_prior.length;nn+=137;features+=648;
}
const out={run:'v2-r1',NN:0,source:'saved actual responses; same validator replay, not independent actor',rows:rows.length,features,nn,prior,maxNN,maxPrior,pass:true};
fs.writeFileSync(__dirname+'/saved92-recount.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out));
