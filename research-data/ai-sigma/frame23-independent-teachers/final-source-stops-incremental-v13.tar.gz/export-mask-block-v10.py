"""Sequential frozen export and input-only mask in one NN0 guardian, no retry."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")


def execute(cfg):
    began = time.monotonic()
    for path, expected in cfg["source_hashes"].items():
        assert sha(path) == expected, "SOURCE_SHA:" + path
    root = Path(cfg["root"])
    export = read(cfg["export_plan"])
    start = time.monotonic()
    subprocess.run(
        [
            "/usr/bin/python3",
            "-B",
            str(root / "export-block-v2.py"),
            "--config",
            cfg["export_plan"],
        ],
        timeout=60,
        check=True,
    )
    export_wall = time.monotonic() - start
    result = read(export["output"])
    assert result["task"] == export["task"] and result["schema"] == "independent-teacher-export-v2"
    assert result["NN"] == 0
    mask = dict(cfg["mask_plan"])
    mask["source_hashes"] = {**cfg["source_hashes"], export["output"]: sha(export["output"])}
    write(cfg["mask_plan_path"], mask)
    start = time.monotonic()
    subprocess.run(
        [
            "/usr/bin/python3",
            "-B",
            str(root / "mask-block-v8.py"),
            "--config",
            cfg["mask_plan_path"],
        ],
        timeout=5,
        check=True,
    )
    mask_wall = time.monotonic() - start
    masked = read(mask["output"])
    assert masked["task"] == mask["task"] and masked["schema"] == "registered-block-Vraw-mask-v8"
    assert masked["NN"] == 0 and masked["planned_rows"] == result["rows"]
    write(
        cfg["output"],
        {
            "task": cfg["task"],
            "schema": "export-mask-registered-block-v10",
            "NN": 0,
            "export": export["output"],
            "export_SHA": sha(export["output"]),
            "mask": mask["output"],
            "mask_SHA": sha(mask["output"]),
            "export_subcommand_wall_s": export_wall,
            "mask_subcommand_wall_s": mask_wall,
            "whole_command_wall_s": time.monotonic() - began,
            "limits_s": {"export": 60, "mask": 5, "outer_guard": 65},
            "no_retry": True,
            "no_model_or_math_change": True,
        },
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    execute(read(parser.parse_args().config))


if __name__ == "__main__":
    main()
