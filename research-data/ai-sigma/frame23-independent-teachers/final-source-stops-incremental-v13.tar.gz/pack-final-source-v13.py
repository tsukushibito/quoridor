"""Incremental source/stop pack; reuse stage1 pack, keep teacher payloads sealed."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tarfile
import time


ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    start = time.monotonic()
    stop = read(ROOT / "producer-final-science-source-stop-v12.json")
    prior = read(ROOT / "stage1-source-pack-receipt-v4.json")
    handoff = read(ROOT / "train576-selection48-immutable-handoff-v12.json")
    assert sha(prior["archive"]) == prior["archive_SHA"]
    files = {
        Path(p)
        for p in {**stop["source_SHA"], **stop["payload_SHA"]}
        if Path(p).is_relative_to(ROOT)
    }
    for check in handoff["checks"]:
        files.add(Path(check["guard"]))
        files.update(Path(check["stop"]).parent.glob("*.json"))
        files.update(Path(check["stop"]).parent.glob("*.log"))
    for run in ["final-prefix-collection-r1-v11", "final-prefix-collection-r2-v12"]:
        files.update((ROOT / run).glob("*"))
    for pattern in [
        "stage2-*.json",
        "stage2-*.md",
        "producer-*.json",
        "producer-*.md",
        "*v10.py",
        "*v11.py",
        "*v12.py",
        "*v13.py",
        "v10-*.json",
        "combined-wiring-*.json",
        "final-prefix-collection-*.json",
        "final-known-cost-*.json",
    ]:
        files.update(ROOT.glob(pattern))
    files.update(
        ROOT / n
        for n in [
            "producer-final-science-source-stop-v12.json",
            "stage1-source-pack-receipt-v4.json",
        ]
    )
    files = {
        p
        for p in files
        if p.is_file() and p.name != "read-metadata-v1" and p.suffix not in (".gz", ".xz")
    }
    reused = {}
    new = {}
    for path in sorted(files):
        name = str(path.relative_to(ROOT))
        digest = sha(path)
        if prior["members"].get(name) == digest:
            reused[name] = digest
        else:
            new[name] = digest
    archive = ROOT / "final-source-stops-incremental-v13.tar.gz"
    with tarfile.open(archive, "x:gz", compresslevel=6) as out:
        for name in new:
            out.add(ROOT / name, arcname=name, recursive=False)
    restored = {}
    with tarfile.open(archive, "r|gz") as source:
        for member in source:
            assert member.isfile() and member.name in new
            restored[member.name] = hashlib.sha256(source.extractfile(member).read()).hexdigest()
    assert restored == new
    result = {
        "UTC": datetime.now(timezone.utc).isoformat(),
        "task": "independent-teachers-285-v2",
        "schema": "incremental-source-stop-pack-v13",
        "archive": str(archive),
        "archive_SHA": sha(archive),
        "archive_bytes": archive.stat().st_size,
        "members": new,
        "reused_prior_members": reused,
        "reused_prior_archive": prior["archive"],
        "reused_prior_archive_SHA": prior["archive_SHA"],
        "byte_stream_restoration": "PASS",
        "raw_teacher_or_cache_or_model_copy": False,
        "sealedfuture_labels_in_archive": False,
        "retained_raw_cache_private_public_inputs": "original immutable assets/ownpaths +SHA handoff; not removed or duplicated",
        "wall_s": time.monotonic() - start,
        "NN": 0,
        "Git_index_commit_owner": "coordinator only",
    }
    with (ROOT / "final-source-pack-receipt-v13.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps({k: result[k] for k in ["archive_bytes", "wall_s", "byte_stream_restoration"]})
    )


if __name__ == "__main__":
    main()
