"""Registered nested train prefix with actual budgets, separate guards, no retry."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")


def guarded(root, cfg, tag, template, argv, hashes, task, expected, hard):
    began = time.monotonic()
    guard = read(root / template)
    guard.update(
        run_dir=str(root / (tag + "-r1-v10")),
        task=task,
        argv=argv,
        source_hashes=hashes,
        hard_seconds=hard,
        expected=expected,
        storage_evidence=cfg["storage_evidence"],
    )
    gp = root / (tag + "-guardian-v10.json")
    write(gp, guard)
    subprocess.run(
        ["/usr/bin/python3", "-B", str(root / "control-v1.py"), "--config", str(gp)], check=True
    )
    process = read(Path(guard["run_dir"]) / "process.json")
    assert process["exit"] == 0 and process["waited"] and not process["current_exact_remaining"]
    process["caller_outside_command_wall_s"] = time.monotonic() - began - process["command_wall_s"]
    return gp, process


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = read(parser.parse_args().config)
    root = Path(cfg["root"])
    for path, expected in cfg["source_hashes"].items():
        assert sha(path) == expected, "SOURCE_SHA:" + path
    blocks = cfg["blocks"]
    assert blocks == list(range(blocks[0], blocks[-1] + 1)) and 5 <= blocks[0] <= blocks[-1] <= 15
    counters = dict(cfg["counters_before"])
    records = []
    failure = None
    reason = None
    try:
        for block in blocks:
            if counters["eligible_old_plus_new"] >= 30000:
                reason = "FIRST_COMPLETE_PREFIX_REACHED_30000"
                break
            if counters["NN0prep_s"] + 65 + 20 > 260:
                reason = "PREP_REMAINING_RESERVATION_INSUFFICIENT"
                break
            if counters["management_known_s"] + 8 + 30 > 160:
                reason = "MANAGEMENT_REMAINING_FORECAST_INSUFFICIENT"
                break
            assert counters["NN"] + 624036 <= 8635167 <= 18200000
            assert counters["science_s"] + 420 <= 12000
            assert counters["science_entries"] < 19 <= 30
            tag = f"block{block:02d}"
            nc = root / f"{tag}-native-v2.json"
            assert sha(nc) == cfg["native_configs"][str(block)]
            native = read(nc)
            pipeline = read(root / "block01-pipeline-v2.json")
            old = pipeline["native_config"]
            pipeline.update(
                task=f"independent-teachers-285-{tag}-v10",
                block=block,
                native_config=str(nc),
                output=str(root / f"{tag}-pipeline-result-v10.json"),
            )
            pipeline["argv"][-1] = str(nc)
            pipeline["source_hashes"].pop(old)
            pipeline["source_hashes"] = {
                **pipeline["source_hashes"],
                **cfg["source_hashes"],
                str(nc): sha(nc),
            }
            pp = root / f"{tag}-pipeline-v10.json"
            write(pp, pipeline)
            gp, proc = guarded(
                root,
                cfg,
                tag,
                "block01-guardian-v2.json",
                ["/usr/bin/python3", "-B", str(root / "generate-block-v2.py"), "--config", str(pp)],
                {**pipeline["source_hashes"], str(pp): sha(pp)},
                pipeline["task"],
                [
                    {
                        "path": pipeline["output"],
                        "task": pipeline["task"],
                        "schema": "independent-teacher-block-v2",
                    }
                ],
                420,
            )
            observed = read(pipeline["output"])
            assert observed["physical_NN"] is not None
            counters["NN"] += observed["physical_NN"]
            counters["science_s"] += proc["command_wall_s"]
            counters["science_entries"] += 1
            counters["management_known_s"] += proc["caller_outside_command_wall_s"]
            record = {"block": block, "generation": pipeline["output"], "generation_guard": str(gp)}
            records.append(record)
            export = read(root / "block01-export-pipeline-v2.json")
            location = Path(native["output"])
            export.update(
                task=f"independent-teachers-285-{tag}-export-v10",
                block=block,
                dataset=str(location / "dataset"),
                cache=str(location.parent / f"{tag}-r1-cache"),
                private_input_metadata=str(root / f"{tag}-targetfree-private-native-v10.jsonl"),
                public_metadata=str(root / f"{tag}-public-targetfree-v10.jsonl"),
                output=str(root / f"{tag}-export-result-v10.json"),
            )
            inputs = [
                root / "export-block-v2.py",
                root / "read-metadata-v1",
                root / "read-metadata-v2.rs",
                root / "registered-family-map-v2.json",
                location / "result.json",
                location / "dataset/manifest.json",
                Path(export["runner"]),
            ]
            export["source_hashes"] = {str(p): sha(p) for p in inputs}
            ep = root / f"{tag}-export-pipeline-v10.json"
            write(ep, export)
            mask = {
                "task": f"independent-teachers-285-{tag}-mask-v10",
                "block": block,
                "native_config": str(nc),
                "export_result": export["output"],
                "exposure_source": cfg["exposure_source"],
                "Vraw": cfg["Vraw"],
                "eligible_before": counters["eligible_old_plus_new"],
                "retained_refs": str(root / f"{tag}-Vraw-eligible-refs-v10.jsonl.gz"),
                "output": str(root / f"{tag}-Vraw-mask-v10.json"),
            }
            combined = {
                "root": str(root),
                "task": f"independent-teachers-285-{tag}-export-mask-v10",
                "export_plan": str(ep),
                "mask_plan": mask,
                "mask_plan_path": str(root / f"{tag}-mask-plan-v10.json"),
                "output": str(root / f"{tag}-export-mask-result-v10.json"),
                "source_hashes": {
                    **cfg["source_hashes"],
                    **export["source_hashes"],
                    str(ep): sha(ep),
                    str(nc): sha(nc),
                },
            }
            cp = root / f"{tag}-export-mask-plan-v10.json"
            write(cp, combined)
            egp, proc = guarded(
                root,
                cfg,
                tag + "-export-mask",
                "block01-export-guardian-v2.json",
                [
                    "/usr/bin/python3",
                    "-B",
                    str(root / "export-mask-block-v10.py"),
                    "--config",
                    str(cp),
                ],
                {**combined["source_hashes"], str(cp): sha(cp)},
                combined["task"],
                [
                    {
                        "path": combined["output"],
                        "task": combined["task"],
                        "schema": "export-mask-registered-block-v10",
                    }
                ],
                65,
            )
            counters["NN0prep_s"] += proc["command_wall_s"]
            counters["management_known_s"] += proc["caller_outside_command_wall_s"]
            counts = read(mask["output"])
            counters["eligible_old_plus_new"] = counts["cumulative_old_plus_new_eligible"]
            record.update(export=export["output"], mask=mask["output"], combined_guard=str(egp))
            write(
                root / f"{tag}-cumulative-point-v10.json",
                {
                    "task": cfg["task"],
                    "schema": "registered-prefix-cumulative-point-v10",
                    "last_block": block,
                    "counters": counters,
                    "science_currently_stopped": True,
                    "old_unknown_costs": "preserved separately, not0",
                    "future_labels_distributed": False,
                },
            )
        if reason is None:
            reason = (
                "FIRST_COMPLETE_PREFIX_REACHED_30000"
                if counters["eligible_old_plus_new"] >= 30000
                else "REGISTERED_T768_BOUND"
            )
    except BaseException as error:
        failure = repr(error)
        raise
    finally:
        write(
            cfg["output"],
            {
                "task": cfg["task"],
                "schema": "stage2-nested-prefix-v10",
                "planned_blocks": blocks,
                "records": records,
                "counters_observed_only": counters,
                "stop_reason": reason,
                "failure": failure,
                "unread_failed_inflight_charge": "UNKNOWN; retain guardian/native or upper bound, no old counter discount",
                "retry": False,
                "future_labels_distributed": False,
            },
        )


if __name__ == "__main__":
    main()
