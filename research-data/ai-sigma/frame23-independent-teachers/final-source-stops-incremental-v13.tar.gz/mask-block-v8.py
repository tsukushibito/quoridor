"""Apply the frozen learner input predicate to one registered train block, NN0."""

import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def lines(path):
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = read(parser.parse_args().config)
    for path, expected in cfg["source_hashes"].items():
        assert sha(path) == expected, "SOURCE_SHA:" + path
    spec = importlib.util.spec_from_file_location("frozen_exposure", cfg["exposure_source"])
    exposure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(exposure)
    native = read(cfg["native_config"])
    exported = read(cfg["export_result"])
    public = lines(exported["public_target_free_metadata"])
    assert sha(exported["public_target_free_metadata"]) == exported["public_metadata_SHA"]
    cache = Path(exported["cache"])
    assert sha(cache / "cache.json") == exported["cache_manifest_SHA"]
    # This permitted train container also contains labels. Only ID/eligibility
    # are read into the predicate; it is not advertised as a sealed container.
    metadata = lines(cache / "rows.jsonl")
    flags = {row["id"]: row["primary_eligible"] for row in metadata}
    assert len(flags) == len(metadata) == len(public) == exported["rows"]
    assert all(type(v) is bool for v in flags.values())
    refs = []
    for row in public:
        assert row["partition"] == "train" and row["id"] in flags
        ref = exposure.public_reference(row, native_run_id=native["run_id"])
        ref["primary_eligible"] = flags[row["id"]]
        refs.append(ref)
    raw_val = lines(cfg["Vraw"])
    assert len(raw_val) == 3285
    masked = exposure.mask(refs, raw_val, label=cfg["task"])
    planned = sorted(exported["rows_by_family"])
    assert len(planned) == 48 and set(masked["groups"]) <= set(planned)
    groups = {g: masked["groups"].get(g, {"planned": 0, "eligible": 0}) for g in planned}
    assert {g: v["planned"] for g, v in groups.items()} == exported["rows_by_family"]
    retained = [r for r in refs if masked["rows"][r["id"]]["eligible"]]
    with Path(cfg["retained_refs"]).open("xb") as stream:
        with gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as packed:
            for row in retained:
                packed.write((json.dumps(row, separators=(",", ":")) + "\n").encode())
    result = {
        "task": cfg["task"],
        "schema": "registered-block-Vraw-mask-v8",
        "NN": 0,
        "block": cfg["block"],
        "Vraw_count": 3285,
        "Vraw_SHA": sha(cfg["Vraw"]),
        "exposure_source_SHA": sha(cfg["exposure_source"]),
        "public_metadata_SHA": exported["public_metadata_SHA"],
        "cache_manifest_SHA": exported["cache_manifest_SHA"],
        "planned_families": 48,
        "planned_rows": len(refs),
        "primary_eligible_before_OR": sum(flags.values()),
        "OR_matches": masked["matches"],
        "eligible_rows": len(retained),
        "groups": groups,
        "zeroeligible_groups": sum(g["eligible"] == 0 for g in groups.values()),
        "history_cross_format": masked["history_cross_format"],
        "labels_used_for_predicate": False,
        "retained_refs": cfg["retained_refs"],
        "retained_refs_SHA": sha(cfg["retained_refs"]),
        "cumulative_old_plus_new_eligible": cfg["eligible_before"] + len(retained),
        "finalmask_frozen": False,
        "independent_certification": False,
    }
    with Path(cfg["output"]).open("x") as stream:
        stream.write(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
