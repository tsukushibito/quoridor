"""One new registered block, separate fresh guards, no retry or replenishment."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")


def guarded(root, path):
    subprocess.run(
        ["/usr/bin/python3", "-B", str(root / "control-v1.py"), "--config", str(path)],
        check=True,
    )
    cfg = read(path)
    process = read(Path(cfg["run_dir"]) / "process.json")
    assert process["exit"] == 0 and process["waited"] and not process["current_exact_remaining"]
    return process


def guard_config(root, cfg, template, tag, pipeline, path, schema, hard):
    guard = read(root / template)
    guard.update(
        run_dir=str(root / (tag + "-r1-v8")),
        task=pipeline["task"],
        storage_evidence=cfg["storage_evidence"],
        source_hashes={**pipeline["source_hashes"], str(path): sha(path)},
        hard_seconds=hard,
    )
    guard["argv"][-1] = str(path)
    guard["expected"] = [{"path": pipeline["output"], "task": pipeline["task"], "schema": schema}]
    gp = root / (tag + "-guardian-v8.json")
    write(gp, guard)
    return gp


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = read(parser.parse_args().config)
    root = Path(cfg["root"])
    for path, expected in cfg["source_hashes"].items():
        assert sha(path) == expected, "SOURCE_SHA:" + path
    block = cfg["block"]
    assert type(block) is int and 3 <= block <= 15
    counters = dict(cfg["counters_before"])
    assert counters["eligible_old_plus_new"] < 30000
    assert counters["NN"] + 624036 <= 8635167 <= 18200000
    assert counters["science_s"] + 420 <= 12000
    assert counters["science_entries"] < 19 <= 30
    assert counters["NN0prep_s"] + 60 + 5 + 20 <= 240
    tag = f"block{block:02d}"
    nc = root / f"{tag}-native-v2.json"
    assert sha(nc) == cfg["native_config_SHA"]
    native = read(nc)
    records = []
    failure = None
    try:
        pipeline = read(root / "block01-pipeline-v2.json")
        old = pipeline["native_config"]
        pipeline.update(
            task=f"independent-teachers-285-{tag}-v8",
            block=block,
            native_config=str(nc),
            output=str(root / f"{tag}-pipeline-result-v8.json"),
        )
        pipeline["argv"][-1] = str(nc)
        pipeline["source_hashes"].pop(old)
        pipeline["source_hashes"][str(nc)] = sha(nc)
        pipeline["source_hashes"].update(cfg["source_hashes"])
        pp = root / f"{tag}-pipeline-v8.json"
        write(pp, pipeline)
        gp = guard_config(
            root,
            cfg,
            "block01-guardian-v2.json",
            tag,
            pipeline,
            pp,
            "independent-teacher-block-v2",
            420,
        )
        process = guarded(root, gp)
        result = read(pipeline["output"])
        assert result["physical_NN"] is not None
        counters["NN"] += result["physical_NN"]
        counters["science_s"] += process["command_wall_s"]
        counters["science_entries"] += 1
        records.append({"generation": pipeline["output"], "generation_guard": str(gp)})
        export = read(root / "block01-export-pipeline-v2.json")
        location = Path(native["output"])
        export.update(
            task=f"independent-teachers-285-{tag}-export-v8",
            block=block,
            dataset=str(location / "dataset"),
            cache=str(location.parent / f"{tag}-r1-cache"),
            private_input_metadata=str(root / f"{tag}-targetfree-private-native-v8.jsonl"),
            public_metadata=str(root / f"{tag}-public-targetfree-v8.jsonl"),
            output=str(root / f"{tag}-export-result-v8.json"),
        )
        inputs = [
            root / "export-block-v2.py",
            root / "read-metadata-v1",
            root / "read-metadata-v2.rs",
            root / "registered-family-map-v2.json",
            location / "result.json",
            location / "dataset/manifest.json",
            Path(export["runner"]),
        ]
        export["source_hashes"] = {str(p): sha(p) for p in inputs}
        ep = root / f"{tag}-export-pipeline-v8.json"
        write(ep, export)
        egp = guard_config(
            root,
            cfg,
            "block01-export-guardian-v2.json",
            tag + "-export",
            export,
            ep,
            "independent-teacher-export-v2",
            60,
        )
        exported = guarded(root, egp)
        counters["NN0prep_s"] += exported["command_wall_s"]
        records[-1].update(export=export["output"], export_guard=str(egp))
        mp = root / f"{tag}-mask-plan-v8.json"
        mask = {
            "task": f"independent-teachers-285-{tag}-mask-v8",
            "block": block,
            "native_config": str(nc),
            "export_result": export["output"],
            "exposure_source": cfg["exposure_source"],
            "Vraw": cfg["Vraw"],
            "eligible_before": counters["eligible_old_plus_new"],
            "retained_refs": str(root / f"{tag}-Vraw-eligible-refs-v8.jsonl.gz"),
            "output": str(root / f"{tag}-Vraw-mask-v8.json"),
            "source_hashes": {
                **cfg["source_hashes"],
                str(nc): sha(nc),
                export["output"]: sha(export["output"]),
            },
        }
        write(mp, mask)
        mg = read(egp)
        mg.update(task=mask["task"], run_dir=str(root / f"{tag}-mask-r1-v8"), hard_seconds=5)
        mg["argv"] = ["/usr/bin/python3", "-B", str(root / "mask-block-v8.py"), "--config", str(mp)]
        mg["source_hashes"] = {**mask["source_hashes"], str(mp): sha(mp)}
        mg["expected"] = [
            {
                "path": mask["output"],
                "task": mask["task"],
                "schema": "registered-block-Vraw-mask-v8",
            }
        ]
        mgp = root / f"{tag}-mask-guardian-v8.json"
        write(mgp, mg)
        masked = guarded(root, mgp)
        counters["NN0prep_s"] += masked["command_wall_s"]
        counts = read(mask["output"])
        counters["eligible_old_plus_new"] = counts["cumulative_old_plus_new_eligible"]
        records[-1].update(mask=mask["output"], mask_guard=str(mgp))
    except BaseException as error:
        failure = repr(error)
        raise
    finally:
        write(
            cfg["output"],
            {
                "task": cfg["task"],
                "schema": "stage2-one-registered-block-v8",
                "block": block,
                "records": records,
                "counters_observed_only": counters,
                "failure": failure,
                "unread_failed_inflight_charge": "UNKNOWN; retain native/guardian or conservative upper bound",
                "retry": False,
                "future_labels_distributed": False,
                "next_block_allowed_by_size": counters["eligible_old_plus_new"] < 30000
                and block < 15,
            },
        )


if __name__ == "__main__":
    main()
