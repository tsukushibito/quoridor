"""Finite immutable train-prefix handoff; no model, label selection, or regeneration."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time


ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1048576), b""):
            value.update(chunk)
    return value.hexdigest()


def absent(identity):
    try:
        parts = Path(f"/proc/{identity['pid']}/stat").read_text().rsplit(")", 1)[1].split()
        return parts[19] != str(identity["start_ticks"])
    except FileNotFoundError:
        return True


def main():
    started = time.monotonic()
    sequence = read(ROOT / "stage2-T5-T15-result-v10.json")
    assert sequence["failure"] is None
    prior_path = ROOT / "train144-selection48-immutable-handoff-v3.json"
    prior = read(prior_path)
    blocks = list(prior["blocks"])
    source_bindings = {}
    payload_bindings = {}
    checks = []
    for block in range(3, sequence["records"][-1]["block"] + 1):
        tag = f"block{block:02d}"
        version = "v8" if block <= 4 else "v10"
        gp = ROOT / f"{tag}-guardian-{version}.json"
        guards = [gp]
        if block <= 4:
            guards += [
                ROOT / f"{tag}-export-guardian-v8.json",
                ROOT / f"{tag}-mask-guardian-v8.json",
            ]
        else:
            guards += [ROOT / f"{tag}-export-mask-guardian-v10.json"]
        for path in guards:
            cfg = read(path)
            run = Path(cfg["run_dir"])
            process, stop = read(run / "process.json"), read(run / "stop.json")
            assert process["exit"] == 0 and process["waited"] and stop["waited"]
            assert not process["current_exact_remaining"] and not stop["current_exact_remaining"]
            assert all(absent(i) for i in [process["identity"], *process["recorded_children"]])
            assert sha(run / "process.json") == stop["process_SHA"]
            source_bindings.update(stop["source_hashes"])
            payload_bindings.update(stop["outputs"])
            checks.append(
                {
                    "guard": str(path),
                    "stop": str(run / "stop.json"),
                    "stop_SHA": sha(run / "stop.json"),
                    "current_exact_remaining": [],
                }
            )
        generation = read(ROOT / f"{tag}-pipeline-result-{version}.json")
        exported = read(ROOT / f"{tag}-export-result-{version}.json")
        mask = read(ROOT / f"{tag}-Vraw-mask-{version}.json")
        native = read(generation["native_report_path"])
        assert sha(generation["native_report_path"]) == generation["native_report_SHA"]
        assert native["planned"] == 48 and len(native["outcomes"]) == 48
        assert all(
            o["status"] in ("goal", "draw") and o["reason"] is None for o in native["outcomes"]
        )
        assert native["all_workers_joined"] and native["stopped"] is None
        dataset = Path(generation["native_report_path"]).parent / "dataset"
        assert sha(dataset / "manifest.json") == exported["dataset_manifest_SHA"]
        for shard in read(dataset / "manifest.json")["shards"]:
            assert sha(dataset / shard["path"]) == shard["sha256"]
        cache = Path(exported["cache"])
        assert sha(cache / "cache.json") == exported["cache_manifest_SHA"]
        cm = read(cache / "cache.json")
        assert cm["allow_test"] is False and cm["rows"] == exported["rows"] == mask["planned_rows"]
        for name, expected in cm["sha256"].items():
            assert sha(cache / cm["files"][name]) == expected
        assert sha(exported["public_target_free_metadata"]) == exported["public_metadata_SHA"]
        assert exported["STM_cache_rows_checked"] == exported["rows"]
        assert sha(mask["retained_refs"]) == mask["retained_refs_SHA"]
        blocks.append(
            {
                "block": block,
                "partition": "train",
                "planned": 48,
                "completed_GOAL": sum(o["status"] == "goal" for o in native["outcomes"]),
                "completed_DRAW": sum(o["status"] == "draw" for o in native["outcomes"]),
                "rows_before_OR": exported["rows"],
                "eligible_rows_after_Vraw_OR": mask["eligible_rows"],
                "OR_matches": mask["OR_matches"],
                "zeroeligible": mask["zeroeligible_groups"],
                "NN": generation["physical_NN"],
                "science_wall_s": read(Path(read(gp)["run_dir"]) / "process.json")[
                    "command_wall_s"
                ],
                "native_run_id": native["run_id"],
                "native_dataset": str(dataset),
                "cache": str(cache),
                "cache_manifest_SHA": exported["cache_manifest_SHA"],
                "public_metadata": exported["public_target_free_metadata"],
                "public_SHA": exported["public_metadata_SHA"],
                "private_input_only_witness": str(
                    ROOT / f"{tag}-targetfree-private-native-{version}.jsonl"
                ),
                "private_input_only_SHA": exported["private_target_free_native_metadata_SHA"],
                "rows_by_family": exported["rows_by_family"],
                "retained_refs": mask["retained_refs"],
                "retained_refs_SHA": mask["retained_refs_SHA"],
                "mask_path": str(ROOT / f"{tag}-Vraw-mask-{version}.json"),
                "mask_SHA": sha(ROOT / f"{tag}-Vraw-mask-{version}.json"),
                "source_stop_SHA": sha(Path(read(gp)["run_dir"]) / "stop.json"),
            }
        )
    for path, expected in {**source_bindings, **payload_bindings}.items():
        assert sha(path) == expected, path
    bg = ROOT / "background-stage2-T5-T15-r1-v10"
    result, state = read(bg / "result.json"), read(bg / "state.json")
    assert result["cleanup_complete"] and result["exit_code"] == 0 and not result["remaining"]
    assert absent(state["child"])
    train = sorted([b for b in blocks if b["partition"] == "train"], key=lambda b: b["block"])
    assert [b["block"] for b in train] == list(range(12))
    assert sum(b["rows_before_OR"] for b in train) == 19536
    eligible = 4803 + sum(b["eligible_rows_after_Vraw_OR"] for b in train if b["block"] >= 3)
    assert eligible + 5981 == sequence["counters_observed_only"]["eligible_old_plus_new"]
    handoff = {
        "task": "independent-teachers-285-v2",
        "schema": "registered-train-prefix-handoff-v12",
        "UTC": datetime.now(timezone.utc).isoformat(),
        "blocks": train + [b for b in blocks if b["partition"] == "selection"],
        "registration": prior["registration"],
        "registration_SHA": prior["registration_SHA"],
        "prior144T_handoff": str(prior_path),
        "prior144T_handoff_SHA": sha(prior_path),
        "train_families": 576,
        "train_rows_before_OR": 19536,
        "train_rows_after_Vraw_OR": eligible,
        "old5981_plus_train_after_OR": 5981 + eligible,
        "accepted30k": False,
        "selection_families": 48,
        "selection_rows": 1645,
        "future_families": 96,
        "future_labels_distributed": False,
        "futuresealed_public_handoff": str(ROOT / "sealed96-public-reference-handoff-v4.json"),
        "Vraw_SHA": read(ROOT / "block11-Vraw-mask-v10.json")["Vraw_SHA"],
        "Tseen_final": "Told all5981 union all actually used train references across saved weights; not frozen",
        "history_crossformat": "UNVERIFIED; no fullhistory nonexposure claim",
        "producer_self_verification": "current source/payload/cache/raw SHA and all planned outcomes/STM rows via stopped export",
        "independent_model_input_verification": "286 separate; no independent PASS asserted",
        "checks": checks,
        "source_bindings": source_bindings,
        "payload_bindings": payload_bindings,
        "background_supervisor_current_exact_absent": absent(state["supervisor"]),
        "counters": sequence["counters_observed_only"],
        "remaining_NOT_STARTED": [12, 13, 14, 15],
        "stop_reason": sequence["stop_reason"],
        "source_collection_command_s": time.monotonic() - started,
        "NN": 0,
    }
    with (ROOT / "train576-selection48-immutable-handoff-v12.json").open("x") as stream:
        stream.write(json.dumps(handoff, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                "families": 576,
                "rows": 19536,
                "collection_s": handoff["source_collection_command_s"],
                "NN": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
