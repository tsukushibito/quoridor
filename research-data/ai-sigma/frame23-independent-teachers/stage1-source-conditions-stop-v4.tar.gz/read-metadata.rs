//! Producer-only input metadata reader. No model or feature recomputation.
use quoridor_core::research::{HistoryKey, SigmaContext};
use quoridor_data::{Result, file_sha, for_each_row, hex_digest};
use std::{fs::OpenOptions, io::BufWriter, io::Write, path::PathBuf};

fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() != 3 {
        return Err("input dataset and new target-free output required".into());
    }
    let input = PathBuf::from(&args[1]);
    let output = PathBuf::from(&args[2]);
    let mut writer = BufWriter::new(
        OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(&output)?,
    );
    let source = file_sha(&input.join("manifest.json"))?;
    let mut rows = 0;
    // Test labels may be decoded only inside this producer. None are emitted.
    for_each_row(&input, true, |row| {
        let context = SigmaContext::from_prefix(&row.prefix).map_err(|e| format!("{e:?}"))?;
        let literal = context
            .history_counts()
            .iter()
            .map(|(key, n)| (key.sigma_string(), *n))
            .collect::<Vec<_>>();
        let bytes = serde_json::to_vec(&literal)?;
        if hex_digest(&bytes) != row.history_key
            || HistoryKey::from(context.position()).sigma_string() != row.state_key
            || context.total_ply() != row.ply
        {
            return Err("prefix/state/history binding mismatch".into());
        }
        serde_json::to_writer(
            &mut writer,
            &serde_json::json!({
                "id":row.id, "native_family":row.family, "partition":row.split,
                "side":row.side, "ply":row.ply, "state_key":row.state_key,
                "history_key":row.history_key,
                "history_format":"SHA256(serde_json(sorted_sigma_history_counts_vec))",
                "history_literal":literal,
                "ids":row.ids, "ids_order":"P1_then_P2",
                "distance_bits":row.distance.map(f32::to_bits),
                "distance_order":"STM_then_opponent_f32_le",
                "input_signature":row.feature_signature, "prefix":row.prefix,
                "producer_schema":"quoridor-teacher-v1",
                "source_manifest_SHA":source,
            }),
        )?;
        writer.write_all(b"\n")?;
        rows += 1;
        Ok(())
    })?;
    writer.flush()?;
    println!("{{\"rows\":{rows},\"NN\":0,\"labels_emitted\":false}}");
    Ok(())
}
