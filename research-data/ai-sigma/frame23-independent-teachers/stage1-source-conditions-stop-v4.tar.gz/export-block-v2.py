"""Producer cache and strict target-free public metadata; sealed labels stay private."""

import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import struct
import subprocess
import time


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = read(parser.parse_args().config)
    began = time.monotonic()
    for path, expected in cfg["source_hashes"].items():
        assert sha(path) == expected, "SOURCE_SHA:" + path
    assert not Path(cfg["output"]).exists()
    manifest = read(cfg["family_map"])
    family_rows = manifest["families"][cfg["block"] * 48 : (cfg["block"] + 1) * 48]
    aliases = {p["native_family"]: p for p in family_rows}
    dataset = Path(cfg["dataset"])
    dataset_manifest = read(dataset / "manifest.json")
    split = family_rows[0]["split"]
    assert all(p["split"] == split for p in family_rows)
    for shard in dataset_manifest["shards"]:
        assert Path(shard["path"]).name == shard["path"]
        assert shard["path"].startswith(split + "-")
        assert sha(dataset / shard["path"]) == shard["sha256"]
    cache_path = Path(cfg["cache"])
    if split != "test":
        assert not cache_path.exists()
        subprocess.run(
            [
                cfg["runner"],
                "dataset",
                "cache",
                "--input",
                str(dataset),
                "--output",
                str(cache_path),
            ],
            check=True,
        )
        cache = read(cache_path / "cache.json")
        assert cache["allow_test"] is False and cache["dataset_sha"] == sha(
            dataset / "manifest.json"
        )
        for name, expected in cache["sha256"].items():
            assert sha(cache_path / name) == expected
    else:
        cache = None
    private = Path(cfg["private_input_metadata"])
    subprocess.run([cfg["reader"], str(dataset), str(private)], check=True)
    counts = collections.Counter()
    total = 0
    with Path(cfg["public_metadata"]).open("x") as public, private.open() as source:
        for line in source:
            row = json.loads(line)
            p = aliases[row["native_family"]]
            assert row["partition"] == p["split"]
            assert row["prefix"][: p["cohort"]] == p["prefix"]
            assert len(row["prefix"]) == row["ply"]
            assert row["side"] == 1 + row["ply"] % 2
            views = [row["side"] - 1, 2 - row["side"]]
            ids = [row["ids"][view] for view in views]
            assert all(sorted(set(v)) == v and all(0 <= x < 312 for x in v) for v in ids)
            assert len(row["distance_bits"]) == 2
            assert all(
                math.isfinite(struct.unpack("<f", struct.pack("<I", b))[0])
                for b in row["distance_bits"]
            )
            # Explicit field construction: no labels, winner, visits, predictions or errors.
            clean = {
                "id": row["id"],
                "canonical_family": p["canonical_family"],
                "native_family_alias": row["native_family"],
                "partition": p["split_purpose"],
                "side": row["side"],
                "ply": row["ply"],
                "cohort": p["cohort"],
                "state_key": row["state_key"],
                "history_key": row["history_key"],
                "history_key_format": row["history_format"],
                "actualSTM_ids": ids,
                "ids_order": "STM_then_opponent",
                "STM_distance_f32bits": row["distance_bits"],
                "distance_order": "STM_then_opponent_f32_le",
                "input_signature": row["input_signature"],
                "prefix": row["prefix"],
                "producer_schema": row["producer_schema"],
                "producer_source_SHA": cfg["producer_source_SHA"],
            }
            public.write(json.dumps(clean, separators=(",", ":"), allow_nan=False) + "\n")
            counts[p["canonical_family"]] += 1
            total += 1
    assert total == sum(s["rows"] for s in dataset_manifest["shards"])
    checked = 0
    eligible_counts = collections.Counter()
    if cache is not None:
        assert cache["rows"] == total
        with (
            (cache_path / "x.f32").open("rb") as x,
            (cache_path / "distance.f32").open("rb") as d,
            (cache_path / "labels.f32").open("rb") as y,
            (cache_path / "rows.jsonl").open() as meta,
        ):
            for line in meta:
                r = json.loads(line)
                assert r["group"] in aliases and r["split"] == split
                assert (
                    r["ids_order"] == "P1_then_P2"
                    and r["distance_order"] == "STM_then_opponent_f32"
                )
                views = [r["side"] - 1, 2 - r["side"]]
                expected = [float(i in r["ids"][v]) for v in views for i in range(312)]
                assert list(struct.unpack("<624f", x.read(2496))) == expected
                assert d.read(8) == struct.pack("<2f", *r["distance"])
                labels = struct.unpack("<2f", y.read(8))
                if r["primary_eligible"]:
                    assert all(math.isfinite(v) and abs(v) <= 1 for v in labels)
                    assert labels == tuple(
                        struct.unpack("<f", struct.pack("<f", r[k]))[0] for k in ("rootmean", "z")
                    )
                    eligible_counts[aliases[r["group"]]["canonical_family"]] += 1
                checked += 1
            assert not x.read(1) and not d.read(1) and not y.read(1)
        assert checked == total
    result = {
        "task": cfg["task"],
        "schema": "independent-teacher-export-v2",
        "NN": 0,
        "block": cfg["block"],
        "planned_family_count": 48,
        "rows": total,
        "cache": str(cache_path) if cache else None,
        "cache_manifest_SHA": sha(cache_path / "cache.json") if cache else None,
        "public_target_free_metadata": cfg["public_metadata"],
        "public_metadata_SHA": sha(cfg["public_metadata"]),
        "private_target_free_native_metadata_SHA": sha(private),
        "family_map_SHA": sha(cfg["family_map"]),
        "dataset_manifest_SHA": sha(dataset / "manifest.json"),
        "rows_by_family": {
            p["canonical_family"]: counts[p["canonical_family"]] for p in family_rows
        },
        "eligible_by_family": {
            p["canonical_family"]: eligible_counts[p["canonical_family"]] for p in family_rows
        }
        if cache
        else "PRODUCER_SEALED_NOT_DELIVERED",
        "STM_cache_rows_checked": checked,
        "history_literal_source": "native replay, SHA and state equality checked",
        "history_cross_old_format": "UNVERIFIED",
        "final_OR_mask": "NOT_FROZEN",
        "sealed_labels_or_densecache_distributed": False,
        "whole_command_wall_s": time.monotonic() - began,
        "source_hashes": cfg["source_hashes"],
    }
    Path(cfg["output"]).write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
