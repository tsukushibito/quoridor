"""Sequential registered entries, separate fresh guardians, no retry or success replenishment."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, obj):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(obj, indent=2, allow_nan=False) + "\n")


def guarded(root, path):
    subprocess.run(
        ["/usr/bin/python3", "-B", str(root / "control-v1.py"), "--config", str(path)], check=True
    )
    cfg = read(path)
    process = read(Path(cfg["run_dir"]) / "process.json")
    assert process["exit"] == 0 and process["waited"] and not process["current_exact_remaining"]
    return process


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = read(parser.parse_args().config)
    root = Path(cfg["root"])
    for path, expected in cfg["source_hashes"].items():
        assert sha(path) == expected, "SOURCE_SHA:" + path
    assert cfg["blocks"] == [2, 26], "REGISTERED_STAGE1_SEQUENCE"
    counters = dict(cfg["counters_before"])
    records = []
    failure = None
    try:
        for block in cfg["blocks"]:
            assert counters["NN"] + 624036 <= 5000000
            assert counters["science_s"] + 420 <= 3600
            assert counters["NN0prep_s"] + 60 <= 300
            tag = f"block{block:02d}"
            nc = root / f"{tag}-native-v2.json"
            assert sha(nc) == cfg["native_configs"][str(block)]
            native = read(nc)
            pipeline = read(root / "block01-pipeline-v2.json")
            old = pipeline["native_config"]
            pipeline.update(
                task=f"independent-teachers-285-{tag}-v2",
                block=block,
                native_config=str(nc),
                output=str(root / f"{tag}-pipeline-result-v2.json"),
            )
            pipeline["argv"][-1] = str(nc)
            pipeline["source_hashes"].pop(old)
            pipeline["source_hashes"][str(nc)] = sha(nc)
            pipeline["source_hashes"].update(cfg["source_hashes"])
            pp = root / f"{tag}-pipeline-v2.json"
            write(pp, pipeline)
            guard = read(root / "block01-guardian-v2.json")
            guard.update(run_dir=str(root / f"{tag}-r1"), task=pipeline["task"])
            guard["argv"][-1] = str(pp)
            guard["source_hashes"] = {**pipeline["source_hashes"], str(pp): sha(pp)}
            guard["expected"] = [
                {
                    "path": pipeline["output"],
                    "task": pipeline["task"],
                    "schema": "independent-teacher-block-v2",
                }
            ]
            gp = root / f"{tag}-guardian-v2.json"
            write(gp, guard)
            process = guarded(root, gp)
            result = read(pipeline["output"])
            assert result["physical_NN"] is not None
            counters["NN"] += result["physical_NN"]
            counters["science_s"] += process["command_wall_s"]
            counters["science_entries"] += 1
            records.append(
                {
                    "block": block,
                    "generation": pipeline["output"],
                    "generation_stop_SHA": sha(Path(guard["run_dir"]) / "stop.json"),
                }
            )
            export = read(root / "block01-export-pipeline-v2.json")
            location = Path(native["output"])
            export.update(
                task=f"independent-teachers-285-{tag}-export-v2",
                block=block,
                dataset=str(location / "dataset"),
                cache=str(location.parent / f"{tag}-r1-cache"),
                private_input_metadata=str(root / f"{tag}-targetfree-private-native-v2.jsonl"),
                public_metadata=str(root / f"{tag}-public-targetfree-v2.jsonl"),
                output=str(root / f"{tag}-export-result-v2.json"),
            )
            inputs = [
                root / "export-block-v2.py",
                root / "read-metadata-v1",
                root / "read-metadata-v2.rs",
                root / "registered-family-map-v2.json",
                location / "result.json",
                location / "dataset/manifest.json",
                Path(export["runner"]),
            ]
            export["source_hashes"] = {str(path): sha(path) for path in inputs}
            ep = root / f"{tag}-export-pipeline-v2.json"
            write(ep, export)
            eg = read(root / "block01-export-guardian-v2.json")
            eg.update(
                run_dir=str(root / f"{tag}-export-r1"),
                task=export["task"],
                source_hashes={**export["source_hashes"], str(ep): sha(ep)},
            )
            eg["argv"][-1] = str(ep)
            eg["expected"] = [
                {
                    "path": export["output"],
                    "task": export["task"],
                    "schema": "independent-teacher-export-v2",
                }
            ]
            egp = root / f"{tag}-export-guardian-v2.json"
            write(egp, eg)
            exported = guarded(root, egp)
            counters["NN0prep_s"] += exported["command_wall_s"]
            records[-1].update(
                export=export["output"], export_stop_SHA=sha(Path(eg["run_dir"]) / "stop.json")
            )
    except BaseException as error:
        failure = repr(error)
        raise
    finally:
        write(
            cfg["output"],
            {
                "task": cfg["task"],
                "schema": "registered-entry-sequence-v2",
                "planned_blocks": cfg["blocks"],
                "records": records,
                "counters_observed_only": counters,
                "failure": failure,
                "unread_failed_inflight_charge": "UNKNOWN; retain individual guardian/raw counters or upper bound",
                "automatic_retry": False,
                "partial_denominators_retained": True,
            },
        )


if __name__ == "__main__":
    main()
