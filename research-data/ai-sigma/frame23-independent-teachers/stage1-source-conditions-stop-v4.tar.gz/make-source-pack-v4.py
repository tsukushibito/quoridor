"""Small source/condition/stop pack, streamed restoration check, no teacher label copy."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tarfile
import time


ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    start = time.monotonic()
    stop = json.loads((ROOT / "stage1-point-stop-v4.json").read_text())
    files = {
        Path(path)
        for path in stop["source_and_payload_SHA"]
        if Path(path).is_relative_to(ROOT) and Path(path).name != "read-metadata-v1"
    }
    for path, expected in stop["source_and_payload_SHA"].items():
        assert sha(path) == expected, path
    for pattern in [
        "*-plan-v*.json",
        "*-guardian-v*.json",
        "*-pipeline-v*.json",
        "block*-native-v2.json",
        "block*-pipeline-result-v2.json",
        "block*-export-result-v2.json",
    ]:
        files.update(ROOT.glob(pattern))
    files.update(
        ROOT / name
        for name in [
            "stage1-point-stop-v4.json",
            "v1-unexecuted-receipt.json",
            "sealed-collection-r1-failure-v3.json",
            "make-source-pack-v4.py",
            "read-metadata.rs",
            "preregister-v1.json",
            "prepare-config-v1.json",
        ]
    )
    members = {str(path.relative_to(ROOT)): sha(path) for path in sorted(files)}
    archive = ROOT / "stage1-source-conditions-stop-v4.tar.gz"
    with tarfile.open(archive, "x:gz", compresslevel=6) as out:
        for path in sorted(files):
            out.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    restored = {}
    with tarfile.open(archive, "r|gz") as source:
        for member in source:
            assert member.isfile() and member.name in members
            stream = source.extractfile(member)
            assert stream is not None
            restored[member.name] = hashlib.sha256(stream.read()).hexdigest()
    assert restored == members
    result = {
        "task": "independent-teachers-285-v2",
        "schema": "small-source-pack-v4",
        "UTC": datetime.now(timezone.utc).isoformat(),
        "archive": str(archive),
        "archive_SHA": sha(archive),
        "archive_bytes": archive.stat().st_size,
        "members": members,
        "all_member_stream_restoration": "PASS",
        "raw_teacher_label_or_densecache_copy": False,
        "read_only_models_binary_shared_sources": "immutable path/SHA references only",
        "command_wall_s": time.monotonic() - start,
        "NN": 0,
        "purpose": "preserve prospective sources/conditions/failed versions/stops for coordinator Git",
        "Git_index_commit_owner": "coordinator only",
    }
    with (ROOT / "stage1-source-pack-receipt-v4.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                key: result[key]
                for key in ["archive_bytes", "command_wall_s", "all_member_stream_restoration"]
            }
        )
    )


if __name__ == "__main__":
    main()
