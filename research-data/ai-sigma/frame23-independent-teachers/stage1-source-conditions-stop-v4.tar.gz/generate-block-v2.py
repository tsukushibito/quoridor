"""One registered 48-family native producer attempt; no automatic retry or relabeling."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = json.loads(Path(parser.parse_args().config).read_text())
    assert not Path(cfg["output"]).exists()
    for path, expected in cfg["source_hashes"].items():
        assert sha(path) == expected, "SOURCE_SHA:" + path
    native = json.loads(Path(cfg["native_config"]).read_text())
    manifest = json.loads(Path(cfg["family_map"]).read_text())
    rows = manifest["families"][cfg["block"] * 48 : (cfg["block"] + 1) * 48]
    assert len(rows) == native["games"] == 48
    assert all(p["native_run_id"] == native["run_id"] for p in rows)
    assert [p["prefix"] for p in rows] == native["openings"]
    assert native["temperature"] == 1.0 and native["simulations"] == 64
    assert not Path(native["output"]).exists()
    began = time.monotonic()
    completed = subprocess.run(cfg["argv"], check=False)
    report_path = Path(native["output"]) / "result.json"
    report = json.loads(report_path.read_text()) if report_path.exists() else None
    nn = None
    if report is not None:
        assert report["schema"] == "quoridor-run-v1" and report["run_id"] == native["run_id"]
        assert report["planned"] == 48 and report["model_sha"] == native["inference"]["model_sha"]
        nn = report["nn_calls"] + report["pump"]["backend_warmup_nn"]
        assert nn <= cfg["physical_NN_upper"]
        planned = json.loads((Path(native["output"]) / "planned.json").read_text())
        assert len(planned) == 48
        for actual, registered in zip(planned, rows, strict=True):
            assert actual["game"] == registered["local_id"]
            assert actual["family"] == registered["native_family"]
            assert actual["opening"] == registered["prefix"]
            assert actual["split"].lower() == registered["split"]
    result = {
        "task": cfg["task"],
        "schema": "independent-teacher-block-v2",
        "block": cfg["block"],
        "planned": 48,
        "native_exit": completed.returncode,
        "native_report_path": str(report_path),
        "native_report_SHA": sha(report_path) if report else None,
        "family_map_SHA": sha(cfg["family_map"]),
        "source_hashes": cfg["source_hashes"],
        "physical_NN": nn,
        "UNKNOWN_charge_if_counter_missing": cfg["physical_NN_upper"],
        "wrapper_native_wall_s": time.monotonic() - began,
        "status": "COMPLETED" if completed.returncode == 0 else "PARTIAL_OR_FAILED",
        "no_success_replenishment": True,
        "future_eval_labels_sent_to_learner": False,
    }
    Path(cfg["output"]).write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    raise SystemExit(completed.returncode)


if __name__ == "__main__":
    main()
