"""Producer finite verification and target-free sealed evaluation reference handoff."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time


ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def absent(identity):
    try:
        fields = Path(f"/proc/{identity['pid']}/stat").read_text().rsplit(")", 1)[1].split()
        return fields[19] != str(identity["start_ticks"])
    except FileNotFoundError:
        return True


def save(name, obj):
    with (ROOT / name).open("x") as stream:
        stream.write(json.dumps(obj, indent=2, allow_nan=False) + "\n")


def main():
    start = time.monotonic()
    checks, public_blocks = [], []
    whitelist = {
        "id",
        "canonical_family",
        "native_family_alias",
        "partition",
        "side",
        "ply",
        "cohort",
        "state_key",
        "history_key",
        "history_key_format",
        "actualSTM_ids",
        "ids_order",
        "STM_distance_f32bits",
        "distance_order",
        "input_signature",
        "prefix",
        "producer_schema",
        "producer_source_SHA",
    }
    for block in [27, 28]:
        tag = f"block{block:02d}"
        for suffix in ["r1", "export-r1"]:
            run = ROOT / f"{tag}-{suffix}"
            stop, process = read(run / "stop.json"), read(run / "process.json")
            assert sha(run / "process.json") == stop["process_SHA"]
            assert process["exit"] == 0 and process["waited"] and stop["waited"]
            assert not process["current_exact_remaining"] and not stop["current_exact_remaining"]
            assert all(absent(i) for i in [process["identity"], *process["recorded_children"]])
            for path, expected in {**stop["source_hashes"], **stop["outputs"]}.items():
                assert sha(path) == expected, path
            checks.append(
                {"run": str(run), "stop_SHA": sha(run / "stop.json"), "current_exact_remaining": []}
            )
        generation = read(ROOT / f"{tag}-pipeline-result-v2.json")
        export = read(ROOT / f"{tag}-export-result-v2.json")
        # Producer only: the report is not included in the public handoff.
        report = read(generation["native_report_path"])
        assert sha(generation["native_report_path"]) == generation["native_report_SHA"]
        assert report["planned"] == len(report["outcomes"]) == 48
        assert all(outcome["status"] == "goal" for outcome in report["outcomes"])
        dataset = Path(generation["native_report_path"]).parent / "dataset"
        manifest = read(dataset / "manifest.json")
        assert sha(dataset / "manifest.json") == export["dataset_manifest_SHA"]
        for shard in manifest["shards"]:
            assert shard["path"].startswith("test-")
            assert sha(dataset / shard["path"]) == shard["sha256"]
        assert export["cache"] is None and export["cache_manifest_SHA"] is None
        assert export["STM_cache_rows_checked"] == 0
        assert export["eligible_by_family"] == "PRODUCER_SEALED_NOT_DELIVERED"
        assert len(export["rows_by_family"]) == 48
        assert sum(export["rows_by_family"].values()) == export["rows"] == manifest["rows"]
        metadata = Path(export["public_target_free_metadata"])
        assert sha(metadata) == export["public_metadata_SHA"]
        count, families = 0, set()
        with metadata.open() as stream:
            for line in stream:
                row = json.loads(line)
                assert set(row) == whitelist and row["partition"] == "sealed_future_eval"
                assert len(row["prefix"]) == row["ply"]
                assert row["side"] == 1 + row["ply"] % 2
                families.add(row["canonical_family"])
                count += 1
        assert count == export["rows"]
        public_blocks.append(
            {
                "block": block,
                "partition": "sealed_future_eval",
                "planned_families": 48,
                "producer_completed_families": 48,
                "raw_input_reference_rows": count,
                "observed_nonempty_families": len(families),
                "public_target_free_metadata": str(metadata),
                "public_metadata_SHA": sha(metadata),
                "rows_by_family": export["rows_by_family"],
                "sealed_dataset_manifest_SHA": export["dataset_manifest_SHA"],
                "producer_export_source_SHA": sha(ROOT / "export-block-v2.py"),
                "labels_or_densecache_delivered": False,
            }
        )
    bg = ROOT / "background-sequence-E27-E28-r1"
    result, state = read(bg / "result.json"), read(bg / "state.json")
    assert result["cleanup_complete"] and not result["remaining"] and result["exit_code"] == 0
    assert absent(state["child"])
    counters = read(ROOT / "sequence-E27-E28-result-v3.json")["counters_observed_only"]
    save(
        "sealed96-producer-acceptance-v3.json",
        {
            "task": "independent-teachers-285-v2",
            "schema": "producer-sealed-acceptance-v3",
            "UTC": datetime.now(timezone.utc).isoformat(),
            "checks": checks,
            "background_result_SHA": sha(bg / "result.json"),
            "all_recorded_exact_absent": True,
            "public_projection": public_blocks,
            "producer_only_label_container_read": True,
            "independent_reviewer_label_container_read": False,
            "counters": counters,
            "collection_command_wall_s": time.monotonic() - start,
            "NN": 0,
            "final_mask": "NOT_FROZEN",
            "oldhistory_compatibility": "UNVERIFIED",
            "producer_self_check_is_independent_certification": False,
        },
    )
    save(
        "sealed96-public-reference-handoff-v3.json",
        {
            "task": "independent-teachers-285-v2",
            "schema": "sealed-targetfree-reference-v3",
            "UTC": datetime.now(timezone.utc).isoformat(),
            "blocks": public_blocks,
            "registration": str(ROOT / "registered-family-map-v2.json"),
            "registration_SHA": sha(ROOT / "registered-family-map-v2.json"),
            "mask_reference": str(ROOT / "mask-reference-amendment-v3.json"),
            "mask_reference_SHA": sha(ROOT / "mask-reference-amendment-v3.json"),
            "planned_families": 96,
            "raw_input_reference_rows": sum(b["raw_input_reference_rows"] for b in public_blocks),
            "labels_winner_pi_value_predictions_errors_in_public_projection": False,
            "sealed_label_container_paths_distributed": False,
            "densecache_created": False,
            "public_history": "hash plus completeprefix; no inferred fullhistory/count",
            "oldhistory_compatibility": "UNVERIFIED",
            "eligible_after_final_OR": "NOT_MEASURED",
            "future_reference_exclusion": "Tseen_final union allVraw; freeze before labels release",
            "producer_self_verification": "source/currentbyte SHA; prefix replay; no independent PASS claimed",
        },
    )
    print(
        json.dumps(
            {
                "future_input_rows": sum(b["raw_input_reference_rows"] for b in public_blocks),
                "command_wall_s": time.monotonic() - start,
                "future_labels_distributed": False,
            }
        )
    )


if __name__ == "__main__":
    main()
