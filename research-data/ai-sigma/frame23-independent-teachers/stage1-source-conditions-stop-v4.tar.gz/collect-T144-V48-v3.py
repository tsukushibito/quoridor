"""Finite saved-artifact handoff; no model, feature generation, or label selection."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time


ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def absent(identity):
    try:
        fields = Path(f"/proc/{identity['pid']}/stat").read_text().rsplit(")", 1)[1].split()
        return fields[19] != str(identity["start_ticks"])
    except FileNotFoundError:
        return True


def main():
    start = time.monotonic()
    checks = []
    blocks = []
    for block in [0, 1, 2, 26]:
        tag = f"block{block:02d}"
        for suffix in ["r1", "export-r1"]:
            run = ROOT / f"{tag}-{suffix}"
            stop = read(run / "stop.json")
            process = read(run / "process.json")
            assert sha(run / "process.json") == stop["process_SHA"]
            assert process["exit"] == 0 and process["waited"] and stop["waited"]
            assert not process["current_exact_remaining"] and not stop["current_exact_remaining"]
            assert all(absent(i) for i in [process["identity"], *process["recorded_children"]])
            for path, expected in {**stop["source_hashes"], **stop["outputs"]}.items():
                assert sha(path) == expected, path
            checks.append(
                {"run": str(run), "stop_SHA": sha(run / "stop.json"), "current_exact_remaining": []}
            )
        generation = read(ROOT / f"{tag}-pipeline-result-v2.json")
        exported = read(ROOT / f"{tag}-export-result-v2.json")
        report = read(generation["native_report_path"])
        assert generation["schema"] == "independent-teacher-block-v2"
        assert exported["schema"] == "independent-teacher-export-v2"
        assert sha(generation["native_report_path"]) == generation["native_report_SHA"]
        assert report["planned"] == 48 and len(report["outcomes"]) == 48
        assert all(outcome["status"] == "goal" for outcome in report["outcomes"])
        dataset = Path(generation["native_report_path"]).parent / "dataset"
        manifest = read(dataset / "manifest.json")
        assert sha(dataset / "manifest.json") == exported["dataset_manifest_SHA"]
        for shard in manifest["shards"]:
            assert sha(dataset / shard["path"]) == shard["sha256"]
        cache = Path(exported["cache"])
        assert sha(cache / "cache.json") == exported["cache_manifest_SHA"]
        cm = read(cache / "cache.json")
        assert cm["allow_test"] is False
        for name, expected in cm["sha256"].items():
            assert sha(cache / cm["files"][name]) == expected
        assert exported["rows"] == cm["rows"] == manifest["rows"]
        assert exported["STM_cache_rows_checked"] == exported["rows"]
        assert len(exported["rows_by_family"]) == 48
        assert sum(exported["rows_by_family"].values()) == exported["rows"]
        public = Path(exported["public_target_free_metadata"])
        assert sha(public) == exported["public_metadata_SHA"]
        whitelist = {
            "id",
            "canonical_family",
            "native_family_alias",
            "partition",
            "side",
            "ply",
            "cohort",
            "state_key",
            "history_key",
            "history_key_format",
            "actualSTM_ids",
            "ids_order",
            "STM_distance_f32bits",
            "distance_order",
            "input_signature",
            "prefix",
            "producer_schema",
            "producer_source_SHA",
        }
        count = 0
        with public.open() as stream:
            for line in stream:
                row = json.loads(line)
                assert set(row) == whitelist
                count += 1
        assert count == exported["rows"]
        process = read(ROOT / f"{tag}-r1/process.json")
        blocks.append(
            {
                "block": block,
                "partition": "train" if block < 26 else "selection",
                "planned": 48,
                "completed_GOAL": 48,
                "rows_before_OR": exported["rows"],
                "NN": generation["physical_NN"],
                "science_wall_s": process["command_wall_s"],
                "cache": str(cache),
                "cache_manifest_SHA": exported["cache_manifest_SHA"],
                "public_metadata": str(public),
                "public_SHA": exported["public_metadata_SHA"],
                "private_input_only_witness": str(
                    ROOT / f"{tag}-targetfree-private-native-v2.jsonl"
                ),
                "private_input_only_SHA": exported["private_target_free_native_metadata_SHA"],
                "rows_by_family": exported["rows_by_family"],
                "source_stop_SHA": sha(ROOT / f"{tag}-r1/stop.json"),
                "export_stop_SHA": sha(ROOT / f"{tag}-export-r1/stop.json"),
            }
        )
    bg = ROOT / "background-sequence-T2-V26-r1"
    result, state = read(bg / "result.json"), read(bg / "state.json")
    assert result["cleanup_complete"] and not result["remaining"] and result["exit_code"] == 0
    assert absent(state["child"])
    payload = {
        "task": "independent-teachers-285-v2",
        "schema": "train144-selection48-handoff-v3",
        "UTC": datetime.now(timezone.utc).isoformat(),
        "registration": str(ROOT / "registered-family-map-v2.json"),
        "registration_SHA": sha(ROOT / "registered-family-map-v2.json"),
        "blocks": blocks,
        "train_families": 144,
        "train_rows_before_OR": 4803,
        "selection_families": 48,
        "selection_rows_before_OR": 1645,
        "old5981_plus_train_before_OR": 10784,
        "accepted_10k_after_OR": "NOT_YET_MEASURED",
        "mask_reference": str(ROOT / "mask-reference-amendment-v3.json"),
        "mask_reference_SHA": sha(ROOT / "mask-reference-amendment-v3.json"),
        "Vraw_newselection_inputrefs": "AVAILABLE; prefit OR predicate/reference SHA required",
        "Tseen_final": "Told all5981 union all actually used train rowrefs across saved weights",
        "oldhistory_compatibility": "UNVERIFIED",
        "future_families": "96 NOT_STARTED",
        "future_labels_distributed": False,
        "independent_model_input_verification": "286 pending",
        "producer_self_verification": "saved sources, raw/cache SHA, STM rows, replay witness",
        "checks": checks,
        "background_cleanup": str(bg / "result.json"),
        "counters": read(ROOT / "sequence-T2-V26-result-v2.json")["counters_observed_only"],
        "collection_command_wall_s": time.monotonic() - start,
        "NN": 0,
        "history_or_actualinput_nonexposure_global_proven": False,
    }
    with (ROOT / "train144-selection48-immutable-handoff-v3.json").open("x") as stream:
        stream.write(json.dumps(payload, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                "train_rows": 4803,
                "selection_rows": 1645,
                "command_wall_s": payload["collection_command_wall_s"],
            }
        )
    )


if __name__ == "__main__":
    main()
