goal quoridor-4lc /170 本人科学停止・最小結果。source bd7ffde0d46f51ec35d8faa4091f526c95ccc914、前165/a78 readonly薄adapter、newbuild/game/GPU/学習0。solo8+parallel32全40 COMPLETE、根648/137f32bits同backend内対応、legalCP actualend<=402/public<=500、全返却zero/次t0前quiescent/closed。NN予算guard204×40=8160で型別停止を事前固定、実到達0。全手NN2491/startup10別、科学成功置換/追加0。

soloCPU2単1：outer5.723927s/runtime3.736830s/phase3.311918s、手NN398/startup2、RAMpeak619491328byte、maxpublic414.893/maxactualadmit400.290/maxcleanup2.531ms、pendingdiscard7/8。parallelCPU2/4/6/8計4logical：outer6.547816s/runtime3.922154s/phase3.378213s、手NN2093/startup8、peak1686081536byte、maxpublic415.200/maxactualadmit401.457/maxcleanup10.494ms、pendingdiscard25/32。全owned観測TIDは許可pool、管理もpool2、currentowner/RAM/topology/次observe非重複admission保存、92 affinity操作0。

source/Model/search/maintimer/observer終端・outerexit0/remaining0/unknown0・登録exactidentity現在不在を有限保存。research-data/ai-sigma/170-native-runtime-ready/science-stop.json SHA b3e9abb87275a1c155b3f8f7efdb31c66972409dc3e92aebad5c507d4e8dde4e。自然/全期/全host/exactkernelCPU保証0、formal_ready=false。pending0の8要求は未観測として保持し補充0。2stateの短runtime診断のみ、terminal-only実ORT取消や一般棋力/NI/大局完走の保証へ格上げ0。

保存helpers/実費mode別集計・全attemptpack/Git/復元/backupを元06:35:22処理/06:50:22提出までに完了し、最大1次案はこの4arena有限成立を条件に単一native modeで小教師生成へ進む別配分。参考batch係数は実測範囲だけ、旧16/大標本のWDL倍率へ適用0。旧165source/rawを編集削除0。
