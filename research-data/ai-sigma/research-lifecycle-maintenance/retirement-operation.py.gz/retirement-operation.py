"""One finite Root-owned obsolete-target retirement; not a production entry."""

import datetime
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tarfile

ROOT = Path("/workspaces/quoridor")
TARGET = (
    ROOT
    / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target"
)
DEST = ROOT / "research-data/ai-sigma/research-lifecycle-maintenance"
PRIVATE = TARGET.parent / "private/quoridor-runner"


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def namespace_users():
    if os.geteuid() != 0:
        child = subprocess.run(
            ["sudo", "-n", "/usr/bin/python3", "-B", __file__, "scan"],
            capture_output=True,
            check=True,
        )
        assert len(child.stdout) < 65536
        return json.loads(child.stdout)
    users = []
    count = 0
    total = 0
    for p in Path("/proc").iterdir():
        if not p.name.isdigit():
            continue
        try:
            count += 1
            assert count < 4096
            links = []
            for name in ["cwd", "exe"]:
                try:
                    links.append(os.readlink(p / name))
                except FileNotFoundError:
                    pass
            for fd in (p / "fd").iterdir():
                try:
                    links.append(os.readlink(fd))
                except FileNotFoundError:
                    pass
            text = (p / "maps").read_text() if (p / "maps").exists() else ""
            total += len(text)
            assert len(text) < 2097152 and total < 33554432
            if (
                any(s == str(TARGET) or s.startswith(str(TARGET) + "/") for s in links)
                or str(TARGET) + "/" in text
            ):
                users.append(int(p.name))
        except FileNotFoundError:
            pass
    return {
        "visible_processes": count,
        "literal_target_users": users,
        "scope": "dated literal cwd/exe/fd/maps only; not host quiet",
    }


def inventory():
    root = TARGET.lstat()
    assert stat.S_ISDIR(root.st_mode) and not TARGET.is_symlink()
    rows = []
    for parent, dirs, files in os.walk(TARGET, followlinks=False):
        for name in dirs + files:
            p = Path(parent) / name
            s = p.lstat()
            assert s.st_dev == root.st_dev
            assert stat.S_ISDIR(s.st_mode) or stat.S_ISREG(s.st_mode)
            rows.append(
                (
                    str(p.relative_to(TARGET)),
                    s.st_dev,
                    s.st_ino,
                    s.st_mode,
                    s.st_size,
                    s.st_mtime_ns,
                    s.st_blocks,
                    s.st_nlink,
                )
            )
            assert len(rows) < 30000
    return sorted(rows)


def main():
    if sys.argv[1:] == ["scan"]:
        print(json.dumps(namespace_users()))
        return
    assert not sys.argv[1:]
    assert TARGET == Path(
        "/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target"
    )
    assert TARGET.resolve() == TARGET
    lock = (ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock").open("a+")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    receipt = {
        "schema": "research.literal-target-retirement.v1",
        "issue": "quoridor-4lc.356",
        "START": utc(),
        "target": str(TARGET),
        "removed": False,
        "primary": None,
    }
    try:
        handoff = (
            ROOT
            / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintenance-integration-v20/source-STOP-binding-v20.json"
        )
        assert (
            hashlib.sha256(handoff.read_bytes()).hexdigest()
            == "64c15c8e918f524a9bf2b912d1a44ea5696f48bb638b91088de6635b2c743e49"
        )
        h = json.loads((handoff.parent / "target-use-handoff-v20.json").read_text())
        assert h["current_owner_active_target_writers_readers"] == []
        assert h["current_owner_jobs_children_TMP"] == [] and h["current_reservation"] == "NONE"
        assert h["paths"]["old_target"]["path"] == str(TARGET)
        receipt["owner_reader_STOP"] = h["current_target_private_path_stat_reader_STOP"]
        receipt["namespace_before"] = namespace_users()
        assert receipt["namespace_before"]["literal_target_users"] == []
        before = inventory()
        private_stat = PRIVATE.stat()
        private_identity = (
            private_stat.st_dev,
            private_stat.st_ino,
            private_stat.st_size,
            private_stat.st_mode,
        )
        # Preserve the compact generated/native/compiler context used by prior records.
        selected = []
        total = 0
        for row in before:
            name = row[0]
            p = TARGET / name
            if stat.S_ISREG(row[3]) and (
                p.suffix in {".d", ".json"}
                or p.name in {"output", "root-output"}
                or (".fingerprint/" in name and p.name.startswith("output-"))
            ):
                data = p.read_bytes()
                total += len(data)
                assert len(data) <= 1048576 and total <= 4194304
                selected.append((name, data, stat.S_IMODE(row[3])))
        archive = io.BytesIO()
        with tarfile.open(fileobj=archive, mode="w:gz") as tar:
            for name, data, mode in selected:
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = mode
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
        blob = archive.getvalue()
        assert len(blob) <= 1048576
        with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as tar:
            for name, data, mode in selected:
                member = tar.getmember(name)
                assert member.mode == mode and tar.extractfile(member).read() == data
        out = DEST / "retired-compiler-context.tar.gz"
        assert not out.exists()
        out.write_bytes(blob)
        # Commit exact custody before any unlink. Root is sole index writer.
        proof = DEST / "retired-compiler-context.json"
        proof.write_text(
            json.dumps(
                {
                    "schema": "research.selected-compiler-context.v1",
                    "target": str(TARGET),
                    "archive_SHA256": hashlib.sha256(blob).hexdigest(),
                    "archive_bytes": len(blob),
                    "source_commit": "1a7ca54253d31e67376d5d7431f3ec446fc9d5be",
                    "members": [
                        {
                            "member": n,
                            "sha256": hashlib.sha256(d).hexdigest(),
                            "bytes": len(d),
                            "mode": f"{m:04o}",
                        }
                        for n, d, m in selected
                    ],
                    "restoration": "all archive members and modes exact in memory",
                    "actual_reader_STOP": utc(),
                },
                indent=2,
            )
            + "\n"
        )
        subprocess.run(
            ["git", "add", str(out), str(proof)], cwd=ROOT, check=True, capture_output=True
        )
        subprocess.run(
            [
                "git",
                "commit",
                "-m",
                "Preserve obsolete common-target compiler context before retirement",
            ],
            cwd=ROOT,
            check=True,
            capture_output=True,
        )
        git_blob = subprocess.run(
            [
                "git",
                "show",
                "HEAD:research-data/ai-sigma/research-lifecycle-maintenance/retired-compiler-context.tar.gz",
            ],
            cwd=ROOT,
            check=True,
            capture_output=True,
        ).stdout
        assert git_blob == blob
        assert inventory() == before
        receipt["namespace_preunlink"] = namespace_users()
        assert receipt["namespace_preunlink"]["literal_target_users"] == []
        receipt["preserved_members"] = len(selected)
        receipt["preserved_logical_B"] = total
        receipt["entry_count"] = len(before)
        receipt["source_reconstruction"] = (
            "Git1a7ca542+retained frozen source patches/config/locks/flags; no bit-identical ELF promise"
        )
        receipt["preunlink_context_commit"] = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, check=True, capture_output=True, text=True
        ).stdout.strip()
        shutil.rmtree(TARGET)
        assert not TARGET.exists()
        s = PRIVATE.stat()
        assert (s.st_dev, s.st_ino, s.st_size, s.st_mode) == private_identity
        receipt["removed"] = True
        receipt["retained_private"] = {
            "path": str(PRIVATE),
            "identity_unchanged": True,
            "qualified": False,
        }
        receipt["whole"] = (
            "same3554GiB/shared1GiBtarget pool serial handover; no global credit or physical freebytes claim"
        )
        receipt["old_failed_whole_fees_HELD_seconds"] = 191.27399532997515
        receipt["hardware_reservation"] = "NONE"
    except BaseException as exc:
        receipt["primary"] = repr(exc)
        raise
    finally:
        receipt["STOP"] = utc()
        receipt["owned_remaining"] = []
        (DEST / "target-retirement-STOP.json").write_text(json.dumps(receipt, indent=2) + "\n")
        fcntl.flock(lock, fcntl.LOCK_UN)
        lock.close()
        print(
            json.dumps(
                {
                    "removed": receipt["removed"],
                    "primary": receipt["primary"],
                    "STOP": receipt["STOP"],
                }
            )
        )


if __name__ == "__main__":
    main()
