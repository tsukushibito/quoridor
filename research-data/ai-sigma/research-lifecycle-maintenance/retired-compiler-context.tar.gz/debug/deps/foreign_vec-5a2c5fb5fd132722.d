/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/foreign_vec-5a2c5fb5fd132722.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/libforeign_vec-5a2c5fb5fd132722.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md:
