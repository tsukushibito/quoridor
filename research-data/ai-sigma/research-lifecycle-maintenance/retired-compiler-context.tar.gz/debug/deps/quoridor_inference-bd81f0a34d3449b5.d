/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/quoridor_inference-bd81f0a34d3449b5.d: crates/quoridor-inference/src/lib.rs

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/libquoridor_inference-bd81f0a34d3449b5.rmeta: crates/quoridor-inference/src/lib.rs

crates/quoridor-inference/src/lib.rs:

# env-dep:CLIPPY_ARGS=--no-deps__CLIPPY_HACKERY__-W__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
