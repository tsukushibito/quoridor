/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/lz4_sys-d612ab4aa31a4017.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lz4-sys-1.11.1+lz4-1.10.0/src/lib.rs

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/liblz4_sys-d612ab4aa31a4017.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lz4-sys-1.11.1+lz4-1.10.0/src/lib.rs

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/liblz4_sys-d612ab4aa31a4017.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lz4-sys-1.11.1+lz4-1.10.0/src/lib.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lz4-sys-1.11.1+lz4-1.10.0/src/lib.rs:
