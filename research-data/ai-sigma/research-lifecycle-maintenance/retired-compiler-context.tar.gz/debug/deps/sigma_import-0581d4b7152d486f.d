/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/sigma_import-0581d4b7152d486f.d: crates/quoridor-runner/src/bin/sigma-import.rs Cargo.toml

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/libsigma_import-0581d4b7152d486f.rmeta: crates/quoridor-runner/src/bin/sigma-import.rs Cargo.toml

crates/quoridor-runner/src/bin/sigma-import.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=--no-deps__CLIPPY_HACKERY__-W__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
