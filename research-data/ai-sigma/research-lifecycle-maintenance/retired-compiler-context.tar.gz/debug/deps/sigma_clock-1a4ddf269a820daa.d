/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/sigma_clock-1a4ddf269a820daa.d: crates/quoridor-runner/tests/sigma_clock.rs crates/quoridor-runner/tests/fixtures/sigma-clock-config.json Cargo.toml

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/libsigma_clock-1a4ddf269a820daa.rmeta: crates/quoridor-runner/tests/sigma_clock.rs crates/quoridor-runner/tests/fixtures/sigma-clock-config.json Cargo.toml

crates/quoridor-runner/tests/sigma_clock.rs:
crates/quoridor-runner/tests/fixtures/sigma-clock-config.json:
Cargo.toml:

# env-dep:CLIPPY_ARGS=--no-deps__CLIPPY_HACKERY__-W__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
