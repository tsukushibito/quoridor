/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/cfg_if-d4fd841ce8570c28.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg-if-1.0.5/src/lib.rs

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/libcfg_if-d4fd841ce8570c28.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg-if-1.0.5/src/lib.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg-if-1.0.5/src/lib.rs:
