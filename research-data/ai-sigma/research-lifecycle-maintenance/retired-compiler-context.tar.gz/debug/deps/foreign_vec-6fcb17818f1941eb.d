/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/foreign_vec-6fcb17818f1941eb.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/libforeign_vec-6fcb17818f1941eb.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/libforeign_vec-6fcb17818f1941eb.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md:
