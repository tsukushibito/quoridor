/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/arrow_format-17c051d325381b6d.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/ipc/mod.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/ipc/generated.rs

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/libarrow_format-17c051d325381b6d.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/ipc/mod.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/ipc/generated.rs

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/debug/deps/libarrow_format-17c051d325381b6d.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/ipc/mod.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/ipc/generated.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/ipc/mod.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/arrow-format-0.8.1/src/ipc/generated.rs:
