/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/release/deps/lz4_sys-b67067d092e6ceba.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lz4-sys-1.11.1+lz4-1.10.0/src/lib.rs

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/release/deps/liblz4_sys-b67067d092e6ceba.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lz4-sys-1.11.1+lz4-1.10.0/src/lib.rs

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/release/deps/liblz4_sys-b67067d092e6ceba.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lz4-sys-1.11.1+lz4-1.10.0/src/lib.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lz4-sys-1.11.1+lz4-1.10.0/src/lib.rs:
