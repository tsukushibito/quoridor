/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/release/deps/pkg_config-0d4ac18a22ab0abf.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pkg-config-0.3.34/src/lib.rs

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/release/deps/libpkg_config-0d4ac18a22ab0abf.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pkg-config-0.3.34/src/lib.rs

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/release/deps/libpkg_config-0d4ac18a22ab0abf.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pkg-config-0.3.34/src/lib.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pkg-config-0.3.34/src/lib.rs:
