/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/release/deps/foreign_vec-28c3d1030e525d57.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/release/deps/libforeign_vec-28c3d1030e525d57.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md

/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/common-software-v4/target/release/deps/libforeign_vec-28c3d1030e525d57.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign_vec-0.1.0/src/docs.md:
