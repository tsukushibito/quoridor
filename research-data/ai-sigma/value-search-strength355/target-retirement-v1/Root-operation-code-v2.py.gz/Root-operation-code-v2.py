"""Finite Root-only custody verification and literal Cargo-cache retirement."""

import argparse
import collections
import datetime
import fcntl
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import shutil
import stat
import subprocess
import tarfile

ROOT = Path("/workspaces/quoridor")
CANON = ROOT / "research-data/ai-sigma/value-search-strength355/target-retirement-v1"
GIT_CUSTODY = "0198ae1"
LITERALS = {
    "351": ROOT / ".worktree/tt-hash-reuse351/.artifacts/tt-hash-reuse351/target",
    "342": ROOT
    / ".worktree/nnue-causal-diagnostic/.artifacts/nnue-causal-diagnosis-v2/target/software-v1",
    "353": ROOT
    / ".worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1/build-target-v1",
}
LOCK = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
FIELDS = ("p", "t", "m", "s", "b", "d", "i", "n", "mt", "ct")


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_receipt(name, value):
    path = CANON / name
    with path.open("x") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


def git_body(name):
    relative = (CANON / name).relative_to(ROOT)
    result = subprocess.run(
        ["git", "show", f"{GIT_CUSTODY}:{relative}"],
        cwd=ROOT,
        capture_output=True,
        check=True,
    )
    return result.stdout


def verify_git_bundle():
    index = json.loads(git_body("Root-preservation-index.json"))
    bodies = {}
    for entry in index["frozen_exact_copies"]:
        data = git_body(entry["name"])
        assert len(data) == entry["bytes"] and sha(data) == entry["SHA256"]
        assert (CANON / entry["name"]).read_bytes() == data
        bodies[entry["name"]] = data
    custody = json.loads(bodies["custody.json"])
    expected = {row["member"]: row for row in custody["selected_target_evidence"]}
    assert len(expected) == 1091
    restored = set()
    with tarfile.open(
        fileobj=io.BytesIO(bodies["selected-target-evidence.tar.gz"]), mode="r:gz"
    ) as archive:
        for member in archive:
            assert member.isfile() and member.name in expected and member.name not in restored
            assert not member.name.startswith("/") and ".." not in Path(member.name).parts
            row = expected[member.name]
            assert member.size == row["bytes"] and member.mode == row["mode"]
            with archive.extractfile(member) as source:
                data = source.read(row["bytes"] + 1)
            assert len(data) == row["bytes"] and sha(data) == row["SHA256"]
            restored.add(member.name)
    assert restored == set(expected)
    return bodies, {
        "Git_commit": GIT_CUSTODY,
        "copied_refs": len(bodies),
        "restored_members": len(restored),
        "restored_expanded_B": sum(row["bytes"] for row in expected.values()),
        "disk_extraction": False,
        "exact_SHA_size_mode": True,
        "all_Git_children_directwait_exit0": True,
    }


def entry(root, path):
    value = path.lstat()
    kind = (
        "dir"
        if stat.S_ISDIR(value.st_mode)
        else "file"
        if stat.S_ISREG(value.st_mode)
        else "REFUSE"
    )
    assert kind != "REFUSE"
    return {
        "p": str(path.relative_to(root)),
        "t": kind,
        "m": stat.S_IMODE(value.st_mode),
        "s": value.st_size,
        "b": value.st_blocks * 512,
        "d": value.st_dev,
        "i": value.st_ino,
        "n": value.st_nlink,
        "mt": value.st_mtime_ns,
        "ct": value.st_ctime_ns,
    }


def inspect_exact(root, expected):
    for ancestor in (root, *root.parents):
        assert not ancestor.is_symlink() and ancestor.is_dir()
    current = [entry(root, root)]
    for base, directories, files in os.walk(root, followlinks=False):
        for name in sorted(directories + files):
            current.append(entry(root, Path(base) / name))
            assert len(current) <= 30000
    actual = {row["p"]: row for row in current}
    assert len(actual) == len(expected)
    assert actual == {row["p"]: {key: row[key] for key in FIELDS} for row in expected}
    assert len({row["d"] for row in current}) == 1
    return current


def namespace_users():
    if os.geteuid() != 0:
        result = subprocess.run(
            ["sudo", "-n", "/usr/bin/python3", "-B", __file__, "scan_namespace"],
            capture_output=True,
            check=True,
            cwd=ROOT,
        )
        assert len(result.stdout) <= 65536
        value = json.loads(result.stdout)
        assert value["matching_literal_users"] == []
        value["privileged_readonly_child_directwait_exit0"] = True
        return value
    users, vanished, unreadable_other_uid = [], 0, []
    scanned = 0
    maps_total = 0
    for process in Path("/proc").iterdir():
        if not process.name.isdigit():
            continue
        try:
            process.stat()
            scanned += 1
            assert scanned <= 4096
            links = []
            for location in ["cwd", "exe"]:
                try:
                    links.append(os.readlink(process / location))
                except FileNotFoundError:
                    pass
            for descriptor in (process / "fd").iterdir():
                try:
                    links.append(os.readlink(descriptor))
                except FileNotFoundError:
                    pass
            with (process / "maps").open() as source:
                text = source.read(2097153)
            assert len(text) <= 2097152
            maps_total += len(text)
            assert maps_total <= 33554432
            hits = sorted(
                {
                    str(root)
                    for root in LITERALS.values()
                    if any(link == str(root) or link.startswith(str(root) + "/") for link in links)
                    or str(root) + "/" in text
                }
            )
            if hits:
                users.append({"pid": int(process.name), "literal_namespaces": hits})
        except FileNotFoundError:
            vanished += 1
    assert not users, users
    return {
        "visible_processes_scanned": scanned,
        "matching_literal_users": users,
        "raced_exit_processes": vanished,
        "other_uid_processes_not_certified": unreadable_other_uid,
        "scope": "Read-only elevated exact literal-namespace cwd/exe/fd/maps snapshot across visible process UIDs; no universal host quiet or future absence certificate.",
    }


def protected_check(bodies):
    manifest = json.loads(bodies["operation-manifest.json"])
    preserved = []
    for operation in manifest["operations"]:
        assert Path(operation["literal_directory"]) == LITERALS[operation["label"]]
        for row in operation["preserved_private_metadata_or_fresh_custody"]:
            path = Path(row["path"])
            value = path.lstat()
            assert stat.S_ISREG(value.st_mode) and not path.is_symlink()
            assert (
                value.st_size,
                stat.S_IMODE(value.st_mode),
                value.st_dev,
                value.st_ino,
                value.st_mtime_ns,
                value.st_ctime_ns,
            ) == (
                row["bytes"],
                row["mode"],
                row["dev"],
                row["inode"],
                row["mtime_ns"],
                row["ctime_ns"],
            )
            preserved.append(
                {
                    "path": str(path),
                    "exact_private_metadata_unchanged": True,
                    "SHA_custody": row["SHA256"],
                    "payload_rehashed_by_Root": False,
                }
            )
    return preserved


def run(command):
    resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
    os.sched_setaffinity(0, {3})
    if command == "scan_namespace":
        assert os.geteuid() == 0
        print(json.dumps(namespace_users()))
        return
    started = utc()
    bodies, restoration = verify_git_bundle()
    if command == "verify":
        write_receipt(
            "Root-Git-restoration-verified.json",
            {
                "issue": "quoridor-4lc.355",
                "START": started,
                "STOP": utc(),
                "restoration": restoration,
                "original_unlink_calls": 0,
                "owned_TMP": [],
                "runtime_grant": False,
            },
        )
        print(json.dumps(restoration))
        return
    assert shutil.rmtree.avoids_symlink_attacks
    assert (
        json.load(open(CANON / "Root-Git-restoration-verified.json"))["restoration"][
            "restored_members"
        ]
        == 1091
    )
    with LOCK.open("r+") as lifetime:
        fcntl.flock(lifetime, fcntl.LOCK_EX | fcntl.LOCK_NB)
        memory = {
            line.split(":")[0]: int(line.split()[1]) * 1024
            for line in Path("/proc/meminfo").read_text().splitlines()
        }
        assert memory["MemAvailable"] >= 4831838208
        filesystem_before = os.statvfs(ROOT)
        rows, inode_counts = {}, collections.Counter()
        unique_blocks = {}
        for label, literal in LITERALS.items():
            expected = [
                json.loads(line)
                for line in gzip.decompress(bodies[f"target-{label}-metadata.jsonl.gz"])
                .decode()
                .splitlines()
            ]
            rows[label] = inspect_exact(literal, expected)
            for row in rows[label]:
                unique_blocks[(row["d"], row["i"])] = row["b"]
                if row["t"] == "file":
                    inode_counts[(row["d"], row["i"])] += 1
        for group in rows.values():
            for row in group:
                if row["t"] == "file":
                    assert row["n"] == inode_counts[(row["d"], row["i"])]
        private_before = protected_check(bodies)
        users_before = namespace_users()
        identity = {
            "pid": os.getpid(),
            "start_ticks": Path(f"/proc/{os.getpid()}/stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19],
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        }
        write_receipt(
            "Root-preunlink-guard-v2.json",
            {
                "issue": "quoridor-4lc.355",
                "UTC": utc(),
                "restoration": restoration,
                "identity": identity,
                "canonical_nonblocking_lifetime": True,
                "users": users_before,
                "exact_map_counts": {key: len(value) for key, value in rows.items()},
                "inode_union_B": sum(unique_blocks.values()),
                "outside_private_metadata": private_before,
                "MemAvailable_B": memory["MemAvailable"],
                "original_target_symlink_special_crossdevice_unknowns": [],
                "scope": "All guarded maps exact BEFORE any unlink; no unknown/newer-reader assumption from closedmetadata alone.",
            },
        )
        removed = []
        for label, literal in LITERALS.items():
            # All shared-inode maps were checked together before unlink. Our own
            # prior hardlink removals alter nlink/ctime in remaining trees.
            assert literal.lstat().st_ino == rows[label][0]["i"]
            namespace_users()
            shutil.rmtree(literal)
            assert not os.path.lexists(literal)
            removed.append(
                {
                    "label": label,
                    "literal_directory": str(literal),
                    "entries_before": len(rows[label]),
                    "absent_after": True,
                }
            )
        private_after = protected_check(bodies)
        assert private_after == private_before
        after_users = namespace_users()
        filesystem_after = os.statvfs(ROOT)
        status = Path("/proc/self/status").read_text()
        hwm = next(line for line in status.splitlines() if line.startswith("VmHWM:"))
        write_receipt(
            "Root-literal-retirement-STOP-v2.json",
            {
                "issue": "quoridor-4lc.355",
                "START": started,
                "source_operation_STOP": utc(),
                "identity": identity,
                "removed": removed,
                "original_inode_union_B": sum(unique_blocks.values()),
                "private_metadata_preserved": private_after,
                "users_after": after_users,
                "own_VmHWM": hwm,
                "continuous_peak": "UNKNOWN",
                "Git_subprocesses": "Directwait exit0 all19; no compiler/native/model/Search/science calls",
                "owned_children_jobs_TMP_remaining": [],
                "filesystem_available_sample_delta_B": filesystem_after.f_bavail
                * filesystem_after.f_frsize
                - filesystem_before.f_bavail * filesystem_before.f_frsize,
                "exclusive_physical_free_bytes": "UNKNOWN; concurrent filesystem activity/reflink attribution not certified",
                "settled_resource_credit": "NOT_ISSUED; separate retention/allocation proof required",
                "old_fees_failed_RAW_masks_UNKNOWN": "retained",
                "outside_source_model_private_science_mutation": 0,
                "runtime_grant": False,
            },
        )
        fcntl.flock(lifetime, fcntl.LOCK_UN)
    print(
        json.dumps(
            {
                "removed": [row["label"] for row in removed],
                "inode_union_B": sum(unique_blocks.values()),
                "credit_granted_B": 0,
                "STOP": utc(),
            }
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["verify", "unlink", "scan_namespace"])
    run(parser.parse_args().command)
