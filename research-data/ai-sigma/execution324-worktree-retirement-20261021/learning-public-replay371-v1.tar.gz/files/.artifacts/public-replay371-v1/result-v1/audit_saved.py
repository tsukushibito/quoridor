"""Final saved-exposure/metric correspondence only; no model or public inputs."""

import hashlib
import importlib.util
import json
from pathlib import Path
import re

ROOT = Path("/workspaces/quoridor")
OWN = ROOT / ".worktree/learning-million/.artifacts/public-replay371-v1"
OUT = OWN / "result-v1"
loader = importlib.util.spec_from_file_location("lc", ROOT / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
with lc.lease():
    lc.physical_and_quiet(
        {
            "limits": {
                "family_B": 2 * 1024**3,
                "host_reserve_B": 4 * 1024**3,
                "worker_cpu": 2,
                "guardian_cpu": 4,
            }
        }
    )
    import numpy as np

    files, arrays, facts = {}, {}, {}
    for arm in ("added_only", "replay"):
        path = OWN / "outputs" / (arm + "-v1") / "exposure.npz"
        ref = lc.bound(path)[0]
        files[arm] = ref
        with np.load(path, allow_pickle=False) as bank:
            arrays[arm] = {k: bank[k].copy() for k in bank.files}
        a = arrays[arm]
        n = 12800 if arm == "added_only" else 6400
        assert a["added_indices"].shape == a["added_reflections"].shape == (n,)
        assert a["added_visits"].shape == (341,)
        expected = np.bincount(a["added_indices"], minlength=341)
        np.testing.assert_array_equal(expected, a["added_visits"])
        assert int(expected.sum()) == n and int(np.count_nonzero(expected)) == 217
        assert len(a["public_indices"]) == len(a["public_visits"])
        assert int(a["public_visits"].sum()) == (0 if arm == "added_only" else 6400)
        assert len(np.unique(a["public_indices"])) == len(a["public_indices"])
        assert np.all(a["public_indices"] >= 0) and np.all(a["public_indices"] < 8413949)
        t = json.loads((path.parent / "training.json").read_bytes())
        # Use the owning retained hash representation exactly, no invented JSON digest.
        assert (
            hashlib.sha256(a["added_indices"].astype("<u4").tobytes()).hexdigest()
            == t["added_stream_SHA256"]
        )
        assert (
            hashlib.sha256(bytes(a["added_reflections"].tolist())).hexdigest()
            == t["added_reflection_SHA256"]
        )
        facts[arm] = {
            "added_seen": n,
            "added_distinct": 217,
            "added_repeat_exposures": n - 217,
            "min_max_visits_on_217": [int(expected[expected > 0].min()), int(expected.max())],
            "public_seen": int(a["public_visits"].sum()),
            "public_distinct": len(a["public_indices"]),
            "public_repeats": int(a["public_visits"].sum()) - len(a["public_indices"]),
        }
        lc.read_ref(ref)
    np.testing.assert_array_equal(
        arrays["added_only"]["added_indices"][:6400], arrays["replay"]["added_indices"]
    )
    np.testing.assert_array_equal(
        arrays["added_only"]["added_reflections"][:6400], arrays["replay"]["added_reflections"]
    )
    pdf = lc.bound(OUT / "public-replay371-comparison.pdf")[0]
    raw = lc.read_ref(pdf)
    assert raw.startswith(b"%PDF-") and raw.rstrip().endswith(b"%%EOF")
    assert b"/Type /Pages" in raw and re.search(rb"/Count 2\b", raw)
    audit = {
        "status": "SAVED_OUTPUT_COUNTERS_AND_PDF_STRUCTURE_MATCH",
        "actual_model_forwards": 0,
        "scope": "Actual saved exposure arrays only; no model/corpus/public/sealed/native reads",
        "exposure_refs": files,
        "facts": facts,
        "exact_added_prefix_and_reflection": True,
        "PDF": pdf,
        "PDF_pages": 2,
        "PDF_raster_visual_inspection": "NOT_PERFORMED; installed PDF raster/text utilities unavailable; owning Matplotlib layout and PDF structure verified; SVG supplied",
        "reader_STOP": lc.stamp(),
        "continuous_RSS_peak": "UNKNOWN",
    }
audit["canonical_lease_RELEASED"] = lc.stamp()
(OUT / "saved-output-audit.json").write_text(json.dumps(audit, indent=2) + "\n")
print(json.dumps(audit))
