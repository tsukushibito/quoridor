"""Materialize normal selected371 fit controls from actual adopted authority/evidence."""

import argparse
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OWNER = ROOT / ".worktree/learning-million"
OWN = OWNER / ".artifacts/public-replay371-v1"
parser = argparse.ArgumentParser()
parser.add_argument("arm", choices=("added_only", "replay"))
parser.add_argument("--prior-manifest", type=Path)
parser.add_argument("--prior-result", type=Path)
args = parser.parse_args()
loader = importlib.util.spec_from_file_location(
    "lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(Path(path), 64 * 1024**2)[0]


def load(reference):
    return lc.document(reference)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    return ref(path)


support = ref(ROOT / "research-data/ai-sigma/public-replay371/support-v1.json")
assert support["sha256"] == "ae6ce3b912191799c9325a11138a7363f15b950285436f3b7051f8197bb7004f"
assert lc.allocated(OWN) + 2 * 1024**2 < 16 * 1024**2
plan = ref(ROOT / "research-data/ai-sigma/teacher-distance-tanh-v1/plan.json")
assert plan["sha256"] == "e8ecd1869d3ceb7c3f5752767ed50630f2e9e98a26e32a658632a6656a65d564"
study = load(plan)["public_replay_study"]
adoption = ref(ROOT / "research-data/ai-sigma/public-replay371/source-plan-adoption-v1.json")
assert adoption["sha256"] == "bd92b21c5f2c3476c9d41fefcd8c070261fdf8bc90ec11ab3493961ee9fd49e2"
for row in load(adoption)["source_and_plan_actual_rows"]:
    lc.read_ref(row["actual_after"])
entry = OWN / "execution-v1" / (args.arm + "-entry-v1")
entry.mkdir()
output = OWN / "outputs" / (args.arm + "-v1")
output.parent.mkdir(exist_ok=True)
assert not output.exists()
(OWN / "TMP").mkdir(exist_ok=True)
tmp = OWN / "TMP" / (args.arm + "-v1")
config = study["paired_fit_configs"][0 if args.arm == "added_only" else 1]
cache_ref = study["added_membership"]
cache = load(cache_ref)
binding = {
    "selected_plan": plan,
    "paired_fit_configs": study["paired_fit_configs"],
    "fit_config_sha": config["sha256"],
    "qualification_forward_rows": 64,
    "schedule_sha256": cache["schedule_sha256"],
    "family_partition_sha256": cache["family_partition_sha256"],
    "dataset": cache["source_binding"],
    **{
        k: study[k]
        for k in (
            "public_membership",
            "public_acceptance",
            "added_membership",
            "diagnostic_indices",
        )
    },
}
if args.arm == "replay":
    assert args.prior_manifest and args.prior_result
    binding.update(
        prior_fit_manifest=ref(args.prior_manifest), prior_fit_result=ref(args.prior_result)
    )
binding_ref = write(entry / "input-binding.json", binding)
build_ref = ref(
    ROOT
    / ".worktree/value-search-strength-arena355/.artifacts/value-search-strength355/ordering368-build-v1/operation-v1/manifest.json"
)
assert build_ref["sha256"] == "70bbce08712e244786232bf0fd6928e9b5f8dab8ecfd8635b8d93415baafb955"
build = load(build_ref)
assert build["status"] == "PASS" and build["cleanup_complete"] and build["remaining"] == []
env_ref = ref(
    ROOT
    / ".worktree/value-search-strength-engineering355/.artifacts/python-environment367-v1/qualified-common-entry-v1.json"
)
assert env_ref["sha256"] == "0c3ac8a56743962140bdc40e4e3b251e2e8a95d7e6ac9551904a3c0f28ca58fa"
environment = load(env_ref)
old = json.loads(
    (OWNER / ".artifacts/lr-comparison366-v1/controls/fit-A-entry-v3/experiment.json").read_bytes()
)
old_q = json.loads(
    (
        OWNER
        / ".artifacts/lr-comparison366-v1/controls/fit-A-entry-v3/numerical-qualification.json"
    ).read_bytes()
)
schedule = old["schedule"]
inputs = [
    plan,
    *study["paired_fit_configs"],
    binding_ref,
    *(
        study[k]
        for k in (
            "public_membership",
            "public_acceptance",
            "added_membership",
            "diagnostic_indices",
        )
    ),
    schedule,
    support,
    adoption,
    env_ref,
]
for k in (
    "regular_interpreter",
    "pyvenv_cfg",
    "root_project",
    "root_lock",
    "root_python_version",
    "layout",
    "public_entry",
    "source_adoption",
):
    inputs.append(environment[k])
for name, width in lc.COMPACT_CACHE_WIDTHS.items():
    path = Path(cache_ref["path"]).parent / name
    inputs.append(
        {
            "path": str(path),
            "sha256": cache["sha256"][name],
            "bytes": cache["file_bytes"][name],
            "mode": "0644",
        }
    )
unchanged = {
    k: old_q["evidence"][k]
    for k in (
        "framework_completion",
        "framework_result",
        "compact_source_adoption",
        "conversion_completion",
        "current_cache_input_interface",
        "actual_produced_cache_interoperability",
    )
}
inputs.extend(unchanged.values())
affected = [
    ref(OWN / "qualification-v1/qualification.json"),
    ref(OWN / "related-v2/qualification.json"),
    ref(OWN / "related-v2/source-STOP-binding.json"),
]
inputs.extend(affected)
if args.arm == "replay":
    inputs.extend([binding["prior_fit_manifest"], binding["prior_fit_result"]])
inputs = list({r["path"]: r for r in inputs}.values())
python = str(lc.project_python())
argv = [
    python,
    "-B",
    "-m",
    "quoridor_training.train",
    "train",
    "--cache",
    str(Path(cache_ref["path"]).parent),
    "--output",
    str(output),
    "--config",
    config["path"],
    "--input-binding",
    binding_ref["path"],
]
warm = load(config)["experiment"]["warm_start"]
experiment = {
    "schema": lc.EXPERIMENT_SCHEMA,
    "phase": "fit",
    "build_manifest": build_ref,
    "config": config,
    "inputs": inputs,
    "models": [{k: warm[k] for k in ("descriptor", "weights", "evaluator_sha256")}],
    "dynamic_libraries": old["dynamic_libraries"],
    "schedule": schedule,
    "numerical_qualification": None,
    "canonical_plan_sha256": plan["sha256"],
    "rules": old["rules"],
    "distance_units": old["distance_units"],
    "value_perspective": old["value_perspective"],
    "planned_slots": 0,
    "batch": None,
    "argv": argv,
}
# This is current fit-correspondence metadata, not a copied numerical campaign or new model PASS.
numerical = lc.numerical_fields(experiment, build)
numerical["evidence"] = {
    "unchanged_primitives_reused_by_reference": unchanged,
    "actual_affected_scopes": affected,
    "actual_common_entry": env_ref,
    "actual_source_adoption": adoption,
    "current_native_Build": build_ref,
    "scope": "Current exact Python fit input/source/model/library correspondence, actual qualified native38/generator47 provenance (native executable NOT run). Reuses unchanged362 framework/compact input/scale/initializer math in exact scopes; new371 sampler/mixed-input/loss/reflection proof64 synthetic forwards + zero-forward cleanup proof. No ordering20-to341 or public native parity claim; no fit/improvement PASS.",
    "scientific_forward_upper": 2000000,
    "qualified_synthetic_forward_rows": 64,
    "no_new_numerical_or_model_forward": True,
}
experiment["numerical_qualification"] = write(entry / "numerical-correspondence.json", numerical)
experiment_ref = write(entry / "experiment.json", experiment)
paths = {
    ROOT / "scripts/dev/research-lifecycle.py",
    ROOT / "scripts/dev/research-job.py",
    ROOT / "python/quoridor_training/cycle_process.py",
    ROOT / "python/quoridor_training/snapshot.py",
    ROOT / "python/quoridor_training/public_replay.py",
}
paths |= {ROOT / "python/quoridor_training" / (name + ".py") for name in lc.FIT_IMPORTS}
caller_refs = [ref(p) for p in sorted(paths)]
names = (
    "training.json",
    "curves.json",
    "curves.csv",
    "exposure.npz",
    "last.pt",
    "last-model/manifest.json",
    "last-model/weights.f32",
    "last-model/training-target.json",
)
spec = {
    "schema": "quoridor.research.lifecycle-intent.v1",
    "kind": "run",
    "owner": str(OWNER),
    "output": str(entry / "operation-v1"),
    "cwd": str(ROOT),
    "artifact": build["artifact"],
    "experiment": experiment_ref,
    "approved_plan": plan,
    "caller_sources": caller_refs,
    "argv": argv,
    "env": {
        "PATH": "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin",
        "PYTHONPATH": str(ROOT / "python"),
        "PYTHONDONTWRITEBYTECODE": "1",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "CUDA_VISIBLE_DEVICES": "",
        "TMPDIR": str(tmp),
        "ORT_DISABLE_TELEMETRY": "1",
    },
    "data_root": str(output),
    "data": [
        {
            "name": "training"
            if n == "training.json"
            else "curves"
            if n == "curves.json"
            else n.replace("/", "_").replace(".", "_"),
            "path": str(output / n),
            "limit_B": 2 * 1024**2,
        }
        for n in names
    ],
    "finalizers": [],
    "support": support,
    "limits": {
        "family_B": 2 * 1024**3,
        "controller_B": 64 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "owned_B": 240 * 1024**2,
        "log_B": 1024**2,
        "free_B": 256 * 1024**2,
        "worker_cpu": 2,
        "guardian_cpu": 4,
    },
    "owned_outputs": [str(OWN)],
    "TMP": str(tmp),
}
# Existing integration-issued support and adopted selected plan authorize this exact normal admission.
spec["intent_sha256"] = lc.canonical_sha(spec)
admission = {
    "schema": "quoridor.research.phase-admission.v1",
    "owner": spec["owner"],
    "limits": spec["limits"],
    "spec_sha256": spec["intent_sha256"],
    "support_sha256": support["sha256"],
    "approved_plan": plan,
    "ready": True,
}
spec["admission"] = write(entry / "admission.json", admission)
intent_ref = write(entry / "intent.json", spec)
job = {
    "issue": "quoridor-4lc.371.1",
    "goal_issue": "quoridor-4lc",
    "thread_id": "01a1100f-6d45-78e0-8a87-84503ff0fbf6",
    "cwd": str(ROOT),
    "argv": [
        python,
        "-B",
        str(ROOT / "scripts/dev/research-lifecycle.py"),
        "run",
        "--intent",
        intent_ref["path"],
        "--sha256",
        intent_ref["sha256"],
    ],
    "end_at": None,
    "notify_until": None,
    "max_runtime_seconds": None,
    "control_interval_seconds": 5,
    "notify_interval_seconds": 10,
    "request_timeout_seconds": 25,
    "log_max_bytes": 1024**2,
    "resource_contract": support["path"],
}
write(entry / "job-config.json", job)
print(
    json.dumps(
        {
            "prepared": str(entry),
            "intent": intent_ref,
            "Build": build_ref,
            "family_B": spec["limits"]["family_B"],
            "forward_rows": 1034547 if args.arm == "added_only" else 615397,
            "no_submission_yet": True,
        }
    )
)
