"""Saved371 metrics only: no models, corpus reads, predictions or checkpoint loading."""

import csv
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.backends.backend_pdf import PdfPages  # noqa: E402

OWN = Path("/workspaces/quoridor/.worktree/learning-million/.artifacts/public-replay371-v1")
OUT = OWN / "result-v1"
OUT.mkdir()
arms = {
    name: json.loads((OWN / "outputs" / (name + "-v1") / "training.json").read_bytes())
    for name in ("added_only", "replay")
}
a, b = arms.values()
assert a["status"] == b["status"] == "COMPLETE"
assert a["curves"][0]["scopes"] == b["curves"][0]["scopes"]
assert a["full_opened_validation"]["initial"] == b["full_opened_validation"]["initial"]
assert a["added_first6400_SHA256"] == b["added_stream_SHA256"]
assert a["added_first6400_reflection_SHA256"] == b["added_reflection_SHA256"]
assert a["forward_rows"] + b["forward_rows"] + 64 == 1650008
scopes = {
    "public_train": "Public T diagnostic (8192)",
    "public_validation": "Opened V diagnostic (8192)",
    "added_train": "Added T (217 rows, 6 families)",
    "added_validation": "Added V (76 rows, 2 families)",
}
labels = {"added_only": "Added-only 64+0", "replay": "Replay 32+32"}
colors = {"added_only": "#c34a36", "replay": "#2365b2"}
rows = []
for arm, value in arms.items():
    assert value["step"] == 200 and value["completed_epochs"] is None
    assert [p["step"] for p in value["curves"]] == list(range(0, 201, 20))
    assert value["learning_rates"] == [0.001 * min(1, u / 20) for u in range(1, 201)]
    for point in value["curves"]:
        for scope, metrics in point["scopes"].items():
            assert (
                metrics["rows"]
                == {
                    "added_train": 217,
                    "added_validation": 76,
                    "public_train": 8192,
                    "public_validation": 8192,
                }[scope]
            )
            for k in ("mse", "sign_accuracy", "saturation_fraction"):
                assert math.isfinite(metrics[k])
            assert 0 <= metrics["mse"] <= 4 and 0 <= metrics["sign_accuracy"] <= 1
            assert 0 <= metrics["saturation_fraction"] <= 1
            rows.append(
                {
                    "arm": arm,
                    "step": point["step"],
                    "scope": scope,
                    **{
                        k: metrics[k]
                        for k in (
                            "rows",
                            "mse",
                            "sign_rows",
                            "sign_accuracy",
                            "saturation_fraction",
                        )
                    },
                }
            )
with (OUT / "all-curves.csv").open("x", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
tables = {}
for scope in scopes:
    tables[scope] = {
        "INITIAL": a["curves"][0]["scopes"][scope],
        "added_only_LAST200": a["curves"][-1]["scopes"][scope],
        "replay_LAST200": b["curves"][-1]["scopes"][scope],
    }
tables["full_opened_validation"] = {
    "INITIAL": a["full_opened_validation"]["initial"],
    "added_only_LAST200": a["full_opened_validation"]["last"],
    "replay_LAST200": b["full_opened_validation"]["last"],
}
summary = {
    "status": "SELECTED_TWO_ARMS_COMPLETE; INTERPRETATION_LIMITED_TO_SAVED_OUTCOME_LEARNING",
    "teacher": "recorded outcome z; row-weighted means",
    "table": tables,
    "exposure": {
        arm: {
            k: v[k]
            for k in (
                "step",
                "added_seen",
                "public_seen",
                "added_distinct",
                "public_distinct",
                "added_repeats",
                "public_repeats",
                "reflected_rows",
                "forward_rows",
                "prior_forward_rows",
                "aggregate_forward_rows",
                "initial_weights_sha",
                "last_weights_sha",
            )
        }
        for arm, v in arms.items()
    },
    "all_work_forwards": 1650008,
    "upper": 2000000,
    "remaining": 349992,
    "INITIAL_correspondence": "Exact four diagnostic banks; shared full openedV bank reused only from original A PASS",
    "added_stream_and_reflection_prefix_exact": True,
    "model_predictions_in_render": 0,
    "learning_rates": a["learning_rates"],
    "evaluation_points": list(range(0, 201, 20)),
    "public_outcome_game_history_rules_lineage": "UNKNOWN",
    "sealed_E_opened": False,
    "limits": [
        "Reduced added repetition is a simultaneous change; not isolated replay-gradient causality",
        "Fixed 50:50 and 200 updates are a diagnostic, not optimality or convergence",
        "Two related added V families; public V was already opened; shared seeds/initializer",
        "No IID/population/strength/legal strategy/default or paused323 implication",
    ],
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
plt.rcParams.update({"font.size": 9, "axes.titlesize": 11, "pdf.fonttype": 42})
pdf_path = OUT / "public-replay371-comparison.pdf"
with PdfPages(pdf_path) as pdf:
    fig, axes = plt.subplots(2, 2, figsize=(11.7, 8.3))
    for ax, (scope, label) in zip(axes.flat, scopes.items()):
        for arm, value in arms.items():
            ax.plot(
                [p["step"] for p in value["curves"]],
                [p["scopes"][scope]["mse"] for p in value["curves"]],
                marker="o",
                markersize=3,
                color=colors[arm],
                label=labels[arm],
            )
        ax.axhline(
            tables[scope]["INITIAL"]["mse"],
            ls="--",
            color="#666666",
            lw=1,
            label="INITIAL reference",
        )
        ax.set(
            title=label,
            xlabel="Completed full-batch updates (64 rows)",
            ylabel="Row-mean squared error on outcome z",
            xticks=list(range(0, 201, 20)),
        )
        ax.grid(alpha=0.2)
        ax.legend(fontsize=8)
    fig.suptitle("371: fixed LR0.001 / fresh BEST43 / outcome-z / preselected LAST200", fontsize=14)
    fig.text(
        0.5,
        0.014,
        "11 evaluation points, not 11 weight snapshots. Same added prefix; replay halves added repetition. No strength or optimal-ratio claim.",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.04, 1, 0.94))
    pdf.savefig(fig)
    fig.savefig(OUT / "mse-curves.svg")
    plt.close(fig)
    fig = plt.figure(figsize=(11.7, 8.3))
    fig.suptitle("INITIAL and LAST200: saved evaluation metrics", fontsize=14)
    ax = fig.add_axes([0.04, 0.42, 0.92, 0.51])
    ax.axis("off")
    cells = []
    for scope, label in {**scopes, "full_opened_validation": "Full opened V (419150)"}.items():
        for model, bank in tables[scope].items():
            cells.append(
                [
                    label,
                    model.replace("_LAST200", " LAST"),
                    str(bank["rows"]),
                    f"{bank['mse']:.6f}",
                    f"{bank['sign_accuracy']:.4%}",
                    f"{bank['saturation_fraction']:.4%}",
                ]
            )
    table = ax.table(
        cellText=cells,
        colLabels=["Scope", "Checkpoint", "Rows", "MSE", "Sign accuracy", "|value| >= 0.9"],
        cellLoc="center",
        loc="center",
        colWidths=[0.28, 0.21, 0.09, 0.12, 0.15, 0.15],
    )
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    table.scale(1, 1.4)
    fig.text(0.05, 0.34, "Exposure and finite-work census", fontsize=12)
    text = [
        "Added-only: 12800 added / 0 public exposures; 217 distinct added, 12583 repeats.",
        "Replay: 6400 added / 6400 public exposures; 217 distinct added, 6183 repeats; 6398 distinct public, 2 repeats.",
        "Fresh independent Adam; LR0.001, updates1..20 linear warmup, then constant; 200 full64 batches each.",
        "A forwards1034547 + B615397 + affected synthetic64 =1650008 <=2000000. Render adds0 forwards.",
        "Full openedV INITIAL evaluated once in A; B reuses exactly that original bank. Each LAST evaluated once.",
        "Row means; sign accuracy uses nonzero-label rows; saturation is measured |prediction| >=0.9.",
        "Replay mitigated public MSE degradation versus added-only, but both worsened versus INITIAL.",
        "Added V also worsened in both. Reduced added repetition is simultaneous, not an isolated replay effect.",
        "Public labels lack complete game/history/termination/rules lineage. Opened V, two related added V families,",
        "shared seeds/initializer limit generalization. No games, sealed E, convergence, optimum or strength claim.",
    ]
    fig.text(0.05, 0.30, "\n".join(text), fontsize=9, va="top", linespacing=1.65)
    pdf.savefig(fig)
    plt.close(fig)
assert pdf_path.stat().st_size <= 8 * 1024**2
print(
    json.dumps(
        {
            "PDF": str(pdf_path),
            "bytes": pdf_path.stat().st_size,
            "pages": 2,
            "curve_rows": len(rows),
            "model_forward_rows": 0,
        }
    )
)
