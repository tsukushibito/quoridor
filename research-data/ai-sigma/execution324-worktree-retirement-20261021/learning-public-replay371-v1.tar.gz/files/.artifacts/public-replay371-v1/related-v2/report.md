# Public replay371 R1 cleanup repair

Only `IndexedPublicCorpus.__init__` and `close` change. Both paths independently attempt every owned map and stream close. Successful handles are removed; failed handles remain with `FAILED_CLOSE_STATE_UNKNOWN`. A `BaseExceptionGroup` preserves the exact originating setup exception first and every returned close exception thereafter. Normal close uses the same all-actions rule. Stage/remaining facts are group notes; the existing trainer error serializer preserves them recursively. No cleanup success is inferred from a returned close error.

One genuinely new synthetic definition passed once through the qualified common entry. It injects setup E after two maps/streams are owned, map-close C and stream-close D, checks E object identity/each secondary/all later close sentinels, then exercises normal close and the maintained trainer finalization receipt. Handles/maps and metadata are explicitly synthetic; tiny local files only, no NumPy arrays/model/public payload/forward/fit updates. The four original definitions and64 forwards remain their original subjects and were not replayed.

Original guardian command wall0.26691446895711124s counted once; controller0.43969450995791703s separate. Full256B capture, direct reaping/handle cleanup complete, remaining[]/TMP absent. ReaderSTOP2026-10-12T03:28:43.113806+00:00 and lease release03:28:43.116726. Returned mask/persist completed versus persisted pending/attempted remain distinct. Continuous peak RSS and exact worker UTC exit UNKNOWN.

Strict zero-fuzz GNU forward/inverse passes for the related thin patch and the complete current-Main patch; gzip reconstructs exact beforeimages. Every byte/AST outside those two methods is exact. Other five-source target/settings/indices/composed publisher7c5b and original3f316/afef remain immutable by reference. Total prospective scientific+qualification forwards1,650,008 of2M; this repair adds zero. Fits unentered; actual related source clearance/Main+selected-plan adoption and fresh normal source/input/fair guards remain required.

R1-only question: does this fixed owning cleanup boundary preserve original primary plus all returned secondary exceptions and attempt all owned closes, with honest states available to the unchanged trainer serialization?

An attempted formatter locator referenced the now-retired research-quality `.venv`; shell returned FileNotFound before any formatter/test child. The installed canonical common entry ran project Ruff format/check/lint successfully. No install or old environment fallback.
