"""Finite owning check of one new371 cleanup definition through existing process controls."""

import importlib.util
import json
import os
from pathlib import Path
import time

ROOT = Path("/workspaces/quoridor")
OWN = Path("/workspaces/quoridor/.worktree/learning-million/.artifacts/public-replay371-v1")
HERE = OWN / "related-v2"
spec = importlib.util.spec_from_file_location(
    "current_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
)
lifecycle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lifecycle)
refs = json.loads((HERE / "bound-inputs.json").read_bytes())
facts = {
    "issue": "quoridor-4lc.371.1",
    "scope": "one synthetic cleanup/error definition; zero forwards/fit updates",
    "primary": None,
    "secondary": [],
}
start = time.monotonic()
try:
    with lifecycle.lease():
        facts["lease_acquired"] = lifecycle.stamp()
        limits = {
            "family_B": 3 * 1024**3,
            "host_reserve_B": 4 * 1024**3,
            "worker_cpu": 2,
            "guardian_cpu": 4,
        }
        lifecycle.physical_and_quiet({"limits": limits})
        facts["physical_guard"] = {
            "at": lifecycle.stamp(),
            "limits": limits,
            "available_RAM_B": lifecycle.process.available_memory(),
            "available_FS_B": __import__("shutil").disk_usage(OWN).free,
        }
        assert facts["physical_guard"]["available_FS_B"] >= 256 * 1024**2
        for ref in refs:
            lifecycle.read_ref(ref, max(1024**2, ref["bytes"]))
        allocated = sum(p.lstat().st_blocks * 512 for p in [OWN, *OWN.rglob("*")])
        assert allocated + 1024**2 <= 4 * 1024**2
        facts["allocated_before_B"] = allocated
        temporary = HERE / "TMP"
        temporary.mkdir()
        deadline = time.monotonic() + 300
        resources = lifecycle.process.CycleResources(
            {
                "max_memory_bytes": 3 * 1024**3 - 64 * 1024**2,
                "max_output_bytes": 4 * 1024**2,
                "host_ram_reserve": 4 * 1024**3,
            },
            OWN,
            deadline,
        )
        command = [
            "/usr/bin/bash",
            str(ROOT / "scripts/dev/project-env.sh"),
            "python",
            "-B",
            str(HERE / "test_public_replay_cleanup.py"),
            "--source",
            str(HERE / "compact_cache.py"),
            "--trainer",
            str(OWN / "source/train.py"),
            "--TMP",
            str(temporary),
            "--result",
            str(HERE / "qualification.json"),
        ]
        env = dict(os.environ)
        env.update(
            {
                k: "1"
                for k in (
                    "OMP_NUM_THREADS",
                    "OPENBLAS_NUM_THREADS",
                    "MKL_NUM_THREADS",
                    "NUMEXPR_NUM_THREADS",
                    "PYTHONDONTWRITEBYTECODE",
                )
            }
        )
        env["CUDA_VISIBLE_DEVICES"] = ""
        capture = lifecycle.Capture(HERE / "full.log", 262144)
        facts["child_command_START"] = lifecycle.stamp()
        try:
            facts["guardian_return"] = lifecycle.process.execute(
                command,
                HERE / "tail.log",
                deadline,
                cpu_core=2,
                resources=resources,
                cwd="/workspaces/quoridor/.worktree/learning-million",
                env=env,
                output_sink=capture,
            )
        except BaseException as error:
            facts["primary"] = lifecycle.error_fact(error)
        finally:
            try:
                capture.close()
            except BaseException as error:
                facts["secondary"].append(lifecycle.error_fact(error))
        facts["directwait_returned_at"] = lifecycle.stamp()
        facts["TMP_remaining"] = [str(p) for p in temporary.rglob("*")]
        if not facts["TMP_remaining"]:
            temporary.rmdir()
        for ref in refs:
            lifecycle.read_ref(ref, max(1024**2, ref["bytes"]))
        facts["source_env_reader_STOP"] = lifecycle.stamp()
        facts["source_env_before_after_MATCH"] = True
        facts["owned_readers_children_jobs_TMP_remaining"] = facts["TMP_remaining"]
except BaseException as error:
    if facts["primary"] is None:
        facts["primary"] = lifecycle.error_fact(error)
    else:
        facts["secondary"].append(lifecycle.error_fact(error))
facts["canonical_lease_RELEASED_at"] = lifecycle.stamp()
facts["controller_wall_seconds"] = time.monotonic() - start
facts["status"] = "PASS" if facts["primary"] is None and not facts["secondary"] else "FAILED"
facts["continuous_peak_RSS_B"] = "UNKNOWN"
(HERE / "STOP.json").write_text(json.dumps(facts, indent=2) + "\n")
print(
    json.dumps(
        {"status": facts["status"], "STOP": str(HERE / "STOP.json"), "primary": facts["primary"]}
    )
)
raise SystemExit(0 if facts["status"] == "PASS" else 1)
