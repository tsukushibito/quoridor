"""Render saved low/high-LR observations only; no model/framework/array entry."""

import argparse
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path
import stat


def read_ref(ref):
    path = Path(ref["path"])
    data = path.read_bytes()
    assert len(data) <= 1048576
    assert len(data) == ref["bytes"]
    assert hashlib.sha256(data).hexdigest() == ref["sha256"]
    assert f"{stat.S_IMODE(path.stat().st_mode):04o}" == ref["mode"]
    return data


def points(ref):
    with gzip.GzipFile(fileobj=io.BytesIO(read_ref(ref))) as stream:
        raw = stream.read(1048577)
    assert len(raw) <= 1048576 and raw.endswith(b"\n")
    result = [json.loads(line) for line in raw.splitlines()]
    assert [p["step"] for p in result] == list(range(0, 201, 20))
    assert [p["completed_epochs"] for p in result] == list(range(0, 51, 5))
    assert all(p["loss_weighting"] == "row" and p["train_scope"] == "full_train" for p in result)
    for p in result:
        assert p["train"]["rows"] == 217 and p["validation"]["rows"] == 76
        for split in ["train", "validation"]:
            for teacher in ["z", "completed_root_raw"]:
                for suffix in ["_mse", "_distance_mse", "_constant_mse", "_T_only_constant"]:
                    assert math.isfinite(p[split][teacher + suffix])
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    config = json.loads(Path(args.inputs).read_bytes())
    assert set(config["series"]) == {"low_A", "low_B", "high_A", "high_B"}
    series = {name: points(ref) for name, ref in config["series"].items()}
    for key, values in series.items():
        base = 0.0001 if key.startswith("low_") else 0.001
        assert values[0]["lr"] == [base]
        for p in values[1:]:
            assert p["lr"] == [base]
    output = Path(args.output)
    assert output.is_absolute() and not output.exists()
    partial = output.with_name(output.name + ".partial")
    assert not partial.exists()
    # Imports occur only in the separately guarded, bounded rendering command.
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    with plt.rc_context({"font.size": 9, "axes.grid": True, "grid.alpha": 0.2}):
        fig, axes = plt.subplots(2, 2, figsize=(13, 9), constrained_layout=True)
        for row, (candidate, training_teacher) in enumerate(
            [("A", "outcome z"), ("B", "raw completed D6")]
        ):
            for column, (teacher, teacher_label) in enumerate(
                [("z", "Outcome z"), ("completed_root_raw", "Raw completed D6")]
            ):
                ax = axes[row, column]
                for lr_name, color in [("low", "#2166ac"), ("high", "#d6604d")]:
                    values = series[lr_name + "_" + candidate]
                    steps = [p["step"] for p in values]
                    for split, style, label in [
                        ("train", "-", "T217"),
                        ("validation", "--", "V76"),
                    ]:
                        ys = [p[split][teacher + "_mse"] for p in values]
                        ax.plot(
                            steps,
                            ys,
                            linestyle=style,
                            marker="o",
                            markersize=3,
                            color=color,
                            label=f"LR {('1e-4' if lr_name == 'low' else '1e-3')} {label}",
                        )
                guide = series["low_" + candidate][0]
                for split, style, label in [("train", ":", "T"), ("validation", "-.", "V")]:
                    for suffix, color, name in [
                        ("_distance_mse", "#555555", "Analytic D"),
                        ("_constant_mse", "#999999", "T-only constant"),
                    ]:
                        target = guide[split][teacher + suffix]
                        for values in series.values():
                            for point in values:
                                assert math.isclose(
                                    point[split][teacher + suffix],
                                    target,
                                    rel_tol=1e-12,
                                    abs_tol=1e-12,
                                )
                        ax.axhline(
                            target,
                            linestyle=style,
                            linewidth=0.8,
                            color=color,
                            label=f"{name} {label}",
                        )
                ax.set_title(
                    f"{candidate}: trained on {training_teacher}; evaluated on {teacher_label}"
                )
                ax.set_xlabel("Optimizer updates")
                ax.set_ylabel("Full-split row-weighted MSE")
                ax.set_xlim(0, 200)
                ax.set_xticks(list(range(0, 201, 40)))
                second = ax.secondary_xaxis("top", functions=(lambda x: x / 4, lambda x: x * 4))
                second.set_xlabel("Completed epochs")
                second.set_xticks(list(range(0, 51, 10)))
                ax.legend(loc="best", fontsize=7, ncol=2)
        fig.suptitle(
            "Same corpus, independent BEST43 warmstarts: LR1e-4 vs LR1e-3\n11 full T/V points; row weighting; frozen own-teacher guides. Opened V contains only two related families.",
            fontsize=12,
        )
        fig.savefig(
            partial,
            format="pdf",
            metadata={
                "Title": "Issue366 low/high learning-rate curves",
                "Subject": "Saved observations only; no prediction or fit replay",
            },
        )
        plt.close(fig)
    assert 0 < partial.stat().st_size <= 8 * 1024**2
    with partial.open("rb") as f:
        os.fsync(f.fileno())
    os.link(partial, output)
    partial.unlink()
    for ref in config["series"].values():
        read_ref(ref)
    print(
        json.dumps(
            {
                "status": "SAVED_CURVES_RENDERED",
                "PDF": str(output),
                "bytes": output.stat().st_size,
                "new_model_forwards": 0,
                "new_fits": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
