"""One affected metadata/dispatch definition, no framework/model/fit execution.

Unrelated native Build/admission/caller/assets ports are labelled fixture stubs.
Interpreter read_ref and both affected publisher functions run unchanged.
"""

import copy
import importlib.util
import json
from pathlib import Path
import resource
import sys
import unittest

resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
ROOT = Path("/workspaces/quoridor")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "python"))
loader = importlib.util.spec_from_file_location("own_publisher", HERE / "research-lifecycle.py")
lifecycle = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lifecycle)
# Import-location-only fixture: adopted production naturally has these paths.
lifecycle.ROOT = ROOT
lifecycle.PILOT_PLAN = ROOT / "research-data/ai-sigma/teacher-distance-tanh-v1/plan.json"
lifecycle.PILOT_DATA = ROOT / ".worktree/assets/data/common-corpus-warmstart-study/pilot-v1"
lifecycle.QUALIFIER = (
    ROOT
    / ".worktree/learning-million/.artifacts/common-corpus-warmstart-study/pilot-v1/test_current_framework.py"
)
ENTRY = HERE.parents[1] / "controls/fit-A-entry-v2"
BASE_SPEC = json.loads((ENTRY / "intent.json").read_bytes())
BASE_EXP = json.loads((ENTRY / "experiment.json").read_bytes())
MANIFEST = json.loads(Path(BASE_EXP["build_manifest"]["path"]).read_bytes())
PLAN = json.loads(Path(BASE_SPEC["approved_plan"]["path"]).read_bytes())
TRAINING = {
    "path": "/home/vscode/.cache/inference/python/cpython-3.14.7-linux-x86_64-gnu/bin/python3.14",
    "sha256": "5a91882290532b2719eaca77c0f3a7448bd73b9214e56df57bc59004560a80c6",
    "bytes": 32418544,
    "mode": "0755",
}
REAL_READ = lifecycle.read_ref


class TrainingInterpreterBoundary(unittest.TestCase):
    def test_bound_interpreter_common_inlet_and_dispatch(self):
        cases = []
        real_reads = []
        native_build_python = copy.deepcopy(MANIFEST["tools"]["PYTHON"])

        def execute_case(phase="fit", change=None, expected_error=None):
            spec, experiment = copy.deepcopy(BASE_SPEC), copy.deepcopy(BASE_EXP)
            experiment["inputs"].append(copy.deepcopy(TRAINING))
            spec["data_root"] = str(HERE / "TMP/nonexistent-fixture-output")
            for item in spec["data"]:
                item["path"] = str(
                    Path(spec["data_root"])
                    / Path(item["path"]).relative_to(Path(BASE_SPEC["data_root"]))
                )
            spec["argv"][8] = spec["data_root"]
            experiment["argv"] = spec["argv"].copy()
            experiment["phase"] = phase
            documents = {
                ref["path"]: json.loads(Path(ref["path"]).read_bytes())
                for ref in [
                    BASE_EXP["config"],
                    BASE_SPEC["experiment"],
                    BASE_SPEC["approved_plan"],
                    BASE_SPEC["admission"],
                ]
            }
            binding_ref = experiment["inputs"][3]
            documents[binding_ref["path"]] = json.loads(Path(binding_ref["path"]).read_bytes())
            for ref in experiment["inputs"]:
                if (
                    ref["path"].endswith("cache.json")
                    or ref in documents[binding_ref["path"]]["paired_fit_configs"]
                ):
                    documents[ref["path"]] = json.loads(Path(ref["path"]).read_bytes())
            if phase == "software-qualification":
                definition = {
                    "path": str(lifecycle.QUALIFIER),
                    "sha256": lifecycle.QUALIFIER_SHA,
                    "bytes": 1,
                    "mode": "0644",
                }
                config = {
                    "definition": definition,
                    "helper_sources": [],
                    "result": str(Path(spec["data_root"]) / "qualification.json"),
                }
                experiment["config"] = {
                    "path": str(HERE / "TMP/fake-software-config.json"),
                    "sha256": "a" * 64,
                    "bytes": 1,
                    "mode": "0644",
                }
                documents[experiment["config"]["path"]] = config
                experiment["inputs"].append(definition)
                experiment["numerical_qualification"] = None
                spec["argv"] = [
                    TRAINING["path"],
                    "-B",
                    str(lifecycle.QUALIFIER),
                    "--result",
                    config["result"],
                ]
                spec["data"] = [
                    {"name": "qualification", "path": config["result"], "limit_B": 65536}
                ]
            elif phase in {"analysis", "compare", "materialize"}:
                experiment["inputs"] = [
                    ref for ref in experiment["inputs"] if ref["path"] != TRAINING["path"]
                ]
                executable = (
                    MANIFEST["tools"]["PYTHON"]["file"]["path"]
                    if phase == "analysis"
                    else MANIFEST["artifact"]["path"]
                )
                spec["argv"] = [executable, "fixture-metadata-only"]
            if change:
                change(spec, experiment)
            experiment["argv"] = spec["argv"].copy()
            documents[spec["experiment"]["path"]] = experiment
            if experiment["numerical_qualification"] is not None:
                documents[experiment["numerical_qualification"]["path"]] = (
                    lifecycle.numerical_fields(experiment, MANIFEST)
                )
            seen = []

            def read_port(ref, limit=lifecycle.CONTROL_BYTES):
                seen.append(ref)
                if ref["path"] == TRAINING["path"]:
                    real_reads.append(ref.copy())
                    return REAL_READ(ref, limit)
                return b"labelled unrelated asset/source fixture"

            # Owning metadata, common inlet, numerical field matching and executable
            # dispatch are real; unrelated Build/source/admission/asset reads are stubs.
            lifecycle.document = lambda ref: copy.deepcopy(documents[ref["path"]])
            lifecycle.accepted_build = lambda *args: copy.deepcopy(MANIFEST)
            lifecycle.approved_plan = lambda *args: copy.deepcopy(PLAN)
            lifecycle.caller_source_refs = lambda *args: []
            lifecycle.build_input_refs = lambda *args: []
            lifecycle.read_ref = read_port
            if expected_error:
                with self.assertRaisesRegex(lifecycle.Refused, expected_error):
                    lifecycle.experiment_check(spec)
            else:
                result = lifecycle.experiment_check(spec)
                if phase in {"fit", "software-qualification"}:
                    self.assertIn(TRAINING, result[2])
                    self.assertIn(TRAINING, seen)
                    # Same FileRef is retained for normal after-command read_ref.
                    REAL_READ(TRAINING, TRAINING["bytes"])
                self.assertEqual(result[0]["phase"], phase)
            self.assertEqual(MANIFEST["tools"]["PYTHON"], native_build_python)
            cases.append({"phase": phase, "expected": expected_error or "accepted"})

        execute_case()
        execute_case(
            change=lambda s, e: e["inputs"].remove(TRAINING),
            expected_error="bound qualified training interpreter",
        )
        execute_case(
            change=lambda s, e: e["inputs"].append(TRAINING.copy()),
            expected_error="bound qualified training interpreter",
        )
        execute_case(
            change=lambda s, e: e["inputs"][-1].update(sha256="0" * 64),
            expected_error="reference drift",
        )
        execute_case(
            change=lambda s, e: s["argv"].__setitem__(0, "/usr/bin/python3.11"),
            expected_error="fit exact trainer",
        )
        execute_case(
            change=lambda s, e: s["argv"].__setitem__(0, "/bin/true"),
            expected_error="fit exact trainer",
        )
        execute_case(phase="software-qualification")
        execute_case(
            phase="software-qualification",
            change=lambda s, e: e["inputs"].remove(TRAINING),
            expected_error="bound qualified training interpreter",
        )
        execute_case(phase="analysis")
        execute_case(
            phase="analysis",
            change=lambda s, e: s["argv"].__setitem__(0, TRAINING["path"]),
            expected_error="executable argv drift",
        )
        execute_case(phase="compare")
        execute_case(phase="materialize")
        self.assertNotIn("torch", sys.modules)
        self.assertNotIn("numpy", sys.modules)
        print(
            json.dumps(
                {
                    "definition": "bound_interpreter_common_inlet_and_dispatch",
                    "cases": cases,
                    "actual_regular_interpreter_identity_reads": len(real_reads),
                    "qualified_build_tools_PYTHON_unchanged": True,
                    "framework_arrays_models_fits_native_calls": 0,
                    "fixture_ports": [
                        "nativeBuild/source",
                        "admission",
                        "caller membership",
                        "unrelated asset reads",
                    ],
                    "owning_common_inlet_dispatch_read_ref": "REAL",
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    unittest.main(argv=[sys.argv[0]], verbosity=2)
