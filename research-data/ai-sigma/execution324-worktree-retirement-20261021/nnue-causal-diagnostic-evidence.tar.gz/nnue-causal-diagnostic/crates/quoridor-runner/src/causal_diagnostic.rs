//! One bounded, history-correct causal campaign. Search/score implementations stay canonical.
use crate::{arena::digest, sigma_qualification::BoundControl};
use quoridor_ai::alphabeta::{
    self, EvalAccumulator, SearchLimits, SearchNamespace, SearchResult, SearchSession,
    StaticEvaluator, StopReason,
};
use quoridor_core::research::{HistoryKey, SigmaContext};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::{
    collections::BTreeSet,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Instant,
};

pub type Result<T> = quoridor_data::Result<T>;
const TT_ENTRIES: usize = 4096;
const TT_BYTES: usize = 1024 * 1024;

#[derive(Clone, Debug)]
struct Parent {
    id: String,
    original_action: u16,
    raw: Value,
}
impl Parent {
    fn context(&self) -> Result<Option<SigmaContext>> {
        let r = &self.raw;
        let prefix: Vec<u16> = serde_json::from_value(r["prefix_actions"].clone())?;
        if digest(&serde_json::to_vec(&prefix)?)
            != r["prefix_SHA256"]
                .as_str()
                .ok_or("original prefix SHA required")?
            || r["ply"].as_u64() != Some(prefix.len() as u64)
            || r["current_mapping"]["ruleset"] != "research-standard-2p-threefold-goal-first-v1"
        {
            return Err("frozen prefix/ply/current rule mapping".into());
        }
        let c = SigmaContext::from_prefix(&prefix)?;
        if c.is_synthetic() || c.terminal_value().is_some() || c.total_ply() >= 200 {
            return Err(
                "original parent is terminal/censored/unsupported in current context".into(),
            );
        }
        let p = c.position();
        if r["native_side"].as_u64() != Some(u64::from(p.turn)) {
            return Err("original STM mapping".into());
        }
        if !r["original_geometry"].is_null() {
            let expected = &r["original_geometry"];
            if expected["pawns"] != json!(p.pawns)
                || expected["stocks"] != json!(p.walls_remaining)
                || expected["horizontal"].as_u64() != Some(p.horizontal)
                || expected["vertical"].as_u64() != Some(p.vertical)
                || expected["turn"].as_u64() != Some(u64::from(p.turn))
            {
                return Err("original geometry mismatch".into());
            }
        }
        let mut pairs: Vec<_> = c
            .history_counts()
            .into_iter()
            .map(|(key, n)| (key.sigma_string(), n))
            .collect();
        pairs.sort();
        if let Some(expected) = r["full_counted_history"]["historical_SHA256"].as_str() {
            if digest(&serde_json::to_vec(&pairs)?) != expected {
                return Err(
                    "original chronology digest mismatch; no reconstructed replacement".into(),
                );
            }
        }
        let features = quoridor_nnue::encode_qf1(p)?;
        if !r["historical_input"].is_null() {
            // Saved Torch input is STM-first. Canonical native views remain absolute-player.
            // This explicit existing correspondence changes neither features nor model input.
            let expected = &r["historical_input"];
            let side = usize::from(features.side);
            let ordered = [&features.ids[side], &features.ids[side ^ 1]];
            let distances: [f32; 2] = serde_json::from_value(expected["distance"].clone())?;
            if expected["ids"] != json!(ordered)
                || distances.map(f32::to_bits) != features.distance.map(f32::to_bits)
                || expected["absolute_STM"].as_u64() != Some(u64::from(p.turn))
                || expected["torch_side"] != 1
            {
                return Err("original QF1/D80/side bits mismatch".into());
            }
            let mut input = Vec::new();
            for ids in ordered {
                for id in 0..312u16 {
                    input.extend_from_slice(
                        &(if ids.contains(&id) { 1f32 } else { 0f32 }).to_le_bytes(),
                    );
                }
            }
            for d in features.distance {
                input.extend_from_slice(&d.to_le_bytes());
            }
            input.extend_from_slice(&1i64.to_le_bytes());
            if digest(&input)
                != expected["input_SHA256"]
                    .as_str()
                    .ok_or("saved input SHA required")?
            {
                return Err("saved QF1+D byte SHA mismatch".into());
            }
        }
        let child = c.play(self.original_action)?;
        let expected_terminal =
            r["original_open_evidence"]["terminal_after_original_action"].as_str();
        if expected_terminal == Some("Goal") && child.position().winner.is_none()
            || expected_terminal == Some("Threefold") && !child.is_repetition_draw()
        {
            return Err("bound legal terminal anchor mismatch".into());
        }
        if let Some(expected) = r["original_open_evidence"]["terminal_D_p1_p2"].as_array() {
            let actual = [
                child.position().wall_distance(0),
                child.position().wall_distance(1),
            ];
            if json!(actual) != json!(expected) {
                return Err("bound terminal geometric distance mismatch".into());
            }
        }
        Ok(Some(c))
    }
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Limits {
    pub per_call_nodes: u64,
    pub aggregate_nodes: u64,
    pub shallow_nodes: u64,
    pub search_calls: usize,
    pub caller_windows: usize,
    pub trace_paths: usize,
    pub standalone_scores: usize,
}
impl Limits {
    fn validate(&self) -> Result<()> {
        if self.per_call_nodes == 0
            || self.per_call_nodes > 8_000_000
            || self.aggregate_nodes == 0
            || self.aggregate_nodes > 256_000_000
            || self.shallow_nodes == 0
            || self.shallow_nodes > 1_000_000
            || self.search_calls == 0
            || self.search_calls > 192
            || self.caller_windows > 16
            || self.trace_paths > 128
            || self.standalone_scores > 256
        {
            return Err("causal finite campaign ceiling".into());
        }
        Ok(())
    }
}
#[derive(Default)]
struct Census {
    admitted_search_attempts: usize,
    admitted_caller_attempts: usize,
    natural_forced_invocations: usize,
    natural_forced_successful_returns: usize,
    natural_forced_error_returns: usize,
    nodes: u64,
    shallow: u64,
    traces: usize,
    scores: usize,
}
impl Census {
    /// Reserve maximum node liability for an error whose counters are unavailable.
    fn admit(&mut self, limits: &Limits, window: bool) -> Option<u64> {
        if (window && self.admitted_caller_attempts >= limits.caller_windows)
            || (!window && self.admitted_search_attempts >= limits.search_calls)
        {
            return None;
        }
        let remaining = limits.aggregate_nodes.checked_sub(self.nodes)?;
        let admitted = remaining.min(limits.per_call_nodes);
        if admitted == 0 {
            return None;
        }
        if window {
            self.admitted_caller_attempts += 1;
        } else {
            self.admitted_search_attempts += 1;
        }
        self.nodes += admitted;
        Some(admitted)
    }
    fn settle(&mut self, admitted: u64, actual: u64) -> Result<()> {
        if actual > admitted {
            return Err("canonical search exceeded admitted node cap".into());
        }
        self.nodes -= admitted - actual;
        Ok(())
    }
}
fn identity(c: &SigmaContext) -> Value {
    let history: Vec<_> = c
        .history_counts()
        .into_iter()
        .map(|(k, n)| (k.history_string(), n))
        .collect();
    json!({"rules":c.ruleset().config_name(),"key":HistoryKey::from(c.position()).history_string(),"history":history,"ply":c.total_ply()})
}
fn namespace(engine: &str, c: &SigmaContext) -> SearchNamespace {
    SearchNamespace {
        evaluator: engine.into(),
        rules: c.ruleset().config_name().into(),
        selectivity: "canonical-pvs-no-policy".into(),
    }
}
fn session(
    eval: Arc<dyn StaticEvaluator>,
    engine: &str,
    c: &SigmaContext,
) -> Result<SearchSession> {
    let session = SearchSession::new(eval, namespace(engine, c), TT_ENTRIES)?;
    if session.tt_capacity() != (TT_ENTRIES, TT_BYTES) {
        return Err("current TT setup mismatch; no resize/reset fallback".into());
    }
    Ok(session)
}
fn search_limits(depth: u16, nodes: u64) -> SearchLimits {
    SearchLimits {
        max_depth: depth,
        max_nodes: nodes,
        time_limit: None,
        tt_entries: TT_ENTRIES,
        use_pvs: true,
        use_tt: true,
    }
}
fn result_value(r: &SearchResult, requested: u16) -> Value {
    json!({"action":r.action,"value_stm":r.value,"requested_depth":requested,"completed_depth":r.completed_depth,
        "matched_complete":r.stop==StopReason::Terminal || (r.stop==StopReason::DepthComplete && r.completed_depth==requested),
        "PV":r.pv,"stop":crate::arena_clock::stop_name(r.stop),"work":crate::arena_clock::alpha_counters(r),
        "search_elapsed_seconds_nested":r.elapsed.as_secs_f64()})
}
fn unknown(reason: &str) -> Value {
    json!({"status":"UNKNOWN","reason":reason})
}
struct SearchObservation {
    record: Value,
    result: Option<SearchResult>,
}
fn natural(
    root: &SigmaContext,
    eval: Arc<dyn StaticEvaluator>,
    engine: &str,
    depth: u16,
    limits: &Limits,
    census: &mut Census,
    cancel: &AtomicBool,
) -> Result<SearchObservation> {
    let Some(admitted) = census.admit(limits, false) else {
        return Ok(SearchObservation {
            record: unknown("fixed aggregate/call budget exhausted"),
            result: None,
        });
    };
    let before = identity(root);
    let start = Instant::now();
    let mut search = match session(eval, engine, root) {
        Ok(s) => s,
        Err(error) => {
            return Ok(SearchObservation {
                record: json!({"status":"UNKNOWN","original_error":error.to_string(),"node_liability_charged":admitted,"actual_nodes":null,"whole_seconds":start.elapsed().as_secs_f64(),"parent_restored":identity(root)==before}),
                result: None,
            });
        }
    };
    census.natural_forced_invocations += 1;
    let outcome = search.search(root, &search_limits(depth, admitted), cancel);
    let whole = start.elapsed().as_secs_f64();
    if identity(root) != before {
        return Err("canonical search parent restoration".into());
    }
    let (tt, metadata) = search.retained_memory_bytes();
    match outcome {
        Ok(r) => {
            census.natural_forced_successful_returns += 1;
            census.settle(admitted, r.stats.nodes)?;
            let record = json!({"status":"OBSERVED","result":result_value(&r,depth),"whole_setup_search_seconds":whole,
                "TT_entries":TT_ENTRIES,"TT_byte_cap":TT_BYTES,"TT_retained_B":tt,"TT_metadata_B":metadata,"parent_restored":true});
            Ok(SearchObservation {
                record,
                result: Some(r),
            })
        }
        Err(error) => {
            census.natural_forced_error_returns += 1;
            Ok(SearchObservation {
                record: json!({"status":"UNKNOWN","original_error":error.to_string(),"node_liability_charged":admitted,"actual_nodes":null,"whole_seconds":whole,"parent_restored":true}),
                result: None,
            })
        }
    }
}
/// A forced first action changes only the supplied root cursor. No copied/pruned engine.
fn forced(
    parent: (&SigmaContext, u16),
    eval: Arc<dyn StaticEvaluator>,
    engine: &str,
    depth: u16,
    limits: &Limits,
    census: &mut Census,
    cancel: &AtomicBool,
) -> Result<Value> {
    let (root, action) = parent;
    let before = identity(root);
    let child = root.play(action)?;
    let observation = natural(&child, eval, engine, depth - 1, limits, census, cancel)?;
    if identity(root) != before {
        return Err("forced parent restoration".into());
    }
    let value = observation
        .result
        .as_ref()
        .and_then(|r| r.value)
        .map(|v| -v);
    let matched = observation.result.as_ref().is_some_and(|r| {
        r.stop == StopReason::Terminal
            || (r.stop == StopReason::DepthComplete && r.completed_depth == depth - 1)
    });
    Ok(
        json!({"forced_action":action,"requested_parent_depth":depth,"parent_value_stm":value,"matched_complete":matched,"child_search":observation.record,"parent_restored":true}),
    )
}
struct TreeNode {
    value: [f32; 2],
    first_moves: Vec<Value>,
    leaf_count: u64,
}
struct TreeEvaluators<'a> {
    eval: [&'a dyn StaticEvaluator; 2],
}
/// One common walk; every legal response is evaluated by BOTH unchanged evaluators.
/// A partial walk never exports a completed minimax/ranking.
fn complete_tree(
    c: &SigmaContext,
    eval: &TreeEvaluators<'_>,
    accumulators: [Option<&EvalAccumulator>; 2],
    depth: u8,
    census: &mut Census,
    limits: &Limits,
    cancel: &AtomicBool,
) -> Result<TreeNode> {
    if cancel.load(Ordering::Relaxed) || census.shallow >= limits.shallow_nodes {
        return Err("complete tree INCOMPLETE: cancellation/node cap".into());
    }
    census.shallow += 1;
    if let Some(v) = c.terminal_value() {
        return Ok(TreeNode {
            value: [v * alphabeta::TERMINAL_SCORE; 2],
            first_moves: Vec::new(),
            leaf_count: 1,
        });
    }
    if depth == 0 {
        let mut value = [0.; 2];
        for i in 0..2 {
            value[i] = eval.eval[i].evaluate(c, accumulators[i])?;
            if !value[i].is_finite() || value[i].abs() > 1. {
                return Err("legacy nonterminal score domain".into());
            }
        }
        return Ok(TreeNode {
            value,
            first_moves: Vec::new(),
            leaf_count: 1,
        });
    }
    let legal = c.legal_ids();
    if legal.is_empty() {
        return Err("unsupported nonterminal without legal responses".into());
    }
    let before = identity(c);
    let mut best = [f32::NEG_INFINITY; 2];
    let mut moves = Vec::new();
    let mut leaf_count = 0;
    for action in legal {
        let child = c.play(action)?;
        let mut next = [None, None];
        if child.terminal_value().is_none() {
            for i in 0..2 {
                next[i] = eval.eval[i].advance_context(accumulators[i], &child)?;
            }
        }
        let node = complete_tree(
            &child,
            eval,
            [next[0].as_ref(), next[1].as_ref()],
            depth - 1,
            census,
            limits,
            cancel,
        )?;
        let values = node.value.map(|v| -v);
        for i in 0..2 {
            best[i] = best[i].max(values[i]);
        }
        leaf_count += node.leaf_count;
        moves.push(json!({"action":action,"values_stm":values,"legal_responses":node.first_moves,"leaf_count":node.leaf_count,"terminal":child.terminal_value()}));
    }
    if identity(c) != before {
        return Err("complete tree parent restoration".into());
    }
    Ok(TreeNode {
        value: best,
        first_moves: moves,
        leaf_count,
    })
}
/// Reading the learner's exact stopped packet is the only public target intake.
pub fn inspect_target(bound: &BoundControl) -> Result<Value> {
    let target: Target = bound.read()?;
    let parents = target.parents()?;
    let mut rows = Vec::new();
    for parent in &parents {
        rows.push(match parent.context() {
            Ok(Some(c))=>json!({"id":parent.id,"status":"SUPPORTED","identity":identity(&c),"terminal":c.terminal_value()}),
            Ok(None)=>json!({"id":parent.id,"status":"UNKNOWN","reason":"unsupported original mapping"}),
            Err(e)=>json!({"id":parent.id,"status":"UNKNOWN","original_error":e.to_string()}),
        });
    }
    Ok(
        json!({"target_sha256":bound.sha256,"parents":rows,"model_calls":0,"search_calls":0,"historical_outcome_relabelled":false,"selection":"sole learner target; no replacement"}),
    )
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(transparent)]
struct Target(Value);
impl Target {
    fn parents(&self) -> Result<Vec<Parent>> {
        let r = &self.0;
        if r["schema"] != "quoridor.nnue-causal.diagnostic-target.v1"
            || r["issue"] != "quoridor-4lc.342.9"
            || r["engineering_issue"] != "quoridor-4lc.342.10"
            || r["selection_frozen_before_new_outputs"] != true
            || r["selection"]["no_fallback_parents"] != true
        {
            return Err("sole learner frozen selection contract".into());
        }
        let rows = r["parents"].as_array().ok_or("parent array")?;
        let mut seen = BTreeSet::new();
        let mut parents = Vec::new();
        for row in rows {
            let id = row["id"]
                .as_str()
                .filter(|s| !s.is_empty())
                .ok_or("parent id")?
                .to_string();
            if !seen.insert(id.clone())
                || row["stratum"].as_str().is_none_or(str::is_empty)
                || row["original_open_evidence"].is_null()
            {
                return Err("parent identity/provenance".into());
            }
            let action: u16 =
                serde_json::from_value(row["candidates"]["original"]["action"].clone())?;
            parents.push(Parent {
                id,
                original_action: action,
                raw: row.clone(),
            });
        }
        let ids: Vec<_> = parents.iter().map(|p| &p.id).collect();
        if rows.is_empty() || rows.len() > 8 || r["selection"]["parent_ids"] != json!(ids) {
            return Err("exact frozen selected parent order/count".into());
        }
        Ok(parents)
    }
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct CampaignPlan {
    pub schema: String,
    pub target: BoundControl,
    pub manifest: BoundControl,
    pub output: std::path::PathBuf,
    pub model_weights_sha256: String,
    pub units: String,
    pub limits: Limits,
    pub depths: Vec<u16>,
    pub current_executable_sha256: String,
    pub current_compiled_sources_sha256: String,
    pub affected_qualification: BoundControl,
}
fn sources() -> std::collections::BTreeMap<&'static str, String> {
    let mut result = crate::compiled_source_bindings();
    result.insert(
        "runner/causal_diagnostic.rs",
        digest(include_bytes!("causal_diagnostic.rs")),
    );
    result.insert("runner/runtime.rs", digest(include_bytes!("runtime.rs")));
    result.insert(
        "runner/sigma_qualification.rs",
        digest(include_bytes!("sigma_qualification.rs")),
    );
    result.insert(
        "nnue/residual.rs",
        digest(include_bytes!("../../quoridor-nnue/src/residual.rs")),
    );
    result
}
/// Exclusive, bounded raw publication. Large parent trees are written once; final report keeps refs.
struct Output {
    root: std::path::PathBuf,
    allocated: usize,
}
impl Output {
    fn create(root: &std::path::Path, intent: &Value) -> Result<Self> {
        std::fs::create_dir(root)?;
        let mut output = Self {
            root: root.into(),
            allocated: 4096,
        };
        output.write(
            "INCOMPLETE",
            &json!({"status":"INCOMPLETE","planned":intent}),
        )?;
        output.write("planned-work.json", intent)?;
        std::fs::File::open(root)?.sync_all()?;
        Ok(output)
    }
    fn write(&mut self, name: &str, value: &Value) -> Result<Value> {
        use std::io::Write;
        if name.contains('/') || name == "." || name == ".." {
            return Err("owned output basename".into());
        }
        let mut raw = serde_json::to_vec(value)?;
        raw.push(b'\n');
        let allocated = raw.len().div_ceil(4096) * 4096;
        // Leave a finite failure/marker margin inside the already supported raw128MiB.
        if self
            .allocated
            .checked_add(allocated)
            .is_none_or(|n| n > 128 * 1024 * 1024 - 65536)
        {
            return Err("owned raw allocation upper; planned remaining work stays UNKNOWN".into());
        }
        let mut file = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(self.root.join(name))?;
        self.allocated += allocated; // Charge failed/partial exclusive files as well.
        file.write_all(&raw)?;
        file.sync_all()?;
        Ok(json!({"path":self.root.join(name),"sha256":digest(&raw),"bytes":raw.len()}))
    }
    fn commit(&self) -> Result<()> {
        std::fs::File::open(&self.root)?.sync_all()?;
        // Last fallible operation: marker absence is the completed-publication boundary.
        std::fs::remove_file(self.root.join("INCOMPLETE"))?;
        Ok(())
    }
    fn failure(
        &mut self,
        error: &dyn std::fmt::Display,
        fallback: &mut dyn std::io::Write,
    ) -> std::io::Result<()> {
        // A failed receipt leaves INCOMPLETE. Report its secondary error only through
        // one fallible channel; never recursively report a fallback error.
        if let Err(secondary)=self.write("failure.json",&json!({"status":"FAILED","primary_error":error.to_string(),"remaining_planned":"UNKNOWN","publication_marker":"INCOMPLETE"})) {
            writeln!(fallback,"causal failure receipt secondary error: {secondary}; primary: {error}")?;
        }
        Ok(())
    }
}
/// Advisory publication/formatting can fail or unwind; return the original outcome object.
fn preserve_outcome<T>(
    outcome: Result<T>,
    report: impl FnOnce(&dyn std::fmt::Display),
) -> Result<T> {
    if let Err(error) = &outcome {
        let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| report(error.as_ref())));
    }
    outcome
}
/// Identity-only port; no Search/model factory is called.
pub fn inspect_bindings(bound: &BoundControl) -> Result<Value> {
    let target: Target = bound.read()?;
    target.parents()?;
    Ok(
        json!({"target_sha256":bound.sha256,"compiled_sources":sources(),
        "compiled_sources_sha256":crate::arena::json_digest(&sources())?,
        "executable_sha256":crate::arena_manifest::file_sha256(&std::env::current_exe()?)?,
        "model_calls":0,"search_calls":0}),
    )
}
fn validate_entry(plan: &CampaignPlan, target: &Target) -> Result<()> {
    plan.limits.validate()?;
    let count = target.parents()?.len();
    if plan.schema != "quoridor.nnue-causal.campaign.v1"
        || plan.depths != [2, 4, 6]
        || plan.units != "BEST51-legacy-D80-logit-residual-tanh"
        || plan.manifest.sha256 != target.0["model"]["expected"]["manifest_expected_SHA256"]
        || plan.model_weights_sha256 != target.0["model"]["expected"]["weights_expected_SHA256"]
        || plan.limits.search_calls != count * 2 * 3 * 4
        || plan.limits.caller_windows != count * 2
        || plan.limits.trace_paths != count * 3
        || plan.limits.standalone_scores != count * 9
        || target.0["candidate_selection"]["existing_genuine_search_proposals_available"] != false
        || target.0["campaign_envelope"]["natural_plus_forced_search_calls_upper"].as_u64()
            != Some(plan.limits.search_calls as u64)
    {
        return Err("exact shared target/work/units/proposal direction".into());
    }
    if crate::arena_manifest::file_sha256(&std::env::current_exe()?)?
        != plan.current_executable_sha256
        || crate::arena::json_digest(&sources())? != plan.current_compiled_sources_sha256
    {
        return Err("actual executable/compiled source identity".into());
    }
    validate_qualification(plan, target)?;
    if !plan.output.is_absolute()
        || plan.output.exists()
        || plan
            .output
            .parent()
            .is_none_or(|p| p.canonicalize().ok().as_deref() != Some(p))
    {
        return Err("fresh canonical output directory required before model IO".into());
    }
    Ok(())
}
const BOUNDARY_CASES: &[&str] = &[
    "causal_census_keeps_unknown_error_liability",
    "causal_partial_proposal_does_not_admit_union",
    "causal_shared_tree_includes_all_responses",
    "causal_shared_tree_cap_has_no_minimax",
    "causal_forced_child_restores_parent_and_sign",
    "causal_output_is_exclusive_and_hashes_saved_bytes",
    "causal_entry_refuses_unbound_coupling",
    "causal_cancelled_receipt_is_not_accepted",
    "causal_legacy_components_match_ordinary_bits",
    "causal_failed_receipt_and_stderr_preserve_primary",
];
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct AffectedQualification {
    schema: String,
    target_sha256: String,
    image_sha256: String,
    compiled_sources_sha256: String,
    manifest_sha256: String,
    weights_sha256: String,
    source_review: BoundControl,
    boundary_tests: BoundControl,
    input_mapping: BoundControl,
    model_input_companion: BoundControl,
}
fn validate_qualification(plan: &CampaignPlan, target: &Target) -> Result<()> {
    let q: AffectedQualification = plan.affected_qualification.read()?;
    if q.schema != "quoridor.nnue-causal.affected-qualification.v1"
        || q.target_sha256 != plan.target.sha256
        || q.image_sha256 != plan.current_executable_sha256
        || q.compiled_sources_sha256 != plan.current_compiled_sources_sha256
        || q.manifest_sha256 != plan.manifest.sha256
        || q.weights_sha256 != plan.model_weights_sha256
    {
        return Err("affected exact image/input/model coupling".into());
    }
    let review: Value = q.source_review.read()?;
    let tests: Value = q.boundary_tests.read()?;
    let mapping: Value = q.input_mapping.read()?;
    if review["status"] != "CLEAR"
        || review["compiled_sources_sha256"] != q.compiled_sources_sha256
        || review["reader_stop"].as_str().is_none_or(str::is_empty)
        || review["remaining"] != json!([])
        || tests["image_sha256"] != q.image_sha256
        || tests["compiled_sources_sha256"] != q.compiled_sources_sha256
        || tests["directwait_cleanup_remaining"] != json!([])
    {
        return Err("stopped source review/actual new-boundary test evidence required".into());
    }
    for &name in BOUNDARY_CASES {
        if tests["cases"][name]["status"] != "PASS" || tests["cases"][name]["exit_code"] != 0 {
            return Err(format!("new boundary qualification missing: {name}").into());
        }
    }
    // Compare the actual newly compiled, model-free replay output, rather than a claimed flag.
    if mapping != inspect_target(&plan.target)? {
        return Err("actual context/input/history mapping receipt mismatch".into());
    }
    let companion: Value = q.model_input_companion.read()?;
    if companion["target_SHA256"] != plan.target.sha256
        || companion["weights"]["SHA256_expected_from_verified_manifest"]
            != plan.model_weights_sha256
    {
        return Err("sole companion target/model binding".into());
    }
    let manifest: quoridor_nnue::residual::ResidualManifest = plan.manifest.read()?;
    let weights_path = plan
        .manifest
        .path
        .parent()
        .ok_or("manifest parent")?
        .join(&manifest.weights);
    if companion["refs"][plan.manifest.path.to_str().ok_or("manifest UTF8 path")?]["SHA256"]
        != plan.manifest.sha256
        || companion["weights"]["path"] != weights_path.to_str().ok_or("weights UTF8 path")?
    {
        return Err("canonical manifest/packed payload path provenance".into());
    }
    let refs = companion["refs"]
        .as_object()
        .ok_or("exact existing qualification refs required")?;
    let mut found_summary = false;
    for (path, info) in refs {
        if info["SHA256"] == "f425274563fab855b05525662e2628aca056e375686179b67076412955047d7d" {
            let summary: Value = BoundControl {
                path: path.into(),
                sha256: info["SHA256"].as_str().ok_or("proof SHA")?.into(),
            }
            .read()?;
            if summary["Scalar_Simd_bits_and_parent_history_ply_undo_PASS"] != true
                || summary["input_current_vs_final_predictions_bit_same"] != true
                || summary["range_permitted32"] != true
                || summary["alerts_passed32"] != true
            {
                return Err("reused exact native input/delta/error proof not qualified".into());
            }
            found_summary = true;
        }
    }
    if !found_summary
        || target.0["model"]["expected"]["weights_expected_SHA256"] != plan.model_weights_sha256
    {
        return Err("reused native proof/model provenance absent".into());
    }
    Ok(())
}
fn complete_proposal(result: &SearchObservation) -> Option<u16> {
    result
        .result
        .as_ref()
        .filter(|r| r.stop == StopReason::DepthComplete && r.completed_depth == 2)
        .and_then(|r| r.action)
}
fn frozen_union(original: u16, results: &[SearchObservation]) -> Option<Vec<u16>> {
    let mut actions = vec![original];
    for result in results {
        let action = complete_proposal(result)?;
        if !actions.contains(&action) {
            actions.push(action);
        }
    }
    Some(actions)
}
fn traced_leaf(
    root: &SigmaContext,
    path: &[u16],
    model: &quoridor_nnue::residual::ResidualModel,
    limits: &Limits,
    census: &mut Census,
) -> Result<Value> {
    if census.traces >= limits.trace_paths || census.scores + 3 > limits.standalone_scores {
        return Ok(unknown("fixed trace/score allocation exhausted"));
    }
    census.traces += 1;
    let before = identity(root);
    let mut leaf = root.clone();
    for &action in path {
        leaf = leaf.play(action)?;
    }
    if let Some(terminal) = leaf.terminal_value() {
        return Ok(
            json!({"path":path,"identity":identity(&leaf),"terminal":terminal,"utility":terminal*alphabeta::TERMINAL_SCORE,
            "terminal_bypass":true,"head_calls":0,"gradient":"UNKNOWN; no training-label inference"}),
        );
    }
    let start = Instant::now();
    let parent = model.full_context(root, quoridor_nnue::EvaluationMode::Scalar)?;
    let parent_bits: Vec<_> = parent
        .values
        .iter()
        .flat_map(|v| v.iter().map(|v| v.to_bits()))
        .collect();
    let mut delta = parent.clone();
    let mut context = root.clone();
    for &action in path {
        context = context.play(action)?;
        delta = model.delta_context(&delta, &context)?;
    }
    let full = model.full_context(&leaf, quoridor_nnue::EvaluationMode::Scalar)?;
    let setup_seconds = start.elapsed().as_secs_f64();
    let mut scratch = model.evaluation_scratch();
    census.scores += 1;
    let head_started = Instant::now();
    let (distance_logit, residual, raw, post) =
        model.legacy_components_with_scratch(&full, &mut scratch)?;
    let head_seconds = head_started.elapsed().as_secs_f64();
    census.scores += 1;
    let delta_parts = model.legacy_components_with_scratch(&delta, &mut scratch)?;
    census.scores += 1;
    let distance = alphabeta::DistanceEvaluator::new(0., 8.).evaluate(&leaf, None)?;
    let max_accumulator_difference = full
        .values
        .iter()
        .zip(&delta.values)
        .flat_map(|(a, b)| a.iter().zip(b).map(|(a, b)| (a - b).abs()))
        .fold(0f32, f32::max);
    let same_parent = parent
        .values
        .iter()
        .flat_map(|v| v.iter().map(|v| v.to_bits()))
        .eq(parent_bits.iter().copied())
        && identity(root) == before;
    let head_match = (post - delta_parts.3).abs() <= 1e-5 + 1e-4 * post.abs();
    let features = quoridor_nnue::encode_qf1(leaf.position())?;
    Ok(
        json!({"status":if same_parent && head_match {"OBSERVED"}else{"UNKNOWN"},"path":path,"identity":identity(&leaf),
        "ids":features.ids,"distance_D80_bits":features.distance.map(f32::to_bits),"native_side":features.side,
        "terminal":false,"canonical_D":distance,"D_logit":distance_logit,"residual_logit":residual,"pre_tanh":raw,"post_tanh":post,
        "delta_components":[delta_parts.0,delta_parts.1,delta_parts.2,delta_parts.3],"max_FT_difference":max_accumulator_difference,
        "same_parent_bits_and_history":same_parent,"full_delta_head_match":head_match,"saturated_FP32":post.abs()==1.,
        "artificial_one_minus_v_squared_proxy":1.-post*post,"actual_current_or_historical_training_gradient":null,
        "observer_FT_setup_update_seconds":setup_seconds,"observer_single_head_seconds":head_seconds,
        "plain_performance_causal_shares":null,"head_calls":2,"standalone_scores":3,"units":"legacy D80 logit; not future raw-step F80"}),
    )
}
/// Single approved campaign; the public caller consumes a hash-bound immutable plan.
/// There is no vector-of-free-models entry and no implicit calibration/warmup/retry.
pub fn run(bound: &BoundControl) -> Result<Value> {
    let whole_started = Instant::now();
    let plan: CampaignPlan = bound.read()?;
    let target: Target = plan.target.read()?;
    validate_entry(&plan, &target)?;
    let parents = target.parents()?;
    let manifest: quoridor_nnue::residual::ResidualManifest = plan.manifest.read()?;
    if manifest.weights_sha != plan.model_weights_sha256
        || manifest.distance_fit.a.to_bits() != 0f32.to_bits()
        || manifest.distance_fit.b.to_bits() != 8f32.to_bits()
    {
        return Err("bound BEST51 legacy distance/logit model required".into());
    }
    let contexts: Vec<_> = parents.iter().map(Parent::context).collect();
    let ids: Vec<_> = parents.iter().map(|p| &p.id).collect();
    let intent = json!({"plan_sha256":bound.sha256,"target_sha256":plan.target.sha256,"parents":ids,
        "depths":[2,4,6],"engines":["D","NNUE"],"initial_proposals":"parent order, D then NNUE, depth2 reused",
        "per_parent_order":"natural depth4,6 engine order; frozen candidate order/depth2,4,6/engine order forced; D,NNUE caller; original,D6PV,NN6PV observer; common depth2 tree",
        "search_call_upper":plan.limits.search_calls,"caller_window_upper":plan.limits.caller_windows,
        "unsupported_or_unentered_planned_slots":"UNKNOWN; no replacement/retry/depth rescue"});
    // Publication reserves the complete planned denominator before model loading or Search.
    let mut output = Output::create(&plan.output, &intent)?;
    let outcome = (|| {
        let model_started = Instant::now();
        let supported = contexts.iter().any(|c| matches!(c, Ok(Some(_))));
        if !supported {
            let report = json!({"status":"UNKNOWN","planned":intent,"all_original_mappings":"unsupported",
                "admitted_search_attempts":0,"admitted_caller_attempts":0,"actual_natural_forced_search_invocations":0,"model_loads":0,"whole_seconds":whole_started.elapsed().as_secs_f64()});
            output.write("campaign-result.json", &report)?;
            output.commit()?;
            return Ok(report);
        }
        // Canonical loader verifies exact packed weight payload SHA/length before evaluation.
        let model = Arc::new(quoridor_nnue::residual::ResidualModel::load(
            &plan.manifest.path,
        )?);
        let model_load_seconds = model_started.elapsed().as_secs_f64();
        let evaluators: [Arc<dyn StaticEvaluator>; 2] = [
            Arc::new(alphabeta::DistanceEvaluator::new(0., 8.)),
            Arc::new(alphabeta::ResidualEvaluator::new(model.clone())),
        ];
        let names = [
            "fixed-D-a0-b8-legacy".to_string(),
            format!("BEST51:{}:legacy", plan.model_weights_sha256),
        ];
        let cancel = Arc::new(AtomicBool::new(false));
        let mut census = Census::default();
        let mut proposals = Vec::new();
        let mut depth2 = Vec::new();
        for (p, context) in parents.iter().zip(&contexts) {
            let mut results = Vec::new();
            for i in 0..2 {
                results.push(match context {
                    Ok(Some(c)) => natural(
                        c,
                        evaluators[i].clone(),
                        &names[i],
                        2,
                        &plan.limits,
                        &mut census,
                        &cancel,
                    )?,
                    _ => SearchObservation {
                        record: unknown("unsupported original current mapping; no replacement"),
                        result: None,
                    },
                });
            }
            let union = frozen_union(p.original_action, &results);
            let current_legal = match (context, &union) {
                (Ok(Some(c)), Some(actions)) => actions.iter().all(|a| c.play(*a).is_ok()),
                _ => false,
            };
            proposals.push(json!({"id":p.id,"candidate_union":union,"current_legal":current_legal,
                "status":if current_legal {"FROZEN_COMPLETE"}else{"UNKNOWN"},
                "D":results[0].record,"NNUE":results[1].record,"target_sha256":plan.target.sha256,
                "historical_outcomes_relabelled":false,"selection":"original then completed depth2 D then NN; deduplicated"}));
            depth2.push(results);
        }
        let mut schedule = Vec::new();
        for (index, p) in parents.iter().enumerate() {
            let mut forced_schedule = Vec::new();
            if proposals[index]["status"] == "FROZEN_COMPLETE" {
                for action in proposals[index]["candidate_union"]
                    .as_array()
                    .ok_or("frozen action array")?
                {
                    for depth in [2, 4, 6] {
                        for engine in &names {
                            forced_schedule
                                .push(json!({"action":action,"depth":depth,"engine":engine}));
                        }
                    }
                }
            }
            schedule.push(json!({"id":p.id,"natural":[[2,0],[2,1],[4,0],[4,1],[6,0],[6,1]],
                "forced":forced_schedule,"forced_if_missing_union":"all planned candidate slots UNKNOWN, unexecuted",
                "caller":[[0,100_000_000,5_000_000],[1,100_000_000,5_000_000]],"caller_requested_depth":SearchLimits::default().max_depth,"tree_depth":2,
                "trace_rules":["original action","D completed depth6 PV","NN completed depth6 PV"]}));
        }
        let frozen = json!({"schema":"quoridor.nnue-causal.candidates.v1","plan_sha256":bound.sha256,"target_sha256":plan.target.sha256,
            "parents":proposals,"ordered_schedule":schedule,"call_upper":plan.limits.search_calls,"depth2_natural_results_reused":true});
        let frozen_ref = output.write("candidate-union-frozen.json", &frozen)?;
        std::fs::File::open(&plan.output)?.sync_all()?;
        let candidates_sha = frozen_ref["sha256"].clone();
        let mut records = Vec::new();
        for (index, p) in parents.iter().enumerate() {
            let context = match &contexts[index] {
                Ok(Some(c)) => c,
                unsupported => {
                    let error = unsupported.as_ref().err().map(ToString::to_string);
                    let row = json!({"id":p.id,"all_planned_stages":unknown("original current mapping unsupported"),"original_error":error,"original":p.raw});
                    records.push(output.write(&format!("parent-{index}.json"), &row)?);
                    continue;
                }
            };
            let mut natural_rows = Vec::new();
            let mut paths = vec![vec![p.original_action]];
            for depth in [2, 4, 6] {
                for i in 0..2 {
                    if depth == 2 {
                        natural_rows.push(json!({"engine":names[i],"depth":depth,"reused":depth2[index][i].record}));
                        continue;
                    }
                    let observed = natural(
                        context,
                        evaluators[i].clone(),
                        &names[i],
                        depth,
                        &plan.limits,
                        &mut census,
                        &cancel,
                    )?;
                    if depth == 6 {
                        paths.push(
                            observed
                                .result
                                .as_ref()
                                .filter(|r| {
                                    r.stop == StopReason::DepthComplete && r.completed_depth == 6
                                })
                                .map(|r| r.pv.clone())
                                .unwrap_or_default(),
                        );
                    }
                    natural_rows
                        .push(json!({"engine":names[i],"depth":depth,"observed":observed.record}));
                }
            }
            let mut forced_rows = Vec::new();
            if frozen["parents"][index]["status"] == "FROZEN_COMPLETE" {
                let actions: Vec<u16> =
                    serde_json::from_value(frozen["parents"][index]["candidate_union"].clone())?;
                for action in actions {
                    for depth in [2, 4, 6] {
                        for i in 0..2 {
                            let result = forced(
                                (context, action),
                                evaluators[i].clone(),
                                &names[i],
                                depth,
                                &plan.limits,
                                &mut census,
                                &cancel,
                            );
                            forced_rows.push(json!({"engine":names[i],"action":action,"depth":depth,"observed":match result {Ok(v)=>v,Err(e)=>json!({"status":"UNKNOWN","original_error":e.to_string()})}}));
                        }
                    }
                }
            } else {
                forced_rows.push(unknown(
                    "proposal union incomplete; forced candidate denominator remains UNKNOWN",
                ));
            }
            let mut caller_rows = Vec::new();
            for i in 0..2 {
                let observed = if let Some(admitted) = census.admit(&plan.limits, true) {
                    let call = crate::runtime::CausalAlphaCall {
                        root: context.clone(),
                        evaluator: evaluators[i].clone(),
                        namespace: namespace(&names[i], context),
                        max_nodes: admitted,
                        depth: SearchLimits::default().max_depth,
                        cancel: cancel.clone(),
                    };
                    match crate::runtime::causal_alpha_receipt(call) {
                        Ok((v, r)) => {
                            if let Some(r) = r {
                                census.settle(admitted, r.stats.nodes)?;
                            }
                            v
                        }
                        Err(e) => {
                            json!({"status":"UNKNOWN","original_error":e.to_string(),"node_liability_charged":admitted})
                        }
                    }
                } else {
                    unknown("fixed aggregate/caller allocation exhausted")
                };
                caller_rows.push(json!({"engine":names[i],"observed":observed}));
            }
            let mut trace = Vec::new();
            for path in paths {
                trace.push(if path.is_empty() {
                    unknown("requested completed PV trace unavailable; no replacement")
                } else {
                    match traced_leaf(context, &path, &model, &plan.limits, &mut census) {
                        Ok(v) => v,
                        Err(e) => json!({"status":"UNKNOWN","original_error":e.to_string()}),
                    }
                });
            }
            let before_shallow = census.shallow;
            let tree = (|| {
                let a = evaluators[0].prepare_context(context)?;
                let b = evaluators[1].prepare_context(context)?;
                complete_tree(
                    context,
                    &TreeEvaluators {
                        eval: [evaluators[0].as_ref(), evaluators[1].as_ref()],
                    },
                    [a.as_ref(), b.as_ref()],
                    2,
                    &mut census,
                    &plan.limits,
                    &cancel,
                )
            })();
            let tree_record = match tree {
                Ok(t) => {
                    json!({"status":"COMPLETE","value_stm":t.value,"all_legal_firstmoves_and_responses":t.first_moves,"leaf_count":t.leaf_count,"expanded_or_leaf_nodes":census.shallow-before_shallow,"optimal_truth":false})
                }
                Err(e) => {
                    json!({"status":"INCOMPLETE","original_error":e.to_string(),"minimax":null,"expanded_or_leaf_nodes":census.shallow-before_shallow})
                }
            };
            let row = json!({"id":p.id,"parent_identity":identity(context),"natural":natural_rows,"forced":forced_rows,"caller100ms":caller_rows,"observer_traces":trace,"common_complete_depth2_tree":tree_record,"original_historical":p.raw,"candidate_freeze_sha256":candidates_sha});
            records.push(output.write(&format!("parent-{index}.json"), &row)?);
        }
        let drop_started = Instant::now();
        drop(evaluators);
        drop(model);
        let model_drop_seconds = drop_started.elapsed().as_secs_f64();
        let report = json!({"schema":"quoridor.nnue-causal.campaign-result.v1","status":"PLANNED_STAGES_COLLECTED_NOT_STRENGTH","plan_sha256":bound.sha256,"target_sha256":plan.target.sha256,"candidate_freeze":frozen_ref,
            "parents":records,"planned_search_call_upper":plan.limits.search_calls,"planned_caller_windows":plan.limits.caller_windows,
            "admitted_search_attempts":census.admitted_search_attempts,"admitted_caller_attempts":census.admitted_caller_attempts,
            "actual_natural_forced_search_invocations":census.natural_forced_invocations,"natural_forced_successful_returns":census.natural_forced_successful_returns,"natural_forced_error_returns":census.natural_forced_error_returns,
            "caller_invocation_return_and_acceptance_census":"per caller TT_and_whole_work and receipt; failed worker without returned counters UNKNOWN","deeper_node_liability":census.nodes,
            "common_tree_nodes":census.shallow,"trace_paths":census.traces,"standalone_scores":census.scores,
            "model_load_seconds_nested":model_load_seconds,"model_drop_seconds_nested":model_drop_seconds,
            "whole_prepublication_seconds":whole_started.elapsed().as_secs_f64(),"model_units":plan.units,"FT_mode":"unchanged Scalar","compiled_sources":sources(),
            "interpretation":"purposive diagnostics; matched complete depth required; observer overhead not plain causal shares; deeperD/consensus not truth; no strength or training labels"});
        output.write("campaign-result.json", &report)?;
        output.commit()?;
        Ok(report)
    })();
    preserve_outcome(outcome, |error| {
        let mut fallback = std::io::stderr().lock();
        let _ = output.failure(error, &mut fallback);
    })
}

#[cfg(test)]
mod boundary_tests {
    use super::*;
    use std::{sync::atomic::AtomicUsize, time::Duration};
    struct Constant {
        value: f32,
        calls: AtomicUsize,
    }
    impl Constant {
        fn new(value: f32) -> Self {
            Self {
                value,
                calls: AtomicUsize::new(0),
            }
        }
    }
    impl StaticEvaluator for Constant {
        fn evaluate(
            &self,
            _: &SigmaContext,
            _: Option<&EvalAccumulator>,
        ) -> alphabeta::Result<f32> {
            self.calls.fetch_add(1, Ordering::Relaxed);
            Ok(self.value)
        }
    }
    fn limits() -> Limits {
        Limits {
            per_call_nodes: 1000,
            aggregate_nodes: 10000,
            shallow_nodes: 100000,
            search_calls: 10,
            caller_windows: 2,
            trace_paths: 3,
            standalone_scores: 9,
        }
    }
    fn observation(action: u16, stop: StopReason) -> SearchObservation {
        SearchObservation {
            record: json!({}),
            result: Some(SearchResult {
                action: Some(action),
                value: Some(0.),
                completed_depth: 2,
                pv: vec![action],
                stats: Default::default(),
                stop,
                elapsed: Duration::ZERO,
            }),
        }
    }
    #[test]
    fn causal_census_keeps_unknown_error_liability() {
        let mut c = Census::default();
        let mut l = limits();
        l.aggregate_nodes = 1500;
        assert_eq!(c.admit(&l, false), Some(1000)); // Unreturned error retains its full liability.
        assert_eq!(c.admitted_search_attempts, 1);
        assert_eq!(c.natural_forced_invocations, 0);
        let admitted = c.admit(&l, false).unwrap();
        assert_eq!(admitted, 500);
        assert!(c.settle(admitted, 501).is_err());
        assert_eq!(c.nodes, 1500);
        assert_eq!(c.admit(&l, true), None);
        c.settle(admitted, 20).unwrap();
        assert_eq!(c.nodes, 1020);
        assert_eq!(c.admit(&l, true), Some(480));
    }
    #[test]
    fn causal_partial_proposal_does_not_admit_union() {
        let completed = observation(3, StopReason::DepthComplete);
        let partial = observation(13, StopReason::NodeLimit);
        assert!(frozen_union(5, &[completed, partial]).is_none());
        assert_eq!(
            frozen_union(
                5,
                &[
                    observation(3, StopReason::DepthComplete),
                    observation(3, StopReason::DepthComplete)
                ]
            ),
            Some(vec![5, 3])
        );
    }
    #[test]
    fn causal_shared_tree_includes_all_responses() {
        let root = SigmaContext::from_prefix(&[]).unwrap();
        let before = identity(&root);
        let a = Constant::new(0.25);
        let b = Constant::new(-0.5);
        let mut c = Census::default();
        let t = complete_tree(
            &root,
            &TreeEvaluators { eval: [&a, &b] },
            [None, None],
            2,
            &mut c,
            &limits(),
            &AtomicBool::new(false),
        )
        .unwrap();
        assert_eq!(t.first_moves.len(), root.legal_ids().len());
        for row in &t.first_moves {
            let child = root.play(row["action"].as_u64().unwrap() as u16).unwrap();
            assert_eq!(
                row["legal_responses"].as_array().unwrap().len(),
                child.legal_ids().len()
            );
        }
        assert_eq!(a.calls.load(Ordering::Relaxed), t.leaf_count as usize);
        assert_eq!(b.calls.load(Ordering::Relaxed), t.leaf_count as usize);
        assert_eq!(t.value, [0.25, -0.5]);
        assert_eq!(identity(&root), before);
    }
    #[test]
    fn causal_shared_tree_cap_has_no_minimax() {
        let root = SigmaContext::from_prefix(&[]).unwrap();
        let before = identity(&root);
        let a = Constant::new(0.25);
        let mut c = Census::default();
        let mut l = limits();
        l.shallow_nodes = 3;
        let result = complete_tree(
            &root,
            &TreeEvaluators { eval: [&a, &a] },
            [None, None],
            2,
            &mut c,
            &l,
            &AtomicBool::new(false),
        );
        assert!(result.is_err());
        assert_eq!(c.shallow, 3);
        assert_eq!(identity(&root), before);
    }
    #[test]
    fn causal_forced_child_restores_parent_and_sign() {
        let root = SigmaContext::from_prefix(&[]).unwrap();
        let before = identity(&root);
        let mut c = Census::default();
        let row = forced(
            (&root, 13),
            Arc::new(Constant::new(0.25)),
            "mock",
            2,
            &limits(),
            &mut c,
            &AtomicBool::new(false),
        )
        .unwrap();
        assert_eq!(row["parent_value_stm"], 0.25);
        assert_eq!(row["matched_complete"], true);
        assert_eq!(row["child_search"]["result"]["requested_depth"], 1);
        assert_eq!(c.admitted_search_attempts, 1);
        assert_eq!(identity(&root), before);
    }
    #[test]
    fn causal_output_is_exclusive_and_hashes_saved_bytes() {
        let base = std::env::var_os("CAUSAL_NN0_TMP").expect("owned admitted test TMP required");
        let root = std::path::PathBuf::from(base)
            .join(format!("causal-publication-{}", std::process::id()));
        let mut out = Output::create(&root, &json!({"planned":2})).unwrap();
        let bound = out
            .write("candidate.json", &json!({"actions":[13,75]}))
            .unwrap();
        let raw = std::fs::read(root.join("candidate.json")).unwrap();
        assert_eq!(bound["sha256"], digest(&raw));
        assert_eq!(raw.last(), Some(&b'\n'));
        assert!(
            out.write("candidate.json", &json!({"changed":true}))
                .is_err()
        );
        assert_eq!(std::fs::read(root.join("candidate.json")).unwrap(), raw);
        assert!(root.join("INCOMPLETE").exists());
        out.commit().unwrap();
        assert!(!root.join("INCOMPLETE").exists());
        for name in ["planned-work.json", "candidate.json"] {
            std::fs::remove_file(root.join(name)).unwrap();
        }
        std::fs::remove_dir(root).unwrap();
    }
    #[test]
    fn causal_entry_refuses_unbound_coupling() {
        let nonexistent = BoundControl {
            path: "/unbound-causal-evidence.json".into(),
            sha256: "0".repeat(64),
        };
        let p = CampaignPlan {
            schema: "quoridor.nnue-causal.campaign.v1".into(),
            target: nonexistent.clone(),
            manifest: nonexistent.clone(),
            output: "/unbound-output".into(),
            model_weights_sha256: "0".repeat(64),
            units: "BEST51-legacy-D80-logit-residual-tanh".into(),
            limits: limits(),
            depths: vec![2, 4, 6],
            current_executable_sha256: "0".repeat(64),
            current_compiled_sources_sha256: "0".repeat(64),
            affected_qualification: nonexistent,
        };
        assert!(validate_qualification(&p, &Target(json!({}))).is_err());
    }
    #[test]
    fn causal_failed_receipt_and_stderr_preserve_primary() {
        struct Broken {
            attempted: Vec<u8>,
        }
        impl std::io::Write for Broken {
            fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
                self.attempted.extend_from_slice(bytes);
                Err(std::io::Error::new(
                    std::io::ErrorKind::BrokenPipe,
                    "injected stderr failure",
                ))
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let base = std::env::var_os("CAUSAL_NN0_TMP").expect("owned admitted test TMP required");
        let root =
            std::path::PathBuf::from(base).join(format!("causal-failure-{}", std::process::id()));
        let mut out = Output::create(&root, &json!({"planned":2})).unwrap();
        out.write("failure.json", &json!({"old_failure":"must remain"}))
            .unwrap();
        let before = std::fs::read(root.join("failure.json")).unwrap();
        let primary: Box<dyn std::error::Error + Send + Sync> =
            Box::new(std::io::Error::other("original campaign E"));
        let pointer = primary.as_ref() as *const _ as *const ();
        let mut fallback = Broken {
            attempted: Vec::new(),
        };
        let outcome: Result<()> = preserve_outcome(Err(primary), |e| {
            assert!(out.failure(e, &mut fallback).is_err());
        });
        let returned = outcome.unwrap_err();
        assert_eq!(returned.as_ref() as *const _ as *const (), pointer);
        assert_eq!(returned.to_string(), "original campaign E");
        assert!(!fallback.attempted.is_empty());
        assert!(root.join("INCOMPLETE").exists());
        assert_eq!(std::fs::read(root.join("failure.json")).unwrap(), before);
        let primary: Box<dyn std::error::Error + Send + Sync> = Box::new(std::io::Error::other(
            "original E despite unexpected reporter unwind",
        ));
        let pointer = primary.as_ref() as *const _ as *const ();
        let returned = preserve_outcome::<()>(Err(primary), |_| {
            panic!("injected advisory reporter unwind")
        })
        .unwrap_err();
        assert_eq!(returned.as_ref() as *const _ as *const (), pointer);
        for name in ["planned-work.json", "failure.json", "INCOMPLETE"] {
            std::fs::remove_file(root.join(name)).unwrap();
        }
        std::fs::remove_dir(root).unwrap();
    }
    #[test]
    fn causal_cancelled_receipt_is_not_accepted() {
        let root = SigmaContext::from_prefix(&[]).unwrap();
        let evaluator = Arc::new(Constant::new(0.));
        let (row, _) = crate::runtime::causal_alpha_receipt(crate::runtime::CausalAlphaCall {
            namespace: namespace("mock", &root),
            root,
            evaluator,
            max_nodes: 100,
            depth: 2,
            cancel: Arc::new(AtomicBool::new(true)),
        })
        .unwrap();
        assert_eq!(row["accepted"], false);
        assert_eq!(row["acceptance_failure"], "Cancelled");
        assert_eq!(row["matching_reply_drained"], true);
        assert!(
            row["opponent_may_start_after_ns"].as_u64().unwrap()
                >= row["authority_receipt_ns"].as_u64().unwrap()
        );
    }
}
