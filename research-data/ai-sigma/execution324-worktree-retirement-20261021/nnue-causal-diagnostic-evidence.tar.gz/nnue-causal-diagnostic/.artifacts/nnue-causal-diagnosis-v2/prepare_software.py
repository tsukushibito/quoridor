"""Materialize necessary owned source/tool bindings under a finite canonical lease."""

import hashlib
import importlib.util
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("causal_software_worker", HERE / "software_worker.py")
WORKER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WORKER)


def materialize():
    root = WORKER.ROOT
    previous = json.loads((HERE / "software-plan-v2.json").read_text())
    # Existing tool evidence reused here; entry rehashes these exact tools under its lease.
    tools = previous["tools"]
    cargo = tools["cargo"]["path"]
    common = [cargo, "--offline", "--locked", "--manifest-path", str(root / "Cargo.toml")]
    commands = [
        common[:1]
        + ["test"]
        + common[1:]
        + [
            "-j1",
            "-p",
            "quoridor-runner",
            "--lib",
            "causal_diagnostic::boundary_tests",
            "--",
            "--test-threads=1",
        ],
        common[:1]
        + ["test"]
        + common[1:]
        + [
            "-j1",
            "-p",
            "quoridor-nnue",
            "--lib",
            "causal_component_boundary_tests",
            "--",
            "--test-threads=1",
        ],
        common[:1]
        + ["build"]
        + common[1:]
        + ["-j1", "--release", "-p", "quoridor-runner", "--bin", "quoridor-runner"],
    ]
    manifest = root / "crates/quoridor-runner/src/arena_manifest.rs"
    body = (
        manifest.read_text()
        .split("pub fn source_bindings()", 1)[1]
        .split("pub fn file_sha256", 1)[0]
    )
    pairs = re.findall(r'\(\s*"([^"]+)"\s*,\s*include_bytes!\(\s*"([^"]+)"\s*\)\s*,?\s*\)', body)
    if len(pairs) != 31:
        raise RuntimeError("current maintained exact source-map definition changed")
    compiled = {
        key: WORKER.file_record((manifest.parent / path).resolve())["SHA256"] for key, path in pairs
    }
    for name in ["causal_diagnostic", "sigma_qualification"]:
        compiled[f"runner/{name}.rs"] = WORKER.file_record(
            root / f"crates/quoridor-runner/src/{name}.rs"
        )["SHA256"]
    files = [
        root / "Cargo.toml",
        root / "Cargo.lock",
        root / "python/quoridor_training/cycle_process.py",
        root / "python/quoridor_training/snapshot.py",
        root / "scripts/dev/research-job.py",
        root / "scripts/dev/research-job.sh",
        HERE / "software_worker.py",
        HERE / "test_software_worker.py",
        Path(__file__).resolve(),
        root / "configs/arena/smoke.json",
    ]
    # Only the seven owned crate/type dependencies, never assets/models/registry/history.
    for crate in (root / "crates").iterdir():
        if crate.is_dir():
            files.extend(
                path
                for path in crate.rglob("*")
                if path.is_file()
                and (path.suffix in {".rs", ".h", ".cpp", ".json"} or path.name == "Cargo.toml")
            )
    refs = [
        HERE / "related-source-STOP-binding-v2.json",
        Path(
            "/workspaces/quoridor/.worktree/learning-million/.artifacts/nnue-causal-engineering-review342-v1/related-v2/control.json"
        ),
        Path(
            "/workspaces/quoridor/research-data/ai-sigma/teacher-distance-tanh-v1/causal-resources-v2.json"
        ),
        Path(
            "/workspaces/quoridor/.worktree/nnue-hypothesis-learner/.artifacts/nnue-causal-diagnosis-v2/diagnostic-target.json"
        ),
        Path(
            "/workspaces/quoridor/.worktree/nnue-hypothesis-learner/.artifacts/nnue-causal-diagnosis-v2/model-input-companion.json"
        ),
    ]
    failure = WORKER.file_record(HERE / "failed-software-STOP-v1.json")
    receipt = Path(
        "/workspaces/quoridor/.artifacts/research-acceptance/engineering-sparse-smoke-fixture-v1/receipt.json"
    )
    files += refs + [receipt, Path(failure["path"])]
    rows = {str(path.resolve()): WORKER.file_record(path.resolve()) for path in files}
    rows.update({row["path"]: row for row in tools.values()})
    configs = [
        root / ".cargo/config.toml",
        root / ".cargo/config",
        Path("/workspaces/quoridor/.cargo/config.toml"),
        Path("/workspaces/quoridor/.cargo/config"),
        Path("/home/vscode/.cargo/config.toml"),
        Path("/home/vscode/.cargo/config"),
    ]
    absent = []
    for path in configs:
        if path.exists():
            rows[str(path.resolve())] = WORKER.file_record(path.resolve())
        else:
            absent.append(str(path))
    body = (root / "crates/quoridor-runner/src/causal_diagnostic.rs").read_text()
    cases = re.findall(r"fn (causal_[a-z0-9_]+)\(", body)
    if len(cases) != 9:
        raise RuntimeError("nine new runner plus one NNUE definition only")
    environment = {
        "CARGO_TARGET_DIR": str(HERE / "target/software-v1"),
        "RUSTC": tools["rustc"]["path"],
        "RUSTDOC": tools["rustdoc"]["path"],
        **{key: tools[key]["path"] for key in ["CC", "CXX", "AR"]},
        "RUSTUP_AUTO_INSTALL": "0",
        "CARGO_NET_OFFLINE": "true",
        "CARGO_INCREMENTAL": "0",
        "CARGO_PROFILE_DEV_OPT_LEVEL": "0",
        "CARGO_PROFILE_DEV_DEBUG": "0",
        "CARGO_PROFILE_TEST_OPT_LEVEL": "0",
        "CARGO_PROFILE_TEST_DEBUG": "0",
        "CARGO_PROFILE_RELEASE_DEBUG": "0",
        "RUSTFLAGS": "",
        "CARGO_ENCODED_RUSTFLAGS": "",
        "PYTHONDONTWRITEBYTECODE": "1",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "CUDA_VISIBLE_DEVICES": "",
    }
    target_map = {
        "prior_failure": failure,
        "rows": WORKER.target_census(HERE / "target/software-v1"),
        "reader_STOP": WORKER.now(),
    }
    map_path = HERE / "retained-target-map-v2.json"
    with map_path.open("x") as output:
        json.dump(target_map, output, indent=2)
        output.write("\n")
    plan = {
        "schema": "quoridor.nnue-causal.software-entry.v1",
        "root": str(root),
        "phase": "affected-software-only",
        "runtime": str(HERE / "control/software-runtime-v2"),
        "target": str(HERE / "target/software-v1"),
        "private": str(HERE / "private/software-v2/quoridor-runner"),
        "prior_failure": failure,
        "retained_target_map": WORKER.file_record(map_path),
        "source_binding": WORKER.file_record(refs[0]),
        "review": WORKER.file_record(refs[1]),
        "resource_proof": WORKER.file_record(refs[2]),
        "target_packet": WORKER.file_record(refs[3]),
        "model_input_companion": WORKER.file_record(refs[4]),
        "whole_B": 2 * WORKER.GIB,
        "commands": commands,
        "case_names": [
            ["causal_diagnostic::boundary_tests::" + name for name in cases],
            [
                "residual::causal_component_boundary_tests::causal_legacy_components_match_ordinary_bits"
            ],
        ],
        "tools": tools,
        "environment": environment,
        "inputs": list(rows.values()),
        "absent_configs": absent,
        "compiled_sources": compiled,
        "compiler_cpu": 2,
        "guardian_cpu": 4,
        "worker_seconds": 650,
        "command_seconds": 120,
        "prepared_at": WORKER.now(),
        "scope": "three build/new-test definitions plus two backend0 source/current-history/input ports",
        "actual_science": "none; guard repeats fresh peer/source/physical/lease before any child",
    }
    WORKER.validate_plan(plan)
    path = HERE / "software-plan-v3.json"
    raw = json.dumps(plan, indent=2, allow_nan=False).encode() + b"\n"
    with path.open("xb") as output:
        output.write(raw)
        output.flush()
        WORKER.os.fsync(output.fileno())
    return {
        "path": str(path),
        "SHA256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "input_rows": len(rows),
        "directed_bytes_including_compiler_tools": sum(row["bytes"] for row in rows.values()),
    }


if __name__ == "__main__":
    WORKER.named_quiet()
    WORKER.physical({"compiler_cpu": 2, "guardian_cpu": 4})
    lease = WORKER.os.open(WORKER.LOCK, WORKER.os.O_RDWR | WORKER.os.O_NOFOLLOW)
    try:
        WORKER.fcntl.flock(lease, WORKER.fcntl.LOCK_EX | WORKER.fcntl.LOCK_NB)
        WORKER.named_quiet()
        WORKER.physical({"compiler_cpu": 2, "guardian_cpu": 4})
        WORKER.os.sched_setaffinity(0, {3})
        print(json.dumps(materialize(), allow_nan=False))
    finally:
        WORKER.os.close(lease)
