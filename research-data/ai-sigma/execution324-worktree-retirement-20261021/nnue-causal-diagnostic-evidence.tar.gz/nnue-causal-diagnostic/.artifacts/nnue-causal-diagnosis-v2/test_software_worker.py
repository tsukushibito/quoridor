"""Affected guardian ports only; no Cargo/native/model calls in these definitions."""

import copy
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("causal_software_worker", HERE / "software_worker.py")
WORKER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WORKER)


class SoftwarePorts(unittest.TestCase):
    def plan(self):
        return copy.deepcopy(json.loads((HERE / "software-plan-v1.json").read_text()))

    def test_actual_job_phase_not_status_controls_activity(self):
        self.assertTrue(WORKER.job_is_active({"phase": "running", "status": "complete"}))
        self.assertTrue(WORKER.job_is_active({"phase": "queued"}))
        self.assertTrue(WORKER.job_is_active({"phase": "starting"}))
        self.assertFalse(WORKER.job_is_active({"phase": "finished", "status": "running"}))
        with self.assertRaises(RuntimeError):
            WORKER.job_is_active({"status": "complete"})
        with self.assertRaises(RuntimeError):
            WORKER.job_is_active({"phase": "unknown"})

    def test_exact_new_case_scope_accepts(self):
        WORKER.validate_plan(self.plan())

    def test_old_or_extra_commands_refuse(self):
        plan = self.plan()
        plan["commands"][0][-3] = "old_suite"
        with self.assertRaisesRegex(RuntimeError, "unplanned command"):
            WORKER.validate_plan(plan)
        plan = self.plan()
        plan["commands"].append(plan["commands"][0])
        with self.assertRaisesRegex(RuntimeError, "three build/test"):
            WORKER.validate_plan(plan)

    def test_wrong_source_or_review_refuses(self):
        for field in ["source_binding", "review"]:
            plan = self.plan()
            plan[field]["SHA256"] = "0" * 64
            with self.assertRaises(RuntimeError):
                WORKER.validate_plan(plan)

    def test_busy_lock_before_input_import_TMP_child(self):
        plan = self.plan()
        with (
            mock.patch.object(WORKER, "named_quiet", return_value=[]),
            mock.patch.object(WORKER, "physical", return_value={}),
            mock.patch.object(WORKER.os, "open", return_value=55),
            mock.patch.object(WORKER.os, "close") as close,
            mock.patch.object(WORKER.fcntl, "flock", side_effect=BlockingIOError("busy")),
            mock.patch.object(WORKER, "verify_rows") as inputs,
            mock.patch.object(WORKER, "load_lifetime") as imports,
            mock.patch.object(WORKER.Path, "mkdir") as mkdir,
        ):
            with self.assertRaises(BlockingIOError):
                WORKER.execute(plan)
            close.assert_called_once_with(55)
            inputs.assert_not_called()
            imports.assert_not_called()
            mkdir.assert_not_called()

    def test_source_error_is_primary_before_imports(self):
        plan = self.plan()
        primary = RuntimeError("original input E")
        with (
            mock.patch.object(WORKER, "named_quiet", return_value=[]),
            mock.patch.object(WORKER, "physical", return_value={}),
            mock.patch.object(WORKER.os, "open", return_value=55),
            mock.patch.object(WORKER.os, "close") as close,
            mock.patch.object(WORKER.fcntl, "flock"),
            mock.patch.object(WORKER, "verify_rows", side_effect=primary),
            mock.patch.object(WORKER, "load_lifetime") as imports,
            mock.patch.object(WORKER.Path, "mkdir") as mkdir,
            mock.patch.object(WORKER.Path, "exists", return_value=False),
            mock.patch.object(WORKER.Allocation, "scan", return_value={}),
        ):
            with self.assertRaises(RuntimeError) as result:
                WORKER.execute(plan)
            self.assertIs(result.exception, primary)
            close.assert_called_once_with(55)
            imports.assert_not_called()
            mkdir.assert_not_called()

    def test_case_census_refuses_missing_or_extra(self):
        required = ["a", "b"]
        self.assertEqual(
            set(WORKER.parse_case_log("test a ... ok\ntest b ... ok", required)), set(required)
        )
        for raw in ["test a ... ok", "test a ... ok\ntest b ... ok\ntest old ... ok"]:
            with self.assertRaisesRegex(RuntimeError, "census mismatch"):
                WORKER.parse_case_log(raw, required)

    def test_positive_allocation_does_not_refund_deleted_files(self):
        base = os.environ["CAUSAL_CONTROL_TEST_TMP"]
        with tempfile.TemporaryDirectory(dir=base) as directory:
            root = Path(directory)
            (root / "target").mkdir()
            path = root / "target/item"
            path.write_bytes(b"x" * 8192)
            with mock.patch.object(WORKER, "OWN", root):
                allocation = WORKER.Allocation()
                first = allocation.scan()["target"]
                self.assertGreaterEqual(first, 8192)
                path.unlink()
                self.assertEqual(allocation.scan()["target"], first)

    def test_retained_target_changed_bytes_refuse_before_lifetime_import(self):
        plan = copy.deepcopy(json.loads((HERE / "software-plan-v3.json").read_text()))
        primary = RuntimeError("retained target byte mismatch")
        with (
            mock.patch.object(WORKER, "named_quiet", return_value=[]),
            mock.patch.object(WORKER, "physical", return_value={}),
            mock.patch.object(WORKER.os, "open", return_value=55),
            mock.patch.object(WORKER.os, "close") as close,
            mock.patch.object(WORKER.fcntl, "flock"),
            mock.patch.object(WORKER, "verify_rows"),
            mock.patch.object(
                WORKER,
                "bounded_json",
                return_value={
                    "status": "CLEAR",
                    "blockers": [],
                    "ordinary_findings": [],
                    "owned_readers_children_jobs_TMP_remaining": [],
                },
            ),
            mock.patch.object(WORKER, "verify_retained_target", side_effect=primary),
            mock.patch.object(WORKER, "load_lifetime") as imports,
            mock.patch.object(WORKER.Path, "exists", return_value=False),
            mock.patch.object(WORKER.Allocation, "scan", return_value={}),
        ):
            with self.assertRaises(RuntimeError) as result:
                WORKER.execute(plan)
            self.assertIs(result.exception, primary)
            imports.assert_not_called()
            close.assert_called_once_with(55)

    def test_seed_keeps_disappeared_charges_and_only_new_growth(self):
        with tempfile.TemporaryDirectory(dir=os.environ["CAUSAL_CONTROL_TEST_TMP"]) as directory:
            root = Path(directory)
            (root / "target").mkdir()
            path = root / "target/item"
            path.write_bytes(b"x" * 8192)
            with mock.patch.object(WORKER, "OWN", root):
                allocation = WORKER.Allocation()
                held = {key: 0 for key in WORKER.CAPS}
                held["target"] = 65536
                held["TMP"] = 131072
                WORKER.seed_allocation(allocation, held)
                self.assertEqual(allocation.charges["target"], 65536)
                self.assertEqual(allocation.charges["TMP"], 131072)
                path.unlink()
                self.assertEqual(allocation.scan()["target"], 65536)
                (root / "target/new").write_bytes(b"x" * 8192)
                self.assertGreaterEqual(allocation.scan()["target"], 65536 + 8192)


if __name__ == "__main__":
    unittest.main()
