"""One affected software entry; maintained cycle_process owns every actual child."""

import argparse
import datetime
import fcntl
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import time
import types

ROOT = Path("/workspaces/quoridor/.worktree/nnue-causal-diagnostic")
OWN = ROOT / ".artifacts/nnue-causal-diagnosis-v2"
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
MIB = 1024**2
GIB = 1024**3
CAPS = {
    "target": GIB,
    "private": 32 * MIB,
    "input": 32 * MIB,
    "raw": 128 * MIB,
    "control": 128 * MIB,
    "TMP": 256 * MIB,
    "failure": 128 * MIB,
}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def file_record(path):
    path = Path(path)
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or path.resolve() != path:
        raise RuntimeError(f"canonical regular input required: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(MIB), b""):
            digest.update(block)
    after = path.lstat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_mode) != (
        after.st_dev,
        after.st_ino,
        after.st_size,
        after.st_mtime_ns,
        after.st_mode,
    ):
        raise RuntimeError(f"input changed while hashing: {path}")
    return {
        "path": str(path),
        "SHA256": digest.hexdigest(),
        "bytes": after.st_size,
        "mode": format(stat.S_IMODE(after.st_mode), "04o"),
    }


def bounded_json(path):
    with Path(path).open("rb") as stream:
        raw = stream.read(MIB + 1)
    if len(raw) > MIB:
        raise RuntimeError("bounded control exceeds1MiB")
    return json.loads(raw)


def verify_rows(rows):
    for row in rows:
        if file_record(row["path"]) != row:
            raise RuntimeError(f"exact hash/size/mode mismatch: {row['path']}")


def validate_plan(plan):
    if plan["schema"] != "quoridor.nnue-causal.software-entry.v1":
        raise RuntimeError("wrong software schema")
    if plan["root"] != str(ROOT) or plan["phase"] != "affected-software-only":
        raise RuntimeError("source owner/phase mismatch")
    if plan["runtime"] != str(OWN / "control/software-runtime-v2"):
        raise RuntimeError("one named runtime only")
    if plan["target"] != str(OWN / "target/software-v1"):
        raise RuntimeError("one exact retained owned target only")
    if plan["private"] != str(OWN / "private/software-v2/quoridor-runner"):
        raise RuntimeError("one named private image only")
    if plan.get("prior_failure", {}).get("SHA256") != (
        "6eb67b48fcaa0b67098a4c4d8b8552ac014ec8daecb177f54f2199613785676c"
    ):
        raise RuntimeError("exact failed entry provenance required")
    if plan.get("retained_target_map", {}).get("path") != str(OWN / "retained-target-map-v2.json"):
        raise RuntimeError("exact owned stopped target map required")
    if plan["source_binding"]["SHA256"] != (
        "5492c41d26270f18ee9d267b2f548f29264cadc5ededfab5106c9b9a51bac787"
    ):
        raise RuntimeError("fixed source repair binding required")
    if plan["review"]["SHA256"] != (
        "cd844ac52206bb318cc609151cd28af3e6583e1d6104bb16d55b11b726f0053c"
    ):
        raise RuntimeError("same actual stopped review required")
    if len(plan["commands"]) != 3 or plan["whole_B"] != 2 * GIB:
        raise RuntimeError("exact three build/test definitions within engineering2GiB")
    cargo = plan["tools"]["cargo"]["path"]
    common = [cargo, "--offline", "--locked", "--manifest-path", str(ROOT / "Cargo.toml")]
    expected = [
        common[:1]
        + ["test"]
        + common[1:]
        + [
            "-j1",
            "-p",
            "quoridor-runner",
            "--lib",
            "causal_diagnostic::boundary_tests",
            "--",
            "--test-threads=1",
        ],
        common[:1]
        + ["test"]
        + common[1:]
        + [
            "-j1",
            "-p",
            "quoridor-nnue",
            "--lib",
            "causal_component_boundary_tests",
            "--",
            "--test-threads=1",
        ],
        common[:1]
        + ["build"]
        + common[1:]
        + ["-j1", "--release", "-p", "quoridor-runner", "--bin", "quoridor-runner"],
    ]
    if plan["commands"] != expected or plan["command_seconds"] != 120:
        raise RuntimeError("unplanned command/scope or administrative bound")
    if plan["worker_seconds"] != 650 or plan["compiler_cpu"] != 2 or plan["guardian_cpu"] != 4:
        raise RuntimeError("fixed software entry lifetime/CPU")


def ancestors():
    result = set()
    pid = os.getpid()
    while pid > 1 and pid not in result:
        result.add(pid)
        fields = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        pid = int(fields[1])
    return result


def job_is_active(state):
    phase = state.get("phase")
    if phase not in {"queued", "starting", "running", "finished"}:
        raise RuntimeError("unknown actual research-job phase; no quiet certificate")
    return phase != "finished"


def named_quiet():
    """Instantaneous named job facts, no global idle/future-quiet certificate."""
    exempt = ancestors()
    competing = []
    for directory in Path("/proc").iterdir():
        if not directory.name.isdecimal() or int(directory.name) in exempt:
            continue
        try:
            raw = (directory / "cmdline").read_bytes()[:65536]
            argv = [part.decode(errors="replace") for part in raw.split(b"\0") if part]
            if not argv:
                continue
            executable = Path(argv[0]).name
            command = " ".join(argv)
            named = executable in {
                "cargo",
                "rustc",
                "cc1",
                "cc1plus",
                "clang",
                "clang++",
                "quoridor-runner",
                "nnue-diagnose",
                "perf",
                "chromium",
                "chrome",
                "headless_shell",
            }
            if "research-job.py" in command and "run" in argv and "--state-dir" in argv:
                runtime = Path(argv[argv.index("--state-dir") + 1])
                state = bounded_json(runtime / "state.json")
                named = job_is_active(state)
            if executable.startswith("python") and len(argv) > 1:
                scripts = [Path(a).name for a in argv[1:] if a.endswith(".py")]
                named = named or any(
                    re.search(r"(live|gradient|software|numeric|generation|throughput).*worker", s)
                    for s in scripts
                )
            if named:
                competing.append({"pid": int(directory.name), "argv": argv})
        except (FileNotFoundError, ProcessLookupError):
            continue
    if competing:
        raise RuntimeError("current named competitor; no queue/interrupt: " + json.dumps(competing))
    return []


def physical(plan):
    affinity = os.sched_getaffinity(0)
    cpus = [plan["compiler_cpu"], plan["guardian_cpu"]]
    identities = []
    for cpu in cpus:
        if cpu not in affinity:
            raise RuntimeError("requested core outside current affinity")
        topology = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        identities.append(
            (
                (topology / "physical_package_id").read_text().strip(),
                (topology / "core_id").read_text().strip(),
            )
        )
    if identities[0] == identities[1]:
        raise RuntimeError("compiler/guardian logical siblings are not distinct cores")
    available = (
        int(
            next(
                line.split()[1]
                for line in Path("/proc/meminfo").read_text().splitlines()
                if line.startswith("MemAvailable:")
            )
        )
        * 1024
    )
    free = shutil.disk_usage(OWN).free
    quota = Path("/sys/fs/cgroup/cpu.max").read_text().split()
    if quota[0] != "max" and int(quota[0]) < int(quota[1]):
        raise RuntimeError("current CPU quota cannot supply one compiler core")
    memory_max = Path("/sys/fs/cgroup/memory.max").read_text().strip()
    if memory_max != "max" and int(memory_max) < 6 * GIB:
        raise RuntimeError("current cgroup memory ceiling below compiler family6GiB")
    if available < 10 * GIB or free < 2 * GIB:
        raise RuntimeError("fresh physical RAM/FS prerequisite")
    return {
        "at": now(),
        "MemAvailable_B": available,
        "FS_free_B": free,
        "cores": list(zip(cpus, identities)),
        "cpu_max": quota,
        "memory_max": memory_max,
        "limits": "kernel topology, not WSL P/E or scheduler isolation certificate",
    }


def load_lifetime():
    # Avoid quoridor_training.__init__ and all numerical/framework imports.
    package = types.ModuleType("_causal_lifetime")
    package.__path__ = [str(ROOT / "python/quoridor_training")]
    sys.modules[package.__name__] = package
    return importlib.import_module("_causal_lifetime.cycle_process")


class Allocation:
    """Positive sampled charges; vanished/rewritten artifacts never grant a refund."""

    def __init__(self):
        self.seen = {}
        self.charges = {name: 0 for name in CAPS}
        self.charges["control"] = 2 * MIB  # All pre-existing namespace plus setup/control margin.
        self.source_and_Git_held = 14139392 + 4 * MIB
        self.samples = 0

    def scan(self):
        for name, cap in CAPS.items():
            top = OWN / name
            pending = [top]
            if name == "control":
                pending += [p for p in OWN.iterdir() if p.is_file()]
            while pending:
                path = pending.pop()
                try:
                    info = path.lstat()
                except FileNotFoundError:
                    continue
                if stat.S_ISLNK(info.st_mode):
                    raise RuntimeError(f"owned output symlink refused: {path}")
                if stat.S_ISDIR(info.st_mode):
                    try:
                        pending.extend(path.iterdir())
                    except FileNotFoundError:
                        continue
                if stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode):
                    identity = (name, str(path), info.st_dev, info.st_ino)
                    allocated = info.st_blocks * 512
                    previous = self.seen.get(identity, 0)
                    self.charges[name] += max(0, allocated - previous)
                    self.seen[identity] = max(previous, allocated)
            if self.charges[name] > cap:
                raise RuntimeError(f"positive owned allocation cap: {name}")
        if sum(self.charges.values()) + self.source_and_Git_held > 2 * GIB:
            raise RuntimeError("engineering whole allocation cap")
        self.samples += 1
        return dict(self.charges)


def target_census(target):
    """Only this stopped owned target: exact file bytes/modes plus directory identities."""
    target = Path(target)
    if target != OWN / "target/software-v1" or not target.is_dir():
        raise RuntimeError("named stopped owned target required")
    rows = []
    pending = [target]
    while pending:
        path = pending.pop()
        info = path.lstat()
        if stat.S_ISREG(info.st_mode):
            rows.append(file_record(path))
        elif stat.S_ISDIR(info.st_mode):
            rows.append(
                {
                    "path": str(path),
                    "kind": "directory",
                    "mode": format(stat.S_IMODE(info.st_mode), "04o"),
                }
            )
            pending.extend(path.iterdir())
        else:
            raise RuntimeError("nonregular retained target refused")
        if len(rows) > 4096:
            raise RuntimeError("retained target census exceeds finite4096 rows")
    return sorted(rows, key=lambda row: row["path"])


def verify_retained_target(plan):
    verify_rows([plan["prior_failure"], plan["retained_target_map"]])
    failed = bounded_json(plan["prior_failure"]["path"])
    if failed["status"] != "FAILED" or failed["job_id"] != "131df16f-6032-49a4-bba8-c345a1e9e48a":
        raise RuntimeError("wrong stopped entry")
    if failed["remaining_readers_children_TMP"] or failed["owned_TMP_remaining"]:
        raise RuntimeError("prior entry not stopped")
    saved = bounded_json(plan["retained_target_map"]["path"])
    if saved["prior_failure"] != plan["prior_failure"] or saved["rows"] != target_census(
        plan["target"]
    ):
        raise RuntimeError("retained target provenance/bytes/modes changed")
    return failed["positive_sampled_component_charges_B"]


def seed_allocation(allocation, held):
    # Populate seen identities first, so existing bytes are not counted twice.
    current = allocation.scan()
    for name in CAPS:
        allocation.charges[name] = max(current[name], held[name])
    allocation.scan()


def parse_case_log(raw, required):
    cases = {}
    for line in raw.splitlines():
        match = re.fullmatch(r"test (\S+) \.\.\. ok", line)
        if match:
            cases[match[1]] = {"status": "PASS", "exit_code": 0}
    if set(cases) != set(required):
        raise RuntimeError("actual exact affected method census mismatch")
    return cases


def execute(plan):
    validate_plan(plan)
    # No lifetime imports, output/TMP or child creation before nonblocking shared admission.
    named_quiet()
    before_physics = physical(plan)
    lease = os.open(LOCK, os.O_RDWR | os.O_NOFOLLOW)
    try:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BaseException:
        os.close(lease)
        raise
    primary = None
    secondary = []
    cp = None
    runtime = Path(plan["runtime"])
    records = []
    attempted_logs = []
    stopped = None
    allocation = Allocation()
    start = time.monotonic()
    source_after = None
    sampled_family_max = 0
    tmp = OWN / "TMP/software-v2"
    try:
        named_quiet()
        physics = physical(plan)
        verify_rows(plan["inputs"])
        for absent in plan["absent_configs"]:
            if Path(absent).exists():
                raise RuntimeError("unbound Cargo config appeared")
        review = bounded_json(plan["review"]["path"])
        if review["status"] != "CLEAR" or review["blockers"] or review["ordinary_findings"]:
            raise RuntimeError("source review not clear")
        if review["owned_readers_children_jobs_TMP_remaining"]:
            raise RuntimeError("review source consumer lease still active")
        held = verify_retained_target(plan)
        seed_allocation(allocation, held)
        for path in [runtime, Path(plan["private"]).parent, tmp]:
            if path.exists():
                raise RuntimeError("fresh owned named path prerequisite")
        cp = load_lifetime()
        os.sched_setaffinity(0, {plan["guardian_cpu"]})
        for path in [runtime, Path(plan["private"]).parent, tmp]:
            path.mkdir(parents=True, exist_ok=False)
        for key, value in plan["environment"].items():
            os.environ[key] = value
        os.environ["TMPDIR"] = str(tmp)
        os.environ["CAUSAL_NN0_TMP"] = str(tmp)
        deadline = start + plan["worker_seconds"]
        resources = cp.CycleResources(
            {
                "max_memory_bytes": 6 * GIB - 64 * MIB,
                "host_ram_reserve": 4 * GIB,
                "max_output_bytes": 2 * GIB,
            },
            OWN,
            deadline,
        )
        parent = cp.identity(cp.process_info(os.getppid()))
        base_check = resources.check

        def check(owned=()):
            nonlocal sampled_family_max
            base_check(owned)
            extra = cp.process_info(parent["pid"]) if parent and cp.alive(parent) else None
            infos = [cp.process_info(os.getpid()), *(cp.process_info(p["pid"]) for p in owned)]
            family = sum(info["rss"] for info in infos if info) + (extra["rss"] if extra else 0)
            sampled_family_max = max(sampled_family_max, family)
            if family > 6 * GIB:
                raise RuntimeError("actual family compiler plus controller exceeds6GiB")
            allocation.scan()

        resources.check = check
        cp.save_record(
            runtime / "actual-START.json",
            {
                "at": now(),
                "identity": cp.identity(cp.process_info(os.getpid())),
                "source_binding": plan["source_binding"],
                "physics": physics,
                "before_physics": before_physics,
                "lease_inode": os.fstat(lease).st_ino,
                "scope": "three affected software commands then two backend0 identity/replay ports",
            },
        )
        all_cases = {}
        with cp.cancellation_signals():
            for index, command in enumerate(plan["commands"]):
                log = runtime / f"command-{index}.log"
                attempted_logs.append(log)
                result = cp.execute(
                    command,
                    log,
                    min(deadline, time.monotonic() + plan["command_seconds"]),
                    cpu_core=plan["compiler_cpu"],
                    resources=resources,
                )
                records.append(result)
                if index < 2:
                    all_cases.update(parse_case_log(log.read_text(), plan["case_names"][index]))
            artifact = Path(plan["target"]) / "release/quoridor-runner"
            artifact_identity = file_record(artifact)
            private = Path(plan["private"])
            with artifact.open("rb") as source, private.open("xb") as output:
                shutil.copyfileobj(source, output, MIB)
                output.flush()
                os.fsync(output.fileno())
            os.chmod(private, 0o755)
            private_identity = file_record(private)
            if private_identity["SHA256"] != artifact_identity["SHA256"]:
                raise RuntimeError("private copy differs from compiler artifact")
            for index, command in enumerate(["causal-bindings", "causal-target"], 3):
                argv = [
                    str(private),
                    command,
                    "--control",
                    plan["target_packet"]["path"],
                    "--control-sha256",
                    plan["target_packet"]["SHA256"],
                ]
                log = runtime / f"command-{index}.log"
                attempted_logs.append(log)
                result = cp.execute(
                    argv,
                    log,
                    min(deadline, time.monotonic() + plan["command_seconds"]),
                    cpu_core=plan["compiler_cpu"],
                    resources=resources,
                )
                records.append(result)
                row = json.loads(log.read_text())
                if row["model_calls"] or row["search_calls"]:
                    raise RuntimeError("metadata/current input replay port entered unplanned work")
                cp.save_record(runtime / f"{command}.json", row)
            bindings = bounded_json(runtime / "causal-bindings.json")
            if bindings["executable_sha256"] != private_identity["SHA256"]:
                raise RuntimeError("actual image self binding mismatch")
            expected_sources = plan["compiled_sources"]
            if bindings["compiled_sources"] != expected_sources:
                raise RuntimeError("actual included source map differs from frozen current source")
            case_receipt = {
                "image_sha256": private_identity["SHA256"],
                "compiled_sources_sha256": bindings["compiled_sources_sha256"],
                "cases": {name.split("::")[-1]: row for name, row in all_cases.items()},
                "directwait_cleanup_remaining": [],
                "scope": "ten new NN0 methods; existing BEST51 payload/backend/Search campaign0",
            }
            cp.save_record(runtime / "boundary-tests.json", case_receipt)
            cp.save_record(
                runtime / "source-review.json",
                {
                    "status": "CLEAR",
                    "compiled_sources_sha256": bindings["compiled_sources_sha256"],
                    "reader_stop": review["source_reader_STOP"],
                    "remaining": [],
                    "actual_review_control": plan["review"],
                    "producer_source_binding": plan["source_binding"],
                    "limits": review["scope"],
                },
            )
    except BaseException as error:
        primary = error
    finally:
        try:
            verify_rows(plan["inputs"])
            source_after = {"at": now(), "all_hash_size_mode_unchanged": True}
        except BaseException as error:
            secondary.append(
                {"stage": "source_after", "type": type(error).__name__, "error": str(error)}
            )
        if tmp.exists():
            try:
                # Remove only owned test/compiler TMP after all direct cycle waits; no target deletion.
                shutil.rmtree(tmp)
            except BaseException as error:
                secondary.append(
                    {
                        "stage": "owned_TMP_cleanup",
                        "type": type(error).__name__,
                        "error": str(error),
                    }
                )
        try:
            charges = allocation.scan()
        except BaseException as error:
            charges = dict(allocation.charges)
            secondary.append(
                {"stage": "allocation_final", "type": type(error).__name__, "error": str(error)}
            )
        disk_receipts = []
        for log in attempted_logs:
            receipt = log.with_suffix(".process.json")
            try:
                disk_receipts.append({"path": str(receipt), "record": bounded_json(receipt)})
            except BaseException as error:
                disk_receipts.append(
                    {"path": str(receipt), "status": "UNKNOWN", "error": str(error)}
                )
                secondary.append(
                    {
                        "stage": "direct_receipt_read",
                        "type": type(error).__name__,
                        "error": str(error),
                    }
                )
        stopped = {
            "at": now(),
            "status": "PASS" if primary is None and not secondary else "FAILED",
            "whole_seconds": time.monotonic() - start,
            "nested_commands_not_added": True,
            "primary_error": None
            if primary is None
            else {"type": type(primary).__name__, "error": str(primary)},
            "secondary_errors": secondary,
            "returned_command_records": records,
            "attempted_direct_commands": len(attempted_logs),
            "persisted_direct_receipts": disk_receipts,
            "persisted_pending_mask_fields": "retained separately; returned records alone can establish completed restoration",
            "source_after": source_after,
            "owned_TMP_remaining": [str(tmp)] if tmp.exists() else [],
            "positive_sampled_component_charges_B": charges,
            "prior_failed_fee_seconds_held": 32.89916462090332,
            "sampled_family_max_B": sampled_family_max,
            "held_source_Git_control_floor_B": allocation.source_and_Git_held,
            "continuous_family_transient_allocation_peaks": "UNKNOWN; sampled guardian only",
            "existing_model_backend_calls": 0,
            "causal_numeric_campaign": "NOT_RUN",
            "ten_tests_scope": "result receipts only; no old successful suites replayed",
        }
        if cp and runtime.exists():
            try:
                cp.save_record(runtime / "owner-STOP.json", stopped)
            except BaseException as error:
                secondary.append(
                    {"stage": "STOP_persist", "type": type(error).__name__, "error": str(error)}
                )
        try:
            os.close(lease)
        except BaseException as error:
            secondary.append(
                {
                    "stage": "canonical_lease_close",
                    "type": type(error).__name__,
                    "error": str(error),
                }
            )
    if primary is not None:
        if secondary:
            primary.add_note("individual finalization facts: " + json.dumps(secondary))
        raise primary
    if secondary:
        raise RuntimeError("software finalization errors: " + json.dumps(secondary))
    return stopped


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha256", required=True)
    args = parser.parse_args()
    if file_record(args.plan)["SHA256"] != args.plan_sha256:
        raise RuntimeError("actual immutable software plan SHA")
    plan = bounded_json(args.plan)
    print(json.dumps(execute(plan), allow_nan=False))


if __name__ == "__main__":
    main()
