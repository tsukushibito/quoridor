"""Finite saved-evidence verification; no evaluator, Search, native or framework calls."""

import importlib.util
import json
import os
from pathlib import Path
import resource
import time

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("causal_numeric_guard", HERE / "numeric_worker.py")
WORKER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WORKER)
GUARD = WORKER.GUARD
RAW = HERE / "raw/campaign-v1"


def verified(ref):
    path = Path(ref["path"])
    row = GUARD.file_record(path)
    if row["SHA256"] != ref["sha256"] or row["bytes"] != ref["bytes"]:
        raise RuntimeError("exact frozen saved-output bytes mismatch")
    return json.loads(path.read_bytes()), row


def trim_observation(row):
    result = row.get("result") or {}
    return {
        "status": row.get("status"),
        "reason": row.get("reason"),
        "original_error": row.get("original_error"),
        "requested_depth": row.get("requested_depth"),
        "matched_complete": row.get("matched_complete"),
        "whole_seconds": row.get("whole_seconds"),
        "parent_restored": row.get("parent_restored"),
        "result": result,
    }


def collect():
    start = GUARD.now()
    timer = time.monotonic()
    report_row = GUARD.file_record(RAW / "campaign-result.json")
    report = json.loads((RAW / "campaign-result.json").read_bytes())
    plan = GUARD.bounded_json(HERE / "campaign-plan-v1.json")
    expected = ["R3", "R6", "C1", "C2", "G1", "T1"]
    if (
        report["target_sha256"] != plan["target"]["sha256"]
        or report["plan_sha256"] != GUARD.file_record(HERE / "campaign-plan-v1.json")["SHA256"]
    ):
        raise RuntimeError("sole target/plan coupling")
    if (RAW / "INCOMPLETE").exists():
        raise RuntimeError("publication incomplete")
    freeze, freeze_row = verified(report["candidate_freeze"])
    rows = [report_row, freeze_row]
    if [p["id"] for p in freeze["parents"]] != expected:
        raise RuntimeError("exact candidate parent order")
    extracted = []
    for i, reference in enumerate(report["parents"]):
        parent, record = verified(reference)
        rows.append(record)
        if parent["id"] != expected[i] or parent["candidate_freeze_sha256"] != freeze_row["SHA256"]:
            raise RuntimeError("parent/freeze provenance")
        for key in [
            "natural",
            "forced",
            "caller100ms",
            "observer_traces",
            "common_complete_depth2_tree",
        ]:
            if key not in parent:
                raise RuntimeError("missing planned parent stage")
        tree = parent["common_complete_depth2_tree"]
        shallow = {k: v for k, v in tree.items() if k != "all_legal_firstmoves_and_responses"}
        shallow["first_moves"] = [
            {k: v for k, v in move.items() if k != "legal_responses"}
            for move in tree.get("all_legal_firstmoves_and_responses", [])
        ]
        extracted.append(
            {
                "id": parent["id"],
                "original_action": parent["original_historical"].get("original_selected_action"),
                "freeze": freeze["parents"][i],
                "natural": parent["natural"],
                "forced": parent["forced"],
                "caller100ms": parent["caller100ms"],
                "traces": parent["observer_traces"],
                "tree": shallow,
                "raw_ref": reference,
            }
        )
    for row in rows:
        if GUARD.file_record(row["path"]) != row:
            raise RuntimeError("saved-output source changed during collection")
    if GUARD.file_record(report_row["path"]) != report_row:
        raise RuntimeError("result changed during collection")
    result = {
        "schema": "quoridor.nnue-causal.saved-extraction.v1",
        "START": start,
        "reader_STOP": GUARD.now(),
        "whole_seconds": time.monotonic() - timer,
        "target_sha256": report["target_sha256"],
        "plan_sha256": report["plan_sha256"],
        "saved_hash_mode_map": rows,
        "counts": {
            k: report[k]
            for k in [
                "actual_natural_forced_search_invocations",
                "admitted_search_attempts",
                "admitted_caller_attempts",
                "natural_forced_successful_returns",
                "natural_forced_error_returns",
                "deeper_node_liability",
                "common_tree_nodes",
                "trace_paths",
                "standalone_scores",
            ]
        },
        "parents": extracted,
        "source_after_unchanged": True,
        "readers_children_TMP_remaining": [],
        "native_model_Search_calls": 0,
        "ru_maxrss_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "limits": "Saved descriptive extraction only; completeness/ranking/terminal/causality interpreted separately",
    }
    path = HERE / "saved-extraction-v1.json"
    with path.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    # Selected shape/fields only; full bounded extraction is retained for verification.
    shape = {
        "STOP": result["reader_STOP"],
        "bytes": path.stat().st_size,
        "counts": result["counts"],
        "parents": [
            {
                "id": p["id"],
                "candidate_union": p["freeze"].get("candidate_union"),
                "natural_first": p["natural"][:1],
                "forced_first": p["forced"][:1],
                "tree_summary": {k: v for k, v in p["tree"].items() if k != "first_moves"},
                "trace_first": p["traces"][:1],
                "caller_keys": [list(c["observed"]) for c in p["caller100ms"]],
            }
            for p in extracted
        ],
    }

    print(json.dumps(shape, allow_nan=False))


if __name__ == "__main__":
    GUARD.named_quiet()
    WORKER.physical()
    lease = os.open(GUARD.LOCK, os.O_RDWR | os.O_NOFOLLOW)
    try:
        GUARD.fcntl.flock(lease, GUARD.fcntl.LOCK_EX | GUARD.fcntl.LOCK_NB)
        GUARD.named_quiet()
        WORKER.physical()
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * GUARD.MIB, 512 * GUARD.MIB))
        collect()
    finally:
        os.close(lease)
