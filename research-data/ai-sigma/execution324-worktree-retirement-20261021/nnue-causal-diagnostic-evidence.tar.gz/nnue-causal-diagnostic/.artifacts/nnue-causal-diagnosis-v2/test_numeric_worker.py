"""Only new numeric entry-control ports, with all actual native/model work blocked."""

import copy
import importlib.util
import json
from pathlib import Path
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("causal_numeric_guard", HERE / "numeric_worker.py")
WORKER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WORKER)


class NumericPorts(unittest.TestCase):
    def plan(self):
        return copy.deepcopy(json.loads((HERE / "numeric-plan-v1.json").read_text()))

    def test_exact_entry_rejects_extra_calls_and_invented_horizon(self):
        WORKER.validate(self.plan())
        for field, value in [
            ("argv", self.plan()["argv"] + ["repeat"]),
            ("max_runtime_seconds", 120),
            ("CPU", 0),
        ]:
            plan = self.plan()
            plan[field] = value
            with self.assertRaises(RuntimeError):
                WORKER.validate(plan)

    def test_busy_lock_before_inputs_import_output_or_child(self):
        guard = WORKER.GUARD
        with (
            mock.patch.object(guard, "named_quiet", return_value=[]),
            mock.patch.object(WORKER, "physical", return_value={}),
            mock.patch.object(WORKER.os, "open", return_value=44),
            mock.patch.object(WORKER.os, "close") as close,
            mock.patch.object(guard.fcntl, "flock", side_effect=BlockingIOError("busy")),
            mock.patch.object(guard, "verify_rows") as reads,
            mock.patch.object(guard, "load_lifetime") as imports,
            mock.patch.object(WORKER.Path, "mkdir") as output,
        ):
            with self.assertRaises(BlockingIOError):
                WORKER.execute(self.plan())
            reads.assert_not_called()
            imports.assert_not_called()
            output.assert_not_called()
            close.assert_called_once_with(44)

    def test_payload_error_primary_before_lifetime_import(self):
        guard = WORKER.GUARD
        original = RuntimeError("original immutable payload hash mismatch")
        with (
            mock.patch.object(guard, "named_quiet", return_value=[]),
            mock.patch.object(WORKER, "physical", return_value={}),
            mock.patch.object(WORKER.os, "open", return_value=44),
            mock.patch.object(WORKER.os, "close") as close,
            mock.patch.object(guard.fcntl, "flock"),
            mock.patch.object(guard, "verify_rows", side_effect=original),
            mock.patch.object(guard, "load_lifetime") as imports,
            mock.patch.object(WORKER.Path, "exists", return_value=False),
            mock.patch.object(guard.Allocation, "scan", return_value={}),
        ):
            with self.assertRaises(RuntimeError) as raised:
                WORKER.execute(self.plan())
            self.assertIs(raised.exception, original)
            imports.assert_not_called()
            close.assert_called_once_with(44)

    def test_changed_counter_domain_refuses_before_import_output(self):
        guard = WORKER.GUARD
        campaign = json.loads((HERE / "campaign-plan-v1.json").read_text())
        campaign["limits"]["search_calls"] = 145
        with (
            mock.patch.object(guard, "named_quiet", return_value=[]),
            mock.patch.object(WORKER, "physical", return_value={}),
            mock.patch.object(WORKER.os, "open", return_value=44),
            mock.patch.object(WORKER.os, "close") as close,
            mock.patch.object(guard.fcntl, "flock"),
            mock.patch.object(guard, "verify_rows"),
            mock.patch.object(guard, "bounded_json", return_value=campaign),
            mock.patch.object(guard, "load_lifetime") as imports,
            mock.patch.object(WORKER.Path, "exists", return_value=False),
            mock.patch.object(WORKER.Path, "mkdir") as output,
            mock.patch.object(guard.Allocation, "scan", return_value={}),
        ):
            with self.assertRaisesRegex(RuntimeError, "counter domains"):
                WORKER.execute(self.plan())
            imports.assert_not_called()
            output.assert_not_called()
            close.assert_called_once_with(44)


if __name__ == "__main__":
    unittest.main()
