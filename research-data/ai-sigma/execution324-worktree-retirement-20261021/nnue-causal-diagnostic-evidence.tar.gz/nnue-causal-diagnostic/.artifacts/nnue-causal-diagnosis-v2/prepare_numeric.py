"""Freeze the already accepted smaller campaign and exact native/control provenance."""

import importlib.util
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("causal_numeric_guard", HERE / "numeric_worker.py")
WORKER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WORKER)
GUARD = WORKER.GUARD


def write_new(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    return GUARD.file_record(path)


def bound(row):
    return {"path": row["path"], "sha256": row["SHA256"]}


def prepare():
    software_plan = GUARD.bounded_json(HERE / "software-plan-v3.json")
    GUARD.verify_rows(software_plan["inputs"])
    software_stop = GUARD.file_record(HERE / "qualified-software-STOP-v2.json")
    software = GUARD.bounded_json(software_stop["path"])
    runtime = HERE / "control/software-runtime-v2"
    sources = GUARD.bounded_json(runtime / "causal-bindings.json")
    companion = GUARD.bounded_json(software_plan["model_input_companion"]["path"])
    target = GUARD.bounded_json(software_plan["target_packet"]["path"])
    manifest_path = Path(companion["weights"]["path"]).parent / "manifest.json"
    manifest = GUARD.file_record(manifest_path)
    weights = GUARD.file_record(Path(companion["weights"]["path"]))
    if (
        manifest["SHA256"] != target["model"]["expected"]["manifest_expected_SHA256"]
        or weights["SHA256"] != target["model"]["expected"]["weights_expected_SHA256"]
    ):
        raise RuntimeError("exact immutable model payload/manifest binding")
    private = GUARD.file_record(Path(software["private"]["path"]))
    if private != software["private"]:
        raise RuntimeError("stopped private SHA/bytes/mode")
    q = {
        "schema": "quoridor.nnue-causal.affected-qualification.v1",
        "target_sha256": software_plan["target_packet"]["SHA256"],
        "image_sha256": sources["executable_sha256"],
        "compiled_sources_sha256": sources["compiled_sources_sha256"],
        "manifest_sha256": manifest["SHA256"],
        "weights_sha256": weights["SHA256"],
        "source_review": bound(GUARD.file_record(runtime / "source-review.json")),
        "boundary_tests": bound(GUARD.file_record(runtime / "boundary-tests.json")),
        "input_mapping": bound(GUARD.file_record(runtime / "causal-target.json")),
        "model_input_companion": bound(software_plan["model_input_companion"]),
    }
    qualification = write_new(HERE / "affected-qualification-v1.json", q)
    campaign = {
        "schema": "quoridor.nnue-causal.campaign.v1",
        "target": bound(software_plan["target_packet"]),
        "manifest": bound(manifest),
        "output": str(HERE / "raw/campaign-v1"),
        "model_weights_sha256": weights["SHA256"],
        "units": "BEST51-legacy-D80-logit-residual-tanh",
        "limits": {
            "per_call_nodes": 8000000,
            "aggregate_nodes": 256000000,
            "shallow_nodes": 1000000,
            "search_calls": 144,
            "caller_windows": 12,
            "trace_paths": 18,
            "standalone_scores": 54,
        },
        "depths": [2, 4, 6],
        "current_executable_sha256": sources["executable_sha256"],
        "current_compiled_sources_sha256": sources["compiled_sources_sha256"],
        "affected_qualification": bound(qualification),
    }
    # Canonical output parent exists before Popen; no campaign/output file exists yet.
    (HERE / "raw").mkdir(exist_ok=True)
    campaign_ref = write_new(HERE / "campaign-plan-v1.json", campaign)
    extra_paths = [
        HERE / "numeric_worker.py",
        HERE / "test_numeric_worker.py",
        Path(__file__).resolve(),
        HERE / "control/software-runtime-v2/source-review.json",
        HERE / "control/software-runtime-v2/boundary-tests.json",
        HERE / "control/software-runtime-v2/causal-target.json",
        HERE / "control/software-runtime-v2/causal-bindings.json",
        HERE / "qualified-software-STOP-v2.json",
        Path(qualification["path"]),
        Path(campaign_ref["path"]),
        manifest_path,
        Path(weights["path"]),
        Path(private["path"]),
    ]
    for path, row in companion["refs"].items():
        if row["SHA256"] == "f425274563fab855b05525662e2628aca056e375686179b67076412955047d7d":
            extra_paths.append(Path(path))
    rows = {row["path"]: row for row in software_plan["inputs"]}
    rows.update({str(path): GUARD.file_record(path) for path in extra_paths})
    plan = {
        "schema": "quoridor.nnue-causal.numeric-entry.v1",
        "runtime": str(HERE / "control/numeric-runtime-v1"),
        "private": private["path"],
        "software_STOP": software_stop,
        "software_stop_expected_sha256": software_stop["SHA256"],
        "campaign": campaign_ref,
        "argv": [
            private["path"],
            "causal-diagnostic",
            "--control",
            campaign_ref["path"],
            "--control-sha256",
            campaign_ref["SHA256"],
        ],
        "CPU": 1,
        "guardian_CPU": 4,
        "whole_B": 2 * GUARD.GIB,
        "max_runtime_seconds": None,
        "inputs": list(rows.values()),
        "environment": {
            "PYTHONDONTWRITEBYTECODE": "1",
            "OMP_NUM_THREADS": "1",
            "OPENBLAS_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "CUDA_VISIBLE_DEVICES": "",
        },
        "freeze_before_outcomes": GUARD.now(),
        "fixed_parent_order": [p["id"] for p in target["parents"]],
        "plain_caller_clock": "100ms authority-receipt/5ms reserve/legality outside/matchingreply-drain before next",
        "limits": "No replays/retries/warmups/calibration/depth rescue; unsupported fixed slots UNKNOWN",
    }
    WORKER.validate(plan)
    result = write_new(HERE / "numeric-plan-v1.json", plan)
    job = GUARD.bounded_json(HERE / "software-job-v2.json")
    job["argv"] = [
        job["argv"][0],
        "-B",
        str(HERE / "numeric_worker.py"),
        "--plan",
        result["path"],
        "--plan-sha256",
        result["SHA256"],
    ]
    job["max_runtime_seconds"] = None
    write_new(HERE / "numeric-job-v1.json", job)
    print(
        json.dumps(
            {
                "plan": result,
                "input_rows": len(rows),
                "parents": plan["fixed_parent_order"],
                "model_payload_hashed_not_evaluated": weights,
                "science_horizons": None,
                "source_reader_STOP": GUARD.now(),
            }
        )
    )


if __name__ == "__main__":
    GUARD.named_quiet()
    WORKER.physical()
    lease = os.open(GUARD.LOCK, os.O_RDWR | os.O_NOFOLLOW)
    try:
        GUARD.fcntl.flock(lease, GUARD.fcntl.LOCK_EX | GUARD.fcntl.LOCK_NB)
        GUARD.named_quiet()
        WORKER.physical()
        os.sched_setaffinity(0, {3})
        prepare()
    finally:
        os.close(lease)
