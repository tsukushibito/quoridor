"""Fixed saved-query/opened-public stream; maintained QF1 keys, no models."""

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import stat
import zlib

import numpy as np
from quoridor_training import public_features as pf

CATEGORIES = ("literal_input", "reflection_only_input", "geometry_distance_mismatch")
LABELS = ("-1", "0", "+1", "other")


def read_ref(ref, maximum=1048576):
    p = Path(ref["path"])
    assert p.stat().st_size == ref["bytes"] <= maximum
    b = p.read_bytes()
    assert hashlib.sha256(b).hexdigest() == ref["sha256"]
    assert f"{stat.S_IMODE(p.stat().st_mode):04o}" == ref["mode"]
    return b


def keys(records):
    assert records.dtype == pf.RECORD and records.ndim == 1
    pf.validate_geometry(records["geometry"])
    assert np.isfinite(records["distance"]).all()
    return pf.model_keys(records)


def geometry_keys(records):
    raw = records.view("u1").reshape(-1, pf.RECORD.itemsize)
    return np.ascontiguousarray(raw[:, :20]).view("V20").reshape(-1)


def reflected(records):
    result = records.copy()
    result["geometry"] = pf.reflect(records["geometry"])
    return keys(result)


def label(z):
    return {-1: "-1", 0: "0", 1: "+1"}.get(int(z), "other")


def table(values):
    out = defaultdict(list)
    for index, value in enumerate(values):
        out[value.tobytes()].append(index)
    return out


def collect_provenance(content, row_ids):
    """Saved absolute winner/row STM bookkeeping, without replay/geometry checks."""
    compressed = read_ref(content["compressed"], 4 * 1024**2)
    decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
    raw = decoder.decompress(compressed, 4 * 1024**2 + 1)
    assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
    assert len(raw) == content["raw_bytes"] <= 4 * 1024**2
    assert hashlib.sha256(raw).hexdigest() == content["raw_sha256"] and raw.endswith(b"\n")
    wanted = set(row_ids)
    rows, games = {}, []
    for line in raw.splitlines():
        record = json.loads(line)
        if record.get("type") != "game":
            continue
        outcome = record["record"]["result"]
        assert outcome["status"] == "returned"
        game = outcome["value"]
        provenance = game["provenance"]
        assert provenance["reason"] == "goal" and provenance["winner"] in (1, 2)
        saved = {
            "game": game["request_id"],
            "family": game["family"],
            "winner_absolute": provenance["winner"],
            "reason": provenance["reason"],
            "ruleset": provenance["ruleset"],
            "final_prefix_plies": len(provenance["final_prefix"]),
            "rows": len(game["rows"]),
        }
        games.append(saved)
        for item in game["rows"]:
            teacher = item["teacher"]
            assert teacher["id"] in wanted and teacher["id"] not in rows
            side = teacher["side"]
            assert side in (1, 2) and item["search"]["parent"]["stm"] == side - 1
            expected = 1 if provenance["winner"] == side else -1
            assert teacher["z"] == expected
            assert teacher["terminal_targets"]["outcome_z"] == expected
            assert teacher["research_ruleset"] == provenance["ruleset"]
            rows[teacher["id"]] = {**saved, "row_side_absolute": side, "own_z": expected}
    assert set(rows) == wanted and len(games) == 8
    return rows, games, len(raw) + len(compressed)


def scan(config, destination):
    public = json.loads(read_ref(config["public_manifest"]))
    query_manifest = json.loads(read_ref(config["query_manifest"]))
    assert public["schema"] == pf.SCHEMA and public["record_bytes"] == 66
    assert public["original_only"] and public["dataset_revision"] == pf.REVISION_NAME
    assert public["revision"] == "751186344fc52ad0c29bc65922e62c6fa915f006"
    assert public["test_sealed"] and len(public["source_shards"]) == 43
    # Membership is selected in metadata BEFORE opening or decoding any record.
    parts = [p for p in public["partitions"] if p["name"] in ("train", "validation")]
    assert [(p["name"], p["rows"]) for p in parts] == [
        ("train", 8413949),
        ("validation", 419150),
    ]
    assert sum(p["bytes"] for p in parts) <= 1024**3
    assert query_manifest["schema"] == "quoridor-common-corpus-terminal-geometry-v3"
    assert query_manifest["rows"] == 341
    buffers = {name: read_ref(ref) for name, ref in config["query_files"].items()}
    assert set(buffers) == set(query_manifest["files"])
    for name, payload in buffers.items():
        assert len(payload) == query_manifest["file_bytes"][name]
        assert hashlib.sha256(payload).hexdigest() == query_manifest["sha256"][name]
    queries = np.frombuffer(buffers["geometry.bin"], dtype=pf.RECORD)
    own = np.frombuffer(buffers["labels.f32"], dtype="<f4").reshape(341, 2)[:, 1]
    raw_scores = np.frombuffer(buffers["completed-root-raw.f32"], dtype="<f4")
    common = np.frombuffer(buffers["common-eligible.u8"], dtype="u1")
    sampling = np.frombuffer(
        buffers["sampling.bin"],
        dtype=np.dtype([("family", "<u4"), ("split", "u1"), ("primary", "u1")]),
    )
    steps = np.frombuffer(buffers["distance-steps.u8"], dtype="u1").reshape(341, 2)
    assert queries["distance"].tobytes() == (steps.astype(np.float64) / 80).astype("<f4").tobytes()
    assert np.array_equal(queries["z"], own) and np.isfinite(raw_scores).all()
    assert set(common.tolist()) <= {0, 1} and set(sampling["split"].tolist()) == {0, 1}
    assert int(common.sum()) == 293
    assert [int(common[sampling["split"] == i].sum()) for i in (0, 1)] == [217, 76]
    ids = query_manifest["sampling"]["row_ids"]
    provenance, games, provenance_bytes = collect_provenance(query_manifest["source_content"], ids)
    assert (
        provenance_bytes + sum(len(v) for v in buffers.values()) + config["query_manifest"]["bytes"]
        <= 4 * 1024**2
    )
    qkeys, rkeys, gkeys = keys(queries), reflected(queries), geometry_keys(queries)
    lookup, reflected_lookup, geometry_lookup = table(qkeys), table(rkeys), table(gkeys)
    union_keys = np.unique(np.concatenate([qkeys, rkeys]))
    unique_geometry = np.unique(gkeys)
    result = {
        "status": "INCOMPLETE",
        "query_rows": 341,
        "query_literal_distinct": len(lookup),
        "query_reflection_orbit_distinct": len(
            set(min(k.tobytes(), r.tobytes()) for k, r in zip(qkeys, rkeys))
        ),
        "source_goal_games": games,
        "logical_opened_record_bytes": 0,
        "query_provenance_bytes": provenance_bytes
        + sum(len(v) for v in buffers.values())
        + config["query_manifest"]["bytes"],
        "partitions": {},
        "queries": [],
        "sealed_files_opened": [],
    }
    for i, rid in enumerate(ids):
        assert provenance[rid]["own_z"] == int(own[i])
        family = query_manifest["sampling"]["families"][int(sampling["family"][i])]
        result["queries"].append(
            {
                "index": i,
                "id": rid,
                "family": family,
                "common_eligible": bool(common[i]),
                "primary_eligible": bool(sampling["primary"][i]),
                "own_z": int(own[i]),
                "raw_completed_D6": float(raw_scores[i]),
                "distance_steps": steps[i].tolist(),
                "input_key_hex": qkeys[i].tobytes().hex(),
                "provenance": provenance[rid],
                "partitions": {},
            }
        )
    for part in parts:
        name = part["name"]
        file = Path(config["public_manifest"]["path"]).parent / part["file"]
        assert (
            part["file"] == name + ".bin"
            and file.stat().st_size == part["bytes"] == part["rows"] * 66
        )
        before = file.stat()
        digest = hashlib.sha256()
        census = dict(
            scanned=0,
            labels={v: 0 for v in LABELS},
            public_rows_matching_any_query={v: 0 for v in CATEGORIES},
        )
        result["partitions"][name] = census
        for query in result["queries"]:
            query["partitions"][name] = {
                category: {"labels": {v: 0 for v in LABELS}, "examples": []}
                for category in CATEGORIES
            }
        with file.open("rb", buffering=0) as stream:
            while block := stream.read(4096 * 66):
                assert len(block) % 66 == 0
                digest.update(block)
                rows = np.frombuffer(block, dtype=pf.RECORD)
                pf.validate_geometry(rows["geometry"])
                assert np.isfinite(rows["distance"]).all()
                assert np.all((rows["distance"] >= 0) & (rows["distance"] <= 1))
                assert np.all(rows["shard"] < 43)
                halves = np.array([s["rows"] // 2 for s in public["source_shards"]], dtype="u4")
                assert np.all(rows["row"] < halves[rows["shard"]])
                for z, count in zip(*np.unique(rows["z"], return_counts=True)):
                    census["labels"][label(z)] += int(count)
                k = keys(rows)
                g = geometry_keys(rows)
                selected = np.flatnonzero(np.isin(k, union_keys) | np.isin(g, unique_geometry))
                for j in selected:
                    kb, gb = k[j].tobytes(), g[j].tobytes()
                    category_targets = {
                        "literal_input": lookup.get(kb, []),
                        "reflection_only_input": [
                            i for i in reflected_lookup.get(kb, []) if qkeys[i].tobytes() != kb
                        ],
                        "geometry_distance_mismatch": [
                            i for i in geometry_lookup.get(gb, []) if qkeys[i].tobytes() != kb
                        ],
                    }
                    for category, targets in category_targets.items():
                        if targets:
                            census["public_rows_matching_any_query"][category] += 1
                        for i in targets:
                            bank = result["queries"][i]["partitions"][name][category]
                            bank["labels"][label(rows["z"][j])] += 1
                            if len(bank["examples"]) < 2:
                                source = public["source_shards"][int(rows["shard"][j])]
                                bank["examples"].append(
                                    {
                                        "public_partition_row": census["scanned"] + int(j),
                                        "shard": int(rows["shard"][j]),
                                        "original_row": int(rows["row"][j]),
                                        "source_file": source["file"],
                                        "source_git_blob": source["blob"],
                                        "input_plane_SHA256": rows["input_sha"][j].tobytes().hex(),
                                        "public_z": int(rows["z"][j]),
                                        "distance_FP32_bits_hex": kb[20:].hex(),
                                    }
                                )
                census["scanned"] += len(rows)
                result["logical_opened_record_bytes"] += len(block)
                assert result["logical_opened_record_bytes"] <= 1024**3
        assert census["scanned"] == part["rows"] and digest.hexdigest() == part["sha256"]
        after = file.stat()
        assert (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
            after.st_ctime_ns,
        )
        census["stream_SHA256"] = digest.hexdigest()
        census["identity_before_after"] = (
            "expected qualified SHA joined once-stream actual SHA; inode/size/mtime/ctime unchanged"
        )
        census["queries_matched"] = {
            category: sum(
                sum(q["partitions"][name][category]["labels"].values()) > 0
                for q in result["queries"]
            )
            for category in CATEGORIES
        }
        (destination / "partial-census.json").write_text(
            json.dumps(
                {
                    "partitions": result["partitions"],
                    "status": "PARTIAL_UNTIL_ALL_COUNTS_AND_HASHES",
                },
                indent=2,
            )
            + "\n"
        )
    for r in [config["public_manifest"], config["query_manifest"], *config["query_files"].values()]:
        read_ref(r)
    for name, census in result["partitions"].items():
        assert sum(census["labels"].values()) == census["scanned"]
        for q in result["queries"]:
            for category in CATEGORIES:
                bank = q["partitions"][name][category]
                assert len(bank["examples"]) <= min(2, sum(bank["labels"].values()))
    result["status"] = "COMPLETE_OPENED_SPLITS_SAVED_CORRESPONDENCE"
    payload = json.dumps(result, indent=2).encode() + b"\n"
    assert len(payload) <= 16 * 1024**2
    (destination / "overlap.json").write_bytes(payload)
    print(
        json.dumps(
            {
                "status": result["status"],
                "partitions": result["partitions"],
                "output_bytes": len(payload),
                "sealed_reads": 0,
                "models_or_predictions_or_games": 0,
            }
        )
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    b = Path(args.config).read_bytes()
    assert hashlib.sha256(b).hexdigest() == args.sha256
    scan(json.loads(b), Path(args.output))


if __name__ == "__main__":
    main()
