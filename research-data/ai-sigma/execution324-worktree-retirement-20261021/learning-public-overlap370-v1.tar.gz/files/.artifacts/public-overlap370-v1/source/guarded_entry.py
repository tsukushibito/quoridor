"""One finite saved-data command under existing lease/resource/process helpers."""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import time


def now():
    return datetime.now(timezone.utc).isoformat()


def ref(path):
    p = Path(path)
    b = p.read_bytes()
    return {
        "path": str(p),
        "sha256": hashlib.sha256(b).hexdigest(),
        "bytes": len(b),
        "mode": f"{stat.S_IMODE(p.stat().st_mode):04o}",
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["fixture", "scan"], required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--sha256", required=True)
    args = parser.parse_args()
    b = Path(args.config).read_bytes()
    assert hashlib.sha256(b).hexdigest() == args.sha256
    cfg = json.loads(b)
    root = Path(cfg["owner"])
    assert root == Path(
        "/workspaces/quoridor/.worktree/learning-million/.artifacts/public-overlap370-v1"
    )
    code = importlib.util.spec_from_file_location(
        "lifecycle", "/workspaces/quoridor/scripts/dev/research-lifecycle.py"
    )
    lifecycle = importlib.util.module_from_spec(code)
    code.loader.exec_module(lifecycle)
    output = root / "controls" / args.stage
    output.mkdir(exist_ok=False)
    result = {
        "stage": args.stage,
        "status": "NOT_ENTERED",
        "remaining": [],
        "errors": [],
        "peak_family_RSS": "UNKNOWN",
        "exact_child_UTCSTART_STOP": "UNKNOWN",
    }
    capture = None
    try:
        with lifecycle.lease():
            lifecycle.physical_and_quiet({"limits": cfg["limits"]})
            assert shutil.disk_usage(root).free >= 128 * 1024**2
            for expected in cfg["source_environment_refs"]:
                assert ref(expected["path"]) == expected
            assert lifecycle.allocated(root) + 32 * 1024**2 <= 60 * 1024**2
            result["physical_available_B"] = lifecycle.process.available_memory()
            result["source_environment_before"] = cfg["source_environment_refs"]
            result["entered_at"] = now()
            command = [
                cfg["python"],
                "-B",
                str(
                    root / "source" / ("test_keys.py" if args.stage == "fixture" else "overlap.py")
                ),
            ]
            if args.stage == "scan":
                fixture = json.loads((root / "controls/fixture/STOP.json").read_bytes())
                assert fixture["status"] == "PASS" and fixture["returned"]["cleanup_complete"]
                command += [
                    "--config",
                    args.config,
                    "--sha256",
                    args.sha256,
                    "--output",
                    str(root / "raw"),
                ]
            env = dict(
                os.environ,
                PYTHONPATH=cfg["PYTHONPATH"],
                PYTHONDONTWRITEBYTECODE="1",
                OMP_NUM_THREADS="1",
                OPENBLAS_NUM_THREADS="1",
                MKL_NUM_THREADS="1",
                CUDA_VISIBLE_DEVICES="",
                TMPDIR=str(root / "TMP"),
            )
            deadline = time.monotonic() + (120 if args.stage == "fixture" else 1800)
            resources = lifecycle.process.CycleResources(
                {
                    "host_ram_reserve": 4 * 1024**3,
                    "max_memory_bytes": 448 * 1024**2,
                    "max_output_bytes": 60 * 1024**2,
                },
                root,
                deadline,
            )
            capture = lifecycle.Capture(output / "command.full.log", 1024 * 1024)
            result["returned"] = lifecycle.process.execute(
                command,
                output / "command.log",
                deadline,
                cpu_core=2,
                resources=resources,
                cwd=str(root),
                env=env,
                output_sink=capture,
            )
            capture.close()
            capture = None
            assert result["returned"]["cleanup_complete"] and not result["returned"]["remaining"]
            for expected in cfg["source_environment_refs"]:
                assert ref(expected["path"]) == expected
            result["source_environment_after"] = "MATCH"
            assert lifecycle.allocated(root / "TMP") <= 16 * 1024**2
            assert lifecycle.allocated(root / "raw") <= 16 * 1024**2
            assert not any((root / "TMP").iterdir())
            result["source_environment_data_reader_STOP"] = now()
            result["status"] = "PASS"
    except BaseException as error:
        result["status"] = "FAILED"
        result["errors"].append({"type": type(error).__name__, "message": str(error)})
    finally:
        if capture:
            try:
                capture.close()
            except BaseException as error:
                result["errors"].append({"type": type(error).__name__, "message": str(error)})
        result["released_at"] = now()
        result["owned_readers_children_jobs_TMP_remaining"] = result.get("returned", {}).get(
            "remaining", "UNKNOWN_if_no_return; inspect_persisted_process_record"
        )
        (output / "STOP.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result))
    assert result["status"] == "PASS"


if __name__ == "__main__":
    main()
