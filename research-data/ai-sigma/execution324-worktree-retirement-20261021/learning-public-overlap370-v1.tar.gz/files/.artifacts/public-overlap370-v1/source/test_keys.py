"""New diagnostic key fixture; maintained NumPy/QF1 decoder, synthetic inputs."""

import unittest
import numpy as np
from quoridor_training import public_features as pf
from overlap import keys, geometry_keys, reflected


class CorrespondenceKeys(unittest.TestCase):
    def test_literal_reflection_distance_provenance_and_STM(self):
        records = np.zeros(3, dtype=pf.RECORD)
        records["geometry"]["pawns"] = [[10, 73], [10, 73], [10, 73]]
        records["geometry"]["stocks"] = [7, 3]
        records["geometry"]["horizontal"] = (1 << 3) | (1 << 56)
        records["geometry"]["vertical"] = 1 << 17
        records["distance"] = np.asarray([13 / 80, 7 / 80], dtype="<f4")
        records["z"] = [-1, 1, 0]
        records["shard"] = [1, 2, 3]
        records["row"] = [2, 3, 4]
        records["input_sha"][1] = 255
        self.assertEqual(pf.GEOMETRY.itemsize, 20)
        self.assertEqual(pf.RECORD.itemsize, 66)
        self.assertEqual(len(np.unique(keys(records))), 1)
        np.testing.assert_array_equal(np.isin(keys(records), keys(records[:1])), [True] * 3)
        self.assertEqual(keys(records)[0].tobytes(), records[0].tobytes()[:28])
        changed = records.copy()
        changed["distance"][0, 0] = np.nextafter(changed["distance"][0, 0], np.float32(1))
        self.assertNotEqual(keys(changed)[0], keys(records)[0])
        self.assertEqual(geometry_keys(changed)[0], geometry_keys(records)[0])
        mirror = records.copy()
        mirror["geometry"] = pf.reflect(records["geometry"])
        np.testing.assert_array_equal(keys(mirror), reflected(records))
        self.assertNotEqual(keys(mirror)[0], keys(records)[0])
        np.testing.assert_array_equal(reflected(mirror), keys(records))
        np.testing.assert_array_equal(mirror["distance"], records["distance"])
        np.testing.assert_array_equal(mirror["z"], records["z"])
        x = pf.features(records["geometry"])
        np.testing.assert_array_equal(
            pf.features(records["geometry"], np.ones(3, dtype=bool)),
            pf.features(mirror["geometry"]),
        )
        packed = np.packbits(x.astype("u1").reshape(3, 624), axis=1, bitorder="little")
        np.testing.assert_array_equal(pf.geometry_from_native(packed), records["geometry"])
        # Record has virtual STM zero: own pawn/D first, opposing view rotated180.
        self.assertEqual(int(np.argmax(x[0, 0, :81])), 10)
        self.assertEqual(int(np.argmax(x[0, 1, :81])), 80 - 73)
        swapped = records.copy()
        swapped["distance"] = records["distance"][:, ::-1]
        self.assertNotEqual(keys(swapped)[0], keys(records)[0])
        wrong = records.copy()
        wrong["geometry"]["stocks"][0, 0] = 11
        with self.assertRaises(ValueError):
            keys(wrong)
        nonfinite = records.copy()
        nonfinite["distance"][0, 0] = np.nan
        with self.assertRaises(AssertionError):
            keys(nonfinite)
        # Membership is restricted before labels: sealed descriptor never opened.
        descriptors = [{"name": "test-sealed"}, {"name": "train"}, {"name": "validation"}]
        self.assertEqual(
            [p["name"] for p in descriptors if p["name"] in ("train", "validation")],
            ["train", "validation"],
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
