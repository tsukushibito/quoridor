def verify_native_parameters(path, state):
    import numpy as np

    native = np.memmap(path, dtype="<f4", mode="r")
    offset = 0
    for key in ("ft.weight", "ft.bias", "h.weight", "h.bias", "out.weight", "out.bias"):
        values = state[key].detach().cpu().numpy().reshape(-1)
        for first in range(0, len(values), 4096):
            part = values[first : first + 4096]
            if not np.array_equal(part, native[offset + first : offset + first + len(part)]):
                raise ValueError("frozen checkpoint/native parameters differ")
        offset += len(values)
    if offset != len(native):
        raise ValueError("frozen native parameter count differs")
