# 342.17.1 選択済み混合学習の現役接続準備

人間の最新委任に従い、342.17の最初の有限recipeを選択済みとする。342.16/e268/806172は当時UNSELECTEDだったhistoryとして変更しない。これを未回答・条件毎のACK待ちにしない。このleafの成果はsource/config準備であり、actual runtime資源/support/起動は324。生成担当のschedule/partition/evalbookを複製せず、未作成のstreams/cache/newweightsにはnullを保持した。

## 初期recipeと実行config

fit-template.SELECTED.jsonは現役resolve_configの形式をそのまま用いる。T-family cap64でchronological等間隔抽出、全Vと原RAW保全、publicT1024＋newDT1024を1mean FP32 outcome MSEへ渡す。batch2048、LR1e-4、freshAdam(.9,.999,eps1e-8,wd0)、FT32/H32/QF1/Zero4/tanhFP32、BEST43 init046fe/descriptor46ec/evaluator96a5、incumbent T-only尺度、output bypass OFF。一候補でdefault昇格なし。order/model38020261015、reflection38020261016、publicsampler38020261017、各source左右反転.5（同seedでもpublicは既存jumped独立stream）。

newD8exposures、max512 fullbatch updates、warmup基準100 then constant、現earlystop patience5/min_delta1e-8/relative1e-4を採用する。初期recipeから別のLR/条件探索を加えない。観測は0、100毎、実最終Uで、両V全量とT panels各最大8192。BESTはstrict newD-V改善、public_non_regression=falseでpublicVを独立監視。INITIALは不変initializer参照、保存weightsはBEST/LASTのみ。earlystopが先なら元のactual終了位置を報告し、512完了に書換えない。失敗時のupdate-in-progress/LASTUNKNOWNとprimary+独立secondaries、marker、全cleanupを現役pathで保持する。arenaを使ってBESTを選び直さない。

actual cacheでT-view件数T、eligible fullV件数Vを得て、U=min(512,ceil(8*T/1024))、warmup_steps=min(100,U)をactual configへ解決してから起動する。**現mixed loopはwarmup100を自動min(U)しない**ため、U<100なら324がこの一つのruntime fieldをresolveする必要がある。source/math変更ではない。各updateは必ずadded1024/public1024で、実added exposure=1024*executed_updates/T。ceil端数で8\*Tを超える分は1024未満（max512 capの場合は8未満もあり得る）を記録する。旧50epoch主張はしない。emptyT/Vはbefore-fit拒否。

## 実forward仕事

実T/V未生成なのでcountは捏造しない。P=sorted({0,U} ∪ {100,200,300,400,500}<=U)、training=2048*U、measurement=|P|*(V+419150+min(T,8192)+8192)。INITIAL測定はこのmeasurement内に一度含む。full-T追加やsealedEはない。nativeparameter比較/ファイルSHA/shape/parameter load/codecによるmodel forwardは0。必要な実initial/newweights native/scalar/optimized/delta/undo対応で実評価したrowはQとして別receiptから一度だけ足し、F=training+measurement+Q<=6MをRootが確認する。forward upperを新規standaloneモデル診断に使わない。

旧5799714+200286は事前保守価格でありactual countではない。actual T/V/Uから既存planned_workを用いて置換し、Qが必要ならactual source-bound qualifierの対象と有限countを事前に固定する。まだ対象行/対応数を持たないQはUNKNOWN。実native評価行とPython参照行は呼出側の実receiptに従って数え、同じinference receiptをnested費と重複加算しない。actual configの既存limits.samplesへ6000000-Q_before-Q_after_upperをbindし、fitのplanned_work以下がその余りに収まることを起動前に確認する。Q_after_upperは実際に必要なfinite new-weight対応scopeから定め、元余裕200286を新しい診断の許可にしない。scheduled arenaのSearch nodes/head費はそのnative work scopeで別報告し、fit-row receiptの重複計上をしない。期末R1/失敗counterはattempted/returnedを分け、intervening actual work UNKNOWNを成功へ昇格しない。

## 現役GPU callerに必要な狭い修復

現train_mixtureはbuild_model(...).to(device)→restore_warmstart_parameters→verify_native_parameters(model.state_dict())を行う。維持中verifierはstate[key].detach().numpy()を呼ぶため、CUDA tensorをdirect numpy変換してTypeErrorになる具体的gapがある。gpu-native-parameter-host.patchはここだけを.detach().cpu().numpy()へ変更する。元state/model/optimizerをmutateせず、hostへ移した同じFP32値を既存np.array_equalで比較する。parameterの順序/count/尺度/比較/数学は不変。generic train writerと他全bodyはbyte/AST exact。

verify_native_parameters.pyは変更した当該関数のみのstopped derivative（runtime別実装ではなくMainへの最小patch根拠）。最小before関数gzip、元Main全FileRef、予測postimagehash、strict GNU zero-fuzz forward/inverse/外AST証拠を添えた。postimageはMainへ未適用。324がsole writerとして普通に採用する。test_native_parameter_host_transfer.pyはこの新境界だけのzero-forward stdlib fake-CUDA→host/refusal定義でUNRUN。既存381/interop/model/head suitesは再実行しない。必要なら324がnormal有限NN0で当該一件のみ実行し、その後の本物GPU init正常pathは実fitの必要initial checkで確認する。これはGPU/Torch/ABI qualification PASSの主張ではない。

## Root-owned GPU監視の具体的gap

現normalcommon_study fitはdirect train argv、親LimitsはCycleResourcesのRSS/output監視であり、GPUResourcesのwhole-device VRAM checkに接続していない。既存GPUResources/DeviceMemoryの監視をnormal parent guardへ再用して、GPU0/6GiB・family8GiBinclcontroller64MiB/CPU8 guardian10を実supportにbindするのがRoot-owned残作業。新しいGPU監視class/frameworkをworkerで作らない。

旧guarded_trainはaffinity{2,3}固定とstorage_admissionを要求し、通常common-study argvは--guard-configを許可しない。その別child routeを今回のsource/custody/CPU8設定に黙って差し替えない。normal parentで既存monitorを接続し、actual whole-device使用（host/display分含む）を6GiBに抑える。configure_frameworkのallocator5GiBはwhole-device capではない。今GPU query/importは行っていない。この実不足をRootへ返し、ACK待ちや新科学選択にはしない。

## actual refsと後段接続

current-source-refs.jsonで選択した現役learner/codec/common entry/source/rootmetadata、BEST43 descriptor/public metadata、既存qualified381 BUILD/interopのhash-size-modeを確認した。既存private artifacts・BEST43weight hashは342.16の真正読取scopeを保持し、今回はmetadata lstatだけ（weights payload再読取なし）。実launcherがchanged/current fieldsだけ必要照合する。installed METADATA numpy2.5.3/torch2.14+cu130/CUDA13.0.96/ORT1.30は342.16から同一。GPU/library importや新probe、環境変更・downloadなし。current callerは新しい実source refsでbindし、旧381資格のsubjectをretargetしない。

親342.17の実予定: 他authorのactualglobal schedule/partition/evalbook→4連続generation batch（各通常結果/finalize/cleanup）→retained順の4streamsを既存terminal-cache --input STREAM [--input ...] --output NEW_CACHEへ→actual outcome_only v3 sevenbinary/manifest→通常train --cache ACTUAL --output NEW --config ACTUAL→chosenBEST（改善なしならINITIAL）/LAST real refs→必要newweights/native対応→pre-fixed独立64openings ×2colours×BEST43/D=256arena。追加Sigma/生成補充/failedscope移植/arenaでcheckpoint rescueなし。

converterの既存distinct input-bindingを使う場合は--input-bindingと--binding-sha256の対。model_scale_authorityはactualBEST43/init尺度lineage。新outcome maskはzのみを所有しraw±2をmask除外しない。四stream/一cacheをRootがactual結果からbindし、詳細gzipは保存するがtrainerはsevenbinaryとcompact metadataだけを読む。publicTのみ更新、openedVは観測、sealedEを読まない。

実fit出力はRoot resourcesのowned_unionにある /workspaces/quoridor/.worktree/assets/checkpoints/fixed-d-sigma-mixture380-v1/candidate-v1 を使う。380という保存nameは元案のnamespaceであり、科学issue342.17の追加outside-support rootを作る理由にしない。

Rootのstatic sequenceはfuture refsを自動発見しないため、既存prepare_selected_operation/通常completion boundaryでactual stream/cache/config/weights/256arenaを接続する。新scheduler/registry/certification/条件毎のACKは追加しない。既存SOURCE checks/normal currentBuild/tool/library/numerical correspondenceは落とさない。current generation source/math/imagesは保持され、必要artifact対応をMain HEAD追随だけのrebuildで置換しない。失敗・不足の正確なfieldだけ修復する。

## 支持・STOP

whole8GiB partial-stop方針は選択済みだが、実whole/decimal50GB成立は324が整理し、resources.json（51505074/3194）を発行した。named changed scopesとdated stable rootsから保守的retained upper32210563072B＋whole8589934592B＝40800497664B、decimal50GBのenvelope headroom9199502336B。これはglobal実測ではなく、全assets walk/deletion/refundをしていない。この実supportをnormal runtimeが消費する。fit-local128MiBはwholeguardでない。new outputs/control/TMPの実unionを既存Limitsで制御し、旧shared inputs/modelsをcopy/二重chargeしない。1280完了保証やcompressioncredit、削除/refund/refillで成立にしない。容量/error時は元FAILED/RAW/counter/remainingUNKNOWNを保持する。

runtime配置はGPUindex0/VRAM6GiB/family8GiB inclcontroller/CPU8 guardian10。これはworker source taskのallocationではない。今回はsourceCPU3/RAM512MiB/GPU0、fresh NB/physical/namedpeerで必要source/metadataだけ読取り、lease解放。実GPU/Torch/native/array/forward/fit/生成/Search/Perf/対局/既存successful testは未実行。source/patch/config整形と必要parserだけを行い、STOPと一回OWN usage、Beads/backupを324へ渡す。323USERPAUSE/fits96/default/seals/model-design/features/研究goalと旧RAW/FAILED/fees/UNKNOWNは維持する。
