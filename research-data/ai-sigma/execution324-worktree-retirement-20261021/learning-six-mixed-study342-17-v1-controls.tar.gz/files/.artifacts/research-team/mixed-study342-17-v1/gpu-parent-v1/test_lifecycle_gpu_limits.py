"""One new zero-forward normal-parent GPU guard boundary; fake device/RSS only."""

import argparse
from contextlib import ExitStack
import copy
import importlib.util
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch


class CommonGPUParent(unittest.TestCase):
    def test_whole_device_controller_storage_pause_and_fresh_cpu_scope(self):
        loader = importlib.util.spec_from_file_location(
            "current_gpu_parent", "/workspaces/quoridor/scripts/dev/research-lifecycle.py"
        )
        lifecycle = importlib.util.module_from_spec(loader)
        loader.loader.exec_module(lifecycle)
        process = lifecycle.process
        G, M = 1024**3, 1024**2
        devices, rss_calls = [], []
        rss = {"parent": G, "child": 32 * M}

        class FakeDevice:
            def __init__(self):
                self.bytes, self.reads = 0, 0
                devices.append(self)

            def used(self):
                self.reads += 1
                return self.bytes

        def process_info(pid):
            rss_calls.append(pid)
            return {"rss": rss["parent"] if pid == os.getpid() else rss["child"]}

        with tempfile.TemporaryDirectory(dir=RESULT.parent) as temporary:
            root = Path(temporary)
            first, second = root / "a", root / "b"
            first.mkdir()
            second.mkdir()
            (first / "retained").write_bytes(b"retained tiny fixture")
            os.link(first / "retained", second / "retained")
            pause = root / "pause"
            support = {
                "resources": {
                    "family_RAM_B": 8 * G,
                    "learner": {
                        "GPU_index": 0,
                        "VRAM_B": 6 * G,
                        "family_RAM_B": 8 * G,
                        "host_cpu": 8,
                        "guardian_cpu": 10,
                    },
                }
            }
            experiment = {
                "phase": "fit",
                "argv": ["synthetic", "train"],
                "config": {"fixture": "config"},
            }
            fit = {"experiment": {"study": "mixed-outcome"}, "training": {"device": "cuda"}}
            docs = {"support": support, "experiment": experiment, "config": fit}
            spec = {
                "kind": "run",
                "env": {"CUDA_VISIBLE_DEVICES": "0"},
                "experiment": {"fixture": "experiment"},
                "support": {"fixture": "support"},
                "selection_index": 0,
                "owner": str(root),
                "output": str(root / "operation"),
                "pause_file": str(pause),
                "limits": {
                    "family_B": 8 * G,
                    "host_reserve_B": 4 * G,
                    "controller_B": 64 * M,
                    "worker_cpu": 8,
                    "guardian_cpu": 10,
                    "log_B": M,
                    "GPU_index": 0,
                    "VRAM_B": 6 * G,
                    "owned_B": None,
                    "free_B": None,
                },
            }
            with ExitStack() as stack:
                stack.enter_context(patch.object(process, "DeviceMemory", FakeDevice))
                stack.enter_context(patch.object(process, "available_memory", lambda: 16 * G))
                stack.enter_context(patch.object(process, "process_info", process_info))
                stack.enter_context(
                    patch.object(lifecycle, "document", lambda ref: docs[ref["fixture"]])
                )
                stack.enter_context(patch.object(lifecycle, "selected_run", lambda *a: None))
                stack.enter_context(
                    patch.object(lifecycle, "charged_roots", lambda *a: [first, second])
                )
                stack.enter_context(
                    patch.object(
                        lifecycle.shutil, "disk_usage", lambda *a: SimpleNamespace(free=100 * G)
                    )
                )
                limits = lifecycle.Limits(spec)
                self.assertIsInstance(limits.gpu_resources, process.GPUResources)
                self.assertEqual(len(devices), 1)
                self.assertEqual(limits.gpu_resources.memory_limit, 8 * G)
                self.assertEqual(limits.memory_limit, 8 * G - 64 * M)
                devices[0].bytes = 6 * G
                children = [{"pid": 123456789}]  # Synthetic; process_info never reads /proc.
                limits.check(children)
                self.assertIn(123456789, rss_calls)
                devices[0].bytes = 6 * G + 1
                with self.assertRaisesRegex(process.CycleStopped, "GPU VRAM cap"):
                    limits.check(children)
                devices[0].bytes = 6 * G
                # Exactly one 64MiB controller reserve; this boundary must pass.
                rss["parent"] = 8 * G - 64 * M - rss["child"]
                limits.check(children)
                self.assertEqual(limits.gpu_resources.observed["peak_family_RSS_bytes"], 8 * G)
                rss["parent"] += 1
                with self.assertRaisesRegex(process.CycleStopped, "memory_limit"):
                    limits.check(children)
                rss["parent"] = G

                # Original whole union deduplicates shared inodes and includes extra_B.
                seen = set()
                union = sum(lifecycle.allocated(path, seen=seen) for path in (first, second))
                spec["limits"]["owned_B"] = union
                limits.check(children)
                with self.assertRaisesRegex(lifecycle.Refused, "owned allocation limit"):
                    limits.check(children, extra_B=1)
                spec["limits"]["owned_B"] = None
                spec["limits"]["free_B"] = 100 * G
                limits.check(children)
                with self.assertRaisesRegex(lifecycle.Refused, "FS reserve"):
                    limits.check(children, extra_B=1)
                spec["limits"]["free_B"] = None

                reads = devices[0].reads
                pause.write_text("synthetic pause")
                with self.assertRaisesRegex(process.CycleStopped, "cycle paused"):
                    limits.check(children)
                self.assertEqual(devices[0].reads, reads)
                pause.unlink()
                limits.deadline = 0
                with self.assertRaisesRegex(process.CycleStopped, "cycle deadline"):
                    limits.check(children)
                limits.deadline = None

                second_limits = lifecycle.Limits(spec)
                self.assertIsNot(second_limits.gpu_resources.device, devices[0])
                self.assertEqual(len(devices), 2)
                for field, invalid in (("VRAM_B", 7 * G), ("GPU_index", 1), ("worker_cpu", 9)):
                    wrong = copy.deepcopy(spec)
                    wrong["limits"][field] = invalid
                    with self.assertRaisesRegex(lifecycle.Refused, "issued CUDA mixed-fit"):
                        lifecycle.Limits(wrong)
                    self.assertEqual(len(devices), 2)
                wrong = copy.deepcopy(spec)
                wrong["env"]["CUDA_VISIBLE_DEVICES"] = "1"
                with self.assertRaisesRegex(lifecycle.Refused, "issued CUDA mixed-fit"):
                    lifecycle.Limits(wrong)
                self.assertEqual(len(devices), 2)
                fit["training"]["device"] = "cpu"
                cpu = lifecycle.Limits(spec)
                self.assertIsNone(cpu.gpu_resources)
                self.assertEqual(len(devices), 2)
                cpu.check(children)
                experiment["phase"] = "corpus"
                fit["training"]["device"] = "cuda"
                nonfit = lifecycle.Limits(spec)
                self.assertIsNone(nonfit.gpu_resources)
                self.assertEqual(len(devices), 2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", type=Path, required=True)
    args = parser.parse_args()
    RESULT = args.result
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.TestSuite(
            [CommonGPUParent("test_whole_device_controller_storage_pause_and_fresh_cpu_scope")]
        )
    )
    RESULT.write_text(
        json.dumps(
            {
                "status": "PASS" if result.wasSuccessful() else "FAILED",
                "tests_run": result.testsRun,
                "fake_device_RSS_and_metadata_only": True,
                "actual_NVML_GPU_model_forward_native_fit_calls": 0,
                "failures": [v for _, v in result.failures],
                "errors": [v for _, v in result.errors],
            },
            indent=2,
        )
        + "\n"
    )
    raise SystemExit(0 if result.wasSuccessful() else 1)
