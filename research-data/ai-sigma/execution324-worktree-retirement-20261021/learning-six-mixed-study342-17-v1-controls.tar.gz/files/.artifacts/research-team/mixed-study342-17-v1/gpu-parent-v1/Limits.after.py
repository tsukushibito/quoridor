class Limits(process.CycleResources):
    """Reuse guardian RSS/deadline/pause; add owned positive allocation bounds."""

    def __init__(self, spec):
        self.spec = spec
        cfg = spec["limits"]
        for name in ("family_B", "host_reserve_B", "log_B"):
            require(
                type(cfg[name]) is int and cfg[name] > 0,
                "positive priced limit: " + name,
            )
        measurement = (
            spec["kind"] == "run"
            and document(spec["experiment"])["argv"][1] == "measure"
        )
        support = document(spec["support"]) if spec.get("support") is not None else {}
        require(
            measurement or bool(support), "owning support for non-measurement operation"
        )
        require(
            cfg["family_B"] <= issued_family_upper(spec, support)
            and cfg["host_reserve_B"] >= 4 * 1024**3,
            "issued family/host envelope",
        )
        # Omitted/None storage is ordinary work, not a default allowance.
        for name in ("owned_B", "free_B"):
            value = cfg.get(name)
            require(
                value is None or (type(value) is int and value > 0),
                "declared storage limit: " + name,
            )
        require(
            cfg.get("owned_B") is None or cfg["owned_B"] <= 50000000000,
            "global storage cap",
        )
        if spec["kind"] == "run" and (
            document(spec["experiment"])["phase"] == "arena"
            or (
                document(spec["experiment"])["phase"] == "compare"
                and document(spec["experiment"])["argv"][1] == "decisions"
            )
        ):
            selected_arena(spec)
        elif spec.get("selection_index") is not None:
            selected_run(spec, document(spec["experiment"]))
        elif not measurement:
            admission = document(spec["admission"])
            require(
                admission["schema"] == "quoridor.research.phase-admission.v1",
                "phase admission",
            )
            require(
                admission["owner"] == spec["owner"] and admission["limits"] == cfg,
                "issued owner/limits",
            )
            require(
                admission["spec_sha256"] == spec["intent_sha256"],
                "actual intent admission",
            )
            require(
                admission["support_sha256"] == spec["support"]["sha256"], "same support"
            )
            require(admission["ready"] is True, "phase not admitted")
            if spec["kind"] == "run":
                require(
                    admission["approved_plan"] == spec["approved_plan"],
                    "issued approved plan",
                )
        require(
            cfg["controller_B"] == 64 * 1024 * 1024, "whole family includes controller"
        )
        self.charged_paths = charged_roots(spec)
        super().__init__(
            {
                "host_ram_reserve": cfg["host_reserve_B"],
                "max_memory_bytes": cfg["family_B"] - cfg["controller_B"],
                "max_output_bytes": None,  # This owner counts actual allocated shared inodes below.
                "pause_file": spec.get("pause_file"),
            },
            spec["output"],
            None,
        )

        self.gpu_resources = None
        if spec["kind"] == "run":
            experiment = document(spec["experiment"])
            if experiment["phase"] == "fit":
                fit = document(experiment["config"])
                if (
                    fit["experiment"]["study"] == "mixed-outcome"
                    and fit["training"]["device"] == "cuda"
                ):
                    issued = support.get("resources", {}).get("learner", {})
                    require(
                        type(cfg.get("GPU_index")) is int
                        and type(issued.get("GPU_index")) is int
                        and cfg["GPU_index"] == issued["GPU_index"] == 0
                        and spec.get("env", {}).get("CUDA_VISIBLE_DEVICES") == "0"
                        and type(cfg.get("VRAM_B")) is int
                        and type(issued.get("VRAM_B")) is int
                        and 0 < cfg["VRAM_B"] <= issued["VRAM_B"]
                        and cfg["family_B"] <= issued.get("family_RAM_B", 0)
                        and cfg["worker_cpu"] == issued.get("host_cpu")
                        and cfg["guardian_cpu"] == issued.get("guardian_cpu"),
                        "issued CUDA mixed-fit device/family/CPU limits",
                    )
                    # GPUResources adds the one controller reserve itself.
                    self.gpu_resources = process.GPUResources(
                        {
                            "host_ram_reserve": cfg["host_reserve_B"],
                            "max_memory_bytes": cfg["family_B"],
                            "max_output_bytes": None,
                            "pause_file": spec.get("pause_file"),
                            "controller_reserve_bytes": cfg["controller_B"],
                            "max_vram_bytes": cfg["VRAM_B"],
                        },
                        spec["output"],
                        None,
                    )

    def check(self, children=(), *, extra_B=0):
        super().check(children)
        if self.gpu_resources is not None:
            self.gpu_resources.check(children)
        budget = self.spec["limits"].get("owned_B")
        require(type(extra_B) is int and extra_B >= 0, "prospective allocation")
        if budget is not None:
            seen = set()
            require(
                sum(allocated(p, seen=seen) for p in self.charged_paths) + extra_B
                <= budget,
                "owned allocation limit",
            )
        reserve = self.spec["limits"].get("free_B")
        if reserve is not None:
            require(
                shutil.disk_usage(self.spec["owner"]).free >= reserve + extra_B,
                "FS reserve",
            )
        if self.spec.get("perf") is not None:
            path = Path(self.spec["perf"]["output"])
            if path.exists():
                info = path.lstat()
                require(
                    stat.S_ISREG(info.st_mode)
                    and info.st_size < self.spec["perf"]["data_max_bytes"],
                    "configured perf capture cap; remaining samples/work UNKNOWN",
                )
