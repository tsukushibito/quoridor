"""One NEW NN0 fixture: exact maintained build_check prefix, no producer imports."""

import ast
from pathlib import Path
import tempfile
import unittest


class TrustedHandoverCase(unittest.TestCase):
    def test_funded_caps_are_parameters_and_cannot_exceed_support(self):
        source = Path(__file__).with_name("research-lifecycle.py").read_text()
        module = ast.parse(source)
        function = next(
            n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == "build_check"
        )
        stop = next(
            i
            for i, n in enumerate(function.body)
            if isinstance(n, ast.Expr)
            and isinstance(n.value, ast.Call)
            and isinstance(n.value.func, ast.Name)
            and n.value.func.id == "private_copy_check"
        )
        function.body = function.body[:stop]
        with tempfile.TemporaryDirectory(prefix="new-handover-", dir=Path(__file__).parent) as name:
            root = Path(name)
            support = {"funded_union_B": 2 * 1024**3}
            handover = {
                "schema": "research.target-handover.v1",
                "status": "HANDED_OVER",
                "target": str(root / "target"),
                "owned_remaining": [],
                "shared_serial_pool": True,
                "old_target": str(root / "absent-old"),
                "target_writer": "SYNTHETIC-OWNER",
                "target_max_B": 1280 * 1024**2,
                "private_pool_B": 64 * 1024**2,
            }
            spec = {
                "owner": str(root),
                "writer": "SYNTHETIC-OWNER",
                "target": handover["target"],
                "TMP": str(root / "TMP"),
                "private": str(root / "private"),
                "target_handover": "handover",
                "support": "support",
                "limits": {"owned_B": 1280 * 1024**2 + 64 * 1024**2 + 72 * 1024**2},
            }

            def require(condition, message):
                if not condition:
                    raise ValueError(message)

            def owned(path, owner):
                require(Path(path).is_relative_to(owner), "fixture ownership")
                return Path(path)

            namespace = {
                "Path": Path,
                "require": require,
                "owned": owned,
                "document": lambda ref: {"handover": handover, "support": support}[ref],
            }
            exec(
                compile(
                    ast.Module(body=[function], type_ignores=[]),
                    "maintained build_check prefix",
                    "exec",
                ),
                namespace,
            )
            check = namespace["build_check"]
            check(spec)  # funded larger actual caps; old literal1GiB/32MiB would refuse
            handover["target_max_B"] = True
            with self.assertRaisesRegex(ValueError, "trusted handover"):
                check(spec)
            handover["target_max_B"] = 2 * 1024**3
            with self.assertRaisesRegex(ValueError, "trusted handover"):
                check(spec)
            handover["target_max_B"] = 1280 * 1024**2
            spec["limits"]["owned_B"] += 1
            with self.assertRaisesRegex(ValueError, "common build/private pool"):
                check(spec)
            spec["limits"]["owned_B"] -= 1
            handover["target_writer"] = "WRONG"
            with self.assertRaisesRegex(ValueError, "single issued writer"):
                check(spec)


if __name__ == "__main__":
    unittest.main(verbosity=2)
