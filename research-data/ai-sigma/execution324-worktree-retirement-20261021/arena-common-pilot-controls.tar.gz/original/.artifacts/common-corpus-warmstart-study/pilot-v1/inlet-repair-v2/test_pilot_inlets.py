"""New source-only discriminators; exact publisher function AST, synthetic controls, NN0."""

import ast
import copy
import hashlib
import json
from pathlib import Path
import unittest

ROOT = Path("/workspaces/quoridor")
SOURCE = Path(__file__).parent / "scripts/dev/research-lifecycle.py"


def functions():
    module = ast.parse(SOURCE.read_text())
    selected = [
        n
        for n in module.body
        if isinstance(n, ast.FunctionDef)
        and n.name
        in {
            "canonical_sha",
            "numerical_check",
            "common_pilot_check",
            "experiment_phase_check",
            "caller_source_refs",
        }
    ]
    names = {"FIT_IMPORTS", "PILOT_DATA", "PILOT_PLAN", "QUALIFIER", "QUALIFIER_SHA", "FIT_OUTPUTS"}
    selected = [
        n
        for n in module.body
        if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id in names for t in n.targets)
    ] + selected
    docs = {}

    def require(ok, message):
        if not ok:
            raise ValueError(message)

    env = {
        "ROOT": ROOT,
        "Path": Path,
        "json": json,
        "sha": lambda raw: hashlib.sha256(raw).hexdigest(),
        "document": lambda ref: copy.deepcopy(docs[ref["path"]]),
        "require": require,
    }
    exec(
        compile(
            ast.Module(body=selected, type_ignores=[]), "selected actual publisher AST", "exec"
        ),
        env,
    )
    return env, docs


class PilotInletTests(unittest.TestCase):
    def setUp(self):
        self.env, self.docs = functions()

    def ref(self, name):
        return {
            "path": name,
            "sha256": hashlib.sha256(name.encode()).hexdigest(),
            "bytes": 1,
            "mode": "0644",
        }

    def corpus(self):
        plan = self.ref(str(self.env["PILOT_PLAN"]))
        config = self.ref("/synthetic/config")
        schedule = self.ref("/synthetic/schedule")
        qref = self.ref("/synthetic/q")
        study = {
            "issue": "quoridor-4lc.362",
            "scientific_entry": True,
            "corpus": {"quantity_families": 8, "blind_schedule": {"synthetic": "blind"}},
        }
        model = []
        manifest = {
            "artifact": self.ref("/synthetic/native"),
            "compiled_sources": {"a": "b"},
            "generator_compiled_sources": {"g": "h"},
        }
        e = {
            "phase": "corpus",
            "canonical_plan_sha256": plan["sha256"],
            "config": config,
            "schedule": schedule,
            "inputs": [plan],
            "models": model,
            "rules": "research-standard-2p-threefold-goal-first-v1",
            "distance_units": "wall-distance/80",
            "value_perspective": "side-to-move",
            "batch": None,
            "planned_slots": 8,
            "numerical_qualification": qref,
            "argv": [
                "/synthetic/native",
                "teacher-pilot",
                "--experiment",
                "@EXPERIMENT@",
                "--experiment-sha256",
                "@EXPERIMENT_SHA256@",
            ],
        }
        spec = {"approved_plan": plan, "data_root": str(self.env["PILOT_DATA"])}
        self.docs[config["path"]] = {
            "phase": "common_corpus",
            "output": spec["data_root"],
            "planned_games": 8,
            "main_volume_n": 8,
            "depth": 6,
            "max_nodes": 100_000_000,
            "max_total_nodes": 1_000_000_000,
            "max_total_plies": 200,
            "per_move_timeout_ms": None,
            "distance_a": 0,
            "distance_b": 8,
            "common_study": {"selected_plan": {k: plan[k] for k in ["path", "sha256"]}},
        }
        self.docs[schedule["path"]] = study["corpus"]["blind_schedule"]
        q = {
            "schema": "quoridor.research.numerical-qualification.v1",
            "status": "PASS",
            "phase": "corpus",
            "artifact_sha256": manifest["artifact"]["sha256"],
            "compiled_sources_sha256": self.env["canonical_sha"](manifest["compiled_sources"]),
            "config_sha256": config["sha256"],
            "schedule_sha256": schedule["sha256"],
            "input_sha256": [plan["sha256"]],
            "descriptor_sha256": [],
            "weights_sha256": [],
            "evaluator_sha256": [],
            "rules": e["rules"],
            "distance_units": e["distance_units"],
            "value_perspective": e["value_perspective"],
            "canonical_plan_sha256": plan["sha256"],
            "remaining": [],
            "generator_compiled_sources_sha256": self.env["canonical_sha"](
                manifest["generator_compiled_sources"]
            ),
        }
        self.docs[qref["path"]] = q
        return spec, e, manifest, {"next_learning_study": study}

    def test_corpus_exact_plan_depth_total_and_output_before_native(self):
        a = self.corpus()
        self.env["common_pilot_check"](*a)
        c = self.docs[a[1]["config"]["path"]]
        for key, value in [
            ("max_total_nodes", 2_000_000_000),
            ("depth", 4),
            ("output", "/other"),
            ("max_nodes", 0),
        ]:
            old = c[key]
            c[key] = value
            with self.assertRaises(ValueError):
                self.env["common_pilot_check"](*a)
            c[key] = old

    def test_corpus_current_numerical_and_generator_proof_not_copied_boolean(self):
        a = self.corpus()
        q = self.docs[a[1]["numerical_qualification"]["path"]]
        for key in [
            "artifact_sha256",
            "generator_compiled_sources_sha256",
            "canonical_plan_sha256",
            "input_sha256",
        ]:
            old = q[key]
            q[key] = "wrong"
            with self.assertRaises(ValueError):
                self.env["common_pilot_check"](*a)
            q[key] = old
        a[1]["numerical_qualification"] = None
        with self.assertRaises(TypeError):
            self.env["common_pilot_check"](*a)

    def test_software_mode_requires_exact_definition_and_result_scope(self):
        spec, e, m, plan = self.corpus()
        e.update(phase="software-qualification", numerical_qualification=None, planned_slots=0)
        py = "/synthetic/python"
        m["tools"] = {"PYTHON": {"file": {"path": py}}}
        result = "/synthetic/qualification/qualification.json"
        definition = self.ref(str(self.env["QUALIFIER"]))
        definition["sha256"] = self.env["QUALIFIER_SHA"]
        self.docs[e["config"]["path"]] = {
            "definition": definition,
            "helper_sources": [],
            "result": result,
        }
        e["inputs"] = [definition]
        warm = {
            "descriptor": self.ref("/synthetic/descriptor"),
            "weights": self.ref("/synthetic/weights"),
            "evaluator_sha256": "e" * 64,
        }
        plan["next_learning_study"]["common_learner_settings"] = {
            "experiment": {"warm_start": warm}
        }
        e["models"] = [warm]

        spec.update(
            data_root="/synthetic/qualification",
            cwd=str(ROOT),
            env={
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONPATH": "/home/vscode/.cache/inference/envs/quoridor-research-team/lib/python3.14/site-packages:"
                + str(ROOT / "python"),
                "OMP_NUM_THREADS": "1",
                "OPENBLAS_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1",
            },
            argv=[py, "-B", str(self.env["QUALIFIER"]), "--result", result],
            data=[{"name": "qualification", "path": result, "limit_B": 65536}],
        )
        self.env["common_pilot_check"](spec, e, m, plan)
        self.docs[e["config"]["path"]]["definition"]["sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            self.env["common_pilot_check"](spec, e, m, plan)
        e["numerical_qualification"] = self.ref("/fake/PASS")
        with self.assertRaises(ValueError):
            self.env["experiment_phase_check"](e)

    def test_fit_pairs_cache_partition_mask_and_current_recipe_are_required(self):
        spec, e, m, plan = self.corpus()
        e.update(phase="fit", planned_slots=0)
        py = "/synthetic/python"
        m["tools"] = {"PYTHON": {"file": {"path": py}}}
        warm = {
            "descriptor": self.ref("/synthetic/descriptor"),
            "weights": self.ref("/synthetic/weights"),
            "evaluator_sha256": "e" * 64,
        }
        settings = {
            "training": {"steps": 200, "batch_size": 64},
            "experiment": {"warm_start": warm},
        }
        plan["next_learning_study"]["common_learner_settings"] = settings
        e["models"] = [warm]
        second = self.ref("/synthetic/config-B")
        binding_ref = self.ref("/synthetic/input-binding")
        config = copy.deepcopy(settings)
        config["training"]["target"] = "z"
        other = copy.deepcopy(settings)
        other["training"]["target"] = "completed_root_raw"
        self.docs[e["config"]["path"]] = config
        self.docs[second["path"]] = other
        cache_ref = self.ref(str(self.env["PILOT_DATA"] / "cache/cache.json"))
        binding = {
            "selected_plan": {k: spec["approved_plan"][k] for k in ("path", "sha256")},
            "fit_config_sha": e["config"]["sha256"],
            "paired_fit_configs": [e["config"], second],
            "cache_manifest_sha": cache_ref["sha256"],
            "schedule_sha256": "s",
            "family_partition_sha256": "p",
            "dataset": {"source": "same"},
        }
        self.docs[binding_ref["path"]] = binding
        self.docs[cache_ref["path"]] = {
            "stream_intake": {"status": "complete"},
            "schedule_sha256": "s",
            "family_partition_sha256": "p",
            "source_binding": {"source": "same"},
            "common_corpus": {"common_eligible_by_split": {"train": 1, "validation": 1}},
        }
        e["inputs"] = [e["config"], second, binding_ref, cache_ref]
        q = self.docs[e["numerical_qualification"]["path"]]
        q.update(
            phase="fit",
            input_sha256=[r["sha256"] for r in e["inputs"]],
            descriptor_sha256=[warm["descriptor"]["sha256"]],
            weights_sha256=[warm["weights"]["sha256"]],
            evaluator_sha256=[warm["evaluator_sha256"]],
        )
        spec.update(
            data_root="/synthetic/unique-fit",
            cwd=str(ROOT),
            env={
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONPATH": "/home/vscode/.cache/inference/envs/quoridor-research-team/lib/python3.14/site-packages:"
                + str(ROOT / "python"),
                "OMP_NUM_THREADS": "1",
                "OPENBLAS_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1",
            },
            argv=[
                py,
                "-B",
                "-m",
                "quoridor_training.train",
                "train",
                "--cache",
                str(self.env["PILOT_DATA"] / "cache"),
                "--output",
                "/synthetic/unique-fit",
                "--config",
                e["config"]["path"],
                "--input-binding",
                binding_ref["path"],
            ],
        )
        spec["data"] = [
            {"path": str(Path(spec["data_root"]) / name)} for name in self.env["FIT_OUTPUTS"]
        ]
        self.env["common_pilot_check"](spec, e, m, plan)
        self.docs[second["path"]]["training"]["steps"] = 201
        with self.assertRaises(ValueError):
            self.env["common_pilot_check"](spec, e, m, plan)
        self.docs[second["path"]]["training"]["steps"] = 200
        self.docs[cache_ref["path"]]["common_corpus"]["common_eligible_by_split"]["validation"] = 0
        with self.assertRaises(ValueError):
            self.env["common_pilot_check"](spec, e, m, plan)

    def test_fit_caller_exact_current_imports_no_355_analysis_alias(self):
        paths = {
            ROOT / "scripts/dev/research-lifecycle.py",
            ROOT / "scripts/dev/research-job.py",
            ROOT / "python/quoridor_training/cycle_process.py",
            ROOT / "python/quoridor_training/snapshot.py",
        }
        paths |= {
            ROOT / "python/quoridor_training" / (name + ".py") for name in self.env["FIT_IMPORTS"]
        }
        spec = {"caller_sources": [self.ref(str(p)) for p in paths]}
        self.env["caller_source_refs"](spec, {"phase": "fit"})
        spec["caller_sources"].pop()
        with self.assertRaises(ValueError):
            self.env["caller_source_refs"](spec, {"phase": "fit"})


if __name__ == "__main__":
    unittest.main()
