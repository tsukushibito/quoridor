"""New AST-extracted saved-converter guard cases; no real cache/native/runtime proof."""

import ast
import copy
from pathlib import Path
import unittest

ROOT = Path("/workspaces/quoridor")
HERE = Path(__file__).resolve().parents[1]
SOURCE = HERE / "scripts/dev/research-lifecycle.py"
NAMES = {"cache_materialize_check", "experiment_phase_check", "common_pilot_check", "collect_data"}


class Refused(Exception):
    pass


def require(condition, message):
    if not condition:
        raise Refused(message)


class CompactGuard(unittest.TestCase):
    def setUp(self):
        tree = ast.parse(SOURCE.read_bytes())
        members = [
            x
            for x in tree.body
            if isinstance(x, ast.FunctionDef)
            and x.name in NAMES
            or isinstance(x, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == "COMPACT_CACHE_WIDTHS" for t in x.targets)
        ]
        self.documents = {}
        self.env = {
            "Path": Path,
            "require": require,
            "document": lambda ref: self.documents[ref["path"]],
            "PILOT_PLAN": ROOT / "research-data/ai-sigma/teacher-distance-tanh-v1/plan.json",
        }
        exec(compile(ast.Module(body=members, type_ignores=[]), str(SOURCE), "exec"), self.env)
        self.refs = {}

        def ref(path, value=None, size=3):
            result = {"path": str(path), "sha256": "a" * 64, "bytes": size, "mode": "0644"}
            self.refs[str(path)] = result
            if value is not None:
                self.documents[str(path)] = value
            return result

        plan = ref(self.env["PILOT_PLAN"])
        stream = ref(HERE / "synthetic-source.gz")
        schedule = ref(HERE / "synthetic-schedule.json", {})
        control = ref(HERE / "synthetic-binding.json")
        config = ref(HERE / "synthetic-generator.json", {})
        sources = ref(HERE / "synthetic-source-map.json", {})
        short = lambda r: {k: r[k] for k in ("path", "sha256")}
        content = {"compressed": stream, "raw_sha256": "b" * 64, "raw_bytes": 17}
        self.documents[control["path"]] = {
            "scope": "common-corpus",
            "stream": short(stream),
            "stream_content": content,
            "schedule": short(schedule),
            "config": short(config),
            "sources": short(sources),
        }
        previous = ref(
            HERE / "synthetic-old-cache/cache.json",
            {
                "schema": "quoridor-common-corpus-terminal-geometry-v2",
                "stream_intake": {"status": "complete"},
                "source_content": content,
                "schedule_sha256": schedule["sha256"],
                "rows": 1,
                "sha256": {},
                "common_corpus": {"config": {"selected_plan": short(plan)}},
            },
        )
        for name, width in self.env["COMPACT_CACHE_WIDTHS"].items():
            if name != "sampling.bin":
                item = ref(Path(previous["path"]).parent / name, size=width)
                self.documents[previous["path"]]["sha256"][name] = item["sha256"]
        output = HERE / "synthetic-NOT_CREATED"
        request = ref(
            HERE / "synthetic-request.json",
            {
                "schema": "quoridor.common-corpus-cache-materialization.v1",
                "stream": stream,
                "intake_binding": control,
                "previous_cache": previous,
                "output": str(output),
            },
        )
        self.manifest = {
            "artifact_target": "terminal-cache",
            "artifact": ref(HERE / "synthetic-binary"),
        }
        self.spec = {
            "data_root": str(output),
            "approved_plan": plan,
            "data": [{"name": n, "path": str(output / n)} for n in self.env["COMPACT_CACHE_WIDTHS"]]
            + [{"name": "cache_manifest", "path": str(output / "cache.json")}],
        }
        self.experiment = {
            "phase": "materialize",
            "models": [],
            "planned_slots": 0,
            "batch": None,
            "numerical_qualification": None,
            "config": request,
            "schedule": schedule,
            "rules": "research-standard-2p-threefold-goal-first-v1",
            "distance_units": "wall-distance/80",
            "value_perspective": "side-to-move",
            "inputs": [
                r
                for p, r in self.refs.items()
                if p not in {request["path"], self.manifest["artifact"]["path"]}
            ],
            "argv": [
                self.manifest["artifact"]["path"],
                stream["path"],
                str(output),
                control["path"],
                control["sha256"],
            ],
        }

    def check(self, e=None, s=None):
        e, s = e or self.experiment, s or self.spec
        self.env["experiment_phase_check"](e)
        self.env["cache_materialize_check"](s, e, self.manifest)

    def test_saved_exact_shape_and_changed_lifetime_inputs_refuse(self):
        self.check()
        for field in ("path", "sha256", "bytes"):
            changed = copy.deepcopy(self.experiment)
            stream = next(r for r in changed["inputs"] if r["path"].endswith("synthetic-source.gz"))
            stream[field] = "wrong" if field != "bytes" else 2
            with self.subTest(field=field), self.assertRaises(Refused):
                self.check(changed)
        changed = copy.deepcopy(self.experiment)
        changed["inputs"].append(changed["inputs"][0])
        with self.assertRaises(Refused):
            self.check(changed)

    def test_codec_cannot_claim_models_games_or_change_output_argv(self):
        self.check()
        for field, value in (
            ("models", [{}]),
            ("planned_slots", 8),
            ("batch", 0),
            ("numerical_qualification", {}),
            ("rules", "wrong"),
        ):
            changed = copy.deepcopy(self.experiment)
            changed[field] = value
            with self.subTest(field=field), self.assertRaises(Refused):
                self.check(changed)
        changed = copy.deepcopy(self.experiment)
        changed["argv"][2] += "-other"
        with self.assertRaises(Refused):
            self.check(changed)

    def test_fit_compact_binary_lifetime_and_partial_marker_refuse(self):
        import tempfile
        import hashlib

        # Whole method is production AST; numerical/math and approved recipe are synthetic fixtures.
        with tempfile.TemporaryDirectory(prefix="compact-parent-test-") as directory:
            data = Path(directory)
            (data / "cache-compact-v3").mkdir()
            self.env.update(
                ROOT=ROOT,
                PILOT_DATA=data,
                FIT_OUTPUTS=(),
                numerical_check=lambda *_: None,
            )
            selected = {"descriptor": {}, "weights": {}, "evaluator_sha256": "c" * 64}
            recipe = {
                "experiment": {"warm_start": selected},
                "training": {"steps": 200, "batch_size": 64},
            }
            a, b = {"path": "A", "sha256": "d" * 64}, {"path": "B", "sha256": "e" * 64}
            self.documents["A"] = {
                **copy.deepcopy(recipe),
                "training": {**recipe["training"], "target": "z"},
            }
            self.documents["B"] = {
                **copy.deepcopy(recipe),
                "training": {**recipe["training"], "target": "completed_root_raw"},
            }
            binding = {"path": "binding", "sha256": "f" * 64}
            cache_ref = {"path": str(data / "cache-compact-v3/cache.json"), "sha256": "1" * 64}
            short_plan = {k: self.spec["approved_plan"][k] for k in ("path", "sha256")}
            self.documents["binding"] = {
                "selected_plan": short_plan,
                "fit_config_sha": a["sha256"],
                "paired_fit_configs": [a, b],
                "cache_manifest_sha": cache_ref["sha256"],
                "schedule_sha256": "2" * 64,
                "family_partition_sha256": "3" * 64,
                "dataset": {},
            }
            cache = {
                "schema": "quoridor-common-corpus-terminal-geometry-v3",
                "rows": 1,
                "files": {n: n for n in self.env["COMPACT_CACHE_WIDTHS"]},
                "sha256": {},
                "file_bytes": {},
                "stream_intake": {"status": "complete"},
                "schedule_sha256": "2" * 64,
                "family_partition_sha256": "3" * 64,
                "source_binding": {},
                "common_corpus": {"common_eligible_by_split": {"train": 1, "validation": 1}},
            }
            binary_refs = []
            for name, width in self.env["COMPACT_CACHE_WIDTHS"].items():
                raw = bytes(width)
                digest = hashlib.sha256(raw).hexdigest()
                cache["sha256"][name] = digest
                cache["file_bytes"][name] = width
                binary_refs.append(
                    {
                        "path": str(data / "cache-compact-v3" / name),
                        "sha256": digest,
                        "bytes": width,
                    }
                )
            self.documents[cache_ref["path"]] = cache
            spec = {
                "approved_plan": self.spec["approved_plan"],
                "cwd": str(ROOT),
                "data_root": str(data / "fit"),
                "env": {
                    "PYTHONDONTWRITEBYTECODE": "1",
                    "PYTHONPATH": "/home/vscode/.cache/inference/envs/quoridor-training/lib/python3.14/site-packages:"
                    + str(ROOT / "python"),
                    "OMP_NUM_THREADS": "1",
                    "OPENBLAS_NUM_THREADS": "1",
                    "MKL_NUM_THREADS": "1",
                },
                "argv": [
                    "PYTHON",
                    "-B",
                    "-m",
                    "quoridor_training.train",
                    "train",
                    "--cache",
                    str(data / "cache-compact-v3"),
                    "--output",
                    str(data / "fit"),
                    "--config",
                    "A",
                    "--input-binding",
                    "binding",
                ],
                "data": [],
            }
            experiment = {
                **self.experiment,
                "phase": "fit",
                "config": a,
                "models": [selected],
                "inputs": [a, b, binding, cache_ref, *binary_refs],
            }
            manifest = {"tools": {"PYTHON": {"file": {"path": "PYTHON"}}}}
            approved = {
                "next_learning_study": {
                    "issue": "quoridor-4lc.362",
                    "scientific_entry": True,
                    "corpus": {"quantity_families": 8},
                    "common_learner_settings": recipe,
                }
            }
            # document normally reparses immutable bytes; emulate a new parse for recipes.
            self.env["document"] = lambda ref: copy.deepcopy(self.documents[ref["path"]])
            check = self.env["common_pilot_check"]
            check(spec, experiment, manifest, approved)
            for field, value in (("sha256", "wrong"), ("bytes", 3)):
                bad = copy.deepcopy(experiment)
                bad["inputs"][-1][field] = value
                with self.subTest(field=field), self.assertRaises(Refused):
                    check(spec, bad, manifest, approved)
            (data / "cache-compact-v3/intake-incomplete.json").write_bytes(b"pending")
            with self.assertRaises(Refused):
                check(spec, experiment, manifest, approved)


if __name__ == "__main__":
    unittest.main()
