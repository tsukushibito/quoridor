from pathlib import Path

R = Path(__file__).parent


def edit(name, old, new):
    p = R / "crates/quoridor-runner/src" / name
    s = p.read_text()
    assert old in s, (name, old[:80])
    p.write_text(s.replace(old, new))


edit(
    "teacher_pilot.rs",
    "    pub max_nodes: u64,",
    '    pub max_nodes: u64,\n    #[serde(default, skip_serializing_if = "Option::is_none")]\n    pub max_total_nodes: Option<u64>,',
)
edit(
    "teacher_pilot.rs",
    "if self.common_study.is_some()",
    "if self.max_total_nodes.is_some()\n            || self.common_study.is_some()",
)
edit(
    "teacher_pilot/depth6.rs",
    "        || c.max_nodes == 0",
    "        || c.max_nodes != 100_000_000\n        || c.max_total_nodes != Some(1_000_000_000)",
)
edit(
    "teacher_pilot/depth6.rs",
    "    if c.common_study.is_some()",
    "    if c.max_total_nodes.is_some() || c.common_study.is_some()",
)
edit(
    "teacher_pilot_execution.rs",
    "atomic::{AtomicBool, Ordering}",
    "atomic::{AtomicBool, AtomicU64, Ordering}",
)
edit(
    "teacher_pilot_execution.rs",
    "    let evaluator = Arc::new(DistanceEvaluator::new(0., 8.));",
    "    play_with_budget(slot, assignment, cancel, policy, None)\n}\n\nfn play_with_budget(\n    slot: &ScheduledGame, assignment: &FamilyAssignment, cancel: &AtomicBool,\n    policy: SearchPolicy, budget: Option<&NodeBudget>,\n) -> Result<GameRecord> {\n    let evaluator = Arc::new(DistanceEvaluator::new(0., 8.));",
)
edit(
    "teacher_pilot_execution.rs",
    "    let limits = SearchLimits {",
    "    let mut limits = SearchLimits {",
)
edit(
    "teacher_pilot_execution.rs",
    """        sessions[usize::from(context.position().turn)]
            .search(context, &limits, cancel)
            .map_err(Into::into)""",
    """        let reserved = match budget {
            Some(b) => b.reserve(policy.nodes)?,
            None => policy.nodes,
        };
        limits.max_nodes = reserved;
        let result = sessions[usize::from(context.position().turn)].search(context, &limits, cancel);
        // An Err has opaque work: retain the whole reservation, never charge zero.
        if let (Some(b), Ok(r)) = (budget, &result) {
            b.settle(reserved, r.stats.nodes)?;
        }
        result.map_err(Into::into)""",
)
# bounded common reservation, no new search method
p = R / "crates/quoridor-runner/src/teacher_pilot_execution.rs"
s = p.read_text()
idx = s.index("\nfn scheduled_failure(")
s = (
    s[:idx]
    + """
/// Shared finite work ceiling. Unreturned/error work retains its reservation.
struct NodeBudget { remaining: AtomicU64 }
impl NodeBudget {
    fn new(nodes: u64) -> Self { Self { remaining: AtomicU64::new(nodes) } }
    fn reserve(&self, per_move: u64) -> Result<u64> {
        let mut old = self.remaining.load(Ordering::Acquire);
        loop {
            let take = old.min(per_move);
            if take == 0 { return Err("common_total_node_cap; remaining decisions UNKNOWN".into()); }
            match self.remaining.compare_exchange_weak(old, old-take, Ordering::AcqRel, Ordering::Acquire) {
                Ok(_) => return Ok(take), Err(now) => old=now,
            }
        }
    }
    fn settle(&self, reserved: u64, returned: u64) -> Result<()> {
        if returned > reserved { return Err("returned nodes exceed reserved common ceiling".into()); }
        self.remaining.fetch_add(reserved-returned, Ordering::AcqRel);
        Ok(())
    }
}
#[cfg(test)]
mod common_node_budget_tests {
    use super::*;
    #[test]
    fn parallel_reservations_returned_work_and_opaque_error_cannot_exceed_total() {
        let b=NodeBudget::new(11);
        let a=b.reserve(7).unwrap(); let c=b.reserve(7).unwrap();
        assert_eq!((a,c),(7,4)); assert!(b.reserve(1).is_err());
        b.settle(a,5).unwrap(); assert_eq!(b.reserve(7).unwrap(),2);
        // The second reservation represents an unreturned Err; no refund.
        assert!(b.reserve(1).is_err()); assert!(b.settle(c,5).is_err());
    }
}
"""
    + s[idx:]
)
s = s.replace(
    "                max_nodes: 100000,",
    "                max_nodes: 100000,\n                max_total_nodes: None,",
)
p.write_text(s)
p = R / "crates/quoridor-runner/src/teacher_pilot_execution/depth6.rs"
s = p.read_text()
s = s.replace(
    "            max_nodes: u64::MAX,",
    "            max_nodes: u64::MAX,\n            max_total_nodes: None,",
)
s = s.replace(
    "        let joined = scheduling::ordered(",
    "        let budget = config.max_total_nodes.map(NodeBudget::new);\n        let joined = scheduling::ordered(",
)
s = s.replace(
    "                play_with_policy(slot, a, cancel, policy(config))",
    "                play_with_budget(slot, a, cancel, policy(config), budget.as_ref())",
)
p.write_text(s)
edit(
    "research_manifest.rs",
    '"compiled_sources":sources(),',
    '"compiled_sources":sources(),"generator_compiled_sources":crate::teacher_pilot_execution::compiled_sources(),',
)
edit(
    "research_manifest.rs",
    '        "arena" => {',
    """        "corpus" => {
            e.numerical_qualification.is_some() && e.models.is_empty()
                && e.planned_slots == 8 && e.batch.is_none()
                && e.argv.len() == 6
                && e.argv[1..] == ["teacher-pilot", "--experiment", "@EXPERIMENT@", "--experiment-sha256", "@EXPERIMENT_SHA256@"]
        }
        "arena" => {""",
)
edit(
    "research_manifest.rs",
    '(phase == "arena" && q["canonical_plan_sha256"] != approved.sha256)',
    '(matches!(phase, "arena" | "corpus") && q["canonical_plan_sha256"] != approved.sha256)',
)
edit(
    "main.rs",
    """        && !(args.len() == 3""",
    """        && !(args.len() == 5 && args[1] == "--experiment" && args[3] == "--experiment-sha256"
            || args.len() == 3""",
)
edit(
    "main.rs",
    """        "teacher-pilot" if args.iter().any(|a| a == "--audit") => {""",
    """        "teacher-pilot" if args.iter().any(|a| a == "--experiment") => {
            strict_pairs(&args, &["--experiment", "--experiment-sha256"], &[])?;
            let bound = quoridor_runner::sigma_qualification::BoundControl {
                path: argument(&args, "--experiment")?.into(),
                sha256: argument(&args, "--experiment-sha256")?,
            };
            println!("{}", serde_json::to_string(&quoridor_runner::teacher_pilot_execution::run_bound(&bound)?)?);
        }
        "teacher-pilot" if args.iter().any(|a| a == "--audit") => {""",
)
p = R / "crates/quoridor-runner/src/teacher_pilot_execution/depth6.rs"
s = p.read_text()
needle = "        stream.append(&Record::Header(Box::new(header.clone())))?;"
assert needle in s
s = s.replace(
    needle,
    needle
    + """
        if matches!(config.phase, teacher_pilot::Phase::CommonCorpus) {
            let raw_requests = serde_json::to_vec(&requests(config, &header.config_sha256))?;
            let mut request_line=raw_requests; request_line.push(b'\\n');
            save_control(&config.output.join("sources.json"), &serde_json::json!({
                "schema":header.schema,"generator_version":header.generator_version,
                "executable_sha256":header.executable_sha256,"compiled_sources":header.compiled_sources,
                "evaluator":header.evaluator,"resource_admission":header.resource_admission}))?;
            save_control(&config.output.join("schedule.json"), &serde_json::json!({
                "scheduled":header.scheduled,"family_partition":header.family_partition,
                "requests_sha256":format!("{:x}",Sha256::digest(&request_line))}))?;
        }
""",
)
p.write_text(s)
p = R / "crates/quoridor-runner/src/teacher_pilot_execution.rs"
s = p.read_text()
i = s.index("\n/// No inference backend or model loading: one serial fixed-D process.")
s = (
    s[:i]
    + """
fn save_control(path: &Path, value: &Value) -> Result<()> {
    let raw=serde_json::to_vec(value)?;
    if raw.len()>1024*1024 { return Err("common control bound".into()); }
    let mut f=OpenOptions::new().create_new(true).write(true).open(path)?;
    f.write_all(&raw)?; f.sync_all()?; Ok(())
}
fn control_ref(path: &Path) -> Result<quoridor_data::terminal_stream::BoundJson> {
    Ok(quoridor_data::terminal_stream::BoundJson {path:path.into(),sha256:quoridor_data::file_sha(path)?})
}
/// One qualified native invocation: retained compressed generation, then the shared cache.
pub fn run_bound(bound: &crate::sigma_qualification::BoundControl) -> Result<Value> {
    let (e,q)=crate::research_manifest::load(bound,"corpus")?;
    let config: PilotConfig=e.config.read()?;
    config.validate()?;
    let study=config.common_study.as_ref().ok_or("common study required")?;
    if !matches!(config.phase, teacher_pilot::Phase::CommonCorpus)
        || study.selected_plan.sha256!=e.canonical_plan_sha256
        || e.inputs.first().is_none_or(|r| r.path!=study.selected_plan.path || r.sha256!=study.selected_plan.sha256)
        || e.schedule.read::<Value>()?!=study.schedule_choice()
        || q["generator_compiled_sources_sha256"]!=crate::arena::json_digest(&compiled_sources())?
    { return Err("current common generator/approved plan/schedule qualification differs".into()); }
    let build:Value=e.build_manifest.read()?;
    if build["generator_compiled_sources"]!=serde_json::to_value(compiled_sources())? {
        return Err("qualified current generator source closure required".into());
    }
    let report=run(&config,e.config.sha256.clone())?;
    save_control(&config.output.join("generation-result.json"), &serde_json::to_value(&report)?)?;
    let content_path=config.output.join("stream-content.json");
    if fs::metadata(&content_path)?.len()>65536 { return Err("content metadata bound".into()); }
    let content:quoridor_data::lossless_jsonl::Content=serde_json::from_slice(&fs::read(&content_path)?)?;
    let schedule_path=config.output.join("schedule.json");
    let schedule:Value=serde_json::from_slice(&fs::read(&schedule_path)?)?;
    let binding=quoridor_data::terminal_stream::IntakeBinding {
        schema:"quoridor-terminal-stream-intake-v1".into(),scope:"common-corpus".into(),human_quantity_n:Some(study.families),
        stream:quoridor_data::terminal_stream::BoundJson{path:content.compressed.path.clone(),sha256:content.compressed.sha256.clone()},
        config:quoridor_data::terminal_stream::BoundJson{path:e.config.path.clone(),sha256:e.config.sha256.clone()},
        sources:control_ref(&config.output.join("sources.json"))?,schedule:control_ref(&schedule_path)?,
        requests_sha256:schedule["requests_sha256"].as_str().ok_or("request SHA")?.into(),
        max_stream_bytes:config.max_output_bytes,max_compressed_bytes:Some(256*1024*1024),
        stream_content:Some(content.clone()), max_line_bytes:GAME_BYTES,
    };
    let path=config.output.join("intake-binding.json");
    save_control(&path, &serde_json::to_value(binding)?)?;
    let cache=quoridor_data::terminal_stream::write_cache(&content.compressed.path,&config.output.join("cache"),&path,&quoridor_data::file_sha(&path)?)?;
    Ok(serde_json::json!({"planned":config.planned_games,"generation":report,"shared_cache":cache,"status":"DATA_RETURNED_PENDING_EXTERNAL_FINALIZATION"}))
}
"""
    + s[i:]
)
p.write_text(s)
