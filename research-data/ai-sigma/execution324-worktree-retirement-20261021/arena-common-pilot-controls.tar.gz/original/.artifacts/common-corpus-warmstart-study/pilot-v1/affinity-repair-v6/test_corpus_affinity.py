"""One new actual child-affinity / wrong-phase refusal discriminator; no science."""

import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent


class CorpusAffinity(unittest.TestCase):
    def test_actual_four_core_child_and_unrelated_phase_refusal(self):
        module_spec = importlib.util.spec_from_file_location(
            "quoridor_training._362_affinity_process",
            ROOT / "python/quoridor_training/cycle_process.py",
        )
        process = importlib.util.module_from_spec(module_spec)
        module_spec.loader.exec_module(process)
        tree = ast.parse((ROOT / "scripts/dev/research-lifecycle.py").read_text())
        selected = ast.Module(
            body=[n for n in tree.body if getattr(n, "name", None) in {"Capture", "command"}],
            type_ignores=[],
        )

        def require(value, message):
            if not value:
                raise ValueError(message)

        def bound(path, limit=None):
            raw = Path(path).read_bytes()
            return (
                {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)},
                raw,
            )

        ns = {
            "process": process,
            "Path": Path,
            "os": os,
            "require": require,
            "bound": bound,
            "document": lambda ref: ref,
            "error_fact": lambda e: {"type": type(e).__name__, "message": str(e)},
            "settled": lambda r: require(
                r["exit_code"] == 0 and r["cleanup_complete"] is True, "actual clean return"
            ),
        }
        exec(compile(selected, "exact-owned-publisher-command", "exec"), ns)
        with tempfile.TemporaryDirectory(dir=ROOT) as temporary:
            directory = Path(temporary)
            spec = {
                "kind": "run",
                "experiment": {"phase": "corpus"},
                "limits": {"worker_cpu": 2, "log_B": 65536},
                "child_cpu_cores": [0, 2, 4, 6],
                "cwd": str(ROOT),
                "env": dict(os.environ),
            }
            row = {
                "name": "actual-affinity",
                "role": "run",
                "argv": [
                    sys.executable,
                    "-B",
                    "-c",
                    "import os,json; print(json.dumps(sorted(os.sched_getaffinity(0))))",
                ],
            }
            returned, full = ns["command"](spec, row, directory, None, process.execute)
            self.assertEqual(json.loads(full.read_text()), [0, 2, 4, 6])
            self.assertTrue(returned["direct_child_reaped"])
            self.assertTrue(returned["handle_closes_complete"])
            self.assertTrue(returned["process_cleanup_complete"])
            self.assertEqual(returned["remaining"], [])
            spec["experiment"] = {"phase": "fit"}
            row["name"] = "wrong-phase"
            with self.assertRaisesRegex(ValueError, "only the qualified corpus"):
                ns["command"](
                    spec, row, directory, None, lambda *a, **k: self.fail("unrelated child entered")
                )


if __name__ == "__main__":
    unittest.main(verbosity=2)
