"""New external-plan/native-dependency discrimination; no science or imports."""

import ast
import copy
import hashlib
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent


class RuntimePlan(unittest.TestCase):
    def test_current_external_plan_preserves_native_inputs_and_old_manifest(self):
        tree = ast.parse((ROOT / "research-lifecycle.py").read_text())
        selected = ast.Module(
            body=[
                n
                for n in tree.body
                if getattr(n, "name", None)
                in {
                    "runtime_dependency_refs",
                    "native_source_refs",
                    "build_input_refs",
                    "accepted_build",
                }
            ],
            type_ignores=[],
        )
        with tempfile.TemporaryDirectory(dir=ROOT) as temporary:
            base = Path(temporary)
            (base / "research-data").mkdir()
            (base / "crates").mkdir()

            def ref(path):
                return {
                    "path": str(path),
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "bytes": path.stat().st_size,
                    "mode": "0644",
                }

            def require(condition, message):
                if not condition:
                    raise ValueError(message)

            def read_ref(reference, limit=None):
                raw = Path(reference["path"]).read_bytes()
                require(
                    hashlib.sha256(raw).hexdigest() == reference["sha256"], "exact dependency drift"
                )
                return raw

            def write(path, raw):
                path.write_bytes(raw)
                return ref(path)

            native = write(base / "crates/native.rs", b"SYNTHETIC native")
            lock = write(base / "Cargo.lock", b"SYNTHETIC lock")
            cargo = write(base / "Cargo.toml", b"SYNTHETIC manifest")
            tool = write(base / "tool", b"SYNTHETIC tool")
            artifact = write(base / "artifact", b"SYNTHETIC no executable")
            plan = base / "research-data/plan.json"
            old_plan = write(plan, b'{"old":true}')
            current = write(plan, b'{"current":true}')
            source = {
                "workspace": str(base),
                "files": [native, lock, cargo],
                "compiled_sources": {"native": native},
                "manifest": cargo,
                "lock": lock,
                "cargo_configs": [],
            }
            manifest = {
                "schema": "fixture-only-BUILD",
                "status": "PASS",
                "cleanup_complete": True,
                "remaining": [],
                "checks": [{"role": r} for r in ("test", "lint", "build", "bindings")],
                "artifact": artifact,
                "source": source,
                "compiled_sources": {"native": native["sha256"]},
                "dependency_refs": [lock, tool, old_plan],
                "tools": {"TOOL": {"file": tool, "version": "fixture-only"}},
            }
            original = copy.deepcopy(manifest)
            ns = {
                "ROOT": base,
                "Path": Path,
                "CONTROL_BYTES": 65536,
                "BUILD_SCHEMA": "fixture-only-BUILD",
                "require": require,
                "read_ref": read_ref,
                "document": lambda ref: manifest,
            }
            exec(compile(selected, "exact-owned-runtime-plan-boundary", "exec"), ns)
            ns["source_check"] = lambda src, native_only=False: [
                read_ref(r) for r in ns["native_source_refs"](src)
            ]
            self.assertIs(
                ns["accepted_build"]({"path": str(base / "manifest.json")}, current), manifest
            )
            lifetime = ns["build_input_refs"](manifest, current)
            self.assertIn(current, lifetime)
            self.assertNotIn(old_plan, lifetime)
            self.assertEqual(manifest, original)
            self.assertIn(tool, lifetime)
            self.assertIn(lock, lifetime)
            (base / "Cargo.lock").write_bytes(b"changed")
            with self.assertRaisesRegex(ValueError, "dependency drift"):
                ns["accepted_build"]({"path": str(base / "manifest.json")}, current)
            (base / "Cargo.lock").write_bytes(b"SYNTHETIC lock")
            manifest["source"]["files"].append(old_plan)
            with self.assertRaisesRegex(ValueError, "cannot replace"):
                ns["runtime_dependency_refs"](manifest, current)


if __name__ == "__main__":
    unittest.main(verbosity=2)
