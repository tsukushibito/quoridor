"""One new actual collect_data AST regression; maintained-shaped synthetic reports, NN0."""

import ast
import copy
import json
from pathlib import Path
import unittest


class CorpusReportCase(unittest.TestCase):
    def test_scheduled_denominator_no_planned_alias_partial_and_missing_refuse(self):
        module = ast.parse(Path(__file__).with_name("research-lifecycle.py").read_text())
        fn = next(
            n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == "collect_data"
        )
        report = {
            "scheduled": 8,
            "recorded": 8,
            "goals": 7,
            "draws": 0,
            "unknown": 1,
            "search_nodes": 17,
        }
        values = {
            "generation_result": json.dumps(report).encode(),
            "cache_manifest": b'{"stream_intake":{"status":"complete"}}',
            "stream_content": b'{"compressed":{"path":"/synthetic/gzip","sha256":"b","bytes":1,"mode":"0644"},"raw_sha256":"a","raw_bytes":8}',
        }

        def require(condition, message):
            if not condition:
                raise ValueError(message)

        env = {
            "json": json,
            "Path": Path,
            "owned": lambda p, o: Path(p),
            "bound": lambda p, limit: ({"path": p}, values[p]),
            "read_ref": lambda r, limit: b"x",
            "require": require,
            "error_fact": lambda error: {"type": type(error).__name__, "message": str(error)},
        }
        exec(
            compile(ast.Module(body=[fn], type_ignores=[]), "actual collect_data AST", "exec"), env
        )
        spec = {
            "owner": "/synthetic",
            "data": [{"name": k, "path": k, "limit_B": 65536} for k in values],
        }
        experiment = {"phase": "corpus", "planned_slots": 8, "batch": None}
        result = env["collect_data"](spec, experiment)
        self.assertEqual(
            (result["status"], result["planned_slots"], result["unknown"]), ("PASS", 8, 1)
        )
        self.assertFalse(result["global_campaign_complete"])
        for mutation in ({"recorded": 7}, {"scheduled": 7}):
            changed = {**report, **mutation}
            values["generation_result"] = json.dumps(changed).encode()
            failed = env["collect_data"](spec, experiment)
            self.assertEqual(failed["status"], "FAILED")
            self.assertEqual(failed["planned_slots"], 8)
            self.assertTrue(failed["errors"])
        values["generation_result"] = json.dumps(
            {k: v for k, v in report.items() if k != "scheduled"}
        ).encode()
        self.assertEqual(env["collect_data"](spec, experiment)["status"], "FAILED")
        values["generation_result"] = json.dumps(report).encode()
        bad = copy.deepcopy(experiment)
        bad["planned_slots"] = 0
        self.assertEqual(env["collect_data"](spec, bad)["status"], "FAILED")


if __name__ == "__main__":
    unittest.main()
