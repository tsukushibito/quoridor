"""One NN0 fixture: vanished DirEntry retry and exhausted-inventory uncertainty."""

from contextlib import contextmanager
import importlib.util
import json
from pathlib import Path
import tempfile
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("arena_software_guard", HERE / "verify.py")
GUARD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GUARD)


class VanishedEntry:
    def __init__(self, path):
        self.path = str(path)

    def stat(self, *, follow_symlinks):
        raise FileNotFoundError(
            2, "fixture entry disappeared after directory enumeration", self.path
        )


def main():
    real_scandir = GUARD.os.scandir
    with tempfile.TemporaryDirectory(dir=HERE / "tmp") as directory:
        root = Path(directory)
        keep = root / "keep.bin"
        keep.write_bytes(b"keep this current allocation")
        vanished = root / "own-linker.rcgu.o"
        vanished.write_bytes(b"temporary")
        attempts = []

        @contextmanager
        def disappear_once(path):
            attempts.append(str(path))
            if len(attempts) == 1:
                vanished.unlink()
                yield [VanishedEntry(vanished)]
            else:
                with real_scandir(path) as entries:
                    yield entries

        GUARD.INVENTORY_RACES.clear()
        with patch.object(GUARD.os, "scandir", disappear_once):
            found = GUARD.inventory(root)
        assert len(attempts) == 2
        assert set(found) == {str(keep)}
        assert found[str(keep)][2] == keep.stat().st_blocks * 512
        assert len(GUARD.INVENTORY_RACES) == 1
        assert GUARD.INVENTORY_RACES[0]["path"] == str(vanished)
        completed_retry_evidence = list(GUARD.INVENTORY_RACES)
        attempts.clear()

        @contextmanager
        def always_inconsistent(path):
            attempts.append(str(path))
            yield [VanishedEntry(keep)]

        GUARD.INVENTORY_RACES.clear()
        refused = False
        with patch.object(GUARD.os, "scandir", always_inconsistent):
            try:
                GUARD.inventory(root)
            except GUARD.PROCESS.CycleStopped as error:
                refused = "three full attempts" in str(error)
        assert refused and len(attempts) == 3 and len(GUARD.INVENTORY_RACES) == 3
        assert keep.exists()
        (HERE / "inventory-qualification.json").write_text(
            json.dumps(
                {
                    "NN": 0,
                    "GPU": 0,
                    "fixture_pass": True,
                    "complete_retry_preserves_current_allocation": True,
                    "exhausted_retry_refuses_admission_as_unknown": True,
                    "completed_retry_evidence": completed_retry_evidence,
                    "exhausted_retry_evidence": GUARD.INVENTORY_RACES,
                },
                indent=2,
            )
            + "\n"
        )


if __name__ == "__main__":
    main()
