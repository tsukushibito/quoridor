"""One bounded software phase; use canonical child cleanup without model or game execution."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import time

ROOT = Path("/workspaces/quoridor/.worktree/arena-evaluation")
OUT = ROOT / ".artifacts/software-validation"
EVIDENCE = Path("/workspaces/quoridor/research-data/ai-sigma/arena-evaluation")
TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")
SPEC = importlib.util.spec_from_file_location(
    "canonical_cycle_process", "/workspaces/quoridor/python/quoridor_training/cycle_process.py"
)
PROCESS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PROCESS)
INVENTORY_RACES = []


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def inventory(root):
    # Each attempt observes a whole inventory. Never substitute zero for a raced file.
    for attempt in range(3):
        result, pending = {}, [root]
        try:
            while pending:
                directory = pending.pop()
                with os.scandir(directory) as entries:
                    for entry in entries:
                        info = entry.stat(follow_symlinks=False)
                        if stat.S_ISDIR(info.st_mode):
                            pending.append(Path(entry.path))
                        elif stat.S_ISREG(info.st_mode):
                            result[entry.path] = (info.st_dev, info.st_ino, info.st_blocks * 512)
            return result
        except FileNotFoundError as error:
            INVENTORY_RACES.append(
                {
                    "at": timestamp(),
                    "root": str(root),
                    "attempt": attempt + 1,
                    "path": error.filename,
                }
            )
    raise PROCESS.CycleStopped("storage inventory raced after three full attempts")


def allocated(roots):
    identities = {}
    for root in roots:
        for device, inode, size in inventory(root).values():
            identities[(device, inode)] = size
    return sum(identities.values())


class Resources(PROCESS.CycleResources):
    def __init__(self, deadline, baseline):
        super().__init__(
            {"max_memory_bytes": 2 * 1024**3 - 64 * 1024**2, "max_output_bytes": 8 * 1024**2},
            OUT,
            deadline,
        )
        self.baseline = baseline
        self.last_storage = 0.0
        self.peak_increment = 0
        self.peak_rss_including_controller = 0

    def check(self, owned=()):
        infos = [
            PROCESS.process_info(os.getpid()),
            *(PROCESS.process_info(m["pid"]) for m in owned),
        ]
        rss = sum(info["rss"] for info in infos if info) + 64 * 1024**2
        self.peak_rss_including_controller = max(self.peak_rss_including_controller, rss)
        if rss > 2 * 1024**3:
            raise PROCESS.CycleStopped("family RSS including controller reserve exceeds 2GiB")
        super().check(owned)
        if time.monotonic() - self.last_storage >= 0.5:
            self.last_storage = time.monotonic()
            current = inventory(TARGET)
            increment = sum(
                max(0, value[2] - self.baseline.get(path, (0, 0, 0))[2])
                for path, value in current.items()
            )
            temporary = allocated([OUT / "tmp"])
            self.peak_increment = max(self.peak_increment, increment + temporary)
            if increment + temporary > 40 * 1024**2:
                raise PROCESS.CycleStopped("build/linker/tmp positive increment exceeds 40MiB")
            if (
                allocated(
                    [
                        ROOT,
                        EVIDENCE,
                        Path("/workspaces/quoridor/.artifacts/arena-evaluation-launch"),
                    ]
                )
                + increment
                > 64 * 1024**2
            ):
                raise PROCESS.CycleStopped("arena inclusive scope exceeds 64MiB")


def main():
    os.chdir(ROOT)
    os.sched_setaffinity(0, {0, 1})
    plan = json.loads((EVIDENCE / "software-phase-prepared.json").read_text())
    admission = json.loads((OUT / "prelaunch.json").read_text())
    storage = json.loads(Path(admission["storage_observation"]).read_text())
    if storage["admission"] != "within" or storage["errors"]:
        raise RuntimeError("completed fresh storage admission required")
    if (datetime.now(timezone.utc) - datetime.fromisoformat(storage["at"])).total_seconds() > 300:
        raise RuntimeError("storage observation expired")
    for item in admission["frozen_files"]:
        if hashlib.sha256(Path(item["path"]).read_bytes()).hexdigest() != item["sha256"]:
            raise RuntimeError("frozen source/control/native/receipt changed: " + item["path"])
    for pid in admission["318_identities"]:
        member = {"pid": pid["pid"], "start_ticks": pid["tick"], "boot_id": pid["boot"]}
        if PROCESS.alive(member):
            raise RuntimeError("318 exact child remains")
    for entry in Path("/proc").iterdir():
        if entry.name.isdigit():
            try:
                argv = (entry / "cmdline").read_bytes().split(b"\0")
                exe = Path(argv[0].decode()).name if argv[0] else ""
                if exe in ("cargo", "rustc", "clippy-driver", "rust-lld", "ld.lld"):
                    raise RuntimeError("foreign compiler present; no interruption: " + entry.name)
            except (FileNotFoundError, PermissionError):
                pass
    os.environ.update(plan["env"])
    os.environ["PATH"] = "/usr/local/cargo/bin:" + os.environ["PATH"]
    (OUT / "tmp").mkdir(exist_ok=True)
    baseline = inventory(TARGET)
    (OUT / "target-before.json").write_text(json.dumps(baseline, sort_keys=True) + "\n")
    started, start = timestamp(), time.monotonic()
    resources = Resources(start + 270, baseline)
    result = {"started": started, "commands": [], "no_arena_or_clock_job": True, "NN": 0, "GPU": 0}
    failure = None
    with (TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            with PROCESS.cancellation_signals():
                for index, command in enumerate(plan["commands"]):
                    record = PROCESS.execute(
                        command,
                        OUT / f"command-{index}.log",
                        resources.deadline,
                        resources=resources,
                    )
                    result["commands"].append(record)
        except BaseException as error:
            failure = error
        finally:
            result.update(
                ended=timestamp(),
                wall_seconds=time.monotonic() - start,
                error=str(failure) if failure else None,
                build_linker_tmp_peak_positive_bytes=resources.peak_increment,
                peak_family_RSS_including_controller_reserve=resources.peak_rss_including_controller,
                inventory_race_attempts=INVENTORY_RACES,
                final_target_positive_bytes=sum(
                    max(0, v[2] - baseline.get(p, (0, 0, 0))[2])
                    for p, v in inventory(TARGET).items()
                ),
                control_scope="Canonical CycleResources/execute/pidfd cleanup; external canonical research-job bounds controller and notification",
                concurrent_319=admission["concurrent_319"],
            )
            records = [json.loads(p.read_text()) for p in OUT.glob("command-*.process.json")]
            result["all_direct_children_reaped"] = all(r["direct_child_reaped"] for r in records)
            result["remaining"] = [m for r in records for m in r["remaining"]]
            result["cleanup_complete"] = all(r["cleanup_complete"] for r in records)
            (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    if failure:
        raise failure


if __name__ == "__main__":
    main()
