"""Refresh named owncrate Cargo freshness, compile only new D-only caller fixture, run sealed harness."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

OUT = Path(__file__).resolve().parent
OLD = OUT.parent / "software-v1"
SPEC = importlib.util.spec_from_file_location("qualified_control", OLD / "worker.py")
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
P = M.P


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(M.WT)
    a = json.loads((OUT / "admission.json").read_text())
    for path, digest in a["bindings"].items():
        assert sha(path) == digest, path
    packet = json.loads(Path(a["source_packet"]).read_text())
    for row in packet["sources"]:
        assert sha(M.WT / row["relative_path"]) == row["SHA256"]
    old_runtime = (M.WT / "crates/quoridor-runner/src/runtime.rs").read_bytes()[
        : a["old_runtime_length"]
    ]
    assert hashlib.sha256(old_runtime).hexdigest() == a["old_runtime_SHA256"]
    assert P.available_memory() > 6 * 1024**3
    M.quiet()
    M.OUT = OUT
    resources = M.Resources()
    known_paths = set()
    for folder in (OLD, OUT.parent / "software-recovery-v1"):
        for log in folder.glob("*.log"):
            for line in log.read_text().splitlines():
                if line.startswith("{"):
                    row = json.loads(line)
                    if row.get("reason") == "compiler-artifact" and not row.get(
                        "fresh"
                    ):
                        for path in row.get("filenames", []):
                            known_paths.add(path)
                            info = Path(path).stat()
                            resources.artifacts[(info.st_dev, info.st_ino)] = (
                                info.st_blocks * 512
                            )
    assert (
        sum(resources.artifacts.values()) + a["harness_linker_TMP_forecast_B"]
        <= 40 * 1024**2
    )
    (OUT / "tmp").mkdir(exist_ok=True)
    os.environ.update(
        CARGO_TARGET_DIR=str(M.TARGET),
        CARGO_INCREMENTAL="0",
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        TMPDIR=str(OUT / "tmp"),
        CUDA_VISIBLE_DEVICES="",
        RUST_TEST_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
    )
    start = time.monotonic()
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "NN": 0,
        "games": 0,
        "hard_realtime_guarantee": False,
        "qualified": False,
    }
    failure = None
    fd = None
    with (M.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        M.quiet()
        try:
            with P.cancellation_signals():
                refresh = []
                for rel in (
                    "crates/quoridor-nnue/src/lib.rs",
                    "crates/quoridor-ai/src/lib.rs",
                    "crates/quoridor-runner/src/lib.rs",
                ):
                    path = M.WT / rel
                    before = path.stat()
                    digest = sha(path)
                    os.utime(path, None)
                    assert sha(path) == digest
                    refresh.append(
                        {
                            "path": rel,
                            "SHA256": digest,
                            "before_mtime_ns": before.st_mtime_ns,
                            "after_mtime_ns": path.stat().st_mtime_ns,
                        }
                    )
                result["named_source_byte_preserving_cache_refresh"] = refresh
                command = [
                    "/usr/local/cargo/bin/cargo",
                    "test",
                    "--offline",
                    "--locked",
                    "-j",
                    "2",
                    "--release",
                    "-p",
                    "quoridor-runner",
                    "--lib",
                    "--no-run",
                    "--message-format=json",
                ]
                record = P.execute(
                    command, OUT / "build.log", None, resources=resources
                )
                result["commands"].append(record)
                rows = [
                    json.loads(line)
                    for line in (OUT / "build.log").read_text().splitlines()
                    if line.startswith("{")
                ]
                for row in rows:
                    if row.get("reason") == "compiler-artifact":
                        known_paths.update(row.get("filenames", []))
                resources.artifacts = {}
                for path in known_paths:
                    info = Path(path).stat()
                    resources.artifacts[(info.st_dev, info.st_ino)] = (
                        info.st_blocks * 512
                    )
                resources.check()
                result["known_completed_artifacts_B"] = sum(
                    resources.artifacts.values()
                )
                result["target_transient_peak_B"] = None
                images = [
                    r["executable"]
                    for r in rows
                    if r.get("reason") == "compiler-artifact"
                    and r.get("executable")
                    and r.get("profile", {}).get("test")
                ]
                assert len(images) == 1
                raw = Path(images[0]).read_bytes()
                assert len(raw) <= a["memory_private_harness_upper_B"]
                result["harness"] = {
                    "compiled_path": images[0],
                    "ELF_SHA256": hashlib.sha256(raw).hexdigest(),
                    "logical_B": len(raw),
                    "source_packet_SHA256": sha(a["source_packet"]),
                }
                # No permanent parallel caller. Sealed immutable ELF lives only for this fixture.
                fd = os.memfd_create(
                    "327-current-clock-fixture", os.MFD_CLOEXEC | os.MFD_ALLOW_SEALING
                )
                offset = 0
                while offset < len(raw):
                    offset += os.write(fd, raw[offset:])
                os.fchmod(fd, 0o700)
                fcntl.fcntl(
                    fd,
                    fcntl.F_ADD_SEALS,
                    fcntl.F_SEAL_WRITE
                    | fcntl.F_SEAL_GROW
                    | fcntl.F_SEAL_SHRINK
                    | fcntl.F_SEAL_SEAL,
                )
                assert (
                    hashlib.sha256(
                        Path(f"/proc/{os.getpid()}/fd/{fd}").read_bytes()
                    ).hexdigest()
                    == result["harness"]["ELF_SHA256"]
                )
                M.quiet()  # Compiler directwait has completed; live caller timing starts after quiet.
                record = P.execute(
                    [
                        f"/proc/{os.getpid()}/fd/{fd}",
                        "runtime::live_caller_clock_tests::distance_live_deadline_completed_cap_cancel_and_tt_nn0",
                        "--exact",
                        "--nocapture",
                    ],
                    OUT / "clock.log",
                    None,
                    resources=resources,
                )
                result["commands"].append(record)
                text = (OUT / "clock.log").read_text()
                assert "1 passed; 0 failed" in text
                line = next(
                    x for x in text.splitlines() if x.startswith("CALLER_CLOCK_NN0=")
                )
                clock = json.loads(line.split("=", 1)[1])
                result["live_observation"] = clock
                first = clock["rows"][0]
                result["qualified"] = first["acceptance"] == "Ok(())"
                assert result["qualified"], (
                    "observed live return late; retain typed unknown and report, no harddeadline rescue"
                )
        except BaseException as error:
            failure = repr(error)
        finally:
            if fd is not None:
                os.close(fd)
            records = [json.loads(p.read_text()) for p in OUT.glob("*.process.json")]
            result.update(
                ended=datetime.now(timezone.utc).isoformat(),
                whole_seconds=time.monotonic() - start,
                error=failure,
                all_direct_children_reaped=all(
                    r.get("direct_child_reaped") for r in records
                ),
                cleanup_complete=all(r.get("cleanup_complete") for r in records),
                remaining=[m for r in records for m in r.get("remaining", [])],
                memfd_closed=True,
                model_calls=0,
                RAMfamily_sampled_including_controller_B=resources.rss_peak,
                native_model_qualification_repeated=False,
                actual_D_matches=0,
                target_transient_peak_B=None,
                source_packet_SHA256=sha(a["source_packet"]),
            )
            (OUT / "result.json").write_text(
                json.dumps(result, indent=2, allow_nan=False) + "\n"
            )
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
