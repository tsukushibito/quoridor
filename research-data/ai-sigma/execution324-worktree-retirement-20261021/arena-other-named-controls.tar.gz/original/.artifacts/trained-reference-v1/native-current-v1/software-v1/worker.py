"""Current native software qualification; finite scoped commands, canonical ownership."""

import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import time
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
WT = OUT.parents[3]
TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")
SPEC = importlib.util.spec_from_file_location(
    "canonical_cycle", "/workspaces/quoridor/python/quoridor_training/cycle_process.py"
)
P = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(P)
P.LOG_MAX_BYTES = 65536


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")


def allocated(root):
    total = 0
    pending = [root]
    while pending:
        folder = pending.pop()
        try:
            with os.scandir(folder) as entries:
                for entry in entries:
                    try:
                        info = entry.stat(follow_symlinks=False)
                    except FileNotFoundError:
                        continue
                    if stat.S_ISDIR(info.st_mode):
                        pending.append(Path(entry.path))
                    else:
                        total += info.st_blocks * 512
        except FileNotFoundError:
            continue
    return total


def quiet():
    foreign = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            args = (entry / "cmdline").read_bytes().split(b"\0")
            name = Path(os.fsdecode(args[0])).name if args[0] else ""
            if name in (
                "cargo",
                "rustc",
                "clippy-driver",
                "rust-lld",
                "ld.lld",
                "nnue-diagnose",
                "quoridor-runner",
                "nnue_search",
            ):
                foreign.append({"pid": int(entry.name), "name": name})
            elif name.startswith("python") and any(
                b in b" ".join(args)
                for b in (
                    b"train.py",
                    b"sigma_reference.py",
                    b"numeric-worker",
                    b"measure-native",
                    b"reference330",
                )
            ):
                foreign.append({"pid": int(entry.name), "name": name})
        except FileNotFoundError:
            continue
    if foreign:
        raise RuntimeError(
            "foreign compiler/numeric clock present; preserve it: " + repr(foreign)
        )


class Resources(P.CycleResources):
    def __init__(self):
        super().__init__(
            {
                "max_memory_bytes": 2 * 1024**3 - 64 * 1024**2,
                "max_output_bytes": 56 * 1024**2,
            },
            OUT,
            None,
        )
        self.rss_peak = self.output_peak = self.tmp_peak = 0
        self.artifacts = {}

    def check(self, owned=()):
        super().check(owned)
        info = [P.process_info(os.getpid()), *(P.process_info(m["pid"]) for m in owned)]
        rss = sum(x["rss"] for x in info if x) + 64 * 1024**2
        self.rss_peak = max(self.rss_peak, rss)
        if rss > 2 * 1024**3:
            raise P.CycleStopped("RAMfamily2GiB including controller reserve")
        tmp = allocated(OUT / "tmp")
        self.tmp_peak = max(self.tmp_peak, tmp)
        if tmp + sum(self.artifacts.values()) > 40 * 1024**2:
            raise P.CycleStopped(
                "named completed artifacts + own TMP exceed 40MiB prospective build bound"
            )
        own = allocated(OUT)
        self.output_peak = max(self.output_peak, own)
        if own - tmp > 2 * 1024**2 + 8 * 1024**2 + 2 * 1024**2:
            raise P.CycleStopped("private ELF + runtime/control bound")


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(WT)
    a = json.loads((OUT / "admission-v2.json").read_text())
    assert sha(a["authority_path"]) == a["authority_SHA256"]
    assert sha(a["source_stop"]) == a["source_stop_SHA256"]
    packet = json.loads(Path(a["source_stop"]).read_text())

    def source_check():
        for row in packet["sources"]:
            assert sha(WT / row["relative_path"]) == row["SHA256"], row["relative_path"]
        extra = packet["related_extra_file"]
        assert sha(WT / extra["path"]) == extra["SHA256"]

    source_check()
    assert sha(a["cycle_path"]) == a["cycle_SHA256"]
    assert sha(__file__) == a["worker_SHA256"]
    assert a["review_blockers"] == 0 and a["review_reader_STOP"]
    assert sha(a["review_control"]) == a["review_control_SHA256"]
    assert P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 56 * 1024**2
    quiet()
    (OUT / "tmp").mkdir(exist_ok=True)
    (OUT / "private").mkdir(exist_ok=True)
    os.environ.update(
        CARGO_TARGET_DIR=str(TARGET),
        CARGO_BUILD_JOBS="2",
        CARGO_INCREMENTAL="0",
        CARGO_NET_OFFLINE="true",
        TMPDIR=str(OUT / "tmp"),
        CUDA_VISIBLE_DEVICES="",
        RUST_TEST_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
    )
    os.environ.pop("QUORIDOR_BENCH_MANIFEST", None)
    os.environ.pop("QUORIDOR_BENCH_FT_MODE", None)
    resources = Resources()
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "private": {},
        "NN_synthetic_planned": 2,
        "trained_model_calls": 0,
        "actual_games": 0,
    }
    start = time.monotonic()
    failure = None

    def command(name, args, json_artifacts=False):
        log = OUT / (name + ".log")
        record = P.execute(args, log, None, resources=resources)
        result["commands"].append({"name": name, **record})
        if not json_artifacts:
            return []
        rows = [
            json.loads(line)
            for line in log.read_text().splitlines()
            if line.startswith("{")
        ]
        for row in rows:
            if row.get("reason") == "compiler-artifact" and not row.get("fresh"):
                for path in row.get("filenames", []):
                    p = Path(path)
                    info = p.stat()
                    resources.artifacts[(info.st_dev, info.st_ino)] = (
                        info.st_blocks * 512
                    )
        resources.check()
        return rows

    def test_harness(name, selectors, cases):
        rows = command(
            name + "-no-run",
            [
                cargo,
                "test",
                *base,
                "--release",
                *selectors,
                "--no-run",
                "--message-format=json",
            ],
            True,
        )
        images = [
            r["executable"]
            for r in rows
            if r.get("reason") == "compiler-artifact"
            and r.get("executable")
            and r.get("profile", {}).get("test")
        ]
        assert len(images) == 1
        exe = images[0]
        result.setdefault("test_harnesses", {})[name] = {
            "path": exe,
            "SHA256": sha(exe),
        }
        for case in cases:
            case_name = name + "-" + case.split("::")[-1]
            command(case_name, [exe, case, "--exact", "--nocapture"])
            assert "1 passed; 0 failed" in (OUT / (case_name + ".log")).read_text(), (
                case
            )

    cargo = "/usr/local/cargo/bin/cargo"
    base = ["--offline", "--locked", "-j", "2"]
    with (TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet()
        try:
            with P.cancellation_signals():
                command("compiler", ["/usr/local/cargo/bin/rustc", "-Vv"])
                rows = command(
                    "release",
                    [
                        cargo,
                        "build",
                        *base,
                        "--release",
                        "-p",
                        "quoridor-runner",
                        "--bin",
                        "quoridor-runner",
                        "--bin",
                        "nnue-diagnose",
                        "--message-format=json",
                    ],
                    True,
                )
                for name, cap in (
                    ("nnue-diagnose", 2 * 1024**2),
                    ("quoridor-runner", 8 * 1024**2),
                ):
                    matching = [
                        r["executable"]
                        for r in rows
                        if r.get("reason") == "compiler-artifact"
                        and r.get("executable")
                        and r["target"]["name"] == name
                    ]
                    assert len(matching) == 1
                    src = Path(matching[0])
                    assert src.stat().st_blocks * 512 <= cap
                    dest = OUT / "private" / name
                    shutil.copy2(src, dest)
                    assert sha(src) == sha(dest) and dest.stat().st_mode & 0o111
                    result["private"][name] = {
                        "path": str(dest),
                        "SHA256": sha(dest),
                        "logical_B": dest.stat().st_size,
                        "mode": dest.stat().st_mode & 0o777,
                    }
                test_harness(
                    "diagnose",
                    ["-p", "quoridor-runner", "--bin", "nnue-diagnose"],
                    [
                        "required_wall_tests::diagnostic_wall_requires_presence_and_accepts_explicit_null_nn0",
                        "native_input::tests::reject_bad_binding",
                        "qualification_tests::qualification_actions_and_inplace_undo_match_immutable_oracle_nn0",
                    ],
                )
                test_harness(
                    "caller",
                    ["-p", "quoridor-runner", "--lib"],
                    [
                        "arena_clock::completion_tests::setup_charges_budget_and_late_completion_is_not_published",
                        "runtime::completed_error_tests::completed_move_does_not_hide_engine_error",
                        "arena_book::tests::partial_book_is_not_relabelled_eight_pairs",
                    ],
                )
                test_harness(
                    "config",
                    ["-p", "quoridor-runner", "--test", "config"],
                    ["optional_job_wall_preserves_other_limits"],
                )
                test_harness(
                    "observed",
                    ["-p", "quoridor-nnue", "--features", "research", "--lib"],
                    [
                        "residual::head_route_observer_test::observed_matches_and_bad_shape_has_no_route"
                    ],
                )
                command(
                    "clippy",
                    [
                        cargo,
                        "clippy",
                        *base,
                        "-p",
                        "quoridor-runner",
                        "--lib",
                        "--bin",
                        "quoridor-runner",
                        "--bin",
                        "nnue-diagnose",
                        "--test",
                        "config",
                        "--",
                        "-D",
                        "warnings",
                    ],
                )
                source_check()
        except BaseException as error:
            failure = repr(error)
        finally:
            records = [json.loads(p.read_text()) for p in OUT.glob("*.process.json")]
            result.update(
                ended=datetime.now(timezone.utc).isoformat(),
                whole_seconds=time.monotonic() - start,
                error=failure,
                all_direct_children_reaped=all(
                    r.get("direct_child_reaped") for r in records
                ),
                cleanup_complete=all(r.get("cleanup_complete") for r in records),
                remaining=[m for r in records for m in r.get("remaining", [])],
                sampled_family_RAM_including_controller_B=resources.rss_peak,
                named_completed_artifact_bytes=sum(resources.artifacts.values()),
                own_TMP_sampled_peak_B=resources.tmp_peak,
                own_output_sampled_peak_B=resources.output_peak,
                shared_target_peak_increment_B=None,
                target_peak_scope="UNKNOWN; accepted40MiB prospective build/cache/linker/TMP bound retained; exact named Cargo completed artifacts only, no sharedtarget inventory",
                private_qualification_complete=False,
                source_stop_SHA256=a["source_stop_SHA256"],
                authority_SHA256=a["authority_SHA256"],
            )
            save("result.json", result)
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
