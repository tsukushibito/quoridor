"""Resume only the repaired synthetic fixture and outstanding scoped release Clippy."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

OUT = Path(__file__).resolve().parent
OLD = OUT.parent / "software-v1"
SPEC = importlib.util.spec_from_file_location(
    "qualified_software_control", OLD / "worker.py"
)
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
P = M.P


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def artifact_paths():
    paths = set()
    for log in OLD.glob("*.log"):
        for line in log.read_text().splitlines():
            if line.startswith("{"):
                row = json.loads(line)
                if row.get("reason") == "compiler-artifact" and not row.get("fresh"):
                    paths.update(row.get("filenames", []))
    return sorted(paths)


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(M.WT)
    a = json.loads((OUT / "admission.json").read_text())
    assert sha(a["authority_path"]) == a["authority_SHA256"]
    assert sha(OLD / "worker.py") == a["original_worker_SHA256"]
    assert sha(OLD / "result.json") == a["original_result_SHA256"]
    assert sha(a["source_stop"]) == a["source_stop_SHA256"]
    packet = json.loads(Path(a["source_stop"]).read_text())
    for row in packet["sources"]:
        assert sha(M.WT / row["relative_path"]) == row["SHA256"]
    for item in a["original_private"].values():
        assert sha(item["path"]) == item["SHA256"]
    assert P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 56 * 1024**2
    M.quiet()
    with (M.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        M.quiet()
        M.OUT = OUT
        resources = M.Resources()
        named = {}
        for name in artifact_paths():
            info = Path(
                name
            ).stat()  # A missing named cache is UNKNOWN, never free credit.
            named[(info.st_dev, info.st_ino)] = info.st_blocks * 512
        resources.artifacts = named
        baseline = sum(named.values())
        assert baseline + a["new_harness_metadata_TMP_upper_B"] <= 40 * 1024**2
        (OUT / "tmp").mkdir(exist_ok=True)
        os.environ.update(
            CARGO_TARGET_DIR=str(M.TARGET),
            CARGO_INCREMENTAL="0",
            CARGO_BUILD_JOBS="2",
            CARGO_NET_OFFLINE="true",
            TMPDIR=str(OUT / "tmp"),
            CUDA_VISIBLE_DEVICES="",
            RUST_TEST_THREADS="1",
            PYTHONDONTWRITEBYTECODE="1",
        )
        start = time.monotonic()
        result = {
            "started": datetime.now(timezone.utc).isoformat(),
            "commands": [],
            "trained_calls": 0,
            "games": 0,
            "synthetic_head_planned": 2,
            "synthetic_FT_planned": 1,
            "named_baseline_B": baseline,
            "original_failure_whole_seconds": a["original_failure_whole_seconds"],
        }
        failure = None

        def command(name, args):
            log = OUT / (name + ".log")
            record = P.execute(args, log, None, resources=resources)
            result["commands"].append({"name": name, **record})
            rows = [
                json.loads(line)
                for line in log.read_text().splitlines()
                if line.startswith("{")
            ]
            for row in rows:
                if row.get("reason") == "compiler-artifact" and not row.get("fresh"):
                    for path in row.get("filenames", []):
                        info = Path(path).stat()
                        resources.artifacts[(info.st_dev, info.st_ino)] = (
                            info.st_blocks * 512
                        )
            resources.check()
            if M.allocated(OLD) + M.allocated(OUT) > 12 * 1024**2:
                raise RuntimeError("combined private/source/runtime inclusive bound")
            return rows

        cargo = "/usr/local/cargo/bin/cargo"
        base = ["--offline", "--locked", "-j", "2", "--release"]
        try:
            with P.cancellation_signals():
                rows = command(
                    "observed-no-run",
                    [
                        cargo,
                        "test",
                        *base,
                        "-p",
                        "quoridor-nnue",
                        "--features",
                        "research",
                        "--lib",
                        "--no-run",
                        "--message-format=json",
                    ],
                )
                images = [
                    r["executable"]
                    for r in rows
                    if r.get("reason") == "compiler-artifact"
                    and r.get("executable")
                    and r.get("profile", {}).get("test")
                ]
                assert len(images) == 1
                exe = images[0]
                result["synthetic_harness"] = {"path": exe, "SHA256": sha(exe)}
                command(
                    "observed-fixture",
                    [
                        exe,
                        "residual::head_route_observer_test::observed_matches_and_bad_shape_has_no_route",
                        "--exact",
                        "--nocapture",
                    ],
                )
                log = (OUT / "observed-fixture.log").read_text()
                assert "1 passed; 0 failed" in log
                assert "OBSERVED_ROUTE_SYNTHETIC_HEAD_ATTEMPTS=2;FT_SETUPS=1" in log
                result["synthetic_head_completed"] = 2
                result["synthetic_FT_completed"] = 1
                command(
                    "clippy",
                    [
                        cargo,
                        "clippy",
                        *base,
                        "-p",
                        "quoridor-runner",
                        "--lib",
                        "--bin",
                        "quoridor-runner",
                        "--bin",
                        "nnue-diagnose",
                        "--test",
                        "config",
                        "--message-format=json",
                        "--",
                        "-D",
                        "warnings",
                    ],
                )
        except BaseException as error:
            failure = repr(error)
        finally:
            records = [json.loads(p.read_text()) for p in OUT.glob("*.process.json")]
            result.update(
                ended=datetime.now(timezone.utc).isoformat(),
                whole_seconds=time.monotonic() - start,
                error=failure,
                remaining=[m for r in records for m in r.get("remaining", [])],
                cleanup_complete=all(r.get("cleanup_complete") for r in records),
                all_direct_children_reaped=all(
                    r.get("direct_child_reaped") for r in records
                ),
                named_completed_peak_B=sum(resources.artifacts.values()),
                RAMfamily_sampled_including_controller_B=resources.rss_peak,
                own_TMP_sampled_peak_B=resources.tmp_peak,
                target_transient_peak_B=None,
                target_peak_scope="UNKNOWN; all old upper reservations retained; exact named current paths and prospective additional5MiB bound only",
                compiled_private_original_version="8a755e6b",
                private_not_rebuilt=True,
                production_test_repair_only=True,
                source_stop_SHA256=a["source_stop_SHA256"],
                native_qualification=False,
            )
            (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
        if failure:
            raise RuntimeError(failure)


if __name__ == "__main__":
    main()
