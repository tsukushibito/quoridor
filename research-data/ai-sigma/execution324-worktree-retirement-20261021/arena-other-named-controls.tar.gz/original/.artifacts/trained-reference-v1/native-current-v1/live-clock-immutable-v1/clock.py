"""Run only the unexecuted D caller fixture from the verified immutable harness."""

from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

OUT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    "qualified_control", OUT.parent / "software-v1/worker.py"
)
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
P = M.P


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(M.WT)
    a = json.loads((OUT / "admission.json").read_text())
    for path, digest in a["bindings"].items():
        assert sha(path) == digest, path
    packet = json.loads(Path(a["source_packet"]).read_text())
    for row in packet["sources"]:
        assert sha(M.WT / row["relative_path"]) == row["SHA256"]
    assert P.available_memory() > 6 * 1024**3
    M.quiet()
    binding = json.loads((OUT / "payload-binding.json").read_text())
    raw = gzip.decompress(Path(binding["gzip_path"]).read_bytes())
    assert hashlib.sha256(raw).hexdigest() == binding["new_harness_payload_SHA256"]
    assert len(raw) == binding["logical_B"] <= 8 * 1024**2
    os.environ.update(
        CUDA_VISIBLE_DEVICES="", RUST_TEST_THREADS="1", PYTHONDONTWRITEBYTECODE="1"
    )
    M.OUT = OUT
    resources = M.Resources()
    start = time.monotonic()
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "source_packet_SHA256": sha(a["source_packet"]),
        "payload_binding_SHA256": sha(OUT / "payload-binding.json"),
        "ELF_SHA256": binding["new_harness_payload_SHA256"],
        "commands": [],
        "compiled_again": False,
        "shared_target_readers_writers": 0,
        "NN_FT_model_games": 0,
        "hard_realtime_guarantee": False,
        "qualified": False,
    }
    fd = None
    failure = None
    try:
        with P.cancellation_signals():
            fd = os.memfd_create(
                "327-immutable-clock-fixture", os.MFD_CLOEXEC | os.MFD_ALLOW_SEALING
            )
            offset = 0
            while offset < len(raw):
                offset += os.write(fd, raw[offset:])
            os.fchmod(fd, 0o700)
            fcntl.fcntl(
                fd,
                fcntl.F_ADD_SEALS,
                fcntl.F_SEAL_WRITE
                | fcntl.F_SEAL_GROW
                | fcntl.F_SEAL_SHRINK
                | fcntl.F_SEAL_SEAL,
            )
            assert sha(f"/proc/{os.getpid()}/fd/{fd}") == result["ELF_SHA256"]
            M.quiet()
            record = P.execute(
                [
                    f"/proc/{os.getpid()}/fd/{fd}",
                    "runtime::live_caller_clock_tests::distance_live_deadline_completed_cap_cancel_and_tt_nn0",
                    "--exact",
                    "--nocapture",
                ],
                OUT / "clock.log",
                None,
                resources=resources,
            )
            result["commands"].append(record)
            text = (OUT / "clock.log").read_text()
            assert "1 passed; 0 failed" in text
            line = next(
                x for x in text.splitlines() if x.startswith("CALLER_CLOCK_NN0=")
            )
            result["live_observation"] = json.loads(line.split("=", 1)[1])
            result["qualified"] = (
                result["live_observation"]["rows"][0]["acceptance"] == "Ok(())"
            )
            assert result["qualified"], (
                "typed late unknown retained; no deadline rescue"
            )
    except BaseException as error:
        failure = repr(error)
    finally:
        if fd is not None:
            os.close(fd)
        records = [json.loads(p.read_text()) for p in OUT.glob("*.process.json")]
        result.update(
            ended=datetime.now(timezone.utc).isoformat(),
            whole_seconds=time.monotonic() - start,
            error=failure,
            direct_children_reaped=all(r.get("direct_child_reaped") for r in records),
            cleanup_complete=all(r.get("cleanup_complete") for r in records),
            remaining=[m for r in records for m in r.get("remaining", [])],
            memfd_closed=True,
            RAMfamily_sampled_including_controller_B=resources.rss_peak,
            target_transient_peak_B=None,
            prior_failed_attempts_retained=True,
        )
        (OUT / "result.json").write_text(
            json.dumps(result, indent=2, allow_nan=False) + "\n"
        )
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
