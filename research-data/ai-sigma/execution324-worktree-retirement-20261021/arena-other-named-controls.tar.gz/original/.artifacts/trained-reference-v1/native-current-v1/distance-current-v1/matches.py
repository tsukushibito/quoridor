"""Run the fixed eight-family current BEST51 vs D census, without compile or retries."""

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

OUT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    "qualified_control", OUT.parent / "software-v1/worker.py"
)
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
P = M.P


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class Resources(P.CycleResources):
    def __init__(self):
        super().__init__(
            {
                "max_memory_bytes": 2 * 1024**3 - 64 * 1024**2,
                "max_output_bytes": 64 * 1024**2,
            },
            OUT,
            None,
        )
        self.rss_peak = self.output_peak = 0

    def check(self, owned=()):
        super().check(owned)
        info = [P.process_info(os.getpid()), *(P.process_info(m["pid"]) for m in owned)]
        rss = sum(x["rss"] for x in info if x) + 64 * 1024**2
        self.rss_peak = max(self.rss_peak, rss)
        if rss > 2 * 1024**3:
            raise P.CycleStopped("RAMfamily2GiB includes64MiBcontroller reserve")
        self.output_peak = max(self.output_peak, M.allocated(OUT))
        if self.output_peak > 64 * 1024**2:
            raise P.CycleStopped("Dphase inclusive64MiB allocated output")


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(M.WT)
    a = json.loads((OUT / "admission.json").read_text())
    for path, digest in a["bindings"].items():
        assert sha(path) == digest, path
    assert os.access(a["private_runner"], os.X_OK)
    assert P.available_memory() > 6 * 1024**3
    M.quiet()
    os.environ.update(
        CUDA_VISIBLE_DEVICES="",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        RUST_TEST_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
    )
    resources = Resources()
    start = time.monotonic()
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "planned_slots": 16,
        "planned_pairs": 8,
        "science_runs_started": [],
        "new_compile": 0,
        "extra_qualification_forwards": 0,
        "whole_job_horizon": None,
        "physical_head_FT_kernel_counts": "UNKNOWN",
        "qualified_complete_evidence": False,
    }
    failure = None
    try:
        with P.cancellation_signals():
            for cohort in ("initial", "main"):
                M.quiet()
                config = json.loads((OUT / f"config-{cohort}.json").read_text())
                target = Path(config["output"])
                assert not target.exists(), (
                    "no overwrite/resume/repeat candidate outcomes"
                )
                result["science_runs_started"].append(cohort)
                record = P.execute(
                    [
                        a["private_runner"],
                        "arena",
                        "--config",
                        str(OUT / f"config-{cohort}.json"),
                    ],
                    OUT / f"arena-{cohort}.log",
                    None,
                    resources=resources,
                )
                result["commands"].append({"scope": f"arena-{cohort}", **record})
                manifest = json.loads((target / "manifest.json").read_text())
                assert (
                    manifest["binding"]["executable_sha256"]
                    == a["private_runner_SHA256"]
                )
                assert (
                    manifest["binding"]["compiled_sources"]
                    == a["expected_compiled_sources"]
                )
                for action in ("audit", "recover"):
                    record = P.execute(
                        [a["private_runner"], "arena", f"--{action}", str(target)],
                        OUT / f"{action}-{cohort}.log",
                        None,
                        resources=resources,
                    )
                    result["commands"].append(
                        {"scope": f"{action}-{cohort}-NN0", **record}
                    )
            result["qualified_complete_evidence"] = True
    except BaseException as error:
        failure = repr(error)
    finally:
        records = [json.loads(p.read_text()) for p in OUT.glob("*.process.json")]
        result.update(
            ended=datetime.now(timezone.utc).isoformat(),
            whole_seconds=time.monotonic() - start,
            error=failure,
            all_direct_children_reaped=all(
                r.get("direct_child_reaped") for r in records
            ),
            cleanup_complete=all(r.get("cleanup_complete") for r in records),
            remaining=[m for r in records for m in r.get("remaining", [])],
            RAMfamily_sampled_including_controller_B=resources.rss_peak,
            owned_output_sampled_peak_B=resources.output_peak,
            shared_target_readers_writers=0,
            no_extra_candidate_slots=True,
            freeze_protocol_SHA256=sha(OUT / "freeze-protocol.json"),
        )
        (OUT / "result.json").write_text(
            json.dumps(result, indent=2, allow_nan=False) + "\n"
        )
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
