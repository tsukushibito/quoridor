"""Fixed independent16 native correspondence, two legal roots, one frozen NN0 book."""

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

OUT = Path(__file__).resolve().parent
OLD = OUT.parent / "software-v1"
SPEC = importlib.util.spec_from_file_location("qualified_control", OLD / "worker.py")
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
P = M.P


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(M.WT)
    a = json.loads((OUT / "admission.json").read_text())
    for path, digest in a["bindings"].items():
        assert sha(path) == digest, path
    actual = json.loads(Path(a["current_source_packet"]).read_text())
    compiled = json.loads(Path(a["compiled_source_packet"]).read_text())
    for row in actual["sources"]:
        assert sha(M.WT / row["relative_path"]) == row["SHA256"]
    # Exact historical production/version proof: only one cfg(test) API spelling differs.
    residual = (M.WT / "crates/quoridor-nnue/src/residual.rs").read_bytes()
    old_residual = residual.replace(
        b"let a = m.full(quoridor_core::Position::default()).unwrap();",
        b"let a = m.full(quoridor_core::Position::initial()).unwrap();",
        1,
    )
    compiled_by = {r["relative_path"]: r["SHA256"] for r in compiled["sources"]}
    assert (
        hashlib.sha256(old_residual).hexdigest()
        == compiled_by["crates/quoridor-nnue/src/residual.rs"]
    )
    for row in actual["sources"]:
        if row["relative_path"] != "crates/quoridor-nnue/src/residual.rs":
            assert row["SHA256"] == compiled_by[row["relative_path"]]
    M.quiet()
    assert P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 56 * 1024**2
    M.OUT = OUT
    resources = M.Resources()
    expected = json.loads((OUT / "expected-compiled-bindings.json").read_text())
    start = time.monotonic()
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "physical_kernel_counts": "UNKNOWN",
        "scope": "current compiled8a755/privatecce724; fixed BEST51; no Torch/fit/export/game",
        "qualified": False,
    }
    failure = None

    def command(name, config):
        record = P.execute(
            [a["private_diagnose"], "--config", str(OUT / config)],
            OUT / (name + ".log"),
            None,
            resources=resources,
        )
        result["commands"].append({"name": name, **record})

    try:
        with P.cancellation_signals():
            command("correspondence", "correspondence-config.json")
            c = json.loads((OUT / "correspondence.json").read_text())
            assert c["compiled_sources"] == expected
            assert c["executable_sha256"] == a["private_diagnose_SHA256"]
            assert (
                c["manifest_sha256"] == a["manifest_SHA256"]
                and c["weights_sha256"] == a["weights_SHA256"]
            )
            assert c["input_sha256"] == a["reference_SHA256"]
            assert c["status"] == "COMPATIBILITY_PASS_INPUT_ONLY"
            assert c["NN"] == 32 and c["processed"] == 32 and c["failed"] == 0
            assert len(c["predictions"]) == 32
            assert all(
                p["within_alert"] and p["guard_route"] is not None
                for p in c["predictions"]
            )
            command("legal", "legal-config-v2.json")
            q = json.loads((OUT / "legal-qualification.json").read_text())
            assert q["compiled_sources"] == expected
            assert q["status"] == "PASS" and q["NN"] == 64 and q["undo_checks"] == 10
            assert q["parent_history_ply_exact_restore"] is True
            root_actions = {
                i: [
                    r["child_action"]
                    for r in q["predictions"]
                    if r["root"] == i and "child_action" in r
                ]
                for i in (0, 1)
            }
            assert root_actions == {0: [3, 5, 13, 81, 145], 1: [67, 75, 77, 81, 145]}
            result.update(
                native_head_API_completed=96,
                native_FT_API_completed=96,
                previously_completed_synthetic_head=2,
                previously_completed_synthetic_FT=1,
                legal_selected_actions=root_actions,
                actual_AVX2=q["avx2_available"],
                observed_routes=[p["guard_route"] for p in c["predictions"]],
                input_legal_qualified=True,
            )
            # The fixed NN0 generator is independent of candidate predictions/outcomes.
            command("book", "book-config.json")
            book = json.loads((OUT / "book-preparation.json").read_text())
            assert book["compiled_sources"] == expected
            result["book_preparation_SHA256"] = sha(OUT / "book-preparation.json")
            result["qualified"] = True
    except BaseException as error:
        failure = repr(error)
    finally:
        records = [json.loads(p.read_text()) for p in OUT.glob("*.process.json")]
        result.update(
            ended=datetime.now(timezone.utc).isoformat(),
            whole_seconds=time.monotonic() - start,
            error=failure,
            all_direct_children_reaped=all(
                r.get("direct_child_reaped") for r in records
            ),
            cleanup_complete=all(r.get("cleanup_complete") for r in records),
            remaining=[m for r in records for m in r.get("remaining", [])],
            RAMfamily_sampled_including_controller_B=resources.rss_peak,
            own_output_sampled_peak_B=resources.output_peak,
            actual_games=0,
            clock_or_strength_qualified=False,
            input_qualification_scope="16 correlated open-originalV targetblind rows, two legal prefixes only; no wholemodel accuracy bound",
            authority_SHA256=a["authority_SHA256"],
            admission_SHA256=sha(OUT / "admission.json"),
        )
        (OUT / "result.json").write_text(
            json.dumps(result, indent=2, allow_nan=False) + "\n"
        )
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
