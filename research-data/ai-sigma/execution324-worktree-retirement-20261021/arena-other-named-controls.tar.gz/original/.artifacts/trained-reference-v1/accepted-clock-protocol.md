# Accepted327 protocol

This supersedes method-pending parts of the preserved prebound-plan.md/future-native-request.json. Source is prepared; tests/build/import/forward/native/book generation/matches are NOT_RUN.327 remains open. Main/Git belongs to324; peer frozen jobs/source stay unchanged.

Human chose deadline/last-completed LEGALreturn before practical matches, fixedD(a0,b8) versus BEST51, eight frozen families/one colour pair each=16slots,100ms. No500ms/sweeps/repeats/book rescue/defaultmodel change. Current baseline and final325/326 adoption use the same clock interface/frozen book with separate actual source/ELF/backend bindings; prior time results are version-local.

SearchSession forwards completed callbacks through the same persistentTT/search_in_table. Caller starts before limits/namespace/session initialization. Remaining budget subtracts elapsed setup and provisional5ms reserve. Complete depth snapshots require finite value/PV and full-history legal replay before the caller deadline. Final error/cancel/terminal/no completion remains distinct; previous completion never hides engine error. Returned legal snapshots still need actual acceptance before100ms immediately before publication. Late remains strict_unknown. No hard-real-time guarantee. Completion timestamp/counters are separate from whole invocation time/counters; engine_error survives a late primary outcome.

Correspondence mode uses input-only JSON and mandatory config input_sha256. Schema native-residual-reference-v1 requires manifest/weights/reference-source SHA and16 ordered unique rows. Row: ordinal,record_sha256,features_sha256,sorted ids[2],distance[2],native_side0,torch_side1,finite expected STM value. Features SHA: two dense312-f32 LE indicator views, then two f32 LE distances, then i64 LE Torch side. Alerts: finite abs1e-5+rel1e-4\*abs(reference), no scalar-head bit demand/tolerance relaxation. Legal-prefix qualifier also checks orderedScalar/Simd FT bits; full/delta/parent/undo rules remain separate. NN counts are caller attempts; physical kernel counts are unavailable. Independent expected16 is NOT_SAVED; per-input head guard route unexposed. Even numerical agreement reports qualification_complete=false. Geometry is never invented history.

NN0 prepare_arena_book reuses the maintained generator. Unexecuted config fixes seed32710001, lengths0/2/4/6/8/10/12/14,32attempts/slot,minD2/maxgap2/pawnfraction.5, all8 exactdepth2 nonterminal checks,250000 preparation nodes. Its60s is a proposal. Conversion refuses missing/duplicate/terminal/history/settings errors. Candidate/rejection denominators and histories remain bound. Initial1/main7 share PRNG/root lineage; Q/balance/independence are unknown. Actual prefixes are NOT_GENERATED. Freeze exact book/history/config/source/model/backend/TT/rules and all16 slots before outcomes.

Matches: depth64/node1e6/TT65536/PVS/MPCoff,100ms/strict_unknown/5ms reserve/maxplies200; bootstrapseed327/resamples2000. Primary complete-family pairs; incomplete/unknown/cohort counts and planned0/1 bounds retained. Fixed correlated book/relativeD is not Sigma/general strength/Elo evidence; repeated95% inspection is not a stopping rule.

Next work needs separate inclusive admission and actual quiet/private bindings. Native56MiB/400s per version, missing16 learnerbatch1 rows/calls and<=120 native attempts, plus16slot480s/new>=50MiB remain estimates, not grants or imposed scientific caps. Caller/book software checks and existing review scope need concrete budgets. Current/final native/caller/clock qualification precedes matches. Parent323pause/seals/old fees/caps/assets/UNKNOWN remain unchanged.

325 exact numeric STOP11:35:09.940211Z and cleanup/Clippy STOP11:42:14.013105Z release entry. D16 slots FIRST; retained Sigma is NEXT.327 owns native/caller/games;328 supplies exact minimal refs, whole328 integration is no gate. Pool761856B remains source-only; native authority0.

TT65536 is requested; persistent policy min(requested,4096) slots/1MiB per engine. Actual retained bytes NOT_RUN. Current pool630784B.

Pool368640B.
