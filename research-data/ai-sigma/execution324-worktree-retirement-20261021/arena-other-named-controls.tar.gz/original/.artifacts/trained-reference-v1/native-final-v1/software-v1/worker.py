"""Finite final merge checks, compiler provenance and immutable payload handoff."""

from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import time

OUT = Path(__file__).resolve().parent
FINAL = OUT.parent
WT = FINAL.parents[2]
OLD = WT / ".artifacts/trained-reference-v1/native-current-v1/software-v1/worker.py"
SPEC = importlib.util.spec_from_file_location("accepted_native_control", OLD)
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
P = M.P
CARGO = "/usr/local/cargo/bin/cargo"
BASE = ["--offline", "--locked", "-j", "2"]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def allocated(root):
    total = 0
    pending = [Path(root)]
    while pending:
        folder = pending.pop()
        try:
            with os.scandir(folder) as entries:
                for entry in entries:
                    try:
                        info = entry.stat(follow_symlinks=False)
                    except FileNotFoundError:
                        continue
                    total += info.st_blocks * 512
                    if stat.S_ISDIR(info.st_mode):
                        pending.append(Path(entry.path))
        except FileNotFoundError:
            continue
    return total


class Resources(P.CycleResources):
    def __init__(self):
        super().__init__(
            {
                "max_memory_bytes": 2 * 1024**3 - 64 * 1024**2,
                "max_output_bytes": 56 * 1024**2,
            },
            FINAL,
            None,
        )
        self.named = set()
        self.rss_peak = self.tmp_peak = self.output_peak = self.named_peak = 0

    def named_bytes(self):
        identities = {}
        for path in self.named:
            try:
                info = Path(path).stat()
            except FileNotFoundError as error:
                raise P.CycleStopped("bound produced artifact disappeared") from error
            identities[(info.st_dev, info.st_ino)] = info.st_blocks * 512
        return sum(identities.values())

    def check(self, owned=()):
        super().check(owned)
        infos = [
            P.process_info(os.getpid()),
            *(P.process_info(x["pid"]) for x in owned),
        ]
        ram = sum(x["rss"] for x in infos if x) + 64 * 1024**2
        self.rss_peak = max(self.rss_peak, ram)
        if ram > 2 * 1024**3:
            raise P.CycleStopped("family RAM including controller exceeds2GiB")
        tmp = allocated(OUT / "tmp")
        named = self.named_bytes()
        self.tmp_peak = max(self.tmp_peak, tmp)
        self.named_peak = max(self.named_peak, named)
        if tmp + named > 40 * 1024**2:
            raise P.CycleStopped("own produced artifacts+linkerTMP exceed final40MiB")
        output = allocated(FINAL) - tmp
        self.output_peak = max(self.output_peak, output)
        if output > 16 * 1024**2:
            raise P.CycleStopped(
                "final private/control/retained failure envelope exceeded"
            )


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(WT)
    a = json.loads((OUT / "admission.json").read_text())
    for path, digest in a["bindings"].items():
        assert sha(path) == digest, path
    packet = json.loads(Path(a["source_stop"]).read_text())

    def sources():
        for row in packet["sources"]:
            path = WT / row["relative_path"]
            assert sha(path) == row["SHA256"], str(path)
            assert path.stat().st_mode & 0o777 == row["mode"]
        append = packet["test_only_append"]
        assert (
            hashlib.sha256(
                Path(append["path"]).read_bytes()[: append["previous_length_B"]]
            ).hexdigest()
            == append["previous_SHA256"]
        )

    sources()
    assert P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 56 * 1024**2
    M.quiet()
    for name in ("tmp", "private"):
        (OUT / name).mkdir(exist_ok=True)
    os.environ.update(
        CARGO_TARGET_DIR=str(M.TARGET),
        CARGO_INCREMENTAL="0",
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        TMPDIR=str(OUT / "tmp"),
        CUDA_VISIBLE_DEVICES="",
        RUST_TEST_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
    )
    for name in (
        "QUORIDOR_BENCH_MANIFEST",
        "QUORIDOR_BENCH_FT_MODE",
        "RUSTFLAGS",
        "CARGO_ENCODED_RUSTFLAGS",
    ):
        os.environ.pop(name, None)
    resources = Resources()
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "private": {},
        "new_neural_calls": 0,
        "games": 0,
        "scientific_horizons": None,
        "qualified_native": False,
        "source_stop_SHA256": sha(a["source_stop"]),
    }
    started = time.monotonic()
    failure = None

    def command(name, args, cargo_json=False):
        log = OUT / (name + ".log")
        record = P.execute(args, log, None, resources=resources)
        result["commands"].append({"name": name, **record})
        rows = []
        if cargo_json:
            rows = [
                json.loads(line)
                for line in log.read_text().splitlines()
                if line.startswith("{")
            ]
            artifacts = []
            for row in rows:
                if row.get("reason") != "compiler-artifact":
                    continue
                if not row["fresh"]:
                    resources.named.update(row.get("filenames", []))
                if row.get("target", {}).get("src_path", "").startswith(str(WT) + "/"):
                    artifacts.append(
                        {
                            "package": row["package_id"],
                            "target": row["target"],
                            "fresh": row["fresh"],
                            "profile": row["profile"],
                            "payloads": [
                                {
                                    "path": p,
                                    "SHA256": sha(p),
                                    "logical_B": Path(p).stat().st_size,
                                }
                                for p in row["filenames"]
                            ],
                        }
                    )
            result.setdefault("own_compiler_artifacts", {})[name] = artifacts
        resources.check()
        return rows

    def harness(name, selectors, case):
        rows = command(
            name + "-no-run",
            [
                CARGO,
                "test",
                *BASE,
                "--release",
                *selectors,
                "--no-run",
                "--message-format=json",
            ],
            True,
        )
        images = [
            r["executable"]
            for r in rows
            if r.get("reason") == "compiler-artifact"
            and r.get("executable")
            and r.get("profile", {}).get("test")
        ]
        assert len(images) == 1, images
        exe = images[0]
        result.setdefault("harnesses", {})[name] = {
            "path": exe,
            "SHA256": sha(exe),
            "case": case,
        }
        M.quiet()
        command(name + "-fixture", [exe, case, "--exact", "--nocapture"])
        assert "1 passed; 0 failed" in (OUT / (name + "-fixture.log")).read_text()
        return Path(exe)

    with (M.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        M.quiet()
        try:
            with P.cancellation_signals():
                refresh = []
                for crate in ("core", "nnue", "ai", "data", "runner"):
                    path = WT / f"crates/quoridor-{crate}/src/lib.rs"
                    before = path.stat()
                    digest = sha(path)
                    os.utime(path, None)
                    assert sha(path) == digest
                    refresh.append(
                        {
                            "path": str(path),
                            "SHA256": digest,
                            "before_mtime_ns": before.st_mtime_ns,
                            "after_mtime_ns": path.stat().st_mtime_ns,
                        }
                    )
                result["own_source_byte_preserving_freshness"] = refresh
                command("compiler", ["/usr/local/cargo/bin/rustc", "-Vv"])
                rows = command(
                    "release",
                    [
                        CARGO,
                        "build",
                        *BASE,
                        "--release",
                        "-p",
                        "quoridor-runner",
                        "--bin",
                        "quoridor-runner",
                        "--bin",
                        "nnue-diagnose",
                        "--message-format=json",
                    ],
                    True,
                )
                actual = result["own_compiler_artifacts"]["release"]
                for name in (
                    "quoridor_core",
                    "quoridor_nnue",
                    "quoridor_ai",
                    "quoridor_data",
                ):
                    found = [r for r in actual if r["target"]["name"] == name]
                    assert len(found) == 1 and found[0]["fresh"] is False, name
                for name, cap in (
                    ("nnue-diagnose", 2 * 1024**2),
                    ("quoridor-runner", 8 * 1024**2),
                ):
                    images = [
                        r["executable"]
                        for r in rows
                        if r.get("reason") == "compiler-artifact"
                        and r.get("executable")
                        and r["target"]["name"] == name
                    ]
                    assert len(images) == 1
                    src = Path(images[0])
                    dst = OUT / "private" / name
                    assert src.stat().st_blocks * 512 <= cap
                    shutil.copy2(src, dst)
                    assert sha(src) == sha(dst) and dst.stat().st_mode & 0o111
                    result["private"][name] = {
                        "path": str(dst),
                        "SHA256": sha(dst),
                        "logical_B": dst.stat().st_size,
                        "mode": dst.stat().st_mode & 0o777,
                    }
                harness(
                    "ai",
                    ["-p", "quoridor-ai", "--features", "research", "--lib"],
                    "alphabeta::merged_session_pool_tests::persistent_completed_callback_with_pool_error_cancel_and_nested_search_nn0",
                )
                harness(
                    "diagnose",
                    ["-p", "quoridor-runner", "--bin", "nnue-diagnose"],
                    "borrowed_input_counter_tests::counted_checked_move_hook_forwards_without_evaluation_charge_nn0",
                )
                caller = harness(
                    "caller",
                    ["-p", "quoridor-runner", "--lib"],
                    "runtime::live_caller_clock_tests::distance_live_deadline_completed_cap_cancel_and_tt_nn0",
                )
                data = caller.read_bytes()
                compressed = gzip.compress(data, mtime=0)
                assert gzip.decompress(compressed) == data
                (OUT / "private" / "caller-harness.gz").write_bytes(compressed)
                assert (
                    allocated(OUT / "private")
                    - (OUT / "private" / "nnue-diagnose").stat().st_blocks * 512
                    <= 8 * 1024**2
                )
                result["caller_harness_gzip"] = {
                    "path": str(OUT / "private" / "caller-harness.gz"),
                    "SHA256": sha(OUT / "private" / "caller-harness.gz"),
                    "payload_SHA256": sha(caller),
                    "logical_B": len(compressed),
                    "roundtrip_verified": True,
                }
                command(
                    "clippy-runner",
                    [
                        CARGO,
                        "clippy",
                        *BASE,
                        "-p",
                        "quoridor-runner",
                        "--lib",
                        "--bin",
                        "quoridor-runner",
                        "--bin",
                        "nnue-diagnose",
                        "--message-format=json",
                        "--",
                        "-D",
                        "warnings",
                    ],
                    True,
                )
                command(
                    "clippy-ai",
                    [
                        CARGO,
                        "clippy",
                        *BASE,
                        "-p",
                        "quoridor-ai",
                        "--features",
                        "research",
                        "--lib",
                        "--message-format=json",
                        "--",
                        "-D",
                        "warnings",
                    ],
                    True,
                )
                sources()
                assert len(result["commands"]) == 10
        except BaseException as error:
            failure = repr(error)
        finally:
            records = [json.loads(p.read_text()) for p in OUT.glob("*.process.json")]
            result.update(
                ended=datetime.now(timezone.utc).isoformat(),
                whole_seconds=time.monotonic() - started,
                error=failure,
                all_direct_children_reaped=all(
                    r.get("direct_child_reaped") for r in records
                ),
                cleanup_complete=all(r.get("cleanup_complete") for r in records),
                remaining=[m for r in records for m in r.get("remaining", [])],
                sampled_family_RAM_including_controller_B=resources.rss_peak,
                produced_artifact_current_B=resources.named_bytes(),
                produced_artifact_sampled_peak_B=resources.named_peak,
                own_TMP_sampled_peak_B=resources.tmp_peak,
                own_output_sampled_peak_B=resources.output_peak,
                shared_target_transient_peak_B=None,
                physical_head_FT_kernel_calls=None,
                preserved_current_outcomes_source_private=True,
            )
            save("result.json", result)
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
