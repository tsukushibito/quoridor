"""Collect only saved final D evidence; no evaluator, compiler, or new game calls."""

from collections import Counter
import hashlib
import json
import math
import struct
from pathlib import Path

OUT = Path(__file__).resolve().parent
MASK = (1 << 64) - 1


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bootstrap(scores, seed=327, resamples=2000):
    state = max(seed, 1)
    n = len(scores)
    bound = MASK - MASK % n
    means = []
    for _ in range(resamples):
        value = 0.0
        for _ in range(n):
            while True:
                state ^= (state << 13) & MASK
                state ^= state >> 7
                state ^= (state << 17) & MASK
                if state < bound:
                    break
            value += scores[state % n]
        means.append(value / n)
    means.sort()
    return [
        means[math.floor((resamples - 1) * 0.025)],
        means[math.ceil((resamples - 1) * 0.975)],
    ]


def main():
    admission = json.loads((OUT / "admission.json").read_text())
    for path, digest in admission["bindings"].items():
        assert sha(path) == digest, path
    planned = json.loads((OUT / "planned-slots.json").read_text())
    reports = {}
    metrics = [
        {
            "moves": 0,
            "stops": Counter(),
            "counters": Counter(),
            "caller_ns": [],
            "depth": [],
            "slack_ns": [],
            "TT": [],
            "missing_whole_counter_rows": 0,
        }
        for _ in range(2)
    ]
    pairs = []
    wins = losses = draws = unknown = 0
    unknown_reasons = Counter()
    census_totals = Counter()
    known_score = 0.0
    by_color = Counter()
    histories = []
    bound_artifacts = {}
    observed_slots = set()
    for cohort in ("initial", "main"):
        root = OUT / f"run-{cohort}"
        manifest = json.loads((root / "manifest.json").read_text())
        assert (
            manifest["binding"]["compiled_sources"]
            == admission["expected_compiled_sources"]
        )
        assert (
            manifest["binding"]["executable_sha256"]
            == admission["private_runner_SHA256"]
        )
        assert all(manifest["cleanup"].values())
        for name, row in manifest["artifacts"].items():
            assert sha(root / name) == row["sha256"]
            bound_artifacts[str(root / name)] = row["sha256"]
        result = manifest["result"]
        summary = manifest["summary"]
        assert result["stopped"] is None and result["all_workers_joined"]
        assert json.loads((OUT / f"audit-{cohort}.log").read_text()) == summary
        journal = [
            json.loads(line)
            for line in (root / "completed.jsonl").read_text().splitlines()
        ]
        direct_report = json.loads((root / "result.json").read_text())
        assert journal == direct_report["outcomes"]
        # json!(report) expands f32 to f64 JSON numbers; direct struct/journal uses f32 shortest text.
        # Only this source-typed field may differ, and its restored f32 bits must match exactly.
        for durable, bound in zip(journal, result["outcomes"], strict=True):
            repaired = json.loads(json.dumps(bound))
            for saved, embedded in zip(
                durable["observations"], repaired["observations"], strict=True
            ):
                if saved["value_stm"] is not None:
                    assert struct.pack("<f", saved["value_stm"]) == struct.pack(
                        "<f", embedded["value_stm"]
                    )
                    embedded["value_stm"] = saved["value_stm"]
            assert durable == repaired
        assert (
            len(manifest["binding"]["planned_slots"])
            == summary["census"]["planned_games"]
        )
        pairs.extend(summary["pairs"])
        for key, value in summary["census"].items():
            if isinstance(value, int):
                census_totals[key] += value
        unknown_reasons.update(summary["census"]["unknown_reasons"])
        if len(summary["pairs"]) > 1:
            assert (
                bootstrap([p["score"] for p in summary["pairs"]])
                == summary["bootstrap"]["percentile_95"]
            )
        reports[cohort] = {
            "summary": summary,
            "evaluator_load_seconds": manifest["evaluator_initialization_seconds"],
            "backend_warmup_NN": result["pump"]["backend_warmup_nn"],
            "manifest_SHA256": sha(root / "manifest.json"),
            "report_nn_calls_field": result["nn_calls"],
            "report_nn_calls_scope": "Sigma inference field; zero does not mean native NNUE work was zero",
        }
        slots = manifest["binding"]["planned_slots"]
        for index in range(0, len(slots), 2):
            assert slots[index]["opening"] == slots[index + 1]["opening"]
            assert slots[index]["replay"] == slots[index + 1]["replay"]
            assert (
                slots[index]["candidate_color"] != slots[index + 1]["candidate_color"]
            )
            histories.append(
                {"family": slots[index]["family"], "replay": slots[index]["replay"]}
            )
        for outcome in result["outcomes"]:
            key = (result["run_id"], outcome["game"])
            assert key not in observed_slots
            observed_slots.add(key)
            frozen = next(
                p
                for p in planned
                if p["run_id"] == key[0] and p["local_game"] == key[1]
            )
            assert outcome["candidate_color"] == frozen["candidate_color"]
            assert outcome["moves"][: len(frozen["prefix"])] == frozen["prefix"]
            if outcome["status"] == "unknown":
                unknown += 1
            elif outcome["status"] == "draw":
                assert outcome["failure"] is None and outcome["winner"] is None
                draws += 1
                known_score += 0.5
            else:
                assert outcome["started"] and outcome["failure"] is None
                assert outcome["status"] == "goal", (
                    "strict_unknown cannot become forfeit"
                )
                if outcome["winner"] == outcome["candidate_color"]:
                    wins += 1
                    by_color[outcome["candidate_color"]] += 1
                    known_score += 1.0
                else:
                    losses += 1
            for engine_index, tt in enumerate(outcome["persistent_tt"]):
                assert (
                    tt["requested_tt_entries"] == 65536
                    and tt["effective_tt_slots"] == 4096
                )
                assert (
                    tt["persistent_tt_byte_cap"] == 1048576
                    and tt["retained_bytes_peak"] <= 1048576
                )
                metrics[engine_index]["TT"].append(tt)
            for row in outcome["observations"]:
                m = metrics[row["engine_index"]]
                whole = row.get("counters")
                if isinstance(whole, dict):
                    m["counters"].update(
                        {
                            k: v
                            for k, v in whole.items()
                            if isinstance(v, int)
                            and k not in ("tt_generation", "tt_retained_bytes")
                        }
                    )
                else:
                    m["missing_whole_counter_rows"] += 1
                if not row["accepted"]:
                    assert row["failure"] is not None or row["engine_error"] is not None
                    continue
                assert row["failure"] is None and row["engine_error"] is None
                assert (
                    row["caller_started_ns"]
                    <= row["last_completed_iteration_ns"]
                    <= row["returned_ns"]
                    <= row["admission_checked_ns"]
                    == row["accepted_ns"]
                    < row["deadline_ns"]
                )
                assert (
                    row["completed_iteration_counters"]["nodes"]
                    <= row["counters"]["nodes"]
                )
                m = metrics[row["engine_index"]]
                m["moves"] += 1
                m["stops"][row["stop"]] += 1
                m["depth"].append(row["completed_depth"])
                m["caller_ns"].append(row["accepted_ns"] - row["caller_started_ns"])
                m["slack_ns"].append(row["deadline_ns"] - row["accepted_ns"])
    assert len(observed_slots) == 16 and len(pairs) == census_totals["complete_pairs"]
    assert wins + losses + draws + unknown == 16
    assert unknown == census_totals["unknown_games"]
    engines = []
    for index, m in enumerate(metrics):
        engines.append(
            {
                "engine_index": index,
                "kind": "BEST51_NNUE" if index == 0 else "D_a0_b8",
                "moves": m["moves"],
                "stop_reasons": dict(m["stops"]),
                "whole_invocation_counter_sums": dict(m["counters"]),
                "missing_whole_counter_rows": m["missing_whole_counter_rows"],
                "nonadditive_state_fields_not_summed": [
                    "tt_generation",
                    "tt_retained_bytes",
                ],
                "capacity_byte_counter_meaning": "sum of ephemeral history-key capacities is allocation work, not resident RAM",
                "completed_depth_min_max": [min(m["depth"]), max(m["depth"])]
                if m["depth"]
                else None,
                "whole_caller_max_ms": max(m["caller_ns"], default=0) / 1e6,
                "whole_caller_total_seconds": sum(m["caller_ns"]) / 1e9,
                "minimum_accepted_deadline_slack_ms": min(m["slack_ns"], default=0)
                / 1e6,
                "TT_requested_slots": 65536,
                "TT_effective_slots": 4096,
                "TT_byte_cap": 1048576,
                "TT_retained_observed_profile_peak_B": max(
                    (t["retained_bytes_peak"] for t in m["TT"]), default=0
                ),
                "physical_NN_head_FT_kernel_counts": None,
                "leaf_counter": None,
                "FT_mode": "Scalar",
                "PVS_actual": True,
                "MPC_actual": False,
            }
        )
    scores = [p["score"] for p in pairs]
    mean = sum(scores) / len(scores) if scores else None
    if unknown == 0:
        assert mean == known_score / 16
    result = {
        "issue": "quoridor-4lc.327",
        "stage": "FINAL_FIXED_D_COMPLETE_VERSION_LOCAL",
        "census": {**dict(census_totals), "unknown_reasons": dict(unknown_reasons)},
        "candidate": {
            "wins": wins,
            "losses": losses,
            "draws": draws,
            "wins_by_color": dict(by_color),
        },
        "complete_pair_mean": mean,
        "planned_score_range": [known_score / 16, (known_score + unknown) / 16],
        "pairs": pairs,
        "bootstrap": {
            "seed": 327,
            "resamples": 2000,
            "unit": "complete family pair",
            "percentile_95": bootstrap(scores) if len(scores) > 1 else None,
            "scope": "conditional fixed eight correlated families; lineage dependence not corrected, no population precision or sequential stopping assurance",
            "algorithm": "maintained xorshift64/rejection sampling/order-statistic indexes; main7 interval independently matched",
        },
        "cohorts": reports,
        "engines": engines,
        "native_NNUE_head_API_pipelines_from_leaf_static_evaluations": engines[0][
            "whole_invocation_counter_sums"
        ]["static_evaluations"],
        "NN_accounting_scope": "available candidate static evaluator/head pipeline counters including partial/rejected invocations when exposed; missing error counters UNKNOWN, no imputation; root/delta FT/physical kernels separate; current and final native96+96 and Torch16 charged separately",
        "game_head_selected_route": "not instrumented per game; runtime AVX2 available and guard selects noFMA fast/scalar branches; saved32 qualification inputs observedfast route",
        "all_recorded_accepted_moves_before_deadline": True,
        "unknown_games_not_draw": unknown,
        "failed_moves_counter_scope": "caller/depth metrics cover accepted moves; available whole counters include rejected rows; missing error counters counted UNKNOWN",
        "audit_recover": {
            "both_audits_summary_match": True,
            "both_recover_processes_exit0": True,
            "durable_journal_equals_direct_report": True,
            "manifest_journal_f32_value_bit_identity": True,
            "recover_stdout_bounded_tail": True,
            "extra_models_or_searches": 0,
        },
        "history_side_checks": {
            "exact_replayed_family_pairs": len(histories),
            "unique_scheduled_slots": len(observed_slots),
        },
        "compiled_source_expected": admission["expected_compiled_sources"],
        "actual_main_commit": admission["actual_main_commit"],
        "model_weight_SHA256": "9ca438e43b0c105ac5f802a302946f2ba71623ea2bc443b9c54cc9a8468b75b0",
        "private_ELF_SHA256": admission["private_runner_SHA256"],
        "freeze_protocol_SHA256": sha(OUT / "freeze-protocol.json"),
        "raw_artifacts_SHA256": bound_artifacts,
        "limitations": [
            "only fixed D opponent/final merged version/eight correlated families; no Sigma/general strength/Elo",
            "unknown/late/error/cancel/censor counts and planned16 bounds retained; unknown never draw",
            "runtime uses maintained PVS=true/MPCoff equally; D-only clock fixture disabled PVS, actual games record PVS work and caller acceptance",
            "physicalNN/FT and continuousstorage/RAM/TT peaks UNKNOWN; sampled values and configured caps separate",
            "final version ed168d3+privatef87f; prior current3W13L not transferred; same already opened book, no sealed-test or population guarantee",
            "no new game/modelforward/compile during collection; old errors/raw/fees/caps/assets/UNKNOWN retained",
        ],
    }
    (OUT / "final-result-summary.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(
        json.dumps(
            {
                k: result[k]
                for k in [
                    "census",
                    "candidate",
                    "complete_pair_mean",
                    "planned_score_range",
                    "bootstrap",
                    "native_NNUE_head_API_pipelines_from_leaf_static_evaluations",
                    "engines",
                ]
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
