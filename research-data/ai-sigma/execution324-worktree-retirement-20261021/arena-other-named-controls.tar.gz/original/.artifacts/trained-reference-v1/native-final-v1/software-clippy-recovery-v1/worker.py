"""Only the two unfinished Clippy commands; require supported forward admission."""

from datetime import datetime, timezone
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import time

OUT = Path(__file__).resolve().parent
PREVIOUS = OUT.parent / "software-v1"
SPEC = importlib.util.spec_from_file_location(
    "frozen_final_control", PREVIOUS / "worker.py"
)
W = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(W)
W.OUT = OUT
P = W.P


class Resources(W.Resources):
    def check(self, owned=()):
        P.CycleResources.check(self, owned)
        infos = [
            P.process_info(os.getpid()),
            *(P.process_info(x["pid"]) for x in owned),
        ]
        ram = sum(x["rss"] for x in infos if x) + 64 * 1024**2
        self.rss_peak = max(self.rss_peak, ram)
        if ram > 2 * 1024**3:
            raise P.CycleStopped("family RAM including controller exceeds2GiB")
        tmp = W.allocated(OUT / "tmp")
        named = self.named_bytes()
        self.tmp_peak = max(self.tmp_peak, tmp)
        self.named_peak = max(self.named_peak, named)
        if tmp + named > self.build_bound:
            raise P.CycleStopped(
                "retained named artifacts+TMP exceed supported build bound"
            )
        output = W.allocated(W.FINAL) - tmp
        self.output_peak = max(self.output_peak, output)
        if output > 16 * 1024**2:
            raise P.CycleStopped(
                "retained final private/control/failure output bound exceeded"
            )


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(W.WT)
    a = json.loads((OUT / "admission.json").read_text())
    assert a["admitted"] is True
    for path, digest in a["bindings"].items():
        assert W.sha(path) == digest, path
    assert W.sha(a["supported_resource_proof"]) == a["supported_resource_proof_SHA256"]
    packet = json.loads(Path(a["source_stop"]).read_text())

    def source_check():
        for row in packet["sources"]:
            assert W.sha(W.WT / row["relative_path"]) == row["SHA256"]
        for value in a["immutable_private"].values():
            assert W.sha(value["path"]) == value["SHA256"]

    source_check()
    W.M.quiet()
    assert P.available_memory() > 6 * 1024**3
    (OUT / "tmp").mkdir(exist_ok=True)
    os.environ.update(
        CARGO_TARGET_DIR=str(W.M.TARGET),
        CARGO_INCREMENTAL="0",
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        TMPDIR=str(OUT / "tmp"),
        CUDA_VISIBLE_DEVICES="",
        RUST_TEST_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
    )
    for name in (
        "QUORIDOR_BENCH_MANIFEST",
        "QUORIDOR_BENCH_FT_MODE",
        "RUSTFLAGS",
        "CARGO_ENCODED_RUSTFLAGS",
    ):
        os.environ.pop(name, None)
    resources = Resources()
    resources.build_bound = a["supported_build_upper_B"]
    known = json.loads(Path(a["retained_artifact_packet"]).read_text())
    for row in known["rows"]:
        assert W.sha(row["path"]) == row["SHA256"], row["path"]
        resources.named.add(row["path"])
    resources.check()
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "new_model_FT_NN_clock_game_calls": 0,
        "old_successes_replayed": False,
        "source_stop_SHA256": W.sha(a["source_stop"]),
        "supported_resource_proof_SHA256": a["supported_resource_proof_SHA256"],
    }
    start = time.monotonic()
    failure = None
    with (W.M.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        W.M.quiet()
        try:
            with P.cancellation_signals():
                for name, selectors in (
                    (
                        "clippy-runner",
                        [
                            "-p",
                            "quoridor-runner",
                            "--lib",
                            "--bin",
                            "quoridor-runner",
                            "--bin",
                            "nnue-diagnose",
                        ],
                    ),
                    (
                        "clippy-ai",
                        ["-p", "quoridor-ai", "--features", "research", "--lib"],
                    ),
                ):
                    log = OUT / (name + ".log")
                    record = P.execute(
                        [
                            W.CARGO,
                            "clippy",
                            *W.BASE,
                            *selectors,
                            "--message-format=json",
                            "--",
                            "-D",
                            "warnings",
                        ],
                        log,
                        None,
                        resources=resources,
                    )
                    result["commands"].append({"name": name, **record})
                    artifacts = []
                    for line in log.read_text().splitlines():
                        if not line.startswith("{"):
                            continue
                        row = json.loads(line)
                        if row.get("reason") != "compiler-artifact":
                            continue
                        if not row["fresh"]:
                            resources.named.update(row["filenames"])
                        if row["target"]["src_path"].startswith(str(W.WT) + "/"):
                            artifacts.append(
                                {
                                    "target": row["target"],
                                    "fresh": row["fresh"],
                                    "profile": row["profile"],
                                    "payloads": {p: W.sha(p) for p in row["filenames"]},
                                }
                            )
                    result.setdefault("artifacts", {})[name] = artifacts
                    resources.check()
                source_check()
                assert len(result["commands"]) == 2
        except BaseException as error:
            failure = repr(error)
        finally:
            records = [json.loads(p.read_text()) for p in OUT.glob("*.process.json")]
            result.update(
                ended=datetime.now(timezone.utc).isoformat(),
                whole_seconds=time.monotonic() - start,
                error=failure,
                all_direct_children_reaped=all(
                    r.get("direct_child_reaped") for r in records
                ),
                cleanup_complete=all(r.get("cleanup_complete") for r in records),
                remaining=[m for r in records for m in r.get("remaining", [])],
                sampled_family_RAM_including_controller_B=resources.rss_peak,
                retained_named_artifacts_B=resources.named_bytes(),
                named_sampled_peak_B=resources.named_peak,
                own_TMP_sampled_peak_B=resources.tmp_peak,
                own_output_sampled_peak_B=resources.output_peak,
                shared_target_transient_peak_B=None,
                qualified_native=False,
            )
            (OUT / "result.json").write_text(
                json.dumps(result, indent=2, allow_nan=False) + "\n"
            )
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
