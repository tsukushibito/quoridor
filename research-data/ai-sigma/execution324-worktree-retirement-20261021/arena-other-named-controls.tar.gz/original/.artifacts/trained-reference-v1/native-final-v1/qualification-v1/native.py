"""Final frozen model/source correspondence; two commands, no regenerated book."""

from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import time

OUT = Path(__file__).resolve().parent
FINAL = OUT.parent
PREVIOUS = FINAL / "software-v1"
SPEC = importlib.util.spec_from_file_location(
    "frozen_final_control", PREVIOUS / "worker.py"
)
W = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(W)
W.OUT = OUT
P = W.P


class Resources(W.Resources):
    def check(self, owned=()):
        P.CycleResources.check(self, owned)
        info = [P.process_info(os.getpid()), *(P.process_info(x["pid"]) for x in owned)]
        ram = sum(x["rss"] for x in info if x) + 64 * 1024**2
        self.rss_peak = max(self.rss_peak, ram)
        if ram > 2 * 1024**3:
            raise P.CycleStopped("final native familyRAM inclcontroller exceeds2GiB")
        named = self.named_bytes()
        self.named_peak = max(self.named_peak, named)
        if named > self.build_bound:
            raise P.CycleStopped(
                "retained bound named artifacts exceed forward build capacity"
            )
        output = W.allocated(FINAL)
        self.output_peak = max(self.output_peak, output)
        if output > 16 * 1024**2:
            raise P.CycleStopped(
                "final private+source+runtime+failedoutput envelope exceeded"
            )


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(W.WT)
    os.environ.update(
        CUDA_VISIBLE_DEVICES="",
        OMP_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        RAYON_NUM_THREADS="1",
    )
    a = json.loads((OUT / "admission.json").read_text())
    assert a["admitted"] is True
    for path, digest in a["bindings"].items():
        assert W.sha(path) == digest, path
    packet = json.loads(Path(a["source_stop"]).read_text())
    for row in packet["sources"]:
        assert W.sha(W.WT / row["relative_path"]) == row["SHA256"]
    W.M.quiet()
    assert P.available_memory() > 6 * 1024**3
    resources = Resources()
    resources.build_bound = a["supported_build_retention_upper_B"]
    known = json.loads(Path(a["retained_artifact_packet"]).read_text())
    for row in known["rows"]:
        assert W.sha(row["path"]) == row["SHA256"], row["path"]
        resources.named.add(row["path"])
    resources.check()
    expected = json.loads((OUT / "expected-compiled-bindings.json").read_text())
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "scope": "FINAL compiled merged source only, same BEST51/330-16/legal2; no Torch/book/game",
        "qualified_input_legal": False,
        "physical_kernel_calls": "UNKNOWN",
        "native_API_head_planned": 96,
        "native_API_FT_planned": 96,
        "book_reused_sha256": a["book_sha256"],
        "new_book_generation": False,
        "source_stop_sha256": a["source_stop_SHA256"],
        "final_strength_complete": False,
    }
    started = time.monotonic()
    failure = None

    def command(name, config):
        record = P.execute(
            [a["private_diagnose"], "--config", str(OUT / config)],
            OUT / (name + ".log"),
            None,
            resources=resources,
        )
        result["commands"].append({"name": name, **record})

    try:
        with P.cancellation_signals():
            command("correspondence", "correspondence-config.json")
            c = json.loads((OUT / "correspondence.json").read_text())
            assert c["compiled_sources"] == expected
            assert c["executable_sha256"] == a["private_diagnose_SHA256"]
            assert c["manifest_sha256"] == a["manifest_SHA256"]
            assert c["weights_sha256"] == a["weights_SHA256"]
            assert c["input_sha256"] == a["reference_SHA256"]
            assert c["status"] == "COMPATIBILITY_PASS_INPUT_ONLY"
            assert c["NN"] == 32 and c["processed"] == 32 and c["failed"] == 0
            assert len(c["predictions"]) == 32
            assert all(
                p["within_alert"] and p["guard_route"] is not None
                for p in c["predictions"]
            )
            command("legal", "legal-config.json")
            q = json.loads((OUT / "legal-qualification.json").read_text())
            assert q["compiled_sources"] == expected
            assert q["status"] == "PASS" and q["NN"] == 64 and q["undo_checks"] == 10
            assert q["parent_history_ply_exact_restore"] is True
            actions = {
                i: [
                    p["child_action"]
                    for p in q["predictions"]
                    if p["root"] == i and "child_action" in p
                ]
                for i in (0, 1)
            }
            assert actions == {0: [3, 5, 13, 81, 145], 1: [67, 75, 77, 81, 145]}
            result.update(
                qualified_input_legal=True,
                native_API_head_completed=96,
                native_API_FT_completed=96,
                observed_routes=[p["guard_route"] for p in c["predictions"]],
                actual_AVX2=q["avx2_available"],
                legal_selected_actions=actions,
                actual_final_game_count=0,
            )
    except BaseException as error:
        failure = repr(error)
    finally:
        records = [json.loads(p.read_text()) for p in OUT.glob("*.process.json")]
        result.update(
            ended=datetime.now(timezone.utc).isoformat(),
            whole_seconds=time.monotonic() - started,
            error=failure,
            all_direct_children_reaped=all(
                r.get("direct_child_reaped") for r in records
            ),
            cleanup_complete=all(r.get("cleanup_complete") for r in records),
            remaining=[m for r in records for m in r.get("remaining", [])],
            sampled_family_RAM_including_controller_B=resources.rss_peak,
            own_output_sampled_peak_B=resources.output_peak,
            retained_build_artifact_B=resources.named_bytes(),
            shared_target_transient_peak_B=None,
            admission_SHA256=W.sha(OUT / "admission.json"),
            parent_seals_models_defaults_unchanged=True,
            input_scope="16 correlated open-originalV rows/twoFT modes; two legal prefixes only; no general error/strength bound",
        )
        (OUT / "result.json").write_text(
            json.dumps(result, indent=2, allow_nan=False) + "\n"
        )
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
