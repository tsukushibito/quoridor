# Generic-arena361 affected software verification

Nine originally unrun assertions passed once: four Python methods and five Rust library tests. One CLI assertion remains unrun because the supplied current Cargo test receipt emits a library harness, not a main.rs test executable.

Source is already reviewed and integrated in Main. Qualified current360 Build ef4ba6e2 and release image39288a17 remain valid at their actual compilation/Clippy/release scope. Current publisher is907205da. Compilation does not prove assertion execution.

The exact four original Python methods ran from current Main test file3b02dc13 against current Main publisher; their bodies match the original stopped definitions. They exercised real FileRef IO and entry/approved-plan/config/journal/command checks with explicitly mocked source/caller/build-membership and fake model/artifact/Q/guardian facts. They passed4/4; no model, engine, geometry or Search was invoked.

The current Cargo-emitted library harness quoridor_runner-7e7af0e37ecd9661, SHA256 86ccf740c9600a44000e05dc2ab399bb7015356dadf67d963a8061c65be91d7e, ran only filter generic_arena_361 with test-threads1. It passed five assertions: arena3 and manifest2, with134 other tests filtered out. Current native source refs/keymaps and harness bytes matched before/after. Load/Q/model ports remain synthetic. Ordering/TT/model/library/private-copy/precopy successes were not replayed.

The already passed related prefix/torn-tail method was not replayed. Its current definition AST, arena collection branch and six relevant helper ASTs match the byte-bound old R1 proof. Reuse applies only to that unchanged boundary, not whole publisher or scientific qualification.

The sixth assertion, generic_arena_361_cli_cannot_override_parent_approved_plan_or_mix_config_route, lives in main.rs. Buildv10's actual Cargo test role uses --lib and its emitted artifact kind is lib. Both existing named executable candidates are library harnesses. Full affected Clippy/release compile Main but do not show this assertion ran. No authentic current main.rs cfg(test) executable is supplied. The smallest remaining condition is that bound binary harness; if absent, only its narrow no-run compilation needs Root's exact sole target-writer custody/support. This leaf performed no Cargo, target growth, new build/private copy or tool-version calls.

Both commands used one CPU3, familyRAM2GiB/G0, fresh nonblocking canonical lease/physical/named-peer/source-before-after checks and the maintained cycle_process guardian with120s limits. Both returned full capture, direct reap, process/handle cleanup, restored mask and completed final record. Earlier persisted pending/attempted records remain separate. Child identities were absent; empty owned testTMPs removed with floors held. Exact child UTCSTOP and continuous peaks remain UNKNOWN. Original Python command wall 0.28140328894369304s and Rust command wall 0.14778079197276384s are separate from parent/admin spans.

Inclusive4MiB is contained in existing8126464B controls. The conservative old floor is max(named original namespace892928B, retained source1MiB); adding new4MiB gives5242880B within component. Historical failures/source/floors held; globalincrement0/currentaggregate47140171776. A metadata-only quoting refusal occurred before shell execution/writes and was corrected. No science/model/rules/Search math/play/default/fullN/323resume qualification is inferred.

Source body readers stopped at 2026-10-11T23:18:48.334829+00:00; readers/children/jobs/TMP/remaining empty, no idle lease. coverage-join.json binds actual full logs and returned/persisted receipts. Root acceptance and the single actual CLI custody condition remain; no new reviewer/stale359 gate/human reply ACK.
