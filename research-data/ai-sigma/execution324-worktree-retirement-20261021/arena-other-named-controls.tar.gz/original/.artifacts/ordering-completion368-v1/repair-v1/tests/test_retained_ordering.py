"""New owning numerical/source correspondence, with synthetic subjects only."""

import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source/scripts/dev/research-lifecycle.py"
spec = importlib.util.spec_from_file_location("ordering368_publisher", SOURCE)
publisher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(publisher)


class RetainedOrdering(unittest.TestCase):
    def test_original_numerical_subject_and_current_source_remain_distinct(self):
        # Actual bounded JSON/FileRef IO; models, build/adoption and guardian facts
        # are explicitly synthetic. No source-before FileRef is read after overwrite.
        with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as name:
            workspace = Path(name)

            def file(path, value):
                path.parent.mkdir(parents=True, exist_ok=True)
                raw = json.dumps(value).encode()
                path.write_bytes(raw)
                return {
                    "path": str(path),
                    "sha256": hashlib.sha256(raw).hexdigest(),
                    "bytes": len(raw),
                    "mode": "0644",
                }

            def shape_ref(path, sha):
                return {"path": str(path), "sha256": sha * 64, "bytes": 1, "mode": "0644"}

            keys = [
                "runner/ordering_assessment.rs",
                "runner/research_manifest.rs",
                "nnue/residual.rs",
            ]
            before = {
                k: file(workspace / "crates" / k, {"synthetic": "original", "key": k}) for k in keys
            }
            after = copy.deepcopy(before)
            for k in keys[:2]:
                after[k] = file(workspace / "crates" / k, {"synthetic": "current", "key": k})

            def build(refs, artifact):
                projection = {k: r["sha256"] for k, r in refs.items()}
                source = {
                    "workspace": str(workspace),
                    "files": list(refs.values()),
                    "manifest": shape_ref(workspace / "Cargo.toml", "6"),
                    "lock": shape_ref(workspace / "Cargo.lock", "7"),
                    "cargo_configs": [],
                    "compiled_sources": refs,
                    "generator_compiled_sources": refs,
                }
                return {
                    "schema": publisher.BUILD_SCHEMA,
                    "status": "PASS",
                    "cleanup_complete": True,
                    "remaining": [],
                    "checks": [
                        {
                            "role": role,
                            "argv": ["/synthetic/cargo", role],
                            "guardian_return": {"exit_code": 0, "cleanup_complete": True},
                        }
                        for role in ("test", "lint", "build", "bindings")
                    ],
                    "artifact": shape_ref(workspace / (artifact + ".bin"), artifact),
                    "compiled_sources": projection,
                    "generator_compiled_sources": projection,
                    "source": source,
                    "tools": {"fixture": "UNCHANGED"},
                    "env": {"RUSTFLAGS": "UNCHANGED", "TMPDIR": artifact},
                }

            original = build(before, "8")
            current = build(after, "9")
            original_ref = file(workspace / "original/manifest.json", original)
            current_ref = file(workspace / "current/manifest.json", current)
            model = {
                "descriptor": {
                    **shape_ref(workspace / "model/manifest.json", "d"),
                    "sha256": "46ec2c4708f96dcf9fad579c2fb0d1299c6663df27412f0faac98267467715e1",
                    "bytes": 677,
                    "mode": "0600",
                },
                "weights": {
                    **shape_ref(workspace / "model/weights.f32", "e"),
                    "sha256": "046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841",
                    "bytes": 49284,
                },
                "evaluator_sha256": "96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875",
            }
            experiment = {
                "phase": "compare",
                "build_manifest": current_ref,
                "config": {
                    **shape_ref(workspace / "config.json", "c"),
                    "sha256": "4a1bb65baea495a99501a087aa59c8391fadbc9fa0719ad9c8350563388c2aa0",
                },
                "schedule": {
                    **shape_ref(workspace / "schedule.json", "s"),
                    "sha256": "6671bbf8d04ed31fedbfeccdbfaf28dcf5c713e02866544f0d9c8de2110b8671",
                },
                "canonical_plan_sha256": "ddb46782feb000f77f5e45d99ffde19d27bce9eaae0e7999afed97bb0a54948e",
                "inputs": [shape_ref(workspace / f"input{i}", str(i)) for i in range(6)],
                "models": [model],
                "dynamic_libraries": [
                    {"file": shape_ref(workspace / f"lib{i}", "b"), "version": "FAKE"}
                    for i in range(5)
                ],
                "rules": "research-standard-2p-threefold-goal-first-v1",
                "distance_units": "wall-distance/80",
                "value_perspective": "side-to-move",
                "planned_slots": 360,
                "batch": None,
                "argv": [
                    "/synthetic/runner",
                    "ordering-assess",
                    "--experiment",
                    "@EXPERIMENT@",
                    "--experiment-sha256",
                    "@EXPERIMENT_SHA256@",
                ],
            }
            qualified = {
                **experiment,
                "phase": "ordering-qualification",
                "build_manifest": original_ref,
                "numerical_qualification": None,
                "planned_slots": 20,
                "argv": [*experiment["argv"]],
            }
            qualified["argv"][1] = "ordering-qualify"
            origin_ref = file(workspace / "qualified-experiment.json", qualified)
            claim = publisher.numerical_fields(experiment, original)
            completion = {
                "schema": publisher.COMPLETION_SCHEMA,
                "status": "PASS",
                "cleanup_complete": True,
                "remaining": [],
                "primary": None,
                "secondary": [],
                "experiment": origin_ref,
                "data": {"status": "PASS", "numerical_qualification": claim},
            }
            qualification = file(workspace / "qualification/manifest.json", completion)
            experiment["numerical_qualification"] = qualification
            adoption = {
                "schema": "quoridor.research.source-adoption.v1",
                "status": "ACCEPTED",
                "source": current["source"],
                "retained_ordering_numerical": {
                    "scope": "ordering20-input-and-head-v1",
                    "qualification": qualification,
                    "build_manifest": original_ref,
                    "changed_compiled_sources": {
                        k: {"before": before[k], "after": after[k]} for k in keys[:2]
                    },
                },
            }

            def admitted(subject, accepted):
                subject = copy.deepcopy(subject)
                subject["source_adoption"] = file(
                    workspace / "research-data/adoption.json", accepted
                )
                return subject

            refs = []
            observed = publisher.numerical_check(experiment, admitted(current, adoption), refs=refs)
            self.assertEqual(observed, claim)
            self.assertNotEqual(observed["artifact_sha256"], current["artifact"]["sha256"])
            self.assertIn(original_ref, refs)
            self.assertIn(origin_ref, refs)
            for key in ("scope", "qualification", "build_manifest", "changed_compiled_sources"):
                bad = copy.deepcopy(adoption)
                del bad["retained_ordering_numerical"][key]
                with self.subTest(missing=key), self.assertRaises((publisher.Refused, KeyError)):
                    publisher.numerical_check(experiment, admitted(current, bad))
            for field, value in (
                ("scope", "wrong"),
                ("qualification", original_ref),
                ("build_manifest", current_ref),
            ):
                bad = copy.deepcopy(adoption)
                bad["retained_ordering_numerical"][field] = value
                with self.subTest(wrong=field), self.assertRaises(publisher.Refused):
                    publisher.numerical_check(experiment, admitted(current, bad))
            bad = copy.deepcopy(adoption)
            bad["retained_ordering_numerical"]["changed_compiled_sources"][keys[0]]["after"][
                "sha256"
            ] = "f" * 64
            with self.assertRaises(publisher.Refused):
                publisher.numerical_check(experiment, admitted(current, bad))
            bad = copy.deepcopy(adoption)
            bad["status"] = "PENDING"
            with self.assertRaises(publisher.Refused):
                publisher.numerical_check(experiment, admitted(current, bad))
            for field in ("tools", "env"):
                drift = copy.deepcopy(current)
                drift[field]["DRIFT"] = "unapproved"
                with self.subTest(compiler=field), self.assertRaises(publisher.Refused):
                    publisher.numerical_check(experiment, admitted(drift, adoption))
            drift = copy.deepcopy(current)
            drift["source"]["compiled_sources"][keys[2]]["sha256"] = "f" * 64
            drift["compiled_sources"][keys[2]] = "f" * 64
            matched = copy.deepcopy(adoption)
            matched["source"] = drift["source"]
            with self.assertRaises(publisher.Refused):
                publisher.numerical_check(experiment, admitted(drift, matched))
            for field in ("inputs", "models", "dynamic_libraries"):
                drift = copy.deepcopy(experiment)
                if field == "inputs":
                    drift[field].reverse()
                elif field == "models":
                    drift[field][0]["evaluator_sha256"] = "f" * 64
                else:
                    drift[field][0]["version"] = "DRIFT"
                with self.subTest(science=field), self.assertRaises(publisher.Refused):
                    publisher.numerical_check(drift, admitted(current, adoption))
            changed_claim = copy.deepcopy(claim)
            changed_claim["artifact_sha256"] = current["artifact"]["sha256"]
            generic = copy.deepcopy(experiment)
            generic["argv"][1] = "value-search-compare"
            generic["numerical_qualification"] = file(workspace / "old-numerical.json", claim)
            with self.assertRaises(publisher.Refused):
                publisher.numerical_check(generic, current)
            # Even a claimed current artifact cannot overwrite the OLD qualification.
            changed_completion = copy.deepcopy(completion)
            changed_completion["data"]["numerical_qualification"] = changed_claim
            changed_q = file(workspace / "changed-qualification/manifest.json", changed_completion)
            drift = copy.deepcopy(experiment)
            drift["numerical_qualification"] = changed_q
            changed_adoption = copy.deepcopy(adoption)
            changed_adoption["retained_ordering_numerical"]["qualification"] = changed_q
            with self.assertRaises(publisher.Refused):
                publisher.numerical_check(drift, admitted(current, changed_adoption))


if __name__ == "__main__":
    unittest.main()
