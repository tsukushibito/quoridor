# Ordering368 current entry gap

No new science job has been submitted. Null runtime fields and an omitted command timeout are supported by the current maintained caller.

The frozen config4a1bb embeds the original existing360 output path. Native prepare_inputs reads that path; output_correspondence requires equality to the new intent.data_root, and Output.setup refuses an existing directory. This prevents an unchanged39288 image/config4a1bb from producing in the exclusively owned new368 namespace. Changing only config.output changes the raw config SHA; current numerical_check requires equality to the qualified Experiment config and retained370ca numerical config SHA. No supported override was found. Original data, image and qualification remain unchanged.

One ordinary fresh-output inlet correspondence is required before submission. Preserve approved method/input/model/source numerical scope; do not rerun root or software qualifiers, write old360 output, bypass current ownership or forge a replacement qualification. If the current port truly lacks that separation, Root must authorise/integrate the smallest genuine source/artifact repair; this leaf has no target growth or compiler grant.

The issued support also needs the normal maintained shape fields funded_union_B and global_held_B. This is a metadata correspondence inside the already issued worker240MiB/global47945478144, not a new grant. A2GiB RUN family is contained in the issued3GiB ceiling and accepted by current publisher; no family-limit code change is necessary.

Fresh unique Experiment/intent/job templates are explicitly NOT_READY with no job/START and no claimed admission. Schedule6671/config4a1bb/20root370ca/currentBuild ef4/image39288 stay by reference. One367 source-only freeze coordination was delivered; no idle lease or whole-owner wait. All old360FAILED/raw/errors/fees/masks/UNKNOWN remain held. Source readers stopped after the finite inlet inspection; children/jobs/TMP empty.
