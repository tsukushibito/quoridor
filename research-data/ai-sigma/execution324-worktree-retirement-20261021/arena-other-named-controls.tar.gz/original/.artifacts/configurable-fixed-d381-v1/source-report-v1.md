# Configurable fixed-D producer and outcome cache — stopped source target

Source only. No author native, Search, model, head, data-generation or fit call. Rustfmt and scoped Ruff format/lint passed; functional Python and native definitions remain UNRUN while original diagnostic job68a167e2 owns shared timing/readers. No quietness is inferred from elapsed time. No Main/Git/index/target/private/environment writes.

The existing D6/PVS/TT4096/solverOFF/(a0,b8) play, goal-first/actual-threefold handling and per-colour sessions are retained. max_total_nodes remains one atomic budget shared across the batch; opaque failed work keeps its reservation. Configured slices use stable global request order and one pre-output partition. Canonical/LR prefix extension and identical LR endpoint geometry form transitive whole families; an evaluation-book collision refuses input preparation before generation. Original score bits are separate from actual outcome z; UNKNOWN is unlabelled, and known near-goal raw±2 is not range-masked. No N/issue/path/paired-teacher selection is hardcoded.

The ten common_study fields are families, prefix_seed, prefix_lengths (unique configured order), split_seed, root_value_policy=outcome_only, schedule, partition, batch_start, batch_count, excluded_books. schedule/partition/books are normal BoundJson {path,sha256}; excluded_books is a LIST. planned_games equals the actual batch_count. Dataset size need not divide the prefix-length count. No 40G/160G, extraction64, 8GiB partial policy or scientific settings are selected here.

## Exact converter interface

`terminal-cache --input STREAM [--input STREAM ...] --output NEW_OUTPUT [--input-binding PATH --binding-sha256 SHA]`

Optional binding flags occur together and carry only distinct necessary lineage. Ordered streams must be disjoint consecutive slices of identical global settings. The normal source header binds the actual config reference. Complete source/footer/counters/history/raw-bit checks and incomplete-marker-last publication remain in the native owner; no detailed cache mirror or previous-cache/v2 migration remains.

`source_binding=[{path,sha256},...]` in input order; `source_content=[{encoding:"gzip-single-member-v1",compressed:{path,sha256,bytes,mode},raw_sha256,raw_bytes},...]`, always arrays even for one stream. dataset_sha is the Rust JSON SHA of the ordered source_binding array, an ordered lineage identity. No independent backend digest is computed.

`stream_intake={status:"complete",scope:"common-corpus",publication_protocol:"incomplete-marker-last-v1",batches:[{batch_start,batch_count,config:{path,sha256}},...]}`. schedule_sha256 and family_partition_sha256 refer to the shared global inputs. Optional model_scale_authority is exactly starting_weights_sha256/descriptor_sha256/evaluator_sha256/scale_policy=incumbent_descriptor_T_only, with no selected_plan.

Seven v3 binaries/widths stay unchanged. sampling.games adds only chronological blocks `{game,family_code,start,rows}`; blocks cover all rows exactly, have unique game names, one family per block and at most200 rows. This preserves actual game identity when multiple games share one collision family. families[].game is the first game representative. TerminalCorpus uses blocks for per-row game names, retains original row order/groups/splits/reflection/FP32 distances, and rejects old range masks and T/V drift. The historic1MiB manifest ceiling is removed from producer and loader.

## Root-owned caller composition

Expose the existing `teacher_pilot::depth6::prepare_inputs(&InputConfig)` at the normal input-preparation caller. Its fields are families,prefix_seed,prefix_lengths,split_seed,excluded_books,output; it creates one actual schedule.json and partition.json before batch outcomes. The supplied output refs are real only after this operation succeeds. Do not invent prospective FileRefs or launch it from this source assignment.

Normal generation `teacher_pilot_execution::run_bound` keeps the maintained Experiment/BoundControl load and now returns one retained stream/report/encoder Content. Aggregate materialization is a separate ordinary converter operation after serial batch completion. Direct `run`/`run_depth6_with_cancel` callers now pass actual BoundJson config identity instead of a bare SHA. Remove old phase/depth-throughput/closed pilot CLI and fixtures when composing current Root-owned callers, rather than retaining compatibility branches. Existing finite execute/directwait/onceFinalize controls own serial batch continuation and unexpected failure/cancel; no per-batch LLM admission is introduced.

Learner381.1 was closed before the last clarification send; that dispatch refusal is retained. At integration align its common_cache_config with excluded_books as a list, preserve configured prefix-length order rather than requiring sorted order, and consume the chronological game-block metadata above. Initial outcome-only and aggregate-array interfaces were accepted previously. Do not reopen or duplicate its passed NN0 definitions for paperwork.

CompactCorpus's fused geometry/reflection API is unchanged. The distance_steps change is only the common-cache completion hook; remaining unrelated recipes were not edited. Root can remove now-unused closed recipe callers with their owning retirement. Existing publication fault tests/shared-node-budget tests remain unchanged and are not selected for replay.

No new generated cache or weights exist. Reviewable parameters remain ordinary explicit settings; Root owns Main adoption, caller composition, current Build, actual tests and future scientific admission. The attached exact new/changed definition list is unrun, not a PASS or a new model/strength claim.
