from prepare import read, write

p = "python/quoridor_training/research355/strength355.py"
s = read(p)
s = s.replace(
    """    require(
        bool(raw["compiled_sources"]) and all(sha(v) for v in raw["compiled_sources"].values()),
        "compiled generator bindings",
    )
""",
    "",
).replace('        "source_compiled_generator": raw["compiled_sources"],\n', "")
write(p, s)
p = "tools/research-session/test_runtime_provenance.py"
s = read(p).replace(
    '            "files": [self.ref(p) for p in (self.source, manifest, lock)],',
    '            "untracked_inputs": [],',
)
s = s.replace("import sys\n", "import sys\nimport subprocess\n")
a = s.index("        script = (")
s = (
    s[:a]
    + """        for args in (["init", "-q"], ["add", "crates/fixture/src/lib.rs", "Cargo.toml", "Cargo.lock"],
                     ["-c", "user.name=Synthetic379", "-c", "user.email=synthetic379@example.invalid", "commit", "-qm", "synthetic source"]):
            subprocess.run(["git", "-C", str(self.root), *args], check=True, capture_output=True)
        self.source_info["commit"] = subprocess.check_output(["git", "-C", str(self.root), "rev-parse", "HEAD"]).decode().strip()
"""
    + s[a:]
)
s = s.replace('"reference drift"', '"Git delta drift"')
write(p, s)
p = "tools/research-session/test_arena_plan.py"
s = read(p).replace(
    '            "source": {"files": [], "compiled_sources": {}},',
    '            "source": {"fixture_only": "NOT BUILD PROVENANCE"},',
)
s = s.replace('            "compiled_sources": {},\n', "").replace(
    '"checks": [{"role": role} for role in ("test", "lint", "build", "bindings")]',
    '"checks": [{"role": role} for role in ("test", "lint", "build")]',
)
s = s.replace(
    'build = {"artifact": spec["artifact"], "compiled_sources": {}}',
    'build = {"artifact": spec["artifact"]}',
)
write(p, s)
p = "python/quoridor_training/research355/test_lifecycle_repair355.py"
s = (
    read(p)
    .replace(
        '            "files": [self.source, manifest, lock, runner],',
        '            "untracked_inputs": [],',
    )
    .replace('            "compiled_sources": self.compiled,\n', "")
)
s = s.replace(
    """        self.build_ref, self.build = self.operation("build")""",
    """        # Saved adapter tests use synthetic compiler/Git facts; the actual owning
        # BUILD checks are covered by test_build_provenance.py, never claimed here.
        source_port = mock.patch.object(publisher, "source_check", return_value=None)
        source_port.start()
        self.addCleanup(source_port.stop)
        self.build_ref, self.build = self.operation("build")""",
)
s = s.replace(
    """                "output": str(operation),
""",
    """                "output": str(operation),
                "source": self.source_info,
                "tools": {}, "env": {}, "target": str(self.root),
""",
)
s = s.replace('roles = ("test", "lint", "build", "bindings")', 'roles = ("test", "lint", "build")')
a = s.index("        for role in roles:\n            raw = json.dumps(")
b = s.index("            log = self.file(", a)
s = (
    s[:a]
    + """        cargo_artifact = {"reason":"compiler-artifact","target":{"name":"quoridor-runner","kind":["bin"]},
            "profile":{"test":False},"executable":self.artifact["path"],"fresh":False}
        for role in roles:
            events = [cargo_artifact, {"reason":"build-finished","success":True}]
            raw = b"\\n".join(json.dumps(event).encode() for event in events) + b"\\n"
"""
    + s[b:]
)
s = s.replace(
    "                compiled_sources=self.compiled_hashes,",
    '                cargo_artifact=cargo_artifact, artifact_target="quoridor-runner", tools={}, env={},',
)
write(p, s)
