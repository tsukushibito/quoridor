# 379 R1-only stopped repair

Restored `let families = families(&book, &plan)?;` immediately after the bound book read, before header, output and model setup. The existing validator again supplies the vector used by later indexes and retains book/plan/rules/family validation before model loading. The obsolete current-source-map comparison stays removed.

The patch adds exactly one line. Removing that line reconstructs original cca41ed8 bytes. The original postsubject is preserved in minimum-before.rs.gz; original a9 binding, negative review3ec4/findings8613, earlier proofs and receipts are historical and unchanged. The other33 members are unchanged by reference. No Main, target, private, environment or library mutation occurred.

Scoped Rustfmt2024 write/check, gzip identity and zero-fuzz/zero-offset GNU forward/inverse reconstruction passed. The existing families validator and all bytes outside the insertion are exact. This is static source proof only: compiler/type/Clippy/build and affected software remain unrun. No old successful tests or scientific calls ran.

Related question for SAME379.2 via Root only: does this exact restored owning binding resolve R1, preserving pre-model full validation while retaining the reviewed simplification and all other guarantees? No whole source graph, mathematical survey or new mechanism is requested.

Inclusive512KiB related source preparation is inside existing4MiB; related1MiB review is the issued reclassification within16MiB review/whole204MiB. No new allocation/refund/borrow. Source-only ownership and actual reader/writer/TMP/lease STOP are in proof.json.376 target custody belongs to its writer; no379 build authority or test-start assumption is made. Root current-source adoption and actual376/Cargo STOP plus returned custody remain future entry facts.
