import ast
from prepare import read, write, remove_between


def delete_method(s, name):
    t = ast.parse(s)
    n = next(n for n in ast.walk(t) if isinstance(n, ast.FunctionDef) and n.name == name)
    lines = s.splitlines(keepends=True)
    return "".join(lines[: n.lineno - 1]) + "".join(lines[n.end_lineno :])


p = "tools/research-session/test_lifecycle.py"
s = read(p)
s = s.replace(
    'self.source_info = {"commit": "1" * 40, "patch": None, "files": [ref(self.source)]}',
    'self.source_info = {"commit": "1" * 40, "patch": None, "untracked_inputs": []}',
)
s = s.replace('            compiled_sources={"source": ref(self.source)},\n', "")
s = s.replace(
    '        self.source_info["files"] += [ref(manifest), ref(lock)]',
    """        # Standard Git is the fixture's only source/delta authority; no map builder.
        for args in (["init", "-q"], ["add", "source.rs", "Cargo.toml", "Cargo.lock"],
                     ["-c", "user.name=Synthetic379", "-c", "user.email=synthetic379@example.invalid", "commit", "-qm", "synthetic source"]):
            subprocess.run(["git", "-C", str(self.root), *args], check=True, capture_output=True)
        self.source_info["commit"] = subprocess.check_output(["git", "-C", str(self.root), "rev-parse", "HEAD"]).decode().strip()""",
)
s = s.replace(
    """            ]
            + [
                {
                    "name": "bindings",
                    "role": "bindings",
                    "argv": [str(self.private), "research-bindings"],
                }
            ],""",
    """            ],""",
)
s = remove_between(
    s, '        elif argv[-1] == "research-bindings":', "        elif len(argv) > 1 and argv[1]"
)
s = s.replace(
    "def test_final_adopted_projection_drift_refuses_after_successful_commands(self):",
    "def test_build379_final_cargo_artifact_drift_refuses_after_successful_commands(self):",
)
s = s.replace(
    '        c["compiled_sources"] = {"source": "0" * 64}',
    '        c["cargo_artifact"]["target"]["name"] = "wrong-target"',
)
# Retire the portion of the manifest/config test which deliberately created an obsolete native echo.
a = s.index("        executor = self.executor\n\n        def mismatch(")
b = s.index("    def test_e2e_build_manifest_", a)
s = s[:a] + s[b:]
a = s.index(
    '        self.source_info["compiled_sources"] = {', s.index("    def generation_fixture")
)
b = s.index('        self.spec["source_adoption"]', a)
s = s[:a] + s[b:]
s = s.replace(
    'sources = {k: ref(self.source)["sha256"] for k in lc.GENERATION_SOURCE_KEYS}',
    'sources = {"opaque-historical": ref(self.source)["sha256"]}',
)
# Assertions about the retired parallel source graph disappear; input/artifact/raw identities remain.
for fragment in [
    """        self.assertEqual(
            c["data"]["generation"]["compiled_sources"],
            {k: r["sha256"] for k, r in self.source_info["compiled_sources"].items()},
        )\n""",
    """        self.assertEqual(
            g["generation_compiled_sources_sha256"], lc.canonical_sha(g["native_compiled_sources"])
        )\n""",
    """        self.assertEqual(
            manifest["compiled_sources"],
            {k: ref(self.source)["sha256"] for k in lc.RESEARCH_SOURCE_KEYS},
        )\n""",
]:
    s = s.replace(fragment, "")
s = s.replace(
    '        self.assertEqual(len(data["generation"]["compiled_sources"]), 35)\n', ""
).replace('        self.assertEqual(len(data["generation"]["native_compiled_sources"]), 34)\n', "")
s = delete_method(s, "test_generation_source_domains_actual35_projection_and_exact_refusals")
s = s.replace('        self.source_info["files"].append(ref(caller))\n', "")
a = s.index('        historical = next(r for r in manifest["source"]["files"]')
b = s.index("\n    def ", a)
s = s[:a] + s[b:]
write(p, s)
p = "tools/research-session/test_runtime_provenance.py"
s = read(p).replace(
    '            "files": [self.ref(self.source), manifest, lock],',
    '            "untracked_inputs": [],',
)
s = s.replace('            "compiled_sources": {"fixture/native": self.ref(self.source)},\n', "")
s = s.replace(
    '            "compiled_sources": {"fixture/native": self.ref(self.source)["sha256"]},\n', ""
)
s = s.replace('("test", "lint", "build", "bindings")', '("test", "lint", "build")')
s = s.replace(
    '        self.assertEqual(manifest["compiled_sources"], self.build["compiled_sources"])\n', ""
)
s = s.replace(
    '        self.assertNotIn(self.source_info["compiled_sources"]["fixture/native"], refs)',
    "        self.assertNotIn(self.ref(self.source), refs)",
)
s = s.replace('            ("compiled_sources", {"fixture/native": "0" * 64}),\n', "")
write(p, s)
p = "tools/research-session/test_ordering_input_qualification.py"
s = read(p).replace(', "compiled_sources": {"fake": "b" * 64}', "")
write(p, s)
