"""Collect one failed379 BUILD, original two-test scope and actual source release."""

import importlib.util
import json
import re
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/build-provenance379-v1"
PHASE = OWN / "software-build-v1"
OUT = PHASE / "failed-collection-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


spec = lc.document(ref(PHASE / "intent.json"))
manifest_ref = ref(PHASE / "operation-v1/manifest.json")
manifest = lc.document(manifest_ref)
job_ref = ref(PHASE / "runtime-v1/result.json")
job = lc.document(job_ref)
lc.require(
    manifest["status"] == "FAILED" and job["job_id"] == "2da77a57-82dd-4378-8855-8dc3510dcde9",
    "same original failed operation",
)
lc.require(not (PHASE / "operation-v1/INCOMPLETE").exists(), "authoritative finalization")
lc.require(not OUT.exists(), "exclusive stopped collection")
checks = manifest["checks"]
identities = [manifest["originating_job"]["supervisor"], manifest["originating_job"]["child"]]
assertion_evidence = []
capture_refs = []
for check in checks:
    for field in ["full_log", "persisted_process_receipt"]:
        lc.read_ref(check[field], max(lc.CONTROL_BYTES, check[field]["bytes"]))
        capture_refs.append(check[field])
    if check["guardian_return"] is not None:
        lc.settled(check["guardian_return"])
        lc.require(
            check["capture_complete"]
            and check["full_log"]["bytes"] == check["guardian_return"]["log_bytes_seen"],
            "actual complete returned scope",
        )
        identities.append(check["guardian_return"]["child"])
    else:
        identities.append(lc.document(check["persisted_process_receipt"])["child"])
    if check["role"] == "test":
        text = lc.read_ref(check["full_log"]).decode()
        expected = next(x for x in check["argv"] if "::build379_" in x)
        lc.require(
            text.count("running 1 test") == 1
            and f"test {expected} ... ok" in text
            and re.search(r"test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured;", text),
            "exact selected assertion executed once",
        )
        assertion_evidence.append(
            {
                "actual_name": expected,
                "count": 1,
                "status": "PASS_ORIGINAL_SCOPE_ONLY",
                "full_log": check["full_log"],
                "guardian_return": check["guardian_return"],
                "Cargo_artifacts": check["cargo"]["artifacts"],
            }
        )
lc.require(
    len(assertion_evidence) == 2 and not any(c["role"] == "build" for c in checks),
    "two passes, release unentered",
)
failed = next(c for c in checks if c["role"] == "lint")
raw = lc.read_ref(failed["full_log"]).decode()
lines = raw.splitlines()
diags = []
for i, line in enumerate(lines):
    if line.startswith("error:") and not line.startswith("error: could not compile"):
        block = []
        for x in lines[i:]:
            if block and (x.startswith("{") or x.startswith("error:")):
                break
            block.append(x)
        diags.append("\n".join(block))
lc.require(len(diags) == 3, "exact original Clippy failure set")
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
absence = []
for identity in identities:
    p = Path("/proc") / str(identity["pid"]) / "stat"
    try:
        actual = p.read_text().rsplit(")", 1)[1].split()[19]
        current = {"pid": identity["pid"], "start_ticks": actual, "boot_id": boot}
    except FileNotFoundError:
        current = None
    lc.require(current != identity, "original owned process still live")
    absence.append({"original": identity, "current": current, "same_identity_live": False})
lc.physical_and_quiet(spec)
with lc.lease():
    lc.source_check(spec["source"])
    for tool in spec["tools"].values():
        lc.read_ref(tool["file"], max(lc.CONTROL_BYTES, tool["file"]["bytes"]))
    lc.document(spec["source_adoption"])
    handover = lc.document(spec["target_handover"])
    marker = json.loads((Path(spec["target"]) / ".research-owner.json").read_bytes())
    lc.require(marker == handover["after_owner_marker"], "actual returned target marker")
    allocated = lc.allocated(spec["target"])
    private_allocated = lc.allocated(Path(spec["private"]).parent)
    lc.require(
        allocated <= handover["target_max_B"]
        and private_allocated <= handover["fresh_private_forward_max_B"],
        "actual retained target/private caps",
    )
    lc.require(
        not Path(spec["private"]).exists() and not Path(spec["TMP"]).exists(),
        "private release unentered/TMP removed",
    )
    paths = [
        MAIN / "crates/quoridor-ai/src/cheap_static_ordering.rs",
        MAIN / "crates/quoridor-ai/src/cheap376_tests.rs",
    ]
    source_refs = [ref(p) for p in paths]
    smallest = [
        {"source": source_refs[0], "code": "\n".join(paths[0].read_text().splitlines()[52:69])},
        {"source": source_refs[1], "code": "\n".join(paths[1].read_text().splitlines()[176:204])},
    ]
    source_STOP = lc.stamp()
lease_STOP = lc.stamp()
OUT.mkdir()
record = {
    "issue": "quoridor-4lc.379.1",
    "job_id": job["job_id"],
    "status": "FAILED_ORIGINAL_NOT_RETRIED",
    "manifest": manifest_ref,
    "outer_job": job_ref,
    "outer_log": ref(PHASE / "runtime-v1/output.log"),
    "original_intent": ref(PHASE / "intent.json"),
    "support": spec["support"],
    "source_adoption": spec["source_adoption"],
    "handover": spec["target_handover"],
    "checks": [
        {
            "name": c["name"],
            "role": c["role"],
            "status": c["status"],
            "full_log": c["full_log"],
            "persisted_process_receipt": c["persisted_process_receipt"],
            "capture_complete": c["capture_complete"],
            "guardian_return": c["guardian_return"],
        }
        for c in checks
    ],
    "passed_assertions": assertion_evidence,
    "versions_passed_original_scope": 7,
    "compiler_rebuilt_test_harnesses": all(
        a["fresh"] is False for e in assertion_evidence for a in e["Cargo_artifacts"]
    ),
    "Clippy_failure_diagnostics": diags,
    "smallest_directed_source": smallest,
    "minimum_Root_repair": "376 ordinary equivalent Clippy corrections: !cell.is_multiple_of(9); iterate PROXIMITY rows/entries with enumerate preserving pawn/anchor indexes and all assertions. No warning allow/semantic change. Root chooses/owns source repair and updated current Source; do not replay two379 or nine376 successes.",
    "release_private_Build_PASS": "NOT_ENTERED_NOT_QUALIFIED",
    "five379_and_eight374_Python": "NOT_RUN pending genuinely accepted Build",
    "inner_cleanup_complete": manifest["cleanup_complete"],
    "outer_cleanup_complete": job["cleanup_complete"],
    "failed_guardian_return": failed["guardian_return"],
    "failed_capture_complete": failed["capture_complete"],
    "failed_persisted_facts": lc.document(failed["persisted_process_receipt"]),
    "primary": manifest["primary"],
    "secondary": manifest["secondary"],
    "controller_whole_wall_seconds_counted_once": job["wall_seconds"],
    "nested_command_walls_not_added": True,
    "original_process_identities": absence,
    "actual_source_reader_STOP": source_STOP,
    "actual_canonical_release": lease_STOP,
    "target_allocated_after_B": allocated,
    "target_retained_floor_B": max(allocated, handover["effective_retained_floor_B"]),
    "target_cap_B": handover["target_max_B"],
    "private_allocated_B": private_allocated,
    "new_private_absent": True,
    "TMP_absent": True,
    "continuous_target_RAM_peak": "UNKNOWN",
    "owned_readers_children_jobs_TMP_remaining": [],
    "reservation": None,
    "Main_source_repairs": 0,
    "automatic_job_retry": 0,
    "model_library_Sigma_Search_games_entry": False,
}
lc.new_json(OUT / "failed-build-STOP.json", record)
print(
    json.dumps(
        {
            "STOP": source_STOP,
            "release": lease_STOP,
            "record": ref(OUT / "failed-build-STOP.json"),
            "target_after_B": allocated,
            "private_B": private_allocated,
            "original_assertions_passed_once": 2,
        }
    )
)
