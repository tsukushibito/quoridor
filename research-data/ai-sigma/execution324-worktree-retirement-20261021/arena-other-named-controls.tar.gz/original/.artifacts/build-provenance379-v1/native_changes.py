from prepare import read, write, remove_between


def replace(path, old, new):
    text = read(path)
    assert old in text, (path, old)
    write(path, text.replace(old, new))


p = "crates/quoridor-runner/src/arena_manifest.rs"
s = read(p)
s = remove_between(s, "pub fn search_source_sha256(", "pub fn file_sha256(")
s = s.replace(
    '        "schema":arena::SCHEMA,"schema_sources_sha256":arena::json_digest(&serde_json::json!({\n            "arena":arena::digest(include_bytes!("arena.rs")),"clock":arena::digest(include_bytes!("arena_clock.rs")),\n            "statistics":arena::digest(include_bytes!("arena_statistics.rs")),"runtime":arena::digest(include_bytes!("runtime.rs"))}))?,',
    '        "schema":arena::SCHEMA,',
)
s = s.replace('"compiled_sources":source_bindings(),', "")
a = s.index('                    .map(|e| {\n                        binding["compiled_sources"]')
b = s.index("                    .collect::<std::result::Result<Vec<_>, _>>()?,", a)
s = (
    s[:a]
    + """                    .map(|_| {
                        binding["executable_sha256"].as_str().map(str::to_owned)
                            .ok_or("search artifact identity")
                    })
"""
    + s[b:]
)
write(p, s)
replace(
    "crates/quoridor-runner/src/lib.rs",
    "pub use arena_manifest::source_bindings as compiled_source_bindings;\n",
    "",
)
p = "crates/quoridor-data/src/bin/terminal-cache.rs"
s = read(p).replace("use sha2::{Digest, Sha256};\n", "")
s = remove_between(
    s, '    if args.as_slice() == ["research-bindings"] {', '    if args.as_slice() == ["--help"] {'
)
s = s[: s.index("\nfn compiled_sources()")] + "\n"
write(p, s)
# Current native admissions have one real image identity. Their backend/model/config/expiry gates remain.
p = "crates/quoridor-runner/src/sigma_qualification.rs"
s = remove_between(read(p), "pub fn sources()", "fn sha(")
s = s.replace("    pub compiled_sources_sha256: String,\n", "").replace(
    "            &self.compiled_sources_sha256,\n", ""
)
s = s.replace(
    "            || self.compiled_sources_sha256 != crate::arena::json_digest(&sources())?\n", ""
)
s = s.replace("source/executable mismatch", "executable mismatch")
s = s.replace(
    "            compiled_sources_sha256: self.native.compiled_sources_sha256.clone(),\n", ""
)
s = s.replace('            compiled_sources_sha256: "a".repeat(64),\n', "")
s = s.replace(
    '        "compiled_sources":sources(),"compiled_sources_sha256":crate::arena::json_digest(&sources())?,\n',
    "",
)
s = s.replace("search_source_sha256", "search_artifact_sha256")
write(p, s)
p = "crates/quoridor-runner/src/runtime.rs"
s = read(p).replace("    pub compiled_sources_sha256: String,\n", "")
s = s.replace(
    "            || self.compiled_sources_sha256\n                != crate::arena::json_digest(&crate::sigma_qualification::sources())?\n",
    "",
)
s = s.replace(
    "            || q.compiled_sources_sha256\n                != crate::arena::json_digest(&crate::sigma_qualification::sources())?\n",
    "",
)
s = s.replace(
    ".map(|e| crate::arena_manifest::search_source_sha256(&e.kind))",
    ".map(|_| crate::arena_manifest::file_sha256(&std::env::current_exe()?))",
)
# The actual-image digest is fallible, unlike the obsolete include_bytes digest.
s = s.replace(
    ".map(|_| crate::arena_manifest::file_sha256(&std::env::current_exe()?))\n                .collect::<Vec<_>>()",
    ".map(|_| crate::arena_manifest::file_sha256(&std::env::current_exe()?))\n                .collect::<Result<Vec<_>>>()?",
)
write(p, s)
p = "crates/quoridor-runner/src/arena.rs"
s = (
    read(p)
    .replace("search_source_sha256", "search_artifact_sha256")
    .replace("search_sources", "search_artifacts")
)
s = s.replace("compiled search binding mismatch", "search artifact binding mismatch")
s = s.replace('                compiled_sources_sha256: "a".repeat(64),\n', "")
write(p, s)
p = "crates/quoridor-runner/src/native_input.rs"
s = read(p).replace('"compiled_sources":quoridor_runner::compiled_source_bindings(),', "")
write(p, s)
p = "crates/quoridor-runner/src/bin/nnue-diagnose.rs"
s = read(p).replace(
    '            v["compiled_sources"] =\n                serde_json::to_value(quoridor_runner::compiled_source_bindings())?;\n',
    "",
)
write(p, s)
# Saved book provenance is data, not a certificate requiring today's source tree to match its producer.
p = "crates/quoridor-runner/src/value_search_strength.rs"
s = read(p).replace('"compiled_sources":crate::compiled_source_bindings(),', "")
s = s.replace(
    "    pub compiled_sources: std::collections::BTreeMap<String, String>,",
    """    // Opaque historical producer provenance in immutable saved books; never a current source inventory.
    #[serde(default, skip_serializing_if = "std::collections::BTreeMap::is_empty")]
    pub compiled_sources: std::collections::BTreeMap<String, String>,""",
)
a = s.index("        compiled_sources: crate::compiled_source_bindings()")
b = s.index("\n", s.index("            .collect(),", a)) + 1
s = s[:a] + "        compiled_sources: Default::default(),\n" + s[b:]
a = s.index("        || book.compiled_sources\n")
b = s.index("\n    {", a)
s = s[:a] + s[b:]
write(p, s)
p = "crates/quoridor-runner/src/value_search_compare.rs"
s = read(p).replace('        || !book_sources_match(&book["compiled_sources"])?\n', "")
s = s.replace("complete/current-source generated book", "complete bound generated book")
s = remove_between(s, "fn book_sources_match(", "fn replay_family(")
s = remove_between(s, "fn sources()", "fn accepted_manifest_identity(")
a = s.index('    if qualified_input["generation_compiled_sources_sha256"]')
b = s.index("    let header =", a)
s = s[:a] + s[b:]
s = s.replace('"compiled_sources":sources(),', "")
write(p, s)
# Pilot output keeps historic header maps as opaque source evidence only; no new inventories are emitted.
p = "crates/quoridor-runner/src/teacher_pilot_execution.rs"
s = read(p).replace(
    "    pub compiled_sources: BTreeMap<String, String>,",
    """    // Historical stream provenance retained for exact reconstruction, not checked against current compiler sources.
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub compiled_sources: BTreeMap<String, String>,""",
)
s = remove_between(s, "pub fn compiled_sources()", "fn stream_reader(")
s = s.replace(
    '        || q["generator_compiled_sources_sha256"] != crate::arena::json_digest(&compiled_sources())?\n',
    "",
)
s = s.replace(
    '    let build: Value = e.build_manifest.read()?;\n    if build["generator_compiled_sources"] != serde_json::to_value(compiled_sources())? {\n        return Err("qualified current generator source closure required".into());\n    }\n',
    "",
)
s = s.replace("compiled_sources: compiled_sources(),", "compiled_sources: BTreeMap::new(),")
write(p, s)
p = "crates/quoridor-runner/src/teacher_pilot_execution/depth6.rs"
s = read(p).replace("compiled_sources: compiled_sources(),", "compiled_sources: BTreeMap::new(),")
s = s.replace(',"compiled_sources":header.compiled_sources', "")
write(p, s)
