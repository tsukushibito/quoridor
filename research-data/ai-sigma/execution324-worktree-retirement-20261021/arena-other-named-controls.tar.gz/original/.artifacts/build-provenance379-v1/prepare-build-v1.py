"""Materialize one current379 normal BUILD; no compiler or assertion execution here."""

import importlib.util
import json
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/build-provenance379-v1"
PHASE = OWN / "software-build-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


adoption = ref(MAIN / "research-data/ai-sigma/build-provenance379/source-adoption-v1.json")
lc.require(
    adoption["sha256"] == "5a2872839ea77d610bb8e9696f15a2fe82a1a463c828f5302702abeddc0a5dd3",
    "current Source",
)
source = lc.document(adoption)["source"]
handover_ref = ref(
    MAIN / ".artifacts/research-team/integration324/379-main-adoption-v1/target-handover.json"
)
lc.require(
    handover_ref["sha256"] == "cb0f1b37afbc52af9ec80781a16c8c6c64e7606143580ef96ae4f82aac585c6d",
    "current custody",
)
handover = lc.document(handover_ref)
support = handover["support"]
lc.document(support)
prior = json.loads(
    (
        MAIN
        / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1/software-build-v4/intent.json"
    ).read_bytes()
)
tools = prior["tools"]
env = {**prior["env"], "TMPDIR": str(PHASE / "TMP-v1")}
limits = {
    "family_B": 3 * 1024**3,
    "controller_B": 64 * 1024**2,
    "host_reserve_B": 4 * 1024**3,
    "owned_B": handover["target_max_B"] + handover["private_pool_B"] + 64 * 1024**2 + 8 * 1024**2,
    "log_B": 512 * 1024,
    "free_B": 4 * 1024**3,
    "worker_cpu": 1,
    "guardian_cpu": 3,
}
cargo = tools["CARGO"]["file"]["path"]
common = [
    "--offline",
    "--locked",
    "--manifest-path",
    source["manifest"]["path"],
    "-j1",
    "--message-format=json-render-diagnostics",
]
selected = {
    "runner": "research_manifest::build379_provenance_tests::build379_retained_input_scope_never_relabels_original_image",
    "data": "terminal_stream::stream_repair_tests::build379_reference_policy_binds_artifact_and_only_schedule_changes",
}
commands = [
    {
        "name": "test-runner-build379",
        "role": "test",
        "argv": [
            cargo,
            "test",
            *common,
            "-p",
            "quoridor-runner",
            "--lib",
            "--features",
            "ordering-assessment",
            selected["runner"],
            "--",
            "--exact",
            "--test-threads=1",
        ],
    },
    {
        "name": "test-data-build379",
        "role": "test",
        "argv": [
            cargo,
            "test",
            *common,
            "-p",
            "quoridor-data",
            "--lib",
            selected["data"],
            "--",
            "--exact",
            "--test-threads=1",
        ],
    },
    {
        "name": "clippy-build379",
        "role": "lint",
        "argv": [
            cargo,
            "clippy",
            *common,
            "--keep-going",
            "-p",
            "quoridor-ai",
            "-p",
            "quoridor-data",
            "-p",
            "quoridor-inference",
            "-p",
            "quoridor-nnue",
            "-p",
            "quoridor-runner",
            "--lib",
            "--bin",
            "quoridor-runner",
            "--tests",
            "--features",
            "quoridor-runner/ordering-assessment",
            "--no-deps",
            "--",
            "-Dwarnings",
        ],
    },
    {
        "name": "release-build379",
        "role": "build",
        "argv": [
            cargo,
            "build",
            *common,
            "--release",
            "-p",
            "quoridor-runner",
            "--bin",
            "quoridor-runner",
            "--features",
            "ordering-assessment",
        ],
    },
]
lc.require(
    commands[-1]["argv"] == next(c["argv"] for c in prior["commands"] if c["role"] == "build"),
    "unchanged admitted release argv",
)
spec = {
    "schema": "quoridor.research.lifecycle-intent.v1",
    "kind": "build",
    "owner": str(MAIN / ".worktree"),
    "writer": "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0",
    "cwd": str(MAIN),
    "output": str(PHASE / "operation-v1"),
    "env": env,
    "limits": limits,
    "support": support,
    "source_adoption": adoption,
    "target_handover": handover_ref,
    "source": source,
    "tools": tools,
    "target": handover["target"],
    "private": handover["candidate"],
    "TMP": str(PHASE / "TMP-v1"),
    "commands": commands,
    "finalizers": [],
    "artifact_target": "quoridor-runner",
}
lc.physical_and_quiet(spec)
with lc.lease():
    lc.require(not PHASE.exists(), "exclusive379 phase")
    lc.build_check(spec)
    for tool in tools.values():
        lc.read_ref(tool["file"], max(lc.CONTROL_BYTES, tool["file"]["bytes"]))
    target_before = lc.allocated(spec["target"])
    lc.require(target_before <= handover["target_max_B"], "actual target cap")
    lc.require(
        lc.allocated(Path(spec["private"]).parent) <= handover["fresh_private_forward_max_B"],
        "private parent cap",
    )
    PHASE.mkdir()
    lc.new_json(
        PHASE / "preflight.json",
        {
            "at": lc.stamp(),
            "target_allocated_B": target_before,
            "target_cap_B": handover["target_max_B"],
            "retained_floor_B": handover["effective_retained_floor_B"],
            "private_allocated_B": lc.allocated(Path(spec["private"]).parent),
            "physical_available_B": lc.process.available_memory(),
            "FS_free_B": lc.shutil.disk_usage(spec["owner"]).free,
            "physical_namedquiet": "Maintained fresh guard passed, repeated at actual entry",
            "canonical_NB": "held during current Git/Cargo/tool/owner/cap checks, released on helper return",
            "source": adoption,
            "handover": handover_ref,
            "support": support,
            "expected_assertions": {name: 1 for name in selected.values()},
            "scope": "Two NN0 metadata assertions; no models/heads/library/geometry/Search/games",
        },
    )
    digest = lc.sha(json.dumps(spec, sort_keys=True, separators=(",", ":")).encode())
    spec["intent_sha256"] = digest
    lc.new_json(
        PHASE / "admission.json",
        {
            "schema": "quoridor.research.phase-admission.v1",
            "owner": spec["owner"],
            "limits": limits,
            "spec_sha256": digest,
            "support_sha256": support["sha256"],
            "ready": True,
            "current_global_held_B": 49996492800,
            "preflight": ref(PHASE / "preflight.json"),
        },
    )
    spec["admission"] = ref(PHASE / "admission.json")
    lc.new_json(PHASE / "intent.json", spec)
    intent = ref(PHASE / "intent.json")
    config = {
        "issue": "quoridor-4lc.379.1",
        "goal_issue": "quoridor-4lc.379",
        "thread_id": "01a11062-b120-73a1-8aa3-fe2cb922c7c0",
        "cwd": str(MAIN),
        "argv": [
            tools["PYTHON"]["file"]["path"],
            "-B",
            str(MAIN / "scripts/dev/research-lifecycle.py"),
            "build",
            "--intent",
            intent["path"],
            "--sha256",
            intent["sha256"],
        ],
        "end_at": None,
        "notify_until": None,
        "max_runtime_seconds": None,
        "control_interval_seconds": 30,
        "notify_interval_seconds": 10,
        "request_timeout_seconds": 25,
        "log_max_bytes": 65536,
        "resource_contract": support["path"],
    }
    lc.new_json(PHASE / "config.json", config)
    print(
        json.dumps(
            {
                "intent": intent,
                "config": ref(PHASE / "config.json"),
                "preflight": ref(PHASE / "preflight.json"),
                "STOP": lc.stamp(),
            }
        )
    )
