from prepare import read, write

p = "crates/quoridor-data/src/terminal_stream.rs"
s = read(p).replace(
    "    compiled_sources: BTreeMap<String, String>,",
    """    // Opaque provenance of immutable saved streams; Cargo owns current build dependencies.
    #[serde(default)]
    compiled_sources: BTreeMap<String, String>,""",
)
s = s.replace(
    '    if h.compiled_sources.is_empty() {\n        return Err("missing compiled source provenance".into());\n    }\n',
    "",
)
s = s.replace(
    '        || source["compiled_sources"]\n            .as_object()\n            .is_none_or(|m| m.is_empty() || m.keys().any(|k| k.contains("synthetic")))\n',
    "",
)
s = s.replace(
    '        || source["compiled_sources"] != serde_json::to_value(&header.compiled_sources)?',
    '        || source["executable_sha256"] != header.executable_sha256',
)
# Reference policy checks the real producer artifact; its bound historical source metadata stays unmodified.
s = s.replace(
    "stream_repair_reference_policy_exact_sources_and_only_schedule_changes",
    "build379_reference_policy_binds_artifact_and_only_schedule_changes",
)
s = s.replace(
    '"evaluator":EVALUATOR,"compiled_sources":',
    '"evaluator":EVALUATOR,"executable_sha256":"a".repeat(64),"compiled_sources":',
)
s = s.replace(
    '            executable_sha256: "control-only".into(),',
    '            executable_sha256: "a".repeat(64),',
)
s = s.replace(
    """        header
            .compiled_sources
            .insert("unexecuted-control-port".into(), "c".repeat(64));""",
    """        header.executable_sha256 = "c".repeat(64);""",
)
s = s.replace(
    """        header
            .compiled_sources
            .insert("unexecuted-control-port".into(), "b".repeat(64));""",
    """        header.executable_sha256 = "a".repeat(64);""",
)
write(p, s)
# Keep exact historical source metadata correspondence in the canonical stream source object.
p = "crates/quoridor-runner/src/teacher_pilot_execution/depth6.rs"
s = read(p).replace(
    '"executable_sha256":header.executable_sha256,',
    '"executable_sha256":header.executable_sha256,"compiled_sources":header.compiled_sources,',
)
write(p, s)
p = "python/quoridor_training/distance_steps.py"
s = read(p).replace('        source = header.get("compiled_sources")\n', "")
s = s.replace(
    '            or not isinstance(source, dict)\n            or not source\n            or any("synthetic" in key for key in source)\n',
    "",
)
write(p, s)
p = "python/quoridor_training/research355/lifecycle355.py"
s = read(p).replace('        compiled_digest(value["compiled_sources"])\n', "")
a = s.index("def generation_sources(")
b = s.index("def models(", a)
s = s[:a] + s[b:]
s = s.replace(
    '        "compiled_sources_sha256": compiled_digest(build["compiled_sources"]),\n', ""
)
# Delete the now unused source-inventory digest; actual file digests remain.
if s.count("compiled_digest(") == 1:
    a = s.index("def compiled_digest(")
    b = s.index("\ndef ", a + 5)
    s = s[:a] + s[b + 1 :]
write(p, s)
p = "python/quoridor_training/research355/stream355.py"
s = read(p).replace(
    '    life.generation_sources(raw_book["compiled_sources"], build["compiled_sources"])\n', ""
)
write(p, s)
p = "crates/quoridor-runner/src/value_search_compare.rs"
s = read(p).replace(
    'let (experiment, qualified_input) = crate::research_manifest::load(bound, "compare")?;',
    'let (experiment, _) = crate::research_manifest::load(bound, "compare")?;',
)
write(p, s)
