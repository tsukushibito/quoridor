import ast
from prepare import read, write, remove_between

p = "scripts/dev/research-lifecycle.py"
s = read(p)


def function(name, body):
    global s
    tree = ast.parse(s)
    n = next(
        n
        for n in tree.body
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name
    )
    lines = s.splitlines(keepends=True)
    s = "".join(lines[: n.lineno - 1]) + body.rstrip() + "\n" + "".join(lines[n.end_lineno :])


function(
    "source_metadata_check",
    '''def source_metadata_check(source):
    """Git/Cargo provenance, not an independently maintained Rust dependency graph."""
    require(set(source) == {"workspace", "commit", "patch", "untracked_inputs", "manifest", "lock", "cargo_configs"}, "Git/Cargo source record")
    require(len(source["commit"]) == 40 and all(c in "0123456789abcdef" for c in source["commit"]), "Git revision")
    workspace = Path(source["workspace"])
    require(workspace.is_absolute(), "adopted workspace")
    for name, filename in (("manifest", "Cargo.toml"), ("lock", "Cargo.lock")):
        require(source[name]["path"] == str(workspace / filename), "adopted Cargo " + name)
    untracked = source["untracked_inputs"]
    require(type(untracked) is list and len({r["path"] for r in untracked}) == len(untracked), "unique used untracked inputs")
    require(all(Path(r["path"]).is_relative_to(workspace) for r in untracked), "untracked input outside workspace")
    for item in source["cargo_configs"]:
        if item["file"] is not None:
            require(item["file"]["path"] == item["path"], "Cargo config identity")''',
)
function(
    "source_check",
    '''def source_check(source):
    """BUILD owns a standard Git revision/delta and actual Cargo inputs.

    Cargo/rustc own source dependency discovery. RUN does not inspect current Rust.
    """
    source_metadata_check(source)
    workspace = Path(source["workspace"])
    require(workspace.resolve() == workspace, "adopted workspace")
    def git(*args):
        completed = subprocess.run(["git", "--no-optional-locks", "-C", str(workspace), *args],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15, check=True)
        require(len(completed.stdout) <= CONTROL_BYTES, "bounded Git provenance")
        return completed.stdout
    require(git("rev-parse", "HEAD").decode().strip() == source["commit"], "Git revision drift")
    patch = b"" if source["patch"] is None else read_ref(source["patch"])
    require(git("diff", "--binary", "--no-ext-diff", "HEAD", "--") == patch, "actual uncommitted Git delta drift")
    untracked = git("ls-files", "--others", "--exclude-standard", "-z", "--", "Cargo.toml", "Cargo.lock", ".cargo", "crates")
    paths = {str(workspace / os.fsdecode(p)) for p in untracked.split(b"\\0") if p}
    require(paths == {r["path"] for r in source["untracked_inputs"]}, "used untracked Cargo inputs drift")
    for ref in [source["manifest"], source["lock"], *source["untracked_inputs"]]:
        read_ref(ref, max(CONTROL_BYTES, ref["bytes"]))
    for item in source["cargo_configs"]:
        path = Path(item["path"])
        if item["file"] is None:
            require(not path.exists() and not path.is_symlink(), "Cargo config appeared")
        else:
            read_ref(item["file"])''',
)
# Preserve the owning retained numerical exception at normal accepted Source. It does not reconstruct a second source graph.
old = s[
    s.index("def retained_ordering_source(") : s.index(
        "\ndef ", s.index("def retained_ordering_source(") + 5
    )
]
a = old.index("    changed = reuse[")
b = old.index('    require(\n        [c["argv"]', a)
head = """    require(
        adoption["schema"] == "quoridor.research.source-adoption.v1"
        and adoption["status"] == "ACCEPTED"
        and adoption["source"] == current["source"]
        and reuse["scope"] == "ordering20-input-and-head-v1"
        and reuse["qualification"] == qualification
        and reuse["build_manifest"] == original_ref
        and (cheap is None or reuse["cheap_static376"] == cheap)
        and original["schema"] == BUILD_SCHEMA and original["status"] == "PASS"
        and original["cleanup_complete"] is True and original["remaining"] == []
        and original["source"]["workspace"] == current["source"]["workspace"]
        and original["tools"] == current["tools"],
        "ordering retained numerical adoption/subject mismatch",
    )
    require({"test", "lint", "build"} <= {c["role"] for c in original["checks"]
        if c["guardian_return"]["exit_code"] == 0 and c["guardian_return"]["cleanup_complete"] is True},
        "ordering original build software incomplete")
"""
old = old[:a] + head + old[b:]
a = old.index("    for key, pair in changed.items():")
old = old[:a]
function("retained_ordering_source", old)
s = s.replace(
    '        "compiled_sources_sha256": canonical_sha(manifest["compiled_sources"]),\n', ""
)
s = s.replace(
    '        {r["role"] for r in manifest["checks"]} >= {"test", "lint", "build", "bindings"},',
    '        {r["role"] for r in manifest["checks"]} >= {"test", "lint", "build"},',
)
s = s.replace("affected test/lint/build/bindings required", "affected test/lint/build required")
a = s.index('    require(\n        manifest["compiled_sources"]', s.index("def accepted_build("))
b = s.index("    for tool ", a)
s = s[:a] + s[b:]
# Admission preserves complete current native artifact/backend/config/expiry, not a compiled source inventory.
a = s.index('        and config["native"]["compiled_sources_sha256"]')
b = s.index('        "current approved cases/', a)
s = s[:a] + ",\n" + s[b:]
s = s.replace(
    "current approved cases/formula/actual native qualification source/image",
    "current approved cases/formula/actual native qualification image",
)
# Generator qualification already binds actual artifact plus all ordered science fields.
a = s.index('        require(\n            q["generator_compiled_sources_sha256"]')
b = s.index("\n        ", s.index("        )", a) + 10)
# exact full call via AST source segment, no guessed indentation span
lines = s.splitlines(keepends=True)
for n in ast.walk(ast.parse(s)):
    if (
        isinstance(n, ast.Expr)
        and isinstance(n.value, ast.Call)
        and 'q["generator_compiled_sources_sha256"]' in ast.get_source_segment(s, n)
    ):
        s = "".join(lines[: n.lineno - 1]) + "".join(lines[n.end_lineno :])
        break
# Converter selection is Cargo package/bin authority, not a manually declared source inventory.
a = s.index("        converter = str(", s.index("def build_check("))
b = s.index('        for row in spec["commands"]:', a)
s = s[:a] + s[b:]
s = s.replace(
    '    require(bool(source["compiled_sources"]), "adopted compiled-source projection required")\n',
    "",
)
s = s.replace('{"test", "lint", "build", "bindings"}', '{"test", "lint", "build"}')
s = s.replace('        if c["role"] != "bindings":\n', "")
# Dedent former Cargo-only body now every permitted command is Cargo.
a = s.index('    for c in spec["commands"]:', s.index("def build_check("))
b = s.index("\n\ndef private_copy_check", a)
block = s[a:b].splitlines(True)
# lines beginning 12spaces beneath removed if get one indentation level removed; nested lines too
block = [line[4:] if line.startswith("            ") else line for line in block]
s = s[:a] + "".join(block) + s[b:]
# Delete every graph/domain builder rather than maintaining aliases.
s = remove_between(s, "GENERATION_SOURCE_KEYS =", "def generation_evidence(")
a = s.index("    generation_source_correspondence(", s.index("def generation_evidence("))
b = s.index("    evidence = {", a)
s = s[:a] + s[b:]
a = s.index(
    '        "compiled_sources": build["compiled_sources"]', s.index("def generation_evidence(")
)
b = s.index('        "book_sha256":', a)
s = s[:a] + s[b:]
s = s.replace("search_source_sha256", "search_artifact_sha256")
# Arena durable/current image identity already matched immediately above; retire redundant source loop.
a = s.index('        for key, digest in manifest["binding"]["compiled_sources"].items():')
b = s.index("\n", s.index("            )", a)) + 1
s = s[:a] + s[b:]
# Standard BUILD witnesses read during the actual owning lifetime.
s = s.replace(
    '                        *spec["source"]["files"],',
    '                        spec["source"]["manifest"], spec["source"]["lock"],\n                        *spec["source"]["untracked_inputs"],',
)
a = s.index(
    '                        if row["role"] == "bindings":',
    s.index('                    for row in spec["commands"]:'),
)
b = s.index('                        result["active_command"] = row', a)
s = s[:a] + s[b:]
a = s.index('                        if row["role"] == "bindings":', a)
b = s.index("                            cargo = cargo_report(", a)
s = s[:a] + s[b:]
# former else body one indent shallower, preserving exact copy/custody checks
b = s.index('                        result["active_command"] = None', a)
s = (
    s[:a]
    + "".join(
        line[4:] if line.startswith("                            ") else line
        for line in s[a:b].splitlines(True)
    )
    + s[b:]
)
s = s.replace('candidate is not None and result.get("compiled_sources")', "candidate is not None")
s = s.replace("actual artifact/bindings required", "actual Cargo artifact required")
s = s.replace(
    '                                candidate = copy_artifact(src, spec["private"])',
    '                                candidate = copy_artifact(src, spec["private"])',
)
# Capture native Cargo identity as the authoritative compiler output, not a native echo command.
s = s.replace(
    '                            candidate = copy_artifact(src, spec["private"])',
    '                            result["cargo_artifact"] = matches[0]\n                            candidate = copy_artifact(src, spec["private"])',
)
a = s.index(
    "            expected = {",
    s.index('    if candidate["kind"] == "build" and candidate.get("artifact")'),
)
b = s.index("        except BaseException as error:", a)
s = (
    s[:a]
    + """            spec = document(candidate["intent"])
            require(candidate["source"] == spec["source"], "final adopted Git/Cargo record")
            require(candidate["tools"] == spec["tools"] and candidate["env"] == spec["env"], "final build tool/environment identity")
            builds = [c for c in candidate["checks"] if c["role"] == "build"]
            require(len(builds) == 1, "one actual build command")
            cargo = cargo_report(read_ref(builds[0]["full_log"]))
            artifacts = [a for a in cargo["artifacts"] if a["target"]["name"] == candidate["artifact_target"]
                and a["target"]["kind"] == ["bin"] and a["profile"]["test"] is False]
            require(artifacts == [candidate["cargo_artifact"]], "actual Cargo artifact receipt")
            emitted = owned(artifacts[0]["executable"], spec["target"])
            require(bound(emitted, 32 * 1024 * 1024)[0]["sha256"] == candidate["artifact"]["sha256"], "Cargo/private artifact drift")
            require({"test", "lint", "build"} <= {c["role"] for c in candidate["checks"]
                if c["status"] == "PASS" and c["capture_complete"] is True
                and c["guardian_return"]["exit_code"] == 0 and c["guardian_return"]["cleanup_complete"] is True},
                "actual completed software checks")
"""
    + s[b:]
)
# Every after-command BUILD lifetime still checks standard Git revision/delta and actual Cargo controls.
write(p, s)
ast.parse(s)
