from prepare import read, write, remove_between

p = "crates/quoridor-runner/src/main.rs"
s = remove_between(
    read(p), '        "research-bindings" => {', '        "strength-book" | "strength-configs" => {'
)
s = s.replace(
    '                        "compiled_sources":quoridor_runner::teacher_pilot_execution::compiled_sources(),\n',
    "",
)
write(p, s)
p = "crates/quoridor-runner/src/ordering_assessment.rs"
s = (
    read(p)
    .replace('"compiled_sources_sha256":arena::json_digest(&research_manifest::sources())?,', "")
    .replace('"compiled_sources":research_manifest::sources(),', "")
)
write(p, s)
p = "crates/quoridor-runner/src/research_manifest.rs"
s = read(p)
s = remove_between(
    s,
    '#[cfg(all(test, feature = "ordering-assessment"))]\nmod ordering368_source_tests {',
    "#[cfg(test)]\nmod common_corpus_phase_tests {",
)
s = s.replace('(["test","lint","build","bindings"].map', '(["test","lint","build"].map')
# Replace obsolete source-graph tests with the owning exact normal adoption/original numerical subject boundary.
s += """
#[cfg(all(test, feature = "ordering-assessment"))]
mod build379_provenance_tests {
    use super::*;
    #[test]
    fn build379_retained_input_scope_never_relabels_original_image() {
        let make = |commit: &str, artifact: &str| json!({
            "schema":"quoridor.research.build-manifest.v1","status":"PASS",
            "cleanup_complete":true,"remaining":[],
            "checks":(["test","lint","build"].map(|r|json!({"role":r,"argv":["cargo",r],
                "guardian_return":{"exit_code":0,"cleanup_complete":true}}))),
            "artifact":{"sha256":artifact.repeat(64)},
            "source":{"workspace":"/synthetic379","commit":commit.repeat(40),"patch":null,
                "manifest":{"sha256":"1".repeat(64)},"lock":{"sha256":"2".repeat(64)},"cargo_configs":[]},
            "tools":{"RUSTC":"unchanged"},"env":{"RUSTFLAGS":"unchanged","TMPDIR":commit}
        });
        let original=make("a","3");
        let current=make("b","4");
        let reference=|name:&str| FileRef {path:format!("/synthetic379/{name}/manifest.json").into(),
            sha256:"5".repeat(64),bytes:1,mode:"0644".into()};
        let qualification=reference("qualification");
        let original_ref=reference("original");
        let adoption=json!({"schema":"quoridor.research.source-adoption.v1","status":"ACCEPTED",
            "source":current["source"],"retained_ordering_numerical":{
                "scope":"ordering20-input-and-head-v1","qualification":qualification,"build_manifest":original_ref}});
        retained_ordering_source(&current,&original,&adoption,&qualification,&original_ref,None).unwrap();
        assert_ne!(original["artifact"],current["artifact"]);
        for key in ["scope","qualification","build_manifest"] {
            let mut bad=adoption.clone();
            bad["retained_ordering_numerical"].as_object_mut().unwrap().remove(key);
            assert!(retained_ordering_source(&current,&original,&bad,&qualification,&original_ref,None).is_err());
        }
        for (key,value) in [("status",json!("FAILED")),("source",json!({"commit":"wrong"}))] {
            let mut bad=adoption.clone();bad[key]=value;
            assert!(retained_ordering_source(&current,&original,&bad,&qualification,&original_ref,None).is_err());
        }
        for key in ["tools","env"] {
            let mut bad=current.clone();bad[key]=json!({"drift":true});
            assert!(retained_ordering_source(&bad,&original,&adoption,&qualification,&original_ref,None).is_err());
        }
        let unchanged=original.clone();
        assert_eq!(original,unchanged);
    }
}
"""
write(p, s)
p = "scripts/dev/research-lifecycle.py"
s = read(p)
s = s.replace(
    'git("diff", "--binary", "--no-ext-diff", "HEAD", "--")',
    'git("diff", "--binary", "--no-ext-diff", "--no-textconv", "HEAD", "--")',
)
s = s.replace(
    '''                for ref in refs:
                    read_ref(ref, max(CONTROL_BYTES, ref["bytes"]))
                result["status"] = "PENDING_FINALIZATION"''',
    '''                for ref in refs:
                    read_ref(ref, max(CONTROL_BYTES, ref["bytes"]))
                if spec["kind"] == "build":
                    source_check(spec["source"])
                result["status"] = "PENDING_FINALIZATION"''',
)
write(p, s)
