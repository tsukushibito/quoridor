"""One-off source packet proof. Does not run production code or scientific inputs."""

from pathlib import Path
import ast
import datetime
import difflib
import gzip
import hashlib
import json
import os
import stat
import subprocess
import tempfile

ROOT = Path("/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/build-provenance379-v1")
MAIN = Path("/workspaces/quoridor")


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


before = json.loads((ROOT / "before-map.json").read_bytes())
patch = []
post = {}
function_proof = {}
for relative, previous in before.items():
    target = ROOT / "postimages" / relative
    new = target.read_bytes()
    if previous is None:
        assert not os.path.lexists(MAIN / relative)
        old = b""
    else:
        old = gzip.decompress((ROOT / "minimum-before" / (relative + ".gz")).read_bytes())
        assert (
            hashlib.sha256(old).hexdigest() == previous["sha256"] and len(old) == previous["bytes"]
        )
        actual = ref(MAIN / relative)
        assert actual == previous, relative
    assert old != new, relative
    post[relative] = ref(target)
    patch += difflib.unified_diff(
        old.decode().splitlines(True),
        new.decode().splitlines(True),
        fromfile="/dev/null" if previous is None else "a/" + relative,
        tofile="b/" + relative,
        n=3,
    )
    if relative.endswith(".py") and old:

        def functions(raw):
            tree = ast.parse(raw)
            return {
                n.name: ast.dump(n, include_attributes=False)
                for n in tree.body
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
            }

        a, b = functions(old), functions(new)
        function_proof[relative] = {
            "unchanged": [k for k in a if k in b and a[k] == b[k]],
            "changed": [k for k in a if k in b and a[k] != b[k]],
            "removed": [k for k in a if k not in b],
            "added": [k for k in b if k not in a],
        }
patch_bytes = "".join(patch).encode()
(ROOT / "changes-v2.patch").write_bytes(patch_bytes)
(ROOT / "changes-v2.patch.gz").write_bytes(gzip.compress(patch_bytes, mtime=0))
assert gzip.decompress((ROOT / "changes-v2.patch.gz").read_bytes()) == patch_bytes
# Temporary reconstruction is explicitly serial source verification TMP, never retained code mirror.
with tempfile.TemporaryDirectory(prefix="strict-source-proof-", dir=ROOT) as directory:
    temp = Path(directory)
    for relative, previous in before.items():
        if previous is None:
            continue
        path = temp / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(
            gzip.decompress((ROOT / "minimum-before" / (relative + ".gz")).read_bytes())
        )
        path.chmod(int(previous["mode"], 8))
    outcomes = []
    for reverse in (False, True):
        argv = [
            "patch",
            "--batch",
            "--fuzz=0",
            "--no-backup-if-mismatch",
            "-p1",
            "-i",
            str(ROOT / "changes-v2.patch"),
        ]
        if reverse:
            argv.insert(1, "-R")
        result = subprocess.run(argv, cwd=temp, capture_output=True, text=True, timeout=30)
        assert result.returncode == 0, result.stdout + result.stderr
        assert (
            "offset" not in result.stdout
            and "fuzz" not in result.stdout
            and "FAILED" not in result.stdout
        )
        for relative, previous in before.items():
            path = temp / relative
            if reverse and previous is None:
                assert not path.exists()
                continue
            expected = (
                gzip.decompress((ROOT / "minimum-before" / (relative + ".gz")).read_bytes())
                if reverse
                else (ROOT / "postimages" / relative).read_bytes()
            )
            assert path.read_bytes() == expected, (relative, reverse)
        outcomes.append(
            {
                "operation": "inverse" if reverse else "forward",
                "exit_code": result.returncode,
                "zero_fuzz": True,
                "zero_offset": True,
                "all_bytes_exact": True,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
        )
assert not list(ROOT.glob("strict-source-proof-*"))
# No 379 derivative edits a reviewed AI kernel/history/NNUE/core body.
assert not any(
    relative.startswith(("crates/quoridor-ai/", "crates/quoridor-core/", "crates/quoridor-nnue/"))
    for relative in post
)
producer = (ROOT / "postimages/crates/quoridor-runner/src/teacher_pilot_execution.rs").read_text()
assert "pub fn compiled_sources()" not in producer
publisher = (ROOT / "postimages/scripts/dev/research-lifecycle.py").read_text()
assert "GENERATION_SOURCE_KEYS" not in publisher and "compiled_sources" not in publisher
assert (
    'candidate["status"] = "FAILED" if candidate["primary"] or candidate["secondary"] else "PASS"'
    in publisher
)
assert not any(
    "include_bytes!" in (ROOT / "postimages" / r).read_text() for r in post if r.endswith(".rs")
)
records = {
    "scope": "static source reconstruction/AST only; no production imports, assertions, Cargo or model/native/library/science calls",
    "current376_beforeimage_refs": {
        r: before[r]
        for r in (
            "crates/quoridor-runner/src/main.rs",
            "crates/quoridor-runner/src/research_manifest.rs",
            "scripts/dev/research-lifecycle.py",
            "crates/quoridor-runner/src/ordering_assessment.rs",
        )
    },
    "before_gzip_exact": True,
    "patch_gzip_exact": True,
    "strict_forward_inverse": outcomes,
    "temporary_reconstruction_cleanup": True,
    "no_AI_core_NNUE_derivative": True,
    "Python_module_function_AST": function_proof,
    "original_errors_cleanup_marker_last_preserved": "unchanged finalizer/error/data funnels outside retired inventory checks; inspect changed execute/finalize joins",
    "postimages": post,
    "static_proof_STOP_UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(ROOT / "source-proof-v2.json").write_text(json.dumps(records, indent=2) + "\n")
print(
    json.dumps(
        {
            "files": len(post),
            "patch_bytes": len(patch_bytes),
            "patch_gzip_bytes": (ROOT / "changes-v2.patch.gz").stat().st_size,
            "publisher_changed_functions": function_proof["scripts/dev/research-lifecycle.py"][
                "changed"
            ],
            "publisher_removed_functions": function_proof["scripts/dev/research-lifecycle.py"][
                "removed"
            ],
            "publisher_unchanged_functions": len(
                function_proof["scripts/dev/research-lifecycle.py"]["unchanged"]
            ),
            "strict_forward_inverse": "PASS static only",
            "STOP": records["static_proof_STOP_UTC"],
        },
        indent=2,
    )
)
