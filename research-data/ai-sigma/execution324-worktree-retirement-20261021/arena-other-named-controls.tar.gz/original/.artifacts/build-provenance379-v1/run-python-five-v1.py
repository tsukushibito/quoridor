"""Run five current379 NN0 methods with existing common-entry and software guardian."""

import importlib.util
import json
import os
import re
import stat
import time
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/build-provenance379-v1"
OUT = OWN / "python-software-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
methods = [
    "test_build379_standard_git_revision_delta_and_untracked_input",
    "test_build379_cargo_receipt_single_image_and_normal_owning_completion",
    "test_build379_artifact_or_returned_capture_drift_cannot_complete",
    "test_build379_private_artifact_drift_is_failed_not_reused",
    "test_build379_obsolete_inventory_and_echo_role_refuse_before_child",
]
test = MAIN / "tools/research-session/test_build_provenance.py"
limits = {
    "family_B": 3 * 1024**3,
    "controller_B": 64 * 1024**2,
    "host_reserve_B": 4 * 1024**3,
    "worker_cpu": 1,
    "guardian_cpu": 3,
    "log_B": 512 * 1024,
}
spec = {
    "cwd": str(MAIN),
    "limits": limits,
    "env": {
        **os.environ,
        "TMPDIR": str(OUT / "TMP"),
        "PYTHONDONTWRITEBYTECODE": "1",
        "CUDA_VISIBLE_DEVICES": "",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
    },
}


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


adoption = ref(MAIN / "research-data/ai-sigma/build-provenance379/source-adoption-v4.json")
lc.require(
    adoption["sha256"] == "009f489be846281d41a7792e92e392deaf7e8585473872afa9256fa6ca646bc0",
    "actual current software metadata",
)
source = lc.document(adoption)["source"]
preprice = ref(OWN / "python-five-preprice-v1.json")
lc.document(preprice)
lc.physical_and_quiet(spec)
with lc.lease():
    lc.require(not OUT.exists(), "exclusive five-method output")
    lc.source_check(source)
    build_ref = ref(OWN / "software-build-v3/operation-v3/manifest.json")
    build = lc.accepted_build(build_ref)
    python = build["tools"]["PYTHON"]["file"]
    lc.read_ref(python, python["bytes"])
    paths = [
        test,
        MAIN / "tools/research-session/test_lifecycle.py",
        MAIN / "scripts/dev/research-lifecycle.py",
        MAIN / "scripts/dev/project-env.sh",
        MAIN / "python/quoridor_training/cycle_process.py",
        MAIN / "python/quoridor_training/snapshot.py",
        MAIN / "python/quoridor_training/__init__.py",
    ]
    refs = [ref(p) for p in paths]
    lc.require(lc.shutil.disk_usage(OWN).free >= 4 * 1024**3, "free filesystem reserve")
    OUT.mkdir()
    (OUT / "TMP").mkdir()
    argv = [
        "/bin/bash",
        str(MAIN / "scripts/dev/project-env.sh"),
        "python",
        "-B",
        str(test),
        *["BuildProvenanceTests." + m for m in methods],
        "-v",
    ]
    resources = lc.process.CycleResources(
        {
            "host_ram_reserve": limits["host_reserve_B"],
            "max_memory_bytes": limits["family_B"] - limits["controller_B"],
            "max_output_bytes": 2 * 1024**2,
        },
        OUT,
        time.monotonic() + 300,
    )
    checks, primary, secondary, cleanup = [], None, [], []
    started = lc.stamp()
    try:
        lc.command(
            spec,
            {"name": "python-five379", "role": "software", "argv": argv},
            OUT,
            resources,
            ledger=checks,
        )
        text = lc.read_ref(checks[0]["full_log"]).decode()
        lc.require(
            "Ran 5 tests" in text and "\nOK\n" in text and all(m in text for m in methods),
            "exact actual five-method assertion census",
        )
    except BaseException as error:
        primary = lc.error_fact(error)
    # Inspect only exact owned TMP children after directwait; do not hide unknown files.
    try:
        returned = checks[0]["guardian_return"]
        identity = (
            returned["child"]
            if returned is not None
            else lc.document(checks[0]["persisted_process_receipt"])["child"]
        )
        proc = Path("/proc") / str(identity["pid"]) / "stat"
        boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        current = (
            None
            if not proc.exists()
            else {
                "pid": identity["pid"],
                "start_ticks": proc.read_text().rsplit(")", 1)[1].split()[19],
                "boot_id": boot,
            }
        )
        lc.require(current != identity, "original child still present")
        for p in (OUT / "TMP").iterdir():
            before = p.lstat()
            lc.require(
                re.fullmatch(r"uv-[0-9a-f]+\.lock", p.name) is not None
                and stat.S_ISREG(before.st_mode)
                and before.st_size == 0,
                "unknown or nonempty TMP subject",
            )
            openers = []
            for proc_dir in Path("/proc").iterdir():
                if not proc_dir.name.isdigit():
                    continue
                try:
                    for fd in (proc_dir / "fd").iterdir():
                        try:
                            info = fd.stat()
                            if (info.st_dev, info.st_ino) == (before.st_dev, before.st_ino):
                                openers.append(str(fd))
                        except OSError:
                            pass
                except OSError:
                    pass
            lc.require(not openers, "owned TMP lock has open FD")
            facts = {
                "before": ref(p),
                "dev": before.st_dev,
                "ino": before.st_ino,
                "open_FDs": openers,
                "original_child": identity,
                "current_child": current,
            }
            after = p.lstat()
            lc.require(
                (after.st_dev, after.st_ino, after.st_size) == (before.st_dev, before.st_ino, 0),
                "TMP subject drift",
            )
            p.unlink()
            cleanup.append(facts)
        (OUT / "TMP").rmdir()
    except BaseException as error:
        secondary.append({"stage": "exact_owned_TMP_cleanup", **lc.error_fact(error)})
    for r in [*refs, build["artifact"], python]:
        try:
            lc.read_ref(r, max(lc.CONTROL_BYTES, r["bytes"]))
        except BaseException as error:
            secondary.append(
                {"stage": "current_source_artifact_python_after", **lc.error_fact(error)}
            )
    try:
        lc.source_check(source)
    except BaseException as error:
        secondary.append({"stage": "standard_Git_Cargo_metadata_after", **lc.error_fact(error)})
    source_STOP = lc.stamp()
lease_STOP = lc.stamp()
receipt = {
    "issue": "quoridor-4lc.379.1",
    "scope": "Five NN0 owning metadata methods, real standard Git fixtures only within OWN TMPDIR; Cargo/native/image/job/executor/physical ports synthetic",
    "status": "FAILED" if primary or secondary else "PASS",
    "build_manifest_original_Source3": build_ref,
    "current_software_Source4": adoption,
    "artifact": build["artifact"],
    "Python": python,
    "preprice": preprice,
    "methods": methods,
    "actual_source_refs_before_after": refs,
    "started_at": started,
    "checks": checks,
    "primary": primary,
    "secondary": secondary,
    "exact_TMP_cleanup": cleanup,
    "actual_source_caller_env_reader_STOP": source_STOP,
    "actual_canonical_release": lease_STOP,
    "owned_readers_children_jobs_TMP_remaining": []
    if not (OUT / "TMP").exists()
    else ["OWN TMP retained"],
    "reservation": None,
    "actual_native_model_library_Sigma_Search_games_entry": False,
    "old_receipts_rewritten": False,
    "child_worker_UTC_STOP": "UNKNOWN; directwait/source-reader STOP is independently recorded",
    "continuous_RAM_peak": "UNKNOWN",
}
lc.new_json(OUT / "receipt.json", receipt)
print(
    json.dumps(
        {
            "status": receipt["status"],
            "receipt": ref(OUT / "receipt.json"),
            "STOP": source_STOP,
            "release": lease_STOP,
        }
    )
)
if primary or secondary:
    raise SystemExit(1)
