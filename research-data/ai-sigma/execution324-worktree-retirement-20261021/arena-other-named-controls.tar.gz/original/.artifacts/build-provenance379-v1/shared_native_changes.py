from prepare import read, write, remove_between

p = "crates/quoridor-runner/src/research_manifest.rs"
s = read(p)
s = remove_between(s, "pub fn sources()", "fn build_status(")
s = s.replace('["test", "lint", "build", "bindings"]', '["test", "lint", "build"]')
s = s.replace('        || build["compiled_sources"] != serde_json::to_value(sources())?\n', "")
s = s.replace(
    '        || q["compiled_sources_sha256"] != arena::json_digest(&numerical_build["compiled_sources"])?\n',
    "",
)
a = s.index('    let changed = reuse["changed_compiled_sources"]')
b = s.index('    for field in ["manifest", "lock", "cargo_configs"]', a)
s = (
    s[:a]
    + """    if adoption["schema"] != "quoridor.research.source-adoption.v1"
        || adoption["status"] != "ACCEPTED"
        || adoption["source"] != current["source"]
        || reuse["scope"] != "ordering20-input-and-head-v1"
        || reuse["qualification"] != serde_json::to_value(qualification)?
        || reuse["build_manifest"] != serde_json::to_value(original_ref)?
        || cheap.is_some_and(|identity| reuse["cheap_static376"] != *identity)
        || !build_status(original)
        || original["source"]["workspace"] != current["source"]["workspace"]
        || original["tools"] != current["tools"]
    {
        return Err("ordering retained numerical adoption/subject mismatch".into());
    }
    // This exact accepted Source owns the independently reviewed input/head scope
    // correspondence. Cargo and its artifact record own the new image, not a
    // second embedded source graph. The ORIGINAL numerical artifact stays original.
"""
    + s[b:]
)
a = s.index("    for (key, pair) in changed {")
b = s.index("    Ok(())\n}", a)
s = s[:a] + s[b:]
# Delete inventory-only source-transfer test module; its mathematical/input tests are separate.
a = s.index("\n#[cfg(test)]\nmod ordering368_") if "\n#[cfg(test)]\nmod ordering368_" in s else -1
# Actual module names are inspected separately before retiring definitions.
s = s.replace(
    '"compiled_sources":sources(),"generator_compiled_sources":crate::teacher_pilot_execution::compiled_sources(),',
    "",
)
s = s.replace('"compiled_sources_sha256":arena::json_digest(&sources()).unwrap(),', "")
write(p, s)
p = "crates/quoridor-runner/src/main.rs"
s = read(p)
s = remove_between(s, '        "research-bindings" => {', '        "strength-book" => {')
s = s.replace(
    '                        "compiled_sources":quoridor_runner::teacher_pilot_execution::compiled_sources(),\n',
    "",
)
# Historical stream source record field remains opaque/empty, never populated by an inventory.
s = s.replace(
    '"executable_sha256":quoridor_runner::arena_manifest::file_sha256(&std::env::current_exe()?)?,',
    '"executable_sha256":quoridor_runner::arena_manifest::file_sha256(&std::env::current_exe()?)?,"compiled_sources":{},',
)
write(p, s)
p = "crates/quoridor-runner/src/ordering_assessment.rs"
s = read(p).replace(
    '"compiled_sources_sha256":arena::json_digest(&research_manifest::sources())?,', ""
)
s = s.replace('"compiled_sources":research_manifest::sources(),', "")
write(p, s)
