"""One-off owned patch preparation; never a production dependency inventory."""

from pathlib import Path
import gzip
import hashlib
import json
import stat

MAIN = Path("/workspaces/quoridor")
OWN = Path("/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/build-provenance379-v1")
MAP = OWN / "before-map.json"


def read(relative):
    p = OWN / "postimages" / relative
    return p.read_text() if p.exists() else (MAIN / relative).read_text()


def write(relative, text):
    source = MAIN / relative
    data = source.read_bytes() if source.exists() else None
    before = json.loads(MAP.read_text()) if MAP.exists() else {}
    if relative not in before:
        before[relative] = (
            None
            if data is None
            else {
                "path": str(source),
                "sha256": hashlib.sha256(data).hexdigest(),
                "bytes": len(data),
                "mode": format(stat.S_IMODE(source.stat().st_mode), "04o"),
            }
        )
        if data is not None:
            packed = OWN / "minimum-before" / (relative + ".gz")
            packed.parent.mkdir(parents=True, exist_ok=True)
            packed.write_bytes(gzip.compress(data, mtime=0))
        MAP.write_text(json.dumps(before, indent=2) + "\n")
    target = OWN / "postimages" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)


def remove_between(text, start, end):
    i = text.index(start)
    j = text.index(end, i)
    return text[:i] + text[j:]
