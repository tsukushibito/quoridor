from prepare import read, write, remove_between

for p in [
    "crates/quoridor-runner/tests/arena.rs",
    "crates/quoridor-runner/tests/fixtures/sigma-clock-config.json",
]:
    s = read(p).replace("search_source_sha256", "search_artifact_sha256")
    write(p, s)
p = "crates/quoridor-runner/tests/sigma_clock.rs"
s = read(p).replace("    let sources = quoridor_runner::compiled_source_bindings();\n", "")
s = s.replace("search_source_sha256", "search_artifact_sha256")
s = s.replace(
    'vec![sources["ai/sigma_mcts.rs"].clone(); 2]',
    "vec![quoridor_runner::arena_manifest::file_sha256(&std::env::current_exe().unwrap()).unwrap(); 2]",
)
s = s.replace(
    "        compiled_sources_sha256: quoridor_runner::arena::json_digest(&quoridor_runner::compiled_source_bindings()).unwrap(),\n",
    "",
)
s = s.replace("_ => q.compiled_sources_sha256 =", "_ => q.executable_sha256 =")
write(p, s)
p = "python/quoridor_training/research355/lifecycle355.py"
s = remove_between(read(p), "COMPILED_KEYS =", "RULES =")
write(p, s)
p = "python/quoridor_training/research355/test_lifecycle355.py"
s = read(p)
a = s.index("        self.compiled = {")
b = s.index("        experiment = {", a)
s = (
    s[:a]
    + """\n    def test_artifact_and_raw_ordered_numerical_arrays(self):
"""
    + s[b:]
)
s = s.replace('            "compiled_sources": self.compiled,\n', "").replace(
    '            "compiled_sources_sha256": expected,\n', ""
)
write(p, s)
p = "python/quoridor_training/research355/test_lifecycle_arena355.py"
s = read(p).replace(
    '            "compiled_sources_sha256": life.compiled_digest(f.compiled_hashes),\n', ""
)
write(p, s)
p = "python/quoridor_training/research355/test_lifecycle_repair355.py"
s = read(p).replace(
    '                    "compiled_sources_sha256": life.compiled_digest(self.compiled_hashes),\n',
    "",
)
s = remove_between(
    s,
    "    def test_generation_domain_correspondence_keeps_full_image_coverage(",
    "    def test_non_authoritative_candidate_",
)
a = s.index('        self.assertEqual(evidence["compiled_sources_domain"]')
b = s.index('        self.assertEqual(evidence["book_sha256"]', a)
s = s[:a] + s[b:]
write(p, s)
