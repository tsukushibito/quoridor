from prepare import read, write, remove_between

p = "docs/development/research-lifecycle.md"
s = read(p)
s = s.replace(
    """- `source`: `commit`, nullable bound `patch`, exact `files` references, absolute `workspace`, full `manifest` and `lock` FileRefs, `compiled_sources` (flat named-key → source FileRef projection) and `cargo_configs` ({path, file: FileRef|null} exact directly searched configurations including witnessed absence). Cargo cwd equals this adopted workspace, and each Cargo argv names the exact adopted manifest using `--manifest-path` before `--`. Cargo.lock is the same adopted dependency. CARGO_HOME and all directly searched ancestor/home config paths are frozen; no transitive generated-header reconstruction is added. Actual zero-model bindings must equal the adopted compiled projection key-for-key and hash-for-hash. Root `quoridor.research.source-adoption.v1` records `status=ACCEPTED` and this exact source once, at adoption. It is recorded in the build; it is not recursively executed per run.""",
    """- `source`: actual Git `commit`, nullable bound `patch` containing the byte-exact `git diff --binary --no-ext-diff --no-textconv HEAD --`, `untracked_inputs` FileRefs for actual untracked Cargo inputs, absolute `workspace`, `manifest` and `lock` FileRefs, and `cargo_configs` ({path, file: FileRef|null}, including directly searched ancestor/CARGO_HOME configuration absence). The standard Git revision/delta and these controls are checked before BUILD, after commands and at finalization. Cargo/rustc own dependency discovery; Cargo.toml is an entry, not an exhaustive source list. No independently maintained Rust file inventory, aliases or embedded `include_bytes!` certification is used. Root records this exact object in the normal accepted Source adoption. Record Source after the code commit; keep Git revision/delta fixed through the entered BUILD/finalizer lifetime. An untracked metadata adoption file may be committed after STOP, avoiding a self-referential Git commit.""",
)
s = s.replace(
    """- `commands`: `{name, role, argv}`, with test/lint/build/bindings roles. Cargo commands are `test`/`clippy`/`build`, `--offline --locked -j1 --message-format=json-render-diagnostics`; no `cargo run`, extra workload or lint-allow workaround is admitted. Bindings is the actual copied runner's `research-bindings` port.""",
    """- `commands`: `{name, role, argv}`, with test/lint/build roles. Cargo commands are `test`/`clippy`/`build`, `--offline --locked -j1 --message-format=json-render-diagnostics`; no `cargo run`, extra workload or lint-allow workaround is admitted. One release command selects the actual package/bin. Cargo JSON records features, target and profile with the emitted executable; its content hash must match the one private artifact. The redundant `research-bindings` command is retired.""",
)
s = s.replace(
    "`artifact`, `compiled_sources`, `source`, source-adoption reference",
    "`artifact`, actual `cargo_artifact` compiler output, `source`, source-adoption reference",
)
s = s.replace(
    "artifact/compiled-source/config/schedule/input/descriptor/weights/evaluator SHA bindings",
    "artifact/config/schedule/input/descriptor/weights/evaluator SHA bindings",
)
s = s.replace("; compare additionally records qualified generation-source digest", "")
s = s.replace(
    """`research-bindings` is the single zero-model compiled-source/artifact port. """,
    """The artifact SHA and actual Cargo compiler output bind the qualified native image. """,
)
s = s.replace(
    "Input/descriptor/weights/evaluator SHA fields are arrays in exact input/model order; compiled_sources_sha256 is SHA256 of serde JSON compact sorted full source map.",
    "Input/descriptor/weights/evaluator SHA fields are arrays in exact input/model order; the actual artifact SHA binds the native executable.",
)
s = s.replace("binds the actual artifact, compiled source map,", "binds the actual artifact,")
s = remove_between(
    s,
    "## Generation source domains and failed-origin inputs",
    "The maintained publisher's read-only `generation_input_data",
)
# Insert the surviving concrete raw/semantic/custody rule instead of source-domain aliases.
a = s.index("The maintained publisher's read-only `generation_input_data")
s = (
    s[:a]
    + """## Generated data and failed-origin inputs

Raw book/schedule SHA joins the original native result; semantic digests describe parsed values. They are different identities and are never rewritten to agree. Immutable books and corpus headers may contain old producer source-map metadata. The SHA-bound records retain it as opaque historical provenance; current admissions do not interpret it as a current source inventory. New producers build no such map. Actual artifact/input/config/history/rules/model correspondence remains required.

"""
    + s[a:]
)
a = s.index("A successful immutable BuildManifest retains its complete authored source snapshot")
b = s.index("Actual RUN dependencies are", a)
s = (
    s[:a]
    + """A successful immutable BuildManifest retains Git revision/delta, relevant untracked input identities, Cargo manifest/lock/configuration, compiler tools/versions, actual commands and Cargo artifact/profile/features as BUILD provenance. It also retains every actual check, full bounded log, returned guardian and normal completion/error/cleanup facts. RUN validates accepted PASS/no-marker completion and actual artifact bytes; native entry checks that exact artifact. RUN does not read current Rust/Cargo/compiler inputs. Historical BuildManifest, Source, failures and restoration records remain immutable.

"""
    + s[b:]
)
s += """
## Current configuration and retained numerical scope

Arena `search_artifact_sha256` binds each engine's actual executable image alongside its independent evaluator/model identity. Sigma NativeIdentity and live cost qualification bind actual executable/backend/config/evidence/expiry; they contain no compiled source-map digest. This does not refresh old qualification validity or certify changed backend timing. Fresh current cost evidence is still required by the selected plan.

One reviewed normal Source adoption may explicitly retain the original `ordering20-input-and-head-v1` numerical scope: `retained_ordering_numerical` contains only `scope`, original `qualification` and `build_manifest` FileRefs, plus `cheap_static376` only for that selected caller. It refers to the independently reviewed correspondence of this exact adopted source, actual unchanged input/head bodies, compiler controls and original numerical domain. Current Build/image and original numerical artifact stay separate; full current configuration/input/model/library correspondence, actual release command/tool/environment equality and original completion remain checked. The adoption is required once because static preparation cannot mint a new numerical PASS. It does not rebuild a per-run source graph, carry source-map aliases, or permit arbitrary future source changes. If this precise exception lacks accepted evidence, admission refuses; do not silently qualify another model/root or replay old successful numerical scopes.

Affected verification uses new owning Git/Cargo/artifact fault cases and the genuinely changed current API tests. Preserve unchanged successful checks in their original scope. A meaningful Rust source edit must produce an actual Cargo `compiler-artifact` with `fresh=false` for the affected target during the supported new build; retain that standard output as rebuild evidence rather than adding a dependency checker. No successful BUILD prefix is salvaged from an old FAILED manifest.
"""
write(p, s)
