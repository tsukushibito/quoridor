"""Collect the original accepted379 BUILD and release its finite source custody."""

import importlib.util
import json
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/build-provenance379-v1"
PHASE = OWN / "software-build-v3"
OUT = PHASE / "qualified-collection-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


spec = lc.document(ref(PHASE / "intent.json"))
manifest_ref = ref(PHASE / "operation-v3/manifest.json")
manifest = lc.accepted_build(manifest_ref)
job_ref = ref(PHASE / "runtime-v3/result.json")
job = lc.document(job_ref)
lc.require(job["job_id"] == "3c00bece-61b8-428d-952b-dc6ed775eb9c", "original job")
lc.require(job["cleanup_complete"] and job["remaining"] == [], "outer cleanup")
lc.require(not OUT.exists(), "exclusive collection")
identities = [manifest["originating_job"]["supervisor"], manifest["originating_job"]["child"]]
checks = manifest["checks"]
lc.require(len(checks) == 10, "seven versions plus affected test/lint/build")
for check in checks:
    lc.require(check["status"] == "PASS" and check["capture_complete"], "completed original scope")
    lc.settled(check["guardian_return"])
    identities.append(check["guardian_return"]["child"])
    for field in ["full_log", "persisted_process_receipt"]:
        lc.read_ref(check[field], max(lc.CONTROL_BYTES, check[field]["bytes"]))
    lc.require(
        check["full_log"]["bytes"] == check["guardian_return"]["log_bytes_seen"], "full capture"
    )
test = next(c for c in checks if c["role"] == "test")
name = "ordering_assessment::cheap376_tests::ordering376_fixed80_two_independent_sweeps_masks_and_finite_denominators"
text = lc.read_ref(test["full_log"]).decode()
lc.require(name in test["argv"] and "--exact" in test["argv"], "literal affected assertion")
lc.require(
    "running 1 test\n" in text
    and "test " + name + " ... ok\n" in text
    and "test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured;" in text,
    "exact executed census",
)
lc.require(manifest["cargo_artifact"]["fresh"] is False, "Cargo rebuild evidence")
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
absence = []
for identity in identities:
    p = Path("/proc") / str(identity["pid"]) / "stat"
    try:
        ticks = p.read_text().rsplit(")", 1)[1].split()[19]
        current = {"pid": identity["pid"], "start_ticks": ticks, "boot_id": boot}
    except FileNotFoundError:
        current = None
    lc.require(current != identity, "same original process still live")
    absence.append({"original": identity, "current": current, "same_identity_live": False})
lc.physical_and_quiet(spec)
with lc.lease():
    lc.source_check(spec["source"])
    for tool in spec["tools"].values():
        lc.read_ref(tool["file"], max(lc.CONTROL_BYTES, tool["file"]["bytes"]))
    lc.document(spec["source_adoption"])
    handover = lc.document(spec["target_handover"])
    marker = json.loads((Path(spec["target"]) / ".research-owner.json").read_bytes())
    lc.require(marker == handover["after_owner_marker"], "current target owner")
    allocated = lc.allocated(spec["target"])
    private_allocated = lc.allocated(Path(spec["private"]).parent)
    lc.require(allocated <= handover["target_max_B"], "target cap")
    lc.require(private_allocated <= handover["fresh_private_forward_max_B"], "private parent cap")
    artifact = ref(spec["private"])
    lc.require(artifact == manifest["artifact"], "actual private image identity")
    emitted = ref(manifest["cargo_artifact"]["executable"])
    lc.require(
        emitted["sha256"] == artifact["sha256"] and emitted["bytes"] == artifact["bytes"],
        "Cargo/private same bytes",
    )
    lc.require(not Path(spec["TMP"]).exists(), "TMP removed")
    source_STOP = lc.stamp()
lease_STOP = lc.stamp()
OUT.mkdir()
record = {
    "issue": "quoridor-4lc.379.1",
    "status": "PASS_AUTHENTIC_CURRENT_BUILD_ONLY",
    "manifest": manifest_ref,
    "outer_job": job_ref,
    "outer_log": ref(PHASE / "runtime-v3/output.log"),
    "intent": ref(PHASE / "intent.json"),
    "source_adoption": spec["source_adoption"],
    "support": spec["support"],
    "handover": spec["target_handover"],
    "artifact": artifact,
    "Cargo_emitted_artifact": emitted,
    "Cargo_release_report": manifest["cargo_artifact"],
    "checks": [
        {
            k: c[k]
            for k in [
                "name",
                "role",
                "status",
                "full_log",
                "persisted_process_receipt",
                "capture_complete",
                "guardian_return",
            ]
        }
        for c in checks
    ],
    "affected_assertions_passed_once": [name],
    "assertions_executed": 1,
    "prior_two379_nine376_twelve374_scope": "Immutable original scope, no replay",
    "authoritative_finished_at": manifest["authoritative_finished_at"],
    "inner_cleanup_complete": manifest["cleanup_complete"],
    "outer_cleanup_complete": job["cleanup_complete"],
    "primary": manifest["primary"],
    "secondary": manifest["secondary"],
    "returned_vs_persisted": "Returned guardians settled completed; original persisted receipts separately bound, pending/attempted fields not rewritten",
    "controller_whole_wall_seconds_counted_once": job["wall_seconds"],
    "all_three379_controllers_once_seconds": 35.304008461069316 + job["wall_seconds"],
    "nested_walls_not_added": True,
    "original_process_identities": absence,
    "actual_source_private_tool_reader_STOP": source_STOP,
    "actual_canonical_release": lease_STOP,
    "target_allocated_after_B": allocated,
    "target_retained_floor_B": max(allocated, 1388646400),
    "target_cap_B": handover["target_max_B"],
    "private_allocated_B": private_allocated,
    "TMP_absent": True,
    "owned_readers_children_jobs_TMP_remaining": [],
    "reservation": None,
    "continuous_peak": "UNKNOWN",
    "five379_and_eight374_Python": "Still unfinished at this BUILD STOP",
    "numerical_model_library_Sigma_Search_game_entry": False,
}
lc.new_json(OUT / "qualified-build-STOP.json", record)
print(
    json.dumps(
        {
            "STOP": source_STOP,
            "release": lease_STOP,
            "record": ref(OUT / "qualified-build-STOP.json"),
            "manifest": manifest_ref,
            "artifact": artifact,
            "target_B": allocated,
            "private_B": private_allocated,
        }
    )
)
