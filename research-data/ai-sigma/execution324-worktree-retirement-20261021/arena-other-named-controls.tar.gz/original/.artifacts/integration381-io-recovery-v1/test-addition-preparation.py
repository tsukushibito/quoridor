from pathlib import Path
import fcntl
p=Path('/workspaces/quoridor/tools/research-session/test_lifecycle.py')
addition='''

class CommonStudySettingsTests(unittest.TestCase):
    def test_corpus_quantity_is_configured_and_cpu_scope_is_owned(self):
        config = {"phase": "common_corpus", "output": "/tmp/owned-data", "planned_games": 3, "depth": 6, "max_nodes": 100, "max_total_nodes": 900, "worker_cores": [1, 4], "cpu_core": 1, "game_workers": 2}
        experiment = {"phase": "corpus", "config": {}, "models": [], "rules": "research-standard-2p-threefold-goal-first-v1", "distance_units": "wall-distance/80", "value_perspective": "side-to-move", "argv": ["runner", "teacher-pilot", "--experiment", "@EXPERIMENT@", "--experiment-sha256", "@EXPERIMENT_SHA256@"]}
        spec = {"data_root": config["output"], "child_cpu_cores": [1, 4, 6, 8], "limits": {"worker_cpu": 1, "guardian_cpu": 6}}
        with patch.object(lc, "document", return_value=config), patch.object(lc, "numerical_check") as numeric:
            for count in (3, 12):
                config["planned_games"] = count
                lc.common_study_check(spec, experiment, {}, {})
            self.assertEqual(numeric.call_count, 2)
            bad = copy.deepcopy(spec)
            bad["limits"]["guardian_cpu"] = 4
            with self.assertRaisesRegex(lc.Refused, "workers/guardian"):
                lc.common_study_check(bad, experiment, {}, {})
            experiment["models"] = [{"descriptor": "foreign model"}]
            with self.assertRaisesRegex(lc.Refused, "model-free"):
                lc.common_study_check(spec, experiment, {}, {})

    def test_mixed_inputs_are_shared_and_initializer_and_cache_custody_remain_checked(self):
        warm = {"descriptor": {"path": "/models/descriptor"}, "weights": {"path": "/models/weights"}, "evaluator_sha256": "a" * 64, "optimizer": "fresh", "scale": "incumbent"}
        public = {"path": "/shared-public/cache.json"}
        acceptance = {"path": "/accepted-public.json"}
        cache_ref = {"path": "/new-data/cache.json"}
        cache = {"rows": 10, "stream_intake": {"status": "complete"}, "sha256": {}, "file_bytes": {}, "common_corpus": {"common_eligible_by_split": {"train": 6, "validation": 4}}}
        inputs = [public, acceptance, cache_ref]
        for name, width in lc.COMPACT_CACHE_WIDTHS.items():
            cache["sha256"][name] = "b" * 64
            cache["file_bytes"][name] = 10 * width
            inputs.append({"path": "/new-data/" + name, "sha256": "b" * 64, "bytes": 10 * width})
        config = {"training": {"target": "z"}, "experiment": {"study": "mixed-outcome", "warm_start": warm}, "mixture": {"public_membership": public, "public_acceptance": acceptance}}
        experiment = {"phase": "fit", "config": {"path": "/settings.json"}, "planned_slots": 0, "rules": "research-standard-2p-threefold-goal-first-v1", "distance_units": "wall-distance/80", "value_perspective": "side-to-move", "inputs": inputs, "models": [{k: warm[k] for k in ("descriptor", "weights", "evaluator_sha256")}]}
        spec = {"data_root": "/tmp/fit-data", "argv": [sys.executable, "-B", "-m", "quoridor_training.train", "train", "--cache", "/new-data", "--output", "/tmp/fit-data", "--config", "/settings.json"]}
        def document(ref):
            return cache if ref == cache_ref else config
        with patch.object(lc, "document", side_effect=document), patch.object(lc, "project_python", return_value=Path(sys.executable)), patch.object(lc, "project_interpreter"), patch.object(lc, "common_training_environment"), patch.object(lc, "numerical_check"):
            lc.common_study_check(spec, experiment, {}, {})
            experiment["inputs"].append({"path": "/shared-public/train.bin"})
            with self.assertRaisesRegex(lc.Refused, "indexed/shared"):
                lc.common_study_check(spec, experiment, {}, {})
            experiment["inputs"].pop()
            warm["scale"] = "new-T-renormalized"
            with self.assertRaisesRegex(lc.Refused, "original scale"):
                lc.common_study_check(spec, experiment, {}, {})
            warm["scale"] = "incumbent"
            inputs[-1]["bytes"] += 1
            with self.assertRaisesRegex(lc.Refused, "binary custody"):
                lc.common_study_check(spec, experiment, {}, {})

    def test_partial_corpus_result_retains_actual_counts_without_plan_census_gate(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            result = root / "generation.json"
            saved = {"scheduled": 5, "recorded": 3, "goals": 1, "draws": 1, "unknown": 1, "search_nodes": 37}
            result.write_text(json.dumps(saved))
            spec = {"owner": tmp, "data_root": tmp, "data": [{"name": "generation_result", "path": str(result), "limit_B": 4096}]}
            experiment = {"phase": "corpus", "planned_slots": 8, "argv": ["runner", "teacher-pilot"]}
            actual = lc.collect_data(spec, experiment)
            self.assertEqual(actual["status"], "PASS")
            self.assertEqual(actual["corpus"], saved)
            self.assertEqual(actual["planned_slots"], 8)
            self.assertNotIn("evaluations", actual["corpus"])
            self.assertFalse(actual["global_campaign_complete"])
            saved["recorded"] = 6
            result.write_text(json.dumps(saved))
            refused = lc.collect_data(spec, experiment)
            self.assertEqual(refused["status"], "FAILED")
            self.assertIn("actual generation census", refused["errors"][0]["message"])

    def test_early_stopped_fit_preserves_actual_exposure_and_original_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = Path(tmp) / "training.json"
            state = {"status": "EARLY_STOPPED", "step": 7, "forward_rows": 29, "added_seen": 12, "public_seen": 12}
            result.write_text(json.dumps(state))
            spec = {"owner": tmp, "data_root": tmp, "data": [{"name": "training", "path": str(result), "limit_B": 4096}]}
            experiment = {"phase": "fit", "planned_slots": 0, "argv": ["python", "-B"]}
            actual = lc.collect_data(spec, experiment)
            self.assertEqual(actual["status"], "PASS")
            self.assertEqual(actual["fit"], state)
            self.assertNotIn("aggregate_forward_rows", actual["fit"])
            state["status"] = "FAILED"
            result.write_text(json.dumps(state))
            refused = lc.collect_data(spec, experiment)
            self.assertEqual(refused["status"], "FAILED")
            self.assertIn("did not complete", refused["errors"][0]["message"])
'''
with open('/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock','a+') as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 s=p.read_text();assert 'class CommonStudySettingsTests' not in s;s=s.replace('\n\nif __name__ == "__main__":',addition+'\n\nif __name__ == "__main__":');p.write_text(s)
 print('Four new owning caller metadata definitions prepared')
