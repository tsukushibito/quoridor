# 学習画像の明示生成方針 — quoridor-4lc.323.3

通常trainerからPNG/SVG描画import・画像頻度分岐・初期/epoch/終了persistの自動callerを撤去した。全selector/固定診断のJSONまたはJSONL.gz/CSV、全点・数値精度・scopes、INITIAL/BEST/LAST、BEST/減衰/早期停止/fullV/fullT、model/FP32/sampler/seed/反転/尺度/教師/分割は変更していない。画像未生成は記録やfreezeの失敗にならず、FROZEN_ARTIFACTSのASTはそのままで画像を含まない。

## 明示入口

`python -B -m quoridor_training.plotting --curves SAVED_RECORD_FILE --output chosen.svg --format svg`、またはMatplotlib導入済みの既存描画Pythonを明示して`--output chosen.png --format png`。対象ファイルと一つの形式だけを描く。SVG baselineをsaved reference-metricsで表示したい場合だけ`--references`を指定する。選定点の表示は既存`--selected-step`を使う。描画は学習/推論/数値記録の書換をしない。

PNG functionの環境変数による外部Python自動呼出しも削除した。PNG/SVG描画APIそのものは維持し、Matplotlibは明示PNG時のみimportする。trainerからは描画環境へ依存しない。既画像・raw・旧source・モデル・原失敗は削除しない。

## main最小patchとWT差分

`main-minimum.patch`は現在mainのSHA固定5既存path＋新しい小fixture1pathに対する画像方針だけ。mainのJSON array数値persistはそのまま。WTの全量JSONL.gz append、unbounded/cohort/INITIAL guard/epoch_measurement hooksを丸ごとmainへ採用しない。stagingのbefore/afterは今回patch検証の限られた入力/証拠で、恒常mirrorや実行入口ではない。

WTでは実測caller ee3ef768…のpersist_curvesからrender引数/頻度分岐/PNG/SVG importを除去した。数値appendはそのまま。関連epoch_measurementのunused PNG/SVG observer2項目だけ撤去して将来の明示計測入口を破損させない。旧323.2測定source/archive/数値/画像は保全し、旧報告へ新callerを遡及適用しない。

現mainはJSON array、実WTはJSONL.gzという生きた版の差がある。それぞれ既形式のreaderを維持し、互換reader/shimを追加していない。形式統合は今回外。main patchのPNG表示だけ、既main診断scopeを正しく表示する小修正を含む。docsは各現入口の保存形式を指定した明示生成コマンドへ更新した。

main patch対象:

- docs/development/nnue-training.md beforeSHA 5c177d36c55531ca65249bd2e9bf53c0026d54d788cb39000549fc63d68e124d afterSHA 523db9f609b350f3bb8fb29bb6bf5200489ec5b432b81ca54883a1219faa0a2e
- docs/development/rust-ai.md beforeSHA a2b4c3dc5977517369326a5e9fcfc80f3da8f19cdf7c852524aafbb93df43e86 afterSHA 955c659fd9ea18cdfbfdfcc465a16734deb880bcbd78b1aaf4ced3d327e171a0
- python/quoridor_training/plotting.py beforeSHA 278dfc2854a8e6ad4c8dc41731933a2cacec4e61fb4ecb075d99d72010a613c9 afterSHA 2610b52c7e37262d099a27ad5af5af9a8888230f85748c345bab5465519bd09c
- python/quoridor_training/test_image_policy.py beforeSHA None afterSHA 0988eff6723d1b37ca1003261b8af7cfa4f5b06526abe9dad86da978e3626651
- python/quoridor_training/test_observation.py beforeSHA 1313d2480b8273a658affc0dd705c31ef4c8c7f4d6fc2573628b6403e3ee3189 afterSHA baff92e40fbd6bf3a4555c7b429de533dc05d532c4c7557d86316151d7261d29
- python/quoridor_training/train.py beforeSHA a1c7934c17069131200d78cb53a83a209ce249ceb6988c762ec7952d354d9ee2 afterSHA ae6cde966caf73e7249106adc5050feb829a5c30606cab445a2b0cfb2b1bab85

WT停止pathはbinding.jsonのWT_stopped_source7path（trainer/plotting/test_observation/test_image_policy/epoch_measurementと2docs）。Rootはmain最小patchを基準として適用範囲を確認し、WT全trainerをコピーしない。

## 検証

WTとmain stagingで各5件NN0 PASS。Torch import拒否・CPU3/address-space512MiB、子wall約0.083/0.076秒、peak RSS45136/43848KiB、forward/CUDA0。実persist closureをsource ASTから隔離し、initial/epoch/final相当の3回を実行して全3点とdouble精度をJSON/CSVに保存、plotter/Popen禁止、画像0を確認。これは実training/model qualificationではない。

PNG/SVG CLIの一方だけの選択、format/extension矛盾の早期拒否、fixed diagnostic対full-selectorラベルを検証。変更前から画像操作だけを除いたtrain関数ASTと現在train ASTがWT/mainとも一致し、数学/数値記録/選定/stop/freezeの変更を除外した。main snapshotにpatch --dry-run成功。既live fixtureは数値/checkpoint assertionsを維持し、画像期待だけFalseへ更新したが、許可外のmodel-forward live fixtureを再実行しない。

既plot環境で2点の人工固定診断からWT PNG、main staging PNG/SVGを個別に生成し、両PNGを目視してscope/row/group表示を確認。WT PNG child1.168秒、main PNG1.040/SVG0.032秒、各CPU3/address-space512MiB、direct subprocess wait/exit0。新依存・全旧曲線描画・Torch/model/GPU/cache/newE読取なし。SVG CLIはMatplotlibをimportしない。

初回mockはfixtureのunbounded local不足で1error/3PASSになり、その失敗をfixture-first-failure.jsonへ保持。fixtureを補って最終PASS。探索318.2への連絡は既closedのためRPC前に拒否された事実を保持し、新role/再送/issue再開は行わない。toy前のnamed science/compiler確認は0だった。

Ruff scoped format/check、Prettier scoped docs、停止source/archive SHA保存。main/Git/index/ref writer0、共有Cargo0。reader/子/plot subprocessは終了、current/next learner numeric予約0。

## 資源・終了

今回source/patch/NN0/人工図/evidenceは既1048MiB/evidence94MiB内の1MiB incrementとしてforecast。旧323.2 root実5113048Bを保全した上でevidence peak88559796B<98566144、全scope1087808561B<1098907648。旧assets/必要予約/費/caps/UNKNOWNは保全、容量全域/target walkや削除/refundは0。実専有namespace最終量はreceiptに記録。

元323 paused-by-user、323.2 closedを維持。今回323.3だけ通常close/backup。GPU転送回数・scalar取出し・まとめた転送/再用bufferは提案のままで、.to(device)/side/finite/記録Mathへ変更していない。追加fit/GPU比較/native資格/globalfreeze/newE/Sigma/新reviewerは0。

証拠: binding.json、math-invariants.json、fixtures.json、toy-PNG-receipt.json、toy-main-receipts.json、main-minimum.patch、WT-stopped-source.tar.gz、main-minimum-source.tar.gz。
