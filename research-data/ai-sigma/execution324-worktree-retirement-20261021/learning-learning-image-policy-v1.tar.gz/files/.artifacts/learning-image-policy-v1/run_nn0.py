"""Only the focused image policy fixture, with Torch imports refused."""

import importlib.abc
import json
import resource
import sys
import time
import unittest


class NoTorch(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "torch" or fullname.startswith("torch."):
            raise AssertionError("Torch import is outside image-policy NN0 scope")
        return None


sys.meta_path.insert(0, NoTorch())
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
started = time.monotonic()
suite = unittest.defaultTestLoader.loadTestsFromName("quoridor_training.test_image_policy")
result = unittest.TextTestRunner(verbosity=2).run(suite)
print(
    json.dumps(
        {
            "success": result.wasSuccessful(),
            "tests": result.testsRun,
            "wall_seconds": time.monotonic() - started,
            "peak_RSS_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            "Torch_imported": "torch" in sys.modules,
            "model_forward": 0,
            "CUDA": 0,
        }
    )
)
sys.exit(0 if result.wasSuccessful() else 1)
