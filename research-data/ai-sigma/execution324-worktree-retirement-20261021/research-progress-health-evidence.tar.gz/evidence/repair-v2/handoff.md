# quoridor-4lc.352 corrective source handoff

Status: source Ready for Root intake; scheduler **not installed or enabled** in Main. Source writer/reader STOP: 2026-10-09T12:11:19.775613+00:00; no retained source readers, test children, or TMP. Root alone integrates Main/Git/index and installs the single timer.

## Exact stopped source

- Worktree `/workspaces/quoridor/.worktree/research-progress-health`, base `9ca36302c56e5f63229e88bcc0b8a7fa0054e468`. No Git add, commit, or index writes.
- Three intended paths and their SHA256/size/mode are in `source-manifest.json`; exact patch `source.patch` SHA256 `15acebce25a39bbefeaba216bb2705ddc3bbfa2eb42b48d43b25df0b288e0e1b`, 95741 bytes. This supersedes the old patch `8acb52250be569c5a5e129d08eeb204029b9b1665e06d6b21976d401897611fb` but preserves it and the old handoff at the parent artifact path.
- Source path hashes: `scripts/dev/research-progress-health.py` d6b1b1abf7a866b4f23ce76e48446367821ec98481a92a13a24ed6605c4c731f (46144B/0o644), `scripts/dev/research-session.py` 0959b27559ef377395988aa776241711c12c6778fa89b2fa444564a9acdd33b3 (20987B/0o644), `scripts/dev/test_research_progress_health.py` fd0bcce1f78135f8ca5d5222733da409de6aafc58dd8efeb5f650ffb6b19e462 (39425B/0o644).

## Corrections to Root's H1–H3 assessment

- **H1:** Current consumer `dashboard.evidence_paths` now selects one exact stopped JSON target, hashes its bytes, and matches a closed direct-child review's named immutable control from its own evidence paths. It checks issue identities, current Beads reviewer assignee, reader STOP, empty remaining, and target SHA; accepts existing TT/Sigma/342 stop/hash aliases and `source_review`. Source-clear false is a distinct blocked-source triage candidate, never a certified clear. Missing, stale, ambiguous, symlinked, oversized, or incomplete proof stays UNKNOWN. The prior optional health receipt path remains only as compatibility for explicit supplied evidence; no new owner registry is required.
- **H2:** Policy authority reads use `beads.sh list --all --brief --flat --id ... --limit 0 --max-rows 1 --json`. The maintained session `--idle-only` path uses the same brief authority read with a 64KiB bounded, directly reaped command port; ordinary send behavior stays intact.
- **H3:** Timer stop opens pidfd, then revalidates exact boot/start/argv while holding it before SIGTERM. Unsupported or changed identity refuses signalling. New-child start uses an inherited gate and pidfd; handshake failures signal only the still-identical owned child, directly wait it, and keep primary/cleanup errors. No foreign science process signal.
- **Latest routing clarification:** Only explicit AUTONOMOUS with a currently eligible batch treats notLoaded Policy as a delivery opportunity. Maintained `--idle-only` resumes that existing thread with full-access/never without a model turn, rereads status, and starts a turn only if idle; active or App Server conflict refuses. CONSULTATION/STOPPED/invalid mode never resume or wake Policy. A failed or uncertain delivery is retained as uncertain, never auto certified.

## Validation and evidence

- `test-receipt.json` records commands and outcomes. Installed Ruff format/check and lint PASS on all three changed handwritten Python files. `python3 -B scripts/dev/test_research_progress_health.py -q`: **24 PASS** (0.648s), including actual-style directed proof without invented health fields, stale hash, source-clear false, symlink/refusal, brief authority, pidfd race, failed startup handshake cleanup, and fake notLoaded→idle/active session routes. Previous 19 PASS and earlier failed-timer test remain preserved at `../handoff.md`; no old failure was relabelled.
- One actual NN0 `check --dry-run` on final source: exit0, `2026-10-09T21:08:23.481298+09:00`, CONSULTATION, candidates0, UNKNOWN2. This is operational uncertainty, not a success/science result. `status`: CONSULTATION and not-running. No Beads comment, policy turn, cursor mutation, science/model/native/browser job, or timer install by this worker.
- Actual brief policy list: one exact open Policy Root row, 898 serialized bytes. `git diff --check` plus new-file whitespace check PASS. Source paths total 106556B; staged repair-v2 controls/patch sampled 103144B and parent artifact 186405B before final handoff, well within the already supported 64MiB whole and 8MiB components. Continuous transient peak not measured; no extra storage grant claimed.

## Ownership and remaining

Root 324 must intake the stopped patch, review code, install the single scheduler in Main, explicitly read back initial CONSULTATION and next due, run its first NN0 check, and only then claim enabled. The optional `../docs-proposal.md` reflects current mode/proof/notLoaded behavior. AUTONOMOUS remains a later explicit human mode choice; this handoff does not authorize it. Policy Root/epic is the only future runtime health recipient, while 324 receives only this finite implementation handoff. Preserve pause 323, N gates, Sigma priority, old fees/UNKNOWN. No active lease, background child, or test TMP remains from this owner.
