# Proposed narrow operations text for Main integration

The current `docs/development/research-jobs.md` 15-minute exception and `docs/design/ai-research-team.md` Root routing paragraphs already describe the policy. Add only the following concrete operator steps to the former after integration; no new document or role is needed.

```sh
state=.artifacts/research-progress-health-v1
python3 -B scripts/dev/research-progress-health.py mode --set-mode consultation --confirm-human-choice --state-dir "$state"
python3 -B scripts/dev/research-progress-health.py check --dry-run --root "$PWD" --state-dir "$state"
python3 -B scripts/dev/research-progress-health.py start --root "$PWD" --state-dir "$state"
python3 -B scripts/dev/research-progress-health.py status --state-dir "$state"
```

`CONSULTATION` is the explicitly approved initial mode: scanner only, bounded pending issue/evidence references, no periodic LLM turn or Beads comment. A failed metadata read reports UNKNOWN and preserves those references while breaking the consecutive-observation streak; a successful scan clears resolved pending candidates. `status` can show the local pending count even in STOPPED mode. Changing to `AUTONOMOUS` requires a new explicit human CLI choice (`mode --set-mode autonomous --confirm-human-choice`); it rechecks current facts before commenting once per fingerprint. A bounded current Beads evidence path plus an exact-hash matching stopped review control on a direct child, explicitly named reviewer, or appropriately related sibling can make a source-review handoff actionable; closed status or age alone cannot. AUTONOMOUS sends one batch through `research-session.sh send --idle-only` only when the policy Root thread is idle, or when a notLoaded thread resumes and is then verified idle. Active threads are never steered by this route. `disable --confirm-human-choice` persists `STOPPED` and stops only the exact owned timer. The mode and cursor survive stop/restart; run `mode --set-mode consultation --confirm-human-choice` and `start` to resume. `remove` clears only operational timer files, retaining mode/cursor for explicit recovery. Missing/corrupt mode returns UNKNOWN and performs no external reads. The timer needs the container and host to remain running; it is not reboot persistent. No scientific guardian, completion notification, pause, or authorization is changed.

The existing workflow text saying there is no periodic LLM supervision remains correct: this is a code-only periodic detector, not a recurring LLM supervisor.
