# 362 retained pilot: stopped two-teacher fit evidence

Both original selected fine-tunes completed 200 updates and have sole authoritative PASS manifests. A trained on actual final outcome z; B trained on mapped raw completed-D6 root value. Both independently warm-started immutable BEST43 weights046fe with fresh Adam. Neither used A's trained model as B's initializer. This report is a stopped result handoff for one relevant independent interpretation assessment via Root324, not a model promotion or playing-strength result.

The retained eight fixedD completed-D6 games produced 341 rows. Both candidates used exactly the same 293 eligible rows (217 T, 76 V), excluded the same 48 outside-unit rows, and preserved all raw evidence. Whole-family partition was fixed before outcomes: six T families, two V families. Eight goals, no observed draws or UNKNOWN outcomes were recorded in the original corpus; genuine threefold inclusion remains the selected policy, without an empirical draw sample. Original source, typed partition, schedule, six binary identities and shared compact sampling order remain unchanged. Detailed canonical Game/history JSON was validated at publication and stayed outside the training path.

Both fits retained INITIAL0, BEST200 and LAST200 plus all 11 full T/V checkpoints at 0,20,...,200. Each charged 10850 training predictions (50 complete row epochs) and 3223 full-selector predictions: 14073 total, below the selected conservative 16023 cap. No diagnostic/ONNX predictions, extra fits, game regeneration or successful qualification replay occurred. Their normalized recipes differed only in teacher target; LR1e-4, batch64, 20-update warm-up, 200 updates, seeds, reflection, incumbent scale, head-distance input and no output bypass stayed fixed.

## Descriptive saved losses

Row-weighted MSE on the same finite eligible T/V scope:

| Saved checkpoint / guide           |      z T |      z V | raw-D6 T | raw-D6 V |
| ---------------------------------- | -------: | -------: | -------: | -------: |
| Shared INITIAL BEST43              | 0.607617 | 0.988319 | 0.324686 | 0.388978 |
| A BEST/LAST200                     | 0.508543 | 0.959763 | 0.313861 | 0.372287 |
| B BEST/LAST200                     | 0.637636 | 0.964890 | 0.231327 | 0.346032 |
| Frozen analytic-D guide            | 0.785288 | 0.752184 | 0.017759 | 0.032598 |
| Frozen own-teacher T-only constant | 0.999809 | 1.000191 | 0.089834 | 0.128861 |

A's selected z validation MSE declined from 0.988319 to 0.959763. B's selected raw validation MSE declined from 0.388978 to 0.346032. B's training z MSE increased while its raw objective decreased. Both candidates' saved validation MSEs remain above the analytic-D guide for both teacher views. These are descriptive saved-scope observations; the two different teachers' loss magnitudes are not directly interchangeable.

Each view used its own correct frozen T-only constant: z0.013824884792626729 and raw-0.050417447454094336. All 11 points in both fits retained the same own-teacher T/V constant and analytic-D row/family guides. Other-teacher views were diagnostic non-selectors. BEST selection used each fit's own teacher V strictly; both selected step200. Exact full-precision values and family-equal metrics remain in the original CSV and observation files.

Readable maintained outputs, by reference:

- A: [z curve](../fit-A-output-compact-v3/z-curves.svg), [raw curve](../fit-A-output-compact-v3/completed_root_raw-curves.svg), [full CSV](../fit-A-output-compact-v3/curves.csv).
- B: [z curve](../fit-B-output-compact-v1/z-curves.svg), [raw curve](../fit-B-output-compact-v1/completed_root_raw-curves.svg), [full CSV](../fit-B-output-compact-v1/curves.csv).

A BEST/LAST weights10d4a86b16a1798b120c9357d812265d70231f6ff2e869a89638e3525b05b744; B BEST/LAST weights4710d9f86aac6bb123d73e7d7dcae684ed31b771e954747df5104ecab73d7082. Original initial weights046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841 are unchanged. Each authoritative manifest binds 23 durable output files, including INITIAL/BEST/LAST checkpoints and exports, both curves, observations and completion status. Post-fit native parity and same-time play were not run or established by these fit completions.

## Authority, lifetime and cost

A authoritative manifest350502098c3f17c8aae7d8cea5b4de3a9f2e110a59272aa20a864036b1343c38 finalized2026-10-11T16:03:53.178200+00:00; source/data collector STOP16:05:56.892992. B authoritative manifest13456bc329aaa0b4b0a17ebb6b6dbf102e6d937dc2347d08591a42faea64444c finalized16:09:05.604095; source/data collector STOP16:10:39.596649. Both have null primary, empty secondary/remaining, true cleanup, direct child reap and complete full captures; INCOMPLETE was removed last. Current native23, current callers, approved plan/config pair, model/library/cache/input/output references matched after collection. No arrays, model inference or native commands ran during collection.

Only original fit command wall seconds are added to the experimental allowance: A3.0296568830963224, B2.955343740992248. Total experimental consumed is150.2711004090961 seconds, remaining5249.728899590904. These totals include the already retained original generation/conversion/failed-fit command charges once. They are not all-work fees. A controller4.023592047975399 and B controller4.088869914994575 are separate; trainer phase timings are inclusive/nested and not added. Software, source, administration and LLM time are excluded. Exact worker/fit-child UTCSTOP, continuous memory peaks and all-work costs remain UNKNOWN. Returned mask/final-record completion remains distinct from the preserved on-disk pending/attempted fields.

All old failed operations, partial exports, original A181 FAILED/23 files/INITIAL0/BEST180/LAST181, raw errors, source packets and costs remain immutable. One post-A metadata collector refusal from using a fresh-entry exclusive-output predicate was retained and corrected to lifetime FileRef checks without re-execution. Both fit TMP roots are absent; exact supervisor/worker/fit identities are freshly absent. No current owned readers, children, jobs, TMP or reservations remain. Canonical detailed source and old/new caches are retained; no retirement or storage credit is claimed. Report/control preparation stays inside existing32MiB controls and funded whole; no new allocation.

## Interpretation limits and remaining acceptance

The eight-game pilot has only two validation families and repeated, related trajectory positions. Opened V selected BEST; shared initial model, deterministic order and common lineage constrain interpretation. These results do not establish IID/population generalization, a unique causal teacher effect, Elo/ranking, terminal ground truth, playing strength, speed or product-default suitability. Raw depth6 estimates are teacher observations, not verified optimal values. No extra quantity, fit, strength evaluation, N/default/seal or paused323 change is authorised by this report.

Root's relevant independent interpretation and normal acceptance remain pending. The finite execution evidence is stopped and available for that one assessment; no recurring or per-run review, extra experiment or ACK is requested. Beads362.1 remains in_progress pending acceptance.
