"""Issue364 finite distance interventions using maintained binary/model APIs.

No evaluator clone: model.forward runs once per admitted row/case; read-only
module hooks capture its out scalar and unchanged non-distance head inputs.
"""

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import sys
import time


def stamp():
    return datetime.now(timezone.utc).isoformat()


def file_ref(path):
    path = Path(path)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return dict(
        path=str(path), sha256=digest, bytes=info.st_size, mode=f"{info.st_mode & 0o777:04o}"
    )


def read_ref(ref):
    assert file_ref(ref["path"]) == ref, ("FileRef drift", ref["path"])
    return Path(ref["path"]).read_bytes()


def write_json(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def input_refs(cfg):
    refs = [
        cfg["diagnostic_source"],
        cfg["support"],
        cfg["accepted_pilot"],
        cfg["settings"],
        cfg["cache_manifest"],
        cfg["python"],
    ]
    refs += cfg["source_refs"] + cfg["cache_binaries"]
    for model in cfg["models"]:
        refs += [model["descriptor"], model["weights"], model["saved_observations"]]
        if "scale" in model:
            refs.append(model["scale"])
    return list({ref["path"]: ref for ref in refs}.values())


def quantiles(values):
    import numpy as np

    values = np.asarray(values, dtype=np.float64)
    if not len(values):
        return dict(n=0, median=None, p90=None, minimum=None, maximum=None)
    assert np.isfinite(values).all()
    return dict(
        n=len(values),
        median=float(np.median(values)),
        p90=float(np.quantile(values, 0.9, method="linear")),
        minimum=float(values.min()),
        maximum=float(values.max()),
    )


def delta_metrics(head, value, baseline, sign, threshold):
    import numpy as np

    head, value, baseline = [np.asarray(v, dtype=np.float64) for v in (head, value, baseline)]
    result = {}
    for name, delta in [("logit", head), ("final_value", value)]:
        result[name] = {
            **quantiles(np.abs(delta)),
            "exact_zero_fraction": float(np.mean(delta == 0)) if len(delta) else None,
            "abs_le_1e_6_fraction": float(np.mean(np.abs(delta) <= threshold))
            if len(delta)
            else None,
            "heuristic_consistent_fraction": float(np.mean(delta * sign > 0))
            if len(delta)
            else None,
            "heuristic_reversed_fraction": float(np.mean(delta * sign < 0)) if len(delta) else None,
            "heuristic_tied_fraction": float(np.mean(delta == 0)) if len(delta) else None,
        }
    nonzero = head != 0
    result["absolute_value_delta_over_logit_delta_nonzero"] = quantiles(
        np.abs(value[nonzero] / head[nonzero])
    )
    result["saturated_baseline_n"] = int(np.count_nonzero(np.abs(baseline) >= 0.99))
    return result


def numerical(cfg):
    began = stamp()
    root = Path(cfg["root"])
    for ref in input_refs(cfg):
        read_ref(ref)
    acceptance = json.loads(read_ref(cfg["accepted_pilot"]))
    settings = json.loads(read_ref(cfg["settings"]))
    assert acceptance["status"] == "ACCEPTED_FINITE_DESCRIPTIVE_PILOT"
    assert [m["weights"]["sha256"] for m in cfg["models"]] == [
        "046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841",
        "10d4a86b16a1798b120c9357d812265d70231f6ff2e869a89638e3525b05b744",
        "4710d9f86aac6bb123d73e7d7dcae684ed31b771e954747df5104ecab73d7082",
    ]
    cache_path = Path(cfg["cache_manifest"]["path"]).parent
    allowed_cache_reads = {
        str(cache_path / name)
        for name in ["cache.json", *[Path(v["path"]).name for v in cfg["cache_binaries"]]]
    }
    data_root = cache_path.parent
    cache_reads = set()

    def audit(event, args):
        if event != "open" or isinstance(args[0], int):
            return
        path = Path(os.fsdecode(args[0])).absolute()
        if path.is_relative_to(data_root):
            assert str(path) in allowed_cache_reads, (
                "detailed/other cache input forbidden",
                str(path),
            )
            cache_reads.add(str(path))

    sys.addaudithook(audit)
    import numpy as np
    import torch
    from quoridor_training.terminal_cache import TerminalCorpus
    from quoridor_training.train import build_model, restore_warmstart_parameters
    from quoridor_training.common import PARAMETER_SHAPES

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    assert not torch.cuda.is_initialized()
    corpus = TerminalCorpus(cache_path)
    assert corpus.row_count == 341 and len(corpus.families) == 8
    family_splits = corpus.manifest["sampling"]["families"]
    assert sum(v["split"] == "train" for v in family_splits) == 6
    assert sum(v["split"] == "validation" for v in family_splits) == 2
    assert int(corpus.eligible.sum()) == 293
    assert int(np.count_nonzero(corpus.eligible & (corpus.splits == 0))) == 217
    assert int(np.count_nonzero(corpus.eligible & (corpus.splits == 1))) == 76
    assert int(np.count_nonzero(~corpus.eligible)) == 48
    groups = np.where(
        corpus.eligible, np.where(corpus.splits == 0, "eligible_T", "eligible_V"), "excluded"
    )
    steps = np.asarray(corpus.integer_distances, dtype=np.int16)
    assert np.isfinite(steps).all() and ((steps >= 0) & (steps <= 80)).all()
    assert np.array_equal(
        (steps.astype("<f4") / np.float32(80)).view("<u4"), corpus.maps[0]["distance"].view("<u4")
    )
    realized = 0
    first_forward = None
    model_results = []
    raw_path = root / "raw/observations.jsonl"
    raw_bytes = 0
    raw_records = 0
    expected_per_model = corpus.row_count + sum(
        int(
            np.count_nonzero(
                (steps[:, v["axis"]] + v["step"] >= 0) & (steps[:, v["axis"]] + v["step"] <= 80)
            )
        )
        for v in cfg["changes"]
    )
    descriptors = []
    with raw_path.open("xb") as raw, torch.inference_mode():
        for model_cfg in cfg["models"]:
            descriptor = json.loads(read_ref(model_cfg["descriptor"]))
            assert descriptor["weights_SHA"] == model_cfg["weights"]["sha256"]
            assert descriptor["distance_fit"] == {"a": 0, "b": 0}
            assert descriptor["schema"] == "quoridor-nnue-distance-residual-v3"
            assert descriptor["feature"] == "QF1-route4-f32-STM-scaled-residual-v3"
            assert descriptor["route_mode"] == "zero4"
            assert (
                descriptor["route_mu_f32"] == [0.0] * 4
                and descriptor["route_sigma_f32"] == [1.0] * 4
            )
            statistics = {key: descriptor[key] for key in ("mu_f32", "sigma_f32")}
            if descriptors:
                assert statistics == {key: descriptors[0][key] for key in statistics}
            if "scale" in model_cfg:
                assert json.loads(read_ref(model_cfg["scale"])) == statistics
            descriptors.append(descriptor)
            model = build_model(settings["model"], statistics)
            restore_warmstart_parameters(model, model_cfg["weights"])
            model.eval()
            assert torch.equal(model.coefficient, torch.zeros(2, dtype=torch.float32))

            def parameter_sha():
                digest = hashlib.sha256()
                state = model.state_dict()
                assert set(state) == set(PARAMETER_SHAPES)
                for name in PARAMETER_SHAPES:
                    digest.update(state[name].detach().numpy().astype("<f4", copy=False).tobytes())
                return digest.hexdigest()

            assert parameter_sha() == model_cfg["weights"]["sha256"]
            capture = {}

            def head_hook(_module, _args, output):
                capture["head"] = output[:, 0].detach().clone()

            def hidden_hook(_module, args):
                capture["hidden_inputs"] = args[0].detach().clone()

            head_handle = model.out.register_forward_hook(head_hook)
            hidden_handle = model.h.register_forward_pre_hook(hidden_hook)
            baseline_head = np.empty(341, dtype=np.float32)
            baseline_value = np.empty(341, dtype=np.float32)
            deltas = {
                change["name"]: {"indices": [], "head": [], "value": [], "baseline": []}
                for change in cfg["changes"]
            }
            omitted = {
                change["name"]: {group: 0 for group in ("eligible_T", "eligible_V", "excluded")}
                for change in cfg["changes"]
            }
            model_count = 0
            try:
                for first in range(0, 341, cfg["batch_rows"]):
                    indices = np.arange(first, min(first + cfg["batch_rows"], 341))
                    feature_array, distance_array, _labels = corpus.batch(indices, None)
                    assert feature_array.dtype == np.float32 and feature_array.shape == (
                        len(indices),
                        2,
                        312,
                    )
                    assert np.isfinite(feature_array).all() and np.isfinite(distance_array).all()
                    for local, index in enumerate(indices):
                        index = int(index)
                        x = torch.from_numpy(feature_array[local : local + 1])
                        side = torch.ones(1, dtype=torch.uint8)
                        feature_sha = hashlib.sha256(x.numpy().tobytes()).hexdigest()
                        record = corpus.record(index)
                        row = dict(
                            model=model_cfg["name"],
                            row_index=index,
                            row_id=corpus.row_ids[index],
                            family=corpus.families[int(corpus.groups[index])],
                            game=corpus.group_games[int(corpus.groups[index])],
                            split=("train", "validation")[int(corpus.splits[index])],
                            common_eligible=bool(corpus.eligible[index]),
                            group=str(groups[index]),
                            input_geometry_sha256=bytes(record["input_sha"]).hex(),
                            FT_input_sha256=feature_sha,
                            STM=1,
                            stock_sum=int(record["geometry"]["stocks"].sum()),
                            original_integer_distances=steps[index].tolist(),
                            baseline=None,
                            changes={},
                        )
                        base_ft = None

                        def evaluate(integer):
                            nonlocal realized, model_count, first_forward, base_ft
                            assert realized < cfg["max_row_forwards"]
                            if first_forward is None:
                                first_forward = stamp()
                                write_json(
                                    root / "controls/numerical-START.json",
                                    dict(
                                        first_forward_START=first_forward,
                                        child_pid=os.getpid(),
                                        issue=cfg["issue"],
                                        model=model_cfg["name"],
                                        row_index=index,
                                        exact_process_UTCSTART="UNKNOWN",
                                        no_continuing_runtime_claim=True,
                                    ),
                                )
                                print(
                                    json.dumps(
                                        {"event": "first_forward_START", "at": first_forward}
                                    ),
                                    flush=True,
                                )
                            normalized = integer.astype("<f4").reshape(1, 2) / np.float32(80)
                            d = torch.from_numpy(normalized)
                            capture.clear()
                            result = model(x, d, side)
                            realized += 1
                            model_count += 1
                            head = capture["head"]
                            hidden = capture["hidden_inputs"]
                            assert (
                                result.shape == head.shape == (1,)
                                and result.dtype == head.dtype == torch.float32
                            )
                            assert torch.isfinite(result).all() and torch.isfinite(head).all()
                            assert torch.equal(
                                torch.tanh(head).view(torch.int32), result.view(torch.int32)
                            ), "same-forward tanh(head) bits"
                            assert torch.equal(hidden[:, 64:66], (d - model.mu) / model.sigma)
                            assert torch.count_nonzero(hidden[:, 66:]) == 0
                            if base_ft is None:
                                base_ft = hidden[:, :64].clone()
                            else:
                                assert torch.equal(
                                    hidden[:, :64].view(torch.int32), base_ft.view(torch.int32)
                                ), "non-distance FT head inputs changed"
                            assert hashlib.sha256(x.numpy().tobytes()).hexdigest() == feature_sha
                            assert torch.equal(side, torch.ones(1, dtype=torch.uint8))
                            return dict(
                                integer_distances=integer.tolist(),
                                normalized_distance_bits=normalized.view("<u4")[0].tolist(),
                                head=float(head.item()),
                                value=float(result.item()),
                                head_bits=int(head.view(torch.int32).item()) & 0xFFFFFFFF,
                                value_bits=int(result.view(torch.int32).item()) & 0xFFFFFFFF,
                            )

                        row["baseline"] = evaluate(steps[index].copy())
                        assert (
                            row["baseline"]["normalized_distance_bits"]
                            == distance_array[local].view("<u4").tolist()
                        )
                        baseline_head[index] = row["baseline"]["head"]
                        baseline_value[index] = row["baseline"]["value"]
                        for change in cfg["changes"]:
                            altered = steps[index].copy()
                            altered[change["axis"]] += change["step"]
                            assert (
                                altered[change["axis"]] - steps[index, change["axis"]]
                                == change["step"]
                            )
                            assert altered[1 - change["axis"]] == steps[index, 1 - change["axis"]]
                            if not 0 <= altered[change["axis"]] <= 80:
                                row["changes"][change["name"]] = {"omitted": "outside_valid_0_80"}
                                omitted[change["name"]][str(groups[index])] += 1
                                continue
                            actual = evaluate(altered)
                            actual["delta_head"] = actual["head"] - row["baseline"]["head"]
                            actual["delta_value"] = actual["value"] - row["baseline"]["value"]
                            row["changes"][change["name"]] = actual
                            entry = deltas[change["name"]]
                            entry["indices"].append(index)
                            entry["head"].append(actual["delta_head"])
                            entry["value"].append(actual["delta_value"])
                            entry["baseline"].append(row["baseline"]["value"])
                        encoded = (
                            json.dumps(row, allow_nan=False, separators=(",", ":")) + "\n"
                        ).encode()
                        assert raw_bytes + len(encoded) <= cfg["max_raw_output_B"]
                        raw.write(encoded)
                        raw_bytes += len(encoded)
                        raw_records += 1
                assert model_count == expected_per_model
                assert parameter_sha() == model_cfg["weights"]["sha256"]
                assert all(parameter.grad is None for parameter in model.parameters())
            finally:
                head_handle.remove()
                hidden_handle.remove()
            aggregate = {}
            for group in ("eligible_T", "eligible_V", "excluded"):
                group_mask = groups == group
                saturation = np.abs(baseline_value[group_mask].astype(np.float64)) >= 0.99
                aggregate[group] = {
                    "rows": int(np.count_nonzero(group_mask)),
                    "baseline_abs_logit": quantiles(np.abs(baseline_head[group_mask])),
                    "baseline_value_range": quantiles(baseline_value[group_mask]),
                    "baseline_saturated_n": int(np.count_nonzero(saturation)),
                    "baseline_saturated_fraction": float(np.mean(saturation)),
                    "changes": {},
                }
                for change in cfg["changes"]:
                    entry = deltas[change["name"]]
                    mask = group_mask[np.asarray(entry["indices"], dtype=np.int64)]
                    h, v, bv = [
                        np.asarray(entry[key], dtype=np.float64)[mask]
                        for key in ("head", "value", "baseline")
                    ]
                    saturated = np.abs(bv) >= 0.99
                    aggregate[group]["changes"][change["name"]] = {
                        "omitted_boundary_rows": omitted[change["name"]][group],
                        "all": delta_metrics(h, v, bv, change["expected_sign"], 1e-6),
                        "saturated": delta_metrics(
                            h[saturated], v[saturated], bv[saturated], change["expected_sign"], 1e-6
                        ),
                        "not_saturated": delta_metrics(
                            h[~saturated],
                            v[~saturated],
                            bv[~saturated],
                            change["expected_sign"],
                            1e-6,
                        ),
                    }
            with gzip.GzipFile(
                fileobj=__import__("io").BytesIO(read_ref(model_cfg["saved_observations"])),
                mode="rb",
            ) as stream:
                points = [json.loads(line) for line in stream]
            point = next(v for v in points if v["step"] == model_cfg["saved_step"])
            correspondence = []
            for split, code in [("train", 0), ("validation", 1)]:
                selected = corpus.eligible & (corpus.splits == code)
                prediction = baseline_value[selected].astype(np.float64)
                for teacher, column in [("z", 1), ("completed_root_raw", 3)]:
                    target = corpus.labels[selected, column].astype(np.float64)
                    mse = float(np.mean((prediction - target) ** 2))
                    saved = point[split][teacher + "_mse"]
                    difference = abs(mse - saved)
                    assert difference <= cfg["metrics"]["saved_aggregate_MSE_max_abs_difference"]
                    correspondence.append(
                        dict(
                            split=split,
                            teacher=teacher,
                            computed_mse=mse,
                            saved_mse=saved,
                            absolute_difference=difference,
                        )
                    )
            model_results.append(
                dict(
                    name=model_cfg["name"],
                    identity=model_cfg,
                    row_forwards=model_count,
                    baseline_correspondence={
                        "rowwise_predictions": "ABSENT from accepted output inventory; no fabricated counterpart",
                        "genuinely_available_saved_full_T_V_aggregate_MSE": correspondence,
                        "criterion": cfg["metrics"]["saved_aggregate_MSE_max_abs_difference"],
                    },
                    groups=aggregate,
                )
            )
    assert realized == expected_per_model * 3 <= 5115 and raw_records == 1023
    assert cache_reads == allowed_cache_reads
    corpus.verify_binding()
    for ref in input_refs(cfg):
        read_ref(ref)
    result = dict(
        issue=cfg["issue"],
        status="COMPLETE_FIXED_DIAGNOSTIC",
        numerical_entered_at=began,
        first_forward_START=first_forward,
        numerical_finished_at=stamp(),
        realized_row_forwards=realized,
        maximum_row_forwards=5115,
        omitted_row_forwards=5115 - realized,
        raw_records=raw_records,
        raw_bytes=raw_bytes,
        raw_observations=file_ref(raw_path),
        inputs_before_after="MATCH",
        unchanged_non_distance_FT_inputs_and_parameters="ALL row/case checks passed; FT hidden input bits exact within each row/model",
        same_forward_tanh_consistency="ALL output FP32 bits matched tanh(captured head); coefficients zero verified",
        cache_reads=sorted(cache_reads),
        detailed_source_reads=0,
        actual_child_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        continuous_family_peak="UNKNOWN",
        models=model_results,
        metrics=cfg["metrics"],
        limits="Distance-only sensitivity of possibly physically inconsistent states; no legal-move/cause/other-feature-importance/strength/population/default claim; excluded48 descriptive only; D6 teacher differs from staticD.",
    )
    write_json(root / "raw/result.json", result)
    print(
        json.dumps(
            {
                "status": result["status"],
                "row_forwards": realized,
                "omitted": 5115 - realized,
                "raw_records": raw_records,
                "finished_at": result["numerical_finished_at"],
            }
        ),
        flush=True,
    )


def guardian(cfg, config_path):
    root = Path(cfg["root"])
    for ref in input_refs(cfg):
        read_ref(ref)
    spec = importlib.util.spec_from_file_location(
        "diagnostic_lifecycle_guard", "/workspaces/quoridor/scripts/dev/research-lifecycle.py"
    )
    life = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(life)
    support = json.loads(read_ref(cfg["support"]))
    assert (
        support["worker_write_root"] == str(root)
        and support["allocation"]["worker_whole_B"] == 60 * 1024**2
    )
    control = root / "controls"
    receipt = dict(
        issue=cfg["issue"],
        started_at=stamp(),
        config=file_ref(config_path),
        source=file_ref(__file__),
        primary=None,
        guardian_return=None,
        sampled_family_RSS_plus_controller_max_B=0,
    )
    deadline = time.monotonic() + cfg["max_runtime_seconds"]
    component_caps = {"source": 4, "controls": 8, "raw": 32, "TMP": 12, "failure": 4}

    class DiagnosticResources(life.process.CycleResources):
        def check(self, owned=()):
            super().check(owned)
            infos = [
                life.process.process_info(os.getpid()),
                *[life.process.process_info(v["pid"]) for v in owned],
            ]
            sample = sum(v["rss"] for v in infos if v) + cfg["controller_reserve_B"]
            receipt["sampled_family_RSS_plus_controller_max_B"] = max(
                receipt["sampled_family_RSS_plus_controller_max_B"], sample
            )
            assert sample <= cfg["family_RAM_B"], "family RSS guard"
            for name, mib in component_caps.items():
                assert life.allocated(root / name) <= mib * 1024**2, (
                    "issued component allocation: " + name
                )
            assert life.allocated(root) <= support["allocation"]["worker_whole_B"]
            assert __import__("shutil").disk_usage(root).free >= 128 * 1024**2

    full = None
    try:
        with life.lease():
            life.physical_and_quiet(
                {
                    "limits": {
                        "family_B": cfg["family_RAM_B"],
                        "host_reserve_B": cfg["host_reserve_B"],
                        "worker_cpu": cfg["worker_cpu"],
                        "guardian_cpu": cfg["guardian_cpu"],
                    }
                }
            )
            # In addition to maintained executable-name guard, protect actual Python fits and private native executables; NB protects quantitative lifetimes.
            for entry in Path("/proc").iterdir():
                if not entry.name.isdigit() or int(entry.name) == os.getpid():
                    continue
                try:
                    args = (entry / "cmdline").read_bytes().split(b"\0")
                except OSError:
                    continue
                words = [os.fsdecode(x) for x in args if x]
                if words and (
                    "quoridor_training.train" in words
                    or Path(words[0]).name.startswith(("quoridor-runner-", "terminal-cache-"))
                ):
                    raise life.Refused("actual named quantitative peer: " + entry.name)
            budget = DiagnosticResources(
                {
                    "host_ram_reserve": cfg["host_reserve_B"],
                    "max_memory_bytes": cfg["family_RAM_B"] - cfg["controller_reserve_B"],
                    "max_output_bytes": support["allocation"]["worker_whole_B"],
                },
                root,
                deadline,
            )
            budget.check()
            receipt["fresh_guard"] = dict(
                canonical_NB="owned through child directwait/source-data after/cleanup",
                physical_cores=[cfg["worker_cpu"], cfg["guardian_cpu"]],
                CPU_count=1,
                threads=1,
                GPU=0,
                actual_available_RAM_B=life.process.available_memory(),
                family_cap_B=cfg["family_RAM_B"],
                host_reserve_B=cfg["host_reserve_B"],
            )
            full = life.Capture(control / "worker.full.log", 1024**2)
            env = {
                **os.environ,
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONPATH": "/home/vscode/.cache/inference/envs/quoridor-training/lib/python3.14/site-packages:/workspaces/quoridor/python",
                "CUDA_VISIBLE_DEVICES": "",
                "OMP_NUM_THREADS": "1",
                "OPENBLAS_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1",
                "TMPDIR": str(root / "TMP"),
                "ORT_DISABLE_TELEMETRY": "1",
            }
            receipt["guardian_return"] = life.process.execute(
                [
                    cfg["python"]["path"],
                    "-B",
                    str(Path(__file__).resolve()),
                    "--config",
                    str(config_path),
                    "--config-sha256",
                    receipt["config"]["sha256"],
                    "--numerical",
                ],
                control / "worker.log",
                deadline,
                cpu_core=cfg["worker_cpu"],
                resources=budget,
                cwd="/workspaces/quoridor/.worktree/learning-million",
                env=env,
                output_sink=full,
            )
            budget.check()
            for ref in input_refs(cfg):
                read_ref(ref)
            assert receipt["source"] == file_ref(__file__) and receipt["config"] == file_ref(
                config_path
            )
            receipt["source_data_model_after"] = "MATCH"
    except BaseException as error:
        receipt["primary"] = life.error_fact(error)
    finally:
        if full:
            full.file.close()
        receipt.update(
            reader_STOP=stamp(),
            full_capture=file_ref(control / "worker.full.log")
            if (control / "worker.full.log").exists()
            else None,
            persisted_process_receipt=file_ref(control / "worker.process.json")
            if (control / "worker.process.json").exists()
            else None,
            continuous_family_RSS_peak="UNKNOWN",
            owned_readers=[],
            owned_children=[],
            owned_jobs=[],
            remaining=receipt["guardian_return"]["remaining"]
            if receipt["guardian_return"]
            else "UNKNOWN",
            TMP=[str(p.relative_to(root)) for p in (root / "TMP").rglob("*")],
            reservation=None,
        )
        receipt["status"] = (
            "PASS"
            if receipt["primary"] is None
            and receipt["guardian_return"]
            and receipt["guardian_return"]["cleanup_complete"]
            else "FAILED"
        )
        write_json(control / "guardian-receipt.json", receipt)
    print(
        json.dumps(
            {
                "guardian_status": receipt["status"],
                "primary": receipt["primary"],
                "reader_STOP": receipt["reader_STOP"],
            }
        ),
        flush=True,
    )
    if receipt["status"] != "PASS":
        raise RuntimeError("retained diagnostic failure; no automatic retry")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--config-sha256", required=True)
    parser.add_argument("--numerical", action="store_true")
    args = parser.parse_args()
    config_raw = args.config.read_bytes()
    assert hashlib.sha256(config_raw).hexdigest() == args.config_sha256
    cfg = json.loads(config_raw)
    if args.numerical:
        numerical(cfg)
    else:
        guardian(cfg, args.config)
