# Compiler namespace assessment — source preparation only

No Cargo recorder, metadata probe, compiler, link, build script, toolchain acquisition, fixture, model or scientific job was run. This assesses a next action; it is neither an entry certificate nor resource approval. The six unfinished commands and retained18PASS results are unchanged.

## Decision

A recorder on the retained shared target is **not a fail-closed “no build” route by itself**. It cannot resolve the complete six-command namespace/cost question.

The smallest potentially informative variant is one first-refused-command capture with **new, empty, exclusively owned target AND build directories**, genuine compiler metadata forwarding, and every compilation rejected. This is a partial diagnostic proposal, not an admitted command. It can record the first requested unit's argv/output naming, but cannot establish later runner/arena/fourClippy namespaces, artifact sizes, cache compatibility or full cost. Never simulate successful compilation to get past the first refusal.

## Why the simple route is insufficient

Cargo's RUSTC_WRAPPER intercepts rustc; build-script execution is a separate lifecycle. The saved failed arena log names16 build-directory artifacts. A cached build-script executable can run without a new rustc invocation, including native/compiler work outside the recorder. This is a control-flow counterexample, not observed execution here. A single Cargo job reduces concurrency but does not prohibit that path. [Cargo environment variables](https://doc.rust-lang.org/cargo/reference/environment-variables.html), [build-script lifecycle](https://doc.rust-lang.org/cargo/reference/build-scripts.html).

Cargo metadata/fingerprint preparation can precede compiler refusal. Refusal does not promise untouched cache files or retained artifacts. A shared-target attempt needs exact metadata/replacement leases and preservation, including the missing runner obligation; a recorder cannot provide retrospective protection.

“Contains --print” is unsafe: native-static-libs can compile, link-args leaves emit enabled, and print queries can redirect output to files. Reject these and every unknown mixed argument. [Rustc print options](https://doc.rust-lang.org/rustc/command-line-arguments/print-options.html).

Global and workspace wrappers differ: Cargo documents that RUSTC_WORKSPACE_WRAPPER changes filename hashes. Documentation alone does not establish that a global recorder plus different target/build directories is identical to this installed Cargo's default namespace. Keep observed names bound to the recorder configuration. [Cargo wrapper configuration](https://doc.rust-lang.org/cargo/reference/environment-variables.html).

## Minimal candidate source contract, if pursued

1. Freeze Cargo/rustc executable digests, actual1.99 identity, source/lock/config, profile/features/environment, recorder bytes and record schema. Never forge1.98 version output. Keep RUSTC at real1.99; use a global recorder rather than a workspace wrapper.
2. Both target and build directories must be new, empty and exclusively owned; override both so inherited build.build-dir cannot reach retained cache. Copy no fingerprints, executables or source trees. Retain compiler/profile/source flags and separately bind any diagnostic job-count change.
3. Permit only individually frozen metadata argv vectors: version identity such as -vV or exact Cargo dummy-input queries for file-names/sysroot/cfg, through the bound executable. Reject real source paths, emit/output/link/extern/plugin options, print-to-file syntax, native-static-libs/link-args, unknown print kinds and extra arguments. Unknown harmless queries still refuse until assessed.
4. Record bounded argv/cwd/config and the refused request, then return nonzero. Forward approved metadata verbatim, with no synthetic answers/project-source stdin. Recorder/log/config/hash failure refuses; no continuation after denied compilation.
5. Fresh target/build directories contain no cached build scripts. This removes the shared-cache bypass under the supported default lifecycle. Custom execution entry points, inherited build-dir/wrappers and registry bookkeeping still need exclusion/bindings. This contract is UNEXECUTED; a descendant monitor does not itself prevent an unadmitted exec.
6. Actual entry requires exact waits/output census, Cargo-home/cache ownership, source STOP, soleCargo, fresh quiet and full resource admission. No sampling-derived hard-real-time guarantee.

Future assertions: approved identity/print acceptance; compile/mixed-query refusal; dangerous print/output-path refusal; wrong compiler/config/log failure; no forged success or launch continuation. Definitions only, UNEXECUTED. No runtime implementation/state framework was added.

## What one refused request establishes

Record crate-name/type, profile/codegen flags, metadata/extra-filename, output/build directory and source path. Compare suffix/logical unit with a saved default artifact record.

A changed suffix proves a difference for **that recorder-bound unit**, not automatically the default configuration. A match cannot prove all dependencies overwrite in place,1.98 metadata works with1.99, or retained bytes/peaks fit. A leaf/build-script refusal may occur before the missing runner's request becomes available. Fake output/fingerprints or allowing compilation to continue violates this question.

The documented unit graph is nightly-only and does not itself provide a complete output/execution namespace; build-plan was removed in1.93. Neither is assumed to be a stable1.99 dry-run. No nightly/bootstrap/probe was used. [Cargo unstable features](https://doc.rust-lang.org/cargo/reference/unstable.html).

## Whole-cost comparison

| Route                            | Required binding and cost                                                                                                                                                                                                          | Present assessment                                                                                                              |
| -------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| Shared-target recorder           | Exact metadata/cache/retained-output leases; prevention of cached-script execution; recorder/default naming correspondence; refusal/control costs                                                                                  | Reject simple wrapper-only entry. It guarantees neither no-build nor preservation.                                              |
| One isolated refused request     | Proposed4MiB temporary directory upper inside heldTMP8; source/control/records within priced128KiB increment; exact Cargo-home/registry writes still unpriced until named ownership is established; CPU/RAM/waits/cleanup included | Potentially small partial evidence, **NOT_ADMITTED**. May stop before runner naming; not the six-command certificate.           |
| Compatible retained1.98 lifetime | Exact provider/cargo/rustc/Clippy/driver/sysroot/path/environment identity, lifetime through all6, acquisition/retention/TMP/control/failure                                                                                       | Prior tail basis may apply only after genuine compatibility. Provider not acquired/authorized; version text alone insufficient. |
| New1.99 dependency build         | Full named variant/replacement union, private payloads, linker/TMP and failure                                                                                                                                                     | Prior same-size172326912 external scenario stays conditional; new sizes/names unqualified.                                      |

A genuinely covered read-only retained1.98 provider could add zero local tool bytes only after its category/allocation and lifetime lease are proved; zero is not assumed. Separate installation/extraction charges compressed input + unpacked compiler/driver/sysroot/Clippy + simultaneous extraction/atomic staging + metadata/control/failure + pending build tail. Acquisition terms are UNKNOWN. No global tool/image inventory, download, install or provider acquisition occurred. A private compiler path can change configuration/cache identity and needs checking.

Positive headroom39845888−35225600=4620288B. The original pending4MiB estimate leaves425984B under its original compatible-lifetime assumptions. New acquisition/variant growth beyond it needs supported classification; old cache/UNKNOWN and missing9236480B are not credit.

The isolated diagnostic's proposed4MiB is a temporary-metadata planning upper, not actual usage or a hard aggregate guarantee. Before entry, created-directory cardinality/cache writes/logs/current temporary lifetimes/refusal overhead must fit a complete supported forecast; otherwise report the named gap. Metadata may not be free because it produces no ELF.

## Preserved boundaries

Stopped32 integration stays frozen; main/Git/index belongs324. No production/v11 controls/private/model payload/333oldRuleA source mutation. Helper331.2 owns artifact/lifetime facts, not recorder implementation or resource admission.

Old raw/source/fees472.5731598730199/positive35225600/missing9236480UNKNOWN/private25313280/upper bounds remain held. Assessment131072 +held7917568 +helper65536 =8114176 <source8519680. No parent/build/qual/games increase or refund.

References establish interfaces/counterexamples, not exact installed Cargo code-path proof. Installed-revision compilation-files source retrieval attempts failed; no default filename-hash invariance is inferred from a different revision.
