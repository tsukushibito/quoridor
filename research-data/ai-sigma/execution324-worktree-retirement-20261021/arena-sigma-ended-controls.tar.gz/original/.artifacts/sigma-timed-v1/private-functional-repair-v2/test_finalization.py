"""Actual controller AST + fake IO ports; no runtime/worker/model import."""

import ast
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
from types import SimpleNamespace
import unittest

SOURCE = Path(__file__).resolve().parent.parent / "private-functional-v1/qualify.py"
TREE = ast.parse(SOURCE.read_text())


class FakeParent:
    def __init__(self, events, census_error=False):
        self.events = events
        self.census_error = census_error

    def rmdir(self):
        self.events.append("rmdir")

    def iterdir(self):
        self.events.append("TMP_census")
        if self.census_error:
            raise PermissionError("TMP census refused")
        raise FileNotFoundError("own TMP absent")


class FakeImage:
    def __init__(self, events, census_error=False):
        self.events = events
        self.parent = FakeParent(events, census_error)

    def unlink(self, missing_ok=False):
        self.events.append("unlink")
        raise OSError("unlink refused")


class FakeReceipt:
    def __init__(self, events, name, bad=False):
        self.events, self.name, self.bad = events, name, bad

    def read_text(self):
        self.events.append("read:" + self.name)
        if self.bad:
            raise OSError("receipt read refused")
        return json.dumps(
            {"direct_child_reaped": True, "cleanup_complete": True, "remaining": []}
        )


def setup_ports(fail_writes=(), bad_receipt=False, unknown_tmp=False):
    events, saved, printed = [], {}, []

    def save(name, value):
        events.append("save:" + name)
        if name in fail_writes:
            raise OSError(name + " write refused")
        saved[name] = copy.deepcopy(value)

    def glob(pattern):
        events.append("receipt_paths")
        return [
            FakeReceipt(events, "first.process.json", bad_receipt),
            FakeReceipt(events, "second.process.json"),
        ]

    finance = SimpleNamespace(
        held=35225600,
        unknown=[{"path": "historical6aaa", "status": "UNKNOWN"}],
        check=lambda: events.append("final_finance"),
        record=lambda _: {"charged_positive_union_B": 35225600},
    )
    resources = SimpleNamespace(
        finance=finance,
        financial_errors=[],
        charge_io_errors=[],
        rss_peak=0,
        output_peak=0,
        tmp_peak=0,
    )
    namespace = {
        "datetime": datetime,
        "timezone": timezone,
        "time": SimpleNamespace(monotonic=lambda: 10.0),
        "json": json,
        "OUT": SimpleNamespace(glob=glob),
        "save": save,
        "print": lambda *args, **kwargs: printed.append(args[0]),
    }
    body = [
        n
        for n in TREE.body
        if isinstance(n, ast.FunctionDef) and n.name in {"error_fact", "finalize"}
    ]
    exec(
        compile(ast.Module(body=body, type_ignores=[]), str(SOURCE), "exec"), namespace
    )
    namespace.update(
        result={"qualified": False},
        failure=None,
        resources=resources,
        admission={"caps_B": {"positive": 39845888}},
        image=FakeImage(events, unknown_tmp),
        created_image=True,
        created_tmp=True,
        started=0.0,
    )
    return namespace, events, saved, printed


class FinalizationTests(unittest.TestCase):
    def test_actual_main_handler_unlink_failure_attempts_later_stages(self):
        ns, events, saved, _ = setup_ports()
        main = next(
            n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "main"
        )
        node = copy.deepcopy(next(n for n in main.body if isinstance(n, ast.Try)))
        node.body = [
            ast.Raise(
                exc=ast.Call(
                    func=ast.Name(id="ValueError", ctx=ast.Load()),
                    args=[ast.Constant("original primary")],
                    keywords=[],
                ),
                cause=None,
            )
        ]
        exec(
            compile(
                ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])),
                str(SOURCE),
                "exec",
            ),
            ns,
        )
        self.assertIn("rmdir", events)
        self.assertIn("receipt_paths", events)
        self.assertIn("save:charged-path-maxima.json", events)
        self.assertIn("save:result.json", events)
        result = saved["result.json"]
        self.assertEqual(result["primary_error"], "ValueError('original primary')")
        self.assertEqual(result["charged_positive_union_B"], 35225600)
        self.assertEqual(result["finalization_errors"][0]["stage"], "TMP_image_unlink")
        self.assertFalse(result["cleanup_complete"])

    def test_charge_and_result_writes_independent_and_fallback_records_unknown(self):
        ns, events, _, printed = setup_ports(
            {"charged-path-maxima.json", "result.json"}, unknown_tmp=True
        )
        ns["finalize"](
            ns["result"],
            "original primary",
            ns["resources"],
            ns["admission"],
            ns["image"],
            True,
            True,
            0.0,
        )
        self.assertIn("save:result.json", events)
        self.assertIn("rmdir", events)
        self.assertEqual(ns["result"]["primary_error"], "original primary")
        self.assertEqual(ns["result"]["charge_persistence"], "UNKNOWN")
        self.assertEqual(ns["result"]["result_persistence"], "UNKNOWN")
        self.assertEqual(ns["result"]["charged_positive_union_B"], 35225600)
        self.assertTrue(
            any(r.get("status") == "UNKNOWN" for r in ns["result"]["remaining"])
        )
        terminal = json.loads(printed[0])
        self.assertEqual(
            {e["stage"] for e in terminal["finalization_errors"]},
            {
                "TMP_image_unlink",
                "TMP_remaining_read",
                "charge_final_write",
                "result_write",
            },
        )

    def test_bad_receipt_does_not_skip_later_receipt_or_charge_result(self):
        ns, events, saved, _ = setup_ports(bad_receipt=True)
        ns["finalize"](
            ns["result"],
            "original primary",
            ns["resources"],
            ns["admission"],
            ns["image"],
            True,
            True,
            0.0,
        )
        self.assertIn("read:second.process.json", events)
        self.assertIn("save:charged-path-maxima.json", events)
        self.assertIn("save:result.json", events)
        self.assertFalse(saved["result.json"]["all_direct_children_reaped"])
        self.assertTrue(
            any(x.get("status") == "UNKNOWN" for x in saved["result.json"]["remaining"])
        )

    def test_actual_resource_check_keeps_financial_error_and_charge_io_separate(self):
        class Base:
            def __init__(self, *args):
                pass

            def check(self, owned=()):
                pass

        def financial_check():
            raise PermissionError("financial stat refused")

        def refused_save(*args):
            raise OSError("charge write refused")

        ns, _, _, _ = setup_ports()
        ns.update(
            P=SimpleNamespace(CycleResources=Base, process_info=lambda _: None),
            OUT=None,
            os=SimpleNamespace(getpid=lambda: 1),
            MIB=1024**2,
            FinancialRetention=lambda _: SimpleNamespace(
                check=financial_check, record=lambda _: {}
            ),
            save=refused_save,
        )
        node = next(
            n
            for n in TREE.body
            if isinstance(n, ast.ClassDef) and n.name == "Resources"
        )
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(SOURCE), "exec"), ns)
        resource = ns["Resources"]({})
        with self.assertRaisesRegex(PermissionError, "financial stat refused"):
            resource.check()
        self.assertEqual(resource.financial_errors[0]["stage"], "financial_stat")
        self.assertEqual(resource.charge_io_errors[0]["stage"], "charge_write")
        self.assertEqual(resource.charge_io_errors[0]["type"], "OSError")


if __name__ == "__main__":
    unittest.main()
