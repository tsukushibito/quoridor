"""Affected new software-controller failure controls; actual AST, fake ports."""

import ast
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import unittest

SOURCE = Path(__file__).parent / "worker.py"
TREE = ast.parse(SOURCE.read_text())


def functions(names, ports):
    nodes = [n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name in names]
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(SOURCE), "exec"), ports)
    return ports


class ControllerTests(unittest.TestCase):
    def test_launch_format_or_preflight_refusal_never_submits(self):
        tree = ast.parse((SOURCE.parent / "launch.py").read_text())
        node = next(
            n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "main"
        )
        admission = {"proof_path": "/proof"}
        raw = json.dumps(admission).encode()
        digest = hashlib.sha256(raw).hexdigest()
        job = {
            "argv": ["/python", "-B", "/owned/worker.py", digest],
            "resource_contract": "/proof",
        }

        class FakePath:
            def __init__(self, name="/owned"):
                self.name = name

            def __truediv__(self, name):
                return FakePath(self.name + "/" + name)

            def __str__(self):
                return self.name

            def exists(self):
                return False

            def read_bytes(self):
                return (
                    raw
                    if self.name.endswith("admission.json")
                    else json.dumps(job).encode()
                )

            def write_text(self, _):
                pass

        for refused in range(4):
            calls = []

            def run(argv, **kwargs):
                self.assertTrue(kwargs["check"])
                calls.append(argv)
                if len(calls) == refused + 1:
                    raise OSError("ordered check refused")

            ports = {
                "OUT": FakePath(),
                "subprocess": SimpleNamespace(run=run),
                "sys": SimpleNamespace(executable="/python"),
                "json": json,
                "hashlib": hashlib,
                "os": SimpleNamespace(environ={}),
            }
            exec(
                compile(
                    ast.Module(body=[node], type_ignores=[]),
                    str(SOURCE.parent / "launch.py"),
                    "exec",
                ),
                ports,
            )
            with self.assertRaisesRegex(OSError, "ordered check refused"):
                ports["main"]()
            self.assertFalse(any("submit" in argv for argv in calls))

    def test_execute_registers_attempt_before_prelaunch_failure(self):
        resources = SimpleNamespace(attempts=[])

        def fail(*args, **kwargs):
            self.assertEqual(resources.attempts[0]["argv"], ["cargo", "test"])
            raise OSError("prelaunch refused")

        ports = functions(
            {"execute"}, {"OUT": Path("/owned"), "P": SimpleNamespace(execute=fail)}
        )
        with self.assertRaisesRegex(OSError, "prelaunch refused"):
            ports["execute"]("arena-build", ["cargo", "test"], resources)
        self.assertEqual(len(resources.attempts), 1)

    def test_failed_missing_census_and_final_io_preserve_primary_unknown(self):
        saved, calls = {}, []

        def save(name, value):
            calls.append(name)
            if name == "observed-owned-charges.json":
                raise OSError("charge write refused")
            saved[name] = copy.deepcopy(value)

        class Output:
            def glob(self, _):
                return []

        class FakePath:
            def __init__(self, _):
                pass

            def exists(self):
                return False

            def read_bytes(self):
                raise FileNotFoundError("receipt absent")

        resources = SimpleNamespace(
            attempts=[
                {
                    "name": "arena-build",
                    "argv": ["cargo", "test"],
                    "receipt": "/owned/arena-build.process.json",
                }
            ],
            peaks={"target": 4096},
            admission={"temporary": "/owned/tmp", "source_bindings": {}},
            check=lambda: calls.append("allocation_final"),
        )
        ports = functions(
            {"terminal"},
            {
                "OUT": Output(),
                "Path": FakePath,
                "save": save,
                "verify": lambda _: None,
                "datetime": datetime,
                "timezone": timezone,
                "json": json,
                "print": lambda *a, **kw: None,
            },
        )
        result = {"software_complete": True}
        self.assertFalse(
            ports["terminal"](
                result, {"type": "OSError", "message": "primary"}, resources
            )
        )
        r = saved["result.json"]
        self.assertFalse(r["software_complete"])
        self.assertFalse(r["cleanup_complete"])
        self.assertEqual(r["primary_error"]["message"], "primary")
        self.assertEqual(r["held_allocation_maxima_B"], {"target": 4096})
        self.assertIn("result.json", calls)
        self.assertTrue(any(x.get("status") == "UNKNOWN" for x in r["remaining"]))
        self.assertTrue(
            any(x["stage"] == "charges_write" for x in r["finalization_errors"])
        )

    def test_prepared_entry_refuses_before_any_input_or_physics(self):
        ports = functions({"validate"}, {})
        with self.assertRaisesRegex(ValueError, "prepared metadata"):
            ports["validate"]({"actual_entry": False, "prepared_only": True})


if __name__ == "__main__":
    unittest.main()
