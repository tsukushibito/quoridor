"""Current binding/physical checks for this finite repair, without submitting a job."""

import fcntl
import hashlib
import json
import os
from pathlib import Path

import worker as W


OUT = Path(__file__).resolve().parent


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verify():
    admission = json.loads((OUT / "admission.json").read_text())
    assert admission["admission"] is True
    assert admission["related_review"]["blockers"] == 0
    assert admission["related_review"]["actual_reader_STOP"]
    assert admission["peer332_actual_STOP"]
    assert admission["source_control_review"]["inclusive_forecast_B"] <= 7 * 1024**2
    for path, expected in admission["bindings"].items():
        assert sha(path) == expected, path
    packet = json.loads(Path(admission["source_stop"]).read_text())
    for path, row in packet["stopped_sources"].items():
        assert sha(W.WT / path) == row["SHA256"]
        assert (W.WT / path).stat().st_mode & 0o777 == row["mode"]
    for row in packet["unchanged_dependency_bindings"]:
        assert sha(W.WT / row["path"]) == row["SHA256"]
    rows = json.loads((OUT / "named-entry-snapshot.json").read_text())[
        "named_before_rows"
    ]
    allowed = set(admission["deliberate_owned_reconstruction"]["paths"])
    assert allowed == set(), "every initial named output must exist"
    for row in rows:
        try:
            assert sha(row["path"]) == row["SHA256"]
            assert Path(row["path"]).stat().st_blocks * 512 == row["allocated_B"]
        except FileNotFoundError:
            assert row["path"] in allowed
    W.quiet()
    assert W.P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 128 * 1024**2
    for name in ["tmp", "private"]:
        (OUT / name).mkdir(exist_ok=True)
    baseline = json.loads((W.OLD / "named-baseline.json").read_text())
    initial = json.loads((W.OLD / "result.json").read_text())
    resource = W.Resources(
        {r["path"]: r["allocated_B"] for r in baseline["rows"]},
        packet["source_positive_allocated_growth_B"],
        initial["named_paths"],
    )
    resource.check()
    with (W.G.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    return True
