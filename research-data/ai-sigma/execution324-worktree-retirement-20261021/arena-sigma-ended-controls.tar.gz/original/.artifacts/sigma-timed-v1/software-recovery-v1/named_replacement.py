"""Exact owned artifact replacement accounting; absent bytes never become credit."""

from pathlib import Path


class NamedArtifactUnknown(RuntimeError):
    pass


class NamedReplacement:
    def __init__(self, original_baseline, prior_rows, known_missing):
        self.baseline = original_baseline
        self.prior = {row["path"]: row["allocated_B"] for row in prior_rows}
        self.known_missing = set(known_missing)
        if not self.known_missing <= self.prior.keys():
            raise NamedArtifactUnknown(
                "missing reconstruction lacks retained allocation"
            )
        self.outputs = set(self.prior)
        self.lease = set()
        self.state = "preparation"
        self.events = []

    def begin(self, exact_outputs):
        if self.state != "preparation":
            raise NamedArtifactUnknown("overlapping output replacement lease")
        self.lease = set(exact_outputs)
        if not self.lease <= self.prior.keys():
            raise NamedArtifactUnknown("replacement lease names an unbound old output")
        self.state = "running"

    def finish(self):
        # Closing the lease precedes final measurement; every emitted output
        # must exist at the terminal boundary, regardless of the prior charge.
        self.state = "terminal"
        self.lease.clear()
        self.known_missing.clear()

    def charge(self, live_owned_compiler=False, stat_path=None):
        stat_path = stat_path or (lambda path: Path(path).stat())
        total = 0
        seen = set()
        for path in sorted(self.outputs):
            previous = self.prior.get(path, 0)
            try:
                info = stat_path(path)
            except FileNotFoundError as error:
                reconstructing = (
                    self.state == "preparation" and path in self.known_missing
                )
                replacing = (
                    self.state == "running"
                    and path in self.lease
                    and live_owned_compiler
                )
                if not (reconstructing or replacing):
                    raise NamedArtifactUnknown(
                        "named output absent outside exact owned lease: " + path
                    ) from error
                # Missing is retained as an explicit reconstruction obligation,
                # not a within-output or qualification result. It cannot refund
                # an artifact retained by the prior compile.
                amount = previous
                key = ("missing-retained", path)
                event = {"path": path, "retained_B": previous, "state": self.state}
                if event not in self.events:
                    self.events.append(event)
            except OSError as error:
                raise NamedArtifactUnknown(
                    "named output stat error: " + path
                ) from error
            else:
                amount = max(previous, info.st_blocks * 512)
                key = (info.st_dev, info.st_ino)
            if key not in seen:
                seen.add(key)
                total += max(0, amount - self.baseline.get(path, 0))
        return total
