"""Tiny control-only fixtures; no Cargo/process/model invocation."""

import unittest
from types import SimpleNamespace

from named_replacement import NamedArtifactUnknown, NamedReplacement


class ReplacementTests(unittest.TestCase):
    def ledger(self, missing=()):
        return NamedReplacement(
            {"owned": 4096}, [{"path": "owned", "allocated_B": 8192}], missing
        )

    @staticmethod
    def absent(_path):
        raise FileNotFoundError

    def test_exact_owned_missing_is_charged_during_live_replacement(self):
        ledger = self.ledger()
        ledger.begin(["owned"])
        self.assertEqual(ledger.charge(True, self.absent), 4096)
        self.assertEqual(ledger.events[0]["retained_B"], 8192)

    def test_unrelated_or_no_live_owner_missing_refuses(self):
        ledger = self.ledger()
        ledger.begin(["owned"])
        with self.assertRaises(NamedArtifactUnknown):
            ledger.charge(False, self.absent)
        ledger.outputs.add("foreign")
        with self.assertRaises(NamedArtifactUnknown):
            ledger.charge(True, self.absent)

    def test_terminal_absence_refuses_even_after_known_reconstruction(self):
        ledger = self.ledger(["owned"])
        self.assertEqual(ledger.charge(False, self.absent), 4096)
        ledger.begin(["owned"])
        ledger.finish()
        with self.assertRaises(NamedArtifactUnknown):
            ledger.charge(True, self.absent)

    def test_small_restored_output_cannot_release_previous_charge(self):
        ledger = self.ledger()
        info = SimpleNamespace(st_dev=1, st_ino=2, st_blocks=8)
        self.assertEqual(ledger.charge(False, lambda _path: info), 4096)


if __name__ == "__main__":
    unittest.main()
