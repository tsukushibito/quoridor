"""Finite NN0 lint recovery; preserve initial artifacts and reuse bound exact cleanup."""

import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
WT = ROOT.parents[1]
OLD = ROOT / "software-v1"
SPEC = importlib.util.spec_from_file_location("sigma_initial_guard", OLD / "worker.py")
G = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(G)
G.OUT = OUT
P = G.P


def quiet():
    G.quiet()
    markers = [
        "quoridor_training.train",
        "quoridor_training.sigma_reference",
        "numeric-worker",
        "numeric_worker",
        "observation-entry-v1/worker",
        "trainer.py",
    ]
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            argv = (entry / "cmdline").read_bytes().split(b"\0")
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not argv or not Path(os.fsdecode(argv[0])).name.startswith("python"):
            continue
        # Match executable script/module arguments, not shell -c source text.
        args = [os.fsdecode(x) for x in argv[1:] if x and not x.startswith(b"-")]
        if any(mark in arg for arg in args for mark in markers):
            raise P.CycleStopped("foreign numerical identity: " + entry.name)


def save(name, obj):
    G.save(name, obj)


class Resources(G.Resources):
    def __init__(self, baseline, source_growth, initial_named):
        super().__init__(baseline, source_growth)
        self.named.update(initial_named)
        self.growth_peak = 18644992  # Retain the first phase charge, never refund it.

    def check(self, owned=()):
        P.CycleResources.check(self, owned)
        self.emitted()
        infos = [P.process_info(os.getpid())]
        infos.extend(P.process_info(m["pid"]) for m in owned)
        ram = sum(x["rss"] for x in infos if x) + 64 * 1024**2
        self.ram_peak = max(self.ram_peak, ram)
        if ram > 2 * 1024**3:
            raise P.CycleStopped("family RAM including controller exceeds2GiB")
        seen = set()
        growth = 0
        for path in self.named:
            try:
                info = Path(path).stat()
            except FileNotFoundError as error:
                raise P.CycleStopped("named artifact disappeared: UNKNOWN") from error
            identity = (info.st_dev, info.st_ino)
            if identity not in seen:
                growth += max(0, info.st_blocks * 512 - self.baseline.get(path, 0))
                seen.add(identity)
        growth = max(growth, 18644992)
        tmp = G.allocated(OLD / "tmp") + G.allocated(OUT / "tmp")
        private = G.allocated(OLD / "private") + G.allocated(OUT / "private")
        self.growth_peak = max(self.growth_peak, growth)
        self.tmp_peak = max(self.tmp_peak, tmp)
        self.private_peak = max(self.private_peak, private)
        if growth > 20 * 1024**2 or tmp > 8 * 1024**2 or private > 15 * 1024**2:
            raise P.CycleStopped(
                "Sigma recovery named-growth/TMP/private component cap"
            )
        if growth + tmp + private > 45 * 1024**2:
            raise P.CycleStopped("Sigma recovery build/private/TMP whole45MiB cap")
        control = G.allocated(ROOT) - tmp - private + self.source_growth
        if control > 4497408:
            raise P.CycleStopped("Sigma recovery inclusive source forecast exceeded")


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(WT)
    admission = json.loads((OUT / "admission.json").read_text())
    for path, expected in admission["bindings"].items():
        assert G.sha(path) == expected, path
    packet = json.loads(Path(admission["source_stop"]).read_text())
    for relative, row in packet["stopped_sources"].items():
        path = WT / relative
        assert G.sha(path) == row["SHA256"], relative
        assert path.stat().st_mode & 0o777 == row["mode"]
    for row in packet["unchanged_dependency_bindings"]:
        assert G.sha(WT / row["path"]) == row["SHA256"]
    forecast = json.loads((ROOT / "software-recovery-prewrite-v1.json").read_text())
    for row in forecast["named_before_rows"]:
        assert G.sha(row["path"]) == row["SHA256"], row["path"]
        assert Path(row["path"]).stat().st_blocks * 512 == row["allocated_B"]
    assert P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 128 * 1024**2
    quiet()
    for name in ["tmp", "private"]:
        (OUT / name).mkdir(exist_ok=True)
    os.environ.update(
        CARGO_TARGET_DIR=str(G.TARGET),
        CARGO_INCREMENTAL="0",
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        TMPDIR=str(OUT / "tmp"),
        CUDA_VISIBLE_DEVICES="",
        RUST_TEST_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
        CARGO_TERM_COLOR="never",
    )
    for name in [
        "RUSTFLAGS",
        "CARGO_ENCODED_RUSTFLAGS",
        "QUORIDOR_BENCH_MANIFEST",
        "QUORIDOR_BENCH_FT_MODE",
    ]:
        os.environ.pop(name, None)
    baseline = json.loads((OLD / "named-baseline.json").read_text())
    original = json.loads((OLD / "result.json").read_text())
    resources = Resources(
        {r["path"]: r["allocated_B"] for r in baseline["rows"]},
        packet["source_positive_allocated_growth_B"],
        original["named_paths"],
    )
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "private": {},
        "models_nn_ft_calls": 0,
        "scientific_games": 0,
        "source_stop_SHA256": G.sha(admission["source_stop"]),
        "qualified_native_clock": False,
        "continuous_storage_peak": "UNKNOWN",
    }
    started = time.monotonic()

    def command(name, argv, cargo_json=False):
        quiet()
        log = OUT / (name + ".log")
        record = P.execute(argv, log, None, resources=resources)
        result["commands"].append({"name": name, **record})
        assert record["log_bytes_seen"] <= P.LOG_MAX_BYTES, "provenance log truncated"
        rows = (
            [
                json.loads(line)
                for line in log.read_text().splitlines()
                if line.startswith("{")
            ]
            if cargo_json
            else []
        )
        resources.emitted()
        resources.check()
        return rows

    def packed(label, image, upper):
        raw = Path(image).read_bytes()
        blob = gzip.compress(raw, mtime=0)
        assert len(blob) <= upper
        assert gzip.decompress(blob) == raw
        path = OUT / "private" / (label + ".gz")
        path.write_bytes(blob)
        result["private"][label] = {
            "path": str(path),
            "gzip_SHA256": G.sha(path),
            "gzip_bytes": len(blob),
            "ELF_SHA256": hashlib.sha256(raw).hexdigest(),
            "ELF_bytes": len(raw),
            "mode": Path(image).stat().st_mode & 0o777,
            "roundtrip": True,
        }
        resources.check()

    failure = None
    with (G.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet()
        resources.check()
        try:
            # Only the changed owned package is refreshed. Unchanged libs retain the
            # initial fresh=false byte/compiler proofs, not a name-based inference.
            lib = WT / "crates/quoridor-runner/src/lib.rs"
            before = G.sha(lib)
            old = lib.stat().st_mtime_ns
            os.utime(lib, ns=(lib.stat().st_atime_ns, time.time_ns()))
            assert G.sha(lib) == before
            save(
                "owned-freshness.json",
                {
                    "path": str(lib),
                    "SHA256": before,
                    "old_mtime_ns": old,
                    "new_mtime_ns": lib.stat().st_mtime_ns,
                },
            )
            command("compiler", ["/usr/local/cargo/bin/rustc", "-Vv"])
            rows = command(
                "release",
                [
                    G.CARGO,
                    "build",
                    *G.BASE,
                    "--release",
                    "-p",
                    "quoridor-runner",
                    "--bin",
                    "quoridor-runner",
                    "--message-format=json",
                ],
                True,
            )
            own = [
                r
                for r in rows
                if r.get("reason") == "compiler-artifact"
                and r.get("target", {}).get("src_path", "").startswith(str(WT) + "/")
            ]
            for name in ["quoridor_runner", "quoridor-runner"]:
                assert any(
                    r["target"]["name"] == name and not r["fresh"] for r in own
                ), name
            save(
                "release-own-payloads.json",
                [
                    {
                        "target": r["target"],
                        "profile": r["profile"],
                        "fresh": r["fresh"],
                        "payloads": [
                            {
                                "path": p,
                                "SHA256": G.sha(p),
                                "allocated_B": Path(p).stat().st_blocks * 512,
                            }
                            for p in r["filenames"]
                        ],
                    }
                    for r in own
                ],
            )
            runner = next(
                r["executable"] for r in own if r["target"]["name"] == "quoridor-runner"
            )
            packed("quoridor-runner", runner, 3 * 1024**2)
            rows = command(
                "caller-build",
                [
                    G.CARGO,
                    "test",
                    *G.BASE,
                    "--release",
                    "-p",
                    "quoridor-runner",
                    "--lib",
                    "--no-run",
                    "--message-format=json",
                ],
                True,
            )
            images = [
                r
                for r in rows
                if r.get("reason") == "compiler-artifact"
                and r.get("executable")
                and r.get("profile", {}).get("test")
            ]
            assert len(images) == 1 and not images[0]["fresh"]
            packed("caller", images[0]["executable"], 2 * 1024**2)
            # Decode only this one immutable test image; remove only our new
            # decode after exactwait, leaving every initial image intact.
            image = OUT / "tmp" / "caller"
            image.write_bytes(
                gzip.decompress((OUT / "private" / "caller.gz").read_bytes())
            )
            image.chmod(result["private"]["caller"]["mode"])
            assert G.sha(image) == result["private"]["caller"]["ELF_SHA256"]
            try:
                command(
                    "closedreceiver-fixture",
                    [
                        str(image),
                        "runtime::sigma_reply_tests::queued_cancel_and_abandoned_request_each_have_one_terminal_reply",
                        "--exact",
                        "--nocapture",
                        "--test-threads=1",
                    ],
                )
            finally:
                image.unlink()  # New owned decoder only, not retained artifact.
            command(
                "clippy",
                [
                    G.CARGO,
                    "clippy",
                    *G.BASE,
                    "-p",
                    "quoridor-runner",
                    "--lib",
                    "--bin",
                    "quoridor-runner",
                    "--test",
                    "arena",
                    "--test",
                    "sigma_clock",
                    "--message-format=json",
                    "--",
                    "-Dwarnings",
                ],
                True,
            )
        except BaseException as error:
            failure = str(error)
        finally:
            result.update(
                stopped=datetime.now(timezone.utc).isoformat(),
                whole_seconds=time.monotonic() - started,
                failure=failure,
                named_paths=sorted(resources.named),
                sampled_peaks={
                    "family_RAM_B": resources.ram_peak,
                    "positive_artifact_growth_B": resources.growth_peak,
                    "TMP_B": resources.tmp_peak,
                    "private_B": resources.private_peak,
                },
            )
            save("result.json", result)
    if failure:
        raise SystemExit(failure)


if __name__ == "__main__":
    main()
