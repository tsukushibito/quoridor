"""Only the new financial forwarding boundary; no runtime imports or actual IO."""

import ast
import copy
from pathlib import Path
import unittest
import stat
from types import SimpleNamespace


class Forwarding(unittest.TestCase):
    def setUp(self):
        source = ast.parse(Path(__file__).with_name("qualify.py").read_text())
        node = next(
            n
            for n in source.body
            if isinstance(n, ast.ClassDef) and n.name == "RetainedRecords"
        )
        self.state = {
            "original_baseline_SHA256": "86b76641353ecf4c5a0107522f97a308b68981a733fc8279fddb504a6312430d",
            "charged_positive_union_B": 35225600,
            "allocation_max_B": {
                "/workspaces/quoridor/.artifacts/rust-migration/target/release/deps/libquoridor_runner-6aaa82ac9921176f.rlib": 9236480
            },
        }
        self.a = {
            "retained_observed_record": "record",
            "original_baseline_path": "baseline",
            "original_baseline_SHA256": self.state["original_baseline_SHA256"],
            "proof_path": "proof",
            "software_retention_upper_B": 1101340672,
        }
        proof = {
            "future_phase_support": [
                {"issue": "quoridor-4lc.331", "inclusive_bytes": 4294967296}
            ],
            "legacy_coverage": {"conservative_held_bytes": 13421772800},
        }
        self.records = {"record": self.state, "baseline": {"rows": []}, "proof": proof}
        self.reads = []

        def bound(a, path):
            self.reads.append(path)
            return copy.deepcopy(self.records[path])

        namespace = {
            "bound_json": bound,
            "Path": Path,
            "copy": copy,
            "PROFILE": "current-e4b-private-functional-four-v1",
        }
        exec(
            compile(
                ast.Module(body=[node], type_ignores=[]),
                "actual-RetainedRecords",
                "exec",
            ),
            namespace,
        )
        self.R = namespace["RetainedRecords"]

    def test_forward_exact_without_legacy_stat_or_rebase(self):
        record = self.R(self.a)
        carried = record.record(self.a)
        self.assertEqual(carried["allocation_max_B"], self.state["allocation_max_B"])
        self.assertEqual(record.held, 35225600)
        self.assertEqual(self.reads, ["record", "baseline", "proof"])
        self.assertIn("UNQUALIFIED", carried["legacy_actual_storage"])
        self.assertEqual(carried["software_phase_retention_upper_B"], 1101340672)

    def test_bad_baseline_charge_namespace_and_proof_refuse(self):
        mutations = [
            lambda: self.state.update(charged_positive_union_B=35225599),
            lambda: self.state.update(charged_positive_union_B=True),
            lambda: self.state.update(original_baseline_SHA256="wrong"),
            lambda: self.state["allocation_max_B"].update({"/foreign/rlib": 1}),
            lambda: self.state["allocation_max_B"].update(
                {"/workspaces/quoridor/.artifacts/rust-migration/target/../foreign": 1}
            ),
            lambda: self.state["allocation_max_B"].update(
                {next(iter(self.state["allocation_max_B"])): 9236479}
            ),
            lambda: self.records["proof"]["future_phase_support"][0].update(
                inclusive_bytes=4294967295
            ),
        ]
        for mutation in mutations:
            self.setUp()
            mutation()
            with self.assertRaises(ValueError):
                self.R(self.a)


class BindingSchema(unittest.TestCase):
    def setUp(self):
        source = ast.parse(Path(__file__).with_name("qualify.py").read_text())
        validate = next(
            n
            for n in source.body
            if isinstance(n, ast.FunctionDef) and n.name == "validate"
        )
        loop = next(
            n
            for n in validate.body
            if isinstance(n, ast.For) and ast.unparse(n.iter) == "a['bindings'].items()"
        )
        worker = (
            Path(__file__).parent.parent
            / "current-compiler-software-recovery-v2/worker.py"
        )
        verifier = next(
            n
            for n in ast.parse(worker.read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == "verify"
        )
        self.calls = []
        outer = self

        class FakePath:
            def __init__(self, name):
                self.name = name

            def lstat(self):
                outer.calls.append(("lstat", self.name))
                return SimpleNamespace(st_mode=stat.S_IFREG | 420, st_size=11)

        def digest(path):
            name = path.name if isinstance(path, FakePath) else path
            self.calls.append(("sha", name))
            return "matching"

        ports = {"Path": FakePath, "stat": stat, "sha": digest}
        exec(
            compile(
                ast.Module(body=[verifier], type_ignores=[]),
                "actual-maintained-verify",
                "exec",
            ),
            ports,
        )

        class Control:
            verify = staticmethod(ports["verify"])
            sha = staticmethod(digest)

        namespace = {
            "S": Control,
            "validate_inputs": lambda a: self.fail(
                "prepared refusal must precede input reads"
            ),
        }
        function = ast.FunctionDef(
            name="check_loop",
            args=ast.arguments(
                posonlyargs=[],
                args=[ast.arg(arg="a")],
                kwonlyargs=[],
                kw_defaults=[],
                defaults=[],
            ),
            body=[loop, ast.Return(value=ast.Constant(value=True))],
            decorator_list=[],
        )
        tree = ast.fix_missing_locations(
            ast.Module(body=[function, validate], type_ignores=[])
        )
        exec(compile(tree, "actual-validate-binding-loop", "exec"), namespace)
        self.check, self.validate = namespace["check_loop"], namespace["validate"]

    def test_matching_typed_and_digest_pass(self):
        typed = {"SHA256": "matching", "mode": 420, "bytes": 11}
        self.assertIs(
            self.check({"bindings": {"dependency": typed, "raw": "matching"}}), True
        )
        self.assertEqual(
            self.calls, [("lstat", "dependency"), ("sha", "dependency"), ("sha", "raw")]
        )

    def test_mismatch_or_unsupported_refuses(self):
        for binding in [
            {"SHA256": "wrong", "mode": 420, "bytes": 11},
            {"SHA256": "matching", "mode": 493, "bytes": 11},
            {"SHA256": "matching", "mode": 420, "bytes": 12},
            {},
            "wrong",
            ["matching"],
        ]:
            with self.assertRaises((ValueError, KeyError)):
                self.check({"bindings": {"dependency": binding}})

    def test_prepared_false_refuses_before_any_io(self):
        with self.assertRaisesRegex(ValueError, "prepared controls"):
            self.validate({"actual_entry": False, "prepared_only": True})
        self.assertEqual(self.calls, [])


if __name__ == "__main__":
    unittest.main()
