"""Literal NN0 expectations for the compiled arena --recover adapter, not games."""

import copy
import hashlib
import json
from pathlib import Path

# Field order follows the bound Rust Serialize definitions. No rule replay here.
CONFIG = "ruleset run_id output games workers active_games max_batch simulations max_plies seed opening_plies openings cpu_cores inference_cpu_core engines inference wall_seconds host_ram_reserve max_memory_bytes max_output_bytes pause_file deadline_unix_ms train_games validation_games temperature mcts_max_nodes mcts_max_bytes cycle arena".split()
ENGINE = "kind model distance_a distance_b depth max_nodes time_ms simd".split()
INFERENCE = "backend model model_sha library device cuda_graph".split()
ARENA = "comparison clock_policy return_reserve_ms tt_entries bootstrap_seed bootstrap_resamples evaluator_sha256 search_source_sha256 book".split()
BOOK = "id usage frozen_before_candidate_results independence openings".split()
OPENING = "id cohort lineage siblings original_seed reference selection_reason candidate_pool_size prefix".split()
SLOT = "game family candidate_color cohort lineage opening replay replay_error reference_q_stm reference_q_band".split()


def ordered(value, fields):
    if set(value) != set(fields):
        raise ValueError("fixture schema fields differ")
    return {name: value[name] for name in fields}


def config_serialized(config, legacy=False):
    c = copy.deepcopy(config)
    c["engines"] = [ordered(e, ENGINE) for e in c["engines"]]
    c["inference"] = ordered(c["inference"], INFERENCE)
    b = c["arena"]["book"]
    b["openings"] = [ordered(o, OPENING) for o in b["openings"]]
    c["arena"]["book"] = ordered(b, BOOK)
    c["arena"] = ordered(c["arena"], ARENA)
    return ordered(c, CONFIG[1:] if legacy else CONFIG)


def digest(value):
    raw = json.dumps(
        value, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode()
    return hashlib.sha256(raw).hexdigest()


def make_fixture(config, extra=False, wrong_ply=False):
    prefix = [13, 67, 4, 76, 13, 67, 4, 76] + ([13] if extra else [])
    c = copy.deepcopy(config)
    c["run_id"] = "NN0-replay-postterminal" if extra else "NN0-replay-third"
    if wrong_ply:
        c["run_id"] += "-deliberately-wrong-expectation"
    c["max_plies"] = 9
    c["arena"]["book"]["id"] = c["run_id"]
    c["arena"]["book"]["openings"][0].update(
        id=c["run_id"],
        prefix=prefix,
        selection_reason="Literal adapter assertion only; no runtime game, model or outcome was generated.",
    )
    history = [
        ["4,0|4,7|1|||10,10", 2],
        ["4,0|4,8|0|||10,10", 3],
        ["4,1|4,7|0|||10,10", 2],
        ["4,1|4,8|1|||10,10", 2],
    ]
    replay = {
        "pawns": [4, 76],
        "walls_left": [10, 10],
        "horizontal": 0,
        "vertical": 0,
        "turn": 0,
        "winner": None,
        "total_ply": 9 if wrong_ply else 8,
        "terminal_value_stm": 0.0,
        "history": history,
        "prefix_sha256": digest(prefix),
        "history_sha256": digest(history),
        "immediate_winning_actions": [],
    }
    slots = []
    for color in range(2):
        slots.append(
            ordered(
                {
                    "game": color,
                    "family": c["run_id"] + "-family-000000",
                    "candidate_color": color,
                    "cohort": "TacticalDiagnostic",
                    "lineage": c["arena"]["book"]["openings"][0]["lineage"],
                    "opening": prefix,
                    "replay": None if extra else replay,
                    "replay_error": "prefix replay: GAME_OVER" if extra else None,
                    "reference_q_stm": None,
                    "reference_q_band": None,
                },
                SLOT,
            )
        )
    return {
        "fixture_only": "EXPECTED/UNEXECUTED; not an actual manifest-start or game evidence",
        "config": c,
        "planned_slots": slots,
        "config_sha256": digest(config_serialized(c)),
        "planned_sha256": digest(slots),
    }


def prepare(out):
    # Before using this encoding, reproduce one retained historical Rust digest.
    root = out.parent
    old = json.loads(
        (root / "live-qualification-v2/run-initial/manifest-start.json").read_text()
    )
    if digest(config_serialized(old["config"], legacy=True)) != old["config_sha256"]:
        raise ValueError("historical Rust serialization calibration refused")
    config = json.loads((out / "config-initial.json").read_text())
    for name, extra, wrong in [
        ("terminal", False, False),
        ("postterminal", True, False),
        ("wrong-terminal-ply", False, True),
    ]:
        (out / ("NN0-" + name + ".expected.json")).write_text(
            json.dumps(make_fixture(config, extra, wrong), indent=2) + "\n"
        )


if __name__ == "__main__":
    prepare(Path(__file__).resolve().parent)
