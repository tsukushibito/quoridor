# Retained production caller: bounded qualification reuse assessment

**Recommendation: the immutable 1.98 production runner is a legitimate candidate for the NEW four one-ply functional slots, independently of the six unfinished software-tail checks. No new production build is required by the identified arena assertion. This is a source/evidence assessment, not live admission or qualification.**

The arena test remains NOT_RUN and the four Clippy checks remain NOT_RUN. They are not waived, passed, or retrospectively completed. The full software plan/task remains incomplete. Actual entry has unresolved resource/control and current runtime/model/backend obligations below.

## Version and executable evidence

The main intake reports all32 stopped path SHA/modes equal producer source8624a7e6; execution reports integration commitcc07bcd. Corefd35/runtime5c862/data42dc/arena80ba are the retained version. The 9cb release and caller builds returned exit0; their own compiler-artifact receipts bind source/target/features/profile and fresh=false for the production runner and caller harness. The later arena build was interrupted by the missing dependency lease, not by a production compiler error. Outer9cb remains FAILED.

| Artifact            | Immutable receipt                                                                                       |
| ------------------- | ------------------------------------------------------------------------------------------------------- |
| Production runner   | gzip ed964e3a… /2259203B; ELF155bd9346977639dccc496d75c7eb3d6cf3e10473dc7de73f6000fd267cc9188 /6382688B |
| Library test caller | gzip d08cc65b… /1755837B; ELFdf9f525b7f6e5cee98205344d0177c0a5d1fe19b0454bd3360651b21cfc662bd /4708224B |

The production CLI runner is the actual operational entry. The caller artifact is a test harness, not a separate production searcher. Retained receipts previously verified packing/roundtrip; this assessment reads receipts/logs only, not those binary payloads. Future entry must independently check exact gzip/decoded SHA/mode and runtime dependencies.

An installed Rust1.99 compiler does not force invoking Cargo to execute an already linked1.98 program. It neither certifies nor invalidates that program's current-kernel/backend compatibility. No1.99 rlib compatibility is assumed.

## Exact pending arena1 assertions

The sole selected arena filter is research_threefold_replay_enters_legal_third_and_refuses_postterminal, tests/arena.rs:252:

1. Replay legal prefix [13,67,4,76,13,67,4,76] under Standard2pThreefold succeeds.
2. Replay.total_ply=8.
3. Replay.terminal_value_stm=Some(0).
4. Replay.winner=None.
5. Sum of serialized replay.history occurrence counts=9.
6. Appending13 after that terminal returns Err.

The additional boundary is the **arena Replay adapter's output fields/serialized counted history**, not a different rules engine. Production arena.rs:319 delegates construction to SigmaContext::from_prefix_with_rules, maps position/total_ply/terminal directly, and serializes history_counts. Its immediate-win list is empty on terminal. This source wiring is already source-reviewed; these exact six adapter assertions have not been executed.

Core research_threefold_legal_third_return_and_undo PASS proves initial1, second nonterminal, third legal arrival, draw0, post-terminal rejection and restored parent. Core boundary/identity/normal-history tests also PASS. AI6 PASS covers alpha/MCTS terminal bypass, full-history TT distinction, reversible error/cancel and canonical200 terminal/censor behavior. Caller research_threefold_real_boundary_records_and_stm_labels PASS replays actual200 nonrepeat/repeat/goal fixtures and checks goal/draw/censored outcomes plus STM labels. These do not turn the adapter test into PASS.

## Why four slots can be independently assessed

The accepted operational roots are exactly [] and [13], one additional move for each colour: two Sigma and two NNUE windows. Total-history max_plies must be1 and2 respectively. Neither starting history nor a single legal move can form a third occurrence or a goal. These endpoints should remain nonterminal and be censored UNKNOWN at the cap, never draw/z0. Internal search may encounter terminal branches; the existing AI/core executable tests cover that canonical behavior, with actual model/caller runtime still to be checked.

The four live records can check the adapter at their actual roots and resulting one-move histories: pawns/stocks/walls/STM, prefix/rules/history hashes, total_ply, sum of occurrences=prefix length+1, nonterminal value, accepted legal move, and unchanged parent. Compare durable outcomes/manifest/planned data and NN0 audit/recovery under the same ruleset. Strict deadline/error/cancel/no-completion/late outcomes remain typed; no success rescue from prior completed work. A returned operational failure does not automatically qualify the caller.

The four-slot census is not a threefold-adapter terminal test, comprehensive fault injection, native numerical rerun, training result or strength sample. No arena1 assertion may be claimed exercised by one-ply records. Do not promote this assessment into full16 readiness.

If comprehensive terminal adapter execution is required before16, retain the exact uncovered arena assertions above. A prospective NN0 fixture through the existing production audit/recovery interface could be assessed as an equivalent adapter check without rebuilding, but it needs its own genuine input/manifest/assertion bindings and supported entry. It has not been designed or run here. Do not fabricate journal success or use a terminal fixture as a scientific game.

## Outstanding admission conditions, separate from compiler tail

- New config/protocol/source-private-main correspondence must explicitly use standard_2p_threefold. Old live-qualification-v2 configs lack the required ruleset and bind oldalpha/MCTS hashes; they cannot be reused byte-for-byte or called new-rule evidence.
- Actual current kernel, ELF/shared libraries and existing ORT provider must be bound and usable. Existing model d790, BEST51/scale/weights/feature/side/finite/native route stay fixed; no newly cached success, warmup, Torch/native96 or passed18 replay.
- Freeze2+2 windows, max128 Sigma requests/2M NNUE nodes,100ms+5ms reserve, whole_wall_time, workers1/active1/batch1, actual same logical CPU0/thread1/GPU0 and effective TT4096; whole-family2GiB includes controller. Qual8 includes all old/new outputs/raw/audit/recovery/control/log/failure. Decode only one existing runner inside supported TMP and retain old private floors; no new private pack.
- Current live-v2 Resources.check imports every retained compiler path and calls ledger.charge(False). Missing runner6aaa rlib therefore refuses before a caller window. That rlib is not consumed by the standalone production ELF, but the existing resource predicate still refuses. **Do not silently skip it, import an empty record, rebase the floor, reconstruct fake bytes, or claim terminal artifact presence.** Root must resolve the explicit resource/lifetime admission treatment while retaining missing9236480B UNKNOWN and positive35225600B. If old presence remains mandatory, live entry cannot proceed until genuinely restored; compiler-tail independence alone does not bypass this.
- The old controller hardcodes build49/private19/positive20 and old source/area lists. Its code is not the current74/38/26 forecast. A new bounded controller/admission must account every retained path maximum/private/root-directory/TMP/history/output and current maintained helper bytes. Old controller/config/runtime stays immutable; new source-control adoption needs appropriate narrowly related proof if it changes a required boundary.
- Actual source/private/resources/ownedreaderSTOP/fresh physical quiet/fairclock/soleCargo predicates and exact wait/cleanup still apply. No job, reservation or approval is created by this document.

## Limits and cost

Four Clippy executions are quality/lint evidence, not new production machine code; none is retrospectively passed. Arena no-run failure did not erase successful release/caller receipts. Prior7 caller fixtures were run on their original pre-API scope; source/control compatibility is reused, not represented as7 new df9 test executions. New18 remain only their saved scope.

Current source assessment upper: held8114176 +new65536 =8179712<8519680. This includes the separate65536 helper allocation and prior integration/metadata controls, with no lowered upper or old credit. Actual live qualification must derive a new inclusive8MiB forecast preserving old functional outputs and failed costs; no build/qual/games transfer is assumed.

Source/private/raw/fees472.5731598730199/maxima/old RuleA outcomes/UNKNOWN/default/pause/seals are preserved. No main/index/Git/source changes, binary/model reads, test repetition, compiler, clock or qualification ran in this assessment.
