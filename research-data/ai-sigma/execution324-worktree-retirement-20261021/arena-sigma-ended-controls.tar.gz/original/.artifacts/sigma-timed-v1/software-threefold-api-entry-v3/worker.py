"""Finite unified-threefold changed-boundary software; no model or live clock runs."""

import ast
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time
import importlib
import stat
import sys
import types

from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
WT = ROOT.parents[1]
OLD = ROOT / "software-v1"
# Current canonical control now has package-relative snapshot imports. Import the
# bound maintained package, while reusing only unchanged old guard declarations.
sys.path.insert(0, "/workspaces/quoridor/python")
P = importlib.import_module("quoridor_training.cycle_process")
P.LOG_MAX_BYTES = 131072
G = types.ModuleType("sigma_entry_guard")
G.__dict__.update(globals())
G.stat = stat
G.TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")
G.BASE = ["--offline", "--locked", "-j", "2"]
G.CARGO = "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo"
guard_tree = ast.parse((OLD / "worker.py").read_text())
guard_names = {"sha", "save", "allocated", "quiet", "Resources"}
guard_body = [
    node
    for node in guard_tree.body
    if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in guard_names
]
assert {node.name for node in guard_body} == guard_names
for node in guard_body:
    if node.name == "allocated":
        for term in ast.walk(node):
            if isinstance(term, ast.Constant) and term.value == 512:
                term.value = 640
                break
        else:
            raise AssertionError("known owned-folder count bound absent")
exec(
    compile(
        ast.Module(body=guard_body, type_ignores=[]), str(OLD / "worker.py"), "exec"
    ),
    G.__dict__,
)
NAMED_SPEC = importlib.util.spec_from_file_location(
    "named_replacement", ROOT / "software-recovery-v2/named_replacement.py"
)
NAMED = importlib.util.module_from_spec(NAMED_SPEC)
NAMED_SPEC.loader.exec_module(NAMED)
NamedReplacement, live_command_members = (
    NAMED.NamedReplacement,
    NAMED.live_command_members,
)


def quiet():
    G.quiet()
    markers = [
        "quoridor_training.train",
        "quoridor_training.sigma_reference",
        "numeric-worker",
        "numeric_worker",
        "observation-entry-v1/worker",
        "trainer.py",
    ]
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            argv = (entry / "cmdline").read_bytes().split(b"\0")
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not argv or not Path(os.fsdecode(argv[0])).name.startswith("python"):
            continue
        # Match executable script/module arguments, not shell -c source text.
        args = [os.fsdecode(x) for x in argv[1:] if x and not x.startswith(b"-")]
        if any(mark in arg for arg in args for mark in markers):
            raise P.CycleStopped("foreign numerical identity: " + entry.name)


def save(name, obj):
    G.save(name, obj)


def load_bound_charge_record(admission, path):
    """Verify the one immutable byte string which is subsequently parsed."""
    if path not in admission["bindings"]:
        raise P.CycleStopped("retained charge record is not bound: " + str(path))
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != admission["bindings"][path]:
        raise P.CycleStopped("retained charge record SHA mismatch: " + str(path))
    return json.loads(raw)


class Resources(G.Resources):
    def __init__(self, baseline, source_growth, initial_named):
        super().__init__(baseline, source_growth)
        self.named.update(initial_named)
        self.growth_peak = 21028864  # Retain the first phase charge, never refund it.
        prepared = json.loads((OUT / "named-entry-snapshot.json").read_text())
        admission = json.loads((OUT / "admission.json").read_text())
        self.ledger = NamedReplacement(
            baseline,
            prepared["named_before_rows"],
            admission["deliberate_owned_reconstruction"]["paths"],
        )
        self.held_growth_charge = 21028864
        retained = admission.get("retained_observed_charges", [])
        states = []
        # Validate every retained record before any record mutates this ledger.
        for path in retained:
            state = load_bound_charge_record(admission, path)
            if not isinstance(state, dict) or state.get(
                "original_baseline_SHA256"
            ) != G.sha(OLD / "named-baseline.json"):
                raise P.CycleStopped(
                    "retained charge baseline mismatch or malformed record"
                )
            maxima = state.get("allocation_max_B")
            union = state.get("charged_positive_union_B")
            if not isinstance(maxima, dict) or type(union) is not int or union < 0:
                raise P.CycleStopped("malformed retained charge maxima/union")
            for output, amount in maxima.items():
                if (
                    not isinstance(output, str)
                    or not output.startswith(str(G.TARGET) + "/")
                    or ".." in output.split("/")
                    or "\0" in output
                    or type(amount) is not int
                    or amount < 0
                ):
                    raise P.CycleStopped(
                        "malformed retained output ownership/allocation"
                    )
            states.append(state)
        for state in states:
            self.ledger.retain(state["allocation_max_B"])
            self.held_growth_charge = max(
                self.held_growth_charge, state["charged_positive_union_B"]
            )
        self.source_forecast_B = admission["source_control_review"][
            "inclusive_forecast_B"
        ]
        assert self.source_forecast_B <= admission["source_control_review"]["cap_B"]
        self.source_stop_sha = G.sha(admission["source_stop"])
        self.active_command = None
        self.active_compiler_identities = []

    def check(self, owned=()):
        P.CycleResources.check(self, owned)
        self.emitted()
        infos = [P.process_info(os.getpid())]
        infos.extend(P.process_info(m["pid"]) for m in owned)
        ram = sum(x["rss"] for x in infos if x) + 64 * 1024**2
        self.ram_peak = max(self.ram_peak, ram)
        if ram > 2 * 1024**3:
            raise P.CycleStopped("family RAM including controller exceeds2GiB")
        self.ledger.outputs.update(self.named)

        def argv_reader(pid):
            argv = (Path("/proc") / str(pid) / "cmdline").read_bytes().split(b"\0")
            return [os.fsdecode(x) for x in argv if x]

        owned_cargo = (
            live_command_members(owned, self.active_command, P.alive, argv_reader)
            if self.active_command
            else []
        )
        for member in owned_cargo:
            if member not in self.active_compiler_identities:
                self.active_compiler_identities.append(member)
        try:
            growth = self.ledger.charge(bool(owned_cargo))
            self.held_growth_charge = max(growth, self.held_growth_charge)
        finally:
            # Even an error after observing one larger path retains that fact
            # for the next finite admission; never rebase to a smaller stat.
            save(
                "charged-path-maxima.json",
                {
                    "original_baseline_SHA256": G.sha(OLD / "named-baseline.json"),
                    "source_stop_SHA256": self.source_stop_sha,
                    "allocation_max_B": dict(self.ledger.prior),
                    "charged_positive_union_B": self.held_growth_charge,
                    "continuous_unobserved_peak": "UNKNOWN",
                },
            )
        growth = self.held_growth_charge
        admission = json.loads((OUT / "admission.json").read_bytes())

        def area_total(name):
            return sum(
                G.allocated(path) + Path(path).stat().st_blocks * 512
                for path in admission["storage_areas"][name]
            )

        tmp = area_total("tmp")
        private = area_total("private")
        admission = json.loads((OUT / "admission.json").read_bytes())
        private = max(private, admission["old_private_held_B"])
        caps = admission["component_caps_B"]
        self.growth_peak = max(self.growth_peak, growth)
        self.tmp_peak = max(self.tmp_peak, tmp)
        self.private_peak = max(self.private_peak, private)
        if (
            growth > caps["positive_artifacts"]
            or tmp > caps["TMP_single_decode_linker"]
            or private > caps["retained_private"]
        ):
            raise P.CycleStopped("unified software positive/TMP/private component cap")
        if growth + tmp + private > admission["whole_build_cap_B"]:
            raise P.CycleStopped("unified software whole build cap")
        control = G.allocated(ROOT) - tmp - private + self.source_growth
        if control > self.source_forecast_B:
            raise P.CycleStopped("Sigma recovery inclusive source forecast exceeded")


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(WT)
    admission = json.loads((OUT / "admission.json").read_bytes())
    assert admission["admission"] is True and admission["prepared_only"] is False
    assert admission["related_review"]["blockers"] == 0
    assert admission["related_review"]["actual_reader_STOP"]
    for path, expected in admission["bindings"].items():
        assert G.sha(path) == expected, path
    packet = json.loads(Path(admission["source_stop"]).read_bytes())
    for relative, row in packet["stopped_sources"].items():
        path = WT / relative
        assert G.sha(path) == row["SHA256"], relative
        assert path.stat().st_mode & 0o777 == row["mode"]
    for row in packet["unchanged_dependency_bindings"]:
        assert G.sha(WT / row["path"]) == row["SHA256"]
    snapshot = json.loads((OUT / "named-entry-snapshot.json").read_bytes())
    assert admission["deliberate_owned_reconstruction"]["paths"] == []
    for row in snapshot["named_before_rows"]:
        assert G.sha(row["path"]) == row["SHA256"]
        assert Path(row["path"]).stat().st_blocks * 512 == row["allocated_B"]
    assert P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 128 * 1024**2
    quiet()
    for name in ["tmp", "private"]:
        (OUT / name).mkdir(exist_ok=True)
    os.environ.update(
        CARGO_TARGET_DIR=str(G.TARGET),
        CARGO_INCREMENTAL="0",
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        TMPDIR=str(OUT / "tmp"),
        CUDA_VISIBLE_DEVICES="",
        RUST_TEST_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
        CARGO_TERM_COLOR="never",
    )
    for name in [
        "RUSTFLAGS",
        "CARGO_ENCODED_RUSTFLAGS",
        "QUORIDOR_BENCH_MANIFEST",
        "QUORIDOR_BENCH_FT_MODE",
    ]:
        os.environ.pop(name, None)
    baseline = json.loads((OLD / "named-baseline.json").read_bytes())
    resources = Resources(
        {row["path"]: row["allocated_B"] for row in baseline["rows"]},
        packet["source_positive_allocated_growth_B"],
        [row["path"] for row in snapshot["named_before_rows"]],
    )
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "private": {},
        "model_native_Torch_calls": 0,
        "scientific_games": 0,
        "source_stop_SHA256": G.sha(admission["source_stop"]),
        "qualified_native_clock": False,
        "continuous_storage_peak": "UNKNOWN",
    }
    started = time.monotonic()
    images = {}
    image_shas = {}

    def command(name, argv, cargo_json=False):
        quiet()
        log = OUT / (name + ".log")
        is_compiler = argv[0] == G.CARGO
        if is_compiler:
            resources.ledger.begin(admission["command_output_leases"][name])
            resources.active_command = argv
        try:
            record = P.execute(argv, log, None, resources=resources)
        finally:
            if is_compiler:
                resources.ledger.finish()
                resources.active_command = None
        result["commands"].append({"name": name, **record})
        raw = log.read_bytes()
        assert record["log_bytes_seen"] <= P.LOG_MAX_BYTES, "provenance truncated"
        rows = (
            [json.loads(line) for line in raw.splitlines() if line.startswith(b"{")]
            if cargo_json
            else []
        )
        resources.emitted()
        resources.check()
        packed_log = gzip.compress(raw, mtime=0)
        assert len(packed_log) <= 8192, "log archive prospective bound exceeded"
        assert gzip.decompress(packed_log) == raw
        archive = log.with_suffix(".log.gz")
        archive.write_bytes(packed_log)
        result["commands"][-1]["raw_log_archive"] = {
            "path": str(archive),
            "raw_SHA256": hashlib.sha256(raw).hexdigest(),
            "gzip_SHA256": G.sha(archive),
            "raw_bytes": len(raw),
            "roundtrip": True,
        }
        log.unlink()  # Only this new raw log, exact bytes retained in its bound gzip.
        resources.check()
        if record["exit_code"] != 0:
            raise P.CycleStopped("command failed: " + name)
        return rows, raw.decode(errors="replace")

    def payload_receipt(name, rows):
        owned = [
            row
            for row in rows
            if row.get("reason") == "compiler-artifact"
            and row.get("target", {}).get("src_path", "").startswith(str(WT) + "/")
        ]
        receipt = [
            {
                "target": row["target"],
                "features": row.get("features"),
                "profile": row["profile"],
                "fresh": row["fresh"],
                "payloads": [
                    {
                        "path": path,
                        "SHA256": G.sha(path),
                        "allocated_B": Path(path).stat().st_blocks * 512,
                    }
                    for path in row["filenames"]
                ],
            }
            for row in owned
        ]
        save(name + "-own-payloads.json", receipt)
        return owned

    def pack(label, source, upper):
        raw = Path(source).read_bytes()
        blob = gzip.compress(raw, mtime=0)
        assert len(blob) <= upper and gzip.decompress(blob) == raw
        path = OUT / "private" / (label + ".gz")
        path.write_bytes(blob)
        result["private"][label] = {
            "path": str(path),
            "gzip_SHA256": G.sha(path),
            "gzip_bytes": len(blob),
            "ELF_SHA256": hashlib.sha256(raw).hexdigest(),
            "ELF_bytes": len(raw),
            "mode": Path(source).stat().st_mode & 0o777,
            "source_packet_SHA256": result["source_stop_SHA256"],
            "roundtrip": True,
        }
        resources.check()

    failure = None
    with (G.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet()
        resources.check()
        try:
            freshness = []
            for relative in admission["owned_source_freshness"]:
                path = WT / relative
                before = G.sha(path)
                old = path.stat().st_mtime_ns
                os.utime(path, ns=(path.stat().st_atime_ns, time.time_ns()))
                assert G.sha(path) == before
                freshness.append(
                    {
                        "path": str(path),
                        "SHA256": before,
                        "old_mtime_ns": old,
                        "new_mtime_ns": path.stat().st_mtime_ns,
                    }
                )
            save("owned-freshness.json", freshness)
            plan = json.loads((OUT / "plan.json").read_bytes())
            for step in plan["steps"]:
                if "argv" in step:
                    rows, _ = command(step["name"], step["argv"], True)
                    own = payload_receipt(step["name"], rows)
                    if step["name"] == "release":
                        for target in [
                            "quoridor_core",
                            "quoridor_nnue",
                            "quoridor_ai",
                            "quoridor_data",
                            "quoridor_runner",
                            "quoridor-runner",
                        ]:
                            assert any(
                                row["target"]["name"] == target and not row["fresh"]
                                for row in own
                            ), target
                        image = next(
                            row["executable"]
                            for row in own
                            if row["target"]["name"] == "quoridor-runner"
                        )
                        pack("quoridor-runner", image, 3 * 1024**2)
                    if step.get("test_image"):
                        found = [
                            row
                            for row in own
                            if row.get("executable") and row["profile"].get("test")
                        ]
                        assert len(found) == 1 and not found[0]["fresh"], step["name"]
                        images[step["test_image"]] = found[0]["executable"]
                        image_shas[step["test_image"]] = G.sha(found[0]["executable"])
                        if step.get("pack_upper_B"):
                            pack(
                                step["test_image"],
                                found[0]["executable"],
                                step["pack_upper_B"],
                            )
                else:
                    label = step["test_image"]
                    receipt = result["private"].get(label)
                    if receipt:
                        image = OUT / "tmp" / label
                        image.write_bytes(
                            gzip.decompress(Path(receipt["path"]).read_bytes())
                        )
                        image.chmod(receipt["mode"])
                        assert G.sha(image) == receipt["ELF_SHA256"]
                    else:
                        # Used only under this exclusive immutable source/Cargo lease;
                        # receipt binds target bytes now; never a future mutable image.
                        image = Path(images[label])
                        assert G.sha(image) == image_shas[label]
                    try:
                        _, log = command(
                            step["name"],
                            [
                                str(image),
                                step["filter"],
                                "--nocapture",
                                "--test-threads=1",
                            ],
                        )
                        assert f"running {step['expected_tests']} test" in log
                        assert f"{step['expected_tests']} passed; 0 failed" in log
                    finally:
                        if receipt:
                            image.unlink()  # New single decoder only; retained gzip unchanged.
        except BaseException as error:
            failure = repr(error)
        finally:
            result.update(
                stopped=datetime.now(timezone.utc).isoformat(),
                whole_seconds=time.monotonic() - started,
                failure=failure,
                charged_allocation_maxima_B=dict(resources.ledger.prior),
                charged_positive_union_B=resources.held_growth_charge,
                named_paths=sorted(resources.named),
                exact_owned_compiler_identities=resources.active_compiler_identities,
                replacement_absence_retained_events=resources.ledger.events,
                sampled_peaks={
                    "family_RAM_B": resources.ram_peak,
                    "positive_artifact_growth_B": resources.growth_peak,
                    "TMP_B": resources.tmp_peak,
                    "private_B": resources.private_peak,
                },
            )
            save("result.json", result)
    if failure:
        raise SystemExit(failure)


if __name__ == "__main__":
    main()
