"""Ordered exact checks precede the one canonical background submission."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent


def main():
    admission_path = OUT / "admission.json"
    job_path = OUT / "job.json"
    if (OUT / "job-runtime-v1").exists() or (OUT / "submit-attempt.json").exists():
        raise ValueError("this namespace already attempted; no automatic retry")
    # Every refusal or exception ends here before submit/Popen of the job.
    subprocess.run(
        [
            "/workspaces/quoridor/tools/research-quality/.venv/bin/ruff",
            "format",
            "--check",
            *[
                str(OUT / n)
                for n in [
                    "qualify.py",
                    "inputs.py",
                    "reviewed_helpers.py",
                    "preflight.py",
                    "launch.py",
                    "test_scope.py",
                ]
            ],
        ],
        check=True,
    )
    subprocess.run(
        [
            "/workspaces/quoridor/tools/research-quality/.venv/bin/ruff",
            "check",
            *[
                str(OUT / n)
                for n in [
                    "qualify.py",
                    "inputs.py",
                    "reviewed_helpers.py",
                    "preflight.py",
                    "launch.py",
                    "test_scope.py",
                ]
            ],
        ],
        check=True,
    )
    subprocess.run(
        [
            "node",
            "/workspaces/quoridor/tools/research-quality/node_modules/prettier/bin/prettier.cjs",
            "--config",
            "/workspaces/quoridor/tools/research-quality/.prettierrc.json",
            "--ignore-path",
            "/dev/null",
            "--check",
            str(admission_path),
            str(job_path),
        ],
        check=True,
    )
    raw = admission_path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    admission = json.loads(raw)
    job = json.loads(job_path.read_bytes())
    if (
        job["argv"] != [sys.executable, "-B", str(OUT / "qualify.py"), digest]
        or job["resource_contract"] != admission["proof_path"]
    ):
        raise ValueError("immutable actual argv/admission/proof mismatch")
    subprocess.run(
        [sys.executable, "-B", str(OUT / "preflight.py"), digest], check=True
    )
    (OUT / "submit-attempt.json").write_text(
        json.dumps(
            {
                "admission_SHA256": digest,
                "job_SHA256": hashlib.sha256(job_path.read_bytes()).hexdigest(),
                "all_prior_checks": "exit0/exactTrue",
                "submit": "ATTEMPTING_ONCE",
            },
            indent=2,
        )
        + "\n"
    )
    subprocess.run(
        [
            "bash",
            "/workspaces/quoridor/scripts/dev/research-job.sh",
            "submit",
            "--config",
            str(job_path),
            "--state-dir",
            str(OUT / "job-runtime-v1"),
        ],
        check=True,
        env={
            **os.environ,
            "UV_NO_SYNC": "1",
            "UV_OFFLINE": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
        },
    )


if __name__ == "__main__":
    main()
