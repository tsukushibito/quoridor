"""Four functional caller windows of the software-qualified current private CLI."""

from datetime import datetime, timezone
import copy
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time

from inputs import PROFILE, bound_json, validate_inputs
import reviewed_helpers as H

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
WT = ROOT.parents[1]
MIB = 1024**2
sys.path.insert(0, "/workspaces/quoridor/python")
from quoridor_training import cycle_process as P  # noqa: E402
from quoridor_training.snapshot import write_json  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "qualified_software_control",
    ROOT / "current-compiler-software-recovery-v2/worker.py",
)
S = importlib.util.module_from_spec(spec)
spec.loader.exec_module(S)
P.LOG_MAX_BYTES = 65536


def save(name, value):
    write_json(OUT / name, value)


H.OUT, H.P, H.save, H.bound_json = OUT, P, save, bound_json


def fair_quiet():
    S.quiet()
    # Match actually executed peer scripts; completed canonical metadata notifiers
    # do not execute these worker scripts and cannot hold a scientific slot.
    peer_roots = (
        "/workspaces/quoridor/.artifacts/lightweight-ordering-A-v1/phase-20261008/",
        "/workspaces/quoridor/.worktree/search-optimization/.artifacts/inference-search-perf-v1/",
        "/workspaces/quoridor/.worktree/endgame-solver335/.artifacts/endgame335/qualification-v1/",
        "/workspaces/quoridor/.worktree/learning-million/.artifacts/value-residual-diagnostic-v1/",
    )
    for p in Path("/proc").iterdir():
        if not p.name.isdecimal() or int(p.name) == os.getpid():
            continue
        try:
            args = [
                os.fsdecode(x) for x in (p / "cmdline").read_bytes().split(b"\0") if x
            ]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not args:
            continue
        executable = Path(args[0]).name
        if executable.startswith("python"):
            scripts = [
                a for a in args[1:] if a.endswith(".py") and Path(a).is_absolute()
            ]
            if any(a.startswith(peer_roots) for a in scripts):
                raise P.CycleStopped("active peer worker at fair entry: " + p.name)
        if executable in {"node", "nodejs", "python3"} and any(
            "browser" in Path(a).name and a.endswith((".py", ".mjs", ".cjs"))
            for a in args[1:]
        ):
            raise P.CycleStopped("active browser harness at fair entry: " + p.name)


def validate(a):
    if a["actual_entry"] is not True or a["prepared_only"] is not False:
        raise ValueError("prepared controls are not actual admission")
    if (
        a["pending_entry_obligations"]
        or a["related_review"]["blockers"] != 0
        or not a["related_review"]["actual_reader_STOP"]
    ):
        raise ValueError("new scope/reader/current entry predicates unresolved")
    validate_inputs(a)
    software = bound_json(a, a["software_bundle_path"])
    if (
        software["software_verified_only"] is not True
        or software["private"]["ELF_SHA256"] != a["runner_ELF_SHA256"]
        or software["private"]["gzip_SHA256"] != a["runner_gzip_SHA256"]
    ):
        raise ValueError("current software/private identity mismatch")
    produced = bound_json(a, a["compiled_production_receipt"])
    owned = [
        p
        for r in produced
        if r["target"]["name"] == "quoridor-runner"
        and r["target"]["src_path"] == str(WT / "crates/quoridor-runner/src/main.rs")
        and r["profile"]["opt_level"] == "3"
        and r["profile"]["test"] is False
        and r["fresh"] is False
        for p in r["payloads"]
        if p["SHA256"] == a["runner_ELF_SHA256"]
    ]
    if (
        len(owned) != 1
        or a["runner_ELF_SHA256"]
        != "e4b05b34e6019f46d9fb48e834a7d55deec9218671654c4e7fa488b9db869a71"
        or a["runner_ELF_bytes"] != 6398912
    ):
        raise ValueError("actual current1.99 source/profile/output evidence absent")
    for path, binding in a["bindings"].items():
        if isinstance(binding, dict):
            # The maintained source/profile proof declares SHA, mode and size.
            # Reuse its exact typed verifier rather than treating it as a digest.
            S.verify({path: binding})
        elif type(binding) is str:
            if S.sha(path) != binding:
                raise ValueError("bound input/control/proof changed: " + path)
        else:
            raise ValueError("unsupported binding representation: " + path)
    prior = bound_json(a, a["prior_worker_result"])
    prior_stop = bound_json(a, a["prior_stop_receipt"])
    if (
        prior["qualified"] is not False
        or prior["primary_error"]
        != "ValueError('functional typed-censor census failed')"
        or prior["all_direct_children_reaped"] is not True
        or prior["cleanup_complete"] is not True
        or prior["remaining"]
        or prior_stop["all4_directwait_process_cleanup"] is not True
        or prior_stop["remaining"]
    ):
        raise ValueError("prior failed controller/raw directwait facts changed")
    # Only saved initial facts are collected; no successful caller is replayed.
    H.collect_run("initial", a)
    for name, prefix in [("p2", [13])]:
        c = bound_json(a, str(OUT / ("config-" + name + ".json")))
        if (
            c["ruleset"] != "standard_2p_threefold"
            or c["games"] != 2
            or c["max_plies"] != len(prefix) + 1
            or c["arena"]["book"]["openings"][0]["prefix"] != prefix
            or c["output"] != str(OUT / ("run-" + name))
        ):
            raise ValueError("functional denominator/prefix/censor changed")
        if (
            [c["workers"], c["active_games"], c["max_batch"], c["inference_cpu_core"]]
            != [1, 1, 1, 0]
            or c["cpu_cores"] != [0]
            or c["arena"]["comparison"] != "whole_wall_time"
        ):
            raise ValueError("actual same-core serial caller policy changed")
        if (
            c["simulations"] != 64
            or c["temperature"] != 1.0
            or c["arena"]["return_reserve_ms"] != 5
            or c["arena"]["tt_entries"] != 65536
            or [e["time_ms"] for e in c["engines"]] != [100, 100]
            or c["engines"][0]["simd"]
        ):
            raise ValueError("fixed model/math/search/clock scope changed")
        if Path(c["output"]).exists():
            raise ValueError("owned output already exists")
    if os.uname().release != a["kernel_release"] or P.available_memory() < 6 * 1024**3:
        raise P.CycleStopped("kernel/fresh family2GiB+host4GiB condition failed")
    fs = os.statvfs(OUT)
    if fs.f_bavail * fs.f_frsize < a["supported_whole_phase_B"]:
        raise P.CycleStopped("fresh disk below whole-phase support")
    fair_quiet()
    return True


class RetainedRecords:
    """Forward immutable financial facts; never qualify non-runtime legacy storage."""

    def __init__(self, a):
        self.a = a
        self.state = bound_json(a, a["retained_observed_record"])
        baseline = bound_json(a, a["original_baseline_path"])
        if (
            self.state["original_baseline_SHA256"] != a["original_baseline_SHA256"]
            or a["original_baseline_SHA256"]
            != "86b76641353ecf4c5a0107522f97a308b68981a733fc8279fddb504a6312430d"
            or not isinstance(baseline["rows"], list)
        ):
            raise ValueError("historical baseline identity changed")
        self.held = self.state["charged_positive_union_B"]
        maxima = self.state["allocation_max_B"]
        if (
            type(self.held) is not int
            or self.held < 35225600
            or not isinstance(maxima, dict)
        ):
            raise ValueError("historical held charge missing/lowered")
        for path, amount in maxima.items():
            if (
                not path.startswith(
                    "/workspaces/quoridor/.artifacts/rust-migration/target/"
                )
                or ".." in Path(path).parts
                or type(amount) is not int
                or amount < 0
            ):
                raise ValueError("invalid historical financial ownership/charge")
        if (
            maxima.get(
                "/workspaces/quoridor/.artifacts/rust-migration/target/release/deps/libquoridor_runner-6aaa82ac9921176f.rlib"
            )
            != 9236480
        ):
            raise ValueError("historical missing charge not retained")
        self.unknown = [
            {
                "scope": "all legacy financial records",
                "status": "retained_UNQUALIFIED_NOT_execution_inputs",
                "known6aaa_max_B": 9236480,
            }
        ]
        # Old files are neither read nor exempted as runtime inputs. Every one of
        # the five required actual runtime inputs must exist and pass full checks.
        self.check()

    def check(self):
        proof = bound_json(self.a, self.a["proof_path"])
        supports = [
            r for r in proof["future_phase_support"] if r["issue"] == "quoridor-4lc.331"
        ]
        if (
            len(supports) != 1
            or supports[0]["inclusive_bytes"] != 4294967296
            or proof["legacy_coverage"]["conservative_held_bytes"] != 13421772800
        ):
            raise ValueError("supported phase/legacy coverage changed")
        return self.held

    def record(self, a):
        return {
            **copy.deepcopy(self.state),
            "historical_unknown": self.unknown,
            "execution_profile": PROFILE,
            "legacy_coverage_held_B": 13421772800,
            "legacy_actual_storage": "UNQUALIFIED/UNKNOWN; no global missing input exception",
            "software_phase_retention_upper_B": a["software_retention_upper_B"],
            "prior_failed_qualification_retention_upper_B": a[
                "prior_qualification_retention_upper_B"
            ],
        }


class Resources(P.CycleResources):
    def __init__(self, a):
        super().__init__(
            {
                "max_memory_bytes": 2 * 1024**3 - 64 * MIB,
                "host_ram_reserve": 4 * 1024**3,
                "max_output_bytes": 64 * MIB,
            },
            OUT,
            None,
        )
        self.a = a
        self.finance = RetainedRecords(a)
        self.rss_peak = self.output_peak = self.tmp_peak = 0
        self.financial_errors, self.charge_io_errors, self.attempted_children = (
            [],
            [],
            [],
        )

    def check(self, owned=()):
        super().check(owned)
        current = S.allocation(OUT)
        self.output_peak = max(self.output_peak, current)
        self.tmp_peak = max(self.tmp_peak, S.allocation(OUT / "tmp"))
        family = (
            sum(
                info["rss"]
                for pid in [os.getpid(), *(m["pid"] for m in owned)]
                if (info := P.process_info(pid))
            )
            + 64 * MIB
        )
        self.rss_peak = max(self.rss_peak, family)
        if (
            family > 2 * 1024**3
            or self.output_peak > 64 * MIB
            or self.a["software_retention_upper_B"]
            + self.a["prior_qualification_retention_upper_B"]
            + self.output_peak
            > self.a["supported_whole_phase_B"]
        ):
            raise P.CycleStopped("current family/qualification/whole guard exceeded")
        primary = None
        try:
            self.finance.check()
        except BaseException as error:
            primary = error
            self.financial_errors.append(H.error_fact("financial_proof", error))
        try:
            save("charged-path-maxima.json", self.finance.record(self.a))
        except BaseException as error:
            self.charge_io_errors.append(H.error_fact("charge_write", error))
            if primary is None:
                raise
        if primary is not None:
            raise primary


def main():
    raw = (OUT / "admission.json").read_bytes()
    if len(sys.argv) != 2 or hashlib.sha256(raw).hexdigest() != sys.argv[1]:
        raise ValueError("actual immutable admission digest mismatch")
    a = json.loads(raw)
    validate(a)
    os.sched_setaffinity(0, {1})
    os.chdir(WT)
    resources = Resources(a)
    image = OUT / "tmp/quoridor-runner"
    started = time.monotonic()
    result = {
        "actual_START": datetime.now(timezone.utc).isoformat(),
        "functional_slots": 4,
        "new_functional_slots": 2,
        "scientific_slots": 0,
        "compiled_replay_NN0": [],
        "commands": [],
        "runs": [],
        "qualified": False,
        "compile_calls": 0,
    }
    failure = None
    created_image = created_tmp = False
    os.environ.update(
        CUDA_VISIBLE_DEVICES="",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        ORT_DISABLE_TELEMETRY="1",
        TMPDIR=str(image.parent),
        PYTHONDONTWRITEBYTECODE="1",
    )
    try:
        with Path(a["cargo_lock"]).open("a") as lock, P.cancellation_signals():
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fair_quiet()
            image.parent.mkdir()
            created_tmp = True
            with (
                gzip.open(a["runner_gzip"], "rb") as source,
                image.open("xb") as target,
            ):
                created_image = True
                shutil.copyfileobj(source, target, 65536)
            image.chmod(0o755)
            if (
                image.stat().st_size != a["runner_ELF_bytes"]
                or S.sha(image) != a["runner_ELF_SHA256"]
            ):
                raise ValueError("immutable current payload decode mismatch")
            resources.check()
            result["prior_controller_failure_preserved"] = bound_json(
                a, a["prior_stop_receipt"]
            )
            result["completed_initial_reused"] = H.collect_run("initial", a)
            for operation in ["audit", "recover"]:
                result["commands"].append(
                    H.execute(
                        image,
                        ["arena", "--" + operation, a["completed_initial_run"]],
                        operation + "-initial",
                        resources,
                    )
                )
            fair_quiet()
            result["commands"].append(
                H.execute(
                    image,
                    ["arena", "--config", str(OUT / "config-p2.json")],
                    "arena-p2",
                    resources,
                )
            )
            result["runs"].append(H.collect_run("p2", a))
            for operation in ["audit", "recover"]:
                result["commands"].append(
                    H.execute(
                        image,
                        ["arena", "--" + operation, str(OUT / "run-p2")],
                        operation + "-p2",
                        resources,
                    )
                )
            result["joined_functional_windows"] = 4
            result["new_functional_windows"] = 2
            result["prior_functional_windows"] = 2
            result["prior_NN0_assertions_reused_without_execution"] = 3
            result["qualified"] = True
    except BaseException as error:
        failure = repr(error)
    finally:
        failure = H.finalize(
            result, failure, resources, a, image, created_image, created_tmp, started
        )
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
