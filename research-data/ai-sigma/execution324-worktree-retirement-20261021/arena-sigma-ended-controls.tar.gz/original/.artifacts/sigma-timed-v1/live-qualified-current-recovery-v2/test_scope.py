"""New collector field/old-result binding and five-command finalization only."""

import ast
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
from types import SimpleNamespace
import unittest


class Collector(unittest.TestCase):
    def setUp(self):
        self.reads = []
        self.a = {
            "completed_initial_run": "/old/run-initial",
            "runner_ELF_SHA256": "e4",
            "critical_compiled_sources": {"key": "source"},
        }
        self.manifest = {
            "binding": {
                "executable_sha256": "e4",
                "rules": "research-standard-2p-threefold-goal-first-v1",
                "compiled_sources": {"key": "source"},
            }
        }
        self.report = {
            "planned": 2,
            "all_workers_joined": True,
            "stopped": None,
            "pump": {"backend_work": {"warm_rows": 0, "logical_rows": 17}},
            "outcomes": [],
        }
        for index in [0, 1]:
            self.report["outcomes"].append(
                {
                    "started": True,
                    "status": "unknown",
                    "winner": None,
                    "reason": "ply_cap_before_terminal",
                    "failure": "ply_cap",
                    "plies": 1,
                    "observations": [
                        {
                            "accepted": True,
                            "engine_error": None,
                            "failure": None,
                            "engine_index": index,
                            "counters": {"nodes": 70680},
                        }
                    ],
                    "persistent_tt": [
                        {"effective_tt_slots": 4096, "persistent_tt_byte_cap": 1048576}
                    ],
                }
            )

        def bound(a, path):
            self.reads.append(path)
            return copy.deepcopy(
                self.report if path.endswith("/result.json") else self.manifest
            )

        node = next(
            n
            for n in ast.parse(
                Path(__file__).with_name("reviewed_helpers.py").read_text()
            ).body
            if isinstance(n, ast.FunctionDef) and n.name == "collect_run"
        )
        ns = {"OUT": Path("/new"), "Path": Path, "json": json, "bound_json": bound}
        exec(
            compile(
                ast.Module(body=[node], type_ignores=[]), "actual-collector", "exec"
            ),
            ns,
        )
        self.collect = ns["collect_run"]

    def test_actual_reason_failure_fields_and_bound_prior(self):
        result = self.collect("initial", self.a)
        self.assertEqual(len(result["accepted_windows"]), 2)
        self.assertEqual(
            self.reads,
            ["/old/run-initial/result.json", "/old/run-initial/manifest.json"],
        )

    def test_wrong_reason_failure_and_engine_error_refuse(self):
        for field, value in [("reason", "ply_cap"), ("failure", None)]:
            self.setUp()
            self.report["outcomes"][0][field] = value
            with self.assertRaises(ValueError):
                self.collect("initial", self.a)
        self.setUp()
        self.report["outcomes"][0]["observations"][0]["engine_error"] = (
            "inference:error"
        )
        with self.assertRaises(ValueError):
            self.collect("initial", self.a)

    def test_missing_or_duplicate_engine_census_refuses(self):
        self.report["outcomes"].pop()
        with self.assertRaises(ValueError):
            self.collect("initial", self.a)
        self.setUp()
        self.report["outcomes"][1]["observations"][0]["engine_index"] = 0
        with self.assertRaises(ValueError):
            self.collect("initial", self.a)


class Finalization(unittest.TestCase):
    def test_exact_five_remaining_receipts_and_missing_refusal(self):
        source = ast.parse(Path(__file__).with_name("reviewed_helpers.py").read_text())
        nodes = [
            n
            for n in source.body
            if isinstance(n, ast.FunctionDef) and n.name in {"error_fact", "finalize"}
        ]
        expected = [
            "audit-initial",
            "recover-initial",
            "arena-p2",
            "audit-p2",
            "recover-p2",
        ]
        for missing in [False, True]:
            records = {
                name + ".process.json": {
                    "command": ["/image", "arena", name],
                    "remaining": [],
                    "direct_child_reaped": True,
                    "cleanup_complete": True,
                }
                for name in expected
            }

            class FakePath:
                def __init__(self, name):
                    self.name = name

                def __str__(self):
                    return "/new/" + self.name

                def read_text(self):
                    return json.dumps(records[self.name])

            class Output:
                def glob(self, pattern):
                    return [FakePath(n) for n in records]

            class Parent:
                def iterdir(self):
                    return iter(())

            saved = {}

            def save(name, value):
                saved[name] = copy.deepcopy(value)

            ns = {
                "OUT": Output(),
                "json": json,
                "datetime": datetime,
                "timezone": timezone,
                "time": SimpleNamespace(monotonic=lambda: 1),
                "save": save,
            }
            exec(
                compile(
                    ast.Module(body=nodes, type_ignores=[]), "actual-finalize", "exec"
                ),
                ns,
            )
            resources = SimpleNamespace(
                attempted_children=[
                    {
                        "receipt": "/new/" + name + ".process.json",
                        "argv": ["/image", "arena", name],
                    }
                    for name in expected
                ],
                finance=SimpleNamespace(
                    check=lambda: None, held=35225600, record=lambda a: {}, unknown=[]
                ),
                financial_errors=[],
                charge_io_errors=[],
                rss_peak=0,
                output_peak=0,
                tmp_peak=0,
            )
            if missing:
                records.pop("recover-p2.process.json")
            result = {"qualified": True}
            failure = ns["finalize"](
                result,
                None,
                resources,
                {"caps_B": {"positive": 35225600}},
                SimpleNamespace(parent=Parent()),
                False,
                False,
                0,
            )
            self.assertEqual(saved["result.json"]["qualified"], not missing)
            self.assertEqual(
                saved["result.json"]["all_direct_children_reaped"], not missing
            )
            self.assertEqual(failure is None, not missing)


if __name__ == "__main__":
    unittest.main()
