"""Exact current private and whole-phase checks; no model execution here."""

import fcntl
import hashlib
import json
from pathlib import Path
import sys

import qualify as Q


def main():
    raw = (Q.OUT / "admission.json").read_bytes()
    if len(sys.argv) != 2 or hashlib.sha256(raw).hexdigest() != sys.argv[1]:
        raise ValueError("immutable admission digest mismatch")
    a = json.loads(raw)
    if Q.validate(a) is not True:
        raise ValueError("preflight requires exactly True")
    with Path(a["cargo_lock"]).open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        Q.fair_quiet()
        resources = Q.Resources(a)
        resources.check()
    print(
        json.dumps(
            {
                "preflight": True,
                "financial_storage": "historical UNKNOWN retained",
                "model_calls": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
