"""Current binding/physical checks for this finite repair, without submitting a job."""

import fcntl
import hashlib
import json
import os
from pathlib import Path

import worker as W


OUT = Path(__file__).resolve().parent


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verify():
    admission = json.loads((OUT / "admission.json").read_text())
    assert admission["admission"] is True
    assert admission["related_review"]["blockers"] == 0
    assert admission["related_review"]["actual_reader_STOP"]
    assert admission["peer332_actual_STOP"]
    assert admission["prepared_only"] is False
    proof = json.loads(Path(admission["current_typed_proof"]).read_bytes())
    assert admission["component_caps_B"] == proof["build_components_B"]
    assert admission["whole_build_cap_B"] == proof["build_upper_B"]
    assert admission["source_control_review"]["cap_B"] == proof["source_upper_B"]
    caps = admission["component_caps_B"]
    forecast = admission["full_forecast_B"]
    assert forecast["positive_union_forecast_B"] <= caps["positive_artifacts"]
    assert forecast["private_future_upper_B"] <= caps["retained_private"]
    assert forecast["TMP_single_decode_or_linker_B"] <= caps["TMP_single_decode_linker"]
    assert forecast["whole_build_forecast_B"] <= admission["whole_build_cap_B"]
    assert (
        admission["source_control_review"]["inclusive_forecast_B"]
        <= admission["source_control_review"]["cap_B"]
    )
    for path, expected in admission["bindings"].items():
        assert sha(path) == expected, path
    packet = json.loads(Path(admission["source_stop"]).read_text())
    for path, row in packet["stopped_sources"].items():
        assert sha(W.WT / path) == row["SHA256"]
        assert (W.WT / path).stat().st_mode & 0o777 == row["mode"]
    for row in packet["unchanged_dependency_bindings"]:
        assert sha(W.WT / row["path"]) == row["SHA256"]
    rows = json.loads((OUT / "named-entry-snapshot.json").read_text())[
        "named_before_rows"
    ]
    assert W.verify_named_snapshot(admission, rows) is True
    W.quiet()
    assert W.P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 128 * 1024**2
    for name in ["tmp", "private"]:
        (OUT / name).mkdir(exist_ok=True)
    baseline = json.loads((W.OLD / "named-baseline.json").read_text())
    resource = W.Resources(
        {r["path"]: r["allocated_B"] for r in baseline["rows"]},
        packet["source_positive_allocated_growth_B"],
        [row["path"] for row in rows],
    )
    resource.check()
    with (W.G.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    return True
