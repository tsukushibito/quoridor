"""Focused AST-only source helper mocks; no worker imports or real file IO."""

import ast
import copy
import hashlib
import json
from pathlib import Path
import resource
import time
from types import SimpleNamespace


def main():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    started = time.monotonic()
    source = Path(__file__).with_name("worker.py")
    node = next(
        n
        for n in ast.parse(source.read_text()).body
        if isinstance(n, ast.FunctionDef) and n.name == "verify_named_snapshot"
    )
    target = Path("/workspaces/quoridor/.artifacts/rust-migration/target")
    missing = str(target / "release/deps/libquoridor_runner-6aaa82ac9921176f.rlib")
    other = str(target / "release/deps/libquoridor_core-4ac94dc2c32cb0aa.rmeta")
    wt = Path("/workspaces/quoridor/.worktree/arena-evaluation")
    profile = {
        "opt_level": "3",
        "debuginfo": 0,
        "debug_assertions": False,
        "overflow_checks": False,
        "test": False,
    }
    raw = json.dumps(
        [
            {
                "target": {
                    "name": "quoridor_runner",
                    "src_path": str(wt / "crates/quoridor-runner/src/lib.rs"),
                },
                "features": ["default"],
                "profile": profile,
                "payloads": [
                    {"path": missing, "SHA256": "prior", "allocated_B": 9236480}
                ],
            }
        ]
    ).encode()
    argv = [
        "/fake/cargo",
        "test",
        "--offline",
        "--locked",
        "-j",
        "2",
        "--release",
        "-p",
        "quoridor-runner",
        "--test",
        "arena",
        "--no-run",
        "--message-format=json",
    ]
    base = {
        "deliberate_owned_reconstruction": {"paths": [missing]},
        "initial_missing_proofs": {
            missing: {
                "path": "/mock/proof",
                "target": "quoridor_runner",
                "source": "crates/quoridor-runner/src/lib.rs",
                "features": ["default"],
                "profile": profile,
            }
        },
        "bindings": {"/mock/proof": hashlib.sha256(raw).hexdigest()},
        "command_output_leases": {"arena-build": [missing]},
    }
    rows = [
        {
            "path": missing,
            "prior_SHA256": "prior",
            "allocated_B": 9236480,
            "initial_missing": True,
        },
        {"path": other, "SHA256": "present", "allocated_B": 4096},
    ]

    class Refused(RuntimeError):
        pass

    def run(admission, snapshot, *, version=False, wrong_missing=False):
        counts = {"proof_reads": 0, "proof_parses": 0}

        class FakePath:
            def __init__(self, path):
                self.path = str(path)

            def __truediv__(self, name):
                return FakePath(self.path + "/" + name)

            def read_bytes(self):
                if self.path.endswith("/plan.json"):
                    return json.dumps(
                        {
                            "steps": [
                                {
                                    "name": "arena-build",
                                    "argv": ["/fake/cargo", "--version"]
                                    if version
                                    else argv,
                                }
                            ]
                        }
                    ).encode()
                assert self.path == "/mock/proof"
                counts["proof_reads"] += 1
                return raw

            def stat(self):
                if self.path == missing or wrong_missing:
                    raise FileNotFoundError(self.path)
                return SimpleNamespace(st_blocks=8)

        def loads(data):
            if data == raw:
                counts["proof_parses"] += 1
            return json.loads(data)

        def digest(path):
            if path == missing or wrong_missing:
                raise FileNotFoundError(path)
            return "present"

        ns = {
            "P": SimpleNamespace(CycleStopped=Refused),
            "G": SimpleNamespace(TARGET=target, CARGO="/fake/cargo", sha=digest),
            "Path": FakePath,
            "OUT": FakePath("/mock/out"),
            "WT": wt,
            "hashlib": hashlib,
            "json": SimpleNamespace(loads=loads),
        }
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(source), "exec"), ns)
        before = copy.deepcopy((admission, snapshot))
        try:
            result = ns["verify_named_snapshot"](admission, snapshot)
        except Refused:
            result = False
        assert (admission, snapshot) == before, "proof check mutated input/held charge"
        return result, counts

    assert run(copy.deepcopy(base), copy.deepcopy(rows))[0] is True
    bad = copy.deepcopy(base)
    bad["bindings"] = {}
    ok, counts = run(bad, copy.deepcopy(rows))
    assert not ok and counts == {"proof_reads": 0, "proof_parses": 0}
    bad = copy.deepcopy(base)
    bad["bindings"]["/mock/proof"] = "wrong"
    ok, counts = run(bad, copy.deepcopy(rows))
    assert not ok and counts == {"proof_reads": 1, "proof_parses": 0}
    for field, value in [
        ("target", "foreign"),
        ("source", "/foreign/lib.rs"),
        ("features", ["other"]),
        ("profile", {}),
    ]:
        bad = copy.deepcopy(base)
        bad["initial_missing_proofs"][missing][field] = value
        ok, counts = run(bad, copy.deepcopy(rows))
        assert not ok and counts["proof_reads"] == 0
    assert not run(copy.deepcopy(base), copy.deepcopy(rows), version=True)[0]
    assert not run(copy.deepcopy(base), copy.deepcopy(rows), wrong_missing=True)[0]
    badrows = copy.deepcopy(rows)
    badrows[0]["allocated_B"] = 9232384
    assert not run(copy.deepcopy(base), badrows)[0]
    empty = copy.deepcopy(base)
    empty["deliberate_owned_reconstruction"]["paths"] = []
    empty["initial_missing_proofs"] = {}
    assert run(empty, [copy.deepcopy(rows[1])])[0]
    print(
        json.dumps(
            {
                "focused_initial_reconstruction_cases": "PASS",
                "helper_AST_only": True,
                "unchanged_input_and_charge": True,
                "model_Cargo_worker_module_import_Popen_realfile_IO": 0,
                "wall_seconds": time.monotonic() - started,
                "rusage_RSS_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                "kernel_memory": {
                    line.split(":", 1)[0]: line.split(":", 1)[1].strip()
                    for line in Path("/proc/self/status").read_text().splitlines()
                    if line.startswith(("VmHWM:", "VmPeak:"))
                },
            }
        )
    )


if __name__ == "__main__":
    main()
