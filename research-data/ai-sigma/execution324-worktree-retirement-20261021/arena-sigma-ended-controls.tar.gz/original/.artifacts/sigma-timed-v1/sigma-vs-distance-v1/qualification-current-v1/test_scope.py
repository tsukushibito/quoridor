"""New fixed-D caller role/identity guards; actual helper AST and fake files only."""

import ast
import copy
import json
from pathlib import Path
import time


def main():
    started = time.monotonic()
    module = ast.parse((Path(__file__).parent / "reviewed_helpers.py").read_text())
    function = next(
        x
        for x in module.body
        if isinstance(x, ast.FunctionDef) and x.name == "collect_run"
    )
    admission = {
        "runner_ELF_SHA256": "elf",
        "critical_compiled_sources": {"core": "core"},
        "expected_evaluator_identities": ["Sigma", "D-fixed"],
    }
    manifest = {
        "binding": {
            "executable_sha256": "elf",
            "rules": "research-standard-2p-threefold-goal-first-v1",
            "compiled_sources": {"core": "core"},
        },
        "loaded_evaluators": [
            {"content_sha256": "Sigma"},
            {"content_sha256": "D-fixed"},
        ],
    }
    outcomes = []
    for engine in [0, 1]:
        outcomes.append(
            {
                "started": True,
                "status": "unknown",
                "winner": None,
                "reason": "ply_cap_before_terminal",
                "failure": "ply_cap",
                "plies": 1,
                "nn_calls": 10 if engine == 0 else 0,
                "observations": [
                    {
                        "engine_index": engine,
                        "accepted": True,
                        "failure": None,
                        "engine_error": None,
                        "counters": {"nodes": 100},
                    }
                ],
                "persistent_tt": [
                    {},
                    {"effective_tt_slots": 4096, "persistent_tt_byte_cap": 1048576},
                ],
            }
        )
    report = {
        "planned": 2,
        "outcomes": outcomes,
        "all_workers_joined": True,
        "stopped": None,
        "pump": {"backend_work": {"warm_rows": 0, "logical_rows": 10}},
    }

    class FakePath:
        def __init__(self, name=""):
            self.name = name

        def __truediv__(self, name):
            return FakePath(name)

        def read_bytes(self):
            return json.dumps(
                manifest if self.name == "manifest.json" else report
            ).encode()

    ns = {"OUT": FakePath(), "json": json}
    exec(
        compile(
            ast.Module(body=[function], type_ignores=[]), "actual-D-collector", "exec"
        ),
        ns,
    )
    assert len(ns["collect_run"]("initial", admission)["accepted_windows"]) == 2
    baseline = copy.deepcopy(report)
    baseline_manifest = copy.deepcopy(manifest)
    for mutation in ["wrong-model", "D-neural-call", "D-TT", "duplicate-role"]:
        report, manifest = copy.deepcopy(baseline), copy.deepcopy(baseline_manifest)
        if mutation == "wrong-model":
            manifest["loaded_evaluators"][1]["content_sha256"] = "other"
        elif mutation == "D-neural-call":
            report["outcomes"][1]["nn_calls"] = 1
        elif mutation == "D-TT":
            report["outcomes"][1]["persistent_tt"][1]["effective_tt_slots"] = 8192
        else:
            report["outcomes"][1]["observations"][0]["engine_index"] = 0
        try:
            ns["collect_run"]("initial", admission)
        except ValueError:
            pass
        else:
            raise AssertionError("new D boundary refusal missing: " + mutation)
    print(
        json.dumps(
            {
                "new_focused_cases": 5,
                "status": "PASS",
                "wall_seconds": time.monotonic() - started,
                "runtime_model_process_calls": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
