"""Approved fixed Sigma versus distance sixteen-slot collection."""

from datetime import datetime, timezone
import copy
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time

from inputs import PROFILE, bound_json, validate_inputs
import reviewed_helpers as H

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WT = ROOT.parents[1]
MIB = 1024**2
sys.path.insert(0, "/workspaces/quoridor/python")
from quoridor_training import cycle_process as P  # noqa: E402
from quoridor_training.snapshot import write_json  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "qualified_software_control",
    ROOT / "current-compiler-software-recovery-v2/worker.py",
)
S = importlib.util.module_from_spec(spec)
spec.loader.exec_module(S)
P.LOG_MAX_BYTES = 65536


def save(name, value):
    write_json(OUT / name, value)


H.OUT, H.P, H.save, H.bound_json = OUT, P, save, bound_json


def fair_quiet():
    S.quiet()
    # Match actually executed peer scripts; completed canonical metadata notifiers
    # do not execute these worker scripts and cannot hold a scientific slot.
    peer_roots = (
        "/workspaces/quoridor/.artifacts/lightweight-ordering-A-v1/phase-20261008/",
        "/workspaces/quoridor/.worktree/search-optimization/.artifacts/inference-search-perf-v1/",
        "/workspaces/quoridor/.worktree/endgame-solver335/.artifacts/endgame335/qualification-v1/",
        "/workspaces/quoridor/.worktree/learning-million/.artifacts/value-residual-diagnostic-v1/",
    )
    for p in Path("/proc").iterdir():
        if not p.name.isdecimal() or int(p.name) == os.getpid():
            continue
        try:
            args = [
                os.fsdecode(x) for x in (p / "cmdline").read_bytes().split(b"\0") if x
            ]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not args:
            continue
        executable = Path(args[0]).name
        if executable.startswith("python"):
            scripts = [
                a for a in args[1:] if a.endswith(".py") and Path(a).is_absolute()
            ]
            if any(a.startswith(peer_roots) for a in scripts):
                raise P.CycleStopped("active peer worker at fair entry: " + p.name)
        if executable in {"node", "nodejs", "python3"} and any(
            "browser" in Path(a).name and a.endswith((".py", ".mjs", ".cjs"))
            for a in args[1:]
        ):
            raise P.CycleStopped("active browser harness at fair entry: " + p.name)


def validate(a):
    if a["actual_entry"] is not True or a["prepared_only"] is not False:
        raise ValueError("prepared controls are not actual admission")
    if (
        a["pending_entry_obligations"]
        or a["related_review"]["blockers"] != 0
        or not a["related_review"]["actual_reader_STOP"]
    ):
        raise ValueError("scope/reader/entry predicates unresolved")
    validate_inputs(a)
    for path, binding in a["bindings"].items():
        if isinstance(binding, dict):
            S.verify({path: binding})
        elif type(binding) is str:
            if S.sha(path) != binding:
                raise ValueError("bound input/control/proof changed: " + path)
        else:
            raise ValueError("unsupported binding representation")
    software = bound_json(a, a["software_bundle_path"])
    qualified = bound_json(a, a["functional_STOP_receipt"])
    if (
        software["software_verified_only"] is not True
        or qualified["qualified_fixed_functional_scope"] is not True
        or qualified["joined_windows"] != 4
        or qualified["remaining"]
        or qualified["main_commit"] != a["main_commit"]
        or qualified["ELF_SHA256"] != a["runner_ELF_SHA256"]
    ):
        raise ValueError("software/current functional qualification missing")
    if a["planned_scientific_slots"] != 16 or a["planned_pairs"] != 8:
        raise ValueError("scientific denominator changed")
    book = bound_json(a, a["book_path"])
    all_openings = []
    for name, slots in [("initial", 2), ("main", 14)]:
        c = bound_json(a, str(OUT / ("config-" + name + ".json")))
        if (
            c["ruleset"] != "standard_2p_threefold"
            or c["games"] != slots
            or c["max_plies"] != 200
            or len(c["arena"]["book"]["openings"]) != slots // 2
            or c["output"] != str(OUT / ("run-" + name))
            or Path(c["output"]).exists()
        ):
            raise ValueError("rules/planned census/owned output changed")
        if (
            [c["workers"], c["active_games"], c["max_batch"], c["inference_cpu_core"]]
            != [1, 1, 1, 0]
            or c["cpu_cores"] != [0]
            or c["arena"]["comparison"] != "whole_wall_time"
            or c["arena"]["return_reserve_ms"] != 5
            or [e["time_ms"] for e in c["engines"]] != [100, 100]
        ):
            raise ValueError("serial whole-caller clock changed")
        if (
            c["simulations"] != 64
            or c["temperature"] != 1.0
            or c["arena"]["tt_entries"] != 65536
            or c["engines"][1]["simd"]
            or c["arena"]["search_source_sha256"]
            != [
                a["critical_compiled_sources"]["ai/sigma_mcts.rs"],
                a["critical_compiled_sources"]["ai/alphabeta.rs"],
            ]
        ):
            raise ValueError("model/search binding changed")
        if (
            [e["kind"] for e in c["engines"]] != ["mcts", "distance"]
            or c["engines"][1]["distance_a"] != 0.0
            or c["engines"][1]["distance_b"] != 8.0
            or c["engines"][1]["model"] is not None
            or c["arena"]["evaluator_sha256"] != a["expected_evaluator_identities"]
        ):
            raise ValueError("fixed Sigma0/D1 identity changed")
        all_openings.extend(c["arena"]["book"]["openings"])
    if [x["prefix"] for x in all_openings] != [
        x["prefix"] for x in book["openings"]
    ] or [x["id"] for x in all_openings] != [x["id"] for x in book["openings"]]:
        raise ValueError("frozen ordered book changed")
    if (
        os.uname().release != a["kernel_release"]
        or P.available_memory() < 6 * 1024**3
        or os.statvfs(OUT).f_bavail * os.statvfs(OUT).f_frsize
        < a["supported_whole_phase_B"]
    ):
        raise P.CycleStopped("fresh kernel/physical capacity condition failed")
    fair_quiet()
    return True


def collect_scientific(name, a):
    target = OUT / ("run-" + name)
    report = json.loads((target / "result.json").read_bytes())
    manifest = json.loads((target / "manifest.json").read_bytes())
    expected = 2 if name == "initial" else 14
    if (
        manifest["binding"]["executable_sha256"] != a["runner_ELF_SHA256"]
        or manifest["binding"]["rules"]
        != "research-standard-2p-threefold-goal-first-v1"
    ):
        raise ValueError("actual private/rules binding mismatch")
    for key, digest in a["critical_compiled_sources"].items():
        if manifest["binding"]["compiled_sources"][key] != digest:
            raise ValueError("actual compiled source mismatch: " + key)
    if [e["content_sha256"] for e in manifest["loaded_evaluators"]] != a[
        "expected_evaluator_identities"
    ]:
        raise ValueError("actual fixed Sigma0/D1 evaluators changed")
    outcomes = report["outcomes"]
    if (
        report["planned"] != expected
        or len(outcomes) != expected
        or sorted(o["game"] for o in outcomes) != list(range(expected))
        or not report["all_workers_joined"]
    ):
        raise ValueError("exact planned census/worker join absent")
    # Actual UNKNOWN/late/error/not-started and stopped reasons are retained.
    # Collection success is not sixteen completed games or a strength certificate.
    return {
        "report": report,
        "manifest_SHA256": S.sha(target / "manifest.json"),
        "moves_gzip_SHA256": S.sha(target / "moves.jsonl.gz"),
    }


class RetainedRecords:
    """Forward immutable financial facts; never qualify non-runtime legacy storage."""

    def __init__(self, a):
        self.a = a
        self.state = bound_json(a, a["retained_observed_record"])
        baseline = bound_json(a, a["original_baseline_path"])
        if (
            self.state["original_baseline_SHA256"] != a["original_baseline_SHA256"]
            or a["original_baseline_SHA256"]
            != "86b76641353ecf4c5a0107522f97a308b68981a733fc8279fddb504a6312430d"
            or not isinstance(baseline["rows"], list)
        ):
            raise ValueError("historical baseline identity changed")
        self.held = self.state["charged_positive_union_B"]
        maxima = self.state["allocation_max_B"]
        if (
            type(self.held) is not int
            or self.held < 35225600
            or not isinstance(maxima, dict)
        ):
            raise ValueError("historical held charge missing/lowered")
        for path, amount in maxima.items():
            if (
                not path.startswith(
                    "/workspaces/quoridor/.artifacts/rust-migration/target/"
                )
                or ".." in Path(path).parts
                or type(amount) is not int
                or amount < 0
            ):
                raise ValueError("invalid historical financial ownership/charge")
        if (
            maxima.get(
                "/workspaces/quoridor/.artifacts/rust-migration/target/release/deps/libquoridor_runner-6aaa82ac9921176f.rlib"
            )
            != 9236480
        ):
            raise ValueError("historical missing charge not retained")
        self.unknown = [
            {
                "scope": "all legacy financial records",
                "status": "retained_UNQUALIFIED_NOT_execution_inputs",
                "known6aaa_max_B": 9236480,
            }
        ]
        # Old files are neither read nor exempted as runtime inputs. Every one of
        # the five required actual runtime inputs must exist and pass full checks.
        self.check()

    def check(self):
        proof = bound_json(self.a, self.a["proof_path"])
        supports = [
            r for r in proof["future_phase_support"] if r["issue"] == "quoridor-4lc.331"
        ]
        if (
            len(supports) != 1
            or supports[0]["inclusive_bytes"] != 4294967296
            or proof["legacy_coverage"]["conservative_held_bytes"] != 13421772800
        ):
            raise ValueError("supported phase/legacy coverage changed")
        return self.held

    def record(self, a):
        return {
            **copy.deepcopy(self.state),
            "historical_unknown": self.unknown,
            "execution_profile": PROFILE,
            "legacy_coverage_held_B": 13421772800,
            "legacy_actual_storage": "UNQUALIFIED/UNKNOWN; no global missing input exception",
            "software_phase_retention_upper_B": a["software_retention_upper_B"],
            "prior_failed_qualification_retention_upper_B": a[
                "prior_qualification_retention_upper_B"
            ],
        }


class Resources(P.CycleResources):
    def __init__(self, a):
        super().__init__(
            {
                "max_memory_bytes": 2 * 1024**3 - 64 * MIB,
                "host_ram_reserve": 4 * 1024**3,
                "max_output_bytes": 256 * MIB,
            },
            OUT,
            None,
        )
        self.a = a
        self.finance = RetainedRecords(a)
        self.rss_peak = self.output_peak = self.tmp_peak = 0
        self.financial_errors, self.charge_io_errors, self.attempted_children = (
            [],
            [],
            [],
        )

    def check(self, owned=()):
        super().check(owned)
        current = S.allocation(OUT)
        self.output_peak = max(self.output_peak, current)
        self.tmp_peak = max(self.tmp_peak, S.allocation(OUT / "tmp"))
        family = (
            sum(
                info["rss"]
                for pid in [os.getpid(), *(m["pid"] for m in owned)]
                if (info := P.process_info(pid))
            )
            + 64 * MIB
        )
        self.rss_peak = max(self.rss_peak, family)
        if (
            family > 2 * 1024**3
            or self.output_peak > 256 * MIB
            or self.a["software_retention_upper_B"]
            + self.a["prior_qualification_retention_upper_B"]
            + self.output_peak
            > self.a["supported_whole_phase_B"]
        ):
            raise P.CycleStopped("current family/qualification/whole guard exceeded")
        primary = None
        try:
            self.finance.check()
        except BaseException as error:
            primary = error
            self.financial_errors.append(H.error_fact("financial_proof", error))
        try:
            save("charged-path-maxima.json", self.finance.record(self.a))
        except BaseException as error:
            self.charge_io_errors.append(H.error_fact("charge_write", error))
            if primary is None:
                raise
        if primary is not None:
            raise primary


def main():
    raw = (OUT / "admission.json").read_bytes()
    if len(sys.argv) != 2 or hashlib.sha256(raw).hexdigest() != sys.argv[1]:
        raise ValueError("actual immutable admission digest mismatch")
    a = json.loads(raw)
    validate(a)
    os.sched_setaffinity(0, {1})
    os.chdir(WT)
    resources = Resources(a)
    image = OUT / "tmp/quoridor-runner"
    started = time.monotonic()
    result = {
        "actual_START": datetime.now(timezone.utc).isoformat(),
        "functional_slots": 0,
        "new_functional_slots": 0,
        "scientific_slots": 16,
        "compiled_replay_NN0": [],
        "commands": [],
        "runs": [],
        "qualified": False,
        "compile_calls": 0,
    }
    failure = None
    created_image = created_tmp = False
    os.environ.update(
        CUDA_VISIBLE_DEVICES="",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        ORT_DISABLE_TELEMETRY="1",
        TMPDIR=str(image.parent),
        PYTHONDONTWRITEBYTECODE="1",
    )
    try:
        with Path(a["cargo_lock"]).open("a") as lock, P.cancellation_signals():
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fair_quiet()
            image.parent.mkdir()
            created_tmp = True
            with (
                gzip.open(a["runner_gzip"], "rb") as source,
                image.open("xb") as target,
            ):
                created_image = True
                shutil.copyfileobj(source, target, 65536)
            image.chmod(0o755)
            if (
                image.stat().st_size != a["runner_ELF_bytes"]
                or S.sha(image) != a["runner_ELF_SHA256"]
            ):
                raise ValueError("immutable current payload decode mismatch")
            resources.check()
            result["functional_STOP_receipt"] = bound_json(
                a, a["functional_STOP_receipt"]
            )
            for name in ["initial", "main"]:
                fair_quiet()
                result["commands"].append(
                    H.execute(
                        image,
                        ["arena", "--config", str(OUT / ("config-" + name + ".json"))],
                        "arena-" + name,
                        resources,
                    )
                )
                result["runs"].append(collect_scientific(name, a))
                for operation in ["audit", "recover"]:
                    result["commands"].append(
                        H.execute(
                            image,
                            ["arena", "--" + operation, str(OUT / ("run-" + name))],
                            operation + "-" + name,
                            resources,
                        )
                    )
            result["actual_planned_slots_collected"] = 16
            result["strength_qualification"] = (
                "PENDING actual census/counters/UNKNOWN/draw/pairs/clock inspection"
            )

            result["qualified"] = True
    except BaseException as error:
        failure = repr(error)
    finally:
        failure = H.finalize(
            result, failure, resources, a, image, created_image, created_tmp, started
        )
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
