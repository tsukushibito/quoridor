"""One private-only execution scope; historical compiler charges remain held."""

import hashlib
import json
from pathlib import Path
import stat

TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")
HISTORICAL_RLIB = str(TARGET / "release/deps/libquoridor_runner-6aaa82ac9921176f.rlib")
RLIB_MAX = 9236480
POSITIVE_FLOOR = 35225600
PROFILE = "current-e4b-private-functional-four-v1"
BASELINE_SHA = "86b76641353ecf4c5a0107522f97a308b68981a733fc8279fddb504a6312430d"
ROOT = Path(__file__).resolve().parents[2]
ASSETS = Path("/workspaces/quoridor/.worktree/assets")
BEST = (
    ASSETS
    / "checkpoints/public-full-learning/trigger-patience-v1/patience1/output/best-model"
)
FIXED_INPUTS = {
    str(
        ROOT / "current-compiler-software-recovery-v2/private/quoridor-runner.gz"
    ): "fc7f0ceecc75c132bafb71fccfb180456245432f3175fba1dbfe5a3c87a110ad",
    str(
        BEST / "manifest.json"
    ): "c4712e0872b6831e33fcf59b99d9d7f774d18a3e8d5236d7923ba65e64aabc39",
    str(
        BEST / "weights.f32"
    ): "9ca438e43b0c105ac5f802a302946f2ba71623ea2bc443b9c54cc9a8468b75b0",
    str(
        ASSETS / "models/ai-sigma/reference/sigma-pcr250/best.onnx"
    ): "d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d",
    "/home/vscode/.cache/inference/envs/quoridor-training/lib/python3.14/site-packages/onnxruntime/capi/libonnxruntime.so.1.30.0": "c902c70b3003c0e99fada202f37478c515ae9bba7944c2b2abd0017bae0c82ed",
}


def bound_json(admission, path):
    """Membership before IO; hash and parse the same immutable bytes."""
    if path not in admission["bindings"]:
        raise ValueError("unbound record: " + path)
    raw = Path(path).read_bytes()
    if (
        len(raw) > 1048576
        or hashlib.sha256(raw).hexdigest() != admission["bindings"][path]
    ):
        raise ValueError("record size/SHA mismatch: " + path)
    return json.loads(raw)


def validate_inputs(admission):
    if admission["execution_profile"] != PROFILE:
        raise ValueError("unsupported private execution profile")
    inputs = admission["execution_inputs"]
    if not inputs or len({row["path"] for row in inputs}) != len(inputs):
        raise ValueError("empty/duplicate execution inputs")
    if {row["path"]: row["SHA256"] for row in inputs} != FIXED_INPUTS:
        raise ValueError("execution inputs differ from the five fixed retained bodies")
    if any(row["path"] == HISTORICAL_RLIB for row in inputs):
        raise ValueError("historical compiler archive is not a runtime input")
    for row in inputs:
        path = Path(row["path"])
        if not path.is_absolute() or ".." in path.parts or path.is_symlink():
            raise ValueError("noncanonical execution input")
        if admission["bindings"].get(str(path)) != row["SHA256"]:
            raise ValueError("runtime input digest not bound")
        info = path.stat()  # Every runtime input must exist; no missing exception.
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o777 != row["mode"]:
            raise ValueError("runtime input type/mode mismatch")
        if (
            info.st_size != row["bytes"]
            or info.st_blocks * 512 > row["allocated_upper_B"]
        ):
            raise ValueError("runtime input allocation/size mismatch")
        with path.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        if digest != row["SHA256"]:
            raise ValueError("runtime input SHA mismatch")
