"""Verify retained sixteen-slot evidence without invoking an engine."""

import collections
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import struct

OUT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    admission = load(OUT / "admission.json")
    worker = load(OUT / "result.json")
    controller = load(OUT / "job-runtime-v1/result.json")
    state = load(OUT / "job-runtime-v1/state.json")
    assert controller["exit_code"] == 0 and controller["direct_child_reaped"]
    assert controller["cleanup_complete"] and controller["remaining"] == []
    assert worker["qualified"] and worker["primary_error"] is None
    assert worker["finalization_errors"] == worker["financial_errors"] == []
    assert worker["charge_io_errors"] == worker["remaining"] == []
    assert not (OUT / "tmp").exists()
    packet = load(OUT / "source-control-STOP-v2-explicit-model.json")
    for name, binding in packet["bindings"].items():
        path = Path(name)
        info = path.stat()
        assert digest(path) == binding["SHA256"]
        assert info.st_size == binding["bytes"]
        assert info.st_mode & 0o777 == binding["mode"]
    records, identities = [], []
    for attempt, returned in zip(worker["attempted_children"], worker["commands"]):
        path = Path(attempt["receipt"])
        receipt = load(path)
        assert receipt["command"] == attempt["argv"] == returned["command"]
        assert receipt["exit_code"] == 0 and receipt["direct_child_reaped"]
        assert receipt["cleanup_complete"] and receipt["handle_closes_complete"]
        assert receipt["remaining"] == []
        identities.append(receipt["child"])
        records.append(
            {
                "name": attempt["name"],
                "SHA256": digest(path),
                "child": receipt["child"],
                "directwait_exit0_cleanup": True,
                "persisted_mask": receipt["signal_mask_restoration"],
                "persisted_final_record": receipt["final_record_persist"],
                "returned_mask": returned["signal_mask_restoration"],
                "returned_final_record": returned["final_record_persist"],
            }
        )
    assert [r["name"] for r in records] == [
        op + "-" + phase
        for phase in ["initial", "main"]
        for op in ["arena", "audit", "recover"]
    ]
    identities.append(state["child"])
    for identity in identities:
        path = Path("/proc") / str(identity["pid"]) / "stat"
        try:
            same = (
                path.read_text().rpartition(") ")[2].split()[19]
                == identity["start_ticks"]
            )
        except FileNotFoundError:
            same = False
        assert not same
    counts, calls = collections.Counter(), collections.Counter()
    rejected, slots, pairs, cohorts = [], [], [], []
    artifact_bindings = {}
    for phase, planned_count in [("initial", 2), ("main", 14)]:
        target = OUT / ("run-" + phase)
        report = load(target / "result.json")
        manifest = load(target / "manifest.json")
        planned = load(target / "planned.json")
        journal = [
            json.loads(row)
            for row in (target / "completed.jsonl").read_text().splitlines()
        ]
        games = list(csv.DictReader(io.StringIO((target / "games.csv").read_text())))
        assert (
            len(journal)
            == len(games)
            == len(planned)
            == len(report["outcomes"])
            == report["planned"]
            == planned_count
        )
        assert report["all_workers_joined"] and report["stopped"] is None
        assert (
            load(OUT / ("audit-" + phase + ".log"))
            == report["arena_summary"]
            == manifest["summary"]
        )
        assert manifest["binding"]["planned_slots"] == planned
        assert (
            manifest["binding"]["executable_sha256"] == admission["runner_ELF_SHA256"]
        )
        assert (
            manifest["binding"]["rules"]
            == "research-standard-2p-threefold-goal-first-v1"
        )
        assert manifest["cleanup"]["gzip_child_reaped"]
        assert manifest["binding"]["admission"]["serial_shared_inference"]
        assert manifest["binding"]["admission"]["worker_cores"] == [0]
        assert manifest["binding"]["admission"]["inference_core"] == 0
        for key, expected in admission["critical_compiled_sources"].items():
            assert manifest["binding"]["compiled_sources"][key] == expected
        for name, binding in manifest["artifacts"].items():
            path = target / name
            assert (
                path.stat().st_size == binding["bytes"]
                and digest(path) == binding["sha256"]
            )
            artifact_bindings[str(path)] = binding
        backend = report["pump"]["backend_work"]
        assert backend["warm_rows"] == backend["failed_rows"] == 0
        expected_moves = []
        for outcome, durable, plan, csvrow in zip(
            report["outcomes"], journal, planned, games
        ):
            assert outcome == durable and outcome["started"]
            assert outcome["game"] == plan["game"] == int(csvrow["game"])
            assert outcome["status"] == csvrow["status"]
            assert outcome["candidate_color"] == plan["candidate_color"]
            assert outcome["moves"][: len(plan["opening"])] == plan["opening"]
            assert outcome["plies"] == len(outcome["moves"])
            assert (
                sum(count for key, count in plan["replay"]["history"])
                == len(plan["opening"]) + 1
            )
            accepted = []
            for observation in outcome["observations"]:
                expected_moves.append(
                    {"game": outcome["game"], "observation": observation}
                )
                assert observation["engine_error"] is None
                assert observation["engine_index"] == (
                    0 if observation["side"] == outcome["candidate_color"] else 1
                )
                calls["attempted"] += 1
                calls["accepted"] += observation["accepted"]
                counters = observation["counters"]
                for key in [
                    "nodes",
                    "nn_requests_attempted",
                    "completed_simulations",
                    "discarded_late_replies",
                ]:
                    calls[key] += counters.get(key, 0)
                if observation["engine_index"] == 1:
                    assert counters["nodes"] <= 1000000
                if observation["accepted"]:
                    assert observation["failure"] is None
                    assert observation["accepted_ns"] < observation["deadline_ns"]
                    accepted.append(observation["action"])
                else:
                    assert observation["failure"] == "time_overrun"
                    assert observation["accepted_ns"] is None
                    assert (
                        observation["admission_checked_ns"]
                        >= observation["deadline_ns"]
                    )
                    assert observation["engine_index"] == 0
                    rejected.append(
                        {
                            "phase": phase,
                            "game": outcome["game"],
                            "ply": observation["ply"],
                            "engine": "Sigma",
                            "caller_seconds": observation["caller_seconds"],
                            "returned_before_deadline": observation["returned_ns"]
                            < observation["deadline_ns"],
                            "excess_ns": observation["admission_checked_ns"]
                            - observation["deadline_ns"],
                            "rejected_action": observation["action"],
                        }
                    )
            assert accepted == outcome["moves"][len(plan["opening"]) :]
            tt = outcome["persistent_tt"][1]
            assert (
                tt["effective_tt_slots"] == 4096
                and tt["persistent_tt_byte_cap"] == 1048576
            )
            if outcome["status"] == "goal":
                counts[
                    "Sigma_W"
                    if outcome["winner"] == outcome["candidate_color"]
                    else "Sigma_L"
                ] += 1
            elif outcome["status"] == "draw":
                counts["draw"] += 1
            else:
                assert (
                    outcome["status"] == "unknown"
                    and outcome["winner"] is None
                    and outcome["failure"] == "time_overrun"
                )
                counts["unknown"] += 1
            slots.append(
                {
                    "phase": phase,
                    **{
                        key: outcome[key]
                        for key in [
                            "game",
                            "family",
                            "candidate_color",
                            "status",
                            "winner",
                            "plies",
                            "reason",
                            "failure",
                        ]
                    },
                }
            )
        with gzip.open(target / "moves.jsonl.gz", "rt") as stream:
            moves = [json.loads(row) for row in stream]
        assert len(moves) == len(expected_moves)
        for actual, expected in zip(moves, expected_moves):
            assert actual["game"] == expected["game"]
            left, right = dict(actual["observation"]), dict(expected["observation"])
            # Journal Value and direct f32 serde spelling differ; original f32 bits must agree.
            assert struct.pack("!f", left.pop("value_stm")) == struct.pack(
                "!f", right.pop("value_stm")
            )
            assert left == right
        for index in range(0, planned_count, 2):
            left, right = report["outcomes"][index : index + 2]
            assert left["family"] == right["family"] and [
                left["candidate_color"],
                right["candidate_color"],
            ] == [0, 1]
            pairs.append(
                {
                    "phase": phase,
                    "family": left["family"],
                    "complete": left["status"] != "unknown"
                    and right["status"] != "unknown",
                }
            )
        cohorts.append(
            {
                "phase": phase,
                "summary": report["arena_summary"],
                "backend_work": backend,
            }
        )
    assert counts == {"Sigma_W": 5, "unknown": 11}
    assert calls["attempted"] == 534 and calls["accepted"] == 523
    assert calls["nodes"] == 23202866 and calls["nn_requests_attempted"] == 6053
    assert len(pairs) == 8 and sum(pair["complete"] for pair in pairs) == 1
    summary = {
        "issue": "quoridor-4lc.336",
        "planned": 16,
        "started": 16,
        "decided": 5,
        "Sigma_W": 5,
        "Sigma_L": 0,
        "Distance_W": 0,
        "Distance_L": 5,
        "draw": 0,
        "unknown": 11,
        "complete_pairs": 1,
        "incomplete_pairs": 7,
        "Sigma_planned_score_bounds": [0.3125, 1.0],
        "Distance_planned_score_bounds": [0.0, 0.6875],
        "call_counters": dict(calls),
        "rejected_clock_windows": rejected,
        "Sigma_late_return_windows": sum(
            not x["returned_before_deadline"] for x in rejected
        ),
        "Sigma_return_in_time_admission_late_windows": sum(
            x["returned_before_deadline"] for x in rejected
        ),
        "slots": slots,
        "pairs": pairs,
        "cohorts": cohorts,
        "artifact_bindings": artifact_bindings,
        "scientific_main_commit": admission["scientific_main_commit"],
        "private_ELF_SHA256": admission["runner_ELF_SHA256"],
        "fixed_D": {"a": 0.0, "b": 8.0, "head": "Tanh", "nn_calls": 0},
        "pair_uncertainty_interval": None,
        "limits": "Eight opened correlated common-initial/PRNG families, one completed pair. No CI/Elo/global rank or independent precision. Eleven informative Sigma clock UNKNOWNs retained, not losses/draws/rescued/rerun. Original331/RuleA/operational4 separate; no triangle inference.",
        "known_all_controller_fees_seconds": 732.1099106160692
        + controller["wall_seconds"],
        "actual_STOP": controller["finished_at"],
        "remaining": [],
        "collection_STOP": datetime.now(timezone.utc).isoformat(),
    }
    target = OUT / "verified-outcome-summary-v1.json"
    assert not target.exists()
    target.write_text(json.dumps(summary, indent=2) + "\n")
    print(
        json.dumps(
            {
                "verified": True,
                "Sigma_W_D_L": 5,
                "unknown": 11,
                "complete_pairs": 1,
                "calls": dict(calls),
                "STOP": controller["finished_at"],
            }
        )
    )


if __name__ == "__main__":
    main()
