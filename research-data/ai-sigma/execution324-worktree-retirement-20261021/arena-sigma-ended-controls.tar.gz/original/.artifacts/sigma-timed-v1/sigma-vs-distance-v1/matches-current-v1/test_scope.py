"""No scientific fixture replay; reused exact collector and lifecycle scope."""

import ast
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    module = ast.parse((root / "qualify.py").read_text())
    assert {x.name for x in module.body if isinstance(x, ast.FunctionDef)} >= {
        "validate",
        "collect_scientific",
        "main",
    }
    print(
        "source syntax only; prior collector/lifecycle proofs reused; science NOT_RUN"
    )


if __name__ == "__main__":
    main()
