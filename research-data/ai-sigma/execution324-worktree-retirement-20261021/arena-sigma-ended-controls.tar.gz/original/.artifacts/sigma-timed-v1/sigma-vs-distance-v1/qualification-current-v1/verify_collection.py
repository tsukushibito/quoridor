"""Collect fixed four operational windows, without executing an engine."""

from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import struct

OUT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    a, r = load(OUT / "admission.json"), load(OUT / "result.json")
    c = load(OUT / "job-runtime-v1/result.json")
    state = load(OUT / "job-runtime-v1/state.json")
    assert c["exit_code"] == 0 and c["direct_child_reaped"]
    assert c["cleanup_complete"] and not c["remaining"]
    assert r["qualified"] and r["primary_error"] is None
    assert not any(
        r[k]
        for k in [
            "remaining",
            "finalization_errors",
            "financial_errors",
            "charge_io_errors",
        ]
    )
    assert not (OUT / "tmp").exists()
    packet = load(OUT / "source-control-STOP-v1.json")
    for name, binding in packet["bindings"].items():
        p = Path(name)
        assert sha(p) == binding["SHA256"]
        assert p.stat().st_size == binding["bytes"]
        assert p.stat().st_mode & 0o777 == binding["mode"]
    attempts = r["attempted_children"]
    assert [x["name"] for x in attempts] == [
        op + "-" + phase
        for phase in ["initial", "p2"]
        for op in ["arena", "audit", "recover"]
    ]
    assert len(r["commands"]) == len(attempts) == 6
    records, identities = [], [state["child"]]
    for attempt, returned in zip(attempts, r["commands"]):
        p = Path(attempt["receipt"])
        receipt = load(p)
        assert receipt["command"] == attempt["argv"] == returned["command"]
        assert receipt["exit_code"] == 0 and receipt["direct_child_reaped"]
        assert receipt["cleanup_complete"] and receipt["handle_closes_complete"]
        assert not receipt["remaining"]
        identities.append(receipt["child"])
        records.append(
            {
                "name": attempt["name"],
                "SHA256": sha(p),
                "child": receipt["child"],
                "directwait_exit0_cleanup": True,
                "persisted_mask": receipt["signal_mask_restoration"],
                "persisted_final_record": receipt["final_record_persist"],
                "returned_mask": returned["signal_mask_restoration"],
            }
        )
    for identity in identities:
        try:
            same = (
                Path("/proc") / str(identity["pid"]) / "stat"
            ).read_text().rpartition(") ")[2].split()[19] == identity["start_ticks"]
        except FileNotFoundError:
            same = False
        assert not same
    windows, rows, nodes = [], 0, 0
    for phase, total in [("initial", 1), ("p2", 2)]:
        p = OUT / ("run-" + phase)
        report, manifest = load(p / "result.json"), load(p / "manifest.json")
        assert manifest["binding"]["executable_sha256"] == a["runner_ELF_SHA256"]
        assert (
            manifest["binding"]["rules"]
            == "research-standard-2p-threefold-goal-first-v1"
        )
        assert manifest["binding"]["config"]["arena"]["evaluator_sha256"] == [
            "d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d",
            "c83db10ba1403b7fc3417e73e14cc5f1a1040c65ac4ac23a5f5703abbb5aa887",
        ]
        for key, value in a["critical_compiled_sources"].items():
            assert manifest["binding"]["compiled_sources"][key] == value
        for name, binding in manifest["artifacts"].items():
            assert sha(p / name) == binding["sha256"]
            assert (p / name).stat().st_size == binding["bytes"]
        assert manifest["cleanup"]["gzip_child_reaped"]
        assert (
            load(OUT / ("audit-" + phase + ".log"))
            == report["arena_summary"]
            == manifest["summary"]
        )
        recovery = load(OUT / ("recover-" + phase + ".log"))
        assert recovery["missing_slots"] == []
        journal = [
            json.loads(line)
            for line in (p / "completed.jsonl").read_text().splitlines()
        ]
        assert journal == report["outcomes"]
        assert (
            report["planned"] == len(journal) == 2
            and report["all_workers_joined"]
            and report["stopped"] is None
        )
        with gzip.open(p / "moves.jsonl.gz", "rt") as f:
            moves = [json.loads(line) for line in f]
        assert len(moves) == 2
        engines = []
        for outcome, move in zip(journal, moves):
            assert outcome["status"] == "unknown" and outcome["winner"] is None
            assert (
                outcome["reason"] == "ply_cap_before_terminal"
                and outcome["failure"] == "ply_cap"
            )
            assert outcome["plies"] == total and len(outcome["observations"]) == 1
            ob = outcome["observations"][0]
            assert (
                ob["accepted"] and ob["failure"] is None and ob["engine_error"] is None
            )
            assert ob["accepted_ns"] < ob["deadline_ns"]
            left, right = dict(move["observation"]), dict(ob)
            assert struct.pack("!f", left.pop("value_stm")) == struct.pack(
                "!f", right.pop("value_stm")
            )
            assert left == right and move["game"] == outcome["game"]
            engines.append(ob["engine_index"])
            if ob["engine_index"] == 1:
                tt = outcome["persistent_tt"][1]
                assert (
                    tt["effective_tt_slots"] == 4096
                    and tt["persistent_tt_byte_cap"] == 1048576
                )
                assert outcome["nn_calls"] == 0 and ob["counters"]["nodes"] <= 1000000
                nodes += ob["counters"]["nodes"]
            windows.append(
                {
                    "phase": phase,
                    "engine": ob["engine_index"],
                    "caller_seconds": ob["caller_seconds"],
                    "action": ob["action"],
                    "status": outcome["status"],
                }
            )
        assert sorted(engines) == [0, 1]
        work = report["pump"]["backend_work"]
        assert (
            work["warm_rows"] == work["failed_rows"] == 0 and work["logical_rows"] <= 64
        )
        rows += work["logical_rows"]
    result = {
        "issue": "quoridor-4lc.336",
        "qualified_fixed_functional_scope": True,
        "joined_windows": 4,
        "Sigma_windows": 2,
        "D_windows": 2,
        "scientific_slots": 0,
        "main_commit": a["scientific_main_commit"],
        "ELF_SHA256": a["runner_ELF_SHA256"],
        "job_id": c["job_id"],
        "actual_START": state["started_at"],
        "worker_STOP": r["actual_STOP"],
        "controller_STOP": c["finished_at"],
        "actual_STOP": c["finished_at"],
        "all6_directwait_cleanup": records,
        "exact7_science_identities_absent": identities,
        "metadata_supervisor": state["supervisor"],
        "remaining": [],
        "TMP_absent": True,
        "Sigma_requests": rows,
        "D_nodes": nodes,
        "windows": windows,
        "controller_wall_seconds": c["wall_seconds"],
        "known_all_controller_fees_seconds": 730.5251211230644 + c["wall_seconds"],
        "whole_forecast_B": 4275699712,
        "supported_B": 4294967296,
        "sample_family_RSS_B": r["RAM_family_sampled_B"],
        "sample_output_B": r["qualification_allocated_peak_B"],
        "sample_TMP_B": r["TMP_allocated_peak_B"],
        "continuous_peak": "UNKNOWN",
        "persisted_mask_fault_qualification": "UNKNOWN; pending/attempted disk facts retained distinctly",
        "historical_positive_floor_B": 35225600,
        "missing6aaa_UNKNOWN_max_B": 9236480,
        "source_packet_SHA256": sha(OUT / "source-control-STOP-v1.json"),
        "current_next_job_Cargo_model_fairclock": "NONE",
        "closed_peer_PRE_RPC_refusals": ["333", "340"],
        "collection_admin_read_refusals": [
            "relative docs paths absent; actual main docs read",
            "collection KeyError guessed Sigma_SHA256 field; corrected fixed evaluator literals; no engine rerun",
        ],
        "collection_STOP": datetime.now(timezone.utc).isoformat(),
    }
    target = OUT / "qualified-functional-STOP-receipt-v1.json"
    assert not target.exists()
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "qualified": True,
                "STOP": c["finished_at"],
                "Sigma_requests": rows,
                "D_nodes": nodes,
                "receipt": str(target),
            }
        )
    )


if __name__ == "__main__":
    main()
