"""Exact v14-reviewed callable bodies; caller supplies this phase's bound ports."""

from datetime import datetime, timezone
import json
import time
from pathlib import Path
from typing import Any, Callable

OUT: Path | None = None
P: Any = None
save: Callable | None = None
bound_json: Callable | None = None


def error_fact(stage, error):
    return {"stage": stage, "type": type(error).__name__, "message": str(error)}


def execute(image, args, name, resources, expected_failure=False):
    # This finite entry can only use the immutable maintained arena CLI.
    if not args or args[0] != "arena":
        raise ValueError("non-arena command not admitted")
    log = OUT / (name + ".log")
    receipt = str(log.with_suffix(".process.json"))
    if any(a["receipt"] == receipt for a in resources.attempted_children):
        raise ValueError("duplicate child attempt/receipt")
    # Registered before P.execute, including any pre-Popen refusal/IO failure.
    resources.attempted_children.append(
        {"name": name, "receipt": receipt, "argv": [str(image), *args]}
    )
    try:
        record = P.execute(
            [str(image), *args], log, None, cpu_core=0, resources=resources
        )
    except P.CycleStopped:
        if not expected_failure:
            raise
        record = json.loads(log.with_suffix(".process.json").read_text())
        if (
            record["exit_code"] != 1
            or not record.get("error", "").startswith("cycle child failed:")
            or not record["direct_child_reaped"]
            or not record["cleanup_complete"]
            or record["remaining"]
            or "recovery history/Q mismatch" not in log.read_text()
        ):
            raise
    else:
        if expected_failure:
            raise ValueError("deliberately wrong replay expectation was accepted")
    resources.check()
    return record


def finalize(
    result, failure, resources, admission, image, created_image, created_tmp, started
):
    """Attempt every owned cleanup/accounting/publication stage independently."""
    errors = []

    def attempt(stage, action, fallback=None):
        try:
            return action()
        except BaseException as error:
            errors.append(error_fact(stage, error))
            return fallback

    if created_image:
        attempt("TMP_image_unlink", lambda: image.unlink(missing_ok=True))
    if created_tmp:
        attempt("TMP_directory_rmdir", image.parent.rmdir)

    # This explicit stat census reports uncertainty rather than claiming empty TMP.
    def temporary_remaining():
        try:
            return [str(p) for p in image.parent.iterdir()]
        except FileNotFoundError:
            return []

    tmp_remaining = attempt("TMP_remaining_read", temporary_remaining)
    paths = attempt("process_receipt_paths", lambda: list(OUT.glob("*.process.json")))
    records = []
    receipt_unknown = paths is None
    attempts = getattr(resources, "attempted_children", None)
    if (
        attempts is None
        or paths is None
        or len({a["receipt"] for a in attempts}) != len(attempts)
        or {str(p) for p in paths} != {a["receipt"] for a in attempts}
    ):
        receipt_unknown = True
        errors.append(
            {
                "stage": "partial_process_receipt_census",
                "type": "UnknownReceipt",
                "message": "attempt registry absent/duplicate or missing/unexpected receipt",
            }
        )
    for path in paths or []:
        record = attempt(
            "process_receipt_read:" + path.name,
            lambda p=path: json.loads(p.read_text()),
        )
        if record is None:
            receipt_unknown = True
        elif not isinstance(record, dict) or not isinstance(
            record.get("remaining"), list
        ):
            receipt_unknown = True
            errors.append(
                {
                    "stage": "process_receipt_schema:" + path.name,
                    "type": "InvalidReceipt",
                    "message": "missing typed directwait/cleanup facts",
                }
            )
        else:
            records.append(record)
            matching = [a for a in attempts or [] if a["receipt"] == str(path)]
            if len(matching) != 1 or record.get("command") != matching[0]["argv"]:
                receipt_unknown = True
                errors.append(
                    {
                        "stage": "process_receipt_attempt:" + path.name,
                        "type": "UnknownReceipt",
                        "message": "receipt does not match registered attempted argv",
                    }
                )

    if result.get("qualified"):
        # Exactly six current arena/audit/recover receipts; all previous jobs
        # remain independently bound historical evidence.
        expected = {
            "arena-initial.process.json",
            "audit-initial.process.json",
            "recover-initial.process.json",
            "arena-main.process.json",
            "audit-main.process.json",
            "recover-main.process.json",
        }
        if paths is None or {p.name for p in paths} != expected:
            receipt_unknown = True
            errors.append(
                {
                    "stage": "process_receipt_census",
                    "type": "UnknownReceipt",
                    "message": "successful scientific plan lacks exact six receipts",
                }
            )
    if any(
        r.get("direct_child_reaped") is not True
        or r.get("cleanup_complete") is not True
        or r.get("remaining")
        for r in records
    ):
        receipt_unknown = True
        errors.append(
            {
                "stage": "process_receipt_cleanup",
                "type": "UnknownCleanup",
                "message": "directwait/cleanup not verified",
            }
        )

    def final_financial():
        resources.finance.check()
        if resources.finance.held > admission["caps_B"]["positive"]:
            raise ValueError("final retained positive component cap exceeded")

    attempt("financial_final_stat", final_financial)
    # The max ledger survives failed stat; charge and result publication are separate.
    charge_saved = attempt(
        "charge_final_write",
        lambda: (
            save("charged-path-maxima.json", resources.finance.record(admission)),
            True,
        )[1],
        False,
    )
    cleanup_complete = (
        not receipt_unknown
        and tmp_remaining == []
        and all(r.get("cleanup_complete") for r in records)
        and not any(e["stage"].startswith(("TMP_", "process_receipt_")) for e in errors)
    )
    remaining = [m for r in records for m in r.get("remaining", [])]
    if tmp_remaining:
        remaining.extend({"owned_TMP": p} for p in tmp_remaining)
    if tmp_remaining is None or receipt_unknown:
        remaining.append({"scope": "TMP/process_receipts", "status": "UNKNOWN"})
    result.update(
        actual_STOP=datetime.now(timezone.utc).isoformat(),
        whole_seconds=time.monotonic() - started,
        primary_error=failure,
        error=failure,
        finalization_errors=errors,
        financial_errors=list(resources.financial_errors),
        charge_io_errors=list(resources.charge_io_errors),
        charge_persistence="SAVED" if charge_saved else "UNKNOWN",
        result_persistence="ATTEMPTED",
        all_direct_children_reaped=not receipt_unknown
        and all(r.get("direct_child_reaped") for r in records),
        cleanup_complete=cleanup_complete,
        remaining=remaining,
        charged_positive_union_B=resources.finance.held,
        historical_unknown=resources.finance.unknown,
        RAM_family_sampled_B=resources.rss_peak,
        qualification_allocated_peak_B=resources.output_peak,
        TMP_allocated_peak_B=resources.tmp_peak,
    )
    result["attempted_children"] = attempts
    if (
        failure is not None
        or errors
        or resources.financial_errors
        or resources.charge_io_errors
    ):
        result["qualified"] = False
        result["error"] = failure or json.dumps(
            errors or resources.financial_errors or resources.charge_io_errors
        )
    result["result_persistence"] = "SAVED_IF_THIS_WRITE_SUCCEEDS"
    result_saved = attempt(
        "result_write", lambda: (save("result.json", result), True)[1], False
    )
    if not result_saved:
        result["qualified"] = False
        result["result_persistence"] = "UNKNOWN"
        result["error"] = failure or json.dumps(errors)
    # Bounded outer job output is an independent evidence channel when disk IO fails.
    if not result_saved or not charge_saved:
        attempt(
            "terminal_receipt_emit",
            lambda: print(
                json.dumps(
                    {
                        key: result[key]
                        for key in [
                            "primary_error",
                            "error",
                            "finalization_errors",
                            "financial_errors",
                            "charge_io_errors",
                            "charge_persistence",
                            "result_persistence",
                            "remaining",
                            "charged_positive_union_B",
                        ]
                    },
                    allow_nan=False,
                ),
                flush=True,
            ),
        )
    if errors or resources.financial_errors or resources.charge_io_errors:
        # If every output channel fails, the raised terminal error still carries
        # the primary, individual stage causes, uncertainty and retained charge.
        result["error"] = json.dumps(
            {
                "primary_error": failure,
                "finalization_errors": errors,
                "financial_errors": resources.financial_errors,
                "charge_io_errors": resources.charge_io_errors,
                "charged_positive_union_B": resources.finance.held,
                "remaining": remaining,
            }
        )
    return result["error"]
