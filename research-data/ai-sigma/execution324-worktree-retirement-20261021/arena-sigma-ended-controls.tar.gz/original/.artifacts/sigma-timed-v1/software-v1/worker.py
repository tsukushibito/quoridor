"""One finite NN0 Sigma adapter software phase, with exact named growth accounting."""

import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import time
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
WT = ROOT.parents[1]
TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")
CONTROL = Path("/workspaces/quoridor/python/quoridor_training/cycle_process.py")
SPEC = importlib.util.spec_from_file_location("canonical_cycle", CONTROL)
P = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(P)
P.LOG_MAX_BYTES = 262144
CARGO = "/usr/local/cargo/bin/cargo"
BASE = ["--offline", "--locked", "-j", "2"]


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def allocated(root):
    # Dedicated bounded folders only; no global/shared target enumeration.
    for attempt in range(2):
        total = 0
        folders = [Path(root)]
        inconsistent = False
        count = 0
        while folders:
            folder = folders.pop()
            try:
                with os.scandir(folder) as entries:
                    for entry in entries:
                        count += 1
                        if count > 512:
                            raise P.CycleStopped("dedicated inventory bound exceeded")
                        try:
                            info = entry.stat(follow_symlinks=False)
                        except FileNotFoundError:
                            inconsistent = True
                            continue
                        total += info.st_blocks * 512
                        if stat.S_ISDIR(info.st_mode):
                            folders.append(Path(entry.path))
            except FileNotFoundError:
                inconsistent = True
        if not inconsistent:
            return total
    raise P.CycleStopped("dedicated inventory UNKNOWN after bounded retry")


def quiet():
    names = {
        "cargo",
        "rustc",
        "clippy-driver",
        "rust-lld",
        "ld.lld",
        "quoridor-runner",
        "nnue-diagnose",
        "nnue_search",
    }
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            argv = (entry / "cmdline").read_bytes().split(b"\0")
        except (FileNotFoundError, ProcessLookupError):
            continue
        if argv and Path(os.fsdecode(argv[0])).name in names:
            raise P.CycleStopped("foreign compiler/science identity: " + entry.name)


class Resources(P.CycleResources):
    def __init__(self, baseline, source_growth):
        super().__init__({"max_memory_bytes": 2 * 1024**3 - 64 * 1024**2}, OUT, None)
        self.baseline = baseline
        self.source_growth = source_growth
        self.named = set()
        self.ram_peak = self.growth_peak = self.tmp_peak = self.private_peak = 0

    def emitted(self):
        for log in OUT.glob("*.log"):
            for line in log.read_text(errors="replace").splitlines():
                if not line.startswith("{"):
                    continue
                try:
                    row = json.loads(line)
                except ValueError:
                    continue  # Partial final line is checked by the final command parser.
                if row.get("reason") == "compiler-artifact" and not row.get("fresh"):
                    self.named.update(row.get("filenames", []))

    def check(self, owned=()):
        super().check(owned)
        self.emitted()
        ram = (
            sum(
                x["rss"]
                for x in [
                    P.process_info(os.getpid()),
                    *(P.process_info(m["pid"]) for m in owned),
                ]
                if x
            )
            + 64 * 1024**2
        )
        self.ram_peak = max(self.ram_peak, ram)
        if ram > 2 * 1024**3:
            raise P.CycleStopped("family RAM including controller exceeds2GiB")
        growth = 0
        identities = set()
        for path in self.named:
            try:
                info = Path(path).stat()
            except FileNotFoundError as error:
                raise P.CycleStopped("emitted named artifact UNKNOWN") from error
            identity = (info.st_dev, info.st_ino)
            if identity in identities:
                continue
            identities.add(identity)
            growth += max(0, info.st_blocks * 512 - self.baseline.get(path, 0))
        tmp = allocated(OUT / "tmp")
        private = allocated(OUT / "private")
        self.growth_peak = max(self.growth_peak, growth)
        self.tmp_peak = max(self.tmp_peak, tmp)
        self.private_peak = max(self.private_peak, private)
        if growth > 20 * 1024**2 or tmp > 8 * 1024**2 or private > 10 * 1024**2:
            raise P.CycleStopped("Sigma named-growth/TMP/private component cap")
        if growth + tmp + private > 40 * 1024**2:
            raise P.CycleStopped("Sigma build/private/TMP whole40MiB cap")
        control = allocated(ROOT) - tmp - private + self.source_growth
        if control > 4497408:
            raise P.CycleStopped("Sigma source/control frozen forecast exceeded")


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(WT)
    admission = json.loads((OUT / "admission.json").read_text())
    for path, expected in admission["bindings"].items():
        assert sha(path) == expected, path
    packet = json.loads(Path(admission["source_stop"]).read_text())
    for relative, row in packet["stopped_sources"].items():
        assert sha(WT / relative) == row["SHA256"]
        assert (WT / relative).stat().st_mode & 0o777 == row["mode"]
    for row in packet["unchanged_dependency_bindings"]:
        assert sha(WT / row["path"]) == row["SHA256"]
    assert P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 128 * 1024**2
    quiet()
    for name in ("tmp", "private"):
        (OUT / name).mkdir(exist_ok=True)
    os.environ.update(
        CARGO_TARGET_DIR=str(TARGET),
        CARGO_INCREMENTAL="0",
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        TMPDIR=str(OUT / "tmp"),
        CUDA_VISIBLE_DEVICES="",
        RUST_TEST_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
        CARGO_TERM_COLOR="never",
    )
    for name in (
        "RUSTFLAGS",
        "CARGO_ENCODED_RUSTFLAGS",
        "QUORIDOR_BENCH_MANIFEST",
        "QUORIDOR_BENCH_FT_MODE",
    ):
        os.environ.pop(name, None)
    baseline = json.loads((OUT / "named-baseline.json").read_text())
    resources = Resources(
        {r["path"]: r["allocated_B"] for r in baseline["rows"]},
        packet["source_positive_allocated_growth_B"],
    )
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "private": {},
        "models_nn_ft_calls": 0,
        "scientific_games": 0,
        "source_stop_SHA256": sha(admission["source_stop"]),
        "qualified_native_clock": False,
        "continuous_storage_peak": "UNKNOWN",
    }
    started = time.monotonic()

    def command(name, argv, cargo_json=False):
        quiet()
        log = OUT / (name + ".log")
        record = P.execute(argv, log, None, resources=resources)
        result["commands"].append({"name": name, **record})
        if record["log_bytes_seen"] > P.LOG_MAX_BYTES:
            raise P.CycleStopped("compiler provenance log tail truncated: UNKNOWN")
        rows = []
        if cargo_json:
            for line in log.read_text().splitlines():
                if line.startswith("{"):
                    rows.append(json.loads(line))
            resources.emitted()
        resources.check()
        return rows

    def harness(name, target, cases):
        rows = command(
            name + "-build",
            [
                CARGO,
                "test",
                *BASE,
                "--release",
                "-p",
                "quoridor-runner",
                *target,
                "--no-run",
                "--message-format=json",
            ],
            True,
        )
        images = [
            r["executable"]
            for r in rows
            if r.get("reason") == "compiler-artifact"
            and r.get("executable")
            and r.get("profile", {}).get("test")
        ]
        assert len(images) == 1
        for index, case in enumerate(cases):
            command(
                f"{name}-fixture{index}",
                [images[0], case, "--nocapture", "--test-threads=1"],
            )
        raw = Path(images[0]).read_bytes()
        compressed = gzip.compress(raw, mtime=0)
        assert gzip.decompress(compressed) == raw
        path = OUT / "private" / (name + ".gz")
        path.write_bytes(compressed)
        result["private"][name] = {
            "gzip_SHA256": sha(path),
            "ELF_SHA256": hashlib.sha256(raw).hexdigest(),
            "ELF_bytes": len(raw),
            "roundtrip": True,
        }
        resources.check()

    failure = None
    with (TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet()
        try:
            freshness = []
            for name in ["core", "nnue", "ai", "data", "inference", "runner"]:
                path = WT / f"crates/quoridor-{name}/src/lib.rs"
                before = sha(path)
                old_ns = path.stat().st_mtime_ns
                os.utime(path, ns=(path.stat().st_atime_ns, time.time_ns()))
                assert sha(path) == before
                freshness.append(
                    {
                        "path": str(path),
                        "SHA256": before,
                        "old_mtime_ns": old_ns,
                        "new_mtime_ns": path.stat().st_mtime_ns,
                    }
                )
            save("owned-freshness.json", freshness)
            command("compiler", ["/usr/local/cargo/bin/rustc", "-Vv"])
            rows = command(
                "release",
                [
                    CARGO,
                    "build",
                    *BASE,
                    "--release",
                    "-p",
                    "quoridor-runner",
                    "--bin",
                    "quoridor-runner",
                    "--message-format=json",
                ],
                True,
            )
            own = [
                r
                for r in rows
                if r.get("reason") == "compiler-artifact"
                and r.get("target", {}).get("src_path", "").startswith(str(WT) + "/")
            ]
            for name in [
                "quoridor_core",
                "quoridor_nnue",
                "quoridor_ai",
                "quoridor_data",
                "quoridor_inference",
                "quoridor_runner",
            ]:
                assert any(
                    r["target"]["name"] == name and not r["fresh"] for r in own
                ), name
            save(
                "release-own-payloads.json",
                [
                    {
                        "target": r["target"],
                        "profile": r["profile"],
                        "fresh": r["fresh"],
                        "payloads": [
                            {
                                "path": p,
                                "SHA256": sha(p),
                                "allocated_B": Path(p).stat().st_blocks * 512,
                            }
                            for p in r["filenames"]
                        ],
                    }
                    for r in own
                ],
            )
            image = next(
                r["executable"]
                for r in own
                if r.get("executable") and r["target"]["name"] == "quoridor-runner"
            )
            destination = OUT / "private" / "quoridor-runner"
            shutil.copy2(image, destination)
            assert sha(image) == sha(destination) and destination.stat().st_mode & 0o111
            result["private"]["runner"] = {
                "path": str(destination),
                "SHA256": sha(destination),
                "bytes": destination.stat().st_size,
                "mode": destination.stat().st_mode & 0o777,
            }
            resources.check()
            harness(
                "caller", ["--lib"], ["sigma_clock::tests::", "sigma_reply_tests::"]
            )
            harness(
                "arena",
                ["--test", "arena"],
                ["timed_sigma_is_whole_engine_serial_and_has_distinct_source_binding"],
            )
            harness(
                "sigma",
                ["--test", "sigma_clock"],
                [
                    "timed_pump_returns_partial_completion_and_keeps_error_and_late_typed"
                ],
            )
            command(
                "clippy",
                [
                    CARGO,
                    "clippy",
                    *BASE,
                    "-p",
                    "quoridor-runner",
                    "--lib",
                    "--bin",
                    "quoridor-runner",
                    "--test",
                    "arena",
                    "--test",
                    "sigma_clock",
                    "--message-format=json",
                    "--",
                    "-Dwarnings",
                ],
                True,
            )
        except BaseException as error:
            failure = str(error)
        finally:
            result.update(
                stopped=datetime.now(timezone.utc).isoformat(),
                whole_seconds=time.monotonic() - started,
                failure=failure,
                named_paths=sorted(resources.named),
                sampled_peaks={
                    "family_RAM_B": resources.ram_peak,
                    "positive_artifact_growth_B": resources.growth_peak,
                    "TMP_B": resources.tmp_peak,
                    "private_B": resources.private_peak,
                },
            )
            save("result.json", result)
    if failure:
        raise SystemExit(failure)


if __name__ == "__main__":
    main()
