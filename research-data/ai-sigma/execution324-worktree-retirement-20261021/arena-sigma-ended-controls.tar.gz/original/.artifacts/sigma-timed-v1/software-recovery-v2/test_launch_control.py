"""Exact refusal tests with a fake submit; no actual Cargo or job submission."""

import subprocess
import unittest

from launch_control import LaunchRefused, verified_submit


class LaunchTests(unittest.TestCase):
    def test_exceptions_and_nontrue_never_submit(self):
        for failure in [
            AssertionError("binding"),
            OSError("stat"),
            ValueError("parser"),
            subprocess.CalledProcessError(1, ["formatter"]),
            None,
            False,
        ]:
            with self.subTest(failure=failure):
                calls = []

                def check():
                    if isinstance(failure, Exception):
                        raise failure
                    return failure

                with self.assertRaises(
                    (
                        AssertionError,
                        OSError,
                        ValueError,
                        subprocess.CalledProcessError,
                        LaunchRefused,
                    )
                ):
                    verified_submit(
                        [("source/format/admission", check)],
                        lambda: calls.append("submit"),
                    )
                self.assertEqual(calls, [])

    def test_all_checks_precede_only_submit(self):
        calls = []

        def check(name):
            calls.append(name)
            return True

        verified_submit(
            [
                ("format", lambda: check("format")),
                ("binding", lambda: check("binding")),
            ],
            lambda: calls.append("submit"),
        )
        self.assertEqual(calls, ["format", "binding", "submit"])


if __name__ == "__main__":
    unittest.main()
