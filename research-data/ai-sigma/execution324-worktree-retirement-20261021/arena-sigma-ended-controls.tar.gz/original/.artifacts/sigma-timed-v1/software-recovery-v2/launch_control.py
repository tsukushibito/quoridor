"""Ordered pre-submit barrier. Every check must succeed before one canonical submit."""

import subprocess


class LaunchRefused(RuntimeError):
    pass


def verified_submit(checks, submit):
    for name, check in checks:
        if check() is not True:
            raise LaunchRefused("check did not explicitly pass: " + name)
    return submit()


def checked_command(argv):
    subprocess.run(argv, check=True, capture_output=True, text=True, timeout=60)
    return True
