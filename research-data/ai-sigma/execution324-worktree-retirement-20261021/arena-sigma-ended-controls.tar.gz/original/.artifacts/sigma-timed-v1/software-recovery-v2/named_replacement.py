"""Exact owned artifact replacement accounting; absent bytes never become credit."""

from pathlib import Path


class NamedArtifactUnknown(RuntimeError):
    pass


class NamedReplacement:
    def __init__(self, original_baseline, prior_rows, known_missing):
        self.baseline = dict(original_baseline)
        self.prior = {row["path"]: row["allocated_B"] for row in prior_rows}
        self.known_missing = set(known_missing)
        if not self.known_missing <= self.prior.keys():
            raise NamedArtifactUnknown(
                "missing reconstruction lacks retained allocation"
            )
        self.outputs = set(self.prior)
        self.lease = set()
        self.state = "preparation"
        self.events = []

    def retain(self, observed_maxima):
        """Restore only a bound derived charge record; the frozen baseline stays fixed."""
        for path, amount in observed_maxima.items():
            if not isinstance(path, str) or type(amount) is not int or amount < 0:
                raise NamedArtifactUnknown("invalid retained charge record")
            self.prior[path] = max(self.prior.get(path, 0), amount)
            self.outputs.add(path)

    def begin(self, exact_outputs):
        if self.state not in {"preparation", "terminal"}:
            raise NamedArtifactUnknown("overlapping output replacement lease")
        self.lease = set(exact_outputs)
        if not self.lease <= self.prior.keys():
            raise NamedArtifactUnknown("replacement lease names an unbound old output")
        self.state = "prepared"

    def finish(self):
        # Closing the lease precedes final measurement; every emitted output
        # must exist at the terminal boundary, regardless of the prior charge.
        self.state = "terminal"
        self.lease.clear()
        self.known_missing.clear()

    def charge(self, live_owned_compiler=False, stat_path=None):
        stat_path = stat_path or (lambda path: Path(path).stat())
        if self.state == "prepared" and live_owned_compiler:
            self.state = "running"
        total = 0
        seen = set()
        for path in sorted(self.outputs):
            previous = self.prior.get(path, 0)
            try:
                info = stat_path(path)
            except FileNotFoundError as error:
                reconstructing = (
                    self.state in {"preparation", "prepared"}
                    and path in self.known_missing
                )
                replacing = (
                    self.state == "running"
                    and path in self.lease
                    and live_owned_compiler
                )
                if not (reconstructing or replacing):
                    raise NamedArtifactUnknown(
                        "named output absent outside exact owned lease: " + path
                    ) from error
                # Missing is retained as an explicit reconstruction obligation,
                # not a within-output or qualification result. It cannot refund
                # an artifact retained by the prior compile.
                amount = previous
                key = ("missing-retained", path)
                event = {"path": path, "retained_B": previous, "state": self.state}
                if event not in self.events:
                    self.events.append(event)
            except OSError as error:
                raise NamedArtifactUnknown(
                    "named output stat error: " + path
                ) from error
            else:
                amount = max(previous, info.st_blocks * 512)
                # Every observed growth becomes this path's retained charge.
                # A later allowed disappearance or smaller restoration must
                # retain it, not merely the allocation known at construction.
                self.prior[path] = amount
                key = (info.st_dev, info.st_ino)
            if key not in seen:
                seen.add(key)
                total += max(0, amount - self.baseline.get(path, 0))
        return total


def live_command_members(owned, expected_argv, is_alive, argv_reader):
    """Use only exact canonical-owned pid/start/boot records and command bytes."""
    matched = []
    for member in owned:
        if not is_alive(member):
            continue
        try:
            argv = argv_reader(member["pid"])
        except FileNotFoundError:
            continue
        if argv == expected_argv:
            matched.append(member)
    return matched
