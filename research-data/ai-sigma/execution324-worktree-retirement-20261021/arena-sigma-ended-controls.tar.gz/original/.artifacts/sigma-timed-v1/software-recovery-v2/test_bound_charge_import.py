"""Actual constructor/function AST, mocked IO only; no runtime import or subprocess."""

import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import unittest


class BoundImportTests(unittest.TestCase):
    def construct(
        self, binding, *, state=None, empty=False, missing=False, bad_second=False
    ):
        state = (
            state
            if state is not None
            else {
                "original_baseline_SHA256": "baseline",
                "allocation_max_B": {"/target/owned": 24576},
                "charged_positive_union_B": 20000000,
            }
        )
        raw = json.dumps(state).encode()
        second = (
            json.dumps({**state, "original_baseline_SHA256": "wrong"}).encode()
            if isinstance(state, dict)
            else raw
        )
        records = [] if empty else ["/record", *(["/second"] if bad_second else [])]
        bindings = (
            {}
            if binding is None
            else {
                path: binding(second if path == "/second" else raw) for path in records
            }
        )
        admission = {
            "bindings": bindings,
            "retained_observed_charges": records,
            "deliberate_owned_reconstruction": {"paths": []},
            "source_control_review": {"inclusive_forecast_B": 4923392},
        }
        calls = {"reads": 0, "retains": []}

        class FakePath:
            def __init__(self, name):
                self.name = name

            def __str__(self):
                return self.name

            def __truediv__(self, name):
                return FakePath(str(self.name) + "/" + name)

            def read_text(self):
                if self.name.endswith("admission.json"):
                    return json.dumps(admission)
                return '{"named_before_rows":[]}'

            def read_bytes(self):
                if self.name not in records:
                    raise AssertionError("unrelated path access")
                calls["reads"] += 1
                if missing:
                    raise FileNotFoundError("missing bound record")
                return second if self.name == "/second" else raw

        class Base:
            def __init__(self, *_args):
                self.named = set()

        class Ledger:
            def __init__(self, *_args):
                pass

            def retain(self, maxima):
                calls["retains"].append(maxima)

        class Stop(RuntimeError):
            pass

        source = ast.parse(Path(__file__).with_name("worker.py").read_text())
        nodes = [
            x
            for x in source.body
            if isinstance(x, ast.ClassDef)
            and x.name == "Resources"
            or isinstance(x, ast.FunctionDef)
            and x.name == "load_bound_charge_record"
        ]
        scope = {
            "Path": FakePath,
            "ROOT": FakePath("root"),
            "OUT": FakePath("out"),
            "OLD": FakePath("old"),
            "json": json,
            "hashlib": hashlib,
            "G": SimpleNamespace(
                Resources=Base, sha=lambda _path: "baseline", TARGET=FakePath("/target")
            ),
            "P": SimpleNamespace(CycleStopped=Stop),
            "NamedReplacement": Ledger,
        }
        exec(
            compile(
                ast.Module(body=nodes, type_ignores=[]), "actual-bound-import", "exec"
            ),
            scope,
        )
        try:
            obj = scope["Resources"]({}, 0, [])
        except (Stop, OSError, json.JSONDecodeError) as error:
            return calls, str(error), None
        return calls, None, obj

    @staticmethod
    def digest(raw):
        return hashlib.sha256(raw).hexdigest()

    def test_unbound_and_mismatched_record_refuse_before_retain(self):
        calls, error, obj = self.construct(None)
        self.assertIn("not bound", error)
        self.assertEqual(calls, {"reads": 0, "retains": []})
        self.assertIsNone(obj)
        calls, error, obj = self.construct(lambda _raw: "wrong-digest")
        self.assertIn("SHA mismatch", error)
        self.assertEqual(calls, {"reads": 1, "retains": []})
        self.assertIsNone(obj)

    def test_exact_bound_bytes_merge_after_single_verified_read(self):
        calls, error, obj = self.construct(self.digest)
        self.assertIsNone(error)
        self.assertEqual(calls, {"reads": 1, "retains": [{"/target/owned": 24576}]})
        self.assertEqual(obj.held_growth_charge, 20000000)

    def test_empty_list_remains_unchanged_without_read_or_retain(self):
        calls, error, obj = self.construct(None, empty=True)
        self.assertIsNone(error)
        self.assertEqual(calls, {"reads": 0, "retains": []})
        self.assertEqual(obj.held_growth_charge, 18644992)

    def test_missing_wrong_baseline_and_malformed_record_refuse_before_any_retain(self):
        cases = [
            {"missing": True},
            {"state": {"original_baseline_SHA256": "wrong"}},
            {"state": []},
            {
                "state": {
                    "original_baseline_SHA256": "baseline",
                    "allocation_max_B": {"/target/owned": 24576},
                    "charged_positive_union_B": False,
                }
            },
            {
                "state": {
                    "original_baseline_SHA256": "baseline",
                    "allocation_max_B": {"/foreign": 24576},
                    "charged_positive_union_B": 20000000,
                }
            },
            {
                "state": {
                    "original_baseline_SHA256": "baseline",
                    "allocation_max_B": {"/target/../escape": 24576},
                    "charged_positive_union_B": 20000000,
                }
            },
            {
                "state": {
                    "original_baseline_SHA256": "baseline",
                    "allocation_max_B": {"/target/owned": -1},
                    "charged_positive_union_B": 20000000,
                }
            },
            {"bad_second": True},
        ]
        for case in cases:
            with self.subTest(case=case):
                calls, error, obj = self.construct(self.digest, **case)
                self.assertIsNotNone(error)
                self.assertIsNone(obj)
                self.assertEqual(calls["retains"], [])


if __name__ == "__main__":
    unittest.main()
