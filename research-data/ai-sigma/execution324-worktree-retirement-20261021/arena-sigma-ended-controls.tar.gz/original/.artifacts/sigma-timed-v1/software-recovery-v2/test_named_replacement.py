"""Tiny control-only fixtures; no Cargo/process/model invocation."""

import unittest
from types import SimpleNamespace

from named_replacement import (
    NamedArtifactUnknown,
    NamedReplacement,
    live_command_members,
)


class ReplacementTests(unittest.TestCase):
    def ledger(self, missing=()):
        return NamedReplacement(
            {"owned": 4096}, [{"path": "owned", "allocated_B": 8192}], missing
        )

    @staticmethod
    def absent(_path):
        raise FileNotFoundError

    def test_exact_owned_missing_is_charged_during_live_replacement(self):
        ledger = self.ledger()
        ledger.begin(["owned"])
        self.assertEqual(ledger.charge(True, self.absent), 4096)
        self.assertEqual(ledger.events[0]["retained_B"], 8192)

    def test_unrelated_or_no_live_owner_missing_refuses(self):
        ledger = self.ledger()
        ledger.begin(["owned"])
        with self.assertRaises(NamedArtifactUnknown):
            ledger.charge(False, self.absent)
        ledger.outputs.add("foreign")
        with self.assertRaises(NamedArtifactUnknown):
            ledger.charge(True, self.absent)

    def test_terminal_absence_refuses_even_after_known_reconstruction(self):
        ledger = self.ledger(["owned"])
        self.assertEqual(ledger.charge(False, self.absent), 4096)
        ledger.begin(["owned"])
        ledger.finish()
        with self.assertRaises(NamedArtifactUnknown):
            ledger.charge(True, self.absent)

    def test_small_restored_output_cannot_release_previous_charge(self):
        ledger = self.ledger()
        info = SimpleNamespace(st_dev=1, st_ino=2, st_blocks=8)
        self.assertEqual(ledger.charge(False, lambda _path: info), 4096)

    def test_observed_growth_is_retained_through_missing_and_smaller_restore(self):
        ledger = self.ledger()
        ledger.begin(["owned"])
        larger = SimpleNamespace(st_dev=1, st_ino=2, st_blocks=32)
        smaller = SimpleNamespace(st_dev=1, st_ino=3, st_blocks=8)
        self.assertEqual(ledger.charge(True, lambda _path: larger), 12288)
        self.assertEqual(ledger.prior["owned"], 16384)
        self.assertEqual(ledger.charge(True, self.absent), 12288)
        self.assertEqual(ledger.events[-1]["retained_B"], 16384)
        self.assertEqual(ledger.charge(True, lambda _path: smaller), 12288)
        ledger.finish()
        with self.assertRaises(NamedArtifactUnknown):
            ledger.charge(True, self.absent)

    def test_observed_maxima_are_independent_and_survive_next_entry(self):
        ledger = NamedReplacement(
            {"owned": 4096, "other": 4096},
            [
                {"path": "owned", "allocated_B": 8192},
                {"path": "other", "allocated_B": 8192},
            ],
            [],
        )
        ledger.begin(["owned", "other"])

        def both_large(path):
            return SimpleNamespace(
                st_dev=1,
                st_ino=2 if path == "owned" else 3,
                st_blocks=32 if path == "owned" else 48,
            )

        charges = [ledger.charge(True, both_large)]
        self.assertEqual(ledger.prior, {"owned": 16384, "other": 24576})
        self.assertEqual(charges[0], 32768)
        charges.append(ledger.charge(True, self.absent))

        def smaller(path):
            return SimpleNamespace(
                st_dev=1, st_ino=2 if path == "owned" else 3, st_blocks=8
            )

        charges.append(ledger.charge(True, smaller))
        self.assertEqual(charges, [32768, 32768, 32768])
        restored = NamedReplacement(
            {"owned": 4096, "other": 4096},
            [{"path": "owned", "allocated_B": 8192}],
            [],
        )
        restored.retain(dict(ledger.prior))
        self.assertEqual(restored.charge(False, smaller), 32768)
        with self.assertRaises(NamedArtifactUnknown):
            restored.charge(False, self.absent)

    def test_only_exact_live_owned_command_activates_lease(self):
        owned = [
            {"pid": 1, "start_ticks": "old", "boot_id": "boot"},
            {"pid": 2, "start_ticks": "live", "boot_id": "boot"},
        ]
        expected = ["cargo", "build", "--release", "-p", "quoridor-runner"]
        self.assertEqual(
            live_command_members(
                owned,
                expected,
                lambda member: member["pid"] == 2,
                lambda _pid: expected,
            ),
            [owned[1]],
        )
        self.assertEqual(
            live_command_members(
                owned,
                expected,
                lambda _member: True,
                lambda _pid: ["cargo", "build", "-p", "foreign"],
            ),
            [],
        )

    def test_other_stat_errors_always_refuse(self):
        ledger = self.ledger(["owned"])

        def denied(_path):
            raise PermissionError("not disappearance")

        with self.assertRaises(NamedArtifactUnknown):
            ledger.charge(False, denied)


if __name__ == "__main__":
    unittest.main()
