"""Finite NN0 lint recovery; preserve initial artifacts and reuse bound exact cleanup."""

import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

from named_replacement import NamedReplacement, live_command_members
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
WT = ROOT.parents[1]
OLD = ROOT / "software-v1"
SPEC = importlib.util.spec_from_file_location("sigma_initial_guard", OLD / "worker.py")
G = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(G)
G.OUT = OUT
# Invoke the bound payload directly so live argv matches the declared command.
G.CARGO = "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo"
P = G.P


def quiet():
    G.quiet()
    markers = [
        "quoridor_training.train",
        "quoridor_training.sigma_reference",
        "numeric-worker",
        "numeric_worker",
        "observation-entry-v1/worker",
        "trainer.py",
    ]
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            argv = (entry / "cmdline").read_bytes().split(b"\0")
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not argv or not Path(os.fsdecode(argv[0])).name.startswith("python"):
            continue
        # Match executable script/module arguments, not shell -c source text.
        args = [os.fsdecode(x) for x in argv[1:] if x and not x.startswith(b"-")]
        if any(mark in arg for arg in args for mark in markers):
            raise P.CycleStopped("foreign numerical identity: " + entry.name)


def save(name, obj):
    G.save(name, obj)


def load_bound_charge_record(admission, path):
    """Verify the one immutable byte string which is subsequently parsed."""
    if path not in admission["bindings"]:
        raise P.CycleStopped("retained charge record is not bound: " + str(path))
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != admission["bindings"][path]:
        raise P.CycleStopped("retained charge record SHA mismatch: " + str(path))
    return json.loads(raw)


class Resources(G.Resources):
    def __init__(self, baseline, source_growth, initial_named):
        super().__init__(baseline, source_growth)
        self.named.update(initial_named)
        self.growth_peak = 18644992  # Retain the first phase charge, never refund it.
        prepared = json.loads((ROOT / "software-recovery-prewrite-v1.json").read_text())
        admission = json.loads((OUT / "admission.json").read_text())
        self.ledger = NamedReplacement(
            baseline,
            prepared["named_before_rows"],
            admission["deliberate_owned_reconstruction"]["paths"],
        )
        self.held_growth_charge = 18644992
        retained = admission.get("retained_observed_charges", [])
        states = []
        # Validate every retained record before any record mutates this ledger.
        for path in retained:
            state = load_bound_charge_record(admission, path)
            if not isinstance(state, dict) or state.get(
                "original_baseline_SHA256"
            ) != G.sha(OLD / "named-baseline.json"):
                raise P.CycleStopped(
                    "retained charge baseline mismatch or malformed record"
                )
            maxima = state.get("allocation_max_B")
            union = state.get("charged_positive_union_B")
            if not isinstance(maxima, dict) or type(union) is not int or union < 0:
                raise P.CycleStopped("malformed retained charge maxima/union")
            for output, amount in maxima.items():
                if (
                    not isinstance(output, str)
                    or not output.startswith(str(G.TARGET) + "/")
                    or ".." in output.split("/")
                    or "\0" in output
                    or type(amount) is not int
                    or amount < 0
                ):
                    raise P.CycleStopped(
                        "malformed retained output ownership/allocation"
                    )
            states.append(state)
        for state in states:
            self.ledger.retain(state["allocation_max_B"])
            self.held_growth_charge = max(
                self.held_growth_charge, state["charged_positive_union_B"]
            )
        self.source_forecast_B = admission["source_control_review"][
            "inclusive_forecast_B"
        ]
        assert self.source_forecast_B <= 11 * 1024**2
        self.active_command = None
        self.active_compiler_identities = []

    def check(self, owned=()):
        P.CycleResources.check(self, owned)
        self.emitted()
        infos = [P.process_info(os.getpid())]
        infos.extend(P.process_info(m["pid"]) for m in owned)
        ram = sum(x["rss"] for x in infos if x) + 64 * 1024**2
        self.ram_peak = max(self.ram_peak, ram)
        if ram > 2 * 1024**3:
            raise P.CycleStopped("family RAM including controller exceeds2GiB")
        self.ledger.outputs.update(self.named)

        def argv_reader(pid):
            argv = (Path("/proc") / str(pid) / "cmdline").read_bytes().split(b"\0")
            return [os.fsdecode(x) for x in argv if x]

        owned_cargo = (
            live_command_members(owned, self.active_command, P.alive, argv_reader)
            if self.active_command
            else []
        )
        for member in owned_cargo:
            if member not in self.active_compiler_identities:
                self.active_compiler_identities.append(member)
        try:
            growth = self.ledger.charge(bool(owned_cargo))
            self.held_growth_charge = max(growth, self.held_growth_charge)
        finally:
            # Even an error after observing one larger path retains that fact
            # for the next finite admission; never rebase to a smaller stat.
            save(
                "charged-path-maxima.json",
                {
                    "original_baseline_SHA256": G.sha(OLD / "named-baseline.json"),
                    "source_stop_SHA256": G.sha(ROOT / "source-stop-v3-clippy.json"),
                    "allocation_max_B": dict(self.ledger.prior),
                    "charged_positive_union_B": self.held_growth_charge,
                    "continuous_unobserved_peak": "UNKNOWN",
                },
            )
        growth = self.held_growth_charge
        tmp = G.allocated(OLD / "tmp") + G.allocated(OUT / "tmp")
        private = G.allocated(OLD / "private") + G.allocated(OUT / "private")
        self.growth_peak = max(self.growth_peak, growth)
        self.tmp_peak = max(self.tmp_peak, tmp)
        self.private_peak = max(self.private_peak, private)
        if growth > 20 * 1024**2 or tmp > 8 * 1024**2 or private > 15 * 1024**2:
            raise P.CycleStopped(
                "Sigma recovery named-growth/TMP/private component cap"
            )
        if growth + tmp + private > 45 * 1024**2:
            raise P.CycleStopped("Sigma recovery build/private/TMP whole45MiB cap")
        control = G.allocated(ROOT) - tmp - private + self.source_growth
        if control > self.source_forecast_B:
            raise P.CycleStopped("Sigma recovery inclusive source forecast exceeded")


def main():
    os.sched_setaffinity(0, {0, 1})
    os.chdir(WT)
    admission = json.loads((OUT / "admission.json").read_text())
    for path, expected in admission["bindings"].items():
        assert G.sha(path) == expected, path
    packet = json.loads(Path(admission["source_stop"]).read_text())
    for relative, row in packet["stopped_sources"].items():
        path = WT / relative
        assert G.sha(path) == row["SHA256"], relative
        assert path.stat().st_mode & 0o777 == row["mode"]
    for row in packet["unchanged_dependency_bindings"]:
        assert G.sha(WT / row["path"]) == row["SHA256"]
    forecast = json.loads((ROOT / "software-recovery-prewrite-v1.json").read_text())
    reconstructing = set(admission["deliberate_owned_reconstruction"]["paths"])
    assert reconstructing == {
        str(G.TARGET / "release/deps/libquoridor_runner-6aaa82ac9921176f.rlib")
    }
    for row in forecast["named_before_rows"]:
        try:
            assert G.sha(row["path"]) == row["SHA256"], row["path"]
            assert Path(row["path"]).stat().st_blocks * 512 == row["allocated_B"]
        except FileNotFoundError:
            assert row["path"] in reconstructing, "unleased absent output"
    assert (
        admission["deliberate_owned_reconstruction"]["retained_allocated_B"] == 8949760
    )
    assert P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 128 * 1024**2
    quiet()
    for name in ["tmp", "private"]:
        (OUT / name).mkdir(exist_ok=True)
    os.environ.update(
        CARGO_TARGET_DIR=str(G.TARGET),
        CARGO_INCREMENTAL="0",
        CARGO_BUILD_JOBS="2",
        CARGO_NET_OFFLINE="true",
        TMPDIR=str(OUT / "tmp"),
        CUDA_VISIBLE_DEVICES="",
        RUST_TEST_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
        CARGO_TERM_COLOR="never",
    )
    for name in [
        "RUSTFLAGS",
        "CARGO_ENCODED_RUSTFLAGS",
        "QUORIDOR_BENCH_MANIFEST",
        "QUORIDOR_BENCH_FT_MODE",
    ]:
        os.environ.pop(name, None)
    baseline = json.loads((OLD / "named-baseline.json").read_text())
    original = json.loads((OLD / "result.json").read_text())
    resources = Resources(
        {r["path"]: r["allocated_B"] for r in baseline["rows"]},
        packet["source_positive_allocated_growth_B"],
        original["named_paths"],
    )
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "private": {},
        "models_nn_ft_calls": 0,
        "scientific_games": 0,
        "source_stop_SHA256": G.sha(admission["source_stop"]),
        "qualified_native_clock": False,
        "continuous_storage_peak": "UNKNOWN",
    }
    started = time.monotonic()

    def command(name, argv, cargo_json=False):
        quiet()
        log = OUT / (name + ".log")
        is_compiler = argv[0] == G.CARGO
        if is_compiler:
            # Only known OWN runner outputs belonging to this finite command.
            targets = admission["command_output_leases"][name]
            resources.ledger.begin(targets)
            resources.active_command = argv
        try:
            record = P.execute(argv, log, None, resources=resources)
        finally:
            if is_compiler:
                resources.ledger.finish()
                resources.active_command = None
        result["commands"].append({"name": name, **record})
        assert record["log_bytes_seen"] <= P.LOG_MAX_BYTES, "provenance log truncated"
        rows = (
            [
                json.loads(line)
                for line in log.read_text().splitlines()
                if line.startswith("{")
            ]
            if cargo_json
            else []
        )
        resources.emitted()
        resources.check()
        return rows

    def packed(label, image, upper):
        raw = Path(image).read_bytes()
        blob = gzip.compress(raw, mtime=0)
        assert len(blob) <= upper
        assert gzip.decompress(blob) == raw
        path = OUT / "private" / (label + ".gz")
        path.write_bytes(blob)
        result["private"][label] = {
            "path": str(path),
            "gzip_SHA256": G.sha(path),
            "gzip_bytes": len(blob),
            "ELF_SHA256": hashlib.sha256(raw).hexdigest(),
            "ELF_bytes": len(raw),
            "mode": Path(image).stat().st_mode & 0o777,
            "roundtrip": True,
        }
        resources.check()

    failure = None
    with (G.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet()
        resources.check()
        try:
            # Only the changed owned package is refreshed. Unchanged libs retain the
            # initial fresh=false byte/compiler proofs, not a name-based inference.
            lib = WT / "crates/quoridor-runner/src/lib.rs"
            before = G.sha(lib)
            old = lib.stat().st_mtime_ns
            os.utime(lib, ns=(lib.stat().st_atime_ns, time.time_ns()))
            assert G.sha(lib) == before
            save(
                "owned-freshness.json",
                {
                    "path": str(lib),
                    "SHA256": before,
                    "old_mtime_ns": old,
                    "new_mtime_ns": lib.stat().st_mtime_ns,
                },
            )
            # Bound original compiler identity is reused; no successful support replay.
            rows = command(
                "release",
                [
                    G.CARGO,
                    "build",
                    *G.BASE,
                    "--release",
                    "-p",
                    "quoridor-runner",
                    "--bin",
                    "quoridor-runner",
                    "--message-format=json",
                ],
                True,
            )
            own = [
                r
                for r in rows
                if r.get("reason") == "compiler-artifact"
                and r.get("target", {}).get("src_path", "").startswith(str(WT) + "/")
            ]
            for name in ["quoridor_runner", "quoridor-runner"]:
                assert any(
                    r["target"]["name"] == name and not r["fresh"] for r in own
                ), name
            save(
                "release-own-payloads.json",
                [
                    {
                        "target": r["target"],
                        "profile": r["profile"],
                        "fresh": r["fresh"],
                        "payloads": [
                            {
                                "path": p,
                                "SHA256": G.sha(p),
                                "allocated_B": Path(p).stat().st_blocks * 512,
                            }
                            for p in r["filenames"]
                        ],
                    }
                    for r in own
                ],
            )
            runner = next(
                r["executable"] for r in own if r["target"]["name"] == "quoridor-runner"
            )
            packed("quoridor-runner", runner, 3 * 1024**2)
            rows = command(
                "caller-build",
                [
                    G.CARGO,
                    "test",
                    *G.BASE,
                    "--release",
                    "-p",
                    "quoridor-runner",
                    "--lib",
                    "--no-run",
                    "--message-format=json",
                ],
                True,
            )
            images = [
                r
                for r in rows
                if r.get("reason") == "compiler-artifact"
                and r.get("executable")
                and r.get("profile", {}).get("test")
            ]
            assert len(images) == 1 and not images[0]["fresh"]
            packed("caller", images[0]["executable"], 2 * 1024**2)
            # Decode only this one immutable test image; remove only our new
            # decode after exactwait, leaving every initial image intact.
            image = OUT / "tmp" / "caller"
            image.write_bytes(
                gzip.decompress((OUT / "private" / "caller.gz").read_bytes())
            )
            image.chmod(result["private"]["caller"]["mode"])
            assert G.sha(image) == result["private"]["caller"]["ELF_SHA256"]
            try:
                command(
                    "closedreceiver-fixture",
                    [
                        str(image),
                        "runtime::sigma_reply_tests::queued_cancel_and_abandoned_request_each_have_one_terminal_reply",
                        "--exact",
                        "--nocapture",
                        "--test-threads=1",
                    ],
                )
            finally:
                image.unlink()  # New owned decoder only, not retained artifact.
            command(
                "clippy",
                [
                    G.CARGO,
                    "clippy",
                    *G.BASE,
                    "-p",
                    "quoridor-runner",
                    "--lib",
                    "--bin",
                    "quoridor-runner",
                    "--test",
                    "arena",
                    "--test",
                    "sigma_clock",
                    "--message-format=json",
                    "--",
                    "-Dwarnings",
                ],
                True,
            )
        except BaseException as error:
            failure = str(error)
        finally:
            result.update(
                stopped=datetime.now(timezone.utc).isoformat(),
                whole_seconds=time.monotonic() - started,
                failure=failure,
                charged_allocation_maxima_B=dict(resources.ledger.prior),
                charged_positive_union_B=resources.held_growth_charge,
                named_paths=sorted(resources.named),
                exact_owned_compiler_identities=resources.active_compiler_identities,
                replacement_absence_retained_events=resources.ledger.events,
                sampled_peaks={
                    "family_RAM_B": resources.ram_peak,
                    "positive_artifact_growth_B": resources.growth_peak,
                    "TMP_B": resources.tmp_peak,
                    "private_B": resources.private_peak,
                },
            )
            save("result.json", result)
    if failure:
        raise SystemExit(failure)


if __name__ == "__main__":
    main()
