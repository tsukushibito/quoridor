"""Only after ordered formatter/parser/provenance/quiet checks, submit once."""

import json
from pathlib import Path
import subprocess

from launch_control import checked_command, verified_submit
import preflight


OUT = Path(__file__).resolve().parent
QUALITY = Path("/workspaces/quoridor/tools/research-quality")
CANONICAL = "/workspaces/quoridor/scripts/dev/research-job.sh"


def parse_job():
    job = json.loads((OUT / "job.json").read_text())
    assert job["issue"] == "quoridor-4lc.331"
    assert job["thread_id"] == "01a11062-b120-73a1-8aa3-fe2cb922c7c0"
    assert job["cwd"] == str(preflight.W.WT)
    assert job["argv"] == ["/usr/bin/python3", "-B", str(OUT / "worker.py")]
    assert job["resource_contract"] == str(OUT / "admission.json")
    assert not (OUT / "job-runtime-v1").exists(), "runtime already exists; no resubmit"
    return True


def main():
    python_files = [
        str(OUT / name)
        for name in [
            "worker.py",
            "named_replacement.py",
            "test_named_replacement.py",
            "launch_control.py",
            "test_launch_control.py",
            "preflight.py",
            "launch.py",
        ]
    ]
    checks = [
        (
            "Python format",
            lambda: checked_command(
                [str(QUALITY / ".venv/bin/ruff"), "format", "--check", *python_files]
            ),
        ),
        (
            "Python lint",
            lambda: checked_command(
                [str(QUALITY / ".venv/bin/ruff"), "check", *python_files]
            ),
        ),
        (
            "JSON format",
            lambda: checked_command(
                [
                    "node",
                    str(QUALITY / "node_modules/prettier/bin/prettier.cjs"),
                    "--config",
                    str(QUALITY / ".prettierrc.json"),
                    "--parser",
                    "json",
                    "--ignore-path",
                    "/dev/null",
                    "--check",
                    str(OUT / "admission.json"),
                    str(OUT / "job.json"),
                ]
            ),
        ),
        (
            "Rust source format",
            lambda: checked_command(
                [
                    "/usr/local/cargo/bin/rustfmt",
                    "--edition",
                    "2024",
                    "--check",
                    str(preflight.W.WT / "crates/quoridor-runner/src/runtime.rs"),
                ]
            ),
        ),
        ("immutable job arguments/parser", parse_job),
        ("source/resource/private/physical/quiet", preflight.verify),
    ]

    def submit():
        return subprocess.run(
            [
                "bash",
                CANONICAL,
                "submit",
                "--config",
                str(OUT / "job.json"),
                "--state-dir",
                str(OUT / "job-runtime-v1"),
            ],
            check=True,
            text=True,
            capture_output=True,
            timeout=60,
        )

    result = verified_submit(checks, submit)
    (OUT / "submission.json").write_text(
        json.dumps(
            {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
            },
            indent=2,
        )
        + "\n"
    )
    print(result.stdout)


if __name__ == "__main__":
    main()
