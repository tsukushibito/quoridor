"""Focused scientific census guards; no model/process/runtime imports."""

import ast
import copy
import json
from pathlib import Path
import time


def main():
    start = time.monotonic()
    source = ast.parse((Path(__file__).parent / "qualify.py").read_text())
    node = next(
        x
        for x in source.body
        if isinstance(x, ast.FunctionDef) and x.name == "collect_scientific"
    )
    digest = "source-fixed"
    admission = {
        "runner_ELF_SHA256": "elf",
        "critical_compiled_sources": {"core/research.rs": digest},
    }
    fixture = {
        "planned": 14,
        "all_workers_joined": True,
        "stopped": "inference:original",
        "outcomes": [
            {"game": i, "status": "unknown", "winner": None, "failure": "engine_error"}
            for i in range(14)
        ],
    }
    manifest = {
        "binding": {
            "executable_sha256": "elf",
            "rules": "research-standard-2p-threefold-goal-first-v1",
            "compiled_sources": {"core/research.rs": digest},
        }
    }

    class Port:
        def __init__(self, name=""):
            self.name = name

        def __truediv__(self, name):
            return Port(name)

        def read_bytes(self):
            return json.dumps(
                manifest if self.name == "manifest.json" else fixture
            ).encode()

    class Proof:
        @staticmethod
        def sha(path):
            return "fake-owned-SHA"

    ns = {"OUT": Port(), "json": json, "S": Proof}
    exec(
        compile(
            ast.Module(body=[node], type_ignores=[]),
            "actual-scientific-collector",
            "exec",
        ),
        ns,
    )
    result = ns["collect_scientific"]("main", admission)
    assert result["report"]["stopped"] == "inference:original"
    assert all(
        o["status"] == "unknown" and o["failure"] == "engine_error"
        for o in result["report"]["outcomes"]
    )
    baseline = copy.deepcopy(fixture)
    for field, value in [
        ("planned", 13),
        ("all_workers_joined", False),
        ("outcomes", baseline["outcomes"][:-1]),
        ("outcomes", [baseline["outcomes"][0], *baseline["outcomes"][0:13]]),
    ]:
        fixture = copy.deepcopy(baseline)
        fixture[field] = value
        try:
            ns["collect_scientific"]("main", admission)
        except ValueError:
            pass
        else:
            raise AssertionError("census refusal missing")
    # The finalizer is unchanged except this phase's exact success receipt set.
    h = ast.parse((Path(__file__).parent / "reviewed_helpers.py").read_text())
    final = next(
        x for x in h.body if isinstance(x, ast.FunctionDef) and x.name == "finalize"
    )
    expected = next(
        x.value
        for x in ast.walk(final)
        if isinstance(x, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "expected" for t in x.targets)
    )
    assert ast.literal_eval(expected) == {
        op + "-" + phase + ".process.json"
        for phase in ["initial", "main"]
        for op in ["arena", "audit", "recover"]
    }
    print(
        json.dumps(
            {
                "focused_cases": 6,
                "status": "PASS",
                "whole_seconds": time.monotonic() - start,
                "runtime_model_process_calls": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
