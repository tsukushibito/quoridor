"""Verify retained sixteen-slot evidence without invoking an engine."""

import collections
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import struct

OUT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    admission = load(OUT / "admission.json")
    worker = load(OUT / "result.json")
    controller = load(OUT / "job-runtime-v1/result.json")
    state = load(OUT / "job-runtime-v1/state.json")
    assert controller["exit_code"] == 0 and controller["direct_child_reaped"]
    assert controller["cleanup_complete"] and controller["remaining"] == []
    assert worker["qualified"] and worker["primary_error"] is None
    assert worker["finalization_errors"] == worker["financial_errors"] == []
    assert worker["charge_io_errors"] == worker["remaining"] == []
    assert not (OUT / "tmp").exists()
    packet = load(OUT / "source-control-STOP-v1.json")
    for name, binding in packet["bindings"].items():
        path = Path(name)
        info = path.stat()
        assert digest(path) == binding["SHA256"]
        assert info.st_size == binding["bytes"]
        assert info.st_mode & 0o777 == binding["mode"]
    records, identities = [], []
    for attempt, returned in zip(worker["attempted_children"], worker["commands"]):
        path = Path(attempt["receipt"])
        receipt = load(path)
        assert receipt["command"] == attempt["argv"] == returned["command"]
        assert receipt["exit_code"] == 0 and receipt["direct_child_reaped"]
        assert receipt["cleanup_complete"] and receipt["handle_closes_complete"]
        assert receipt["remaining"] == []
        identities.append(receipt["child"])
        records.append(
            {
                "name": attempt["name"],
                "SHA256": digest(path),
                "child": receipt["child"],
                "directwait_exit0_cleanup": True,
                "persisted_mask": receipt["signal_mask_restoration"],
                "persisted_final_record": receipt["final_record_persist"],
                "returned_mask": returned["signal_mask_restoration"],
                "returned_final_record": returned["final_record_persist"],
            }
        )
    assert [r["name"] for r in records] == [
        op + "-" + phase
        for phase in ["initial", "main"]
        for op in ["arena", "audit", "recover"]
    ]
    identities.append(state["child"])
    for identity in identities:
        path = Path("/proc") / str(identity["pid"]) / "stat"
        try:
            same = (
                path.read_text().rpartition(") ")[2].split()[19]
                == identity["start_ticks"]
            )
        except FileNotFoundError:
            same = False
        assert not same
    counts, calls = collections.Counter(), collections.Counter()
    rejected, slots, pairs, cohorts = [], [], [], []
    artifact_bindings = {}
    for phase, planned_count in [("initial", 2), ("main", 14)]:
        target = OUT / ("run-" + phase)
        report = load(target / "result.json")
        manifest = load(target / "manifest.json")
        planned = load(target / "planned.json")
        journal = [
            json.loads(row)
            for row in (target / "completed.jsonl").read_text().splitlines()
        ]
        games = list(csv.DictReader(io.StringIO((target / "games.csv").read_text())))
        assert (
            len(journal)
            == len(games)
            == len(planned)
            == len(report["outcomes"])
            == report["planned"]
            == planned_count
        )
        assert report["all_workers_joined"] and report["stopped"] is None
        assert (
            load(OUT / ("audit-" + phase + ".log"))
            == report["arena_summary"]
            == manifest["summary"]
        )
        assert manifest["binding"]["planned_slots"] == planned
        assert (
            manifest["binding"]["executable_sha256"] == admission["runner_ELF_SHA256"]
        )
        assert (
            manifest["binding"]["rules"]
            == "research-standard-2p-threefold-goal-first-v1"
        )
        assert manifest["cleanup"]["gzip_child_reaped"]
        assert manifest["binding"]["admission"]["serial_shared_inference"]
        assert manifest["binding"]["admission"]["worker_cores"] == [0]
        assert manifest["binding"]["admission"]["inference_core"] == 0
        for key, expected in admission["critical_compiled_sources"].items():
            assert manifest["binding"]["compiled_sources"][key] == expected
        for name, binding in manifest["artifacts"].items():
            path = target / name
            assert (
                path.stat().st_size == binding["bytes"]
                and digest(path) == binding["sha256"]
            )
            artifact_bindings[str(path)] = binding
        backend = report["pump"]["backend_work"]
        assert backend["warm_rows"] == backend["failed_rows"] == 0
        expected_moves = []
        for outcome, durable, plan, csvrow in zip(
            report["outcomes"], journal, planned, games
        ):
            assert outcome == durable and outcome["started"]
            assert outcome["game"] == plan["game"] == int(csvrow["game"])
            assert outcome["status"] == csvrow["status"]
            assert outcome["candidate_color"] == plan["candidate_color"]
            assert outcome["moves"][: len(plan["opening"])] == plan["opening"]
            assert outcome["plies"] == len(outcome["moves"])
            assert (
                sum(count for key, count in plan["replay"]["history"])
                == len(plan["opening"]) + 1
            )
            accepted = []
            for observation in outcome["observations"]:
                expected_moves.append(
                    {"game": outcome["game"], "observation": observation}
                )
                assert observation["engine_error"] is None
                assert observation["engine_index"] == (
                    0 if observation["side"] == outcome["candidate_color"] else 1
                )
                calls["attempted"] += 1
                calls["accepted"] += observation["accepted"]
                counters = observation["counters"]
                for key in [
                    "nodes",
                    "nn_requests_attempted",
                    "completed_simulations",
                    "discarded_late_replies",
                ]:
                    calls[key] += counters.get(key, 0)
                if observation["engine_index"] == 0:
                    assert counters["nodes"] <= 1000000
                if observation["accepted"]:
                    assert observation["failure"] is None
                    assert observation["accepted_ns"] < observation["deadline_ns"]
                    accepted.append(observation["action"])
                else:
                    assert observation["failure"] == "time_overrun"
                    assert observation["accepted_ns"] is None
                    assert observation["returned_ns"] >= observation["deadline_ns"]
                    assert observation["engine_index"] == 1
                    rejected.append(
                        {
                            "phase": phase,
                            "game": outcome["game"],
                            "ply": observation["ply"],
                            "engine": "Sigma",
                            "caller_seconds": observation["caller_seconds"],
                            "excess_ns": observation["admission_checked_ns"]
                            - observation["deadline_ns"],
                            "rejected_action": observation["action"],
                        }
                    )
            assert accepted == outcome["moves"][len(plan["opening"]) :]
            tt = outcome["persistent_tt"][0]
            assert (
                tt["effective_tt_slots"] == 4096
                and tt["persistent_tt_byte_cap"] == 1048576
            )
            if outcome["status"] == "goal":
                counts[
                    "NNUE_W"
                    if outcome["winner"] == outcome["candidate_color"]
                    else "NNUE_L"
                ] += 1
            elif outcome["status"] == "draw":
                counts["draw"] += 1
            else:
                assert (
                    outcome["status"] == "unknown"
                    and outcome["winner"] is None
                    and outcome["failure"] == "time_overrun"
                )
                counts["unknown"] += 1
            slots.append(
                {
                    "phase": phase,
                    **{
                        key: outcome[key]
                        for key in [
                            "game",
                            "family",
                            "candidate_color",
                            "status",
                            "winner",
                            "plies",
                            "reason",
                            "failure",
                        ]
                    },
                }
            )
        with gzip.open(target / "moves.jsonl.gz", "rt") as stream:
            moves = [json.loads(row) for row in stream]
        assert len(moves) == len(expected_moves)
        for actual, expected in zip(moves, expected_moves):
            assert actual["game"] == expected["game"]
            left, right = dict(actual["observation"]), dict(expected["observation"])
            # Journal Value and direct f32 serde spelling differ; original f32 bits must agree.
            assert struct.pack("!f", left.pop("value_stm")) == struct.pack(
                "!f", right.pop("value_stm")
            )
            assert left == right
        for index in range(0, planned_count, 2):
            left, right = report["outcomes"][index : index + 2]
            assert left["family"] == right["family"] and [
                left["candidate_color"],
                right["candidate_color"],
            ] == [0, 1]
            pairs.append(
                {
                    "phase": phase,
                    "family": left["family"],
                    "complete": left["status"] != "unknown"
                    and right["status"] != "unknown",
                }
            )
        cohorts.append(
            {
                "phase": phase,
                "summary": report["arena_summary"],
                "backend_work": backend,
            }
        )
    assert counts == {"NNUE_L": 14, "unknown": 2}
    assert calls["attempted"] == 660 and calls["accepted"] == 658
    assert calls["nodes"] == 16246244 and calls["nn_requests_attempted"] == 7746
    assert len(pairs) == 8 and sum(pair["complete"] for pair in pairs) == 6
    summary = {
        "issue": "quoridor-4lc.331",
        "planned": 16,
        "started": 16,
        "decided": 14,
        "NNUE_W": 0,
        "NNUE_L": 14,
        "Sigma_W": 14,
        "Sigma_L": 0,
        "draw": 0,
        "unknown": 2,
        "complete_pairs": 6,
        "incomplete_pairs": 2,
        "NNUE_planned_score_bounds": [0, 0.125],
        "Sigma_planned_score_bounds": [0.875, 1],
        "call_counters": dict(calls),
        "rejected_clock_windows": rejected,
        "slots": slots,
        "pairs": pairs,
        "cohorts": cohorts,
        "artifact_bindings": artifact_bindings,
        "main_commit": "ad358f6",
        "private_ELF_SHA256": admission["runner_ELF_SHA256"],
        "limits": "Eight opened correlated common-initial/PRNG families. No Elo/global rank or calibrated independent precision; old RuleA and four functional windows separate. Two UNKNOWNs are not losses/draws/rescued/rerun.",
        "known_all_controller_fees_seconds": 667.7499553130475
        + controller["wall_seconds"],
    }
    stop = {
        "issue": "quoridor-4lc.331",
        "job_id": controller["job_id"],
        "actual_START": state["started_at"],
        "worker_STOP": worker["actual_STOP"],
        "controller_STOP": controller["finished_at"],
        "controller_wall_seconds": controller["wall_seconds"],
        "all6_directwait_cleanup": records,
        "science7_exact_identities_absent": identities,
        "metadata_supervisor": state["supervisor"],
        "metadata_notifier_not_science": True,
        "TMP_absent": True,
        "remaining": [],
        "source13_before_after_match": True,
        "source_packet_SHA256": digest(OUT / "source-control-STOP-v1.json"),
        "persisted_mask_fault_qualification": "UNKNOWN; pending/attempted disk facts distinct from returned completed",
        "sample_family_RSS_B": worker["RAM_family_sampled_B"],
        "sample_output_B": worker["qualification_allocated_peak_B"],
        "sample_TMP_B": worker["TMP_allocated_peak_B"],
        "continuous_peak": "UNKNOWN",
        "whole_forecast_B": 4258922496,
        "supported_B": 4294967296,
        "legacy_positive_floor_B": 35225600,
        "missing6aaa_UNKNOWN_max_B": 9236480,
        "current_next_Cargo_model_clock_reservation": "NONE",
        "recovery": "Four NN0 audit/recover exact CLI directwait0. Bounded recover stdout tails65536 retained; full output not retained; all source-bound inputs/journal/results preserved.",
        "admin_collection_failures": [
            "JSONDecodeError treating bounded recover tail as whole JSON",
            "AssertionError requiring persisted mask completed although pending is retained",
            "AssertionError comparing JSON float spelling instead of original f32 value bits",
        ],
        "prewrite_report_upper_B": 262144,
        "inside_source32MiB": True,
        "collection_STOP": datetime.now(timezone.utc).isoformat(),
    }
    for name, value in [
        ("verified-outcome-summary-v1.json", summary),
        ("actual-scientific-STOP-receipt-v1.json", stop),
    ]:
        path = OUT / name
        assert not path.exists()
        path.write_text(json.dumps(value, indent=2) + "\n")
    print(
        json.dumps(
            {
                "verified": True,
                "counts": dict(counts),
                "pairs": [6, 2],
                "calls": dict(calls),
                "STOP": controller["finished_at"],
                "fee": summary["known_all_controller_fees_seconds"],
            }
        )
    )


if __name__ == "__main__":
    main()
