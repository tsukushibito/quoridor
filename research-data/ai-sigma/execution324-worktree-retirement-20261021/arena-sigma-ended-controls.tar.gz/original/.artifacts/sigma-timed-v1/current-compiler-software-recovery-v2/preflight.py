"""Read-only actual admission/quiet gate; never submits or starts a child."""

import hashlib
import json
from pathlib import Path
import sys

import worker

raw = (Path(__file__).resolve().parent / "admission.json").read_bytes()
if len(sys.argv) != 2 or hashlib.sha256(raw).hexdigest() != sys.argv[1]:
    raise ValueError("actual immutable admission digest absent/mismatched")
if worker.validate(json.loads(raw)) is not True:
    raise ValueError("preflight did not return exactly True")
print("preflight exactTrue; no submit/Popen")
