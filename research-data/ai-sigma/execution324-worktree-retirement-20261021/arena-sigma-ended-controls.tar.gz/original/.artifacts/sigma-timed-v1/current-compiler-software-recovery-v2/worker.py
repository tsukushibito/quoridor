"""Remaining NN0 software in one exclusively owned current-compiler target."""

from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

sys.path.insert(0, "/workspaces/quoridor/python")
from quoridor_training import cycle_process as P  # noqa: E402
from quoridor_training.snapshot import write_json  # noqa: E402

OUT = Path(__file__).resolve().parent
WT = OUT.parents[2]
MIB = 1024**2
P.LOG_MAX_BYTES = 8 * MIB


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while block := stream.read(MIB):
            digest.update(block)
    return digest.hexdigest()


def save(name, value):
    write_json(OUT / name, value)


def verify(bindings):
    for path, row in bindings.items():
        p = Path(path)
        info = p.lstat()
        if (
            not stat.S_ISREG(info.st_mode)
            or stat.S_IMODE(info.st_mode) != row["mode"]
            or info.st_size != row["bytes"]
            or sha(p) != row["SHA256"]
        ):
            raise ValueError("immutable input changed: " + path)


def allocation(root):
    """Only this job's new namespace; disappearance never lowers held maxima."""
    pending, total = [Path(root)], 0
    while pending:
        p = pending.pop()
        try:
            info = p.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode):
            raise ValueError("symlink in exclusive output: " + str(p))
        total += info.st_blocks * 512
        if stat.S_ISDIR(info.st_mode):
            pending.extend(p.iterdir())
        elif not stat.S_ISREG(info.st_mode):
            raise ValueError("unsupported owned output kind: " + str(p))
    return total


def quiet():
    forbidden = {
        "cargo",
        "rustc",
        "clippy-driver",
        "cargo-clippy",
        "perf",
        "quoridor-runner",
    }
    markers = (
        "numeric-worker",
        "numeric_worker",
        "qualify.py",
        "train.py",
        "trainer.py",
        "matches-worker",
    )
    for path in Path("/proc").iterdir():
        if not path.name.isdecimal() or int(path.name) == os.getpid():
            continue
        try:
            args = [
                os.fsdecode(a)
                for a in (path / "cmdline").read_bytes().split(b"\0")
                if a
            ]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not args:
            continue
        base = Path(args[0]).name
        if base in forbidden or (
            base.startswith("python")
            and any(
                Path(a).name.startswith(markers)
                for a in args[1:]
                if not a.startswith("-")
            )
        ):
            raise P.CycleStopped("foreign compiler/science present: " + path.name)


def validate(admission):
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared metadata is not entry")
    if admission["pending_entry_obligations"]:
        raise ValueError("entry obligations remain")
    verify(admission["bindings"])
    if Path(admission["target"]).exists() or Path(admission["temporary"]).exists():
        raise ValueError("new exclusive target/TMP already exists")
    if not {0, 1}.issubset(os.sched_getaffinity(0)):
        raise ValueError("actual CPUs unavailable")
    if P.available_memory() < 8 * 1024**3:
        raise P.CycleStopped("fresh memory below family6GiB + host2GiB reserve")
    fs = os.statvfs(OUT)
    if fs.f_bavail * fs.f_frsize < admission["supported_whole_phase_B"]:
        raise P.CycleStopped("fresh free disk below inclusive phase support")
    quiet()
    return True


class Resources(P.CycleResources):
    def __init__(self, admission):
        super().__init__(
            {
                "max_memory_bytes": 6 * 1024**3 - 512 * MIB,
                "host_ram_reserve": 2 * 1024**3,
                "max_output_bytes": admission["supported_whole_phase_B"],
            },
            OUT,
            None,
        )
        self.admission = admission
        self.attempts = []
        self.peaks = {
            "target": 0,
            "temporary": 0,
            "private": 0,
            "whole": 0,
            "family_RSS": 0,
        }

    def check(self, owned=()):
        super().check(owned)
        for name, cap in self.admission["software_component_caps_B"].items():
            value = (
                allocation(self.admission[name]) if name != "whole" else allocation(OUT)
            )
            self.peaks[name] = max(self.peaks[name], value)
            if self.peaks[name] > cap:
                raise P.CycleStopped("held owned allocation exceeds " + name)
        family = (
            sum(
                info["rss"]
                for pid in [os.getpid(), *(m["pid"] for m in owned)]
                if (info := P.process_info(pid))
            )
            + 512 * MIB
        )
        self.peaks["family_RSS"] = max(self.peaks["family_RSS"], family)
        if family > 6 * 1024**3:
            raise P.CycleStopped("whole family6GiB including controller reserve")


def execute(name, argv, resources):
    log = OUT / (name + ".log")
    attempt = {
        "name": name,
        "argv": argv,
        "receipt": str(log.with_suffix(".process.json")),
    }
    if any(a["receipt"] == attempt["receipt"] for a in resources.attempts):
        raise ValueError("duplicate attempt")
    resources.attempts.append(attempt)
    record = P.execute(argv, log, None, resources=resources)
    if (
        record.get("exit_code") != 0
        or record.get("direct_child_reaped") is not True
        or record.get("cleanup_complete") is not True
        or record.get("remaining")
    ):
        raise ValueError("command/directwait failed: " + name)
    if record["log_bytes_seen"] > record["log_bytes_retained"]:
        raise ValueError("compiler metadata/test log truncated")
    return log, record


def artifacts(log, target):
    found = []
    for line in log.read_text().splitlines():
        if not line.startswith("{"):
            continue
        event = json.loads(line)
        if event.get("reason") != "compiler-artifact":
            continue
        paths = event.get("filenames", []) + (
            [event["executable"]] if event.get("executable") else []
        )
        rows = []
        for filename in sorted(set(paths)):
            p = Path(filename)
            if not p.is_relative_to(target) or p.is_symlink():
                raise ValueError("compiler emitted outside owned output lease")
            info = p.stat()
            rows.append(
                {
                    "path": filename,
                    "SHA256": sha(p),
                    "bytes": info.st_size,
                    "mode": stat.S_IMODE(info.st_mode),
                    "allocated_B": info.st_blocks * 512,
                }
            )
        found.append({**event, "payloads": rows})
    if not found:
        raise ValueError("no actual compiler artifact events")
    return found


def terminal(result, primary, resources):
    """Independent accounting/census/result attempts; no empty-list cleanup claim."""
    failures, receipts, remaining = [], [], []

    def attempt(stage, call):
        try:
            return call()
        except BaseException as error:
            failures.append(
                {"stage": stage, "type": type(error).__name__, "message": str(error)}
            )
            return None

    unknown = False
    paths = attempt("receipt_paths", lambda: list(OUT.glob("*.process.json")))
    if paths is None or {str(p) for p in paths} != {
        a["receipt"] for a in resources.attempts
    }:
        unknown = True
    for a in resources.attempts:
        r = attempt(
            "receipt:" + a["name"],
            lambda a=a: json.loads(Path(a["receipt"]).read_bytes()),
        )
        if (
            not isinstance(r, dict)
            or r.get("command") != a["argv"]
            or r.get("direct_child_reaped") is not True
            or r.get("cleanup_complete") is not True
            or r.get("remaining") != []
        ):
            unknown = True
        if isinstance(r, dict):
            receipts.append(r)
            remaining.extend(r.get("remaining", []))
    temporary = Path(resources.admission["temporary"])
    if not unknown and temporary.exists():
        attempt("owned_empty_TMP_rmdir", temporary.rmdir)
    tmp_rows = attempt(
        "owned_TMP_census",
        lambda: [str(p) for p in temporary.iterdir()] if temporary.exists() else [],
    )
    if tmp_rows is None:
        unknown = True
    elif tmp_rows:
        remaining.extend({"owned_TMP": p} for p in tmp_rows)
    attempt("source_final", lambda: verify(resources.admission["source_bindings"]))
    attempt("allocation_final", resources.check)
    attempt(
        "charges_write",
        lambda: save(
            "observed-owned-charges.json",
            {
                "held_maxima_B": resources.peaks,
                "baseline": "NEW exclusive namespace, zero pre-existing output",
                "legacy": "separately held unchanged;6aaa UNKNOWN not consumed",
            },
        ),
    )
    if unknown:
        remaining.append({"scope": "attempted children/receipts", "status": "UNKNOWN"})
    result.update(
        actual_STOP=datetime.now(timezone.utc).isoformat(),
        primary_error=primary,
        finalization_errors=failures,
        attempts=resources.attempts,
        process_receipts=receipts,
        all_direct_children_reaped=not unknown,
        cleanup_complete=not unknown and not remaining,
        remaining=remaining,
        held_allocation_maxima_B=resources.peaks,
    )
    if primary is not None or failures or unknown:
        result["software_complete"] = False
    saved = attempt("result_write", lambda: (save("result.json", result), True)[1])
    if saved is not True:
        result["software_complete"] = False
        result["result_persistence"] = "UNKNOWN"
    print(json.dumps(result, allow_nan=False), flush=True)
    return result["software_complete"]


def main():
    started = time.monotonic()
    raw = (OUT / "admission.json").read_bytes()
    if len(sys.argv) != 2 or hashlib.sha256(raw).hexdigest() != sys.argv[1]:
        raise ValueError("actual job does not bind these admission bytes")
    admission = json.loads(raw)
    validate(admission)
    resources = Resources(admission)
    result = {
        "actual_START": datetime.now(timezone.utc).isoformat(),
        "software_complete": False,
        "model_calls": 0,
        "scientific_games": 0,
        "commands": [],
    }
    primary = None
    target = Path(admission["target"])
    try:
        with Path(admission["cargo_lock"]).open("a") as lock, P.cancellation_signals():
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            quiet()
            verify(admission["bindings"])
            target.mkdir()
            Path(admission["temporary"]).mkdir()
            Path(admission["private"]).mkdir()
            os.sched_setaffinity(0, {0, 1})
            os.chdir(WT)
            os.environ.update(
                CARGO_TARGET_DIR=str(target),
                CARGO_BUILD_JOBS="2",
                CARGO_INCREMENTAL="0",
                CARGO_NET_OFFLINE="true",
                CARGO_TERM_COLOR="never",
                RUST_TEST_THREADS="1",
                TMPDIR=admission["temporary"],
                CUDA_VISIBLE_DEVICES="",
                RUSTC=admission["rustc"],
                RUSTDOC=admission["rustdoc"],
                PATH=str(Path(admission["rustc"]).parent)
                + os.pathsep
                + os.environ["PATH"],
            )
            for name in [
                "RUSTFLAGS",
                "CARGO_ENCODED_RUSTFLAGS",
                "QUORIDOR_BENCH_MANIFEST",
                "QUORIDOR_BENCH_FT_MODE",
                "RUSTC_WRAPPER",
                "RUSTC_WORKSPACE_WRAPPER",
            ]:
                os.environ.pop(name, None)
            for name in list(os.environ):
                if (
                    name.startswith(("CARGO_PROFILE_", "CARGO_TARGET_"))
                    and name != "CARGO_TARGET_DIR"
                ):
                    os.environ.pop(name)
            for name in ["RUSTC_BOOTSTRAP", "CARGO_BUILD_TARGET", "CXXFLAGS", "CFLAGS"]:
                os.environ.pop(name, None)
            harness = None
            production = None
            for step in admission["plan"]:
                verify(admission["source_bindings"])
                argv = (
                    step["argv"]
                    if step["name"] != "arena-one"
                    else [
                        harness,
                        "--exact",
                        "research_threefold_replay_enters_legal_third_and_refuses_postterminal",
                        "--test-threads=1",
                        "--nocapture",
                    ]
                )
                log, record = execute(step["name"], argv, resources)
                if step["name"] == "arena-one":
                    if "1 passed; 0 failed;" not in log.read_text():
                        raise ValueError(
                            "one required terminal replay test did not pass"
                        )
                else:
                    emitted = artifacts(log, target)
                    save(step["name"] + "-artifacts.json", emitted)
                    for e in emitted:
                        if e["target"]["name"] == "arena" and e.get("executable"):
                            harness = e["executable"]
                        if (
                            e["target"]["name"] == "quoridor-runner"
                            and "bin" in e["target"]["kind"]
                            and e["profile"]["opt_level"] == "3"
                            and not e["profile"]["test"]
                        ):
                            production = e.get("executable")
                result["commands"].append({"name": step["name"], "receipt": record})
            if production is None:
                log, record = execute(
                    "necessary-production-cli",
                    admission["conditional_production_argv"],
                    resources,
                )
                emitted = artifacts(log, target)
                save("necessary-production-cli-artifacts.json", emitted)
                choices = [
                    e["executable"]
                    for e in emitted
                    if e["target"]["name"] == "quoridor-runner"
                    and "bin" in e["target"]["kind"]
                    and e["profile"]["opt_level"] == "3"
                    and not e["profile"]["test"]
                    and e.get("executable")
                ]
                if len(choices) != 1:
                    raise ValueError(
                        "actual current-compiler production body absent/ambiguous"
                    )
                production = choices[0]
                result["commands"].append(
                    {"name": "necessary-production-cli", "receipt": record}
                )
            packed = Path(admission["private"]) / "quoridor-runner.gz"
            with (
                Path(production).open("rb") as source,
                gzip.open(packed, "wb", compresslevel=6) as output,
            ):
                while block := source.read(MIB):
                    output.write(block)
            with gzip.open(packed, "rb") as source:
                digest = hashlib.sha256()
                while block := source.read(MIB):
                    digest.update(block)
            if digest.hexdigest() != sha(production):
                raise ValueError("private packed payload roundtrip mismatch")
            result["private"] = {
                "path": str(packed),
                "gzip_SHA256": sha(packed),
                "ELF_SHA256": sha(production),
                "ELF_bytes": Path(production).stat().st_size,
                "compiled_source_bindings": admission["source_bindings"],
                "compiler_bindings": admission["compiler_bindings"],
            }
            resources.check()
            result["software_complete"] = True
    except BaseException as error:
        primary = {"type": type(error).__name__, "message": str(error)}
    result["whole_seconds_before_finalization"] = time.monotonic() - started
    complete = terminal(result, primary, resources)
    if not complete:
        raise RuntimeError(
            json.dumps(
                {
                    "primary": primary,
                    "finalization_errors": result["finalization_errors"],
                    "remaining": result["remaining"],
                }
            )
        )


if __name__ == "__main__":
    main()
