"""Bounded real-backend caller qualification, separate from strength games."""

from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
WT = ROOT.parents[1]
SOFTWARE = ROOT / "software-serial-cpu-v1"
PRIOR = ROOT / "software-recovery-v2"
OLDQUAL = ROOT / "live-qualification-v1"
sys.path.insert(0, str(SOFTWARE))
SPEC = importlib.util.spec_from_file_location(
    "qualified_software", SOFTWARE / "worker.py"
)
W = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(W)
G, P = W.G, W.P
P.LOG_MAX_BYTES = 65536
MIB = 1024**2


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


class Resources(P.CycleResources):
    def __init__(self, admission):
        super().__init__(
            # Logical whole-folder bound is qualification8 + separately-held
            # buildTMP8; the allocated component guards below enforce both.
            {"max_memory_bytes": 2 * 1024**3 - 64 * MIB, "max_output_bytes": 16 * MIB},
            OUT,
            None,
        )
        # Reuse the reviewed raw-once/hash-before-parse record loader. These
        # records are actual observations, not mock fixtures or new baselines.
        states = []
        for path in admission["retained_observed_charges"]:
            state = W.load_bound_charge_record(admission, path)
            assert (
                state["original_baseline_SHA256"]
                == admission["original_baseline_SHA256"]
            )
            states.append(state)
        baseline_packet = json.loads(
            (ROOT / "software-v1/named-baseline.json").read_text()
        )
        baseline = {row["path"]: row["allocated_B"] for row in baseline_packet["rows"]}
        self.ledger = W.NamedReplacement(baseline, [], [])
        self.held = admission["held_positive_union_B"]
        for state in states:
            self.ledger.retain(state["allocation_max_B"])
            self.ledger.outputs.update(state["allocation_max_B"])
            self.held = max(self.held, state["charged_positive_union_B"])
        self.rss_peak = self.output_peak = self.tmp_peak = 0
        self.source_upper = admission["source_control_upper_B"]
        self.source_growth = admission["source_positive_allocated_growth_B"]

    def check(self, owned=()):
        super().check(owned)
        infos = [
            P.process_info(os.getpid()),
            *(P.process_info(x["pid"]) for x in owned),
        ]
        rss = sum(x["rss"] for x in infos if x) + 64 * MIB
        self.rss_peak = max(self.rss_peak, rss)
        if rss > 2 * 1024**3:
            raise P.CycleStopped("RAMfamily2GiB includes64MiB controller")
        # No compiler/replacement lease is admitted here. Any missing retained
        # output remains UNKNOWN; a prior measured larger allocation stays held.
        self.held = max(self.held, self.ledger.charge(False))
        save(
            "charged-path-maxima.json",
            {
                "original_baseline_SHA256": G.sha(
                    ROOT / "software-v1/named-baseline.json"
                ),
                "allocation_max_B": dict(self.ledger.prior),
                "charged_positive_union_B": self.held,
                "continuous_unobserved_peak": "UNKNOWN",
            },
        )
        tmp = sum(
            G.allocated(p)
            for p in (
                ROOT / "software-v1/tmp",
                PRIOR / "tmp",
                SOFTWARE / "tmp",
                OUT / "tmp",
            )
        )
        private = sum(
            G.allocated(p / "private") for p in (ROOT / "software-v1", PRIOR, SOFTWARE)
        )
        self.tmp_peak = max(self.tmp_peak, tmp)
        if self.held > 20 * MIB or private > 19 * MIB or tmp > 8 * MIB:
            raise P.CycleStopped("retained build/private/TMP component cap")
        if self.held + private + tmp > 49 * MIB:
            raise P.CycleStopped("retained build/private/TMP whole49MiB cap")
        output = G.allocated(OUT) - G.allocated(OUT / "tmp") + G.allocated(OLDQUAL)
        self.output_peak = max(self.output_peak, output)
        if output > 8 * MIB:
            raise P.CycleStopped("qualification allocated8MiB cap")
        old_control = (
            G.allocated(ROOT)
            - G.allocated(OUT)
            - G.allocated(OLDQUAL)
            - private
            - sum(
                G.allocated(p / "tmp") for p in (ROOT / "software-v1", PRIOR, SOFTWARE)
            )
        )
        if old_control + self.source_growth > self.source_upper:
            raise P.CycleStopped("prior source/control held forecast exceeded")


def validate(admission):
    assert admission["actual_entry"] is True
    assert admission["accepted_operational_windows"] == {"Sigma": 2, "NNUE": 2}
    for path, expected in admission["bindings"].items():
        assert sha(path) == expected, path
    packet = json.loads(Path(admission["source_stop"]).read_text())
    for relative, row in packet["stopped_sources"].items():
        path = WT / relative
        assert sha(path) == row["SHA256"], relative
        assert path.stat().st_mode & 0o777 == row["mode"]
    for row in packet["unchanged_dependency_bindings"]:
        assert sha(WT / row["path"]) == row["SHA256"]
    assert P.available_memory() > 6 * 1024**3
    fs = os.statvfs(OUT)
    assert fs.f_bavail * fs.f_frsize > 128 * MIB
    W.quiet()
    for prefix in ("initial", "p2"):
        config = json.loads((OUT / f"config-{prefix}.json").read_text())
        assert not Path(config["output"]).exists()
        expected_prefix = [] if prefix == "initial" else [13]
        assert config["games"] == 2
        assert config["max_plies"] == len(expected_prefix) + 1
        assert config["arena"]["book"]["openings"][0]["prefix"] == expected_prefix
        assert config["arena"]["comparison"] == "whole_wall_time"
    return True


def collect_run(target, admission):
    report = json.loads((target / "result.json").read_text())
    manifest = json.loads((target / "manifest.json").read_text())
    assert manifest["binding"]["executable_sha256"] == admission["runner_ELF_SHA256"]
    source = manifest["binding"]["compiled_sources"]
    for key, expected in admission["critical_compiled_sources"].items():
        assert source[key] == expected, key
    assert report["planned"] == 2 and report["all_workers_joined"]
    assert report["stopped"] is None
    moves = []
    with gzip.open(target / "moves.jsonl.gz", "rt") as stream:
        for line in stream:
            moves.append(json.loads(line))
    assert len(moves) == 2, "one and only one caller window per operational slot"
    return {"report": report, "moves": moves, "compiled_sources": source}


def main():
    # Controls run on CPU1; the actual single-thread caller/backend use CPU0.
    os.sched_setaffinity(0, {1})
    os.chdir(WT)
    a = json.loads((OUT / "admission.json").read_text())
    validate(a)
    for name in ("tmp",):
        (OUT / name).mkdir(exist_ok=True)
    os.environ.update(
        CUDA_VISIBLE_DEVICES="",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
        TMPDIR=str(OUT / "tmp"),
    )
    resources = Resources(a)
    start = time.monotonic()
    result = {
        "started": datetime.now(timezone.utc).isoformat(),
        "commands": [],
        "runs": [],
        "planned_functional_slots": 4,
        "strength_slots": 0,
        "prelaunch_planned_Sigma_caller_markers": 0,
        "prelaunch_planned_NNUE_caller_markers": 0,
        "new_compile": 0,
        "new_Torch": 0,
        "model_warmup_calls": 0,
        "live_evidence_collected": False,
        "qualified": False,
    }
    failure = None
    image = OUT / "tmp/quoridor-runner"
    try:
        with (G.TARGET / "arena-software-writer.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            W.quiet()
            assert not image.exists(), "no overwrite of an earlier decoded payload"
            raw = gzip.decompress(Path(a["runner_gzip"]).read_bytes())
            assert len(raw) == a["runner_ELF_bytes"]
            assert hashlib.sha256(raw).hexdigest() == a["runner_ELF_SHA256"]
            image.write_bytes(raw)
            image.chmod(0o755)
            del raw
            resources.check()
            with P.cancellation_signals():
                for prefix in ("initial", "p2"):
                    W.quiet()
                    result["prelaunch_planned_Sigma_caller_markers"] += 1
                    result["prelaunch_planned_NNUE_caller_markers"] += 1
                    target = OUT / f"run-{prefix}"
                    record = P.execute(
                        [
                            str(image),
                            "arena",
                            "--config",
                            str(OUT / f"config-{prefix}.json"),
                        ],
                        OUT / f"arena-{prefix}.log",
                        None,
                        cpu_core=0,
                        resources=resources,
                    )
                    result["commands"].append({"scope": prefix, **record})
                    result["runs"].append(collect_run(target, a))
                    for operation in ("audit", "recover"):
                        record = P.execute(
                            [str(image), "arena", f"--{operation}", str(target)],
                            OUT / f"{operation}-{prefix}.log",
                            None,
                            cpu_core=0,
                            resources=resources,
                        )
                        result["commands"].append(
                            {"scope": f"{operation}-{prefix}-NN0", **record}
                        )
                result["live_evidence_collected"] = True
                # Numerical/caller outcome qualification is collected separately;
                # controller exit0 never turns late/failed windows into successes.
    except BaseException as error:
        failure = repr(error)
    finally:
        if image.exists():
            assert sha(image) == a["runner_ELF_SHA256"]
            image.unlink()  # Only this job's explicitly temporary decoded image.
        records = [json.loads(p.read_text()) for p in OUT.glob("*.process.json")]
        result.update(
            ended=datetime.now(timezone.utc).isoformat(),
            whole_seconds=time.monotonic() - start,
            error=failure,
            all_direct_children_reaped=all(
                r.get("direct_child_reaped") for r in records
            ),
            cleanup_complete=all(r.get("cleanup_complete") for r in records),
            remaining=[x for r in records for x in r.get("remaining", [])],
            RAMfamily_sampled_including_controller_B=resources.rss_peak,
            qualification_allocated_peak_B=resources.output_peak,
            single_decode_TMP_peak_B=resources.tmp_peak,
            charged_positive_union_B=resources.held,
            shared_target_readers_writers=0,
        )
        save("result.json", result)
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
