"""Reuse the reviewed ordered, fail-closed canonical submission barrier."""

import json
import importlib.util
import os
from pathlib import Path
import subprocess

import qualify as Q

OUT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    "launch_control", Q.PRIOR / "launch_control.py"
)
CONTROL = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CONTROL)
checked_command, verified_submit = CONTROL.checked_command, CONTROL.verified_submit


def formatted():
    checked_command(
        [
            "/workspaces/quoridor/tools/research-quality/.venv/bin/ruff",
            "format",
            "--check",
            str(OUT / "qualify.py"),
            str(OUT / "launch.py"),
        ]
    )
    checked_command(
        [
            "/workspaces/quoridor/tools/research-quality/.venv/bin/ruff",
            "check",
            str(OUT / "qualify.py"),
            str(OUT / "launch.py"),
        ]
    )
    checked_command(
        [
            "node",
            "/workspaces/quoridor/tools/research-quality/node_modules/prettier/bin/prettier.cjs",
            "--config",
            "/workspaces/quoridor/tools/research-quality/.prettierrc.json",
            "--parser",
            "json",
            "--ignore-path",
            "/dev/null",
            "--check",
            *(
                str(OUT / name)
                for name in (
                    "config-initial.json",
                    "config-p2.json",
                    "admission.json",
                    "job.json",
                )
            ),
        ]
    )
    return True


def parsed():
    job = json.loads((OUT / "job.json").read_text())
    assert job["argv"] == ["/usr/bin/python3", "-B", str(OUT / "qualify.py")]
    assert job["issue"] == "quoridor-4lc.331"
    assert all(
        job[k] is None for k in ("end_at", "notify_until", "max_runtime_seconds")
    )
    assert job["resource_contract"] == str(OUT / "admission.json")
    return True


def preflight():
    a = json.loads((OUT / "admission.json").read_text())
    Q.validate(a)
    (OUT / "tmp").mkdir(exist_ok=True)
    import fcntl

    with (Q.G.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        r = Q.Resources(a)
        r.check()
        # Single decoded image is charged before its actual future creation.
        assert r.held + a["private_held_B"] + 8 * Q.MIB <= 49 * Q.MIB
    Q.save(
        "preflight.json",
        {
            "actual_entry_predicates": True,
            "positive_union_B": r.held,
            "retained_record_SHA256": Q.sha(Q.SOFTWARE / "charged-path-maxima.json"),
            "foreign_named": [],
            "RAM_available_B": Q.P.available_memory(),
            "source_private_caps_bound": True,
            "model_or_backend_calls": 0,
        },
    )
    return True


def submit():
    result = subprocess.run(
        [
            "bash",
            "/workspaces/quoridor/scripts/dev/research-job.sh",
            "submit",
            "--config",
            str(OUT / "job.json"),
            "--state-dir",
            str(OUT / "job-runtime-v1"),
        ],
        check=True,
        capture_output=True,
        text=True,
        timeout=45,
    )
    Q.save(
        "submission.json",
        {
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        },
    )
    print(result.stdout)


if __name__ == "__main__":
    os.sched_setaffinity(0, {0, 1})
    verified_submit(
        [
            ("formatters", formatted),
            ("job parser/argv", parsed),
            ("frozen live admission", preflight),
        ],
        submit,
    )
