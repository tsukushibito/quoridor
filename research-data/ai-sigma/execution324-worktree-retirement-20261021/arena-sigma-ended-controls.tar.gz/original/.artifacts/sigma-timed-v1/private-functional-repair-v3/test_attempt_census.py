"""Two new actual-finalize AST cases; fake IO, no worker/model/Popen import."""

import ast
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
from types import SimpleNamespace
import unittest

SOURCE = Path(__file__).parent.parent / "private-functional-v1/qualify.py"
TREE = ast.parse(SOURCE.read_text())
NAMES = ["NN0-terminal", "NN0-postterminal", "NN0-wrong-terminal-ply"] + [
    op + "-" + name
    for name in ["initial", "p2"]
    for op in ["arena", "audit", "recover"]
]


class Receipt:
    def __init__(self, name, verified=True, wrong_command=False):
        self.name = name + ".process.json"
        self.verified = verified
        self.wrong_command = wrong_command

    def __str__(self):
        return "/owned/" + self.name

    def read_text(self):
        return json.dumps(
            {
                "command": ["wrong"] if self.wrong_command else ["image", self.name],
                "direct_child_reaped": self.verified,
                "cleanup_complete": self.verified,
                "remaining": [],
            }
        )


def run_finalizer(names, receipts, primary, qualified=False, registry=True):
    saved = {}
    finance = SimpleNamespace(
        held=35225600,
        unknown=[{"historical": "6aaa", "status": "UNKNOWN"}],
        check=lambda: None,
        record=lambda _: {"charged_positive_union_B": 35225600},
    )
    resources = SimpleNamespace(
        finance=finance,
        financial_errors=[],
        charge_io_errors=[],
        rss_peak=0,
        output_peak=0,
        tmp_peak=0,
    )
    if registry:
        resources.attempted_children = [
            {
                "name": name,
                "receipt": "/owned/" + name + ".process.json",
                "argv": ["image", name + ".process.json"],
            }
            for name in names
        ]
    namespace = {
        "datetime": datetime,
        "timezone": timezone,
        "time": SimpleNamespace(monotonic=lambda: 1.0),
        "json": json,
        "OUT": SimpleNamespace(glob=lambda _: receipts),
        "save": lambda name, value: saved.update({name: copy.deepcopy(value)}),
    }
    nodes = [
        n
        for n in TREE.body
        if isinstance(n, ast.FunctionDef) and n.name in {"finalize", "error_fact"}
    ]
    exec(
        compile(ast.Module(body=nodes, type_ignores=[]), str(SOURCE), "exec"), namespace
    )
    image = SimpleNamespace(parent=SimpleNamespace(iterdir=lambda: []))
    result = {"qualified": qualified}
    error = namespace["finalize"](
        result,
        primary,
        resources,
        {"caps_B": {"positive": 39845888}},
        image,
        False,
        False,
        0.0,
    )
    return saved["result.json"], error


class AttemptCensusTests(unittest.TestCase):
    def test_primary_clears_persisted_qualified_with_complete_nine_receipts(self):
        result, error = run_finalizer(
            NAMES, [Receipt(n) for n in NAMES], "original primary", True
        )
        self.assertFalse(result["qualified"])
        self.assertEqual(result["primary_error"], "original primary")
        self.assertEqual(error, "original primary")
        self.assertTrue(result["all_direct_children_reaped"])
        self.assertTrue(result["cleanup_complete"])

    def test_failed_partial_census_unknown_unless_registered_zero_or_all_verified(self):
        cases = [
            (["one"], [], True),
            (["one", "two"], [Receipt("one")], True),
            (["one"], [Receipt("one", verified=False)], True),
            (["one"], [Receipt("one", wrong_command=True)], True),
            ([], [], False),
            ([], [Receipt("unregistered")], True),
            (["one", "one"], [Receipt("one")], True),
        ]
        for names, receipts, registry in cases:
            with self.subTest(names=names, registry=registry, receipts=len(receipts)):
                result, _ = run_finalizer(
                    names, receipts, "original primary", registry=registry
                )
                self.assertFalse(result["qualified"])
                self.assertFalse(result["cleanup_complete"])
                self.assertFalse(result["all_direct_children_reaped"])
                self.assertTrue(
                    any(r.get("status") == "UNKNOWN" for r in result["remaining"])
                )
                self.assertEqual(result["charged_positive_union_B"], 35225600)
                self.assertEqual(result["primary_error"], "original primary")
        for names, receipts in [([], []), (["one"], [Receipt("one")])]:
            result, _ = run_finalizer(names, receipts, "original primary")
            self.assertFalse(result["qualified"])
            self.assertTrue(result["cleanup_complete"])
            self.assertTrue(result["all_direct_children_reaped"])
            self.assertEqual(result["remaining"], [])


if __name__ == "__main__":
    unittest.main()
