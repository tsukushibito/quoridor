"""Prepared finite private-only qualification; no compiler or new engine copy."""

from datetime import datetime, timezone
import fcntl
import gzip
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time

from private_profile import FinancialRetention, PROFILE, bound_json, validate_inputs

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
WT = ROOT.parents[1]
MIB = 1024**2
sys.path.insert(0, "/workspaces/quoridor/python")
from quoridor_training import cycle_process as P  # noqa: E402

# Reuse maintained allocation/quiet helpers and exact process-control APIs.
spec = importlib.util.spec_from_file_location(
    "retained_control", ROOT / "software-arena-lease-recovery-v4/worker.py"
)
W = importlib.util.module_from_spec(spec)
spec.loader.exec_module(W)
G = W.G
P.LOG_MAX_BYTES = 65536


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def error_fact(stage, error):
    return {"stage": stage, "type": type(error).__name__, "message": str(error)}


def validate(admission):
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared profile is not admission")
    if (
        admission["related_review"]["blockers"] != 0
        or not admission["related_review"]["actual_reader_STOP"]
    ):
        raise ValueError("private-only scope review/STOP absent")
    if (
        admission["execution_profile"] != PROFILE
        or admission["main_commit"][:7] != "cc07bcd"
    ):
        raise ValueError("unsupported retained source/version profile")
    if admission["pending_entry_obligations"]:
        raise ValueError("unresolved entry obligation")
    validate_inputs(admission)
    compiled = bound_json(admission, admission["historical_unknown"]["receipt"])
    own = [
        p
        for r in compiled
        if r["target"]["name"] == "quoridor-runner"
        and r["target"]["src_path"] == str(WT / "crates/quoridor-runner/src/main.rs")
        and r["profile"]["opt_level"] == "3"
        and r["profile"]["test"] is False
        and r["fresh"] is False
        for p in r["payloads"]
        if p["SHA256"] == admission["runner_ELF_SHA256"]
    ]
    if (
        len(own) != 1
        or admission["runner_ELF_SHA256"]
        != "155bd9346977639dccc496d75c7eb3d6cf3e10473dc7de73f6000fd267cc9188"
        or admission["runner_ELF_bytes"] != 6382688
    ):
        raise ValueError("retained real release/source/profile payload proof mismatch")
    for path, expected in admission["bindings"].items():
        if G.sha(path) != expected:
            raise ValueError("bound control/source/proof/input changed: " + path)
    for name, prefix in [("initial", []), ("p2", [13])]:
        c = bound_json(admission, str(OUT / ("config-" + name + ".json")))
        if (
            c["ruleset"] != "standard_2p_threefold"
            or c["games"] != 2
            or c["max_plies"] != len(prefix) + 1
            or c["arena"]["book"]["openings"][0]["prefix"] != prefix
            or c["output"] != str(OUT / ("run-" + name))
        ):
            raise ValueError("functional rule/prefix/censor scope changed")
        if (
            [c["workers"], c["active_games"], c["max_batch"], c["inference_cpu_core"]]
            != [1, 1, 1, 0]
            or c["cpu_cores"] != [0]
            or c["arena"]["comparison"] != "whole_wall_time"
        ):
            raise ValueError("serial shared actual core profile changed")
        if (
            c["simulations"] != 64
            or c["temperature"] != 1.0
            or c["arena"]["return_reserve_ms"] != 5
            or c["arena"]["tt_entries"] != 65536
            or [e["time_ms"] for e in c["engines"]] != [100, 100]
            or c["engines"][0]["simd"]
        ):
            raise ValueError("fixed search/clock/head configuration changed")
        if Path(c["output"]).exists():
            raise ValueError("output already exists")
    if P.available_memory() <= 6 * 1024**3:
        raise P.CycleStopped("fresh available RAM insufficient")
    fs = os.statvfs(OUT)
    if fs.f_bavail * fs.f_frsize <= 128 * MIB:
        raise P.CycleStopped("fresh disk allowance insufficient")
    W.quiet()
    return True


class Resources(P.CycleResources):
    def __init__(self, admission):
        super().__init__({"max_memory_bytes": 2 * 1024**3 - 64 * MIB}, OUT, None)
        self.a = admission
        self.finance = FinancialRetention(admission)
        self.rss_peak = self.output_peak = self.tmp_peak = 0
        self.financial_errors = []
        self.charge_io_errors = []
        self.attempted_children = []

    def check(self, owned=()):
        super().check(owned)
        infos = [
            P.process_info(os.getpid()),
            *(P.process_info(m["pid"]) for m in owned),
        ]
        ram = sum(x["rss"] for x in infos if x) + 64 * MIB
        self.rss_peak = max(self.rss_peak, ram)
        if ram > 2 * 1024**3:
            raise P.CycleStopped("whole family2GiB includes controller")
        financial_error = None
        try:
            positive = self.finance.check()
        except BaseException as error:
            financial_error = error
            self.financial_errors.append(error_fact("financial_stat", error))
        try:
            save("charged-path-maxima.json", self.finance.record(self.a))
        except BaseException as error:
            self.charge_io_errors.append(error_fact("charge_write", error))
            if financial_error is None:
                raise
        if financial_error is not None:
            # Do not replace the originating stat refusal with the charge IO error.
            raise financial_error

        def total(name):
            amount = 0
            for path in self.a["storage_areas"][name]:
                # Only the new explicitly owned, not-yet-created output area.
                # This is not an execution input or historical storage credit.
                if (
                    name == "TMP"
                    and path == str(OUT / "tmp")
                    and not Path(path).exists()
                ):
                    continue
                amount += G.allocated(path) + Path(path).stat().st_blocks * 512
            return amount

        actual_private = total("private")
        private = max(self.a["private_held_B"], actual_private)
        tmp = total("TMP")
        qual = (
            max(self.a["old_qual_held_B"], total("old_qualification"))
            + G.allocated(OUT)
            + OUT.stat().st_blocks * 512
            - G.allocated(OUT / "tmp")
        )
        self.tmp_peak = max(self.tmp_peak, tmp)
        self.output_peak = max(self.output_peak, qual)
        caps = self.a["caps_B"]
        if (
            positive > caps["positive"]
            or private > caps["private"]
            or tmp > caps["TMP"]
            or positive + private + tmp + caps["failure"] > caps["build"]
            or qual > caps["qualification"]
        ):
            raise P.CycleStopped("private-only inclusive component/whole cap exceeded")
        # Fixed source package plus all previously held source/review uppers.
        # New runtime logs/fixtures/outcomes are separately guarded in qual8.
        package = OUT.stat().st_blocks * 512 + sum(
            Path(p).stat().st_blocks * 512 for p in self.a["source_control_paths"]
        )
        repair_package = (
            G.allocated(self.a["repair_control_root"])
            + Path(self.a["repair_control_root"]).stat().st_blocks * 512
            + max(0, package - 131072)
        )
        source = (
            8376320
            + self.a["repair_review_upper_B"]
            + max(self.a["repair_control_upper_B"], repair_package)
        )
        if (
            source > self.a["source_whole_upper_B"]
            or self.a["source_whole_upper_B"] > caps["source"]
        ):
            raise P.CycleStopped("inclusive source/control forecast exceeded")


def execute(image, args, name, resources, expected_failure=False):
    # This finite entry can only use the immutable maintained arena CLI.
    if not args or args[0] != "arena":
        raise ValueError("non-arena command not admitted")
    log = OUT / (name + ".log")
    receipt = str(log.with_suffix(".process.json"))
    if any(a["receipt"] == receipt for a in resources.attempted_children):
        raise ValueError("duplicate child attempt/receipt")
    # Registered before P.execute, including any pre-Popen refusal/IO failure.
    resources.attempted_children.append(
        {"name": name, "receipt": receipt, "argv": [str(image), *args]}
    )
    try:
        record = P.execute(
            [str(image), *args], log, None, cpu_core=0, resources=resources
        )
    except P.CycleStopped:
        if not expected_failure:
            raise
        record = json.loads(log.with_suffix(".process.json").read_text())
        if (
            record["exit_code"] != 1
            or not record.get("error", "").startswith("cycle child failed:")
            or not record["direct_child_reaped"]
            or not record["cleanup_complete"]
            or record["remaining"]
            or "recovery history/Q mismatch" not in log.read_text()
        ):
            raise
    else:
        if expected_failure:
            raise ValueError("deliberately wrong replay expectation was accepted")
    resources.check()
    return record


def replay_checks(image, admission, resources):
    results = []
    for name in ["terminal", "postterminal", "wrong-terminal-ply"]:
        packet = bound_json(admission, str(OUT / ("NN0-" + name + ".expected.json")))
        directory = OUT / ("NN0-" + name)
        directory.mkdir()
        # Hand-authored EXPECTED fixture, never impersonates a runtime game.
        (directory / "manifest-start.json").write_text(json.dumps(packet) + "\n")
        record = execute(
            image,
            ["arena", "--recover", str(directory)],
            "NN0-" + name,
            resources,
            name == "wrong-terminal-ply",
        )
        if name != "wrong-terminal-ply":
            recovered = json.loads((OUT / ("NN0-" + name + ".log")).read_text())
            if recovered["observed_outcomes"] or len(recovered["missing_slots"]) != 2:
                raise ValueError("NN0 fixture unexpectedly contains runtime outcomes")
            if recovered["missing_slots"] != packet["planned_slots"]:
                raise ValueError("compiled replay output assertion mismatch")
        results.append({"NN0_expected_fixture": name, "process": record})
    return results


def collect_run(name, admission):
    target = OUT / ("run-" + name)
    report = json.loads((target / "result.json").read_text())
    manifest = json.loads((target / "manifest.json").read_text())
    if (
        manifest["binding"]["executable_sha256"] != admission["runner_ELF_SHA256"]
        or manifest["binding"]["rules"]
        != "research-standard-2p-threefold-goal-first-v1"
    ):
        raise ValueError("actual executable/rules correspondence failed")
    for key, value in admission["critical_compiled_sources"].items():
        if manifest["binding"]["compiled_sources"][key] != value:
            raise ValueError("actual compiled source mismatch: " + key)
    if (
        report["planned"] != 2
        or not report["all_workers_joined"]
        or report["stopped"] is not None
    ):
        raise ValueError("functional run incomplete/error")
    accepted = []
    for outcome in report["outcomes"]:
        if (
            not outcome["started"]
            or outcome["status"] != "unknown"
            or outcome["winner"] is not None
            or outcome["reason"] != "ply_cap"
            or len(outcome["observations"]) != 1
        ):
            raise ValueError("functional typed-censor census failed")
        obs = outcome["observations"][0]
        if (
            not obs["accepted"]
            or obs["engine_error"] is not None
            or obs["failure"] is not None
            or outcome["plies"] != (1 if name == "initial" else 2)
        ):
            raise ValueError("caller window not accepted/one-ply censored")
        accepted.append(obs)
        if obs["engine_index"] == 0:
            tt = outcome["persistent_tt"][0]
            if (
                tt["effective_tt_slots"] != 4096
                or tt["persistent_tt_byte_cap"] != 1048576
                or obs["counters"]["nodes"] > 1000000
            ):
                raise ValueError("actual NNUE TT/node allowance mismatch")
    if (
        report["pump"]["backend_work"]["warm_rows"] != 0
        or report["pump"]["backend_work"]["logical_rows"] > 64
    ):
        raise ValueError("Sigma request or warmup scope exceeded")
    return {"report": report, "accepted_windows": accepted}


def finalize(
    result, failure, resources, admission, image, created_image, created_tmp, started
):
    """Attempt every owned cleanup/accounting/publication stage independently."""
    errors = []

    def attempt(stage, action, fallback=None):
        try:
            return action()
        except BaseException as error:
            errors.append(error_fact(stage, error))
            return fallback

    if created_image:
        attempt("TMP_image_unlink", lambda: image.unlink(missing_ok=True))
    if created_tmp:
        attempt("TMP_directory_rmdir", image.parent.rmdir)

    # This explicit stat census reports uncertainty rather than claiming empty TMP.
    def temporary_remaining():
        try:
            return [str(p) for p in image.parent.iterdir()]
        except FileNotFoundError:
            return []

    tmp_remaining = attempt("TMP_remaining_read", temporary_remaining)
    paths = attempt("process_receipt_paths", lambda: list(OUT.glob("*.process.json")))
    records = []
    receipt_unknown = paths is None
    attempts = getattr(resources, "attempted_children", None)
    if (
        attempts is None
        or paths is None
        or len({a["receipt"] for a in attempts}) != len(attempts)
        or {str(p) for p in paths} != {a["receipt"] for a in attempts}
    ):
        receipt_unknown = True
        errors.append(
            {
                "stage": "partial_process_receipt_census",
                "type": "UnknownReceipt",
                "message": "attempt registry absent/duplicate or missing/unexpected receipt",
            }
        )
    for path in paths or []:
        record = attempt(
            "process_receipt_read:" + path.name,
            lambda p=path: json.loads(p.read_text()),
        )
        if record is None:
            receipt_unknown = True
        elif not isinstance(record, dict) or not isinstance(
            record.get("remaining"), list
        ):
            receipt_unknown = True
            errors.append(
                {
                    "stage": "process_receipt_schema:" + path.name,
                    "type": "InvalidReceipt",
                    "message": "missing typed directwait/cleanup facts",
                }
            )
        else:
            records.append(record)
            matching = [a for a in attempts or [] if a["receipt"] == str(path)]
            if len(matching) != 1 or record.get("command") != matching[0]["argv"]:
                receipt_unknown = True
                errors.append(
                    {
                        "stage": "process_receipt_attempt:" + path.name,
                        "type": "UnknownReceipt",
                        "message": "receipt does not match registered attempted argv",
                    }
                )

    if result.get("qualified"):
        expected = {
            "NN0-terminal.process.json",
            "NN0-postterminal.process.json",
            "NN0-wrong-terminal-ply.process.json",
        } | {
            op + "-" + name + ".process.json"
            for name in ["initial", "p2"]
            for op in ["arena", "audit", "recover"]
        }
        if paths is None or {p.name for p in paths} != expected:
            receipt_unknown = True
            errors.append(
                {
                    "stage": "process_receipt_census",
                    "type": "UnknownReceipt",
                    "message": "successful finite plan lacks exact nine receipts",
                }
            )
    if any(
        r.get("direct_child_reaped") is not True
        or r.get("cleanup_complete") is not True
        or r.get("remaining")
        for r in records
    ):
        receipt_unknown = True
        errors.append(
            {
                "stage": "process_receipt_cleanup",
                "type": "UnknownCleanup",
                "message": "directwait/cleanup not verified",
            }
        )

    def final_financial():
        resources.finance.check()
        if resources.finance.held > admission["caps_B"]["positive"]:
            raise ValueError("final retained positive component cap exceeded")

    attempt("financial_final_stat", final_financial)
    # The max ledger survives failed stat; charge and result publication are separate.
    charge_saved = attempt(
        "charge_final_write",
        lambda: (
            save("charged-path-maxima.json", resources.finance.record(admission)),
            True,
        )[1],
        False,
    )
    cleanup_complete = (
        not receipt_unknown
        and tmp_remaining == []
        and all(r.get("cleanup_complete") for r in records)
        and not any(e["stage"].startswith(("TMP_", "process_receipt_")) for e in errors)
    )
    remaining = [m for r in records for m in r.get("remaining", [])]
    if tmp_remaining:
        remaining.extend({"owned_TMP": p} for p in tmp_remaining)
    if tmp_remaining is None or receipt_unknown:
        remaining.append({"scope": "TMP/process_receipts", "status": "UNKNOWN"})
    result.update(
        actual_STOP=datetime.now(timezone.utc).isoformat(),
        whole_seconds=time.monotonic() - started,
        primary_error=failure,
        error=failure,
        finalization_errors=errors,
        financial_errors=list(resources.financial_errors),
        charge_io_errors=list(resources.charge_io_errors),
        charge_persistence="SAVED" if charge_saved else "UNKNOWN",
        result_persistence="ATTEMPTED",
        all_direct_children_reaped=not receipt_unknown
        and all(r.get("direct_child_reaped") for r in records),
        cleanup_complete=cleanup_complete,
        remaining=remaining,
        charged_positive_union_B=resources.finance.held,
        historical_unknown=resources.finance.unknown,
        RAM_family_sampled_B=resources.rss_peak,
        qualification_allocated_peak_B=resources.output_peak,
        TMP_allocated_peak_B=resources.tmp_peak,
    )
    result["attempted_children"] = attempts
    if (
        failure is not None
        or errors
        or resources.financial_errors
        or resources.charge_io_errors
    ):
        result["qualified"] = False
        result["error"] = failure or json.dumps(
            errors or resources.financial_errors or resources.charge_io_errors
        )
    result["result_persistence"] = "SAVED_IF_THIS_WRITE_SUCCEEDS"
    result_saved = attempt(
        "result_write", lambda: (save("result.json", result), True)[1], False
    )
    if not result_saved:
        result["qualified"] = False
        result["result_persistence"] = "UNKNOWN"
        result["error"] = failure or json.dumps(errors)
    # Bounded outer job output is an independent evidence channel when disk IO fails.
    if not result_saved or not charge_saved:
        attempt(
            "terminal_receipt_emit",
            lambda: print(
                json.dumps(
                    {
                        key: result[key]
                        for key in [
                            "primary_error",
                            "error",
                            "finalization_errors",
                            "financial_errors",
                            "charge_io_errors",
                            "charge_persistence",
                            "result_persistence",
                            "remaining",
                            "charged_positive_union_B",
                        ]
                    },
                    allow_nan=False,
                ),
                flush=True,
            ),
        )
    if errors or resources.financial_errors or resources.charge_io_errors:
        # If every output channel fails, the raised terminal error still carries
        # the primary, individual stage causes, uncertainty and retained charge.
        result["error"] = json.dumps(
            {
                "primary_error": failure,
                "finalization_errors": errors,
                "financial_errors": resources.financial_errors,
                "charge_io_errors": resources.charge_io_errors,
                "charged_positive_union_B": resources.finance.held,
                "remaining": remaining,
            }
        )
    return result["error"]


def main():
    os.sched_setaffinity(0, {1})
    os.chdir(WT)
    admission = json.loads((OUT / "admission.json").read_text())
    validate(admission)  # Prepared false refuses before any payload/model read.
    resources = Resources(admission)
    image = OUT / "tmp/quoridor-runner"
    started = time.monotonic()
    result = {
        "actual_START": datetime.now(timezone.utc).isoformat(),
        "functional_slots": 4,
        "scientific_slots": 0,
        "compiled_replay_NN0": [],
        "commands": [],
        "runs": [],
        "qualified": False,
        "compile_calls": 0,
    }
    failure = None
    created_image = False
    created_tmp = False
    os.environ.update(
        CUDA_VISIBLE_DEVICES="",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        ORT_DISABLE_TELEMETRY="1",
        TMPDIR=str(image.parent),
        PYTHONDONTWRITEBYTECODE="1",
    )
    try:
        with (G.TARGET / "arena-software-writer.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            W.quiet()
            image.parent.mkdir()
            created_tmp = True
            with (
                gzip.open(admission["runner_gzip"], "rb") as source,
                image.open("xb") as target,
            ):
                created_image = True
                shutil.copyfileobj(source, target, 65536)
            image.chmod(0o755)
            if (
                image.stat().st_size != admission["runner_ELF_bytes"]
                or G.sha(image) != admission["runner_ELF_SHA256"]
            ):
                raise ValueError("immutable decoded production payload mismatch")
            resources.check()
            with P.cancellation_signals():
                result["compiled_replay_NN0"] = replay_checks(
                    image, admission, resources
                )
                for name in ["initial", "p2"]:
                    W.quiet()
                    result["commands"].append(
                        execute(
                            image,
                            [
                                "arena",
                                "--config",
                                str(OUT / ("config-" + name + ".json")),
                            ],
                            "arena-" + name,
                            resources,
                        )
                    )
                    result["runs"].append(collect_run(name, admission))
                    for operation in ["audit", "recover"]:
                        result["commands"].append(
                            execute(
                                image,
                                ["arena", "--" + operation, str(OUT / ("run-" + name))],
                                operation + "-" + name,
                                resources,
                            )
                        )
                result["qualified"] = True
    except BaseException as error:
        failure = repr(error)
    finally:
        failure = finalize(
            result,
            failure,
            resources,
            admission,
            image,
            created_image,
            created_tmp,
            started,
        )
    if failure:
        raise RuntimeError(failure)


if __name__ == "__main__":
    main()
