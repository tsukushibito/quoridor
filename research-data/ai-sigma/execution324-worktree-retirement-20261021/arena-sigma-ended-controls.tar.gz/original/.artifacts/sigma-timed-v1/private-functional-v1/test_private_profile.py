"""New private-purpose/retained-charge boundary only; no runtime imports/jobs."""

import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import private_profile as C


def prepared_records():
    rlib = C.HISTORICAL_RLIB
    other = str(C.TARGET / "release/deps/another-owned-known.rmeta")
    profile = {
        "opt_level": "3",
        "debuginfo": 0,
        "debug_assertions": False,
        "overflow_checks": False,
        "test": False,
    }
    data = {
        "/bound-record": {
            "original_baseline_SHA256": C.BASELINE_SHA,
            "charged_positive_union_B": C.POSITIVE_FLOOR,
            "allocation_max_B": {rlib: C.RLIB_MAX, other: 8192},
        },
        "/bound-baseline": {
            "rows": [
                {"path": rlib, "allocated_B": 8769536},
                {"path": other, "allocated_B": 4096},
            ]
        },
        "/bound-receipt": [
            {
                "target": {
                    "name": "quoridor_runner",
                    "src_path": "/own-WT/crates/quoridor-runner/src/lib.rs",
                },
                "profile": profile,
                "features": ["default"],
                "payloads": [
                    {
                        "path": rlib,
                        "SHA256": "old-compiled-payload",
                        "allocated_B": C.RLIB_MAX,
                    }
                ],
            }
        ],
    }
    a = {
        "execution_profile": C.PROFILE,
        "WT": "/own-WT",
        "retained_observed_record": "/bound-record",
        "original_baseline_path": "/bound-baseline",
        "original_baseline_SHA256": C.BASELINE_SHA,
        "historical_unknown": {
            "path": rlib,
            "max_allocation_B": C.RLIB_MAX,
            "receipt": "/bound-receipt",
            "prior_SHA256": "old-compiled-payload",
            "compiled_profile": profile,
        },
        "bindings": {"/bound-baseline": C.BASELINE_SHA},
    }
    return a, data, other


class PrivatePurposeTests(unittest.TestCase):
    def ledger(self):
        a, data, other = prepared_records()
        with patch.object(C, "bound_json", side_effect=lambda _, p: data[p]):
            ledger = C.FinancialRetention(a)
        return ledger, a, other

    def test_exact_historical_unknown_holds_floor_and_maxima(self):
        ledger, a, other = self.ledger()

        def stat_path(p):
            if p == C.HISTORICAL_RLIB:
                raise FileNotFoundError(p)
            return SimpleNamespace(st_blocks=64)

        self.assertEqual(ledger.check(stat_path), C.POSITIVE_FLOOR)
        self.assertEqual(ledger.maxima[other], 32768)
        self.assertEqual(
            ledger.record(a)["historical_unknown"][0]["allocation_max_B"], C.RLIB_MAX
        )
        self.assertEqual(
            ledger.check(lambda _: SimpleNamespace(st_blocks=0)), C.POSITIVE_FLOOR
        )
        self.assertEqual(ledger.maxima[C.HISTORICAL_RLIB], C.RLIB_MAX)

    def test_no_other_missing_stat_error_or_compile_profile_exemption(self):
        ledger, a, other = self.ledger()
        with self.assertRaises(ValueError):
            ledger.check(lambda _: (_ for _ in ()).throw(FileNotFoundError(other)))
        with self.assertRaises(PermissionError):
            ledger.check(lambda _: (_ for _ in ()).throw(PermissionError(other)))
        self.assertGreaterEqual(ledger.held, C.POSITIVE_FLOOR)
        a["execution_profile"] = "arena-build-compile"
        with patch.object(C, "bound_json") as read:
            with self.assertRaises(ValueError):
                C.FinancialRetention(a)
            read.assert_not_called()

    def test_bound_raw_membership_digest_before_parse(self):
        with patch.object(Path, "read_bytes") as read:
            with self.assertRaises(ValueError):
                C.bound_json({"bindings": {}}, "/unbound")
            read.assert_not_called()
        raw = b"invalid JSON"
        with (
            patch.object(Path, "read_bytes", return_value=raw),
            patch.object(C.json, "loads") as parse,
        ):
            with self.assertRaises(ValueError):
                C.bound_json({"bindings": {"/bound": "wrong-sha"}}, "/bound")
            parse.assert_not_called()
        raw = json.dumps({"held": C.POSITIVE_FLOOR}).encode()
        with patch.object(Path, "read_bytes", return_value=raw) as read:
            self.assertEqual(
                C.bound_json(
                    {"bindings": {"/bound": hashlib.sha256(raw).hexdigest()}}, "/bound"
                )["held"],
                C.POSITIVE_FLOOR,
            )
            read.assert_called_once()

    def test_required_private_input_missing_is_not_historical_exception(self):
        a = {
            "execution_profile": C.PROFILE,
            "execution_inputs": [
                {"path": p, "SHA256": digest} for p, digest in C.FIXED_INPUTS.items()
            ],
            "bindings": dict(C.FIXED_INPUTS),
        }
        with (
            patch.object(Path, "is_symlink", return_value=False),
            patch.object(Path, "stat", side_effect=FileNotFoundError("required input")),
        ):
            with self.assertRaises(FileNotFoundError):
                C.validate_inputs(a)
        a["execution_inputs"][0]["path"] = C.HISTORICAL_RLIB
        with self.assertRaises(ValueError):
            C.validate_inputs(a)


if __name__ == "__main__":
    unittest.main()
