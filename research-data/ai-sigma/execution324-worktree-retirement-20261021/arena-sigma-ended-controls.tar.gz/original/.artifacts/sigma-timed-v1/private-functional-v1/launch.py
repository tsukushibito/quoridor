"""Prepared canonical submission barrier; no entry while flags/obligations remain."""

import fcntl
import importlib.util
import json
from pathlib import Path
import subprocess

import qualify as Q

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "launch_control", Q.ROOT / "software-recovery-v2/launch_control.py"
)
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)


def formatted():
    py = [
        str(OUT / n)
        for n in [
            "qualify.py",
            "private_profile.py",
            "replay_fixtures.py",
            "launch.py",
            "test_private_profile.py",
        ]
    ]
    for argv in [
        [
            "/workspaces/quoridor/tools/research-quality/.venv/bin/ruff",
            "format",
            "--check",
            *py,
        ],
        ["/workspaces/quoridor/tools/research-quality/.venv/bin/ruff", "check", *py],
        [
            "node",
            "/workspaces/quoridor/tools/research-quality/node_modules/prettier/bin/prettier.cjs",
            "--config",
            "/workspaces/quoridor/tools/research-quality/.prettierrc.json",
            "--ignore-path",
            "/dev/null",
            "--check",
            *[
                str(OUT / n)
                for n in [
                    "config-initial.json",
                    "config-p2.json",
                    "admission.json",
                    "job.json",
                ]
            ],
        ],
    ]:
        C.checked_command(argv)
    return True


def parsed():
    job = json.loads((OUT / "job.json").read_text())
    if (
        job["issue"] != "quoridor-4lc.331"
        or job["argv"] != ["/usr/bin/python3", "-B", str(OUT / "qualify.py")]
        or job["resource_contract"] != str(OUT / "admission.json")
        or any(
            job[k] is not None
            for k in ["end_at", "notify_until", "max_runtime_seconds"]
        )
    ):
        raise ValueError("immutable finite job identity/horizon mismatch")
    return True


def preflight():
    a = json.loads((OUT / "admission.json").read_text())
    Q.validate(a)  # Exactly True is necessary; prepared flags refuse first.
    with (Q.G.TARGET / "arena-software-writer.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        Q.W.quiet()
        resource = Q.Resources(a)
        resource.check()
        if (
            resource.finance.held
            + a["private_held_B"]
            + a["caps_B"]["TMP"]
            + a["caps_B"]["failure"]
            > a["caps_B"]["build"]
        ):
            raise ValueError("single-decode prospective whole cost does not fit")
    return True


def submit():
    result = subprocess.run(
        [
            "bash",
            "/workspaces/quoridor/scripts/dev/research-job.sh",
            "submit",
            "--config",
            str(OUT / "job.json"),
            "--state-dir",
            str(OUT / "job-runtime-v1"),
        ],
        check=True,
        capture_output=True,
        text=True,
        timeout=45,
    )
    Q.save(
        "submission.json",
        {"exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr},
    )
    return True


if __name__ == "__main__":
    C.verified_submit([formatted, parsed, preflight], submit)
