"""One private-only execution scope; historical compiler charges remain held."""

import hashlib
import json
from pathlib import Path
import stat

TARGET = Path("/workspaces/quoridor/.artifacts/rust-migration/target")
HISTORICAL_RLIB = str(TARGET / "release/deps/libquoridor_runner-6aaa82ac9921176f.rlib")
RLIB_MAX = 9236480
POSITIVE_FLOOR = 35225600
PROFILE = "retained-155-private-functional-four-v1"
BASELINE_SHA = "86b76641353ecf4c5a0107522f97a308b68981a733fc8279fddb504a6312430d"
ROOT = Path(__file__).resolve().parent.parent
ASSETS = Path("/workspaces/quoridor/.worktree/assets")
BEST = (
    ASSETS
    / "checkpoints/public-full-learning/trigger-patience-v1/patience1/output/best-model"
)
FIXED_INPUTS = {
    str(
        ROOT / "software-threefold-api-entry-v3/private/quoridor-runner.gz"
    ): "ed964e3a9c180b9e59c0c82a23951569b1e461bc24e657952e3ef3f94cab8e70",
    str(
        BEST / "manifest.json"
    ): "c4712e0872b6831e33fcf59b99d9d7f774d18a3e8d5236d7923ba65e64aabc39",
    str(
        BEST / "weights.f32"
    ): "9ca438e43b0c105ac5f802a302946f2ba71623ea2bc443b9c54cc9a8468b75b0",
    str(
        ASSETS / "models/ai-sigma/reference/sigma-pcr250/best.onnx"
    ): "d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d",
    "/home/vscode/.cache/inference/envs/quoridor-training/lib/python3.14/site-packages/onnxruntime/capi/libonnxruntime.so.1.30.0": "c902c70b3003c0e99fada202f37478c515ae9bba7944c2b2abd0017bae0c82ed",
}


def bound_json(admission, path):
    """Membership before IO; hash and parse the same immutable bytes."""
    if path not in admission["bindings"]:
        raise ValueError("unbound record: " + path)
    raw = Path(path).read_bytes()
    if (
        len(raw) > 1048576
        or hashlib.sha256(raw).hexdigest() != admission["bindings"][path]
    ):
        raise ValueError("record size/SHA mismatch: " + path)
    return json.loads(raw)


def validate_inputs(admission):
    if admission["execution_profile"] != PROFILE:
        raise ValueError("unsupported private execution profile")
    inputs = admission["execution_inputs"]
    if not inputs or len({row["path"] for row in inputs}) != len(inputs):
        raise ValueError("empty/duplicate execution inputs")
    if {row["path"]: row["SHA256"] for row in inputs} != FIXED_INPUTS:
        raise ValueError("execution inputs differ from the five fixed retained bodies")
    if any(row["path"] == HISTORICAL_RLIB for row in inputs):
        raise ValueError("historical compiler archive is not a runtime input")
    for row in inputs:
        path = Path(row["path"])
        if not path.is_absolute() or ".." in path.parts or path.is_symlink():
            raise ValueError("noncanonical execution input")
        if admission["bindings"].get(str(path)) != row["SHA256"]:
            raise ValueError("runtime input digest not bound")
        info = path.stat()  # Every runtime input must exist; no missing exception.
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o777 != row["mode"]:
            raise ValueError("runtime input type/mode mismatch")
        if (
            info.st_size != row["bytes"]
            or info.st_blocks * 512 > row["allocated_upper_B"]
        ):
            raise ValueError("runtime input allocation/size mismatch")
        with path.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        if digest != row["SHA256"]:
            raise ValueError("runtime input SHA mismatch")


class FinancialRetention:
    """Named maxima are financial records, separate from required runtime inputs."""

    def __init__(self, admission):
        if admission["execution_profile"] != PROFILE:
            raise ValueError("private financial scope used by another profile")
        state = bound_json(admission, admission["retained_observed_record"])
        baseline = bound_json(admission, admission["original_baseline_path"])
        if state["original_baseline_SHA256"] != admission["original_baseline_SHA256"]:
            raise ValueError("retained original baseline mismatch")
        if admission["original_baseline_SHA256"] != BASELINE_SHA:
            raise ValueError("original baseline may not be rebased")
        if (
            admission["bindings"][admission["original_baseline_path"]]
            != admission["original_baseline_SHA256"]
        ):
            raise ValueError("baseline binding mismatch")
        amounts = state["allocation_max_B"]
        held = state["charged_positive_union_B"]
        if (
            type(held) is not int
            or held < POSITIVE_FLOOR
            or not isinstance(amounts, dict)
        ):
            raise ValueError("held union missing/lowered")
        for path, amount in amounts.items():
            if (
                not isinstance(path, str)
                or not path.startswith(str(TARGET) + "/")
                or ".." in Path(path).parts
                or "\0" in path
                or type(amount) is not int
                or amount < 0
            ):
                raise ValueError("invalid retained ownership/allocation")
        historical = admission["historical_unknown"]
        proof = bound_json(admission, historical["receipt"])
        if (
            historical["path"] != HISTORICAL_RLIB
            or historical["max_allocation_B"] != RLIB_MAX
            or amounts.get(HISTORICAL_RLIB) != RLIB_MAX
        ):
            raise ValueError("unsupported historical UNKNOWN declaration")
        payloads = [
            p
            for r in proof
            if r["target"]["name"] == "quoridor_runner"
            and r["target"]["src_path"]
            == admission["WT"] + "/crates/quoridor-runner/src/lib.rs"
            and r["profile"] == historical["compiled_profile"]
            and r["features"] == ["default"]
            for p in r["payloads"]
            if p["path"] == HISTORICAL_RLIB
        ]
        if (
            len(payloads) != 1
            or payloads[0]["SHA256"] != historical["prior_SHA256"]
            or payloads[0]["allocated_B"] != RLIB_MAX
        ):
            raise ValueError("historical OWN compiler receipt mismatch")
        self.baseline = {row["path"]: row["allocated_B"] for row in baseline["rows"]}
        self.maxima = dict(amounts)
        self.held = held
        self.unknown = []

    def check(self, stat_path=None):
        """Retain the exact historical exception, never exempt any required input."""
        stat_path = stat_path or (lambda path: Path(path).stat())
        unknown = []
        try:
            for path in sorted(self.maxima):
                try:
                    info = stat_path(path)
                except FileNotFoundError:
                    if path != HISTORICAL_RLIB:
                        raise ValueError(
                            "other historical output absent/UNKNOWN: " + path
                        )
                    unknown.append(
                        {
                            "path": path,
                            "allocation_max_B": self.maxima[path],
                            "status": "historical_UNKNOWN_NOT_runtime_storage_qualified",
                        }
                    )
                else:
                    self.maxima[path] = max(self.maxima[path], info.st_blocks * 512)
        finally:
            # Persist even a larger observation preceding a later refusal.
            self.held = max(
                self.held,
                sum(
                    max(0, amount - self.baseline.get(path, 0))
                    for path, amount in self.maxima.items()
                ),
            )
            self.unknown = unknown
        return self.held

    def record(self, admission):
        return {
            "original_baseline_SHA256": admission["original_baseline_SHA256"],
            "allocation_max_B": dict(self.maxima),
            "charged_positive_union_B": self.held,
            "historical_unknown": self.unknown,
            "execution_profile": PROFILE,
            "continuous_unobserved_peak": "UNKNOWN",
        }
