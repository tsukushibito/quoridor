"""One fixed 64-request pilot and saved-only audit, using maintained ownership."""

from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import sys

import software_worker_P01_v4 as S
from pilot_control import OUTPUT, WHOLE, config, verify

P, ROOT, MIB = S.P, S.ROOT, S.MIB
write_json = S.write_json


def quiet():
    S.quiet()
    # Artifact scripts include native/model and saved-analysis guardians. Stable
    # canonical job notifiers live in tools/, and are not treated as computation.
    for entry in Path("/proc").iterdir():
        if not entry.name.isdecimal() or int(entry.name) == os.getpid():
            continue
        try:
            argv = [
                os.fsdecode(a)
                for a in (entry / "cmdline").read_bytes().split(b"\0")
                if a
            ]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if (
            argv
            and Path(argv[0]).name.startswith("python")
            and any(".artifacts/" in arg and arg.endswith(".py") for arg in argv[1:])
        ):
            raise P.CycleStopped(
                "active artifact source/model/analysis guardian: " + entry.name
            )


def bound_json(admission, name):
    if name not in admission["bindings"]:
        raise ValueError("unbound metadata")
    raw = Path(name).read_bytes()
    if hashlib.sha256(raw).hexdigest() != admission["bindings"][name]["SHA256"]:
        raise ValueError("metadata changed before parse")
    return json.loads(raw)


def validate(admission):
    # Prepared refusal precedes input IO or any native child.
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared pilot is not execution")
    if admission["pending_obligations"] or admission["phase"] != "pilot64":
        raise ValueError("pilot entry obligations remain")
    if (
        admission["supported_whole_B"] != WHOLE
        or admission["main_volume_n"] is not None
    ):
        raise ValueError("whole phase or full generation N")
    required = {
        str(ROOT / "pilot_worker_v2.py"),
        str(ROOT / "software_worker_P01_v4.py"),
        str(ROOT / "pilot_control.py"),
        admission["executable"],
        admission["private"],
        admission["software_receipt"],
        admission["label_receipt"],
        admission["config"],
        admission["retained_charge_path"],
    }
    if not required.issubset(admission["bindings"]):
        raise ValueError("missing required private/controller/proof binding")
    if (
        admission["executable"]
        != str(ROOT / "target-current99-v1/release/quoridor-runner")
        or admission["private"] != str(ROOT / "private-pilot-current99-P01-v4.gz")
        or admission["software_receipt"]
        != str(ROOT / "software-qualified-STOP-P01-v4.json")
    ):
        raise ValueError("not the exact qualified OWN runtime body")
    verify(admission["bindings"])
    c = config(Path(admission["config"]).read_bytes())
    software = bound_json(admission, admission["software_receipt"])
    labels = bound_json(admission, admission["label_receipt"])
    if (
        software["status"] != "SCOPED_SOFTWARE_PASS"
        or software["remaining"] != []
        or software["processcleanup"] != []
        or software["compiled_body"]["path"] != admission["executable"]
        or software["packed_private"]["path"] != admission["private"]
        or software["compiled_body"]["SHA256"]
        != admission["bindings"][admission["executable"]]["SHA256"]
        or software["packed_private"]["SHA256"]
        != admission["bindings"][admission["private"]]["SHA256"]
        or not software["config_inlet"]["valid"]
        or software["config_inlet"]["models_loaded"] != 0
        or labels["production_terminal_SHA256"]
        != software["config_inlet"]["compiled_sources"][
            "crates/quoridor-data/src/terminal.rs"
        ]
        or labels["remaining"] != []
        or labels["status"] != "SCOPED_PASS"
        or labels["joined_Rust_scope"]["label_definitions_PASS"] != 7
        or labels["directwait"] is not True
        or labels["processcleanup"] is not True
        or labels["source_after_match"] is not True
    ):
        raise ValueError("actual software/label/body dependency mismatch")
    expected = {
        "target": [str(ROOT / "target-current99-v1"), 2 * 1024**3],
        "private": [str(ROOT / "private-pilot-current99-P01-v4.gz"), 128 * MIB],
        "controls": [str(ROOT / "pilot-control-output-v2"), 512 * MIB],
        "pilot": [OUTPUT, 1024**3],
        "TMP": [str(ROOT / "pilot-TMP-v2"), 256 * MIB],
    }
    if (
        admission["owned_roots"] != expected
        or admission["output"] != expected["controls"][0]
        or admission["temporary"] != expected["TMP"][0]
        or admission["retained_outputs"]
        != [
            str(ROOT / name)
            for name in (
                "software-output-v1",
                "software-output-recovery-v2",
                "software-output-tail-v3",
                "software-output-P01-v4",
            )
        ]
        or admission["retained_private"]
        != [
            str(ROOT / "partial-runner-b7-before-v3.gz"),
            str(ROOT / "private-pilot-current99-v3.gz"),
        ]
        or admission["retained_charge_path"]
        != str(ROOT / "software-output-P01-v4/held-charges.json")
    ):
        raise ValueError("exact owned output/retention leases differ")
    if any(
        Path(name).exists()
        for name in (OUTPUT, admission["output"], admission["temporary"])
    ):
        raise ValueError("exclusive pilot namespace already exists")
    if (
        not Path(OUTPUT).parent.is_dir()
        or Path(OUTPUT).parent.is_symlink()
        or str(Path(OUTPUT).parent.resolve()) != str(Path(OUTPUT).parent)
    ):
        raise ValueError("declared assets parent unavailable")
    if (
        platform.release() != admission["kernel_release"]
        or Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        != admission["boot_id"]
    ):
        raise ValueError("actual kernel/boot changed")
    if 0 not in os.sched_getaffinity(0) or P.available_memory() < 6 * 1024**3:
        raise ValueError("pilot CPU/family2GiB plus host4GiB unavailable")
    fs = os.statvfs(ROOT)
    if fs.f_bavail * fs.f_frsize < WHOLE:
        raise ValueError("inclusive physical storage unavailable")
    quiet()
    return c


class Resources(S.Resources):
    def __init__(self, admission, output):
        P.CycleResources.__init__(
            self,
            {
                "host_ram_reserve": 4 * 1024**3,
                "max_memory_bytes": 2 * 1024**3 - 64 * MIB,
                "max_output_bytes": 512 * MIB,
            },
            output,
            None,
        )
        self.admission, self.attempts, self.maxima = admission, [], {}
        allowed = {
            "target": [admission["owned_roots"]["target"][0]],
            "controls": admission["retained_outputs"],
            "private": [admission["private"], *admission["retained_private"]],
        }
        for row in bound_json(admission, admission["retained_charge_path"]):
            kind, name, charge = (
                row["component"],
                row["path"],
                row["max_observed_allocated_B"],
            )
            if (
                kind not in allowed
                or type(charge) is not int
                or charge < 0
                or not any(
                    Path(name).is_relative_to(Path(root)) for root in allowed[kind]
                )
                or (kind, name) in self.maxima
            ):
                raise ValueError("foreign/duplicate retained charge")
            self.maxima[(kind, name)] = charge
        self.maxima[("pilot", str(Path(OUTPUT).parent))] = (
            Path(OUTPUT).parent.stat().st_blocks * 512
        )
        self.family_peak, self.next_storage_check = 0, 0

    def check(self, owned=()):
        super().check(owned)
        if self.family_peak > 2 * 1024**3:
            raise P.CycleStopped("pilot family2GiB including64MiB controller")


def main():
    path = Path(sys.argv[1])
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != sys.argv[2]:
        raise ValueError("immutable pilot admission")
    admission = json.loads(raw)
    c = validate(admission)
    output = Path(admission["output"])
    output.mkdir()
    resources = Resources(admission, output)
    result = {
        "qualified": False,
        "scope": "one64 fixed-D pilot plus saved audit",
        "N": None,
    }
    primary = None
    try:
        # Exclude Cargo only for this actual finite fair interval; no idle lease.
        with S.LOCK.open("a+b") as lock, P.cancellation_signals():
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            quiet()
            verify(admission["bindings"])
            os.environ.update(
                {
                    "OMP_NUM_THREADS": "1",
                    "OPENBLAS_NUM_THREADS": "1",
                    "MKL_NUM_THREADS": "1",
                    "CUDA_VISIBLE_DEVICES": "",
                }
            )
            S.execute(
                "pilot64",
                [
                    admission["executable"],
                    "teacher-pilot",
                    "--config",
                    admission["config"],
                ],
                resources,
                output,
                0,
            )
            saved = S.execute(
                "audit64",
                [admission["executable"], "teacher-pilot", "--audit", c["output"]],
                resources,
                output,
                0,
            )
            report = json.loads(saved.read_bytes())
            if report["scheduled"] != 64 or report["recorded"] != 64:
                raise ValueError("exact64 audit census incomplete")
            result["report"] = report
            result["private_SHA256"] = admission["bindings"][admission["executable"]][
                "SHA256"
            ]
            verify(admission["bindings"])
    except BaseException as error:
        primary = error
    # Reuse the independently staged finalizer, adjusting only the success census.
    finalize(result, primary, resources, output)


def finalize(result, primary, resources, output):
    errors, receipts, remaining = [], [], []

    def attempt(stage, action):
        try:
            return action()
        except BaseException as error:
            errors.append(
                {"stage": stage, "type": type(error).__name__, "message": str(error)}
            )
            return None

    attempt("final_resources", resources.check)
    unknown = False
    for tried in resources.attempts:
        receipt = attempt(
            "receipt:" + tried["name"],
            lambda tried=tried: json.loads(Path(tried["receipt"]).read_bytes()),
        )
        verified = bool(
            receipt
            and receipt.get("command") == tried["command"]
            and receipt.get("direct_child_reaped") is True
            and receipt.get("cleanup_complete") is True
            and receipt.get("remaining") == []
        )
        unknown |= not verified
        receipts.append(
            {"attempt": tried, "receipt": receipt, "cleanup_verified": verified}
        )
        if receipt:
            remaining.extend(receipt.get("remaining", []))
    result.update(
        primary_error=None
        if primary is None
        else {"type": type(primary).__name__, "message": str(primary)},
        stage_failures=errors,
        attempted_children=resources.attempts,
        receipts=receipts,
        cleanup_unknown=unknown,
        cleanup_complete=not unknown and not remaining,
        remaining=remaining,
        family_RSS_sample_peak_B=resources.family_peak,
        continuous_peak="UNKNOWN",
        source_STOP=datetime.now(timezone.utc).isoformat(),
    )
    charges = [
        {"component": kind, "path": path, "max_observed_allocated_B": value}
        for (kind, path), value in sorted(resources.maxima.items())
    ]
    attempt("held_charges", lambda: write_json(output / "held-charges.json", charges))
    result["qualified"] = (
        primary is None and not errors and not unknown and len(receipts) == 2
    )
    attempt("result", lambda: write_json(output / "pilot-result.json", result))
    if errors:
        result["qualified"] = False
        print(json.dumps({"terminal_failure_facts": result}), flush=True)
    if primary is not None:
        raise primary
    if errors or unknown or not result["qualified"]:
        raise RuntimeError("pilot qualification incomplete: " + json.dumps(result))


if __name__ == "__main__":
    main()
