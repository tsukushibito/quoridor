"""Actual quiet-function ASTs with fake /proc; no production imports or children."""

import ast
import json
import os
from pathlib import Path
import resource
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent


class Refused(RuntimeError):
    pass


class Entry:
    def __init__(self, pid, argv):
        self.name, self.argv = str(pid), argv

    def __truediv__(self, name):
        assert name == "cmdline"
        return self

    def read_bytes(self):
        return b"\0".join(os.fsencode(arg) for arg in self.argv) + b"\0"


def actual_function(path):
    tree = ast.parse(path.read_text())
    node = next(
        n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "quiet"
    )
    return compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec")


def check(argv, expected_refusal, pid=200):
    proc = SimpleNamespace(iterdir=lambda: [Entry(pid, argv)])
    ports = {
        "Path": lambda arg: proc if arg == "/proc" else Path(arg),
        "os": SimpleNamespace(getpid=lambda: 100, fsdecode=os.fsdecode),
        "P": SimpleNamespace(CycleStopped=Refused),
    }
    base = dict(ports)
    exec(actual_function(ROOT / "software_worker_P01_v4.py"), base)
    ports["S"] = SimpleNamespace(quiet=base["quiet"])
    exec(actual_function(ROOT / "pilot_worker_v3.py"), ports)
    try:
        ports["quiet"]()
    except Refused:
        assert expected_refusal, argv
    else:
        assert not expected_refusal, argv


def main():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    begin = time.monotonic()
    cases = [
        (["python3", "-B", ".artifacts/review/read_control_metadata.py"], False, 200),
        (["python3", "-B", ".artifacts/review/read_source.py"], False, 200),
        (
            [
                "python3",
                "-B",
                "tools/research-session/job.py",
                "notify",
                ".artifacts/state.json",
            ],
            False,
            99,
        ),
        (
            [
                "python3",
                "-B",
                "tools/research-session/job.py",
                "run",
                "--config",
                ".artifacts/job.json",
            ],
            False,
            99,
        ),
        (["python3", "-B", ".artifacts/pilot_worker_v3.py"], False, 100),
        (["rustc", "input.rs"], True, 200),
        (["cargo", "test"], True, 200),
        (["quoridor-runner", "teacher-pilot"], True, 200),
        (["perf", "record"], True, 200),
        (["chrome", "--headless"], True, 200),
        (["python3", "-B", ".artifacts/plain_worker_v2.py"], True, 200),
        (["python3", "-B", ".artifacts/pilot_worker_v3.py"], True, 200),
        (["python3", "-B", ".artifacts/numeric_worker_v1.py"], True, 200),
        (["python3", "-B", ".artifacts/software_worker_P01_v4.py"], True, 200),
        (["python3", "-B", ".artifacts/worker.py"], True, 200),
    ]
    for argv, refusal, pid in cases:
        check(argv, refusal, pid)
    print(
        json.dumps(
            {
                "scope": "actual guard AST/fake proc",
                "cases_PASS": len(cases),
                "internal_wall_seconds": time.monotonic() - begin,
                "Popen_compiler_native_model": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
