"""Frozen pilot admission; full N, fits and development games have no inlet."""

import hashlib
import json
import math
import os
from pathlib import Path
import stat

OUTPUT = (
    "/workspaces/quoridor/.worktree/assets/data/nnue-teacher-distance-tanh-v1/pilot-64"
)
MIB = 1024**2
WHOLE = 4 * 1024**3


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while block := stream.read(MIB):
            value.update(block)
    return value.hexdigest()


def verify(bindings):
    for path, expected in bindings.items():
        if not isinstance(expected, dict) or set(expected) != {
            "SHA256",
            "mode",
            "bytes",
        }:
            raise ValueError("unsupported immutable binding")
        if (
            not isinstance(expected["SHA256"], str)
            or len(expected["SHA256"]) != 64
            or any(c not in "0123456789abcdef" for c in expected["SHA256"])
            or type(expected["mode"]) is not int
            or type(expected["bytes"]) is not int
            or expected["bytes"] < 0
        ):
            raise ValueError("malformed immutable metadata")
        target = Path(path)
        info = target.lstat()
        if (
            not stat.S_ISREG(info.st_mode)
            or str(target.resolve()) != path
            or stat.S_IMODE(info.st_mode) != expected["mode"]
            or info.st_size != expected["bytes"]
            or digest(target) != expected["SHA256"]
        ):
            raise ValueError("immutable dependency changed: " + path)


def config(raw):
    value = json.loads(raw)
    expected = {
        "phase": "pilot64",
        "main_volume_n": None,
        "ruleset": "standard_2p_threefold",
        "planned_games": 64,
        "prefix_seed": 20261008,
        "attempts_per_prefix": 32,
        "depth": 3,
        "max_nodes": 100000,
        "tt_slots": 4096,
        "use_pvs": True,
        "solver_order_contact": False,
        "distance_a": 0.0,
        "distance_b": 8.0,
        "per_move_timeout_ms": None,
        "max_total_plies": 200,
        "cpu_core": 0,
        "output": OUTPUT,
    }
    for key, item in expected.items():
        actual = value.get(key, object())
        bad_type = (
            (isinstance(item, bool) and type(actual) is not bool)
            or (type(item) is int and type(actual) is not int)
            or (type(item) is float and type(actual) not in (int, float))
        )
        if actual != item or bad_type:
            raise ValueError("not the authorized pilot: " + key)
    if math.copysign(1, value["distance_a"]) != 1:
        raise ValueError("fixed positive-zero distance coefficient")
    if set(value) != set(expected) | {
        "run_id",
        "host_ram_reserve",
        "max_memory_bytes",
        "max_output_bytes",
    }:
        raise ValueError("unsupported pilot config fields")
    if (
        not isinstance(value["run_id"], str)
        or not value["run_id"]
        or any(
            not (letter.isascii() and (letter.isalnum() or letter in "-_."))
            for letter in value["run_id"]
        )
    ):
        raise ValueError("pilot identity")
    for key in ("host_ram_reserve", "max_memory_bytes", "max_output_bytes"):
        if type(value[key]) is not int or value[key] <= 0:
            raise ValueError("invalid pilot resource integer")
    if (
        value["host_ram_reserve"] < 4 * 1024**3
        or value["max_memory_bytes"] > 2 * 1024**3 - 64 * MIB
        or value["max_output_bytes"] > 1024**3
    ):
        raise ValueError("pilot resource profile")
    return value


def validate(admission, process_ports):
    # This precedes all input IO, decoding, fixture and canonical submission.
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared metadata is not entry")
    if admission["pending_obligations"]:
        raise ValueError("actual entry obligations remain")
    if admission["supported_whole_B"] != WHOLE or admission["phase"] != "pilot64":
        raise ValueError("unsupported whole phase/purpose")
    verify(admission["bindings"])
    path = admission["config"]
    if path not in admission["bindings"]:
        raise ValueError("unbound config")
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != admission["bindings"][path]["SHA256"]:
        raise ValueError("config changed between reads")
    value = config(raw)
    if Path(value["output"]).exists() or Path(admission["temporary"]).exists():
        raise ValueError("exclusive pilot output/TMP already exists")
    if 0 not in os.sched_getaffinity(0):
        raise ValueError("pilot core unavailable")
    if process_ports.available_memory() < value["host_ram_reserve"] + 2 * 1024**3:
        raise ValueError("physical family plus host reserve unavailable")
    fs = os.statvfs(Path(admission["temporary"]).parent)
    if fs.f_bavail * fs.f_frsize < WHOLE:
        raise ValueError("physical inclusive disk unavailable")
    return True
