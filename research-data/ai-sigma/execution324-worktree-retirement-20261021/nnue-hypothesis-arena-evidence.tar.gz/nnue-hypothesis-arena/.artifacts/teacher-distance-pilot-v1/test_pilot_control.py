"""Focused before-submit scope tests; no runtime/model/private/Popen calls."""

import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch

import pilot_control as C


class PilotScope(unittest.TestCase):
    def setUp(self):
        self.value = json.loads(
            Path(__file__).with_name("pilot-config.prepared.json").read_bytes()
        )

    def test_exact_pilot_scope_and_refuse_full_fit_games_before_submit(self):
        self.assertEqual(C.config(json.dumps(self.value)), self.value)
        for key, value in (
            ("phase", "full"),
            ("phase", "fit"),
            ("phase", "development96"),
            ("main_volume_n", 1000),
            ("planned_games", 96),
            ("per_move_timeout_ms", 100),
            ("solver_order_contact", True),
            ("ruleset", "rule_a"),
            ("max_total_plies", 201),
            ("tt_slots", 65536),
            ("distance_a", False),
            ("distance_a", -0.0),
            ("distance_b", "8"),
            ("max_memory_bytes", True),
        ):
            with self.subTest(key=key, value=value):
                changed = copy.deepcopy(self.value)
                changed[key] = value
                submit = unittest.mock.Mock()
                with self.assertRaises(ValueError):
                    C.config(json.dumps(changed))
                    submit()
                submit.assert_not_called()

    def test_prepared_refuses_before_any_input_io(self):
        with patch.object(C, "verify") as verify:
            with self.assertRaises(ValueError):
                C.validate({"actual_entry": False, "prepared_only": True}, None)
            verify.assert_not_called()


if __name__ == "__main__":
    unittest.main()
