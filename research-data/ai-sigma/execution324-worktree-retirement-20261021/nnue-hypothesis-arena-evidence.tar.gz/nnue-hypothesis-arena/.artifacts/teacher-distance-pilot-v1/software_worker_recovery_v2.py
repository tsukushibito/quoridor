"""One finite affected runner software batch, using maintained child ownership."""

from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

sys.path.insert(0, "/workspaces/quoridor/python")
from quoridor_training import cycle_process as P  # noqa: E402
from quoridor_training.snapshot import write_json  # noqa: E402

from pilot_control import WHOLE, digest, verify  # noqa: E402

ROOT = Path(__file__).resolve().parent
WT = ROOT.parents[1]
MIB = 1024**2
P.LOG_MAX_BYTES = 8 * MIB
LOCK = Path(
    "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
)


def quiet():
    forbidden = {
        "cargo",
        "rustc",
        "clippy-driver",
        "cargo-clippy",
        "perf",
        "quoridor-runner",
        "chrome",
        "chromium",
        "chrome-headless-shell",
    }
    markers = (
        "numeric-worker",
        "numeric_worker",
        "qualify.py",
        "train.py",
        "trainer.py",
        "matches-worker",
        "statistics.py",
        "finite-driver",
        "software_worker.py",
        "public-synthetic",
    )
    for entry in Path("/proc").iterdir():
        if not entry.name.isdecimal() or int(entry.name) == os.getpid():
            continue
        try:
            argv = [
                os.fsdecode(a)
                for a in (entry / "cmdline").read_bytes().split(b"\0")
                if a
            ]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not argv:
            continue
        if (
            Path(argv[0]).name in forbidden
            or Path(argv[0]).name.startswith(
                ("quoridor_runner-", "quoridor_ai-", "measure_native", "profile_native")
            )
            or (
                Path(argv[0]).name.startswith("python")
                and any(
                    Path(arg).name.startswith(markers)
                    or (Path(arg).name == "worker.py" and ".artifacts" in arg)
                    for arg in argv[1:]
                    if not arg.startswith("-")
                )
            )
        ):
            raise P.CycleStopped(
                "active named compiler/measurement/browser: " + entry.name
            )


def validate(admission):
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared software is not entry")
    if (
        admission["pending_obligations"]
        or admission["purpose"] != "fixed-D-pilot-software"
    ):
        raise ValueError("software entry obligations/purpose")
    if (
        admission["supported_whole_B"] != WHOLE
        or admission["main_volume_n"] is not None
    ):
        raise ValueError("unsupported phase/full N")
    required = {
        str(WT / name)
        for name in (
            "Cargo.lock",
            "crates/quoridor-runner/Cargo.toml",
            "crates/quoridor-runner/src/main.rs",
            "crates/quoridor-runner/src/lib.rs",
            "crates/quoridor-runner/src/teacher_pilot.rs",
            "crates/quoridor-runner/src/teacher_pilot_execution.rs",
            "crates/quoridor-core/src/research.rs",
            "crates/quoridor-core/src/position.rs",
            "crates/quoridor-ai/src/alphabeta.rs",
            "crates/quoridor-data/src/lib.rs",
            "crates/quoridor-data/src/terminal.rs",
        )
    } | {
        str(ROOT / "software_worker_recovery_v2.py"),
        str(ROOT / "software-output-v1/held-charges.json"),
        str(ROOT / "software-failed-STOP-v1.json"),
        str(WT / "configs/arena/smoke.json"),
        str(ROOT / "pilot_control.py"),
        admission["cargo"],
        admission["compiler_environment"]["RUSTC"],
        admission["config"],
        "/workspaces/quoridor/python/quoridor_training/__init__.py",
        "/workspaces/quoridor/python/quoridor_training/cycle_process.py",
        "/workspaces/quoridor/python/quoridor_training/snapshot.py",
        "/workspaces/quoridor/research-data/ai-sigma/teacher-distance-tanh-v1/resources-pilot.json",
        "/workspaces/quoridor/research-data/ai-sigma/execution-resources-20261008.json",
    }
    if not required.issubset(admission["bindings"]):
        raise ValueError("unbound required compiler/source/control dependency")
    expected_target = ROOT / "target-current99-v1"
    if admission["target"] != str(expected_target) or admission["private"] != str(
        ROOT / "private-pilot-current99-v2.gz"
    ):
        raise ValueError("not the exact declared OWN fresh output lease")
    if admission["compiler_environment"]["CARGO_TARGET_DIR"] != str(expected_target):
        raise ValueError("Cargo output lease/environment mismatch")
    expected_output = ROOT / "software-output-recovery-v2"
    if admission["output"] != str(expected_output) or expected_output.exists():
        raise ValueError("not the new exclusive command/receipt namespace")
    roots = {
        "target": [str(expected_target), 2 * 1024**3],
        "private": [str(ROOT / "private-pilot-current99-v2.gz"), 128 * MIB],
        "controls": [str(expected_output), 512 * MIB],
    }
    if (
        admission["owned_roots"] != roots
        or admission["compiler_environment"].get("RUSTUP_AUTO_INSTALL") != "0"
    ):
        raise ValueError("owned leases/caps/toolchain auto-install policy differ")
    verify(admission["bindings"])
    if Path(admission["private"]).exists():
        raise ValueError("new exclusive private namespace already exists")
    target = Path(admission["target"])
    if not target.is_dir() or target.is_symlink():
        raise ValueError("exact retained OWN target absent/unsupported")
    if admission["retained_charge_path"] != str(
        ROOT / "software-output-v1/held-charges.json"
    ) or admission["retained_outputs"] != [str(ROOT / "software-output-v1")]:
        raise ValueError("retained ledger/output scope differs")
    if not {0, 2}.issubset(os.sched_getaffinity(0)):
        raise ValueError("actual command CPUs unavailable")
    if P.available_memory() < 10 * 1024**3:
        raise ValueError("family6GiB plus host4GiB unavailable")
    fs = os.statvfs(ROOT)
    if fs.f_bavail * fs.f_frsize < WHOLE:
        raise ValueError("inclusive phase disk unavailable")
    quiet()
    return True


class Resources(P.CycleResources):
    def __init__(self, admission, output):
        super().__init__(
            {
                "host_ram_reserve": 4 * 1024**3,
                "max_memory_bytes": 6 * 1024**3 - 64 * MIB,
                "max_output_bytes": 512 * MIB,
            },
            output,
            None,
        )
        self.admission = admission
        self.attempts = []
        self.maxima = {}
        # Import immutable observations without reducing any previous per-path charge.
        verify(
            {
                admission["retained_charge_path"]: admission["bindings"][
                    admission["retained_charge_path"]
                ]
            }
        )
        raw = Path(admission["retained_charge_path"]).read_bytes()
        if (
            hashlib.sha256(raw).hexdigest()
            != admission["bindings"][admission["retained_charge_path"]]["SHA256"]
        ):
            raise ValueError("retained charge changed before parse")
        rows = json.loads(raw)
        allowed = {
            "target": [admission["target"]],
            "controls": admission["retained_outputs"],
        }
        for row in rows:
            component, name, charge = (
                row["component"],
                row["path"],
                row["max_observed_allocated_B"],
            )
            if (
                component not in allowed
                or type(charge) is not int
                or charge < 0
                or not any(
                    Path(name).is_relative_to(Path(root)) for root in allowed[component]
                )
            ):
                raise ValueError("foreign/malformed retained charge")
            key = (component, name)
            if key in self.maxima:
                raise ValueError("duplicate retained charge")
            self.maxima[key] = charge
        self.family_peak = 0
        self.next_storage_check = 0

    def check(self, owned=()):
        super().check(owned)
        rss = (
            sum(
                info["rss"]
                for pid in [os.getpid(), *(m["pid"] for m in owned)]
                if (info := P.process_info(pid))
            )
            + 64 * MIB
        )
        self.family_peak = max(self.family_peak, rss)
        if rss > 6 * 1024**3:
            raise P.CycleStopped("software family6GiB incl controller")
        if time.monotonic() < self.next_storage_check:
            return
        self.next_storage_check = time.monotonic() + 0.5
        # Only this job's new exclusive directories; each observed path stays charged.
        for component, (root, cap) in self.admission["owned_roots"].items():
            paths = [Path(root)]
            if component == "controls":
                paths.extend(Path(name) for name in self.admission["retained_outputs"])
            while paths:
                path = paths.pop()
                try:
                    info = path.lstat()
                except FileNotFoundError:
                    continue
                if stat.S_ISLNK(info.st_mode):
                    raise ValueError("symlink in owned software outputs")
                key = (component, str(path))
                self.maxima[key] = max(self.maxima.get(key, 0), info.st_blocks * 512)
                if stat.S_ISDIR(info.st_mode):
                    paths.extend(path.iterdir())
                elif not stat.S_ISREG(info.st_mode):
                    raise ValueError("unsupported owned output kind")
            held = sum(
                value for (kind, _), value in self.maxima.items() if kind == component
            )
            if held > cap:
                raise P.CycleStopped("held path allocations exceed " + component)


def execute(name, argv, resources, output, core):
    log = output / (name + ".log")
    attempt = {
        "name": name,
        "command": argv,
        "receipt": str(log.with_suffix(".process.json")),
    }
    if any(entry["receipt"] == attempt["receipt"] for entry in resources.attempts):
        raise ValueError("duplicate command receipt")
    resources.attempts.append(
        attempt
    )  # Even a refused execution has an attempted census.
    record = P.execute(argv, log, None, cpu_core=core, resources=resources)
    if (
        record.get("exit_code") != 0
        or record.get("direct_child_reaped") is not True
        or record.get("cleanup_complete") is not True
        or record.get("remaining")
        or record.get("command") != argv
    ):
        raise ValueError("command/direct wait/cleanup failed: " + name)
    if record["log_bytes_seen"] != record["log_bytes_retained"]:
        raise ValueError("qualification log truncated")
    return log


def artifacts(log, target):
    events = []
    for line in log.read_text().splitlines():
        if not line.startswith("{"):
            continue
        event = json.loads(line)
        if event.get("reason") != "compiler-artifact":
            continue
        observed = {}
        for filename in event.get("filenames", []) + (
            [event["executable"]] if event.get("executable") else []
        ):
            path = Path(filename)
            if not path.is_relative_to(target) or path.is_symlink():
                raise ValueError("compiler output outside exact OWN target lease")
            info = path.stat()
            if not stat.S_ISREG(info.st_mode):
                raise ValueError("compiler output not regular")
            observed[filename] = {
                "SHA256": digest(path),
                "bytes": info.st_size,
                "mode": stat.S_IMODE(info.st_mode),
                "allocated_B": info.st_blocks * 512,
            }
        event["observed_outputs"] = observed
        events.append(event)
    return events


def finalize(result, primary, resources, output):
    errors, receipts, remaining = [], [], []

    def attempt(stage, action):
        try:
            return action()
        except BaseException as error:
            errors.append(
                {"stage": stage, "type": type(error).__name__, "message": str(error)}
            )
            return None

    attempt("final_resources", resources.check)
    unknown = False
    for tried in resources.attempts:
        receipt = attempt(
            "receipt:" + tried["name"],
            lambda tried=tried: json.loads(Path(tried["receipt"]).read_bytes()),
        )
        verified = bool(
            receipt
            and receipt.get("command") == tried["command"]
            and receipt.get("direct_child_reaped") is True
            and receipt.get("cleanup_complete") is True
            and receipt.get("remaining") == []
        )
        unknown |= not verified
        receipts.append(
            {"attempt": tried, "receipt": receipt, "cleanup_verified": verified}
        )
        if receipt:
            remaining.extend(receipt.get("remaining", []))
    result.update(
        primary_error=None
        if primary is None
        else {"type": type(primary).__name__, "message": str(primary)},
        stage_failures=errors,
        attempted_children=resources.attempts,
        receipts=receipts,
        cleanup_unknown=unknown,
        cleanup_complete=not unknown and not remaining,
        remaining=remaining,
        family_RSS_sample_peak_B=resources.family_peak,
        continuous_peak="UNKNOWN",
        source_STOP=datetime.now(timezone.utc).isoformat(),
    )
    charges = [
        {"component": kind, "path": path, "max_observed_allocated_B": value}
        for (kind, path), value in sorted(resources.maxima.items())
    ]
    attempt("held_charges", lambda: write_json(output / "held-charges.json", charges))
    result["qualified"] = (
        primary is None and not errors and not unknown and len(receipts) == 4
    )
    attempt("result", lambda: write_json(output / "software-result.json", result))
    if errors:
        result["qualified"] = False
        print(json.dumps({"terminal_failure_facts": result}), flush=True)
    if primary is not None:
        raise primary
    if errors or unknown or not result["qualified"]:
        raise RuntimeError("software qualification incomplete: " + json.dumps(result))


def main():
    path = Path(sys.argv[1])
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != sys.argv[2]:
        raise ValueError("admission immutable digest")
    admission = json.loads(raw)
    if validate(admission) is not True:
        raise ValueError("software preflight did not return exactlyTrue")
    output = Path(admission["output"])
    output.mkdir()  # New finite attempt namespace only.
    resources = Resources(admission, output)
    result, primary = (
        {
            "qualified": False,
            "scope": "new generator6 tests/release/scopedClippy/config; label7 supplied separately",
        },
        None,
    )
    try:
        with LOCK.open("a+b") as lock, P.cancellation_signals():
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            quiet()
            verify(admission["bindings"])
            os.chdir(WT)
            for key in admission["unset_environment"]:
                os.environ.pop(key, None)
            os.environ.update(admission["compiler_environment"])
            cargo = admission["cargo"]
            common = [
                cargo,
                "--offline",
                "--locked",
                "-j1",
                "--release",
                "-p",
                "quoridor-runner",
            ]
            tests = execute(
                "generator-tests",
                [
                    cargo,
                    "test",
                    *common[1:],
                    "--lib",
                    "teacher_pilot",
                    "--message-format=json",
                    "--",
                    "--nocapture",
                ],
                resources,
                output,
                2,
            )
            if "test result: ok. 6 passed;" not in tests.read_text():
                raise ValueError("exact six changed runner tests not PASS")
            build = execute(
                "runner-release",
                [
                    cargo,
                    "build",
                    *common[1:],
                    "--bin",
                    "quoridor-runner",
                    "--message-format=json",
                ],
                resources,
                output,
                2,
            )
            entries = artifacts(build, Path(admission["target"]))
            binaries = [
                row["executable"]
                for row in entries
                if row.get("executable")
                and row["target"]["name"] == "quoridor-runner"
                and row["profile"]["test"] is False
            ]
            if len(binaries) != 1:
                raise ValueError("exact runner artifact absent/ambiguous")
            binary = Path(binaries[0])
            result.update(
                compiler_artifacts=entries,
                executable={
                    "path": str(binary),
                    "SHA256": digest(binary),
                    "bytes": binary.stat().st_size,
                    "mode": stat.S_IMODE(binary.stat().st_mode),
                },
            )
            if any(
                row["target"]["src_path"]
                != str(WT / "crates/quoridor-runner/src/main.rs")
                or row["profile"]["opt_level"] != "3"
                for row in entries
                if row.get("executable") == str(binary)
            ):
                raise ValueError("compiled production source/profile differs")
            execute(
                "scoped-clippy",
                [
                    cargo,
                    "clippy",
                    *common[1:],
                    "--lib",
                    "--bin",
                    "quoridor-runner",
                    "--no-deps",
                    "--",
                    "-Dwarnings",
                ],
                resources,
                output,
                2,
            )
            execute(
                "config-inlet",
                [
                    str(binary),
                    "teacher-pilot",
                    "--config",
                    admission["config"],
                    "--check-config",
                ],
                resources,
                output,
                0,
            )
            private = Path(admission["private"])
            with (
                private.open("xb") as destination,
                gzip.GzipFile(fileobj=destination, mode="wb", mtime=0) as packed,
                binary.open("rb") as source,
            ):
                while chunk := source.read(MIB):
                    packed.write(chunk)
            result["packed_private"] = {
                "path": str(private),
                "SHA256": digest(private),
                "bytes": private.stat().st_size,
            }
            final_outputs = {}
            for event in entries:
                for name in event["observed_outputs"]:
                    path = Path(name)
                    info = path.lstat()
                    if not stat.S_ISREG(info.st_mode):
                        raise ValueError(
                            "final named artifact absent/unsupported; allocation held UNKNOWN"
                        )
                    final_outputs[name] = {
                        "SHA256": digest(path),
                        "bytes": info.st_size,
                        "mode": stat.S_IMODE(info.st_mode),
                        "allocated_B": info.st_blocks * 512,
                    }
            result["final_named_outputs"] = final_outputs
            verify(admission["bindings"])
    except BaseException as error:
        primary = error
    finalize(result, primary, resources, output)


if __name__ == "__main__":
    main()
