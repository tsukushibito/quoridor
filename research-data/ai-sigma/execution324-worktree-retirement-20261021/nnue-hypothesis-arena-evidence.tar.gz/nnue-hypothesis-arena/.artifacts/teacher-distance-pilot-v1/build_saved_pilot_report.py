"""Summarize one immutable pilot stream; never invoke search or generation."""

from collections import Counter
from datetime import datetime, timezone
import csv
import difflib
import fcntl
import gzip
import hashlib
import io
import json
from pathlib import Path
import resource
import time

import pilot_worker_v5 as W

ROOT = Path(__file__).resolve().parent
WT = ROOT.parents[1]
OUT = ROOT / "final-report-v1"
RAW = Path(
    "/workspaces/quoridor/.worktree/assets/data/nnue-teacher-distance-tanh-v1/pilot-64/pilot-stream.jsonl"
)
RAW_SHA = "208afa5d50090e8f2e9771f01cdd61fdee9f7908e445237d23cf4e554b5595af"
STOP_SHA = "d335315417fafa854228b49c7b172e29ce132a78b58ffb1fc97ea1b9c83f62db"
UPPER = 262144


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def binding(path):
    s = path.stat()
    return {
        "SHA256": sha(path.read_bytes()),
        "mode": s.st_mode & 0o777,
        "bytes": s.st_size,
        "allocated_B": s.st_blocks * 512,
    }


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def main():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2,) * 2)
    begin = time.monotonic()
    W.quiet()
    lock = W.S.LOCK.open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        W.quiet()
        assert not OUT.exists(), "new report namespace required"
        stop_bytes = (ROOT / "pilot-qualified-STOP-v5.json").read_bytes()
        assert sha(stop_bytes) == STOP_SHA
        stop = json.loads(stop_bytes)
        report = stop["report"]
        raw_binding = binding(RAW)
        assert raw_binding["SHA256"] == RAW_SHA
        game_rows, games = [], []
        split_rows, row_z, row_margin, winners = (Counter() for _ in range(4))
        header = footer = requests = None
        with RAW.open() as stream:
            for line in stream:
                event = json.loads(line)
                kind = event["type"]
                if kind == "requests":
                    assert requests is None
                    requests = event
                elif kind == "header":
                    assert header is None
                    header = event["record"]
                elif kind == "game":
                    game = event["record"]
                    games.append(game["game"])
                    rows = game["rows"]
                    provenance = game["provenance"]
                    winners[str(provenance["winner"])] += 1
                    splits = set()
                    for row in rows:
                        teacher = row["teacher"]
                        split = teacher["split"]
                        splits.add(split)
                        split_rows[split] += 1
                        targets = teacher["terminal_targets"]
                        row_z[str(targets["outcome_z"])] += 1
                        row_margin[str(targets["margin_target_steps"])] += 1
                    assert len(splits) == 1
                    game_rows.append(
                        {
                            "game": game["game"],
                            "request_id": game["request_id"],
                            "family": game["family"],
                            "split": next(iter(splits)),
                            "prefix_length": len(game["initial_prefix"]),
                            "final_ply": game["final_context"]["ply"],
                            "winner_absolute": provenance["winner"],
                            "termination": provenance["reason"],
                            "rows": len(rows),
                            "attempted_search_calls": game["attempted_search_calls"],
                            "wall_ns": game["wall_ns"],
                        }
                    )
                elif kind == "footer":
                    assert footer is None
                    footer = event["record"]
                else:
                    raise ValueError("unexpected stream event")
        assert requests["planned"] == 64 and games == list(range(64))
        assert header["executable_sha256"] == stop["critical_private_body"]["SHA256"]
        assert footer == report
        assert sum(split_rows.values()) == report["rows"] == 2798
        assert Counter(g["prefix_length"] for g in game_rows) == Counter(
            {n: 4 for n in range(4, 20)}
        )
        assignments = header["family_partition"]["assignments"]
        assignment_by_game = {a["game"]: a for a in assignments}
        assert len(assignment_by_game) == 64
        for game in game_rows:
            assignment = assignment_by_game[game["request_id"]]
            assert game["family"] == assignment["family"]
            assert game["split"] == assignment["split"]
        scheduled = header["scheduled"]
        attempts = sum(len(s["attempts"]) for s in scheduled)
        rejected = Counter(
            a["rejection"]
            for s in scheduled
            for a in s["attempts"]
            if a["rejection"] is not None
        )
        family_split = {}
        for a in assignments:
            previous = family_split.setdefault(a["family"], a["split"])
            assert previous == a["split"]
        assert binding(RAW) == raw_binding
        OUT.mkdir()
        csv_text = io.StringIO()
        writer = csv.DictWriter(csv_text, fieldnames=list(game_rows[0]))
        writer.writeheader()
        writer.writerows(game_rows)
        (OUT / "games.csv").write_text(csv_text.getvalue())
        native_seconds = report["native_whole_ns"] / 1e9
        controller_seconds = stop["controller_whole_seconds"]
        summary = {
            "scope": "saved metadata/count arithmetic only; no canonical replay or model call",
            "job": stop["job"],
            "raw": {"path": str(RAW), **raw_binding},
            "verified_native_and_audit_report": report,
            "prefix_attempts": attempts,
            "prefix_rejections": dict(rejected),
            "scheduled_failures": sum(
                s["scheduled_failure"] is not None for s in scheduled
            ),
            "unique_families": len(family_split),
            "family_split_counts": dict(Counter(family_split.values())),
            "game_split_counts": dict(Counter(g["split"] for g in game_rows)),
            "row_split_counts": dict(split_rows),
            "winner_absolute_counts": dict(winners),
            "row_outcome_target_counts": dict(row_z),
            "row_margin_target_counts": dict(row_margin),
            "final_ply_min_max": [
                min(g["final_ply"] for g in game_rows),
                max(g["final_ply"] for g in game_rows),
            ],
            "observed_native_games_per_second": 64 / native_seconds,
            "observed_native_rows_per_second": 2798 / native_seconds,
            "observed_whole_with_audit_games_per_second": 64 / controller_seconds,
            "observed_raw_bytes_per_scheduled_game": raw_binding["bytes"] / 64,
            "observed_rows_per_scheduled_game": 2798 / 64,
            "sample_family_B": stop["sampled_family_B"],
            "continuous_peak": "UNKNOWN",
            "known_software_plus_pilot_controller_seconds": stop[
                "known_software_plus_pilot_controller_seconds"
            ],
            "N": None,
        }
        save("summary.json", summary)
        options = []
        for n in (640, 6400, 64000):
            raw_estimate = (raw_binding["bytes"] * n + 63) // 64
            options.append(
                {
                    "proposed_scheduled_games": n,
                    "selected": False,
                    "projected_rows": 2798 * n / 64,
                    "projected_native_seconds": native_seconds * n / 64,
                    "projected_generation_plus_audit_controller_seconds": controller_seconds
                    * n
                    / 64,
                    "projected_raw_bytes": raw_estimate,
                    "projection_above_current_1GiB_raw_component_B": max(
                        0, raw_estimate - 1024**3
                    ),
                }
            )
        pricing = {
            "N": None,
            "options": options,
            "unit": "scheduled games, proposed for human decision only",
            "basis": "linear empirical pilot ratios, not a minimum, finite upper, accuracy certificate, or launch admission",
            "whole_cost_formula": "retained source/build/private/raw/failures + future generation + audit + cache/conversion + four fits + six-view native qualification + 96-slot evaluation + TMP/review/Git/cleanup",
            "retained_whole_phase_component_uppers_B": {
                "source": 134217728,
                "build_dependencies": 2147483648,
                "private": 134217728,
                "pilot_raw": 1073741824,
                "TMP": 268435456,
                "control_review_Git_failure_cleanup": 536870912,
            },
            "unpriced": [
                "four fits/epochs/updates until N and complete recipe are fixed",
                "training cache/conversion and model payload growth",
                "six-view native qualification and 96-slot outputs/work",
                "new prefix seed/length schedule for a proposed full volume",
                "nonlinear game lengths, failed prefix attempts, UNKNOWN and IO/resource failures",
            ],
            "future_whole_forecast": "NOT_ADMITTED; actual inclusive bounds required after human N and before any full-generation/fit/96 Popen",
            "old_caps_assets_maxima_failed_fees_UNKNOWN": "held unchanged; no subtraction or cache credit",
        }
        save("volume-options.json", pricing)
        lines = [
            "# Fixed-D 64-game pilot report",
            "",
            "All 64 scheduled games finished by goal; draw0 and UNKNOWN0. The canonical saved-only audit returned the same report. There are 2,798 eligible rows, 2,798 distinct positions and no position duplicates. This is an implementation/coverage pilot, not a strength or statistical-sufficiency result.",
            "",
            f"Prefix scheduling retained {attempts} candidate attempts and {sum(rejected.values())} rejected candidates. Four accepted new prefixes occur at each length4..19; seed20261008. No evaluation-book, colour-copy or replacement game was used. The input-only family partition has {len(family_split)} families: games {dict(Counter(g['split'] for g in game_rows))}, rows {dict(split_rows)}. Exact LR and prefix-series grouping is supplied by the frozen data API before outcomes.",
            "",
            "Both sides used unchanged D(a0,b8), depth3, node100000, PVS, TT4096 and no move timeout; solver/order/contact OFF. All2,798 accepted calls achieved depth3, with6,167,917 nodes. Goal-first/legal-third canonical rules apply. The pilot contains no actual draw or UNKNOWN rows; those label/error boundaries are qualified by the separate seven label and affected runner tests, not by invented pilot coverage.",
            "",
            "Coverage: contact84; opening(ply<20)544; endgame(min integer wall distance<=2)256. Wall-stock pair frequencies are retained in summary.json; bins overlap and are not a balanced sampling claim. Full chronology, side-to-move, actual search evidence, original z and both terminal teachers remain in the single authoritative JSONL.",
            "",
            f"Native generation whole {native_seconds:.9f}s; audited controller whole {controller_seconds:.9f}s, including setup/generation/serialization/audit/cleanup. Observed native throughput {64 / native_seconds:.3f} games/s and {2798 / native_seconds:.3f} rows/s. Raw {raw_binding['bytes']}B (allocated{raw_binding['allocated_B']}B). Known software-plus-pilot controller fees {stop['known_software_plus_pilot_controller_seconds']:.9f}s include prior failed software; nested spans are not added. Other historical/control costs and unmeasured peaks remain held/UNKNOWN.",
            "",
            "| Proposed scheduled games | Projected rows | Native seconds | Generation+audit seconds | Raw bytes |",
            "| ---: | ---: | ---: | ---: | ---: |",
        ]
        for option in options:
            lines.append(
                f"| {option['proposed_scheduled_games']} | {option['projected_rows']:.0f} | {option['projected_native_seconds']:.3f} | {option['projected_generation_plus_audit_controller_seconds']:.3f} | {option['projected_raw_bytes']} |"
            )
        lines.extend(
            [
                "",
                "These are illustrative, unselected scheduled-game quantities and linear projections, not bounds or recommendations. The current raw component is1GiB; the larger projections require new supported component/whole forecasts. Four-fit/cache/model/six-view/96-slot costs remain unpriced until N and the complete recipe are fixed. No whole future phase is admitted by this table. N remains null; human N choice is the next scientific decision. Full generation, four fits and96 slots have not started.",
                "",
                f"Actual job {stop['job']}: START{stop['actualSTART']}, workerSTOP{stop['workerSTOP']}, controllerSTOP{stop['controllerSTOP']}. Both exact children directly waited/reaped; process/handle cleanup remaining[]. Persisted signal-mask restoration pending and final-record attempted are preserved separately; filesystem/fault-finalization guarantees are not claimed. Sampled family126,447,616B; continuous peak UNKNOWN. Current Cargo/model/pilot/fair reservation NONE.",
                "",
                f"Private3f884650 / packed255b3fae, current runner execution d43f303d, canonical coreb789/alphafb6323 and minimal data terminalc370/lib6bbed are immutable used bindings. Main's later clock/data/opt-in work is not retroactively substituted. Pilot raw SHA256 `{RAW_SHA}`. Source/software/label/source-review proofs and all failed jobs/old fees/UNKNOWN stay retained. Main/Git/index integration belongs to324; defaults/seals/323USERPAUSE unchanged.",
                "",
            ]
        )
        (OUT / "report.md").write_text("\n".join(lines))
        # Exact four-path source handoff, no Git/index operation or source mirror.
        map_records = {}
        patch = []
        for rel, old_name in (
            ("crates/quoridor-runner/src/lib.rs", "lib.rs.before.gz"),
            ("crates/quoridor-runner/src/main.rs", "main.rs.before.gz"),
            ("crates/quoridor-runner/src/teacher_pilot.rs", None),
            ("crates/quoridor-runner/src/teacher_pilot_execution.rs", None),
        ):
            path = WT / rel
            old_path = ROOT / old_name if old_name else None
            old = gzip.decompress(old_path.read_bytes()) if old_path else b""
            current = path.read_bytes()
            map_records[rel] = {
                "before": {"SHA256": sha(old), "bytes": len(old), "mode": 420}
                if old_path
                else None,
                "after": binding(path),
                "before_archive": str(old_path) if old_path else None,
            }
            patch.extend(
                difflib.unified_diff(
                    old.decode().splitlines(True),
                    current.decode().splitlines(True),
                    fromfile="a/" + rel if old_path else "/dev/null",
                    tofile="b/" + rel,
                )
            )
        (OUT / "runner-source-final.patch").write_text("".join(patch))
        save(
            "runner-source-map-final.json",
            {
                "paths": map_records,
                "integration_owner": "sole324",
                "source_only": True,
                "used_software": str(ROOT / "software-qualified-STOP-census-v5.json"),
                "raw_and_old_jobs": "immutable",
            },
        )
        assert binding(RAW) == raw_binding
        save(
            "collection-control.json",
            {
                "begin_monotonic": begin,
                "end_monotonic": time.monotonic(),
                "wall_seconds": time.monotonic() - begin,
                "own_ru_maxrss_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                "family_peak": "UNKNOWN",
                "guard": "fresh W.quiet before and after nonblocking canonical lock, saved-only parsing",
                "native_model_geometry_calls": 0,
                "raw_before_after": raw_binding,
                "prewrite_upper_B": UPPER,
                "old_failures_fees_UNKNOWN": "held",
                "current_next": "NONE",
                "readerSTOP": datetime.now(timezone.utc).isoformat(),
            },
        )
        inclusive = (
            sum(p.stat().st_blocks * 512 for p in OUT.iterdir())
            + OUT.stat().st_blocks * 512
        )
        assert inclusive <= UPPER, (inclusive, UPPER)
        print(
            json.dumps(
                {"output": str(OUT), "summary": summary, "new_allocated_B": inclusive}
            )
        )
    finally:
        lock.close()


if __name__ == "__main__":
    main()
