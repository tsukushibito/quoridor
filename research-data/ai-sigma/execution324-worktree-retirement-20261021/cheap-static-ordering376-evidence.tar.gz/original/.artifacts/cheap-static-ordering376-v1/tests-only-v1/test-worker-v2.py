"""Exactly two affected Cargo filters through the maintained tests-only software port."""

import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess

HERE = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
module_spec = importlib.util.spec_from_file_location(
    "guard376", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(lc)


def check_refs(settings, refs):
    for ref in refs:
        lc.read_ref(ref, max(lc.CONTROL_BYTES, ref["bytes"]))
    for path in settings["optional_cargo_configs_absent"]:
        lc.require(not os.path.lexists(path), "optional Cargo configuration appeared: " + path)
    for tool in settings["tools"]:
        p = Path(tool["path"])
        info = p.stat()
        actual = dict(
            resolved=str(p.resolve()),
            device=info.st_dev,
            inode=info.st_ino,
            bytes=info.st_size,
            mode=format(stat.S_IMODE(info.st_mode), "04o"),
            mtime_ns=info.st_mtime_ns,
        )
        lc.require(
            all(tool[k] == v for k, v in actual.items()), "tool metadata drift: " + tool["name"]
        )


class TestResources(lc.process.CycleResources):
    """Existing family resources plus this handed target, owned controls and serial TMP."""

    def __init__(self, settings):
        self.settings = settings
        super().__init__(
            {
                "host_ram_reserve": settings["host_reserve_B"],
                "max_memory_bytes": settings["family_B"] - settings["controller_B"],
                "max_output_bytes": settings["controls_B"],
            },
            HERE / "operation",
            None,
        )

    def check(self, owned=()):
        super().check(owned)
        s = self.settings
        tmp = lc.allocated(HERE / "TMP")
        lc.require(tmp <= s["TMP_B"], "serial TMP allocation cap")
        lc.require(lc.allocated(HERE) - tmp <= s["controls_B"], "inclusive controls/captures cap")
        lc.require(shutil.disk_usage(HERE).free >= s["FS_reserve_B"], "FS reserve")
        lc.require(lc.allocated(s["target"]) <= s["target_max_B"], "actual target cap")
        marker = json.loads((Path(s["target"]) / ".research-owner.json").read_bytes())
        lc.require(marker == self.marker, "actual target writer/support marker drift")


def current_guard(settings, refs, affinity):
    check_refs(settings, refs)
    os.sched_setaffinity(0, affinity)
    lc.physical_and_quiet(
        {
            "limits": {
                k: settings[k] for k in ("family_B", "host_reserve_B", "worker_cpu", "guardian_cpu")
            }
        }
    )


def target_custody(settings):
    h = lc.document(settings["handover"])
    lc.require(
        h["target_writer"] == settings["owner"]
        and h["target"] == settings["target"]
        and h["target_max_B"] == settings["target_max_B"]
        and h["support"]["sha256"] == settings["support"]["sha256"],
        "actual tests-only handover",
    )
    lc.require(not os.path.lexists(settings["old_target"]), "old serial target present")
    marker = json.loads((Path(settings["target"]) / ".research-owner.json").read_bytes())
    lc.require(marker == h["after_owner_marker"], "handed target marker")
    observed = lc.allocated(settings["target"])
    lc.require(
        max(observed, settings["target_retained_floor_B"]) <= settings["target_max_B"],
        "retained/actual target cap",
    )
    return marker, observed


def census(path, row):
    data = path.read_bytes()
    lc.cargo_report(data)
    text = data.decode("utf-8", errors="strict")
    names = re.findall(r"^test ([^\s]+) \.\.\. ok$", text, re.MULTILINE)
    count = row["expected_passed_count"]
    lc.require(
        sorted(names) == sorted(row["expected_libtest_names"]) and len(names) == count,
        "actual selected test names/count incomplete or extra",
    )
    lc.require(
        re.findall(r"^running (\d+) tests?$", text, re.MULTILINE) == [str(count)],
        "actual native test selection",
    )
    summaries = re.findall(
        r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; "
        r"(\d+) measured; (\d+) filtered out;",
        text,
        re.MULTILINE,
    )
    lc.require(
        len(summaries) == 1 and summaries[0][:4] == (str(count), "0", "0", "0"),
        "complete actual libtest result required",
    )
    return {
        "actual_names": names,
        "passed": count,
        "failed": 0,
        "ignored": 0,
        "measured": 0,
        "filtered_out": int(summaries[0][4]),
        "full_log": lc.bound(path)[0],
    }


def clean_tmp(tmp):
    # Only the generated exclusive TMP namespace is eligible for removal.
    if os.path.lexists(tmp):
        lc.allocated(tmp)  # Refuse symlinks before cleanup; preserve the actual failure.
        shutil.rmtree(tmp)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--settings-sha256", required=True)
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    settings_ref, settings_data = lc.bound(HERE / "settings.json")
    lc.require(settings_ref["sha256"] == args.settings_sha256, "frozen settings SHA")
    settings = json.loads(settings_data)
    refs = [*settings["refs"], settings_ref, lc.bound(Path(__file__))[0]]
    affinity = os.sched_getaffinity(0)
    report = {
        "issue": settings["issue"],
        "kind": "TESTS_ONLY_SOFTWARE",
        "status": "FAILED",
        "primary": None,
        "secondary": [],
        "checks": [],
        "assertion_census": [],
        "started_at": lc.stamp(),
        "model_real_heads": 0,
        "private_growth_B": 0,
        "source_env_reader_STOP": None,
        "owned_readers_children_jobs_TMP_remaining": {},
        "continuous_peak_RSS": "UNKNOWN",
        "outer_controller": "separate completion authority",
    }
    primary = None
    tmp_created = False
    resources = None
    try:
        current_guard(settings, refs, affinity)
        with (
            lc.lease(),
            lc.process.cancellation_signals(),
            Path(settings["env_lock"]).open("r") as env_reader,
        ):
            fcntl.flock(env_reader, fcntl.LOCK_SH | fcntl.LOCK_NB)
            try:
                current_guard(settings, refs, affinity)
                marker, observed = target_custody(settings)
                resources = TestResources(settings)
                resources.marker = marker
                resources.check()
                report["actual_target_before_B"] = observed
                report["target_historical_floor_B"] = settings["target_retained_floor_B"]
                report["settings"] = settings_ref
                revision = subprocess.run(
                    ["git", "-C", str(MAIN), "rev-parse", "HEAD"],
                    capture_output=True,
                    check=True,
                    timeout=20,
                )
                delta = subprocess.run(
                    [
                        "git",
                        "-C",
                        str(MAIN),
                        "diff",
                        "--no-ext-diff",
                        "--",
                        *[r["path"] for r in refs if r["path"].startswith(str(MAIN / "crates"))],
                    ],
                    capture_output=True,
                    check=True,
                    timeout=20,
                )
                lc.require(len(delta.stdout) <= 65536, "bounded affected Git delta")
                report["actual_Git_revision"] = revision.stdout.decode().strip()
                report["affected_Git_delta"] = delta.stdout.decode()
                report["tools_metadata"] = settings["tools"]
                report["source_before"] = refs
                lc.require(not os.path.lexists(HERE / "TMP"), "exclusive owned TMP already exists")
                if args.preflight:
                    report["status"] = "PREFLIGHT_PASS_NO_CHILD_NO_TMP_NO_PRIVATE"
                else:
                    lc.require(
                        not os.path.lexists(HERE / "operation"),
                        "exclusive operation already exists",
                    )
                    (HERE / "operation").mkdir()
                    (HERE / "TMP").mkdir()
                    tmp_created = True
                    lc.process.LOG_MAX_BYTES = settings["tail_B"]
                    spec = {
                        "kind": "run",
                        "cwd": settings["cwd"],
                        "env": settings["env"],
                        "limits": {
                            "worker_cpu": settings["worker_cpu"],
                            "log_B": settings["full_capture_B"],
                        },
                    }
                    for row in settings["commands"]:
                        current_guard(settings, refs, affinity)
                        resources.check()
                        try:
                            lc.command(
                                spec, row, HERE / "operation", resources, ledger=report["checks"]
                            )
                        finally:
                            check_refs(settings, refs)
                        report["assertion_census"].append(
                            census(HERE / "operation" / (row["name"] + ".full.log"), row)
                        )
                    lc.require(
                        sum(x["passed"] for x in report["assertion_census"]) == 9,
                        "actual nine assertions",
                    )
                    report["status"] = "FIVE_AI_FOUR_RUNNER_ASSERTIONS_PASS"
            except BaseException as error:
                primary = error
                report["primary"] = lc.error_fact(error)
            finally:
                if tmp_created:
                    try:
                        report["TMP_after_commands_allocated_B"] = lc.allocated(HERE / "TMP")
                        clean_tmp(HERE / "TMP")
                    except BaseException as error:
                        report["secondary"].append(
                            {"stage": "owned_TMP_cleanup", **lc.error_fact(error)}
                        )
                        if primary is None:
                            primary = error
                            report["primary"] = lc.error_fact(error)
                report["source_after"] = []
                for ref in refs:
                    try:
                        actual, _ = lc.bound(ref["path"], max(lc.CONTROL_BYTES, ref["bytes"]))
                        report["source_after"].append(actual)
                        lc.require(actual == ref, "source/environment/control drift")
                    except BaseException as error:
                        report["secondary"].append({"stage": "after_ref", **lc.error_fact(error)})
                        if primary is None:
                            primary = error
                            report["primary"] = lc.error_fact(error)
                if resources:
                    try:
                        resources.check()
                        report["actual_target_after_B"] = lc.allocated(settings["target"])
                    except BaseException as error:
                        report["secondary"].append(
                            {"stage": "final_resource_check", **lc.error_fact(error)}
                        )
                        if primary is None:
                            primary = error
                            report["primary"] = lc.error_fact(error)
                report["source_env_reader_STOP"] = lc.stamp()
    except BaseException as error:
        if primary is None:
            primary = error
            report["primary"] = lc.error_fact(error)
        else:
            report["secondary"].append({"stage": "outer_guard_or_release", **lc.error_fact(error)})
    finally:
        if primary:
            report["status"] = "FAILED"
        remaining = [str(HERE / "TMP")] if os.path.lexists(HERE / "TMP") else []
        checks = report["checks"]
        report["persisted_only_receipts"] = []
        report["owned_exact_identity_observations"] = []
        child_remaining = []
        for check in checks:
            record = check.get("guardian_return")
            if record is None and check.get("persisted_process_receipt"):
                record = lc.document(check["persisted_process_receipt"])
                report["persisted_only_receipts"].append({"check": check["name"], "record": record})
            if record is None:
                child_remaining.append(
                    {"check": check["name"], "state": "UNKNOWN_no_return_or_receipt"}
                )
                continue
            identities = [*record.get("remaining", [])]
            if record.get("child") and record["child"] not in identities:
                identities.append(record["child"])
            for member in identities:
                observed = {
                    "check": check["name"],
                    "identity": member,
                    "alive": lc.process.alive(member),
                }
                report["owned_exact_identity_observations"].append(observed)
                if observed["alive"]:
                    child_remaining.append(member)
        report["owned_readers_children_jobs_TMP_remaining"] = {
            "readers": [],
            "children": child_remaining,
            "jobs": [],
            "TMP": remaining,
        }
        report["leases_released_before_metadata_STOP"] = True
        report["finished_at"] = lc.stamp()
        report["scope"] = settings["assertion_scope"]
        name = "preflight-v2.json" if args.preflight else "test-STOP.json"
        lc.new_json(HERE / name, report)
        print(
            json.dumps(
                {
                    "status": report["status"],
                    "report": str(HERE / name),
                    "primary": report["primary"],
                }
            )
        )
    if primary:
        raise primary


if __name__ == "__main__":
    main()
