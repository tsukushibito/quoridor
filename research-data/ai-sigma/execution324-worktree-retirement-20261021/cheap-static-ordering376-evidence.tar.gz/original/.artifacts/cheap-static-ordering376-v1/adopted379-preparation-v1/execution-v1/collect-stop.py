"""Collect one normal finalized original entry and remove its empty owned TMP."""

import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("intent", type=Path)
    args = parser.parse_args()
    spec = json.loads(args.intent.read_bytes())
    source = spec["caller_sources"][0]
    raw = Path(source["path"]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != source["sha256"] or len(raw) != source["bytes"]:
        raise ValueError("lifecycle source drift before collection import")
    module_spec = importlib.util.spec_from_file_location("lc376_stop", source["path"])
    lc = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(lc)
    directory = Path(spec["output"]).parent
    affinity = os.sched_getaffinity(0)
    try:
        lc.physical_and_quiet(spec)
        with (
            lc.lease(),
            Path("/home/vscode/.cache/inference/envs/quoridor-training.setup.lock").open(
                "rb"
            ) as env_lock,
        ):
            fcntl.flock(env_lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
            lc.Limits(spec).check()
            manifest_ref, manifest_raw = lc.bound(Path(spec["output"]) / "manifest.json")
            manifest = json.loads(manifest_raw)
            lc.require(
                manifest["status"] == "PASS"
                and manifest["primary"] is None
                and manifest["secondary"] == []
                and manifest["cleanup_complete"] is True
                and manifest["remaining"] == [],
                "actual finalized original entry incomplete",
            )
            lc.require(
                not (Path(spec["output"]) / "INCOMPLETE").exists()
                and not (Path(spec["data_root"]) / "INCOMPLETE").exists(),
                "original incomplete marker remains",
            )
            check = manifest["checks"][0]
            full = lc.read_ref(check["full_log"], spec["limits"]["log_B"])
            returned = check["guardian_return"]
            lc.require(
                check["capture_complete"] is True
                and len(full) == returned["log_bytes_seen"]
                and returned["direct_child_reaped"] is True,
                "full capture/directwait incomplete",
            )
            files = {Path(ref["path"]).name: ref for ref in manifest["data"]["files"]}
            data = {name: lc.read_ref(ref, 3 * 1024**2) for name, ref in files.items()}
            receipt = json.loads(data["result.json"])
            rows = [json.loads(row) for row in data["observations.jsonl"].splitlines()]
            costs = [json.loads(row) for row in data["costs.jsonl"].splitlines()]
            lc.require(
                len(rows) == len(costs) == receipt["attempted"] == 20
                and receipt["planned_sessions"] == receipt["session_setup_Ok"] == 14
                and receipt["actual_Search_invocations"] == 20
                and receipt["durably_published_complete_rows"] == 20,
                "original process planned/attempted/session census",
            )
            state_ref, state_raw = lc.bound(directory / "runtime-v1/state.json")
            state = json.loads(state_raw)
            identities = {
                "native": returned["child"],
                "lifecycle": state["child"],
                "notifier_supervisor": state["supervisor"],
            }
            live = {name: lc.process.alive(member) for name, member in identities.items()}
            lc.require(not live["native"] and not live["lifecycle"], "original reader still live")
            tmp = Path(spec["TMP"])
            removed = []
            for child in tmp.iterdir():
                info = child.lstat()
                lc.require(
                    stat.S_ISREG(info.st_mode)
                    and info.st_nlink == 1
                    and info.st_size == 0
                    and child.name.startswith("uv-")
                    and child.name.endswith(".lock"),
                    "unexpected owned TMP preserved",
                )
                removed.append(child.name)
                child.unlink()
            tmp.rmdir()
            result = {
                "manifest": manifest_ref,
                "state": state_ref,
                "job_result": lc.bound(directory / "runtime-v1/result.json")[0],
                "data": list(files.values()),
                "full_capture": check["full_log"],
                "actual_census": {
                    k: receipt[k]
                    for k in (
                        "process_index",
                        "image_role",
                        "planned",
                        "attempted",
                        "completed_requested_depth",
                        "planned_UNKNOWN",
                        "returned_Err",
                        "planned_plain",
                        "planned_diagnostic",
                        "planned_sessions",
                        "node_liability",
                    )
                },
                "identities": identities,
                "exact_identity_live": live,
                "notifier_scope": "administration separately classified; never reader/completion authority",
                "guardian_return": returned,
                "persisted_process_receipt": check["persisted_process_receipt"],
                "removed_owned_empty_TMP_files": removed,
                "admin_shape_error_preserved": "Initial saved inspection requested absent primary_error key; no scientific command/write/retry; actual manifest fields primary/secondary used.",
            }
    finally:
        os.sched_setaffinity(0, affinity)
    result.update(
        source_input_library_image_caller_reader_STOP=lc.stamp(),
        owned_readers=[],
        children=[],
        jobs=[],
        TMP=[],
        leases_remaining=[],
        continuous_peak="UNKNOWN",
        adoption="NOT_ASSESSED_PARTIAL_CAMPAIGN",
    )
    lc.new_json(args.intent.parent / "collected-STOP.json", result)


if __name__ == "__main__":
    main()
