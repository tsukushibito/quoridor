"""Prepare one original entry; the maintained lifecycle CLI remains the worker."""

import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("intent", type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    spec = json.loads(args.intent.read_bytes())
    source = spec["caller_sources"][0]
    raw = Path(source["path"]).read_bytes()
    if len(raw) != source["bytes"] or hashlib.sha256(raw).hexdigest() != source["sha256"]:
        raise ValueError("current lifecycle source drift before import")
    module_spec = importlib.util.spec_from_file_location("lc376_entry", source["path"])
    lc = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(lc)
    affinity = os.sched_getaffinity(0)
    result = {"intent": lc.bound(args.intent)[0], "native_calls": 0, "job_submitted": False}
    try:
        lc.require(lc.allocated(here) + 64 * 1024 <= 1024**2, "entry preparation 1MiB")
        lc.physical_and_quiet(spec)
        with (
            lc.lease(),
            Path("/home/vscode/.cache/inference/envs/quoridor-training.setup.lock").open(
                "rb"
            ) as env_lock,
        ):
            fcntl.flock(env_lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
            for ref in spec["caller_sources"]:
                lc.read_ref(ref)
            metadata = json.loads(
                (here.parent / "current-runtime-callers-environment.json").read_bytes()
            )
            for ref in metadata["environment_sources"]:
                lc.read_ref(ref)
            resources = lc.Limits(spec)
            resources.check()
            for name in ("output", "data_root", "TMP"):
                lc.require(
                    not os.path.lexists(spec[name]), "original output already entered: " + name
                )
            runtime = Path(spec["output"]).parent / "runtime-v1"
            lc.require(not os.path.lexists(runtime), "original runtime already entered")
            Path(spec["TMP"]).mkdir()
            result["prepared_TMP"] = spec["TMP"]
            result["fresh_preflight"] = "PASS"
    except BaseException as error:
        result["error"] = lc.error_fact(error)
        raise
    finally:
        os.sched_setaffinity(0, affinity)
        result.update(reader_STOP=lc.stamp(), leases_remaining=[], children=[], jobs=[])
        lc.new_json(args.intent.parent / "entry-preparation.json", result)


if __name__ == "__main__":
    main()
