# Fixed cheap-static376 assessment: prebound adoption gate fails

All four original ABBA processes completed once: 80/80 requested-depth completions, 72 plain + 8 diagnostic calls, 56 sessions, 256M reserved-node liability, 0 UNKNOWN and 0 returned errors. No refill, repeat, rescue, calibration or additional model/head qualification was performed. The actual total node count is 114824148. The stopped result is provisional pending SAME376.2 interpretation and Root acceptance; default/profile adoption is unsupported.

The frozen criterion requires node and evaluation ratio medians <=0.95 and whole-root ratio median <=1.02 in BOTH cold and warm strata, plus no context in which BOTH B medians exceed the bracketing A median by >1.10. Ratios are medians of each process's available plain repetitions, then median(B1,B2)/median(A0,A3), with stratum medians across the planned contexts. The 8 diagnostic calls remain outside the primary 72 plain observations.

| Stratum | Nodes | Evaluations | Whole-root time | Gate |
| --- | ---: | ---: | ---: | --- |
| cold | 1.001816243 | 1.003524636 | 1.433261163 | FAIL |
| warm | 0.995836861 | 0.994179813 | 1.372345577 | FAIL |

Both B processes exceed the 1.10 adverse whole-root threshold in all ten geometric contexts. Cold D4 family102 also exceeds that threshold for nodes and evaluations (paired ratios 1.199930283 and 1.250296242). All four B/A comparisons for each context are retained in the immutable collector JSON. No context is dropped.

| Depth | Family | Warm local ply | Nodes | Evaluations | Whole-root time |
| ---: | ---: | --- | ---: | ---: | ---: |
| 4 | 0 | cold | 1.005523193 | 1.006159773 | 1.585043484 |
| 4 | 34 | cold | 0.977779172 | 0.977448279 | 1.369496569 |
| 4 | 68 | cold | 1.025078912 | 1.032934247 | 1.461035600 |
| 4 | 102 | cold | 1.199930283 | 1.250296242 | 1.605758348 |
| 4 | 0 | 0 | 1.005523193 | 1.006159773 | 1.393422433 |
| 4 | 0 | 2 | 1.022743624 | 1.031596377 | 1.509615962 |
| 4 | 0 | 4 | 0.986150530 | 0.982199853 | 1.351268721 |
| 4 | 0 | 6 | 0.886232860 | 0.856700869 | 1.335284545 |
| 6 | 34 | cold | 0.992044845 | 0.988402597 | 1.405486725 |
| 6 | 102 | cold | 0.998109294 | 1.000889500 | 1.328903205 |

The twenty matching local request groups retain identical full value bits and selected actions across A0/B1/B2/A3. Eighteen groups retain identical PVs; the two D4 family102 repetitions have legal PV differences retained verbatim. Full roots, counted history, legal action lists, counters, requested-depth statuses and source-qualified native legality/parent-undo checks remain in original journals and owning Run facts. No geometry/PV/oracle replay was added; this is limited to the ten fixed nonrandom geometric contexts, not a strength or universal equivalence result.

The eight included diagnostic calls retain the actual map/order/cutoff counters. For each B process, diagnostic request0 borrows 17149 parent goal-map pairs and request7 borrows13952; missing and newly computed pairs are zero in these calls. A's matching diagnostic requests have available pairs17088/14075 and zero cheap-static parents/borrowed pairs. These observations do not prove map availability in every search. Instrumented costs stay separate.

| Process | Controller seconds | Nested native seconds | Actual nodes |
| --- | ---: | ---: | ---: |
| process-00-A | 53.818934408947825 | 53.30263074603863 | 28768618 |
| process-01-B | 73.96188606182113 | 73.39383195992559 | 28643456 |
| process-02-B | 73.78593341913074 | 73.04943875200115 | 28643456 |
| process-03-A | 54.3948451699689 | 53.31660366803408 | 28768618 |

Known original numerical controllers total 255.961599059868595 seconds ONCE. Nested native/Search/session/root timers are not added. Whole-root intervals retain setup on first/shared-session root, drop on last, replay, ordering/history/TT preparation and journal publication in their actual domains; model/input/header/footer/outer lifecycle costs remain separate and included in original outer whole. Later saved collection/verification/admin/LLM cost is separate: saved collector persisted wall0.13919583009555936 seconds, remaining administrative/LLM cost UNKNOWN. Table accounting is not RSS; continuous peak remains UNKNOWN.

All four owning Run manifests finalized ONCE as PASS, primarynull/secondary[]/cleanuptrue/remaining[], with full native captures, directwait/reap, afterrefs and native/lifecycle identity absence. Each original returned guardian completed mask/final-record facts remain distinct from its persisted receipt. Notifier identities are separately classified. All owned per-process zero uvlocks/TMP were removed after child completion; exact STOP maps are supplied.

The frozen saved collector itself ran ONCE, exited0, directly reaped and wrote its bounded result. A producer administrative wrapper then raised TypeError by treating lc.command's (record,capture.path) tuple as a dictionary. That original wrapper and error are preserved. No collector or Search replay occurred. A metadata-only continuation bound the persisted process receipt, full empty stdout and output, verified exact collector identity absence, cleaned only owned empty metadata TMP, and recorded final STOP. The returned guardian record was not retained by the wrapper: its mask/final-record completion is UNKNOWN and is not replaced by persisted pending/attempted values. This limitation belongs to saved administration, not a retroactive scientific PASS.

The common immutable Buildb7fa and read-only artifactf727 were used without a copy/build/source restore. Current Run authority stays separate from original370ca/ef4 input/head qualification. Math/kernel/lifetime review, original nine NN0 successes, ordinary lint inverses and current affected metadata software are reused only in their unchanged qualified scopes. No new model/head/strength/default proof is inferred. All historical failures, RAW, INCOMPLETE, masks, costs, floors and USERPAUSE323 are preserved.

No tuning, second block, profile switch or default promotion follows from this negative fixed result. Root owns acceptance and subsequent code-retirement decisions. Own leaf remains in_progress pending the required accepted interpretation.
