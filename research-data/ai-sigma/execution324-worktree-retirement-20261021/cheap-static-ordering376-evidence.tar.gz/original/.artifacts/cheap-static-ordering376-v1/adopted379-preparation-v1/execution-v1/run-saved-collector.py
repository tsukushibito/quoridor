"""Run the frozen saved-only collector once through maintained command ownership."""

import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys

HERE = Path(__file__).resolve().parent


def main():
    spec = json.loads((HERE / "process-03-A/intent.json").read_bytes())
    source = spec["caller_sources"][0]
    raw = Path(source["path"]).read_bytes()
    if len(raw) != source["bytes"] or hashlib.sha256(raw).hexdigest() != source["sha256"]:
        raise ValueError("actual lifecycle caller drift before saved collection")
    module_spec = importlib.util.spec_from_file_location("lc376_saved", source["path"])
    lc = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(lc)
    directory = HERE / "saved-collection-v1"
    lc.require(not directory.exists(), "saved collector already entered; do not repeat")
    affinity = os.sched_getaffinity(0)
    check = None
    try:
        lc.require(lc.allocated(HERE) + 384 * 1024 <= 1024**2, "inclusive helper/control 1MiB")
        lc.physical_and_quiet(spec)
        with (
            lc.lease(),
            Path("/home/vscode/.cache/inference/envs/quoridor-training.setup.lock").open(
                "rb"
            ) as env_lock,
        ):
            fcntl.flock(env_lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
            resources = lc.Limits(spec)
            resources.check()
            for ref in spec["caller_sources"]:
                lc.read_ref(ref)
            recipe_ref, raw = lc.bound(HERE.parent / "collection-recipe.json")
            recipe = json.loads(raw)
            lc.read_ref(recipe["collector_byref"])
            lc.read_ref(recipe["canonical_method"])
            for name in ("process-00-A", "process-01-B", "process-02-B", "process-03-A"):
                stop = json.loads((HERE / name / "collected-STOP.json").read_bytes())
                lc.require(
                    stop["owned_readers"] == stop["children"] == stop["jobs"] == stop["TMP"] == []
                    and not stop["exact_identity_live"]["native"]
                    and not stop["exact_identity_live"]["lifecycle"],
                    "original process not released",
                )
                lc.read_ref(stop["manifest"])
            argv = [sys.executable, "-B", *recipe["invocation"][4:]]
            lc.require(not os.path.lexists(argv[-1]), "saved output already exists")
            directory.mkdir()
            spec["env"]["TMPDIR"] = str(HERE / "completion-03-TMP")
            resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
            with lc.process.cancellation_signals():
                check = lc.command(
                    spec,
                    {"name": "saved-collector", "role": "saved_analysis", "argv": argv},
                    directory,
                    resources,
                )
            lc.require(check["status"] == "PASS", "saved collector failed; no repeat")
            lc.new_json(
                directory / "command-receipt.json",
                {
                    "check": check,
                    "recipe": recipe_ref,
                    "collector": recipe["collector_byref"],
                    "output": lc.bound(Path(argv[-1]))[0],
                    "RLIMIT_AS_B": 512 * 1024**2,
                    "native_Search_model_heads": 0,
                },
            )
    finally:
        os.sched_setaffinity(0, affinity)
    lc.new_json(
        directory / "reader-STOP.json",
        {
            "actual_reader_STOP": lc.stamp(),
            "readers": [],
            "children": [],
            "jobs": [],
            "leases_remaining": [],
            "check": check,
            "continuous_peak": "UNKNOWN",
            "scientific_interpretation": "PENDING_INDEPENDENT_ACCEPTANCE",
        },
    )


if __name__ == "__main__":
    main()
