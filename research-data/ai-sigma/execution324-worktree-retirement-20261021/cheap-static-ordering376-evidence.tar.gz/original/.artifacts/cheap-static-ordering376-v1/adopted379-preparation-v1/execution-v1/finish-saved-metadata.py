"""Finish saved metadata after the collector wrapper error, without child execution."""

import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat

HERE = Path(__file__).resolve().parent


def main():
    spec = json.loads((HERE / "process-03-A/intent.json").read_bytes())
    source = spec["caller_sources"][0]
    raw = Path(source["path"]).read_bytes()
    if len(raw) != source["bytes"] or hashlib.sha256(raw).hexdigest() != source["sha256"]:
        raise ValueError("actual source drift before saved metadata completion")
    module_spec = importlib.util.spec_from_file_location("lc376_finish", source["path"])
    lc = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(lc)
    affinity = os.sched_getaffinity(0)
    directory = HERE / "saved-collection-v1"
    try:
        lc.physical_and_quiet(spec)
        with (
            lc.lease(),
            Path("/home/vscode/.cache/inference/envs/quoridor-training.setup.lock").open(
                "rb"
            ) as env_lock,
        ):
            fcntl.flock(env_lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
            lc.Limits(spec).check()
            record_ref, raw = lc.bound(directory / "saved-collector.process.json")
            record = json.loads(raw)
            lc.require(
                record["exit_code"] == 0
                and record["status"] == "complete"
                and record["direct_child_reaped"] is True
                and record["cleanup_complete"] is True
                and record["remaining"] == [],
                "actual saved collector receipt incomplete",
            )
            lc.require(not lc.process.alive(record["child"]), "saved collector still live")
            full_ref, full_raw = lc.bound(directory / "saved-collector.full.log")
            lc.require(len(full_raw) == record["log_bytes_seen"], "saved full capture incomplete")
            output_ref, raw = lc.bound(HERE.parent / "future-fixed80-collection.json")
            output = json.loads(raw)
            lc.require(len(output["processes"]) == 4, "original result process scope")
            stops = [
                lc.bound(HERE / name / "collected-STOP.json")[0]
                for name in (
                    "process-00-A",
                    "process-01-B",
                    "process-02-B",
                    "process-03-A",
                )
            ]
            tmp = HERE / "completion-03-TMP"
            removed = []
            for path in tmp.iterdir():
                info = path.lstat()
                lc.require(
                    stat.S_ISREG(info.st_mode)
                    and info.st_nlink == 1
                    and info.st_size == 0
                    and path.name.startswith("uv-")
                    and path.name.endswith(".lock"),
                    "unexpected metadata TMP preserved",
                )
                removed.append(path.name)
                path.unlink()
            tmp.rmdir()
            receipt = {
                "persisted_collector": record_ref,
                "full_capture": full_ref,
                "output": output_ref,
                "four_original_reader_STOPs": stops,
                "collector_invocations": 1,
                "native_Search_calls_added": 0,
                "original_wrapper": lc.bound(HERE / "run-saved-collector.py")[0],
                "wrapper_error": {
                    "type": "TypeError",
                    "message": "tuple indices must be integers or slices, not str",
                    "point": "after lc.command returned (record, capture.path); check['status'] assumed a dict",
                    "outer_exit_code": 1,
                    "collector_replayed": False,
                },
                "actual_returned_guardian_record": "NOT_RETAINED_BY_WRAPPER; do not substitute persisted receipt",
                "persisted_signal_mask_restoration": record["signal_mask_restoration"],
                "persisted_final_record_persist": record["final_record_persist"],
                "exact_saved_collector_identity": record["child"],
                "exact_saved_collector_live": False,
                "removed_owned_empty_TMP": removed,
            }
    finally:
        os.sched_setaffinity(0, affinity)
    receipt.update(
        actual_final_reader_writer_STOP=lc.stamp(),
        owned_readers=[],
        children=[],
        jobs=[],
        TMP=[],
        leases_remaining=[],
        continuous_peak="UNKNOWN",
        interpretation="PENDING_RELATED_REVIEW_ACCEPTANCE",
    )
    lc.new_json(directory / "metadata-completion-STOP.json", receipt)


if __name__ == "__main__":
    main()
