# Current generator correspondence for376

Frozen376 control80886d39 and all producer source remain unchanged. Current374 Source5 was hash/size/mode verified before parsing. Its primary map has39 keys; the inherited arena map has37. The maintained11 path aliases give48 generator keys. The inherited data/lossless_jsonl.rs key is distinct from the existing crates/quoridor-data/src/lossless_jsonl.rs alias and must be retained.

Neither frozen376 producer guard hardcodes a current47 count. Both use actual Source maps and explicit additions; research-bindings delegates the generator projection to the maintained teacher function. Root metadata composition is sufficient for this omitted inherited key. The current cheap member is added to the primary research map, not the unchanged inherited arena function: this inspected basis predicts primary40/generator48, pending genuine supported Build output. If current inheritance later includes cheap, derive that exact union instead of forcing a count.

The fixed packet’s prospective generator47 wording is an admission-planning limitation. This metadata addendum supersedes that future-count wording only. Original370ca/ef4/39288 remains the original historical47/input-head subject. No source, scoring, test, model, runtime or scientific proof was changed or replayed. Root may supply this fact to the existing scoped reviewer; no new review task/question is required.

The inclusive64KiB forward is contained in the existing final source1MiB/source16MiB/whole240MiB support. No target/private authority or execution readiness follows. Actual selected-reader STOP and empty owned lists are in proof.json;374 priority and future fresh guards remain.
