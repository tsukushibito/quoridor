"""Saved native376 census/descriptive analysis only; never a BUILD or admission port.

Use after actual four process lifetimes/finalizers/STOP. Does not load models,
execute Search, replay geometry, or interpret future379 BUILD schemas.
"""

import argparse
import hashlib
import json
import math
import os
import stat
from pathlib import Path
from statistics import median

PROCESS_LIMIT = 3 * 1024**2
METRICS = ("nodes", "evaluations", "whole_root_seconds")


def read_file(path, limit):
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise ValueError(f"bounded regular file required: {path}")
        raw = stream.read(limit + 1)
        if len(raw) > limit:
            raise ValueError(f"file grew beyond bound: {path}")
    return raw, {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def decode(raw):
    return json.loads(
        raw,
        object_pairs_hook=unique_object,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
    )


def jsonl(raw):
    if raw and not raw.endswith(b"\n"):
        raise ValueError("partial JSONL tail")
    return [decode(line) for line in raw.splitlines()]


def finite(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def context(row):
    return (row["depth"], row["family"], row["warm"], row["local_ply"])


def process(directory, index, schedule):
    expected = [r for r in schedule if r["process_index"] == index]
    local = [
        {
            "id": r["local_request_id"],
            "pass": r["session"],
            "diagnostic": r["diagnostic"],
            "profile": r["profile"],
            "depth": r["depth"],
            "root": r["original_root_index"],
            "warm": r["warm"],
            "node_cap": r["node_cap"],
        }
        for r in expected
    ]
    evidence = {
        "process": index,
        "role": "ABBA"[index],
        "planned": 20,
        "refs": [],
        "errors": [],
        "native_complete": False,
    }
    captured = {}
    rows = []
    rows_parsed = False
    complete = {}
    try:
        used = 0
        for name in ("planned.json", "observations.jsonl", "costs.jsonl", "result.json"):
            raw, reference = read_file(directory / name, PROCESS_LIMIT - used)
            used += len(raw)
            captured[name] = raw
            evidence["refs"].append(reference)
        header = decode(captured["planned.json"])
        rows = jsonl(captured["observations.jsonl"])
        rows_parsed = True
        costs = jsonl(captured["costs.jsonl"])
        footer = decode(captured["result.json"])
        if (directory / "INCOMPLETE").exists() or (directory / "INCOMPLETE").is_symlink():
            raise ValueError("native INCOMPLETE retained")
        if (
            header["schema"] != "quoridor.cheap-static376.intent.v1"
            or header["algorithm"] != "cheap-static376-integer-parent-v1"
            or header["process_index"] != index
            or header["image_role"] != "ABBA"[index]
            or header["fixed_projection"] != expected
            or header["requests"] != local
            or header["planned"] != 20
            or header["plain"] != 18
            or header["diagnostic"] != 2
            or header["process_sessions"] != 14
        ):
            raise ValueError("actual header/projection/count drift")
        evidence["footer_counts"] = {
            key: footer.get(key)
            for key in (
                "attempted",
                "actual_Search_invocations",
                "returned_Ok",
                "returned_Err",
                "completed_requested_depth",
                "durably_published_complete_rows",
                "planned_UNKNOWN",
                "not_invoked",
                "node_liability",
            )
        }
        evidence["original_footer_status"] = footer.get("status")
        if len(rows) != 20 or len(costs) != 20:
            raise ValueError("partial/extra native journals; retain UNKNOWN denominator")
        intervals = footer["root_whole_intervals"]
        if len(intervals) != 20 or len(footer["passes"]) != 14:
            raise ValueError("session/root whole-cost census")
        for i, (row, request) in enumerate(zip(rows, local, strict=True)):
            if row["request"] != request or row["status"] != "COMPLETE":
                raise ValueError(f"request{i} incomplete/mismatch")
            observation = row["observed"]
            if (
                observation["returned"] != "Ok"
                or observation["completed_depth"] != request["depth"]
                or observation["stop"] != "DepthComplete"
                or type(observation["value"]) not in (int, float)
                or not math.isfinite(observation["value"])
                or observation["action"] not in row["root_legal_action_ids"]
                or len(set(row["root_legal_action_ids"])) != len(row["root_legal_action_ids"])
                or costs[i]["request_id"] != i
                or intervals[i]["request_id"] != i
            ):
                raise ValueError(f"request{i} returned/cost shape")
            metrics = {
                "nodes": observation["work"]["nodes"],
                "evaluations": observation["work"]["evaluations"],
                "whole_root_seconds": intervals[i]["whole_interval_seconds"],
            }
            if (
                not all(finite(value) for value in metrics.values())
                or metrics["nodes"] > request["node_cap"]
            ):
                raise ValueError(f"request{i} invalid cost/work")
            complete[i] = {"row": row, "metrics": metrics}
        for key in (
            "attempted",
            "actual_Search_invocations",
            "returned_Ok",
            "completed_requested_depth",
            "durably_published_complete_rows",
        ):
            if footer[key] != 20:
                raise ValueError(f"incomplete footer {key}")
        if (
            footer["returned_Err"] != 0
            or footer["planned_UNKNOWN"] != 0
            or footer["not_invoked"] != 0
        ):
            raise ValueError("native remaining/Err UNKNOWN")
        if (
            footer["status"] != "COMPLETE"
            or footer["schema"] != "quoridor.cheap-static376.result.v1"
        ):
            raise ValueError("native footer incomplete")
        if footer["node_liability"] != sum(r["observed"]["work"]["nodes"] for r in rows):
            raise ValueError("actual consumed-node footer mismatch")
        evidence["native_complete"] = True
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        evidence["errors"].append({"type": type(error).__name__, "message": str(error)})
        if not rows and "observations.jsonl" in captured:
            try:
                rows = jsonl(captured["observations.jsonl"])
                rows_parsed = True
            except (ValueError, UnicodeError) as publication_error:
                evidence["errors"].append(
                    {
                        "stage": "partial_observation_journal",
                        "message": str(publication_error),
                    }
                )
        # Any partial/failed footer remains its own raw evidence. No inferred success.
        failure = directory / "failure.json"
        try:
            raw, reference = read_file(failure, min(PROCESS_LIMIT - used, 524288))
            evidence["refs"].append(reference)
            evidence["failure"] = decode(raw)
        except (OSError, ValueError):
            pass
    evidence["published_rows_seen"] = len(rows) if rows_parsed else "UNKNOWN"
    evidence["coverage_complete_rows_checked"] = len(complete)
    return evidence, complete


def analyze(schedule, processes):
    evidence = [item[0] for item in processes]
    result = {
        "scope": "saved-native census/descriptive statistics, NOT authority/Build/adoption",
        "planned": 80,
        "plain_planned": 72,
        "diagnostic_planned": 8,
        "sessions_planned": 56,
        "node_liability_reserved": 256000000,
        "processes": evidence,
        "native_gate": "UNKNOWN",
        "contexts": [],
        "formal_adoption": "UNSUPPORTED until owning current image/Run/onceFinalize/STOP and independent interpretation accepted",
        "cost_scope": "original root_whole_intervals only; never sum nested timers or add later saved collection/admin/LLM to controller",
    }
    if not all(e["native_complete"] for e in evidence):
        return result
    # Compare every matching sweep first, including eight diagnostic returns.
    pairs = []
    for local in range(20):
        rows = [item[1][local]["row"] for item in processes]
        first = rows[0]
        for row in rows[1:]:
            if (
                row["prefix_sha256"] != first["prefix_sha256"]
                or row["root"] != first["root"]
                or set(row["root_legal_action_ids"]) != set(first["root_legal_action_ids"])
                or row["observed"]["value"] != first["observed"]["value"]
            ):
                result["comparison_error"] = f"local{local} parent/legal/value agreement"
                return result
        pairs.append(
            {
                "local_id": local,
                "value_bits": [r["observed"]["value_bits"] for r in rows],
                "actions": [r["observed"]["action"] for r in rows],
                "PVs": [r["observed"]["PV"] for r in rows],
            }
        )
    result["all_return_agreement"] = pairs
    unknown = False
    adverse = False
    grouped = {}
    for request in schedule[:20]:
        grouped.setdefault(context(request), []).append(request["local_request_id"])
    for key, ids in grouped.items():
        plain = [i for i in ids if not schedule[i]["diagnostic"]]
        medians = [
            {metric: median(p[1][i]["metrics"][metric] for i in plain) for metric in METRICS}
            for p in processes
        ]
        comparisons = {}
        ratios = {}
        bad = {}
        for metric in METRICS:
            baseline = median(medians[i][metric] for i in (0, 3))
            candidate = median(medians[i][metric] for i in (1, 2))
            if baseline <= 0:
                unknown = True
            ratios[metric] = candidate / baseline if baseline > 0 else None
            comparisons[metric] = [
                medians[b][metric] / medians[a][metric] if medians[a][metric] > 0 else None
                for b, a in ((1, 0), (1, 3), (2, 0), (2, 3))
            ]
            bad[metric] = baseline > 0 and all(medians[b][metric] > 1.10 * baseline for b in (1, 2))
            adverse |= bad[metric]
        result["contexts"].append(
            {
                "depth": key[0],
                "family": key[1],
                "warm": key[2],
                "local_ply": key[3],
                "plain_ids": plain,
                "per_process_plain_medians": medians,
                "paired_ratios": ratios,
                "four_B_A_order": ["B1/A0", "B1/A3", "B2/A0", "B2/A3"],
                "four_B_A": comparisons,
                "both_B_adverse_over_1_10": bad,
            }
        )
    strata = {}
    for label, warm in (("cold", False), ("warm", True)):
        rows = [r for r in result["contexts"] if r["warm"] == warm]
        strata[label] = {
            metric: median(r["paired_ratios"][metric] for r in rows)
            if all(r["paired_ratios"][metric] is not None for r in rows)
            else None
            for metric in METRICS
        }
    result["strata_median_of_context_ratios"] = strata
    thresholds = {"nodes": 0.95, "evaluations": 0.95, "whole_root_seconds": 1.02}
    eligible = (
        not unknown
        and not adverse
        and all(
            row[metric] is not None and row[metric] <= thresholds[metric]
            for row in strata.values()
            for metric in METRICS
        )
    )
    result["native_gate"] = (
        "UNKNOWN"
        if unknown
        else ("PREBOUND_NUMERICAL_PASS" if eligible else "PREBOUND_NUMERICAL_FAIL")
    )
    result["both_B_adverse_any"] = adverse
    result["CI_general_strength_causal_share"] = "NOT_INFERRED"
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--schedule", type=Path, required=True)
    parser.add_argument("--method", type=Path, required=True)
    parser.add_argument("--process-data", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw, schedule_ref = read_file(args.schedule, 262144)
    schedule = decode(raw)
    method_raw, method_ref = read_file(args.method, 65536)
    method = decode(method_raw)
    if (
        len(args.process_data) != 4
        or len(set(args.process_data)) != 4
        or len(schedule) != 80
        or method["schedule_sha256"] != schedule_ref["sha256"]
        or method["schema"] != "quoridor.cheap-static376.assessment.v1"
        or method["planned_Search_calls"] != 80
        or method["planned_sessions"] != 56
        or sum(r["diagnostic"] for r in schedule) != 8
        or sum(r["node_cap"] for r in schedule) != 256000000
    ):
        raise ValueError("fixed prebound four-process workload required")
    processes = [process(path, i, schedule) for i, path in enumerate(args.process_data)]
    result = analyze(schedule, processes)
    result["schedule"] = schedule_ref
    result["method"] = method_ref
    output = (json.dumps(result, indent=2, allow_nan=False) + "\n").encode()
    if len(output) > 262144:
        raise ValueError("full collection output exceeds inclusive bound")
    with args.output.open("xb") as stream:
        stream.write(output)
        stream.flush()
        os.fsync(stream.fileno())


if __name__ == "__main__":
    main()
