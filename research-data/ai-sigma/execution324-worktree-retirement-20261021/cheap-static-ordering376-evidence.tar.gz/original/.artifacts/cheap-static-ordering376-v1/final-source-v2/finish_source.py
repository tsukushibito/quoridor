"""Finite source-only patch reconstruction and declared boundary checks for376."""

import ast
import difflib
import gzip
import hashlib
import json
import re
import stat
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OWN = ROOT / ".worktree/cheap-static-ordering376"
FINAL = OWN / ".artifacts/cheap-static-ordering376-v1/final-source-v2"
HISTORY = FINAL.parent / "source-v1"


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }


def save(name, value):
    (FINAL / name).write_text(json.dumps(value, indent=2) + "\n")


def read(name):
    return json.loads((FINAL / name).read_text())


def verified(reference):
    assert ref(Path(reference["path"])) == reference
    return Path(reference["path"]).read_bytes()


def apply_exact(data, patch, reverse=False):
    """Apply parsed unified hunks; no offset/fuzz search or shell patch writes."""
    lines = data.splitlines(keepends=True)
    output = []
    cursor = 0
    rows = patch.splitlines(keepends=True)
    i = 2
    while i < len(rows):
        match = re.fullmatch(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n", rows[i])
        assert match, rows[i]
        old_start, old_count, new_start, new_count = match.groups()
        old_count = int(old_count or 1)
        new_count = int(new_count or 1)
        start = int(new_start if reverse else old_start)
        count = new_count if reverse else old_count
        at = start - 1 if count else start
        assert at >= cursor
        output.extend(lines[cursor:at])
        cursor = at
        old_seen = new_seen = 0
        i += 1
        while i < len(rows) and not rows[i].startswith("@@ "):
            tag, text = rows[i][0], rows[i][1:]
            assert tag in " +-"
            old_seen += tag in " -"
            new_seen += tag in " +"
            consume = tag in (" +" if reverse else " -")
            produce = tag in (" -" if reverse else " +")
            if consume:
                assert cursor < len(lines) and lines[cursor] == text
                cursor += 1
            if produce:
                output.append(text)
            i += 1
        assert (old_seen, new_seen) == (old_count, new_count)
    output.extend(lines[cursor:])
    return "".join(output)


def block(text, start):
    at = text.index("{", start)
    depth = 1
    end = at + 1
    while depth:
        assert end < len(text)
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return text[at:end]


def functions(text):
    result = {}
    for m in re.finditer(r"\bfn\s+(\w+)\s*(?:<[^\n]*?>)?\s*\(", text):
        name = m.group(1)
        body = block(text, m.end())
        result.setdefault(name, []).append(body)
    return result


def lexical(text):
    # rustfmt can change trailing commas inside unchanged bodies.
    return re.sub(r",(?=[\)\]\}])", "", re.sub(r"\s+", "", text))


current = {
    "path": str(ROOT / "research-data/ai-sigma/three-engine-comparison374/source-adoption-v3.json"),
    "sha256": "929828cc18c827cc8ce076778af7b6ec78f384f4754063e3ff50228fa0929b5b",
    "bytes": 51615,
    "mode": "0644",
}
adoption = json.loads(verified(current))
current_files = {x["path"]: x for x in adoption["source"]["files"]}
mapping = read("source-map.json")
alpha = mapping[0]
alpha["before_gzip"] = ref(FINAL / "before-current374-v3/crates/quoridor-ai/src/alphabeta.rs.gz")
alpha["before_Main"] = current_files[str(ROOT / alpha["relative"])]
old_test = "crates/quoridor-runner/src/ordering_assessment_tests.rs"
if not any(x["relative"] == old_test for x in mapping):
    mapping.append(
        {
            "relative": old_test,
            "before_Main": current_files[str(ROOT / old_test)],
            "before_gzip": ref(FINAL / f"before-legal-capture/{old_test}.gz"),
        }
    )
before = {}
after = {}
patches = []
for item in mapping:
    relative = item["relative"]
    path = OWN / relative
    item["after_OWN"] = ref(path)
    after[relative] = path.read_text()
    if item["before_Main"] is None:
        assert not (ROOT / relative).exists()
        before[relative] = ""
    else:
        data = verified(item["before_Main"])
        original = gzip.decompress(verified(item["before_gzip"]))
        assert original == data
        before[relative] = data.decode()
    patch = "".join(
        difflib.unified_diff(
            before[relative].splitlines(keepends=True),
            after[relative].splitlines(keepends=True),
            fromfile="a/" + relative,
            tofile="b/" + relative,
            n=3,
        )
    )
    assert patch
    assert apply_exact(before[relative], patch) == after[relative]
    assert apply_exact(after[relative], patch, reverse=True) == before[relative]
    patches.append(patch)
assert len(mapping) == 11
(FINAL / "source.patch").write_text("".join(patches))
save("source-map.json", mapping)

pub = "scripts/dev/research-lifecycle.py"
trees = [ast.parse(s) for s in (before[pub], after[pub])]
definitions = [
    {
        n.name: ast.dump(n, include_attributes=False)
        for n in t.body
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
    }
    for t in trees
]
changed = sorted(k for k in definitions[0] if definitions[0][k] != definitions[1].get(k))
added = sorted(set(definitions[1]) - set(definitions[0]))
assert changed == ["experiment_check", "numerical_check", "retained_ordering_source"]
assert added == ["cheap_ordering_inputs"]
unchanged = sorted(k for k in definitions[0] if definitions[0][k] == definitions[1][k])
assert len(unchanged) == 61
imports = [
    [
        ast.dump(n, include_attributes=False)
        for n in t.body
        if isinstance(n, (ast.Import, ast.ImportFrom))
    ]
    for t in trees
]
assert imports[0] == imports[1]
old_experiment = next(
    n for n in trees[0].body if isinstance(n, ast.FunctionDef) and n.name == "experiment_check"
)
new_experiment = next(
    n for n in trees[1].body if isinstance(n, ast.FunctionDef) and n.name == "experiment_check"
)
added_branch = [
    n
    for n in new_experiment.body
    if isinstance(n, ast.If) and "ordering-cheap-assess" in ast.dump(n.test)
]
assert len(added_branch) == 1
original_branch = [
    n
    for n in old_experiment.body
    if isinstance(n, ast.If) and "ordering-assess" in ast.dump(n.test)
]
assert len(original_branch) == 1
assert ast.dump(added_branch[0].body[0], include_attributes=False) == ast.dump(
    original_branch[0].body[0], include_attributes=False
)
assert len(added_branch[0].body) == 2
new_experiment.body[new_experiment.body.index(added_branch[0])] = original_branch[0]
assert ast.dump(old_experiment, include_attributes=False) == ast.dump(
    new_experiment, include_attributes=False
)

rel = "crates/quoridor-ai/src/alphabeta.rs"
fb, fa = functions(before[rel]), functions(after[rel])
protected = [
    "negamax",
    "control",
    "evaluate",
    "pv",
    "new_with_score_domain",
    "new_without_continuation_or_static",
    "reset",
    "search",
]
for name in protected:
    assert [lexical(x) for x in fb[name]] == [lexical(x) for x in fa[name]], name
for name in ["Key", "Entry", "Table", "ContextFingerprint"]:
    token = "struct " + name
    texts = []
    for text in (before[rel], after[rel]):
        at = text.index(token)
        if name == "ContextFingerprint":
            texts.append(text[at : text.index(";", at) + 1])
        else:
            texts.append(text[at : text.index("{", at)] + block(text, at))
    assert texts[0] == texts[1], name
assert "baseline.retained_memory_bytes().0 <=" in after[rel]
history = "crates/quoridor-ai/src/continuation_history.rs"
hb, ha = functions(before[history]), functions(after[history])
assert hb == ha
assert (
    after[old_test].replace(
        "validate_return(&root, &result, &request, None)",
        "validate_return(&root, &result, &request)",
    )
    == before[old_test]
)

proof = read("static-proof.json")
proof.update(
    {
        "current_Main_adoption": current,
        "strict_patch_inverse": "PASS11 subjects memory-only parsed unified patch, zero-offset/zero-fuzz each direction",
        "patch": ref(FINAL / "source.patch"),
        "Python_AST_changed": changed,
        "Python_AST_added": added,
        "Python_AST_unchanged_definition_count": len(unchanged),
        "Python_AST_unchanged_definitions": unchanged,
        "continuation_all_function_bodies_exact": sorted(hb),
        "mechanical_existing_test_wiring": "static360 scratch enum; TT false->Off tuple; current374 factory bool->Off/Coverage and .0 retained; old return helper extraNone, assertions untouched. All UNRUN.",
        "new_definitions": {
            "AI": 5,
            "runner_metadata": 3,
            "runner_returned_data_geometry": 1,
            "total": 9,
            "status": "UNBUILT/UNTYPED/UNRUN",
            "scoring_boundary_upper": 58,
            "admitted_ceiling": 60,
            "human_ceiling": 64,
            "real_NN_heads": 0,
            "recursive_cancel_injection": "NOT_CERTIFIED",
            "new_return_definition": "structured mock, geometry only; completed_depth4 field is not executed Search/depth qualification",
        },
        "legal_capture": "Moves same validation legal Vec, no extra generation/clone/Search; only cheap row; noaction null. Allocation/serialization/drop charged to actual root whole.",
    }
)
proof["format_checks"] = {
    "status": "PENDING_FINAL_SCOPED_CHECK",
    "Rust_type_tests": "UNBUILT/UNTYPED/UNRUN",
}
save("static-proof.json", proof)
plan = read("affected-software-plan.json")
plan["current374_base"] = current
plan["commands"][1]["assertion_scope"] = (
    "ONLY4 new runner definitions: 3 metadata-only +1 structured-return/geometry witness, model0/Search0; no old assertions"
)
save("affected-software-plan.json", plan)
question = read("review-question.json")
question["target_scope"] = (
    "final-source-v2 explicitly current374 v3 composition, 11 exact source deltas and9new definitions"
)
question["limits"][0] = (
    "9 definitions UNBUILT/UNTYPED/UNRUN; no Cargo/native/model/Search/geometry/test invocations in preparation"
)
question["questions"].append(
    "Does actual return legal-set capture reuse the existing validation Vec without new enumeration/Search, preserve old-route validation/None behavior and honestly label the one new structured-return geometry witness?"
)
save("review-question.json", question)
method = read("assessment-method.json")
method["schedule_sha256"] = ref(FINAL / "schedule.json")["sha256"]
method["actual_legal_set_capture"] = (
    "same validate_return Vec moved into cheap-only result row; noaction null/UNKNOWN, no extraSearch; actual vector capacity/allocation/serialization/drop remain charged"
)
save("assessment-method.json", method)
whole = read("whole-cost.json")
whole["source"]["new_final_source_upper_B"] = 1048576
whole["source"]["initial_coherent_source_upper_B_HELD"] = 4194304
whole["target"]["growth_predicate"] = (
    "max(actual,current typed retainedfloor)+64MiB forward within Rootissued absolute cap; precise gap before child, no allocation grant from old snapshot"
)
save("whole-cost.json", whole)
report = (FINAL / "report.md").read_text()
for old, new in [
    (
        "Five new AI definitions and three new metadata definitions",
        "Five new AI definitions, three new metadata definitions and one new returned-data/geometry definition",
    ),
    ("ten subjects", "eleven subjects"),
    ("source upper53", "source upper58"),
    ("current375 cleanup20d9", "current374/375 publisher2e2c348e"),
    ("Source db7e3ddf/49988", "Source929828cc/51615 (v3)"),
]:
    report = report.replace(old, new)
report += "\nThe current374 factory-test `.0` token is carried exactly from v3; its production/OFF factory remains unchanged. The new return helper moves the already-computed validation legal vector into a cheap-only row. No-action data is null, not a forged complete legal set. One new structured-return witness exercises this boundary without Search/model; its depth4 field is mock data, not a completed-depth result. An existing old test only gains the None argument and is not executed. The bounded definition upper is58 under the source admission60/human ceiling64, with0 real heads.\n"
(FINAL / "report.md").write_text(report)
print(
    json.dumps(
        {
            "subjects": len(mapping),
            "definitions": 9,
            "upper": 58,
            "strict_inverse": "PASS",
            "Python_unchanged": len(unchanged),
            "TT_declarations": "exact",
            "status": "SOURCE_ONLY_UNRUN",
        }
    )
)
