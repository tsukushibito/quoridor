#376 R1 source-only repair

Deleted only the accidental three-line `if cheap` cap branch in `qualify(bound)`. The correct3MiB branch remains exactly in `run_impl(bound, cheap)`. The entire qualifier function is now byte-exact to the immutable prior before-gzip. Its execution/import was not attempted.

The thinpatch has one hunk and exactly three deleted lines; parsed memory-only forward/inverse reconstruction is exact at the declared positions, without offset/fuzz. Rustfmt2024 check passed for the affected file. No Python source changed and no old formatting/test/software scope was replayed.

The other10 source subjects, original80886d39 control, negativebc7c review, schedule/method and all9 existing definitions are retained by immutable reference. All9 remain UNBUILT/UNTYPED/UNRUN. Source predicates/math/TT/history/leaf/error/lifetime/defaults and fixed oneimage80/caps/criteria are unchanged. The old reviewed caller is reconstructible from the new minimum before-gzip; the old packet is not relabeled as current source-clear.

New caller hash and source-reader/writer STOP, empty owned lists and patch/custody facts are in proof.json. The new target is frozen through SAME376.2 actual related readerSTOP. Root routes only R1; producer does not dispatch/adopt/Main/Git/build/model/Search/geometry or80 entry. Generator correspondence stays in its separate addendum; historical47 is not expanded.

Inclusive relatedsource1MiB remains inside issuedsource16MiB/whole240MiB, no global increment/refund/borrow.374 actual source/build/timing priority and future fresh runtime/custody predicates remain.
