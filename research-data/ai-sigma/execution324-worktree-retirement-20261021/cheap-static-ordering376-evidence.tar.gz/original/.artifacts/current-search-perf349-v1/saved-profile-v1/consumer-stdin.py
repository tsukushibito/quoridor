"""Supply saved records to the existing stdin consumer."""

from pathlib import Path
import runpy
import sys

here = Path(__file__).resolve().parent
with (here / "consumer-input.json").open() as stream:
    sys.stdin = stream
    runpy.run_path(
        str(here.parent / "configured-consumer-v1/consume.py"), run_name="__main__"
    )
