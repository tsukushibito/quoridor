"""Consume completed records and decode two saved perf files; never record events."""

import copy
import fcntl
import functools
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import sys


OUT = Path(__file__).resolve().parent
BASE = OUT.parent
COMPLETION = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/finite-continuation-v1/arena-sequence-v3/completion.json"
)
CONSUMER = BASE / "configured-consumer-v1/consume.py"


def ref(path):
    path = Path(path)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return {
        "path": str(path),
        "sha256": digest.hexdigest(),
        "bytes": info.st_size,
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


def read(item):
    assert ref(item["path"]) == item, item["path"]
    return json.loads(Path(item["path"]).read_text())


def write(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def main():
    ledger = []
    facts = {"status": "ATTEMPTED", "checks": ledger, "new_Search_calls": 0}
    with Path(
        "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
    ).open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        loader = importlib.util.spec_from_file_location(
            "profile_lifecycle",
            "/workspaces/quoridor/scripts/dev/research-lifecycle.py",
        )
        lc = importlib.util.module_from_spec(loader)
        sys.modules[loader.name] = lc
        loader.loader.exec_module(lc)
        completion_ref = {
            "path": str(COMPLETION),
            "sha256": "b4c60eb5719049cc77c17b99ff7559aee72306d32f58f7cfc79802115ce82f25",
            "bytes": 107133,
            "mode": "0644",
        }
        completion = read(completion_ref)
        refs = [completion["first_plain_manifest"]] + [
            row["manifest"] for row in completion["measurements"]
        ]
        manifests = [read(item) for item in refs]
        spec = copy.deepcopy(read(manifests[1]["intent"]))
        spec["perf"] = None
        spec["output"] = str(OUT)
        spec["data_root"] = str(OUT / "data")
        spec["data"] = []
        spec["TMP"] = str(OUT / "TMP")
        spec["limits"]["worker_cpu"] = 3
        spec["limits"]["log_B"] = 8 * 1024**2
        spec["env"] = dict(os.environ)
        spec["env"].update(
            TMPDIR=spec["TMP"],
            PERF_BUILDID_DIR=str(OUT / "TMP/buildid-cache"),
            DEBUGINFOD_URLS="",
            PYTHONDONTWRITEBYTECODE="1",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
        )
        for key in list(spec["env"]):
            if key.startswith("QUORIDOR_LIFECYCLE_"):
                del spec["env"][key]
        available = os.sched_getaffinity(0)
        lc.physical_and_quiet(spec)
        os.sched_setaffinity(0, available)
        resources = lc.Limits(spec)
        resources.check()
        tool = ref("/usr/bin/perf")
        images = [
            ref(m["data"]["measurement"]["settings"]["artifact"]["path"])
            for m in manifests
        ]
        for m, image in zip(manifests, images):
            assert image == m["data"]["measurement"]["settings"]["artifact"]
            for item in m["data"]["files"]:
                assert ref(item["path"]) == item
        facts.update(
            completion=completion_ref,
            manifests=refs,
            images=images,
            tool=tool,
            caller=ref(lc.__file__),
            process=ref(lc.process.__file__),
            interpreter_argv=sys.executable,
            interpreter=ref(Path(sys.executable).resolve()),
            environment={
                k: spec["env"][k]
                for k in ("TMPDIR", "PERF_BUILDID_DIR", "DEBUGINFOD_URLS")
            },
            guard_limits=spec["limits"],
            charged_roots=[str(p) for p in resources.charged_paths],
        )
        labels = [
            "A plain-before",
            "A sampled",
            "A plain-after",
            "B plain-before",
            "B sampled",
            "B plain-after",
        ]
        write(
            "consumer-input.json",
            [
                {"label": label, "record": r["path"], "planned": 6}
                for label, r in zip(labels, refs)
            ],
        )
        (OUT / "TMP").mkdir()
        try:
            with lc.process.cancellation_signals():
                lc.command(
                    spec,
                    {
                        "name": "consume",
                        "role": "offline",
                        "argv": [sys.executable, "-B", str(OUT / "consumer-stdin.py")],
                    },
                    OUT,
                    resources,
                    ledger=ledger,
                )
                for label, manifest in (("A", manifests[1]), ("B", manifests[4])):
                    raw = next(
                        r
                        for r in manifest["data"]["files"]
                        if Path(r["path"]).name == "perf.data"
                    )
                    prefix = [
                        "/usr/bin/perf",
                        "--no-pager",
                        "--buildid-dir",
                        str(OUT / "TMP/buildid-cache"),
                    ]
                    commands = {
                        "self": prefix
                        + [
                            "report",
                            "-i",
                            raw["path"],
                            "--stdio",
                            "--header",
                            "--no-children",
                            "--percent-limit",
                            "0",
                            "--sort",
                            "dso,symbol",
                            "--call-graph",
                            "none",
                            "-n",
                            "--show-total-period",
                        ],
                        "inclusive": prefix
                        + [
                            "report",
                            "-i",
                            raw["path"],
                            "--stdio",
                            "--children",
                            "--percent-limit",
                            "0",
                            "--sort",
                            "dso,symbol",
                            "--call-graph",
                            "none",
                            "-n",
                            "--show-total-period",
                        ],
                        "script": prefix
                        + [
                            "script",
                            "-i",
                            raw["path"],
                            "--show-lost-events",
                            "-F",
                            "comm,pid,tid,time,event,period,ip,sym,dso",
                        ],
                    }
                    for kind, argv in commands.items():
                        lc.command(
                            spec,
                            {
                                "name": label + "-" + kind,
                                "role": "offline",
                                "argv": argv,
                            },
                            OUT,
                            resources,
                            executor=functools.partial(
                                lc.process.execute, no_new_privs=True
                            ),
                            ledger=ledger,
                        )
                resources.check()
                for manifest in manifests:
                    for item in manifest["data"]["files"]:
                        assert ref(item["path"]) == item
                assert ref("/usr/bin/perf") == tool
                assert [ref(r["path"]) for r in images] == images
                facts["status"] = "PASS"
        except BaseException as error:
            facts["status"] = "FAILED"
            facts["error"] = lc.error_fact(error)
        finally:
            facts["TMP_contents_before_cleanup"] = [
                str(p.relative_to(OUT / "TMP")) for p in (OUT / "TMP").rglob("*")
            ]
            shutil.rmtree(OUT / "TMP")
            facts["reader_STOP"] = lc.stamp()
            facts["remaining"] = []
            facts["TMP_absent"] = not (OUT / "TMP").exists()
        facts["canonical_release_by_context_return"] = True
    write("offline-result.json", facts)
    print(
        json.dumps(
            {
                "status": facts["status"],
                "checks": len(ledger),
                "reader_STOP": facts["reader_STOP"],
                "error": facts.get("error"),
            }
        )
    )


if __name__ == "__main__":
    main()
