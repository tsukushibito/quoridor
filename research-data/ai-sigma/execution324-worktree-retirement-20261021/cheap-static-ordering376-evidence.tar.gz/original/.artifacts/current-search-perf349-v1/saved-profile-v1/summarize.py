"""Summarize saved consumer facts and standard perf output, without new execution."""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from statistics import median


OUT = Path(__file__).resolve().parent


def write(name, data):
    with (OUT / name).open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")


def reference(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o7777:04o}",
    }


def symbol_table(role, kind):
    rows = []
    pattern = (
        r"^\s*([\d.]+)%\s+(\d+)\s+(\d+)\s+(\S+)\s+\[.\]\s+(.*?)\s+-\s+-\s*$"
        if kind == "self"
        else r"^\s*([\d.]+)%\s+([\d.]+)%\s+(\d+)\s+(\d+)\s+(\S+)\s+\[.\]\s+(.*?)\s+-\s+-\s*$"
    )
    text = (OUT / (role + "-" + kind + ".full.log")).read_text()
    for line in text.splitlines():
        match = re.match(pattern, line)
        if not match:
            continue
        if kind == "self":
            percent, samples, period, dso, symbol = match.groups()
            rows.append(
                {
                    "symbol": symbol,
                    "dso": dso,
                    "self_percent_rounded": float(percent),
                    "self_samples": int(samples),
                    "self_period": int(period),
                }
            )
        else:
            inclusive, percent, samples, period, dso, symbol = match.groups()
            rows.append(
                {
                    "symbol": symbol,
                    "dso": dso,
                    "inclusive_percent_rounded": float(inclusive),
                    "self_percent_rounded": float(percent),
                    "self_samples": int(samples),
                    "self_period": int(period),
                }
            )
    return rows


def profile(role):
    self_rows = symbol_table(role, "self")
    inclusive = symbol_table(role, "inclusive")
    blocks = (OUT / (role + "-script.full.log")).read_text().strip().split("\n\n")
    samples = []
    chains = Counter()
    for block in blocks:
        lines = block.splitlines()
        match = re.match(
            r"^.+?\s+(\d+)/(\d+)\s+([\d.]+):\s+(\d+)\s+cpu-clock:u:", lines[0]
        )
        if not match:
            continue
        frames = []
        for line in lines[1:]:
            frame = re.match(r"^\s*([0-9a-f]+)\s+(.+)\s+\((.+)\)$", line)
            if frame:
                ip, symbol, dso = frame.groups()
                frames.append({"ip": ip, "symbol": symbol, "dso": dso})
        pid, tid, time, period = match.groups()
        samples.append(
            {
                "pid": int(pid),
                "tid": int(tid),
                "time": float(time),
                "period": int(period),
                "frames": frames,
            }
        )
        chains.update([" -> ".join(f["symbol"] for f in frames[:5])])
    total = sum(s["period"] for s in samples)
    self_total = sum(r["self_period"] for r in self_rows)
    assert total == self_total
    terms = {
        "map_generation": ["::wall_distance_maps"],
        "map_validation_distinct_symbol": ["validate_maps"],
        "cheap_prepare_distinct_symbol": ["cheap_static_ordering::prepare"],
        "cheap_scoring_resolved_direct_edge": [
            "cheap_static_ordering::directly_blocks"
        ],
        "sorting": [
            "::sort_by::<<quoridor_ai::alphabeta::Search>::ordered",
            "core::slice::sort::",
        ],
        "ordered": ["<quoridor_ai::alphabeta::Search>::ordered"],
        "edge_queries": ["::is_edge_open"],
        "TT_table": ["<quoridor_ai::alphabeta::Table>"],
        "board_hash": ["<quoridor_ai::alphabeta::BoardCursor>"],
        "context_fingerprint": ["<quoridor_ai::alphabeta::ContextFingerprint>"],
        "history_context": [
            "<quoridor_core::research::ContextUndo>",
            "::is_repetition_draw",
        ],
        "history_ordering_distinct_symbol": ["continuation_history", "signed_gravity"],
        "NNUE_delta": [
            "<quoridor_nnue::Model>::delta_move_into",
            "::advance_move_context",
        ],
        "NNUE_feature_validation": [
            "quoridor_nnue::validate_features",
            "::validate_accumulator",
        ],
        "NNUE_features": ["quoridor_nnue::features::"],
        "NNUE_head": [
            "ResidualModel>::evaluate_with_scratch",
            "quoridor_nnue::simd::avx2_dot_fast",
        ],
        "legal_generation": [
            "::legal_action_ids",
            "::legal_pawn_mask",
            "::both_reachable",
        ],
        "make_unmake": [
            "::make_move",
            "<quoridor_core::position::Position>::play",
            "::unmake",
        ],
    }
    groups = {}
    for name, needles in terms.items():

        def matches(symbol):
            if name == "ordered":
                return symbol == "<quoridor_ai::alphabeta::Search>::ordered"
            return any(n in symbol for n in needles)

        rows = [r for r in self_rows if matches(r["symbol"])]
        chain_samples = [
            s for s in samples if any(matches(f["symbol"]) for f in s["frames"])
        ]
        groups[name] = {
            "resolved_self_samples": sum(r["self_samples"] for r in rows),
            "resolved_self_percent": 100 * sum(r["self_period"] for r in rows) / total,
            "resolved_any_frame_samples": len(chain_samples),
            "resolved_any_frame_percent": 100
            * sum(s["period"] for s in chain_samples)
            / total,
            "resolved_symbols": [r["symbol"] for r in rows],
            "meaning": "Overlapping named-symbol groups, not additive causal costs. No resolved symbol/sample means unresolved, not zero cost.",
        }
    unknown_leaf = [
        s for s in samples if not s["frames"] or s["frames"][0]["symbol"] == "[unknown]"
    ]
    raw_address_leaf = [
        s
        for s in samples
        if not s["frames"]
        or s["frames"][0]["symbol"] == "[unknown]"
        or s["frames"][0]["symbol"].startswith("0x")
    ]
    edge_parents = Counter()
    for s in samples:
        if s["frames"] and "::is_edge_open" in s["frames"][0]["symbol"]:
            edge_parents.update(
                [s["frames"][1]["symbol"] if len(s["frames"]) > 1 else "UNKNOWN"]
            )
    text = (OUT / (role + "-self.full.log")).read_text()
    return {
        "sample_count": len(samples),
        "sample_period_sum": total,
        "reported_lost_samples": int(
            re.search(r"Total Lost Samples:\s*(\d+)", text)[1]
        ),
        "first_sample_time": min(s["time"] for s in samples),
        "last_sample_time": max(s["time"] for s in samples),
        "unresolved_leaf_samples": len(unknown_leaf),
        "unresolved_leaf_percent": 100 * sum(s["period"] for s in unknown_leaf) / total,
        "raw_address_or_unresolved_leaf_samples": len(raw_address_leaf),
        "unresolved_ancestor_samples": sum(
            any(f["symbol"] == "[unknown]" for f in s["frames"]) for s in samples
        ),
        "unknown_terminal_sentinel_samples": sum(
            bool(s["frames"]) and s["frames"][-1]["ip"] == "ffffffffffffffff"
            for s in samples
        ),
        "named_frame_count_range": [
            min(len(s["frames"]) for s in samples),
            max(len(s["frames"]) for s in samples),
        ],
        "edge_query_recorded_immediate_callers": dict(edge_parents),
        "groups": groups,
        "self_symbols": self_rows,
        "inclusive_symbols": inclusive,
        "top_recorded_callchain_prefixes": [
            {"chain": k, "samples": v} for k, v in chains.most_common(20)
        ],
        "sample_window": "One entire native process including setup/replay/Search/drop/hash verification. No per-root sample partition inferred.",
    }


def main():
    consumer = json.loads((OUT / "consume.full.log").read_text())
    offline = json.loads((OUT / "offline-result.json").read_text())
    runs = []
    for run in consumer["runs"]:
        observations = [
            o
            for c in consumer["contexts"]
            for o in c["observations"]
            if o["label"] == run["label"]
        ]
        guardian = json.loads(Path(run["record"]).read_text())["checks"][0].get(
            "guardian_return"
        )
        runs.append(
            {
                "label": run["label"],
                "artifact": run["actual_settings"]["artifact"],
                "code_version": run["actual_settings"]["code_version"]["commit"],
                "counts": run["counts"],
                "cost_domains": run["cost_domains"],
                "nodes": sum(o["returned"]["work"]["nodes"] for o in observations),
                "evaluations": sum(
                    o["returned"]["work"]["evaluations"] for o in observations
                ),
                "guardian_return_present": guardian is not None,
            }
        )
    contexts = []
    for context in consumer["contexts"]:
        observations = context["observations"]
        a = [o for o in observations if o["profile"] == "control"]
        b = [o for o in observations if o["profile"] == "cheap"]
        ratios = next(
            r["plain_ratios"]
            for r in context["descriptive_plain_profile_ratios"]
            if r["numerator_profile"] == "cheap"
        )
        contexts.append(
            {
                "id": context["request_id"],
                "same_root_limits_model_input_settings": context[
                    "same_recorded_root_and_limits"
                ],
                "within_role_full_returned_work_agreement": {
                    role: row["available_return_fields_agree"]
                    for role, row in context["profiles"].items()
                },
                "AB_value_bits_equal": a[0]["returned"]["value_bits"]
                == b[0]["returned"]["value_bits"],
                "AB_action_equal": a[0]["returned"]["action"]
                == b[0]["returned"]["action"],
                "AB_legal_ids_equal": a[0]["returned"]["root_legal_action_ids"]
                == b[0]["returned"]["root_legal_action_ids"],
                "AB_PV_equal": a[0]["returned"]["PV"] == b[0]["returned"]["PV"],
                "returned_PVs": {
                    "A": a[0]["returned"]["PV"],
                    "B": b[0]["returned"]["PV"],
                },
                "all_parents_unchanged": all(
                    o["returned"]["parent_unchanged"] is True for o in observations
                ),
                "requested_depth": a[0]["request"]["depth"],
                "all_completed_depth_equal_requested": all(
                    o["returned"]["completed_depth"] == o["request"]["depth"]
                    for o in observations
                ),
                "plain_B_over_A_two_observation_medians": ratios,
                "sampled_over_plain_root_body": {
                    role: row["sampled_over_plain_root_body"]
                    for role, row in context["profiles"].items()
                },
                "plain_times_and_work": [
                    {"label": o["label"], "metrics": o["metrics"]}
                    for o in observations
                    if not o["sampled"]
                ],
            }
        )
    a_plain = [r for r in runs if r["label"].startswith("A plain")]
    b_plain = [r for r in runs if r["label"].startswith("B plain")]
    whole = {
        role: median(
            r["cost_domains"]["whole_before_result_publication_seconds"] for r in rs
        )
        for role, rs in (("A", a_plain), ("B", b_plain))
    }
    timings = {
        "plain_whole_before_result_publication_medians": whole,
        "B_over_A_plain_whole_before_result_publication": whole["B"] / whole["A"],
        "sampled_over_plain_whole": {
            role: next(
                r["cost_domains"]["whole_before_result_publication_seconds"]
                for r in runs
                if r["label"] == role + " sampled"
            )
            / whole[role]
            for role in "AB"
        },
        "interpretation": "Descriptive selected observations only; A's earlier plain image differs. Domains overlap. Native timer ends before final result publication; original guardian/controller/finalizer costs remain separately recorded and are not added twice.",
    }
    data = {
        "counts": consumer["count_facts"],
        "runs": runs,
        "contexts": contexts,
        "timings": timings,
        "profiles": {role: profile(role) for role in "AB"},
        "offline_operations": reference(OUT / "offline-result.json"),
        "original_completion": offline["completion"],
        "saved_consumer": reference(OUT.parent / "configured-consumer-v1/consume.py"),
        "original_full_consumer_output": reference(OUT / "consume.full.log"),
        "reader_STOP": datetime.now(timezone.utc).isoformat(),
        "new_Search_calls": 0,
        "new_perf_events": 0,
        "adoption": "Original376 fixed80 FAIL remains unchanged; profiling selects no optimization or default promotion.",
    }
    write("result.json", data)
    print(
        json.dumps(
            {
                "counts": data["counts"],
                "timings": timings,
                "profiles": {
                    r: {
                        k: p[k]
                        for k in [
                            "sample_count",
                            "reported_lost_samples",
                            "unresolved_leaf_samples",
                            "unknown_terminal_sentinel_samples",
                            "edge_query_recorded_immediate_callers",
                        ]
                    }
                    for r, p in data["profiles"].items()
                },
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
