    def check(self, children=()):
        super().check(children)
        seen = set()
        require(
            sum(allocated(p, seen=seen) for p in self.charged_paths)
            <= self.spec["limits"]["owned_B"],
            "owned allocation limit",
        )
        require(
            shutil.disk_usage(self.spec["owner"]).free >= self.spec["limits"]["free_B"],
            "FS reserve",
        )
        if self.spec["kind"] == "build":
            h = document(self.spec["target_handover"])
            require(allocated(self.spec["target"]) <= h["target_max_B"], "target cap")
            private = allocated(Path(self.spec["private"]).parent)
            require(
                private <= h["fresh_private_forward_max_B"]
                and private + h["old_private_retained_allocated_B"]
                <= h["private_pool_B"],
                "retained private pool cap",
            )
            require(allocated(self.spec["TMP"]) <= 64 * 1024 * 1024, "TMP cap")
        if self.spec["support"]["sha256"] == PERF349_SUPPORT:
            require(allocated(self.spec["TMP"]) <= 4 * 1048576, "349 serial TMP cap")
            if self.spec.get("perf") is not None:
                path = Path(self.spec["perf"]["output"])
                if path.exists():
                    info = path.lstat()
                    require(
                        stat.S_ISREG(info.st_mode) and info.st_size < 12 * 1048576,
                        "349 perf cap; remaining samples/work UNKNOWN",
                    )
