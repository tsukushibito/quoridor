"""Finish stopped metadata facts only; never import a target or submit jobs."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }, raw


prepared_ref, raw = ref(HERE / "prepared-inputs.json")
assert (prepared_ref["sha256"], prepared_ref["bytes"]) == (
    "524f75828fca681557bc2c2dcc05a4584923627fc4b9f8bf93c935b6877675e3",
    22806,
)
facts = json.loads(raw)
absence = []
for entry in facts["entries"]:
    assert entry["current_metadata_check"] == "PASS" and entry["exact_refusal"] is None
    for key in ("experiment", "intent", "job"):
        assert ref(Path(entry[key]["path"]))[0] == entry[key]
    base = Path(entry["intent"]["path"]).parent
    for name in ("native", "TMP", "perf.data", "operation-v1", "runtime-v1"):
        path = base / name
        assert not os.path.lexists(path), "actual unexpected execution output"
        absence.append(str(path))
    assert entry["planned_calls"] == 6 and entry["sessions"] == 3
    assert entry["node_liability"] == 18000000
    intent = json.loads(Path(entry["intent"]["path"]).read_bytes())
    assert intent["artifact"] == facts["Artifact_readonly"]
    assert intent["caller_sources"] == facts["caller_sources"]
    if intent["perf"] is not None:
        assert Path(intent["perf"]["output"]).parent == Path(intent["data_root"]).parent
        assert intent["perf"]["frequency_hz"] == 49
assert len(facts["entries"]) == 6
stop = {
    "issue": "quoridor-4lc.349",
    "related_issue": "quoridor-4lc.376.1",
    "status": "STOPPED_SIX_METADATA_CHECKED_SCIENCE_UNENTERED",
    "prepared_inputs": prepared_ref,
    "report": ref(HERE / "report.md")[0],
    "assembly": ref(HERE / "assemble.py")[0],
    "preserved_preparation_refusal": ref(HERE / "assembly-refusal-v1.json")[0],
    "counts": facts["counts"],
    "six_entry_FileRefs_and_CLI": "Bound in prepared-inputs entries; normal settings+result remain the run unit, no new required control ledger.",
    "actual_absent_outputs": absence,
    "source_image_environment_reader_STOP": facts[
        "source_image_environment_metadata_reader_STOP"
    ],
    "public_common_entry_return": {
        "exit_code": 0,
        "canonical_environment_release_UTC": "UNKNOWN; released by scope/return",
    },
    "metadata_writer_reader_STOP": datetime.now(timezone.utc).isoformat(),
    "owned": {
        "readers": [],
        "children": [],
        "jobs": [],
        "TMP": [],
        "leases": [],
        "reservation": None,
    },
    "jobs_submitted": 0,
    "native_perf_model_library_load_geometry_Search_calls": 0,
    "ordinary_preparation_storage": None,
    "directed_usage": {
        "allocated_B": facts["ordinary_directed_preparation_usage_before_receipt_B"],
        "scope": facts["usage_scope"],
    },
    "next": "Root coordinates actual serial timed slot; repeat fresh guards at entry, no future quietness from preparation.",
}
path = HERE / "source-STOP.json"
path.write_text(json.dumps(stop, indent=2) + "\n")
print(
    json.dumps(
        {
            "source_STOP": ref(path)[0],
            "prepared_inputs": prepared_ref,
            "report": stop["report"],
            "all_six_metadata_checks": "PASS",
            "jobs_submitted": 0,
        }
    )
)
