"""Saved first-pass collection and current after refs; no scientific command."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
OUT = HERE / "collection-v1"


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }, raw


def read(path, expected=None):
    actual, raw = ref(path)
    if expected is not None:
        assert actual == expected, "saved record drift"
    return actual, json.loads(raw)


manifest_ref, manifest = read(HERE / "operation-v1/manifest.json")
assert (
    manifest_ref["sha256"]
    == "d2e56a1f058415c0e4094a70b4a638004b4a37e393e5ef700a3f6e0e73057cf3"
)
intent_ref, spec = read(HERE / "intent.json", manifest["intent"])
experiment_ref, experiment = read(HERE / "experiment.json", manifest["experiment"])
settings_ref, settings = read(HERE / "native/settings.json")
native_ref, native = read(HERE / "native/result.json")
runtime_ref, runtime = read(HERE / "runtime-v1/result.json")
assert (
    runtime_ref["sha256"]
    == "5b25f6ce1f6b7a0a29fbe3556876cd087a36ee1dfc3f59061564794e0e1d00bd"
)
state_ref, state = read(HERE / "runtime-v1/state.json")
process_ref, persisted = read(HERE / "operation-v1/run.process.json")
usage_ref, usage = read(HERE / "operation-v1/storage-usage.json")
journal_ref, journal = ref(HERE / "native/measurements.jsonl")
journal_rows = [json.loads(line) for line in journal.splitlines()]
assert journal.endswith(b"\n")
rows = native["measurements"]
for expected in manifest["data"]["files"]:
    assert ref(Path(expected["path"]))[0] == expected
full_ref, full = ref(HERE / "operation-v1/run.full.log")
assert full_ref == manifest["checks"][0]["full_log"]
assert manifest["checks"][0]["capture_complete"] is True
assert process_ref == manifest["checks"][0]["persisted_process_receipt"]
assert not os.path.lexists(HERE / "TMP")
assert not os.path.lexists(HERE / "operation-v1/INCOMPLETE")

boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
identities = []
for expected in (state["supervisor"], state["child"], persisted["child"]):
    path = Path(f"/proc/{expected['pid']}/stat")
    if path.exists():
        fields = path.read_text().rsplit(")", 1)[1].split()
        actual = {"pid": expected["pid"], "start_ticks": fields[19], "boot_id": boot}
        assert actual != expected, "original scientific process still present"
        status = "DIFFERENT"
    else:
        actual = None
        status = "ABSENT"
    identities.append({"expected": expected, "actual": actual, "state": status})

after_refs = []
after_error = None
try:
    with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "r"
    ) as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        module = importlib.util.spec_from_file_location(
            "current349_collection", MAIN / "scripts/dev/research-lifecycle.py"
        )
        lc = importlib.util.module_from_spec(module)
        sys.modules[module.name] = lc
        module.loader.exec_module(lc)
        available = sorted(os.sched_getaffinity(0))
        worker = 1 if 1 in available else available[0]
        guardian = (
            4
            if 4 in available and 4 != worker
            else next(c for c in available if c != worker)
        )
        lc.physical_and_quiet(
            {
                "kind": "software",
                "limits": {
                    "family_B": 536870912,
                    "host_reserve_B": 4294967296,
                    "worker_cpu": worker,
                    "guardian_cpu": guardian,
                },
            }
        )
        expected_refs = [
            *spec["caller_sources"],
            spec["artifact"],
            spec["experiment"],
            experiment["build_manifest"],
            experiment["config"],
            experiment["schedule"],
            *experiment["inputs"],
            *[r["file"] for r in experiment["dynamic_libraries"]],
        ]
        for model in experiment["models"]:
            expected_refs.extend((model["descriptor"], model["weights"]))
        for expected in expected_refs:
            actual = lc.artifact_ref(expected["path"])
            after_refs.append(actual)
            assert actual == expected, "current after-ref drift"
        source_stop = datetime.now(timezone.utc).isoformat()
    canonical_release = datetime.now(timezone.utc).isoformat()
except BaseException as error:
    after_error = {"type": type(error).__name__, "message": str(error)}
    source_stop = datetime.now(timezone.utc).isoformat()
    canonical_release = None

measurements = []
for row in rows:
    value = row.get("measurement") or {}
    measurements.append(
        {
            "request": row["request"],
            "root": row["root"],
            "status": row["status"],
            "completed_depth": value.get("completed_depth"),
            "value_bits": value.get("value_bits"),
            "action": value.get("action"),
            "PV": value.get("PV"),
            "root_legal_action_ids": value.get("root_legal_action_ids"),
            "parent_unchanged": value.get("parent_unchanged"),
            "available_work_counters": value.get("work"),
            "root_body_including_journal_seconds": row.get(
                "root_body_including_journal_seconds"
            ),
        }
    )
facts = {
    "issue": "quoridor-4lc.349",
    "pass": "00-A-plain-before",
    "original_job": runtime["job_id"],
    "authoritative_manifest": manifest_ref,
    "manifest_status": manifest["status"],
    "primary": manifest["primary"],
    "secondary": manifest["secondary"],
    "cleanup_complete": manifest["cleanup_complete"],
    "once_FINALIZE": {
        "exit_code": 0,
        "authoritative_finished_at": manifest["authoritative_finished_at"],
    },
    "actual_settings": settings_ref,
    "actual_result": native_ref,
    "journal": journal_ref,
    "journal_recorded_rows": len(journal_rows),
    "maintained_journal_facts": {
        key: manifest["data"]["measurement"].get(key)
        for key in (
            "journal_rows",
            "journal_partial_tail",
            "journal_result_rows_agree",
            "unreturned_tail",
        )
    },
    "journal_timing_scope": "The final result additionally records post-write journal and inclusive timing; original saved forms remain separate.",
    "full_capture": full_ref,
    "runtime_result": runtime_ref,
    "process_receipt": process_ref,
    "actual_census": {
        key: native.get(key)
        for key in (
            "planned",
            "scheduled",
            "calls",
            "attempted",
            "complete",
            "uncompleted",
            "unperformed",
            "extra_calls",
            "remaining_requests",
            "errors",
        )
    },
    "measurements": measurements,
    "observed_nodes": sum(m["measurement"]["work"]["nodes"] for m in rows),
    "observed_evaluations": sum(m["measurement"]["work"]["evaluations"] for m in rows),
    "session_domains": native["session_domains"],
    "returned_guardian": manifest["checks"][0]["guardian_return"],
    "persisted_process_facts": persisted,
    "controller_fee_seconds_once": runtime["wall_seconds"],
    "nested_clocks": "Native/guardian/setup/root/session clocks overlap the original controller, not added. Saved collection/finalization/admin is separate; total not inferred.",
    "exact_original_processes": identities,
    "after_refs": after_refs,
    "after_ref_error": after_error,
    "actual_source_input_model_library_image_caller_reader_STOP": source_stop,
    "actual_canonical_release": canonical_release,
    "common_environment_release_UTC": "UNKNOWN until entry returns",
    "TMP_absent": True,
    "INCOMPLETE_absent": True,
    "remaining_owned": {
        "readers": [],
        "children": [],
        "jobs": [],
        "TMP": [],
        "leases": [],
        "reservation": None,
    },
    "directed_postwork_usage_receipt": usage_ref,
    "usage": usage,
    "cumulative_campaign": {
        "planned_calls": 36,
        "observed_calls": native["calls"],
        "remaining_unentered_calls": 30,
        "next_pass_submitted": False,
    },
    "scope": "Original first plain pass only. No aggregate A/B benefit, Perf sample sufficiency, adoption or new scientific qualification inferred.",
    "metadata_reader_STOP": datetime.now(timezone.utc).isoformat(),
}
OUT.mkdir()
path = OUT / "collection-result.json"
path.write_text(json.dumps(facts, indent=2) + "\n")
print(
    json.dumps(
        {
            "collection": ref(path)[0],
            "manifest": manifest_ref,
            "census": facts["actual_census"],
            "nodes": facts["observed_nodes"],
            "evaluations": facts["observed_evaluations"],
            "after_ref_error": after_error,
            "reader_STOP": source_stop,
            "canonical_release": canonical_release,
            "identities": identities,
        }
    )
)
