"""Preserve one original pre-child refusal; no finalized manifest fabrication."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "collection-v1"


def reference(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }, raw


result_ref, result_raw = reference(HERE / "runtime-v1/result.json")
assert (result_ref["sha256"], result_ref["bytes"]) == (
    "8f6c8707512a92cc1064357f9f52ea2b8ab7787bf4303e0bb7451af644638983",
    504,
)
result = json.loads(result_raw)
output_ref, output_raw = reference(HERE / "runtime-v1/output.log")
assert (output_ref["sha256"], output_ref["bytes"]) == (
    "3d51fe333f16590ddb7f6c49f010a01a5eb7d39a9617a2c83dc138a3d82dfff0",
    2406,
)
config_ref, config_raw = reference(HERE / "runtime-v1/config.json")
config = json.loads(config_raw)
state_ref, state_raw = reference(HERE / "runtime-v1/state.json")
state = json.loads(state_raw)
prefix = "lifecycle partial facts: "
partial_lines = [
    line[len(prefix) :]
    for line in output_raw.decode().splitlines()
    if line.startswith(prefix)
]
assert len(partial_lines) == 1
partial = json.loads(partial_lines[0])
assert partial["primary"]["message"] == "CPU affinity admission"
assert partial["checks"] == []
intent_ref, intent_raw = reference(HERE / "intent.json")
assert intent_ref == partial["intent"]
intent = json.loads(intent_raw)
assert (
    intent_ref["sha256"]
    == "7d24a585c1644ccf5f14f6e4bb266c504415897257dbebd4d0fed31a0191114f"
)
absent = []
for name in ("operation-v1", "native", "TMP", "perf.data"):
    path = HERE / name
    assert not os.path.lexists(path), "unexpected scientific or operation output"
    absent.append(str(path))

identities = []
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
for expected in (state["supervisor"], state["child"]):
    path = Path(f"/proc/{expected['pid']}/stat")
    if path.exists():
        fields = path.read_text().rsplit(")", 1)[1].split()
        actual = {"pid": expected["pid"], "start_ticks": fields[19], "boot_id": boot}
        assert actual != expected, "original owner process still present"
        status = "DIFFERENT"
    else:
        actual = None
        status = "ABSENT"
    identities.append({"expected": expected, "actual": actual, "state": status})

facts = {
    "issue": "quoridor-4lc.349",
    "pass": "01-A-sampled",
    "original_job": result["job_id"],
    "status": "FAILED_PRE_CHILD_ADMISSION_REFUSAL",
    "runtime_result": result_ref,
    "full_runtime_output": output_ref,
    "original_config": config_ref,
    "original_state": state_ref,
    "original_intent": intent_ref,
    "original_extracted_partial_facts": partial,
    "partial_record_scope": "Exact original stdout JSON, not a finalized operation manifest or repaired guardian return.",
    "outer_returned_process_facts": result,
    "cleanup_distinction": "Partial lifecycle cleanup_complete/process_cleanup_complete=false with checks[] versus outer job cleanup_complete=true/direct-child-reaped/remaining[]. Neither rewritten.",
    "controller_fee_seconds_once": result["wall_seconds"],
    "scientific_scope": {
        "planned_calls": 6,
        "actual_calls": 0,
        "perf_native_children_entered": 0,
        "unperformed_calls": 6,
        "native_census_footer_counters": None,
        "method": "Not reached; no model/input/library/native/current-profile PASS or sample sufficiency inferred.",
        "fixed_campaign_actual_calls": 6,
        "fixed_campaign_planned_calls": 36,
        "fixed_campaign_unentered_calls": 30,
    },
    "actual_entry_affinity_mask": None,
    "affinity_scope": "Saved trace proves only that configured worker/guardian cores were not contained in actual controller affinity. Actual mask was not recorded; do not invent it.",
    "requested_worker_cpu": intent["limits"]["worker_cpu"],
    "requested_guardian_cpu": intent["limits"]["guardian_cpu"],
    "normal_finalization": {
        "invoked": False,
        "manifest_created": False,
        "reason": "Original physical guard refused before operation/candidate creation. No existing normal onceFinalize target; do not knowingly finalize an absent candidate or invent a manifest.",
        "owed_finalizers_original": partial["owed_finalizers"],
    },
    "actual_absent_paths": absent,
    "exact_original_process_observations": identities,
    "original_partial_controller_finished_at": partial["finished_at"],
    "original_outer_finished_at": result["finished_at"],
    "original_canonical_environment_release_UTC": "UNKNOWN; original process exit/reap and observed absence retained",
    "fresh_owner_empty_reader_STOP": datetime.now(timezone.utc).isoformat(),
    "current_source_model_input_library_image_after_refs": "NOT_REACHED at failed scientific entry; no extra model/library/artifact probe during refusal collection",
    "owned": {
        "readers": [],
        "children": [],
        "jobs": [],
        "TMP": [],
        "leases": [],
        "reservation": None,
    },
    "retry_or_next_pass_submitted": False,
    "ordinary_collection_storage_budget": None,
    "next_input": "Root ordinary controller-affinity launch correction, using actual topology/restoration facts; original six sampled calls remain genuinely unentered. No automatic job retry or next pass.",
}
OUT.mkdir()
path = OUT / "collection-result.json"
path.write_text(json.dumps(facts, indent=2) + "\n")
print(
    json.dumps(
        {
            "collection": reference(path)[0],
            "status": facts["status"],
            "original_failure": partial["primary"],
            "identities": identities,
            "actual_calls": 0,
            "normal_finalize": facts["normal_finalization"],
            "STOP": facts["fresh_owner_empty_reader_STOP"],
        }
    )
)
