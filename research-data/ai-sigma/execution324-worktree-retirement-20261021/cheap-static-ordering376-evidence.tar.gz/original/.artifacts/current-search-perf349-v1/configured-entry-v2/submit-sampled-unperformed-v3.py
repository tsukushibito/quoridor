"""Bind and submit one authorized, genuinely unperformed sampled pass."""

from datetime import datetime, timezone
import copy
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path("/workspaces/quoridor")
HERE = Path(__file__).resolve().parent
OLD = HERE / "runs/01-A-sampled"
BASE = HERE / "runs/01-A-sampled-unperformed-v3"
BUILD = {
    "path": "/workspaces/quoridor/.artifacts/research-team/integration324/finite-continuation-v1/compatible-build-v1/operation-v1/manifest.json",
    "sha256": "bddfd4d55392d2730f56e41f417d8bf43e42af4f3d3674ca2926633a3d01dd18",
    "bytes": 36461,
    "mode": "0644",
}
ARTIFACT = {
    "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1/private-images/quoridor-runner374-finite349-perf-unit-v1",
    "sha256": "4b9a61aada88ccda16091221c586c4c67922f48d8801a8578c63e016ebc2b0ae",
    "bytes": 9471984,
    "mode": "0755",
}


def stamp():
    return datetime.now(timezone.utc).isoformat()


def write(path, value):
    with path.open("x") as file:
        file.write(json.dumps(value, indent=2) + "\n")


assert not BASE.exists(), "original new pass root must be absent"
available = set(os.sched_getaffinity(0))
assert {1, 4} <= available, "required actual worker1/guardian4 affinity"
primary = None
preflight = {}
try:
    with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "r"
    ) as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        loader = importlib.util.spec_from_file_location(
            "sampled349_current_entry", MAIN / "scripts/dev/research-lifecycle.py"
        )
        lc = importlib.util.module_from_spec(loader)
        sys.modules[loader.name] = lc
        loader.loader.exec_module(lc)
        spec = lc.document(lc.bound(OLD / "intent.json")[0])
        spec = copy.deepcopy(spec)
        spec.pop("intent_sha256")
        lc.physical_and_quiet(spec)
        manifest = lc.accepted_build(BUILD)
        assert manifest["artifact"] == ARTIFACT
        original_experiment = lc.document(spec["experiment"])
        experiment = copy.deepcopy(original_experiment)
        experiment["build_manifest"] = BUILD
        experiment["argv"][0] = ARTIFACT["path"]
        assert experiment["planned_slots"] == 6 and experiment["batch"] == 1
        subject_paths = [Path(ref["path"]) for ref in spec["caller_sources"]]
        subject_paths += [
            MAIN / "scripts/dev/project-env.sh",
            MAIN / "pyproject.toml",
            MAIN / "uv.lock",
            Path(sys.executable).resolve(),
        ]
        before = [lc.bound(path)[0] for path in subject_paths]
        BASE.mkdir()
        write(BASE / "experiment.json", experiment)
        spec["experiment"] = lc.bound(BASE / "experiment.json")[0]
        spec["artifact"] = ARTIFACT
        spec["caller_sources"] = before[:4]
        spec["output"] = str(BASE / "operation-v1")
        spec["data_root"] = str(BASE / "native")
        spec["TMP"] = str(BASE / "TMP")
        spec["owned_outputs"] = [
            str(HERE),
            str(HERE.parent / "configured-entry-v1/runs"),
            spec["TMP"],
        ]
        spec["env"] = {
            key: os.environ.get(key, value) for key, value in spec["env"].items()
        }
        spec["env"].update(
            {
                "TMPDIR": spec["TMP"],
                "PERF_BUILDID_DIR": str(BASE / "buildid-cache"),
                "CUDA_VISIBLE_DEVICES": "",
                "OMP_NUM_THREADS": "1",
                "OPENBLAS_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1",
                "NUMEXPR_NUM_THREADS": "1",
            }
        )
        for item in spec["data"]:
            item["path"] = (
                str(BASE / "perf.data")
                if item["name"] == "perf_RAW"
                else str(BASE / "native" / Path(item["path"]).name)
            )
        spec["perf"]["output"] = str(BASE / "perf.data")
        spec["perf"]["tool"] = lc.artifact_ref(spec["perf"]["tool"]["path"])
        native = [
            arg.replace("@EXPERIMENT@", spec["experiment"]["path"]).replace(
                "@EXPERIMENT_SHA256@", spec["experiment"]["sha256"]
            )
            for arg in experiment["argv"]
        ]
        spec["argv"] = lc.measurement_argv(spec, experiment, native)
        assert spec["argv"][spec["argv"].index("--max-size") + 1] == "12582912B"
        spec["intent_sha256"] = lc.canonical_sha(spec)
        write(BASE / "intent.json", spec)
        intent = lc.bound(BASE / "intent.json")[0]
        lc.experiment_check(spec)
        lc.Limits(spec).check()
        for name in ["operation-v1", "native", "TMP", "perf.data", "runtime-v1"]:
            assert not os.path.lexists(BASE / name)
        after = [lc.bound(path)[0] for path in subject_paths]
        assert before == after, "current caller/environment drift"
        job = lc.document(lc.bound(OLD / "job.json")[0])
        job["argv"] = [
            sys.executable,
            "-B",
            str(MAIN / "scripts/dev/research-lifecycle.py"),
            "run",
            "--intent",
            intent["path"],
            "--sha256",
            intent["sha256"],
        ]
        job["resource_contract"] = intent["path"]
        write(BASE / "job.json", job)
        preflight = {
            "intent": intent,
            "experiment": spec["experiment"],
            "job": lc.bound(BASE / "job.json")[0],
            "Build": BUILD,
            "artifact_readonly": ARTIFACT,
            "current_caller_environment_before": before,
            "current_caller_environment_after": after,
            "worker_cpu": 1,
            "guardian_cpu": 4,
            "preflight_reader_STOP": stamp(),
            "settings_config_schedule_unchanged": experiment["config"]
            == original_experiment["config"]
            and experiment["schedule"] == original_experiment["schedule"],
            "planned_this_entry": 6,
            "old_pass_outputs_untouched": True,
        }
    preflight["canonical_release"] = stamp()
except BaseException as failure:
    primary = {"type": type(failure).__name__, "message": str(failure)}
finally:
    os.sched_setaffinity(0, available)
if primary:
    BASE.mkdir(exist_ok=True)
    write(
        BASE / "preflight-refusal.json",
        {
            "primary": primary,
            "STOP": stamp(),
            "submitted": False,
            "owned": [],
            "actual_restored_parent_affinity": sorted(os.sched_getaffinity(0)),
        },
    )
    print(json.dumps({"status": "REFUSED", "primary": primary}))
    raise SystemExit(1)
launch_mask = sorted(os.sched_getaffinity(0))
assert set(launch_mask) == available and {1, 4} <= set(launch_mask)
preflight.update(
    {
        "actual_parent_affinity_original": sorted(available),
        "actual_launch_affinity": launch_mask,
        "owned_pre_submit": [],
        "ordinary_binding_storage_budget": None,
    }
)
write(BASE / "launch.json", preflight)
submit = [
    "/usr/bin/bash",
    str(MAIN / "scripts/dev/project-env.sh"),
    "python",
    "-B",
    str(MAIN / "scripts/dev/research-job.py"),
    "submit",
    "--config",
    str(BASE / "job.json"),
    "--state-dir",
    str(BASE / "runtime-v1"),
]
completed = subprocess.run(submit, cwd=MAIN, capture_output=True, text=True)
(BASE / "submission.json").write_text(completed.stdout)
(BASE / "submission.stderr.log").write_text(completed.stderr)
write(
    BASE / "submission-return.json",
    {
        "argv": submit,
        "returncode": completed.returncode,
        "returned_at": stamp(),
        "launch": lc.bound(BASE / "launch.json")[0],
        "submission": lc.bound(BASE / "submission.json")[0],
        "ordinary_directed_binding_usage_before_return_B": lc.allocated(
            BASE, seen=set()
        ),
        "scientific_START": "UNKNOWN; submit receipt is not native entry",
        "storage_budget": None,
    },
)
print(completed.stdout)
print(json.dumps({"binding": str(BASE), "submit_returncode": completed.returncode}))
raise SystemExit(completed.returncode)
