"""Compose existing normal Run inputs; validate metadata, never submit or run."""

from datetime import datetime, timezone
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import sys


MAIN = Path("/workspaces/quoridor")
HERE = Path(__file__).resolve().parent
OWNER = HERE.parent
RUNS = HERE / "runs"
RECIPE = OWNER / "common-measurement-v1/selected-settings/current-recipe.json"
BUILD = {
    "path": "/workspaces/quoridor/.artifacts/research-team/integration324/arena-entry-v1/compatible-build-v2/operation-v1/manifest.json",
    "sha256": "5d7b6cec8f2d133707615e9066c2867b59bcc51be948d16291cf8d55b9dd57e3",
    "bytes": 40762,
    "mode": "0644",
}
ARTIFACT = {
    "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1/private-images/quoridor-runner374-capture349-raw-v1",
    "sha256": "dd199514dd90488373f54a7e0289c1eaae6fe59afab6508ea6141695e864d4e6",
    "bytes": 9472400,
    "mode": "0755",
}


def write(path, value):
    with path.open("x") as file:
        file.write(json.dumps(value, indent=2) + "\n")


with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
    "r"
) as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    module = importlib.util.spec_from_file_location(
        "maintained349_lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(module)
    sys.modules[module.name] = lc
    module.loader.exec_module(lc)
    available = sorted(os.sched_getaffinity(0))
    assert len(available) >= 2, "two distinct actual CPUs required"
    worker_cpu = 1 if 1 in available else available[0]
    guardian_cpu = (
        4
        if 4 in available and 4 != worker_cpu
        else next(c for c in available if c != worker_cpu)
    )
    lc.physical_and_quiet(
        {
            "kind": "software",
            "limits": {
                "family_B": 536870912,
                "host_reserve_B": 4294967296,
                "worker_cpu": worker_cpu,
                "guardian_cpu": guardian_cpu,
            },
        }
    )
    subject_paths = [
        MAIN / p
        for p in [
            "scripts/dev/research-lifecycle.py",
            "scripts/dev/research-job.py",
            "python/quoridor_training/cycle_process.py",
            "python/quoridor_training/snapshot.py",
            "scripts/dev/project-env.sh",
            "pyproject.toml",
            "uv.lock",
        ]
    ]
    before = [lc.bound(path)[0] for path in subject_paths]
    assert (
        before[0]["sha256"]
        == "ced9aef1c7406d62c4dada9b81e0ac84c19de4ab53ad0d916b89f77249152769"
    )
    assert before[0]["bytes"] == 204788
    manifest = lc.accepted_build(BUILD)
    assert manifest["artifact"] == ARTIFACT
    recipe_ref, recipe_raw = lc.bound(RECIPE)
    recipe = json.loads(recipe_raw)
    library_record = Path(
        "/workspaces/quoridor/.worktree/cheap-static-ordering376/.artifacts/cheap-static-ordering376-v1/adopted379-preparation-v1/common-image-binding-v1/process-00-A/experiment.json"
    )
    library_metadata_ref, raw = lc.bound(library_record)
    libraries = json.loads(raw)["dynamic_libraries"]
    for library in libraries:
        assert lc.artifact_ref(library["file"]["path"]) == library["file"]
    perf_tool = lc.artifact_ref("/usr/bin/perf")
    current_python = lc.artifact_ref(str(Path(sys.executable).resolve()))
    caller_sources = before[:4]
    # Standard submit launches its supervisor through the public environment entry.
    job_text = (MAIN / "scripts/dev/research-job.py").read_text()
    assert 'str(Path(__file__).with_name("project-env.sh"))' in job_text
    assert '"--config"' in job_text and '"--state-dir"' in job_text
    env = {
        key: os.environ[key]
        for key in [
            "PATH",
            "HOME",
            "PYTHONPATH",
            "QUORIDOR_PROJECT_ROOT",
            "QUORIDOR_PROJECT_ENV",
            "UV_PROJECT_ENVIRONMENT",
            "VIRTUAL_ENV",
            "UV_CACHE_DIR",
            "UV_PYTHON_INSTALL_DIR",
        ]
        if key in os.environ
    }
    env.update(
        {
            "CUDA_VISIBLE_DEVICES": "",
            "OMP_NUM_THREADS": "1",
            "OPENBLAS_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "NUMEXPR_NUM_THREADS": "1",
            "ORT_DISABLE_TELEMETRY": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "UV_NO_SYNC": "1",
            "UV_OFFLINE": "1",
        }
    )
    RUNS.mkdir()
    entries = []
    for index, chosen in enumerate(recipe["passes"]):
        label = f"{index:02d}-{chosen['role']}-{chosen['mode']}"
        base = RUNS / label
        base.mkdir()
        settings, requests = lc.measurement_config(
            {
                "config": chosen["config"],
                "schedule": chosen["schedule"],
                "inputs": recipe["inputs"],
                "rules": json.loads(lc.read_ref(chosen["config"]))["namespace"][
                    "rules"
                ],
            }
        )
        experiment = {
            "schema": "quoridor.research.experiment.v1",
            "phase": "compare",
            "build_manifest": BUILD,
            "config": chosen["config"],
            "inputs": recipe["inputs"],
            "models": recipe["models"],
            "dynamic_libraries": libraries,
            "schedule": chosen["schedule"],
            "numerical_qualification": None,
            "canonical_plan_sha256": "",
            "rules": settings["namespace"]["rules"],
            "distance_units": "wall-distance/80",
            "value_perspective": "side-to-move",
            "planned_slots": len(requests),
            "batch": index,
            "argv": [
                ARTIFACT["path"],
                "measure",
                "--experiment",
                "@EXPERIMENT@",
                "--experiment-sha256",
                "@EXPERIMENT_SHA256@",
            ],
        }
        write(base / "experiment.json", experiment)
        experiment_ref = lc.bound(base / "experiment.json")[0]
        data_root, tmp = base / "native", base / "TMP"
        spec = {
            "schema": "quoridor.research.lifecycle-intent.v1",
            "kind": "run",
            "owner": str(OWNER),
            "cwd": str(MAIN),
            "output": str(base / "operation-v1"),
            "data_root": str(data_root),
            "owned_outputs": [
                str(HERE),
                str(OWNER / "configured-entry-v1/runs"),
                str(tmp),
            ],
            "TMP": str(tmp),
            "artifact": ARTIFACT,
            "experiment": experiment_ref,
            "caller_sources": caller_sources,
            "finalizers": [],
            "limits": {
                "family_B": 2147483648,
                "controller_B": 67108864,
                "host_reserve_B": 4294967296,
                "owned_B": 83886080,
                "log_B": 2097152,
                "free_B": 4294967296,
                "worker_cpu": worker_cpu,
                "guardian_cpu": guardian_cpu,
            },
            "env": {
                **env,
                "TMPDIR": str(tmp),
                "PERF_BUILDID_DIR": str(base / "buildid-cache"),
            },
            "data": [
                {
                    "name": name,
                    "path": str(data_root / filename),
                    "limit_B": settings["output_bytes"],
                }
                for name, filename in [
                    ("settings", "settings.json"),
                    ("measurements", "measurements.jsonl"),
                    ("result", "result.json"),
                ]
            ],
            "perf": None,
        }
        if chosen["perf_settings"] is not None:
            spec["perf"] = {
                "tool": perf_tool,
                "output": str(base / "perf.data"),
                **chosen["perf_settings"],
            }
            spec["data"].append(
                {
                    "name": "perf_RAW",
                    "path": spec["perf"]["output"],
                    "limit_B": spec["perf"]["data_max_bytes"],
                }
            )
        native_argv = [
            arg.replace("@EXPERIMENT@", experiment_ref["path"]).replace(
                "@EXPERIMENT_SHA256@", experiment_ref["sha256"]
            )
            for arg in experiment["argv"]
        ]
        spec["argv"] = lc.measurement_argv(spec, experiment, native_argv)
        spec["intent_sha256"] = lc.canonical_sha(spec)
        write(base / "intent.json", spec)
        intent = lc.bound(base / "intent.json")[0]
        metadata_error = None
        try:
            lc.experiment_check(spec)
            limits = lc.Limits(spec)
            limits.check()
        except lc.Refused as failure:
            metadata_error = lc.error_fact(failure)
        job = {
            "issue": "quoridor-4lc.349",
            "goal_issue": "quoridor-4lc",
            "thread_id": "01a11004-79f3-7c20-872c-432a2c347664",
            "cwd": str(MAIN),
            "argv": [
                sys.executable,
                "-B",
                str(MAIN / "scripts/dev/research-lifecycle.py"),
                "run",
                "--intent",
                intent["path"],
                "--sha256",
                intent["sha256"],
            ],
            "resource_contract": intent["path"],
            "end_at": None,
            "notify_until": None,
            "max_runtime_seconds": None,
            "control_interval_seconds": 30,
            "notify_interval_seconds": 10,
            "request_timeout_seconds": 25,
            "log_max_bytes": 16384,
        }
        write(base / "job.json", job)
        job_ref = lc.bound(base / "job.json")[0]
        entries.append(
            {
                "label": label,
                "experiment": experiment_ref,
                "intent": intent,
                "job": job_ref,
                "submit_argv": [
                    "/usr/bin/bash",
                    str(MAIN / "scripts/dev/project-env.sh"),
                    "python",
                    "-B",
                    str(MAIN / "scripts/dev/research-job.py"),
                    "submit",
                    "--config",
                    job_ref["path"],
                    "--state-dir",
                    str(base / "runtime-v1"),
                ],
                "current_metadata_check": "PASS"
                if metadata_error is None
                else "REFUSED",
                "exact_refusal": metadata_error,
                "planned_calls": len(requests),
                "sessions": len({r["session"] for r in requests}),
                "node_liability": sum(r["node_cap"] for r in requests),
                "collector_argv_template": [
                    sys.executable,
                    "-B",
                    str(MAIN / "scripts/dev/research-lifecycle.py"),
                    "finalize",
                    "--operation",
                    spec["output"],
                    "--job-result",
                    str(base / "runtime-v1/result.json"),
                    "--sha256",
                    "<actual-original-job-result-SHA>",
                ],
            }
        )
    assert before == [lc.bound(path)[0] for path in subject_paths], (
        "actual current caller drift"
    )
    assert lc.artifact_ref(ARTIFACT["path"]) == ARTIFACT
    facts = {
        "recipe": recipe_ref,
        "Build": BUILD,
        "Artifact_readonly": ARTIFACT,
        "entries": entries,
        "current_common_sys_executable": sys.executable,
        "actual_regular_Python": current_python,
        "environment": env,
        "caller_sources": caller_sources,
        "common_entry_environment_refs": before[4:],
        "runtime_five_libraries": libraries,
        "library_metadata_origin": library_metadata_ref,
        "actual_standard_perf_tool": perf_tool,
        "native_boundary": "Authentic accepted compatible BUILD owns the newly verified RAW predicate; no Main Rust inventory/equality or native probe.",
        "actual_parent_available_CPUs_before_guard": available,
        "selected_worker_cpu": worker_cpu,
        "selected_guardian_cpu": guardian_cpu,
        "normal_measure_route_requires_separate_admission": False,
        "bulk_storage": {
            "whole_B": 83886080,
            "charged_owned_roots": [str(HERE), str(OWNER / "configured-entry-v1/runs")],
            "real_FS_reserve_B": 4294967296,
            "old_category_caps": "NOT_USED",
            "ordinary_preparation_storage": None,
            "used_bytes_not_forecast": True,
        },
        "counts": {
            "planned_calls": sum(e["planned_calls"] for e in entries),
            "sessions": sum(e["sessions"] for e in entries),
            "node_liability": sum(e["node_liability"] for e in entries),
        },
        "ordinary_directed_preparation_usage_before_receipt_B": lc.allocated(
            HERE, seen=set()
        ),
        "usage_scope": "One new prepared-inputs namespace observation before receipt, excludes untouched shared image/assets and old namespace; not global occupancy or peak.",
        "original_configured_packet": str(
            OWNER / "configured-entry-v1/prepared-inputs.json"
        ),
        "source_image_environment_metadata_reader_STOP": datetime.now(
            timezone.utc
        ).isoformat(),
        "actual_operation_native_Search_perf_model_library_load_Cargo_calls": 0,
        "jobs_submitted": 0,
        "common_entry_sys_executable_for_job_and_collector": True,
        "science_status": "UNENTERED; no quiet-slot selection or current-profile result claimed",
    }
write(HERE / "prepared-inputs.json", facts)
print(
    json.dumps(
        {
            "status": "STOPPED_PREP_METADATA_CHECKED_NO_SCIENTIFIC_LAUNCH",
            "entries": [
                {
                    "label": e["label"],
                    "metadata": e["current_metadata_check"],
                    "error": e["exact_refusal"],
                }
                for e in entries
            ],
            "counts": facts["counts"],
        }
    )
)
