"""Collect the original failed profiler launch; never launch scientific work."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "collection-v2"


def read_record(relative, expected=None):
    path = HERE / relative
    raw = path.read_bytes()
    ref = {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }
    if expected:
        assert (ref["sha256"], ref["bytes"]) == expected
    return ref, raw


refs = {}
records = {}
for name, expected in {
    "runtime-v2/result.json": (
        "fa7107dc63d56810bccf570adc2e8ac9a5be862981808735041a9c63419751f6",
        505,
    ),
    "operation-v1/candidate.json": (
        "27bf00c2c586e64bb58c045aaded8d66be931157d2a076af110209cc3ccf60aa",
        8963,
    ),
    "operation-v1/manifest.json": (
        "f434bb182eb0420cdcd99cb3cbd7ed39873044c7dbdd3d85bd9a3ee3fd4aff4a",
        12941,
    ),
    "operation-v1/run.process.json": (
        "1688a64b8c8f850d87fd5f97de305facb2b80d11241b8c436be0814e25fac9b5",
        3178,
    ),
    "runtime-v2/state.json": None,
    "operation-v1/storage-usage.json": None,
}.items():
    refs[name], raw = read_record(name, expected)
    records[name] = json.loads(raw)
refs["operation-v1/run.full.log"], log = read_record(
    "operation-v1/run.full.log",
    ("48e8400602634f54dfa79fc945233fc1fd18d92605fbfcd9ee68056b5998c63e", 197),
)
refs["runtime-v2/output.log"], _ = read_record(
    "runtime-v2/output.log",
    ("3be27a2c15e50e9fb041bff79f12b5d7ad670e65e1fbef87d2c27b3ff1e9e128", 11376),
)
result = records["runtime-v2/result.json"]
manifest = records["operation-v1/manifest.json"]
process = records["operation-v1/run.process.json"]
state = records["runtime-v2/state.json"]
assert result["job_id"] == "0531067e-46da-4ca5-8ef4-bd7461cf0353"
assert manifest["status"] == "FAILED" and process["exit_code"] == 129
assert manifest["checks"][0]["guardian_return"] is None
assert not manifest["checks"][0]["capture_complete"]
absent = []
for name in ("native", "TMP", "perf.data", "operation-v1/INCOMPLETE"):
    path = HERE / name
    assert not os.path.lexists(path), f"unexpected retained path: {path}"
    absent.append(str(path))
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
identities = []
for expected in (state["supervisor"], state["child"], process["child"]):
    path = Path(f"/proc/{expected['pid']}/stat")
    actual = None
    if path.exists():
        fields = path.read_text().rsplit(")", 1)[1].split()
        actual = {"pid": expected["pid"], "start_ticks": fields[19], "boot_id": boot}
        assert actual != expected, "original process remains"
    identities.append(
        {
            "expected": expected,
            "actual": actual,
            "state": "DIFFERENT" if actual else "ABSENT",
        }
    )
facts = {
    "issue": "quoridor-4lc.349",
    "job": result["job_id"],
    "status": "FAILED_PROFILER_ARGUMENT_PARSING",
    "references": refs,
    "literal_profiler_stderr": log.decode(),
    "limitation": "Perf returned usage for --max-size 12582912, exit129. No native output or RAW exists. Exact parser expectation is not inferred from a new tool probe.",
    "normal_finalization": {
        "invoked_once": True,
        "exit_code": 1,
        "manifest_status": manifest["status"],
        "authoritative_finished_at": manifest["authoritative_finished_at"],
        "INCOMPLETE_absent": True,
    },
    "outer_process_facts": result,
    "original_persisted_profiler_process_facts": process,
    "original_manifest_cleanup_complete": manifest["cleanup_complete"],
    "original_manifest_process_cleanup_complete": manifest["process_cleanup_complete"],
    "original_guardian_return": None,
    "original_command_capture_complete": False,
    "cleanup_distinction": "Original lifecycle FAILED/cleanupfalse/null return/capturefalse is preserved alongside persisted profiler reaped/cleanuptrue and outer cleanuptrue; persisted mask pending/final-record attempted remain unchanged.",
    "primary": manifest["primary"],
    "controller_seconds_once": result["wall_seconds"],
    "nested_profiler_seconds_not_added": process["wall_seconds"],
    "scientific_scope": {
        "planned_this_pass": 6,
        "recorded_calls": 0,
        "unperformed_this_pass": 6,
        "native_census": None,
        "perf_samples": None,
        "campaign_performed": 6,
        "campaign_planned": 36,
        "campaign_unentered": 30,
    },
    "original_process_observations": identities,
    "absent_paths": absent,
    "source_model_input_library_image_after": "No native/model/input/library session entered; no new qualification or payload probe. Original worker did not publish after-read refs. No current scientific PASS inferred.",
    "original_release_UTC": "UNKNOWN; original exit/reap and fresh exact identity absence recorded",
    "actual_owned_metadata_reader_STOP": datetime.now(timezone.utc).isoformat(),
    "owned": {
        "readers": [],
        "children": [],
        "jobs": [],
        "TMP": [],
        "leases": [],
        "reservation": None,
    },
    "next_input": "Owning ordinary perf --max-size argument correction before a unique unfinished sampled entry; original six calls remain unperformed. No retry or next pass submitted.",
    "old_runtime_v1_preserved": True,
    "measurement_settings_unchanged": True,
    "retry_or_next_pass_submitted": False,
    "postwork_usage": records["operation-v1/storage-usage.json"],
}
OUT.mkdir()
path = OUT / "collection-result.json"
path.write_text(json.dumps(facts, indent=2) + "\n")
ref, _ = read_record("collection-v2/collection-result.json")
print(
    json.dumps(
        {
            "collection": ref,
            "STOP": facts["actual_owned_metadata_reader_STOP"],
            "identities": identities,
            "calls": 0,
            "status": facts["status"],
        }
    )
)
