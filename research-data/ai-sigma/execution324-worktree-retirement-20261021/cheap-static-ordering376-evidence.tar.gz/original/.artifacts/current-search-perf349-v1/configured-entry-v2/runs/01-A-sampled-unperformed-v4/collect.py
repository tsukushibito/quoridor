"""Preserve the original permission-error measurement result and retained RAW."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
OUT = HERE / "collection-v1"


def stamp():
    return datetime.now(timezone.utc).isoformat()


def read(relative, expected=None):
    path = HERE / relative
    raw = path.read_bytes()
    ref = {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }
    if expected:
        assert (ref["sha256"], ref["bytes"]) == expected
    return ref, raw


refs = {}
records = {}
for relative, expected in {
    "runtime-v1/result.json": (
        "6f58c50491a4026e0c76d0a2054a97bf8ef9881de49c73e4aa1d89f1379c76a3",
        506,
    ),
    "operation-v1/candidate.json": (
        "c14e76d29291b328fcc4e45ec458fbd154aaff29994fea7e21829b5b57038d4e",
        9349,
    ),
    "operation-v1/manifest.json": (
        "e880f33c090361cf875758b7e90bd0fef297cc69aadf4f6f7eee9668603184b5",
        13164,
    ),
    "operation-v1/run.process.json": (
        "c7dee022a0978038c262b41089d7a92466ee006c71864a235646d3c25151d5b4",
        3277,
    ),
    "runtime-v1/state.json": None,
    "operation-v1/storage-usage.json": None,
    "intent.json": (
        "9f50ba1a85d51fc0bafbbd48d792f43eb2bbc5402fc40dd6b53dfde8aaca36f3",
        7328,
    ),
    "launch.json": None,
}.items():
    refs[relative], raw = read(relative, expected)
    records[relative] = json.loads(raw)
refs["operation-v1/run.full.log"], log = read(
    "operation-v1/run.full.log",
    ("60cc86290abdda25a1ae3ca18efa1cf618687dc5a717849704c6a5d299475b64", 281),
)
refs["runtime-v1/output.log"], _ = read(
    "runtime-v1/output.log",
    ("5189927f02257c092a480e02876fa2a5fbbbf3822af09edc412f3ad4d6a3f3df", 11510),
)
refs["perf.data"], _ = read(
    "perf.data",
    ("2c9dbf13dcb62f39226f11f0aad3aca70b76414dab40bc5f248512b4c4245d9b", 19292),
)
assert refs["perf.data"]["mode"] == "0600" and not (HERE / "perf.data").is_symlink()
manifest = records["operation-v1/manifest.json"]
process = records["operation-v1/run.process.json"]
result = records["runtime-v1/result.json"]
state = records["runtime-v1/state.json"]
assert result["job_id"] == "81c6b866-b03f-46fc-943c-4bd5c4d8ceec"
assert manifest["status"] == "FAILED" and process["exit_code"] == 1
assert manifest["checks"][0]["guardian_return"] is None
assert not manifest["checks"][0]["capture_complete"]
absent = []
for name in ["native", "TMP", "operation-v1/INCOMPLETE"]:
    assert not os.path.lexists(HERE / name)
    absent.append(str(HERE / name))
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
identities = []
for expected in [state["supervisor"], state["child"], process["child"]]:
    path = Path(f"/proc/{expected['pid']}/stat")
    actual = None
    if path.exists():
        fields = path.read_text().rsplit(")", 1)[1].split()
        actual = {"pid": expected["pid"], "start_ticks": fields[19], "boot_id": boot}
        assert actual != expected, "original process remains"
    identities.append(
        {
            "expected": expected,
            "actual": actual,
            "state": "DIFFERENT" if actual else "ABSENT",
        }
    )
# One current owning after-reference check; no model/library loading or tool execution.
after_guard = {"status": "UNKNOWN", "error": None}
available = set(os.sched_getaffinity(0))
try:
    with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "r"
    ) as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        loader = importlib.util.spec_from_file_location(
            "failed349_after_metadata", MAIN / "scripts/dev/research-lifecycle.py"
        )
        lc = importlib.util.module_from_spec(loader)
        sys.modules[loader.name] = lc
        loader.loader.exec_module(lc)
        spec = records["intent.json"]
        lc.physical_and_quiet(spec)
        lc.experiment_check(spec)
        experiment = lc.document(spec["experiment"])
        after_guard = {
            "status": "MATCH",
            "caller_sources": spec["caller_sources"],
            "experiment": spec["experiment"],
            "artifact": spec["artifact"],
            "config": experiment["config"],
            "schedule": experiment["schedule"],
            "inputs": experiment["inputs"],
            "models": experiment["models"],
            "libraries": experiment["dynamic_libraries"],
            "reader_STOP": stamp(),
            "scope": "Existing Run identity guard only; no payload inference/library/model load or new qualification.",
        }
    after_guard["canonical_release"] = stamp()
except BaseException as error:
    after_guard["error"] = {"type": type(error).__name__, "message": str(error)}
    after_guard["reader_STOP"] = stamp()
finally:
    os.sched_setaffinity(0, available)
facts = {
    "issue": "quoridor-4lc.349",
    "job": result["job_id"],
    "status": "FAILED_PERMISSION_ERROR_NO_NATIVE_MEASUREMENT_RECORDS",
    "references": refs,
    "literal_full_log": log.decode(),
    "normal_finalization": {
        "invoked_once": True,
        "exit_code": 1,
        "manifest_status": manifest["status"],
        "finished_at": manifest["authoritative_finished_at"],
        "INCOMPLETE_absent": True,
    },
    "primary": manifest["primary"],
    "manifest_cleanup_complete": manifest["cleanup_complete"],
    "manifest_process_cleanup_complete": manifest["process_cleanup_complete"],
    "returned_guardian": None,
    "capture_complete": False,
    "original_persisted_process_facts": process,
    "outer_job_facts": result,
    "cleanup_distinction": "Original lifecycle cleanupfalse/null guardian/capturefalse retained separately from persisted and outer direct-reaped cleanuptrue. Original persisted signal-mask pending/final-record attempted are not upgraded.",
    "actual_original_identity_observations": identities,
    "absent_paths": absent,
    "RAW": refs["perf.data"],
    "RAW_interpretation": "Retained failed-launch RAW, not decoded or claimed sufficient; counters/samples/callchains UNKNOWN. Exact denied syscall/object not identified by281B log.",
    "scientific_scope": {
        "planned_calls": 6,
        "recorded_calls": 0,
        "recorded_complete": 0,
        "uncompleted_calls": 6,
        "actual_native_execution_extent": "UNKNOWN; no native identity/settings/journal/result available",
        "campaign_completed": 6,
        "campaign_planned": 36,
        "campaign_remaining": 30,
        "perf_sufficiency": "UNKNOWN",
    },
    "controller_seconds_once": result["wall_seconds"],
    "nested_perf_seconds_not_added": process["wall_seconds"],
    "current_after_identity_guard": after_guard,
    "original_release_UTC": "UNKNOWN; exact original exit/reap plus fresh absence preserved",
    "actual_metadata_reader_STOP": stamp(),
    "owned": {
        "readers": [],
        "children": [],
        "jobs": [],
        "TMP": [],
        "leases": [],
        "reservation": None,
    },
    "postwork_usage": records["operation-v1/storage-usage.json"],
    "next_condition": "Permission denied(os error13) in sampled launch before native measurement records; exact boundary unresolved. Preserve RAW, identify owning denied object/syscall before any genuinely unfinished entry. No production guard/permission waiver or automatic retry.",
    "retry_or_next_pass_submitted": False,
}
OUT.mkdir()
(OUT / "collection-result.json").write_text(json.dumps(facts, indent=2) + "\n")
collection, _ = read("collection-v1/collection-result.json")
print(
    json.dumps(
        {
            "collection": collection,
            "STOP": facts["actual_metadata_reader_STOP"],
            "identities": identities,
            "after_guard": after_guard["status"],
            "after_error": after_guard.get("error"),
            "remaining_calls": 30,
        }
    )
)
