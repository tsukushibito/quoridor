"""Finite owning software checks via the maintained command guardian; no BUILD/Run claim."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
SOURCE = HERE / "after/scripts/dev/research-lifecycle.py"
CYCLE = HERE / "after/python/quoridor_training/cycle_process.py"
OUT = HERE / "actual-checks-v6"
TMP = OUT / "TMP"


def reference(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
    }


# Bootstrap reader ownership precedes importing the exact owned guard and its ordinary helpers.
with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
    "r"
) as bootstrap:
    fcntl.flock(bootstrap, fcntl.LOCK_EX | fcntl.LOCK_NB)
    import quoridor_training

    quoridor_training.__path__.insert(0, str(CYCLE.parent))
    module = importlib.util.spec_from_file_location("owned349_lifecycle", SOURCE)
    lc = importlib.util.module_from_spec(module)
    module.loader.exec_module(lc)
    assert Path(lc.process.__file__).resolve() == CYCLE
    subjects = [
        SOURCE,
        CYCLE,
        HERE / "after/tools/research-session/test_lifecycle.py",
        HERE / "after/tools/research-session/test_lifecycle_storage.py",
        Path(__file__),
        MAIN / "scripts/dev/project-env.sh",
        MAIN / "python/quoridor_training/snapshot.py",
    ]
    before = [reference(p) for p in subjects]
    fcntl.flock(bootstrap, fcntl.LOCK_UN)

spec = {
    "cwd": str(MAIN),
    "kind": "software",
    "limits": {
        "family_B": 536870912,
        "host_reserve_B": 4294967296,
        "worker_cpu": 1,
        "guardian_cpu": 4,
        "log_B": 2097152,
    },
    "env": {
        **os.environ,
        "RESEARCH_TEST_ROOT": str(MAIN),
        "RESEARCH_LIFECYCLE_SOURCE": str(SOURCE),
        "RESEARCH_CYCLE_SOURCE": str(CYCLE),
        "TMPDIR": str(TMP),
        "PYTHONDONTWRITEBYTECODE": "1",
    },
}
checks = []
error = None
try:
    lc.physical_and_quiet(spec)
    with lc.lease(), lc.process.cancellation_signals():
        assert before == [reference(p) for p in subjects], (
            "actual subject drift before checks"
        )
        OUT.mkdir()
        TMP.mkdir()
        resources = lc.process.CycleResources(
            {
                "host_ram_reserve": 4294967296,
                "max_memory_bytes": 536870912,
                "max_output_bytes": None,
            },
            OUT,
            None,
        )
        for name, pattern, selected, count in [
            (
                "unbudgeted-construction",
                "test_lifecycle_storage.py",
                "test_unbudgeted_guards_do_not_scan_and_keep_pause_memory",
                1,
            ),
        ]:
            row = {
                "name": name,
                "role": "software",
                "argv": [
                    sys.executable,
                    "-B",
                    "-m",
                    "unittest",
                    "discover",
                    "-s",
                    str(HERE / "after/tools/research-session"),
                    "-p",
                    pattern,
                    "-k",
                    selected,
                    "-v",
                ],
            }
            _, full = lc.command(spec, row, OUT, resources, ledger=checks)
            text = full.read_text()
            assert re.search(rf"Ran {count} tests? in", text) and re.search(
                r"^OK$", text, re.M
            ), "partial/zero/wrong test census"
        assert before == [reference(p) for p in subjects], (
            "actual subject drift after checks"
        )
        TMP.rmdir()
except BaseException as failure:
    error = lc.error_fact(failure)
finally:
    if TMP.exists() and not list(TMP.iterdir()):
        TMP.rmdir()
    OUT.mkdir(exist_ok=True)
    seen = set()
    used = lc.allocated(OUT, seen=seen)
    facts = {
        "status": "PASS" if error is None else "FAILED",
        "subject_before": before,
        "subject_after": [reference(p) for p in subjects],
        "checks": checks,
        "primary": error,
        "actual_reader_STOP": datetime.now(timezone.utc).isoformat(),
        "remaining": {
            "readers": [],
            "children": [],
            "jobs": [],
            "TMP": list(map(str, TMP.iterdir())) if TMP.exists() else [],
            "leases": [],
            "reservation": None,
        },
        "storage_budget_B": None,
        "observed_check_retention_B": used,
        "usage_scope": "Actual named test output retention before this final admin receipt; no storage scan on ordinary guard ticks. Not global usage or peak.",
        "native_Cargo_model_Search_perf_calls": 0,
        "scope": "Two changed final-subject owning synthetic filesystem/metadata assertions against exact OWN modules; native3/Python2 Perf remainUNRUN, no production integration claim.",
    }
    lc.new_json(OUT / "result.json", facts)
if error is not None:
    raise SystemExit(1)
print(
    json.dumps(
        {"status": "PASS", "owning_assertions": 1, "result": str(OUT / "result.json")}
    )
)
