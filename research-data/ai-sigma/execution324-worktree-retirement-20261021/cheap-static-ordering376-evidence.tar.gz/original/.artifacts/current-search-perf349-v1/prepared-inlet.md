# Current-search Perf349 stopped preparation

The current f727 image has usable symbol and unwind metadata, but cannot admit the selected six-call passes. One minimum owning caller/Run change and one affected common image are necessary. No optimization, build, native workload, model load or perf event was run.

The fixed question is A plain-before/sampled/plain-after, then B in the same order: cold D4 family102, cold D6 family34, then warm D4 family0 at chronological local ply0/2/4/6 (original indices4/5/6/7). Every pass has fresh cold sessions and one fresh chronological warm session. The frozen projection has 36 calls, 18 sessions, 108M node liability, 24 plain and12 sampled calls. Scores/model/TT/PVS/history and all original376 failures remain unchanged.

## Exact owning limitations

Current `ordering_assessment.rs` CheapPlan/validate_cheap (94–225), preparation (227–280) and run_impl (1131 onward) bind 20 calls, original80 schedule and376 support; current Python `cheap_ordering_inputs` (725 onward) repeats that boundary. Use the same maintained replay/model/session/journal/finalization owner with an explicit selected349 projection and plan. Filtering old20 outputs or submitting six calls under original80 authority is invalid.

Current Python `experiment_check` (1739/1746) requires nativeartifact argv, and native `research_manifest.rs` (392–459) requires the guardian as immediate parent and exact native argv. A literal `perf record … -- NATIVE …` breaks those guarantees. The minimum standard-wrapper extension must bind the authentic perf tool/static argv and actual guardian→perf→native identities, native artifact/argv and complete startup/directwait/drain/cancel/flush/cleanup. Do not spoof the parent variable or waive origin checks. A late PID attachment cannot establish complete setup coverage. This is a concrete existing owning-boundary change, not a second lifecycle.

The prospective native command remains `QUALIFIED_NEW_NATIVE ordering-cheap-assess --experiment ABS --experiment-sha256 SHA`; ordinary Run stays the current qualified common-entry Python and maintained research-job/onceFinalize path. The record argv in runtime-plan.json is standard-tool syntax, not a currently admissible spec.

## Sampling and attribution

Freeze 99Hz software `cpu-clock:u`, DWARF8192, 64 ring pages, two32MiB files and `--no-buildid-cache`. At99Hz the maximum stack payload is 811008B per sampled CPU-second before record overhead; that arithmetic is no elapsed prediction or guarantee of sufficient samples. Current perf6.1.187 supports DWARF/libunwind/libdw; event access was not probed. Available kernel sample-rate100000/stack127/paranoid2 are metadata, not runtime admission. No hardware cycles or kernel-cost inference.

ELF f727 has `.symtab`, `.strtab`, `.eh_frame`/header and build-id42bdf985540a12b495d3658c04b4c560d313bbb5, without debug/line/inline info. Selected Search::ordered/child, map generation, delta, residual head, TT/context/history, make_move and sort symbols, plus selected unwind FDEs, support function-level profiling. `validate_maps` has no independent named symbol; preparation/validation and other inlined costs may remain merged or unresolved. A debug/flags rebuild is not required by these metadata facts. Runtime stack quality and the causal validation share remain UNKNOWN.

Keep self and inclusive reports separate, never add overlapping inclusive percentages. Show model/map generation/validation/prepare/score/sort, TT/hash/context/history, feature/delta/head, legal generation/make/unmake where resolvable. Native whole-root includes setup/drop/replay/maps/sort/history/journals; outer model/request/selfdigest/Run/profiler/report/admin domains are also retained without adding nested clocks. Compare all three passes within each role for depth/value bits/action/PV/work/parent. Report bracket plain observations and sampled overhead separately, preserving A/B work differences.

## Issued support and exact unfinished inputs

Actual95cb support issues80MiB: data64, controls4, native/results/reports4, serialTMP2, failure/cleanup2, review2, Root/Git2. The practical subcaps and full-output policy are in runtime-plan.json. Size/lost/unwind/access/flush/capped results remain honest FAILED/UNKNOWN without refill; native complete depth does not imply sufficient samples. No elapsed deadline/kill estimate is proposed. Old preliminary whole-resource-request.json stays immutable and is superseded by the actual support.

The necessary caller image/build has zero authority in that80MiB. A concrete prospective42MiB bound is target growth24 + private/custody12 + serialsoftwareTMP4 + software captures/finalizers/failure2; finish is not guaranteed. Root may settle genuinely available existing held376 components or one compatible arena build after actual source/target STOP. Current349 target/private floor/cap/marker/union and software custody are unsupplied. No new global grant or transfer is presumed; current global49996492800 remains held.

Next ordinary step is Root settlement of the smallest affected caller/profiler-origin implementation and genuine single image software scope, then exact current Run specs/admissions and fresh quiet/custody guards. Original model/head evidence stays its historical scope; no new head/Q/model probe or old successful suite is necessary. Arena374 actual software/timing lifetime keeps priority, without an all-games/admin/Policy acknowledgement gate.

## Stopped scope

Current source identities are recorded in current-inlet-refs.json; current publisher4d0e8d40 is distinct from historical376 caller refs. Main/ELF readers last stopped at2026-10-13T01:58:09.312269+00:00 after synchronous directwait and canonical/env release. The later support read was metadata only. All owned scientific readers/children/jobs/TMP/leases are empty; no hardware reservation. Formatting and closure/admin occur afterward. Before/after private stat identities matched; its payload SHA was not rehashed for this inspection and remains original read-only custody. Future entry must check actual immutable artifact/runtime/model/input/library identities.
