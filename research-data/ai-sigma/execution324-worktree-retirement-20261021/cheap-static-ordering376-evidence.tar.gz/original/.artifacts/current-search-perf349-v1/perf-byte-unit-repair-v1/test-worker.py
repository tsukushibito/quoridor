"""One affected NN0 metadata definition through the maintained software guardian."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
SOURCE = HERE / "after/scripts/dev/research-lifecycle.py"
TEST = HERE / "after/tools/research-session/test_measurement.py"
OUT = HERE / "author-check-v1"
TMP = OUT / "TMP"
NAME = "test_perf_max_size_renders_exact_byte_unit"


def stamp():
    return datetime.now(timezone.utc).isoformat()


def reference(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
    "r"
) as bootstrap:
    fcntl.flock(bootstrap, fcntl.LOCK_EX | fcntl.LOCK_NB)
    loader = importlib.util.spec_from_file_location(
        "perf_unit_current_guard", MAIN / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    sys.modules[loader.name] = lc
    loader.loader.exec_module(lc)
    subjects = [
        SOURCE,
        TEST,
        Path(__file__),
        MAIN / "scripts/dev/research-lifecycle.py",
        Path(lc.process.__file__),
        MAIN / "scripts/dev/project-env.sh",
        MAIN / "pyproject.toml",
        MAIN / "uv.lock",
        Path(sys.executable).resolve(),
    ]
    before = [reference(p) for p in subjects]
available = sorted(os.sched_getaffinity(0))
assert {1, 4} <= set(available), "actual worker1/guardian4 affinity required"
spec = {
    "cwd": str(MAIN),
    "kind": "software",
    "limits": {
        "family_B": 536870912,
        "controller_B": 67108864,
        "host_reserve_B": 4294967296,
        "worker_cpu": 1,
        "guardian_cpu": 4,
        "log_B": 2097152,
    },
    "env": {
        **os.environ,
        "TMPDIR": str(TMP),
        "PYTHONDONTWRITEBYTECODE": "1",
        "RESEARCH_TEST_ROOT": str(MAIN),
        "RESEARCH_LIFECYCLE_SOURCE": str(SOURCE),
    },
}
checks = []
primary = None
after = []
stop = None
release = None
try:
    lc.physical_and_quiet(spec)
    with lc.lease(), lc.process.cancellation_signals():
        try:
            assert before == [reference(p) for p in subjects], "pre-child source drift"
            OUT.mkdir()
            TMP.mkdir()
            resources = lc.process.CycleResources(
                {
                    "host_ram_reserve": 4294967296,
                    "max_memory_bytes": 536870912,
                    "max_output_bytes": None,
                },
                OUT,
                None,
            )
            row = {
                "name": "perf-byte-unit",
                "role": "software",
                "argv": [
                    sys.executable,
                    "-B",
                    "-m",
                    "unittest",
                    "discover",
                    "-s",
                    str(TEST.parent),
                    "-p",
                    TEST.name,
                    "-k",
                    NAME,
                    "-v",
                ],
            }
            _, full = lc.command(spec, row, OUT, resources, ledger=checks)
            captured = full.read_text()
            assert re.search(r"Ran 1 test in", captured) and re.search(
                r"^OK$", captured, re.M
            )
            assert "PerfRawOwnershipTests." + NAME in captured
        finally:
            if TMP.exists() and not list(TMP.iterdir()):
                TMP.rmdir()
            after = [reference(p) for p in subjects]
            assert before == after, "post-child source drift"
            stop = stamp()
    release = stamp()
except BaseException as error:
    primary = lc.error_fact(error)
finally:
    OUT.mkdir(exist_ok=True)
    usage = lc.allocated(HERE, seen=set())
    facts = {
        "status": "PASS" if primary is None else "FAILED",
        "primary": primary,
        "checks": checks,
        "subject_before": before,
        "subject_after": after,
        "selected": "PerfRawOwnershipTests." + NAME,
        "owning_assertions": 1 if primary is None else None,
        "actual_source_TMP_STOP": stop or stamp(),
        "actual_canonical_release": release,
        "public_entry_sys_executable": sys.executable,
        "public_entry_environment_release_UTC": "UNKNOWN until public entry returns",
        "parent_affinity_before_guard": available,
        "owned": {
            "readers": [],
            "jobs": [],
            "children": [],
            "TMP": list(map(str, TMP.iterdir())) if TMP.exists() else [],
            "leases": [],
            "reservation": None,
        },
        "storage_budget": None,
        "allocated_before_receipt_B": usage,
        "usage_scope": "One directed owned repair namespace observation, before receipt; no global occupancy or peak.",
        "Rust_test_status": "UNBUILT/UNTYPED/UNRUN",
        "native_model_head_Search_perf_calls": 0,
    }
    lc.new_json(OUT / "result.json", facts)
print(
    json.dumps(
        {
            "status": facts["status"],
            "primary": primary,
            "result": reference(OUT / "result.json"),
        }
    )
)
raise SystemExit(1 if primary else 0)
