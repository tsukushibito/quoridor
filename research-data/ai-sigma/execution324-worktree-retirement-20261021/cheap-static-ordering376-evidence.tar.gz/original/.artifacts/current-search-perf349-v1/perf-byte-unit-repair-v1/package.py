"""Package the sparse byte-unit correction and original owning verification."""

import ast
from datetime import datetime, timezone
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
PATHS = [
    "scripts/dev/research-lifecycle.py",
    "crates/quoridor-runner/src/research_manifest.rs",
    "tools/research-session/test_measurement.py",
]


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


before = {
    name: gzip.decompress(
        (HERE / "minimum-before" / (name.replace("/", "__") + ".gz")).read_bytes()
    ).decode()
    for name in PATHS
}
after = {name: (HERE / "after" / name).read_text() for name in PATHS}
assert after[PATHS[0]] == before[PATHS[0]].replace(
    '        str(perf["data_max_bytes"]),',
    '        str(perf["data_max_bytes"]) + "B",',
    1,
)
name = "measurement_perf_max_size_requires_exact_byte_unit"
rust = after[PATHS[1]]
start = rust.index("    #[test]\n    fn " + name)
end = rust.index(
    "    #[test]\n    fn measurement_configured_perf_and_actual_chain_shape", start
)
restored = rust[:start] + rust[end:]
restored = restored.replace(
    '        format!("{}B", perf.data_max_bytes),',
    "        perf.data_max_bytes.to_string(),",
    1,
)
restored = restored.replace(
    '                "12582912B".into(),', '                "12582912".into(),', 1
)
assert restored == before[PATHS[1]], "unrelated Rust body changed"
py = ast.parse(after[PATHS[2]])
cls = next(
    n
    for n in py.body
    if isinstance(n, ast.ClassDef) and n.name == "PerfRawOwnershipTests"
)
cls.body = [
    n
    for n in cls.body
    if not isinstance(n, ast.FunctionDef)
    or n.name != "test_perf_max_size_renders_exact_byte_unit"
]
assert ast.dump(py, include_attributes=False) == ast.dump(
    ast.parse(before[PATHS[2]]), include_attributes=False
)
patch = "".join(
    "".join(
        difflib.unified_diff(
            before[name].splitlines(True),
            after[name].splitlines(True),
            fromfile="a/" + name,
            tofile="b/" + name,
        )
    )
    for name in PATHS
)
reverse = "".join(
    "".join(
        difflib.unified_diff(
            after[name].splitlines(True),
            before[name].splitlines(True),
            fromfile="a/" + name,
            tofile="b/" + name,
        )
    )
    for name in PATHS
)
(HERE / "forward.patch").write_text(patch)
(HERE / "inverse.patch").write_text(reverse)
work = HERE / "inverse-check"
work.mkdir()
try:
    for name in PATHS:
        p = work / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(before[name])
    checks = []
    for path, expected in [
        (HERE / "forward.patch", after),
        (HERE / "inverse.patch", before),
    ]:
        completed = subprocess.run(
            ["/usr/bin/patch", "--batch", "--fuzz=0", "-p1", "-i", str(path)],
            cwd=work,
            capture_output=True,
            text=True,
        )
        assert (
            completed.returncode == 0
            and "offset" not in completed.stdout
            and "fuzz" not in completed.stdout
        )
        assert all((work / name).read_text() == expected[name] for name in PATHS)
        checks.append(
            {
                "patch": ref(path),
                "stdout": completed.stdout,
                "returncode": completed.returncode,
            }
        )
finally:
    shutil.rmtree(work)
result = json.loads((HERE / "author-check-v1/result.json").read_bytes())
assert result["status"] == "PASS" and result["owning_assertions"] == 1
facts = {
    "issue": "quoridor-4lc.349",
    "status": "STOPPED_ORDINARY_SOURCE_FIX",
    "base_capture": ref(HERE / "capture.json"),
    "after": {name: ref(HERE / "after" / name) for name in PATHS},
    "minimum_before": [
        ref(HERE / "minimum-before" / (name.replace("/", "__") + ".gz"))
        for name in PATHS
    ],
    "forward": ref(HERE / "forward.patch"),
    "inverse": ref(HERE / "inverse.patch"),
    "strict_forward_inverse": checks,
    "outside_scope": "Python production is one literal byte suffix only. Rust production one format expression; original metadata expectation one suffix; one new Rust metadata definition. Existing Python test AST unchanged after removing one new definition. All unrelated production/error/identity/chain/FD/cleanup bodies byte-exact.",
    "format": "Changed Python statement and new definition taken from project Ruff output; unrelated existing source formatting preserved. New Rust code scoped Rustfmt2024. Worker/package Ruff formatted and checked.",
    "Python_actual_check": ref(HERE / "author-check-v1/result.json"),
    "Python_selected": "PerfRawOwnershipTests.test_perf_max_size_renders_exact_byte_unit",
    "Rust_selected": "research_manifest::measurement_launch_tests::measurement_perf_max_size_requires_exact_byte_unit",
    "Rust_status": "UNBUILT/UNTYPED/UNRUN",
    "Rust_command": [
        "cargo",
        "test",
        "--offline",
        "--locked",
        "-j",
        "1",
        "-p",
        "quoridor-runner",
        "--lib",
        "--features",
        "measurement",
        "research_manifest::measurement_launch_tests::measurement_perf_max_size_requires_exact_byte_unit",
        "--",
        "--exact",
        "--test-threads=1",
    ],
    "remaining": "Root current Source/adoption and one genuinely affected compatible image: exact new Rust metadata assertion, full affected Clippy/release/current artifact. No original assertions replay. Native old dd199514 remains immutable and is not retargeted.",
    "scientific_scope": "No perf/native/model/head/Search calls. Selected49Hz/12582912-byte cap/36 workload unchanged; existing firstplain6 complete,30unentered. No pass submitted.",
    "optional_origin_TypeError": "Not changed: original primary/secondary and missing-data facts preserved; no broadening of this routine argv fix.",
    "actual_author_source_reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
    "owning_software_STOP": result["actual_source_TMP_STOP"],
    "canonical_release": result["actual_canonical_release"],
    "owned": {
        "readers": [],
        "children": [],
        "jobs": [],
        "TMP": [],
        "leases": [],
        "reservation": None,
    },
    "storage_budget": None,
    "directed_postwork_usage": {
        "allocated_B": result["allocated_before_receipt_B"],
        "scope": result["usage_scope"],
    },
}
(HERE / "source-STOP.json").write_text(json.dumps(facts, indent=2) + "\n")
print(
    json.dumps(
        {
            "STOP": ref(HERE / "source-STOP.json"),
            "after": facts["after"],
            "Python": facts["Python_actual_check"],
            "actual_STOP": facts["actual_author_source_reader_writer_STOP"],
        }
    )
)
