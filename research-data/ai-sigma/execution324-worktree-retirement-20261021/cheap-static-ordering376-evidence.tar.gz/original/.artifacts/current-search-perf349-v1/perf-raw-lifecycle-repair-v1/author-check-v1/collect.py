"""Collect only the saved new owning test and exact process identities."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "operation-v1"


def reference(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }, raw


result_ref, raw = reference(OUT / "result.json")
assert (result_ref["sha256"], result_ref["bytes"]) == (
    "750f27ed29667f0584cc4e9ad8b69e34c966566ab3fa448c5bf7232ffb65d452",
    8939,
)
result = json.loads(raw)
assert result["status"] == "PASS" and result["primary"] is None
assert result["subject_before"] == result["subject_after"]
assert len(result["checks"]) == 1 and result["passed_assertions"] == 1
check = result["checks"][0]
assert check["status"] == "PASS" and check["capture_complete"] is True
guardian = check["guardian_return"]
assert guardian["exit_code"] == 0 and guardian["cleanup_complete"] is True
assert guardian["direct_child_reaped"] is True and guardian["remaining"] == []
full_ref, full = reference(Path(check["full_log"]["path"]))
assert full_ref == check["full_log"]
lines = full.splitlines()
assert (
    sum(
        line.startswith(
            b"test_configured_raw_sibling_charged_and_absent_before_launch "
        )
        for line in lines
    )
    == 1
)
assert b"Ran 1 test" in full and full.rstrip().endswith(b"OK")
persisted_ref, persisted_raw = reference(
    Path(check["persisted_process_receipt"]["path"])
)
assert persisted_ref == check["persisted_process_receipt"]
persisted = json.loads(persisted_raw)
assert not (OUT / "TMP").exists()
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
identities = []
for expected in (result["worker_identity"], guardian["child"]):
    stat = Path(f"/proc/{expected['pid']}/stat")
    if not stat.exists():
        state = "ABSENT"
        actual = None
    else:
        fields = stat.read_text().rsplit(")", 1)[1].split()
        actual = {"pid": expected["pid"], "start_ticks": fields[19], "boot_id": boot}
        assert actual != expected, "original process identity still present"
        state = "DIFFERENT"
    identities.append({"expected": expected, "actual": actual, "state": state})
facts = {
    "issue": "quoridor-4lc.349",
    "related_issue": "quoridor-4lc.376.1",
    "status": "PASS",
    "selected_new_owning_assertions": 1,
    "subject": "Current Main f47bad46 Python RAW owning boundary only",
    "operation_result": result_ref,
    "full_capture": full_ref,
    "persisted_process_receipt": persisted_ref,
    "returned_guardian": guardian,
    "persisted_process_facts": persisted,
    "returned_vs_persisted": "Separate original facts; returned completed mask/persist statuses do not rewrite disk values.",
    "controller_wall_seconds_once": guardian["wall_seconds"],
    "nested_unittest_wall": "Not added to controller fee",
    "actual_source_TMP_reader_STOP": result["actual_source_TMP_reader_STOP"],
    "actual_canonical_release": result["actual_canonical_release"],
    "public_common_entry_return": {
        "exit_code": 0,
        "environment_SH_release_UTC": "UNKNOWN",
    },
    "exact_process_observations": identities,
    "source_before_after_exact": True,
    "TMP_exists": False,
    "remaining": {
        "readers": [],
        "children": [],
        "jobs": [],
        "TMP": [],
        "leases": [],
        "reservation": None,
    },
    "storage_budget": None,
    "directed_usage": {
        "allocated_B": result["allocated_usage_before_receipt_B"],
        "scope": result["usage_scope"],
    },
    "actual_metadata_reader_STOP": datetime.now(timezone.utc).isoformat(),
    "native_Cargo_perf_model_head_geometry_Search_calls": 0,
    "remaining_image_work": "Root owns native RAW metadata1/compatible Clippy-release; 742 remains old immutable. Rebind six entries only after genuine affected image.",
}
stop = HERE / "check-STOP.json"
stop.write_text(json.dumps(facts, indent=2) + "\n")
print(
    json.dumps(
        {
            "check_STOP": reference(stop)[0],
            "full_capture": full_ref,
            "persisted_masks": {
                key: persisted.get(key)
                for key in (
                    "signal_mask_restoration",
                    "final_record_persist",
                    "cleanup_complete",
                )
            },
            "exact_identities": identities,
        }
    )
)
