"""Static source correspondence and ordinary sparse handoff; no helper imports."""

import ast
from datetime import datetime, timezone
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
PYTHON = "scripts/dev/research-lifecycle.py"
RUST = "crates/quoridor-runner/src/research_manifest.rs"
TEST = "tools/research-session/test_measurement.py"


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


def publish(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + "\n")


def py_nodes(raw):
    return {
        node.name: ast.dump(node, include_attributes=False)
        for node in ast.parse(raw).body
        if isinstance(node, (ast.FunctionDef, ast.ClassDef))
    }


def py_function(raw, name):
    lines = raw.splitlines(keepends=True)
    node = next(
        node for node in ast.parse(raw).body if getattr(node, "name", None) == name
    )
    return "".join(lines[node.lineno - 1 : node.end_lineno]) + "\n"


def rust_function(raw, name, next_marker):
    start = raw.index(f"fn {name}(")
    end = raw.index(next_marker, start)
    return raw[start:end]


operations = []


def operation(path, name, before, after, kind="replace"):
    directory = HERE / "subjects" / name
    directory.mkdir(parents=True)
    (directory / "before.txt").write_text(before)
    (directory / "after.txt").write_text(after)
    (directory / "before.gz").write_bytes(gzip.compress(before.encode(), mtime=0))
    operations.append(
        {
            "path": path,
            "subject": name,
            "operation": kind,
            "before": ref(directory / "before.txt"),
            "minimum_before": ref(directory / "before.gz"),
            "after": ref(directory / "after.txt"),
        }
    )


before_py = (HERE / "before" / PYTHON).read_text()
after_py = (HERE / "after" / PYTHON).read_text()
old = py_nodes(before_py)
new = py_nodes(after_py)
assert old.keys() == new.keys()
assert {name for name in old if old[name] != new[name]} == {"charged_roots"}
assert py_function(before_py, "measurement_argv") == py_function(
    after_py, "measurement_argv"
)
operation(
    PYTHON,
    "charged_roots",
    py_function(before_py, "charged_roots"),
    py_function(after_py, "charged_roots"),
)

before_rs = (HERE / "before" / RUST).read_text()
after_rs = (HERE / "after" / RUST).read_text()
helper_start = after_rs.index(
    "/// The caller has verified the actual tool/argv/parent chain."
)
helper_end = after_rs.index("fn perf_launch_shape(", helper_start)
helper = after_rs[helper_start:helper_end]
test_start = after_rs.index("#[cfg(test)]\nmod profiler_raw_tests")
new_test = after_rs[test_start:]
for name, next_marker in (
    ("perf_launch_shape", "fn launch_plan("),
    ("launch_plan", "/// Validate all entry identities"),
):
    operation(
        RUST,
        name,
        rust_function(before_rs, name, next_marker),
        rust_function(after_rs, name, next_marker),
    )
operation(
    RUST,
    "profiler_open_raw",
    "fn perf_launch_shape(\n",
    helper + "fn perf_launch_shape(\n",
)
old_fixture = 'json!({"owner":dir,"perf":{"tool":tool,"output":output'
new_fixture = 'json!({"owner":dir,"data_root":dir.join("native"),"perf":{"tool":tool,"output":output'
operation(RUST, "existing_shape_fixture_field", old_fixture, new_fixture)
operation(RUST, "profiler_raw_tests", "", new_test, "append")

reconstructed = after_rs[:test_start].rstrip() + "\n"
reconstructed = reconstructed.replace(helper, "", 1).replace(
    new_fixture, old_fixture, 1
)
for name, next_marker in (
    ("perf_launch_shape", "fn launch_plan("),
    ("launch_plan", "/// Validate all entry identities"),
):
    reconstructed = reconstructed.replace(
        rust_function(after_rs, name, next_marker),
        rust_function(before_rs, name, next_marker),
        1,
    )
assert reconstructed == before_rs, "outside Rust bodies changed"
assert rust_function(
    before_rs, "check_perf_chain", "#[derive(Deserialize)]"
) == rust_function(after_rs, "check_perf_chain", "#[derive(Deserialize)]")

before_test = (HERE / "before" / TEST).read_text()
after_test = (HERE / "after" / TEST).read_text()
assert all(
    py_nodes(after_test)[name] == body for name, body in py_nodes(before_test).items()
)
new_class = py_function(after_test, "PerfRawOwnershipTests")
operation(
    TEST,
    "PerfRawOwnershipTests",
    'if __name__ == "__main__":\n',
    new_class + '\nif __name__ == "__main__":\n',
)

combined = []
for relative in (PYTHON, RUST, TEST):
    before = (HERE / "before" / relative).read_text()
    after = (HERE / "after" / relative).read_text()
    combined += difflib.unified_diff(
        before.splitlines(keepends=True),
        after.splitlines(keepends=True),
        fromfile="a/" + relative,
        tofile="b/" + relative,
    )
patch = HERE / "combined.patch"
patch.write_text("".join(combined))
# Strict patch inverse is on the exact frozen base, never on Main.
inverse = HERE / "inverse-work"
for relative in (PYTHON, RUST, TEST):
    path = inverse / relative
    path.parent.mkdir(parents=True)
    path.write_bytes((HERE / "before" / relative).read_bytes())
patch_results = []
for reverse in (False, True):
    command = [
        "patch",
        "--batch",
        "--fuzz=0",
        "-p1",
        "-d",
        str(inverse),
        "-i",
        str(patch),
    ]
    if reverse:
        command.append("--reverse")
    result = subprocess.run(command, capture_output=True, text=True, check=True)
    assert "offset" not in result.stdout and "fuzz" not in result.stdout
    branch = "before" if reverse else "after"
    assert all(
        (inverse / p).read_bytes() == (HERE / branch / p).read_bytes()
        for p in (PYTHON, RUST, TEST)
    )
    patch_results.append(
        {"reverse": reverse, "exit_code": result.returncode, "stdout": result.stdout}
    )

publish(
    "source-delta.json",
    {
        "operations": operations,
        "combined_patch": ref(patch),
        "base": "Frozen common-measurement-v1 directed bodies. Do not install full historical postimages over Main. Compose only named exact functions/snippets/new test module; current Path import, moved test module, two-AI, optional storage and journal-prefix changes stay untouched.",
        "strict_forward_inverse_frozen_base": patch_results,
        "Python_unchanged_AST_except": ["charged_roots"],
        "Rust_outside_named_insert_replace_append_inverse_byteexact": True,
        "check_perf_chain_byteexact": True,
        "measurement_argv_pre_Popen_absence_byteexact": True,
        "old_Python_test_bodies_ASTexact": True,
        "new_definition_status": {
            "PerfRawOwnershipTests.test_configured_raw_sibling_charged_and_absent_before_launch": "UNRUN",
            "research_manifest::profiler_raw_tests::measurement_profiler_raw_live_fd_stale_foreign_symlink_and_identity": "UNBUILT/UNTYPED/UNRUN",
        },
        "no_actual_Main_read_or_write": True,
        "source_preparation_STOP": datetime.now(timezone.utc).isoformat(),
    },
)
print(
    json.dumps(
        {"source_delta": ref(HERE / "source-delta.json"), "operations": len(operations)}
    )
)
