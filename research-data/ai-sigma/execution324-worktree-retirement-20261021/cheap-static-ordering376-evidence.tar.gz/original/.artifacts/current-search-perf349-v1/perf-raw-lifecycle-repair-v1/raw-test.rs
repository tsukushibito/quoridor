#[cfg(test)]
mod profiler_raw_tests {
    use super::*;
    #[test]
    fn measurement_profiler_raw_live_fd_stale_foreign_symlink_and_identity() {
        use std::os::fd::AsRawFd;
        use std::os::unix::fs::symlink;
        struct Temp(PathBuf);
        impl Drop for Temp {
            fn drop(&mut self) {
                let _ = fs::remove_dir_all(&self.0);
            }
        }
        let stamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let dir = std::env::temp_dir().join(format!("profiler-raw-{}-{stamp}", std::process::id()));
        fs::create_dir(&dir).unwrap();
        let _temp = Temp(dir.clone());
        let output = dir.join("perf.data");
        let profiler = launch_identity(std::process::id()).unwrap().0;
        assert!(profiler_open_raw(&profiler, &output).is_err());
        let writer = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&output)
            .unwrap();
        let evidence = profiler_open_raw(&profiler, &output).unwrap();
        assert_eq!(evidence["fd"], json!(writer.as_raw_fd()));
        let mut wrong = profiler.clone();
        wrong.start_ticks.push('0');
        assert!(profiler_open_raw(&wrong, &output).is_err());
        wrong.pid = 0;
        assert!(profiler_open_raw(&wrong, &output).is_err());
        drop(writer);
        assert!(profiler_open_raw(&profiler, &output).is_err());
        let reader = fs::File::open(&output).unwrap();
        assert!(profiler_open_raw(&profiler, &output).is_err());
        drop(reader);
        let other = dir.join("foreign.data");
        let foreign_writer = fs::File::create(&other).unwrap();
        assert!(profiler_open_raw(&profiler, &output).is_err());
        drop(foreign_writer);
        let stale_writer = fs::OpenOptions::new().write(true).open(&output).unwrap();
        fs::remove_file(&output).unwrap();
        fs::write(&output, b"replacement").unwrap();
        assert!(profiler_open_raw(&profiler, &output).is_err());
        drop(stale_writer);
        fs::remove_file(&output).unwrap();
        let live_writer = fs::OpenOptions::new().write(true).open(&other).unwrap();
        symlink(&other, &output).unwrap();
        assert!(profiler_open_raw(&profiler, &output).is_err());
        drop(live_writer);
        fs::remove_file(&output).unwrap();
        fs::create_dir(&output).unwrap();
        assert!(profiler_open_raw(&profiler, &output).is_err());
    }
}
