"""One new Main RAW ownership check through the maintained ordinary guardian."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
OUT = HERE / "operation-v1"
TMP = OUT / "TMP"
SOURCE = MAIN / "scripts/dev/research-lifecycle.py"
TEST = MAIN / "tools/research-session/test_measurement.py"
CYCLE = MAIN / "python/quoridor_training/cycle_process.py"
ADOPTION = (
    MAIN
    / ".artifacts/research-team/integration324/arena-entry-v1/perf-source-adoption.json"
)
EXPECTED_ADOPTION = "eadf64d429d303b2a62769c4fa9081b26cbff6ee20b0dfcae914968f11f1392b"
NAME = "test_configured_raw_sibling_charged_and_absent_before_launch"


def stamp():
    return datetime.now(timezone.utc).isoformat()


def reference(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


def identity():
    fields = Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()
    return {
        "pid": os.getpid(),
        "start_ticks": fields[19],
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    }


bootstrap_error = None
before = []
subjects = []
adoption_ref = None
try:
    with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "r"
    ) as bootstrap:
        fcntl.flock(bootstrap, fcntl.LOCK_EX | fcntl.LOCK_NB)
        adoption_raw = ADOPTION.read_bytes()
        adoption_ref = reference(ADOPTION)
        assert (
            adoption_ref["sha256"],
            adoption_ref["bytes"],
            adoption_ref["mode"],
        ) == (EXPECTED_ADOPTION, 2200, "0644"), "actual Root adoption drift"
        adoption = json.loads(adoption_raw)
        assert adoption["commit"] == "f47bad46c2c84327573101109e1a913f96bd5c06"
        assert (
            reference(SOURCE) == adoption["after"]["scripts/dev/research-lifecycle.py"]
        )
        assert (
            reference(TEST)
            == adoption["after"]["tools/research-session/test_measurement.py"]
        )
        module = importlib.util.spec_from_file_location(
            "maintained349_raw_check", SOURCE
        )
        lc = importlib.util.module_from_spec(module)
        sys.modules[module.name] = lc
        module.loader.exec_module(lc)
        assert Path(lc.process.__file__).resolve() == CYCLE
        subjects = [
            SOURCE,
            TEST,
            CYCLE,
            Path(__file__),
            ADOPTION,
            MAIN / "scripts/dev/project-env.sh",
            MAIN / "python/quoridor_training/snapshot.py",
            MAIN / "pyproject.toml",
            MAIN / "uv.lock",
            Path(sys.executable).resolve(),
        ]
        before = [reference(path) for path in subjects]
except BaseException as error:
    bootstrap_error = {"type": type(error).__name__, "message": str(error)}

if bootstrap_error is not None:
    OUT.mkdir()
    (OUT / "pre-entry-refusal.json").write_text(
        json.dumps(
            {
                "status": "REFUSED",
                "primary": bootstrap_error,
                "actual_reader_STOP": stamp(),
                "command_entered": False,
                "owned": [],
                "storage_budget": None,
            },
            indent=2,
        )
        + "\n"
    )
    print(json.dumps({"status": "REFUSED", "primary": bootstrap_error}))
    raise SystemExit(1)

available = sorted(os.sched_getaffinity(0))
assert len(available) >= 2, "two distinct actual worker/guardian CPUs required"
worker_cpu = 1 if 1 in available else available[0]
guardian_cpu = (
    4
    if 4 in available and 4 != worker_cpu
    else next(c for c in available if c != worker_cpu)
)
spec = {
    "cwd": str(MAIN),
    "kind": "software",
    "limits": {
        "family_B": 536870912,
        "controller_B": 67108864,
        "host_reserve_B": 4294967296,
        "worker_cpu": worker_cpu,
        "guardian_cpu": guardian_cpu,
        "log_B": 2097152,
    },
    "env": {
        **os.environ,
        "TMPDIR": str(TMP),
        "PYTHONDONTWRITEBYTECODE": "1",
        "RESEARCH_TEST_ROOT": str(MAIN),
        "RESEARCH_LIFECYCLE_SOURCE": str(SOURCE),
    },
}
checks = []
primary = None
after = []
source_stop = None
canonical_release = None
worker_identity = identity()
lease_entered = False
try:
    lc.physical_and_quiet(spec)
    with lc.lease(), lc.process.cancellation_signals():
        lease_entered = True
        try:
            assert before == [reference(path) for path in subjects], (
                "pre-child source drift"
            )
            OUT.mkdir()
            TMP.mkdir()
            resources = lc.process.CycleResources(
                {
                    "host_ram_reserve": 4294967296,
                    "max_memory_bytes": 536870912,
                    "max_output_bytes": None,
                },
                OUT,
                None,
            )
            row = {
                "name": "configured-perf-RAW-ownership-nn0",
                "role": "software",
                "argv": [
                    sys.executable,
                    "-B",
                    "-m",
                    "unittest",
                    "discover",
                    "-s",
                    str(TEST.parent),
                    "-p",
                    TEST.name,
                    "-k",
                    NAME,
                    "-v",
                ],
            }
            _, full = lc.command(spec, row, OUT, resources, ledger=checks)
            captured = full.read_text()
            assert re.search(r"Ran 1 test in", captured) and re.search(
                r"^OK$", captured, re.M
            ), "partial/zero/failed test census"
            assert "PerfRawOwnershipTests" in captured and NAME in captured, (
                "different owning definition"
            )
        finally:
            if TMP.exists() and not list(TMP.iterdir()):
                TMP.rmdir()
            after = [reference(path) for path in subjects]
            assert before == after, "post-child source drift"
            source_stop = stamp()
    canonical_release = stamp()
except BaseException as failure:
    primary = lc.error_fact(failure)
    if lease_entered and canonical_release is None:
        canonical_release = stamp()
finally:
    OUT.mkdir(exist_ok=True)
    if source_stop is None:
        source_stop = stamp()
    used = lc.allocated(OUT, seen=set())
    facts = {
        "status": "PASS" if primary is None else "FAILED",
        "primary": primary,
        "adoption": adoption_ref,
        "subject_before": before,
        "subject_after": after,
        "checks": checks,
        "selected_definition": "PerfRawOwnershipTests." + NAME,
        "passed_assertions": 1 if primary is None else None,
        "worker_identity": worker_identity,
        "public_entry_sys_executable": sys.executable,
        "actual_parent_affinity_before_physical_check": available,
        "selected_worker_cpu": worker_cpu,
        "selected_guardian_cpu": guardian_cpu,
        "actual_source_TMP_reader_STOP": source_stop,
        "actual_canonical_release": canonical_release,
        "public_entry_environment_SH_release": "UNKNOWN until outer entry returns",
        "remaining": {
            "readers": [],
            "jobs": [],
            "TMP": list(map(str, TMP.iterdir())) if TMP.exists() else [],
            "leases": [],
            "reservation": None,
        },
        "storage_budget": None,
        "allocated_usage_before_receipt_B": used,
        "usage_scope": "One directed check-operation observation before receipt; not global occupancy or peak.",
        "native_Cargo_perf_model_head_geometry_Search_calls": 0,
        "scope": "One genuinely new current-Main RAW owning Python assertion; no prior assertion replay or image qualification.",
    }
    lc.new_json(OUT / "result.json", facts)
if primary is not None:
    print(json.dumps({"status": "FAILED", "primary": primary}))
    raise SystemExit(1)
print(
    json.dumps(
        {"status": "PASS", "owning_assertions": 1, "result": str(OUT / "result.json")}
    )
)
