"""Seal ordinary stopped source facts; no imports of production or tests."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def reference(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


original = []
for name, sha, size in (
    (
        "source-STOP.json",
        "097594eb4b612e893851c2a4cf7948c566b22776d16cfe01f7888c3fe248ea08",
        2691,
    ),
    (
        "prepared-inputs.json",
        "d5c3f847259a0200c4a78b761358e51c83dae91b297e3407ba26cd7ce5f95217",
        20897,
    ),
    (
        "report.md",
        "9d8de2b70cb8e68d4e730eb9236c9e60ad0013133ce4ea182c18d1e5901366ec",
        5874,
    ),
):
    actual = reference(HERE.parent / "configured-entry-v1" / name)
    assert (actual["sha256"], actual["bytes"], actual["mode"]) == (sha, size, "0644")
    original.append(actual)

files = [reference(path) for path in sorted(HERE.rglob("*")) if path.is_file()]
facts = {
    "issue": "quoridor-4lc.349",
    "related_issue": "quoridor-4lc.376.1",
    "status": "STOPPED_SOURCE_STATIC_CHECKED_NEW_ASSERTIONS_UNRUN",
    "original_packet_verified_unchanged": original,
    "source_delta": reference(HERE / "source-delta.json"),
    "report": reference(HERE / "report.md"),
    "prepared_files": files,
    "static_checks": {
        "Rustfmt_check": "PASS",
        "Ruff_format_check": "PASS",
        "Ruff_check": "PASS excluding pre-existing frozen E741 outside delta",
        "Python_AST_parse_and_unchanged_other_definitions": "PASS",
        "GNU_patch_forward_inverse_no_fuzz_no_offset_frozen_base": "PASS",
        "Rust_unchanged_outside_selected_bodies_inverse_byteexact": "PASS",
    },
    "assertion_counts": {
        "new_Python_selected": 1,
        "new_Rust_selected": 1,
        "executed": 0,
    },
    "tests_Cargo_native_perf_model_head_geometry_Search_jobs_entered": 0,
    "Main_source_body_reads_writes": 0,
    "reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
    "owned": {"readers": [], "children": [], "jobs": [], "TMP": [], "leases": []},
    "reservation": None,
    "storage_budget": None,
    "directed_postwork_usage": {
        "allocated_B": 1122304,
        "scope": "Only this new repair namespace, before report/final receipt/admin writes. Not peak/global usage.",
    },
    "remaining": [
        "Actual arena timed/source release then author one new guarded Python definition",
        "Root sparse integration and one genuinely affected native definition/image in its Cargo slot",
        "Fresh selected fair timed36 slot after actual affected image; no profiling entry yet",
    ],
}
stop = HERE / "source-STOP.json"
stop.write_text(json.dumps(facts, indent=2) + "\n")
print(json.dumps(reference(stop)))
