"""Prepare sparse owning derivatives from frozen bodies; no Main or test entry."""

from pathlib import Path
import gzip

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "common-measurement-v1" / "after"
PYTHON = "scripts/dev/research-lifecycle.py"
RUST = "crates/quoridor-runner/src/research_manifest.rs"
TEST = "tools/research-session/test_measurement.py"

for relative in (PYTHON, RUST, TEST):
    raw = (BASE / relative).read_bytes()
    for branch in ("before", "after"):
        path = HERE / branch / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    preserved = HERE / "minimum-before" / (relative.replace("/", "__") + ".gz")
    preserved.parent.mkdir(parents=True, exist_ok=True)
    preserved.write_bytes(gzip.compress(raw, mtime=0))

path = HERE / "after" / PYTHON
text = path.read_text()
old = """        data_root = owned(spec["data_root"], spec["owner"])
        for item in spec["data"]:
            path = owned(item["path"], spec["owner"])
            require(
                path.is_relative_to(data_root),
                "declared data outside charged data root",
            )"""
new = """        data_root = owned(spec["data_root"], spec["owner"])
        perf = spec.get("perf")
        raw = None
        if perf is not None:
            raw = owned(perf["output"], spec["owner"])
            require(
                raw != data_root and raw.parent == data_root.parent,
                "configured perf RAW must be a native output sibling",
            )
            require(
                sum(
                    item["name"] == "perf_RAW"
                    and item["path"] == str(raw)
                    and item["limit_B"] == perf["data_max_bytes"]
                    for item in spec["data"]
                ) == 1,
                "one full configured perf RAW capture",
            )
            paths.append(raw)
        for item in spec["data"]:
            path = owned(item["path"], spec["owner"])
            require(
                path.is_relative_to(data_root)
                or (
                    path == raw
                    and item["name"] == "perf_RAW"
                    and item["limit_B"] == perf["data_max_bytes"]
                ),
                "declared data outside charged data root/configured perf RAW",
            )"""
assert text.count(old) == 1
path.write_text(text.replace(old, new))

path = HERE / "after" / RUST
text = path.read_text()
text = text.replace(
    "    let output = &perf.output;\n",
    "    let output = &perf.output;\n"
    '    let data_root = PathBuf::from(intent["data_root"].as_str().ok_or("native output root")?);\n',
    1,
)
text = text.replace(
    "        || fs::symlink_metadata(output).is_ok()\n",
    "        || output == &data_root\n"
    "        || output.parent() != data_root.parent()\n",
    1,
)
anchor = "fn perf_launch_shape(\n"
assert text.count(anchor) == 1
text = text.replace(anchor, (HERE / "raw-helper.rs").read_text() + "\n" + anchor)
old = """        tool.verify()?;
        if launch_identity(immediate)?.0 != profiler || launch_identity(parent)?.0 != guardian {"""
new = """        tool.verify()?;
        let raw = profiler_open_raw(
            &profiler,
            &PathBuf::from(intent["perf"]["output"].as_str().ok_or("perf RAW output")?),
        )?;
        if launch_identity(immediate)?.0 != profiler || launch_identity(parent)?.0 != guardian {"""
assert text.count(old) == 1
text = text.replace(old, new)
text = text.replace('"perf_argv":argv})', '"perf_argv":argv,"perf_RAW_open":raw})', 1)
# This old definition is not selected again; supply the newly required shape field.
old = 'json!({"owner":dir,"perf":{"tool":tool,"output":output'
assert text.count(old) == 1
text = text.replace(
    old,
    'json!({"owner":dir,"data_root":dir.join("native"),"perf":{"tool":tool,"output":output',
)
text += "\n" + (HERE / "raw-test.rs").read_text()
path.write_text(text)

path = HERE / "after" / TEST
text = path.read_text()
anchor = 'if __name__ == "__main__":\n'
assert text.count(anchor) == 1
text = text.replace(anchor, (HERE / "python-test.py").read_text() + "\n\n" + anchor)
path.write_text(text)
