/// The caller has verified the actual tool/argv/parent chain. Bind RAW to that
/// live profiler's writable FD, not merely to a file left at the configured path.
fn profiler_open_raw(profiler: &LaunchIdentity, output: &std::path::Path) -> Result<Value> {
    use std::os::unix::fs::{MetadataExt, OpenOptionsExt};
    if launch_identity(profiler.pid)?.0 != *profiler
        || !fs::symlink_metadata(output)?.is_file()
        || output.canonicalize()? != output
    {
        return Err("live profiler regular RAW identity required".into());
    }
    let raw = fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK | libc::O_CLOEXEC)
        .open(output)?;
    let metadata = raw.metadata()?;
    if !metadata.is_file() || metadata.uid() != unsafe { libc::geteuid() } {
        return Err("profiler RAW regular owner required".into());
    }
    for entry in fs::read_dir(format!("/proc/{}/fd", profiler.pid))? {
        let entry = entry?;
        let fd_path = entry.path();
        let Ok(target) = fs::read_link(&fd_path) else {
            continue;
        };
        if target != output {
            continue;
        }
        let Ok(opened) = fs::metadata(&fd_path) else {
            continue;
        };
        if !opened.is_file() || opened.dev() != metadata.dev() || opened.ino() != metadata.ino() {
            continue;
        }
        let fd = entry.file_name().to_string_lossy().parse::<u32>()?;
        let info = fs::read_to_string(format!("/proc/{}/fdinfo/{fd}", profiler.pid))?;
        let flags = u32::from_str_radix(
            info.lines()
                .find_map(|line| line.strip_prefix("flags:").map(str::trim))
                .ok_or("profiler FD flags")?,
            8,
        )?;
        let access = flags & libc::O_ACCMODE as u32;
        if access != libc::O_WRONLY as u32 && access != libc::O_RDWR as u32 {
            continue;
        }
        let current = fs::symlink_metadata(output)?;
        let still_open = fs::metadata(&fd_path)?;
        if !current.is_file()
            || current.dev() != metadata.dev()
            || current.ino() != metadata.ino()
            || still_open.dev() != metadata.dev()
            || still_open.ino() != metadata.ino()
            || fs::read_link(&fd_path)? != output
            || launch_identity(profiler.pid)?.0 != *profiler
        {
            return Err("profiler RAW/FD/process drift".into());
        }
        return Ok(
            json!({"path":output,"profiler":profiler,"fd":fd,"device":metadata.dev(),"inode":metadata.ino(),"uid":metadata.uid(),"flags_octal":format!("{flags:o}")}),
        );
    }
    Err("configured RAW is not open for writing by verified profiler".into())
}
