"""Finite guarded reading of the existing Run/job interface; no child operation."""

import fcntl
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path


MAIN = Path("/workspaces/quoridor")
SOURCE = MAIN / "scripts/dev/research-lifecycle.py"


with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
    "r"
) as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    module = importlib.util.spec_from_file_location("maintained349_lifecycle", SOURCE)
    lc = importlib.util.module_from_spec(module)
    module.loader.exec_module(lc)
    lc.physical_and_quiet(
        {
            "kind": "software",
            "limits": {
                "family_B": 536870912,
                "host_reserve_B": 4294967296,
                "worker_cpu": 1,
                "guardian_cpu": 4,
            },
        }
    )
    raw = SOURCE.read_bytes()
    print(
        json.dumps(
            {"publisher_sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
        )
    )
    for name in [
        "lease",
        "physical_and_quiet",
        "caller_source_refs",
        "accepted_build",
        "experiment_check",
        "originating_job",
        "source_metadata_check",
    ]:
        print(inspect.getsource(getattr(lc, name)))
    print(inspect.getsource(lc.Limits))
    job = (MAIN / "scripts/dev/research-job.py").read_text()
    lines = job.splitlines()
    for i, line in enumerate(lines):
        if any(
            s in line
            for s in [
                "setup.lock",
                "project_env",
                "project-env",
                "env_lock",
                "def submit",
            ]
        ):
            print("job slice", i + 1, "\n".join(lines[max(0, i - 3) : i + 13]))
