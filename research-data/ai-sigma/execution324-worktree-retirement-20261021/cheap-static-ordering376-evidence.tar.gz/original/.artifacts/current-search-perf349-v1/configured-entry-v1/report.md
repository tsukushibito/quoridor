The six existing settings drafts are now complete typed Experiments and normal
Run/job inputs bound to genuine BUILD85d6019b and shared read-only
artifact742c817d. No image copy, chmod, Cargo, native invocation, model/library
load, perf event, Search call or job submission occurred. Original configurations,
recipe, inputs and algorithms remain unchanged.

Current common-entry `sys.executable` is
`/home/vscode/.cache/inference/envs/quoridor-training/bin/python` for every
job and once-finalize collector. The normal research-job submitter launches its
supervisor through `project-env.sh`; that public entry holds environment SH.
The current caller's four ordinary maintained Python refs and environment entry,
project/lock refs are bound, with before/after equality under finite canonical
EXNB/common-env SH. No Rust dependency inventory or Main-Git equality was added.
The genuine BUILD retains its original20dcb16/foreign577 code provenance;
later documentation commits do not relabel the native artifact.

The five named runtime library files matched their existing exact FileRefs and
version metadata; no library session or payload qualification was performed.
The actual standard perf ToolRef is `/usr/bin/perf`, SHA
09c2952fdd0a982d797978c35e590bb00bdc02dbfee9ec13fe50fadafb25c22f,
9059728B0750. Actual owning Run guards repeat these identities at entry/after
use. These metadata bindings are not model/head or current-profile PASS.

The retained recipe is A plain-before/sampled/plain-after, then B
plain-before/sampled/plain-after; each pass has coldD4 family102, coldD6
family34 and chronological warm family0 local0→2→4→6 in one fresh warm
session. Totals are36 calls/18 sessions/108M node liability, with two sampled
passes at49Hz cpu-clock:u/DWARF8192/ring64/two12MiB/no-buildid-cache.
Model/input refs, TT4096/PVS/history/seed/score/math/cancel settings are unchanged.

Four plain entries passed the current ordinary `experiment_check` and
`Limits.check`. Both sampled entries are **REFUSED BEFORE JOB/PERF/NATIVE**:
`Refused: declared data outside charged data root`. Their complete settings
and exact refusal are preserved in prepared-inputs.json; no known-bad submission
or fabricated readiness occurred. The current measure route requires no separate
phase-admission record, but the human-selected real serial slot remains unsupplied.

The sampled owning contradiction is concrete:

- Python `charged_roots` requires every declared data item, including perf RAW,
  under `spec.data_root`.
- Native `perf_launch_shape` requires the RAW parent to exist and canonicalize.
  Native `owned_output` requires `data_root` to be absent until Output.setup
  creates it. Putting RAW under data_root cannot satisfy both conditions at
  child entry. The intended RAW sibling in the already existing pass directory
  satisfies the native-parent layout, but currently Python refuses it.
- Native `perf_launch_shape` also rejects an existing RAW pathname
  (`fs::symlink_metadata(output).is_ok()`). Its prelaunch fresh-file condition
  must be distinguished from child-entry ownership of the profiler-created
  regular RAW file, with the existing verified profiler/tool/argv/PID lifetime.

The smallest owning correction is to charge/capture the exact configured owned
RAW sibling alongside the fresh native directory through current `charged_roots`,
and reconcile the current native RAW-file predicate with the verified live perf
parent. Retain pre-Popen absence, exclusive owned path/regular non-symlink file,
actual profiler FD/process/tool/argv identity and final full RAW capture. Do not
weaken parent/origin checks, precreate the native directory, use a waiver or
alternate controller. A meaningful affected case distinguishes prelaunch absent
RAW from child-entry profiler-owned regular RAW, and still rejects a foreign,
symlink or wrong-parent file. Any necessary native correction requires one
genuinely affected current image; artifact742 remains unchanged and retained.
No source change is implemented by this preparation.

For the genuinely substantial output, the one aggregate80MiB limit covers the
complete new runs namespace (all six controls/native/perf/log/candidate/finalizer,
TMP/failure/cleanup outputs), deduping overlapping roots/inodes through current
Limits. The existing real FS reserve is4GiB, family2GiB includes controller64MiB,
host reserve4GiB, worker1/guardian4/G0. No executable/private/target/TMP category
ceilings or old preprice gate is reinstated. Ordinary preparation storage is None;
its directed post-use observation is separate from forecast/peak/global usage.

Proposed slot: after the owning RAW conditions are settled, use the next actually
nonconflicting serial window coordinated by324 with arena374. Enter each of the
six original jobs only on fresh normal physical/named-peer/fair/canonicalEXNB/
environment and artifact/input/library conditions after its predecessor's actual
directwait/once-finalization/source/TMP STOP. Actual arena374 entry has priority;
no all766-games/parent/Policy ACK or idle clock is proposed. Preparation-time quiet
is not future admission. Do not start the four plain passes prematurely as a
replacement campaign.

Scoped Ruff and JSON/AST checks passed. Generated SHA-bound JSON inputs retain
normal json.dumps formatting; their bytes are not reformatted after hashing.
A preliminary read-only interface-inspection helper hit Python inspect's
unregistered-module class-reflection TypeError after reading the owning functions;
that source/helper/error is retained, no operation or software assertion entered.
Assembly registered its imported module normally and completed; no production
patch, assertion replay or new qualification was involved. Prior consumer NN0
PASS, Rust3 PASS, FAILED/RAW/masks/costs, original376 adoptionFAIL, defaults,
USERPAUSE323/N/seals/fits96 remain original.
