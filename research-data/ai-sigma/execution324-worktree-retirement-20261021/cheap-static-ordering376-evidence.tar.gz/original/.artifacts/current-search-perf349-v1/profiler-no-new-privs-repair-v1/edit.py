"""Apply the narrow child policy and protected-path error context to owned bytes."""

from pathlib import Path

HERE = Path(__file__).resolve().parent
p = HERE / "after/python/quoridor_training/cycle_process.py"
s = p.read_text()
s = s.replace(
    "    cpu_cores=None,\n):", "    cpu_cores=None,\n    no_new_privs=False,\n):", 1
)
s = s.replace(
    "    if resources:\n        resources.check()\n    elif deadline",
    '    if type(no_new_privs) is not bool:\n        raise ValueError("no_new_privs must be a boolean")\n    if resources:\n        resources.check()\n    elif deadline',
    1,
)
s = s.replace(
    '        "child": None,\n        "log_bytes_seen": 0,',
    '        "child": None,\n        "launch_policy": {"no_new_privs_requested": no_new_privs, "verified_before_exec": None},\n        "log_bytes_seen": 0,',
    1,
)
s = s.replace(
    '    try:\n        stream = log.open("xb")',
    """    try:
        stream = log.open("xb")
        # Initialize libc in the parent; the existing child callback only calls it.
        prctl = None
        if no_new_privs:
            prctl = ctypes.CDLL(None, use_errno=True).prctl
            prctl.argtypes = [ctypes.c_int, *([ctypes.c_ulong] * 4)]
            prctl.restype = ctypes.c_int""",
    1,
)
s = s.replace(
    "                signal.pthread_sigmask(signal.SIG_SETMASK, launch_mask)\n                if cpu_cores",
    """                signal.pthread_sigmask(signal.SIG_SETMASK, launch_mask)
                if no_new_privs:
                    if prctl(38, 1, 0, 0, 0) != 0:  # PR_SET_NO_NEW_PRIVS
                        error = ctypes.get_errno()
                        raise OSError(error, "PR_SET_NO_NEW_PRIVS failed")
                    if prctl(39, 0, 0, 0, 0) != 1:  # PR_GET_NO_NEW_PRIVS
                        raise OSError("PR_GET_NO_NEW_PRIVS did not return 1")
                if cpu_cores""",
    1,
)
s = s.replace(
    "            direct_fd = os.pidfd_open(child.pid)",
    """            if no_new_privs:
                # Popen returned only after the callback and exec succeeded.
                record["launch_policy"]["verified_before_exec"] = 1
            direct_fd = os.pidfd_open(child.pid)""",
    1,
)
p.write_text(s)
p = HERE / "after/scripts/dev/research-lifecycle.py"
s = p.read_text()
needle = '        record = executor(\n            row["argv"],'
assert s.count(needle) == 1
s = s.replace(
    needle,
    """        if spec.get("perf") is not None and row.get("role") == "run":
            require(
                spec["kind"] == "run" and row["argv"] == spec["argv"],
                "actual configured profiler launch",
            )
            cpu_args["no_new_privs"] = True
        record = executor(
            row["argv"],""",
    1,
)
p.write_text(s)
p = HERE / "after/crates/quoridor-runner/src/research_manifest.rs"
s = p.read_text()
needle = "/// The caller has verified the actual tool/argv/parent chain."
helper = """fn profiler_io<T>(
    operation: &str,
    path: &Path,
    pid: u32,
    fd: Option<u32>,
    result: std::io::Result<T>,
) -> Result<T> {
    result.map_err(|error| {
        format!(
            "profiler origin {operation}: path={} pid={pid} fd={fd:?} errno={:?}: {error}",
            path.display(),
            error.raw_os_error(),
        ).into()
    })
}

"""
assert s.count(needle) == 1
s = s.replace(needle, helper + needle, 1)
a = s.index("fn profiler_open_raw(")
z = s.index("\nfn perf_launch_shape(", a)
body = s[a:z]
body = body.replace(
    "!fs::symlink_metadata(output)?.is_file()",
    '!profiler_io("symlink_metadata RAW", output, profiler.pid, None, fs::symlink_metadata(output))?.is_file()',
    1,
)
body = body.replace(
    "output.canonicalize()? != output",
    'profiler_io("canonicalize RAW", output, profiler.pid, None, output.canonicalize())? != output',
    1,
)
body = body.replace(
    "    let raw = fs::OpenOptions::new()\n",
    '    let raw = profiler_io("open RAW", output, profiler.pid, None, fs::OpenOptions::new()\n',
    1,
)
body = body.replace("        .open(output)?;", "        .open(output))?;", 1)
body = body.replace(
    "    let metadata = raw.metadata()?;",
    '    let metadata = profiler_io("fstat RAW", output, profiler.pid, None, raw.metadata())?;',
    1,
)
body = body.replace(
    '    for entry in fs::read_dir(format!("/proc/{}/fd", profiler.pid))? {\n        let entry = entry?;',
    """    let directory = PathBuf::from(format!("/proc/{}/fd", profiler.pid));
    let mut inaccessible_fd = None;
    for entry in profiler_io("read_dir", &directory, profiler.pid, None, fs::read_dir(&directory))? {
        let entry = profiler_io("read_dir entry", &directory, profiler.pid, None, entry)?;""",
    1,
)
body = body.replace(
    """        let Ok(target) = fs::read_link(&fd_path) else {
            continue;
        };""",
    """        let target = match fs::read_link(&fd_path) {
            Ok(target) => target,
            Err(error) => {
                if error.kind() == std::io::ErrorKind::PermissionDenied && inaccessible_fd.is_none() {
                    inaccessible_fd = profiler_io::<()>("read_link FD", &fd_path, profiler.pid, entry.file_name().to_string_lossy().parse().ok(), Err(error)).err();
                }
                continue;
            }
        };""",
    1,
)
body = body.replace(
    """        let Ok(opened) = fs::metadata(&fd_path) else {
            continue;
        };""",
    """        let opened = match fs::metadata(&fd_path) {
            Ok(opened) => opened,
            Err(error) => {
                if inaccessible_fd.is_none() {
                    inaccessible_fd = profiler_io::<()>("stat RAW FD", &fd_path, profiler.pid, entry.file_name().to_string_lossy().parse().ok(), Err(error)).err();
                }
                continue;
            }
        };""",
    1,
)
body = body.replace(
    """        let info = fs::read_to_string(format!("/proc/{}/fdinfo/{fd}", profiler.pid))?;""",
    """        let info_path = PathBuf::from(format!("/proc/{}/fdinfo/{fd}", profiler.pid));
        let info = profiler_io("read fdinfo", &info_path, profiler.pid, Some(fd), fs::read_to_string(&info_path))?;""",
    1,
)
body = body.replace(
    "let current = fs::symlink_metadata(output)?;",
    'let current = profiler_io("recheck RAW", output, profiler.pid, Some(fd), fs::symlink_metadata(output))?;',
    1,
)
body = body.replace(
    "let still_open = fs::metadata(&fd_path)?;",
    'let still_open = profiler_io("recheck FD", &fd_path, profiler.pid, Some(fd), fs::metadata(&fd_path))?;',
    1,
)
body = body.replace(
    "fs::read_link(&fd_path)? != output",
    'profiler_io("recheck FD target", &fd_path, profiler.pid, Some(fd), fs::read_link(&fd_path))? != output',
    1,
)
body = body.replace(
    '    Err("configured RAW is not open',
    '    if let Some(error) = inaccessible_fd {\n        return Err(error);\n    }\n    Err("configured RAW is not open',
    1,
)
s = s[:a] + body + s[z:]
needle = (
    """            (&fs::canonicalize(format!("/proc/{immediate}/exe"))?, &tool),"""
)
assert s.count(needle) == 1
s = s.replace(
    needle,
    """            (&profiler_io("canonicalize exe", &PathBuf::from(format!("/proc/{immediate}/exe")), immediate, None, fs::canonicalize(format!("/proc/{immediate}/exe")))?, &tool),""",
    1,
)
needle = "mod profiler_raw_tests {\n    use super::*;"
assert s.count(needle) == 1
s = s.replace(
    needle,
    needle
    + """
    #[test]
    fn measurement_profiler_io_error_preserves_stage_path_pid_fd_errno() {
        for (operation, path, fd) in [
            ("canonicalize exe", "/proc/19/exe", None),
            ("read_dir", "/proc/19/fd", None),
            ("read fdinfo", "/proc/19/fdinfo/7", Some(7)),
        ] {
            let error = profiler_io::<()>(operation, Path::new(path), 19, fd,
                Err(std::io::Error::from_raw_os_error(libc::EACCES))).unwrap_err().to_string();
            assert!(error.contains(operation));
            assert!(error.contains(&format!("path={path}")));
            assert!(error.contains("pid=19"));
            assert!(error.contains(&format!("fd={fd:?}")));
            assert!(error.contains(&format!("errno=Some({})", libc::EACCES)));
            assert!(error.contains(&std::io::Error::from_raw_os_error(libc::EACCES).to_string()));
        }
        assert_eq!(profiler_io("fixture", Path::new("/unused"), 19, None, Ok(42)).unwrap(), 42);
    }
""",
    1,
)
p.write_text(s)
