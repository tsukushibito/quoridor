"""Freeze sparse source and original scoped NN0 outcomes without test replay."""

import ast
from datetime import datetime, timezone
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
PATHS = [
    "scripts/dev/research-lifecycle.py",
    "python/quoridor_training/cycle_process.py",
    "crates/quoridor-runner/src/research_manifest.rs",
]
NEW = "tools/research-session/test_perf_launch_policy.py"


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


def function(text, name):
    node = next(
        n
        for n in ast.parse(text).body
        if isinstance(n, ast.FunctionDef) and n.name == name
    )
    lines = text.splitlines(True)
    return "".join(lines[node.lineno - 1 : node.end_lineno])


before = {
    name: gzip.decompress(
        (HERE / "minimum-before" / (name.replace("/", "__") + ".gz")).read_bytes()
    ).decode()
    for name in PATHS
}
after = {name: (HERE / "after" / name).read_text() for name in [*PATHS, NEW]}
for name, selected in [(PATHS[0], "command"), (PATHS[1], "execute")]:
    assert (
        after[name].replace(
            function(after[name], selected), function(before[name], selected), 1
        )
        == before[name]
    ), name
rust = after[PATHS[2]]
a = rust.index("fn profiler_io<T>(")
z = rust.index("/// The caller has verified", a)
restored = rust[:a] + rust[z:]
for start, end in [
    ("fn profiler_open_raw(", "\nfn perf_launch_shape("),
    ("fn launch_plan(", "\n/// Validate all entry identities"),
]:
    a, z = restored.index(start), restored.index(end, restored.index(start))
    old_a, old_z = (
        before[PATHS[2]].index(start),
        before[PATHS[2]].index(end, before[PATHS[2]].index(start)),
    )
    restored = restored[:a] + before[PATHS[2]][old_a:old_z] + restored[z:]
a = restored.index(
    "    #[test]\n    fn measurement_profiler_io_error_preserves_stage_path_pid_fd_errno"
)
z = restored.index(
    "    #[test]\n    fn measurement_profiler_raw_live_fd_stale_foreign_symlink_and_identity",
    a,
)
restored = restored[:a] + restored[z:]
assert restored == before[PATHS[2]], "outside native owned scope changed"
forward = "".join(
    "".join(
        difflib.unified_diff(
            before[name].splitlines(True),
            after[name].splitlines(True),
            fromfile="a/" + name,
            tofile="b/" + name,
        )
    )
    for name in PATHS
)
forward += "".join(
    difflib.unified_diff(
        [], after[NEW].splitlines(True), fromfile="/dev/null", tofile="b/" + NEW
    )
)
inverse = "".join(
    "".join(
        difflib.unified_diff(
            after[name].splitlines(True),
            before[name].splitlines(True),
            fromfile="a/" + name,
            tofile="b/" + name,
        )
    )
    for name in PATHS
)
inverse += "".join(
    difflib.unified_diff(
        after[NEW].splitlines(True), [], fromfile="a/" + NEW, tofile="/dev/null"
    )
)
(HERE / "forward.patch").write_text(forward)
(HERE / "inverse.patch").write_text(inverse)
work = HERE / "inverse-check"
work.mkdir()
proof = []
try:
    for name in PATHS:
        path = work / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(before[name])
    for patch, expected in [
        (HERE / "forward.patch", after),
        (HERE / "inverse.patch", before),
    ]:
        done = subprocess.run(
            ["/usr/bin/patch", "--batch", "--fuzz=0", "-p1", "-i", str(patch)],
            cwd=work,
            capture_output=True,
            text=True,
        )
        assert (
            done.returncode == 0
            and "offset" not in done.stdout
            and "fuzz" not in done.stdout
        )
        assert all((work / name).read_text() == body for name, body in expected.items())
        if patch.name == "inverse.patch":
            assert not (work / NEW).exists()
        proof.append(
            {"patch": ref(patch), "returncode": done.returncode, "stdout": done.stdout}
        )
finally:
    shutil.rmtree(work)
old_test = gzip.decompress(
    (HERE / "minimum-before/test_perf_launch_policy-original-failed.py.gz").read_bytes()
).decode()
assert after[NEW] == old_test.replace(
    '            self.assertEqual(persisted["remaining"], [])',
    '            self.assertNotIn("remaining", persisted)',
    1,
)
first = json.loads((HERE / "author-check-v1/result.json").read_bytes())
second = json.loads((HERE / "author-check-v2/result.json").read_bytes())
assert (
    first["status"] == "FAILED"
    and second["status"] == "PASS"
    and second["owning_assertions"] == 1
)
log = (HERE / "author-check-v1/perf-no-new-privs.full.log").read_text()
retained_passes = [
    "test_selected_policy_survives_exec_ordinary_launch_and_session",
    "test_selected_policy_cancel_directwait_drain_and_cleanup",
    "test_owning_command_selects_policy_only_for_configured_run",
]
for name in retained_passes:
    assert re.search(r"^" + name + r" .* \.\.\. ok$", log, re.M)
facts = {
    "issue": "quoridor-4lc.349",
    "status": "STOPPED_SPARSE_LOWER_PRIVILEGE_AND_CONTEXT_REPAIR",
    "base": ref(HERE / "capture.json"),
    "after": {name: ref(HERE / "after" / name) for name in [*PATHS, NEW]},
    "forward": ref(HERE / "forward.patch"),
    "inverse": ref(HERE / "inverse.patch"),
    "strict_forward_inverse": proof,
    "minimum_before": [ref(p) for p in sorted((HERE / "minimum-before").iterdir())],
    "outside_owner_bodies": "Exact bytes outside LC.command, cycle_process.execute, native profiler_io addition/profiler_open_raw/launch_plan and one new native metadata definition. Root finite sequence and configured_arena_plan/new arena metadata assertion unchanged.",
    "policy": "Only validated configured perf run requests no_new_privs. Existing prepare_child uses libc initialized before fork; set38/check39; Popen success reports verified_before_exec1. Unrequested/incomplete isNone, never claimedfalse actual inherited state. No wrapper/privilege/toolmode/sysctl/cap/guard changes.",
    "native_context": "Stage/path/PID/FD/raw errno/original error for exe/protectedRAW/FD reads. Benign unmatched/racing FD continues; bounded inaccessible_fd error only returned if no valid open RAW match. All existing path/owner/device/inode/writable/chain/identity guards unchanged.",
    "Python_first_invocation": ref(HERE / "author-check-v1/result.json"),
    "Python_retained_original_passes": retained_passes,
    "Python_first_failed_scope": "Missing remaining field in preexec failure fixture; originalFAILED/nullguardian/capturefalse/persisted facts preserved. Three actual ok definitions retained, never transplanted to PASS guardian.",
    "Python_unfinished_invocation": ref(HERE / "author-check-v2/result.json"),
    "Python_newly_passed_definition": "test_failed_set_or_check_refuses_command_and_initializes_libc_in_parent",
    "verification_scope": "Four new Python definitions:3actualPASS in originalFAILED invocation plus1corrected fixturePASS once. Set/get failures, selected exec/session/PID/no_new_privs, ordinary unrequested/parent unchanged, cancel/directwait/drain/cleanup, owning exact argv policy dispatch. No old assertion suite replay.",
    "Rust_new_definition": "research_manifest::profiler_raw_tests::measurement_profiler_io_error_preserves_stage_path_pid_fd_errno",
    "Rust_status": "UNBUILT/UNTYPED/UNRUN; Root combines one new assertion/fullaffected Clippy/release with arena consumer in genuine compatible image",
    "actual_software_reader_STOP": second["actual_source_TMP_STOP"],
    "actual_canonical_release": second["actual_canonical_release"],
    "actual_author_reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
    "owned": {
        "readers": [],
        "children": [],
        "jobs": [],
        "TMP": [],
        "leases": [],
        "reservation": None,
    },
    "storage_budget": None,
    "directed_usage_before_receipt_B": second["allocated_before_receipt_B"],
    "scientific_execution": "No perf/native image/model/head/Search/Cargo/numerical job. Original81FAILEDRAW/NULL/TypeError/actualextentUNKNOWN and all costs retained;6/36 complete30unfinished unchanged. No proven originalerrno attribution or automatic retry.",
}
path = HERE / "source-STOP.json"
path.write_text(json.dumps(facts, indent=2) + "\n")
print(
    json.dumps(
        {
            "STOP": ref(path),
            "after": facts["after"],
            "readerSTOP": facts["actual_software_reader_STOP"],
            "writerSTOP": facts["actual_author_reader_writer_STOP"],
        }
    )
)
