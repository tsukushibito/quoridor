"""One finite NN0 check via current maintained lifecycle/cycle_process."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys


HERE = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
OUT = HERE / "operation-v1"
TMP = OUT / "TMP"
SOURCE = MAIN / "scripts/dev/research-lifecycle.py"
CYCLE = MAIN / "python/quoridor_training/cycle_process.py"


def reference(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


bootstrap_error = None
try:
    with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open(
        "r"
    ) as bootstrap:
        fcntl.flock(bootstrap, fcntl.LOCK_EX | fcntl.LOCK_NB)
        module = importlib.util.spec_from_file_location(
            "maintained349_lifecycle", SOURCE
        )
        lc = importlib.util.module_from_spec(module)
        module.loader.exec_module(lc)
        assert Path(lc.process.__file__).resolve() == CYCLE
        subjects = [
            SOURCE,
            CYCLE,
            HERE.parent / "consume.py",
            HERE / "test_consumer.py",
            Path(__file__),
            MAIN / "scripts/dev/project-env.sh",
            MAIN / "python/quoridor_training/snapshot.py",
            MAIN / "pyproject.toml",
            MAIN / "uv.lock",
        ]
        before = [reference(path) for path in subjects]
        stop = json.loads((HERE.parent / "source-STOP.json").read_bytes())
        expected = next(
            r
            for r in stop["prepared_files"]
            if r["path"] == str(HERE.parent / "consume.py")
        )
        assert reference(HERE.parent / "consume.py") == expected, (
            "frozen consumer drift"
        )
except BaseException as error:
    bootstrap_error = {"type": type(error).__name__, "message": str(error)}

if bootstrap_error is not None:
    OUT.mkdir()
    (OUT / "pre-entry-refusal.json").write_text(
        json.dumps(
            {
                "primary": bootstrap_error,
                "actual_reader_STOP": datetime.now(timezone.utc).isoformat(),
                "command_entered": False,
                "remaining": [],
                "storage_budget": None,
            },
            indent=2,
        )
        + "\n"
    )
    print(json.dumps({"status": "REFUSED", "primary": bootstrap_error}))
    raise SystemExit(1)

spec = {
    "cwd": str(MAIN),
    "kind": "software",
    "limits": {
        "family_B": 536870912,
        "controller_B": 67108864,
        "host_reserve_B": 4294967296,
        "worker_cpu": 1,
        "guardian_cpu": 4,
        "log_B": 2097152,
    },
    "env": {
        **os.environ,
        "TMPDIR": str(TMP),
        "PYTHONDONTWRITEBYTECODE": "1",
        "CONSUMER_CHECK_CASES": str(OUT / "synthetic-cases"),
    },
}
checks = []
error = None
try:
    lc.physical_and_quiet(spec)
    with lc.lease(), lc.process.cancellation_signals():
        assert before == [reference(path) for path in subjects], (
            "pre-child source drift"
        )
        OUT.mkdir()
        TMP.mkdir()
        resources = lc.process.CycleResources(
            {
                "host_ram_reserve": 4294967296,
                "max_memory_bytes": 536870912,
                "max_output_bytes": None,
            },
            OUT,
            None,
        )
        row = {
            "name": "saved-consumer-nn0",
            "role": "software",
            "argv": [
                sys.executable,
                "-B",
                "-m",
                "unittest",
                "discover",
                "-s",
                str(HERE),
                "-p",
                "test_consumer.py",
                "-k",
                "test_saved_consumer_missing_terminal_null_unknown_and_sampling",
                "-v",
            ],
        }
        _, full = lc.command(spec, row, OUT, resources, ledger=checks)
        captured = full.read_text()
        assert re.search(r"Ran 1 test in", captured) and re.search(
            r"^OK$", captured, re.M
        ), "wrong/partial/zero test census"
        assert before == [reference(path) for path in subjects], (
            "post-child source drift"
        )
        TMP.rmdir()
except BaseException as failure:
    error = lc.error_fact(failure)
finally:
    if TMP.exists() and not list(TMP.iterdir()):
        TMP.rmdir()
    OUT.mkdir(exist_ok=True)
    used = lc.allocated(OUT, seen=set())
    facts = {
        "status": "PASS" if error is None else "FAILED",
        "subject_before": before,
        "subject_after": [reference(path) for path in subjects],
        "checks": checks,
        "primary": error,
        "actual_source_environment_reader_STOP": datetime.now(timezone.utc).isoformat(),
        "remaining": {
            "readers": [],
            "children": [],
            "jobs": [],
            "TMP": list(map(str, TMP.iterdir())) if TMP.exists() else [],
            "leases": [],
            "reservation": None,
        },
        "storage_budget": None,
        "allocated_usage_before_receipt_B": used,
        "usage_scope": "One directed observation of this check operation, fixtures and full captures before this receipt. Not global usage or peak.",
        "native_Cargo_perf_model_input_image_RAW_geometry_Search_calls": 0,
        "scope": "ONE new synthetic saved-consumer definition, using exact frozen cc755 consumer with current maintained guardian. No old success replay, science or acceptedBuild claim.",
    }
    lc.new_json(OUT / "result.json", facts)
if error is not None:
    print(json.dumps({"status": "FAILED", "primary": error}))
    raise SystemExit(1)
print(
    json.dumps(
        {"status": "PASS", "owning_assertions": 1, "result": str(OUT / "result.json")}
    )
)
