The one new NN0 saved-consumer definition passed once through current Main
`research-lifecycle.command` and `cycle_process`, entered through the qualified
public Python entry. The frozen consumer fe21b5e1 remains byte-exact; all
selected before/after source identities match.

The synthetic check covers missing terminal output, a null measurement,
retained incomplete-tail/error facts, missing saved-record errors, unknown
sampling origin, absent counters, and separation of plain timing from sampled
overhead. Its uncreated RAW path remains uncreated and unread. The full capture
shows the exact selected definition, `Ran 1 test`, `OK`. No real model, input,
image, RAW, native, head, geometry, Search, perf or Cargo call occurred.

The initial invocation incorrectly constrained the caller to core4 before the
maintained physical guard could admit worker1 and guardian4. It refused with
`CPU affinity admission` before any child/check: operation-v1/checks is empty.
That original FAILED receipt and worker remain immutable. A fresh operation-v2
removed only the external taskset restriction; the maintained guard selected
the actual physical cores, enforced its fresh predicates, and entered the sole
new assertion. There was no assertion retry, guard bypass or prior-suite replay.

The returned guardian reports exit0, direct child reaped, cleanup/handles
complete and remaining[]. Full capture is 265 bytes. Its 0.11591506200056756s
guardian clock is recorded once; the nested 0.002s unittest clock is not added.
Returned mask/persistence `completed/completed` and persisted receipt
`pending/attempted` remain separately retained, with no rewrite. The exact
PID/start/boot child is freshly absent; own TMP/readers/children/jobs/leases
are empty. Worker source-after STOP is 2026-10-13T07:10:17.366704+00:00;
the common-entry wrapper returned0 and released environment SH on exit,
independent release UTC UNKNOWN. Saved collection STOP is in check-STOP.json.

Storage is None. The one successful operation's directed retained allocation
observation is 53,248 bytes before its result receipt, excluding source/admin
receipts, untouched assets and global usage/peak. Scope-limited Ruff formatting
and checks passed for the new test and worker.

The existing six entry drafts/configs/recipe remain unchanged:
36 calls / 18 sessions / 108M node upper / 49Hz / two12MiB. No executable or
acceptedBuild is supplied by this check. Original commonBUILD c772111d remains
authoritatively FAILED in its own scope, with its three real Rust definitions
PASS separately retained, never rerun or transplanted here. Root's genuine
compatible Clippy/release/image completion and fresh fair entry conditions
remain necessary before numerical use. No 374/parent/Policy ACK gate is added.
