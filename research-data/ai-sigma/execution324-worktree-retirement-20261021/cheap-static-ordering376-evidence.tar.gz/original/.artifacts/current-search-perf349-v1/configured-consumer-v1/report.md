The current six-pass settings and result consumer are prepared. The owning
BUILD c772111d remains pending by the supplied integration fact; its runtime
was not polled. No measurement, native, perf, model, library, Cargo, test or
scientific collector was invoked in this preparation.

`entry-drafts.json` references the existing unchanged control/cheap configs,
request schedule, BEST43 model descriptor/weights and two shared input files.
The six drafts retain A plain-before / sampled / plain-after, then B
plain-before / sampled / plain-after: 36 calls, 18 sessions, 108M maximum
node liability. Sampling remains cpu-clock:u / 49Hz / dwarf,8192 / ring64 /
12MiB per sampled file / no-buildid-cache. These are configuration values,
not source assertions. No assets are copied or reopened here.

The native input method is the adopted `measurement::prepare_roots`: book
JSON pointers `/families/102` and `/families/34`, and the unique game=0
JSONL record's moves truncated to prefixes 4, 6, 8, 10. Each pass has two
independent cold sessions and one chronological warm session, local plies
0→2→4→6 (original warm indices 4→5→6→7). Full counted history and the
existing evaluator namespace remain selected; no input generator, new
root survey or model/head qualification is introduced.

The drafts intentionally lack the genuine completed BUILD, immutable
measure artifact, fresh runtime library/caller/environment binding and
owned sampled output/tool binding. They are not executable normal intents
or ready admissions. The next owning completion event supplies the BUILD
and actual artifact; current Run then fills its existing Experiment,
records the actual execution settings, and uses the maintained lifecycle
command/once-finalization path. Controller and collector use the current
common-entry `sys.executable`, independently of historical Build Python.
Storage is None for ordinary preparation, not an implicit allowance.

`consume.py` is a saved-result interpretation function and CLI. It consumes
the existing normal Run manifest's `data.measurement` object; it does not
duplicate journal parsing or introduce a proof/admission/qualification
path. Give stdin a list of label plus absolute saved Run-record path and
capture stdout through the ordinary software path. It retains the actual
settings snapshot, terminal counts/errors, remaining requests, complete
journal-prefix/incomplete-tail facts, returned fields, RAW references and
operational failure/cleanup facts. If the terminal result is absent it
uses only the saved recorded prefix, with terminal counts unknown.

Sampling is identified from actual profiler process-origin/RAW metadata;
missing origin is unknown rather than assumed plain. Per-context plain
medians and sampled overhead ratios are descriptive only. Every partial
or error observation remains visible; no incomplete/missing-counter
observation receives an invented ratio. It exposes return-field/work
agreement within a profile and descriptive plain-profile ratios when
recorded context/settings agree; it does not enforce plan equality,
reject partial data, infer adoption, or manufacture a confidence interval.
Actual settings differences remain present for interpretation. Root-body
timing includes replay, return validation, root drop and journal; model and
session setup/drop plus outer controller costs are separately reported.
Overlapping time domains are never added.

Verification in this preparation is scoped Ruff format/check, Python AST
parse, JSON parse and arithmetic of the retained literal recipe. All pass.
The new consumer is **UNRUN**, and no numeric records were fabricated or
read to test it. Its narrow affected software check, once a normal source
slot is available, is preservation of a missing-terminal prefix/null
measurement and unknown sampling/counters, plus separation of sampled
and plain observations. Existing passed owning measurement definitions
are not replayed. Native three definitions and owning BUILD completion
remain the existing Root responsibility.

All prior author source packets, failed BUILD facts, source/test scopes,
RAW/costs/masks/UNKNOWN and the original376 adoption FAIL remain immutable.
No Main/Git/target/private/environment writes or source/read leases were
held. The supplied current afterrefs and Source-v7 were hashed before
metadata parsing; no current Main source or ongoing job output was read.
