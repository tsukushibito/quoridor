"""One synthetic saved-record check, with no scientific/native process or asset."""

import importlib.util
import json
import os
from pathlib import Path
import unittest


HERE = Path(__file__).resolve().parent
subject = HERE.parent / "consume.py"
module = importlib.util.spec_from_file_location("saved_consumer349", subject)
consumer = importlib.util.module_from_spec(module)
module.loader.exec_module(consumer)


class SavedConsumerCheck(unittest.TestCase):
    def test_saved_consumer_missing_terminal_null_unknown_and_sampling(self):
        fixtures = Path(os.environ["CONSUMER_CHECK_CASES"])
        fixtures.mkdir()
        snapshot = {
            "settings": {"profile": "synthetic-target", "seed": None},
            "execution": {"models": [], "inputs": []},
        }
        root = {"synthetic_only": True, "position": "unchanged"}
        request = {"id": "comparison", "depth": 1, "node_cap": 20}

        def row(seconds):
            return {
                "request": request,
                "root": root,
                "status": "COMPLETE",
                "root_body_including_journal_seconds": seconds,
                "measurement": {
                    "status": "COMPLETE",
                    "parent_unchanged": True,
                    "work": {"nodes": 10},
                    "value_bits": "synthetic-return-token",
                },
            }

        def save(label, evidence, *, status="PASS", primary=None):
            path = fixtures / (label + ".json")
            path.write_text(
                json.dumps(
                    {
                        "fixture_only": "NOT SCIENTIFIC OR PROCESS AUTHORITY",
                        "status": status,
                        "cleanup_complete": True,
                        "remaining": [],
                        "primary": primary,
                        "secondary": [],
                        "data": {"measurement": evidence, "errors": []},
                    }
                )
            )
            return consumer.read_run(
                {"label": label, "record": str(path), "planned": 1}
            )

        null_row = {
            "request": {"id": "interrupted-preparation"},
            "root": root,
            "status": "UNKNOWN",
            "measurement": None,
        }
        partial = save(
            "partial",
            {
                "settings": snapshot,
                "result": None,
                "recorded_prefix": [null_row],
                "journal_rows": 1,
                "incomplete_tail": {"bytes": 7, "status": "UNKNOWN"},
                "unreturned_tail": True,
                "runtime_launch_origin": None,
            },
            status="FAILED",
            primary={"type": "SyntheticInterruptedRecord", "message": "retained"},
        )
        self.assertIsNone(partial["sampled"])
        self.assertEqual(partial["rows"], [null_row])

        def terminal(seconds):
            return {
                "planned": 1,
                "calls": 1,
                "complete": 1,
                "uncompleted": 0,
                "unperformed": 0,
                "measurements": [row(seconds)],
                "errors": [],
                "status": "COMPLETE",
            }

        plain = save(
            "plain",
            {
                "settings": snapshot,
                "result": terminal(2),
                "runtime_launch_origin": {
                    "guardian": "synthetic",
                    "native": "synthetic",
                },
            },
        )
        # The RAW path deliberately does not exist. Its metadata is referenced,
        # never read or promoted into actual profiler identity by this consumer.
        raw = [{"path": str(fixtures / "UNCREATED-perf.data"), "fixture_only": True}]
        sampled = save(
            "sampled",
            {
                "settings": snapshot,
                "result": terminal(8),
                "perf_RAW": raw,
                "runtime_launch_origin": {"profiler": "synthetic"},
            },
        )
        unknown_origin = save(
            "plain-looking-label-with-unknown-origin",
            {"settings": snapshot, "result": terminal(1000)},
        )
        missing = consumer.read_run(
            {
                "label": "unavailable",
                "record": str(fixtures / "missing.json"),
                "planned": 1,
            }
        )
        self.assertEqual(missing["saved_record_error"]["type"], "FileNotFoundError")
        self.assertIsNone(missing["sampled"])

        report = consumer.interpret([partial, plain, sampled, unknown_origin, missing])
        summaries = {r["label"]: r for r in report["runs"]}
        self.assertIsNone(summaries["partial"]["counts"]["calls"])
        self.assertEqual(summaries["partial"]["primary"], partial["primary"])
        self.assertEqual(summaries["partial"]["journal"]["incomplete_tail"]["bytes"], 7)
        self.assertTrue(summaries["partial"]["journal"]["unreturned_tail"])
        self.assertEqual(summaries["sampled"]["perf_RAW"], raw)
        self.assertEqual(report["count_facts"]["known_reported_calls"], 3)
        self.assertEqual(
            report["count_facts"]["requested_calls_without_reported_calls"], 2
        )
        self.assertEqual(
            report["count_facts"]["runs_without_terminal_call_counts"],
            ["partial", "unavailable"],
        )

        contexts = {c["request_id"]: c for c in report["contexts"]}
        null_observation = contexts["interrupted-preparation"]["observations"][0]
        self.assertEqual(null_observation["returned"], {})
        self.assertIsNone(null_observation["metrics"]["nodes"])
        comparison = contexts["comparison"]
        self.assertEqual(len(comparison["observations"]), 3)
        facts = comparison["profiles"]["synthetic-target"]
        self.assertEqual(facts["plain_observations"], 1)
        self.assertEqual(facts["sampled_observations"], 1)
        self.assertEqual(
            facts["plain_medians"]["root_body_including_journal_seconds"], 2
        )
        self.assertIsNone(facts["plain_medians"]["evaluations"])
        self.assertEqual(
            facts["sampled_over_plain_root_body"], [{"label": "sampled", "ratio": 4}]
        )
        self.assertFalse((fixtures / "UNCREATED-perf.data").exists())
        (fixtures / "consumer-report.json").write_text(
            json.dumps(report, indent=2) + "\n"
        )


if __name__ == "__main__":
    unittest.main()
