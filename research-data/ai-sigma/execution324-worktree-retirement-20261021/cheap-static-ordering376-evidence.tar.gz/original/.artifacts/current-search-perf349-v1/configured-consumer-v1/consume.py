"""Interpret saved normal Run measurements; never launch or certify a run.

stdin: [{"label": str, "record": absolute Run-manifest path, "planned": int}].
stdout: interpretation facts referencing the original settings/result records.
Sampling is observed from actual launch metadata/RAW, not the label.
"""

import json
import math
import sys
from pathlib import Path
from statistics import median


def number(value):
    return value if type(value) in (int, float) and math.isfinite(value) else None


def ratio(numerator, denominator):
    if numerator is None or denominator is None or denominator <= 0:
        return None
    return numerator / denominator


def center(values):
    return median(values) if values else None


def read_run(item):
    path = Path(item["record"])
    if not path.is_absolute():
        raise ValueError("absolute saved Run record required")
    try:
        manifest = json.loads(path.read_text())
        record_error = None
    except (OSError, json.JSONDecodeError) as error:
        manifest = {}
        record_error = {"type": type(error).__name__, "message": str(error)}
    evidence = manifest.get("data", {}).get("measurement") or {}
    snapshot = evidence.get("settings") or {}
    result = evidence.get("result")
    rows = (
        result.get("measurements", [])
        if result is not None
        else evidence.get("recorded_prefix") or []
    )
    origin = evidence.get("runtime_launch_origin") or {}
    raw = evidence.get("perf_RAW") or []
    # An absent terminal result or absent RAW does not turn sampling into plain.
    sampled = (
        True
        if raw or origin.get("profiler") is not None
        else False
        if origin.get("guardian") is not None and origin.get("native") is not None
        else None
    )
    return {
        "label": item["label"],
        "record": str(path),
        "requested_planned": item.get("planned"),
        "saved_record_error": record_error,
        "manifest_status": manifest.get("status"),
        "cleanup_complete": manifest.get("cleanup_complete"),
        "remaining": manifest.get("remaining"),
        "primary": manifest.get("primary"),
        "secondary": manifest.get("secondary"),
        "settings": snapshot,
        "result": result,
        "rows": rows,
        "evidence": evidence,
        "sampled": sampled,
        "perf_RAW": raw,
        "data_errors": manifest.get("data", {}).get("errors", []),
    }


def metrics(row):
    returned = row.get("measurement") or {}
    work = returned.get("work") or {}
    return {
        "nodes": number(work.get("nodes")),
        "evaluations": number(work.get("evaluations")),
        "root_body_including_journal_seconds": number(
            row.get("root_body_including_journal_seconds")
        ),
        "Search_call_seconds": number(returned.get("Search_call_seconds")),
    }


def signature(row, run):
    request = row.get("request", {})
    root = row.get("root")
    settings = run["settings"].get("settings")
    execution = run["settings"].get("execution")
    if root is None or settings is None or execution is None:
        return None
    return json.dumps(
        [
            root,
            request.get("depth"),
            request.get("node_cap"),
            request.get("time_limit_ms"),
            request.get("diagnostic", False),
            request.get("warmup", False),
            {k: v for k, v in settings.items() if k != "profile"},
            execution.get("models"),
            execution.get("inputs"),
        ],
        sort_keys=True,
    )


def interpret(runs):
    summaries = []
    groups = {}
    for run in runs:
        result = run["result"] or {}
        snapshot = run["settings"]
        summaries.append(
            {
                "label": run["label"],
                "record": run["record"],
                "requested_planned": run["requested_planned"],
                "saved_record_error": run["saved_record_error"],
                "manifest_status": run["manifest_status"],
                "cleanup_complete": run["cleanup_complete"],
                "remaining": run["remaining"],
                "primary": run["primary"],
                "secondary": run["secondary"],
                "profile": snapshot.get("settings", {}).get("profile"),
                "sampled": run["sampled"],
                "actual_settings": snapshot,
                "counts": {
                    key: result.get(key)
                    for key in (
                        "planned",
                        "scheduled",
                        "calls",
                        "attempted",
                        "complete",
                        "uncompleted",
                        "unperformed",
                        "unscheduled",
                        "extra_calls",
                    )
                },
                "status": result.get("status"),
                "errors": result.get("errors"),
                "remaining_requests": result.get("remaining_requests"),
                "data_errors": run["data_errors"],
                "journal": {
                    key: value
                    for key, value in run["evidence"].items()
                    if key not in {"settings", "result", "recorded_prefix", "perf_RAW"}
                },
                "perf_RAW": run["perf_RAW"],
                "cost_domains": {
                    key: result.get(key)
                    for key in (
                        "setup_seconds",
                        "target_drop_seconds",
                        "session_domains",
                        "whole_driver_seconds",
                        "whole_before_result_publication_seconds",
                    )
                },
            }
        )
        for row in run["rows"]:
            request = row.get("request", {})
            key = request.get("id")
            groups.setdefault(key, []).append((run, row))

    comparisons = []
    for key, entries in groups.items():
        shapes = [signature(row, run) for run, row in entries]
        comparable = None not in shapes and len(set(shapes)) == 1
        observations = []
        profiles = {}
        for run, row in entries:
            returned = row.get("measurement") or {}
            profile = run["settings"].get("settings", {}).get("profile")
            valid = (
                row.get("status") == "COMPLETE"
                and returned.get("parent_unchanged") is True
            )
            observation = {
                "label": run["label"],
                "profile": profile,
                "sampled": run["sampled"],
                "request": row.get("request"),
                "root": row.get("root"),
                "status": row.get("status"),
                "returned": returned,
                "metrics": metrics(row),
                "domains": {k: v for k, v in row.items() if k.endswith("seconds")},
            }
            observations.append(observation)
            if valid and comparable and profile is not None:
                profiles.setdefault(profile, []).append(observation)
        profile_facts = {}
        for profile, observations_for_profile in profiles.items():
            plain = [o for o in observations_for_profile if o["sampled"] is False]
            sampled = [o for o in observations_for_profile if o["sampled"] is True]
            medians = {
                metric: center(
                    [
                        o["metrics"][metric]
                        for o in plain
                        if o["metrics"][metric] is not None
                    ]
                )
                for metric in (
                    "nodes",
                    "evaluations",
                    "root_body_including_journal_seconds",
                    "Search_call_seconds",
                )
            }
            profile_facts[profile] = {
                "plain_observations": len(plain),
                "sampled_observations": len(sampled),
                "plain_medians": medians,
                "sampled_over_plain_root_body": [
                    {
                        "label": o["label"],
                        "ratio": ratio(
                            o["metrics"]["root_body_including_journal_seconds"],
                            medians["root_body_including_journal_seconds"],
                        ),
                    }
                    for o in sampled
                ],
                "available_return_fields_agree": {
                    field: len(
                        {
                            json.dumps(o["returned"].get(field), sort_keys=True)
                            for o in observations_for_profile
                        }
                    )
                    == 1
                    if all(field in o["returned"] for o in observations_for_profile)
                    else None
                    for field in (
                        "value_bits",
                        "action",
                        "PV",
                        "completed_depth",
                        "work",
                        "root_legal_action_ids",
                        "parent_unchanged",
                    )
                },
            }
        pair_ratios = [
            {
                "numerator_profile": numerator,
                "denominator_profile": denominator,
                "plain_ratios": {
                    metric: ratio(
                        facts["plain_medians"][metric], base["plain_medians"][metric]
                    )
                    for metric in facts["plain_medians"]
                },
            }
            for numerator, facts in profile_facts.items()
            for denominator, base in profile_facts.items()
            if numerator != denominator
        ]
        comparisons.append(
            {
                "request_id": key,
                "same_recorded_root_and_limits": comparable,
                "observations": observations,
                "profiles": profile_facts,
                "descriptive_plain_profile_ratios": pair_ratios,
            }
        )
    return {
        "runs": summaries,
        "contexts": comparisons,
        "count_facts": {
            "known_reported_calls": sum(
                (r["result"] or {}).get("calls", 0) for r in runs
            ),
            "known_reported_complete": sum(
                (r["result"] or {}).get("complete", 0) for r in runs
            ),
            "runs_without_terminal_call_counts": [
                r["label"] for r in runs if r["result"] is None
            ],
            "requested_calls_without_reported_calls": sum(
                max(0, r["requested_planned"] - (r["result"] or {}).get("calls", 0))
                for r in runs
                if type(r["requested_planned"]) is int
            ),
            "meaning": "Sums of available reported counts only. Requested calls lacking a terminal report remain unobserved/UNKNOWN, not proof of zero execution.",
        },
        "interpretation_limits": [
            "Original settings/result and journal facts remain the authority for actual partial execution.",
            "Missing counters/times stay null; incomplete calls are retained without a ratio or refill.",
            "Root body includes replay, returned validation, root drop and journal; model/session setup/drop and outer controller costs are separate.",
            "Cost domains overlap and must not be summed. Sampled timing is overhead, not plain speed.",
            "This is descriptive saved-data interpretation, not adoption, universal equivalence, a confidence interval or a new run.",
        ],
    }


if __name__ == "__main__":
    print(
        json.dumps(
            interpret([read_run(item) for item in json.load(sys.stdin)]), indent=2
        )
    )
