# Ordering382 source pair

Implemented two separate, reversible patches in the existing OWN cheap-static worktree. No Main/Git/index, runner/Python/lifecycle, target/private/environment or model/data write occurred. No Cargo, native test, Search, perf, head or numerical job ran. The applied saved context was verified as ordering-cost372/gpt-6.1-sol/high/danger-full-access/never before ordinary commands. The explicitly resumed Docker stop does not lift USERPAUSE323 or fits96.

## 1. Structure and current factories

`structure.patch` moves ranking and its before/after observation into private `move_ordering.rs`. `Search::ordered` now visibly obtains legal ids, calls the existing score-production sequence, stable-sorts through that ranking, and optionally observes the result. `ordering_scores` retains policy length/finite/error/control checks, static preparation and map validation, signed history computation, static addition and counters in their original statement order. It introduces no new score formula or validity boundary.

The helper has one priority/policy/history/ActionID comparison definition. Its diagnostic dynamic-only comparison uses that same definition, with the existing distinction: Coverage omits its goal tier, whereas Cheap and its control keep their common exact legal goal tier. Unsigned comparison still uses u64, without narrowing. Observation OFF does not construct the lazy dynamic snapshot or execute the diagnostic scans. Observation ON retains the necessary pre-static dynamic snapshot; there is no copied legal vector or second sort.

The research enum now contains only the two current caller variants `CheapStaticControl` and `CombinedSignedCheapStatic`. Their stable names were retained so the maintained measure Control/Cheap caller needs no runner change. Three obsolete test-only variants are removed. Four maintained correctness definitions now exercise product constructors and the existing private `static_enabled=Off` knob instead of those retired variants. Product `new`, score-domain constructor and `new_without_continuation_or_static` are byte-exact. Current research factories still create signed history, select their original CheapControl/Cheap mode, observer flag and algorithm namespace suffix.

## 2. Cached ranks and optional policy

`cached-ranks.patch` applies only atop the structure patch. `Ranking::new` visits each legal action once and stores two u8 priority views in one fixed stack array: the actual legal-goal tier and the existing diagnostic view without that tier. PV is handled first; the killer rank and legal-goal boolean are computed once for each remaining action. This also preserves a goal/killer overlap when the diagnostic comparison omits goals. Both sorting and diagnostics read those stored ranks.

The None/Some policy branch is selected before stable sort. None supplies an equal policy tier without a float comparison; Some retains descending `f32::total_cmp`, including positive/negative zero. The history/static score and ascending numeric ActionID tie remain the same. The policy score array and original finite/shape validation remain; scores are not approximated or recomputed in the comparator.

There is no additional production heap allocation. The rank array has418 logical bytes for209 pairs of u8; compiler layout, returned-aggregate optimization, spills/RSS and timing remain unmeasured. The standard stable sort and its existing internal allocation remain. The snapshot is scoped to observation ON. No per-parent cache, MovePicker, lazy legality, extra control/deadline callback, new trait, registry or alternate comparator was introduced.

## Static verification and current limitations

All seven affected handwritten Rust files pass scoped Rustfmt2024/check. The ordinary JSON recipe/software selection passes project Prettier/check. GNU patch applies each structure/reduction/combined patch with zero fuzz and zero offset; every exact forward afterimage and inverse beforeimage/absence matches. Temporary patch-check trees were removed. Minimum exact beforeimages decompress byte-for-byte.

`source-protection.json` confirms every alpha byte outside the named ordering/scoring, current research factory selection and new module declaration is unchanged. The score/control/error/counter sequence matches the extracted original after only slice-reference/format normalization and relocation of the observation snapshot. The history module outside the research enum is byte-exact. On patch2, score production, callbacks/error handling, all factories and all other files are byte-exact; only the two production call sites/helper and corresponding new unit fixture change. Static/cheap kernels, map validation, history updates/aging, TT, PVS, leaf/model/math, make/unmake and default selection were not edited.

Rust syntax formatting and patch/static checks are **not type or assertion PASS**. All new/current affected definitions remain UNBUILT/UNTYPED/UNRUN. Root alone owns the unique supported Cargo/image slot and actual source adoption. No old math/NNUE/head/model suite or original34936/37680 was replayed.

## Exact affected verification

Three new definitions are in `alphabeta::move_ordering::tests`:

- `ordering382_rank_tiers_policy_total_cmp_and_integer_boundaries`: hand-specified tier/tie expectations, None/Some and signed zero, signed score limits/u64 high boundary, Coverage versus common-goal diagnostic comparison; no copied old comparator oracle.
- `ordering382_policy_and_observation_preserve_legal_order_parent_and_interrupts`: actual legal-set preservation, ON/OFF identical order for None/Some policy, policy error and cancellation, parent/history restoration through the existing fake-evaluator fixture.
- `ordering382_two_research_targets_preserve_product_factories`: diagnostics-feature-only current Control/Cheap and product/OFF factory selection; NoCalls evaluator forbids evaluation.

The first two exist with `research`; all three with `research-diagnostics`. Four changed maintained product/cold-warm/independent-value/history-context definitions and one directly affected existing Cheap legal-goal/parent/error definition are selected separately in `affected-software-plan.json`:8 assertion definitions total under diagnostics, no broad old suite. It gives literal filters/full names and expected counts, research compile-only closure, affected research/diagnostics Clippy and the existing optimized measurement release role. Compile-only or zero-test output must remain labelled accordingly. All selected fixtures use fake evaluators/zero real heads; no BEST43 payload is a software-test input.

## One scoped review question and selected finite method

Does this exact pair preserve the total ordering tuple, current product/research factory behavior and original diagnostic definitions for all relevant signed/unsigned, PV/goal/killer overlap and policy signed-zero cases, while preserving the scoring/error/cancel/undo boundary? The source check should also confirm that observation OFF introduces no dedicated snapshot/scan and that the new cached ranks have invocation-local lifetime. Review only these changed boundaries; original math/input/head evidence retains its original scope. Author does not dispatch the reviewer.

`selected48-recipe.json` records the already selected finite configuration: Control O,N,N,O then Cheap O,N,N,O; eight fresh processes, six calls/three sessions each, total48/24/144M upper. Each has coldD4family102/coldD6family34 and one chronological warmfamily0 sequence0→2→4→6, original2M/8M caps, TT4096/1MiB/PVS/BEST43/full history/rules. No sampling, games, training, tune, refill or additional campaign. Old O is authentic readonly fbd0; N Build/image is genuinely pending and cannot be inferred from source.

Root binds actual current settings/results, image and serial lifetimes through the maintained measure/job port. Within each profile O/N require exact completed depth/value bits/action/PV/full Search work/parent restoration. Both profiles' N/O whole-before-publication medians must be≤1, with no context having both N times>1.10×O median. Missing/error/capped results are unsupported/UNKNOWN. If the reduction fails, Root can withdraw only patch2 in a separate commit; structure-only remains independently reviewable with software verification and explicitly unmeasured performance, without a second native campaign.

The original34936 profile,37680 adoptionFAIL/local pruning observations, all old RAW/FAILED costs/masks/UNKNOWN, models/defaults/N/seals/fits96/USERPAUSE323 are retained. No default promotion or strength/general-speed claim is made.382.1 stays in_progress pending actual owning verification; parent382 owns adoption/performance conclusions. Final source-reader/writer STOP, exact maps and directed ordinary post-use observation accompany the one324 handoff.
