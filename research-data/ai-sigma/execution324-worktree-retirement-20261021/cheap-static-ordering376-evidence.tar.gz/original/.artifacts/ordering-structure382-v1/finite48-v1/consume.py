"""Compare saved common-measure results for the selected O/N order reduction.

This reads references only; it never launches, finalizes, or replaces work.
The common saved reader retains incomplete journal prefixes and absent results.
"""

import argparse
import importlib.util
import json
from pathlib import Path
from statistics import median


def common_reader(composition):
    path = composition["existing_consumer"]["path"]
    spec = importlib.util.spec_from_file_location("saved_measure_reader", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def numeric(value):
    # bool is not a measurement, and NaN/Infinity are not available times.
    import math

    return (
        value
        if type(value) in (int, float) and math.isfinite(value) and value >= 0
        else None
    )


def quotient(numerator, denominator):
    return (
        numerator / denominator if denominator is not None and denominator > 0 else None
    )


def same(values):
    return len({json.dumps(v, sort_keys=True) for v in values}) == 1


def interpret(composition, runs):
    summaries = []
    by_profile = {}
    expected_requests = composition["expected_requests"]
    expected_sessions = []
    for request in expected_requests:
        if not expected_sessions or expected_sessions[-1] != request["session"]:
            expected_sessions.append(request["session"])
    for selection, run in zip(composition["passes"], runs, strict=True):
        result = run["result"] or {}
        snapshot = run["settings"]
        counts = {
            key: result.get(key)
            for key in (
                "planned",
                "scheduled",
                "calls",
                "attempted",
                "complete",
                "uncompleted",
                "unperformed",
                "unscheduled",
                "extra_calls",
            )
        }
        domains = result.get("session_domains")
        resets = (
            [d.get("session") for d in domains if d.get("domain") == "reset"]
            if isinstance(domains, list)
            else None
        )
        teardowns = (
            [d.get("session") for d in domains if d.get("domain") == "teardown"]
            if isinstance(domains, list)
            else None
        )
        complete = (
            run["manifest_status"] == "PASS"
            and run["cleanup_complete"] is True
            and run["remaining"] == []
            and run["primary"] is None
            and not run["secondary"]
            and result.get("status") == "COMPLETE"
            and result.get("errors") == []
            and result.get("remaining_requests") == []
            and run["sampled"] is False
            and resets == expected_sessions
            and teardowns is not None
            and len(teardowns) == len(expected_sessions)
            and all(
                counts[k] == selection["planned"]
                for k in ("planned", "scheduled", "calls", "attempted", "complete")
            )
            and all(
                counts[k] == 0
                for k in ("uncompleted", "unperformed", "unscheduled", "extra_calls")
            )
            and [row.get("request") for row in run["rows"]] == expected_requests
            and snapshot.get("settings")
            == composition["expected_settings"][selection["profile"]]
            and snapshot.get("execution", {}).get("models") == composition["models"]
            and snapshot.get("execution", {}).get("inputs") == composition["inputs"]
        )
        whole = numeric(result.get("whole_before_result_publication_seconds"))
        binding = composition["bindings"].get(selection["image_role"], {})
        image_matches = (
            bool(binding)
            and snapshot.get("artifact") == binding.get("artifact")
            and snapshot.get("code_build") == binding.get("build_manifest")
        )
        summary = {
            "label": selection["label"],
            "profile": selection["profile"],
            "image_role": selection["image_role"],
            "record": selection["record"],
            "saved_record_error": run["saved_record_error"],
            "manifest_status": run["manifest_status"],
            "cleanup_complete": run["cleanup_complete"],
            "remaining": run["remaining"],
            "primary": run["primary"],
            "secondary": run["secondary"],
            "counts": counts,
            "actual_session_reset_labels": resets,
            "actual_session_teardown_labels": teardowns,
            "errors": result.get("errors"),
            "remaining_requests": result.get("remaining_requests"),
            "available_prefix_rows": len(run["rows"]),
            "selected_complete_scope": complete,
            "actual_image_matches_selected_role": image_matches,
            "whole_before_result_publication_seconds": whole,
            # Full actual settings and original process masks remain in this one
            # authoritative record, rather than another identical result body.
            "actual_identity": {
                k: snapshot.get(k) for k in ("artifact", "code_build", "code_version")
            },
            "actual_environment_record": selection["record"]
            + "#/data/measurement/settings/environment",
            "actual_settings_record": selection["record"]
            + "#/data/measurement/settings",
            "actual_process_facts_record": selection["record"],
        }
        summaries.append(summary)
        by_profile.setdefault(selection["profile"], []).append(
            (selection, run, summary)
        )

    profiles = {}
    for profile, entries in by_profile.items():
        context_facts = []
        exact_statuses = []
        adverse_flags = []
        for expected in expected_requests:
            observations = []
            rows = []
            fields_present = set(composition["expected_work_fields"])
            for _, other_run, _ in entries:
                for other in other_run["rows"]:
                    if other.get("request", {}).get("id") == expected["id"]:
                        fields_present.update(
                            (other.get("measurement") or {}).get("work") or {}
                        )
            for selection, run, summary in entries:
                matching = [
                    r
                    for r in run["rows"]
                    if r.get("request", {}).get("id") == expected["id"]
                ]
                row = matching[0] if len(matching) == 1 else None
                returned = (row or {}).get("measurement") or {}
                work = returned.get("work")
                missing = [
                    k
                    for k in sorted(fields_present)
                    if not isinstance(work, dict) or numeric(work.get(k)) is None
                ]
                legal = returned.get("root_legal_action_ids")
                valid = (
                    row is not None
                    and row.get("status") == "COMPLETE"
                    and returned.get("status") == "COMPLETE"
                    and returned.get("returned") == "Ok"
                    and returned.get("stop") == "DepthComplete"
                    and returned.get("completed_depth") == expected["depth"]
                    and type(returned.get("value_bits")) is int
                    and type(returned.get("action")) is int
                    and isinstance(returned.get("PV"), list)
                    and bool(returned["PV"])
                    and all(type(a) is int for a in returned["PV"])
                    and returned["PV"][0] == returned.get("action")
                    and isinstance(legal, list)
                    and bool(legal)
                    and all(type(a) is int for a in legal)
                    and len(set(legal)) == len(legal)
                    and returned.get("action") in legal
                    and returned.get("parent_unchanged") is True
                    and not missing
                )
                seconds = numeric(
                    (row or {}).get("root_body_including_journal_seconds")
                )
                observations.append(
                    {
                        "label": selection["label"],
                        "image_role": selection["image_role"],
                        "row_index": run["rows"].index(row)
                        if row is not None
                        else None,
                        "status": (row or {}).get("status"),
                        "valid_complete_return": valid,
                        "missing_work_counters": missing,
                        "root_body_including_journal_seconds": seconds,
                    }
                )
                rows.append((selection, row, returned, valid))
            fields = (
                "completed_depth",
                "value_bits",
                "action",
                "PV",
                "work",
                "root_legal_action_ids",
                "parent_unchanged",
            )
            known = len(rows) == 4 and all(valid for _, _, _, valid in rows)
            agreement = {
                field: same([r.get(field) for _, _, r, _ in rows]) if known else None
                for field in fields
            }
            differences = {
                field: [
                    {"label": selected["label"], "value": returned.get(field)}
                    for selected, _, returned, _ in rows
                ]
                for field, agrees in agreement.items()
                if agrees is False
            }
            root_agrees = (
                same([row.get("root") for _, row, _, _ in rows]) if known else None
            )
            status = (
                "UNKNOWN"
                if not known
                else "PASS"
                if all(agreement.values()) and root_agrees
                else "FAIL"
            )
            exact_statuses.append(status)
            times = {
                role: [
                    o["root_body_including_journal_seconds"]
                    for o in observations
                    if o["image_role"] == role
                ]
                for role in ("O", "N")
            }
            timed = all(
                len(v) == 2 and all(t is not None for t in v) for v in times.values()
            )
            old_median = median(times["O"]) if timed else None
            new_ratios = (
                [quotient(t, old_median) for t in times["N"]] if timed else None
            )
            adverse = (
                all(r > 1.10 for r in new_ratios)
                if new_ratios is not None and None not in new_ratios
                else None
            )
            adverse_flags.append(adverse)
            context_facts.append(
                {
                    "id": expected["id"],
                    "observations": observations,
                    "exact_status": status,
                    "agreement": agreement,
                    "differences": differences,
                    "root_agrees": root_agrees,
                    "O_median_seconds": old_median,
                    "each_N_over_O_median": new_ratios,
                    "both_N_adverse_over_1_10": adverse,
                }
            )
        totals = {
            role: [
                summary["whole_before_result_publication_seconds"]
                for selection, _, summary in entries
                if selection["image_role"] == role
            ]
            for role in ("O", "N")
        }
        total_known = all(
            len(v) == 2 and all(t is not None for t in v) for v in totals.values()
        )
        old = median(totals["O"]) if total_known else None
        new = median(totals["N"]) if total_known else None
        whole_ratio = quotient(new, old) if total_known else None
        complete = len(entries) == 4 and all(
            s["selected_complete_scope"] and s["actual_image_matches_selected_role"]
            for _, _, s in entries
        )
        exact = (
            "UNKNOWN"
            if not complete or "UNKNOWN" in exact_statuses
            else "FAIL"
            if "FAIL" in exact_statuses
            else "PASS"
        )
        timing = (
            "UNKNOWN"
            if not complete or whole_ratio is None or None in adverse_flags
            else "PASS"
            if whole_ratio <= 1.0 and not any(adverse_flags)
            else "FAIL"
        )
        condition_differences = {}
        for domain in ("settings", "execution", "environment"):
            snapshots = [
                (selected["label"], run["settings"].get(domain) or {})
                for selected, run, _ in entries
            ]
            changed = {}
            for key in sorted({k for _, values in snapshots for k in values}):
                observations = [
                    {"label": label, "present": key in values, "value": values.get(key)}
                    for label, values in snapshots
                ]
                if not same(
                    [{k: v for k, v in o.items() if k != "label"} for o in observations]
                ):
                    changed[key] = observations
            condition_differences[domain] = changed
        profiles[profile] = {
            "selected_complete_scope": complete,
            "exact_order_work_status": exact,
            "whole_observations_seconds": totals,
            "O_median_seconds": old,
            "N_median_seconds": new,
            "N_over_O_median": whole_ratio,
            "timing_gate": timing,
            "actual_condition_differences": condition_differences,
            "contexts": context_facts,
        }
    gates = [
        p[k]
        for p in profiles.values()
        for k in ("exact_order_work_status", "timing_gate")
    ]
    decision = (
        "UNKNOWN/UNSUPPORTED"
        if set(profiles) != {"control", "cheap"} or "UNKNOWN" in gates
        else "SUPPORTED_SELECTED_COMPARISON"
        if all(g == "PASS" for g in gates)
        else "UNSUPPORTED"
    )
    return {
        "records": summaries,
        "census": {
            "planned_calls": sum(p["planned"] for p in composition["passes"]),
            "available_terminal_complete_calls": sum(
                s["counts"]["complete"]
                for s in summaries
                if type(s["counts"]["complete"]) is int
            ),
            "terminal_count_unknown_records": [
                s["label"]
                for s in summaries
                if type(s["counts"]["complete"]) is not int
            ],
            "available_terminal_reset_sessions": sum(
                len(s["actual_session_reset_labels"])
                for s in summaries
                if s["actual_session_reset_labels"] is not None
            ),
            "session_count_unknown_records": [
                s["label"]
                for s in summaries
                if s["actual_session_reset_labels"] is None
            ],
        },
        "profiles": profiles,
        "reduction_decision": decision,
        "scope": "This fixed saved comparison only. No general CPU/strength/default claim, refill, repeated finalization or new native work. Missing observations stay unknown; original settings/results/process masks are referenced.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--composition", type=Path, required=True)
    args = parser.parse_args()
    composition = json.loads(args.composition.read_text())
    reader = common_reader(composition)
    runs = [reader.read_run({**p, "label": p["label"]}) for p in composition["passes"]]
    print(json.dumps(interpret(composition, runs), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
