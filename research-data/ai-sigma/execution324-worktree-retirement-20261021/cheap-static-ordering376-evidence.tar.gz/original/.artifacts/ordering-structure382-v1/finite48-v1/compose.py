"""Write existing sequence/Run inputs after Root supplies actual current bindings.

No execution, admission, library/model/image loading or authority is performed.
Missing bindings produce no runnable settings. The maintained sequence owns
fresh per-operation paths, intent digests, job execution and once-finalization.
"""

import argparse
import copy
import hashlib
import json
from pathlib import Path


def reference(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


def compose(composition, bindings, destination):
    # These are existing Run fields supplied at the actual current boundary;
    # this helper does not revive historical caller/library/env identities.
    template = bindings["run_template"]
    libraries = bindings["dynamic_libraries"]
    roles = {"O": composition["bindings"]["O"], "N": bindings["N"]}
    for role in roles.values():
        role["artifact"]["path"]
        role["build_manifest"]["path"]
    for key in ("caller_sources", "env", "limits"):
        template[key]
    if not libraries or not template["caller_sources"]:
        raise ValueError("actual current caller/runtime bindings required")
    owner = Path(composition["owner"])
    destination = destination.resolve()
    destination.relative_to(owner)
    experiments = []
    templates = []
    original = json.loads(Path(composition["existing_experiment"]["path"]).read_text())
    for selected in composition["passes"]:
        binding = roles[selected["image_role"]]
        experiment = {
            **original,
            "build_manifest": binding["build_manifest"],
            "config": selected["config"],
            "inputs": composition["inputs"],
            "models": composition["models"],
            "dynamic_libraries": libraries,
            "schedule": selected["schedule"],
            "numerical_qualification": None,
            "canonical_plan_sha256": "",
            "planned_slots": selected["planned"],
            "batch": selected["index"],
            "argv": [
                binding["artifact"]["path"],
                "measure",
                "--experiment",
                "@EXPERIMENT@",
                "--experiment-sha256",
                "@EXPERIMENT_SHA256@",
            ],
        }
        experiments.append(
            (destination / f"experiment-{selected['index']:03d}.json", experiment)
        )
    # No file is written until all actual binding inputs above are available.
    destination.mkdir(exist_ok=False)
    for selected, (path, experiment) in zip(
        composition["passes"], experiments, strict=True
    ):
        path.write_text(json.dumps(experiment, indent=2) + "\n")
        exp_ref = reference(path)
        spec = copy.deepcopy(template)
        placeholder = owner / f"template-{selected['index']:03d}"
        for key in ("admission", "intent_sha256", "settings", "approved_plan"):
            spec.pop(key, None)
        spec.update(
            kind="run",
            owner=str(owner),
            cwd="/workspaces/quoridor",
            output=str(placeholder / "operation"),
            data_root=str(placeholder / "data"),
            TMP=str(placeholder / "TMP"),
            artifact=roles[selected["image_role"]]["artifact"],
            experiment=exp_ref,
            finalizers=[],
            perf=None,
            owned_outputs=[str(owner)],
        )
        spec["env"]["TMPDIR"] = spec["TMP"]
        spec["env"].pop("PERF_BUILDID_DIR", None)
        spec["data"] = [
            {
                "name": name,
                "path": str(placeholder / "data" / file),
                "limit_B": composition["expected_settings"][selected["profile"]][
                    "output_bytes"
                ],
            }
            for name, file in (
                ("settings", "settings.json"),
                ("measurements", "measurements.jsonl"),
                ("result", "result.json"),
            )
        ]
        spec["argv"] = [
            a.replace("@EXPERIMENT@", exp_ref["path"]).replace(
                "@EXPERIMENT_SHA256@", exp_ref["sha256"]
            )
            for a in experiment["argv"]
        ]
        templates.append(spec)
    settings = {
        **composition["sequence_fields"],
        "owner": str(owner),
        "output": composition["sequence_output"],
        "measurements": templates,
    }
    path = destination / "settings.json"
    path.write_text(json.dumps(settings, indent=2) + "\n")
    ready_composition = {
        **composition,
        "bindings": roles,
        "status": "ACTUAL_BINDINGS_COMPOSED_NOT_LAUNCHED",
        "pending": ["Root actual serial slot and fresh entry guards"],
    }
    (destination / "comparison-inputs.json").write_text(
        json.dumps(ready_composition, indent=2) + "\n"
    )
    return reference(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--composition", type=Path, required=True)
    parser.add_argument("--bindings", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(
        json.dumps(
            compose(
                json.loads(args.composition.read_text()),
                json.loads(args.bindings.read_text()),
                args.output,
            )
        )
    )


if __name__ == "__main__":
    main()
