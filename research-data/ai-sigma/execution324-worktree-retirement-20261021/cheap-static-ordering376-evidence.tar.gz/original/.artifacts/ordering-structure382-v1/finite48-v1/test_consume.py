"""New synthetic saved-result checks. No Search, native process or shared asset."""

import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("ordering382_saved", HERE / "consume.py")
consumer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(consumer)


def fixture():
    requests = [
        {
            "id": name,
            "session": name,
            "root": i,
            "depth": 1,
            "node_cap": 100,
            "time_limit_ms": None,
            "diagnostic": False,
            "warmup": False,
        }
        for i, name in enumerate(("cold", "warm"))
    ]
    passes = [
        {
            "label": f"{profile}-{i}-{role}",
            "profile": profile,
            "image_role": role,
            "record": f"/synthetic/{profile}-{i}.json",
            "planned": len(requests),
        }
        for profile in ("control", "cheap")
        for i, role in enumerate(("O", "N", "N", "O"))
    ]
    bindings = {
        role: {
            "artifact": {"synthetic_role": role},
            "build_manifest": {"synthetic_build": role},
        }
        for role in ("O", "N")
    }
    composition = {
        "passes": passes,
        "bindings": bindings,
        "models": [],
        "inputs": [],
        "expected_settings": {
            profile: {"profile": profile, "seed": None}
            for profile in ("control", "cheap")
        },
        "expected_requests": requests,
        "expected_work_fields": ["nodes", "evaluations", "TT_hits"],
    }
    runs = []
    for selected in passes:
        rows = [
            {
                "request": request,
                "root": {"synthetic_position": request["root"]},
                "status": "COMPLETE",
                "root_body_including_journal_seconds": 1.0,
                "measurement": {
                    "status": "COMPLETE",
                    "returned": "Ok",
                    "stop": "DepthComplete",
                    "completed_depth": 1,
                    "value_bits": 1065353216,
                    "action": 2,
                    "PV": [2],
                    "root_legal_action_ids": [1, 2, 3],
                    "parent_unchanged": True,
                    "work": {"nodes": 10, "evaluations": 7, "TT_hits": 1},
                },
            }
            for request in requests
        ]
        whole = 10.0 if selected["image_role"] == "O" else 9.0
        result = {
            **{
                k: len(rows)
                for k in ("planned", "scheduled", "calls", "attempted", "complete")
            },
            **{
                k: 0
                for k in ("uncompleted", "unperformed", "unscheduled", "extra_calls")
            },
            "status": "COMPLETE",
            "errors": [],
            "remaining_requests": [],
            "measurements": rows,
            "session_domains": [
                {"session": request["session"], "domain": domain, "seconds": 0.01}
                for request in requests
                for domain in ("reset", "teardown")
            ],
            "whole_before_result_publication_seconds": whole,
        }
        binding = bindings[selected["image_role"]]
        runs.append(
            {
                "settings": {
                    "settings": composition["expected_settings"][selected["profile"]],
                    "execution": {"models": [], "inputs": []},
                    "artifact": binding["artifact"],
                    "code_build": binding["build_manifest"],
                    "code_version": {"synthetic_git": selected["image_role"]},
                },
                "result": result,
                "rows": rows,
                "sampled": False,
                "manifest_status": "PASS",
                "cleanup_complete": True,
                "remaining": [],
                "primary": None,
                "secondary": [],
                "saved_record_error": None,
            }
        )
    return composition, runs


class OrderingComparisonCheck(unittest.TestCase):
    def test_exact_full_work_and_role_images_are_distinct_from_missingness(self):
        composition, runs = fixture()
        report = consumer.interpret(composition, runs)
        self.assertEqual(report["reduction_decision"], "SUPPORTED_SELECTED_COMPARISON")
        self.assertNotEqual(
            report["records"][0]["actual_identity"],
            report["records"][1]["actual_identity"],
        )
        changed = copy.deepcopy(runs)
        changed[1]["rows"][0]["measurement"]["work"]["TT_hits"] += 1
        report = consumer.interpret(composition, changed)
        self.assertEqual(
            report["profiles"]["control"]["exact_order_work_status"], "FAIL"
        )
        self.assertIn(
            "work", report["profiles"]["control"]["contexts"][0]["differences"]
        )
        changed[1]["rows"][0]["measurement"]["work"]["TT_hits"] = None
        report = consumer.interpret(composition, changed)
        self.assertEqual(report["reduction_decision"], "UNKNOWN/UNSUPPORTED")
        self.assertEqual(
            report["profiles"]["control"]["contexts"][0]["observations"][1][
                "missing_work_counters"
            ],
            ["TT_hits"],
        )
        for field, value in (
            ("PV", [2, 1]),
            ("parent_unchanged", False),
            ("root_legal_action_ids", [2, 3]),
        ):
            changed = copy.deepcopy(runs)
            changed[1]["rows"][0]["measurement"][field] = value
            self.assertNotEqual(
                consumer.interpret(composition, changed)["reduction_decision"],
                "SUPPORTED_SELECTED_COMPARISON",
            )

    def test_missing_terminal_prefix_is_retained_without_completeness_or_timing(self):
        composition, runs = fixture()
        saved = json.loads((HERE / "composition.json").read_text())
        reader = consumer.common_reader(saved)
        partial = {
            "status": "FAILED",
            "cleanup_complete": True,
            "remaining": [],
            "primary": {"stage": "cancelled"},
            "secondary": [],
            "data": {
                "measurement": {
                    "settings": runs[1]["settings"],
                    "result": None,
                    "recorded_prefix": [runs[1]["rows"][0]],
                    "runtime_launch_origin": {"guardian": {}, "native": {}},
                }
            },
        }
        with tempfile.TemporaryDirectory(
            dir=HERE, prefix="synthetic-only-"
        ) as directory:
            path = Path(directory) / "partial.json"
            path.write_text(json.dumps(partial))
            runs[1] = reader.read_run(
                {"label": "partial", "record": str(path), "planned": 2}
            )
            report = consumer.interpret(composition, runs)
        self.assertEqual(report["reduction_decision"], "UNKNOWN/UNSUPPORTED")
        self.assertEqual(report["records"][1]["available_prefix_rows"], 1)
        self.assertIsNone(report["records"][1]["counts"]["complete"])
        self.assertIsNone(
            report["records"][1]["whole_before_result_publication_seconds"]
        )
        self.assertIsNone(
            report["profiles"]["control"]["contexts"][1]["observations"][1]["row_index"]
        )

    def test_both_new_contexts_and_each_profile_whole_gate_keep_exact_boundaries(self):
        composition, runs = fixture()
        for index in (1, 2):
            runs[index]["rows"][0]["root_body_including_journal_seconds"] = 1.1
        self.assertEqual(
            consumer.interpret(composition, runs)["reduction_decision"],
            "SUPPORTED_SELECTED_COMPARISON",
        )
        runs[1]["rows"][0]["root_body_including_journal_seconds"] = 1.2
        self.assertEqual(
            consumer.interpret(composition, runs)["reduction_decision"],
            "SUPPORTED_SELECTED_COMPARISON",
        )
        runs[2]["rows"][0]["root_body_including_journal_seconds"] = 1.2
        report = consumer.interpret(composition, runs)
        self.assertEqual(report["profiles"]["control"]["timing_gate"], "FAIL")
        self.assertTrue(
            report["profiles"]["control"]["contexts"][0]["both_N_adverse_over_1_10"]
        )
        _, runs = fixture()
        for index in (5, 6):
            runs[index]["result"]["whole_before_result_publication_seconds"] = 10.01
        self.assertEqual(
            consumer.interpret(composition, runs)["profiles"]["cheap"]["timing_gate"],
            "FAIL",
        )
        runs[5]["result"]["whole_before_result_publication_seconds"] = None
        self.assertEqual(
            consumer.interpret(composition, runs)["reduction_decision"],
            "UNKNOWN/UNSUPPORTED",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
