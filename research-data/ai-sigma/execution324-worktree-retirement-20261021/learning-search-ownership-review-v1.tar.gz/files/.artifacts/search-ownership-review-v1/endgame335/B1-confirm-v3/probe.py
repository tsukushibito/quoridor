"""Independent current-main AST fake ports; no producer/runtime import."""

import ast
import json
import resource
import signal
import time
from pathlib import Path
from types import SimpleNamespace

resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
SOURCE = Path(
    "/workspaces/quoridor/.worktree/endgame-solver335/.artifacts/endgame335/qualification-v1/guard.py"
)
started = time.monotonic()
main = next(
    n
    for n in ast.parse(SOURCE.read_text()).body
    if isinstance(n, ast.FunctionDef) and n.name == "main"
)


def case(origin, faults):
    events, outputs = [], []
    primary = (
        OSError("original START IO")
        if origin == "start"
        else ValueError("original identity")
    )

    def operation(stage):
        events.append(stage)
        if stage in faults:
            raise PermissionError(stage)

    class FakePath:
        def __init__(self, value):
            self.value = str(value)

        def __truediv__(self, value):
            return FakePath(self.value + "/" + str(value))

        @property
        def name(self):
            return self.value.rsplit("/", 1)[-1]

        def open(self, mode):
            assert mode in ("a", "xb")
            stage = "lease" if mode == "a" else "log"
            operation(stage + "_open")
            return SimpleNamespace(close=lambda: operation(stage + "_close"))

        def read_text(self):
            assert self.value == "/proc/meminfo"
            return "MemAvailable: 8388608 kB\n"

        def write_text(self, value):
            stage = (
                "START_record" if self.value.endswith("-START.json") else "STOP_record"
            )
            events.append(stage)
            if stage == "START_record" and origin == "start":
                raise primary
            if stage in faults:
                raise PermissionError(stage)
            if stage == "STOP_record":
                outputs.append(json.loads(value))

    class Child:
        pid, returncode, waits = 900001, None, 0

        def poll(self):
            return 0

        def terminate(self):
            operation("direct_TERM")

        def kill(self):
            operation("direct_KILL")

        def wait(self, timeout):
            assert timeout == 3
            self.waits += 1
            stage = "first_wait" if self.waits == 1 else "second_wait"
            operation(stage)
            self.returncode = 0

    child = Child()

    def spawn(*args, **kwargs):
        operation("fake_spawn")
        assert kwargs["start_new_session"] is True
        return child

    def identity(pid):
        operation("identity")
        if origin == "identity":
            raise primary
        return {"pid": pid, "start": "fake", "boot": "fake"}

    def alive(item):
        operation("remaining_census")
        return False

    def flock(lease, flags):
        operation("lease_unlock" if flags == 8 else "lease_lock")

    def stdout(value):
        outputs.append(json.loads(value))
        operation("terminal_stdout")

    def allocated():
        operation("final_allocated")
        return 0

    namespace = {
        "sys": SimpleNamespace(argv=["guard.py", "mock", "/fake/cargo"]),
        "Path": FakePath,
        "HERE": FakePath("/fake/own"),
        "fcntl": SimpleNamespace(flock=flock, LOCK_EX=2, LOCK_NB=4, LOCK_UN=8),
        "os": SimpleNamespace(
            sched_setaffinity=lambda *a: None,
            environ={},
            getpid=lambda: 1,
            getppid=lambda: 2,
        ),
        "competitors": lambda owned: [],
        "rss": lambda pid: 0,
        "allocated": allocated,
        "stamp": lambda: "mock-time",
        "time": SimpleNamespace(monotonic=lambda: 0.0),
        "subprocess": SimpleNamespace(Popen=spawn, STDOUT=-2),
        "signal": signal,
        "JOB": SimpleNamespace(
            runtime=SimpleNamespace(process_identity=identity, alive=alive),
            signal_members=lambda known, sig: operation(
                "owned_TERM" if sig == signal.SIGTERM else "owned_KILL"
            ),
        ),
        "json": json,
        "print": stdout,
    }
    exec(
        compile(ast.Module(body=[main], type_ignores=[]), str(SOURCE), "exec"),
        namespace,
    )
    caught = None
    try:
        namespace["main"]()
    except BaseException as error:
        caught = error
    assert child.waits >= 1
    assert all(
        s in events
        for s in (
            "log_close",
            "lease_unlock",
            "lease_close",
            "final_allocated",
            "STOP_record",
            "terminal_stdout",
        )
    )
    if origin:
        assert caught is primary
        assert "direct_TERM" in events
        notes = " ".join(caught.__notes__)
        for f in faults:
            assert f in notes, (f, notes)
    else:
        assert isinstance(caught, SystemExit) and caught.code == 1
    if "first_wait" in faults:
        assert child.waits == 2
        assert "owned_KILL" in events and "direct_KILL" in events
    return {
        "origin": origin,
        "faults": sorted(faults),
        "events": events,
        "waits": child.waits,
        "primary_same_object": caught is primary if origin else None,
        "status_failed": caught is not None,
        "receipt_direct_wait": outputs[-1]["direct_wait"],
        "census": outputs[-1]["remaining"],
        "notes": getattr(caught, "__notes__", []),
    }


results = [
    case("start", set()),
    case(
        "start",
        {
            "owned_TERM",
            "direct_TERM",
            "first_wait",
            "owned_KILL",
            "direct_KILL",
            "log_close",
            "remaining_census",
            "lease_unlock",
            "lease_close",
            "final_allocated",
            "STOP_record",
            "terminal_stdout",
        },
    ),
    case("identity", set()),
    case(None, {"remaining_census", "STOP_record"}),
]
print(
    json.dumps(
        {
            "PASS": len(results),
            "scope": "actual main AST; fake child/IO/identity/lease only",
            "real_spawn_calls": 0,
            "wall": time.monotonic() - started,
            "VmHWM_KiB": next(
                int(x.split()[1])
                for x in Path("/proc/self/status").read_text().splitlines()
                if x.startswith("VmHWM:")
            ),
            "cases": results,
        },
        indent=2,
    )
)
