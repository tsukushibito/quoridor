"""Metadata-only actual helper AST fake ports; no guard/runtime import."""

import ast
import json
import resource
import time
from pathlib import Path
from types import SimpleNamespace

resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
start = time.monotonic()
source = Path(
    "/workspaces/quoridor/.worktree/endgame-solver335/.artifacts/endgame335/qualification-v1/guard.py"
)
node = next(
    n
    for n in ast.parse(source.read_text()).body
    if isinstance(n, ast.FunctionDef) and n.name == "completed_notification"
)
identity = {"pid": 123, "start_ticks": "321", "boot_id": "bound"}
args = [
    "/own/python3",
    "-B",
    "/workspaces/quoridor/scripts/dev/research-job.py",
    "run",
    "--state-dir",
    "/own/state",
]
results = []


def check(
    label,
    expect=False,
    state_change=None,
    result_change=None,
    delete=None,
    fault=None,
    argv=None,
):
    state = {"supervisor": identity, "phase": "finished", "job_id": "job"}
    result = {
        "job_id": "job",
        "direct_child_reaped": True,
        "cleanup_complete": True,
        "remaining": [],
        "cleanup_errors": [],
    }
    state.update(state_change or {})
    result.update(result_change or {})
    if delete:
        (state if delete[0] == "state" else result).pop(delete[1])
    reads, ids = [], []

    class Port:
        def __init__(self, value):
            self.value = str(value)

        @property
        def name(self):
            return self.value.rsplit("/", 1)[-1]

        def __truediv__(self, name):
            return Port(self.value + "/" + name)

        def read_bytes(self):
            reads.append(self.name)
            if fault == "missing" and self.name == "result.json":
                raise FileNotFoundError(self.name)
            if fault == "malformed":
                return b"{"
            if fault == "changed" and len(reads) > 2:
                return b"{}"
            return json.dumps(state if self.name == "state.json" else result).encode()

    def identify(pid):
        assert pid == 123
        ids.append(pid)
        if fault == "missing_identity":
            return None
        if fault == "changed_identity" and len(ids) > 1:
            return {**identity, "start_ticks": "reused"}
        return identity

    namespace = {
        "Path": Port,
        "json": json,
        "JOB": SimpleNamespace(runtime=SimpleNamespace(process_identity=identify)),
    }
    exec(
        compile(ast.Module(body=[node], type_ignores=[]), str(source), "exec"),
        namespace,
    )
    actual = namespace["completed_notification"](123, args if argv is None else argv)
    assert actual is expect, (label, actual)
    if argv is not None:
        assert reads == [] and ids == []
    results.append(
        {
            "case": label,
            "excluded": actual,
            "metadata_reads": len(reads),
            "identities": len(ids),
        }
    )


check("canonical completed", True)
for key in ("supervisor", "phase", "job_id"):
    check("missing state " + key, delete=("state", key))
for key in (
    "job_id",
    "direct_child_reaped",
    "cleanup_complete",
    "remaining",
    "cleanup_errors",
):
    check("missing result " + key, delete=("result", key))
check("running", state_change={"phase": "running"})
check("wrong supervisor", state_change={"supervisor": {**identity, "pid": 124}})
check("wrong job", result_change={"job_id": "other"})
for label, change in [
    ("not reaped", {"direct_child_reaped": False}),
    ("numeric not boolean", {"cleanup_complete": 1}),
    ("live remaining", {"remaining": [123]}),
    ("unknown remaining", {"remaining": None}),
    ("cleanup error", {"cleanup_errors": ["IO"]}),
]:
    check(label, result_change=change)
for fault in (
    "missing",
    "malformed",
    "changed",
    "missing_identity",
    "changed_identity",
):
    check(fault, fault=fault)
for index, replacement in [
    (0, "/own/cargo"),
    (1, "-u"),
    (2, "/other/job.py"),
    (3, "submit"),
    (4, "--other"),
]:
    changed = args.copy()
    changed[index] = replacement
    check("argv mismatch " + str(index), argv=changed)
check("extra argv", argv=args + ["extra"])
print(
    json.dumps(
        {
            "PASS": len(results),
            "wall": time.monotonic() - start,
            "VmHWM_KiB": next(
                int(l.split()[1])
                for l in Path("/proc/self/status").read_text().splitlines()
                if l.startswith("VmHWM:")
            ),
            "real_process_IO_runtime_calls": 0,
            "cases": results,
        },
        indent=2,
    )
)
