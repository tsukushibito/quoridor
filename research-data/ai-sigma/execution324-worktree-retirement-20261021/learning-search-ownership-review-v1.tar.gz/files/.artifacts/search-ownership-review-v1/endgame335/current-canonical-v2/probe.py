"""One actual guard-main AST failure branch, with fake process/file ports only."""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import time
from types import SimpleNamespace

resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
start = time.monotonic()
source = Path(
    "/workspaces/quoridor/.worktree/endgame-solver335/.artifacts/endgame335/qualification-v1/guard.py"
)
raw = source.read_bytes()
assert (
    hashlib.sha256(raw).hexdigest()
    == "3a561aab798db5eec4d126f67c24201629f6ffe7e13b863aa0258c4e8a75bf44"
)
tree = ast.parse(raw)
main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "main")
events = []
primary = OSError("START receipt write refused")


class FakePath:
    def __init__(self, value):
        self.value = str(value)

    def __truediv__(self, value):
        return FakePath(self.value + "/" + str(value))

    def __str__(self):
        return self.value

    @property
    def name(self):
        return self.value.rsplit("/", 1)[-1]

    def read_text(self):
        assert self.value == "/proc/meminfo"
        return "MemAvailable: 4194304 kB\n"

    def open(self, mode):
        assert mode == "xb"
        events.append("open_own_log")
        return self

    def __enter__(self):
        return self

    def __exit__(self, *args):
        events.append("log_close")

    def write_text(self, text):
        events.append("START_write")
        assert self.value.endswith("-START.json")
        raise primary


class FakeChild:
    pid = 999
    returncode = None

    def wait(self, **kwargs):
        events.append("directwait")
        self.returncode = 0

    def poll(self):
        return 0


def spawn(*args, **kwargs):
    events.append("fake_spawn")
    return FakeChild()


ns = {
    "sys": SimpleNamespace(argv=["guard.py", "source_mock", "/fake/qualified_driver"]),
    "Path": FakePath,
    "HERE": FakePath("/fake/owned"),
    "os": SimpleNamespace(
        sched_setaffinity=lambda *a: None,
        getpid=lambda: 1,
        getppid=lambda: 2,
        environ={},
    ),
    "competitors": lambda owned: [],
    "rss": lambda pid: 0,
    "stamp": lambda: "mock-time",
    "time": SimpleNamespace(monotonic=lambda: 0.0),
    "subprocess": SimpleNamespace(Popen=spawn, STDOUT=-2),
    "JOB": SimpleNamespace(
        runtime=SimpleNamespace(process_identity=lambda pid: {"pid": pid}),
        signal_members=lambda *a: events.append("signal_cleanup"),
    ),
    "json": json,
}
exec(compile(ast.Module(body=[main], type_ignores=[]), str(source), "exec"), ns)
try:
    ns["main"]()
except OSError as caught:
    assert caught is primary
else:
    raise AssertionError("START write refusal required")
assert events == ["open_own_log", "fake_spawn", "START_write", "log_close"]
result = {
    "source_SHA256": hashlib.sha256(raw).hexdigest(),
    "actual_AST_body": "guard.main",
    "counterexample_reproduced": True,
    "events": events,
    "expected_after_spawn_failure": "directwait and owned cleanup attempted, primary and receipt failure retained",
    "actual_directwait_attempts": 0,
    "actual_signal_cleanup_attempts": 0,
    "real_Popen_jobs_runtime_payload_model_calls": 0,
    "wall_s": time.monotonic() - start,
    "VmHWM_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "CPU": [3],
    "STOP": datetime.now(timezone.utc).isoformat(),
    "owned_children": 0,
    "limits": "Fake process and file ports only; no live child, actual disk fault, Rust, geometry or allocator execution.",
}
with (Path(__file__).parent / "probe-result.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result))
