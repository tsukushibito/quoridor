# quoridor-4lc.335.1 current canonical v2

結論：genuine prefixと明示されたtrusted allocation/control契約の下で、public solve／private minimaxのfalse Provenへ至るsource経路は見つけなかった。数学/APIの条件付きblockers0。future finite driverのguardにはB1 [P1・通常修正]があり、その実行境界は未clear。driver14calls／page allocator実資格／全ゲーム／強度／default／Wasmは認定しない。

証拠root：`/workspaces/quoridor/.worktree/learning-million/.artifacts/search-ownership-review-v1/endgame335/current-canonical-v2`。target OWN WT qualification-v1のsource-bindings-v2 SHA `0499f85a09b1ea2a06f0efba15fbb33aaa4dc437d7e04169731a51120c9aa46e`、software-STOP-v2 SHA `913b606775e36185337fb213b5a4246dda3b78e60c968750b0ac8369aa3dcba0`。22 source/manifest/lockのSHA／length／modeを前後照合し不変。private-bindings-v2は4 ELFの宣言metadataだけを読んだ。実ELF／library／modelは読まず、提供compiler/receiptの連鎖の範囲に留めた。全path/SHAはcontrol.json。

## B1 [P1・通常修正] child生成後のSTART IOがwait finallyの外

固定guard.py SHA `3a561aab798db5eec4d126f67c24201629f6ffe7e13b863aa0258c4e8a75bf44`、127–143行。Popen後のidentity取得とSTART.json保存が、child.waitを含むtry/finallyより前にある。START保存がOSErrorになるとwait／owned signal cleanup／STOP receiptへ到達しない。

実main ASTをfake process/file portsで実行した。実eventsはlog open → fake spawn → START write refusal → log close。directwait=0、signal cleanup=0。期待はchildを作った瞬間から、後続metadata失敗でもそのchildのwaitと必要なowned cleanupを試行し、元原因と各失敗を保持すること。これはreal orphanやdisk faultの発生を主張するものではなく、将来の有限driver前に修正する具体的source branchである。新controller/frameworkを要求しない。producerだけが修正し、同reviewerへ固定rebindする。

## API／proofの確認

- public endgame.rs `c9d2a6e117966b5dc1ac3d4524fc13e59e63c60d5dec43dc64215d440cc552e0` はexplicit feature entry。borrowed action prefixをshared fd35 genuine factoryへ渡し、counts輸入や独自move/rules engineを持たない。rules ID・representation256・limits・input backing attribution・allocation boundを検査してから予約する。256とoperational ply capはcollection/control boundsで、200 terminalやdrawへ変換しない。both stocks0以外はNotApplicable。
- shared coreのinline initial occurrence=1＋overlay successorを一度ずつ取り、rootを重ねない。HistoryKeyはpawn／STM／両stock／H/V。makeはlegal/terminal／ply overflow／capacity拒否をmutation前に行い、private undo tokenでposition/ply/overlayを復元する。root prefixを含めcapacity prefix+max_framesで、frame上限で拒否される直前の一時childも収まる。一般clone/play/history_counts／Arcはexclusive cursor外。genuine replayなので、thirdはlegal transition後のdraw、goalが先、terminal後の続行は拒否。
- private kernel `3e7ede713dff7f97be0ca34a711d8cce688c230f267cc588fbb13af43a7a4a4d` はexplicit frames。child Loss witnessからWin、全childrenが解決している場合だけLoss/Draw。unknown siblingはDraw/Lossを妨げ、別のLoss witnessによるWinだけは成立する。空children／重複／wall IDs／rule errorを勝敗やdrawにしない。
- memoはinvocation-localでrules混在なし。full Position＋absolute ply＋正規化した全history countsを比較する。counts0／>3／overflow／history容量超過を拒否。count順をソートし同じkeyを加算するので、base/overlayの表現違いを同じ意味へ正規化する。partial keyはmemo recordを作らず、cancelで全invocationを停止する。12960 board-only tableの証明ではない。
- 予約・payload/capacity計数はchecked arithmetic。4 kernel vectorsと1 pathを一度予約し、実capacityを再計数する。push/insertは各予約上限の内側。途中制限／make失敗／undo失敗はproofを出さない。undo faultでprivate cursorが元へ戻らない場合はそのowned cursorをdropし、caller prefix/外部parentを変えない。全fault restorationの証明とはしない。正常cleanup後、storage/cursor drop後にもcancel/deadlineをsampleする。public whole clockはreplay前開始でclosure storage dropと最終sampleを含むが、callbackの無いprefix pass／allocator／OS scheduling／sampleから実returnまでをhardRTとはしない。
- Provenはterminalならbest_move=None、nonterminalなら合法attaining moveとExactRootHistory。private memoのmoveは同一position/countsで証明した合法move。fallbackは未証明と区別する。trusted source_ref文字列は自己認証器ではなく、Noneや無根拠のcaller attributionから資格を推定しない。

## Qualification-only allocatorと証拠範囲

qualified_driver.rs SHA `46d5321b596f62d1c4ca6d2ebaca9f99110d42dd83b81900c249407b2538c304` はLinux64限定、実entryでpage4096を要求する。各mapはheader page＋ceil(payload/4096) pages。checked sizing、alignment>4096/map failureのrefusal、header内のlength/tracked flag、同じbase/lengthのmunmapを読む限り、固定typesのalignment/backingの対応は成立する。headerはpage内、payloadはpage-alignedでrequested sizeを覆う。rounding＋headerは1 allocationあたり8192未満なので、path8192／4 vectors32768はこのallocatorの保守的source bound。System／Arc／OS VMA／RSS／全platformの証明ではない。munmap失敗はfailedに残り、tracked LIVEを減らさない。

ACTIVEはsolve直前から返却まで。prefix-precondition/root/legal vectorの一般APIは外側。予約後のcursor法はallocation-freeなshared path/mask/transitionを使い、想定5 mapsに対応する。calls<=5／mapped peak<=requested+calls*8192／reported heap bound／live0／failed0を実driverで要求する。default reallocの一時copy/freeも計数するが、このsolver正常経路では予約済みvectorsのgrowthは行わない。全実map・alignment・fault・transient peak検査は未実行なので、その成功を今回補わない。

七根のfull backingはPREFIX120B、draw124B、goal116B、near/obstructed68Bをslice長だけに縮めず渡す。cold/fresh二回ともgenuine factory preconditionsとlegal attaining moveを確認する。Unknownを有限refusalとして保存しexpected WDLの証明にしない設計で、driver exit0／correct=trueだけから全7 WDL成功を認定してはならない。個々のoutcomeとallocation結果が必要。未実行14callsの時間／速さ／常時ONを推測しない。

提供rawとdirectwait receiptsを限定読取し、現17 API/private tests＋5 independent graph algebra＋3 genuine-prefix testsの25 PASSを確認。Root56 Loss／60 Drawの独立depth-two証明は、canonical全legal child＋相手goal witness／third drawから組み立てられ、別pawn rules engineではない。synthetic accountingのunit結果はpage/System資格ではない。partial memo／make/unmake故障／after-drop cancel/deadlineを含む一方、実allocator faultとin-progress nested public reentryは未確認。owned no-deps Clippy PASSとbroader core lint failure、初回unlocked build／import／wrongcwdの失敗は別履歴で保持し、whole core品質や過去retrocomplianceへ昇格しない。

通常指摘C1 [P3]：test/sourceヘッダのUNEXECUTED／「type未確認」等は、現在の限定25 PASS／optimized buildと区別した表現へ更新する。platform driver／performance pendingという範囲は残す。

## 費用・保存・停止

独立実行は上記guard AST/fake-port反例1件のみ。whole0.019092226s、内部0.001251742s、VmHWM16400KiB、CPU3／RLIMIT_AS512MiB。自分のprobeのみRuff format0.065434227s。Rust／Cargo／geometry／allocator／model／native／ELF／job／network0。family peak／一部light readsの個別exact wallはUNKNOWN、計測済みBeads/hash/probe/admin費はcontrolに記録。提供25を再実行せず、旧privatekernel/algebraとcanonical331の不変部分の限定proofを再利用した。

reader/substantial analysis STOP `2026-10-08T09:19:58.881318+00:00`、own children/jobs/readers remaining `[]`、同期directwait。source/main/Git/index writer0。新evidence forecast262144B、latest forward cap8MiB inside335whole512MiB/proof68f528。旧used32768/raw/fees/UNKNOWNをrefundしない。16→8MiB steerをforward適用し、余剰を実験許可と解釈しない。

335.1だけclose／backupし、335＋324へ一度通知する。parent335未完了、defaults/Wasm/games/fit/323pause/seals不変。B1はfuture driver制御の通常修正で、数学の新しいmethod ACKや全run reviewer gateを要求しない。次のqueued331確認は、このreader/report/adminの自然STOP後に行う。
