"""New controller finalization only: actual AST, stdlib ports, no runtime imports."""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import time
from types import SimpleNamespace

resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
start = time.monotonic()
source = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/sigma-timed-v1/private-functional-v1/qualify.py"
)
raw = source.read_bytes()
assert (
    hashlib.sha256(raw).hexdigest()
    == "d974262b384bfdd6438e46c23ecd9533bc8b5576ac2b7f5cf2895dbbe26c0306"
)
tree = ast.parse(raw)
main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "main")
outer = next(n for n in main.body if isinstance(n, ast.Try))
primary = ValueError("original qualification failure")
cleanup = OSError("owned temporary unlink refused")
attempts = []


class FakeImage:
    def exists(self):
        return True

    def unlink(self):
        attempts.append("unlink")
        raise cleanup

    @property
    def parent(self):
        return SimpleNamespace(rmdir=lambda: attempts.append("rmdir"))


class FakeOut:
    def glob(self, pattern):
        attempts.append("process_receipt_census")
        return []


def fake_save(name, value):
    attempts.append("save:" + name)


ports = {
    "primary": primary,
    "created_image": True,
    "created_tmp": True,
    "image": FakeImage(),
    "OUT": FakeOut(),
    "result": {"qualified": False},
    "failure": None,
    "started": time.monotonic(),
    "resources": SimpleNamespace(
        finance=SimpleNamespace(held=35225600, unknown=[]),
        rss_peak=0,
        output_peak=0,
        tmp_peak=0,
    ),
    "save": fake_save,
    "time": time,
    "datetime": datetime,
    "timezone": timezone,
    "json": json,
}
derived = ast.Try(
    body=[ast.Raise(exc=ast.Name(id="primary", ctx=ast.Load()))],
    handlers=outer.handlers,
    orelse=[],
    finalbody=outer.finalbody,
)
module = ast.fix_missing_locations(ast.Module(body=[derived], type_ignores=[]))
try:
    exec(compile(module, str(source), "exec"), ports)
except OSError as caught:
    assert caught is cleanup
else:
    raise AssertionError("cleanup refusal must propagate")
assert ports["failure"] == repr(primary)
assert attempts == ["unlink"]
assert "error" not in ports["result"]
facts = [
    {
        "case": "actual main exception handler/finally with failed owned unlink",
        "counterexample_reproduced": True,
        "actual_attempts": attempts.copy(),
        "expected_later_attempts": [
            "rmdir",
            "process_receipt_census",
            "save:result.json",
        ],
        "original_primary_persisted": False,
        "result_retained_charge_persisted": False,
    }
]

resources = next(
    n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "Resources"
)
check = next(
    n for n in resources.body if isinstance(n, ast.FunctionDef) and n.name == "check"
)
finance_try = next(n for n in check.body if isinstance(n, ast.Try))
finance_failure = PermissionError("financial stat refused")
receipt_failure = OSError("charge persistence refused")


def refusing_check():
    raise finance_failure


def refusing_save(name, value):
    attempts.append(name)
    raise receipt_failure


ports = {
    "self": SimpleNamespace(
        finance=SimpleNamespace(
            check=refusing_check, record=lambda a: {"held": 35225600}
        ),
        a={},
    ),
    "save": refusing_save,
}
try:
    exec(
        compile(
            ast.fix_missing_locations(ast.Module(body=[finance_try], type_ignores=[])),
            str(source),
            "exec",
        ),
        ports,
    )
except OSError as caught:
    assert caught is receipt_failure
    assert caught.__context__ is finance_failure
else:
    raise AssertionError("persistence refusal must propagate")
facts.append(
    {
        "case": "actual Resources.check financial try/finally with save failure",
        "counterexample_reproduced": True,
        "charge_save_attempts": 1,
        "explicit_primary_and_secondary_fact_aggregation": False,
        "original_finance_exception_only_in_implicit_context": True,
    }
)
result = {
    "source_SHA256": hashlib.sha256(raw).hexdigest(),
    "facts": facts,
    "wall_s": time.monotonic() - start,
    "VmHWM_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "CPU": [3],
    "STOP": datetime.now(timezone.utc).isoformat(),
    "owned_children": 0,
    "runtime_model_Popen_payload_calls": 0,
    "limits": "Actual AST handlers/finally with fake owned-path/finance/save ports; not disk fault, compiler, CLI, backend or process cleanup qualification.",
}
with (Path(__file__).parent / "probe-result.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result))
