# quoridor-4lc.331.1 R1a/R1b confirmation v14

Result: R1a/R1b resolved on this fixed source; blockers0, ordinary source findings0. Optional private-profile source clear only. Prepared entry remains false; no actual CLI/model/runtime/private/physics qualification or job authority follows.

Evidence root: /workspaces/quoridor/.worktree/learning-million/.artifacts/search-ownership-review-v1/sigma-deadline-v1/private-functional-R1ab-confirm-v14
Target packet SHA256 f5647e6bacf9e1b5d60d356a0f1011de2669c2dafe964e61cea1c9f8c70c12f5
Controller SHA256 035e8d72287bca22266bd9fd68d8321c786c211235b97381b65a7c353ddda350
All23 bound source/control/archive refs match SHA/size/mode before/after; binding-map digests and exact target path in control.json. Prior controller gzip restores 1b65f38a exactly.

R1a: finalize now clears qualified for every supplied primary (failure is not None), before result persistence. Actual function with primary + initially qualified=true + all nine verified receipts saves qualified=false and retains primary. Cleanup can still be verified independently of qualification.

R1b: Resources owns an invocation-local attempted_children list. execute registers the exact receipt path and argv BEFORE P.execute and refuses duplicate receipt use. The maintained P.execute source records the same string command vector under command. All phases compare actual paths with registered attempts, then compare each command plus direct wait/cleanup/remaining facts. Absent/duplicate registry, missing/unexpected/unreadable receipt, wrong argv or unverified cleanup produce UNKNOWN and cannot claim empty verified census. Exact successful-nine census still applies. Only an explicit zero-attempt registry or a completely verified partial registry establishes cleanup on a failed job.

Independent actual-AST/fake-port probe: primary + nine receipts; five missing/partial/wrongargv/unverified/absent-registry subcases; explicit zero and verified partial; registration before a refused execution port. All PASS; primary object from the refused port preserved. No real P.execute/Popen/backend/import/payload calls. Whole0.029013705s, internal0.008276705s, VmHWM17780KiB, CPU3/AS512MiB. Own probe Ruff formatted0.183736304s. Supplied new2 tests PASS0.045188889s remain separate evidence, not replayed. Old4/R1/private-input/CLI/math proofs reused.

validate/replay_checks/collect_run/main ASTs are unchanged from preserved v13. Final charge/result/terminal-fallback handling is reused from R1; filesystem success is not guaranteed. Old raw/65KiB breach/fees/UNKNOWN remain held. Future proof68f supports whole4GiB, prepared source policy32MiB is future metadata, not retrocompliance or an actual admission. Current source/private/proof/caps/quiet/soleCargo obligations remain; direct Rust1.99 software route does not require this optional profile or another human method ACK.

Administrative deviation retained: initial fresh-context lookup in the last1MiB found no turn_context. The sequential orchestration nevertheless completed ready/show/claim/packet-read/new-control before the corrective lookup. This was not strict fresh-verification-before-admin compliance. No source analysis/science occurred before bounded8MiB context filtering reverified actual gpt-6.1-sol/high/learning-million/danger-full-access/never. No old reasoning was used as evidence. Failure and costs remain in control; no retrocompliance claim. Effective permissions themselves matched the already verified current turn.

Reader/substantial analysis STOP 2026-10-08T09:32:21.546551+00:00. Own fixture children directwait, remaining[]. Source/main/Git/index writer0; Cargo/model/runtime/library/ELF/job0. Family peak and some read exact walls UNKNOWN; measured command/hash/probe fees retained. New own namespace inclusive<=32768; all old evidence retained.

Only331.1 closes/backup, once each331+324. Current340 and335 completed their natural STOP/report/backup/notifications before this queued scope. Parent331 remains incomplete; paused323/seals/defaults unchanged.

