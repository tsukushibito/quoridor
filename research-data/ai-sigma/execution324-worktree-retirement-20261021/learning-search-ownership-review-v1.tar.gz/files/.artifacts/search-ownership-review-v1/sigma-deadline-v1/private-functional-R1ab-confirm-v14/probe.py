"""R1a/R1b-only actual AST and fake receipt/execution ports; no runtime imports."""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import time
from types import SimpleNamespace

resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
start = time.monotonic()
source = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/sigma-timed-v1/private-functional-v1/qualify.py"
)
raw = source.read_bytes()
assert (
    hashlib.sha256(raw).hexdigest()
    == "035e8d72287bca22266bd9fd68d8321c786c211235b97381b65a7c353ddda350"
)
tree = ast.parse(raw)
nodes = [
    n
    for n in tree.body
    if isinstance(n, ast.FunctionDef)
    and n.name in ["error_fact", "finalize", "execute"]
]


class Receipt:
    def __init__(self, name, wrong=False, verified=True):
        self.name = name
        self.wrong, self.verified = wrong, verified

    def __str__(self):
        return "/owned/" + self.name

    def read_text(self):
        return json.dumps(
            {
                "command": ["wrong"] if self.wrong else ["image", self.name],
                "direct_child_reaped": self.verified,
                "cleanup_complete": self.verified,
                "remaining": [],
            }
        )


def fixture(names, paths, primary, qualified=False, registry=True):
    saved = {}
    ns = {
        "json": json,
        "datetime": datetime,
        "timezone": timezone,
        "time": time,
        "OUT": SimpleNamespace(glob=lambda p: paths),
        "save": lambda name, value: saved.update({name: json.loads(json.dumps(value))}),
    }
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), "exec"), ns)
    res = SimpleNamespace(
        finance=SimpleNamespace(
            held=35225600,
            unknown=[],
            check=lambda: None,
            record=lambda a: {"held": 35225600},
        ),
        financial_errors=[],
        charge_io_errors=[],
        rss_peak=0,
        output_peak=0,
        tmp_peak=0,
    )
    if registry:
        res.attempted_children = [
            {"receipt": "/owned/" + name, "argv": ["image", name]} for name in names
        ]
    image = SimpleNamespace(parent=SimpleNamespace(iterdir=lambda: []))
    result = {"qualified": qualified}
    ns["finalize"](
        result,
        primary,
        res,
        {"caps_B": {"positive": 39845888}},
        image,
        False,
        False,
        time.monotonic(),
    )
    return saved["result.json"]


names = [
    "NN0-terminal.process.json",
    "NN0-postterminal.process.json",
    "NN0-wrong-terminal-ply.process.json",
] + [
    op + "-" + name + ".process.json"
    for name in ["initial", "p2"]
    for op in ["arena", "audit", "recover"]
]
result = fixture(names, [Receipt(n) for n in names], "original primary", True)
assert result["qualified"] is False and result["primary_error"] == "original primary"
assert result["all_direct_children_reaped"] and result["cleanup_complete"]
facts = [
    {
        "case": "primary + qualifiedtrue + nine verified receipts",
        "PASS": True,
        "saved_qualified": result["qualified"],
    }
]
cases = [
    (["one.process.json"], [], True),
    (["one.process.json", "two.process.json"], [Receipt("one.process.json")], True),
    (["one.process.json"], [Receipt("one.process.json", wrong=True)], True),
    (["one.process.json"], [Receipt("one.process.json", verified=False)], True),
    ([], [], False),
]
for ns, paths, registry in cases:
    result = fixture(ns, paths, "failed partial", registry=registry)
    assert (
        not result["qualified"]
        and not result["all_direct_children_reaped"]
        and not result["cleanup_complete"]
    )
    assert any(r.get("status") == "UNKNOWN" for r in result["remaining"])
    assert result["charged_positive_union_B"] == 35225600
facts.append(
    {
        "case": "missing/partial/wrongargv/unverified/absent registry",
        "PASS": True,
        "subcases": len(cases),
        "all_UNKNOWN": True,
    }
)
for ns, paths in [([], []), (["one.process.json"], [Receipt("one.process.json")])]:
    result = fixture(ns, paths, "other failure")
    assert (
        not result["qualified"]
        and result["all_direct_children_reaped"]
        and result["cleanup_complete"]
        and result["remaining"] == []
    )
facts.append(
    {
        "case": "explicit zero and verified partial registry",
        "PASS": True,
        "subcases": 2,
        "cleanup_verified_without_qualified": True,
    }
)
ledger = []
primary = OSError("preflight refused before child")
events = []


class LogPort:
    def __str__(self):
        return "/owned/one.process.json"

    def with_suffix(self, suffix):
        return self


class OutPort:
    def __truediv__(self, name):
        return LogPort()


def execute_port(*args, **kwargs):
    assert ledger == [
        {
            "name": "one",
            "receipt": "/owned/one.process.json",
            "argv": ["image", "arena", "--recover", "/owned/expected"],
        }
    ]
    events.append("registered_before_execution_port")
    raise primary


ns = {
    "OUT": OutPort(),
    "P": SimpleNamespace(
        execute=execute_port, CycleStopped=type("Stopped", (Exception,), {})
    ),
    "json": json,
}
exec(
    compile(
        ast.Module(
            body=[next(n for n in nodes if n.name == "execute")], type_ignores=[]
        ),
        str(source),
        "exec",
    ),
    ns,
)
try:
    ns["execute"](
        "image",
        ["arena", "--recover", "/owned/expected"],
        "one",
        SimpleNamespace(attempted_children=ledger),
    )
except OSError as caught:
    assert caught is primary
else:
    raise AssertionError("original port error required")
assert events == ["registered_before_execution_port"]
facts.append(
    {
        "case": "actual execute registers exact argv/receipt before refused P.execute port",
        "PASS": True,
        "primary_object_preserved": True,
    }
)
result = {
    "source_SHA256": hashlib.sha256(raw).hexdigest(),
    "facts": facts,
    "wall_s": time.monotonic() - start,
    "VmHWM_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "CPU": [3],
    "STOP": datetime.now(timezone.utc).isoformat(),
    "owned_children": 0,
    "model_runtime_Popen_payload_calls": 0,
    "limits": "Actual Python AST/fake ports only; not live disk/process/backend qualification.",
}
with (Path(__file__).parent / "probe-result.json").open("x") as f:
    json.dump(result, f, indent=2)
    f.write("\n")
print(json.dumps(result))
