"""Only current collector and five-receipt census AST, metadata/fake ports."""

import ast
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import time
from types import SimpleNamespace

resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
start = time.monotonic()
q = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/sigma-timed-v1/live-qualified-current-recovery-v2"
)
a = json.loads((q / "admission.prepared.json").read_text())
helper = ast.parse((q / "reviewed_helpers.py").read_text())
node = lambda name: next(
    n for n in helper.body if isinstance(n, ast.FunctionDef) and n.name == name
)
old = {}
for filename in ("result.json", "manifest.json"):
    path = str(Path(a["completed_initial_run"]) / filename)
    raw = Path(path).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == a["bindings"][path]
    old[path] = json.loads(raw)
reads = []
mutate = None


def bound(admission, path):
    reads.append(path)
    value = copy.deepcopy(old[path])
    if mutate and path.endswith("result.json"):
        mutate(value)
    return value


ns = {"OUT": q, "Path": Path, "bound_json": bound, "json": json}
exec(
    compile(
        ast.Module(body=[node("collect_run")], type_ignores=[]),
        "actual-collector",
        "exec",
    ),
    ns,
)
collected = ns["collect_run"]("initial", a)
assert len(collected["accepted_windows"]) == 2
assert sorted(o["engine_index"] for o in collected["accepted_windows"]) == [0, 1]
assert reads == [
    str(Path(a["completed_initial_run"]) / filename)
    for filename in ("result.json", "manifest.json")
]
collector_cases = [
    {
        "case": "actual bound initial metadata",
        "accepted_census": [0, 1],
        "model_or_root_replay": False,
    }
]
for name, change in [
    (
        "reason/failure conflation",
        lambda value: value["outcomes"][0].update(reason="ply_cap"),
    ),
    (
        "duplicate engine",
        lambda value: value["outcomes"][1]["observations"][0].update(engine_index=0),
    ),
]:
    mutate = change
    try:
        ns["collect_run"]("initial", a)
    except ValueError as error:
        collector_cases.append({"case": name, "refused": str(error)})
    else:
        raise AssertionError("invalid collector accepted")

names = ["audit-initial", "recover-initial", "arena-p2", "audit-p2", "recover-p2"]
argv = {}
for name in names:
    target = a["completed_initial_run"] if name.endswith("initial") else "/new/run-p2"
    if name == "arena-p2":
        argv[name] = ["/new/image", "arena", "--config", "/new/config-p2.json"]
    else:
        argv[name] = ["/new/image", "arena", "--" + name.split("-")[0], target]
finalizer_cases = []
for case in ("exact-five", "missing-one", "extra-old-receipt", "mismatched-argv"):
    records = {
        name + ".process.json": {
            "command": argv[name],
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
        }
        for name in names
    }
    if case == "missing-one":
        records.pop("recover-p2.process.json")
    if case == "extra-old-receipt":
        records["NN0-terminal.process.json"] = {
            "command": ["old"],
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
        }
    if case == "mismatched-argv":
        records["recover-initial.process.json"]["command"] = ["/wrong/image", "arena"]

    class Receipt:
        def __init__(self, name):
            self.name = name

        def __str__(self):
            return "/new/" + self.name

        def read_text(self):
            return json.dumps(records[self.name])

    class Output:
        def glob(self, pattern):
            assert pattern == "*.process.json"
            return [Receipt(name) for name in records]

    saved = {}

    def save(name, value):
        saved[name] = copy.deepcopy(value)

    resources = SimpleNamespace(
        attempted_children=[
            {"receipt": "/new/" + name + ".process.json", "argv": argv[name]}
            for name in names
        ],
        finance=SimpleNamespace(
            check=lambda: None,
            held=35225600,
            record=lambda a: {},
            unknown=["legacy retained UNKNOWN"],
        ),
        financial_errors=[],
        charge_io_errors=[],
        rss_peak=0,
        output_peak=0,
        tmp_peak=0,
    )
    ports = {
        "OUT": Output(),
        "json": json,
        "datetime": datetime,
        "timezone": timezone,
        "time": SimpleNamespace(monotonic=lambda: 1),
        "save": save,
    }
    exec(
        compile(
            ast.Module(body=[node("error_fact"), node("finalize")], type_ignores=[]),
            "actual-finalize",
            "exec",
        ),
        ports,
    )
    result = {"qualified": True}
    failure = ports["finalize"](
        result,
        None,
        resources,
        {"caps_B": {"positive": 35225600}},
        SimpleNamespace(parent=SimpleNamespace(iterdir=lambda: iter(()))),
        False,
        False,
        0,
    )
    expected = case == "exact-five"
    assert saved["result.json"]["qualified"] is expected
    assert saved["result.json"]["cleanup_complete"] is expected
    assert (failure is None) is expected
    if not expected:
        assert any(r.get("status") == "UNKNOWN" for r in result["remaining"])
    finalizer_cases.append(
        {
            "case": case,
            "qualified": result["qualified"],
            "cleanup": result["cleanup_complete"],
            "status_matches_expected": True,
        }
    )
print(
    json.dumps(
        {
            "PASS_cases": len(collector_cases) + len(finalizer_cases),
            "scope": "actual source AST; old bound JSON metadata + fake receipt/save ports; no new model/root or process execution",
            "model_native_runtime_Popen_calls": 0,
            "wall": time.monotonic() - start,
            "VmHWM_KiB": next(
                int(l.split()[1])
                for l in Path("/proc/self/status").read_text().splitlines()
                if l.startswith("VmHWM:")
            ),
            "collector": collector_cases,
            "census": finalizer_cases,
        },
        indent=2,
    )
)
