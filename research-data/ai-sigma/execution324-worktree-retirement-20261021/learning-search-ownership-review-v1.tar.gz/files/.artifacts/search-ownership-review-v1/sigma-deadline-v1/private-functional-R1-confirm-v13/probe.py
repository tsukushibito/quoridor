"""R1-only independent actual-AST tests; no runtime, model or child process ports."""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import time
from types import SimpleNamespace

resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
start = time.monotonic()
source = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/sigma-timed-v1/private-functional-v1/qualify.py"
)
raw = source.read_bytes()
assert (
    hashlib.sha256(raw).hexdigest()
    == "1b65f38a5b0bed74d4af4c3e30f9fe2ca22e08c9274269b336609a0789dcec5a"
)
tree = ast.parse(raw)
functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
body = [functions["error_fact"], functions["finalize"]]
facts = []


class Receipt:
    def __init__(self, name):
        self.name = name

    def read_text(self):
        return json.dumps(
            {"direct_child_reaped": True, "cleanup_complete": True, "remaining": []}
        )


def ports(receipts, unlink_failure=False):
    events, saved = [], {}

    def unlink(missing_ok=False):
        events.append("unlink")
        if unlink_failure:
            raise OSError("owned unlink refused")

    def save(name, value):
        events.append("save:" + name)
        saved[name] = json.loads(json.dumps(value))

    finance = SimpleNamespace(
        held=35225600,
        unknown=[],
        check=lambda: events.append("financial_check"),
        record=lambda a: {"charged_positive_union_B": 35225600},
    )
    res = SimpleNamespace(
        finance=finance,
        financial_errors=[],
        charge_io_errors=[],
        rss_peak=0,
        output_peak=0,
        tmp_peak=0,
    )
    ns = {
        "datetime": datetime,
        "timezone": timezone,
        "time": time,
        "json": json,
        "save": save,
        "OUT": SimpleNamespace(glob=lambda p: receipts),
        "print": lambda *a, **k: events.append("terminal_stdout"),
    }
    exec(compile(ast.Module(body=body, type_ignores=[]), str(source), "exec"), ns)
    image = SimpleNamespace(
        unlink=unlink,
        parent=SimpleNamespace(
            rmdir=lambda: events.append("rmdir"), iterdir=lambda: []
        ),
    )
    return ns, image, res, events, saved


main = functions["main"]
outer = next(n for n in main.body if isinstance(n, ast.Try))
ns, image, res, events, saved = ports([Receipt("partial.process.json")], True)
primary = ValueError("original primary")
ns.update(
    primary=primary,
    result={"qualified": False},
    failure=None,
    resources=res,
    admission={"caps_B": {"positive": 39845888}},
    image=image,
    created_image=True,
    created_tmp=True,
    started=time.monotonic(),
)
derived = ast.Try(
    body=[ast.Raise(exc=ast.Name(id="primary", ctx=ast.Load()))],
    handlers=outer.handlers,
    orelse=[],
    finalbody=outer.finalbody,
)
exec(
    compile(
        ast.fix_missing_locations(ast.Module(body=[derived], type_ignores=[])),
        str(source),
        "exec",
    ),
    ns,
)
assert saved["result.json"]["primary_error"] == repr(primary)
assert all(
    e in events
    for e in [
        "rmdir",
        "financial_check",
        "save:charged-path-maxima.json",
        "save:result.json",
    ]
)
assert not saved["result.json"]["qualified"]
assert saved["result.json"]["finalization_errors"][0]["stage"] == "TMP_image_unlink"
facts.append(
    {
        "case": "original main handler ValueError + owned unlink OSError",
        "PASS": True,
        "later_stages_attempted": events,
    }
)


class Base:
    def __init__(self, *args):
        pass

    def check(self, owned=()):
        pass


stat_error = PermissionError("financial stat refused")
io_error = OSError("charge write refused")


def refuse_stat():
    raise stat_error


def refuse_write(*args):
    raise io_error


ns.update(
    P=SimpleNamespace(CycleResources=Base, process_info=lambda p: None),
    os=SimpleNamespace(getpid=lambda: 1),
    MIB=1024**2,
    FinancialRetention=lambda a: SimpleNamespace(
        check=refuse_stat, record=lambda a: {}
    ),
    save=refuse_write,
)
node = next(
    n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "Resources"
)
exec(compile(ast.Module(body=[node], type_ignores=[]), str(source), "exec"), ns)
r = ns["Resources"]({})
try:
    r.check()
except PermissionError as caught:
    assert caught is stat_error
else:
    raise AssertionError("originating stat must propagate")
assert r.financial_errors[0]["type"] == "PermissionError"
assert r.charge_io_errors[0]["type"] == "OSError"
facts.append(
    {
        "case": "financial PermissionError + charge OSError",
        "PASS": True,
        "primary_object_preserved": True,
        "financial_errors": r.financial_errors,
        "charge_io_errors": r.charge_io_errors,
    }
)

names = [
    "NN0-terminal.process.json",
    "NN0-postterminal.process.json",
    "NN0-wrong-terminal-ply.process.json",
] + [
    op + "-" + name + ".process.json"
    for name in ["initial", "p2"]
    for op in ["arena", "audit", "recover"]
]
ns, image, res, events, saved = ports([Receipt(name) for name in names])
result = {"qualified": True}
error = ns["finalize"](
    result,
    repr(primary),
    res,
    {"caps_B": {"positive": 39845888}},
    image,
    True,
    True,
    time.monotonic(),
)
assert error == repr(primary)
assert saved["result.json"]["qualified"] is True
facts.append(
    {
        "case": "primary after qualified flag, all nine receipts valid",
        "counterexample_reproduced": True,
        "expected_qualified": False,
        "actual_saved_qualified": saved["result.json"]["qualified"],
        "primary_error": saved["result.json"]["primary_error"],
    }
)

ns, image, res, events, saved = ports([])
result = {"qualified": False}
error = ns["finalize"](
    result,
    "CycleStopped('child cleanup/receipt unavailable')",
    res,
    {"caps_B": {"positive": 39845888}},
    image,
    True,
    True,
    time.monotonic(),
)
assert saved["result.json"]["all_direct_children_reaped"] is True
assert saved["result.json"]["cleanup_complete"] is True
assert saved["result.json"]["remaining"] == []
facts.append(
    {
        "case": "failed phase, receipt paths empty; no child-attempt ledger",
        "counterexample_reproduced": True,
        "expected_census": "UNKNOWN unless zero child attempts independently established",
        "actual_census": {
            "all_direct_children_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
        },
        "live_child_failure_claim": False,
    }
)
result = {
    "source_SHA256": hashlib.sha256(raw).hexdigest(),
    "facts": facts,
    "wall_s": time.monotonic() - start,
    "VmHWM_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "STOP": datetime.now(timezone.utc).isoformat(),
    "CPU": [3],
    "framework_runtime_payload_calls": 0,
    "owned_children": 0,
    "limits": "Python AST/fake ports only; no live process/disk/Cargo/backend qualification.",
}
with (Path(__file__).parent / "probe-result.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result))
