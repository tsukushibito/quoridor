# quoridor-4lc.331.1 private-only確認 v12

結論：新しいprivate purpose／historical chargeの分離は固定source上で成立する。新controllerの失敗finalizationにR1 [P1・通常修正]が1件残るため、related clearは出さない。研究方法・model・rules変更は不要。prepared admissionはfalseのまま、実entry／CLI／backend資格は認定しない。

証拠root：`/workspaces/quoridor/.worktree/learning-million/.artifacts/search-ownership-review-v1/sigma-deadline-v1/private-functional-confirm-v12`。targetはarena WT `private-functional-v1/source-control-stop-v1.json` SHA `4171aac563cadd8c118041d7b681110e581062f78c7b28c6dec402f90bb0029a`。固定15pathのSHA／mode／lengthを前後照合し一致。map、必要CLI source SHA、3件の実financial metadata SHAは`control.json`。

## R1 [P1・通常修正] cleanup／保存失敗で後続finalizationと保持記録を飛ばす

`qualify.py` SHA `d974262b384bfdd6438e46c23ecd9533bc8b5576ac2b7f5cf2895dbbe26c0306`、366–390行。元の資格失敗を`failure=repr(error)`へ保存した後、finallyの`image.unlink()`、rmdir、process receipt読取、result保存を保護なしで順に実行する。

同じ実handler/finally ASTを使い、元のValueError＋自分のTMP画像unlinkのOSErrorをfake portsで発生させた。実際に試行されたstageはunlinkだけ。rmdir、process census、`result.json`の保存は試行されず、元失敗と保持額35225600も最終結果へ書く機会が無くなる。cleanup例外が単独で伝播する。ファイル削除成功を保証する要求ではなく、個別失敗後にも必要な後続stageを試行し、primary／cleanup／IO／remaining UNKNOWNを記録できる構造が必要。

同source129–132行の`Resources.check`でも、financial stat拒否に続く`charged-path-maxima.json`保存拒否は、保存OSErrorだけを送出する。元PermissionErrorは暗黙の`__context__`に残るが、mainが保存する`repr(error)`には個別financial原因が入らない。これも実AST＋fake saveで確認した。新しいfinancial snapshotの永続化は各checkのfinallyで試みる設計だが、この失敗帰属とmainのfinal保存経路を修正する必要がある。

元primaryと各cleanup／checkpointではなくcharge／receipt IO失敗を別stageとして保持し、final charge/resultの保存を独立に試行する通常修正をproducerへ返す。保存が成功しなければUNKNOWNと原因を残し、成功を保証したと記録しない。pre-entry refusalで旧outputを変更する必要はない。修正は同reviewerへ新しい固定sourceSTOPで戻す。

## 確認した新境界

- `private_profile.py` はbound membershipをIO前、raw SHAをparse前に確認し同じrawをparseする。実baseline86b／maxima3c6／OWN release receipt884aを小JSONとしてhash照合した。positive floorと実heldは35225600、historical runner6aaa maxは9236480。source/profile/features／OWN target path／prior SHA／allocationが一致する。payloadは読んでいない。
- historical missingの例外はprivate profile名＋この1pathに限定。compile profileや他pathのmissing/stat errorへ拡張しない。maximaとheldは減らさず、UNKNOWNをglobal storage資格へ昇格しない。旧NamedReplacement／first Cargo／terminal missingのsourceや試験は再実行していない。
- 実行入力は固定5path/SHA集合。各入力のcanonical path／非symlink／通常file／mode／size／allocation upper／SHAを別に必須とし、historical rlibを実行入力へ混ぜない。将来のlinked immutable bodyに現在rustc1.98 executableを要求する必要はないが、現kernel／loader／ORT／private body資格は今回のsourceレビューから認定しない。
- preparedfalseとpending obligationsは`validate`の最初で拒否。新controllerは maintained P.execute／directwait／cancelを呼び、単一decodeの明示TMPだけを新規所有・削除する。既存private／TMP／旧qualificationのmissingを新しいTMP不存在例外へ広げない。現16 source/control pathのallocation＋directoryは131072、source式8376320でprepared wholeと一致しcap8519680未満。新actual admission/jobとtransitive bindingは未freezeの条件として残る。
- CLI `main -> recover_arena -> arena_manifest::recover -> slots -> arena::replay` を必要範囲だけ読んだ。recoverはmodel/searchを起動せず、Config/Slot digest、book/plan、fullReplayの一致を要求する。Slot cohortはenumのserde名ではなくDebug stringなのでfixtureの`TacticalDiagnostic`と整合する。Config/Engine/Inference/Book/Opening/Slot field orderも対応する。
- 8ply literalは第三反復draw0／winnerNone／totalply8／history合計9、追加13はGAME_OVER、wrong plyはfullReplay不一致を期待する定義。これは期待値の静的整合であり合法性の実Rust証明ではない。wrong fixtureを単なるexit1では通さず、specific recovery history/Q mismatchとwait/cleanupを要求する。3 NN0 recoverを4 functional windowsより先に置き、成功側missing slotsと全期待Slotの一致も確認する。6つのterminal関連事実をfullReplay比較で観測する経路はあるが、未実行arena1／四Clippy／旧fixture全体をPASSへ昇格しない。
- 4 windowsは2 Sigma＋2 NNUE、[]/[13]から1追加ply、結果はcap UNKNOWN。collectorはaccepted/error/census、実compiled sources／TT／node／Sigma warmup・row上限を確認する。exit0だけを資格にせず、16 science／strength／defaultへ一般化しない。

## 実行範囲・費用・停止

新しい独立probeは2つの実AST失敗branchだけ。provided新4mock PASS0.057654597sは別証拠として再利用し、旧成功suiteは再実行なし。probe whole `0.051406086s`、内部 `0.003224402s`、VmHWM17120KiB、CPU3、RLIMIT_AS512MiB。Ruffで自分のprobeのみformat（0.132622480s）。model/runtime/Popen/Cargo/ELF/library/assets/forward/network/job0。fake portsでのbranch証拠はdisk fault／CLI／backend／実cleanup成功ではない。family peakと一部light read個別wallはUNKNOWN；計測したBeads/probe/hash/admin費はcontrolに保持し、旧費・failure・upperをrefundしない。

reader/substantial analysis STOP `2026-10-08T08:15:19.990807+00:00`。own reader／fixture child／job remaining `[]`、同期directwait、source/main/Git/index writer0。新outputはこのnamespaceのみ、cap65536B内。レビューleafだけclose／backupし、331＋324へ一度通知する。parent331未完了、323pause／seals／defaults不変。related repair clearと実readerSTOPに加えて、future source/private/maxima/wholecap/physics/soleCargo等の入口条件は引き続き必要。
