"""One isolated duplicate-engine predicate case; actual AST, bound metadata."""

import ast
import copy
import hashlib
import json
from pathlib import Path
import resource
import time

resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
started = time.monotonic()
q = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/sigma-timed-v1/live-qualified-current-recovery-v2"
)
a = json.loads((q / "admission.prepared.json").read_text())
values = {}
for filename in ("result.json", "manifest.json"):
    p = str(Path(a["completed_initial_run"]) / filename)
    b = Path(p).read_bytes()
    assert hashlib.sha256(b).hexdigest() == a["bindings"][p]
    values[p] = json.loads(b)
# Both engine indices1 skip unrelated NNUE TT checks and reach the new census.
values[str(Path(a["completed_initial_run"]) / "result.json")]["outcomes"][0][
    "observations"
][0]["engine_index"] = 1
node = next(
    n
    for n in ast.parse((q / "reviewed_helpers.py").read_text()).body
    if isinstance(n, ast.FunctionDef) and n.name == "collect_run"
)
ports = {
    "OUT": q,
    "Path": Path,
    "json": json,
    "bound_json": lambda a, p: copy.deepcopy(values[p]),
}
exec(
    compile(
        ast.Module(body=[node], type_ignores=[]), "actual-collector-census", "exec"
    ),
    ports,
)
try:
    ports["collect_run"]("initial", a)
except ValueError as error:
    assert str(error) == "functional pair lacks exactly one caller per engine"
else:
    raise AssertionError("duplicate-engine census accepted")
print(
    json.dumps(
        {
            "PASS": 1,
            "reason": "functional pair lacks exactly one caller per engine",
            "model_runtime_Popen_calls": 0,
            "wall": time.monotonic() - started,
            "VmHWM_KiB": next(
                int(l.split()[1])
                for l in Path("/proc/self/status").read_text().splitlines()
                if l.startswith("VmHWM:")
            ),
        }
    )
)
