# quoridor-4lc.331.1 R1-only confirmation v13

Result: original two v12 counterexamples resolved; two related finalization facts remain blocking ordinary repairs. No method/model/rules change requested. No private entry clear.

Evidence root: /workspaces/quoridor/.worktree/learning-million/.artifacts/search-ownership-review-v1/sigma-deadline-v1/private-functional-R1-confirm-v13
Target packet SHA256: ed6a7dd1eac29fdd8c2ae5b5a23b228d4d256ec907ee483ef932a876107f9a7b
Controller SHA256: 1b65f38a5b0bed74d4af4c3e30f9fe2ca22e08c9274269b336609a0789dcec5a
All16 bound hashes/modes/lengths match before/after. Full packet path, binding-map digest, changed paths/SHA and commands are in control.json.

Resolved: actual main handler/finalize AST preserves original ValueError facts after owned unlink OSError, attempts rmdir/finance/charge/result, and reports cleanup false. Actual Resources.check AST reraises the original financial PermissionError object and separately records charge OSError. No runtime imports or real IO were used.

R1a [P1 ordinary repair]: finalize lines444-449 clears qualified only for accumulated stage/resource errors, not for supplied primary failure. With result.qualified=true, original primary and nine valid receipts, the actual function saves qualified=true plus primary_error, then returns the error. Expected saved qualified=false. Main sets qualified inside contexts whose exit may subsequently fail, so its handler can supply this state. Controller failure still propagates; this is a contradictory persisted qualification claim, not evidence of an actual successful failed job. Clear qualified whenever a primary remains.

R1b [P1 ordinary repair]: exact receipt census is enforced only when result.qualified is true (365-383). On a failed phase with an empty receipt list, receipt_unknown remains false and all([]) records direct children reaped=true, cleanup_complete=true, remaining=[]. The actual AST probe reproduces these facts. A failed P.execute/receipt-write path can lack a receipt; this controller has no independent child-attempt census establishing zero children. Expected UNKNOWN unless zero attempts or every attempted child's wait/cleanup is established. Track attempts before execution and validate the partial receipt census; do not infer cleanup from an empty collection. This is a source/mock gap, not a live child failure claim.

Other R1 changes: each receipt read, TMP census, charge and result writes are attempted independently; failed publication has terminal stdout and raised error carrying primary/stage/held-charge/UNKNOWN facts. Correctly refuses successful qualification with missing nine receipts. These mechanisms do not guarantee disk/stdout success. Source-formatted tests were inspected; supplied4 PASS costs remain separate, not replayed.

Old d974 gzip restores exact SHA. validate/execute/replay_checks/collect_run ASTs are unchanged; v12 private scope/5inputs/CLI/math proofs reused. Preparedfalse stays false. Historical repair65KiB breach/raw/fees remain held; prospective98304 source allowance is not retrocompliance. New human4GiB support is future authority, not a change to this review512MiB or these frozen historical caps. Direct Rust software route is not gated by adopting this optional private profile.

Independent probe: two resolved checks + two remaining counterexamples; whole0.028734060s, internal0.005134685s, VmHWM17672KiB, CPU3/AS512MiB. Ruff formatting0.184679144s. Family peak and some light-read exact wall UNKNOWN. Cargo/runtime/model/library/payload/Popen/native/job/network0. Source-derived Python AST/fake ports are not live fault/CLI/backend qualification.

Reader/substantial analysis STOP 2026-10-08T08:54:22.442862+00:00. Owned fixture children directwait; remaining[]. Own output<=32768 inclusive, old evidence held. Only331.1 closes/backup; one notification each331+324. Parent331 incomplete; pause/seals/defaults unchanged. Future entry still requires actual source/private/proof/cap/physics/soleCargo predicates.

