"""One read-only Main typecheck using maintained process ownership."""

from builtins import BaseExceptionGroup
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import time

ROOT = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
LOCK = MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock"
GIB = 1024**3


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while block := stream.read(1024 * 1024):
            h.update(block)
    return h.hexdigest()


def verify(path, expected):
    p = Path(path)
    info = p.lstat()
    if not stat.S_ISREG(info.st_mode) or p.resolve(strict=True) != p:
        raise ValueError("noncanonical regular source/tool: " + str(p))
    if (info.st_size, stat.S_IMODE(info.st_mode), digest(p)) != (
        expected["bytes"],
        expected["mode"],
        expected["sha256"],
    ):
        raise ValueError("bound source/tool changed: " + str(p))


def quiet():
    names = {
        "cargo",
        "rustc",
        "clippy-driver",
        "cargo-clippy",
        "perf",
        "quoridor-runner",
        "chrome",
        "chromium",
        "chrome-headless-shell",
    }
    markers = (
        "software_worker",
        "software_guard",
        "numeric_worker",
        "numeric-worker",
        "matches-worker",
        "finite-driver",
        "public-synthetic",
        "statistics.py",
        "train.py",
        "trainer.py",
        "qualify.py",
        "execute-retention.py",
    )
    found = []
    for p in Path("/proc").iterdir():
        if not p.name.isdecimal() or int(p.name) in (os.getpid(), os.getppid()):
            continue
        try:
            argv = [os.fsdecode(x) for x in (p / "cmdline").read_bytes().split(b"\0") if x]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not argv:
            continue
        executable = Path(argv[0]).name
        if (
            executable in names
            or executable.startswith(("quoridor_runner-", "measure_native", "profile_native"))
            or (
                executable.startswith("python")
                and any(Path(x).name.startswith(markers) for x in argv[1:])
            )
        ):
            found.append({"pid": int(p.name), "argv": argv})
    if found:
        raise RuntimeError("actual named competitor: " + json.dumps(found))
    return []


def physical():
    available = next(
        int(x.split()[1]) * 1024
        for x in Path("/proc/meminfo").read_text().splitlines()
        if x.startswith("MemAvailable:")
    )
    if available < 10 * GIB or not {2, 4}.issubset(os.sched_getaffinity(0)):
        raise ValueError("family6GiB plus host4GiB or CPU affinity unavailable")
    cores = [
        tuple(
            (Path(f"/sys/devices/system/cpu/cpu{cpu}/topology") / name).read_text().strip()
            for name in ("physical_package_id", "core_id")
        )
        for cpu in (2, 4)
    ]
    if cores[0] == cores[1]:
        raise ValueError("CPU2/4 share physical package/core identity")
    fs = os.statvfs(ROOT)
    if fs.f_bavail * fs.f_frsize < GIB:
        raise ValueError("filesystem lacks complete bounded positive-growth forecast")
    return {
        "MemAvailable_B": available,
        "CPU2_CPU4_package_core": cores,
        "FS_available_B": fs.f_bavail * fs.f_frsize,
        "scheduler_isolation": "UNKNOWN",
    }


def inputs(binding):
    for path, expected in binding["files"].items():
        verify(path, expected)
    for path in binding["absent"]:
        if os.path.lexists(path):
            raise ValueError("bound config absence changed: " + path)
    for root, expected in binding["namespaces"].items():
        actual = sorted(
            str(p.relative_to(root)) for p in Path(root).rglob("*") if p.is_file() or p.is_symlink()
        )
        if actual != expected:
            raise ValueError("selected source namespace changed: " + root)
    for root, records in binding.get("trees", {}).items():
        for name, (sha256, size, mode) in records.items():
            verify(Path(root) / name, {"sha256": sha256, "bytes": size, "mode": mode})


def declared_compiler_inputs(binding, target):
    known = set(binding["files"])
    for root, records in binding.get("trees", {}).items():
        known.update(str(Path(root) / name) for name in records)
    inspected = 0
    for path in target.rglob("*.d"):
        if path.stat().st_size > 1024 * 1024:
            raise ValueError("compiler dependency record exceeds finite1MiB")
        for name in re.findall(r"(?:^|\s)(/[^\s:]+)", path.read_text(), re.M):
            source = Path(name).resolve()
            if source.is_relative_to(target):
                continue  # Generated compiler outputs are guarded in the fresh owned target.
            if str(source) not in known:
                raise ValueError("compiler declared input absent from prebound map: " + str(source))
        inspected += 1
    if inspected == 0:
        raise ValueError("actual compiler dependency records unavailable")
    return inspected


def main():
    started = time.monotonic()
    raw = Path(sys.argv[1]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != sys.argv[2]:
        raise ValueError("immutable admission digest")
    a = json.loads(raw)
    if a["actual_entry"] is not True or a["prepared_only"] is not False:
        raise ValueError("prepared controls refuse before resource/input/child ports")
    expected = [
        a["environment"]["CARGO"],
        "check",
        "--offline",
        "--locked",
        "--manifest-path",
        "/workspaces/quoridor/Cargo.toml",
        "-j1",
        "-p",
        "quoridor-runner",
        "--bin",
        "quoridor-runner",
    ]
    if a["command"] != expected or a["worker_seconds"] != 180 or a["whole347_B"] != 4 * GIB:
        raise ValueError("wrong single-command scope or supported bounds")
    quiet()
    physical()
    lock = LOCK.open("r+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet()
        physical()
        verify(a["binding_map"]["path"], a["binding_map"])
        binding = json.loads(Path(a["binding_map"]["path"]).read_bytes())
        inputs(binding)
        for key in ("target", "TMP"):
            p = Path(a[key])
            if not p.is_relative_to(ROOT) or os.path.lexists(p):
                raise ValueError("fresh exclusive owned namespace required: " + str(p))
        sys.path.insert(0, str(MAIN / "python"))
        from quoridor_training import cycle_process as P
        from quoridor_training.snapshot import write_json

        if P.available_memory() < 10 * GIB:
            raise ValueError("actual cgroup/host capacity lacks family6GiB and host4GiB")
    except BaseException as primary:
        try:
            lock.close()
        except BaseException as error:
            raise BaseExceptionGroup("prestart refusal and lease close", [primary, error]) from None
        raise

    primary, errors, returned = None, [], None
    result = {
        "qualified": False,
        "purpose": "current Main runnerbin composite typecheck only",
        "command": a["command"],
        "models_games_tests": 0,
        "continuous_peak": "UNKNOWN",
    }
    resources = None
    temporary, target = Path(a["TMP"]), Path(a["target"])

    class Resources(P.CycleResources):
        def __init__(self):
            super().__init__(
                {
                    "host_ram_reserve": 4 * GIB,
                    "max_memory_bytes": 6 * GIB,
                    "max_output_bytes": 1024**2,
                },
                ROOT / "output",
                started + 180,
            )
            self.maxima, self.missing, self.family_peak = {}, set(), 0

        def check(self, owned=()):
            super().check(owned)
            family = (
                sum(
                    i["rss"]
                    for i in [
                        P.process_info(os.getpid()),
                        *(P.process_info(x["pid"]) for x in owned),
                    ]
                    if i
                )
                + 64 * 1024**2
            )
            self.family_peak = max(self.family_peak, family)
            if family > self.memory_limit:
                raise P.CycleStopped("family RSS including controller reserve")
            for name, root, cap in (
                ("target", target, 512 * 1024**2),
                ("TMP", temporary, 64 * 1024**2),
                ("controls", ROOT, 1024**2),
            ):
                pending = [root]
                while pending:
                    p = pending.pop()
                    if name == "controls" and p in (temporary, target):
                        continue
                    try:
                        info = p.lstat()
                    except FileNotFoundError:
                        self.missing.add(str(p))
                        continue
                    self.maxima[name, str(p)] = max(
                        self.maxima.get((name, str(p)), 0), info.st_blocks * 512
                    )
                    if stat.S_ISDIR(info.st_mode):
                        try:
                            pending.extend(p.iterdir())
                        except FileNotFoundError:
                            self.missing.add(str(p))
                    elif stat.S_ISLNK(info.st_mode):
                        if p != temporary / "cargo-home/registry" or p.resolve() != Path(
                            a["registry_root"]
                        ):
                            raise P.CycleStopped("unexpected owned output symlink")
                    elif not stat.S_ISREG(info.st_mode):
                        raise P.CycleStopped("unexpected owned output kind")
                total = sum(v for (kind, _), v in self.maxima.items() if kind == name)
                if total > cap:
                    raise P.CycleStopped("inclusive positive allocation " + name)
            total = a["held_arena_target_floor_B"] + sum(
                v for (kind, _), v in self.maxima.items() if kind in ("target", "TMP")
            )
            if total > 2 * GIB:
                raise P.CycleStopped("build component including held old floor")

    def attempt(stage, action):
        try:
            return action()
        except BaseException as error:
            errors.append({"stage": stage, "type": type(error).__name__, "message": str(error)})
            return None

    try:
        result["physical"] = physical()
        quiet()
        os.sched_setaffinity(0, {4})
        for key in (
            "RUSTC_WRAPPER",
            "RUSTC_WORKSPACE_WRAPPER",
            "RUSTFLAGS",
            "CARGO_ENCODED_RUSTFLAGS",
            "CFLAGS",
            "CXXFLAGS",
            "CARGO_BUILD_TARGET",
            "CARGO_TARGET_DIR",
        ):
            os.environ.pop(key, None)
        os.environ.update(a["environment"])
        temporary.mkdir()
        cargo_home = temporary / "cargo-home"
        cargo_home.mkdir()
        (cargo_home / "registry").symlink_to(a["registry_root"], target_is_directory=True)
        (cargo_home / "config.toml").write_text(
            '[net]\noffline = true\n[cache]\nauto-clean-frequency = "never"\n'
        )
        target.mkdir()
        (ROOT / "output").mkdir()
        os.chdir(MAIN)
        resources = Resources()
        resources.check()
        result["worker_identity"] = P.identity(P.process_info(os.getpid()))
        result["actual_worker_START"] = now()
        write_json(ROOT / "output/START.json", result)
        P.LOG_MAX_BYTES = 65536
        with P.cancellation_signals():
            returned = P.execute(
                a["command"], ROOT / "output/check.log", None, cpu_core=2, resources=resources
            )
        result["returned_finalization"] = returned
        if returned["exit_code"] != 0 or returned["remaining"] or not returned["cleanup_complete"]:
            raise RuntimeError("single check did not qualify")
        result["compiler_dependency_records_verified"] = declared_compiler_inputs(binding, target)
    except BaseException as error:
        primary = error
    finally:
        attempt("input_after", lambda: inputs(binding))
        record = attempt(
            "persisted_receipt",
            lambda: json.loads((ROOT / "output/check.process.json").read_bytes()),
        )
        clean = bool(
            record
            and record.get("direct_child_reaped")
            and record.get("cleanup_complete")
            and record.get("remaining") == []
        )
        result.update(
            primary_error=None
            if primary is None
            else {"type": type(primary).__name__, "message": str(primary)},
            persisted_process_receipt=record,
            process_cleanup_complete=clean,
            persisted_mask="UNKNOWN"
            if record is None
            else record.get("signal_mask_restoration", "UNKNOWN"),
            returned_mask="UNKNOWN"
            if returned is None
            else returned.get("signal_mask_restoration", "UNKNOWN"),
        )
        if clean:
            attempt("owned_TMP_cleanup", lambda: shutil.rmtree(temporary))
        if resources is not None:
            attempt("final_resources", resources.check)
            result.update(
                sampled_family_peak_B=resources.family_peak,
                held_allocations=[
                    {"component": kind, "path": path, "maximum_sampled_allocated_B": value}
                    for (kind, path), value in sorted(resources.maxima.items())
                ],
                sampled_vanished_paths=sorted(resources.missing),
                old_target_floor_B=a["held_arena_target_floor_B"],
            )
        result.update(
            source_reader_STOP=now(),
            remaining=[]
            if clean
            else (record or {}).get("remaining", ["UNKNOWN command ownership"]),
            TMP_remaining=[] if not temporary.exists() else [str(temporary)],
            stage_errors=errors,
        )
        attempt("canonical_lease_close", lock.close)
        result["qualified"] = (
            primary is None and not errors and clean and not result["TMP_remaining"]
        )
        result["whole_worker_seconds"] = time.monotonic() - started
        attempt("result_persist", lambda: write_json(ROOT / "output/result.json", result))
        if errors:
            print(
                json.dumps(
                    {
                        "terminal_failure_facts": {
                            "primary_error": result["primary_error"],
                            "stage_errors": errors,
                            "remaining": result["remaining"],
                            "TMP_remaining": result["TMP_remaining"],
                            "source_reader_STOP": result["source_reader_STOP"],
                        }
                    }
                ),
                flush=True,
            )
        if primary is not None:
            if errors:
                primary.add_note("independent finalization errors: " + json.dumps(errors))
            raise primary
        if errors or not result["qualified"]:
            raise RuntimeError("stopped composite check incomplete: " + json.dumps(result))


if __name__ == "__main__":
    main()
