"""Freeze selected compiler inputs; no Cargo, library or model execution."""

import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import tomllib

MAIN = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent


def main():
    spec = importlib.util.spec_from_file_location("guard", OUT / "worker.py")
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    guard.quiet()
    physical = guard.physical()
    lock = guard.LOCK.open("r+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        guard.quiet()
        guard.physical()
        files, trees, namespaces, absent = {}, {}, {}, []
        io = 0

        def record(path):
            nonlocal io
            path = Path(path).resolve(strict=True)
            info = path.stat()
            if not stat.S_ISREG(info.st_mode):
                raise ValueError("input must be regular: " + str(path))
            io += info.st_size
            if io > 1024**3:
                raise ValueError("selected input/tool hashing exceeds finite1GiB")
            return {
                "sha256": guard.digest(path),
                "bytes": info.st_size,
                "mode": stat.S_IMODE(info.st_mode),
            }

        def add(path):
            path = Path(path).resolve(strict=True)
            if str(path) not in files:
                files[str(path)] = record(path)

        for name in (
            "Cargo.toml",
            "Cargo.lock",
            "python/quoridor_training/__init__.py",
            "python/quoridor_training/cycle_process.py",
            "python/quoridor_training/snapshot.py",
            "scripts/dev/research-job.py",
            "scripts/dev/research-job.sh",
            "scripts/dev/research-runtime.py",
            "scripts/dev/research-session.py",
            "scripts/dev/beads.sh",
            "research-data/ai-sigma/sigma-receipt-reevaluation-v1/resources.json",
            "research-data/ai-sigma/execution-resources-20261008.json",
        ):
            add(MAIN / name)
        add(OUT / "worker.py")
        add(OUT / "prepare.py")
        manifests = []
        for name in ("runner", "core", "nnue", "ai", "data", "inference"):
            package = MAIN / ("crates/quoridor-" + name)
            add(package / "Cargo.toml")
            manifests.append(tomllib.loads((package / "Cargo.toml").read_text()))
            source = package / "src"
            namespaces[str(source)] = sorted(
                str(p.relative_to(source))
                for p in source.rglob("*")
                if p.is_file() or p.is_symlink()
            )
            for path in source.rglob("*.rs"):
                add(path)
            if (package / "build.rs").exists():
                add(package / "build.rs")
        add(MAIN / "crates/quoridor-wasm/Cargo.toml")
        native = MAIN / "crates/quoridor-inference/native"
        namespaces[str(native)] = sorted(
            str(p.relative_to(native)) for p in native.rglob("*") if p.is_file() or p.is_symlink()
        )
        for path in native.rglob("*"):
            if path.is_file() and path.suffix in (".cpp", ".c", ".h", ".hpp"):
                add(path)
        for name in (
            "crates/quoridor-core/tests/fixtures/research_threefold.rs",
            "configs/arena/smoke.json",
            "crates/quoridor-runner/tests/fixtures/sigma-clock-config.json",
        ):
            add(MAIN / name)
        for base in (MAIN, MAIN.parent, Path("/"), Path("/usr/local/cargo")):
            names = (
                ("config", "config.toml")
                if base == Path("/usr/local/cargo")
                else (".cargo/config", ".cargo/config.toml")
            )
            for name in names:
                path = base / name
                if os.path.lexists(path):
                    add(path)
                else:
                    absent.append(str(path))
        for name in ("rust-toolchain", "rust-toolchain.toml"):
            path = MAIN / name
            if path.exists():
                add(path)
            else:
                absent.append(str(path))
        sigma = json.loads(
            (
                MAIN
                / "research-data/ai-sigma/sigma-receipt-reevaluation-v1/main-source-integration-v1.json"
            ).read_text()
        )
        deeper = json.loads(
            (
                MAIN
                / "research-data/ai-sigma/deeper-teacher-generation-v1/main-source-integration-v1.json"
            ).read_text()
        )
        for row in sigma["paths"]:
            actual = files[str(MAIN / row["path"])]
            if (actual["sha256"], actual["bytes"], actual["mode"]) != (
                row["after_sha256"],
                row["after_bytes"],
                row["after_mode"],
            ):
                raise ValueError("integrated caller source mismatch")
        for path, expected in deeper["main_postimages"].items():
            if files[str(MAIN / path)] != expected:
                raise ValueError("integrated depth6 source mismatch")
        packages = [
            p
            for p in tomllib.loads((MAIN / "Cargo.lock").read_text())["package"]
            if p.get("source")
        ]
        byname = {}
        for package in packages:
            byname.setdefault(package["name"], []).append(package)

        def lookup(dependency):
            fields = dependency.split()
            candidates = byname.get(fields[0], [])
            if len(fields) > 1 and fields[1][0].isdigit():
                candidates = [p for p in candidates if p["version"] == fields[1]]
            if len(candidates) != 1:
                raise ValueError("ambiguous locked dependency: " + dependency)
            return candidates[0]

        queue = []
        for manifest in manifests:
            for section in ("dependencies", "build-dependencies"):
                for name, value in manifest.get(section, {}).items():
                    if name.startswith("quoridor-"):
                        continue
                    queue.append(
                        lookup(value.get("package", name) if isinstance(value, dict) else name)
                    )
        selected = {}
        while queue:
            package = queue.pop()
            key = (package["name"], package["version"])
            if key in selected:
                continue
            selected[key] = package
            queue.extend(lookup(dep) for dep in package.get("dependencies", []))
        registry = Path("/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f")
        c_sources = []
        absent_registry_candidates = []
        for name, version in sorted(selected):
            base = registry / (name + "-" + version)
            if not base.is_dir():
                absent.append(str(base))
                absent_registry_candidates.append(name + "-" + version)
                continue
            names = sorted(
                str(p.relative_to(base)) for p in base.rglob("*") if p.is_file() or p.is_symlink()
            )
            namespaces[str(base)] = names
            records = {}
            for name in names:
                path = base / name
                if path.suffix not in (
                    ".rs",
                    ".toml",
                    ".c",
                    ".h",
                    ".hpp",
                    ".cpp",
                    ".s",
                    ".S",
                    ".inc",
                    ".in",
                    ".def",
                ) and name not in (".cargo-ok", ".cargo_vcs_info.json", ".cargo-checksum.json"):
                    continue
                value = record(path)
                records[name] = [value["sha256"], value["bytes"], value["mode"]]
                if path.suffix in (".c", ".cpp", ".h", ".hpp"):
                    c_sources.append(path)
            trees[str(base)] = records
            # Literal embedded text/data are compiler inputs too; bind them,
            # without executing package tests or reading unrelated cache payloads.
            for name in tuple(records):
                path = base / name
                if path.suffix != ".rs":
                    continue
                for embedded in re.findall(
                    r'include_(?:str|bytes)!\s*\(\s*"([^"]+)"', path.read_text(errors="replace")
                ):
                    included = (path.parent / embedded).resolve()
                    if included.is_file():
                        add(included)
        system = [
            Path("/usr/include/c++/12"),
            Path("/usr/include/x86_64-linux-gnu/c++/12"),
            Path("/usr/lib/gcc/x86_64-linux-gnu/12/include"),
        ]
        headers = []
        for base in system:
            records = {}
            for path in base.rglob("*"):
                if path.is_file():
                    value = record(path)
                    records[str(path.relative_to(base))] = [
                        value["sha256"],
                        value["bytes"],
                        value["mode"],
                    ]
                    headers.append(path)
            trees[str(base)] = records
        search = [
            native,
            *system,
            Path("/usr/include/c++/12/backward"),
            Path("/usr/local/include"),
            Path("/usr/include/x86_64-linux-gnu"),
            Path("/usr/include"),
        ]
        pending, seen, conditional_missing = (
            [*headers, *c_sources, *native.glob("*.h"), native / "ort.cpp"],
            set(),
            set(),
        )
        while pending:
            path = pending.pop().resolve()
            if path in seen:
                continue
            seen.add(path)
            text = path.read_text(errors="replace")
            for delimiter, name in re.findall(
                r"^\s*#\s*include(?:_next)?\s*([<\"])([^>\"]+)[>\"]", text, re.M
            ):
                candidates = ([path.parent / name] if delimiter == '"' else []) + [
                    base / name for base in search
                ]
                positive = {p.resolve() for p in candidates if p.is_file()}
                if not positive:
                    conditional_missing.add(name)
                for header in positive:
                    if str(header) not in files and not any(
                        header.is_relative_to(Path(base)) for base in trees
                    ):
                        add(header)
                    if header not in seen:
                        pending.append(header)
        compiler = Path("/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu")
        previous = json.loads(
            (
                MAIN
                / ".worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/materialization-v7/admission.remaining.actual-v6.json"
            ).read_text()
        )
        tools = [compiler / "bin" / name for name in ("cargo", "rustc", "rustdoc")]
        tools += [Path("/usr/bin/x86_64-linux-gnu-" + name) for name in ("gcc-12", "g++-12", "ar")]
        tools.append(Path("/usr/bin/python3").resolve())
        tools.extend(
            Path("/usr/lib/gcc/x86_64-linux-gnu/12") / name
            for name in ("cc1", "cc1plus", "collect2")
        )
        tools.extend(Path("/usr/bin/x86_64-linux-gnu-" + name) for name in ("as", "ld.bfd"))
        for tool in tools:
            add(tool)
            if str(tool) in previous["bindings"]:
                actual, old = files[str(tool)], previous["bindings"][str(tool)]
                if (actual["sha256"], actual["bytes"], actual["mode"]) != (
                    old["SHA256"],
                    old["bytes"],
                    old["mode"],
                ):
                    raise ValueError("supplied current compiler/tool identity changed")
        for tool in compiler.glob("lib/*rustc_driver*.so"):
            add(tool)
        for tool in (compiler / "lib/rustlib/x86_64-unknown-linux-gnu/lib").iterdir():
            if tool.is_file() and tool.suffix in (".rlib", ".rmeta", ".so"):
                add(tool)
        environment = dict(
            RUSTC=str(compiler / "bin/rustc"),
            RUSTDOC=str(compiler / "bin/rustdoc"),
            CARGO=str(compiler / "bin/cargo"),
            RUSTUP_TOOLCHAIN="stable-x86_64-unknown-linux-gnu",
            RUSTUP_AUTO_INSTALL="0",
            CARGO_NET_OFFLINE="true",
            CARGO_BUILD_JOBS="1",
            CARGO_PROFILE_DEV_DEBUG="0",
            CARGO_PROFILE_DEV_OPT_LEVEL="0",
            CARGO_PROFILE_DEV_INCREMENTAL="false",
            CARGO_INCREMENTAL="0",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
            CUDA_VISIBLE_DEVICES="",
            PYTHONDONTWRITEBYTECODE="1",
            CC="/usr/bin/x86_64-linux-gnu-gcc-12",
            CXX="/usr/bin/x86_64-linux-gnu-g++-12",
            AR="/usr/bin/x86_64-linux-gnu-ar",
            CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER="/usr/bin/x86_64-linux-gnu-gcc-12",
            CARGO_HOME=str(OUT / "TMP/cargo-home"),
            CARGO_TARGET_DIR=str(OUT / "target"),
            TMPDIR=str(OUT / "TMP"),
            CARGO_CACHE_AUTO_CLEAN_FREQUENCY="never",
            CFLAGS="-MD",
            CXXFLAGS="-MD",
            PATH="/usr/bin:/bin",
        )
        binding = dict(
            version=1,
            files=files,
            trees=trees,
            namespaces=namespaces,
            absent=absent,
            selected_registry_packages=[name + "-" + version for name, version in sorted(selected)],
            source_scope="local type closure + locked normal/build dependency source superset + installed C/C++ headers/tools/sysroot",
            conditional_literal_headers_not_installed=sorted(conditional_missing),
            input_bytes_hashed=io,
            source_preparation_reader_STOP=guard.now(),
            physical=physical,
            environment=environment,
            registry_proof="actual installed source file hashes/modes/lengths and namespaces; stock registry does not require vendor checksum file",
            compiler_dependency_trace="CFLAGS/CXXFLAGS -MD record actual C/C++ system header inputs, checked with Rust .d records against this prebound map after the sole check; no extra compiler invocation",
            absent_registry_candidates=absent_registry_candidates,
            absence_policy="inactive conservative lock branches must stay absent; no new cache extraction admitted; actual offline check decides required closure",
            inherited_prep_failures=[
                "vendor checksum assumed in stock registry",
                "conservative lock closure required uninstalled inactive optional package",
            ],
        )
        encoded = json.dumps(binding, separators=(",", ":"), sort_keys=True).encode() + b"\n"
        if len(encoded) > 700000:
            raise ValueError("input map exceeds reserved control provision: " + str(len(encoded)))
        with (OUT / "bindings.json").open("xb") as stream:
            stream.write(encoded)
        (OUT / "environment.json").write_text(json.dumps(environment, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "binding_sha256": guard.digest(OUT / "bindings.json"),
                    "binding_bytes": len(encoded),
                    "Main_files": len(files),
                    "selected_packages": len(selected),
                    "tree_files": sum(map(len, trees.values())),
                    "input_bytes_hashed": io,
                    "source_preparation_reader_STOP": binding["source_preparation_reader_STOP"],
                    "conditional_missing_header_count": len(conditional_missing),
                }
            )
        )
    except BaseException as primary:
        try:
            lock.close()
        except BaseException as cleanup:
            raise BaseExceptionGroup(
                "binding failure and lease close", [primary, cleanup]
            ) from None
        raise
    else:
        lock.close()


if __name__ == "__main__":
    main()
