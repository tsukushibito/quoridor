# Ordering372 original process1/B stopped collection

Original job `c779fa40-957f-4f24-ac6b-0fe46f688c76` completed once. Normal FINALIZE ran once and published PASS. All 20 planned Search calls returned Ok and completed their requested depths: 16 depth4, four depth6, zero UNKNOWN. All 14 session setups completed; actual nodes are 28,769,396 against the unchanged 64M liability.

Saved verification confirms the fixed global schedule ids 20..39 and local request ids 0..19, both profiles, cold families and warm original root indices 4/5/6/7 (local plies 0/2/4/6), full counted roots, 14 setup/drop lifetimes, 20 observation/cost rows, and footer totals. All 20 pairs with original A have identical action/value bits/PV/depth/stop/full work counters and recorded ordering counters. Plain diagnostics are disabled; zero ordering statistics do not measure absent ordering work. No optimization benefit is graded from the current 40/80 calls.

Controller START 2026-10-12T07:43:09.296940+00:00; worker source STOP 2026-10-12T07:44:25.376571+00:00; controller STOP 2026-10-12T07:44:25.510978+00:00; whole 76.22184002003632s. Nested native whole 74.986580807s is not added. Known software plus process0/1 controllers total 387.36122353794053s once. Later saved collection, FINALIZE, formatting, administration and LLM costs are separate/UNKNOWN.

Complete 9,686-byte stdout equals the durable native result. One native was directly waited/reaped with closed handles, and native/worker/supervisor exact identities are freshly absent. TMP and INCOMPLETE are absent. Returned mask/final record completed remains distinct from persisted pending/attempted. Cleanup true, primary null, secondary/remaining empty. Continuous family RSS peak UNKNOWN.

All 135 selected SHA/size/mode refs match before/after, including actual Source B101, compiled38/generator47, current caller/dependencies, original input/model/library/private custody, current result and original A saved comparison refs. Source/input/library/private reader STOP 2026-10-12T07:51:12.294328+00:00; lease released before collector STOP 2026-10-12T07:51:12.295080+00:00. No new model/Search/build/test/geometry calls or source/target/private writes occurred during collection.

The inclusive 128KiB collection is already priced inside controls48MiB and the all-four controls forecast47,525,888B; raw all-four15,204,352B remains below16MiB. All original source/images/results/RAW/failedfees/masks/UNKNOWN and positive floors remain held.

Original process2/B is already authorized after this valid stopped census/cleanup and new fresh guards, with the same immutable B image/source and new exclusive controls/output/runtime. No Main restoration or Root ACK is needed for 2B. After actual2B source/library STOP, Root must restore exactly four A paths and verify all99 A source refs before3A. Task372.1 remains in progress; no idle reservation, replay/refill, Policy intermediate or default change.
