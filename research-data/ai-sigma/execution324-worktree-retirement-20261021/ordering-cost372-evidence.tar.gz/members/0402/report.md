# Original final3/A stopped collection

Job22a8bc4b-454a-4a12-9879-edc39f8b0048 completed once; normalFINALIZE PASS. All20 requested-depth returns complete,14sessions,28,769,396nodes/64M liability,0UNKNOWN. Exact output/fullwork/count-root/prefix/session plans match originalA0/B1/B2. Full9695B capture equals native result; directwait/reap/handlescleanup and all12 own identities freshly absent/TMP+INCOMPLETE gone.

ControllerSTOP2026-10-12T08:23:57.855226+00:00/whole130.87377806100994s, native129.21291593s nested NOTadded. P3 source-input-library-private readerSTOP2026-10-12T08:29:59.041436+00:00/collectorSTOP2026-10-12T08:29:59.041998+00:00; selected137 refs exactbeforeafter/currentA99/38/47 and savedhistoricalB scope. Later whole fixed80 aggregation/critical pipeline STOP is separate and supplied in result-handoff-v1.

All80 complete,56sessions,115,077,584nodes,0UNKNOWN. See result-handoff-v1/report.md and summary.json for the frozen adoption refusal despite passing profile medians. No newrun/source/target/private/model/test/geometry calls/writes; all oldfees/RAW/masks/UNKNOWN andpositivefloors held. This contained128KiB collection and finalpacket262KiB stay in existing48MiB controls/whole512MiB. Task remains in progress for normal related interpretation/intake; no runtime reservation.
