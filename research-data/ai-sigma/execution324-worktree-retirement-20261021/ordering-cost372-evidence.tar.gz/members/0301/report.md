# Ordering372 first A process: stopped result collection

Job `4094ee5e-91ba-411e-a172-ea04010e27b4` completed the original process 0/A once. Normal lifecycle FINALIZE ran once and published PASS. This is the first 20 of the fixed ABBA campaign's 80 planned calls; no optimization benefit is assessed yet.

The saved projection and journals agree on 20 attempted Search invocations, 20 Ok returns, 20 requested-depth completions, zero UNKNOWN, and 14 session setups. There are 16 depth4 and four depth6 returns. Actual nodes total 28,769,396 against the unchanged 64,000,000 liability. Both profiles retain their original cold families and warm original root indices 4/5/6/7, corresponding to local plies 0/2/4/6. Session setup/drop flags and 14 pass footers match the 20 requests and cost rows.

Saved verification checked projection/order, requested depth, node caps, f32 value bits, action/PV head, work-counter types, cold-book root and counted-history identities, repeated cross-profile roots, and cost/header/footer totals. Actual legality/replay and parent-restoration checks retain the reviewed caller's scope; collection did not execute geometry, a model, or Search. This plain campaign disables diagnostics: recorded ordering statistics are zero and cannot be interpreted as absent ordering work. No A/B work-equivalence or ratio claim can be made from A alone.

Controller START was 2026-10-12T07:05:16.394958Z and STOP 07:07:27.129567Z, whole 130.74609363800846 seconds. Native whole through result publication was 127.575381583 seconds, nested and not added. Known software plus first-process controller fees are 311.13938351790421 seconds. Later saved collection, FINALIZE, formatting, administration, and LLM work are separate; unmeasured amounts remain UNKNOWN.

One full 9,697-byte native stdout capture equals the durable native result. Native, worker, and supervisor were directly waited/reaped and their exact identities freshly absent. Returned mask restoration/final record are completed; persisted receipt retains pending/attempted. Outer cleanup is true, primary is null, secondary and remaining are empty. Operation INCOMPLETE and owned TMP are absent. Continuous family RSS peak remains UNKNOWN.

All 131 selected SHA/size/mode references match before/after collection, including actual restored Source A's 99 files, compiled38/generator47 projections, source/config/dependencies/current caller, input/model/library/private custody, and durable data. Source/input/library/private reader STOP is 2026-10-12T07:18:25.612118Z; canonical lease was released before collector STOP 07:18:25.614412Z. Current next reservation is empty.

The first collector refused on an incorrect lexical-order assertion for displayed history strings. Canonical HistoryKey ordering is a different representation. That refusal remains in `collection-failure.json`; the corrected check compares exact cold-book history arrays and cross-profile identities, unique positive counts, and the counted root. No experiment or source was changed or rerun.

Collection's inclusive 128KiB is contained in the existing controls forecast 42,610,688 bytes below the 48MiB cap. Original raw forecast 15,204,352 below 16MiB, all prior floors/failed fees/RAW/masks/UNKNOWN, and both authentic images remain held. No source, target, private, input, or model writes occurred.

Root324 can now restore exactly the four B native paths and verify all 101 immutable Source B refs before a fresh process1/B entry. The author has no Main source-switch authority. Processes1/2/3 remain NOT_ENTERED; task372.1 stays in progress. No hardware lease or parent/admin/Policy ACK hold follows this stopped A result.
