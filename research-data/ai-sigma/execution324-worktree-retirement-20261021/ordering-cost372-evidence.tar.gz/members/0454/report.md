# Ordering372: stopped exact-score source preparation

S and C are implemented as separable patches in the assigned managed
`ordering-cost372` workspace. The six affected Rust files pass scoped Rustfmt
2024 formatting and syntax parsing. Six new correctness definitions remain
**UNBUILT / UNTYPED / UNRUN**. There has been no Cargo, private-image creation,
target access/growth, model load, Search, geometry execution, game or measurement.
Independent source acceptance and runtime qualification remain separate.

The initial source is Root's managed Main `67f94a5` assignment. Four selected
Main beforeimages still matched this workspace's preserved beforeimages when
checked read-only. Root support `9370c827` grants the finite 512MiB whole scope;
it does not make a target, image or future hardware interval ready. Original
App cwd/model/high/full-access/never were verified in actual turn context
`01a12e15-621d-7950-acf7-744e11836d23` at 03:08:36.070Z.

## S: exact parent DAG work

`static_ordering.rs` formerly propagated all 81 origin rows for each player,
then extracted the actual pawn prefix and summed nine goal endpoints for each
suffix. The new code propagates the actual pawn prefix once in descending
distance order and sums goal suffixes once in reverse order. A suffix includes
the empty path at a reachable goal vertex. DAG edges, distances and topology
are the existing parent-only geometry; legal jump destinations use the same
existing map/progress expression.

For wall edges `(u,v)` and `(x,y)`, individual coverage is still
`prefix[u]*suffix[v]`. Intersection is still
`prefix[u]*paths(v,x)*suffix[y]` plus the opposite edge order. Strictly
decreasing distance makes those orders disjoint. The union is the same checked
sum-minus-intersection, normalized with the same checked `*1024 / total` floor,
then the same signed 512/128 coefficients, division and i16 clipping.

Only a contributing intersection with nonzero prefix/suffix can demand an
intermediate row. Identical endpoints contribute the empty path; a distinct
endpoint at equal/higher distance is unreachable. Otherwise the row is cleared
and propagated once, reused within that player/parent, and marked ready only
after its final control check. Ready bits reset per player/parent. There is no
geometry-keyed/global wall cache, child BFS/evaluation, recursive matrix clone
or state/history mutation. In the worst case up to 81 rows may still be needed;
no wall-time benefit or universal complexity improvement is asserted.

The invocation-owned heap remains 81*81*u128 = **104,976B**, with identical
fallible allocation/capacity. The scratch header adds 81 ready booleans; native
64-bit layout is expected to grow from 16B to 104B (an **88B** header increment),
with a future type/layout assertion. The existing prefix/suffix/DAG/topology
scratch remains local. This is accounting, not observed RSS or continuous peak.
Partial rows never become ready; subsequent preparation resets validity and
recomputes demanded rows. Checkpoints cover every nine prefix/suffix vertices,
every legal wall and each demanded-row start/end. The largest uninterrupted
phase is bounded by the fixed 81-cell/four-edge geometry/row, not a hard real-time
or asynchronous fault certificate. Changed checkpoint timing is not claimed
equivalent under time-limited/cancelled searches; the fixed comparison has no
time limit and retains honest interruptions.

## C: resolve the same rows once

`continuation_history.rs` now constructs `ResolvedRows` once per scored parent
and once per completed cutoff event. It stores pawn-from and wall main bases
plus five optional continuation row bases. Existing lags 1/2/3/4/6, actual
mover/parity, action-range check and absent sentinel are unchanged. Candidates
perform the same `2*main + five signed continuation` sum in the same slot order.
Returned unique siblings receive the same signed gravity, depth cap/bonus and
positive/negative event accounting. Deduplication and update order are unchanged.

Rows own only indices, have no allocation/table/path borrow and do not cross a
child transition. Their expected native local size is <=96B; history arrays
remain exactly 900,376B. The alpha change is limited to one import and resolving
rows before the existing candidate loop. Everything outside those two changes
reconstructs byte-exact, including TT, PVS, evaluation, terminal/control/undo,
priorities, diagnostics and scientific counters. Constructor, gravity, bonus,
main/continuation namespaces, reset, 16-valid-root aging and all Stats fields are
unchanged. The single-action `scores` convenience exists only under cfg(test)
for current fixtures, not a parallel production path.

## Discriminating affected definitions

The three S definitions compare all 209 scores, goal flags and ordered legal
IDs with independent BFS/explicit-route enumeration on seven fixed parents:
empty, alternate wall routes, H/V obstacles, both STM, straight/diagonal jump and
goal-near cases, with borrowed/computed maps and reused scratch. Separate
diamond/intersection/row-failure fixtures check demand-only propagation,
deduplication, i16/integer arithmetic, u128 overflow refusals, incomplete-row
invisibility, cancellation/error, unreachable maps and reentry. Each explicit
reference route enumeration refuses above 20,000 paths; it never silently
approximates or truncates coverage.

The three C definitions use an independent raw-index/i64-gravity reference,
positive/negative/extreme table values, both movers, every lag/missing sentinel,
all 209 raw index slots and actual legal sorting. Raw typed path fixtures are
explicitly not chronological game-history proofs. Full tables and cutoff
counts are compared after duplicate-return events and before/after 16-root
aging/reset. A narrow maintained-state port checks actual parent ordering tiers,
child cancellation/returned evaluator error, path/root restoration and unchanged
history on reentry. It reuses existing fixture helpers without replaying their
old tests or a complete-tree suite. Only one NN0 fake evaluator call is possible;
actual model heads are zero in these definitions.

The conservative new qualification ceiling is **61 scoring/context/cutoff/child
admissions <=64** and **one fake evaluation <=32 heads**: 23 S prepares, 16 C raw
score contexts, 17 cutoff events, three ordered calls and two child attempts.
Reference calculations/sorts/table captures/setup/drop are all qualification
work. Six exact filters and scoped affected AI Clippy are prepared, not admitted
or executed. Existing `static360_tests.rs` changes only one helper-signature
call; assertions and all other source are exact. No old successful suite is
requested for execution.

## Fixed future comparison and concrete remaining entry conditions

`fixed80-schedule.json` and `assessment-and-software-plan.json` freeze one ABBA
block, same BEST43/current ScalarFT/TT4096/1MiB/PVS, two existing profiles.
Four processes each perform 20 calls: continuation then combined static;
per profile, four cold D4 families 0/34/68/102, four chronological warm D4
local plies 0/2/4/6, then cold D6 families 34/102. The original warm root indices
are **4/5/6/7**. Every cold root gets a fresh session; each profile/process gets
one separate warm session retaining TT/history across the four real roots.
There are **80 calls / 56 sessions / 256M node liability** (64 D4 at 2M,
16 D6 at 8M), with null total/end/notify/command timers and ordinary count,
node, resource, cancellation and once-finalization ownership bounds.

Per context, the primary ratio is median(B1,B2 whole-root) divided by
median(A0,A3 whole-root), then median of ten contexts per profile. All four
B-versus-bracketing-A ratios and cold/warm/depth strata remain visible. Positive
acceptance requires all 80 requested depths complete, exact valuebits/action/PV
and scientific node/eval/cutoff/PVS/TT/key/history/capacity work, combined median
<=0.95, continuation median <=1.02, and no context where both B repetitions
exceed the bracketing A median by >1.05. Partial/capped/error results remain
UNKNOWN/FAILED, without rescue/refill/sweep/extra campaign. There is no CI,
general speed/strength, causal CPU share or profile/default-switch claim.

Existing accepted368 reports (31bc/1e69/0fcc) establish a negative fixed static
result and repeated-work motivation only. Original raw journals/model/root
payloads were not reaggregated. Whole-root must include actual setup/replay,
maps/history/FT/scratch/sort, primary+cost serialization/sync and session drop;
shared model/input/header/footer/directwait/finalizers stay outer, nested costs
are not added or assigned invented per-root shares.

Two real implementation boundaries remain before heavy entry. First, Root has
not handed over a literal sole shared target/current retained floor/192MiB
positive growth to this owner. No target or private path was touched. Second,
the retained qualified368 runner image's `ordering_assessment::schedule` and
`validate` require the old 360-call protocol. It cannot truthfully execute this
80-call plan unchanged. The smallest necessary maintained-caller change is a
fixed 80-call projection plus bound validation/census/footer, retaining the
existing model/replay/output/session/cleanup path. No runner source write is
assigned in this source phase. Root must bind that ordinary caller adaptation
to the actual role-specific image(s), including any strictly necessary caller
closure; no by-habit baseline rebuild, old 360-call replay, second target or
permanent dual-TT/source framework is proposed. The existing image/Build refs
remain held by reference, not relabelled as 80-call-ready.

## Supported whole and stopped handoff

Issued worker component uppers are source16 + target-positive192 + private32 +
control24 + raw16 + serialTMP144 + failure56 = **480MiB**, plus review8/Root24 =
**512MiB**. The managed sparse-source floor is 4,993,024B. This source phase
prepriced at most 1MiB source/test/preimage/patch growth and 256KiB controls;
later current larger samples/floors and all simultaneous private/TMP/failure
lifetimes must be charged before growth. Two required images must fit the actual
private union, existing baseline is referenced rather than copied. Target
retained floor/marker/custody are still unknown to this owner, not free cache.
Global held support is 49,153,437,696B, not actual disk usage or a refund.

Future substantial software/measurement requires related source clear and
readerSTOP, actual source/tool/compiler/dependency/library/image/model/input
correspondence, 3GiB family including64MiB controller/4GiB host reserve, CPU1/
thread1/GPU0 and fresh peer/physical/named-quiet/nonblocking lifetime custody.
Qualified367 and371 fits/evals/PDF retain priority. Light source preparation
holds no hardware lock/reservation or whole-parent/reply-ACK gate.

S/C patches, compressed beforeimages, exact selected maps and a memory-only
unified-patch reconstruction proof are frozen for Root's one related372.2
review. No self-dispatch, source adoption, test/type result or image authority is
claimed. Initial directional source reads preceded prewrite identity capture;
support and accepted small reports were hash-before-parse. Wrong formatter path
and an initially unscoped constructor-name matcher refused and were corrected,
with the original administrative failures retained in static-proof metadata.
All old RAW/FAILED/fees/floors/masks/UNKNOWN,323 USERPAUSE,seals/defaults/fullN/
fits96 remain unchanged. Parent/leaf stays in progress until real qualification,
one finite result and acceptance; this handoff is the actual source boundary.
