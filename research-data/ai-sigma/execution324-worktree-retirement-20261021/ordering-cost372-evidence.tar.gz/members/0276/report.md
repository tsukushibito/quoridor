# Accepted372 comparison-only retirement proposal

The fixed80 result is accepted, with overall prebound adoption **FAIL** at continuation coldD4 family34. This proposal removes the completed comparison entry while keeping baselineA computation and the active ordering-assess path. It makes no new optimization, performance, capacity, model or default decision.

Root324 owns application to Main/Git/index. The author changed only sparse derivatives in this exclusive artifact directory. The strict patch modifies four current files and deletes three comparison-only test sources:

- Runner main.rs: remove only the ordering-cost-assess command arm.
- Runner ordering_assessment.rs: remove fixed372 constants, types, schedule/validation/input correspondence, cost dispatch and test wiring. Specialize the existing cost=false implementation as the one public run. Keep ordinary360 plan/schedule, context replay, evaluator/session/Search parameters, observed fields, journals, setup/drop clocks, failure/close/once-finalization paths.
- Runner research_manifest.rs: remove only372 source-reuse and numerical-subject branches; preserve ordinary ordering-assess qualification checks and current BUILD-vs-RUN owning boundaries.
- Current375 publisher research-lifecycle.py: remove ordering_cost372_inputs and the372 branches in retained_ordering_source/numerical_check/experiment_check. The current76b04fb1 source is the base.
- Delete unreferenced AI static372_tests.rs and continuation372_tests.rs; delete runner ordering372_tests.rs and its comparison-only wiring. Active baseline static/continuation code, static360/current correctness modules stay.

## Exact preservation and verification

All seven before images are gzip-preserved with original SHA/size/mode. Strict forward and inverse parsing reproduces every postimage and exact original bytes without fuzz. Outside edit hunks is unchanged. The unchanged ordinary ordering-assessment schedule/math/replay/session/IO/error/qualification helper span is33,594B byte exact, and its current test tail is exact except the removed372 wiring. Publisher other53 functions/classes are byte exact; the three changed functions are the named removal subjects only, with experiment_check all other statements AST exact.

Rustfmt2024 parse/format/check of only three affected sparse Rust derivatives, project Ruff format/check of the derivative and two finite preparation/proof scripts, Python AST/compile syntax only, and scoped Markdown/JSON formatting are the checks. No Rust typecheck, old assertions, build, model, geometry, Search, game, native scientific call or successful-suite replay was performed. Detailed runtime/collision/math proofs are the accepted original source/result scopes, not re-executed here.

The exact source usages were searched only in the relevant runner/AI/dev and maintenance documentation scopes. After the removal, no fixed372 entry/schema/helper or test-module reference remains in the four derived maintained sources. The two optimized-only AI modules have no current baseline wiring. Current ordering_assessment_tests.rs references ordinary costs.jsonl and remains unchanged.

## Composition and reconstruction

The shared function/path subjects were delivered directly to SAME374.1 arena owner, preserving its actual saved arena-evaluation cwd. Its source derivative is not modified. Root composes this exact removal with current374 source only after the relevant actual reader releases; an unrelated owner/admin/parent closure is no gate. A strict before mismatch requires owning-boundary composition, not replacing a newer publisher with these full postimages.

Current source is actual accepted375 publisher76b04fb1/149213 and restored baselineA alphabeta ed7c/115809. Olde19/B state and old370ca/ef4 qualification are never restored or relabeled. All old frozen comparison packets, source/software/private custody, raw/scientific data/input/models, failed fees/masks/UNKNOWN remain referenced and untouched. Git is the reconstruction source for obsolete code after Root preserves/applies this proposal; exact before gzip and inverse make the local handoff reconstructible. No compatibility shim, source mirror, registry or repeated experiment is retained as a live entry.

The proposed deletions are source-only; no data/model/RAW/private/target/cache/worktree deletion or byte-credit/refund is granted. The inclusive4MiB proposal is inside existing source16MiB/worker480/whole512MiB. All prior component floors/positive forwards/global holdings are held. Root alone performs adoption and settles later retention. This leaf remains in progress until actual required preservation/cleanup acceptance, with no hardware reservation or reply-only ACK.

See operation-manifest.json for the literal7 operations and refs, proof.json for strict inverse/AST scope, and the final source/control STOP for current bindings and empty owned lists.
