#372 baselineA failed BUILD, released

Original job `cb3e7293` failed at the first Cargo test compilation: E0716 in `ordering372_tests.rs:47`. The fixture helper closure inferred a borrowed name lifetime incompatible with the temporary formatted library name. No new metadata assertion executed. Seven normal tool-version commands passed; Clippy, release, private copy and bindings were not reached. Models, heads, geometry and Search calls are0.

The smallest proposed Root-only repair is the explicit helper parameter `|name: &str|`. It changes no assertions, workload, scores, input identity or runtime boundary. Exact inverse and Rustfmt2024 stdin agreement passed. No Main/managed Rust source was edited and no job was retried.

Controller START04:49:25.191024, worker STOP04:49:30.646087, controller STOP04:49:30.772485Z; whole5.581935861s. Nested failed Cargo3.579562162s is not added. Normal FINALIZE executed once and published authoritative FAILED manifest25136d9a. It retained the original missing returned guardian/capture_complete=false and persisted pending/attempted mask facts; outer cleanup=true and exact process absence do not promote that to an inner completion certificate. The operation INCOMPLETE marker was removed by normal finalization only; raw/candidate/failed statuses remain.

Collector source-reader STOP04:54:32.763501 and lease release04:54:32.764134Z. All99 source/38 compiled/47 generator and tool/dependency witnesses match; MainA oldS/C and publisher are unchanged. Seven version children, failed Cargo child, lifecycle and supervisor exact identities are freshly absent. TMP is absent, new private root contains only its4096B directory, A image does not exist. Current target sample1361850368 is held, versus preentry1361846272; no cache/fee/raw/mask refund. Continuous family peaks remain UNKNOWN.

Root can apply the one fixture annotation after this actual source release and issue the genuinely unfinished A source/control continuation. No B adoption/image or80-call assessment is qualified yet. No extra source review, old successful suite/head/model replay or human method ACK is requested.
