"""One stopped sparse removal proposal; never writes Main or executes research."""

import gzip
from pathlib import Path


BASE = Path(__file__).parent / "after"


def once(text, old, new=""):
    assert text.count(old) == 1, repr(old[:100])
    return text.replace(old, new, 1)


def span(text, start, end, replacement=""):
    assert text.count(start) == 1
    a = text.index(start)
    b = text.index(end, a + len(start))
    assert a < b
    return text[:a] + replacement + text[b:]


def publish(name, transform):
    path = BASE / name
    before = gzip.decompress(
        (Path(__file__).parent / "before" / (name + ".gz")).read_bytes()
    ).decode()
    after = transform(before)
    assert after != before
    path.write_text(after)


def assessment(t):
    t = once(
        t,
        'const COST_SCHEDULE_SHA: &str = "79cbf20f954007d5c13e1904c8e337ab360056e18d2cd7537b67fa8b08de00c4";\n',
    )
    t = once(
        t,
        'const COST_SUPPORT_SHA: &str = "9370c8271fd8958c7da0d035d8f31cc906ab1e4864aafcdaeeb6376b6be483b8";\n',
    )
    t = span(t, "/// One of four fixed processes.", "fn schedule()")
    t = once(
        t,
        "fn run_impl(bound: &BoundControl, cost: bool)",
        "pub fn run(bound: &BoundControl)",
    )
    t = span(
        t,
        "    let (cost_plan, requests, roots) = if cost {",
        "    let output_root = output_correspondence()?;\n    let inputs_seconds",
        "    let (_, requests, roots) = prepare_inputs(&e)?;\n    let planned = 360;\n    let node_limit = AGGREGATE;\n",
    )
    t = once(t, "    let mut header = json!", "    let header = json!")
    t = span(
        t,
        "    if let Some(plan) = &cost_plan {\n        if plan.plan.output",
        "    let mut count = Census::default();",
        "    let mut output = Output::new(&output_root);\n",
    )
    t = once(t, "    let mut cost_stops = [0usize; 4];\n")
    t = span(
        t,
        "                        if cost {",
        '                        pending["observed"] = observed(&r);',
    )
    t = once(
        t,
        'if cost {"quoridor.ordering372.result.v1"} else {"quoridor.continuation360.result.v1"}',
        '"quoridor.continuation360.result.v1"',
    )
    t = once(
        t,
        'if cost {"quoridor.ordering372.failure.v1"} else {"quoridor.continuation360.failure.v1"}',
        '"quoridor.continuation360.failure.v1"',
    )
    t = span(
        t,
        "    let annotate = |mut value: Value| {",
        '\n#[cfg(test)]\n#[path = "ordering_assessment_tests.rs"]',
        "    finish_output(&mut output, outcome, secondary, failure)\n}\n",
    )
    t = once(t, '\n#[cfg(test)]\n#[path = "ordering372_tests.rs"]\nmod ordering372_tests;\n')
    return t


def main(t):
    return span(
        t,
        '        #[cfg(feature = "ordering-assessment")]\n        "ordering-cost-assess" => {',
        '        "value-search-compare" => {',
    )


def manifest(t):
    start = '#[cfg(feature = "ordering-assessment")]\nfn retained_ordering_source('
    body = "    // One source-adoption decision records the reviewed wrapper-only change."
    t = span(
        t,
        start,
        body,
        '#[cfg(feature = "ordering-assessment")]\nfn retained_ordering_source(\n    current: &Value,\n    original: &Value,\n    adoption: &Value,\n    qualification: &FileRef,\n    original_ref: &FileRef,\n) -> Result<()> {\n',
    )
    t = span(
        t,
        "    let mut wrappers = vec![",
        '    if adoption["schema"]',
        '    let wrappers = [\n        "runner/ordering_assessment.rs",\n        "runner/research_manifest.rs",\n    ];\n',
    )
    t = span(
        t,
        '    let test_changes = reuse["changed_native_tests"].as_array();',
        "    for (path, old) in &old_files {",
        '    if old_files.keys().ne(new_files.keys()) {\n        return Err("ordering native source membership changed".into());\n    }\n',
    )
    t = once(
        t,
        'return Err("372 native source removal refused".into());',
        'return Err("ordering native source removal refused".into());',
    )
    t = once(t, "            && !reviewed_test(Some(old), Some(new))\n")
    t = once(
        t,
        '    for (path, new) in &new_files {\n        if !old_files.contains_key(path) && !reviewed_test(None, Some(new)) {\n            return Err("372 unreviewed native source addition".into());\n        }\n    }\n',
    )
    t = once(
        t,
        "    let (q, numerical_build, numerical_subject) = {",
        "    let (q, numerical_build) = {",
    )
    t = once(t, "        let mut numerical_subject = None;\n")
    t = once(
        t,
        '        let cost = e.argv.get(1).is_some_and(|a| a == "ordering-cost-assess");\n',
    )
    t = once(
        t,
        '        if cost || e.argv.get(1).is_some_and(|a| a == "ordering-assess") {',
        '        if e.argv.get(1).is_some_and(|a| a == "ordering-assess") {',
    )
    t = span(
        t,
        "            let correspondence = if cost {",
        "            if !crate::ordering_assessment::qualification_shape(&qualified)",
    )
    t = once(
        t,
        "                || (!cost\n                    && (qualified.config != e.config\n                        || qualified.schedule != e.schedule\n                        || qualified.inputs != e.inputs\n                        || qualified.models != e.models\n                        || serde_json::to_value(&qualified.dynamic_libraries)?\n                            != serde_json::to_value(&e.dynamic_libraries)?))",
        "                || qualified.config != e.config\n                || qualified.schedule != e.schedule\n                || qualified.inputs != e.inputs\n                || qualified.models != e.models\n                || serde_json::to_value(&qualified.dynamic_libraries)?\n                    != serde_json::to_value(&e.dynamic_libraries)?",
    )
    t = span(
        t,
        "                if cost {\n                    retained_ordering_source_impl(",
        "                numerical_build = original;",
        "                retained_ordering_source(\n                    &build,\n                    &original,\n                    &adoption,\n                    reference,\n                    &qualified.build_manifest,\n                )?;\n",
    )
    t = once(
        t,
        '            if cost && qualified.build_manifest == e.build_manifest {\n                return Err("372 new caller cannot use original20 artifact".into());\n            }\n',
    )
    t = once(
        t,
        "            if cost {\n                numerical_subject = Some(qualified);\n            }\n",
    )
    t = once(
        t,
        "        (q, numerical_build, numerical_subject)",
        "        (q, numerical_build)",
    )
    t = once(
        t,
        '    #[cfg(feature = "ordering-assessment")]\n    let subject = numerical_subject.as_ref().unwrap_or(&e);\n    #[cfg(not(feature = "ordering-assessment"))]\n    let subject = &e;',
        "    let subject = &e;",
    )
    t = once(
        t,
        '        || (e.argv.get(1).is_some_and(|a| a == "ordering-cost-assess")\n            && q["canonical_plan_sha256"] != subject.canonical_plan_sha256)\n',
    )
    return t


def publisher(t):
    t = span(t, "def ordering_cost372_inputs(", "def retained_ordering_source(")
    t = once(
        t,
        "def retained_ordering_source(current, original, adoption, qualification, original_ref, cost=None):",
        "def retained_ordering_source(current, original, adoption, qualification, original_ref):",
    )
    t = span(t, "    if cost is not None:", '    require(\n        adoption["schema"]')
    t = span(
        t,
        "    def reviewed_test(before, after):",
        "    for path, old in old_files.items():",
        '    require(set(old_files) == set(new_files), "ordering native source membership changed")\n',
    )
    t = once(t, "            or reviewed_test(old, new)\n")
    t = once(
        t,
        '    for path in set(new_files) - set(old_files):\n        require(reviewed_test(None, new_files[path]), "372 unreviewed native source addition")\n\n',
    )
    t = once(t, '    cost = experiment["argv"][1] == "ordering-cost-assess"\n')
    t = once(
        t,
        '    if cost or experiment["argv"][1] == "ordering-assess":',
        '    if experiment["argv"][1] == "ordering-assess":',
    )
    t = once(
        t,
        "        correspondence = ordering_cost372_inputs(experiment, qualified) if cost else None\n",
    )
    t = once(t, "            cost\n            or all(\n", "            all(\n")
    t = once(
        t,
        "                manifest, original, adoption, reference, original_ref, correspondence\n",
        "                manifest, original, adoption, reference, original_ref\n",
    )
    t = span(
        t,
        "        if cost:\n            require(",
        '        q = q["data"]["numerical_qualification"]',
    )
    t = once(
        t,
        '    if experiment["phase"] == "compare" and experiment["argv"][1] in {\n        "ordering-assess",\n        "ordering-cost-assess",\n    }:',
        '    if experiment["phase"] == "compare" and experiment["argv"][1] == "ordering-assess":',
    )
    t = once(
        t,
        '        if experiment["argv"][1] == "ordering-cost-assess":\n            require(\n                document(experiment["config"])["plan"]["output"] == spec["data_root"],\n                "372 owned runtime output",\n            )\n',
    )
    return t


if __name__ == "__main__":
    publish("crates/quoridor-runner/src/ordering_assessment.rs", assessment)
    publish("crates/quoridor-runner/src/main.rs", main)
    publish("crates/quoridor-runner/src/research_manifest.rs", manifest)
    publish("scripts/dev/research-lifecycle.py", publisher)
