"""Parse-only custody and inverse checks for this fixed seven-path removal."""

import ast
import difflib
import gzip
import hashlib
import json
import re
from pathlib import Path


BASE = Path(__file__).parent
ROOT = Path("/workspaces/quoridor")
DELETED = {
    "crates/quoridor-runner/src/ordering372_tests.rs",
    "crates/quoridor-ai/src/static372_tests.rs",
    "crates/quoridor-ai/src/continuation372_tests.rs",
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def apply_strict(raw, diff):
    """Read only the generated fixed-path hunks; no fuzzy application or writes."""
    source = raw.splitlines(keepends=True)
    out = []
    offset = 0
    lines = diff.splitlines(keepends=True)
    assert lines[0].startswith("--- ") and lines[1].startswith("+++ ")
    i = 2
    while i < len(lines):
        match = re.fullmatch(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n", lines[i])
        assert match, lines[i]
        old_start, old_n, new_start, new_n = match.groups()
        old_n = 1 if old_n is None else int(old_n)
        new_n = 1 if new_n is None else int(new_n)
        start = int(old_start) - (1 if old_n else 0)
        assert start >= offset
        out.extend(source[offset:start])
        offset = start
        i += 1
        consumed = produced = 0
        while i < len(lines) and not lines[i].startswith("@@ "):
            kind, text = lines[i][0], lines[i][1:]
            assert kind in " +-"
            if kind in " -":
                assert source[offset] == text
                offset += 1
                consumed += 1
            if kind in " +":
                out.append(text)
                produced += 1
            i += 1
        assert consumed == old_n and produced == new_n
        assert len(out) - new_n == int(new_start) - (1 if new_n else 0)
    out.extend(source[offset:])
    return "".join(out)


def main():
    before = json.loads((BASE / "prewrite.json").read_text())["before_current_Main"]
    maps = []
    patches = []
    inverse_patches = []
    for ref in before:
        name = str(Path(ref["path"]).relative_to(ROOT))
        old = gzip.decompress((BASE / "before" / (name + ".gz")).read_bytes())
        assert digest(old) == ref["sha256"] and len(old) == ref["bytes"]
        path = BASE / "after" / name
        new = b"" if name in DELETED else path.read_bytes()
        assert name not in DELETED or not path.exists()
        assert new != old
        old_label = "a/" + name
        new_label = "/dev/null" if name in DELETED else "b/" + name
        diff = "".join(
            difflib.unified_diff(
                old.decode().splitlines(True), new.decode().splitlines(True), old_label, new_label
            )
        )
        inverse = "".join(
            difflib.unified_diff(
                new.decode().splitlines(True), old.decode().splitlines(True), new_label, old_label
            )
        )
        assert apply_strict(old.decode(), diff).encode() == new
        assert apply_strict(new.decode(), inverse).encode() == old
        patches.append(diff)
        inverse_patches.append(inverse)
        maps.append(
            {
                "relative_path": name,
                "before": ref,
                "after": None
                if name in DELETED
                else {
                    "path": ref["path"],
                    "sha256": digest(new),
                    "bytes": len(new),
                    "mode": ref["mode"],
                },
                "derived_path": None if name in DELETED else str(path),
                "strict_forward_and_inverse": True,
                "unchanged_outside_hunks": True,
                "hunks": diff.count("\n@@ "),
            }
        )
    (BASE / "removal.patch").write_text("".join(patches))
    (BASE / "inverse.patch").write_text("".join(inverse_patches))

    name = "scripts/dev/research-lifecycle.py"
    old = gzip.decompress((BASE / "before" / (name + ".gz")).read_bytes()).decode()
    new = (BASE / "after" / name).read_text()
    compile(new, str(BASE / "after" / name), "exec")  # Syntax only; never execute/import.
    original = {
        n.name: n for n in ast.parse(old).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))
    }
    current = {
        n.name: n for n in ast.parse(new).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))
    }
    changed = {
        n for n in original.keys() & current.keys() if ast.dump(original[n]) != ast.dump(current[n])
    }
    assert original.keys() - current.keys() == {"ordering_cost372_inputs"}
    assert current.keys() - original.keys() == set()
    assert changed == {"retained_ordering_source", "numerical_check", "experiment_check"}
    for n in current.keys() - changed:
        assert ast.get_source_segment(old, original[n]) == ast.get_source_segment(new, current[n])
    # The minimal experiment_check edit is independent of all arena/375 code.
    original_body = ast.get_source_segment(old, original["experiment_check"])
    expected = original_body.replace(
        'experiment["argv"][1] in {\n        "ordering-assess",\n        "ordering-cost-assess",\n    }',
        'experiment["argv"][1] == "ordering-assess"',
    )
    fixed_guard = '        if experiment["argv"][1] == "ordering-cost-assess":\n            require(\n                document(experiment["config"])["plan"]["output"] == spec["data_root"],\n                "372 owned runtime output",\n            )\n'
    assert expected.count(fixed_guard) == 1
    expected = expected.replace(fixed_guard, "")
    assert ast.dump(ast.parse(expected)) == ast.dump(
        ast.parse(ast.get_source_segment(new, current["experiment_check"]))
    )
    name = "crates/quoridor-runner/src/ordering_assessment.rs"
    old = gzip.decompress((BASE / "before" / (name + ".gz")).read_bytes()).decode()
    new = (BASE / "after" / name).read_text()
    beginning = "fn schedule()"
    end = "/// Uses the maintained generic Experiment"
    assert old[old.index(beginning) : old.index(end)] == new[new.index(beginning) : new.index(end)]
    tail = '\n#[cfg(test)]\n#[path = "ordering_assessment_tests.rs"]'
    old_tail = old[old.index(tail) :].replace(
        '\n#[cfg(test)]\n#[path = "ordering372_tests.rs"]\nmod ordering372_tests;\n', ""
    )
    assert old_tail == new[new.index(tail) :]
    for path in (BASE / "after").rglob("*"):
        if path.is_file():
            assert not re.search(
                r"ordering372|ordering-cost-assess|CostPlan|CostRequest|run_cost|retained_cost_inputs|ordering_cost372_inputs",
                path.read_text(),
            )
    proof = {
        "issue": "quoridor-4lc.372.1",
        "maps": maps,
        "strict_minimal_forward_inverse_exact": True,
        "outside_edit_hunks_unchanged": True,
        "publisher_unaffected_function_class_bodies_byteexact": len(current) - len(changed),
        "publisher_changed_functions_only": sorted(changed),
        "publisher_deleted_function_only": "ordering_cost372_inputs",
        "publisher_experiment_check_other_statements_AST_exact": True,
        "ordering_assessment_schedule_math_replay_session_IO_error_qualification_segment_byteexact_B": len(
            old[old.index(beginning) : old.index(end)].encode()
        ),
        "ordering_assessment_current_tests_tail_byteexact_except_only_372_wiring": True,
        "statically_specialized_live_route": "current run_impl(cost=false) -> public run; original360 plan/schedule/count/model/Search/cost-journal/error/finalization statements retained; no new behavior selected",
        "removed_test_scope": "two unreferenced optimized-only AI modules and comparison-only runner372 metadata definitions; active static360/current ordering_assessment correctness modules retained",
        "Python_syntax_compile_without_execution": True,
        "runtime_tests_model_geometry_Search_native_build_calls": 0,
        "typecheck_runtime_qualification": "NOT_RUN; literal removal parse/source proof only",
        "retained_source_identity": "current375 publisher76b04fb1 plus actual restoredA computation; no olde19/B numerical reclassification",
        "Root_adoption": "NOT_ADOPTED; source-current/readerSTOP and current374 composition required; Main/Git/index writer Root only",
    }
    (BASE / "proof.json").write_text(json.dumps(proof, indent=2) + "\n")
    print(
        json.dumps(
            {
                "changed_paths": len(maps),
                "removed_modules": len(DELETED),
                "publisher_unaffected_BYTEEXACT": len(current) - len(changed),
                "strict_inverse": True,
                "new_runtime_calls": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
