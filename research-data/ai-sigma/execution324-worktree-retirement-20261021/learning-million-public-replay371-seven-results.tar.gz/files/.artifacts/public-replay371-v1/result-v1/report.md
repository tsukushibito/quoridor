# Public replay371 fixed two-arm result

The selected two arms completed200 full64-row updates each and every requested diagnostic/full-opened-V measurement. Replay mitigated public MSE and sign-accuracy degradation relative to added-only. Both LAST200 models nevertheless worsened full opened-V MSE and sign accuracy versus shared INITIAL. Both also worsened added-V MSE. This completes the finite learning-curve comparison; it does not establish improved strength, convergence or an optimal replay ratio.

[Two-page comparison PDF](public-replay371-comparison.pdf), [four-panel SVG](mse-curves.svg), [full-precision88-row curves CSV](all-curves.csv), [full-precision table/exposure JSON](summary.json). Eleven points are evaluations, not eleven weight snapshots. Only two LAST model exports/checkpoints were created; INITIAL remains the existing immutable reference. PDF35147B<8MiB; two-page structure and owning layout checked. Independent raster/text extraction was unavailable with installed utilities; no dependency was added.

## Observed outcome

| Evaluation scope           |   Rows | INITIAL MSE | Added-only LAST200 | Replay LAST200 |
| -------------------------- | -----: | ----------: | -----------------: | -------------: |
| Added T                    |    217 | 0.607616551 |        0.075567458 |    0.210949456 |
| Added V                    |     76 | 0.988318670 |        1.383881509 |    1.224835771 |
| Public T frozen diagnostic |   8192 | 0.417721881 |        0.590998402 |    0.436259593 |
| Opened V frozen diagnostic |   8192 | 0.438102217 |        0.622420959 |    0.459764884 |
| Full opened V              | 419150 | 0.423870713 |        0.602325569 |    0.443130563 |

PublicT diagnostic is8192 preselected train-only records; openedV diagnostic8192 preselected already-opened validation records. Full openedV contains419150 records. All metrics are unweighted row means on recorded outcome z, with squared error of final tanh value; sign accuracy uses nonzero-label rows, saturation measures abs(value)≥0.9. Full precision, including all four scopes' sign/saturation curves and family summaries, is retained in original training.json and the CSV/JSON.

| Full opened V      |         MSE | Sign accuracy | Saturation abs(value)≥0.9 |
| ------------------ | ----------: | ------------: | ------------------------: |
| INITIAL            | 0.423870713 |    84.311344% |                48.539664% |
| Added-only LAST200 | 0.602325569 |    78.371943% |                51.280926% |
| Replay LAST200     | 0.443130563 |    83.594417% |                49.308839% |

Added-only lowers added-T MSE more strongly(0.607616551→0.075567458) than replay(→0.210949456), while its public degradation is larger. Replay added-V MSE1.224835771 is below added-only1.383881509, but both exceed INITIAL0.988318670. Added-V sign accuracy is0.552631579 for replay versus0.565789474 for added-only and INITIAL0.631578947: lower MSE is not uniform improvement across metrics.

| Added V family | Rows | INITIAL MSE | Added-only LAST200 | Replay LAST200 |
| -------------- | ---: | ----------: | -----------------: | -------------: |
| 6c9e2b1dd974   |   28 | 0.638721659 |        0.526577235 |    0.642297146 |
| 14108e8ca4c0   |   48 | 1.192250260 |        1.883975668 |    1.564649968 |

## Fixed work and exposure

Both independently warm-start immutable BEST43 weights046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841, descriptor46ec2c47/evaluator96a5f41f, same incumbent T-only scale/QF1/FT32/H32/Zero4/FP32/tanh/standardizedD-head/input D/80/output bypassOFF. Fresh Adam each: LR0.001/betas0.9,0.999/eps1e-8/wd0, updates1..20 linear warmup then constant, batch64/seed36220261011/reflectionseed36220261012/probability0.5. No early convergence stop, V-selected model or refit; primary comparison LAST200. No50-epoch claim: full batches cycle across217 added rows.

- Added-only:12800 added exposures,217 distinct,12583 repeats; every eligible added row appears58 or59 times. No public training exposures.
- Replay:6400 added exposures,217 distinct,6183 repeats, each29 or30 times;6400 publicT exposures,6398 distinct/two repeat exposures. Shared6400 added index and reflection prefixes agree exactly in saved arrays and source hashes.
- Fixed publicT sampling seed37120261012 with replacement; diagnosticT/V8192 indices each frozen without replacement before outcome decode using seeds37120261013/37120261014. Same11 evaluation steps0,20,…,200 include217addedT/76addedV and both public diagnostic subsets. Shared full openedV INITIAL evaluated once by A and reused unchanged by B; each LAST evaluated once.
- A1034547+B615397=1649944 actual scientific row-forwards. Original affected mixed-loss synthetic fixture64; R1 cleanup0; render/counter collection0. Aggregate1650008≤2000000, remaining349992. No further predictions or campaign were performed.

Existing341-row canonical corpus/seven-binary compact522b is unchanged; common293=217T76V,48 excluded in BOTH arms. Source histories/gzip remain reconstruction evidence outside training. PublicT8413949 is train-only; openedV419150 eval-only; sealedE never opened, even for hashing. No second public scan/global hash dictionary, feature cache mirror or model/evaluator copy.

## Original results, timing and custody

Both original authoritative manifests are PASS/cleanuptrue/primarynull/secondary[]/remaining[] and their INCOMPLETE markers were removed last. A authoritativefinished2026-10-12T03:54:00.121844+00:00, B03:57:55.913975. A LAST weights5fed7ac8d237303021a34cee71484cfd75fb2dde4e9d4f782d390231a246be9d, B LAST160a66f421f7593d5e56ccee9c55a3d471db751357524d38e65905d3cf96e4b8. B starts046fe, never from A. Original eight output refs per arm, current plan/source/config/model/environment/library/Build inputs and exact STOPs are in result-binding.json.

Only original returned command walls count at their scopes: A7.163113988004625s, B5.127937959972769s, fit+evaluation pair12.291051947977394s. Separate training-internal6.5124992210185155/4.541315019945614s are nested and not added. Generation/build/public scan were not repeated. Training versus evaluation separate durations UNKNOWN. Render command2.0122639159671962s, saved metrics only. Both job-controller wholes sum16.965737182996236s and are not added to inner commands; source/qualification/admin/LLM/Git elapsed totals UNKNOWN. Original affected fixture1.5757230729795992s and R1zero-forward0.26691446895711124s are separate software scopes.

CPU1/thread1/GPU0; each fit used supported2GiB family including64MiB controller below3GiB upper, host reserve4GiB, owned240MiB inside issued256MiB worker/review/Root envelope. Inputs/env were held once, no copies or installed dependencies. Direct child reaping, process/handle cleanup and source/input/model/library hashes after matched. Returned masks/persistence completed versus disk pending/attempted remain distinct. Continuous peakRSS/working set and exact worker UTCexit UNKNOWN; lifecycle/controller timestamps are not substituted for model first-forward/worker exit.

A collector readerSTOP03:55:45.595735, B03:59:17.540919. Render source/env readerSTOP04:02:22.259214 and canonical release04:02:22.259607. Saved-output readerSTOP04:06:40.464504/release04:06:40.468090. All owned scientific children/jobs/readers/TMP lists empty, no idle hardware reservation. Actual source/native/cache/environment/unique output/failure evidence retained; no asset retirement/refund. A stale administrative state.json locator and pre-entry completed-output predicate refusal were corrected without launching/rerunning/refinalizing. Saved-exposure audit initially assumed a JSON digest; it refused, then used the owning exact LEu32 digest. Original data/source/results never changed.

## Inferential limits and integration text

This fixed50:50 intervention also halves added-row repetition. It cannot isolate a replay-gradient causal effect or establish50:50 as optimal. Both arms share initializer, seeds and initial evaluation; repeated/opened validation and only two related addedV families limit generalization. Public recordedz lacks recoverable complete game/history/winner/termination/rules lineage. MSE/sign accuracy/saturation reflect this retained record scope, not terminal truth, strategic novelty or corruption. No legal alternatives, native parity, teacher regeneration, strength games, convergence/population/IID/default/fullN or paused323 resumption is implied. Any ratio/data/training/strength change remains a later human choice; none was selected here.

Suggested existing-findings delta: “Fixed371 two200/full64 outcome-z arms completed. Replay32added+32publicT mitigated full openedV MSE deterioration(0.443130563) relative to added-only(0.602325569), but both exceeded INITIAL0.423870713; addedV MSE also worsened. Replay halves added repetition, so this is a finite exposure/learning tradeoff, not isolated replay causality, optimal-ratio or strength evidence.”
