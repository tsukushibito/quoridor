# B1 aggregate-node accounting repair

Both failed-return and accepted-return additions call `add_search_nodes`, which assigns only after checked u64 addition succeeds. MAX+1 returns a stage-specific accounting error; it cannot wrap/saturate or change the prior accumulator. Missing-node parse errors keep their original messages. No depth/node/move/time cap or search/teacher/model/rule/TT/RNG policy changed.

Producer summary and saved-only footer audit share this checked path. A refused producer summary leaves previously committed game rows/returned counters/termination/failure facts intact and attempts the existing generation-failure receipt; it cannot publish a successful footer. A saved wrapped footer cannot be validated by unchecked recomputation.

One new `depth6_node_aggregate_normal_boundary_and_both_overflow_routes` Rust definition passes synthetic SearchResult ports through maintained play/summary paths for accepted and underdepth failed returns: 7+9=16, MAX+0=MAX, MAX+1 refuses with corresponding stage; original game serialization remains exact, underdepth UNKNOWN/failed evidence preserved, summarize_results also refuses, accumulator itself is unchanged on error. Near-terminal genuine prefix replay belongs the fixture, not a scientific four-game depth6 reference. This definition is UNBUILT/UNTYPED/UNRUN.

Only two owned Rust files changed (summary/helper and affected definition), formatted/scoped rustfmt-check PASS. Before gzip, prior review2357/control328c and fullold source target5a1e remain unchanged. All old successful geometry/math/session/scheduler/lease source conclusions are reused. No compiler/model/Search/native/geometry execution or old suite replay in this repair.

Controller e119cc and verified STOP724eaf are now a concrete future software dependency. They are outside the B1 source question; sourceclear never exempts controller/proof/owner/physical/storage/lease or actualreaderSTOP. No new software/scientific job is submitted by this handoff. Parent348 remains incomplete and actual four-game runtime cost UNKNOWN.
