"""Finite owned software chain; maintained cycle_process owns each child/wait."""

from builtins import BaseExceptionGroup

import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time

sys.path.insert(0, "/workspaces/quoridor/python")
from quoridor_training import cycle_process as P

ROOT = Path("/workspaces/quoridor/.worktree/deeper-teacher-scheduling")
BASE = ROOT / ".artifacts/deeper-teacher-scheduling-v1"
OUT = BASE / "compiler-repair-v2"
BIND = json.loads((OUT / "software-source-binding.json").read_text())
TARGET, TMP, PRIVATE = BASE / "target", OUT / "TMP-software-v2", BASE / "private"
OLD_TMP = BASE / "TMP-software"
LOCK = Path(
    "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
)


def allocated(root):
    total = root.stat().st_blocks * 512 if root.exists() else 0
    pending = [root] if root.exists() else []
    while pending:
        with os.scandir(pending.pop()) as entries:
            for entry in entries:
                info = entry.stat(follow_symlinks=False)
                total += info.st_blocks * 512
                if stat.S_ISDIR(info.st_mode):
                    pending.append(Path(entry.path))
    return total


def verify_source():
    for row in BIND["rows"]:
        p = Path(row["path"])
        raw = p.read_bytes()
        if (
            hashlib.sha256(raw).hexdigest() != row["SHA256"]
            or len(raw) != row["bytes"]
            or stat.S_IMODE(p.stat().st_mode) != row["mode"]
        ):
            raise P.CycleStopped("fixed software source changed: " + str(p))


def quiet():
    for path in Path("/proc").iterdir():
        if not path.name.isdigit() or int(path.name) == os.getpid():
            continue
        try:
            args = (path / "cmdline").read_bytes().split(b"\0")
            name = Path(args[0].decode(errors="replace")).name
            if name in {"cargo", "rustc", "nnue-diagnose", "quoridor-runner"} or (
                name.startswith("python")
                and any(
                    part in args
                    for part in (
                        b"quoridor_training.train",
                        b"quoridor_training.sigma_reference",
                    )
                )
            ):
                raise P.CycleStopped(
                    "foreign finite software/model interval: " + str(path)
                )
        except (FileNotFoundError, ProcessLookupError):
            continue


def notify(stage, identities=()):
    path = OUT / f"software-{stage}.txt"
    path.write_text(
        f"348.1 actual software {stage} UTC={time.time()} CPU3/oneCargojob/GPU0; "
        f"identities={list(identities)}; source-only newdepth6 NN0 then runner build/CLIcheck, "
        "scientificgames/modelcalls0. Exact process receipts/STOP in "
        + str(OUT)
        + ".\n"
    )
    for thread, issue, cwd in (
        (
            "01a11062-b120-73a1-8aa3-fe2cb922c7c0",
            "quoridor-4lc.348.2",
            "/workspaces/quoridor/.worktree/arena-evaluation",
        ),
        (
            "01a1153d-7900-7740-837f-c300ca54764f",
            "quoridor-4lc.324",
            "/workspaces/quoridor",
        ),
    ):
        reply = subprocess.run(
            [
                "bash",
                "/workspaces/quoridor/scripts/dev/research-session.sh",
                "send",
                "--thread",
                thread,
                "--issue",
                issue,
                "--body-file",
                str(path),
                "--cwd",
                cwd,
            ],
            text=True,
            capture_output=True,
            timeout=60,
        )
        P.save_record(
            OUT / f"software-{stage}-{issue}.json",
            {"exit": reply.returncode, "reply": (reply.stdout + reply.stderr)[-4096:]},
        )
        # One delivery attempt; unknown RPC is not resent.


class Guard(P.CycleResources):
    def __init__(self):
        super().__init__(
            {
                "host_ram_reserve": BIND["host_reserve_B"],
                "max_memory_bytes": BIND["family_RAM_B"] - BIND["controller_RAM_B"],
                "max_output_bytes": BIND["whole_B"],
                "pause_file": str(OUT / "cancel"),
            },
            ROOT,
            None,
        )
        self.started = False
        self.peaks = {}

    def check(self, owned=()):
        super().check(owned)
        verify_source()
        for path, cap in (
            (TARGET, BIND["target_B"]),
            (TMP, BIND["TMP_B"]),
            (PRIVATE, BIND["private_B"]),
        ):
            now = allocated(path)
            self.peaks[str(path)] = max(now, self.peaks.get(str(path), 0))
            if now > cap:
                raise P.CycleStopped(
                    f"owned component cap: {path} actual{now} cap{cap}"
                )
        if allocated(TMP) + allocated(OLD_TMP) > BIND["TMP_B"]:
            raise P.CycleStopped("retained+new TMP sharedcap")
        rest = (
            allocated(ROOT)
            - allocated(TARGET)
            - allocated(TMP)
            - allocated(OLD_TMP)
            - allocated(PRIVATE)
        )
        if rest > 64 * 1024**2:
            raise P.CycleStopped("source/control checkout cap")
        if owned and not self.started:
            self.started = True
            notify("START", owned)


def main():
    os.chdir(ROOT)
    os.environ.update(
        CARGO_TARGET_DIR=str(TARGET),
        TMPDIR=str(TMP),
        CARGO_NET_OFFLINE="true",
        CARGO_INCREMENTAL="0",
        OPENBLAS_NUM_THREADS="1",
    )
    verify_source()
    quiet()
    for p in (TARGET, PRIVATE):
        if not p.is_dir() or p.is_symlink():
            raise P.CycleStopped("retained own component identity unavailable")
    TMP.mkdir(exist_ok=False)
    guard = Guard()
    compiler = subprocess.run(
        [shutil.which("rustc"), "-Vv"], text=True, capture_output=True, check=True
    ).stdout
    P.save_record(
        OUT / "compiler.json",
        {
            "rustc": compiler,
            "cargo": shutil.which("cargo"),
            "profile": "release/opt3/thinLTO/codegen1; offline--locked-j1",
            "env": {
                k: os.environ[k]
                for k in (
                    "CARGO_TARGET_DIR",
                    "TMPDIR",
                    "CARGO_NET_OFFLINE",
                    "CARGO_INCREMENTAL",
                )
            },
        },
    )
    commands = [
        [
            shutil.which("cargo"),
            "test",
            "--offline",
            "--locked",
            "--release",
            "-j1",
            "-p",
            "quoridor-runner",
            "--lib",
            "depth6_",
            "--",
            "--test-threads=1",
        ],
        [
            shutil.which("cargo"),
            "build",
            "--offline",
            "--locked",
            "--release",
            "-j1",
            "-p",
            "quoridor-runner",
            "--bin",
            "quoridor-runner",
        ],
    ]
    receipts = []
    primary = None
    started = time.monotonic()
    try:
        with P.cancellation_signals():
            for index, command in enumerate(commands):
                quiet()
                with LOCK.open("a+") as lock:
                    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    try:
                        record = P.execute(
                            command,
                            OUT / f"software-{index}.log",
                            None,
                            cpu_core=3,
                            resources=guard,
                        )
                        if (
                            record.get("direct_child_reaped") is not True
                            or record.get("cleanup_complete") is not True
                            or record.get("remaining") != []
                        ):
                            raise P.CycleStopped("owned software STOP not verified")
                        receipts.append(record)
                    finally:
                        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
            source = TARGET / "release/quoridor-runner"
            if source.stat().st_size > BIND["private_B"]:
                raise P.CycleStopped("private executable upper")
            if (PRIVATE / "quoridor-runner").exists():
                raise P.CycleStopped("private path already owned; no overwrite")
            shutil.copyfile(source, PRIVATE / "quoridor-runner")
            (PRIVATE / "quoridor-runner").chmod(0o755)
            guard.check()
            receipts.append(
                P.execute(
                    [
                        str(PRIVATE / "quoridor-runner"),
                        "teacher-pilot",
                        "--config",
                        str(OUT / "depth6-config.json"),
                        "--check-config",
                    ],
                    OUT / "software-2.log",
                    None,
                    cpu_core=3,
                    resources=guard,
                )
            )
    except BaseException as error:
        primary = error
    finally:
        final_errors = []

        def attempt(stage, action):
            try:
                return action()
            except BaseException as error:
                final_errors.append((stage, error))

        leftovers = attempt("TMP_census", lambda: [p.name for p in TMP.iterdir()])
        if leftovers == []:
            attempt("owned_empty_TMP_remove", TMP.rmdir)
        attempt("source_recheck", verify_source)
        record = {
            "status": "FAILED" if primary or final_errors else "SOFTWARE_PASS",
            "primary": repr(primary) if primary else None,
            "returned_receipts": receipts,
            "wall_s": time.monotonic() - started,
            "sampled_component_peaks": guard.peaks,
            "continuous_family_peak": "UNKNOWN",
            "TMP_remaining": leftovers if leftovers is not None else "UNKNOWN",
            "models": 0,
            "scientific_games": 0,
            "source_match": not any(n == "source_recheck" for n, _ in final_errors),
            "actualSTOP": time.time(),
            "final_failures": [{"stage": n, "error": repr(e)} for n, e in final_errors],
        }
        attempt(
            "STOP_persist", lambda: P.save_record(OUT / "software-STOP.json", record)
        )
        attempt("STOP_notify", lambda: notify("STOP"))
        if final_errors:
            errors = ([primary] if primary is not None else []) + [
                e for _, e in final_errors
            ]
            group = BaseExceptionGroup("software primary/finalization", errors)
            group.add_note("final facts: " + json.dumps(record))
            raise group
    if primary:
        raise primary


if __name__ == "__main__":
    main()
