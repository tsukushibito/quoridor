# Maintained depth6 independent-game recipe

Status: source-engineered; software qualification pending after controller fail-closed authority-read timeout. Scientific games/model calls zero.

Existing `teacher-pilot --config … --check-config|--run` dispatches explicit `phase=depth6_throughput`; `teacher-pilot-audit` detects its authoritative stream schema. Old fixed64/depth3 recipe is retained unchanged. `teacher_pilot_execution::run_depth6_with_cancel` accepts caller-owned AtomicBool; cancellation creates no eligible teachers.

Four stable IDs `deeper-teacher-depth6-four-game-000` through `003`, lengths 4/8/12/16, seed20261008/max32 attempts. ID-derived RNG and input-only frozen family partition precede outcomes. Exact/reflected duplicates and terminal prefixes are refused, evidence retained/no fill. Worker completion order cannot change IDs/prefixes/split/teachers.

Two independent workers each own a game/history and TWO original per-colour persistent TT sessions, 4096 slots each. One single-thread search active per game, using the session selected by actual STM. No cross-colour TT-sharing optimization. D(a0,b8)/PVS/canonical rules/teacher sign remain maintained. Every accepted move requires complete depth6/depth_cap, explicit u64::MAX nodes and time_limit=None. Goal/genuine third occurrence terminal; ply200 UNKNOWN. Underdepth/error/cancel/illegal result UNKNOWN, not eligible lower-depth salvage.

Immutable indexed scheduling, bounded per-worker channel and index-ordered writer. Writer failure drops all receivers before joining all threads; ScheduleFailure keeps original error and join facts. Partial stream retained/refuses complete audit. Request journal and authoritative stream preserve attempts/starts/completed/UNKNOWN/errors. Saved-only audit before full footer follows worker joins. Opaque failed work has no invented zero-node evidence. External whole-generation/serialization/audit/cleanup receipt is required for completed games/hour and eligible rows/hour; per-game/search spans alone cannot supply them.

Software fixtures use synthetic ports, not scientific serial reference, mathematical/model/strength or live fault qualification. Runtime deep-game cost UNKNOWN; no d3 extrapolation/sweep/N selection/extra games. Four-game numerical entry belongs Arena348.2 only after fixed-source review and affected software success.

Software outer nonblocking canonical writer lease starts before TMP/START/Popen, stays across commands/private/source/final cleanup STOP, then independently attempts unlock/close. Old V1/V2 per-command scope remains historical. Actual V3 failedcontroller STOP nevertheless confirmed lease released with no release failures and owned directwait/cleanup[]. Guard stage records avoid in-job Beads RPC; communication is separately reported. The unchanged canonical controller's 5-second authority-read timeout failed again, so no blind retry/bypass/main helper edit by this owner.
