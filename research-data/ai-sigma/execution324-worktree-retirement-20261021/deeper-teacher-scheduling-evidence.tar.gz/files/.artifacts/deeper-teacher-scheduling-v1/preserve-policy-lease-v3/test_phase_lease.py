"""Actual guard main AST: fake ports only, no process/lock/framework imports."""

from builtins import BaseExceptionGroup

import ast
import json
from pathlib import Path
import time
from types import SimpleNamespace
import unittest

SOURCE = Path(__file__).with_name("software_guard.py")


class PhaseLease(unittest.TestCase):
    def run_case(
        self, body_error=None, acquire_error=None, unlock_error=None, close_error=None
    ):
        events = []

        class Handle:
            def fileno(self):
                return 4

            def close(self):
                events.append("close")
                if close_error:
                    raise close_error

        def flock(fd, op):
            events.append("unlock" if op == 8 else "acquire")
            error = unlock_error if op == 8 else acquire_error
            if error:
                raise error

        def phase():
            events.extend(
                ["TMP", "START", "commands", "private", "source", "cleanupSTOP"]
            )
            if body_error:
                raise body_error

        def save(path, value):
            events.append(path.name)

        node = next(
            x
            for x in ast.parse(SOURCE.read_text()).body
            if isinstance(x, ast.FunctionDef) and x.name == "main"
        )
        ns = {
            "LOCK": SimpleNamespace(open=lambda mode: Handle()),
            "fcntl": SimpleNamespace(flock=flock, LOCK_EX=2, LOCK_NB=4, LOCK_UN=8),
            "os": SimpleNamespace(getpid=lambda: 123),
            "time": time,
            "P": SimpleNamespace(save_record=save),
            "OUT": Path("/fake"),
            "owned_phase": phase,
            "json": json,
            "BaseExceptionGroup": BaseExceptionGroup,
        }
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(SOURCE), "exec"), ns)
        error = None
        try:
            ns["main"]()
        except BaseException as caught:
            error = caught
        return events, error

    def test_lifetime_and_primary_identity(self):
        events, error = self.run_case()
        self.assertIsNone(error)
        self.assertLess(events.index("acquire"), events.index("TMP"))
        self.assertLess(events.index("cleanupSTOP"), events.index("unlock"))
        primary = KeyboardInterrupt("original")
        events, error = self.run_case(body_error=primary)
        self.assertIs(error, primary)
        self.assertIn("lease-STOP.json", events)

    def test_unlock_failure_cannot_skip_close_or_original(self):
        primary, unlock, close = (
            ValueError("primary"),
            OSError("unlock"),
            OSError("close"),
        )
        events, error = self.run_case(primary, unlock_error=unlock, close_error=close)
        self.assertEqual(error.exceptions, (primary, unlock, close))
        self.assertLess(events.index("unlock"), events.index("close"))
        self.assertIn("lease-STOP.json", events)

    def test_refusal_never_starts_owned_phase(self):
        primary = BlockingIOError("busy")
        events, error = self.run_case(acquire_error=primary)
        self.assertIs(error, primary)
        self.assertNotIn("TMP", events)
        self.assertNotIn("unlock", events)
        self.assertIn("close", events)

    def test_sessions_restore_legacy_source_policy(self):
        source = Path(
            "crates/quoridor-runner/src/teacher_pilot_execution.rs"
        ).read_text()
        start = source.index("fn play_with_policy(")
        end = source.index("fn scheduled_failure(", start)
        body = source[start:end]
        self.assertIn("let mut sessions = [", body)
        self.assertEqual(body.count("SearchSession::new("), 2)
        self.assertIn("sessions[usize::from(context.position().turn)]", body)
        self.assertNotIn("session_index", body)


if __name__ == "__main__":
    unittest.main()
