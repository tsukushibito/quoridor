# 348.3 affinity/prior-config-v8 source confirmation

**Blockers0 / ordinary findings0** for the fixed inlet and prior-config boundary. This is conditional SOURCE clearance, not actual entry, resource isolation, four-game completion or throughput qualification. Parent348 remains incomplete.

Target2185422ecf3589389542e25a1d2476a560ac9f21431431bbede60d075af713bc; worker964b4f78dcfc2b96d60972674fb17e6ffc20ff87b4099af55f0e45c24ccc6e1a. All18 selected inputs plus packet match SHA/size/mode before and after. Exact map in control.json. Patch7413a963 reconstructs the new worker byte-for-byte from f9f532bb. Unchanged source ASTs and main normalization proof are in delta-checks.json; no source functions or supplied ports were executed.

## Four-core inlet

The necessary maintained [resources::admit](/workspaces/quoridor/.worktree/deeper-teacher-scheduling/crates/quoridor-runner/src/resources.rs:55) uses current process affinity, collapses physical siblings, sorts representatives, reserves the last min(n-1,2), then limits remaining candidates by quota-minus-two and validates requested workers. With four distinct admitted representatives0/2/4/6 and quota>=4, reserves are4/6 and requested worker pool0/2 remains available with inference=false. Old inlet0/2 leaves only0; inlet0/2/4 likewise leaves only0. This matches the reported native refusal, without reproducing it.

The changed guardian checks four distinct package/core tuples, actual allowed0246 and at least four-core cgroup quota before entry, while generation argv passes0246 to the unchanged native selector. Config still requests workers0/2, guardian stays4; native RAM reserve and worker count are unchanged. CPU6 is host reserve, not a third game worker. Resources.rs use was limited to generic admit/available-memory selection semantics; an oversized directed excerpt included unused explicit-helper text, which was not assessed or qualified. No P/E-core, universal kernel, future quiet or scheduler-isolation certificate is given. Native/current physical checks can still refuse actual entry.

## Cached config-only stage

The new cached_config requires the fixed afc73714 job identity, stopped config-only PASS, complete directwait/cleanup and empty remaining; exact prior receipt argv/int exit0/directwait/cleanup/full-log retention; and log/receipt digests agreeing with the bound STOP immutable refs. All three prior artifacts are mandatory source bindings and therefore checked under the lifetime lease. Missing/malformed/mismatched evidence becomes a caught primary and cannot reach generation.

The unchanged main check still requires valid=true, integer models_loaded0, Nnull, exact configSHA and full compiled-source map, plus fixed D0b8. Directed metadata agrees with config017c, privatea45 supplied unchanged helper/guarded-execution chain and the current compiled identities. The process receipt proves argv/path and the log proves source/config identity; neither alone self-authenticates executable bytes. Same-image provenance relies on the supplied prior guarded same-private execution and fixed helper/private certificate, together with fresh private SHA under the current lease. No ELF or payload was read here.

Prior config PASS is separate from the exactly TWO new generation/audit receipts; it is not copied into attempts. New census compares two exact registered argv and verified exit0 records. Config reuse failure stops generation, generation refusal still stops audit, and partial/mismatched/finalization evidence still refuses qualification. Full-source/private/physical/owner/quiet/lease conditions remain fresh requirements; old CPU/quiet observations are not reused.

c77abe15 remains a whole FAILED afc73714 job: config-only PASS, generation refused BEFORE output/schedule/Search, saved audit NOT_RUN, all four scientific plans unfinished. The prior1.631769229s failed fee remains separate/held with prior253.172252253s; supplied known controller total254.804021482s excludes nested spans. Returned first signal-mask completed and persisted pending/final-record-attempted remain distinct. No historical receipt is rewritten, no all-fault success or UNKNOWN bypass is inferred.

## Unchanged boundaries and limits

Byte/AST checks show only physical/validate/cached_config/two-receipt census and corresponding main cache/metadata/census wiring changed. Main entry, execute, resource class, scientific generation/audit sequence and primary capture, collector and G1 finalizers match the accepted v6 after removing only declared changes. Config/TT/PVS/two colour sessions/depth6/u64MAX/timeNone/200UNKNOWN/IDs/RNG/Nnull remain in prior proof scope, without resurvey.

Eight supplied actual-source AST ports PASS was inspected, not rerun: four-core/quota/missing-reserve refusal, actual prior metadata read without CLI, failed exit/unknown cleanup/wrong digest cache refusal, and two-new census. This is mocked hardware/metadata evidence, not a live corrected inlet or generation. No old test, Rust, native, model, Search, geometry, framework or private execution occurred. Preparedfalse and new output/TMP namespaces remain; provisional qualification requires actual external controller/directwait/final cleanup acceptance. Rates remain None pending owner whole-external generation/serialization/audit/cleanup STOP. No new game/serial reference/N/fullvolume/training/adoption/default grant, paused323/seals intact.

## Preservation and STOP

Actual reader/substantial source analysis STOP **2026-10-09T04:49:13.627293+00:00**; owned readers/children/jobs/TMP remaining[]. Source/main/Git/index writes0; this evidence namespace only. All19 inputs unchanged. Input129096B plus packet is below1MiB. New131072B inclusive prewrite plus prior observed311296B=442368B below same cumulative2MiB, review128MiB/whole3481.5GiB. Prior307200 sample and old131K/262K uppers/raw/fees/masks/UNKNOWN remain held, no refund.

Source parsing/reconstruction/metadata checks wall0.013259620s/VmHWM19712KiB; final hash wall0.000281649s, CPU3/stdlibAS512MiB/GPU0. Individual uninstrumented source/admin fees and continuous family peak UNKNOWN. Formatter/Beads closure/backup/notices after readerSTOP are recorded separately. Close only348.3 and report once348.2+324. No idle clock, wholeUI/Main/348 completion gate or Root/human method ACK is introduced.
