# 348.3 B1 repair confirmation

B1 resolved. Blockers0 / ordinary findings0 for this fixed, narrow SOURCE-only accounting delta. Affected software remains pending; parent348 is incomplete.

Target B1-source-review-target.json SHA256 `04814dfe6bc734c529f81461fdd6347ed6f051e786b7a16dff5f902d4055f192`. All14 selected target/current-source/archive/delta/prior-proof SHA, length and modes match before and after. Exact map is in control.json. New execution source98889813 and new affected-definition source8e9c4cd8 reconstruct byte-for-byte from the two before gzip archives with patch55172538 (6118B). The archives decompress to prior executionb2c28791 and depth6 module634b7353. The other three Rust files retain their prior bound hashes. No source mirror or producer edit was made.

## B1 resolution

[add_search_nodes](/workspaces/quoridor/.worktree/deeper-teacher-scheduling/crates/quoridor-runner/src/teacher_pilot_execution.rs:796) evaluates checked_add and propagates its error before the assignment to report.search_nodes. MAX+1 therefore refuses and leaves that accumulator unchanged. No wrap, saturation or clipping is used. Missing-node parse errors retain their messages. Both prior unchecked additions are replaced by this helper, tagged failed_return and accepted_return respectively.

The producer summary and saved footer auditor use the same checked summary path. Overflow cannot yield an exact-total successful footer: summary returns Err; previously committed individual node counts, game rows, termination and failure facts remain in the original stream, and the unchanged failure-receipt path attempts to preserve the accounting cause. In-memory GameRecords are borrowed, not modified by summary. No universal disk-fault success or cleanup guarantee follows.

The new cfg(test) definition uses maintained play/summary ports for both accepted depth6 and rejected underdepth returns: 7+9=16, MAX+0=MAX, MAX+1 stage-specific refusal, unchanged input game JSON, retained failed evidence/UNKNOWN/no rows for underdepth, summarize_results refusal, and direct accumulator preservation on error. These are declared integer-domain fixtures with synthetic SearchResult values and reused near-terminal prefixes, not real huge-node searches or a scientific fixed-four serial reference. The definition is UNBUILT/UNTYPED/UNRUN; source inspection does not establish test success or type correctness.

## Scope and evidence

Prior target5a1ebe1c/review2357c442/control328c3f12 and readerSTOP23:31:58.228148 are unchanged and reused. Scheduler, two original per-colour4096TT/PVS sessions per game, rules, labels, RNG, family/split, strict depth6/u64MAX and old guard AST4 conclusions were not reviewed or executed again. The current source repair changes only the aggregate helper/call sites and one new test definition. No new depth/node/time cap, search policy, teacher, feature or model change is inferred.

Main-controller e119cc/verified STOP724eaf is a separate future software dependency named in the producer packet. This narrow review gives it no runtime/source/lease or admission qualification; the bounded65s authority read is not a scientific cap. Affected depth6 Rust filter/type/build/CLI/private and scientific four games remain NOT_RUN. No Cargo, Rust, native, library, model, Search, geometry, weights, ELF, assets/corpus, old64pilot, successful suite or guard AST execution occurred. Only tiny in-memory byte reconstruction and source-structure assertions ran; no new mocked scheduler or independent rules implementation was created. FullN remains unselected; defaults, seals and paused323 remain unchanged.

## Stop, costs and preservation

Actual reader/substantial source analysis STOP: **2026-10-08T23:42:21.654676+00:00**. Owned readers/children/jobs/TMP remaining[]. Source/main/Git/index writes0; only this repair evidence namespace is written. Ordinary formatting/Beads closure/backup/delivery after readerSTOP is separately recorded and does not reopen source analysis.

Inclusive new prewrite262144B plus observed prior namespace65536B =327680B, below total2097152B inside348 held review128MiB/whole1.5GiB. Prior observed61440B and all old uppers/failures/raw/fees/TMP/mask UNKNOWN remain held; no refund. Bound directed inputs166615B <1MiB. CPU3/stdlib AS512MiB/GPU0. Delta checks wall0.001317570s and VmHWM16280KiB are separately scoped; final hash wall0.000265203s. Continuous family peak and uninstrumented total source/admin fees remain UNKNOWN. Required ready output was accidentally unfiltered and tool-truncated; old issue conclusions were not surveyed or used. Show/claim were scoped only348.3. No prior successful proof replay was used to recover that display.

Only348.3 closes after this confirmation, backup and one report each348.1/348.2/324. Software/numerical admission retains its independent dependencies and fresh guards.
