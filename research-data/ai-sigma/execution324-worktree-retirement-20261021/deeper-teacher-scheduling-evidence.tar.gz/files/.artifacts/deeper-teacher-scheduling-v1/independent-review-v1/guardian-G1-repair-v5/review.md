# 348.3 G1-only repair-v5 confirmation

G1 is partially repaired. One residual ordinary P2 branch remains; blockers1, additional ordinary findings0. Source clearance is withheld for the same G1 attribution boundary. No new science, method or review role is requested.

Fixed target17fd3d33b59160ed2fb68de695e0140d20d9d1fd242be67409b8a48843878814 / worker0c177c19e0635b1bbbb607612dc38f73b408d679217e93b11580e4ce0552e27a. All17 selected inputs plus packet have matching SHA/size/mode before and after. Exact map in control.json. Patch97254766 reconstructs the new worker byte-for-byte from retained d914ea27. Source AST comparison confirms unchanged sha/verify/sources/quiet/physical/validate/collect_stream functions, main prefix/resource/execute definitions, scientific try body and primary-capture handler. This is source parsing, never AST function execution.

## Repaired G1 paths

receipt_fields rejects non-object receipts, non-list remaining and missing/non-integer exit_code (including bool). Decode and field checks are independently attempted; parsed malformed evidence stays in receipts, UNKNOWN blocks qualification and TMP removal, and remaining.extend uses only a validated list. receipt_census refuses malformed exit fields, and its call is protected. Diagnostic publication is attempted, followed by an independent terminal-failure-result attempt that can record a diagnostic failure. These repair the original shape/census/stdout branches.

The supplied eight actual-source AST/fake-port cases PASS their declared scope: receipt list/string, remaining:null, missing/bool exit, census refusal, original generation/resource error plus stdout refusal, and verified receipt missing exit. They were read, not rerun. They check later charge/result/close attempts and original-generation attribution. FakePath.open supplies a close that merely appends an event and never raises, so a failing final close is outside this evidence.

## Residual G1: a late close failure is not retained with an existing primary

[The changed finalization order](/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/deeper-teacher-generation-v1/control-guardian-repair-v5/depth6_worker.py:559) puts result publication, terminal diagnostic and terminal-failure result BEFORE attempt(lock_close, lock.close). If generation already failed and lock.close raises, attempt adds a lock_close row to local errors AFTER the final serialized result and diagnostic. The next branch immediately re-raises primary; it adds no exception note/group and makes no subsequent publication carrying that new close failure.

The original generation exception is preserved, but this secondary close cause is absent from the declared durable result/diagnostic and is not explicitly attached to the returned primary. This does not claim an actual close failure, orphan, false qualification or numeric result. It is the same requested independent-finalization/primary-plus-secondary attribution question, exposed by moving close below all publication attempts.

After all finalizers, retain the accumulated secondary facts with an existing primary, for example by attaching structured exception notes before re-raising that same exception. Preserve the canonical lifetime ordering and the requirement for actual external controller/directwait/cleanup acceptance; no lease-release-before-publication redesign is required. Add one focused producer main-port definition combining an original generation refusal with a failing close, asserting the original primary and retained lock_close cause. Same author/reviewer stopped delta is sufficient; old eight/20/native successful suites need no broad replay.

On a primary-free path, the existing RuntimeError includes result.stage_failures after close because that in-memory list aliases errors. The residual identified here is specifically the existing-primary branch. Prepublication qualified fields are still provisional and cannot replace actual worker/controller/directwait/final cleanup success; rates remain None. A failed external job must not be accepted even if an earlier file carried qualified=true.

## Scope, preservation and STOP

Earlier review54f7de59/control2abf and readerSTOP03:32:18.059777 are unchanged. Old20/helper5/privatea45/adcf/native B1/math/labels/PVS/scientific/body proofs were reused without source survey or runtime replay. Prepared entry remains false; no native/private/library/framework execution or payload/ELF/weights/corpus/geometry/Search/model/scientific tests or own fake ports ran. Four scientific games, external whole rate, N and adoption remain unqualified; paused323/seals/defaults intact.

Actual reader/substantial source analysis STOP **2026-10-09T03:50:44.090515+00:00**; owned readers/children/jobs/TMP remaining[]. Source/main/Git/index writes0. Only this evidence namespace is written. New262144B inclusive prewrite plus prior observed188416B gives450560B below same cumulative2097152B, held348 review128MiB/whole1.5GiB. All old uppers/raw/fees/masks/UNKNOWN remain held without refund.

CPU3/stdlibAS512MiB/GPU0; source delta reconstruction/AST parsing wall0.009471064s/VmHWM18836KiB; final hash wall0.000289324s. Continuous family peak and uninstrumented individual source/admin fees remain UNKNOWN. Formatting/admin after readerSTOP is separately recorded. Existing source stays bound to this STOP; producer ordinary repair may proceed then refreeze to the same reviewer. Close only348.3 and backup/report once348.2+324; parent348 incomplete. No idle clock or method ACK is introduced.
