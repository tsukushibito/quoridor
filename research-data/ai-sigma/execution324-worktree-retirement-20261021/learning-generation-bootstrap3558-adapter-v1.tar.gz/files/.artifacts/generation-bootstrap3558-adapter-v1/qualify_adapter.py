"""Finite NN0 source-only guard for ONLY the new generation adapter cases."""

import argparse
import datetime
import fcntl
import importlib
import json
import os
from pathlib import Path
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "value-search-strength355-analysis-v1"
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", required=True)
    parser.add_argument("--tests", nargs="*")
    args = parser.parse_args()
    with LOCK.open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        sys.path.insert(0, str(OLD))
        guard = importlib.import_module("io355")
        guard.named_quiet()
        guard.finite_physical()
        sys.path.insert(0, str(HERE))
        refs = {
            str(path): guard.identity(path)
            for path in [
                HERE / "lifecycle355.py",
                HERE / "test_bootstrap_adapter.py",
                Path(__file__).resolve(),
                OLD / "io355.py",
                OLD / "strength355.py",
            ]
        }
        sample = (
            sum(p.stat().st_blocks * 512 for p in HERE.rglob("*")) + HERE.stat().st_blocks * 512
        )
        if sample + 65536 > 1048576:
            raise RuntimeError("Own new1MiB source support exceeded")
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        clock = time.monotonic()
        module = importlib.import_module("test_bootstrap_adapter")
        suite = (
            unittest.defaultTestLoader.loadTestsFromNames(args.tests, module)
            if args.tests
            else unittest.defaultTestLoader.loadTestsFromModule(module)
        )
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        for path, ref in refs.items():
            if guard.identity(Path(path)) != ref:
                raise RuntimeError("Own selected source changed during NN0 fixture")
        if list(HERE.glob("synthetic-bootstrap-adapter-*")):
            raise RuntimeError("Owned fixture cleanup incomplete")
        high = (
            int(
                next(
                    line.split()[1]
                    for line in Path("/proc/self/status").read_text().splitlines()
                    if line.startswith("VmHWM:")
                )
            )
            * 1024
            + 67108864
        )
        if high > 536870912:
            raise RuntimeError("Sampled family allowance exceeded")
        stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
        record = {
            "schema": "quoridor.strength355.generation-adapter-NN0-STOP.v1",
            "issue": "quoridor-4lc.355.8",
            "actual_START": start,
            "actual_reader_STOP": stop,
            "PASS": result.wasSuccessful(),
            "count": result.testsRun,
            "failures": [str(test) for test, _ in result.failures],
            "errors": [str(test) for test, _ in result.errors],
            "source_refs": refs,
            "whole_seconds": time.monotonic() - clock,
            "sampled_family_including64MiB_B": high,
            "continuous_peak_LLM_admin_fees": "UNKNOWN",
            "owned_readers_children_jobs_TMP_remaining": [],
            "model_Torch_native_Cargo_geometry_Search_games_realdata_calls": 0,
            "actual_applied_context": "08:19:51.333Z/danger-full-access/never/originallearning-million/gpt6.1-solhigh",
            "own_hardware_reservation_after_direct_return": "NONE",
        }
        (HERE / ("NN0-STOP-" + args.version + ".json")).write_text(
            json.dumps(record, indent=2) + "\n"
        )
        return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    raise SystemExit(main())
