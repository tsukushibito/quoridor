"""New downstream numerical-null refusal fixtures; no runtime qualifications."""

from pathlib import Path
import tempfile
import unittest
from unittest import mock

import lifecycle355 as life

HERE = Path(__file__).resolve().parent


def descriptor(path, sha="a" * 64, mode="0644"):
    return {"path": str(path), "sha256": sha, "bytes": 1, "mode": mode}


class DownstreamGuard(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(
            prefix="synthetic-bootstrap-adapter-", dir=HERE
        )
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)

    def experiment(self, phase):
        rows = []
        selected = life.MODELS[:1] if phase == "arena" else life.MODELS
        for i, (manifest, weights, evaluator) in enumerate(selected):
            rows.append(
                {
                    "descriptor": descriptor(
                        self.root / f"model{i}", manifest, "0644" if i == 0 else "0600"
                    ),
                    "weights": descriptor(self.root / f"weights{i}", weights),
                    "evaluator_sha256": evaluator,
                }
            )
        return {
            "schema": life.PREFIX + "experiment.v1",
            "phase": phase,
            "build_manifest": descriptor(self.root / "manifest.json"),
            "canonical_plan_sha256": life.s.PLAN_SHA,
            "planned_slots": 512 if phase == "arena" else 0,
            "batch": 0 if phase == "arena" else None,
            "rules": life.RULES,
            "distance_units": life.UNITS,
            "value_perspective": life.PERSPECTIVE,
            "config": descriptor(self.root / "config"),
            "schedule": descriptor(self.root / "schedule"),
            "inputs": [descriptor(self.root / "input")],
            "models": rows,
            "dynamic_libraries": [],
            "numerical_qualification": None,
        }

    def metadata(self, value):
        file = descriptor(self.root / "experiment")
        metadata = mock.Mock()
        metadata.refs = {
            "experiment": {
                "path": file["path"],
                "SHA256": file["sha256"],
                "bytes": file["bytes"],
                "mode": file["mode"],
            }
        }
        metadata.get.return_value = value
        return metadata, file

    def test_all_downstream_phases_refuse_null_even_with_matching_models(self):
        for phase in ("materialize", "compare", "arena", "analysis"):
            value = self.experiment(phase)
            metadata, file = self.metadata(value)
            with self.subTest(phase=phase), self.assertRaises(ValueError):
                life.experiment(metadata, file, value["build_manifest"], phase)

    def test_null_model_free_draft_cannot_escalate_to_analysis_or_arena(self):
        for phase in ("materialize", "compare", "arena", "analysis"):
            value = self.experiment(phase)
            value["models"] = []
            metadata, file = self.metadata(value)
            with self.subTest(phase=phase), self.assertRaises(ValueError):
                life.experiment(metadata, file, value["build_manifest"], phase)


class GenerationGuard(DownstreamGuard):
    def fixture(self):
        value = self.experiment("generation")
        value["models"] = []
        value["schedule"] = descriptor(
            self.root / "schedule",
            "65a242a4ccec472a47a6aa0df806dd6dbf71a9e51bbdb27b550325765af5ebf3",
        )
        value["schedule"]["bytes"] = 44027
        value["inputs"] = [
            descriptor(self.root / "plan", life.s.PLAN_SHA),
            descriptor(
                self.root / "OPEN8",
                "be50f486ccfdef3ae1c1bddde33d8369398a19c2a6ccd3d3324b64863f322dbc",
            ),
        ]
        artifact = descriptor(self.root / "runner", mode="0755")
        value["argv"] = [
            artifact["path"],
            "strength-book",
            "--experiment",
            "@EXPERIMENT@",
            "--experiment-sha256",
            "@EXPERIMENT_SHA256@",
        ]
        config = {
            key: {"path": ref["path"], "sha256": ref["sha256"]}
            for key, ref in zip(("plan", "old_prefixes"), value["inputs"])
        }
        config["output"] = str(self.root / "data")
        metadata, file = self.metadata(value)

        def read(ref, *args):
            if ref == value["config"]:
                return config
            if ref == value["build_manifest"]:
                return {
                    "artifact": artifact,
                    "compiled_sources": {key: "b" * 64 for key in life.COMPILED_KEYS},
                }
            raise AssertionError("Unexpected read: numerical/model/outcome payload")

        metadata.read.side_effect = read
        return (
            value,
            metadata,
            file,
            config,
            {
                "artifact": artifact,
                "compiled_sources": {key: "b" * 64 for key in life.COMPILED_KEYS},
            },
        )

    def test_generation_null_and_omitted_do_not_construct_numerical_pass(self):
        for omitted in (False, True):
            value, metadata, file, _, build = self.fixture()
            if omitted:
                del value["numerical_qualification"]
            with self.subTest(omitted=omitted):
                self.assertIs(
                    life.experiment(metadata, file, value["build_manifest"], "generation"), value
                )
                self.assertIsNone(life.numerical(metadata, value, build))
                self.assertTrue(
                    all(call.args[0] is not None for call in metadata.read.call_args_list)
                )

    def test_generation_cannot_carry_models_or_numerical_certificate(self):
        for key, replacement in (
            ("models", self.experiment("compare")["models"]),
            ("numerical_qualification", descriptor(self.root / "fakePASS")),
        ):
            value, metadata, file, _, _ = self.fixture()
            value[key] = replacement
            with self.subTest(key=key), self.assertRaises(ValueError):
                life.experiment(metadata, file, value["build_manifest"], "generation")

    def test_generation_refuses_wrong_command_slots_batch_and_libraries(self):
        for key, replacement in (
            ("argv", ["runner", "compare"]),
            ("planned_slots", 512),
            ("planned_slots", False),
            ("batch", 0),
            ("dynamic_libraries", None),
        ):
            value, metadata, file, _, _ = self.fixture()
            value[key] = replacement
            with self.subTest(key=key, replacement=replacement), self.assertRaises(ValueError):
                life.experiment(metadata, file, value["build_manifest"], "generation")

    def test_generation_refuses_input_order_and_config_identity_drift(self):
        for mutation in ("order", "config", "plan"):
            value, metadata, file, config, _ = self.fixture()
            if mutation == "order":
                value["inputs"].reverse()
            elif mutation == "config":
                config["old_prefixes"]["sha256"] = "f" * 64
            else:
                value["inputs"][0]["sha256"] = "f" * 64
                config["plan"]["sha256"] = "f" * 64
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                life.experiment(metadata, file, value["build_manifest"], "generation")

    def completion_fixture(self, status):
        value, metadata, file, _, build = self.fixture()
        completion_ref = descriptor(self.root / "operation" / "manifest.json")
        original = {"type": "SyntheticGenerationFailure", "message": "original partial"}
        completed = {
            "schema": life.PREFIX + "completion.v1",
            "kind": "run",
            "status": status,
            "cleanup_complete": status == "PASS",
            "remaining": [],
            "authoritative_finished_at": "2026-10-10T07:00:00+00:00",
            "primary": None if status == "PASS" else original,
            "secondary": []
            if status == "PASS"
            else [{"stage": "owed_finalizer", "type": "Synthetic", "message": "retained"}],
            "checks": [{"guardian_return": None, "persisted_process_receipt": None}],
            "outer_job_result": descriptor(self.root / "outer-result"),
            "intent": descriptor(self.root / "intent"),
            "owed_finalizers": [],
            "build_manifest": value["build_manifest"],
            "experiment": file,
            "data": {"files": [descriptor(self.root / "available-partial")], "errors": []},
        }

        def add(ref):
            metadata.refs[ref["path"]] = {
                "path": ref["path"],
                "SHA256": ref["sha256"],
                "bytes": ref["bytes"],
                "mode": ref["mode"],
            }
            return ref["path"]

        original_read = metadata.read.side_effect
        metadata.read.side_effect = (
            lambda ref, *args: value if ref == file else original_read(ref, *args)
        )
        metadata.add.side_effect = add
        metadata.get.side_effect = (
            lambda name, *args: completed if name == completion_ref["path"] else value
        )
        return value, metadata, completion_ref, completed, build

    def test_finalized_generation_preserves_failed_partial_provenance_without_numerical(self):
        value, metadata, ref, completed, build = self.completion_fixture("FAILED")
        actual, experiment = life.finalized_input(metadata, ref, value["build_manifest"])
        self.assertIs(actual, completed)
        self.assertEqual(actual["status"], "FAILED")
        self.assertFalse(actual["cleanup_complete"])
        self.assertIs(actual["primary"], completed["primary"])
        self.assertEqual(len(actual["secondary"]), 1)
        self.assertEqual(len(actual["data"]["files"]), 1)
        self.assertIsNone(life.numerical(metadata, experiment, build))

    def test_finalized_generation_refuses_candidate_marker_and_build_substitution(self):
        for mutation in ("marker", "build"):
            value, metadata, ref, completed, _ = self.completion_fixture("PASS")
            if mutation == "marker":
                marker = Path(ref["path"]).parent / "INCOMPLETE"
                marker.parent.mkdir()
                marker.touch()
            else:
                completed["build_manifest"] = descriptor(self.root / "other-build")
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                life.finalized_input(metadata, ref, value["build_manifest"])

    def full_completion(self):
        value, metadata, ref, completed, build = self.completion_fixture("PASS")
        evidence = {
            "schema": life.PREFIX + "generation-evidence.v1",
            "phase": "generation",
            "numerical_qualification": None,
            "models_loaded": 0,
            "search_calls": 0,
            "games_started": 0,
            "scientific_planned_slots": 512,
            "artifact": build["artifact"],
            "compiled_sources": build["compiled_sources"],
            "experiment": completed["experiment"],
            "config": value["config"],
            "inputs": value["inputs"],
            "schedule": value["schedule"],
            "rules": life.RULES,
            "limitation": "bound generation metadata; no numerical/model/history qualification",
        }
        output = self.root / "data"
        files = [
            descriptor(output / name, str(i + 1) * 64)
            for i, name in enumerate(
                ("generation-start.json", "book.json", "schedule.json", "generation-result.json")
            )
        ]
        completed["data"] = {"files": files, "errors": [], "generation": evidence}
        result = {
            "schema": "quoridor.value-search-strength.book.v1",
            "complete": True,
            "families": 128,
            "attempted": 130,
            "transitions": 1000,
            "book_sha256": files[1]["sha256"],
            "schedule_sha256": files[2]["sha256"],
            "models_loaded": 0,
            "search_calls": 0,
            "games_started": 0,
            "external_finalization": "PENDING; native receipt alone cannot admit campaign",
        }
        synthetic_schedule = [{"synthetic_slot": i} for i in range(512)]
        original_read = metadata.read.side_effect
        files = tuple(files)  # preserve bound read routing when declarations are mutated

        def read(file, *args):
            if file == files[3]:
                return result
            if file == files[1]:
                return {"compiled_sources": build["compiled_sources"]}
            if file in (files[2], value["schedule"]):
                return synthetic_schedule
            return original_read(file, *args)

        metadata.read.side_effect = read
        return value, metadata, ref, completed, build, result, synthetic_schedule

    def test_complete_descriptive_generation_uses_bound_evidence_not_numerical(self):
        value, metadata, ref, completed, build, _, schedule = self.full_completion()
        # This isolates authoritative/binding logic from the frozen real schedule digest.
        # The actual schedule helper is independently exercised below on synthetic arrays.
        with mock.patch.object(life, "generation_schedule") as join:
            actual, experiment = life.finalized_input(metadata, ref, value["build_manifest"])
            join.assert_called_once_with(
                schedule,
                schedule,
                "9bfb6135506f8d237f92d12d75de5e9131faaf5c8693f12f91f6a1698a487e1e",
            )
        self.assertIs(actual, completed)
        self.assertIsNone(life.numerical(metadata, experiment, build))
        self.assertEqual(actual["data"]["generation"]["scientific_planned_slots"], 512)

    def test_descriptive_binding_drift_refuses_before_native_payload_reads(self):
        import copy

        for field in (
            "artifact",
            "compiled_sources",
            "experiment",
            "config",
            "inputs",
            "schedule",
            "rules",
            "models_loaded",
            "search_calls",
            "games_started",
            "numerical_qualification",
        ):
            value, metadata, _, completed, _, _, _ = self.full_completion()
            evidence = copy.deepcopy(completed["data"]["generation"])
            if type(evidence[field]) is dict:
                if field == "compiled_sources":
                    evidence[field][next(iter(life.COMPILED_KEYS))] = "f" * 64
                else:
                    evidence[field]["sha256"] = "f" * 64
            elif type(evidence[field]) is list:
                evidence[field].reverse()
            elif evidence[field] is None:
                evidence[field] = descriptor(self.root / "numerical-PASS")
            elif type(evidence[field]) is int:
                evidence[field] = 1
            else:
                evidence[field] = "drift"
            completed["data"]["generation"] = evidence
            metadata.read.reset_mock()
            with self.subTest(field=field), self.assertRaises(ValueError):
                life.generation_evidence(metadata, completed, value)
            self.assertFalse(
                any(
                    call.args[0] in completed["data"]["files"]
                    for call in metadata.read.call_args_list
                )
            )

    def test_native_result_raw_hashes_cannot_be_replaced_with_other_schedule_domains(self):
        for digest in (
            "65a242a4ccec472a47a6aa0df806dd6dbf71a9e51bbdb27b550325765af5ebf3",
            "9bfb6135506f8d237f92d12d75de5e9131faaf5c8693f12f91f6a1698a487e1e",
        ):
            value, metadata, _, completed, _, result, _ = self.full_completion()
            result["schedule_sha256"] = digest
            with self.subTest(digest=digest), self.assertRaises(ValueError):
                life.generation_evidence(metadata, completed, value)

    def test_full_schedule_order_and_typed_values_are_preserved(self):
        import hashlib
        import json
        import copy

        schedule = [{"synthetic_slot": i, "flag": True} for i in range(512)]
        digest = hashlib.sha256(
            json.dumps(schedule, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()
        ).hexdigest()
        life.generation_schedule(copy.deepcopy(schedule), schedule, digest)
        for mutation in ("order", "missing", "bool", "wrong_semantic"):
            actual = copy.deepcopy(schedule)
            expected_digest = digest
            if mutation == "order":
                actual[0], actual[1] = actual[1], actual[0]
            elif mutation == "missing":
                actual.pop()
            elif mutation == "bool":
                actual[0]["flag"] = 1
            else:
                expected_digest = "f" * 64
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                life.generation_schedule(actual, schedule, expected_digest)

    def test_generation_partial_available_ledger_is_descriptive_only(self):
        value, metadata, _, completed, _, _, _ = self.full_completion()
        completed["status"] = "FAILED"
        completed["primary"] = {"type": "Synthetic", "message": "retain original"}
        completed["data"]["files"] = completed["data"]["files"][:2]
        actual = life.generation_evidence(metadata, completed, value)
        self.assertIs(actual, completed["data"]["generation"])
        del completed["data"]["generation"]
        self.assertIsNone(life.generation_evidence(metadata, completed, value))
        self.assertEqual(completed["status"], "FAILED")

    def test_completion_declarations_and_nested_types_fail_closed(self):
        import copy

        for mutation in (
            "order",
            "missing",
            "root",
            "journal",
            "bool_bytes",
            "data_error",
            "libraries",
        ):
            value, metadata, _, completed, _, _, _ = self.full_completion()
            if mutation == "order":
                completed["data"]["files"].reverse()
            elif mutation == "missing":
                completed["data"]["files"].pop()
            elif mutation == "root":
                completed["data"]["files"][0]["path"] = str(
                    self.root / "other" / "generation-start.json"
                )
            elif mutation == "journal":
                completed["data"]["files"][0]["path"] = str(self.root / "data" / "journal.jsonl")
            elif mutation == "bool_bytes":
                completed["data"]["generation"]["artifact"] = copy.deepcopy(
                    completed["data"]["generation"]["artifact"]
                )
                completed["data"]["generation"]["artifact"]["bytes"] = True
            elif mutation == "data_error":
                completed["data"]["errors"] = [{"message": "retained"}]
            else:
                value["dynamic_libraries"] = None
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                life.generation_evidence(metadata, completed, value)

    def test_missing_declaration_refuses_without_fixture_routing_loss(self):
        value, metadata, _, completed, _, _, _ = self.full_completion()
        completed["data"]["files"].pop()
        with self.assertRaises(ValueError):
            life.generation_evidence(metadata, completed, value)

    def test_declared_library_array_remains_required_for_completed_bootstrap(self):
        value, metadata, ref, completed, build, _, schedule = self.full_completion()
        library = {
            "file": descriptor(self.root / "declared-library"),
            "version": "synthetic version",
        }
        value["dynamic_libraries"] = [library]
        with mock.patch.object(life, "generation_schedule") as join:
            actual, experiment = life.finalized_input(metadata, ref, value["build_manifest"])
            join.assert_called_once_with(
                schedule,
                schedule,
                "9bfb6135506f8d237f92d12d75de5e9131faaf5c8693f12f91f6a1698a487e1e",
            )
        self.assertIs(actual, completed)
        self.assertIs(experiment["dynamic_libraries"][0], library)
        self.assertIsNone(life.numerical(metadata, experiment, build))
        library["version"] = ""
        with self.assertRaises(ValueError):
            life.generation_conditions(metadata, experiment, build)


class RelatedG1G2Guard(GenerationGuard):
    def test_actual_native_pending_marker_and_external_authority_are_distinct(self):
        value, metadata, ref, completed, _, result, schedule = self.full_completion()
        self.assertEqual(
            result["external_finalization"], "PENDING; native receipt alone cannot admit campaign"
        )
        with mock.patch.object(life, "generation_schedule") as join:
            actual, _ = life.finalized_input(metadata, ref, value["build_manifest"])
            join.assert_called_once_with(
                schedule,
                schedule,
                "9bfb6135506f8d237f92d12d75de5e9131faaf5c8693f12f91f6a1698a487e1e",
            )
        self.assertEqual(actual["status"], "PASS")
        for wrong in ("PENDING", "PENDING; native receipt alone cannot admit campaign ", "PASS"):
            result["external_finalization"] = wrong
            with self.subTest(marker=wrong), self.assertRaises(ValueError):
                life.generation_evidence(metadata, completed, value)

    def sparse_failed(self, cleanup):
        value, metadata, ref, completed, build, _, _ = self.full_completion()
        envelope = {
            "schema": "quoridor.research.generation-evidence.v1",
            "phase": "generation",
            "numerical_qualification": None,
            "scientific_planned_slots": 512,
        }
        completed["status"] = "FAILED"
        completed["cleanup_complete"] = cleanup
        completed["primary"] = {"type": "SyntheticNativeOutputMissing", "message": "original"}
        completed["secondary"] = [
            {"stage": "owed_finalizer", "type": "Synthetic", "message": "keep secondary"}
        ]
        completed["data"]["errors"] = [{"file": "generation-result.json", "message": "missing"}]
        completed["data"]["generation"] = envelope
        completed["data"]["files"] = completed["data"]["files"][:2]
        return value, metadata, ref, completed, build, envelope

    def test_parent_shaped_sparse_failed_envelope_retains_available_and_unknown_facts(self):
        for cleanup in (True, False):
            value, metadata, ref, completed, build, envelope = self.sparse_failed(cleanup)
            primary, secondary, files, errors = (
                completed["primary"],
                completed["secondary"],
                completed["data"]["files"],
                completed["data"]["errors"],
            )
            with self.subTest(cleanup=cleanup):
                actual, experiment = life.finalized_input(metadata, ref, value["build_manifest"])
                self.assertIs(actual, completed)
                self.assertIs(actual["primary"], primary)
                self.assertIs(actual["secondary"], secondary)
                self.assertIs(actual["data"]["files"], files)
                self.assertIs(actual["data"]["errors"], errors)
                self.assertIs(actual["cleanup_complete"], cleanup)
                self.assertEqual(actual["status"], "FAILED")
                self.assertIs(actual["data"]["generation"], envelope)
                self.assertEqual(
                    set(envelope),
                    {"schema", "phase", "numerical_qualification", "scientific_planned_slots"},
                )
                self.assertIsNone(life.numerical(metadata, experiment, build))
                self.assertFalse(
                    any(call.args[0] in files for call in metadata.read.call_args_list)
                )
                self.assertNotIn("models_loaded", envelope)
                self.assertNotIn("search_calls", envelope)
                self.assertNotIn("games_started", envelope)

    def test_sparse_available_bindings_validated_without_reading_native_outputs(self):
        value, metadata, _, completed, build, envelope = self.sparse_failed(True)
        envelope["artifact"] = dict(build["artifact"])
        self.assertIs(life.generation_evidence(metadata, completed, value), envelope)
        envelope["artifact"]["sha256"] = "f" * 64
        with self.assertRaises(ValueError):
            life.generation_evidence(metadata, completed, value)
        self.assertFalse(
            any(call.args[0] in completed["data"]["files"] for call in metadata.read.call_args_list)
        )

    def test_sparse_wrong_envelope_and_unowned_or_duplicate_refs_refuse(self):
        for mutation in (
            "phase",
            "schema",
            "numerical",
            "denominator",
            "missing",
            "counter_bool",
            "unowned",
            "duplicate",
            "unknown",
        ):
            value, metadata, _, completed, _, envelope = self.sparse_failed(False)
            if mutation == "phase":
                envelope["phase"] = "arena"
            elif mutation == "schema":
                envelope["schema"] = "quoridor.research.numerical-qualification.v1"
            elif mutation == "numerical":
                envelope["numerical_qualification"] = descriptor(self.root / "fake-PASS")
            elif mutation == "denominator":
                envelope["scientific_planned_slots"] = 0
            elif mutation == "missing":
                del envelope["scientific_planned_slots"]
            elif mutation == "counter_bool":
                envelope["models_loaded"] = False
            elif mutation == "unowned":
                completed["data"]["files"][0]["path"] = str(
                    self.root / "foreign" / "generation-start.json"
                )
            elif mutation == "duplicate":
                completed["data"]["files"].append(completed["data"]["files"][0])
            else:
                envelope["status"] = "PASS"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                life.generation_evidence(metadata, completed, value)

    def test_sparse_envelope_cannot_admit_pass_or_incomplete_completion(self):
        for mutation in ("PASS", "INCOMPLETE"):
            value, metadata, ref, completed, _, envelope = self.sparse_failed(True)
            if mutation == "PASS":
                completed["status"] = "PASS"
                completed["primary"] = None
                completed["secondary"] = []
                completed["data"]["errors"] = []
                with self.assertRaises((ValueError, KeyError)):
                    life.finalized_input(metadata, ref, value["build_manifest"])
            else:
                marker = Path(ref["path"]).parent / "INCOMPLETE"
                marker.parent.mkdir()
                marker.touch()
                with self.assertRaises(ValueError):
                    life.finalized_input(metadata, ref, value["build_manifest"])
            self.assertEqual(len(envelope), 4)
