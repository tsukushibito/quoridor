import hashlib, json, math
from pathlib import Path

R = Path("/workspaces/quoridor/.worktree/learning-million")
A = R / ".artifacts/public-full-learning"


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def put(p, v):
    Path(p).write_text(json.dumps(v, indent=2) + "\n")


old = json.loads((A / "caller-review-binding-r1.json").read_text())
paths = list(old["source_paths_SHA"]) + [
    str(R / "python/quoridor_training/qualification.py"),
    str(R / "crates/quoridor-runner/src/bin/nnue-diagnose.rs"),
    str(R / "crates/quoridor-runner/src/resources.rs"),
    str(R / "crates/quoridor-nnue/src/residual.rs"),
    str(R / "crates/quoridor-nnue/src/lib.rs"),
    str(R / "crates/quoridor-core/src/research.rs"),
]
source = {
    "schema": "quoridor-public-full-caller-source-r2",
    "source_paths_SHA": {p: sha(p) for p in paths},
    "previous_r1_binding_SHA": sha(A / "caller-review-binding-r1.json"),
    "normal_repairs": [
        "C1 supply-attempt/drawn names; no forward claim",
        "C2 CSV explicit kind/selection/scope/rows",
    ],
    "plan_SHA": sha(A / "convergence-plan-v1.json"),
    "NN0_log": str(A / "caller-NN0-r3.log"),
    "NN0_log_SHA": sha(A / "caller-NN0-r3.log"),
    "related_new_fixture": "current trainer null horizon natural scientific early stop, three named exports/PT/native byte binding, missing test labels, actual PNG; NOT_RUN until new job",
    "native_control": "Option null time/NN/processed; same model/math and CPU/memory admission; legacy finite callers remain active supported capability",
    "supply_question": "same fixed2048 original IDs+Bernoulli correctLR mask; two fixed-objective Adam updates CPU/CUDA, then one warmup+five production timing repetitions per128/512/2048; discarded optimization states, no candidate selected",
    "statistics_stop": str(A / "train-statistics-r1/stop-receipt.json"),
    "statistics_stop_SHA": sha(A / "train-statistics-r1/stop-receipt.json"),
    "finalSigma": "NOT_IMPLEMENTED/UNQUALIFIED; sealed E closed",
}
put(A / "caller-review-binding-r2.json", source)
from sys import path

path.insert(0, str(R / "python"))
from quoridor_training.common import resolve_config

cfg = {
    "model": {
        "architecture": "distance_residual",
        "transformer_width": 32,
        "hidden_width": 32,
        "dropout": 0,
        "distance_a": 0,
        "distance_b": 8,
    },
    "optimizer": {"name": "adam", "lr": 3e-5, "weight_decay": 0},
    "training": {
        "steps": None,
        "batch_size": 128,
        "seed": 32320261007,
        "target": "z",
        "sampling": "epoch",
        "loss_weighting": "row",
        "scheduler": "plateau",
        "warmup_steps": math.ceil(math.ceil(8413949 / 128) / 16),
        "lr_decay_factor": 0.5,
        "lr_decay_patience": 2,
        "min_lr": 1e-6,
        "reflection_probability": 0.5,
        "reflection_seed": 32320261008,
        "device": "cuda",
        "threads": 2,
    },
    "evaluation": {
        "batch_size": 2048,
        "monitor": "row",
        "early_stopping_patience": 8,
        "early_stopping_unit": "epoch",
        "min_delta": 1e-4,
        "diagnostic_rows": 8192,
        "diagnostic_interval": math.ceil(math.ceil(8413949 / 128) / 8),
        "full_train": False,
        "full_train_every_epochs": 5,
    },
    "limits": {"seconds": None, "samples": None},
    "artifacts": {"mode": "native", "save_scheduled": False, "checkpoint_steps": []},
    "data": {"overlap_policy": "report"},
}
preview = A / "supply-fit-preview-r1.json"
put(preview, cfg)
resolve_config(preview)
stop = json.loads((A / "train-statistics-r1/stop-receipt.json").read_text())
binding = {
    "role": "qualification preview only; actual candidate configs bound after supply batch selection before firstfit",
    "cache_manifest_sha": stop["result"]["cache_manifest_sha"],
    "scale_artifact": stop["scale_path"],
    "scale_artifact_sha": stop["result"]["scale_sha"],
    "constant_artifact": stop["constant_path"],
    "constant_artifact_sha": stop["result"]["constant_sha"],
    "fit_config_sha": sha(preview),
    "model_initial_seed": 32320261007,
    "plan_SHA": sha(A / "convergence-plan-v1.json"),
    "test_opened": False,
}
put(A / "supply-input-binding-r1.json", binding)
root = Path("/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/supply-r1")
root.mkdir(parents=True)
(root / "tmp").mkdir()
base = Path(
    "/workspaces/quoridor/.artifacts/research-coordination/full-learning-capacity/current-admitted-with-full-learning.json"
)
config = {
    "cache": "/workspaces/quoridor/.worktree/assets/inputs/public-full-learning/original-full-v1/recovery-r1/corpus",
    "fit_config": str(preview),
    "scale": stop["scale_path"],
    "input_binding": str(A / "supply-input-binding-r1.json"),
    "output": str(root / "output"),
    "seconds": None,
    "source_binding": str(A / "caller-review-binding-r2.json"),
    "source_binding_sha": sha(A / "caller-review-binding-r2.json"),
    "storage_admission": str(base),
    "storage_admission_sha": sha(base),
    "control_source_sha": {
        str(Path("/workspaces/quoridor") / p): sha(Path("/workspaces/quoridor") / p)
        for p in [
            "scripts/dev/research-job.py",
            "scripts/dev/research-job.sh",
            "scripts/dev/research-session.py",
            "research-data/ai-sigma/public-full-learning/recovery-storage-admission.json",
        ]
    },
    "native_binary": None,
    "native_binary_sha": None,
    "native_build_output": "/workspaces/quoridor/.artifacts/rust-migration/target/release/nnue-diagnose",
    "parallel_review_reserve_bytes": 512 * 1024**2,
    "max_forward_rows": None,
    "allocation_bytes": 1090519040,
    "local_peak_forecast_bytes": 8 * 1024**2,
    "build_source_forecast_bytes": 64 * 1024**2,
    "build_positive_growth_recorded": None,
    "build_growth_status": "NOT_RECORDED; reserved64MiB/no targetwalk",
    "scientific_control": "native finite fixture/qualification repetitions define question; time/forward/count resource limits null",
    "sealed_E_labels": "CLOSED",
}
put(A / "supply-config-r1.json", config)
job = {
    "issue": "quoridor-4lc.323",
    "goal_issue": "quoridor-4lc",
    "thread_id": "01a1100f-6d45-78e0-8a87-84503ff0fbf6",
    "cwd": str(R),
    "argv": [
        "/usr/bin/env",
        "CARGO_TARGET_DIR=/workspaces/quoridor/.artifacts/rust-migration/target",
        "CARGO_BUILD_JOBS=2",
        "OPENBLAS_NUM_THREADS=1",
        "OMP_NUM_THREADS=2",
        "MKL_NUM_THREADS=2",
        "NUMEXPR_NUM_THREADS=1",
        "PYTHONPATH=" + str(R / "python"),
        "TMPDIR=" + str(root / "tmp"),
        "QUORIDOR_PLOTS_PYTHON=/home/vscode/.cache/inference/envs/quoridor-learning-plots/bin/python",
        "/home/vscode/.cache/inference/envs/quoridor-training/bin/python",
        "-B",
        "-m",
        "quoridor_training.qualification",
        "--config",
        str(A / "supply-config-r1.json"),
        "--prepare-native",
    ],
    "end_at": None,
    "notify_until": None,
    "max_runtime_seconds": None,
    "control_interval_seconds": 3,
    "notify_interval_seconds": 5,
    "request_timeout_seconds": 25,
    "log_max_bytes": 131072,
    "resource_contract": "/workspaces/quoridor/research-data/ai-sigma/public-full-learning/task.md",
}
put(A / "supply-job-r1.json", job)
