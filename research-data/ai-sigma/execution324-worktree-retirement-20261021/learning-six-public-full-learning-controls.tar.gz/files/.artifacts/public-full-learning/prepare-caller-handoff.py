import hashlib, json, os
from pathlib import Path

R = Path("/workspaces/quoridor/.worktree/learning-million")
A = R / ".artifacts/public-full-learning"


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def put(p, v):
    Path(p).write_text(json.dumps(v, indent=2, ensure_ascii=False) + "\n")


plan = {
    "schema": "quoridor-public-full-convergence-plan-v1",
    "issue": "quoridor-4lc.323",
    "dataset_manifest_SHA": "07d81abc2230b2fe6b7c5fb7a425e7e3109bfaf2c467f5c72f8d3bdb975279b",
    "dataset_manifest_SHA_correction": "exact hash read from data STOP receipt below",
    "data": "all qualified original observations; T8413949/V419150/newE371978/opened50000 isolated",
    "primary": "full original validation rowMSE at step0 and each completed epoch",
    "candidate_LR": [3e-5, 1e-4, 3e-4],
    "batch_selection_before_fit": "qualify128/512/2048 same fixed inputs/initial weights/math, select lowest median end-to-end bounded supply+transfer+update time per row among finite numerically qualified VRAM-fitting batches; no linear LR scaling",
    "candidates": "each LR to scientific early stopping, same selected batch, model/initial seed/train order/reflection RNG/scale/optimizer/schedule",
    "model": "QF1+D residual FT32/H32 route4off dropout0 FP32 a0/b8 Adam wd0",
    "seeds": {
        "model_and_epoch_shuffle": 32320261007,
        "online_reflection": 32320261008,
        "diagnostic_subset": 32320261009,
    },
    "augmentation": {
        "train_probability": 0.5,
        "validation": "fixed original; no reflection RNG consumption",
        "saved_rows_added": 0,
        "independent_games": "UNKNOWN",
    },
    "schedule": {
        "warmup_steps": "ceil(ceil(T/batch)/16), fixed after supply qualification before first fit",
        "plateau_factor": 0.5,
        "plateau_patience_epoch_observations": 2,
        "absolute_min_delta": 1e-4,
        "min_lr": 1e-6,
    },
    "stop": {
        "scientific_patience_epochs": 8,
        "min_delta": 1e-4,
        "nonfinite": "stop and retain exact failed attempt",
        "epoch_limit": None,
        "wall_limit": None,
        "samples_limit": None,
        "MAXjobs": None,
    },
    "curve": {
        "selector": "step0 and each completed epoch fullV",
        "diagnostic": "0/1/2/5/10/20; every25 through2000; then ceil(ceil(T/batch)/8) updates plus completed epochs",
        "fixed_diag_rows_each_split": 8192,
        "fullT": "epoch1 and every5epochs",
        "CSV_JSON": "each observed point",
        "PNG_SVG": "0/20/100/500/1000/2000, selector epochs and final; recorded values only",
        "checkpoints": "INITIAL/BEST/LAST only",
    },
    "selection": "minimum recorded fullV rowMSE across LR candidates/checkpoints; exact ties lower LR then earlier update; early-stop min_delta does not redefine BEST",
    "evaluation": "newE labels closed until all candidate/config rules frozen; one chosen candidate,D,trainconstant,fixed Sigma value NN; no openedE reselection",
    "comparative_limit": "co-running software costs recorded; no fairness/speed or strength claim from training elapsed",
    "resources": {
        "CPU": [2, 3],
        "RAM_family": 4294967296,
        "VRAM": 6442450944,
        "inclusive_storage": 1090519040,
    },
    "pending": "actual supply numerical qualification, selected batch configs, live trainer proof, related independent caller review; finalSigma boundary separate",
}
receipt = json.loads((A / "data-recovery-r1-stop-receipt.json").read_text())
plan["dataset_manifest_SHA"] = receipt["cache_manifest_SHA"]
del plan["dataset_manifest_SHA_correction"]
put(A / "convergence-plan-v1.json", plan)
paths = [
    "train.py",
    "common.py",
    "sampling.py",
    "plotting.py",
    "test_observation.py",
    "test_public_sigma.py",
    "compact_cache.py",
    "public_features.py",
    "cache.py",
    "residual_model.py",
    "scaled_model.py",
    "cycle_process.py",
]
binding = {
    "schema": "quoridor-public-full-caller-review-v1",
    "purpose": "actual online reflection/validation/row selector/null convergence/train-only scale/named checkpoint/early curve caller; finalSigma and live GPU not qualified",
    "source_paths_SHA": {
        str(R / "python/quoridor_training" / p): sha(R / "python/quoridor_training" / p)
        for p in paths
    },
    "plan": str(A / "convergence-plan-v1.json"),
    "plan_SHA": sha(A / "convergence-plan-v1.json"),
    "NN0_log": str(A / "caller-NN0-r2.log"),
    "NN0_log_SHA": sha(A / "caller-NN0-r2.log"),
    "parent_input_acceptance": "/workspaces/quoridor/research-data/ai-sigma/public-full-learning/input-boundary-acceptance.json",
    "live_GPU_trainer": "NOT_RUN",
    "sealedE_labels": "CLOSED",
    "data_STOP_receipt": str(A / "data-recovery-r1-stop-receipt.json"),
    "data_STOP_SHA": sha(A / "data-recovery-r1-stop-receipt.json"),
}
put(A / "caller-review-binding-r1.json", binding)
