"""Prepare the explicitly selected 0.1 upper probe; incremental plan is historical."""

import copy
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

WT = Path("/workspaces/quoridor/.worktree/learning-million")
A = WT / ".artifacts/public-full-learning"
ROOT = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/lr-bracket-v1/lr0p1"
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def put(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + "\n")


historical = A / "higher-LR-cohort-v1.json"
prior_entry = load(A / "higher-lr1e-3-entry-v1.json")
assert not Path(prior_entry["runtime"]).exists()
assert not Path(prior_entry["output"]).exists()
source = A / "recording-source-binding-r6.json"
for path, expected in load(source)["source_paths_SHA"].items():
    assert sha(path) == expected, path
config = load(A / "fit-lr3e-4-config.json")
baseline = copy.deepcopy(config)
config["optimizer"]["lr"] = 0.1
checked = copy.deepcopy(config)
checked["optimizer"]["lr"] = baseline["optimizer"]["lr"]
assert checked == baseline
config_path = A / "bracket-lr0p1-config-v1.json"
put(config_path, config)
binding = load(A / "fit-lr3e-4-input-binding.json")
binding["role"] = "human-selected initial-LR bracket upper probe; same qualified INITIAL/protocol"
binding["fit_config_sha"] = sha(config_path)
binding_path = A / "bracket-lr0p1-input-binding-v1.json"
put(binding_path, binding)
plan = {
    "schema": "quoridor-initial-LR-log-bracket-v1",
    "at": datetime.now(timezone.utc).isoformat(),
    "authority": "explicit human: first deliberately extreme LR; log-space bracket refinement",
    "superseded_unexecuted_incremental_plan": str(historical),
    "superseded_plan_SHA": sha(historical),
    "incremental_plan_actual_fit_start": 0,
    "original_cohort": str(A / "locked-cohort-v1.json"),
    "original_cohort_SHA": sha(A / "locked-cohort-v1.json"),
    "original_candidate_outcomes": str(A / "fit-lr3e-4-stop-receipt-r3.json"),
    "original_candidate_outcomes_SHA": sha(A / "fit-lr3e-4-stop-receipt-r3.json"),
    "source_binding": str(source),
    "source_binding_SHA": sha(source),
    "incumbent": {"initial_LR": 0.0003, "recorded_fullV_rowMSE": 0.4486358587958654},
    "first_probe": {
        "initial_LR": 0.1,
        "config": str(config_path),
        "config_SHA": sha(config_path),
        "input_binding": str(binding_path),
        "input_binding_SHA": sha(binding_path),
    },
    "scientific_conditions": "only initial LR differs from original three; same warmup/plateau/earlystop/INITIAL/FP32/Adam/data/scale/batch2048/epoch/reflection RNG/original fullV",
    "primary_selection": "lowest recorded original fullV rowMSE among finite scientifically completed trajectories; exact tie lower initial LR then earlier update; preserve finite minima and failures of ineligible trajectories separately",
    "material_improvement": 0.0001,
    "stability": "finite loss/gradients/parameters through unchanged scientific early stop; finite transient spikes alone do not prove instability",
    "decision_rules": {
        "first_adverse": "if 0.1 is nonfinite or does not materially improve the incumbent, mark tested adverse upper and next probe sqrt(0.1*0.0003)",
        "first_midpoint_LR": math.sqrt(0.1 * 0.0003),
        "useful_upper": "if current highest probe is finite and materially improves incumbent, no upper boundary established; propose and bind a 10x larger upper probe before next run",
        "refinement": "geometric midpoint between useful incumbent and tested adverse upper; materially improving finite midpoint replaces incumbent, otherwise midpoint becomes tested adverse upper; retain all results without asserting excluded region cannot contain a better trajectory",
        "practical_precision_ratio": 2.0,
        "validation_refinement_patience": 3,
        "stop": "tested adverse/useful bracket ratio<=2, or three successive midpoint refinements fail to improve best fullV by1e-4; this is validation search patience, not a wall/epoch/forward/MAXjob cap",
        "operational_failure": "preserve and repair within scope; it does not establish nonfinite/stability or validation boundary",
        "nonmonotonicity": "LR-MSE monotonicity NOT_PROVEN; local log refinement is a practical search, not binary proof of global optimum or maximal stable LR",
        "scheduler_interpretation": "initial LR distinct from effective LR curve; recovery after decay does not prove constant high-LR safety",
        "before_each_next_entry": "bind exact config/input/source/decision and inclusive storage; no automatic cap multiplication or model/schedule rescue",
    },
    "time_epoch_sample_forward_MAXjob_horizons": None,
    "newE_Sigma_release": "HELD until expanded selection/global freeze/final related boundary",
    "all_previous_outcomes_failures_UNKNOWN_costs": "PRESERVED",
}
plan_path = A / "LR-bracket-plan-v1.json"
put(plan_path, plan)
guard = load(A / "fit-lr3e-4-guard-recording-r3.json")
old_output = Path(guard["output"]).parent
old_config, old_input = guard["fit_config"], guard["input_binding"]
guard.update(
    output=str(ROOT / "output"),
    fit_config=str(config_path),
    input_binding=str(binding_path),
    expanded_cohort=str(plan_path),
    expanded_cohort_SHA=sha(plan_path),
)
expected = guard["expected_files_sha256"]
del expected[old_config]
del expected[old_input]
for path in [config_path, binding_path, plan_path]:
    expected[str(path)] = sha(path)
for path, digest in expected.items():
    assert sha(path) == digest, path
guard_path = A / "bracket-lr0p1-guard-v1.json"
put(guard_path, guard)
job = load(A / "fit-lr3e-4-job-recording-r3.json")
job["argv"] = [
    item.replace(str(old_output), str(ROOT)).replace(
        str(A / "fit-lr3e-4-guard-recording-r3.json"), str(guard_path)
    )
    for item in job["argv"]
]
assert job["argv"][-1] == str(guard_path)
job_path = A / "bracket-lr0p1-job-v1.json"
put(job_path, job)
for directory in [ROOT / "tmp", ROOT / "mpl-cache"]:
    directory.mkdir(parents=True, exist_ok=False)
forecast = load(A / "higher-lr1e-3-local-forecast-v1.json")
forecast.update(
    admitted_next_candidate="lr0p1 ONLY; supersedes unexecuted lr1e-3 entry",
    prior_incremental_fit_start=0,
    candidate_output_guard=guard["resources"]["max_output_bytes"],
    next_output=str(ROOT / "output"),
    all_previous_assets_failures_preserved=True,
)
forecast_path = A / "bracket-lr0p1-local-forecast-v1.json"
put(forecast_path, forecast)
entry = {
    "id": "lr0p1",
    "initial_LR": 0.1,
    "output": str(ROOT / "output"),
    "forecast": str(forecast_path),
    "runtime": str(A / "bracket-lr0p1-runtime-v1"),
}
for key, path in [
    ("config", config_path),
    ("input_binding", binding_path),
    ("guard", guard_path),
    ("job", job_path),
    ("cohort", plan_path),
]:
    entry[key] = str(path)
    entry[key + "_SHA"] = sha(path)
put(A / "bracket-lr0p1-entry-v1.json", entry)
print(
    json.dumps(
        {
            "candidate": 0.1,
            "next_if_adverse": plan["decision_rules"]["first_midpoint_LR"],
            "evidence_peak": forecast["evidence_peak"],
            "evidence_margin": forecast["evidence_margin"],
            "source_changes": 0,
        }
    )
)
