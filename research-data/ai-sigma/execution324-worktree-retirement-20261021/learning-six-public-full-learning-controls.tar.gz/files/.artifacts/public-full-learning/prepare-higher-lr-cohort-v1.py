"""Bind LR-only continuation without rewriting the original cohort or outcomes."""

import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

WT = Path("/workspaces/quoridor/.worktree/learning-million")
EVIDENCE = WT / ".artifacts/public-full-learning"
ROOT = Path("/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/higher-lr-v1")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((EVIDENCE / name).read_text())


def put(path, value):
    path = Path(path)
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + "\n")


source = read("recording-source-binding-r6.json")
for path, expected in source["source_paths_SHA"].items():
    assert sha(path) == expected, path
original = EVIDENCE / "locked-cohort-v1.json"
assert sha(original) == "db5076c65798d68cce14924513e93ed1bd790b31ed57337206beed297a9f44cf"
template = read("fit-lr3e-4-config.json")
inputs = read("fit-lr3e-4-input-binding.json")
old_guard = read("fit-lr3e-4-guard-recording-r3.json")
old_job = read("fit-lr3e-4-job-recording-r3.json")
entries = []
for name, lr in [("lr1e-3", 1e-3), ("lr3e-3", 3e-3), ("lr1e-2", 1e-2)]:
    config = copy.deepcopy(template)
    config["optimizer"]["lr"] = lr
    restored = copy.deepcopy(config)
    restored["optimizer"]["lr"] = template["optimizer"]["lr"]
    assert restored == template
    config_path = EVIDENCE / f"higher-{name}-config-v1.json"
    put(config_path, config)
    binding = copy.deepcopy(inputs)
    binding["role"] = (
        "higher initial-LR continuation; same qualified INITIAL and scientific protocol"
    )
    binding["fit_config_sha"] = sha(config_path)
    binding_path = EVIDENCE / f"higher-{name}-input-binding-v1.json"
    put(binding_path, binding)
    entries.append(
        {
            "id": name,
            "LR": lr,
            "config": str(config_path),
            "config_SHA": sha(config_path),
            "input_binding": str(binding_path),
            "input_binding_SHA": sha(binding_path),
            "output": str(ROOT / name / "output"),
            "resource_admission": "one next entry only; subsequent outputs need inclusive local forecast",
        }
    )

plan = {
    "schema": "quoridor-higher-initial-LR-cohort-v1",
    "at": datetime.now(timezone.utc).isoformat(),
    "original_cohort": str(original),
    "original_cohort_SHA": sha(original),
    "source_binding": str(EVIDENCE / "recording-source-binding-r6.json"),
    "source_binding_SHA": sha(EVIDENCE / "recording-source-binding-r6.json"),
    "original_selection": "lr3e-4 .4486358587958654 provisional among original three only",
    "entries": entries,
    "only_scientific_config_difference": "initial Adam LR",
    "selection": "lowest recorded full original V rowMSE across scientifically completed finite candidates; exact tie lower initial LR then earlier update",
    "stability": "finite loss/gradients/parameters and scientific early stop; transient oscillations are retained and do not alone classify instability",
    "operational_failure": "preserve failure and costs; it does not establish an LR stability boundary",
    "expansion_rule": {
        "first": "1e-3",
        "then": "if 1e-3 completes finite/stable, run 3e-3, even if 1e-3 does not improve",
        "next": "if 3e-3 finite/stable and its recorded BEST improves the best lower-LR candidate by at least 1e-4, run 1e-2",
        "further": "same geometric 1/3 decade sequence, advancing only while newest candidate is finite/stable and improves the best lower-LR result by at least 1e-4; bind config and inclusive storage before each entry",
        "stop": "observed nonfinite instability or no material validation benefit under this protocol; no universal maximum or optimum claim",
        "benefit_threshold": 1e-4,
        "threshold_role": "expansion decision only; checkpoint BEST remains strict observed minimum",
    },
    "initial_weights_SHA": inputs["initial_weights_sha"],
    "cache_manifest_SHA": inputs["cache_manifest_sha"],
    "scale_SHA": inputs["scale_artifact_sha"],
    "constant_SHA": inputs["constant_artifact_sha"],
    "time_epoch_sample_forward_job_horizons": None,
    "newE_Sigma_release": "HELD until expanded comparison and global freeze plus final boundary",
    "historical_cohort_outputs_failures_costs": "PRESERVED; no resume/rewrite/reselection using test",
}
plan_path = EVIDENCE / "higher-LR-cohort-v1.json"
put(plan_path, plan)

entry = entries[0]
runroot = ROOT / entry["id"]
for directory in [runroot / "tmp", runroot / "mpl-cache"]:
    directory.mkdir(parents=True, exist_ok=False)
guard = copy.deepcopy(old_guard)
guard.update(
    output=entry["output"],
    fit_config=entry["config"],
    input_binding=entry["input_binding"],
    expanded_cohort=str(plan_path),
    expanded_cohort_SHA=sha(plan_path),
)
expected = guard["expected_files_sha256"]
del expected[old_guard["fit_config"]]
del expected[old_guard["input_binding"]]
expected[entry["config"]] = entry["config_SHA"]
expected[entry["input_binding"]] = entry["input_binding_SHA"]
expected[str(plan_path)] = sha(plan_path)
for path, digest in expected.items():
    assert sha(path) == digest, path
guard_path = EVIDENCE / "higher-lr1e-3-guard-v1.json"
put(guard_path, guard)
job = copy.deepcopy(old_job)
job["argv"] = [
    item.replace(str(Path(old_guard["output"]).parent), str(runroot))
    .replace(old_guard["output"], entry["output"])
    .replace(str(EVIDENCE / "fit-lr3e-4-guard-recording-r3.json"), str(guard_path))
    for item in old_job["argv"]
]
assert job["argv"][-1] == str(guard_path)
job_path = EVIDENCE / "higher-lr1e-3-job-v1.json"
put(job_path, job)

forecast = read("remaining-fixed-cohort-local-forecast-r6.json")
outputs = {
    "lr3e-5_failed_pipeline": 23226772,
    "lr1e-4_failed_zero_update_entry": 464793,
    "lr1e-4_completed": 7094613,
    "lr3e-4_completed": read("fit-lr3e-4-records-checkpoints-visits-r3.json")["output_bytes"],
}
old_bytes = sum(outputs.values())
new_guard = guard["resources"]["max_output_bytes"]
other_evidence = 17 * 1024**2
evidence_peak = old_bytes + new_guard + other_evidence
assert evidence_peak < forecast["evidence_upper_unchanged"]
assert forecast["all_scope_peak_upper"] < forecast["learning_inclusive"]
forecast.update(
    schema="higher-LR-next-entry-local-forecast-v1",
    actual_preserved_candidate_output_bytes=outputs,
    new_candidate_output_guard=new_guard,
    other_review_control_images_evidence_upper=other_evidence,
    evidence_peak=evidence_peak,
    evidence_margin=forecast["evidence_upper_unchanged"] - evidence_peak,
    admitted_next_candidate="lr1e-3 ONLY",
    subsequent_candidate_admission="recompute with actual new outputs; no multiplication of per-run cap",
    parent_overlay="/workspaces/quoridor/research-data/ai-sigma/search-optimization/storage-allocation-canonical-ordered-ft.json",
    new_raw_roots_or_coverage_changes=False,
    old_assets_deletion=0,
    full_or_target_scan=0,
)
put(EVIDENCE / "higher-lr1e-3-local-forecast-v1.json", forecast)
put(
    EVIDENCE / "higher-lr1e-3-entry-v1.json",
    {
        **entry,
        "cohort": str(plan_path),
        "cohort_SHA": sha(plan_path),
        "guard": str(guard_path),
        "guard_SHA": sha(guard_path),
        "job": str(job_path),
        "job_SHA": sha(job_path),
        "runtime": str(EVIDENCE / "higher-lr1e-3-runtime-v1"),
        "forecast": str(EVIDENCE / "higher-lr1e-3-local-forecast-v1.json"),
    },
)
print(
    json.dumps(
        {
            "next": entries[0],
            "evidence_peak": evidence_peak,
            "evidence_margin": forecast["evidence_margin"],
            "old_source_changes": 0,
        }
    )
)
