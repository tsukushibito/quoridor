import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path

R = Path("/workspaces/quoridor/.worktree/learning-million")
A = R / ".artifacts/public-full-learning"


def sha(p):
    h = hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda: f.read(1048576), b""):
            h.update(b)
    return h.hexdigest()


def put(p, v):
    Path(p).write_text(json.dumps(v, indent=2) + "\n")


base = Path(
    "/workspaces/quoridor/.artifacts/research-coordination/full-learning-capacity/current-admitted-with-full-learning.json"
)
assert sha(base) == "887d2d14f1657a0baf3f455f99843f4de5c87abbd7f45c11d832215344c122d9"
b = json.loads(base.read_text())
assert b["admission"] == "within" and not b["errors"]
allocation = Path(
    "/workspaces/quoridor/research-data/ai-sigma/public-full-learning/recovery-storage-admission.json"
)
assert sha(allocation) == "77d00d10e9caaca12ac2b2b24407fa0ae1cfee730a6bf40618d2018ada2916f5"
peer = Path(
    "/workspaces/quoridor/.worktree/search-optimization/.artifacts/search-optimization/map-storage-r2/stop-receipt.json"
)
p = json.loads(peer.read_text())
# The actual packet plus persisted finished controller are complementary; exact parent stop fields retained below.
runtime = peer.parent / "runtime/result.json"
actual = json.loads(runtime.read_text())
assert actual["exit_code"] == 0 and actual["cleanup_complete"] and actual["remaining"] == []
stop = json.loads((A / "data-recovery-r1-stop-receipt.json").read_text())
cache = Path(stop["cache_path"])
assert sha(cache / "cache.json") == stop["cache_manifest_SHA"]
assert (
    stop["controller"]["cleanup_complete"]
    and stop["guardian"]["direct_child_reaped"]
    and stop["guardian"]["remaining"] == []
)
physics = []
for entry in Path("/proc").iterdir():
    if not entry.name.isdigit():
        continue
    try:
        name = (entry / "comm").read_text().strip()
        if name in {
            "cargo",
            "rustc",
            "clippy-driver",
            "cc1",
            "ld",
            "nnue-diagnose",
            "quoridor-runner",
        }:
            physics.append({"pid": int(entry.name), "comm": name})
    except FileNotFoundError:
        pass
assert not physics, physics
available = next(
    int(line.split()[1]) * 1024
    for line in Path("/proc/meminfo").read_text().splitlines()
    if line.startswith("MemAvailable:")
)
assert available > 8 * 1024**3
root = A / "train-statistics-r1"
root.mkdir()
checks = {
    str(path): sha(path)
    for path in [
        base,
        allocation,
        cache / "cache.json",
        A / "convergence-plan-v1.json",
        A / "caller-review-binding-r1.json",
        R / "python/quoridor_training/train.py",
        R / "python/quoridor_training/cycle_process.py",
        R / "python/quoridor_training/compact_cache.py",
        R / "python/quoridor_training/public_features.py",
        R / "python/quoridor_training/cache.py",
        Path("/workspaces/quoridor/scripts/dev/research-job.py"),
        Path("/workspaces/quoridor/scripts/dev/research-session.py"),
    ]
}
config = {
    "output": str(root / "statistics"),
    "cache": str(cache),
    "expected_files_sha256": checks,
    "storage_admission": str(base),
    "resources": {
        "max_memory_bytes": 3 * 1024**3,
        "host_ram_reserve": 4 * 1024**3,
        "max_output_bytes": 1048576,
    },
    "CPU": [2, 3],
    "GPU": 0,
    "time_limit": None,
    "forward_limit": None,
    "controller_reserve_bytes": 64 * 1024**2,
    "reviewer_parallel_reserve_bytes": 512 * 1024**2,
}
put(A / "train-statistics-config-r1.json", config)
job = {
    "issue": "quoridor-4lc.323",
    "goal_issue": "quoridor-4lc",
    "thread_id": "01a1100f-6d45-78e0-8a87-84503ff0fbf6",
    "cwd": str(R),
    "argv": [
        "/usr/bin/env",
        "OPENBLAS_NUM_THREADS=1",
        "OMP_NUM_THREADS=1",
        "MKL_NUM_THREADS=1",
        "NUMEXPR_NUM_THREADS=1",
        "CUDA_VISIBLE_DEVICES=",
        "PYTHONPATH=" + str(R / "python"),
        "/home/vscode/.cache/inference/envs/quoridor-training/bin/python",
        "-B",
        "-m",
        "quoridor_training.train",
        "statistics",
        "--cache",
        str(cache),
        "--output",
        str(root / "statistics"),
        "--guard-config",
        str(A / "train-statistics-config-r1.json"),
    ],
    "end_at": None,
    "notify_until": None,
    "max_runtime_seconds": None,
    "control_interval_seconds": 3,
    "notify_interval_seconds": 5,
    "request_timeout_seconds": 25,
    "log_max_bytes": 131072,
    "resource_contract": "/workspaces/quoridor/research-data/ai-sigma/public-full-learning/task.md",
}
put(A / "train-statistics-job-r1.json", job)
put(
    root / "prelaunch.json",
    {
        "at": datetime.now(timezone.utc).isoformat(),
        "capacity_reused_SHA": sha(base),
        "recovery_allocation_SHA": sha(allocation),
        "inclusive_storage": 1090519040,
        "fullscan": False,
        "new_output_forecast_bytes": 1048576,
        "output_in_evidence80MiB": True,
        "heavy_scratch": "no NPZ/temp full prediction needed; old partial preserved",
        "peer_actualSTOP": actual["finished_at"],
        "peer_result_SHA": sha(runtime),
        "foreign_science_compiler": physics,
        "MemAvailable": available,
        "affinity_available": sorted(os.sched_getaffinity(0)),
        "source_checks": checks,
        "sealed_E_labels": "CLOSED",
        "model_forward": 0,
        "time_caps": None,
    },
)
print(
    json.dumps(
        {
            "prepared": True,
            "peer_STOP": actual["finished_at"],
            "MemAvailable": available,
            "new_output_forecast_bytes": 1048576,
        }
    )
)
