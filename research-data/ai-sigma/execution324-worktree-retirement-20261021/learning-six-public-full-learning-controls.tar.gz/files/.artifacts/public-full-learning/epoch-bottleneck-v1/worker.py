"""Two discarded actual epochs with existing guardian, no candidate release."""

import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import (
    GPUResources,
    cancellation_signals,
    execute,
    alive,
)


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class TelemetryResources(GPUResources):
    class Utilization(ctypes.Structure):
        _fields_ = [("gpu", ctypes.c_uint), ("memory", ctypes.c_uint)]

    def __init__(self, config, output):
        super().__init__(config, output, None)
        self.device.library.nvmlDeviceGetUtilizationRates.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(self.Utilization),
        ]
        self.samples = []
        self.phase = "setup"
        self.telemetry_cpu = 0.0

    def check(self, owned=()):
        super().check(owned)
        tick = time.process_time()
        sample = {
            "monotonic": time.monotonic(),
            "phase": self.phase,
            "owned": [],
            "whole_device_memory_bytes": self.device.used(),
        }
        util = self.Utilization()
        code = self.device.library.nvmlDeviceGetUtilizationRates(
            self.device.handle, ctypes.byref(util)
        )
        sample["whole_device_GPU_percent"] = int(util.gpu) if code == 0 else None
        sample["whole_device_memory_utilization_percent"] = int(util.memory) if code == 0 else None
        sample["NVML_code"] = code
        for member in owned:
            path = Path(f"/proc/{member['pid']}/stat")
            try:
                fields = path.read_text().rsplit(")", 1)[1].split()
            except FileNotFoundError:
                continue
            sample["owned"].append(
                {
                    "identity": member,
                    "CPU_ticks": int(fields[11]) + int(fields[12]),
                    "ticks_per_second": os.sysconf("SC_CLK_TCK"),
                }
            )
        self.samples.append(sample)
        self.telemetry_cpu += time.process_time() - tick


def main():
    config = json.loads(Path(sys.argv[1]).read_text())
    os.sched_setaffinity(0, {2, 3})
    for path, digest in config["expected_files_sha256"].items():
        if sha(path) != digest:
            raise ValueError("source/input/control mismatch: " + path)
    admission = json.loads(Path(config["storage_admission"]).read_text())
    if admission["admission"] != "within" or admission["errors"]:
        raise ValueError("completed capacity binding")
    root = Path(config["root"])
    root.mkdir(parents=True, exist_ok=False)
    (root / "tmp").mkdir()
    (root / "mpl-cache").mkdir()
    started = time.monotonic()
    resources = TelemetryResources(config["resources"], root)
    result = {"candidate_adoption": False, "newE_opened": False, "phases": []}
    try:
        with cancellation_signals():
            for phase, observer_config in config["phases"]:
                resources.phase = phase
                mark = time.monotonic()
                command = [
                    sys.executable,
                    "-B",
                    "-m",
                    "quoridor_training.epoch_measurement",
                    "--config",
                    observer_config,
                ]
                execute(command, root / (phase + ".log"), None, resources=resources)
                process = json.loads((root / (phase + ".process.json")).read_text())
                if (
                    not process["direct_child_reaped"]
                    or not process["cleanup_complete"]
                    or process["remaining"]
                    or alive(process["child"])
                ):
                    raise ValueError("exact phase cleanup")
                result["phases"].append(
                    {
                        "phase": phase,
                        "whole_child_control_seconds": time.monotonic() - mark,
                        "process": process,
                    }
                )
    finally:
        result.update(
            finished_at=datetime.now(timezone.utc).isoformat(),
            whole_worker_seconds=time.monotonic() - started,
            observed_resources=resources.observed,
            controller_reserve_bytes=resources.controller_reserve,
            telemetry=resources.samples,
            telemetry_extra_guardian_CPU_seconds=resources.telemetry_cpu,
            scope="sampled NVML whole-device, not process-exclusive utilization or absolute peak",
        )
        write(root / "worker-result.json", result)
    print(json.dumps({"status": "two discarded epochs completed", "candidate_adoption": False}))


if __name__ == "__main__":
    main()
