"""Saved small JSON only: no model, tensor arrays, plot, profiler or new run."""

import gzip
import hashlib
import json
from pathlib import Path
import tarfile


A = Path(__file__).resolve().parent
R = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/epoch-bottleneck-v1"
)
WT = Path("/workspaces/quoridor/.worktree/learning-million")


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


plain = load(R / "plain/output/epoch-measurement.json")
detail = load(R / "detailed/output/epoch-measurement.json")
worker = load(R / "worker-result.json")
rows = []
for mode in ("plain", "detailed"):
    output = R / mode / "output"
    sampling = load(output / "sampling.json")
    with gzip.open(output / "curves.jsonl.gz", "rt") as stream:
        curves = [json.loads(line) for line in stream]
    assert sampling["training_row_min_visits"] == sampling["training_row_max_visits"] == 1
    assert sampling["seen"] == sampling["sampler_advanced_seen"] == 8413949
    assert sampling["reflection"]["reflected_drawn_original_rows"] == 4209397
    assert curves[-1]["validation"]["target_mse"] == 0.4655768743122415
    assert not (output / "freeze.json").exists()
    rows.append({"mode": mode, "sampling": sampling, "full_selector_curves": curves})
assert (
    rows[0]["full_selector_curves"][-1]["validation"]
    == rows[1]["full_selector_curves"][-1]["validation"]
)

spans = detail["nested_spans"]
top_names = [
    "epoch_sampling_shuffle_index",
    "index_attempted_visit_accounting",
    "zero_grad",
    "CPU_supply",
    "H2D_features_distance_side",
    "explicit_CUDA_synchronize_wait",
    "GPU_training_forward",
    "loss_target_H2D_and_finite_check",
    "GPU_backward",
    "finite_gradient_check",
    "GPU_Adam_step",
    "finite_parameter_check",
    "index_successful_visit_accounting",
]
loop = detail["lifecycle_disjoint_wall_seconds"]["training_loop"]
table = [
    {
        "phase": name,
        "wall_seconds": spans["training_loop/" + name]["inclusive_wall_seconds"],
        "fraction_detailed_loop": spans["training_loop/" + name]["inclusive_wall_seconds"] / loop,
    }
    for name in top_names
]
table.append(
    {
        "phase": "unattributed_rest_including_instrumentation",
        "wall_seconds": loop - sum(r["wall_seconds"] for r in table),
    }
)
assert table[-1]["wall_seconds"] >= 0
profiler = detail["profiler_key_averages"]
CPU_names = {e["key"] for e in profiler if "CPU" in e["device_type"]}
activities = [e for e in profiler if "CUDA" in e["device_type"] and e["key"] not in CPU_names]
synthetic = [e for e in profiler if "CUDA" in e["device_type"] and e["key"] in CPU_names]
device_ms = sum(e["self_device_us"] for e in activities) / 1000
H2D_ms = sum(e["self_device_us"] for e in activities if e["key"].startswith("Memcpy HtoD")) / 1000
CUDA = {
    "window_training_updates": 16,
    "coincident_fixed_diagnostic_prediction_batches": 8,
    "physical_kernel_memcpy_memset_rows": len(activities),
    "summed_activity_ms": device_ms,
    "H2D_activity_ms": H2D_ms,
    "H2D_fraction_of_summed_activity": H2D_ms / device_ms,
    "physical_activities": activities,
    "excluded_synthetic_CPU_range_device_rows": synthetic,
    "rule": "Exclude duplicated CUDA user/operator range names also present in CPU rows; sum physical activities only, never ranges plus kernels.",
    "active_device_utilization_of_window": "UNKNOWN: window wall not separately recorded; activities can overlap",
    "backward_pure_kernel_ms": "NOT_SEPARATELY_ATTRIBUTABLE from retained key averages; stream elapsed recorded separately",
    "instrumented_device_time_not_whole_epoch_extrapolation": True,
}
NVML = {}
for mode in ("plain", "detailed"):
    samples = [
        s
        for s in worker["telemetry"]
        if s["phase"] == mode and s["whole_device_GPU_percent"] is not None
    ]
    duration = sum(y["monotonic"] - x["monotonic"] for x, y in zip(samples, samples[1:]))
    NVML[mode] = {
        "samples": len(samples),
        "time_weighted_whole_device_GPU_percent": sum(
            x["whole_device_GPU_percent"] * (y["monotonic"] - x["monotonic"])
            for x, y in zip(samples, samples[1:])
        )
        / duration,
        "max_sample_whole_device_GPU_percent": max(s["whole_device_GPU_percent"] for s in samples),
        "scope": "whole child lifecycle; includes initialization/evaluation/PNG. Whole device not learner-exclusive; rolling samples not instantaneous kernels.",
    }
files = {
    str(p.relative_to(R)): {"bytes": p.stat().st_size, "SHA256": sha(p)}
    for p in R.rglob("*")
    if p.is_file()
}
control = load(A / "control.json")
for path, digest in control["expected_files_sha256"].items():
    assert sha(path) == digest, path
source = [
    WT / "python/quoridor_training" / name
    for name in ["train.py", "epoch_measurement.py", "test_epoch_measurement.py"]
]
with tarfile.open(A / "stopped-source.tar.gz", "w:gz") as archive:
    for path in source:
        archive.add(path, arcname=str(path.relative_to(WT)))
result = {
    "scope": "measurement only: no new candidate, test or optimization",
    "same_actual_entry": "initialLR.01/factor.5/patience1; null scientific horizon; FT32/H32/FP32/Adam/batch2048/full original T/V/same INITIAL/seeds/50%correctLR",
    "plain": plain,
    "detailed": detail,
    "training_loop_nonoverlapping_top_level_table": table,
    "CUDA_representative_activity": CUDA,
    "NVML": NVML,
    "CPU_plain_loop_core_equivalents": plain["lifecycle_process_CPU_seconds"]["training_loop"]
    / plain["lifecycle_disjoint_wall_seconds"]["training_loop"],
    "plain_epoch_training_diagnostics_boundary_seconds": sum(
        plain["lifecycle_disjoint_wall_seconds"][k]
        for k in ["training_loop", "fixed_diagnostic", "epoch_boundary"]
    ),
    "overhead_whole_train_call_seconds": detail["whole_train_call_seconds"]
    - plain["whole_train_call_seconds"],
    "overhead_whole_train_call_fraction": detail["whole_train_call_seconds"]
    / plain["whole_train_call_seconds"]
    - 1,
    "overhead_loop_fraction": loop / plain["lifecycle_disjoint_wall_seconds"]["training_loop"] - 1,
    "overhead_limit": "One fixed-order pair; instrumentation and uncontrolled cache/clock variation not statistically separated. Plain has lifecycle hooks/unchanged guards but no detailed spans/CUDA events/profiler.",
    "actual_sampling_curve_checks": rows,
    "diagnostic_output_files": files,
    "owned_root_actual_bytes": sum(x["bytes"] for x in files.values()),
    "forecast": load(A / "forecast.json"),
    "stopped_source": {str(p): sha(p) for p in source},
    "stopped_source_archive_SHA": sha(A / "stopped-source.tar.gz"),
    "source_binding_at_collection": "PASS; runtime used mutable future root manifest does not invalidate saved entry",
    "stop_receipt": str(A / "stop-receipt.json"),
    "parent323_pause": "retained; native/globalfreeze/newE/Sigma not run",
}
(A / "analysis.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(
    json.dumps(
        {
            "same_rows_curves_weights": "PASS",
            "plain_loop": plain["lifecycle_disjoint_wall_seconds"]["training_loop"],
            "H2D_caller": spans["training_loop/H2D_features_distance_side"][
                "inclusive_wall_seconds"
            ],
            "CPU_expand": spans["training_loop/CPU_geometry_to_QF1"]["inclusive_wall_seconds"],
            "whole_cost": load(A / "runtime/result.json")["wall_seconds"],
            "root_actual_bytes": result["owned_root_actual_bytes"],
        }
    )
)
