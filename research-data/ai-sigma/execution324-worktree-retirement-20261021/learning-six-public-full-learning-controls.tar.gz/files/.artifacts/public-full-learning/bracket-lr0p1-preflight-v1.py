"""Small fixed-entry checks; no corpus, shared-target, or historical inventory."""

import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

WT = Path("/workspaces/quoridor/.worktree/learning-million")
A = WT / ".artifacts/public-full-learning"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


entry = load(A / "bracket-lr0p1-entry-v1.json")
assert Path.cwd() == WT
os.sched_setaffinity(0, {2, 3})
guard = load(entry["guard"])
for path, expected in guard["expected_files_sha256"].items():
    assert sha(path) == expected, path
for key in ["config", "input_binding", "guard", "job", "cohort"]:
    assert sha(entry[key]) == entry[key + "_SHA"], key
job = load(entry["job"])
assert all(job[k] is None for k in ["end_at", "notify_until", "max_runtime_seconds"])
config = load(entry["config"])
assert config["training"]["steps"] is None
assert config["limits"] == {"seconds": None, "samples": None}
baseline = load(A / "fit-lr3e-4-config.json")
comparison = load(entry["config"])
comparison["optimizer"]["lr"] = baseline["optimizer"]["lr"]
assert comparison == baseline
inputs = load(entry["input_binding"])
cache_manifest = Path(guard["cache"]) / "cache.json"
assert sha(cache_manifest) == inputs["cache_manifest_sha"]
initial = Path(inputs["qualified_initial_native_manifest"])
initial_manifest = load(initial)
weights = initial.parent / initial_manifest["weights"]
assert sha(weights) == inputs["initial_weights_sha"]
base = load(guard["storage_admission"])
assert base["admission"] == "within" and not base["errors"]
assert (
    sha(guard["storage_admission"])
    == "887d2d14f1657a0baf3f455f99843f4de5c87abbd7f45c11d832215344c122d9"
)
overlay_path = Path(
    "/workspaces/quoridor/research-data/ai-sigma/search-optimization/storage-allocation-canonical-ordered-ft.json"
)
overlay = load(overlay_path)
root_manifest = Path(
    "/workspaces/quoridor/.artifacts/task-session-permissions/native-completion-root-manifest.json"
)
assert sha(root_manifest) == overlay["root_manifest_after_sha256"]
assert overlay["parent_after"] < overlay["parent_cap"]
assert overlay["unknown_retained"] == 134217728
forecast = load(entry["forecast"])
assert forecast["evidence_peak"] < forecast["evidence_upper_unchanged"]
assert forecast["all_scope_peak_upper"] < forecast["learning_inclusive"] == 1090519040
assert not Path(entry["runtime"]).exists()
assert not Path(entry["output"]).exists()

peer = Path(
    "/workspaces/quoridor/.worktree/search-optimization/.artifacts/search-optimization/ordered-ft-canonical-v1/numeric-runtime/result.json"
)
peer_result = load(peer)
assert peer_result["cleanup_complete"] and peer_result["remaining"] == []
own_result = load(A / "fit-lr3e-4-runtime-recording-r3/result.json")
assert own_result["cleanup_complete"] and own_result["remaining"] == []
stop = load(A / "fit-lr3e-4-stop-receipt-r3.json")
for check in stop["identity_checks"].values():
    identity = check["identity"]
    stat_path = Path(f"/proc/{identity['pid']}/stat")
    if stat_path.exists():
        ticks = stat_path.read_text().rsplit(")", 1)[1].split()[19]
        assert ticks != identity["start_ticks"], identity

foreign = []
for path in Path("/proc").iterdir():
    if not path.name.isdigit() or int(path.name) == os.getpid():
        continue
    try:
        comm = (path / "comm").read_text().strip()
        cmd = (path / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        continue
    if comm in {"cargo", "rustc", "clippy-driver", "nnue-diagnose", "quoridor-runner"} or (
        comm.startswith("python")
        and any(
            module in cmd
            for module in [
                "-m quoridor_training.train",
                "-m quoridor_training.qualification",
                "quoridor_training.public_sigma",
            ]
        )
    ):
        foreign.append({"pid": int(path.name), "comm": comm, "cmd": cmd[:400]})
assert foreign == [], foreign
mem = {
    line.split(":")[0]: line.split(":")[1].strip()
    for line in Path("/proc/meminfo").read_text().splitlines()
}
available = int(mem["MemAvailable"].split()[0]) * 1024
assert available > 8 * 1024**3
query = subprocess.run(
    ["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"],
    check=True,
    capture_output=True,
    text=True,
)
used = int(query.stdout.strip()) * 1024**2
assert used < 2 * 1024**3
value = {
    "at": datetime.now(timezone.utc).isoformat(),
    "entry": entry,
    "permissions": {
        "sandbox": "danger-full-access",
        "approvalPolicy": "never",
        "source": "active explicit developer permission profile",
    },
    "actual_cwd": str(Path.cwd()),
    "affinity": sorted(os.sched_getaffinity(0)),
    "source_config_initial_cache_scale_binding": "PASS",
    "old_cohort_and_all_outputs_preserved": True,
    "peer_last_exactSTOP": peer_result,
    "peer_current_reservation": "latest direct318: no job/no numerical reservation/source-only",
    "foreign_science_compilers_observed": foreign,
    "available_memory": available,
    "device_used": used,
    "local_forecast": forecast,
    "parent_overlay": str(overlay_path),
    "parent_overlay_SHA": sha(overlay_path),
    "root_manifest_SHA": sha(root_manifest),
    "full_or_sharedtarget_walk": False,
    "newE": "CLOSED",
}
target = A / "bracket-lr0p1-prelaunch-v1.json"
assert not target.exists()
target.write_text(json.dumps(value, indent=2) + "\n")
print(
    json.dumps(
        {
            "entry_checks": "PASS",
            "available_memory": available,
            "device_used": used,
            "evidence_margin": forecast["evidence_margin"],
        }
    )
)
