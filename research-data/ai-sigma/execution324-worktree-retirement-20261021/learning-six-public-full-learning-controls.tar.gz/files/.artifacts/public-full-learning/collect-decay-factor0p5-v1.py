"""Read saved artifacts only; no model construction, forward, or cache labels."""

import gzip
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from quoridor_training.sampling import EarlyStopping
from quoridor_training.train import verify_native_parameters

WORK = Path("/workspaces/quoridor/.worktree/learning-million")
ART = WORK / ".artifacts/public-full-learning"
ROOT = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/decay-pair-v1/factor0p5"
)
OUT = ROOT / "output"


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def finite_tree(obj):
    if isinstance(obj, torch.Tensor):
        return bool(torch.isfinite(obj).all())
    if isinstance(obj, dict):
        return all(finite_tree(v) for v in obj.values())
    if isinstance(obj, (list, tuple)):
        return all(finite_tree(v) for v in obj)
    return True


receipt = read(ART / "decay-factor0p5-stop-receipt-v1.json")
status = read(OUT / "run-status.json")
config = read(OUT / "config.json")
freeze = read(OUT / "freeze.json")
protocol = read(ART / "decay-pair-protocol-v1.json")
with gzip.open(OUT / "curves.jsonl.gz", "rt") as stream:
    points = [json.loads(line) for line in stream]
best = min(points, key=lambda p: p["validation"]["target_mse"])
assert len(points) == status["completed_epochs"] + 1
stopper = EarlyStopping(
    config["evaluation"]["early_stopping_patience"], config["evaluation"]["min_delta"]
)
trace = []
crossings = {}
thresholds = [*protocol["fixed_absolute_targets"], protocol["fixed_near_reference_target"]]
for epoch, point in enumerate(points):
    assert point["completed_epochs"] == epoch
    assert point["step"] == 4109 * epoch
    assert point["training_seen"] == 8413949 * epoch
    assert point["validation"]["rows"] == 419150
    loss = point["validation"]["target_mse"]
    significant_improvement, stopping = stopper.observe(loss)
    trace.append(
        {"epoch": epoch, "V": loss, "lr": point["lr"], "stop": stopping, "stale": stopper.stale}
    )
    assert stopping == (epoch == status["completed_epochs"])
    for target in thresholds:
        if str(target) not in crossings and loss <= target:
            crossings[str(target)] = {
                k: point[k]
                for k in ("completed_epochs", "step", "training_seen", "wall_seconds", "lr")
            }
for target in thresholds:
    crossings.setdefault(str(target), None)

checkpoints = {}
for name in ("initial", "best", "last"):
    pt = OUT / (name + ".pt")
    cp = torch.load(pt, map_location="cpu", weights_only=True)
    assert cp["position"] == status["checkpoint_positions"][name]
    assert cp["dataset_sha"] == freeze["dataset_sha"]
    assert cp["model_config"] == config["model"]
    assert cp["scale"] == read(OUT / "scale.json")
    assert finite_tree(cp["model"]) and finite_tree(cp["optimizer"])
    verify_native_parameters(OUT / (name + "-model/weights.f32"), cp["model"])
    adam_steps = sorted({int(v["step"]) for v in cp["optimizer"]["state"].values()})
    assert adam_steps == ([cp["position"]["step"]] if name != "initial" else [])
    checkpoints[name] = {
        "position": cp["position"],
        "PT_SHA": digest(pt),
        "weights_SHA": digest(OUT / (name + "-model/weights.f32")),
        "finite_model_Adam": True,
        "native_ordered_bytes_exact": True,
        "Adam_steps": adam_steps,
    }

with np.load(OUT / "sampling-counts.npz", allow_pickle=False) as counts:
    print("NPZ keys", counts.files)
    visits = counts["row_counts"]
    attempted = counts["attempted_row_counts"]
    assert visits.dtype == np.int64 and np.array_equal(visits, attempted)
    assert np.all(visits[:8413949] == 62) and np.all(visits[8413949:] == 0)
    assert int(visits.sum()) == status["training_seen"]
    visit_receipt = {
        "dtype": str(visits.dtype),
        "Trows": 8413949,
        "per_Trow": 62,
        "Voptimizer_visits": 0,
        "sum": int(visits.sum()),
        "attempted_equal_completed": True,
        "NPZ_SHA": digest(OUT / "sampling-counts.npz"),
    }

for name, expected in freeze["artifacts_sha256"].items():
    assert digest(OUT / name) == expected, name
entry = read(ART / "decay-factor0p5-entry-admitted-v2.json")
for name in ("config", "input_binding", "guard", "job", "cohort"):
    assert digest(Path(entry[name])) == entry[name + "_SHA"]
binding = read(ART / "recording-source-binding-r6.json")
for source, expected in binding["source_paths_SHA"].items():
    assert digest(Path(source)) == expected, source

files = [p for p in ROOT.rglob("*") if p.is_file()]
root_bytes = sum(p.stat().st_size for p in files)
receipt.update(
    {
        "BEST_position": status["checkpoint_positions"]["best"],
        "effective_BEST_LR_after_selector": best["lr"],
        "finite_scientific_stop_trace": trace,
        "checkpoint_metadata_checks": checkpoints,
        "actual_visit_arrays": visit_receipt,
        "original_fullV_crossings": crossings,
        "speed_target_reached": crossings[str(protocol["fixed_near_reference_target"])] is not None,
        "selector_points": len(points),
        "diagnostic_points": sum(1 for _ in gzip.open(OUT / "diagnostic-curves.jsonl.gz", "rt")),
        "freeze_all_artifact_SHA": "PASS",
        "global_final_freeze": "NOT_RELEASED",
        "trained_native_live_parity": "NOT_RUN",
        "collection_model_forward": 0,
        "collection_GPU": 0,
        "owned_run_root_bytes": root_bytes,
        "files_SHA": {str(p.relative_to(ROOT)): digest(p) for p in files},
        "PNG_viewed": "PENDING",
        "entry": entry,
    }
)
path = ART / "decay-factor0p5-stop-collection-v1.json"
path.write_text(json.dumps(receipt, indent=2) + "\n")
forecast = read(ART / "decay-factor0p5-local-forecast-admitted-v2.json")
old = forecast["actual_preserved_candidate_output_bytes"]
evidence_needed = (
    sum(old.values())
    + root_bytes
    + forecast["candidate_output_guard"]
    + forecast["other_review_control_images_evidence_upper"]
    + forecast["original_first_phase_control_upper"]
    + forecast["additional_first_phase_control_allowance"]
    + 262144
)
proposal = {
    "schema": "decay-second-local-inclusive-forecast-v1",
    "current_learning_bytes": forecast["learning_inclusive"],
    "current_evidence_bytes": forecast["evidence_upper_bytes"],
    "old_outputs_preserved": old,
    "first_completed_root": str(ROOT),
    "first_completed_root_bytes": root_bytes,
    "second_output_guard_bytes": forecast["candidate_output_guard"],
    "second_control_allowance": 262144,
    "other_evidence_upper": forecast["other_review_control_images_evidence_upper"],
    "first_controls_upper": 524288,
    "required_evidence_bytes": evidence_needed,
    "deficit_bytes": max(0, evidence_needed - forecast["evidence_upper_bytes"]),
    "required_additional_MiB": int(
        np.ceil(max(0, evidence_needed - forecast["evidence_upper_bytes"]) / 1048576)
    ),
    "second_entry": "NOT_ADMITTED",
    "no_global_scan_no_delete_no_selfallocation": True,
}
(ART / "decay-factor0p25-local-forecast-v1.json").write_text(json.dumps(proposal, indent=2) + "\n")
print(
    json.dumps(
        {
            "BEST": receipt["BEST_V"],
            "epoch": receipt["BEST_epoch"],
            "crossings": crossings,
            "root_bytes": root_bytes,
            "second_forecast": proposal,
        }
    )
)
