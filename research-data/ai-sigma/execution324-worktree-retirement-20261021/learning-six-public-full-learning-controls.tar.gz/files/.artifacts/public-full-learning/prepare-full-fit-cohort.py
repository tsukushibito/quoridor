import hashlib, json, math
from pathlib import Path

R = Path("/workspaces/quoridor/.worktree/learning-million")
A = R / ".artifacts/public-full-learning"


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def put(p, v):
    Path(p).write_text(json.dumps(v, indent=2) + "\n")


qroot = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/supply-recovery-r1"
)
q = json.loads((qroot / "output/result.json").read_text())
assert q["status"] == "PASS" and q["recommended_batch"] == 2048
preview = json.loads((A / "supply-fit-preview-r1.json").read_text())
binding = json.loads((A / "supply-input-binding-r1.json").read_text())
binding.update(
    initial_weights_sha=q["initial_weights_SHA"],
    qualified_initial_native_manifest=str(qroot / "output/initial-model/manifest.json"),
    native_binary=json.loads((qroot / "native-ready.json").read_text())["path"],
    qualification_stop_receipt=str(qroot / "stop-receipt.json"),
)
steps_epoch = math.ceil(8413949 / 2048)
cohort = {
    "schema": "quoridor-public-full-locked-cohort-v1",
    "plan": str(A / "convergence-plan-v1.json"),
    "plan_SHA": sha(A / "convergence-plan-v1.json"),
    "supply_result": str(qroot / "output/result.json"),
    "supply_result_SHA": sha(qroot / "output/result.json"),
    "batch": 2048,
    "batch_selection_rule": "pre-fixed min median qualified warm production per-row cost",
    "steps_per_complete_epoch": steps_epoch,
    "epoch_tail_rows": 8413949 % 2048,
    "initial_weights_SHA": q["initial_weights_SHA"],
    "scale_SHA": q["scale_SHA"],
    "cache_manifest_SHA": q["cache_manifest_SHA"],
    "candidates": [],
    "primary": "full original validation rowMSE; per-run actualminimum, crossrun exacttie lowerLR then earlierupdate",
    "stop": "patience8epoch/min_delta1e-4 or nonfinite, time/epoch/samples/MAXjob null",
    "final_test_release": "HELD until allcandidate selection+global freeze and finalSigma relatedboundary/native qualification. Per-runfreeze does not release newE.",
    "newE_labels": "CLOSED",
    "whole_FT_head": "FTScalarSimd/headScalar. Native metrics separate from whole search.",
    "secondary_stratum": "original_train_input_known is original cache membership only, not proof that online reflected inputs were never seen",
    "pure_compile_NN0_concurrent": "only private immutable learner binary/library; CPU0,1/RAM2GiB/GPU0, no fairclock claim",
}
root = Path("/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/convergence-v1")
root.mkdir(parents=True)
source = json.loads((A / "caller-review-binding-r3.json").read_text())
source["source_paths_SHA"] = {p: sha(p) for p in source["source_paths_SHA"]}
source["previous_r3_binding_SHA"] = sha(A / "caller-review-binding-r3.json")
source["normal_additions"] = [
    "fixed qualification initial_weights_sha guard before any fullcompact selector/optimizer forward",
    "secondary stratum named original_train_input_known: excludes claim about reflected seen inputs",
]
source["NN0_log"] = str(A / "caller-NN0-r4.log")
source["NN0_log_SHA"] = sha(A / "caller-NN0-r4.log")
source["actual_qualification_STOP"] = str(qroot / "stop-receipt.json")
source["actual_qualification_STOP_SHA"] = sha(qroot / "stop-receipt.json")
put(A / "full-fit-source-binding-r4.json", source)
for label, lr in [("lr3e-5", 3e-5), ("lr1e-4", 1e-4), ("lr3e-4", 3e-4)]:
    config = json.loads(json.dumps(preview))
    config["optimizer"]["lr"] = lr
    config["training"]["batch_size"] = 2048
    config["training"]["warmup_steps"] = math.ceil(steps_epoch / 16)
    config["evaluation"]["diagnostic_interval"] = math.ceil(steps_epoch / 8)
    path = A / f"fit-{label}-config.json"
    put(path, config)
    inputs = {
        **binding,
        "role": "locked original-full correctLR learning candidate",
        "fit_config_sha": sha(path),
        "native_binary_sha": sha(binding["native_binary"]),
        "data_source_original_library": "/workspaces/quoridor/.worktree/learning-million/.artifacts/learning-million/libquoridor_data.so",
    }
    inputs["original_library_sha"] = sha(inputs["data_source_original_library"])
    ipath = A / f"fit-{label}-input-binding.json"
    put(ipath, inputs)
    outputroot = root / label
    outputroot.mkdir()
    (outputroot / "tmp").mkdir()
    (outputroot / "mpl-cache").mkdir()
    expected = {p: d for p, d in source["source_paths_SHA"].items()}
    for p in [
        path,
        ipath,
        Path(inputs["scale_artifact"]),
        Path(inputs["constant_artifact"]),
        Path(inputs["native_binary"]),
        Path(inputs["data_source_original_library"]),
        Path("/workspaces/quoridor/scripts/dev/research-job.py"),
        Path("/workspaces/quoridor/scripts/dev/research-session.py"),
    ]:
        expected[str(p)] = sha(p)
    guard = {
        "output": str(outputroot / "output"),
        "cache": "/workspaces/quoridor/.worktree/assets/inputs/public-full-learning/original-full-v1/recovery-r1/corpus",
        "fit_config": str(path),
        "input_binding": str(ipath),
        "seconds": None,
        "expected_files_sha256": expected,
        "storage_admission": "/workspaces/quoridor/.artifacts/research-coordination/full-learning-capacity/current-admitted-with-full-learning.json",
        "resources": {
            "max_memory_bytes": 4 * 1024**3,
            "host_ram_reserve": 4 * 1024**3,
            "max_output_bytes": 20 * 1024**2,
            "max_vram_bytes": 6 * 1024**3,
            "controller_reserve_bytes": 64 * 1024**2,
        },
        "current_storage_inclusive": 1090519040,
        "source_build_reserved": 64 * 1024**2,
        "source_bindings": str(A / "full-fit-source-binding-r4.json"),
        "time_compute_forward_MAXjob_limits": None,
        "caps_histories": "old319fees/caps/UNKNOWN retained, not current work limits",
        "library_binary_immutable": "PASS; shared target readerwriter0",
        "test_release": False,
    }
    gpath = A / f"fit-{label}-guard-config.json"
    put(gpath, guard)
    job = {
        "issue": "quoridor-4lc.323",
        "goal_issue": "quoridor-4lc",
        "thread_id": "01a1100f-6d45-78e0-8a87-84503ff0fbf6",
        "cwd": str(R),
        "argv": [
            "/usr/bin/env",
            "OPENBLAS_NUM_THREADS=1",
            "OMP_NUM_THREADS=2",
            "MKL_NUM_THREADS=2",
            "NUMEXPR_NUM_THREADS=1",
            "PYTHONPATH=" + str(R / "python"),
            "TMPDIR=" + str(outputroot / "tmp"),
            "MPLCONFIGDIR=" + str(outputroot / "mpl-cache"),
            "QUORIDOR_PLOTS_PYTHON=/home/vscode/.cache/inference/envs/quoridor-learning-plots/bin/python",
            "/home/vscode/.cache/inference/envs/quoridor-training/bin/python",
            "-B",
            "-m",
            "quoridor_training.train",
            "train",
            "--cache",
            guard["cache"],
            "--output",
            guard["output"],
            "--guard-config",
            str(gpath),
        ],
        "end_at": None,
        "notify_until": None,
        "max_runtime_seconds": None,
        "control_interval_seconds": 3,
        "notify_interval_seconds": 5,
        "request_timeout_seconds": 25,
        "log_max_bytes": 131072,
        "resource_contract": "/workspaces/quoridor/research-data/ai-sigma/public-full-learning/task.md",
    }
    jpath = A / f"fit-{label}-job.json"
    put(jpath, job)
    cohort["candidates"].append(
        {
            "id": label,
            "LR": lr,
            "config": str(path),
            "config_SHA": sha(path),
            "input_binding": str(ipath),
            "input_binding_SHA": sha(ipath),
            "guard_config": str(gpath),
            "guard_SHA": sha(gpath),
            "job_config": str(jpath),
            "job_config_SHA": sha(jpath),
            "output": guard["output"],
            "warmup_steps": config["training"]["warmup_steps"],
            "diagnostic_interval": config["evaluation"]["diagnostic_interval"],
        }
    )
put(A / "locked-cohort-v1.json", cohort)
