"""Small fixed-entry checks; no corpus, shared-target, or historical inventory."""

import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

WT = Path("/workspaces/quoridor/.worktree/learning-million")
A = WT / ".artifacts/public-full-learning"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


entry = load(Path(sys.argv[1]))
assert Path.cwd() == WT
assert entry["resource_admission"] == "ADMITTED"
os.sched_setaffinity(0, {2, 3})
guard = load(entry["guard"])
for path, expected in guard["expected_files_sha256"].items():
    assert sha(path) == expected, path
for key in ["config", "input_binding", "guard", "job", "cohort"]:
    assert sha(entry[key]) == entry[key + "_SHA"], key
job = load(entry["job"])
assert all(job[k] is None for k in ["end_at", "notify_until", "max_runtime_seconds"])
config = load(entry["config"])
assert config["training"]["steps"] is None
assert config["limits"] == {"seconds": None, "samples": None}
baseline = load(entry["baseline_config"])
assert sha(entry["baseline_config"]) == entry["baseline_config_SHA"]
comparison = load(entry["config"])
for dotted, change in entry["expected_config_changes"].items():
    section, key = dotted.split(".")
    assert baseline[section][key] == change["before"]
    assert comparison[section][key] == change["after"]
    comparison[section][key] = change["before"]
assert comparison == baseline
inputs = load(entry["input_binding"])
cache_manifest = Path(guard["cache"]) / "cache.json"
assert sha(cache_manifest) == inputs["cache_manifest_sha"]
initial = Path(inputs["qualified_initial_native_manifest"])
initial_manifest = load(initial)
weights = initial.parent / initial_manifest["weights"]
assert sha(weights) == inputs["initial_weights_sha"]
base = load(guard["storage_admission"])
assert base["admission"] == "within" and not base["errors"]
assert (
    sha(guard["storage_admission"])
    == "887d2d14f1657a0baf3f455f99843f4de5c87abbd7f45c11d832215344c122d9"
)
overlay_path = Path(guard["current_typed_storage_overlay"])
overlay = load(overlay_path)
root_manifest = Path(
    "/workspaces/quoridor/.artifacts/task-session-permissions/native-completion-root-manifest.json"
)
assert sha(root_manifest) == overlay["root_manifest_after_SHA256"]
assert overlay["parent_after_bytes"] < overlay["parent_cap_bytes"]
assert overlay["UNKNOWN_retained_bytes"] == 134217728
forecast = load(entry["forecast"])
assert forecast["admission"] == "ADMITTED"
assert sha(forecast["explicit_Root_allocation"]) == forecast["allocation_SHA"]
assert forecast["evidence_peak"] < forecast["evidence_upper_bytes"]
assert (
    forecast["all_scope_peak_upper"]
    < forecast["learning_inclusive"]
    == guard["current_storage_inclusive"]
)
assert not Path(entry["runtime"]).exists()
assert not Path(entry["output"]).exists()

peer = Path(entry["peer_runtime"]) / "result.json"
peer_result = load(peer)
peer_state = load(Path(entry["peer_runtime"]) / "state.json")
peer_stop = load(entry["peer_stop_receipt"])
peer_process = peer_stop["guardian"]
assert peer_stop["controller"]["job_id"] == peer_result["job_id"]
assert peer_result["cleanup_complete"] and peer_result["remaining"] == []
assert peer_process["direct_child_reaped"] and peer_process["cleanup_complete"]
assert peer_process["remaining"] == []
peer_identities = [peer_state["child"]] + peer_process["identities"]
peer_identity_checks = []
for ident in peer_identities:
    path = Path(f"/proc/{ident['pid']}/stat")
    actual_tick = path.read_text().rsplit(")", 1)[1].split()[19] if path.exists() else None
    expected_tick = ident.get("start_ticks", ident.get("tick"))
    assert actual_tick != expected_tick, ident
    peer_identity_checks.append({"identity": ident, "same_pid_start_alive": False})
stop = load(entry["previous_stop_collection"])
assert stop["controller"]["cleanup_complete"] and stop["controller"]["remaining"] == []
for check in stop["identity_checks"].values():
    identity = check["identity"]
    stat_path = Path(f"/proc/{identity['pid']}/stat")
    if stat_path.exists():
        ticks = stat_path.read_text().rsplit(")", 1)[1].split()[19]
        assert ticks != identity["start_ticks"], identity

foreign = []
for path in Path("/proc").iterdir():
    if not path.name.isdigit() or int(path.name) == os.getpid():
        continue
    try:
        comm = (path / "comm").read_text().strip()
        cmd = (path / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        continue
    if (
        comm
        in {
            "cargo",
            "rustc",
            "clippy-driver",
            "nnue-diagnose",
            "quoridor-runner",
            "canonical-bench",
            "canonical-crite",
        }
        or comm.startswith("nnue_search")
        or (
            comm.startswith("python")
            and any(
                module in cmd
                for module in [
                    "-m quoridor_training.train",
                    "-m quoridor_training.qualification",
                    "quoridor_training.public_sigma",
                ]
            )
        )
    ):
        foreign.append({"pid": int(path.name), "comm": comm, "cmd": cmd[:400]})
assert foreign == [], foreign
mem = {
    line.split(":")[0]: line.split(":")[1].strip()
    for line in Path("/proc/meminfo").read_text().splitlines()
}
available = int(mem["MemAvailable"].split()[0]) * 1024
assert available > 8 * 1024**3
query = subprocess.run(
    ["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"],
    check=True,
    capture_output=True,
    text=True,
)
used = int(query.stdout.strip()) * 1024**2
assert used < 2 * 1024**3
value = {
    "at": datetime.now(timezone.utc).isoformat(),
    "entry": entry,
    "permissions": {
        "sandbox": "danger-full-access",
        "approvalPolicy": "never",
        "source": "active explicit developer permission profile",
    },
    "actual_cwd": str(Path.cwd()),
    "affinity": sorted(os.sched_getaffinity(0)),
    "source_config_initial_cache_scale_binding": "PASS",
    "old_cohort_and_all_outputs_preserved": True,
    "peer_last_exactSTOP": peer_result,
    "peer_current_reservation": "direct318 exact current numeric STOP; next numeric NONE",
    "peer_identity_checks": peer_identity_checks,
    "peer_guard_wait_cleanup": {
        k: peer_process[k]
        for k in ("ended", "direct_child_reaped", "cleanup_complete", "remaining")
    },
    "foreign_science_compilers_observed": foreign,
    "available_memory": available,
    "device_used": used,
    "local_forecast": forecast,
    "parent_overlay": str(overlay_path),
    "parent_overlay_SHA": sha(overlay_path),
    "root_manifest_SHA": sha(root_manifest),
    "full_or_sharedtarget_walk": False,
    "newE": "CLOSED",
}
target = A / (entry["id"] + "-prelaunch-v1.json")
assert not target.exists()
target.write_text(json.dumps(value, indent=2) + "\n")
print(
    json.dumps(
        {
            "entry_checks": "PASS",
            "available_memory": available,
            "device_used": used,
            "evidence_margin": forecast["evidence_margin"],
        }
    )
)
