"""Attribute immutable saved fit outputs without constructing or forwarding a model."""

import gzip
import hashlib
import json
import statistics
import sys
from pathlib import Path

import numpy as np
import torch

from quoridor_training.sampling import EarlyStopping
from quoridor_training.train import verify_native_parameters


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def finite_tree(obj):
    if isinstance(obj, torch.Tensor):
        return bool(torch.isfinite(obj).all())
    if isinstance(obj, dict):
        return all(finite_tree(v) for v in obj.values())
    if isinstance(obj, (tuple, list)):
        return all(finite_tree(v) for v in obj)
    return True


entry_path = Path(sys.argv[1])
art = entry_path.parent
entry = read(entry_path)
out = Path(entry["output"])
root = out.parent
name = entry["id"]
receipt = read(art / (name + "-stop-receipt-v1.json"))
status = read(out / "run-status.json")
config = read(out / "config.json")
freeze = read(out / "freeze.json")
sampling = read(out / "sampling.json")
inputs = read(entry["input_binding"])
with gzip.open(out / "curves.jsonl.gz", "rt") as stream:
    points = [json.loads(line) for line in stream]
rows_train = sampling["training_rows"]
rows_validation = points[0]["validation"]["rows"]
steps_epoch = (rows_train + config["training"]["batch_size"] - 1) // config["training"][
    "batch_size"
]
epochs = status["completed_epochs"]
assert status["status"] == "EARLY_STOPPED" and len(points) == epochs + 1
stopper = EarlyStopping(
    config["evaluation"]["early_stopping_patience"], config["evaluation"]["min_delta"]
)
trace = []
for epoch, point in enumerate(points):
    assert point["completed_epochs"] == epoch
    assert point["training_seen"] == rows_train * epoch
    assert point["step"] == steps_epoch * epoch
    assert point["validation"]["rows"] == rows_validation
    improved, stop = stopper.observe(point["validation"]["target_mse"])
    assert stop == (epoch == epochs)
    trace.append(
        {
            "epoch": epoch,
            "V": point["validation"]["target_mse"],
            "lr_after_selector": point["lr"],
            "significant_improvement": improved,
            "stale": stopper.stale,
            "stop": stop,
        }
    )

checkpoints = {}
for checkpoint in ("initial", "best", "last"):
    path = out / (checkpoint + ".pt")
    cp = torch.load(path, map_location="cpu", weights_only=True)
    assert cp["position"] == status["checkpoint_positions"][checkpoint]
    assert cp["dataset_sha"] == freeze["dataset_sha"] == inputs["cache_manifest_sha"]
    assert cp["model_config"] == config["model"]
    assert cp["scale"] == read(out / "scale.json")
    assert finite_tree(cp["model"]) and finite_tree(cp["optimizer"])
    weights = out / (checkpoint + "-model/weights.f32")
    verify_native_parameters(weights, cp["model"])
    adam_steps = sorted({int(v["step"]) for v in cp["optimizer"]["state"].values()})
    assert adam_steps == ([] if checkpoint == "initial" else [cp["position"]["step"]])
    checkpoints[checkpoint] = {
        "position": cp["position"],
        "PT_SHA": digest(path),
        "weights_SHA": digest(weights),
        "finite_model_Adam": True,
        "native_parameter_bytes_exact": True,
        "Adam_steps": adam_steps,
    }
assert checkpoints["initial"]["weights_SHA"] == inputs["initial_weights_sha"]
with np.load(out / "sampling-counts.npz", allow_pickle=False) as counts:
    visits = counts["row_counts"]
    attempted = counts["attempted_row_counts"]
    assert visits.dtype == np.int64 and np.array_equal(visits, attempted)
    assert np.all(visits[:rows_train] == epochs) and np.all(visits[rows_train:] == 0)
    assert int(visits.sum()) == status["training_seen"]
    visit_proof = {
        "schema": str(counts["schema"]),
        "index_encoding": str(counts["index_encoding"]),
        "training_index_range": counts["training_index_range"].tolist(),
        "Trows": rows_train,
        "Vrows": rows_validation,
        "per_Trow": epochs,
        "Voptimizer_visits": 0,
        "dtype": str(visits.dtype),
        "sum": int(visits.sum()),
        "attempted_equal_completed": True,
        "NPZ_SHA": digest(out / "sampling-counts.npz"),
    }
for path, expected in freeze["artifacts_sha256"].items():
    assert digest(out / path) == expected, path
for key in ("config", "input_binding", "guard", "job", "cohort"):
    assert digest(entry[key]) == entry[key + "_SHA"], key
source = read(art / "recording-source-binding-r6.json")
for path, expected in source["source_paths_SHA"].items():
    assert digest(path) == expected, path
for path_key, sha_key in (
    ("native_binary", "native_binary_sha"),
    ("data_source_original_library", "original_library_sha"),
    ("scale_artifact", "scale_artifact_sha"),
    ("constant_artifact", "constant_artifact_sha"),
):
    assert digest(inputs[path_key]) == inputs[sha_key], path_key
best = min(points, key=lambda p: p["validation"]["target_mse"])
assert freeze["best_validation_mse"] == best["validation"]["target_mse"]
thresholds = (0.44, 0.435, 0.43, 0.42605264436242674)
crossings = {}
for threshold in thresholds:
    first = next((p for p in points if p["validation"]["target_mse"] <= threshold), None)
    crossings[str(threshold)] = (
        {k: first[k] for k in ("completed_epochs", "step", "training_seen", "wall_seconds", "lr")}
        if first
        else None
    )
files = [p for p in root.rglob("*") if p.is_file()]
times = [b["wall_seconds"] - a["wall_seconds"] for a, b in zip(points, points[1:])]
receipt.update(
    {
        "finite_scientific_stop_trace": trace,
        "checkpoint_metadata_checks": checkpoints,
        "actual_visit_arrays": visit_proof,
        "freeze_all_artifact_SHA": "PASS",
        "freeze_SHA": digest(out / "freeze.json"),
        "original_fullV_crossings": crossings,
        "speed_target_reached": crossings[str(thresholds[-1])] is not None,
        "selector_points": len(points),
        "diagnostic_points": sum(1 for _ in gzip.open(out / "diagnostic-curves.jsonl.gz", "rt")),
        "owned_run_root_bytes": sum(p.stat().st_size for p in files),
        "files_SHA": {str(p.relative_to(root)): digest(p) for p in files},
        "observed_resources": read(root / "observed-resources.json"),
        "epoch_wall_summary": {
            "median_seconds": statistics.median(times),
            "mean_seconds": statistics.mean(times),
            "scope": "actual saved selector interval incl evaluation/IO; co-running context, not comparative performance proof",
        },
        "decay_events_after_epoch": [
            {"epoch": b["completed_epochs"], "next_LR": b["lr"]}
            for a, b in zip(points, points[1:])
            if a["lr"] != b["lr"]
        ],
        "collection_model_forward": 0,
        "collection_GPU": 0,
        "PNG_viewed": "PENDING",
        "future_root_overlay": "applies next-entry only; used guard/resource config preserved",
    }
)
target = art / (name + "-stop-collection-v1.json")
assert not target.exists()
target.write_text(json.dumps(receipt, indent=2) + "\n")
print(
    json.dumps(
        {
            "BEST": receipt["BEST_V"],
            "epoch": epochs,
            "crossings": crossings,
            "root_bytes": receipt["owned_run_root_bytes"],
            "result": str(target),
        }
    )
)
