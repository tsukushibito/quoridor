def measurement_config(experiment):
    """Functional shapes only; settings and input order belong to the run."""
    config = document(experiment["config"])
    requests = document(experiment["schedule"])
    require(
        isinstance(config, dict)
        and set(config)
        <= {
            "roots",
            "profile",
            "tt_entries",
            "use_tt",
            "use_pvs",
            "namespace",
            "output_bytes",
            "record_bytes",
            "seed",
            "lmr",
            "lmr_method",
            "zero_stock_approx_min_root_walls",
            "zero_stock_approx_method",
            "zero_stock_safe_race",
        }
        and {
            "roots",
            "profile",
            "tt_entries",
            "use_tt",
            "use_pvs",
            "namespace",
            "output_bytes",
            "record_bytes",
        }
        <= set(config),
        "measurement settings shape",
    )
    require(
        config["profile"] in {"control", "cheap", "coverage"},
        "configured ordering target",
    )
    for key in ("tt_entries", "output_bytes", "record_bytes"):
        require(
            type(config[key]) is int and config[key] > 0, "measurement positive " + key
        )
    require(
        config["record_bytes"] <= config["output_bytes"],
        "measurement record/output limit",
    )
    require(
        all(type(config[key]) is bool for key in ("use_tt", "use_pvs")),
        "measurement Boolean switches",
    )
    require(type(config.get("lmr", False)) is bool, "measurement LMR switch")
    require(
        type(config.get("zero_stock_safe_race", False)) is bool,
        "measurement safe-race switch",
    )
    lmr_method = config.get("lmr_method", "depth_rank")
    require(
        type(lmr_method) is str
        and lmr_method
        in (
            "fixed_one",
            "depth_rank",
        ),
        "measurement LMR method",
    )
    method = config.get("zero_stock_approx_method", "race")
    require(
        type(method) is str and method in {"race", "fixed_d"},
        "measurement zero-stock approximation method",
    )
    threshold = config.get("zero_stock_approx_min_root_walls")
    require(
        threshold is None or (type(threshold) is int and 0 <= threshold <= 20),
        "measurement zero-stock threshold must be an integer0..20 or null",
    )
    require(
        not config.get("lmr", False)
        or (config["use_pvs"] and config["profile"] in {"control", "cheap"}),
        "measurement LMR requires PVS and Control/Cheap",
    )
    require(
        config.get("seed") is None
        or (type(config["seed"]) is int and 0 <= config["seed"] < 2**64),
        "measurement seed metadata",
    )
    namespace = config["namespace"]
    require(
        isinstance(namespace, dict)
        and set(namespace) == {"evaluator", "rules", "selectivity"}
        and all(isinstance(v, str) and v for v in namespace.values())
        and namespace["rules"] == experiment["rules"],
        "measurement namespace",
    )
    require(isinstance(config["roots"], list) and config["roots"], "measurement roots")
    for root in config["roots"]:
        require(
            isinstance(root, dict)
            and {"input", "pointer", "field", "label"} <= set(root)
            and set(root)
            <= {
                "input",
                "pointer",
                "field",
                "label",
                "prefix_len",
                "jsonl_match",
                "check_history",
            }
            and type(root["input"]) is int
            and 0 <= root["input"] < len(experiment["inputs"])
            and all(isinstance(root[k], str) for k in ("pointer", "field", "label"))
            and (not root["pointer"] or root["pointer"].startswith("/"))
            and bool(root["field"]),
            "measurement root selector",
        )
        require(
            root.get("prefix_len") is None
            or (type(root["prefix_len"]) is int and root["prefix_len"] >= 0),
            "chronological prefix length",
        )
        require(
            root.get("jsonl_match") is None or isinstance(root["jsonl_match"], dict),
            "JSONL selection",
        )
        require(type(root.get("check_history", False)) is bool, "history check switch")
    require(isinstance(requests, list), "measurement request array")
    ids, closed, active = set(), set(), None
    for request in requests:
        require(
            isinstance(request, dict)
            and {"id", "session", "root", "depth", "node_cap"} <= set(request)
            and set(request)
            <= {
                "id",
                "session",
                "root",
                "depth",
                "node_cap",
                "time_limit_ms",
                "diagnostic",
                "warmup",
                "observe_completed_depths",
                "observe_lmr",
            }
            and all(
                isinstance(request[k], str) and request[k] for k in ("id", "session")
            )
            and request["id"] not in ids
            and type(request["root"]) is int
            and 0 <= request["root"] < len(config["roots"])
            and type(request["depth"]) is int
            and 0 < request["depth"] < 2**16
            and type(request["node_cap"]) is int
            and 0 < request["node_cap"] < 2**64,
            "measurement request type/range/identity",
        )
        require(
            request.get("time_limit_ms") is None
            or (
                type(request["time_limit_ms"]) is int
                and 0 < request["time_limit_ms"] < 2**64
            ),
            "measurement optional deadline",
        )
        require(
            all(
                type(request.get(k, False)) is bool
                for k in (
                    "diagnostic",
                    "warmup",
                    "observe_completed_depths",
                    "observe_lmr",
                )
            ),
            "measurement request switches",
        )
        ids.add(request["id"])
        if active != request["session"]:
            require(request["session"] not in closed, "session reused after teardown")
            if active is not None:
                closed.add(active)
            active = request["session"]
    if any(r.get("observe_lmr", False) for r in requests):
        require(
            len(requests) <= 12
            and len({r["session"] for r in requests}) == len(requests)
            and len({r["root"] for r in requests}) == len(requests)
            and config["profile"] == "control"
            and config["tt_entries"] == 1048576
            and config["use_tt"]
            and config["use_pvs"]
            and config.get("lmr", False)
            and lmr_method == "depth_rank"
            and threshold is None
            and not config.get("zero_stock_safe_race", False)
            and all(
                r.get("observe_lmr", False)
                and r["depth"] == 5
                and r["node_cap"] == 1000000
                and r.get("time_limit_ms") is None
                and not r.get("diagnostic", False)
                and not r.get("warmup", False)
                and not r.get("observe_completed_depths", False)
                for r in requests
            ),
            "bounded LMR observation cold Control/depth_rank D5/1M TT1M scope",
        )
        require(
            all(
                r["field"] == "prefix"
                and r.get("prefix_len") is None
                and r.get("jsonl_match") is None
                and not r.get("check_history", False)
                for r in config["roots"]
            ),
            "LMR observation complete-prefix selectors",
        )
    return config, requests
