"""Stopped metadata collection, no source/native/test replay or ownership writes."""

from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path

import intake

loader = importlib.util.spec_from_file_location(
    "lc417_metadata", intake.ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
here = intake.HERE
source = json.loads((here / "source-STOP.json").read_text())
controller = source["controller"]
fresh = lc.process.identity(lc.process.process_info(controller["pid"]))
assert fresh is None or fresh != controller
children = []
phases = []
for phase in ["admin-v1", "delivery-v1"]:
    path = here / phase / "result.json"
    if not path.exists():
        continue
    data = json.loads(path.read_text())
    phases.append(
        {
            "phase": phase,
            "result": intake.ref(path),
            "status": data["status"],
            "primary": data["primary"],
        }
    )
    for check in data["checks"]:
        disk_ref = check.get("persisted_process_receipt")
        if disk_ref is None:
            children.append(
                {
                    "phase": phase,
                    "name": check["name"],
                    "child": "UNKNOWN; no recorded identity",
                    "returned": check["guardian_return"],
                    "status": check["status"],
                }
            )
            continue
        assert intake.ref(Path(disk_ref["path"])) == disk_ref
        disk = json.loads(Path(disk_ref["path"]).read_text())
        returned = check["guardian_return"]
        facts = returned if returned is not None else disk
        assert facts["direct_child_reaped"] and facts["handle_closes_complete"]
        assert facts["cleanup_complete"] and not facts["remaining"]
        current = lc.process.identity(lc.process.process_info(facts["child"]["pid"]))
        assert current is None or current != facts["child"]
        children.append(
            {
                "phase": phase,
                "name": check["name"],
                "status": check["status"],
                "child": facts["child"],
                "fresh": current,
                "exit_code": facts["exit_code"],
                "direct_child_reaped": facts["direct_child_reaped"],
                "handles_complete": facts["handle_closes_complete"],
                "cleanup_complete": facts["cleanup_complete"],
                "returned_NULL": returned is None,
                "returned_mask": None
                if returned is None
                else returned.get("signal_mask_restoration"),
                "returned_persist": None
                if returned is None
                else returned.get("final_record_persist"),
                "disk_mask": disk.get("signal_mask_restoration"),
                "disk_persist": disk.get("final_record_persist"),
                "persisted_process_receipt": disk_ref,
                "capture": check["full_log"],
                "child_wall_seconds_once": facts["wall_seconds"],
            }
        )
    assert not (here / phase / "TMP").exists(), phase
result = {
    "issue": "quoridor-4lc.417.2",
    "metadata_STOP": datetime.now(timezone.utc).isoformat(),
    "source_STOP": intake.ref(here / "source-STOP.json"),
    "source_controller": controller,
    "source_controller_fresh": fresh,
    "phases": phases,
    "children": children,
    "source_readers": [],
    "source_writers": [],
    "children_remaining": [],
    "jobs": [],
    "handles": [],
    "TMP": [],
    "leases": [],
    "owned": [],
    "current_metadata_verifier": lc.process.identity(
        lc.process.process_info(os.getpid())
    ),
    "verifier_scope": "finite metadata writer, exits after this record; direct return checked by tool, not falsely self-absent at write time",
    "earlier_unrecorded_guard_controller_identities": "UNKNOWN; commands returned normally via tool; no invented PID/UTC",
    "no_Beads_mutation_close_or_backup": True,
    "leaf": "in_progress same claimant; Root324 accepts/closes/backs up",
    "usage": "only source-STOP directed walk once; tinyadmin excluded, no repeated storage walk/global claim",
}
name = (
    "delivery-STOP.json"
    if (here / "delivery-v1/result.json").exists()
    else "admin-STOP.json"
)
(here / name).write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"STOP": intake.ref(here / name), "owned": [], "phases": phases}))
