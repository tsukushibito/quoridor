"""One immutable owning-source intake for 417; no engine or test execution."""

import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
BASE = "0252dd5a81ab8e65e92dc8f9b2d2bf90c9fd0bee"
ROOT = Path("/workspaces/quoridor")


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def git(*args):
    return subprocess.run(
        [
            "git",
            "-c",
            "core.packedGitWindowSize=8m",
            "-c",
            "core.packedGitLimit=32m",
            "--no-optional-locks",
            *args,
        ],
        cwd=ROOT,
        check=True,
        capture_output=True,
    ).stdout


def main():
    context = {
        "verified_UTC": "2026-10-15T14:12:51.001Z",
        "cwd": "/workspaces/quoridor",
        "model": "gpt-6.1-sol",
        "effort": "high",
        "sandbox_policy": {"type": "danger-full-access"},
        "approval_policy": "never",
        "source": "same saved rollout actual turn_context",
        "ordering_exception": "first tool read pwd/session directory metadata; actual turn_context verified immediately afterwards, before source/Beads/implementation",
    }
    (HERE / "actual-context.json").write_text(json.dumps(context, indent=2) + "\n")
    for verb in [("ready", "--json"), ("show", "quoridor-4lc.417.2", "--json")]:
        result = subprocess.run(
            ["bash", str(ROOT / "scripts/dev/beads.sh"), *verb],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        name = "ready.json" if verb[0] == "ready" else "own-before.json"
        (HERE / name).write_text(result.stdout)
    (own,) = json.loads((HERE / "own-before.json").read_text())
    assert (
        own["id"] == "quoridor-4lc.417.2"
        and own["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
    )
    assert own["status"] in {"open", "in_progress"}
    if own["status"] == "open":
        update = subprocess.run(
            [
                "bash",
                str(ROOT / "scripts/dev/beads.sh"),
                "update",
                own["id"],
                "--status",
                "in_progress",
                "--json",
            ],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        (HERE / "own-claim.json").write_text(update.stdout)
    contract = ROOT / ".artifacts/research-policy/lmr-internal-sequence-20261015.md"
    print("CONTRACT\n" + contract.read_text())
    assert git("rev-parse", "--verify", BASE + "^{commit}").decode().strip() == BASE
    owners = []
    for relative in [
        "crates/quoridor-ai/src/alphabeta.rs",
        "crates/quoridor-ai/src/lmr_observation416.rs",
        "crates/quoridor-runner/src/measurement.rs",
    ]:
        raw = git("show", BASE + ":" + relative)
        path = HERE / "before" / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        owners.append(
            {
                "relative": relative,
                "Git": BASE,
                "blob_oid": git("rev-parse", BASE + ":" + relative).decode().strip(),
                "before": ref(path),
            }
        )
        if relative.endswith("lmr_observation416.rs"):
            print("CURRENT_OBSERVER\n" + raw.decode())
        else:
            for i, line in enumerate(raw.decode().splitlines()):
                if any(
                    t in line
                    for t in [
                        "struct SearchInvocation",
                        "fn search_in_table",
                        "fn reduced_child",
                        "fn lmr_allowed",
                        "observe_lmr",
                        "fn lmr_observation_output",
                        "struct RootSpec",
                    ]
                ):
                    print(relative, i + 1, line)
    relative = "scripts/dev/research-lifecycle.py"
    text = git("show", BASE + ":" + relative).decode()
    fn = next(
        n
        for n in ast.parse(text).body
        if isinstance(n, ast.FunctionDef) and n.name == "measurement_config"
    )
    body = "".join(text.splitlines(keepends=True)[fn.lineno - 1 : fn.end_lineno])
    (HERE / "before-measurement_config.py").write_text(body)
    print("PYTHON_OWNER\n" + body)
    (HERE / "Python-owner.json").write_text(
        json.dumps(
            {
                "Git": BASE,
                "relative": relative,
                "whole_sha256": hashlib.sha256(text.encode()).hexdigest(),
                "lines": [fn.lineno, fn.end_lineno],
                "function": ref(HERE / "before-measurement_config.py"),
            },
            indent=2,
        )
        + "\n"
    )
    inputs = (
        ROOT
        / ".artifacts/research-team/integration324/lmr-limited-observation416-v1/inputs-v1/twelve-prefixes.json"
    )
    r = ref(inputs)
    assert (
        r["sha256"]
        == "75e417572078a3d20c5d3c0b8e46afad46790dd18ac2e5c925098cd8c5a75c1a"
        and r["bytes"] == 35281
        and r["mode"] == "0644"
    )
    value = json.loads(inputs.read_text())
    assert ref(inputs) == r
    assert [x["evaluator"] for x in value["roots"]] == ["distance"] * 6 + ["nnue"] * 6
    assert [len(x["prefix"]) for x in value["roots"]] == [
        4,
        6,
        5,
        9,
        4,
        6,
        4,
        6,
        4,
        9,
        8,
        4,
    ]
    (HERE / "intake-refs.json").write_text(
        json.dumps(
            {
                "base": BASE,
                "context": ref(HERE / "actual-context.json"),
                "contract": ref(contract),
                "owners": owners,
                "inputs": r,
                "own": {"id": own["id"], "assignee": own["assignee"]},
                "observed_UTC": datetime.now(timezone.utc).isoformat(),
                "cwd": os.getcwd(),
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
