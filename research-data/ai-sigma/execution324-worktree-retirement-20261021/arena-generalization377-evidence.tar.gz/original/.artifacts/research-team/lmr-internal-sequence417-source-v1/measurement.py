"""One native diagnostic consumer; retain canonical input and ordinary output."""

import re
from pathlib import Path

from kernel import HERE, once, write

RUNNER = Path("crates/quoridor-runner/src/measurement.rs")


def main():
    text = (HERE / "before" / RUNNER).read_text()
    a = text.index("        let lmr_output = lmr_observation.as_deref().map")
    b = text.index("        let mut row = match result", a)
    output = text[a:b].replace(
        "result.is_ok() && after == self.before,",
        'row["status"] == "COMPLETE" && row["completed_depth"] == 5 && after == self.before,',
    )
    text = text[:a] + text[b:]
    at = text.index('        row["actual_selectivity"]')
    text = text[:at] + output + text[at:]
    # Move the existing numeric work expression and assignments to one owner,
    # so Err traces need no fake SearchResult/stop/depth/elapsed placeholders.
    a = text.index("fn observed(r: &SearchResult) -> Value {")
    b = text.index("fn validate_return(", a)
    observed = text[a:b]
    start = observed.index('"work":') + len('"work":')
    end = observed.index(',\n        "ordering":', start)
    work = observed[start:end]
    observed = observed[:start] + "observed_work(s)" + observed[end:]
    additions = re.findall(r'    result\["work"\].*?;\n', observed, re.DOTALL)
    for addition in additions:
        observed = once(observed, addition, "")
    helper = (
        "fn observed_work(s: &alphabeta::SearchStats) -> Value {\n    let mut work=json!("
        + work
        + ");\n"
    )
    helper += "".join(x.replace('result["work"]', "work") for x in additions)
    helper += "    work\n}\n"
    text = text[:a] + helper + observed + text[b:]
    a = text.index("// Bounded output for the one opt-in diagnostic.")
    b = text.index("fn observation_input_check(", a)
    replacement = (HERE / "trial-output.rs").read_text() + "\n"
    replacement += (HERE / "observer-output.rs").read_text() + "\n"
    text = text[:a] + replacement + text[b:]
    before = """            observation["root_fullhistory"] = self.before.clone();
            row["lmr_observation"] = observation;"""
    after = """            observation["root_fullhistory"] = self.before.clone();
            observation["root_common_invocations"] = json!(1);
            observation["root_recorded_nodes"] = row["work"]["nodes"].clone();
            observation["root_work_known"] = json!(!row["work"].is_null());
            observation["actual_root_plus_arm_invocations"] = json!(
                1 + observation["arm_function_calls"].as_u64().unwrap());
            observation["actual_root_plus_explicit_child_calls"] = json!(
                1 + observation["arm_explicit_child_scouts"].as_u64().unwrap());
            observation["root_plus_arm_known_nodes"] = json!(
                row["work"]["nodes"].as_u64().unwrap_or(0)
                    + observation["arm_recorded_nodes"].as_u64().unwrap());
            observation["approved_maxima_not_actual_usage"] = json!({
                "roots":12,"branches":48,"arm_trials":192,
                "top_level_entries":204,"root_plus_explicit_child_calls":300,
                "nodes":31_200_000});
            row["lmr_observation"] = observation;"""
    text = once(text, before, after)
    text += "\n" + (HERE / "measurement_tests.rs").read_text()
    write(RUNNER, text)
    print(
        "single observer consumer updated; canonical input replay and ordinary outputs retained"
    )


if __name__ == "__main__":
    main()
