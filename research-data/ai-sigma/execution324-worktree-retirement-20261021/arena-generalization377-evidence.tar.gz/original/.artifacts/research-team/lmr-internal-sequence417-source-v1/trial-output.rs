fn trial_stage_output(stage: alphabeta::LmrStage) -> Value {
    json!({"child_depth":stage.child_depth,"window_bits":stage.window_bits,
        "value_bits":stage.value_bits,"bound":stage.bound,"completed":stage.completed,
        "status":if stage.completed {"COMPLETE"} else {"UNKNOWN"},
        "stop":stage.stop.map(|r|format!("{r:?}")),"error":stage.error,
        "interrupted_without_result":!stage.completed && stage.stop.is_none() && !stage.error})
}

fn lmr_trial_output(
    session: &SearchSession,
    root: &SigmaContext,
    branch: &alphabeta::LmrBranch,
    arm: alphabeta::LmrArm,
    cancel: &AtomicBool,
) -> Value {
    let start = Instant::now();
    let trial = session.lmr_trial(root, branch, arm, cancel);
    // Identical finite whole boundary, including reconstruction/allocate/drop,
    // and excluding JSON rendering in both N and R.
    let whole = start.elapsed().as_nanos();
    let mut row = match trial {
        Err(error) => json!({"status":"UNKNOWN","common_invocation_started":false,
            "error":fact(&error),"kernel_elapsed_ns":Value::Null,"work":Value::Null,
            "protocol_complete":false,"value_bits":Value::Null,"bound":Value::Null,
            "returned_child_depth":Value::Null,"parent_restored":Value::Null,"child_scouts":0,
            "confirmation_condition":Value::Null,"confirmation_entered":false,
            "confirmation_completed":Value::Null,"stages":[null,null]}),
        Ok(trial) => {
            let trace = trial.trace;
            let complete = trial.result.as_ref().is_ok_and(|r| {
                r.stop == StopReason::DepthComplete
                    && r.value.is_some()
                    && trace.parent_restored == Some(true)
            });
            let mut row = match trial.result {
                Ok(result) => {
                    json!({"status":if complete {"COMPLETE"} else {"UNKNOWN"},
                        "returned":"Ok","stop":format!("{:?}",result.stop),
                        "value_bits":if complete {result.value.map(f32::to_bits)} else {None},
                        "returned_child_depth":complete.then_some(result.completed_depth),
                        "Search_internal_elapsed_seconds":result.elapsed.as_secs_f64()})
                }
                Err(error) => json!({"status":"UNKNOWN","returned":"Err","error":fact(&error),
                    "value_bits":Value::Null,"returned_child_depth":Value::Null}),
            };
            let stages: Vec<_> = trace
                .stages
                .iter()
                .map(|s| {
                    s.map(|s| {
                        let mut row = trial_stage_output(s.scout);
                        row["nodes_before"] = json!(s.nodes_before);
                        row["nodes_after"] = json!(s.nodes_after);
                        row["evaluations_before"] = json!(s.evaluations_before);
                        row["evaluations_after"] = json!(s.evaluations_after);
                        row
                    })
                })
                .collect();
            // The common invocation may return Err after canonical restoration.
            // Its bounded trace still retains actual cumulative work if known.
            row["work"] = trace
                .final_stats
                .as_ref()
                .map_or(Value::Null, observed_work);
            row["common_invocation_started"] = json!(true);
            row["state_work_known"] = json!(!row["work"].is_null());
            row["parent_restored"] = json!(trace.parent_restored);
            row["kernel_elapsed_ns"] = json!(trace.kernel_elapsed.map(|d| d.as_nanos()));
            row["child_scouts"] = json!(trace.child_calls);
            row["confirmation_entered"] =
                json!(arm == alphabeta::LmrArm::ReducedThenConfirm && trace.child_calls == 2);
            row["confirmation_completed"] = if arm == alphabeta::LmrArm::ReducedThenConfirm {
                json!(trace.stages[1].map(|s| s.scout.completed))
            } else {
                Value::Null
            };
            row["confirmation_condition"] = if arm == alphabeta::LmrArm::ReducedThenConfirm {
                json!(
                    trace.stages[0]
                        .and_then(|s| s.scout.value_bits)
                        .map(|v| f32::from_bits(v) > f32::from_bits(trial.window_bits[0]))
                )
            } else {
                Value::Null
            };
            row["stages"] = json!(stages);
            row["bound"] = if complete {
                trace
                    .stages
                    .iter()
                    .rev()
                    .flatten()
                    .next()
                    .map_or(Value::Null, |s| json!(s.scout.bound))
            } else {
                Value::Null
            };
            row["window_bits"] = json!(trial.window_bits);
            row["protocol_complete"] = json!(complete);
            row["final_source"] = if complete {
                json!(if arm == alphabeta::LmrArm::Normal {
                    "normal"
                } else if trace.child_calls == 1 {
                    "shallow"
                } else {
                    "confirmation"
                })
            } else {
                Value::Null
            };
            row
        }
    };
    row["arm"] = json!(arm.name());
    row["arm_function_called"] = json!(true);
    row["normal_target_child_depth"] = json!(branch.normal_child_depth());
    row["reduced_target_child_depth"] = json!(branch.reduced_child_depth());
    row["probe_extra"] = json!(1);
    row["whole_elapsed_ns"] = json!(whole);
    row["node_cap_total"] = json!(100_000);
    row["time_limit_ms"] = Value::Null;
    row["initial_TT_entries"] = json!(0);
    row["initial_ordering"] = json!("zero continuation and killers; captured path only");
    row["initial_TT_capacity"] = json!(1_048_576);
    row["PV_scope"] = json!("parent action only; no complete child PV claimed");
    row["normal_semantics"] =
        json!("finite selective-depth estimate, not WDL/fullwidth truth or historical warm replay");
    row
}

fn lmr_unperformed_arm(arm: alphabeta::LmrArm) -> Value {
    json!({"arm":arm.name(),"status":"UNKNOWN","protocol_complete":false,
        "common_invocation_started":false,"arm_function_called":false,"execution":"UNPERFORMED",
        "reason":"root D5 incomplete/invalid, earlier arm error/cancel, or cancellation; no refill",
        "child_scouts":0,"work":Value::Null,"state_work_known":false,
        "value_bits":Value::Null,"bound":Value::Null,"returned_child_depth":Value::Null,
        "kernel_elapsed_ns":Value::Null,"whole_elapsed_ns":Value::Null,
        "stages":[null,null],"confirmation_condition":Value::Null,
        "confirmation_entered":false,"confirmation_completed":Value::Null,"parent_restored":Value::Null,
        "normal_target_child_depth":2,"reduced_target_child_depth":1,"probe_extra":1,
        "node_cap_total":100000,"time_limit_ms":null})
}
fn lmr_repeat_status(a: &Value, b: &Value) -> &'static str {
    if a["protocol_complete"] != true || b["protocol_complete"] != true {
        return "UNKNOWN";
    }
    let keys = [
        "status",
        "returned",
        "stop",
        "value_bits",
        "bound",
        "returned_child_depth",
        "protocol_complete",
        "work",
        "stages",
        "child_scouts",
        "confirmation_condition",
        "confirmation_entered",
        "confirmation_completed",
        "parent_restored",
        "window_bits",
        "final_source",
    ];
    if keys.iter().all(|k| a[*k] == b[*k]) {
        "MATCH"
    } else {
        "DIFFERENT"
    }
}
fn lmr_bits_comparison(a: &Value, b: &Value) -> Value {
    json!({"value_bits":if a.is_null()||b.is_null() {"UNKNOWN"} else if a==b {"MATCH"} else {"DIFFERENT"},
        "left":a,"right":b})
}
