pub const LMR_OBSERVATION_PROTOCOL: &str = "internal-lmr-sequence417-v1";
pub const LMR_ARM_ORDER: [LmrArm; 4] = [
    LmrArm::Normal,
    LmrArm::ReducedThenConfirm,
    LmrArm::ReducedThenConfirm,
    LmrArm::Normal,
];

#[derive(Clone, Copy, Debug)]
pub struct LmrTtFacts {
    pub stored_depth: u16,
    pub bound: &'static str,
    pub context_matches: bool,
    pub usable_depth: bool,
    pub legal_move: Option<u16>,
}
#[derive(Clone, Copy, Debug)]
pub struct LmrBranchFacts {
    pub hypothesis: &'static str,
    pub slot: &'static str,
    pub iteration_depth: u16,
    /// Eligible distinct-hand visits ONLY at iteration5/d3/ply2.
    pub visit: u64,
    pub parent_depth: u16,
    pub parent_ply: usize,
    pub parent_stm: u8,
    pub distinct_rank: usize,
    pub action: u16,
    pub quantum: u16,
    pub alpha_beta_bits: [u32; 2],
    pub tt: Option<LmrTtFacts>,
}
pub struct LmrBranch {
    pub facts: LmrBranchFacts,
    parent: SigmaContext,
    path: Vec<(u8, u16)>,
    root_completed: bool,
    pub stages: [Option<LmrStage>; 3],
}
impl LmrBranch {
    pub fn parent(&self) -> &SigmaContext {
        &self.parent
    }
    pub fn path(&self) -> &[(u8, u16)] {
        &self.path
    }
    pub fn reduced_child_depth(&self) -> u16 {
        self.facts.parent_depth - 1 - self.facts.quantum.max(1)
    }
    pub fn normal_child_depth(&self) -> u16 {
        self.facts.parent_depth - 1
    }
}
#[derive(Clone, Copy, Default, Debug)]
pub struct LmrCoverage {
    pub opportunities: u64,
    pub first_completed: u64,
    pub first_fail_low: u64,
    pub normal_confirmations: u64,
    pub full_windows: u64,
    pub selection_candidates: u64,
    pub selected: u64,
    pub same_parent_skips: u64,
    pub same_branch_skips: u64,
    pub full_slots_skips: u64,
}
pub(super) struct Frame {
    facts: LmrBranchFacts,
    bucket: (usize, usize),
    selected: Option<usize>,
    stages: [Option<LmrStage>; 3],
    calls: usize,
}
pub struct LmrObservation {
    branches: [Option<LmrBranch>; 4],
    pub(super) frames: [Option<Frame>; 6],
    /// Target gate only: rank4..8/9..15/16..31/32+ x actual q0/q1.
    pub coverage: [[LmrCoverage; 2]; 4],
    pub(super) iteration: u16,
    visits: u64,
    used: bool,
    pub finished: bool,
    pub root_stop: Option<String>,
}
impl Default for LmrObservation {
    fn default() -> Self {
        Self {
            branches: std::array::from_fn(|_| None),
            frames: std::array::from_fn(|_| None),
            coverage: [[LmrCoverage::default(); 2]; 4],
            iteration: 0,
            visits: 0,
            used: false,
            finished: false,
            root_stop: None,
        }
    }
}

// This exact complete-history owner is retained from the current observer.
fn same_history(a: &SigmaContext, b: &SigmaContext) -> bool {
    a.position() == b.position()
        && a.is_synthetic() == b.is_synthetic()
        && a.total_ply() == b.total_ply()
        && a.ruleset().id() == b.ruleset().id()
        && a.occurrences().all(|(k, _)| a.count(k) == b.count(k))
        && b.occurrences().all(|(k, _)| a.count(k) == b.count(k))
}
impl LmrObservation {
    pub fn branches(&self) -> impl Iterator<Item = &LmrBranch> {
        self.branches.iter().filter_map(Option::as_ref)
    }
    fn retain(&mut self, class: usize, ply: usize, c: &SigmaContext, path: &[PlayedMove]) {
        let f = self.frames[ply].as_ref().expect("active target hand");
        let facts = f.facts;
        let (r, q) = f.bucket;
        self.coverage[r][q].selection_candidates += 1;
        let Some(slot) = (class * 2..class * 2 + 2).find(|&i| self.branches[i].is_none()) else {
            self.coverage[r][q].full_slots_skips += 1;
            return;
        };
        let hypothesis = if class == 0 { "H0" } else { "H+" };
        let mut same_parent = false;
        let mut same_branch = false;
        for b in self.branches() {
            if same_history(&b.parent, c) {
                same_branch |= b.facts.action == facts.action;
                same_parent |= b.facts.hypothesis == hypothesis;
            }
        }
        if same_branch {
            self.coverage[r][q].same_branch_skips += 1;
            return;
        }
        if same_parent {
            self.coverage[r][q].same_parent_skips += 1;
            return;
        }
        let f = self.frames[ply].as_mut().expect("active target hand");
        let mut facts = facts;
        facts.hypothesis = hypothesis;
        facts.slot = ["H0-0", "H0-1", "H+-0", "H+-1"][slot];
        self.branches[slot] = Some(LmrBranch {
            facts,
            parent: c.clone(),
            path: path.iter().map(|m| (m.colour, m.action)).collect(),
            stages: f.stages,
            root_completed: false,
        });
        f.selected = Some(slot);
        self.coverage[r][q].selected += 1;
    }
    pub(super) fn begin(
        &mut self,
        c: &SigmaContext,
        path: &[PlayedMove],
        mut facts: LmrBranchFacts,
    ) {
        if self.iteration != 5
            || facts.parent_depth != 3
            || facts.parent_ply != 2
            || facts.distinct_rank < 4
            || facts.quantum > 1
        {
            return;
        }
        self.visits += 1;
        facts.iteration_depth = 5;
        facts.visit = self.visits;
        let rank = match facts.distinct_rank {
            4..=8 => 0,
            9..=15 => 1,
            16..=31 => 2,
            _ => 3,
        };
        let q = usize::from(facts.quantum);
        self.coverage[rank][q].opportunities += 1;
        self.frames[2] = Some(Frame {
            facts,
            bucket: (rank, q),
            selected: None,
            stages: [None; 3],
            calls: 0,
        });
        if q == 0 && rank == 0 {
            self.retain(0, 2, c, path);
        }
    }
    pub(super) fn child_start(&mut self, ply: usize, action: u16, depth: u16, window: [f32; 2]) {
        let Some(f) = self.frames.get_mut(ply).and_then(Option::as_mut) else {
            return;
        };
        if f.facts.action != action {
            return;
        }
        let i = f.calls;
        assert!(
            i < 3,
            "one original shallow/confirmation/full-window sequence"
        );
        f.calls += 1;
        f.stages[i] = Some(LmrStage {
            child_depth: depth,
            window_bits: window.map(f32::to_bits),
            value_bits: None,
            bound: None,
            completed: false,
            stop: None,
            error: false,
        });
        let (rank, q) = f.bucket;
        if i > 0 {
            if q > 0 && i == 1 {
                self.coverage[rank][q].normal_confirmations += 1;
            } else {
                self.coverage[rank][q].full_windows += 1;
            }
        }
        if let Some(slot) = f.selected {
            self.branches[slot].as_mut().unwrap().stages = f.stages;
        }
    }
    pub(super) fn child_return(
        &mut self,
        c: &SigmaContext,
        path: &[PlayedMove],
        ply: usize,
        action: u16,
        result: &NodeResult<f32>,
    ) {
        let Some(f) = self.frames.get_mut(ply).and_then(Option::as_mut) else {
            return;
        };
        if f.facts.action != action {
            return;
        }
        let i = f.calls - 1;
        f.stages[i].as_mut().unwrap().record_return(result);
        let mut select = false;
        if let Ok(value) = result
            && i == 0
        {
            let (rank, q) = f.bucket;
            self.coverage[rank][q].first_completed += 1;
            if *value <= f32::from_bits(f.facts.alpha_beta_bits[0]) {
                self.coverage[rank][q].first_fail_low += 1;
                select = q == 1;
            }
        }
        if let Some(slot) = f.selected {
            self.branches[slot].as_mut().unwrap().stages = f.stages;
        }
        if select {
            self.retain(1, ply, c, path);
        }
    }
    fn finish(&mut self, result: &Result<SearchResult>) {
        self.finished = true;
        self.root_stop = Some(match result {
            Ok(r) => format!("{:?}", r.stop),
            Err(e) => e.to_string(),
        });
        let complete = result.as_ref().is_ok_and(|r| {
            r.stop == StopReason::DepthComplete
                && r.completed_depth == 5
                && r.value.is_some()
                && r.action.is_some()
        });
        for branch in self.branches.iter_mut().flatten() {
            branch.root_completed = complete;
        }
        self.frames = std::array::from_fn(|_| None);
    }
}
