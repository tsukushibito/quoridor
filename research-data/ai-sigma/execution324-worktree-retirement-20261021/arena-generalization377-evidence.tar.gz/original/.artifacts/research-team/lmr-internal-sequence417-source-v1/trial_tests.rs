#[cfg(test)]
mod trial_tests {
    use super::*;
    use std::sync::atomic::AtomicU64;

    struct Constant;
    impl StaticEvaluator for Constant {
        fn evaluate(&self, _: &SigmaContext, _: Option<&EvalAccumulator>) -> Result<f32> {
            Ok(0.25)
        }
    }
    fn session(eval: Arc<dyn StaticEvaluator>) -> SearchSession {
        SearchSession::new_with_ordering(
            eval,
            SearchNamespace {
                evaluator: "417-toy".into(),
                rules: "research-standard-2p-threefold-goal-first-v1".into(),
                selectivity: "417-toy".into(),
            },
            1_048_576,
            ScoreDomain::LEGACY,
            OrderingProfile::CheapStaticControl,
            false,
            true,
        )
        .unwrap()
    }
    fn branch(alpha: f32) -> (SigmaContext, LmrBranch) {
        let root = SigmaContext::from_prefix(&[]).unwrap();
        let parent = SigmaContext::from_prefix(&[3, 75]).unwrap();
        let action = parent.legal_ids()[0];
        (
            root,
            LmrBranch {
                facts: LmrBranchFacts {
                    hypothesis: "H0",
                    slot: "H0-0",
                    iteration_depth: 5,
                    visit: 1,
                    parent_depth: 3,
                    parent_ply: 2,
                    parent_stm: parent.position().turn,
                    distinct_rank: 4,
                    action,
                    quantum: 0,
                    alpha_beta_bits: [alpha.to_bits(), 1.0f32.to_bits()],
                    tt: None,
                },
                parent,
                path: vec![(0, 3), (1, 75)],
                root_completed: true,
                stages: [None; 3],
            },
        )
    }
    #[test]
    fn lmr417_r_fail_low_omits_confirmation_and_keeps_shallow_depth() {
        let (root, b) = branch(0.5);
        let s = session(Arc::new(Constant));
        let trial = s
            .lmr_trial(
                &root,
                &b,
                LmrArm::ReducedThenConfirm,
                &AtomicBool::new(false),
            )
            .unwrap();
        assert_eq!(trial.trace.child_calls, 1);
        assert!(trial.trace.stages[1].is_none());
        let first = trial.trace.stages[0].unwrap();
        assert!(first.scout.completed);
        assert_eq!(first.scout.bound, Some("Upper"));
        assert_eq!(trial.trace.parent_restored, Some(true));
        let r = trial.result.unwrap();
        assert_eq!(r.completed_depth, 1);
        assert_eq!(r.value.map(f32::to_bits), Some(0.25f32.to_bits()));
        assert_eq!(r.stats.lmr_full_depth_confirmations, 0);
        assert_eq!(s.table.generation, 0);
    }
    #[test]
    fn lmr417_r_fail_high_inherits_tt_order_and_contiguous_cumulative_work() {
        let (root, b) = branch(0.0);
        let s = session(Arc::new(Constant));
        let trial = s
            .lmr_trial(
                &root,
                &b,
                LmrArm::ReducedThenConfirm,
                &AtomicBool::new(false),
            )
            .unwrap();
        assert_eq!(trial.trace.child_calls, 2);
        let first = trial.trace.stages[0].unwrap();
        let second = trial.trace.stages[1].unwrap();
        assert_eq!(first.scout.child_depth, 1);
        assert_eq!(second.scout.child_depth, 2);
        assert_eq!(first.scout.window_bits, second.scout.window_bits);
        assert_eq!(first.nodes_after, Some(second.nodes_before));
        assert_eq!(first.evaluations_after, Some(second.evaluations_before));
        let r = trial.result.unwrap();
        assert_eq!(r.completed_depth, 2);
        assert!(r.stats.tt_order_only > 0); // Exact shallow child key at wrong numeric depth.
        assert_eq!(r.stats.nodes, second.nodes_after.unwrap());
        assert_eq!(r.stats.lmr_full_depth_confirmations, 1);
        assert_eq!(
            trial.trace.final_stats.as_ref().unwrap().nodes,
            r.stats.nodes
        );
        assert_eq!(s.table.generation, 0);
    }
    fn capped(root: &SigmaContext, b: &LmrBranch, cap: u64) -> LmrTrialResult {
        let parent = SigmaContext::from_prefix(&[3, 75]).unwrap();
        assert!(same_history(&parent, b.parent()));
        assert!(same_history(root, &SigmaContext::from_prefix(&[]).unwrap()));
        let limits = SearchLimits {
            max_depth: 5,
            max_nodes: cap,
            time_limit: None,
            tt_entries: 1_048_576,
            use_tt: true,
            use_pvs: true,
        };
        let mut table = Table::persistent(1_048_576).unwrap();
        let mut history = ContinuationHistory::new().unwrap();
        let path = [
            PlayedMove {
                colour: 0,
                action: 3,
            },
            PlayedMove {
                colour: 1,
                action: 75,
            },
        ];
        let mut trace = LmrTrialTrace::new(2, b.facts.action);
        let mut callback = |_: &SearchResult| {};
        let result = search_in_table::<false, true>(
            &parent,
            &Constant,
            &limits,
            &AtomicBool::new(false),
            None,
            SearchInvocation {
                on_completed: &mut callback,
                observation: None,
                trial_trace: Some(&mut trace),
                trial: Some(TrialInvocation {
                    action: b.facts.action,
                    normal_depth: 2,
                    reduced_depth: 1,
                    arm: LmrArm::ReducedThenConfirm,
                    alpha: 0.0,
                    parent_ply: 2,
                    path: &path,
                }),
            },
            (
                &mut table,
                ScoreDomain::LEGACY,
                Some(&mut history),
                false,
                StaticMode::CheapControl,
                (true, LmrMethod::DepthRank),
                (false, ZeroStockApproxMethod::Race, false),
            ),
        );
        LmrTrialResult {
            result,
            trace,
            arm: LmrArm::ReducedThenConfirm,
            normal_child_depth: 2,
            reduced_child_depth: 1,
            window_bits: [0.0f32.to_bits(), next_up(0.0).to_bits()],
        }
    }
    #[test]
    fn lmr417_confirmation_cap_is_shared_and_cannot_publish_shallow_as_normal() {
        let (root, b) = branch(0.0);
        let s = session(Arc::new(Constant));
        let complete = s
            .lmr_trial(
                &root,
                &b,
                LmrArm::ReducedThenConfirm,
                &AtomicBool::new(false),
            )
            .unwrap();
        let shallow_nodes = complete.trace.stages[0].unwrap().nodes_after.unwrap();
        let trial = capped(&root, &b, shallow_nodes);
        assert_eq!(trial.trace.child_calls, 2);
        assert!(trial.trace.stages[0].unwrap().scout.completed);
        assert!(!trial.trace.stages[1].unwrap().scout.completed);
        assert_eq!(trial.trace.stages[1].unwrap().scout.value_bits, None);
        assert_eq!(trial.trace.parent_restored, Some(true));
        let r = trial.result.unwrap();
        assert_eq!(r.stop, StopReason::NodeLimit);
        assert_eq!(r.stats.nodes, shallow_nodes);
        assert_eq!(r.completed_depth, 0);
        assert_eq!(r.value, None);
    }
    #[test]
    fn lmr417_second_stage_error_cancel_and_parent_restore_are_isolated() {
        struct Interrupt {
            calls: AtomicU64,
            at: u64,
            cancel: Arc<AtomicBool>,
            error: bool,
        }
        impl StaticEvaluator for Interrupt {
            fn evaluate(&self, _: &SigmaContext, _: Option<&EvalAccumulator>) -> Result<f32> {
                let n = self.calls.fetch_add(1, Ordering::Relaxed) + 1;
                if n == self.at {
                    if self.error {
                        return Err(SearchError::Evaluation(
                            "417 injected confirmation error".into(),
                        ));
                    }
                    self.cancel.store(true, Ordering::Relaxed);
                }
                Ok(0.25)
            }
        }
        let (root, b) = branch(0.0);
        let complete = session(Arc::new(Constant))
            .lmr_trial(
                &root,
                &b,
                LmrArm::ReducedThenConfirm,
                &AtomicBool::new(false),
            )
            .unwrap();
        let shallow_evals = complete.trace.stages[0].unwrap().evaluations_after.unwrap();
        for error in [false, true] {
            let cancel = Arc::new(AtomicBool::new(false));
            let s = session(Arc::new(Interrupt {
                calls: AtomicU64::new(0),
                at: shallow_evals + 1,
                cancel: cancel.clone(),
                error,
            }));
            let trial = s
                .lmr_trial(&root, &b, LmrArm::ReducedThenConfirm, &cancel)
                .unwrap();
            assert_eq!(trial.trace.child_calls, 2);
            assert!(trial.trace.stages[0].unwrap().scout.completed);
            assert!(!trial.trace.stages[1].unwrap().scout.completed);
            assert_eq!(trial.trace.parent_restored, Some(true));
            assert!(trial.trace.final_stats.is_some());
            if error {
                assert!(trial.result.is_err());
            } else {
                let r = trial.result.unwrap();
                assert_eq!(r.stop, StopReason::Cancelled);
                assert_eq!(r.completed_depth, 0);
                assert_eq!(r.value, None);
            }
            assert_eq!(s.table.generation, 0);
            assert!(same_history(
                &root,
                &SigmaContext::from_prefix(&[]).unwrap()
            ));
        }
    }
    #[test]
    fn lmr417_nrrn_repetitions_are_independent_and_observation_off_keeps_work() {
        let (root, b) = branch(0.0);
        let s = session(Arc::new(Constant));
        let mut results = Vec::new();
        for arm in LMR_ARM_ORDER {
            let t = s
                .lmr_trial(&root, &b, arm, &AtomicBool::new(false))
                .unwrap();
            assert!(t.trace.kernel_elapsed.is_some());
            assert_eq!(t.trace.parent_restored, Some(true));
            let r = t.result.unwrap();
            results.push((
                arm,
                r.value.map(f32::to_bits),
                r.completed_depth,
                r.stats.nodes,
                r.stats.evaluations,
                r.stats.tt_hits,
                r.stats.tt_generation,
                t.trace.child_calls,
            ));
        }
        assert_eq!(results[0], results[3]);
        assert_eq!(results[1], results[2]);
        assert_eq!(s.table.generation, 0);
        let limits = SearchLimits {
            max_depth: 5,
            max_nodes: 20_000,
            time_limit: None,
            tt_entries: 1_048_576,
            use_tt: true,
            use_pvs: true,
        };
        let mut plain = session(Arc::new(Constant));
        let mut observed = session(Arc::new(Constant));
        let mut o = LmrObservation::default();
        let a = plain
            .search(&root, &limits, &AtomicBool::new(false))
            .unwrap();
        let b = observed
            .search_with_lmr_observation(&root, &limits, &AtomicBool::new(false), &mut o)
            .unwrap();
        assert_eq!(a.value.map(f32::to_bits), b.value.map(f32::to_bits));
        assert_eq!(a.action, b.action);
        assert_eq!(a.pv, b.pv);
        assert_eq!(a.stop, b.stop);
        assert_eq!(a.stats.nodes, b.stats.nodes);
        assert_eq!(a.stats.evaluations, b.stats.evaluations);
        assert_eq!(a.stats.tt_hits, b.stats.tt_hits);
        assert_eq!(a.stats.tt_order_only, b.stats.tt_order_only);
        assert_eq!(a.stats.lmr_attempts, b.stats.lmr_attempts);
        assert_eq!(
            a.stats.lmr_full_depth_confirmations,
            b.stats.lmr_full_depth_confirmations
        );
        assert!(o.finished);
        assert!(o.branches().all(|b| b.facts.iteration_depth == 5
            && b.facts.parent_depth == 3
            && b.facts.parent_ply == 2));
    }
    #[test]
    fn lmr417_current_opt_in_refuses_warm_method_incomplete_root_and_path_drift() {
        let (root, mut b) = branch(0.0);
        let limits = SearchLimits {
            max_depth: 5,
            max_nodes: 1,
            time_limit: None,
            tt_entries: 1_048_576,
            use_tt: true,
            use_pvs: true,
        };
        let mut s = session(Arc::new(Constant));
        let mut o = LmrObservation::default();
        s.set_lmr_method(LmrMethod::FixedOne);
        assert!(
            s.search_with_lmr_observation(&root, &limits, &AtomicBool::new(false), &mut o)
                .is_err()
        );
        s.set_lmr_method(LmrMethod::DepthRank);
        s.search(&root, &limits, &AtomicBool::new(false)).unwrap();
        assert!(
            s.search_with_lmr_observation(&root, &limits, &AtomicBool::new(false), &mut o)
                .is_err()
        );
        let fresh = session(Arc::new(Constant));
        b.root_completed = false;
        assert!(
            fresh
                .lmr_trial(&root, &b, LmrArm::Normal, &AtomicBool::new(false))
                .is_err()
        );
        b.root_completed = true;
        b.path[0].0 = 1;
        assert!(
            fresh
                .lmr_trial(&root, &b, LmrArm::Normal, &AtomicBool::new(false))
                .is_err()
        );
        b.path[0].0 = 0;
        b.path.pop();
        assert!(
            fresh
                .lmr_trial(&root, &b, LmrArm::Normal, &AtomicBool::new(false))
                .is_err()
        );
        assert_eq!(fresh.table.generation, 0);
    }
}
