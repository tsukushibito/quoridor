"""Necessary constructor-only migration for existing private Search fixtures."""

import json
from pathlib import Path

import intake
from kernel import once, write

PATHS = [
    Path("crates/quoridor-ai/src") / name
    for name in [
        "continuation360_tests.rs",
        "zero_stock410_tests.rs",
        "zero_stock411_tests.rs",
    ]
]


def main():
    refs = []
    for p in PATHS:
        target = intake.HERE / "before" / p
        if not target.exists():
            target.write_bytes(intake.git("show", intake.BASE + ":" + str(p)))
        before = target.read_text()
        after = once(
            before,
            "        lmr_observation: None,",
            '        lmr_observation: None,\n        #[cfg(feature = "research-diagnostics")]\n        trial_trace: None,',
        )
        write(p, after)
        refs.append(
            {
                "relative": str(p),
                "Git": intake.BASE,
                "before": intake.ref(target),
                "scope": "one cfg-only Search constructor field; assertions and bodies otherwise exact",
            }
        )
    (intake.HERE / "fixture-intake.json").write_text(json.dumps(refs, indent=2) + "\n")
    print(
        "three existing Search literal fixtures migrated by one cfg-only None field each"
    )


if __name__ == "__main__":
    main()
