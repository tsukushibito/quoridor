"""Freeze this leaf's exact private source and original process receipts."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import stat

from fixtures import PATHS
import intake


def freeze(lc, here):
    affinity = os.sched_getaffinity(0)
    os.sched_setaffinity(0, {3})
    try:
        phases, children, failures = [], [], []
        for path in sorted(here.glob("*-v*/result.json")):
            result = json.loads(path.read_text())
            phases.append(intake.ref(path))
            if result["status"] != "PASS":
                failures.append(
                    {
                        "phase": path.parent.name,
                        "original": intake.ref(path),
                        "primary": result["primary"],
                    }
                )
            for check in result["checks"]:
                returned = check["guardian_return"]
                disk_ref = check.get("persisted_process_receipt")
                if disk_ref is None:
                    children.append(
                        {
                            "phase": path.parent.name,
                            "name": check["name"],
                            "status": check["status"],
                            "guardian_return": returned,
                            "persisted_process_receipt": None,
                            "child": "UNKNOWN; no recorded identity",
                        }
                    )
                    continue
                assert intake.ref(Path(disk_ref["path"])) == disk_ref
                disk = json.loads(Path(disk_ref["path"]).read_text())
                facts = returned if returned is not None else disk
                assert facts["direct_child_reaped"] and facts["cleanup_complete"]
                assert facts["handle_closes_complete"] and not facts["remaining"]
                child = facts["child"]
                fresh = lc.process.identity(lc.process.process_info(child["pid"]))
                assert fresh is None or fresh != child
                children.append(
                    {
                        "phase": path.parent.name,
                        "name": check["name"],
                        "status": check["status"],
                        "child": child,
                        "fresh_identity": fresh,
                        "exit_code": facts["exit_code"],
                        "launch_policy": facts["launch_policy"],
                        "direct_child_reaped": facts["direct_child_reaped"],
                        "handles_complete": facts["handle_closes_complete"],
                        "cleanup_complete": facts["cleanup_complete"],
                        "returned_scope": "NULL; disk cleanup only, never synthesized settled return"
                        if returned is None
                        else "original settled guardian return",
                        "returned_mask": None
                        if returned is None
                        else returned.get("signal_mask_restoration"),
                        "returned_persist": None
                        if returned is None
                        else returned.get("final_record_persist"),
                        "disk_mask": disk.get("signal_mask_restoration"),
                        "disk_persist": disk.get("final_record_persist"),
                        "original_seconds_once_nested_excluded": facts["wall_seconds"],
                        "full_log": check["full_log"],
                        "capture_complete_reported": check["capture_complete"],
                        "disk_receipt": disk_ref,
                    }
                )
            assert not (path.parent / "TMP").exists()
        assert not (here / "proof-frame").exists()
        ai = Path("crates/quoridor-ai/src/alphabeta.rs")
        sources = []
        for relative in [
            ai,
            ai.with_name("lmr_observation416.rs"),
            ai.with_name("lmr_observation.rs"),
            Path("crates/quoridor-runner/src/measurement.rs"),
            *PATHS,
        ]:
            before, post = here / "before" / relative, here / "post" / relative
            sources.append(
                {
                    "relative": str(relative),
                    "before": intake.ref(before)
                    if before.exists()
                    else "ABSENT at fixed Git",
                    "post": intake.ref(post)
                    if post.exists()
                    else "ABSENT; retired current runtime module",
                }
            )
        bound = {
            "issue": "quoridor-4lc.417.2",
            "base_Git": intake.BASE,
            "status": "SOURCE_FROZEN; UNBUILT/UNTYPED/UNRUN",
            "source_refs": sources,
            "intake": intake.ref(here / "intake-refs.json"),
            "fixture_intake": intake.ref(here / "fixture-intake.json"),
            "actual_context": intake.ref(here / "actual-context.json"),
            "resume_context": intake.ref(here / "resume-context.json"),
            "final_spec": intake.ref(here / "final-spec-refs.json"),
            "source_readback": intake.ref(here / "actual-source-readback.json"),
            "forward": intake.ref(here / "lmr-internal-sequence417.patch"),
            "inverse": intake.ref(here / "lmr-internal-sequence417.inverse.patch"),
            "static_proof": intake.ref(here / "static-proof.json"),
            "verification_plan": intake.ref(here / "verification-plan.json"),
            "report": intake.ref(here / "report-ja.md"),
            "selected_input": json.loads((here / "intake-refs.json").read_text())[
                "inputs"
            ],
            "Python": "UNCHANGED existing measurement_config owner; exact whole/function hashes in static-proof.json",
            "components_before_gzip": [
                intake.ref(p) for p in sorted((here / "before-gzip").rglob("*.gz"))
            ],
            "managedproduction_Main_Git_index_Cargo_native_Search_model_test_writes_or_execution": 0,
            "review_dispatch": 0,
            "leaf": "same claimant in_progress; Root324 acceptance/backup/close only",
        }
        (here / "source-binding.json").write_text(json.dumps(bound, indent=2) + "\n")
        seen, logical, allocated, files = set(), 0, 0, 0
        for directory, _, names in os.walk(here):
            for p in [Path(directory)] + [Path(directory) / n for n in names]:
                s = p.lstat()
                key = (s.st_dev, s.st_ino)
                if key in seen:
                    continue
                seen.add(key)
                allocated += s.st_blocks * 512
                if stat.S_ISREG(s.st_mode):
                    logical += s.st_size
                    files += 1
        fs = os.statvfs(here)
        result = {
            "issue": "quoridor-4lc.417.2",
            "source_binding": intake.ref(here / "source-binding.json"),
            "actual_source_reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
            "controller": lc.process.identity(lc.process.process_info(os.getpid())),
            "controller_scope": "this metadata-only writer; fresh absence checked after return in admin-STOP",
            "phases": phases,
            "children": children,
            "original_failures_immutable": failures,
            "guarded_child_seconds_once_sum": sum(
                c.get("original_seconds_once_nested_excluded", 0) for c in children
            ),
            "not_total_turn_elapsed_LLM_CPU_or_continuous_family_peak": True,
            "current_source_readers": [],
            "writers": [],
            "children_remaining": [],
            "jobs": [],
            "handles": [],
            "TMP": [],
            "leases": [],
            "owned": [],
            "canonical_hardware_reservation": "NONE; no idle lease, immutable named Git source only",
            "directed_OWN_usage_once": {
                "logical_file_bytes": logical,
                "allocated_inode_bytes": allocated,
                "files": files,
                "dedup_inodes": len(seen),
                "FS_available_bytes": fs.f_bavail * fs.f_frsize,
                "scope": str(here),
                "budget": None,
                "excluded": "this final STOP and later tinyadmin; no assets/target/global walk or oldholding charge/refund",
                "global_actual": "UNKNOWN",
                "decimal_global_limit": 50_000_000_000,
            },
            "native_type_assertions_review_science": "NOT_RUN; Root only",
            "ownership": "417.2 in_progress; Root324 acceptance/backup/close; no author close/backup",
        }
        (here / "source-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "source_STOP": intake.ref(here / "source-STOP.json"),
                    "binding": intake.ref(here / "source-binding.json"),
                    "owned": [],
                }
            )
        )
    finally:
        os.sched_setaffinity(0, affinity)
