"""Sparse current-owner implementation of the fixed Astra 417 specification."""

from pathlib import Path

import intake

HERE = intake.HERE
AI = Path("crates/quoridor-ai/src/alphabeta.rs")
OLD = AI.with_name("lmr_observation416.rs")
NEW = AI.with_name("lmr_observation.rs")


def once(text, before, after):
    assert text.count(before) == 1, before[:140]
    return text.replace(before, after, 1)


def write(path, text):
    target = HERE / "post" / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)


def main():
    text = (HERE / "before" / AI).read_text()
    text = text.replace("lmr_observation416", "lmr_observation")
    text = text.replace(
        "LmrColdProbe,", "LmrArm, LmrTrialResult, LmrTrialStage, LmrTrialTrace,"
    )
    text = once(
        text,
        "    LmrBranch, LmrBranchFacts,",
        "    LMR_ARM_ORDER, LMR_OBSERVATION_PROTOCOL, LmrBranch, LmrBranchFacts,",
    )
    text = once(
        text,
        '                        hypothesis: "",',
        '                        hypothesis: "",\n                        slot: "",',
    )
    text = text.replace(
        "const OBSERVE: bool = false",
        "const OBSERVE: bool = false, const TRACE: bool = false",
    )
    text = text.replace(
        "impl<const OBSERVE: bool> Search<'_, OBSERVE>",
        "impl<const OBSERVE: bool, const TRACE: bool> Search<'_, OBSERVE, TRACE>",
    )
    text = text.replace(
        "fn search_in_table<const OBSERVE: bool>",
        "fn search_in_table<const OBSERVE: bool, const TRACE: bool>",
    )
    text = text.replace("Search::<OBSERVE>", "Search::<OBSERVE,TRACE>")
    text = text.replace("search_in_table::<false>", "search_in_table::<false,false>")
    text = once(
        text,
        "    lmr_observation: Option<&'a mut LmrObservation>,\n}",
        "    lmr_observation: Option<&'a mut LmrObservation>,\n    #[cfg(feature = \"research-diagnostics\")]\n    trial_trace: Option<&'a mut LmrTrialTrace>,\n}",
    )
    text = text.replace(
        "lmr_observation: None,",
        'lmr_observation: None,\n        #[cfg(feature = "research-diagnostics")]\n        trial_trace: None,',
    )
    text = once(
        text,
        "        lmr_observation: invocation.observation,",
        '        lmr_observation: invocation.observation,\n        #[cfg(feature = "research-diagnostics")]\n        trial_trace: invocation.trial_trace,',
    )
    text = once(
        text,
        "    cold: Option<lmr_observation::ColdScout<'a>>,",
        "    trial: Option<lmr_observation::TrialInvocation<'a>>,\n    #[cfg(feature = \"research-diagnostics\")]\n    trial_trace: Option<&'a mut LmrTrialTrace>,",
    )
    text = once(
        text,
        "            cold: None,",
        '            trial: None,\n            #[cfg(feature = "research-diagnostics")]\n            trial_trace: None,',
    )
    text = text.replace("invocation.cold", "invocation.trial")
    start = text.index(
        "        if let Some(cold) = &invocation.trial {\n            // Exactly one internal child/scout;"
    )
    end = text.index("        for depth in 1..=limits.max_depth {", start)
    text = (
        text[:start]
        + """        if let Some(trial) = &invocation.trial {
            let kernel_start = Instant::now();
            let value = match trial.arm {
                LmrArm::Normal => state.child(&mut c,a.as_ref(),trial.action,trial.normal_depth,
                    [trial.alpha,next_up(trial.alpha)],trial.parent_ply+1),
                LmrArm::ReducedThenConfirm => state.reduced_child(&mut c,a.as_ref(),trial.action,
                    [trial.normal_depth,trial.reduced_depth],trial.alpha,trial.parent_ply+1),
            };
            let elapsed=kernel_start.elapsed();
            if let Some(trace)=state.trial_trace.as_deref_mut() {
                trace.kernel_elapsed=Some(elapsed);
                trace.finish_dispatch(&value,&state.stats);
            }
            let value=value?;
            state.control()?;
            result.action=Some(trial.action);
            result.value=Some(value);
            result.completed_depth=if trial.arm==LmrArm::ReducedThenConfirm
                && state.trial_trace.as_ref().is_some_and(|trace| trace.child_calls==1) {
                    trial.reduced_depth
                } else { trial.normal_depth };
            result.pv=vec![trial.action];
            return Ok(());
        }
"""
        + text[end:]
    )
    text = once(
        text,
        "    let start = Instant::now();\n    if limits.max_depth == 0",
        """    #[cfg(feature = "research-diagnostics")]
    if TRACE && (invocation.trial.is_none()
        || invocation.trial_trace.is_none()
        || OBSERVE || invocation.observation.is_some())
    {
        return Err(SearchError::Limits("internal trial/trace ownership mismatch".into()));
    }
    let start = Instant::now();
    if limits.max_depth == 0""",
    )
    text = once(
        text,
        """        self.control()?;
        let mover = c.position().turn;""",
        """        #[cfg(feature = "research-diagnostics")]
        if TRACE && let Some(trace)=self.trial_trace.as_deref_mut() {
            trace.child_start(ply,action,depth,window,&self.stats);
        }
        self.control()?;
        let mover = c.position().turn;""",
    )
    text = once(
        text,
        """        result
    }

    fn safe_race_value(""",
        """        #[cfg(feature = "research-diagnostics")]
        if TRACE && let Some(trace)=self.trial_trace.as_deref_mut() {
            trace.child_return(ply,action,&result,&self.stats);
        }
        result
    }

    fn safe_race_value(""",
    )
    text = once(
        text,
        """        state.table.clear();
        if let Some(history) = state.ordering.as_deref_mut()""",
        """        #[cfg(feature = "research-diagnostics")]
        if TRACE && let Some(trace)=state.trial_trace.as_deref_mut() { trace.parent_restored=Some(false); }
        state.table.clear();
        if let Some(history) = state.ordering.as_deref_mut()""",
    )
    text = once(
        text,
        """    match run {
        Ok(()) => {}""",
        """    #[cfg(feature = "research-diagnostics")]
    if TRACE {
        state.stats.tt_retained_bytes=state.table.retained_bytes();
        state.stats.tt_generation=state.table.generation;
        state.publish_distance_counts();
        if let Some(trace)=state.trial_trace.as_deref_mut() {
            trace.parent_restored=Some(true);
            trace.final_stats=Some(state.stats.clone());
        }
    }
    match run {
        Ok(()) => {}""",
    )
    write(AI, text)
    module = "//! One bounded final-iteration observer and common internal N/R trial.\nuse super::*;\n"
    for name in [
        "stage.rs",
        "selector.rs",
        "trial.rs",
        "trial_tests.rs",
        "selector_tests.rs",
    ]:
        module += (HERE / name).read_text() + "\n"
    write(NEW, module)
    print(
        "fixed D5/d3/ply2 selector and common cumulative-cap N/R implementation composed privately"
    )


if __name__ == "__main__":
    main()
