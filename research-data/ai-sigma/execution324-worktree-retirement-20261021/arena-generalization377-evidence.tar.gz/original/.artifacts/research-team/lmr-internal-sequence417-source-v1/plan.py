"""Prepare Root's necessary software selections; execute no Rust or tests."""

import json

import intake

here = intake.HERE
proof = json.loads((here / "static-proof.json").read_text())
plan = {
    "issue": "quoridor-4lc.417.2",
    "status": "DEFINITIONS_UNBUILT_UNTYPED_UNRUN; Root software only",
    "new": [
        {
            "package": "quoridor-ai",
            "features": ["research-diagnostics"],
            "filter": "lmr417_",
            "expected_definitions": 8,
            "exact_names": proof["new_AI_definitions"],
        },
        {
            "package": "quoridor-runner",
            "features": ["research-diagnostics"],
            "filter": "measurement417_",
            "expected_definitions": 2,
            "exact_names": proof["new_runner_definitions"],
        },
    ],
    "affected": [
        {
            "package": "quoridor-runner",
            "features": ["research-diagnostics"],
            "filter": "measurement416_",
            "expected_definitions": 2,
            "reason": "retained strict opt-in and canonical prefix/history-input owning checks",
        },
        *[
            {
                "package": "quoridor-ai",
                "features": ["research-diagnostics"],
                "filter": name,
                "expected_definitions": 1,
                "reason": "changed private constructor field and common child TRACE=false/error/undo boundary",
            }
            for name in [
                "continuation360_o1_unsigned_child_has_no_context_allocation_on_return_or_error",
                "zero_stock410_error_and_cancel_do_not_publish_leaf_or_change_parent",
                "safe_race411_error_cancel_undo_restore_full_history",
            ]
        ],
    ],
    "software": [
        "research and research-diagnostics compile of affected AI/runner",
        "research and research-diagnostics AI Clippy, affected measurement/runner Clippy under maintained Root job",
        "optimized genuine runner build with research-diagnostics; bind actual image/Build only when real",
    ],
    "expected_new_total": 10,
    "expected_selected_affected_total": 5,
    "native_by_author": 0,
    "old_full_suite_replay": 0,
    "scientific_entry_by_author": 0,
    "review_questions": [
        "target final iteration5/d3/ply2 and eligibility; H0 pre-return reservation; complete-history different-parent and global branch dedup; no refill",
        "canonical prefix+captured path restoration and parent STM/post-TT alpha/next_up/depth/bound sign",
        "one common reduced_child call preserves TT/order/scratch/generation/start/cumulative100K across R confirmation; cap/error leaves final UNKNOWN",
        "independent N/R/R/N trials and raw outer timing/Result-before-question-mark; no original-root extra calls or OFF work",
        "consumer root-D5 gate, null stages, returned depth vs target/protocol, actual calls/node split, nonclock repeat drift retained",
    ],
    "runtime_limits_not_author_entry_permission": {
        "root_calls_max": 12,
        "root_nodes_each": 1_000_000,
        "branches_max": 48,
        "arm_order": ["N1", "R1", "R2", "N2"],
        "arm_trials_max": 192,
        "arm_nodes_total_each": 100_000,
        "top_level_entries_max": 204,
        "root_plus_explicit_child_calls_max": 300,
        "nodes_max": 31_200_000,
        "time_limit": None,
        "refill": False,
        "new_roots": 0,
    },
    "source_only_limits": [
        "Rustfmt parse is not type/native verification; actual assertions may require ordinary owning repair",
        "no guessed new image/Build/model/admission/result; normal child is finite selective-depth estimate, not WDL",
        "actual branch availability/underfill/caps/cost/RSS/stack size/clock resolution/cold cache behavior UNKNOWN until authorized Root collection",
        "source-only software packet does not authorize old416 replay, extra calls or independent review dispatch",
    ],
}
(here / "verification-plan.json").write_text(json.dumps(plan, indent=2) + "\n")
print(json.dumps({"new": 10, "affected": 5, "native": "UNBUILT/UNTYPED/UNRUN"}))
