# 417.2 frozen source handoff — current324 only

最終Astra spec4bd725f2 / immutable Git0252dd5a81ab8e65e92dc8f9b2d2bf90c9fd0beeに対するsource packetです。実source STOP 2026-10-15T14:42:57.502535+00:00。親の完全履歴を区別するH0/H+各2枠、final iteration5/d3/ply2 gate、N1-R1-R2-N2を実装しました。

Nはcommon child depth2一度、Rはbyte-exactのcommon reduced_child[2,1]一度です。R確認は同state/TT/order/scratch/generation/start/counters/累積100Kを共有し、別cold正常探索を呼びません。root D5未完了は全arm UNPERFORMED UNKNOWN、opaque branchも未完了root拒否。fail-low COMPLETEはreturned depth1 / target2と分離。true terminal/fullhistory/TT/LMR式/ordering/score/model/undo/defaultsは変更しません。

7 paths（Alpha、旧416module削除、新lmr_observation module、measurement、既存private Search fixture3のcfg None追加のみ）。旧416独立二scout APIは現役から撤去。Python measurement_configは既に同じ12 cold D5/1M/TT1M設定と完全prefixを厳密検査するため変更不要です。before gzip / exact postimage FileRefsはsource-bindingを参照。古いwhole Alpha/publisherの上書きはしないでください。

Rustfmt/Ruff/Prettier/static forward+inverse/protected/newabsence PASS。AI新8・runner新2、維持するstrict request/input owning2＋constructor/child/error/restore owning3をverification-planに正確なfilters/countsで列挙しました。**UNBUILT/UNTYPED/UNRUN**。作者native/test/Search/model/science/review dispatch0。維持した制御wrapper/guard Pythonは承認内で実行しており、zero実行という表現の対象はalgorithm/native/test/scienceで、制御helperの実行を隠しません。

kernel/wholeは別々のraw ns、各段のdepth/window/parent-view bits/bound/stop/partialworkとreturned depth、N/R反復nonclock全work対応を保存します。source-onlyから費用差・WDL・一般benefitを主張しません。上限204 top-level/300 root+明示child/31.2Mは実使用と別。OFFはconst false/false、追加snapshot/scan/heap/pernodeclock/counterwalkなし。actual stack/RSS/coldness/clockresolution UNKNOWN。

原compose-v2表記誤検査FAILED、v3凍結Python関数断片を含むlint選択FAILEDを保持。後者のbefore bytesはGit exact、対象helper限定で解消。原capture/returned-vs-disk/masks/costはsource-STOPに保持し、成功へ書き換えていません。source guarded child wall once-sum 8.736492176001775s（nested除外、全LLM/turn費ではない）。

実source reader/children/jobs/handles/TMP/leases/owned[]、current metadata/controllerの返却後fresh absenceはadmin-STOP/delivery evidenceへ別記します。OWN usage一度: logical 2078642B / allocated 2650112B、最終STOP以降tinyadmin除外、global actual UNKNOWN。資源actual CPU3/guardian7/512MiB family/G0/no_new_privs、selected topology/readbackと原guard receipt保持、idle/canonical/hardware leaseなし。

417.2は同claimantのin_progressのままです。明示clarificationどおり、受入れ・Beads status/backup/closeは324のみ。source freezeで新scienceを許可せず、Rootの必要software/限定review/真正imageへ引き渡します。混合/learner全prep-pipeline/323 USERPAUSEと旧RAW/FAILED/fees/UNKNOWNは不変。Policyへcopyなし、ACK不要。

```json
{
  "forward": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/lmr-internal-sequence417-source-v1/lmr-internal-sequence417.patch",
    "sha256": "41e10fd0d07f9fb300c660272acc826e30b931af7db3007f05f07d23a672a8c2",
    "bytes": 113324,
    "mode": "0644"
  },
  "inverse": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/lmr-internal-sequence417-source-v1/lmr-internal-sequence417.inverse.patch",
    "sha256": "fe304ad0c3aab484cba075a7977368079e631cc230419e094beafcb7a571e524",
    "bytes": 113339,
    "mode": "0644"
  },
  "static_proof": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/lmr-internal-sequence417-source-v1/static-proof.json",
    "sha256": "256b9f6f11c653612bd4c3f4fb3e0a6b7e6e56c52b9094d23be756ab05ca7904",
    "bytes": 3931,
    "mode": "0644"
  },
  "verification_plan": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/lmr-internal-sequence417-source-v1/verification-plan.json",
    "sha256": "6bbc7a7482387881362fbf188d8a66de8553049f13d2da62309d2b230a26971e",
    "bytes": 4716,
    "mode": "0644"
  },
  "report": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/lmr-internal-sequence417-source-v1/report-ja.md",
    "sha256": "5e7b2bd0cd2b49233beb537916a511a100b5868de99b035f28d77a251929e2b7",
    "bytes": 7980,
    "mode": "0644"
  },
  "source_binding": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/lmr-internal-sequence417-source-v1/source-binding.json",
    "sha256": "146d64b549b7ab64c89a454e78fb1a0cf1eaaf35dc00b9a2e10f3bde326d0011",
    "bytes": 10780,
    "mode": "0644"
  },
  "source_STOP": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/lmr-internal-sequence417-source-v1/source-STOP.json",
    "sha256": "342887a9a5f864e337fc68492549e252f0ded7efb85940049d499262e8173f66",
    "bytes": 63974,
    "mode": "0644"
  }
}
```
