# 417.2：内側の枝・連続R手順のsource handoff

固定Git `0252dd5a81ab8e65e92dc8f9b2d2bf90c9fd0bee` とAstra最終spec `4bd725f2…` に対する私有薄差分です。Main・managed production・Git/index・Cargo・モデル・native/Search・科学実行は変更／実行していません。source/formatter/static証明と、必要なRust定義の準備のみです。新定義は **UNBUILT/UNTYPED/UNRUN**。417.2は同claimantのin_progressを保ち、受入れ・backup・closeは324が行います。

現役observerを `lmr_observation.rs` へ整理し、旧416二本の独立scout APIと旧moduleを撤去しました。旧image/Git/RAWは不変です。入口は既存 `observe_lmr` と `SearchSession::search_with_lmr_observation` を再用し、出力版はAI正本の `LMR_OBSERVATION_PROTOCOL = internal-lmr-sequence417-v1` です。Python `measurement_config` は既にdistinct cold 12/D5/1M/TT1M/Control/depth_rank/PVS・完全prefix・他observer/approx OFFを厳密に扱うため変更不要です。既存runnerの型・設定・canonical replay/admissionも保持しました。

## 選択・共通kernel

iteration5 / parent d3 / ply2 / eligibleだけを採取します。H0はq0/rank4..8を返値前に予約し、H+は実q1の完了shallow fail-lowで採取します。各仮説は異なる親の完全履歴から2枠、全4枠では完全履歴+actionを重複除去します。H0/H+間の同親・別actionは許可します。`same_history` の盤面・rules・ply・全aggregate counts照合は現正本とbyte exactです。比較は保持済み最大4枝のみで、訪問全体の集合は作りません。枠が満ちた後は同履歴比較をせず、full-slot skipとして別計上します。coverageの分母は対象gate内のrank4..8/9..15/16..31/32+ × q0/q1です。

H0-0/H0-1/H+-0/H+-1を保持し、中断枠は交換しません。rootがD5を完了していなければ、部分slotを残したまま全armをUNPERFORMED UNKNOWNにします。opaque branchもroot完了資格を保持し、直接trial APIから未完了rootを迂回できないようにしています。root完了時の最大4 flag更新は診断ONだけです。

追加APIは `LmrArm::{Normal, ReducedThenConfirm}`、`LMR_ARM_ORDER`、`SearchSession::lmr_trial(&self, root, branch, arm, cancel) -> Result<LmrTrialResult>` です。枝ごとにN1→R1→R2→N2。各armでcanonical root+captured colour/action pathから親を再構成し、保存された完全履歴と照合します。親STM/post-TT alpha/ply2を維持し、窓は `[alpha,next_up(alpha)]`。新規TT1M、continuation/killer、scratch、accumulator、共通Search stateを使用し、終了後に局所所有物をdropします。元sessionのTT/historyは不変です。

Nは既存`child` depth2を一度、Rは既存`reduced_child` `[2,1]`を一度呼びます。`reduced_child` のbodyはbyte exactです。Rのshallow>alpha時だけ、同じstate/TT/order/scratch/generation/start/counters/累積100Kでdepth2 scoutを確認します。budget reset・別cold confirmation・parent full-window・別negamaxはありません。失敗時にもkernel時計を保持するため、Resultを受けてから計時を終え、その後に伝播します。

root observerとtrial stageは同じ`LmrStage::record_return`で親視点bits/bound/stop/errorを分類します。trialは対象parent/actionの固定2段だけを保持し、枝選択やcoverageを行いません。shallow fail-lowのprotocol COMPLETEはreturned_child_depth=1 / normal_target=2と別記します。確認がcap/cancel/errorなら浅い完了段を残し、final bits/bound/depthはnull、protocol UNKNOWNです。未入場段はnullです。

## 計時・会計・OFF

kernelのraw nsは共通親準備・child storage作成後、N/R dispatch直前からそのreturn直後までです。Rはshallowと必要確認の連続時間を含みます。wholeのraw nsはcallerからarm関数を呼ぶ直前から再構成・割当・kernel・復元検査・局所dropを終えたreturn直後まで。JSON整形／出力と返却recordの後日のdropは外です。既存Search elapsedは別名のまま保存し、内包時計を足しません。whole−kernelを純粋初期化費とは呼びません。OS/model/allocator coldnessと時計分解能はUNKNOWNです。

N1/N2・R1/R2はnonclock結果・全work・段数／段内容の対応を保存し、差はDIFFERENT、未完了はUNKNOWNにします。4 raw値を削除しません。元warm shallow対R shallow、N対R final、N対R confirmation、H0元normal対Nを分けます。PVは親actionだけでfull child PVではありません。

root、arm関数entry、common invocation、明示child calls、R確認条件／開始／完了／完了fail-lowで未使用／中断不明を分離します。rootとarmの既知nodes/evalsは別集計、stage workはarm内包で再加算しません。未開始・未知workを0件の完了仕事へ置換しません。上限204 top-level / 300 root+明示child / 31.2M nodesは上限fieldとして実使用と分離します。

通常経路はconst `<false,false>`、元root観測は`<true,false>`、trialのみ`<false,true>`。TRACE hooks・時計・stats cloneはcfg research-diagnosticsかつTRACEのみです。OFFへsnapshot/履歴scan/heap/毎node時計/counter walkは足しません。Searchにcfg-onlyのOption trace参照が一つ増えるため、既存fixture3箇所にも`None`一行ずつを追加しました。実stackサイズ・cache/RSS・コピー／計測費の孤立値は未計測UNKNOWNです。観測・snapshotや同一frame記録の実費は今回のwhole/kernelに含まれます。

## 静的根拠と残作業

`static-proof.json` は厳密forward→inverse、旧module復元／新module ABSENT復元、必要before gzip、保護関数、fixtureの追加field以外byte exact、Python不変を結びます。root_depth/reduced_child/lmr_allowed/ordering/control/enter/TT key/approx/safe/distance/PV、通常反復loopをbyte保護。通常childはTRACE hooksを除きexact、negamaxはslot label以外exactです。measurementのcanonical input/replay/validate/validate_returnとcompleted callbackもexact。通常work JSONは同じfield/式/代入を一つの`observed_work`へ移し、Error時に偽SearchResultを作りません。

新AI8+runner2定義を用意しました。selectorの最終gate・異親完全履歴・予約中断・全枠重複、R1段／2段・状態継承・累積cap・確認中error/cancel/undo・NRRN独立反復・OFF work対応・warm/method/path拒否、出力depth/bound/null/非時計work driftを扱います。正確なfeature/filter/countと本当に必要なaffected選択は`verification-plan.json`。Rootだけがcompile、必要assertions、research/diagnostics/runner Clippy、release/genuineimageと限定レビューを実施します。source clearから実行結果／速度／WDL／因果は導きません。

原authoring失敗を保存しています。多重同一path apply_patchは適用前に拒否（子／変更なし）。compose-v2 static proofは`1_000_000`表記を仮定した誤りで停止し、AST整数値確認へ修正。compose-v3はstatic proof PASS後、lint対象globが凍結した関数断片を含み、外部owner名のF821で停止しました。断片のbyte不変はGitとの比較で確認済みです。lint/formatterの対象を今回手書きhelperだけへ狭め、原FAILED/capture/costを保持します。native失敗／成功とは扱いません。

source/controlの実reader/child directwait/reap・fresh PID/start/boot・handles・TMP・返却対diskのmask差は`source-STOP.json`に保存します。現在controllerの終了は返却後の`admin-STOP.json`で別確認します。lease予約や全host静穏の主張はしません。OWN usageは終了時一度だけ、global actualはUNKNOWN。Beads/backup/closeはRoot所有、parentやpaused scopeへ操作しません。
