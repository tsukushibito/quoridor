"""Read frozen final Astra spec and bound verification exactly once."""

import json
from pathlib import Path

import intake

HERE = intake.HERE
directory = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/lmr-internal-sequence417-analysis-v1"
)
path = directory / "spec-ja.md"
before = intake.ref(path)
assert (
    before["sha256"]
    == "4bd725f25597e661e8665163be1c4c010d99d0fd57be1ab13a7d8894c87f6745"
    and before["bytes"] == 10703
    and before["mode"] == "0644"
)
print("FINAL_ASTRA_SPEC\n" + path.read_text())
assert intake.ref(path) == before
binding = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-internal-sequence417-v1/spec-binding.json"
)
binding_ref = intake.ref(binding)
data = json.loads(binding.read_text())
assert intake.ref(binding) == binding_ref


def refs(value):
    if isinstance(value, dict):
        if {"path", "sha256", "bytes", "mode"} <= set(value):
            yield value
        for child in value.values():
            yield from refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from refs(child)


verification = next(
    r for r in refs(data) if r["path"] == str(directory / "verification.json")
)
assert intake.ref(Path(verification["path"])) == verification
print("FINAL_VERIFICATION\n" + Path(verification["path"]).read_text())
assert intake.ref(Path(verification["path"])) == verification
(HERE / "final-spec-refs.json").write_text(
    json.dumps(
        {
            "spec": before,
            "Root_binding": binding_ref,
            "verification": verification,
            "ownership_clarification": "assignee retained in_progress; acceptance/leaf close/backup Root324 only",
        },
        indent=2,
    )
    + "\n"
)
