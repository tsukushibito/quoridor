"""Read-only Beads resolution and stopped-source metadata handoff preparation."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess

import intake


def main():
    here = intake.HERE
    for name, expected in [
        (
            "source-binding.json",
            ("146d64b549b7ab64c89a454e78fb1a0cf1eaaf35dc00b9a2e10f3bde326d0011", 10780),
        ),
        (
            "source-STOP.json",
            ("342887a9a5f864e337fc68492549e252f0ded7efb85940049d499262e8173f66", 63974),
        ),
    ]:
        actual = intake.ref(here / name)
        assert (actual["sha256"], actual["bytes"], actual["mode"]) == (
            *expected,
            "0644",
        )
    binding = json.loads((here / "source-binding.json").read_text())
    stop = json.loads((here / "source-STOP.json").read_text())
    for key in ["forward", "inverse", "static_proof", "verification_plan", "report"]:
        assert intake.ref(Path(binding[key]["path"])) == binding[key]
    resolved = {}
    for issue, label in [
        ("quoridor-4lc.417.2", "own-current"),
        ("quoridor-4lc.324", "recipient-current"),
    ]:
        result = subprocess.run(
            ["bash", "scripts/dev/beads.sh", "show", issue, "--json"],
            cwd=intake.ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        (here / (label + ".json")).write_text(result.stdout)
        (record,) = json.loads(result.stdout)
        resolved[issue] = {k: record.get(k) for k in ["id", "assignee", "status"]}
    own = resolved["quoridor-4lc.417.2"]
    assert (
        own["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
        and own["status"] == "in_progress"
    )
    target = resolved["quoridor-4lc.324"]["assignee"]
    assert target == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
    (here / "recipient-resolution.json").write_text(
        json.dumps(resolved, indent=2) + "\n"
    )
    refs = {
        key: binding[key]
        for key in ["forward", "inverse", "static_proof", "verification_plan", "report"]
    }
    refs.update(
        source_binding=intake.ref(here / "source-binding.json"),
        source_STOP=intake.ref(here / "source-STOP.json"),
    )
    usage = stop["directed_OWN_usage_once"]
    text = f"""# 417.2 frozen source handoff — current324 only

最終Astra spec4bd725f2 / immutable Git{intake.BASE}に対するsource packetです。実source STOP {stop["actual_source_reader_writer_STOP"]}。親の完全履歴を区別するH0/H+各2枠、final iteration5/d3/ply2 gate、N1-R1-R2-N2を実装しました。

Nはcommon child depth2一度、Rはbyte-exactのcommon reduced_child[2,1]一度です。R確認は同state/TT/order/scratch/generation/start/counters/累積100Kを共有し、別cold正常探索を呼びません。root D5未完了は全arm UNPERFORMED UNKNOWN、opaque branchも未完了root拒否。fail-low COMPLETEはreturned depth1 / target2と分離。true terminal/fullhistory/TT/LMR式/ordering/score/model/undo/defaultsは変更しません。

7 paths（Alpha、旧416module削除、新lmr_observation module、measurement、既存private Search fixture3のcfg None追加のみ）。旧416独立二scout APIは現役から撤去。Python measurement_configは既に同じ12 cold D5/1M/TT1M設定と完全prefixを厳密検査するため変更不要です。before gzip / exact postimage FileRefsはsource-bindingを参照。古いwhole Alpha/publisherの上書きはしないでください。

Rustfmt/Ruff/Prettier/static forward+inverse/protected/newabsence PASS。AI新8・runner新2、維持するstrict request/input owning2＋constructor/child/error/restore owning3をverification-planに正確なfilters/countsで列挙しました。**UNBUILT/UNTYPED/UNRUN**。作者native/test/Search/model/science/review dispatch0。維持した制御wrapper/guard Pythonは承認内で実行しており、zero実行という表現の対象はalgorithm/native/test/scienceで、制御helperの実行を隠しません。

kernel/wholeは別々のraw ns、各段のdepth/window/parent-view bits/bound/stop/partialworkとreturned depth、N/R反復nonclock全work対応を保存します。source-onlyから費用差・WDL・一般benefitを主張しません。上限204 top-level/300 root+明示child/31.2Mは実使用と別。OFFはconst false/false、追加snapshot/scan/heap/pernodeclock/counterwalkなし。actual stack/RSS/coldness/clockresolution UNKNOWN。

原compose-v2表記誤検査FAILED、v3凍結Python関数断片を含むlint選択FAILEDを保持。後者のbefore bytesはGit exact、対象helper限定で解消。原capture/returned-vs-disk/masks/costはsource-STOPに保持し、成功へ書き換えていません。source guarded child wall once-sum {stop["guarded_child_seconds_once_sum"]}s（nested除外、全LLM/turn費ではない）。

実source reader/children/jobs/handles/TMP/leases/owned[]、current metadata/controllerの返却後fresh absenceはadmin-STOP/delivery evidenceへ別記します。OWN usage一度: logical {usage["logical_file_bytes"]}B / allocated {usage["allocated_inode_bytes"]}B、最終STOP以降tinyadmin除外、global actual UNKNOWN。資源actual CPU3/guardian7/512MiB family/G0/no_new_privs、selected topology/readbackと原guard receipt保持、idle/canonical/hardware leaseなし。

417.2は同claimantのin_progressのままです。明示clarificationどおり、受入れ・Beads status/backup/closeは324のみ。source freezeで新scienceを許可せず、Rootの必要software/限定review/真正imageへ引き渡します。混合/learner全prep-pipeline/323 USERPAUSEと旧RAW/FAILED/fees/UNKNOWNは不変。Policyへcopyなし、ACK不要。

```json
{json.dumps(refs, ensure_ascii=False, indent=2)}
```
"""
    (here / "handoff-ja.md").write_text(text)
    print(
        json.dumps(
            {
                "recipient": target,
                "own": own,
                "source_UTC": stop["actual_source_reader_writer_STOP"],
                "prepared_UTC": datetime.now(timezone.utc).isoformat(),
                "handoff": str(here / "handoff-ja.md"),
            }
        )
    )


if __name__ == "__main__":
    main()
