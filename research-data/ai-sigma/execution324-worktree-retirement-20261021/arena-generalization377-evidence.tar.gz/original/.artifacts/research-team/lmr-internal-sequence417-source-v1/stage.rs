#[derive(Clone, Copy, Debug)]
pub struct LmrStage {
    pub child_depth: u16,
    pub window_bits: [u32; 2],
    pub value_bits: Option<u32>,
    pub bound: Option<&'static str>,
    pub completed: bool,
    pub stop: Option<StopReason>,
    pub error: bool,
}
impl LmrStage {
    fn record_return(&mut self, result: &NodeResult<f32>) {
        self.completed = false;
        self.value_bits = None;
        self.bound = None;
        self.stop = None;
        self.error = false;
        match result {
            Ok(value) => {
                self.completed = true;
                self.value_bits = Some(value.to_bits());
                self.bound = Some(if *value <= f32::from_bits(self.window_bits[0]) {
                    "Upper"
                } else if *value >= f32::from_bits(self.window_bits[1]) {
                    "Lower"
                } else {
                    "Exact"
                });
            }
            Err(Interrupted::Stop(reason)) => self.stop = Some(*reason),
            Err(Interrupted::Error(_)) => self.error = true,
        }
    }
}
