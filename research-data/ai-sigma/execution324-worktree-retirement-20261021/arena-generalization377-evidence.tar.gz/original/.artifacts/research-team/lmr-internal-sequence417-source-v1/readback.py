"""One actual source child affinity/NNP/RSS snapshot, not a performance job."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import resource

import intake

status = dict(
    line.split(":", 1)
    for line in Path("/proc/self/status").read_text().splitlines()
    if ":" in line
)
assert os.sched_getaffinity(0) == {3}
assert status["NoNewPrivs"].strip() == "1"
assert os.environ["CUDA_VISIBLE_DEVICES"] == ""
assert os.environ["OMP_NUM_THREADS"] == "1"
result = {
    "observed_UTC": datetime.now(timezone.utc).isoformat(),
    "worker_actual_affinity": [3],
    "NoNewPrivs": 1,
    "current_RSS": status["VmRSS"].strip(),
    "child_peak_RSS_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "scope": "one child instantaneous readback/its peak only; not continuous whole-family peak",
    "GPU": 0,
    "family_RSS_budget_bytes": 512 * 1024**2,
    "host_reserve_bytes": 4 * 1024**3,
    "control": "maintained CycleResources/process.execute port; no Go/Node AS512",
}
(intake.HERE / "actual-source-readback.json").write_text(
    json.dumps(result, indent=2) + "\n"
)
print(json.dumps(result))
