/// Independent procedures, not new LMR methods or namespaces.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LmrArm {
    Normal,
    ReducedThenConfirm,
}
impl LmrArm {
    pub fn name(self) -> &'static str {
        match self {
            Self::Normal => "N",
            Self::ReducedThenConfirm => "R",
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct LmrTrialStage {
    pub scout: LmrStage,
    pub nodes_before: u64,
    pub nodes_after: Option<u64>,
    pub evaluations_before: u64,
    pub evaluations_after: Option<u64>,
}
pub struct LmrTrialTrace {
    pub stages: [Option<LmrTrialStage>; 2],
    pub child_calls: usize,
    pub kernel_elapsed: Option<Duration>,
    pub final_stats: Option<SearchStats>,
    pub parent_restored: Option<bool>,
    child_ply: usize,
    action: u16,
}
impl LmrTrialTrace {
    fn new(parent_ply: usize, action: u16) -> Self {
        Self {
            stages: [None; 2],
            child_calls: 0,
            kernel_elapsed: None,
            final_stats: None,
            parent_restored: None,
            child_ply: parent_ply + 1,
            action,
        }
    }
    pub(super) fn child_start(
        &mut self,
        ply: usize,
        action: u16,
        depth: u16,
        window: [f32; 2],
        stats: &SearchStats,
    ) {
        if ply != self.child_ply || action != self.action {
            return;
        }
        assert!(
            self.child_calls < 2,
            "one direct scout or shallow plus conditional confirmation"
        );
        self.stages[self.child_calls] = Some(LmrTrialStage {
            scout: LmrStage {
                child_depth: depth,
                window_bits: window.map(f32::to_bits),
                value_bits: None,
                bound: None,
                completed: false,
                stop: None,
                error: false,
            },
            nodes_before: stats.nodes,
            nodes_after: None,
            evaluations_before: stats.evaluations,
            evaluations_after: None,
        });
        self.child_calls += 1;
    }
    pub(super) fn child_return(
        &mut self,
        ply: usize,
        action: u16,
        result: &NodeResult<f32>,
        stats: &SearchStats,
    ) {
        if ply != self.child_ply || action != self.action {
            return;
        }
        let stage = self.stages[self.child_calls - 1]
            .as_mut()
            .expect("started parent scout");
        stage.nodes_after = Some(stats.nodes);
        stage.evaluations_after = Some(stats.evaluations);
        stage.scout.record_return(result);
    }
    pub(super) fn finish_dispatch(&mut self, result: &NodeResult<f32>, stats: &SearchStats) {
        // Early control/make errors can return before the normal child epilogue.
        // The dispatch Result still classifies that entered stage without a clock.
        if self.child_calls > 0
            && self.stages[self.child_calls - 1]
                .as_ref()
                .is_some_and(|s| s.nodes_after.is_none())
        {
            self.child_return(self.child_ply, self.action, result, stats);
        }
    }
}

pub(super) struct TrialInvocation<'a> {
    pub(super) action: u16,
    pub(super) normal_depth: u16,
    pub(super) reduced_depth: u16,
    pub(super) arm: LmrArm,
    pub(super) alpha: f32,
    pub(super) parent_ply: usize,
    pub(super) path: &'a [PlayedMove],
}
pub struct LmrTrialResult {
    /// Incomplete/error results never supply a completed normal-depth value.
    pub result: Result<SearchResult>,
    pub trace: LmrTrialTrace,
    pub arm: LmrArm,
    pub normal_child_depth: u16,
    pub reduced_child_depth: u16,
    pub window_bits: [u32; 2],
}
impl SearchSession {
    fn observation_compatible(&self, limits: &SearchLimits) -> bool {
        self.static_enabled == StaticMode::CheapControl
            && self.lmr
            && self.lmr_method == LmrMethod::DepthRank
            && !self.ordering_diagnostics
            && self.zero_stock_approx_min_root_walls.is_none()
            && !self.zero_stock_approx_effective
            && !self.zero_stock_safe_race
            && self.table.slots.len() == 1_048_576
            && limits.tt_entries == 1_048_576
            && limits.use_pvs
            && limits.use_tt
            && limits.time_limit.is_none()
            && limits.max_depth == 5
            && limits.max_nodes > 0
            && limits.max_nodes <= 1_000_000
    }
    pub fn search_with_lmr_observation(
        &mut self,
        root: &SigmaContext,
        limits: &SearchLimits,
        cancel: &AtomicBool,
        observation: &mut LmrObservation,
    ) -> Result<SearchResult> {
        if !self.observation_compatible(limits) || observation.used || self.table.generation != 0 {
            return Err(SearchError::Limits("LMR observation requires fresh Control/TT1M/depth_rank, bounded D5, approximation OFF".into()));
        }
        observation.used = true;
        let mut callback = |_: &SearchResult| {};
        let result = search_in_table::<true, false>(
            root,
            self.evaluator.as_ref(),
            limits,
            cancel,
            None,
            SearchInvocation {
                on_completed: &mut callback,
                observation: Some(&mut *observation),
                trial: None,
                trial_trace: None,
            },
            (
                &mut self.table,
                self.score_domain,
                self.ordering.as_mut(),
                false,
                StaticMode::CheapControl,
                (true, LmrMethod::DepthRank),
                (false, self.zero_stock_approx_method, false),
            ),
        );
        observation.finish(&result);
        result
    }

    /// One cold N or R procedure. R uses the existing reduced_child owner in
    /// ONE invocation/state: its normal-depth confirmation inherits shallow
    /// TT/ordering/scratch and the same cumulative cap and cancellation token.
    pub fn lmr_trial(
        &self,
        root: &SigmaContext,
        branch: &LmrBranch,
        arm: LmrArm,
        cancel: &AtomicBool,
    ) -> Result<LmrTrialResult> {
        let limits = SearchLimits {
            max_depth: 5,
            max_nodes: 100_000,
            time_limit: None,
            tt_entries: 1_048_576,
            use_tt: true,
            use_pvs: true,
        };
        if !self.observation_compatible(&limits) {
            return Err(SearchError::Limits(
                "incompatible internal LMR trial".into(),
            ));
        }
        if !branch.root_completed
            || branch.facts.iteration_depth != 5
            || branch.facts.parent_depth != 3
            || branch.facts.parent_ply != 2
            || branch.facts.quantum > 1
            || !f32::from_bits(branch.facts.alpha_beta_bits[0]).is_finite()
        {
            return Err(SearchError::Limits(
                "trial requires final D5, parent d3/ply2 and actual q0/1".into(),
            ));
        }
        let mut parent = root.clone();
        for &(colour, action) in &branch.path {
            if parent.position().turn != colour {
                return Err(SearchError::Root("captured path mover mismatch".into()));
            }
            parent = parent.play(action)?;
        }
        if !same_history(&parent, &branch.parent)
            || parent.terminal_value().is_some()
            || branch.path.len() != branch.facts.parent_ply
        {
            return Err(SearchError::Root(
                "trial parent/path/fullhistory mismatch".into(),
            ));
        }
        let normal_depth = branch.normal_child_depth();
        let reduced_depth = branch.reduced_child_depth();
        let alpha = f32::from_bits(branch.facts.alpha_beta_bits[0]);
        let mut table = Table::persistent(1_048_576)?;
        let mut history = ContinuationHistory::new()?;
        let path: Vec<_> = branch
            .path
            .iter()
            .map(|&(colour, action)| PlayedMove { colour, action })
            .collect();
        let mut callback = |_: &SearchResult| {};
        let mut trace = LmrTrialTrace::new(branch.facts.parent_ply, branch.facts.action);
        let result = search_in_table::<false, true>(
            &parent,
            self.evaluator.as_ref(),
            &limits,
            cancel,
            None,
            SearchInvocation {
                on_completed: &mut callback,
                observation: None,
                trial_trace: Some(&mut trace),
                trial: Some(TrialInvocation {
                    action: branch.facts.action,
                    normal_depth,
                    reduced_depth,
                    arm,
                    alpha,
                    parent_ply: branch.facts.parent_ply,
                    path: &path,
                }),
            },
            (
                &mut table,
                self.score_domain,
                Some(&mut history),
                false,
                StaticMode::CheapControl,
                (true, LmrMethod::DepthRank),
                (false, self.zero_stock_approx_method, false),
            ),
        );
        // Caller whole boundary includes these drops, not just kernel time.
        drop(table);
        drop(history);
        drop(path);
        drop(parent);
        Ok(LmrTrialResult {
            result,
            trace,
            arm,
            normal_child_depth: normal_depth,
            reduced_child_depth: reduced_depth,
            window_bits: [alpha.to_bits(), next_up(alpha).to_bits()],
        })
    }
}
