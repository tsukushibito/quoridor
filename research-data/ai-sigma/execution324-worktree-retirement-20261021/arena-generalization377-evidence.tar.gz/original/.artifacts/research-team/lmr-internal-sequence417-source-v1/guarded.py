"""Existing finite source port, private named objects and scoped CPU admission."""

from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path("/workspaces/quoridor")
HERE = Path(__file__).resolve().parent
loader = importlib.util.spec_from_file_location(
    "retire413_lc", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
OUT = HERE / sys.argv[1]
OUT.mkdir()
TMP = OUT / "TMP"
TMP.mkdir()
commands = json.loads((HERE / (sys.argv[1] + "-commands.json")).read_text())
env = {
    **os.environ,
    "CUDA_VISIBLE_DEVICES": "",
    "OMP_NUM_THREADS": "1",
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": str(TMP),
    "NODE_OPTIONS": "--max-old-space-size=128",
    "NODE_DISABLE_COMPILE_CACHE": "1",
}
spec = {
    "kind": "software",
    "cwd": str(ROOT),
    "env": env,
    "limits": {"worker_cpu": 3, "guardian_cpu": 7, "log_B": 2 * 1024**2},
    "command_timeout_seconds": 120,
}
result = {
    "status": "ATTEMPTED",
    "checks": [],
    "primary": None,
    "canonical_lease": "NONE: private named immutable objects only",
    "storage_budget": None,
}
affinity = os.sched_getaffinity(0)
try:
    assert {3, 7} <= affinity, "declared source CPUs unavailable"
    physical = []
    siblings = set()
    for cpu in (3, 7):
        base = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        physical.append(
            [
                (base / name).read_text().strip()
                for name in ("physical_package_id", "core_id")
            ]
        )
        for group in (base / "thread_siblings_list").read_text().strip().split(","):
            bounds = [int(n) for n in group.split("-")]
            siblings.update(range(bounds[0], bounds[-1] + 1))
    assert physical[0] != physical[1], "source/guardian share physical core"
    assert lc.process.available_memory() >= 4 * 1024**3 + 512 * 1024**2
    # One instantaneous selected-core peer check, not a globalquiet gate or lease.
    conflicts = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            args = (
                (entry / "cmdline")
                .read_bytes()
                .replace(b"\0", b" ")
                .decode(errors="replace")
            )
            allowed = os.sched_getaffinity(int(entry.name))
        except (OSError, ProcessLookupError):
            continue
        if (
            len(allowed) <= 4
            and allowed & siblings
            and (
                "quoridor" in args
                or Path(args.split(" ")[0]).name in {"cargo", "rustc", "cc1plus"}
            )
        ):
            conflicts.append(
                {
                    "identity": lc.process.identity(
                        lc.process.process_info(int(entry.name))
                    ),
                    "allowed_CPUs": sorted(allowed),
                    "command_prefix": args[:240],
                }
            )
    result.update(
        physical_cpu_identities=physical,
        physical_sibling_CPUs=sorted(siblings),
        selected_core_pinned_peers=conflicts,
        admission_observed_UTC=datetime.now(timezone.utc).isoformat(),
        availability_scope="available affinity/distinct topology/RAM plus instantaneous no narrow pinned research peer on selected physical siblings; no futurequiet/allhost claim",
    )
    assert not conflicts, "selected physical source/guardian peer active"
    os.sched_setaffinity(0, {7})
    result["guardian_actual_affinity_while_guarding"] = sorted(os.sched_getaffinity(0))
    assert os.sched_getaffinity(0) == {7}
    with lc.process.cancellation_signals():
        for name, argv in commands:
            resources = lc.process.CycleResources(
                {"max_memory_bytes": 512 * 1024**2, "host_ram_reserve": 4 * 1024**3},
                OUT,
                time.monotonic() + 120,
            )

            def execute(*args, **kwargs):
                return lc.process.execute(*args, **kwargs, no_new_privs=True)

            lc.command(
                spec,
                {
                    "name": name,
                    "role": "software",
                    "argv": [sys.executable if a == "@PYTHON@" else a for a in argv],
                },
                OUT,
                resources,
                executor=execute,
                ledger=result["checks"],
            )
    result["status"] = "PASS"
except BaseException as error:
    result.update(status="FAILED", primary=lc.error_fact(error))
finally:
    os.sched_setaffinity(0, affinity)
    remaining = list(TMP.iterdir())
    if not remaining:
        TMP.rmdir()
    result.update(
        reader_STOP=datetime.now(timezone.utc).isoformat(),
        TMP_remaining=[str(p) for p in remaining],
        original_affinity=sorted(affinity),
        restored_affinity=sorted(os.sched_getaffinity(0)),
    )
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    if sys.argv[2:] == ["--freeze"] and result["status"] == "PASS":
        import finish

        finish.freeze(lc, HERE)
print(
    json.dumps(
        {k: result[k] for k in ("status", "primary", "reader_STOP", "TMP_remaining")}
    )
)
raise SystemExit(0 if result["status"] == "PASS" else 1)
