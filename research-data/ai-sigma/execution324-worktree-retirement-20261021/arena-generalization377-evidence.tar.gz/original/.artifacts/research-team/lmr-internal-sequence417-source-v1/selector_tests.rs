#[cfg(test)]
mod selector_tests {
    use super::*;

    fn facts(c: &SigmaContext, action: u16, q: u16) -> LmrBranchFacts {
        LmrBranchFacts {
            hypothesis: "",
            slot: "",
            iteration_depth: 0,
            visit: 0,
            parent_depth: 3,
            parent_ply: 2,
            parent_stm: c.position().turn,
            distinct_rank: if q == 0 { 4 } else { 16 },
            action,
            quantum: q,
            alpha_beta_bits: [0.0f32.to_bits(), 1.0f32.to_bits()],
            tt: None,
        }
    }
    fn path(actions: [u16; 2]) -> [PlayedMove; 2] {
        [
            PlayedMove {
                colour: 0,
                action: actions[0],
            },
            PlayedMove {
                colour: 1,
                action: actions[1],
            },
        ]
    }
    #[test]
    fn lmr417_selector_final_gate_reserves_before_return_and_distinguishes_fullhistories() {
        let a = SigmaContext::from_prefix(&[81, 83]).unwrap();
        let b = SigmaContext::from_prefix(&[83, 81]).unwrap();
        assert_eq!(a.position(), b.position());
        assert!(!same_history(&a, &b));
        let ids = a.legal_ids();
        let mut o = LmrObservation::default();
        let f = facts(&a, ids[0], 0);
        o.iteration = 4;
        o.begin(&a, &path([81, 83]), f);
        o.iteration = 5;
        for (depth, ply) in [(4, 2), (3, 1), (3, 3)] {
            let mut outside = f;
            outside.parent_depth = depth;
            outside.parent_ply = ply;
            o.begin(&a, &path([81, 83]), outside);
        }
        assert_eq!(o.branches().count(), 0);
        assert_eq!(
            o.coverage
                .iter()
                .flatten()
                .map(|c| c.opportunities)
                .sum::<u64>(),
            0
        );
        o.begin(&a, &path([81, 83]), f);
        assert_eq!(o.branches().count(), 1); // Reserved before any return.
        o.child_start(2, ids[0], 2, [0.0, next_up(0.0)]);
        o.child_return(
            &a,
            &path([81, 83]),
            2,
            ids[0],
            &Err(Interrupted::Stop(StopReason::Cancelled)),
        );
        assert_eq!(
            o.branches().next().unwrap().stages[0].unwrap().stop,
            Some(StopReason::Cancelled)
        );
        o.begin(&a, &path([81, 83]), facts(&a, ids[1], 0)); // Same parent cannot replace interruption.
        assert_eq!(o.coverage[0][0].same_parent_skips, 1);
        o.begin(&b, &path([83, 81]), facts(&b, ids[0], 0));
        assert_eq!(
            o.branches().map(|b| b.facts.slot).collect::<Vec<_>>(),
            ["H0-0", "H0-1"]
        );
        assert_eq!(o.branches().next().unwrap().facts.action, ids[0]);
        o.finish(&Err(SearchError::Evaluation(
            "incomplete original root".into(),
        )));
        assert!(o.finished && o.frames.iter().all(Option::is_none));
        assert!(o.branches().all(|b| !b.root_completed));
        assert_eq!(o.branches().count(), 2); // Partial slots survive, but cannot enter arms.
    }
    #[test]
    fn lmr417_selector_completed_q1_fail_low_dedup_and_cross_hypothesis_parent() {
        let a = SigmaContext::from_prefix(&[81, 83]).unwrap();
        let b = SigmaContext::from_prefix(&[83, 81]).unwrap();
        let ids = a.legal_ids();
        let mut o = LmrObservation::default();
        o.iteration = 5;
        o.begin(&a, &path([81, 83]), facts(&a, ids[0], 0));
        let complete = |o: &mut LmrObservation,
                        c: &SigmaContext,
                        p: &[PlayedMove],
                        action,
                        value: NodeResult<f32>| {
            o.begin(c, p, facts(c, action, 1));
            o.child_start(2, action, 1, [0.0, next_up(0.0)]);
            o.child_return(c, p, 2, action, &value);
        };
        complete(
            &mut o,
            &a,
            &path([81, 83]),
            ids[1],
            Err(Interrupted::Stop(StopReason::NodeLimit)),
        );
        assert_eq!(o.branches().count(), 1);
        complete(&mut o, &a, &path([81, 83]), ids[1], Ok(0.25));
        assert_eq!(o.branches().count(), 1);
        complete(&mut o, &a, &path([81, 83]), ids[0], Ok(-0.25)); // Same branch across H0/H+ rejected.
        assert_eq!(o.coverage[2][1].same_branch_skips, 1);
        complete(&mut o, &a, &path([81, 83]), ids[1], Ok(-0.25)); // Same parent, other hypothesis/action allowed.
        complete(&mut o, &a, &path([81, 83]), ids[2], Ok(-0.25));
        assert_eq!(o.coverage[2][1].same_parent_skips, 1);
        complete(&mut o, &b, &path([83, 81]), ids[1], Ok(0.0));
        assert_eq!(
            o.branches().map(|b| b.facts.slot).collect::<Vec<_>>(),
            ["H0-0", "H+-0", "H+-1"]
        );
        let selected = o.branches().find(|b| b.facts.slot == "H+-0").unwrap();
        assert!(selected.stages[0].unwrap().completed);
        assert_eq!(selected.stages[0].unwrap().bound, Some("Upper"));
        let mut outside = facts(&b, ids[2], 2);
        outside.distinct_rank = 32;
        o.begin(&b, &path([83, 81]), outside);
        assert_eq!(
            o.coverage[3][0].opportunities + o.coverage[3][1].opportunities,
            0
        );
        let action = ids[2];
        o.begin(&b, &path([83, 81]), facts(&b, action, 1));
        for (depth, window, value) in [
            (1, [0.0, next_up(0.0)], 0.5),
            (2, [0.0, next_up(0.0)], 0.5),
            (2, [0.0, 1.0], 0.25),
        ] {
            o.child_start(2, action, depth, window);
            o.child_return(&b, &path([83, 81]), 2, action, &Ok(value));
        }
        assert_eq!(o.coverage[2][1].normal_confirmations, 1);
        assert_eq!(o.coverage[2][1].full_windows, 1);
        assert_eq!(o.branches().count(), 3); // Full-window work does not select another slot.
    }
}
