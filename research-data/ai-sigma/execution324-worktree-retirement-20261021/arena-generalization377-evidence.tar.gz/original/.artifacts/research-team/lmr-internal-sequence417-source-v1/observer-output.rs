// Root work and arm work are disjoint; stage work is nested inside an arm.
fn lmr_observation_output(
    session: &SearchSession,
    root: &SigmaContext,
    observation: &alphabeta::LmrObservation,
    cancel: &AtomicBool,
    root_ok: bool,
) -> Value {
    let mut branches = Vec::new();
    let mut invocations = 0u64;
    let mut function_calls = 0u64;
    let mut child_calls = 0u64;
    let mut nodes = 0u64;
    let mut evaluations = 0u64;
    let mut unknown_work = 0u64;
    let mut completed = 0u64;
    let mut reduced_started = 0u64;
    let mut confirmations_entered = 0u64;
    let mut confirmations_completed = 0u64;
    let mut confirmations_condition_true = 0u64;
    let mut confirmations_unused = 0u64;
    let mut halted = !root_ok;
    for branch in observation.branches() {
        let f = &branch.facts;
        let stages: Vec<_> = branch
            .stages
            .iter()
            .map(|s| s.map(trial_stage_output))
            .collect();
        let mut arms = Vec::new();
        for (index, arm) in alphabeta::LMR_ARM_ORDER.into_iter().enumerate() {
            let mut row = if halted || cancel.load(Ordering::Relaxed) {
                lmr_unperformed_arm(arm)
            } else {
                lmr_trial_output(session, root, branch, arm, cancel)
            };
            row["arm_index"] = json!(index);
            row["repeat"] = json!(if index < 2 { 1 } else { 2 });
            row["label"] = json!(["N1", "R1", "R2", "N2"][index]);
            let started = row["common_invocation_started"] == true;
            function_calls += u64::from(row["arm_function_called"] == true);
            invocations += u64::from(started);
            child_calls += row["child_scouts"].as_u64().unwrap_or(0);
            reduced_started += u64::from(started && arm == alphabeta::LmrArm::ReducedThenConfirm);
            confirmations_entered += u64::from(row["confirmation_entered"] == true);
            confirmations_completed += u64::from(row["confirmation_completed"] == true);
            confirmations_condition_true += u64::from(row["confirmation_condition"] == true);
            confirmations_unused += u64::from(
                started
                    && arm == alphabeta::LmrArm::ReducedThenConfirm
                    && row["protocol_complete"] == true
                    && row["child_scouts"] == 1,
            );
            if let (Some(n), Some(e)) = (
                row["work"]["nodes"].as_u64(),
                row["work"]["evaluations"].as_u64(),
            ) {
                nodes += n;
                evaluations += e;
            } else {
                unknown_work += u64::from(row["arm_function_called"] == true);
            }
            completed += u64::from(row["protocol_complete"] == true);
            if !row["error"].is_null() || row["stop"] == "Cancelled" {
                halted = true;
            }
            arms.push(row);
        }
        let mut comparisons = Vec::new();
        for (n, r) in [(0, 1), (3, 2)] {
            comparisons.push(json!({"N_label":arms[n]["label"],"R_label":arms[r]["label"],
                "N_vs_R_final":lmr_bits_comparison(&arms[n]["value_bits"],&arms[r]["value_bits"]),
                "N_bound":arms[n]["bound"],"R_final_bound":arms[r]["bound"],
                "N_returned_depth":arms[n]["returned_child_depth"],"R_returned_depth":arms[r]["returned_child_depth"],
                "N_vs_R_confirmation":lmr_bits_comparison(&arms[n]["value_bits"],&arms[r]["stages"][1]["value_bits"]),
                "original_warm_shallow_vs_R_shallow":if f.quantum==1 {
                    lmr_bits_comparison(&stages[0]["value_bits"],&arms[r]["stages"][0]["value_bits"])
                } else {Value::Null},
                "original_normal_vs_N":if f.quantum==0 {
                    lmr_bits_comparison(&stages[0]["value_bits"],&arms[n]["value_bits"])
                } else {Value::Null}}));
        }
        branches.push(json!({"hypothesis":f.hypothesis,"slot":f.slot,"iteration_depth":f.iteration_depth,
            "eligible_visit_serial":f.visit,"parent_depth":f.parent_depth,"parent_ply":f.parent_ply,
            "path_action_colour":branch.path(),"parent":identity(branch.parent()),"parent_stm":f.parent_stm,
            "distinct_rank":f.distinct_rank,"action":f.action,"eligible":true,
            "protected_by_saved_ranking":false,"original_q":f.quantum,
            "post_TT_pre_child_alpha_beta_bits":f.alpha_beta_bits,
            "TT":f.tt.map(|tt|json!({"stored_depth":tt.stored_depth,"bound":tt.bound,
                "context_matches":tt.context_matches,"usable_depth":tt.usable_depth,"legal_move":tt.legal_move})),
            "original_stages":stages,"arms":arms,"comparisons":comparisons,
            "N_repeat_nonclock_work_status":lmr_repeat_status(&arms[0],&arms[3]),
            "R_repeat_nonclock_work_status":lmr_repeat_status(&arms[1],&arms[2])}));
    }
    let coverage: Vec<_> = observation
        .coverage
        .iter()
        .map(|rank| {
            rank.iter()
                .map(|c| {
                    json!({"opportunities":c.opportunities,"first_completed":c.first_completed,
            "first_fail_low":c.first_fail_low,"normal_confirmations_started":c.normal_confirmations,
            "full_windows_started":c.full_windows,"selection_candidates":c.selection_candidates,
            "selected":c.selected,"same_parent_skips":c.same_parent_skips,
            "same_branch_skips":c.same_branch_skips,"full_slots_skips":c.full_slots_skips})
                })
                .collect::<Vec<_>>()
        })
        .collect();
    let planned = branches.len() as u64 * 4;
    json!({"version":alphabeta::LMR_OBSERVATION_PROTOCOL,"finished":observation.finished,
        "status":if root_ok&&completed==planned&&branches.len()==4 {"COMPLETE"} else {"PARTIAL"},
        "root_completed_D5_and_restored":root_ok,"selected_branches":branches.len(),"maximum_branches":4,
        "missing_branch_slots":4-branches.len(),"planned_selected_arm_slots":planned,
        "complete_arms":completed,"unknown_or_unperformed_selected_arms":planned-completed,
        "root_stop":observation.root_stop,"branches":branches,"coverage":coverage,
        "coverage_axes":{"iteration_depth":5,"parent_depth":3,"parent_ply":2,
            "distinct_rank":["4..8","9..15","16..31","32+"],"quantum":[0,1]},
        "skip_counter_scope":"selection candidates with free hypothesis slot; full slots counted separately",
        "arm_function_calls":function_calls,"arm_common_invocations":invocations,"arm_explicit_child_scouts":child_calls,
        "arm_recorded_nodes":nodes,"arm_recorded_evaluations":evaluations,
        "arm_unknown_work_invocations":unknown_work,"R_started":reduced_started,
        "R_confirmation_entered":confirmations_entered,"R_confirmation_completed":confirmations_completed,
        "R_confirmation_condition_true":confirmations_condition_true,
        "R_confirmation_unused_complete_fail_low":confirmations_unused,
        "R_unentered_confirmation_unknown":reduced_started-confirmations_entered-confirmations_unused,
        "R_no_confirmation_entered":reduced_started-confirmations_entered,
        "root_calls_exclude_arms":true,"stage_work_is_nested":true,"refill":false,
        "whole_excludes":"JSON encode/output and returned record later drop",
        "OS_model_allocator_coldness":"UNKNOWN","clock_resolution_ns":Value::Null})
}
