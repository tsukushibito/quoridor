#[cfg(test)]
mod lmr417_tests {
    use super::*;
    #[test]
    fn measurement417_repeat_work_drift_and_unperformed_nulls_are_not_complete() {
        let mut a = json!({"protocol_complete":true,"status":"COMPLETE","returned":"Ok",
            "stop":"DepthComplete","returned_child_depth":1,"value_bits":0,"bound":"Upper",
            "work":{"nodes":17,"evaluations":8},"child_scouts":1,"stages":[{"completed":true},null],
            "confirmation_entered":false,"confirmation_completed":null,"kernel_elapsed_ns":0,"whole_elapsed_ns":0});
        let mut b = a.clone();
        b["kernel_elapsed_ns"] = json!(4);
        b["whole_elapsed_ns"] = json!(100);
        assert_eq!(lmr_repeat_status(&a, &b), "MATCH");
        b["work"]["nodes"] = json!(18);
        assert_eq!(lmr_repeat_status(&a, &b), "DIFFERENT");
        a["protocol_complete"] = json!(false);
        assert_eq!(lmr_repeat_status(&a, &b), "UNKNOWN");
        for arm in alphabeta::LMR_ARM_ORDER {
            let row = lmr_unperformed_arm(arm);
            assert_eq!(row["protocol_complete"], false);
            assert_eq!(row["execution"], "UNPERFORMED");
            assert!(row["kernel_elapsed_ns"].is_null() && row["work"].is_null());
            assert!(row["returned_child_depth"].is_null() && row["value_bits"].is_null());
            assert_eq!(row["stages"], json!([null, null]));
        }
    }
    #[test]
    fn measurement417_stage_depth_sign_bound_and_interrupted_value_are_explicit() {
        let stage = alphabeta::LmrStage {
            child_depth: 1,
            window_bits: [0.0f32.to_bits(), 1u32],
            value_bits: Some((-0.25f32).to_bits()),
            bound: Some("Upper"),
            completed: true,
            stop: None,
            error: false,
        };
        let row = trial_stage_output(stage);
        assert_eq!(row["child_depth"], 1);
        assert_eq!(row["value_bits"], (-0.25f32).to_bits());
        assert_eq!(row["bound"], "Upper");
        let row = trial_stage_output(alphabeta::LmrStage {
            value_bits: None,
            bound: None,
            completed: false,
            stop: Some(StopReason::NodeLimit),
            ..stage
        });
        assert_eq!(row["status"], "UNKNOWN");
        assert_eq!(row["stop"], "NodeLimit");
        assert!(row["value_bits"].is_null() && row["bound"].is_null());
        assert_eq!(
            lmr_bits_comparison(&Value::Null, &json!(0))["value_bits"],
            "UNKNOWN"
        );
    }
}
