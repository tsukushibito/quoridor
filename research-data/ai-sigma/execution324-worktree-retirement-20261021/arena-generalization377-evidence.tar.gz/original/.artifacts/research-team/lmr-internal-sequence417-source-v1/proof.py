"""Finite source reconstruction/byte checks, never Rust/type/test execution."""

import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

import intake
from fixtures import PATHS

HERE = intake.HERE
AI = Path("crates/quoridor-ai/src/alphabeta.rs")
OLD = AI.with_name("lmr_observation416.rs")
NEW = AI.with_name("lmr_observation.rs")
RUNNER = Path("crates/quoridor-runner/src/measurement.rs")


def function(text, name):
    start = re.search(
        r"(?m)^\s*(?:pub(?:\([^)]*\))? )?fn " + name + r"\b", text
    ).start()
    brace = text.index("{", start)
    depth = 0
    for token in re.finditer(
        r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\\n])\'|[{}]',
        text[brace:],
    ):
        if token.group() == "{":
            depth += 1
        elif token.group() == "}":
            depth -= 1
            if depth == 0:
                return text[start : brace + token.end()]
    raise AssertionError(name)


def diff(before, after, relative):
    return "".join(
        difflib.unified_diff(
            before.splitlines(keepends=True),
            after.splitlines(keepends=True),
            fromfile="a/" + str(relative) if before else "/dev/null",
            tofile="b/" + str(relative) if after else "/dev/null",
            n=3,
        )
    )


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def main():
    paths = [AI, OLD, NEW, RUNNER, *PATHS]
    before = {p: "" if p == NEW else (HERE / "before" / p).read_text() for p in paths}
    after = {p: "" if p == OLD else (HERE / "post" / p).read_text() for p in paths}
    assert not intake.git("ls-tree", "-z", intake.BASE, "--", str(NEW))
    assert not (HERE / "post" / OLD).exists()
    for needle in ["ColdScout", "cold_lmr_scout", "LmrColdProbe", "lmr_observation416"]:
        assert all(needle not in text for text in after.values()), needle
    calls = intake.git(
        "grep",
        "-n",
        "-E",
        "cold_lmr_scout|LmrColdProbe|lmr_observation416",
        intake.BASE,
        "--",
        "crates",
    ).decode()
    assert all(
        any(str(p) + ":" in line for p in [AI, OLD, RUNNER])
        for line in calls.splitlines()
    )
    (HERE / "retired-caller-scope.txt").write_text(calls)
    protected = []
    for name in [
        "root_depth",
        "reduced_child",
        "lmr_allowed",
        "prepared_moves",
        "eager_ordered",
        "ordered",
        "control",
        "enter",
        "key",
        "zero_stock_approx_leaf",
        "zero_stock_approx_value",
        "safe_race_value",
        "publish_distance_counts",
        "pv",
    ]:
        old, new = function(before[AI], name), function(after[AI], name)
        assert old == new, name
        protected.append(
            {"function": name, "bytes": len(old.encode()), "sha256": sha(old)}
        )
    assert function(before[OLD], "same_history") == function(after[NEW], "same_history")
    old = function(before[AI], "negamax_entered")
    new = function(after[AI], "negamax_entered").replace(
        '                        slot: "",\n', ""
    )
    assert old == new, "normal negamax differs beyond diagnostic slot label"
    old = function(before[AI], "child")
    new = function(after[AI], "child")
    new = re.sub(
        r'        #\[cfg\(feature = "research-diagnostics"\)\]\n        if TRACE && let Some\(trace\) = self.trial_trace.as_deref_mut\(\) \{\n.*?\n        \}\n',
        "",
        new,
        flags=re.DOTALL,
    )
    assert old == new, "canonical child differs beyond bounded TRACE hooks"
    old, new = before[AI], after[AI]
    marker = "        for depth in 1..=limits.max_depth {"
    finish = "        Ok(())\n    })();"
    assert (
        old[old.index(marker) : old.index(finish, old.index(marker))]
        == new[new.index(marker) : new.index(finish, new.index(marker))]
    )
    old_tests = before[AI].split("#[cfg(test)]", 1)[1]
    new_tests = after[AI].split("#[cfg(test)]", 1)[1]
    assertions = r"\b(?:assert|assert_eq|assert_ne)!\([\s\S]*?\);"
    assert re.findall(assertions, old_tests) == re.findall(assertions, new_tests)
    runner_protected = [
        "observation_input_check",
        "replay",
        "validate",
        "validate_return",
        "completed_depth_observation",
    ]
    for name in runner_protected:
        assert function(before[RUNNER], name) == function(after[RUNNER], name), name
    # The ordinary work-output expression and assignments have exactly one
    # owner after extraction, with the same counter fields and expressions.
    old_observed = function(before[RUNNER], "observed")
    work = function(after[RUNNER], "observed_work")
    old_fields = re.findall(
        r'"([A-Za-z0-9_]+)":s\.(\w+)', old_observed.split('"ordering":', 1)[0]
    )
    new_fields = re.findall(r'"([A-Za-z0-9_]+)":s\.(\w+)', work)
    assert old_fields == new_fields
    old_assignments = re.findall(
        r'result\["work"\](.*?);', old_observed, flags=re.DOTALL
    )
    new_assignments = re.findall(r"work(\[.*?);", work, flags=re.DOTALL)

    def compact(values):
        return [re.sub(r"\s+", "", x) for x in values]

    assert compact(old_assignments) == compact(new_assignments)
    for p in PATHS:
        assert (
            after[p].replace(
                '        #[cfg(feature = "research-diagnostics")]\n        trial_trace: None,\n',
                "",
            )
            == before[p]
        ), str(p)
    # Existing Python admission already owns the exact 12/D5/1M cold opt-in.
    # No Python change or second protocol setting is necessary.
    python = intake.git(
        "show", intake.BASE + ":scripts/dev/research-lifecycle.py"
    ).decode()
    node = next(
        n
        for n in ast.parse(python).body
        if isinstance(n, ast.FunctionDef) and n.name == "measurement_config"
    )
    selected = "".join(
        python.splitlines(keepends=True)[node.lineno - 1 : node.end_lineno]
    )
    assert selected == (HERE / "before-measurement_config.py").read_text()
    constants = {
        n.value
        for n in ast.walk(node)
        if isinstance(n, ast.Constant) and type(n.value) is int
    }
    assert "observe_lmr" in selected and {1_000_000, 1_048_576} <= constants
    forward = "".join(diff(before[p], after[p], p) for p in paths)
    inverse = "".join(diff(after[p], before[p], p) for p in paths)
    (HERE / "lmr-internal-sequence417.patch").write_text(forward)
    (HERE / "lmr-internal-sequence417.inverse.patch").write_text(inverse)
    frame = HERE / "proof-frame"
    frame.mkdir()
    try:
        for p in [AI, OLD, RUNNER, *PATHS]:
            target = frame / p
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(before[p])
        for direction in [
            "lmr-internal-sequence417.patch",
            "lmr-internal-sequence417.inverse.patch",
        ]:
            result = subprocess.run(
                [
                    "patch",
                    "--batch",
                    "--fuzz=0",
                    "--no-backup-if-mismatch",
                    "-p1",
                    "-i",
                    str(HERE / direction),
                ],
                cwd=frame,
                check=False,
                capture_output=True,
                text=True,
            )
            (HERE / (direction + ".proof.log")).write_text(
                result.stdout + result.stderr
            )
            assert result.returncode == 0, (direction, result.stderr)
            expected = before if direction.endswith("inverse.patch") else after
            for p in paths:
                assert (
                    (frame / p).read_text() == expected[p]
                    if expected[p]
                    else not (frame / p).exists()
                ), (direction, str(p))
    finally:
        shutil.rmtree(frame)
    for p in [AI, OLD, RUNNER, *PATHS]:
        target = HERE / "before-gzip" / p.with_suffix(p.suffix + ".gz")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(gzip.compress(before[p].encode(), mtime=0))
        assert gzip.decompress(target.read_bytes()) == before[p].encode()
    ai_names = re.findall(r"fn (lmr417_\w+)\(", after[NEW])
    runner_names = re.findall(r"fn (measurement417_\w+)\(", after[RUNNER])
    assert len(ai_names) == 8 and after[NEW].count("#[test]") == 8
    assert len(runner_names) == 2
    result = {
        "static_status": "PASS",
        "native_status": "UNBUILT/UNTYPED/UNRUN",
        "forward_inverse_exact": True,
        "old_module_restored_new_absence_restored": True,
        "protected_AI_functions": protected,
        "normal_child_except_TRACE_hooks_byte_exact": True,
        "normal_negamax_except_slot_label_byte_exact": True,
        "ordinary_iteration_loop_byte_exact": True,
        "existing_AI_assertions_byte_exact": True,
        "same_history_owner_byte_exact": True,
        "existing_external_fixture_assertions_and_outside_bytes_exact": True,
        "protected_runner_functions": runner_protected,
        "ordinary_work_counter_fields_and_assignments_exact": True,
        "Python_whole_unchanged_sha256": sha(python),
        "Python_measurement_config_unchanged_sha256": sha(selected),
        "new_AI_definitions": ai_names,
        "new_runner_definitions": runner_names,
        "private_proof_frame_removed": not frame.exists(),
    }
    (HERE / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "static_status": "PASS",
                "AI_new": len(ai_names),
                "runner_new": len(runner_names),
            }
        )
    )


if __name__ == "__main__":
    main()
