"""Freeze the exact413 source and original controller scopes without upgrades."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def freeze(lc, here):
    affinity = os.sched_getaffinity(0)
    os.sched_setaffinity(0, {3})
    try:
        records = []
        failures = []
        phases = []
        for path in sorted(here.glob("*-v*/result.json")):
            result = json.loads(path.read_text())
            phases.append(ref(path))
            if result["status"] != "PASS":
                failures.append(
                    {
                        "phase": path.parent.name,
                        "original": ref(path),
                        "primary": result["primary"],
                    }
                )
            for check in result["checks"]:
                returned = check["guardian_return"]
                disk = json.loads(
                    Path(check["persisted_process_receipt"]["path"]).read_text()
                )
                if returned is not None:
                    lc.settled(returned)
                    assert check["capture_complete"]
                else:
                    assert check["status"] == "FAILED"
                facts = returned if returned is not None else disk
                assert facts["direct_child_reaped"] and facts["cleanup_complete"]
                assert facts["handle_closes_complete"] and not facts["remaining"]
                child = facts["child"]
                fresh = lc.process.identity(lc.process.process_info(child["pid"]))
                assert fresh is None or fresh != child
                records.append(
                    {
                        "phase": path.parent.name,
                        "name": check["name"],
                        "status": check["status"],
                        "child": child,
                        "fresh_identity": fresh,
                        "capture_complete_reported": check["capture_complete"],
                        "full_log": check["full_log"],
                        "persisted_process_receipt": check["persisted_process_receipt"],
                        "launch_policy": facts["launch_policy"],
                        "returned_scope": "NULL remains UNKNOWN; disk cleanup scope only"
                        if returned is None
                        else "original settled directwait/reap/handles/cleanup",
                        "returned_mask": None
                        if returned is None
                        else returned["signal_mask_restoration"],
                        "returned_persist": None
                        if returned is None
                        else returned["final_record_persist"],
                        "disk_mask": disk.get("signal_mask_restoration"),
                        "disk_persist": disk.get("final_record_persist"),
                        "original_seconds_once_nested_excluded": facts["wall_seconds"],
                    }
                )
            # Preserve original TMP_remaining observations; verify actual now.
            assert not (path.parent / "TMP").exists(), str(path.parent / "TMP")
        manifest = json.loads((here / "selected-source-manifest.json").read_text())
        for selected in manifest:
            if "postimage" in selected:
                assert ref(Path(selected["postimage"]["path"])) == selected["postimage"]
            for component in selected.get("components", []):
                for name in ["before", "after"]:
                    assert ref(Path(component[name]["path"])) == component[name]
        authority = json.loads((here / "component-binding.json").read_text())
        for key in ["fixed412", "fixed412_STOP"]:
            assert ref(Path(authority[key]["path"])) == authority[key]
        fixed_binding = json.loads(Path(authority["fixed412"]["path"]).read_text())
        known = {}

        def collect(value):
            if isinstance(value, dict):
                if {"path", "sha256", "bytes", "mode"} <= value.keys():
                    known[value["path"]] = value
                for child in value.values():
                    collect(child)
            elif isinstance(value, list):
                for child in value:
                    collect(child)

        collect(fixed_binding)
        verified_components = []
        previous = here.parent / "lmr-standard412-v1"
        for relative in [
            "crates/quoridor-ai/src/alphabeta.rs",
            "crates/quoridor-ai/src/lmr408_tests.rs",
            "crates/quoridor-runner/src/measurement.rs",
            "crates/quoridor-runner/src/runtime_lmr_method_tests.rs",
            "scripts/dev/test_research_lmr_standard.py",
            "measurement_config.py",
            "comparison_conditions.py",
            "apply_comparison_cost.py",
            "apply_comparison_arena.py",
            "arena_observation.py",
            "arena_lmr_method.rs",
            "runtime_requested_lmr_method.rs",
        ]:
            path = previous / "post" / relative
            expected = known[str(path)]
            assert ref(path) == expected
            verified_components.append(expected)
        binding = {
            "issue": "quoridor-4lc.413.1",
            "status": "SOURCE_FROZEN_NATIVE_UNBUILT_UNTYPED_UNRUN",
            "prospective_base": authority,
            "verified_fixed412_components": verified_components,
            "subjects": manifest,
            "forward": ref(here / "lmr-aggressive413.patch"),
            "inverse": ref(here / "lmr-aggressive413.inverse.patch"),
            "strict_static_proof": ref(here / "strict-proof.json"),
            "verification_plan": ref(here / "verification-plan.json"),
            "report": ref(here / "source-report.md"),
            "context": ref(here / "source-context.json"),
            "Main_writes": 0,
            "composition": "sparse exact subject delta over frozen412, not old full publisher/runtime/Alpha overwrite; Root ordinary fixture repairs compose independently",
        }
        (here / "source-binding.json").write_text(json.dumps(binding, indent=2) + "\n")
        usage = lc.process.directory_bytes(here)
        fs = os.statvfs(here)
        controller = lc.process.identity(lc.process.process_info(os.getpid()))
        assert controller is not None
        output = {
            "issue": "quoridor-4lc.413.1",
            "status": "SOURCE_FROZEN_NATIVE_UNBUILT_UNTYPED_UNRUN",
            "actual_source_reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
            "refs": {
                name: ref(here / name)
                for name in [
                    "source-binding.json",
                    "source-report.md",
                    "verification-plan.json",
                    "source-context.json",
                    "strict-proof.json",
                    "selected-source-manifest.json",
                    "lmr-aggressive413.patch",
                    "lmr-aggressive413.inverse.patch",
                    "prepare.py",
                    "extract.py",
                    "packet.py",
                    "finish.py",
                    "guarded.py",
                ]
            },
            "source_controller": {
                "identity": controller,
                "scope": "light metadata epilogue exits after final write; actual fresh absence checked after tool return",
            },
            "phases": phases,
            "fresh_guarded_child_census": records,
            "original_failures": failures,
            "additional_error_scopes": [
                "hold-send-v1 commands PASS and accepted once, original outer epilogue exit1 empty uv lock; cleanup-only no resend, original result TMP observation retained",
                "two lightweight read inspections guessed absent admin.py/runtime_lmr412_tests.rs; exit2 retained in tool record, no source/native entry",
            ],
            "native": "UNBUILT/UNTYPED/UNRUN; no compile/test/Search/model/science/reviewer dispatch",
            "nested_Git_patch": "subprocess.run synchronous exit/reap only; separate PID/start/boot not recorded UNKNOWN, not fabricated; original family cleanup retained",
            "readers": [],
            "writers": [],
            "children": [],
            "jobs": [],
            "handles": [],
            "TMP": [],
            "leases": [],
            "owned": [],
            "canonical_hardware_lease": "NONE; no global/futurequiet claim",
            "storage": {
                "budget": None,
                "directed_OWN_allocated_B": usage,
                "dedupe": "existing directory_bytes dev/inode over OWN413 only",
                "FS_available_B": fs.f_bavail * fs.f_frsize,
                "excluded": "this final STOP and later tiny admin; no assets/sharedtarget/global scan",
                "global_actual": "UNKNOWN; decimal50GB maintained",
            },
            "Beads_backup_close": "324 only; in_progress until canonical acceptance",
            "preserved": "411/412 fixed originals; allRAWFAILEDfeesUNKNOWN, product/generatorOFF/models/weights/seals/oldfits96/mixedlearnerALLprep-pipeline+323USERPAUSE/foreign",
        }
        (here / "source-STOP.json").write_text(json.dumps(output, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "source_STOP": ref(here / "source-STOP.json"),
                    "binding": ref(here / "source-binding.json"),
                    "OWN_allocated_B_once": usage,
                    "owned": [],
                }
            )
        )
    finally:
        os.sched_setaffinity(0, affinity)
