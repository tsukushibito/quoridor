"""One sparse413 candidate over frozen412; author performs no native execution."""

import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
PREVIOUS = HERE.parent / "lmr-standard412-v1"
BASE = "9908347e8cb8a9204572b5840c3e63d6197bc7a9"
NAMES = ["depth_rank_late_one", "depth_rank_deep_two", "depth_rank_early_one"]


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def replace(text, before, after, count=1):
    assert text.count(before) == count, (before[:100], text.count(before), count)
    return text.replace(before, after)


def git_source(relative):
    return subprocess.run(
        [
            "git",
            "-c",
            "core.packedGitWindowSize=8m",
            "-c",
            "core.packedGitLimit=32m",
            "--no-optional-locks",
            "show",
            BASE + ":" + relative,
        ],
        cwd="/workspaces/quoridor",
        capture_output=True,
        check=True,
    ).stdout.decode()


def frame_bases():
    frames = {}
    for relative in [
        "crates/quoridor-ai/src/alphabeta.rs",
        "crates/quoridor-ai/src/lmr408_tests.rs",
        "crates/quoridor-runner/src/measurement.rs",
        "crates/quoridor-runner/src/runtime_lmr_method_tests.rs",
        "scripts/dev/test_research_lmr_standard.py",
    ]:
        frames[relative] = (PREVIOUS / "post" / relative).read_text()
    runtime = git_source("crates/quoridor-runner/src/runtime.rs")
    for component in ["arena_lmr_method.rs", "runtime_requested_lmr_method.rs"]:
        runtime = replace(
            runtime,
            (PREVIOUS / "before" / component).read_text(),
            (PREVIOUS / "post" / component).read_text(),
        )
    frames["crates/quoridor-runner/src/runtime.rs"] = runtime
    publisher = git_source("scripts/dev/research-lifecycle.py")
    # Reconstruct only for strict whole-file patch proof; no publisher mirror.
    for component in [
        "measurement_config",
        "comparison_conditions",
        "apply_comparison_cost",
        "apply_comparison_arena",
        "arena_observation",
    ]:
        # The frozen412 function preimage already includes frozen411's optional
        # safe-race settings. Git9908347 alone intentionally predates that delta.
        # Select the named immutable function, then compose the fixed412 owner;
        # never treat a stale full publisher as the prospective412 authority.
        node = next(
            n
            for n in ast.parse(publisher).body
            if isinstance(n, ast.FunctionDef) and n.name == component
        )
        lines = publisher.splitlines(True)
        selected = "".join(lines[node.lineno - 1 : node.end_lineno])
        publisher = replace(
            publisher,
            selected,
            (PREVIOUS / "post" / (component + ".py")).read_text().rstrip() + "\n",
        )
    frames["scripts/dev/research-lifecycle.py"] = publisher
    return frames


def diff(before, after, relative):
    return "".join(
        difflib.unified_diff(
            before.splitlines(True),
            after.splitlines(True),
            fromfile="a/" + relative,
            tofile="b/" + relative,
            n=3,
        )
    )


def prepare():
    binding = json.loads((HERE / "component-binding.json").read_text())
    for name in ["fixed412", "fixed412_STOP"]:
        expected = binding[name]
        assert ref(Path(expected["path"])) == expected
    frames = frame_bases()
    post = dict(frames)
    relative = "crates/quoridor-ai/src/alphabeta.rs"
    text = post[relative]
    text = replace(
        text,
        "    DepthRank,\n}",
        "    DepthRank,\n    DepthRankLateOne,\n    DepthRankDeepTwo,\n    DepthRankEarlyOne,\n}",
    )
    text = replace(
        text,
        '            "depth_rank" => Ok(Self::DepthRank),',
        '            "depth_rank" => Ok(Self::DepthRank),\n            "depth_rank_late_one" => Ok(Self::DepthRankLateOne),\n            "depth_rank_deep_two" => Ok(Self::DepthRankDeepTwo),\n            "depth_rank_early_one" => Ok(Self::DepthRankEarlyOne),',
    )
    text = replace(
        text,
        '            Self::DepthRank => "depth_rank",',
        '            Self::DepthRank => "depth_rank",\n            Self::DepthRankLateOne => "depth_rank_late_one",\n            Self::DepthRankDeepTwo => "depth_rank_deep_two",\n            Self::DepthRankEarlyOne => "depth_rank_early_one",',
    )
    text = replace(
        text,
        '            Self::DepthRank => "lmr408-depth-rank-log63-extra0to3-pvs-verify-v1",',
        '            Self::DepthRank => "lmr408-depth-rank-log63-extra0to3-pvs-verify-v1",\n            Self::DepthRankLateOne => "lmr413-depth-rank-d5-m16-plus1-cap4-pvs-verify-v1",\n            Self::DepthRankDeepTwo => "lmr413-depth-rank-d7-m16-plus2-cap5-pvs-verify-v1",\n            Self::DepthRankEarlyOne => "lmr413-depth-rank-d5-m8-plus1-cap4-pvs-verify-v1",',
    )
    marker = "\n        }\n    }\n    fn prepare(self) {"
    start = text.index("    pub fn reduction_rule(self)")
    end = text.index(marker, start)
    rules = """
            Self::DepthRankLateOne => "canonical depth_rank q; d>=5,m>=16,q>0: extra=min(q+1,4,d-2), else q; child=d-1-extra; existing protection/PVS",
            Self::DepthRankDeepTwo => "canonical depth_rank q; d>=7,m>=16,q>0: extra=min(q+2,5,d-2), else q; child=d-1-extra; existing protection/PVS",
            Self::DepthRankEarlyOne => "canonical depth_rank q; d>=5,m>=8,q>0: extra=min(q+1,4,d-2), else q; child=d-1-extra; existing protection/PVS","""
    text = text[:end] + rules + text[end:]
    text = replace(
        text,
        "        if self == Self::DepthRank {\n            LMR_DEPTH_RANK",
        "        if self != Self::FixedOne {\n            LMR_DEPTH_RANK",
    )
    old = """        match self {
            Self::FixedOne => 1,
            Self::DepthRank => u16::from(
                LMR_DEPTH_RANK.get().expect("LMR prepared before Search")
                    [usize::from(depth.min(63))][rank.min(63)],
            ),
        }"""
    new = """        if self == Self::FixedOne {
            return 1;
        }
        let q = u16::from(
            LMR_DEPTH_RANK.get().expect("LMR prepared before Search")
                [usize::from(depth.min(63))][rank.min(63)],
        );
        if q == 0 {
            return 0;
        }
        match self {
            Self::DepthRankLateOne if depth >= 5 && rank >= 16 => (q + 1).min(4).min(depth - 2),
            Self::DepthRankDeepTwo if depth >= 7 && rank >= 16 => (q + 2).min(5).min(depth - 2),
            Self::DepthRankEarlyOne if depth >= 5 && rank >= 8 => (q + 1).min(4).min(depth - 2),
            _ => q,
        }"""
    text = replace(text, old, new)
    text = replace(
        text,
        "    pub lmr_attempts: u64,",
        "    pub lmr_attempts: u64,\n    /// Started scouts whose extra reduction exceeds canonical depth_rank q.\n    /// Counts calls (including interrupted calls), not additional plies.\n    pub lmr_additional_reductions: u64,",
    )
    text = replace(
        text,
        "            let mut v = if reduced {\n                self.reduced_child(",
        "            let mut v = if reduced {\n                if matches!(self.stats.lmr_method, LmrMethod::DepthRankLateOne | LmrMethod::DepthRankDeepTwo | LmrMethod::DepthRankEarlyOne)\n                    && reduction > LmrMethod::DepthRank.reduction(depth, i + 1)\n                {\n                    self.stats.lmr_additional_reductions += 1;\n                }\n                self.reduced_child(",
    )
    post[relative] = text
    relative = "crates/quoridor-ai/src/lmr408_tests.rs"
    text = post[relative]
    start = text.index(
        "#[test]\nfn lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial() {"
    )
    end = text.index("\nstruct DepthTrace", start)
    block = text[start:end]
    block = block.replace(
        "#[test]\nfn lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial() {",
        "fn zero_quantum_tt_first_fixture(method: LmrMethod) {",
    )
    block = block.replace("LmrMethod::DepthRank.prepare();", "method.prepare();")
    block = block.replace(
        "s.stats.lmr_method = LmrMethod::DepthRank;", "s.stats.lmr_method = method;"
    )
    block = replace(
        block,
        "            assert_eq!(s.stats.tt_exact_hits, 5);",
        "            assert_eq!(s.stats.lmr_additional_reductions, 0);\n            assert_eq!(s.stats.tt_exact_hits, 5);",
    )
    wrapper = """#[test]
fn lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial() {
    zero_quantum_tt_first_fixture(LmrMethod::DepthRank);
}

"""
    post[relative] = (
        text[:start]
        + wrapper
        + block
        + text[end:]
        + '\n#[path = "lmr413_tests.rs"]\nmod lmr413_tests;\n'
    )
    relative = "crates/quoridor-runner/src/measurement.rs"
    text = post[relative]
    text = replace(
        text,
        '"LMR_full_window_researches":s.lmr_full_window_researches,',
        '"LMR_full_window_researches":s.lmr_full_window_researches,"LMR_additional_reductions":s.lmr_additional_reductions,',
    )
    text = replace(
        text,
        '    result["work"]["LMR_full_window_researches"] = json!(s.lmr_full_window_researches);',
        '    result["work"]["LMR_full_window_researches"] = json!(s.lmr_full_window_researches);\n    result["work"]["LMR_additional_reductions"] = json!(s.lmr_additional_reductions);',
    )
    post[relative] = text + (HERE / "drafts/measurement413_tests.rs").read_text()
    relative = "crates/quoridor-runner/src/runtime.rs"
    text = post[relative]
    text = replace(
        text,
        "    pub lmr_full_window_researches: u64,",
        "    pub lmr_full_window_researches: u64,\n    #[serde(default)]\n    pub lmr_additional_reductions: u64,",
    )
    text = replace(
        text,
        "        self.lmr_full_window_researches += s.lmr_full_window_researches;",
        "        self.lmr_full_window_researches += s.lmr_full_window_researches;\n        self.lmr_additional_reductions += s.lmr_additional_reductions;",
    )
    text = replace(
        text,
        '"full_window_researches":r.stats.lmr_full_window_researches}',
        '"full_window_researches":r.stats.lmr_full_window_researches,"additional_reductions":r.stats.lmr_additional_reductions}',
        count=2,
    )
    post[relative] = text
    relative = "crates/quoridor-runner/src/runtime_lmr_method_tests.rs"
    post[relative] += (HERE / "drafts/runtime413_tests.rs").read_text()
    relative = "scripts/dev/research-lifecycle.py"
    text = post[relative]
    for function, old in [
        ("measurement_config", '{"fixed_one", "depth_rank"}'),
        ("arena_plan_check", '("fixed_one", "depth_rank")'),
    ]:
        node = next(
            n
            for n in ast.parse(text).body
            if isinstance(n, ast.FunctionDef) and n.name == function
        )
        lines = text.splitlines(True)
        before = "".join(lines[node.lineno - 1 : node.end_lineno])
        after = replace(before, old, repr(tuple(["fixed_one", "depth_rank", *NAMES])))
        text = text.replace(before, after, 1)
    post[relative] = text
    relative = "scripts/dev/test_research_lmr_standard.py"
    text = post[relative]
    text = replace(
        text,
        '\n\nif __name__ == "__main__":',
        (HERE / "drafts/python413_tests.py").read_text()
        + '\n\nif __name__ == "__main__":',
    )
    post[relative] = text
    relative = "crates/quoridor-ai/src/lmr413_tests.rs"
    post[relative] = (HERE / "drafts/lmr413_tests.rs").read_text()
    # Full changed AI/measurement/test postimages; runtime/publisher only sparse
    # subjects. Temporary full formatting frames are owned and removed later.
    tmp = Path(__import__("os").environ["TMPDIR"]) / "format-frames"
    tmp.mkdir()
    for rel, text in post.items():
        path = tmp / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
    (HERE / "prepared-frames.json").write_text(
        json.dumps({"path": str(tmp), "relative": list(post)}, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                "prospective_base": BASE,
                "component412_STOP": binding["fixed412_STOP"],
                "format_frames": str(tmp),
                "no_native_execution": True,
            }
        )
    )


if __name__ == "__main__":
    prepare()
