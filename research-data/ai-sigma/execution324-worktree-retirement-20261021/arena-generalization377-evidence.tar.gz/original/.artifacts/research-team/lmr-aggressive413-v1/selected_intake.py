"""Verify fixed412 authority, select only current typed method/counter owners."""

import ast
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
SOURCE412 = HERE.parent / "lmr-standard412-v1"
BASE = "9908347e8cb8a9204572b5840c3e63d6197bc7a9"


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


for name, sha, size in [
    (
        "source-STOP.json",
        "4514667c7d712d9ec4f2bbdedc3d2b9e240fb98c490122493d41d5bec395994d",
        51612,
    ),
    (
        "source-binding.json",
        "43bbf98f7741b495cd245e2b4736fc34bacfeea23f13796e5e00fd6e566fdfb8",
        20263,
    ),
]:
    actual = ref(SOURCE412 / name)
    assert (
        actual["sha256"] == sha and actual["bytes"] == size and actual["mode"] == "0644"
    )
refs = []
for rel in [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-runner/src/measurement.rs",
    "measurement_config.py",
]:
    src = SOURCE412 / "post" / rel
    dest = HERE / "before" / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(src.read_bytes())
    refs.append({"relative": rel, "component412": ref(src), "before": ref(dest)})
for name in ["arena_lmr_method.rs", "runtime_requested_lmr_method.rs"]:
    src = SOURCE412 / "post" / name
    dest = HERE / "before" / ("component412-" + name)
    dest.write_bytes(src.read_bytes())
    refs.append({"component412": ref(src), "before": ref(dest)})
for rel in [
    "crates/quoridor-runner/src/runtime.rs",
    "scripts/dev/research-lifecycle.py",
    "crates/quoridor-ai/src/lmr408_tests.rs",
]:
    data = subprocess.run(
        ["git", "--no-optional-locks", "show", BASE + ":" + rel],
        cwd="/workspaces/quoridor",
        check=True,
        capture_output=True,
    ).stdout
    text = data.decode()
    if rel.endswith(".py"):
        for node in ast.parse(text).body:
            if (
                isinstance(node, ast.FunctionDef)
                and node.lineno < 2531 <= node.end_lineno
            ):
                fragment = "".join(
                    text.splitlines(True)[node.lineno - 1 : node.end_lineno]
                )
                dest = HERE / "before" / (node.name + ".py")
                dest.write_text(fragment + "\n")
                refs.append(
                    {
                        "relative": rel,
                        "base_git": BASE,
                        "full_sha256": hashlib.sha256(data).hexdigest(),
                        "function": node.name,
                        "before": ref(dest),
                    }
                )
                print("Python selected function", node.name)
    elif rel.endswith("runtime.rs"):
        lines = text.splitlines()
        for i, line in enumerate(lines):
            if "lmr_full_window_researches" in line:
                print(rel, i + 1, "\n".join(lines[max(0, i - 3) : i + 5]))
        refs.append(
            {
                "relative": rel,
                "base_git": BASE,
                "full_sha256": hashlib.sha256(data).hexdigest(),
                "bytes": len(data),
            }
        )
    else:
        source = SOURCE412 / "post" / rel
        data = source.read_bytes()
        text = data.decode()
        print(text[-12000:])
        # Needed current owning fixture subject only, not an old engine copy.
        dest = HERE / "before" / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        refs.append({"relative": rel, "base_git": BASE, "before": ref(dest)})
(HERE / "component-binding.json").write_text(
    json.dumps(
        {
            "fixed412": ref(SOURCE412 / "source-binding.json"),
            "fixed412_STOP": ref(SOURCE412 / "source-STOP.json"),
            "base_Main": BASE,
            "refs": refs,
        },
        indent=2,
    )
    + "\n"
)
alpha = (HERE / "before/crates/quoridor-ai/src/alphabeta.rs").read_text()
lines = alpha.splitlines()
for i, line in enumerate(lines):
    if "lmr_attempts +=" in line:
        print("production quantum branch", i + 1, "\n".join(lines[i - 20 : i + 35]))
