"""Strict static scope/roundtrip proof; never compile or execute test definitions."""

import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

import prepare

HERE = Path(__file__).resolve().parent


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def block(text, start, stop):
    left = text.index(start)
    return text[left : text.index(stop, left)]


def functions(text):
    lines = text.splitlines(True)
    return {
        n.name: "".join(lines[n.lineno - 1 : n.end_lineno])
        for n in ast.parse(text).body
        if isinstance(n, ast.FunctionDef)
    }


def rust_definition(text, marker):
    left = text.index(marker)
    opened = text.index("{", left)
    depth = 1
    cursor = opened + 1
    while depth:
        depth += (text[cursor] == "{") - (text[cursor] == "}")
        cursor += 1
    return text[left:cursor]


def strict_diff(before, after, path):
    return "".join(
        difflib.unified_diff(
            before.splitlines(True),
            after.splitlines(True),
            fromfile="a/" + path if before else "/dev/null",
            tofile="b/" + path if after else "/dev/null",
            n=3,
        )
    )


def main():
    frames = prepare.frame_bases()
    temporary = Path(json.loads((HERE / "prepared-frames.json").read_text())["path"])
    post = {
        str(p.relative_to(temporary)): p.read_text()
        for p in temporary.rglob("*")
        if p.is_file()
    }
    alpha = "crates/quoridor-ai/src/alphabeta.rs"
    before = frames[alpha]
    after = post[alpha]
    boundaries = (
        "/// Additional reduction from normal child depth",
        "/// Heuristic leaves, not exact WDL",
    )
    normal = after.replace(block(after, *boundaries), block(before, *boundaries), 1)
    addition = "    /// Started scouts whose extra reduction exceeds canonical depth_rank q.\n    /// Counts calls (including interrupted calls), not additional plies.\n    pub lmr_additional_reductions: u64,\n"
    normal = prepare.replace(normal, addition, "")
    start = "            let mut v = if reduced {\n"
    end = "                self.reduced_child("
    normal = prepare.replace(
        normal, block(normal, start, end), block(before, start, end)
    )
    assert normal == before, (
        "Alpha outside method definition, scalar and one caller event changed"
    )
    assert block(
        after, "            LMR_DEPTH_RANK.get_or_init", "    fn reduction(self"
    ) == block(
        before, "            LMR_DEPTH_RANK.get_or_init", "    fn reduction(self"
    ), "canonical table construction changed"
    for marker in ["    fn lmr_allowed(", "    fn reduced_child("]:
        assert rust_definition(after, marker) == rust_definition(before, marker)
    fixture = "crates/quoridor-ai/src/lmr408_tests.rs"
    old = frames[fixture]
    new = post[fixture]
    for marker in [
        "fn lmr408_names_table_units_zero_edges_and_sixty_three_clamps()",
        "fn lmr408_effective_method_namespace_history_reset_warm_and_approx_independence()",
        "fn lmr408_saved_protection_precedes_depth_rank_quantum()",
        "fn lmr408_multi_ply_full_depth_confirmation_error_cancel_and_parent_restore()",
    ]:
        assert rust_definition(new, marker) == rust_definition(old, marker)
    old_fixture = rust_definition(
        old,
        "fn lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial()",
    )
    new_fixture = rust_definition(
        new, "fn zero_quantum_tt_first_fixture(method: LmrMethod)"
    )
    restored = new_fixture.replace(
        "fn zero_quantum_tt_first_fixture(method: LmrMethod)",
        "fn lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial()",
    )
    restored = restored.replace(
        "method.prepare();", "LmrMethod::DepthRank.prepare();"
    ).replace(
        "s.stats.lmr_method = method;", "s.stats.lmr_method = LmrMethod::DepthRank;"
    )
    restored = prepare.replace(
        restored, "            assert_eq!(s.stats.lmr_additional_reductions, 0);\n", ""
    )
    assert restored == old_fixture, (
        "reused q0 fixture changed beyond method parameter/newcounter assertion"
    )
    relative = "crates/quoridor-runner/src/measurement.rs"
    text = post[relative]
    text = text[: text.index("\n#[cfg(test)]\nmod lmr413_metadata_tests")]
    text = prepare.replace(
        text, ',"LMR_additional_reductions":s.lmr_additional_reductions', ""
    )
    text = prepare.replace(
        text,
        '    result["work"]["LMR_additional_reductions"] = json!(s.lmr_additional_reductions);\n',
        "",
    )
    assert text.rstrip() == frames[relative].rstrip()
    relative = "crates/quoridor-runner/src/runtime.rs"
    text = post[relative]
    text = prepare.replace(
        text, "    #[serde(default)]\n    pub lmr_additional_reductions: u64,\n", ""
    )
    text = prepare.replace(
        text,
        "        self.lmr_additional_reductions += s.lmr_additional_reductions;\n",
        "",
    )
    text = prepare.replace(
        text, ',"additional_reductions":r.stats.lmr_additional_reductions', "", count=2
    )
    assert text == frames[relative], "runtime outside existing scalar consumers changed"
    relative = "crates/quoridor-runner/src/runtime_lmr_method_tests.rs"
    assert (
        post[relative].split("\n#[test]\nfn runtime413_")[0].rstrip()
        == frames[relative].rstrip()
    )
    relative = "scripts/dev/test_research_lmr_standard.py"
    text = post[relative]
    node = next(
        n
        for n in ast.walk(ast.parse(text))
        if isinstance(n, ast.FunctionDef) and n.name.startswith("test_lmr413_")
    )
    lines = text.splitlines(True)
    text = "".join(lines[: node.lineno - 1] + lines[node.end_lineno :])
    assert ast.dump(ast.parse(text)) == ast.dump(ast.parse(frames[relative]))
    publisher = "scripts/dev/research-lifecycle.py"
    old_functions = functions(frames[publisher])
    new_functions = functions(post[publisher])
    assert old_functions.keys() == new_functions.keys()
    changed_functions = [
        name for name in old_functions if old_functions[name] != new_functions[name]
    ]
    assert set(changed_functions) == {"arena_plan_check", "measurement_config"}, (
        changed_functions
    )
    normalized = post[publisher]
    for name in changed_functions:
        normalized = normalized.replace(new_functions[name], old_functions[name], 1)
        # The only syntax delta is the two added explicit-method allowlists.
        old_ast = ast.parse(old_functions[name])
        new_ast = ast.parse(new_functions[name])
        for tree in [old_ast, new_ast]:
            for node in ast.walk(tree):
                if isinstance(node, ast.Compare):
                    for index, value in enumerate(node.comparators):
                        if isinstance(value, (ast.Set, ast.Tuple)) and all(
                            isinstance(v, ast.Constant) for v in value.elts
                        ):
                            strings = [v.value for v in value.elts]
                            if strings[:2] == ["fixed_one", "depth_rank"] or set(
                                strings
                            ) == {"fixed_one", "depth_rank"}:
                                node.comparators[index] = ast.Tuple(
                                    elts=[
                                        ast.Constant("fixed_one"),
                                        ast.Constant("depth_rank"),
                                    ],
                                    ctx=ast.Load(),
                                )
        assert ast.dump(old_ast) == ast.dump(new_ast), name
    assert normalized == frames[publisher], (
        "publisher outside two function subjects changed"
    )
    forward = "".join(
        strict_diff(frames.get(rel, ""), value, rel)
        for rel, value in sorted(post.items())
    )
    inverse = "".join(
        strict_diff(value, frames.get(rel, ""), rel)
        for rel, value in sorted(post.items())
    )
    (HERE / "lmr-aggressive413.patch").write_text(forward)
    (HERE / "lmr-aggressive413.inverse.patch").write_text(inverse)
    proof = Path(os.environ["TMPDIR"]) / "strict-proof"
    proof.mkdir()
    for rel, value in frames.items():
        write(proof / rel, value)
    receipts = []
    for name, expected in [
        ("lmr-aggressive413.patch", post),
        ("lmr-aggressive413.inverse.patch", frames),
    ]:
        result = subprocess.run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "--no-backup-if-mismatch",
                "-p1",
                "-i",
                str(HERE / name),
            ],
            cwd=proof,
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stdout + result.stderr
        assert (
            "fuzz" not in result.stdout.lower()
            and "offset" not in result.stdout.lower()
        )
        actual = {
            str(p.relative_to(proof)): p.read_text()
            for p in proof.rglob("*")
            if p.is_file()
        }
        assert actual == expected, name
        receipts.append(
            {
                "patch": prepare.ref(HERE / name),
                "returncode": result.returncode,
                "stdout": result.stdout,
                "strict_complete_tree_equal": True,
            }
        )
    manifests = []
    sparse = {"crates/quoridor-runner/src/runtime.rs", publisher}
    for rel, text in post.items():
        before = frames.get(rel, "")
        row = {
            "relative": rel,
            "before_sha256": hashlib.sha256(before.encode()).hexdigest()
            if before
            else None,
            "before_bytes": len(before.encode()),
            "after_sha256": hashlib.sha256(text.encode()).hexdigest(),
            "after_bytes": len(text.encode()),
            "mode": "0644",
            "base": "fixed412 over immutable9908347+frozen411",
        }
        if rel not in sparse:
            if before:
                write(HERE / "before" / rel, before)
            write(HERE / "post" / rel, text)
            row["postimage"] = prepare.ref(HERE / "post" / rel)
        elif rel == publisher:
            row["components"] = []
            for name in changed_functions:
                write(HERE / "before" / (name + ".py"), old_functions[name] + "\n")
                write(HERE / "post" / (name + ".py"), new_functions[name] + "\n")
                row["components"].append(
                    {
                        "function": name,
                        "before": prepare.ref(HERE / "before" / (name + ".py")),
                        "after": prepare.ref(HERE / "post" / (name + ".py")),
                    }
                )
        else:
            row["components"] = []
            for name, old_part, new_part in [
                (
                    "TtProfile.rs",
                    rust_definition(before, "struct TtProfile"),
                    rust_definition(text, "struct TtProfile"),
                ),
                (
                    "TtProfile_record.rs",
                    rust_definition(
                        before,
                        "    fn record(&mut self, result: &alphabeta::SearchResult)",
                    ),
                    rust_definition(
                        text,
                        "    fn record(&mut self, result: &alphabeta::SearchResult)",
                    ),
                ),
                (
                    "runtime_lmr_work.rs",
                    "\n".join(
                        line
                        for line in before.splitlines()
                        if '"lmr_work_completed"' in line
                        or '"lmr_work_terminal"' in line
                    )
                    + "\n",
                    "\n".join(
                        line
                        for line in text.splitlines()
                        if '"lmr_work_completed"' in line
                        or '"lmr_work_terminal"' in line
                    )
                    + "\n",
                ),
            ]:
                write(HERE / "before" / name, old_part + "\n")
                write(HERE / "post" / name, new_part + "\n")
                row["components"].append(
                    {
                        "subject": name,
                        "before": prepare.ref(HERE / "before" / name),
                        "after": prepare.ref(HERE / "post" / name),
                    }
                )
        manifests.append(row)
    fresh = "crates/quoridor-ai/src/lmr413_tests.rs"
    absence = subprocess.run(
        [
            "git",
            "-c",
            "core.packedGitWindowSize=8m",
            "--no-optional-locks",
            "cat-file",
            "-e",
            prepare.BASE + ":" + fresh,
        ],
        cwd="/workspaces/quoridor",
        capture_output=True,
        text=True,
    )
    assert absence.returncode != 0 and fresh not in frames
    (HERE / "selected-source-manifest.json").write_text(
        json.dumps(manifests, indent=2) + "\n"
    )
    static = {
        "status": "PASS: source/format/static only",
        "native": "UNBUILT/UNTYPED/UNRUN",
        "strict_forward_inverse": receipts,
        "protected": [
            "Alpha outside LmrMethod+one scalar+one caller counter event byte exact",
            "canonical logarithm/OnceLock table body byte exact",
            "lmr_allowed/reduced_child bodies byte exact",
            "old four408 definitions exact; q0 fixture method-parameter factoring only",
            "runtime outside existing TtProfile/work subjects byte exact",
            "publisher outside arena_plan_check/measurement_config byte exact; their AST only method allowlists",
            "existing method/namespace builder/reset single owner unchanged",
        ],
        "new_absence": {
            "path": fresh,
            "immutable_base": prepare.BASE,
            "fixed412": "absent",
            "git_returncode": absence.returncode,
            "stderr": absence.stderr,
        },
        "nested_subprocess_identity": "synchronous Git/patch directwait exit captured; separate PID/start/boot unrecorded UNKNOWN; maintained outer family owns cleanup",
    }
    (HERE / "strict-proof.json").write_text(json.dumps(static, indent=2) + "\n")
    # Draft fragments were formatted in their real owning syntax contexts.
    write(HERE / "drafts/lmr413_tests.rs", post[fresh])
    measurement = post["crates/quoridor-runner/src/measurement.rs"]
    write(
        HERE / "drafts/measurement413_tests.rs",
        "\n"
        + measurement[measurement.index("#[cfg(test)]\nmod lmr413_metadata_tests") :],
    )
    runtime_tests = post["crates/quoridor-runner/src/runtime_lmr_method_tests.rs"]
    write(
        HERE / "drafts/runtime413_tests.rs",
        "\n#[test]\n"
        + rust_definition(
            runtime_tests,
            "fn runtime413_candidate_methods_bind_factory_and_accumulate_actual_scout_counter()",
        )
        + "\n",
    )
    py = post["scripts/dev/test_research_lmr_standard.py"]
    new_test = next(
        n
        for n in ast.walk(ast.parse(py))
        if isinstance(n, ast.FunctionDef) and n.name.startswith("test_lmr413_")
    )
    write(
        HERE / "drafts/python413_tests.py",
        "\n"
        + "".join(py.splitlines(True)[new_test.lineno - 1 : new_test.end_lineno])
        + "\n",
    )
    shutil.rmtree(proof)
    shutil.rmtree(temporary)
    if temporary.parent.exists() and not any(temporary.parent.iterdir()):
        temporary.parent.rmdir()
    print(
        json.dumps(
            {
                "strict_static": "PASS",
                "subjects": len(post),
                "new_native_tests": "UNBUILT/UNTYPED/UNRUN",
                "TMP_frames_removed": True,
            }
        )
    )


if __name__ == "__main__":
    main()
