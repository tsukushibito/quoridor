"""Cleanup only the exact stopped send helper's ordinary empty uv lock."""

import importlib.util
import json
from pathlib import Path

import hold_admin

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "hold_cleanup_lc", "/workspaces/quoridor/scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lc)
result = json.loads((HERE / "hold-send-v1/result.json").read_text())
assert result["status"] == "PASS"
for check in result["checks"]:
    returned = check["guardian_return"]
    lc.settled(returned)
    child = returned["child"]
    fresh = lc.process.identity(lc.process.process_info(child["pid"]))
    assert fresh is None or fresh != child
tmp = HERE / "hold-send-v1/TMP"
for path in tmp.iterdir():
    assert path.name == "uv-cc8f3ad7aa19080a.lock"
    assert path.is_file() and not path.is_symlink() and path.stat().st_size == 0
    path.unlink()
tmp.rmdir()
hold_admin.freeze(lc, HERE)
