
#[cfg(test)]
mod lmr413_metadata_tests {
    use super::*;

    #[test]
    fn measurement413_names_roundtrip_and_partial_counter_have_actual_method() {
        let base = json!({"roots":[{"input":0,"pointer":"","field":"moves","label":"toy"}],"profile":"control","tt_entries":4096,"use_tt":true,"use_pvs":true,
            "namespace":{"evaluator":crate::teacher_pilot_execution::EVALUATOR_ID,"rules":"standard","selectivity":"synthetic"},"output_bytes":10000,"record_bytes":1000});
        for method in [
            LmrMethod::DepthRankLateOne,
            LmrMethod::DepthRankDeepTwo,
            LmrMethod::DepthRankEarlyOne,
        ] {
            for enabled in [false, true] {
                let mut config = base.clone();
                config["lmr_method"] = json!(method.name());
                config["lmr"] = json!(enabled);
                let settings: Settings = serde_json::from_value(config).unwrap();
                validate(&settings, &[]).unwrap();
                let decoded: Settings =
                    serde_json::from_value(serde_json::to_value(settings).unwrap()).unwrap();
                assert_eq!(LmrMethod::from_name(&decoded.lmr_method).unwrap(), method);
                let result = SearchResult {
                    action: None,
                    value: None,
                    completed_depth: 0,
                    pv: vec![],
                    stats: alphabeta::SearchStats {
                        lmr_enabled: enabled,
                        lmr_method: method,
                        lmr_additional_reductions: u64::from(enabled) * 7,
                        ..Default::default()
                    },
                    stop: StopReason::NodeLimit,
                    elapsed: std::time::Duration::ZERO,
                };
                let row = observed(&result);
                let callback = completed_depth_observation(&result);
                assert_eq!(
                    row["lmr_rule"],
                    if enabled {
                        json!(method.id())
                    } else {
                        Value::Null
                    }
                );
                assert_eq!(
                    row["work"]["LMR_additional_reductions"],
                    u64::from(enabled) * 7
                );
                assert_eq!(
                    callback["cumulative_work"]["LMR_additional_reductions"],
                    row["work"]["LMR_additional_reductions"]
                );
                assert_eq!(row["completed_depth"], 0);
                assert_eq!(row["stop"], "NodeLimit");
            }
        }
    }
}
