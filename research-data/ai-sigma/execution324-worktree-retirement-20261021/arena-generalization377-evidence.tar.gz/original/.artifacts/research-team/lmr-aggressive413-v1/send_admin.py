"""One frozen413 source delivery; no source replay or Beads mutation."""

from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path

import finish

HERE = Path(__file__).resolve().parent


def prepare(lc):
    ref = finish.ref
    actual = ref(HERE / "source-STOP.json")
    assert (
        actual["sha256"]
        == "61c003922fadcebb1dd8ffc5bc62f9adef51a27c8f452c657276beb58664c734"
    )
    assert actual["bytes"] == 50700 and actual["mode"] == "0644"
    binding = ref(HERE / "source-binding.json")
    assert (
        binding["sha256"]
        == "65ea10bfc3a712466989d71a7538d57e253c24f741dd4005884c3a063bf2832d"
    )
    assert binding["bytes"] == 19809 and binding["mode"] == "0644"
    stop = json.loads((HERE / "source-STOP.json").read_text())
    controller = stop["source_controller"]["identity"]
    fresh = lc.process.identity(lc.process.process_info(controller["pid"]))
    assert fresh is None or fresh != controller
    (HERE / "handoff-controller-census.json").write_text(
        json.dumps(
            {
                "observed_UTC": datetime.now(timezone.utc).isoformat(),
                "original_source_controller": controller,
                "fresh_identity": fresh,
                "scope": "original quality-v2 tool returned exit0; sourceSTOP original unchanged",
                "owned_source": [],
            },
            indent=2,
        )
        + "\n"
    )
    selected = {
        name: value
        for name, value in stop["refs"].items()
        if name
        in {
            "source-binding.json",
            "source-report.md",
            "verification-plan.json",
            "lmr-aggressive413.patch",
            "lmr-aggressive413.inverse.patch",
            "strict-proof.json",
            "source-context.json",
        }
    }
    body = (
        """quoridor-4lc.413.1 ONE frozen source handoff. SAME gpt-6.1-sol/high/cwdMain/danger-full-access/approval never actual turn_context07:54:51.554 verified. Author Main/managedproduction/Git/index/Cargo/Beads/native/test/Search/model/Perf/game/solver/science/reviewerdispatch0.
412 fixedsourceSTOP4514667c/binding43bbf98f remains immutable; prospective base is its exact postimages/functions over Git9908347+frozen411e738/dbf3, not stale Git alone. Root ordinary411fixture repair sparse-compose separately. 411/412/410/408 scientific originals untouched. Actual411 native+collection release received; no idle canonical/hardware lease.
A DepthRank/depth_rank remains default and exact q. B DepthRankLateOne/depth_rank_late_one: d>=5,m>=16,q>0 ->min(q+1,4,d-2); C DepthRankDeepTwo/depth_rank_deep_two d>=7,m>=16,q>0 ->min(q+2,5,d-2); D DepthRankEarlyOne/depth_rank_early_one d>=5,m>=8,q>0 ->min(q+1,4,d-2), otherwiseq. Child=d-1-extra>=1. Canonical table construction body/OnceLock shared exact. Existing typed AI from_name/name/id/reduction_rule owns namespace/reset; setter(method)->(), set_lmr(enabled)->Result<()> unchanged; runtime+measurement use actual type, no local ID builder. FixedOne/OFF, product/generator enableOFF, 412 normal research depth_rank selection retained.
Protected lmr_allowed/reduced_child and PVS normal-depth/full-window body byte exact; root/TT/goal/killer/distinct/keyfreeze/history/TT/undo/approx math unchanged. One new SearchStats scalar lmr_additional_reductions counts actual started positive B/C/D scouts with extra>q, including interrupted calls, NOT additional ply/benefit. One extra shared-table read on positive candidate scout only; A/Fixed/OFF skip it. Scalar/layout/copy/counter/setup/drop costs included whole, isolated cost/RSS UNKNOWN.
Existing measurement work+callback cumulative_work and runtime TtProfile/lmr_work_completed/lmr_work_terminal carry same scalar; overlapping views not summed. arena_clock whole_search unchanged (it had noLMR fields). Python measurement_config and arena_plan_check method allowlists only; strict/null/types/default semantics preserved. Sparse runtime/publisher component refs, no persistent whole mirror.
Rustfmt/Ruff/static strict forward+inverse fuzz0/offset0/newabsence/protected byte+AST PASS. NewAI5+measurement1+runtime1 Rust and Python1 UNBUILT/UNTYPED/UNRUN; exact names/features/counts in plan. One affected existing408q0 definition factored into shared private fixture; remainingfour408 bodies exact, no oldsuccessful suite replay. Tiny quantum expected boundaries/q0/protection/distinct16/scout error/confirm/cancel/namespace/warm definitions prepared, no native execution.
Originalselected-intake FAILED, source-v1 component preimage refusal, source-v2 helper order-assert FAILED, quality-v1 unused-import lintFAILED, timing-send epilogue lock exit1/NULLvsdisk masks/captures/costs retained. Repairs only source/helper scopes, no scientific retry. Sourceguard originalchildIDs fresh absent/different/directwait/reap/handles/TMPgone; controller now fresh absent/different after tool return. Nested synchronous Git/patch separatePID/start/boot UNKNOWN distinct. OWNallocated1515520B once, storageNone/FS actual inSTOP/globalactualUNKNOWN/decimal50GB. SourceCPU3/guardian7/family512MiB/G0/hostreserve4GiB actual readbacks eachphase; no AS512 Go/Node or quietclaim.
Root necessarycompile/research+diagnostics/Clippy/genuineN+same relatedreview and original authorized192/384 only; author job/root/config/call preparation0. No source clear->speed/strength/default promotion. Beads/backup/close324 only, leafinprogress until canonical acceptance. Mixed/learnerALLprep-pipeline/323USERPAUSE/models/weights/seals/oldfits96/defaultproductgeneratorOFF/foreign/oldRAWFAILEDfeesUNKNOWN held.
OWN """
        + str(HERE)
        + "\nSourceSTOP "
        + json.dumps(actual)
        + "\nBinding "
        + json.dumps(binding)
        + "\nExact packet refs "
        + json.dumps(selected, ensure_ascii=False)
        + "\nNo ACK/extra review/science requested.\n"
    )
    (HERE / "handoff.txt").write_text(body)
    print(
        json.dumps(
            {
                "verified_source_STOP": actual,
                "binding": binding,
                "source_controller_fresh": fresh,
                "owned_source": [],
            }
        )
    )


def complete(lc, here):
    directory = HERE / "send-v1"
    result = json.loads((directory / "result.json").read_text())
    assert result["status"] == "PASS"
    census = []
    for check in result["checks"]:
        returned = check["guardian_return"]
        lc.settled(returned)
        child = returned["child"]
        fresh = lc.process.identity(lc.process.process_info(child["pid"]))
        assert fresh is None or fresh != child
        census.append(
            {
                "name": check["name"],
                "child": child,
                "fresh_identity": fresh,
                "settled_return": returned,
                "full_log": check["full_log"],
                "disk_receipt": check["persisted_process_receipt"],
            }
        )
    tmp = directory / "TMP"
    if tmp.exists():
        for path in tmp.iterdir():
            assert (
                path.name == "uv-cc8f3ad7aa19080a.lock"
                and path.is_file()
                and not path.is_symlink()
                and path.stat().st_size == 0
            )
            path.unlink()
        tmp.rmdir()
    fact = {
        "actual_admin_STOP": datetime.now(timezone.utc).isoformat(),
        "source_STOP": finish.ref(HERE / "source-STOP.json"),
        "source_controller": json.loads(
            (HERE / "handoff-controller-census.json").read_text()
        ),
        "delivery_result": finish.ref(directory / "result.json"),
        "accepted_receipt": finish.ref(directory / "send-once.full.log"),
        "fresh_delivery_children": census,
        "readers": [],
        "writers": [],
        "children": [],
        "jobs": [],
        "handles": [],
        "TMP": [],
        "leases": [],
        "owned": [],
        "scope": "light metadata epilogue exits after final write, tool return separate",
        "usage": "once in sourceSTOP, later tiny delivery/admin excluded",
        "Beads_backup_close": "324 only, no own/parent close",
    }
    (HERE / "admin-STOP.json").write_text(json.dumps(fact, indent=2) + "\n")
    print(json.dumps({"admin_STOP": finish.ref(HERE / "admin-STOP.json"), "owned": []}))


if __name__ == "__main__":
    loader = importlib.util.spec_from_file_location(
        "send413_lc", "/workspaces/quoridor/scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    prepare(lc)
