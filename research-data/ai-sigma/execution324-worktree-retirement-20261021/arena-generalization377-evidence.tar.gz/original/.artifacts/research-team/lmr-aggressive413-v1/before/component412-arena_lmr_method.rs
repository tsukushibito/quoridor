pub(crate) fn arena_lmr_method(engine: &Engine) -> alphabeta::Result<alphabeta::LmrMethod> {
    alphabeta::LmrMethod::from_name(
        engine
            .lmr_method
            .as_deref()
            .unwrap_or(alphabeta::LmrMethod::default().name()),
    )
}
