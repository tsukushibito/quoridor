"""Existing guarded metadata delivery, with its own light epilogue."""

import sys

import hold_admin

sys.modules["finish"] = hold_admin
__import__("guarded")
