# 413: DepthRankからの3候補 — sourceのみ

固定412 sourceSTOP4514667c/source-binding43bbf98fを直接の基準にした私有patchです。Main9908347単独ではなく、凍結411のpostimages/functionsを含む412の実componentを使います。Rootの通常fixture修正は薄いsubject単位で合成してください。Main、managed production、Git/index、Cargo、Beads、image/model、native、Search、test、Perf、gameへの作者write/実行は0です。真正N/Build/数値結果は未作成です。

| 対照/候補 | 型と設定名 | canonical qからの変更 |
| --- | --- | --- |
| A | DepthRank / `depth_rank` | 変更なし。412の既定methodも維持 |
| B | DepthRankLateOne / `depth_rank_late_one` | d>=5,m>=16,q>0ならmin(q+1,4,d-2) |
| C | DepthRankDeepTwo / `depth_rank_deep_two` | d>=7,m>=16,q>0ならmin(q+2,5,d-2) |
| D | DepthRankEarlyOne / `depth_rank_early_one` | d>=5,m>=8,q>0ならmin(q+1,4,d-2) |

その他はqです。child=d-1-extraで最低1。canonical4096cell u8表の式・構築bodyはbyte exact、既存OnceLockを共有して一度初期化します。三つの追加methodを選んでも別表・per-node log/heap/evaluationはありません。FixedOne/OFF、root/TT/goal/killerの保護、4th distinctの数え方、除外条件、LMR許可関数、reduced_child body、scout→通常childdepth確認→必要なfull-windowのbodyは元のままです。TT-first後の採点時点/凍結keys/tail/PVS同手再探索/history/rules/NNUE/undo/approx411は変更しません。

AI LmrMethodがfrom_name/name/id/reduction_ruleと既存namespace/resetの唯一のownerです。set_lmr_methodは既存の()、set_lmrは既存Result<()>、enabledとmethodは独立。同じ有効methodのwarm保持、変更時のTT/history破棄は既存経路を使います。raw enable omission、製品/generatorのLMROFFは変更しません。Python measurement_configとarena_plan_checkのliteral allowlistだけを拡張し、null/type/未知名の拒否は保持します。runtime factoryとmeasurement loaderは既存の型変換へそのまま流します。

追加scalarはSearchStats::lmr_additional_reductions一つだけです。実際の正のreduced scoutを開始する直前、B/C/Dでextra>canonical qの時に1増やします。追加ply合計でも成立/速度/成功回数でもなく、取消/errorで中断するcallも含みます。q0/保護/非発動は0です。candidateの正のscout時だけ追加の同表lookupが一回あり、A/FixedOne/OFFにはそのlookupはありません。新u64のlayout/copy、match/lookup/counter、metadata/setup/dropの費用は実wholeに含まれます。独立費/RSS/効果はUNKNOWNです。

measurementのworkとcompleted-depth cumulative_workにLMR_additional_reductionsを追加。runtimeの既存TtProfile集約、lmr_work_completed、lmr_work_terminalにも同じscalarを追加します。これらは重なるため合算不可。従来LMR fieldを持たないarena_clock::alpha_countersには別ownerを作らず、元のwhole_search意味を保持します。古い結果/schemaの数値を書換えません。

新定義はAI5+runner2+Python1、全てUNBUILT/UNTYPED/UNRUNです。有限expected quantum境界、63clamp、q0、既定/namespace/reset/warm、TT/goal/killer保護、actual distinct16th scout/error復元、通常深さ確認/取消を既存小fixtureと明示期待値で準備しました。NoHead/ExpectedErrorはhead呼出しが起きてはならない場所を検出するtoyで、実modelは読みません。実counter用fixtureは65536slotの小TTへ15 childをseedし、16thのエラーで停止して履歴/親を検査します。これらのtoy結果自体もまだ不明です。既存408のq0 fixtureをmethod引数へ小さく共用し、その一つだけaffected対象。残る四つの408定義はbyte exactです。旧engine/comparator/table式oracleや成功suite全体を複製/実行しません。

Rustfmt、Python project Ruff、private全frameのstrict forward/inverse（fuzz0/offset0）、新file不存在、protected outsideのbyte/AST検査はPASS。runtime/publisherは必要subjectのbefore/postだけを残し、整形/patch証明に使ったfull frameはTMPから削除しました。Rootへ渡すpatchはprospective412にのみ適用する薄い差分です。保護・数式・PVS bodyを変えたlarge postimageとしてMainへ上書きしないでください。

元selected-intake-v1の関数名誤認FAILED、source-v1のGit単独と411含み412関数の不一致拒否、source-v2の同じ二関数を順序付きlistで誤比較したhelper FAILEDを保全しました。後二つはhelperだけ修正し、完了済みformatterを再実行せず既存private frameで静的証明を継続。timing-checkpointの送信は一度受理済み、送信後epilogueが空uv lockを検出したexit1と元resultも保持し、停止child確認後にそのOWN lockだけcleanup、再送0。NULL return/capturefalseとdisk cleanup/pending-attemptedは別scopeです。

sourceCPU3/guardian7、family512MiB、GPU0、hostreserve4GiB、no_new_privsと既存guardで各有限childを制御しました。Go/NodeへAS512は課していません。Main/canonical/native hardware leaseを取得せず、global/futurequietは主張しません。LLM host利用/連続RSSpeakはUNKNOWNです。actual children/directwait/reap/handles/freshidentity/TMP/STOPと一度のOWN dev/inode usageはsource-STOP.jsonにあります。同期Git/patch孫processの独立PID/start/bootは未記録UNKNOWNで、outer guardian cleanupとは区別します。

quality-v1ではreport生成helperの未使用import一つでRuffがFAILEDになりました。元capture/resultを保持し、importだけを除去しました。production/test定義は変更せず、native/assertionの実行もありません。

Rootのみ必要compile/research/research-diagnostics/Clippy/build/関連reviewと既承認192/384を実行します。作者はjob/config/rootsを増やしません。412標準選択は維持し、候補採用/強度/defaultの結論は未検証です。411 LMROFF/image/128、410/408、393/398棄却、旧RAW/FAILED/費/UNKNOWN、mixed/learner全prep-pipeline/323 USERPAUSE、models/weights/seals/oldfits96/foreignは不変。Beads/backup/closeも324だけ、leafは受入れまでin_progressです。
