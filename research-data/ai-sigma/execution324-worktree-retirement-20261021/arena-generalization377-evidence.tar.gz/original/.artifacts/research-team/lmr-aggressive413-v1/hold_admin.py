"""One light timing checkpoint; no source preparation or scientific work."""

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def census(lc, paths):
    checks = []
    for path in paths:
        result = json.loads(path.read_text())
        for check in result["checks"]:
            disk = json.loads(
                Path(check["persisted_process_receipt"]["path"]).read_text()
            )
            returned = check["guardian_return"]
            if returned is not None:
                lc.settled(returned)
            facts = returned if returned is not None else disk
            assert facts["direct_child_reaped"] and facts["cleanup_complete"]
            assert facts["handle_closes_complete"] and not facts["remaining"]
            child = facts["child"]
            fresh = lc.process.identity(lc.process.process_info(child["pid"]))
            assert fresh is None or fresh != child
            checks.append(
                {
                    "phase_result": ref(path),
                    "name": check["name"],
                    "status": check["status"],
                    "child": child,
                    "fresh_identity": fresh,
                    "returned": returned,
                    "persisted_receipt": check["persisted_process_receipt"],
                    "capture_complete_reported": check["capture_complete"],
                    "NULL_scope": "original return UNKNOWN; disk cleanup scope only"
                    if returned is None
                    else None,
                }
            )
        # Historical TMP_remaining is the original observation, never rewritten.
        assert not (path.parent / "TMP").exists()
    return checks


def prepare(lc):
    prior = sorted(HERE.glob("*-v*/result.json"))
    checks = census(lc, prior)
    controller = lc.process.identity(lc.process.process_info(os.getppid()))
    fact = {
        "observed_UTC": datetime.now(timezone.utc).isoformat(),
        "checkpoint": "selected-intake-v2 PASS, readerSTOP 07:22:50.203981Z",
        "candidate_source_written": False,
        "fixed_component_binding": ref(HERE / "component-binding.json"),
        "actual_prior_children": checks,
        "prior_guardian_PID_start": "not separately recorded; synchronous tool returns retained",
        "delivery_controller": controller,
        "substantial_work": "HOLD until actual411 native/collection STOP",
        "readers": [],
        "source_writers": [],
        "children": [],
        "jobs": [],
        "TMP": [],
        "leases": [],
        "owned_substantial": [],
        "light_admin_scope": "this bounded metadata/delivery child remains until directwait",
        "prior_small_read_error": "unentered inspection guessed nonexistent admin.py, sed exit2; no source change",
    }
    path = HERE / "timing-checkpoint-v1.json"
    path.write_text(json.dumps(fact, indent=2) + "\n")
    (HERE / "timing-checkpoint-handoff.txt").write_text(
        "quoridor-4lc.413.1 actual timing checkpoint, not full source handoff. "
        "SAME gpt-6.1-sol/high/cwdMain/danger-full-access/approval never verified. "
        "No active substantial guarded command; last selected-intake-v2 PASS "
        "readerSTOP07:22:50.203981Z. Current fresh original child identities "
        "absent/different/directwait/reap/handles/TMPgone; original helper "
        "selected-intake-v1 FAILED/NULL/persisted facts remain. "
        "412 sourceSTOP4514667c fixed; only413 bounded before-subject intake done, "
        "candidate production/test postimages not yet written. "
        "Chosen explicit B/C/D names depth_rank_late_one/depth_rank_deep_two/"
        "depth_rank_early_one; planned one actual additional-reduction counter. "
        "No Main/Git/Cargo/Beads/native/test/Search/model/science. "
        "HOLD substantial source/helper/formatter/CPU/IO until actual411 STOP; "
        "light admin only; no idle canonical/hardware lease or ACK gate. "
        "Exact checkpoint " + json.dumps(ref(path)) + ". "
        "Beads/backup/close Root only; all pauses/defaults/RAW/FAILED/fees held.\n"
    )
    print(json.dumps({"checkpoint": ref(path), "owned_substantial": []}))


def freeze(lc, here):
    path = HERE / "hold-send-v1/result.json"
    fact = {
        "actual_admin_STOP": datetime.now(timezone.utc).isoformat(),
        "checkpoint": ref(HERE / "timing-checkpoint-v1.json"),
        "delivery_result": ref(path),
        "accepted_receipt": ref(HERE / "hold-send-v1/send-once.full.log"),
        "actual_admin_children": census(lc, [path]),
        "readers": [],
        "writers": [],
        "children": [],
        "jobs": [],
        "handles": [],
        "TMP": [],
        "leases": [],
        "owned": [],
        "scope": "light final metadata writer exits after this write; tool return separate",
        "usage": "one directed OWN postcheck deferred to final source STOP; no asset scan",
        "original_admin_epilogue_failure": "hold-send-v1 original exec exit1 after accepted send: empty uv lock remained; original result retained; cleanup-only no resend",
    }
    output = HERE / "timing-admin-STOP-v1.json"
    output.write_text(json.dumps(fact, indent=2) + "\n")
    print(json.dumps({"admin_STOP": ref(output), "owned": []}))


if __name__ == "__main__":
    spec = importlib.util.spec_from_file_location(
        "hold_lc", "/workspaces/quoridor/scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lc)
    prepare(lc)
