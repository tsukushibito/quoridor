"""Finite static hunk/inverse and unchanged-owner check; no Rust execution."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
name = "crates/quoridor-ai/src/alphabeta.rs"
new_test = "crates/quoridor-ai/src/tt_first386_tests.rs"
before = gzip.decompress((HERE / "alphabeta.before.gz").read_bytes())
current = (ROOT / name).read_bytes()
old = before.decode()
new = current.decode()
start = "    fn negamax("
end = "    fn root_depth("
assert old[: old.index(start)] == new[: new.index(start)]
wiring = '#[cfg(all(test, feature = "research-diagnostics"))]\n#[path = "tt_first386_tests.rs"]\nmod tt_first386_tests;\n\n'
assert new[new.index(end) :].replace(wiring, "") == old[old.index(end) :]
old_node = old[old.index(start) : old.index(end)]
new_node = new[new.index(start) : new.index(end)]
assert (
    old_node[: old_node.index("        let moves = self.ordered(")]
    == new_node[: new_node.index("        let legal = legal.unwrap_or_else(")]
)
body = "            let mut v = if self.limits.use_pvs"
old_body = old_node[
    old_node.index(body) : old_node.index(
        "\n        }\n        self.control()?;", old_node.index(body)
    )
]
new_body = new_node[new_node.index(body) : new_node.index("            i += 1;")]
assert old_body.rstrip() == new_body.rstrip()
epilogue = "        self.control()?;\n        if let Some(winner)"
assert old_node[old_node.index(epilogue) :] == new_node[new_node.index(epilogue) :]

baseline = json.loads((HERE / "before-read-v1/result.json").read_text())
for ref in baseline["frozen_remaining385"] + baseline["frozen377"]:
    assert hashlib.sha256(Path(ref["path"]).read_bytes()).hexdigest() == ref["sha256"]

with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as scratch:
    tree = Path(scratch)
    p = tree / name
    p.parent.mkdir(parents=True)
    p.write_bytes(before)
    for inverse, patch in ((False, "source.patch"), (True, "source.inverse.patch")):
        output = subprocess.check_output(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "--no-backup-if-mismatch",
                "--remove-empty-files",
                "-p1",
                "-d",
                str(tree),
                "-i",
                str(HERE / patch),
            ],
            stderr=subprocess.STDOUT,
            text=True,
        )
        print(output, end="")
        assert "offset" not in output and "fuzz" not in output
        assert p.read_bytes() == (before if inverse else current)
        if inverse:
            assert not (tree / new_test).exists()
        else:
            assert (tree / new_test).read_bytes() == (ROOT / new_test).read_bytes()
print(
    "Exact forward/inverse and unchanged child/PVS/cutoff/epilogue/root/other13 source subjects PASS; native type/tests UNRUN"
)
