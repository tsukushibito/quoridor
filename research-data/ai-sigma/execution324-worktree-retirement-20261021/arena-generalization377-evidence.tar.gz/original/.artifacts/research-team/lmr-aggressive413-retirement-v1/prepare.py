"""One retirement delta over immutable current Main; no managed-source writes."""

import ast
import gzip
import hashlib
import json
import os
from pathlib import Path

import intake

HERE = intake.HERE
RETIRED = ["depth_rank_late_one", "depth_rank_deep_two", "depth_rank_early_one"]


def replace(text, before, after, count=1):
    assert text.count(before) == count, (before[:80], text.count(before), count)
    return text.replace(before, after)


def block(text, start, stop):
    left = text.index(start)
    return text[left : text.index(stop, left)]


def python_functions(text):
    lines = text.splitlines(True)
    return {
        node.name: "".join(lines[node.lineno - 1 : node.end_lineno])
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef)
    }


def bases():
    refs = json.loads((HERE / "intake-refs.json").read_text())
    frames = {}
    for owner in refs["owners"]:
        relative = owner["relative"]
        raw = intake.git("show", intake.BASE + ":" + relative)
        assert (
            hashlib.sha256(raw).hexdigest() == owner["sha256"]
            and len(raw) == owner["bytes"]
        )
        frames[relative] = raw.decode()
    return frames


def main():
    frames = bases()
    post = dict(frames)
    previous = (
        HERE.parent / "lmr-aggressive413-v1/before/crates/quoridor-ai/src/alphabeta.rs"
    )
    expected = intake.ref(previous)
    assert (
        expected["sha256"]
        == "0391bcd26f0f20f873af9c0bfe0567852bdf87cc70f5aa824d78d30b42e4e86e"
        and expected["bytes"] == 161687
        and expected["mode"] == "0644"
    )
    original_method = block(
        previous.read_text(),
        "/// Additional reduction from normal child depth",
        "/// Heuristic leaves, not exact WDL",
    )
    relative = "crates/quoridor-ai/src/alphabeta.rs"
    text = post[relative]
    text = replace(
        text,
        block(
            text,
            "/// Additional reduction from normal child depth",
            "/// Heuristic leaves, not exact WDL",
        ),
        original_method,
    )
    text = replace(
        text,
        "    /// Started scouts whose extra reduction exceeds canonical depth_rank q.\n    /// Counts calls (including interrupted calls), not additional plies.\n    pub lmr_additional_reductions: u64,\n",
        "",
    )
    start = "            let mut v = if reduced {\n"
    end = "                self.reduced_child("
    text = replace(text, block(text, start, end), start)
    post[relative] = text
    relative = "crates/quoridor-ai/src/lmr408_tests.rs"
    text = post[relative]
    wrapper = intake.definition(
        text,
        "fn lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial()",
    )
    helper = intake.definition(
        text, "fn zero_quantum_tt_first_fixture(method: LmrMethod)"
    )
    restored = helper.replace(
        "fn zero_quantum_tt_first_fixture(method: LmrMethod)",
        "fn lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial()",
    )
    restored = restored.replace(
        "method.prepare();", "LmrMethod::DepthRank.prepare();"
    ).replace(
        "s.stats.lmr_method = method;", "s.stats.lmr_method = LmrMethod::DepthRank;"
    )
    restored = replace(
        restored, "            assert_eq!(s.stats.lmr_additional_reductions, 0);\n", ""
    )
    text = replace(text, wrapper + "\n\n" + helper, restored)
    text = replace(text, '\n#[path = "lmr413_tests.rs"]\nmod lmr413_tests;\n', "")
    text += """
#[test]
fn lmr413_retired_names_rejected_by_current_method_owner() {
    for name in ["depth_rank_late_one", "depth_rank_deep_two", "depth_rank_early_one"] {
        assert!(LmrMethod::from_name(name).is_err());
    }
    assert_eq!(LmrMethod::from_name("depth_rank").unwrap(), LmrMethod::DepthRank);
    assert_eq!(LmrMethod::from_name("fixed_one").unwrap(), LmrMethod::FixedOne);
    assert_eq!(LmrMethod::default(), LmrMethod::DepthRank);
}
"""
    post[relative] = text
    del post["crates/quoridor-ai/src/lmr413_tests.rs"]
    relative = "crates/quoridor-runner/src/measurement.rs"
    text = post[relative]
    text = replace(text, ',"LMR_additional_reductions":s.lmr_additional_reductions', "")
    text = replace(
        text,
        '    result["work"]["LMR_additional_reductions"] = json!(s.lmr_additional_reductions);\n',
        "",
    )
    start = "\n#[cfg(test)]\nmod lmr413_metadata_tests"
    assert text.count(start) == 1
    left = text.index(start)
    module = intake.definition(text, "mod lmr413_metadata_tests")
    text = text[:left] + text[left:].replace("\n#[cfg(test)]\n" + module, "", 1)
    text = (
        text.rstrip()
        + """

#[cfg(test)]
mod lmr413_retirement_tests {
    use super::*;

    #[test]
    fn measurement413_retired_names_refused_even_when_lmr_off() {
        let base = json!({"roots":[{"input":0,"pointer":"","field":"moves","label":"toy"}],"profile":"control","tt_entries":4096,"use_tt":true,"use_pvs":true,
            "namespace":{"evaluator":crate::teacher_pilot_execution::EVALUATOR_ID,"rules":"standard","selectivity":"synthetic"},"output_bytes":10000,"record_bytes":1000});
        for name in ["depth_rank_late_one", "depth_rank_deep_two", "depth_rank_early_one"] {
            for enabled in [false, true] {
                let mut config = base.clone();
                config["lmr_method"] = json!(name);
                config["lmr"] = json!(enabled);
                let settings: Settings = serde_json::from_value(config).unwrap();
                assert!(validate(&settings, &[]).is_err());
            }
        }
    }
}
"""
    )
    post[relative] = text
    relative = "crates/quoridor-runner/src/runtime.rs"
    text = post[relative]
    text = replace(
        text, "    #[serde(default)]\n    pub lmr_additional_reductions: u64,\n", ""
    )
    text = replace(
        text,
        "        self.lmr_additional_reductions += s.lmr_additional_reductions;\n",
        "",
    )
    text = replace(
        text, ',"additional_reductions":r.stats.lmr_additional_reductions', "", count=2
    )
    post[relative] = text
    relative = "crates/quoridor-runner/src/runtime_lmr_method_tests.rs"
    text = post[relative]
    function = intake.definition(
        text,
        "fn runtime413_candidate_methods_bind_factory_and_accumulate_actual_scout_counter()",
    )
    post[relative] = replace(text, "\n#[test]\n" + function, "").rstrip() + "\n"
    relative = "scripts/dev/research-lifecycle.py"
    text = post[relative]
    for function in ["measurement_config", "arena_plan_check"]:
        before = python_functions(text)[function]
        after = before
        for name in RETIRED:
            lines = after.splitlines(True)
            match = [line for line in lines if '"' + name + '"' in line]
            assert len(match) == 1
            after = replace(after, match[0], "")
        text = replace(text, before, after)
    post[relative] = text
    relative = "scripts/dev/test_research_lmr_standard.py"
    text = post[relative]
    node = next(
        n
        for n in ast.walk(ast.parse(text))
        if isinstance(n, ast.FunctionDef)
        and n.name
        == "test_lmr413_named_methods_reach_current_measurement_and_prepare_consumers"
    )
    lines = text.splitlines(True)
    text = "".join(lines[: node.lineno - 1] + lines[node.end_lineno :])
    method = """
    def test_lmr413_retired_names_rejected_by_current_measurement(self):
        raw = dict(
            roots=[dict(input=0, pointer="", field="moves", label="toy")],
            profile="control", tt_entries=4096, use_tt=True, use_pvs=True,
            namespace=dict(evaluator="toy", rules="standard", selectivity="native-owned"),
            output_bytes=1000, record_bytes=100,
        )
        experiment = dict(config={}, schedule={}, inputs=[{}], rules="standard")
        for name in ["depth_rank_late_one", "depth_rank_deep_two", "depth_rank_early_one"]:
            for enabled in [False, True]:
                with patch.object(lc, "document", side_effect=[dict(raw, lmr_method=name, lmr=enabled), []]):
                    with self.assertRaisesRegex(lc.Refused, "measurement LMR method"):
                        lc.measurement_config(experiment)
"""
    post[relative] = replace(
        text,
        '\n\nif __name__ == "__main__":',
        method + '\n\nif __name__ == "__main__":',
    )
    temporary = Path(os.environ["TMPDIR"]) / "frames"
    temporary.mkdir()
    for relative, text in post.items():
        path = temporary / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
    before_refs = []
    for relative, text in frames.items():
        path = HERE / "before-gzip" / (relative + ".gz")
        path.parent.mkdir(parents=True, exist_ok=True)
        packed = gzip.compress(text.encode(), mtime=0)
        path.write_bytes(packed)
        assert gzip.decompress(packed) == text.encode()
        before_refs.append(
            {
                "relative": relative,
                "gzip": intake.ref(path),
                "uncompressed_sha256": hashlib.sha256(text.encode()).hexdigest(),
                "uncompressed_bytes": len(text.encode()),
            }
        )
    (HERE / "prepared.json").write_text(
        json.dumps(
            {
                "base": intake.BASE,
                "temporary_frames": str(temporary),
                "retired_file": "crates/quoridor-ai/src/lmr413_tests.rs",
                "reference_two_method_owner": expected,
                "reference_method_SHA256": hashlib.sha256(
                    original_method.encode()
                ).hexdigest(),
                "before_gzip": before_refs,
            },
            indent=2,
        )
        + "\n"
    )
    print(
        json.dumps(
            {
                "prepared": "one retirement source delta",
                "frames": len(post),
                "deleted_file": "lmr413_tests.rs",
                "native_test_compile": "UNBUILT/UNTYPED/UNRUN",
            }
        )
    )


if __name__ == "__main__":
    main()
