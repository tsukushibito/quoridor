"""One source retirement handoff; immutable packet and prior failures unchanged."""

from datetime import datetime, timezone
import importlib.util
import json

import intake

HERE = intake.HERE


def prepare(lc):
    actual = intake.ref(HERE / "source-STOP.json")
    assert (
        actual["sha256"]
        == "0be2fa35575f2cae41a77e74aeaff2ef3eb5720755c5beb3d12844120cffa2c0"
    )
    assert actual["bytes"] == 39042 and actual["mode"] == "0644"
    binding = intake.ref(HERE / "source-binding.json")
    assert (
        binding["sha256"]
        == "80eafb324e5a99c0794dc412f99405527a35b4fa26ec5ae6dd66636c4b3388dc"
    )
    assert binding["bytes"] == 14484 and binding["mode"] == "0644"
    stop = json.loads((HERE / "source-STOP.json").read_text())
    controller = stop["source_controller"]["identity"]
    fresh = lc.process.identity(lc.process.process_info(controller["pid"]))
    assert fresh is None or fresh != controller
    (HERE / "handoff-controller-census.json").write_text(
        json.dumps(
            {
                "observed_UTC": datetime.now(timezone.utc).isoformat(),
                "source_controller": controller,
                "fresh_identity": fresh,
                "original_tool_return": "quality-v2 exit0; sourceSTOP unchanged",
                "owned": [],
            },
            indent=2,
        )
        + "\n"
    )
    refs = {
        name: value
        for name, value in stop["refs"].items()
        if name
        in {
            "source-binding.json",
            "source-manifest.json",
            "retire413.patch",
            "retire413.inverse.patch",
            "static-proof.json",
            "report-ja.md",
            "verification-plan.json",
            "source-context.json",
            "source-v1-controller-error.json",
        }
    }
    body = (
        """quoridor-4lc.413.5 ONE frozen ordinary retirement source handoff. Actualcontext11:03:23.984 cwdMain/gpt-6.1-sol/high/danger-full-access/approvalnever verified. Wrapperready/show confirms actualleaf413.5 SAMEassignee01a11004; actualstatusopen retained, authorstatus/backup/closewrites0, Root324 only. Current324assignee01a1376a verified.
Immutablecurrent367fc042ff6b7a5a2b51d8099e5988cc15da58f1 ->thin8path retirement patch+inverse, beforegzip roundtrip and fullafterSHA-size-mode bound. Main/managedproduction/Git/index/sharedCargo/native/test/Search/model/Perf/game/solver/science/reviewerdispatch0. Original41325ee+a628toyfix+b9d515e7/Build1af3ad9e/software/RAW/settings/errors/fees retained, no rebuild/replay/modifiedoldpacket.413 finalnumericpacket15b47d7c/713091 not reread, Rootinstruction only: no generalbenefit/superiority/same-work/ranking support+no concrete furtheruse/test plan, NOT provenequivalence/inferiority.
Removed DepthRankLateOne/DeepTwo/EarlyOne enum/name/id/rule/extra correction and lmr_additional_reductions field/event plus all measurementcallback/TtProfile/arena completed-terminal extra metadata. No alias/shim/always0/retiredruntime/oldenginecopy. Removed candidateAI5(filelmr413_tests.rs deleted),runner/runtime2,Python1. q0 fixture singleuser nowinline, wrapper/helper/childmodule/counterassert removed. Newonlynegative Rust2+Python1 for retirednames (including OFF) and affectedq0one; exactfilters/counts/feature inplan, UNBUILT/UNTYPED/UNRUN. Existing412generic/default/oldtable/successsuite replay NOTrequested.
Current ADepthRank/FixedOne methodbody restored exact fixed412 component, DepthRankdefault kept; canonicalOnceLocktable body byteexact. Alpha outside selectedmethod/scalar/caller-removal byteexact, lmr_allowed/reduced_child/SafeRace/Approx/distance/fullhistory/TT/root/ordering/PVS/undo/cancel/math and productgeneratorenableOFF preserved. Python measurement_config/arena_plan_check two explicitnames only, lifecycle outside2functions byteexact and AST onlyretiredconstant removal. Existing412 Python definitions+remaining408four exact. Runtimeoutsidecounter ownerexact. Candidate strings remainONLY3negative definitions, no liveacceptor.
Scoped Rustfmt/Ruff/Prettier/static forward->inverse fuzz0/offset0/fulltreeexact/ABSENTdeletedfile->exactrestore/gzip/protected proofs complete. Source-v1 sixchildren diskexit0 inclstaticproof+lint, BUT privateproof helper deleted currentTMP and originalparentfinallyFAILEDFileNotFoundError before result.json persistence. Originalparentreturnmask/guardianID/STOPUTC UNKNOWN, no fabricatedresult; originalsixdisk pending/attempted/rawcaptures/freshchildabsence/directreap/handles retained. Onlycleanuphelper fixed to leave activecontrollerTMP, candidate unchanged, no successfulchecks/native rerun. Firstintake statusopen assertFAILED andqualityunusedPathimportRuffFAILED retained too; fixesprivatehelpers only.
Final actualsourceSTOP/currentcontroller freshabsentdifferent, alloriginalchildidentities freshabsentdifferent/directwait-reap/handles/TMPgone/owned[]; separate orphanparentUNKNOWN scope explicit. SourceCPU3/guardian7/family512MiB/G0/hostreserve4GiB/topology/currentpinnedpeer/no_new_privs/cleanup underexistingport; no AS512 Go/Node/globalquiet/idlelease. OWNallocated4530176B once (includes actualBeads fullcapture), storageNone/FSactualinSTOP/globalactualUNKNOWN/decimal50GB, no assets/targetwalk/oldholding charge/refund. NestedGit/patch independentPID/startUNKNOWN distinct.
Root necessarycompile/research+diagnosticsClippy/release+minimalnew/affected selections, no extra numerical/mathreview or science. Root sparsecompose only, neveroldfullfileoverwrite. AllmixedlearnerALLprep-pipeline/323USERPAUSE/models/weights/seals/oldfits96/foreign/defaultproductgeneratorOFF/oldRAWFAILEDfeesUNKNOWN preserved. Actualleafopen metadata retained; Root updatesinprogress/acceptance/close; no ACK orparentclose gate.
OWN """
        + str(HERE)
        + "\nActualsourceSTOP "
        + json.dumps(actual)
        + "\nBinding "
        + json.dumps(binding)
        + "\nPacket refs "
        + json.dumps(refs, ensure_ascii=False)
        + "\nNo Policycopy/reviewerdispatch/newexperiment requested.\n"
    )
    (HERE / "handoff.txt").write_text(body)
    print(
        json.dumps(
            {
                "STOP": actual,
                "binding": binding,
                "source_controller_fresh": fresh,
                "owned": [],
            }
        )
    )


def complete(lc, here):
    directory = HERE / "send-v1"
    result = json.loads((directory / "result.json").read_text())
    assert result["status"] == "PASS"
    accepted = json.loads((directory / "send-once.full.log").read_text())
    assert accepted["accepted"] is True
    census = []
    for check in result["checks"]:
        returned = check["guardian_return"]
        lc.settled(returned)
        child = returned["child"]
        fresh = lc.process.identity(lc.process.process_info(child["pid"]))
        assert fresh is None or fresh != child
        census.append(
            {
                "name": check["name"],
                "child": child,
                "fresh_identity": fresh,
                "original_settled_return": returned,
                "full_log": check["full_log"],
                "disk_receipt": check["persisted_process_receipt"],
            }
        )
    tmp = directory / "TMP"
    if tmp.exists():
        for path in tmp.iterdir():
            assert (
                path.name == "uv-cc8f3ad7aa19080a.lock"
                and path.is_file()
                and not path.is_symlink()
                and path.stat().st_size == 0
            )
            path.unlink()
        tmp.rmdir()
    fact = {
        "actual_admin_STOP": datetime.now(timezone.utc).isoformat(),
        "source_STOP": intake.ref(HERE / "source-STOP.json"),
        "source_controller": json.loads(
            (HERE / "handoff-controller-census.json").read_text()
        ),
        "accepted_receipt": intake.ref(directory / "send-once.full.log"),
        "delivery_result": intake.ref(directory / "result.json"),
        "original_admin_child_census": census,
        "readers": [],
        "writers": [],
        "children": [],
        "jobs": [],
        "handles": [],
        "TMP": [],
        "leases": [],
        "owned": [],
        "scope": "light metadata epilogue exits after finalwrite, tool return separate",
        "usage": "once in originalsourceSTOP; later tinyadmin excluded",
        "Beads_status_backup_close": "324 only",
    }
    (HERE / "admin-STOP.json").write_text(json.dumps(fact, indent=2) + "\n")
    print(json.dumps({"admin_STOP": intake.ref(HERE / "admin-STOP.json"), "owned": []}))


if __name__ == "__main__":
    loader = importlib.util.spec_from_file_location(
        "retire413_send", "/workspaces/quoridor/scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    prepare(lc)
