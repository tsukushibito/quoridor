"""Exact retirement source STOP, with original lost-ledger scope preserved."""

from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path

import intake


def freeze(lc, here):
    affinity = os.sched_getaffinity(0)
    os.sched_setaffinity(0, {3})
    try:
        records = []
        phases = []
        failures = []
        for path in sorted(here.glob("*-v*/result.json")):
            result = json.loads(path.read_text())
            phases.append(intake.ref(path))
            if result["status"] != "PASS":
                failures.append(
                    {
                        "phase": path.parent.name,
                        "original": intake.ref(path),
                        "primary": result["primary"],
                    }
                )
            for check in result["checks"]:
                returned = check["guardian_return"]
                disk = json.loads(
                    Path(check["persisted_process_receipt"]["path"]).read_text()
                )
                if returned is not None:
                    lc.settled(returned)
                else:
                    assert check["status"] == "FAILED"
                facts = returned if returned is not None else disk
                assert (
                    facts["direct_child_reaped"]
                    and facts["cleanup_complete"]
                    and facts["handle_closes_complete"]
                    and not facts["remaining"]
                )
                child = facts["child"]
                fresh = lc.process.identity(lc.process.process_info(child["pid"]))
                assert fresh is None or fresh != child
                records.append(
                    {
                        "phase": path.parent.name,
                        "name": check["name"],
                        "status": check["status"],
                        "child": child,
                        "fresh_identity": fresh,
                        "launch_policy": facts["launch_policy"],
                        "returned_scope": "UNKNOWN NULL, persisted cleanup scope only"
                        if returned is None
                        else "original settled guardian directwait/reap/handles/cleanup",
                        "returned_mask": None
                        if returned is None
                        else returned["signal_mask_restoration"],
                        "returned_persist": None
                        if returned is None
                        else returned["final_record_persist"],
                        "disk_mask": disk.get("signal_mask_restoration"),
                        "disk_persist": disk.get("final_record_persist"),
                        "capture_complete_reported": check["capture_complete"],
                        "full_log": check["full_log"],
                        "disk_receipt": check["persisted_process_receipt"],
                        "original_seconds_once_nested_excluded": facts["wall_seconds"],
                    }
                )
            assert not (path.parent / "TMP").exists()
        # Original parent failed before persisting its result, while all six
        # children had already returned. Never synthesize its lost return masks.
        orphan = here / "source-v1"
        assert not (orphan / "result.json").exists()
        assert not (orphan / "TMP").exists()
        orphan_children = []
        for path in sorted(orphan.glob("*.process.json")):
            disk = json.loads(path.read_text())
            assert disk["exit_code"] == 0 and disk["direct_child_reaped"]
            assert (
                disk["cleanup_complete"]
                and disk["handle_closes_complete"]
                and not disk["remaining"]
            )
            child = disk["child"]
            fresh = lc.process.identity(lc.process.process_info(child["pid"]))
            assert fresh is None or fresh != child
            name = path.name.removesuffix(".process.json")
            orphan_children.append(
                {
                    "name": name,
                    "original_disk_receipt": intake.ref(path),
                    "original_full_log": intake.ref(orphan / (name + ".full.log")),
                    "child": child,
                    "fresh_identity": fresh,
                    "exit_code": disk["exit_code"],
                    "direct_child_reaped": disk["direct_child_reaped"],
                    "cleanup_complete": disk["cleanup_complete"],
                    "handle_closes_complete": disk["handle_closes_complete"],
                    "launch_policy": disk["launch_policy"],
                    "returned_guardian_and_mask": "UNKNOWN, original in-memory parent ledger absent",
                    "capture_complete_reported": "UNKNOWN, original ledger absent; original full file retained",
                    "disk_mask": disk["signal_mask_restoration"],
                    "disk_persist": disk["final_record_persist"],
                    "original_seconds_once_nested_excluded": disk["wall_seconds"],
                }
            )
        assert len(orphan_children) == 6
        binding = json.loads((here / "source-binding.json").read_text())
        for row in binding["subjects"]:
            packed = row["before"]
            path = Path(packed["gzip"]["path"])
            assert intake.ref(path) == packed["gzip"]
            raw = gzip.decompress(path.read_bytes())
            assert (
                hashlib.sha256(raw).hexdigest() == packed["uncompressed_sha256"]
                and len(raw) == packed["uncompressed_bytes"]
            )
            if "postimage" in row:
                assert intake.ref(Path(row["postimage"]["path"])) == row["postimage"]
            for component in row.get("components", []):
                for key in ["before", "after"]:
                    assert intake.ref(Path(component[key]["path"])) == component[key]
        controller = lc.process.identity(lc.process.process_info(os.getpid()))
        usage = lc.process.directory_bytes(here)
        fs = os.statvfs(here)
        result = {
            "issue": "quoridor-4lc.413.5",
            "status": "SOURCE_FROZEN_NATIVE_UNBUILT_UNTYPED_UNRUN",
            "actual_source_reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
            "refs": {
                name: intake.ref(here / name)
                for name in [
                    "source-binding.json",
                    "source-manifest.json",
                    "retire413.patch",
                    "retire413.inverse.patch",
                    "static-proof.json",
                    "report-ja.md",
                    "verification-plan.json",
                    "source-context.json",
                    "source-v1-controller-error.json",
                    "ownership-selected.json",
                    "source-modes.txt",
                    "guarded.py",
                    "prepare.py",
                    "prove.py",
                    "packet.py",
                    "finish.py",
                ]
            },
            "source_controller": {
                "identity": controller,
                "scope": "light metadata epilogue, exits after finalwrite; fresh identity checked after tool return",
            },
            "phases": phases,
            "fresh_original_child_census": records,
            "original_failures": failures,
            "original_source_v1_parent": {
                "status": "FAILED original tool exit1 TMP finally",
                "original_reader_STOP_UTC": "UNKNOWN, not persisted",
                "original_guardian_identity": "UNKNOWN, not separately persisted",
                "result_json": "ABSENT; not reconstructed",
                "error_observation": intake.ref(
                    here / "source-v1-controller-error.json"
                ),
                "original_children_disk_scope": orphan_children,
            },
            "native_type_tests_Search_model_Perf_game_solver_Cargo_build_Main_managedproduction_Git_index_Beads_reviewdispatch": 0,
            "readers": [],
            "writers": [],
            "children": [],
            "jobs": [],
            "handles": [],
            "TMP": [],
            "leases": [],
            "owned": [],
            "canonical_hardware_lease": "NONE; no global/futurequiet/idlelease",
            "nested_Git_patch": "subprocess.run synchronous waits; separate PID/start/boot UNKNOWN, original guardian descendant scopes distinct",
            "storage": {
                "budget": None,
                "directed_OWN_allocated_B_once": usage,
                "dedupe": "existing directory_bytes dev/inode over OWNretirement only",
                "FS_available_B": fs.f_bavail * fs.f_frsize,
                "excluded": "this STOP and later tinyadmin, no assets/target/globalwalk or oldholding charge/refund",
                "global_actual": "UNKNOWN; decimal50GB retained",
            },
            "Beads_status_backup_close": "324 only; actual ownership-selected statusopen preserved, author mutation0; Root updates/accepts/closes",
            "preserved": "413 originalsource/software/image b9d515e7/Build1af3ad9e/configs/RAW/errors/feesUNKNOWN and411/412/410/414packets; allmixedlearnerALLprep-pipeline/323pause/productgeneratorOFF/models/weights/seals/oldfits96/foreign",
        }
        (here / "source-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "source_STOP": intake.ref(here / "source-STOP.json"),
                    "binding": intake.ref(here / "source-binding.json"),
                    "OWN_allocated_B_once": usage,
                    "owned": [],
                }
            )
        )
    finally:
        os.sched_setaffinity(0, affinity)
