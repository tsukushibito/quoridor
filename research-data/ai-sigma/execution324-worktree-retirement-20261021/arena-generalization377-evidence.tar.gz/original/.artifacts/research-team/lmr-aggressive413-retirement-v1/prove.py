"""Strict private retirement/protected-owner proof, no native/test execution."""

import ast
import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

import intake
import prepare

HERE = intake.HERE


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data)


def change(before, after, relative):
    return "".join(
        difflib.unified_diff(
            before.splitlines(True),
            after.splitlines(True),
            fromfile="a/" + relative if before else "/dev/null",
            tofile="b/" + relative if after else "/dev/null",
            n=3,
        )
    )


def main():
    before = prepare.bases()
    prepared = json.loads((HERE / "prepared.json").read_text())
    temporary = Path(prepared["temporary_frames"])
    post = {
        str(path.relative_to(temporary)): path.read_text()
        for path in temporary.rglob("*")
        if path.is_file()
    }
    alpha = "crates/quoridor-ai/src/alphabeta.rs"
    start, stop = (
        "/// Additional reduction from normal child depth",
        "/// Heuristic leaves, not exact WDL",
    )
    norm = post[alpha].replace(
        prepare.block(post[alpha], start, stop),
        prepare.block(before[alpha], start, stop),
        1,
    )
    norm = prepare.replace(
        norm,
        "    pub lmr_attempts: u64,\n",
        "    pub lmr_attempts: u64,\n    /// Started scouts whose extra reduction exceeds canonical depth_rank q.\n    /// Counts calls (including interrupted calls), not additional plies.\n    pub lmr_additional_reductions: u64,\n",
    )
    marker = "            let mut v = if reduced {\n"
    prefix = prepare.block(before[alpha], marker, "                self.reduced_child(")
    norm = prepare.replace(norm, marker, prefix)
    assert norm == before[alpha], (
        "Alpha protected outside selected method/counter changed"
    )
    table_start = "            LMR_DEPTH_RANK.get_or_init"
    table_end = "    fn reduction(self"
    assert prepare.block(before[alpha], table_start, table_end) == prepare.block(
        post[alpha], table_start, table_end
    )
    for marker in [
        "    fn lmr_allowed(",
        "    fn reduced_child(",
        "    fn safe_race_value(",
        "    fn zero_stock_approx_value(",
    ]:
        assert intake.definition(before[alpha], marker) == intake.definition(
            post[alpha], marker
        )
    actual_method = prepare.block(post[alpha], start, stop)
    assert (
        hashlib.sha256(actual_method.encode()).hexdigest()
        == prepared["reference_method_SHA256"]
    )
    relative = "crates/quoridor-ai/src/lmr408_tests.rs"
    old = before[relative]
    new = post[relative]
    for marker in [
        "fn lmr408_names_table_units_zero_edges_and_sixty_three_clamps()",
        "fn lmr408_effective_method_namespace_history_reset_warm_and_approx_independence()",
        "fn lmr408_saved_protection_precedes_depth_rank_quantum()",
        "fn lmr408_multi_ply_full_depth_confirmation_error_cancel_and_parent_restore()",
    ]:
        assert intake.definition(old, marker) == intake.definition(new, marker)
    helper = intake.definition(
        old, "fn zero_quantum_tt_first_fixture(method: LmrMethod)"
    )
    restored = helper.replace(
        "fn zero_quantum_tt_first_fixture(method: LmrMethod)",
        "fn lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial()",
    )
    restored = restored.replace(
        "method.prepare();", "LmrMethod::DepthRank.prepare();"
    ).replace(
        "s.stats.lmr_method = method;", "s.stats.lmr_method = LmrMethod::DepthRank;"
    )
    restored = prepare.replace(
        restored, "            assert_eq!(s.stats.lmr_additional_reductions, 0);\n", ""
    )
    assert restored == intake.definition(
        new,
        "fn lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial()",
    )
    assert "zero_quantum_tt_first_fixture" not in new and "mod lmr413_tests" not in new
    relative = "crates/quoridor-runner/src/measurement.rs"
    old = before[relative]
    positive = intake.definition(old, "mod lmr413_metadata_tests")
    old = prepare.replace(old, "\n#[cfg(test)]\n" + positive, "").rstrip()
    old = prepare.replace(
        old, ',"LMR_additional_reductions":s.lmr_additional_reductions', ""
    )
    old = prepare.replace(
        old,
        '    result["work"]["LMR_additional_reductions"] = json!(s.lmr_additional_reductions);\n',
        "",
    )
    new = post[relative]
    negative = intake.definition(new, "mod lmr413_retirement_tests")
    new = prepare.replace(new, "\n#[cfg(test)]\n" + negative, "").rstrip()
    assert old == new
    relative = "crates/quoridor-runner/src/runtime.rs"
    old = before[relative]
    old = prepare.replace(
        old, "    #[serde(default)]\n    pub lmr_additional_reductions: u64,\n", ""
    )
    old = prepare.replace(
        old,
        "        self.lmr_additional_reductions += s.lmr_additional_reductions;\n",
        "",
    )
    old = prepare.replace(
        old, ',"additional_reductions":r.stats.lmr_additional_reductions', "", count=2
    )
    assert old == post[relative]
    relative = "crates/quoridor-runner/src/runtime_lmr_method_tests.rs"
    method = intake.definition(
        before[relative],
        "fn runtime413_candidate_methods_bind_factory_and_accumulate_actual_scout_counter()",
    )
    assert (
        prepare.replace(before[relative], "\n#[test]\n" + method, "").rstrip()
        == post[relative].rstrip()
    )
    publisher = "scripts/dev/research-lifecycle.py"
    old_fns = prepare.python_functions(before[publisher])
    new_fns = prepare.python_functions(post[publisher])
    changed = {name for name in old_fns if old_fns[name] != new_fns[name]}
    assert changed == {"measurement_config", "arena_plan_check"}
    norm = post[publisher]
    for name in changed:
        norm = prepare.replace(norm, new_fns[name], old_fns[name])
        old_ast = ast.parse(old_fns[name])
        for node in ast.walk(old_ast):
            if isinstance(node, (ast.Tuple, ast.Set)):
                node.elts = [
                    v
                    for v in node.elts
                    if not (isinstance(v, ast.Constant) and v.value in prepare.RETIRED)
                ]
        assert ast.dump(old_ast) == ast.dump(ast.parse(new_fns[name]))
    assert norm == before[publisher], (
        "publisher bytes outside two function owners changed"
    )
    relative = "scripts/dev/test_research_lmr_standard.py"

    def methods(text):
        lines = text.splitlines(True)
        return {
            node.name: "".join(lines[node.lineno - 1 : node.end_lineno])
            for node in ast.walk(ast.parse(text))
            if isinstance(node, ast.FunctionDef)
        }

    old_methods, new_methods = methods(before[relative]), methods(post[relative])
    assert set(old_methods) - set(new_methods) == {
        "test_lmr413_named_methods_reach_current_measurement_and_prepare_consumers"
    }
    assert set(new_methods) - set(old_methods) == {
        "test_lmr413_retired_names_rejected_by_current_measurement"
    }
    for name in old_methods.keys() & new_methods.keys():
        assert old_methods[name] == new_methods[name]
    retired_file = prepared["retired_file"]
    assert retired_file in before and retired_file not in post
    negative_sites = {
        "crates/quoridor-ai/src/lmr408_tests.rs": "fn lmr413_retired_names_rejected_by_current_method_owner()",
        "crates/quoridor-runner/src/measurement.rs": "fn measurement413_retired_names_refused_even_when_lmr_off()",
    }
    for relative, text in post.items():
        assert (
            "lmr_additional_reductions" not in text
            and "LMR_additional_reductions" not in text
        )
        assert not any(
            name in text
            for name in [
                "DepthRankLateOne",
                "DepthRankDeepTwo",
                "DepthRankEarlyOne",
                "zero_quantum_tt_first_fixture",
            ]
        )
        if relative in negative_sites:
            text = text.replace(intake.definition(text, negative_sites[relative]), "")
        elif relative == "scripts/dev/test_research_lmr_standard.py":
            text = text.replace(
                new_methods[
                    "test_lmr413_retired_names_rejected_by_current_measurement"
                ],
                "",
            )
        assert not any(name in text for name in prepare.RETIRED), relative
    all_paths = sorted(before.keys() | post.keys())
    forward = "".join(
        change(before.get(rel, ""), post.get(rel, ""), rel) for rel in all_paths
    )
    inverse = "".join(
        change(post.get(rel, ""), before.get(rel, ""), rel) for rel in all_paths
    )
    (HERE / "retire413.patch").write_text(forward)
    (HERE / "retire413.inverse.patch").write_text(inverse)
    proof = Path(os.environ["TMPDIR"]) / "roundtrip"
    proof.mkdir()
    for relative, text in before.items():
        write(proof / relative, text)
    receipts = []
    for patch, expected in [
        ("retire413.patch", post),
        ("retire413.inverse.patch", before),
    ]:
        result = subprocess.run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "--no-backup-if-mismatch",
                "-p1",
                "-i",
                str(HERE / patch),
            ],
            cwd=proof,
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stdout + result.stderr
        assert (
            "fuzz" not in result.stdout.lower()
            and "offset" not in result.stdout.lower()
        )
        actual = {
            str(p.relative_to(proof)): p.read_text()
            for p in proof.rglob("*")
            if p.is_file()
        }
        assert actual == expected
        receipts.append(
            {
                "patch": intake.ref(HERE / patch),
                "returncode": result.returncode,
                "stdout": result.stdout,
                "complete_tree_exact": True,
                "deleted_file_absent_or_restored_exact": True,
            }
        )
    manifest = []
    for relative in all_paths:
        packed = next(
            row for row in prepared["before_gzip"] if row["relative"] == relative
        )
        assert intake.ref(Path(packed["gzip"]["path"])) == packed["gzip"]
        assert (
            gzip.decompress(Path(packed["gzip"]["path"]).read_bytes()).decode()
            == before[relative]
        )
        row = {
            "relative": relative,
            "before": packed,
            "after": None
            if relative not in post
            else {
                "sha256": hashlib.sha256(post[relative].encode()).hexdigest(),
                "bytes": len(post[relative].encode()),
                "mode": "0644",
            },
        }
        if relative in post and relative not in {
            publisher,
            "crates/quoridor-runner/src/runtime.rs",
        }:
            write(HERE / "post" / relative, post[relative])
            row["postimage"] = intake.ref(HERE / "post" / relative)
        elif relative == publisher:
            row["components"] = []
            for name in sorted(changed):
                for directory, text in [
                    ("before-components", old_fns[name]),
                    ("post", new_fns[name]),
                ]:
                    write(HERE / directory / (name + ".py"), text + "\n")
                row["components"].append(
                    {
                        "function": name,
                        "before": intake.ref(
                            HERE / "before-components" / (name + ".py")
                        ),
                        "after": intake.ref(HERE / "post" / (name + ".py")),
                    }
                )
        elif relative in post:
            row["components"] = []
            for marker, name in [
                ("struct TtProfile", "TtProfile.rs"),
                (
                    "    fn record(&mut self, result: &alphabeta::SearchResult)",
                    "TtProfile_record.rs",
                ),
            ]:
                for directory, frame in [
                    ("before-components", before[relative]),
                    ("post", post[relative]),
                ]:
                    write(
                        HERE / directory / name, intake.definition(frame, marker) + "\n"
                    )
                row["components"].append(
                    {
                        "subject": name,
                        "before": intake.ref(HERE / "before-components" / name),
                        "after": intake.ref(HERE / "post" / name),
                    }
                )
            for directory, frame in [
                ("before-components", before[relative]),
                ("post", post[relative]),
            ]:
                text = (
                    "\n".join(
                        line
                        for line in frame.splitlines()
                        if '"lmr_work_completed"' in line
                        or '"lmr_work_terminal"' in line
                    )
                    + "\n"
                )
                write(HERE / directory / "arena_lmr_work.rs", text)
            row["components"].append(
                {
                    "subject": "arena_lmr_work.rs",
                    "before": intake.ref(HERE / "before-components/arena_lmr_work.rs"),
                    "after": intake.ref(HERE / "post/arena_lmr_work.rs"),
                }
            )
        manifest.append(row)
    (HERE / "source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    proof_result = {
        "status": "STATIC_PASS_ONLY",
        "base": intake.BASE,
        "strict_forward_inverse": receipts,
        "deleted_file": retired_file,
        "negative_strings_only": list(negative_sites)
        + ["scripts/dev/test_research_lmr_standard.py"],
        "protected": [
            "Alpha outside two-method definition/counter deletion byte exact",
            "current A/FixedOne owner restored exact prior412 component, defaultDepthRank retained",
            "canonical table construction body and lmr_allowed/reduced_child/SafeRace/Approx bodies byte exact",
            "runtime outside counter serialization/aggregation byte exact",
            "publisher outside two allowlist functions byte exact; only retired constants removed from AST",
            "existing412 Python definitions byte exact; remaining408 four definitions exact; q0 only one-caller cleanup",
            "no new shim/alias/placeholder/profile/registry/namespace builder",
        ],
        "native": "UNBUILT/UNTYPED/UNRUN",
        "nested_patch_identity": "synchronous subprocess.run wait/reap; independent PID/start/boot unrecorded UNKNOWN, original guardian family scope separate",
    }
    (HERE / "static-proof.json").write_text(json.dumps(proof_result, indent=2) + "\n")
    # The gzip is the bound beforeimage; no redundant persistent unmodified
    # runtime/publisher/full-source mirror is kept in the private output.
    shutil.rmtree(proof)
    shutil.rmtree(temporary)
    if (
        temporary.parent != Path(os.environ["TMPDIR"])
        and temporary.parent.exists()
        and not any(temporary.parent.iterdir())
    ):
        temporary.parent.rmdir()
    print(
        json.dumps(
            {
                "static": "PASS",
                "changed_paths": len(all_paths),
                "deleted": retired_file,
                "new_Rust": 2,
                "new_Python": 1,
                "native": "UNBUILT/UNTYPED/UNRUN",
                "TMP_frames_removed": True,
            }
        )
    )


if __name__ == "__main__":
    main()
