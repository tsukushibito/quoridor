"""Selected ownership and immutable live consumers, not scientific payloads."""

import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
BASE = "367fc042ff6b7a5a2b51d8099e5988cc15da58f1"


def git(*args):
    return subprocess.run(
        [
            "git",
            "-c",
            "core.packedGitWindowSize=8m",
            "-c",
            "core.packedGitLimit=32m",
            "--no-optional-locks",
            *args,
        ],
        cwd="/workspaces/quoridor",
        capture_output=True,
        check=True,
    ).stdout


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def definition(text, marker):
    left = text.index(marker)
    cursor = text.index("{", left) + 1
    depth = 1
    while depth:
        depth += (text[cursor] == "{") - (text[cursor] == "}")
        cursor += 1
    return text[left:cursor]


def main():
    selected = {}
    for name in ["own-leaf", "current-integration"]:
        (issue,) = json.loads(
            (HERE / "ownership-v1" / (name + ".full.log")).read_text()
        )
        selected[name] = {k: issue.get(k) for k in ["id", "status", "assignee"]}
    assert selected["own-leaf"]["id"] == "quoridor-4lc.413.5"
    assert (
        selected["own-leaf"]["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
    )
    # Root alone changes status. An assigned open leaf is the supplied actual
    # ownership, not a reason to add an ACK gate before authorized private work.
    assert selected["own-leaf"]["status"] in {"open", "in_progress"}
    assert (
        selected["current-integration"]["assignee"]
        == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
    )
    assert git("rev-parse", "--verify", BASE + "^{commit}").decode().strip() == BASE
    (HERE / "ownership-selected.json").write_text(json.dumps(selected, indent=2) + "\n")
    print(json.dumps(selected))
    matches = git(
        "grep",
        "-n",
        "-E",
        "DepthRankLateOne|DepthRankDeepTwo|DepthRankEarlyOne|depth_rank_(late_one|deep_two|early_one)|lmr_additional_reductions|LMR_additional_reductions",
        BASE,
        "--",
        "crates/quoridor-ai/src",
        "crates/quoridor-runner/src",
        "scripts/dev",
        "python",
        "docs/development/ai-research-code.md",
    ).decode()
    (HERE / "selected-live-matches.txt").write_text(matches)
    paths = sorted({line.split(":", 2)[1] for line in matches.splitlines()})
    print(matches)
    owners = []
    for relative in paths:
        raw = git("show", BASE + ":" + relative)
        owners.append(
            {
                "relative": relative,
                "Git": BASE,
                "blob_oid": git("rev-parse", BASE + ":" + relative).decode().strip(),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": "100644",
            }
        )
        # Retain only affected source/test subjects. Full lifecycle/runtime are
        # transient immutable frames later; their patches/functions are sparse.
        if relative not in {
            "scripts/dev/research-lifecycle.py",
            "crates/quoridor-runner/src/runtime.rs",
        }:
            path = HERE / "before" / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
    (HERE / "intake-refs.json").write_text(
        json.dumps(
            {
                "base": BASE,
                "ownership": ref(HERE / "ownership-selected.json"),
                "selected_match_capture": ref(HERE / "selected-live-matches.txt"),
                "owners": owners,
                "source_only": True,
            },
            indent=2,
        )
        + "\n"
    )
    for relative in [
        "crates/quoridor-ai/src/lmr408_tests.rs",
        "scripts/dev/test_research_lmr_standard.py",
    ]:
        text = (
            (HERE / "before" / relative).read_text()
            if (HERE / "before" / relative).exists()
            else git("show", BASE + ":" + relative).decode()
        )
        if relative.endswith("lmr408_tests.rs"):
            print("CURRENT_Q0", definition(text, "fn zero_quantum_tt_first_fixture"))
        else:
            print("CURRENT_PYTHON_END", text[-2500:])


if __name__ == "__main__":
    main()
