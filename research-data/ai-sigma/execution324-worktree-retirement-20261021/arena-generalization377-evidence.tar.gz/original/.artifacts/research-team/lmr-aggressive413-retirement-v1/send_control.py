"""Existing guarded port, light source-handoff metadata epilogue only."""

import finish
import send_admin

finish.freeze = send_admin.complete
__import__("guarded")
