"""One source retirement report, no numerical interpretation or replay."""

import json
import shutil

import intake

HERE = intake.HERE


def main():
    manifest = json.loads((HERE / "source-manifest.json").read_text())
    ownership = json.loads((HERE / "ownership-selected.json").read_text())
    paths = [row["relative"] for row in manifest]
    modes = intake.git("ls-tree", intake.BASE, "--", *paths).decode()
    assert len(modes.splitlines()) == len(paths) and all(
        line.startswith("100644 blob ") for line in modes.splitlines()
    )
    (HERE / "source-modes.txt").write_text(modes)
    prepared = json.loads((HERE / "prepared.json").read_text())
    binding = {
        "issue": "quoridor-4lc.413.5",
        "scope": "retire only comparison-ended unsupported candidates, source only",
        "actual_ownership": ownership,
        "immutable_Main": intake.BASE,
        "intake": intake.ref(HERE / "intake-refs.json"),
        "source_modes": intake.ref(HERE / "source-modes.txt"),
        "subjects": manifest,
        "reference_A_FixedOne_method_owner": prepared["reference_two_method_owner"],
        "reference_method_SHA256": prepared["reference_method_SHA256"],
        "forward": intake.ref(HERE / "retire413.patch"),
        "inverse": intake.ref(HERE / "retire413.inverse.patch"),
        "static_proof": intake.ref(HERE / "static-proof.json"),
        "native": "UNBUILT/UNTYPED/UNRUN",
        "Root_Composition": "sparse subjects against named367fc current source, never old fullfile overwrite; original scienceimage b9d515e7/Build1af3ad9e unchanged",
    }
    (HERE / "source-binding.json").write_text(json.dumps(binding, indent=2) + "\n")
    verification = {
        "status": "author native/type/tests UNBUILT/UNTYPED/UNRUN",
        "new_Rust": {
            "count": 2,
            "AI_feature": "research-diagnostics",
            "runner_feature": "research-diagnostics",
            "names": [
                "lmr413_retired_names_rejected_by_current_method_owner",
                "measurement413_retired_names_refused_even_when_lmr_off",
            ],
        },
        "new_Python": {
            "count": 1,
            "path": "scripts/dev/test_research_lmr_standard.py",
            "name": "ResearchLmrStandardTests.test_lmr413_retired_names_rejected_by_current_measurement",
        },
        "affected_required": {
            "count": 1,
            "AI_feature": "research-diagnostics",
            "name": "lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial",
            "reason": "changed one-user fixture inlined back, parameter/candidate counter assertion removed; other existing408 bodies untouched",
        },
        "retired_definitions": {
            "AI": 5,
            "runner": 2,
            "Python": 1,
            "file": "crates/quoridor-ai/src/lmr413_tests.rs",
            "one_old_toy_type_repair": "preserved in bound beforegzip/Git, not rerun",
        },
        "Root_software": "necessary research/research-diagnostics compile, relevant Clippy/release and the exact new/affected owning selections only; no existing412 generic/default successful-suite replay requested",
        "negative_boundary": "three removed names fail AI from_name and actual native/Python measurement validation even OFF. Runtime uses unchanged AI owner. arena_plan_check two-name allowlist AST-only removal, no duplicate parser/compatibility alias; owning compile/static proof covers unchanged generic factory.",
        "source_proofs": "current complete before->forward->inverse exact, deleted-file ABSENT then exact restore, gzip roundtrip, method/table/protected math/PVS/TT/history/distance and lifecycle outside2 functions byte/AST checks",
        "no_science_review": "normal source retirement only, author reviewerdispatch0; no numeric/math review added or call/game/model/Search/solver/build replay",
    }
    (HERE / "verification-plan.json").write_text(
        json.dumps(verification, indent=2) + "\n"
    )
    context = {
        "actual_turn_context": {
            "timestamp": "2026-10-15T11:03:23.984Z",
            "cwd": "/workspaces/quoridor",
            "model": "gpt-6.1-sol",
            "effort": "high",
            "sandbox": "danger-full-access",
            "approval": "never",
        },
        "resources": "CPU3/guardian7/family512MiB/GPU0/hostreserve4GiB existing source port, actual availability/distinct topology/selected-core pinned-peer absence eachphase; no global/futurequiet/idlelease; no AS512 on Go/Node",
        "ownership": ownership,
        "Root_status_backup_close": "324 only; original actual leaf status open observed, no author mutation; assigned authorized source work proceeded without ACK gate",
        "numerical_basis": {
            "scope": "Root-provided instruction only, not read/recomputed by author",
            "path": "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-aggressive413-v1/final-interpretation-v1/result.json",
            "sha256": "15b47d7cda5e2de9f1f5bae523673a426765f6f0eaf4c28e7e430d1a8b79321d",
            "bytes": 713091,
            "mode": "NOT_CHECKED",
            "decision_reason": "no demonstrated general benefit/superiority/same-work speed/ranking and no concrete further use/test plan, not proof of equivalence or inferiority",
        },
        "source_writes": "OWN retirement output only; Main/managedproduction/Git/index/sharedCargo/Beads and old411/412/413/414 packets unchanged",
    }
    (HERE / "source-context.json").write_text(json.dumps(context, indent=2) + "\n")
    orphan = {
        "phase": "source-v1",
        "original_tool_exit_code": 1,
        "exception": "FileNotFoundError in guarded.py finally: source-v1/TMP removed before remaining=list(TMP.iterdir())",
        "original_result_json": "ABSENT; never fabricated",
        "original_reader_STOP_UTC": "UNKNOWN: finally failed before persistence",
        "original_guardian_return_and_masks": "UNKNOWN: in-memory ledger not persisted; use each original disk receipt scope, do not promote pending/attempted",
        "original_helper": intake.ref(HERE / "original-helper/prove-before-TMP-fix.py"),
        "child_fact": "six command disk receipts and fullcaptures retained; static-proof child exit0, lint exit0; no rerun of completed source checks or any native assertion",
        "repair": "only proof cleanup helper now leaves its current controller TMP to controller; code source candidate unchanged; scoped Ruff checks repaired helper only",
    }
    (HERE / "source-v1-controller-error.json").write_text(
        json.dumps(orphan, indent=2) + "\n"
    )
    # Before-gzip exact roundtrip already proved; discard only this task's
    # redundant unmodified loose copies, not any frozen pre-existing packet.
    loose = HERE / "before"
    if loose.exists():
        shutil.rmtree(loose)
    report = """# 413.5: 比較終了した候補の現役経路撤去

**DepthRankLateOne/DeepTwo/EarlyOneと候補専用counterを、指定の現役sourceから除く薄いpatchを準備しました。Main適用・native/type/test/buildは未実施（UNBUILT/UNTYPED/UNRUN）です。**

指定immutable baseは367fc042ff6b7a5a2b51d8099e5988cc15da58f1（413 source25ee392b＋toy型修正a6282a4d＋412publication）。wrapper ready/showで実leaf quoridor-4lc.413.5と同じ本人assigneeを確認。実statusはopenだったため、in_progressだけを許すhelperの最初のassertがFAILEDになりました。元capture/receiptを保全し、Rootのみstatusを更新する契約に合わせて割当済みopenも受け付けました。作者によるBeads/status/backup/close操作はありません。

撤去の理由は、Rootから渡された固定有限結果では一般benefit/優越/同仕事速度/候補順位が支持されず、具体的な追加利用/試験計画もないためです。等価や劣位が証明されたためとは説明しません。Root指定のfinal-interpretation SHA15b47d7c/713091は指示の根拠として記録しただけで、科学payload/RAW/reportを読み直したり数値再計算していません。既存science image b9d515e7/Build1af3ad9eのbuild/replay/変更は0です。

## 変更する現役8paths

- alpha: 3enum/name/id/rule/追加量補正とlmr_additional_reductions scalar/実発動countを除去。DepthRank/FixedOneの定義は固定412の実owner componentとbyte exactへ戻し、DepthRank既定は保持。canonical表/OnceLockの式・構築bodyは現baseともbyte exact。
- lmr408_tests: 一利用者となったq0 fixtureを元のowning testへinlineし、候補用引数/helper/module/counter assertionを削除。残る既存四定義はbyte exact。短いretired-name拒否定義一つを追加。
- lmr413_tests.rs: 候補専用AI5を含むfileを現役から削除。beforegzipとGitに原型・toy型修正を保存。
- measurement: work/callbackの追加counterと候補専用metadata testを除去。actual validateがOFFでも三名を拒否する小definition一つへ置換。
- runtime: TtProfile scalar/集約とarena completed/terminalのextra fieldを除去。always0 placeholder/互換fieldは残さない。通常LMR attempts/confirmations/researchesは保持。
- runtime_lmr_method_tests: 候補専用factory/counter testだけ削除。現役A/FixedOne/OFF/412の定義は保持。
- lifecycle: measurement_config/arena_plan_checkのallowlistから三名のみ除去し、現役二名へ。関数外bytesと関数ASTのその他条件は保護。
- test_research_lmr_standard: 候補positive-definition一つを削除し、actual measurement_configでOFF/ON双方の拒否を確認するnegative一つへ。既存412二定義はbyte exact。

negative内の三つの文字列は拒否対象であり、互換alias/実行経路ではありません。生きたenum/API/consumerから三名と全additional-reductions fieldが消えることを静的確認しました。新profile/registry/parser/namespace builder/cache/古いengineコピーは0です。currentguideには対象名のlive設定箇所がなく、historical findings/結果を削除・書換えません。

通常q表、root/TT/goal/killer保護、通常childdepth確認/PVS、ordering/keyfreeze、TT/fullhistory、makeundo/cancel/error、score/modelは変更しません。411 SafeRace/ApproxRace/FixedDの設定・TTkind・距離owner・数式・既定OFFはalphaの変更外byte proofで保護。製品/実generator enableOFFと412の研究標準DepthRank採用も保持します。

## 検証と失敗のscope

現役base全8pathsをprivate frameでforward→inverseし、fuzz0/offset0・完全tree一致、候補fileのABSENT→元の正確復元、gzip roundtripを確認。Rustfmt/プロジェクトRuffとsource/protected byte/ASTチェックのchildはexit0で完了しました。新native/type/test実行PASSではありません。必要新定義はRust2＋Python1、affectedは整理したq0一つだけを正確filter/countでverification-planへ記載。既存412のgeneric/default成功定義や旧table/solver/success suiteを再演する計画はありません。Rootが必要compile/research+diagnostics Clippy/releaseを発行します。通常source撤去に新たな数値/数学review dispatchはありません。

source-v1のproof helperが自身のframeを消した後、同じcontrollerのTMPまで消し、controllerの最終STOP保存がFileNotFoundErrorでFAILEDになりました。六つのchild disk receipt/fullcapturesは残り、static proofとlint childはexit0です。parent result.jsonは不存在で、returned guardian/mask/STOP UTCを再構成しません。disk pending/attempted/cleanupを別scopeとして残し、helperのTMP親削除条件だけ修正。候補sourceはそのまま、完了したformatter/proof/lint childを再実行していません。元helperもoriginal-helperに保全し、最終fresh process censusで停止を確認します。

beforeimageはこの有限対象8pathsのgzip＋SHA-size-mode/Git blobへbindし、必要componentと全postimage hashをsource-manifestへ保存。runtime/publisher full frameはTMPのみ、終了後削除。元413/412/411/410/414 packetやmodelsを変更せず、Mainへ古いfullfileを上書きしません。Rootが正確な薄いsubjectを合成します。

CPU3/guardian7/family512MiB/GPU0/hostreserve4GiBを現役guardで実制御し、実available affinity/physical/readback/瞬間的対象pinned-peer不在、no_new_privs/fullcapture/directwait/reap/handlesを記録。global/futurequietやidle leaseは主張しません。Go/NodeにAS512は課していません。nested Git/patchの個別PID/startはUNKNOWNと分けます。普通source storageNone、OWN一度のdev/inode使用とactual freshID/TMP/reader-writerSTOP/owned[]はsource-STOP.jsonにあります。全assets/target/global walkや旧holding再加算/refundはありません。

Root324だけがMain/Git/index/sharedCargo/Beads/status/backup/closeを所有します。作者は私有出力のみ、native/Search/model/Perf/game/solver/science/レビューdispatch0。全mixed/learner prep-pipelineと323 USERPAUSE、product/generatorOFF、models/weights/seals/oldfits96/foreign/旧RAWFAILED全費UNKNOWNは保持。本人leafの受入れ・状態更新・closeもRoot担当で、ACK/parentcloseをsource作業のgateにしていません。
"""
    (HERE / "report-ja.md").write_text(report)
    print(
        json.dumps(
            {
                "source_only": True,
                "new_Rust": 2,
                "new_Python": 1,
                "affected_q0": 1,
                "native": "UNBUILT/UNTYPED/UNRUN",
                "source_v1_parent_failure_preserved": True,
            }
        )
    )


if __name__ == "__main__":
    main()
