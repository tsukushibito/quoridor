"""Finite static patch, inverse and untouched-owner check; no native execution."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
before = json.loads((HERE / "before.json").read_text())
original = {
    str(Path(ref["path"]).relative_to(ROOT)): gzip.decompress(
        Path(ref["before_gzip"]).read_bytes()
    )
    for ref in before["before"]
}

with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as scratch:
    tree = Path(scratch)
    for name, data in original.items():
        path = tree / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    names = ["01-legal-reuse", "02-lag-references", "03-unstable-sort"]
    for inverse, steps in ((False, names), (True, reversed(names))):
        for name in steps:
            info = json.loads((HERE / (name + ".json")).read_text())
            field = "before_sha256" if inverse else "after_sha256"
            patch = HERE / (name + (".inverse.patch" if inverse else ".patch"))
            output = subprocess.check_output(
                [
                    "patch",
                    "--batch",
                    "--fuzz=0",
                    "--no-backup-if-mismatch",
                    "-p1",
                    "-d",
                    str(tree),
                    "-i",
                    str(patch),
                ],
                stderr=subprocess.STDOUT,
                text=True,
            )
            print(output, end="")
            assert "offset" not in output and "fuzz" not in output
            for ref in info["subjects"]:
                data = (tree / ref["path"]).read_bytes()
                assert hashlib.sha256(data).hexdigest() == ref[field]
        for name, data in original.items():
            assert (tree / name).read_bytes() == (
                data if inverse else (ROOT / name).read_bytes()
            )

for ref in before["377_frozen_before"]:
    assert hashlib.sha256(Path(ref["path"]).read_bytes()).hexdigest() == ref["sha256"]

name = "crates/quoridor-ai/src/move_ordering.rs"
assert (ROOT / name).read_bytes().replace(b"sort_unstable_by", b"sort_by") == original[
    name
]

name = "crates/quoridor-ai/src/continuation_history.rs"
old = original[name].decode()
new = (ROOT / name).read_text()
marker = "pub(super) struct ContinuationHistory"
assert old.split(marker)[0] == new.split(marker)[0]
assert (
    old[old.index("    pub fn new()") : old.index("    pub fn scores(")]
    == new[new.index("    pub fn new()") : new.index("    pub fn prepare_scores(")]
)
assert (
    old[old.index("    fn update(") :].strip()
    == new[new.index("    fn update(") : new.index("#[cfg(test)]")].strip()
)

name = "crates/quoridor-ai/src/alphabeta.rs"
old = original[name].decode()
new = (ROOT / name).read_text()
assert old[: old.index("    fn ordered(")] == new[: new.index("    fn ordered(")]
assert (
    old[old.index("    fn child(") : old.index("    fn negamax(")]
    == new[new.index("    fn child(") : new.index("    fn negamax(")]
)
marker = "pub struct SearchNamespace"
assert old[old.index(marker) :] == new[new.index(marker) :]
print(
    "Three exact forward/inverse patches, zero fuzz/offset, frozen377 and untouched comparator/update/aging/child/evaluator/factory owners PASS"
)
