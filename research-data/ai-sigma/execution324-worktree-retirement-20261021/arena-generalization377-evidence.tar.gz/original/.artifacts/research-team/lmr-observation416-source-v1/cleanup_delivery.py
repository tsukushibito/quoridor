"""Remove only the sender's unheld zero-byte uv TMP lock after directreap."""

from datetime import datetime, timezone
import fcntl
import importlib.util
import json
import os
import stat

import intake

HERE = intake.HERE
loader = importlib.util.spec_from_file_location(
    "cleanup416_lc", "/workspaces/quoridor/scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
records = []
for phase in ["admin-v1", "admin-v2", "delivery-v1"]:
    result = json.loads((HERE / phase / "result.json").read_text())
    for check in result["checks"]:
        returned = check["guardian_return"]
        disk = json.loads(
            __import__("pathlib")
            .Path(check["persisted_process_receipt"]["path"])
            .read_text()
        )
        facts = returned if returned is not None else disk
        assert (
            facts["direct_child_reaped"]
            and facts["cleanup_complete"]
            and facts["handle_closes_complete"]
            and not facts["remaining"]
        )
        child = facts["child"]
        fresh = lc.process.identity(lc.process.process_info(child["pid"]))
        assert fresh is None or fresh != child
        records.append(
            {
                "phase": phase,
                "name": check["name"],
                "child": child,
                "fresh": fresh,
                "returned_NULL": returned is None,
                "returned_mask": None
                if returned is None
                else returned.get("signal_mask_restoration"),
                "disk_mask": disk.get("signal_mask_restoration"),
                "receipt": check["persisted_process_receipt"],
                "directreap": facts["direct_child_reaped"],
                "handles": facts["handle_closes_complete"],
                "cleanup": facts["cleanup_complete"],
            }
        )
directory = HERE / "delivery-v1/TMP"
path = directory / "uv-cc8f3ad7aa19080a.lock"
assert list(directory.iterdir()) == [path]
fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
try:
    info = os.fstat(fd)
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_size == 0
    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    path.unlink()
finally:
    os.close(fd)
directory.rmdir()
stop = {
    "actual_admin_cleanup_UTC": datetime.now(timezone.utc).isoformat(),
    "original_delivery_result": intake.ref(HERE / "delivery-v1/result.json"),
    "original_TMP_remaining_preserved": True,
    "cleanup": "owned zero-byte uv lock unheld via flock; unlink+close+rmdir after all sender children directreaped",
    "removed_file": {
        "path": str(path),
        "dev": info.st_dev,
        "inode": info.st_ino,
        "bytes": info.st_size,
    },
    "records": records,
    "source_readers": [],
    "source_writers": [],
    "scientific_children": [],
    "TMP": [],
    "leases": [],
    "owned": [],
    "current_helper": "metadata-only guarded child; its own final directreap/handles are in cleanup-v1 result",
    "extra_delivery_or_science": 0,
}
(HERE / "final-admin-STOP.json").write_text(json.dumps(stop, indent=2) + "\n")
print(
    json.dumps(
        {
            "final_admin_STOP": intake.ref(HERE / "final-admin-STOP.json"),
            "delivery_TMP_exists": directory.exists(),
            "owned": [],
        }
    )
)
