# 416.2 source-only 凍結引渡し

現在324向け一回のsource handoffです。本人416.2はclaimantを保持し、format/static復元までの私有source準備範囲だけCLOSED・backup前後/showclosed済みです。Rootのnative型/software・限定独立確認・genuine image・入力admission・診断実行は未実施の別範囲で、parent416の完了を主張しません。source-STOP内のin_progress記載はsource凍結時点の状態で、後の本人admin closureへ書き換えていません。

OWN `/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/lmr-observation416-source-v1/`。

- `source-binding.json` SHA256 `2f8e450d85c7291faa9f2449265ad90b980d9875cf312645cebc0b4e0fed46e7` /6126B0644。
- `source-STOP.json` SHA256 `f79617fbb67138f4a6c129bf71eabd84149f92585b06a8184db638ce2e75ba93` /64127B0644。実source guard STOP12:36:45.066586Z、全original childのfresh identity absent/different/directwait/reap/handles/TMPgone/owned[]。そのcontrollerもadminでfresh absent確認済み。
- `lmr-observation416.patch` SHA256 `043df6864307673c24973b803d50c9fdd10d879c2f30064a5a8cf2411325a929` /61695B0644、inverse `8e515ed9497fdb159873da31e55cddfa2f01122f4883a200f5dc59a3d8ae6dce` /61695B0644。
- `report-ja.md` SHA256 `bb5adb764fb59736fde283e31dc552fdee20b76ec921fd40dfb635983abdcb49` /7672B0644。
- `verification-plan.json` SHA256 `d12e076e673b717403eb818603ba695627b68bb138cf4882ff95fd79f7b3741e` /3620B0644。newAI6 `lmr416_`/research-diagnostics、runner2 `measurement416_`/measurement、Python NN0定義1はUNBUILT/UNTYPED/UNRUN。旧suite再演0。
- `admin-v2/result.json` が最終admin guard STOP/directreap/TMP[]、`own-after-admin.json` が本人showclosed、backup-before/after.txtを保存。admin-v1はunused import lint失敗でBeads操作未入場、原FAILED/capture/NULL-vs-diskを保持。

immutable base `8c54ec630e253dc5b92604a52057b4978a8fea68`。変更はAlpha薄いhooks/共通invocation、new owning `lmr_observation416.rs`、measurementのRequest/metadata/input companion、Python `measurement_config`関数のみ。Python全publisherの恒常copyはありません。14 AI関数と既存assertions byte保護、関数外Python byte/AST、strict forward/inverse/ABSENT、Rustfmt/Ruff/Prettier PASS。Sourcepostはbindingの3FileRefsを厳密に使い、他subjectへ古いfullfileを上書きしないでください。

入口はRequest `observe_lmr` default false。AI APIはresearch-diagnostics限定 `search_with_lmr_observation(...,&mut LmrObservation)` と `cold_lmr_scout(root,&branch,normal,cancel)`。最大4枠、H0 before-return確保・H+完了shallow fail-lowのみ、hypothesis内完全親履歴+action重複除外、元postTT/current alpha・nonroot ply・parentSTMを記録。OFF/coldはconst OBSERVE=false、元Searchへの追加child/確認/TT/order書込みはありません。probeは元rootprefix+capturedpathで完全親counts照合し、別cold TT/history/scratchを作って共通childを一度だけ呼びます。root/反復深化への代用やparent自動確認はありません。

Root入力 `75e41757`/35281Bの12prefixは既存from_prefix/validate_normalで全再生し、opening4手のcountsとdivergence boardを別検査します。from_counts代用0。native admissionは未実行です。各operationのevaluatorに対応する6selectorsなどをRootの現common configへ正確に設定してください。observe_lmrはD5/1M、fresh unique root/session、TT1M、Control/PVS/depth_rank ON、approx/safe/otherobserver OFFに限定します。

元driver callsはroot数だけです。cold_invocations/child_called/complete/UNKNOWN/recorded work/unknown workを別censusへ出し、12+96<=108calls・12M+9.6M<=21.6MをRoot admission/collectorでも維持してください。cold probeのSearchResult PVはcaptured parent actionだけで、完全なchild PVは再構成していません。value/boundはparentSTM・実窓のnominal selective estimateで、TT内boundそのもの・WDL/fullwidth証明・元warm TTの再現・因果的bad moveの確定ではありません。未入場stage=null、中断stageはvalue/bound=null・completed=false、cap/不足からの補充0です。

OWN使用一回はlogical2,225,759B/allocated2,785,280B、171files/199dedupinodes、FS available505,247,330,304B。その時点以後のsource-STOP/軽いadminは明示除外、globalactual UNKNOWN、decimal50GB・oldfees/RAW/FAILED/pauses/models/defaultsは不変。source worker3/guardian7/family512MiB/G0/hostreserve4GiB・NNP/fullcapture/directwait/reapを現portで保存、現在source/readers/writers/jobs/TMP/leases/owned[]。Main/Git/Cargo/native/Search/model/test/science/reviewer dispatch0。

Root必要softwareと一回の限定reviewへ渡してください。新しい科学件数・候補・入力選択・追加Root/Policy ACK gateは発行していません。
