#[cfg(test)]
mod tests {
    use super::*;

    fn parent() -> (SigmaContext, SigmaContext, Vec<PlayedMove>) {
        let root = SigmaContext::from_prefix(&[]).unwrap();
        let parent = root.play(3).unwrap();
        (
            root,
            parent,
            vec![PlayedMove {
                colour: 0,
                action: 3,
            }],
        )
    }
    fn facts(c: &SigmaContext, depth: u16, quantum: u16) -> LmrBranchFacts {
        LmrBranchFacts {
            hypothesis: "",
            iteration_depth: 0,
            visit: 0,
            parent_depth: depth,
            parent_ply: 1,
            parent_stm: c.position().turn,
            distinct_rank: match quantum {
                0 => 4,
                1 => 16,
                _ => 60,
            },
            action: c.legal_ids()[0],
            quantum,
            alpha_beta_bits: [0.0f32.to_bits(), 1.0f32.to_bits()],
            tt: None,
        }
    }
    fn session(eval: Arc<dyn StaticEvaluator>) -> SearchSession {
        let mut s = SearchSession::new_with_ordering(
            eval,
            SearchNamespace {
                evaluator: "416-toy".into(),
                rules: "research-standard-2p-threefold-goal-first-v1".into(),
                selectivity: "416-toy".into(),
            },
            1_048_576,
            ScoreDomain::LEGACY,
            OrderingProfile::CheapStaticControl,
            false,
            true,
        )
        .unwrap();
        s.set_lmr_method(LmrMethod::DepthRank);
        s
    }
    struct Constant;
    impl StaticEvaluator for Constant {
        fn evaluate(&self, _: &SigmaContext, _: Option<&EvalAccumulator>) -> Result<f32> {
            Ok(0.25)
        }
    }
    fn limits() -> SearchLimits {
        SearchLimits {
            max_depth: 2,
            max_nodes: 1000,
            time_limit: None,
            tt_entries: 1_048_576,
            use_tt: true,
            use_pvs: true,
        }
    }
    #[test]
    fn lmr416_h0_reserves_before_return_and_never_refills_interruption() {
        let (_, c, path) = parent();
        let mut o = LmrObservation::default();
        o.iteration = 4;
        let f = facts(&c, 3, 0);
        o.begin(&c, &path, f);
        assert_eq!(o.branches().count(), 1);
        assert!(
            o.branches()
                .next()
                .unwrap()
                .stages
                .iter()
                .all(Option::is_none)
        );
        o.child_start(1, f.action, 2, [0.0, next_up(0.0)]);
        o.child_return(
            &c,
            &path,
            1,
            f.action,
            &Err(Interrupted::Stop(StopReason::NodeLimit)),
        );
        let mut later = f;
        later.action = c.legal_ids()[1];
        o.begin(&c, &path, later);
        let b = o.branches().next().unwrap();
        assert_eq!(b.facts.action, f.action);
        assert_eq!(b.facts.iteration_depth, 4);
        assert!(!b.stages[0].unwrap().completed);
        assert_eq!(b.stages[0].unwrap().value_bits, None);
    }
    #[test]
    fn lmr416_hplus_completed_fail_low_buckets_and_fullhistory_action_dedup() {
        let (_, c, path) = parent();
        let mut o = LmrObservation::default();
        let f = facts(&c, 3, 1);
        o.begin(&c, &path, f);
        o.child_start(1, f.action, 1, [0.0, next_up(0.0)]);
        assert_eq!(o.branches().count(), 0);
        o.child_return(&c, &path, 1, f.action, &Ok(-0.25));
        assert_eq!(o.branches().count(), 1);
        let mut other = facts(&c, 4, 2);
        other.distinct_rank = 60;
        o.begin(&c, &path, other);
        o.child_start(1, other.action, 1, [0.0, next_up(0.0)]);
        o.child_return(&c, &path, 1, other.action, &Ok(0.0));
        assert_eq!(o.branches().count(), 1); // Same H+ full parent/action, different bucket.
        other.action = c.legal_ids()[1];
        o.begin(&c, &path, other);
        o.child_start(1, other.action, 1, [0.0, next_up(0.0)]);
        o.child_return(&c, &path, 1, other.action, &Ok(0.0));
        assert_eq!(o.branches().count(), 2);
        assert_eq!(o.coverage[1][3][2].first_fail_low, 2);
        assert!(
            o.branches()
                .all(|b| b.stages[1].is_none() && b.stages[2].is_none())
        );
    }
    #[test]
    fn lmr416_stage_post_tt_windows_parent_view_and_confirmation_coverage() {
        let (_, c, path) = parent();
        let mut o = LmrObservation::default();
        let f = facts(&c, 4, 0);
        o.begin(&c, &path, f);
        o.child_start(1, f.action, 3, [0.0, next_up(0.0)]);
        o.child_return(&c, &path, 1, f.action, &Ok(0.5));
        o.child_start(1, f.action, 3, [0.0, 1.0]);
        o.child_return(&c, &path, 1, f.action, &Ok(0.25));
        let b = o.branches().next().unwrap();
        assert_eq!(b.stages[0].unwrap().bound, Some("Lower"));
        assert_eq!(b.stages[1].unwrap().bound, Some("Exact"));
        assert_eq!(b.stages[1].unwrap().value_bits, Some(0.25f32.to_bits()));
        assert_eq!(b.facts.parent_stm, c.position().turn);
        let f = facts(&c, 4, 1);
        o.begin(&c, &path, f);
        o.child_start(1, f.action, 2, [0.0, next_up(0.0)]);
        o.child_return(&c, &path, 1, f.action, &Ok(0.5));
        o.child_start(1, f.action, 3, [0.0, next_up(0.0)]);
        o.child_return(&c, &path, 1, f.action, &Ok(0.5));
        o.child_start(1, f.action, 3, [0.0, 1.0]);
        assert_eq!(o.coverage[1][2][1].normal_confirmations, 1);
        assert_eq!(o.coverage[1][2][1].full_windows, 1);
    }
    #[test]
    fn lmr416_cold_single_child_nonroot_path_independence_cancel_error_and_parent() {
        struct Fails;
        impl StaticEvaluator for Fails {
            fn evaluate(&self, _: &SigmaContext, _: Option<&EvalAccumulator>) -> Result<f32> {
                Err(SearchError::Evaluation("416 injected error".into()))
            }
        }
        let (root, c, path) = parent();
        let mut o = LmrObservation::default();
        o.begin(&c, &path, facts(&c, 3, 0));
        let b = o.branches().next().unwrap();
        let s = session(Arc::new(Constant));
        for normal in [false, true] {
            let p = s
                .cold_lmr_scout(&root, b, normal, &AtomicBool::new(false))
                .unwrap();
            assert!(p.child_called);
            let r = p.result.unwrap();
            assert_eq!(r.completed_depth, if normal { 2 } else { 1 });
            assert_eq!(r.action, Some(b.facts.action));
            assert_eq!(r.stats.tt_generation, 0); // No root iterative-deepening generation.
            assert_eq!(s.table.generation, 0);
            assert!(same_history(&c, b.parent()));
        }
        let cancelled = s
            .cold_lmr_scout(&root, b, false, &AtomicBool::new(true))
            .unwrap();
        assert!(!cancelled.child_called);
        let r = cancelled.result.unwrap();
        assert_eq!(r.stop, StopReason::Cancelled);
        assert_eq!(r.value, None);
        assert_eq!(r.completed_depth, 0);
        assert!(
            session(Arc::new(Fails))
                .cold_lmr_scout(&root, b, false, &AtomicBool::new(false))
                .unwrap()
                .result
                .is_err()
        );
        assert!(same_history(&c, b.parent()));
        assert!(same_history(
            &root,
            &SigmaContext::from_prefix(&[]).unwrap()
        ));
        // Exercise the same direct-child invocation with an intentionally tiny
        // toy cap. A partial scout must not borrow an earlier root iteration.
        let mut table = Table::persistent(1_048_576).unwrap();
        let mut history = ContinuationHistory::new().unwrap();
        let called = std::cell::Cell::new(false);
        let limits = SearchLimits {
            max_nodes: 1,
            max_depth: 5,
            ..limits()
        };
        let mut callback = |_: &SearchResult| {};
        let capped = search_in_table::<false>(
            &c,
            &Constant,
            &limits,
            &AtomicBool::new(false),
            None,
            SearchInvocation {
                on_completed: &mut callback,
                observation: None,
                cold: Some(ColdScout {
                    action: b.facts.action,
                    depth: 2,
                    alpha: 0.0,
                    parent_ply: 1,
                    path: &path,
                    child_called: &called,
                }),
            },
            (
                &mut table,
                ScoreDomain::LEGACY,
                Some(&mut history),
                false,
                StaticMode::CheapControl,
                (true, LmrMethod::DepthRank),
                (false, ZeroStockApproxMethod::Race, false),
            ),
        )
        .unwrap();
        assert!(called.get());
        assert_eq!(capped.stop, StopReason::NodeLimit);
        assert_eq!(capped.stats.nodes, 1);
        assert_eq!(capped.completed_depth, 0);
        assert_eq!(capped.value, None);
    }
    #[test]
    fn lmr416_observation_on_off_toy_root_and_original_work_correspond() {
        let root = SigmaContext::from_prefix(&[]).unwrap();
        let mut plain = session(Arc::new(Constant));
        let mut completed_callbacks = 0;
        let a = plain
            .search_with_updates(&root, &limits(), &AtomicBool::new(false), &mut |_| {
                completed_callbacks += 1;
            })
            .unwrap();
        assert_eq!(completed_callbacks, a.completed_depth);
        drop(plain);
        let mut diagnostic = session(Arc::new(Constant));
        let mut o = LmrObservation::default();
        let b = diagnostic
            .search_with_lmr_observation(&root, &limits(), &AtomicBool::new(false), &mut o)
            .unwrap();
        assert_eq!(a.value.map(f32::to_bits), b.value.map(f32::to_bits));
        assert_eq!(a.action, b.action);
        assert_eq!(a.pv, b.pv);
        assert_eq!(a.completed_depth, b.completed_depth);
        assert_eq!(a.stats.nodes, b.stats.nodes);
        assert_eq!(a.stats.evaluations, b.stats.evaluations);
        assert_eq!(a.stats.lmr_attempts, b.stats.lmr_attempts);
        assert!(o.finished);
        assert_eq!(o.branches().count(), 0); // Root D2 has no nonroot d3/d4.
    }
    #[test]
    fn lmr416_opt_in_refuses_warm_wrong_mode_and_parent_path_drift() {
        let (root, c, path) = parent();
        let mut s = session(Arc::new(Constant));
        let mut o = LmrObservation::default();
        s.set_lmr_method(LmrMethod::FixedOne);
        assert!(
            s.search_with_lmr_observation(&root, &limits(), &AtomicBool::new(false), &mut o)
                .is_err()
        );
        s.set_lmr_method(LmrMethod::DepthRank);
        s.search(&root, &limits(), &AtomicBool::new(false)).unwrap();
        assert!(
            s.search_with_lmr_observation(&root, &limits(), &AtomicBool::new(false), &mut o)
                .is_err()
        );
        let mut observed = LmrObservation::default();
        observed.begin(&c, &path, facts(&c, 3, 0));
        observed.branches[0].as_mut().unwrap().path[0].0 = 1;
        let b = observed.branches().next().unwrap();
        assert!(
            s.cold_lmr_scout(&root, b, false, &AtomicBool::new(false))
                .is_err()
        );
    }
}
