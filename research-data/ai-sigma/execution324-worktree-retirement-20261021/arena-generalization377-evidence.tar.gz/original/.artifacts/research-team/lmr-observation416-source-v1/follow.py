"""One bounded immutable consumer intake and exact selected input structure."""

import ast
import json
from pathlib import Path
import intake

HERE = intake.HERE
path = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-limited-observation416-v1/inputs-v1/twelve-prefixes.json"
)
before = intake.ref(path)
assert (
    before["sha256"]
    == "75e417572078a3d20c5d3c0b8e46afad46790dd18ac2e5c925098cd8c5a75c1a"
    and before["bytes"] == 35281
    and before["mode"] == "0644"
)
value = json.loads(path.read_text())
print("INPUT_TOP_KEYS", list(value))
print("ROOT0", json.dumps(value["roots"][0], indent=2))
assert [len(r["prefix"]) for r in value["roots"]] == [
    4,
    6,
    5,
    9,
    4,
    6,
    4,
    6,
    4,
    9,
    8,
    4,
]
assert intake.ref(path) == before
(HERE / "selected-input-ref.json").write_text(json.dumps(before, indent=2) + "\n")
relative = "scripts/dev/research-lifecycle.py"
text = intake.git("show", intake.BASE + ":" + relative).decode()
node = next(
    n
    for n in ast.parse(text).body
    if isinstance(n, ast.FunctionDef) and n.name == "measurement_config"
)
lines = text.splitlines(keepends=True)
body = "".join(lines[node.lineno - 1 : node.end_lineno])
(HERE / "before-measurement_config.py").write_text(body)
(HERE / "measurement-config-binding.json").write_text(
    json.dumps(
        {
            "base": intake.BASE,
            "relative": relative,
            "whole_sha256": __import__("hashlib").sha256(text.encode()).hexdigest(),
            "lines": [node.lineno, node.end_lineno],
            "function": intake.ref(HERE / "before-measurement_config.py"),
        },
        indent=2,
    )
    + "\n"
)
print("PYTHON_MEASUREMENT_CONFIG", body)
