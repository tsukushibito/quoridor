// Bounded output for the one opt-in diagnostic. Root call accounting remains
// the driver's existing count; cold invocation/child/node counts are separate.
fn lmr_observation_output(
    session: &SearchSession,
    root: &SigmaContext,
    observation: &alphabeta::LmrObservation,
    cancel: &AtomicBool,
    root_ok: bool,
) -> Value {
    let mut branches = Vec::new();
    let mut invocations = 0u64;
    let mut child_calls = 0u64;
    let mut recorded_nodes = 0u64;
    let mut recorded_evaluations = 0u64;
    let mut unknown_work_invocations = 0u64;
    let mut completed_probes = 0u64;
    let mut halted = !root_ok;
    for branch in observation.branches() {
        let f = &branch.facts;
        let stages: Vec<_> = branch
            .stages
            .iter()
            .map(|s| {
                s.map(|s| json!({
            "child_depth":s.child_depth,"window_bits":s.window_bits,"value_bits":s.value_bits,
            "bound":s.bound,"completed":s.completed,
            "status":if s.completed {"COMPLETE"} else {"UNKNOWN"},
            "interrupted":!s.completed,
        }))
            })
            .collect();
        let mut probes = Vec::new();
        for normal in [false, true] {
            let start = Instant::now();
            let mut row = if halted || cancel.load(Ordering::Relaxed) {
                json!({"status":"UNKNOWN","common_invocation_started":false,"child_called":false,
                    "reason":"root error, earlier probe error or cancellation; no replacement"})
            } else {
                match session.cold_lmr_scout(root, branch, normal, cancel) {
                    Err(error) => {
                        halted = true;
                        json!({"status":"UNKNOWN","common_invocation_started":false,
                            "child_called":false,"error":fact(&error)})
                    }
                    Ok(probe) => {
                        invocations += 1;
                        child_calls += u64::from(probe.child_called);
                        let mut row = match probe.result {
                            Err(error) => {
                                halted = true;
                                unknown_work_invocations += 1;
                                json!({"status":"UNKNOWN","returned":"Err","error":fact(&error),
                                    "nodes":Value::Null,"evaluations":Value::Null})
                            }
                            Ok(result) => {
                                recorded_nodes += result.stats.nodes;
                                recorded_evaluations += result.stats.evaluations;
                                let complete = result.stop == StopReason::DepthComplete
                                    && result.completed_depth == probe.child_depth
                                    && result.value.is_some();
                                let mut row = observed(&result);
                                row.as_object_mut().unwrap().remove("ordering");
                                row["status"] =
                                    json!(if complete { "COMPLETE" } else { "UNKNOWN" });
                                row["bound"] = if complete {
                                    json!(if result.value.unwrap()
                                        <= f32::from_bits(probe.window_bits[0])
                                    {
                                        "Upper"
                                    } else if result.value.unwrap()
                                        >= f32::from_bits(probe.window_bits[1])
                                    {
                                        "Lower"
                                    } else {
                                        "Exact"
                                    })
                                } else {
                                    Value::Null
                                };
                                if result.stop == StopReason::Cancelled {
                                    halted = true;
                                }
                                row
                            }
                        };
                        row["common_invocation_started"] = json!(true);
                        row["child_called"] = json!(probe.child_called);
                        row["window_bits"] = json!(probe.window_bits);
                        row
                    }
                }
            };
            row["kind"] = json!(if normal { "normal" } else { "reduced" });
            row["requested_child_depth"] = json!(if normal {
                branch.normal_child_depth()
            } else {
                branch.reduced_child_depth()
            });
            row["parent_ply"] = json!(f.parent_ply);
            row["parent_stm"] = json!(f.parent_stm);
            row["TT_initial_entries"] = json!(0);
            row["ordering_initial"] =
                json!("zero continuation and killers; captured actor/path only");
            row["node_cap"] = json!(100_000);
            row["time_limit_ms"] = Value::Null;
            row["whole_including_local_setup_drop_seconds"] = json!(start.elapsed().as_secs_f64());
            completed_probes += u64::from(row["status"] == "COMPLETE");
            probes.push(row);
        }
        let both = probes.iter().all(|p| p["status"] == "COMPLETE");
        let match_status = if both {
            if probes[0]["value_bits"] == probes[1]["value_bits"] {
                "MATCH"
            } else {
                "DIFFERENT"
            }
        } else {
            "UNKNOWN"
        };
        branches.push(json!({"hypothesis":f.hypothesis,"iteration_depth":f.iteration_depth,
            "eligible_visit_serial":f.visit,"parent_depth":f.parent_depth,"parent_ply":f.parent_ply,
            "path_action_colour":branch.path(),"parent":identity(branch.parent()),
            "parent_stm":f.parent_stm,"distinct_rank":f.distinct_rank,"action":f.action,
            "eligible":true,"protected_by_saved_ranking":false,"quantum":f.quantum,
            "post_TT_pre_child_alpha_beta_bits":f.alpha_beta_bits,
            "TT":f.tt.map(|tt|json!({"stored_depth":tt.stored_depth,"bound":tt.bound,
                "context_matches":tt.context_matches,"usable_depth":tt.usable_depth,"legal_move":tt.legal_move})),
            "stages":stages,"stage_order":if f.quantum==0 {json!(["normal_scout","full_window",null])}
                else {json!(["shallow","normal_depth_confirmation","full_window"])},
            "cold_probes":probes,"cold_value_bits_correspondence":match_status,
            "normal_probe_semantics":"selective estimate; not historical warm TT or WDL/full-width truth"}));
    }
    let coverage: Vec<_> = observation
        .coverage
        .iter()
        .map(|depth| {
            depth
                .iter()
                .map(|rank| {
                    rank.iter().map(|c|
        json!({"opportunities":c.opportunities,"first_completed":c.first_completed,
            "first_fail_low":c.first_fail_low,"normal_confirmations_started":c.normal_confirmations,
            "full_windows_started":c.full_windows})).collect::<Vec<_>>()
                })
                .collect::<Vec<_>>()
        })
        .collect();
    let planned_probes = branches.len() as u64 * 2;
    json!({"version":"limited-lmr-observation416-v1","finished":observation.finished,
        "status":if root_ok && completed_probes==planned_probes {"COMPLETE"} else {"PARTIAL"},
        "selected_branches":branches.len(),"maximum_branches":4,
        "planned_cold_scouts":planned_probes,"complete_cold_scouts":completed_probes,
        "unknown_or_unperformed_cold_scouts":planned_probes-completed_probes,
        "missing_buckets_are_not_refilled":true,
        "root_stop":observation.root_stop,"branches":branches,"coverage":coverage,
        "coverage_axes":{"depth":[3,4],"distinct_rank":["4..8","9..15","16..31","32+"],"quantum":["0","1","2+"]},
        "cold_common_invocations":invocations,"cold_child_calls":child_calls,
        "cold_recorded_nodes":recorded_nodes,"cold_recorded_evaluations":recorded_evaluations,
        "cold_unknown_work_invocations":unknown_work_invocations,
        "root_calls_exclude_cold_scouts":true,"refill":false})
}

fn observation_input_check(prefix: &[u16], expected: &Value, root: &SigmaContext) -> Result<()> {
    let opening = expected
        .get("opening_bound")
        .ok_or("observation requires bound opening and divergence board")?;
    let length: usize = serde_json::from_value(opening["prefix_len"].clone())?;
    if length > prefix.len() {
        return Err("opening prefix longer than divergence prefix".into());
    }
    let before = SigmaContext::from_prefix(&prefix[..length])?;
    before.validate_normal()?;
    let actual = identity(&before);
    if actual["root_key"] != opening["root_key"]
        || actual["history_counts"] != opening["history_counts"]
    {
        return Err("observation original opening fullhistory mismatch".into());
    }
    let board = &expected["expected_divergence_board"];
    let p = root.position();
    let wall_ids: Vec<u16> = (0..64)
        .filter(|bit| p.horizontal & (1u64 << bit) != 0)
        .map(|b| 81 + b)
        .chain(
            (0..64)
                .filter(|bit| p.vertical & (1u64 << bit) != 0)
                .map(|b| 145 + b),
        )
        .collect();
    if json!(p.pawns) != board["pawns_cell_ids"]
        || json!(p.walls_remaining) != board["stocks"]
        || json!(p.turn) != board["side_to_move"]
        || json!(root.total_ply()) != board["total_ply"]
        || json!(wall_ids) != board["wall_action_ids"]
    {
        return Err("observation divergence board/turn/ply mismatch".into());
    }
    // Counts above qualify only the opening. Root's full counts come solely
    // from replaying the entire SHA-bound chronological prefix in replay().
    Ok(())
}
