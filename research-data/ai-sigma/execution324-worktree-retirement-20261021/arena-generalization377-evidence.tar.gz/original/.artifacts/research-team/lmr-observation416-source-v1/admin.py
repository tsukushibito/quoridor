"""Own source-only closure and existing recipient, no production/science work."""

from datetime import datetime, timezone
import json
import os
import subprocess

import intake

HERE = intake.HERE


def beads(*args):
    result = subprocess.run(
        ["bash", "/workspaces/quoridor/scripts/dev/beads.sh", *args],
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout


def main():
    # The existing guarded child owns this small metadata helper. No source
    # changes or new native/runtime admissions occur here.
    import importlib.util

    loader = importlib.util.spec_from_file_location(
        "admin416_lc", "/workspaces/quoridor/scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    stop_path = HERE / "source-STOP.json"
    stop_ref = intake.ref(stop_path)
    stop = json.loads(stop_path.read_text())
    assert intake.ref(stop_path) == stop_ref
    old = stop["controller"]
    fresh = lc.process.identity(lc.process.process_info(old["pid"]))
    assert fresh is None or fresh != old
    assert not stop["owned"] and not stop["TMP"]
    before_text = beads("show", "quoridor-4lc.416.2", "--json")
    (HERE / "own-before-admin.json").write_text(before_text)
    (before,) = json.loads(before_text)
    assert before["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
    assert before["status"] == "in_progress"
    (HERE / "backup-before.txt").write_text(beads("backup", "sync"))
    binding = intake.ref(HERE / "source-binding.json")
    note = (
        f"416.2 source-only frozen at {stop['actual_source_reader_writer_STOP']}. "
        f"Binding {binding['path']} SHA256 {binding['sha256']}/{binding['bytes']}B; "
        f"source STOP {stop_ref['sha256']}/{stop_ref['bytes']}B. "
        "Scoped Rustfmt/Ruff/Prettier + strict forward/inverse/ABSENT/protected byte+AST proof PASS. "
        "AI6+runner2+Python1 new definitions UNBUILT/UNTYPED/UNRUN. "
        "No Main/Git/Cargo/native/Search/model/science executions or independent review dispatch. "
        "Closing only author private source preparation; integration, native qualification, limited distinct review and approved diagnostic entry remain parent416/current324 owned, not claimed complete. "
        "Original draft/proof failures, NULL-vs-disk receipts/costs retained; all pauses/defaults/model/RAW held."
    )
    (HERE / "own-note-update.json").write_text(
        beads("update", before["id"], "--append-notes", note, "--json")
    )
    (HERE / "own-close.json").write_text(
        beads(
            "close",
            before["id"],
            "--reason",
            "Verified private source-only preparation: formatted/static exact reconstruction and stopped packet; native/type/tests/review/science remain explicitly NOT_RUN and parent416/324 owned. Evidence source-binding.json 2f8e450d85c7291faa9f2449265ad90b980d9875cf312645cebc0b4e0fed46e7.",
            "--json",
        )
    )
    after_text = beads("show", before["id"], "--json")
    (HERE / "own-after-admin.json").write_text(after_text)
    (after,) = json.loads(after_text)
    assert after["status"] == "closed" and after["assignee"] == before["assignee"]
    (HERE / "backup-after.txt").write_text(beads("backup", "sync"))
    (parent,) = json.loads(beads("show", "quoridor-4lc.324", "--json"))
    assignee = parent["assignee"]
    assert assignee.startswith("codex:") and parent["status"] != "closed"
    recipient = {
        "issue": parent["id"],
        "assignee": assignee,
        "thread": assignee.removeprefix("codex:"),
        "read_scope": "current Beads assignee only; no parent mutation",
    }
    (HERE / "recipient.json").write_text(json.dumps(recipient, indent=2) + "\n")
    boundary = {
        "actual_admin_source_checkpoint": datetime.now(timezone.utc).isoformat(),
        "source_STOP": stop_ref,
        "source_controller": old,
        "fresh_source_controller": fresh,
        "own_issue": before["id"],
        "status": after["status"],
        "claimant_preserved": True,
        "recipient": recipient,
        "current_helper_identity": lc.process.identity(
            lc.process.process_info(os.getpid())
        ),
        "current_helper_scope": "this guarded metadata child only; final admin guard result records its directreap/cleanup",
        "source_readers": [],
        "source_writers": [],
        "scientific_children": [],
        "jobs": [],
        "leases": [],
        "owned": [],
        "native_tests_science": "NOT_RUN",
    }
    (HERE / "admin-checkpoint.json").write_text(json.dumps(boundary, indent=2) + "\n")
    print(
        json.dumps(
            {
                "own_status": after["status"],
                "recipient": recipient,
                "source_controller_fresh": fresh,
                "owned": [],
            }
        )
    )


if __name__ == "__main__":
    main()
