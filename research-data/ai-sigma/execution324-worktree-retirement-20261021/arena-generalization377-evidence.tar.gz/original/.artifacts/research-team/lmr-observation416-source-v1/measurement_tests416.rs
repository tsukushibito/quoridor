#[cfg(test)]
mod lmr416_tests {
    use super::*;
    #[test]
    fn measurement416_opt_in_strict_cold_limits_serde_and_no_other_observers() {
        let base = json!({"roots":[{"input":0,"pointer":"/roots/0","field":"prefix","label":"toy"}],
            "profile":"control","tt_entries":1048576,"use_tt":true,"use_pvs":true,"lmr":true,"lmr_method":"depth_rank",
            "namespace":{"evaluator":crate::teacher_pilot_execution::EVALUATOR_ID,"rules":"standard","selectivity":"toy"},
            "output_bytes":1000000,"record_bytes":100000});
        let settings: Settings = serde_json::from_value(base).unwrap();
        let request = json!({"id":"one","session":"one","root":0,"depth":5,"node_cap":1000000,"observe_lmr":true});
        let r: Request = serde_json::from_value(request.clone()).unwrap();
        validate(&settings, &[r]).unwrap();
        for (key, value) in [
            ("diagnostic", json!(true)),
            ("observe_completed_depths", json!(true)),
            ("warmup", json!(true)),
            ("depth", json!(6)),
            ("node_cap", json!(100001)),
            ("time_limit_ms", json!(1)),
        ] {
            let mut bad = request.clone();
            bad[key] = value;
            let r: Request = serde_json::from_value(bad).unwrap();
            assert!(validate(&settings, &[r]).is_err());
        }
        for value in [json!(null), json!(1), json!("true")] {
            let mut bad = request.clone();
            bad["observe_lmr"] = value;
            assert!(serde_json::from_value::<Request>(bad).is_err());
        }
        let r: Request = serde_json::from_value(request.clone()).unwrap();
        assert!(validate(&settings, &[r.clone(), r]).is_err());
        let r: Request = serde_json::from_value(
            json!({"id":"off","session":"off","root":0,"depth":1,"node_cap":1}),
        )
        .unwrap();
        assert!(!r.observe_lmr);
        validate(&settings, &[r]).unwrap();
    }
    #[test]
    fn measurement416_chronological_divergence_replay_keeps_opening_counts_separate() {
        let opening = SigmaContext::from_prefix(&[3, 75, 4, 76]).unwrap();
        let mut bound = identity(&opening);
        bound["prefix_len"] = json!(4);
        let expected = json!({"opening_bound":bound,"expected_divergence_board":{
            "pawns_cell_ids":[13,76],"stocks":[10,10],"wall_action_ids":[],"side_to_move":1,"total_ply":5}});
        let spec = RootSpec {
            prefix: vec![3, 75, 4, 76, 13],
            expected: Some(expected.clone()),
        };
        let root = replay(&spec, opening.ruleset().id()).unwrap();
        assert_ne!(identity(&root)["history_counts"], bound["history_counts"]);
        assert_eq!(root.total_ply(), 5);
        let mut bad = expected.clone();
        bad["expected_divergence_board"]["side_to_move"] = json!(0);
        assert!(
            replay(
                &RootSpec {
                    prefix: spec.prefix.clone(),
                    expected: Some(bad)
                },
                opening.ruleset().id()
            )
            .is_err()
        );
        let mut bad = expected;
        bad["opening_bound"]["history_counts"] = json!([]);
        assert!(
            replay(
                &RootSpec {
                    prefix: spec.prefix,
                    expected: Some(bad)
                },
                opening.ruleset().id()
            )
            .is_err()
        );
    }
}
