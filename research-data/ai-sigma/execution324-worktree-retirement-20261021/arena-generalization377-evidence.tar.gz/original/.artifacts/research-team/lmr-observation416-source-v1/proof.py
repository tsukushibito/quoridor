"""Static reconstruction/byte proof only. Never compiles or executes Rust/tests."""

import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

import intake

HERE = intake.HERE
AI = Path("crates/quoridor-ai/src/alphabeta.rs")
MEASURE = Path("crates/quoridor-runner/src/measurement.rs")
NEW = AI.with_name("lmr_observation416.rs")
PYTHON = Path("scripts/dev/research-lifecycle.py")


def function(text, name):
    start = re.search(
        r"(?m)^\s*(?:pub(?:\([^)]*\))? )?fn " + name + r"\b", text
    ).start()
    brace = text.index("{", start)
    tokens = re.finditer(
        r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\\n])\'|[{}]',
        text[brace:],
    )
    depth = 0
    for token in tokens:
        if token.group() == "{":
            depth += 1
        elif token.group() == "}":
            depth -= 1
            if depth == 0:
                return text[start : brace + token.end()]
    raise AssertionError(name)


def diff(before, after, relative, offset=0):
    patch = "".join(
        difflib.unified_diff(
            before.splitlines(keepends=True),
            after.splitlines(keepends=True),
            fromfile="a/" + str(relative) if before else "/dev/null",
            tofile="b/" + str(relative) if after else "/dev/null",
            n=3,
        )
    )
    if offset:
        patch = re.sub(
            r"(?m)^@@ -(\d+)(,\d+)? \+(\d+)(,\d+)? @@",
            lambda m: f"@@ -{int(m[1]) + offset}{m[2] or ''} +{int(m[3]) + offset}{m[4] or ''} @@",
            patch,
        )
    return patch


def main():
    before = {p: (HERE / "before" / p).read_text() for p in [AI, MEASURE]}
    after = {p: (HERE / "post" / p).read_text() for p in [AI, MEASURE, NEW]}
    assert not intake.git("ls-tree", "-z", intake.BASE, "--", str(NEW)), (
        "new module existed in fixed base"
    )
    before[NEW] = ""
    whole = intake.git("show", intake.BASE + ":" + str(PYTHON)).decode()
    binding = json.loads((HERE / "measurement-config-binding.json").read_text())
    assert hashlib.sha256(whole.encode()).hexdigest() == binding["whole_sha256"]
    old_body = (HERE / "before-measurement_config.py").read_text()
    new_body = (HERE / "post-measurement_config.py").read_text()
    tree = ast.parse(whole)
    selected = next(
        n
        for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name == "measurement_config"
    )
    lines = whole.splitlines(keepends=True)
    assert "".join(lines[selected.lineno - 1 : selected.end_lineno]) == old_body
    prefix, suffix = (
        "".join(lines[: selected.lineno - 1]),
        "".join(lines[selected.end_lineno :]),
    )
    changed = prefix + new_body + suffix
    ast.parse(changed)
    assert changed[: len(prefix)] == prefix and changed[-len(suffix) :] == suffix
    original_nodes = [
        ast.dump(n, include_attributes=False) for n in tree.body if n is not selected
    ]
    changed_nodes = [
        ast.dump(n, include_attributes=False)
        for n in ast.parse(changed).body
        if not (isinstance(n, ast.FunctionDef) and n.name == "measurement_config")
    ]
    assert original_nodes == changed_nodes
    forward = "".join(diff(before[p], after[p], p) for p in [AI, MEASURE, NEW])
    inverse = "".join(diff(after[p], before[p], p) for p in [AI, MEASURE, NEW])
    # Normal surrounding context avoids an artificial EOF anchor at the end
    # of the extracted function. Only this function's bytes differ.
    forward += diff(whole, changed, PYTHON)
    inverse += diff(changed, whole, PYTHON)
    (HERE / "lmr-observation416.patch").write_text(forward)
    (HERE / "lmr-observation416.inverse.patch").write_text(inverse)
    protected = []
    for name in [
        "root_depth",
        "reduced_child",
        "lmr_allowed",
        "prepared_moves",
        "eager_ordered",
        "ordered",
        "control",
        "enter",
        "key",
        "zero_stock_approx_leaf",
        "zero_stock_approx_value",
        "safe_race_value",
        "publish_distance_counts",
        "pv",
    ]:
        old = function(before[AI], name)
        new = function(after[AI], name)
        assert old == new, name
        protected.append(
            {
                "function": name,
                "bytes": len(old.encode()),
                "sha256": hashlib.sha256(old.encode()).hexdigest(),
            }
        )
    # Existing tests change constructor/signature plumbing only, never assertions.
    before_tests = before[AI].split("#[cfg(test)]", 1)[1]
    after_tests = after[AI].split("#[cfg(test)]", 1)[1]

    def assertions(text):
        return re.findall(r"\b(?:assert|assert_eq|assert_ne)!\([\s\S]*?\);", text)

    assert assertions(before_tests) == assertions(after_tests)
    assert after[NEW].count("#[test]") == 6
    runner_names = re.findall(r"fn (measurement416_\w+)\(", after[MEASURE])
    assert len(runner_names) == 2
    ai_names = re.findall(r"fn (lmr416_\w+)\(", after[NEW])
    assert len(ai_names) == 6
    frame = HERE / "proof-frame"
    frame.mkdir()
    try:
        for p in [AI, MEASURE, PYTHON]:
            target = frame / p
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(whole if p == PYTHON else before[p])
        for direction in [
            "lmr-observation416.patch",
            "lmr-observation416.inverse.patch",
        ]:
            result = subprocess.run(
                [
                    "patch",
                    "--batch",
                    "--fuzz=0",
                    "--no-backup-if-mismatch",
                    "-p1",
                    "-i",
                    str(HERE / direction),
                ],
                cwd=frame,
                check=False,
                capture_output=True,
                text=True,
            )
            print(direction, result.stdout.strip(), result.stderr.strip())
            (HERE / (direction + ".proof.log")).write_text(
                result.stdout + result.stderr
            )
            assert result.returncode == 0, (direction, result.returncode)
            if direction.endswith("inverse.patch"):
                assert not (frame / NEW).exists()
                assert all((frame / p).read_text() == before[p] for p in [AI, MEASURE])
                assert (frame / PYTHON).read_text() == whole
            else:
                assert all(
                    (frame / p).read_text() == after[p] for p in [AI, MEASURE, NEW]
                )
                assert (frame / PYTHON).read_text() == changed
    finally:
        shutil.rmtree(frame)
    for p in [AI, MEASURE]:
        target = HERE / "before-gzip" / p.with_suffix(p.suffix + ".gz")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(gzip.compress(before[p].encode(), mtime=0))
        assert gzip.decompress(target.read_bytes()) == before[p].encode()
    alpha_old_functions = list(re.finditer(r"(?m)^    fn (\w+)\(", before[AI]))
    callback_offset = before[AI].index("&mut |_| cancel.store(true, Ordering::Relaxed)")
    affected_callback = next(
        m[1] for m in reversed(alpha_old_functions) if m.start() < callback_offset
    )
    result = {
        "static_status": "PASS",
        "native_status": "UNBUILT/UNTYPED/UNRUN",
        "forward_inverse_exact": True,
        "new_module_absence_restored": True,
        "publisher_other_AST_and_bytes_exact": True,
        "publisher_prefix_sha256": hashlib.sha256(prefix.encode()).hexdigest(),
        "publisher_suffix_sha256": hashlib.sha256(suffix.encode()).hexdigest(),
        "publisher_whole_post_sha256": hashlib.sha256(changed.encode()).hexdigest(),
        "protected_AI_functions": protected,
        "existing_AI_test_assertions_byte_exact": True,
        "new_AI_definitions": ai_names,
        "new_runner_definitions": runner_names,
        "affected_callback_test": affected_callback,
        "Python_function_before": intake.ref(HERE / "before-measurement_config.py"),
        "Python_function_after": intake.ref(HERE / "post-measurement_config.py"),
        "no_persistent_whole_publisher_copy": True,
        "private_proof_frame_removed": not frame.exists(),
    }
    (HERE / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "static_status": "PASS",
                "AI_new": len(ai_names),
                "runner_new": len(runner_names),
                "affected_callback_test": affected_callback,
            }
        )
    )


if __name__ == "__main__":
    main()
