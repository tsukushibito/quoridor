"""Finite scoped formatter/static command list, no test/compiler execution."""

import json
from pathlib import Path

here = Path(__file__).resolve().parent
ruff = ["@PYTHON@", "-m", "ruff"]
config = ["--no-cache", "--config", "/workspaces/quoridor/pyproject.toml"]
helpers = [
    str(here / n)
    for n in [
        "intake.py",
        "support.py",
        "follow.py",
        "build416.py",
        "build_measurement.py",
        "proof.py",
        "finish.py",
        "quality.py",
        "measurement_config416_test.py",
    ]
]
templates = [
    str(here / n)
    for n in [
        "draft-module.rs",
        "tests416.rs",
        "measurement416.rs",
        "measurement_tests416.rs",
    ]
]
posts = [
    str(here / "post" / n)
    for n in [
        "crates/quoridor-ai/src/alphabeta.rs",
        "crates/quoridor-ai/src/lmr_observation416.rs",
        "crates/quoridor-runner/src/measurement.rs",
    ]
]
fmt = ["rustfmt", "--edition", "2024", "--config", "skip_children=true"]
docs = [str(here / n) for n in ["report-ja.md", "verification-plan.json"]] + [
    str(p) for p in sorted(here.glob("*-commands.json"))
]
formatter = [
    "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier",
    "--config",
    "/workspaces/quoridor/.prettierrc.json",
]
commands = [
    ["format-own-Python", ruff + ["format"] + config + helpers],
    ["format-Rust-subjects", fmt + templates],
    ["generate-final-subjects", ["@PYTHON@", "-B", str(here / "build_measurement.py")]],
    ["format-postimages", fmt + posts],
    [
        "format-Python-function",
        ruff + ["format"] + config + [str(here / "post-measurement_config.py")],
    ],
    ["lint-own-helpers", ruff + ["check"] + config + helpers],
    [
        "Python-format-check",
        ruff
        + ["format", "--check"]
        + config
        + helpers
        + [str(here / "post-measurement_config.py")],
    ],
    [
        "function-fragment-syntax-lint",
        ruff
        + ["check", "--select", "E9,F63,F7"]
        + config
        + [str(here / "post-measurement_config.py")],
    ],
    ["Rust-format-check", fmt + ["--check"] + posts + templates],
    ["final-static-proof", ["@PYTHON@", "-B", str(here / "proof.py")]],
    [
        "format-own-docs-config",
        formatter + ["--write"] + docs + [str(here / "quality-v1-commands.json")],
    ],
    [
        "check-own-docs-config",
        formatter + ["--check"] + docs + [str(here / "quality-v1-commands.json")],
    ],
]
(here / "quality-v1-commands.json").write_text(json.dumps(commands, indent=2) + "\n")
print("prepared finite static-only quality commands")
