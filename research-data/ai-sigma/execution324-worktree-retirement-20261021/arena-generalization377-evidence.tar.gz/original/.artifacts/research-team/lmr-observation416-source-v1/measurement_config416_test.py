"""One new owning NN0 definition; Root runs only after sparse composition."""

import ast
import copy
from pathlib import Path
import unittest


class Measurement416(unittest.TestCase):
    def test_measurement416_observer_entry_cold_limits_bool_and_omission(self):
        source = Path("scripts/dev/research-lifecycle.py").read_text()
        function = next(
            n
            for n in ast.parse(source).body
            if isinstance(n, ast.FunctionDef) and n.name == "measurement_config"
        )
        config = {
            "roots": [
                {"input": 0, "pointer": "/roots/0", "field": "prefix", "label": "toy"}
            ],
            "profile": "control",
            "tt_entries": 1048576,
            "use_tt": True,
            "use_pvs": True,
            "lmr": True,
            "lmr_method": "depth_rank",
            "namespace": {"evaluator": "toy", "rules": "toy", "selectivity": "toy"},
            "output_bytes": 1000000,
            "record_bytes": 100000,
        }
        request = {
            "id": "one",
            "session": "one",
            "root": 0,
            "depth": 5,
            "node_cap": 1000000,
            "observe_lmr": True,
        }
        docs = {"cfg": config, "req": [request]}

        def require(condition, message):
            if not condition:
                raise ValueError(message)

        scope = {"document": docs.__getitem__, "require": require}
        exec(
            compile(
                ast.Module(body=[function], type_ignores=[]),
                "measurement_config",
                "exec",
            ),
            scope,
        )
        entry = scope["measurement_config"]
        experiment = {
            "config": "cfg",
            "schedule": "req",
            "rules": "toy",
            "inputs": [{}],
        }
        entry(experiment)
        for key, value in [
            ("observe_lmr", None),
            ("observe_lmr", 1),
            ("observe_lmr", "true"),
            ("diagnostic", True),
            ("warmup", True),
            ("observe_completed_depths", True),
            ("depth", 6),
            ("node_cap", 100001),
            ("time_limit_ms", 1),
        ]:
            bad = copy.deepcopy(request)
            bad[key] = value
            docs["req"] = [bad]
            with self.assertRaises(ValueError):
                entry(experiment)
        docs["req"] = [request]
        config["roots"][0]["check_history"] = True
        with self.assertRaises(ValueError):
            entry(experiment)
        del config["roots"][0]["check_history"]
        docs["req"] = [{k: v for k, v in request.items() if k != "observe_lmr"}]
        docs["req"][0]["depth"] = 1
        docs["req"][0]["node_cap"] = 1
        entry(experiment)


if __name__ == "__main__":
    unittest.main()
