"""Own leaf administration and minimum immutable hook/history owners."""

import json
import subprocess

import intake

HERE = intake.HERE
(issue,) = json.loads((HERE / "intake-v1/own-leaf.full.log").read_text())
selected = {k: issue.get(k) for k in ["id", "status", "assignee"]}
assert selected["id"] == "quoridor-4lc.416.2"
assert selected["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
assert selected["status"] in {"open", "in_progress"}
if selected["status"] == "open":
    result = subprocess.run(
        [
            "bash",
            "/workspaces/quoridor/scripts/dev/beads.sh",
            "update",
            selected["id"],
            "--status",
            "in_progress",
            "--json",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    (HERE / "claim-update.json").write_text(result.stdout)
(HERE / "ownership-selected.json").write_text(
    json.dumps(
        {
            "original": selected,
            "claim": "already assigned SAME owner; own status in_progress maintained through wrapper only",
            "other_issues_written": 0,
        },
        indent=2,
    )
    + "\n"
)
print(json.dumps(selected))
for relative, terms in [
    (
        "crates/quoridor-core/src/research.rs",
        ["pub struct HistoryKey", "pub fn occurrences", "pub fn count("],
    ),
    ("crates/quoridor-ai/src/move_ordering.rs", ["fn lmr_protected"]),
]:
    text = intake.git("show", intake.BASE + ":" + relative).decode()
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if any(term in line for term in terms):
            print(relative, i + 1, "\n".join(lines[i : i + 15]))
alpha = (HERE / "before/crates/quoridor-ai/src/alphabeta.rs").read_text()
print(
    "SEARCH_INITIALIZERS",
    [
        (i + 1, line)
        for i, line in enumerate(alpha.splitlines())
        if "Search {" in line or "search_in_table(" in line
    ],
)
measurement = (HERE / "before/crates/quoridor-runner/src/measurement.rs").read_text()
for i, line in enumerate(measurement.splitlines()):
    if "fn identity" in line or "fn replay(" in line:
        print("INPUT_OWNER", i + 1, "\n".join(measurement.splitlines()[i : i + 60]))
