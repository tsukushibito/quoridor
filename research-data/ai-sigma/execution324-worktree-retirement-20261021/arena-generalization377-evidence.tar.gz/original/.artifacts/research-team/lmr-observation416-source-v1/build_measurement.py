"""Private measurement and function-only Python companion; source only."""

from pathlib import Path
import build416

HERE = Path(__file__).resolve().parent
relative = Path("crates/quoridor-runner/src/measurement.rs")
once = build416.once
text = (HERE / "before" / relative).read_text()
text = once(
    text,
    "    observe_completed_depths: bool,\n}",
    "    observe_completed_depths: bool,\n    #[serde(default)]\n    observe_lmr: bool,\n}",
)
text = text.replace(
    "observe_completed_depths: false,",
    "observe_completed_depths: false,\n            observe_lmr: false,",
)
text = once(
    text,
    "    let mut ids = std::collections::BTreeSet::new();",
    """    if requests.iter().any(|r| r.observe_lmr) {
        let unique_sessions: std::collections::BTreeSet<_> = requests.iter().map(|r| &r.session).collect();
        let unique_roots: std::collections::BTreeSet<_> = requests.iter().map(|r| r.root).collect();
        if requests.len() > 12 || unique_sessions.len() != requests.len() || unique_roots.len() != requests.len()
            || settings.profile != Profile::Control || settings.tt_entries != 1_048_576
            || !settings.use_tt || !settings.use_pvs || !settings.lmr
            || LmrMethod::from_name(&settings.lmr_method)? != LmrMethod::DepthRank
            || settings.zero_stock_approx_min_root_walls.is_some() || settings.zero_stock_safe_race
            || requests.iter().any(|r| !r.observe_lmr || r.depth != 5 || r.node_cap != 1_000_000
                || r.time_limit_ms.is_some() || r.warmup || r.diagnostic || r.observe_completed_depths) {
            return Err("bounded LMR observation requires <=12 distinct cold Control/depth_rank D5/1M roots, TT1M/PVS, no other observers/approximation".into());
        }
    }
    let mut ids = std::collections::BTreeSet::new();""",
)
text = once(
    text,
    """    let expected = selector
        .check_history
        .then(|| json!({"root_key":row["root_key"],"history_counts":row["history_counts"]}));""",
    """    let expected = if row.get("opening_bound").is_some() || row.get("expected_divergence_board").is_some() {
        if selector.field != "prefix" || selector.prefix_len.is_some() || selector.check_history || selector.jsonl_match.is_some() {
            return Err("observation must replay the full chronological prefix, not opening counts/truncation".into());
        }
        Some(json!({"opening_bound":row["opening_bound"],"expected_divergence_board":row["expected_divergence_board"],
            "id":row["id"],"evaluator":row["evaluator"],"source_example":row["source_example"],
            "original_A_raw":row["original_A_raw"],"original_B_raw":row["original_B_raw"]}))
    } else {
        selector.check_history.then(|| json!({"root_key":row["root_key"],"history_counts":row["history_counts"]}))
    };""",
)
text = once(
    text,
    """        self.before = identity(&root);
        self.root = Some(root);""",
    """        if request.observe_lmr {
            let expected = self.roots[request.root].expected.as_ref().ok_or("observation missing bound input")?;
            if expected.get("opening_bound").is_none() { return Err("observation requires bound chronological input".into()); }
            let kind = if self.settings.namespace.evaluator == crate::teacher_pilot_execution::EVALUATOR_ID {"distance"} else {"nnue"};
            if expected["evaluator"] != kind { return Err("observation input/evaluator mismatch".into()); }
        }
        self.before = identity(&root);
        self.root = Some(root);""",
)
text = once(
    text,
    """        let search_started = Instant::now();
        let mut completed_depths = Vec::new();
        let result = if request.observe_completed_depths {""",
    """        let mut lmr_observation = request.observe_lmr.then(|| Box::new(alphabeta::LmrObservation::default()));
        let search_started = Instant::now();
        let mut completed_depths = Vec::new();
        let result = if let Some(observation) = lmr_observation.as_deref_mut() {
            session.search_with_lmr_observation(root, &limits, cancel, observation)
        } else if request.observe_completed_depths {""",
)
text = once(
    text,
    "        let after = identity(root);\n        let mut row = match result {",
    """        let after = identity(root);
        let lmr_output = lmr_observation.as_deref().map(|observation|
            lmr_observation_output(session, root, observation, cancel, result.is_ok() && after == self.before));
        let mut row = match result {""",
)
text = once(
    text,
    '        row["Search_call_seconds"] = json!(search_seconds);',
    """        if let Some(mut observation) = lmr_output {
            observation["input"] = self.roots[request.root].expected.clone().unwrap_or(Value::Null);
            observation["root_fullhistory"] = self.before.clone();
            row["lmr_observation"] = observation;
        }
        row["Search_call_seconds"] = json!(search_seconds);""",
)
text = once(
    text,
    """        if actual["root_key"] != expected["root_key"]
            || actual["history_counts"] != expected["history_counts"]""",
    """        if expected.get("opening_bound").is_some() {
            observation_input_check(&spec.prefix, expected, &root)?;
        } else if actual["root_key"] != expected["root_key"]
            || actual["history_counts"] != expected["history_counts"]""",
)
text += (
    "\n"
    + (HERE / "measurement416.rs").read_text()
    + "\n"
    + (HERE / "measurement_tests416.rs").read_text()
)
build416.write(relative, text)
body = (HERE / "before-measurement_config.py").read_text()
body = body.replace(
    '                "observe_completed_depths",',
    '                "observe_completed_depths",\n                "observe_lmr",',
)
body = once(
    body,
    'for k in ("diagnostic", "warmup", "observe_completed_depths")',
    'for k in ("diagnostic", "warmup", "observe_completed_depths", "observe_lmr")',
)
body = once(
    body,
    "    return config, requests",
    """    if any(r.get("observe_lmr", False) for r in requests):
        require(
            len(requests) <= 12
            and len({r["session"] for r in requests}) == len(requests)
            and len({r["root"] for r in requests}) == len(requests)
            and config["profile"] == "control"
            and config["tt_entries"] == 1048576
            and config["use_tt"] and config["use_pvs"] and config.get("lmr", False)
            and lmr_method == "depth_rank" and threshold is None
            and not config.get("zero_stock_safe_race", False)
            and all(r.get("observe_lmr", False) and r["depth"] == 5 and r["node_cap"] == 1000000
                    and r.get("time_limit_ms") is None and not r.get("diagnostic", False)
                    and not r.get("warmup", False) and not r.get("observe_completed_depths", False)
                    for r in requests),
            "bounded LMR observation cold Control/depth_rank D5/1M TT1M scope",
        )
        require(all(r["field"] == "prefix" and r.get("prefix_len") is None
                    and r.get("jsonl_match") is None and not r.get("check_history", False)
                    for r in config["roots"]), "LMR observation complete-prefix selectors")
    return config, requests""",
)
(HERE / "post-measurement_config.py").write_text(body + "\n")
print("private measurement and one Python function generated; untyped/unrun")
