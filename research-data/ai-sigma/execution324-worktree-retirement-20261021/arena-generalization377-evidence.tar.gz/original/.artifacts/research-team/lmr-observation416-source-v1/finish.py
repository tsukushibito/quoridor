"""Freeze exact source refs and original returned-versus-disk process scope."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import stat

import intake


def freeze(lc, here):
    original_affinity = os.sched_getaffinity(0)
    os.sched_setaffinity(0, {3})
    try:
        phases, children, failures = [], [], []
        for path in sorted(here.glob("*-v*/result.json")):
            result = json.loads(path.read_text())
            phases.append(intake.ref(path))
            if result["status"] != "PASS":
                failures.append(
                    {
                        "phase": path.parent.name,
                        "original": intake.ref(path),
                        "primary": result["primary"],
                    }
                )
            for check in result["checks"]:
                returned = check["guardian_return"]
                disk_ref = check.get("persisted_process_receipt")
                if disk_ref is None:
                    children.append(
                        {
                            "phase": path.parent.name,
                            "name": check["name"],
                            "status": check["status"],
                            "guardian_return": returned,
                            "persisted_process_receipt": None,
                            "child": "UNKNOWN; no recorded identity",
                        }
                    )
                    continue
                disk = json.loads(Path(disk_ref["path"]).read_text())
                facts = returned if returned is not None else disk
                assert facts["direct_child_reaped"] and facts["cleanup_complete"]
                assert facts["handle_closes_complete"] and not facts["remaining"]
                child = facts["child"]
                fresh = lc.process.identity(lc.process.process_info(child["pid"]))
                assert fresh is None or fresh != child
                children.append(
                    {
                        "phase": path.parent.name,
                        "name": check["name"],
                        "status": check["status"],
                        "child": child,
                        "fresh_identity": fresh,
                        "exit_code": facts["exit_code"],
                        "launch_policy": facts["launch_policy"],
                        "direct_child_reaped": facts["direct_child_reaped"],
                        "handles_complete": facts["handle_closes_complete"],
                        "cleanup_complete": facts["cleanup_complete"],
                        "returned_scope": "NULL; disk cleanup only, never synthesized settled return"
                        if returned is None
                        else "original settled guardian return",
                        "returned_mask": None
                        if returned is None
                        else returned.get("signal_mask_restoration"),
                        "returned_persist": None
                        if returned is None
                        else returned.get("final_record_persist"),
                        "disk_mask": disk.get("signal_mask_restoration"),
                        "disk_persist": disk.get("final_record_persist"),
                        "original_seconds_once_nested_excluded": facts["wall_seconds"],
                        "full_log": check["full_log"],
                        "capture_complete_reported": check["capture_complete"],
                        "disk_receipt": disk_ref,
                    }
                )
            assert not (path.parent / "TMP").exists()
        assert not (here / "proof-frame").exists()
        source_refs = []
        for relative in [
            Path("crates/quoridor-ai/src/alphabeta.rs"),
            Path("crates/quoridor-ai/src/lmr_observation416.rs"),
            Path("crates/quoridor-runner/src/measurement.rs"),
        ]:
            before = here / "before" / relative
            post = here / "post" / relative
            source_refs.append(
                {
                    "relative": str(relative),
                    "before": intake.ref(before)
                    if before.exists()
                    else "ABSENT at fixed Git",
                    "post": intake.ref(post),
                }
            )
        bound = {
            "issue": "quoridor-4lc.416.2",
            "base_Git": intake.BASE,
            "status": "SOURCE_FROZEN; UNBUILT/UNTYPED/UNRUN",
            "intake": intake.ref(here / "intake-refs.json"),
            "source_refs": source_refs,
            "Python_function_owner": intake.ref(
                here / "measurement-config-binding.json"
            ),
            "Python_before": intake.ref(here / "before-measurement_config.py"),
            "Python_post": intake.ref(here / "post-measurement_config.py"),
            "Python_fixture": intake.ref(here / "measurement_config416_test.py"),
            "forward": intake.ref(here / "lmr-observation416.patch"),
            "inverse": intake.ref(here / "lmr-observation416.inverse.patch"),
            "static_proof": intake.ref(here / "static-proof.json"),
            "verification_plan": intake.ref(here / "verification-plan.json"),
            "report": intake.ref(here / "report-ja.md"),
            "selected_input": json.loads(
                (here / "selected-input-ref.json").read_text()
            ),
            "components_before_gzip": [
                intake.ref(p) for p in sorted((here / "before-gzip").rglob("*.gz"))
            ],
            "managed_production_Main_Git_index_Cargo_native_Search_models_tests_written_or_executed": 0,
            "no_independent_review_dispatched": True,
        }
        (here / "source-binding.json").write_text(json.dumps(bound, indent=2) + "\n")
        # One affected namespace walk only. Dedupe hardlinks/overlap by real FS inode.
        seen, logical, allocated, files = set(), 0, 0, 0
        for directory, dirs, names in os.walk(here):
            for p in [Path(directory)] + [Path(directory) / n for n in names]:
                s = p.lstat()
                key = (s.st_dev, s.st_ino)
                if key in seen:
                    continue
                seen.add(key)
                allocated += s.st_blocks * 512
                if stat.S_ISREG(s.st_mode):
                    logical += s.st_size
                    files += 1
        fs = os.statvfs(here)
        controller = lc.process.identity(lc.process.process_info(os.getpid()))
        result = {
            "issue": "quoridor-4lc.416.2",
            "source_binding": intake.ref(here / "source-binding.json"),
            "actual_source_reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
            "controller": controller,
            "controller_scope": "current metadata-only writer; its fresh absence is checked after return in admin-STOP",
            "phases": phases,
            "children": children,
            "original_failures_immutable": failures,
            "guarded_child_seconds_once_sum": sum(
                c.get("original_seconds_once_nested_excluded", 0) for c in children
            ),
            "not_turn_elapsed_or_total_LLM_CPU_peak_claim": True,
            "current_source_readers": [],
            "writers": [],
            "children_remaining": [],
            "jobs": [],
            "handles": [],
            "TMP": [],
            "leases": [],
            "owned": [],
            "canonical_hardware_reservation": "NONE; no idle lease; source named immutable Git only, maintained port import unchanged",
            "directed_OWN_usage_once": {
                "logical_file_bytes": logical,
                "allocated_inode_bytes": allocated,
                "files": files,
                "dedup_inodes": len(seen),
                "FS_available_bytes": fs.f_bavail * fs.f_frsize,
                "scope": str(here),
                "budget": None,
                "excluded": "this final STOP and later tinyadmin; no assets/target/global walk or oldholding charge/refund",
                "global_actual": "UNKNOWN",
                "decimal_global_limit": 50_000_000_000,
            },
            "native_type_test_software_review_science": "NOT_RUN; Root only, leaf remains in_progress pending scope acceptance",
        }
        (here / "source-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "source_STOP": intake.ref(here / "source-STOP.json"),
                    "binding": intake.ref(here / "source-binding.json"),
                    "owned": [],
                }
            )
        )
    finally:
        os.sched_setaffinity(0, original_affinity)
