# 416.2 限定LMR観測・隔離cold scout source

固定12局面向けの私有候補です。Main、managed production、Git/index/Cargoへの書込み、native/Search/model/game/testの実行はありません。native型検査・software・独立境界確認・入力admission・科学結果は未実施です。元415/413/412/411/410と停止中のmixed/learner/323は変更していません。

基盤は immutable Git `8c54ec630e253dc5b92604a52057b4978a8fea68`。Alpha before `0391bcd2`/161687B、measurement before `678decab`/68774B。Astra design `c2e3102a`/7192Bと verification `4393a542`/1939Bは読取前後にhash/size/modeを検査しました。具体的なFileRefs、forward/inverseとbefore gzipは source-binding.json にまとめます。

## 現役入口とOFF

単一の Request `observe_lmr: bool`、省略falseです。Pythonはbool以外を拒否し、native serdeもnull/数値/文字列を拒否します。ONではControl、TT1M、PVS、LMR depth_rank、D5/1M/timeNone、他observer/approx/safe-race OFF、各rootに別session、重複rootなし、最大12要求を検査します。evaluator/namespace/設定の正本と製品・生成defaultsは既存のままです。

AIの追加APIはresearch-diagnostics限定の `LmrObservation::default()`、`SearchSession::search_with_lmr_observation(root, limits, cancel, &mut observation)`、`SearchSession::cold_lmr_scout(root, &branch, normal, cancel)` です。method/table/順位の別実装はありません。private Searchをconst `OBSERVE`で分け、通常とcoldはfalse、採取rootだけtrueです。OFFのper-node snapshot/heap/scan/clock/log/counter walkを追加しません。Searchの任意observer参照とinvocation metadataのlayout/最適化後機械語・stack/RSS差は未計測です。

## 採取

実際に選択された異なる手のindexから、既存の `lmr_allowed` とcanonical quantumを使います。合法TT-firstもdistinct rankに含み、PVS同手再探索では進めません。採点済み保護情報・frozen key・TT-first後のsiblings準備時点はそのままです。

固定4枠はH0 d3/d4、H+ q1/q2+。H0はeligible q0かつrank4..8の子実行前に確保し、未完了でも交換しません。H+は実際に完了したshallow fail-lowだけ確保します。同一hypothesisの完全親履歴＋actionの重複は除き、最初の未重複対象を採取します。枠取得後の置換、cap/errorからの補充、追加rootはありません。履歴同一性はposition/rules/synthetic/total plyとcanonical `count` の両方向照合です。選ばれた最大4親だけContext/pathを保存し、TTやhistory tablesは保存しません。

窓は元のpost-TT/current alphaとbetaのbitsです。childの実窓/深さ、parent STMへ反転済みの実戻り値/bound/completionを記録します。q0のstageはnormal scout→必要時full window、q>0はshallow→必要時normal-depth確認→必要時full windowです。H+採取自体はshallow fail-lowなので後続stageは通常nullです。未入場stageはnull、開始後中断はvalue/bound nullとcompleted=falseです。TT metadataは元のprobe戻りと合法性確認の結果を使い、追加probeをしません。保護は既存のcombined saved-ranking gateがfalseという事実を記録し、別のgoal判定を観測のために実行しません。

coverageはd3/d4 × rank4..8/9..15/16..31/32+ × q0/q1/q2+の固定配列です。eligible機会、最初のchild完了/fail-low、通常深さ確認/full window開始を数えます。visit serialは全iterationにわたるeligible nonroot d3/d4の異なる手の通番です。未到達depthやcapで機会が無いことを、仮説否定や未観測費用0とは扱いません。

## chronological入力とcold隔離

Root提供 `twelve-prefixes.json` は `75e41757`/35281B0644で前後検査済み。元array順distance6→NNUE6、prefix長 `[4,6,5,9,4,6,4,6,4,9,8,4]` を保持します。共通の `from_prefix`/`validate_normal`/非terminal/rules検査で全prefixを再生します。opening_boundはopening長だけを再生して比較し、divergenceは駒・stock・壁ID・手番・plyを別に比較します。opening countsをdivergence完全countsへ流用せず、`from_counts`へ置換しません。future native admissionはRootで未実施です。

元root Searchが返却し親復元を確認した後、保持した各branchのreduced/normalを順に実行します。両者とも別の空TT1M、zero continuation/killers、別scratch/storageを所有し終了時dropします。root sessionはimmutable borrowだけです。同じrootの完全prefix Contextと採取action/colour pathから親を再構成し、保存した完全親counts/position/plyと一致しなければ拒否します。

共通 `search_in_table` の検査・prepare・control・復元を再用し、元nonroot ply+1で既存childを一度呼びます。root_depth/iterative-deepening/parentでの自動確認は呼びません。親STMの窓 `[alpha,next_up(alpha)]`、H0 child d-2、H+ d-1-q、normal d-1、各100K/timeNoneです。下位の探索は現行selective depth_rankのままです。capsではcompleted_depth=0/value=Noneが残り、以前のroot iterationの完了値を代用しません。normal probeも全幅/WDLのoracleではなく、元warm TT/historyを再現しません。

Rootエラー/復元不一致/cancelはprobe未入場をUNKNOWNとし、probeのprepare/kernel error後も残りを補充しません。NodeLimitのreducedと独立normalは事前に定めた別scoutで、追加確認ではありません。child_calledはcommon child呼出の有無、common_invocation_startedとは別です。元driverのcallsはroot数のまま、cold呼出・child呼出・完了/UNKNOWN・recorded nodes/evalsを別censusにします。Errorで失われたworkを0にせずunknown_work_invocationsを出します。

全体上限は12 roots＋48 branches×2＝108 calls、12M＋9.6M＝21.6M nodes。Rootはmanifest/resources/collectorの計数でroot driver callsだけを全Search数と扱わないでください。1rootの元TTと1probeの空TTが同時にliveになるためTTだけで約2×既存1M retained分です。snapshot Context/path、history、scratch、NNUE storage、drop/copy/clone費は別で、実peak/timeはUNKNOWNです。whole target clockはprobe準備・drop・出力を含み、Search_call_secondsは元rootのみです。nested clockを加算しません。

## 検証と残る境界

Rustfmt/Ruff/Prettierとstatic forward→inverse/ABSENT復元、Pythonの関数外byte/AST、既存AI assertionsと列挙した数学/探索関数のbyte保護を実施します。native new AI6＋runner2＋Python NN0定義1はすべてUNBUILT/UNTYPED/UNRUNです。正確なnames/features/filterはverification-plan.jsonへ記録します。Rootの必要compile/Clippy/genuine buildと、別ownerによるprobe isolation/window/depth/boundの限定確認が必要です。

original source helperのassert失敗draft-v1と、関数末尾を仮のEOFとしてdiffしたstatic proof-v1/v2失敗はcapture/receipt/NULLとdisk状態を保持しています。後者は元function外の通常contextを含むthin diffへ修正し、関数外bytes/ASTは不変です。源コードの型・native/softwareや科学の成功には読み替えません。外部payload/旧RAW/solver/モデル読取は0です。

終了時の実directwait/reap/fresh PID-start-boot/handles/TMP/owned[]、親controller返却後のadmin STOP、OWNだけの一度の実使用はsource-STOP/admin-STOPへ記録します。Main/Git/Cargo・parent close・科学入場は現在324だけです。
