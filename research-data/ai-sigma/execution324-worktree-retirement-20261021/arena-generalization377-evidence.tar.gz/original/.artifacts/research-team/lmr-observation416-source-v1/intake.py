"""Bound immutable416 design before/after parse, and only current owning source."""

import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
BASE = "8c54ec630e253dc5b92604a52057b4978a8fea68"


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def git(*args):
    return subprocess.run(
        [
            "git",
            "-c",
            "core.packedGitWindowSize=8m",
            "-c",
            "core.packedGitLimit=32m",
            "--no-optional-locks",
            *args,
        ],
        cwd="/workspaces/quoridor",
        capture_output=True,
        check=True,
    ).stdout


def main():
    verified = []
    directory = Path(
        "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/lmr-observation416-analysis-v1"
    )
    for name, sha, size in [
        (
            "design-ja.md",
            "c2e3102ab2304efe4070ef6407848d297ae77ae2bfebbe178c0179e0ff2930b2",
            7192,
        ),
        (
            "verification.json",
            "4393a542626f39763fbc9ade1156ef09dfa680c568a415b9c12edf8918e19075",
            1939,
        ),
    ]:
        path = directory / name
        before = ref(path)
        assert (
            before["sha256"] == sha
            and before["bytes"] == size
            and before["mode"] == "0644"
        )
        data = path.read_text()
        print(name, data)
        assert ref(path) == before
        verified.append(before)
    contract = Path(
        "/workspaces/quoridor/.artifacts/research-policy/lmr-limited-observation-20261015.md"
    )
    print("CONTRACT", contract.read_text())
    assert git("rev-parse", "--verify", BASE + "^{commit}").decode().strip() == BASE
    owners = []
    for relative in [
        "crates/quoridor-ai/src/alphabeta.rs",
        "crates/quoridor-runner/src/measurement.rs",
    ]:
        raw = git("show", BASE + ":" + relative)
        path = HERE / "before" / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        owners.append(
            {
                "relative": relative,
                "Git": BASE,
                "blob_oid": git("rev-parse", BASE + ":" + relative).decode().strip(),
                "before": ref(path),
            }
        )
        text = raw.decode()
        if relative.endswith("alphabeta.rs"):
            assert (
                owners[-1]["before"]["sha256"].startswith("0391bcd2")
                and len(raw) == 161687
            )
            for i, line in enumerate(text.splitlines()):
                if any(
                    term in line
                    for term in [
                        "fn negamax",
                        "fn child(",
                        "fn reduced_child",
                        "fn search_in_table",
                        "fn search(",
                        "pub fn search",
                        "fn lmr_allowed",
                        "struct Search",
                        "struct SearchSession",
                        "struct SearchLimits",
                    ]
                ):
                    print("AI_OWNER", i + 1, line)
        else:
            assert (
                owners[-1]["before"]["sha256"].startswith("678decab")
                and len(raw) == 68774
            )
            for i, line in enumerate(text.splitlines()):
                if any(
                    term in line
                    for term in [
                        "struct Settings",
                        "struct Request",
                        "struct Alpha",
                        "impl Target",
                        "fn call(",
                        "fn observed",
                        "fn drive",
                        "fn validate",
                        "fn load",
                    ]
                ):
                    print("MEASUREMENT_OWNER", i + 1, line)
    (HERE / "intake-refs.json").write_text(
        json.dumps(
            {
                "base": BASE,
                "specs_verified_before_after": verified,
                "contract": ref(contract),
                "owners": owners,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
