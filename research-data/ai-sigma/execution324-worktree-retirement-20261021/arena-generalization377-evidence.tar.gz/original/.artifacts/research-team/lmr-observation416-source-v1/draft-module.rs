//! Bounded research-only observations. No search, evaluator or ordering copy.
use super::*;

#[derive(Clone, Copy, Debug)]
pub struct LmrStage {
    pub child_depth: u16,
    pub window_bits: [u32; 2],
    pub value_bits: Option<u32>,
    pub bound: Option<&'static str>,
    pub completed: bool,
}

#[derive(Clone, Copy, Debug)]
pub struct LmrTtFacts {
    pub stored_depth: u16,
    pub bound: &'static str,
    pub context_matches: bool,
    pub usable_depth: bool,
    pub legal_move: Option<u16>,
}

#[derive(Clone, Copy, Debug)]
pub struct LmrBranchFacts {
    pub hypothesis: &'static str,
    pub iteration_depth: u16,
    /// Serial over eligible nonroot d3/d4 distinct hands, across iterations.
    pub visit: u64,
    pub parent_depth: u16,
    pub parent_ply: usize,
    pub parent_stm: u8,
    pub distinct_rank: usize,
    pub action: u16,
    pub quantum: u16,
    pub alpha_beta_bits: [u32; 2],
    pub tt: Option<LmrTtFacts>,
}

pub struct LmrBranch {
    pub facts: LmrBranchFacts,
    parent: SigmaContext,
    path: Vec<(u8, u16)>,
    pub stages: [Option<LmrStage>; 3],
}
impl LmrBranch {
    pub fn parent(&self) -> &SigmaContext {
        &self.parent
    }
    pub fn path(&self) -> &[(u8, u16)] {
        &self.path
    }
    pub fn reduced_child_depth(&self) -> u16 {
        self.facts.parent_depth - 1 - self.facts.quantum.max(1)
    }
    pub fn normal_child_depth(&self) -> u16 {
        self.facts.parent_depth - 1
    }
}

#[derive(Clone, Copy, Default, Debug)]
pub struct LmrCoverage {
    pub opportunities: u64,
    pub first_completed: u64,
    pub first_fail_low: u64,
    pub normal_confirmations: u64,
    pub full_windows: u64,
}
pub(super) struct Frame {
    facts: LmrBranchFacts,
    bucket: (usize, usize, usize),
    selected: Option<usize>,
    stages: [Option<LmrStage>; 3],
    calls: usize,
}

pub struct LmrObservation {
    branches: [Option<LmrBranch>; 4],
    pub(super) frames: [Option<Frame>; 6],
    /// d3/d4 x rank 4..8/9..15/16..31/32+ x q0/q1/q2+.
    pub coverage: [[[LmrCoverage; 3]; 4]; 2],
    pub(super) iteration: u16,
    visits: u64,
    used: bool,
    pub finished: bool,
    pub root_stop: Option<String>,
}
impl Default for LmrObservation {
    fn default() -> Self {
        Self {
            branches: std::array::from_fn(|_| None),
            frames: std::array::from_fn(|_| None),
            coverage: [[[LmrCoverage::default(); 3]; 4]; 2],
            iteration: 0,
            visits: 0,
            used: false,
            finished: false,
            root_stop: None,
        }
    }
}
fn same_history(a: &SigmaContext, b: &SigmaContext) -> bool {
    a.position() == b.position()
        && a.is_synthetic() == b.is_synthetic()
        && a.total_ply() == b.total_ply()
        && a.ruleset().id() == b.ruleset().id()
        && a.occurrences().all(|(k, _)| a.count(k) == b.count(k))
        && b.occurrences().all(|(k, _)| a.count(k) == b.count(k))
}
impl LmrObservation {
    pub fn branches(&self) -> impl Iterator<Item = &LmrBranch> {
        self.branches.iter().filter_map(Option::as_ref)
    }
    fn retain(&mut self, slot: usize, ply: usize, c: &SigmaContext, path: &[PlayedMove]) {
        if self.branches[slot].is_some() {
            return;
        }
        let f = self.frames[ply].as_ref().expect("active eligible hand");
        let hypothesis = if slot < 2 { "H0" } else { "H+" };
        if self.branches().any(|b| {
            b.facts.hypothesis == hypothesis
                && b.facts.action == f.facts.action
                && same_history(&b.parent, c)
        }) {
            return;
        }
        let mut facts = f.facts;
        facts.hypothesis = hypothesis;
        self.branches[slot] = Some(LmrBranch {
            facts,
            parent: c.clone(),
            path: path.iter().map(|m| (m.colour, m.action)).collect(),
            stages: f.stages,
        });
        self.frames[ply].as_mut().expect("active hand").selected = Some(slot);
    }
    pub(super) fn begin(
        &mut self,
        c: &SigmaContext,
        path: &[PlayedMove],
        mut facts: LmrBranchFacts,
    ) {
        let d = facts.parent_depth;
        let ply = facts.parent_ply;
        if !(3..=4).contains(&d) || ply == 0 || ply >= self.frames.len() {
            return;
        }
        self.visits += 1;
        facts.visit = self.visits;
        facts.iteration_depth = self.iteration;
        let r = match facts.distinct_rank {
            4..=8 => 0,
            9..=15 => 1,
            16..=31 => 2,
            _ => 3,
        };
        let q = usize::from(facts.quantum.min(2));
        let bucket = (usize::from(d - 3), r, q);
        self.coverage[bucket.0][r][q].opportunities += 1;
        self.frames[ply] = Some(Frame {
            facts,
            bucket,
            selected: None,
            stages: [None; 3],
            calls: 0,
        });
        if q == 0 && r == 0 {
            self.retain(usize::from(d - 3), ply, c, path);
        }
    }
    pub(super) fn child_start(&mut self, ply: usize, action: u16, depth: u16, window: [f32; 2]) {
        let Some(f) = self.frames.get_mut(ply).and_then(Option::as_mut) else {
            return;
        };
        if f.facts.action != action {
            return;
        }
        let i = f.calls;
        assert!(i < 3, "one shallow/confirm/full-window sequence");
        f.calls += 1;
        f.stages[i] = Some(LmrStage {
            child_depth: depth,
            window_bits: window.map(f32::to_bits),
            value_bits: None,
            bound: None,
            completed: false,
        });
        let (d, r, q) = f.bucket;
        if i > 0 {
            if q > 0 && i == 1 {
                self.coverage[d][r][q].normal_confirmations += 1;
            } else {
                self.coverage[d][r][q].full_windows += 1;
            }
        }
        if let Some(slot) = f.selected {
            self.branches[slot].as_mut().unwrap().stages = f.stages;
        }
    }
    pub(super) fn child_return(
        &mut self,
        c: &SigmaContext,
        path: &[PlayedMove],
        ply: usize,
        action: u16,
        result: &NodeResult<f32>,
    ) {
        let Some(f) = self.frames.get_mut(ply).and_then(Option::as_mut) else {
            return;
        };
        if f.facts.action != action {
            return;
        }
        let i = f.calls - 1;
        let s = f.stages[i].as_mut().unwrap();
        let mut select = None;
        if let Ok(value) = result {
            s.completed = true;
            s.value_bits = Some(value.to_bits());
            s.bound = Some(if *value <= f32::from_bits(s.window_bits[0]) {
                "Upper"
            } else if *value >= f32::from_bits(s.window_bits[1]) {
                "Lower"
            } else {
                "Exact"
            });
            if i == 0 {
                let (d, r, q) = f.bucket;
                self.coverage[d][r][q].first_completed += 1;
                if *value <= f32::from_bits(f.facts.alpha_beta_bits[0]) {
                    self.coverage[d][r][q].first_fail_low += 1;
                    if q > 0 {
                        select = Some(if q == 1 { 2 } else { 3 });
                    }
                }
            }
        }
        if let Some(slot) = f.selected {
            self.branches[slot].as_mut().unwrap().stages = f.stages;
        }
        if let Some(slot) = select {
            self.retain(slot, ply, c, path);
        }
    }
    fn finish(&mut self, result: &Result<SearchResult>) {
        self.finished = true;
        self.root_stop = Some(match result {
            Ok(r) => format!("{:?}", r.stop),
            Err(e) => e.to_string(),
        });
        self.frames = std::array::from_fn(|_| None);
    }
}

pub(super) struct ColdScout<'a> {
    pub(super) action: u16,
    pub(super) depth: u16,
    pub(super) alpha: f32,
    pub(super) parent_ply: usize,
    pub(super) path: &'a [PlayedMove],
    pub(super) child_called: &'a std::cell::Cell<bool>,
}
pub struct LmrColdProbe {
    /// Err means the internal kernel failed; no completed value is supplied.
    pub result: Result<SearchResult>,
    pub child_called: bool,
    pub child_depth: u16,
    pub window_bits: [u32; 2],
}
impl SearchSession {
    fn observation_compatible(&self, limits: &SearchLimits) -> bool {
        self.static_enabled == StaticMode::CheapControl
            && self.lmr
            && self.lmr_method == LmrMethod::DepthRank
            && !self.ordering_diagnostics
            && self.zero_stock_approx_min_root_walls.is_none()
            && !self.zero_stock_approx_effective
            && !self.zero_stock_safe_race
            && self.table.slots.len() == 1_048_576
            && limits.tt_entries == 1_048_576
            && limits.use_pvs
            && limits.use_tt
            && limits.time_limit.is_none()
            && limits.max_depth <= 5
            && limits.max_nodes <= 1_000_000
    }
    pub fn search_with_lmr_observation(
        &mut self,
        root: &SigmaContext,
        limits: &SearchLimits,
        cancel: &AtomicBool,
        observation: &mut LmrObservation,
    ) -> Result<SearchResult> {
        if !self.observation_compatible(limits) || observation.used || self.table.generation != 0 {
            return Err(SearchError::Limits("LMR observation requires fresh Control/TT1M/depth_rank, bounded D5, approximation OFF".into()));
        }
        observation.used = true;
        let mut callback = |_: &SearchResult| {};
        let result = search_in_table::<true>(
            root,
            self.evaluator.as_ref(),
            limits,
            cancel,
            None,
            SearchInvocation {
                on_completed: &mut callback,
                observation: Some(&mut *observation),
                cold: None,
            },
            (
                &mut self.table,
                self.score_domain,
                self.ordering.as_mut(),
                false,
                StaticMode::CheapControl,
                (true, LmrMethod::DepthRank),
                (false, self.zero_stock_approx_method, false),
            ),
        );
        observation.finish(&result);
        result
    }
    /// A single common child scout at its original nonroot ply. No root search,
    /// iterative deepening, parent confirmation, historical TT or order snapshot.
    pub fn cold_lmr_scout(
        &self,
        root: &SigmaContext,
        branch: &LmrBranch,
        normal: bool,
        cancel: &AtomicBool,
    ) -> Result<LmrColdProbe> {
        if !self.observation_compatible(&SearchLimits {
            max_depth: 5,
            max_nodes: 100_000,
            time_limit: None,
            tt_entries: 1_048_576,
            use_tt: true,
            use_pvs: true,
        }) {
            return Err(SearchError::Limits("incompatible cold LMR scout".into()));
        }
        let mut parent = root.clone();
        for &(colour, action) in &branch.path {
            if parent.position().turn != colour {
                return Err(SearchError::Root("captured path mover mismatch".into()));
            }
            parent = parent.play(action)?;
        }
        if !same_history(&parent, &branch.parent)
            || parent.terminal_value().is_some()
            || branch.path.len() != branch.facts.parent_ply
        {
            return Err(SearchError::Root(
                "cold scout parent/path/fullhistory mismatch".into(),
            ));
        }
        let depth = if normal {
            branch.normal_child_depth()
        } else {
            branch.reduced_child_depth()
        };
        let alpha = f32::from_bits(branch.facts.alpha_beta_bits[0]);
        let limits = SearchLimits {
            max_depth: 5,
            max_nodes: 100_000,
            time_limit: None,
            tt_entries: 1_048_576,
            use_tt: true,
            use_pvs: true,
        };
        let mut table = Table::persistent(1_048_576)?;
        let mut history = ContinuationHistory::new()?;
        let path: Vec<_> = branch
            .path
            .iter()
            .map(|&(colour, action)| PlayedMove { colour, action })
            .collect();
        let mut callback = |_: &SearchResult| {};
        let child_called = std::cell::Cell::new(false);
        let result = search_in_table::<false>(
            &parent,
            self.evaluator.as_ref(),
            &limits,
            cancel,
            None,
            SearchInvocation {
                on_completed: &mut callback,
                observation: None,
                cold: Some(ColdScout {
                    action: branch.facts.action,
                    depth,
                    alpha,
                    parent_ply: branch.facts.parent_ply,
                    path: &path,
                    child_called: &child_called,
                }),
            },
            (
                &mut table,
                self.score_domain,
                Some(&mut history),
                false,
                StaticMode::CheapControl,
                (true, LmrMethod::DepthRank),
                (false, self.zero_stock_approx_method, false),
            ),
        );
        Ok(LmrColdProbe {
            result,
            child_called: child_called.get(),
            child_depth: depth,
            window_bits: [alpha.to_bits(), next_up(alpha).to_bits()],
        })
    }
}
