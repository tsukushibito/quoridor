"""Private sparse draft from the pinned beforeimages; never runs Rust."""

from pathlib import Path

HERE = Path(__file__).resolve().parent
AI = Path("crates/quoridor-ai/src/alphabeta.rs")
OUT = HERE / "post"


def once(text, before, after):
    assert text.count(before) == 1, before[:160]
    return text.replace(before, after, 1)


def write(path, text):
    target = OUT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)


alpha = (HERE / "before" / AI).read_text()
alpha = once(
    alpha,
    '#[path = "move_ordering.rs"]',
    """#[cfg(feature = "research-diagnostics")]
#[path = "lmr_observation416.rs"]
mod lmr_observation416;
#[cfg(feature = "research-diagnostics")]
pub use lmr_observation416::{LmrObservation, LmrBranch, LmrBranchFacts, LmrStage, LmrTtFacts, LmrCoverage, LmrColdProbe};

#[path = "move_ordering.rs"]""",
)
alpha = once(
    alpha, "struct Search<'a> {", "struct Search<'a, const OBSERVE: bool = false> {"
)
alpha = once(
    alpha, "impl Search<'_> {", "impl<const OBSERVE: bool> Search<'_, OBSERVE> {"
)
alpha = once(
    alpha,
    "    history: [u64; 209],\n}",
    """    history: [u64; 209],
    #[cfg(feature = "research-diagnostics")]
    lmr_observation: Option<&'a mut LmrObservation>,
}""",
)
# All pre-existing literals stay on the compile-time OFF route.
alpha = alpha.replace("let mut state = Search {", "let mut state = Search::<false> {")
alpha = alpha.replace(
    "history: [0; 209],",
    'history: [0; 209],\n        #[cfg(feature = "research-diagnostics")]\n        lmr_observation: None,',
)
alpha = once(
    alpha,
    """    ) -> NodeResult<f32> {
        self.control()?;
        let mover = c.position().turn;""",
    """    ) -> NodeResult<f32> {
        #[cfg(feature = "research-diagnostics")]
        if OBSERVE && let Some(o) = self.lmr_observation.as_deref_mut() {
            o.child_start(ply - 1, action, depth, window);
        }
        self.control()?;
        let mover = c.position().turn;""",
)
alpha = once(
    alpha,
    "        result.map(|v| -v)\n    }",
    """        let result = result.map(|v| -v);
        #[cfg(feature = "research-diagnostics")]
        if OBSERVE && let Some(o) = self.lmr_observation.as_deref_mut() {
            o.child_return(c, &self.path, ply - 1, action, &result);
        }
        result
    }""",
)
needle = """            let reduction = if self.lmr
                && moves
                    .as_ref()
                    .is_some_and(|moves| self.lmr_allowed(action, depth, i, alpha, tt_move, moves))
            {"""
alpha = once(
    alpha,
    needle,
    """            let eligible = self.lmr && moves.as_ref()
                .is_some_and(|moves| self.lmr_allowed(action, depth, i, alpha, tt_move, moves));
            let reduction = if eligible {""",
)
alpha = once(
    alpha,
    "            let reduced = reduction > 0;",
    """            #[cfg(feature = "research-diagnostics")]
            if OBSERVE && eligible && let Some(o) = self.lmr_observation.as_deref_mut() {
                let tt = hit.map(|(stored_depth, _, bound, _, context_matches)| LmrTtFacts {
                    stored_depth, bound: match bound {
                        Bound::Exact => "Exact", Bound::Lower => "Lower", Bound::Upper => "Upper",
                        Bound::ApproxLeaf => "ApproxLeaf", Bound::SafeRaceLeaf => "SafeRaceLeaf",
                    },
                    context_matches, usable_depth: tt_move.is_some() && context_matches && stored_depth == depth,
                    legal_move: tt_move,
                });
                o.begin(c, &self.path, LmrBranchFacts {
                    hypothesis: "", iteration_depth: 0, visit: 0, parent_depth: depth,
                    parent_ply: ply, parent_stm: c.position().turn, distinct_rank: i + 1,
                    action, quantum: reduction, alpha_beta_bits: [alpha.to_bits(), beta.to_bits()], tt,
                });
            }
            let reduced = reduction > 0;""",
)
alpha = once(
    alpha,
    """            if let Some(work) = node_work.as_mut() {
                work.returned(&mut self.stats.ordering);
            }
            if let Some(actions) = returned.as_mut() {""",
    """            #[cfg(feature = "research-diagnostics")]
            if OBSERVE && let Some(o) = self.lmr_observation.as_deref_mut() {
                o.frames[ply] = None;
            }
            if let Some(work) = node_work.as_mut() {
                work.returned(&mut self.stats.ordering);
            }
            if let Some(actions) = returned.as_mut() {""",
)
# One concrete invocation type keeps setup and cleanup in their existing owner.
alpha = once(
    alpha,
    "fn search_in_table(\n",
    """struct SearchInvocation<'a> {
    on_completed: &'a mut dyn FnMut(&SearchResult),
    #[cfg(feature = "research-diagnostics")]
    observation: Option<&'a mut LmrObservation>,
    #[cfg(feature = "research-diagnostics")]
    cold: Option<lmr_observation416::ColdScout<'a>>,
}
impl<'a> SearchInvocation<'a> {
    fn root(on_completed: &'a mut dyn FnMut(&SearchResult)) -> Self {
        Self { on_completed,
            #[cfg(feature = "research-diagnostics")] observation: None,
            #[cfg(feature = "research-diagnostics")] cold: None,
        }
    }
}

fn search_in_table<const OBSERVE: bool>(
""",
)
alpha = once(
    alpha,
    """    on_completed: &mut dyn FnMut(&SearchResult),
    table_and_domain: SearchTableAndDomain<'_, '_>,""",
    """    invocation: SearchInvocation<'_>,
    table_and_domain: SearchTableAndDomain<'_, '_>,""",
)
alpha = alpha.replace("    search_in_table(\n", "    search_in_table::<false>(\n")
alpha = alpha.replace(
    "let r = search_in_table(\n", "let r = search_in_table::<false>(\n"
)
alpha = alpha.replace(
    "&mut |_| cancel.store(true, Ordering::Relaxed),\n            (",
    "SearchInvocation::root(&mut |_| cancel.store(true, Ordering::Relaxed)),\n            (",
)
alpha = alpha.replace(
    "            on_completed,\n            (",
    "            SearchInvocation::root(on_completed),\n            (",
)
alpha = alpha.replace(
    "        on_completed,\n        (",
    "        SearchInvocation::root(on_completed),\n        (",
)
# The only existing direct test call uses an inline completion closure.
alpha = alpha.replace(
    "            &mut |_| {},\n            (",
    "            SearchInvocation::root(&mut |_| {}),\n            (",
)
alpha = alpha.replace(
    "    let mut state = Search::<false> {",
    "    let mut state = Search::<OBSERVE> {",
    1,
)
alpha = once(
    alpha,
    """        lmr_observation: None,
    };
    let mut result = SearchResult""",
    """        lmr_observation: invocation.observation,
    };
    #[cfg(feature = "research-diagnostics")]
    if let Some(cold) = &invocation.cold { state.path.extend_from_slice(cold.path); }
    let mut result = SearchResult""",
)
alpha = once(
    alpha,
    """        for depth in 1..=limits.max_depth {
            state.table.next_generation();""",
    """        #[cfg(feature = "research-diagnostics")]
        if let Some(cold) = &invocation.cold {
            // Exactly one internal child/scout; no parent/root iteration or confirmation.
            cold.child_called.set(true);
            let value = state.child(&mut c, a.as_ref(), cold.action, cold.depth,
                [cold.alpha, next_up(cold.alpha)], cold.parent_ply + 1)?;
            state.control()?;
            result.action = Some(cold.action);
            result.value = Some(value);
            result.completed_depth = cold.depth;
            result.pv = vec![cold.action];
            return Ok(());
        }
        for depth in 1..=limits.max_depth {
            #[cfg(feature = "research-diagnostics")]
            if OBSERVE && let Some(o) = state.lmr_observation.as_deref_mut() { o.iteration = depth; }
            state.table.next_generation();""",
)
alpha = once(
    alpha,
    "            on_completed(&result);",
    "            (invocation.on_completed)(&result);",
)
alpha = once(
    alpha,
    "        || !state.path.is_empty()\n",
    """        || {
            #[cfg(feature = "research-diagnostics")]
            { if let Some(cold) = &invocation.cold { state.path != cold.path } else { !state.path.is_empty() } }
            #[cfg(not(feature = "research-diagnostics"))]
            { !state.path.is_empty() }
        }
""",
)
alpha = once(
    alpha,
    """    if result.completed_depth > 0
        && let Some(history)""",
    """    let ordinary_root = {
        #[cfg(feature = "research-diagnostics")] { invocation.cold.is_none() }
        #[cfg(not(feature = "research-diagnostics"))] { true }
    };
    if ordinary_root && result.completed_depth > 0
        && let Some(history)""",
)
write(AI, alpha)
module = (HERE / "draft-module.rs").read_text()
write(
    AI.with_name("lmr_observation416.rs"),
    module + "\n" + (HERE / "tests416.rs").read_text(),
)
print("private alpha/module draft generated; no Rust executed")
