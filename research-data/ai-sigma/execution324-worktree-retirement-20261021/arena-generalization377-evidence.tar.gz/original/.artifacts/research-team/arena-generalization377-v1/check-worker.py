"""Finite source/NN0 checks through maintained CycleResources/execute/Capture."""

import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
loader = importlib.util.spec_from_file_location(
    "arena377_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
OUT = HERE / sys.argv[1]
OUT.mkdir()
TMP = OUT / "TMP"
TMP.mkdir()
env = {
    **os.environ,
    "CUDA_VISIBLE_DEVICES": "",
    "PYTHONDONTWRITEBYTECODE": "1",
    "OMP_NUM_THREADS": "1",
    "TMPDIR": str(TMP),
    "RUFF_CACHE_DIR": str(OUT / "ruff-cache"),
    "NODE_OPTIONS": "--max-old-space-size=128",
}
spec = {
    "kind": "software",
    "owner": str(HERE),
    "cwd": str(ROOT),
    "output": str(OUT),
    "TMP": str(TMP),
    "env": env,
    "limits": {
        "family_B": 512 * 1024**2,
        "controller_B": 64 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "owned_B": None,
        "log_B": 2 * 1024**2,
        "worker_cpu": 3,
        "guardian_cpu": 4,
    },
    "command_timeout_seconds": 120,
}
checks = json.loads((HERE / "commands.json").read_text())
result = {"status": "ATTEMPTED", "checks": [], "primary": None}
affinity = os.sched_getaffinity(0)
try:
    with lc.lease(), lc.process.cancellation_signals():
        lc.physical_and_quiet(spec)
        for name, argv in checks:
            resources = lc.process.CycleResources(
                {
                    "max_memory_bytes": 512 * 1024**2,
                    "host_ram_reserve": 4 * 1024**3,
                    "max_output_bytes": None,
                },
                OUT,
                time.monotonic() + 120,
            )
            record = lc.command(
                spec,
                {
                    "name": name,
                    "argv": [sys.executable if a == "@PYTHON@" else a for a in argv],
                    "role": "software",
                },
                OUT,
                resources,
                ledger=result["checks"],
            )
        result["status"] = "PASS"
except BaseException as error:
    result["status"] = "FAILED"
    result["primary"] = lc.error_fact(error)
finally:
    os.sched_setaffinity(0, affinity)
    remaining = list(TMP.iterdir())
    if not remaining:
        TMP.rmdir()
    result.update(
        reader_STOP=lc.stamp(),
        TMP_remaining=[str(p) for p in remaining],
        original_affinity=sorted(affinity),
        restored_affinity=sorted(os.sched_getaffinity(0)),
    )
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            "status": result["status"],
            "checks": [
                {"name": c["name"], "status": c["status"]} for c in result["checks"]
            ],
            "primary": result["primary"],
            "reader_STOP": result["reader_STOP"],
        }
    )
)
raise SystemExit(0 if result["status"] == "PASS" else 1)
