"""Format only owned lifecycle function bodies; preserve unrelated source bytes."""

import ast
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / "scripts/dev/research-lifecycle.py"
NAMES = {
    "arena_model_check",
    "arena_decision_plan_check",
    "arena_plan_check",
    "planned_game_slice",
    "diagnostic_proposal",
    "interval_tail",
    "arena_analysis_check",
    "arena_score_tables",
    "arena_analysis",
    "collect_data",
}
source = SOURCE.read_text()
lines = source.splitlines(keepends=True)
nodes = [
    n
    for n in ast.parse(source).body
    if isinstance(n, ast.FunctionDef) and n.name in NAMES
]
fragment = HERE / "owned-format-fragment.py"
fragment.write_text(
    "\n\n\n".join("".join(lines[n.lineno - 1 : n.end_lineno]) for n in nodes) + "\n"
)
try:
    subprocess.run(
        [sys.executable, "-B", "-m", "ruff", "format", "--no-cache", str(fragment)],
        check=True,
    )
    formatted = fragment.read_text().splitlines(keepends=True)
    replacements = {
        n.name: "".join(formatted[n.lineno - 1 : n.end_lineno])
        for n in ast.parse("".join(formatted)).body
        if isinstance(n, ast.FunctionDef)
    }
    for node in sorted(nodes, key=lambda n: n.lineno, reverse=True):
        lines[node.lineno - 1 : node.end_lineno] = replacements[node.name].splitlines(
            keepends=True
        )
    value = "".join(lines)
    before = {
        n.name: ast.dump(n, include_attributes=False)
        for n in ast.parse(source).body
        if isinstance(n, (ast.FunctionDef, ast.ClassDef))
    }
    after = {
        n.name: ast.dump(n, include_attributes=False)
        for n in ast.parse(value).body
        if isinstance(n, (ast.FunctionDef, ast.ClassDef))
    }
    assert before == after
    SOURCE.write_text(value)
    print("Scoped lifecycle format/AST equality PASS; unrelated bytes retained")
finally:
    fragment.unlink(missing_ok=True)
