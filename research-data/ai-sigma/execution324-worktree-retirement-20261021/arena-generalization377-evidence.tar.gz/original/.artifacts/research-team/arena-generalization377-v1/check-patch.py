"""Verify the selected source patch and inverse against their exact Git base."""

import ast
import difflib
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
record = json.loads((HERE / "source-map.json").read_text())
env = {**os.environ, "GIT_OPTIONAL_LOCKS": "0"}
before = {}
after = {}
for ref in record["changed_paths"]:
    path = Path(ref["path"]).relative_to(ROOT)
    before[path] = (
        subprocess.check_output(
            ["git", "show", f"{record['base']}:{path}"], cwd=ROOT, env=env
        )
        if ref["before_sha256"] is not None
        else None
    )
    after[path] = (ROOT / path).read_bytes()

forward = []
inverse = []
for path in before:
    old = before[path]
    new = after[path]
    forward.extend(
        difflib.unified_diff(
            [] if old is None else old.decode().splitlines(keepends=True),
            new.decode().splitlines(keepends=True),
            fromfile="/dev/null" if old is None else f"a/{path}",
            tofile=f"b/{path}",
        )
    )
    inverse.extend(
        difflib.unified_diff(
            new.decode().splitlines(keepends=True),
            [] if old is None else old.decode().splitlines(keepends=True),
            fromfile=f"a/{path}",
            tofile="/dev/null" if old is None else f"b/{path}",
        )
    )
assert (HERE / "source.patch").read_text() == "".join(forward)
assert (HERE / "source.inverse.patch").read_text() == "".join(inverse)

path = Path("scripts/dev/research-lifecycle.py")
old_nodes = {
    node.name: ast.dump(node, include_attributes=False)
    for node in ast.parse(before[path]).body
    if isinstance(node, (ast.FunctionDef, ast.ClassDef))
}
new_nodes = {
    node.name: ast.dump(node, include_attributes=False)
    for node in ast.parse(after[path]).body
    if isinstance(node, (ast.FunctionDef, ast.ClassDef))
}
for name in record["protected_lifecycle_top_level_AST"]:
    assert old_nodes[name] == new_nodes[name], name

with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as scratch:
    tree = Path(scratch)
    for path, data in before.items():
        if data is not None:
            target = tree / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    for patch, expected in (("source.patch", after), ("source.inverse.patch", before)):
        output = subprocess.check_output(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "--no-backup-if-mismatch",
                "--remove-empty-files",
                "-p1",
                "-d",
                str(tree),
                "-i",
                str(HERE / patch),
            ],
            stderr=subprocess.STDOUT,
            text=True,
        )
        print(output, end="")
        assert "offset" not in output and "fuzz" not in output
        for path, data in expected.items():
            target = tree / path
            if data is None:
                assert not target.exists(), path
            else:
                assert target.read_bytes() == data, path
print(
    "Exact forward/inverse, zero fuzz/offset, protected owner AST and TMP cleanup PASS"
)
