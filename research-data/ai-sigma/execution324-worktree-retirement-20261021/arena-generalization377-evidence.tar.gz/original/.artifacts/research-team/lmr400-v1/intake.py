"""One finite named LMR/fixed-D Cheap current source intake, no native."""

import gzip
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import stat

ROOT = Path("/workspaces/quoridor")
OWN = Path.cwd()
HERE = Path(__file__).resolve().parent
paths = [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-ai/src/cheap_static_ordering.rs",
    "crates/quoridor-ai/src/cheap376_tests.rs",
    "crates/quoridor-ai/src/lib.rs",
    "crates/quoridor-runner/src/measurement.rs",
]
refs = []
for i, relative in enumerate(paths):
    path = ROOT / relative
    raw = path.read_bytes()
    target = OWN / relative
    if target.exists():
        (HERE / f"{i}.OWN-before.gz").write_bytes(
            gzip.compress(target.read_bytes(), mtime=0)
        )
    (HERE / f"{i}.Main-before.gz").write_bytes(gzip.compress(raw, mtime=0))
    target.write_bytes(raw)
    refs.append(
        {
            "relative": relative,
            "before": {
                "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
            },
        }
    )
spec = importlib.util.spec_from_file_location(
    "lmr400_source_intake", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lc)
function = lc.measurement_config
path = Path(inspect.getsourcefile(function))
raw = path.read_bytes()
source = inspect.getsource(function)
(HERE / "measurement_config.before.py").write_text(source)
refs.append(
    {
        "relative": str(path.relative_to(ROOT)),
        "owner": "measurement_config ONLY/Root composition",
        "before": {
            "path": str(path),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
        },
        "function_before_sha256": hashlib.sha256(source.encode()).hexdigest(),
    }
)
new = "crates/quoridor-ai/src/lmr400_tests.rs"
assert not (ROOT / new).exists() and not (OWN / new).exists()
(HERE / "current-intake.json").write_text(
    json.dumps(
        {
            "refs": refs,
            "new_test_before": "ABSENT",
            "Main_Git_index_Cargo_native_model_Search_Perf_writes_calls": 0,
        },
        indent=2,
    )
    + "\n"
)
print(
    "Five named current Rust subjects + minimum measurement_config function captured; prior OWN preserved; no native/science"
)
