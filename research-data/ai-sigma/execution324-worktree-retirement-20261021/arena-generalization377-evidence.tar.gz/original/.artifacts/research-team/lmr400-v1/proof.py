"""Exact source patch/inverse and protected scopes; no native/type/test execution."""

import ast
import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
OWN = Path.cwd()
ROOT = Path("/workspaces/quoridor")
intake = json.loads((HERE / "current-intake.json").read_text())
support = json.loads((HERE / "support-intake.json").read_text())
indexed = [(i, item) for i, item in enumerate(intake["refs"][:5]) if i != 3] + list(
    enumerate(support["refs"], 5)
)
before = {
    item["relative"]: gzip.decompress((HERE / f"{i}.Main-before.gz").read_bytes())
    for i, item in indexed
}
new = "crates/quoridor-ai/src/lmr400_tests.rs"
before[new] = b""
after = {name: (OWN / name).read_bytes() for name in before}
# One necessary real Python owning function, captured transiently under this
# source guard. Its surrounding source is neither copied nor owned by author.
python = intake["refs"][-1]
raw = (ROOT / python["relative"]).read_bytes()
assert hashlib.sha256(raw).hexdigest() == python["before"]["sha256"]
old_function = (HERE / "measurement_config.before.py").read_bytes()
new_function = (HERE / "measurement_config.after.py").read_bytes()
assert raw.count(old_function) == 1
assert len(ast.parse(new_function).body) == 1 and isinstance(
    ast.parse(new_function).body[0], ast.FunctionDef
)
before[python["relative"]] = raw
after[python["relative"]] = raw.replace(old_function, new_function, 1)


def patch(left, right):
    return "".join(
        "".join(
            difflib.unified_diff(
                left[name].decode().splitlines(True),
                right[name].decode().splitlines(True),
                "/dev/null" if not left[name] else "a/" + name,
                "/dev/null" if not right[name] else "b/" + name,
            )
        )
        for name in left
    )


(HERE / "lmr400.patch").write_text(patch(before, after))
(HERE / "lmr400.inverse.patch").write_text(patch(after, before))
tmp = Path(os.environ["TMPDIR"]) / "roundtrip"
tmp.mkdir()
try:
    for name, data in before.items():
        if data:
            target = tmp / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    for label, left, right in [("forward", before, after), ("inverse", after, before)]:
        result = subprocess.run(
            ["/usr/bin/patch", "--batch", "--fuzz=0", "--no-backup-if-mismatch", "-p1"],
            input=patch(left, right),
            text=True,
            cwd=tmp,
            capture_output=True,
            timeout=120,
            check=True,
        )
        assert "offset" not in result.stdout and "fuzz" not in result.stdout
        for name, data in right.items():
            path = tmp / name
            assert path.read_bytes() == data if data else not path.exists()
        print(label, "exact GNU patch/nooffset/nofuzz/newabsence PASS")
finally:
    shutil.rmtree(tmp)


def method(raw, name):
    text = raw.decode()
    start = text.index("    fn " + name + "(")
    end = re.search(r"\n    (?:fn |#\[)", text[start + 5 :])
    assert end
    return text[start : start + 5 + end.start()]


protected = {}
alpha = "crates/quoridor-ai/src/alphabeta.rs"
for name in ["control", "enter", "child", "root_depth"]:
    old = method(before[alpha], name)
    current = method(after[alpha], name)
    assert old == current, name
    protected[name] = hashlib.sha256(current.encode()).hexdigest()
old = before[alpha].decode()
current = after[alpha].decode()
eval_start = "pub type Result<T>"
eval_end = "#[derive(Debug, Clone)]\npub struct SearchLimits"
assert (
    old[old.index(eval_start) : old.index(eval_end)]
    == current[current.index(eval_start) : current.index(eval_end)]
)
protected["evaluation_models_score_domains_scratch_and_forward_math"] = hashlib.sha256(
    old[old.index(eval_start) : old.index(eval_end)].encode()
).hexdigest()
tt_start = "// Compact359-v1:"
tt_end = "#[cfg_attr(test, derive(Debug))]\nenum Interrupted"
assert (
    old[old.index(tt_start) : old.index(tt_end)]
    == current[current.index(tt_start) : current.index(tt_end)]
)
protected["TT_key_history_fingerprint_depth_bound_capacity_replacement_generation"] = (
    hashlib.sha256(old[old.index(tt_start) : old.index(tt_end)].encode()).hexdigest()
)
old_node = method(before[alpha], "negamax")
new_node = method(after[alpha], "negamax")
for name, start, end in [
    (
        "terminal_legal_TT_numeric_and_order_only",
        None,
        "        let mut deferred = None;",
    ),
    (
        "single_return_parent_cutoff_history_and_TT_publication",
        "            if let Some(work) = node_work.as_mut() {\n                work.returned",
        "\n        Ok(value)",
    ),
]:
    a = (
        old_node[: old_node.index(end)]
        if start is None
        else old_node[old_node.index(start) : old_node.index(end)]
    )
    b = (
        new_node[: new_node.index(end)]
        if start is None
        else new_node[new_node.index(start) : new_node.index(end)]
    )
    assert a == b, name
    protected[name] = hashlib.sha256(a.encode()).hexdigest()
cheap = "crates/quoridor-ai/src/cheap_static_ordering.rs"
for name in ["validate_maps", "blocked_edges", "directly_blocks"]:
    # Top-level functions end at the next top-level fn/pub/attribute.
    def top(raw):
        t = raw.decode()
        first = t.index("fn " + name + "(")
        end = re.search(r"\n(?:fn |pub\(super\) fn |#\[)", t[first + 3 :])
        assert end
        return t[first : first + 3 + end.start()]

    assert top(before[cheap]) == top(after[cheap]), name
    protected[name] = hashlib.sha256(top(before[cheap]).encode()).hexdigest()
history = "crates/quoridor-ai/src/continuation_history.rs"
original = (
    before[history]
    .decode()
    .replace('#[cfg(feature = "research-diagnostics")]\n', "", 1)
)
assert after[history].decode() == original
protected["continuation_history_only_OrderingProfile_cfg_removed"] = True
lib = intake["refs"][3]
assert (OWN / lib["relative"]).read_bytes() == gzip.decompress(
    (HERE / "3.Main-before.gz").read_bytes()
)
protected["public_lib_and_other_algorithms_unchanged"] = lib["before"]
subjects = []
for name, data in after.items():
    path = OWN / name
    actual_data = new_function if name == python["relative"] else data
    subjects.append(
        {
            "relative": name,
            "owner": "measurement_config function only/Root composition"
            if name == python["relative"]
            else "OWN managed source",
            "before": "ABSENT"
            if not before[name]
            else {
                "sha256": hashlib.sha256(before[name]).hexdigest(),
                "bytes": len(before[name]),
            },
            "after": {
                "path": str(HERE / "measurement_config.after.py")
                if name == python["relative"]
                else str(path),
                "sha256": hashlib.sha256(actual_data).hexdigest(),
                "bytes": len(actual_data),
                "mode": "0644",
                "hash_scope": "actual function derivative file only"
                if name == python["relative"]
                else "full file",
            },
        }
    )
    if name == python["relative"]:
        subjects[-1]["composed_expected"] = {
            "relative": name,
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
            "scope": "prospective full subject/NOT existing FileRef, only function patch owned",
        }
new_tests = []
for name in [
    new,
    "crates/quoridor-ai/src/cheap376_tests.rs",
    "crates/quoridor-runner/src/measurement.rs",
]:
    new_tests.extend(
        re.findall(
            r"#\[test\]\s*fn ((?:lmr400_|cheap400_|measurement400_)[a-z0-9_]+)",
            after[name].decode(),
        )
    )
assert len(new_tests) == 10, new_tests
python_test = HERE / "measurement_config400_tests.py"
ast.parse(python_test.read_text())
result = {
    "status": "STATIC_EXACT_SOURCE_PASS",
    "subjects": subjects,
    "protected": protected,
    "new_tests": new_tests,
    "new_count": len(new_tests),
    "Python_test_definition": {
        "path": str(python_test),
        "name": "LmrMeasurementConfig400Tests.test_optional_boolean_and_pvs_profile_boundaries",
        "sha256": hashlib.sha256(python_test.read_bytes()).hexdigest(),
        "bytes": python_test.stat().st_size,
        "mode": "0644",
        "status": "UNIMPORTED/UNRUN, AST/Ruff syntax only",
    },
    "affected_existing": [
        "cheap376_exact_integer_terms_orientations_colours_missing_and_borrowed_maps",
        "fixed_d392_binding_allows_only_exact_empty_model_d_and_preserves_nnue_binding",
    ],
    "new_native_type_tests": "UNBUILT/UNTYPED/UNRUN",
    "Python": "measurement_config single function AST/range source only, NOT imported/tested",
    "Main_Git_index_Cargo_native_Search_model_Perf_calls_writes": 0,
}
(HERE / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    "Protected originalTT/core/history/child/root andclaimedcachevalidation exact; new10+affected2 definitions UNRUN"
)
