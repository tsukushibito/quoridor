"""Stopped source receipts and one actual directed affected usage observation."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import stat

os.sched_setaffinity(0, {3})
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
HERE = Path(__file__).resolve().parent
OWN = Path.cwd()


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
phases = []
children = []
for name in [
    "intake-v1",
    "intake-v2",
    "static-v1",
    "static-v2",
    "static-v3",
    "final-v1",
    "final-format-v1",
]:
    path = HERE / name / "result.json"
    phase = json.loads(path.read_text())
    assert not phase["TMP_remaining"] and not (HERE / name / "TMP").exists()
    phases.append(
        {
            "ref": ref(path),
            "status": phase["status"],
            "reader_STOP": phase["reader_STOP"],
            "primary": phase["primary"],
        }
    )
    for command in phase["checks"]:
        returned = command.get("guardian_return")
        if not returned or not returned.get("child"):
            continue
        original = returned["child"]
        proc = Path(f"/proc/{original['pid']}/stat")
        fresh = None
        if proc.exists():
            fields = proc.read_text().rsplit(")", 1)[1].split()
            fresh = {"pid": original["pid"], "start_ticks": fields[19], "boot_id": boot}
        assert fresh != original
        assert (
            returned["direct_child_reaped"]
            and not returned["remaining"]
            and returned["cleanup_complete"]
            and returned["handle_closes_complete"]
        )
        assert command["capture_complete"]
        disk_ref = command["persisted_process_receipt"]
        disk_path = Path(disk_ref["path"])
        assert ref(disk_path) == disk_ref
        disk = json.loads(disk_path.read_text())
        children.append(
            {
                "phase": name,
                "command": command["name"],
                "original": original,
                "fresh": fresh,
                "status": "absent" if fresh is None else "different",
                "directwait_exit": returned["exit_code"],
                "direct_reaped": True,
                "handles_complete": True,
                "cleanup_complete": True,
                "fullcapture": command["full_log"],
                "persisted_receipt": disk_ref,
                "returned_mask": returned.get("signal_mask_restoration"),
                "original_disk_mask": disk.get("signal_mask_restoration"),
                "returned_persist": returned.get("final_record_persist"),
                "original_disk_persist": disk.get("final_record_persist"),
                "launch_policy": returned.get("launch_policy"),
                "ordinary_seconds": returned["wall_seconds"],
            }
        )
proof = json.loads((HERE / "static-proof.json").read_text())
assert proof["status"] == "STATIC_EXACT_SOURCE_PASS"
for subject in proof["subjects"]:
    actual = ref(Path(subject["after"]["path"]))
    assert all(actual[k] == subject["after"][k] for k in actual)
actual_test = ref(Path(proof["Python_test_definition"]["path"]))
assert all(actual_test[k] == proof["Python_test_definition"][k] for k in actual_test)
selected = [
    "lmr400.patch",
    "lmr400.inverse.patch",
    "static-proof.json",
    "report-ja.md",
    "current-intake.json",
    "support-intake.json",
    "measurement_config.before.py",
    "measurement_config.after.py",
    "measurement_config400_tests.py",
    "api-peer-send.json",
]
refs = {name: ref(HERE / name) for name in selected}
for i in range(8):
    refs[f"{i}.Main-before.gz"] = ref(HERE / f"{i}.Main-before.gz")
assert json.loads((HERE / "api-peer-send.json").read_text())["accepted"]
seen = set()
allocated = 0
logical = 0
files = 0
for root in [
    HERE,
    *[
        Path(s["after"]["path"])
        for s in proof["subjects"]
        if s["owner"] == "OWN managed source"
    ],
]:
    for path in [root] if root.is_file() else [root, *root.rglob("*")]:
        info = path.lstat()
        assert not stat.S_ISLNK(info.st_mode)
        key = (info.st_dev, info.st_ino)
        if key in seen:
            continue
        seen.add(key)
        allocated += info.st_blocks * 512
        if stat.S_ISREG(info.st_mode):
            logical += info.st_size
            files += 1
fs = os.statvfs(HERE)
available = fs.f_bavail * fs.f_frsize
assert available >= 4 * 1024**3
result = {
    "status": "STOPPED_LMR400_SOURCE_STATIC_CLEAR_NATIVE_SCIENCE_PENDING",
    "issue": "quoridor-4lc.400.1",
    "claimant": "codex:01a11004-79f3-7c20-872c-432a2c347664",
    "context": {
        "turn": "01a13ac7-a83f-7861-a82d-a7c78b2f44e0",
        "cwd": str(OWN),
        "model": "gpt-6.1-sol",
        "effort": "high",
        "sandbox": "danger-full-access",
        "approvalPolicy": "never",
        "verified_before_first_command": True,
    },
    "source_reader_STOP": phases[-1]["reader_STOP"],
    "source_metadata_stamp": datetime.now(timezone.utc).isoformat(),
    "canonical_common_env_release": "normal helper/lease/project-env wrapper return, independent UTC UNKNOWN",
    "owned_readers": [],
    "owned_writers": [],
    "owned_children": [],
    "owned_jobs": [],
    "owned_handles": [],
    "owned_TMP": [],
    "owned_leases": [],
    "metadata_scope": "Source guarded commands have directwaited; this small receipt write then exit, admin/Beads/send afterward only",
    "phases": phases,
    "original_children": children,
    "fast_nested_patch_Node_children": "not separately identified; bounded original guardian/session descendants; exact fast PID UNKNOWN, direct subprocess waits and temporary cleanup source-proved",
    "refs": refs,
    "subjects": proof["subjects"],
    "protected": proof["protected"],
    "new_Rust_tests": proof["new_tests"],
    "new_Rust_count": 10,
    "new_Python_test": proof["Python_test_definition"],
    "affected_existing_tests": proof["affected_existing"],
    "software_status": "Rust UNBUILT/UNTYPED/UNRUN; Python case UNIMPORTED/UNRUN, formatter/AST only",
    "API": "existing two OrderingProfile factory under research + set_lmr(bool)->Result/lmr_enabled(); defaults OFF",
    "method": "factory :control/:cheap; ON adds :lmr400-late4-depth3-minus1-pvs-verify-v1; TT/history clear at mode switch/reset",
    "rule": "internal depth>=3, distinct legal index>=3, minus1 child ply, PVS/no-policy/signed Control/Cheap; TT/goal/killer excluded; shallow alpha-high requires normal-depth scout before existing fullwindow",
    "bound_semantics": "LMR nominal completed/TT parent depth is selective, NOT full-width minimax proof; reduced child entry stores actual depth; fail-low can miss deeper value",
    "scalars": "three started-call counters only: attempts/normal-depth confirmation/fullwindow research; partial/error NOT success",
    "Cheap": "None -> existing canonical parent map pair, same validation/coefficients; genuine cached hit kept; Control goals_only no extra BFS",
    "Python_owner": "actual research-lifecycle.py::measurement_config physical path; function-only derivative/patch, virtual composed expected hash NOT existing FileRef; no publisher/Main write",
    "Peer": "400.2 informed once accepted; arena functions/runtime/config writer separate, no AI duplication or peer-completion gate",
    "Root_remaining": "research + research-diagnostics compile, newRust10 + affected2 + newconfigNN0one, affectedClippy/release/genuineN, ONE narrow LMR/namespace/history/error/Cheap/strength uncertainty review; Root-only approved cost96/48sessions288M + arena128games64pairs, not author entry",
    "Main_Git_index_Cargo_native_model_Search_Perf_game_fit_writes_calls": 0,
    "pause": "mixed/learner sourceprep/wholepipeline/256 and323USERPAUSE, defaults/models/seals/oldfits96/RAWFAILEDfeesUNKNOWN unchanged",
    "usage": {
        "scope": "OWN400 evidence/original beforegzips/FAILED captures plus eight changed Rust source subjects; one inode-dedup directed postwork before finalreceipt/admin",
        "storage_budget": None,
        "allocated_B": allocated,
        "regular_logical_B": logical,
        "files": files,
        "actual_FS_available_B": available,
        "FS_reserve_B": 4 * 1024**3,
        "whole_global_actual": "UNKNOWN",
        "continuous_peak": "UNKNOWN",
        "global_decimal_cap_B": 50_000_000_000,
    },
}
(HERE / "source-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
stop = ref(HERE / "source-STOP.json")
(HERE / "handoff.txt").write_text(
    "400.1 ONE frozen sourceSTOP "
    + json.dumps(stop)
    + "\n"
    + "LMR defaultOFF existingControl/Cheap + fixedD Cheap parentmaps. Strictpatch/inverse/newabsence/protectedTT/fullhistory/child/root/eval/validation PASS, newRust10+affected2 and newPythonNN0one UNBUILT/UNTYPED/UNRUN/UNIMPORTED. Source-only no native/Search/model/Perf/Cargo. API/method shared400.2 once accepted, SourceRoot/arena scopes disjoint. Python actual owner is research-lifecycle.py::measurement_config only, function sparse notwholepublisher.\n"
    + "Lastsource readerSTOP "
    + phases[-1]["reader_STOP"]
    + ", originalchildren freshabsent/different/directwait/reap/handles/fullcaptures/TMPgone/owned[]; returnedvsoriginaldisk masks separate; static-v1 helpermarkerFAILED and static-v3 finalassertformatFAILED originalscopes retained, corrected source checks PASS. Oneaffectedusage "
    + str(allocated)
    + " allocatedB budgetNone before receipt/admin, globalactual/peakUNKNOWN.\n"
    + "Root genuine software/image + one narrow selectiveLMR/method/TT/history/undo/Cheap/strength review, then alreadyapprovedcost96/arena128 ONLY; no fabricatedN/configrefs/sourceclear->speedadoption/no newcalls/refill/sweep. Leafin_progress untilacceptance. Mixed/learner/323pause andoriginalRAWFAILEDfeesUNKNOWN/defaults/models/seals held. Routinecurrent324only/noACK.\n"
)
print(
    json.dumps(
        {
            "source_STOP": stop,
            "owned": [],
            "allocated_B": allocated,
            "new_Rust": 10,
            "new_Python": 1,
            "native": "UNBUILT/UNTYPED/UNRUN",
        }
    )
)
