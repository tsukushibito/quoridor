"""Three necessary owning ranking/history/test scaffolding subjects only."""

import gzip
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path("/workspaces/quoridor")
HERE = Path(__file__).resolve().parent
refs = []
for i, relative in enumerate(
    [
        "crates/quoridor-ai/src/move_ordering.rs",
        "crates/quoridor-ai/src/continuation_history.rs",
        "crates/quoridor-ai/src/continuation360_tests.rs",
    ],
    start=5,
):
    p = ROOT / relative
    raw = p.read_bytes()
    own = Path.cwd() / relative
    (HERE / f"{i}.OWN-before.gz").write_bytes(gzip.compress(own.read_bytes(), mtime=0))
    (HERE / f"{i}.Main-before.gz").write_bytes(gzip.compress(raw, mtime=0))
    own.write_bytes(raw)
    refs.append(
        {
            "relative": relative,
            "before": {
                "path": str(p),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": format(stat.S_IMODE(p.stat().st_mode), "04o"),
            },
        }
    )
(HERE / "support-intake.json").write_text(
    json.dumps({"refs": refs, "Main_writes": 0, "native_calls": 0}, indent=2) + "\n"
)
print(
    "Three required current ranking/profile/test-scaffold subjects captured; private prior bytes preserved"
)
