"""Read only named immutable owners for the fixed 419 observation design."""

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
COMMIT = "61d783d1882bb02e8617cdbe42c1fce24cda8e9b"
PATHS = (
    "crates/quoridor-runner/src/value_search_compare.rs",
    "crates/quoridor-runner/src/bin/nnue-diagnose.rs",
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-core/src/position.rs",
)
RANGES = {
    "crates/quoridor-runner/src/value_search_compare.rs": [
        (1, 57),
        (85, 130),
        (211, 318),
        (357, 447),
        (596, 684),
    ],
    "crates/quoridor-runner/src/bin/nnue-diagnose.rs": [(1, 25), (490, 600)],
    "crates/quoridor-ai/src/alphabeta.rs": [(1, 39), (759, 775), (2869, 2891)],
    "crates/quoridor-core/src/position.rs": [(231, 273), (313, 358)],
}
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
children = []


def identity(pid):
    try:
        start = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
        return {"pid": pid, "start_ticks": start, "boot_id": BOOT}
    except FileNotFoundError:
        return None


def git(arguments):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_PAGER="cat")
    p = subprocess.Popen(
        ["git", "--no-pager", "--no-replace-objects", *arguments],
        cwd="/workspaces/quoridor",
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    original = identity(p.pid)
    stdout, stderr = p.communicate(timeout=15)
    now = identity(p.pid)
    children.append(
        {
            "original": original,
            "returncode": p.returncode,
            "directwait_reaped": True,
            "handles_closed": p.stdout.closed and p.stderr.closed,
            "fresh": "absent"
            if now is None
            else "different"
            if now != original
            else "SAME",
        }
    )
    assert p.returncode == 0, stderr.decode()
    assert now != original or now is None
    return stdout


tree = git(["ls-tree", COMMIT, "--", *PATHS]).decode().splitlines()
tree_by_path = {}
for line in tree:
    fields, path = line.split("\t")
    mode, kind, oid = fields.split()
    assert kind == "blob"
    tree_by_path[path] = {"mode": mode, "git_blob": oid}

refs = []
for path in PATHS:
    data = git(["cat-file", "blob", f"{COMMIT}:{path}"])
    assert len(data) < 1048576
    oid = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
    assert oid == tree_by_path[path]["git_blob"]
    lines = data.decode().splitlines()
    index = [
        [i, line.strip()]
        for i, line in enumerate(lines, 1)
        if re.match(r"\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+", line)
        or re.match(r"\s*(?:pub(?:\([^)]*\))?\s+)?(?:struct|enum|trait)\s+", line)
    ]
    ref = {
        "commit": COMMIT,
        "path": path,
        **tree_by_path[path],
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "lines": len(lines),
        "named_owners": index,
        "git_object_payload_matches_named_tree": True,
    }
    refs.append(ref)
    if len(sys.argv) == 1:
        print(json.dumps(ref, ensure_ascii=False))
    else:
        assert sys.argv[1] == "bodies"
        print("IMMUTABLE", path, oid, ref["sha256"])
        for first, last in RANGES[path]:
            for number in range(first, min(last, len(lines)) + 1):
                print(f"{number}: {lines[number - 1]}")

(
    ROOT
    / (
        "immutable-owner-index.json"
        if len(sys.argv) == 1
        else "immutable-owner-body-refs.json"
    )
).write_text(
    json.dumps({"refs": refs, "git_children": children}, ensure_ascii=False, indent=2)
    + "\n"
)
