"""Freeze the selected saved inputs and finite 419 design; execute no engine."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import struct

OWN = Path(__file__).resolve().parent


def load(name):
    return json.loads((OWN / name).read_text())


def save(name, value):
    (OWN / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


selected = load("selected-position-evidence.json")
raw = load("raw-selected-prefixes.json")
assert [(x["record"]["slot"], x["record"]["ply"]) for x in selected["selected"]] == [
    (4, 11),
    (4, 39),
    (5, 12),
]
parents = []
for item in selected["selected"]:
    r = item["record"]
    source = r["original_record"]
    row = next(x for x in raw["selected_rows"] if x["game"] == source["game"])
    actions = row["selected_fields"]["moves"]
    observation = next(
        x for x in row["selected_fields"]["observations"] if x["ply"] == r["ply"]
    )
    assert actions[: r["ply"]] == r["prefix_actions"]
    assert actions[r["ply"]] == r["nnue_action"]["id"] == observation["action"]
    assert observation == r["original_observation"]
    history = r["full_history"]
    assert len(history["ordered_history_keys"]) == r["ply"] + 1
    counts = Counter(history["ordered_history_keys"])
    assert counts[history["native_history_key_from_maintained_rules_view"]] == 1
    assert r["state"]["winner"] is None
    state = {
        k: r["state"][k]
        for k in (
            "schemaVersion",
            "rulesetId",
            "pawns",
            "wallsRemaining",
            "horizontalWalls",
            "verticalWalls",
            "turn",
            "winner",
            "ply",
            "positionKey",
            "researchHistoryKey",
        )
    }
    old = {
        k: observation[k]
        for k in (
            "side",
            "action",
            "accepted",
            "failure",
            "completed_depth",
            "value_stm",
            "pv",
            "stop",
            "thinking_seconds",
            "caller_seconds",
            "completed_iteration_counters",
        )
    }
    old["value_stm_f32_bits"] = struct.unpack(
        "<I", struct.pack("<f", observation["value_stm"])
    )[0]
    parent = {
        "id": f"distance-slot{r['slot']:03d}-ply{r['ply']:03d}",
        "slot": r["slot"],
        "case_index_383": r["case_index"],
        "position_index_383": r["position_index"],
        "family_id_383": r["family_id"],
        "actual_raw_family": row["selected_fields"]["family"],
        "nnue_colour": r["nnue_colour"],
        "rules": history["rules"],
        "from_prefix_actions": r["prefix_actions"],
        "source_prefix_actions_sha256": r["prefix_actions_sha256"],
        "source_position_record": item["position"]["position_record"],
        "source_raw": {
            "journal": source["files"]["journal"],
            "line_1_based": row["line_1_based"],
            "game": source["game"],
            "raw_line_sha256": source["raw_line_sha256"],
            "raw_line_bytes": source["raw_line_bytes"],
            "line_hash_convention": row["line_hash_convention"],
            "prefix_slice": [0, r["ply"]],
            "action_index_zero_based": r["ply"],
            "observation_ply": r["ply"],
        },
        "expected_maintained_rules_view": state,
        "expected_native_history_key_from_maintained_rules_view": history[
            "native_history_key_from_maintained_rules_view"
        ],
        "expected_ordered_history_keys": history["ordered_history_keys"],
        "source_ordered_history_sha256": history["ordered_history_sha256"],
        "expected_history_multiset_for_comparison_only": sorted(counts.items()),
        "expected_current_repetition_count": 1,
        "original_nnue_observation": old,
        "original_actual_continuation_first_six": actions[r["ply"] : r["ply"] + 6],
        "parent_horizons": [2, 3],
        "candidate_anchor_horizon": 3,
        "historical_candidate_action": r["nnue_action"]["id"],
        "native_full_prefix_admission": "PENDING_NORMAL_CANONICAL_REPLAY",
        "saved_byte_correspondence": "MATCH",
    }
    parents.append(parent)

inputs = {
    "issue": "quoridor-4lc.419.1",
    "kind": "fixed_saved_inputs_before_new_numerical_results",
    "parents": parents,
    "selection": {
        "rule": "exact_three_named_human_candidates_in_given_order_no_replacement",
        "new_search_or_forward_results_used": False,
        "parents": 3,
        "games": 2,
        "shared_start_families": 1,
        "independent_three_samples": False,
        "raw_streams_decoded_once": 1,
        "raw_lines_selected": 2,
        "native_chronology_certificate": False,
        "history_constructor": "SigmaContext::from_prefix",
    },
    "evaluator_bindings": {
        "N": {
            "description": "fresh353 no-output-bypass BEST43",
            "factory": "measurement::load_evaluator/ResidualModel/ResidualEvaluator",
            "descriptor": {
                "path": "/workspaces/quoridor/.worktree/assets/checkpoints/public-no-bypass-v1/candidate-v1/output/best-model/manifest.json",
                "sha256": "46ec2c4708f96dcf9fad579c2fb0d1299c6663df27412f0faac98267467715e1",
                "bytes": 677,
                "mode": "0600",
            },
            "weights_sha256": "046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841",
            "weights_bytes": 49284,
            "typed_evaluator_sha256": "96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875",
            "distance_head_input": "existing standardized D/80; retained with a=b=0",
            "simd": False,
            "model_payload_read_by_analyst": False,
        },
        "D": {
            "factory": "measurement::load_evaluator/DistanceEvaluator::new(0,8)",
            "evaluator_namespace": "original-distance-a0-b8-tanh",
            "models": [],
            "simd": False,
        },
    },
    "source_evidence_refs": selected["refs"],
}
save("fixed-inputs.json", inputs)

settings = {
    "ordering_profile": "control",
    "policy": None,
    "lmr": False,
    "cheap": False,
    "zero_stock_approx_min_root_walls": None,
    "zero_stock_safe_race": False,
    "use_pvs": True,
    "use_tt": True,
    "tt_entries": 1048576,
    "time_limit": None,
    "max_nodes_per_invocation_including_iterations": 1000000,
    "parent_horizons": [2, 3],
    "session_state": "fresh_per_unique_call; immutable loaded model may be shared",
    "score_domain": {
        "name": "LEGACY",
        "nonterminal_abs_bound": 1,
        "goal": 2,
        "draw": 0,
    },
    "goal_before_threefold_before_static": True,
}
normal_calls = [
    {
        "id": f"{p['id']}:{e}:H{h}:normal",
        "parent_id": p["id"],
        "evaluator": e,
        "parent_horizon": h,
        "kind": "normal_all_legal_root",
    }
    for p in parents
    for h in (2, 3)
    for e in ("N", "D")
]
assert len(normal_calls) == 12 and len({r["id"] for r in normal_calls}) == 12
tree_bound = 3 + 9 + 9 * 136 + 9 * 136**2
assert tree_bound == 167700 < 300000
design = {
    "issue": "quoridor-4lc.419.1",
    "state": "DESIGN_FIXED_BEFORE_NEW_NUMERICAL_RESULTS",
    "target_git_for_named_owner_read": "61d783d1882bb02e8617cdbe42c1fce24cda8e9b",
    "settings": settings,
    "normal_call_schedule": normal_calls,
    "candidate_policy": {
        "anchor_horizon": 3,
        "sources": ["historical_nnue_action", "complete_N_H3", "complete_D_H3"],
        "dedup_order": "ascending_ActionID",
        "max_per_parent": 3,
        "shared_across_horizons": [2, 3],
        "incomplete_anchor": "missing contributor; no completed_lower_depth replacement",
        "H2_action_outside_union": "record and retain fixed union",
        "new_call_for_anchor": False,
    },
    "forced_semantics": {
        "existing_owner": "SearchInvocation/iterative-deepening/Search::child",
        "fixed_action_in_parent_horizon": True,
        "child_remaining_depth": "H-1",
        "nonroot_child_ply": 1,
        "parent_window": ["-infinity", "+infinity"],
        "iterative_depths": "1..H, same invocation and cumulative node budget",
        "parent_stm_sign_inversions": 1,
        "restricted_root_is_ordinary_alllegal_TT_Exact": False,
        "child_TT_history_depth_bound_contract": "unchanged",
        "promote_child_to_fresh_root": False,
    },
    "common_tree": {
        "existing_owner": "narrow shared value_search_compare::tree semantics",
        "root_actions": "fixed union only",
        "subsequent_actions": "ALL canonical legal actions",
        "one_tree_max_parent_plies": 3,
        "static_frontier_plies_saved": [2, 3],
        "terminal_first": True,
        "TT_or_pruning_or_path_merge": False,
        "global_visits_cap": 300000,
        "safe_9x9_branch_upper": 136,
        "source_node_upper_for_three_parents": tree_bound,
        "bound_is_actual_node_count_or_runtime": False,
        "incomplete": "UNKNOWN; never omit branches or substitute static values",
        "storage": "compact parent/action records; root prefix plus path reconstructs history",
    },
    "backup": {
        "value_perspective": "local side to move",
        "operator": "max_a(-child_value)",
        "tie_set": "f32 numeric equality, signed zeros tie",
        "canonical_action": "lowest ActionID among tied legal actions",
        "ordinary_kernel_tie_order": "record actual; not assumed same",
        "exact_authority": "complete finite-horizon candidate subtree only, not game WDL",
    },
    "intervention": {
        "eligible": "complete common tree and differing N/D argmax tie sets",
        "candidate_pair": "canonical N argmax, canonical D argmax",
        "witness_paths": "each evaluator canonical optimal response path under each candidate",
        "max_paths_per_parent_horizon": 4,
        "endpoint_dedup": "action-path lexicographic order",
        "units": "each distinct nonterminal endpoint singly, then all jointly",
        "replacement": "only local-STM N post score becomes same-leaf D canonical post score",
        "maximum_saved_contrasts": 30,
        "backup": "all actions rebacked up; PV is allowed to change",
        "terminal_replacement_or_new_search_or_forward": False,
        "failed_to_flip": "report insufficient selected endpoint intervention; no new endpoint search",
    },
    "head_view": {
        "owner": "canonical ResidualModel single head/baseline/finite-check/tanh computation",
        "values": ["baseline", "linear residual", "pre_tanh_f32", "post_tanh_f32"],
        "input_scale": "raw distance/80 and canonical (distance-mu)/sigma are distinct",
        "atanh_reconstruction_or_duplicate_formula_or_second_head": False,
        "ordinary_OFF_added_scan_clone_heap_or_per_node_clock": False,
        "untraceable_Search_TT_static_origin": "UNKNOWN",
    },
    "parity": {
        "selection": "roots and distinct arrivals on fixed canonical witness paths",
        "source_upper_selected_states": 75,
        "contract_hard_state_cap": 256,
        "additional_N_evaluations_per_state_upper": 4,
        "full_qualification_or_successful_old_suite_replay": False,
        "exact": "features, history, parent-input and accumulator restoration",
        "FP32": "record bits/errors and inherited numerical alerts; do not assert unsupported bit equality",
    },
    "census_caps": {
        "normal_calls": 12,
        "forced_calls": 36,
        "Search_calls_total": 48,
        "N_Search_calls": 24,
        "Search_nodes_total": 48000000,
        "common_tree_visits": 300000,
        "logical_N_evaluations_global": 25000000,
        "conservative_N_evaluation_upper_with_extra_root_and_parity": 24301027,
        "all_caps_are_actual_usage": False,
        "no_refill_cap_depth_root_or_candidate_increase": True,
    },
    "necessary_new_fixture_questions": [
        "forced H-1/ply1/fullwindow/iterative cumulative cap; restricted parent TT isolation",
        "canonical history/terminal-first/make-undo/error-cancel and complete result authority",
        "two-evaluator alllegal complete/incomplete finite backup, parity of STM sign and signed-zero ties",
        "single canonical pre/post head view without ordinary OFF overhead",
        "saved intervention fully rebacks alternative responses; no frozen-PV shortcut",
        "unique call/candidate accounting and no lower-depth rescue or missing-slot refill",
    ],
    "status": {
        "new_numerical_calls_entered_by_analyst": 0,
        "new_model_loads_or_forwards_by_analyst": 0,
        "implementation_and_independent_source_review": "PENDING_ROOT_AND_419_2",
        "software_and_native_input_admission": "PENDING_ROOT",
        "419_1_after_design": "same leaf remains in_progress awaiting original finite saved result",
        "human_or_Root_spec_ACK_gate": False,
        "Astra_or_recursive_delegation": False,
    },
}
assert (
    design["census_caps"]["conservative_N_evaluation_upper_with_extra_root_and_parity"]
    < 25000000
)
save("design.json", design)
save(
    "design-checks.json",
    {
        "fixed_named_parent_count": len(parents),
        "horizons_from_saved_completion_and_cost_only": True,
        "new_numerical_results_used": False,
        "source_tree_bound_arithmetic": tree_bound,
        "calls_upper": 12 + 3 * 3 * 2 * 2,
        "nodes_upper": (12 + 3 * 3 * 2 * 2) * 1000000,
        "logical_N_upper": 24000000 + 300000 + 256 * 4 + 3,
        "intervention_upper": 3 * 2 * 5,
        "selected_parity_state_source_upper": 3 + 3 * 2 * 4 * 3,
        "RAW_prefix_observation_checks": load("selected-input-byte-checks.json"),
        "model_payload_read": False,
        "test_or_engine_execution": False,
    },
)
for name in ("fixed-inputs.json", "design.json", "design-checks.json"):
    b = (OWN / name).read_bytes()
    print(
        json.dumps(
            {"file": name, "sha256": hashlib.sha256(b).hexdigest(), "bytes": len(b)}
        )
    )
