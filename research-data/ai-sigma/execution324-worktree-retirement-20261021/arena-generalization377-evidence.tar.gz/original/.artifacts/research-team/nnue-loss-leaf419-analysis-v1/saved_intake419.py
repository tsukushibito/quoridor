"""Bounded metadata intake for the single original FAILED 419 run."""

import hashlib
import json
from pathlib import Path
import stat

OWN = Path(__file__).resolve().parent
BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-loss-leaf419-v1"
)
PATHS = [
    BASE / "diagnostic48-v1/collection.json",
    BASE / "diagnostic48-v1/prepared.json",
    BASE / "diagnostic48-v1/plan.json",
    BASE / "diagnostic48-v1/settings.json",
    BASE / "diagnostic48-v1/job/result.json",
    BASE / "software-acceptance.json",
    BASE / "source-review-acceptance.json",
    OWN / "design.json",
    OWN / "fixed-inputs.json",
]


def file_ref(path, data):
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }


def outline(value):
    if isinstance(value, dict):
        return {"type": "object", "keys": list(value)}
    if isinstance(value, list):
        return {
            "type": "list",
            "length": len(value),
            "first_type_or_keys": (
                list(value[0])
                if value and isinstance(value[0], dict)
                else type(value[0]).__name__
                if value
                else None
            ),
        }
    return value if not isinstance(value, str) else value[:240]


def refs_inside(value):
    result = []
    if isinstance(value, dict):
        if all(k in value for k in ("path", "sha256", "bytes")):
            result.append(
                {k: value[k] for k in ("path", "sha256", "bytes", "mode") if k in value}
            )
        for child in value.values():
            result.extend(refs_inside(child))
    elif isinstance(value, list):
        for child in value:
            result.extend(refs_inside(child))
    return result


records = []
for path in PATHS:
    assert path.stat().st_size <= 2097152
    data = path.read_bytes()
    before = file_ref(path, data)
    value = json.loads(data)
    after = file_ref(path, path.read_bytes())
    assert before == after
    record = {
        "before": before,
        "after": after,
        "outline": {k: outline(v) for k, v in value.items()},
        "embedded_file_refs": refs_inside(value),
    }
    records.append(record)
    print(json.dumps({"ref": before, "outline": record["outline"]}, ensure_ascii=False))
(OWN / "analysis-intake-index.json").write_text(
    json.dumps(records, ensure_ascii=False, indent=2) + "\n"
)
