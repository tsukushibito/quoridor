"""Reuse the finite saved-reader guard for the finite 419 design/saved-analysis phase."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

assert os.sched_getaffinity(0) == {9}
assert "NoNewPrivs:\t1" in Path("/proc/self/status").read_text()
ROOT = Path(__file__).resolve().parent
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def ident(pid):
    try:
        start = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
        return {"pid": pid, "start_ticks": start, "boot_id": boot}
    except FileNotFoundError:
        return None


def rss(pid):
    try:
        return int(Path(f"/proc/{pid}/statm").read_text().split()[1]) * os.sysconf(
            "SC_PAGE_SIZE"
        )
    except FileNotFoundError:
        return 0


def available():
    return next(
        int(x.split()[1]) * 1024
        for x in Path("/proc/meminfo").read_text().splitlines()
        if x.startswith("MemAvailable:")
    )


def physical(cpu):
    base = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
    return [
        int((base / name).read_text()) for name in ("physical_package_id", "core_id")
    ]


assert physical(5) != physical(9)
assert available() >= 4 * 1024**3
tag = sys.argv[1]
assert tag.replace("-", "").replace("_", "").isalnum()
guardian = ident(os.getpid())
process = subprocess.Popen(
    sys.argv[2:], stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True
)
original = ident(process.pid)
seen = {process.pid: original}
started = time.monotonic()
peak = 0
while True:
    todo, family = [process.pid], set()
    while todo:
        pid = todo.pop()
        if pid in family:
            continue
        family.add(pid)
        identity = ident(pid)
        if identity:
            seen[pid] = identity
        try:
            todo.extend(
                int(x)
                for x in Path(f"/proc/{pid}/task/{pid}/children").read_text().split()
            )
        except FileNotFoundError:
            pass
    sampled = rss(os.getpid()) + sum(rss(pid) for pid in family)
    peak = max(peak, sampled)
    if (
        sampled > 512 * 1024**2
        or available() < 4 * 1024**3
        or time.monotonic() - started > 90
    ):
        os.killpg(process.pid, 9)
        stdout, stderr = process.communicate()
        refusal = "finite analysis guard resource/time refusal"
        break
    try:
        stdout, stderr = process.communicate(timeout=0.025)
        refusal = None
        break
    except subprocess.TimeoutExpired:
        pass
fresh = []
for old in seen.values():
    if old:
        current = ident(old["pid"])
        state = (
            "absent" if current is None else ("different" if current != old else "SAME")
        )
        fresh.append({"original": old, "fresh_state": state})
receipt = {
    "guardian_identity": guardian,
    "child_identity": original,
    "returncode": process.returncode,
    "directwait_reaped": True,
    "handles_closed": process.stdout.closed and process.stderr.closed,
    "fresh_exact_identities": fresh,
    "stdout_sha256": hashlib.sha256(stdout).hexdigest(),
    "stdout_bytes": len(stdout),
    "stderr": stderr.decode(),
    "guard_refusal": refusal,
    "wall_seconds": time.monotonic() - started,
    "child_maxrss_kib": resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
    "sampled_family_max_RSS_B": peak,
    "continuous_family_RSS_peak": "UNKNOWN",
    "worker_cpu": 5,
    "guardian_cpu": 9,
    "physical_topology": {"5": physical(5), "9": physical(9)},
    "family_RSS_limit_B": 512 * 1024**2,
    "host_reserve_B": 4 * 1024**3,
    "GPU": 0,
    "owned_children_TMP_leases_remaining": [],
    "guard_complete_after_direct_reap": datetime.datetime.now(
        datetime.timezone.utc
    ).isoformat(),
}
(ROOT / f"{tag}.full.log").write_bytes(stdout)
(ROOT / f"{tag}.stderr.log").write_bytes(stderr)
(ROOT / f"{tag}-receipt.json").write_text(
    json.dumps(receipt, ensure_ascii=False, indent=2) + "\n"
)
print(stdout.decode())
print("GUARD", json.dumps(receipt))
assert (
    process.returncode == 0
    and refusal is None
    and all(x["fresh_state"] != "SAME" for x in fresh)
)
