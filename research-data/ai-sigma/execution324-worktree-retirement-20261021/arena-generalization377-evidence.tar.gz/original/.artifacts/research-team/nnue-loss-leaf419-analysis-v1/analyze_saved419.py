"""Reback up only the recorded finite 419 trees; no rules, model or engine import."""

from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import stat
import struct

OWN = Path(__file__).resolve().parent


def load(name):
    return json.loads((OWN / name).read_text())


def write(name, value):
    (OWN / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def number(bits):
    return struct.unpack("<f", struct.pack("<I", bits))[0]


def bits(value):
    return struct.unpack("<I", struct.pack("<f", value))[0]


def ulps(a, b):
    def ordered(value):
        return (~value & 0xFFFFFFFF) if value & 0x80000000 else value | 0x80000000

    return abs(ordered(a) - ordered(b))


def action_name(action):
    if action < 81:
        return f"{chr(97 + action % 9)}{1 + action // 9}"
    offset = action - (81 if action < 145 else 145)
    return f"{'H' if action < 145 else 'V'}({chr(97 + offset % 8)}{1 + offset // 8})"


raw_ref = load("analysis-result-schema.json")["raw_result_ref"]
raw_path = Path(raw_ref["path"])
raw_bytes = raw_path.read_bytes()
assert len(raw_bytes) == raw_ref["bytes"]
assert hashlib.sha256(raw_bytes).hexdigest() == raw_ref["sha256"]
assert f"{stat.S_IMODE(raw_path.stat().st_mode):04o}" == raw_ref["mode"]
result = json.loads(raw_bytes)
del raw_bytes
inputs = load("fixed-inputs.json")
extracted = load("analysis-extraction.json")
calls = extracted["calls"]
by_call = {r["id"]: r for r in calls}
assert len(by_call) == len(calls) == 40
parents = inputs["parents"]
parity = load("analysis-bounded-parity.json")
parity_lookup = {}
for selected in parity["selected_rows"]:
    parent = selected["value"]["parent"]
    for row_index, row in enumerate(selected["value"]["rows"]):
        key = parent, tuple(row["path"])
        assert key not in parity_lookup
        parity_lookup[key] = (row, selected, row_index)

assert len(parity_lookup) == 35
tree_checks = []
conditions = []
contrasts = []
endpoint_facts = []
forced_comparisons = []
parity_tree_checks = []
state_support = []
backup_bit_comparisons = 0
signed_zero_bit_differences = 0
all_leaf_count = 0
selected_states = set()

for tree_index, t in enumerate(result["trees"]):
    parent = t["parent"]
    assert parent == tree_index
    assert t["tree_error"] is None and t["parent_restored"]
    nodes = t["tree"]["nodes"]
    assert all(n["terminal"] is None for n in nodes), (
        "This actual data has no terminal nodes"
    )
    seen_children = Counter()
    path_to_node = {(): 0}
    node_paths = {0: ()}
    depth_counts = Counter()
    for i, n in enumerate(nodes):
        depth_counts[n["ply"]] += 1
        assert n["expansion_error"] is None
        assert len(n["children"]) == n["planned_children"]
        assert len(n["children"]) == len(set(n["children"]))
        if i == 0:
            assert n["parent"] is None and n["ply"] == 0
            assert [nodes[c]["action"] for c in n["children"]] == t["candidates"]
            assert n["legal_children"] >= len(n["children"])
        else:
            assert n["parent"] < i
            assert n["ply"] == nodes[n["parent"]]["ply"] + 1
            if n["ply"] < 3:
                assert n["planned_children"] == n["legal_children"]
        for child in n["children"]:
            assert child > i and nodes[child]["parent"] == i
            seen_children[child] += 1
            path = node_paths[i] + (nodes[child]["action"],)
            assert path not in path_to_node
            node_paths[child] = path
            path_to_node[path] = child
        if n["leaf"] is not None:
            all_leaf_count += 1
            assert n["ply"] in (2, 3)
            leaf = n["leaf"]
            assert all(
                math.isfinite(number(leaf[k])) and abs(number(leaf[k])) <= 1
                for k in ("nnue_post_bits", "distance_post_bits")
            )
            assert number(leaf["baseline_bits"]) == 0
            assert leaf["pre_tanh_bits"] == leaf["residual_bits"]
        if n["ply"] == 3:
            assert not n["children"] and n["leaf"] is not None
    assert set(seen_children) == set(range(1, len(nodes)))
    assert all(v == 1 for v in seen_children.values())

    def backup(horizon, evaluator, replacement=None):
        replacement = replacement or {}
        values = {}
        for i in range(len(nodes) - 1, -1, -1):
            n = nodes[i]
            if n["ply"] > horizon:
                continue
            if n["ply"] == horizon:
                key = "nnue_post_bits" if evaluator == 0 else "distance_post_bits"
                source = replacement.get(i, n["leaf"][key])
                values[i] = number(source)
            else:
                assert n["children"]
                values[i] = max(-values[child] for child in n["children"])
        return values

    def ranking(values):
        pairs = [
            {"action": nodes[c]["action"], "value_parent_bits": bits(-values[c])}
            for c in nodes[0]["children"]
        ]
        best = max(number(p["value_parent_bits"]) for p in pairs)
        tied = sorted(
            p["action"] for p in pairs if number(p["value_parent_bits"]) == best
        )
        return {
            "candidate_values": pairs,
            "canonical_action": tied[0],
            "argmax_ties": tied,
            "value_bits": bits(best),
            "status": "COMPLETE",
        }

    def witness(values, horizon, first_action=None):
        at, path = 0, []
        while nodes[at]["ply"] < horizon:
            if at == 0 and first_action is not None:
                choices = [
                    c
                    for c in nodes[at]["children"]
                    if nodes[c]["action"] == first_action
                ]
            else:
                choices = [c for c in nodes[at]["children"] if -values[c] == values[at]]
            at = min(choices, key=lambda c: nodes[c]["action"])
            path.append(nodes[at]["action"])
        return at, path

    def compare_ranking(actual, expected):
        assert actual["argmax_ties"] == expected["argmax_ties"]
        assert actual["canonical_action"] == expected["canonical_action"]
        assert actual["candidate_values"] == expected["candidate_values"]
        assert actual["value_bits"] == expected["value_bits"]

    for comp in t["comparisons"]:
        h = comp["parent_horizon"]
        values = [backup(h, e) for e in (0, 1)]
        ranks = [ranking(v) for v in values]
        for e in (0, 1):
            compare_ranking(ranks[e], comp["N" if e == 0 else "D"])
            for i, value in values[e].items():
                saved = nodes[i]["backup_bits"][h - 2][e]
                backup_bit_comparisons += 1
                if bits(value) != saved:
                    assert value == number(saved) == 0
                    signed_zero_bit_differences += 1
        expected_endpoints = set()
        for e in (0, 1):
            for action in {r["canonical_action"] for r in ranks}:
                node_id, path = witness(values[e], h, action)
                expected_endpoints.add((tuple(path), node_id))
                for length in range(h + 1):
                    selected_states.add((parent, tuple(path[:length])))
        expected_endpoints = sorted(expected_endpoints)
        assert [
            (tuple(q["path"]), q["node"]) for q in comp["endpoints"]
        ] == expected_endpoints
        differ = ranks[0]["argmax_ties"] != ranks[1]["argmax_ties"]
        expected_sets = (
            [[node_id] for _, node_id in expected_endpoints]
            + [[node_id for _, node_id in expected_endpoints]]
            if differ
            else []
        )
        assert len(comp["interventions"]) == len(expected_sets)
        normal = {
            e: next(
                c
                for c in calls
                if c["parent"] == parent
                and c["H"] == h
                and c["forced"] is None
                and c["evaluator"] == e
            )
            for e in ("N", "D")
        }
        single_flips = 0
        joint_flip = False
        for intervention_index, (saved, expected_nodes) in enumerate(
            zip(comp["interventions"], expected_sets, strict=True)
        ):
            assert [r["node"] for r in saved["replaced"]] == expected_nodes
            repl = {}
            for r in saved["replaced"]:
                leaf = nodes[r["node"]]["leaf"]
                assert r["original_bits"] == leaf["nnue_post_bits"]
                assert r["replacement_bits"] == leaf["distance_post_bits"]
                assert tuple(r["path"]) == node_paths[r["node"]]
                repl[r["node"]] = r["replacement_bits"]
            new_values = backup(h, 0, repl)
            new_rank = ranking(new_values)
            compare_ranking(new_rank, saved["ranking"])
            _, path = witness(new_values, h)
            assert path == saved["PV"] and saved["all_responses_rebacked_up"]
            changed = new_rank["canonical_action"] != ranks[0]["canonical_action"]
            tie_changed = new_rank["argmax_ties"] != ranks[0]["argmax_ties"]
            joint = intervention_index == len(expected_sets) - 1
            single_flips += int(changed and not joint)
            joint_flip = changed if joint else joint_flip
            contrasts.append(
                {
                    "parent": parent,
                    "H": h,
                    "index": intervention_index,
                    "joint": joint,
                    "paths": [r["path"] for r in saved["replaced"]],
                    "node_ids": expected_nodes,
                    "old_rank": ranks[0],
                    "new_rank": new_rank,
                    "new_PV": path,
                    "canonical_action_changed": changed,
                    "argmax_ties_changed": tie_changed,
                    "recorded_intervention_pointer": f"$.trees[{tree_index}].comparisons[{h - 2}].interventions[{intervention_index}]",
                }
            )
            if changed and not joint:
                node_id = expected_nodes[0]
                path = list(node_paths[node_id])
                parity_row, row_source, row_index = parity_lookup[(parent, tuple(path))]
                state_support.append(
                    {
                        "parent": parent,
                        "H": h,
                        "path": path,
                        "full_prefix_actions": parents[parent]["from_prefix_actions"]
                        + path,
                        "root_id": parents[parent]["id"],
                        "root_original_source": parents[parent]["source_raw"],
                        "tree_result_ref": raw_ref,
                        "tree_node_pointer": f"$.trees[{tree_index}].tree.nodes[{node_id}]",
                        "parity_journal_ref": row_source["original_journal"],
                        "parity_line_1_based": row_source["line_1_based"],
                        "parity_row_sha256": row_source["row_sha256"],
                        "parity_value_pointer": f"$.rows[{row_index}]",
                        "saved_features": parity_row["detail"]["features"],
                        "saved_leaf": nodes[node_id]["leaf"],
                        "interpretation": "existing recorded nonterminal endpoint; singleton saved substitution changes finite C selection; not a new root or WDL truth",
                        "fresh_native_state_replay_or_forward": False,
                        "new_context_native_admission": "required in any separately authorized use; analysis does not certify chronology by JSON",
                    }
                )
        for action in t["candidates"]:
            for e, label in enumerate(("N", "D")):
                call = next(
                    c
                    for c in calls
                    if c["parent"] == parent
                    and c["H"] == h
                    and c["forced"] == action
                    and c["evaluator"] == label
                )
                candidate = next(
                    q for q in ranks[e]["candidate_values"] if q["action"] == action
                )
                forced_comparisons.append(
                    {
                        "call_id": call["id"],
                        "evaluator": label,
                        "parent": parent,
                        "H": h,
                        "action": action,
                        "Search_value_bits": call["requested_value_bits"],
                        "tree_value_bits": candidate["value_parent_bits"],
                        "abs_difference": abs(
                            call["value"] - number(candidate["value_parent_bits"])
                        ),
                        "ULP_difference": ulps(
                            call["requested_value_bits"], candidate["value_parent_bits"]
                        ),
                    }
                )
        for path, node_id in expected_endpoints:
            n = nodes[node_id]
            endpoint_facts.append(
                {
                    "parent": parent,
                    "H": h,
                    "node": node_id,
                    "path": list(path),
                    "path_names": [action_name(a) for a in path],
                    "leaf": n["leaf"],
                    "leaf_local_STM": (parents[parent]["nnue_colour"] + len(path)) % 2,
                    "root_STM": parents[parent]["nnue_colour"],
                    "root_sign": 1 if len(path) % 2 == 0 else -1,
                    "original_pointer": f"$.trees[{tree_index}].tree.nodes[{node_id}]",
                }
            )
        conditions.append(
            {
                "parent": parent,
                "root_id": parents[parent]["id"],
                "H": h,
                "C": t["candidates"],
                "N": ranks[0],
                "D": ranks[1],
                "N_PV": witness(values[0], h)[1],
                "D_PV": witness(values[1], h)[1],
                "normal": normal,
                "different_argmax": differ,
                "single_intervention_action_flips": single_flips,
                "joint_intervention_action_flip": joint_flip,
                "intervention_count": len(comp["interventions"]),
                "root_original_completed_depth": parents[parent][
                    "original_nnue_observation"
                ]["completed_depth"],
            }
        )
    for key, (row, selected, row_index) in parity_lookup.items():
        p_index, path = key
        if p_index != parent or not path:
            continue
        node_id = path_to_node[path]
        if nodes[node_id]["leaf"] is not None:
            leaf = nodes[node_id]["leaf"]
            full = row["detail"]["full"]
            matches = (
                leaf["nnue_post_bits"] == full["post_tanh_bits"]
                and leaf["pre_tanh_bits"] == full["pre_tanh_bits"]
            )
            assert matches
            parity_tree_checks.append(
                {
                    "parent": parent,
                    "path": list(path),
                    "node": node_id,
                    "full_head_matches_saved_tree_leaf_bits": True,
                }
            )
    tree_checks.append(
        {
            "parent": parent,
            "nodes": len(nodes),
            "depth_counts": dict(sorted(depth_counts.items())),
            "terminal_nodes": 0,
            "node_parent_and_recorded_alllegal_expansion_counts": "MATCH",
            "candidate_root_legal_count": nodes[0]["legal_children"],
            "candidate_root_expanded": len(t["candidates"]),
            "new_geometry_or_legal_move_execution": 0,
        }
    )

assert selected_states == set(parity_lookup)
assert sum(t["nodes"] for t in tree_checks) == 47577
assert all_leaf_count == 47567
assert len(contrasts) == 23
assert len(forced_comparisons) == 28
assert 12 + 4 * sum(len(t["candidates"]) for t in result["trees"]) == 40
assert sum(c["nodes"] for c in calls) == 74064
assert sum(c["evals"] for c in calls if c["evaluator"] == "N") == 36975
for c in calls:
    assert c["status"] == "COMPLETE" and c["bound"] == "Exact"
    assert c["parent_restored"] and c["completed_depth"] == c["H"]
    assert c["stop"] == "DepthComplete" and c["window"] == ["-infinity", "+infinity"]
    if c["forced"] is not None:
        assert c["child_depth"] == c["H"] - 1 and c["nonroot_ply"] == 1
        assert c["restricted_root_TT"] is False and c["action"] == c["forced"]
    assert c["PV"][0] == c["action"] and len(c["PV"]) <= c["H"]
assert hashlib.sha256(raw_path.read_bytes()).hexdigest() == raw_ref["sha256"]

details = [row["detail"] for (row, _, _) in parity_lookup.values() if "detail" in row]
parity_summary = {
    "states": len(parity_lookup),
    "root_states": 3,
    "edge_states": len(details),
    "parent_exact_all": all(
        row["parent_exact"] for row, _, _ in parity_lookup.values()
    ),
    "features_exact_all": all(r["features_exact"] for r in details),
    "shape_exact_all": all(r["shape_exact"] for r in details),
    "FT_alerts": sum(r["FT_alert"] for r in details),
    "value_alerts": sum(r["value_alert"] for r in details),
    "value_bit_equal": sum(r["value_bits_equal"] for r in details),
    "max_FT_error": max(r["max_FT_error"] for r in details),
    "max_value_abs_error": max(r["value_abs_error"] for r in details),
    "recorded_tolerances": {"abs": 1e-5, "rel": 1e-4},
    "logical_evaluations": 3 + 4 * len(details),
    "tree_leaf_correspondences": parity_tree_checks,
    "head_input_lengths": sorted({len(r["full"]["input_bits"]) for r in details}),
}
assert (
    parity_summary["parent_exact_all"]
    and parity_summary["features_exact_all"]
    and parity_summary["shape_exact_all"]
)
assert parity_summary["FT_alerts"] == parity_summary["value_alerts"] == 0
census = result["census"]
assert (
    census["nnue_logical_charge_including_unknown_reservations"]
    == 36975 + 47567 + parity_summary["logical_evaluations"]
    == 84673
)
assert (
    census["diagnostic_head_calls_started"]
    == 47567 + parity_summary["logical_evaluations"]
)
assert census["diagnostic_delta_contexts_started"] == len(details) == 32
assert census["diagnostic_full_contexts_started"] == 47567 + 3 + 2 * len(details)

analysis = {
    "issue": "quoridor-4lc.419.1",
    "original_operational_outcome": "FAILED; saved finite observations only",
    "source_result_ref_before_after": raw_ref,
    "conditions": conditions,
    "interventions": contrasts,
    "endpoint_facts": endpoint_facts,
    "tree_checks": tree_checks,
    "parity": parity_summary,
    "forced_Search_vs_tree": forced_comparisons,
    "calls": calls,
    "census": census,
    "checks": {
        "all_saved_backups_and_23_interventions_recomputed": True,
        "compared_backup_values": backup_bit_comparisons,
        "signed_zero_only_bit_differences": signed_zero_bit_differences,
        "selected_endpoints_and_parity_paths_exactly_match_fixed_rule": True,
        "new_model_forward_Search_geometry_solver": 0,
    },
    "finite_interpretation": {
        "parent_horizon_cases": 6,
        "different_N_D_argmax": sum(c["different_argmax"] for c in conditions),
        "intervention_cases_with_singleton_action_flip": sum(
            c["single_intervention_action_flips"] > 0 for c in conditions
        ),
        "singleton_action_flips": sum(
            c["single_intervention_action_flips"] for c in conditions
        ),
        "joint_action_flips": sum(
            c["joint_intervention_action_flip"] for c in conditions
        ),
        "all_intervention_action_flips": sum(
            c["canonical_action_changed"] for c in contrasts
        ),
        "WDL_or_general_strength_or_original_warm_state_causal_claim": False,
    },
}
write("saved-analysis-result.json", analysis)
assert len(state_support) <= 8
write(
    "existing-endpoint-input-support.json",
    {
        "selection": "all singleton saved interventions that change canonical C action, existing parent/H/path order; no replacement or added root",
        "states": state_support,
        "count": len(state_support),
        "new_forward_or_native_admission": False,
        "use_scope": "only input support for separately authorized420; original419 roots unchanged; no Sigma truth claim",
    },
)
print(
    json.dumps(
        {
            "finite_interpretation": analysis["finite_interpretation"],
            "parity": {
                k: v
                for k, v in parity_summary.items()
                if k != "tree_leaf_correspondences"
            },
            "forced_max_abs_by_eval": {
                e: max(
                    r["abs_difference"]
                    for r in forced_comparisons
                    if r["evaluator"] == e
                )
                for e in ("N", "D")
            },
            "support_states": len(state_support),
            "checks": analysis["checks"],
        },
        ensure_ascii=False,
    )
)
