"""Create static tables and an SVG from already extracted 419 arithmetic."""

import csv
import json
from pathlib import Path
import struct
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

OWN = Path(__file__).resolve().parent
data = json.loads((OWN / "saved-analysis-result.json").read_text())
views = json.loads((OWN / "analysis-leaf-views.json").read_text())


def num(b):
    return struct.unpack("<f", struct.pack("<I", b))[0]


def fmt(x):
    return f"{x:+.6f}"


with (OWN / "candidate-table.tsv").open("w", newline="") as f:
    w = csv.writer(f, delimiter="\t", lineterminator="\n")
    w.writerow(
        [
            "parent",
            "H",
            "action",
            "N_C_value",
            "D_C_value",
            "N_C_best",
            "D_C_best",
            "N_normal_action",
            "D_normal_action",
            "N_normal_value",
            "D_normal_value",
        ]
    )
    for condition in data["conditions"]:
        for action in condition["C"]:
            pair = [
                next(
                    p for p in condition[e]["candidate_values"] if p["action"] == action
                )
                for e in ("N", "D")
            ]
            w.writerow(
                [
                    condition["root_id"],
                    condition["H"],
                    action,
                    num(pair[0]["value_parent_bits"]),
                    num(pair[1]["value_parent_bits"]),
                    condition["N"]["canonical_action"],
                    condition["D"]["canonical_action"],
                    condition["normal"]["N"]["action"],
                    condition["normal"]["D"]["action"],
                    condition["normal"]["N"]["value"],
                    condition["normal"]["D"]["value"],
                ]
            )
with (OWN / "interventions.tsv").open("w", newline="") as f:
    w = csv.writer(f, delimiter="\t", lineterminator="\n")
    w.writerow(
        [
            "parent",
            "H",
            "index",
            "joint",
            "paths",
            "original_C_action",
            "intervened_C_action",
            "changed",
            "new_PV",
        ]
    )
    for r in data["interventions"]:
        w.writerow(
            [
                r["parent"],
                r["H"],
                r["index"],
                r["joint"],
                json.dumps(r["paths"]),
                r["old_rank"]["canonical_action"],
                r["new_rank"]["canonical_action"],
                r["canonical_action_changed"],
                json.dumps(r["new_PV"]),
            ]
        )

case = next(c for c in data["conditions"] if c["parent"] == 0 and c["H"] == 2)
contrast = next(
    c
    for c in data["interventions"]
    if c["parent"] == 0 and c["H"] == 2 and c["paths"] == [[156, 91]]
)
leaf = next(
    v for v in views if v["parent"] == 0 and v["H"] == 2 and v["path"] == [156, 91]
)


def value(rank, action):
    return num(
        next(
            x["value_parent_bits"]
            for x in rank["candidate_values"]
            if x["action"] == action
        )
    )


def text(x, y, content, cls="body", anchor="start"):
    return f'<text x="{x}" y="{y}" class="{cls}" text-anchor="{anchor}">{escape(content)}</text>'


parts = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="850" viewBox="0 0 1200 850" role="img" aria-labelledby="title desc">',
    '<title id="title">419 保存有限木：葉一つの置換で固定C内の選択が変わる例</title>',
    '<desc id="desc">原runはstdout captureでFAILED。slot4 ply11 horizon2の保存共通木で、156と68の候補だけを比較。葉156,91のNNUE値を同葉D値へ置くとC内の選択は156から68に変わる。対局勝敗と全合法rootの介入後選択は未判定。</desc>',
    '<defs><marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#596579"/></marker></defs>',
    '<style>text{font-family:"Noto Sans CJK JP","Yu Gothic",sans-serif;fill:#192638}.title{font-size:25px;font-weight:700}.body{font-size:20px}.small{font-size:16px}.blue{font-size:23px;fill:#185ca6;font-weight:700}.red{font-size:22px;fill:#ae253b;font-weight:700}.green{font-size:23px;fill:#08704c;font-weight:700}.box{fill:white;stroke:#b9c5d4;stroke-width:2}.line{fill:none;stroke:#596579;stroke-width:2;marker-end:url(#arrow)}</style>',
    '<rect width="1200" height="850" fill="#f5f7fa"/>',
    text(38, 40, "原operational outcome: FAILED / 保存された有限木の介入", "title"),
    text(
        38,
        72,
        "slot4 / ply11 · 親STM=P1 · H2 · C={68 f8, 156 V(d2)} · 値はすべて親視点",
        "body",
    ),
    '<rect x="350" y="98" width="500" height="75" rx="12" class="box"/>',
    text(600, 129, "親が候補値の最大を選ぶ（C内）", "body", "middle"),
    text(600, 156, "各候補では相手の全合法応手を含む", "small", "middle"),
    '<path d="M460,173 L275,217" class="line"/><path d="M740,173 L925,217" class="line"/>',
    '<rect x="55" y="220" width="465" height="135" rx="12" class="box"/>',
    '<rect x="680" y="220" width="465" height="135" rx="12" class="box"/>',
    text(80, 253, "68 = f8"),
    text(80, 289, f"N {fmt(value(case['N'], 68))}", "blue"),
    text(80, 326, f"D {fmt(value(case['D'], 68))}", "body"),
    text(705, 253, "156 = V(d2)"),
    text(705, 289, f"N {fmt(value(case['N'], 156))}  ← 元のC内選択", "blue"),
    text(705, 326, f"D {fmt(value(case['D'], 156))}", "body"),
    '<path d="M920,355 L920,393" class="line"/>',
    '<rect x="590" y="397" width="555" height="175" rx="12" fill="#fff4f4" stroke="#c85b6b" stroke-width="2"/>',
    text(615, 430, "相手の応手91=H(c2)：path [156,91]", "body"),
    text(
        615,
        462,
        f"N pre-tanh {fmt(leaf['pre_tanh'])} → post {fmt(leaf['NNUE_static'])}",
        "small",
    ),
    text(615, 496, f"この葉だけD値 {fmt(leaf['D_static'])} へ置換", "red"),
    text(615, 531, "同じ葉・同じSTM・同じhorizon。その他の値は固定。", "small"),
    text(80, 410, "原対局の実続行は [156,123,…]。", "body"),
    text(80, 443, "[156,91]は診断PV上の葉であり、", "small"),
    text(80, 471, "実戦で踏んだ葉とは主張しない。", "small"),
    '<rect x="55" y="605" width="1090" height="123" rx="12" fill="#eef8f3" stroke="#69a78c" stroke-width="2"/>',
    text(80, 639, "全応手を再backupした後（PV固定はしない）", "body"),
    text(
        80,
        679,
        f"68 f8: {fmt(value(contrast['new_rank'], 68))}  ← 新しいC内選択",
        "green",
    ),
    text(680, 679, f"156 V(d2): {fmt(value(contrast['new_rank'], 156))}", "red"),
    text(
        55,
        770,
        "C外のroot手はこの木に無い。全合法rootの介入後選択、Dの正しさ、真のWDLは未判定。",
        "small",
    ),
    text(
        55,
        803,
        "H3では固定4endpointを同時置換しても156が残る：代替葉 [156,193,140] の親値 +0.938093。",
        "small",
    ),
    "</svg>",
]
svg = "\n".join(parts) + "\n"
root = ET.fromstring(svg)
assert root.tag == "{http://www.w3.org/2000/svg}svg"
assert not root.findall(".//{http://www.w3.org/2000/svg}script")
(OWN / "finite-leaf-example.svg").write_text(svg)
print(
    json.dumps(
        {
            "candidate_rows": sum(len(c["C"]) for c in data["conditions"]),
            "saved_intervention_rows": len(data["interventions"]),
            "static_SVG_XML_valid": True,
            "forward_Search_or_new_interventions": 0,
        }
    )
)
