"""Adapt the existing saved consumers to current Control's three passes/one RAW.

Input is the existing consumer's list of label/record/planned objects. Run only
after integration releases the actual measurement readers; never records events.
"""

import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path("/workspaces/quoridor")
OLD = ROOT / ".worktree/cheap-static-ordering376/.artifacts/current-search-perf349-v1"


def load(name, path):
    loader = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(loader)
    sys.modules[name] = module
    loader.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    lc = load("lc388", ROOT / "scripts/dev/research-lifecycle.py")
    consumer = load("consumer388", OLD / "configured-consumer-v1/consume.py")
    summary = load("summary388", OLD / "saved-profile-v1/summarize.py")
    out = args.out.resolve()
    out.mkdir()
    summary.OUT = out
    spec = {
        "kind": "run",
        "limits": {
            "family_B": 512 * 1024**2,
            "host_reserve_B": 4 * 1024**3,
            "worker_cpu": 3,
            "guardian_cpu": 4,
        },
    }
    lc.physical_and_quiet(spec)
    checks = []
    raw = None
    primary = None
    tmp = out / "TMP"
    try:
        with lc.lease():
            items = json.loads(args.runs.read_text())
            runs = [consumer.read_run(item) for item in items]
            lc.new_json(out / "consumer.json", consumer.interpret(runs))
            sampled = [r for r in runs if r["sampled"] is True]
            if len(sampled) != 1 or len(sampled[0]["perf_RAW"]) != 1:
                raise ValueError("one actual sampled pass and one saved RAW required")
            raw = sampled[0]["perf_RAW"][0]
            if lc.artifact_ref(raw["path"]) != raw:
                raise ValueError("saved RAW identity changed")
            tmp.mkdir()
            env = dict(os.environ)
            env.update(
                TMPDIR=str(tmp),
                PERF_BUILDID_DIR=str(tmp / "buildid-cache"),
                DEBUGINFOD_URLS="",
                CUDA_VISIBLE_DEVICES="",
                OMP_NUM_THREADS="1",
                OPENBLAS_NUM_THREADS="1",
                PYTHONDONTWRITEBYTECODE="1",
            )
            resources = lc.process.CycleResources(
                dict(max_memory_bytes=512 * 1024**2, host_ram_reserve=4 * 1024**3),
                out,
                None,
            )
            prefix = [
                "/usr/bin/perf",
                "--no-pager",
                "--buildid-dir",
                str(tmp / "buildid-cache"),
            ]
            commands = {
                "self": prefix
                + [
                    "report",
                    "-i",
                    raw["path"],
                    "--stdio",
                    "--header",
                    "--no-children",
                    "--percent-limit",
                    "0",
                    "--sort",
                    "dso,symbol",
                    "--call-graph",
                    "none",
                    "-n",
                    "--show-total-period",
                ],
                "inclusive": prefix
                + [
                    "report",
                    "-i",
                    raw["path"],
                    "--stdio",
                    "--header",
                    "--children",
                    "--percent-limit",
                    "0",
                    "--sort",
                    "dso,symbol",
                    "--call-graph",
                    "none",
                    "-n",
                    "--show-total-period",
                ],
                "script": prefix
                + [
                    "script",
                    "-i",
                    raw["path"],
                    "--show-lost-events",
                    "-F",
                    "comm,pid,tid,time,event,period,ip,sym,dso",
                ],
            }
            try:
                for kind, argv in commands.items():
                    name = "A-" + kind
                    capture = lc.Capture(out / (name + ".full.log"), 8 * 1024**2)
                    record = None
                    try:
                        with lc.process.cancellation_signals():
                            record = lc.process.execute(
                                argv,
                                out / (name + ".log"),
                                None,
                                resources=resources,
                                cpu_core=3,
                                cwd=ROOT,
                                env=env,
                                no_new_privs=True,
                                output_sink=capture,
                            )
                        lc.settled(record)
                    finally:
                        capture.close()
                        checks.append(
                            dict(
                                name=name,
                                guardian_return=record,
                                persisted_receipt=lc.bound(
                                    out / (name + ".process.json")
                                )[0]
                                if (out / (name + ".process.json")).exists()
                                else None,
                                full_capture=lc.bound(capture.path, 8 * 1024**2)[0],
                            )
                        )
                os.sched_setaffinity(0, {3})
                profile = summary.profile("A")
                profile["groups"]["sorting"]["label"] = (
                    "sorting/unstable/comparator where resolved"
                )
                profile["unresolved_responsibilities"] = {
                    "FT_ID_copy": "UNKNOWN unless a distinct saved symbol/callchain resolves it",
                    "inlined_comparator_prepare_validation": "UNKNOWN attribution within caller samples",
                    "dynamic_calls_skip_BFS_cache_hits": "UNKNOWN without recorded counters",
                    "unwind_completeness": "UNKNOWN; named frames and unknown sentinels are observations",
                }
                lc.new_json(out / "profile.json", profile)
            finally:
                try:
                    if lc.artifact_ref(raw["path"]) != raw:
                        raise ValueError("saved RAW changed during offline decode")
                finally:
                    shutil.rmtree(tmp)
            comparisons = []
            fields = [
                "completed_depth",
                "value_bits",
                "action",
                "PV",
                "work",
                "root_legal_action_ids",
                "parent_unchanged",
                "stop",
                "status",
            ]
            rows = [r["rows"] for r in runs]
            for index in range(max(map(len, rows), default=0)):
                selected = [rr[index] if index < len(rr) else None for rr in rows]
                complete = all(
                    row is not None
                    and row.get("measurement", {}).get("status") == "COMPLETE"
                    for row in selected
                )
                comparisons.append(
                    dict(
                        index=index,
                        complete_all_passes=complete,
                        same_full_root_history=all(
                            row is not None
                            and row.get("root") == selected[0].get("root")
                            for row in selected
                        )
                        if selected[0] is not None
                        else None,
                        returned_fields_agree={
                            k: all(
                                row is not None
                                and k in row.get("measurement", {})
                                and row["measurement"][k]
                                == selected[0].get("measurement", {}).get(k)
                                for row in selected
                            )
                            if selected[0] is not None
                            else None
                            for k in fields
                        },
                    )
                )
            lc.new_json(out / "comparison.json", comparisons)
    except BaseException as error:
        primary = lc.error_fact(error)
        raise
    finally:
        lc.new_json(
            out / "result.json",
            dict(
                status="ERROR" if primary else "SAVED_ANALYSIS",
                primary=primary,
                RAW=raw,
                decoder_checks=checks,
                reused_consumers=[
                    lc.bound(OLD / "configured-consumer-v1/consume.py")[0],
                    lc.bound(OLD / "saved-profile-v1/summarize.py")[0],
                ],
                new_Search_model_perf_record_calls=0,
                reader_STOP=lc.stamp(),
                TMP_absent=not tmp.exists(),
                owned_readers_writers_children_jobs_TMP_leases=[],
            ),
        )


if __name__ == "__main__":
    main()
