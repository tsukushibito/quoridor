"""Finite named current source/caller intake; no native, model or test calls."""

import gzip
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path("/workspaces/quoridor")
OWN = Path.cwd()
OUT = Path(__file__).resolve().parent
paths = [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-ai/src/compact_tt359_tests.rs",
    "crates/quoridor-runner/src/runtime.rs",
    "crates/quoridor-runner/src/measurement.rs",
    "crates/quoridor-runner/src/teacher_pilot_execution.rs",
    "crates/quoridor-runner/src/arena.rs",
    "configs/arena/distance-control-100ms.json",
    "configs/arena/distance-control-500ms.json",
]
refs = []
for i, relative in enumerate(paths):
    source = ROOT / relative
    raw = source.read_bytes()
    if i == 0:
        assert (
            hashlib.sha256(raw).hexdigest()
            == "468f6d8cbe36c73747f8b9293916ef3d122496386a4824ebc5f66d59f64108b3"
        )
    (OUT / f"{i}.Main-before.gz").write_bytes(gzip.compress(raw, mtime=0))
    refs.append(
        {
            "relative": relative,
            "Main": {
                "path": str(source),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": format(stat.S_IMODE(source.stat().st_mode), "04o"),
            },
        }
    )
    if i == 1:
        current = OWN / relative
        previous = current.read_bytes()
        (OUT / "compact_tt359_tests.OWN-before.gz").write_bytes(
            gzip.compress(previous, mtime=0)
        )
        # Only the necessary current owning test file; frozen evidence untouched.
        current.write_bytes(raw)

lines = []
for relative in [
    "docs/development/rust-ai.md",
    "docs/development/ai-research-code.md",
    "README.md",
]:
    for number, line in enumerate((ROOT / relative).read_text().splitlines(), 1):
        if "distance-control-100ms" in line or "distance-control-500ms" in line:
            lines.append({"path": relative, "line": number, "text": line})
result = {
    "status": "NAMED_SOURCE_INTAKE_PASS",
    "refs": refs,
    "alphabeta_matches_frozen392_before": True,
    "live_doc_template_references_in_selected_docs": lines,
    "new_test_Main_absent": not (
        ROOT / "crates/quoridor-ai/src/tt_capacity397_tests.rs"
    ).exists(),
    "Main_Git_index_writes": 0,
    "scientific_calls": 0,
    "scope": "Current named TT/caller/measurement/teacher/arena/templates only; not a source inventory",
}
assert result["new_test_Main_absent"]
(OUT / "current-intake.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    "Current TT/caller named source captured; AI exact frozen392, NN/model/native calls0"
)
