"""Read only the current measurement settings consumer under the owning lease."""

import ast
import hashlib
import json
from pathlib import Path
import stat

path = Path("/workspaces/quoridor/scripts/dev/research-lifecycle.py")
raw = path.read_bytes()
text = raw.decode()
lines = text.splitlines(True)
node = next(
    n
    for n in ast.parse(text).body
    if isinstance(n, ast.FunctionDef) and n.name == "measurement_config"
)
subject = "".join(lines[node.lineno - 1 : node.end_lineno])
out = Path(__file__).resolve().parent
result = {
    "function": "measurement_config",
    "path": str(path),
    "file_ref": {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    },
    "subject_sha256": hashlib.sha256(subject.encode()).hexdigest(),
    "subject_bytes": len(subject.encode()),
    "source": subject,
    "status": "SOURCE_ONLY; not called/imported/tested",
    "scientific_calls": 0,
}
(out / "current-consumer-subject.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    "One current Python measurement config subject captured; no validator or scientific invocation"
)
