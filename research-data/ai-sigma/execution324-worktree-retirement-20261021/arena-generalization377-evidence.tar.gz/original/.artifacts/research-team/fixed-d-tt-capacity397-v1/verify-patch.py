"""Exact scoped source correspondence and strict GNU roundtrip; no Rust execution."""

import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import stat
import subprocess

OWN = Path.cwd()
OUT = Path(__file__).resolve().parent
intake = json.loads((OUT / "current-intake.json").read_text())
paths = [intake["refs"][i]["relative"] for i in [0, 1, 2]]
TEST = "crates/quoridor-ai/src/tt_capacity397_tests.rs"
before = {
    p: gzip.decompress((OUT / f"{i}.Main-before.gz").read_bytes())
    for i, p in enumerate(paths)
}
before[TEST] = b""
after = {p: (OWN / p).read_bytes() for p in before}
assert intake["new_test_Main_absent"]
for i, path in enumerate(paths):
    assert (
        hashlib.sha256(before[path]).hexdigest() == intake["refs"][i]["Main"]["sha256"]
    )


def body(raw, signature):
    text = raw.decode()
    start = text.index(signature)
    brace = text.index("{", start)
    depth = 0
    for i in range(brace, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    raise AssertionError(signature)


protected = []
for path, signatures in {
    paths[0]: [
        "fn compatible(",
        "fn get_hashed(",
        "fn retained_bytes(",
        "fn clear(",
        "fn next_generation(",
        "fn discard_uncommitted(",
        "fn probe_hashed(",
        "fn insert_hashed(",
        "fn ordered(",
        "fn negamax(",
        "fn child(",
        "fn root_depth(",
        "fn create(",
        "pub fn new_with_control_ordering(",
        "pub fn tt_capacity(",
        "fn search_in_table(",
    ],
    paths[2]: ["fn invoke_alpha_observed("],
}.items():
    for signature in signatures:
        assert body(before[path], signature) == body(after[path], signature), (
            path,
            signature,
        )
        protected.append([path, signature])

# Full surrounding source is exact after accounting for the narrow subjects.
old = before[paths[0]].decode()
new = after[paths[0]].decode()
for signature in ["fn persistent(", "fn with_limit("]:
    new = new.replace(
        body(after[paths[0]], signature), body(before[paths[0]], signature), 1
    )
new = new.replace("    " + body(after[paths[0]], "fn requested_bytes(") + "\n", "", 1)
new = new.replace(
    "    /// Capacity is the requested slot count, without a persistent-table clamp.\n    /// Allocation is fallible; live retained bytes are reported separately.\n",
    "",
    1,
)
new = new.replace(
    "let mut capped = Table::persistent(4096)",
    "let mut capped = Table::persistent(65536)",
    1,
)
new = new.replace(
    'SearchSession::new(e.clone(), ns("D0,8:tanh"), 4096).unwrap();\n        let seed',
    'SearchSession::new(e.clone(), ns("D0,8:tanh"), 65536).unwrap();\n        let seed',
    1,
)
assert '#[path = "tt_capacity397_tests.rs"]\nmod tt_capacity397_tests;' in new
new = new.replace(
    '\n#[cfg(all(test, feature = "research"))]\n#[path = "tt_capacity397_tests.rs"]\nmod tt_capacity397_tests;\n',
    "",
    1,
)
assert new == old, "unowned alphabeta bytes changed"
assert (
    after[paths[1]]
    .decode()
    .replace(
        "let mut t = Table::persistent(4096)", "let mut t = Table::persistent(65536)", 1
    )
    == before[paths[1]].decode()
)
old = before[paths[2]].decode()
new = after[paths[2]].decode()
new = new.replace(
    "config.arena.as_ref().map_or(4096, |a| a.tt_entries)",
    "config.arena.as_ref().map_or(65536, |a| a.tt_entries)",
    1,
)
test_body = body(
    after[paths[2]],
    "fn tt_capacity397_runtime_requested_effective_and_retained_precancel(",
)
new = new.replace("    #[test]\n    " + test_body + "\n\n", "", 1)
signature = "fn distance_live_deadline_completed_cap_cancel_and_tt_nn0("
new = new.replace(
    body(after[paths[2]], signature), body(before[paths[2]], signature), 1
)
assert new == old, "unowned runtime bytes changed"

for filename, left, right in [
    ("source.patch", before, after),
    ("source.inverse.patch", after, before),
]:
    chunks = []
    for path in before:
        chunks.extend(
            difflib.unified_diff(
                left[path].decode().splitlines(True),
                right[path].decode().splitlines(True),
                fromfile="a/" + path if left[path] else "/dev/null",
                tofile="b/" + path if right[path] else "/dev/null",
            )
        )
    (OUT / filename).write_text("".join(chunks))
TMP = OUT / "proof-TMP"
TMP.mkdir()
captures = []
try:
    for path, raw in before.items():
        p = TMP / path
        p.parent.mkdir(parents=True, exist_ok=True)
        if raw:
            p.write_bytes(raw)
    for name, expected in [("source.patch", after), ("source.inverse.patch", before)]:
        r = subprocess.run(
            ["/usr/bin/patch", "--batch", "--fuzz=0", "-p1", "-i", str(OUT / name)],
            cwd=TMP,
            capture_output=True,
            text=True,
            check=True,
            timeout=60,
        )
        assert not re.search(r"offset|fuzz|FAILED", r.stdout + r.stderr)
        for path, raw in expected.items():
            assert (
                (TMP / path).read_bytes() == raw if raw else not (TMP / path).exists()
            )
        captures.append(
            {
                "patch": name,
                "exit_code": r.returncode,
                "stdout": r.stdout,
                "stderr": r.stderr,
            }
        )
finally:
    shutil.rmtree(TMP)


def ref(p):
    raw = p.read_bytes()
    return {
        "path": str(p.resolve()),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(p.stat().st_mode), "04o"),
    }


names = re.findall(r"#\[test\]\s*fn (tt_capacity397_\w+)\(", after[TEST].decode())
runner_names = re.findall(
    r"#\[test\]\s*fn (tt_capacity397_\w+)\(", after[paths[2]].decode()
)
assert len(names) == 5 and len(runner_names) == 1
for path in after:
    (OUT / (Path(path).name + ".after.gz")).write_bytes(
        gzip.compress(after[path], mtime=0)
    )
result = {
    "status": "STATIC_BYTE_PROOF_PASS",
    "current_intake": ref(OUT / "current-intake.json"),
    "before_refs": [intake["refs"][i]["Main"] for i in [0, 1, 2]],
    "new_test_before": "ABSENT",
    "owned_postimages": [ref(OWN / path) for path in after],
    "forward": ref(OUT / "source.patch"),
    "inverse": ref(OUT / "source.inverse.patch"),
    "protected_bodies_exact": protected,
    "outside_owned_subjects_exact": True,
    "GNU_zero_fuzz_zero_offset_exact_roundtrip": captures,
    "new_AI_names": names,
    "new_runner_names": runner_names,
    "new_count": 6,
    "affected_old_requests_only": [
        "persistent_tt_contract_and_cost",
        "compact359_fixed_layout_admission_allocation_and_paired_hash",
        "distance_live_deadline_completed_cap_cancel_and_tt_nn0",
    ],
    "native_status": "UNBUILT/UNTYPED/UNRUN",
    "model_Cargo_native_Search_geometry_Perf_game_fit_calls": 0,
    "temporary_tree_absent": not TMP.exists(),
    "Root_composition": "Sparse function/field/test hunks only; do not install full Alpha/runtime postimages over394 callbacks or any later source",
}
(OUT / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    "Scoped TT/caller source isolation / forward inverse / six definitions STATIC PASS; native UNRUN"
)
