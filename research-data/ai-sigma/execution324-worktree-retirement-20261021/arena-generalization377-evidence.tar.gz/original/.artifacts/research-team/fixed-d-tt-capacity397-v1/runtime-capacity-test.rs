#[test]
fn tt_capacity397_runtime_requested_effective_and_retained_precancel() {
    let root = SigmaContext::from_prefix(&[]).unwrap();
    let before = root.clone();
    for requested in [4096, 1_048_576] {
        let mut session = None;
        let mut profile = TtProfile::default();
        let limits = SearchLimits {
            max_depth: 1,
            max_nodes: 1,
            time_limit: None,
            tt_entries: requested,
            use_pvs: true,
            use_tt: true,
        };
        let result = invoke_alpha_observed(
            &mut session,
            &mut profile,
            Arc::new(DistanceEvaluator::new(0., 8.)),
            alphabeta::SearchNamespace {
                evaluator: "397-D0,8:tanh-caller-capacity".into(),
                rules: "research-standard-2p-threefold-goal-first-v1".into(),
                selectivity: "fullwidth-PVS-MPC-OFF-v1".into(),
            },
            &root,
            &limits,
            &AtomicBool::new(true),
            Instant::now(),
            alphabeta::SearchSession::new,
            None,
            None,
            Duration::ZERO,
            None,
        )
        .unwrap();
        assert_eq!(result.stop, alphabeta::StopReason::Cancelled);
        assert_eq!(result.completed_depth, 0);
        assert!(result.value.is_none());
        assert_eq!(profile.requested_tt_entries, Some(requested));
        assert_eq!(profile.effective_tt_slots, Some(requested));
        let actual = session.as_ref().unwrap();
        assert_eq!(profile.persistent_tt_byte_cap, Some(actual.tt_capacity().1));
        assert_eq!(
            profile.retained_bytes_peak,
            actual.retained_memory_bytes().0
        );
        assert!(profile.retained_bytes_peak <= actual.tt_capacity().1);
        if requested == 4096 {
            assert_eq!(actual.tt_capacity().1, 1024 * 1024);
        }
        assert_eq!(root.position(), before.position());
        assert_eq!(root.total_ply(), before.total_ply());
        assert_eq!(root.history_counts(), before.history_counts());
    }
}
