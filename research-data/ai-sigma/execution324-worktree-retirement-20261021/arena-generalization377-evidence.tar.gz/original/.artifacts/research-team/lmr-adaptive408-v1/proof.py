"""Static sparse subject and standard-patch proof only; no Rust/test execution."""

import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
INPUT = HERE / "prepare-v1/TMP"
TMP = Path(os.environ["TMPDIR"])
AI = "crates/quoridor-ai/src/alphabeta.rs"
MEASURE = "crates/quoridor-runner/src/measurement.rs"
PY = "scripts/dev/research-lifecycle.py"
OLD_TEST = "crates/quoridor-ai/src/lmr400_tests.rs"
NEW_TEST = "crates/quoridor-ai/src/lmr408_tests.rs"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def block(source, marker):
    start = source.index(marker)
    cursor = source.index("{", start) + 1
    level = 1
    while level:
        level += (source[cursor] == "{") - (source[cursor] == "}")
        cursor += 1
    return source[start:cursor]


def function(source, name):
    found = list(
        re.finditer(r"(?m)^    (?:pub )?fn " + re.escape(name) + r"\(", source)
    )
    assert len(found) == 1, (name, len(found))
    return block(source, found[0].group())


before = {
    rel: (INPUT / (Path(rel).name + ".before")).read_text()
    for rel in (AI, MEASURE, OLD_TEST)
}
before[PY] = (INPUT / "publisher.before").read_text()
before[NEW_TEST] = ""
after = {rel: (INPUT / Path(rel).name).read_text() for rel in (AI, MEASURE, OLD_TEST)}
after[NEW_TEST] = (HERE / "lmr408_tests.rs").read_text()
fragment = (HERE / "measurement_config.before.py").read_text()
updated = (INPUT / "measurement_config.py").read_text()
assert before[PY].count(fragment) == 1
after[PY] = before[PY].replace(fragment, updated)
assert before[PY].replace(fragment, "") == after[PY].replace(updated, "")
(HERE / "measurement_config.after.py").write_text(updated)
old_py, new_py = ast.parse(before[PY]), ast.parse(after[PY])
old_nodes = {
    n.name: n for n in old_py.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))
}
new_nodes = {
    n.name: n for n in new_py.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))
}
assert old_nodes.keys() == new_nodes.keys()
assert all(
    name == "measurement_config" or ast.dump(node) == ast.dump(new_nodes[name])
    for name, node in old_nodes.items()
)
protected = {}
for name in [
    "control",
    "enter",
    "child",
    "zero_stock_approx_leaf",
    "zero_stock_approx_value",
    "set_zero_stock_approx_method",
    "set_zero_stock_approx_min_root_walls",
    "set_zero_stock_approx_effective",
    "root_depth",
    "ordered",
    "eager_ordered",
    "prepared_moves",
    "ordering_scores",
    "shared_signed_ordering",
    "lmr_allowed",
    "pv",
]:
    assert function(before[AI], name) == function(after[AI], name), name
    protected[name] = sha(function(after[AI], name).encode())
old = function(before[AI], "negamax")
new = function(after[AI], "negamax")
old_start = old.index("            let reduced = self.lmr")
old_end = old.index("            let mut v =", old_start)
new_start = new.index("            let reduction =")
new_end = new.index("            let mut v =", new_start)
loop_before, loop_after = old[old_start:old_end], new[new_start:new_end]
restored = new[:new_start] + loop_before + new[new_end:]
restored, count = re.subn(
    r"self\.reduced_child\(\s*c,\s*a,\s*action,\s*\[depth - 1, depth - 1 - reduction\],\s*alpha,\s*ply \+ 1,?\s*\)\?",
    "self.reduced_child(c, a, action, depth - 1, alpha, ply + 1)?",
    restored,
)
assert count == 1 and restored == old, (
    "negamax outside quantum selection/depth argument changed"
)
old_reduced, new_reduced = (
    function(before[AI], "reduced_child"),
    function(after[AI], "reduced_child"),
)
restored = new_reduced.replace("child_depths: [u16; 2]", "child_depth: u16")
restored = restored.replace(
    "        let [child_depth, reduced_depth] = child_depths;\n        debug_assert!(reduced_depth < child_depth);\n",
    "",
)
restored = restored.replace(
    "            reduced_depth,", "            child_depth - 1,"
)
assert restored == old_reduced, "confirmation or interruption behavior changed"
assert (
    function(before[AI], "set_lmr").split("        if enabled != self.lmr", 1)[0]
    == function(after[AI], "set_lmr").split("        self.change_lmr", 1)[0]
)
# The old fixture definitions only migrate the private helper's depth argument.
restored = after[OLD_TEST].replace("[2, 1]", "2")
assert "".join(restored.split()) == "".join(before[OLD_TEST].split())
assert after[OLD_TEST].count("[2, 1]") == 3
assert ".ln()" not in function(after[AI], "negamax")
assert "get_or_init" not in function(after[AI], "negamax")
for name in ["replay", "identity", "validate_return"]:
    marker = "fn " + name + "("
    assert block(before[MEASURE], marker) == block(after[MEASURE], marker), name
subjects = {
    "AI::LMR quantum selection": {"before": loop_before, "after": loop_after},
    "AI::reduced_child": {"before": old_reduced, "after": new_reduced},
    "AI::set_lmr": {
        "before": function(before[AI], "set_lmr"),
        "after": function(after[AI], "set_lmr"),
    },
    "AI::LmrMethod": {"before": None, "after": block(after[AI], "impl LmrMethod {")},
    "AI::change_lmr": {"before": None, "after": function(after[AI], "change_lmr")},
    "Python::measurement_config": {"before": fragment, "after": updated},
}
(HERE / "subjects.json").write_text(json.dumps(subjects, indent=2) + "\n")
forward, inverse = [], []
for rel in (AI, MEASURE, PY, OLD_TEST, NEW_TEST):
    old_path = "/dev/null" if rel == NEW_TEST else "a/" + rel
    forward.extend(
        difflib.unified_diff(
            before[rel].splitlines(keepends=True),
            after[rel].splitlines(keepends=True),
            fromfile=old_path,
            tofile="b/" + rel,
        )
    )
    inverse.extend(
        difflib.unified_diff(
            after[rel].splitlines(keepends=True),
            before[rel].splitlines(keepends=True),
            fromfile="b/" + rel,
            tofile=old_path,
        )
    )
(HERE / "lmr408.patch").write_text("".join(forward))
(HERE / "lmr408.inverse.patch").write_text("".join(inverse))
tree = TMP / "roundtrip"
tree.mkdir()
for rel, text in before.items():
    if rel == NEW_TEST:
        continue
    path = tree / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
commands = []
for filename, wanted in [("lmr408.patch", after), ("lmr408.inverse.patch", before)]:
    argv = ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(HERE / filename)]
    done = subprocess.run(argv, check=True, capture_output=True, text=True, cwd=tree)
    assert not re.search(r"offset|fuzz|FAILED|reject", done.stdout + done.stderr, re.I)
    commands.append(
        {
            "argv": argv,
            "returncode": done.returncode,
            "stdout": done.stdout,
            "stderr": done.stderr,
        }
    )
    for rel, text in wanted.items():
        if rel == NEW_TEST and not text:
            assert not (tree / rel).exists()
        else:
            assert (tree / rel).read_text() == text, rel
binding = json.loads((HERE / "base-components.json").read_text())
binding.update(
    after=[
        {
            "relative": rel,
            "sha256": sha(text.encode()),
            "bytes": len(text.encode()),
            "mode": "0644",
            "reconstruction": "frozen407 prospective postimage + lmr408.patch",
        }
        for rel, text in after.items()
    ],
    protected_AI_function_sha256=protected,
    strict_forward_inverse="PASS, zero offsets/fuzz and new absence restored",
    publisher_outside_measurement_config="BYTE EXACT",
    negamax_outside_quantum_selection_and_depth_argument="BYTE EXACT",
    reduced_child_normal_confirmation_and_error_contract="BYTE EXACT after depth-argument substitution",
    existing_lmr400_test_migration="three private calls: normal/reduced depths [2,1], otherwise unchanged tokens/strings",
    standard_patch_directwait=commands,
    namespace_runtime_companion="408.2 owns exact Option<LmrMethod> caller; config.rs one optional field Root composition, no runtime/arena mutation here",
)
(HERE / "source-binding.json").write_text(json.dumps(binding, indent=2) + "\n")
runner_test = function(
    after[MEASURE],
    "measurement408_lmr_method_default_refusal_namespace_and_result_roundtrip",
)
(HERE / "measurement408_test.rs").write_text(runner_test + "\n")
tests = re.findall(r"(?m)^fn (lmr408_\w+)\(", after[NEW_TEST])
assert len(tests) == 5
plan = {
    "new_AI": {
        "filter": "lmr408_",
        "features": ["research", "research-diagnostics"],
        "expected_each": 5,
        "definitions": tests,
        "status": "UNBUILT/UNTYPED/UNRUN",
    },
    "new_runner": {
        "filter": "measurement408_lmr_method_default_refusal_namespace_and_result_roundtrip",
        "expected": 1,
        "status": "UNBUILT/UNTYPED/UNRUN",
    },
    "new_Python_NN0": {
        "filter": "LmrMethod408Tests.test_exact_lmr_method_names_default_and_off_activation_independence",
        "expected": 1,
        "status": "NOT_RUN",
    },
    "affected_selections": [
        "lmr400_method_profile_switch_and_reset_clear_real_tt_and_keep_defaults_off",
        "lmr400_eligibility_uses_frozen_rank_for_tt_goal_killers_and_exact_late_boundary",
    ],
    "affected_private_depth_signature": [
        name
        for name in re.findall(r"(?m)^fn (lmr400_\w+)\(", before[OLD_TEST])
        if ".reduced_child(" in block(before[OLD_TEST], "fn " + name + "(")
    ],
    "affected_note": "Select only definitions owning the changed helper/namespace after Root evaluates accepted prior evidence; no whole suite replay. Three old helper calls have mechanical [2,1] arguments.",
    "required_Root": [
        "research/research-diagnostics compile",
        "affected Clippy/release",
        "one related reduction/rank/confirmation/TT/consumer review",
    ],
    "author_native_calls": 0,
    "science": "Root only, original authorized96/128; author grants none",
}
(HERE / "verification-plan.json").write_text(json.dumps(plan, indent=2) + "\n")
# Delete only this task's successful temporary source reconstructions/cache.
shutil.rmtree(tree)
for path in INPUT.iterdir():
    if path.is_dir():
        assert path.name in {"base407", "ruff-cache"}
        shutil.rmtree(path)
    else:
        assert path.name in {
            "alphabeta.rs",
            "alphabeta.rs.before",
            "measurement.rs",
            "measurement.rs.before",
            "lmr400_tests.rs",
            "lmr400_tests.rs.before",
            "publisher.before",
            "measurement_config.py",
        }
        path.unlink()
INPUT.rmdir()
print(
    json.dumps(
        {
            "strict_roundtrip": "PASS",
            "protected_AI_functions": len(protected),
            "new_AI": len(tests),
            "new_runner": 1,
            "new_Python": 1,
            "native": "UNBUILT/UNTYPED/UNRUN",
        }
    )
)
