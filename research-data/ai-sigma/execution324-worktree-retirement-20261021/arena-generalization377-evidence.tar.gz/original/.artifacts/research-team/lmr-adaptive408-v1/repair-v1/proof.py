"""Static-only proof for one already-entered fixture's counter denominator."""

import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
INPUT = HERE / "prepare-v1/TMP"
TMP = Path(os.environ["TMPDIR"])
REL = "crates/quoridor-ai/src/lmr408_tests.rs"
TARGET = "lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial"


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def function(source, name):
    start = source.index("fn " + name + "(")
    end = source.index("{", start) + 1
    depth = 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start:end]


before = (INPUT / "before.rs").read_text()
after = (INPUT / "lmr408_tests.rs").read_text()
old, new = function(before, TARGET), function(after, TARGET)
assert before.replace(old, "") == after.replace(new, "")
other = {}
for name in re.findall(r"(?m)^fn (lmr408_\w+)\(", before):
    if name != TARGET:
        body = function(before, name)
        assert body == function(after, name), name
        other[name] = sha(body)
assert len(other) == 4
assert "assert_eq!(s.stats.tt_exact_hits, 5);" in new
assert "assert_eq!(s.stats.tt_usable_depth, 4);" in new
assert "assert_eq!(s.stats.tt_cutoffs, 4);" in new
assert "assert!(s.stats.tt_order_only > 0);" in new
assert (
    "(s.stats.lmr_attempts, s.stats.lmr_full_depth_confirmations),\n                (0, 0)"
    in new
)
assert (
    "assert_eq!((Key::of(c), c.history_counts(), s.context, s.board), before);" in new
)
assert "assert!(s.path.is_empty());" in new
for file, a, b, old_path, new_path in [
    ("fixture.patch", before, after, "a/" + REL, "b/" + REL),
    ("fixture.inverse.patch", after, before, "b/" + REL, "a/" + REL),
]:
    (HERE / file).write_text(
        "".join(
            difflib.unified_diff(
                a.splitlines(keepends=True),
                b.splitlines(keepends=True),
                fromfile=old_path,
                tofile=new_path,
            )
        )
    )
tree = TMP / "roundtrip"
path = tree / REL
path.parent.mkdir(parents=True)
path.write_text(before)
commands = []
for file, expected in [("fixture.patch", after), ("fixture.inverse.patch", before)]:
    argv = ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(HERE / file)]
    done = subprocess.run(argv, cwd=tree, check=True, capture_output=True, text=True)
    assert not re.search(r"offset|fuzz|FAILED|reject", done.stdout + done.stderr, re.I)
    assert path.read_text() == expected
    commands.append(
        {
            "argv": argv,
            "exit_code": done.returncode,
            "stdout": done.stdout,
            "stderr": done.stderr,
        }
    )
(HERE / "definition.before.rs").write_text(old + "\n")
(HERE / "definition.after.rs").write_text(new + "\n")
intake = json.loads((HERE / "intake.json").read_text())
binding = {
    "relative": REL,
    "original_source_STOP": intake["original_source_STOP"],
    "before": intake["original_fixture"],
    "after": {
        "relative": REL,
        "sha256": sha(after),
        "bytes": len(after.encode()),
        "mode": "0644",
        "reconstruction": "frozen original fixture plus fixture.patch",
    },
    "only_changed_definition": TARGET,
    "protected_four_definition_sha256": other,
    "outside_target_definition": "BYTE EXACT",
    "production_changes": 0,
    "strict_forward_inverse": "PASS: zero fuzz/offset and exact full-file restoration",
    "patch_directwait": commands,
    "intake_semantics": "intake.json",
    "native_type_test_status": "UNBUILT/UNTYPED/UNRUN",
}
(HERE / "source-binding.json").write_text(json.dumps(binding, indent=2) + "\n")
(HERE / "verification-plan.json").write_text(
    json.dumps(
        {
            "only_repaired_definition": "alphabeta::lmr408_tests::" + TARGET,
            "package": "quoridor-ai",
            "feature": "research-diagnostics",
            "lib": True,
            "test_args": ["--exact", "--nocapture", "--test-threads=1"],
            "expected": 1,
            "author_execution": "UNBUILT/UNTYPED/UNRUN",
            "four_original_pass_definitions": "NOT rerun; retain actual original FAILED-build scope",
            "Root_remaining": "repaired1 plus genuinely unentered remaining software; same existing reviewer only",
            "production_science_changes": 0,
        },
        indent=2,
    )
    + "\n"
)
shutil.rmtree(tree)
(INPUT / "before.rs").unlink()
(INPUT / "lmr408_tests.rs").unlink()
INPUT.rmdir()
print(
    json.dumps(
        {
            "strict_roundtrip": "PASS",
            "other_definitions_byte_exact": len(other),
            "only_repaired_definition": TARGET,
            "native": "UNBUILT/UNTYPED/UNRUN",
        }
    )
)
