"""Root-only NN0 definition against the maintained function, never run by author."""

import ast
import copy
from pathlib import Path
import unittest


class LmrMethod408Tests(unittest.TestCase):
    def test_exact_lmr_method_names_default_and_off_activation_independence(self):
        path = Path("/workspaces/quoridor/scripts/dev/research-lifecycle.py")
        node = next(
            n
            for n in ast.parse(path.read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == "measurement_config"
        )

        def require(condition, message):
            if not condition:
                raise ValueError(message)

        env = {"document": lambda value: value, "require": require}
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec"), env)
        config = {
            "roots": [{"input": 0, "pointer": "", "field": "moves", "label": "toy"}],
            "profile": "control",
            "tt_entries": 4096,
            "use_tt": True,
            "use_pvs": True,
            "namespace": {
                "evaluator": "toy",
                "rules": "standard",
                "selectivity": "toy",
            },
            "output_bytes": 10000,
            "record_bytes": 1000,
        }
        experiment = {
            "config": config,
            "schedule": [],
            "rules": "standard",
            "inputs": [{}],
        }
        check = env["measurement_config"]
        self.assertEqual(check(copy.deepcopy(experiment))[0], config)
        for method in ["fixed_one", "depth_rank"]:
            for enabled in [False, True]:
                selected = copy.deepcopy(experiment)
                selected["config"].update(lmr_method=method, lmr=enabled)
                self.assertEqual(check(selected)[0], selected["config"])
        for method in [None, True, False, 0, 1.0, "", "adaptive", "DepthRank", [], {}]:
            with self.subTest(method=method), self.assertRaises(ValueError):
                selected = copy.deepcopy(experiment)
                selected["config"]["lmr_method"] = method
                check(selected)


if __name__ == "__main__":
    unittest.main()
