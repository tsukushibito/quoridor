"""One source STOP with real process/receipt facts; no new authority mechanism."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path


def freeze(lc, here):
    def ref(path):
        data = path.read_bytes()
        return {
            "path": str(path),
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
            "mode": f"{path.stat().st_mode & 0o777:04o}",
        }

    phases, census = [], []
    for phase in (
        "api-send-v1",
        "api-send-v2",
        "signature-send-v1",
        "prepare-v1",
        "proof-v1",
        "quality-v1",
    ):
        directory = here / phase
        path = directory / "result.json"
        phase_result = json.loads(path.read_text())
        assert phase_result["status"] == (
            "FAILED" if phase == "api-send-v1" else "PASS"
        ), phase
        assert not (directory / "TMP").exists(), phase
        phases.append(ref(path))
        for check in phase_result["checks"]:
            returned = check["guardian_return"]
            disk = json.loads(
                Path(check["persisted_process_receipt"]["path"]).read_text()
            )
            observed = returned if returned is not None else disk
            if returned is not None:
                lc.settled(returned)
                assert check["capture_complete"] and check["status"] == "PASS"
            else:
                assert phase == "api-send-v1" and check["status"] == "FAILED"
            assert observed["direct_child_reaped"] and observed["cleanup_complete"]
            assert observed["handle_closes_complete"] and observed["remaining"] == []
            child = observed["child"]
            current = lc.process.process_info(child["pid"])
            assert current is None or lc.process.identity(current) != child, child
            census.append(
                {
                    "phase": phase,
                    "name": check["name"],
                    "status": check["status"],
                    "original_child": child,
                    "fresh_identity": lc.process.identity(current),
                    "identity_state": "absent"
                    if current is None
                    else "different identity",
                    "directwait_reap_cleanup_handles": True,
                    "guardian_return": "available" if returned is not None else None,
                    "returned_signal_mask_restoration": returned.get(
                        "signal_mask_restoration"
                    )
                    if returned
                    else "UNKNOWN",
                    "returned_final_record_persist": returned.get(
                        "final_record_persist"
                    )
                    if returned
                    else "UNKNOWN",
                    "persisted_signal_mask_restoration": disk.get(
                        "signal_mask_restoration"
                    ),
                    "persisted_final_record_persist": disk.get("final_record_persist"),
                    "no_new_privs": observed["launch_policy"],
                    "capture_complete_in_original_return_scope": check[
                        "capture_complete"
                    ],
                    "full_log": check["full_log"],
                    "persisted_receipt": check["persisted_process_receipt"],
                    "original_seconds_once": observed.get("wall_seconds"),
                }
            )
    files = [
        "source-binding.json",
        "base-components.json",
        "lmr408.patch",
        "lmr408.inverse.patch",
        "subjects.json",
        "lmr408_tests.rs",
        "measurement408_test.rs",
        "measurement_config.before.py",
        "measurement_config.after.py",
        "measurement_config408_tests.py",
        "verification-plan.json",
        "report-ja.md",
        "applied-context.json",
        "api-to-arena.txt",
        "api-signature.txt",
        "temporary-cleanup.json",
        "guarded.py",
        "prepare.py",
        "proof.py",
        "cleanup.py",
        "finish.py",
    ]
    usage = lc.process.directory_bytes(here)
    fs = os.statvfs(here)
    result = {
        "issue": "quoridor-4lc.408.1",
        "status": "SOURCE_STOPPED_PRIVATE_PROPOSAL_ONLY",
        "source_reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
        "prospective_base": "frozen407 postimages based on7bf4e3a4; Root reconciles aa233e3 ordinary repairs sparsely",
        "refs": {name: ref(here / name) for name in files},
        "phases": phases,
        "fresh_process_census": census,
        "readers": [],
        "writers": [],
        "children": [],
        "jobs": [],
        "handles": [],
        "TMP": [],
        "leases": [],
        "owned": [],
        "canonical_lease": "not acquired: immutable private source; no future quietness claim",
        "native_type_test_status": "UNBUILT/UNTYPED/UNRUN",
        "new_definitions": {"AI": 5, "runner": 1, "Python_NN0": 1},
        "native_Cargo_model_Search_Perf_game_review_dispatch": 0,
        "Main_managed_source_406_407_Beads_writes": 0,
        "storage": {
            "budget": None,
            "directed_own_allocated_B": usage,
            "dedupe": "existing directory_bytes device/inode over OWN408 only",
            "excludes": "final STOP write/stdout and later324 delivery/admin",
            "FS_available_B": fs.f_bavail * fs.f_frsize,
            "global_actual": "UNKNOWN; no global scan",
        },
        "original_failure": "api-send-v1 active session cwd refusal retained; no accepted delivery there, guardian NULL and disk masks retained",
        "API_delivery": {
            "initial": ref(here / "api-send-v2/api-send.full.log"),
            "requested_signature_answer": ref(
                here / "signature-send-v1/api-signature-send.full.log"
            ),
        },
        "Beads_status_backup": "324 only; leaf in_progress",
        "Root_remaining": "sparse composition/software/review/authorized96 and128 only; author scientific calls0",
        "pauses": "mixed/learner all preparation/pipeline and323 USERPAUSE unchanged",
    }
    (here / "source-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {"source_STOP": ref(here / "source-STOP.json"), "usage": usage, "owned": []}
        )
    )
