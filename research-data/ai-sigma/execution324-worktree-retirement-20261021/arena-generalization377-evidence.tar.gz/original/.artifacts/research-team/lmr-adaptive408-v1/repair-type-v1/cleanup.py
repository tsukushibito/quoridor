"""Clean reconstructible source-helper TMP after actual failed-child cleanup."""

import hashlib
import json
import os
from pathlib import Path
import shutil

from quoridor_training import cycle_process

HERE = Path(__file__).resolve().parent
result = json.loads((HERE / "prepare-v1/result.json").read_text())
assert result["status"] == "FAILED"
check = result["checks"][0]
assert check["guardian_return"] is None
record = json.loads(Path(check["persisted_process_receipt"]["path"]).read_text())
assert (
    record["cleanup_complete"]
    and record["direct_child_reaped"]
    and record["remaining"] == []
)
assert record["handle_closes_complete"]
current = cycle_process.process_info(record["child"]["pid"])
assert current is None or cycle_process.identity(current) != record["child"]
binding = json.loads((HERE / "source-binding.json").read_text())
expected = {
    "before.rs": binding["before"]["sha256"],
    "alphabeta.rs": binding["after"]["sha256"],
}
tmp = HERE / "prepare-v1/TMP"
removed = []
assert {p.name for p in tmp.iterdir()} == set(expected)
for path in tmp.iterdir():
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == expected[path.name], "keep unique failure output if it differs"
    removed.append(
        {
            "path": str(path),
            "sha256": digest,
            "bytes": len(data),
            "reconstruction": "immutable45d source or immutable45d+type-alias.patch; failed-prepare-v1.py retained",
        }
    )
    path.unlink()
tmp.rmdir()
quality = json.loads((HERE / "quality-v1/result.json").read_text())
assert quality["status"] == "FAILED"
failed = quality["checks"][-1]
assert failed["name"] == "rustfmt-check" and failed["guardian_return"] is None
disk = json.loads(Path(failed["persisted_process_receipt"]["path"]).read_text())
assert (
    disk["direct_child_reaped"] and disk["cleanup_complete"] and disk["remaining"] == []
)
assert disk["handle_closes_complete"]
current = cycle_process.process_info(disk["child"]["pid"])
assert current is None or cycle_process.identity(current) != disk["child"]
quality_tmp = HERE / "quality-v1/TMP"
assert {p.name for p in quality_tmp.iterdir()} == {"ruff-cache"}
shutil.rmtree(quality_tmp / "ruff-cache")
quality_tmp.rmdir()
cache = Path(os.environ["RUFF_CACHE_DIR"])
if cache.exists():
    assert cache.name == "ruff-cache" and cache.parent == Path(os.environ["TMPDIR"])
    shutil.rmtree(cache)
(HERE / "temporary-cleanup.json").write_text(json.dumps(removed, indent=2) + "\n")
print(
    json.dumps(
        {
            "reconstructible_failed_helper_TMP_removed": len(removed),
            "original_failure_captures_receipts": "unchanged",
        }
    )
)
