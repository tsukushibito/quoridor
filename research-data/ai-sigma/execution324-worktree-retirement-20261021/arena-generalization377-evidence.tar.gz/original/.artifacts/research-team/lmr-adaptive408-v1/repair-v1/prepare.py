"""One counter-denominator fixture repair, from frozen source and canonical TT."""

import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE.parent
TMP = Path(os.environ["TMPDIR"])
TEST = "crates/quoridor-ai/src/lmr408_tests.rs"
ALPHA = "crates/quoridor-ai/src/alphabeta.rs"
TARGET = "lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verified(path, expected):
    data = path.read_bytes()
    assert sha(data) == expected["sha256"] and len(data) == expected["bytes"]
    assert path.stat().st_mode & 0o777 == int(expected["mode"], 8)
    return data


def function(source, marker):
    start = source.index(marker)
    end = source.index("{", start) + 1
    level = 1
    while level:
        level += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start:end]


stop_ref = {
    "path": str(ORIGINAL / "source-STOP.json"),
    "sha256": "397930aea23950f7d36fdd0f31af111113ac5e508656bac21fb24fd8f3b283ca",
    "bytes": 28986,
    "mode": "0644",
}
stop = json.loads(verified(Path(stop_ref["path"]), stop_ref))
before_ref = stop["refs"]["lmr408_tests.rs"]
before = verified(Path(before_ref["path"]), before_ref).decode()
commands = []


def git_object(rel):
    argv = [
        "git",
        "--no-optional-locks",
        "-C",
        "/workspaces/quoridor",
        "show",
        "00c9f83:" + rel,
    ]
    result = subprocess.run(argv, check=True, capture_output=True)
    commands.append(
        {"argv": argv, "exit_code": result.returncode, "stderr": result.stderr.decode()}
    )
    return result.stdout.decode()


assert git_object(TEST) == before, (
    "Root composition fixture differs from frozen author fixture"
)
alpha = git_object(ALPHA)
probe_owned = function(alpha, "    fn probe_owned(")
probe_hashed = function(alpha, "    fn probe_hashed(")
assert "self.probe_hashed(" in probe_owned
assert (
    "stats.tt_exact_hits += u64::from(matches!(entry.bound, Bound::Exact));"
    in probe_hashed
)
assert "stored_depth" not in probe_hashed
depth_begin = alpha.index(
    "                if context_matches && stored_depth == depth {"
)
depth_end = alpha.index("        let legal = legal.unwrap_or_else", depth_begin)
depth_clause = alpha[depth_begin:depth_end]
assert "self.stats.tt_usable_depth += 1;" in depth_clause
assert "self.stats.tt_cutoffs += 1;" in depth_clause
assert "self.stats.tt_order_only += 1;" in depth_clause
old = "            assert_eq!(s.stats.tt_exact_hits, 4);"
new = """            // Matching Exact-bound probes include the wrong-depth parent;
            // only the four full-depth child hits are numerically usable.
            assert_eq!(s.stats.tt_exact_hits, 5);
            assert_eq!(s.stats.tt_usable_depth, 4);
            assert_eq!(s.stats.tt_cutoffs, 4);"""
assert before.count(old) == 1
after = before.replace(old, new)
(TMP / "lmr408_tests.rs").write_text(after)
(TMP / "before.rs").write_text(before)
(HERE / "intake.json").write_text(
    json.dumps(
        {
            "original_source_STOP": stop_ref,
            "original_fixture": before_ref,
            "Root_composition_test_correspondence": "00c9f83 fixture BYTE EXACT to frozen author fixture",
            "canonical_TT": {
                "git_object": "00c9f83:" + ALPHA,
                "sha256": sha(alpha.encode()),
                "bytes": len(alpha.encode()),
                "probe_owned": probe_owned,
                "probe_hashed": probe_hashed,
                "depth_qualification_clause": depth_clause,
            },
            "git_object_directwait": commands,
            "only_definition": TARGET,
            "native_type_test_status": "UNBUILT/UNTYPED/UNRUN",
        },
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "status": "static fixture repair prepared",
            "raw_exact": "parent1+children4=5",
            "numeric_depth_qualified": 4,
        }
    )
)
