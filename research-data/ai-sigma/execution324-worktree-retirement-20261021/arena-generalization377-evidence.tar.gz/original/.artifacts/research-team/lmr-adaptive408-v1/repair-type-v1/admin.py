"""Metadata-only cleanup after the one accepted324 delivery."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat

from quoridor_training import cycle_process

HERE = Path(__file__).resolve().parent
saved = json.loads((HERE / "root-send-v1/result.json").read_text())
check = saved["checks"][0]
record = check["guardian_return"]
assert saved["status"] == "PASS" and check["capture_complete"]
assert record["direct_child_reaped"] and record["cleanup_complete"]
assert record["remaining"] == [] and record["handle_closes_complete"]
receipt = json.loads((HERE / "root-send-v1/root-send.full.log").read_text())
assert receipt["accepted"] is True
current = cycle_process.process_info(record["child"]["pid"])
assert current is None or cycle_process.identity(current) != record["child"]
tmp = HERE / "root-send-v1/TMP"
removed = []
for path in tmp.iterdir():
    info = path.lstat()
    assert path.name.startswith("uv-") and path.suffix == ".lock"
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
    removed.append(
        {
            "path": str(path),
            "bytes": info.st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
    )
    path.unlink()
tmp.rmdir()
cache = Path(os.environ["RUFF_CACHE_DIR"])
if cache.exists():
    assert cache.name == "ruff-cache" and cache.parent == Path(os.environ["TMPDIR"])
    shutil.rmtree(cache)
result = {
    "admin_STOP": datetime.now(timezone.utc).isoformat(),
    "source_STOP_unchanged": "STOP.json",
    "Root_delivery": receipt,
    "original_delivery_child": record["child"],
    "fresh_delivery_identity": cycle_process.identity(current),
    "ordinary_TMP_cleanup": removed,
    "owned": [],
    "TMP": [],
    "leases": [],
    "Beads_writes": 0,
    "final_admin_guardian_receipt": str(HERE / "admin-v1/result.json"),
}
(HERE / "admin-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
