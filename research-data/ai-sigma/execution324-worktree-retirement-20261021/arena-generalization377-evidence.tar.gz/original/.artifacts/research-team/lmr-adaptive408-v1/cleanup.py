"""Normal cleanup of only this leaf's stopped delivery temporary lock files."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import stat

from quoridor_training import cycle_process

HERE = Path(__file__).resolve().parent
removed = []
for stage in ("api-send-v1", "api-send-v2", "signature-send-v1"):
    result = json.loads((HERE / stage / "result.json").read_text())
    check = result["checks"][0]
    returned = check["guardian_return"]
    record = returned or json.loads(
        Path(check["persisted_process_receipt"]["path"]).read_text()
    )
    assert (
        record["direct_child_reaped"]
        and record["cleanup_complete"]
        and record["remaining"] == []
    )
    assert record["handle_closes_complete"]
    current = cycle_process.process_info(record["child"]["pid"])
    assert current is None or cycle_process.identity(current) != record["child"]
    tmp = HERE / stage / "TMP"
    for path in tmp.iterdir():
        info = path.lstat()
        assert path.name.startswith("uv-") and path.suffix == ".lock"
        assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
        removed.append(
            {
                "path": str(path),
                "bytes": info.st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "returned_guardian_available": returned is not None,
            }
        )
        path.unlink()
    tmp.rmdir()
cache = Path(os.environ["RUFF_CACHE_DIR"])
if cache.exists():
    assert cache.name == "ruff-cache" and cache.parent == Path(os.environ["TMPDIR"])
    shutil.rmtree(cache)
(HERE / "temporary-cleanup.json").write_text(json.dumps(removed, indent=2) + "\n")
print(
    json.dumps({"owned_delivery_TMP": [], "removed_own_temporary_locks": len(removed)})
)
