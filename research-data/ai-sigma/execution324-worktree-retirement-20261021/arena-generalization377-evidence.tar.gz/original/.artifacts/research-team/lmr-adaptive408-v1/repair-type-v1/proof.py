"""Verify a type alias substitution only, never compile or execute Rust."""

import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
INPUT = HERE / "prepare-v2/TMP"
TMP = Path(os.environ["TMPDIR"])
REL = "crates/quoridor-ai/src/alphabeta.rs"
before = (INPUT / "before.rs").read_text()
after = (INPUT / "alphabeta.rs").read_text()
start = after.index("type SearchTableAndDomain<")
end = after.index("\n\nfn search_in_table(", start) + 2
alias = after[start:end]
old_start = before.index(
    "    table_and_domain: (", before.index("\nfn search_in_table(")
)
old_end = before.index("    ),", old_start) + len("    ),")
old_type = before[old_start:old_end]
new_type = "    table_and_domain: SearchTableAndDomain<'_, '_>,"
assert after.count(new_type) == 1 and after.count("type SearchTableAndDomain<") == 1
restored = after[:start] + after[end:]
restored = restored.replace(new_type, old_type)
assert restored == before, "changes extend beyond alias declaration/signature type"
old_body_start = before.index(") -> Result<SearchResult> {", old_end) + len(
    ") -> Result<SearchResult> "
)
new_body_start = after.index(
    ") -> Result<SearchResult> {", after.index(new_type)
) + len(") -> Result<SearchResult> ")
assert before[old_body_start:] == after[new_body_start:], (
    "function body or later subjects changed"
)
underlying = alias.split("=", 1)[1].strip().rstrip(";")
underlying = underlying.replace("&'table mut", "&mut").replace("&'history mut", "&mut")
previous = old_type.split(":", 1)[1].strip().rstrip(",")
assert "".join(underlying.split()) == "".join(previous.split()), (
    "representation differs"
)
assert "<'table, 'history>" in alias and "pub type" not in alias
assert "#[allow" not in alias and "Box" not in alias and "dyn " not in alias
for filename, a, b, a_path, b_path in [
    ("type-alias.patch", before, after, "a/" + REL, "b/" + REL),
    ("type-alias.inverse.patch", after, before, "b/" + REL, "a/" + REL),
]:
    (HERE / filename).write_text(
        "".join(
            difflib.unified_diff(
                a.splitlines(keepends=True),
                b.splitlines(keepends=True),
                fromfile=a_path,
                tofile=b_path,
            )
        )
    )
tree = TMP / "roundtrip"
path = tree / REL
path.parent.mkdir(parents=True)
path.write_text(before)
commands = []
for filename, expected in [
    ("type-alias.patch", after),
    ("type-alias.inverse.patch", before),
]:
    argv = ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(HERE / filename)]
    result = subprocess.run(argv, cwd=tree, capture_output=True, text=True, check=True)
    assert not re.search(
        r"offset|fuzz|FAILED|reject", result.stdout + result.stderr, re.I
    )
    assert path.read_text() == expected
    commands.append(
        {
            "argv": argv,
            "exit_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    )
intake = json.loads((HERE / "intake.json").read_text())
binding = {
    "before": intake["before"],
    "after": {
        "relative": REL,
        "sha256": hashlib.sha256(after.encode()).hexdigest(),
        "bytes": len(after.encode()),
        "mode": "0644",
        "reconstruction": "immutable45d source plus type-alias.patch",
    },
    "only_change": "private SearchTableAndDomain<'table,'history> alias plus parameter type substitution",
    "independent_reference_lifetimes": "preserved as two explicit alias parameters, no equality requirement",
    "underlying_type": "TOKEN EXACT after lifetime naming; same tuple representation",
    "function_body_and_remaining_tail": "BYTE EXACT",
    "function_body_and_tail_sha256": hashlib.sha256(
        after[new_body_start:].encode()
    ).hexdigest(),
    "entire_source_outside_alias_and_type_substitution": "BYTE EXACT",
    "strict_roundtrip": "PASS zero fuzz/offset and exact inverse restoration",
    "patch_directwait": commands,
    "native_type_test_status": "UNBUILT/UNTYPED/UNRUN",
}
(HERE / "source-binding.json").write_text(json.dumps(binding, indent=2) + "\n")
(HERE / "type.before.txt").write_text(old_type + "\n")
(HERE / "type.after.rs").write_text(alias.rstrip() + "\n")
(HERE / "verification-plan.json").write_text(
    json.dumps(
        {
            "Root_only": [
                "original failed research Clippy -D warnings",
                "genuinely unentered diagnostics/runner Clippy/release",
            ],
            "tests": "NO assertion reruns; all13 selected PASS retain original v4FAILED scope and original4PASS retain v2FAILED scope",
            "review": "no new mathematical review for alias-only repair",
            "author_native_type_test": "UNBUILT/UNTYPED/UNRUN",
            "original_failures": "v4type_complexity and source helper prepare-v1 parser failure retained separately",
        },
        indent=2,
    )
    + "\n"
)
shutil.rmtree(tree)
(INPUT / "before.rs").unlink()
(INPUT / "alphabeta.rs").unlink()
INPUT.rmdir()
print(
    json.dumps(
        {
            "type_representation": "unchanged",
            "all_bodies": "BYTE EXACT",
            "strict_roundtrip": "PASS",
            "native": "UNBUILT/UNTYPED/UNRUN",
        }
    )
)
