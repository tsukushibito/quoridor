# 408 Clippy：既存tupleのprivate型alias

immutable Main `45d55c61468b83012a144c098eb73080e4911296` の `search_in_table::table_and_domain` に対する、原v4の `clippy::type_complexity` 一件だけを扱う。元logから該当compiler messageだけを保存し、Cargo JSON全体は表示していない。

既存tupleをprivate `SearchTableAndDomain<'table, 'history>` へ命名し、引数を `SearchTableAndDomain<'_, '_>` とした。元から独立したTable参照とContinuationHistory参照に別々の明示lifetimeを与え、同一lifetime制約を追加しない。全要素と順序は元のtupleのままであり、新しいstruct/configstate、public API、heap、clone、dynamic dispatch、lint allowはない。

alias宣言と引数の型置換を戻すと全文byte exact。関数本体とそれ以降もbyte exact、underlying tupleはlifetimeの命名を除きtoken exactである。標準patch fuzz0/offset0のforward/inverse、対象Rustfmtと静的lintを確認する。Rust型確認・Clippy・native/testは作者未実行で、修復後はUNBUILT/UNTYPED/UNRUN。

Rootは失敗したresearch Clippyと、本当に未入場のdiagnostics/runner Clippy/releaseだけを続ける。既にPASSした13 assertionsと元v2の他4PASSは元FAILED buildのscopeを保持し、再演しない。LMR方式/表/順位/保護/TT/undo/math/counter、O1のnull拒否、counterfixture修復には触れていない。数学source reviewの再dispatchも行わない。

作者の最初の診断抽出helperはlogをJSONと仮定しFAILEDになった。元failed-prepare-v1.py、fullcapture、guardian NULL、disk mask/費を保存し、actual Clippy textの該当範囲だけを読む処理へ通常修復した。再構成可能な一時sourceはhash一致を確認してcleanupし、独自retry loopや実softwareの再演はない。

全文moduleはRustfmt済みだが、抽出したstandalone alias snapshotの末尾空行だけで追加checkがFAILEDになった。元fragment/receiptを保持し、snapshot単体の整形だけを直した。production patch/after hashや関数本体は変更していない。失敗時のhelper/configは履歴として凍結し、現役helperと新commandだけを対象整形する。

writerはrepair-type-v1だけ。CPU3/guardian7/family768MiB/GPU0/host reserve4GiB、既存guard/取消/directwait/reap/capture/handles/TMPを使用し、普通storageはNoneで一度のaffected使用だけをSTOPへ記録する。Main/Git/index/Cargo/Beads/native/model/Search/science0。旧source/repair packet、FAILED/費/NULL-vs-persisted、全pause/default/model/sealは不変。
