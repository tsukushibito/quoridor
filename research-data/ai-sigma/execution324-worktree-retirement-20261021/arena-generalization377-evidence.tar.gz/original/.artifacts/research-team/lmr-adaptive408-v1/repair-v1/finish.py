"""One finite test-only repair STOP, retaining original failed-build scopes."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path


def freeze(lc, here):
    def ref(path):
        data = path.read_bytes()
        return {
            "path": str(path),
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
            "mode": f"{path.stat().st_mode & 0o777:04o}",
        }

    intake = json.loads((here / "intake.json").read_text())
    original = intake["original_source_STOP"]
    assert ref(Path(original["path"])) == original
    stop = json.loads(Path(original["path"]).read_text())
    for name in (
        "lmr408_tests.rs",
        "lmr408.patch",
        "lmr408.inverse.patch",
        "source-binding.json",
    ):
        assert ref(Path(stop["refs"][name]["path"])) == stop["refs"][name], name
    phases, census = [], []
    for stage in ("prepare-v1", "proof-v1", "quality-v1"):
        path = here / stage / "result.json"
        data = json.loads(path.read_text())
        assert data["status"] == "PASS" and not (here / stage / "TMP").exists()
        phases.append(ref(path))
        for check in data["checks"]:
            returned = check["guardian_return"]
            lc.settled(returned)
            assert check["status"] == "PASS" and check["capture_complete"]
            assert returned["handle_closes_complete"]
            child = returned["child"]
            current = lc.process.process_info(child["pid"])
            assert current is None or lc.process.identity(current) != child
            disk = json.loads(
                Path(check["persisted_process_receipt"]["path"]).read_text()
            )
            census.append(
                {
                    "name": check["name"],
                    "original_child": child,
                    "fresh_identity": lc.process.identity(current),
                    "fresh_state": "absent"
                    if current is None
                    else "different identity",
                    "directwait_reap_handles_cleanup": True,
                    "no_new_privs": returned["launch_policy"],
                    "returned_signal_mask_restoration": returned[
                        "signal_mask_restoration"
                    ],
                    "returned_final_record_persist": returned["final_record_persist"],
                    "disk_signal_mask_restoration": disk.get("signal_mask_restoration"),
                    "disk_final_record_persist": disk.get("final_record_persist"),
                    "full_capture": check["full_log"],
                    "persisted_receipt": check["persisted_process_receipt"],
                }
            )
    files = [
        "source-binding.json",
        "fixture.patch",
        "fixture.inverse.patch",
        "definition.before.rs",
        "definition.after.rs",
        "intake.json",
        "verification-plan.json",
        "rationale-ja.md",
        "applied-context.json",
        "guarded.py",
        "prepare.py",
        "proof.py",
        "finish.py",
    ]
    usage = lc.process.directory_bytes(here)
    fs = os.statvfs(here)
    result = {
        "issue": "quoridor-4lc.408.1",
        "status": "TEST_ONLY_REPAIR_SOURCE_STOPPED",
        "reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
        "refs": {name: ref(here / name) for name in files},
        "phases": phases,
        "fresh_process_census": census,
        "original408sourceSTOP": original,
        "original_frozen_subjects": "rehashed and unchanged",
        "assertion_reason": "raw Exact probes parent1+children4=5; usable-depth and numeric TT cutoffs each4; ordering-only parent remains",
        "four_other_definitions": "BYTE EXACT; original fourPASS retain original BUILDv2 FAILED scope, no replay",
        "author_native_type_test": "UNBUILT/UNTYPED/UNRUN",
        "Root_verification": "one exact repaired definition only, plus genuinely unentered remaining checks",
        "Main_Git_index_Cargo_Beads_production_science_review_dispatch": 0,
        "readers": [],
        "writers": [],
        "children": [],
        "jobs": [],
        "handles": [],
        "TMP": [],
        "leases": [],
        "owned": [],
        "canonical_lease": "none; immutable named Git objects and OWN frozen evidence only",
        "original_failures": "Root BUILDv1 E0308 16.877447953s and BUILDv2 fixture 9.350574793s retained, no status/capture/mask/cost rewrite",
        "storage": {
            "budget": None,
            "directed_repair_allocated_B": usage,
            "dedupe": "existing directory_bytes device/inode, repair-v1 only",
            "excludes": "final STOP write/stdout and later delivery/admin",
            "FS_available_B": fs.f_bavail * fs.f_frsize,
            "global_actual": "UNKNOWN; no global audit",
        },
        "pauses": "all prior mixed/learner/323 USERPAUSE/defaults/models/seals/RAWFAILEDfees unchanged",
    }
    (here / "STOP.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"STOP": ref(here / "STOP.json"), "usage": usage, "owned": []}))
