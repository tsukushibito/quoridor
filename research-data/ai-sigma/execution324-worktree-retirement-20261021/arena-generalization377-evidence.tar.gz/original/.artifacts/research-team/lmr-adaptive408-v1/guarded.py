"""Private immutable-object preparation through the maintained child controller."""

from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path("/workspaces/quoridor")
HERE = Path(__file__).resolve().parent
loader = importlib.util.spec_from_file_location(
    "lmr408_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
OUT = HERE / sys.argv[1]
OUT.mkdir()
TMP = OUT / "TMP"
TMP.mkdir()
commands = json.loads((HERE / (sys.argv[1] + "-commands.json")).read_text())
env = {
    **os.environ,
    "CUDA_VISIBLE_DEVICES": "",
    "OMP_NUM_THREADS": "1",
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": str(TMP),
    "RUFF_CACHE_DIR": str(TMP / "ruff-cache"),
    "NODE_OPTIONS": "--max-old-space-size=128",
    "NODE_DISABLE_COMPILE_CACHE": "1",
}
spec = {
    "kind": "software",
    "cwd": str(ROOT),
    "env": env,
    "limits": {"worker_cpu": 3, "guardian_cpu": 7, "log_B": 2 * 1024**2},
    "command_timeout_seconds": 120,
}
result = {
    "status": "ATTEMPTED",
    "checks": [],
    "primary": None,
    "canonical_lease": "not acquired: private immutable Git objects only",
    "storage_budget": None,
}
affinity = os.sched_getaffinity(0)
try:
    # No global-quiet/canonical-writer admission is requested for this private
    # immutable-object source task. The normal source worker/guardian, host
    # reserve, family RSS, capture, cancellation and child ownership still apply.
    assert {3, 7} <= affinity, "declared source CPUs unavailable"
    physical = []
    for cpu in (3, 7):
        base = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        physical.append(
            [
                (base / name).read_text().strip()
                for name in ("physical_package_id", "core_id")
            ]
        )
    assert physical[0] != physical[1], "source/guardian share physical core"
    assert lc.process.available_memory() >= 4 * 1024**3 + 768 * 1024**2
    result["physical_cpu_identities"] = physical
    os.sched_setaffinity(0, {7})
    with lc.process.cancellation_signals():
        for name, argv in commands:
            resources = lc.process.CycleResources(
                {"max_memory_bytes": 768 * 1024**2, "host_ram_reserve": 4 * 1024**3},
                OUT,
                time.monotonic() + 120,
            )

            def execute(*args, **kwargs):
                return lc.process.execute(*args, **kwargs, no_new_privs=True)

            lc.command(
                spec,
                {
                    "name": name,
                    "role": "software",
                    "argv": [sys.executable if a == "@PYTHON@" else a for a in argv],
                },
                OUT,
                resources,
                executor=execute,
                ledger=result["checks"],
            )
    result["status"] = "PASS"
except BaseException as error:
    result["status"] = "FAILED"
    result["primary"] = lc.error_fact(error)
finally:
    os.sched_setaffinity(0, affinity)
    # Helpers own their finite temporary files. Never delete failure leftovers.
    remaining = list(TMP.iterdir())
    if not remaining:
        TMP.rmdir()
    result.update(
        reader_STOP=datetime.now(timezone.utc).isoformat(),
        TMP_remaining=[str(p) for p in remaining],
        original_affinity=sorted(affinity),
        restored_affinity=sorted(os.sched_getaffinity(0)),
    )
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    if sys.argv[2:] == ["--freeze"] and result["status"] == "PASS":
        import finish

        finish.freeze(lc, HERE)
print(
    json.dumps(
        {k: result[k] for k in ("status", "primary", "reader_STOP", "TMP_remaining")}
    )
)
raise SystemExit(0 if result["status"] == "PASS" else 1)
