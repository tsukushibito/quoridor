# 408のq=0 fixture：raw Exact hitと深さ利用件数を区別

元テストの `tt_exact_hits == 4` は、Exact-boundのprobe命中を数値cutoff件数と取り違えた期待値だった。既存production counterは変更しない。

正本の `Table::probe_owned` は `probe_hashed` に委譲する。後者はkeyとcontextが一致したExact-bound entryごとに `tt_exact_hits` を加算し、ここではstored depthを検査しない。その後のnegamaxがlegal TT手とdepth一致を確認して `tt_usable_depth` を加算し、Exact値を返す際に `tt_cutoffs` を加算する。

fixtureの親はdepth1/Exactで、要求depth6には使えずordering-only。4子はdepth5/Exactで、通常child depth5に一致する。従ってraw Exact hitは親1＋子4＝5、depth-qualified利用とTT数値cutoffは各4である。観測された5へ単に合わせるのでなく、この独立した二段階をassertする。

修復はraw期待値を5へ直し、`tt_usable_depth == 4` と `tt_cutoffs == 4` を追加する。既存 `tt_order_only > 0`、返値0.5、LMR trial/確認0、history/Key/board/parent復元、path空のassertionは全て保持する。これでwrong-depth親を数値利用せずTT-firstとして読み、4番目distinctのq=0をfull-depth PVSで処理した意図を保つ。NoHead fixtureも保持し、減深してTT depthを外してheadに到達すれば依然失敗する。

元source STOP397930ae/patch/binding/406/407は不変。Root composition00c9f83の対象testは元OWN fixtureにbyte exactであることを確認し、正本TT関数の必要部分だけをintakeへ記録した。新しいtest定義・production・telemetry・LMR規則・保護条件は追加/変更していない。残る4定義と対象関数外はbyte exact、標準patchのfuzz0/offset0でforward/inverseを確認した。Rustfmtと静的lintだけで、修復後のnative/type/testはUNBUILT/UNTYPED/UNRUN。

Rootへの実行選択は `alphabeta::lmr408_tests::lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial` のexact1件だけ。元4PASSはoriginal BUILDv2 FAILEDの限定証拠として保持し、再演/Build全体PASSへ昇格しない。BUILDv1 E0308/16.877447953s、BUILDv2 fixture failure/9.350574793s、NULL/returned-vs-disk masks・capture・費を保持する。残る未入場softwareと同じ関連reviewは324所有。

作者はrepair-v1のみwriter、Main/Git/index/Cargo/Beads/native/model/Search/Perf/science0。source CPU3/guardian7/family768MiB/GPU0/host reserve4GiB、既存CycleResources/execute/Capture/no_new_privsで有限source処理を行う。元5定義を実行せず、普通保存予算None、最後にrepair-v1だけのallocated使用を一度記録する。actual process/reader/TMP/lease STOPはrepairのSTOP.json。全pause/旧RAW/FAILED/費/UNKNOWNは不変。
