# 408：固定1plyと深さ・順位LMRの共通実装準備

私有source差分のみ。406の式・image・96 callsと407の凍結sourceは変更していない。408のnative/type/test/Cargo/Search/model/Perf/game実行は0で、新定義はUNBUILT/UNTYPED/UNRUN。software・限定review・真正build・承認96 calls/128 gamesは324が所有する。本報告は速度・棋力・採用結果ではない。

## 基盤と合成範囲

immutable Git `7bf4e3a4a3497158e9458a22b8814e1069e52e5b` に凍結407 patchを一時再構成し、407 STOP `df653e8a…/18579B0644`、binding、patchをhash/size/mode確認してから使用した。再構成した全407 postimageは宣言hashと一致した。Rootのcurrent `aa233e3` の406 fixture修復はこの私有407基盤に混ぜず、Rootが既存ordinary repairと408の担当関数だけを疎に合成する。全postimage上書きを求めない。

408 deltaはAI `alphabeta.rs`、runner `measurement.rs`、Python `measurement_config` のみ。新 `lmr408_tests.rs` と、既存 `lmr400_tests.rs` のprivate helper呼出し3箇所の引数移行を含む。core/NNUE/arena/runtime/Engine config、旧406/407ファイル、managed production postimage、Main/Git/index/sharedCargoは書き換えていない。永続全文mirrorは作らず、一時全文は往復証明後に削除した。前後の最小subjectは `subjects.json`、完全な再構成は固定407 component refsとforward patchで行う。

## 方法・APIとnamespace

正本はAIの `LmrMethod::{FixedOne, DepthRank}`。設定名は `fixed_one` / `depth_rank`、省略は `fixed_one`。既存bool `lmr` は既定OFFで、方法選択だけでは有効化しない。measurementの明示null・bool・数値・未知名は拒否する。

- `LmrMethod::from_name(&str) -> Result<LmrMethod>`
- `name(self) -> &'static str`、`id(self) -> &'static str`、`reduction_rule(self) -> &'static str`
- `SearchSession::set_lmr_method(&mut self, LmrMethod) -> ()`
- 既存 `SearchSession::set_lmr(&mut self, bool) -> Result<()>`
- `SearchSession::lmr_method(&self) -> Option<LmrMethod>` は実効ON時だけSome
- `OrderingProfile::namespace(self, SearchNamespace, Option<LmrMethod>) -> SearchNamespace`

`new_with_ordering(..., lmr: bool)` は現役factoryとして既定固定方式を維持する。新callerはfactory(false)→method setter→set_lmr(enabled)?とし、setupで不要な二度clearを避ける。ON中の方法切替、ON/OFF切替は一つのprivate `change_lmr` がnamespace/TT/historyを更新する。同じ実効方法、OFF中の方法変更ではclearせずwarmを保つ。resetは選んだLMR方式を保持する。零在庫近似IDは独立した最後のcomponentとして保持し、閾値やroot壁数をnamespaceへ重複追加しない。

FixedOne IDは既存 `lmr400-late4-depth3-minus1-pvs-verify-v1`。DepthRank IDは `lmr408-depth-rank-log63-extra0to3-pvs-verify-v1`。namespaceをruntimeで再実装せず、上記profileの正本を呼ぶ。

arena408.2にはAPIと具体署名を配送済み。最初の指定cwd送信はactive sessionのcwd変更として配送前refusal、保存済みcwdを維持した別の未配送送信はaccepted=true。追加の署名質問にも具体的な戻り値を一度配送した。元refusal/guardian NULL/disk mask/費は保持する。peerはruntime/arena・Python arena関数のみを担当し、Engine config.rsのoptional String一fieldはRoot合成の具体的inletとして報告している。

## 削減量と初期化費

FixedOneは従来どおり内部d>=3、distinct一始まりm>=4で追加削減1。DepthRankは契約の

`q=clamp(floor(0.7844+ln(min(d,63))*ln(min(m,63))/2.4696)-1,0,min(3,d-2))`

を使い、通常child depth d-1からqだけ追加で減らす。確認用d6/m4,16,32→0,1,2、d12→1,2,3を新テストの独立定数期待値に記した。作者は表/テストを実行していない。

64×64のu8表をstd OnceLockへ一度だけ構築する。選択setterおよびSearch初期化で準備し、node内は既に準備した表を整数indexで読むだけ。0行/列や不適用域にlogを掛けない。d/m>63は端値、最大追加3はこの候補の固定設定で、最適値とは主張しない。表bodyは4096B、OnceLockの実size/alignment、init時のcompiler move、stack、RSSと実費はUNKNOWN。per-node heap/log/評価器呼出しは追加していない。初期化はRootのwhole/setup費に含める。

q=0は通常PVSへ流す。偽trial、同じ深さの重複確認はない。q>0は既存 `reduced_child` にnormal/reduced child depthの組を渡す。追加引数で別loopを増やさず、浅いfail-highなら元のnormal-depth scoutを必ず通り、その後の必要full-window PVSへ従来どおり続く。LMR試行・通常深さ確認・full-window件数の意味も維持する。

distinct indexは既存i+1でTT-firstを含み、PVS同手再探索は進めない。既存のroot/TT/goal/killer・provider等の保護を維持し、TT-first後の準備時点、既に準備した兄弟key/historyのfreezeも変更しない。LMRのnominal completed depthは引き続き選択的探索で、全幅minimax保証ではない。

## settings/resultsと共通境界

measurementは `lmr_method` を受け、AI from_nameでOFF中も検証する。setup/callは要求名、実効method ID/null、AI reduction_rule/nullを既存結果へ載せる。SearchStatsは一Searchのenabled/method snapshotを持ち、completed callbackと結果も同じID・規則を記録する。新しい台帳、namespace builder、profile、solver/registry、モデル/係数・history補正・追加評価はない。

親復元・取消・error・true terminal/fullhistory/TT depth/boundsと、406/407の零在庫処理は共通のまま。今回将来比較では近似OFFをRootが設定する。製品・generator・旧arenaのLMR既定OFFと4096等の元要求値は変更しない。

## 静的確認と残る検証

forward/inverseは標準patchのfuzz0/offset0で全文一致、新テストabsence復元PASS。Pythonはmeasurement_config外byte exact。AIの保護16関数はbyte exact。negamaxはq選択とreduced-depth引数以外byte exact、reduced_childは深さ引数の置換を戻せば確認・error契約がbyte exact。既存400 testは3引数の `[normal,reduced]=[2,1]` 移行と整形だけで、旧探索器コピーはない。

新AI5定義は表/単位/63境界、方法switch/warm/reset/近似独立、保存protection、TT先行後のdistinct4番q0でfull-depth TTだけを読む経路、2ply削減後のfull-depth確認と取消/error復元。runner1はdefault/拒否/設定roundtripと結果、Python NN0 1は同じ現役設定関数を使う。すべて未実行。新定義名・feature/filter/期待件数、変更private helperを持つ3定義と必要なnamespace/protection影響選択は `verification-plan.json`。旧成功suite全体を再演していない。

Root関連確認への問いは、追加qの単位・clamp・distinct順位、q0通常経路、normal-depth scout後のfull-window、実効方法とTT/history、零在庫component独立、callerの正本namespace/結果対応である。Rootが必要compile/research+diagnostics/Clippy/release/真正imageと一度の同じ関連reviewを行う。作者からreview/science dispatchはない。

## 実STOPと保存

実turn_contextは今回cwd `/workspaces/quoridor`、gpt-6.1-sol/high、danger-full-access/approval neverを最初の通常command前に確認。writerはOWN408だけ。既存CycleResources/execute/Capture、sourceCPU3/guardian7の実affinity/physical readback、family768MiB/host reserve4GiB/GPU0、有限command120秒、no_new_privs、directwait/reap/fullcapture/handles/TMPcleanupを適用する。私有immutable源泉なのでcanonical writer lease/global quietは要求していない。

原返却settled maskとdisk pending/attempted、送信refusalのguardian NULLは区別して保存。最後のfresh identity/reader/writer/handles/child/TMP/lease owned[]、一度のOWN使用とFS観測は `source-STOP.json`。普通storage budgetはNone、global actualはUNKNOWN。混合/learner全prep/pipeline・323USERPAUSE、旧RAW/FAILED/費/UNKNOWN/defaults/models/weights/sealsを保持する。Beads更新/backup/leaf closeは指定どおり324だけで、本人はin_progressのまま引き渡す。
