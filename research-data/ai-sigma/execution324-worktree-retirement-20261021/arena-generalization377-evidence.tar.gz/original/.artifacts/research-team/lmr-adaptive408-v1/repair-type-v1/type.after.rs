type SearchTableAndDomain<'table, 'history> = (
    &'table mut Table,
    ScoreDomain,
    Option<&'history mut ContinuationHistory>,
    bool,
    StaticMode,
    (bool, LmrMethod),
    (bool, ZeroStockApproxMethod),
);
