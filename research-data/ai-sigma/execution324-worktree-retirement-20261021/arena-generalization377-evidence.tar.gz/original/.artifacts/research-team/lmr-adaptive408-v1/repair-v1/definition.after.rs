fn lmr408_zero_quantum_tt_first_distinct_fourth_uses_full_pvs_without_fake_trial() {
    let root = SigmaContext::from_prefix(&[]).unwrap();
    let ids = root.legal_ids();
    assert!(ids.len() > 4);
    let mut history = ContinuationHistory::new().unwrap();
    static L: std::sync::LazyLock<SearchLimits> =
        std::sync::LazyLock::new(|| limits(6, true, true));
    LmrMethod::DepthRank.prepare();
    with_state(
        &root,
        &NoHead,
        &AtomicBool::new(false),
        &mut history,
        |s, c| {
            s.limits = &L;
            s.lmr = true;
            s.static_scratch = Some(StaticScratch::CheapControl);
            s.stats.lmr_method = LmrMethod::DepthRank;
            s.context = ContextFingerprint::of(c);
            s.board = Some(BoardCursor::of(c));
            *s.table = Table::new(4096).unwrap();
            s.table.next_generation();
            // Wrong-depth parent entry supplies only the genuine first TT ordering hand.
            for (position, depth, value, best) in std::iter::once((root.clone(), 1, 0.0, ids[0]))
                .chain(ids.iter().take(4).enumerate().map(|(i, &id)| {
                    let child = root.play(id).unwrap();
                    let best = child.legal_ids()[0];
                    (child, 5, if i < 3 { 0.5 } else { -0.5 }, best)
                }))
            {
                s.table.insert(
                    Entry {
                        key: Key::of(&position),
                        context: ContextFingerprint::of(&position).unwrap().0,
                        context_valid: true,
                        hash: 0,
                        generation: 0,
                        depth,
                        value,
                        best: Some(best),
                        bound: Bound::Exact,
                    },
                    &mut s.stats,
                );
            }
            s.table.committed = s.table.generation;
            s.table.next_generation();
            let before = (Key::of(c), c.history_counts(), s.context, s.board);
            assert_eq!(s.negamax(c, None, 6, 0.0, 0.25, 0).unwrap(), 0.5);
            assert_eq!(
                (s.stats.lmr_attempts, s.stats.lmr_full_depth_confirmations),
                (0, 0)
            );
            // Matching Exact-bound probes include the wrong-depth parent;
            // only the four full-depth child hits are numerically usable.
            assert_eq!(s.stats.tt_exact_hits, 5);
            assert_eq!(s.stats.tt_usable_depth, 4);
            assert_eq!(s.stats.tt_cutoffs, 4);
            assert!(s.stats.tt_order_only > 0);
            assert_eq!((Key::of(c), c.history_counts(), s.context, s.board), before);
            assert!(s.path.is_empty());
        },
    );
}
