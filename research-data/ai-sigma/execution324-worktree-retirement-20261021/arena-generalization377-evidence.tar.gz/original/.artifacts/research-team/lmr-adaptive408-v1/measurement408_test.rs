fn measurement408_lmr_method_default_refusal_namespace_and_result_roundtrip() {
    let base = json!({"roots":[{"input":0,"pointer":"","field":"moves","label":"toy"}],"profile":"control","tt_entries":4096,"use_tt":true,"use_pvs":true,
            "namespace":{"evaluator":crate::teacher_pilot_execution::EVALUATOR_ID,"rules":"standard","selectivity":"synthetic"},"output_bytes":10000,"record_bytes":1000});
    let settings: Settings = serde_json::from_value(base.clone()).unwrap();
    assert_eq!(settings.lmr_method, "fixed_one");
    for (value, valid) in [
        (json!("fixed_one"), true),
        (json!("depth_rank"), true),
        (Value::Null, false),
        (json!(true), false),
        (json!(1), false),
        (json!("adaptive"), false),
    ] {
        let mut config = base.clone();
        config["lmr_method"] = value;
        assert_eq!(
            serde_json::from_value::<Settings>(config).is_ok_and(|s| validate(&s, &[]).is_ok()),
            valid
        );
    }
    for method in [LmrMethod::FixedOne, LmrMethod::DepthRank] {
        for enabled in [false, true] {
            let result = SearchResult {
                action: None,
                value: None,
                completed_depth: 0,
                pv: vec![],
                stats: alphabeta::SearchStats {
                    lmr_enabled: enabled,
                    lmr_method: method,
                    ..Default::default()
                },
                stop: StopReason::NodeLimit,
                elapsed: std::time::Duration::ZERO,
            };
            let expected = if enabled {
                json!(method.id())
            } else {
                Value::Null
            };
            assert_eq!(observed(&result)["lmr_rule"], expected);
            assert_eq!(completed_depth_observation(&result)["lmr_rule"], expected);
            let mut config = base.clone();
            config["lmr_method"] = json!(method.name());
            let settings: Settings = serde_json::from_value(config).unwrap();
            let decoded: Settings =
                serde_json::from_value(serde_json::to_value(settings).unwrap()).unwrap();
            assert_eq!(LmrMethod::from_name(&decoded.lmr_method).unwrap(), method);
        }
    }
}
