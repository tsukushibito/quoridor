"""One private alias for the existing tuple; immutable45d source only."""

import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
TMP = Path(os.environ["TMPDIR"])
REV = "45d55c61468b83012a144c098eb73080e4911296"
REL = "crates/quoridor-ai/src/alphabeta.rs"
LOG = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-adaptive408-v1/compatible-build-v4/operation-v1/research-affected-lint.full.log"
)
argv = [
    "git",
    "--no-optional-locks",
    "-C",
    "/workspaces/quoridor",
    "show",
    REV + ":" + REL,
]
result = subprocess.run(argv, check=True, capture_output=True)
before = result.stdout.decode()
old = """    table_and_domain: (
        &mut Table,
        ScoreDomain,
        Option<&mut ContinuationHistory>,
        bool,
        StaticMode,
        (bool, LmrMethod),
        (bool, ZeroStockApproxMethod),
    ),"""
alias = """type SearchTableAndDomain<'table, 'history> = (
    &'table mut Table,
    ScoreDomain,
    Option<&'history mut ContinuationHistory>,
    bool,
    StaticMode,
    (bool, LmrMethod),
    (bool, ZeroStockApproxMethod),
);

"""
assert before.count(old) == 1 and "type SearchTableAndDomain" not in before
after = before.replace(old, "    table_and_domain: SearchTableAndDomain<'_, '_>,")
assert after.count("\nfn search_in_table(") == 1
after = after.replace("\nfn search_in_table(", "\n" + alias + "fn search_in_table(")
(TMP / "alphabeta.rs").write_text(after)
(TMP / "before.rs").write_text(before)
diagnostics = []
plain = []
digest = hashlib.sha256()
with LOG.open("rb") as stream:
    for line in stream:
        digest.update(line)
        text = line.decode(errors="replace")
        if "error: very complex type used." in text:
            plain = [text[:2000]]
        elif plain and len(plain) < 18 and not text.lstrip().startswith("{"):
            plain.append(text[:2000])
        try:
            row = json.loads(line)
        except ValueError:
            continue
        message = row.get("message")
        if not isinstance(message, dict):
            continue
        code = (message.get("code") or {}).get("code")
        if code == "clippy::type_complexity":
            diagnostics.append(
                {
                    "code": code,
                    "level": message.get("level"),
                    "message": message.get("message"),
                    "spans": [
                        {
                            k: span.get(k)
                            for k in (
                                "file_name",
                                "line_start",
                                "line_end",
                                "is_primary",
                            )
                        }
                        for span in message.get("spans", [])
                    ],
                    "rendered": message.get("rendered", "")[:4000],
                }
            )
if not diagnostics and plain:
    rendered = "".join(plain)
    assert "#type_complexity" in rendered and "alphabeta.rs:2445" in rendered
    diagnostics.append(
        {
            "code": "clippy::type_complexity",
            "level": "error",
            "message": plain[0].strip(),
            "rendered": rendered,
            "format": "standard Clippy text; bounded selected diagnostic only",
        }
    )
assert diagnostics, "selected original type_complexity diagnostic not found"
(HERE / "intake.json").write_text(
    json.dumps(
        {
            "base_commit": REV,
            "before": {
                "git_object": REV + ":" + REL,
                "relative": REL,
                "sha256": hashlib.sha256(result.stdout).hexdigest(),
                "bytes": len(result.stdout),
                "mode": "0644",
            },
            "git_object_directwait": {
                "argv": argv,
                "exit_code": result.returncode,
                "stderr": result.stderr.decode(),
            },
            "selected_diagnostics": diagnostics,
            "original_log": {
                "path": str(LOG),
                "sha256": digest.hexdigest(),
                "bytes": LOG.stat().st_size,
                "mode": f"{LOG.stat().st_mode & 0o777:04o}",
                "read_scope": "one named original failure capture, only selected diagnostic retained/printed",
            },
            "native_type_test_status": "UNBUILT/UNTYPED/UNRUN",
        },
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "selected_diagnostic": diagnostics[0]["message"],
            "private_alias": "SearchTableAndDomain<'table, 'history>",
            "source_only": True,
        }
    )
)
