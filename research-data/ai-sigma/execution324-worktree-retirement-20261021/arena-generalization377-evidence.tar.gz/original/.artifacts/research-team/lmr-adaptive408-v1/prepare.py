"""One sparse408 proposal atop exact frozen407 objects, never Main mutation."""

import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
FROZEN = HERE.parent / "zero-stock-approx-method407-v1"
TMP = Path(os.environ["TMPDIR"])
REV = "7bf4e3a4a3497158e9458a22b8814e1069e52e5b"
AI = "crates/quoridor-ai/src/alphabeta.rs"
MEASURE = "crates/quoridor-runner/src/measurement.rs"
PY = "scripts/dev/research-lifecycle.py"
OLD_TEST = "crates/quoridor-ai/src/lmr400_tests.rs"
NEW_TEST = "crates/quoridor-ai/src/lmr408_tests.rs"
commands = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verified(path, sha, size):
    data = path.read_bytes()
    assert (
        digest(data) == sha
        and len(data) == size
        and path.stat().st_mode & 0o777 == 0o644
    ), path
    return data


def run(argv, **kwargs):
    result = subprocess.run(argv, check=True, capture_output=True, **kwargs)
    commands.append(
        {
            "argv": argv,
            "returncode": result.returncode,
            "stderr": result.stderr.decode(),
        }
    )
    return result.stdout


def git(*args):
    return run(["git", "--no-optional-locks", "-C", "/workspaces/quoridor", *args])


def replace(text, old, new, count=1):
    assert text.count(old) == count, (old[:90], text.count(old), count)
    return text.replace(old, new)


stop = json.loads(
    verified(
        FROZEN / "source-STOP.json",
        "df653e8a13425ea983a94d0a543cde47495f7e2bb7be1ab3740859471227ddb9",
        18579,
    )
)
binding_ref = stop["refs"]["source-binding.json"]
binding = json.loads(
    verified(
        FROZEN / "source-binding.json", binding_ref["sha256"], binding_ref["bytes"]
    )
)
patch_ref = stop["refs"]["method407.patch"]
verified(FROZEN / "method407.patch", patch_ref["sha256"], patch_ref["bytes"])
tree = TMP / "base407"
tree.mkdir()
for rel in (AI, MEASURE, PY):
    path = tree / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(git("show", f"{REV}:{rel}"))
output = run(
    ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(FROZEN / "method407.patch")],
    cwd=tree,
)
assert not re.search(rb"offset|fuzz|FAILED|reject", output, re.I)
for item in binding["after"]:
    data = (tree / item["relative"]).read_bytes()
    assert digest(data) == item["sha256"] and len(data) == item["bytes"]
before = {rel: (tree / rel).read_text() for rel in (AI, MEASURE, PY)}
before[OLD_TEST] = git("show", f"{REV}:{OLD_TEST}").decode()
assert not git("ls-tree", REV, "--", NEW_TEST)
ai = before[AI]
enum = """
/// Additional reduction from normal child depth, not the ordinary played ply.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub enum LmrMethod {
    #[default]
    FixedOne,
    DepthRank,
}
static LMR_DEPTH_RANK: std::sync::OnceLock<[[u8; 64]; 64]> = std::sync::OnceLock::new();
impl LmrMethod {
    pub fn from_name(name: &str) -> Result<Self> {
        match name {
            "fixed_one" => Ok(Self::FixedOne),
            "depth_rank" => Ok(Self::DepthRank),
            _ => Err(SearchError::Limits("unsupported LMR method".into())),
        }
    }
    pub fn name(self) -> &'static str {
        match self {
            Self::FixedOne => "fixed_one",
            Self::DepthRank => "depth_rank",
        }
    }
    pub fn id(self) -> &'static str {
        match self {
            Self::FixedOne => LMR_METHOD,
            Self::DepthRank => "lmr408-depth-rank-log63-extra0to3-pvs-verify-v1",
        }
    }
    pub fn reduction_rule(self) -> &'static str {
        match self {
            Self::FixedOne => "d>=3,m>=4: extra=1; child=d-1-extra; existing protection/PVS",
            Self::DepthRank => "d>=3,m>=4: extra=clamp(floor(0.7844+ln(min(d,63))*ln(min(m,63))/2.4696)-1,0,min(3,d-2)); child=d-1-extra; existing protection/PVS",
        }
    }
    fn prepare(self) {
        if self == Self::DepthRank {
            LMR_DEPTH_RANK.get_or_init(|| {
                let mut table = [[0; 64]; 64];
                for (depth, row) in table.iter_mut().enumerate().skip(3) {
                    for (rank, cell) in row.iter_mut().enumerate().skip(4) {
                        let extra = (0.7844 + (depth as f64).ln() * (rank as f64).ln() / 2.4696).floor() - 1.0;
                        *cell = extra.clamp(0.0, (depth - 2).min(3) as f64) as u8;
                    }
                }
                table
            });
        }
    }
    fn reduction(self, depth: u16, rank: usize) -> u16 {
        if depth < 3 || rank < 4 {
            return 0;
        }
        match self {
            Self::FixedOne => 1,
            Self::DepthRank => u16::from(
                LMR_DEPTH_RANK.get().expect("LMR prepared before Search")
                    [usize::from(depth.min(63))][rank.min(63)],
            ),
        }
    }
}
"""
ai = replace(
    ai,
    'pub const LMR_METHOD: &str = "lmr400-late4-depth3-minus1-pvs-verify-v1";\n',
    'pub const LMR_METHOD: &str = "lmr400-late4-depth3-minus1-pvs-verify-v1";\n' + enum,
)
ai = replace(
    ai,
    "pub struct SearchStats {",
    """pub struct SearchStats {
    /// One per-Search snapshot; method selection alone does not enable LMR.
    pub lmr_enabled: bool,
    pub lmr_method: LmrMethod,""",
)
ai = replace(
    ai,
    "            let reduced = self.lmr\n                && moves\n                    .as_ref()\n                    .is_some_and(|moves| self.lmr_allowed(action, depth, i, alpha, tt_move, moves));",
    """            let reduction = if self.lmr
                && moves.as_ref().is_some_and(|moves|
                    self.lmr_allowed(action, depth, i, alpha, tt_move, moves))
            {
                // i counts distinct hands, including TT-first; re-search never advances it.
                self.stats.lmr_method.reduction(depth, i + 1)
            } else {
                0
            };
            let reduced = reduction > 0;""",
)
ai = replace(
    ai,
    "self.reduced_child(c, a, action, depth - 1, alpha, ply + 1)?",
    "self.reduced_child(c, a, action, [depth - 1, depth - 1 - reduction], alpha, ply + 1)?",
)
ai = replace(
    ai,
    "        child_depth: u16,\n        alpha: f32,\n        ply: usize,\n    ) -> NodeResult<f32> {\n        self.stats.lmr_attempts += 1;",
    """        child_depths: [u16; 2],
        alpha: f32,
        ply: usize,
    ) -> NodeResult<f32> {
        let [child_depth, reduced_depth] = child_depths;
        debug_assert!(reduced_depth < child_depth);
        self.stats.lmr_attempts += 1;""",
)
ai = replace(
    ai,
    "            child_depth - 1,\n            [alpha, next_up(alpha)],",
    "            reduced_depth,\n            [alpha, next_up(alpha)],",
)
ai = replace(
    ai,
    "pub fn namespace(self, namespace: SearchNamespace, lmr: bool)",
    "pub fn namespace(self, namespace: SearchNamespace, lmr: Option<LmrMethod>)",
)
ai = replace(
    ai,
    "fn append_lmr_method(namespace: &mut SearchNamespace) {",
    "fn append_lmr_method(namespace: &mut SearchNamespace, method: LmrMethod) {",
)
ai = replace(
    ai,
    "namespace.selectivity.push_str(LMR_METHOD);",
    "namespace.selectivity.push_str(method.id());",
)
ai = replace(
    ai,
    "fn namespace(self, mut namespace: SearchNamespace, lmr: bool)",
    "fn namespace(self, mut namespace: SearchNamespace, lmr: Option<LmrMethod>)",
)
ai = replace(
    ai,
    "        if lmr {\n            append_lmr_method(&mut namespace);\n        }",
    "        if let Some(method) = lmr {\n            append_lmr_method(&mut namespace, method);\n        }",
)
# Only the session owns the selected setting. Search gets an immutable scalar snapshot.
ai = replace(
    ai,
    "    lmr: bool,\n    method: SessionMethod,",
    "    lmr: bool,\n    lmr_method: LmrMethod,\n    method: SessionMethod,",
)
begin = ai.index("        if enabled != self.lmr {", ai.index("    pub fn set_lmr("))
end = ai.index("    /// Observation only;", begin)
ai = (
    ai[:begin]
    + """        self.change_lmr(enabled, self.lmr_method);
        Ok(())
    }
    /// Selects a method without activating it. No numeric namespace change while OFF.
    pub fn set_lmr_method(&mut self, method: LmrMethod) {
        self.change_lmr(self.lmr, method);
    }
    fn change_lmr(&mut self, enabled: bool, method: LmrMethod) {
        method.prepare(); // One process table, outside per-node search work.
        if enabled == self.lmr && (method == self.lmr_method || !enabled) {
            self.lmr_method = method;
            return;
        }
        // Approximation remains the final independent method component.
        if self.zero_stock_approx_effective {
            self.namespace.selectivity.truncate(
                self.namespace.selectivity.len() - self.zero_stock_approx_method.id().len() - 1,
            );
        }
        if self.lmr {
            self.namespace.selectivity.truncate(
                self.namespace.selectivity.len() - self.lmr_method.id().len() - 1,
            );
        }
        if enabled {
            append_lmr_method(&mut self.namespace, method);
        }
        if self.zero_stock_approx_effective {
            append_zero_stock_approx_method(&mut self.namespace, self.zero_stock_approx_method);
        }
        self.lmr = enabled;
        self.lmr_method = method;
        self.table.clear();
        if let Some(history) = self.ordering.as_mut() {
            history.reset();
        }
    }
    pub fn lmr_enabled(&self) -> bool {
        self.lmr
    }
    pub fn lmr_method(&self) -> Option<LmrMethod> {
        self.lmr.then_some(self.lmr_method)
    }
"""
    + ai[end:]
)
ai = replace(
    ai,
    "session.method.namespace(session.namespace, false)",
    "session.method.namespace(session.namespace, None)",
    2,
)
ai = replace(
    ai,
    "            lmr: false,\n            method: SessionMethod::Plain,",
    "            lmr: false,\n            lmr_method: LmrMethod::FixedOne,\n            method: SessionMethod::Plain,",
)
ai = replace(
    ai,
    "self.method.namespace(namespace, self.lmr)",
    "self.method.namespace(namespace, self.lmr.then_some(self.lmr_method))",
)
ai = replace(
    ai,
    "                self.lmr,\n                (",
    "                (self.lmr, self.lmr_method),\n                (",
)
ai = replace(
    ai,
    "        StaticMode,\n        bool,\n        (bool, ZeroStockApproxMethod),",
    "        StaticMode,\n        (bool, LmrMethod),\n        (bool, ZeroStockApproxMethod),",
)
ai = replace(
    ai,
    "        static_enabled,\n        lmr,\n        (zero_stock",
    "        static_enabled,\n        (lmr, lmr_method),\n        (zero_stock",
)
ai = replace(
    ai,
    "    let root_context = if limits.use_tt {",
    "    if lmr {\n        lmr_method.prepare();\n    }\n    let root_context = if limits.use_tt {",
)
ai = replace(
    ai,
    "        stats: SearchStats {\n            root_walls_remaining,",
    "        stats: SearchStats {\n            lmr_enabled: lmr,\n            lmr_method,\n            root_walls_remaining,",
)
ai = replace(
    ai,
    "            StaticMode::Coverage,\n            false,\n            (false, ZeroStockApproxMethod::Race),",
    "            StaticMode::Coverage,\n            (false, LmrMethod::FixedOne),\n            (false, ZeroStockApproxMethod::Race),",
)
ai = replace(
    ai,
    "                StaticMode::Off,\n                false,\n                (false, ZeroStockApproxMethod::Race),",
    "                StaticMode::Off,\n                (false, LmrMethod::FixedOne),\n                (false, ZeroStockApproxMethod::Race),",
)
ai = replace(
    ai,
    '#[cfg(test)]\n#[path = "lmr400_tests.rs"]',
    '#[cfg(test)]\n#[path = "lmr408_tests.rs"]\nmod lmr408_tests;\n\n#[cfg(test)]\n#[path = "lmr400_tests.rs"]',
)

old_test, count = re.subn(
    r"\.reduced_child\(c, None, (target|action), 2,",
    r".reduced_child(c, None, \1, [2, 1],",
    before[OLD_TEST],
)
assert count == 3
measure = before[MEASURE]
measure = replace(
    measure, "    self, OrderingProfile,", "    self, LmrMethod, OrderingProfile,"
)
measure = replace(
    measure,
    "    lmr: bool,",
    '    lmr: bool,\n    #[serde(default = "default_lmr_method")]\n    lmr_method: String,',
)
measure = replace(
    measure,
    "fn default_zero_stock_approx_method()",
    "fn default_lmr_method() -> String {\n    LmrMethod::default().name().into()\n}\n\nfn default_zero_stock_approx_method()",
)
measure = replace(
    measure,
    "fn validate(settings: &Settings, requests: &[Request]) -> Result<()> {",
    "fn validate(settings: &Settings, requests: &[Request]) -> Result<()> {\n    LmrMethod::from_name(&settings.lmr_method)?;",
)
measure = replace(
    measure, "                self.settings.lmr,", "                false,"
)
measure = replace(
    measure,
    "        session.set_zero_stock_approx_method(",
    "        session.set_lmr_method(LmrMethod::from_name(&self.settings.lmr_method)?);\n        session.set_lmr(self.settings.lmr)?;\n        session.set_zero_stock_approx_method(",
)
measure = replace(
    measure,
    '                "lmr_rule":if lmr {Some(alphabeta::LMR_METHOD)} else {None}',
    '                "lmr_method_requested":self.settings.lmr_method,\n                "lmr_rule":self.session.as_ref().and_then(SearchSession::lmr_method).map(LmrMethod::id),\n                "lmr_parameters":self.session.as_ref().and_then(SearchSession::lmr_method).map(LmrMethod::reduction_rule)',
)
measure = replace(
    measure,
    '        row["actual_selectivity"] = json!(session.namespace().selectivity);',
    '        row["actual_selectivity"] = json!(session.namespace().selectivity);\n        row["lmr_method_requested"] = json!(self.settings.lmr_method);\n        row["lmr_rule"] = json!(session.lmr_method().map(LmrMethod::id));\n        row["lmr_parameters"] = json!(session.lmr_method().map(LmrMethod::reduction_rule));',
)
measure = replace(
    measure,
    '    let s = &r.stats;\n    json!({"completed_depth"',
    '    let s = &r.stats;\n    json!({"lmr_rule":s.lmr_enabled.then(|| s.lmr_method.id()),"lmr_parameters":s.lmr_enabled.then(|| s.lmr_method.reduction_rule()),"completed_depth"',
)
measure = replace(
    measure,
    '    result["work"]["LMR_attempts"] =',
    '    result["lmr_rule"] = json!(s.lmr_enabled.then(|| s.lmr_method.id()));\n    result["lmr_parameters"] = json!(s.lmr_enabled.then(|| s.lmr_method.reduction_rule()));\n    result["work"]["LMR_attempts"] =',
)
measure = replace(
    measure,
    "mod tests {\n    use super::*;",
    "mod tests {\n    use super::*;\n" + (HERE / "measurement408_test.rs").read_text(),
)

publisher = before[PY]
node = next(
    n
    for n in ast.parse(publisher).body
    if isinstance(n, ast.FunctionDef) and n.name == "measurement_config"
)
fragment = "".join(
    publisher.splitlines(keepends=True)[node.lineno - 1 : node.end_lineno]
)
updated = replace(
    fragment, '            "lmr",', '            "lmr",\n            "lmr_method",'
)
updated = replace(
    updated,
    '    require(type(config.get("lmr", False)) is bool, "measurement LMR switch")',
    """    require(type(config.get("lmr", False)) is bool, "measurement LMR switch")
    lmr_method = config.get("lmr_method", "fixed_one")
    require(
        type(lmr_method) is str and lmr_method in {"fixed_one", "depth_rank"},
        "measurement LMR method",
    )""",
)
(HERE / "measurement_config.before.py").write_text(fragment)
(TMP / "measurement_config.py").write_text(updated)
for rel, text in ((AI, ai), (MEASURE, measure), (OLD_TEST, old_test)):
    (TMP / Path(rel).name).write_text(text)
    (TMP / (Path(rel).name + ".before")).write_text(before[rel])
(TMP / "publisher.before").write_text(publisher)
(HERE / "base-components.json").write_text(
    json.dumps(
        {
            "base_Git": REV,
            "fixed407_STOP": {
                "path": str(FROZEN / "source-STOP.json"),
                "sha256": "df653e8a13425ea983a94d0a543cde47495f7e2bb7be1ab3740859471227ddb9",
                "bytes": 18579,
                "mode": "0644",
            },
            "fixed407_binding": binding_ref,
            "fixed407_patch": patch_ref,
            "before": [
                {
                    "relative": rel,
                    "sha256": digest(text.encode()),
                    "bytes": len(text.encode()),
                    "mode": "0644",
                }
                for rel, text in before.items()
            ],
            "new_test": {
                "relative": NEW_TEST,
                "before": "ABSENT at base Git and own reconstruction",
            },
            "Root_current_ref_information_only": "aa233e3 ordinary406 fixture fixes remain Root-owned; sparse production/function composition only, no stale whole-file overwrite",
            "commands_directwait": commands,
            "native": "UNBUILT/UNTYPED/UNRUN",
        },
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "status": "private408 draft constructed",
            "base": "exact frozen407 prospective postimages",
            "old_test_depth_argument_migrations": count,
        }
    )
)
