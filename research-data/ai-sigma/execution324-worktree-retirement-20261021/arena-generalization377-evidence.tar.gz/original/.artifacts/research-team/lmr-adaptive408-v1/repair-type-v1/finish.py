"""A stopped alias-only source packet, not a software PASS."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path


def freeze(lc, here):
    def ref(path):
        data = path.read_bytes()
        return {
            "path": str(path),
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
            "mode": f"{path.stat().st_mode & 0o777:04o}",
        }

    phases, census = [], []
    for phase in ("prepare-v1", "prepare-v2", "proof-v1", "quality-v1", "quality-v2"):
        path = here / phase / "result.json"
        result = json.loads(path.read_text())
        assert result["status"] == (
            "FAILED" if phase in ("prepare-v1", "quality-v1") else "PASS"
        )
        assert not (here / phase / "TMP").exists()
        phases.append(ref(path))
        for check in result["checks"]:
            returned = check["guardian_return"]
            disk = json.loads(
                Path(check["persisted_process_receipt"]["path"]).read_text()
            )
            observed = returned if returned is not None else disk
            if returned is not None:
                lc.settled(returned)
                assert check["capture_complete"] and check["status"] == "PASS"
            else:
                assert (
                    phase in ("prepare-v1", "quality-v1")
                    and check["status"] == "FAILED"
                )
            assert observed["direct_child_reaped"] and observed["cleanup_complete"]
            assert observed["handle_closes_complete"] and observed["remaining"] == []
            child = observed["child"]
            current = lc.process.process_info(child["pid"])
            assert current is None or lc.process.identity(current) != child
            census.append(
                {
                    "phase": phase,
                    "name": check["name"],
                    "status": check["status"],
                    "original_child": child,
                    "fresh_identity": lc.process.identity(current),
                    "directwait_reap_handles_cleanup": True,
                    "no_new_privs": observed["launch_policy"],
                    "returned_guardian": "available" if returned is not None else None,
                    "returned_mask": returned.get("signal_mask_restoration")
                    if returned
                    else "UNKNOWN",
                    "returned_persist": returned.get("final_record_persist")
                    if returned
                    else "UNKNOWN",
                    "persisted_mask": disk.get("signal_mask_restoration"),
                    "persisted_persist": disk.get("final_record_persist"),
                    "original_capture_complete_scope": check["capture_complete"],
                    "full_capture": check["full_log"],
                    "persisted_receipt": check["persisted_process_receipt"],
                    "original_seconds_once": observed.get("wall_seconds"),
                }
            )
    files = [
        "source-binding.json",
        "type-alias.patch",
        "type-alias.inverse.patch",
        "type.before.txt",
        "type.after.rs",
        "intake.json",
        "verification-plan.json",
        "rationale-ja.md",
        "applied-context.json",
        "temporary-cleanup.json",
        "failed-prepare-v1.py",
        "type-after-before-standalone-format.txt",
        "guarded.py",
        "prepare.py",
        "proof.py",
        "cleanup.py",
        "finish.py",
    ]
    usage = lc.process.directory_bytes(here)
    fs = os.statvfs(here)
    result = {
        "issue": "quoridor-4lc.408.1",
        "status": "PRIVATE_ALIAS_ONLY_SOURCE_STOPPED",
        "reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
        "base_commit": "45d55c61468b83012a144c098eb73080e4911296",
        "refs": {name: ref(here / name) for name in files},
        "phases": phases,
        "fresh_process_census": census,
        "source_scope": "one private alias declaration + signature type; all bodies byte exact",
        "native_type_test_status": "UNBUILT/UNTYPED/UNRUN",
        "Root_remaining": "failed research lint plus genuinely unentered diagnostics/runner lint/release only; no assertion replay/no new math review",
        "original_errors": "buildv4 FAILED; parser-helper prepare-v1 and standalone snapshot check quality-v1 FAILED retain captures/cost/NULL/disk masks",
        "Main_Git_index_Cargo_Beads_native_test_Search_model_science_review_dispatch": 0,
        "readers": [],
        "writers": [],
        "children": [],
        "jobs": [],
        "handles": [],
        "TMP": [],
        "leases": [],
        "owned": [],
        "canonical_lease": "none; named immutable45d source and owned artifacts only",
        "storage": {
            "budget": None,
            "directed_repair_allocated_B": usage,
            "dedupe": "existing directory_bytes device/inode in repair-type-v1 only",
            "excludes": "final STOP write/stdout and later delivery/admin",
            "FS_available_B": fs.f_bavail * fs.f_frsize,
            "global_actual": "UNKNOWN; no global audit",
        },
        "pauses": "all prior pauses/defaults/models/seals/oldfits96/foreign and RAWFAILEDfeesUNKNOWN unchanged",
    }
    (here / "STOP.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"STOP": ref(here / "STOP.json"), "usage": usage, "owned": []}))
