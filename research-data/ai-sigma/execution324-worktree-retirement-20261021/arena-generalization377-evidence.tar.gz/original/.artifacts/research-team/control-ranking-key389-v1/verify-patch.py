"""Static byte/patch correspondence only; never compiles or executes Rust."""

import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
OWN = BASE.parents[2]
SRC = Path("crates/quoridor-ai/src")
NAMES = ["move_ordering.rs", "move_ordering_tests.rs", "alphabeta.rs"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    before = {
        name: gzip.decompress((BASE / (name + ".before.gz")).read_bytes())
        for name in NAMES
    }
    after = {name: (OWN / SRC / name).read_bytes() for name in NAMES}
    old = "        ranking.sort(&mut ids);\n"
    new = (
        '        #[cfg(feature = "research-diagnostics")]\n'
        "        if matches!(\n"
        "            self.static_scratch.as_ref(),\n"
        "            Some(StaticScratch::CheapControl)\n"
        "        ) {\n"
        "            ranking.sort_control(&mut ids);\n"
        "        } else {\n"
        "            ranking.sort(&mut ids);\n"
        "        }\n"
        '        #[cfg(not(feature = "research-diagnostics"))]\n'
        "        ranking.sort(&mut ids);\n"
    )
    assert before["alphabeta.rs"].decode().count(old) == 1
    assert (
        before["alphabeta.rs"].decode().replace(old, new)
        == after["alphabeta.rs"].decode()
    )
    rank = after["move_ordering.rs"].decode()
    start = rank.index(
        '    #[cfg(feature = "research-diagnostics")]\n    pub fn sort_control('
    )
    end = rank.index("\n}\n\n/// Constructed only", start)
    assert (rank[:start].rstrip("\n") + rank[end:]).encode() == before[
        "move_ordering.rs"
    ].rstrip(b"\n") + b"\n"
    tests = after["move_ordering_tests.rs"].decode()
    insertion = tests.index("\n", tests.index("use super::*;")) + 1
    original = tests.index(
        "#[test]\nfn control385_legal_vector_is_scored_and_sorted_in_place"
    )
    assert (tests[:insertion] + "\n" + tests[original:]).encode() == before[
        "move_ordering_tests.rs"
    ]
    definitions = re.findall(r"fn (control389_key_\w+)\(", tests[insertion:original])
    assert len(definitions) == 4
    patches = {}
    for direction, left, right in [
        ("forward", before, after),
        ("inverse", after, before),
    ]:
        text = "".join(
            "".join(
                difflib.unified_diff(
                    left[name].decode().splitlines(True),
                    right[name].decode().splitlines(True),
                    fromfile="a/" + str(SRC / name),
                    tofile="b/" + str(SRC / name),
                )
            )
            for name in NAMES
        )
        target = BASE / (
            "source.patch" if direction == "forward" else "source.inverse.patch"
        )
        target.write_text(text)
        patches[direction] = target
    tmp = BASE / "TMP"
    tmp.mkdir()
    try:
        for name in NAMES:
            path = tmp / SRC / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(before[name])
        for direction, expected in [("forward", after), ("inverse", before)]:
            result = subprocess.run(
                [
                    "/usr/bin/patch",
                    "--batch",
                    "--fuzz=0",
                    "--no-backup-if-mismatch",
                    "-p1",
                    "-i",
                    str(patches[direction]),
                ],
                cwd=tmp,
                capture_output=True,
                text=True,
                check=True,
            )
            assert "offset" not in result.stdout and "fuzz" not in result.stdout
            print(direction, result.stdout.strip())
            assert all(
                (tmp / SRC / name).read_bytes() == expected[name] for name in NAMES
            )
    finally:
        shutil.rmtree(tmp)
    (BASE / "static-proof.json").write_text(
        json.dumps(
            {
                "scope": "Exact three-path forward/inverse zero-fuzz/zero-offset; no Rust/helper/native/Search execution",
                "postimages": [
                    {
                        "path": str(OWN / SRC / name),
                        "sha256": sha(after[name]),
                        "bytes": len(after[name]),
                        "mode": "0644",
                        "before_sha256": sha(before[name]),
                    }
                    for name in NAMES
                ],
                "new_definitions": definitions,
                "native_status": "UNBUILT/UNTYPED/UNRUN",
                "outside_removal_correspondence": "Alpha all outside exact one owning call; Ranking outside one new method exact; every old test/import byte exact",
                "TMP_absent": not tmp.exists(),
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
