# 389：Controlの一時的な複合ordering key

一候補を実装した。`move_ordering.rs::Ranking::sort_control` はControlのno-policy/signed scoreに限り、既存の順位・signed history降順・ActionID昇順を一つのu64へ符号化し、合法IDごとに一度作る。比較器はその固定stack keyの整数比較だけを行う。`alphabeta.rs::ordered` の唯一の入口変更は既存 `StaticScratch::CheapControl` の分岐。公開profile/settings、score、モデル、history、TT/PVS、探索順序の意味、合法集合、取消/エラー/復元は変更していない。

現在のMainとOWNの3対象は書込み前にbytes/hash/size/modeが一致した。Main基点は発行済み8b3b029、具体的な対象は [before-read.json](before-read.json)。historical OWN baseや377/385/386 evidenceは更新しない。Main/Git/index/Cargoへの書込みは0。

## キーと境界

keyは `rank << 40 | descending_score << 8 | ActionID`。既存順位はPV0、goal1、killer2/3、通常4で、`Ranking::priority(id, true)`を直接使用する。`descending_score = !(score as u32 ^ (1u32 << 31))` はi32全域を逆順のu32全域へ移す。i32::MINを否定しないのでoverflowせず、MIN/-1/0/MAXを含むsigned比較に一致する。historyの32bitsは8〜39、rankは40以上、合法ID0〜208は下位8bitsに入り、重なりはない。同順位・同scoreなら昇順ActionIDとなる。

既存の生成IDの一意性・0〜208の範囲を再用し、異なる合法APIや検証省略を作っていない。既存 `Ranking::new` の合法ID/rank作成もそのまま。key作成とsort中にscore/rankを書き換えず、TT子後に作られた現在のscoreをその場で使用する。永続cacheではない。

local `[u64; 209]` は1,672Bの固定stackで、heap allocation・追加Vec・ID配列copyはない。zero初期化、合法手の追加一巡、stack/cache footprintの費用がある。whole benefitは未測定で、388のsorting self157/565はこの候補の効果予測ではない。stable化や別sort法への変更もない。

policy Someとunsigned scoreは`sort_control`から既存`sort`へそのまま戻る。Some policyの`total_cmp`、+0/-0、unsigned u64全域は既存規則を保持する。非ControlのCheap/製品Coverage/その他入口は既存sort。research-diagnosticsなしのbuildでは元のsortのみ。provider/静的準備/score検査を経た後の位置に分岐を置いたため、エラーやprovider呼出しを省かない。

診断は既存 `Observation::after` の同じRanking/priority/compareを使う。keyはその順位の等価な符号化であり、診断用dynamic-only比較をkeyに置き換えていない。診断OFFの新たな観測scan/copyは0。keyの合法手一巡は実際のsort処理で、観測probeではない。

## 新しい4定義と未完了software

新定義は全て`alphabeta::move_ordering::tests`、research-diagnostics下。**UNBUILT/UNTYPED/UNRUN**であり、Rustfmtや静的patch検査はassertion PASSではない。

1. `control389_key_preserves_rank_signed_extremes_and_id_ties`：PV/goal/両killer優先とMIN/MAX/-1・同値ID tieを明示したexpected配列。並びの隣接対を現役Rankingのcompareで確認する。旧比較器のコピーはない。
2. `control389_key_full_legal_order_is_in_place_and_observation_uses_same_rank`：一つの全合法集合、MIN/-1/0/MAXの明示bucket、異なる入力順で完全order・Vec pointer/capacity・親を保持。現役Observationが同じ順位とdynamic scoreを読む。
3. `control389_key_excludes_policy_signed_zero_and_unsigned_scores`：policy +0/-0がsigned scoreより優先し、unsigned最大/上位bit比較は元の経路に残る。
4. `control389_key_control_call_keeps_diagnostic_on_off_order_and_parent`：実際のControl owning callをfake NN0 stateで使用し、ON/OFFの全合法順・pointer・親・診断母数を確認する。model/head/Search探索は不要な定義。

Rootの新scope選択は例えば `cargo test --locked -p quoridor-ai --lib --features research-diagnostics control389_key_ -- --test-threads=1`、**expected4 passed/0failed/0ignored**。0test/compile-onlyをPASSにしない。必要research/research-diagnostics compile、Clippy、release/genuineN、既存の関連cancel/error/goal/provider境界の再用範囲、rank/keyの一度の限定独立reviewをRootが所有する。作者はCargo/native/Search/model/NN/Perf/geometry/qualificationを一切実行していない。

## 可逆性・source STOP

変更は3pathsだけ。[source.patch](source.patch) と [source.inverse.patch](source.inverse.patch)、minimum beforegzips、[static-proof.json](static-proof.json) にafterrefsがある。GNU patch zero-fuzz/zero-offsetでforward後の3fileはexactpost、inverse後はexactbefore。Alphaは唯一のowning call以外すべてexact、Rankingは新method以外すべてexact、元のtest/import bytesもすべてexact。Rootが現在の対象beforerefsへ薄いpatchだけを適用し、古い全postimageを共有Mainに上書きしない。

 scoped Rustfmt write/checkとhelper Ruff format/lintを実行した。初回static proofはRustfmt後の`matches!`が複数行なのにhelperが一行を期待したため、**patch生成前にrefused**。元のfailure/capture/persisted pending-attempted/returnedguardian不在を [initial-static-refusal.json](initial-static-refusal.json) に保持した。Rust sourceを変えず、helperの期待文字列だけを整形済みliteralへ修正し、新しいunfinished proofを実行した。最終forward/inverse/protected-bodyの静的確認はPASS。

各有限format/static childはCPU3・family512MiB・host reserve4GiB・GPU0、maintained CycleResources/execute・full capture・no_new_privsを使用した。7 original childはfresh不在/別identity、directreap/handles/remaining[]、proof TMPは消失。成功時のreturned settled masksと元のpersisted masksは別々に保存する。失敗commandで返らなかったguardianを作らない。詳細は [process-facts.json](process-facts.json) と各元receipt。sourceは最終STOPから固定し、idleleaseを保持しない。

Rootの将来評価は既存Control O-N-N-O24/12sessions/72Mだけ。Oは真正387 ced70ad8/Buildf4482c31、Nはsoftware後の真正imageが必要。depth/valuebits/action/PV/ALLwork/legal/fullhistory/parentの完全一致、whole N中央値≤O、同root両NがO中央値×1.10超なしを保持する。作者から測定発行は0。未知のbenefitを採用や一般速度・強さ・default変更へ広げない。追加sampling/warmup/refill/tuning/Cheap/games/fitは0。

OWN affected usageを一度観測して最終STOPへ結合する。共有asset/cache/target/private/model/RAWや旧evidenceを新増加として数えず、global実使用/連続peakはUNKNOWN。old FAILED/RAW/fees/UNKNOWN、323USERPAUSE/fits96/models/defaults/N/seals/mixed science UNSELECTEDを保持する。leafはRootのrequired scope受入れまでopenで、作者からreview dispatch・Policy copyは行わない。
