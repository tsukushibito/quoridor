"""Administrative command-list formatting, preserving exact parsed argv values."""

import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
paths = sorted(HERE.glob("*-commands.json"))
original = {p: p.read_bytes() for p in paths}
parsed = {p: json.loads(raw) for p, raw in original.items()}
subprocess.run(
    [
        "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier",
        "--config",
        "/workspaces/quoridor/tools/research-quality/.prettierrc.json",
        "--write",
        *map(str, paths),
        str(HERE / "report.md"),
    ],
    timeout=120,
    check=True,
)
for path in paths:
    assert json.loads(path.read_bytes()) == parsed[path]
    (HERE / (path.name + ".before-format.txt")).write_bytes(original[path])
(HERE / "administrative-format-correspondence.json").write_text(
    json.dumps(
        [
            {
                "path": str(p),
                "before_sha256": hashlib.sha256(original[p]).hexdigest(),
                "after_sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                "parsed_argv_unchanged": True,
            }
            for p in paths
        ],
        indent=2,
    )
    + "\n"
)
subprocess.run(
    [
        "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier",
        "--config",
        "/workspaces/quoridor/tools/research-quality/.prettierrc.json",
        "--check",
        *map(str, paths),
        str(HERE / "report.md"),
    ],
    timeout=120,
    check=True,
)
print(
    "Administrative command lists formatting only/parsed argv equal; original configs preserved; FAILED/results/checkpoint/scientific records untouched"
)
