"""Finite named current ordering/source intake, no native or scientific calls."""

import gzip
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path("/workspaces/quoridor")
OWN = Path.cwd()
OUT = Path(__file__).resolve().parent
paths = [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-ai/src/move_ordering.rs",
    "crates/quoridor-ai/src/continuation_history.rs",
    "crates/quoridor-ai/src/move_ordering_tests.rs",
    "crates/quoridor-ai/src/ordering_work394_tests.rs",
    "crates/quoridor-ai/src/tt_first386_tests.rs",
]
refs = []
for i, relative in enumerate(paths):
    p = ROOT / relative
    raw = p.read_bytes()
    if i == 0:
        assert (
            hashlib.sha256(raw).hexdigest()
            == "657b6ae516382472887200367b0aae6a96cea11589554e3075af5c080ecacfe3"
        )
    (OUT / f"{i}.Main-before.gz").write_bytes(gzip.compress(raw, mtime=0))
    own = OWN / relative
    prior = own.read_bytes() if own.exists() else None
    if prior is not None:
        (OUT / f"{i}.OWN-before.gz").write_bytes(gzip.compress(prior, mtime=0))
    own.write_bytes(raw)
    refs.append(
        {
            "relative": relative,
            "Main": {
                "path": str(p),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": format(stat.S_IMODE(p.stat().st_mode), "04o"),
            },
            "prior_OWN": "ABSENT"
            if prior is None
            else hashlib.sha256(prior).hexdigest(),
        }
    )
result = {
    "status": "NAMED_ORDERING_SOURCE_INTAKE_PASS",
    "refs": refs,
    "scope": "Current six necessaryAI subjects only, previous OWN bytes preserved; no fullcheckout mirror",
    "Main_Git_index_writes": 0,
    "native_test_geometry_model_Search_Perf_calls": 0,
    "new_test_before": "ABSENT",
}
assert not (ROOT / "crates/quoridor-ai/src/deferred_tail399_tests.rs").exists()
assert not (OWN / "crates/quoridor-ai/src/deferred_tail399_tests.rs").exists()
(OUT / "current-intake.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    "Current Alpha657b + ordering/diagnostic subjects captured; prior OWN preserved; no native/scientific calls"
)
