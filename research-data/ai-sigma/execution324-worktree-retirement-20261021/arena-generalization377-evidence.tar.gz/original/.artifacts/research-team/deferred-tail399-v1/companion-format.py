"""Parse/format only the captured result fragment; no new Main reader."""

from pathlib import Path
import os
import re
import subprocess

HERE = Path(__file__).resolve().parent
fragment = (HERE / "measurement-output-after.rs.fragment").read_text()
temporary = Path(os.environ["TMPDIR"]) / "companion.rs"
temporary.write_text(
    "fn companion(o: &OrderingStats) {\n    let mut result = json!({\n"
    + fragment
    + "\n}\n"
)
try:
    subprocess.run(
        [
            "/usr/local/cargo/bin/rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            str(temporary),
        ],
        timeout=120,
        check=True,
    )
    formatted = temporary.read_text()
    start = formatted.index('        "ordering":')
    end = formatted.rfind("\n}")
    assert formatted[start:end] == fragment.rstrip("\n")
    # No typing claim: only every emitted field has an actual owning definition.
    definitions = (
        Path.cwd() / "crates/quoridor-ai/src/continuation_history.rs"
    ).read_text()
    for member in re.findall(r"\b[ow]\.([a-z_]+)", fragment):
        assert re.search(r"pub " + member + r"\s*:", definitions), member
    print(
        "Captured companion Rustfmt parsing/format PASS; emitted field definitions present; UNBUILT/UNTYPED/UNRUN"
    )
finally:
    temporary.unlink()
