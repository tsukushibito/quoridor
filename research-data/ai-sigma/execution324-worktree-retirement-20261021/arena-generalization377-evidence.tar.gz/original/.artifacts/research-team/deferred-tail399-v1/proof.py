"""Finite strict patch roundtrip and protected owning subject checks, no native."""

import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess

HERE = Path(__file__).resolve().parent
OWN = Path.cwd()
intake = json.loads((HERE / "current-intake.json").read_text())
indexes = [0, 1, 2, 4]
before = {
    intake["refs"][i]["relative"]: gzip.decompress(
        (HERE / f"{i}.Main-before.gz").read_bytes()
    )
    for i in indexes
}
new = "crates/quoridor-ai/src/deferred_tail399_tests.rs"
before[new] = b""
after = {name: (OWN / name).read_bytes() for name in before}


def patch(left, right):
    result = []
    for name in left:
        result.extend(
            difflib.unified_diff(
                left[name].decode().splitlines(True),
                right[name].decode().splitlines(True),
                "/dev/null" if not left[name] else "a/" + name,
                "/dev/null" if not right[name] else "b/" + name,
            )
        )
    return "".join(result)


forward = patch(before, after)
inverse = patch(after, before)
(HERE / "deferred-tail399.patch").write_text(forward)
(HERE / "deferred-tail399.inverse.patch").write_text(inverse)
tmp = Path(os.environ["TMPDIR"]) / "strict-roundtrip"
tmp.mkdir()
try:
    for name, raw in before.items():
        if raw:
            path = tmp / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
    for label, text, expected in [
        ("forward", forward, after),
        ("inverse", inverse, before),
    ]:
        returned = subprocess.run(
            ["/usr/bin/patch", "--batch", "--fuzz=0", "--no-backup-if-mismatch", "-p1"],
            input=text,
            text=True,
            cwd=tmp,
            capture_output=True,
            timeout=120,
            check=True,
        )
        assert "offset" not in returned.stdout and "fuzz" not in returned.stdout
        for name, raw in expected.items():
            path = tmp / name
            assert path.read_bytes() == raw if raw else not path.exists()
        print(label, "GNU patch exact bytes PASS/no fuzz/no offset")
finally:
    shutil.rmtree(tmp)


def method(raw, name):
    text = raw.decode()
    start = text.index("    fn " + name + "(")
    end = re.search(r"\n    (?:fn |#\[)", text[start + 5 :])
    assert end is not None
    return text[start : start + 5 + end.start()]


alpha = "crates/quoridor-ai/src/alphabeta.rs"
protected = {}
for name in ["control", "enter", "ordering_scores", "child", "root_depth"]:
    original = method(before[alpha], name)
    current = method(after[alpha], name)
    assert current == original, name
    protected[name] = hashlib.sha256(current.encode()).hexdigest()
# TT probe/depth/context/numeric cutoff and completed history/TT epilogue unchanged.
old_node = method(before[alpha], "negamax")
new_node = method(after[alpha], "negamax")
for name, left, right in [
    ("TT_and_legal_before_preparation", None, "        let mut deferred = None;"),
    (
        "child_PVS_and_completed_history_TT_epilogue",
        "            let mut v = if self.limits.use_pvs",
        "\n        if let Some(work) = node_work {",
    ),
]:
    old = (
        old_node[: old_node.index(right)]
        if left is None
        else old_node[
            old_node.index(left) : old_node.index(right, old_node.index(left))
        ]
    )
    current = (
        new_node[: new_node.index(right)]
        if left is None
        else new_node[
            new_node.index(left) : new_node.index(right, new_node.index(left))
        ]
    )
    assert old == current, name
    protected[name] = hashlib.sha256(current.encode()).hexdigest()
history = "crates/quoridor-ai/src/continuation_history.rs"
start = "pub(super) const LAGS"
end = "/// Observation-only work."
original = before[history].decode()
current = after[history].decode()
old = original[original.index(start) : original.index(end)]
now = current[current.index(start) : current.index(end)]
# Strip only expanded diagnostic fields; all history arithmetic/table code stays exact.
old_history = old[old.index("/// Actual mover") :]
new_history = now[now.index("/// Actual mover") :]
assert old_history == new_history
protected["history_index_scoring_update_aging"] = hashlib.sha256(
    new_history.encode()
).hexdigest()
ordering = "crates/quoridor-ai/src/move_ordering.rs"
old = before[ordering].decode()
now = after[ordering].decode()
assert (
    old[: old.index("    pub fn sort_control")]
    == now[: now.index("    pub fn sort_control")]
)
protected["Ranking_priority_policy_total_cmp_signed_unsigned"] = hashlib.sha256(
    old[: old.index("    pub fn sort_control")].encode()
).hexdigest()
for i in [3, 5]:
    relative = intake["refs"][i]["relative"]
    assert (OWN / relative).read_bytes() == gzip.decompress(
        (HERE / f"{i}.Main-before.gz").read_bytes()
    )
    protected[relative] = intake["refs"][i]["Main"]["sha256"]
tests = re.findall(r"#\[test\]\s*fn (control399_[a-z0-9_]+)", after[new].decode())
assert len(tests) == 6
refs = []
for name, raw in after.items():
    path = OWN / name
    refs.append(
        {
            "relative": name,
            "before": "ABSENT"
            if not before[name]
            else {
                "sha256": hashlib.sha256(before[name]).hexdigest(),
                "bytes": len(before[name]),
            },
            "after": {
                "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
            },
        }
    )
(HERE / "static-proof.json").write_text(
    json.dumps(
        {
            "status": "STATIC_EXACT_ROUNDTRIP_PASS",
            "GNU_patch": "forward/inverse --batch --fuzz=0, exact/nooffset/no backups; new absence restored",
            "protected": protected,
            "subjects": refs,
            "new_test_names": tests,
            "new_test_count": len(tests),
            "affected_existing_names": [
                "control394_deferred_remainder_excludes_tt_and_counts_all_consumed",
                "control394_first_last_sorted_cutoffs_and_root_pvs_count_distinct_moves",
                "control394_cancel_error_and_limit_leave_started_work_unfinished_parent_exact",
            ],
            "native_compile_type_tests": "UNBUILT/UNTYPED/UNRUN",
            "Main_Git_index_Cargo_native_model_Search_Perf_writes_or_calls": 0,
        },
        indent=2,
    )
    + "\n"
)
print(
    "Protected search/math/history/comparator subjects exact; six new + three affected definitions UNRUN"
)
