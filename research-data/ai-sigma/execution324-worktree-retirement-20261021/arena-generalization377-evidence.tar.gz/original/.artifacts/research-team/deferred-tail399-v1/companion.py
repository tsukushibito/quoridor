"""Capture only the current output boundary and propose its sparse JSON delta."""

import difflib
import hashlib
import json
from pathlib import Path
import stat

HERE = Path(__file__).resolve().parent
path = Path("/workspaces/quoridor/crates/quoridor-runner/src/measurement.rs")
raw = path.read_bytes()
before = raw.decode()
after = before
for name in [
    "history_compared_nodes",
    "first_choice_compared_nodes",
    "first_choice_changed_nodes",
]:
    needle = '"history_changed_nodes":o.history_changed_nodes,'
    assert before.count(needle) == 1
    after = after.replace(needle, needle + f'"{name}":o.{name},', 1)
needle = '"static_changed_nodes":o.static_changed_nodes'
assert before.count(needle) == 1
after = after.replace(
    needle, needle + ',"static_compared_nodes":o.static_compared_nodes', 1
)
for anchor, names in [
    (
        "preparation_actions_requested",
        [
            "first_selection_calls_started",
            "first_selection_actions_started",
            "selected_reads_started",
            "selected_returns_started",
        ],
    ),
    (
        "sort_nodes_finished",
        [
            "prepared_nodes_finished",
            "selected_reads_finished",
            "selected_returns_finished",
            "selected_cutoff_no_tail_sort_nodes",
        ],
    ),
]:
    needle = f'            "{anchor}": w.{anchor},\n'
    assert before.count(needle) == 1
    after = after.replace(
        needle,
        needle + "".join(f'            "{n}": w.{n},\n' for n in names),
        1,
    )
patch = "".join(
    difflib.unified_diff(
        before.splitlines(True),
        after.splitlines(True),
        "a/crates/quoridor-runner/src/measurement.rs",
        "b/crates/quoridor-runner/src/measurement.rs",
    )
)
(HERE / "measurement-companion.patch").write_text(patch)
lines = before.splitlines(True)
start = next(i for i, line in enumerate(lines) if '"ordering":{"ordered_nodes"' in line)
end = (
    next(
        i
        for i in range(start, len(lines))
        if '"consumed_fraction_finished"' in lines[i]
    )
    + 4
)
(HERE / "measurement-output-before.rs.fragment").write_text("".join(lines[start:end]))
(HERE / "measurement-output-after.rs.fragment").write_text(
    "".join(after.splitlines(True)[start : end + 8])
)
(HERE / "measurement-companion.json").write_text(
    json.dumps(
        {
            "before": {
                "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
            },
            "output_fragment_first_line": start + 1,
            "scope": "Existing saved result ordering/work JSON only; Root composition, no runner writer by author",
            "denominators": {
                "history_changed_nodes": "history_compared_nodes: full eager sorted adjacency only",
                "static_changed_nodes": "static_compared_nodes: full eager sorted adjacency only",
                "first_choice_changed_nodes": "first_choice_compared_nodes: eligible Control first-choice vs rank+ID without history",
                "consumed_fraction_finished": "selected+sorted distinct reads / prepared actions; TT excluded",
                "sort_actions_finished": "actual full eager sorted list or actual deferred sorted suffix, never an unsorted tail",
            },
            "native_status": "UNBUILT/UNTYPED/UNRUN; proposed Root companion only",
        },
        indent=2,
    )
    + "\n"
)
print("Sparse existing result JSON companion captured; no Main write")
