"""Stopped source metadata, original child census, one directed usage observation."""

import hashlib
import json
import os
from pathlib import Path
import resource
import stat
from datetime import datetime, timezone

os.sched_setaffinity(0, {3})
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
HERE = Path(__file__).resolve().parent
OWN = Path.cwd()


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
phases = []
children = []
for phase in [
    "intake-v1",
    "format-v1",
    "format-v2",
    "final-check-v1",
    "final-quality-v1",
    "freeze-v1",
    "delivery-format-v1",
]:
    result_path = HERE / phase / "result.json"
    result = json.loads(result_path.read_text())
    assert not result["TMP_remaining"]
    assert not (HERE / phase / "TMP").exists()
    phases.append(
        {
            "result": ref(result_path),
            "status": result["status"],
            "reader_STOP": result["reader_STOP"],
            "primary": result["primary"],
        }
    )
    for check in result["checks"]:
        returned = check.get("guardian_return")
        if not returned:
            continue
        identity = returned.get("child")
        if not identity:
            continue
        proc = Path(f"/proc/{identity['pid']}/stat")
        current = None
        if proc.exists():
            tail = proc.read_text().rsplit(")", 1)[1].split()
            current = {"pid": identity["pid"], "start_ticks": tail[19], "boot_id": boot}
        assert current != identity, (phase, check["name"], identity)
        assert returned["direct_child_reaped"] and returned["remaining"] == []
        assert returned["cleanup_complete"] and returned["handle_closes_complete"]
        assert check["capture_complete"]
        persisted_ref = check["persisted_process_receipt"]
        persisted_path = Path(persisted_ref["path"])
        assert ref(persisted_path) == persisted_ref
        persisted = json.loads(persisted_path.read_text())
        children.append(
            {
                "phase": phase,
                "name": check["name"],
                "original_identity": identity,
                "fresh_identity": current,
                "fresh_status": "absent" if current is None else "different",
                "directwait_exit": returned["exit_code"],
                "direct_reaped": returned["direct_child_reaped"],
                "cleanup_complete": returned["cleanup_complete"],
                "handles_complete": returned["handle_closes_complete"],
                "capture_complete": check["capture_complete"],
                "fullcapture": check["full_log"],
                "returned_signal_mask_restoration": returned.get(
                    "signal_mask_restoration"
                ),
                "returned_final_record_persist": returned.get("final_record_persist"),
                "original_disk_signal_mask_restoration": persisted.get(
                    "signal_mask_restoration"
                ),
                "original_disk_final_record_persist": persisted.get(
                    "final_record_persist"
                ),
                "persisted_receipt": persisted_ref,
                "no_new_privs": returned.get("launch_policy"),
                "original_maintenance_seconds": returned["wall_seconds"],
            }
        )
proof = json.loads((HERE / "static-proof.json").read_text())
assert proof["status"] == "STATIC_EXACT_ROUNDTRIP_PASS"
for subject in proof["subjects"]:
    assert ref(Path(subject["after"]["path"])) == subject["after"]
selected = [
    "deferred-tail399.patch",
    "deferred-tail399.inverse.patch",
    "static-proof.json",
    "report.md",
    "measurement-companion.patch",
    "measurement-companion.json",
    "measurement-output-before.rs.fragment",
    "measurement-output-after.rs.fragment",
    "current-intake.json",
]
refs = {name: ref(HERE / name) for name in selected}
for i in [0, 1, 2, 4]:
    refs[f"{i}.Main-before.gz"] = ref(HERE / f"{i}.Main-before.gz")
# One affected observation; directory/inode dedupe, no unrelated assets/global scan.
seen = set()
allocated = 0
logical = 0
files = 0
paths = [HERE, *[Path(s["after"]["path"]) for s in proof["subjects"]]]
for path in paths:
    visited = [path] if path.is_file() else [path, *path.rglob("*")]
    for candidate in visited:
        info = candidate.lstat()
        assert not stat.S_ISLNK(info.st_mode), candidate
        identity = (info.st_dev, info.st_ino)
        if identity in seen:
            continue
        seen.add(identity)
        allocated += info.st_blocks * 512
        if stat.S_ISREG(info.st_mode):
            logical += info.st_size
            files += 1
fs = os.statvfs(HERE)
available = fs.f_bavail * fs.f_frsize
assert available >= 4 * 1024**3, available
result = {
    "status": "STOPPED_SOURCE_STATIC_CLEAR_NATIVE_PENDING",
    "issue": "quoridor-4lc.399.1",
    "claimant": "codex:01a11004-79f3-7c20-872c-432a2c347664",
    "context": {
        "turn": "01a13a4a-8ea9-7733-907e-1b1cdacd0eac",
        "cwd": str(OWN),
        "model": "gpt-6.1-sol",
        "effort": "high",
        "sandbox": "danger-full-access",
        "approvalPolicy": "never",
        "actual_verified": True,
    },
    "source_guard_last_STOP": phases[-1]["reader_STOP"],
    "source_guard_release": "normal lease/helper/public common-env wrapper return; independent UTC UNKNOWN",
    "source_metadata_stamp": datetime.now(timezone.utc).isoformat(),
    "owned_readers": [],
    "owned_writers": [],
    "owned_children": [],
    "owned_jobs": [],
    "owned_handles": [],
    "owned_TMP": [],
    "owned_leases": [],
    "metadata_scope": "Source already frozen/guarded commands returned; this receipt creation then directwait, Beads+backup/send administrative only",
    "phases": phases,
    "original_children": children,
    "nested_patch_rustfmt_child_identity": "not individually recorded; bounded guardian session descendants/directwait captured, original helper returned; exact fast-child PID UNKNOWN",
    "refs": refs,
    "subjects": proof["subjects"],
    "new_tests": proof["new_test_names"],
    "affected_tests": proof["affected_existing_names"],
    "remaining": "Root research/research-diagnostics type/compile, new6+affected3, affected Clippy, genuine optimized N, narrow independent ordering/keyfreeze/tail/diagnostic review, already selected NNUE4K+fixedD1M ONNO48",
    "native_type_compile_tests": "UNBUILT/UNTYPED/UNRUN",
    "scientific_native_model_Search_Perf_Cargo_calls": 0,
    "Main_Git_index_runner_python_writes": 0,
    "old_checkpoint_a14b": "immutable; not rewritten to current STOP",
    "398": "Root reported exact correspondence but timingFAIL1.0006667799, rollback4f39f3bd; unaccepted geometry excluded from399 O/N",
    "usage": {
        "scope": "OWN399 evidence including original failed controls/captures + five changed AI files, inode overlap counted once; before final receipt/admin outputs",
        "storage_budget": None,
        "allocated_B": allocated,
        "regular_logical_B": logical,
        "regular_files": files,
        "observed_FS_available_B": available,
        "FS_reserve_B": 4 * 1024**3,
        "continuous_peak": "UNKNOWN",
        "whole_global_actual": "UNKNOWN",
        "global_decimal_cap_B": 50_000_000_000,
    },
}
(HERE / "source-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
stop_ref = ref(HERE / "source-STOP.json")
(HERE / "handoff.txt").write_text(
    "399.1 frozen sourceSTOP " + json.dumps(stop_ref) + "\n"
    "ONE Control/no-policy/signed exact-first selection then once-needed frozen-key tail sort. Root eager/provider/unsigned/Cheap/Coverage remain eager. Five AI paths; source patch/inverse, protected math/history/root/child/TT epilogue byteexact and newfile absence roundtrip PASS. New6+affected394three definitions UNBUILT/UNTYPED/UNRUN. Measurement output companion sparse proposal only (before22423996/42851), no runner/Main write. Key1672B + enum frame/recursive lifetime cost explicit UNKNOWN. Full-order diagnostics denominator only eager; deferred first-choice/prepared vs selected/sorted truthful.\n"
    "Format/lint/static PASS; original format-v1 EAGAIN checks[] and final-check-v1 Node ENOENT preserved. Last actual readerSTOP "
    + phases[-1]["reader_STOP"]
    + "; original returned vs disk masks distinct; all original recorded children freshabsent/different/directreap/handles/fullcaptures/TMPgone, owned[]. No native/test/Search/model/Perf/Cargo execution. Affected usage "
    + str(allocated)
    + " allocatedB once before final receipt/admin, budgetNone/globalactualUNKNOWN.\n"
    "Root only software+one narrow review+true N+approved NNUE4K/fixedD1M ONNO48; no398 rejected geometry, no newcalls/tuning/refill. Leaf staysin_progress until acceptance. Mixed/learner and323USERPAUSE/defaults/models/seals/historyRAWFAILEDUNKNOWN retained. No Policycopy/ACK gate.\n"
)
print(
    json.dumps(
        {
            "source_STOP": stop_ref,
            "owned": [],
            "usage_allocated_B": allocated,
            "native": "UNBUILT/UNTYPED/UNRUN",
        }
    )
)
