"""Scoped source/byte correspondence; no native code or scientific execution."""

import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import stat
import subprocess

OWN = Path.cwd()
OUT = OWN / ".artifacts/research-team/fixed-d-generation392-v1"
intake = json.loads((OUT / "source-intake.json").read_text())
paths = [r["relative"] for r in intake["refs"] if not r.get("companion_only")]
before = {
    p: gzip.decompress((OUT / f"{i}.before.gz").read_bytes())
    for i, p in enumerate(paths)
}
after = {p: (OWN / p).read_bytes() for p in paths}
for label, path in [
    ("data", "crates/quoridor-data/src/terminal_stream.rs"),
    ("data-test", "crates/quoridor-data/tests/terminal_stream.rs"),
]:
    before[path] = gzip.decompress((OUT / (label + ".before.gz")).read_bytes())
    after[path] = (OUT / ("companion-" + label + ".rs")).read_bytes()
    (OUT / (label + ".after.gz")).write_bytes(gzip.compress(after[path], mtime=0))
# Compose only two formatted Python owning function subjects; never install a publisher copy.
publisher = "scripts/dev/research-lifecycle.py"
before[publisher] = gzip.decompress((OUT / "publisher.before.gz").read_bytes())
original = before[publisher].decode().splitlines(True)
formatted = (OUT / "publisher-fragments.py").read_text().splitlines(True)
fragments = {
    n.name: "".join(formatted[n.lineno - 1 : n.end_lineno])
    for n in ast.parse("".join(formatted)).body
    if isinstance(n, ast.FunctionDef)
}
assert set(fragments) == {"measurement_config", "experiment_phase_check"}
for node in sorted(
    ast.parse("".join(original)).body, key=lambda n: n.lineno, reverse=True
):
    if isinstance(node, ast.FunctionDef) and node.name in fragments:
        original[node.lineno - 1 : node.end_lineno] = fragments[node.name].splitlines(
            True
        )
after[publisher] = "".join(original).encode()


# No compiler, source qualifier, model load or old test imports are involved.
def function(text, signature):
    start = text.index(signature)
    brace = text.index("{", start)
    depth = 0
    for i in range(brace, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    raise AssertionError(signature)


protected = []
for path, signatures in {
    paths[0]: [
        "fn child(",
        "fn root_depth(",
        "fn control(",
        "pub fn new_with_score_domain(",
        "pub fn new_without_continuation_or_static(",
        "pub fn new_for_ordering_assessment(",
    ],
    paths[1]: ["pub fn sort_control("],
    paths[2]: ["pub(super) fn prepare("],
    paths[3]: ["pub(super) fn prepare(", "fn validate_maps("],
    paths[4]: [
        "fn play_using_policy(",
        "fn audit_game_policy(",
        "fn summarize(",
        "fn reserve(",
        "fn settle(",
    ],
    paths[7]: ["fn drive(", "fn validate_return(", "fn prepare_roots("],
}.items():
    for signature in signatures:
        assert function(before[path].decode(), signature) == function(
            after[path].decode(), signature
        ), (path, signature)
        protected.append([path, signature])
assert "step_by(workers)" not in after[paths[6]].decode()
assert "mpsc::sync_channel(workers)" in after[paths[6]].decode()
assert "next.fetch_add(1, Ordering::Relaxed)" in after[paths[6]].decode()
assert "index == recorded" not in after[paths[5]].decode()
assert (
    "record.index != census.recorded"
    not in after["crates/quoridor-data/src/terminal_stream.rs"].decode()
)
# Current publisher outside two owned functions is byte exact.
for patch_name, left, right in [
    ("source.patch", before, after),
    ("source.inverse.patch", after, before),
]:
    chunks = []
    for path in before:
        chunks.extend(
            difflib.unified_diff(
                left[path].decode().splitlines(True),
                right[path].decode().splitlines(True),
                fromfile="a/" + path,
                tofile="b/" + path,
            )
        )
    (OUT / patch_name).write_text("".join(chunks))
TMP = OUT / "proof-TMP"
TMP.mkdir()
try:
    for path, raw in before.items():
        p = TMP / path
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(raw)
    captures = []
    for patch_name, expected in [
        ("source.patch", after),
        ("source.inverse.patch", before),
    ]:
        result = subprocess.run(
            [
                "/usr/bin/patch",
                "--batch",
                "--fuzz=0",
                "-p1",
                "-i",
                str(OUT / patch_name),
            ],
            cwd=TMP,
            capture_output=True,
            text=True,
            check=True,
        )
        assert not re.search(r"offset|fuzz|FAILED", result.stdout + result.stderr)
        captures.append(
            {
                "patch": patch_name,
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
        )
        assert all((TMP / path).read_bytes() == raw for path, raw in expected.items())
finally:
    shutil.rmtree(TMP)


def ref(path):
    b = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(b).hexdigest(),
        "bytes": len(b),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


new_definitions = []
for path in before:
    old_names = set(re.findall(r"fn (\w+)\(", before[path].decode()))
    for name in re.findall(r"fn (fixed_d392_\w+)\(", after[path].decode()):
        if name not in old_names:
            new_definitions.append({"path": path, "name": name})
assert len(new_definitions) == 7
result = {
    "status": "STATIC_BYTE_PROOF_PASS",
    "before_refs": [r["Main"] for r in intake["refs"]],
    "owned_postimages": [ref(OWN / p) for p in paths],
    "companion_after_subjects": [
        {
            "Main_path": "/workspaces/quoridor/" + p,
            "sha256": hashlib.sha256(after[p]).hexdigest(),
            "bytes": len(after[p]),
            "mode": "0644",
            "not_installed": True,
        }
        for p in before
        if p not in paths
    ],
    "forward": ref(OUT / "source.patch"),
    "inverse": ref(OUT / "source.inverse.patch"),
    "GNU_zero_fuzz_zero_offset_and_exact_inverse": captures,
    "unchanged_function_bodies": protected,
    "new_definitions": new_definitions,
    "native_status": "UNBUILT/UNTYPED/UNRUN",
    "temporary_proof_tree_absent": not TMP.exists(),
    "source_model_native_Cargo_Search_Perf_geometry_game_fit_execution": 0,
}
(OUT / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    "Static protected bodies / forward / inverse / seven new definitions PASS; native UNRUN"
)
