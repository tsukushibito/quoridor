def measurement_config(experiment):
    """Functional shapes only; settings and input order belong to the run."""
    config = document(experiment["config"])
    requests = document(experiment["schedule"])
    require(
        isinstance(config, dict)
        and set(config)
        <= {
            "roots",
            "profile",
            "tt_entries",
            "use_tt",
            "use_pvs",
            "namespace",
            "output_bytes",
            "record_bytes",
            "seed",
        }
        and {
            "roots",
            "profile",
            "tt_entries",
            "use_tt",
            "use_pvs",
            "namespace",
            "output_bytes",
            "record_bytes",
        }
        <= set(config),
        "measurement settings shape",
    )
    require(
        config["profile"] in {"control", "cheap", "coverage"},
        "configured ordering target",
    )
    for key in ("tt_entries", "output_bytes", "record_bytes"):
        require(
            type(config[key]) is int and config[key] > 0, "measurement positive " + key
        )
    require(
        config["record_bytes"] <= config["output_bytes"],
        "measurement record/output limit",
    )
    require(
        all(type(config[key]) is bool for key in ("use_tt", "use_pvs")),
        "measurement Boolean switches",
    )
    require(
        config.get("seed") is None
        or (type(config["seed"]) is int and 0 <= config["seed"] < 2**64),
        "measurement seed metadata",
    )
    namespace = config["namespace"]
    require(
        isinstance(namespace, dict)
        and set(namespace) == {"evaluator", "rules", "selectivity"}
        and all(isinstance(v, str) and v for v in namespace.values())
        and namespace["rules"] == experiment["rules"],
        "measurement namespace",
    )
    require(isinstance(config["roots"], list) and config["roots"], "measurement roots")
    for root in config["roots"]:
        require(
            isinstance(root, dict)
            and {"input", "pointer", "field", "label"} <= set(root)
            and set(root)
            <= {
                "input",
                "pointer",
                "field",
                "label",
                "prefix_len",
                "jsonl_match",
                "check_history",
            }
            and type(root["input"]) is int
            and 0 <= root["input"] < len(experiment["inputs"])
            and all(isinstance(root[k], str) for k in ("pointer", "field", "label"))
            and (not root["pointer"] or root["pointer"].startswith("/"))
            and bool(root["field"]),
            "measurement root selector",
        )
        require(
            root.get("prefix_len") is None
            or (type(root["prefix_len"]) is int and root["prefix_len"] >= 0),
            "chronological prefix length",
        )
        require(
            root.get("jsonl_match") is None or isinstance(root["jsonl_match"], dict),
            "JSONL selection",
        )
        require(type(root.get("check_history", False)) is bool, "history check switch")
    require(isinstance(requests, list), "measurement request array")
    ids, closed, active = set(), set(), None
    for request in requests:
        require(
            isinstance(request, dict)
            and {"id", "session", "root", "depth", "node_cap"} <= set(request)
            and set(request)
            <= {
                "id",
                "session",
                "root",
                "depth",
                "node_cap",
                "time_limit_ms",
                "diagnostic",
                "warmup",
            }
            and all(
                isinstance(request[k], str) and request[k] for k in ("id", "session")
            )
            and request["id"] not in ids
            and type(request["root"]) is int
            and 0 <= request["root"] < len(config["roots"])
            and type(request["depth"]) is int
            and 0 < request["depth"] < 2**16
            and type(request["node_cap"]) is int
            and 0 < request["node_cap"] < 2**64,
            "measurement request type/range/identity",
        )
        require(
            request.get("time_limit_ms") is None
            or (
                type(request["time_limit_ms"]) is int
                and 0 < request["time_limit_ms"] < 2**64
            ),
            "measurement optional deadline",
        )
        require(
            all(type(request.get(k, False)) is bool for k in ("diagnostic", "warmup")),
            "measurement request switches",
        )
        ids.add(request["id"])
        if active != request["session"]:
            require(request["session"] not in closed, "session reused after teardown")
            if active is not None:
                closed.add(active)
            active = request["session"]
    return config, requests


def experiment_phase_check(experiment):
    phase = experiment["phase"]
    require(
        phase
        in {
            "generation",
            "materialize",
            "compare",
            "arena",
            "analysis",
            "corpus",
            "fit",
            "software-qualification",
        },
        "phase",
    )
    if phase == "compare" and experiment["argv"][1] == "measure":
        config = document(experiment["config"])
        fixed_d = config["namespace"]["evaluator"] == "original-distance-a0-b8-tanh"
        require(
            (
                fixed_d
                and experiment["models"] == []
                and config["profile"] in {"control", "coverage"}
            )
            or (
                not fixed_d
                and len(experiment["models"]) == 1
                and config["profile"] in {"control", "cheap"}
            ),
            "measurement evaluator/model/profile binding",
        )
        return
    if phase == "software-qualification":
        require(
            experiment.get("numerical_qualification") is None
            and experiment["planned_slots"] == 0
            and experiment.get("batch") is None,
            "software-only qualifier cannot claim numerical/game qualification",
        )
        return
    if phase == "materialize" and experiment.get("numerical_qualification") is None:
        require(
            experiment["models"] == []
            and experiment["planned_slots"] == 0
            and experiment.get("batch") is None,
            "saved codec cannot claim model/numerical/game qualification",
        )
        return
    if phase != "generation":
        require(
            isinstance(experiment.get("numerical_qualification"), dict),
            "non-generation numerical qualification required",
        )
        return
    require(
        experiment.get("numerical_qualification") is None
        and experiment["models"] == []
        and type(experiment["planned_slots"]) is int
        and experiment["planned_slots"] == 0
        and experiment.get("batch") is None,
        "generation-only model-free non-game bootstrap",
    )
    require(
        len(experiment["argv"]) == 6
        and experiment["argv"][1:]
        == [
            "strength-book",
            "--experiment",
            "@EXPERIMENT@",
            "--experiment-sha256",
            "@EXPERIMENT_SHA256@",
        ],
        "generation exact strength-book argv",
    )
    require(
        experiment["canonical_plan_sha256"] == GENERATION_PLAN
        and experiment["rules"] == "research-standard-2p-threefold-goal-first-v1"
        and experiment["distance_units"] == "wall-distance/80"
        and experiment["value_perspective"] == "side-to-move",
        "generation scientific identity",
    )
