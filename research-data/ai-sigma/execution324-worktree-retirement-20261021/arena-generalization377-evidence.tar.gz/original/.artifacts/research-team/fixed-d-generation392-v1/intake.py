"""Finite selected-source intake under the maintained reader lease."""

import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = Path.cwd()
OUT = OWN / ".artifacts/research-team/fixed-d-generation392-v1"
loader = importlib.util.spec_from_file_location(
    "lc392", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
paths = [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-ai/src/move_ordering.rs",
    "crates/quoridor-ai/src/static_ordering.rs",
    "crates/quoridor-ai/src/cheap_static_ordering.rs",
    "crates/quoridor-runner/src/teacher_pilot_execution.rs",
    "crates/quoridor-runner/src/teacher_pilot_execution/depth6.rs",
    "crates/quoridor-runner/src/teacher_pilot_execution/scheduling.rs",
    "crates/quoridor-runner/src/measurement.rs",
    "crates/quoridor-runner/src/research_manifest.rs",
]
refs = []
affinity = os.sched_getaffinity(0)
spec = {
    "kind": "software",
    "limits": {
        "family_B": 512 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "worker_cpu": 3,
        "guardian_cpu": 4,
    },
}
try:
    with lc.lease(), lc.process.cancellation_signals():
        lc.physical_and_quiet(spec)
        os.sched_setaffinity(0, {3})
        for i, name in enumerate(paths):
            main = MAIN / name
            own = OWN / name
            b = main.read_bytes()
            old = own.read_bytes() if own.exists() else None
            (OUT / f"{i}.before.gz").write_bytes(gzip.compress(b, mtime=0))
            if old is not None and old != b:
                (OUT / f"{i}.OWN-before.gz").write_bytes(gzip.compress(old, mtime=0))
            refs.append(
                {
                    "relative": name,
                    "Main": lc.artifact_ref(main),
                    "own_before_sha256": hashlib.sha256(old).hexdigest()
                    if old is not None
                    else None,
                    "synced": old != b,
                }
            )
            if old != b:
                own.parent.mkdir(parents=True, exist_ok=True)
                own.write_bytes(b)
        # Required foreign consumers: keep only compressed beforebytes, not a source mirror.
        for name, label in [
            ("crates/quoridor-data/src/terminal_stream.rs", "data"),
            ("crates/quoridor-data/tests/terminal_stream.rs", "data-test"),
            ("scripts/dev/research-lifecycle.py", "publisher"),
        ]:
            p = MAIN / name
            b = p.read_bytes()
            (OUT / (label + ".before.gz")).write_bytes(gzip.compress(b, mtime=0))
            refs.append(
                {"relative": name, "Main": lc.artifact_ref(p), "companion_only": True}
            )
finally:
    os.sched_setaffinity(0, affinity)
(OUT / "source-intake.json").write_text(
    json.dumps(
        {
            "refs": refs,
            "reader_STOP": lc.stamp(),
            "owned_readers_writers_children_jobs_TMP_leases": [],
            "original_affinity": sorted(affinity),
            "restored_affinity": sorted(os.sched_getaffinity(0)),
            "storage_budget": None,
        },
        indent=2,
    )
    + "\n"
)
print("Selected source intake complete; reader lease released")
