"""One saved-only 415 extraction. No engine, model, rules replay or bootstrap."""

from collections import Counter, defaultdict
import csv
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import statistics
import stat
import struct
import time
import zlib

os.sched_setaffinity(0, {5})
assert os.sched_getaffinity(0) == {5}
OWN = Path(__file__).resolve().parent
GAUGES = {"tt_generation", "tt_retained_bytes", "TT_representation"}
WORK = (
    "nodes",
    "static_evaluations",
    "delta_updates",
    "cutoffs",
    "pvs_researches",
    "tt_probes",
    "tt_key_hits",
    "tt_exact_hits",
    "tt_usable_depth",
    "tt_bound_cutoffs",
    "tt_order_only",
    "tt_context_matches",
    "tt_context_misses",
    "tt_index_collisions",
)
LMR = ("attempts", "full_depth_confirmations", "full_window_researches")
selected_refs = []


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def ref(path):
    path = Path(path)
    content = path.read_bytes()
    info = path.stat()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(content).hexdigest(),
        "bytes": len(content),
        "mode": format(info.st_mode & 0o777, "04o"),
    }


def pinned_document(expected, cap=512 * 1024):
    fd = os.open(expected["path"], os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        content = stream.read(cap + 1)
    actual = {
        "path": expected["path"],
        "sha256": hashlib.sha256(content).hexdigest(),
        "bytes": len(content),
        "mode": format(info.st_mode & 0o777, "04o"),
    }
    assert actual == expected and len(content) <= cap
    selected_refs.append(expected)
    return json.loads(content)


def measured(values):
    if not values:
        return {"n": 0}
    vals = sorted(values)
    return {
        "n": len(vals),
        "sum": math.fsum(vals),
        "mean": math.fsum(vals) / len(vals),
        "median": statistics.median(vals),
        "min": vals[0],
        "p95": vals[math.ceil(len(vals) * 0.95) - 1],
        "max": vals[-1],
    }


def bits(value):
    return None if value is None else struct.pack("<f", value).hex()


def board_bookkeeping(moves, ply):
    """Only saved ActionID bookkeeping; no legality/geometry/path computation."""
    pawns, stocks, walls = [4, 76], [10, 10], []
    for index, action in enumerate(moves[:ply]):
        assert type(action) is int and 0 <= action <= 208
        if action < 81:
            pawns[index % 2] = action
        else:
            stocks[index % 2] -= 1
            walls.append(action)
    assert min(stocks) >= 0
    return {
        "pawns_cell_ids": pawns,
        "pawns_xy": [[cell % 9, cell // 9] for cell in pawns],
        "stocks": stocks,
        "wall_action_ids": sorted(walls),
        "side_to_move": ply % 2,
        "total_ply": ply,
    }


def depth_band(depth):
    if depth is None:
        return "no_completed_snapshot"
    if depth <= 4:
        return "1..4"
    if depth <= 8:
        return "5..8"
    if depth <= 15:
        return "9..15"
    if depth <= 31:
        return "16..31"
    return "32..64"


class Aggregate:
    def __init__(self):
        self.counts = Counter()
        self.depths = Counter()
        self.stops = Counter()
        self.clocks = defaultdict(list)
        self.work = {"selected": Counter(), "terminal": Counter()}
        self.present = {"selected": Counter(), "terminal": Counter()}
        self.null = {"selected": Counter(), "terminal": Counter()}
        self.lmr = {"selected": Counter(), "terminal": Counter()}
        self.partial_nodes = []
        self.values = []

    def add(self, observation):
        self.counts["observations"] += 1
        self.counts["accepted"] += observation["accepted"]
        self.counts["fallback"] += observation["counters"].get("selection_reason") == (
            "legal_fallback_no_completed_iteration"
        )
        self.stops[observation["stop"]] += 1
        depth = observation["completed_depth"]
        if depth is not None:
            self.depths[depth] += 1
        value = observation["value_stm"]
        if value is not None:
            assert math.isfinite(value)
            self.values.append(value)
        counters = observation["counters"]
        for field in ("caller_seconds", "thinking_seconds"):
            value = observation.get(field)
            if value is not None:
                self.clocks[field].append(value)
        receipt = counters.get("authority_receipt_ns")
        if receipt is not None:
            self.clocks["receipt_slack_ms"].append(
                (observation["deadline_ns"] - receipt) / 1e6
            )
            self.clocks["receipt_to_terminal_ms"].append(
                (observation["returned_ns"] - receipt) / 1e6
            )
            self.counts["late_receipt"] += receipt >= observation["deadline_ns"]
        for view, data in (
            ("selected", observation.get("completed_iteration_counters")),
            ("terminal", counters.get("whole_search")),
        ):
            if isinstance(data, dict):
                self.counts[view + "_n"] += 1
                for name, value in data.items():
                    if name in GAUGES:
                        continue
                    if value is None:
                        self.null[view][name] += 1
                    elif type(value) is int:
                        self.work[view][name] += value
                        self.present[view][name] += 1
        for view, name in (
            ("selected", "lmr_work_completed"),
            ("terminal", "lmr_work_terminal"),
        ):
            if isinstance(counters.get(name), dict):
                self.lmr[view].update(counters[name])
        completed = observation.get("completed_iteration_counters")
        terminal = counters.get("whole_search")
        if isinstance(completed, dict) and isinstance(terminal, dict):
            self.partial_nodes.append(terminal["nodes"] - completed["nodes"])

    def output(self):
        vals = [depth for depth, count in self.depths.items() for _ in range(count)]
        return {
            "counts": dict(self.counts),
            "depth": {**measured(vals), "histogram": dict(sorted(self.depths.items()))},
            "stop": dict(self.stops),
            "clocks": {name: measured(vals) for name, vals in self.clocks.items()},
            "work": {name: dict(vals) for name, vals in self.work.items()},
            "present_n": {name: dict(vals) for name, vals in self.present.items()},
            "null_n": {name: dict(vals) for name, vals in self.null.items()},
            "lmr": {name: dict(vals) for name, vals in self.lmr.items()},
            "terminal_minus_selected_nodes": measured(self.partial_nodes),
            "snapshot_value_stm": measured(self.values),
        }


def compact(observation):
    counters = observation["counters"]
    receipt = counters.get("authority_receipt_ns")
    selected = observation.get("completed_iteration_counters")
    terminal = counters.get("whole_search")
    return {
        "ply": observation["ply"],
        "side": observation["side"],
        "engine_index": observation["engine_index"],
        "action": observation["action"],
        "completed_depth": observation["completed_depth"],
        "value_stm": observation["value_stm"],
        "value_f32_le_hex": bits(observation["value_stm"]),
        "pv": observation["pv"],
        "accepted": observation["accepted"],
        "stop": observation["stop"],
        "selection_reason": counters.get("selection_reason"),
        "caller_seconds": observation.get("caller_seconds"),
        "thinking_seconds": observation.get("thinking_seconds"),
        "receipt_slack_ms": (
            (observation["deadline_ns"] - receipt) / 1e6
            if receipt is not None
            else None
        ),
        "receipt_to_terminal_ms": (
            (observation["returned_ns"] - receipt) / 1e6
            if receipt is not None
            else None
        ),
        "selected_work": (
            {key: selected.get(key) for key in WORK}
            if isinstance(selected, dict)
            else None
        ),
        "terminal_work": (
            {key: terminal.get(key) for key in WORK}
            if isinstance(terminal, dict)
            else None
        ),
        "lmr_selected": counters.get("lmr_work_completed"),
        "lmr_terminal": counters.get("lmr_work_terminal"),
        "method": counters.get("requested_lmr_method"),
        "actual_method_id": counters.get("actual_lmr_method_id"),
        "AI_worker_core": counters.get("AI_worker_core"),
    }


def raw_rows(expected, raw_bytes, raw_sha, cap):
    """Hash before parse, then one bounded full decompression/parse stream."""
    fd = os.open(expected["path"], os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        digest = hashlib.sha256()
        while block := stream.read(65536):
            digest.update(block)
        assert stat.S_ISREG(before.st_mode)
        assert before.st_size == expected["bytes"]
        assert (before.st_mode & 0o777) == int(expected["mode"], 8)
        assert digest.hexdigest() == expected["sha256"]
        stream.seek(0)
        compressed, raw_hash = hashlib.sha256(), hashlib.sha256()
        decoder = zlib.decompressobj(31)
        pending = b""
        total = line_no = offset = 0
        while block := stream.read(65536):
            compressed.update(block)
            raw = decoder.decompress(block, raw_bytes - total + 1)
            assert not decoder.unused_data and not decoder.unconsumed_tail
            raw_hash.update(raw)
            total += len(raw)
            assert total <= raw_bytes
            pending += raw
            while b"\n" in pending:
                line, pending = pending.split(b"\n", 1)
                assert len(line) <= cap
                line_no += 1
                yield (
                    line_no,
                    offset,
                    hashlib.sha256(line + b"\n").hexdigest(),
                    json.loads(line),
                )
                offset += len(line) + 1
            assert len(pending) <= cap
        after = os.fstat(stream.fileno())
        assert decoder.eof and not pending and total == raw_bytes
        assert raw_hash.hexdigest() == raw_sha
        assert compressed.hexdigest() == expected["sha256"]
        assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        )


def write_json(name, data):
    (OWN / name).write_text(
        json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n"
    )


def write_csv(name, rows):
    fields = list(rows[0])
    with (OWN / name).open("w", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


started = time.monotonic()
intake = json.loads((OWN / "extraction-inputs.json").read_text())
metadata = json.loads((OWN / "raw-intake-metadata.json").read_text())
overview = json.loads((OWN / "overview.json").read_text())
selection = json.loads((OWN / "example-selection.json").read_text())
original_result_ref = metadata["original_result"]
expected_result = pinned_document(original_result_ref)
selected_examples = {
    (group["evaluator"], fid): group["group"]
    for group in selection["selected_groups"]
    for fid in group["existing_ID_first3"]
}
family_overview = {row["family_id"]: row for row in overview["families"]}
groups = defaultdict(Aggregate)
families = {}
games = []
pairs = []
examples = []
integrity = []
pair_pending_max = 0
for config, contrast in zip(intake["configs"], metadata["contrasts"], strict=True):
    batch = config["batch"]
    evaluator = config["engines"][0]["kind"]
    archive = contrast["files"]["completed.jsonl.gz"]
    pending_pairs = {}
    seen = set()
    for line_no, byte_offset, line_sha, row in raw_rows(
        archive,
        contrast["archive_raw_bytes"],
        contrast["archive_raw_sha256"],
        config["record_cap"],
    ):
        game = row["game"]
        assert game not in seen and 0 <= game < 196
        seen.add(game)
        opening = config["openings"][game // 2]
        fid = opening["reference"]["settings"]["family_id"]
        prefix = opening["prefix"]
        moves = row["moves"]
        assert moves[: len(prefix)] == prefix and len(moves) == row["plies"]
        assert len(row["observations"]) == len(moves) - len(prefix)
        assert row["started"] and row["status"] == "goal" and row["failure"] is None
        initial = board_bookkeeping(moves, len(prefix))
        root_parts = opening["reference"]["settings"]["root_key"].split("|")
        assert initial["stocks"] == [int(x) for x in root_parts[-1].split(",")]
        assert initial["pawns_xy"] == [
            [int(x) for x in root_parts[0].split(",")],
            [int(x) for x in root_parts[1].split(",")],
        ]
        assert initial["side_to_move"] == int(root_parts[2])
        family = families.setdefault(
            fid,
            {
                "family_id": fid,
                "prefix_len": len(prefix),
                "initial_stocks": initial["stocks"],
                "initial_turn": initial["side_to_move"],
                "opening_root_key": opening["reference"]["settings"]["root_key"],
                "opening_history_counts": opening["reference"]["settings"][
                    "history_counts"
                ],
            },
        )
        assert (
            family["prefix_len"] == len(prefix)
            and family["initial_stocks"] == initial["stocks"]
        )
        category = family_overview[fid][evaluator]["class"]
        stock = [10, 10]
        obs_map = {}
        work_by_engine = [Counter(), Counter()]
        for ply, action in enumerate(moves):
            if ply >= len(prefix):
                observation = row["observations"][ply - len(prefix)]
                assert observation["ply"] == ply and observation["action"] == action
                assert observation["side"] == ply % 2
                index = observation["engine_index"]
                assert index == (
                    0 if observation["side"] == row["candidate_color"] else 1
                )
                method = config["engines"][index]["lmr_method"]
                assert observation["counters"]["requested_lmr_method"] == method
                obs_map[ply] = observation
                result = "win" if row["winner"] == observation["side"] else "loss"
                for dimension, value in (
                    ("all", "all"),
                    ("colour", observation["side"]),
                    ("stock_total", sum(stock)),
                    ("depth_band", depth_band(observation["completed_depth"])),
                    ("method_game_result", result),
                    ("pair_class", category),
                ):
                    groups[evaluator, method, dimension, str(value)].add(observation)
                terminal = observation["counters"].get("whole_search")
                if isinstance(terminal, dict):
                    work_by_engine[index].update(
                        {
                            key: terminal[key]
                            for key in WORK
                            if type(terminal.get(key)) is int
                        }
                    )
            if action >= 81:
                stock[ply % 2] -= 1
                assert stock[ply % 2] >= 0
        b_colour = 1 - row["candidate_color"]
        family[evaluator + "_B_score_colour" + str(b_colour)] = int(
            row["winner"] == b_colour
        )
        family[evaluator + "_played_plies_colour" + str(b_colour)] = len(
            row["observations"]
        )
        family[evaluator + "_total_plies_colour" + str(b_colour)] = row["plies"]
        game_row = {
            "evaluator": evaluator,
            "family_id": fid,
            "game": game,
            "archive_line": line_no,
            "A_colour": row["candidate_color"],
            "B_colour": b_colour,
            "winner": row["winner"],
            "B_win": int(row["winner"] == b_colour),
            "prefix_len": len(prefix),
            "initial_stock0": initial["stocks"][0],
            "initial_stock1": initial["stocks"][1],
            "played_plies": len(row["observations"]),
            "total_recorded_plies": row["plies"],
            "final_stock0": stock[0],
            "final_stock1": stock[1],
        }
        for index, method in enumerate(("A", "B")):
            for key in WORK:
                game_row[method + "_" + key] = work_by_engine[index][key]
        games.append(game_row)
        record_ref = {
            "archive": archive,
            "line": line_no,
            "uncompressed_byte_offset": byte_offset,
            "uncompressed_line_sha256": line_sha,
            "game": game,
        }
        key = game // 2
        if key not in pending_pairs:
            pending_pairs[key] = (row, obs_map, record_ref)
            pair_pending_max = max(pair_pending_max, len(pending_pairs))
            continue
        other, other_map, other_ref = pending_pairs.pop(key)
        assert {row["candidate_color"], other["candidate_color"]} == {0, 1}
        assert other["moves"][: len(prefix)] == prefix
        first = next(
            (
                idx
                for idx, (a, b) in enumerate(zip(row["moves"], other["moves"]))
                if a != b
            ),
            None,
        )
        pair = {
            "evaluator": evaluator,
            "family_id": fid,
            "prefix_len": len(prefix),
            "B_pair_score": family_overview[fid][evaluator]["B_score"],
            "pair_class": category,
            "first_archive_A_colour": other["candidate_color"],
            "first_difference_absolute_ply": first,
            "postopening_shared_actions": (
                first - len(prefix) if first is not None else len(moves) - len(prefix)
            ),
            "same_complete_saved_history_before_difference": True,
            "history_proof": "same bound opening fullhistory and same complete recorded action prefix",
        }
        if first is None:
            assert row["moves"] == other["moves"]
            pair["status"] = "identical_full_game"
            pair["side"] = None
            examples_data = None
        else:
            assert first >= len(prefix) and moves[:first] == other["moves"][:first]
            both = [
                (row, obs_map[first], record_ref),
                (other, other_map[first], other_ref),
            ]
            both.sort(key=lambda item: item[1]["engine_index"])
            a_row, a_obs, a_ref = both[0]
            b_row, b_obs, b_ref = both[1]
            assert a_obs["engine_index"] == 0 and b_obs["engine_index"] == 1
            assert a_obs["side"] == b_obs["side"]
            pair.update(
                status="first_difference",
                side=a_obs["side"],
                A_game=a_row["game"],
                B_game=b_row["game"],
                A_action=a_obs["action"],
                B_action=b_obs["action"],
                A_depth=a_obs["completed_depth"],
                B_depth=b_obs["completed_depth"],
                A_value=a_obs["value_stm"],
                B_value=b_obs["value_stm"],
                A_value_bits=bits(a_obs["value_stm"]),
                B_value_bits=bits(b_obs["value_stm"]),
                A_stop=a_obs["stop"],
                B_stop=b_obs["stop"],
                A_caller_seconds=a_obs["caller_seconds"],
                B_caller_seconds=b_obs["caller_seconds"],
                A_terminal_nodes=a_obs["counters"]["whole_search"]["nodes"],
                B_terminal_nodes=b_obs["counters"]["whole_search"]["nodes"],
                A_terminal_lmr=a_obs["counters"].get("lmr_work_terminal"),
                B_terminal_lmr=b_obs["counters"].get("lmr_work_terminal"),
            )
            examples_data = {
                "evaluator": evaluator,
                "family_id": fid,
                "selection_group": selected_examples.get((evaluator, fid)),
                "absolute_ply": first,
                "postopening_shared_actions": first - len(prefix),
                "side": a_obs["side"],
                "opening_root_key": family["opening_root_key"],
                "opening_history_counts": family["opening_history_counts"],
                "opening_prefix": prefix,
                "shared_played_actions_after_opening": moves[len(prefix) : first],
                "full_history_action_prefix_sha256": hashlib.sha256(
                    json.dumps(moves[:first], separators=(",", ":")).encode()
                ).hexdigest(),
                "history_join": pair["history_proof"],
                "board_from_saved_actions": board_bookkeeping(moves, first),
                "A": {
                    "raw": a_ref,
                    "decision": compact(a_obs),
                    "actual_next_actions": a_row["moves"][first : first + 8],
                    "actual_goal_winner": a_row["winner"],
                    "actual_actor_won": a_row["winner"] == a_obs["side"],
                    "final_ply": a_row["plies"],
                },
                "B": {
                    "raw": b_ref,
                    "decision": compact(b_obs),
                    "actual_next_actions": b_row["moves"][first : first + 8],
                    "actual_goal_winner": b_row["winner"],
                    "actual_actor_won": b_row["winner"] == b_obs["side"],
                    "final_ply": b_row["plies"],
                },
                "internal_TT_killer_history_clock_equality": "UNKNOWN",
                "action_quality_oracle": "UNKNOWN",
                "branch_rank_actual_q_static_value": "NOT_RECORDED",
            }
        if (evaluator, fid) in selected_examples:
            examples.append(
                examples_data
                or {
                    "evaluator": evaluator,
                    "family_id": fid,
                    "selection_group": selected_examples[evaluator, fid],
                    "status": "no_divergence; not replaced",
                }
            )
        pairs.append(pair)
        family[evaluator + "_first_difference_ply"] = first
        family[evaluator + "_postopening_shared_actions"] = pair[
            "postopening_shared_actions"
        ]
    assert seen == set(range(196)) and not pending_pairs
    integrity.append(
        {
            "archive": archive,
            "raw_bytes": contrast["archive_raw_bytes"],
            "raw_sha256": contrast["archive_raw_sha256"],
            "rows": len(seen),
            "compressed_before_parse_and_stream_hash": "MATCH",
            "raw_stream_hash": "MATCH",
            "full_decompression_passes_this_extraction": 1,
        }
    )
    selected_refs.append(archive)
del row, other, obs_map, other_map, a_row, b_row, a_obs, b_obs, both
reader_stop = utc()
assert (
    len(pairs) == 196
    and len(games) == 392
    and len(families) == 98
    and len(examples) == 12
)
assert sum(len(x["prefix"]) for x in intake["configs"][0]["openings"]) == 992
all_n = sum(
    accumulator.counts["observations"]
    for key, accumulator in groups.items()
    if key[2] == "all"
)
all_completed = sum(
    sum(accumulator.depths.values())
    for key, accumulator in groups.items()
    if key[2] == "all"
)
assert all_n == expected_result["observation_census"]["accepted"] == 20285
assert (
    all_completed
    == expected_result["observation_census"]["selected_counters_n"]
    == 20284
)
comparisons = {}
for evaluator in ("nnue", "distance"):
    rows = [row for row in pairs if row["evaluator"] == evaluator]
    comparable = [row for row in rows if row["status"] == "first_difference"]
    comparisons[evaluator] = {
        "pairs": len(rows),
        "first_difference": len(comparable),
        "identical_full_game": len(rows) - len(comparable),
        "postopening_shared_actions": measured(
            [row["postopening_shared_actions"] for row in rows]
        ),
        "difference_at_first_searched_move": sum(
            row["postopening_shared_actions"] == 0 for row in comparable
        ),
        "B_deeper": sum(
            row["B_depth"] is not None
            and row["A_depth"] is not None
            and row["B_depth"] > row["A_depth"]
            for row in comparable
        ),
        "same_completed_depth": sum(
            row["B_depth"] == row["A_depth"] for row in comparable
        ),
        "B_shallower": sum(
            row["B_depth"] is not None
            and row["A_depth"] is not None
            and row["B_depth"] < row["A_depth"]
            for row in comparable
        ),
        "missing_depth": sum(
            row["A_depth"] is None or row["B_depth"] is None for row in comparable
        ),
        "same_value_bits": sum(
            row["A_value_bits"] == row["B_value_bits"] for row in comparable
        ),
    }
group_output = [
    {
        "evaluator": key[0],
        "method": key[1],
        "dimension": key[2],
        "stratum": key[3],
        **accumulator.output(),
    }
    for key, accumulator in sorted(groups.items())
]
write_json("group-summaries.json", group_output)
write_json(
    "first-divergences.json",
    sorted(pairs, key=lambda row: (row["evaluator"], row["family_id"])),
)
write_json(
    "examples.json",
    sorted(examples, key=lambda row: (row["evaluator"], row["family_id"])),
)
family_rows = []
for fid, data in sorted(families.items()):
    item = {
        "family_id": fid,
        "prefix_len": data["prefix_len"],
        "initial_turn": data["initial_turn"],
        "initial_stock0": data["initial_stocks"][0],
        "initial_stock1": data["initial_stocks"][1],
    }
    item.update(
        {
            key: value
            for key, value in data.items()
            if key.startswith(("nnue_", "distance_"))
        }
    )
    family_rows.append(item)
write_csv("family-table.csv", family_rows)
write_csv(
    "game-table.csv", sorted(games, key=lambda row: (row["evaluator"], row["game"]))
)
write_json(
    "extraction-result.json",
    {
        "issue": "quoridor-4lc.415.1",
        "scope": "one new saved-only extraction, not original412 acceptance re-audit",
        "census": {
            "games": 392,
            "pairs": 196,
            "shared_families": 98,
            "accepted": all_n,
            "completed_snapshots": all_completed,
            "fallback": all_n - all_completed,
        },
        "comparisons": comparisons,
        "integrity": integrity,
        "fixed_example_selection": ref(OWN / "example-selection.json"),
        "examples": len(examples),
        "prefix_length_histogram": dict(
            Counter(data["prefix_len"] for data in families.values())
        ),
        "initial_stock_histogram": dict(
            Counter(sum(data["initial_stocks"]) for data in families.values())
        ),
        "selected_refs": selected_refs,
        "actual_RAW_reader_STOP": reader_stop,
        "RAW_in_memory_after_STOP": "large original row/observation maps released before readerSTOP; only compact aggregates/examples retained",
        "pair_pending_max": pair_pending_max,
        "new_Search_model_solver_bootstrap_game": 0,
        "wall_seconds": time.monotonic() - started,
        "self_ru_maxrss_B": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        "unknown": [
            "internal state equality",
            "branch ranks/q/static evaluations",
            "single-step oracle",
            "causal strength or isolated costs",
            "physical NN and continuous family RSS",
        ],
        "owned_TMP_leases": [],
    },
)
print(
    json.dumps(
        {
            "comparisons": comparisons,
            "RAW_reader_STOP": reader_stop,
            "games": len(games),
            "pairs": len(pairs),
            "examples": len(examples),
            "group_summaries": len(group_output),
            "wall_seconds": time.monotonic() - started,
            "owned_TMP_leases": [],
        }
    )
)
