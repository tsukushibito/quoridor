import os
from pathlib import Path
import subprocess

os.sched_setaffinity(0, {5})
own = Path(__file__).resolve().parent
ruff = Path("/home/vscode/.cache/inference/envs/quoridor-training/bin/ruff")
assert ruff.is_file(), "existing project Ruff missing"
for args in (
    [
        "format",
        "--no-cache",
        str(own / "extract415.py"),
        str(own / "guard.py"),
        str(own / "format415.py"),
    ],
    [
        "check",
        "--no-cache",
        str(own / "extract415.py"),
        str(own / "guard.py"),
        str(own / "format415.py"),
    ],
    [
        "format",
        "--check",
        "--no-cache",
        str(own / "extract415.py"),
        str(own / "guard.py"),
        str(own / "format415.py"),
    ],
):
    result = subprocess.run(
        [str(ruff), *args], capture_output=True, text=True, timeout=20
    )
    print(result.stdout, result.stderr, end="")
    assert result.returncode == 0, args
