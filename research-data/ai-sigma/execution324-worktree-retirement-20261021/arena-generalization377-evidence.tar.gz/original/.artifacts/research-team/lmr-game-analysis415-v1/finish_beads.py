"""Verify and close only the owned 415.1 issue using the maintained wrapper."""

from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

os.sched_setaffinity(0, {5})
OWN = Path(__file__).resolve().parent
ISSUE = "quoridor-4lc.415.1"
OWNER = "codex:01a118a1-aef1-7252-b21b-42f07dd5b1e6"
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
os.environ.update(GOMAXPROCS="1", GOMEMLIMIT="128MiB", BEADS_ACTOR=OWNER)


def identity(pid):
    try:
        return {
            "pid": pid,
            "start_ticks": Path(f"/proc/{pid}/stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19],
            "boot_id": BOOT,
        }
    except FileNotFoundError:
        return None


def run(label, args):
    process = subprocess.Popen(
        ["bash", "scripts/dev/beads.sh", *args],
        cwd="/workspaces/quoridor",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    old = identity(process.pid)
    stdout, stderr = process.communicate()
    (OWN / f"{label}.stdout.log").write_bytes(stdout)
    (OWN / f"{label}.stderr.log").write_bytes(stderr)
    receipt = {
        "operation": args[:2],
        "child_identity": old,
        "returncode": process.returncode,
        "directwait_reaped": True,
        "handles_closed": process.stdout.closed and process.stderr.closed,
        "fresh_identity": identity(process.pid),
        "completed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    (OWN / f"{label}-admin-receipt.json").write_text(
        json.dumps(receipt, indent=2) + "\n"
    )
    assert process.returncode == 0, (label, stderr.decode())
    assert old is None or identity(process.pid) != old
    return stdout


control = json.loads((OWN / "control.json").read_bytes())
verification = json.loads((OWN / "verification.json").read_bytes())
assert (
    control["analysis_complete"]
    and not control["strong_causal_or_general_strength_claims_confirmed"]
)
assert verification["saved_analysis_consistency"] == "PASS"
for name in (
    "ruff-own-final-v2-receipt.json",
    "ruff-format-own-final-receipt.json",
    "prettier-check-final-receipt.json",
):
    assert json.loads((OWN / name).read_bytes())["returncode"] == 0
report_sha = hashlib.sha256((OWN / "report-ja.md").read_bytes()).hexdigest()
before = json.loads(run("beads-before-close", ["show", ISSUE, "--json"]))[0]
assert before["id"] == ISSUE and before["assignee"] == OWNER
assert before["status"] in ("in_progress", "closed")
if before["status"] == "in_progress":
    note = f"415 saved analysis verified complete at gpt-6.1-sol/max/fullnever. One original392 RAW stream eachgzip once; RAWSTOP10:51:23.370580Z/reap10:51:23.479383Z, compactSTOP11:21:46.693394Z/reap.698934Z, owned[]. All98families/196firstdivergences/12fixedexamples, 137view partitions and fallback1 retained. Report {OWN / 'report-ja.md'} SHA256 {report_sha}; exactrefs/verification/STOP sameOWN. No new causal/strength grant, Search/game/bootstrap/model/native0; old412 acceptance unchanged. Main/findings/parent415 remain current324; all pauses/defaults/models/seals/originalFAILEDfeesUNKNOWN preserved. Final own close/backup evidence follows in completion.json."
    run(
        "beads-final-update",
        [
            "update",
            ISSUE,
            "--if-assignee",
            OWNER,
            "--if-status",
            "in_progress",
            "--append-notes",
            note,
            "--json",
        ],
    )
    run(
        "beads-own-close",
        [
            "close",
            ISSUE,
            "--reason",
            f"Verified saved-only392 analysis, fixed12 examples, formatted/linted and stopped; {OWN / 'report-ja.md'}; no new science or causal grant.",
            "--json",
        ],
    )
after = json.loads(run("beads-after-close", ["show", ISSUE, "--json"]))[0]
assert after["status"] == "closed" and after["assignee"] == OWNER
assert hashlib.sha256((OWN / "report-ja.md").read_bytes()).hexdigest() == report_sha
run("beads-final-backup", ["backup", "sync"])
out = {
    "issue": ISSUE,
    "status_before": before["status"],
    "status_after": after["status"],
    "assignee_unchanged": after["assignee"] == before["assignee"],
    "backup_sync_exit0": True,
    "report_sha256": report_sha,
    "parent415_modified": False,
    "other_review_issues_modified": False,
    "owned": [],
    "completed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(OWN / "closure.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out))
