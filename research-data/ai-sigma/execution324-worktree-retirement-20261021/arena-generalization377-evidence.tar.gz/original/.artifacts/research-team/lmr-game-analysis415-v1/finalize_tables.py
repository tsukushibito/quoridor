"""Verify and present compact 415 extracts without reopening any RAW payload."""

from collections import Counter
from pathlib import Path
import csv
import datetime
import hashlib
import io
import json
import math
import os
import stat
import statistics
import struct

os.sched_setaffinity(0, {5})
assert os.sched_getaffinity(0) == {5}
OWN = Path(__file__).resolve().parent
refs = []


def read(name):
    p = OWN / name
    s = p.stat()
    assert s.st_size < 1500000
    b = p.read_bytes()
    refs.append(
        {
            "path": str(p),
            "sha256": hashlib.sha256(b).hexdigest(),
            "bytes": len(b),
            "mode": f"{stat.S_IMODE(s.st_mode):04o}",
            "inode": s.st_ino,
            "mtime_ns": s.st_mtime_ns,
        }
    )
    if name.endswith(".csv"):
        return list(csv.DictReader(io.StringIO(b.decode())))
    return json.loads(b)


extraction = read("extraction-result.json")
tables = read("analysis-tables.json")
families = read("family-table.csv")
games = read("game-table.csv")
divergences = read("first-divergences.json")
examples = read("examples.json")
groups = read("group-summaries.json")
selection = read("example-selection.json")
inputs = read("extraction-inputs.json")
assert extraction["census"] == {
    "games": 392,
    "pairs": 196,
    "shared_families": 98,
    "accepted": 20285,
    "completed_snapshots": 20284,
    "fallback": 1,
}
assert len(families) == 98 and len(games) == 392 and len(divergences) == 196
assert len({int(f["family_id"]) for f in families}) == 98
assert all(int(f["initial_turn"]) == 0 for f in families)
assert Counter(int(f["prefix_len"]) for f in families) == {4: 22, 8: 26, 12: 26, 16: 24}
by_family = {int(f["family_id"]): f for f in families}
all_groups = {
    (g["evaluator"], g["method"]): g for g in groups if g["dimension"] == "all"
}
assert len(all_groups) == 4
checks = ["392 game rows, 196 comparisons, 98 shared starts and input strata"]

for (evaluator, method), all_group in all_groups.items():
    n = all_group["counts"]["observations"]
    assert all_group["counts"]["accepted"] == n
    assert all_group["counts"]["late_receipt"] == 0
    h = {int(k): v for k, v in all_group["depth"]["histogram"].items()}
    expanded = sorted(d for d, count in h.items() for _ in range(count))
    assert all_group["depth"]["n"] == all_group["counts"]["selected_n"] == len(expanded)
    assert statistics.median(expanded) == all_group["depth"]["median"]
    assert math.isclose(
        statistics.mean(expanded), all_group["depth"]["mean"], rel_tol=1e-12
    )
    assert all_group["depth"]["p95"] == expanded[math.ceil(0.95 * len(expanded)) - 1]
    same_method = [
        g for g in groups if (g["evaluator"], g["method"]) == (evaluator, method)
    ]
    for dimension in {g["dimension"] for g in same_method} - {"all"}:
        partition = [g for g in same_method if g["dimension"] == dimension]
        for field in all_group["counts"]:
            assert (
                sum(g["counts"].get(field, 0) for g in partition)
                == all_group["counts"][field]
            ), (evaluator, method, dimension, field)
        combined = Counter()
        for g in partition:
            combined.update(g["depth"]["histogram"])
        assert dict(combined) == all_group["depth"]["histogram"]
        for view in ("selected", "terminal"):
            for field, total in all_group["work"][view].items():
                assert sum(g["work"][view].get(field, 0) for g in partition) == total
            for field, total in all_group["lmr"][view].items():
                assert sum(g["lmr"][view].get(field, 0) for g in partition) == total
    method_games = [g for g in games if g["evaluator"] == evaluator]
    column = "A" if method == "fixed_one" else "B"
    assert len(method_games) == 196
    assert (
        sum(int(g[f"{column}_nodes"]) for g in method_games)
        == all_group["work"]["terminal"]["nodes"]
    )
    for field in [
        "static_evaluations",
        "delta_updates",
        "pvs_researches",
        "tt_probes",
        "tt_key_hits",
        "tt_context_matches",
        "tt_context_misses",
        "tt_index_collisions",
    ]:
        assert (
            sum(int(g[f"{column}_{field}"]) for g in method_games)
            == all_group["work"]["terminal"][field]
        )
    workrow = next(
        x
        for x in tables["work_table"]
        if (x["evaluator"], x["method"]) == (evaluator, method)
    )
    assert workrow["observations"] == n
    assert workrow["terminal_nodes"] == all_group["work"]["terminal"]["nodes"]
    assert workrow["selected_nodes"] == all_group["work"]["selected"]["nodes"]
    assert workrow["LMR_trials"] == all_group["lmr"]["terminal"]["attempts"]
    assert (
        workrow["normal_depth_confirmations"]
        == all_group["lmr"]["terminal"]["full_depth_confirmations"]
    )
    assert (
        workrow["LMR_fullwindow"]
        == all_group["lmr"]["terminal"]["full_window_researches"]
    )
    assert (
        workrow["partial_work_comparable_calls"]
        == all_group["terminal_minus_selected_nodes"]["n"]
    )
assert sum(g["counts"]["observations"] for g in all_groups.values()) == 20285
assert sum(g["depth"]["n"] for g in all_groups.values()) == 20284
assert sum(g["counts"]["fallback"] for g in all_groups.values()) == 1
checks.append(
    "137 aggregate views partition to method totals; depth histograms, per-game terminal work, completed/fallback denominators"
)

pair_classes = {}
played_plies = {}
for evaluator, expected_wins in [("nnue", 106), ("distance", 99)]:
    selected_games = [g for g in games if g["evaluator"] == evaluator]
    assert len({int(g["game"]) for g in selected_games}) == 196
    assert sum(int(g["B_win"]) for g in selected_games) == expected_wins
    classes = Counter()
    for family, familyrow in by_family.items():
        pair = [g for g in selected_games if int(g["family_id"]) == family]
        assert len(pair) == 2
        assert sorted(int(g["B_colour"]) for g in pair) == [0, 1]
        score_sum = sum(int(g["B_win"]) for g in pair)
        classes[{0: "B_both_lose", 1: "split", 2: "B_both_win"}[score_sum]] += 1
        for g in pair:
            colour = int(g["B_colour"])
            assert int(g["B_win"]) == int(
                familyrow[f"{evaluator}_B_score_colour{colour}"]
            )
            assert int(g["played_plies"]) == int(
                familyrow[f"{evaluator}_played_plies_colour{colour}"]
            )
            assert int(g["total_recorded_plies"]) == int(g["played_plies"]) + int(
                g["prefix_len"]
            )
    pair_classes[evaluator] = dict(classes)
    played_plies[evaluator] = sum(int(g["played_plies"]) for g in selected_games)
    ds = [d for d in divergences if d["evaluator"] == evaluator]
    assert len(ds) == 98 and all(d["status"] == "first_difference" for d in ds)
    assert all(
        d["same_complete_saved_history_before_difference"]
        and d["A_action"] != d["B_action"]
        for d in ds
    )
    assert all(
        d["first_difference_absolute_ply"]
        == d["prefix_len"] + d["postopening_shared_actions"]
        for d in ds
    )
    comparison = extraction["comparisons"][evaluator]
    assert (
        sum(d["postopening_shared_actions"] == 0 for d in ds)
        == comparison["difference_at_first_searched_move"]
    )
    complete = [d for d in ds if d["A_depth"] is not None and d["B_depth"] is not None]
    assert (
        sum(d["A_value_bits"] == d["B_value_bits"] for d in complete)
        == comparison["same_value_bits"]
    )
    assert sum(d["B_depth"] > d["A_depth"] for d in complete) == comparison["B_deeper"]
    assert (
        sum(d["B_depth"] == d["A_depth"] for d in complete)
        == comparison["same_completed_depth"]
    )
    assert (
        sum(d["B_depth"] < d["A_depth"] for d in complete) == comparison["B_shallower"]
    )
    for condition in ("prefix_len", "initial_stock_total"):
        condition_rows = [
            r for r in tables["opening_conditions"] if r["condition"] == condition
        ]
        assert sum(r["families"] for r in condition_rows) == 98
        assert sum(r[f"{evaluator}_games"] for r in condition_rows) == 196
        assert sum(r[f"{evaluator}_B_W"] for r in condition_rows) == expected_wins
    colour_rows = [r for r in tables["colour_table"] if r["evaluator"] == evaluator]
    assert len(colour_rows) == 4 and all(r["games"] == 98 for r in colour_rows)
    assert (
        sum(r["W"] for r in colour_rows if r["method"] == "depth_rank") == expected_wins
    )
checks.append(
    "98-family scores, colour/stock/prefix partitions and all196 first-divergence joins"
)

assert len(examples) == 12 and selection["selected_before_RAW"] is True
expected_examples = set()
for selected in selection["selected_groups"]:
    evaluator = selected["evaluator"]
    matching = sorted(
        family
        for family, f in by_family.items()
        if (
            int(f[f"{evaluator}_B_score_colour0"])
            + int(f[f"{evaluator}_B_score_colour1"])
        )
        / 2
        == selected["B_pair_score"]
    )
    assert selected["existing_ID_first3"] == matching[:3]
    expected_examples.update(
        (evaluator, selected["group"], family) for family in matching[:3]
    )
assert {
    (e["evaluator"], e["selection_group"], e["family_id"]) for e in examples
} == expected_examples
assert all(len(e["opening_prefix"]) == 4 for e in examples)
fallback_examples = 0
for e in examples:
    d = next(
        d
        for d in divergences
        if (d["evaluator"], d["family_id"]) == (e["evaluator"], e["family_id"])
    )
    assert e["absolute_ply"] == d["first_difference_absolute_ply"]
    assert e["board_from_saved_actions"]["total_ply"] == e["absolute_ply"]
    assert e["board_from_saved_actions"]["side_to_move"] == e["side"]
    for side in ("A", "B"):
        branch = e[side]
        decision = branch["decision"]
        assert (
            decision["action"]
            == d[f"{side}_action"]
            == branch["actual_next_actions"][0]
        )
        assert decision["completed_depth"] == d[f"{side}_depth"]
        assert decision["ply"] == e["absolute_ply"] and decision["side"] == e["side"]
        assert branch["raw"]["game"] == d[f"{side}_game"]
        assert 1 <= branch["raw"]["line"] <= 196
        archive = next(
            x["archive"]
            for x in extraction["integrity"]
            if x["archive"]["path"] == branch["raw"]["archive"]["path"]
        )
        assert archive == branch["raw"]["archive"]
        if decision["value_stm"] is None:
            fallback_examples += 1
            assert decision["pv"] == [] and decision["completed_depth"] is None
        else:
            assert (
                struct.pack("<f", decision["value_stm"]).hex()
                == decision["value_f32_le_hex"]
            )
            assert decision["pv"][0] == decision["action"]
        assert branch["actual_actor_won"] == (branch["actual_goal_winner"] == e["side"])
assert fallback_examples == 1
checks.append(
    "12 fixed examples, no replacements; exact game/ply/RAW pointers, snapshot bits/PV and actual continuation joins"
)

for r in refs:
    p = Path(r["path"])
    s = p.stat()
    assert (s.st_ino, s.st_size, s.st_mtime_ns) == (
        r["inode"],
        r["bytes"],
        r["mtime_ns"],
    )
    assert hashlib.sha256(p.read_bytes()).hexdigest() == r["sha256"]
    r["before_after"] = "MATCH"
    del r["inode"], r["mtime_ns"]
reader_stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
verification = {
    "issue": "quoridor-4lc.415.1",
    "saved_analysis_consistency": "PASS",
    "checks": checks,
    "selected_compact_refs": refs,
    "actual_selected_compact_reader_STOP": reader_stop,
    "actual_RAW_reader_STOP": extraction["actual_RAW_reader_STOP"],
    "RAW_integrity_reused_without_new_payload_read": extraction["integrity"],
    "RAW_payload_reads_this_finalizer": 0,
    "new_native_Search_model_solver_bootstrap_games": 0,
    "owned_TMP_leases": [],
    "pair_classes": pair_classes,
    "played_plies_by_evaluator": played_plies,
}
(OWN / "verification.json").write_text(
    json.dumps(verification, ensure_ascii=False, indent=2) + "\n"
)


def code(v):
    return (
        "—"
        if v is None
        else f"`{json.dumps(v, ensure_ascii=False, separators=(',', ':'))}`"
    )


lines = [
    "# 固定12分岐：原参照と記録された判断",
    "",
    "A=fixed_one、B=depth_rank。同じ開始fullhistoryと全共有着手prefixを照合した最初の分岐。plyは0始まりの絶対ply、game/RAW行は元dataset内番号。ActionID/PVは元記録の整数。valueは手番視点の選択的推定でoracleではない。",
    "",
    "二色score=1/0の各群で既存ID順先頭3をRAW抽出前に固定した。12例とも分岐し、補充0。結果を使った説明用選択であり、全例prefix4に偏る。TT/killer/history/時計/先行探索状態の同一性、枝のrank/実q/静的値はUNKNOWNまたは未記録。",
    "",
]
for e in examples:
    label = "NNUE" if e["evaluator"] == "nnue" else "固定D"
    group = "B両勝ち" if e["selection_group"] == "B_favourable" else "B両負け"
    board = e["board_from_saved_actions"]
    lines += [
        f"## {label} family {e['family_id']}／{group}／ply {e['absolute_ply']}",
        "",
        f"共有局面：P0/P1座標={code(board['pawns_xy'])}、stocks={code(board['stocks'])}、配置wall ActionIDs={code(board['wall_action_ids'])}、手番P{e['side']}。共有着手={code(e['opening_prefix'] + e['shared_played_actions_after_opening'])}。fullhistory action prefix SHA256=`{e['full_history_action_prefix_sha256']}`。開始root_key/countsと全fieldは[examples.json](examples.json)の同familyを参照。",
        "",
        "| 方法 | action | 完成深さ | value STM／f32 LE bits | PV | terminal nodes／LMR trial-confirm-fullwindow／PVS |",
        "| --- | ---: | ---: | --- | --- | --- |",
    ]
    for side in ("A", "B"):
        branch = e[side]
        d = branch["decision"]
        lmr = d["lmr_terminal"]
        work = d["terminal_work"]
        lines.append(
            f"| {side} | {d['action']} | {code(d['completed_depth'])} | {code(d['value_stm'])} / {code(d['value_f32_le_hex'])} | {code(d['pv'])} | {work['nodes']} / {lmr['attempts']}-{lmr['full_depth_confirmations']}-{lmr['full_window_researches']} / {work['pvs_researches']} |"
        )
    lines.append("")
    for side in ("A", "B"):
        branch = e[side]
        d, raw = branch["decision"], branch["raw"]
        lines += [
            f"{side}: game {raw['game']}、stop=`{d['stop']}`、selection=`{d['selection_reason']}`、caller {d['caller_seconds'] * 1000:.3f}ms、receipt slack {d['receipt_slack_ms']:.3f}ms、receipt→terminal {d['receipt_to_terminal_ms']:.3f}ms。実続行先頭8={code(branch['actual_next_actions'])}、実goal勝者P{branch['actual_goal_winner']}、終局ply {branch['final_ply']}。",
            "",
            f"RAW: [{Path(raw['archive']['path']).parent.parent.name}/completed.jsonl.gz]({raw['archive']['path']}) 行{raw['line']}、非圧縮byte offset {raw['uncompressed_byte_offset']}、行SHA256=`{raw['uncompressed_line_sha256']}`。archive SHA256=`{raw['archive']['sha256']}`。",
            "",
        ]
    if any(e[s]["decision"]["completed_depth"] is None for s in ("A", "B")):
        lines += [
            "Aは完成snapshotなしの合法fallback。記録terminal nodes=0/trial=0を、物理Search/forwardが無かった証明やLMRの悪手原因へ変換しない。初回準備・制御・schedulingの原因は未分離。原勝敗・分母から除外しない。",
            "",
        ]
lines += [
    "各行のselected/terminal work、TT、全clock、完全開始履歴、直接RAW参照は[examples.json](examples.json)に保持。実勝者はその一手の正しさを証明せず、異PV/valueを単独LMR演算の効果へ帰属しない。",
    "",
]
(OWN / "examples-ja.md").write_text("\n".join(lines))

lines = [
    "# 全98系統：二色得点・条件・最初の分岐",
    "",
    "B0/B1はBがP0/P1を担当したゲームの勝点。drawなし。全開始手番P0。手数は開始prefixを除く実対局ply、分岐は絶対ply。共有系統をNNUE/固定Dで重複した独立標本へ数えない。",
    "",
    "| ID | prefix | 初在庫P0/P1 | NNUE B0/B1 | D B0/B1 | 初分岐 N/D | 実手数N B0/B1 | 実手数D B0/B1 |",
    "| ---: | ---: | --- | --- | --- | --- | --- | --- |",
]
for f in sorted(families, key=lambda f: int(f["family_id"])):
    lines.append(
        f"| {f['family_id']} | {f['prefix_len']} | {f['initial_stock0']}/{f['initial_stock1']} | {f['nnue_B_score_colour0']}/{f['nnue_B_score_colour1']} | {f['distance_B_score_colour0']}/{f['distance_B_score_colour1']} | {f['nnue_first_difference_ply']}/{f['distance_first_difference_ply']} | {f['nnue_played_plies_colour0']}/{f['nnue_played_plies_colour1']} | {f['distance_played_plies_colour0']}/{f['distance_played_plies_colour1']} |"
    )
lines += [
    "",
    "[family-table.csv](family-table.csv)は全column、[game-table.csv](game-table.csv)は全392局の対応game/RAW行/色/実在庫/仕事量、[first-divergences.json](first-divergences.json)は全196分岐を保持する。",
    "",
]
(OWN / "families-ja.md").write_text("\n".join(lines))
print(
    json.dumps(
        {
            "checks": checks,
            "compact_reader_STOP": reader_stop,
            "RAW_rereads": 0,
            "examples": len(examples),
            "families": len(families),
            "owned": [],
        },
        ensure_ascii=False,
    )
)
