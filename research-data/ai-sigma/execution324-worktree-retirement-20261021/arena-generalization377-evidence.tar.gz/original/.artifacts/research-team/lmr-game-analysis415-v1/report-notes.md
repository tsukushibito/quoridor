# 415 保存解析の草稿：summaryから分かる範囲

これは全392棋譜の詳細解析が完了した報告ではない。原412のCI・選択・完了判定は前提として保持する。2026-10-15の413384 timing調整時点で、本RAW全392stream抽出は真正未入場。1レコードのschema previewだけが完了しており、first divergence・在庫別workの結論はまだない。

既存98系統のB二色score分類は、NNUEで両勝ち31／片勝ち44／両負け23、fixedDで14／71／13。NNUEの16勝分の差は両勝ち対両負けの8系統差に対応し、fixedDの2勝差は1系統差に対応する。片勝ちはdrawではなく、一方の色が二局とも勝つ実結果であり、方式同等性を示さない。

Bの色0/色1勝数はNNUE 51/55（各98局）、fixedD 51/48（各98局）。先後を説明するときは、色と実開始rootの手番／prefix長を照合する。総記録plyは開始prefixを含むので、異なる開始条件の「探索後の手数」としてそのまま比較しない。実対局後の手数はobservations等との対応を本抽出で確認する。

NNUEとfixedDで同じpair分類なのは42系統（両勝ち5、片勝ち33、両負け4）。残り56系統は分類が違い、両勝ちと両負けが正反対なのは7系統。これは共有開始条件に対する異なる実結果の記述であり、evaluatorやLMR単独の因果証明ではない。

固定12枠はexample-selection.jsonにRAW本抽出前に保存した。NNUE有利1/2/5・不利8/12/20、fixedD有利1/5/7・不利3/20/21。該当pairで分岐がなければそのまま未該当とし、別IDで埋めない。二色scoreによる有利／不利は全対局結果のラベルであり、ある一手の正誤oracleではない。

同一局面の対応は、同じ保存初期盤面・完全履歴と同じ実着手prefix、同じ絶対ply／手番、記録されたroot decision境界を使う。内部TT・killer/history・先行探索・時計まで同一とはしない。snapshot value/PVは同じside-to-move視点で並べるが、後の勝者やNNUE値を真値へ昇格しない。

各手のselected completed snapshotとterminal whole_searchは内包する別viewで、加算しない。LMR trialの件数だけから実q量・対象順位・削減深さ・個々の失敗枝を復元できない。DepthRankのq0はtrialに入らないため、trial減少をそのまま選択性の弱さや計算節約へ読み替えない。TTの命中・履歴・深さ資格、同一手のPVS再探索も独立な局面数ではない。

position_traitsの保存は旧summaryで0件。実在庫は原初期在庫と保存済みwall着手からの帳簿上の導出が可能かを区別し、保存されていない幾何・静的評価・branch rankを作らない。モデル・Search・BFS・新game・bootstrapは実行しない。

ここまでの数値はoverview.jsonにある既存小summaryの記述的整理のみ。一般優越・非劣性・因果・製品/実generator昇格の新主張はない。全pause/defaults/models/seals/旧RAWFAILED費UNKNOWNを保持する。
