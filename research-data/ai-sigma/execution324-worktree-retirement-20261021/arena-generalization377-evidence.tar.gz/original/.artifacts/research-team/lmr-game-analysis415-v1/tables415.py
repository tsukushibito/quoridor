"""Compact descriptive tables from the completed 415 extraction only."""

from collections import Counter, defaultdict
import csv
import json
import os
from pathlib import Path
import statistics

os.sched_setaffinity(0, {5})
OWN = Path(__file__).resolve().parent


def doc(name):
    return json.loads((OWN / name).read_text())


def mean(values):
    return statistics.mean(values) if values else None


def quantile(values):
    return {
        "n": len(values),
        "mean": mean(values),
        "median": statistics.median(values) if values else None,
        "min": min(values) if values else None,
        "max": max(values) if values else None,
    }


def write_csv(name, rows):
    with (OWN / name).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


with (OWN / "family-table.csv").open() as stream:
    families = list(csv.DictReader(stream))
with (OWN / "game-table.csv").open() as stream:
    games = list(csv.DictReader(stream))
groups = doc("group-summaries.json")
pairs = doc("first-divergences.json")
examples = doc("examples.json")
conditions = []
for kind in ["prefix_len", "initial_stock_total"]:
    buckets = defaultdict(list)
    for family in families:
        value = (
            int(family["prefix_len"])
            if kind == "prefix_len"
            else int(family["initial_stock0"]) + int(family["initial_stock1"])
        )
        buckets[value].append(family)
    for value, rows in sorted(buckets.items()):
        item = {"condition": kind, "value": value, "families": len(rows)}
        for ev in ["nnue", "distance"]:
            scores = [
                int(row[ev + "_B_score_colour" + str(colour)])
                for row in rows
                for colour in [0, 1]
            ]
            item[ev + "_B_W"] = sum(scores)
            item[ev + "_B_L"] = len(scores) - sum(scores)
            item[ev + "_games"] = len(scores)
            item[ev + "_score"] = sum(scores) / len(scores)
            item[ev + "_B_both_win"] = sum(
                int(row[ev + "_B_score_colour0"]) + int(row[ev + "_B_score_colour1"])
                == 2
                for row in rows
            )
            item[ev + "_B_both_lose"] = sum(
                int(row[ev + "_B_score_colour0"]) + int(row[ev + "_B_score_colour1"])
                == 0
                for row in rows
            )
        conditions.append(item)

all_groups = {
    (row["evaluator"], row["method"]): row
    for row in groups
    if row["dimension"] == "all"
}
work_table = []
depth_table = []
colour_table = []
stock_table = []
for (ev, method), group in all_groups.items():
    work = group["work"]["terminal"]
    trial = group["lmr"]["terminal"]
    nodes = work["nodes"]
    work_table.append(
        {
            "evaluator": ev,
            "method": method,
            "observations": group["counts"]["observations"],
            "terminal_nodes": nodes,
            "terminal_evals": work["static_evaluations"],
            "selected_nodes": group["work"]["selected"]["nodes"],
            "terminal_minus_selected_nodes": group["terminal_minus_selected_nodes"][
                "sum"
            ],
            "partial_work_comparable_calls": group["terminal_minus_selected_nodes"][
                "n"
            ],
            "terminal_minus_selected_node_share": group[
                "terminal_minus_selected_nodes"
            ]["sum"]
            / nodes,
            "LMR_trials": trial["attempts"],
            "normal_depth_confirmations": trial["full_depth_confirmations"],
            "LMR_fullwindow": trial["full_window_researches"],
            "confirm_per_trial": trial["full_depth_confirmations"] / trial["attempts"],
            "trials_per_1000_nodes": 1000 * trial["attempts"] / nodes,
            "pvs_researches": work["pvs_researches"],
            "TT_probes": work["tt_probes"],
            "TT_key_hits": work["tt_key_hits"],
            "TT_numeric_cutoffs": work["tt_bound_cutoffs"],
            "TT_context_matches": work["tt_context_matches"],
            "TT_context_misses": work["tt_context_misses"],
            "caller_mean_ms": 1000 * group["clocks"]["caller_seconds"]["mean"],
            "thinking_field_mean_ms": 1000
            * group["clocks"]["thinking_seconds"]["mean"],
            "receipt_to_terminal_mean_ms": group["clocks"]["receipt_to_terminal_ms"][
                "mean"
            ],
        }
    )
    hist = {int(key): value for key, value in group["depth"]["histogram"].items()}
    depth_table.append(
        {
            "evaluator": ev,
            "method": method,
            "completed_n": group["depth"]["n"],
            "fallback_n": group["counts"]["fallback"],
            "depth_1_4": sum(value for key, value in hist.items() if key <= 4),
            "depth_5_15": sum(value for key, value in hist.items() if 5 <= key <= 15),
            "depth_16_31": sum(value for key, value in hist.items() if 16 <= key <= 31),
            "depth_32_64": sum(value for key, value in hist.items() if 32 <= key <= 64),
            "depth64": hist.get(64, 0),
            "mean": group["depth"]["mean"],
            "median": group["depth"]["median"],
            "p95": group["depth"]["p95"],
        }
    )
    for colour in [0, 1]:
        row = next(
            row
            for row in groups
            if (row["evaluator"], row["method"], row["dimension"], row["stratum"])
            == (ev, method, "colour", str(colour))
        )
        actual = [
            game
            for game in games
            if game["evaluator"] == ev
            and int(game["A_colour" if method == "fixed_one" else "B_colour"]) == colour
        ]
        wins = sum(int(game["winner"]) == colour for game in actual)
        colour_table.append(
            {
                "evaluator": ev,
                "method": method,
                "colour": colour,
                "games": len(actual),
                "W": wins,
                "L": len(actual) - wins,
                "observations": row["counts"]["observations"],
                "completed_n": row["depth"]["n"],
                "fallback": row["counts"]["fallback"],
                "depth_mean": row["depth"]["mean"],
                "depth_median": row["depth"]["median"],
                "depth_p95": row["depth"]["p95"],
                "played_plies_mean": mean(
                    [int(game["played_plies"]) for game in actual]
                ),
            }
        )
    for stock in ["zero", "positive"]:
        rows = [
            row
            for row in groups
            if (row["evaluator"], row["method"], row["dimension"])
            == (ev, method, "stock_total")
            and (int(row["stratum"]) == 0) == (stock == "zero")
        ]
        h = Counter()
        n = completed = fallback = 0
        node_sum = trial_sum = 0
        for row in rows:
            h.update(
                {int(key): value for key, value in row["depth"]["histogram"].items()}
            )
            n += row["counts"]["observations"]
            completed += row["depth"]["n"]
            fallback += row["counts"]["fallback"]
            node_sum += row["work"]["terminal"]["nodes"]
            trial_sum += row["lmr"]["terminal"]["attempts"]
        vals = [key for key, count in h.items() for _ in range(count)]
        stock_table.append(
            {
                "evaluator": ev,
                "method": method,
                "derived_current_root_stock": stock,
                "observations": n,
                "completed_n": completed,
                "fallback": fallback,
                "depth_median": statistics.median(vals) if vals else None,
                "depth_mean": mean(vals),
                "depth64": h[64],
                "terminal_nodes": node_sum,
                "LMR_trials": trial_sum,
            }
        )

matched = []
for ev in ["nnue", "distance"]:
    rows = [row for row in pairs if row["evaluator"] == ev]
    for category in ["B_both_win", "split", "B_both_lose"]:
        subset = [row for row in rows if row["pair_class"] == category]
        comparable = [
            row
            for row in subset
            if row["A_depth"] is not None and row["B_depth"] is not None
        ]
        matched.append(
            {
                "evaluator": ev,
                "pair_class": category,
                "pairs": len(subset),
                "both_completed": len(comparable),
                "B_deeper": sum(row["B_depth"] > row["A_depth"] for row in comparable),
                "same_depth": sum(
                    row["B_depth"] == row["A_depth"] for row in comparable
                ),
                "B_shallower": sum(
                    row["B_depth"] < row["A_depth"] for row in comparable
                ),
                "same_value_bits_when_both_completed": sum(
                    row["A_value_bits"] == row["B_value_bits"] for row in comparable
                ),
                "mean_postopening_common_actions": mean(
                    [row["postopening_shared_actions"] for row in subset]
                ),
            }
        )
case_rows = []
for case in examples:
    aa, bb = case["A"]["decision"], case["B"]["decision"]
    case_rows.append(
        {
            "evaluator": case["evaluator"],
            "family_id": case["family_id"],
            "group": case["selection_group"],
            "absolute_ply": case["absolute_ply"],
            "postopening_shared_actions": case["postopening_shared_actions"],
            "side": case["side"],
            "stocks": case["board_from_saved_actions"]["stocks"],
            "pawns_xy": case["board_from_saved_actions"]["pawns_xy"],
            "wall_action_ids": case["board_from_saved_actions"]["wall_action_ids"],
            "A_game": case["A"]["raw"]["game"],
            "B_game": case["B"]["raw"]["game"],
            "A_line": case["A"]["raw"]["line"],
            "B_line": case["B"]["raw"]["line"],
            "A_action": aa["action"],
            "B_action": bb["action"],
            "A_depth": aa["completed_depth"],
            "B_depth": bb["completed_depth"],
            "A_value": aa["value_stm"],
            "B_value": bb["value_stm"],
            "A_pv": aa["pv"],
            "B_pv": bb["pv"],
            "A_stop": aa["stop"],
            "B_stop": bb["stop"],
            "A_terminal_nodes": aa["terminal_work"]["nodes"],
            "B_terminal_nodes": bb["terminal_work"]["nodes"],
            "A_lmr": aa["lmr_terminal"],
            "B_lmr": bb["lmr_terminal"],
            "A_selected_lmr": aa["lmr_selected"],
            "B_selected_lmr": bb["lmr_selected"],
            "A_actual_next_actions": case["A"]["actual_next_actions"],
            "B_actual_next_actions": case["B"]["actual_next_actions"],
            "A_goal_winner": case["A"]["actual_goal_winner"],
            "B_goal_winner": case["B"]["actual_goal_winner"],
        }
    )
order = {
    ev: dict(
        Counter(
            row["first_archive_A_colour"] for row in pairs if row["evaluator"] == ev
        )
    )
    for ev in ["nnue", "distance"]
}
same_values = {
    ev: {
        "both_completed": sum(
            row["A_depth"] is not None and row["B_depth"] is not None
            for row in pairs
            if row["evaluator"] == ev
        ),
        "same_depth_n": sum(
            row["A_depth"] is not None and row["A_depth"] == row["B_depth"]
            for row in pairs
            if row["evaluator"] == ev
        ),
        "same_value_bits_at_same_depth": sum(
            row["A_depth"] is not None
            and row["A_depth"] == row["B_depth"]
            and row["A_value_bits"] == row["B_value_bits"]
            for row in pairs
            if row["evaluator"] == ev
        ),
    }
    for ev in ["nnue", "distance"]
}
data = {
    "opening_conditions": conditions,
    "work_table": work_table,
    "depth_table": depth_table,
    "colour_table": colour_table,
    "stock_table": stock_table,
    "first_difference_by_pair_class": matched,
    "same_value_at_same_depth": same_values,
    "fixed_example_table": case_rows,
    "first_in_archive_A_colour": order,
    "example_prefix_lengths": sorted({len(row["opening_prefix"]) for row in examples}),
    "all_initial_turns": sorted({int(row["initial_turn"]) for row in families}),
    "raw_extraction_replayed": False,
}
(OWN / "analysis-tables.json").write_text(
    json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n"
)
write_csv("condition-table.csv", conditions)
write_csv("colour-table.csv", colour_table)
write_csv("work-table.csv", work_table)
write_csv("depth-table.csv", depth_table)
print(
    json.dumps(
        {
            "opening_conditions": conditions,
            "depth_table": depth_table,
            "stock_table": stock_table,
            "matched": matched,
            "same_values": same_values,
            "example_prefix_lengths": data["example_prefix_lengths"],
            "all_initial_turns": data["all_initial_turns"],
            "first_archive_A_colour": order,
            "cases": [
                {
                    key: row[key]
                    for key in [
                        "evaluator",
                        "family_id",
                        "absolute_ply",
                        "A_action",
                        "B_action",
                        "A_depth",
                        "B_depth",
                        "A_value",
                        "B_value",
                        "A_pv",
                        "B_pv",
                        "A_terminal_nodes",
                        "B_terminal_nodes",
                        "A_stop",
                        "B_stop",
                    ]
                }
                for row in case_rows
            ],
        }
    )
)
