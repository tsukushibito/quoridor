import csv
import json
import os
from pathlib import Path

os.sched_setaffinity(0, {5})
own = Path(__file__).resolve().parent
result = json.loads((own / "extraction-result.json").read_text())
groups = json.loads((own / "group-summaries.json").read_text())
examples = json.loads((own / "examples.json").read_text())
pairs = json.loads((own / "first-divergences.json").read_text())
print(
    json.dumps(
        {
            "prefix_hist": result["prefix_length_histogram"],
            "initial_stock_hist": result["initial_stock_histogram"],
        }
    )
)
for row in groups:
    if row["dimension"] == "all":
        print(
            json.dumps(
                {
                    "method": row["evaluator"] + ":" + row["method"],
                    "counts": row["counts"],
                    "depth": row["depth"],
                    "terminal": row["work"]["terminal"],
                    "selected": row["work"]["selected"],
                    "lmr": row["lmr"],
                    "clock_means": {
                        key: value.get("mean") for key, value in row["clocks"].items()
                    },
                    "partial_nodes": row["terminal_minus_selected_nodes"],
                }
            )
        )
print(
    json.dumps(
        {
            "examples": [
                {
                    "evaluator": row["evaluator"],
                    "id": row["family_id"],
                    "group": row["selection_group"],
                    "ply": row["absolute_ply"],
                    "common": row["postopening_shared_actions"],
                    "board": row["board_from_saved_actions"],
                    "A": row["A"],
                    "B": row["B"],
                }
                for row in examples
            ]
        }
    )
)
print(
    json.dumps(
        {
            "missing_snapshot_at_divergence": [
                row for row in pairs if row["A_depth"] is None or row["B_depth"] is None
            ]
        }
    )
)
with (own / "game-table.csv").open() as stream:
    games = list(csv.DictReader(stream))
print(
    json.dumps(
        {
            "played_total_by_evaluator": {
                ev: sum(
                    int(row["played_plies"]) for row in games if row["evaluator"] == ev
                )
                for ev in ["nnue", "distance"]
            }
        }
    )
)
