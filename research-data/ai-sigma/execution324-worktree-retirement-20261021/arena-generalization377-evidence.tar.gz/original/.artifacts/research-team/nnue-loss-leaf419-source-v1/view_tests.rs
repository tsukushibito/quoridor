#[cfg(all(test, feature = "research"))]
mod residual_value419_tests {
    use super::*;
    use std::cell::Cell;

    fn toy(weights: Vec<f32>, distance_fit: DistanceFit) -> ResidualModel {
        ResidualModel::from_parts(
            Topology {
                ft_width: 1,
                hidden_width: 1,
            },
            weights,
            [0.25, 0.5],
            [0.125, 0.25],
            distance_fit,
            RouteMode::Zero4,
            [0.; 4],
            [1.; 4],
        )
        .unwrap()
    }

    fn weights() -> (Vec<f32>, usize, usize) {
        let t = Topology {
            ft_width: 1,
            hidden_width: 1,
        };
        let head = FEATURE_COUNT + 1;
        let output = head + t.input_width() + 4 + 1;
        (
            vec![0.; ResidualModel::parameter_count(t).unwrap()],
            head,
            output,
        )
    }

    #[test]
    fn residual419_view_normalized_distance_one_head_and_parent_unchanged() {
        let (mut w, head, output) = weights();
        w[head] = 0.25;
        w[head + 1] = 0.5;
        w[head + 2] = 2.;
        w[head + 3] = -1.;
        w[output] = 0.25;
        w[output + 1] = -0.25;
        let model = toy(w, DistanceFit { a: 0.125, b: 2. });
        let mut a = model.full(Position::default()).unwrap();
        a.values = [vec![2.], vec![-3.]];
        a.features.distance = [0.5, 0.75];
        a.features.side = 0;
        let parent_values = a.values.clone();
        let parent_distances = a.features.distance;
        let mut scratch = model.evaluation_scratch();
        let pointer = scratch.input.as_ptr();
        let capacity = scratch.input.capacity();
        let calls = Cell::new(0);
        let view = model
            .value_with_scratch_observed(&a, &mut scratch, |_, _| calls.set(calls.get() + 1))
            .unwrap();
        // Inputs [ReLU(2), ReLU(-3), (.5-.25)/.125, (.75-.5)/.25]
        // give hidden 3.5, residual .625, distance logit .625, total 1.25.
        assert_eq!(view.pre_tanh.to_bits(), 1.25_f32.to_bits());
        assert_eq!(view.post_tanh.to_bits(), (1.25_f64.tanh() as f32).to_bits());
        assert_eq!(calls.get(), 1);
        assert_eq!(scratch.input[2..4], [2., 1.]);
        assert!(scratch.input[4..].iter().all(|v| v.to_bits() == 0));
        assert_eq!(pointer, scratch.input.as_ptr());
        assert_eq!(capacity, scratch.input.capacity());
        assert_eq!(a.values, parent_values);
        assert_eq!(a.features.distance, parent_distances);
        assert_eq!(a.features.side, 0);
        assert_eq!(
            model
                .evaluate_with_scratch(&a, &mut scratch)
                .unwrap()
                .to_bits(),
            view.post_tanh.to_bits()
        );
        let public_view = model.evaluate_view_with_scratch(&a, &mut scratch).unwrap();
        assert_eq!(public_view.pre_tanh.to_bits(), view.pre_tanh.to_bits());
        assert_eq!(public_view.post_tanh.to_bits(), view.post_tanh.to_bits());
    }

    #[test]
    fn residual419_view_retains_finite_saturated_logit_and_output_bits() {
        for (logit, expected_post) in [(-100., -1.), (0., 0.), (100., 1.)] {
            let (mut w, _, output) = weights();
            w[output + 1] = logit;
            let model = toy(w, DistanceFit { a: 0., b: 0. });
            let a = model.full(Position::default()).unwrap();
            let mut scratch = model.evaluation_scratch();
            let view = model.evaluate_view_with_scratch(&a, &mut scratch).unwrap();
            assert_eq!(view.pre_tanh.to_bits(), logit.to_bits());
            assert_eq!(view.post_tanh.to_bits(), (expected_post as f32).to_bits());
            assert_eq!(
                model.evaluate(&a).unwrap().to_bits(),
                view.post_tanh.to_bits()
            );
        }
    }

    #[test]
    fn residual419_view_preserves_validation_and_nonfinite_logit_refusal() {
        let (w, _, _) = weights();
        let model = toy(w, DistanceFit { a: 0., b: 0. });
        let a = model.full(Position::default()).unwrap();
        let mut scratch = model.evaluation_scratch();
        let calls = Cell::new(0);
        let mut bad = ResidualScratch { input: vec![] };
        assert!(matches!(
            model.value_with_scratch_observed(&a, &mut bad, |_, _| calls.set(calls.get() + 1)),
            Err(Error::Input(_))
        ));
        let mut invalid = a.clone();
        invalid.features.distance[0] = f32::NAN;
        assert!(
            model
                .value_with_scratch_observed(&invalid, &mut scratch, |_, _| calls
                    .set(calls.get() + 1))
                .is_err()
        );
        assert_eq!(calls.get(), 0);
        let (mut w, _, output) = weights();
        w[output + 1] = f32::MAX;
        let overflowing = toy(w, DistanceFit { a: f32::MAX, b: 0. });
        let a = overflowing.full(Position::default()).unwrap();
        let mut scratch = overflowing.evaluation_scratch();
        assert!(matches!(
            overflowing.value_with_scratch_observed(&a, &mut scratch, |_, _| calls.set(calls.get() + 1)),
            Err(Error::Numeric(message)) if message == "residual logit"
        ));
        assert_eq!(calls.get(), 1);
        assert!(matches!(
            overflowing.evaluate_with_scratch(&a, &mut scratch),
            Err(Error::Numeric(message)) if message == "residual logit"
        ));
    }
}
