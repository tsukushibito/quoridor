"""Read only the canonical residual owner and its existing toy fixture inlet."""

import json
import re

from intake import HERE, git
from read_owners import body

base = json.loads((HERE / "intake-refs.json").read_text())["base_Git"]
text = git("show", base + ":crates/quoridor-nnue/src/residual.rs").decode()
print("HEADER", "\n".join(text.splitlines()[:120]))
print("FIXTURE_NAMES", re.findall(r"fn (\w+)\(", text))
start = text.find("#[cfg(test)]")
print("TEST_INLET", text[start : start + 8500])
for name in ("from_parts", "evaluationscratch", "full"):
    match = re.search(r"(?m)^    pub fn " + name + r"\b", text)
    if match:
        print("OWNER", body(text, match.start()))
