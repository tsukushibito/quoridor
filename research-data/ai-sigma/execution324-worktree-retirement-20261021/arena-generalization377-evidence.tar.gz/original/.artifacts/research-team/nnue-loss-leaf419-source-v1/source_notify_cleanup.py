"""Close the one actual notification's private zero-byte, verified-unheld uv lock."""

from datetime import datetime, timezone
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import stat

from intake import HERE, ROOT, ref

loader = importlib.util.spec_from_file_location(
    "lc419_notify_cleanup", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
source = HERE / "source-notify-v1/result.json"
original = ref(source)
data = json.loads(source.read_text())
assert data["status"] == "PASS"
fresh = []
for identity in [data["controller"]]:
    current = lc.process.identity(lc.process.process_info(identity["pid"]))
    assert current is None or current != identity
    fresh.append({"original": identity, "fresh": current})
receipts = []
for check in data["checks"]:
    disk = json.loads(Path(check["persisted_process_receipt"]["path"]).read_text())
    returned = check["guardian_return"]
    facts = disk if returned is None else returned
    assert (
        facts["direct_child_reaped"]
        and facts["handle_closes_complete"]
        and facts["cleanup_complete"]
        and not facts["remaining"]
    )
    current = lc.process.identity(lc.process.process_info(facts["child"]["pid"]))
    assert current is None or current != facts["child"]
    fresh.append({"original": facts["child"], "fresh": current})
    receipts.append(
        {
            "command": check["name"],
            "returned_NULL": returned is None,
            "persisted": check["persisted_process_receipt"],
            "fullcapture": check["full_log"],
            "directwait_reap": True,
            "handles_closed": True,
            "cleanup_complete": True,
        }
    )
(notification,) = [
    check
    for check in data["checks"]
    if check["name"] == "send-one-frozen-source-current324"
]
receipt = json.loads(Path(notification["full_log"]["path"]).read_text())
assert (
    receipt["accepted"] is True
    and receipt["thread_id"] == "01a1376a-bfd3-75d2-bd64-61e9416b3b13"
)
tmp = HERE / "source-notify-v1/TMP"
assert len(data["TMP_remaining"]) == 1
path = Path(data["TMP_remaining"][0])
assert path.parent == tmp and path.name == "uv-cc8f3ad7aa19080a.lock"
before = path.lstat()
assert stat.S_ISREG(before.st_mode) and before.st_size == 0
fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC)
try:
    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    actual = os.fstat(fd)
    assert (actual.st_dev, actual.st_ino) == (before.st_dev, before.st_ino)
    assert path.lstat().st_ino == actual.st_ino
    path.unlink()
finally:
    os.close(fd)
tmp.rmdir()
record = {
    "phase": "FINAL_SOURCE_DELIVERY_CLEANUP_STOP",
    "actual_STOP": datetime.now(timezone.utc).isoformat(),
    "original_guard_result_preserved": original,
    "original_TMP_remaining_preserved": data["TMP_remaining"],
    "fresh_original_identities": fresh,
    "receipts": receipts,
    "actual_final_delivery_receipt": receipt,
    "RPC_final_source_attempts": 1,
    "resend_retry_refinalize": 0,
    "uv_cleanup": "only own zero-byte regular file, exact inode O_NOFOLLOW, flock EX NB unheld, unlink/rmdir",
    "TMP_absent": not tmp.exists(),
    "readers": [],
    "source_writers": [],
    "children": [],
    "jobs": [],
    "handles": [],
    "TMP": [],
    "leases": [],
    "owned": [],
    "current_small_cleanup_admin": "enclosing guard direct return recorded separately; no source or numerical work",
    "leaf": "same claimant in_progress; Root324 acceptance/backup/close",
    "additional_scientific_calls": 0,
}
target = HERE / "source-v1/delivery-STOP.json"
target.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"delivery": receipt, "STOP": ref(target), "owned": []}))
