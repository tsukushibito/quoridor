# 419.2 frozen source-only handoff

固定spec51935438/inputsb26fb4d5、base61d783d1882bb02e8617cdbe42c1fce24cda8e9bの一累積patchです。Main/managedproduction/Git/index/Cargo/native/model/Search/tests/science/Astra/reviewdispatch0。同claimant/in_progressを保持し、Root324が受入れ/backup/closeします。最終source配送は今回一度だけ、独立head checkpointを別に重ねて適用しないでください。

forcedはcommon Invocation/反復深化/child、H−1/ply1/fullwindow/累積1M、制限親通常TTなし。通常root_depth/child/PVS/TT/Key/evaluator/410411数学body exact。N/D fresh factory・固定3完全prefixのboard/ordered/fullhistory照合、H3完成anchorだけの一C、最大48/48M・N24・木300k・全logicalNN25Mを実コードで制御。H2/H3共通compact木・signedzero numeric tie・保存最大30介入の全応手rebackup・限定parity・canonical一head baseline/residual/pre/post/input viewを準備しました。通常OFFの追加head/clone/scan/clockなし。simd=falseは既存FT flagでheadのguarded routingは変更しません。

static Rustfmt/Ruff/一時完全publisher AST+lint/strict fuzz0 forward+inverse/新4file absence/subject外byte/保護body proof PASS。新AI4+NNUE3+runner5=12とPythonNN0oneはUNBUILT/UNTYPED/UNRUN。必要Root software/限定419.3 source判定は未実行です。新entryは既存measurement config loss_leaf_419=true、3selectorsと12normal schedule slots（全Search分母48は別census）。420交点はfunction-subject-mapに明記し、whole measurement/runtime overwrite不可・Sigma科学混入0です。

元FAILED/NULL-vs-disk/captures/masks/費UNKNOWNを保持。source actualSTOP20:49:42.780325Z、元source/format/proof IDs freshabsent/different/directwait/reap/handles/TMPgone/owned[]、canonical/hardwareleases0。最終小adminの返却境界はsource-admin-STOP.jsonへ別保存します。対象usage一回はlogical 5617683B / allocated_file 6533120B、globalactualUNKNOWN・decimal50GB保持。全pause/default/models/seals/旧RAW不変。Main/typed source/software/science clearへ昇格せず、ACKや420 completionを通常工程gateにしません。

```json
{
  "binding": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1/source-binding.json",
    "sha256": "4682f577313ace2aa9319dccc0d79a2ca3dc8ecfd61c35fbd095b285542d341d",
    "bytes": 12223,
    "mode": "0644"
  },
  "STOP": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1/source-STOP.json",
    "sha256": "017bb84dc53e12df48067350482285096dc5dca086969f78f72b19635b10c79a",
    "bytes": 50482,
    "mode": "0644"
  },
  "forward": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1/forward.patch",
    "sha256": "40d5cc08c9ac901ed722eaf75ca7f6aa279e4b0430b23457860837ac48eebf6c",
    "bytes": 82409,
    "mode": "0644"
  },
  "inverse": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1/inverse.patch",
    "sha256": "d56105b05a51aa5fac338358337be03a5e3cd4500f73dc80fef9c1e7fd7fba7b",
    "bytes": 82409,
    "mode": "0644"
  },
  "report": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1/report-ja.md",
    "sha256": "7240df759c5978543d7162906d5cc845fef049659b8d40f5c3d23d4f1411a698",
    "bytes": 8742,
    "mode": "0644"
  },
  "subjects": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1/function-subject-map.json",
    "sha256": "668ad07b039fb8af1ba151faff049fc6d29baf0352e70541ff371b658b49d409",
    "bytes": 7537,
    "mode": "0644"
  },
  "verification": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1/verification-plan.json",
    "sha256": "add66f08bd55dc3665d1b5bb30dcf22478eb09152d79ca423343a3b72cc5ecf3",
    "bytes": 8257,
    "mode": "0644"
  },
  "usage": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1/usage.json",
    "sha256": "6136e7c8df55bb2de4212662fd7c8ac355432408eae822b87c53e9ee8933dad9",
    "bytes": 780,
    "mode": "0644"
  },
  "completion": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1/completion.json",
    "sha256": "f37d6ee64b06e60896fe7b4f46a1c0733b4d2757b7bc5384cae7470892b82449",
    "bytes": 2771,
    "mode": "0644"
  }
}
```

最終metadata/formatterも元identity freshabsent/different、返却/directreap/handles/TMPgoneを確認しました。

```json
{
  "source_admin_STOP": {
    "path": "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1/source-admin-STOP.json",
    "sha256": "b5689e0d42133b3b57abd3f542bed102778d2e2af35b6f5a6fcd1789e1d6300b",
    "bytes": 6560,
    "mode": "0644"
  }
}
```
