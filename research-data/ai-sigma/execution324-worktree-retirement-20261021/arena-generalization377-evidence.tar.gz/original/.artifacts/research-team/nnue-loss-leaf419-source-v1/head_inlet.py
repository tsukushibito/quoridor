"""Bounded canonical math/forced caller facts, not candidate implementation."""

import hashlib
import json
import re

import intake
from read_owners import body


def main():
    here = intake.HERE
    base = json.loads((here / "intake-refs.json").read_text())["base_Git"]
    selected = []
    for relative in [
        "crates/quoridor-nnue/src/residual.rs",
        "crates/quoridor-runner/src/value_search_compare.rs",
    ]:
        raw = intake.git("show", base + ":" + relative)
        text = raw.decode()
        print("CANONICAL_HEAD_REF", relative, hashlib.sha256(raw).hexdigest(), len(raw))
        parts = []
        if relative.endswith("residual.rs"):
            names = [
                m[1]
                for m in re.finditer(r"(?m)^\s*(?:pub(?:\([^)]*\))? )?fn (\w+)", text)
            ]
            print("HEAD_METHOD_NAMES", names)
            for name in ["evaluate", "evaluate_with_scratch"]:
                m = re.search(
                    r"(?m)^\s*(?:pub(?:\([^)]*\))? )?fn " + name + r"\b", text
                )
                assert m, name
                part = body(text, m.start())
                print("HEAD_OWNER", name, "\n" + part)
                parts.append(part)
            # Only declaration/API names relating directly to scalar head views.
            for line in text.splitlines():
                if any(
                    token in line
                    for token in [
                        "struct Evaluation",
                        "pub fn",
                        "raw_value",
                        "pre_tanh",
                        ".tanh",
                        "pub baseline",
                        "pub residual",
                    ]
                ):
                    print("HEAD_INLET", line)
        else:
            lines = text.splitlines()
            seen = set()
            for i, line in enumerate(lines):
                if "forced" in line.lower():
                    lo, hi = max(0, i - 8), min(len(lines), i + 24)
                    fresh = [j for j in range(lo, hi) if j not in seen]
                    if fresh:
                        part = "\n".join(f"{j + 1}: {lines[j]}" for j in fresh)
                        print("EXISTING_FORCED_CALLER\n" + part)
                        parts.append(part)
                        seen.update(fresh)
        path = here / "selected" / (relative.replace("/", "__") + "-inlet.txt")
        path.write_text("\n\n".join(parts) + "\n")
        selected.append(
            {
                "relative": relative,
                "Git": base,
                "blob_oid": intake.git("rev-parse", base + ":" + relative)
                .decode()
                .strip(),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": "0644",
                "selected": intake.ref(path),
            }
        )
    (here / "head-inlet-refs.json").write_text(
        json.dumps(
            {
                "base_Git": base,
                "selected": selected,
                "implementation": "NOT_STARTED; fixed419.1 source protocol/input pending",
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
