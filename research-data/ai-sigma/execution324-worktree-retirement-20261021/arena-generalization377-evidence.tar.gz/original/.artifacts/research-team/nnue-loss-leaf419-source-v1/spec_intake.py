"""Verify the fixed designer packet before parsing and bind this source continuation."""

import json
import subprocess

from intake import HERE, ROOT, git, ref

source = HERE.parent / "nnue-loss-leaf419-analysis-v1"
expected = {
    "design-completion.json": (
        "491e2c78673cd85c2220bb4e719a9ca1c7b364a145506833e8a9ffb21ae4dcab",
        9720,
    ),
    "spec-ja.md": (
        "51935438948fd853e22d3e29421c0a0099cf0e412d33ba688bfd5ee8ae5be03f",
        13935,
    ),
    "fixed-inputs.json": (
        "b26fb4d5f21bac5b9614610504aac7022850223a6af67b4680530c08e8429304",
        24449,
    ),
    "design.json": (
        "af0cfa0295b26aee4240f06ee69ff368eda1e5d02866ea9b17741defa5ac1897",
        8398,
    ),
    "control.json": (
        "68b39f16f0fa5e432588c4ba49abfecb4f415cf772e86a4919bbe798e2958402",
        2752,
    ),
    "final-STOP.json": (
        "4cfd60d212d9cc3f3a7b858d59210e3204820f2a393875b1ca6f99192e3f1d89",
        18549,
    ),
}
refs = {}
for name, (sha, size) in expected.items():
    path = source / name
    actual = ref(path)
    assert (actual["sha256"], actual["bytes"], actual["mode"]) == (sha, size, "0644"), (
        name
    )
    refs[name] = actual
for name in expected:
    path = source / name
    if name in {"spec-ja.md", "design.json", "control.json"}:
        print(name, path.read_text())
    elif name == "fixed-inputs.json":
        data = json.loads(path.read_text())
        print(name, json.dumps(data, ensure_ascii=False))
    assert ref(path) == refs[name]
base = json.loads((HERE / "intake-refs.json").read_text())["base_Git"]
assert git("rev-parse", "HEAD").decode().strip() == base
own = subprocess.run(
    ["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.419.2", "--json"],
    cwd=ROOT,
    check=True,
    capture_output=True,
    text=True,
)
(HERE / "own-spec-continuation.json").write_text(own.stdout)
(record,) = json.loads(own.stdout)
assert (
    record["assignee"] == "codex:01a11004-79f3-7c20-872c-432a2c347664"
    and record["status"] == "in_progress"
)
(HERE / "fixed-spec-binding.json").write_text(
    json.dumps(
        {
            "verified_before_parse_and_after": refs,
            "base_Git": base,
            "context": {
                "timestamp": "2026-10-15T20:24:39.446Z",
                "turn": "01a1413c-ffd0-7510-b4ae-5c27dc165f63",
                "cwd": str(ROOT),
                "model": "gpt-6.1-sol",
                "effort": "high",
                "sandbox": "danger-full-access",
                "approval": "never",
                "actual_rollout_context_verified": True,
            },
            "native_Search_tests_model_science_Astra": 0,
        },
        indent=2,
    )
    + "\n"
)
