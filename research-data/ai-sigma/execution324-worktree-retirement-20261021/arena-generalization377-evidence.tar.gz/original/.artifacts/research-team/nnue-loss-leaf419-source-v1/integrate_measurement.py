"""Thin existing measurement integration; all mutations stay in private snapshots."""

from intake import HERE
from read_owners import body

post = HERE / "source-v1/post"
path = post / "crates/quoridor-runner/src/measurement.rs"
text = path.read_text()
text = text.replace(
    "#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq)]",
    '#[path = "measurement_loss_leaf.rs"]\nmod loss_leaf;\n\n#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq)]',
    1,
)
text = text.replace(
    "struct Settings {",
    "struct Settings {\n    #[serde(default)]\n    loss_leaf_419: bool,",
    1,
)
text = text.replace(
    "fn validate(settings: &Settings, requests: &[Request]) -> Result<()> {",
    "fn validate(settings: &Settings, requests: &[Request]) -> Result<()> {\n    if settings.loss_leaf_419 { loss_leaf::validate(settings, requests)?; }",
    1,
)
text = text.replace(
    '    let expected = if row.get("opening_bound").is_some()',
    """    let expected = if row.get("expected_ordered_history_keys").is_some() {
        if selector.field != "from_prefix_actions" || selector.prefix_len.is_some()
            || selector.jsonl_match.is_some() || selector.check_history {
            return Err("loss-leaf requires the complete canonical prefix, not supplied counts".into());
        }
        Some(row.clone())
    } else if row.get("opening_bound").is_some()""",
    1,
)
start = text.index("fn load_evaluator(")
old = body(text, start)
model_start = old.index("    let selected = e.models.first()")
model_body = old[model_start:]
model_body = model_body.replace(
    "    Ok(Arc::new(alphabeta::ResidualEvaluator::new(model)))", "    Ok(model)", 1
)
new = (
    """fn load_evaluator(e: &Experiment, settings: &Settings) -> Result<Arc<dyn StaticEvaluator>> {
    evaluator_binding(settings, e.models.len())?;
    if e.models.is_empty() {
        return Ok(Arc::new(alphabeta::DistanceEvaluator::new(0., 8.)));
    }
    Ok(Arc::new(alphabeta::ResidualEvaluator::new(load_residual_model(e)?)))
}

fn load_residual_model(e: &Experiment) -> Result<Arc<quoridor_nnue::residual::ResidualModel>> {
"""
    + model_body
)
text = text[:start] + new + text[start + len(old) :]
marker = '        if expected.get("opening_bound").is_some() {'
assert text.count(marker) == 1
text = text.replace(
    marker,
    """        if expected.get("expected_ordered_history_keys").is_some() {
            loss_leaf::input_check(&spec.prefix, expected, &root)?;
        } else if expected.get("opening_bound").is_some() {""",
    1,
)
start = text.index(
    "    let (prepared, preparation_seconds) = timed(", text.index("pub fn run(")
)
stop = text.index('    result["runtime_launch_origin"]', start)
old = text[start:stop]
old = old.replace(
    "    let mut result = match prepared", "    let mut result = match prepared", 1
)
text = (
    text[:start]
    + """    let mut result = if settings.loss_leaf_419 {
        loss_leaf::run(&e, &settings, &requests, &cancel, &mut |row| output.row(row))?
    } else {
"""
    + old
    + """        result
    };
"""
    + text[stop:]
)
path.write_text(text)
# Reuse the exact terminal-first and per-edge STM sign owners of the old finite
# common tree, without carrying its old book/models/caps/nested representation.
path = post / "crates/quoridor-runner/src/value_search_compare.rs"
text = path.read_text()
start = text.index("fn tree(")
text = (
    text[:start]
    + """pub(crate) fn tree_terminal(root: &SigmaContext) -> Option<f32> {
    root.terminal_value().map(|v| v * alphabeta::TERMINAL_SCORE)
}
pub(crate) fn tree_parent_value(child: f32) -> f32 { -child }

"""
    + text[start:]
)
start = text.index("fn tree(")
old = body(text, start)
new = (
    old.replace(
        "if let Some(v) = root.terminal_value()",
        "if let Some(v) = tree_terminal(root)",
        1,
    )
    .replace("values: [v * alphabeta::TERMINAL_SCORE; 3]", "values: [v; 3]", 1)
    .replace("t.values.map(|v| -v)", "t.values.map(tree_parent_value)", 1)
)
assert new != old
text = text[:start] + new + text[start + len(old) :]
path.write_text(text)
# Function-only Python postimage. Never persist or rewrite the whole publisher.
path = HERE / "source-v1/before-measurement_config.py.txt"
text = path.read_text()
text = text.replace(
    '            "roots",\n', '            "loss_leaf_419",\n            "roots",\n', 1
)
marker = '    require(type(config.get("lmr", False)) is bool, "measurement LMR switch")'
assert text.count(marker) == 1
text = text.replace(
    marker,
    """    require(type(config.get("loss_leaf_419", False)) is bool, "loss-leaf switch")
"""
    + marker,
    1,
)
marker = "    return config, requests"
extra = """    if config.get("loss_leaf_419", False):
        parent_ids = ("distance-slot004-ply011", "distance-slot004-ply039", "distance-slot005-ply012")
        require(
            config["profile"] == "control" and config["tt_entries"] == 1048576
            and config["use_tt"] and config["use_pvs"] and not config.get("lmr", False)
            and threshold is None and not config.get("zero_stock_safe_race", False)
            and len(config["roots"]) == 3 and len(requests) == 12
            and len({r["session"] for r in requests}) == 12
            and len(experiment["inputs"]) == 1
            and experiment["inputs"][0]["sha256"] == "b26fb4d5f21bac5b9614610504aac7022850223a6af67b4680530c08e8429304",
            "loss-leaf fixed cold Control/OFF input protocol",
        )
        for i, root in enumerate(config["roots"]):
            require(root["input"] == 0 and root["pointer"] == f"/parents/{i}"
                    and root["field"] == "from_prefix_actions" and root["label"] == parent_ids[i]
                    and root.get("prefix_len") is None and root.get("jsonl_match") is None
                    and not root.get("check_history", False), "loss-leaf complete-prefix selectors")
        for i, request in enumerate(requests):
            parent, depth, engine = i // 4, 2 + (i % 4) // 2, ("N", "D")[i % 2]
            require(request["id"] == f"{parent_ids[parent]}:{engine}:H{depth}:normal"
                    and request["root"] == parent and request["depth"] == depth
                    and request["node_cap"] == 1000000 and request.get("time_limit_ms") is None
                    and not any(request.get(k, False) for k in ("diagnostic", "warmup", "observe_lmr", "observe_completed_depths")),
                    "loss-leaf fixed normal schedule; forced union derived once natively")
"""
assert text.count(marker) == 1
text = text.replace(marker, extra + marker, 1)
(HERE / "source-v1/measurement_config.py").write_text(text)
print("PRIVATE_EXISTING_ENTRY_INTEGRATION_WRITTEN")
