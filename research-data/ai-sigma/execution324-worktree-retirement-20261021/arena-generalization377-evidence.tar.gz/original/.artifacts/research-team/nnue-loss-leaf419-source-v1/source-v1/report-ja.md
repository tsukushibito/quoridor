# 419.2：敗戦親・共通葉診断の凍結source

固定SolMax spec `51935438948fd853e22d3e29421c0a0099cf0e412d33ba688bfd5ee8ae5be03f` とinput `b26fb4d5f21bac5b9614610504aac7022850223a6af67b4680530c08e8429304` に合わせた一つの私有patchを用意した。source基盤はGit `61d783d1882bb02e8617cdbe42c1fce24cda8e9b`。source/staticの確認だけで、独立source_clear・Rust型・native/software・モデル・科学資格は未取得。新native12定義とPython NN0一定義はUNBUILT/UNTYPED/UNRUNである。Main、managed production、Git/index、Cargo、モデル、Search、forward、native tests、科学、Astra、再帰委譲、review dispatchは実行・変更していない。

## 接続と保護

forcedは既存SearchSession/SearchInvocationと1..Hの反復深化を使う。Hは親の指定着手を含み、childはH−1/ply1/full window。同じ呼出しのTT・ordering・scratch・累積node capを使う。新しい薄いforced-root helperがcommon childを一度呼び、制限親の通常TT probe/storeを通らない。通常の `root_depth`、child、negamax、reduced-child/PVS、TT・Key、411/410の数学、N/D evaluator本体はbyte exact。417 observerの3つのInvocation literalには `forced_root: None` だけを足し、現役機能を保った。制限rootをall-legal rootの履歴creditとして完了させない。

measurementの既存configに `loss_leaf_419: bool` を追加し、既定false・null拒否とした。通常OFFでは旧root payload処理を保ち、入力のfield有無から観測modeを推測しない。独立420との交点は `Settings`、`validate`、`root_spec`、`prepare_roots`、`replay`、`load_evaluator`、`run` と新しい狭い `load_residual_model`。後者は既存のNNUE読込／fingerprint検査を一ownerに抽出したもので、registryや新evaluator数学ではない。420との合成はfunction-subject単位でRootが行う。全measurement/runtimeを上書きしてはならない。

## 固定入力・call・counter

入場は既存のcompare/measurement Experimentを使う。configの `loss_leaf_419=true`、root selectorsはinput0の `/parents/0..2`、field `from_prefix_actions`、元ID label、truncation/jsonl/check_historyなし。input SHA/bytes/modeとBEST43のdescriptor/weights/typed evaluatorをnative側でも固定する。scheduleはspecの親順/H2→H3/N→Dの12通常request、各fresh session/TT1M/Control/PVS/1M/timeNone、全observer/LMR/approx/safe OFF。Experimentのplanned_slots=12は初期schedule分母であり、全Searchは別censusで最大48と明示する。

実完全prefixはcanonical `from_prefix` とnormal検査で入場する。native ownerが最終baseをcountsに集約するため、chronological順はcounts/occurrencesから推測しない。入場時だけ空prefixからcanonical makeで順序付きprojectionを確認し、同じ最終board/ply/rules/full countsへ一致させる。末尾count・在庫・壁anchor・手番・全順序を照合し、途中terminalを越えない。これは小さいprefixの追加admission処理の実費で、per-leafのhistory cloneや新chronology権威ではない。

H3のCOMPLETE actionだけがanchorとなる。親ごとの一度のunionをActionID昇順でdedupし、同じCをH2/H3で使う。未完成H3へH2を補充しない。forcedは親/H2→H3/N→D/action昇順、最大36。normalとforcedは別request IDで、Cのdedupにより役割の重複を追加callへしない。全callのfresh table/order/scratchと残る1M liability、N最大24、node上限48M、全stage logical NNUE25Mを分離する。Errで実workを取得できない場合は1Mの未確定liabilityを残し、原error・保存済みrow・UNKNOWNを保持する。returned観測は後続validationが失敗しても捨てない。cap/cancel/error/未入場を補充しない。

## 共通木・保存介入・限定parity

既存value-search比較のterminal-firstと辺ごとのSTM反転を小さな共通ownerへ抽出した。旧treeはその2箇所を戻すとbyte exactであり、旧book/model/caps/3評価器/nested表現は419へ流用しない。419はroot C、その後ALL legalをcanonical make/unmakeで一度だけply3まで辿る。TT・pruning・pathmergeはない。非終端ply2/3でNNUE/Dを同葉評価し、H2/H3へ共有する。flat parent/action/ply/terminal/child数/static/backup記録にし、全nodeへ履歴・feature・81cellsを複製しない。

300k実visitを制御し、missing child/未完成ancestorはUNKNOWN。H2 frontierが全て保存済みならH3途中停止でもH2だけ独立COMPLETEにできる。backupはlocal STM `max(-child)`。±0は数値tie、bitsは別に保存し、canonicalは最小ActionID。通常Searchのtie選択と同じだとは仮定しない。

両C内tie集合が違うparent×Hだけ、両canonical winnerから両評価器のcanonical応手を辿る最大4endpointをpath辞書順でdedupする。単独各1＋全同時、全体最大30。NNUE local postだけを同葉D postへ置換し、全応手を毎回rebackupする。固定PVや追加endpoint探しは使わない。Dはoracleではない。新fixtureは、置換で別の応手へ切り替わる既知toyを含む。

canonical headは一計算からbaseline/residual/pre/postのbitsを返す。finite検査・算術順序・標準化入力・f64 tanh→f32は元のまま。既存routing二bool callbackを拡張しない。scratch input viewはresearch診断時の不変borrowだけで、通常OFFにhead再実行・clone・scan・clockを足さない。viewの返却表現・ABI・stack・copy・時間は未測定でUNKNOWN。

固定canonical pathと3rootだけをbounded parityに選ぶ。max256を埋める追加状態はない。full/delta/親復元のexact構造とFP32 error/既存abs1e-5+rel1e-4 alertを区別し、特徴・input bits・親出力・fullhistory復元を保存する。terminalにはstatic head/logitを付けない。physical FT更新数とSearch head数は未計測ならUNKNOWNとし、Search evaluations、診断full/delta/head starts、logical liability、tree visits、callsを混同しない。`simd=false` は既存callerのscalar FT selectorであり、canonical headのguarded runtime routingを改変・一律scalar化したとの主張ではない。

## source確認・Rootで残る検証

全変更Rust/Pythonは対象限定Rustfmt/Ruffで整形した。function-only publisher postは一時的な完全publisherへ差し込み、AST parseとproject Ruff lintを行い、終了後その一時fileを消した。恒常publisher mirrorは作らない。strict forward/inverseはfuzz0/offsetなし、全before/postと新4fileのabsence復元が一致した。通常root/child/PVS/TT/evaluator/head入力bodyとsubject外bytesを保護した。詳細は `source-binding.json`、`function-subject-map.json`、`verification-plan.json`。

新nativeはAI4・NNUE3・runner5の12定義、Python NN0は1定義。Rootが必要なresearch/research-diagnostics compile、これらと関連3定義、Clippy、真正releaseを実行する。現時点でRust型/Clippy/native PASSは主張しない。419.3は最終packetのforced depth/window/TT、history/undo、木完成/sign/tie、head非干渉、保存介入/counter境界を限定確認する段階で、作者からdispatchしていない。419.3の初期spec見解をsource_clearへ昇格しない。

source guardはCPU3/別physical guardian7、family512MiB inclusive controller、GPU0、hostreserve4GiB、no_new_privs、有限source command/fullcapture/directwait/reap/handles/TMPcleanup。各実入場のtopology/affinity/RAM/限定pinned peerを記録した。全host静穏・連続RSS peak・LLM資源はUNKNOWN。canonical/Main/hardware leaseとidle予約は0。

原FAILEDは保持した。inletの初期未記録controller、returned NULLとdisk masks、uv notification lock、静的proofの広いmodule区切り、literal Git検索の誤escape、統合proofの空行/同一braceによる区間照合停止は成功へ書換えていない。修正はsource helperの対象選択/境界だけで、科学や成功native suiteの再演ではない。最終成功proofは新しい実source変更後に実行した。

このforwardはbaseから累積した一packetであり、独立head-view checkpointのpatchを別に重ねて適用しない。Rootがcurrent sourceへ薄く合成する。最終affected usageはOWNだけ一度計測し、global実使用はUNKNOWNのまま。全models/weights/seals/defaults/product/generator、mixed/learner ALLprep/pipelineと323 USERPAUSE、旧RAW/FAILED/費/UNKNOWN、foreign devcontainerは不変。419.2の同claimant/in_progressを維持し、受入れ・backup・closeは324が担当する。
