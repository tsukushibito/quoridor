"""Resolve actual owning API facts without widening production or fixture scope."""

import gzip
from intake import HERE
from read_owners import body

out = HERE / "source-v1"
alpha = out / "post/crates/quoridor-ai/src/alphabeta.rs"
before = gzip.decompress(
    (out / "before/crates/quoridor-ai/src/alphabeta.rs.gz").read_bytes()
).decode()
text = alpha.read_text()
start = text.index("    fn root_depth(")
changed = body(text, start)
original = body(before, before.index("    fn root_depth("))
helper = """    fn forced_root_depth(
        &mut self, c: &mut SigmaContext, a: Option<&EvalAccumulator>, depth: u16, action: u16,
    ) -> NodeResult<(u16, f32)> {
        self.enter()?;
        if !c.legal_ids().contains(&action) {
            return Err(Interrupted::Error(SearchError::Root("illegal forced root action".into())));
        }
        // Restricted parent values never enter the all-legal root TT owner.
        let value = self.child(c, a, action, depth - 1,
            [f32::NEG_INFINITY, f32::INFINITY], 1)?;
        self.control()?;
        Ok((action, value))
    }

"""
text = text[:start] + helper + original + text[start + len(changed) :]
text = text.replace(
    "state.root_depth(&mut c, a.as_ref(), depth, result.action, invocation.forced_root)?",
    """if let Some(action) = invocation.forced_root {
                state.forced_root_depth(&mut c, a.as_ref(), depth, action)?
            } else {
                state.root_depth(&mut c, a.as_ref(), depth, result.action)?
            }""",
    1,
)
text = text.replace(
    "let mut on_completed = |_| {};", "let mut on_completed = |_: &SearchResult| {};", 1
)
alpha.write_text(text)
path = out / "post/crates/quoridor-runner/src/measurement_loss_leaf.rs"
text = path.read_text()
old = """    let ordered: Vec<_> = root.occurrences().map(|(key, weight)| {
        if weight != 1 { return Err("from_prefix history must enumerate chronological arrivals".into()); }
        Ok(key.history_string())
    }).collect::<Result<_>>()?;"""
new = """    // from_prefix deliberately aggregates its final base; occurrences() does
    // not retain chronological order. Reconstruct only this bounded admission
    // projection with the same checked owner, never infer order from counts.
    let mut chronology = SigmaContext::from_prefix(&[])?;
    let mut ordered = vec![HistoryKey::from(chronology.position()).history_string()];
    for &action in prefix {
        chronology.make_move(action)?;
        ordered.push(HistoryKey::from(chronology.position()).history_string());
    }
    chronology.validate_normal()?;
    if identity(&chronology) != identity(root) { return Err("prefix admission projections differ".into()); }"""
assert text.count(old) == 1
text = text.replace(old, new, 1)
path.write_text(text)
print("ORDINARY_ROOT_DEPTH_EXACT; PREFIX_COUNTS_NOT_CHRONOLOGY")
