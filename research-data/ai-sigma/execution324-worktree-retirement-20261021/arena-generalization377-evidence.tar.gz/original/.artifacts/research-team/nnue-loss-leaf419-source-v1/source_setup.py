"""Pin only files that need sparse edits, and print the selected existing inlets."""

import gzip
import json
import re

from intake import HERE, git, ref
from read_owners import body

base = json.loads((HERE / "intake-refs.json").read_text())["base_Git"]
out = HERE / "source-v1"
out.mkdir()
refs = []
for relative in [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-ai/src/lib.rs",
    "crates/quoridor-runner/src/measurement.rs",
    "crates/quoridor-runner/src/value_search_compare.rs",
    "crates/quoridor-nnue/src/residual.rs",
]:
    raw = git("show", base + ":" + relative)
    before = out / "before" / (relative + ".gz")
    before.parent.mkdir(parents=True, exist_ok=True)
    before.write_bytes(gzip.compress(raw, mtime=0))
    post = out / "post" / relative
    post.parent.mkdir(parents=True, exist_ok=True)
    post.write_bytes(raw)
    refs.append(
        {"relative": relative, "before_gzip": ref(before), "post_initial": ref(post)}
    )
    text = raw.decode()
    if relative.endswith("measurement.rs"):
        print("MEASUREMENT_HEADER", "\n".join(text.splitlines()[:240]))
        print(
            "MEASUREMENT_NAMES",
            re.findall(r"(?m)^(?:pub(?:\([^)]*\))? )?fn (\w+)", text),
        )
        for name in ["run", "identity", "read", "observation_input_check"]:
            match = re.search(r"(?m)^(?:pub(?:\([^)]*\))? )?fn " + name + r"\b", text)
            if match:
                print("MEASUREMENT_OWNER", name, body(text, match.start()))
    elif relative.endswith("alphabeta.rs"):
        print(
            "ALPHA_NAMES", re.findall(r"(?m)^\s*(?:pub(?:\([^)]*\))? )?fn (\w+)", text)
        )
        for marker in [
            "struct SearchInvocation",
            "pub struct SearchSession",
            "impl SearchSession",
            "pub struct SearchLimits",
            "pub struct SearchResult",
            "pub struct ResidualEvaluator",
        ]:
            start = text.index(marker)
            print("ALPHA_INLET", marker, text[max(0, start - 100) : start + 2300])
        for name in ["search", "search_with_completed", "invoke", "pv"]:
            match = re.search(
                r"(?m)^\s*(?:pub(?:\([^)]*\))? )?fn " + name + r"\b", text
            )
            if match:
                print("ALPHA_OWNER", name, body(text, match.start()))
    elif relative.endswith("value_search_compare.rs"):
        print("COMPARE_HEADER", "\n".join(text.splitlines()[:85]))
        print(
            "COMPARE_FUNCTIONS",
            re.findall(r"(?m)^(?:pub(?:\([^)]*\))? )?fn (\w+)", text),
        )
    elif relative.endswith("lib.rs"):
        print("AI_LIB", text)
(out / "before-refs.json").write_text(
    json.dumps({"base_Git": base, "subjects": refs}, indent=2) + "\n"
)
# Python publisher is one selected function, never a persistent full publisher mirror.
publisher = git("show", base + ":scripts/dev/research-lifecycle.py").decode()
match = re.search(r"(?m)^def measurement_config\(", publisher)
assert match
end = re.search(r"(?m)^def \w+\(", publisher[match.end() :])
stop = match.end() + end.start() if end else len(publisher)
selected = publisher[match.start() : stop]
(out / "before-measurement_config.py.txt").write_text(selected)
print("PYTHON_MEASUREMENT_CONFIG", selected)
