"""Read the two validation owners required by the small proposed unit fixtures."""

import json
import re

from intake import HERE, git
from read_owners import body

base = json.loads((HERE / "intake-refs.json").read_text())["base_Git"]
for relative, names in [
    (
        "crates/quoridor-nnue/src/residual.rs",
        ["observed_matches_and_bad_shape_has_no_route"],
    ),
    ("crates/quoridor-nnue/src/lib.rs", ["validate_accumulator"]),
]:
    text = git("show", base + ":" + relative).decode()
    for name in names:
        match = re.search(r"(?m)^\s*(?:pub(?:\([^)]*\))? )?fn " + name + r"\b", text)
        assert match
        print(relative, body(text, match.start()))
