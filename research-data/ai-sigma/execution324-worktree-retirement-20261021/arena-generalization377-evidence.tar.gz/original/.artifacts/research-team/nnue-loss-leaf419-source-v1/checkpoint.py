"""Actual finite intake boundary; implementation waits only for fixed protocol."""

from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path

import intake


def main():
    here = intake.HERE
    loader = importlib.util.spec_from_file_location(
        "lc419_checkpoint", intake.ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    children = []
    for name in ["intake-v1", "owners-v1", "head-v1", "head-view-v1"]:
        path = here / name / "result.json"
        phase = json.loads(path.read_text())
        assert phase["status"] == "PASS" and not (path.parent / "TMP").exists()
        for check in phase["checks"]:
            returned = check["guardian_return"]
            disk_ref = check["persisted_process_receipt"]
            assert intake.ref(Path(disk_ref["path"])) == disk_ref
            disk = json.loads(Path(disk_ref["path"]).read_text())
            facts = returned if returned is not None else disk
            assert facts["direct_child_reaped"] and facts["handle_closes_complete"]
            assert facts["cleanup_complete"] and not facts["remaining"]
            fresh = lc.process.identity(lc.process.process_info(facts["child"]["pid"]))
            assert fresh is None or fresh != facts["child"]
            children.append(
                {
                    "phase": name,
                    "result": intake.ref(path),
                    "child": facts["child"],
                    "fresh_identity": fresh,
                    "returned_scope": "original settled return"
                    if returned is not None
                    else "NULL; disk facts only",
                    "direct_child_reaped": facts["direct_child_reaped"],
                    "handles_complete": facts["handle_closes_complete"],
                    "cleanup_complete": facts["cleanup_complete"],
                    "returned_mask": None
                    if returned is None
                    else returned.get("signal_mask_restoration"),
                    "disk_mask": disk.get("signal_mask_restoration"),
                    "returned_persist": None
                    if returned is None
                    else returned.get("final_record_persist"),
                    "disk_persist": disk.get("final_record_persist"),
                    "fullcapture": check["full_log"],
                    "child_wall_seconds_once": facts["wall_seconds"],
                }
            )
    result = {
        "issue": "quoridor-4lc.419.2",
        "scope": "bounded pre-spec source intake only; not frozen implementation handoff",
        "actual_intake_reader_STOP": datetime.now(timezone.utc).isoformat(),
        "children": children,
        "source_refs": intake.ref(here / "intake-refs.json"),
        "selected_owners": intake.ref(here / "selected-owner-refs.json"),
        "head_refs": intake.ref(here / "head-inlet-refs.json"),
        "observed_head": intake.ref(here / "observed-head-ref.json"),
        "report": intake.ref(here / "inlet-cost-ja.md"),
        "pending_dependency": "419.1 fixed specification and exact input FileRefs; no human/Root reapproval or parent-close gate",
        "horizon_tree_intervention_API_choices": "NOT_FIXED; no independent protocol expansion",
        "native_Search_model_tests_science_review_dispatch_Astra": 0,
        "Main_Git_index_Cargo_managedproduction_writes": 0,
        "readers": [],
        "source_writers": [],
        "children_remaining": [],
        "jobs": [],
        "handles": [],
        "TMP": [],
        "leases": [],
        "owned": [],
        "source_guard_controller_identities_earlier_phases": "UNKNOWN where not recorded; tool returned normally, no invented PID/start",
        "current_metadata_child": "this finite guarded writer; its recorded identity/reap is in preparation-v1/result.json after return",
        "usage": "DEFERRED one directed OWN walk until final source phase; no global/asset/target walk or reserve",
        "leaf": "in_progress same claimant; Root324 acceptance/backup/close",
    }
    (here / "intake-checkpoint.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "checkpoint": intake.ref(here / "intake-checkpoint.json"),
                "owned": [],
                "dependency": result["pending_dependency"],
            }
        )
    )


if __name__ == "__main__":
    main()
