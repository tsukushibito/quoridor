"""Selected existing hook bodies and immutable contract, no execution thereof."""

from datetime import datetime, timezone
import json
import re

import intake


def body(text, start):
    brace = text.index("{", start)
    depth = 0
    for t in re.finditer(
        r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\\n])\'|[{}]',
        text[brace:],
    ):
        if t.group() == "{":
            depth += 1
        elif t.group() == "}":
            depth -= 1
            if depth == 0:
                return text[start : brace + t.end()]
    raise AssertionError("unterminated selected source")


def main():
    here = intake.HERE
    original = json.loads((here / "intake-refs.json").read_text())
    base = original["base_Git"]
    contract = (
        intake.ROOT / ".artifacts/research-policy/nnue-loss-leaf-validation-20261015.md"
    )
    before = intake.ref(contract)
    contract_text = contract.read_text()
    assert intake.ref(contract) == before
    print("HUMAN_CONTRACT\n" + contract_text)
    requests = {
        "crates/quoridor-runner/src/value_search_compare.rs": [
            "admit",
            "settle",
            "validate_return",
            "call",
            "tree",
        ],
        "crates/quoridor-runner/src/bin/nnue-diagnose.rs": [
            "feature",
            "shallow_terminal",
            "prepare",
            "accumulator_error",
            "same_float_bits",
            "qualify_residual",
        ],
        "crates/quoridor-runner/src/measurement.rs": [
            "evaluator_binding",
            "load_evaluator",
            "replay",
        ],
        "crates/quoridor-ai/src/alphabeta.rs": [
            "child",
            "negamax",
            "root_depth",
            "search_in_table",
        ],
        "crates/quoridor-ai/src/lmr_observation.rs": ["lmr_trial"],
    }
    selected = []
    for relative, names in requests.items():
        raw = intake.git("show", base + ":" + relative)
        previous = next(r for r in original["sources"] if r["relative"] == relative)
        import hashlib

        assert hashlib.sha256(raw).hexdigest() == previous["sha256"]
        text = raw.decode()
        parts = []
        for name in names:
            m = re.search(r"(?m)^\s*(?:pub(?:\([^)]*\))? )?fn " + name + r"\b", text)
            assert m, name
            part = body(text, m.start())
            parts.append("// SELECTED OWNER FUNCTION " + name + "\n" + part)
            print("OWNER", relative, name, "\n" + part)
        if relative.endswith("alphabeta.rs"):
            for owner in [
                "impl StaticEvaluator for DistanceEvaluator",
                "impl StaticEvaluator for ResidualEvaluator",
                "pub trait StaticEvaluator",
            ]:
                start = text.index(owner)
                part = body(text, start)
                parts.append(part)
                print("MATH_AND_EVAL_OWNER", owner, "\n" + part)
        path = here / "selected" / (relative.replace("/", "__") + ".txt")
        path.parent.mkdir(exist_ok=True)
        path.write_text("\n\n".join(parts) + "\n")
        selected.append(
            {"source": previous, "selected": intake.ref(path), "function_names": names}
        )
    (here / "selected-owner-refs.json").write_text(
        json.dumps(
            {
                "base_Git": base,
                "contract": before,
                "selected": selected,
                "reader_UTC": datetime.now(timezone.utc).isoformat(),
                "final_spec": "PENDING419.1; no horizon/tree/intervention choice made",
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
