"""Read only the canonical prefix/history and manifest input interfaces."""

import json
import re
from intake import HERE, git
from read_owners import body

base = json.loads((HERE / "intake-refs.json").read_text())["base_Git"]
for path, names in [
    ("crates/quoridor-core/src/research.rs", ["from_prefix", "occurrences"]),
    ("crates/quoridor-runner/src/research_manifest.rs", ["validate_comparison"]),
]:
    text = git("show", base + ":" + path).decode()
    for name in names:
        m = re.search(r"(?m)^\s*(?:pub(?:\([^)]*\))? )?fn " + name + r"\b", text)
        if m:
            print(path, name, body(text, m.start()))
    if path.endswith("research_manifest.rs"):
        for name in [
            "pub struct Experiment",
            "pub struct ModelRef",
            "pub struct BoundControl",
        ]:
            start = text.find(name)
            if start >= 0:
                print(text[start : start + 1700])
