"""Apply small current-owner edits in private postimages, never managed production."""

import gzip
import json

from intake import HERE, git, ref

out = HERE / "source-v1"
post = out / "post"
base = json.loads((HERE / "intake-refs.json").read_text())["base_Git"]
alpha = post / "crates/quoridor-ai/src/alphabeta.rs"
text = alpha.read_text()
assert text.count("struct SearchInvocation<'a> {") == 1
text = text.replace(
    "struct SearchInvocation<'a> {",
    "struct SearchInvocation<'a> {\n    forced_root: Option<u16>,",
    1,
)
text = text.replace(
    '            on_completed,\n            #[cfg(feature = "research-diagnostics")]\n            observation: None,',
    '            on_completed,\n            forced_root: None,\n            #[cfg(feature = "research-diagnostics")]\n            observation: None,',
    1,
)
marker = "        previous: Option<u16>,\n    ) -> NodeResult<(u16, f32)> {\n        self.enter()?;"
assert text.count(marker) == 1
text = text.replace(
    marker,
    """        previous: Option<u16>,
        forced: Option<u16>,
    ) -> NodeResult<(u16, f32)> {
        self.enter()?;
        if let Some(action) = forced {
            if !c.legal_ids().contains(&action) {
                return Err(Interrupted::Error(SearchError::Root("illegal forced root action".into())));
            }
            // This is a restricted parent, never an ordinary all-legal root TT value.
            // The common child still owns enter/control/context/TT/make/undo/PVS.
            let value = self.child(c, a, action, depth - 1,
                [f32::NEG_INFINITY, f32::INFINITY], 1)?;
            self.control()?;
            return Ok((action, value));
        }""",
    1,
)
text = text.replace(
    "state.root_depth(&mut c, a.as_ref(), depth, result.action)?",
    "state.root_depth(&mut c, a.as_ref(), depth, result.action, invocation.forced_root)?",
    1,
)
text = text.replace(
    "    if ordinary_root\n        && result.completed_depth > 0",
    "    if ordinary_root\n        && invocation.forced_root.is_none()\n        && result.completed_depth > 0",
    1,
)
marker = (
    "    /// Same persistent table and search; callback publishes complete depths only."
)
assert text.count(marker) == 1
text = text.replace(
    marker,
    """    /// Restrict only the parent action. H includes this move; all 1..=H iterations
    /// share the invocation's cumulative cap, table, ordering and scratch. No
    /// restricted parent numeric entry is read or stored as an all-legal root.
    pub fn search_forced(
        &mut self,
        root: &SigmaContext,
        action: u16,
        limits: &SearchLimits,
        cancel: &AtomicBool,
    ) -> Result<SearchResult> {
        let root_walls = root.position().walls_remaining.into_iter().map(u16::from).sum();
        self.set_zero_stock_approx_effective(permit_zero_stock_approx(
            self.zero_stock_approx_min_root_walls, root_walls, limits.max_depth));
        let mut on_completed = |_| {};
        let mut invocation = SearchInvocation::root(&mut on_completed);
        invocation.forced_root = Some(action);
        search_in_table::<false, false>(root, self.evaluator.as_ref(), limits, cancel, None,
            invocation, (&mut self.table, self.score_domain, self.ordering.as_mut(),
            self.ordering_diagnostics, self.static_enabled, (self.lmr, self.lmr_method),
            (self.zero_stock_approx_effective, self.zero_stock_approx_method, self.zero_stock_safe_race)))
    }

"""
    + marker,
    1,
)
alpha.write_text(text)
relative = "crates/quoridor-ai/src/lmr_observation.rs"
raw = git("show", base + ":" + relative)
before = out / "before" / (relative + ".gz")
before.write_bytes(gzip.compress(raw, mtime=0))
text = raw.decode()
text = text.replace(
    "SearchInvocation {", "SearchInvocation {\n                forced_root: None,"
)
assert text != raw.decode()
(post / relative).write_text(text)
(out / "observer-companion-before.json").write_text(
    json.dumps({"relative": relative, "before_gzip": ref(before)}, indent=2) + "\n"
)
# The independent view checkpoint stays immutable; extend its private proposal
# with the concrete baseline/residual fields now required by the fixed spec.
residual = post / "crates/quoridor-nnue/src/residual.rs"
text = (HERE / "head-view-proposal-v1/residual.rs").read_text()
text = text.replace(
    "pub struct ResidualValueView {",
    "pub struct ResidualValueView {\n    pub baseline_logit: f32,\n    pub linear_residual: f32,",
    1,
)
text = text.replace(
    "        Ok(ResidualValueView {\n            pre_tanh: value,",
    "        Ok(ResidualValueView {\n            baseline_logit: u,\n            linear_residual: r,\n            pre_tanh: value,",
    1,
)
marker = "impl ResidualModel {"
text = text.replace(
    marker,
    """#[cfg(feature = "research")]
impl ResidualScratch {
    /// Borrow the canonical already-prepared head input for bounded diagnostics.
    /// No preparation, allocation, formula or inference is performed here.
    pub fn input_view(&self) -> &[f32] { &self.input }
}
"""
    + marker,
    1,
)
text = text.replace(
    "        assert_eq!(view.pre_tanh.to_bits(), 1.25_f32.to_bits());",
    "        assert_eq!(view.baseline_logit.to_bits(), 0.625_f32.to_bits());\n        assert_eq!(view.linear_residual.to_bits(), 0.625_f32.to_bits());\n        assert_eq!(view.pre_tanh.to_bits(), 1.25_f32.to_bits());",
    1,
)
residual.write_text(text)
print("PRIVATE_FORCED_INVOCATION_AND_CANONICAL_VIEW_PREPARED")
