"""Static exact reconstruction and ownership proof; never execute authored tests."""

import ast
import difflib
import gzip
import hashlib
from itertools import accumulate
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

from intake import HERE, ROOT, git, ref
from read_owners import body

OUT = HERE / "source-v1"
POST = OUT / "post"
BASE = json.loads((HERE / "intake-refs.json").read_text())["base_Git"]
before = {}
for entry in json.loads((OUT / "before-refs.json").read_text())["subjects"]:
    relative = entry["relative"]
    before[relative] = gzip.decompress(
        Path(entry["before_gzip"]["path"]).read_bytes()
    ).decode()
observer = "crates/quoridor-ai/src/lmr_observation.rs"
before[observer] = gzip.decompress(
    (OUT / "before" / (observer + ".gz")).read_bytes()
).decode()
texts = {relative: (POST / relative).read_text() for relative in before}
new = [
    "crates/quoridor-ai/src/forced_root419_tests.rs",
    "crates/quoridor-runner/src/measurement_loss_leaf.rs",
    "crates/quoridor-runner/src/measurement_loss_leaf_tests.rs",
    "scripts/dev/test_measurement_loss_leaf419.py",
]
for relative in new:
    assert git("ls-tree", BASE, "--", relative) == b"", relative
    texts[relative] = (POST / relative).read_text()


def function(text, name):
    match = re.search(
        r"(?m)^[ \t]*(?:pub(?:\([^)]*\))? )?fn " + re.escape(name) + r"\b", text
    )
    assert match, name
    return body(text, match.start())


def span(text, start, end=None):
    index = text.index(start)
    return index, len(text) if end is None else text.index(end, index)


def functions(text, names):
    result = []
    for name in names:
        match = re.search(
            r"(?m)^[ \t]*(?:pub(?:\([^)]*\))? )?fn " + re.escape(name) + r"\b", text
        )
        if match:
            result.append(
                (match.start(), match.start() + len(body(text, match.start())))
            )
    return result


def inside(start, stop, ranges):
    return start == stop or any(low <= start and stop <= high for low, high in ranges)


alpha = "crates/quoridor-ai/src/alphabeta.rs"
nnue = "crates/quoridor-nnue/src/residual.rs"
measurement = "crates/quoridor-runner/src/measurement.rs"
compare = "crates/quoridor-runner/src/value_search_compare.rs"
protected = {}
for name in [
    "root_depth",
    "child",
    "negamax",
    "negamax_entered",
    "reduced_child",
    "prepared_moves",
    "ordering_scores",
    "safe_race_value",
    "zero_stock_approx_value",
    "pv",
]:
    old = function(before[alpha], name)
    assert old == function(texts[alpha], name), name
    protected["alphabeta::" + name] = hashlib.sha256(old.encode()).hexdigest()
for marker in [
    "impl Table {",
    "impl Key {",
    "impl StaticEvaluator for DistanceEvaluator",
    "impl StaticEvaluator for ResidualEvaluator",
]:
    old = body(before[alpha], before[alpha].index(marker))
    assert old == body(texts[alpha], texts[alpha].index(marker)), marker
    protected[marker] = hashlib.sha256(old.encode()).hexdigest()
old = function(before[nnue], "linear_head_with_scratch_observed")
assert old == function(texts[nnue], "linear_head_with_scratch_observed")
protected["canonical_standardized_linear_head"] = hashlib.sha256(
    old.encode()
).hexdigest()
scratch = body(before[nnue], before[nnue].index("pub struct ResidualScratch"))
assert scratch == body(texts[nnue], texts[nnue].index("pub struct ResidualScratch"))
protected["unchanged_ResidualScratch_storage"] = hashlib.sha256(
    scratch.encode()
).hexdigest()
helper = function(texts[nnue], "value_with_scratch_observed")
helper = helper.replace(
    "fn value_with_scratch_observed(", "pub fn evaluate_with_scratch_observed(", 1
)
helper = helper.replace(
    ") -> Result<ResidualValueView> {", ") -> Result<f32> {", 1
).replace(
    "        Ok(ResidualValueView {\n            baseline_logit: u,\n            linear_residual: r,\n            pre_tanh: value,\n            post_tanh: f64::from(value).tanh() as f32,\n        })",
    "        Ok(f64::from(value).tanh() as f32)",
    1,
)
assert helper == function(before[nnue], "evaluate_with_scratch_observed")
assert re.sub(r"(?m)^ *forced_root: None,\n", "", texts[observer]) == before[observer]
restored = (
    function(texts[compare], "tree")
    .replace(
        "if let Some(v) = tree_terminal(root)",
        "if let Some(v) = root.terminal_value()",
        1,
    )
    .replace("values: [v; 3]", "values: [v * alphabeta::TERMINAL_SCORE; 3]", 1)
    .replace("t.values.map(tree_parent_value)", "t.values.map(|v| -v)", 1)
)
assert restored == function(before[compare], "tree")
protected["old_tree_modulo_exact_terminal_sign_extraction"] = hashlib.sha256(
    restored.encode()
).hexdigest()


def allowed(relative, text, is_post):
    if relative == alpha:
        ranges = functions(
            text, ["search_in_table", "search_forced", "forced_root_depth"]
        )
        ranges.append(span(text, "struct SearchInvocation<'a>", "fn search_in_table<"))
        if is_post:
            ranges.append(
                span(text, '\n#[cfg(test)]\n#[path = "forced_root419_tests.rs"]')
            )
            ranges.append(
                span(
                    text,
                    "    /// Restrict only the parent action.",
                    "    /// Same persistent table and search;",
                )
            )
        return ranges
    if relative == measurement:
        ranges = functions(
            text,
            [
                "validate",
                "root_spec",
                "prepare_roots",
                "load_evaluator",
                "load_residual_model",
                "run",
                "replay",
            ],
        )
        ranges.append(
            span(
                text,
                "struct Settings {",
                "#[derive(Clone, Debug, Deserialize, Serialize)]\n#[serde(deny_unknown_fields)]\nstruct SearchNamespaceSettings",
            )
        )
        # Adjacent loader functions include only their owned separating whitespace.
        ranges.append(span(text, "fn load_evaluator(", "fn drive("))
        if is_post:
            ranges.append(
                span(
                    text,
                    '#[path = "measurement_loss_leaf.rs"]',
                    "#[derive(Clone, Copy, Debug",
                )
            )
        return ranges
    if relative == compare:
        ranges = functions(text, ["tree", "tree_terminal", "tree_parent_value"])
        if is_post:
            ranges.append(span(text, "pub(crate) fn tree_terminal(", "fn tree("))
        return ranges
    if relative == nnue:
        ranges = [
            span(
                text,
                "    pub fn evaluate_with_scratch_observed(",
                "    /// Shared packed-input/guarded head kernel.",
            )
        ]
        if is_post:
            ranges += [
                span(
                    text,
                    "/// Two views of one canonical residual-head computation",
                    "/// Worker-owned input storage.",
                ),
                span(
                    text,
                    "pub struct ResidualScratch",
                    "impl ResidualModel {",
                ),
                span(
                    text,
                    '\n#[cfg(all(test, feature = "research"))]\nmod residual_value419_tests {',
                ),
            ]
        return ranges
    if relative == observer:
        return functions(text, ["search_with_lmr_observation", "lmr_trial"])
    return []


outside = {}
for relative in before:
    if relative == observer:
        outside[relative] = (
            "EXACT after removing only three explicit forced_root None fields"
        )
        continue
    if before[relative] == texts[relative]:
        outside[relative] = "UNCHANGED_WHOLE_FILE"
        continue
    old_ranges = allowed(relative, before[relative], False)
    new_ranges = allowed(relative, texts[relative], True)
    old_lines = before[relative].splitlines(True)
    new_lines = texts[relative].splitlines(True)
    old_offsets = [0, *accumulate(map(len, old_lines))]
    new_offsets = [0, *accumulate(map(len, new_lines))]

    def extended(text, ranges):
        result = []
        for start, stop in ranges:
            low = max(0, text.rfind("\n", 0, start) + 1)
            while low > 0:
                preceding = max(0, text.rfind("\n", 0, low - 1) + 1)
                if text[preceding:low].strip():
                    break
                low = preceding
            high = len(text) if text.find("\n", stop) < 0 else text.find("\n", stop) + 1
            while high < len(text):
                following = text.find("\n", high)
                following = len(text) if following < 0 else following + 1
                if text[high:following].strip():
                    break
                high = following
            result.append((low, high))
        return result

    old_ranges = extended(before[relative], old_ranges)
    new_ranges = extended(texts[relative], new_ranges)
    for op, i, j, a, b in difflib.SequenceMatcher(
        None, old_lines, new_lines, autojunk=False
    ).get_opcodes():
        if op != "equal":
            assert inside(old_offsets[i], old_offsets[j], old_ranges), (
                relative,
                op,
                "before",
                i,
                j,
            )
            assert inside(new_offsets[a], new_offsets[b], new_ranges), (
                relative,
                op,
                "post",
                a,
                b,
            )
    outside[relative] = (
        "CHANGED_BYTES_ONLY_IN_DECLARED_FUNCTION_STRUCT_OR_TEST_INCLUDE_SUBJECTS"
    )

# Reconstruct one temporary full publisher only for AST/lint and strict patch
# proof. Persist only the owned function and sparse patch, never a publisher mirror.
publisher = "scripts/dev/research-lifecycle.py"
whole = git("show", BASE + ":" + publisher).decode()
old_function = (OUT / "before-measurement_config.py.txt").read_text()
fragment = (OUT / "measurement_config.py").read_text().rstrip() + "\n\n\n"
assert whole.count(old_function) == 1
replacement = whole.replace(old_function, fragment, 1)
assert replacement.replace(fragment, old_function, 1) == whole
ast.parse(replacement)
before[publisher] = whole
texts[publisher] = replacement
outside[publisher] = (
    "PREFIX_SUFFIX_BYTES_EXACT; full publisher AST parsed, only measurement_config replaced"
)
(OUT / "before-measurement_config.py.gz").write_bytes(
    gzip.compress(old_function.encode(), mtime=0)
)
changed = [relative for relative in texts if texts[relative] != before.get(relative)]
forward, inverse = [], []
for relative in changed:
    old = before.get(relative, "")
    value = texts[relative]
    forward.extend(
        difflib.unified_diff(
            old.splitlines(True),
            value.splitlines(True),
            fromfile="a/" + relative if relative in before else "/dev/null",
            tofile="b/" + relative,
        )
    )
    inverse.extend(
        difflib.unified_diff(
            value.splitlines(True),
            old.splitlines(True),
            fromfile="a/" + relative,
            tofile="b/" + relative if relative in before else "/dev/null",
        )
    )
(OUT / "forward.patch").write_text("".join(forward))
(OUT / "inverse.patch").write_text("".join(inverse))
with tempfile.TemporaryDirectory(
    prefix="final419-proof-", dir=os.environ["TMPDIR"]
) as directory:
    temp = Path(directory)
    for relative, value in before.items():
        path = temp / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value)
    for patch in ["forward.patch", "inverse.patch"]:
        result = subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "--input", str(OUT / patch)],
            cwd=temp,
            check=True,
            capture_output=True,
            text=True,
        )
        assert "offset" not in result.stdout and "fuzz" not in result.stdout
        if patch == "forward.patch":
            for relative, value in texts.items():
                assert (temp / relative).read_text() == value
            subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "ruff",
                    "check",
                    "--no-cache",
                    "--config",
                    str(ROOT / "pyproject.toml"),
                    str(temp / publisher),
                ],
                check=True,
            )
        else:
            for relative, value in before.items():
                assert (temp / relative).read_text() == value
            for relative in new:
                assert not (temp / relative).exists(), relative
        assert not list(temp.rglob("*.rej"))
        print(patch, "EXACT_FUZZ0_NEW_ABSENCE_RESTORED")

tests = []
for package, feature, relative, prefix in [
    (
        "quoridor-ai",
        "research",
        "crates/quoridor-ai/src/forced_root419_tests.rs",
        "alphabeta::forced_root419_tests::",
    ),
    ("quoridor-nnue", "research", nnue, "residual::residual_value419_tests::"),
    (
        "quoridor-runner",
        "research-diagnostics",
        "crates/quoridor-runner/src/measurement_loss_leaf_tests.rs",
        "measurement::loss_leaf::tests::",
    ),
]:
    names = re.findall(r"#\[test\]\s+fn (\w+)\(", texts[relative])
    if relative == nnue:
        names = [name for name in names if name.startswith("residual419_")]
    for name in names:
        assert name not in before.get(relative, "")
        tests.append(
            {
                "package": package,
                "features": [feature],
                "exact_filter": prefix + name,
                "expected_count": 1,
                "status": "UNBUILT/UNTYPED/UNRUN",
            }
        )
assert len(tests) == 12
verification = {
    "native_new": tests,
    "native_new_total": 12,
    "NN0_new": {
        "path": "scripts/dev/test_measurement_loss_leaf419.py",
        "class": "LossLeaf419Admission",
        "filter": "test_fixed_scope_and_explicit_boolean_refusals_nn0",
        "expected_count": 1,
        "status": "UNRUN",
    },
    "affected_native": [
        {
            "package": "quoridor-nnue",
            "feature": "research",
            "filter": "residual::head_route_observer_test::observed_matches_and_bad_shape_has_no_route",
            "expected_count": 1,
        },
        {
            "package": "quoridor-ai",
            "feature": "research",
            "filter": "alphabeta::persistent_tt_tests::persistent_tt_contract_and_cost",
            "expected_count": 1,
        },
        {
            "package": "quoridor-ai",
            "feature": "research",
            "unique_name_filter": "research_threefold_terminal_bypass_and_reversible_error_cancel",
            "expected_count": 1,
        },
    ],
    "Root_only": "research and research-diagnostics compile; owning new12 + affected3 + NN0one; necessary Clippy and genuine optimized build; no old qualification/successful suites replay",
    "review_boundaries": [
        "forced parent H/child H-1 ply1 fullwindow iterative cumulative budget and parent TT exclusion",
        "complete prefix vs ordered history and canonical make/unmake on errors/cancellation",
        "compact common tree completeness/terminal/sign/numeric signed-zero ties",
        "one canonical head/baseline/residual/pre/post view and OFF noninterference",
        "saved-only interventions must rebackup alternatives; no D oracle",
        "all-stage logical NNUE liability/call/tree/parity upper bounds",
    ],
    "source_checks": {
        "formatter": "PASS before proof; final touched scopes separately checked",
        "protected_body_hashes": protected,
        "outside_subjects": outside,
        "strict_forward_inverse": True,
        "new_absence_restored": new,
        "publisher_AST_and_full_temporary_Ruff_lint": True,
    },
    "native_type_model_Search_science_Astra_review_dispatch": 0,
}
(OUT / "verification-plan.json").write_text(json.dumps(verification, indent=2) + "\n")
subjects = []
for relative in changed:
    old = before.get(relative)
    value = texts[relative]
    subjects.append(
        {
            "relative": relative,
            "before": None
            if old is None
            else {
                "sha256": hashlib.sha256(old.encode()).hexdigest(),
                "bytes": len(old.encode()),
                "mode": "0644",
            },
            "post": {
                "sha256": hashlib.sha256(value.encode()).hexdigest(),
                "bytes": len(value.encode()),
                "mode": "0644",
            },
            "private_post": ref(POST / relative)
            if relative != publisher
            else ref(OUT / "measurement_config.py"),
            "storage": "function-only postimage plus sparse patch"
            if relative == publisher
            else "affected source postimage only",
        }
    )
(OUT / "source-binding.json").write_text(
    json.dumps(
        {
            "issue": "quoridor-4lc.419.2",
            "base_Git": BASE,
            "fixed_spec": ref(HERE / "fixed-spec-binding.json"),
            "component_head_view_immutable": ref(
                HERE / "head-view-proposal-v1/source-binding.json"
            ),
            "subjects": subjects,
            "forward": ref(OUT / "forward.patch"),
            "inverse": ref(OUT / "inverse.patch"),
            "before_gzip_refs": json.loads((OUT / "before-refs.json").read_text())[
                "subjects"
            ],
            "observer_companion_before": ref(OUT / "before" / (observer + ".gz")),
            "publisher_function_before_gzip": ref(
                OUT / "before-measurement_config.py.gz"
            ),
            "verification_plan": ref(OUT / "verification-plan.json"),
            "native_status": "UNBUILT/UNTYPED/UNRUN",
        },
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "changed_subjects": len(subjects),
            "new_native_definitions": len(tests),
            "static_proof": "PASS",
            "native": "UNBUILT/UNTYPED/UNRUN",
        }
    )
)
