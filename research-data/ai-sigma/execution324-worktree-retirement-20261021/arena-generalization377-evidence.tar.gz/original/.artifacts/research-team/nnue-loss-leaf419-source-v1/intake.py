"""419 immutable owning-source intake only; no evaluator/search/test execution."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
OWNER = "codex:01a11004-79f3-7c20-872c-432a2c347664"


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def git(*args):
    return subprocess.run(
        [
            "git",
            "-c",
            "core.packedGitWindowSize=8m",
            "-c",
            "core.packedGitLimit=32m",
            "--no-optional-locks",
            *args,
        ],
        cwd=ROOT,
        check=True,
        capture_output=True,
    ).stdout


def main():
    assert os.getcwd() == str(ROOT)
    assert os.sched_getaffinity(0) == {3}
    status = dict(
        line.split(":", 1)
        for line in Path("/proc/self/status").read_text().splitlines()
        if ":" in line
    )
    assert status["NoNewPrivs"].strip() == "1"
    context = {
        "actual_turn_context_UTC": "2026-10-15T19:52:41.307Z",
        "turn_id": "01a1411f-bb35-7861-93ca-71a6d7b94b65",
        "cwd": str(ROOT),
        "model": "gpt-6.1-sol",
        "effort": "high",
        "sandbox_policy": {"type": "danger-full-access"},
        "approval_policy": "never",
        "verified_before_first_ordinary_command": True,
        "source": "same saved rollout actual turn_context",
        "worker_actual_affinity": [3],
        "NoNewPrivs": 1,
        "current_RSS": status["VmRSS"].strip(),
        "scope": "one source child readback; not continuous family peak/global quiet",
    }
    (HERE / "actual-context.json").write_text(json.dumps(context, indent=2) + "\n")
    records = {}
    for args, name in [
        (("ready", "--json"), "ready"),
        (("show", "quoridor-4lc.419.2", "--json"), "own-before"),
        (("show", "quoridor-4lc.419", "--json"), "parent-contract"),
    ]:
        result = subprocess.run(
            ["bash", "scripts/dev/beads.sh", *args],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        (HERE / (name + ".json")).write_text(result.stdout)
        records[name] = json.loads(result.stdout)
    (own,) = records["own-before"]
    assert own["id"] == "quoridor-4lc.419.2" and own["assignee"] == OWNER
    assert own["status"] in {"open", "in_progress"}
    if own["status"] == "open":
        result = subprocess.run(
            [
                "bash",
                "scripts/dev/beads.sh",
                "update",
                own["id"],
                "--status",
                "in_progress",
                "--json",
            ],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        (HERE / "own-claim.json").write_text(result.stdout)
    base = git("rev-parse", "--verify", "HEAD^{commit}").decode().strip()
    refs = []
    paths = [
        "crates/quoridor-runner/src/value_search_compare.rs",
        "crates/quoridor-runner/src/bin/nnue-diagnose.rs",
        "crates/quoridor-runner/src/measurement.rs",
        "crates/quoridor-ai/src/alphabeta.rs",
        "crates/quoridor-ai/src/lmr_observation.rs",
        "crates/quoridor-runner/src/teacher_pilot_execution.rs",
    ]
    for relative in paths:
        raw = git("show", base + ":" + relative)
        assert len(raw) <= 1024 * 1024
        text = raw.decode()
        functions = [
            {"name": m[1], "line": text.count("\n", 0, m.start()) + 1}
            for m in re.finditer(
                r"(?m)^\s*(?:pub(?:\([^)]*\))? )?(?:async )?fn (\w+)", text
            )
        ]
        entry = {
            "relative": relative,
            "Git": base,
            "blob_oid": git("rev-parse", base + ":" + relative).decode().strip(),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "mode": "0644",
            "functions": functions,
        }
        refs.append(entry)
        print("NAMED_OWNER", json.dumps(entry))
        if relative.endswith("value_search_compare.rs") or relative.endswith(
            "nnue-diagnose.rs"
        ):
            print("OWNER_HEADER", relative, "\n" + "\n".join(text.splitlines()[:140]))
        else:
            print("IMPORTS", relative, "\n" + "\n".join(text.splitlines()[:38]))
    (HERE / "intake-refs.json").write_text(
        json.dumps(
            {
                "issue": own["id"],
                "owner": OWNER,
                "base_Git": base,
                "context": ref(HERE / "actual-context.json"),
                "sources": refs,
                "phase": "BOUNDED_INTAKE; final419.1 spec/input pending; no science/adoption",
                "source_read_UTC": datetime.now(timezone.utc).isoformat(),
            },
            indent=2,
        )
        + "\n"
    )
    for record in records["parent-contract"]:
        print("PARENT_CONTRACT", record.get("description", ""), record.get("notes", ""))
    print(
        json.dumps(
            {
                "owner": own["assignee"],
                "status": "in_progress",
                "base_Git": base,
                "scope": "six named immutable owners only; no persistent whole-source copy",
                "Astra_invocations": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
