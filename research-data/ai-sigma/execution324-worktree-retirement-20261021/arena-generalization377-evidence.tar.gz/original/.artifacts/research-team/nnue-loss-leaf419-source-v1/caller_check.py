"""Resolve only references affected by the changed private invocation field."""

import json
from intake import HERE, git
from read_owners import body

base = json.loads((HERE / "intake-refs.json").read_text())["base_Git"]
for pattern in ["SearchInvocation {", ".root_depth("]:
    print(
        git("grep", "-n", "-F", pattern, base, "--", "crates/quoridor-ai/src").decode()
    )
text = git("show", base + ":crates/quoridor-core/src/research.rs").decode()
for name in ["pub fn from_prefix_with_rules", "pub fn make_move", "pub fn unmake_move"]:
    start = text.index(name)
    print(body(text, start))
