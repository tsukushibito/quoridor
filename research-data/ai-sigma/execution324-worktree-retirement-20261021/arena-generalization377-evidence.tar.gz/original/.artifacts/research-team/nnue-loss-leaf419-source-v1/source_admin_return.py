"""Verify the returned final metadata/formatter originals before the single delivery."""

from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path

from intake import HERE, ROOT, ref

loader = importlib.util.spec_from_file_location(
    "lc419_admin_return", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
path = HERE / "source-packet-freeze-v1/result.json"
data = json.loads(path.read_text())
assert (
    data["status"] == "PASS"
    and not data["TMP_remaining"]
    and not (path.parent / "TMP").exists()
)
identities = [data["controller"]]
receipts = []
for check in data["checks"]:
    disk = json.loads(Path(check["persisted_process_receipt"]["path"]).read_text())
    returned = check["guardian_return"]
    facts = disk if returned is None else returned
    assert (
        facts["direct_child_reaped"]
        and facts["cleanup_complete"]
        and facts["handle_closes_complete"]
        and not facts["remaining"]
    )
    identities.append(facts["child"])
    receipts.append(
        {
            "name": check["name"],
            "returned_NULL": returned is None,
            "persisted": check["persisted_process_receipt"],
            "fullcapture": check["full_log"],
            "directwait_reap": True,
            "handles_closed": True,
        }
    )
fresh = []
for old in identities:
    current = lc.process.identity(lc.process.process_info(old["pid"]))
    assert current is None or current != old
    fresh.append({"original": old, "fresh": current})
record = {
    "phase": "SOURCE_FINAL_METADATA_RETURN_STOP",
    "observed_UTC": datetime.now(timezone.utc).isoformat(),
    "source_STOP": ref(HERE / "source-v1/source-STOP.json"),
    "original_final_metadata_guard": ref(path),
    "fresh_returned_original_identities": fresh,
    "receipts": receipts,
    "readers": [],
    "source_writers": [],
    "children": [],
    "jobs": [],
    "handles": [],
    "TMP": [],
    "leases": [],
    "owned": [],
    "scope": "returned original source-freeze/report/formatter/controller identities; this short current admin closes before the subsequent notification-only child",
    "final_source_deliveries_before_notification": 0,
}
stop = HERE / "source-v1/source-admin-STOP.json"
assert not stop.exists()
stop.write_text(json.dumps(record, indent=2) + "\n")
body = HERE / "source-v1/handoff-ja.md"
with body.open("a") as file:
    file.write(
        "\n最終metadata/formatterも元identity freshabsent/different、返却/directreap/handles/TMPgoneを確認しました。\n\n```json\n"
        + json.dumps({"source_admin_STOP": ref(stop)}, indent=2)
        + "\n```\n"
    )
print(json.dumps({"STOP": ref(stop), "owned": [], "notification_only_next": True}))
