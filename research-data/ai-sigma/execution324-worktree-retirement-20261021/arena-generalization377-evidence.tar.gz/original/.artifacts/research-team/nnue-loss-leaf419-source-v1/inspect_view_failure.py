"""Inspect only the exact private text discrepancy; do not rerun a suite."""

import difflib
import gzip

from intake import HERE
from read_owners import body

out = HERE / "head-view-proposal-v1"
before = gzip.decompress((out / "before.rs.gz").read_bytes()).decode()
post = (out / "residual.rs").read_text()
original = body(before, before.index("    pub fn evaluate_with_scratch_observed("))
stripped = post[: post.index('\n#[cfg(all(test, feature = "research"))]')]
start = stripped.index("/// Two views of one canonical residual-head computation")
stop = stripped.index("/// Worker-owned input storage.", start)
stripped = stripped[:start] + stripped[stop:]
start = stripped.index("    pub fn evaluate_with_scratch_observed(")
helper_start = stripped.index("    fn value_with_scratch_observed(")
stop = helper_start + len(body(stripped, helper_start))
stripped = stripped[:start] + original + stripped[stop:]
print(
    "".join(difflib.unified_diff(before.splitlines(True), stripped.splitlines(True)))[
        :5000
    ]
)
