"""Stop this bounded pre-spec phase, retaining all original process facts."""

from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path

import intake


def main():
    here = intake.HERE
    loader = importlib.util.spec_from_file_location(
        "lc419_intake_stop", intake.ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    phases = []
    children = []
    controllers = []
    for name in [
        "intake-v1",
        "owners-v1",
        "head-v1",
        "head-view-v1",
        "preparation-v1",
        "dependency-v1",
    ]:
        path = here / name / "result.json"
        data = json.loads(path.read_text())
        assert data["status"] == "PASS" and not (path.parent / "TMP").exists()
        phases.append(intake.ref(path))
        c = data.get("controller")
        if c:
            fresh = lc.process.identity(lc.process.process_info(c["pid"]))
            assert fresh is None or fresh != c
            controllers.append({"phase": name, "identity": c, "fresh": fresh})
        else:
            controllers.append(
                {
                    "phase": name,
                    "identity": "UNKNOWN; not recorded",
                    "tool_returned": True,
                }
            )
        for check in data["checks"]:
            disk_ref = check["persisted_process_receipt"]
            assert intake.ref(Path(disk_ref["path"])) == disk_ref
            disk = json.loads(Path(disk_ref["path"]).read_text())
            returned = check["guardian_return"]
            facts = returned if returned is not None else disk
            assert facts["direct_child_reaped"] and facts["handle_closes_complete"]
            assert facts["cleanup_complete"] and not facts["remaining"]
            fresh = lc.process.identity(lc.process.process_info(facts["child"]["pid"]))
            assert fresh is None or fresh != facts["child"]
            children.append(
                {
                    "phase": name,
                    "name": check["name"],
                    "identity": facts["child"],
                    "fresh": fresh,
                    "directreap": True,
                    "handles_closed": True,
                    "cleanup_complete": True,
                    "returned_NULL": returned is None,
                    "returned_mask": None
                    if returned is None
                    else returned.get("signal_mask_restoration"),
                    "returned_persist": None
                    if returned is None
                    else returned.get("final_record_persist"),
                    "disk_mask": disk.get("signal_mask_restoration"),
                    "disk_persist": disk.get("final_record_persist"),
                    "fullcapture": check["full_log"],
                    "receipt": disk_ref,
                    "child_wall_seconds_once": facts["wall_seconds"],
                }
            )
    record = {
        "issue": "quoridor-4lc.419.2",
        "stage": "BOUNDED_PRE_SPEC_INTAKE_STOP; NOT final implementation handoff",
        "actual_STOP": datetime.now(timezone.utc).isoformat(),
        "phases": phases,
        "controllers": controllers,
        "children": children,
        "source_base_Git": json.loads((here / "intake-refs.json").read_text())[
            "base_Git"
        ],
        "inlet_report": intake.ref(here / "inlet-cost-ja.md"),
        "source_refs": intake.ref(here / "intake-refs.json"),
        "dependency_observed": intake.ref(here / "dependency419.1.json"),
        "dependency": "419.1 fixed spec and exact input FileRefs not received",
        "no_new_horizon_tree_intervention_choice": True,
        "implementation_patch": "NOT_STARTED",
        "native_Search_model_tests_science_Astra_review_dispatch": 0,
        "readers": [],
        "source_writers": [],
        "children_remaining": [],
        "jobs": [],
        "handles": [],
        "TMP": [],
        "leases": [],
        "owned": [],
        "usage": "one final directed OWN usage deferred until implementation source completion; no advance reserve/global walk",
        "leaf": "same claimant in_progress; Root324 accepts/closes/backs up",
    }
    (here / "intake-STOP.json").write_text(json.dumps(record, indent=2) + "\n")
    root = subprocess_show_recipient(here)
    refs = {
        "inlet_report": intake.ref(here / "inlet-cost-ja.md"),
        "intake_STOP": intake.ref(here / "intake-STOP.json"),
        "source_refs": intake.ref(here / "intake-refs.json"),
        "head_owner": intake.ref(here / "observed-head-ref.json"),
    }
    text = f"""# 419.2 bounded inlet checkpoint — not final source handoff

419.2本人claim/in_progress、Sol6.1/high/cwdMain/fullnever actualcontext確認済み。immutable Git{record["source_base_Git"]}のnamed ownersだけを限定intakeし、実STOP {record["actual_STOP"]}、readers/children/jobs/TMP/leases/owned[]。Astra/新session/review/native/model/Search/test/science0、Main/Git/index/Cargo/managedproduction writes0です。

技術facts: 既存355 common-tree/forcedには3engines/旧model/TT4096/上限とnested whole responsesが固定され、その設定の419流用は不可。現measurement loaderのResidualEvaluator/fingerprint・完全prefix replayとcommon kernelを再用する。417 observer/APIは現役で保持し、419へcopyせず共通Invocationへ薄く接続する。

正本ResidualModelのobserved callbackはfast/avx2 boolだけ。pre-tanh logitは公開されないため、post値のatanh推定や別formulaを使わず、canonical headからpre/postを一度に得る最小view接続が必要です。通常OFFにhead二重実行/clone/scan/clockを加えない。full/delta照合は既存primitiveだけ、旧qualification再演なし。TT origin不明はUNKNOWN、Dはoracleにしない。

419.1は同SolMaxでin_progress、固定spec/input refsはこのleafへまだ未着です。source/API・horizon・木/介入単位を勝手に固定せず、現hook/費用factsを止まった境界で先に共有します。これは最終fixed source packetではなく、その配送はまだ0回。固定specと入力が届けば同leafで通常実装を続け、Root/人間ACKやparentcloseは要求しません。実装/新assertion定義は未開始、source-only静的整形/lint以外のPASS主張なし。最終OWN usage walkは源泉実装終了時の一度へ残します。Beads受入れ/backup/closeは324、paused scopeは不変。

```json
{json.dumps(refs, ensure_ascii=False, indent=2)}
```
"""
    (here / "inlet-checkpoint-handoff-ja.md").write_text(text)
    print(
        json.dumps(
            {
                "STOP": refs["intake_STOP"],
                "recipient": root,
                "owned": [],
                "pending": "fixed419.1 spec/input only",
            }
        )
    )


def subprocess_show_recipient(here):
    import subprocess

    result = subprocess.run(
        ["bash", "scripts/dev/beads.sh", "show", "quoridor-4lc.324", "--json"],
        cwd=intake.ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    (here / "recipient324.json").write_text(result.stdout)
    (record,) = json.loads(result.stdout)
    assert record["assignee"] == "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
    return record["assignee"]


if __name__ == "__main__":
    main()
