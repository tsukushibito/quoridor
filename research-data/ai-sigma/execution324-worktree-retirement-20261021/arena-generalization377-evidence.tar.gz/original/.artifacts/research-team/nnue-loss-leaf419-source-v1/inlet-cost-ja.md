# 419.2：既存hookの限定intake／実装可能性

対象immutable Gitは `61d783d1882bb02e8617cdbe42c1fce24cda8e9b`。419.2を本人claimしてin_progressです。最初の通常command前に保存turn_contextのgpt-6.1-sol/high/cwdMain/danger-full-access/approval neverを確認しました。Main／managed production／Git index／Cargo／モデル／native Search／科学／テストは変更・実行していません。Astra・追加session・再帰委譲・review dispatchは0です。

**本記録はspec前の限定準備です。419.1の固定specと入力FileRefsはまだこのleafへ届いておらず、horizon、候補unionを定める観測、木／介入単位、source APIは確定していません。** 人間再承認や別parent closeを求める状態ではありません。これらが到着すれば同leafで実装を続けます。旧417 packetも現役417 observerも変更しません。

## 再用できる正本と必要差分

`measurement.rs::load_evaluator` は、固定Dの正確な既存namespace＋models空の場合だけD(0,8)を返し、NNUEはdescriptorから`ResidualModel`をloadして実fingerprintを照合します。BEST43 fresh353はこの`ResidualEvaluator`経路を使うべきで、plain `NnueEvaluator`や旧比較の3engine設定へ置換しません。Control/PVS/TT1M、LMR/Cheap/approx/safe OFFは明示設定でき、研究標準・製品・generator defaultを変える必要はありません。

`measurement.rs::replay` は`from_prefix`→`validate_normal`、synthetic／terminal拒否、rules／totalply／期待fullhistory照合を所有しています。419も完全な時系列prefixを同入口で再生し、原RAW行・board・side・stock・親identityに束縛する形が使えます。盤面JSONやopeningだけのcountsを完全履歴へ読み替えたり、`from_counts`で代用しません。

旧`value_search_compare.rs::tree` はterminal-first、同じ合法手展開、同葉で複数評価器、辺ごとの一度の符号反転を持ちます。ただし現bodyには3評価器、局所100k／全800k visits／2400k評価、再帰した全responses JSONが固定されています。419へそのまま呼べません。必要な共通木処理の狭い共用と、2評価器・全300k visits・compact記録への対応が必要です。旧固定355のplan／book128／モデル／上限／出力枠を新入口の前提へ移しません。全nodeへfullhistoryやfeatureをコピーする表現は避け、Root prefixと経路で再構成できる情報と、specが必要とする保存値だけに絞る必要があります。実RSS／保存量／所要時間は未測定UNKNOWNです。

同旧callerのforced処理はparent horizon6→合法childのSearch depth5、返値を一度だけnegateしています。この深さの一控除自体を誤りとは呼びません。ただしchildを別rootとしてSearchしており、419で必要なparent/nonroot ply・full-window・iterative capの意味を明記する必要があります。旧sessionはCoverage/TT4096で、call上限・namespace・モデルも固定です。これを419の実設定として使うことはできません。

現`alphabeta.rs`の`SearchInvocation`と通常iterative-deepeningは、child/PVS、terminal/history、make/undo、enter/control、復元、TT、evaluator scratchの共通所有者です。維持417は、その同kernelへcaptured pathと非root plyを渡せる実例です。ただし417 APIはLMR depth_rank ON、D5/d3/ply2、100K、N/R診断専用の資格を持ちます。419へ資格を緩めて流用せず、必要なforced-root制約を同じ既存kernelへ薄く接続します。別negamax／Search loop／417 observerコピーは不要と見ています。実際の最小signature・current consumer変更範囲は固定specに合わせて決めます。

## NNUEの値・入力・parity

canonical `ResidualModel::evaluate_with_scratch_observed` は、正本head `linear_head_with_scratch_observed` のresidual、正本distance baseline、有限logit検査、f64 tanh→f32の順です。標準化distance入力はhead正本の `(distance-mu)/sigma` にあります。baselineのbが0であっても、この入力を消してよいとはなりません。

既存observed callbackはfast-range判定とAVX2 availabilityの **二つのboolだけ** で、raw logitや入力値を返しません。linear-head helperもpub(crate)です。従ってpre-tanhをpost値のatanhから推測せず、同じcanonical計算からpre/post値を一度に得る小さな診断viewが必要です。同じmath bodyへ最小の共有returnを設ける候補なら、別formula/evaluatorやheadの二重実行は不要です。新API／view fieldsはまだ固定していません。通常OFFに入力clone／head再計算／scan／毎node clockを足しません。

`nnue-diagnose.rs::qualify_residual` にはfull/delta、Scalar/Simd、canonical make/unmake、特徴／accumulator／親のexact復元、値誤差の部品があります。**既存qualification全体や旧成功suiteは実行しません。** 必要なprimitive照合だけを、specで指定された実追跡状態の最大256へ結びます。FT/head物理呼出しと論理評価回数は別で、NNUEの全経路を一つの共有論理counterで会計する必要があります。prepare/deltaだけでhead実行済みとは数えません。

NNUE Search側の24M node由来上限、木／parityを含む25M論理評価、Search48 calls各1M／全48M、木300k visitsは別の制約です。実counterとcap/error/取消／未入場／仕事量UNKNOWNを残し、上限を実使用へ置換しません。head viewやparityの追加評価も同じ全体counterへ含める必要があります。作者からforward／model load／nativeは発行しません。

## 起源・数学・残る具体依存

common treeのterminal leaf／static horizon leafは自分の正本評価に由来すると記録できます。通常Search結果・PVの末端をstatic NN値へ読み替えません。現TTの数値起源が追えない範囲はUNKNOWNです。full TT snapshotや新trace基盤を必要条件へ足さず、specが要求する最小path／対抗手／leaf参照を使います。Dも深いSearchもoracleではありません。

必要なのは、419.1から来る固定親の完全prefix+RAW refs、二horizon、unionの呼出し共有規則、共通木の正確な展開単位／保存単位／cap時の扱い、事前固定のbackup介入と同点規則です。現在はこれらを独自に決めず、実装・新fixture定義／exact filtersはPENDINGとします。sourceから原因／速度／強さ／WDLや採用を認定しません。

現source guardはCPU3と別physical guardian7、family RSS512MiB（`CycleResources.check`はcontroller＋owned childrenを合算）、GPU0、host reserve4GiB、no_new_privs、bounded fullcapture/directwait/reapを使っています。実topology／available affinity／selected pinned peerの瞬間観測とworker readbackを保存しました。Go/NodeへAS512は掛けません。guarded source childrenは各正常境界で終了しTMPを解消、idle canonical/hardware leaseはありません。controllerの記録がない以前のtoolはPIDをUNKNOWNとして扱い、架空のabsenceを作りません。

凍結417/418／旧RAW／FAILED／費UNKNOWNと、mixed/learner全prep-pipeline／323 USERPAUSE、models/weights/seals/oldfits96／foreign変更／製品generator defaultsは不変です。本人leafはin_progressを維持し、受入れ／backup／closeは324。普通sourceに事前storage枠は作らず、本人usageの一度のwalkは最終source終了時へ残します。
