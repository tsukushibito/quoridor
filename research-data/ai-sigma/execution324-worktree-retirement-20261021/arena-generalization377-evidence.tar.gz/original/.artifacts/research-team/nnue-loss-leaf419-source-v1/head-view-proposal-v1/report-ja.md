# 419.2 canonical head view — 独立ready部分の私有checkpoint

これは最終419 source handoffではない。419.1の固定specに依存しないpre/post-tanh viewだけを実装案と3つのfixture定義へまとめた。Main・managed production・Git/index・Cargoの変更、native/type/test/model/forward/Search/science、Astra、新session、review dispatchは0。419.2は同claimantのin_progressを維持し、受入れ・backup・closeは324が行う。

## 計算の正本

対象はimmutable Git `61d783d1882bb02e8617cdbe42c1fce24cda8e9b` の `crates/quoridor-nnue/src/residual.rs`。beforeはSHA256 `99f5acd09eec12aa78142d62973e16fa8e0dcb377c26e6deca731897c519dabd`、38066B、0644。

research専用の `evaluate_view_with_scratch` が `ResidualValueView { pre_tanh, post_tanh }` を返す。非公開の一つのownerが既存linear headを一度呼び、元と同じ順序でdistance logit、residualとの和、finite検査、f64 tanhからf32への変換を行う。通常の既存評価は同じownerのpost値を返す。`evaluate_with_scratch_observed` の `FnOnce(bool, bool)` は変更しない。atanh推定・別formula・一般traceは導入しない。

head本体の標準化distance入力、scratch幅・accumulator検査、SIMD/fallback、算術はbyte exact。通常OFFにhead再実行・heap確保・clone・scan・clockを加えない。viewの二つのf32の受渡しに伴う実ABI・stack・copy・最適化・時間は未測定でUNKNOWN。既存scratch生成・モデルsetup・FT/距離取得は既存ownerのまま。このviewを419のleaf/feature/parity記録へ接続する範囲は固定spec後に同じ私有差分で整理する。

## 定義と静的確認

新fixtureはresearch featureの `residual::residual_value419_tests` に3定義。小さな明示weightで標準化distanceと既知dyadic logit 1.25、head callback一度、scratch再利用、親不変を扱う。飽和時も有限pre-logitを保持し、既存post値のbitsを扱う。最後の定義はshape/finite拒否と元のnonfinite combined-logitエラーを扱う。旧head implementationのコピーや旧qualification一式は追加しない。

RustfmtとhelperのRuff format/lintは実行した。strict forward→inverseを標準patchのfuzz0、offsetなしで私有一時directory上に適用し、before/post全bytesを照合した。新定義の元absence、head本体、元のfinite検査と算術の復元、変更subject以外のbytesが一致した。fixture・Rust型・出力bitsの実行確認はしていない。全3定義は **UNBUILT/UNTYPED/UNRUN**。Root用の正確なfilters/countsと既存owning影響1件は `verification.json` に記録した。Rootは最終419 sourceの必要softwareへ一度含める。

初回static proofは既存research test moduleにも一致する広い区切りを使い、変更外byte照合でFAILEDとなった。`view-format-proof-v1` の原結果・capture・費・NULL/保存maskを残した。差分inspectionでhelperの抽出範囲だけの問題と判明し、新module名を含む一意のselectorへ修正した。production案は変更せず `view-proof-correction-v1` のproofがPASSした。失敗を成功へ書換えていない。

## 境界

source CPU3・guardian7、family512MiB inclusive controller、GPU0、host reserve4GiBの既存guardを使った。各入場でaffinity/distinct physical topology/利用可能RAM/選択coreの限定peerを確認し、child no_new_privs・fullcapture・directwait/reap・handles・TMPcleanupを記録した。全host静穏や連続peak/RSS、LLM資源は証明していない。canonical/Main/hardware leaseは取得していない。

`source-binding.json` がbefore gzip・post・thin forward/inverse・protected hash・verificationを束縛する。`../view-STOP.json` は今回phaseの原成功/失敗を保った実child/controller fresh identity、returned-vs-persisted receipt、directreap/handles/TMP境界を記録する。

親/horizon/候補union/forced API/共通木/介入単位は未固定で、419.1の実specへ合わせる。今回のcheckpointをsource_clear・最終handoff・数値資格にしない。最終source packetの配送はまだ0回。新たなRoot問い合わせ・周期wake・設計者bootstrapは行わない。最終source終了時の一度のaffected usageにまとめ、今回の中間checkpointでglobal/asset/target walkや旧費の再加算は行わない。全pause/default/model/sealと原RAW/FAILED/費/UNKNOWNは保持する。
