"""Prepare only the canonical head-view proposal; no evaluation or test execution."""

import gzip
import hashlib
import json

from intake import HERE, git, ref
from read_owners import body

OUT = HERE / "head-view-proposal-v1"
OUT.mkdir()
base = json.loads((HERE / "intake-refs.json").read_text())["base_Git"]
relative = "crates/quoridor-nnue/src/residual.rs"
raw = git("show", base + ":" + relative)
assert (
    hashlib.sha256(raw).hexdigest()
    == "99f5acd09eec12aa78142d62973e16fa8e0dcb377c26e6deca731897c519dabd"
)
before = raw.decode()
before_path = OUT / "before.rs.gz"
before_path.write_bytes(gzip.compress(raw, mtime=0))
anchor = "/// Worker-owned input storage. Models and accumulators remain borrowed."
view = """/// Two views of one canonical residual-head computation, in STM perspective.
/// `pre_tanh` is the finite combined distance-plus-residual logit; `post_tanh`
/// is the existing f64-tanh-to-f32 output, including saturation.
#[derive(Debug, Clone, Copy)]
pub struct ResidualValueView {
    pub pre_tanh: f32,
    pub post_tanh: f32,
}

"""
assert before.count(anchor) == 1
post = before.replace(anchor, view + anchor)
start = post.index("    pub fn evaluate_with_scratch_observed(")
old = body(post, start)
marker = "        let r = self.linear_head_with_scratch_observed(a, scratch, observe)?;"
assert old.count(marker) == 1
helper = old.replace(
    "pub fn evaluate_with_scratch_observed(", "fn value_with_scratch_observed(", 1
)
helper = helper.replace(
    ") -> Result<f32> {", ") -> Result<ResidualValueView> {", 1
).replace(
    "        Ok(f64::from(value).tanh() as f32)",
    "        Ok(ResidualValueView {\n            pre_tanh: value,\n            post_tanh: f64::from(value).tanh() as f32,\n        })",
    1,
)
replacement = (
    """    pub fn evaluate_with_scratch_observed(
        &self,
        a: &Accumulator,
        scratch: &mut ResidualScratch,
        observe: impl FnOnce(bool, bool),
    ) -> Result<f32> {
        Ok(self.value_with_scratch_observed(a, scratch, observe)?.post_tanh)
    }

    /// Research view of the same head, without another head evaluation or tanh inversion.
    #[cfg(feature = "research")]
    pub fn evaluate_view_with_scratch(
        &self,
        a: &Accumulator,
        scratch: &mut ResidualScratch,
    ) -> Result<ResidualValueView> {
        self.value_with_scratch_observed(a, scratch, |_, _| {})
    }

"""
    + helper
)
post = post[:start] + replacement + post[start + len(old) :]
post += "\n" + (HERE / "view_tests.rs").read_text()
(OUT / "residual.rs").write_text(post)
(OUT / "initial-binding.json").write_text(
    json.dumps(
        {
            "phase": "PRIVATE_SPEC_INDEPENDENT_VIEW_ONLY_NOT_FINAL419_SOURCE",
            "base_Git": base,
            "relative": relative,
            "before_sha256": hashlib.sha256(raw).hexdigest(),
            "before_gzip": ref(before_path),
            "tests_native": "UNBUILT/UNTYPED/UNRUN",
            "research_view": "evaluate_view_with_scratch -> ResidualValueView { pre_tanh, post_tanh }",
            "callback": "evaluate_with_scratch_observed FnOnce(bool,bool) unchanged",
            "spec_dependent_forced_tree_horizon_intervention": "NOT_IMPLEMENTED",
        },
        indent=2,
    )
    + "\n"
)
print("PRIVATE_HEAD_VIEW_PREPARED")
