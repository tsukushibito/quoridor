"""Read only the current observed residual head and its exact caller inlets."""

import hashlib
import json
import re

import intake
from read_owners import body


def main():
    here = intake.HERE
    base = json.loads((here / "intake-refs.json").read_text())["base_Git"]
    relative = "crates/quoridor-nnue/src/residual.rs"
    raw = intake.git("show", base + ":" + relative)
    text = raw.decode()
    parts = []
    for name in ["evaluate_with_scratch_observed", "linear_head_with_scratch_observed"]:
        m = re.search(r"(?m)^\s*(?:pub(?:\([^)]*\))? )?fn " + name + r"\b", text)
        assert m, name
        part = body(text, m.start())
        print("OBSERVED_HEAD", name, "\n" + part)
        parts.append(part)
    path = here / "selected/residual-observed-head.txt"
    path.write_text("\n\n".join(parts) + "\n")
    refs = {
        "relative": relative,
        "Git": base,
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": "0644",
        "selected": intake.ref(path),
    }
    (here / "observed-head-ref.json").write_text(json.dumps(refs, indent=2) + "\n")


if __name__ == "__main__":
    main()
