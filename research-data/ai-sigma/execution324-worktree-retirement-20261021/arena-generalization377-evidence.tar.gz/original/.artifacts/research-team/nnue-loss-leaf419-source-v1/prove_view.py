"""Exact private patch reconstruction, protected bytes and fixture definitions only."""

import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

from intake import HERE, ref
from read_owners import body

out = HERE / "head-view-proposal-v1"
before = gzip.decompress((out / "before.rs.gz").read_bytes()).decode()
post = (out / "residual.rs").read_text()
relative = "crates/quoridor-nnue/src/residual.rs"
names = [
    "residual419_view_normalized_distance_one_head_and_parent_unchanged",
    "residual419_view_retains_finite_saturated_logit_and_output_bits",
    "residual419_view_preserves_validation_and_nonfinite_logit_refusal",
]
for name in names:
    assert name not in before and post.count("fn " + name + "(") == 1
assert post.count("mod residual_value419_tests {") == 1
assert len(re.findall(r"#\[test\]", post)) == len(re.findall(r"#\[test\]", before)) + 3
start = before.index("    pub fn evaluate_with_scratch_observed(")
original = body(before, start)
helper_start = post.index("    fn value_with_scratch_observed(")
helper = body(post, helper_start)
assert helper.count("self.linear_head_with_scratch_observed(a, scratch, observe)?") == 1
restored_helper = helper.replace(
    "fn value_with_scratch_observed(", "pub fn evaluate_with_scratch_observed(", 1
)
restored_helper = restored_helper.replace(
    ") -> Result<ResidualValueView> {", ") -> Result<f32> {", 1
).replace(
    "        Ok(ResidualValueView {\n            pre_tanh: value,\n            post_tanh: f64::from(value).tanh() as f32,\n        })",
    "        Ok(f64::from(value).tanh() as f32)",
    1,
)
assert restored_helper == original, "canonical arithmetic/finite check changed"
head = "    pub(crate) fn linear_head_with_scratch_observed("
protected_head = body(before, before.index(head))
assert body(post, post.index(head)) == protected_head
protected_callback = "observe: impl FnOnce(bool, bool)"
assert protected_callback in original and protected_callback in helper
stripped = post[
    : post.index(
        '\n#[cfg(all(test, feature = "research"))]\nmod residual_value419_tests {'
    )
]
struct_start = stripped.index(
    "/// Two views of one canonical residual-head computation"
)
struct_end = stripped.index("/// Worker-owned input storage.", struct_start)
stripped = stripped[:struct_start] + stripped[struct_end:]
wrapper_start = stripped.index("    pub fn evaluate_with_scratch_observed(")
helper_start = stripped.index("    fn value_with_scratch_observed(")
helper_end = helper_start + len(body(stripped, helper_start))
stripped = stripped[:wrapper_start] + original + stripped[helper_end:]
assert stripped == before, "bytes outside the exact view subjects changed"
for label, source, target, fromfile, tofile in [
    ("forward.patch", before, post, "a/" + relative, "b/" + relative),
    ("inverse.patch", post, before, "a/" + relative, "b/" + relative),
]:
    (out / label).write_text(
        "".join(
            difflib.unified_diff(
                source.splitlines(keepends=True),
                target.splitlines(keepends=True),
                fromfile=fromfile,
                tofile=tofile,
            )
        )
    )
with tempfile.TemporaryDirectory(
    prefix="view-roundtrip-", dir=os.environ["TMPDIR"]
) as directory:
    path = Path(directory) / relative
    path.parent.mkdir(parents=True)
    path.write_text(before)
    for patch, expected in [("forward.patch", post), ("inverse.patch", before)]:
        result = subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "--input", str(out / patch)],
            cwd=directory,
            check=True,
            capture_output=True,
            text=True,
        )
        assert "offset" not in result.stdout and "fuzz" not in result.stdout
        assert path.read_text() == expected
        assert not list(Path(directory).rglob("*.rej"))
        print(result.stdout.strip())
verification = {
    "phase": "SPEC_INDEPENDENT_PRIVATE_HEAD_VIEW_ONLY_NOT_FINAL_SOURCE_HANDOFF",
    "status": "STATIC_PASS; native UNBUILT/UNTYPED/UNRUN",
    "package": "quoridor-nnue",
    "required_features": ["research"],
    "new_definitions": [
        {
            "filter": "residual::residual_value419_tests::" + name,
            "exact": True,
            "expected_count": 1,
        }
        for name in names
    ],
    "new_total": 3,
    "genuinely_affected_existing": [
        {
            "filter": "residual::head_route_observer_test::observed_matches_and_bad_shape_has_no_route",
            "exact_filter_status": "enclosing module verified in pinned postimage",
            "expected_count": 1,
        }
    ],
    "Root_native_plan": "necessary research compile/Clippy/new3 plus the owning observed-head assertion once after final419 source; no old full qualification replay",
    "not_typechecked": True,
    "no_evaluator_model_test_execution": True,
    "proof": {
        "forward_inverse_exact_fuzz0": True,
        "all_outside_subject_bytes_equal": True,
        "canonical_arithmetic_finite_check_restored_exact": True,
        "head_standardized_inputs_SIMD_validation_body_exact": True,
        "head_calls_per_view_owner": 1,
        "new_test_names_absent_before": True,
    },
}
(out / "verification.json").write_text(json.dumps(verification, indent=2) + "\n")
(out / "source-binding.json").write_text(
    json.dumps(
        {
            "base_Git": json.loads((out / "initial-binding.json").read_text())[
                "base_Git"
            ],
            "relative": relative,
            "before": {
                "sha256": hashlib.sha256(before.encode()).hexdigest(),
                "bytes": len(before.encode()),
                "mode": "0644",
            },
            "before_gzip": ref(out / "before.rs.gz"),
            "post": ref(out / "residual.rs"),
            "forward": ref(out / "forward.patch"),
            "inverse": ref(out / "inverse.patch"),
            "protected_head_sha256": hashlib.sha256(
                protected_head.encode()
            ).hexdigest(),
            "verification": ref(out / "verification.json"),
            "source_status": "PRIVATE_INTERIM_NOT_FINAL419_CLEAR",
            "Main_managedproduction_Git_index_Cargo_native_model_Search_tests_science": 0,
        },
        indent=2,
    )
    + "\n"
)
print(json.dumps({"proof": verification["proof"], "new_definitions": names}))
