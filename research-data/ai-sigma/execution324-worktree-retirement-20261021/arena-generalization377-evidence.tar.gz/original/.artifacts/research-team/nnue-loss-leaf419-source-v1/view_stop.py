"""Collect the returned head-view phase receipts without changing their facts."""

from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path

from intake import HERE, ROOT, ref

loader = importlib.util.spec_from_file_location(
    "lc419_view_stop", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
phases = []
controllers = []
children = []
for name in [
    "view-intake-v1",
    "view-fixture-intake-v1",
    "view-build-v1",
    "view-format-proof-v1",
    "view-discrepancy-v1",
    "view-proof-correction-v1",
]:
    path = HERE / name / "result.json"
    data = json.loads(path.read_text())
    assert data["status"] == ("FAILED" if name == "view-format-proof-v1" else "PASS")
    assert not data["TMP_remaining"] and not (path.parent / "TMP").exists()
    identity = data["controller"]
    fresh = lc.process.identity(lc.process.process_info(identity["pid"]))
    assert fresh is None or fresh != identity
    controllers.append({"phase": name, "original": identity, "fresh": fresh})
    phases.append(ref(path))
    for check in data["checks"]:
        receipt = check["persisted_process_receipt"]
        assert ref(Path(receipt["path"])) == receipt
        disk = json.loads(Path(receipt["path"]).read_text())
        returned = check["guardian_return"]
        facts = disk if returned is None else returned
        assert facts["direct_child_reaped"] and facts["handle_closes_complete"]
        assert facts["cleanup_complete"] and not facts["remaining"]
        fresh = lc.process.identity(lc.process.process_info(facts["child"]["pid"]))
        assert fresh is None or fresh != facts["child"]
        children.append(
            {
                "phase": name,
                "command": check["name"],
                "original": facts["child"],
                "fresh": fresh,
                "directreap": facts["direct_child_reaped"],
                "handles_closed": facts["handle_closes_complete"],
                "cleanup_complete": facts["cleanup_complete"],
                "remaining": facts["remaining"],
                "returned_NULL": returned is None,
                "returned_mask": None
                if returned is None
                else returned.get("signal_mask_restoration"),
                "returned_persist": None
                if returned is None
                else returned.get("final_record_persist"),
                "disk_mask": disk.get("signal_mask_restoration"),
                "disk_persist": disk.get("final_record_persist"),
                "receipt": receipt,
                "fullcapture": check["full_log"],
                "child_wall_seconds_once": facts["wall_seconds"],
            }
        )
record = {
    "issue": "quoridor-4lc.419.2",
    "phase": "SPEC_INDEPENDENT_VIEW_STOP_NOT_FINAL419_HANDOFF",
    "source_reader_STOP": "2026-10-15T20:10:59.428706+00:00",
    "fresh_observed_UTC": datetime.now(timezone.utc).isoformat(),
    "phases": phases,
    "controllers": controllers,
    "children": children,
    "source_binding": ref(HERE / "head-view-proposal-v1/source-binding.json"),
    "report": ref(HERE / "head-view-proposal-v1/report-ja.md"),
    "verification": ref(HERE / "head-view-proposal-v1/verification.json"),
    "initial_intake_STOP_unchanged": ref(HERE / "intake-STOP.json"),
    "native_type_tests_model_forward_Search_science_Astra_review_dispatch": 0,
    "final419_source_handoffs": 0,
    "readers": [],
    "source_writers": [],
    "children_remaining": [],
    "jobs": [],
    "handles": [],
    "TMP": [],
    "leases": [],
    "owned": [],
    "scope": "all returned source/format/proof children above; current private metadata recorder is transient and its enclosing guard return is recorded separately",
    "usage": "one directed final419 affected usage still deferred; no advance reserve or global walk",
    "leaf": "same claimant in_progress; Root324 acceptance/backup/close",
    "dependency": "fixed419.1 spec and exact inputs; no Root ACK query/poll/wake",
}
(HERE / "view-STOP.json").write_text(json.dumps(record, indent=2) + "\n")
print(
    json.dumps(
        {
            "STOP": ref(HERE / "view-STOP.json"),
            "source_owned": [],
            "status": "STATIC_VIEW_ONLY",
        }
    )
)
