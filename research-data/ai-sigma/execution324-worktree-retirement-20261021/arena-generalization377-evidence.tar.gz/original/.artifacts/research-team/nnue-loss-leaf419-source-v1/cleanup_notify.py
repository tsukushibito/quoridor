"""Remove only the returned helper's verified-unheld zero-byte OWN uv lock."""

from datetime import datetime, timezone
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import stat

import intake

here = intake.HERE
loader = importlib.util.spec_from_file_location(
    "lc419_inlet_cleanup", intake.ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
original = intake.ref(here / "inlet-notify-v1/result.json")
result = json.loads((here / "inlet-notify-v1/result.json").read_text())
assert result["status"] == "PASS" and len(result["checks"]) == 1
check = result["checks"][0]
facts = check["guardian_return"]
assert facts["direct_child_reaped"] and facts["handle_closes_complete"]
assert facts["cleanup_complete"] and not facts["remaining"]
fresh = lc.process.identity(lc.process.process_info(facts["child"]["pid"]))
assert fresh is None or fresh != facts["child"]
tmp = here / "inlet-notify-v1/TMP"
assert len(result["TMP_remaining"]) == 1
path = Path(result["TMP_remaining"][0])
assert path.parent == tmp and path.name == "uv-cc8f3ad7aa19080a.lock"
before = path.lstat()
assert stat.S_ISREG(before.st_mode) and before.st_size == 0
fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC)
try:
    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    opened = os.fstat(fd)
    assert (opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino)
    assert path.lstat().st_ino == opened.st_ino
    path.unlink()
finally:
    os.close(fd)
tmp.rmdir()
receipt = json.loads(Path(check["full_log"]["path"]).read_text())
assert (
    receipt["accepted"] is True
    and receipt["thread_id"] == "01a1376a-bfd3-75d2-bd64-61e9416b3b13"
)
cleanup = {
    "cleanup_STOP": datetime.now(timezone.utc).isoformat(),
    "original_delivery_result": original,
    "original_returned_TMP_remaining_preserved": result["TMP_remaining"],
    "original_child": facts["child"],
    "original_child_fresh": fresh,
    "directreap_handles_complete": True,
    "zero_byte_regular_file_unheld_EX_NB_then_unlinked": str(path),
    "TMP_absent": not tmp.exists(),
    "RPC_original_capture": check["full_log"],
    "RPC_accepted_receipt": receipt,
    "RPC_attempts": 1,
    "resend_retry_refinalization": 0,
    "owned": [],
}
(here / "inlet-notify-cleanup.json").write_text(json.dumps(cleanup, indent=2) + "\n")
print(
    json.dumps(
        {
            "delivery": receipt,
            "cleanup": intake.ref(here / "inlet-notify-cleanup.json"),
            "owned": [],
        }
    )
)
