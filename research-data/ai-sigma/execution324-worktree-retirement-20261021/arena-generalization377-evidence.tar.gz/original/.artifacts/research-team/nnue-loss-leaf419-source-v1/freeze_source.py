"""Freeze this source-only packet and stopped process facts, without native execution."""

from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess

from intake import HERE, ROOT, ref
from read_owners import body

out = HERE / "source-v1"
loader = importlib.util.spec_from_file_location(
    "lc419_source_stop", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
binding_path = out / "source-binding.json"
binding = json.loads(binding_path.read_text())
changed = {entry["relative"] for entry in binding["subjects"]}
binding["before_gzip_refs"] = [
    {"relative": entry["relative"], "before_gzip": entry["before_gzip"]}
    for entry in binding["before_gzip_refs"]
    if entry["relative"] in changed
]
for entry in binding["subjects"]:
    assert ref(Path(entry["private_post"]["path"])) == entry["private_post"]
for key in [
    "forward",
    "inverse",
    "verification_plan",
    "observer_companion_before",
    "publisher_function_before_gzip",
    "fixed_spec",
    "component_head_view_immutable",
]:
    reference = binding[key]
    assert ref(Path(reference["path"])) == reference, key

owners = {
    "crates/quoridor-ai/src/alphabeta.rs": [
        "forced_root_depth",
        "search_forced",
        "search_in_table",
        "root_depth",
    ],
    "crates/quoridor-nnue/src/residual.rs": [
        "evaluate_with_scratch_observed",
        "value_with_scratch_observed",
        "evaluate_view_with_scratch",
        "input_view",
        "linear_head_with_scratch_observed",
    ],
    "crates/quoridor-runner/src/measurement.rs": [
        "validate",
        "root_spec",
        "prepare_roots",
        "replay",
        "load_evaluator",
        "load_residual_model",
        "run",
    ],
    "crates/quoridor-runner/src/value_search_compare.rs": [
        "tree",
        "tree_terminal",
        "tree_parent_value",
    ],
}
subjects = []


def digest(text):
    return {
        "sha256": hashlib.sha256(text.encode()).hexdigest(),
        "bytes": len(text.encode()),
    }


for relative, names in owners.items():
    old = gzip.decompress((out / "before" / (relative + ".gz")).read_bytes()).decode()
    new = (out / "post" / relative).read_text()
    for name in names:
        values = []
        for text in [old, new]:
            match = re.search(
                r"(?m)^[ \t]*(?:pub(?:\([^)]*\))? )?fn " + re.escape(name) + r"\b", text
            )
            values.append(None if match is None else digest(body(text, match.start())))
        subjects.append(
            {
                "relative": relative,
                "function": name,
                "before": values[0],
                "post": values[1],
                "unchanged": values[0] == values[1],
            }
        )
subject_map = {
    "functions": subjects,
    "other_owned_subjects": {
        "SearchInvocation": "forced_root field plus root constructor default None",
        "lmr_observation.rs": "three forced_root None fields only; whole-file reverse byte proof",
        "ResidualValueView": "research value views from canonical math; concrete scalar fields",
        "ResidualScratch": "storage byte exact; input_view is immutable research borrow",
        "measurement::Settings": "defaultfalse loss_leaf_419 only",
        "research-lifecycle.py": "measurement_config function only",
    },
    "420_sparse_composition": "NNUE loader, prepare/replay and run function subjects overlap; do not overwrite a whole measurement/runtime file; 419 rejects any nonselected evaluator/model/input before its numerical entry",
}
(out / "function-subject-map.json").write_text(json.dumps(subject_map, indent=2) + "\n")
binding["function_subject_map"] = ref(out / "function-subject-map.json")
binding["report"] = ref(out / "report-ja.md")
binding["ordinary_defaults_product_generator_models_weights_and_scientific_inputs"] = (
    "UNCHANGED"
)
binding["420_wait_or_scientific_mix"] = False
binding_path.write_text(json.dumps(binding, indent=2) + "\n")

phases = []
controllers = []
children = []
failed = {
    "caller-check-v1",
    "source-proof-v1",
    "source-proof-separator-v1",
    "source-proof-final-v1",
}
names = [
    "spec-intake-v1",
    "source-setup-v1",
    "core-edit-v1",
    "input-api-v1",
    "measurement-edit-v1",
    "caller-check-v1",
    "caller-check-correction-v1",
    "tighten-source-v1",
    "source-format-v1",
    "source-proof-v1",
    "source-proof-separator-v1",
    "source-proof-final-v1",
    "source-roundtrip-v1",
    "source-final-boundary-v1",
    "source-freeze-proof-v1",
]
for name in names:
    path = HERE / name / "result.json"
    data = json.loads(path.read_text())
    assert data["status"] == ("FAILED" if name in failed else "PASS"), name
    assert not data["TMP_remaining"] and not (path.parent / "TMP").exists()
    identity = data["controller"]
    fresh = lc.process.identity(lc.process.process_info(identity["pid"]))
    assert fresh is None or fresh != identity
    controllers.append({"phase": name, "original": identity, "fresh": fresh})
    phases.append(ref(path))
    for check in data["checks"]:
        receipt = check["persisted_process_receipt"]
        assert ref(Path(receipt["path"])) == receipt
        disk = json.loads(Path(receipt["path"]).read_text())
        returned = check["guardian_return"]
        facts = disk if returned is None else returned
        assert facts["direct_child_reaped"] and facts["handle_closes_complete"]
        assert facts["cleanup_complete"] and not facts["remaining"]
        fresh = lc.process.identity(lc.process.process_info(facts["child"]["pid"]))
        assert fresh is None or fresh != facts["child"]
        children.append(
            {
                "phase": name,
                "command": check["name"],
                "original": facts["child"],
                "fresh": fresh,
                "directwait_reap": facts["direct_child_reaped"],
                "handles_closed": facts["handle_closes_complete"],
                "cleanup_complete": facts["cleanup_complete"],
                "returned_NULL": returned is None,
                "returned_mask": None
                if returned is None
                else returned.get("signal_mask_restoration"),
                "returned_persist": None
                if returned is None
                else returned.get("final_record_persist"),
                "disk_mask": disk.get("signal_mask_restoration"),
                "disk_persist": disk.get("final_record_persist"),
                "receipt": receipt,
                "fullcapture": check["full_log"],
                "child_wall_seconds_once": facts["wall_seconds"],
            }
        )

for issue, name in [
    ("quoridor-4lc.419.2", "own-source-stop"),
    ("quoridor-4lc.324", "current-recipient"),
]:
    result = subprocess.run(
        ["bash", "scripts/dev/beads.sh", "show", issue, "--json"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    (out / (name + ".json")).write_text(result.stdout)
    (record,) = json.loads(result.stdout)
    expected = (
        "codex:01a11004-79f3-7c20-872c-432a2c347664"
        if issue.endswith("419.2")
        else "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13"
    )
    assert record["assignee"] == expected
    if issue.endswith("419.2"):
        assert record["status"] == "in_progress"

# One directed affected walk for this whole419 author scope, including failed
# controls/captures and before/post artifacts. No links/assets/target traversal.
logical = allocated = files = directories = 0
links = []
stack = [HERE]
while stack:
    directory = stack.pop()
    directories += 1
    for entry in os.scandir(directory):
        stat = entry.stat(follow_symlinks=False)
        if entry.is_symlink():
            links.append(str(Path(entry.path).relative_to(HERE)))
            logical += stat.st_size
            allocated += stat.st_blocks * 512
        elif entry.is_dir(follow_symlinks=False):
            stack.append(Path(entry.path))
        else:
            files += 1
            logical += stat.st_size
            allocated += stat.st_blocks * 512
usage = {
    "measured_UTC": datetime.now(timezone.utc).isoformat(),
    "path": str(HERE),
    "logical_B": logical,
    "allocated_file_B": allocated,
    "files": files,
    "directories": directories,
    "symlinks_not_followed": links,
    "scope": "one actual affected OWN walk, including original failures/captures; directory allocation not included",
    "later_small_admin_excluded": "this usage record, STOP/completion/handoff, notification receipts and their tiny cleanup metadata",
    "advance_storage_budget": None,
    "global_actual": "UNKNOWN",
    "decimal_global_cap_B": 50_000_000_000,
    "previous_covered_49328115712B": "historical conservative coverage, not actual global usage or new permanent charge/refund",
}
(out / "usage.json").write_text(json.dumps(usage, indent=2) + "\n")
stop = {
    "issue": "quoridor-4lc.419.2",
    "phase": "FROZEN_SOURCE_ONLY",
    "source_reader_writer_STOP": "2026-10-15T20:49:42.780325+00:00",
    "fresh_process_verification_UTC": datetime.now(timezone.utc).isoformat(),
    "source_binding": ref(binding_path),
    "report": ref(out / "report-ja.md"),
    "verification_plan": ref(out / "verification-plan.json"),
    "phases": phases,
    "controllers": controllers,
    "children": children,
    "preserved_prior_intake_STOP": ref(HERE / "intake-STOP.json"),
    "preserved_head_view_STOP": ref(HERE / "view-STOP.json"),
    "unknown_scope": "initial unrecorded controllers/NULL-vs-persisted facts remain as in original STOPs; no invented identities/peaks",
    "readers": [],
    "source_writers": [],
    "children_remaining": [],
    "jobs": [],
    "handles": [],
    "TMP": [],
    "leases": [],
    "owned": [],
    "current_metadata_recorder": "transient private admin excluded from stopped source identities; enclosing return/fresh closure saved separately after directwait",
    "native_status": "UNBUILT/UNTYPED/UNRUN",
    "native_Search_forward_model_tests_science_Astra_recursive_dispatch": 0,
    "Main_managedproduction_Git_index_Cargo_Beads_status_writes": 0,
    "usage": ref(out / "usage.json"),
    "leaf": "same claimant in_progress; Root324 verification/acceptance/backup/close",
}
(out / "source-STOP.json").write_text(json.dumps(stop, indent=2) + "\n")
refs = {
    "binding": ref(binding_path),
    "STOP": ref(out / "source-STOP.json"),
    "forward": ref(out / "forward.patch"),
    "inverse": ref(out / "inverse.patch"),
    "report": ref(out / "report-ja.md"),
    "subjects": ref(out / "function-subject-map.json"),
    "verification": ref(out / "verification-plan.json"),
    "usage": ref(out / "usage.json"),
}
(out / "completion.json").write_text(
    json.dumps(
        {
            "issue": "quoridor-4lc.419.2",
            "source_only": True,
            "refs": refs,
            "native_new_definitions": 12,
            "NN0_new_definitions": 1,
            "native_status": "UNBUILT/UNTYPED/UNRUN",
            "source_clear": "PENDING_DISTINCT419.3; initial spec view not implementation clear",
            "final_source_notifications_before_this_packet": 0,
            "Root_ack_required": False,
        },
        indent=2,
    )
    + "\n"
)
refs["completion"] = ref(out / "completion.json")
message = f"""# 419.2 frozen source-only handoff

固定spec51935438/inputsb26fb4d5、base61d783d1882bb02e8617cdbe42c1fce24cda8e9bの一累積patchです。Main/managedproduction/Git/index/Cargo/native/model/Search/tests/science/Astra/reviewdispatch0。同claimant/in_progressを保持し、Root324が受入れ/backup/closeします。最終source配送は今回一度だけ、独立head checkpointを別に重ねて適用しないでください。

forcedはcommon Invocation/反復深化/child、H−1/ply1/fullwindow/累積1M、制限親通常TTなし。通常root_depth/child/PVS/TT/Key/evaluator/410411数学body exact。N/D fresh factory・固定3完全prefixのboard/ordered/fullhistory照合、H3完成anchorだけの一C、最大48/48M・N24・木300k・全logicalNN25Mを実コードで制御。H2/H3共通compact木・signedzero numeric tie・保存最大30介入の全応手rebackup・限定parity・canonical一head baseline/residual/pre/post/input viewを準備しました。通常OFFの追加head/clone/scan/clockなし。simd=falseは既存FT flagでheadのguarded routingは変更しません。

static Rustfmt/Ruff/一時完全publisher AST+lint/strict fuzz0 forward+inverse/新4file absence/subject外byte/保護body proof PASS。新AI4+NNUE3+runner5=12とPythonNN0oneはUNBUILT/UNTYPED/UNRUN。必要Root software/限定419.3 source判定は未実行です。新entryは既存measurement config loss_leaf_419=true、3selectorsと12normal schedule slots（全Search分母48は別census）。420交点はfunction-subject-mapに明記し、whole measurement/runtime overwrite不可・Sigma科学混入0です。

元FAILED/NULL-vs-disk/captures/masks/費UNKNOWNを保持。source actualSTOP20:49:42.780325Z、元source/format/proof IDs freshabsent/different/directwait/reap/handles/TMPgone/owned[]、canonical/hardwareleases0。最終小adminの返却境界はsource-admin-STOP.jsonへ別保存します。対象usage一回はlogical {logical}B / allocated_file {allocated}B、globalactualUNKNOWN・decimal50GB保持。全pause/default/models/seals/旧RAW不変。Main/typed source/software/science clearへ昇格せず、ACKや420 completionを通常工程gateにしません。

```json
{json.dumps(refs, ensure_ascii=False, indent=2)}
```
"""
(out / "handoff-ja.md").write_text(message)
print(
    json.dumps(
        {
            "completion": refs["completion"],
            "STOP": refs["STOP"],
            "usage": usage,
            "owned_source": [],
        }
    )
)
