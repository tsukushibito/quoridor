"""Named immutable source/functions only; retain frozen411 components."""

import ast
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
BASE = "9908347e8cb8a9204572b5840c3e63d6197bc7a9"
SOURCE411 = HERE.parent / "zero-stock-safe-race411-v1"


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def git(rel):
    run = subprocess.run(
        ["git", "--no-optional-locks", "show", BASE + ":" + rel],
        cwd="/workspaces/quoridor",
        check=True,
        capture_output=True,
    )
    return run.stdout.decode()


refs = []
for rel in [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-runner/src/measurement.rs",
    "measurement_config.py",
]:
    before = SOURCE411 / "post" / rel
    data = before.read_bytes()
    binding = json.loads((SOURCE411 / "source-binding.json").read_text())
    selected = next(row for row in binding["scope"] if row["relative"] == rel)
    assert ref(before) == selected["post"]
    dest = HERE / "before" / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    refs.append({"relative": rel, "component411": ref(before), "before": ref(dest)})
    text = data.decode()
    if rel.endswith("alphabeta.rs"):
        for token in ["pub enum LmrMethod", "lmr_method: LmrMethod::", "lmr: false"]:
            for i, line in enumerate(text.splitlines()):
                if token in line:
                    print(
                        rel, i + 1, "\n".join(text.splitlines()[max(0, i - 2) : i + 11])
                    )

for rel, names in {
    "crates/quoridor-runner/src/runtime.rs": ["arena_lmr_method", "run_game"],
    "scripts/dev/research-lifecycle.py": ["arena_observation"],
}.items():
    text = git(rel)
    if rel.endswith(".py"):
        tree = ast.parse(text)
        functions = [
            node
            for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name in names
        ]
        assert len(functions) == 1
        for node in functions:
            part = "".join(text.splitlines(True)[node.lineno - 1 : node.end_lineno])
            path = HERE / "before" / (node.name + ".py")
            path.write_text(part + "\n")
            refs.append(
                {
                    "relative": rel,
                    "git": BASE + ":" + rel,
                    "full_sha256": hashlib.sha256(text.encode()).hexdigest(),
                    "function": node.name,
                    "before": ref(path),
                }
            )
    else:
        # Only the existing method selector and observation expression are needed.
        start = text.index("pub(crate) fn arena_lmr_method(")
        end = text.index("\n}", start) + 2
        part = text[start:end]
        path = HERE / "before/arena_lmr_method.rs"
        path.write_text(part + "\n")
        print(part)
        line = next(
            line for line in text.splitlines() if '"requested_lmr_method":' in line
        )
        (HERE / "before/runtime_requested_lmr_method.rs").write_text(line + "\n")
        refs.append(
            {
                "relative": rel,
                "git": BASE + ":" + rel,
                "full_sha256": hashlib.sha256(text.encode()).hexdigest(),
                "function_before": ref(path),
                "expression_before": ref(
                    HERE / "before/runtime_requested_lmr_method.rs"
                ),
            }
        )
        print(line)
(HERE / "intake-binding.json").write_text(
    json.dumps(
        {
            "main_base": BASE,
            "prospective_components": "accepted Main410 + frozen411 source-binding dbf3a737 (not yet native qualified)",
            "components": refs,
        },
        indent=2,
    )
    + "\n"
)
print("Minimal prospective before subjects copied;411 remains immutable")
