"""Keep existing fixed-one controls explicit, migrate generic default assertions."""

import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
counts = {}


def migrate(rel, edits):
    text = (
        (HERE / "post" / rel).read_text()
        if (HERE / "post" / rel).exists()
        else (HERE / "before" / rel).read_text()
    )
    for old, new, expected in edits:
        assert text.count(old) == expected, (rel, old, text.count(old))
        text = text.replace(old, new)
    dest = HERE / "post" / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text)
    counts[rel] = [(old, n) for old, _, n in edits]


rel = "crates/quoridor-ai/src/lmr400_tests.rs"
text = (HERE / "before" / rel).read_text()
text = text.replace("ends_with(LMR_METHOD)", "ends_with(LmrMethod::default().id())")
text, n = re.subn(
    r"(?m)^([ \t]*)s\.lmr = (true|enabled);$",
    lambda m: m[1] + "s.stats.lmr_method = LmrMethod::FixedOne;\n" + m[0],
    text,
)
assert n == 6
(HERE / "post" / rel).write_text(text)
counts[rel] = {
    "generic_default_suffix": 3,
    "explicit_fixed_one_toy_state_selections": 6,
    "toy_algorithm_assertions": "unchanged",
}
migrate(
    "crates/quoridor-ai/src/search_settings403_tests.rs",
    [
        ("LmrMethod::FixedOne", "LmrMethod::default()", 3),
        ('format!(":{LMR_METHOD}")', 'format!(":{}", LmrMethod::default().id())', 1),
        (
            'format!("newteacher:signed-control-goal-first:{LMR_METHOD}")',
            'format!("newteacher:signed-control-goal-first:{}", LmrMethod::default().id())',
            1,
        ),
    ],
)
for name, n in [("zero_stock406_tests.rs", 2), ("zero_stock407_tests.rs", 1)]:
    migrate(
        "crates/quoridor-ai/src/" + name,
        [("contains(LMR_METHOD)", "contains(LmrMethod::default().id())", n)],
    )
migrate(
    "crates/quoridor-runner/src/runtime_lmr400_tests.rs",
    [
        (
            'format!(":{}", alphabeta::LMR_METHOD)',
            'format!(":{}", alphabeta::LmrMethod::default().id())',
            1,
        )
    ],
)
migrate(
    "crates/quoridor-runner/src/measurement.rs",
    [("ends_with(alphabeta::LMR_METHOD)", "ends_with(LmrMethod::default().id())", 1)],
)
(HERE / "fixture-migrations.json").write_text(json.dumps(counts, indent=2) + "\n")
print(
    "Only existing default assertions and explicit old fixed-one fixture choices migrated; no execution"
)
