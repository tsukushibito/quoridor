"""One normal412 delivery and its exact stopped metadata, no source replay."""

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def prepare(lc):
    actual = ref(HERE / "source-STOP.json")
    assert (
        actual["sha256"]
        == "4514667c7d712d9ec4f2bbdedc3d2b9e240fb98c490122493d41d5bec395994d"
        and actual["bytes"] == 51612
        and actual["mode"] == "0644"
    )
    stop = json.loads((HERE / "source-STOP.json").read_text())
    binding = ref(HERE / "source-binding.json")
    assert (
        binding["sha256"]
        == "43bbf98f7741b495cd245e2b4736fc34bacfeea23f13796e5e00fd6e566fdfb8"
        and binding["bytes"] == 20263
    )
    controller = stop["source_controller"]["identity"]
    fresh = lc.process.identity(lc.process.process_info(controller["pid"]))
    assert fresh is None or fresh != controller
    (HERE / "handoff-controller-census.json").write_text(
        json.dumps(
            {
                "observed_UTC": datetime.now(timezone.utc).isoformat(),
                "original_source_controller": controller,
                "fresh_identity": fresh,
                "source_tool_return": "original quality-v2 exec returned exit0; not a fabricated guardian return",
                "owned_source": [],
            },
            indent=2,
        )
        + "\n"
    )
    selected = {
        name: value
        for name, value in stop["refs"].items()
        if name
        in {
            "source-binding.json",
            "source-report.md",
            "verification-plan.json",
            "guide-fragment.md",
            "lmr-standard412.patch",
            "lmr-standard412.inverse.patch",
        }
    }
    body = (
        """quoridor-4lc.412.1 ONE frozen source handoff. SAME gpt-6.1-sol/high/cwdMain/fullnever actual turn_context verified. Author Main/managedproduction/Git/index/Cargo/Beads/native/test/Search/model/Perf/game/solver/science/reviewdispatch0.
Human selected normal future research LMR ON/depth_rank, not population strength proof. Existing live comparison_conditions resolves omitted lmr_values=(True,) and lmr_method=depth_rank into explicit variants; existing apply_comparison_cost/arena propagate actual fields. This is the ONE existing research preparation owner, no registry/preset/shim/namespace copier. Explicit OFF/fixed_one controls kept. Raw measurement/Engine enable omission and product/generator remain OFF; typed method omission becomes AI DepthRank only. Runtime selector/requested metadata and Python measurement/arena omission correspond mechanically. Null/type/unknown/refusal owner semantics unchanged.
Prospective base actualMain9908347 + own frozen411 source-binding dbf3a737/sourceSTOPe738ebee.411 postimages unchanged. Thin patches only; no full oldAlpha/runtime/publisher overwrite. Root ordinary411 repairs may sparse-compose. No guessed N/Build. Main412 adoption/affected software AFTER actual411timingSTOP;412 arena still genuine408 image with both methods explicit, no rebuild/replay of frozen subjects.
Source/Rustfmt/Ruff/strict forward+inverse fuzzzero PASS. Alpha byte-exact after reversing only default attr/constructor selector/newtest decl, all LMR table/protection/PVS/history/411/410 algorithms unchanged. Runtime outside2 subjects and publisher outside5 existing functions byte exact. NewRust3 (AI1+measurement1+runtime1) +Python2 UNBUILT/UNTYPED/UNRUN. Generic default assertions migrated; old fixed-one toy states6 explicitly pinned, no old math/success suite replay. Exact new and necessary affected selections/counts in verification-plan.
Existing method.prepare may initialize old4096cell OnceLock once on default-selected setter even OFF; no new table/pernode log, real setup/RSS cost UNKNOWN, whole must include it. Guide fragment inserts normal standard in existing ai-research-code only. Oldhistorical source/results and existing D/D SHA examples preserved.
Original no-match Gitgrep FAILED and helper Ruff failure retained (returnedNULL/capturefalse/disk pending-attempted), repaired scoped static checks only. Exact guarded child identities fresh absent/different/directwait/reap/handles/TMPgone; nested synchronous Git/patch separate PID/start unrecorded=UNKNOWN not invented. Sourcecontroller now fresh absent/different; readers/children/jobs/TMP/leases/owned[]. Directed OWN allocated1765376B once, storageNone/globalactualUNKNOWN/decimal50GB. Beads/backup/close324 only, leafinprogress pendingcanonical acceptance; allmixedlearnerALLprep-pipeline/323pause/models/defaultproductgeneratorOFF/weights/seals/oldfits96/foreign/oldRAWFAILEDfeesUNKNOWN held.
OWN: """
        + str(HERE)
        + "\nSourceSTOP "
        + json.dumps(actual)
        + "\nExact packet refs "
        + json.dumps(selected, ensure_ascii=False)
        + "\nNo ACK/science/reviewer dispatch requested.\n"
    )
    (HERE / "handoff.txt").write_text(body)
    print(
        json.dumps(
            {
                "verified_source_STOP": actual,
                "binding": binding,
                "source_controller_fresh": fresh,
                "owned": [],
            }
        )
    )


def finish(lc, here):
    directory = HERE / "send-v1"
    result = json.loads((directory / "result.json").read_text())
    assert result["status"] == "PASS"
    census = []
    for check in result["checks"]:
        returned = check["guardian_return"]
        assert returned is not None
        lc.settled(returned)
        child = returned["child"]
        fresh = lc.process.identity(lc.process.process_info(child["pid"]))
        assert fresh is None or fresh != child
        census.append(
            {
                "name": check["name"],
                "child": child,
                "fresh_identity": fresh,
                "settled_return": returned,
                "full_log": check["full_log"],
                "disk_receipt": check["persisted_process_receipt"],
            }
        )
    tmp = directory / "TMP"
    if tmp.exists():
        for path in tmp.iterdir():
            assert (
                path.name == "uv-cc8f3ad7aa19080a.lock"
                and path.is_file()
                and not path.is_symlink()
            )
            path.unlink()
        tmp.rmdir()
    fact = {
        "actual_admin_STOP": datetime.now(timezone.utc).isoformat(),
        "source_STOP": ref(HERE / "source-STOP.json"),
        "delivery_result": ref(directory / "result.json"),
        "receipt": ref(directory / "send-once.full.log"),
        "fresh_delivery_census": census,
        "source_controller": json.loads(
            (HERE / "handoff-controller-census.json").read_text()
        ),
        "readers": [],
        "source_writers": [],
        "children": [],
        "jobs": [],
        "handles": [],
        "TMP": [],
        "leases": [],
        "owned": [],
        "scope": "light metadata epilogue controller exits after final write; tool return remains separate",
        "usage": "once in sourceSTOP; later tiny admin excluded",
        "Beads_backup_close": "324 only; no parent/own close or extra science",
    }
    (HERE / "admin-STOP.json").write_text(json.dumps(fact, indent=2) + "\n")
    print(json.dumps({"admin_STOP": ref(HERE / "admin-STOP.json"), "owned": []}))


if __name__ == "__main__":
    loader = importlib.util.spec_from_file_location(
        "lmr412_send_lc", "/workspaces/quoridor/scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(lc)
    prepare(lc)
