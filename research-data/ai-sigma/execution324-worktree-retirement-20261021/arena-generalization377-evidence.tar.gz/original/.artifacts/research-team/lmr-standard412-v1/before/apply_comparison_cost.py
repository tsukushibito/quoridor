def apply_comparison_cost(config, common, variant):
    config["tt_entries"] = common["tt_entries"]
    config["use_tt"] = common["use_tt"]
    config["use_pvs"] = common["use_pvs"]
    config["namespace"]["rules"] = common["rules"]
    config["profile"] = variant["profile"]
    config["lmr"] = variant["lmr"]

