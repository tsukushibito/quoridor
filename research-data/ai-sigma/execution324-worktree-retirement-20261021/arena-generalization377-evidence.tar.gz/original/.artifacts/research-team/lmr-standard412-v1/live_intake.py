"""Minimum live preparation configuration and guide owner, not old recipes."""

import ast
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
BASE = "9908347e8cb8a9204572b5840c3e63d6197bc7a9"
for rel in [
    "configs/arena/README.md",
    "configs/arena/distance-control-100ms.json",
    "configs/arena/distance-control-500ms.json",
    "docs/development/ai-research-code.md",
]:
    text = subprocess.run(
        ["git", "--no-optional-locks", "show", BASE + ":" + rel],
        cwd="/workspaces/quoridor",
        check=True,
        capture_output=True,
    ).stdout.decode()
    print(rel)
    print(text)
    if rel.startswith("configs/"):
        path = HERE / "before" / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
rel = "scripts/dev/research-lifecycle.py"
text = subprocess.run(
    ["git", "--no-optional-locks", "show", BASE + ":" + rel],
    cwd="/workspaces/quoridor",
    check=True,
    capture_output=True,
).stdout.decode()
for node in ast.parse(text).body:
    if isinstance(node, ast.FunctionDef) and (
        "condition" in node.name or "setting" in node.name
    ):
        print(node.name, node.lineno)
        if node.name in {
            "research_condition",
            "configured_condition",
            "study_condition",
            "measure_condition",
        }:
            print("".join(text.splitlines(True)[node.lineno - 1 : node.end_lineno]))
