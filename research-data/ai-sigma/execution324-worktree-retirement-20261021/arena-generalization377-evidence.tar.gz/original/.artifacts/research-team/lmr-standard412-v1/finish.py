"""Stopped412 source scope; existing guardian receipts are never upgraded."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil


def freeze(lc, here):
    def ref(path):
        data = path.read_bytes()
        return {
            "path": str(path),
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
            "mode": f"{path.stat().st_mode & 0o777:04o}",
        }

    affinity = os.sched_getaffinity(0)
    os.sched_setaffinity(0, {3})
    try:
        phases = []
        census = []
        failures = []
        for result_file in sorted(here.glob("*-v*/result.json")):
            record = json.loads(result_file.read_text())
            phase = result_file.parent.name
            phases.append(ref(result_file))
            if record["status"] != "PASS":
                failures.append(
                    {
                        "phase": phase,
                        "status": record["status"],
                        "primary": record["primary"],
                        "ref": ref(result_file),
                    }
                )
                assert phase in {"python-tests-intake-v1", "quality-v1"}
            for check in record["checks"]:
                disk = json.loads(
                    Path(check["persisted_process_receipt"]["path"]).read_text()
                )
                returned = check["guardian_return"]
                if returned is not None:
                    lc.settled(returned)
                    assert check["capture_complete"]
                else:
                    assert check["status"] == "FAILED"
                    assert (
                        disk["direct_child_reaped"]
                        and disk["cleanup_complete"]
                        and disk["handle_closes_complete"]
                        and disk["remaining"] == []
                    )
                facts = returned if returned is not None else disk
                child = facts["child"]
                fresh = lc.process.identity(lc.process.process_info(child["pid"]))
                assert fresh is None or fresh != child
                census.append(
                    {
                        "phase": phase,
                        "name": check["name"],
                        "status": check["status"],
                        "child": child,
                        "fresh_identity": fresh,
                        "capture_complete_reported": check["capture_complete"],
                        "full_log": check["full_log"],
                        "disk_receipt": check["persisted_process_receipt"],
                        "no_new_privs": facts["launch_policy"],
                        "returned_scope": "NULL remains UNKNOWN"
                        if returned is None
                        else "original settled return/directwait/reap/handles/cleanup",
                        "returned_mask": None
                        if returned is None
                        else returned["signal_mask_restoration"],
                        "returned_persist": None
                        if returned is None
                        else returned["final_record_persist"],
                        "disk_mask": disk.get("signal_mask_restoration"),
                        "disk_persist": disk.get("final_record_persist"),
                        "original_seconds_once_nested_excluded": facts["wall_seconds"],
                    }
                )
            tmp = result_file.parent / "TMP"
            if tmp.exists():
                for path in tmp.iterdir():
                    assert (
                        path.name == "ruff-cache"
                        and path.is_dir()
                        and not path.is_symlink()
                    )
                    shutil.rmtree(path)
                tmp.rmdir()
        controller = {
            "identity": lc.process.identity(lc.process.process_info(os.getpid())),
            "observed_UTC": datetime.now(timezone.utc).isoformat(),
            "scope": "light stopped-reader metadata epilogue, not a reconstructed launch timestamp",
        }
        assert controller["identity"] is not None
        usage = lc.process.directory_bytes(here)
        fs = os.statvfs(here)
        result = {
            "issue": "quoridor-4lc.412.1",
            "status": "SOURCE_FROZEN_NATIVE_UNBUILT_UNTYPED_UNRUN",
            "source_reader_writer_STOP": datetime.now(timezone.utc).isoformat(),
            "refs": {
                name: ref(here / name)
                for name in [
                    "source-binding.json",
                    "lmr-standard412.patch",
                    "lmr-standard412.inverse.patch",
                    "source-report.md",
                    "verification-plan.json",
                    "guide-fragment.md",
                    "fixture-migrations.json",
                    "source-context.json",
                    "guarded.py",
                    "finish.py",
                    "prove.py",
                ]
            },
            "source_controller": controller,
            "phases": phases,
            "fresh_guarded_child_census": census,
            "original_failures": failures,
            "nested_subprocesses": "immutable Git reads and exact patch applications synchronously returned/reaped by subprocess.run; their separate PID/start/boot not recorded=UNKNOWN, not upgraded; no leftover temp frames; guardian family scope and recorded descendants retained",
            "native_tests": "UNBUILT/UNTYPED/UNRUN; source/formatter/static proof only",
            "source_review": "ordinary defaults only, Root routes necessary related conditions/interpretation review; author dispatch0",
            "Main_managedproduction_Git_index_Cargo_Beads_backup_close_native_test_Search_model_Perf_geometry_game_solver_science": 0,
            "prospective_base": "Main9908347 + frozen411 source-binding dbf3a737 (still own immutable); no current/new image or Build guessed",
            "adoption_boundary": "Root Main integration/necessary software after actual411 timingSTOP;412 arena uses old genuine408 image with both methods explicit",
            "readers": [],
            "source_writers": [],
            "children": [],
            "jobs": [],
            "handles": [],
            "TMP": [],
            "leases": [],
            "owned": [],
            "metadata_controller_scope": "this epilogue exits after its final write; exact absence checked after tool return in handoff, not invented here",
            "canonical_hardware_lease": "NONE: private fixed components/named Git objects only; no global/future quietness claim",
            "storage": {
                "budget": None,
                "directed_OWN_allocated_B": usage,
                "dedupe": "existing directory_bytes dev/inode over OWN412 only",
                "FS_available_B": fs.f_bavail * fs.f_frsize,
                "excluded": "final STOP and later tiny delivery/admin; no assets/sharedtarget/global walk",
                "global_actual": "UNKNOWN; decimal50GB retained",
            },
            "Beads_backup_close": "324 only; leaf remains in_progress until canonical acceptance",
            "preserved": "411 fixed source/image/explicitLMROFF;410/408 originaldata andoldRAWFAILEDfeesUNKNOWN; product/generatorLMROFF/models/weights/seals/oldfits96/mixedlearnerALLprep-pipeline+323USERPAUSE/foreign",
        }
        (here / "source-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "source_STOP": ref(here / "source-STOP.json"),
                    "binding": ref(here / "source-binding.json"),
                    "owned": [],
                    "usage_B": usage,
                }
            )
        )
    finally:
        os.sched_setaffinity(0, affinity)
