"""Pin only the owning test subjects that require default migration."""

import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
BASE = "9908347e8cb8a9204572b5840c3e63d6197bc7a9"
refs = []
for rel in [
    "crates/quoridor-ai/src/lmr408_tests.rs",
    "scripts/dev/test_research_comparison.py",
]:
    data = subprocess.run(
        ["git", "--no-optional-locks", "show", BASE + ":" + rel],
        cwd="/workspaces/quoridor",
        check=True,
        capture_output=True,
    ).stdout
    dest = HERE / "before" / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    refs.append(
        {
            "relative": rel,
            "git": BASE + ":" + rel,
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
            "mode": "0644",
        }
    )
    if rel.endswith(".py"):
        print(data.decode())
(HERE / "test-before-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
