def apply_comparison_arena(config, common, pair):
    arena = common["arena"]
    # The existing arena entry fixes these flags true; it has no override fields.
    assert common["use_tt"] is True and common["use_pvs"] is True
    config["ruleset"] = common["ruleset"]
    config["arena"]["tt_entries"] = common["tt_entries"]
    config["arena"]["return_reserve_ms"] = arena["return_reserve_ms"]
    config["management_cpu_core"] = arena["management_guardian"]
    config["cpu_cores"] = list(arena["AI_workers"])
    config["host_ram_reserve"] = common["host_reserve_B"]
    config["max_plies"] = arena["max_plies"]
    config["max_memory_bytes"] = common["family_B"] - common["controller_B"]
    for engine, variant in zip(config["engines"], pair, strict=True):
        assert engine["kind"] == variant["evaluator"]
        engine["ordering_profile"] = variant["profile"]
        engine["lmr"] = variant["lmr"]
        for key in ("depth", "max_nodes", "time_ms"):
            engine[key] = arena[key]

