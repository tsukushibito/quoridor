"""Only repaired helper lint plus genuinely unentered static checks."""

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
original = json.loads((HERE / "quality-v1-commands.json").read_text())
changed = [
    str(HERE / name)
    for name in [
        "caller_tests_intake.py",
        "live_intake.py",
        "finish.py",
        "remaining_quality.py",
    ]
]
commands = []
for action in ["format", "check"]:
    commands.append(
        [
            "ruff-" + action + "-repaired",
            [
                "@PYTHON@",
                "-m",
                "ruff",
                action,
                "--no-cache",
                "--config",
                "/workspaces/quoridor/pyproject.toml",
                *changed,
            ],
        ]
    )
for name, argv in original[3:]:
    commands.append(
        [name, [arg.replace("quality-v1/TMP", "quality-v2/TMP") for arg in argv]]
    )
(HERE / "quality-v2-commands.json").write_text(json.dumps(commands, indent=2) + "\n")
print("Original Rustfmt/owned formatting not replayed; native/test0")
