"""Only live callers/tests crossing the changed omission boundary."""

from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
BASE = "9908347e8cb8a9204572b5840c3e63d6197bc7a9"
run = subprocess.run(
    [
        "git",
        "--no-optional-locks",
        "grep",
        "-n",
        "comparison_conditions(\\|apply_comparison_cost(\\|apply_comparison_arena(",
        BASE,
        "--",
        "scripts/dev",
        "crates/quoridor-runner",
    ],
    cwd="/workspaces/quoridor",
    check=True,
    capture_output=True,
)
print(run.stdout.decode())
for rel in [
    "crates/quoridor-runner/src/runtime_lmr_method_tests.rs",
    "crates/quoridor-ai/src/lmr408_tests.rs",
]:
    text = subprocess.run(
        ["git", "--no-optional-locks", "show", BASE + ":" + rel],
        cwd="/workspaces/quoridor",
        check=True,
        capture_output=True,
    ).stdout.decode()
    print(rel)
    print(text[:6000] if "runtime" in rel else text[:5000])
    if "runtime" in rel:
        path = HERE / "before" / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
text = (HERE / "before/crates/quoridor-runner/src/measurement.rs").read_text()
lines = text.splitlines()
for i, line in enumerate(lines):
    if ("fixed_one" in line or "FixedOne" in line) and i > 900:
        print("measurement", i + 1, "\n".join(lines[max(0, i - 7) : i + 8]))
