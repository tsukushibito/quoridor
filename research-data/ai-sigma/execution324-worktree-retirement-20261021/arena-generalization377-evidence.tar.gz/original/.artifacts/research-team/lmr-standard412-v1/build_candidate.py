"""One sparse default/caller candidate; frozen411 files are never written."""

from pathlib import Path

HERE = Path(__file__).resolve().parent


def save(rel, text):
    dest = HERE / "post" / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text)


rel = "crates/quoridor-ai/src/alphabeta.rs"
text = (HERE / "before" / rel).read_text()
old = "pub enum LmrMethod {\n    #[default]\n    FixedOne,\n    DepthRank,\n}"
assert text.count(old) == 1
text = text.replace(
    old, "pub enum LmrMethod {\n    FixedOne,\n    #[default]\n    DepthRank,\n}"
)
assert text.count("lmr_method: LmrMethod::FixedOne,") == 1
text = text.replace(
    "lmr_method: LmrMethod::FixedOne,", "lmr_method: LmrMethod::default(),"
)
marker = '#[path = "zero_stock411_tests.rs"]'
assert text.count(marker) == 1
text = text.replace(
    marker, '#[path = "lmr412_tests.rs"]\nmod lmr412_tests;\n\n#[cfg(test)]\n' + marker
)
save(rel, text)

rel = "crates/quoridor-ai/src/lmr408_tests.rs"
text = (HERE / "before" / rel).read_text()
assert text.count("    assert_eq!(LmrMethod::default(), LmrMethod::FixedOne);\n") == 1
save(
    rel,
    text.replace("    assert_eq!(LmrMethod::default(), LmrMethod::FixedOne);\n", ""),
)

rel = "crates/quoridor-runner/src/measurement.rs"
text = (HERE / "before" / rel).read_text()
old = '        let settings: Settings = serde_json::from_value(base.clone()).unwrap();\n        assert_eq!(settings.lmr_method, "fixed_one");\n'
assert text.count(old) == 1
text = text.replace(old, "")  # Default assertion moves to the focused412 definition.
index = text.index("    #[test]", text.index("#[cfg(test)]"))
text = (
    text[:index]
    + """    #[test]
    fn measurement412_method_omission_keeps_enable_off_and_explicit_controls() {
        let base=json!({"roots":[{"input":0,"pointer":"","field":"moves","label":"toy"}],"profile":"control","tt_entries":4096,"use_tt":true,"use_pvs":true,"namespace":{"evaluator":"toy","rules":"standard","selectivity":"full"},"output_bytes":1000,"record_bytes":100});
        let omitted:Settings=serde_json::from_value(base.clone()).unwrap();
        assert!(!omitted.lmr); assert_eq!(omitted.lmr_method,"depth_rank");
        for enabled in [false,true] {
            let mut selected=base.clone(); selected["lmr"]=json!(enabled);
            let settings:Settings=serde_json::from_value(selected.clone()).unwrap();
            assert_eq!(settings.lmr,enabled); assert_eq!(settings.lmr_method,"depth_rank");
            selected["lmr_method"]=json!("fixed_one");
            let settings:Settings=serde_json::from_value(selected).unwrap();
            validate(&settings,&[]).unwrap();
            assert_eq!(settings.lmr,enabled); assert_eq!(settings.lmr_method,"fixed_one");
        }
        for bad in [Value::Null,json!(true),json!(1),json!("unknown")] {
            let mut selected=base.clone(); selected["lmr_method"]=bad;
            assert!(!serde_json::from_value::<Settings>(selected).is_ok_and(|settings|validate(&settings,&[]).is_ok()));
        }
    }

"""
    + text[index:]
)
# default_lmr_method already delegates to the single typed AI owner.
save(rel, text)

rel = "crates/quoridor-runner/src/runtime_lmr_method_tests.rs"
text = (HERE / "before" / rel).read_text()
old = '    let e = engine("control", false, None);\n    assert_eq!(arena_lmr_method(&e).unwrap(), LmrMethod::FixedOne);\n'
assert text.count(old) == 1
text = text.replace(old, "")
text += """
#[test]
fn runtime412_method_omission_binds_default_but_never_enables_lmr() {
    use alphabeta::LmrMethod;
    for profile in ["control","cheap"] {
        for enabled in [false,true] {
            let e=engine(profile,enabled,None);
            assert_eq!(arena_lmr_method(&e).unwrap(),LmrMethod::DepthRank);
            let session=arena_alpha_session(Arc::new(NoForward),base(),64,&e,None).unwrap();
            assert_eq!(session.lmr_enabled(),enabled);
            assert_eq!(session.lmr_method(),enabled.then_some(LmrMethod::DepthRank));
            assert_eq!(session.namespace(),&arena_alpha_namespace(&e,base()).unwrap());
        }
    }
    let e=engine("control",true,Some("fixed_one"));
    let session=arena_alpha_session(Arc::new(NoForward),base(),64,&e,None).unwrap();
    assert_eq!(session.lmr_method(),Some(LmrMethod::FixedOne));
}
"""
save(rel, text)

for name in ["arena_lmr_method.rs", "runtime_requested_lmr_method.rs"]:
    text = (HERE / "before" / name).read_text()
    assert text.count("alphabeta::LmrMethod::FixedOne.name()") == 1
    save(
        name,
        text.replace(
            "alphabeta::LmrMethod::FixedOne.name()",
            "alphabeta::LmrMethod::default().name()",
        ),
    )
for name in ["measurement_config.py", "arena_observation.py"]:
    text = (HERE / "before" / name).read_text()
    old = (
        'config.get("lmr_method", "fixed_one")'
        if name.startswith("measurement")
        else 'else "fixed_one"'
    )
    assert text.count(old) == 1
    save(name, text.replace(old, old.replace("fixed_one", "depth_rank")))

text = (HERE / "before/comparison_conditions.py").read_text()
assert 'for lmr in common["lmr_values"]' in text
text = text.replace(
    "dict(evaluator=evaluator, profile=profile, lmr=lmr)",
    'dict(evaluator=evaluator, profile=profile, lmr=lmr, lmr_method=common.get("lmr_method", "depth_rank"))',
)
text = text.replace(
    'for lmr in common["lmr_values"]', 'for lmr in common.get("lmr_values", (True,))'
)
text = text.replace(
    '"""The only varied research factors; evaluator-specific identities stay bound."""',
    '"""Normal research uses ON/depth_rank; explicit controls stay explicit.\n\n    This preparation owner resolves settings, never session namespace IDs.\n    Product/generator and direct raw config enable defaults remain OFF.\n    """',
)
save("comparison_conditions.py", text)
for name in ["apply_comparison_cost.py", "apply_comparison_arena.py"]:
    text = (HERE / "before" / name).read_text()
    token = (
        'config["lmr"] = variant["lmr"]'
        if "cost" in name
        else 'engine["lmr"] = variant["lmr"]'
    )
    owner = "config" if "cost" in name else "engine"
    assert text.count(token) == 1
    save(
        name,
        text.replace(
            token,
            token + f'\n    {owner}["lmr_method"] = variant["lmr_method"]'
            if owner == "config"
            else token + '\n        engine["lmr_method"] = variant["lmr_method"]',
        ),
    )
print("412 single private default/caller candidate; method math/enable flags untouched")
