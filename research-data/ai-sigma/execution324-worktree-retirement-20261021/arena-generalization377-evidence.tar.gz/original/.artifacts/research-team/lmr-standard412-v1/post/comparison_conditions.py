def comparison_conditions(common):
    """Normal research uses ON/depth_rank; explicit controls stay explicit.

    This preparation owner resolves settings, never session namespace IDs.
    Product/generator and direct raw config enable defaults remain OFF.
    """
    return [
        dict(
            evaluator=evaluator,
            profile=profile,
            lmr=lmr,
            lmr_method=common.get("lmr_method", "depth_rank"),
        )
        for evaluator in common["evaluators"]
        for profile in common["profiles"]
        for lmr in common.get("lmr_values", (True,))
    ]
