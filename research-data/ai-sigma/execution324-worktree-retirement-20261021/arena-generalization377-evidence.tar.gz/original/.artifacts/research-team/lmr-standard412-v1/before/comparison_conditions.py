def comparison_conditions(common):
    """The only varied research factors; evaluator-specific identities stay bound."""
    return [
        dict(evaluator=evaluator, profile=profile, lmr=lmr)
        for evaluator in common["evaluators"]
        for profile in common["profiles"]
        for lmr in common["lmr_values"]
    ]

