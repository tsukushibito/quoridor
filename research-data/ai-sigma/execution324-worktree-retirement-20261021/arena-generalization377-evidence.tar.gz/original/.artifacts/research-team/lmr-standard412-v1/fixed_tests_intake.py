"""Only fixed-one or default-sensitive existing owning fixture subjects."""

from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
BASE = "9908347e8cb8a9204572b5840c3e63d6197bc7a9"
for rel in [
    "crates/quoridor-ai/src/lmr400_tests.rs",
    "crates/quoridor-ai/src/search_settings403_tests.rs",
    "crates/quoridor-ai/src/zero_stock406_tests.rs",
    "crates/quoridor-ai/src/zero_stock407_tests.rs",
    "crates/quoridor-runner/src/runtime_lmr400_tests.rs",
]:
    data = subprocess.run(
        ["git", "--no-optional-locks", "show", BASE + ":" + rel],
        cwd="/workspaces/quoridor",
        check=True,
        capture_output=True,
    ).stdout
    dest = HERE / "before" / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    text = data.decode()
    lines = text.splitlines()
    if "lmr400_tests.rs" in rel or "search_settings403" in rel:
        print(rel)
        print(text[:9000])
    else:
        for i, line in enumerate(lines):
            if "LMR_METHOD" in line:
                print(rel, i + 1, "\n".join(lines[max(0, i - 10) : i + 7]))
