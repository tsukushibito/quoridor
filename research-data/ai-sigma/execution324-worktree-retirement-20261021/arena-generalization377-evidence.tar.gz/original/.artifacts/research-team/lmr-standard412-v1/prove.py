"""Exact sparse composition, protected math and forward/inverse; no test execution."""

import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
TMP = Path(os.environ["TMPDIR"])
BASE = "9908347e8cb8a9204572b5840c3e63d6197bc7a9"


def digest(data):
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": "0644",
    }


def ref(path):
    return {"path": str(path), **digest(path.read_bytes())}


def function(text, name):
    start = text.index("fn " + name + "(")
    # Include the visibility from this function's own line.
    start = text.rfind("\n", 0, start) + 1
    end = text.index("{", start) + 1
    depth = 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return text[start:end]


def mask_runtime(text):
    selected = function(text, "arena_lmr_method")
    text = text.replace(selected, "<typed-default-selector>")
    line = next(
        line for line in text.splitlines(True) if '"requested_lmr_method":' in line
    )
    return text.replace(line, "<requested-method-observation>\n")


def mask_publisher(text):
    nodes = [
        n
        for n in ast.parse(text).body
        if isinstance(n, ast.FunctionDef) and n.name in PY_FUNCTIONS
    ]
    assert len(nodes) == len(PY_FUNCTIONS)
    lines = text.splitlines(True)
    for node in sorted(nodes, key=lambda n: n.lineno, reverse=True):
        lines[node.lineno - 1 : node.end_lineno] = ["<" + node.name + ">\n"]
    return "".join(lines)


frames = {}
subjects = []
frozen411 = HERE.parent / "zero-stock-safe-race411-v1"
for name, sha, size in [
    (
        "source-binding.json",
        "dbf3a73770f23f126462e20341439b755d9f946fa100fb19d11ad2e9d79a67a8",
        8107,
    ),
    (
        "source-STOP.json",
        "e738ebeeb593a20e3162ee01097d1c340a0596d14b67ec4b10c1e378fef3570e",
        50405,
    ),
]:
    actual = ref(frozen411 / name)
    assert (
        actual["sha256"] == sha and actual["bytes"] == size and actual["mode"] == "0644"
    )
for path in sorted((HERE / "post/crates").rglob("*.rs")):
    rel = str(path.relative_to(HERE / "post"))
    before = HERE / "before" / rel
    old = before.read_bytes() if before.exists() else b""
    frames[rel] = (old, path.read_bytes())
    subjects.append(
        {
            "relative": rel,
            "before": ref(before) if before.exists() else None,
            "post": ref(path),
        }
    )

runtime_before = (TMP / "runtime-before.rs").read_text()
runtime = (TMP / "runtime.rs").read_text()
assert mask_runtime(runtime_before) == mask_runtime(runtime)
selector = function(runtime, "arena_lmr_method") + "\n"
(HERE / "post/arena_lmr_method.rs").write_text(selector)
line = next(
    line for line in runtime.splitlines(True) if '"requested_lmr_method":' in line
)
(HERE / "post/runtime_requested_lmr_method.rs").write_text(line)
frames["crates/quoridor-runner/src/runtime.rs"] = (
    runtime_before.encode(),
    runtime.encode(),
)
subjects.append(
    {
        "relative": "crates/quoridor-runner/src/runtime.rs",
        "base_git": BASE,
        "before_full": digest(runtime_before.encode()),
        "post_reconstructible_full": digest(runtime.encode()),
        "before_subjects": [
            ref(HERE / "before" / n)
            for n in ["arena_lmr_method.rs", "runtime_requested_lmr_method.rs"]
        ],
        "post_subjects": [
            ref(HERE / "post" / n)
            for n in ["arena_lmr_method.rs", "runtime_requested_lmr_method.rs"]
        ],
        "protected": "outside two declared method selection/observation subjects BYTE_EXACT",
    }
)

PY_FUNCTIONS = {
    "measurement_config",
    "arena_observation",
    "comparison_conditions",
    "apply_comparison_cost",
    "apply_comparison_arena",
}
publisher_before = (TMP / "publisher-before.py").read_text()
publisher = (TMP / "publisher.py").read_text()
assert mask_publisher(publisher_before) == mask_publisher(publisher)
for side, text in [("before", publisher_before), ("post", publisher)]:
    lines = text.splitlines(True)
    for node in ast.parse(text).body:
        if isinstance(node, ast.FunctionDef) and node.name in PY_FUNCTIONS:
            selected = "".join(lines[node.lineno - 1 : node.end_lineno]).strip()
            assert (
                selected == (HERE / side / (node.name + ".py")).read_text().strip()
            ), node.name
frames["scripts/dev/research-lifecycle.py"] = (
    publisher_before.encode(),
    publisher.encode(),
)
subjects.append(
    {
        "relative": "scripts/dev/research-lifecycle.py",
        "base_git": BASE,
        "prospective_component": "measurement_config from frozen411 dbf3a737; other functions exact9908347",
        "before_full": digest(publisher_before.encode()),
        "post_reconstructible_full": digest(publisher.encode()),
        "functions": [
            {
                "name": name,
                "before": ref(HERE / "before" / (name + ".py")),
                "post": ref(HERE / "post" / (name + ".py")),
            }
            for name in sorted(PY_FUNCTIONS)
        ],
        "protected": "outside the five existing named functions BYTE_EXACT; no namespace IDs built in Python",
    }
)

rel = "scripts/dev/test_research_lmr_standard.py"
data = (HERE / "post" / rel).read_bytes()
ast.parse(data)
frames[rel] = (b"", data)
subjects.append({"relative": rel, "before": None, "post": ref(HERE / "post" / rel)})
guide_before = (TMP / "guide-before.md").read_text()
guide = (TMP / "guide.md").read_text()
anchor = "## 設定を使うarena／計測の有限実行\n\n"
assert guide == guide_before.replace(
    anchor, anchor + (HERE / "guide-fragment.md").read_text().rstrip() + "\n\n"
)
frames["docs/development/ai-research-code.md"] = (guide_before.encode(), guide.encode())
subjects.append(
    {
        "relative": "docs/development/ai-research-code.md",
        "base_git": BASE,
        "before_full": digest(guide_before.encode()),
        "post_reconstructible_full": digest(guide.encode()),
        "fragment": ref(HERE / "guide-fragment.md"),
        "protected": "all existing text/history BYTE_EXACT; single current standard insertion",
    }
)

# A full reverse edit proves all AI algorithm/coefficients/TT/PVS/history/
# safe-race/approx/score/enable flags untouched, not a copied comparator oracle.
rel = "crates/quoridor-ai/src/alphabeta.rs"
old, new = [value.decode() for value in frames[rel]]
restored = new.replace(
    "pub enum LmrMethod {\n    FixedOne,\n    #[default]\n    DepthRank,\n}",
    "pub enum LmrMethod {\n    #[default]\n    FixedOne,\n    DepthRank,\n}",
)
restored = restored.replace(
    "lmr_method: LmrMethod::default(),", "lmr_method: LmrMethod::FixedOne,"
)
restored = restored.replace(
    '#[cfg(test)]\n#[path = "lmr412_tests.rs"]\nmod lmr412_tests;\n\n', ""
)
assert restored == old, "out-of-scope Alpha change"

forward = []
inverse = []
for rel, (old, new) in sorted(frames.items()):
    forward.extend(
        difflib.unified_diff(
            old.decode().splitlines(True),
            new.decode().splitlines(True),
            fromfile="a/" + rel if old else "/dev/null",
            tofile="b/" + rel,
        )
    )
    inverse.extend(
        difflib.unified_diff(
            new.decode().splitlines(True),
            old.decode().splitlines(True),
            fromfile="a/" + rel,
            tofile="b/" + rel if old else "/dev/null",
        )
    )
(HERE / "lmr-standard412.patch").write_text("".join(forward))
(HERE / "lmr-standard412.inverse.patch").write_text("".join(inverse))
with tempfile.TemporaryDirectory(prefix="patch-roundtrip-", dir=TMP) as directory:
    root = Path(directory)
    for rel, (old, _) in frames.items():
        if old:
            dest = root / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(old)
    for name, which in [
        ("lmr-standard412.patch", 1),
        ("lmr-standard412.inverse.patch", 0),
    ]:
        run = subprocess.run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "--no-backup-if-mismatch",
                "-p1",
                "-i",
                str(HERE / name),
            ],
            cwd=root,
            check=True,
            capture_output=True,
        )
        print(run.stdout.decode())
        for rel, values in frames.items():
            dest = root / rel
            expected = values[which]
            assert dest.read_bytes() == expected if expected else not dest.exists(), (
                name,
                rel,
            )
        assert not list(root.rglob("*.rej")) and not list(root.rglob("*.orig"))
        print(
            "nested patch directwait/reap exit0; individual PID/start UNKNOWN, outer guardian owns family"
        )
new_files = [rel for rel, (old, _) in frames.items() if not old]
for rel in new_files:
    run = subprocess.run(
        ["git", "--no-optional-locks", "ls-tree", BASE, "--", rel],
        cwd="/workspaces/quoridor",
        check=True,
        capture_output=True,
    )
    assert run.stdout == b"", rel

new_rust = []
for rel, (_, new) in frames.items():
    if rel.endswith(".rs"):
        new_rust.extend(
            re.findall(
                r"#\[test\]\s*fn ((?:lmr|measurement|runtime)412_\w+)\(", new.decode()
            )
        )
assert len(new_rust) == 3, new_rust
python_tree = ast.parse(
    (HERE / "post/scripts/dev/test_research_lmr_standard.py").read_text()
)
python_tests = [
    n.name
    for n in ast.walk(python_tree)
    if isinstance(n, ast.FunctionDef) and n.name.startswith("test_lmr412_")
]
assert len(python_tests) == 2
plan = {
    "status": "author UNBUILT/UNTYPED/UNRUN",
    "new_Rust": {
        "count": 3,
        "names": new_rust,
        "AI_feature": "research-diagnostics",
        "runner_feature": "research-diagnostics",
    },
    "new_Python": {
        "path": "scripts/dev/test_research_lmr_standard.py",
        "class": "ResearchLmrStandardTests",
        "count": 2,
        "names": python_tests,
        "execution": "Root maintained bounded NN0 against actual composed current entry only",
    },
    "affected_AI": {
        "count": 6,
        "names": [
            "lmr400_method_profile_switch_and_reset_clear_real_tt_and_keep_defaults_off",
            "settings403_typed_profile_methods_match_factory_and_reject_unsupported_names",
            "settings403_method_switch_and_raw_reset_keep_profile_clear_tt_and_defaults",
            "settings403_active_signed_control_identity_survives_reset_without_profile_alias",
            "zero_stock406_effective_namespace_switch_reset_and_same_mode_warm_reuse",
            "zero_stock407_effective_switch_reset_and_threshold_equivalence_clear_only_when_needed",
        ],
    },
    "affected_runner": {
        "count": 2,
        "names": [
            "runtime400_factory_modes_match_actual_namespace_and_separate_four_domains",
            "measurement400_lmr_defaults_refusals_real_method_and_scalar_output",
        ],
    },
    "old_fixed_one_math_scope": "six direct lmr400 toy state selections explicitly pinned to FixedOne; old algorithm assertions unchanged, no full old suite/table/solver replay requested",
    "migrated_default_assertions": "old408 AI/runtime/measurement default-only assertions moved to new412 definitions; explicit methods/table/PVS bodies retained",
    "required_software": "Root necessary research/research-diagnostics compile, relevant Clippy and genuine build at actual411 timingSTOP; no author compiler/test calls",
    "math_proof": "Alpha byte-exact after reversing only default attribute, constructor method selection and new test module declaration",
    "science": "author0; old408 genuine image and explicit both method names for412 arena, no new default image qualification or extra calls",
}
(HERE / "verification-plan.json").write_text(json.dumps(plan, indent=2) + "\n")
binding = {
    "issue": "quoridor-4lc.412.1",
    "base_Main_Git": BASE,
    "prospective_frozen411": json.loads((HERE / "intake-binding.json").read_text()),
    "scopes": subjects,
    "forward": ref(HERE / "lmr-standard412.patch"),
    "inverse": ref(HERE / "lmr-standard412.inverse.patch"),
    "strict_roundtrip": "PASS exactbytes both directions, fuzz0/no reject/backup; new files removed by inverse",
    "new_absence_at_base_Git": new_files,
    "protected_Alpha_full_reverse_edit": "PASS byte exact all other code, enable flags and LMR math unchanged",
    "protected_runtime": "outside two method default/observation subjects exact",
    "protected_publisher": "outside five existing functions exact",
    "verification": ref(HERE / "verification-plan.json"),
    "native": "UNBUILT/UNTYPED/UNRUN",
    "Main_Git_index_Cargo_Beads_source_managed_native_tests_Search_model_Perf_game_solver_reviewdispatch": 0,
    "Root_composition": "sparse hunks only on actual current411 afterrefs/ordinary repairs; no stale full postimage overwrite or guessed image/Build",
}
(HERE / "source-binding.json").write_text(json.dumps(binding, indent=2) + "\n")
for name in [
    "runtime-before.rs",
    "runtime.rs",
    "publisher-before.py",
    "publisher.py",
    "guide-before.md",
    "guide.md",
]:
    (TMP / name).unlink()
# Discard only unnecessary immutable source/config intake copies in OWN412.
for name in ["prepare_selected_operation.py", "sequence.py"]:
    (HERE / "before" / name).unlink()
for path in (HERE / "before/configs/arena").iterdir():
    path.unlink()
(HERE / "before/configs/arena").rmdir()
(HERE / "before/configs").rmdir()
print(
    json.dumps(
        {
            "strict_sparse_proof": "PASS",
            "paths": len(frames),
            "newRust": new_rust,
            "newPython": python_tests,
            "native": "UNBUILT/UNTYPED/UNRUN",
        }
    )
)
