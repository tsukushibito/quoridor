def arena_observation(config, row):
    """Audit owned native decisions without replaying geometry or Search."""
    accepted = []
    for obs in row["observations"]:
        index = obs["engine_index"]
        require(
            type(index) is int and 0 <= index < len(config["engines"]),
            "observation engine",
        )
        for key in ("caller_seconds", "thinking_seconds", "value_stm"):
            value = obs.get(key)
            require(
                value is None or (type(value) in (int, float) and math.isfinite(value)),
                "nonfinite observation",
            )
        require(type(obs["accepted"]) is bool, "typed acceptance")
        if not obs["accepted"]:
            continue
        require(
            obs["failure"] is None
            and obs["engine_error"] is None
            and type(obs["action"]) is int
            and type(obs["accepted_ns"]) is int
            and type(obs["admission_checked_ns"]) is int
            and type(obs["returned_ns"]) is int
            and obs["accepted_ns"] >= obs["admission_checked_ns"] >= obs["returned_ns"],
            "illegal/incoherent acceptance",
        )
        a = config["arena"]
        if config["engines"][index]["kind"] == "mcts":
            counters = obs["counters"]
            receipt = counters["authority_receipt_ns"]
            require(
                type(receipt) is int
                and type(obs["deadline_ns"]) is int
                and receipt < obs["deadline_ns"]
                and counters["authority_legal"] is True
                and counters["inflight_after_drain"] == 0
                and type(counters["completed_simulations"]) is int
                and (
                    (counters["completed_simulations"] > 0)
                    or (
                        counters["completed_simulations"] == 0
                        and counters.get("selection_reason")
                        == "legal_fallback_no_completed_simulation"
                        and "completed_simulation_counters" in counters
                        and "last_completed_simulation_ns" in counters
                        and counters["completed_simulation_counters"] is None
                        and counters["last_completed_simulation_ns"] is None
                        and obs["value_stm"] is None
                    )
                )
                and counters["clock_contract"] == "authority-action-receipt-v1"
                and counters["clock_contract_sha256"]
                == "04062382f70648cdfd722e59c35be1100719169097a04749b0046ea5a19a280d"
                and obs["returned_ns"] == counters["drain_finished_ns"]
                and obs["returned_ns"] >= receipt
                and obs["completed_depth"] is None
                and obs["pv"] == [],
                "Sigma receipt/drain/completed simulation",
            )
            accepted.append(obs["action"])
            continue
        counters = obs["counters"]
        engine = config["engines"][index]
        if engine.get("ordering_profile") is not None:
            method = counters.get("actual_search_namespace")
            require(
                isinstance(method, dict)
                and set(method) == {"evaluator", "rules", "selectivity"}
                and all(isinstance(v, str) and v for v in method.values())
                and method["rules"] == "research-standard-2p-threefold-goal-first-v1"
                and method["evaluator"]
                in {
                    kind
                    + ":sha256:"
                    + a["evaluator_sha256"][index]
                    + ":simd="
                    + str(engine["simd"]).lower()
                    for kind in {
                        "distance": ("distance-tanh-f32",),
                        "nnue": ("nnue-f32", "nnue-residual-f32"),
                        "nnue_quantized": ("nnue-i16",),
                    }.get(engine["kind"], ())
                }
                # The native typed factory and report validator own exact namespace/ID
                # correspondence. Do not duplicate AI method suffixes in this reader.
                and counters.get("requested_lmr_method")
                == (
                    engine.get("lmr_method")
                    if engine.get("lmr_method") is not None
                    else "depth_rank"
                )
                and (
                    all(
                        isinstance(counters.get(k), str) and counters[k]
                        for k in ("actual_lmr_method_id", "lmr_reduction_rule")
                    )
                    if engine.get("lmr", False)
                    else all(
                        k in counters and counters[k] is None
                        for k in ("actual_lmr_method_id", "lmr_reduction_rule")
                    )
                )
                and type(counters.get("actual_lmr_enabled")) is bool
                and counters["actual_lmr_enabled"] == engine.get("lmr", False),
                "configured/actual arena ordering-LMR method correspondence",
            )
        fallback = (
            a["comparison"] == "whole_wall_time"
            and counters.get("selection_reason")
            == "legal_fallback_no_completed_iteration"
        )
        require(
            counters["completed_snapshot_validation_failed"] is False
            and (
                (
                    obs["completed_depth"] is None
                    and obs["value_stm"] is None
                    and obs["pv"] == []
                    and obs["last_completed_iteration_ns"] is None
                    and obs["completed_iteration_counters"] is None
                )
                if fallback
                else (
                    obs["pv"]
                    and obs["pv"][0] == obs["action"]
                    and type(obs["completed_depth"]) is int
                    and obs["completed_depth"] > 0
                    and obs["value_stm"] is not None
                )
            ),
            "alpha completion/PV or truthful zero-work fallback",
        )
        if a["comparison"] == "evaluator_fixed_depth":
            require(
                type(obs["completed_depth"]) is int
                and obs["completed_depth"] == config["engines"][index]["depth"]
                and obs["stop"] == "depth_cap"
                and obs["value_stm"] is not None
                and obs["deadline_ns"] is None,
                "partial depth cannot publish action",
            )
        else:
            receipt = counters["authority_receipt_ns"]
            require(
                type(receipt) is int
                and type(obs["deadline_ns"]) is int
                and receipt < obs["deadline_ns"]
                and counters["drain_finished_ns"] == obs["returned_ns"]
                and (
                    (
                        obs["returned_ns"] >= receipt
                        and counters["inflight_after_drain"] == 0
                    )
                    if a["comparison"] == "whole_wall_time"
                    else obs["returned_ns"] == receipt
                ),
                "main receipt/terminal drain",
            )
        accepted.append(obs["action"])
    if not config["arena"].get("decision_only", False):
        opening = config["arena"]["book"]["openings"][row["game"] // 2]["prefix"]
        require(
            row["moves"][: len(opening)] == opening
            and accepted == row["moves"][len(opening) :],
            "full opening/accepted actions/durable moves",
        )
