# 412.1 研究標準 LMR ON / depth_rank の私有source準備

人間の研究上の採用選択を、既存の準備入口と省略methodの解決へ反映する一候補である。一般棋力の優越・追加対局の成功を認定するpacketではない。作者のMain/managed production/Git/index/Cargo/Beads/native/test/Search/model/Perf/game/solver/review dispatchは0。新定義はUNBUILT/UNTYPED/UNRUNで、必要software・Main採用・Beads/backup/closeは324が所有する。

## 実際の入口と最小変更

現役の通常研究準備は `research-lifecycle.py::comparison_conditions` と `apply_comparison_cost` / `apply_comparison_arena`。現在の使用callerは同publisherとそのmaintained owning testで、artifactの一度限りrecipeは現役標準ではない。既存D/D調整presetは固定source/evaluator SHAを持つ例であり、通常研究標準としてretargetしない。

`comparison_conditions` だけが通常研究の省略を解決する。`lmr_values`省略は `(True,)`、`lmr_method`省略は `depth_rank`。各条件へ実fieldを明示し、2つの既存適用関数がmeasurement/engine JSONへその値を書き込む。明示OFF / `fixed_one`、明示した条件配列を保持する。別preset/registry/設定継承は作らず、templateに残る別methodを黙って使わない。既存current callerはこの関数が作る条件を渡すので、method fieldの伝播を一つのownerに保つ。

汎用readerや製品・実generatorのenable既定は変えない。直接のmeasurement JSONの `lmr`省略はfalse、Engineの既存bool/Option形も保持する。AI enumの省略methodだけ `DepthRank` にし、SearchSession内部method初期値をこのtyped defaultへ寄せる。`set_lmr` / bool引数はそのまま独立で、OFFから勝手にONへしない。explicit `FixedOne` は引き続き同じmethodとして選べる。

measurementの既存default helperは既にAIのtyped defaultを呼ぶので新しいmethod解決関数を足さない。runtimeのselectorと要求method観測は `LmrMethod::default().name()`、Pythonのmeasurement検証とarena観測の省略名は `depth_rank` へ機械的に揃える。measurementのmethod null/未知名/型違い拒否、Engine Optionとarena planの既存None/null/type規則は変更しない。namespace/ID/suffixやreduction_ruleはAIが唯一の正本で、Python側へ複製しない。

現在の案内は既存 `docs/development/ai-research-code.md` の有限arena/計測入口へ一節を挿入するfragment/薄いpatchにした。標準値の解決場所と直接raw configのOFFを同じ一節で説明する。旧400/402/408の歴史判断や実結果を置換せず、Rootが既存findings/ordering設計への参照を統合する。新しい必読文書やtask listは作らない。

## 数学・既定・費用の保護

LMR table、係数、保護、distinct rank、full-depth scout/PVS、TT/history/rules/model/score、411 safe-raceと410 approximationの実装は変えない。Alpha全体を、default属性・constructorのmethod選択・newtest宣言だけ逆編集するとbeforeにbyte exactで戻ることを静的に確認する。runtimeは2subject、publisherは5既存function以外のbyteを保護し、forward/inverseはfuzz0で完全復元する。production/generatorのenable flag、TT容量やmodel/weightsは触らない。

既存 `change_lmr` はmethod選択時、OFFでも既存 `method.prepare()` を呼ぶ。この所有/実装はそのままなので、新しい省略methodを選ぶsetter経路では既存4096-cell OnceLock tableがprocess一度で初期化され得る。新table/heap/per-node logや係数は追加しないが、初回setup費と共有static領域/RSS実寸は未測定でありゼロとは主張しない。必要な実費は新current imageのwhole/setup境界に含む。凍結411のLMR OFF/image/比較へはこの変更を混入しない。

old default-only assertionsはnew412定義へ移し、既存explicit-method/table本体を保持する。generic factory/namespace assertionsはtyped defaultを参照する。固定1手のq/confirmationを検査する旧toy状態6箇所は `FixedOne` を明示し、従来と同じ状態・既存数学assertionsを保つ。単に新defaultへ変えて旧固定1手の反例を別方式へ流用しない。これらの機械的保守をold成功suite全体の再演要求にはしない。

## 基準・検証・引渡し境界

immutable Main `9908347e8cb8a9204572b5840c3e63d6197bc7a9` と、凍結411 `source-binding dbf3a737` の必要AI/measurement/measurement_config postimageを合成基準にした。411 original source-STOP e738ebee/50405 と全postimagesを変更しない。411の普通fixture修復やRoot current afterrefsが変われば、Rootがdefaultの狭いhunkだけを合成する。全古postimage上書きや未来image/Buildを仮定しない。Main採用/affected softwareは実411timing STOP後で、412の追加対局は真正408同一imageと明示した両methodを使う別のscopeである。

新定義はAI1・runner measurement1・runtime1・Python2。method省略とenableの独立、明示OFF/fixed_one、型/null/未知名拒否、通常研究準備のresolved field伝播とarena consumerの省略対応を検査する定義だけを書いた。作者は実行していない。正確なnew/affected names・features・件数はverification-planに置く。旧LMR table/geometry/model/solver/旧成功suite全体は再演しない。

source/formatter/static guardはworker3/guardian7、family512MiB/GPU0/host4GiB reserve。actual affinity/topology/readbackと各childのno_new_privs/directwait/reap/handles/captureを記録し、immutable Gitの子は同期runの返却を記録するが、個別PID/start未記録ならUNKNOWNとする。canonical/hardware leaseは保持せず、全host quietや未来quietを主張しない。Node/GoへAS512は掛けない。

一度のconsumer検索は対象path/patternに該当が無くexit1、元FAILED/NULL/capturefalse/pending-attemptedを保持した。後の必要範囲のliteral検索ではpublisherだけが見つかった。科学/ソフト成功suiteの再実行やguard bypassではない。途中で読んだ不要なimmutable config/関数copyは、OWN412だけから除き、元Gitと元intake logを保持する。formatter/proof用の3つの全体frameはOWN TMP内だけで直ちに削除し、恒常source mirrorを残さない。

最初のqualityはRustfmtと私有Python整形の元PASSを保持し、補助scriptの未使用import3個とimport位置だけでRuff FAILEDになった。修正対象だけの整形/lintと、その時点で未入場だったpublisher/差分証明を続け、nativeや旧成功assertionは実行しない。

ordinary storageは事前枠なし、最後にOWN412のinode dedupe使用一度だけ。共有target/assetsを走査・再課金しない。decimal50GB/global actual UNKNOWN、旧RAW/FAILED/fees/UNKNOWN、mixed/learner全prep/pipelineと323 USERPAUSE、製品/実generator OFF、models/weights/seals/oldfits96/foreignを保持する。412の新科学entry・review dispatchは作者0。
