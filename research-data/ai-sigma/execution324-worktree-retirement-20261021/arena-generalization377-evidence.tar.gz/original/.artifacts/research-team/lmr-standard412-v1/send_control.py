"""Same maintained guarded port, metadata delivery epilogue only."""

import finish
import send_admin

finish.freeze = send_admin.finish
__import__("guarded")
