"""Transient formatter/proof frames, not a persistent source mirror."""

import ast
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
TMP = Path(os.environ["TMPDIR"])
BASE = "9908347e8cb8a9204572b5840c3e63d6197bc7a9"


def git(rel):
    run = subprocess.run(
        ["git", "--no-optional-locks", "show", BASE + ":" + rel],
        cwd="/workspaces/quoridor",
        check=True,
        capture_output=True,
    )
    print(
        "nested immutable Git read returned/reaped exit0; individual PID/start not recorded:",
        rel,
    )
    return run.stdout.decode()


def function_replace(text, name, new):
    node = next(
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name == name
    )
    lines = text.splitlines(True)
    return (
        "".join(lines[: node.lineno - 1])
        + new.rstrip()
        + "\n"
        + "".join(lines[node.end_lineno :])
    )


runtime = git("crates/quoridor-runner/src/runtime.rs")
updated = runtime
for name in ["arena_lmr_method.rs", "runtime_requested_lmr_method.rs"]:
    old = (HERE / "before" / name).read_text().rstrip()
    new = (HERE / "post" / name).read_text().rstrip()
    assert updated.count(old) == 1
    updated = updated.replace(old, new)
(TMP / "runtime-before.rs").write_text(runtime)
(TMP / "runtime.rs").write_text(updated)

publisher = git("scripts/dev/research-lifecycle.py")
# 411 is a prospective frozen component. No claim that currentMain/adopted
# image already contains it, and no write to that original component.
publisher = function_replace(
    publisher, "measurement_config", (HERE / "before/measurement_config.py").read_text()
)
updated = publisher
for name in [
    "measurement_config",
    "arena_observation",
    "comparison_conditions",
    "apply_comparison_cost",
    "apply_comparison_arena",
]:
    updated = function_replace(
        updated, name, (HERE / "post" / (name + ".py")).read_text()
    )
(TMP / "publisher-before.py").write_text(publisher)
(TMP / "publisher.py").write_text(updated)

guide = git("docs/development/ai-research-code.md")
anchor = "## 設定を使うarena／計測の有限実行\n\n"
assert guide.count(anchor) == 1
updated = guide.replace(
    anchor, anchor + (HERE / "guide-fragment.md").read_text().rstrip() + "\n\n"
)
(TMP / "guide-before.md").write_text(guide)
(TMP / "guide.md").write_text(updated)
print("Only three named temporary formatter frames; all removed after strict proof")
