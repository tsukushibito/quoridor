"""Generate the finite scoped formatter/proof command list, never a job."""

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
RUSTFMT = "/usr/local/cargo/bin/rustfmt"
PY = "@PYTHON@"
CONFIG = "/workspaces/quoridor/pyproject.toml"
rust = [str(p) for p in sorted((HERE / "post/crates").rglob("*.rs"))]
helpers = [str(p) for p in sorted(HERE.glob("*.py"))]
fragments = [str(p) for p in sorted((HERE / "post").glob("*.py"))]
new_test = str(HERE / "post/scripts/dev/test_research_lmr_standard.py")
tmp = HERE / "quality-v1/TMP"
commands = [
    [
        "rustfmt-owned",
        [RUSTFMT, "--edition", "2024", "--config", "skip_children=true", *rust],
    ],
    [
        "ruff-format-owned",
        [
            PY,
            "-m",
            "ruff",
            "format",
            "--no-cache",
            "--config",
            CONFIG,
            *helpers,
            *fragments,
            new_test,
        ],
    ],
    [
        "ruff-check-owned",
        [
            PY,
            "-m",
            "ruff",
            "check",
            "--no-cache",
            "--config",
            CONFIG,
            *helpers,
            new_test,
        ],
    ],
    [
        "prettier-guide",
        [
            "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier",
            "--config",
            "/workspaces/quoridor/.prettierrc.json",
            "--write",
            str(HERE / "source-context.json"),
            str(HERE / "source-report.md"),
            str(HERE / "guide-fragment.md"),
        ],
    ],
    ["prepare-transient-frames", [PY, "-B", str(HERE / "prepare_proof.py")]],
    [
        "rustfmt-runtime-frame",
        [
            RUSTFMT,
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            str(tmp / "runtime.rs"),
        ],
    ],
    [
        "ruff-check-composed-publisher",
        [
            PY,
            "-m",
            "ruff",
            "check",
            "--no-cache",
            "--config",
            CONFIG,
            str(tmp / "publisher.py"),
        ],
    ],
    ["strict-proof", [PY, "-B", str(HERE / "prove.py")]],
]
(HERE / "quality-v1-commands.json").write_text(json.dumps(commands, indent=2) + "\n")
print("Scoped formatting/static commands prepared; no test/compile/native invocation")
