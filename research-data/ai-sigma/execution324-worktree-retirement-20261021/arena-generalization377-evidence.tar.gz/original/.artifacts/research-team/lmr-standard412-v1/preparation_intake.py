"""Select the live pure preparation helpers and maintained runner guide."""

import ast
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
BASE = "9908347e8cb8a9204572b5840c3e63d6197bc7a9"
rel = "scripts/dev/research-lifecycle.py"
text = subprocess.run(
    ["git", "--no-optional-locks", "show", BASE + ":" + rel],
    cwd="/workspaces/quoridor",
    check=True,
    capture_output=True,
).stdout.decode()
for node in ast.parse(text).body:
    if isinstance(node, ast.FunctionDef) and 5280 <= node.lineno <= 5460:
        part = "".join(text.splitlines(True)[node.lineno - 1 : node.end_lineno])
        print(node.name, node.lineno)
        print(part)
        dest = HERE / "before" / (node.name + ".py")
        dest.write_text(part + "\n")
rel = "crates/quoridor-runner/README.md"
text = subprocess.run(
    ["git", "--no-optional-locks", "show", BASE + ":" + rel],
    cwd="/workspaces/quoridor",
    check=True,
    capture_output=True,
).stdout.decode()
lines = text.splitlines(True)
for i, line in enumerate(lines):
    if "LMR" in line or "lmr" in line or "configured-research" in line:
        print(rel, i + 1, "".join(lines[max(0, i - 3) : i + 7]))
(HERE / "before/runner-guide-lmr-lines.json").write_text(
    json.dumps(
        {
            "base": BASE,
            "relative": rel,
            "sha256": hashlib.sha256(text.encode()).hexdigest(),
            "bytes": len(text),
        },
        indent=2,
    )
    + "\n"
)
