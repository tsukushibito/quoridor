# 395 合法手ビット集合候補

一候補を準備した。変更は `position.rs` の `legal_pawn_mask` から `legal_action_ids` までの担当領域と、新規 `tests/legal_bits395.rs` のみ。公開 API、ID、探索設定、score、NNUE、TT、history、PVS、distance geometry は変更していない。native の型・compile・assertion・費用は未確認であり、採用・一般速度改善は主張しない。

駒の通常移動・jump・横回避は private `pawn_destinations` 一つに移し、同じ条件で u128 に目的地を入れる。公開81配列はその集合を投影する。内部ID列挙では配列のゼロ初期化と81走査を省き、set bit を昇順に取り出す。公開 `play` と Game は変更していない。既存 `is_edge_open` の範囲判定が、unchecked pawn の不正目的地を bit shift より先に拒む。

壁は同向き隣接 anchor の対称関係を一つの private helper で表す。H は列0/7を shift 前に除外、V は行0/7を除外する。設置済みH/VのORは同anchorの設置・交差を除外し、各向きの隣接集合は同向き重なりだけを除外する。候補64bitの残bitを H、V の順に昇順列挙する。これは経路の証明ではない。既存 WallPosts と、閉路候補に必要な exact WallEdges 到達判定はそのまま。baseline が到達不能なら壁を列挙しない既存 unchecked 契約も保持する。

公開 one-wall 判定も同じ隣接関係を単一query bitへ適用する。両向き64候補集合・WallPosts・追加BFSを作らず、選んだ向きの壁とのANDだけで重なりを判定する。実際の費用増減は未計測。stock/winner/anchor範囲の短絡順、公開 `legal_wall` の二player到達判定は変更していない。

静的確認では担当領域の前後、`play` 以降の全byteと公開 `legal_wall` body が元byteに一致。担当before SHA は `2dbc3d257badad38cd66b27db6fe640ecdc0a374a8c16dd59df36c9792514aad`。393の追加保存候補はRootで不支持rollback済み。このpacketの全 `position.rs` postimageは履歴393の外側を含むため、**全file上書き禁止**。Rootは前記同一legal領域のhunksのみ現復帰391 sourceに合成する。GNU forward/inverse は保存beforeに対しfuzz0/offset0で完全往復、新規testはinverseでABSENTへ戻った。

新規五定義は H/V全anchor境界・両colour、交差/重なり/接触・stock0・winner、四方向jumpと横回避/盤端、last-route切断と到達不能unchecked、Game公開mask/集合/昇順/parentと拒否を対象にする。壁の期待値は既存scalar geometry＋独立cellqueue `support/queue_reference.rs` を再用する。駒の期待値は明示的rule目的地であり、このreferenceのpawn部分が公開maskを使う点を独立oracleとは扱わない。old implementationのコピーやmask式を期待値として複製していない。

scoped Rustfmt apply/check、helper Ruff format/lint、byte isolation/strict patch proof は既存guarded software portで実PASS。五つのRustテストは **UNBUILT / UNTYPED / UNRUN**。Cargo/native/geometry/model/Search/Perf/game/fitは作者0。Rootの必要software・一度の限定legality review・最新実採用Oと395だけを加えた真正Nの承認済みONNO24が残る。追加call/refill/候補変更なし。leafはin_progressで保ち、混合342.17・323 USERPAUSEと旧RAW/FAILED/費/UNKNOWNを維持する。

正確なrefs、五definition名、process returned/persisted差、reader/子/TMP STOP、実使用は `source-STOP.json` とリンクされた `static-proof.json` / `static-v1/result.json` を参照する。native benefit、one-wall cost、一般speed、動的hit頻度はUNKNOWN。
