"""Thin legal-owner byte proof only; no Rust or geometry execution."""

import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import stat
import subprocess

OWN = Path.cwd()
OUT = OWN / ".artifacts/research-team/legal-action-bits395-v1"
POSITION = "crates/quoridor-core/src/position.rs"
TEST = "crates/quoridor-core/tests/legal_bits395.rs"
intake = json.loads((OUT / "source-intake.json").read_text())
before = {
    POSITION: gzip.decompress((OUT / "position.rs.before.gz").read_bytes()),
    TEST: b"",
}
after = {path: (OWN / path).read_bytes() for path in before}
assert hashlib.sha256(before[POSITION]).hexdigest() == intake["Main_source"]["sha256"]
assert intake["new_test_before"] == "ABSENT"
start = b"    pub fn legal_pawn_mask"
end = b"    pub fn play("
old = before[POSITION]
new = after[POSITION]
old_start, old_end = old.index(start), old.index(end)
new_start, new_end = new.index(start), new.index(end)
assert old[:old_start] == new[:new_start]
assert old[old_end:] == new[new_end:]
assert (
    hashlib.sha256(old[old_start:old_end]).hexdigest()
    == intake["Root_disjoint_control"]["legal_owners_SHA256"]
)


# The public one-wall route, exact baseline reachability and WallPosts/BFS
# implementations stay owned by their existing paths, outside this change.
def body(raw, signature):
    text = raw.decode()
    offset = text.index(signature)
    brace = text.index("{", offset)
    depth = 0
    for i in range(brace, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[offset : i + 1]
    raise AssertionError(signature)


assert body(old, "pub fn legal_wall(") == body(new, "pub fn legal_wall(")
reference = OWN / "crates/quoridor-core/tests/support/queue_reference.rs"
expected = next(
    r["file"]
    for r in intake["reference_inputs"]
    if r["relative"].endswith("queue_reference.rs")
)
assert hashlib.sha256(reference.read_bytes()).hexdigest() == expected["sha256"]
names = re.findall(r"#\[test\]\s*fn (legal_bits395_\w+)\(", after[TEST].decode())
assert len(names) == len(set(names)) == 5

for name, left, right in [
    ("source.patch", before, after),
    ("source.inverse.patch", after, before),
]:
    chunks = []
    for path in before:
        chunks.extend(
            difflib.unified_diff(
                left[path].decode().splitlines(True),
                right[path].decode().splitlines(True),
                fromfile="a/" + path if left[path] else "/dev/null",
                tofile="b/" + path if right[path] else "/dev/null",
            )
        )
    (OUT / name).write_text("".join(chunks))
TMP = OUT / "proof-TMP"
TMP.mkdir()
captures = []
try:
    p = TMP / POSITION
    p.parent.mkdir(parents=True)
    p.write_bytes(before[POSITION])
    (TMP / TEST).parent.mkdir(parents=True, exist_ok=True)
    for name, expected in [("source.patch", after), ("source.inverse.patch", before)]:
        result = subprocess.run(
            ["/usr/bin/patch", "--batch", "--fuzz=0", "-p1", "-i", str(OUT / name)],
            cwd=TMP,
            capture_output=True,
            text=True,
            check=True,
            timeout=60,
        )
        assert not re.search(r"offset|fuzz|FAILED", result.stdout + result.stderr)
        for path, raw in expected.items():
            assert (
                (TMP / path).read_bytes() == raw if raw else not (TMP / path).exists()
            )
        captures.append(
            {
                "patch": name,
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
        )
finally:
    shutil.rmtree(TMP)


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path.resolve()),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


for path, raw in after.items():
    (OUT / (Path(path).name + ".after.gz")).write_bytes(gzip.compress(raw, mtime=0))
result = {
    "status": "STATIC_BYTE_PROOF_PASS",
    "before": intake["Main_source"],
    "new_test_before": "ABSENT",
    "legal_owner_before_sha256": hashlib.sha256(old[old_start:old_end]).hexdigest(),
    "legal_owner_after_sha256": hashlib.sha256(new[new_start:new_end]).hexdigest(),
    "outside_legal_owner_exact": True,
    "public_legal_wall_body_exact": True,
    "composition": "Apply only legal-owner hunks on current restored391 position; never install historical393 full postimage.",
    "postimages": [ref(OWN / path) for path in after],
    "forward": ref(OUT / "source.patch"),
    "inverse": ref(OUT / "source.inverse.patch"),
    "GNU_zero_fuzz_zero_offset_exact_roundtrip": captures,
    "independent_wall_reference": ref(reference),
    "new_test_definitions": names,
    "expected_new_test_count": 5,
    "native_status": "UNBUILT/UNTYPED/UNRUN",
    "temporary_tree_absent": not TMP.exists(),
    "Cargo_native_geometry_Search_model_Perf_game_fit_calls": 0,
}
(OUT / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    "Legal-owner isolation / GNU forward inverse / new-file absence / five definitions STATIC PASS; native UNRUN"
)
