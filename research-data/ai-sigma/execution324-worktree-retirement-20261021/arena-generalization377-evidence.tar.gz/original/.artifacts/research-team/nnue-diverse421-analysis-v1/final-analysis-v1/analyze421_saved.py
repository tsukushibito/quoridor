"""Analyze the original421 compact results; never import a model or run search."""

import ast
from collections import Counter
import datetime
import hashlib
import io
import json
import math
from pathlib import Path
import stat
import struct
import zipfile


BASE = Path(__file__).resolve().parent
CHECKS = {}


def check(name, value):
    CHECKS[name] = bool(value)


def save(name, value):
    (BASE / name).write_text(
        json.dumps(value, ensure_ascii=False, separators=(",", ":")) + "\n"
    )


def reference(path, data=None):
    path = Path(path)
    data = path.read_bytes() if data is None else data
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }


def added_exposure(ref):
    path = Path(ref["path"])
    data = path.read_bytes()
    before = reference(path, data)
    if before != ref:
        raise ValueError("Saved exposure FileRef mismatch")
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        entry = archive.getinfo("added_visits.npy")
        if entry.file_size > 65536:
            raise ValueError("Unexpected added-only exposure array size")
        raw = archive.read(entry)
    if raw[:6] != b"\x93NUMPY":
        raise ValueError("Expected canonical NPY header")
    version = tuple(raw[6:8])
    if version == (1, 0):
        header_size = struct.unpack("<H", raw[8:10])[0]
        offset = 10
    elif version in ((2, 0), (3, 0)):
        header_size = struct.unpack("<I", raw[8:12])[0]
        offset = 12
    else:
        raise ValueError(f"Unsupported NPY version {version}")
    header = ast.literal_eval(raw[offset : offset + header_size].decode("latin1"))
    if header["fortran_order"] or len(header["shape"]) != 1:
        raise ValueError("Expected one-dimensional row visit counts")
    dtype = header["descr"]
    formats = {"<i8": "q", "<u8": "Q", "<i4": "i", "<u4": "I"}
    if dtype not in formats:
        raise ValueError(f"Unsupported count dtype {dtype}")
    counts = list(
        struct.unpack(
            f"<{header['shape'][0]}{formats[dtype]}", raw[offset + header_size :]
        )
    )
    after = reference(path)
    if after != before:
        raise ValueError("Saved exposure changed during read")
    return counts, header, {"before": before, "after": after, "exact": True}


def main():
    inlet = json.loads((BASE / "inlet.json").read_text())
    training = json.loads((BASE / "training-arena-inlet.json").read_text())
    provenance = json.loads((BASE / "fit-provenance-inlet.json").read_text())
    cache_inlet = json.loads((BASE / "cache-config-exposure-inlet.json").read_text())
    arena_manifest = json.loads((BASE / "arena-manifest-inlet.json").read_text())
    v, x = inlet["values"], training["values"]
    cache = cache_inlet["values"]["cache_manifest"]
    c, m = x["training_C"], x["training_M"]
    check(
        "generation64_goal_unknown0",
        v["generation"]["census"]["goals"]
        == v["generation"]["census"]["recorded"]
        == 64
        and v["generation"]["census"]["unknown"] == 0,
    )
    check(
        "2822_distinct_eligible_completed_nominalD6",
        x["generation_report"]["distinct_positions"]
        == cache["rows"]
        == v["generation"]["census"]["eligible_rows"]
        == 2822
        and v["generation"]["census"]["achieved_depths"] == {"6": 2822},
    )
    check(
        "generation_node_budget",
        v["generation"]["census"]["search_nodes"] == 434615074 < 1000000000,
    )
    split = cache["common_corpus"]["common_eligible_by_split"]
    check("raw_T2216_V606", split == {"train": 2216, "validation": 606})
    r = m["training_view_rows"]
    updates = math.ceil(4 * r / 128)
    check(
        "R927_U29",
        r == 927 and updates == c["plan"]["updates"] == m["plan"]["updates"] == 29,
    )
    check("same_initial_reference", c["initial_reference"] == m["initial_reference"])
    check(
        "shared_initial_metrics_no_new_M_forward",
        c["curves"][0]["scopes"] == m["curves"][0]["scopes"]
        and m["curves"][0]["forward_rows"] == 0
        and m["plan"]["reused_initial"],
    )
    check(
        "same_observation_schedule",
        c["plan"]["observation_steps"]
        == m["plan"]["observation_steps"]
        == [0, 8, 15, 22, 29],
    )
    check(
        "same_LR_warmup",
        c["learning_rates"] == m["learning_rates"]
        and all(
            math.isclose(lr, 0.0001 * min((i + 1) / 10, 1), abs_tol=1e-12)
            for i, lr in enumerate(c["learning_rates"])
        ),
    )
    check(
        "actual_C_M_training_counts",
        c["added_seen"] == 0
        and c["public_seen"]
        == c["training_forwards"]
        == m["training_forwards"]
        == 29 * 256
        and m["added_seen"] == m["public_seen"] == 29 * 128,
    )
    check("less_than_fourR_plus128", m["added_seen"] < 4 * r + 128)
    exposure_ref = next(
        a["before"] for a in cache_inlet["refs"] if a["name"] == "M_exposure_counts"
    )
    counts, header, exposure_read = added_exposure(exposure_ref)
    positives = [
        {"cache_row": i, "visits": count} for i, count in enumerate(counts) if count
    ]
    check(
        "actual_added_exposure",
        len(counts) == 2822
        and len(positives) == r
        and sum(counts) == m["added_seen"]
        and all(a >= 0 for a in counts),
    )
    check(
        "four_or_five_visits", Counter(a["visits"] for a in positives) == {4: 923, 5: 4}
    )
    exposure = {
        "source": exposure_ref,
        "only_decoded_member": "added_visits.npy",
        "header": header,
        "positive_rows": positives,
        "counts_histogram_all_cache_rows": dict(Counter(counts)),
        "total_draws": sum(counts),
        "distinct_selected": len(positives),
        "mean_visits_selected": sum(counts) / r,
        "public_arrays_model_arrays_decoded": False,
    }
    curves, stocks = [], []
    for arm, t in (("C", c), ("M", m)):
        new_t_families = set(t["curves"][0]["scopes"]["added_train"]["families"])
        new_v_families = set(t["curves"][0]["scopes"]["added_validation"]["families"])
        check(
            f"{arm}_51T_13V_disjoint",
            len(new_t_families) == 51
            and len(new_v_families) == 13
            and not new_t_families & new_v_families,
        )
        metric_min = min(
            t["curves"],
            key=lambda row: (
                row["scopes"]["added_validation"]["family_mse"],
                row["step"],
            ),
        )["step"]
        check(
            f"{arm}_BEST_family_selector",
            metric_min == t["best_step"]
            and t["selection"]["added_metric"] == "family_mse"
            and t["selection"]["public_non_regression"] is False,
        )
        for row in t["curves"]:
            compact = {
                "arm": arm,
                "step": row["step"],
                "training_forwards": row["training_forwards"],
                "measurement_forwards": row["measurement_forwards"],
                "forward_rows": row["forward_rows"],
                "scopes": {},
            }
            for name, scope in row["scopes"].items():
                compact["scopes"][name] = {
                    key: scope[key]
                    for key in (
                        "rows",
                        "mse",
                        "family_mse",
                        "sign_rows",
                        "sign_accuracy",
                        "saturation_fraction",
                        "stock_strata",
                        "calibration",
                    )
                }
                check(
                    f"{arm}_{row['step']}_{name}_calibration_rows",
                    sum(z["rows"] for z in scope["calibration"]) == scope["rows"],
                )
                if scope["stock_strata"]:
                    check(
                        f"{arm}_{row['step']}_{name}_stock_rows_MSE",
                        sum(z["rows"] for z in scope["stock_strata"].values())
                        == scope["rows"]
                        and math.isclose(
                            sum(
                                z["rows"] * z["mse"]
                                for z in scope["stock_strata"].values()
                            )
                            / scope["rows"],
                            scope["mse"],
                            abs_tol=1e-12,
                        ),
                    )
            curves.append(compact)
        for stock, initial in t["curves"][0]["scopes"]["added_train"][
            "stock_strata"
        ].items():
            stocks.append(
                {
                    "arm": arm,
                    "stock": stock,
                    "T_rows": initial["rows"],
                    "T_initial": initial,
                    "T_last": t["curves"][-1]["scopes"]["added_train"]["stock_strata"][
                        stock
                    ],
                    "V_rows": t["curves"][0]["scopes"]["added_validation"][
                        "stock_strata"
                    ][stock]["rows"],
                    "V_initial": t["curves"][0]["scopes"]["added_validation"][
                        "stock_strata"
                    ][stock],
                    "V_last": t["curves"][-1]["scopes"]["added_validation"][
                        "stock_strata"
                    ][stock],
                }
            )
    raw_stocks = Counter()
    for pair, number in x["generation_report"]["wall_stock_positions"].items():
        n = sum(int(a) for a in pair.split(","))
        group = "16..20" if n >= 16 else "8..15" if n >= 8 else "1..7" if n else "0..0"
        raw_stocks[group] += number
    check("generation_raw_stock_histogram", sum(raw_stocks.values()) == 2822)
    rows = v["D4_remaining_M6"]["rows"]
    by_key = {(row["kind"], row["parent"]): row for row in rows}
    check(
        "18_unique_D4_not24_execution",
        len(rows) == len(by_key) == 18
        and v["D4_remaining_M6"]["aggregate_unique_Search_calls"] == 18
        and v["D4_remaining_M6"]["semantic_comparisons"] == 24,
    )
    check(
        "original12_reused_exact",
        all(
            by_key[(row["kind"], row["parent"])] == row
            for row in v["D4_original12"]["rows"]
        ),
    )
    check(
        "C6_alias_no_calls",
        len(v["D4_remaining_M6"]["C_aliases"]) == 6
        and all(
            row["additional_Search_calls"] == 0
            for row in v["D4_remaining_M6"]["C_aliases"]
        ),
    )
    check(
        "D4_actual_nodes",
        sum(row["work"]["nodes"] for row in rows)
        == v["D4_original12"]["work_nodes"]
        + v["D4_remaining_M6"]["work_nodes_this_operation"]
        == 893657,
    )
    d4_table = []
    for parent in range(6):
        selected = {kind: by_key[(kind, parent)] for kind in ("BEST43", "M", "D")}
        check(
            f"D4_root{parent}_fullhistory_match",
            selected["BEST43"]["root"] == selected["M"]["root"] == selected["D"]["root"]
            and not selected["BEST43"]["root"]["synthetic"],
        )
        for kind, row in selected.items():
            observations = row["completed_depth_observations"]
            check(
                f"D4_{parent}_{kind}_horizon_restore_bits",
                row["completed_depth"] == row["request"]["depth"] == 4
                and row["request"]["node_cap"] == 2000000
                and row["request"]["time_limit_ms"] is None
                and row["parent_unchanged"]
                and struct.unpack("<I", struct.pack("<f", row["value"]))[0]
                == row["value_bits"]
                and observations[-1]["value_bits"] == row["value_bits"]
                and observations[-1]["action"] == row["action"],
            )
            check(
                f"D4_{parent}_{kind}_LMR_approx_safe_OFF",
                row["work"]["LMR_attempts"] == 0
                and all(
                    z["lmr_rule"] is None
                    and z["zero_stock_approx_method"] is None
                    and z["zero_stock_safe_race"] is False
                    for z in observations
                ),
            )
        d4_table.append(
            {
                "parent": parent,
                "ply": selected["BEST43"]["root"]["ply"],
                "root_identity": selected["BEST43"]["root"],
                "by_evaluator": {
                    kind: {
                        key: row[key]
                        for key in (
                            "action",
                            "value",
                            "value_bits",
                            "PV",
                            "completed_depth",
                            "work",
                            "Search_call_seconds",
                            "source",
                            "source_pointer",
                        )
                    }
                    for kind, row in selected.items()
                },
                "M_vs_BEST43_action_changed": selected["M"]["action"]
                != selected["BEST43"]["action"],
                "M_vs_BEST43_PV_changed": selected["M"]["PV"]
                != selected["BEST43"]["PV"],
            }
        )
    arena = []
    first_book = x["arena0_config.json"]["arena"]["book"]
    expected_lineages = {opening["lineage"] for opening in first_book["openings"]}
    total_nodes = 0
    for contrast in v["arena_remaining96"]["contrasts"]:
        batch = contrast["batch"]
        native = x[f"arena{batch}_result.json"]["report"]
        config = x[f"arena{batch}_config.json"]
        families = {row["family"] for row in contrast["family_summary"]["pairs"]}
        check(
            f"arena{batch}_shared16_complete_pairs",
            config["arena"]["book"] == first_book
            and {row["lineage"] for row in contrast["family_summary"]["pairs"]}
            == expected_lineages
            and len(expected_lineages) == 16
            and len(families) == 16
            and contrast["census"]["complete_pairs"] == 16
            and contrast["census"]["completed_games"] == 32
            and contrast["census"]["unknown_games"] == 0,
        )
        check(
            f"arena{batch}_saved_native_summary_exact",
            native["arena_summary"] == contrast["family_summary"]
            and native["all_workers_joined"]
            and native["stopped"] is None,
        )
        score = (contrast["candidate_wins"] + contrast["candidate_draws"] / 2) / 32
        check(
            f"arena{batch}_score",
            score
            == contrast["score"]
            == sum(row["score"] for row in contrast["family_summary"]["pairs"]) / 16,
        )
        check(
            f"arena{batch}_fixed_config",
            config["arena"]["tt_entries"] == 1048576
            and config["arena"]["return_reserve_ms"] == 5
            and config["arena"]["max_total_nodes"] == 250000000
            and config["max_plies"] == 200
            and all(
                engine["time_ms"] == 100
                and engine["max_nodes"] == 1000000
                and engine["ordering_profile"] == "control"
                and engine["lmr"] is True
                and engine["lmr_method"] == "depth_rank"
                for engine in config["engines"]
            ),
        )
        check(
            f"arena{batch}_same_image",
            config["arena"]["search_artifact_sha256"]
            == ["35e47e65effdb04763e7f7b38475514490915f6a97bfa285bfeb2dbe4cf449a2"] * 2,
        )
        nodes = contrast["operation_node_budget"][
            "charged_nodes_including_opaque_reservations"
        ]
        check(f"arena{batch}_disjoint_quota", nodes <= 250000000)
        total_nodes += nodes
        arena.append(
            {
                "comparison": contrast["comparison"],
                "W": contrast["candidate_wins"],
                "D": contrast["candidate_draws"],
                "L": contrast["candidate_losses"],
                "score": score,
                "native_CI95_reused": contrast["family_summary"]["bootstrap"][
                    "percentile_95"
                ],
                "bootstrap_unit": "complete family pair",
                "family_pairs": contrast["family_summary"]["pairs"],
                "node_budget": contrast["operation_node_budget"],
                "native_report_wall_seconds_nested": native["wall_seconds"],
                "completions": dict(
                    Counter(z["status"] for z in native["pump"]["completions"])
                ),
                "identities": x[f"arena{batch}_evaluator-identities.json"],
            }
        )
    check(
        "arena_C_alias_same_identity",
        x["arena1_evaluator-identities.json"][0]
        == x["arena1_evaluator-identities.json"][1],
    )
    check(
        "arena128_node_cap_and_census",
        total_nodes
        == v["arena_remaining96"]["total_charged_nodes"]
        == 726360091
        < 1000000000
        and v["arena_remaining96"]["completed_games"] == 128
        and v["arena_remaining96"]["goal"] == 127
        and v["arena_remaining96"]["draw"] == 1
        and v["arena_remaining96"]["UNKNOWN"] == 0,
    )
    check(
        "C_and_M_forward_arithmetic",
        c["forward_rows"] + m["forward_rows"] == 3874723
        and 3874723 + 120 + 2
        == v["changed_weights"][
            "conservative_forward_total_including_prior_failed_attempt"
        ]
        == 3874845
        < 6000000,
    )
    fees = {
        "generation": v["generation"]["outer_seconds_once"],
        "C_original_FAILED": provenance["values"]["C_outer"]["wall_seconds"],
        "M": v["fit_M"]["original_seconds_once"],
        "changed_weights_v2": v["changed_weights"]["original_seconds_once"],
        "identity_no_head": v["identity_view"]["original_seconds_once"],
        "D4_original12_Msetup_UNKNOWN": v["D4_original12"][
            "original_outer_seconds_once"
        ],
        "D4_genuine_M6": v["D4_remaining_M6"]["original_outer_seconds_once"],
        "arena_original_first32": v["arena_first32"]["original_outer_seconds_once"],
        "arena_remaining96": v["arena_remaining96"]["new_outer_seconds_once"],
    }
    check(
        "C_operation_FAILED_preserved",
        provenance["values"]["C_outer"]["outcome"] == "failed"
        and v["fit_C"]["original_operational_status_unchanged"] == "FAILED",
    )
    selected = {}
    for package in (inlet, training, provenance, cache_inlet, arena_manifest):
        for ref in package["refs"]:
            selected[ref["before"]["path"]] = ref
    selected[exposure_ref["path"]] = {"name": "M_added_visits_only", **exposure_read}
    stable = []
    for ref in selected.values():
        final = reference(ref["before"]["path"])
        check(f"stable_{ref['name']}", final == ref["before"])
        stable.append({**ref, "final": final, "final_exact": final == ref["before"]})
    stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(
        "selectedrefs-before-after.json",
        {
            "refs": stable,
            "readerSTOP": stop,
            "no_followed_model_library_corpus_or_RAW_payload_refs": True,
        },
    )
    save("exposure-added-only.json", exposure)
    save(
        "saved-checks.json",
        {
            "all_pass": all(CHECKS.values()),
            "checks": CHECKS,
            "source_or_producer_test_replay": 0,
        },
    )
    result = {
        "issue": "quoridor-4lc.421.1",
        "status": "ORIGINAL_SAVED_ANALYSIS_READY_FOR_ORDINARY_OWNER_ACCEPTANCE",
        "generation": {
            "census": v["generation"]["census"],
            "distinct_positions": 2822,
            "workers": 6,
            "stock_histogram_all_generated_rows": dict(raw_stocks),
            "canonical_T_families": 51,
            "canonical_V_families": 13,
            "raw_T": 2216,
            "V_all_rows": 606,
            "selected_T": 927,
            "selection_cap_32_per_game_not_independent_samples": True,
            "nominal_D6_selective_LMR": True,
        },
        "fit": {
            "updates_each": 29,
            "learning_rate": 0.0001,
            "warmup_updates": 10,
            "batch_each": 256,
            "C_new_public_rows_per_update": [0, 256],
            "M_new_public_rows_per_update": [128, 128],
            "new_draws": 3712,
            "new_distinct": 927,
            "new_visits_histogram": dict(Counter(z["visits"] for z in positives)),
            "C_BEST_step": 0,
            "M_BEST_step": 29,
            "C_BEST_aliases_frozen_BEST43": True,
            "M_BEST_equals_LAST": v["fit_M"]["selected_BEST_descriptor"]["sha256"]
            == v["fit_M"]["last_descriptor"]["sha256"],
            "curves": curves,
            "stock_scopes": stocks,
            "C_reflected_rows": c["reflected_rows"],
            "M_reflected_rows": m["reflected_rows"],
            "fit_logical_forwards": 3874723,
            "changed_weight_heads": 120,
            "prior_failed_attempt_conservative_head_bound": 2,
            "conservative_fit_and_correspondence_forwards": 3874845,
            "initial_shared_logical_rows_not_replayed": 428875,
            "public_game_family_coverage": "UNKNOWN; original metadata absent; no corpus scan",
        },
        "D4": {
            "unique_calls": 18,
            "original12_replayed": 0,
            "genuine_M_calls": 6,
            "C_semantic_aliases": 6,
            "semantic_entries": 24,
            "complete_unique": 18,
            "original_setup_M6_UNKNOWN_preserved": True,
            "total_nodes": 893657,
            "rows": d4_table,
            "M_action_changes_vs_BEST43": sum(
                z["M_vs_BEST43_action_changed"] for z in d4_table
            ),
            "M_PV_changes_vs_BEST43": sum(
                z["M_vs_BEST43_PV_changed"] for z in d4_table
            ),
            "fullwidth_finite_horizon_not_game_WDL": True,
        },
        "arena": {
            "games": 128,
            "pairs": 64,
            "shared_start_families": 16,
            "goal": 127,
            "draw": 1,
            "UNKNOWN": 0,
            "nodes": total_nodes,
            "node_cap": 1000000000,
            "separate_operation_cap": 250000000,
            "quota_transfer_or_refill": False,
            "contrasts": arena,
            "search_artifact_sha256_metadata_only": x["arena0_config.json"]["arena"][
                "search_artifact_sha256"
            ][0],
            "Build_metadata_only": arena_manifest["values"]["manifest"][
                "build_manifest"
            ],
            "C_vs_BEST43_same_typed_identity": True,
            "no_native_bootstrap_recomputed_or_arena_archive_decoded": True,
            "accepted_snapshot_depth_fallback_late_details_not_in_compact_summaries": "UNKNOWN; no archive reread",
        },
        "known_original_outer_seconds_counted_once": fees,
        "known_outer_subtotal_seconds_NOT_full_cost": math.fsum(fees.values()),
        "nested_times_not_added": True,
        "all_source_software_other_failed_helpers_LLM_admin_full_cost_continuous_RSS_physical_NN": "UNKNOWN",
        "validation_discrepancies": [
            name for name, passed in CHECKS.items() if not passed
        ],
        "readerSTOP": stop,
        "new_Search_fit_forward_game_solver_bootstrap": 0,
        "no_423_scale_resolution_in_this_phase": True,
    }
    save("result.json", result)
    print(
        json.dumps(
            {
                "all_checks_pass": all(CHECKS.values()),
                "discrepancies": result["validation_discrepancies"],
                "exposure_histogram": result["fit"]["new_visits_histogram"],
                "D4_action_changes": result["D4"]["M_action_changes_vs_BEST43"],
                "D4_PV_changes": result["D4"]["M_PV_changes_vs_BEST43"],
                "D4_table": [
                    {
                        "p": z["parent"],
                        "ply": z["ply"],
                        "values": {k: a["value"] for k, a in z["by_evaluator"].items()},
                        "actions": {
                            k: a["action"] for k, a in z["by_evaluator"].items()
                        },
                        "nodes": {
                            k: a["work"]["nodes"] for k, a in z["by_evaluator"].items()
                        },
                    }
                    for z in d4_table
                ],
                "raw_stocks": dict(raw_stocks),
                "known_original_outer_subtotal": result[
                    "known_outer_subtotal_seconds_NOT_full_cost"
                ],
                "readerSTOP": stop,
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
