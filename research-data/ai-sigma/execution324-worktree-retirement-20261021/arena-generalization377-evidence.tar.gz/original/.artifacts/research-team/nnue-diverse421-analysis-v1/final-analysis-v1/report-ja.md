421の固定試行は、64生成・二つの29更新fit・D4の18実呼出し・128対局まで実施済みである。混合Mは新Vのfamily-MSEを小さく改善したが、棋力改善は未確定。正式な重み/default昇格を支持せず、Mを今回の研究候補として保存する。Cの選択BESTはstep0の凍結BEST43そのものであり、C/BEST43の14勝18敗を学習による関数劣化へ読み替えない。

固定spec `afa79145`、実nativeの`search_artifact_sha256=35e47e65`、Build metadata `9bf66048`を参照した。HEAD再build・新forward・fit・Search・対局・bootstrapは0。モデル/ライブラリ/原RAWや対局archiveは読み直していない。設定と保存済みcurve、samplerの追加行visit countだけを用いた。

生成は4/8/12/16 plyの各16 requests、計64が全てGOAL、UNKNOWN0。実6 game workers・各1 search thread、固定D(0,8,tanh)/Control/PVS/TT1M/LMR ON-depth_rank、近似/safe OFF、名目D6・4M/手で、2,822 callsが全て名目D6完成した。434,615,074 nodesは全生成1G cap内である。selective D6を全幅探索や最適WDLと呼ばない。教師は実outcome zで、Dの検索値は解析用のまま。

保存cacheは64 canonical familyを51T/13Vに分け、raw T2,216行・V606行。Tだけを各game・各stock層8行以内で927行へ選択し、V606行は全て保持した。実viewは1 T game平均18.18行で、最大32/gameや層quotaは充足保証ではない。

| 残壁合計 | 全生成行 | 選択T行 | V全行 | MのV MSE：INITIAL→step29 |
| -------- | -------: | ------: | ----: | ------------------------ |
| 16–20    |       36 |      21 |    15 | 1.600743 → 1.575183      |
| 8–15     |      295 |     188 |    79 | 0.883087 → 0.868523      |
| 1–7      |    1,419 |     398 |   279 | 0.278837 → 0.276480      |
| 0        |    1,072 |     320 |   233 | 0.073597 → 0.072414      |

残壁16–20はTの約2.27%、Vの約2.48%だけである。層の穴を別層で補充していない。64展開へ増やしても、高壁数の入力が十分になったとはいえない。保存generationの`distinct_positions=2822`、samplerのdistinct row-ID=927は、それぞれの定義の件数であり、左右反転を含むNNUE入力のdistinctや統計的独立標本数へ昇格しない。

C=公開のみ256、M=新T128+公開128/batchで、同じBEST43・fresh Adam・LR1e-4・10更新linear warmup・T-only左右反転0.5・既存尺度から始めた。U=ceil(4×927/128)=29。各条件の訓練forwardは7,424行、Cの公開抽出7,424、Mの公開/新T抽出は各3,712。Mの`exposure.npz`中`added_visits.npy`だけを読んだ実countは、923行が4回、4行が5回、全927行で3,712回、平均4.0043回。公開samplerのseed系列は共通でも、公開露出量はCがMの2倍であり、純粋な多様性一因の比較ではない。

全opened公開V419,150・固定公開T panel8,192・新V606・選択新T927を、0/8/15/22/29で測定した。MのINITIALはCの成功観測を共有し、428,875行を再forwardしていない。選択は新V family-MSE最小、同点は早いstepで、公開V非悪化条件は設けていない。

| step | C 新V family-MSE | M 新V family-MSE | C 公開V MSE | M 公開V MSE |
| ---- | ---------------: | ---------------: | ----------: | ----------: |
| 0    |         0.297568 |         0.297568 |    0.423871 |    0.423871 |
| 8    |         0.297578 |         0.297054 |    0.423868 |    0.423869 |
| 15   |         0.297729 |         0.295995 |    0.423878 |    0.423873 |
| 22   |         0.297886 |         0.294993 |    0.423888 |    0.423888 |
| 29   |         0.297895 |         0.294023 |    0.423891 |    0.423912 |

MのBEST=LAST=step29、新V family-MSEはINITIAL比約1.19%低下、新V row-MSEは0.311417→0.307346、新T row-MSEは0.565935→0.556840。公開V row-MSEは約0.00004176増えた。Cは29更新を実行したが、選択family-MSEではstep0を上回らず、BEST=INITIALとなった。Cのstep29を実arenaのCモデルと取り違えない。

Mの新V符号正解率は530/606→531/606、飽和率は60.56%で同じ。新T符号正解率は738/927→735/927で、MSEと全指標が一様に改善したわけではない。残壁16–20のV符号正解は3/15のまま。層別MSE・符号・平均値、10等幅binの記述的calibrationはresultに保持した。小さい層を選んで一般優越を作らず、新VはBEST選択にも使ったVであり未使用のsealed評価ではない。公開corpusのgame/family欠測はUNKNOWNのまま、全域scanはしていない。

旧371の8ゲーム・217T/76V・約29/30反復・200更新とは、展開、抽出、露出、batch、LR、更新数などが同時に違う。今回が旧371のV悪化を再現しなかったことを、多様性だけの因果効果とはしない。同じ小規模混合を未実施として再発行しない。

凍結後D4は、同じ6親・Control/PVS/TT1M・LMR/近似/safe OFF・時間上限なし・2M/callで18 unique実呼出し、全て完成、893,657 nodes。Cの6件はBEST43の同じ重み/要求結果をaliasとして共有し、24 semantic entriesと18実呼出しを区別した。旧12成功を再実行せず、typed evaluator identityの誤結合で未入場だったM6だけを正規に実行した。元M setup UNKNOWN/FAILEDと費は上書きしていない。

| 親 / prefix ply | BEST43の着手 / root値 | Mの着手 / root値 | Dの着手 / root値 |
| --------------- | --------------------- | ---------------- | ---------------- |
| p0 / 4          | 13 / −0.412663        | 13 / −0.413027   | 13 / −0.197375   |
| p1 / 8          | 150 / −0.920775       | 150 / −0.913281  | 140 / 0.000000   |
| p2 / 12         | 204 / +0.956317       | 204 / +0.952913  | 22 / +0.099668   |
| p3 / 16         | 148 / +0.331933       | 14 / +0.274264   | 14 / −0.099668   |
| p4 / 4          | 14 / +0.430942        | 14 / +0.391616   | 14 / 0.000000    |
| p5 / 8          | 97 / +0.577031        | 97 / +0.578989   | 13 / 0.000000    |

着手は保存native ID。全6親でMの値が変わり、選択手は1親、PVは2親で変わった。同じ有限horizon・盤面/手番/完全履歴とparent復元のmetadataを照合し、正常なnative入力受入れは元collectorのauthorityを再用した。値/仕事の異評価器間一致を条件にせず、深いPVの新規再生もしない。

具体例p3は`fixed-d-family-000003`、16 ply・残壁5、prefix `[139,126,166,91,172,119,142,107,191,83,134,187,5,201,208,173]`。BEST43はaction148/PV `[148,67]`、Mはaction14/PV `[14,67,148]`、Dはaction14/PV `[14,67,85,93]`、nodesは順に30,847/25,317/23,282だった。各値は各評価器が選んだ手のroot検索値で、同じ候補手の強制値やstatic葉評価ではない。MとDの選択一致は正解/改善の証明ではなく、この一手が旧敗因を修正したともいえない。full prefix/完全履歴/valuebits/PVと原FileRef・JSON pointerは`candidate-example.json`に結合した。

初回arenaは同じ凍結image・16開始系列を4対照で共用、各二色32ゲーム、計128 unique games/64 complete pairs。127 GOAL+1真正draw、UNKNOWN0で、原op0の32成功を再用し、真正未入場op1..3の96だけをmigration後に回収した。各operationの250M quotaは独立、総726,360,091 nodes<1G、残余転用/補充/再演は0。100ms receipt/5ms reserve・1M/手・200 total ply・Control/PVS/TT1M/LMR ON-depth_rank、近似/safe OFFであり、D4のLMR OFF固定horizonとは別条件である。

| 対照（左が候補）   | W–D–L / 32 |    score | 原nativeのfamily-pair 95%区間 | charged nodes |
| ------------------ | ---------- | -------: | ----------------------------- | ------------: |
| M / BEST43（主要） | 18–0–14    |   56.25% | 37.5–71.875%                  |   124,076,722 |
| C / BEST43         | 14–0–18    |   43.75% | 31.25–56.25%                  |   147,519,359 |
| M / D              | 21–0–11    |  65.625% | 50.0–81.25%                   |   226,419,772 |
| C / D              | 17–1–14    | 54.6875% | 42.1875–68.75%                |   228,344,238 |

区間は保存済みnativeの10,000 resamplesをそのまま再用した。4対照の表示family名には比較名が付くが、正本book全体（16 prefix/完全履歴/root/source refs）とlineage集合が全対照でexactに同じである。64色pairや128ゲームを64/128個の独立開始系列に水増しせず、対照を合算しない。主要区間は50%を含み、副次M/Dも下限が50%に接する。M/C直接対局はなく、複数対照・shared starts・選択済みcheckpointの条件付き結果であり、Elo/非劣性/一般優越/正式昇格の証拠にはしない。

C/BEST43は保存typed identityが両側同じ`96a5…`で、CのBESTは元重みのalias。したがって14勝18敗を「公開継続でモデルが弱くなった」と説明できない。全体時計で切れる探索、色、履歴・TT/ordering状態、時刻/実行環境の変動や有限bookの不確実性を残す。同じ重みでも本条件で戦績が偏った事実は、Mの18勝14敗からも小標本の強さを読み過ぎない理由になる。今回のcompact summaryにないaccepted深さ・fallback/遅延等の詳細、孤立推論/探索費や物理forward、連続family RSSはUNKNOWNとし、archive再解凍で埋めない。native reportのpump `nn_calls=0`をnative NNUE forward0とは扱わない。

二fitの論理forwardはC2,151,799+M1,722,924=3,874,723。変更重みの24状態・18 child遷移の対応確認120 headsと、前回失敗に残した保守的2 heads上界を含め3,874,845≤6M。canonical identity viewはhead0。NNUEのSearch/arena仕事はこの訓練forward予算と別計上し、物理FT/head回数へ変換しない。

この選択参照からの原outer時間は、生成92.406842s、Cの原FAILED32.092758s、M141.428322s、変更重みv2 3.235790s、identity view3.348076s、D4原467.436874s+M新入場103.486473s、arena原32の453.373311s+残96の461.925801s。各一度の小計1,758.734246sで、nested native/Search/学習内部時計を加えていない。これは全費用ではなく、他の原FAILED・source/software・全LLM/helper/admin費はUNKNOWN。9p待ちやmigrationを含む外側時間から学習/探索の速度差を認定しない。

Cは全29更新/5観測を保存した後、Rootが存在しない新INITIAL/BESTを要求したため原operation FAILEDとなった。そのFAILEDを成功へ書き換えず、別saved validationとstep0 aliasとして採用した。raw fingerprintをtyped SHAと誤記したD4 setup、前回変更重み失敗、arena前入場失敗、NULL返却と後保存masks、収集helperの失敗も元refのまま保持した。

本解析のlocator/shape printerは3回失敗したが、原実験は再演していない。成功checkpoint後はprivate cacheを再用した。また、自作checkerの表示family文字列比較3件は誤った比較単位だったため、原check/resultを残し、正本book全体とlineageのexact対応だけを確認して訂正した。suffix加工、新classifier、原data/CI修正は0。Ruff/Prettier・保存算術/行数/露出/BEST/alias/census/反復しない合成確認とselected FileRefs前後照合を実施し、reader STOP・directwait/reap・fresh identity/handles/TMP/leases/owned[]を同directoryに保存する。

次の優先候補は一つだけ、高壁数の有効行/系列coverageを将来のデータ規模判断で明示すること。今回T21/V15の薄さを見ずに局数や更新だけを増やす根拠はない。これは追加生成/fit/評価の発行ではなく、423の未変換pilotから規模を推定することもしない。421の本人leafは元claimantのin_progressを保ち、通常owner受入れへreadinessを一度324へ渡す。423は別の実依存として、このreader STOP後にだけ扱う。旧342.17/323 USERPAUSE・製品/generator defaults・models/weights/seals・foreign変更は不変である。
