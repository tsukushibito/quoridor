"""Check the finite protocol's arithmetic without reading any model or data bank."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat


OWN = Path(__file__).resolve().parent


def ref(path):
    meta = path.stat()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": meta.st_size,
        "mode": f"{stat.S_IMODE(meta.st_mode):04o}",
    }


def main():
    spec = json.loads((OWN / "spec.json").read_text())
    contract = json.loads((OWN / "contract-ref.json").read_text())
    assert (contract["sha256"], contract["bytes"]) == (
        spec["contract_sha256"],
        spec["contract_bytes"],
    )
    assert len(set(spec["seeds"].values())) == len(spec["seeds"])
    completed = json.loads((OWN / "completed-d6-cap-evidence.json").read_text())
    subject = next(
        s
        for s in completed["strata"]
        if s["evaluator"] == "distance" and s["profile"] == "control"
    )
    root = next(r for r in subject["roots"] if r["request"]["depth"] == 6)
    assert root["statuses"][1:3] == ["COMPLETE", "COMPLETE"]
    assert root["completed_depths"][1:3] == [6, 6]
    assert root["work"][1]["nodes"] == root["work"][2]["nodes"] == 1431825
    assert spec["generation"]["max_nodes_per_move"] == 4000000
    rows_max = 64 * 32
    updates_max = (4 * rows_max + 127) // 128
    assert updates_max == 64
    eval_max = 9 * (419150 + 8192 + 64 * 200 + rows_max)
    train_max = 2 * updates_max * 256
    total_max = eval_max + train_max + 1024
    assert total_max == 4013502 < 6000000
    checks = {
        "status": "FINITE_DESIGN_ARITHMETIC_PASS_NO_NUMERICAL_RESEARCH",
        "selected_generation_move_cap": 4000000,
        "saved_completed_D6_nodes": 1431825,
        "nominal_64_unique": {
            "T_families": 51,
            "V_families": 13,
            "R_max": 1632,
            "U_max": 51,
        },
        "duplicate_families_conservative": {
            "R_max": rows_max,
            "U_max": updates_max,
            "newV_rows_upper": 12800,
        },
        "forward_upper": {
            "bank_evaluations": eval_max,
            "training": train_max,
            "changed_weights": 1024,
            "total": total_max,
            "remaining": 6000000 - total_max,
        },
        "small_R_rounding_example": {
            "R": 1,
            "U": 1,
            "added_draws": 128,
            "per_row": 128,
        },
        "finite_search_node_cap": 6 * 4 * 2000000,
        "arena_games_cap": 16 * 2 * 4,
        "bulk_B": 256 * 1024**2,
        "reference_files": [
            ref(OWN / n)
            for n in (
                "spec.json",
                "spec-ja.md",
                "contract-ref.json",
                "completed-d6-cap-evidence.json",
                "prior371-reference.json",
            )
        ],
        "input_reader_STOP": datetime.now(timezone.utc).isoformat(),
        "identity": {
            "pid": os.getpid(),
            "start_ticks": Path("/proc/self/stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19],
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        },
        "TMP": [],
        "leases": [],
        "children": [],
        "scope": "saved scalar arithmetic only; no corpus, source, model, native or forward",
    }
    (OWN / "design-check.json").write_text(
        json.dumps(checks, ensure_ascii=False, indent=2) + "\n"
    )
    print(
        json.dumps(
            {k: v for k, v in checks.items() if k != "reference_files"},
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
