421.1 本人所有で ready/show → close → show(closed) → backup sync を実施しました。

原 assignee codex:01a118a1-aef1-7252-b21b-42f07dd5b1e6 を保持。publication e3e66d6、原 report72a6dbac/失敗/費/pause は不変、source/science再演0。423.1は変更せずin_progressの一度のcount-cost解決を続けます。

実owner-close guard STOP2026-10-16T15:25:58.775237Z、直接wait/reap/全exact children fresh absent/handles closed/TMP・lease・owned[]。

receipt: /workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-diverse421-analysis-v1/final-analysis-v1/owner-close-v1/receipt.json
