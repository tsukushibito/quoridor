# 421 固定設計：多様なoutcomeデータを少ない反復で追加する

新421だけの事前設計であり、新規数値はまだない。371は実施済みで、混合は悪化を軽減したが、追加V・公開VともINITIALより悪かった。今回も教師は実outcomeのzSTMで、q混合・特徴・幅・尺度・lossは変更しない。旧342.17途中RAW、323、fits96、414、製品/generator既定は再開しない。[今回契約](/workspaces/quoridor/.artifacts/research-policy/nnue-diverse-mixture-20261015.md)のSHA e3cb5b30／16326Bを束縛する。

**生成の各手capを4,000,000 nodesに一度固定する。** 元408の保存summaryで、固定D・Control・depth_rank・TT1Mのcold family34は、累積1,431,825 nodesで名目D6を完成し、二反復のworkは同じだった。選択した根拠は[completed-d6-cap-evidence.json](completed-d6-cap-evidence.json)（正本c7ffe037／197883B、`/strata/2/roots/1`、B位置1/2）。2Mから未知の展開への余裕を取り4Mを選ぶ。8Mの必要性・4Mの最適性・新しい全局面の完成は示していない。古い一親の二反復は独立二例ではない。元2M配送履歴は残し、新421結果による増枠・再実行・補充はしない。全生成1G nodes、64requests、序盤込み200plyは据え置く。

seedは[spec.json](spec.json)へ固定した。生成prefix42120261015、評価prefix42120261016、両学習42120261017、左右反転42120261018、公開sampler42120261019、新T cycling42120261020、arenaと既存family bootstrap42120261021、公開T8192 panel42120261022。既存ownerの同じseed系列を使い、独自hash/registryは足さない。

生成64slotsと評価16slotsをそれぞれ長さ4/8/12/16でround-robinにする。各slotの既存32候補だけを使う。既存canonical family ownerで左右反転・延長・同endpointの推移閉包をまとめ、実Fのfloor(4F/5)をT、残りをVとする。評価開始は生成T/Vと既存評価bookから同じ規則で分離する。IDの違いを独立性の根拠にしない。実prefix・全履歴・schedule・分割・評価bookのrefsを初回結果より前に凍結する。衝突・終端・欠測slotを新requestで埋めない。公開全域との未知の履歴重複はUNKNOWNを残す。

固定D(0,8,tanh)、Control/PVS/TT1048576、LMR ON/depth_rank、近似・safe OFF、名目D6を明示する。game固有の二sessionを一workerで順次使う。widthは実physical/RAMで1..8の一値をentry前に解決し、幅比較はしない。TT本体は現ABIなら1colour83,886,128B、8game二色で1,342,178,048Bであり、その他RSSやallocatorは別。family4GiBを本体見積りだけで資格済みにしない。UNKNOWN/不完成/200ply/error/cancelへ勝敗を付けず、正規converterが受け入れたGOAL/真正threefoldだけをoutcome教師にする。raw±2の旧maskは持ち込まない。

新Tだけを各gameの残壁16..20／8..15／1..7／0へ分け、各層n<=8なら全部、n>8ならchronological index `floor(i*(n-1)/7), i=0..7`を選ぶ。空層の枠は移さない。pre-action rowの既存geometry stocksとrow_game_codesを使い、schemaや詳細Game JSONのtraining再読は不要。`mixture.train_stock_strata`と`train_family_row_cap:null`を用い、Vは全適格行。game最大32行でもgame/family均等・独立32例とは呼ばない。

Cは公開256、新D0、Mは公開128＋新D128、同batch256、同BEST43／既存尺度から独立fresh Adamで始める。実選択T行RからU=ceil(4R/128)、最大64を両条件に使う。LR1e-4、最初W=min(10,U)更新はj/Wのlinear warmup、その後constant、betas(.9,.999)/eps1e-8/decay0、train-only LR反転.5。公開uniform streamのseedと第n抽出を共有するが、C/Mの消費数が256/128なので更新ごとの入力一致は要求しない。新Tは既存shuffled cyclingで実行ごとの行露出を保存する。

64requestsが64unique familiesなら51T/13V、R<=1632、U<=51である。重複groupに複数requestがある場合、Tgame数は51とは限らないため、この上界を一般化しない。保守的にはR<=64×32=2048、U<=64。`4R<=128U<4R+128`だが、小Rで各行4/5回になるとは限らない。例えばR=1ではU=1でも128回であり、この端数効果を隠さない。T/V空なら結果を保全して停止し、追加生成・split変更・200updatesへの復帰はしない。

step0とceil(kU/4),k=1..4の重複を除き最大5点。full opened-publicV419150、全newV、固定公開T8192、選択newTを測る。INITIALは実モデル・尺度・bank identityに束縛した一つの観測を両条件で参照する。`selector.added_metric=family_mse`は各newV family内のSSE/countを求めてfamily間で算術平均する。BESTはINITIALを含む最小値・同点早いstep、`public_non_regression=false`で公開Vは別監視。arenaを選び直しに使わない。INITIAL/BEST/実LASTだけを保持し、同一重みの同じ成功測定は共有する。

校正は同じ予測からp=(v+1)/2を10等幅binに分け、t=(z+1)/2の平均との隔たりとnを記述する（最後のbinは1を含む、draw target=.5）。勝率の資格ではない。符号一致はz=±1の分母、予測0は正解にせず、drawは件数・|v|を別記。publicのfamily/history欠測を仮のfamilyで補完しない。追加forwardは不要。

最大forwardは、共有INITIAL＋両条件各4点=9観測、保守的newV<=64×200=12800、newT<=2048より、`9×(419150+8192+12800+2048)+2×64×256+1024 = 4,013,502`。最後の1024は変更重みだけの最大128状態に必要なPython/native full/delta/undo/尺度対応のlogical row上限で、実数を記録する。6Mまで1,986,498の余裕があるが、新しい観測を自動追加する枠ではない。実bank行数とcached INITIAL identityをentry時に照合する。学習forwardとSearch/arenaの仕事は別分母。

凍結評価bookの実eligible ID先頭最大6親を結果前に固定し、BEST43/C/M/D、D4、LMR OFF、Control/PVS/TT1M、近似safe OFF、timeなし、最大24calls×2M=48M。初回arenaはM/BEST43、C/BEST43、M/D、C/D、最大16family二色=128games/64pairs。同100ms receipt/5ms reserve/1M/200ply、全arena1G、LMR ON/depth_rank。他は共通。同16familyの多重対照を独立標本へ増やさない。M/C直接対局はなく、MSEやD一致だけで強さ・原因を確定しない。負の結果・INITIAL選択・UNKNOWNでも追加fit/seed/roots/refillを出さない。

生成・conversion/view・二模型/曲線・有限確認・arena・archive/control/failure/serialTMPは既存whole256MiB guardへ含め、部分停止を許す。49,420,488,704B＋実420増分の保存境界とdecimal50GBは324がscience entry時に合成する。共有targetの再課金、減少refund、旧RAW削除はしない。今回の変更ownerだけを独立確認し、source/software/image/実入力と資源が成立した各工程から進める。Root/人間ACK・親close・全員完了は入口にしない。

本人421.1は設計返却後も同claimantの実dependencyとして開いたまま元の結果を待ち、最後に保存分析・verify/close/backupを行う。420の原FAILEDと保存分析は別に完了する。source/LLM/admin全費・continuous peak・実global容量はUNKNOWN、全旧pause/model/default/RAWFAILEDを維持する。
