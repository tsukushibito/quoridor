"""One stopped source receipt and one directed post-work observation, no Main."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import stat

os.sched_setaffinity(0, {3})
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
HERE = Path(__file__).resolve().parent
OWN = Path.cwd()


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
phases = []
children = []
for name in [
    "intake-v1",
    "intake-v2",
    "edit-v1",
    "static-v1",
    "static-v2",
    "final-v1",
    "final-format-v1",
]:
    path = HERE / name / "result.json"
    phase = json.loads(path.read_text())
    assert not phase["TMP_remaining"] and not (HERE / name / "TMP").exists()
    phases.append(
        {
            "ref": ref(path),
            "status": phase["status"],
            "reader_STOP": phase["reader_STOP"],
            "primary": phase["primary"],
        }
    )
    for command in phase["checks"]:
        returned = command.get("guardian_return")
        if not returned or not returned.get("child"):
            continue
        original = returned["child"]
        proc = Path(f"/proc/{original['pid']}/stat")
        fresh = None
        if proc.exists():
            fields = proc.read_text().rsplit(")", 1)[1].split()
            fresh = {"pid": original["pid"], "start_ticks": fields[19], "boot_id": boot}
        assert fresh != original
        assert returned["direct_child_reaped"] and not returned["remaining"]
        assert returned["cleanup_complete"] and returned["handle_closes_complete"]
        assert command["capture_complete"]
        disk_ref = command["persisted_process_receipt"]
        disk_path = Path(disk_ref["path"])
        assert ref(disk_path) == disk_ref
        disk = json.loads(disk_path.read_text())
        children.append(
            {
                "phase": name,
                "command": command["name"],
                "original": original,
                "fresh": fresh,
                "status": "absent" if fresh is None else "different",
                "directwait_exit": returned["exit_code"],
                "direct_reaped": True,
                "handles_complete": True,
                "cleanup_complete": True,
                "fullcapture": command["full_log"],
                "persisted_receipt": disk_ref,
                "returned_mask": returned.get("signal_mask_restoration"),
                "original_disk_mask": disk.get("signal_mask_restoration"),
                "returned_persist": returned.get("final_record_persist"),
                "original_disk_persist": disk.get("final_record_persist"),
                "launch_policy": returned.get("launch_policy"),
                "ordinary_seconds": returned["wall_seconds"],
            }
        )
proof = json.loads((HERE / "static-proof.json").read_text())
plan = json.loads((HERE / "verification-plan.json").read_text())
assert proof["new_tests"] == plan["new_names"] and proof["new_count"] == 6
for subject in proof["subjects"]:
    assert ref(Path(subject["after"]["path"])) == subject["after"]
refs = {
    name: ref(HERE / name)
    for name in [
        "shared-signed402.patch",
        "shared-signed402.inverse.patch",
        "static-proof.json",
        "report-ja.md",
        "verification-plan.json",
        "current-intake.json",
        "test-intake.json",
    ]
}
refs.update(
    {f"{i}.Main-before.gz": ref(HERE / f"{i}.Main-before.gz") for i in range(5)}
)
seen = set()
allocated = logical = files = 0
for root in [HERE, *[Path(s["after"]["path"]) for s in proof["subjects"]]]:
    for path in [root] if root.is_file() else [root, *root.rglob("*")]:
        info = path.lstat()
        assert not stat.S_ISLNK(info.st_mode)
        key = (info.st_dev, info.st_ino)
        if key in seen:
            continue
        seen.add(key)
        allocated += info.st_blocks * 512
        if stat.S_ISREG(info.st_mode):
            logical += info.st_size
            files += 1
fs = os.statvfs(HERE)
available = fs.f_bavail * fs.f_frsize
assert available >= 4 * 1024**3
result = {
    "status": "STOPPED_SHARED_SIGNED_SOURCE_STATIC_PASS_NATIVE_SCIENCE_PENDING",
    "issue": "quoridor-4lc.402.1",
    "claimant": "codex:01a11004-79f3-7c20-872c-432a2c347664",
    "context": {
        "turn": "01a13c6e-af12-7a93-a204-65a4993770f3",
        "cwd": str(OWN),
        "model": "gpt-6.1-sol",
        "effort": "high",
        "sandbox": "danger-full-access",
        "approvalPolicy": "never",
        "verified_before_first_command": True,
    },
    "source_reader_STOP": phases[-1]["reader_STOP"],
    "source_metadata_stamp": datetime.now(timezone.utc).isoformat(),
    "canonical_common_env_release": "normal guard/lease/project-env wrapper return; independent release UTC UNKNOWN",
    "owned_readers": [],
    "owned_writers": [],
    "owned_children": [],
    "owned_jobs": [],
    "owned_handles": [],
    "owned_TMP": [],
    "owned_leases": [],
    "metadata_scope": "Guarded source commands directwaited; this small private receipt write then exit; only later admin/Beads/send",
    "phases": phases,
    "original_children": children,
    "fast_nested_patch_Node_children": "not individually identified; bounded original guardian session/observed descendants/direct subprocess waits/TMP removal; fast PID/start UNKNOWN",
    "refs": refs,
    "subjects": proof["subjects"],
    "protected": proof["protected"],
    "new_Rust_tests": proof["new_tests"],
    "new_Rust_count": 6,
    "affected_existing_tests": plan["affected"],
    "affected_expected": 4,
    "software_status": "UNBUILT/UNTYPED/UNRUN; formatter/static pass is not native/type/test success",
    "API": "existing profiles/set_lmr/factory/method/namespace unchanged; private shared_signed_ordering + signed_keys + deferred_signed/SignedKeys",
    "score_only_profile_difference": "Control goals-only/history; Cheap adds exact unchanged static scores/coefficients/genuine maps/validation at shared preparation point",
    "LMR": "unchanged late4/depth3/minus1/PVS full-depth confirmation; same frozen key protects TT/goal/killers; selective nominal depth unchanged",
    "diagnostics": "both shared targets actual prepared/selected/tail sorted; full-order adjacency only assessed eager nodes, first choice versus tiers+ID measures history+static combined; no observation-only sort/copy/scan OFF",
    "measurement_companion": "no field/type/code change needed; Root consumer description must preserve denominator and combined first-choice semantics",
    "stack_cache_copy_RSS_runtime_hit_speed": "UNKNOWN; fixed key information209x8=1672B, not sizeof/peak or benefit",
    "Root_remaining": "research+research-diagnostics compile, new6+affected4, affected Clippy/release/genuine image, one related key/TT-first/history/LMR/error/diagnostic review; only Root selected new96calls/48sessions288M +128games",
    "Main_Git_index_Cargo_native_test_Search_model_geometry_Perf_game_fit_writes_calls": 0,
    "pause": "mixed/learner/323 USERPAUSE; defaults/models/weights/seals/oldfits96/393398rejection/oldRAWFAILEDfeesUNKNOWN preserved",
    "usage": {
        "scope": "OWN402 evidence/beforegzips/FAILED captures + six changed AI source subjects, inode dedup; before finalreceipt/admin",
        "storage_budget": None,
        "allocated_B": allocated,
        "regular_logical_B": logical,
        "files": files,
        "actual_FS_available_B": available,
        "FS_reserve_B": 4 * 1024**3,
        "global_decimal_cap_B": 50_000_000_000,
        "whole_global_actual": "UNKNOWN",
        "continuous_peak": "UNKNOWN",
    },
}
(HERE / "source-STOP.json").write_text(json.dumps(result, indent=2) + "\n")
stop = ref(HERE / "source-STOP.json")
(HERE / "handoff.txt").write_text(
    "402.1 one frozen sourceSTOP "
    + json.dumps(stop)
    + "\n"
    + "Current AI2+owning tests3+newmodule1 sparse forward/inverse + protected/currentbefore/newabsence/scopedformat PASS. Shared signed/no-policy Control/Cheap samekey/TTfirst/minfirst/frozen deferred tail; only exact unchanged score owner differs. No publicAPI/method/TT namespace/LMR math change. New6+affected4 UNBUILT/UNTYPED/UNRUN, native/science0.\n"
    + "Diagnostics actualprepared/selected/sorted, no hidden tail sort; first-choice change is history+static combined, full adjacency denominator only eager/root. No runner field change; report/plan exactrefs in STOP. TT Cheap scoring begins only if siblings needed; genuine map/validator owner byteexact. Stack/cache/copy/RSS/frequency/speed UNKNOWN.\n"
    + "Source readerSTOP "
    + phases[-1]["reader_STOP"]
    + "; originalchildren freshlyabsent/different/directwait/reap/handles/fullcapture/TMPgone/owned[]. Original static-v1 helper pubfn extractionFAILED preserved, ordinary helper repair static-v2/final PASS; masks/persist original vs returned separate. Oneaffectedusage "
    + str(allocated)
    + " allocatedB/storageNone/globalactualUNKNOWN before receipt/admin.\n"
    + "Root genuine software/one boundary review/newselected96+128 only; no sourceclear->adoption/old400 replay/default change/pausedmixed resume. Leaf staysin_progress until acceptance; current324 only/noACK.\n"
)
print(
    json.dumps(
        {
            "source_STOP": stop,
            "owned": [],
            "allocated_B": allocated,
            "new_Rust": 6,
            "native": "UNBUILT/UNTYPED/UNRUN",
        }
    )
)
