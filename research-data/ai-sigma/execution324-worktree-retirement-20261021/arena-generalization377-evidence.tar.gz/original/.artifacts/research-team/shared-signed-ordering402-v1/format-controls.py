"""Scoped installed project formatting of handwritten JSON controls."""

import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
paths = sorted(HERE.glob("*-commands.json")) + [HERE / "verification-plan.json"]
for path in paths:
    raw = path.read_bytes()
    before = json.loads(raw)
    saved = path.with_suffix(path.suffix + ".before-format.txt")
    if not saved.exists():
        saved.write_bytes(raw)
    subprocess.run(
        [
            "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier",
            "--config",
            "/workspaces/quoridor/tools/research-quality/.prettierrc.json",
            "--write",
            str(path),
        ],
        check=True,
        timeout=120,
    )
    assert json.loads(path.read_bytes()) == before
print("Only owned handwritten JSON formatted; executed argv/data preserved")
