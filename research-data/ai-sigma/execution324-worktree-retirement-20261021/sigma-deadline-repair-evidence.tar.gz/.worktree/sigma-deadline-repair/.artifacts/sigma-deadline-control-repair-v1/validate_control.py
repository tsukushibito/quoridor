"""Finite owned NN0 validation; no live model, science job, or shared target."""

import ctypes
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
WT = ROOT.parent.parent
MAIN = Path("/workspaces/quoridor")
LIMIT = 512 * 1024 * 1024
TARGET_LIMIT = 768 * 1024 * 1024
TARGET = ROOT / "target"
TMP = ROOT / "TMP"
PHASE = sys.argv[1]
COMMANDS = {
    "2": [
        [
            "cargo",
            "test",
            "--offline",
            "--locked",
            "-p",
            "quoridor-runner",
            "--lib",
            "sigma_",
            "--",
            "--test-threads=1",
        ],
        [
            "cargo",
            "test",
            "--offline",
            "--locked",
            "-p",
            "quoridor-runner",
            "--test",
            "sigma_clock",
            "--no-run",
            "--message-format=json",
        ],
        [
            "cargo",
            "clippy",
            "--offline",
            "--locked",
            "-p",
            "quoridor-runner",
            "--lib",
            "--",
            "-D",
            "warnings",
        ],
    ],
}

COMMANDS["5"] = [
    [
        "cargo",
        "test",
        "--offline",
        "--locked",
        "-p",
        "quoridor-runner",
        "--lib",
        "sigma_clock::tests::packing_consumes_admitted_operation_and_communication_reserve",
        "--",
        "--exact",
        "--test-threads=1",
    ],
    [
        "cargo",
        "test",
        "--offline",
        "--locked",
        "-p",
        "quoridor-runner",
        "--lib",
        "runtime::sigma_receipt_tests::communication_delay_uses_actual_authority_receipt_not_engine_timestamp",
        "--",
        "--exact",
        "--test-threads=1",
    ],
    [
        "cargo",
        "test",
        "--offline",
        "--locked",
        "-p",
        "quoridor-runner",
        "--test",
        "sigma_clock",
        "--no-run",
    ],
]

# Related R01/R02 repairs only: new definitions and the changed controller route.
COMMANDS["6"] = [
    [
        "cargo",
        "test",
        "--offline",
        "--locked",
        "-p",
        "quoridor-runner",
        "--lib",
        f"runtime::sigma_receipt_tests::{name}",
        "--",
        "--exact",
        "--test-threads=1",
    ]
    for name in [
        "alpha_receipt_rule_violation_precedes_lateness_without_state_application",
        "disproven_choice_packing_communication_disables_next_inference_without_rescuing_errors",
        "slow_legality_does_not_disprove_decision_communication",
        "actual_delayed_packing_disproves_only_communication_and_drains_original_error",
        "actual_timed_controller_freezes_action_drains_then_starts_opponent",
    ]
] + [
    [
        "cargo",
        "test",
        "--offline",
        "--locked",
        "-p",
        "quoridor-runner",
        "--test",
        "sigma_clock",
        "--no-run",
    ],
    [
        "cargo",
        "clippy",
        "--offline",
        "--locked",
        "-p",
        "quoridor-runner",
        "--lib",
        "--",
        "-D",
        "warnings",
    ],
]


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def allocation(paths):
    seen = set()
    total = 0
    for path in paths:
        if not path.exists():
            continue
        for base, _, files in os.walk(path):
            for item in [Path(base), *(Path(base) / name for name in files)]:
                try:
                    info = item.lstat()
                except FileNotFoundError:
                    continue
                key = info.st_dev, info.st_ino
                if key not in seen:
                    seen.add(key)
                    total += info.st_blocks * 512
    return total


def family(parent, tracked):
    pending = [parent]
    rss = 0
    while pending:
        pid = pending.pop()
        try:
            data = Path(f"/proc/{pid}/status").read_text()
            rss += (
                int(
                    next(
                        (
                            line.split()[1]
                            for line in data.splitlines()
                            if line.startswith("VmRSS:")
                        ),
                        "0",
                    )
                )
                * 1024
            )
            children = [
                int(s) for s in Path(f"/proc/{pid}/task/{pid}/children").read_text().split()
            ]
        except FileNotFoundError:
            continue
        tracked.update(children)
        pending.extend(children)
    return rss


def terminate(tracked, sig):
    for pid in sorted(tracked, reverse=True):
        try:
            os.kill(pid, sig)
        except ProcessLookupError:
            pass


def main():
    if PHASE in {"3", "4"}:
        built = json.loads((ROOT / "integration-binary.json").read_text())
        binary = Path(built["path"])
        assert binary.is_relative_to(TARGET)
        assert hashlib.sha256(binary.read_bytes()).hexdigest() == built["sha256"]
        assert all(
            hashlib.sha256((WT / path).read_bytes()).hexdigest() == digest
            for path, digest in built["source_sha256"].items()
        )
        COMMANDS[PHASE] = [[str(binary), "--test-threads=1", "--nocapture"]]
        if PHASE == "4":
            COMMANDS[PHASE][0].extend(
                [
                    "--exact",
                    "stale_zero_and_mismatched_cost_qualification_fail_before_requests",
                ]
            )
    assert PHASE in COMMANDS
    contracts = {
        "docs/design/sigma-deadline-control-repair-v1.md": "04062382f70648cdfd722e59c35be1100719169097a04749b0046ea5a19a280d",
        "research-data/ai-sigma/teacher-distance-tanh-v1/resources-pilot.json": "44c71bc56428705bfd6efc3c8c3531011c63dbf00a16a077a9a25cdac0cf8fa4",
    }
    for path, digest in contracts.items():
        assert hashlib.sha256((MAIN / path).read_bytes()).hexdigest() == digest
    lock_path = MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock"
    with lock_path.open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print(
                json.dumps(
                    {
                        "entry": "REFUSED_before_Popen",
                        "reason": "canonical_Cargo_writer_busy",
                        "utc": utc(),
                    }
                )
            )
            return 3
        affinity = {0, 2, 4, 6} if PHASE in {"3", "4"} else {3}
        assert affinity.issubset(os.sched_getaffinity(0))
        topology = {}
        for cpu in affinity:
            base = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
            topology[cpu] = [
                int((base / "physical_package_id").read_text()),
                int((base / "core_id").read_text()),
            ]
        if PHASE in {"3", "4"}:
            assert len({tuple(t) for t in topology.values()}) == 4
        os.sched_setaffinity(0, affinity)
        ctypes.CDLL(None).prctl(36, 1, 0, 0, 0)
        mem = (
            int(
                next(
                    line.split()[1]
                    for line in Path("/proc/meminfo").read_text().splitlines()
                    if line.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        space = os.statvfs(WT)
        assert mem > LIMIT + 1024 * 1024 * 1024
        assert space.f_bavail * space.f_frsize > 1024 * 1024 * 1024
        rows = subprocess.run(
            ["ps", "-eo", "pid,comm,args"], capture_output=True, text=True, check=True
        ).stdout.splitlines()
        names = {
            "cargo",
            "rustc",
            "perf",
            "quoridor-runner",
            "chromium",
            "chrome",
            "Xvfb",
            "teacher-qualify",
        }
        conflicts = [
            row
            for row in rows[1:]
            if len(row.split(None, 2)) >= 2 and row.split(None, 2)[1] in names
        ]
        assert not conflicts, conflicts
        vram = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=memory.used,memory.total",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert vram.returncode == 0
        sources = [
            "crates/quoridor-runner/src/runtime.rs",
            "crates/quoridor-runner/src/sigma_clock.rs",
            "crates/quoridor-runner/tests/sigma_clock.rs",
            "crates/quoridor-runner/tests/fixtures/sigma-clock-config.json",
        ]
        binding = {path: hashlib.sha256((WT / path).read_bytes()).hexdigest() for path in sources}
        env = os.environ.copy()
        env.update(
            CARGO_TARGET_DIR=str(TARGET),
            TMPDIR=str(TMP),
            CARGO_BUILD_JOBS="1",
            CARGO_PROFILE_DEV_DEBUG="0",
            CARGO_PROFILE_TEST_DEBUG="0",
            CARGO_INCREMENTAL="0",
            CARGO_NET_OFFLINE="true",
        )
        record = {
            "START_utc": utc(),
            "CPU_affinity": sorted(affinity),
            "reported_topology": topology,
            "topology_limit": "WSL reported distinct cores; P/E and scheduler isolation not certified",
            "cpu_quota": Path("/sys/fs/cgroup/cpu.max").read_text().strip(),
            "memory_cgroup_max": Path("/sys/fs/cgroup/memory.max").read_text().strip(),
            "jobs": 1,
            "family_RAM_upper_B": LIMIT,
            "target_deps_TMP_upper_B": TARGET_LIMIT,
            "whole_upper_B": 1073741824,
            "source_sha256": binding,
            "contract_sha256": contracts,
            "lock": str(lock_path),
            "MemAvailable_B": mem,
            "filesystem_available_B": space.f_bavail * space.f_frsize,
            "VRAM_metadata_MiB": vram.stdout.strip(),
            "named_conflicts": conflicts,
            "commands": [],
            "family_observed_peak_B": 0,
            "target_TMP_observed_peak_B": 0,
            "guard_failure": None,
        }
        begin = time.monotonic()
        for index, command in enumerate(COMMANDS[PHASE], 1):
            tracked = set()
            with (ROOT / f"software-{PHASE}-{index}.log").open("xb") as log:
                process = subprocess.Popen(
                    command, cwd=WT, env=env, stdout=log, stderr=subprocess.STDOUT
                )
                tracked.add(process.pid)
                command_record = {
                    "command": command,
                    "START_utc": utc(),
                    "pid": process.pid,
                }
                record["commands"].append(command_record)
                (ROOT / f"software-{PHASE}-start.json").write_text(
                    json.dumps(record, indent=2) + "\n"
                )
                print(json.dumps(command_record), flush=True)
                while process.poll() is None:
                    rss = family(os.getpid(), tracked)
                    target = allocation([TARGET, TMP])
                    record["family_observed_peak_B"] = max(record["family_observed_peak_B"], rss)
                    record["target_TMP_observed_peak_B"] = max(
                        record["target_TMP_observed_peak_B"], target
                    )
                    horizon = 3.8 if PHASE == "4" else 4 if PHASE == "3" else 118
                    reason = None
                    if rss > LIMIT:
                        reason = "family_RAM"
                    elif target > TARGET_LIMIT:
                        reason = "target_TMP_bytes"
                    elif time.monotonic() - begin > horizon:
                        reason = f"whole_phase_{horizon}s"
                    elif os.fstat(log.fileno()).st_size > 1048576:
                        reason = "log_1MiB"
                    if reason:
                        record["guard_failure"] = reason
                        terminate(tracked, signal.SIGTERM)
                        break
                    time.sleep(0.1)
                try:
                    result = process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    terminate(tracked, signal.SIGKILL)
                    result = process.wait(timeout=5)
                adopted = []
                while True:
                    try:
                        pid, status = os.waitpid(-1, os.WNOHANG)
                    except ChildProcessError:
                        break
                    if pid == 0:
                        break
                    adopted.append([pid, status])
                remaining = [pid for pid in tracked if Path(f"/proc/{pid}").exists()]
                command_record.update(
                    STOP_utc=utc(),
                    exit_code=result,
                    directwait=True,
                    adopted_directwait=adopted,
                    remaining=remaining,
                    cleanup=[],
                )
                assert not remaining, remaining
            if PHASE == "2" and index == 2 and result == 0:
                artifacts = []
                for line in (ROOT / f"software-{PHASE}-{index}.log").read_text().splitlines():
                    try:
                        item = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if (
                        item.get("reason") == "compiler-artifact"
                        and item.get("target", {}).get("name") == "sigma_clock"
                        and item.get("executable")
                    ):
                        artifacts.append(item["executable"])
                assert len(artifacts) == 1, artifacts
                binary = Path(artifacts[0])
                (ROOT / "integration-binary.json").write_text(
                    json.dumps(
                        {
                            "path": str(binary),
                            "sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
                            "bytes": binary.stat().st_size,
                            "source_sha256": binding,
                        },
                        indent=2,
                    )
                    + "\n"
                )
            if result != 0:
                break
        record.update(
            STOP_utc=utc(),
            remaining=[],
            cleanup=[],
            actual_allocated_whole_WT_B=allocation([WT]),
            sampling_limit="100ms observations; transient between-sample peaks UNKNOWN",
        )
        assert all(
            hashlib.sha256((WT / path).read_bytes()).hexdigest() == digest
            for path, digest in binding.items()
        )
        (ROOT / f"software-{PHASE}-stop.json").write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps(record), flush=True)
        return int(record["commands"][-1]["exit_code"] != 0)


if __name__ == "__main__":
    raise SystemExit(main())
