"""New public no-bypass boundary checks; no framework or corpus imports."""

import unittest

from .common import public_distance_parameterization, resolve_config


class PublicNoBypassConfigurationTests(unittest.TestCase):
    def config(self, *changes):
        return resolve_config(
            overrides=[
                'model.architecture="distance_residual"',
                "model.distance_a=0",
                "model.distance_b=0",
                "model.distance_bypass=false",
                *changes,
            ]
        )

    def test_explicit_zero_bypass_is_public_parameterization(self):
        model = self.config()["model"]
        self.assertTrue(public_distance_parameterization(model))
        self.assertEqual((model["distance_a"], model["distance_b"]), (0, 0))

    def test_no_bypass_cannot_retain_offset_or_distance_coefficient(self):
        for change in ("model.distance_a=0.1", "model.distance_b=8"):
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.config(change)

    def test_boolean_condition_cannot_be_forged_by_numeric_values(self):
        for value in ("0", "1", "null", '"false"'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.config("model.distance_bypass=" + value)

    def test_zero_coefficients_without_explicit_condition_do_not_admit_public_fit(self):
        model = {"distance_a": 0, "distance_b": 0}
        self.assertFalse(public_distance_parameterization(model))
        self.assertTrue(public_distance_parameterization({"distance_a": 0, "distance_b": 8}))

    def test_future_step_transforms_or_labels_do_not_change_original_units(self):
        for change in ('model.train_transform="F"', 'training.target="outcome_steps"'):
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.config(change)


if __name__ == "__main__":
    unittest.main()
