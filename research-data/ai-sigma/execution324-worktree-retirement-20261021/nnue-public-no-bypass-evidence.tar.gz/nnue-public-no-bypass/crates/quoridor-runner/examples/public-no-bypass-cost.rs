//! Temporary353 bounded trained-model whole search setup/drop observation.
//! The maintained alpha implementation owns all search mathematics. This is
//! eight non-timed depth2 calls on the fixed qualification inputs, not games
//! or a clock/performance sweep. Real 100ms admission stays in the arena.
use quoridor_ai::alphabeta::{
    ResidualEvaluator, SearchLimits, SearchNamespace, SearchSession, StopReason,
};
use quoridor_core::research::SigmaContext;
use quoridor_nnue::residual::ResidualModel;
use serde_json::{Value, json};
use std::{
    error::Error,
    ffi::OsString,
    fmt, fs,
    io::Write,
    path::PathBuf,
    sync::{Arc, atomic::AtomicBool},
    time::Instant,
};

type Failure = Box<dyn Error>;
struct Observations {
    rows: Vec<Value>,
    models: Vec<Value>,
    calls_attempted: u32,
    calls_returned: u32,
    calls_validated: u32,
    nodes: Option<u64>,
    active: Option<usize>,
    stage: String,
    search_errors: Vec<(String, Failure)>,
}
impl Observations {
    fn new() -> Self {
        let prefixes = [vec![], vec![13], vec![13, 67], vec![13, 67, 81, 66, 14, 65]];
        let rows = ["candidate BEST", "retained BEST51"]
            .into_iter()
            .flat_map(|tag| {
                prefixes.iter().map(move |prefix| {
                    json!({"checkpoint":tag,"prefix":prefix,"state":"UNENTERED",
                "result":"UNKNOWN","error":null,"teacher":null})
                })
            })
            .collect();
        Self {
            rows,
            models: vec![
                json!({"checkpoint":"candidate BEST","state":"UNENTERED"}),
                json!({"checkpoint":"retained BEST51","state":"UNENTERED"}),
            ],
            calls_attempted: 0,
            calls_returned: 0,
            calls_validated: 0,
            nodes: Some(0),
            active: None,
            stage: "input/load".into(),
            search_errors: vec![],
        }
    }
    fn returned(&mut self, index: usize, evidence: Value) {
        self.calls_returned += 1;
        self.rows[index]["state"] = json!("RETURNED");
        self.rows[index]["returned_evidence"] = evidence;
    }
    fn payload(
        &self,
        primary: &Option<Failure>,
        secondary: &[(String, Failure)],
        start: Instant,
    ) -> Value {
        json!({"schema":"quoridor.public-no-bypass.whole-search-cost.v1",
            "status":if primary.is_none(){"COMPLETE"}else{"FAILED"},"rows":self.rows,"models":self.models,
            "Search_calls":self.calls_attempted,"Search_calls_returned":self.calls_returned,"Search_calls_validated":self.calls_validated,
            "aggregate_nodes":self.nodes,"aggregate_nodes_known":self.nodes.is_some(),"active_slot":self.active,"last_stage":self.stage,
            "requested_depth":2,"all_complete_finite_legal":primary.is_none() && self.calls_validated==8,
            "primary":primary.as_ref().map(|e|e.to_string()),
            "secondary":secondary.iter().map(|(stage,e)|json!({"stage":stage,"error":e.to_string()})).collect::<Vec<_>>(),
            "whole_setup_load_search_drop_seconds":start.elapsed().as_secs_f64(),"authority_clock_qualification":false,
            "counter_domain":"attempted/Result-returned/validated separated; aggregate sums only available returned Ok nodes, Err/unreturned work UNKNOWN; no node rescue",
            "games_fit_teacher":0,"scope":"fixed qualification inputs; no arithmetic speed/causal CPU shares/strength claim"})
    }
}
#[derive(Debug)]
struct RetainedFailure {
    primary: Failure,
    secondary: Vec<(String, Failure)>,
}
impl fmt::Display for RetainedFailure {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{}; retained secondary: {:?}",
            self.primary, self.secondary
        )
    }
}
impl Error for RetainedFailure {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        Some(self.primary.as_ref())
    }
}
fn retain(
    primary: &mut Option<Failure>,
    secondary: &mut Vec<(String, Failure)>,
    stage: &str,
    error: Failure,
) {
    if primary.is_none() {
        *primary = Some(error)
    } else {
        secondary.push((stage.into(), error))
    }
}
fn finish(
    observed: &mut Observations,
    result: Result<(), Failure>,
    start: Instant,
    mut publish: impl FnMut(&Value) -> Result<(), Failure>,
    mut fallback: impl FnMut(&Value) -> Result<(), Failure>,
) -> Result<(), Failure> {
    let mut primary = None;
    let mut secondary = vec![];
    for (stage, error) in std::mem::take(&mut observed.search_errors) {
        retain(&mut primary, &mut secondary, &stage, error)
    }
    if let Err(error) = result {
        retain(&mut primary, &mut secondary, "caller_failure", error)
    }
    if primary.is_some()
        && let Some(i) = observed.active
    {
        observed.rows[i]["state"] = json!("FAILED")
    }
    if let Err(error) = publish(&observed.payload(&primary, &secondary, start)) {
        retain(&mut primary, &mut secondary, "report_publication", error);
        if let Err(error) = fallback(&observed.payload(&primary, &secondary, start)) {
            retain(
                &mut primary,
                &mut secondary,
                "partial_stderr_publication",
                error,
            );
        }
    }
    match primary {
        None => Ok(()),
        Some(primary) if secondary.is_empty() => Err(primary),
        Some(primary) => Err(Box::new(RetainedFailure { primary, secondary })),
    }
}

fn run(args: &[OsString], observed: &mut Observations) -> Result<(), Failure> {
    if args.len() != 4 {
        return Err("candidate BEST, retained BEST51 manifests, fixed4 prefixes, output".into());
    }
    let prefixes: Vec<Vec<u16>> = serde_json::from_slice(&fs::read(PathBuf::from(&args[2]))?)?;
    if prefixes != [vec![], vec![13], vec![13, 67], vec![13, 67, 81, 66, 14, 65]] {
        return Err("exact qualification prefixes".into());
    }
    let mut complete = true;
    for (model_index, (tag, path)) in [("candidate BEST", &args[0]), ("retained BEST51", &args[1])]
        .into_iter()
        .enumerate()
    {
        observed.stage = format!("{tag}/model_load");
        observed.models[model_index]["state"] = json!("ATTEMPTED");
        let model_start = Instant::now();
        let model = Arc::new(ResidualModel::load(PathBuf::from(path))?);
        let load_seconds = model_start.elapsed().as_secs_f64();
        let fingerprint = model.fingerprint();
        let identity = quoridor_data::hex_digest(&fingerprint);
        observed.models[model_index] = json!({"checkpoint":tag,"state":"LOADED","fingerprint_SHA256":identity,
            "loaded_evaluator_content_SHA256":identity,"model_load_setup_seconds":load_seconds,"model_adapter_drop_seconds":"UNKNOWN"});
        let evaluator = Arc::new(ResidualEvaluator::new(model.clone()));
        for (prefix_index, prefix) in prefixes.iter().enumerate() {
            let slot = model_index * 4 + prefix_index;
            observed.active = Some(slot);
            observed.stage = format!("{tag}/prefix{prefix_index}/setup");
            observed.rows[slot]["state"] = json!("SETUP_ATTEMPTED");
            let call_start = Instant::now();
            let root = SigmaContext::from_prefix(prefix)?;
            root.validate_normal()?;
            if root.terminal_value().is_some() {
                return Err("genuine nonterminal qualification root".into());
            }
            let before_position = root.position();
            let before_history = root.history_counts();
            let setup_start = Instant::now();
            let mut session = SearchSession::new(
                evaluator.clone(),
                SearchNamespace {
                    evaluator: format!("nnue-residual-f32:sha256:{identity}:simd=false"),
                    rules: root.ruleset().id().into(),
                    selectivity: "fullwidth-PVS-MPC-OFF-v1".into(),
                },
                4096,
            )?;
            let session_setup_seconds = setup_start.elapsed().as_secs_f64();
            let tt_capacity = session.tt_capacity();
            observed.stage = format!("{tag}/prefix{prefix_index}/Search");
            observed.rows[slot]["state"] = json!("ATTEMPTED");
            let search_start = Instant::now();
            observed.calls_attempted += 1;
            let returned = session.search(
                &root,
                &SearchLimits {
                    max_depth: 2,
                    max_nodes: 100000,
                    time_limit: None,
                    tt_entries: 4096,
                    use_pvs: true,
                    use_tt: true,
                },
                &AtomicBool::new(false),
            );
            let search_seconds = search_start.elapsed().as_secs_f64();
            let evidence = match &returned {
                Ok(r) => {
                    json!({"return":"VALUE","action":r.action,"value":r.value,"value_bits":r.value.map(f32::to_bits),
                    "completed_depth":r.completed_depth,"PV":r.pv,"stop":quoridor_runner::arena_clock::stop_name(r.stop),
                    "whole_invocation_counters":quoridor_runner::arena_clock::alpha_counters(r)})
                }
                Err(error) => {
                    json!({"return":"ERROR","error":error.to_string(),"counters":"UNKNOWN"})
                }
            };
            observed.returned(slot, evidence);
            // Retain the original returned cause and all returned Ok work before
            // any later history validation, drop accounting, or publication can fail.
            let (returned_result, returned_error) = match returned {
                Ok(result) => {
                    observed.nodes = observed
                        .nodes
                        .and_then(|n| n.checked_add(result.stats.nodes));
                    (Some(result), None)
                }
                Err(error) => {
                    let text = error.to_string();
                    observed
                        .search_errors
                        .push((format!("Search_slot{slot}"), Box::new(error)));
                    (None, Some(text))
                }
            };
            let retained = session.retained_memory_bytes();
            let drop_start = Instant::now();
            drop(session);
            let session_drop_seconds = drop_start.elapsed().as_secs_f64();
            observed.rows[slot]["available_setup_drop"] = json!({"session_setup_seconds":session_setup_seconds,
                "search_including_rootFT_head_delta_seconds":search_seconds,"session_drop_seconds":session_drop_seconds,
                "TT_requested":4096,"TT_effective":tt_capacity.0,"TT_byte_cap":tt_capacity.1,
                "TT_retained_B":retained.0,"session_metadata_B":retained.1});
            if root.position() != before_position || root.history_counts() != before_history {
                return Err("search mutated original full history".into());
            }
            let (result, error) = match returned_result {
                Some(r) => {
                    if observed.nodes.is_none() {
                        return Err("node overflow; individual actual counters retained".into());
                    }
                    let valid = r.stop == StopReason::DepthComplete
                        && r.completed_depth == 2
                        && r.stats.nodes <= 100000
                        && r.value.is_some_and(|v| v.is_finite() && v.abs() <= 2.)
                        && r.action
                            .is_some_and(|a| r.pv.first() == Some(&a) && root.play(a).is_ok());
                    complete &= valid;
                    if valid {
                        observed.calls_validated += 1;
                    }
                    (
                        Some(
                            json!({"action":r.action,"value":r.value,"completed_depth":r.completed_depth,
                        "PV":r.pv,"stop":quoridor_runner::arena_clock::stop_name(r.stop),
                        "whole_invocation_counters":quoridor_runner::arena_clock::alpha_counters(&r),
                        "requested_depth2_complete_finite_legal":valid}),
                        ),
                        None,
                    )
                }
                None => {
                    complete = false;
                    (None, returned_error)
                }
            };
            let retained_evidence = observed.rows[slot]["returned_evidence"].clone();
            observed.rows[slot] = json!({"checkpoint":tag,"prefix":prefix,"result":result,"error":error,
                "state":if result.as_ref().is_some_and(|r|r["requested_depth2_complete_finite_legal"]==true){"VALIDATED"}else{"INCOMPLETE_OR_ERROR"},
                "returned_evidence":retained_evidence,
                "model_fingerprint_SHA256":identity,"session_setup_seconds":session_setup_seconds,
                "search_including_rootFT_head_delta_seconds":search_seconds,
                "session_drop_seconds":session_drop_seconds,"whole_root_setup_search_drop_seconds":call_start.elapsed().as_secs_f64(),
                "TT_requested":4096,"TT_effective":tt_capacity.0,"TT_byte_cap":tt_capacity.1,
                "TT_retained_B":retained.0,"session_metadata_B":retained.1,
                "full_history_unchanged":true,"teacher":null});
            observed.active = None;
        }
        let drop_start = Instant::now();
        drop(evaluator);
        drop(model);
        observed.models[model_index] = json!({"checkpoint":tag,"fingerprint_SHA256":identity,"state":"COMPLETED_DROP",
            "loaded_evaluator_content_SHA256":quoridor_data::hex_digest(&fingerprint),
            "model_load_setup_seconds":load_seconds,
            "model_adapter_drop_seconds":drop_start.elapsed().as_secs_f64()});
    }
    if observed.calls_attempted != 8 || observed.nodes.is_none_or(|n| n > 800000) {
        return Err("exact8 calls, aggregate800000 counted scope".into());
    }
    if !complete {
        return Err(
            "fixed qualification incomplete/error; retained all8 planned slots, no rescue/retry"
                .into(),
        );
    }
    Ok(())
}

fn main() -> Result<(), Failure> {
    let start = Instant::now();
    let args: Vec<_> = std::env::args_os().skip(1).collect();
    let output = args.get(3).map(PathBuf::from);
    let mut observed = Observations::new();
    let result = run(&args, &mut observed);
    finish(
        &mut observed,
        result,
        start,
        |value| {
            fs::write(
                output.as_ref().ok_or("output path UNKNOWN")?,
                serde_json::to_vec_pretty(value)?,
            )?;
            Ok(())
        },
        |value| {
            let mut stderr = std::io::stderr().lock();
            serde_json::to_writer(&mut stderr, value)?;
            stderr.write_all(b"\n")?;
            Ok(())
        },
    )
}
#[cfg(test)]
mod partial_353_tests {
    use super::*;
    #[test]
    fn partial_353_cost_returned_slot_and_unentered_denominator_survive_failure() {
        let mut observed = Observations::new();
        observed.calls_attempted = 1;
        observed.active = Some(0);
        observed.returned(
            0,
            json!({"synthetic":true,"nodes":17,"value_bits":0.25f32.to_bits()}),
        );
        let mut saved = Value::Null;
        let result = finish(
            &mut observed,
            Err("setup-next-failed".into()),
            Instant::now(),
            |v| {
                saved = v.clone();
                Ok(())
            },
            |_| panic!("unneeded fallback"),
        );
        assert_eq!(result.unwrap_err().to_string(), "setup-next-failed");
        assert_eq!(saved["Search_calls_returned"], 1);
        assert_eq!(saved["rows"][0]["returned_evidence"]["nodes"], 17);
        assert_eq!(saved["rows"][1]["state"], "UNENTERED");
        assert_eq!(saved["rows"].as_array().unwrap().len(), 8);
    }
    #[test]
    fn partial_353_cost_original_error_and_all_publication_errors_survive() {
        let mut observed = Observations::new();
        observed
            .search_errors
            .push(("slot-first".into(), "original-Search-error".into()));
        let result = finish(
            &mut observed,
            Err("later-setup-error".into()),
            Instant::now(),
            |_| Err("publish-error".into()),
            |_| Err("stderr-error".into()),
        );
        let error = result.unwrap_err();
        let retained = error.downcast_ref::<RetainedFailure>().unwrap();
        assert_eq!(retained.primary.to_string(), "original-Search-error");
        assert_eq!(retained.secondary.len(), 3);
        assert_eq!(retained.secondary[0].1.to_string(), "later-setup-error");
        assert_eq!(retained.secondary[1].1.to_string(), "publish-error");
        assert_eq!(retained.secondary[2].1.to_string(), "stderr-error");
    }
}
