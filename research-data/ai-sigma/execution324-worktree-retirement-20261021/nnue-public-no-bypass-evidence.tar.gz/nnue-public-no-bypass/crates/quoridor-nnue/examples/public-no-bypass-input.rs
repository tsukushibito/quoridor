//! Temporary353 trained BEST/LAST caller: maintained full/delta/undo/error APIs.
//! No Search, teacher or optimizer. Retained initial image/source stay immutable.
use quoridor_core::research::SigmaContext;
use quoridor_nnue::{Accumulator, EvaluationMode, encode_qf1, residual::ResidualModel};
use serde_json::{Value, json};
use std::{error::Error, ffi::OsString, fmt, fs, io::Write, path::PathBuf, time::Instant};

type Failure = Box<dyn Error>;

#[derive(Default, serde::Serialize)]
struct Counts {
    normal_attempted: u32,
    normal_returned: u32,
    normal_validated: u32,
    rejected_evaluation_attempted: u32,
    rejected_evaluation_returned: u32,
    rejected_evaluation_validated: u32,
    rejected_input_attempted: u32,
    rejected_input_returned: u32,
    rejected_input_validated: u32,
    transition_attempted: u32,
    move_returned: u32,
    undo_attempted: u32,
    undo_returned: u32,
    transition_validated: u32,
}

struct Observations {
    counts: Counts,
    rows: Vec<Value>,
    slots: Vec<Value>,
    available: Vec<Value>,
    active: Option<usize>,
    stage: String,
    model_load_seconds: Option<f64>,
}
impl Observations {
    fn new() -> Self {
        Self {
            counts: Counts::default(),
            rows: vec![],
            available: vec![],
            active: None,
            stage: "input/load".into(),
            model_load_seconds: None,
            slots: [vec![], vec![13], vec![13, 67], vec![13, 67, 81, 66, 14, 65]]
                .into_iter()
                .enumerate()
                .map(|(index, prefix)| {
                    json!({
                        "index":index,"prefix":prefix,"state":"UNENTERED","models":"UNKNOWN"
                    })
                })
                .collect(),
        }
    }
    fn payload(
        &self,
        primary: &Option<Failure>,
        secondary: &[(String, Failure)],
        started: Instant,
    ) -> Value {
        json!({"schema":"quoridor.public-no-bypass.trained-native-input.v1",
            "status":if primary.is_none() {"COMPLETE"} else {"FAILED"},
            "rows":self.rows,"planned_slots":self.slots,"available":self.available,
            "active_slot":self.active,"last_stage":self.stage,"counts":self.counts,
            "successful_evaluations":self.counts.normal_validated,
            "deliberate_rejected_evaluations":self.counts.rejected_evaluation_validated,
            "deliberate_rejected_input_constructions":self.counts.rejected_input_validated,
            "legal_delta_undo_transitions":self.counts.transition_validated,
            "model_load_seconds":self.model_load_seconds,"whole_native_seconds":started.elapsed().as_secs_f64(),
            "primary":primary.as_ref().map(|e| e.to_string()),
            "secondary":secondary.iter().map(|(stage,e)| json!({"stage":stage,"error":e.to_string()})).collect::<Vec<_>>(),
            "counter_domain":"API attempts/Result returns include errors; validated is separate; absent arrays/slots UNKNOWN, never successful by inference",
            "Search_calls":0,"teacher_or_game_calls":0})
    }
}

#[derive(Debug)]
struct RetainedFailure {
    primary: Failure,
    secondary: Vec<(String, Failure)>,
}
impl fmt::Display for RetainedFailure {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{}; retained secondary: {:?}",
            self.primary, self.secondary
        )
    }
}
impl Error for RetainedFailure {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        Some(self.primary.as_ref())
    }
}

fn retain_error(
    primary: &mut Option<Failure>,
    secondary: &mut Vec<(String, Failure)>,
    stage: &str,
    error: Failure,
) {
    if primary.is_none() {
        *primary = Some(error);
    } else {
        secondary.push((stage.into(), error));
    }
}
fn finish(
    observed: &mut Observations,
    result: Result<(), Failure>,
    started: Instant,
    mut publish: impl FnMut(&Value) -> Result<(), Failure>,
    mut fallback: impl FnMut(&Value) -> Result<(), Failure>,
) -> Result<(), Failure> {
    let mut primary = result.err();
    let mut secondary = vec![];
    if primary.is_some()
        && let Some(i) = observed.active
    {
        observed.slots[i]["state"] = json!("FAILED");
    }
    if let Err(error) = publish(&observed.payload(&primary, &secondary, started)) {
        retain_error(&mut primary, &mut secondary, "report_publication", error);
        if let Err(error) = fallback(&observed.payload(&primary, &secondary, started)) {
            retain_error(
                &mut primary,
                &mut secondary,
                "partial_stderr_publication",
                error,
            );
        }
    }
    match primary {
        None => Ok(()),
        Some(primary) if secondary.is_empty() => Err(primary),
        Some(primary) => Err(Box::new(RetainedFailure { primary, secondary })),
    }
}

fn observe_evaluation<E: Error + 'static>(
    observed: &mut Observations,
    location: &str,
    operation: impl FnOnce() -> Result<f32, E>,
) -> Result<f32, Failure> {
    observed.stage = location.into();
    observed.counts.normal_attempted += 1;
    let returned = operation();
    observed.counts.normal_returned += 1;
    match returned {
        Err(error) => {
            observed.available.push(json!({"location":location,"return":"ERROR","error":error.to_string(),"value":"UNKNOWN"}));
            Err(Box::new(error))
        }
        Ok(value) => {
            observed.available.push(
                json!({"location":location,"return":"VALUE","value_bits":value.to_bits(),
                "value":value.is_finite().then_some(value),"finite":value.is_finite()}),
            );
            let value = finite(value)?;
            observed.counts.normal_validated += 1;
            Ok(value)
        }
    }
}
fn rejected_evaluation<E: Error + 'static>(
    observed: &mut Observations,
    location: &str,
    operation: impl FnOnce() -> Result<f32, E>,
) -> Result<(), Failure> {
    observed.stage = location.into();
    observed.counts.rejected_evaluation_attempted += 1;
    let returned = operation();
    observed.counts.rejected_evaluation_returned += 1;
    match returned {
        Err(error) => {
            observed.counts.rejected_evaluation_validated += 1;
            observed.available.push(
                json!({"location":location,"expected_rejection":true,"error":error.to_string()}),
            );
            Ok(())
        }
        Ok(value) => {
            observed
                .available
                .push(json!({"location":location,"unexpected_acceptance_bits":value.to_bits()}));
            Err("deliberate invalid evaluation accepted".into())
        }
    }
}
fn rejected_input<E: Error + 'static>(
    observed: &mut Observations,
    location: &str,
    operation: impl FnOnce() -> Result<Accumulator, E>,
) -> Result<(), Failure> {
    observed.stage = location.into();
    observed.counts.rejected_input_attempted += 1;
    let returned = operation();
    observed.counts.rejected_input_returned += 1;
    match returned {
        Err(error) => {
            observed.counts.rejected_input_validated += 1;
            observed.available.push(json!({"location":location,"expected_input_rejection":true,"error":error.to_string()}));
            Ok(())
        }
        Ok(value) => {
            observed
                .available
                .push(json!({"location":location,"unexpected_accepted_FT_bits":bits(&value)}));
            Err("deliberate invalid input accepted".into())
        }
    }
}

fn bits(a: &Accumulator) -> Vec<u32> {
    a.values.iter().flatten().map(|v| v.to_bits()).collect()
}
fn finite(value: f32) -> Result<f32, Box<dyn Error>> {
    if !value.is_finite() || value.abs() > 1.0 {
        return Err("finite legacy tanh score required".into());
    }
    Ok(value)
}
fn run(args: &[OsString], observed: &mut Observations) -> Result<(), Box<dyn Error>> {
    if args.len() != 4 {
        return Err("trained BEST manifest, LAST manifest, four prefixes JSON, output JSON".into());
    }
    let load_start = Instant::now();
    observed
        .available
        .push(json!({"checkpoint":"BEST","load":"ATTEMPTED"}));
    let best = ResidualModel::load(PathBuf::from(&args[0]))?;
    observed
        .available
        .push(json!({"checkpoint":"BEST","load":"RETURNED","fingerprint":best.fingerprint()}));
    observed
        .available
        .push(json!({"checkpoint":"LAST","load":"ATTEMPTED"}));
    let last = ResidualModel::load(PathBuf::from(&args[1]))?;
    observed
        .available
        .push(json!({"checkpoint":"LAST","load":"RETURNED","fingerprint":last.fingerprint()}));
    if best.fingerprint() == last.fingerprint() {
        return Err("two distinct frozen trained checkpoints required".into());
    }
    observed.model_load_seconds = Some(load_start.elapsed().as_secs_f64());
    let prefixes: Vec<Vec<u16>> = serde_json::from_slice(&fs::read(PathBuf::from(&args[2]))?)?;
    if prefixes != [vec![], vec![13], vec![13, 67], vec![13, 67, 81, 66, 14, 65]] {
        return Err("exact prebound four genuine input prefixes".into());
    }
    for (index, prefix) in prefixes.into_iter().enumerate() {
        observed.active = Some(index);
        observed.stage = format!("prefix{index}/geometry");
        observed.slots[index]["state"] = json!("ATTEMPTED");
        let root = SigmaContext::from_prefix(&prefix)?;
        root.validate_normal()?;
        if root.terminal_value().is_some() {
            return Err("nonterminal maintained full-history input required".into());
        }
        let feature = encode_qf1(root.position())?;
        let side = usize::from(feature.side);
        let integer_d = [
            root.position().wall_distance(side).ok_or("STM distance")?,
            root.position()
                .wall_distance(side ^ 1)
                .ok_or("opponent distance")?,
        ];
        let raw_bits = integer_d.map(|d| ((f64::from(d) / 80.) as f32).to_bits());
        if feature.distance.map(f32::to_bits) != raw_bits {
            return Err("canonical STM-first D/80 bits".into());
        }
        let legal = root.legal_ids();
        let actions = [
            *legal.iter().find(|&&a| a < 81).ok_or("pawn fixture")?,
            *legal.iter().find(|&&a| a >= 81).ok_or("wall fixture")?,
        ];
        observed.slots[index]["models"] = json!([{"checkpoint":"BEST","state":"UNENTERED"},{"checkpoint":"LAST","state":"UNENTERED"}]);
        observed.available.push(json!({"prefix_index":index,"stage":"input_available","ids_absolute_players":feature.ids,
            "native_side":feature.side,"integer_D_STM_first":integer_d,"raw_D_over80_bits":raw_bits,"selected_actions":actions}));
        let mut model_rows = Vec::new();
        for (model_index, (tag, model, other)) in [("BEST", &best, &last), ("LAST", &last, &best)]
            .into_iter()
            .enumerate()
        {
            observed.stage = format!("prefix{index}/{tag}/parent_setup");
            observed.slots[index]["models"][model_index]["state"] = json!("ATTEMPTED");
            let setup_start = Instant::now();
            let parent = model.full_context(&root, EvaluationMode::Scalar)?;
            let parent_bits = bits(&parent);
            observed.available.push(json!({"prefix_index":index,"checkpoint":tag,"parent_FT_bits":parent_bits,
                "actual_parent_ids":parent.features.ids,"actual_parent_raw_D_bits":parent.features.distance.map(f32::to_bits)}));
            if parent.features != feature {
                return Err("model changed canonical QF1/D/side input".into());
            }
            let parent_position = root.position();
            let parent_history = root.history_counts();
            let mut scratch = model.evaluation_scratch();
            let mut selected_head = None;
            let evaluated = observe_evaluation(observed, &format!("{index}/{tag}/parent"), || {
                model.evaluate_with_scratch_observed(&parent, &mut scratch, |permit, avx| {
                    selected_head = Some((permit, avx));
                })
            });
            let packed = scratch.packed_input();
            observed.available.push(json!({"prefix_index":index,"checkpoint":tag,
                "actual_packed_head_bits":packed.iter().map(|v|v.to_bits()).collect::<Vec<_>>(),"head_selection":selected_head}));
            // Scratch is available even when the returned evaluation is rejected;
            // keep it as observed scratch, without treating it as a valid head.
            let value = evaluated?;
            if packed.len() != 70 || packed[66..].iter().any(|v| v.to_bits() != 0) {
                return Err("actual positive Zero4/head width".into());
            }
            let head_d = [packed[64].to_bits(), packed[65].to_bits()];
            observed.available.push(json!({"prefix_index":index,"checkpoint":tag,"value":value,"head_D_bits":head_d,"head_Zero4_bits":packed[66..].iter().map(|v|v.to_bits()).collect::<Vec<_>>(),"head_selection":selected_head}));
            let setup_head_seconds = setup_start.elapsed().as_secs_f64();
            let mut child_rows = Vec::new();
            for action in actions {
                observed.stage = format!("prefix{index}/{tag}/child{action}");
                observed.counts.transition_attempted += 1;
                let mut context = root.clone();
                let made = context.make_move(action);
                observed.counts.move_returned += 1;
                let undo = made?;
                observed.available.push(json!({"prefix_index":index,"checkpoint":tag,"action":action,"move_applied":true,"undo":"UNENTERED"}));
                context.validate_normal()?;
                if context.terminal_value().is_some() {
                    return Err("prebound delta fixture unexpectedly terminal".into());
                }
                let full = model.full_context(&context, EvaluationMode::Scalar)?;
                observed.available.push(
                    json!({"prefix_index":index,"checkpoint":tag,"action":action,
                    "full_ids":full.features.ids,"full_FT_bits":bits(&full)}),
                );
                let mut delta = model.child_buffer(EvaluationMode::Scalar);
                let updated = model.delta_move_into(&parent, &undo, &context, &mut delta);
                observed.available.push(
                    json!({"prefix_index":index,"checkpoint":tag,"action":action,
                    "full_ids":full.features.ids,"delta_ids":delta.features.ids,
                    "full_FT_bits":bits(&full),"delta_FT_bits":bits(&delta),
                    "delta_error":updated.as_ref().err().map(ToString::to_string),
                    "delta_buffer_semantics":"partial buffer until update returned Ok"}),
                );
                updated?;
                if full.features != delta.features || bits(&parent) != parent_bits {
                    return Err("delta input or immutable parent state changed".into());
                }
                let full_value =
                    observe_evaluation(observed, &format!("{index}/{tag}/{action}/full"), || {
                        model.evaluate_with_scratch(&full, &mut scratch)
                    })?;
                let delta_value =
                    observe_evaluation(observed, &format!("{index}/{tag}/{action}/delta"), || {
                        model.evaluate_with_scratch(&delta, &mut scratch)
                    })?;
                let error = (f64::from(full_value) - f64::from(delta_value)).abs();
                if !error.is_finite() || error > 1e-5 {
                    return Err("actual trained full/delta tolerance".into());
                }
                let child_input = delta.features.clone();
                drop(delta);
                drop(full);
                observed.counts.undo_attempted += 1;
                observed.stage = format!("{index}/{tag}/{action}/undo");
                let undone = context.unmake_move(undo);
                observed.counts.undo_returned += 1;
                undone?;
                context.validate_normal()?;
                if context.position() != parent_position
                    || context.history_counts() != parent_history
                    || context.total_ply() != root.total_ply()
                    || bits(&parent) != parent_bits
                {
                    return Err("full counted chronology/parent undo mismatch".into());
                }
                let restored = observe_evaluation(
                    observed,
                    &format!("{index}/{tag}/{action}/restored"),
                    || model.evaluate_with_scratch(&parent, &mut scratch),
                )?;
                if restored.to_bits() != value.to_bits() {
                    return Err("parent value after undo differs".into());
                }
                observed.counts.transition_validated += 1;
                let child_row = json!({"action":action,"ids_absolute_players":child_input.ids,
                    "side":child_input.side,"raw_D_over80":child_input.distance,
                    "full_value":full_value,"delta_value":delta_value,"absolute_error":error,
                    "parent_accumulator_bits_unchanged":true,"full_history_undo":true});
                observed.available.push(
                    json!({"prefix_index":index,"checkpoint":tag,"validated_child":child_row}),
                );
                child_rows.push(child_row);
            }
            if index == 0 {
                let mut invalid = feature.clone();
                invalid.distance[0] = f32::NAN;
                rejected_input(observed, &format!("{index}/{tag}/NaN-input"), || {
                    model.full_features(invalid, EvaluationMode::Scalar)
                })?;
                let mut invalid = feature.clone();
                invalid.ids[0] = vec![312];
                rejected_input(observed, &format!("{index}/{tag}/ID312-input"), || {
                    model.full_features(invalid, EvaluationMode::Scalar)
                })?;
                let mut invalid = parent.clone();
                invalid.values[0][0] = f32::NAN;
                rejected_evaluation(observed, &format!("{index}/{tag}/NaN-FT"), || {
                    model.evaluate_with_scratch(&invalid, &mut scratch)
                })?;
                let foreign = other.full_context(&root, EvaluationMode::Scalar)?;
                rejected_evaluation(observed, &format!("{index}/{tag}/foreign-FT"), || {
                    model.evaluate_with_scratch(&foreign, &mut scratch)
                })?;
            }
            model_rows.push(json!({"checkpoint":tag,"value":value,"head_D_bits":head_d,
                "head_Zero4_bits":[0,0,0,0],"FT_mode":"Scalar","head_selection":selected_head,
                "full_context_setup_head_seconds":setup_head_seconds,"children":child_rows}));
            observed.slots[index]["models"][model_index] =
                json!({"checkpoint":tag,"state":"VALIDATED","available":model_rows.last()});
        }
        if model_rows[0]["head_D_bits"] != model_rows[1]["head_D_bits"] {
            return Err("trained checkpoint D head inputs differ".into());
        }
        observed.rows.push(json!({"prefix":prefix,"ruleset":root.ruleset().id(),"ply":root.total_ply(),
            "ids_absolute_players":feature.ids,"native_side":feature.side,"integer_D_STM_first":integer_d,
            "raw_D_over80":feature.distance,"raw_D_over80_bits":raw_bits,"models":model_rows,
            "teacher":null,"scope":"genuine legal qualification fixtures, not labelled corpus"}));
        observed.slots[index]["state"] = json!("VALIDATED");
        observed.active = None;
    }
    if observed.counts.normal_validated != 56
        || observed.counts.transition_validated != 16
        || observed.counts.rejected_evaluation_validated != 4
        || observed.counts.rejected_input_validated != 4
    {
        return Err("exact native qualification counters".into());
    }
    Ok(())
}

fn main() -> Result<(), Failure> {
    let started = Instant::now();
    let args: Vec<_> = std::env::args_os().skip(1).collect();
    let output = args.get(3).map(PathBuf::from);
    let mut observed = Observations::new();
    let result = run(&args, &mut observed);
    finish(
        &mut observed,
        result,
        started,
        |value| {
            let output = output.as_ref().ok_or("output path UNKNOWN")?;
            fs::write(output, serde_json::to_vec_pretty(value)?)?;
            Ok(())
        },
        |value| {
            let mut stderr = std::io::stderr().lock();
            serde_json::to_writer(&mut stderr, value)?;
            stderr.write_all(b"\n")?;
            Ok(())
        },
    )
}

#[cfg(test)]
mod partial_353_tests {
    use super::*;
    #[test]
    fn partial_353_native_return_then_error_retains_value_and_unentered_slots() {
        let mut observed = Observations::new();
        observed.active = Some(0);
        observe_evaluation::<std::io::Error>(&mut observed, "synthetic", || Ok(0.5)).unwrap();
        let mut saved = Value::Null;
        let result = finish(
            &mut observed,
            Err("original-native-error".into()),
            Instant::now(),
            |v| {
                saved = v.clone();
                Ok(())
            },
            |_| panic!("unneeded fallback"),
        );
        assert_eq!(result.unwrap_err().to_string(), "original-native-error");
        assert_eq!(saved["status"], "FAILED");
        assert_eq!(saved["successful_evaluations"], 1);
        assert_eq!(saved["available"][0]["value_bits"], 0.5f32.to_bits());
        assert_eq!(saved["planned_slots"][0]["state"], "FAILED");
        assert_eq!(saved["planned_slots"][1]["state"], "UNENTERED");
    }
    #[test]
    fn partial_353_native_error_return_is_not_validated_success() {
        let mut observed = Observations::new();
        let result = observe_evaluation(&mut observed, "synthetic", || {
            Err(std::io::Error::other("first"))
        });
        assert_eq!(result.unwrap_err().to_string(), "first");
        assert_eq!(observed.counts.normal_attempted, 1);
        assert_eq!(observed.counts.normal_returned, 1);
        assert_eq!(observed.counts.normal_validated, 0);
    }
    #[test]
    fn partial_353_native_primary_and_all_publication_errors_retained() {
        let mut observed = Observations::new();
        let primary: Failure = "native-first".into();
        let result = finish(
            &mut observed,
            Err(primary),
            Instant::now(),
            |_| Err("publish-second".into()),
            |_| Err("stderr-third".into()),
        );
        let error = result.unwrap_err();
        let retained = error.downcast_ref::<RetainedFailure>().unwrap();
        assert_eq!(retained.primary.to_string(), "native-first");
        assert_eq!(retained.secondary.len(), 2);
        assert_eq!(retained.secondary[0].1.to_string(), "publish-second");
        assert_eq!(retained.secondary[1].1.to_string(), "stderr-third");
    }
}
