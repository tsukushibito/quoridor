"""353 BEST/LAST four-prefix parity using the unchanged qualified capture helpers."""

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import stat
import struct
import sys
import time


def json_evidence(value):
    """Keep nonfinite observations explicitly, rather than losing the entire census."""
    if isinstance(value, float) and not math.isfinite(value):
        return {"nonfinite": repr(value), "binary64_bits": struct.pack("!d", value).hex()}
    if isinstance(value, dict):
        return {key: json_evidence(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [json_evidence(item) for item in value]
    return value


def error_facts(error):
    if error is None:
        return None
    return {
        "type": type(error).__name__,
        "message": str(error),
        "notes": list(getattr(error, "__notes__", ())),
        "cause": None if error.__cause__ is None else repr(error.__cause__),
        "retained_observer_restoration_errors": [
            {"type": type(e).__name__, "message": str(e)}
            for e in getattr(error, "retained_observer_restoration_errors", ())
        ],
    }


def capture_arrays(arrays, payload, secondary):
    """Freeze already captured arrays, retaining each available raw representation."""
    retained = payload.setdefault("observations", [])
    for index, array in enumerate(arrays):
        item = {"index": index, "state": "RETURNED", "representation": "UNKNOWN"}
        retained.append(item)
        try:
            item["representation"] = {
                "shape": list(array.shape),
                "dtype": str(array.dtype),
                "raw_bytes_hex": array.tobytes().hex(),
            }
            item["values"] = array.tolist()
            item["state"] = "CAPTURED"
        except BaseException as error:
            item["state"] = "CAPTURE_FAILED"
            secondary.append(("observation_array_" + str(index), error))


def failed_slots(slots):
    """A failure never converts a returned array into validated work."""
    for slot in slots.values():
        if slot["state"] in ("ATTEMPTED", "RETURNED"):
            slot["last_available_state"] = slot["state"]
            slot["state"] = "FAILED"


def reconcile_native(output, payload, secondary):
    """Read saved facts; a raw failed return never becomes a successful execute return."""
    refs = payload.setdefault("native_raw_refs", {})
    for name, field in [
        ("native.process.json", "native_raw_process"),
        ("native.json", "native_available"),
    ]:
        path = output / name
        if not path.exists():
            payload.setdefault(field, "UNKNOWN")
            continue
        try:
            info = path.lstat()
            with path.open("rb") as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
            refs[name] = {
                "path": str(path),
                "SHA256": digest,
                "bytes": info.st_size,
                "mode": f"{stat.S_IMODE(info.st_mode):04o}",
            }
            if info.st_size > 1048576:
                raise ValueError("bounded native census payload exceeds1MiB; raw retained")
            actual = json.loads(path.read_text())
            if type(actual) is not dict:
                raise ValueError("native saved record is not an object")
            payload[field] = actual
        except BaseException as error:
            secondary.append(("native_saved_" + name, error))
            payload.setdefault(field, "UNKNOWN")
    raw = payload.get("native_raw_process")
    payload["native_command_observed_returned"] = bool(
        type(raw) is dict
        and raw.get("direct_child_reaped") is True
        and type(raw.get("exit_code")) is int
    )
    payload["native_execute_success_returned"] = payload.get("native_process_returned") is not None


def finish_capture(output, primary, payload, collectors, publish, fallback):
    """Preserve the first exception object and every later collection/publication error."""
    secondary = []
    for stage, collector in collectors:
        try:
            collector(payload, secondary)
        except BaseException as error:
            secondary.append((stage, error))

    def snapshot():
        first = primary if primary is not None else (secondary[0][1] if secondary else None)
        return json_evidence(
            {
                **payload,
                "status": "FAILED" if first is not None else "COMPLETE",
                "primary": error_facts(first),
                "secondary": [{"stage": s, "error": error_facts(e)} for s, e in secondary],
            }
        )

    try:
        publish(output / "invocation-census.json", snapshot())
    except BaseException as error:
        secondary.append(("invocation_census_publication", error))
        try:
            fallback(snapshot())
        except BaseException as error:
            secondary.append(("partial_stderr_publication", error))
    if primary is not None or secondary:
        first = primary if primary is not None else secondary[0][1]
        first.retained_capture_secondary = tuple(secondary)
        first.add_note(
            "all later capture/publication errors: " + repr([(s, repr(e)) for s, e in secondary])
        )
        raise first


def main(config):
    from quoridor_training.common import resolve_config
    from quoridor_training.cycle_process import execute
    from quoridor_training.snapshot import write_json
    from quoridor_training.train import build_model

    import numpy as np
    import torch

    beginning = time.monotonic()
    helper_path = Path(config["head_helpers"])
    if (
        hashlib.sha256(helper_path.read_bytes()).hexdigest()
        != "868665d7b83c554b49727a2f73b8bc619f995b8dcab4f59b8567821e2f754ad6"
    ):
        raise ValueError("exact reused finite/capture/restoration helpers")
    spec = importlib.util.spec_from_file_location("qualified_head_helpers", helper_path)
    helpers = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helpers)
    if torch.__version__ != "2.14.0+cu130" or not torch.cuda.is_available():
        raise ValueError("same qualified framework/device")
    torch.set_num_threads(2)
    torch.set_num_interop_threads(2)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    free, total = torch.cuda.mem_get_info()
    if free < 6 * 1024**3:
        raise ValueError("fresh CUDA headroom")
    torch.cuda.set_per_process_memory_fraction(min(5 * 1024**3 / total, 1.0))
    cfg = resolve_config(config["fit_config"])
    scale = json.loads(Path(config["scale"]).read_text())
    original_scale_bytes = Path(config["original_T_statistics"]).read_bytes()
    if (
        hashlib.sha256(original_scale_bytes).hexdigest()
        != "0a322186e48d1ef45a02927848a45939df7a36cbfe299fae442270cc42b4a61b"
    ):
        raise ValueError("original eligible-T statistics provenance")
    original_scale = json.loads(original_scale_bytes)
    for key in ["mu_f32", "sigma_f32"]:
        if (
            np.asarray(scale[key], dtype=np.float32).tobytes()
            != np.asarray(original_scale[key], dtype=np.float32).tobytes()
        ):
            raise ValueError("trained scale changed original effective T-only bits")
    if (
        cfg["model"]["distance_bypass"] is not False
        or cfg["model"]["distance_a"] != 0
        or cfg["model"]["distance_b"] != 0
    ):
        raise ValueError("sole no-output-bypass condition")
    output = Path(config["output"])
    output.mkdir(exist_ok=False)
    counts = {
        "Torch_attempted": 0,
        "Torch_returned": 0,
        "Torch_validated": 0,
        "Torch_rows_attempted": 0,
        "native_command_attempted": 0,
        "native_command_returned": 0,
        "optimizer_fit_game_Search": 0,
        "constructors_attempted": 0,
        "constructors_returned": 0,
        "trained_load_attempted": 0,
        "trained_load_returned": 0,
    }
    primary = None
    models, initial_snapshots = [], []
    native_process = None
    observations = []
    scores = {}
    native = None
    parameter_facts = {tag: {"state": "UNENTERED"} for tag in ["BEST", "LAST"]}
    slots = {
        tag + "/" + device: {"state": "UNENTERED", "array": "UNKNOWN"}
        for tag in ["BEST", "LAST"]
        for device in ["cpu", "cuda"]
    }
    try:
        for tag in ["BEST", "LAST"]:
            item = config["checkpoints"][tag]
            torch.manual_seed(cfg["training"]["seed"])
            counts["constructors_attempted"] += 1
            parameter_facts[tag]["state"] = "CONSTRUCTOR_ATTEMPTED"
            model = build_model(cfg["model"], scale)
            counts["constructors_returned"] += 1
            models.append((tag, model))
            initial_sha = helpers.parameter_sha(model)
            parameter_facts[tag].update(
                state="CONSTRUCTOR_RETURNED", initial_parameter_SHA256=initial_sha
            )
            if initial_sha != "2ddacbf88145816b6b0c86e13ebb983d7c1b64e42f8d346623873a18ae7414ad":
                raise ValueError("actual same factory/scale before trained loading")
            checkpoint = torch.load(item["pt"], map_location="cpu", weights_only=True)
            if (
                checkpoint["target"] != "z"
                or checkpoint["dataset_sha"]
                != "07d81abc2230b2fe6b7c5fb7a425e7e3109bf9af2c467f5c72f8d3bdb975279b"
            ):
                raise ValueError("actual trained checkpoint teacher/dataset")
            if (
                checkpoint["scale"]["mu_f32"] != scale["mu_f32"]
                or checkpoint["scale"]["sigma_f32"] != scale["sigma_f32"]
            ):
                raise ValueError("actual trained T-only scaling")
            counts["trained_load_attempted"] += 1
            parameter_facts[tag]["state"] = "TRAINED_LOAD_ATTEMPTED"
            model.load_state_dict(checkpoint["model"], strict=True)
            counts["trained_load_returned"] += 1
            model.eval()
            loaded_sha = helpers.parameter_sha(model)
            parameter_facts[tag].update(
                state="TRAINED_LOAD_RETURNED", loaded_parameter_SHA256=loaded_sha
            )
            if loaded_sha != item["ordered_parameter_SHA256"]:
                raise ValueError("actual loaded trained ordered parameters")
            expected_mu = np.asarray(scale["mu_f32"], dtype=np.float32)
            expected_sigma = np.asarray(scale["sigma_f32"], dtype=np.float32)
            if (
                model.mu.detach().numpy().tobytes() != expected_mu.tobytes()
                or model.sigma.detach().numpy().tobytes() != expected_sigma.tobytes()
                or model.coefficient.detach().numpy().view(np.uint32).tolist() != [0, 0]
            ):
                raise ValueError("actual loaded effective scale/output coefficient bits")
            initial_snapshots.append(
                (
                    tag,
                    helpers.parameter_sha(model),
                    model.mu.detach().numpy().tobytes(),
                    model.sigma.detach().numpy().tobytes(),
                    model.coefficient.detach().numpy().tobytes(),
                )
            )
            parameter_facts[tag].update(
                state="TRAINED_LOAD_VALIDATED",
                mu_bits=expected_mu.view(np.uint32).tolist(),
                sigma_bits=expected_sigma.view(np.uint32).tolist(),
                coefficient_bits=[0, 0],
            )
        command = [
            config["native_image"],
            config["checkpoints"]["BEST"]["manifest"],
            config["checkpoints"]["LAST"]["manifest"],
            config["prefixes"],
            str(output / "native.json"),
        ]
        counts["native_command_attempted"] += 1
        native_process = execute(command, output / "native.log", time.monotonic() + 30)
        counts["native_command_returned"] += 1
        native = json.loads((output / "native.json").read_text())
        if (
            native.get("status") != "COMPLETE"
            or native["successful_evaluations"] != 56
            or native["deliberate_rejected_evaluations"] != 4
            or native["deliberate_rejected_input_constructions"] != 4
            or native["legal_delta_undo_transitions"] != 16
            or native["Search_calls"] != 0
            or len(native["rows"]) != 4
        ):
            raise ValueError("exact finite native/error/undo scope")
        original = json.loads(Path(config["qualified_initial_input"]).read_text())
        for current, old in zip(native["rows"], original["rows"], strict=True):
            for field in [
                "prefix",
                "ids_absolute_players",
                "native_side",
                "integer_D_STM_first",
                "raw_D_over80_bits",
            ]:
                if current[field] != old[field]:
                    raise ValueError(
                        "current trained input differs from already qualified canonical input: "
                        + field
                    )
            if any(
                row["head_D_bits"] != old["candidate_actual_head_D_bits"]
                or row["head_Zero4_bits"] != [0, 0, 0, 0]
                for row in current["models"]
            ):
                raise ValueError("actual trained canonical head D/Zero4 changed")
        features = np.zeros((4, 2, 312), dtype=np.float32)
        for i, row in enumerate(native["rows"]):
            for view, ids in enumerate(row["ids_absolute_players"]):
                features[i, view, ids] = 1
        distance = np.asarray([row["raw_D_over80"] for row in native["rows"]], dtype=np.float32)
        sides = np.asarray([row["native_side"] + 1 for row in native["rows"]], dtype=np.int64)
        expected_d = np.asarray(
            [row["models"][0]["head_D_bits"] for row in native["rows"]], dtype=np.uint32
        )
        for model_index, (tag, model) in enumerate(models):
            reference = np.asarray(
                [row["models"][model_index]["value"] for row in native["rows"]], dtype=np.float32
            )
            with torch.inference_mode():
                for device in ["cpu", "cuda"]:
                    model = model.to(device)
                    counts["Torch_attempted"] += 1
                    counts["Torch_rows_attempted"] += 4
                    slot = slots[tag + "/" + device]
                    slot.update(state="ATTEMPTED", observation_start=len(observations))
                    prediction_tensor = helpers.actual_head_forward(
                        model,
                        torch.from_numpy(features).to(device),
                        torch.from_numpy(distance).to(device),
                        torch.from_numpy(sides).to(device),
                        observations,
                    )
                    counts["Torch_returned"] += 1
                    slot.update(
                        state="RETURNED",
                        tensor_shape=list(prediction_tensor.shape),
                        tensor_dtype=str(prediction_tensor.dtype),
                        tensor_device=str(prediction_tensor.device),
                    )
                    prediction = prediction_tensor.cpu().numpy()
                    slot["array"] = {
                        "shape": list(prediction.shape),
                        "dtype": str(prediction.dtype),
                        "raw_bytes_hex": prediction.tobytes().hex(),
                    }
                    scores[tag + "/" + device] = prediction.tolist()
                    helpers.captured_input_bits(
                        np, observations[-1], expected_d, tag + "/" + device
                    )
                    helpers.finite_correspondence(
                        np, prediction, reference, tag + "/" + device + "/native"
                    )
                    counts["Torch_validated"] += 1
                    slot.update(state="VALIDATED", observation_end=len(observations))
            before = initial_snapshots[model_index]
            if (
                helpers.parameter_sha(model) != before[1]
                or model.mu.detach().cpu().numpy().tobytes() != before[2]
                or model.sigma.detach().cpu().numpy().tobytes() != before[3]
                or model.coefficient.detach().cpu().numpy().tobytes() != before[4]
            ):
                raise ValueError(
                    "trained parameters/scale/coefficient mutated during qualification"
                )
            parameter_facts[tag]["post_forward_bit_invariants"] = True
        torch.cuda.synchronize()
        if (
            counts["Torch_attempted"] != 4
            or counts["Torch_returned"] != 4
            or counts["Torch_validated"] != 4
            or counts["Torch_rows_attempted"] != 16
        ):
            raise ValueError("exact four new trained calls/16 rows")
        write_json(
            output / "result.json",
            {
                "schema": "quoridor.public-no-bypass.trained-qualification.v1",
                "counts": counts,
                "native": native,
                "native_process": native_process,
                "scores": scores,
                "actual_head_D_Zero4_exact": True,
                "parameters_scale_coefficient_unchanged": True,
                "CUDA_peak_allocated_B": torch.cuda.max_memory_allocated(),
                "CUDA_peak_reserved_B": torch.cuda.max_memory_reserved(),
                "whole_seconds": time.monotonic() - beginning,
                "teacher_labels": None,
                "scope": "fixed genuine legal qualification inputs, not fullV/reliability/strength or universal delta certificate",
            },
        )
    except BaseException as error:
        primary = error
        failed_slots(slots)
    finally:

        def parameter_collection(payload, secondary):
            for tag, model in models:
                if parameter_facts[tag].get("post_forward_bit_invariants") is True:
                    continue  # Reuse the actual successful snapshot, never repeat a forward.
                try:
                    parameter_facts[tag]["partial_current_parameter_SHA256"] = (
                        helpers.parameter_sha(model)
                    )
                    for name in ["mu", "sigma", "coefficient"]:
                        parameter_facts[tag][name + "_partial_bits"] = (
                            getattr(model, name).detach().cpu().numpy().view(np.uint32).tolist()
                        )
                except BaseException as error:
                    parameter_facts[tag]["partial_snapshot"] = "UNKNOWN"
                    secondary.append(("partial_parameters_" + tag, error))

        finish_capture(
            output,
            primary,
            {
                "counts": counts,
                "native_process_returned": native_process,
                "native_available": native if native is not None else "UNKNOWN",
                "observations": [],
                "scores_available": scores,
                "Torch_slots": slots,
                "initial_snapshots": [
                    {
                        "checkpoint": item[0],
                        "parameter_SHA256": item[1],
                        "mu_bytes_hex": item[2].hex(),
                        "sigma_bytes_hex": item[3].hex(),
                        "coefficient_bytes_hex": item[4].hex(),
                    }
                    for item in initial_snapshots
                ],
                "parameter_facts": parameter_facts,
                "no_optimizer_fit_games": True,
                "counter_domain": "Torch helper Tensor-return counted before copy/validation; native execute-success and raw child-return separate; unavailable facts UNKNOWN",
                "scope": "ordinary returned errors/cancellation/collection/publication; no universal asynchronous process-fault guarantee",
            },
            [
                (
                    "observation_capture",
                    lambda payload, errors: capture_arrays(observations, payload, errors),
                ),
                (
                    "native_saved_reconciliation",
                    lambda payload, errors: reconcile_native(output, payload, errors),
                ),
                ("parameter_collection", parameter_collection),
            ],
            write_json,
            lambda payload: print(json.dumps(payload, allow_nan=False), file=sys.stderr),
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    args = parser.parse_args()
    main(json.loads(args.config.read_text()))
