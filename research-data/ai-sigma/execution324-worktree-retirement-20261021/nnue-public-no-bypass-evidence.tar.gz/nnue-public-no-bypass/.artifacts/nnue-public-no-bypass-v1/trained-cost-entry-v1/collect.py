"""Verify saved eight-call cost data and release, without extra Search calls."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import sys

ROOT = Path(
    "/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1"
)
HERE = ROOT / "trained-cost-entry-v1"
OUTPUT = ROOT / "native-qualification-v1/trained-cost-v1/cost.json"


def identity(path):
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {
        "SHA256": digest,
        "bytes": path.stat().st_size,
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def main():
    with Path(
        "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
    ).open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        spec = importlib.util.spec_from_file_location("entry353", ROOT / "entry_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        guard.quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        assert memory > 512 * 1024**2 + 4 * 1024**3
        admission = json.loads((HERE / "admission.json").read_text())
        result = json.loads((HERE / "job-runtime/result.json").read_text())
        state = json.loads((HERE / "job-runtime/state.json").read_text())
        start = json.loads((HERE / "worker-runtime/START.json").read_text())
        worker = json.loads((HERE / "worker-runtime/STOP.json").read_text())
        cost = json.loads(OUTPUT.read_text())
        assert result["job_id"] == "7781a252-586b-4dd4-8b79-c908a7c4e078"
        assert (
            result["exit_code"] == 0
            and result["direct_child_reaped"] is True
            and result["cleanup_complete"] is True
            and result["remaining"] == []
        )
        assert worker["primary"] is None and worker["secondary"] == [] and worker["remaining"] == []
        assert len(worker["returned_processes"]) == 1
        returned = worker["returned_processes"][0]
        assert returned["command"] == ["/usr/bin/taskset", "-c", "0", *admission["commands"][0]]
        assert (
            returned["exit_code"] == 0
            and returned["direct_child_reaped"] is True
            and returned["handle_closes_complete"] is True
            and returned["process_cleanup_complete"] is True
            and returned["remaining"] == []
        )
        assert returned["log_bytes_seen"] == returned["log_bytes_retained"]
        assert (
            cost["schema"] == "quoridor.public-no-bypass.whole-search-cost.v1"
            and cost["status"] == "COMPLETE"
        )
        assert cost["primary"] is None and cost["secondary"] == []
        assert (
            cost["Search_calls"]
            == cost["Search_calls_returned"]
            == cost["Search_calls_validated"]
            == 8
        )
        assert (
            cost["all_complete_finite_legal"] is True
            and cost["authority_clock_qualification"] is False
        )
        assert (
            cost["games_fit_teacher"] == 0
            and cost["requested_depth"] == 2
            and len(cost["rows"]) == 8
        )
        prefixes = [[], [13], [13, 67], [13, 67, 81, 66, 14, 65]]
        summaries = {}
        total_nodes = 0
        for model_index, tag in enumerate(["candidate BEST", "retained BEST51"]):
            rows = cost["rows"][model_index * 4 : model_index * 4 + 4]
            assert [row["prefix"] for row in rows] == prefixes
            nodes = 0
            for row in rows:
                assert (
                    row["checkpoint"] == tag
                    and row["state"] == "VALIDATED"
                    and row["error"] is None
                    and row["full_history_unchanged"] is True
                )
                search = row["result"]
                assert (
                    search["requested_depth2_complete_finite_legal"] is True
                    and search["completed_depth"] == 2
                )
                assert math.isfinite(search["value"]) and search["action"] == search["PV"][0]
                n = search["whole_invocation_counters"]["nodes"]
                assert type(n) is int and 0 <= n <= 100000
                nodes += n
                for field in [
                    "session_setup_seconds",
                    "search_including_rootFT_head_delta_seconds",
                    "session_drop_seconds",
                    "whole_root_setup_search_drop_seconds",
                ]:
                    assert math.isfinite(row[field]) and row[field] >= 0
            summaries[tag] = {
                "matched_depth2_calls": 4,
                "nodes": nodes,
                "search_seconds": sum(
                    row["search_including_rootFT_head_delta_seconds"] for row in rows
                ),
                "whole_root_setup_search_drop_seconds": sum(
                    row["whole_root_setup_search_drop_seconds"] for row in rows
                ),
                "model_setup_drop": cost["models"][model_index],
            }
            total_nodes += nodes
        assert total_nodes == cost["aggregate_nodes"] and total_nodes <= 800000
        for path, binding in admission["bindings"].items():
            guard.identity_bytes(path, binding)
        sys.path.insert(0, str(ROOT.parents[1] / "python"))
        from quoridor_training import cycle_process

        members = [returned["child"], start["identity"]]
        assert all(not cycle_process.alive(member) for member in members)
        paths = [
            HERE / name
            for name in [
                "job-runtime/result.json",
                "job-runtime/state.json",
                "job-runtime/config.json",
                "job-runtime/output.log",
                "worker-runtime/START.json",
                "worker-runtime/STOP.json",
                "worker-runtime/command-0.log",
                "worker-runtime/command-0.process.json",
                "admission.json",
            ]
        ] + [OUTPUT]
        receipt = {
            "schema": "quoridor.public-no-bypass.fixed-eight-cost-qualified-STOP.v1",
            "issue": "quoridor-4lc.353",
            "job_id": result["job_id"],
            "controller_START": state["started_at"],
            "worker_START": start["control_START"],
            "worker_STOP": worker["STOP"],
            "controller_STOP": result["finished_at"],
            "whole_controller_seconds": result["wall_seconds"],
            "nested_native_seconds_not_added": returned["wall_seconds"],
            "fixed_calls_attempted_returned_validated": [8, 8, 8],
            "aggregate_nodes": total_nodes,
            "model_summaries": summaries,
            "whole_native_setup_load_search_drop_seconds": cost[
                "whole_setup_load_search_drop_seconds"
            ],
            "raw_refs": {str(path): identity(path) for path in paths},
            "source_refs": admission["bindings"],
            "source_after_exact_count": len(admission["bindings"]),
            "primary": None,
            "secondary": [],
            "owned_remaining": [],
            "two_exact_identities_fresh_absent": members,
            "sample_family_RSS_B": worker["sample_family_RSS_including64MiB_B"],
            "sample_positive_component_maxima_B": worker["sample_component_maxima_B"],
            "continuous_peak": "UNKNOWN",
            "old_floors_RAW_failed_fees_TMP_masks": "held no refund; returned completed distinct from persisted pending/attempted",
            "current_next_Cargo_model_native_Search_fair_reservation": "NONE",
            "collector_reader_STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "scope": "fixed four-prefix paired work/setup/drop observations; differing nodes not arithmetic speed; no 100ms/strength/CPU-share certificate",
        }
        with (HERE / "qualified-cost-STOP.json").open("x") as stream:
            stream.write(json.dumps(receipt, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "receipt": str(HERE / "qualified-cost-STOP.json"),
                    **identity(HERE / "qualified-cost-STOP.json"),
                    "models": summaries,
                    "STOP": receipt["collector_reader_STOP"],
                }
            )
        )


if __name__ == "__main__":
    main()
