"""Fixed eight-call native cost preparation; no Search/model invocation here."""

import datetime
import difflib
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path(
    "/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1"
)
HERE = ROOT / "trained-cost-entry-v1"
NUMERIC = ROOT / "trained-numerical-entry-v2"
INCUMBENT = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/trigger-patience-v1/patience1/output/best-model"
)


def identity(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise ValueError("direct regular binding")
    with path.open("rb") as stream:
        sha = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"SHA256": sha, "bytes": info.st_size, "mode": f"{stat.S_IMODE(info.st_mode):04o}"}


def write(name, obj):
    with (HERE / name).open("x") as stream:
        stream.write(json.dumps(obj, indent=2) + "\n")


def main():
    with Path(
        "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
    ).open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        affinity = os.sched_getaffinity(0)
        if not {0, 2}.issubset(affinity):
            raise ValueError("current native/controller affinity")
        os.sched_setaffinity(0, {3})
        spec = importlib.util.spec_from_file_location("entry353", ROOT / "entry_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        guard.quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        if memory < 6 * 1024**3:
            raise ValueError("family2GiB plus4GiB host reserve")
        physical = [
            tuple(
                Path(f"/sys/devices/system/cpu/cpu{c}/topology/{n}").read_text().strip()
                for n in ("physical_package_id", "core_id")
            )
            for c in (0, 2)
        ]
        if len(set(physical)) != 2:
            raise ValueError("native/controller distinct physical cores")
        fs = os.statvfs(ROOT)
        free = fs.f_bavail * fs.f_frsize
        if free < 4 * 1024**3:
            raise ValueError("fresh whole phase storage headroom")
        config = json.loads((NUMERIC / "admission.actual-formatted.json").read_text())
        qualified = json.loads((NUMERIC / "qualified-trained-STOP.corrected.json").read_text())
        config["stage"] = "cost"
        config["worker_CPUs"] = [0]
        config["controller_CPU"] = 2
        config["family_RSS_upper_B"] = 2 * 1024**3
        config["runtime"] = str(HERE / "worker-runtime")
        config["prepare_owned_parents"] = [str(ROOT / "native-qualification-v1/trained-cost-v1")]
        config["commands"] = [
            [
                str(ROOT / "private-images-v1/whole-cost-v2"),
                str(guard.ASSETS / "candidate-v1/output/best-model/manifest.json"),
                str(INCUMBENT / "manifest.json"),
                str(ROOT / "head-input-prefixes-v1.json"),
                str(ROOT / "native-qualification-v1/trained-cost-v1/cost.json"),
            ]
        ]
        config["planned_counts"] = {
            "native_command": 1,
            "Search_attempted_upper": 8,
            "depth_each": 2,
            "nodes_each_upper": 100000,
            "nodes_aggregate_upper": 800000,
            "Torch_optimizer_fit_games_teacher": 0,
        }
        config["current_trained_numerical"] = {
            "path": str(NUMERIC / "qualified-trained-STOP.corrected.json"),
            "identity": identity(NUMERIC / "qualified-trained-STOP.corrected.json"),
        }
        config["numeric_guard_before"] = {
            "path": str(HERE / "entry_guard.before.py.gz"),
            "identity": identity(HERE / "entry_guard.before.py.gz"),
        }
        bindings = config["bindings"]
        bindings[str(ROOT / "entry_guard.py")] = identity(ROOT / "entry_guard.py")
        for path in [
            HERE / "entry_guard.before.py.gz",
            NUMERIC / "qualified-trained-STOP.corrected.json",
            INCUMBENT / "manifest.json",
            INCUMBENT / "weights.f32",
            *map(Path, qualified["raw_refs"]),
        ]:
            bindings[str(path)] = identity(path)
        if (
            bindings[str(INCUMBENT / "manifest.json")]["SHA256"]
            != "c4712e0872b6831e33fcf59b99d9d7f774d18a3e8d5236d7923ba65e64aabc39"
            or bindings[str(INCUMBENT / "weights.f32")]["SHA256"]
            != "9ca438e43b0c105ac5f802a302946f2ba71623ea2bc443b9c54cc9a8468b75b0"
        ):
            raise ValueError("retained exact original BEST51 identity")
        observations = []
        for item in config["storage_components"]:
            observed = guard.charged(item["roots"], item.get("excluded", ()))
            held = max(
                observed,
                item["retained_floor_B"],
                qualified["sample_positive_component_maxima_B"][item["name"]],
            )
            forward = {"controls": 8388608, "native_qualification": 4194304, "TMP": 67108864}.get(
                item["name"], 0
            )
            if held + forward > item["upper_B"]:
                raise ValueError("contained forward gap: " + item["name"])
            item["retained_floor_B"] = held
            if item["name"] == "TMP":
                item["roots"].append(str(HERE / "worker-runtime/TMP"))
            observations.append(
                {
                    "name": item["name"],
                    "sample_B": observed,
                    "held_floor_B": held,
                    "forward_B": forward,
                    "upper_B": item["upper_B"],
                }
            )
        config["preparation_physics"] = {
            "MemAvailable_B": memory,
            "filesystem_free_B": free,
            "physical_CPU0_CPU2": physical,
            "namedquiet": [],
        }
        config["fresh_preparation_device"] = "CPU-only/GPU0; no CUDA import or device workload"
        config["actual_latest_model_fit0"] = "eight fixed native Search calls; no Torch/fit/game"
        for path, expected in bindings.items():
            guard.identity_bytes(path, expected)
        guard.supported_commands(config)
        guard.trained_boundary_clear(config)
        for review in config["source_reviews"]:
            guard.review_clear(review)
        for path in [
            HERE / "worker-runtime",
            HERE / "job-runtime",
            ROOT / "native-qualification-v1/trained-cost-v1",
        ]:
            if path.exists():
                raise FileExistsError("exclusive cost namespace already exists: " + str(path))
        write(
            "retained-and-forward-ledger.json",
            {
                "before_entry_UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "components": observations,
                "whole_upper_B": sum(x["upper_B"] for x in config["storage_components"]),
                "all_old_floors_RAW_fees_masks_unknown": "HELD no refunds",
            },
        )
        write("admission.json", config)
        formatter = "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier"
        subprocess.run(
            [formatter, "--ignore-path", "/dev/null", "--write", str(HERE / "admission.json")],
            check=True,
        )
        job = {
            "issue": "quoridor-4lc.353",
            "goal_issue": "quoridor-4lc",
            "thread_id": "01a1100f-6d45-78e0-8a87-84503ff0fbf6",
            "cwd": "/workspaces/quoridor/.worktree/learning-million",
            "argv": [
                "/usr/bin/python3",
                "-B",
                str(ROOT / "entry_guard.py"),
                str(HERE / "admission.json"),
                "--sha256",
                identity(HERE / "admission.json")["SHA256"],
            ],
            "end_at": None,
            "notify_until": None,
            "max_runtime_seconds": 210,
            "control_interval_seconds": 30,
            "notify_interval_seconds": 10,
            "request_timeout_seconds": 25,
            "log_max_bytes": 1048576,
            "resource_contract": str(guard.PROOF),
        }
        write("job-config.json", job)
        subprocess.run(
            [
                formatter,
                "--ignore-path",
                "/dev/null",
                "--check",
                str(HERE / "admission.json"),
                str(HERE / "job-config.json"),
            ],
            check=True,
        )
        before = gzip.decompress((HERE / "entry_guard.before.py.gz").read_bytes()).decode()
        after = (ROOT / "entry_guard.py").read_text()
        with (HERE / "control-only.patch").open("x") as stream:
            stream.write(
                "".join(
                    difflib.unified_diff(
                        before.splitlines(True),
                        after.splitlines(True),
                        fromfile="a/entry_guard.py",
                        tofile="b/entry_guard.py",
                    )
                )
            )
        stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(
            "prepared-source-STOP.json",
            {
                "schema": "quoridor.public-no-bypass.fixed-eight-cost.prepared.v1",
                "READY": True,
                "actual_START": None,
                "reservation": "NONE",
                "source_writer_reader_STOP": stop,
                "bindings": bindings,
                "admission": identity(HERE / "admission.json"),
                "job_config": identity(HERE / "job-config.json"),
                "fixed_counts": config["planned_counts"],
                "physics": config["preparation_physics"],
                "current_software": config["current_trained_software"],
                "current_trained": config["current_trained_numerical"],
                "owned_readers_children_jobs_TMP": [],
                "actual_permission_context": config["actual_permission_context"],
                "continuous_peak": "UNKNOWN",
            },
        )
        print(
            json.dumps(
                {"READY": True, "STOP": stop, "admission": identity(HERE / "admission.json")}
            )
        )


if __name__ == "__main__":
    main()
