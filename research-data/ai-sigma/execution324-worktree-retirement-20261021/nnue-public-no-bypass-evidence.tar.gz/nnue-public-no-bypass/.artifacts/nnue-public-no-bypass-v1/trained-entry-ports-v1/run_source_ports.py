"""Use the same canonical finite source-port guardian for three NEW controls."""

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "port_guard", ROOT.parent / "clock-repair-v1/run_source_ports.py"
)
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
driver.ROOT = ROOT
driver.WT = ROOT.parents[2]
if __name__ == "__main__":
    driver.run()
