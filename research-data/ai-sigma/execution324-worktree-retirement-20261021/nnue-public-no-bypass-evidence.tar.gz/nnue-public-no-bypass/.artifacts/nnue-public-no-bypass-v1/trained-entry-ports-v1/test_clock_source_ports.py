"""Three NEW no-model ports of the current353 admission parser and scope."""

import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import unittest

ROOT = Path(__file__).resolve().parent
TASK = ROOT.parent
spec = importlib.util.spec_from_file_location("entry", TASK / "entry_guard.py")
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)


def identity(path):
    info = path.stat()
    return {
        "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": info.st_size,
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


class EntryPorts(unittest.TestCase):
    def test_actual_clock_receipt_is_parsed_and_old_blocker_receipt_refuses(self):
        base = Path("/workspaces/quoridor/.artifacts/nnue-public-no-bypass-review353-v1")
        receipt = base / "clock-related-v2/control.json"
        actual = json.loads(receipt.read_text())
        expected = {
            "path": str(receipt),
            "identity": identity(receipt),
            "review_issue": "quoridor-4lc.353.3",
            "reviewed_boundary": actual["reviewed_boundary"],
            "target": actual["target_binding"]["path"],
        }
        entry.review_clear(expected)
        old = base / "clock-v1/control.json"
        old_actual = json.loads(old.read_text())
        expected.update(
            path=str(old),
            identity=identity(old),
            reviewed_boundary=old_actual["reviewed_boundary"],
            target=old_actual["target_binding"]["path"],
        )
        with self.assertRaisesRegex(ValueError, "not clear"):
            entry.review_clear(expected)

    def test_completed_fit_has_no_active_guard_entry(self):
        with self.assertRaisesRegex(ValueError, "unsupported353 stage"):
            entry.supported_commands({"stage": "fit"})

    def test_five_fixed_affected_commands_accept_and_extra_command_refuses(self):
        path = TASK / "trained-qualification-v1/software-source-plan-v1.json"
        plan = json.loads(path.read_text())
        config = {
            "stage": "software",
            "commands": plan["commands"],
            "operational_seconds": 180,
            "bindings": {str(path): identity(path)},
        }
        entry.supported_commands(config)
        config["commands"] = config["commands"] + [["/usr/bin/true"]]
        with self.assertRaisesRegex(ValueError, "exact unfinished11"):
            entry.supported_commands(config)


if __name__ == "__main__":
    unittest.main(verbosity=2)
