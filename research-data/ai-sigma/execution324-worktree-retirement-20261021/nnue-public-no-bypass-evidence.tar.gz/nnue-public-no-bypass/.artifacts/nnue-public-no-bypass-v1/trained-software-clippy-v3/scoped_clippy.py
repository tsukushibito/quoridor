"""Finish353 scoped lint without changing unrelated immutable depth6 bodies.

The overall Cargo101 and every diagnostic remain raw evidence. Only two exact
prebound unchanged-source diagnostics are outside this changed-boundary scope.
No lint is disabled, and any additional warning/error or partial capture fails.
"""

import datetime
import hashlib
import json
from pathlib import Path
import sys

from quoridor_training import cycle_process as process


EXPECTED = {
    ("clippy::cmp_owned", "crates/quoridor-runner/src/teacher_pilot/depth6.rs", 31, 31),
    (
        "clippy::large_enum_variant",
        "crates/quoridor-runner/src/teacher_pilot_execution/depth6.rs",
        34,
        41,
    ),
}


def classify(lines, exit_code):
    observed, diagnostics, finished = [], [], []
    for line in lines:
        if not line.strip():
            continue
        if not line.startswith("{"):
            text = line.strip()
            if text.startswith(("Checking ", "Compiling ")) or text == (
                "error: could not compile `quoridor-runner` (lib) due to 2 previous errors"
            ):
                continue
            raise ValueError("unexpected or incomplete Cargo capture: " + text)
        value = json.loads(line)
        reason = value.get("reason")
        if reason == "compiler-message":
            message = value["message"]
            primary = [s for s in message["spans"] if s["is_primary"]]
            if message["level"] != "error" or len(primary) != 1:
                raise ValueError("unbound compiler warning/error")
            span = primary[0]
            signature = (
                message["code"]["code"],
                span["file_name"],
                span["line_start"],
                span["line_end"],
            )
            if signature not in EXPECTED:
                raise ValueError("new or changed diagnostic: " + repr(signature))
            observed.append(signature)
            diagnostics.append(message)
        elif reason == "build-finished":
            finished.append(value.get("success"))
        elif reason not in ("compiler-artifact", "build-script-executed"):
            raise ValueError("unknown Cargo message domain")
    if exit_code != 101 or len(observed) != 2 or set(observed) != EXPECTED or finished != [False]:
        raise ValueError("complete exact unrelated diagnostic census not established")
    return diagnostics


def run(config_path):
    config = json.loads(Path(config_path).read_text())
    root = Path(config["WT"])
    for relative, expected in config["unchanged_foreign_source_SHA256"].items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
            raise ValueError("unrelated diagnostic source changed")
    plan = json.loads(Path(config["source_plan"]).read_text())
    argv = list(plan["commands"][-1])
    argv.insert(argv.index("--no-deps"), "--message-format=json")
    directory = Path(config["runtime"])
    directory.mkdir()
    deadline = __import__("time").monotonic() + 150
    primary, record = None, None
    try:
        record = process.execute(argv, directory / "cargo.log", deadline)
    except process.CycleStopped as error:
        primary = error
        record = json.loads((directory / "cargo.process.json").read_text())
    if (
        record is None
        or record.get("direct_child_reaped") is not True
        or record.get("process_cleanup_complete") is not True
        or record.get("handle_closes_complete") is not True
        or record.get("remaining") != []
        or record.get("finalization_errors") != []
        or record.get("log_bytes_seen") != record.get("log_bytes_retained")
        or record["log_bytes_seen"] > 8388608
    ):
        raise ValueError("exact full Cargo wait/capture/cleanup required") from primary
    try:
        diagnostics = classify(
            (directory / "cargo.log").read_text().splitlines(), record["exit_code"]
        )
    except BaseException as error:
        if primary is not None:
            primary.add_note("scoped classification also refused: " + repr(error))
            raise primary from error
        raise
    for relative, expected in config["unchanged_foreign_source_SHA256"].items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
            raise ValueError("unrelated diagnostic source-after changed")
    receipt = {
        "schema": "quoridor.public-no-bypass.scoped-clippy.v1",
        "scope": "353 changed clock/runtime/bin/cost source only; two exact immutable unrelated diagnostics excluded",
        "scoped_clear": True,
        "overall_Cargo_outcome": "FAILED101, not whole-library lint clear",
        "original_Cargo_error": str(primary),
        "diagnostics": diagnostics,
        "unchanged_foreign_source_SHA256": config["unchanged_foreign_source_SHA256"],
        "process": record,
        "STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "owned_remaining": [],
        "no_lints_disabled": True,
    }
    (directory / "scoped-STOP.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(
        json.dumps(
            {
                "scoped_clear": True,
                "overall_Cargo_exit": 101,
                "receipt": str(directory / "scoped-STOP.json"),
            }
        )
    )


if __name__ == "__main__":
    run(sys.argv[1])
