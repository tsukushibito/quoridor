"""New353 receipt-chain/unfinished-command guards, stdlib only and no child."""

import ast
import copy
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import stat
import sys
import time

WT = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass")
ROOT = WT / ".artifacts/nnue-public-no-bypass-v1"
HERE = ROOT / "trained-partial-software-v5"
MAIN = Path("/workspaces/quoridor")
GUARD = ROOT / "entry_guard.py"


def identity(path):
    s = path.lstat()
    return {
        "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": s.st_size,
        "mode": f"{stat.S_IMODE(s.st_mode):04o}",
    }


def main():
    beginning = time.monotonic()
    cases = []
    with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        source = GUARD.read_text()
        tree = ast.parse(source)
        names = {"identity_bytes", "trained_boundary_clear", "supported_commands", "quiet"}
        nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
        assert len(nodes) == len(names)
        env = dict(
            WT=WT,
            ROOT=ROOT,
            Path=Path,
            os=os,
            sys=sys,
            re=re,
            json=json,
            stat=stat,
            hashlib=hashlib,
            datetime=datetime,
        )
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(GUARD), "exec"), env)
        env["quiet"]()
        assert 3 in os.sched_getaffinity(0)
        memory = (
            int(re.search(r"MemAvailable:\s+(\d+)", Path("/proc/meminfo").read_text())[1]) * 1024
        )
        assert memory > 512 * 1024**2 + 4 * 1024**3
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        reviews = {}
        docs = {}
        for name, directory in [
            ("partial", "trained-boundary-related-v2"),
            ("timing", "trained-timing-related-v3"),
        ]:
            path = (
                MAIN / ".artifacts/nnue-public-no-bypass-review353-v1" / directory / "control.json"
            )
            v = json.loads(path.read_text())
            target = Path(v["target_binding_path"])
            reviews[name] = {
                "path": str(path),
                "identity": identity(path),
                "target": str(target),
                "target_identity": identity(target),
                "reviewed_boundary": v["reviewed_boundary"],
            }
            docs[str(path)] = v
            docs[str(target)] = json.loads(target.read_text())
        config = {"trained_boundary_reviews": reviews}
        env["trained_boundary_clear"](config)
        cases.append("actual complementary typed receipts/current identities accepted")
        before = identity(GUARD)
        # Synthetic parser ports authenticate fixture identity at the stub layer;
        # no synthetic receipt is written or admitted as real source proof.
        fixture = {}

        class FakePath:
            def __init__(self, raw):
                self.raw = str(raw)

            def read_text(self):
                return json.dumps(fixture[self.raw])

        real_path, real_identity = env["Path"], env["identity_bytes"]
        env["Path"] = FakePath
        env["identity_bytes"] = lambda path, expected: None
        partial = reviews["partial"]["path"]
        timing = reviews["timing"]["path"]
        timing_target = reviews["timing"]["target"]
        cost = str(WT / "crates/quoridor-runner/examples/public-no-bypass-cost.rs")
        mutations = [
            ("partial copied true refuses", lambda f: f[partial].update(source_clear=True)),
            ("numeric final clear refuses", lambda f: f[timing].update(source_clear=1)),
            ("boolean blockers refuses", lambda f: f[timing].update(blockers=False)),
            ("boolean ordinary refuses", lambda f: f[timing].update(ordinary=False)),
            (
                "target-only review refuses",
                lambda f: f[timing].update(schema="quoridor.target-only.v1"),
            ),
            ("wrong issue refuses", lambda f: f[timing].update(review_issue="quoridor-4lc.342.11")),
            ("unresolved timing refuses", lambda f: f[timing].update(T2_R1_resolved=False)),
            (
                "nonempty ownership refuses",
                lambda f: f[timing].update(owned_jobs=[{"synthetic": True}]),
            ),
            ("missing ownership refuses", lambda f: f[timing].pop("owned_TMP")),
            (
                "partial remaining differs refuses",
                lambda f: f[partial].update(remaining_findings=["T1"]),
            ),
            (
                "missing partial acceptance refuses",
                lambda f: f[partial].update(
                    T2_original_partial_evidence_loss_resolved_in_source=False
                ),
            ),
            (
                "target hash differs refuses",
                lambda f: f[timing].update(target_binding_SHA256="0" * 64),
            ),
            (
                "wrong current cost chain refuses",
                lambda f: f[timing]["current_cost_source"][cost].update(SHA256="0" * 64),
            ),
            (
                "wrong timing beforeimage refuses",
                lambda f: f[timing_target]["before"].update(SHA256="0" * 64),
            ),
            (
                "future STOP refuses",
                lambda f: f[timing].update(actual_source_reader_STOP="2099-01-01T00:00:00+00:00"),
            ),
            (
                "source release inversion refuses",
                lambda f: f[timing_target].update(
                    source_writer_reader_STOP="2026-10-09T19:30:00+00:00"
                ),
            ),
        ]
        for name, mutate in mutations:
            fixture.clear()
            fixture.update(copy.deepcopy(docs))
            mutate(fixture)
            try:
                env["trained_boundary_clear"](copy.deepcopy(config))
            except (ValueError, KeyError):
                cases.append(name)
            else:
                raise AssertionError(name)
        env["Path"], env["identity_bytes"] = real_path, real_identity

        def bad_identity(path, expected):
            raise ValueError("synthetic actual SHA/size/mode drift")

        env["identity_bytes"] = bad_identity
        try:
            env["trained_boundary_clear"](config)
        except ValueError:
            cases.append("actual hash/size/mode identity layer refuses before parser")
        else:
            raise AssertionError("identity drift accepted")
        env["identity_bytes"] = real_identity
        plan_path = HERE / "compiler-source-plan.json"
        plan = json.loads(plan_path.read_text())
        expected = plan["commands"][:-1] + [
            [
                "/usr/bin/python3",
                "-B",
                str(ROOT / "trained-software-clippy-v4/scoped_clippy.py"),
                str(HERE / "scoped-clippy-config.json"),
            ]
        ]
        stage = {
            "stage": "software",
            "bindings": {str(plan_path): identity(plan_path)},
            "commands": expected,
            "operational_seconds": 180,
        }
        env["supported_commands"](stage)
        cases.append("exact affected five-command stage accepted without execution")
        for name, mutate in [
            ("extra command refuses", lambda v: v["commands"].append(["/bin/true"])),
            ("old clock filter refuses", lambda v: v["commands"][0].__setitem__(-3, "receipt_353")),
            ("altered operational cap refuses", lambda v: v.update(operational_seconds=181)),
            ("fit stage refuses", lambda v: v.update(stage="fit")),
        ]:
            v = copy.deepcopy(stage)
            mutate(v)
            try:
                env["supported_commands"](v)
            except ValueError:
                cases.append(name)
            else:
                raise AssertionError(name)
        assert identity(GUARD) == before
        assert not any(x in sys.modules for x in ["torch", "numpy", "quoridor_training.train"])
        rss = int(re.search(r"VmRSS:\s+(\d+)", Path("/proc/self/status").read_text())[1]) * 1024
        assert rss + 64 * 1024**2 < 512 * 1024**2
        payload = {
            "schema": "quoridor.public-no-bypass.receipt-command.guard-ports.v5",
            "STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "whole_seconds": time.monotonic() - beginning,
            "PASS": len(cases),
            "cases": cases,
            "actual_guard_before_after": before,
            "parsed_actual_receipts": reviews,
            "synthetic_source_permits_written": 0,
            "Cargo_model_framework_native_Search_optimizer_fit_game_calls": 0,
            "direct_child_waits": 0,
            "remaining": [],
            "TMP": [],
            "namedquiet": [],
            "CPU": 3,
            "AS_B": 512 * 1024**2,
            "MemAvailable_B": memory,
            "sample_family_including64MiB_B": rss + 64 * 1024**2,
            "continuous_peak": "UNKNOWN",
            "scope": "actual new guard functions, synthetic failclosed parser cases; no run/lifecycle or model calls",
        }
        with (HERE / "guard-ports-STOP.json").open("x") as stream:
            stream.write(json.dumps(payload, indent=2) + "\n")
        print(json.dumps({"PASS": len(cases), "runtime_calls": 0, "remaining": []}))


if __name__ == "__main__":
    main()
