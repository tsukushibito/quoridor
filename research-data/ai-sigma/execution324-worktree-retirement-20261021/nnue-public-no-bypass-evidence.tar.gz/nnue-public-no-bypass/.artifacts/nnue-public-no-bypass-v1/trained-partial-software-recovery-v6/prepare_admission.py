"""Fresh directed353 software preparation; no build/model calls or global walk."""

import datetime
import difflib
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import time

WT = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass")
ROOT = WT / ".artifacts/nnue-public-no-bypass-v1"
HERE = ROOT / "trained-partial-software-recovery-v6"
MAIN = Path("/workspaces/quoridor")


def identity(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"SHA256": digest, "bytes": info.st_size, "mode": f"{stat.S_IMODE(info.st_mode):04o}"}


def write(name, value):
    with (HERE / name).open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


def main():
    beginning = time.monotonic()
    with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        spec = importlib.util.spec_from_file_location("entry353", ROOT / "entry_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        guard.quiet()
        memory = (
            int(
                next(
                    line.split()[1]
                    for line in Path("/proc/meminfo").read_text().splitlines()
                    if line.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        assert memory > 6 * 1024**3 + 4 * 1024**3
        assert {2, 4}.issubset(os.sched_getaffinity(0))
        physical = [
            tuple(
                Path(f"/sys/devices/system/cpu/cpu{core}/topology/{n}").read_text().strip()
                for n in ["physical_package_id", "core_id"]
            )
            for core in [2, 4]
        ]
        assert len(set(physical)) == 2
        fs = os.statvfs(ROOT)
        free = fs.f_bavail * fs.f_frsize
        assert free > 4 * 1024**3
        old = json.loads((ROOT / "trained-partial-software-v5/admission.json").read_text())
        old_qualified = json.loads(
            (ROOT / "trained-partial-software-v5/worker-runtime/STOP.json").read_text()
        )
        config = {
            k: v
            for k, v in old.items()
            if k
            not in [
                "software_completed_prefix",
                "software_completed_release",
                "private_images_already_retained",
            ]
        }
        config["runtime"] = str(HERE / "worker-runtime")
        assert not Path(config["runtime"]).exists() and not (HERE / "job-runtime").exists()
        plan = json.loads(
            (ROOT / "trained-partial-software-v5/compiler-source-plan.json").read_text()
        )
        config["commands"] = plan["commands"][2:-1] + [
            [
                "/usr/bin/python3",
                "-B",
                str(ROOT / "trained-software-clippy-v4/scoped_clippy.py"),
                str(HERE / "scoped-clippy-config.json"),
            ]
        ]
        config["private_images"] = {
            "trained-native-v2": "examples/public-no-bypass-input",
            "whole-cost-v2": "examples/public-no-bypass-cost",
        }
        assert all(
            not (ROOT / "private-images-v1" / name).exists() for name in config["private_images"]
        )
        config["new_Rust_definitions"] = 5
        config["private_forward_upper_B"] = 2097152
        config["actual_latest_model_fit0"] = (
            "Only new observer tests/changed examples/software; actual fit already completed, no replay"
        )
        config["old_initial_Rust_Torch_native_Adam_fit_success_not_replayed"] = True
        config["preparation_physics"] = {
            "MemAvailable_B": memory,
            "physical_cpu2_cpu4": physical,
            "filesystem_free_B": free,
            "namedquiet": [],
        }
        reviews = {}
        for name, directory in [
            ("partial", "trained-boundary-related-v2"),
            ("timing", "trained-timing-related-v3"),
        ]:
            path = (
                MAIN / ".artifacts/nnue-public-no-bypass-review353-v1" / directory / "control.json"
            )
            actual = json.loads(path.read_text())
            target = Path(actual["target_binding_path"])
            reviews[name] = {
                "path": str(path),
                "identity": identity(path),
                "target": str(target),
                "target_identity": identity(target),
                "reviewed_boundary": actual["reviewed_boundary"],
            }
        config["trained_boundary_reviews"] = reviews
        config["routine_observer_repairs"] = json.loads((HERE / "routine-repairs.json").read_text())
        previous = ROOT / "trained-partial-software-v5"
        config["completed_partial_scope"] = {
            str(previous / name): identity(previous / name)
            for name in [
                "admission.json",
                "worker-runtime/STOP.json",
                "job-runtime/result.json",
                "worker-runtime/command-0.log",
                "worker-runtime/command-1.log",
            ]
        }
        guard.trained_boundary_clear(config)
        for row in config["source_reviews"]:
            guard.review_clear(row)
        # Only the actually changed source/control refs are refreshed. Unchanged
        # compiler and dependency identities must match their qualified binding.
        mutable = {
            str(ROOT / "entry_guard.py"),
            str(WT / "crates/quoridor-nnue/examples/public-no-bypass-input.rs"),
            str(WT / "crates/quoridor-runner/examples/public-no-bypass-cost.rs"),
            str(ROOT / "trained-software-clippy-v4/scoped_clippy.py"),
        }
        bindings = config["bindings"]
        bindings.pop(str(ROOT / "trained-qualification-v1/software-source-plan-v1.json"), None)
        bindings.pop(str(ROOT / "trained-software-clippy-v4/scoped-clippy-config.json"), None)
        for name in ["public-no-bypass-input", "public-no-bypass-cost"]:
            bindings.pop(str(ROOT / "build-target-v1/release/examples" / name), None)
        # Only these two requested rebuilt outputs are mutable; unchanged runner image remains bound.
        for raw, expected in list(bindings.items()):
            if raw in mutable:
                bindings[raw] = identity(Path(raw))
            else:
                guard.identity_bytes(raw, expected)
        named = [
            ROOT / "trained-partial-software-v5/compiler-source-plan.json",
            HERE / "scoped-clippy-config.json",
            HERE / "routine-ports-STOP.json",
            ROOT / "trained-qualification-v1/qualify_trained.py",
        ]
        for row in reviews.values():
            named += [Path(row["path"]), Path(row["target"])]
        for row in config["routine_observer_repairs"].values():
            named += [Path(row["before_gzip"])]
        named += [Path(path) for path in config["completed_partial_scope"]]
        for path in named:
            bindings[str(path)] = identity(path)
        observations = []
        for component in config["storage_components"]:
            observed = guard.charged(component["roots"], component.get("excluded", ()))
            held = max(
                component.get("retained_floor_B", 0),
                old_qualified["sample_component_maxima_B"][component["name"]],
                observed,
            )
            if component["name"] == "build_target":
                held = max(held, 614277120)
                assert held + 134217728 <= 766578688
                component["upper_B"] = 766578688
            if component["name"] == "private_images":
                held = max(held, 10760192)
                assert held + 2097152 <= 33554432
                component["upper_B"] = max(component["upper_B"], held + 2097152)
            if component["name"] == "review":
                held = max(held, 10485760)
            if component["name"] == "controls":
                # All5 outer1MiB logs + inner1MiB + controller1MiB and JSON/failure
                # receipts use a contained prospective8MiB, not the earlier1MiB guess.
                assert held + 8 * 1024**2 < component["upper_B"]
            if component["name"] == "TMP":
                component["roots"].append(str(HERE / "worker-runtime/TMP"))
                assert held + 67108864 < component["upper_B"]
            component["retained_floor_B"] = held
            assert held <= component["upper_B"]
            observations.append(
                {
                    "name": component["name"],
                    "observed_B": observed,
                    "held_floor_B": held,
                    "upper_B": component["upper_B"],
                }
            )
        assert sum(c["upper_B"] for c in config["storage_components"]) <= 4294967296
        config["raw_logs_forward_upper_B"] = 8388608
        config["actual_source_stop_permission_context"] = (
            "2026-10-09T19:55:58.504Z fullaccessnever/originallearning-million/gpt6.1-sol/high"
        )
        guard.supported_commands(config)
        write(
            "retained-and-forward-ledger.json",
            {
                "before_runtime_growth_UTC": datetime.datetime.now(
                    datetime.timezone.utc
                ).isoformat(),
                "components": observations,
                "whole_upper_B": sum(c["upper_B"] for c in config["storage_components"]),
                "new_log_receipts_forward_B": 8388608,
                "new_logs_inside_controls_B": 134217728,
                "old_forecast1MiB_log_guess_retained": "corrected prospectively to8MiB before job; no component/global grant",
                "new_private_two_B": 2097152,
                "new_build_growth_B": 134217728,
                "all_old_positive_floors_TMP_RAW_masks_fees_unknown": "HELD no refunds",
            },
        )
        write("admission.json", config)
        admission = HERE / "admission.json"
        job = {
            "issue": "quoridor-4lc.353",
            "goal_issue": "quoridor-4lc",
            "thread_id": "01a1100f-6d45-78e0-8a87-84503ff0fbf6",
            "cwd": "/workspaces/quoridor/.worktree/learning-million",
            "argv": [
                "/usr/bin/python3",
                "-B",
                str(ROOT / "entry_guard.py"),
                str(admission),
                "--sha256",
                identity(admission)["SHA256"],
            ],
            "end_at": None,
            "notify_until": None,
            "max_runtime_seconds": 210,
            "control_interval_seconds": 30,
            "notify_interval_seconds": 10,
            "request_timeout_seconds": 25,
            "log_max_bytes": 1048576,
            "resource_contract": str(guard.PROOF),
        }
        write("job-config.json", job)
        before_source = gzip.decompress((HERE / "entry_guard.before.py.gz").read_bytes()).decode()
        after_source = (ROOT / "entry_guard.py").read_text()
        patch = "".join(
            difflib.unified_diff(
                before_source.splitlines(True),
                after_source.splitlines(True),
                fromfile="a/.artifacts/nnue-public-no-bypass-v1/entry_guard.py",
                tofile="b/.artifacts/nnue-public-no-bypass-v1/entry_guard.py",
            )
        )
        with (HERE / "control-only.patch").open("x") as stream:
            stream.write(patch)
        assert all(identity(Path(p)) == expected for p, expected in bindings.items())
        write(
            "prepared-source-STOP.json",
            {
                "schema": "quoridor.public-no-bypass.unfinished-example.prepared-STOP.v6",
                "source_writer_reader_STOP": datetime.datetime.now(
                    datetime.timezone.utc
                ).isoformat(),
                "READY": True,
                "actual_START": None,
                "reservation": "NONE",
                "admission": identity(admission),
                "job_config": identity(HERE / "job-config.json"),
                "guard": identity(ROOT / "entry_guard.py"),
                "bindings": bindings,
                "actual_receipt_chain": reviews,
                "routine_source_repairs": config["routine_observer_repairs"],
                "actual_five_test_scope_reused": config["completed_partial_scope"],
                "new_guard_ports_PASS": 17,
                "old_eleven_tests_and_model_success_replayed": False,
                "new_five_Rust_defs": "ACTUAL_PASS5 reused from v5; definitions byte-identical",
                "model_calls": 0,
                "preflight_seconds": time.monotonic() - beginning,
                "fresh_physics": config["preparation_physics"],
                "canonical_nonblocking_lease": "preflight held; released; worker repeats beforeTMP/Popen",
                "owned_readers_children_jobs_TMP_remaining": [],
                "old_RAW_fees_masks_TMP_unknown": "HELD",
            },
        )
        print(
            json.dumps(
                {
                    "prepared": str(HERE / "prepared-source-STOP.json"),
                    "bindings": len(bindings),
                    "MemAvailable_B": memory,
                    "physical": physical,
                    "commands": 3,
                    "actual_START": None,
                    "remaining": [],
                }
            )
        )


if __name__ == "__main__":
    main()
