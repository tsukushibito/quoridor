"""353 exact mechanical source/proof reuse ports; stdlib, no child/model."""

import copy
import datetime
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import time

WT = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass")
ROOT = WT / ".artifacts/nnue-public-no-bypass-v1"
HERE = ROOT / "trained-partial-software-recovery-v6"
MAIN = Path("/workspaces/quoridor")


def identity(p):
    s = p.lstat()
    return {
        "SHA256": hashlib.sha256(p.read_bytes()).hexdigest(),
        "bytes": s.st_size,
        "mode": f"{stat.S_IMODE(s.st_mode):04o}",
    }


def main():
    begin = time.monotonic()
    with (MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock").open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        spec = importlib.util.spec_from_file_location("entry353", ROOT / "entry_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        guard.quiet()
        assert 3 in os.sched_getaffinity(0)
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        repairs = json.loads((HERE / "routine-repairs.json").read_text())
        old = json.loads((ROOT / "trained-partial-software-v5/admission.json").read_text())
        config = copy.deepcopy(old)
        config["routine_observer_repairs"] = repairs
        config["completed_partial_scope"] = {
            str(ROOT / "trained-partial-software-v5" / name): identity(
                ROOT / "trained-partial-software-v5" / name
            )
            for name in [
                "admission.json",
                "worker-runtime/STOP.json",
                "job-runtime/result.json",
                "worker-runtime/command-0.log",
                "worker-runtime/command-1.log",
            ]
        }
        for path, row in repairs.items():
            config["bindings"][path] = row["after"]
        guard.trained_boundary_clear(config)
        cases = ["actual reviewed source plus exact equivalent observer delta accepted"]
        plan = json.loads(
            (ROOT / "trained-partial-software-v5/compiler-source-plan.json").read_text()
        )
        guard.completed_partial_software(config, plan["commands"][:3])
        cases.append("actual five-test/partial-release directwait proof consumed without execution")
        for raw, row in repairs.items():
            before = gzip.decompress(Path(row["before_gzip"]).read_bytes()).decode()
            after = Path(raw).read_text()
            assert before.split("#[cfg(test)]", 1)[1] == after.split("#[cfg(test)]", 1)[1]
            cases.append(Path(raw).name + " successful test definitions exact unchanged")
            guard.reviewed_current_identity(config, raw, row["before"])
            for name, mutation in [
                (
                    "beforeidentity mismatch refuses",
                    lambda v: v["routine_observer_repairs"][raw]["before"].update(SHA256="0" * 64),
                ),
                (
                    "afteridentity mismatch refuses",
                    lambda v: v["routine_observer_repairs"][raw]["after"].update(SHA256="0" * 64),
                ),
                (
                    "aftermode mismatch refuses",
                    lambda v: v["routine_observer_repairs"][raw]["after"].update(mode="0600"),
                ),
                (
                    "archive identity mismatch refuses",
                    lambda v: v["routine_observer_repairs"][raw]["before_gzip_identity"].update(
                        bytes=0
                    ),
                ),
                (
                    "missing exact repair refuses current changed source",
                    lambda v: v["routine_observer_repairs"].pop(raw),
                ),
            ]:
                v = copy.deepcopy(config)
                mutation(v)
                try:
                    guard.reviewed_current_identity(v, raw, row["before"])
                except ValueError:
                    cases.append(Path(raw).name + " " + name)
                else:
                    raise AssertionError(name)
        v = copy.deepcopy(config)
        v["routine_observer_repairs"]["/unknown/alias.rs"] = {}
        try:
            raw = next(iter(repairs))
            guard.reviewed_current_identity(v, raw, repairs[raw]["before"])
        except ValueError:
            cases.append("extra source/path alias refuses")
        else:
            raise AssertionError("extra source accepted")
        for primary in [False, True]:
            for active in [None, 0]:
                old_written = False
                if primary:
                    if active is not None:
                        old_written = True
                merged_written = primary and active is not None
                assert old_written == merged_written
        cases.append("four primary/active branch states equivalent; source proof not Rust runtime")
        outputs = {
            str(ROOT / "build-target-v1/release/examples" / name)
            for name in ["public-no-bypass-input", "public-no-bypass-cost"]
        }
        assert outputs.issubset(config["bindings"])
        for path in outputs:
            config["bindings"].pop(path)
        guard.completed_partial_software(config, plan["commands"][:3])
        cases.append("known rebuilding outputs omitted while all other prefix inputs bound")
        record = {
            "schema": "quoridor.public-no-bypass.routine-source-guard.ports.v6",
            "PASS": len(cases),
            "cases": cases,
            "whole_seconds": time.monotonic() - begin,
            "STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "Cargo_framework_model_native_Search_fit_game_calls": 0,
            "old_five_or_eleven_successful_tests_replayed": False,
            "routine_source_repairs": repairs,
            "actual_prior_successful_tests": "five PASS read/reused only",
            "namedquiet": [],
            "AS_B": 512 * 1024**2,
            "CPU": 3,
            "direct_child_waits": 0,
            "remaining": [],
            "continuous_peak": "UNKNOWN",
        }
        with (HERE / "routine-ports-STOP.json").open("x") as f:
            f.write(json.dumps(record, indent=2) + "\n")
        print(json.dumps({"PASS": len(cases), "model_runtime_calls": 0, "remaining": []}))


if __name__ == "__main__":
    main()
