"""Single finite synthetic source-port child; canonical lease covers its lifetime."""

import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import time


ROOT = Path(__file__).resolve().parent
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def identity(pid):
    stat = Path(f"/proc/{pid}/stat").read_text()
    return {
        "pid": pid,
        "start_ticks": stat[stat.rindex(")") + 2 :].split()[19],
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    }


def check_sources(bindings):
    for name, expected in bindings.items():
        path = Path(name)
        actual = {
            "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": path.stat().st_size,
            "mode": f"{path.stat().st_mode & 0o7777:04o}",
        }
        if actual != expected:
            raise ValueError("fixed port source/proof changed: " + name)


def competitors():
    found = []
    pattern = re.compile(
        r"(^|/)(cargo|rustc|perf|quoridor-runner|nnue-diagnose|chromium|chrome)(\s|$)"
        r"|current_gradients.py|torchrun|finite-driver"
    )
    for p in Path("/proc").iterdir():
        if not p.name.isdigit() or int(p.name) in (os.getpid(), os.getppid()):
            continue
        try:
            argv = p.joinpath("cmdline").read_bytes().split(b"\0")
            if Path(os.fsdecode(argv[0])).name in ("bash", "sh", "timeout"):
                continue
            text = " ".join(os.fsdecode(x) for x in argv if x)
            if pattern.search(text):
                found.append({"pid": int(p.name), "argv": text[:256]})
        except (OSError, IndexError):
            continue
    if found:
        raise RuntimeError("actual named compute/browser: " + repr(found))
    return found


def child_limits():
    os.sched_setaffinity(0, {3})
    resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
    resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
    resource.setrlimit(resource.RLIMIT_FSIZE, (65536, 65536))


def main():
    started = time.monotonic()
    record = {"schema": "quoridor.public-no-bypass.synthetic-ports-STOP.v1", "primary": None}
    secondary = []
    child = None
    tmp = None
    bindings = None
    with LOCK.open("a+b") as lease:
        try:
            fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
            bindings = json.loads((ROOT / "ports-input-binding.json").read_text())
            check_sources(bindings)
            record["named_competitors"] = competitors()
            memory = (
                int(
                    next(
                        x.split()[1]
                        for x in Path("/proc/meminfo").read_text().splitlines()
                        if x.startswith("MemAvailable:")
                    )
                )
                * 1024
            )
            if memory < 603979776 + 4294967296:
                raise ValueError("512MiB child plus64MiB controller and4GiB host reserve")
            fs = os.statvfs(ROOT)
            if fs.f_bavail * fs.f_frsize < 262144:
                raise ValueError("repair forecast free storage")
            if not {3, 5}.issubset(os.sched_getaffinity(0)):
                raise ValueError("worker3/controller5 affinity")
            physical = [
                tuple(
                    (Path(f"/sys/devices/system/cpu/cpu{cpu}/topology") / name).read_text().strip()
                    for name in ("physical_package_id", "core_id")
                )
                for cpu in (3, 5)
            ]
            if physical[0] == physical[1]:
                raise ValueError("distinct physical worker/controller")
            record.update(MemAvailable_B=memory, physical_cores=physical)
            os.sched_setaffinity(0, {5})
            tmp = ROOT / "owned-entry-port-TMP-v1"
            tmp.mkdir()
            record["actual_START"] = now()
            environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", TMPDIR=str(tmp))
            with (ROOT / "ports-output.log").open("xb") as log:
                child = subprocess.Popen(
                    ["/usr/bin/python3", "-B", str(ROOT / "test_entry_ports.py")],
                    env=environment,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    preexec_fn=child_limits,
                )
                record["child"] = identity(child.pid)
                try:
                    record["exit_code"] = child.wait(timeout=30)
                except BaseException:
                    child.kill()
                    child.wait()
                    raise
            record["directwait"] = True
            if record["exit_code"] != 0:
                raise RuntimeError("new synthetic ports failed; retained log")
        except BaseException as error:
            record["primary"] = repr(error)
        finally:
            if child is not None and child.poll() is None:
                try:
                    child.kill()
                    child.wait()
                except BaseException as error:
                    secondary.append(("directwait", repr(error)))
            if child is not None:
                try:
                    record["exact_child_absent"] = not Path(f"/proc/{child.pid}").exists()
                    if not record["exact_child_absent"]:
                        raise RuntimeError("child identity census not absent")
                except BaseException as error:
                    secondary.append(("census", repr(error)))
            try:
                if bindings is not None:
                    check_sources(bindings)
                    record["source_after_exact"] = True
            except BaseException as error:
                secondary.append(("source_after", repr(error)))
            if tmp is not None and tmp.exists():
                try:
                    if child is None or child.poll() is not None:
                        tmp.rmdir()
                    else:
                        raise RuntimeError("TMP cleanup without reap")
                except BaseException as error:
                    secondary.append(("TMP", repr(error)))
            record.update(
                actual_STOP=now(),
                whole_seconds=time.monotonic() - started,
                secondary=secondary,
                remaining=[]
                if child is None or record.get("exact_child_absent") is True
                else [record["child"]],
                TMP_remaining=[] if tmp is None or not tmp.exists() else [str(tmp)],
                child_maxrss_KiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                framework_model_native_Search_fit_calls=0,
                continuous_family_peak="UNKNOWN",
            )
            (ROOT / "ports-STOP.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))
    if record["primary"] is not None or secondary:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
