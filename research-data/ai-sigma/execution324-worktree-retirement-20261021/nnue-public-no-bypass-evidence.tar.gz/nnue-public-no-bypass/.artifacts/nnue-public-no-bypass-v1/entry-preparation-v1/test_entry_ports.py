"""New source ports for353 entry checks; no real receipt or admission is minted."""

import ast
import copy
import datetime
import hashlib
import json
from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "entry_guard.py"
tree = ast.parse(SOURCE.read_text())
names = {"verified_process_census", "retained_raise", "supported_commands", "review_clear"}
functions = [x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name in names]
assert len(functions) == 4
namespace = {
    "Path": Path,
    "re": re,
    "datetime": datetime,
    "hashlib": hashlib,
    "json": json,
    "WT": ROOT.parents[1],
    "ROOT": ROOT,
    "TOOLCHAIN": Path("/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin"),
}
exec(compile(ast.Module(body=functions, type_ignores=[]), str(SOURCE), "exec"), namespace)


class EntryPorts(unittest.TestCase):
    def test_unknown_receipt_never_becomes_empty_cleanup(self):
        calls = []

        class ProcessPort:
            @staticmethod
            def alive(child):
                calls.append(child)
                return False

        good = {
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
            "child": {
                "pid": 123,
                "start_ticks": "1234",
                "boot_id": "ab5e66ac-12ce-49b0-ac55-afe05e3f5216",
            },
        }
        validate = namespace["verified_process_census"]
        self.assertTrue(validate([good], ProcessPort))
        for key in ("direct_child_reaped", "cleanup_complete", "remaining", "child"):
            for value in (None, False, 1, "", {}):
                bad = {**good, key: value}
                with self.subTest(key=key, value=value):
                    calls.clear()
                    self.assertFalse(validate([bad], ProcessPort))
                    self.assertEqual(calls, [])
            bad = dict(good)
            del bad[key]
            self.assertFalse(validate([bad], ProcessPort))
        self.assertFalse(validate([], ProcessPort))
        self.assertFalse(validate([{**good, "remaining": [good["child"]]}], ProcessPort))
        for child in (
            {**good["child"], "pid": True},
            {**good["child"], "start_ticks": "UNKNOWN"},
            {**good["child"], "boot_id": "UNKNOWN"},
        ):
            self.assertFalse(validate([{**good, "child": child}], ProcessPort))

    def test_live_child_refuses_cleanup(self):
        class ProcessPort:
            @staticmethod
            def alive(_):
                return True

        record = {
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
            "child": {
                "pid": 123,
                "start_ticks": "1234",
                "boot_id": "ab5e66ac-12ce-49b0-ac55-afe05e3f5216",
            },
        }
        self.assertFalse(namespace["verified_process_census"]([record], ProcessPort))

    def test_all_secondary_facts_survive_publication_failure(self):
        primary = RuntimeError("original model/child error")
        source = OSError("source-after")
        cleanup = OSError("owned TMP")
        publication = OSError("STOP publication")
        facts = [("source", source), ("TMP", cleanup), ("STOP", publication)]
        with self.assertRaises(RuntimeError) as caught:
            namespace["retained_raise"](primary, facts)
        self.assertIs(caught.exception, primary)
        self.assertEqual(primary.retained_finalization_errors, tuple(facts))
        self.assertIn("STOP publication", primary.__notes__[0])
        with self.assertRaises(OSError) as caught:
            namespace["retained_raise"](None, facts)
        self.assertIs(caught.exception, source)
        self.assertEqual(source.retained_finalization_errors, tuple(facts))

    def test_unsupported_commands_or_stages_refuse(self):
        with self.assertRaisesRegex(ValueError, "unsupported"):
            namespace["supported_commands"]({"stage": "additional-fit"})
        with self.assertRaisesRegex(ValueError, "exact two"):
            namespace["supported_commands"](
                {"stage": "software", "commands": [["cargo", "test"]], "operational_seconds": 180}
            )
        with self.assertRaisesRegex(ValueError, "ONE exact"):
            namespace["supported_commands"](
                {"stage": "numerical", "commands": [["python", "another-model.py"]]}
            )

    def test_actual_receipt_fields_not_copied_clear_summary(self):
        # All data exists only in memory; nothing is an actual review receipt.
        target = b"synthetic stopped target"
        actual = {
            "schema": "quoridor.nnue-public-no-bypass.head-input-source-review.v1",
            "parent_issue": "quoridor-4lc.353",
            "review_issue": "quoridor-4lc.353.2",
            "reviewed_boundary": "synthetic-port-boundary",
            "source_clear": False,
            "blockers": 3,
            "ordinary": 0,
            "actual_reader_STOP": "2026-10-09T13:55:16.021819+00:00",
            "owned_remaining": [],
            "owned_children_jobs_readers_TMP": [],
            "target_binding_SHA256": hashlib.sha256(target).hexdigest(),
        }

        class PathPort:
            def __init__(self, name):
                self.name = name

            def read_text(self):
                return json.dumps(actual)

            def read_bytes(self):
                return target

        expected = {
            "path": "synthetic-only-memory-receipt",
            "identity": {},
            "target": "synthetic-only-memory-target",
            "review_issue": "quoridor-4lc.353.2",
            "reviewed_boundary": "synthetic-port-boundary",
            "source_clear": True,
            "blockers": 0,
        }
        scope = dict(namespace, Path=PathPort, identity_bytes=lambda *_: None)
        exec(
            compile(
                ast.Module(
                    body=[next(x for x in functions if x.name == "review_clear")], type_ignores=[]
                ),
                str(SOURCE),
                "exec",
            ),
            scope,
        )
        validate = scope["review_clear"]
        with self.assertRaisesRegex(ValueError, "not clear"):
            validate(expected)
        actual.update(source_clear=True, blockers=0)
        for field, value in (
            ("review_issue", "quoridor-4lc.353.1"),
            ("blockers", False),
            ("source_clear", 1),
            ("owned_remaining", None),
            ("owned_children_jobs_readers_TMP", ["UNKNOWN"]),
            ("target_binding_SHA256", "wrong-target"),
        ):
            saved = copy.deepcopy(actual)
            actual[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                validate(expected)
            actual.clear()
            actual.update(saved)


if __name__ == "__main__":
    unittest.main(verbosity=2)
