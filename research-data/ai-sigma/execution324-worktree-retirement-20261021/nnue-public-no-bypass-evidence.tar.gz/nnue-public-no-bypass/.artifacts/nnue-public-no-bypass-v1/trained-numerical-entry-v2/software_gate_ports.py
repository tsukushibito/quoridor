"""New model-free discriminators through the actual current software gate."""

import copy
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import time
from unittest.mock import patch

ROOT = Path(
    "/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1"
)
HERE = ROOT / "trained-numerical-entry-v2"
SOFTWARE = ROOT / "trained-partial-software-recovery-v6"


def main():
    start = time.monotonic()
    with Path(
        "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
    ).open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        spec = importlib.util.spec_from_file_location("entry353", ROOT / "entry_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        guard.quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        assert memory > 512 * 1024**2 + 4 * 1024**3
        receipt = SOFTWARE / "qualified-software-STOP.json"
        actual = json.loads(receipt.read_text())
        named = [
            receipt,
            SOFTWARE / "admission.json",
            *map(Path, actual["raw_refs"]),
            ROOT / "trained-qualification-v1/trained-native-config-v1.json",
            ROOT / "trained-qualification-v1/trained-native-config-v2.json",
        ]
        # Only stopped bounded JSON fixture metadata is read. No ELF/framework/model payload.
        original = {str(p): p.read_bytes() for p in named}
        archive = HERE / "entry_guard.before.py.gz"
        original[str(archive)] = archive.read_bytes()
        source_identities = actual["source_refs"]
        config = {
            "current_trained_software": {
                "path": str(receipt),
                "identity": actual_identity(receipt),
            },
            "bindings": {
                str(SOFTWARE / "admission.json"): actual_identity(SOFTWARE / "admission.json")
            },
            "software_guard_before": {"path": str(archive), "identity": actual_identity(archive)},
        }
        results = []

        def check(label, mutation=None, refuse=True):
            contents = dict(original)
            cfg = copy.deepcopy(config)
            if mutation:
                mutation(contents, cfg)

            def identity(path, expected):
                key = str(path)
                if key in contents:
                    data = contents[key]
                    if (
                        hashlib.sha256(data).hexdigest() != expected["SHA256"]
                        or len(data) != expected["bytes"]
                    ):
                        raise ValueError("synthetic exact metadata identity")
                elif key in source_identities:
                    if expected != source_identities[key]:
                        raise ValueError("synthetic source identity")
                elif key in {r["path"] for r in actual["private2"].values()} | {
                    r["actual_compiler_artifact"] for r in actual["private2"].values()
                }:
                    rows = [
                        r
                        for r in actual["private2"].values()
                        if key in (r["path"], r["actual_compiler_artifact"])
                    ]
                    if any(expected[k] != rows[0][k] for k in ("SHA256", "bytes", "mode")):
                        raise ValueError("synthetic compiler/private identity")
                else:
                    raise ValueError("unexpected fixture path")

            with (
                patch.object(guard, "identity_bytes", identity),
                patch.object(Path, "read_text", lambda p, *a, **k: contents[str(p)].decode()),
                patch.object(Path, "read_bytes", lambda p: contents[str(p)]),
            ):
                failed = False
                try:
                    guard.completed_trained_software(cfg)
                except (ValueError, KeyError):
                    failed = True
                assert failed == refuse, label
            results.append({"case": label, "PASS": True, "synthetic_metadata_only": True})

        def change(path, field, value, rebind=False):
            def mutate(contents, cfg):
                key = str(path)
                obj = json.loads(contents[key])
                obj[field] = value
                contents[key] = (json.dumps(obj) + "\n").encode()
                if rebind:
                    cfg["current_trained_software"]["identity"] = bytes_identity(contents[key])

            return mutate

        check("actual-success-metadata-fixture", refuse=False)
        check("receipt-hash-drift", change(receipt, "primary", {"type": "error"}))
        check("owner-primary-refuses", change(receipt, "primary", {"type": "error"}, True))
        check(
            "owner-secondary-refuses",
            change(receipt, "secondary", [{"stage": "source_after"}], True),
        )
        check("nonempty-owner-census-refuses", change(receipt, "owned_remaining", [123], True))
        check(
            "future-STOP-refuses",
            change(receipt, "collector_reader_STOP", "2999-01-01T00:00:00+00:00", True),
        )
        check(
            "different-private-namespace-refuses", change(receipt, "private2", {"old-v1": {}}, True)
        )
        check(
            "checkpoint-input-change-refuses",
            change(
                ROOT / "trained-qualification-v1/trained-native-config-v2.json",
                "scale",
                "unbound-scale",
            ),
        )
        check(
            "old-image-refuses",
            change(
                ROOT / "trained-qualification-v1/trained-native-config-v2.json",
                "native_image",
                "old-v1",
            ),
        )
        check(
            "other-output-refuses",
            change(
                ROOT / "trained-qualification-v1/trained-native-config-v2.json",
                "output",
                "different-output",
            ),
        )
        check("copied-source-proof-refuses", change(receipt, "source_refs", {}, True))
        # Rebound forged outer receipt cannot conceal failed/truncated raw controller or child.
        for name, path, field, value in [
            ("external-failure", SOFTWARE / "job-runtime/result.json", "exit_code", 1),
            ("external-bool-exit", SOFTWARE / "job-runtime/result.json", "exit_code", False),
            ("external-truncation", SOFTWARE / "job-runtime/result.json", "log_bytes_retained", 0),
            (
                "worker-secondary",
                SOFTWARE / "worker-runtime/STOP.json",
                "secondary",
                [{"stage": "source_after"}],
            ),
        ]:

            def mutate(contents, cfg, path=path, field=field, value=value):
                change(path, field, value)(contents, cfg)
                obj = json.loads(contents[str(receipt)])
                obj["raw_refs"][str(path)] = bytes_identity(
                    contents[str(path)], "0600" if "job-runtime" in str(path) else "0644"
                )
                contents[str(receipt)] = (json.dumps(obj) + "\n").encode()
                cfg["current_trained_software"]["identity"] = bytes_identity(contents[str(receipt)])

            check(name, mutate)
        stop = {
            "schema": "quoridor.public-no-bypass.current-software-gate.ports.v2",
            "new_discriminators": results,
            "count": len(results),
            "models_framework_native_Cargo_Search_fit_games": 0,
            "actual_family_continuous_peak": "UNKNOWN",
            "MemAvailable_B": memory,
            "whole_seconds": time.monotonic() - start,
            "STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "owned_remaining": [],
        }
        with (HERE / "software-gate-ports-STOP.json").open("x") as stream:
            stream.write(json.dumps(stop, indent=2) + "\n")
        print(json.dumps({"new_ports_PASS": len(results), "STOP": stop["STOP"]}))


def bytes_identity(data, mode="0644"):
    return {"SHA256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "mode": mode}


def actual_identity(path):
    return bytes_identity(path.read_bytes(), f"{path.stat().st_mode & 0o777:04o}")


if __name__ == "__main__":
    main()
