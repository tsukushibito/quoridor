"""Collect stopped353 trained qualification, never rerun a model or native command."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import stat
import sys

ROOT = Path(
    "/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1"
)
HERE = ROOT / "trained-numerical-entry-v2"
OUTPUT = ROOT / "native-qualification-v1/trained-input-v2"


def identity(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    with path.open("rb") as stream:
        sha = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"SHA256": sha, "bytes": info.st_size, "mode": f"{stat.S_IMODE(info.st_mode):04o}"}


def main():
    with Path(
        "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
    ).open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        spec = importlib.util.spec_from_file_location("entry353", ROOT / "entry_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        guard.quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        assert memory > 512 * 1024**2 + 4 * 1024**3
        admission = json.loads((HERE / "admission.actual-formatted.json").read_text())
        controller = json.loads((HERE / "job-runtime/result.json").read_text())
        state = json.loads((HERE / "job-runtime/state.json").read_text())
        start = json.loads((HERE / "worker-runtime/START.json").read_text())
        worker = json.loads((HERE / "worker-runtime/STOP.json").read_text())
        result = json.loads((OUTPUT / "result.json").read_text())
        census = json.loads((OUTPUT / "invocation-census.json").read_text())
        native = json.loads((OUTPUT / "native.json").read_text())
        process = json.loads((OUTPUT / "native.process.json").read_text())
        assert controller["job_id"] == "ad772fcb-bb29-4027-81bc-7254df7ef051"
        assert type(controller["exit_code"]) is int and controller["exit_code"] == 0
        for value in [controller, process, *worker["returned_processes"]]:
            assert (
                value["direct_child_reaped"] is True
                and value["cleanup_complete"] is True
                and value["remaining"] == []
            )
            assert value["log_bytes_seen"] == value["log_bytes_retained"]
        assert worker["primary"] is None and worker["secondary"] == [] and worker["remaining"] == []
        assert len(worker["returned_processes"]) == 1
        assert worker["returned_processes"][0]["command"][3:] == admission["commands"][0]
        assert census["status"] == native["status"] == "COMPLETE"
        assert census["primary"] is None and native["primary"] is None
        assert census["secondary"] == native["secondary"] == []
        expected = {
            "Torch_attempted": 4,
            "Torch_returned": 4,
            "Torch_validated": 4,
            "Torch_rows_attempted": 16,
            "native_command_attempted": 1,
            "native_command_returned": 1,
            "optimizer_fit_game_Search": 0,
            "constructors_attempted": 2,
            "constructors_returned": 2,
            "trained_load_attempted": 2,
            "trained_load_returned": 2,
        }
        assert census["counts"] == result["counts"] == expected
        assert result["native"] == native
        returned_native = result["native_process"]
        final_fields = {"signal_mask_restoration", "final_record_persist"}
        assert {k: v for k, v in returned_native.items() if k not in final_fields} == {
            k: v for k, v in process.items() if k not in final_fields
        }
        assert returned_native["signal_mask_restoration"] == "completed"
        assert returned_native["final_record_persist"] == "completed"
        assert (
            native["successful_evaluations"] == 56
            and native["deliberate_rejected_evaluations"] == 4
        )
        assert (
            native["deliberate_rejected_input_constructions"] == 4
            and native["legal_delta_undo_transitions"] == 16
        )
        assert native["Search_calls"] == 0 and len(native["rows"]) == 4
        assert (
            census["native_execute_success_returned"] is True
            and census["native_command_observed_returned"] is True
        )
        assert all(row["state"] == "VALIDATED" for row in census["Torch_slots"].values())
        assert (
            result["actual_head_D_Zero4_exact"] is True
            and result["parameters_scale_coefficient_unchanged"] is True
        )
        errors = {}
        for index, tag in enumerate(["BEST", "LAST"]):
            expected_sha = {
                "BEST": "046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841",
                "LAST": "73b9b3d5a28cb7349c80b9beacfcb1880dd480af6d2e656a1521bf01c77fad81",
            }[tag]
            facts = census["parameter_facts"][tag]
            assert (
                facts["loaded_parameter_SHA256"] == expected_sha
                and facts["post_forward_bit_invariants"] is True
            )
            for device in ["cpu", "cuda"]:
                values = result["scores"][tag + "/" + device]
                references = [row["models"][index]["value"] for row in native["rows"]]
                assert len(values) == 4 and all(math.isfinite(v) for v in values + references)
                errors[tag + "/" + device] = max(
                    abs(a - b) for a, b in zip(values, references, strict=True)
                )
                assert errors[tag + "/" + device] <= 1e-5
        delta = [
            child
            for row in native["rows"]
            for model in row["models"]
            for child in model["children"]
        ]
        assert len(delta) == 16
        assert all(
            child["full_history_undo"] is True
            and child["parent_accumulator_bits_unchanged"] is True
            and math.isfinite(child["absolute_error"])
            and child["absolute_error"] <= 1e-5
            for child in delta
        )
        for path, binding_identity in admission["bindings"].items():
            guard.identity_bytes(path, binding_identity)
        sys.path.insert(0, str(ROOT.parents[1] / "python"))
        from quoridor_training import cycle_process

        members = [process["child"], worker["returned_processes"][0]["child"], start["identity"]]
        assert all(not cycle_process.alive(member) for member in members)
        names = [
            "job-runtime/result.json",
            "job-runtime/state.json",
            "job-runtime/config.json",
            "job-runtime/output.log",
            "worker-runtime/START.json",
            "worker-runtime/STOP.json",
            "worker-runtime/command-0.log",
            "worker-runtime/command-0.process.json",
            "admission.actual-formatted.json",
        ]
        paths = [HERE / name for name in names] + [
            OUTPUT / name
            for name in [
                "result.json",
                "invocation-census.json",
                "native.json",
                "native.log",
                "native.process.json",
            ]
        ]
        stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
        receipt = {
            "schema": "quoridor.public-no-bypass.trained-qualified-STOP.v2",
            "issue": "quoridor-4lc.353",
            "job_id": controller["job_id"],
            "controller_START": state["started_at"],
            "worker_START": start["control_START"],
            "worker_STOP": worker["STOP"],
            "controller_STOP": controller["finished_at"],
            "whole_controller_seconds": controller["wall_seconds"],
            "nested_child_seconds_not_added": worker["returned_processes"][0]["wall_seconds"],
            "counts": expected,
            "native_counts": native["counts"],
            "finite_Torch_native_max_absolute_errors": errors,
            "delta_full_max_absolute_error": max(child["absolute_error"] for child in delta),
            "parameter_facts": census["parameter_facts"],
            "head_D_Zero4_exact": True,
            "params_scale_coefficients_unchanged": True,
            "actual_direct_Torch_child_and_native_wait_handle_cleanup": True,
            "three_exact_identities_fresh_absent": members,
            "source_after_exact_count": len(admission["bindings"]),
            "source_refs": admission["bindings"],
            "raw_refs": {str(path): identity(path) for path in paths},
            "primary": None,
            "secondary": [],
            "owned_remaining": [],
            "sample_family_RSS_B": worker["sample_family_RSS_including64MiB_B"],
            "sample_positive_component_maxima_B": worker["sample_component_maxima_B"],
            "CUDA_peak_allocated_B": result["CUDA_peak_allocated_B"],
            "CUDA_peak_reserved_B": result["CUDA_peak_reserved_B"],
            "continuous_peak_and_physical_kernel_details": "UNKNOWN",
            "returned_masks_completed_raw_masks_pending": {
                k: {"returned": returned_native[k], "raw": process[k]} for k in final_fields
            },
            "old_floors_RAW_fees_failed_TMP": "held no refund",
            "collector_reader_STOP": stop,
            "current_next_Cargo_model_native_Search_fair_reservation": "NONE",
            "scope": "four genuine qualification prefixes only; not fullV/strength/universal history or delta certificate",
        }
        with (HERE / "qualified-trained-STOP.json").open("x") as stream:
            stream.write(json.dumps(receipt, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "receipt": str(HERE / "qualified-trained-STOP.json"),
                    **identity(HERE / "qualified-trained-STOP.json"),
                    "errors": errors,
                    "STOP": stop,
                }
            )
        )


if __name__ == "__main__":
    main()
