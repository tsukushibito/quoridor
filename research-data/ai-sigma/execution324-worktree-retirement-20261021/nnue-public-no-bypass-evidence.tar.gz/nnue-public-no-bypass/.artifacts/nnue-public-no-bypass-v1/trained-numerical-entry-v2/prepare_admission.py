"""Directed current353 trained qualification admission, no framework/model execution."""

import ctypes
import datetime
import difflib
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import time

WT = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass")
ROOT = WT / ".artifacts/nnue-public-no-bypass-v1"
HERE = ROOT / "trained-numerical-entry-v2"
SOFTWARE = ROOT / "trained-partial-software-recovery-v6"


def identity(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise ValueError("exact regular directed binding")
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"SHA256": digest, "bytes": info.st_size, "mode": f"{stat.S_IMODE(info.st_mode):04o}"}


def write(name, obj):
    with (HERE / name).open("x") as stream:
        stream.write(json.dumps(obj, indent=2) + "\n")


def main():
    begin = time.monotonic()
    with Path(
        "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
    ).open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        available_affinity = os.sched_getaffinity(0)
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        spec = importlib.util.spec_from_file_location("entry353", ROOT / "entry_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        guard.quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        if memory < 14 * 1024**3:
            raise ValueError("fresh10GiB family+4GiB host reserve")
        fs = os.statvfs(ROOT)
        free = fs.f_bavail * fs.f_frsize
        if free < 4 * 1024**3:
            raise ValueError("fresh whole phase filesystem headroom")
        # Physical readiness before any retained library/payload hash. No model import.
        cores = [0, 2, 4, 6, 8]
        if not set(cores).issubset(available_affinity):
            raise ValueError("current affinity")
        physical = [
            tuple(
                Path(f"/sys/devices/system/cpu/cpu{c}/topology/{n}").read_text().strip()
                for n in ("physical_package_id", "core_id")
            )
            for c in cores
        ]
        if len(set(physical)) != len(physical):
            raise ValueError("current worker/controller physical cores differ")
        library = ctypes.CDLL("libnvidia-ml.so.1")

        class Info(ctypes.Structure):
            _fields_ = [(n, ctypes.c_ulonglong) for n in ("total", "free", "used")]

        handle = ctypes.c_void_p()
        library.nvmlDeviceGetHandleByIndex_v2.argtypes = [
            ctypes.c_uint,
            ctypes.POINTER(ctypes.c_void_p),
        ]
        library.nvmlDeviceGetMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.POINTER(Info)]
        if library.nvmlInit_v2() or library.nvmlDeviceGetHandleByIndex_v2(0, ctypes.byref(handle)):
            raise ValueError("current NVML device readiness")
        info = Info()
        if (
            library.nvmlDeviceGetMemoryInfo(handle, ctypes.byref(info))
            or info.free < 6 * 1024**3
            or info.used > 6 * 1024**3
        ):
            raise ValueError("fresh device free/whole upper")
        old = json.loads((ROOT / "trained-numerical-entry-v1/admission.json").read_text())
        software = json.loads((SOFTWARE / "admission.json").read_text())
        qualified = json.loads((SOFTWARE / "qualified-software-STOP.json").read_text())
        config = {
            k: v
            for k, v in old.items()
            if k
            not in (
                "software_qualification_actual",
                "source_prior_qualification_not_replayed",
                "fresh_preparation_device",
                "preparation_physics",
                "actual_permission_context",
                "private_forward_upper_B",
                "new_Rust_definitions",
            )
        }
        config["commands"][0][-1] = str(
            ROOT / "trained-qualification-v1/trained-native-config-v2.json"
        )
        config["runtime"] = str(HERE / "worker-runtime")
        config["prepare_owned_parents"] = [str(ROOT / "native-qualification-v1")]
        config["trained_boundary_reviews"] = software["trained_boundary_reviews"]
        config["routine_observer_repairs"] = software["routine_observer_repairs"]
        config["current_trained_software"] = {
            "path": str(SOFTWARE / "qualified-software-STOP.json"),
            "identity": identity(SOFTWARE / "qualified-software-STOP.json"),
        }
        config["software_guard_before"] = {
            "path": str(HERE / "entry_guard.before.py.gz"),
            "identity": identity(HERE / "entry_guard.before.py.gz"),
        }
        config["source_reviews"] = software["source_reviews"]
        bindings = dict(software["bindings"])
        old_guard = str(ROOT / "entry_guard.py")
        bindings[old_guard] = identity(ROOT / "entry_guard.py")
        # Only frozen numerical/framework/scale/input refs are added from prior
        # preparation; no stale private/config/output or failed classifier identity.
        select = [str(WT / "python") + "/", "/home/vscode/.cache/inference/"]
        fixed = [
            "qualify_no_bypass.py",
            "candidate-fit-config-v1.json",
            "head-input-prefixes-v1.json",
            "numerical-qualification-v2/output/native-head-input.json",
            "trained-qualification-v1/qualify_trained.py",
            "trained-qualification-v1/presentation-binding.json",
            "trained-qualification-v1/trained-native-config-v1.json",
        ]
        fixed_paths = {str(ROOT / n) for n in fixed}
        for path, expected in old["bindings"].items():
            if (
                any(path.startswith(prefix) for prefix in select)
                or path in fixed_paths
                or path.startswith(
                    "/workspaces/quoridor/.worktree/assets/checkpoints/public-no-bypass-v1/"
                )
                or path.endswith("/train-statistics-r1/statistics/train-only-scale.json")
            ):
                # The qualifier has the independently confirmed partial-evidence
                # repair; its current bfb967 source was bound by the software map.
                if path == str(ROOT / "trained-qualification-v1/qualify_trained.py"):
                    expected = software["bindings"][path]
                guard.identity_bytes(path, expected)
                bindings[path] = expected
        named = [
            HERE / "entry_guard.before.py.gz",
            HERE / "software-gate-ports-STOP.json",
            SOFTWARE / "admission.json",
            SOFTWARE / "qualified-software-STOP.json",
            ROOT / "trained-qualification-v1/trained-native-config-v2.json",
        ]
        named.extend(Path(p) for p in qualified["raw_refs"])
        for row in qualified["private2"].values():
            named.extend([Path(row["path"]), Path(row["actual_compiler_artifact"])])
        for path in named:
            bindings[str(path)] = identity(path)
        config["bindings"] = bindings
        config["storage_components"] = software["storage_components"]
        observations = []
        for component in config["storage_components"]:
            name = component["name"]
            observed = guard.charged(component["roots"], component.get("excluded", ()))
            held = max(
                observed,
                component.get("retained_floor_B", 0),
                qualified["sample_positive_component_maxima_B"][name],
            )
            if name == "review":
                held = max(held, 10485760)
            component["retained_floor_B"] = held
            forward = {
                "controls": 8388608,
                "native_qualification": 4194304,
                "TMP": 67108864,
                "dependency_identity_and_setup": 1048576,
            }.get(name, 0)
            if held + forward > component["upper_B"]:
                raise ValueError("concrete contained forward gap: " + name)
            if name == "TMP":
                component["roots"].append(str(HERE / "worker-runtime/TMP"))
            observations.append(
                {
                    "name": name,
                    "sampled_B": observed,
                    "held_floor_B": held,
                    "new_forward_B": forward,
                    "upper_B": component["upper_B"],
                }
            )
        config["fresh_preparation_device"] = {
            "total_B": info.total,
            "free_B": info.free,
            "used_B": info.used,
        }
        config["preparation_physics"] = {
            "MemAvailable_B": memory,
            "filesystem_free_B": free,
            "physical_cores": physical,
            "namedquiet": [],
        }
        config["actual_permission_context"] = (
            "2026-10-09T20:55:07.317Z danger-full-access/never/gpt-6.1-sol/high/originallearning-million"
        )
        config["old_initial_Rust_Torch_native_Adam_fit_success_not_replayed"] = True
        config["actual_latest_model_fit0"] = (
            "new trained four calls only; completed one fit not replayed"
        )
        config["new_Rust_definitions"] = (
            "actual five observer definitions PASS reused v5; current example release/lint/private v6 qualified"
        )
        config["planned_counts"] = old["planned_counts"]
        for path, expected in bindings.items():
            guard.identity_bytes(path, expected)
        guard.supported_commands(config)
        guard.trained_boundary_clear(config)
        for receipt in config["source_reviews"]:
            guard.review_clear(receipt)
        for p in (
            HERE / "worker-runtime",
            HERE / "job-runtime",
            ROOT / "native-qualification-v1/trained-input-v2",
        ):
            if p.exists():
                raise FileExistsError("exclusive new runtime/output already exists: " + str(p))
        write(
            "retained-and-forward-ledger.json",
            {
                "before_runtime_growth_UTC": datetime.datetime.now(
                    datetime.timezone.utc
                ).isoformat(),
                "components": observations,
                "whole_upper_B": sum(c["upper_B"] for c in config["storage_components"]),
                "old_positive_RAW_TMP_fee_mask_UNKNOWN": "HELD no refund",
                "library_payload_read_scope": "exact existing named framework hashes, no corpus or weights replay",
            },
        )
        write("admission.json", config)
        admission = HERE / "admission.json"
        job = {
            "issue": "quoridor-4lc.353",
            "goal_issue": "quoridor-4lc",
            "thread_id": "01a1100f-6d45-78e0-8a87-84503ff0fbf6",
            "cwd": "/workspaces/quoridor/.worktree/learning-million",
            "argv": [
                "/usr/bin/python3",
                "-B",
                str(ROOT / "entry_guard.py"),
                str(admission),
                "--sha256",
                identity(admission)["SHA256"],
            ],
            "end_at": None,
            "notify_until": None,
            "max_runtime_seconds": 210,
            "control_interval_seconds": 30,
            "notify_interval_seconds": 10,
            "request_timeout_seconds": 25,
            "log_max_bytes": 1048576,
            "resource_contract": str(guard.PROOF),
        }
        write("job-config.json", job)
        before = gzip.decompress((HERE / "entry_guard.before.py.gz").read_bytes()).decode()
        after = (ROOT / "entry_guard.py").read_text()
        with (HERE / "control-only.patch").open("x") as stream:
            stream.write(
                "".join(
                    difflib.unified_diff(
                        before.splitlines(True),
                        after.splitlines(True),
                        fromfile="a/entry_guard.py",
                        tofile="b/entry_guard.py",
                    )
                )
            )
        stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(
            "prepared-source-STOP.json",
            {
                "schema": "quoridor.public-no-bypass.trained-numerical.prepared.v2",
                "READY": True,
                "actual_START": None,
                "reservation": "NONE",
                "source_writer_reader_STOP": stop,
                "bindings": bindings,
                "admission": identity(admission),
                "job_config": identity(HERE / "job-config.json"),
                "fixed_counts": config["planned_counts"],
                "current_software": config["current_trained_software"],
                "sample_physics": config["preparation_physics"],
                "sample_device": config["fresh_preparation_device"],
                "all_owned_readers_children_jobs_TMP": [],
                "stdlib_preparation_whole_seconds": time.monotonic() - begin,
                "family_continuous_peak": "UNKNOWN",
                "permission_context": config["actual_permission_context"],
            },
        )
        print(
            json.dumps(
                {
                    "READY": True,
                    "STOP": stop,
                    "bindings": len(bindings),
                    "admission": identity(admission),
                }
            )
        )


if __name__ == "__main__":
    main()
