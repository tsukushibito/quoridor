"""New static discriminators of the actual maintained caller source.

These execute no Rust, search, geometry or model. The nine new Rust behavioral
definitions remain NOT_RUN until affected software qualification after review.
"""

import gzip
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent
WT = ROOT.parents[2]
CLOCK = (WT / "crates/quoridor-runner/src/arena_clock.rs").read_text()
RUNTIME = (WT / "crates/quoridor-runner/src/runtime.rs").read_text()


def block(text, signature):
    start = text.index(signature)
    opening = text.index("{", start)
    depth = 1
    end = opening + 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return text[start:end]


class ClockSourcePorts(unittest.TestCase):
    def test_observer_cannot_call_rules_or_receive_context(self):
        publish = block(CLOCK, "pub fn publish(")
        self.assertNotIn("SigmaContext", publish)
        self.assertNotIn(".play(", publish)
        for check in ("completed_depth > 0", "f32::is_finite", "r.pv.first() == Some(&a)"):
            self.assertIn(check, publish)
        observed = block(RUNTIME, "fn invoke_alpha_observed(")
        self.assertIn("done.publish(r, deadline)", observed)
        self.assertNotIn("root.play(", observed)

    def test_receipt_precedes_every_deferred_rules_call_and_decision(self):
        caller = RUNTIME[
            RUNTIME.index(
                "let mut completion = crate::arena_clock::Completion::default();",
                RUNTIME.index("fn new_game("),
            ) :
        ]
        receipt = caller.index("let returned = Instant::now();")
        validation = caller.index("alpha_validate_completion(&completion, action,")
        rules = caller.index("g.context.play(a).is_ok()")
        checked = caller.index("let checked = Instant::now();")
        decision = caller.index("let mut decision = alpha_receipt_decision(")
        self.assertLess(receipt, validation)
        self.assertLess(validation, rules)
        self.assertLess(rules, checked)
        self.assertLess(checked, decision)
        self.assertIn(
            "ns(returned)", caller[decision : caller.index("// The run deadline", decision)]
        )

    def test_late_superseded_actions_are_kept_and_all_checked(self):
        publish = block(CLOCK, "pub fn publish(")
        self.assertLess(
            publish.index("actions_to_validate.push"), publish.index("deadline.is_none_or")
        )
        validate = block(CLOCK, "pub fn validate_actions(")
        self.assertIn("for &action in &self.actions_to_validate", validate)
        self.assertIn("valid &= legal(action)", validate)
        self.assertNotIn(".all(", validate)
        self.assertNotIn("valid &&", validate)

    def test_snapshot_selection_and_original_failure_priority_are_unchanged(self):
        before_clock = gzip.decompress((ROOT / "arena_clock.rs.before.gz").read_bytes()).decode()
        before_runtime = gzip.decompress((ROOT / "runtime.rs.before.gz").read_bytes()).decode()
        self.assertEqual(block(CLOCK, "pub fn select("), block(before_clock, "pub fn select("))
        self.assertEqual(
            block(RUNTIME, "fn alpha_receipt_decision("),
            block(before_runtime, "fn alpha_receipt_decision("),
        )
        self.assertEqual(
            block(CLOCK, "pub(crate) fn remaining("),
            block(before_clock, "pub(crate) fn remaining("),
        )
        self.assertIn("search_result.is_err() || !snapshots_valid", RUNTIME)
        self.assertIn("invalid completed-depth snapshot", RUNTIME)

    def test_work_counters_and_synchronous_invocation_are_retained(self):
        observed = block(RUNTIME, "fn invoke_alpha_observed(")
        self.assertIn("profile.record(result)", observed)
        self.assertIn("session.search_with_updates", observed)
        self.assertNotIn("thread::spawn", observed)
        select = block(CLOCK, "pub fn select(")
        self.assertNotIn("r.stats", select)
        self.assertIn('"completed_snapshot_validation_failed"', RUNTIME)
        self.assertIn('receipt_counters["drain_finished_ns"] = ns(returned)', RUNTIME)

    def test_nine_new_rust_definitions_bound_without_old_suite_execution(self):
        self.assertEqual(block(CLOCK, "mod completion_receipt_353_tests").count("#[test]"), 6)
        self.assertEqual(block(RUNTIME, "mod alpha_receipt_353_tests").count("#[test]"), 3)
        route = json.loads(
            Path(
                "/workspaces/quoridor/.artifacts/research-acceptance/public-no-bypass-v1/clock-book-route-v1/route.json"
            ).read_text()
        )
        self.assertEqual(route["games"], 16)
        self.assertEqual(route["seed"], 32710001)


if __name__ == "__main__":
    unittest.main(verbosity=2)
