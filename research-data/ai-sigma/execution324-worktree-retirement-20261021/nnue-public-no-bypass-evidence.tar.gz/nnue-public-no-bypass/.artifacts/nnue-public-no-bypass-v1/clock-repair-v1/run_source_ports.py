"""One new source-only port child under the existing canonical lifetime lease."""

import datetime
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
WT = ROOT.parents[2]
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def run():
    start = time.monotonic()
    primary, secondary, returned = None, [], []
    with LOCK.open("a+b") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        spec = importlib.util.spec_from_file_location("entry_guard", ROOT.parent / "entry_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        bindings = json.loads((ROOT / "ports-input-binding.json").read_text())
        for path, expected in bindings.items():
            guard.identity_bytes(path, expected)
        if len(bindings) > 16:
            raise ValueError("directed bounded source set")
        guard.quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        if memory < 603979776 + 4294967296:
            raise ValueError("512MiB child+64MiB controller+4GiB host reserve")
        cores = [3, 5]
        physical = [
            tuple(
                (Path(f"/sys/devices/system/cpu/cpu{c}/topology") / n).read_text().strip()
                for n in ("physical_package_id", "core_id")
            )
            for c in cores
        ]
        if len(set(physical)) != 2 or not set(cores).issubset(os.sched_getaffinity(0)):
            raise ValueError("fresh distinct physical cores")
        if (
            guard.charged([ROOT]) > 1048576
            or os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize < 1048576
        ):
            raise ValueError("supported1MiB source increment")
        sys.path.insert(0, str(WT / "python"))
        from quoridor_training import cycle_process as process

        os.sched_setaffinity(0, {5})
        deadline = time.monotonic() + 30
        resources = process.CycleResources(
            {
                "max_memory_bytes": 536870912,
                "host_ram_reserve": 4294967296,
                "max_output_bytes": 1048576,
            },
            ROOT,
            deadline,
        )
        tmp = ROOT / "owned-port-TMP-v1"
        tmp.mkdir()
        os.environ.update(PYTHONDONTWRITEBYTECODE="1", TMPDIR=str(tmp))
        actual_start = now()
        try:
            with process.cancellation_signals():
                returned.append(
                    process.execute(
                        ["/usr/bin/python3", "-B", str(ROOT / "test_clock_source_ports.py")],
                        ROOT / "ports-output.log",
                        deadline,
                        cpu_core=3,
                        resources=resources,
                    )
                )
        except BaseException as error:
            primary = error
        finally:
            records = returned or [json.loads(p.read_text()) for p in ROOT.glob("*.process.json")]
            remaining = None
            try:
                if not guard.verified_process_census(records, process):
                    raise ValueError("owned child census incomplete")
                remaining = []
            except BaseException as error:
                secondary.append(("census", error))
            for path, expected in bindings.items():
                try:
                    guard.identity_bytes(path, expected)
                except BaseException as error:
                    secondary.append(("source_after", error))
            retained = None
            if remaining == []:
                try:
                    retained = guard.retain_owned_tmp(tmp)
                except BaseException as error:
                    secondary.append(("TMP", error))
            record = {
                "schema": "quoridor.public-no-bypass.clock-source-ports-STOP.v1",
                "actual_START": actual_start,
                "actual_STOP": now(),
                "whole_seconds": time.monotonic() - start,
                "primary": None if primary is None else repr(primary),
                "secondary": [{"stage": s, "error": repr(e)} for s, e in secondary],
                "returned": returned,
                "remaining": remaining,
                "TMP_retained_path": retained,
                "MemAvailable_B": memory,
                "physical_cores": physical,
                "continuous_family_peak": "UNKNOWN",
                "Rust_new9_definitions": "NOT_RUN",
                "model_native_Search_Cargo_geometry_fit_games": 0,
                "old_fees_RAW_masks_UNKNOWN": "held",
            }
            try:
                (ROOT / "ports-STOP.json").write_text(json.dumps(record, indent=2) + "\n")
            except BaseException as error:
                secondary.append(("STOP_publication", error))
        guard.retained_raise(primary, secondary)
        print(
            json.dumps(
                {
                    "actual_START": actual_start,
                    "actual_STOP": record["actual_STOP"],
                    "remaining": remaining,
                    "source_ports": "PASS",
                    "Rust9": "NOT_RUN",
                }
            )
        )


if __name__ == "__main__":
    run()
