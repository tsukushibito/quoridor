"""353.4 T1/T2 new stdlib-only discriminators; no numerical/framework imports."""

import ast
import datetime
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import resource
import stat
import struct
import sys
import time

WT = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass")
ROOT = WT / ".artifacts/nnue-public-no-bypass-v1"
HERE = ROOT / "trained-boundary-repair-v2"
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")


def identity(path):
    info = path.lstat()
    return {
        "path": str(path),
        "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": info.st_size,
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


def selected(path, names, env):
    tree = ast.parse(path.read_text())
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in nodes} == set(names)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec"), env)
    return env


def main():
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    beginning = time.monotonic()
    cases, secondary, primary = [], [], None
    fixtures = HERE / "synthetic-only-v1"
    owned_files = []
    with LOCK.open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        env = dict(Path=Path, os=os, sys=sys, re=re, json=json)
        quiet = selected(ROOT / "entry_guard.py", {"quiet"}, env)["quiet"]
        quiet()
        affinity_before = sorted(os.sched_getaffinity(0))
        assert 3 in affinity_before
        topology = [
            Path(f"/sys/devices/system/cpu/cpu3/topology/{name}").read_text().strip()
            for name in ["physical_package_id", "core_id"]
        ]
        memory = (
            int(re.search(r"MemAvailable:\s+(\d+)", Path("/proc/meminfo").read_text())[1]) * 1024
        )
        assert memory > 512 * 1024**2 + 4 * 1024**3
        assert os.statvfs(HERE).f_bavail * os.statvfs(HERE).f_frsize > 512 * 1024**2
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        paths = [
            ROOT / "trained-software-clippy-v4/scoped_clippy.py",
            ROOT / "trained-qualification-v1/qualify_trained.py",
            WT / "crates/quoridor-nnue/examples/public-no-bypass-input.rs",
            WT / "crates/quoridor-runner/examples/public-no-bypass-cost.rs",
            Path(__file__),
        ]
        before = [identity(path) for path in paths]
        fixtures.mkdir()
        try:
            classifier = ROOT / "trained-software-clippy-v4/scoped_clippy.py"
            tree = ast.parse(classifier.read_text())
            constants = [
                node
                for node in tree.body
                if isinstance(node, ast.Assign)
                and any(
                    isinstance(t, ast.Name) and t.id in {"EXPECTED_TARGETS", "EXPECTED_SOURCES"}
                    for t in node.targets
                )
            ]
            env = dict(json=json, Path=Path)
            exec(compile(ast.Module(body=constants, type_ignores=[]), str(classifier), "exec"), env)
            selected(classifier, {"classify"}, env)
            classify = env["classify"]
            config = json.loads(
                (ROOT / "trained-software-clippy-v4/scoped-clippy-config.json").read_text()
            )
            allowed = config["allowed_diagnostics"]
            base = [
                json.dumps(
                    {
                        "reason": "compiler-message",
                        "message": {
                            "level": "warning",
                            "spans": [item["primary_span"]],
                            "code": {"code": item["code"]},
                        },
                    }
                )
                for item in allowed
            ]
            base += [
                json.dumps(
                    {
                        "reason": "compiler-artifact",
                        "target": {
                            "name": key[0],
                            "kind": list(key[1]),
                            "src_path": str(WT / path),
                        },
                    }
                )
                for key, path in env["EXPECTED_TARGETS"].items()
            ]

            def check(name, operation):
                operation()
                cases.append({"case": name, "PASS": True, "synthetic": True})

            for value in [1, 1.0, "true", None, False, [], {}]:

                def bad(value=value):
                    try:
                        classify(
                            base + [json.dumps({"reason": "build-finished", "success": value})],
                            0,
                            allowed,
                            WT,
                        )
                    except ValueError:
                        return
                    raise AssertionError("nonliteral success accepted")

                check("T1 refuses " + repr(value), bad)
            for tail, name in [
                ([{"reason": "build-finished"}], "missing success"),
                ([], "missing build-finished"),
                ([{"reason": "build-finished", "success": True}] * 2, "duplicate true"),
            ]:

                def invalid_tail(tail=tail):
                    try:
                        classify(base + [json.dumps(item) for item in tail], 0, allowed, WT)
                    except ValueError:
                        return
                    raise AssertionError("missing/duplicate finished accepted")

                check("T1 " + name, invalid_tail)
            check(
                "T1 literal True discriminates",
                lambda: classify(
                    base + [json.dumps({"reason": "build-finished", "success": True})],
                    0,
                    allowed,
                    WT,
                ),
            )

            env = dict(json=json, math=math, struct=struct, hashlib=hashlib, stat=stat)
            selected(
                ROOT / "trained-qualification-v1/qualify_trained.py",
                {
                    "json_evidence",
                    "error_facts",
                    "capture_arrays",
                    "failed_slots",
                    "reconcile_native",
                    "finish_capture",
                },
                env,
            )
            finish, reconcile = env["finish_capture"], env["reconcile_native"]

            def raises_same(operation, error):
                try:
                    operation()
                except BaseException as actual:
                    assert actual is error
                    return actual
                raise AssertionError("failure not raised")

            def first_and_later():
                first, later1, later2 = (
                    ValueError("primary"),
                    OSError("capture1"),
                    OSError("capture2"),
                )
                payload = {
                    "scores_available": {"BEST/cpu": [0.25]},
                    "native_available": {"rows": [{"value_bits": 1048576000}]},
                    "parameter_facts": {"BEST": {"mu_bits": [1, 2]}},
                }
                saved = []

                def collect(p, errors):
                    errors.extend([("one", later1), ("two", later2)])

                actual = raises_same(
                    lambda: finish(
                        fixtures,
                        first,
                        payload,
                        [("collect", collect)],
                        lambda p, v: saved.append(v),
                        lambda v: None,
                    ),
                    first,
                )
                assert [e for s, e in actual.retained_capture_secondary] == [later1, later2]
                assert saved[0]["status"] == "FAILED" and len(saved[0]["secondary"]) == 2
                assert saved[0]["scores_available"] == payload["scores_available"]
                assert saved[0]["native_available"] == payload["native_available"]
                assert saved[0]["parameter_facts"] == payload["parameter_facts"]

            check("T2 original primary/all collection errors/available facts", first_and_later)

            def every_publication_error():
                first, pub, fallback = (
                    RuntimeError("original"),
                    OSError("publish"),
                    OSError("fallback"),
                )

                def fail(error):
                    raise error

                actual = raises_same(
                    lambda: finish(
                        fixtures,
                        first,
                        {"rows": [1]},
                        [],
                        lambda p, v: fail(pub),
                        lambda v: fail(fallback),
                    ),
                    first,
                )
                assert [e for s, e in actual.retained_capture_secondary] == [pub, fallback]

            check("T2 original plus both publication errors objects", every_publication_error)

            def first_publication_error():
                pub, fallback = OSError("first publication"), OSError("later stderr")

                def fail(error):
                    raise error

                actual = raises_same(
                    lambda: finish(
                        fixtures, None, {}, [], lambda p, v: fail(pub), lambda v: fail(fallback)
                    ),
                    pub,
                )
                assert actual.retained_capture_secondary[-1][1] is fallback

            check("T2 publication primary when no earlier failure", first_publication_error)

            def cancel_and_restoration():
                first, restore1, restore2 = (
                    KeyboardInterrupt("returned cancel"),
                    OSError("remove"),
                    OSError("fallback remove"),
                )
                first.retained_observer_restoration_errors = (restore1, restore2)
                first.add_note("original restoration note")
                saved = []
                raises_same(
                    lambda: finish(
                        fixtures, first, {}, [], lambda p, v: saved.append(v), lambda v: None
                    ),
                    first,
                )
                assert saved[0]["primary"]["notes"] == ["original restoration note"]
                assert [
                    e["message"]
                    for e in saved[0]["primary"]["retained_observer_restoration_errors"]
                ] == ["remove", "fallback remove"]

            check("T2 returned cancellation and existing restoration facts", cancel_and_restoration)

            class Array:
                shape, dtype = (1, 2), "float32"

                def tobytes(self):
                    return struct.pack("<ff", 0.25, float("nan"))

                def tolist(self):
                    return [[0.25, float("nan")]]

            class BadArray(Array):
                def tobytes(self):
                    raise OSError("synthetic unavailable copy")

            def arrays_and_secondary():
                payload, errors = {}, []
                env["capture_arrays"]([Array(), BadArray(), Array()], payload, errors)
                frozen = env["json_evidence"](payload)
                json.dumps(frozen, allow_nan=False)
                assert len(frozen["observations"]) == 3 and len(errors) == 1
                assert (
                    frozen["observations"][0]["representation"]["raw_bytes_hex"]
                    == Array().tobytes().hex()
                )
                assert frozen["observations"][0]["values"][0][1]["nonfinite"] == "nan"
                assert frozen["observations"][1]["state"] == "CAPTURE_FAILED"
                assert frozen["observations"][2]["state"] == "CAPTURED"

            check("T2 per-array partial/raw bits/nonfinite/continued capture", arrays_and_secondary)

            def states():
                slots = {
                    "prior": {"state": "VALIDATED", "array": {"raw": "00"}},
                    "current": {"state": "RETURNED", "array": {"raw": "01"}},
                    "next": {"state": "UNENTERED", "array": "UNKNOWN"},
                }
                env["failed_slots"](slots)
                assert slots["prior"]["state"] == "VALIDATED"
                assert (
                    slots["current"]["state"] == "FAILED"
                    and slots["current"]["last_available_state"] == "RETURNED"
                )
                assert slots["current"]["array"] == {"raw": "01"}
                assert slots["next"]["state"] == "UNENTERED" and slots["next"]["array"] == "UNKNOWN"

            check("T2 failed returned slot/prior validation/unentered denominator", states)

            def write(name, content):
                path = fixtures / name
                with path.open("x") as stream:
                    stream.write(content)
                os.chmod(path, 0o600)
                owned_files.append(path)
                return path

            def raw_failed_execute():
                write(
                    "native.process.json",
                    json.dumps(
                        {
                            "direct_child_reaped": True,
                            "exit_code": 1,
                            "process_cleanup_complete": True,
                            "synthetic": True,
                        }
                    ),
                )
                write(
                    "native.json",
                    json.dumps(
                        {
                            "status": "FAILED",
                            "rows": [{"value_bits": 1048576000}],
                            "successful_evaluations": 1,
                            "synthetic": True,
                        }
                    ),
                )
                payload, errors = {"native_process_returned": None}, []
                reconcile(fixtures, payload, errors)
                assert errors == [] and payload["native_command_observed_returned"] is True
                assert payload["native_execute_success_returned"] is False
                assert payload["native_available"]["status"] == "FAILED"
                assert payload["native_available"]["successful_evaluations"] == 1
                assert payload["native_raw_refs"]["native.process.json"]["mode"] == "0600"

            check(
                "T2 execute raise reconciles raw failed process/partial rows/actual modes",
                raw_failed_execute,
            )

            def malformed_raw():
                path = fixtures / "native.process.json"
                path.write_text("{partial")
                payload, errors = {"native_process_returned": None}, []
                reconcile(fixtures, payload, errors)
                assert len(errors) == 1 and payload["native_command_observed_returned"] is False
                assert payload["native_execute_success_returned"] is False
                assert payload["native_raw_refs"]["native.process.json"]["bytes"] == 8
                assert payload["native_available"]["successful_evaluations"] == 1

            check("T2 malformed raw receipt retained without inferred success", malformed_raw)
        except BaseException as error:
            primary = error
        finally:
            for path in owned_files:
                try:
                    path.unlink()
                except BaseException as error:
                    secondary.append(("own synthetic file cleanup", error))
            try:
                fixtures.rmdir()
            except BaseException as error:
                secondary.append(("own synthetic dir cleanup", error))
        after = [identity(path) for path in paths]
        assert before == after
        assert not any(
            name in sys.modules for name in ["torch", "numpy", "quoridor_training.train"]
        )
        rss = int(re.search(r"VmRSS:\s+(\d+)", Path("/proc/self/status").read_text())[1]) * 1024
        assert rss + 64 * 1024**2 < 512 * 1024**2
        record = {
            "schema": "quoridor.public-no-bypass.T1-T2.synthetic-ports.v1",
            "START": start,
            "STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "whole_seconds": time.monotonic() - beginning,
            "cases": cases,
            "passed": len(cases),
            "primary": None if primary is None else repr(primary),
            "secondary": [(stage, repr(error)) for stage, error in secondary],
            "source_before_after": before,
            "source_unchanged": before == after,
            "physics": {
                "namedquiet": [],
                "CPU": 3,
                "package_core": topology,
                "MemAvailable_B": memory,
                "AS_B": 512 * 1024**2,
                "sample_family_inclusive64MiB_B": rss + 64 * 1024**2,
                "continuous_peak": "UNKNOWN",
            },
            "direct_child_waits": 0,
            "remaining": [],
            "synthetic_TMP_removed": not fixtures.exists(),
            "model_framework_Cargo_Search_optimizer_fit_game_calls": 0,
            "scope": "actual changed Python helpers on synthetic values; Rust definitions unbuilt/unrun",
        }
        with (HERE / "ports-STOP.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2) + "\n")
        if primary:
            for stage, error in secondary:
                primary.add_note(stage + ": " + repr(error))
            raise primary
        if secondary:
            raise secondary[0][1]
        print(json.dumps({"PASS": len(cases), "remaining": [], "model_calls": 0}))


if __name__ == "__main__":
    main()
