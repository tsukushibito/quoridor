"""Freeze exact353.4 related source delta; no Git/index or numerical work."""

import ast
import datetime
import difflib
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import stat
import sys

WT = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass")
ROOT = WT / ".artifacts/nnue-public-no-bypass-v1"
HERE = ROOT / "trained-boundary-repair-v2"
MAIN = Path("/workspaces/quoridor")
LOCK = MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock"


def identity(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    return {
        "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": info.st_size,
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


def write(name, value):
    with (HERE / name).open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


def calls(source, names):
    tree = ast.parse(source)
    return sorted(
        ast.dump(node, include_attributes=False)
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and ast.unparse(node.func) in names
    )


def main():
    with LOCK.open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        tree = ast.parse((ROOT / "entry_guard.py").read_text())
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "quiet")
        env = dict(os=os, sys=sys, Path=Path, re=re, json=json)
        exec(compile(ast.Module(body=[fn], type_ignores=[]), "maintained-quiet", "exec"), env)
        env["quiet"]()
        memory = (
            int(re.search(r"MemAvailable:\s+(\d+)", Path("/proc/meminfo").read_text())[1]) * 1024
        )
        assert memory >= 512 * 1024**2 + 4 * 1024**3
        assert 3 in os.sched_getaffinity(0)
        topology = [
            Path(f"/sys/devices/system/cpu/cpu3/topology/{n}").read_text().strip()
            for n in ["physical_package_id", "core_id"]
        ]
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        before = json.loads((HERE / "before.json").read_text())
        current, patch, proofs, definitions = {}, [], [], []
        for raw, old in before.items():
            path = Path(raw)
            original = gzip.decompress(Path(old["retained_before_gzip"]).read_bytes())
            post = path.read_bytes()
            assert hashlib.sha256(original).hexdigest() == old["SHA256"]
            assert len(original) == old["bytes"] and identity(path)["mode"] == old["mode"]
            current[raw] = identity(path)
            relative = path.relative_to(WT).as_posix()
            delta = list(
                difflib.unified_diff(
                    original.decode().splitlines(True),
                    post.decode().splitlines(True),
                    fromfile="a/" + relative,
                    tofile="b/" + relative,
                )
            )
            assert delta
            patch.extend(delta)

            # Reconstruct exact postimage and inverse from retained context/hunk lines.
            def apply(lines, image):
                source = image.decode().splitlines(True)
                result, cursor = [], 0
                index = 2
                while index < len(lines):
                    header = re.fullmatch(r"@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@\n", lines[index])
                    assert header, lines[index]
                    position = int(header[1]) - 1
                    result.extend(source[cursor:position])
                    cursor = position
                    index += 1
                    while index < len(lines) and not lines[index].startswith("@@ "):
                        mark, body = lines[index][0], lines[index][1:]
                        if mark in " -":
                            assert source[cursor] == body
                            cursor += 1
                        if mark in " +":
                            result.append(body)
                        index += 1
                result.extend(source[cursor:])
                return "".join(result).encode()

            assert apply(delta, original) == post
            reverse = list(
                difflib.unified_diff(
                    post.decode().splitlines(True),
                    original.decode().splitlines(True),
                    fromfile="b/" + relative,
                    tofile="a/" + relative,
                )
            )
            assert apply(reverse, post) == original
            proofs.append(
                {
                    "path": raw,
                    "before_gzip_SHA_matches": True,
                    "forward_inverse_exact": True,
                    "hunks": sum(line.startswith("@@ ") for line in delta),
                }
            )
            if path.suffix == ".rs":
                definitions.extend(
                    {"path": raw, "definition": name, "qualification": "UNBUILT_NOT_RUN"}
                    for name in re.findall(r"fn (partial_353_\w+)\(", post.decode())
                )
            if path.name == "qualify_trained.py":
                names = {
                    "build_model",
                    "torch.manual_seed",
                    "torch.load",
                    "model.load_state_dict",
                    "helpers.actual_head_forward",
                    "helpers.captured_input_bits",
                    "helpers.finite_correspondence",
                    "torch.cuda.synchronize",
                    "execute",
                }
                assert calls(original.decode(), names) == calls(post.decode(), names)
                proofs.append(
                    {
                        "unchanged_python_factory_model_forward_validation_native_calls_AST": sorted(
                            names
                        )
                    }
                )
            if path.suffix == ".rs":
                old_run = original.decode()  # Original examples put the work in main.
                new_run = post.decode().split("fn run(")[1].split("fn main(")[0]
                names = [
                    "evaluate_with_scratch_observed",
                    "evaluate_with_scratch",
                    "full_context",
                    "full_features",
                    "delta_move_into",
                    "make_move",
                    "unmake_move",
                    "search",
                ]
                census = {name: len(re.findall(r"\." + name + r"\(", old_run)) for name in names}
                assert census == {
                    name: len(re.findall(r"\." + name + r"\(", new_run)) for name in names
                }
                proofs.append(
                    {"path": raw, "original_numeric_API_callsite_counts_unchanged": census}
                )
        patch_path = HERE / "related.patch"
        if patch_path.exists():
            assert patch_path.read_text() == "".join(
                patch
            )  # Preserve prior unpublished exact patch.
        else:
            with patch_path.open("x") as stream:
                stream.write("".join(patch))
        old_target = (
            MAIN
            / ".artifacts/research-acceptance/public-no-bypass-v1/trained-boundary-review-dispatch-v1/target.json"
        )
        old_refs = json.loads(old_target.read_text())["selected_refs"]
        names = [
            "qualify_no_bypass.py",
            "entry_guard.py",
            "arena_clock.rs",
            "runtime.rs",
            "scoped-clippy-config.json",
            "trained-native-config-v1.json",
            "software-source-plan-v1.json",
        ]
        unchanged = {}
        for raw, expected in old_refs.items():
            if Path(raw).name in names:
                assert identity(Path(raw)) == expected
                unchanged[raw] = expected
        assert len(unchanged) == 5
        clock_control = (
            MAIN / ".artifacts/nnue-public-no-bypass-review353-v1/clock-related-v2/control.json"
        )
        assert (
            identity(clock_control)["SHA256"]
            == "0d7ed90e30159786b48f818b3efea8ea7a3049a5d077de175fb1e434264cdaa7"
        )
        for row in json.loads(clock_control.read_text())["current_changed_source_refs"]:
            expected = {key: row[key] for key in ["SHA256", "bytes", "mode"]}
            assert identity(Path(row["path"])) == expected
            unchanged[row["path"]] = expected
        assert len(unchanged) == 7
        # The current normal-return SearchError exposes no work counters; do not fabricate them.
        source_after = {raw: identity(Path(raw)) for raw in current}
        assert source_after == current
        rss = int(re.search(r"VmRSS:\s+(\d+)", Path("/proc/self/status").read_text())[1]) * 1024
        assert rss + 64 * 1024**2 < 512 * 1024**2
        write(
            "static-check.json",
            {
                "schema": "quoridor.public-no-bypass.T1-T2.static.v1",
                "proofs": proofs,
                "unchanged_refs": unchanged,
                "new_Rust_definitions": definitions,
                "Rust_execution": "UNBUILT_NOT_RUN",
                "source_after_match": True,
                "numeric_model_Search_Cargo_calls": 0,
                "physical": {
                    "namedquiet": [],
                    "MemAvailable_B": memory,
                    "CPU": 3,
                    "package_core": topology,
                    "AS_B": 512 * 1024**2,
                    "sample_inclusive64MiB_B": rss + 64 * 1024**2,
                    "continuous_peak": "UNKNOWN",
                },
                "STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "remaining": [],
            },
        )
        write("current-source-map.json", {"changed": current, "unchanged": unchanged})
        print(
            json.dumps(
                {
                    "paths": len(current),
                    "Rust_definitions_unbuilt": len(definitions),
                    "patch_SHA256": identity(patch_path)["SHA256"],
                    "remaining": [],
                }
            )
        )


if __name__ == "__main__":
    main()
