"""One stopped353 preparation: exact existing assets, no numerical framework import."""

import copy
import ctypes
import datetime
import difflib
import fcntl
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import sys
import time

R = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1")
WT = R.parents[1]
P = R / "numerical-entry-preparation-v1"
OLD = Path("/workspaces/quoridor/.worktree/learning-million/.artifacts/public-full-learning")
CORPUS = Path(
    "/workspaces/quoridor/.worktree/assets/inputs/public-full-learning/original-full-v1/recovery-r1/corpus"
)
INC = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/trigger-patience-v1/patience1/output"
)
ENV = Path("/home/vscode/.cache/inference/envs/quoridor-training")
PYTHON = ENV / "bin/python"
TORCH = ENV / "lib/python3.14/site-packages/torch"


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def ident(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode), str(path)
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"SHA256": digest, "bytes": info.st_size, "mode": f"{stat.S_IMODE(info.st_mode):04o}"}


def main():
    beginning = time.monotonic()
    spec = importlib.util.spec_from_file_location("guard", R / "entry_guard.py")
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    with guard.LOCK.open("a+b") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet = guard.quiet()
        sys.path.insert(0, str(WT / "python"))
        from quoridor_training import cycle_process as process

        memory = process.available_memory()
        assert memory >= 14 * 1024**3
        device = process.DeviceMemory()
        info = device.Info()
        assert not device.library.nvmlDeviceGetMemoryInfo(device.handle, ctypes.byref(info))
        assert info.free >= 6 * 1024**3
        config = json.loads((R / "numerical-admission-v1.json").read_text())
        assert config["output"] == str(R / "numerical-qualification-v1/output")
        sources = [
            "common.py",
            "train.py",
            "residual_model.py",
            "scaled_model.py",
            "supply.py",
            "cycle_process.py",
            "sampling.py",
            "snapshot.py",
            "public_features.py",
            "cache.py",
            "distance_steps.py",
        ]
        paths = [
            R / "entry_guard.py",
            R / "qualify_no_bypass.py",
            R / "numerical-admission-v1.json",
            R / "candidate-fit-config-v1.json",
            R / "candidate-input-binding-v1.json",
            R / "head-input-prefixes-v1.json",
            R / "software-entry-v1/qualified-software-STOP.json",
            R / "private-images-v1/head-input-v1",
            OLD / "train-statistics-r1/statistics/train-only-scale.json",
            OLD / "train-statistics-r1/statistics/train-only-constant.json",
            INC / "best.pt",
            INC / "best-model/manifest.json",
            INC / "best-model/weights.f32",
            CORPUS / "cache.json",
            CORPUS / "train.bin",
            CORPUS / "validation.bin",
            PYTHON.resolve(),
            ENV / "pyvenv.cfg",
            TORCH / "version.py",
            TORCH / "__init__.py",
            TORCH / "nn/modules/module.py",
            TORCH / "lib/libtorch_cpu.so",
            TORCH / "lib/libtorch_cuda.so",
            Path(
                "/workspaces/quoridor/.worktree/learning-million/.artifacts/learning-million/libquoridor_data.so"
            ),
            guard.PROOF,
            *[WT / "python/quoridor_training" / name for name in sources],
        ]
        bindings = {str(path): ident(path) for path in paths}
        expected = {
            str(
                CORPUS / "train.bin"
            ): "f12dc04cc6f94b047e677835191d36b42b71f69e6c8753e5f2555ebddb3dabdb",
            str(
                CORPUS / "validation.bin"
            ): "babf61a106a4a317601f652069d00025712ff16174c71fee6255aa06c8e9b69f",
            str(
                INC / "best.pt"
            ): "b16ba38e65de5de40e6dd421e2200fb25f7524a46b13e441c976eec32f1305ac",
            str(
                INC / "best-model/weights.f32"
            ): "9ca438e43b0c105ac5f802a302946f2ba71623ea2bc443b9c54cc9a8468b75b0",
            str(
                R / "private-images-v1/head-input-v1"
            ): "222269071c01f94aa604fb391b49f763dcc86171ac492816c1e454627b14bd5b",
            str(
                R / "qualify_no_bypass.py"
            ): "868665d7b83c554b49727a2f73b8bc619f995b8dcab4f59b8567821e2f754ad6",
            str(
                CORPUS / "cache.json"
            ): "07d81abc2230b2fe6b7c5fb7a425e7e3109bf9af2c467f5c72f8d3bdb975279b",
            str(guard.PROOF): guard.PROOF_SHA,
            str(
                Path(
                    "/workspaces/quoridor/.worktree/learning-million/.artifacts/learning-million/libquoridor_data.so"
                )
            ): "f83dbc68735d688fe0056731f04f167e11e51dfe77fe221e3cd80155b564f1f3",
        }
        for path, digest in expected.items():
            assert bindings[path]["SHA256"] == digest, path
        admission = json.loads((R / "software-admission-v1.json").read_text())
        for review in admission["source_reviews"]:
            guard.review_clear(review)
            bindings[review["path"]] = review["identity"]
            target = Path(review["target"])
            bindings[str(target)] = ident(target)
        components = copy.deepcopy(admission["storage_components"])
        observed = json.loads((R / "software-entry-v1/worker-runtime/STOP.json").read_text())[
            "sample_component_maxima_B"
        ]
        for component in components:
            component["retained_floor_B"] = max(
                component.get("retained_floor_B", 0),
                observed.get(component["name"], 0),
                guard.charged(component["roots"], component.get("excluded", ())),
            )
            assert component["retained_floor_B"] <= component["upper_B"]
            if component["name"] == "TMP":
                component["roots"].append(str(R / "numerical-entry-v1/worker-runtime/TMP"))
        entry = {
            **admission,
            "stage": "numerical",
            "commands": [
                [
                    str(PYTHON),
                    "-B",
                    str(R / "qualify_no_bypass.py"),
                    str(R / "numerical-admission-v1.json"),
                ]
            ],
            "operational_seconds": 180,
            "worker_CPUs": [0, 2, 4, 6],
            "controller_CPU": 8,
            "family_RSS_upper_B": 10 * 1024**3,
            "whole_device_VRAM_upper_B": 6 * 1024**3,
            "runtime": str(R / "numerical-entry-v1/worker-runtime"),
            "prepare_owned_parents": [str(R / "numerical-qualification-v1")],
            "bindings": bindings,
            "symlink_bindings": {str(PYTHON): str(PYTHON.resolve())},
            "storage_components": components,
            "initial_parameter_SHA256": config["initial_parameter_SHA256"],
            "planned_counts": {
                "Torch_calls": 4,
                "Torch_rows": 2060,
                "native_calls": 8,
                "disposable_Adam_updates": 1,
                "fit_calls": 0,
            },
            "sealed_E_reads": 0,
        }
        entry.pop("private_image", None)
        guard.supported_commands(entry)
        (R / "numerical-entry-v1").mkdir(exist_ok=False)
        write(R / "numerical-entry-admission-v1.json", entry)
        old = gzip.decompress((P / "entry_guard.software-source.gz").read_bytes()).decode()
        new = (R / "entry_guard.py").read_text()
        (P / "ordinary-control-delta.patch").write_text(
            "".join(
                difflib.unified_diff(
                    old.splitlines(True),
                    new.splitlines(True),
                    fromfile="software-entry-guard.py",
                    tofile="current-entry-guard.py",
                )
            )
        )
        write(
            P / "guarded-input-framework-physical-preparation.json",
            {
                "actual_STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "applied_context_verified": "2026-10-09T15:38:00.311Z/fullaccess/never/gpt-6.1-sol/high/originallearning-million",
                "named_competitors": quiet,
                "available_memory_B": memory,
                "device_total_B": info.total,
                "device_free_B": info.free,
                "selected_bindings": bindings,
                "selected_bytes": sum(x["bytes"] for x in bindings.values()),
                "existing_payloads_readonly_no_copy": True,
                "model_framework_imports_forward_optimizer_fit_Cargo_Search": 0,
                "owned_remaining": [],
                "whole_seconds": time.monotonic() - beginning,
                "continuous_peak": "UNKNOWN",
                "failed_prior_preparation": "nonexistent native_corpus.py before any model/framework; correct maintained cache.py",
                "whole_B": 4294967296,
                "prospective_increment_B": 524288,
            },
        )
        print(
            json.dumps(
                {
                    "preparation_STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    "bindings": len(bindings),
                    "bytes": sum(x["bytes"] for x in bindings.values()),
                    "whole_seconds": time.monotonic() - beginning,
                    "model_calls": 0,
                }
            )
        )


if __name__ == "__main__":
    main()
