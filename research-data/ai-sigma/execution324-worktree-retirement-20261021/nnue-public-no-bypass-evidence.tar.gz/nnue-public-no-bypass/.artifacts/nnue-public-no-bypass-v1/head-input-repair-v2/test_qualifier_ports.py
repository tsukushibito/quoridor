"""New synthetic discriminator ports; stdlib only, no numerical framework/model."""

import importlib.util
import math
from pathlib import Path
import struct
import unittest


SOURCE = Path(__file__).resolve().parents[1] / "qualify_no_bypass.py"
spec = importlib.util.spec_from_file_location("qualifier_ports_source", SOURCE)
qualifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qualifier)


class Array:
    def __init__(self, values, dtype="f32", shape=None):
        self.values = values
        self.dtype = dtype
        self.shape = shape or (len(values),)

    def __sub__(self, other):
        return Array([x - y for x, y in zip(self.values, other.values, strict=True)])

    def __ne__(self, value):
        return Array([x != value for row in self.values for x in row], "bool")

    def __getitem__(self, slices):
        rows, columns = slices
        values = [row[columns] for row in self.values[rows]]
        return Array(values, self.dtype, (len(values), len(values[0])))

    def view(self, dtype):
        values = [
            [struct.unpack("<I", struct.pack("<f", x))[0] for x in row] for row in self.values
        ]
        return Array(values, dtype, self.shape)

    def all(self):
        return all(self.values)


class NP:
    ndarray = Array
    float32 = "f32"
    uint32 = "u32"

    @staticmethod
    def isfinite(value):
        rows = value.values if len(value.shape) == 1 else [x for row in value.values for x in row]
        return Array([math.isfinite(x) for x in rows], "bool")

    @staticmethod
    def abs(value):
        return Array([abs(x) for x in value.values])

    @staticmethod
    def max(value):
        return max(value.values)

    @staticmethod
    def any(value):
        return any(value.values)

    @staticmethod
    def array_equal(left, right):
        return left.shape == right.shape and left.values == right.values


class Head:
    def __init__(self, registration_error=None, removal_error=None):
        self.foreign = lambda *_: None
        self._forward_pre_hooks = {1: self.foreign}
        self._forward_pre_hooks_with_kwargs = {1: True}
        self.registration_error = registration_error
        self.removal_error = removal_error

    def register_forward_pre_hook(self, callback):
        self._forward_pre_hooks[2] = callback
        if self.registration_error:
            raise self.registration_error
        head = self

        class Handle:
            def remove(self):
                if head.removal_error:
                    raise head.removal_error
                head._forward_pre_hooks.pop(2, None)

        return Handle()


class ModelPort:
    def __init__(self, head, error):
        self.h = head
        self.error = error

    def __call__(self, *_):
        raise self.error


class QualifierPorts(unittest.TestCase):
    def test_nonfinite_returns_and_errors_refuse_before_tolerance(self):
        for origin in ("CPU candidate/native", "CPU incumbent/native", "CUDA candidate/CPU"):
            for bad in (math.nan, math.inf, -math.inf):
                with self.subTest(origin=origin, bad=bad):
                    with self.assertRaisesRegex(ValueError, origin + " actual: nonfinite"):
                        qualifier.finite_correspondence(
                            NP, Array([bad, 0, 0, 0]), Array([0] * 4), origin
                        )
                    with self.assertRaisesRegex(ValueError, origin + " reference: nonfinite"):
                        qualifier.finite_correspondence(
                            NP, Array([0] * 4), Array([bad, 0, 0, 0]), origin
                        )
        with self.assertRaisesRegex(ValueError, "errors: nonfinite"):
            qualifier.finite_correspondence(NP, Array([1e308] * 4), Array([-1e308] * 4), "overflow")

    def test_wrong_shape_dtype_and_finite_tolerance(self):
        for value in (Array([0] * 3), Array([0] * 4, "f64"), [0] * 4):
            with (
                self.subTest(value=value),
                self.assertRaisesRegex(ValueError, "expected FP32 shape"),
            ):
                qualifier.finite_correspondence(NP, value, Array([0] * 4), "CPU")
        qualifier.finite_correspondence(NP, Array([1e-6] * 4), Array([0] * 4), "within")
        with self.assertRaisesRegex(ValueError, "finite correspondence error"):
            qualifier.finite_correspondence(NP, Array([1e-3] * 4), Array([0] * 4), "outside")

    def test_cuda_all_d_and_zero4_bits(self):
        expected = Array([[0, 0] for _ in range(4)], "u32", (4, 2))
        valid = Array([[0.0] * 6 for _ in range(4)], shape=(4, 6))
        qualifier.captured_input_bits(NP, valid, expected, "CUDA")
        for column in range(6):
            for value in (1.0, -0.0):
                rows = [[0.0] * 6 for _ in range(4)]
                rows[2][column] = value
                with (
                    self.subTest(column=column, value=value),
                    self.assertRaisesRegex(ValueError, "D/Zero4 bits"),
                ):
                    qualifier.captured_input_bits(NP, Array(rows, shape=(4, 6)), expected, "CUDA")
        rows = [[0.0] * 6 for _ in range(4)]
        rows[0][5] = math.nan
        with self.assertRaisesRegex(ValueError, "nonfinite actual return"):
            qualifier.captured_input_bits(NP, Array(rows, shape=(4, 6)), expected, "CUDA")

    def test_registration_cancellation_removes_only_owned_callback(self):
        primary = KeyboardInterrupt("after callback installation")
        head = Head(registration_error=primary)
        with self.assertRaises(KeyboardInterrupt) as caught:
            qualifier.actual_head_forward(
                ModelPort(head, AssertionError("unreached")), None, [], None, []
            )
        self.assertIs(caught.exception, primary)
        self.assertEqual(head._forward_pre_hooks, {1: head.foreign})
        self.assertEqual(head._forward_pre_hooks_with_kwargs, {1: True})

    def test_forward_primary_and_all_restoration_errors_retained(self):
        primary = RuntimeError("forward failure")
        secondary = OSError("handle removal")
        head = Head(removal_error=secondary)
        with self.assertRaises(RuntimeError) as caught:
            qualifier.actual_head_forward(ModelPort(head, primary), None, [], None, [])
        self.assertIs(caught.exception, primary)
        self.assertEqual(primary.retained_observer_restoration_errors, (secondary,))
        self.assertEqual(head._forward_pre_hooks, {1: head.foreign})
        self.assertIn("handle removal", primary.__notes__[0])

    def test_registration_primary_and_registry_cleanup_error_retained(self):
        primary = KeyboardInterrupt("registration")
        secondary = OSError("registry census")

        class FailingRegistry(dict):
            def items(self):
                raise secondary

        head = Head(registration_error=primary)
        head._forward_pre_hooks = FailingRegistry(head._forward_pre_hooks)
        with self.assertRaises(KeyboardInterrupt) as caught:
            qualifier.actual_head_forward(ModelPort(head, AssertionError()), None, [], None, [])
        self.assertIs(caught.exception, primary)
        self.assertEqual(primary.retained_observer_restoration_errors, (secondary,))
        self.assertIs(head._forward_pre_hooks[1], head.foreign)
        # Failed cleanup is retained, not misrepresented as a successful restoration.
        self.assertIn(2, head._forward_pre_hooks)

    def test_multiple_restoration_errors_preserve_primary(self):
        primary = RuntimeError("forward")
        removal = OSError("remove")
        census = OSError("census")

        class FailingRegistry(dict):
            def items(self):
                raise census

        head = Head(removal_error=removal)
        head._forward_pre_hooks = FailingRegistry(head._forward_pre_hooks)
        with self.assertRaises(RuntimeError) as caught:
            qualifier.actual_head_forward(ModelPort(head, primary), None, [], None, [])
        self.assertIs(caught.exception, primary)
        self.assertEqual(primary.retained_observer_restoration_errors, (removal, census))
        self.assertEqual(len(primary.__notes__), 2)

    def test_successful_forward_restoration_error_is_not_lost(self):
        removal = OSError("remove after success")
        head = Head(removal_error=removal)

        class TensorPort:
            shape = (0, 70)

            def detach(self):
                return self

            cpu = detach
            numpy = detach
            copy = detach

            def __getitem__(self, _):
                return "synthetic capture"

        class SuccessfulPort:
            h = head

            def __call__(self, *_):
                head._forward_pre_hooks[2](head, (TensorPort(),))
                return "synthetic returned output"

        with self.assertRaises(OSError) as caught:
            qualifier.actual_head_forward(SuccessfulPort(), None, [], None, [])
        self.assertIs(caught.exception, removal)
        self.assertEqual(removal.retained_observer_restoration_errors, (removal,))
        self.assertEqual(head._forward_pre_hooks, {1: head.foreign})


if __name__ == "__main__":
    unittest.main(verbosity=2)
