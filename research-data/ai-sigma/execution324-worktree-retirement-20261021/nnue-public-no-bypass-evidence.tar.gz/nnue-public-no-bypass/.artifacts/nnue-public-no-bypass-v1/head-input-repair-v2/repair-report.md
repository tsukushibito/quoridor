# 353 H1–H3 related qualifier repair

Only `qualify_no_bypass.py` changed from the stopped companion. Original beforeimage, SHA, companion and blocker report remain retained.

H1 validates the existing CPU/native/CUDA arrays as FP32, shape (4,), finite returns and finite element errors before tolerance. Failure messages name the originating return or error array. No extra forward is added.

H2 validates every existing captured head array as finite FP32 (4,6), exact standardized D bits and all four positive-zero bits. The CUDA capture uses the same actual native expected bits as both CPU captures. FT, predictions and gradients are not required to equal across conditions.

H3 puts registration inside the cleanup region. Cleanup removes the acquired handle, then locates only callback entries whose object identity is the local observer. This also covers a registration port that installs the callback and raises before returning a handle. Foreign hooks remain untouched. All restoration exceptions stay attached to the original primary object; with no primary, the first restoration exception is raised with all retained facts. Cleanup failure is reported honestly, without a universal asynchronous-fault guarantee.

Eight new stdlib synthetic-port methods passed once under the canonical nonblocking lifetime lease. They discriminate NaN/infinite returns, subtraction overflow, shape/dtype mismatch, finite tolerance failure, all six CUDA D/Zero4 fields (including negative zero), registration cancellation, primary/one-or-multiple restoration errors, registry cleanup refusal and post-success restoration failure. These are mocked source ports, not real Torch/native/device qualification. No framework, model, corpus, native, Search or fit call was executed. The original five config tests were not repeated.

Ports START 2026-10-09T14:09:44.937384+00:00, STOP 14:09:44.977477+00:00; direct wait exit0, exact child absent, source-after exact, secondary[], ownership/TMP[]. Whole 0.05745410895906389s; sampled child max RSS18976KiB, continuous family peak UNKNOWN. CPU3/5 freshly distinct physical cores. The ended peer campaign and collector STOP were preserved; this entry freshly checked named compute/browser[] and acquired the canonical lease nonblocking.

Original planned four Torch calls/2060 rows/native8/one disposable Adam/fit0 and all native arithmetic/config/recipe/initializer sources remain unchanged and unexecuted here. Numerical/private/framework/CUDA/fit readiness remains pending. Actual Policy human presentation of fit curves and same-V INITIAL/BEST/LAST table remains required before candidate games, without a reply-only approval gate.

Prospective repair upper262144B stays inside the held source phase2MiB/source64MiB/whole4GiB proof c810e5e0. Old charges, failed fees, masks and UNKNOWN facts stay held. This is a related return to SAME353.2 through324; no new leaf or broad source assessment.
