"""Three NEW related source-semantic ports, not actual Rust branch execution.

The actual maintained invoke-to-authority Rust definitions are UNBUILT/NOT_RUN
and will run after related source clear under the affected software entry.
"""

import gzip
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent
WT = ROOT.parents[2]
CLOCK = (WT / "crates/quoridor-runner/src/arena_clock.rs").read_text()
RUNTIME = (WT / "crates/quoridor-runner/src/runtime.rs").read_text()


def block(text, signature):
    start = text.index(signature)
    opening = text.index("{", start)
    depth = 1
    end = opening + 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return text[start:end]


def malformed_return_expression(text):
    invoke = block(text, "fn invoke_alpha_observed(")
    body = block(invoke, "if done.invalid {").split("{", 1)[1].rsplit("}", 1)[0]
    return " ".join(x.split("//", 1)[0].strip() for x in body.splitlines()).strip()


class RelatedSourcePorts(unittest.TestCase):
    def test_actual_malformed_branch_is_identity_for_both_returned_objects(self):
        expression = malformed_return_expression(RUNTIME)
        self.assertEqual(expression, "result")
        # This is a symbolic ownership check of that literal Rust expression,
        # not an execution of session.search_with_updates or the Rust function.
        for returned in [
            {"stats": {"nodes": 37}, "PV": [13], "stop": "depth"},
            RuntimeError("distinct original Root"),
        ]:
            environment = {"result": returned}
            self.assertIs(environment[expression], returned)
        before = gzip.decompress((ROOT / "runtime.rs.before.gz").read_bytes()).decode()
        self.assertNotEqual(malformed_return_expression(before), "result")
        invoke = block(RUNTIME, "fn invoke_alpha_observed(")
        self.assertLess(
            invoke.index("let result = session.search_with_updates"),
            invoke.index("if done.invalid"),
        )
        self.assertIn("Ok(result) => profile.record(result)", invoke)

    def test_every_present_action_is_queued_before_any_coherence_or_deadline_refusal(self):
        publish = block(CLOCK, "pub fn publish(")
        queue = block(publish, "if let Some(action) = r.action")
        self.assertIn("self.actions_to_validate.push(action);", queue)
        self.assertLess(publish.index("if let Some(action)"), publish.index("let coherent"))
        self.assertLess(publish.index("actions_to_validate.push"), publish.index("if !coherent"))
        self.assertLess(
            publish.index("actions_to_validate.push"), publish.index("deadline.is_none_or")
        )
        self.assertNotIn("unwrap()", publish)
        validate = block(CLOCK, "pub fn validate_actions(")
        self.assertIn("valid &= legal(action)", validate)
        self.assertNotIn("valid &&", validate)
        self.assertNotIn(".play(", publish)

    def test_actual_invoke_to_authority_definitions_and_c2_arrival_fixture_are_bound(self):
        tests = block(RUNTIME, "mod alpha_receipt_353_tests")
        self.assertEqual(tests.count("#[test]"), 5)
        invoke = block(tests, "fn malformed_then_invoke(")
        self.assertIn("completion.publish(&malformed, None)", invoke)
        self.assertIn("invoke_alpha_observed(", invoke)
        for name in [
            "fn receipt_353_actual_invoke_malformed_then_ok_retains_work_and_refuses()",
            "fn receipt_353_actual_invoke_malformed_then_original_error_retains_cause()",
        ]:
            definition = block(tests, name)
            self.assertIn("malformed_then_invoke(", definition)
            self.assertIn("alpha_validate_completion(", definition)
            self.assertIn("alpha_receipt_decision(", definition)
            self.assertIn("Failure::EngineError", definition)
        malformed = block(CLOCK, "fn receipt_353_finite_depth_action_pv_errors_are_not_rescued()")
        for required in [
            "authority_received",
            "vec![13, 209]",
            "vec![13, 13, 209]",
            "c.at, chosen_at",
            "Some(Instant::now())",
        ]:
            self.assertIn(required, malformed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
