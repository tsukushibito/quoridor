# 353.4 T2-R1 timing-only confirmation

Confirm only the four-line permutation in public-no-bypass-cost.rs: stage string and ATTEMPTED JSON preparation now precede search_start. The scalar attempted counter, maintained session.search, all arguments/limits and immediate post-return search_seconds remain byte-identical and in their original order. Whole-call and whole-phase still include observer and publication work. No cost subtraction, calibration, extra call, estimator change or impact claim.

The exact source-order discriminator rejects the previous observer placement and accepts the new window. Exact forward/inverse substitution and the one-hunk patch prove every other source byte unchanged, including the five new unbuilt Rust definitions. Rustfmt syntax/format check and Ruff for the source-check helper passed. There was no Rust compilation/execution, model/framework/native/Search/cost/fit/game run or replay of the prior19 Python ports.

Retain the accepted T1 and original T2 partial-evidence proof from control2778/report9683; do not resurvey those boundaries. The original targeta7eb, patch441835, archives and blocked controls remain immutable. The old cost a6eda5cf is retained in the new gzip beforeimage. The other three source identities match the accepted related assessment.

Numerical READY remains false. Actual software/private/input/framework/device/physical/peer/lifetime qualifications remain necessary after authentic narrow source confirmation. Policy actual presentation4ba is already satisfied. No new fit, games, scientific method, teacher/data/features/seed/clock/TT/default/N/seal or323 pause change. Return only this related question to the same353.4 reviewer through324.
