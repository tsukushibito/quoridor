"""T2-R1 exact source-order discriminator, no Rust/model/Search execution."""

import ast
import datetime
import difflib
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import stat
import sys

WT = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass")
ROOT = WT / ".artifacts/nnue-public-no-bypass-v1"
HERE = ROOT / "trained-timing-repair-v3"
COST = WT / "crates/quoridor-runner/examples/public-no-bypass-cost.rs"
MAIN = Path("/workspaces/quoridor")
REVIEW = MAIN / ".artifacts/nnue-public-no-bypass-review353-v1/trained-boundary-related-v2"
LOCK = MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock"
OLD = """            let search_start = Instant::now();
            observed.calls_attempted += 1;
            observed.stage = format!("{tag}/prefix{prefix_index}/Search");
            observed.rows[slot]["state"] = json!("ATTEMPTED");
"""
NEW = """            observed.stage = format!("{tag}/prefix{prefix_index}/Search");
            observed.rows[slot]["state"] = json!("ATTEMPTED");
            let search_start = Instant::now();
            observed.calls_attempted += 1;
"""


def identity(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    return {
        "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": info.st_size,
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


def create(name, value):
    with (HERE / name).open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


def sample(source):
    begin = source.index("            let search_start = Instant::now();")
    end = source.index(
        "            let search_seconds = search_start.elapsed().as_secs_f64();", begin
    )
    return source[begin:end]


def main():
    with LOCK.open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        tree = ast.parse((ROOT / "entry_guard.py").read_text())
        node = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == "quiet")
        env = dict(os=os, sys=sys, Path=Path, re=re, json=json)
        exec(compile(ast.Module(body=[node], type_ignores=[]), "maintained-quiet", "exec"), env)
        env["quiet"]()
        assert 3 in os.sched_getaffinity(0)
        available = (
            int(re.search(r"MemAvailable:\s+(\d+)", Path("/proc/meminfo").read_text())[1]) * 1024
        )
        assert available > 512 * 1024**2 + 4 * 1024**3
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        original = gzip.decompress((HERE / "cost.before.rs.gz").read_bytes()).decode()
        current = COST.read_text()
        before = json.loads((HERE / "before.json").read_text())
        assert hashlib.sha256(original.encode()).hexdigest() == before["SHA256"]
        assert original.count(OLD) == 1 and current.count(NEW) == 1
        assert original.replace(OLD, NEW) == current
        assert current.replace(NEW, OLD) == original
        old_sample, new_sample = sample(original), sample(current)
        assert "observed.stage = format!" in old_sample and 'json!("ATTEMPTED")' in old_sample
        assert (
            "observed.stage = format!" not in new_sample and 'json!("ATTEMPTED")' not in new_sample
        )
        assert new_sample == old_sample.replace(
            '            observed.stage = format!("{tag}/prefix{prefix_index}/Search");\n'
            '            observed.rows[slot]["state"] = json!("ATTEMPTED");\n',
            "",
        )
        assert new_sample.startswith(
            "            let search_start = Instant::now();\n"
            "            observed.calls_attempted += 1;\n"
            "            let returned = session.search("
        )
        assert new_sample.endswith("            );\n")
        control = json.loads((REVIEW / "control.json").read_text())
        unchanged = {
            p: v for p, v in control["current_four_changed_source_refs"].items() if p != str(COST)
        }
        assert all(identity(Path(p)) == v for p, v in unchanged.items())
        source_identity = identity(COST)
        delta = "".join(
            difflib.unified_diff(
                original.splitlines(True),
                current.splitlines(True),
                fromfile="a/crates/quoridor-runner/examples/public-no-bypass-cost.rs",
                tofile="b/crates/quoridor-runner/examples/public-no-bypass-cost.rs",
            )
        )
        assert delta.count("@@ ") == 1
        with (HERE / "timing-only.patch").open("x") as stream:
            stream.write(delta)
        create(
            "static-check.json",
            {
                "schema": "quoridor.public-no-bypass.T2-R1.source-order.v1",
                "exact_four_line_permutation_only": True,
                "before_discriminator_rejects_new_observer_in_search_window": True,
                "after_discriminator_accepts_original_scalar_Search_end_window": True,
                "whole_call_and_phase_observer_publication_costs_retained": True,
                "all_other_source_bytes_and_five_Rust_definitions_unchanged": True,
                "forward_inverse_exact": True,
                "unchanged_three_refs": unchanged,
                "source_before_after_hash_match": identity(COST) == source_identity,
                "Rustfmt_check": "PASS",
                "runtime_cost_model_Cargo_Search_calls": 0,
                "old19Python_ports_and_oldsuccessful_suites_replayed": False,
                "five_Rust_definitions": "UNBUILT_NOT_RUN",
                "namedquiet": [],
                "CPU": 3,
                "MemAvailable_B": available,
                "AS_B": 512 * 1024**2,
                "continuous_peak": "UNKNOWN",
                "direct_child_waits": 0,
                "owned_readers_children_jobs_TMP_remaining": [],
                "STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            },
        )
        print(
            json.dumps(
                {
                    "only_changed_source": source_identity,
                    "patch": identity(HERE / "timing-only.patch"),
                    "source_order": "PASS",
                    "runtime_calls": 0,
                    "remaining": [],
                }
            )
        )


if __name__ == "__main__":
    main()
