"""Temporary353 lifetime entry around maintained process/resource helpers.

An immutable admission names the exact stage, source/review/input identities,
commands and owned namespaces. No framework/CUDA import precedes the NB lease.
This is task control, not a second trainer or experiment registry.
"""

import argparse
import datetime
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import time

WT = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass")
ROOT = WT / ".artifacts/nnue-public-no-bypass-v1"
ASSETS = Path("/workspaces/quoridor/.worktree/assets/checkpoints/public-no-bypass-v1")
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
PROOF = Path("/workspaces/quoridor/research-data/ai-sigma/public-no-bypass-v1/resources-v1.json")
PROOF_SHA = "c810e5e09a14d21719db086af22f7bdb9bb4adbbf1cb18e9ea479b86d394a534"
TOOLCHAIN = Path("/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin")


def identity_bytes(path, expected):
    p = Path(path)
    info = p.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size != expected["bytes"]:
        raise ValueError("regular exact named input: " + str(p))
    with p.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    if digest != expected["SHA256"] or f"{stat.S_IMODE(info.st_mode):04o}" != expected["mode"]:
        raise ValueError("exact digest/mode: " + str(p))


def review_clear(expected):
    identity_bytes(expected["path"], expected["identity"])
    actual = json.loads(Path(expected["path"]).read_text())
    schema = {
        "quoridor-4lc.353.1": "quoridor.nnue-public-no-bypass.source-review.v1",
        "quoridor-4lc.353.2": "quoridor.nnue-public-no-bypass.head-input-source-review.v1",
        "quoridor-4lc.353.3": "quoridor.nnue-public-no-bypass.clock-source-review.v1",
    }.get(expected["review_issue"])
    if (
        schema is None
        or actual.get("schema") != schema
        or actual.get("parent_issue") != "quoridor-4lc.353"
        or actual.get("review_issue") != expected["review_issue"]
        or actual.get("reviewed_boundary") != expected["reviewed_boundary"]
        or actual.get("source_clear") is not True
        or type(actual.get("blockers")) is not int
        or actual["blockers"] != 0
        or type(actual.get("ordinary")) is not int
        or actual["ordinary"] != 0
    ):
        raise ValueError("actual changed-boundary source receipt is not clear")
    target = Path(expected["target"])
    if actual.get("target_binding_SHA256") != hashlib.sha256(target.read_bytes()).hexdigest():
        raise ValueError("review binds a different stopped target")
    census = (
        "owned_readers_children_jobs_TMP_remaining"
        if expected["review_issue"] == "quoridor-4lc.353.3"
        else "owned_children_jobs_readers_TMP"
    )
    for field in ("owned_remaining", census):
        if type(actual.get(field)) is not list or actual[field] != []:
            raise ValueError("actual reviewer ownership census missing/nonempty")
    moment = datetime.datetime.fromisoformat(actual["actual_reader_STOP"])
    if moment.tzinfo is None or moment > datetime.datetime.now(datetime.timezone.utc):
        raise ValueError("actual reader STOP invalid")
    if expected["review_issue"] == "quoridor-4lc.353.3":
        current = actual.get("current_changed_source_refs")
        if type(current) is not list or len(current) != 2:
            raise ValueError("actual two-path caller receipt missing")
        for row in current:
            identity_bytes(row["path"], row)


def reviewed_current_identity(config, path, reviewed):
    """Allow only the exact compiler-requested equivalent ledger-if collapse."""
    repairs = config.get("routine_observer_repairs", {})
    allowed = {
        str(WT / "crates/quoridor-nnue/examples/public-no-bypass-input.rs"): "slots",
        str(WT / "crates/quoridor-runner/examples/public-no-bypass-cost.rs"): "rows",
    }
    if type(repairs) is not dict or not set(repairs).issubset(allowed):
        raise ValueError("unknown source repair/alias not admitted")
    if path not in repairs:
        identity_bytes(path, reviewed)
        return
    row = repairs[path]
    if row["before"] != reviewed:
        raise ValueError("mechanical repair beforeimage is not the actual reviewed source")
    identity_bytes(row["before_gzip"], row["before_gzip_identity"])
    original = gzip.decompress(Path(row["before_gzip"]).read_bytes())
    if (
        hashlib.sha256(original).hexdigest() != reviewed["SHA256"]
        or len(original) != reviewed["bytes"]
    ):
        raise ValueError("mechanical repair archive differs from actual review")
    element = allowed[path]
    punctuation = ";" if element == "slots" else ""
    old = (
        "    if primary.is_some() {\n        if let Some(i) = observed.active {\n"
        + f'            observed.{element}[i]["state"] = json!("FAILED"){punctuation}\n'
        + "        }\n    }\n"
    )
    new = (
        "    if primary.is_some()\n        && let Some(i) = observed.active\n    {\n"
        + f'        observed.{element}[i]["state"] = json!("FAILED"){punctuation}\n'
        + "    }\n"
    )
    if (
        original.decode().count(old) != 1
        or original.decode().replace(old, new) != Path(path).read_text()
    ):
        raise ValueError("source differs beyond exact equivalent observer condition")
    identity_bytes(path, row["after"])
    if row["after"]["mode"] != reviewed["mode"]:
        raise ValueError("mechanical source mode changed")


def trained_boundary_clear(config):
    """Parse the complementary immutable partial/timing reviews, never copied clears."""
    supplied = config["trained_boundary_reviews"]
    if type(supplied) is not dict or set(supplied) != {"partial", "timing"}:
        raise ValueError("actual complementary353.4 receipts required")
    actual = {}
    targets = {}
    for name in ["partial", "timing"]:
        row = supplied[name]
        identity_bytes(row["path"], row["identity"])
        value = json.loads(Path(row["path"]).read_text())
        identity_bytes(row["target"], row["target_identity"])
        target = json.loads(Path(row["target"]).read_text())
        if (
            value.get("schema")
            != "quoridor.nnue-public-no-bypass.trained-boundary-source-review.v1"
            or value.get("review_issue") != "quoridor-4lc.353.4"
            or value.get("parent_issue") != "quoridor-4lc.353"
            or value.get("reviewed_boundary") != row["reviewed_boundary"]
            or value.get("target_binding_SHA256") != row["target_identity"]["SHA256"]
            or type(value.get("blockers")) is not int
            or type(value.get("ordinary")) is not int
            or value["ordinary"] != 0
        ):
            raise ValueError("actual353.4 scope/target/count types differ")
        stop_field = "actual_reader_STOP" if name == "partial" else "actual_source_reader_STOP"
        moment = datetime.datetime.fromisoformat(value[stop_field])
        producer = datetime.datetime.fromisoformat(target["source_writer_reader_STOP"])
        if (
            moment.tzinfo is None
            or producer.tzinfo is None
            or producer > moment
            or moment > datetime.datetime.now(datetime.timezone.utc)
            or target["source_writer_reader_STOP"] != value["producer_source_STOP"]
        ):
            raise ValueError("actual353.4 source/reader STOP invalid")
        fields = (
            ["owned_remaining", "owned_readers_children_jobs_TMP_remaining"]
            if name == "partial"
            else ["owned_readers", "owned_children", "owned_jobs", "owned_TMP", "remaining"]
        )
        if any(type(value.get(field)) is not list or value[field] != [] for field in fields):
            raise ValueError("actual353.4 ownership census missing/nonempty")
        actual[name], targets[name] = value, target
    partial, timing = actual["partial"], actual["timing"]
    if datetime.datetime.fromisoformat(
        partial["actual_reader_STOP"]
    ) > datetime.datetime.fromisoformat(targets["timing"]["source_writer_reader_STOP"]):
        raise ValueError("timing repair predates actual partial reviewer release")
    if (
        partial.get("source_clear") is not False
        or partial["blockers"] != 1
        or partial.get("T2_original_partial_evidence_loss_resolved_in_source") is not True
        or partial.get("resolved_findings") != ["T1"]
        or partial.get("remaining_findings") != ["T2-R1"]
        or timing.get("source_clear") is not True
        or timing["blockers"] != 0
        or timing.get("T2_R1_resolved") is not True
        or timing.get("remaining_findings") != []
    ):
        raise ValueError("T1/partial acceptance and sole remaining timing resolution required")
    cost = str(WT / "crates/quoridor-runner/examples/public-no-bypass-cost.rs")
    original = partial.get("current_four_changed_source_refs")
    current = timing.get("current_cost_source")
    if type(original) is not dict or len(original) != 4 or cost not in original:
        raise ValueError("actual four reviewed partial sources missing")
    if type(current) is not dict or set(current) != {cost}:
        raise ValueError("actual one reviewed timing source missing")
    unchanged = {path: identity for path, identity in original.items() if path != cost}
    if (
        targets["partial"].get("changed_refs") != original
        or targets["timing"].get("changed_refs") != current
        or targets["timing"].get("accepted_unchanged_three_refs") != unchanged
        or targets["timing"].get("before", {}).get("SHA256") != original[cost]["SHA256"]
    ):
        raise ValueError("actual partial-to-timing source chain differs")
    for path, identity in {**unchanged, **current}.items():
        if timing["selected_refs_before"].get(path) != identity:
            raise ValueError("actual timing receipt does not bind accepted current source")
        reviewed_current_identity(config, path, identity)


def quiet():
    found = []
    pattern = re.compile(
        r"(^|/)(cargo|rustc|perf|quoridor-runner|nnue-diagnose|chromium|chrome)(\s|$)"
        r"|current_gradients.py|torchrun|finite-driver|statistics-runtime|qualify_trained.py"
        r"|trained-native-v[12]|whole-cost-v[12]|direct16-runner-v1|quoridor_training.train"
    )
    for p in Path("/proc").iterdir():
        if not p.name.isdigit() or int(p.name) in (os.getpid(), os.getppid()):
            continue
        try:
            argv = p.joinpath("cmdline").read_bytes().split(b"\0")
            if Path(os.fsdecode(argv[0])).name in ("bash", "sh", "timeout"):
                continue
            text = " ".join(os.fsdecode(x) for x in argv if x)
            if pattern.search(text):
                found.append({"pid": int(p.name), "argv": text[:512]})
        except (OSError, IndexError):
            continue
    if found:
        raise RuntimeError("actual named competitor: " + json.dumps(found))
    return found


def owned(path):
    p = Path(path)
    if p.is_symlink() or not (p.is_relative_to(ROOT) or p.is_relative_to(ASSETS)):
        raise ValueError("exclusive353 output namespace: " + str(p))
    for parent in p.parents:
        if parent.is_symlink():
            raise ValueError("output parent symlink: " + str(parent))
    return p


def charged(roots, excluded=()):
    """Only exact owned named roots; no global storage walk or old credit."""
    seen, total = set(), 0
    excluded = {Path(x) for x in excluded}
    for item in roots:
        root = WT if Path(item) == WT else owned(item)
        if not root.exists():
            continue
        paths = [root]
        if root.is_dir():
            pending = [root]
            while pending:
                directory = pending.pop()
                for path in directory.iterdir():
                    if path in excluded or root == WT and path == WT / ".artifacts":
                        continue
                    paths.append(path)
                    if path.is_dir() and not path.is_symlink():
                        pending.append(path)
        for path in paths:
            try:
                info = path.lstat()
            except FileNotFoundError:
                continue
            if stat.S_ISLNK(info.st_mode):
                raise ValueError("owned output symlink")
            key = (info.st_dev, info.st_ino)
            if key not in seen:
                total += info.st_blocks * 512
                seen.add(key)
    return total


def retain_owned_tmp(tmp):
    """After verified directwait, retain generated TMP bytes in issued cleanup storage."""
    if not tmp.exists():
        return None
    if not tmp.is_relative_to(ROOT) or tmp.is_symlink():
        raise ValueError("exact owned TMP retention")
    destination = owned(ROOT / "cleanup-v1" / tmp.relative_to(ROOT))
    if destination.exists():
        raise FileExistsError("prior retained TMP namespace must not be replaced")
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Same-filesystem atomic rename preserves every byte/inode; no cache credit.
    tmp.rename(destination)
    return str(destination)


def retained_raise(primary, errors):
    if primary is None and not errors:
        return
    first = primary if primary is not None else errors[0][1]
    first.retained_finalization_errors = tuple(errors)
    first.add_note("all finalization stages: " + repr([(stage, repr(e)) for stage, e in errors]))
    raise first


def verified_process_census(records, process):
    return bool(records) and all(
        x.get("direct_child_reaped") is True
        and x.get("cleanup_complete") is True
        and type(x.get("remaining")) is list
        and x["remaining"] == []
        and type(x.get("child")) is dict
        and set(x["child"]) == {"pid", "start_ticks", "boot_id"}
        and type(x["child"]["pid"]) is int
        and x["child"]["pid"] > 0
        and type(x["child"]["start_ticks"]) is str
        and x["child"]["start_ticks"].isdigit()
        and type(x["child"]["boot_id"]) is str
        and re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", x["child"]["boot_id"])
        and not process.alive(x["child"])
        for x in records
    )


def completed_partial_software(config, commands):
    """Bind actual five-test/release proof; do not replay identical successful tests."""
    prior = ROOT / "trained-partial-software-v5"
    required = {
        str(prior / name)
        for name in [
            "admission.json",
            "worker-runtime/STOP.json",
            "job-runtime/result.json",
            "worker-runtime/command-0.log",
            "worker-runtime/command-1.log",
        ]
    }
    refs = config["completed_partial_scope"]
    if type(refs) is not dict or set(refs) != required:
        raise ValueError("actual bounded partial software proof refs required")
    for path, identity in refs.items():
        identity_bytes(path, identity)
    before = json.loads((prior / "admission.json").read_text())
    stop = json.loads((prior / "worker-runtime/STOP.json").read_text())
    result = json.loads((prior / "job-runtime/result.json").read_text())
    if (
        result.get("job_id") != "8e1ddcab-4259-4a55-8a8d-d73a4137b979"
        or result.get("exit_code") != 1
        or result.get("direct_child_reaped") is not True
        or result.get("cleanup_complete") is not True
        or result.get("remaining") != []
        or stop.get("remaining") != []
        or len(stop.get("returned_processes", [])) != 3
    ):
        raise ValueError(
            "actual partial successful scope lacks failed controller/directwait provenance"
        )
    for row, command in zip(stop["returned_processes"], commands, strict=True):
        if (
            row.get("command") != ["/usr/bin/taskset", "-c", "2", *command]
            or row.get("exit_code") != 0
            or row.get("primary_error") is not None
            or row.get("direct_child_reaped") is not True
            or row.get("process_cleanup_complete") is not True
            or row.get("handle_closes_complete") is not True
            or row.get("remaining") != []
            or row.get("finalization_errors") != []
        ):
            raise ValueError("actual successful prefix command/wait/cleanup differs")
    for number, count in [(0, 3), (1, 2)]:
        if (
            f"test result: ok. {count} passed; 0 failed;"
            not in (prior / f"worker-runtime/command-{number}.log").read_text()
        ):
            raise ValueError("actual five Rust definitions missing")
    output_root = ROOT / "build-target-v1/release/examples"
    outputs = {
        str(output_root / name) for name in ["public-no-bypass-input", "public-no-bypass-cost"]
    }
    for path, reviewed in before["bindings"].items():
        if path == str(ROOT / "entry_guard.py") or path in outputs:
            continue  # Temporary control changes; explicit expected build outputs were wrongly frozen in v5.
        if path in config.get("routine_observer_repairs", {}):
            reviewed_current_identity(config, path, reviewed)
        elif config["bindings"].get(path) != reviewed:
            raise ValueError("qualified test source/dependency/compiler identity changed")
        else:
            identity_bytes(path, reviewed)


def completed_trained_software(config):
    """Reconcile actual controller/worker/compiler custody before new trained work."""
    directory = ROOT / "trained-partial-software-recovery-v6"
    path = directory / "qualified-software-STOP.json"
    supplied = config["current_trained_software"]
    if supplied["path"] != str(path):
        raise ValueError("exact current example/software receipt required")
    identity_bytes(path, supplied["identity"])
    actual = json.loads(path.read_text())
    if (
        actual.get("schema")
        != "quoridor.public-no-bypass.current-example-qualified-software-STOP.v6"
        or actual.get("issue") != "quoridor-4lc.353"
        or actual.get("job_id") != "d98c39f9-a735-40bf-a480-1c6175381bde"
        or actual.get("primary") is not None
        or actual.get("secondary") != []
        or actual.get("owned_remaining") != []
    ):
        raise ValueError("actual current software completion is incomplete/failed")
    for raw, expected in actual["raw_refs"].items():
        identity_bytes(raw, expected)
    result = json.loads((directory / "job-runtime/result.json").read_text())
    worker = json.loads((directory / "worker-runtime/STOP.json").read_text())
    job = json.loads((directory / "job-runtime/config.json").read_text())
    admission_path = directory / "admission.json"
    identity_bytes(admission_path, config["bindings"][str(admission_path)])
    admission = json.loads(admission_path.read_text())
    if (
        result.get("job_id") != actual["job_id"]
        or type(result.get("exit_code")) is not int
        or result["exit_code"] != 0
        or result.get("cleanup_complete") is not True
        or result.get("direct_child_reaped") is not True
        or result.get("remaining") != []
        or result.get("finished_at") != actual["controller_STOP"]
        or result.get("log_bytes_seen") != result.get("log_bytes_retained")
        or worker.get("STOP") != actual["worker_STOP"]
        or worker.get("primary") is not None
        or worker.get("secondary") != []
        or worker.get("remaining") != []
    ):
        raise ValueError("external/software worker completion differs")
    if job.get("argv") != [
        "/usr/bin/python3",
        "-B",
        str(ROOT / "entry_guard.py"),
        str(admission_path),
        "--sha256",
        config["bindings"][str(admission_path)]["SHA256"],
    ]:
        raise ValueError("actual external invocation does not bind software admission")
    returned = worker["returned_processes"]
    if len(returned) != 3 or len(admission["commands"]) != 3:
        raise ValueError("three actually affected software commands required")
    for row, command in zip(returned, admission["commands"], strict=True):
        expected = ["/usr/bin/taskset", "-c", "2", *command]
        if (
            row.get("command") != expected
            or type(row.get("exit_code")) is not int
            or row["exit_code"] != 0
            or row.get("status") != "complete"
            or any(
                row.get(k) is not True
                for k in (
                    "direct_child_reaped",
                    "process_cleanup_complete",
                    "handle_closes_complete",
                )
            )
            or row.get("remaining") != []
            or row.get("log_bytes_seen") != row.get("log_bytes_retained")
        ):
            raise ValueError("actual affected software return/capture/cleanup differs")
    # The current entry control has an additive receipt-consumption gate. Bind its
    # exact historical image separately; never pretend the compiler read this gate.
    before = config["software_guard_before"]
    identity_bytes(before["path"], before["identity"])
    historical = gzip.decompress(Path(before["path"]).read_bytes())
    source = actual["source_refs"]
    old_guard = source[str(ROOT / "entry_guard.py")]
    if (
        hashlib.sha256(historical).hexdigest() != old_guard["SHA256"]
        or len(historical) != old_guard["bytes"]
    ):
        raise ValueError("actual software entry beforeimage differs")
    for raw, expected in source.items():
        if raw != str(ROOT / "entry_guard.py"):
            identity_bytes(raw, expected)
    scoped = json.loads((directory / "worker-runtime/scoped-clippy/scoped-STOP.json").read_text())
    if (
        scoped.get("schema") != "quoridor.public-no-bypass.scoped-clippy.v2"
        or scoped.get("scoped_clear") is not True
        or scoped.get("overall_Cargo_outcome") != "SUCCESS0 full requested lib/bin/example targets"
        or len(scoped.get("requested_targets_complete", [])) != 3
        or scoped.get("no_lints_disabled") is not True
        or scoped.get("owned_remaining") != []
    ):
        raise ValueError("actual all-target scoped Clippy closure differs")
    images = actual["private2"]
    if set(images) != {"trained-native-v2", "whole-cost-v2"}:
        raise ValueError("current two compiler images missing")
    if worker.get("private_image") != [
        {k: images[name][k] for k in ("path", "SHA256", "bytes", "mode")}
        for name in ("trained-native-v2", "whole-cost-v2")
    ]:
        raise ValueError("worker and owner private custody differ")
    for name, row in images.items():
        if row["path"] != str(ROOT / "private-images-v1" / name):
            raise ValueError("current private namespace differs")
        identity_bytes(row["path"], row)
        identity_bytes(row["actual_compiler_artifact"], row["compiler_artifact"])
        if {k: row[k] for k in ("SHA256", "bytes", "mode")} != row["compiler_artifact"]:
            raise ValueError("current private/compiler correspondence differs")
    for field in ("controller_STOP", "collector_reader_STOP"):
        moment = datetime.datetime.fromisoformat(actual[field])
        if moment.tzinfo is None or moment > datetime.datetime.now(datetime.timezone.utc):
            raise ValueError("actual software STOP missing/invalid")
    fixed = json.loads(
        (ROOT / "trained-qualification-v1/trained-native-config-v1.json").read_text()
    )
    current = json.loads(
        (ROOT / "trained-qualification-v1/trained-native-config-v2.json").read_text()
    )
    fixed["native_image"] = images["trained-native-v2"]["path"]
    fixed["output"] = str(ROOT / "native-qualification-v1/trained-input-v2")
    if current != fixed:
        raise ValueError("trained qualification input scope changed beyond current image/output")


def completed_trained_numerical(config):
    """Consume actual fixed trained outputs and cleanup before native cost entry."""
    directory = ROOT / "trained-numerical-entry-v2"
    path = directory / "qualified-trained-STOP.corrected.json"
    supplied = config["current_trained_numerical"]
    if supplied["path"] != str(path):
        raise ValueError("exact stopped current trained qualification required")
    identity_bytes(path, supplied["identity"])
    actual = json.loads(path.read_text())
    if (
        actual.get("schema") != "quoridor.public-no-bypass.trained-qualified-STOP.v2"
        or actual.get("issue") != "quoridor-4lc.353"
        or actual.get("job_id") != "ad772fcb-bb29-4027-81bc-7254df7ef051"
        or actual.get("primary") is not None
        or actual.get("secondary") != []
        or actual.get("owned_remaining") != []
    ):
        raise ValueError("trained qualification incomplete/error")
    for raw, expected in actual["raw_refs"].items():
        identity_bytes(raw, expected)
    controller = json.loads((directory / "job-runtime/result.json").read_text())
    worker = json.loads((directory / "worker-runtime/STOP.json").read_text())
    output = ROOT / "native-qualification-v1/trained-input-v2"
    census = json.loads((output / "invocation-census.json").read_text())
    result = json.loads((output / "result.json").read_text())
    native = json.loads((output / "native.json").read_text())
    if (
        type(controller.get("exit_code")) is not int
        or controller["exit_code"] != 0
        or controller.get("cleanup_complete") is not True
        or controller.get("remaining") != []
        or worker.get("primary") is not None
        or worker.get("secondary") != []
        or worker.get("remaining") != []
        or len(worker["returned_processes"]) != 1
        or census.get("status") != "COMPLETE"
        or census.get("primary") is not None
        or census.get("secondary") != []
        or native.get("status") != "COMPLETE"
        or native.get("primary") is not None
        or native.get("secondary") != []
        or result.get("actual_head_D_Zero4_exact") is not True
        or result.get("parameters_scale_coefficient_unchanged") is not True
    ):
        raise ValueError("actual trained result/worker/controller domains differ")
    counts = {
        "Torch_attempted": 4,
        "Torch_returned": 4,
        "Torch_validated": 4,
        "Torch_rows_attempted": 16,
        "native_command_attempted": 1,
        "native_command_returned": 1,
        "optimizer_fit_game_Search": 0,
        "constructors_attempted": 2,
        "constructors_returned": 2,
        "trained_load_attempted": 2,
        "trained_load_returned": 2,
    }
    if any(
        value != counts or any(type(v) is not int for v in value.values())
        for value in (actual["counts"], census["counts"], result["counts"])
    ):
        raise ValueError("actual trained fixed count domains differ")
    if (
        native["successful_evaluations"],
        native["deliberate_rejected_evaluations"],
        native["deliberate_rejected_input_constructions"],
        native["legal_delta_undo_transitions"],
        native["Search_calls"],
    ) != (56, 4, 4, 16, 0):
        raise ValueError("actual native finite/error/delta-undo counts differ")
    for tag, sha in {
        "BEST": "046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841",
        "LAST": "73b9b3d5a28cb7349c80b9beacfcb1880dd480af6d2e656a1521bf01c77fad81",
    }.items():
        if (
            census["parameter_facts"][tag]["loaded_parameter_SHA256"] != sha
            or census["parameter_facts"][tag]["post_forward_bit_invariants"] is not True
        ):
            raise ValueError("current trained loaded parameter proof differs")
    for returned in [result["native_process"], *worker["returned_processes"]]:
        if (
            type(returned.get("exit_code")) is not int
            or returned["exit_code"] != 0
            or any(
                returned.get(k) is not True
                for k in (
                    "direct_child_reaped",
                    "handle_closes_complete",
                    "process_cleanup_complete",
                )
            )
            or returned.get("remaining") != []
        ):
            raise ValueError("actual trained native/Torch wait-cleanup missing")
    before = config["numeric_guard_before"]
    identity_bytes(before["path"], before["identity"])
    historical = gzip.decompress(Path(before["path"]).read_bytes())
    source = actual["source_refs"]
    old = source[str(ROOT / "entry_guard.py")]
    if hashlib.sha256(historical).hexdigest() != old["SHA256"] or len(historical) != old["bytes"]:
        raise ValueError("actual numerical entry beforeimage differs")
    for raw, expected in source.items():
        if raw != str(ROOT / "entry_guard.py"):
            identity_bytes(raw, expected)
    moment = datetime.datetime.fromisoformat(actual["collector_reader_STOP"])
    if moment.tzinfo is None or moment > datetime.datetime.now(datetime.timezone.utc):
        raise ValueError("actual trained collector STOP invalid")


def completed_cost_and_presentation(config):
    """Bind actual eight-call cost, private caller and human presentation before games."""
    directory = ROOT / "trained-cost-entry-v1"
    path = directory / "qualified-cost-STOP.json"
    expected = config["current_cost"]
    if expected["path"] != str(path):
        raise ValueError("exact eight-call cost receipt required")
    identity_bytes(path, expected["identity"])
    actual = json.loads(path.read_text())
    if (
        actual.get("schema") != "quoridor.public-no-bypass.fixed-eight-cost-qualified-STOP.v1"
        or actual.get("issue") != "quoridor-4lc.353"
        or actual.get("job_id") != "7781a252-586b-4dd4-8b79-c908a7c4e078"
        or actual.get("primary") is not None
        or actual.get("secondary") != []
        or actual.get("owned_remaining") != []
    ):
        raise ValueError("current cost incomplete/failed")
    for raw, expected in actual["raw_refs"].items():
        identity_bytes(raw, expected)
    before = config["cost_guard_before"]
    identity_bytes(before["path"], before["identity"])
    archived = gzip.decompress(Path(before["path"]).read_bytes())
    old = actual["source_refs"][str(ROOT / "entry_guard.py")]
    if hashlib.sha256(archived).hexdigest() != old["SHA256"] or len(archived) != old["bytes"]:
        raise ValueError("actual cost entry beforeimage differs")
    for raw, expected in actual["source_refs"].items():
        if raw != str(ROOT / "entry_guard.py"):
            identity_bytes(raw, expected)
    result = json.loads((directory / "job-runtime/result.json").read_text())
    worker = json.loads((directory / "worker-runtime/STOP.json").read_text())
    data = json.loads((ROOT / "native-qualification-v1/trained-cost-v1/cost.json").read_text())
    if (
        type(result.get("exit_code")) is not int
        or result["exit_code"] != 0
        or result.get("cleanup_complete") is not True
        or result.get("remaining") != []
        or worker.get("primary") is not None
        or worker.get("secondary") != []
        or worker.get("remaining") != []
        or len(worker["returned_processes"]) != 1
        or data.get("status") != "COMPLETE"
        or data.get("primary") is not None
        or data.get("secondary") != []
        or data.get("all_complete_finite_legal") is not True
        or any(
            type(data.get(k)) is not int or data[k] != 8
            for k in ("Search_calls", "Search_calls_returned", "Search_calls_validated")
        )
        or len(data.get("rows", [])) != 8
    ):
        raise ValueError("actual eight matching-depth complete cost calls required")
    caller = ROOT / "private-images-v1/direct16-runner-v1"
    caller_expected = config["bindings"][str(caller)]
    if caller_expected != {
        "SHA256": "634fb7036266965a8080b3384f6b79cce4d84c3977c3244a944b7600731a268e",
        "bytes": 8332144,
        "mode": "0755",
    }:
        raise ValueError("actual qualified current caller image differs")
    identity_bytes(caller, caller_expected)
    compiler = ROOT / "build-target-v1/release/quoridor-runner"
    identity_bytes(compiler, caller_expected)
    caller_proof = ROOT / "trained-software-clippy-v4/qualified-software-STOP.json"
    identity_bytes(
        caller_proof,
        {
            "SHA256": "5fe613fdeae8ff296eb698c21b2185bb808a9ccc75ae3907d5d91211602958d2",
            "bytes": 38269,
            "mode": "0644",
        },
    )
    caller_scope = json.loads(caller_proof.read_text())
    custody = caller_scope["private3"]["direct16-runner-v1"]
    if (
        custody["private"] != {"path": str(caller), **caller_expected}
        or custody["compiler_artifact"] != {"path": str(compiler), **caller_expected}
        or caller_scope["primary"] is not None
        or caller_scope["secondary"] != []
        or caller_scope["owned_remaining"] != []
    ):
        raise ValueError("actual current caller custody/software scope differs")
    for filename, expected in caller_scope["original_clock_source_SHA256"].items():
        current = WT / "crates/quoridor-runner/src" / filename
        if hashlib.sha256(current.read_bytes()).hexdigest() != expected:
            raise ValueError("compiled qualified clock/runtime source changed")
    # Presentation is a recorded human-visible fact, not file delivery or a fresh ACK.
    presentation = Path(
        "/workspaces/quoridor/.artifacts/research-acceptance/public-no-bypass-v1/fit-report-intake-v1/actual-Policy-presentation.json"
    )
    identity_bytes(
        presentation,
        {
            "SHA256": "4ba5590e35106d64660694c51e6eb084ebe6d055a1f86d15d05f8c3f458e20fe",
            "bytes": 1743,
            "mode": "0644",
        },
    )
    fixed = json.loads((ROOT / "arena-direct16-v1/cohort-specification.json").read_text())
    native_config = json.loads(
        (ROOT / "arena-direct16-entry-recovery-v2/arena-config.json").read_text()
    )
    if native_config != config["frozen_arena_config"]:
        raise ValueError("actual direct16 executable config differs")
    previous = json.loads((ROOT / "arena-direct16-entry-v1/arena-config.json").read_text())
    output = ROOT / "arena-development-v1/direct16-recovery-v2/run"
    previous["inference_cpu_core"] = None
    previous["output"] = str(output)
    if native_config != previous:
        raise ValueError("only unused external-core control/new exclusive output may change")
    if native_config["output"] != str(output) or output.exists():
        raise ValueError("new exclusive ONE-cohort output required; no stale/partial reuse")
    book_sha = hashlib.sha256(
        json.dumps(native_config["arena"]["book"], sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    if book_sha != fixed["book_canonical_sorted_compact_SHA256"]:
        raise ValueError("entire original book/provenance differs")
    if (
        native_config["games"] != 16
        or native_config["seed"] != 32710001
        or native_config["workers"] != 1
        or native_config["cpu_cores"] != [0]
        or native_config["max_plies"] != 200
        or native_config["ruleset"] != "standard_2p_threefold"
        or native_config["wall_seconds"] is not None
        or native_config["deadline_unix_ms"] != 0
        or native_config["inference"] is not None
    ):
        raise ValueError("frozen direct16 count/rules/clock/cpu scope differs")
    fingerprints = [row["fingerprint_SHA256"] for row in data["models"]]
    if native_config["arena"]["evaluator_sha256"] != fingerprints:
        raise ValueError("actual loaded evaluator/cost identities differ")
    alpha = WT / "crates/quoridor-ai/src/alphabeta.rs"
    source_sha = hashlib.sha256(alpha.read_bytes()).hexdigest()
    if native_config["arena"]["search_source_sha256"] != [source_sha, source_sha]:
        raise ValueError("shared compiled alpha source identity differs")
    for index, engine in enumerate(native_config["engines"]):
        if engine != {
            "kind": "nnue",
            "model": fixed["models"][index]["manifest"]["path"],
            "depth": 64,
            "max_nodes": 1000000,
            "time_ms": 100,
            "simd": False,
            "distance_a": 0.0,
            "distance_b": 0.0 if index == 0 else 8.0,
        }:
            raise ValueError("exact two model/clock/backend scopes differ")
    if any(
        native_config["arena"][k] != fixed[k]
        for k in (
            "comparison",
            "clock_policy",
            "return_reserve_ms",
            "tt_entries",
            "bootstrap_seed",
            "bootstrap_resamples",
        )
    ):
        raise ValueError("original authority/drain/TT/book statistics controls differ")


def supported_commands(config):
    """Freeze the actual maintained stage; no caller-selected extra work."""
    if config["stage"] == "software":
        plan_path = ROOT / "trained-partial-software-v5/compiler-source-plan.json"
        identity_bytes(plan_path, config["bindings"][str(plan_path)])
        plan = json.loads(plan_path.read_text())
        if (
            plan["schema"] != "quoridor.public-no-bypass.partial-example-software.v5"
            or len(plan["commands"]) != 5
        ):
            raise ValueError("exact five affected example/software commands")
        expected = plan["commands"][:-1] + [
            [
                "/usr/bin/python3",
                "-B",
                str(ROOT / "trained-software-clippy-v4/scoped_clippy.py"),
                str(ROOT / "trained-partial-software-recovery-v6/scoped-clippy-config.json"),
            ]
        ]
        completed_partial_software(config, plan["commands"][:3])
        expected = expected[
            2:
        ]  # Matching successful five tests reused; mechanically changed release required.

        if config["commands"] != expected or config["operational_seconds"] != 180:
            raise ValueError("exact new five observer tests/two examples/Clippy scope")
    elif config["stage"] == "numerical":
        expected = [
            [
                "/home/vscode/.cache/inference/envs/quoridor-training/bin/python",
                "-B",
                str(ROOT / "trained-qualification-v1/qualify_trained.py"),
                str(ROOT / "trained-qualification-v1/trained-native-config-v2.json"),
            ]
        ]
        if config["commands"] != expected:
            raise ValueError("ONE exact four new trained calls/16rows, no optimizer or fit")
        completed_trained_software(config)
    elif config["stage"] == "cost":
        expected = [
            [
                str(ROOT / "private-images-v1/whole-cost-v2"),
                str(ASSETS / "candidate-v1/output/best-model/manifest.json"),
                "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/trigger-patience-v1/patience1/output/best-model/manifest.json",
                str(ROOT / "head-input-prefixes-v1.json"),
                str(ROOT / "native-qualification-v1/trained-cost-v1/cost.json"),
            ]
        ]
        if config["commands"] != expected:
            raise ValueError("exact eight depth2 cost calls; no warmup/extra inputs")
        completed_trained_software(config)
        completed_trained_numerical(config)
    elif config["stage"] == "arena":
        expected = [
            [
                str(ROOT / "private-images-v1/direct16-runner-v1"),
                "arena",
                "--config",
                str(ROOT / "arena-direct16-entry-recovery-v2/arena-config.json"),
            ]
        ]
        if config["commands"] != expected:
            raise ValueError("ONE fixed direct16 cohort, no other native commands")
        completed_trained_software(config)
        completed_trained_numerical(config)
        completed_cost_and_presentation(config)
    else:
        raise ValueError("unsupported353 stage")


def run(admission, expected_SHA256):
    beginning = time.monotonic()
    with LOCK.open("a+b") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        admission = owned(admission)
        info = admission.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_size > 1048576:
            raise ValueError("bounded regular own immutable admission")
        data = admission.read_bytes()
        if hashlib.sha256(data).hexdigest() != expected_SHA256:
            raise ValueError("actual immutable admission SHA differs")
        config = json.loads(data)
        if hashlib.sha256(PROOF.read_bytes()).hexdigest() != PROOF_SHA:
            raise ValueError("issued353 inclusive proof")
        proof = json.loads(PROOF.read_text())
        if sum(proof["components_B"].values()) != 4294967296:
            raise ValueError("whole component arithmetic")
        if (
            type(config["family_RSS_upper_B"]) is not int
            or not 67108864
            < config["family_RSS_upper_B"]
            <= proof["future_fit_memory_family_upper_B"]
            or sum(x["upper_B"] for x in config["storage_components"]) > proof["new_whole_B"]
            or len({x["name"] for x in config["storage_components"]})
            != len(config["storage_components"])
        ):
            raise ValueError("issued family/whole distinct component support")
        if len(config["source_reviews"]) != 3 or {
            x["review_issue"] for x in config["source_reviews"]
        } != {"quoridor-4lc.353.1", "quoridor-4lc.353.2", "quoridor-4lc.353.3"}:
            raise ValueError("actual config/head-input/caller source scopes required")
        quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        if memory < config["family_RSS_upper_B"] + 4294967296:
            raise ValueError("fresh family plus4GiB host reserve")
        fs = os.statvfs(ROOT)
        if fs.f_bavail * fs.f_frsize < 4294967296:
            raise ValueError("fresh inclusive phase filesystem headroom")
        cores = config["worker_CPUs"] + [config["controller_CPU"]]
        if len(cores) != len(set(cores)) or not set(cores).issubset(os.sched_getaffinity(0)):
            raise ValueError("exact worker/controller affinity")
        physical = [
            tuple(
                (Path(f"/sys/devices/system/cpu/cpu{c}/topology") / n).read_text().strip()
                for n in ("physical_package_id", "core_id")
            )
            for c in cores
        ]
        if len(set(physical)) != len(physical):
            raise ValueError("distinct physical cores")
        # Large framework/compiler/input hashes only after actual quiet and
        # physical predicates, under the already acquired lifetime NB lease.
        supported_commands(config)
        for path, expected in config["bindings"].items():
            identity_bytes(path, expected)
        for path, target in config.get("symlink_bindings", {}).items():
            p = Path(path)
            if not p.is_symlink() or str(p.resolve(strict=True)) != target:
                raise ValueError("actual effective executable symlink differs")
        for receipt in config["source_reviews"]:
            review_clear(receipt)
        trained_boundary_clear(config)
        for component in config["storage_components"]:
            if (
                component["upper_B"] > proof["components_B"][component["name"]]
                or not 0 <= component.get("retained_floor_B", 0) <= component["upper_B"]
                or charged(component["roots"], component.get("excluded", ())) > component["upper_B"]
            ):
                raise ValueError("supported retained+future component: " + component["name"])
        directory = owned(config["runtime"])
        directory.mkdir()
        tmp = directory / "TMP"
        returned, primary, errors = [], None, []
        resources, process = None, None
        execution_attempted = False
        private_image = None
        retained_TMP_path = None
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        try:
            tmp.mkdir()
            for parent in config.get("prepare_owned_parents", []):
                owned(parent).mkdir(parents=True, exist_ok=True)
            os.environ.update(
                PYTHONPATH=str(WT / "python"),
                PYTHONDONTWRITEBYTECODE="1",
                TMPDIR=str(tmp),
                CUBLAS_WORKSPACE_CONFIG=":4096:8",
                RUSTC=str(TOOLCHAIN / "rustc"),
                RUSTDOC=str(TOOLCHAIN / "rustdoc"),
                RUSTUP_TOOLCHAIN="stable",
                RUSTUP_AUTO_INSTALL="0",
                CARGO_TARGET_DIR=str(ROOT / "build-target-v1"),
                CARGO_BUILD_JOBS="1",
                CARGO_NET_OFFLINE="true",
                CARGO_INCREMENTAL="0",
                CARGO_PROFILE_DEV_DEBUG="0",
                CARGO_PROFILE_DEV_OPT_LEVEL="0",
                CARGO_PROFILE_DEV_INCREMENTAL="false",
                UV_NO_SYNC="1",
                UV_OFFLINE="1",
            )
            if config["stage"] == "numerical":
                cache = owned(ROOT / "dependency-identity-v1/cuda-cache")
                cache.mkdir(parents=True, exist_ok=True)
                os.environ["CUDA_CACHE_PATH"] = str(cache)
            os.sched_setaffinity(0, {config["controller_CPU"]})
            sys.path.insert(0, str(WT / "python"))
            from quoridor_training import cycle_process as process

            deadline = (
                None
                if config["operational_seconds"] is None
                else time.monotonic() + config["operational_seconds"]
            )
            (directory / "START.json").write_text(
                json.dumps(
                    {
                        "control_START": start,
                        "stage": config["stage"],
                        "identity": process.identity(process.process_info(os.getpid())),
                        "physics": {"available_B": memory, "physical_cores": physical},
                        "config": config,
                        "actual_child_START": "pending first execute receipt",
                    },
                    indent=2,
                )
                + "\n"
            )

            class Resources(process.CycleResources):
                def __init__(self):
                    super().__init__(
                        {
                            "max_memory_bytes": config["family_RSS_upper_B"] - 67108864,
                            "host_ram_reserve": 4294967296,
                            "max_output_bytes": 4294967296,
                        },
                        ROOT,
                        deadline,
                    )
                    self.peak_sample_B = 0
                    self.component_max_B = {
                        item["name"]: item.get("retained_floor_B", 0)
                        for item in config["storage_components"]
                    }
                    self.device = process.DeviceMemory() if config["stage"] == "numerical" else None

                def check(self, owned=()):
                    super().check(owned)
                    infos = [
                        process.process_info(os.getpid()),
                        *(process.process_info(p["pid"]) for p in owned),
                    ]
                    rss = sum(i["rss"] for i in infos if i) + 67108864
                    self.peak_sample_B = max(self.peak_sample_B, rss)
                    if rss > config["family_RSS_upper_B"]:
                        raise RuntimeError("whole family with64MiB controller reserve")
                    for item in config["storage_components"]:
                        observed = charged(item["roots"], item.get("excluded", ()))
                        self.component_max_B[item["name"]] = max(
                            self.component_max_B[item["name"]], observed
                        )
                        if self.component_max_B[item["name"]] > item["upper_B"]:
                            raise RuntimeError(
                                "owned inclusive retained+future component: " + item["name"]
                            )
                    if (
                        self.device is not None
                        and self.device.used() > config["whole_device_VRAM_upper_B"]
                    ):
                        raise RuntimeError("whole physical device VRAM guard")

            resources = Resources()
            with process.cancellation_signals():
                for number, command in enumerate(config["commands"]):
                    argv = [
                        "/usr/bin/taskset",
                        "-c",
                        ",".join(map(str, config["worker_CPUs"])),
                        *command,
                    ]
                    execution_attempted = True
                    returned.append(
                        process.execute(
                            argv, directory / f"command-{number}.log", deadline, resources=resources
                        )
                    )
                if config["stage"] == "software":
                    scoped = json.loads((directory / "scoped-clippy/scoped-STOP.json").read_text())
                    if (
                        scoped.get("scoped_clear") is not True
                        or scoped.get("overall_Cargo_outcome")
                        != "SUCCESS0 full requested lib/bin/example targets"
                        or scoped.get("schema") != "quoridor.public-no-bypass.scoped-clippy.v2"
                        or len(scoped.get("requested_targets_complete", [])) != 3
                        or scoped.get("no_lints_disabled") is not True
                        or scoped.get("owned_remaining") != []
                    ):
                        raise ValueError("actual current scoped Clippy closure required")
                    for number, count in [(0, 3), (1, 2)]:
                        text = (
                            ROOT
                            / "trained-partial-software-v5/worker-runtime"
                            / f"command-{number}.log"
                        ).read_text()
                        if f"test result: ok. {count} passed; 0 failed;" not in text:
                            raise ValueError(
                                "five new actual observer/finalizer definitions not qualified"
                            )
                    expected_images = {
                        "trained-native-v2": "examples/public-no-bypass-input",
                        "whole-cost-v2": "examples/public-no-bypass-cost",
                    }
                    if config["private_images"] != expected_images:
                        raise ValueError("exact two changed compiler/private images")
                    artifacts = {
                        name: ROOT / "build-target-v1/release" / relative
                        for name, relative in expected_images.items()
                    }
                    infos = [path.lstat() for path in artifacts.values()]
                    if (
                        any(not stat.S_ISREG(info.st_mode) or info.st_size <= 0 for info in infos)
                        or sum(info.st_size for info in infos) > 2097152
                    ):
                        raise ValueError(
                            "two changed private images exceed prospective2MiB; no copy"
                        )
                    private_image = []
                    for name, artifact in artifacts.items():
                        private = owned(ROOT / "private-images-v1" / name)
                        with artifact.open("rb") as source, private.open("xb") as target:
                            if source.read(4) != b"\x7fELF":
                                raise ValueError("actual compiled ELF required")
                            source.seek(0)
                            shutil.copyfileobj(source, target, 65536)
                            target.flush()
                            os.fsync(target.fileno())
                        private.chmod(0o755)
                        record = {
                            "path": str(private),
                            "SHA256": hashlib.sha256(private.read_bytes()).hexdigest(),
                            "bytes": private.stat().st_size,
                            "mode": "0755",
                        }
                        private_image.append(record)
                        if record["SHA256"] != hashlib.sha256(artifact.read_bytes()).hexdigest():
                            raise ValueError("private compiler artifact correspondence")
                        resources.check()
                    resources.check()
        except BaseException as error:
            primary = error
        finally:
            records = list(returned)
            try:
                paths = list(directory.glob("*.process.json"))
            except BaseException as error:
                paths = []
                errors.append(("raw_census_paths", error))
            for path in paths:
                try:
                    raw = json.loads(path.read_text())
                    if type(raw) is not dict:
                        raise ValueError("malformed raw process receipt")
                    if not any(x.get("child") == raw.get("child") for x in records):
                        records.append(raw)
                except BaseException as error:
                    errors.append(("raw_census", error))
            empty = not execution_attempted
            if execution_attempted:
                try:
                    empty = process is not None and verified_process_census(records, process)
                except BaseException as error:
                    empty = False
                    errors.append(("owned_census", error))
            if any(
                stage in ("raw_census", "raw_census_paths", "owned_census") for stage, _ in errors
            ):
                empty = False
            for path, expected in config["bindings"].items():
                try:
                    identity_bytes(path, expected)
                except BaseException as error:
                    errors.append(("source_input_after", error))
            for path, target in config.get("symlink_bindings", {}).items():
                try:
                    p = Path(path)
                    if not p.is_symlink() or str(p.resolve(strict=True)) != target:
                        raise ValueError("effective executable symlink changed")
                except BaseException as error:
                    errors.append(("executable_symlink_after", error))
            if empty:
                try:
                    retained_TMP_path = retain_owned_tmp(tmp)
                except BaseException as error:
                    errors.append(("owned_TMP", error))
            else:
                errors.append(
                    ("owned_census_UNKNOWN", RuntimeError("unverified remaining; TMP retained"))
                )
            stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
            receipt = {
                "control_START": start,
                "STOP": stop,
                "stage": config["stage"],
                "whole_controller_seconds": time.monotonic() - beginning,
                "returned_processes": returned,
                "retained_raw_process_receipts": records,
                "execution_attempted": execution_attempted,
                "primary": None
                if primary is None
                else {"type": type(primary).__name__, "message": str(primary)},
                "secondary": [
                    {"stage": stage, "type": type(e).__name__, "message": str(e)}
                    for stage, e in errors
                ],
                "remaining": [] if empty else None,
                "TMP_retained": tmp.exists(),
                "retained_TMP_artifact": retained_TMP_path,
                "private_image": private_image,
                "sample_family_RSS_including64MiB_B": None
                if resources is None
                else resources.peak_sample_B,
                "sample_component_maxima_B": None
                if resources is None
                else resources.component_max_B,
                "continuous_peak": "UNKNOWN",
                "old_fees_RAW_masks_UNKNOWN": "held",
                "nested_spans_not_added": True,
            }
            try:
                (directory / "STOP.json").write_text(json.dumps(receipt, indent=2) + "\n")
            except BaseException as error:
                errors.append(("STOP_publication", error))
        retained_raise(primary, errors)
        print(
            json.dumps(
                {"control_START": start, "STOP": stop, "receipt": str(directory / "STOP.json")}
            )
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("admission", type=Path)
    parser.add_argument("--sha256", required=True)
    args = parser.parse_args()
    run(args.admission, args.sha256)
