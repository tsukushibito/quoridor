"""Freeze ONE direct353 cohort using the qualified caller and saved model/cost facts."""

import datetime
import difflib
import fcntl
import gzip
import importlib.util
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(
    "/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1"
)
HERE = ROOT / "arena-direct16-entry-recovery-v2"
COST = ROOT / "trained-cost-entry-v1"


def main():
    with Path(
        "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
    ).open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        affinity = os.sched_getaffinity(0)
        if not {0, 2, 3}.issubset(affinity):
            raise ValueError("current native/controller/source affinity")
        os.sched_setaffinity(0, {3})
        spec = importlib.util.spec_from_file_location("entry353", ROOT / "entry_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        guard.quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        if memory < 6 * 1024**3:
            raise ValueError("actual family2GiB+host4GiB memory")
        physical = [
            tuple(
                Path(f"/sys/devices/system/cpu/cpu{c}/topology/{n}").read_text().strip()
                for n in ("physical_package_id", "core_id")
            )
            for c in (0, 2)
        ]
        if len(set(physical)) != 2:
            raise ValueError("worker/controller distinct physical cores")
        fs = os.statvfs(ROOT)
        free = fs.f_bavail * fs.f_frsize
        if free < 4 * 1024**3:
            raise ValueError("new whole phase filesystem headroom")
        # Reuse one frozen task preparation metadata helper, not another trainer.
        spec = importlib.util.spec_from_file_location(
            "cost_preparation", COST / "prepare_admission.py"
        )
        metadata = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(metadata)
        identity = metadata.identity
        config = json.loads((COST / "admission.json").read_text())
        qualified = json.loads((COST / "qualified-cost-STOP.json").read_text())
        arena = json.loads((HERE / "arena-config.json").read_text())
        config["stage"] = "arena"
        config["commands"] = [
            [
                str(ROOT / "private-images-v1/direct16-runner-v1"),
                "arena",
                "--config",
                str(HERE / "arena-config.json"),
            ]
        ]
        config["operational_seconds"] = None
        config["runtime"] = str(HERE / "worker-runtime")
        config["prepare_owned_parents"] = [str(ROOT / "arena-development-v1/direct16-recovery-v2")]
        config["current_cost"] = {
            "path": str(COST / "qualified-cost-STOP.json"),
            "identity": identity(COST / "qualified-cost-STOP.json"),
        }
        config["cost_guard_before"] = {
            "path": str(ROOT / "arena-direct16-entry-v1/entry_guard.before.py.gz"),
            "identity": identity(ROOT / "arena-direct16-entry-v1/entry_guard.before.py.gz"),
        }
        config["frozen_arena_config"] = arena
        config["planned_counts"] = {
            "scheduled_games": 16,
            "full_history_families": 8,
            "colour_pairs": 8,
            "max_plies_each": 200,
            "clock_ms_both": 100,
            "configured_reserve_ms": 5,
            "Torch_fit_teacher_extra_cohorts": 0,
        }
        bindings = config["bindings"]
        bindings[str(ROOT / "entry_guard.py")] = identity(ROOT / "entry_guard.py")
        named = [
            COST / "qualified-cost-STOP.json",
            HERE / "entry_guard.before.py.gz",
            HERE / "arena-config.json",
            ROOT / "arena-direct16-v1/cohort-specification.json",
            ROOT / "trained-software-clippy-v4/qualified-software-STOP.json",
            Path(
                "/workspaces/quoridor/.artifacts/research-acceptance/public-no-bypass-v1/fit-report-intake-v1/actual-Policy-presentation.json"
            ),
        ]
        named.extend(Path(p) for p in qualified["raw_refs"])
        fixed = json.loads((ROOT / "arena-direct16-v1/cohort-specification.json").read_text())
        for row in (
            fixed["entire_historical_book_ref"],
            fixed["route"],
            fixed["actual_Policy_presentation_binding"],
        ):
            guard.identity_bytes(row["path"], row)
            named.append(Path(row["path"]))
        for path in named:
            bindings[str(path)] = identity(path)
        observations = []
        for item in config["storage_components"]:
            observed = guard.charged(item["roots"], item.get("excluded", ()))
            held = max(
                observed,
                item["retained_floor_B"],
                qualified["sample_positive_component_maxima_B"][item["name"]],
            )
            forward = {"controls": 8388608, "arena_development": 234881024, "TMP": 67108864}.get(
                item["name"], 0
            )
            if held + forward > item["upper_B"]:
                raise ValueError("contained prospective whole component gap: " + item["name"])
            item["retained_floor_B"] = held
            if item["name"] == "TMP":
                item["roots"].append(str(HERE / "worker-runtime/TMP"))
            observations.append(
                {
                    "name": item["name"],
                    "sample_B": observed,
                    "held_floor_B": held,
                    "new_forward_B": forward,
                    "upper_B": item["upper_B"],
                }
            )
        config["preparation_physics"] = {
            "MemAvailable_B": memory,
            "filesystem_free_B": free,
            "CPU0_CPU2_physical": physical,
            "namedquiet": [],
        }
        config["actual_latest_model_fit0"] = (
            "ONE candidate/BEST51 direct16 cohort only, fit already completed unchanged"
        )
        config["scientific_wall_horizon"] = None
        for path, expected in bindings.items():
            guard.identity_bytes(path, expected)
        guard.supported_commands(config)
        guard.trained_boundary_clear(config)
        for review in config["source_reviews"]:
            guard.review_clear(review)
        for path in [HERE / "worker-runtime", HERE / "job-runtime", Path(arena["output"])]:
            if path.exists():
                raise FileExistsError("exclusive runtime/output already exists: " + str(path))

        def write(name, obj):
            with (HERE / name).open("x") as stream:
                stream.write(json.dumps(obj, indent=2) + "\n")

        write(
            "retained-and-forward-ledger.json",
            {
                "pre_entry_UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "components": observations,
                "whole_upper_B": sum(x["upper_B"] for x in config["storage_components"]),
                "old_positive_RAW_fee_TMP_mask_UNKNOWN": "HELD no refunds",
            },
        )
        write("admission.json", config)
        formatter = "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier"
        subprocess.run(
            [formatter, "--ignore-path", "/dev/null", "--write", str(HERE / "admission.json")],
            check=True,
        )
        job = {
            "issue": "quoridor-4lc.353",
            "goal_issue": "quoridor-4lc",
            "thread_id": "01a1100f-6d45-78e0-8a87-84503ff0fbf6",
            "cwd": "/workspaces/quoridor/.worktree/learning-million",
            "argv": [
                "/usr/bin/python3",
                "-B",
                str(ROOT / "entry_guard.py"),
                str(HERE / "admission.json"),
                "--sha256",
                identity(HERE / "admission.json")["SHA256"],
            ],
            "end_at": None,
            "notify_until": None,
            "max_runtime_seconds": None,
            "control_interval_seconds": 30,
            "notify_interval_seconds": 10,
            "request_timeout_seconds": 25,
            "log_max_bytes": 1048576,
            "resource_contract": str(guard.PROOF),
        }
        write("job-config.json", job)
        subprocess.run(
            [
                formatter,
                "--ignore-path",
                "/dev/null",
                "--check",
                str(HERE / "admission.json"),
                str(HERE / "job-config.json"),
                str(HERE / "arena-config.json"),
            ],
            check=True,
        )
        before = gzip.decompress((HERE / "entry_guard.before.py.gz").read_bytes()).decode()
        after = (ROOT / "entry_guard.py").read_text()
        with (HERE / "control-only.patch").open("x") as stream:
            stream.write(
                "".join(
                    difflib.unified_diff(
                        before.splitlines(True),
                        after.splitlines(True),
                        fromfile="a/entry_guard.py",
                        tofile="b/entry_guard.py",
                    )
                )
            )
        stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(
            "prepared-source-STOP.json",
            {
                "schema": "quoridor.public-no-bypass.direct16.prepared.v1",
                "READY": True,
                "actual_START": None,
                "reservation": "NONE",
                "source_writer_reader_STOP": stop,
                "bindings": bindings,
                "admission": identity(HERE / "admission.json"),
                "job_config": identity(HERE / "job-config.json"),
                "actual_arena_config": identity(HERE / "arena-config.json"),
                "original_book_SHA256": fixed["book_canonical_sorted_compact_SHA256"],
                "actual_qualified_cost": config["current_cost"],
                "actual_Policy_presentation": identity(named[5]),
                "fixed_counts": config["planned_counts"],
                "physics": config["preparation_physics"],
                "owned_readers_children_jobs_TMP": [],
                "continuous_peak": "UNKNOWN",
                "permission_context": config["actual_permission_context"],
            },
        )
        print(
            json.dumps(
                {"READY": True, "STOP": stop, "admission": identity(HERE / "admission.json")}
            )
        )


if __name__ == "__main__":
    main()
