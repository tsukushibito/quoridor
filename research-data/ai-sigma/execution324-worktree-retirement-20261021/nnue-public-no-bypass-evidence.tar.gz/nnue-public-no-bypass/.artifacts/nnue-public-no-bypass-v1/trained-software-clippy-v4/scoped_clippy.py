"""Complete lib/bin/example Clippy; fail closed except two exact foreign warnings.

Normal warning severity lets downstream targets finish. The external predicate
enforces warnings-as-errors everywhere except two prebound immutable diagnostics.
Historical failed Cargo101 and the insufficient v3 classifier remain evidence.
"""

import datetime
import hashlib
import json
from pathlib import Path
import stat
import sys
import time

from quoridor_training import cycle_process as process


EXPECTED_SOURCES = {
    "clippy::cmp_owned": "crates/quoridor-runner/src/teacher_pilot/depth6.rs",
    "clippy::large_enum_variant": "crates/quoridor-runner/src/teacher_pilot_execution/depth6.rs",
}
EXPECTED_TARGETS = {
    ("quoridor_runner", ("lib",)): "crates/quoridor-runner/src/lib.rs",
    ("quoridor-runner", ("bin",)): "crates/quoridor-runner/src/main.rs",
    (
        "public-no-bypass-cost",
        ("example",),
    ): "crates/quoridor-runner/examples/public-no-bypass-cost.rs",
}


def validate_contract(config):
    allowed = config["allowed_diagnostics"]
    if type(allowed) is not list or len(allowed) != 2:
        raise ValueError("exact two foreign signatures only")
    root = Path(config["WT"])
    seen = set()
    for item in allowed:
        code, span = item["code"], item["primary_span"]
        if code in seen or EXPECTED_SOURCES.get(code) != span["file_name"]:
            raise ValueError("extra exception/path alias/code")
        seen.add(code)
        path = root / span["file_name"]
        info = path.lstat()
        actual = {
            "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": info.st_size,
            "mode": f"{stat.S_IMODE(info.st_mode):04o}",
        }
        if not stat.S_ISREG(info.st_mode) or actual != item["source_identity"]:
            raise ValueError("actual foreign source hash/size/mode drift")
    return allowed


def classify(lines, exit_code, allowed, root):
    seen, diagnostics, finished, targets = [], [], [], set()
    for line in lines:
        if not line.strip():
            continue
        if not line.startswith("{"):
            text = line.strip()
            if text.startswith(("Checking ", "Compiling ", "Finished ")):
                continue
            if text in {
                "warning: `quoridor-runner` (lib) generated 2 warnings",
                "warning: `quoridor-runner` (lib) generated 2 warnings (run `cargo clippy --fix --lib -p quoridor-runner -- ` to apply 1 suggestion)",
            }:
                continue  # Cargo summary; exact two structured warnings still required below.
            raise ValueError("unexpected/partial/non-JSON Cargo diagnostic: " + text)
        value = json.loads(line)
        reason = value.get("reason")
        if reason == "compiler-message":
            message = value["message"]
            primary = [span for span in message["spans"] if span["is_primary"]]
            if message["level"] != "warning" or len(primary) != 1:
                raise ValueError("any compiler error/unknown severity/primary refuses")
            code = message["code"]["code"]
            matches = [x for x in allowed if x["code"] == code and x["primary_span"] == primary[0]]
            if len(matches) != 1:
                raise ValueError("warning code/path/full primary span not prebound")
            seen.append(code)
            diagnostics.append(message)
        elif reason == "build-finished":
            success = value.get("success")
            if type(success) is not bool or success is not True:
                raise ValueError("literal boolean true build-finished required")
            finished.append(success)
        elif reason == "compiler-artifact":
            target = value["target"]
            key = (target["name"], tuple(target["kind"]))
            if key in EXPECTED_TARGETS:
                if target["src_path"] != str(root / EXPECTED_TARGETS[key]):
                    raise ValueError("requested target path mismatch")
                targets.add(key)
        elif reason != "build-script-executed":
            raise ValueError("unknown Cargo message domain")
    if (
        exit_code != 0
        or len(seen) != 2
        or set(seen) != set(EXPECTED_SOURCES)
        or finished != [True]
        or targets != set(EXPECTED_TARGETS)
    ):
        raise ValueError(
            "successful complete lib/bin/example target and diagnostic census required"
        )
    return diagnostics


def run(config_path):
    config = json.loads(Path(config_path).read_text())
    root = Path(config["WT"])
    allowed = validate_contract(config)
    plan = json.loads(Path(config["source_plan"]).read_text())
    argv = list(plan["commands"][-1])
    if argv[-2:] != ["--", "-Dwarnings"]:
        raise ValueError("original strict Clippy command identity changed")
    argv = argv[:-2]
    argv.insert(argv.index("--no-deps"), "--message-format=json")
    directory = Path(config["runtime"])
    directory.mkdir()
    record = process.execute(argv, directory / "cargo.log", time.monotonic() + 150)
    if (
        record.get("direct_child_reaped") is not True
        or record.get("process_cleanup_complete") is not True
        or record.get("handle_closes_complete") is not True
        or record.get("remaining") != []
        or record.get("finalization_errors") != []
        or record.get("log_bytes_seen") != record.get("log_bytes_retained")
        or record["log_bytes_seen"] > 8388608
    ):
        raise ValueError("exact full successful Cargo wait/capture/cleanup required")
    diagnostics = classify(
        (directory / "cargo.log").read_text().splitlines(), record["exit_code"], allowed, root
    )
    validate_contract(config)
    receipt = {
        "schema": "quoridor.public-no-bypass.scoped-clippy.v2",
        "scope": "353 changed source; actual complete lib/bin/costexample check, exact two foreign warnings excluded",
        "scoped_clear": True,
        "overall_Cargo_outcome": "SUCCESS0 full requested lib/bin/example targets",
        "ordinary_whole_warnings_as_errors": "FAILED on immutable unrelated warnings; old101 preserved",
        "no_lints_disabled": True,
        "external_warning_refusal": "all except exact2 full structured primary-span/source identities",
        "diagnostics": diagnostics,
        "allowed_diagnostics": allowed,
        "requested_targets_complete": [list(key) for key in sorted(EXPECTED_TARGETS)],
        "process": record,
        "STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "owned_remaining": [],
    }
    (directory / "scoped-STOP.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(
        json.dumps(
            {
                "scoped_clear": True,
                "all3_targets_complete": True,
                "receipt": str(directory / "scoped-STOP.json"),
            }
        )
    )


if __name__ == "__main__":
    run(sys.argv[1])
