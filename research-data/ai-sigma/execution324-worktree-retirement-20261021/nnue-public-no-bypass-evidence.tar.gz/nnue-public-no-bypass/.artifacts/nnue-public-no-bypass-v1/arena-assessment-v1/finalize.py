"""Freeze the bounded existing353 interpretation handoff and display delta."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
PROOF = Path("/workspaces/quoridor/research-data/ai-sigma/public-no-bypass-v1/resources-v1.json")
POLICY = Path(
    "/workspaces/quoridor/.artifacts/research-acceptance/public-no-bypass-v1/fit-report-intake-v1/actual-Policy-presentation.json"
)
CLOCK = Path(
    "/workspaces/quoridor/.artifacts/nnue-public-no-bypass-review353-v1/clock-related-v2/control.json"
)


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def identity(path):
    info = path.stat()
    return {
        "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": info.st_size,
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


def main():
    with LOCK.open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        spec = importlib.util.spec_from_file_location("owned_saved_assessor", HERE / "assess.py")
        admin = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(admin)
        admin.quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        if memory < 536870912 + 4294967296:
            raise RuntimeError("family+host RAM")
        if os.statvfs(HERE).f_bavail * os.statvfs(HERE).f_frsize < 4294967296:
            raise RuntimeError("whole filesystem support")
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
        if (
            identity(PROOF)["SHA256"]
            != "c810e5e09a14d21719db086af22f7bdb9bb4adbbf1cb18e9ea479b86d394a534"
        ):
            raise RuntimeError("issued whole support drift")
        selected = [
            HERE / x
            for x in (
                "report.md",
                "verified-summary.json",
                "authority-clock.csv",
                "known-controller-fees.json",
                "review-question.md",
                "report-input-binding.json",
                "report-collection-STOP.json",
                "collection-domain-note.json",
                "assess.py",
                "freeze_report.py",
                "forecast.json",
            )
        ] + [
            ROOT / "fit-results-v1/fit-report.md",
            ROOT / "fit-results-v1/fit-report-source-STOP.json",
            ROOT / "fit-results-v1/verified-fit-STOP.json",
            ROOT / "curves-render-v1/same-V-table.csv",
            ROOT / "trained-partial-software-recovery-v6/qualified-software-STOP.json",
            ROOT / "trained-software-clippy-v4/qualified-software-STOP.json",
            ROOT / "trained-numerical-entry-v2/qualified-trained-STOP.corrected.json",
            ROOT / "trained-cost-entry-v1/qualified-cost-STOP.json",
            ROOT / "arena-direct16-entry-recovery-v2/process-release-STOP.json",
            ROOT / "arena-development-v1/direct16-recovery-v2/run/config.json",
            ROOT / "arena-development-v1/direct16-recovery-v2/run/planned.json",
            ROOT / "arena-development-v1/direct16-recovery-v2/run/manifest-start.json",
            POLICY,
            CLOCK,
            PROOF,
        ]
        refs = {str(p): identity(p) for p in selected}
        total = sum(x["bytes"] for x in refs.values())
        if total > 1048576:
            raise RuntimeError("selected compact review input1MiB unsupported")
        # Readonly old maps/result/raw retain their own hashes; no PT/ELF/framework/corpus read.
        for path, expected in json.loads((HERE / "forecast.json").read_bytes())[
            "exact_named_input_refs"
        ].items():
            if identity(Path(path)) != expected:
                raise RuntimeError("durable artifact drift")
        allocated = (
            sum(p.stat().st_blocks * 512 for p in HERE.iterdir() if p.is_file())
            + HERE.stat().st_blocks * 512
        )
        if allocated + 131072 > 2097152:
            raise RuntimeError("inclusive2MiB saved phase unsupported")
        fields = {
            "stage": (
                "353 completed one fit and direct16; stopped bounded interpretation review handoff ready",
                "353の1回の学習と16対局が完了。停止済みの限定解釈レビューを引き渡し可能",
            ),
            "next_action": (
                "324 assigns existing independent interpretation reviewer for fixed report; then accept limited result and one Policy handoff, no numerical replay",
                "324が固定報告の独立解釈レビューを既存担当へ割り当てる。限定結果の受入れとPolicyへの1回の引渡しへ進む。数値再実行なし",
            ),
            "wait_reason": (
                "No active compute/reader lease; consequential interpretation acceptance pending. Human curve/table presentation already satisfied; no reply-only approval or N gate",
                "実行中の計算や読み手リースなし。重要な解釈の受入れが未完了。人間への曲線・表提示は完了済み。返答だけの承認待ちやN選択待ちはなし",
            ),
        }
        dashboard = {
            "stage": fields["stage"][0],
            "wait_kind": "review",
            "next_action": fields["next_action"][0],
            "wait_reason": fields["wait_reason"][0],
            "runtime_dirs": [],
            "evidence_paths": [
                str(HERE / "report.md"),
                str(HERE / "verified-summary.json"),
                str(HERE / "authority-clock.csv"),
                str(HERE / "known-controller-fees.json"),
                str(HERE / "stopped-target.json"),
                str(POLICY),
            ],
        }
        (HERE / "dashboard.json").write_text(json.dumps({"dashboard": dashboard}, indent=2) + "\n")
        display = {
            "issue": "quoridor-4lc.353",
            "fields": {
                k: {
                    "English": en,
                    "English_UTF8_SHA256": hashlib.sha256(en.encode()).hexdigest(),
                    "Japanese": ja,
                    "Japanese_UTF8_SHA256": hashlib.sha256(ja.encode()).hexdigest(),
                }
                for k, (en, ja) in fields.items()
            },
        }
        (HERE / "display-ja.json").write_text(
            json.dumps(display, ensure_ascii=False, indent=2) + "\n"
        )
        for p in selected:
            if identity(p) != refs[str(p)]:
                raise RuntimeError("selected source after changed")
        stop = stamp()
        target = {
            "schema": "quoridor.public-no-bypass.completed-interpretation-target.v1",
            "issue": "quoridor-4lc.353",
            "review_question": str(HERE / "review-question.md"),
            "actual_source_reader_writer_STOP": stop,
            "owned_readers_children_jobs_TMP_remaining": [],
            "current_next_Cargo_model_native_Search_fair_reservation": "NONE",
            "selected_refs": refs,
            "selected_unique_B": total,
            "selected_input_upper_B": 1048576,
            "source_control_report_failure_admin_upper_B": 2097152,
            "phase_allocated_before_final_target_B": allocated,
            "last_target_notice_admin_forward_upper_B": 131072,
            "issued_whole_resource_ref": str(PROOF),
            "resource_SHA256": refs[str(PROOF)]["SHA256"],
            "proposed_related_review_output_admin_upper_B": 1048576,
            "review_support": "inside existing128MiB, old10MiB held;324 makes concrete assignment before reviewer growth, new globalgrant0",
            "source_qualification_replay": False,
            "new_model_Search_forward_fit_games": 0,
            "interpretation_acceptance": "PENDING independent consequential scope review through324",
            "permissions": {
                "verified_actual_turn_context_UTC": "2026-10-09T21:42:09.303Z",
                "sandbox": "danger-full-access",
                "approval_policy": "never",
                "cwd": "/workspaces/quoridor/.worktree/learning-million",
                "model": "gpt-6.1-sol",
                "effort": "high",
                "session_ref": "/home/vscode/.codex/sessions/2026/10/06/rollout-2026-10-06T07-13-28-01a1100f-6d45-78e0-8a87-84503ff0fbf6.jsonl",
                "procedure_note": "Initial pwd-only command preceded refreshed turn_context read; carried prior21:35 verified fact in summary. Latest context explicitly checked before source/report writes and data reads; no permission mismatch. This ordering gap is retained rather than claiming before-every-command verification.",
            },
            "known_limits": [
                "Stdout490165B prefix absent; full durable named result/manifest/journals checked.",
                "Two book serialization hashes same actual object; all manifest f32 decimal differences exact bits.",
                "Earlier preparation825768KiB ru_maxrss domain gap retained; current final selfVmHWM/family samples separate/continuousUNKNOWN.",
                "All old failures fees RAW masks positivefloors/TMP held, no refund/default/N/seal/323pause change.",
            ],
        }
        (HERE / "stopped-target.json").write_text(json.dumps(target, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "target": str(HERE / "stopped-target.json"),
                    "identity": identity(HERE / "stopped-target.json"),
                    "report": identity(HERE / "report.md"),
                    "selected_refs": len(refs),
                    "selected_unique_B": total,
                    "actual_source_reader_writer_STOP": stop,
                    "allocated_B": allocated,
                    "remaining": [],
                }
            )
        )


if __name__ == "__main__":
    main()
