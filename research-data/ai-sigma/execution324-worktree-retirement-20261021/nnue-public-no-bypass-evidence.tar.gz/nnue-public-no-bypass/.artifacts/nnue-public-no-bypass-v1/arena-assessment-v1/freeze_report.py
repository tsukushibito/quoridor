"""Freeze one stopped report from already qualified named saved evidence."""

import csv
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
RUN = ROOT / "arena-development-v1/direct16-recovery-v2/run"
JOBS = [
    "software-entry-v1",
    "numerical-entry-v1",
    "numerical-entry-recovery-v2",
    "fit-entry-v1",
    "trained-software-entry-v1",
    "trained-software-recovery-v2",
    "trained-software-clippy-v3",
    "trained-software-clippy-v4",
    "trained-partial-software-v5",
    "trained-partial-software-recovery-v6",
    "trained-numerical-entry-v2",
    "trained-cost-entry-v1",
    "arena-direct16-entry-v1",
    "arena-direct16-entry-recovery-v2",
]
PROVENANCE = [
    ROOT / "fit-results-v1/fit-report.md",
    ROOT / "fit-results-v1/fit-report-source-STOP.json",
    ROOT / "fit-results-v1/verified-fit-STOP.json",
    ROOT / "curves-render-v1/same-V-table.csv",
    ROOT / "trained-partial-software-recovery-v6/qualified-software-STOP.json",
    ROOT / "trained-numerical-entry-v2/qualified-trained-STOP.corrected.json",
    ROOT / "trained-cost-entry-v1/qualified-cost-STOP.json",
    ROOT / "native-qualification-v1/trained-cost-v1/cost.json",
    ROOT / "arena-direct16-entry-recovery-v2/process-release-STOP.json",
    ROOT / "arena-direct16-entry-recovery-v2/retained-and-forward-ledger.json",
    Path(
        "/workspaces/quoridor/.artifacts/research-acceptance/public-no-bypass-v1/fit-report-intake-v1/actual-Policy-presentation.json"
    ),
]


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def identity(path):
    info = path.stat()
    return {
        "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": info.st_size,
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def main():
    with LOCK.open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # Only the already source-bound administrative quiet predicate is used.
        spec = importlib.util.spec_from_file_location("owned_saved_assessor", HERE / "assess.py")
        admin = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(admin)
        admin.quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        require(memory >= 536870912 + 4294967296, "RAM family+host")
        require(os.statvfs(HERE).f_bavail * os.statvfs(HERE).f_frsize >= 4294967296, "whole FS")
        os.sched_setaffinity(0, {3})
        physical = {
            str(c): [
                (Path(f"/sys/devices/system/cpu/cpu{c}/topology") / n).read_text().strip()
                for n in ("physical_package_id", "core_id")
            ]
            for c in (3, 4)
        }
        require(physical["3"] != physical["4"], "distinct physical cores")
        resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
        before = stamp()
        forecast = json.loads((HERE / "forecast.json").read_bytes())
        named = (
            [Path(x) for x in forecast["exact_named_input_refs"]]
            + PROVENANCE
            + [ROOT / x / "job-runtime/result.json" for x in JOBS]
            + [HERE / "verified-summary.json", HERE / "assess.py", Path(__file__)]
        )
        # Prospective named selected addition stays inside8MiB input and2MiB output forecast.
        require(sum(p.stat().st_size for p in named) <= 8388608, "selected input upper")
        refs = {str(p): identity(p) for p in named}
        (HERE / "report-input-binding.json").write_text(
            json.dumps(
                {
                    "before_growth_UTC": before,
                    "inputs": refs,
                    "input_unique_B": sum(x["bytes"] for x in refs.values()),
                    "input_upper_B": 8388608,
                    "output_inclusive_upper_B": 2097152,
                    "issued_component": "controls128MiB/whole4GiBc810",
                    "new_global_grant_B": 0,
                },
                indent=2,
            )
            + "\n"
        )
        for raw, expected in forecast["exact_named_input_refs"].items():
            require(refs[raw] == expected, "frozen raw input drift")
        summary = json.loads((HERE / "verified-summary.json").read_bytes())
        raw = json.loads((RUN / "result.json").read_bytes())
        costs = []
        ids = set()
        for phase in JOBS:
            path = ROOT / phase / "job-runtime/result.json"
            value = json.loads(path.read_bytes())
            require(value["job_id"] not in ids, "job cost duplication")
            ids.add(value["job_id"])
            require(
                value["outcome"] in ("succeeded", "failed") and value["wall_seconds"] >= 0,
                "unknown unfinished fee",
            )
            costs.append(
                {
                    "phase": phase,
                    **{
                        k: value.get(k)
                        for k in (
                            "job_id",
                            "outcome",
                            "exit_code",
                            "finished_at",
                            "wall_seconds",
                            "direct_child_reaped",
                            "cleanup_complete",
                            "remaining",
                        )
                    },
                    "ref": str(path),
                    "identity": refs[str(path)],
                }
            )
        whole = sum(x["wall_seconds"] for x in costs)
        costdoc = {
            "schema": "quoridor.public-no-bypass.known-controller-fees.v1",
            "unique_actual_controllers": costs,
            "known_controller_sum_seconds": whole,
            "nested_worker_native_trainer_times_added": False,
            "legacy_incumbent_training_and_old_research_fees": "retained separately; not credited/refunded or duplicated into new353",
            "all_source_review_admin_LLM_and_unsaved_costs": "UNKNOWN; aggregate is known named controller subset, not universal whole-cost total",
            "new_model_Search_fit_games": 0,
        }
        (HERE / "known-controller-fees.json").write_text(json.dumps(costdoc, indent=2) + "\n")
        fields = [
            "game",
            "ply",
            "engine_index",
            "action",
            "completed_depth",
            "caller_started_ns",
            "deadline_ns",
            "authority_receipt_ns",
            "last_completed_iteration_ns",
            "drain_finished_ns",
            "admission_checked_ns",
            "state_commit_ns",
            "legality_cost_ns",
            "whole_nodes",
            "completed_iteration_nodes",
        ]
        with (HERE / "authority-clock.csv").open("x", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for out in raw["outcomes"]:
                for ob in out["observations"]:
                    c = ob["counters"]
                    writer.writerow(
                        {
                            "game": out["game"],
                            **{k: ob[k] for k in fields if k in ob},
                            "authority_receipt_ns": c["authority_receipt_ns"],
                            "drain_finished_ns": c["drain_finished_ns"],
                            "state_commit_ns": c["state_commit_ns"],
                            "legality_cost_ns": c["legality_cost_ns"],
                            "whole_nodes": c["nodes"],
                            "completed_iteration_nodes": ob["completed_iteration_counters"][
                                "nodes"
                            ],
                        }
                    )
        collectionnote = {
            "prior_preparation_inspection_ru_maxrss_KiB": 825768,
            "prior_actual_self_VmHWM_KiB": 27772,
            "successful_final_saved_check_ru_maxrss_KiB": summary["saved_collection"][
                "ru_maxrss_KiB"
            ],
            "successful_final_self_VmHWM_B": summary["saved_collection"]["actual_self_VmHWM_B"],
            "note": "verified-summary saved note refers to EARLIER preparation inspection, not final check32732KiB. Origin of discrepant earlier ru_maxrss is not proven; retain domain discrepancy. No universal continuous family certificate.",
        }
        (HERE / "collection-domain-note.json").write_text(
            json.dumps(collectionnote, indent=2) + "\n"
        )
        (HERE / "report.md").write_text(report(summary, whole))
        (HERE / "review-question.md").write_text(
            """# Fixed consequential interpretation question for353\n\nConfirm the scope of the result from ONE fresh public no-output-bypass fit and ONE prebound colour-paired direct16 cohort against retained BEST51. Assess whether the lower opened-selector V MSE/sign result plus9W7L permits only a bounded observed comparison, and whether the report correctly refuses general strength, Elo, deterministic bypass causality or default promotion. Check full planned denominator, fixed original full-history book/loaded candidates/caller source/actual presentation, pair versus game score uncertainty and honest whole/nested/UNKNOWN fees. Check791 authority records and durable evidence reconciliation, including truncated stdout prefix and exactf32 JSON-format correspondence.\n\nUse stopped compact report/summary/clockCSV/plan/config/startmanifest and supplied qualified receipts. Source/math/head/recipe/clock and actual trained/cost scopes are already qualified; do not re-run tests, models, native/Search/games/fit or broad corpus/math surveys. No new data, labels, seeds, feature/teacher/TT/clock/default/N decisions. Original false/blocker controls and old failed controllers remain unchanged. Any missing decisive fact remainsUNKNOWN; do not reconstruct unsaved payload.\n\nRoot324 assigns the appropriate existing independent reviewer and related Beads leaf. Proposed inclusive review output/admin1MiB inside issued review128MiB/whole4GiBc810; oldreview10MiB held, no global increase/borrow/refund. The immutable stopped target will bind exact selected refs below1MiB, actual writer/readerSTOP and remaining[]. This is a consequential interpretation boundary, not per-run permission or whole-owner gate.\n"""
        )
        for p in named:
            require(identity(p) == refs[str(p)], "source/input after changed " + str(p))
        vm = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/self/status").read_text().splitlines()
                    if x.startswith("VmHWM:")
                )
            )
            * 1024
        )
        require(vm + 67108864 <= 536870912, "actual selfHWM+controller")
        (HERE / "report-collection-STOP.json").write_text(
            json.dumps(
                {
                    "started_UTC": before,
                    "actual_source_reader_writer_STOP": stamp(),
                    "owned_readers_children_jobs_TMP_remaining": [],
                    "input_after": True,
                    "selected_input_B": sum(x["bytes"] for x in refs.values()),
                    "actual_self_VmHWM_B": vm,
                    "sampled_family_including64MiB_control_B": vm + 67108864,
                    "MemAvailable_B": memory,
                    "physical": physical,
                    "RLIMIT_AS_B": 536870912,
                    "continuous_family_peak": "UNKNOWN",
                    "new_model_Search_fit_games": 0,
                    "new_output_admin_inclusive_upper_B": 2097152,
                    "all_old_positive_floors_RAW_failed_fees_TMP_masks_UNKNOWN": "held withoutrefund",
                },
                indent=2,
            )
            + "\n"
        )
        print(
            json.dumps(
                {
                    "report": str(HERE / "report.md"),
                    "known_controllers_seconds": whole,
                    "new_evidence": "report/summary/clockCSV/fees/STOP; final formatting and stopped target follow",
                    "source_collection_STOP": stamp(),
                }
            )
        )


def report(s, whole):
    return f"""# ONE public no-bypass candidate: bounded completed comparison

The no-bypass BEST has same-original-V MSE **0.423870712170**, against retained BEST51 **0.427440880985** (**0.835243% lower**). It scored **9 wins, 7 losses, 0 draws** in the one frozen16-game direct comparison. All16 planned games completed by goal; UNKNOWN0. The observed score is **56.25%** on this specific book. General playing-strength improvement is **not established**; no default/model promotion is made.

## Learning and input scope

| Checkpoint | Physical epoch | Updates | Rows seen | Same V419150 MSE | V sign accuracy |
|---|---:|---:|---:|---:|---:|
| candidate INITIAL |0|0|0|1.000000000000|0.000000%|
| candidate BEST |43|176687|361799807|0.423870712170|84.311344%|
| candidate LAST |46|189014|387041654|0.423877643344|84.306334%|
| retained BEST51 |51|209559|429111399|0.427440880985|84.131934%|

[Actual saved learning curves]({ROOT}/curves-render-v1/learning-curves-v3.png) · [Exact V table]({ROOT}/curves-render-v1/same-V-table.csv) · [Verified fit report]({ROOT}/fit-results-v1/fit-report.md).

ONE fresh same-seed fit used original eligible T8413949/opened V419150, original labels/families/split/reflection/QF1/FP32 FT32H32/tanh and T-only scale. Sealed E was not opened. Only the fixed additive OUTPUT bypass changed b8→0/a0; canonical wall D/80 and standardized head-D/Zero4 remained bit-bound to incumbent. The unchanged Adam/LR/warmup/plateau/early-stop recipe stopped at physical46 after eight stale observations39–46 relative to significant38; strict BEST43 did not reset that significance rule. Final LR9.765625e-6, minimum1e-6 not reached. One-fit/one-seed opened-selector V is not an independent sealed population evaluation.

BEST ordered weights046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841; LAST73b9b3d5a28cb7349c80b9beacfcb1880dd480af6d2e656a1521bf01c77fad81. Incumbent9ca438e43b0c105ac5f802a302946f2ba71623ea2bc443b9c54cc9a8468b75b0 remains the actual trained legacy residual/logit/tanh model. These are not the future raw-step/F80 interface. Saved BEST saturation48.539664% versus48.303471%; lowerMSE is not evidence that saturation causes defeats. Candidate bias-0.0015030481492018081, incumbent bias UNKNOWN; reliability bins and action-ranking estimates UNKNOWN, no extra forwards to fill them.

## Actual trained qualification and costs

Fixed new trained qualification passed4Torch calls/16 rows for BEST/LAST,56 native successful evaluations plus4 evaluation rejects and4 input rejects,16 legal delta/undo transitions on four frozen genuine prefixes. Maximum Torch/native error7.450580596923828e-08 under1e-5; actual standardized D/positive Zero4 and parameter/buffer/coefficient bits checked. Qualification is this trained input/finite/error/delta/undo scope, not every possible history or strength. Original corrected counter receipt5dc1 retained separately from erroneous38727 saved collector metadata; no model replay.

Eight separate depth2/100000-node cost calls completed, candidate4 calls5608 nodes/Search0.006439780s/setup-search-drop0.006853887s; incumbent4 calls3655 nodes/Search0.003899640s/setup-search-drop0.004037875s. Different evaluated work prevents arithmetic-speed attribution. Search-only timer excludes ledger staging; whole phase charges it. Physical NNUE head-call totals remain UNKNOWN; inference-pump nn_calls0 does not mean zero value inference.

## Fixed16 cohort and full denominator

Original sorted bookSHA8dc6fe1afe6e6ef85cd58462fc9cb9ee469b20f18f7c98c109e33d259e1c7035, eight full-history OPEN families, seed32710001,16 colour-paired slots. The actual native ordered JSON book SHA4b46175df2f3e81421660c4cf0f0e9acdb56eb3f6621d25e4f059a07228b14a5 encodes the exact same book object; source/selection/lineage/prefix/full counted-history metadata are retained. No alternative book, family, original policy outcome or terminal label was selected after results.

| Original family slot | Candidate P1 | Candidate P2 | Pair score |
|---|---|---|---:|
|0|loss|loss|0.00|
|1|loss|win|0.50|
|2|loss|win|0.50|
|3|loss|win|0.50|
|4|loss|win|0.50|
|5|win|win|1.00|
|6|win|loss|0.50|
|7|win|win|1.00|

Candidate P1:3/8 wins; candidate P2:6/8. Complete-pair primary score9/16=0.5625; no incomplete pairs/UNKNOWN slots excluded or substituted. Saved bootstrap2000/seed331, complete-family-pair units, percentile interval[0.375,0.75]. This conditional descriptive interval includes0.5 and does not correct the common-initial/PRNG lineage dependence. It is not an Elo/general-strength confidence certificate. Observing9W7L from this tiny development book cannot establish broad superiority or uniquely identify fixed-bypass causality across seeds.

All16 terminal records are goal outcomes, finalply38–91, with791 generated moves after112 book-prefix actions. No draw coverage was created. Rules Standard2p/legal-third/goal-first/200 operationalcap→UNKNOWN, same PVS/alpha source, TT4096/1MiB cap, ScalarFT/guarded head/contactOFF, single CPU0/thread1/GPU0. No Sigma/D/extra cohort, fit or warmup was run. Prefix/current-stock history mapping and terminal/legality facts come from actual qualified native source and retained records; saved verification did not execute geometry or reconstruct unknown history.

## Thinking clock, work and provenance

All791 invocation/returned-action records were accepted; illegal/late/error/unfinished0. Actual immutable authority receipt precedes caller rules validation and state commit, matching drain finishes before the next caller. Receipt-thinking range{s["clock_census"]["thinking_seconds_min_max"][0] * 1000:.6f}–{s["clock_census"]["thinking_seconds_min_max"][1] * 1000:.6f}ms within100ms; configured5ms reserve. Caller range{s["clock_census"]["caller_seconds_min_max"][0] * 1000:.6f}–{s["clock_census"]["caller_seconds_min_max"][1] * 1000:.6f}ms; legality715–117138ns occurs after receipt. Synchronous local drain-after-receipt0ns is the recorded domain, not a universal cancellation or hardRT guarantee. Completed-depth distributions and full invocation counters are retained separately; none substituted TT usable-depth for Search depth.

Candidate396 move decisions/16102342 nodes/11532930 static evaluations; incumbent395/15813947/11125889. Whole work31916289 nodes is not a controlled same-position throughput comparison; different paths and stopping depths were expected. See [complete clock census CSV]({HERE}/authority-clock.csv) and [verified summary]({HERE}/verified-summary.json).

Loaded evaluator digests candidate96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875/incumbent519410ed5eb0b340d1d25df8626d67f508bee7706cbd4ba8a7175bf4e613e645. Private runner634fb7036266965a8080b3384f6b79cce4d84c3977c3244a944b7600731a268e; shared alpha sourcebc7c25dd06043499977df38a78f63d6ce27cfbde1120608257dddbaa57140faa, actual compiled clock910571/runtime79e8. Authentic clock-source clear and eleven affectedRust tests/currentimage/scopedClippy/custody proofs are reused. Actual Policy curve+V-table presentation4ba occurred before the first native game; no delivery/closure inference or reply-only approval.

Durable result/manifest/completed journal/CSV/gzip moves/plan/config/evaluator files matched all named hashes. Manifest expands533 value_stm decimals, typed result uses shortestf32 text; every difference matched exact LE-f32 bits, all other decoded fields exact. Native stdout1538741B retainedtail1048576B: prefix490165B absent; no full-stdout claim. Full durable result1538740B/manifest1577499B/completedjournal1534553B support the independent saved reconciliation; no game replay.

## Whole cost, errors and STOP

Actual direct16 controllerSTART2026-10-09T21:26:46.700091Z/sourceSTOP21:28:06.357527Z/controllerSTOP21:28:06.454375Z, whole79.783929439s. Native76.085149942s and runner74.720927401s are nested, not added. Source/input/private209 after matched, native+guardian freshly absent, directwait/reaped/handles/processcleanup[], no owned readers/children/jobs/TMP left. Sampled arena family125161472B including64MiB controller reserve; continuouspeak UNKNOWN. Native runtime peak_rss field19693568B is its recorded scope, not substituted as continuous family max.

Fit whole1020.968283897s; fit command1018.703749152s/trainerbody1018.106147993s nested. Known14 unique353 controller results, including all failed qualification/software/pre-native attempts, sum **{whole:.9f}s**; exact [named fee table]({HERE}/known-controller-fees.json). Source, review, rendering, admin/LLM and unsaved fees remain UNKNOWN outside that known subset; legacy incumbent training and historicalresearch costs are retained separately. No fee subtraction/cache credit/refund.

Original pre-native direct16 attempt failed before output/model/Search/game0 because unused inference-core field demanded a backend; recovery changed only that field to null and exclusive output. Current recovery is first actual16, not a failed-game retry. Earlier failed software/control/Clippy101/false-clear/TMP/secondary/masks and parameter-census metadata errors remain immutable. Returned completed masks are distinct from persisted pending/attempted. Saved-preparation ru_maxrss825768KiB vs own VmHWM27772KiB discrepancy retained with origin UNKNOWN; successful final check VmHWM33517568B/family sample100626432B, continuousUNKNOWN. See domain correction note.

Issued4GiBc810/global47,567,466,496B holds all resource component uppers/positive old floors. New saved named input unique<8MiB and inclusive source/report/control/failure/admin2MiB stay inside heldcontrols128MiB; related review proposed1MiB inside heldreview128MiB, no new global grant or TT342 borrowing. No default/seal/323USERPAUSE/N/fullgeneration/fourfits96 change.

This stopped bundle requests the appropriate existing independent consequential interpretation review through324. Root alone adopts canonical findings/source/Git and delivers the meaningful Policy result once. No additional numerical phase or promotion is authorized from this report.
"""


if __name__ == "__main__":
    main()
