"""Bounded saved-only direct16 reconciliation; no engine or model execution."""

import csv
import collections
import struct
import datetime
import fcntl
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import re
import resource
import stat

ROOT = Path(__file__).resolve().parent
RUN = ROOT.parent / "arena-development-v1/direct16-recovery-v2/run"
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def identity(path):
    s = path.stat()
    return {
        "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": s.st_size,
        "mode": f"{stat.S_IMODE(s.st_mode):04o}",
    }


def quiet():
    pattern = re.compile(
        r"(^|/)(cargo|rustc|perf|quoridor-runner|nnue-diagnose|chromium|chrome)(\s|$)|current_gradients.py|torchrun|finite-driver|statistics-runtime|qualify_trained.py|trained-native-v[12]|whole-cost-v[12]|direct16-runner-v1|quoridor_training.train"
    )
    for p in Path("/proc").iterdir():
        if not p.name.isdigit() or int(p.name) in (os.getpid(), os.getppid()):
            continue
        try:
            argv = p.joinpath("cmdline").read_bytes().split(b"\0")
            if Path(os.fsdecode(argv[0])).name in ("bash", "sh", "timeout"):
                continue
            if pattern.search(" ".join(os.fsdecode(x) for x in argv if x)):
                raise RuntimeError(f"actual named competitor {p.name}")
        except (OSError, IndexError):
            continue


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def compact_sha(value, sorted_keys=False):
    return hashlib.sha256(
        json.dumps(value, sort_keys=sorted_keys, separators=(",", ":"), ensure_ascii=False).encode()
    ).hexdigest()


def same_saved(a, b, location="", differences=None):
    if differences is None:
        differences = []
    require(type(a) is type(b), "saved type mismatch " + location)
    if isinstance(a, dict):
        require(a.keys() == b.keys(), "saved keys mismatch " + location)
        for k in a:
            same_saved(a[k], b[k], location + "/" + k, differences)
    elif isinstance(a, list):
        require(len(a) == len(b), "saved list length " + location)
        for i, (av, bv) in enumerate(zip(a, b)):
            same_saved(av, bv, location + "/" + str(i), differences)
    elif a != b:
        require(
            location.endswith("/value_stm")
            and type(a) is float
            and math.isfinite(a)
            and math.isfinite(b)
            and struct.pack("<f", a) == struct.pack("<f", b),
            "saved mismatch " + location,
        )
        differences.append(location)
    return differences


def reconcile(result, manifest, planned, config, start, journal, forecast):
    binding = manifest["binding"]
    require(start == binding, "start/final binding mismatch")
    require(
        binding["config"] == config and binding["planned_slots"] == planned,
        "actual config/plan mismatch",
    )
    require(
        binding["planned_sha256"]
        == forecast["exact_named_input_refs"][str(RUN / "planned.json")]["SHA256"],
        "planned binding mismatch",
    )
    require(compact_sha(config) == binding["config_sha256"], "serialized config mismatch")
    book = config["arena"]["book"]
    require(
        compact_sha(book, True)
        == "8dc6fe1afe6e6ef85cd58462fc9cb9ee469b20f18f7c98c109e33d259e1c7035",
        "original canonical book mismatch",
    )
    require(compact_sha(book) == binding["book_sha256"], "native book serialization mismatch")
    require(
        config["ruleset"] == "standard_2p_threefold"
        and binding["rules"] == "research-standard-2p-threefold-goal-first-v1",
        "rules mismatch",
    )
    require(
        config["run_id"] == result["run_id"] == "353-public-no-bypass-vs-BEST51-direct16-v1",
        "run identity mismatch",
    )
    require(
        config["games"]
        == result["planned"]
        == len(planned)
        == len(journal)
        == len(result["outcomes"])
        == 16,
        "full denominator mismatch",
    )
    require(
        config["seed"] == 32710001
        and config["workers"] == config["active_games"] == 1
        and config["cpu_cores"] == [0]
        and config["inference"] is None
        and config["inference_cpu_core"] is None
        and config["max_plies"] == 200,
        "frozen cohort scope",
    )
    require(
        config["arena"]["return_reserve_ms"] == 5
        and config["arena"]["tt_entries"] == 4096
        and config["arena"]["clock_policy"] == "strict_unknown",
        "clock/TT scope",
    )
    require(
        [e["distance_b"] for e in config["engines"]] == [0.0, 8.0]
        and all(
            e["distance_a"] == 0.0
            and e["time_ms"] == 100
            and e["depth"] == 64
            and e["max_nodes"] == 1000000
            and e["simd"] is False
            for e in config["engines"]
        ),
        "engine settings mismatch",
    )
    require(
        [e["content_sha256"] for e in manifest["loaded_evaluators"]]
        == config["arena"]["evaluator_sha256"]
        == [
            "96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875",
            "519410ed5eb0b340d1d25df8626d67f508bee7706cbd4ba8a7175bf4e613e645",
        ],
        "loaded evaluator coupling",
    )
    require(
        binding["executable_sha256"]
        == "634fb7036266965a8080b3384f6b79cce4d84c3977c3244a944b7600731a268e",
        "private binding mismatch",
    )
    require(
        binding["compiled_sources"]["runner/arena_clock.rs"]
        == "910571aa729e57a88121888aab1a09c995d643ff13ca7bd5841c65cdabbfd42f"
        and binding["compiled_sources"]["runner/runtime.rs"]
        == "79e8d6ccab2b9de45d720e0625250463324fde2e73f789173939249c665361b7",
        "compiled caller mismatch",
    )
    for filename, expected in manifest["artifacts"].items():
        require(Path(filename).name == filename, "artifact alias")
        got = identity(RUN / filename)
        require(
            got["SHA256"] == expected["sha256"] and got["bytes"] == expected["bytes"],
            "durable artifact mismatch " + filename,
        )
    differences = same_saved(manifest["result"], result)
    require(
        sorted(journal, key=lambda x: x["game"]) == result["outcomes"], "completed journal differs"
    )
    require(
        result["all_workers_joined"] is True
        and manifest["cleanup"] == {"all_workers_joined": True, "gzip_child_reaped": True}
        and result["stopped"] is None,
        "durable cleanup/stopped status",
    )
    require(
        result["rows"] == result["eligible_rows"] == 0 and result["dataset"] is None,
        "unexpected data generation",
    )
    csvrows = list(csv.DictReader((RUN / "games.csv").read_text().splitlines()))
    require(len(csvrows) == 16, "CSV denominator")
    games, observations, perengine, family_scores = (
        [],
        [],
        [collections.Counter(), collections.Counter()],
        collections.defaultdict(list),
    )
    depth_counts = [collections.Counter(), collections.Counter()]
    stops = [collections.Counter(), collections.Counter()]
    think, caller, legal_ns, drain_ns = [], [], [], []
    move_by_game = collections.defaultdict(list)
    gzip_count = 0
    with gzip.open(RUN / "moves.jsonl.gz", "rt") as stream:
        for line in stream:
            gzip_count += len(line.encode())
            require(gzip_count <= 8388608, "decompressed move journal scope exceeded")
            row = json.loads(line)
            move_by_game[row["game"]].append(row["observation"])
    require(
        {x["game"] for x in planned} == set(range(16))
        and {x["game"] for x in result["outcomes"]} == set(range(16)),
        "duplicate/missing game",
    )
    for p, out, csvrow in zip(planned, result["outcomes"], csvrows):
        game = out["game"]
        opening = book["openings"][game // 2]
        require(
            p["game"] == game
            and p["candidate_color"] == out["candidate_color"] == game % 2
            and p["family"] == out["family"],
            "planned game/family/colour coupling",
        )
        require(
            p["opening"] == opening["prefix"]
            and p["lineage"] == opening["lineage"]
            and p["replay_error"] is None,
            "opening provenance/replay",
        )
        replay = p["replay"]
        require(
            replay["prefix_sha256"] == compact_sha(p["opening"])
            and replay["total_ply"] == len(p["opening"])
            and replay["winner"] is None
            and replay["turn"] == len(p["opening"]) % 2,
            "prefix replay metadata",
        )
        oldhistory = {k: v for k, v in opening["reference"]["settings"]["full_history"]}
        history = replay["history"]
        require(
            len({k for k, v in history}) == len(history)
            and {k.rsplit("|", 1)[0]: v for k, v in history} == oldhistory
            and sum(v for k, v in history) == len(p["opening"]) + 1,
            "complete counted history mapping",
        )
        require(
            out["started"] is True
            and out["failure"] is None
            and out["status"] == "goal"
            and out["reason"] == "goal"
            and out["winner"] in (0, 1),
            "terminal census/UNKNOWN refusal",
        )
        require(
            out["moves"][: len(p["opening"])] == p["opening"]
            and len(out["moves"]) == out["plies"] < 200,
            "move chronology count/prefix",
        )
        obs = out["observations"]
        require(len(obs) == out["plies"] - len(p["opening"]), "generated move count")
        same_saved(move_by_game[game], obs, "moves")
        score = int(out["winner"] == out["candidate_color"])
        family_scores[out["family"]].append(score)
        games.append(
            {
                "game": game,
                "family": out["family"],
                "candidate_colour": out["candidate_color"],
                "winner": out["winner"],
                "candidate_score": score,
                "status": out["status"],
                "final_ply": out["plies"],
                "opening_plies": len(p["opening"]),
                "generated_moves": len(obs),
            }
        )
        for key in ("game", "candidate_color", "winner", "plies"):
            require(int(csvrow[key]) == out[key], "CSV field mismatch")
        require(
            csvrow["status"] == "goal" and csvrow["started"] == "true" and csvrow["failure"] == "",
            "CSV status mismatch",
        )
        last_drain = 0
        for i, ob in enumerate(obs):
            ply = i + len(p["opening"])
            require(
                ob["ply"] == ply
                and ob["side"] == ply % 2
                and ob["engine_index"] == (0 if ob["side"] == out["candidate_color"] else 1)
                and ob["action"] == out["moves"][ply],
                "action/engine chronology",
            )
            require(
                ob["accepted"] is True
                and ob["failure"] is None
                and ob["engine_error"] is None
                and ob["completed_depth"] > 0
                and ob["pv"][0] == ob["action"]
                and math.isfinite(ob["value_stm"]),
                "accepted result validity",
            )
            c = ob["counters"]
            start_ns, receipt, deadline = (
                ob["caller_started_ns"],
                ob["returned_ns"],
                ob["deadline_ns"],
            )
            require(
                deadline - start_ns == 100000000
                and last_drain <= start_ns <= receipt <= deadline
                and c["authority_receipt_ns"] == receipt
                and c["drain_finished_ns"] >= receipt,
                "authority receipt/deadline/drain",
            )
            require(
                receipt <= ob["admission_checked_ns"] <= ob["accepted_ns"] == c["state_commit_ns"]
                and ob["last_completed_iteration_ns"] <= receipt
                and c["completed_snapshot_validation_failed"] is False,
                "deferred validation/commit",
            )
            require(
                c["clock_contract"] == "authority-action-receipt-v1"
                and c["clock_contract_sha256"]
                == "04062382f70648cdfd722e59c35be1100719169097a04749b0046ea5a19a280d",
                "clock identity",
            )
            for seconds, ns in (
                (ob["thinking_seconds"], receipt - start_ns),
                (ob["caller_seconds"], ob["accepted_ns"] - start_ns),
            ):
                require(
                    math.isfinite(seconds) and abs(seconds - ns / 1e9) <= 1e-12,
                    "timing domain mismatch",
                )
            require(
                c["drain_after_receipt_ns"] == c["drain_finished_ns"] - receipt
                and c["legality_cost_ns"] >= 0
                and c["full_caller_ns"] == ob["accepted_ns"] - start_ns,
                "caller accounting",
            )
            engine = ob["engine_index"]
            perengine[engine].update(
                {
                    "moves": 1,
                    **{
                        key: c[key]
                        for key in (
                            "nodes",
                            "static_evaluations",
                            "delta_updates",
                            "tt_probes",
                            "tt_key_hits",
                            "tt_exact_hits",
                            "tt_usable_depth",
                            "tt_bound_cutoffs",
                            "tt_capacity_skips",
                        )
                    },
                }
            )
            depth_counts[engine][ob["completed_depth"]] += 1
            stops[engine][ob["stop"]] += 1
            think.append(ob["thinking_seconds"])
            caller.append(ob["caller_seconds"])
            legal_ns.append(c["legality_cost_ns"])
            drain_ns.append(c["drain_after_receipt_ns"])
            last_drain = c["drain_finished_ns"]
            observations.append(ob)
        for engine, profile in enumerate(out["persistent_tt"]):
            eo = [o for o in obs if o["engine_index"] == engine]
            require(
                profile["attempts"]
                == profile["search_invocations"]
                == profile["successful_results"]
                == len(eo)
                and profile["initialization_attempts"] == profile["initialization_successes"] == 1,
                "persistent session invocation counts",
            )
            require(
                all(
                    profile[k] == 0
                    for k in (
                        "cancellations",
                        "no_completed_iteration_results",
                        "initialization_errors",
                        "namespace_resets",
                        "search_errors_without_counters",
                        "errors",
                        "illegal_moves",
                    )
                ),
                "persistent session error/reset",
            )
            require(
                profile["requested_tt_entries"] == profile["effective_tt_slots"] == 4096
                and profile["persistent_tt_byte_cap"] == 1048576
                and profile["retained_bytes_peak"] <= 1048576,
                "actual TT capacity",
            )
    wins = sum(g["candidate_score"] for g in games)
    pairs = [{"family": k, "scores": v, "pair_mean": sum(v) / 2} for k, v in family_scores.items()]
    require(
        len(pairs) == 8 and all(len(p["scores"]) == 2 for p in pairs), "complete paired denominator"
    )
    summary = result["arena_summary"]
    require(
        summary["census"]
        == {
            "planned_games": 16,
            "started_games": 16,
            "completed_games": 16,
            "unknown_games": 0,
            "complete_pairs": 8,
            "incomplete_pairs": 0,
            "unknown_reasons": {},
        },
        "summary census",
    )
    require(
        summary["complete_pair_mean"] == summary["valid_game_score_secondary"] == wins / 16
        and summary["planned_score_range"] == [wins / 16, wins / 16],
        "summary scores",
    )
    require(
        [p["pair_mean"] for p in pairs] == [p["score"] for p in summary["pairs"]], "pair summaries"
    )
    return {
        "schema": "quoridor.public-no-bypass.direct16.saved-assessment.v1",
        "issue": "quoridor-4lc.353",
        "new_model_Search_fit_games": 0,
        "durable_input_refs": forecast["exact_named_input_refs"],
        "verification": "PASS saved named corpus/census/config/book/loaded-evaluator/compiled-clock/action-receipt/deferred-commit/drain checks; independent consequential interpretation pending",
        "counts": {
            "planned": 16,
            "started": 16,
            "completed": 16,
            "unknown": 0,
            "goals": 16,
            "draws": 0,
            "complete_pairs": 8,
            "caller_observations": len(observations),
            "generated_moves": sum(g["generated_moves"] for g in games),
        },
        "comparison": {
            "candidate_W_L_D": [wins, 16 - wins, 0],
            "pair_mean": wins / 16,
            "by_candidate_colour": [
                {
                    "colour": c,
                    "wins": sum(g["candidate_score"] for g in games if g["candidate_colour"] == c),
                    "games": 8,
                }
                for c in (0, 1)
            ],
            "pairs": pairs,
            "bootstrap_saved": summary["bootstrap"],
            "interpretation": "Modestly lower same-originalV MSE and9/16 on this fixed shared-lineage book; general strength improvement unestablished, no Elo/default promotion.",
        },
        "games": games,
        "clock_census": {
            "invoked_returned_accepted": len(observations),
            "rejected_illegal_late_error_unfinished": 0,
            "thinking_seconds_min_max": [min(think), max(think)],
            "caller_seconds_min_max": [min(caller), max(caller)],
            "thinking_sum_seconds": sum(think),
            "caller_sum_seconds": sum(caller),
            "legality_ns_min_max": [min(legal_ns), max(legal_ns)],
            "drain_after_receipt_ns_min_max": [min(drain_ns), max(drain_ns)],
            "checked": "100ms authority receipt before validation/commit, matching drain before following caller; qualified source supplies deferred caller rules; no new geometric replay/hardRT certificate",
        },
        "work": {
            "per_engine": [dict(x) for x in perengine],
            "completed_depth_counts": [dict(x) for x in depth_counts],
            "stop_counts": [dict(x) for x in stops],
            "physical_NN_calls": "UNKNOWN; runner inference-pump nn_calls0 is not physical NNUE evaluation count",
            "speed_interpretation": "Different trajectories/nodes; no arithmetic speed ratio or causal CPU shares",
        },
        "serialization": {
            "book_sorted_compact_SHA256": compact_sha(book, True),
            "native_book_ordered_compact_SHA256": compact_sha(book),
            "manifest_result_FP32_value_format_differences": len(differences),
            "FP32_values": "all exact LE-f32 bits; all other fields exact; typed f32 shortest decimals differ from expanded manifest Value JSON",
        },
        "cost": {
            "runner_wall_seconds": result["wall_seconds"],
            "native_seconds": 76.08514994196594,
            "controller_whole_seconds": 79.78392943891231,
            "nested_not_added": True,
            "startup": {
                k: manifest[k]
                for k in (
                    "startup_cost",
                    "evaluator_initialization_seconds",
                    "backend_initialization_seconds",
                    "model_warmup",
                )
            },
            "peak_rss_recorded_B": result["peak_rss"],
            "continuous_peak": "UNKNOWN",
        },
        "limitations": [
            "One model/seed and16 development games on8 correlated original full-history families; no population strength or significance claim.",
            "Terminal goal facts/legality are supplied by qualified native source and retained actual records; this saved pass does not execute rules.",
            "Native stdout tail truncated490165B prefix; full durable result/manifest/journal hashed and crosschecked, no fullstdoutcapture claim.",
            "ReturnedCOMPLETED masks distinct from persistedpending/attempted; no universal async/fault/host isolation claim.",
            "All historical failures/costs/TMP/positive resource floors/UNKNOWN held; no refunds.",
        ],
    }


def main():
    started = stamp()
    with LOCK.open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet()
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        if memory < 536870912 + 4294967296:
            raise RuntimeError("family+host RAM unsupported")
        if os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize < 4294967296:
            raise RuntimeError("whole filesystem support insufficient")
        os.sched_setaffinity(0, {3})
        physical = {
            str(c): [
                (Path(f"/sys/devices/system/cpu/cpu{c}/topology") / n).read_text().strip()
                for n in ("physical_package_id", "core_id")
            ]
            for c in (3, 4)
        }
        if physical["3"] == physical["4"]:
            raise RuntimeError("physical cores not distinct")
        resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
        forecast = json.loads((ROOT / "forecast.json").read_bytes())
        for path, expected in forecast["exact_named_input_refs"].items():
            if identity(Path(path)) != expected:
                raise RuntimeError(f"input identity drift {path}")
        if (
            sum(x["bytes"] for x in forecast["exact_named_input_refs"].values())
            > forecast["input_scope_upper_B"]
        ):
            raise RuntimeError("input upper exceeded")
        result = json.loads((RUN / "result.json").read_bytes())
        manifest = json.loads((RUN / "manifest.json").read_bytes())
        planned = json.loads((RUN / "planned.json").read_bytes())
        config = json.loads((RUN / "config.json").read_bytes())
        start = json.loads((RUN / "manifest-start.json").read_bytes())
        journal = [json.loads(x) for x in (RUN / "completed.jsonl").read_bytes().splitlines()]
        summary = reconcile(result, manifest, planned, config, start, journal, forecast)
        sample = dict(
            x.split(":", 1)
            for x in Path("/proc/self/status").read_text().splitlines()
            if x.startswith(("VmRSS:", "VmHWM:"))
        )
        rss_B = int(sample["VmHWM"].split()[0]) * 1024
        if rss_B + 67108864 > 536870912:
            raise RuntimeError("observed selfHWM+controller family exceeds512MiB")
        summary["saved_collection"] = {
            "started_UTC": started,
            "STOP_UTC": stamp(),
            "MemAvailable_B": memory,
            "physical": physical,
            "actual_self_VmHWM_B": rss_B,
            "sampled_family_including64MiB_control_B": rss_B + 67108864,
            "ru_maxrss_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            "continuous_family_peak": "UNKNOWN",
            "ru_maxrss_note": "Tool child reports825768KiB while own /proc VmHWM is smaller; origin not proven, retained as resource-domain discrepancy, not a family certificate.",
            "RLIMIT_AS_B": 536870912,
            "owned_children_readers_jobs_TMP_remaining": [],
        }
        for path, expected in forecast["exact_named_input_refs"].items():
            if identity(Path(path)) != expected:
                raise RuntimeError(f"after identity drift {path}")
        output = ROOT / "verified-summary.json"
        if output.exists():
            raise RuntimeError("immutable assessment output already exists")
        output.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
        print(
            json.dumps(
                {
                    "summary": str(output),
                    "identity": identity(output),
                    "counts": summary["counts"],
                    "clock": summary["clock_census"],
                    "result": summary["comparison"],
                    "resources": summary["saved_collection"],
                },
                allow_nan=False,
            )
        )


if __name__ == "__main__":
    main()
