"""Publish bounded closure metadata; frozen research evidence stays unchanged."""

import datetime
import hashlib
import json
from pathlib import Path
import stat

root = Path(__file__).resolve().parent
closed = json.loads((root / "closed-Beads.json").read_bytes())
assert closed["status"] == "closed"

fields = {
    "stage": (
        "353 completed and closed after independent bounded interpretation acceptance",
        "353は独立した限定解釈の受入れ後に完了・終了",
    ),
    "next_action": (
        "324 integrates canonical findings/source and delivers one meaningful Policy result; no numerical continuation",
        "324が正本の知見・ソースを統合し、Policyへ結果を1回渡す。数値実行の継続なし",
    ),
    "wait_reason": (
        "No remaining owned work or hardware/reader lease; no reply-only gate",
        "担当内の残作業や計算・読み手リースなし。返答だけを待つゲートなし",
    ),
    "close_reason": (
        closed["close_reason"],
        "公開全量での学習1回と固定16対局を検証し、独立解釈レビューで指摘なし。同一VのMSEは0.835243%低下、9勝7敗・不明0。固定の小規模bookの観測に限定し、一般的な棋力改善や標準モデル昇格は示さない。過去証拠と費用を保持し、正本統合とPolicy通知は324が担当。N・封印・既定値・323停止は変更なし。",
    ),
}

display = {
    "issue": "quoridor-4lc.353",
    "fields": {
        key: {
            "English": english,
            "English_UTF8_SHA256": hashlib.sha256(english.encode()).hexdigest(),
            "Japanese": japanese,
            "Japanese_UTF8_SHA256": hashlib.sha256(japanese.encode()).hexdigest(),
        }
        for key, (english, japanese) in fields.items()
    },
}
(root / "display-ja-close.json").write_text(
    json.dumps(display, ensure_ascii=False, indent=2) + "\n"
)
dashboard = {
    "dashboard": {
        "stage": fields["stage"][0],
        "wait_kind": "none",
        "next_action": fields["next_action"][0],
        "wait_reason": fields["wait_reason"][0],
        "runtime_dirs": [],
        "evidence_paths": [
            str(root / name)
            for name in (
                "report.md",
                "owner-interpretation-acceptance.json",
                "closure-handoff.json",
                "display-ja-close.json",
            )
        ],
    }
}
(root / "dashboard-closed.json").write_text(json.dumps(dashboard, indent=2) + "\n")
refs = {}
for name in (
    "owner-interpretation-acceptance.json",
    "report.md",
    "stopped-target.json",
    "closed-Beads.json",
    "display-ja-close.json",
):
    path = root / name
    raw = path.read_bytes()
    info = path.stat()
    refs[str(path)] = {
        "SHA256": hashlib.sha256(raw).hexdigest(),
        "bytes": info.st_size,
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }

packet = {
    "schema": "quoridor.public-no-bypass.owner-closure-handoff.v1",
    "issue": "quoridor-4lc.353",
    "actual_Beads_status": "closed",
    "closed_at": closed["closed_at"],
    "actual_reader_source_artifact_STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "owned_readers_children_jobs_TMP_remaining": [],
    "current_next_compute_fair_reservation": "NONE",
    "refs": refs,
    "independent_interpretation_control_SHA256": "f43526a3409af60cb35e54c266e4358cbdad885288cf7b7b46baa8d87dccf565",
    "independent_reader_STOP": "2026-10-09T21:59:23.139872+00:00",
    "new_model_Search_forward_fit_games": 0,
    "scope_closed": "ONE fresh public no-output-bypass fit + ONE fixed16; limited interpretation accepted; no defaultpromotion/generalstrength/Elo/unique causality",
    "Main_Git_findings_Policy_writer": "324 only",
    "all_old_floors_RAW_failed_fees_TMP_masks_UNKNOWN": "held; no refund",
    "resource": "closure64KiB inside existing2MiB saved phase/controls128MiB/whole4GiBc810; reviewer11MiB inside128MiB; currentglobal47575855104 includes3548MiB, no new grant",
    "N_fits96_seals_defaults_323pause_parent342_epic": "unchanged",
    "actual_context_verified": "2026-10-09T22:00:45.928Z fullaccessnever/gpt6.1-solhigh/originallearning-million",
    "admin_refusal": "initial inline closure DISPLAY syntax refused before files, dependent metadata file-not-found refused; no research/source mutation; corrected publication here",
}
(root / "closure-handoff.json").write_text(json.dumps(packet, indent=2) + "\n")
print(
    json.dumps(
        {
            "closed_at": closed["closed_at"],
            "packet": str(root / "closure-handoff.json"),
            "SHA256": hashlib.sha256((root / "closure-handoff.json").read_bytes()).hexdigest(),
            "remaining": [],
        }
    )
)
