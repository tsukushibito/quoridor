"""353 saved-only fit report and standalone SVG plots; no model/framework calls."""

import csv
import datetime
import fcntl
import gzip
import hashlib
import html
import importlib.util
import json
import math
import os
from pathlib import Path
import stat
import sys
import time

R = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1")
OUT = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-no-bypass-v1/candidate-v1/output"
)
OLD = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/trigger-patience-v1/patience1/output"
)
DEST = R / "curves-render-v1"


def identity(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"SHA256": digest, "bytes": info.st_size, "mode": f"{stat.S_IMODE(info.st_mode):04o}"}


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def csv_rows(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def main():
    beginning = time.monotonic()
    spec = importlib.util.spec_from_file_location("guard", R / "entry_guard.py")
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    with guard.LOCK.open("a+b") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        guard.quiet()
        sys.path.insert(0, str(guard.WT / "python"))
        from quoridor_training import cycle_process as process

        assert process.available_memory() >= 5 * 1024**3
        os.sched_setaffinity(0, {5})
        selected = [
            OUT / name
            for name in [
                "freeze.json",
                "run-status.json",
                "data.json",
                "config.json",
                "scale.json",
                "sampling.json",
                "curves.csv",
                "diagnostic-curves.csv",
                "batch.jsonl.gz",
                "initial.pt",
                "best.pt",
                "last.pt",
            ]
        ]
        selected += [
            OUT / tag / name
            for tag in ["initial-model", "best-model", "last-model"]
            for name in ["manifest.json", "weights.f32", "training-target.json"]
        ]
        selected += [
            OLD / name
            for name in [
                "freeze.json",
                "curves.csv",
                "scale.json",
                "data.json",
                "config.json",
                "best-model/manifest.json",
            ]
        ]
        before = {str(path): identity(path) for path in selected}
        assert sum(x["bytes"] for x in before.values()) < 4 * 1024**2
        freeze = json.loads((OUT / "freeze.json").read_text())
        old_freeze = json.loads((OLD / "freeze.json").read_text())
        status = json.loads((OUT / "run-status.json").read_text())
        data = json.loads((OUT / "data.json").read_text())
        cfg = json.loads((OUT / "config.json").read_text())
        scale = json.loads((OUT / "scale.json").read_text())
        old_scale = json.loads((OLD / "scale.json").read_text())
        assert scale == old_scale
        assert (
            before[str(OLD / "freeze.json")]["SHA256"]
            == "ad6ce413846408ddbcd792903ae22e22b0b3349d54198c5665df0783d6164c56"
        )
        assert (
            freeze["dataset_sha"]
            == old_freeze["dataset_sha"]
            == "07d81abc2230b2fe6b7c5fb7a425e7e3109bf9af2c467f5c72f8d3bdb975279b"
        )
        assert (
            data["train"] == 8413949
            and data["validation"] == 419150
            and data["test_opened"] is False
        )
        assert (
            cfg["model"]["distance_bypass"] is False
            and cfg["model"]["distance_a"] == cfg["model"]["distance_b"] == 0
        )
        assert (
            cfg["limits"]["seconds"] is None
            and cfg["limits"]["samples"] is None
            and cfg["training"]["steps"] is None
        )
        for relative, digest in freeze["artifacts_sha256"].items():
            assert identity(OUT / relative)["SHA256"] == digest, relative
        for tag in ["initial-model", "best-model", "last-model"]:
            manifest = json.loads((OUT / tag / "manifest.json").read_text())
            assert identity(OUT / tag / "weights.f32")["SHA256"] == manifest["weights_SHA"]
            assert (
                manifest["mu_f32"] == scale["mu_f32"]
                and manifest["sigma_f32"] == scale["sigma_f32"]
            )
            assert (
                manifest["distance_fit"] == {"a": 0, "b": 0} and manifest["route_mode"] == "zero4"
            )
        assert (
            before[str(OUT / "initial-model/weights.f32")]["SHA256"]
            == "2ddacbf88145816b6b0c86e13ebb983d7c1b64e42f8d346623873a18ae7414ad"
        )
        curves, diagnostics, incumbent = (
            csv_rows(OUT / "curves.csv"),
            csv_rows(OUT / "diagnostic-curves.csv"),
            csv_rows(OLD / "curves.csv"),
        )
        assert len(curves) == 47 and all(
            int(row["validation_rows"]) == 419150 and row["validation_scope"] == "full_selector"
            for row in curves + incumbent
        )
        assert all(
            int(row["validation_rows"]) == 8192
            and row["validation_scope"] == "fixed_diagnostic_subset"
            for row in diagnostics
        )
        best = min(curves, key=lambda row: float(row["validation_row_mse"]))
        assert (
            int(best["step"]) == freeze["best_step"]
            and float(best["validation_row_mse"]) == freeze["best_validation_mse"]
        )
        old_best = min(incumbent, key=lambda row: float(row["validation_row_mse"]))
        assert (
            float(old_best["validation_row_mse"])
            == old_freeze["best_validation_mse"]
            == 0.42744088098494515
        )
        assert status["status"] == "EARLY_STOPPED" and status["fault"] is None
        assert int(curves[-1]["completed_epochs"]) == status["completed_epochs"] == 46
        assert all(
            int(row["training_seen"]) == int(row["completed_epochs"]) * 8413949 for row in curves
        )
        with gzip.open(OUT / "batch.jsonl.gz", "rt") as stream:
            batch = [json.loads(line) for line in stream]
        completed = [row for row in batch if row["status"] == "COMPLETED"]
        assert completed[-1]["actual_optimizer_step"] == status["step"] == 189014
        assert all(
            math.isfinite(row["objective_loss"])
            and all(math.isfinite(v) for v in row["gradient_norm"].values())
            for row in completed
        )
        significant, last_significant, stale = math.inf, 0, 0
        for row in curves:
            value = float(row["validation_row_mse"])
            if value < significant - cfg["evaluation"]["min_delta"]:
                significant, last_significant, stale = value, int(row["completed_epochs"]), 0
            else:
                stale += 1
        assert stale == 8 and last_significant == 38
        DEST.mkdir(exist_ok=False)
        table = []
        for label, row in [
            ("candidate INITIAL", curves[0]),
            ("candidate BEST", best),
            ("candidate LAST", curves[-1]),
            ("retained BEST51", old_best),
        ]:
            table.append(
                {
                    "checkpoint": label,
                    "epoch": int(row["completed_epochs"]),
                    "update": int(row["step"]),
                    "seen": int(row["training_seen"]),
                    "same_V_rows": 419150,
                    "row_MSE": float(row["validation_row_mse"]),
                    "sign_accuracy": float(row["validation_sign_accuracy"]),
                    "saturation_fraction": float(row["validation_saturation_fraction"]),
                    "bias": float(row["validation_bias"]) if row.get("validation_bias") else None,
                    "saved_selector_wall_seconds": float(row["wall_seconds"]),
                }
            )
        with (DEST / "same-V-table.csv").open("w") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(table[0]))
            writer.writeheader()
            writer.writerows(table)
        candidate_mse, incumbent_mse = table[1]["row_MSE"], table[3]["row_MSE"]
        summary = {
            "same_V_table": table,
            "BEST_absolute_MSE_change": candidate_mse - incumbent_mse,
            "BEST_relative_MSE_reduction_percent": 100
            * (incumbent_mse - candidate_mse)
            / incumbent_mse,
            "known_fixed_D_same_V_MSE_from_incumbent_saved_curve": float(
                old_best["validation_distance_mse"]
            ),
            "candidate_zero_bypass_distance_baseline_MSE": float(best["validation_distance_mse"]),
            "selected_epoch_update_seen": [43, 176687, 361799807],
            "last_epoch_update_seen": [46, 189014, 387041654],
            "last_significant_epoch": last_significant,
            "stale_complete_epochs": stale,
            "last_observed_LR": completed[-1]["lr"][0],
            "recipe_minimum_LR": cfg["training"]["min_lr"],
            "minimum_LR_reached": completed[-1]["lr"][0] <= cfg["training"]["min_lr"],
            "fit_status": status,
            "checkpoint_native_correspondence": "UNFINISHED for trained weights; initial parameter/input numerical qualification reused only within its scope",
            "calibration": "saved sign/saturation/bias available; bin/reliability/ranking/prediction records UNKNOWN, no new forward",
            "strength": "NOT_EVALUATED; smaller sameV MSE is not promotion",
            "presentation": "Policy actual human conversation presentation required before candidate16; not yet recorded",
            "manifest_weight_hashes": {
                tag: {
                    "manifest": before[str(OUT / tag / "manifest.json")],
                    "ordered_weights": before[str(OUT / tag / "weights.f32")],
                }
                for tag in ["initial-model", "best-model", "last-model"]
            },
            "input_source_map": before,
            "new_model_forward_fit_game_calls": 0,
        }
        write(DEST / "summary.json", summary)
        parts = [
            '<svg xmlns="http://www.w3.org/2000/svg" width="1800" height="1380" viewBox="0 0 1800 1380"><rect width="1800" height="1380" fill="white"/>',
            "<style>text{font-family:DejaVu Sans,sans-serif;fill:#17202a} .title{font-size:26px;font-weight:bold}.label{font-size:19px}.small{font-size:16px}</style>",
            '<text x="50" y="40" class="title">ONE full-public no-bypass fit — saved learning curves</text>',
            '<text x="50" y="69" class="label">T 8,413,949 | same original V 419,150 | tanh(z) row MSE | INITIAL / BEST / LAST retained</text>',
        ]

        def panel(left, top, title, series, low, high, ymaxx=52, ticks=None, ylog=False):
            width, height = 735, 435
            x0, y0 = left + 82, top + 50
            parts.append(
                f'<text x="{left}" y="{top + 16}" class="label">{html.escape(title)}</text>'
            )
            for tick in [0, 10, 20, 30, 40, 50]:
                x = x0 + tick / ymaxx * width
                parts.append(
                    f'<path d="M{x:.2f} {y0} V{y0 + height}" stroke="#e5e7eb"/><text x="{x:.2f}" y="{y0 + height + 27}" text-anchor="middle" class="small">{tick}</text>'
                )
            for tick in ticks or [low, (low + high) / 2, high]:
                y = y0 + (high - tick) / (high - low) * height
                label = f"1e{int(tick)}" if ylog else f"{tick:.3f}"
                parts.append(
                    f'<path d="M{x0} {y:.2f} H{x0 + width}" stroke="#e5e7eb"/><text x="{x0 - 10}" y="{y + 6:.2f}" text-anchor="end" class="small">{label}</text>'
                )
            parts.append(
                f'<path d="M{x0} {y0} V{y0 + height} H{x0 + width}" fill="none" stroke="#374151"/>'
            )
            parts.append(
                f'<text x="{x0 + width / 2}" y="{y0 + height + 53}" text-anchor="middle" class="small">Completed physical epochs (fractional for saved diagnostics)</text>'
            )
            for index, (label, rows, key, color, dashed, markers) in enumerate(series):
                pts = []
                for row in rows:
                    xval, val = float(row["row_epoch"]), float(row[key])
                    if ylog:
                        val = math.log10(val)
                    if not low <= val <= high:
                        continue
                    x = x0 + xval / ymaxx * width
                    y = y0 + (high - val) / (high - low) * height
                    pts.append(f"{x:.2f},{y:.2f}")
                    if markers:
                        parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="4" fill="{color}"/>')
                dash = ' stroke-dasharray="7 5"' if dashed else ""
                parts.append(
                    f'<polyline points="{" ".join(pts)}" fill="none" stroke="{color}" stroke-width="2.4"{dash}/>'
                )
                legend_y = y0 + height + 82 + index * 23
                parts.append(
                    f'<path d="M{x0} {legend_y} h25" stroke="{color}" stroke-width="3"{dash}/><text x="{x0 + 33}" y="{legend_y + 5}" class="small">{html.escape(label)}</text>'
                )

        full_v = [
            ("Candidate: full original V", curves, "validation_row_mse", "#047857", False, False),
            (
                "Retained incumbent: saved same-V points",
                incumbent,
                "validation_row_mse",
                "#6b7280",
                True,
                False,
            ),
        ]
        panel(
            30,
            105,
            "A. Full V row MSE — INITIAL included",
            full_v,
            0.35,
            1.02,
            ticks=[0.4, 0.6, 0.8, 1.0],
        )
        panel(
            915,
            105,
            "B. Full V detail — epoch 1 onward (INITIAL outside zoom)",
            full_v,
            0.4,
            0.48,
            ticks=[0.4, 0.42, 0.44, 0.46, 0.48],
        )
        full_t = [row for row in curves if row["train_scope"] == "full_train"]
        panel(
            30,
            735,
            "C. Candidate training and fixed diagnostics — scopes kept separate",
            [
                (
                    "Full T: epoch 1 and every 5 (sparse measurements)",
                    full_t,
                    "train_row_mse",
                    "#1d4ed8",
                    True,
                    True,
                ),
                (
                    "Fixed T diagnostic: 8,192 rows (not full T)",
                    diagnostics,
                    "train_row_mse",
                    "#60a5fa",
                    False,
                    False,
                ),
                (
                    "Fixed V diagnostic: 8,192 rows (not selector)",
                    diagnostics,
                    "validation_row_mse",
                    "#9333ea",
                    False,
                    False,
                ),
            ],
            0.35,
            1.02,
            ticks=[0.4, 0.6, 0.8, 1.0],
        )
        lr_rows = [{**row, "learning_rate": row["lr"][0]} for row in completed]
        panel(
            915,
            735,
            "D. Saved observed learning rate — log10 scale, warmup included",
            [
                (
                    "Actual completed-update LR observations",
                    lr_rows,
                    "learning_rate",
                    "#b45309",
                    False,
                    False,
                )
            ],
            -6,
            -2,
            ticks=[-6, -5, -4, -3, -2],
            ylog=True,
        )
        parts.append(
            '<text x="50" y="1355" class="small">BEST epoch 43; LAST epoch 46. Strict BEST differs from significant-improvement patience. No strength claim or new model evaluations.</text></svg>'
        )
        (DEST / "learning-curves.svg").write_text("\n".join(parts))
        os.environ["MAGICK_THREAD_LIMIT"] = "1"
        deadline = time.monotonic() + 60
        resources = process.CycleResources(
            {
                "max_memory_bytes": 448 * 1024**2,
                "host_ram_reserve": 4 * 1024**3,
                "max_output_bytes": 4 * 1024**3,
            },
            R,
            deadline,
        )
        rendered = process.execute(
            [
                "/usr/bin/taskset",
                "-c",
                "3",
                "/usr/bin/convert",
                "-background",
                "white",
                str(DEST / "learning-curves.svg"),
                str(DEST / "learning-curves.png"),
            ],
            DEST / "render.log",
            deadline,
            resources=resources,
        )
        after = {str(path): identity(path) for path in selected}
        assert after == before
        assert guard.verified_process_census([rendered], process)
        write(
            DEST / "render-STOP.json",
            {
                "actual_STOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "source_input_unchanged": True,
                "selected_input_bytes": sum(x["bytes"] for x in before.values()),
                "process": rendered,
                "remaining": [],
                "new_model_forward_fit_games": 0,
                "whole_seconds": time.monotonic() - beginning,
                "stdlib_SVG_ImageMagick_renderer": "used existing tools after unavailable offline matplotlib; no downloads/shared environment changes",
                "whole_B": 4294967296,
                "continuous_peak": "UNKNOWN",
            },
        )
        print(
            json.dumps(
                {
                    "BEST_MSE": candidate_mse,
                    "LAST_MSE": table[2]["row_MSE"],
                    "relative_reduction_percent": summary["BEST_relative_MSE_reduction_percent"],
                    "actual_saved_render_STOP": datetime.datetime.now(
                        datetime.timezone.utc
                    ).isoformat(),
                }
            )
        )


if __name__ == "__main__":
    main()
