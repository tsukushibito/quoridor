"""Render the owned saved curve coordinates through existing ImageMagick drawing."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import time
import xml.etree.ElementTree as ET

R = Path("/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1")
D = R / "curves-render-v1"


def main():
    spec = importlib.util.spec_from_file_location("guard", R / "entry_guard.py")
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    with guard.LOCK.open("a+b") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        guard.quiet()
        sys.path.insert(0, str(guard.WT / "python"))
        from quoridor_training import cycle_process as process

        assert process.available_memory() > 5 * 1024**3
        os.sched_setaffinity(0, {5})
        os.environ["MAGICK_THREAD_LIMIT"] = "1"
        root = ET.parse(D / "learning-curves-v2.svg").getroot()
        drawing = []
        for element in root:
            tag = element.tag.split("}")[-1]
            attrs = element.attrib
            if tag == "style":
                continue
            if tag == "rect":
                drawing.append("fill white stroke none rectangle 0,0 1800,1450")
            elif tag == "text":
                text = element.text.replace("\\", "\\\\").replace('"', '\\"')
                size = {"title": 26, "label": 19, "small": 16}[attrs["class"]]
                anchor = {"middle": "center", "end": "right"}.get(attrs.get("text-anchor"), "left")
                weight = "bold" if attrs["class"] == "title" else "normal"
                drawing.append(
                    f'fill "#17202a" stroke none font-size {size} font-weight {weight} text-anchor {anchor} text {attrs["x"]},{attrs["y"]} "{text}"'
                )
            elif tag == "path":
                drawing.append(
                    f'fill none stroke "{attrs["stroke"]}" stroke-width {attrs.get("stroke-width", 1)} path "{attrs["d"]}"'
                )
            elif tag == "polyline":
                points = attrs["points"].split()
                # Explicit open segments: native drawing polyline closed the draft PNG.
                drawing.append(
                    f'fill none stroke "{attrs["stroke"]}" stroke-width {attrs["stroke-width"]}'
                )
                drawing.extend(f"line {a} {b}" for a, b in zip(points, points[1:]))
            elif tag == "circle":
                drawing.append(
                    f'fill "{attrs["fill"]}" stroke none circle {attrs["cx"]},{attrs["cy"]} {float(attrs["cx"]) + float(attrs["r"])},{attrs["cy"]}'
                )
            else:
                raise ValueError("unsupported owned saved plot primitive " + tag)
        command = [
            "/usr/bin/taskset",
            "-c",
            "3",
            "/usr/bin/convert",
            "-size",
            "1800x1450",
            "xc:white",
            "-font",
            "DejaVu-Sans",
        ]
        chunks, chunk = [], ""
        active_style = 'fill none stroke "#17202a" stroke-width 1'
        for line in drawing:
            if len((chunk + line).encode()) > 30000:
                chunks.append(chunk)
                # Retain active drawing style when splitting a large series.
                chunk = active_style + "\n"
            chunk += line + "\n"
            if line.startswith("fill ") and not any(
                token in line for token in (" path ", " text ", " circle ", " rectangle ")
            ):
                active_style = line
        if chunk:
            chunks.append(chunk)
        for chunk in chunks:
            command += ["-draw", chunk]
        command += [str(D / "learning-curves-v3.png")]
        deadline = time.monotonic() + 60
        resources = process.CycleResources(
            {
                "max_memory_bytes": 448 * 1024**2,
                "host_ram_reserve": 4 * 1024**3,
                "max_output_bytes": 4 * 1024**3,
            },
            R,
            deadline,
        )
        result = process.execute(command, D / "render-final.log", deadline, resources=resources)
        assert guard.verified_process_census([result], process)
        summary = json.loads((D / "summary.json").read_text())
        for path, expected in summary["input_source_map"].items():
            p = Path(path)
            info = p.lstat()
            assert (
                info.st_size == expected["bytes"]
                and f"{stat.S_IMODE(info.st_mode):04o}" == expected["mode"]
            )
            assert hashlib.sha256(p.read_bytes()).hexdigest() == expected["SHA256"]
        record = {
            "actual_source_reader_writer_STOP": datetime.datetime.now(
                datetime.timezone.utc
            ).isoformat(),
            "process": {k: v for k, v in result.items() if k != "command"},
            "command_SHA256": hashlib.sha256(json.dumps(result["command"]).encode()).hexdigest(),
            "remaining": [],
            "saved_inputs_after_exact": True,
            "new_model_forward_fit_games": 0,
            "old_refusals_draft_plot_fees": "retained, draftPNG closed polyline corrected to explicit open segments; no saved numeric data changes",
            "whole_B": 4294967296,
            "continuous_peak": "UNKNOWN",
        }
        (D / "render-final-STOP.json").write_text(json.dumps(record, indent=2) + "\n")
        print("saved plot rendering STOP", record["actual_source_reader_writer_STOP"])


if __name__ == "__main__":
    main()
