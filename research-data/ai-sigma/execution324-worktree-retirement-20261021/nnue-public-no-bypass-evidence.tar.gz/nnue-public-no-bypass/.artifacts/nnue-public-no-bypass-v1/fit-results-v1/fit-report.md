# ONE full-public no-bypass fit: verified saved results

The fresh candidate BEST has same-original-V row MSE **0.423870712170**, versus retained BEST51 **0.427440880985**: **0.835243% lower**, absolute change -0.003570168815. This is one retained-recipe fit on the opened selector V, not a playing-strength or promotion result.

![Saved learning curves](/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1/curves-render-v1/learning-curves-v3.png)

[Vector figure](/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1/curves-render-v1/learning-curves-v2.svg) · [Exact table CSV](/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1/curves-render-v1/same-V-table.csv) · [Bound summary](/workspaces/quoridor/.worktree/nnue-public-no-bypass/.artifacts/nnue-public-no-bypass-v1/curves-render-v1/summary.json)

## Same original V (419,150 eligible rows)

| Checkpoint        | Physical epoch | Completed updates | Training rows seen |      V row MSE | V sign accuracy | Saved saturation fraction |
| ----------------- | -------------: | ----------------: | -----------------: | -------------: | --------------: | ------------------------: |
| candidate INITIAL |              0 |                 0 |                  0 | 1.000000000000 |       0.000000% |                 0.000000% |
| candidate BEST    |             43 |           176,687 |        361,799,807 | 0.423870712170 |      84.311344% |                48.539664% |
| candidate LAST    |             46 |           189,014 |        387,041,654 | 0.423877643344 |      84.306334% |                48.561136% |
| retained BEST51   |             51 |           209,559 |        429,111,399 | 0.427440880985 |      84.131934% |                48.303471% |

The saved incumbent fixed-distance-only score has same-V MSE 0.855844157121. The candidate's zero-output-bypass baseline is 1.0; it is not the fixed-D model. These are reused saved metrics, not new evaluations.

## Curve and convergence domains

A/B show all saved full-V row MSE selector points: 47 candidate observations (INITIAL and 46 complete epochs) and 52 comparable incumbent saved points. No new incumbent fit or V forward was run. Panel B explicitly excludes INITIAL from its zoom.

Panel C keeps candidate full-T measurements (8,413,949 rows at epoch 1 and every 5) separate from the fixed T and V diagnostics (8,192 rows each). Fixed diagnostics do not select BEST. The x-axis is completed physical epochs, fractional for within-epoch diagnostics. Exact update/seen/wall domains remain in the saved CSVs and table.

Panel D shows saved learning-rate observations including warmup, with a log10 y-axis. The fit stopped EARLY_STOPPED with no fault after eight stale completed-epoch observations, epochs 39–46, relative to the last significant improvement at epoch 38 (absolute min_delta 0.0001). Strict BEST still improved at epoch 43 without resetting significant-improvement patience. The final observed LR was 0.000009765625; the configured minimum 0.000001 was not reached. No replacement epoch/update/wall/sample cutoff was introduced.

## Input, output and checkpoint coupling

T=8,413,949; opened V=419,150; sealed E was not opened. Dataset manifest SHA256 07d81abc2230b2fe6b7c5fb7a425e7e3109bf9af2c467f5c72f8d3bdb975279b. Original T-only scale: mu [0.10472780466079712, 0.09871304780244827], sigma [0.05110647529363632, 0.050166402012109756]; its effective FP32 values match retained incumbent scale.

The sole scientific change is the additive fixed-distance OUTPUT coefficient b=8→0 with explicit distance_bypass=false and a=0. Canonical QF1, raw wall D/80 before T normalization, standardized head D, Zero4, FP32 FT32/H32, tanh and existing row teacher z remain. Seed 32320261007, reflection 0.5/seed32320261008, batch2048, Adam0.01/wd0, warm257, plateau0.5/patience1, strict BEST and significant min_delta/early-stop8 were retained. Qualified supply_workers2 is explicit; the maintained default0 was not changed.

INITIAL/BEST/LAST checkpoint files and their native manifests/ordered LE-f32 payloads are frozen in the exact source map. INITIAL ordered parameters match 2ddacbf88145816b6b0c86e13ebb983d7c1b64e42f8d346623873a18ae7414ad; BEST ordered weights are 046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841; LAST ordered weights are 73b9b3d5a28cb7349c80b9beacfcb1880dd480af6d2e656a1521bf01c77fad81.

The existing initial CPU/CUDA/native head-input/finite/disposable-Adam qualification is reused within that initial scope. Trained BEST/LAST Torch/native correspondence, changed legal/delta/undo/finite/error evidence and inference/search cost remain unfinished. No trained native or playing-strength certificate is inferred from exported bytes.

## Available modelling observations and limits

BEST saved V sign accuracy is 84.311344%, versus incumbent 84.131934%. Saved saturation fractions are 48.539664% and 48.303471%. Candidate BEST saved mean prediction-minus-label bias is -0.0015030481492018081; LAST is -0.00034994502701965957. Incumbent bias is not in its supplied curve and remains UNKNOWN. Reliability bins, per-position action ranking and unlogged predictions remain UNKNOWN; no additional forwards were used to fill them. The opened V selects BEST, so this is not an independent sealed generalization estimate.

## Actual costs and cleanup

Controller START 2026-10-09T15:51:48.982147+00:00; worker source/cleanup STOP 2026-10-09T16:08:49.442948+00:00; controller STOP 2026-10-09T16:08:49.657021+00:00. External whole 1020.968283897s. Fit command 1018.703749152s and the trainer's own body wall 1018.106147993s are nested and not added. BEST selector point wall 952.504888687s; LAST selector point wall 1017.114980081s. Incumbent saved selector wall is historical, not a fresh matched throughput benchmark.

One fit command directly waited/reaped, all handles/process cleanup complete, exact child/guardian freshly absent, source/input after hashes exact, primary null, secondary[], remaining[]. Generated TMP was atomically retained under cleanup-v1; original failed qualification controllers, raw outputs, secondary errors, pending persisted masks and returned completed masks remain distinct. All failures and positive storage maxima are held without refund.

Sampled fit family RSS including controller reserve 2,882,838,528 B under the issued 10 GiB family bound; continuous peak remains UNKNOWN. Fit VRAM peak was not saved and remains UNKNOWN; the maintained whole-device 6 GiB guard and original per-process 5 GiB allocator were active. Initial qualification CUDA peak is not substituted as fit peak. The issued whole4GiB and all component upper bounds remain held.

The standard plotting package was absent and offline setup refused (no downloads/shared framework mutation). Existing ImageMagick rendered the bounded saved SVG coordinates; two missing SVG-delegate refusals and draft raster corrections are retained. Final readable PNG uses open segments and the correct legend colours. Rendering/collection made zero model/forward/fit/game calls.

## One-time presentation sequence

Deliver this exact verified report/figure/table to Root324 for the existing Policy human conversation. Candidate16 may enter only after the actual human presentation fact/reference is received and bound in the pre-arena entry. File creation, delivery acceptance, owner closure and native qualification are not that presentation. This imposes no new human approval or reply-only ACK. Independent trained-native/source qualification may proceed on fresh guards while only games wait. N, full-generation/four-fits96, defaults, seals and 323 USERPAUSE are unchanged.
