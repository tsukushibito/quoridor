"""353 scoped qualification caller; admitted lifetime guard precedes this module.

No fit or checkpoint selection. One disposable Adam update is discarded.
Actual packed Torch/native D inputs are compared; outputs need not equal the incumbent.
"""

import argparse
import hashlib
import json
from pathlib import Path
import time


ORDERED = ("ft.weight", "ft.bias", "h.weight", "h.bias", "out.weight", "out.bias")


def parameter_sha(model):
    digest = hashlib.sha256()
    state = model.state_dict()
    for key in ORDERED:
        digest.update(state[key].detach().cpu().numpy().astype("<f4").tobytes())
    return digest.hexdigest()


def actual_head_forward(model, x, d, side, observations):
    """Observe the maintained head input, with exact hook lifetime and restoration."""
    captured = []

    def observe(module, args):
        value = args[0].detach().cpu().numpy().copy()
        if value.shape != (len(d), 70):
            raise ValueError("actual FT32/H32/Zero4 head width")
        captured.append(value[:, 64:70])

    handle = None
    primary = None
    restoration = []
    try:
        # Registration itself may install the callback before raising/cancellation.
        handle = model.h.register_forward_pre_hook(observe)
        result = model(x, d, side)
        if len(captured) != 1:
            raise ValueError("exact one maintained head invocation")
        observations.append(captured[0])
        return result
    except BaseException as error:
        primary = error
        raise
    finally:
        if handle is not None:
            try:
                handle.remove()
            except BaseException as error:
                restoration.append(error)
        try:
            # Identity, not a table reset: foreign callbacks remain installed.
            hooks = model.h._forward_pre_hooks
            owned = [key for key, callback in hooks.items() if callback is observe]
            for key in owned:
                try:
                    del hooks[key]
                    model.h._forward_pre_hooks_with_kwargs.pop(key, None)
                except BaseException as error:
                    restoration.append(error)
        except BaseException as error:
            restoration.append(error)
        if restoration:
            first = primary if primary is not None else restoration[0]
            first.retained_observer_restoration_errors = tuple(restoration)
            for error in restoration:
                first.add_note("head observer restoration: " + repr(error))
            if primary is None:
                raise first


def finite_f32(np, value, shape, origin):
    """Validate already returned arrays before any tolerance arithmetic."""
    if not isinstance(value, np.ndarray) or value.shape != shape or value.dtype != np.float32:
        raise ValueError(origin + ": expected FP32 shape " + repr(shape))
    if not np.isfinite(value).all():
        raise ValueError(origin + ": nonfinite actual return")
    return value


def finite_correspondence(np, actual, reference, origin):
    finite_f32(np, actual, (4,), origin + " actual")
    finite_f32(np, reference, (4,), origin + " reference")
    errors = np.abs(actual - reference)
    finite_f32(np, errors, (4,), origin + " errors")
    maximum = float(np.max(errors))
    if not maximum <= 1e-5:
        raise ValueError(origin + ": finite correspondence error " + repr(maximum))


def captured_input_bits(np, captured, expected_d, origin):
    finite_f32(np, captured, (4, 6), origin + " head D/Zero4")
    bits = captured.view(np.uint32)
    if not np.array_equal(bits[:, :2], expected_d) or np.any(bits[:, 2:] != 0):
        raise ValueError(origin + ": actual standardized D/Zero4 bits")
    return bits


def qualify(config):
    from quoridor_training.common import resolve_config
    from quoridor_training.snapshot import write_json
    from quoridor_training.train import build_model, export, load
    from quoridor_training.cycle_process import execute

    import numpy as np
    import torch

    started = time.monotonic()
    if torch.__version__ != config["torch_version"] or not torch.cuda.is_available():
        raise ValueError("bound framework and original CUDA recipe required")
    torch.set_num_threads(2)
    torch.set_num_interop_threads(2)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    free, total = torch.cuda.mem_get_info()
    if free < 6 * 1024**3:
        raise ValueError("fresh qualification CUDA headroom for original allocator")
    torch.cuda.set_per_process_memory_fraction(min(5 * 1024**3 / total, 1.0))
    cfg = resolve_config(config["candidate_config"])
    old_cfg = resolve_config(config["incumbent_config"])
    scale = json.loads(Path(config["scale"]).read_text())
    torch.manual_seed(cfg["training"]["seed"])
    candidate = build_model(cfg["model"], scale)
    if parameter_sha(candidate) != config["initial_parameter_SHA256"]:
        raise ValueError("same ordered initialization before optimizer/qualification")
    incumbent = build_model(old_cfg["model"], scale)
    checkpoint = torch.load(config["incumbent_checkpoint"], map_location="cpu", weights_only=True)
    if checkpoint["target"] != "z" or checkpoint["dataset_sha"] != config["cache_manifest_SHA256"]:
        raise ValueError("incumbent dataset/teacher coupling")
    if (
        checkpoint["scale"]["mu_f32"] != scale["mu_f32"]
        or checkpoint["scale"]["sigma_f32"] != scale["sigma_f32"]
    ):
        raise ValueError("incumbent T-only scale")
    incumbent.load_state_dict(checkpoint["model"], strict=True)
    if parameter_sha(incumbent) != config["incumbent_parameter_SHA256"]:
        raise ValueError("accepted BEST51 ordered parameters")
    candidate.eval()
    incumbent.eval()
    output = Path(config["output"])
    output.mkdir(exist_ok=False)
    manifest = export(candidate, cfg, scale, {"a": 0, "b": 0}, output / "initial-model")
    native_path = output / "native-head-input.json"
    command = [
        config["native_image"],
        str(manifest),
        config["incumbent_manifest"],
        config["prefixes"],
        str(native_path),
    ]
    native_process = execute(command, output / "native.log", time.monotonic() + 30)
    native = json.loads(native_path.read_text())
    if native["model_calls"] != 8 or native["Search_calls"] != 0 or len(native["rows"]) != 4:
        raise ValueError("fixed native input-call scope")
    features = np.zeros((4, 2, 312), dtype=np.float32)
    for i, row in enumerate(native["rows"]):
        for view, ids in enumerate(row["ids_absolute_players"]):
            features[i, view, ids] = 1
    distance = np.asarray([row["raw_D_over80"] for row in native["rows"]], dtype=np.float32)
    sides = np.asarray([row["native_side"] + 1 for row in native["rows"]], dtype=np.int64)
    raw_bits = distance.view(np.uint32)
    expected_raw = np.asarray([row["raw_D_over80_bits"] for row in native["rows"]], dtype=np.uint32)
    if not np.array_equal(raw_bits, expected_raw):
        raise ValueError("actual native canonical D/80 input")
    observations = []
    with torch.inference_mode():
        cpu = actual_head_forward(
            candidate,
            torch.from_numpy(features),
            torch.from_numpy(distance),
            torch.from_numpy(sides),
            observations,
        ).numpy()
        old = actual_head_forward(
            incumbent,
            torch.from_numpy(features),
            torch.from_numpy(distance),
            torch.from_numpy(sides),
            observations,
        ).numpy()
    native_bits = np.asarray(
        [row["candidate_actual_head_D_bits"] for row in native["rows"]], dtype=np.uint32
    )
    candidate_bits = captured_input_bits(np, observations[0], native_bits, "CPU candidate")[:, :2]
    captured_input_bits(np, observations[1], native_bits, "CPU incumbent")
    native_cpu = np.asarray([row["candidate_value"] for row in native["rows"]], dtype=np.float32)
    native_old = np.asarray([row["incumbent_value"] for row in native["rows"]], dtype=np.float32)
    finite_correspondence(np, cpu, native_cpu, "CPU candidate/native")
    finite_correspondence(np, old, native_old, "CPU incumbent/native")
    candidate = candidate.to("cuda")
    with torch.inference_mode():
        cuda = (
            actual_head_forward(
                candidate,
                torch.from_numpy(features).cuda(),
                torch.from_numpy(distance).cuda(),
                torch.from_numpy(sides).cuda(),
                observations,
            )
            .cpu()
            .numpy()
        )
    captured_input_bits(np, observations[2], native_bits, "CUDA candidate")
    finite_correspondence(np, cuda, cpu, "CUDA candidate/CPU")
    corpus = load(config["cache"])
    if corpus.binding["dataset_sha"] != config["cache_manifest_SHA256"]:
        raise ValueError("actual original full public input binding")
    x, d, z = corpus.batch(np.arange(2048, dtype=np.int64))
    if not np.isin(z[:, 1], (-1, 1)).all():
        raise ValueError("actual original labelled T qualification batch")
    candidate.train()
    optimizer = torch.optim.Adam(candidate.parameters(), lr=cfg["optimizer"]["lr"], weight_decay=0)
    optimizer.zero_grad(set_to_none=True)
    prediction = candidate(
        torch.from_numpy(x).cuda(),
        torch.from_numpy(d).cuda(),
        torch.ones(2048, dtype=torch.long, device="cuda"),
    )
    loss = torch.nn.functional.mse_loss(prediction, torch.from_numpy(z[:, 1].copy()).cuda())
    loss.backward()
    if not torch.isfinite(loss) or any(
        p.grad is None or not torch.isfinite(p.grad).all() for p in candidate.parameters()
    ):
        raise ValueError("finite actual original-objective gradient")
    optimizer.step()
    if any(not torch.isfinite(p).all() for p in candidate.parameters()):
        raise ValueError("finite disposable optimizer update")
    corpus.verify_binding()
    torch.cuda.synchronize()
    write_json(
        output / "result.json",
        {
            "schema": "quoridor.public-no-bypass.numerical-qualification.v1",
            "Torch_invocations": 4,
            "Torch_rows": 2060,
            "native_model_calls": 8,
            "optimizer_disposable_updates": 1,
            "fit_calls": 0,
            "Search_calls": 0,
            "initial_parameter_SHA256": config["initial_parameter_SHA256"],
            "actual_head_D_bits": candidate_bits.tolist(),
            "actual_head_D_exact": True,
            "incumbent_output_equality_required": False,
            "native_process": native_process,
            "known_original_T_disposable_loss": float(loss),
            "wall_seconds": time.monotonic() - started,
            "CUDA_peak_allocated_B": torch.cuda.max_memory_allocated(),
            "CUDA_peak_reserved_B": torch.cuda.max_memory_reserved(),
            "scope": "changed input/parameterization/finite-optimizer qualification; no fit or selected trained candidate",
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    args = parser.parse_args()
    qualify(json.loads(args.config.read_text()))
