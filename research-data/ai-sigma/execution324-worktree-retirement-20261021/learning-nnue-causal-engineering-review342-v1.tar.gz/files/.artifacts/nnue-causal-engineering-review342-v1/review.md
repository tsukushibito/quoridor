# 342.13 source review

Source clearance is withheld: one failure-attribution blocker (R1), one ordinary counter-label finding (C1). This is a completed static review, not build/model/campaign qualification.

Target `c7f450c8c0063c8c9c373587e588ed5b04935b4b5a31af340e742326ccf810ad`; exact source/input/patch/plan rows are in before.json and after.json. All 11 SHA/size/mode triples match before/after (426420 directed bytes). Reverse-patch reconstruction independently matches all five declared original/postimage source hashes. The four original files retain their old production bytes outside additive routes/accessor/tests. Target685/companionfbcf provenance review9d06/controlbd88 is reused; model/ELF/PT/weights and original corpus/history payloads were not read.

## R1 — P1, preserve primary if both failure receipt and stderr fail

[Output::failure](/workspaces/quoridor/.worktree/nnue-causal-diagnostic/crates/quoridor-runner/src/causal_diagnostic.rs:555) calls `eprintln!` after `self.write("failure.json", ...)` returns Err. Production [run](/workspaces/quoridor/.worktree/nnue-causal-diagnostic/crates/quoridor-runner/src/causal_diagnostic.rs:1064) calls it before returning the original `outcome`.

Concrete branch: campaign already has an original Err E; owned failure.json creation/write/sync fails with S; stderr is broken/unavailable. Rust's `eprintln!` can panic on the stderr write failure. Expected: return E unchanged, retain S as secondary when an available channel permits, leave unentered work UNKNOWN. Actual source: panic can escape before `outcome` returns, contradicting the comment that secondary receipt failure cannot replace the primary. This is a static standard-library IO behavior counterexample; no live disk/pipe fault was executed.

Use a fallible, best-effort stderr write (or equivalent non-panicking fallback) whose IO Err is contained. Preserve the originating error and partial/INCOMPLETE facts; do not recursively report fallback failure. Add only an affected negative boundary assertion. No method/model change is needed.

## C1 — P2, name admitted attempts separately from real invocations

[Census::admit](/workspaces/quoridor/.worktree/nnue-causal-diagnostic/crates/quoridor-runner/src/causal_diagnostic.rs:172) increments calls/windows before session construction or the receipt worker can invoke Search. For example, [natural](/workspaces/quoridor/.worktree/nnue-causal-diagnostic/crates/quoridor-runner/src/causal_diagnostic.rs:266) session setup Err gives `calls=1` with Search invocations=0. [final report](/workspaces/quoridor/.worktree/nnue-causal-diagnostic/crates/quoridor-runner/src/causal_diagnostic.rs:1050) labels this `actual_search_calls`; analogous window count is admitted attempts, not guaranteed invocation/receipt count. Conservative node liability is appropriate and must remain charged. Rename these fields to admitted/attempted counts or separately record invocation/returned/validated counts; do not silently reinterpret them as successful complete searches.

## Verified source boundaries

The actual immutable plan/control reader hashes bounded canonical bytes before deserialize. Entry checks image/source/model identities, stopped review, nine affected test receipts, actual mapping replay equality and reused exact native proof before model loading. Current mapping replays genuine prefixes, checks STM/geometry/history SHA, both QF1 views and FP32 D/80 input bytes, and preserves unsupported mappings as UNKNOWN without replacement. Canonical legal terminal anchors stay separate from historical teacher provenance.

The twelve depth2 proposal results are reused. Ordered original/D/NN unique union and schedule are saved/synced before deeper, forced or timed results. Missing/partial proposals do not admit a substitute union. Forced children delegate canonical play/Search with sign reversal. One all-legal depth2 walk evaluates both canonical evaluators; any cap/error/cancel yields INCOMPLETE without a minimax claim. Tree-node liability is separate from deeper/caller liability. Fixed six-parent counts are <=144 search attempts, <=12 receipt windows, <=18 traces and <=54 standalone scores.

Receipt source delegates maintained alpha clock/Completion: 100ms, 5ms reserve, default depth64, authority timestamp before legality, matching worker join and session drop before the next caller. A returned engine Err cannot be rescued by an earlier completion. Intrusive Scalar FT/delta/head/components occur after plain receipts and are not claimed as performance shares or historical gradients. New component accessor delegates unchanged linear head and identical FP32 logit plus f64-tanh-to-f32 postprocess. No PVS/TT/rules/default/features/model/teacher change was found in the scoped patch.

Exclusive output leaves an INCOMPLETE marker and planned denominator, bounds allocation and retains primary Err when ordinary secondary publication succeeds. That favorable behavior does not cover R1's simultaneous fallback IO failure.

## Limits and stop

Nine Rust definitions remain UNBUILT/UNTYPED/UNRUN; no tests, target functions, imports, Search, geometry, model, native, Cargo/compiler, neural forward, timing or games were executed. Future controls must freeze the sole approved target685/companionfbcf and exact qualified image/source/input/model/resource identities; this review does not qualify a different target or a numeric entry. Live cleanup/allocator/IO/fault and current model parity are NOT_VERIFIED. Busy/ready Sigma and other actual fair work were not interrupted or reserved against.

Fixed-target reader/substantial source analysis STOP 2026-10-09T12:08:57.987844+00:00; owned readers/children/jobs/TMP remaining[]. Source/main/Git/index writes0. Evidence prewrite393216B < supported1048576B; all earlier reviews/fees/errors/UNKNOWN remain held. Two own administrative errors (initial dict-map assumption; unavailable local Rustdoc path) are retained, with no target change. Direct shell calls returned; uninstrumented continuous family peaks and total fees remain UNKNOWN. Only leaf342.13 may close; parent342.10 and campaign remain incomplete. No change to 323 pause, seals, defaults, N or fits.
