"""Bind the retained owned compiler namespace for unfinished qualification only."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat

BASE = Path(__file__).resolve().parents[1]
RECOVERY = Path(__file__).resolve().parent
FIRST = BASE / "source-qualification-v1"
WORKER = BASE / "qualification-preparation-v1/worker.py"


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            value.update(block)
    return value.hexdigest()


def save(name, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    allocated = sum(p.stat().st_blocks * 512 for p in RECOVERY.iterdir() if p.is_file())
    assert allocated + len(data) + 4096 <= 524288, "declared control growth bound"
    path = RECOVERY / name
    assert not path.exists(), str(path)
    path.write_bytes(data)
    return path


def main():
    guard = json.loads((FIRST / "guard.json").read_text())
    target = Path(guard["target"])
    signature = {
        "environment": {
            k: v
            for k, v in guard["compiler_environment"].items()
            if k not in {"TMPDIR", "PYTHONPATH", "PYTHONDONTWRITEBYTECODE"}
        },
        "compiler_and_lock": {
            p: sha
            for p, sha in guard["refs"].items()
            if p.endswith("Cargo.lock") or "/stable-x86_64-unknown-linux-gnu/bin/" in p
        },
        "features": ["research"],
        "profile": guard["profile"],
    }
    records, amount = [], 0
    for root, directories, files in os.walk(target, followlinks=False):
        for name in sorted(directories + files):
            path = Path(root) / name
            info = path.lstat()
            assert not stat.S_ISLNK(info.st_mode), str(path)
            amount += info.st_blocks * 512
            records.append(
                {
                    "relative_path": str(path.relative_to(target)),
                    "stat": [
                        info.st_dev,
                        info.st_ino,
                        info.st_mode,
                        info.st_size,
                        info.st_mtime_ns,
                    ],
                }
            )
    passed_executable = target / "debug/deps/quoridor_nnue-3376826b4f9572ab"
    assert passed_executable.is_file()
    lease = save(
        "retained-target-lease.json",
        {
            "target": str(target),
            "compiler_environment": signature,
            "records": records,
            "immutable_pass_payloads": {str(passed_executable): digest(passed_executable)},
            "previous_NNUE_six": "PASS once; no replay; unchanged NNUE source/dependencies",
            "allocated_namespace_sample_B": amount,
            "continuous_peak": "UNKNOWN",
            "previous_maximum_B": 224358400,
        },
    )
    guard["entry_ready"] = False
    guard["reuse_owned_target"] = True
    guard["retained_target_lease"] = str(lease)
    guard["compiler_environment_signature"] = signature
    guard["retained_build_roots"] = [str(FIRST / "private"), str(FIRST / "TMP")]
    for key in ("private", "TMP", "output"):
        guard[key] = str(RECOVERY / key)
    guard["receipt"] = str(RECOVERY / "receipt.json")
    guard["compiler_environment"]["TMPDIR"] = guard["TMP"]
    guard["commands"] = guard["commands"][1:]
    alpha = Path(guard["cwd"]) / "crates/quoridor-ai/src/alphabeta.rs"
    assert digest(alpha) == "e02a4337054a66ecc07e537d871e1b87d4c7597414bbdbe757ea06428357c6ca"
    guard["refs"][str(alpha)] = digest(alpha)
    guard["refs"][str(WORKER)] = digest(WORKER)
    for row in guard["reviewed_source_rows"]:
        if row["path"] == str(alpha):
            row.update(SHA256=digest(alpha), bytes=alpha.stat().st_size)
    binding = save(
        "source-binding.json",
        {
            "issue": guard["issue"],
            "source_STOP": datetime.now(timezone.utc).isoformat(),
            "rows": guard["reviewed_source_rows"],
            "prior_reviewed_binding": guard["source_binding"],
            "prior_reviewed_binding_SHA256": guard["source_binding_SHA256"],
            "delta": str(RECOVERY / "test-only-source-STOP.json"),
            "delta_SHA256": digest(RECOVERY / "test-only-source-STOP.json"),
            "review_scope": "prior342.6 source clear reused outside one transparent retained cfg(test) LEGACY argument repair",
            "NNUE_six": "actual prior6PASS retained; no replay",
            "remaining": "AI6/example/2Clippy/four GENERAL initial rows; NOT_RUN",
        },
    )
    guard["source_binding"] = str(binding)
    guard["source_binding_SHA256"] = digest(binding)
    for p in (
        binding,
        lease,
        RECOVERY / "test-only-source-STOP.json",
        RECOVERY / "cfg-test-legacy-domain.patch",
        FIRST / "failed-qualified-STOP-v1.json",
        FIRST / "output/NNUE-six.log",
    ):
        guard["refs"][str(p)] = digest(p)
    guard["control_source_STOP"] = datetime.now(timezone.utc).isoformat()
    guard["actual_peer_release_facts"]["342.3"] = (
        "d70f62cc ownerSTOP19:21:44.640258/all4waitcleanup[]/currentNONE/pilotNOT_READY; fresh checks still required"
    )
    guard["retained_uppers_RAW_fees_UNKNOWN"] = (
        "all held; firstFAILED whole28.22439295903314s; target counted once plus both old and new private/TMP; no freecache/refund"
    )
    guard["future_entry_predicates"] = (
        "genuinelyREADY D64 priority; fresh proof/source/compiler/physical/quiet; exact retained owned namespace check before and after canonical nonblocking lock; no idle reservation"
    )
    path = save("guard.json", guard)
    print(
        json.dumps({"guard": str(path), "lease_records": len(records), "target_sample_B": amount})
    )


if __name__ == "__main__":
    main()
