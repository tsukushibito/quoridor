"""Read-only main feature closure: exactly three finite Cargo checks."""

from datetime import datetime, timezone
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

BASE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "owned_qualification", BASE / "qualification-preparation-v1/worker.py"
)
shared = importlib.util.module_from_spec(spec)
spec.loader.exec_module(shared)
process = shared.process


def validate_main(guard, launch=False):
    shared.validate(guard, launch=launch)
    for path in guard["Cargo_config_absent"]:
        if Path(path).exists():
            raise ValueError("new unbound Cargo configuration: " + path)


def preserved_namespace(guard):
    lease = json.loads(Path(guard["preserved_lease"]).read_text())
    root = Path(lease["target"])
    for row in lease["records"]:
        info = (root / row["relative_path"]).lstat()
        actual = [info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns]
        if actual != row["stat"]:
            raise ValueError("retained owned namespace changed")


class Resources(shared.Resources):
    def check(self, owned=()):
        super().check(owned)
        new_storage = sum(
            shared.allocated(self.guard[key], self.unknown)
            for key in ("target", "TMP")
            if Path(self.guard[key]).exists()
        )
        self.sampled["new_MAIN_target_deps_TMP"] = max(
            self.sampled.get("new_MAIN_target_deps_TMP", 0), new_storage
        )
        if new_storage > self.guard["new_MAIN_upper_B"]:
            raise process.CycleStopped("MAIN target/deps/TMP exact supported gap")


def main():
    path = Path(sys.argv[1])
    guard = json.loads(path.read_text())
    if sys.argv[2:] == ["--check"]:
        validate_main(guard)
        shared.retained_target_check(guard)
        preserved_namespace(guard)
        print(
            json.dumps(
                {"check": True, "Cargo_native_model_calls": 0, "ready": guard["entry_ready"]}
            )
        )
        return
    guard_sha = shared.sha(path)
    if guard_sha != os.environ.get("QUORIDOR_GUARD_SHA256"):
        raise ValueError("immutable actual main-check guard digest")
    result = {
        "issue": guard["issue"],
        "status": "STARTED",
        "commands": [],
        "finalization_errors": [],
        "primary_error": None,
    }
    clock_start, primary, lock, resources = time.monotonic(), None, None, None
    try:
        validate_main(guard, launch=True)
        shared.retained_target_check(guard)
        preserved_namespace(guard)
        lock = open(guard["Cargo_lock"], "a+b")
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        validate_main(guard, launch=True)
        shared.retained_target_check(guard)
        preserved_namespace(guard)
        os.sched_setaffinity(0, set(guard["CPU"]))
        os.chdir(guard["cwd"])
        for key in ("target", "private", "TMP", "output"):
            Path(guard[key]).mkdir(parents=True, exist_ok=False)
        deadline = time.monotonic() + guard["max_runtime_seconds"]
        resources = Resources(guard, deadline)
        result["actualSTART"] = datetime.now(timezone.utc).isoformat()
        for entry in guard["commands"]:
            if shared.sha(path) != guard_sha:
                raise ValueError("immutable guard changed")
            validate_main(guard, launch=True)
            log = Path(guard["output"]) / (entry["name"] + ".log")
            record = shared.run_command(
                result, entry["name"], entry["argv"], log, deadline, resources
            )
            if record["log_bytes_seen"] > process.LOG_MAX_BYTES:
                raise ValueError("main-check log truncated; qualification UNKNOWN")
        result["status"] = "PASS"
    except BaseException as error:
        primary = error
        result.update(
            status="FAILED", primary_error={"type": type(error).__name__, "message": str(error)}
        )
    finally:
        result["actualSTOP"] = datetime.now(timezone.utc).isoformat()
        result["worker_whole_seconds"] = time.monotonic() - clock_start
        if resources:
            result["sampled"] = resources.sampled
            result["transient_census_UNKNOWN"] = resources.unknown
        result["continuous_peak"] = "UNKNOWN"
        for stage, action in [
            ("Cargo_lock_close", lambda: lock.close() if lock else None),
            ("preserved_namespace_after", lambda: preserved_namespace(guard)),
            (
                "source_after",
                lambda: result.update(
                    source_after_match=all(shared.sha(p) == sha for p, sha in guard["refs"].items())
                ),
            ),
            ("guard_after", lambda: result.update(guard_after_match=shared.sha(path) == guard_sha)),
        ]:
            try:
                action()
                if stage == "preserved_namespace_after":
                    result[stage] = True
            except BaseException as error:
                result["finalization_errors"].append(
                    {"stage": stage, "type": type(error).__name__, "message": str(error)}
                )
        try:
            process.write_json(Path(guard["receipt"]), result)
        except BaseException as error:
            if primary is None:
                primary = error
            else:
                primary.add_note("main-check receipt persistence: " + repr(error))
        if result["finalization_errors"] and primary is None:
            primary = RuntimeError("main-check finalization incomplete")
    if primary is not None:
        raise primary
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    with process.cancellation_signals():
        main()
