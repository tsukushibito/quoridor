"""New receipt-wrapper fake ports only; no real child or numerical calls."""

import ast
import json
from pathlib import Path
from types import SimpleNamespace
import unittest


source = Path(__file__).with_name("worker.py")
tree = ast.parse(source.read_text())
function = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == "run_command")
namespace = {"json": json, "process": SimpleNamespace()}
exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), "exec"), namespace)
run = namespace["run_command"]


class Port:
    def __init__(self, value=None, error=None):
        self.value, self.error = value, error

    def with_suffix(self, _suffix):
        return self

    def exists(self):
        return True

    def read_text(self):
        if self.error:
            raise self.error
        return json.dumps(self.value)


class ReceiptWrapper(unittest.TestCase):
    def test_returned_record_remains_distinct_from_persisted(self):
        record = {"signal_mask_restoration": "completed"}
        namespace["process"].execute = lambda *_args, **_kwargs: record
        result = {"commands": [], "finalization_errors": []}
        self.assertIs(run(result, "new", ["/fake"], Port(), 1, None), record)
        self.assertIs(result["commands"][0]["returned_record"], record)
        self.assertNotIn("persisted_record", result["commands"][0])

    def check_primary(self, port):
        primary = OSError("original execution failure")

        def fail(*_args, **_kwargs):
            raise primary

        namespace["process"].execute = fail
        result = {"commands": [], "finalization_errors": []}
        with self.assertRaises(OSError) as caught:
            run(result, "new", ["/fake"], port, 1, None)
        self.assertIs(caught.exception, primary)
        self.assertEqual(len(result["finalization_errors"]), 1)
        self.assertEqual(result["commands"], [])
        self.assertIn("failed receipt collection", primary.__notes__[0])

    def test_wrong_receipt_identity_preserves_primary(self):
        self.check_primary(Port({"command": ["/different"]}))

    def test_receipt_io_failure_preserves_primary(self):
        self.check_primary(Port(error=PermissionError("receipt denied")))


if __name__ == "__main__":
    unittest.main()
