"""Bind only the remaining Clippy and GENERAL initial qualification."""

from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import stat

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
PREVIOUS = BASE / "source-qualification-recovery-v2"
spec = importlib.util.spec_from_file_location("stopped_preparation", PREVIOUS / "prepare.py")
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.RECOVERY = ROOT


def main():
    guard = json.loads((PREVIOUS / "guard.json").read_text())
    target = Path(guard["target"])
    records = []
    for directory, dirs, files in os.walk(target, followlinks=False):
        for name in sorted(dirs + files):
            path = Path(directory) / name
            info = path.lstat()
            assert not stat.S_ISLNK(info.st_mode)
            records.append(
                {
                    "relative_path": str(path.relative_to(target)),
                    "stat": [
                        info.st_dev,
                        info.st_ino,
                        info.st_mode,
                        info.st_size,
                        info.st_mtime_ns,
                    ],
                }
            )
    first_lease = json.loads((PREVIOUS / "retained-target-lease.json").read_text())
    immutable = first_lease["immutable_pass_payloads"]
    for path, expected in immutable.items():
        assert helper.digest(path) == expected
    example = target / "debug/examples/step_reference"
    immutable[str(example)] = helper.digest(example)
    lease = helper.save(
        "retained-target-lease.json",
        {
            "target": str(target),
            "compiler_environment": guard["compiler_environment_signature"],
            "records": records,
            "immutable_pass_payloads": immutable,
            "previous_pass_scopes": "NNUE6/AI6/examplebuild/NNUEClippy all retained; none replayed",
            "retained_sample_max_B": 281575424,
            "continuous_peak": "UNKNOWN",
        },
    )
    guard["retained_target_lease"] = str(lease)
    guard["retained_build_roots"] += [str(PREVIOUS / "private"), str(PREVIOUS / "TMP")]
    for key in ("private", "TMP", "output"):
        guard[key] = str(ROOT / key)
    guard["receipt"] = str(ROOT / "receipt.json")
    guard["compiler_environment"]["TMPDIR"] = guard["TMP"]
    guard["commands"] = [
        entry for entry in guard["commands"] if entry["name"] == "AI-scoped-Clippy"
    ]
    assert len(guard["commands"]) == 1
    alpha = Path(guard["cwd"]) / "crates/quoridor-ai/src/alphabeta.rs"
    for row in guard["reviewed_source_rows"]:
        if row["path"] == str(alpha):
            row.update(SHA256=helper.digest(alpha), bytes=alpha.stat().st_size)
    binding = helper.save(
        "source-binding.json",
        {
            "issue": guard["issue"],
            "source_STOP": datetime.now(timezone.utc).isoformat(),
            "rows": guard["reviewed_source_rows"],
            "previous_binding": guard["source_binding"],
            "previous_binding_SHA256": guard["source_binding_SHA256"],
            "cfg_test_delta": str(ROOT / "test-only-source-STOP.json"),
            "cfg_test_delta_SHA256": helper.digest(ROOT / "test-only-source-STOP.json"),
            "review_scope": "342.6 source clear plus two mechanical cfg(test) deltas; unchanged production and new12PASS scope",
        },
    )
    guard["source_binding"] = str(binding)
    guard["source_binding_SHA256"] = helper.digest(binding)
    for path, expected in guard["refs"].items():
        actual = helper.digest(path)
        if path != str(alpha):
            assert actual == expected, "unchanged dependency changed: " + path
    guard["refs"][str(alpha)] = helper.digest(alpha)
    for path in [
        binding,
        lease,
        ROOT / "test-only-source-STOP.json",
        ROOT / "cfg-test-chunk-decoding.patch",
        ROOT / "prewrite.json",
        ROOT / "prepare.py",
        PREVIOUS / "failed-qualified-STOP-v2.json",
        PREVIOUS / "output/AI-six.log",
        PREVIOUS / "output/native-example-build.log",
        PREVIOUS / "output/NNUE-scoped-Clippy.log",
        example,
    ]:
        guard["refs"][str(path)] = helper.digest(path)
    guard["entry_ready"] = False
    guard["control_source_STOP"] = datetime.now(timezone.utc).isoformat()
    guard["retained_uppers_RAW_fees_UNKNOWN"] = (
        "all original components held; previous target/private/TMP281575424 sampled, continuous/transient UNKNOWN; knowncontrollers44.46683627204038; no refunds"
    )
    guard["actual_peer_release_facts"]["342.3"] = (
        "direct source/preflightSTOP19:36:13.276737/no job/pilotNOT_READY, before own24ddSTOP19:37:20.975557; fresh checks still required"
    )
    helper.save("guard.json", guard)
    print(
        json.dumps(
            {
                "lease_records": len(records),
                "remaining_commands": [x["name"] for x in guard["commands"]],
            }
        )
    )


if __name__ == "__main__":
    main()
