# 342.2 maintained score/native implementation handoff

The current implementation and initial qualification are ready for sole324
integration. `binding.json` binds ten changed AI/NNUE paths and nine unchanged
dependencies against `e2e7181`; `search-native-maintained.patch` has a successful
read-only reverse-apply check. Source formatting passed for all ten owned Rust
files. No main, index, commit, foreign source or managed-worktree write occurred.

The explicit `quoridor-nnue-distance-step-v1` loader keeps raw integer canonical
opponent-minus-STM distance separate from normalized D/80 head inputs. A/B/C add
the integer bypass once; D retains the distance inputs without the bypass. Raw
and `80*tanh(raw/80)` deployment views are explicit. Step-specific strict nested
topology parsing leaves the legacy topology format unchanged. Parameter shape,
SHA, finite values, effective FP32 normalizers, score units, recipe and bounds
are checked before model admission. The outward envelope covers the full encode
and up to 200 general delta transitions; unsafe bounds refuse without clipping.
Shared linear-head extraction preserves the ordered legacy arithmetic. The
original DistanceEvaluator nonterminal expression and default LEGACY search
convention remain unchanged.

The maintained interfaces are `StepModel::{load,load_bytes,full_context,
delta_move_into,delta_context,evaluate_with_scratch,nonterminal_abs_bound}`,
`ScoreDomain::{common,checked}`, typed `GoalPlayer`, `GoalSign` and
`TerminalOutcome::from_context`, and `DistanceStepEvaluator::{new,session,
reset_session}`. Callers freeze one common dominant terminal domain across all
permitted opponents/views before creating sessions. The evaluator's TT identity
includes model, view, units, bypass, scale, parameter/input fingerprint, FT mode
and domain bits. Reset clears the table and accounting. Real canonical goal and
threefold terminal paths precede static/neural evaluation; an operational cap is
not a draw. Position-only and GENERAL numerical APIs cannot establish history
or legal-geometry provenance.

## Joined affected qualification

| Actual job | Whole controller seconds | Accepted executed scope                                                                |
| ---------- | -----------------------: | -------------------------------------------------------------------------------------- |
| bc089429   |        28.22439295903314 | Six NNUE definitions PASS; AI compile failed before execution                          |
| 24dd187a   |       16.242443313007243 | Six AI definitions, reference example build, NNUE scoped Clippy PASS; AI Clippy failed |
| 3fc531ed   |        2.299106835038401 | Quiet refusal before Cargo/native/Search/model/lock acquisition                        |
| 1e0068e3   |       2.7122136870166287 | Remaining AI scoped Clippy and four GENERAL initial native rows PASS                   |

The twelve distinct new Rust definitions ran once. Successful tests/build/Clippy
stages were joined rather than replayed. Two retained cfg(test) repairs supplied
LEGACY to the table argument and replaced fixed-size chunk decoding with the
same fixed-array operation. Production bytes outside these test deltas are
unchanged from the reviewed packet. The source clear from SAME342.6 is reused
only in its unchanged scope. All failed statuses, original logs and fees remain
held. The known controller sum is **49.47815679409541 seconds**; nested command
spans are not added. Unmetered source/support costs remain UNKNOWN.

The NNUE definitions exercise views, bypass/distance consistency, finite and
saturation refusal, outward bounds, strict manifests/parameter bytes, checked
and general delta ownership/error recovery and legacy ordered postprocessing.
AI definitions exercise typed terminal/finite successor edges, genuine goals,
nonterminal and repeating cap-boundary fixtures, independent complete small-tree
raw/F minimax with PVS re-search, TT reset/namespace and nested search,
cancellation/error restoration. Finite fixtures are not universal FT bit
identity, all-model correctness or live OS/fault recovery certificates.

## Initial native representation

One private example process returned exactly four GENERAL rows using the single
retained 12321-element LE-f32 parameter file SHA
`7dd66213177996ba30a8ec7e729299322c10cc616fba202ae326c7dbc6a63708`.
The private ELF SHA is
`b3e8aa5214ef66d14b8ebcbc9383c70481361c2ba48185a3480f21ec122b5f00`
(1771944 bytes, mode0755), matching the actual compiled target payload. Rust1.99,
dev/test opt0, debug0 and the actual source/lock/compiler/flags are bound by the
qualification receipts; this is a correctness variant without cost claims.

| View  | Saved Torch value |      Native value | Raw native steps | Value difference |
| ----- | ----------------: | ----------------: | ---------------: | ---------------: |
| A-F   | 7.973439693450928 | 7.973439693450928 |                8 |                0 |
| B-F   | 7.973439693450928 | 7.973439693450928 |                8 |                0 |
| C-raw |                 8 |                 8 |                8 |                0 |
| D-F   |                 0 |                 0 |                0 |                0 |

The inputs are empty QF1 ID sets/all-zero features, native side0, normalized
FP32 distances .1/.2 and independent integer distances8/16. They are synthetic
GENERAL mathematics, not legal Quoridor geometry or genuine game histories.
Raw8/0 are analytic zero-head components, not additional Torch predictions.
There were four native attempts/returns/validations and zero new Torch
forwards, optimizer, fits, games or cost measurements. Exported and derived raw
bounds agree exactly: A/B/C80.00001525878906, D0. ScalarFT and available/selected
guarded AVX2 head flags were observed; physical kernels remain UNKNOWN. The
separate legal codec rows have no saved Torch predictions and inherit none of
this synthetic forward evidence. Later trained-model16 references, trained
six-view qualification, cold-cost work and96 development games remain NOT_RUN.

## STOP, resources and retained facts

The last job's authoritative START is19:55:20.553253Z, worker STOP19:55:22.312835Z
and controller STOP19:55:23.265086Z on2026-10-08. Both direct commands were waited,
handles closed and process cleanup remaining[]; both child identities plus the
guardian were freshly absent. The completed notifier is separate metadata and
is not killed or treated as computation. Returned mask/final-persist completion
and persisted pending/attempted fields are retained distinctly. Source103 refs
and guard match after STOP. Current-next owned Cargo/native/model/fair reservation
is NONE; this handoff is source/text only.

Whole support remains1536MiB under44c71/68f, including all original component
uppers and prior RAW/assets/failures/UNKNOWNs. Last sampled family335708160 bytes
includes64MiB control, phase-with-checkout419397632 and joint
build/private/TMP283365376. These are sampled observations; continuous/transient
peaks remain UNKNOWN. The small v2 control forecast524288 was exceeded by its
688128-byte saved control/raw footprint; that miss is preserved within the
unchanged268MiB component, without retrospective PASS or refund. The v3 refusal
coincided with actual324 maintenance; the detected PID was not recorded, so its
supplemental chronology does not reconstruct an exact detector identity.
The earlier18:22:20 fake-port scheduling deviation and344's later chronology
remain in the bound evidence; no raw rewrite, rescue or reweighting occurred.

`qualified-STOP-v4.json` and the three earlier receipts are linked by
`binding.json`; raw logs/process records and private source/compiler/payload
bindings stay at their existing paths. N remains null. This implementation does
not lift323 USERPAUSE, change models/defaults/seals, authorize training/full
quantity or adopt the contact, ordering or solver experiments. Sole324 integrates
the stopped patch; task342.2 remains in_progress until verified scoped acceptance.
