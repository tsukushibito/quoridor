"""Finite affected score qualification, using maintained child ownership."""

from datetime import datetime, timezone
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import stat
import sys
import time

from quoridor_training import cycle_process as process


def sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            value.update(block)
    return value.hexdigest()


def allocated(root, unknown):
    pending, total = [Path(root)], 0
    while pending:
        path = pending.pop()
        try:
            info = path.lstat()
            if stat.S_ISLNK(info.st_mode):
                raise ValueError("owned allocation symlink refused: " + str(path))
            total += info.st_blocks * 512
            if stat.S_ISDIR(info.st_mode):
                pending.extend(path.iterdir())
        except FileNotFoundError:
            if len(unknown) < 16:
                unknown.append({"path": str(path), "transient_peak": "UNKNOWN"})
            elif len(unknown) == 16:
                unknown.append(
                    {"additional_transient_paths": "NOT_RETAINED", "transient_peak": "UNKNOWN"}
                )
    return total


def quiet(owned=()):
    ancestors, pid = set(), os.getpid()
    while pid and pid not in ancestors:
        ancestors.add(pid)
        info = process.process_info(pid)
        pid = info["parent"] if info else 0
    found = []
    for path in Path("/proc").iterdir():
        if not path.name.isdigit() or int(path.name) in ancestors:
            continue
        try:
            args = [os.fsdecode(x) for x in (path / "cmdline").read_bytes().split(b"\0") if x]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not args:
            continue
        name = Path(args[0]).name
        named = name in {
            "cargo",
            "rustc",
            "clippy-driver",
            "perf",
            "quoridor-arena",
            "quoridor-runner",
            "quoridor-research",
            "chrome",
            "chromium",
            "chromium-browser",
            "step_reference",
        } or name.startswith(("nnue_search-", "quoridor_ai-", "quoridor_nnue-", "criterion_bench-"))
        if name.startswith("python"):
            script_args = [x for x in args[1:] if not x.startswith("-")]
            if script_args:
                script = Path(script_args[0])
                named |= ".artifacts" in script.parts and script.suffix == ".py"
                if script.name == "research-job.py" and "run" in args:
                    # A controller is metadata only after its canonical finished receipt.
                    canonical = Path("/workspaces/quoridor/scripts/dev/research-job.py")
                    known_python = {
                        Path(p).resolve()
                        for p in (
                            "/usr/bin/python3",
                            "/home/vscode/.cache/inference/envs/quoridor-research-team/bin/python",
                        )
                    }
                    if (
                        script.resolve() != canonical
                        or Path(args[0]).resolve() not in known_python
                        or len(args) != 6
                        or args[1:5] != ["-B", str(canonical), "run", "--state-dir"]
                    ):
                        named = True
                    else:
                        try:
                            directory = Path(args[args.index("--state-dir") + 1])
                            state = json.loads((directory / "state.json").read_text())
                            result = json.loads((directory / "result.json").read_text())
                            named |= not (
                                directory.is_absolute()
                                and state.get("phase") == "finished"
                                and state.get("job_id") == result.get("job_id")
                                and state.get("supervisor")
                                == process.identity(process.process_info(int(path.name)))
                                and result.get("direct_child_reaped") is True
                                and result.get("cleanup_complete") is True
                                and result.get("remaining") == []
                            )
                        except (OSError, ValueError, IndexError):
                            named = True
        if named:
            info = process.process_info(int(path.name))
            if info and info["state"] != "Z":
                if process.identity(info) in owned:
                    continue
                parent, visited = info["parent"], set()
                while parent and parent not in visited and parent != os.getpid():
                    visited.add(parent)
                    parent_info = process.process_info(parent)
                    parent = parent_info["parent"] if parent_info else 0
                if parent == os.getpid():
                    continue
                found.append(process.identity(info))
    return found


class Resources(process.CycleResources):
    def __init__(self, guard, deadline):
        super().__init__(guard, guard["phase"], deadline)
        self.guard = guard
        self.unknown = []
        self.sampled = {
            "family_RSS_including_control": 0,
            "phase_with_checkout_reserve": 0,
            "target_private_TMP": 0,
        }

    def check(self, owned=()):
        super().check(owned)
        if quiet(owned):
            raise process.CycleStopped("intervening actual foreign hardware work")
        infos = [
            process.process_info(os.getpid()),
            *(process.process_info(x["pid"]) for x in owned),
        ]
        rss = sum(x["rss"] for x in infos if x) + self.guard["controller_reserve_bytes"]
        amount = allocated(self.guard["phase"], self.unknown) + self.guard["checkout_reserve_bytes"]
        build = sum(
            allocated(self.guard[key], self.unknown)
            for key in ("target", "private", "TMP")
            if Path(self.guard[key]).exists()
        )
        build += sum(
            allocated(path, self.unknown) for path in self.guard.get("retained_build_roots", [])
        )
        for key, value in [
            ("family_RSS_including_control", rss),
            ("phase_with_checkout_reserve", amount),
            ("target_private_TMP", build),
        ]:
            self.sampled[key] = max(self.sampled[key], value)
        if (
            rss > self.memory_limit
            or amount > self.guard["whole_bytes"]
            or build > self.guard["build_private_TMP_bytes"]
        ):
            raise process.CycleStopped("inclusive family/whole/build storage guard")


def validate(guard, launch=False):
    if launch and guard.get("entry_ready") is not True:
        raise ValueError("source preparation only; immutable admission is not ready")
    for path, expected in guard["refs"].items():
        if sha(path) != expected:
            raise ValueError("bound source/compiler/payload/proof changed: " + path)
    for row in guard["reviewed_source_rows"]:
        info = Path(row["path"]).stat()
        if info.st_size != row["bytes"] or stat.S_IMODE(info.st_mode) != row["mode"]:
            raise ValueError("reviewed source size/mode changed: " + row["path"])
    proof = json.loads(Path(guard["proof"]).read_text())
    section = proof["phases"]["search"]
    if (
        section["whole_bytes"] != guard["whole_bytes"]
        or sum(section["components_bytes"].values()) != guard["whole_bytes"]
    ):
        raise ValueError("whole-phase allocator proof")
    if proof["parent_proof"]["cap_bytes"] != 50000000000:
        raise ValueError("parent decimal capacity proof")
    competitors = quiet()
    if competitors:
        raise process.CycleStopped(
            "actual foreign compiler/model/fair/browser/fixture: " + repr(competitors)
        )
    if process.available_memory() < guard["max_memory_bytes"] + guard["host_ram_reserve"]:
        raise process.CycleStopped("fresh physical host/family memory headroom")
    if shutil.disk_usage(guard["phase"]).free < guard["whole_bytes"]:
        raise process.CycleStopped("fresh physical storage headroom")
    if not set(guard["CPU"]).issubset(os.sched_getaffinity(0)):
        raise ValueError("actual CPU affinity availability")
    for key, value in guard["compiler_environment"].items():
        if os.environ.get(key) != value:
            raise ValueError("effective compiler environment: " + key)


def check_tests(log, expected):
    text = Path(log).read_text()
    actual = {
        line.split()[1]
        for line in text.splitlines()
        if line.startswith("test ") and line.endswith(" ... ok")
    }
    if actual != set(expected) or f"test result: ok. {len(expected)} passed; 0 failed;" not in text:
        raise ValueError("affected executed test census differs from frozen definitions")


def retained_target_check(guard):
    target = Path(guard["target"])
    if not guard.get("reuse_owned_target"):
        if target.exists():
            raise ValueError("new target already exists")
        return
    if target.is_symlink() or not target.is_dir():
        raise ValueError("declared owned retained target missing or symlinked")
    lease = json.loads(Path(guard["retained_target_lease"]).read_text())
    if (
        lease["target"] != str(target)
        or lease["compiler_environment"] != guard["compiler_environment_signature"]
    ):
        raise ValueError("retained namespace/compiler/profile lease")
    for row in lease["records"]:
        path = target / row["relative_path"]
        info = path.lstat()
        if [info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns] != row["stat"]:
            raise ValueError("retained namespace changed before entry: " + str(path))
    for path, expected in lease["immutable_pass_payloads"].items():
        if sha(path) != expected:
            raise ValueError("previous PASS payload changed: " + path)


def run_command(result, name, command, log, deadline, resources):
    try:
        record = process.execute(command, log, deadline, resources=resources)
    except BaseException as primary:
        receipt = log.with_suffix(".process.json")
        try:
            if receipt.exists():
                record = json.loads(receipt.read_text())
                if record["command"] != command:
                    raise ValueError("failed receipt command binding")
                result["commands"].append({"name": name, "persisted_record": record})
        except BaseException as secondary:
            result["finalization_errors"].append(
                {
                    "stage": "failed receipt",
                    "type": type(secondary).__name__,
                    "message": str(secondary),
                }
            )
            primary.add_note("failed receipt collection: " + repr(secondary))
        raise
    result["commands"].append({"name": name, "returned_record": record})
    return record


def main():
    guard_path = Path(sys.argv[1])
    guard = json.loads(guard_path.read_text())
    if sys.argv[2:] == ["--check"]:
        validate(guard)
        print(
            json.dumps(
                {
                    "source_proof_physics_check": True,
                    "entry_ready": guard["entry_ready"],
                    "Popen_native_model_calls": 0,
                }
            )
        )
        return
    guard_sha = sha(guard_path)
    if guard_sha != os.environ.get("QUORIDOR_GUARD_SHA256"):
        raise ValueError("actual immutable guard digest is not bound by launch argv")
    result = {
        "issue": guard["issue"],
        "commands": [],
        "status": "STARTED",
        "primary_error": None,
        "finalization_errors": [],
    }
    started, primary, lock, resources = time.monotonic(), None, None, None
    try:
        validate(guard, launch=True)
        retained_target_check(guard)
        lock = open(guard["Cargo_lock"], "a+b")
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        validate(guard, launch=True)
        retained_target_check(guard)
        os.sched_setaffinity(0, set(guard["CPU"]))
        os.chdir(guard["cwd"])
        if not guard.get("reuse_owned_target"):
            Path(guard["target"]).mkdir(parents=True, exist_ok=False)
        for key in ("private", "TMP", "output"):
            Path(guard[key]).mkdir(parents=True, exist_ok=False)
        deadline = time.monotonic() + guard["max_runtime_seconds"]
        resources = Resources(guard, deadline)
        result["actualSTART"] = datetime.now(timezone.utc).isoformat()
        for entry in guard["commands"]:
            if sha(guard_path) != guard_sha:
                raise ValueError("active guard source changed")
            name, command = entry["name"], entry["argv"]
            validate(guard, launch=True)
            log = Path(guard["output"]) / (name + ".log")
            run_command(
                result,
                name,
                command,
                log,
                min(deadline, time.monotonic() + guard["per_command_seconds"]),
                resources,
            )
            if entry.get("tests"):
                check_tests(log, entry["tests"])
            if result["commands"][-1]["returned_record"]["log_bytes_seen"] > process.LOG_MAX_BYTES:
                raise ValueError("compiler proof log was truncated; qualification UNKNOWN")
            for line in log.read_text().splitlines():
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                if isinstance(row, dict) and row.get("reason") == "compiler-artifact":
                    result.setdefault("compiler_artifacts", []).append(
                        {"command": name, "row": row}
                    )
        executable = Path(guard["target"]) / "debug/examples/step_reference"
        private = Path(guard["private"]) / "step_reference"
        shutil.copyfile(executable, private)
        private.chmod(0o755)
        result["private_payload"] = {
            "path": str(private),
            "SHA256": sha(private),
            "bytes": private.stat().st_size,
            "mode": stat.S_IMODE(private.stat().st_mode),
            "same_target_SHA": sha(private) == sha(executable),
        }
        validate(guard, launch=True)
        if sha(guard_path) != guard_sha:
            raise ValueError("guard changed before native initial qualification")
        log = Path(guard["output"]) / "initial-native-four.log"
        run_command(
            result,
            "initial-native-four",
            [str(private), guard["initial_request"]],
            log,
            min(deadline, time.monotonic() + 30),
            resources,
        )
        native = json.loads(log.read_text())
        if (
            native["schema"] != "nnue-distance-step-general-reference-result-v1"
            or len(native["rows"]) != 4
        ):
            raise ValueError("initial GENERAL four-row native output")
        checks = []
        for row, condition in zip(native["rows"], "ABCD", strict=True):
            value, raw = row["value"]["value"], row["value"]["raw_steps"]
            expected = guard["expected_values"][condition]
            if (
                row["weights_SHA"] != guard["weights_SHA"]
                or not math.isfinite(value)
                or abs(value - expected) > 1e-5 + 1e-4 * abs(expected)
                or raw != guard["expected_raw_analytic"][condition]
            ):
                raise ValueError("initial native reference discrepancy: " + condition)
            checks.append(
                {
                    "condition": condition,
                    "reference": expected,
                    "value": value,
                    "difference": value - expected,
                    "raw_steps": raw,
                    "raw_reference_scope": "analytic zero-head; not Torch observation",
                }
            )
        result["initial_general_parity"] = checks
        result["initial_native_attempted_returned_validated"] = [4, 4, 4]
        result["status"] = "PASS"
    except BaseException as error:
        primary = error
        result.update(
            status="FAILED", primary_error={"type": type(error).__name__, "message": str(error)}
        )
    finally:
        result["actualSTOP"] = datetime.now(timezone.utc).isoformat()
        result["whole_seconds"] = time.monotonic() - started
        if resources:
            result["sampled"] = resources.sampled
            result["transient_census_UNKNOWN"] = resources.unknown
        result["continuous_peak"] = "UNKNOWN"
        for stage, action in [
            ("Cargo_lock_close", lambda: lock.close() if lock else None),
            (
                "source_after_check",
                lambda: result.update(
                    source_after_match=all(
                        sha(p) == expected for p, expected in guard["refs"].items()
                    )
                ),
            ),
            (
                "guard_after_check",
                lambda: result.update(guard_after_match=sha(guard_path) == guard_sha),
            ),
        ]:
            try:
                action()
            except BaseException as error:
                result["finalization_errors"].append(
                    {"stage": stage, "type": type(error).__name__, "message": str(error)}
                )
        try:
            process.write_json(Path(guard["receipt"]), result)
        except BaseException as error:
            result["finalization_errors"].append(
                {"stage": "receipt_persist", "type": type(error).__name__, "message": str(error)}
            )
            print(json.dumps(result), flush=True)
            if primary is None:
                primary = error
            else:
                primary.add_note("receipt persistence failed: " + repr(error))
    if primary:
        raise primary
    if (
        result["finalization_errors"]
        or not result.get("source_after_match")
        or not result.get("guard_after_match")
    ):
        raise ValueError("source/outer finalization refusal")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    with process.cancellation_signals():
        main()
