# 420.2 関連交点確認 — 固定参照の変更でclear保留

対象はMain `f0f3715`、疎合成 `5afe0e391cec05d9c78afab0fa95ab078c827097` とPython admissionの2関数、保存後stdout receiptだけです。元420 source clear/CLOSEDは変更していません。

**source_clear=false / blockers=1 / ordinary=0。実装上の欠陥を認定したものではありません。** 最初のチェッカー実行では8 Main subjectと保護対象419の5 sourceのSHA/size/mode、measurement joinの厳密forward/inverse、419のroot_spec/prepare_roots/replay/load_residual_modelのbyte一致を確認しました。その後、自作チェッカーのpub(crate)関数読取を直して再実行した際、sigma_evaluator_tests.rsが固定参照から変わっていました。

- 固定: `1b595f65d8d179287b30c88f76f2f86f8808a5d8a4e59f73b41f9619f3e263e0` / 12194B / 0644
- 観測: `f4544f8b36e53da0221d2406a4ad93b0379db9c776cace70495f581d88088cd6` / 12294B / 0644

変更後の本文は評価せず、その場で対象読取を停止しました。after mapの残りはUNKNOWNで、全チェッカーPASSとはしていません。必要な普通修復は同担当がこの新差分と固定postimageを束縛することだけです。旧7path全レビューや成功suiteの再演は不要です。

読めた交点では、Nの419 canonical loader、loss専用分岐、prepare_roots(...,false)、Sigmaの同一Arcとdrop前work取得が保たれ、Sigma+lossは入口拒否です。Pythonは入力/library/CPU設定と閉じたnamespaceの形を検査し、最終hash計算と実loaded identity照合はRustに残ります。D/NNUE枝を置換していません。measurement::runはOutput.finish後に戻るため、mainのrecords_savedは保存のreceiptであり、COMPLETE/有効勝敗/棋力成功を意味しません。これらは停止までの静的所見で、変動した固定target全体のclearではありません。

供給済みNN0一件のPASSはmetadata AST/fake入力の作者証拠のみ。今回は実行していません。Rust定義・型・compile・実reference・モデル/library・native/inference/Search/gameは未資格のままです。実reference input/outputはdispatch時ABSENT。性能・棋力・因果・default採用・数値入場は認めません。

Reader STOP: **2026-10-15T22:05:46.934682+00:00**。owned readers/children/jobs/TMP/handles/leases/remainingはすべて[]。canonical leaseは取得していません。有限read-only subprocessは同期return/reap済み。通常toolの完全なchild identity/handle receiptおよび連続family peakはUNKNOWNです。対象source/Main/Git/indexへのwriteは0。元失敗・RAW・費・mask/UNKNOWNとpause/sealは保持しています。
