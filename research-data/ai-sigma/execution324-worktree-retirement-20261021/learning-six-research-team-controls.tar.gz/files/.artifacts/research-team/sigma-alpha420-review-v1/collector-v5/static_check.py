"""One collector map insertion, test-definition custody, no target execution."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import time

OWN = Path(__file__).parent
ROOT = Path("/workspaces/quoridor")
TARGET = (
    ROOT
    / ".artifacts/research-team/integration324/sigma-alpha420-v1/arena-collector-repair-v1/proof.json"
)
resource.setrlimit(resource.RLIMIT_AS, (805306368, 805306368))
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(path, expected=None):
    p = Path(path)
    assert not p.is_symlink()
    raw = p.read_bytes()
    ref = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    if expected:
        assert ref == {k: expected[k] for k in ref}, (ref, expected)
    if str(p) in refs:
        assert ref == refs[str(p)]
    refs[str(p)] = ref
    return raw


def git(*args):
    p = subprocess.run(["git", *args], cwd=ROOT, capture_output=True, check=True, timeout=20)
    return p.stdout


entry = now()
raw = read(TARGET)
assert (
    hashlib.sha256(raw).hexdigest()
    == "2246f370f81f808227201fdfb76f95d986349539b485857f6a6ddc064e9c26ad"
)
target = json.loads(raw)
old = gzip.decompress(read(target["before_gzip"]["path"], target["before_gzip"]))
assert hashlib.sha256(old).hexdigest() == target["before_sha256"]
path = "scripts/dev/research-lifecycle.py"
assert old == git("show", f"{target['before_git']}:{path}")
current = read(target["after"]["path"], target["after"])
assert current == git("show", f"8be646b:{path}")
insertion = b'                        "sigma_value": ("sigma-value-onnx-cpu",),\n'
assert current.count(insertion) == 1 and current.replace(insertion, b"") == old
delta = git(
    "diff",
    "--no-ext-diff",
    "--no-color",
    "--no-renames",
    target["before_git"],
    "8be646b",
    "--",
    path,
)
lines = delta.splitlines(keepends=True)
at = next(i for i, line in enumerate(lines) if line.startswith(b"--- "))
parser_path = OWN.parent / "static_check.py"
node = next(
    n
    for n in ast.parse(parser_path.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name == "apply"
)
scope = {"re": re}
exec(compile(ast.Module(body=[node], type_ignores=[]), str(parser_path), "exec"), scope)
forward, n = scope["apply"](old, b"".join(lines[at:]))
inverse, m = scope["apply"](current, b"".join(lines[at:]), True)
assert forward == current and inverse == old and n == m == 1


def outside_observation(raw):
    tree = ast.parse(raw)
    tree.body = [
        n
        for n in tree.body
        if not (isinstance(n, ast.FunctionDef) and n.name == "arena_observation")
    ]
    return ast.dump(tree, include_attributes=False)


assert outside_observation(old) == outside_observation(current)
test_path = "scripts/dev/test_arena_sigma420.py"
new_test = read(target["NN0_source"]["path"], target["NN0_source"])
assert new_test == git("show", f"8be646b:{test_path}")
old_test = git("show", f"{target['before_git']}:{test_path}")
tree = ast.parse(new_test)
classes = [node for node in tree.body if isinstance(node, ast.ClassDef)]
assert len(classes) == 1
new_name = "test_sigma_completed_observation_typed_namespace_nn0"
new_methods = [
    node for node in classes[0].body if isinstance(node, ast.FunctionDef) and node.name == new_name
]
assert len(new_methods) == 1
classes[0].body.remove(new_methods[0])
imports = [
    node
    for node in tree.body
    if isinstance(node, ast.Import) and len(node.names) == 1 and node.names[0].name == "math"
]
assert len(imports) == 1
tree.body.remove(imports[0])
assert ast.dump(tree, include_attributes=False) == ast.dump(
    ast.parse(old_test), include_attributes=False
)
old_method_name = "test_closed_model_and_three_core_fixed_depth_nn0"
old_class = next(n for n in ast.parse(old_test).body if isinstance(n, ast.ClassDef))
old_method = next(
    n for n in old_class.body if isinstance(n, ast.FunctionDef) and n.name == old_method_name
)
new_method = next(
    n for n in classes[0].body if isinstance(n, ast.FunctionDef) and n.name == old_method_name
)
assert ast.get_source_segment(old_test.decode(), old_method) == ast.get_source_segment(
    new_test.decode(), new_method
)
before = list(refs.values())
for ref in before:
    read(ref["path"], ref)
stop = now()
result = dict(
    fixed_Main="8be646b",
    target=refs[str(TARGET)],
    entry=entry,
    actual_reader_STOP=stop,
    selected_before=before,
    selected_after=list(refs.values()),
    all_refs_SHA_size_mode_before_after_exact=True,
    selected_input_B=sum(r["bytes"] for r in before),
    strict_forward_inverse_hunks=n,
    only_one_exact_insertion=True,
    outside_observation_AST_exact=True,
    old_test_body_byte_exact=True,
    new_test_only_math_import_and_one_method=True,
    target_functions_imports_tests_native_model_Search_calls=0,
    supplied_NN0="Producer says one new method PASS; foreground PID/CPU/RSS UNKNOWN, not rerun",
    fresh_known_producer_IDs="No concrete PID/start/boot supplied for this target; UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_TMP=[],
    owned_handles=[],
    owned_leases=[],
    remaining=[],
    canonical_lease_acquired=False,
    directwait="Synchronous read-only git subprocesses returned/reaped; plain-tool detailed process/handle receipt UNKNOWN",
    static_elapsed_seconds=time.monotonic() - started,
    reported_self_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    continuous_family_peak="UNKNOWN",
    future_quiet_or_reservation=False,
)
(OWN / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            k: result[k]
            for k in [
                "actual_reader_STOP",
                "all_refs_SHA_size_mode_before_after_exact",
                "selected_input_B",
                "strict_forward_inverse_hunks",
                "static_elapsed_seconds",
                "reported_self_ru_maxrss_KiB",
            ]
        }
    )
)
