"""420 fixed-source byte/hunk checks only; no Rust or target body execution."""

import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = OWN.with_name("sigma-alpha420-source-v1")
EXPECTED = "ed1b811f4c7cecc72f3091c11565e6247bd89e5681fcd7f959799e2518dc0581"
resource.setrlimit(resource.RLIMIT_AS, (805306368, 805306368))
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
refs = {}
begin = time.monotonic()


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink(), str(p)
    b = p.read_bytes()
    actual = {
        "path": str(p),
        "sha256": hashlib.sha256(b).hexdigest(),
        "bytes": len(b),
        "mode": f"{p.stat().st_mode & 0o7777:04o}",
    }
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    refs[str(p)] = actual
    return b


def witness(path):
    p = Path(path)
    b = p.read_bytes()
    ref = {
        "path": str(p),
        "sha256": hashlib.sha256(b).hexdigest(),
        "bytes": len(b),
        "mode": f"{p.stat().st_mode & 0o7777:04o}",
    }
    read(ref)
    return ref


def split_patch(raw):
    ls = raw.splitlines(keepends=True)
    ix = [i for i, s in enumerate(ls) if s.startswith(b"--- ")]
    ix.append(len(ls))
    out = {}
    for a, b in zip(ix, ix[1:]):
        assert ls[a + 1].startswith(b"+++ b/")
        name = ls[a + 1][6:].strip().decode()
        out[name] = b"".join(ls[a:b])
    return out


def apply(raw, diff, reverse=False):
    ls = raw.splitlines(keepends=True)
    ds = diff.splitlines(keepends=True)
    out, pos, i, count = [], 0, 2, 0
    while i < len(ds):
        m = re.fullmatch(rb"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n", ds[i])
        assert m, ds[i]
        a, na, b, nb = [int(x) if x is not None else 1 for x in m.groups()]
        if reverse:
            a, na, b, nb = b, nb, a, na
        at = a - 1 if na else a
        assert at >= pos
        out.extend(ls[pos:at])
        assert len(out) == (b - 1 if nb else b)
        pos = at
        consumed = produced = 0
        i += 1
        while i < len(ds) and not ds[i].startswith(b"@@ "):
            tag, body = ds[i][:1], ds[i][1:]
            assert tag in (b" ", b"+", b"-"), ds[i]
            if tag in (b" ", b"+" if reverse else b"-"):
                assert pos < len(ls) and ls[pos] == body, (pos, i)
                pos += 1
                consumed += 1
            if tag in (b" ", b"-" if reverse else b"+"):
                out.append(body)
                produced += 1
            i += 1
        assert (consumed, produced) == (na, nb)
        count += 1
    out.extend(ls[pos:])
    return b"".join(out), count


start = stamp()
target = json.loads(
    read(
        {
            "path": str(BASE / "source-binding.json"),
            "sha256": EXPECTED,
            "bytes": 11559,
            "mode": "0644",
        }
    )
)
read(
    {
        "path": str(BASE / "STOP.json"),
        "sha256": "ec50a6d5446be00eed5f9504000b82c780bc724ab889de83272cae80fad32d61",
        "bytes": 1871,
        "mode": "0644",
    }
)
for ref in target["evidence"].values():
    read(ref)
parts = split_patch(read(target["evidence"]["source.patch"]))
checks, before_map = [], {}
for row in target["source_subjects"]:
    before = b"" if row["before_absent"] else gzip.decompress(read(row["before_gzip"]))
    assert len(before) == row["before_bytes"]
    if not row["before_absent"]:
        assert hashlib.sha256(before).hexdigest() == row["before_sha256"]
    post = read(row["postimage"])
    diff = parts.pop(row["relative_path"])
    forward, n = apply(before, diff)
    inverse, m = apply(post, diff, True)
    assert forward == post and inverse == before and n == m
    before_map[row["relative_path"]] = before
    checks.append(
        {
            "relative_path": row["relative_path"],
            "hunks": n,
            "forward_inverse_exact": True,
            "before_absent": row["before_absent"],
        }
    )
assert not parts
function_map = json.loads(read(target["evidence"]["function-subject-map.json"]))
segments = 0
for subject in function_map["subjects"]:
    old = before_map[subject["relative_path"]].splitlines(keepends=True)
    new = read(subject["after"]).splitlines(keepends=True)
    for segment in subject["changed_segments"]:
        for label, ls in [("before", old), ("after", new)]:
            a, b = segment[label + "_lines_half_open_1based"]
            raw = b"".join(ls[a - 1 : b - 1])
            assert hashlib.sha256(raw).hexdigest() == segment[label + "_sha256"]
        segments += 1
inputs = json.loads(read(target["evidence"]["fixed-inputs.json"]))
book = json.loads(read(inputs["canonical_book"]))
shared = json.loads(read(inputs["shared419_inputs"]))
assert len(inputs["parents"]) == 6 and len(inputs["arena_families"]) == 4
assert inputs["selection_uses420_or419_new_results"] is False
assert [p["prefix"] for p in inputs["parents"][:3]] == [
    p["from_prefix_actions"] for p in shared["parents"][:3]
]
# Book is selected saved metadata only; no journal/RAW decode or native legality replay.
backend = json.loads(read(target["evidence"]["backend-inputs.json"]))
read(backend["provenance"])
static = json.loads(read(target["evidence"]["static-proof.json"]))
read(static["unchanged_PRIVATE_research_manifest"])
witnesses = [
    witness(p)
    for p in [
        "/workspaces/quoridor/.worktree/learning-million/crates/quoridor-inference/src/lib.rs",
        "/workspaces/quoridor/.worktree/learning-million/crates/quoridor-inference/native/ort.cpp",
        "/workspaces/quoridor/.worktree/learning-million/crates/quoridor-core/src/research.rs",
        "/workspaces/quoridor/.worktree/learning-million/crates/quoridor-ai/src/alphabeta.rs",
        "/workspaces/quoridor/crates/quoridor-runner/src/arena_clock.rs",
    ]
]
initial = dict(refs)
for ref in list(initial.values()):
    read(ref)
assert refs == initial
stop = stamp()
proof = {
    "binding_SHA256": EXPECTED,
    "source_checks": checks,
    "lexical_changed_segments_checked": segments,
    "Rust_AST_type_compile_tests": "NOT_RUN",
    "source_input_refs_before": initial,
    "source_input_refs_after": refs,
    "selected_ref_count": len(refs),
    "directed_unique_bytes": sum(r["bytes"] for r in refs.values()),
    "necessary_unchanged_witnesses": witnesses,
    "book_keys_inspected": list(book),
    "input_selection_metadata_only": True,
    "reader_START": start,
    "read_window_STOP": stop,
    "wall_seconds": time.monotonic() - begin,
    "resource_scope": "CPU10, stdlib AS768MiB; not continuous whole-family peak proof",
    "native_payload_or_target_execution": False,
    "owned_readers": [],
    "owned_children": [],
    "owned_jobs": [],
    "owned_TMP": [],
    "owned_leases": [],
    "remaining": [],
}
(OWN / "static-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            k: proof[k]
            for k in [
                "binding_SHA256",
                "selected_ref_count",
                "lexical_changed_segments_checked",
                "directed_unique_bytes",
                "read_window_STOP",
                "wall_seconds",
            ]
        }
    )
)
print("source_hunks", sum(r["hunks"] for r in checks))
