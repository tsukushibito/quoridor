"""Receipt-only delta and outstanding final map; no target execution."""

import ast
import datetime
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import time

OWN = Path(__file__).parent
ROOT = Path("/workspaces/quoridor")
BASE = ROOT / ".artifacts/research-team/integration324/sigma-alpha420-v1"
COMMIT = "8d799321d2f06f33a0ab027465b6149af527e90b"
resource.setrlimit(resource.RLIMIT_AS, (805306368, 805306368))
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(path, expected=None):
    p = Path(path)
    assert not p.is_symlink(), p
    raw = p.read_bytes()
    actual = {
        "path": str(p),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{p.stat().st_mode & 0o7777:04o}",
    }
    if expected:
        assert actual == {k: expected[k] for k in actual}, (actual, expected)
    if str(p) in refs:
        assert actual == refs[str(p)], p
    refs[str(p)] = actual
    return raw


def git(*args):
    p = subprocess.run(["git", *args], cwd=ROOT, timeout=20, capture_output=True, check=True)
    return p.stdout


def outside_two(raw):
    lines = raw.decode().splitlines(keepends=True)
    spans = [
        (n.lineno - 1, n.end_lineno)
        for n in ast.parse(raw).body
        if isinstance(n, ast.FunctionDef)
        and n.name in {"measurement_config", "experiment_phase_check"}
    ]
    assert len(spans) == 2
    for a, b in reversed(spans):
        lines[a:b] = ["<selected function>\n"]
    return "".join(lines)


entry = now()
proof_raw = read(BASE / "reference-identity-view.json")
assert hashlib.sha256(proof_raw).hexdigest() == (
    "012b28906806b26d5cf0091b3a5efb52ea15c2a659d6ce24bdc2699774286e63"
)
proof = json.loads(proof_raw)
relative = "crates/quoridor-runner/src/sigma_evaluator_tests.rs"
old = git("show", f"f0f3715:{relative}")
current = read(proof["after"]["path"], proof["after"])
assert hashlib.sha256(old).hexdigest() == proof["before_sha256"]
assert len(old) == 12194
assert current == git("show", f"{COMMIT}:{relative}")
delta = git(
    "diff", "--no-ext-diff", "--no-color", "--no-renames", "f0f3715", COMMIT, "--", relative
)
lines = delta.splitlines(keepends=True)
at = next(i for i, line in enumerate(lines) if line.startswith(b"--- "))
strict_delta = b"".join(lines[at:])
# Reuse only the reviewer's parser, not old verification bodies.
parser_path = OWN.parent / "static_check.py"
node = next(
    n
    for n in ast.parse(parser_path.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name == "apply"
)
scope = {"re": re}
exec(compile(ast.Module(body=[node], type_ignores=[]), str(parser_path), "exec"), scope)
forward, hunks = scope["apply"](old, strict_delta)
inverse, reverse_hunks = scope["apply"](current, strict_delta, True)
assert hunks == reverse_hunks == 2 and forward == current and inverse == old
renamed = old.replace(
    b"let (evaluator, _) = match setup {", b"let (evaluator, identity) = match setup {"
)
insert = b'    report["evaluator_identity"] = json!(format!("sigma-value-onnx-cpu:sha256:{identity}"));\n'
assert current.count(insert) == 1
assert current.replace(insert, b"") == renamed
assert b"#[ignore" in current and b"fn sigma_value_actual_cpu_reference_bounded()" in current
composition_raw = read(BASE / "composition-v1/result.json")
assert hashlib.sha256(composition_raw).hexdigest() == (
    "e5ea4c89ed434751d6914cdc716d99bcdd594856aeff96316b19e88bf04923c7"
)
composition = json.loads(composition_raw)
# Outstanding final map only: unaffected bodies are not re-reviewed.
for ref in composition["subjects"]:
    read(ref["path"], proof["after"] if ref["path"] == proof["after"]["path"] else ref)
for ref in composition["protected419"]:
    if not ref["path"].endswith("research-lifecycle.py"):
        read(ref["path"], ref)
py_proof = json.loads(read(BASE / "python-admission-proof.json"))
py_path = "scripts/dev/research-lifecycle.py"
py = read(ROOT / py_path)
assert hashlib.sha256(py).hexdigest() == py_proof["after_sha256"]
py_before = git("show", f"5afe0e391cec05d9c78afab0fa95ab078c827097:{py_path}")
assert hashlib.sha256(py_before).hexdigest() == py_proof["before_sha256"]
assert outside_two(py_before) == outside_two(py)
assert py == git("show", f"{COMMIT}:{py_path}")
companion = "crates/quoridor-runner/src/measurement_ordering394_tests.rs"
c = read(ROOT / companion)
fields = {b"inference: None,", b"sigma_value: None,"}
removed = [line for line in c.splitlines(keepends=True) if line.strip() in fields]
assert len(removed) == 2
assert b"".join(line for line in c.splitlines(keepends=True) if line.strip() not in fields) == git(
    "show", f"ba900a7:{companion}"
)
main_path = "crates/quoridor-runner/src/main.rs"
main = read(ROOT / main_path)
assert main == git("show", f"{COMMIT}:{main_path}")
receipt = b"""println!(
                "{}",
                serde_json::to_string(&serde_json::json!({
                    "records_saved": true,
                    "status": report.get("status"),
                    "runtime_launch_origin": report.get("runtime_launch_origin"),
                }))?
            );"""
assert main.count(receipt) == 1
assert main.replace(receipt, b'println!("{}", serde_json::to_string(&report)?);') == git(
    "show", f"ba900a7^:{main_path}"
)
guard = BASE / "python-admission-NN0-guard-v1"
supplied = json.loads(read(guard / "returned-receipt.json"))
stop = json.loads(read(guard / "STOP.json"))
check = supplied["checks"][0]
assert check["status"] == "PASS"
assert check["guardian_return"]["direct_child_reaped"] is True
assert check["guardian_return"]["cleanup_complete"] is True
assert check["guardian_return"]["remaining"] == []
read(check["full_log"]["path"], check["full_log"])
read(check["persisted_process_receipt"]["path"], check["persisted_process_receipt"])
identities = [
    {
        "original": i["original"],
        "fresh_pid_absent": not (Path("/proc") / str(i["original"]["pid"])).exists(),
    }
    for i in stop["identities"]
]
before = list(refs.values())
for ref in before:
    read(ref["path"], ref)
reader_stop = now()
result = {
    "fixed_Main": COMMIT,
    "entry": entry,
    "actual_reader_STOP": reader_stop,
    "reference_identity_view": refs[str(BASE / "reference-identity-view.json")],
    "source_before_after": before,
    "source_after": list(refs.values()),
    "all_refs_exact_before_after": True,
    "delta_hunks": hunks,
    "delta_forward_inverse_exact": True,
    "only_returned_identity_receipt": True,
    "outside_Python_two_functions_exact": True,
    "companion_only_two_None_fields": True,
    "main_only_saved_receipt": True,
    "reused_scope": "Prior419 functions/measurement join and original420 clear; no rerun",
    "supplied_NN0": "One producer metadata test PASS; not rerun/native qualification",
    "producer_known_identity_fresh": identities,
    "target_imports_functions_tests_native_model_Search_calls": 0,
    "owned_readers": [],
    "owned_children": [],
    "owned_jobs": [],
    "owned_TMP": [],
    "owned_handles": [],
    "owned_leases": [],
    "remaining": [],
    "canonical_lease_acquired": False,
    "directwait": "All synchronous read-only git calls returned/reaped; plain-tool detailed identity/handle receipt UNKNOWN",
    "static_helper_elapsed_seconds": time.monotonic() - started,
    "self_ru_maxrss_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "continuous_family_peak": "UNKNOWN",
    "future_quiet_or_reservation": False,
}
(OWN / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
(OWN / "delta.patch").write_bytes(delta)
print(
    json.dumps(
        {
            k: result[k]
            for k in [
                "actual_reader_STOP",
                "all_refs_exact_before_after",
                "delta_hunks",
                "static_helper_elapsed_seconds",
                "self_ru_maxrss_KiB",
                "producer_known_identity_fresh",
            ]
        }
    )
)
