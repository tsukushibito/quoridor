"""Four-function admission delta only; never import or execute target bodies."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import time

OWN = Path(__file__).parent
ROOT = Path("/workspaces/quoridor")
BASE = ROOT / ".artifacts/research-team/integration324/sigma-alpha420-v1/arena-consumer-v1"
COMMIT = "15e3d88dd2ff8acb3dc1719564f0daf1911c150a"
NAMES = {"arena_cpu_cores", "experiment_check", "arena_model_check", "arena_plan_check"}
resource.setrlimit(resource.RLIMIT_AS, (805306368, 805306368))
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
refs = {}
start = time.monotonic()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(path, expected=None):
    p = Path(path)
    assert not p.is_symlink(), p
    raw = p.read_bytes()
    ref = {
        "path": str(p),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{p.stat().st_mode & 0o7777:04o}",
    }
    if expected:
        assert ref == {k: expected[k] for k in ref}, (ref, expected)
    if str(p) in refs:
        assert refs[str(p)] == ref, p
    refs[str(p)] = ref
    return raw


def blob(commit, path):
    result = subprocess.run(
        ["git", "show", f"{commit}:{path}"], cwd=ROOT, timeout=20, check=True, capture_output=True
    )
    return result.stdout


def outside_bytes(raw):
    lines = raw.decode().splitlines(keepends=True)
    spans = [
        (n.lineno - 1, n.end_lineno)
        for n in ast.parse(raw).body
        if isinstance(n, ast.FunctionDef) and n.name in NAMES
    ]
    assert len(spans) == 4
    for a, b in reversed(spans):
        lines[a:b] = ["<selected function>\n"]
    return "".join(lines)


def outside_ast(raw):
    tree = ast.parse(raw)
    tree.body = [n for n in tree.body if not (isinstance(n, ast.FunctionDef) and n.name in NAMES)]
    return ast.dump(tree, include_attributes=False)


entry = now()
proof_raw = read(BASE / "proof.json")
assert hashlib.sha256(proof_raw).hexdigest() == (
    "7ddd466e8053d02a5073538ed67415713c30a717a5a43d1e68f058eaf1fb2c11"
)
proof = json.loads(proof_raw)
assert proof["commit"] == COMMIT and set(proof["functions"]) == NAMES
proposal = json.loads(read(proof["proposal"]["path"], proof["proposal"]))
patch = read(proof["thin_patch"]["path"], proof["thin_patch"])
compressed = read(proposal["minimum_before_gzip"]["path"], proposal["minimum_before_gzip"])
before_functions = gzip.decompress(compressed)
path = "scripts/dev/research-lifecycle.py"
old = blob("8d799321d2f06f33a0ab027465b6149af527e90b", path)
assert hashlib.sha256(old).hexdigest() == proof["before"]["sha256"]
assert len(old) == proof["before"]["bytes"]
current = read(proof["after"]["path"], proof["after"])
assert current == blob(COMMIT, path)
# Reuse only our strict parser; none of the old verification bodies is run.
parser_path = OWN.parent / "static_check.py"
node = next(
    n
    for n in ast.parse(parser_path.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name == "apply"
)
scope = {"re": re}
exec(compile(ast.Module(body=[node], type_ignores=[]), str(parser_path), "exec"), scope)
forward, n = scope["apply"](old, patch)
inverse, m = scope["apply"](current, patch, True)
assert forward == current and inverse == old and n == m == 5
assert outside_bytes(old) == outside_bytes(current)
assert outside_ast(old) == outside_ast(current)
old_nodes = {
    n.name: n for n in ast.parse(old).body if isinstance(n, ast.FunctionDef) and n.name in NAMES
}
gzip_nodes = {n.name: n for n in ast.parse(before_functions).body if isinstance(n, ast.FunctionDef)}
assert set(gzip_nodes) == NAMES
for name in NAMES:
    assert ast.dump(old_nodes[name], include_attributes=False) == ast.dump(
        gzip_nodes[name], include_attributes=False
    )
read(proof["new_NN0"]["path"], proof["new_NN0"])
capture = read(proof["new_NN0_capture"]["path"], proof["new_NN0_capture"])
assert b"Ran 1 test" in capture and capture.rstrip().endswith(b"OK")
before = list(refs.values())
for ref in before:
    read(ref["path"], ref)
stop = now()
result = {
    "fixed_Main": COMMIT,
    "entry": entry,
    "actual_reader_STOP": stop,
    "target": refs[str(BASE / "proof.json")],
    "selected_before": before,
    "selected_after": list(refs.values()),
    "all_refs_SHA_size_mode_before_after_exact": True,
    "selected_input_B": sum(r["bytes"] for r in before),
    "strict_patch_hunks": n,
    "forward_inverse_exact": True,
    "outside_four_bytes_exact": True,
    "outside_four_AST_exact": True,
    "before_gzip_four_functions_AST_match": True,
    "supplied_one_NN0": "PASS capture and definitions read only; no rerun",
    "supplied_guard_PID_identity": proof["nested_subprocess_PID_identity"],
    "fresh_known_producer_IDs": "No concrete PID/start/boot supplied in this target; UNKNOWN, no invented fresh absence",
    "target_body_import_function_test_native_model_Search_calls": 0,
    "owned_readers": [],
    "owned_children": [],
    "owned_jobs": [],
    "owned_TMP": [],
    "owned_handles": [],
    "owned_leases": [],
    "remaining": [],
    "canonical_lease_acquired": False,
    "directwait": "All synchronous read-only git subprocesses returned/reaped. Plain-tool detailed process/handle receipts UNKNOWN.",
    "static_elapsed_seconds": time.monotonic() - start,
    "reported_self_ru_maxrss_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "continuous_family_peak": "UNKNOWN",
    "future_quiet_or_reservation": False,
}
(OWN / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            k: result[k]
            for k in [
                "actual_reader_STOP",
                "all_refs_SHA_size_mode_before_after_exact",
                "strict_patch_hunks",
                "selected_input_B",
                "static_elapsed_seconds",
                "reported_self_ru_maxrss_KiB",
            ]
        }
    )
)
