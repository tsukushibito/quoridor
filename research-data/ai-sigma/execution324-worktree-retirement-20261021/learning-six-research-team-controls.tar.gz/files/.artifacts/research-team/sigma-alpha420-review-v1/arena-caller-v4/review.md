# 420.2 arena callerの4 guard関連確認

**source_clear=true / blockers=0 / ordinary=0**。固定Main `15e3d88dd2ff8acb3dc1719564f0daf1911c150a`のresearch-lifecycle.pyにあるarena_cpu_cores / experiment_check / arena_model_check / arena_plan_checkだけの評価です。元420・419 join・custody clearと元拒否/失敗記録は保持しました。

5 hunkの厳密forward/inverseは旧eb6f55a3/231884Bから新16b801d0/233554B0644を再構成し、4関数外のbyteとASTは一致しました。供給されたbefore gzipの4関数ASTも旧版に一致。選択7参照250782BはSHA/size/mode前後一致です。旧8subjects/22refsやRust/数理全体は再調査していません。

SigmaValueの新枝はevaluator_fixed_depthだけを認め、engine.modelなし、CPU ORT/device0/cuda-off、positive exact-int logical_row_limit、64 lower-hex identity形状、bound ONNX path+SHAとdynamic-library参照を要求します。Pythonはidentity hashを新設せず、実library/modelと最終identityの検証は変更していないnative ownerが担います。Python形状検査は実ロードや数値資格を意味しません。MCTSの既存whole-wall枝、NNUE/D枝、unused/missing backendとdescriptor censusは保持しています。

ordering_profileの既存NNUE/D条件にsigma_valueを加え、fixed-depth+managementは同じarena_cpu_coresを通ります。workers/active_games/max_batch各1、inference coreなし、二つのAI coreとdistinct management、launch child coresとの一致、CPU3/threads1/GPU0/controller-included/family RAMとissued limit一致を変えていません。physical topology・空き・host reserveは既存の入場guardの仕事で、この静的clearからfuture quietや予約を主張しません。

供給された一つのmetadata NN0はmodel/CPUの2関数をfake metadataで確認した作者証拠です（12+5 negative、fixed-depth/old whole-wall positive）。定義と98BのOK captureを読んだだけで再実行していません。残る2関数の接続はsourceで確認しました。レビュー者が実行したのは有限stdlibのpatch/AST checkerのみ、対象関数/import/test/native/model/library/Search/Cargoは0。Rootの別途5-row native referenceやBuild/imageは本レビューで再検証しておらず、24Search/8game/数値・性能・棋力・defaultの資格は付与しません。

Actual reader STOP: **2026-10-15T22:38:29.978210+00:00**。owned readers/children/jobs/handles/TMP/leases/remainingは[]。canonical/hardware lease取得なし。read-only git subprocessはdirect return/reap済み。供給proofのnested PID identity自体がUNKNOWNで、今回対象に具体的なPID/start/bootはないためfresh absenceもUNKNOWNです。通常toolの詳細handle receiptと連続family peakはUNKNOWN。static helper elapsed 0.2978991340205539秒、self ru_maxrss 735988KiBはfamily測定証明ではなく、nested時間をwholeへ加算しません。Main/source/Git/index writeは0。旧RAW/FAILED費/mask/UNKNOWN、learning/mixed/323pause/models/seals/defaultは保持します。
