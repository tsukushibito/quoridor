# 420.2 固定 Sigma value / αβ 差分確認

固定 source-binding `ed1b811f4c7cecc72f3091c11565e6247bd89e5681fcd7f959799e2518dc0581`（11559B/0644）について、**source_clear=true、blockers=0、ordinary=0**。対象は私有7 postimageと必要な現行callsiteだけである。Main419との最終疎合成、Rust型・compile・新fixture・実ORT/model・CPU parity・Search・対局の資格を含めない。

| 確認境界         | 固定差分で確認できたこと                                                                                                                                                                                                                                                                      | 未実行／入場時の限界                                                                                                                                                                                                           |
| ---------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 入力・STM・value | `SigmaValueEvaluator` は既存 `features(context.position())` を1行だけ同期backendへ渡し、有限かつ[-1,1]のvalueを符号反転／tanh／再尺度化なしで返す。policy logitsは有限性を検査するがordering/providerに渡さない。                                                                             | joint policy/value forwardでありvalue-only計算費ではない。現モデルとの実同等性は未確認。                                                                                                                                       |
| 所有・失敗       | Send backendを一つのMutexが所有し、shape/nonfinite/range/backend/poison/rowlimitはEvaluation errorへ伝播する。ゼロ評価や成功fallbackを作らない。terminalは共通Searchが先に判定し、adapter直接terminal呼出しも拒否する。                                                                       | ORT同期呼出しは途中preemptしない。cancelは既存Search／matching-terminal回収へ戻す。terminal node推論0をbackend初期化費0とは扱わない。                                                                                          |
| identity・累積   | model SHAと実library binary SHA、CPU/FP32/batch1/intra1/inter1/sequential、feature/value意味をtyped IDに入れ、runtimeとmeasurementが同じIDをnamespaceへ接続する。pathと予算は数学IDにしない。backendはmeasurementの各sessionおよびarenaの各game resetを越えて保持する。                       | binary SHAはlibrary内容／版を固定するが、実loaded versionは本確認で観測していない。1.30.0は既存library証拠の値。別operationへの残量移送は原normal receiptsに基づく実entry作業で、今回のdraft自体が300Kを証明するわけではない。 |
| factory・binding | measurementとruntimeのSigma分岐は同じ `runtime::sigma_value_evaluator` を使う。ONNXはExperiment.inputs、ORTはdynamic_librariesで結合し、actual factoryはlibrary SHAを再計算する。偽NNUE descriptorや旧固定モデル件数を足さない。                                                              | model/library payloadは読まず、actual load/forwardも0。旧D/NNUE経路の数値式は変えず、tuple/optional ownerの接続変更だけ。                                                                                                      |
| 固定深度arena    | managementを持つfixed-depthは既存two-AI/main authority経路を使う。time=NoneのdeadlineはNone。requested depth、DepthComplete、finite value、action/PVを既存helperで確認し、engine error／cancelを先に拒否する。matching terminal回収後にだけcommitし、不足深度／rowcap／errorはUNKNOWNへ戻る。 | legal fallbackや以前の浅いcompletionはエラーを救済しない。通常ルールgoal/true thirdだけterminal、200plyはUNKNOWN。WholeWallTimeの成功へ読み替えない。                                                                          |
| fixture・選択    | 六つのfake NN0定義と一つのignored actual reference定義があり、STM/terminal/cancel/error/budget/reset/ID/binding/no-clock不足深度を扱う。固定入力は6親、arena4系統・二色で、419先頭3prefixと保存book参照が結合する。                                                                           | 全定義UNBUILT/UNTYPED/UNRUN。実CPU reference input/outputはABSENT。新しい合法性/fullhistory native replayも未実行。旧成功16/28やモデル全資格を再実行していない。                                                               |

`OrtBackend` の現行native sourceはCPU session、FP32 tensor、intra1/inter1/sequentialを設定する。CreateSession・allocator・graph setupと、明示的なqort_runのlogical/executed/warm/failedは別物である。既存counterのlogicalには失敗requestが含まれ、physicalはexecuted/warm/captureの別domain。adapter側もattempted/failed/refusalを別に持つ。measurementはbefore/afterと最終workを保存し、arenaはown backendの累積snapshotを回収する。counter取得不能はUNKNOWNであり、未記録を0や新しい予算へ置換しない。実fixtureもfake warm=0をactual warmの資格にしていない。

portable AI/Wasm、PUCT、NNUE head/FT、Dの式、既存depth_rank、Cargo依存は420 patchの変更対象ではない。StaticEvaluatorの既存prepare/advance defaultはNoneであり、policy provider・新しい推論queue/cache/registryを追加していない。固定深度化は既存evaluation workersの条件拡張で、一般D/NNUEの従来managementなし経路やWholeWallTime条件を同一視しない。

## Main419との交点

この私有beforeは旧61dであり、**postimage全fileをMainへ上書きする承認ではない**。Main9c8f0c2のcanonical `load_residual_model`、RootSelector、replay、run、loss_leaf_419と419 module宣言を保持し、Sigma分岐／返却owner／Settings.inference等の必要差分だけを疎合成する。今回私有measurementの旧ResidualModel::load部分は、Main419 loaderの代わりにはならない。Rootの固定合成証拠が届けばその交点だけが関連確認対象となる。現Root softwareやその真正imageのPASSはこの未合成420 codeへ移さない。

## 有限設定と証拠

fixed-inputs/backend-inputs/finite-settingsを原SHAで照合した。419の3親は同じfamily0由来を含み、独立6familyとは扱わない。追加保存book family0/1/2とarena0/1/2/3は結果前の固定metadataであり、旧RAWを再decodeしていない。モデルd790…/11663428B、ORT c902…/28985152B/既存version1.30.0の参照は保持し、payload hash/loadを本reviewで実行していない。

設定の最大24 Search（6親×D1/D2×2、各50K／総1.2Mnodes）、前段100Klogical（32参照と必要時256witnessを含む）、後段8局200K、全300Kは選択された有限仕事の設定である。共通APIへ24/32/8等の固定件数guardを埋めない。別operationは前の実logical消費を差し引き、UNKNOWN消費から正の残量を捏造しない。actual Build/typed ID/Experiment/admission/CPU referenceがnullのdraftはREADYではない。419 witnessの未着をこの実装のgateにしない。

独立stdlib checkerで7 postimageの40 unified hunkをforward/inverseとも厳密適用し、新規2fileのbefore不存在も復元した。関数対応表の50 segmentの座標とbyte SHAを照合したが、これはRust AST/type判定ではない。40 selected refsは前後および最終照合でSHA/size/mode一致。必要な既存Main arena_clock helperだけを参照し、Main419全source監査やmergeは行わなかった。

作者のformatter実write成功、outer collector KeyError失敗、未入場EAGAIN、returned NULLとdisk pending/attempted masksはそれぞれの原scopeのまま保持する。原child1.7207567199948244sとouter各spanを重複加算せず、science費0への置換や成功への改名をしない。reviewer側の古いformatter locator不在とshared入力field名KeyErrorもverification.jsonへ保持し、現在のformatter／schemaで限定修復した。target body／Rust／Cargo／native／model／fixture／Search／arenaは実行していない。

## STOPと範囲

最終selected reader STOP: **2026-10-15T21:19:58.681873+00:00**。own readers/children/jobs/TMP/leases/remainingは空、finite toolは全てdirect-returnした。source/hardware/software leaseは取得／保持していない。作者が記録した9 process identityは今回の/proc照合で全てABSENT。plain execの正確な全child PID・handle receiptはtoolから提供されていないため、その不足を架空の0や全host cleanupへ変えない。

CPU10/guardian14は実topologyで別physical core、419 software2/4とも別core。これはentry時点の配置でありfuture quiet/reservationではない。stdlib checkerはAS768MiB、CPU10で0.1566336539981421s、最終metadata照合はreader-STOPの別span。whole family連続peak／全work費／global actualはUNKNOWN。ordinary reviewの事前保存枠は作らず、本人outputだけのactual usageを最後に一度記録する。共有target・旧RAW/models/envは走査／再課金／削除refundしない。decimal50GB、既存covered上限、323/mixed/learnerの停止、models/seals/defaultsは保持する。
