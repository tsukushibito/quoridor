"""Finite reviewer-owned byte/AST checks; never execute target bodies."""

import ast
import datetime
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import time

OWN = Path(__file__).parent
ROOT = Path("/workspaces/quoridor")
EVIDENCE = ROOT / ".artifacts/research-team/integration324/sigma-alpha420-v1"
resource.setrlimit(resource.RLIMIT_AS, (805306368, 805306368))
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
started = time.monotonic()
refs = {}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(path, expected=None):
    path = Path(path)
    assert not path.is_symlink(), path
    raw = path.read_bytes()
    ref = dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )
    if expected:
        assert ref == {k: expected[k] for k in ref}, (ref, expected)
    if str(path) in refs:
        assert refs[str(path)] == ref, path
    refs[str(path)] = ref
    return raw


def blob(commit, path):
    result = subprocess.run(
        ["git", "show", f"{commit}:{path}"], cwd=ROOT, check=True, capture_output=True, timeout=15
    )
    return result.stdout


def function(raw, name):
    # Lexical top-level span, not a Rust parser/type check.
    match = re.search(rb"^(?:pub(?:\([^\n)]*\))? )?fn " + name.encode() + rb"\(", raw, re.M)
    assert match, name
    end = raw.index(b"\n}", match.start()) + 2
    return raw[match.start() : end]


def outside_python(raw):
    lines = raw.decode().splitlines(keepends=True)
    tree = ast.parse(raw)
    spans = [
        (n.lineno - 1, n.end_lineno)
        for n in tree.body
        if isinstance(n, ast.FunctionDef)
        and n.name in {"measurement_config", "experiment_phase_check"}
    ]
    assert len(spans) == 2
    for a, b in reversed(spans):
        lines[a:b] = ["<selected function>\n"]
    return "".join(lines)


# Reuse ONLY the reviewer's strict patch parser function, not its old checks.
own_old = OWN.parent / "static_check.py"
node = next(
    n
    for n in ast.parse(own_old.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name == "apply"
)
scope = {"re": re}
exec(compile(ast.Module(body=[node], type_ignores=[]), str(own_old), "exec"), scope)
apply_patch = scope["apply"]
entry = now()
result = json.loads(read(EVIDENCE / "composition-v1/result.json"))
assert refs[str(EVIDENCE / "composition-v1/result.json")]["sha256"] == (
    "e5ea4c89ed434751d6914cdc716d99bcdd594856aeff96316b19e88bf04923c7"
)
join = read(result["measurement_join"]["path"], result["measurement_join"])
read(result["source_patch"]["path"], result["source_patch"])
for ref in result["subjects"]:
    read(ref["path"], ref)
for ref in result["protected419"]:
    if ref["path"].endswith("research-lifecycle.py"):
        continue  # Explicitly superseded by the two-function admission change.
    read(ref["path"], ref)
measurement_path = "crates/quoridor-runner/src/measurement.rs"
current = read(ROOT / measurement_path)
before = blob(result["previous_head"], measurement_path)
forward, hunks = apply_patch(before, join)
inverse, reverse_hunks = apply_patch(current, join, True)
assert forward == current and inverse == before and hunks == reverse_hunks
protected = {}
for name in ["root_spec", "prepare_roots", "replay", "load_residual_model"]:
    a, b = function(before, name), function(current, name)
    assert a == b, name
    protected[name] = hashlib.sha256(b).hexdigest()
author = next(
    r["postimage"]
    for r in json.loads(
        read(OWN.parent.with_name("sigma-alpha420-source-v1") / "source-binding.json")
    )["source_subjects"]
    if r["relative_path"] == measurement_path
)
author_raw = read(author["path"], author)
for name in ["evaluator_binding", "sigma_value_binding", "validate_evaluator_binding"]:
    # evaluator_binding intentionally adds only the 419 mixed-loss exclusion.
    a, b = function(author_raw, name), function(current, name)
    if name == "evaluator_binding":
        b = b.replace(b"            || settings.loss_leaf_419\n", b"")
    assert a == b, name
assert b"Arc::new(alphabeta::ResidualEvaluator::new(load_residual_model(e)?))" in current
assert b"let roots = prepare_roots(&e, &settings.roots, false)?;" in current
assert b"let mut result = if settings.loss_leaf_419 {" in current
assert current.index(b'result["inference_work"]') < current.index(b"drop(target);")
companion = "crates/quoridor-runner/src/measurement_ordering394_tests.rs"
companion_old = blob(result["previous_head"], companion)
companion_new = read(ROOT / companion)
assert (
    companion_new.replace(b"            inference: None,\n", b"").replace(
        b"            sigma_value: None,\n", b""
    )
    == companion_old
)
py_path = "scripts/dev/research-lifecycle.py"
py_before = blob(result["commit"], py_path)
py_current = read(ROOT / py_path)
py_proof = json.loads(read(EVIDENCE / "python-admission-proof.json"))
assert hashlib.sha256(py_before).hexdigest() == py_proof["before_sha256"]
assert hashlib.sha256(py_current).hexdigest() == py_proof["after_sha256"]
assert outside_python(py_before) == outside_python(py_current)
assert py_current == blob("f0f3715", py_path)
main_path = "crates/quoridor-runner/src/main.rs"
main = read(ROOT / main_path)
assert main == blob("f0f3715", main_path)
old_main = blob("ba900a7^", main_path)
receipt = b"""println!(
                "{}",
                serde_json::to_string(&serde_json::json!({
                    "records_saved": true,
                    "status": report.get("status"),
                    "runtime_launch_origin": report.get("runtime_launch_origin"),
                }))?
            );"""
assert main.count(receipt) == 1
assert main.replace(receipt, b'println!("{}", serde_json::to_string(&report)?);') == old_main
assert current.index(b"output.finish(&result)?;") < current.index(
    b"Ok(result)\n}", current.index(b"pub fn run(")
)
# Necessary unchanged native entry verification ranges are read, never executed.
read(ROOT / "crates/quoridor-runner/src/research_manifest.rs")
read(ROOT / "scripts/dev/test_measurement_sigma420.py")
guard = EVIDENCE / "python-admission-NN0-guard-v1"
guard_receipt = json.loads(read(guard / "returned-receipt.json"))
guard_stop = json.loads(read(guard / "STOP.json"))
check = guard_receipt["checks"][0]
assert check["status"] == "PASS"
assert check["guardian_return"]["direct_child_reaped"] is True
assert check["guardian_return"]["cleanup_complete"] is True
assert check["guardian_return"]["remaining"] == []
read(check["full_log"]["path"], check["full_log"])
read(check["persisted_process_receipt"]["path"], check["persisted_process_receipt"])
known = []
for row in guard_stop["identities"]:
    identity = row["original"]
    # No signalling or foreign process alteration. A reused PID is UNKNOWN.
    proc = Path("/proc") / str(identity["pid"])
    known.append({"identity": identity, "fresh_pid_absent": not proc.exists()})
before_refs = list(refs.values())
for ref in before_refs:
    read(ref["path"], ref)
stop = now()
proof = dict(
    entry=entry,
    reader_STOP=stop,
    target_commit="f0f3715",
    sparse_commit=result["commit"],
    composition_result=refs[str(EVIDENCE / "composition-v1/result.json")],
    before=before_refs,
    after=list(refs.values()),
    before_after_exact=True,
    measurement_join_hunks=hunks,
    strict_forward_inverse=True,
    canonical419_functions_byte_exact=protected,
    author_binding_functions_exact_except_explicit_loss_exclusion=True,
    companion_only_two_None_fields=True,
    python_outside_two_functions_byte_exact=True,
    main_only_compact_receipt=True,
    target_functions_executed=0,
    target_tests_rerun=0,
    native_model_Search_calls=0,
    supplied_NN0_PASS="One supplied metadata AST test only; not reviewer execution/native qualification",
    supplied_guard_child_current=known,
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    directwait="All synchronous git reads returned/reaped; tool child identity/handle receipts UNKNOWN",
    elapsed_seconds=time.monotonic() - started,
    self_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    continuous_family_peak="UNKNOWN",
    future_quiet_or_reservation=False,
)
(OWN / "static-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            k: proof[k]
            for k in [
                "reader_STOP",
                "measurement_join_hunks",
                "before_after_exact",
                "elapsed_seconds",
                "self_ru_maxrss_KiB",
                "supplied_guard_child_current",
            ]
        }
    )
)
