"""Only the stopped one-off caller's R1 finalization and C1/C2 descriptions."""

import gzip
import hashlib
from pathlib import Path

OUT = Path(__file__).resolve().parent
before = (OUT.parent / "measurement_static426_tests.rs").read_bytes()
assert (
    hashlib.sha256(before).hexdigest()
    == "f249e319b0ce268e3ea6f3f5ef8d0410cd9081a1ad65eea80606f5ff65473ce3"
)
(OUT / "before.rs.gz").write_bytes(gzip.compress(before, mtime=0))
s = before.decode()
helper = r"""
// Private one-off publication only. At most4096 bytes per output channel.
fn terminal_write(writer: &mut dyn Write, receipt: &Value) -> Result<()> {
    let mut bytes = serde_json::to_vec(receipt)?;
    bytes.push(b'\n');
    if bytes.len() > 4096 {
        return Err("bounded terminal receipt exceeded".into());
    }
    writer.write_all(&bytes)?;
    writer.flush()?;
    Ok(())
}

fn finish(
    report: &mut Value,
    work: Result<()>,
    save: impl FnOnce(&Value) -> Result<()>,
    stdout: &mut dyn Write,
    stderr: &mut dyn Write,
    output: &Path,
) -> Result<()> {
    let mut first = work.err();
    // The report written below cannot attest its own returned write or later I/O.
    report["final_persistence"] = json!({"status":"ATTEMPTED_RETURN_UNKNOWN_IN_REPORT",
        "returned_status_location":"bounded terminal receipt if any channel succeeds"});
    report["terminal_output"] = json!("NOT_YET_ATTEMPTED_UNKNOWN_IN_REPORT");
    let saved = save(report);
    report["final_persistence"] = json!({"status":if saved.is_ok(){"OK"}else{"FAILED"}});
    if let Err(error) = saved {
        report["secondary_errors"].as_array_mut().unwrap().push(json!({"stage":"final_persist","error":fact(&*error)}));
        if first.is_none() { first = Some(error); }
    }
    let mut receipt = json!({"saved":output,"work_status":report["status"],
        "final_persistence":report["final_persistence"],"work_error_present":!report["primary_error"].is_null(),
        "publication_error_count":report["secondary_errors"].as_array().unwrap().len(),
        "publication_errors":report["secondary_errors"],
        "NNUE_head_started_reservations":report["counts"]["NNUE_head_started"],
        "NNUE_head_returned_Ok_only":report["counts"]["NNUE_head_returned"],
        "stdout":"ATTEMPTED_RETURN_UNKNOWN","stderr":"NOT_ATTEMPTED"});
    match terminal_write(stdout, &receipt) {
        Ok(()) => report["terminal_output"] = json!({"stdout":"OK","stderr":"NOT_ATTEMPTED"}),
        Err(error) => {
            report["secondary_errors"].as_array_mut().unwrap().push(json!({"stage":"stdout","error":fact(&*error)}));
            if first.is_none() { first = Some(error); }
            receipt["stdout"] = json!("FAILED");
            receipt["stderr"] = json!("ATTEMPTED_RETURN_UNKNOWN");
            receipt["publication_error_count"] = json!(report["secondary_errors"].as_array().unwrap().len());
            receipt["publication_errors"] = report["secondary_errors"].clone();
            match terminal_write(stderr, &receipt) {
                Ok(()) => report["terminal_output"] = json!({"stdout":"FAILED","stderr":"OK"}),
                Err(error) => {
                    report["secondary_errors"].as_array_mut().unwrap().push(json!({"stage":"stderr","error":fact(&*error)}));
                    report["terminal_output"] = json!({"stdout":"FAILED","stderr":"FAILED"});
                    if first.is_none() { first = Some(error); }
                }
            }
        }
    }
    // Available facts remain separate in memory/receipts; if every channel fails,
    // durability is UNKNOWN. Never replace work's original error with an I/O panic.
    first.map_or(Ok(()), Err)
}
"""
needle = "fn state(context: &SigmaContext) -> Value {"
s = s.replace(needle, helper + "\n" + needle, 1)
s = s.replace(
    '"Search_calls":0,"simd":false,"primary_error":null,"secondary_errors":[],',
    """"Search_calls":0,"FT_context_mode":"Scalar",
        "head_route":"unchanged canonical magnitude-guarded head; hardware route not measured",
        "counter_scope":{"NNUE_head_started":"pre-persist reservations/maybe-entered; Err/cancel invocation UNKNOWN",
            "NNUE_head_returned":"Ok-only; Err returns not counted; pending is not zero work",
            "NNUE_full_context_started":"pre-persist reservations/maybe-entered; invocation UNKNOWN on error",
            "NNUE_full_context_returned":"Ok-only; no refill from incomplete counters"},
        "primary_error":null,"secondary_errors":[],""",
    1,
)
start = s.index(
    "    let saved = persist(&mut file, &report);\n", s.index("let drop_start")
)
s = (
    s[:start]
    + """    finish(
        &mut report,
        work,
        |value| persist(&mut file, value),
        &mut std::io::stdout().lock(),
        &mut std::io::stderr().lock(),
        &output,
    )
}
"""
)
s += r"""

#[test]
fn output_failures_keep_original_work_error_zero_head() {
    #[derive(Debug)]
    struct WorkError;
    impl std::fmt::Display for WorkError {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result { f.write_str("originating E") }
    }
    impl std::error::Error for WorkError {}
    struct Broken;
    impl Write for Broken {
        fn write(&mut self, _: &[u8]) -> std::io::Result<usize> {
            Err(std::io::Error::new(std::io::ErrorKind::BrokenPipe,"output failed"))
        }
        fn flush(&mut self) -> std::io::Result<()> { Ok(()) }
    }
    let make_report = || json!({"status":"FAILED_PARTIAL_UNKNOWN","primary_error":{"message":"originating E"},
        "secondary_errors":[],"counts":{"NNUE_head_started":0,"NNUE_head_returned":0}});
    let mut report = make_report();
    let original = Box::new(WorkError);
    let identity = (&*original) as *const WorkError;
    let result = finish(&mut report,Err(original),|_|Err("final save F".into()),&mut Broken,&mut Broken,Path::new("/NOT_CREATED"));
    let error = result.unwrap_err();
    assert!(std::ptr::eq(error.downcast_ref::<WorkError>().unwrap(),identity));
    assert_eq!(report["final_persistence"]["status"],"FAILED");
    assert_eq!(report["secondary_errors"].as_array().unwrap().iter().map(|v|v["stage"].as_str().unwrap()).collect::<Vec<_>>(),["final_persist","stdout","stderr"]);
    assert_eq!(report["terminal_output"],json!({"stdout":"FAILED","stderr":"FAILED"}));
    // The saved snapshot cannot claim its own returned save status; the successful
    // fallback receipt can report final-save FAILED while stderr's return is pending.
    let mut report = make_report();
    let mut fallback = Vec::new();
    let result = finish(&mut report,Err(Box::new(WorkError)),|snapshot|{
        assert_eq!(snapshot["final_persistence"]["status"],"ATTEMPTED_RETURN_UNKNOWN_IN_REPORT");
        Err("final save F".into())
    },&mut Broken,&mut fallback,Path::new("/NOT_CREATED"));
    assert!(result.unwrap_err().is::<WorkError>());
    let receipt:Value=serde_json::from_slice(&fallback).unwrap();
    assert_eq!(receipt["final_persistence"]["status"],"FAILED");
    assert_eq!(receipt["stdout"],"FAILED");
    assert_eq!(receipt["publication_errors"][0]["stage"],"final_persist");
    assert_eq!(receipt["publication_errors"][1]["stage"],"stdout");
    assert_eq!(receipt["stderr"],"ATTEMPTED_RETURN_UNKNOWN");
    assert!(fallback.len()<=4096);
}
"""
(OUT / "measurement_static426_tests.rs").write_text(s)
