"""Static sparse-delta/protected-body proof only; never execute the Rust fixture."""

import difflib
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
before = gzip.decompress((OUT / "before.rs.gz").read_bytes()).decode()
after = (OUT / "measurement_static426_tests.rs").read_text()
assert (
    hashlib.sha256(before.encode()).hexdigest()
    == "f249e319b0ce268e3ea6f3f5ef8d0410cd9081a1ad65eea80606f5ff65473ce3"
)


def body(source, name):
    start = source.index("fn " + name + "(")
    return source[start : source.index("\n}\n", start) + 3]


protected = {}
for name in ("persist", "state", "comparison", "saved_f32"):
    a = body(before, name)
    b = body(after, name)
    assert a == b
    protected[name] = hashlib.sha256(a.encode()).hexdigest()
start = "    let mut model: Option<ResidualModel> = None;"
old = before[
    before.index(start) : before.index(
        "    let saved = persist(&mut file, &report);", before.index(start)
    )
]
new = after[after.index(start) : after.index("    finish(\n", after.index(start))]
assert old == new
assert "println!" not in after and "eprintln!" not in after
assert '"simd":false' not in after and "pre-persist reservations/maybe-entered" in after
patch = "".join(
    difflib.unified_diff(
        before.splitlines(True),
        after.splitlines(True),
        fromfile="a/crates/quoridor-runner/src/measurement_static426_tests.rs",
        tofile="b/crates/quoridor-runner/src/measurement_static426_tests.rs",
    )
)
(OUT / "related.patch").write_text(patch)
work = OUT / "strict-TMP"
target = work / "crates/quoridor-runner/src/measurement_static426_tests.rs"
target.parent.mkdir(parents=True)
target.write_text(before)
captures = []
for reverse in (False, True):
    cmd = ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(OUT / "related.patch")]
    if reverse:
        cmd.insert(1, "--reverse")
    r = subprocess.run(cmd, cwd=work, text=True, capture_output=True, check=True)
    assert target.read_text() == (before if reverse else after)
    captures.append(
        dict(argv=cmd, exit_code=r.returncode, stdout=r.stdout, stderr=r.stderr)
    )
target.unlink()
for d in (target.parent, target.parent.parent, target.parent.parent.parent, work):
    d.rmdir()
proof = dict(
    before_SHA=hashlib.sha256(before.encode()).hexdigest(),
    post_SHA=hashlib.sha256(after.encode()).hexdigest(),
    strict_forward_inverse=captures,
    protected_function_BYTES=protected,
    protected_native_work_model_math_drop_status_BYTES_SHA=hashlib.sha256(
        old.encode()
    ).hexdigest(),
    AST_note="BYTE exact protected bodies imply unchanged AST; no Rust type/AST compiler executed",
    Main_and_all_other_modules_changed=0,
    source_metadata_input_and_oldpacket_unchanged=True,
    checks="static only; new zero-head Rust assertion definition UNBUILT/UNTYPED/UNRUN",
    new_fixture="measurement::static426_tests::output_failures_keep_original_work_error_zero_head",
    fixture_cases=[
        "work E plus final-save F and both broken channels: original E object identity; every secondary stage retained in memory",
        "work E plus F and broken stdout: successful bounded stderr receipt records failure/secondary facts; save snapshot and stderr receipt do not claim own returned I/O",
    ],
    all_channel_durability="UNKNOWN if every sink fails; no claim of guaranteed receipt",
    TMP_removed=True,
)
(OUT / "protected-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            "post_SHA": proof["post_SHA"],
            "new_fixture": "UNRUN",
            "oldfixture_or_model_execution": 0,
        }
    )
)
