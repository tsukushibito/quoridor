# 426.3 R1/C1/C2だけの関連修正

元7f4ff8f0/input b00b/caller f249、成功済みcompile593583ac、negative review c0d227fd/control12a1fe13は不変。新private derivativeと疎patchだけを返す。Main/Git/Cargo/native/head/model/旧fixture実行は作者0。新Rust定義もUNBUILT/UNTYPED/UNRUN、source-clear/数値PASSは本人が認定しない。

R1: 元のwork Errを最優先でそのまま返す。final persistのErrは別stageとして保持し、元Errが無い場合だけそのErrを返す。println!/eprintln!を除去し、一channel最大4096Bのfallible write_all/flushを使う。stdout失敗は別stage、stderrへ一度だけfallbackし、その失敗も別stage。新head/再試行/別result frameworkはない。work結果とpublication結果を分ける。保存JSONは自身の最終save返却や後続stdout/stderrの結果を証明できないためATTEMPTED/RETURN_UNKNOWNを明記する。save返却後のterminal receiptはsaveのOK/FAILEDとsecondary factsを表し、自channelについては返却UNKNOWNのまま。available in-memory reportは全secondary stageを保持する。全channel失敗時の永続化はUNKNOWNであり、保証しない。上限より大きいterminal receiptは無制限に書かずErrとして扱う。

C1: startedは永続化前reservation/maybe-entered、returnedはOk-onlyと明示した。pre-entry persist Errで実invocationが無い場合もreservationが残り、Err/cancelで返却したかはUNKNOWN。pendingを実work0やall-return censusに置換せず、補充しない。成功時7head/whole28上限は不変。

C2: simd:falseの曖昧な表示をScalarFT/context指定に改めた。canonical headは既存magnitude guard/hardware routeのまま、scalar-only headやphysical FT/headを測定したとは言わずUNKNOWNを保持する。

新zero-head fixtureは一つだけ添付した（実行0）。work Eとfinal save Fと両broken channelの反例、同じE object identity、secondary順序final_persist/stdout/stderrをassertする。同一definition内で、stderrが成功する場合のbounded receiptと、save snapshot/自channel返却がUNKNOWNであることもassertする。元seven-state definitionや旧成功suiteは再演しない。Rootの必要filterはmeasurement::static426_tests::output_failures_keep_original_work_error_zero_head。

protected-proof.jsonはpersist/state/comparison/saved_f32、およびseven-stateのmodel load/実評価/親照合/件数/cap/drop/statusブロックのBYTE exactを確認した。これらのASTもbyte同一ゆえ不変であり、Rust AST/typecheckerを実行したという主張ではない。元callerだけのbefore gzip、thin related.patch、strict GNU zero-fuzz forward/inverseを保存。既存measurement.rs moduleや他production ownerに変更0。Rustfmt edition2024、project Ruff no-cache、Markdown Prettierを担当sourceだけへ適用する。実STOP/cleanup/usageはbinding参照。

Actual context 2026-10-16T21:52:04.201Z Sol6.1/high/Main/danger-full-access/neverを最初に確認。sourceCPU10/guardian14/family1GiB inclcontroller/GPU0/reserve4GiBの既存fresh physical guardとdirectwait/reapを使用。元426コンテキスト順序逸脱・元FAILED/費・oldUSERPAUSE/default/models/seals/capsは全保持。Root324へ一度返し、同426.4関連確認の配送はRootが行う。authorはreviewerをdispatchしない。
