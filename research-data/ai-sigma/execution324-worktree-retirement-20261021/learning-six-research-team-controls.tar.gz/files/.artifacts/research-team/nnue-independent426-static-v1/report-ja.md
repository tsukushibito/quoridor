# 426B: 同じ7状態へのW BEST118だけの静的評価入口

私有source準備完了。Main変更・Cargo・Rust型検査・native・モデル読み込み・head forward・Search・Sigma/D実行は作者0。Rustの新定義はUNBUILT/UNTYPED/UNRUNであり、数値結果ではない。324が真正compiler/test artifactと通常入力寿命を束縛して一度実行する。

## 入力と同一性

`input.json`は実423 arena Experiment-0-0に記録されたWと、公開済み422のinput/resultへのFileRefだけを持つ。WはBEST118、descriptor fbf0beb86fdf7f42f5bdd88893df215423ca86873da04308ed5029128edaf70a、weights ab073fb138b84710c0d244c1459aebc016a74743ecabee5e949321a00ec81b99、typed 8a8eb7fb87035f03c4cfa6b45ca1aa5d2f1b144c6fa1298dd11b82975307953d。weights本文は作者未読・未hash。

3親のIDはdistance-slot004-ply011、distance-slot004-ply039、distance-slot005-ply012。後続4状態は422の保存順どおり156-91、156-196、192-43、60-53-61。fixed-state-index.jsonに完全prefix、元source pointer、実STM/壁/在庫/履歴、旧direct値を保存した。新root/反転/選び直しはない。422のD2 searched値は混入させない。

native callerは正本measurement::replayで完全prefixを合法・非終端・normalとして再生し、state projection（HistoryKey、全history_counts、ply/rules/synthetic、pawns/walls/stocks/STM/terminal）を422実観測と照合する。original input/resultのSHAを通常FileRefで検査する。oldNNUE/Sigma/Dは保存direct値だけを読み、新実行しない。全7状態のcanonical featuresも保存422と照合する。

## 最小差分と件数

production関数/encoder/head/traitは変更0。measurement.rsの既存cfg(test) module直後に4行追加し、一時的なmeasurement_static426_tests.rsを1つ加える疎patchだけ。最小before gzip、after context、strict GNU zero-fuzz forward/inverseを保存。全source鏡像は作らず、Rootは現在のnamed sourceへこのhunkだけを合成する。元422 callerはretired済みであり、復活・実行しない。今回callerも結果保存後に削除可能、再構成はGit/packetから行う。

新filterは `measurement::static426_tests::seven_saved_states_w_only_once`（quoridor-runner、measurement feature、lib test profile）。ignoredなので通常compileでは数値実行しない。Rootが真正buildしたtest executableに次を与える。

- QUORIDOR_STATIC426_INPUT: この実input.jsonの絶対path
- QUORIDOR_STATIC426_INPUT_SHA256: 同実SHA256
- QUORIDOR_STATIC426_OUTPUT: Rootが発行する未作成のunique output
- argv suffix: --ignored --exact measurement::static426_tests::seven_saved_states_w_only_once --nocapture --test-threads=1

通常Experiment/guardianのordered inputsにはこのpacket、元422 input/result、W descriptor/weights、元BEST43 descriptor、actual test artifact/build/current source/runtimeを含め、実before/after寿命を保護する。旧422 JSONに記載されたSigma/library参照は旧事実の文脈だけで、新Bでロード/再hashしない。未来image/Experiment/output FileRefは作っていない。

正本ResidualModel::load（typed fingerprint照合）、full_context(Scalar)、evaluate_view_with_scratchを再用する。pre/postは1回のcanonical headから取り、atanh/別head/別encodingはない。descriptorの尺度・Zero4・topology・distance_fit・activation関連の既存設定は元BEST43 descriptorと比較する。Wの重みだけを読む。old weightsは読まない。

constructorはResidualModel::load→from_parts→Model::from_parts/HeadRange::newの現sourceを確認し、allocation/finite/shape/SHA/fingerprint/conservative magnitude計算だけでcanonical head呼出しがない。constructor started/returnedを別保存し、constructor logical heads=0はこの固定sourceの静的根拠付きでありhardware観測ではない。evaluation_scratchもallocationだけ。新full_contextは7、headは完成時7を予定し、各entry前にstartedを永続化し、返却後returnedを増やす。上限28はconstructor/確認を含むwhole ceilingであり、残り21回を使用する予定はない。新delta/full parity、追加state、oldhead/Sigma/D、Searchは0。既存Wのchanged-weight correspondenceは旧423 scopeのまま再演しない。physical FT/head回数と実peakはUNKNOWN。

出力は旧422と同じcounts.NNUE_head_started/returned、NNUE_full_context_started/returned、rows[].NNUEのpre/post/bits/features等を使用する。rows[].saved422に元NNUE/Sigma/Dを保持し、Wとの差・符号（厳密0を0）・abs>=.99を記述する。候補endpoint4個をfull-root argmax/真のWDL/原因/正解labelに昇格しない。状態/モデル不一致、非finite、cap/errorは元FAILED/PARTIAL/UNKNOWNのままで補充0。head中断はpendingのまま開始/返却を区別する。setup/drop/wholeは包含し非加算、速度の証拠ではない。

## 検証と留保

Rustfmt edition2024 write/check、project Ruff no-cache format/check/lint、minimum-context strict patch forward/inverse、固定7メタデータ対応・独立prefix・旧direct成功保存/順序・実W参照の有限stdlib整合を確認した。これは旧422成功suiteや新native qualificationの再演ではない。新数値定義は一つ、Rootの型検査と実行が必要。新software fake model・Torch/NumPy/NVML importは0。

最初のpwdはactual turn_context確認より先に実行した（手順順序の逸脱）。その後、2026-10-16T21:26:58.734ZのSol6.1/high/Main/danger-full-access/neverを確認し、source/数値作業の前に本人claimを行った。最初のintake-v1は末尾rgの旧retired caller不一致でexit1（取得metadataは保存）となりFAILEDのまま。rust-format-v1は誤った/usr/bin/rustfmtのENOENTでchild未入場、rust-format-v2は実PATH /usr/local/cargo/bin/rustfmtで未実行formatを完了。元FAILED/NULLとdisk/費は保持し、成功へ書換えない。

実CPU10/guardian14は毎回既存physical_and_quietでdistinct core/available RAMを確認し、family1GiB inclcontroller/GPU0/hostreserve4GiB、bounded capture524288、CycleResources/directwait/reapを使用した。Main source intakeだけcanonical lease、private formatter/proofには不要なMain寿命を取得しない。future quiet/idle leaseは主張しない。STOP/実knownidentity fresh absence/handle/TMP/usageは別receiptを参照。科学AのtimingとBのnativeはRootが直列化する。旧423/421/424/425の結果・費、323/342.17のUSERPAUSE、default/models/weights/seals/newEは不変。
