"""One typed distance-fit comparison only, after the immutable8493 caller."""

import gzip
import hashlib
from pathlib import Path

OUT = Path(__file__).resolve().parent
before = (OUT.parent / "related-R1-v1/measurement_static426_tests.rs").read_bytes()
assert (
    hashlib.sha256(before).hexdigest()
    == "8493b9b467708307d7a8d20465a97bcf58d85134e215412ffb68393dbdff76d8"
)
(OUT / "before.rs.gz").write_bytes(gzip.compress(before, mtime=0))
s = before.decode()
helper = """fn distance_fit_check(actual: &Value, incumbent: &Value) -> Result<()> {
    for fit in [actual, incumbent] {
        let fields = fit.as_object().ok_or("distance_fit object required")?;
        if fields.len() != 2 || !fields.contains_key("a") || !fields.contains_key("b") {
            return Err("distance_fit exact a,b fields required".into());
        }
    }
    let actual: quoridor_nnue::DistanceFit = serde_json::from_value(actual.clone())?;
    let incumbent: quoridor_nnue::DistanceFit = serde_json::from_value(incumbent.clone())?;
    if ![actual.a, actual.b, incumbent.a, incumbent.b].iter().all(|v| v.is_finite())
        || actual.a.to_bits() != incumbent.a.to_bits()
        || actual.b.to_bits() != incumbent.b.to_bits()
    {
        return Err("distance_fit finite exact f32 bits mismatch".into());
    }
    Ok(())
}

"""
assert s.count('            "distance_fit",\n') == 1
s = s.replace('            "distance_fit",\n', "", 1)
needle = '        if desc["weights_SHA"] != p.nnue.weights.sha256'
assert s.count(needle) == 1
s = s.replace(
    needle,
    '        distance_fit_check(&desc["distance_fit"], &old_desc["distance_fit"])?;\n'
    + needle,
    1,
)
s = s.replace(
    "fn state(context: &SigmaContext) -> Value {",
    helper + "fn state(context: &SigmaContext) -> Value {",
    1,
)
s += """
#[test]
fn distance_fit_integer_float_zero_and_refusals_zero_head() {
    let integer = json!({"a":0,"b":0});
    let float = json!({"a":0.0,"b":0.0});
    assert!(distance_fit_check(&integer, &float).is_ok());
    assert!(distance_fit_check(&float, &integer).is_ok());
    for invalid in [
        json!({"a":0.125,"b":0}),
        json!({"a":0,"b":0.125}),
        json!({"a":-0.0,"b":0}),
        json!({"a":1e39,"b":0}),
        json!({"a":0}),
        json!({"a":0,"b":"0"}),
        json!({"a":null,"b":0}),
        json!({"a":0,"b":0,"extra":0}),
        Value::Null,
        json!([0,0]),
    ] {
        assert!(distance_fit_check(&invalid, &integer).is_err());
        assert!(distance_fit_check(&integer, &invalid).is_err());
    }
}
"""
(OUT / "measurement_static426_tests.rs").write_text(s)
