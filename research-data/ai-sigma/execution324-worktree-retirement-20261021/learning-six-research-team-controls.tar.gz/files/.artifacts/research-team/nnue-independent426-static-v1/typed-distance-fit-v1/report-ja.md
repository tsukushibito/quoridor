# 426.3: distance_fitの型付き比較だけを修復

元8493 caller/元ec8d R1 clearとoutput-failure zerohead PASS、元input b00b、元descriptor/weights/typed refsは不変。今回はthin delta AFTER8493だけ。Main/Git/Cargo/native/model/test/head実行は作者0。

distance_fitは他の必須JSON比較loopから一項目だけ外し、既存public quoridor_nnue::DistanceFit（a,b:f32、Serialize/Deserialize）として両descriptorの値をparseする。同じa/bだけのobjectを要求し、欠落/型不正/余分field/null等は拒否する。全4係数がfiniteで、a同士/b同士のto_bitsが厳密一致する場合だけ受け入れる。整数0と浮動小数0.0は同じ+0 f32として一致する。-0対+0はbit差として拒否する。f32へoverflowする数も拒否する。包括的なmetadata正規化、許容誤差、scale変更、validator bypassはない。

新fixtureは一つだけ。整数0/float0の双方向一致と、a/b各実係数差、符号付きzero bit差、f32 overflow、欠落/string/null/extra/非objectの双方向拒否をassertするsourceを追加した。filterはmeasurement::static426_tests::distance_fit_integer_float_zero_and_refusals_zero_head。UNBUILT/UNTYPED/UNRUNであり、作者はこれも元output-failure PASSも実行しない。Rootが必要なchanged-source compile/newfixture/lint/releaseと同426.4型付き入口確認を行う。

protected-proofは新helper/新fixtureと一field-list削除/一call挿入を逆変換すると元8493全BYTEが復元されることを確認した。R1 finish/terminal_write/既存zerohead fixture、C1/C2、モデル/head/encoder/FT/尺度/全履歴/親/capと他requiredJSONfieldは不変。source-body byte同一からAST不変と言えるが、作者がRust AST/typecheckを実行した主張ではない。最小caller before gzip、thin patch、strict GNU zero-fuzz forward/inverseを保存する。元descriptorJSONとSHAを変更しない。

原B job4c4265e2はFAILEDのまま。setup、7状態のboard/context同一性検証、descriptor比較は実際に入場したのでwhole-job未入場とは呼ばない。constructor/full NNUE context/headの各started/returnedは全0、準備済み7行はNOT_RUN_UNKNOWN。outer1.7768354490108322sを元scopeで一度保持し、nested native0.026587972010020167sを別加算しない。返却guardian NULLとdisk pending/attempted、旧notification supervisorの別寿命、process cleanup/STOPを元collectionで保持する。再開できるのは本当に未入場のモデル/head部分だけ、上限28/同7状態のまま。完了head再演・補充・row resetはない。

Actual context2026-10-16T22:12:09.117Z Sol6.1/high/Main/danger-full-access/neverを最初に確認。CPU10/guardian14/family1GiB inclcontroller/GPU0/reserve4GiBを既存fresh guardで適用し、bounded capture/directwait/reapを使用。普通のsource/format/static proofのみ。Rustfmt edition2024とproject Ruff no-cache/Markdown Prettierを担当範囲だけに適用し、必要API sourceのbefore/after参照・actual STOP/owned[]/一度のdirected usageをpacketに含める。Root324へ一度返し、review配送は作者0。旧caps/pauses/default/models/seals/RAWFAILED/費UNKNOWN不変。
