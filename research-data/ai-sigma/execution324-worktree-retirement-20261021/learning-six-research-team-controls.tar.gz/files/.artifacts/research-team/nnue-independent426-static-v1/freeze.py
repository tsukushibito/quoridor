"""Build the minimum private sparse patch and fixed metadata binding; no inference."""

import difflib
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")


def ref(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(
        path=str(p.resolve()),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{p.stat().st_mode & 0o777:04o}",
    )


before = '#[cfg(test)]\n#[path = "measurement_weight_correspondence_tests.rs"]\nmod weight_correspondence_tests;\n'
after = (
    before
    + '\n#[cfg(test)]\n#[path = "measurement_static426_tests.rs"]\nmod static426_tests;\n'
)
(OUT / "module-before.rs.gz").write_bytes(gzip.compress(before.encode(), mtime=0))
(OUT / "module-after.rs").write_text(after)
patch = "".join(
    difflib.unified_diff(
        before.splitlines(True),
        after.splitlines(True),
        fromfile="a/crates/quoridor-runner/src/measurement.rs",
        tofile="b/crates/quoridor-runner/src/measurement.rs",
    )
)
new = (OUT / "measurement_static426_tests.rs").read_text()
patch += "".join(
    difflib.unified_diff(
        [],
        new.splitlines(True),
        fromfile="/dev/null",
        tofile="b/crates/quoridor-runner/src/measurement_static426_tests.rs",
    )
)
(OUT / "source.patch").write_text(patch)
# Private tiny reconstruction only; never a whole Main source mirror.
work = OUT / "strict-patch-TMP"
base = work / "crates/quoridor-runner/src"
base.mkdir(parents=True)
(base / "measurement.rs").write_text(before)
captures = []
for reverse in (False, True):
    argv = ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(OUT / "source.patch")]
    if reverse:
        argv.insert(1, "--reverse")
    p = subprocess.run(argv, cwd=work, text=True, capture_output=True, check=True)
    captures.append(
        dict(argv=argv, exit_code=p.returncode, stdout=p.stdout, stderr=p.stderr)
    )
    if not reverse:
        assert (base / "measurement.rs").read_text() == after
        assert (base / "measurement_static426_tests.rs").read_bytes() == (
            OUT / "measurement_static426_tests.rs"
        ).read_bytes()
assert (base / "measurement.rs").read_text() == before
assert not (base / "measurement_static426_tests.rs").exists()
(base / "measurement.rs").unlink()
for d in (base, base.parent, base.parent.parent, work):
    d.rmdir()
(OUT / "strict-proof.json").write_text(
    json.dumps(
        dict(
            forward_inverse=captures,
            outside_module_insertion_bytes_unchanged=True,
            production_function_bodies_changed=0,
            whole_source_mirror_created=False,
            new_file_absence_restored=True,
            TMP_removed=True,
        ),
        indent=2,
    )
    + "\n"
)
# New finite fixed-state bookkeeping, not old tests, replay, or a fake model.
p = json.loads((OUT / "input.json").read_text())
old = json.loads((OUT / "saved422-input.json").read_text())
saved = json.loads((OUT / "saved422-result.json").read_text())
assert p["head_limit"] == 28 and len(old["rows"]) == len(saved["rows"]) == 7
assert len({tuple(x["prefix"]) for x in old["rows"]}) == 7
assert [x["id"] for x in old["rows"]] == [x["id"] for x in saved["rows"]]
assert p["nnue"] == json.loads((OUT / "saved-model-refs.json").read_text())["models"][0]
assert saved["models"]["NNUE"] == old["nnue"]
assert saved["counts"]["NNUE_head_returned"] == 7 and saved["status"] == "COMPLETE"
(OUT / "metadata-check.json").write_text(
    json.dumps(
        dict(
            status="PASS_metadata_only",
            states=7,
            unique_prefixes=7,
            original_order_preserved=True,
            old_saved_values_are_direct=True,
            new_head_calls=0,
            old_success_suite_replay=0,
            native_typecheck="UNRUN",
            Rust_numeric_definition="UNRUN",
            prospective_new_W_heads=7,
            whole_new_W_inclusive_head_ceiling=28,
        ),
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        dict(
            patch=ref(OUT / "source.patch"),
            input=ref(OUT / "input.json"),
            new_caller=ref(OUT / "measurement_static426_tests.rs"),
        )
    )
)
