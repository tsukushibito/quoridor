"""Prepare only the fixed W-only packet from accepted compact saved metadata."""

import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")


def ref(path):
    p = Path(path)
    b = p.read_bytes()
    return dict(
        path=str(p.resolve()),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{p.stat().st_mode & 0o777:04o}",
    )


models = json.loads((OUT / "saved-model-refs.json").read_text())["models"]
refs = json.loads((OUT / "intake-refs.json").read_text())
bind = {Path(x["path"]).name: x for x in refs[:2]}
old = json.loads((OUT / "saved422-input.json").read_text())
saved = json.loads((OUT / "saved422-result.json").read_text())
assert len(old["rows"]) == len(saved["rows"]) == 7
assert saved["status"] == "COMPLETE"
assert saved["models"]["NNUE"] == models[1] == old["nnue"]
assert all(
    r["prefix"] == s["prefix"] and r["id"] == s["id"] and s["status"] == "COMPLETE"
    for r, s in zip(old["rows"], saved["rows"], strict=True)
)
packet = dict(
    original_input=bind["input.json"],
    saved_result=bind["result.json"],
    nnue=models[0],
    head_limit=28,
)
(OUT / "input.json").write_text(json.dumps(packet, indent=2) + "\n")
(OUT / "fixed-state-index.json").write_text(
    json.dumps(
        [
            dict(
                id=r["id"],
                prefix=r["prefix"],
                source_file=r["source_file"],
                source_pointer=r["source_pointer"],
                state=s["state"],
                old_saved=dict(NNUE=s["NNUE"], Sigma=s["Sigma"], D=s["D"]),
                viewpoint="actual local STM; no root-backup sign",
            )
            for r, s in zip(old["rows"], saved["rows"], strict=True)
        ],
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "prepared": str(OUT / "input.json"),
            "states": 7,
            "new_numeric_rows": 0,
            "nnue": models[0],
        }
    )
)
