#[cfg(test)]
#[path = "measurement_weight_correspondence_tests.rs"]
mod weight_correspondence_tests;

#[cfg(test)]
#[path = "measurement_static426_tests.rs"]
mod static426_tests;
