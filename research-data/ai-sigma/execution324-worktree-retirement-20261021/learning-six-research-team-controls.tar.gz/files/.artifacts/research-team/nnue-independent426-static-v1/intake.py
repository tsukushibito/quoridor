import hashlib
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
refs = []


def read(path):
    p = ROOT / path
    before = p.stat()
    b = p.read_bytes()
    after = p.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_dev,
        after.st_ino,
        after.st_size,
        after.st_mtime_ns,
    )
    refs.append(
        dict(
            path=str(p),
            sha256=hashlib.sha256(b).hexdigest(),
            bytes=len(b),
            mode=f"{before.st_mode & 0o777:04o}",
        )
    )
    return b


for name in ("input.json", "result.json"):
    (OUT / ("saved422-" + name)).write_bytes(
        read(Path("research-data/ai-sigma/static-evaluators422") / name)
    )
x = json.loads(read(Path("research-data/ai-sigma/nnue-teacher-refresh423/result.json")))


def walk(x):
    if isinstance(x, dict):
        if (
            "selected_BEST_descriptor_metadata_ref_only" in x
            and x.get("BEST_step") == 118
        ):
            print(json.dumps(x["selected_BEST_descriptor_metadata_ref_only"]))
        for v in x.values():
            walk(v)
    elif isinstance(x, list):
        for v in x:
            walk(v)


walk(x)
for path, ranges in [
    ("crates/quoridor-runner/src/measurement.rs", [(1, 90), (650, 715), (910, 950)]),
    ("crates/quoridor-nnue/src/residual.rs", [(130, 225), (238, 255), (280, 355)]),
    (
        "crates/quoridor-runner/src/measurement_weight_correspondence_tests.rs",
        [(1, 200)],
    ),
]:
    b = read(Path(path))
    lines = b.decode().splitlines(keepends=True)
    text = "".join(
        f"// ORIGINAL {path}:{lo}-{hi}\n" + "".join(lines[lo - 1 : hi])
        for lo, hi in ranges
    )
    (OUT / (Path(path).name + ".scoped.txt")).write_text(text)
    print(text)
(OUT / "intake-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
