"""Only static sparse-delta/recovery checks; new Rust assertions stay UNRUN."""

import difflib
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
before = gzip.decompress((OUT / "before.rs.gz").read_bytes()).decode()
after = (OUT / "measurement_static426_tests.rs").read_text()
assert (
    hashlib.sha256(before.encode()).hexdigest()
    == "8493b9b467708307d7a8d20465a97bcf58d85134e215412ffb68393dbdff76d8"
)
recovered = after[
    : after.index(
        "\n#[test]\nfn distance_fit_integer_float_zero_and_refusals_zero_head()"
    )
]
start = recovered.index("fn distance_fit_check(")
end = recovered.index("fn state(", start)
recovered = recovered[:start] + recovered[end:]
recovered = recovered.replace(
    '        distance_fit_check(&desc["distance_fit"], &old_desc["distance_fit"])?;\n',
    "",
    1,
)
recovered = recovered.replace(
    '            "route_sigma_f32",\n',
    '            "route_sigma_f32",\n            "distance_fit",\n',
    1,
)
assert recovered == before
patch = "".join(
    difflib.unified_diff(
        before.splitlines(True),
        after.splitlines(True),
        fromfile="a/crates/quoridor-runner/src/measurement_static426_tests.rs",
        tofile="b/crates/quoridor-runner/src/measurement_static426_tests.rs",
    )
)
(OUT / "typed-distance-fit.patch").write_text(patch)
work = OUT / "strict-TMP"
target = work / "crates/quoridor-runner/src/measurement_static426_tests.rs"
target.parent.mkdir(parents=True)
target.write_text(before)
records = []
for inverse in (False, True):
    cmd = [
        "patch",
        "--batch",
        "--fuzz=0",
        "-p1",
        "-i",
        str(OUT / "typed-distance-fit.patch"),
    ]
    if inverse:
        cmd.insert(1, "--reverse")
    x = subprocess.run(cmd, cwd=work, text=True, capture_output=True, check=True)
    assert target.read_text() == (before if inverse else after)
    records.append(
        dict(argv=cmd, exit_code=x.returncode, stdout=x.stdout, stderr=x.stderr)
    )
target.unlink()
for d in (target.parent, target.parent.parent, target.parent.parent.parent, work):
    d.rmdir()
proof = dict(
    before_SHA=hashlib.sha256(before.encode()).hexdigest(),
    post_SHA=hashlib.sha256(after.encode()).hexdigest(),
    strict_forward_inverse=records,
    exact_recovery="remove ONLY new typed helper/one new fixture, reverse one field-list removal and inserted call; every remaining original BYTE exact",
    protected="R1 finish/terminal_write and prior zerohead test; C1/C2 labels; model/head/context/cap/identity/history/normalization and all other required JSON comparisons outside distance_fit",
    production_math_model_or_descriptor_change=0,
    old_inputs_packets_or_outputs_changed=0,
    newfixture="measurement::static426_tests::distance_fit_integer_float_zero_and_refusals_zero_head",
    newfixture_status="UNBUILT/UNTYPED/UNRUN; source only",
    original_native_failure="setup/7 board and descriptor work entered FAILED; all constructor/context/head0 retained; not whole-job-unentered",
    author_native_model_test_head_calls=0,
    TMP_removed=True,
)
(OUT / "protected-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            "post_SHA": proof["post_SHA"],
            "exact_recovery": True,
            "newfixture_execution": 0,
        }
    )
)
