"""426B frozen Rust source/metadata checks only; no target code execution."""

import ast
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
TEAM = OWN.parents[1]
BASE = TEAM / "nnue-independent426-static-v1"
ROOT = Path("/workspaces/quoridor/.artifacts/research-team/integration324/nnue-independent426-v1")
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
T0 = time.monotonic()
START = datetime.datetime.now(datetime.timezone.utc).isoformat()
REFS = {}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read(ref):
    p = Path(ref["path"])
    i = p.lstat()
    assert not p.is_symlink() and i.st_size == ref["bytes"] <= 1048576
    with p.open("rb") as f:
        b = f.read(ref["bytes"] + 1)
    a = dict(path=str(p), sha256=sha(b), bytes=len(b), mode=f"{i.st_mode & 4095:04o}")
    assert a == {k: ref[k] for k in a}, (a, ref)
    REFS[str(p)] = a
    return b


def witness(p):
    p = Path(p)
    i = p.lstat()
    assert i.st_size <= 1048576
    with p.open("rb") as f:
        b = f.read(1048577)
    return read(dict(path=str(p), sha256=sha(b), bytes=len(b), mode=f"{i.st_mode & 4095:04o}"))


root_ref = dict(
    path=str(BASE / "source-binding.json"),
    sha256="7f4ff8f09cfb1c99d6c3e22b41ae992af0cf4a2da98b133119da9786150187b2",
    bytes=7410,
    mode="0644",
)
binding = json.loads(read(root_ref))
files = binding["files"]
for ref in files.values():
    read(ref)
read(binding["contract"])
composition = json.loads(witness(ROOT / "static-preparation-v1/source-composition.json"))
route = json.loads(witness(ROOT / "intake-v1/entry-route.json"))
assert composition["binding"] == root_ref
old_module = gzip.decompress(read(files["module-before.rs.gz"]))
new_module = read(files["module-after.rs"])
whole_before = gzip.decompress(read(composition["before_recovery"]))
assert (
    len(whole_before) == composition["before"]["bytes"]
    and sha(whole_before) == composition["before"]["sha256"]
)
whole_post = read(composition["after"])
assert (
    whole_before.count(old_module) == 1
    and whole_before.replace(old_module, new_module, 1) == whole_post
)
assert whole_post.replace(new_module, old_module, 1) == whole_before
caller = read(files["measurement_static426_tests.rs"])
assert caller == read(composition["new_caller"])
# The author patch is a minimum owner fragment, not a zero-offset wholeMain patch.
utility_path = TEAM / "sigma-alpha420-review-v1/static_check.py"
ua = ast.parse(utility_path.read_bytes())
u = {"re": re}
exec(
    compile(
        ast.Module(
            body=[
                n
                for n in ua.body
                if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
            ],
            type_ignores=[],
        ),
        str(utility_path),
        "exec",
    ),
    u,
)
parts = u["split_patch"](read(files["source.patch"]))
hunks = 0
for name, old, new in [
    ("crates/quoridor-runner/src/measurement.rs", old_module, new_module),
    ("crates/quoridor-runner/src/measurement_static426_tests.rs", b"", caller),
]:
    f, n = u["apply"](old, parts[name])
    r, m = u["apply"](new, parts[name], True)
    assert f == new and r == old and n == m
    hunks += n
packet = json.loads(read(files["input.json"]))
assert packet["head_limit"] == 28
assert (
    packet["nnue"] == route["models"][0]
    and packet["original_input"] == route["B_original_seven_input"]
    and packet["saved_result"] == route["B_saved_old_values"]
)
original = json.loads(read(packet["original_input"]))
saved = json.loads(read(packet["saved_result"]))
index = json.loads(read(files["fixed-state-index.json"]))
assert (
    len(original["rows"]) == len(saved["rows"]) == len(index) == 7 and saved["status"] == "COMPLETE"
)
assert len({tuple(x["prefix"]) for x in original["rows"]}) == 7
assert original["nnue"] == saved["models"]["NNUE"]
for a, b, c in zip(original["rows"], saved["rows"], index):
    assert (
        a["id"] == b["id"] == c["id"]
        and a["prefix"] == b["prefix"] == c["prefix"]
        and b["status"] == "COMPLETE"
    )
    assert c["state"] == b["state"] and c["old_saved"] == {k: b[k] for k in ["NNUE", "Sigma", "D"]}
    assert a["source_file"] == c["source_file"] and a["source_pointer"] == c["source_pointer"]
    assert (
        b["NNUE"]["features"]["side"] == b["state"]["side"]
        and b["state"]["terminal"] is None
        and b["state"]["winner"] is None
        and b["state"]["identity"]["synthetic"] is False
    )
assert [r["id"] for r in original["rows"][:3]] == [
    "distance-slot004-ply011",
    "distance-slot004-ply039",
    "distance-slot005-ply012",
]
# Hash unchanged production dependencies, inspect only required constructor/context/head ranges.
intake = json.loads(read(files["intake-refs.json"]))
residual_ref = next(r for r in intake if r["path"].endswith("/residual.rs"))
residual = read(residual_ref).decode()
base = read(json.loads(read(files["base-constructor-ref.json"]))).decode()
ctor = residual[
    residual.index("    pub fn from_parts(") : residual.index("    pub fn full_features(")
]
base_ctor = base[base.index("    pub fn from_parts(") : base.index("    pub fn topology(")]
head_range = residual[residual.index("    fn new(t: Topology") : residual.index("    fn permits(")]
scratch = residual[
    residual.index("    pub fn evaluation_scratch(") : residual.index(
        "    /// One-shot inference convenience."
    )
]
assert not re.search(
    r"\b(?:evaluate|full_context|linear_head|value_with_scratch)\w*\s*\(",
    ctor + base_ctor + head_range + scratch,
)
view = residual[
    residual.index("    pub fn evaluate_view_with_scratch(") : residual.index(
        "    /// Shared packed-input/"
    )
]
assert (
    view.count("self.value_with_scratch_observed(") == 1
    and view.count("self.linear_head_with_scratch_observed(") == 1
)
source = caller.decode()
assert (
    source.count("ResidualModel::load(")
    == source.count("model.full_context(")
    == source.count("model.evaluate_view_with_scratch(")
    == 1
)
assert source.count("#[test]") == source.count("#[ignore =") == 1
assert (
    "original_rows.len() != 7" in source
    and "saved_rows.len() != 7" in source
    and ">= p.head_limit" in source
)
assert (
    'state(&root) != prior["state"]' in source
    and 'features != saved_rows[i]["NNUE"]["features"]' in source
    and 'state(root) != saved_rows[i]["state"]' in source
)
assert all(
    x not in source
    for x in [
        "OrtBackend",
        "LoadedModel::load",
        "evaluate_delta",
        "model.delta(",
        "SearchSession::",
    ]
)
lines = source.splitlines()
evidence = {}
for key, needle in [
    ("final_persist", "let saved = persist("),
    ("stdout", "    println!("),
    ("stderr", "        eprintln!("),
    ("primary_return", "    work?;"),
    ("head_pending_persist", "let view = model.evaluate_view_with_scratch("),
]:
    evidence[key] = next(i + 1 for i, l in enumerate(lines) if needle in l)
assert (
    evidence["final_persist"] < evidence["stdout"] < evidence["stderr"] < evidence["primary_return"]
)
assert source.count('"secondary_errors"') == 1
for ref in list(REFS.values()):
    read(ref)
STOP = datetime.datetime.now(datetime.timezone.utc).isoformat()
p = dict(
    target=root_ref,
    refs_before_after=REFS,
    selected_refs=len(REFS),
    selected_unique_bytes=sum(r["bytes"] for r in REFS.values()),
    strict_fragment_forward_inverse_hunks=hunks,
    wholeMain_unique_fragment_composition_inverse_exact=True,
    production_outside_module_insertion_bytes_exact=True,
    caller_current_Main_exact=True,
    states7_order_prefix_saved_state_features_exact=True,
    constructor_head_calls_source_zero=True,
    prospective_full_context7_head7_ceiling28=True,
    no_new_old_models_Sigma_D_Search_or_delta_calls=True,
    counter_scope="started is pre-persist reservation/maybe-entered; returned increments only after Ok; interruption/Err requires UNKNOWN, not actual invocation equality",
    failure_path_source_lines=evidence,
    normal_guarded_head_not_all_scalar_hardware=True,
    target_functions_tests_models_native_executed=0,
    start=START,
    reader_STOP=STOP,
    own_identity=dict(
        pid=os.getpid(),
        start_ticks=Path(f"/proc/{os.getpid()}/stat").read_text().rsplit(")", 1)[1].split()[19],
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    ),
    helper_wall_s=time.monotonic() - T0,
    self_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    family_continuous_peak="UNKNOWN",
    leases_acquired=[],
    owned_readers_children_jobs_handles_TMP_leases_remaining=[],
)
(OWN / "static-proof.json").write_text(json.dumps(p, indent=2) + "\n")
print(
    json.dumps(
        {
            k: p[k]
            for k in [
                "selected_refs",
                "selected_unique_bytes",
                "strict_fragment_forward_inverse_hunks",
                "reader_STOP",
                "own_identity",
                "failure_path_source_lines",
                "helper_wall_s",
                "self_ru_maxrss_KiB",
            ]
        }
    )
)
