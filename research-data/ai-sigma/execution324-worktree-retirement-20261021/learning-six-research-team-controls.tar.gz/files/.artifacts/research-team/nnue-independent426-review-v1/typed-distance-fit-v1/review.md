型付きdistance_fit関連確認: SOURCE CLEAR、blocker 0 / ordinary 0。

固定binding 146bb858、post 6540e526だけを対象とした。既存DistanceFitのa/b:f32 Deserializeを使い、両側のobjectが正確にa,bの2項目であることを先に確認する。finiteとto_bitsの一致により、整数0と浮動小数0.0は同じ正のzeroとして比較される。異なるf32値、符号付きzeroの不一致、非finiteへのoverflowは拒否し、missing/string/null/extra/nonobjectも型または形状検査で拒否する。許容誤差は導入されていない。同じネイティブf32 bitsに丸められる表現同士の一致は、この型付き境界の意図した範囲である。

4ハンクを独立にゼロoffset・完全context照合で正逆適用した。さらに新helperと新fixtureを除き、field-list/callの編集を逆に戻すと8493の全バイトを回復する。R1の原error優先・publication secondary、C1/C2、他のJSON照合、モデル/履歴/context/head/capコードはそのままである。Main postと保護measurementも選択FileRefに一致した。旧8493は保存gzipの歴史的beforeである。

新zero-head fixtureは定義のみ読んだ。Rustの型検査・compile・fixture・model load・7head・nativeは実行していない。元4c4265e2はsetupでFAILED、constructor/context/head0、7件NOT_RUN_UNKNOWNのまま。outer 1.7768354490108322秒とnested native .026587972010020167秒を加算しない。原R1 negative、その後の修復clear、統計sourceの別ordinary 2件は変更しない。source clearはsoftware/モデル/数値/性能/棋力の資格ではない。

選択refsは全て読取前後のSHA/size/mode一致。実reader STOP 2026-10-16T22:24:26.387736+00:00。有限stdlib helperはforeground exit0、元PIDはfresh absent。owned readers/children/jobs/handles/TMP/leases/remainingは空。canonical leaseは取得していない。tool内部waitpid等の詳細と連続family peakはUNKNOWN。CPU16、AS512MiB、helper自己ru_maxrss 15668KiBはそれぞれ別の事実であり、継続family証明ではない。
