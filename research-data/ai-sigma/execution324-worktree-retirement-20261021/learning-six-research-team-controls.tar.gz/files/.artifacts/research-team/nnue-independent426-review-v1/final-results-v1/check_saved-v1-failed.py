"""Finite saved-metadata joins only; never imports or executes target code."""

import ast
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import stat
import time
from collections import Counter
from datetime import datetime, timezone

resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
START = time.monotonic()
ROOT = Path("/workspaces/quoridor")
BASE = (
    ROOT
    / ".worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1"
)
OUT = Path(__file__).parent
REFS = {}
INDEX = {}


def read(ref):
    path = Path(ref["path"])
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode)
    assert before.st_size == ref["bytes"] <= 1200000
    assert format(stat.S_IMODE(before.st_mode), "04o") == ref["mode"]
    with path.open("rb") as stream:
        body = stream.read(ref["bytes"] + 1)
    assert len(body) == ref["bytes"]
    assert hashlib.sha256(body).hexdigest() == ref["sha256"]
    assert path.lstat().st_ino == before.st_ino
    REFS[str(path)] = ref
    assert sum(r["bytes"] for r in REFS.values()) <= 4 * 1024 * 1024
    return body


def capture(path):
    """Bind a selected saved derivative not independently listed in completion."""
    path = Path(path)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_size <= 1200000
    with path.open("rb") as stream:
        body = stream.read(info.st_size + 1)
    ref = {
        "path": str(path),
        "sha256": hashlib.sha256(body).hexdigest(),
        "bytes": len(body),
        "mode": format(stat.S_IMODE(info.st_mode), "04o"),
    }
    return read(ref)


def load(ref):
    return json.loads(read(ref))


target = {
    "path": str(BASE / "completion.json"),
    "sha256": "e98476ccf446407fa74cb8c062da0cc4cd97a32f4abed858af9e1192990b1851",
    "bytes": 11007,
    "mode": "0644",
}
completion = load(target)
arts = completion["artifacts"]
for name in [
    "report-ja.md",
    "checks.json",
    "control.json",
    "STOP.json",
    "next-learning-proposal.json",
]:
    read(arts[name])
result = load(arts["result.json"])
table = load(arts["static-seven-table.json"])
selected = load(arts["selectedrefs-final.json"])
for item in selected["selected_small_sources"]:
    assert item["MATCH"] and item["before_parse"] == item["final"]
    INDEX[item["final"]["path"]] = item["final"]


def named(suffix):
    found = [r for p, r in INDEX.items() if p.endswith(suffix)]
    assert len(found) == 1, suffix
    return found[0]


# Original book, authoritative schedule and carrier mapping, no rules replay.
book = load(named("/arena-settings-v1/arena-book.json"))["families"]
schedule = load(named("/arena-settings-v1/schedule.json"))
carrier = load(named("/arena-settings-v1/carrier-provenance.json"))["selected"]
assert len(book) == len(carrier) == 192 and len(schedule) == 384
configs = [load(named(f"/arena384-v1/config-{i:03}.json")) for i in range(12)]
families = json.loads(capture(BASE / "A-v1/families.json"))
games = list(csv.DictReader(io.StringIO(capture(BASE / "A-v1/games.csv").decode())))
family_csv = list(csv.DictReader(io.StringIO(capture(BASE / "A-v1/families.csv").decode())))
assert len(families) == len(family_csv) == 192 and len(games) == 384
assert len({f["canonical_family"] for f in families}) == 192
by_id = {f["analysis_family_index"]: f for f in families}
native_csv = []
for batch in range(12):
    native_csv.append(
        list(csv.DictReader(io.StringIO(read(named(f"/batch-{batch:03}/data/games.csv")).decode())))
    )
    assert len(native_csv[-1]) == 32
for index, family in enumerate(families):
    original = book[index]
    provenance = carrier[index]
    assert family["analysis_family_index"] == index == provenance["selection_ordinal"]
    assert (
        family["native_global_request_id"]
        == original["family_id"]
        == provenance["global_request_id"]
    )
    assert family["request_id"] == original["id"] == provenance["request_id"]
    assert family["canonical_family"] == provenance["canonical_family"]
    assert family["prefix"] == original["prefix"]
    assert family["root_key"] == original["root_key"]
    history = json.dumps(original["history_counts"], separators=(",", ":"), sort_keys=True).encode()
    assert (
        hashlib.sha256(history).hexdigest() == family["complete_history_SHA256_utf8_sorted_compact"]
    )
    assert family["lineage"] == "426-independent:" + original["id"]
    assert float(family_csv[index]["candidate_score"]) == family["candidate_score"]
for slot, (row, planned) in enumerate(zip(games, schedule)):
    assert int(row["global_slot"]) == planned["slot"] == slot
    batch, local = int(row["batch"]), int(row["local_game"])
    assert (batch, local) == (planned["batch"], planned["local_game"])
    fid = int(row["analysis_family_index"])
    family = by_id[fid]
    assert (
        int(row["native_global_request_id"])
        == planned["family_id"]
        == family["native_global_request_id"]
    )
    assert row["canonical_family"] == family["canonical_family"]
    opening = configs[batch]["arena"]["book"]["openings"][planned["matchup"]]
    assert opening["reference"]["settings"] == book[fid]
    assert (
        opening["prefix"] == family["prefix"]
        and opening["lineage"] == row["lineage"] == family["lineage"]
    )
    raw_row = native_csv[batch][local]
    for source, dest in [
        ("game", "local_game"),
        ("family", "native_family_display"),
        ("winner", "winner"),
        ("candidate_color", "candidate_color"),
        ("status", "status"),
        ("plies", "reported_plies"),
    ]:
        assert raw_row[source] == row[dest]
    assert row["status"] == "goal" and raw_row["started"] == "true" and not raw_row["failure"]
    colour = int(row["candidate_color"])
    assert colour == planned["candidate_color"]
    score = int(row["winner"]) == colour
    assert int(row["candidate_score"]) == score == family["colour_scores"][colour]
assert all(f["candidate_score"] == sum(f["colour_scores"]) / 2 for f in families)
assert Counter(f["candidate_score"] for f in families) == {0.0: 48, 0.5: 105, 1.0: 39}
assert sum(int(g["candidate_score"]) for g in games) == 183
assert [
    sum(int(g["candidate_score"]) for g in games if int(g["candidate_color"]) == c) for c in [0, 1]
] == [92, 91]

# Read the actual executed body as syntax only; never import NumPy or target code.
stat_refs = completion["actual_statistical_execution"]
old_ast = ast.parse(read(stat_refs["original_frozen_source"]))
new_ast = ast.parse(read(stat_refs["executed_bounded_CLI_source"]))
old_fn = next(
    n
    for n in old_ast.body
    if isinstance(n, ast.FunctionDef) and n.name == "interval_from_complete_family_scores"
)
new_fn = next(n for n in new_ast.body if isinstance(n, ast.FunctionDef) and n.name == old_fn.name)
assert ast.dump(old_fn) == ast.dump(new_fn)
assert ast.dump(
    ast.Module(
        body=[n for n in old_ast.body if not isinstance(n, ast.FunctionDef) or n.name != "main"],
        type_ignores=[],
    )
) == ast.dump(
    ast.Module(
        body=[n for n in new_ast.body if not isinstance(n, ast.FunctionDef) or n.name != "main"],
        type_ignores=[],
    )
)
boot_input = load(stat_refs["input"])
boot_output = load(stat_refs["output"])
binding = load(stat_refs["binding"])
lifetime = load(stat_refs["actual_lifetime"])
stdout = capture(BASE / "A-v1/original192-family-bootstrap-once.full.log")
assert (
    len(stdout) == lifetime["stdout_bytes"]
    and hashlib.sha256(stdout).hexdigest() == lifetime["stdout_sha256"]
)
assert lifetime["returncode"] == 0 and lifetime["directwait_reaped"] and lifetime["handles_closed"]
assert lifetime["owned_children_TMP_leases_remaining"] == []
assert boot_input["all_384_complete"] is True and boot_input["planned_family_count"] == 192
for i, entry in enumerate(boot_input["complete_families"]):
    assert entry["global_family_id"] == i
    assert entry["native_global_request_id"] == families[i]["native_global_request_id"]
    assert entry["candidate_score"] == families[i]["candidate_score"]
assert len(boot_input["complete_families"]) == 192
assert binding["executions"] == 1 and binding["result"] == boot_output
assert (
    boot_output["input"] == stat_refs["input"]
    and boot_output["executed_statistical_source"] == stat_refs["executed_bounded_CLI_source"]
)
assert boot_output["python_version"] == "3.14.7" and boot_output["numpy_version"] == "2.5.3"
assert boot_output["seed"] == 42620261016 and boot_output["executed_resamples"] == 10000
assert boot_output["rng"] == "NumPy Generator(PCG64)" and boot_output["quantile_method"] == "linear"
assert boot_output["family_mean"] == 183 / 384 == 0.4765625
assert boot_output["percentile_95"] == [0.4296875, 0.5234375]
assert boot_output["criterion_fixed_book_time_only"] == "NOT_MET"

# Current seven saved values against original422, without recomputing any head.
b_collection = load(named("/static-seven-typed-v1/collection.json"))
b = load(b_collection["result"])
old = load(named("/static-evaluators422/result.json"))
assert len(b["rows"]) == len(old["rows"]) == len(table["rows"]) == 7
for current, prior, compared in zip(b["rows"], old["rows"], table["rows"]):
    assert current["id"] == prior["id"] == compared["id"] and current["status"] == "COMPLETE"
    assert current["prefix"] == prior["prefix"] and current["state"] == prior["state"]
    assert current["NNUE"]["features"] == prior["NNUE"]["features"]
    assert current["saved422"] == {k: prior[k] for k in ["NNUE", "Sigma", "D"]}
    for key in ["pre_tanh", "post_tanh"]:
        assert compared["W_" + key.split("_")[0]] == current["NNUE"][key]
        assert compared["old_" + key.split("_")[0]] == prior["NNUE"][key]
    sign = 1 if current["state"]["side"] == prior["original_parent_side"] else -1
    assert compared["original_parent_view_sign"] == sign
    assert compared["W_parent_view_post"] == sign * current["NNUE"]["post_tanh"]
assert all((r["old_post"] > 0) == (r["W_post"] > 0) for r in table["rows"])
assert (
    sum(abs(r["old_post"]) >= 0.99 for r in table["rows"])
    == sum(abs(r["W_post"]) >= 0.99 for r in table["rows"])
    == 3
)
assert all(abs(r["W_pre"]) < abs(r["old_pre"]) for r in table["rows"])
assert b["counts"] == b_collection["counts"] == result["B"]["counts"]
assert b_collection["total_logical_canonical_heads"] == 7 <= b_collection["inclusive_cap"] == 28
assert all(
    b[k] == 0
    for k in [
        "Search_calls",
        "new_D_calls",
        "new_Sigma_rows",
        "new_delta_calls",
        "new_oldNNUE_heads",
    ]
)
assert (
    result["B"]["temporary_inlet_retirement"]["caller_exact_immutable_reconstruction"]["sha256"]
    == "6540e5261594fb900bf4ef87b098832e4330e35004af3633ead7a14c61104b54"
)

raw = load(completion["original_RAW_once"]["summary"])
assert raw["record_count"] == 384 and raw["discrepancies"] == []
assert sum(m["accepted_completed"] for m in raw["model"]) == 16733
assert sum(m["receipt_late"] for m in raw["model"]) == 0
assert (
    sum(m["whole_search_work_alternative"]["nodes"]["sum"] for m in raw["model"])
    == result["A"]["charged_nodes"]
    == 1640581337
)
assert sum(result["A"]["disjoint_quotas"]) == 1640581337
assert all(n <= 250000000 for n in result["A"]["disjoint_quotas"])
assert 3000000000 - 1640581337 == result["A"]["unused_quota_not_lent"]
assert (
    abs(
        sum(result["known_original_outer_seconds_once"].values())
        - result["known_original_outer_subtotal_seconds"]
    )
    < 1e-9
)
assert 3763 * 8 == 30104 == 117 * 256 + 152

# Final selected custody check ends the source/saved reader, before report/admin.
for ref in list(REFS.values()):
    read(ref)
stop = datetime.now(timezone.utc).isoformat()
pid = os.getpid()
proof = {
    "target": target,
    "selected_refs_before_after": list(REFS.values()),
    "selected_unique_bytes": sum(r["bytes"] for r in REFS.values()),
    "family_schedule_CSV_join": "192 full-history/family identities, 384 two-colour slots exact; native classification reused",
    "bootstrap": "actual source/input/output/receipt joined; statistic AST exact; NOT re-executed",
    "B": "seven saved full states/features/pre/post/parent-view exact; zero new heads",
    "work_cost_proposal_arithmetic": "MATCH",
    "reader_STOP": stop,
    "identity": {
        "pid": pid,
        "start_ticks": Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[19],
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    },
    "affinity": sorted(os.sched_getaffinity(0)),
    "physical_core16": Path("/sys/devices/system/cpu/cpu16/topology/core_id").read_text().strip(),
    "physical_core18": Path("/sys/devices/system/cpu/cpu18/topology/core_id").read_text().strip(),
    "MemAvailable": next(
        s for s in Path("/proc/meminfo").read_text().splitlines() if s.startswith("MemAvailable:")
    ),
    "continuous_family_peak": "UNKNOWN; assigned family1GiB envelope not a continuous-peak certificate",
    "self_ru_maxrss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "elapsed_seconds": time.monotonic() - START,
    "lease_acquired": False,
    "target_import_execution_NumPy_RAW_decode_native": 0,
    "owned_remaining": [],
}
(OUT / "static-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            k: proof[k]
            for k in [
                "reader_STOP",
                "identity",
                "selected_unique_bytes",
                "self_ru_maxrss_kib",
                "elapsed_seconds",
            ]
        }
    )
)
