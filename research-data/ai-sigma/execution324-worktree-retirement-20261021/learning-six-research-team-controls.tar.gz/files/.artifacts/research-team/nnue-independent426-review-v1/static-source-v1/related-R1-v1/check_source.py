"""R1/C1/C2 Rust-source bytes and metadata only, never target execution."""

import ast
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
TEAM = OWN.parents[2]
BASE = TEAM / "nnue-independent426-static-v1/related-R1-v1"
ROOT = Path("/workspaces/quoridor/.artifacts/research-team/integration324/nnue-independent426-v1")
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
T0 = time.monotonic()
START = datetime.datetime.now(datetime.timezone.utc).isoformat()
REFS = {}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read(ref):
    p = Path(ref["path"])
    i = p.lstat()
    assert not p.is_symlink() and i.st_size == ref["bytes"] <= 131072
    with p.open("rb") as f:
        b = f.read(ref["bytes"] + 1)
    a = dict(path=str(p), sha256=sha(b), bytes=len(b), mode=f"{i.st_mode & 4095:04o}")
    assert a == {k: ref[k] for k in a}, (a, ref)
    REFS[str(p)] = a
    return b


def witness(p):
    p = Path(p)
    i = p.lstat()
    assert i.st_size <= 131072
    with p.open("rb") as f:
        b = f.read(131073)
    return read(dict(path=str(p), sha256=sha(b), bytes=len(b), mode=f"{i.st_mode & 4095:04o}"))


def function(raw, name):
    start = raw.index(("fn " + name + "(").encode())
    end = raw.index(b"\n}\n", start) + 3
    return raw[start:end]


root_ref = dict(
    path=str(BASE / "source-binding.json"),
    sha256="ec8d0a8185abbafcff7c88d0307d7a17e9e1bfe838e48e0fb3eed6973416f8f9",
    bytes=4662,
    mode="0644",
)
binding = json.loads(read(root_ref))
for r in [
    binding["original_binding"],
    binding["original_input"],
    binding["original_caller"],
    binding["negative_review"],
    *binding["files"].values(),
]:
    read(r)
files = binding["files"]
post = read(files["measurement_static426_tests.rs"])
before = gzip.decompress(read(files["before.rs.gz"]))
assert sha(before) == binding["original_caller"]["sha256"] and before == read(
    binding["original_caller"]
)
composition = json.loads(witness(ROOT / "static-related-preparation-v1/source-composition.json"))
assert composition["source_binding"] == root_ref and read(composition["after"]) == post
assert composition["before"]["sha256"] == sha(before)
read(composition["protected_main_module"])
# Strict unified patch using only our prior reviewer utility, never Rust parsing/execution.
utilpath = TEAM / "sigma-alpha420-review-v1/static_check.py"
tree = ast.parse(utilpath.read_bytes())
u = {"re": re}
exec(
    compile(
        ast.Module(
            body=[
                n
                for n in tree.body
                if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
            ],
            type_ignores=[],
        ),
        str(utilpath),
        "exec",
    ),
    u,
)
parts = u["split_patch"](read(files["related.patch"]))
assert len(parts) == 1
patch = parts["crates/quoridor-runner/src/measurement_static426_tests.rs"]
f, n = u["apply"](before, patch)
r, m = u["apply"](post, patch, True)
assert f == post and r == before and n == m
protected = {}
for name in ["persist", "state", "comparison", "saved_f32"]:
    old = function(before, name)
    assert old == function(post, name)
    protected[name] = sha(old)
old_start = before.index(b"    let work = (|| -> Result<()> {")
new_start = post.index(b"    let work = (|| -> Result<()> {")
old_end = before.index(b"    let saved = persist(&mut file, &report);", old_start)
new_end = post.index(b"    finish(\n", new_start)
assert before[old_start:old_end] == post[new_start:new_end]
protected["numerical_work_model_caps_drop_status"] = sha(before[old_start:old_end])
text = post.decode()
finish = function(post, "finish").decode()
writer = function(post, "terminal_write").decode()
assert "println!" not in text and "eprintln!" not in text
assert "let mut first = work.err();" in finish and "first.map_or(Ok(()), Err)" in finish
assert finish.count("if first.is_none()") == 3
assert "let saved = save(report);" in finish and finish.index(
    "ATTEMPTED_RETURN_UNKNOWN_IN_REPORT"
) < finish.index("let saved = save(report);")
assert "NOT_YET_ATTEMPTED_UNKNOWN_IN_REPORT" in finish
assert 'if saved.is_ok(){"OK"}else{"FAILED"}' in finish
assert (
    '"stage":"final_persist"' in finish
    and '"stage":"stdout"' in finish
    and '"stage":"stderr"' in finish
)
assert (
    "match terminal_write(stdout, &receipt)" in finish
    and "match terminal_write(stderr, &receipt)" in finish
)
assert (
    '"work_status":report["status"]' in finish
    and '"final_persistence":report["final_persistence"]' in finish
)
assert '"NNUE_head_started_reservations"' in finish and '"NNUE_head_returned_Ok_only"' in finish
assert (
    "if bytes.len() > 4096" in writer
    and "writer.write_all(&bytes)?;" in writer
    and "writer.flush()?;" in writer
)
assert writer.index("if bytes.len() > 4096") < writer.index("writer.write_all(&bytes)?;")
assert (
    '"FT_context_mode":"Scalar"' in text
    and '"head_route":"unchanged canonical magnitude-guarded head; hardware route not measured"'
    in text
)
assert (
    "pre-persist reservations/maybe-entered" in text
    and "Ok-only; Err returns not counted; pending is not zero work" in text
)
assert text.count("#[test]") == 2 and text.count("#[ignore =") == 1
assert (
    text.count("model.full_context(")
    == text.count("model.evaluate_view_with_scratch(")
    == text.count("ResidualModel::load(")
    == 1
)
assert "fn output_failures_keep_original_work_error_zero_head()" in text
assert (
    "std::ptr::eq(" in text
    and '["final_persist", "stdout", "stderr"]' in text
    and "assert!(fallback.len() <= 4096)" in text
)
for ref in list(REFS.values()):
    read(ref)
STOP = datetime.datetime.now(datetime.timezone.utc).isoformat()
p = dict(
    target=root_ref,
    selected_refs=len(REFS),
    selected_unique_bytes=sum(r["bytes"] for r in REFS.values()),
    refs_before_after=REFS,
    strict_forward_inverse_hunks=n,
    whole_current_Main_post_exact=True,
    historical_before_gzip_reconstructed=True,
    protected_main_module_exact=True,
    protected_bytes_SHA256=protected,
    source_resolution=dict(
        R1="original work Err object wins; fallible terminal writes, separate save/stdout/stderr facts; own-channel return and all-channel durability UNKNOWN",
        C1="pre-persist reservations/maybe-entered and Ok-only domains explicit",
        C2="ScalarFT/context and unchanged guarded head/physical route UNKNOWN explicit",
    ),
    new_zero_head_fixture_definition_read_not_run=True,
    original_7_state_model_math_work_not_replayed=True,
    target_functions_tests_Rust_models_native_executed=0,
    start=START,
    reader_STOP=STOP,
    own_identity=dict(
        pid=os.getpid(),
        start_ticks=Path(f"/proc/{os.getpid()}/stat").read_text().rsplit(")", 1)[1].split()[19],
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    ),
    helper_wall_s=time.monotonic() - T0,
    self_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    family_continuous_peak="UNKNOWN",
    leases_acquired=[],
    owned_readers_children_jobs_handles_TMP_leases_remaining=[],
)
(OWN / "static-proof.json").write_text(json.dumps(p, indent=2) + "\n")
print(
    json.dumps(
        {
            k: p[k]
            for k in [
                "selected_refs",
                "selected_unique_bytes",
                "strict_forward_inverse_hunks",
                "reader_STOP",
                "own_identity",
                "helper_wall_s",
                "self_ru_maxrss_KiB",
            ]
        }
    )
)
