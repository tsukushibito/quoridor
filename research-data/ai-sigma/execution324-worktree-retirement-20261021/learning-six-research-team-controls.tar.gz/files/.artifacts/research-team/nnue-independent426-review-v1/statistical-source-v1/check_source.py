"""426 statistical-body AST/ref inspection only; never import/run target/NumPy."""

import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/design-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
START = datetime.datetime.now(datetime.timezone.utc).isoformat()
T0 = time.monotonic()
REFS = {}


def read(ref):
    p = Path(ref["path"])
    i = p.lstat()
    assert not p.is_symlink() and i.st_size == ref["bytes"] <= 131072
    with p.open("rb") as f:
        b = f.read(ref["bytes"] + 1)
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{i.st_mode & 4095:04o}",
    )
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    REFS[str(p)] = actual
    return b


completion_ref = dict(
    path=str(BASE / "completion.json"),
    sha256="04d9ec2b04b233b645e7de429ba168671b5f3a25206492cd8bbc94048d0c0640",
    bytes=3785,
    mode="0644",
)
completion = json.loads(read(completion_ref))
refs = {Path(r["path"]).name: r for r in completion["fixed_artifacts"]}
body_ref = refs["family_bootstrap426.py"]
assert (
    body_ref["sha256"] == "87ec6094b26f9e79c5c80f7d4c9129c753c872ce375dba029af359d888b1eb8c"
    and body_ref["bytes"] == 4093
)
source = read(body_ref)
tree = ast.parse(source)
settings = json.loads(read(refs["resolved-settings.json"]))
read(completion["contract"])
for name in ["report-ja.md", "control.json", "checks.json", "static-checks.json"]:
    read(refs[name])
constants = {
    n.targets[0].id: ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign)
}
assert constants == dict(SEED=42620261016, RESAMPLES=10000, PLANNED_FAMILIES=192)
functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
assert set(functions) == {"interval_from_complete_family_scores", "file_ref", "main"}
interval = functions["interval_from_complete_family_scores"]
main = functions["main"]
text = ast.unparse(interval)
maintext = ast.unparse(main)
assert "np.asarray(scores, dtype=np.float64)" in text
assert "type(score) not in (int, float)" in text
assert "values.ndim != 1 or len(values) > PLANNED_FAMILIES" in text
assert "np.isfinite(values)" in text and "np.isin(values, [0.0, 0.25, 0.5, 0.75, 1.0])" in text
assert "np.random.Generator(np.random.PCG64(SEED))" in text
assert "rng.choice(values, size=(RESAMPLES, len(values)), replace=True)" in text
assert "sampled.mean(axis=1, dtype=np.float64)" in text
assert "np.quantile(means, [0.025, 0.975], method='linear')" in text
assert "if len(values) == 0:\n        return None" in text
assert "type(i) is not int or not 0 <= i < PLANNED_FAMILIES" in maintext
assert "ids != sorted(set(ids))" in maintext
assert (
    "type(complete) is not bool or (complete and ids != list(range(PLANNED_FAMILIES)))" in maintext
)
assert (
    "'MET' if interval[0] > 0.5 else 'NOT_MET'" in maintext
    and "if complete else 'NOT_APPLICABLE_INCOMPLETE'" in maintext
)
calls = [ast.unparse(n.func) for n in ast.walk(main) if isinstance(n, ast.Call)]
assert calls.count("interval_from_complete_family_scores") == 1
assert "'partial_scope': 'complete-pair conditional; planned bounds are separate'" in maintext
assert (
    "file_ref(input_path, input_bytes)" in maintext
    and "file_ref(source_path, source_bytes)" in maintext
)
assert (
    "'interpreter': sys.executable" in maintext
    and "'python_version': platform.python_version()" in maintext
    and "'numpy_version': np.__version__" in maintext
)
stats = settings["statistics"]
assert (
    stats["bootstrap_seed"] == constants["SEED"]
    and stats["bootstrap_resamples"] == constants["RESAMPLES"]
    and stats["old423_CI_pooling"] is False
    and stats["bootstrap_now"] is False
)
assert settings["A"]["canonical_target_families"] == 192 and settings["A"]["games"] == 384
lines = source.decode().splitlines()


def line_of(needle):
    return next(i + 1 for i, l in enumerate(lines) if needle in l)


assert line_of("input_bytes = input_path.read_bytes()") < line_of("if len(input_bytes) > 131072:")
assert line_of("if output_path.exists():") < line_of("output_path.write_text(")
assert not any(
    isinstance(n, ast.Call) and ast.unparse(n.func) in ["compile", "exec", "eval"]
    for n in ast.walk(tree)
)
for ref in list(REFS.values()):
    read(ref)
STOP = datetime.datetime.now(datetime.timezone.utc).isoformat()
p = dict(
    target=body_ref,
    completion=completion_ref,
    settings=refs["resolved-settings.json"],
    selected_refs=len(REFS),
    selected_unique_bytes=sum(r["bytes"] for r in REFS.values()),
    refs_before_after=REFS,
    statistical_body_AST_read_only=True,
    target_imports_functions_tests_or_NumPy_executed=False,
    bootstrap_resamples_executed_by_reviewer=0,
    source_method=dict(
        constants=constants,
        unit="prevalidated true global complete two-colour family score",
        quarter_grid_with_draws=True,
        ordered_unique_global_ids=True,
        dtype="float64",
        rng="Generator(PCG64)",
        choice="replace=True, shape10000 x number_complete_families",
        mean_axis=1,
        quantile="[.025,.975], method linear",
        empty_returns_None_and_zero_resamples=True,
        criterion="all384 flag + exactly IDs0..191; lower>.5; incomplete NOT_APPLICABLE",
        partial="complete-pair conditional only; observed-game/planned bounds external saved census",
        old423_pooling=False,
    ),
    ordinary_IO_evidence=dict(
        input_read_line=line_of("input_bytes = input_path.read_bytes()"),
        cap_after_read_line=line_of("if len(input_bytes) > 131072:"),
        output_precheck_line=line_of("if output_path.exists():"),
        nonexclusive_write_line=line_of("output_path.write_text("),
    ),
    future_provenance_scope="normal caller binds actual426 canonical family/colour/history/plan joins, source/input/interpreter/NumPy/seed/output and full lifetime; no source-only numerical admission",
    start=START,
    reader_STOP=STOP,
    own_identity=dict(
        pid=os.getpid(),
        start_ticks=Path(f"/proc/{os.getpid()}/stat").read_text().rsplit(")", 1)[1].split()[19],
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    ),
    helper_wall_s=time.monotonic() - T0,
    self_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    family_continuous_peak="UNKNOWN",
    owned_readers_children_jobs_handles_TMP_leases_remaining=[],
    leases_acquired=[],
)
(OWN / "static-proof.json").write_text(json.dumps(p, indent=2) + "\n")
print(
    json.dumps(
        {
            k: p[k]
            for k in [
                "selected_refs",
                "selected_unique_bytes",
                "reader_STOP",
                "own_identity",
                "ordinary_IO_evidence",
                "helper_wall_s",
                "self_ru_maxrss_KiB",
            ]
        }
    )
)
