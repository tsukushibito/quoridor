"""One finite source-check child under the maintained process/resource owner."""

import json
import os
from pathlib import Path
import sys
import time
from datetime import datetime, timezone

sys.path.insert(0, "/workspaces/quoridor/python")
from quoridor_training import cycle_process as process

OUT = Path(__file__).parent
physical = {}
for cpu in [16, 18]:
    path = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
    physical[cpu] = [int((path / name).read_text()) for name in ["physical_package_id", "core_id"]]
assert physical[16] != physical[18] and set(os.sched_getaffinity(0)) == {18}
deadline = time.monotonic() + 60
resources = process.CycleResources(
    {"max_memory_bytes": 1073741824, "host_ram_reserve": 4294967296}, OUT, deadline
)
resources.check()
ancestors = {os.getpid()}
parent = os.getppid()
while parent > 1:
    ancestors.add(parent)
    info = process.process_info(parent)
    if info is None:
        break
    parent = info["parent"]
pinned = []
for path in Path("/proc").iterdir():
    if not path.name.isdecimal() or int(path.name) in ancestors:
        continue
    try:
        affinity = set(os.sched_getaffinity(int(path.name)))
    except ProcessLookupError:
        continue
    if affinity and affinity <= {16, 17, 18, 19}:
        info = process.process_info(int(path.name))
        if info:
            pinned.append({"identity": process.identity(info), "affinity": sorted(affinity)})
assert not pinned, pinned
entry = {
    "at": datetime.now(timezone.utc).isoformat(),
    "physical": physical,
    "guardian_cpu": 18,
    "worker_cpu": 16,
    "family_limit_bytes": 1073741824,
    "host_reserve_bytes": 4294967296,
    "MemAvailable_bytes": process.available_memory(),
    "pinned_peers_on_selected_physical_cores": pinned,
    "B_generation": "user reports active worker2/guardian6; allowed untimed coexistence; no global quiet claim",
    "GPU": 0,
    "lease_acquired": False,
}
(OUT / "entry.json").write_text(json.dumps(entry, indent=2) + "\n")
record = process.execute(
    [sys.executable, "-B", str(OUT / "check_source.py")],
    OUT / "static-check.capture.log",
    deadline,
    cpu_core=16,
    resources=resources,
    cwd="/workspaces/quoridor",
)
resources.check()
returned = {
    "returned": record,
    "guardian_identity": process.identity(process.process_info(os.getpid())),
    "fresh_child_absent": not process.alive(record["child"]),
    "STOP": datetime.now(timezone.utc).isoformat(),
    "owned_readers_children_jobs_handles_TMP_leases_remaining": [],
    "continuous_family_peak": "UNKNOWN; CycleResources periodic checks only",
}
(OUT / "static-check.returned.json").write_text(json.dumps(returned, indent=2) + "\n")
print(json.dumps(returned))
