429.4の限定training-view sourceはclear。blocker 0 / ordinary 0。対象はresult-binding b31c407d、source-binding 03c89b2d、source.patch 3d9596f3である。実cache/view/fit/evaluationの参照は未作成であり、この確認は数値READYや新しいfit/eval/arenaの許可を与えない。

optional mixture.training_viewは既存設定resolverの許可field/default Noneへ加わる。FileRefは正確な4項目、plain intの正byte数、lowercase64hex SHA、mode0600/0644を要求する。このroleだけ上限4MiB、既存public membership/acceptanceは1MiBのまま。absolute pathとregular non-symlink/size/mode/raw SHAは既存bound_file_bytes側で検査する。config段階のpath非空だけを絶対path保証と読み替えない。

新JSONは正確にcache_manifest_sha256とindicesを要求し、cache identityを実TerminalCorpus.manifest_shaに一致させる。通常cache.jsonの内容SHAとの対応であり、別cacheや同名directoryを受け入れるものではない。indicesは非空list、全要素type(i) is intでBooleanも拒否、sorted(set(indices))と完全一致する昇順・重複なし、かつ既存candidates集合の部分集合でなければ拒否する。string/float/nested-list/null、負値、capで落ちたT、Vや他の範囲外行は正規候補集合に入れない。JSON構文自体の不正もjson.loadsで失敗する。

候補は変更前と同じfamily_training_view(eligible/split/family cap又は既存game-stock strata)の結果を先に作り、その後だけで絞る。新しいsplitやfamily classifierを作らず、既存policyが除いた行を戻さない。Vは元のnp.flatnonzero(added.eligible & (added.splits == 1))をbyte-exactに保持し、T subsetでVを削らない。Noneは元candidateを返し、その後のint64 array化で同じindices/orderを保つ。出力provenanceには選択済みindices/cache SHAに加え、viewがある場合だけそのFileRefを保存する。

既存readerはlstatでrole/size/mode/regularを検査し、read_bytesのSHAを照合する通常FileRef readerである。開いたFDへのhard read capや敵対的filesystem race耐性を新たに保証したとは呼ばない。固定所有の入力を通常のordered Experiment.inputsへ入れ、実行前後・全lifetimeのcustodyを既存のRUNで守る必要がある。本patchだけではその未来の入力登録や変更監視は成立しない。作者のhelper読取や保存前後だけを将来のRUN資格にしない。

保持されたminimum-before gzipと5 owner before/after SHAを独立に照合し、2 synthetic fileの5ハンクを完全context/ゼロoffsetで正逆適用した。省略区間は明示的なsynthetic commentであり、current Main全体との一致は主張しない。formatted helper/validatorのAST対応、optional fieldを除去した既存default AST、元T抽出とV式のbyte一致を確認した。既存cache/model/scale/421/F/INITIAL/loss/optimizer/finalizersはこの差分の変更対象に加えられておらず、既存受理scopeを再用する。Rootによる実current owner preimage照合と疎合成は別の必要作業である。

作者の4新NN0定義・原PASS capture・returned directwait/cleanupを読んだ。テストが読んだhelperとfrozen fragmentのAST対応を確認したが、対象function/test/portは一切実行していない。元のsynthetic NN0は本番cache/NumPy/Torch/model/実行lifetimeの資格ではない。追加のtarget software checkを必要とする未解決分岐はなかった。

17 selected refsのSHA/size/mode前後一致。実source reader STOP 2026-10-17T00:52:59.176553+00:00。CPU16 worker PID501040/start24673778、guardian18 PID501039/start24673776、boot6c2e177d-29e9-4a05-ad60-026060b53fb9。existing CycleResources/process.executeはfamily1GiB/hostreserve4GiB/GPU0、distinct physical cores8/9、entry available17301106688B、選択coreに他pinned processなしで有限helperを実行した。Bのworker2/guardian6でのuntimed generationとcoexistする範囲であり、global fairquietや将来quietは主張しない。

helper exit0、direct child reap/process cleanup/handle close/signal-mask restorationはreturned recordで成功。262B capture、wall .03143210499547422s、helper self ru_maxrss17088KiB。guard cleanup STOP 2026-10-17T00:52:59.188335+00:00、元child/guardian fresh absent、owned readers/children/jobs/handles/TMP/leases/remaining[]。canonical/Main lifetime leaseは取得していない。CycleResourcesはperiodic checkでありcontinuous family peak/full feeはUNKNOWN。author旧FAILED/UNKNOWN/RAW/費用、342.17/323USERPAUSE/defaults/models/sealsは変更しない。
