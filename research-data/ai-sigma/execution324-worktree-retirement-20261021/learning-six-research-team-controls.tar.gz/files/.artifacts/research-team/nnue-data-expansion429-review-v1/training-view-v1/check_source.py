"""Strict private-fragment reconstruction and AST checks; no target execution."""

import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import stat
from datetime import datetime, timezone

resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
BASE = Path(
    "/workspaces/quoridor/.worktree/learning-million/.artifacts/research-team/nnue-data-expansion429-learning-v1"
)
OUT = Path(__file__).parent
REFS = {}


def read(ref):
    path = Path(ref["path"])
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_size == ref["bytes"] < 262144
    assert format(stat.S_IMODE(info.st_mode), "04o") == ref["mode"]
    with path.open("rb") as stream:
        body = stream.read(ref["bytes"] + 1)
    assert len(body) == ref["bytes"] and hashlib.sha256(body).hexdigest() == ref["sha256"]
    REFS[str(path)] = ref
    return body


def captured(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_size < 262144
    body = path.read_bytes()
    return read(
        {
            "path": str(path),
            "bytes": len(body),
            "mode": format(stat.S_IMODE(info.st_mode), "04o"),
            "sha256": hashlib.sha256(body).hexdigest(),
        }
    )


def function(source, name):
    tree = ast.parse(source)
    return next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)


result_ref = {
    "path": str(BASE / "result-binding.json"),
    "sha256": "b31c407d35907183b219935491412acec8848ad36b8ef7da54d3f77c1f7ba09f",
    "bytes": (BASE / "result-binding.json").stat().st_size,
    "mode": "0644",
}
result = json.loads(read(result_ref))
binding = json.loads(read(result["source_binding"]))
refs = {
    Path(r["path"]).name: r for r in binding["artifacts"] + binding["existing_command_receipts"]
}
names = [
    "source.patch",
    "source-proof.json",
    "owner-chunks.json",
    "final-minimum-before.json.gz",
    "training_view_indices.py",
    "common-prefix.after.py",
    "validate_mixture_config.after.py",
    "test_training_view_nn0.py",
    "NN0-format-AST-correspondence.json",
    "final-static-correspondence.json",
    "subset-NN0-v1.returned.json",
    "final-current-owner-intake-v3.returned.json",
]
raw = {name: read(refs[name]) for name in names}
read(result["STOP"])
chunks = json.loads(raw["owner-chunks.json"])
minimum = json.loads(gzip.decompress(raw["final-minimum-before.json.gz"]))
supplier = json.loads(raw["source-proof.json"])
assert len(chunks) == len(minimum) == len(supplier["hunks"]) == 5
before, expected = {}, {}
for chunk, prior, proof in zip(chunks, minimum, supplier["hunks"]):
    assert chunk["path"] == prior["path"] == proof["path"]
    assert chunk["before"] == prior["before"] and prior["original_line"] == proof["original_line"]
    for key in ["before", "after"]:
        assert hashlib.sha256(chunk[key].encode()).hexdigest() == proof[key + "_sha"]
    lines = before.setdefault(chunk["path"], [])
    gap = prior["original_line"] - 1 - len(lines)
    assert gap >= 0
    lines.extend(["# omitted\n"] * gap)
    lines.extend(chunk["before"].splitlines(keepends=True))
before = {path: "".join(lines) for path, lines in before.items()}
for path, source in before.items():
    for chunk in chunks:
        if chunk["path"] == path:
            assert source.count(chunk["before"]) == 1
            source = source.replace(chunk["before"], chunk["after"], 1)
    expected[path] = source


def apply(source, patch, reverse=False):
    lines = source.splitlines(keepends=True)
    result, position, index, count = [], 0, 0, 0
    while index < len(patch):
        match = re.fullmatch(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n", patch[index])
        assert match
        a, ac, b, bc = [int(x) if x is not None else 1 for x in match.groups()]
        index += 1
        body = []
        while index < len(patch) and not patch[index].startswith("@@ "):
            body.append(patch[index])
            index += 1
        assert sum(x[0] in " -" for x in body) == ac and sum(x[0] in " +" for x in body) == bc
        at = (b if reverse else a) - 1
        assert at >= position
        result.extend(lines[position:at])
        position = at
        for row in body:
            sign, value = row[0], row[1:]
            if sign == " " or sign == ("+" if reverse else "-"):
                assert lines[position] == value
                position += 1
            if sign == " " or sign == ("-" if reverse else "+"):
                result.append(value)
        count += 1
    result.extend(lines[position:])
    return "".join(result), count


parts = {}
for section in raw["source.patch"].decode().split("--- a/")[1:]:
    lines = section.splitlines(keepends=True)
    parts[lines[0].strip()] = lines[2:]
hunk_count = 0
for path, patch in parts.items():
    post, count = apply(before[path], patch)
    assert post == expected[path]
    assert apply(post, patch, True)[0] == before[path]
    hunk_count += count

helper = function(chunks[2]["after"], "training_view_indices")
assert ast.dump(helper) == ast.dump(function(raw["training_view_indices.py"], helper.name))
assert ast.dump(function(chunks[1]["after"], "validate_mixture_config")) == ast.dump(
    function(raw["validate_mixture_config.after.py"], "validate_mixture_config")
)
assert ast.dump(ast.parse(chunks[0]["after"])) == ast.dump(ast.parse(raw["common-prefix.after.py"]))
# The unchanged no-view defaults, extraction, V expression and saved provenance.
old_prefix = ast.parse(chunks[0]["before"])
new_prefix = ast.parse(chunks[0]["after"])
for node in new_prefix.body:
    if isinstance(node, ast.Assign) and any(
        isinstance(t, ast.Name) and t.id == "MIXTURE_OPTIONS" for t in node.targets
    ):
        node.value.elts = [
            x
            for x in node.value.elts
            if not isinstance(x, ast.Constant) or x.value != "training_view"
        ]
    if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
        node.value.keywords = [k for k in node.value.keywords if k.arg != "training_view"]
assert ast.dump(old_prefix) == ast.dump(new_prefix)
addition = '            train_rows = np.asarray(\n                training_view_indices(m.get("training_view"), added.manifest_sha, train_rows),\n                dtype=np.int64,\n            )\n'
assert chunks[3]["after"].replace(addition, "", 1) == chunks[3]["before"]
assert (
    chunks[3]["after"].count(
        "validation_rows = np.flatnonzero(added.eligible & (added.splits == 1))"
    )
    == 1
)
tests = ast.parse(raw["test_training_view_nn0.py"])
test_names = [
    n.name for n in ast.walk(tests) if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")
]
assert len(test_names) == 4
receipt = json.loads(raw["subset-NN0-v1.returned.json"])
assert (
    receipt["returned"]["exit_code"] == 0
    and receipt["returned"]["direct_child_reaped"]
    and receipt["returned"]["cleanup_complete"]
)
capture = captured(BASE / "subset-NN0-v1.capture.log")
assert (
    len(capture) == receipt["returned"]["log_bytes_retained"]
    and b"Ran 4 tests" in capture
    and b"OK" in capture
)
owner_capture = captured(BASE / "final-current-owner-intake-v3.capture.log").decode()
reader = owner_capture.split("COMMON_BOUND_READER\n", 1)[1].split("def warmstart_model_inputs(", 1)[
    0
]
function(reader, "bound_file_bytes")
assert not any(
    isinstance(n, ast.Import) and any(a.name in ["numpy", "torch"] for a in n.names)
    for n in tests.body
)
# No target function/test is called. No whole Main composition is asserted.
for ref in list(REFS.values()):
    read(ref)
stop = datetime.now(timezone.utc).isoformat()
proof = {
    "result_target": result_ref,
    "source_target": result["source_binding"],
    "selected_refs_before_after": list(REFS.values()),
    "strict_synthetic_files": len(parts),
    "strict_synthetic_hunks": hunk_count,
    "strict_forward_inverse": True,
    "whole_Main_postimage_claim": False,
    "five_owner_chunks_and_before_gzip": "MATCH",
    "formatted_helper_validator_AST": "MATCH",
    "no_view_existing_default_AST": "MATCH",
    "original_candidate_extraction_and_V_bytes": "MATCH",
    "author_four_NN0_saved_PASS": test_names,
    "reviewer_target_tests_or_functions_executed": 0,
    "selected_reader_STOP": stop,
    "worker_identity": {
        "pid": os.getpid(),
        "start_ticks": Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()[19],
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    },
    "self_ru_maxrss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "owned_remaining": [],
    "lease_acquired": False,
}
(OUT / "static-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            k: proof[k]
            for k in [
                "selected_reader_STOP",
                "worker_identity",
                "strict_synthetic_files",
                "strict_synthetic_hunks",
                "self_ru_maxrss_kib",
            ]
        }
    )
)
