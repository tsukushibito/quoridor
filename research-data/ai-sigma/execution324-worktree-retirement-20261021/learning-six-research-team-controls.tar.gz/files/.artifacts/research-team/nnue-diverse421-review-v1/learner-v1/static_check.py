"""Fixed learner source, strict patch/AST and scalar bounds; no target execution."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = OWN.parent.with_name("nnue-diverse421-learning-v1")
resource.setrlimit(resource.RLIMIT_AS, (805306368, 805306368))
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
refs = {}
start = time.monotonic()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink(), p
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    if str(p) in refs:
        assert refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


entry = now()
binding = json.loads(
    read(
        dict(
            path=str(BASE / "result-binding.json"),
            sha256="9f14cd69ac25fb43d4a65743e97e659dcc0601de8aa539c6c3f0a05f334176e0",
            bytes=14109,
            mode="0644",
        )
    )
)
contents = {name: read(ref) for name, ref in binding["files"].items()}
settings = json.loads(contents["settings.SELECTED.json"])
spec = json.loads(read(settings["fixed_spec"]))
read(settings["contract"])
source_proof = json.loads(contents["source-proof.json"])
read(source_proof["original_production_forward_inverse"])
new_test_patch = read(source_proof["new_test_forward_inverse"])
# Only reuse reviewer-owned parser functions, never target helpers/tests.
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
assert len(nodes) == 2
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
parts = scope["split_patch"](contents["source.patch"])
patch_checks = []
outside = []
for name, row in binding["production_targets"].items():
    old = gzip.decompress(contents[name + ".before.gz"])
    assert hashlib.sha256(old).hexdigest() == row["before"]["sha256"]
    assert len(old) == row["before"]["bytes"]
    post = contents[name]
    patch = parts.pop("python/quoridor_training/" + name)
    f, n = scope["apply"](old, patch)
    b, m = scope["apply"](post, patch, True)
    assert f == post and b == old and n == m
    patch_checks.append({"name": name, "hunks": n, "forward_inverse_exact": True})
    owners = set(source_proof[name]["owners"])

    def kept(raw):
        result = []
        for node in ast.parse(raw).body:
            names = {node.name} if isinstance(node, (ast.FunctionDef, ast.ClassDef)) else set()
            if isinstance(node, ast.Assign):
                names |= {n.id for n in node.targets if isinstance(n, ast.Name)}
            if names & owners:
                continue
            if isinstance(node, ast.ClassDef) and "settings" in owners:
                for method in node.body:
                    if isinstance(method, ast.FunctionDef) and method.name == "settings":
                        node.body.remove(method)
                        break
                result.append((ast.dump(node, include_attributes=False), None))
            else:
                result.append(
                    (
                        ast.dump(node, include_attributes=False),
                        ast.get_source_segment(raw.decode(), node),
                    )
                )
        return result

    assert kept(old) == kept(post), name
    outside.append({"name": name, "unowned_AST_and_statement_bytes_exact": True})
new_name = "python/quoridor_training/test_diverse_outcome.py"
new_post = contents["test_diverse_outcome.py"]
aggregate_new_patch = parts.pop(new_name)
assert not parts
f, n = scope["apply"](b"", aggregate_new_patch)
b, m = scope["apply"](new_post, aggregate_new_patch, True)
assert f == new_post and b == b"" and n == m
final_parts = scope["split_patch"](new_test_patch)
assert list(final_parts) == [new_name]
assert scope["apply"](b"", final_parts[new_name])[0] == new_post
patch_checks.append(
    {
        "name": "test_diverse_outcome.py",
        "hunks": n,
        "forward_inverse_exact": True,
        "before_absent": True,
    }
)
# Independent scalar arithmetic from the selected design, not a target function.
scalar = []
for r in (1, 32, 1632, 2048):
    u = min(64, (4 * r + 127) // 128)
    points = sorted({0, *((k * u + 3) // 4 for k in range(1, 5))})
    assert 4 * r <= 128 * u < 4 * r + 128
    scalar.append(
        dict(R=r, U=u, points=points, added_draws=128 * u, mean_added_exposure=128 * u / r)
    )
scope_rows = 419150 + 12800 + 8192 + 2048
forward_upper = 2 * 64 * 256 + 9 * scope_rows + 1024
assert forward_upper == binding["design_forward_upper_including_changed_weights_1024"] == 4013502
assert forward_upper < binding["whole_forward_cap"] == 6000000
assert (1 / 1 + 0 / 2) / 2 == 0.5 and 1 / 3 != 0.5
assert (
    settings["M"]["mixture"]["added_sampling_seed"]
    == spec["seeds"]["added_shuffled_cycling"]
    == 42120261020
)
assert (
    settings["C"]["training"]["seed"]
    == settings["M"]["training"]["seed"]
    == spec["seeds"]["training_both_arms"]
)
for arm in ("C", "M"):
    cfg = settings[arm]
    assert cfg["training"]["steps"] is None and cfg["training"]["warmup_steps"] is None
    assert cfg["training"]["batch_size"] == 256 and cfg["training"]["threads"] == 2
    assert cfg["optimizer"]["lr"] == 1e-4 and cfg["optimizer"]["weight_decay"] == 0
    assert cfg["evaluation"]["early_stopping_patience"] == 0
    assert cfg["mixture"]["selector"] == {
        "public_non_regression": False,
        "added_metric": "family_mse",
    }
    assert cfg["mixture"]["train_stock_strata"] == spec["T_view"]["train_stock_strata"]
    assert (
        cfg["mixture"]["public_sampling_seed"] == spec["seeds"]["public_uniform_stream_both_arms"]
    )
    assert cfg["mixture"]["diagnostic_seed"] == spec["seeds"]["public_T8192_panel"]
assert settings["C"]["experiment"]["warm_start"] == settings["M"]["experiment"]["warm_start"]
assert (settings["C"]["mixture"]["added_rows"], settings["C"]["mixture"]["public_rows"]) == (0, 256)
assert (settings["M"]["mixture"]["added_rows"], settings["M"]["mixture"]["public_rows"]) == (
    128,
    128,
)
assert (
    settings["actual_cache"] is None
    and settings["actual_newT_R"] is None
    and settings["actual_U"] is None
)
receipts = []
for ref in binding["receipts"]:
    rows = json.loads(read(ref))
    for row in rows:
        if row["name"].startswith("NN0"):
            g = row.get("guardian_return")
            receipts.append(
                {
                    "name": row["name"],
                    "ref": ref,
                    "returned": g is not None,
                    "exit_code": g.get("exit_code") if g else None,
                    "direct_child_reaped": g.get("direct_child_reaped") if g else None,
                    "cleanup_complete": g.get("cleanup_complete") if g else None,
                    "error": row.get("error"),
                }
            )
stop = json.loads(contents["STOP.json"])
known = []
for row in stop["original_children_fresh_absent_or_different"]:
    old = row["original"]
    proc = Path("/proc") / str(old["pid"])
    known.append({"original": old, "fresh_pid_absent": not proc.exists()})
assert len(known) == 45 and all(r["fresh_pid_absent"] for r in known)
before = list(refs.values())
for ref in before:
    read(ref)
reader_stop = now()
result = dict(
    target=refs[str(BASE / "result-binding.json")],
    actual_reader_STOP=reader_stop,
    entry=entry,
    before=before,
    after=list(refs.values()),
    all_refs_before_after_exact=True,
    strict_patch_checks=patch_checks,
    unowned_production=outside,
    scalar_checks=scalar,
    planned_forward_upper_including_changed_weights_1024=forward_upper,
    new_NN0_receipts=receipts,
    producer_known_identity_fresh=known,
    target_functions_tests_framework_model_native_Search_executed=0,
    source_Main_Git_index_writes=0,
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    canonical_lease_acquired=False,
    directwait="Finite stdlib helper returned; plain-tool process identity/handle receipt UNKNOWN",
    static_elapsed_seconds=time.monotonic() - start,
    self_VmHWM=next(
        line
        for line in Path("/proc/self/status").read_text().splitlines()
        if line.startswith("VmHWM:")
    ),
    reported_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    continuous_family_peak="UNKNOWN",
    future_quiet_or_reservation=False,
)
(OWN / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            k: result[k]
            for k in [
                "actual_reader_STOP",
                "all_refs_before_after_exact",
                "strict_patch_checks",
                "scalar_checks",
                "static_elapsed_seconds",
                "self_VmHWM",
            ]
        }
    )
)
