"""Stopped generation/input patch and lexical contracts; no Rust/target execution."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-diverse421-data-v1/generation-source-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (805306368, 805306368))
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
refs = {}
start = time.monotonic()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink(), p
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    if str(p) in refs:
        assert refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def lexical_body(raw, token):
    at = raw.index(token.encode())
    line = raw.rfind(b"\n", 0, at) + 1
    indent = raw[line:at]
    assert not indent.strip()
    end = raw.index(b"\n" + indent + b"}", at) + len(indent) + 2
    return raw[at:end]


entry = now()
completion = json.loads(
    read(
        dict(
            path=str(BASE / "completion.json"),
            sha256="7ad25c6ec914df733e055c71fc7db55e2499958354a6f74661aaa5e5bb766259",
            bytes=3371,
            mode="0644",
        )
    )
)
raws = {
    key: read(value)
    for key, value in completion.items()
    if isinstance(value, dict) and "path" in value
}
for ref in completion["drafts"]:
    read(ref)
binding = json.loads(raws["source_binding"])
for ref in binding["spec_refs"]:
    read(ref)
addendum = json.loads(read(binding["addendum"]))
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
assert len(nodes) == 2
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
forward = scope["split_patch"](raws["forward"])
inverse = scope["split_patch"](raws["inverse"])
before, after = {}, {}
checks = []
for row in binding["subjects"]:
    name = row["subject"]
    old = gzip.decompress(read(row["recovery"]))
    assert (
        len(old) == row["before"]["bytes"]
        and hashlib.sha256(old).hexdigest() == row["before"]["sha256"]
    )
    post = read(row["post"])
    f, n = scope["apply"](old, forward.pop(name))
    b, m = scope["apply"](post, inverse.pop(name))
    assert f == post and b == old and n == m
    before[name], after[name] = old, post
    checks.append({"subject": name, "hunks": n, "strict_forward_inverse": True})
assert not forward and not inverse
protected = []
static = json.loads(raws["static_proof"])
for row in static["protected"]:
    old = lexical_body(before[row["subject"]], row["body"])
    post = lexical_body(after[row["subject"]], row["body"])
    assert old == post
    protected.append(
        {
            "subject": row["subject"],
            "body": row["body"],
            "lexical_SHA256": hashlib.sha256(post).hexdigest(),
            "byte_exact": True,
        }
    )
ai = "crates/quoridor-ai/src/alphabeta.rs"
assert b"Ok(Self::requested_bytes(n)?.max(1024 * 1024))" in after[ai]
assert lexical_body(before[ai], "fn requested_bytes(") == lexical_body(
    after[ai], "fn requested_bytes("
)
assert lexical_body(before[ai], "pub fn tt_capacity(") == lexical_body(
    after[ai], "pub fn tt_capacity("
)
defs = json.loads(raws["verification"])["new_definitions"]
assert len(defs) == 6
for row in defs:
    assert b"fn " + row["name"].encode() + b"(" in after[row["subject"]]
drafts = {Path(ref["path"]).name: json.loads(read(ref)) for ref in completion["drafts"]}
gen = drafts["generation-settings.draft.json"]
assert gen["max_nodes"] == addendum["generation_max_nodes_per_move"] == 4000000
assert gen["max_total_nodes"] == addendum["unchanged_global_cap"] == 1000000000
assert gen["tt_slots"] == 1048576 and gen["lmr"] is True and gen["lmr_method"] == "depth_rank"
assert gen["depth"] == 6 and gen["max_total_plies"] == 200 and gen["per_move_timeout_ms"] is None
assert gen["ready"] is False and gen["image"] is None and gen["schedule"] is None
g = drafts["generation-input.draft.json"]
e = drafts["evaluation-input.draft.json"]
assert g["families"] == 64 and e["config"]["families"] == 16
assert g["split_seed"] == e["config"]["split_seed"] == addendum["split_seed"] == 42120261023
assert e["ready"] is False and e["config"]["unique_families"] is True
assert e["resolve_excluded_books"]["generation_prefix_book"] is None
assert e["config"]["excluded_books"] is None
# Composition metadata only. No Main/source/platform qualification inferred.
composition_path = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-diverse421-v1/composition-v1/result.json"
)
composition = json.loads(
    read(
        dict(
            path=str(composition_path),
            sha256="7722163a9fe7d8e271f0c33fedafd1111bafa529778cbf5276e041dc32575f6c",
            bytes=3574,
            mode="0644",
        )
    )
)
assert composition["commit"] == "6c9c73cc7730ab78da708834a0dfbd96fbb4d4a0"
for row in binding["subjects"]:
    ref = next(
        r for r in composition["subjects"] if r["path"] == "/workspaces/quoridor/" + row["subject"]
    )
    assert all(ref[k] == row["post"][k] for k in ["sha256", "bytes", "mode"])
stop = json.loads(raws["STOP"])
known = {}
for row in stop["receipts"]:
    for old in [row["controller"], *row.get("children", [])]:
        key = (old["pid"], old["start_ticks"], old["boot_id"])
        known[key] = {
            "original": old,
            "fresh_pid_absent": not (Path("/proc") / str(old["pid"])).exists(),
        }
assert all(row["fresh_pid_absent"] for row in known.values())
selected = list(refs.values())
for ref in selected:
    read(ref)
reader_stop = now()
result = dict(
    target=refs[str(BASE / "completion.json")],
    source_binding=completion["source_binding"],
    entry=entry,
    actual_reader_STOP=reader_stop,
    before=selected,
    after=list(refs.values()),
    all_refs_SHA_size_mode_before_after_exact=True,
    patch_checks=checks,
    protected_lexical_bodies=protected,
    Table_checked_arithmetic_and_live_getter_unchanged=True,
    Root_composition_metadata_matches_6_posts=True,
    current_Main_payload_not_rechecked=True,
    six_Rust_definitions="UNBUILT/UNTYPED/UNRUN at author; no reviewer execution or Root-software claim",
    producer_known_identity_fresh=list(known.values()),
    target_functions_tests_Rust_native_model_Search_geometry_executed=0,
    old_book_model_library_RAW_payload_reads=0,
    source_Main_Git_index_writes=0,
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    canonical_lease_acquired=False,
    directwait="Finite stdlib helper returned; no owned subprocess. Plain-tool detailed process/handle receipt UNKNOWN",
    static_elapsed_seconds=time.monotonic() - start,
    self_VmHWM=next(
        line
        for line in Path("/proc/self/status").read_text().splitlines()
        if line.startswith("VmHWM:")
    ),
    reported_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    continuous_family_peak="UNKNOWN",
    future_quiet_or_reservation=False,
)
(OWN / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            k: result[k]
            for k in [
                "actual_reader_STOP",
                "all_refs_SHA_size_mode_before_after_exact",
                "patch_checks",
                "static_elapsed_seconds",
                "self_VmHWM",
            ]
        }
    )
)
print("fresh_known_source_IDs", len(known))
