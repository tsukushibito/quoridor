"""Finite receiver source/patch checks only; never execute target functions."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import time
import tomllib

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-diverse421-data-v1/receiver-repair-v1"
)
ROOT = Path("/workspaces/quoridor")
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (50, 50))
refs = {}
start = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    s = p.stat()
    actual = {
        "path": str(p),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{s.st_mode & 0o7777:04o}",
    }
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def body(raw, token):
    at = raw.index(token.encode())
    line = raw.rfind(b"\n", 0, at) + 1
    indent = raw[line:at]
    assert not indent.strip(), (token, indent)
    end = raw.index(b"\n" + indent + b"}", at) + len(indent) + 2
    return raw[at:end]


def normalized(raw):
    text = raw.decode()
    text = re.sub(r",\s*(?=[)\]])", "", text)
    return re.sub(r"\s+", "", text)


entry = now()
completion_ref = {
    "path": str(BASE / "completion.json"),
    "sha256": "e3f16e96f1ee3bb15adf69f10ab3f9f574579688033a80c39b740a8a77e7da1e",
    "bytes": 3188,
    "mode": "0644",
}
completion = json.loads(read(completion_ref))
contents = {
    k: read(v)
    for k, v in completion.items()
    if isinstance(v, dict) and {"path", "sha256", "bytes", "mode"} <= v.keys()
}
binding = json.loads(contents["source_binding"])
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
assert len(nodes) == 2
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
forward = scope["split_patch"](contents["forward"])
inverse = scope["split_patch"](contents["inverse"])
before, after, patch_checks = {}, {}, []
for row in binding["subjects"]:
    name = row["subject"]
    old = gzip.decompress(read(row["before_recovery"]))
    assert len(old) == row["before"]["bytes"]
    assert hashlib.sha256(old).hexdigest() == row["before"]["sha256"]
    post = read(row["post"])
    original = subprocess.run(
        ["git", "show", f"{binding['base_git']}:{name}"],
        cwd=ROOT,
        capture_output=True,
        check=True,
        timeout=20,
    )
    assert original.stdout == old
    reconstructed, forward_count = scope["apply"](old, forward[name])
    restored, inverse_count = scope["apply"](post, inverse[name])
    assert reconstructed == post and restored == old
    assert forward_count == inverse_count
    before[name], after[name] = old, post
    patch_checks.append({"subject": name, "hunks": forward_count, "exact": True})
assert set(forward) == set(inverse) == set(before)
data = "crates/quoridor-data/src/"
teacher = "crates/quoridor-runner/src/teacher_pilot_execution.rs"
protected = {
    data + "terminal_stream.rs": [
        "fn validate_game(",
        "fn common_depth_census(",
        "fn validate_completion_index(",
        "fn validate_game_slot(",
        "fn common_config(",
    ],
    data + "common_corpus.rs": [
        "pub fn targets(",
        "pub fn raw_completed_d6(",
        "pub fn validate_inputs(",
        "pub fn excluded_book_prefixes(",
    ],
    teacher: ["fn play_with_budget(", "fn finish_game(", "fn play_using_policy("],
}
checks = []
for name, tokens in protected.items():
    for token in tokens:
        raw = body(before[name], token)
        assert raw == body(after[name], token), token
        checks.append({"subject": name, "body": token, "sha256": hashlib.sha256(raw).hexdigest()})
old_formatter = body(before[teacher], "fn session_settings(")
new_formatter = body(after[data + "common_corpus.rs"], "pub fn fixed_d_session_settings(")
assert old_formatter[old_formatter.index(b"{") :] == new_formatter[new_formatter.index(b"{") :]
old_ns = body(before[teacher], "fn search_namespace(")
old_ns = old_ns[old_ns.index(b"{") :]
for a, b in [
    (b"EVALUATOR_ID", b"EVALUATOR"),
    (b"quoridor_data::common_corpus::VERSION", b"VERSION"),
    (b"policy.nodes", b"max_nodes"),
    (b"policy.tt_slots", b"tt_slots"),
]:
    old_ns = old_ns.replace(a, b)
new_ns = body(after[data + "common_corpus.rs"], "pub fn fixed_d_search_namespace(")
assert normalized(old_ns) == normalized(new_ns[new_ns.index(b"{") :])


def original_routing(raw):
    text = raw.decode().replace(
        "fixed_d_search_namespace(policy.nodes, policy.tt_slots)", "search_namespace(policy)"
    )
    text = re.sub(
        r"expected_fixed_d_session_settings\(\s*policy\.nodes,\s*policy\.tt_slots,\s*policy\.lmr,\s*policy\.lmr_method,?\s*\)",
        "expected_session_settings(policy)",
        text,
    )
    return text.replace("fixed_d_session_settings(", "session_settings(").encode()


for token in ["fn configured_sessions(", "fn validate_return_policy("]:
    assert normalized(body(before[teacher], token)) == normalized(
        original_routing(body(after[teacher], token))
    ), token
toml_name = "crates/quoridor-data/Cargo.toml"
old_toml = tomllib.loads(before[toml_name].decode())
new_toml = tomllib.loads(after[toml_name].decode())
assert new_toml["dependencies"].pop("quoridor-ai") == {
    "path": "../quoridor-ai",
    "features": ["research"],
}
assert old_toml == new_toml
capacity_view = json.loads(contents["canonical_capacity_source_view"])
ai = subprocess.run(
    ["git", "show", f"{capacity_view['git']}:{capacity_view['path']}"],
    cwd=ROOT,
    capture_output=True,
    check=True,
    timeout=20,
).stdout
assert hashlib.sha256(ai).hexdigest() == capacity_view["sha256"]
assert all(v.encode() in ai for v in capacity_view["selected_bodies"].values())
assert b"Table::persistent_byte_limit(capacity)" in body(ai, "pub fn requested_tt_byte_limit(")
assert b"requested_bytes(n)?.max(1024 * 1024)" in body(ai, "fn persistent_byte_limit(")
common = after[data + "common_corpus.rs"]
expected = body(common, "pub fn expected_fixed_d_session_settings(")
assert b"!(1..=1_048_576).contains(&tt_slots)" in expected
assert b"SearchSession::requested_tt_byte_limit(tt_slots)?" in expected
assert b"OrderingProfile::CheapStaticControl" in expected
assert b".namespace(fixed_d_search_namespace(max_nodes, tt_slots), method)" in expected
receiver = after[data + "terminal_stream.rs"]
validate = body(receiver, "fn validate_search(")
for token in [
    b's.counters["session"] != policy.session',
    b'number(&s.counters, "tt_retained_bytes")? > policy.tt_byte_limit',
    b's.counters["lmr_enabled"].as_bool() != Some(policy.lmr)',
    b's.counters["lmr_method_id"] != json!(policy.lmr.then_some(policy.lmr_method.id()))',
    b's.counters["zero_stock_approx_permitted"].as_bool() != Some(false)',
    b's.counters["zero_stock_safe_race_enabled"].as_bool() != Some(false)',
    b"s.parent != Context::of(c)",
    b"(policy.strict_completed_depth && s.completed_depth != policy.depth)",
]:
    assert token in validate, token
stop = json.loads(contents["source_STOP"])
identities = []


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            identity = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if identity not in identities:
                identities.append(identity)
        for x in v.values():
            find_ids(x)
    elif isinstance(v, list):
        for x in v:
            find_ids(x)


find_ids(stop)
absences = []
for v in identities:
    absent = not Path(f"/proc/{v['pid']}").exists()
    absences.append({"identity": v, "fresh_pid_absent": absent})
    assert absent, v
before_refs = list(refs.values())
for ref in before_refs:
    read(ref)
reader_stop = now()
proof = {
    "target": completion_ref,
    "binding": completion["source_binding"],
    "entry": entry,
    "actual_reader_STOP": reader_stop,
    "before": before_refs,
    "after": list(refs.values()),
    "patches": patch_checks,
    "strict_forward_inverse_gzip_Git_before": True,
    "protected_bodies": checks,
    "pure_formatter_moved_body_exact": True,
    "namespace_parameter_substitution_only": True,
    "configured_sessions_and_return_policy_equivalent_after_helper_routing": True,
    "only_Cargo_dependency": "existing workspace quoridor-ai research; lock Root-owned separately",
    "canonical_AI": {
        "git": capacity_view["git"],
        "path": capacity_view["path"],
        "sha256": capacity_view["sha256"],
        "selected_body_views_match": True,
        "pure_checked_requested_bytes_route": True,
        "native_ABI_layout_not_executed": True,
    },
    "fresh_known_identities": absences,
    "static_seconds": time.monotonic() - start,
    "self_VmHWM": next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    "family_continuous_peak": "UNKNOWN",
    "target_functions_tests_Rust_native_model_Search_RAW_executions": 0,
    "source_Main_Git_index_writes": 0,
    "owned_readers": [],
    "owned_children": [],
    "owned_jobs": [],
    "owned_handles": [],
    "owned_TMP": [],
    "owned_leases": [],
    "remaining": [],
    "canonical_lease_acquired": False,
    "directwait": "Five immutable Git reads returned synchronously/reaped; plain tool detailed identity/handle receipt UNKNOWN",
    "future_quiet_or_reservation": False,
}
(OWN / "static-proof.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        {
            "reader_STOP": reader_stop,
            "selected_refs": len(refs),
            "hunks": sum(v["hunks"] for v in patch_checks),
            "protected_bodies": len(checks),
            "fresh_absent": len(absences),
            "seconds": proof["static_seconds"],
            "self_VmHWM": proof["self_VmHWM"],
        }
    )
)
