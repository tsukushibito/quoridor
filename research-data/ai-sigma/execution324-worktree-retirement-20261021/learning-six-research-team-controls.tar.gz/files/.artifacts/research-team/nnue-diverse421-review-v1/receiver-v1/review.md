# 421.4 receiver修復の限定source確認

**source_clear=true / blockers=0 / ordinary=0**。固定completion `e3f16e96f1ee3bb15adf69f10ab3f9f574579688033a80c39b740a8a77e7da1e` / binding `df9c05daf5f9cb3eac58ad400e4ec881914466a99c0da8364c86c8292aadf56b` の4 owning pathsだけを確認しました。19 selected refsのSHA/size/modeが前後一致し、17 hunkを正逆独立patchとbefore gzipから厳密再構成、4 beforeはimmutable `67668dddf09589cd30a860e6bb5fd6d842842a65` と一致しました。

receiverは固定configの正のnodes・nominal D6・PVS=true・TT1..1048576を要求します。省略LMRはOFF、methodの省略/nullはAI既定DepthRankです。OFFでも不正なmethod名・型とLMRの非boolは拒否します。byte limitはrow自己申告ではなく、AI正本 `SearchSession::requested_tt_byte_limit` の既存checked Table算術から求めます。TT/session構築や独自ABI式は追加していません。実ABIの数値・メモリ使用は未資格で、saved83886128Bを普遍定数にはしません。

同じ純粋metadata inletがproducerとreceiverへControl/profile・evaluator・rules・nodes/slots・LMR名/id/式・selective_nominal/fullwidth_nominalを渡します。rowのsession JSON全体をconfig由来のexpected値と比較し、別途actual countersのLMR enable/id・approxOFF・safeOFF・retained<=canonical上限を検査します。自己申告の巨大capacityや整合した偽rowだけで上限を増やせません。既存header/config/requests/source/schedule/partitionの束縛は残っています。

producerのmetadata formatter本体はbyte一致、namespaceは引数置換だけです。configured_sessionsとreturn validationは共有helper呼出しへ正規化した後に一致し、従来の2色別retained sessions、Distance(0,8) Tanh、Control/PVS/LMRの意味・setter順を保持します。play/finish、receiverのvalidate_game/census/slot、targets/raw_completed_d6/input/除外bookの計12 bodyはbyte不変です。nominal completed6、上限/停止理由、history/STM/PV、outcome/split/full planned census、raw ±2 とビットを緩める差分はありません。LMR有効D6をfull-width minimax証明へ昇格しません。

Cargo変更は既存workspace AI research依存1本だけです。Main/Cargo.lockの機械的依存追記・実feature閉包・compile/Clippy/current converter softwareはRootの別工程で、ここでは未実行です。2 adapted fixturesと3 new definitionsはUNBUILT/UNTYPED/UNRUN。レビュー者は対象関数・tests・Rust/native/model/Search/geometry/Cargo/変換・RAW streamを実行/読取せず、old success suiteも再演していません。authorの5039B先頭record viewは限定saved metadataであり、64goal/2822rows/434615074nodesの独立全RAW検証ではありません。

旧converter97671426と09c98e5dのFAILED、partial compact-v1、元RAW57dac034、費・mask・UNKNOWNはそのまま保持します。この修復は未完了のfresh conversionを可能にするsource確認で、ゲーム再生成/refill・cache/fit/数値/棋力/defaultの許可ではありません。

Reader STOP **2026-10-16T00:47:16.701758+00:00**。known49 PIDは当該windowでfresh absent、owned readers/children/jobs/handles/TMP/leases/remaining=[]、canonical lease取得なし。5 immutable Git subprocessはdirect return/reap済み、plain toolの詳細identity/handlesと連続family peakはUNKNOWN。最終stdlib static helper2.538388339秒、self VmHWM19016kB、AS512MiB/CPU10。00:44:27のCPU10/core5とguardian14/core7、MemAvailable15573492kBは dated factsだけでfuture quiet/所有を主張しません。

レビュー側helperのtuple戻り値処理と名前置換順の失敗2件・診断TypeErrorを原記録として保持し、対象欠陥や旧成功の再実行へ置き換えません。最終checkerは正常終了しました。Main/source/Git/index書込0。421.4はin_progressを維持、旧pause/model/weights/seal/default/RAWFAILED費UNKNOWNを変更しません。
