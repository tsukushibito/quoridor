"""Arena cap inlet and exact relocation only; never execute target/Rust/tests."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-diverse421-data-v1"
)
ROOT = Path("/workspaces/quoridor")
resource.setrlimit(resource.RLIMIT_AS, (805306368, 805306368))
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
refs = {}
start = time.monotonic()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink(), p
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    if str(p) in refs:
        assert actual == refs[str(p)]
    refs[str(p)] = actual
    return raw


def body(raw, token):
    at = raw.index(token.encode())
    line = raw.rfind(b"\n", 0, at) + 1
    indent = raw[line:at]
    # Visibility may precede fn in the relocated node budget.
    indent = indent.replace(b"pub(crate) ", b"")
    assert not indent.strip(), (token, indent)
    end = raw.index(b"\n" + indent + b"}", at) + len(indent) + 2
    return raw[at:end]


entry = now()
completion = json.loads(
    read(
        dict(
            path=str(BASE / "completion.json"),
            sha256="da853d25eb6804731457ccd8f4cea75d372824654c0926170b8e809b5c44bd4d",
            bytes=3196,
            mode="0644",
        )
    )
)
keys = [
    "arena_source_binding",
    "arena_report",
    "arena_forward",
    "arena_inverse",
    "arena_static_proof",
    "arena_verification",
    "arena_draft",
    "source_STOP",
]
contents = {name: read(completion[name]) for name in keys}
binding = json.loads(contents["arena_source_binding"])
generation = json.loads(read(binding["generation_binding"]))
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
forward = scope["split_patch"](contents["arena_forward"])
inverse = scope["split_patch"](contents["arena_inverse"])
before, after, checks = {}, {}, []
teacher = "crates/quoridor-runner/src/teacher_pilot_execution.rs"
runtime = "crates/quoridor-runner/src/runtime.rs"
resources = "crates/quoridor-runner/src/resources.rs"
for row in binding["subjects"]:
    name = row["subject"]
    old = gzip.decompress(read(row["recovery"]))
    assert (
        len(old) == row["before"]["bytes"]
        and hashlib.sha256(old).hexdigest() == row["before"]["sha256"]
    )
    post = read(row["post"])
    if name == teacher:
        gen_row = next(r for r in generation["subjects"] if r["subject"] == name)
        assert gen_row["post"]["sha256"] == row["before"]["sha256"]
    else:
        returned = subprocess.run(
            ["git", "show", f"8be646be:{name}"],
            cwd=ROOT,
            capture_output=True,
            check=True,
            timeout=20,
        )
        assert returned.stdout == old
    f, n = scope["apply"](old, forward.pop(name))
    b, m = scope["apply"](post, inverse.pop(name))
    assert f == post and b == old and n == m
    checks.append({"subject": name, "hunks": n, "strict_forward_inverse": True})
    before[name], after[name] = old, post
assert not forward and not inverse
protected = []
for row in json.loads(contents["arena_static_proof"])["protected_bodies"]:
    a, b = body(before[row["subject"]], row["body"]), body(after[row["subject"]], row["body"])
    assert a == b
    protected.append(
        {
            "subject": row["subject"],
            "body": row["body"],
            "byte_exact": True,
            "lexical_SHA256": hashlib.sha256(b).hexdigest(),
        }
    )
relocated = []
for token in ["fn new(", "fn reserve(", "fn settle("]:
    a, b = body(before[teacher], token), body(after[resources], token)
    assert a == b
    relocated.append(
        {"body": token, "byte_exact": True, "lexical_SHA256": hashlib.sha256(b).hexdigest()}
    )
assert body(before[teacher], "mod common_node_budget_tests {") == body(
    after[resources], "mod common_node_budget_tests {"
)
r = after[runtime]
turn = body(r, "fn evaluation_turn(")
assert (
    turn.index(b"budget.reserve(")
    < turn.index(b"let started = Instant::now()")
    < turn.index(b".commands")
)
assert b"max_nodes: turn.node_limit.unwrap_or(e.max_nodes)" in r
assert (
    turn.index(b"let terminal = loop")
    < turn.index(b".settle(reserved, result.stats.nodes)")
    < turn.index(b"record_evaluation_alpha(")
)
assert b"if owner == engine && origin == id =>" in turn
assert b"result: Ok(result)" in turn and b"operation_node_remaining_after_drain" in turn
assert b"owners.close();" in r and b"charged_nodes_including_opaque_reservations" in r
new_fn = "arena421_exhausted_operation_budget_enters_no_worker_and_preserves_unknown_parent"
assert b"fn " + new_fn.encode() + b"(" in r
draft = json.loads(contents["arena_draft"])
assert len(draft["conditions"]) == 4
assert (
    draft["arena"]["max_total_nodes_per_contrast"] * len(draft["conditions"])
    == draft["whole_arena_max_total_nodes"]
    == 1000000000
)
assert draft["arena"]["max_total_nodes_per_contrast"] == 250000000
assert draft["ready"] is False and draft["image"] is None and draft["Experiment"] is None
assert draft["games_max"] == 128 and draft["engine"]["max_nodes"] == 1000000
assert draft["clock"] == {"authority_receipt_ms": 100, "return_reserve_ms": 5}
stop = json.loads(contents["source_STOP"])
known = {}
for row in stop["receipts"]:
    identities = [row["controller"], *[p["original"] for p in row.get("processes", [])]]
    for old in identities:
        key = (old["pid"], old["start_ticks"], old["boot_id"])
        known[key] = {
            "original": old,
            "fresh_pid_absent": not (Path("/proc") / str(old["pid"])).exists(),
        }
metadata = stop.get("metadata_writer_identity")
if metadata:
    known[(metadata["pid"], metadata["start_ticks"], metadata["boot_id"])] = {
        "original": metadata,
        "fresh_pid_absent": not (Path("/proc") / str(metadata["pid"])).exists(),
    }
assert all(r["fresh_pid_absent"] for r in known.values())
selected = list(refs.values())
for ref in selected:
    read(ref)
reader_stop = now()
result = dict(
    target=refs[str(BASE / "completion.json")],
    source_binding=completion["arena_source_binding"],
    entry=entry,
    actual_reader_STOP=reader_stop,
    before=selected,
    after=list(refs.values()),
    all_refs_SHA_size_mode_before_after_exact=True,
    patch_checks=checks,
    protected_lexical_bodies=protected,
    NodeBudget_relocated_methods=relocated,
    moved_original_fixture_byte_exact=True,
    base8be_and_generation_before_exact=True,
    scalar_four_disjoint_250M_equals_1G=True,
    producer_known_identity_fresh=list(known.values()),
    new_definition="One assertion UNBUILT/UNTYPED/UNRUN at author; moved fixture not a new pass",
    target_functions_tests_Rust_native_model_Search_geometry_executed=0,
    model_library_RAW_payload_reads=0,
    source_Main_Git_index_writes=0,
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    canonical_lease_acquired=False,
    directwait="Read-only git subprocesses synchronous returned/reaped; plain-tool identity/handle details UNKNOWN",
    static_elapsed_seconds=time.monotonic() - start,
    self_VmHWM=next(
        line
        for line in Path("/proc/self/status").read_text().splitlines()
        if line.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    future_quiet_or_reservation=False,
)
(OWN / "static-proof.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            k: result[k]
            for k in [
                "actual_reader_STOP",
                "all_refs_SHA_size_mode_before_after_exact",
                "patch_checks",
                "static_elapsed_seconds",
                "self_VmHWM",
            ]
        }
    )
)
print("fresh_known_source_IDs", len(known))
