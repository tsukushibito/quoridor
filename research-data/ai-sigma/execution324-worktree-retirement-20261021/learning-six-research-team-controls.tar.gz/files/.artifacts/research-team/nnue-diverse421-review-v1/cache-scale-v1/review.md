# 421.4 cache / fit scale binding の限定source確認

**source_clear=true / blockers=0 / ordinary=0**。固定target `ffc2cd0ba97293c9360b9720e308ee0a8fdfbd046ec7f853feb6b4e47b74addc` に対する4 hunkをbefore gzipから正方向・逆方向とも厳密再構成しました。14 selected refsのSHA/size/modeは前後一致。変更ownerは `common_cache_config` と `public_replay.admit` だけで、外側bytes/ASTと他21 top-level ownerが一致しています。新4 fake NN0の作者PASSはsaved evidenceとして読むだけで、再実行していません。

`common_cache_config` のauthority欠落許容はdata-only読取のためです。presentならdict型・完全fieldset・lowercase SHA・incumbent_descriptor_T_onlyを引き続き要求し、null/不正型/欠落fieldsetも拒否します。native provenance、complete stream、ordered source/batch union、schedule/partition、outcome eligibility/censusには同じ検査が残っています。実cacheやbinaryを変更する差分ではありません。

fitは必ず従来の `warmstart_model_inputs` を通り、authorityがゼロなら拒否します。cache内authorityと外部authorityを同じactual warmstart descriptor/weights/evaluator・T-only scale tupleへ比較し、両方ある場合は両方一致が必要です。外部経路は明示cache SHA、同じcache path/hash、descriptor/weightsの完全なFileRef一致を要求します。既存bound_file_bytesループが全filesのregular/size/mode/raw SHAを検査するので、空のfilesやhashだけの代用refでは通りません。cache内の不正authorityを正しい外部authorityで救済することもありません。

C.input-binding619ac7f6の宣言は、cache76ddaff5/135087B、BEST43 descriptor46ec/677B0600・weights046fe/49284B・evaluator96a5・incumbent_descriptor_T_onlyに一致します。元のresolved recipe検査とdescriptor/scale validatorはbyte不変で、BEST43以外やscale再計算へ緩めていません。これはbinding metadataの照合であり、レビュー者はcache/descriptor/weightsのpayloadを読取・再hashしていません。actualcache完成T2216/V606はRootが渡したsaved事実で、ここで独立censusは行っていません。

通常entryではbinding自身とfiles全ref、cache binaries、current config/model/public/caller/libraryをordered Experiment.inputsへ入れ、argvと生存期間のbefore/after custodyを既存guardianで束縛する必要があります。このsource変更だけがinput lifetimeやRUNを認定するものではありません。特にinput-binding JSON自体をこの関数が自己認証する仕組みではありません。正常な既存parent/Experiment admissionが前提です。

Mは今後の実C STOP/finalize/cleanup後のINITIAL FileRefを同じexternal tupleへ追加し、Mの実Experiment inputsへ束縛する必要があります。未来refは本packetにありません。train_mixture/observation_binding全一致検査・scopes・step0再利用/zero-new-forward・loss/optimizer/export/forward/finalizers/LAST UNKNOWNはbyte不変で、MをCの学習済みweightsから開始する差分もありません。実C INITIAL・R/U/configs・本物のruntime interoperabilityは未成立であり、fake testのtoy observationを実数値として扱いません。

実source Reader STOP **2026-10-16T01:18:01.155466+00:00**。既知9 PIDはそのwindowでfresh absent、owned readers/children/jobs/handles/TMP/leases/remaining=[]。canonical/hardware lease取得なし。finite stdlib checker0.135307285秒/self VmHWM25852kB、AS512MiB/CPU16。01:15:54のCPU16/core8とguardian18/core9、MemAvailable14873612kBはdated factでありfuture quietではありません。連続family peakとplain tool詳細identity/handlesはUNKNOWN。対象関数/import/tests/Python-framework/Torch/NumPy/cachepayload/RAW/native/Search/Cargoは0。Main/source/Git/index書込0。

本source clearはsoftware/native/cache/fit/strength/defaultの資格ではありません。原materializer KeyError、FAILED/partial cache/RAW/費/mask/UNKNOWN、旧323・342のpause、model/weights/seals/defaultsを保持します。421.4はin_progressを維持し、ACK・親閉鎖待ちを作りません。
