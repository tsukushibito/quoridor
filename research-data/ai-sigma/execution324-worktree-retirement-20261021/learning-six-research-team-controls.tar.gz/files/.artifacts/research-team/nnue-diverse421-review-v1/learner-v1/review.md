# 421.4 learner source phase

**source_clear=true / blockers=0 / ordinary=0**。固定421.2 binding `9f14cd69ac25fb43d4a65743e97e659dcc0601de8aa539c6c3f0a05f334176e0`に限定します。spec afa79145 / contract e3cb5b30と照合し、4既存sourceと新testの計29hunkを厳密forward/inverseで再構成、変更外AST/statement byte不変と選択参照前後一致を確認しました。モデル/head/loss/scale/export/codecの旧資格は再監査・再実行していません。

Tの既存eligibleだけを、gameごとにstock16..20/8..15/1..7/0から各8行までchronological等間隔で選び、空層を補充しません。Vは全eligible行、collision familyのT/V混在は拒否。同familyに複数gameがあるため、32行capはfamily均等・game均等objectiveや独立標本数を意味しません。既存outcome-only cacheとliteral STM zを使い、stock/q/誤差によるラベル選別は追加していません。

Cはadded0+public256、Mは128+128、同U/同出発モデルのfresh Adamです。publicは同seed19のn番目drawが共通で、update-aligned行一致ではありません。added cyclingは独立seed20。完了updateのvisitsとattempted countersを分けて残します。R=1はU=1でも128draw、R=1632はU=51、R=2048はU=64。小Rを4/5露出と呼べません。scalar上界は2×64×256 +9×(419150+12800+8192+2048)+1024 = **4,013,502**。未使用6M枠は追加scienceの許可ではありません。

newVのfamilyごとSSE/countを平均してBESTをstrict improvementで選び、同値は早い点、public nonregression=falseです。INITIALはCの実保存観測FileRefとinitializer/scale/cache/public/scope indices/counts/constants/batch/strataが一致する場合だけMで再利用し、Mの新INITIAL forwardは0。通常parentはその実C FileRefを実inputsにも束縛する必要があり、現時点でcache/R/U/config/newweights/観測refを捏造していません。失敗中のoptimizerを過去stepへ戻さずLAST UNKNOWNを保ち、exposure/LAST/result/identityの独立finalizerを残しています。

供給された7 fake NN0はsource-related synthetic証拠です。元test-onlyFAIL、未完了だけの訂正PASS、format/sourceproof拒否とpending-vs-returned receiptの区別を保持。fake256/real0はproducer-bound factsであり、今回は対象関数・テスト・NumPy/Torch・モデル/forward・native/Search/Cargoを実行していません。実fit/転換/入力native/strengthは未資格です。

Reader STOP **2026-10-15T23:50:02.124512+00:00**、producerの既知45 PIDはfresh absent、owned readers/children/jobs/handles/TMP/leases/remaining=[]。lease取得なし。有限stdlib checkerのみ0.263778150秒、self VmHWM20808kB（連続family peakはUNKNOWN）。詳細な通常tool identity/handle receiptとfuture quietは主張しません。CPU10/core5とguardian14/core7は別physical、entry23:44:49のMemAvailable15696608kBはその時点の事実だけです。Main/Git/sourceへのwrite0、旧RAW/費/UNKNOWN・pause/model/sealは保持。421.4はin_progressのまま、次の固定generation/input phaseだけを継続します。
