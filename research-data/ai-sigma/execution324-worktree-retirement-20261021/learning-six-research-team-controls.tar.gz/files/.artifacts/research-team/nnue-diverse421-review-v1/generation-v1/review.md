# 421.4 generation/input source phase

**source_clear=true / blockers=0 / ordinary=0**。固定completion `7ad25c6ec914df733e055c71fc7db55e2499958354a6f74661aaa5e5bb766259` / binding `9a88588580a5673ef96a84546faf230c2dbb255010c34b7dc9f1476ad42c778d`だけの関連確認です。6 Rust sourceの32hunkを正逆両patchで厳密再構成し、gzip before/post/SHA-size-modeの前後一致、7保護bodyのbyte一致を確認。Root composition6c9c73ccのmetadataが同6postを指すことも確認しました。現在Mainやsoftware全体の資格を新設していません。

生成はmaintained Control factoryから、method選択後にLMRを有効化します。実sessionのcapacity/namespace/methodを保存してcanonical expected policyへ照合し、各game内の二色sessionを別所有、approx/safeは明示OFF。TT1Mのbyte上限はTable自身のchecked算術を公開しただけで、introspection用の追加TTやownerはありません。省略LMRはfalse、無効method名はOFFでも拒否。今回のLMR ON D6はselective nominal完了で、exact fullwidth minimax証明ではありません。

return policyはfinite value/bit、D6完了、stop、node/PV/action、stock/STMを含むfull-history parent、method/TT/namespaceを検査します。既存NodeBudget/finish_game/terminal/ContextRecord/targetsはbyte不変で、opaque Errは予約を返さず、取消/未完成/error/200ply UNKNOWNにzを付けません。NodeBudgetはdynamic schedulerの外に一つだけ作り、全slotへ共有します。本studyは一つの64slot config/1G全体budgetで入り、batchごと1Gに作り直してはなりません。

入力は既存rules-only候補とcanonical partition_familiesを使い、旧bookのfamilies/openingsを同じprefix readerで準備・入場検査へ渡します。除外familyと、eval unique=trueで二番目以降のfamily slotは、元attempt/action/reasonを残すmissingにして補充しません。生成では同familyの複数gameを保持。実64requestと実family数/T-V数を混同しません。Rootは実generation prefix_book BoundJsonを16evalのexcluded_booksへ追加し、結果前に凍結する必要があります。draftはそのrefをnull/ready=falseのままにしており、Python再構成やdummy refはありません。旧未封印128book a6abde1fは供給metadataだけで、他bookの網羅はUNKNOWNです。

run_boundの小さいstdoutは保存済みgeneration-result/contentへの参照と件数を返し、詳細RAWを再出力しません。configは同じstrict型へ正規化して省略falseと明示falseを比較し、unknown fieldの拒否を保ちます。saved結果をcollector成功・棋力やソース資格へ救済する変更ではありません。

6新Rust定義は作者snapshotでUNBUILT/UNTYPED/UNRUN。今回は対象関数/test/import、Rust/native/geometry/prefix/Search/Cargo、model/library/旧book/RAW payloadを実行・読取していません。Rootの並行softwareは別証拠です。learner phaseのclearは再実行せず再用。実入力・global budget・source/image・全resourceの入場、後段arena1G packet、fit/strength/defaultは本clearの範囲外です。

Reader STOP **2026-10-15T23:55:56.296404+00:00**、既知source controller/childの78 PIDはfresh absent。owned readers/children/jobs/handles/TMP/leases/remaining=[]、canonical/hardware leaseなし。有限stdlib helper0.094755898秒、self VmHWM18012kB、連続family peakと詳細tool handles/identityはUNKNOWN。元NULL-return/disk failure、pending-vs-returned/mask・RAW・費/UNKNOWNは保持。Main/Git/source write0。421.4はin_progressのまま、未着の後段packetをpollせず関連source依存を待ちます。parent/pause/model/seal/defaultは変更しません。
