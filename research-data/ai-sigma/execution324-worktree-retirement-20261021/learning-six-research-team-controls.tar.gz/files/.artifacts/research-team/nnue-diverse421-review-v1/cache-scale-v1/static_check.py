"""Static patch/AST/ref checks only; no target function/import/test execution."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = OWN.parents[1] / "nnue-diverse421-learning-v1/cache-scale-receiver-v1"
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (50, 50))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    s = p.stat()
    raw = p.read_bytes()
    actual = {
        "path": str(p),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{s.st_mode & 0o7777:04o}",
    }
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def owner(raw, name):
    tree = ast.parse(raw)
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    lines = raw.splitlines(keepends=True)
    return tree, node, b"".join(lines[node.lineno - 1 : node.end_lineno])


entry = now()
target = {
    "path": str(BASE / "result-binding.json"),
    "sha256": "ffc2cd0ba97293c9360b9720e308ee0a8fdfbd046ec7f853feb6b4e47b74addc",
    "bytes": 6438,
    "mode": "0644",
}
binding = json.loads(read(target))
contents = {name: read(ref) for name, ref in binding["refs"].items()}
producer_proof = json.loads(contents["static-proof.json"])
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
parser_nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
assert len(parser_nodes) == 2
scope = {"re": re}
exec(compile(ast.Module(body=parser_nodes, type_ignores=[]), str(parser), "exec"), scope)
patches = scope["split_patch"](contents["source.patch"])
subjects = {
    "python/quoridor_training/common.py": ("common.py", "common_cache_config"),
    "python/quoridor_training/public_replay.py": ("public_replay.py", "admit"),
}
patch_checks = []
protected = []
before, after = {}, {}
for subject, (name, changed) in subjects.items():
    old = gzip.decompress(contents[name.replace(".py", ".before.py.gz")])
    new = contents[name]
    declared = producer_proof["owners"][subject]["before"]
    assert hashlib.sha256(old).hexdigest() == declared["sha256"]
    assert len(old) == declared["bytes"]
    forward, n = scope["apply"](old, patches[subject])
    inverse, m = scope["apply"](new, patches[subject], reverse=True)
    assert forward == new and inverse == old and n == m
    old_tree, old_owner, old_segment = owner(old, changed)
    new_tree, new_owner, new_segment = owner(new, changed)
    old_outside = old.replace(old_segment, b"# reviewed owner omitted", 1)
    new_outside = new.replace(new_segment, b"# reviewed owner omitted", 1)
    assert old_outside == new_outside
    old_tree.body = [v for v in old_tree.body if v is not old_owner]
    new_tree.body = [v for v in new_tree.body if v is not new_owner]
    assert ast.dump(old_tree, include_attributes=False) == ast.dump(
        new_tree, include_attributes=False
    )
    protected_names = []
    for node in old_tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            raw = ast.get_source_segment(old.decode(), node).encode()
            match = next(n for n in new_tree.body if getattr(n, "name", None) == node.name)
            assert raw == ast.get_source_segment(new.decode(), match).encode()
            protected_names.append(node.name)
    protected.append(
        {"subject": subject, "outside_owner_bytes_AST_exact": True, "owners": protected_names}
    )
    patch_checks.append({"subject": subject, "hunks": n, "exact_forward_inverse": True})
    before[name], after[name] = old, new
test_name = "python/quoridor_training/test_cache_scale_binding.py"
new_test = contents["test_cache_scale_binding.py"]
forward, n = scope["apply"](b"", patches[test_name])
inverse, m = scope["apply"](new_test, patches[test_name], reverse=True)
assert forward == new_test and inverse == b"" and n == m
assert set(patches) == set(subjects) | {test_name}
test_ast = ast.parse(new_test)
new_methods = [
    child.name
    for node in test_ast.body
    if isinstance(node, ast.ClassDef) and node.name == "CacheScaleBindingNN0"
    for child in node.body
    if isinstance(child, ast.FunctionDef) and child.name.startswith("test_")
]
assert len(new_methods) == 4
patch_checks.append(
    {"subject": test_name, "hunks": n, "exact_forward_inverse": True, "executed": False}
)

# Check exact changed containment statically; never evaluate the branches.
_, common_node, common = owner(after["common.py"], "common_cache_config")
guards = [
    node
    for node in common_node.body
    if isinstance(node, ast.If)
    and ast.dump(node.test, include_attributes=False)
    == ast.dump(
        ast.parse('"model_scale_authority" in manifest', mode="eval").body, include_attributes=False
    )
]
assert len(guards) == 1
guard = guards[0]
assert not guard.orelse
guard_text = ast.get_source_segment(after["common.py"].decode(), guard)
assert "not isinstance(authority, dict)" in guard_text
assert 'authority["scale_policy"] != "incumbent_descriptor_T_only"' in guard_text
_, _, admit = owner(after["public_replay.py"], "admit")
assert b"model_inputs = warmstart_model_inputs(cfg)" in admit
assert (
    b"if not authorities or any(authority != expected_authority for authority in authorities):"
    in admit
)
assert (
    b'extra.get("cache_manifest_sha256") != hashlib.sha256(path.read_bytes()).hexdigest()' in admit
)
for token in [
    b'cache_ref.get("path") != str(path)',
    b'cache_ref.get("sha256") != extra["cache_manifest_sha256"]',
    b'files.get("descriptor") != warm["descriptor"]',
    b'files.get("weights") != warm["weights"]',
    b'for name, ref in extra.get("files", {}).items():',
    b'bound_file_bytes(ref, max(1024**2, ref["bytes"]))',
]:
    assert token in admit
external = json.loads(contents["C.input-binding.json"])
assert set(external) == {"cache_manifest_sha256", "model_scale_authority", "files"}
assert set(external["files"]) == {"cache_manifest", "descriptor", "weights"}
assert external["files"]["cache_manifest"]["sha256"] == external["cache_manifest_sha256"]
constants = {}
for node in ast.parse(after["common.py"]).body:
    if (
        isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
    ):
        if node.targets[0].id in {"BEST43_DESCRIPTOR", "BEST43_WEIGHTS", "BEST43_EVALUATOR"}:
            constants[node.targets[0].id] = ast.literal_eval(node.value)
assert external["model_scale_authority"] == {
    "starting_weights_sha256": constants["BEST43_WEIGHTS"],
    "descriptor_sha256": constants["BEST43_DESCRIPTOR"],
    "evaluator_sha256": constants["BEST43_EVALUATOR"],
    "scale_policy": "incumbent_descriptor_T_only",
}
assert external["files"]["descriptor"]["sha256"] == constants["BEST43_DESCRIPTOR"]
assert external["files"]["descriptor"]["mode"] == "0600"
assert external["files"]["descriptor"]["bytes"] == 677
assert external["files"]["weights"]["sha256"] == constants["BEST43_WEIGHTS"]
assert external["files"]["weights"]["bytes"] == 49284
assert (
    external["cache_manifest_sha256"]
    == "76ddaff52f36524b5fa69960ccf3201e32b8d2411b07aac1280200bf86407e6f"
)
assert external["files"]["cache_manifest"]["bytes"] == 135087
_, _, validation = owner(after["common.py"], "validate_mixed_config")
for k in ["BEST43_DESCRIPTOR", "BEST43_WEIGHTS", "BEST43_EVALUATOR"]:
    assert k.encode() in validation
_, _, train = owner(after["public_replay.py"], "train_mixture")
assert b"bound_file_bytes(initial_observation_ref, 16 * 1024**2)" in train
assert b'initial_observation.get("binding") != observation_binding' in train
assert b"reuse_initial=initial_observation_ref is not None" in train
assert b"reused = initial_observation if step == 0 else None" in train
author_tests = json.loads(contents["nn0-result.json"])
assert author_tests["tests_run"] == 4 and author_tests["failures"] == author_tests["errors"] == 0
assert author_tests["real_forward_rows"] == 0
ids = []


def find_ids(value):
    if isinstance(value, dict):
        if {"pid", "start_ticks", "boot_id"} <= value.keys():
            identity = {k: value[k] for k in ["pid", "start_ticks", "boot_id"]}
            if identity not in ids:
                ids.append(identity)
        for child in value.values():
            find_ids(child)
    elif isinstance(value, list):
        for child in value:
            find_ids(child)


find_ids(json.loads(contents["STOP.json"]))
fresh = []
for identity in ids:
    absent = not Path(f"/proc/{identity['pid']}").exists()
    assert absent, identity
    fresh.append({"identity": identity, "fresh_pid_absent": absent})
before_refs = list(refs.values())
for ref in before_refs:
    read(ref)
stop = now()
proof = {
    "target": target,
    "actual_reader_START": entry,
    "actual_reader_STOP": stop,
    "before": before_refs,
    "after": list(refs.values()),
    "patches": patch_checks,
    "protected_outside_changed_owners": protected,
    "changed_owners": ["common_cache_config", "admit"],
    "external_C_binding_exact_declared_BEST43_metadata": external,
    "M_future_INITIAL_ref_not_fabricated": True,
    "model_cache_descriptor_weights_payload_read_or_hash": False,
    "author_four_fake_NN0": "saved PASS, not rerun; framework/model/corpus qualification false",
    "reviewer_target_imports_functions_tests_Rust_Cargo_native_Search_frameworks": 0,
    "source_Main_Git_index_writes": 0,
    "static_seconds": time.monotonic() - started,
    "self_VmHWM": next(
        v for v in Path("/proc/self/status").read_text().splitlines() if v.startswith("VmHWM:")
    ),
    "continuous_family_peak": "UNKNOWN",
    "fresh_known_identities": fresh,
    "owned_readers": [],
    "owned_children": [],
    "owned_jobs": [],
    "owned_handles": [],
    "owned_TMP": [],
    "owned_leases": [],
    "remaining": [],
    "canonical_lease_acquired": False,
    "directwait": "Finite foreground static helper returns synchronously; no child subprocess; plain tool detailed identity/handle receipt UNKNOWN",
    "future_quiet_or_idle_lease": False,
}
(OWN / "static-proof.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        {
            "reader_STOP": stop,
            "refs": len(refs),
            "hunks": sum(v["hunks"] for v in patch_checks),
            "protected_top_level_owners": sum(len(v["owners"]) for v in protected),
            "fresh_absent": len(fresh),
            "seconds": proof["static_seconds"],
            "self_VmHWM": proof["self_VmHWM"],
        }
    )
)
