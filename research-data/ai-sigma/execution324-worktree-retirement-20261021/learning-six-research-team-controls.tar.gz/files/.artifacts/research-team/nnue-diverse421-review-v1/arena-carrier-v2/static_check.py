"""Arena carrier receiver delta and saved metadata joins only; no target execution."""

import ast
import copy
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-diverse421-data-v1/arena-carrier-repair-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def remove_once(raw, start, end):
    a = raw.index(start)
    b = raw.index(end, a) + len(end)
    return raw[:a] + raw[b:]


def replace_once(raw, old, new):
    assert raw.count(old) == 1
    return raw.replace(old, new)


entry = now()
target = dict(
    path=str(BASE / "source-v1/completion.json"),
    sha256="b949f3814c1c31737305c46642a7e1c8b2d6bfdfd7c24960ec6a57c2394a7ed3",
    bytes=11420,
    mode="0644",
)
completion = json.loads(read(target))
binding = json.loads(read(completion["source_binding"]))
old, post = read(binding["before"]), read(binding["post"])
assert gzip.decompress(read(binding["minimum_recovery"])) == old
forward, inverse = read(binding["forward"]), read(binding["inverse"])
proof = json.loads(read(binding["proof"]))
protected355 = read(proof["protected355"])
read(completion["report"])
stop_raw = read(completion["sourceSTOP"])
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
fw, rv = scope["split_patch"](forward), scope["split_patch"](inverse)
name = binding["path"]
assert set(fw) == set(rv) == {name}
rebuilt, source_hunks = scope["apply"](old, fw[name])
restored, count = scope["apply"](post, rv[name])
assert rebuilt == post and restored == old and count == source_hunks
restored = remove_once(
    post, b"/// Arena admission consumes this common immutable book view,", b"}\n\n"
)
restored = remove_once(
    restored,
    b"    #[test]\n    fn arena421_input_book_projection_batch_seed_and_strict_history()",
    b"\n    }\n\n",
)
restored = replace_once(
    restored, b"book: &ArenaInputBook,", b"book: &crate::value_search_strength::GeneratedBook,"
)
restored = replace_once(
    restored,
    b"let book: ArenaInputBook = plan.book.read()?;",
    b"let book: crate::value_search_strength::GeneratedBook = plan.book.read()?;",
)
restored = replace_once(
    restored, b"        ArenaInputBook,", b"        crate::value_search_strength::GeneratedBook,"
)
assert restored == old
assert post.count(b"#[test]") == old.count(b"#[test]") + 1
assert b"#[serde(deny_unknown_fields)]\npub struct Family" in protected355
assert (
    b"pub seed: u64" in protected355 and b"pub history_counts: Vec<(String, u16)>" in protected355
)
metadata = json.loads(read(completion["metadata_binding"]))
original_completion = json.loads(read(metadata["original_completion"]))
book_raw = read(metadata["carrier"])
book = json.loads(book_raw)
provenance = json.loads(read(metadata["provenance"]))
plan_raw = read(metadata["plan"])
plan = json.loads(plan_raw)
old_book_raw = read(provenance["original_carrier"])
old_book = json.loads(old_book_raw)
old_plan_ref = next(r for r in original_completion["outputs"] if r["path"].endswith("/plan.json"))
old_plan_raw = read(old_plan_ref)
old_plan = json.loads(old_plan_raw)
schedule = json.loads(read(metadata["unchanged_schedule"]))
native_schedule = json.loads(read(provenance["source_native_schedule"]))
prefix_book = json.loads(read(provenance["source_prefix_book"]))
generator = json.loads(read(provenance["source_generator_config"]))
read(provenance["source_native_input_preparation"])
assert book["complete"] is True and book["rules"] == plan["rules"] == old_book["rules"]
assert set(book) == {"complete", "rules", "families"}
seed = generator["prefix_seed"]
assert seed == provenance["seed"] == 42120261016
assert provenance["per_family_rng_state"] == "UNKNOWN"
assert provenance["per_family_independent_seed"] is False
assert provenance["seed_regeneration_claim"] is False
assert (
    len(book["families"])
    == len(old_book["families"])
    == len(native_schedule["scheduled"])
    == len(prefix_book["openings"])
    == 16
)
for f, previous, slot, opening, attempt in zip(
    book["families"],
    old_book["families"],
    native_schedule["scheduled"],
    prefix_book["openings"],
    provenance["actual_attempts"],
    strict=True,
):
    expected = {**previous, "seed": seed, "attempt_id": 0}
    assert f == expected
    assert f["family_id"] == slot["game"] == attempt["family_id"]
    assert f["id"] == slot["request_id"] == attempt["request_id"]
    opening_prefix = opening["prefix"] if isinstance(opening, dict) else opening
    assert f["prefix"] == slot["prefix"] == opening_prefix
    assert f["root_key"] == slot["root"]["state_key"]
    assert f["history_counts"] == slot["root"]["history"]
    assert slot["scheduled_failure"] is None
    assert (
        len(slot["attempts"]) == 1 and slot["attempts"][0]["attempt"] == attempt["attempt_id"] == 0
    )
    assert slot["attempts"][0]["rejection"] is None
old_files = {"arena-book.json": old_book_raw, "plan.json": old_plan_raw}
new_files = {"arena-book.json": book_raw, "plan.json": plan_raw}
quota = 0
for i, pair in enumerate(metadata["configs"]):
    before, after = read(pair["before"]), read(pair["after"])
    previous, current = json.loads(before), json.loads(after)
    expected = copy.deepcopy(previous)
    for opening, f in zip(expected["arena"]["book"]["openings"], book["families"], strict=True):
        assert opening["id"] == f["id"] and opening["prefix"] == f["prefix"]
        opening["original_seed"] = seed
        opening["reference"]["source_sha256"] = metadata["carrier"]["sha256"]
        opening["reference"]["settings"].update(
            attempt_id=0,
            seed=seed,
            seed_scope="shared_generator_batch_prefix_seed",
            per_family_rng_state=None,
        )
        assert opening["reference"]["settings"]["root_key"] == f["root_key"]
        assert opening["reference"]["settings"]["history_counts"] == f["history_counts"]
    assert current == expected
    assert current["games"] == 32 and current["arena"]["max_total_nodes"] == 250000000
    assert current["engines"] == plan["matchups"][i]["engines"]
    assert current["arena"]["evaluator_sha256"] == plan["matchups"][i]["evaluator_sha256"]
    assert plan["batches"][i]["config"] == pair["after"]
    quota += current["arena"]["max_total_nodes"]
    old_files[f"config-{i:03}.json"], new_files[f"config-{i:03}.json"] = before, after
assert quota == completion["whole_quota"] == 1000000000
assert plan["planned_slots"] == len(schedule) == 128
expected_plan = copy.deepcopy(old_plan)
expected_plan["book"] = metadata["carrier"]
expected_plan["inputs"] = [
    metadata["carrier"] if r == provenance["original_carrier"] else r for r in old_plan["inputs"]
] + [metadata["provenance"]]
for batch, pair in zip(expected_plan["batches"], metadata["configs"], strict=True):
    batch["config"] = pair["after"]
assert expected_plan == plan
for r in plan["inputs"]:
    if "/identity-view-v1/" in r["path"]:
        identity = json.loads(read(r))
        assert identity["typed_evaluator_sha256"] == plan["models"][1]["evaluator_sha256"]
    if "/fit-C-v1/saved-completion" in r["path"]:
        c = json.loads(read(r))
        assert c["best_step"] == 0 and c["selected_BEST"] == plan["models"][0]["descriptor"]
meta_refs = {Path(r["path"]).name: r for r in completion["metadata_files"]}
mf = scope["split_patch"](read(meta_refs["forward.patch"]))
mi = scope["split_patch"](read(meta_refs["inverse.patch"]))
assert set(mf) == set(mi) == set(old_files) == set(new_files)
metadata_hunks = 0
for name in old_files:
    result, count = scope["apply"](old_files[name], mf[name])
    reverse, reverse_count = scope["apply"](new_files[name], mi[name])
    assert result == new_files[name] and reverse == old_files[name] and count == reverse_count
    metadata_hunks += count
ids = []


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            identity = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if identity not in ids:
                ids.append(identity)
        for child in v.values():
            find_ids(child)
    elif isinstance(v, list):
        for child in v:
            find_ids(child)


find_ids(json.loads(stop_raw))
fresh = []
for identity in ids:
    assert not Path(f"/proc/{identity['pid']}").exists(), identity
    fresh.append(dict(identity=identity, fresh_pid_absent=True))
before = list(refs.values())
for ref in before:
    read(ref)
stop = now()
out = dict(
    target=target,
    source_binding=completion["source_binding"],
    before=before,
    after=list(refs.values()),
    unique_selected_input_B=sum(r["bytes"] for r in before),
    source_reader_START=entry,
    source_reader_STOP=stop,
    source_clear=True,
    blockers=0,
    ordinary=0,
    strict_source_hunks=source_hunks,
    strict_metadata_hunks=metadata_hunks,
    protected_before_after_exact=True,
    prefix_history_family_order_exact=True,
    shared_batch_seed=seed,
    per_family_rng="UNKNOWN",
    actual_attempt_id=0,
    four_operation_quota_sum=quota,
    fixture="UNBUILT/UNTYPED/UNRUN; no old13/NodeBudget replay",
    fresh_known_IDs=fresh,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="Finite foreground stdlib patch/metadata helper; no subprocess; detailed tool handles UNKNOWN",
    target_functions_tests_models_RAW_native_geometry_library_Search_executions=0,
    source_Main_Git_index_writes=0,
    futurequiet=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            reader_STOP=stop,
            refs=len(refs),
            source_hunks=source_hunks,
            metadata_hunks=metadata_hunks,
            fresh_absent=len(fresh),
            seconds=out["static_seconds"],
        )
    )
)
