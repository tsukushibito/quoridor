# 421.4 arena aggregate node inlet

**source_clear=true / blockers=0 / ordinary=0**。固定completion `da853d25eb6804731457ccd8f4cea75d372824654c0926170b8e809b5c44bd4d` / binding `2eff73382d30624172827924ddb936ab0ebe44390e79d7a51df1b95d27c9cbb7`の4 owning pathsだけを確認しました。21hunkの正逆patch/gzip/current postimageを厳密再構成、8 protected bodyとNodeBudgetの3method・元fixtureのbyte一致を確認。runtime/arena/resourcesは8be646be、teacher executionは受理済みgeneration postというbefore対応も一致。learner/genの成功scopeや32hunkは再実行していません。

budgetはEvaluationWorkersにoperation単位で一つだけ作り、games loopではresetしません。mainがthinking clock/dispatchより先にmin(残枠, engine.max_nodes)を予約し、workerの本物のSearchLimitsへ渡します。枠0では親・観測・forfeitを変更する前に既存error/UNKNOWN経路へ戻り、後続slotも既存の未入場censusへ残ります。true rule terminalの判定は次の予約より前です。

精算はengine/idが一致するterminalを回収した後、そのAlpha Okの累積stats.nodesだけです。選択completed snapshotは重複加算しません。cancel後でも実terminalの既知workは精算可能で、Err/panic/channel不明のopaque予約は保持します。次turnは既存drain/commit順を通ります。時計・Control/PVS/TT/LMR factory・親復元・合法性・error priority・commit本体はbyte不変です。cap超過をDraw/forfeitや成功fallbackへ変える処理はありません。

NodeBudgetは既存resourcesへ移動した同じ算術で、新registry/scheduler/loopではありません。省略Noneでは別budgetや新counter JSONを作らず、従来限度を使います。既存structの追加領域や速度/layout/RSSは未資格で、OFF無費用は主張しません。ONの最終pumpにはjoin後cap/remaining/opaqueを含むcharged上界を保存し、terminal node数へ再加算しません。これは観測exact node合計ではなく、実Searchが渡したmax_nodesを守る既存契約に基づく保守的な上限です。

後段4対照は固定250Mずつ、計1G、移送/refillなしというdraftです。128maximumは完了保証ではなくquotaによりUNKNOWNを残せます。実config/input/model/software/resource対応はRootの通常入場で別途束縛し、source clearから数値・対局・棋力/defaultを認めません。実generation準備の64/16入力はこのsource確認の依存や再実行対象にしていません。

新規assertion1件は作者snapshotでUNBUILT/UNTYPED/UNRUN。移動したfixtureを新PASSへ数えず、レビュー者は対象関数・テスト・Rust/native/model/Search/geometry/Cargo/ゲームを実行せず、model/library/RAW payloadも読んでいません。Main scan/adoptionなし。Rootの疎合成・softwareは別scopeです。

Reader STOP **2026-10-16T00:07:03.358431+00:00**、既知source/controller/child127 PIDはfresh absent、owned readers/children/jobs/handles/TMP/leases/remaining=[]。lease取得なし。read-only gitはdirect return/reap済み、詳細tool identity/handle receiptと連続family peakはUNKNOWN。有限stdlib checker0.711530335秒/self VmHWM20120kB。CPU16/core8とguardian18/core9は別physical、00:03:55のMemAvailable15942396kBはその時点の事実だけでfuture quietではありません。Main/source/Git write0、旧NULL/disk/mask/RAWFAILED費/UNKNOWNと全pause/model/seal/defaultを保持。421.4はin_progressのままです。
