# 422.1 固定7状態の直接static caller

新422だけのsource-only成果。作者のnative/モデル読込・forward・Search・suite・arena・学習は0。421の9f14/fcc9/180093f6と実cache依存、旧323/342.17/全旧learner pause、重み・特徴・scale・既定・RAW/FAILED/費/UNKNOWNを維持した。

## 入力と呼出し

既存fixed-inputs b26fb4d5の元3親、existing-endpoint-input-support 5953bd81の全4 endpointをstored orderで固定した。input.jsonはこの7件と既存モデル・library/control refsだけを含む。原RAW、19MB tree/parity journal、モデル/library payloadを作者は読み込まず、サイズ/mode metadataだけ必要範囲で確認した。

Main変更案はmeasurement.rsへのcfg(test) module3行と、新measurement_static422_tests.rsだけ。新production API/trait/encoder/CLI/registryや別評価式は作らない。既存のnormal replay/loss_leaf::input_checkで元3親の完全prefix・ordered history・count multiset・盤面・手番・在庫・非終端を確認する。4 endpointは完全prefix replayと、本物の元parentから保存pathをplayしたcontextが一致し、既存モデルfeatures/距離bits/sideとも一致することを確認する。countの出力だけ比較用にkey順へ正規化し、contextをcountから構築しない。

NNUEは元BEST43のdescriptor/weights/fingerprintを束縛し、現行ResidualModel::load→full_context(Scalar)→evaluate_view_with_scratchを使う。pre/postは同じ一回のcanonical head計算から取得する。T-only scale/Zero4/FP32/tanhとheadは変更せず、atanh/別head式はない。現行measurementのload_residual_modelと同じcanonical loader/fingerprint検査をtest内で使う。新しい実full/delta parityは行わず、保存419 parityの4 endpointの適用範囲をlocatorsで再用する。

Sigmaはruntime::sigma_value_evaluatorの一つのArc/同期CPU backendを全7行で保持する。論理limit7、旧420と同じbudget-independent typed identity、ONNX d790とlibrary c902/既存1.30.0 metadataを使用する。raw_value/adapter_valueは二つの独立観測ではない。adapterの実返値を、NetworkOutput.valueを無加工で返す現在sourceとの同一forward対応として二欄に示し、その根拠を各行へ明記する。rawを別に得る追加forwardは0。MCTS root mean/policyには置換せず、joint policy+valueの実費としてcounterを保存する。既存ORT createは明示Runを呼ばず、CPU session intra/inter各1のsourceも束縛する。runtime versionの追加queryはせず、library bytesの実identityと既存version metadataを区別する。

Dは既存DistanceEvaluator::new(0,8).evaluate(root,None)だけ。Dをoracleとして扱わない。全行の値は実localSTMであり、endpointの元parent sideとpath長を別に記録する。rootバックアップ値へ符号を変えた値ではなく、STM反転の反対称性を受入条件にもしていない。元3親の旧探索値はstatic欄へ持ち込まずUNKNOWN。4 endpointの旧DIRECT N/D bitsと差は保存値からの記述に限定し、一致/違いで追加状態や再実行を選ばない。

## 件数と部分結果

事前に7状態を全てadmitし、モデルsetup後に7行のdirect entryを一回通す。通常完了時は新NNUE canonical head7、Sigma logical7/physicalは実counter、D7。NNUEのfull-context/FT準備とheadのstarted/returnedを分けて記録し、新delta/parity/reference call0。ResidualModelのload/from_partsはheadを呼ばないsource対応を明記する。物理FTやhardware head instruction回数はUNKNOWNで、entry回数を物理kernel数と同一視しない。

whole422上限はSigma14 logical/physical（warm/failedを含む実counter）、NNUE28 actual head、D7である。callerは各entry前にguardし、Sigmaは途中でbackendを作り直さず、setup/dropも保持する。Runやconstructorの費用をvalue-only推論費と呼ばない。追加fixture推論、旧reference5、16/28suite、再試行・refillは0。

途中error/非finite/上限/取消では、完了行・started/returned・in-progress/未実行UNKNOWNとprimary/secondaryを保存し、0/fallback/数学Drawへ変えない。通常guardianが取消/kill/直接wait/reap/handles/TMP/全source/model/library before-afterを所有する。強制cancel直前のnative resultがSTARTING/IN_PROGRESSならそのまま原部分事実として回収する。setup/drop/whole時間は重なるscopeで足さず、速度結果ではない。

出力はJSONの保存先と小summaryだけ。表の正本列はid/source/prefix、history key/counts、盤面・手番・在庫、モデル/実image/ORT refs、NNUE pre/post+bits、Sigma raw/adapter+bitsと根拠、D+bits、旧DIRECT対応、calls/errorsである。実image FileRefは原Build/guardian collectionが実test executableへ結び、nativeはcurrent_exe pathを保存する。将来image/output FileRefを作者packetへ埋めていない。

## Rootの一回の実施と撤去

必要なgenuine compile/Clippy/test-profile artifactはRootの共有Cargo ownerが行う。作者のRustfmtはsyntax/formatだけで、新definitionはUNBUILT/UNTYPED/UNRUN。filterは`measurement::static_evaluators422_tests::seven_saved_states_direct_static_once`、crate quoridor-runnerのmeasurement feature/lib test。実runは同じartifactへ`--ignored --exact FILTER --nocapture --test-threads=1`だけを一回与える。旧成功testを選ばない。

環境変数はQUORIDOR_STATIC422_INPUT、QUORIDOR_STATIC422_INPUT_SHA256（整形済み実input SHA）、QUORIDOR_STATIC422_OUTPUT（既存owner directory内の新file）。parentが実input/3原metadata、実モデル/ORT library、現行sourceとgenuine executable/runtimeを通常entryで束縛し、後でも検査する。N/Dモデルmathや入力encoderのproduction変更はないので、新しいproduction変換reviewは識別していない。型付きsoftwareと数値はRootの次の実依存である。

7行の原saved resultを保持後、この一度限りのcfg(test) moduleを撤去可能。元source/patch/入力はpacketとGitで復元でき、常設APIや旧互換経路として残す必要はない。独立する421のconverter/fitや親close/Root ACKをsource完了条件にしない。
