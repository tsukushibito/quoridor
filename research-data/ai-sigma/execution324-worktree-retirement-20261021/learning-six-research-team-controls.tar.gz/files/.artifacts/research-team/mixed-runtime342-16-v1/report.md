# 混合学習の実運用準備（342.16.1）

この成果は設定・参照・資源の準備であり、科学実行の許可ではない。1回の試行委任と3つの重要条件は未回答。生成、schedule/partition作成、cache作成、model forward、fit、Search、対局、Perf、Cargoは実行していない。既存381の成功は元のscopeで再利用し、再演していない。

## 提案設定と相違点

settings.UNSELECTED.jsonは既存381の同じ形式を使用する。max1280リクエストを320ずつ4batch、opening4/8/12/16、completedD6と実最終STM outcome z、生成前のglobal whole-family80/20、T-family最大64行、全RAWと全Vを保全する案。public T:newD T=1024:1024、FP32 batch2048、fresh Adam LR1e-4、BEST43の不変parameters・incumbent T-only尺度・output bypass OFF、一候補。max512updates／newD8exposures／6M all forwards、source別左右反転.5、100update毎と終端の測定、INITIAL参照/BEST/LAST、newD-V選択・publicV別監視という未選択案を表した。

旧settings66cbd755はselector.public_non_regression=trueでpublicV gateを要求する。今回の「newD-V選択・publicV別監視」案はfalseとして明示し、trueを比較選択肢として保持した。どちらも人間選択済みとは扱わない。cap64／all rows、publicV gate有無、whole8GiB部分停止／worst-case容量は重要な未選択条件である。warmup100、patience5等の旧提案値も許可に転用しない。

80/20はnative partition_familiesが反転・prefix extension・同endpointをまとめたunique familyをrankし、floor(4F/5)をTとする。リクエスト数の固定1024T/256Vを保証しない。生成前の予定・実family/request分母、failed/UNKNOWN、欠測を残す。raw±2でも実outcomeがあればeligibleであり、raw範囲でzをmaskしない。旧362のraw-range maskを新データとして流用しない。

T view上限64*1024=65536、max512*2048=1048576 training forwards。Vゲーム数256という旧価格仮定は無条件boundでないため、newV全体を最大243200行で保守的に計算した。7測定点で(publicV419150+newV243200+T診断8192\*2)の4751138、計5799714、6Mまで200286余裕。全件正常・最低行数・収束・実runtimeを保証しない。cacheの実行数で既存planned_workがモデル開始前にboundを計算し、empty T/Vや6M超過は拒否する。capNoneやfull_train追加を黙って選ばない。

## 真正参照と工程接続

observations.jsonと最終bindingに必要なcurrent source/entry/root環境/BEST43/public metadataおよび真正artifactのFileRefsを記録した。元software-preparation4c4640cb、converter BUILD14764cb2/private3ba55549、runner BUILDf8890ea6/private9a63d2f3、interop2961d46c、settings66cbd755はhash/size/mode一致。両BUILDは元PASS/cleanupを維持し、Main HEADに合わせるためのbuildや資格再実行はしない。selected current caller等のrefsは新しい観測であり、旧qualificationをretargetしない。実launcherが既存normal native/tool/source対応を改めて確認することと、新scopeのPASS主張を区別する。

工程ownerは324の既存research-lifecycle.py sequence/prepare_selected_operation。新scheduler/helper/registryは作っていない。次の接続を同ownerが通常のcoded sequence内で成立させる必要がある。

1. selected InputConfigをteacher-pilot --prepare-inputs SETTINGS --input-sha256 SHAで一度作成する。実excluded book入力を検査し、global schedule/partitionは全batch共通で生成前に固定。
2. 4つの通常corpus RUNをstart0/320/640/960、count320で順次実行。whole共同node budget40G/batch案、D6、最大100M/move、総200ply。元childwait→authoritative result/finalize→cleanup/source STOPを完了して次へ進む。unexpected failure/cancelでsuffix UNKNOWN、成功batchを繰り返さず、refillしない。
3. retained4streamのglobal順をterminal-cache --input STREAM ... --output NEW_CACHEへ渡す。必要なら既存distinct input-bindingのmodel_scale_authorityを束縛する。CLIは--input-bindingと--binding-sha256の対。1つのoutcome_only v3 cache/7binaryを公表し、incomplete markerを最後に除去。詳細canonical gzipは保存し、trainerは再parseしない。
4. actual cache/7binary/manifest/public membership/immutable initializer/current共通entryをbindし、通常train --cache PATH --output PATH --config CONFIGで一候補を学習。scale再計算・optimizer resume・teacher変更なし。fit前のactual planned_work/counters、BEST/LAST、失敗時UNKNOWN checkpoint、primaryと独立secondary、全cleanupを現役入口で保持。
5. 候補の実descriptor/weights・必要native/export対応が揃ってから、独立64openingsを各2colours x BEST43/D=256games案で現役arena/sequenceへ渡す。100ms/5ms reserve/200plyは旧提案。sealedE、追加strengthgame、候補の救済再fit、比較対象の自動変更なし。

現在のsequence.settings.runsは事前にbindされたExperiment/config/inputsのlistを順次実行する。prepare_selected_operationは配置/intent等を作るが、先行生成結果から後段streams/cache/候補weightsを自動発見・再束縛する機能ではない。現settingsのrun_templates/streams/cacheはnullで、eval新modelも未作成。従って「4batch→converter→train→evalが今そのまま起動可能」とは主張しない。既存sequence ownerにおける後段準備のactual dependency接続が具体的残作業であり、別framework/admission/手動ACK chainを追加する理由ではない。必要なら324が同prepare境界を狭く変更する。今回のleafはMainを変更しない。

出力先案は既存fixed-d-sigma-mixture380-v1のdata/inputs、generation/batch-000..003、compact、checkpoints/candidate-v1、arena-evaluation側評価namespaceを使用する。今回1回の限定exists観測では全てabsent。提案文字列はFileRefでなく、実schedule/partition/cache/stream/newweightsにはnullを保持。ダミーhash、runnable Experiment/admission、runtime cacheは作成していない。

## 資源の限定観測と配置案

2026-10-14T02:54Zの一回のread-only観測: 10physical cores／20logical CPUs（0/1、2/3、4/5…18/19が各siblings）。RAM MemAvailable17217524KiB、swap未使用。GPU index0 RTX3060、driver591.86、total12288MiB、used1394MiB、free10715MiB、util0、compute-app list空。GPU/model/library初期化、timing/forward/probeをしていない。共有venvはregular Python3.14.7の既存project entryで、installed METADATAはnumpy2.5.3、torch2.14.0+cu130、CUDA runtime13.0.96、onnxruntime1.30.0。これらはmetadata事実であり、ABI/kernel/学習resident/性能の再資格ではない。

生成2workerをCPU0/2、guardian4、reserve6とする未選択配置なら4distinct physical cores。sourceCPU3はCPU2と同coreなので同時計測/生成に使わずsource停止を優先する。learner hostCPU8/guardian10、single GPU index0、familyRAM8GiB incl controller64MiB、hostreserve4GiB、GPU envelope6GiB案。現configure_frameworkのallocator ceilingは5GiB（提案6GiBを無断変更する話ではない）。全core選択はactual future affinity/physical/fair peer検査が必要。generation→materialize→learner→timed arenaは直列にし、Cargo/Perf/大IOやshared env mutationを重ねない。今の空きは未来quietではなく、lease/環境の予約を持たない。

## 保存量と未発行支持

dated covered observationは2026-10-11 allocated24161214464B（24.161GB）。2026-10-13の381 directed postusageはsource1576960B、controls7888896B、2private artifacts10375168B、shared target1511092224B。前者3つの対象とshared targetの保持scopeは異なり、target全額を新deltaとして足さない。Oct11から現在までの全増分、現global actual、continuous peaks、旧source/環境retirementの減少creditはUNKNOWN。旧49.99GB forecastはactual occupancyではない。RAW/model/failedを削除して容量を作っていない。

今回のasset-volume statvfs available508073684992BはFSの空きでありresearch allocation50GBの証明ではない。dated24.161GB+8GiB=32751149056B、50GBまで17248850944Bだが、未covered増分があるので現在8GiB支持の成立を保証しない。22GiB案ならdated合計47783534592B、余地2216465408Bにすぎず、現retentionが必要。繰り返すglobal/assets auditは行っていない。

whole8GiB案（RAW6GiB＋compact/config512MiB＋fit128MiB＋compilegrowth512MiB＋eval512MiB＋serial TMP/failure/review/Git384MiB）はbulk集計でありsubcap配分を発行していない。既存shared input/model/環境/targetは再copy・新規重複課金しない。16MiB/game\*1280=20GiBのworst-case detailに加え他工程があり、8GiBは完了保証でなく部分停止案。compression実測比をcapacity creditにしない。cache固定binaryは91B/row、243200行なら22131200B、その上にrow/family metadata・checkpoints/curves・capture・一時overlapが乗る。

mixture.output_limit_bytes=128MiBはfit-local guardで、全工程8GiB guardではない。科学委任後のactual bulk支持と、既存Limits.owned_Bが数えるnew outputs/control/TMP unionを一貫してbindするのは324。既存retained holdings/shared corpusをfresh出力として二重計上しない。空きreserve4GiBと実支持を起動時確認し、容量到達はFAILED/partial/remaining UNKNOWNと元fees/RAW/secondaryを保存して停止する。自動拡張/refill/削除はしない。

## 検証と限界

変更はOWNの提案/report/観測のみ。整形とcomplete配置のresolve_configを一度だけparserとして確認する。GPU、実new cache、generation、fit、candidate-native、arenaは未実行。既存381成功を再演せず、actual delegate、cap64/all、selector、whole8GiBの人間条件と実入力・後段binding・bulk支持が未成立であることを残す。323USERPAUSE/fits96/モデル/defaults/N/seals、旧FAILED/RAW/fees/UNKNOWNを維持する。
