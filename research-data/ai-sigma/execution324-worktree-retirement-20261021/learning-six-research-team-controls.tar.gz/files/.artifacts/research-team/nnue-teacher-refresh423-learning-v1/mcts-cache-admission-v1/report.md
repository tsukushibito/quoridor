# MCTS cache metadata admission delta

423.2の凍結source a56b3eba / f3bf8ac2に対する関連修復。`common_cache_config`だけを対象とし、既存Alpha source Content / rootmean contractと421のmodel-scale検査を維持する。Main / publisher / converter / runtime cacheは編集しない。

新producerの正本completion-v2 c4df42ddをhash-size-mode照合してから、必要な凍結postimageのmetadata記述だけを読む。現在の不足は、新しいMCTS sourceをAlphaのgzip-single-memberと偽らず受け入れる分岐。model / payload / history / NPZ / cacheの全decode、forward、fit、native、旧成功suiteは実行しない。

開始contextは2026-10-16T02:51:24.083Z、保存Sol6.1 / high / Main / danger-full-access / approvalPolicy never。最初のintake-v1は02:52:08.894106Z canonical NB EAGAINで子未入場。原拒否を保存し、holderを推測せず、自動再試行しない。actual共有release後のfresh guardで未実行部分だけを進める。

実421 D4のnative / collection / guard STOPを受け、再開context03:05:23.607Zに同じ設定を確認した。未読のcompletion-v2 c4df42dd / 5816、data-source-v2 binding f4247661 / 5558、そのterminal_cache.rs b2c9c829 / 37342とterminal_stream.rs b3a54916 / 61205をhash-size-mode照合し、必要なmetadata記述だけを抽出してbefore / after一致を確認した。RustのC1 canonical game IDとC2 fixture edge修復は別作者の対象であり、Python側で不正fixtureを許容する変更は加えない。

MCTSのsource_contentは`{encoding:"native-teacher-dataset-shards-v1",manifest:BoundJson}`、source_bindingは各datasetの`manifest.json`参照。`mcts_datasets`は同順のdataset path / manifest SHA / 実rows。`mcts_source`はmodel SHA / completed simulationsを保持する。`mcts_native_configs`はordered BoundJson配列を保存した**ファイルのBoundJson**であって配列そのものではなく、dataset_shaはそのファイルのSHAである。元Alphaのordered binding array hashをMCTSに適用しない。

分岐はMCTS専用3fieldの部分集合が現れた場合の不完全metadataを拒否する。rootmean_is_rawはMCTSでtrue、Alphaでfalseを厳密に要求する。MCTS側はsource / binding / dataset manifestの対応、dataset合計rows、same-length列と連続batch union、正のu32 simulation数、lowercase SHA、absolute refs、native-config-list SHAを検査する。batch configの本文や一覧ファイル、dataset bodyを再読してnative出版時の正本検査を二重実装しない。列を同時に一貫して改変した偽manifestまでこのmetadata-only関数だけで再資格化するとは主張せず、実cache FileRefと正規入場の束縛が必要である。

共通のz eligibility / census / schedule / partition検査と421 initializer-scale検査は維持する。Alphaの既存source loopはelse側へそのまま移すだけで、scope外のwarmstart / model / sampling / train / finalizerを変更しない。MCTSのraw root meanをz教師として扱わない。データのみのreadはfit許可ではなく、既存public_replay.admitの実cache / initializer / scale binding要件はそのままである。将来runtime refsとfinal fit-viewは未生成のまま。

prepare-delta-v1は03:07:15.275691Z canonical NB EAGAIN、子未入場でpostimage未生成。原拒否と既存sourceを保持して通常のactual releaseを324へ依頼した。独立のprivate test / proof sourceだけを準備し、NN0・formatter・差分検証の成功を先取りしていない。

## 実確認と引渡し

Rootのidentity native / collection actualSTOP03:18:24.342265Zを受け、context03:31:15.659ZのSol6.1 / high / Main / fullneverを確認し、未実行deltaをprepare-delta-v2で生成した。前のEAGAINは原FAILED / childnullのまま保持し、成功へ書き換えていない。

新規`MctsCacheAdmissionNN0`の4定義を一度だけ実行し、全PASS、実STOP03:31:35.359617Z。実モデル / forward / Torch / NumPy / corpus body読取は0、旧423の10定義・421・381・native・parity等の再演は0。metadata-only関数のsource body読取を拒否するmockも付け、単なる見掛けの参照にせず実関数の戻りと拒否を確認した。fake metadataのhashやpathはtoyであり、将来cacheやmodelのFileRefではない。

4定義は、(1) 正規MCTS metadataを本文readなしに受理、(2) 不完全mode・不正model / sims / config-list参照・Alphaとの偽装混在を拒否、(3) dataset manifestの対応・行数・重複・順序・batch unionの不一致を拒否、(4) Alpha経路と両modeの既存尺度検査を保持、を対象とする。nonstrictなfixtureに合わせて検査を弱めていない。

`proof-v1`は03:31:40.034059ZにPASS。差分は凍結common e5dc86b5の`common_cache_config`一関数と新規metadata testだけ。元Alpha loop bodyのAST、元model_scale_authority検査のBYTE / AST、元batch cursor末尾AST、関数外BYTE / ASTが一致した。GNU patch zero-fuzz forward / reverseでexact post / beforeを復元し、TMPを除去した。元423 packet / accepted421 admission / F親consumer・runtime refsは変更していない。

新testの意図するmaintained pathは`python/quoridor_training/test_mcts_cache_admission.py`。Rootは元423 sourceの後へこのthin deltaを合成する。作者がMainへ直接適用したものではなく、cache / pilot / fit / nativeの資格結果や実科学の成功ではない。related限定確認・Main採用・必要な実runtime refsはRoot所有。source-only packetと実STOP / 費 / 元拒否はbindingに保存する。

最終check-v1は03:32:55.411227Z NB拒否、続くPrettier config-intakeも03:38:21.278998Z子未入場で拒否され、原記録を保持した。Rootのactual release03:36:05.984052Zと私有処理のlock範囲整理指示に従い、OWN wrapperにprivate-onlyを加えた。これは既存physical / family-memory / CPU / capture / directwait / cleanupを維持し、私有formatterの全実行時間にMain canonicalを保持しない変更だけ。通常のMain / producer intakeは従来のcanonical付き経路を保持する。新しいlock / monitor / guard frameworkは作らない。

Ruffは03:37:35.280053Zの短いcanonical intakeで実project設定71B / SHA134db010を凍結して使った。reportのPrettierは私有の空設定とno-editorconfigで通常defaultsを明示し、Main設定の再探索をしない。元のconfig探索commandは未入場であり、project全域に設定がないと資格化したものではない。コードのproject Ruff format / check / no-cache lintと、report整形・check、元frozen423 result / source / common refsのbefore / after exactはfinal-checks-v2でPASSし、03:39:12.508492Zに実停止した。4定義の再演は0。
