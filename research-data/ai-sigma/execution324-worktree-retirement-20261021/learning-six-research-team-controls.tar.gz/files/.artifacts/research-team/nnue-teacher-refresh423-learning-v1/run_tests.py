"""Only new private derivative tests; model/Torch calls remain synthetic."""

import importlib.util
import hashlib
import json
from pathlib import Path
import sys
import unittest

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "python"))
import quoridor_training

for name in ("common", "sampling", "public_replay"):
    spec = importlib.util.spec_from_file_location("quoridor_training." + name, OWN / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    setattr(quoridor_training, name, module)
spec = importlib.util.spec_from_file_location(
    "teacher_refresh_nn0", OWN / "test_teacher_refresh_inputs.py"
)
tests = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = tests
spec.loader.exec_module(tests)
names = sys.argv[1:] or unittest.defaultTestLoader.getTestCaseNames(tests.TeacherRefreshInputsNN0)
suite = unittest.TestSuite(tests.TeacherRefreshInputsNN0(name) for name in names)
result = unittest.TextTestRunner(verbosity=2).run(suite)
facts = {
    "test_filters": names,
    "tests_run": result.testsRun,
    "failures": len(result.failures),
    "errors": len(result.errors),
    "real_torch_imported": "torch" in sys.modules,
    "real_model_forward_rows": 0,
    "labelled_fake_forward_rows": tests.FAKE_ROWS,
    "old_test_methods_run": 0,
}
suffix = "all" if len(sys.argv) == 1 else hashlib.sha256("\n".join(names).encode()).hexdigest()[:16]
output = OWN / ("nn0-result-" + suffix + ".json")
with output.open("x") as stream:
    json.dump(facts, stream, indent=2)
    stream.write("\n")
print(json.dumps(facts))
sys.exit(0 if result.wasSuccessful() and not facts["real_torch_imported"] else 1)
