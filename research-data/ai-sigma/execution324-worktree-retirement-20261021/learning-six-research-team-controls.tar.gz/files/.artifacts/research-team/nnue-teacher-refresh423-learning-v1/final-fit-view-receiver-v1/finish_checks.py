"""Finish scoped source/doc checks without replaying any NN0 definition."""

import json
from pathlib import Path
import subprocess
import sys

OWN = Path(__file__).resolve().parent
files = [
    str(OWN / (name + ".py"))
    for name in ("common", "test_final_fit_view", "prove", "finish_checks", "collect_metadata")
]
config = str(OWN / "ruff.project.toml")
commands = [
    [
        sys.executable,
        "-B",
        "-m",
        "ruff",
        "format",
        "--no-cache",
        "--config",
        config,
        str(OWN / "finish_checks.py"),
        str(OWN / "collect_metadata.py"),
    ],
    [
        sys.executable,
        "-B",
        "-m",
        "ruff",
        "format",
        "--check",
        "--no-cache",
        "--config",
        config,
        *files,
    ],
    [sys.executable, "-B", "-m", "ruff", "check", "--no-cache", "--config", config, *files],
    [
        "/home/vscode/.local/bin/node",
        "tools/research-quality/node_modules/prettier/bin/prettier.cjs",
        "--config",
        str(OWN / "prettier.private.json"),
        "--no-editorconfig",
        "--write",
        str(OWN / "report.md"),
    ],
    [
        "/home/vscode/.local/bin/node",
        "tools/research-quality/node_modules/prettier/bin/prettier.cjs",
        "--config",
        str(OWN / "prettier.private.json"),
        "--no-editorconfig",
        "--check",
        str(OWN / "report.md"),
    ],
]
captures = []
for command in commands:
    r = subprocess.run(command, capture_output=True, text=True)
    captures.append(
        {"argv": command, "exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr}
    )
    print(r.stdout, end="")
    print(r.stderr, end="", file=sys.stderr)
    if r.returncode:
        (OWN / "finish-failure.json").write_text(json.dumps(captures, indent=2) + "\n")
        raise RuntimeError("scoped final source check failed")
(OWN / "finish-checks.json").write_text(
    json.dumps(
        {
            "captures": captures,
            "new_tests_replayed": 0,
            "real_model_forwards": 0,
            "Main_source_reads": 0,
            "Ruff_configuration": "actual project71B snapshot; formatter/checks no-cache",
            "report_format": "explicit Prettier defaults/no-editorconfig",
        },
        indent=2,
    )
    + "\n"
)
print("scoped format/lint/docs PASS; no new runtime work")
