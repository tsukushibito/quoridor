"""Sparse current-source patch with explicit owner and unchanged-finalizer proof."""

import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import tempfile

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent


def reference(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


def function(tree, path):
    body = tree.body
    for name in path.split("."):
        node = next(
            n for n in body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name == name
        )
        body = node.body
    return node


def replace_owners(before, after, owners):
    old_tree, new_tree = ast.parse(before), ast.parse(after)
    lines = after.decode().splitlines(True)
    for name in sorted(owners, key=lambda n: function(new_tree, n).lineno, reverse=True):
        old, new = function(old_tree, name), function(new_tree, name)
        old_lines = before.decode().splitlines(True)
        lines[new.lineno - 1 : new.end_lineno] = old_lines[old.lineno - 1 : old.end_lineno]
    return "".join(lines)


owners = {
    "common": ["validate_mixed_config", "validate_mixture_config", "warmstart_model_inputs"],
    "public_replay": ["planned_work", "Selector.observe", "admit", "train_mixture"],
}
evidence = {}
patch_text = []
old_sources = {}
for name in ("common", "public_replay", "sampling"):
    before = gzip.decompress((OWN / (name + ".before.py.gz")).read_bytes())
    after = (OWN / (name + ".py")).read_bytes()
    old_sources[name] = before
    restored = replace_owners(before, after, owners.get(name, []))
    if name == "common":
        anchor = 'DEFAULTS["mixture"] = dict.fromkeys(MIXTURE_FIELDS)\n'
        start = restored.index(anchor) + len(anchor)
        old = before.decode()
        old_start = old.index(anchor) + len(anchor)
        restored = (
            restored[:start]
            + old[old_start : old.index("STEP_MODEL_DEFAULTS")]
            + restored[restored.index("STEP_MODEL_DEFAULTS") :]
        )
    elif name == "public_replay":
        start = restored.index("def public_observation_policy(")
        end = restored.index("def planned_work(")
        restored = restored[:start] + restored[end:]
        old_function = function(ast.parse(before), "train_mixture")
        new_function = function(ast.parse(after), "train_mixture")
        # The cleanup/action ordering and LAST UNKNOWN/primary-secondary semantics
        # remain the original owning implementation.
        old_try = next(n for n in old_function.body if isinstance(n, ast.Try))
        new_try = next(n for n in new_function.body if isinstance(n, ast.Try))
        assert ast.dump(ast.Module(body=old_try.finalbody, type_ignores=[])) == ast.dump(
            ast.Module(body=new_try.finalbody, type_ignores=[])
        )
        old_lines = before.decode().splitlines(True)
        new_lines = after.decode().splitlines(True)
        assert "".join(
            old_lines[old_try.finalbody[0].lineno - 1 : old_try.finalbody[-1].end_lineno]
        ) == "".join(new_lines[new_try.finalbody[0].lineno - 1 : new_try.finalbody[-1].end_lineno])
        for nested in ("forward", "save_checkpoint"):
            old = next(
                n for n in old_function.body if isinstance(n, ast.FunctionDef) and n.name == nested
            )
            new = next(
                n for n in new_function.body if isinstance(n, ast.FunctionDef) and n.name == nested
            )
            assert ast.dump(old) == ast.dump(new)
            assert ast.get_source_segment(before.decode(), old) == ast.get_source_segment(
                after.decode(), new
            )
    else:
        assert after.startswith(before), "sampling original bytes must remain complete prefix"
        tree = ast.parse(after)
        tree.body = [
            n
            for n in tree.body
            if not (isinstance(n, ast.FunctionDef) and n.name == "indexed_public_sample")
        ]
        assert ast.dump(tree) == ast.dump(ast.parse(before))
        restored = before.decode()
    assert restored.encode() == before, "outside-owner bytes changed: " + name
    assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse(before))
    target = "python/quoridor_training/" + name + ".py"
    patch_text.extend(
        difflib.unified_diff(
            before.decode().splitlines(True),
            after.decode().splitlines(True),
            fromfile="a/" + target,
            tofile="b/" + target,
        )
    )
    evidence[target] = {
        "after": reference(OWN / (name + ".py")),
        "outside_declared_owners_BYTE_AST_exact": True,
        "changed_existing_owners": owners.get(name, []),
        "before_gzip": reference(OWN / (name + ".before.py.gz")),
    }

target = "python/quoridor_training/test_teacher_refresh_inputs.py"
assert not (ROOT / target).exists()
patch_text.extend(
    difflib.unified_diff(
        [],
        (OWN / "test_teacher_refresh_inputs.py").read_text().splitlines(True),
        fromfile="/dev/null",
        tofile="b/" + target,
    )
)
(OWN / "source.patch").write_text("".join(patch_text))
captures = []
with tempfile.TemporaryDirectory(prefix="patch-recovery-", dir=OWN) as directory:
    stage = Path(directory)
    for name, raw in old_sources.items():
        p = stage / "python/quoridor_training" / (name + ".py")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(raw)
    for inverse in (False, True):
        argv = ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(OWN / "source.patch")]
        if inverse:
            argv.append("-R")
        result = subprocess.run(argv, cwd=stage, capture_output=True, text=True, check=True)
        captures.append(
            {
                "argv": argv,
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
        )
        for name, before in old_sources.items():
            actual = (stage / "python/quoridor_training" / (name + ".py")).read_bytes()
            assert actual == (before if inverse else (OWN / (name + ".py")).read_bytes())
        if inverse:
            assert not (stage / target).exists()
        else:
            assert (stage / target).read_bytes() == (
                OWN / "test_teacher_refresh_inputs.py"
            ).read_bytes()
(OWN / "static-proof.json").write_text(
    json.dumps(
        {
            "source_owners": evidence,
            "explicit_module_insertions": {
                "common": ["MIXTURE_OPTIONS", "DEFAULTS mixture options"],
                "public_replay": ["public_observation_policy", "initial_observation_scopes"],
                "sampling": ["indexed_public_sample"],
            },
            "public_replay_finally_BYTE_AST_exact": True,
            "original_forward_and_checkpoint_export_BYTE_AST_exact": True,
            "strict_forward_inverse": captures,
            "new_test_target": target,
            "new_test_previously_absent": True,
            "new_test": reference(OWN / "test_teacher_refresh_inputs.py"),
            "recovery_TMP_removed": True,
        },
        indent=2,
    )
    + "\n"
)
print("outside-owner BYTE/AST, preserved finalizer/forward/export and strict patch recovery: PASS")
