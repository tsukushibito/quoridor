def common_cache_config(manifest):
    """Typed published outcome-cache lineage; no study/plan or raw-range selector."""
    mcts_fields = {"mcts_source", "mcts_datasets", "mcts_native_configs"}
    mcts = bool(mcts_fields.intersection(manifest))
    if mcts and not mcts_fields.issubset(manifest):
        raise ValueError("complete MCTS source metadata required")
    c = manifest["common_corpus"]
    cfg = c["config"]
    fields = {
        "families",
        "prefix_seed",
        "prefix_lengths",
        "split_seed",
        "root_value_policy",
        "schedule",
        "partition",
        "batch_start",
        "batch_count",
        "excluded_books",
    }

    def bound_json_ref(value):
        return (
            isinstance(value, dict)
            and set(value) == {"path", "sha256"}
            and isinstance(value["path"], str)
            and bool(value["path"])
            and isinstance(value["sha256"], str)
            and len(value["sha256"]) == 64
            and all(ch in "0123456789abcdef" for ch in value["sha256"])
        )

    if (
        manifest["schema"] != "quoridor-common-corpus-terminal-geometry-v3"
        or set(cfg) != fields
        or type(cfg["families"]) is not int
        or cfg["families"] <= 0
        or any(
            type(cfg[k]) is not int or not 0 <= cfg[k] < 2**64
            for k in ("prefix_seed", "split_seed")
        )
        or not isinstance(cfg["prefix_lengths"], list)
        or not cfg["prefix_lengths"]
        or any(type(v) is not int or not 0 < v < 200 for v in cfg["prefix_lengths"])
        or len(cfg["prefix_lengths"]) != len(set(cfg["prefix_lengths"]))
        or cfg["root_value_policy"] != "outcome_only"
        or any(not bound_json_ref(cfg[k]) for k in ("schedule", "partition"))
        or not isinstance(cfg["excluded_books"], list)
        or any(not bound_json_ref(ref) for ref in cfg["excluded_books"])
        or any(type(cfg[k]) is not int or cfg[k] < 0 for k in ("batch_start", "batch_count"))
        or cfg["batch_count"] <= 0
        or cfg["batch_start"] + cfg["batch_count"] > cfg["families"]
        or c["planned_families"] != cfg["families"]
        or c["raw_file"] != "completed-root-raw.f32"
        or c["common_mask_file"] != "common-eligible.u8"
        or c["sampling_file"] != "sampling.bin"
        or c["teacher_A"] != "actual_final_z"
        or c["rootmean_is_raw"] is not mcts
        or type(manifest["rows"]) is not int
        or manifest["rows"] < 0
        or type(c["common_eligible_rows"]) is not int
        or not 0 <= c["common_eligible_rows"] <= manifest["rows"]
    ):
        raise ValueError("published configured outcome/raw/sampling contract")
    counts = c["common_eligible_by_split"]
    if (
        set(counts) != {"train", "validation"}
        or any(type(v) is not int or v < 0 for v in counts.values())
        or sum(counts.values()) != c["common_eligible_rows"]
    ):
        raise ValueError("literal outcome T/V eligible census")

    def digest(value):
        return (
            isinstance(value, str)
            and len(value) == 64
            and all(v in "0123456789abcdef" for v in value)
        )

    if "model_scale_authority" in manifest:
        authority = manifest["model_scale_authority"]
        if (
            not isinstance(authority, dict)
            or set(authority)
            != {
                "starting_weights_sha256",
                "descriptor_sha256",
                "evaluator_sha256",
                "scale_policy",
            }
            or any(
                not digest(authority[k])
                for k in (
                    "starting_weights_sha256",
                    "descriptor_sha256",
                    "evaluator_sha256",
                )
            )
            or authority["scale_policy"] != "incumbent_descriptor_T_only"
        ):
            raise ValueError("published initializer/frozen scale authority")
    intake = manifest["stream_intake"]
    sources, bindings = manifest["source_content"], manifest["source_binding"]
    if (
        intake["status"] != "complete"
        or intake["scope"] != "common-corpus"
        or intake["publication_protocol"] != "incomplete-marker-last-v1"
        or manifest["schedule_sha256"] != cfg["schedule"]["sha256"]
        or manifest["family_partition_sha256"] != cfg["partition"]["sha256"]
        or not digest(manifest["dataset_sha"])
        or not isinstance(sources, list)
        or not sources
        or not isinstance(bindings, list)
        or len(bindings) != len(sources)
        or len(intake["batches"]) != len(sources)
    ):
        raise ValueError("published complete ordered source/global schedule/partition lineage")
    if mcts:
        model, datasets, configs = (
            manifest["mcts_source"],
            manifest["mcts_datasets"],
            manifest["mcts_native_configs"],
        )
        if (
            not isinstance(model, dict)
            or set(model) != {"model_sha256", "completed_simulations"}
            or not digest(model["model_sha256"])
            or type(model["completed_simulations"]) is not int
            or not 0 < model["completed_simulations"] < 2**32
            or not bound_json_ref(configs)
            or not Path(configs["path"]).is_absolute()
            or configs["sha256"] != manifest["dataset_sha"]
            or not isinstance(datasets, list)
            or len(datasets) != len(sources)
        ):
            raise ValueError("published MCTS model/simulations/ordered native config lineage")
        if (
            any(
                not isinstance(dataset, dict)
                or set(dataset) != {"dataset", "manifest_sha256", "rows"}
                or not isinstance(dataset["dataset"], str)
                or not Path(dataset["dataset"]).is_absolute()
                or not digest(dataset["manifest_sha256"])
                or type(dataset["rows"]) is not int
                or dataset["rows"] < 0
                for dataset in datasets
            )
            or sum(dataset["rows"] for dataset in datasets) != manifest["rows"]
        ):
            raise ValueError("published MCTS dataset manifest/row census")
    seen, cursor = set(), cfg["batch_start"]
    for source, binding, batch in zip(sources, bindings, intake["batches"]):
        if mcts:
            dataset = datasets[len(seen)]
            if (
                not isinstance(source, dict)
                or set(source) != {"encoding", "manifest"}
                or source["encoding"] != "native-teacher-dataset-shards-v1"
                or not bound_json_ref(binding)
                or not Path(binding["path"]).is_absolute()
                or source["manifest"] != binding
                or binding
                != {
                    "path": str(Path(dataset["dataset"]) / "manifest.json"),
                    "sha256": dataset["manifest_sha256"],
                }
                or binding["path"] in seen
                or set(batch) != {"batch_start", "batch_count", "config"}
                or type(batch["batch_start"]) is not int
                or batch["batch_start"] != cursor
                or type(batch["batch_count"]) is not int
                or batch["batch_count"] <= 0
                or not bound_json_ref(batch["config"])
                or not Path(batch["config"]["path"]).is_absolute()
            ):
                raise ValueError("ordered MCTS source manifest/configured batch interval")
        else:
            compressed = source["compressed"]
            if (
                set(source) != {"encoding", "compressed", "raw_sha256", "raw_bytes"}
                or source["encoding"] != "gzip-single-member-v1"
                or set(compressed) != {"path", "sha256", "bytes", "mode"}
                or not bound_json_ref(binding)
                or not Path(binding["path"]).is_absolute()
                or binding != {"path": compressed["path"], "sha256": compressed["sha256"]}
                or binding["path"] in seen
                or type(compressed["bytes"]) is not int
                or compressed["bytes"] <= 0
                or compressed["mode"] not in ("0600", "0644")
                or not digest(source["raw_sha256"])
                or type(source["raw_bytes"]) is not int
                or source["raw_bytes"] <= 0
                or set(batch) != {"batch_start", "batch_count", "config"}
                or type(batch["batch_start"]) is not int
                or batch["batch_start"] != cursor
                or type(batch["batch_count"]) is not int
                or batch["batch_count"] <= 0
                or not bound_json_ref(batch["config"])
            ):
                raise ValueError("ordered disjoint source Content/configured batch interval")
        seen.add(binding["path"])
        cursor += batch["batch_count"]
    if cursor != cfg["batch_start"] + cfg["batch_count"]:
        raise ValueError("actual batch union does not cover published interval")
    if "input_binding" in manifest or "final_fit_view" in manifest:
        # Only small SHA-bound metadata is opened here, never datasets/rows.
        metadata, metadata_bytes = {}, 0

        def metadata_identity(info):
            return (
                info.st_dev,
                info.st_ino,
                info.st_mode,
                info.st_size,
                info.st_mtime_ns,
                info.st_ctime_ns,
            )

        def read_metadata(reference, limit=1048576):
            nonlocal metadata_bytes
            if not bound_json_ref(reference) or not Path(reference["path"]).is_absolute():
                raise ValueError("absolute SHA-bound fit-view metadata required")
            key = (reference["path"], reference["sha256"])
            if key not in metadata:
                path = Path(reference["path"])
                info = path.lstat()
                if (
                    not stat.S_ISREG(info.st_mode)
                    or not 0 < info.st_size <= limit
                    or metadata_bytes + info.st_size > 16777216
                ):
                    raise ValueError("bounded regular fit-view metadata required")
                raw = path.read_bytes()
                if (
                    len(raw) != info.st_size
                    or hashlib.sha256(raw).hexdigest() != reference["sha256"]
                    or metadata_identity(path.lstat()) != metadata_identity(info)
                ):
                    raise ValueError("fit-view metadata SHA/identity drift")
                metadata_bytes += len(raw)
                metadata[key] = (json.loads(raw), info)
            return metadata[key][0]

        def exact(left, right):
            return json.dumps(left, sort_keys=True) == json.dumps(right, sort_keys=True)

        def prefix(value):
            return isinstance(value, list) and all(
                type(action) is int and 0 <= action < 65536 for action in value
            )

        def input_assignments(config):
            schedule = read_metadata(config["schedule"], 4194304)
            partition = read_metadata(config["partition"], 4194304)
            slots = schedule["scheduled"]
            assigned = partition["assignments"]
            if (
                not isinstance(slots, list)
                or len(slots) != config["families"]
                or not isinstance(assigned, list)
                or len(assigned) != config["families"]
                or partition["schema"] != "quoridor-terminal-family-partition-v1"
                or type(partition["seed"]) is not int
                or partition["seed"] != config["split_seed"]
                or not isinstance(partition["rounding"], str)
                or not partition["rounding"]
            ):
                raise ValueError("fit-view bound schedule/partition denominator or seed")
            family_splits = {}
            for index, (slot, assignment) in enumerate(zip(slots, assigned)):
                request = f"fixed-d-family-{index:06}"
                length = config["prefix_lengths"][index % len(config["prefix_lengths"])]
                if (
                    type(slot["game"]) is not int
                    or slot["game"] != index
                    or slot["request_id"] != request
                    or type(slot["requested_prefix_length"]) is not int
                    or slot["requested_prefix_length"] != length
                    or not prefix(slot["prefix"])
                    or len(slot["prefix"]) != length
                    or slot.get("scheduled_failure") is not None
                    or set(assignment) != {"game", "family", "prefix", "split"}
                    or assignment["game"] != request
                    or not digest(assignment["family"])
                    or not prefix(assignment["prefix"])
                    or assignment["prefix"] != slot["prefix"]
                    or assignment["split"] not in ("train", "validation")
                    or family_splits.setdefault(assignment["family"], assignment["split"])
                    != assignment["split"]
                ):
                    raise ValueError("fit-view canonical request/prefix/family/split metadata")
            return assigned, partition["rounding"]

        inlet = read_metadata(manifest["input_binding"]) if "input_binding" in manifest else {}
        if not isinstance(inlet, dict):
            raise ValueError("fit-view input binding object required")
        has_view = "final_fit_view" in manifest
        if has_view != ("final_fit_view" in inlet):
            raise ValueError("manifest/input binding fit-view omission or conflict")
        if has_view:
            view = manifest["final_fit_view"]
            if (
                not mcts
                or not isinstance(view, dict)
                or set(view)
                != {"config", "scope", "realized_games", "changed_global_ids", "assignments"}
                or view["scope"] != "sampling-only-original-source-validated"
                or view["config"] != inlet["final_fit_view"]
                or "model_scale_authority" not in manifest
                or not exact(inlet.get("model_scale_authority"), manifest["model_scale_authority"])
                or not exact(read_metadata(view["config"]), cfg)
                or cfg["batch_start"] != 0
                or cfg["batch_count"] != cfg["families"]
                or type(view["realized_games"]) is not int
                or view["realized_games"] != cfg["families"]
                or not isinstance(view["assignments"], list)
                or len(view["assignments"]) != cfg["families"]
            ):
                raise ValueError("complete bound MCTS final sampling view/scale required")
            references = read_metadata(configs)
            if not exact(references, [batch["config"] for batch in intake["batches"]]):
                raise ValueError("ordered original native configs differ from source batches")
            final, rounding = input_assignments(cfg)
            expected, changed = [], []
            varying = {"families", "schedule", "partition", "batch_start", "batch_count"}
            for source_index, (reference, batch, dataset) in enumerate(
                zip(references, intake["batches"], datasets)
            ):
                native = read_metadata(reference)
                original = native["common_study"]
                if (
                    not isinstance(original, dict)
                    or set(original) != fields
                    or not exact(
                        {k: v for k, v in original.items() if k not in varying},
                        {k: v for k, v in cfg.items() if k not in varying},
                    )
                    or type(original["families"]) is not int
                    or not 0 < original["families"] <= cfg["families"]
                    or type(original["batch_start"]) is not int
                    or type(original["batch_count"]) is not int
                    or original["batch_start"] != batch["batch_start"]
                    or original["batch_count"] != batch["batch_count"]
                    or original["batch_start"] + original["batch_count"] > original["families"]
                    or type(native["simulations"]) is not int
                    or native["simulations"] != model["completed_simulations"]
                    or native["inference"]["model_sha"] != model["model_sha256"]
                    or not isinstance(native["output"], str)
                    or not Path(native["output"]).is_absolute()
                    or str(Path(native["output"]) / "dataset") != dataset["dataset"]
                ):
                    raise ValueError(
                        "original source config/slice/model/output differs from fit view"
                    )
                original_assignments, original_rounding = input_assignments(original)
                if original_rounding != rounding:
                    raise ValueError("source/final partition convention differs")
                for index in range(
                    original["batch_start"], original["batch_start"] + original["batch_count"]
                ):
                    old, new = original_assignments[index], final[index]
                    if (
                        old["game"] != new["game"]
                        or old["family"] != new["family"]
                        or old["prefix"] != new["prefix"]
                    ):
                        raise ValueError("source/final request/prefix/family differs")
                    expected.append(
                        {
                            "global_id": index,
                            "game": f"game-{index}",
                            "request_id": old["game"],
                            "source_index": source_index,
                            "family": old["family"],
                            "prefix": old["prefix"],
                            "source_split": old["split"],
                            "view_split": new["split"],
                        }
                    )
                    if old["split"] != new["split"]:
                        changed.append(index)
            if not exact(view["assignments"], expected) or not exact(
                view["changed_global_ids"], changed
            ):
                raise ValueError("exact ordered realized fit-view assignment/change correspondence")
            sampling = manifest["sampling"]
            families, codes = [], {}
            for assignment in expected:
                family = assignment["family"]
                if family not in codes:
                    codes[family] = len(families)
                    families.append(
                        {
                            "family": family,
                            "game": assignment["game"],
                            "split": assignment["view_split"],
                        }
                    )
            if not exact(sampling["families"], families) or len(sampling["games"]) != len(expected):
                raise ValueError("final sampling family/realized game census differs")
            rows, split_rows = [0] * len(families), {"train": 0, "validation": 0}
            source_rows = [0] * len(datasets)
            cursor = 0
            for assignment, game in zip(expected, sampling["games"]):
                code = codes[assignment["family"]]
                if (
                    type(game["rows"]) is not int
                    or not 0 < game["rows"] <= 200
                    or not exact(
                        game,
                        {
                            "game": assignment["game"],
                            "family_code": code,
                            "start": cursor,
                            "rows": game["rows"],
                        },
                    )
                ):
                    raise ValueError("final sampling game identity/code/chronological range")
                rows[code] += game["rows"]
                source_rows[assignment["source_index"]] += game["rows"]
                cursor += game["rows"]
            eligible = sampling["common_eligible_by_family"]
            if (
                cursor != manifest["rows"]
                or not exact(source_rows, [d["rows"] for d in datasets])
                or not exact(sampling["rows_by_family"], rows)
                or not isinstance(eligible, list)
                or len(eligible) != len(rows)
            ):
                raise ValueError("final sampling row/family census differs")
            for family, count, total in zip(families, eligible, rows):
                if type(count) is not int or not 0 <= count <= total:
                    raise ValueError("final sampling eligible family count")
                split_rows[family["split"]] += count
            if split_rows != counts:
                raise ValueError("final sampling eligible split census differs")
        # Normal caller inputs protect these metadata identities for its lifetime;
        # check every opened body again before returning this admission result.
        for (path, sha), (_, info) in metadata.items():
            path = Path(path)
            if (
                metadata_identity(path.lstat()) != metadata_identity(info)
                or hashlib.sha256(path.read_bytes()).hexdigest() != sha
            ):
                raise ValueError("fit-view metadata changed during admission")
    return cfg
