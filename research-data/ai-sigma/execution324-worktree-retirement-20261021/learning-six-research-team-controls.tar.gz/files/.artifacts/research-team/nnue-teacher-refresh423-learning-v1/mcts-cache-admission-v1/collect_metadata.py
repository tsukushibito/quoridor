"""Save stopped source receipt metadata; no Main, model or dataset body access."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat

OWN = Path(__file__).resolve().parent


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


def write(name, value):
    with (OWN / name).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
children, controllers, receipts, failures, walls = [], [], [], [], []
for path in sorted(OWN.glob("*.returned.json")):
    value = json.loads(path.read_bytes())
    name = path.name.removesuffix(".returned.json")
    disk_path = OWN / (name + ".guardian.process.json")
    disk = json.loads(disk_path.read_bytes()) if disk_path.exists() else None
    returned = value.get("returned")
    if disk:
        child = disk["child"]
        actual = None
        try:
            raw = (Path("/proc") / str(child["pid"]) / "stat").read_text()
            actual = {
                "pid": child["pid"],
                "start_ticks": raw[raw.rfind(")") + 2 :].split()[19],
                "boot_id": boot,
            }
        except FileNotFoundError:
            pass
        assert actual != child, child
        assert (
            disk["direct_child_reaped"]
            and disk["cleanup_complete"]
            and disk["handle_closes_complete"]
        )
        assert not disk["remaining"]
        children.append({"expected": child, "actual": actual, "original": "ABSENT_OR_DIFFERENT"})
        walls.append(
            {"name": name, "original_command_wall": disk["wall_seconds"], "scientific": False}
        )
    pid = value.get("controller_pid")
    if pid:
        assert not (Path("/proc") / str(pid)).exists(), pid
        controllers.append({"pid": pid, "actual_present": False, "start_ticks": "UNKNOWN"})
    receipts.append(
        {
            "returned": ref(path),
            "disk": ref(disk_path) if disk else None,
            "returned_mask_persist": {
                k: returned.get(k) if returned else None
                for k in ("signal_mask_restoration", "final_record_persist")
            },
            "disk_mask_persist": {
                k: disk.get(k) if disk else None
                for k in ("signal_mask_restoration", "final_record_persist")
            },
        }
    )
    if value.get("error") or (returned or {}).get("exit_code") != 0:
        failures.append(
            {
                "name": name,
                "error": value.get("error"),
                "returned": returned,
                "disk_exit": disk.get("exit_code") if disk else None,
            }
        )
tmp = [
    str(p)
    for p in OWN.iterdir()
    if p.is_dir() and (p.name.startswith("tmp") or p.name.startswith("delta-recovery-"))
]
assert not tmp
last = json.loads((OWN / "final-docs-v1.returned.json").read_bytes())
assert last["error"] is None and last["returned"]["exit_code"] == 0
write(
    "STOP.json",
    {
        "source_reader_writer_STOP": last["stopped_at"],
        "collection_observed_at": datetime.now(timezone.utc).isoformat(),
        "children": children,
        "controllers": controllers,
        "receipts": receipts,
        "owned": {
            k: [] for k in ("readers", "writers", "children", "jobs", "handles", "TMP", "leases")
        },
        "original_failed_preentries": failures,
        "original_command_walls_once": walls,
        "source_software_wall_sum": sum(r["original_command_wall"] for r in walls),
        "nested_controller_LLM_added": False,
        "peak_RSS": "UNKNOWN",
        "exact_worker_UTC_exit": "UNKNOWN",
        "real_model_forward_rows": 0,
    },
)
write(
    "source-binding.json",
    {
        "issue": "quoridor-4lc.423.2",
        "owner": "common_cache_config",
        "base_frozen_423_result": ref(OWN.parent / "result-binding.json"),
        "base_frozen_common": ref(OWN.parent / "common.py"),
        "post": ref(OWN / "common.py"),
        "owner_post": ref(OWN / "common_cache_config.after.py"),
        "owner_before_gzip": ref(OWN / "common_cache_config.before.py.gz"),
        "forward": ref(OWN / "source.patch"),
        "inverse": ref(OWN / "inverse.patch"),
        "proof": ref(OWN / "proof.json"),
        "checks": ref(OWN / "finish-checks.json"),
        "test": ref(OWN / "test_mcts_cache_admission.py"),
        "test_target": "python/quoridor_training/test_mcts_cache_admission.py",
        "producer_completion": ref(OWN / "producer-completion.json"),
        "producer_selected_binding": ref(OWN / "producer-binding.json"),
        "producer_metadata_refs_and_sections": ref(OWN / "producer-shapes.json"),
        "guard_private_scope_before_gzip": ref(OWN / "guard.before-private-scope.py.gz"),
        "guard_private_scope_post": ref(OWN / "guard.py"),
        "actual_Ruff_config_intake": ref(OWN / "format-config-refs.json"),
        "private_report_format_method": "Prettier explicit empty config/no-editorconfig; project config search preentry refused, not asserted absent",
        "new_definitions": 4,
        "new_definition_replays": 0,
        "real_forward_rows": 0,
        "original_Alpha_and_scale_and_outside_owner_exact": True,
        "future_runtime_refs": "NOT_CREATED",
    },
)
write(
    "result-binding.json",
    {
        "issue": "quoridor-4lc.423.2",
        "status": "STOPPED_RELATED_SOURCE_NN0_COMPLETE_ROOT_REVIEW_ADOPTION_PENDING",
        "source": ref(OWN / "source-binding.json"),
        "report": ref(OWN / "report.md"),
        "STOP": ref(OWN / "STOP.json"),
        "new_four_metadata_definitions": "PASS_ONCE",
        "actual_cache_pilot_fit_native_model": "NOT_RUN",
        "existing_frozen_423_packet_unchanged": True,
    },
)
write("affected-usage.json", {"allocated_bytes": 0})
seen, allocated = set(), 0
for root, dirs, files in os.walk(OWN):
    allocated += Path(root).stat().st_blocks * 512
    for name in files:
        s = (Path(root) / name).lstat()
        if (s.st_dev, s.st_ino) not in seen:
            seen.add((s.st_dev, s.st_ino))
            allocated += s.st_blocks * 512
with (OWN / "affected-usage.json").open("w") as stream:
    json.dump(
        {
            "scope": str(OWN),
            "allocated_bytes": allocated,
            "measurement": "once OWN dev/inode blocks including directories",
            "global_actual": "UNKNOWN",
            "old_asset_scan": False,
            "refund_or_grant": False,
        },
        stream,
        indent=2,
    )
    stream.write("\n")
print(
    json.dumps(
        {
            "result": ref(OWN / "result-binding.json"),
            "source": ref(OWN / "source-binding.json"),
            "STOP": ref(OWN / "STOP.json"),
            "affected_B": allocated,
            "metadata_helper_STOP": datetime.now(timezone.utc).isoformat(),
        }
    )
)
