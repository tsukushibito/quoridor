"""Collect this stopped private source packet; no payload, model or Main reads."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat

OWN = Path(__file__).resolve().parent


def stamp():
    return datetime.now(timezone.utc).isoformat()


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


def write(name, value):
    with (OWN / name).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
observations, receipts, failed, walls = [], [], [], []
for path in sorted(OWN.glob("*.returned.json")):
    record = json.loads(path.read_bytes())
    name = path.name.removesuffix(".returned.json")
    disk_path = OWN / (name + ".guardian.process.json")
    disk = json.loads(disk_path.read_bytes()) if disk_path.exists() else None
    returned = record.get("returned")
    evidence = {"returned": ref(path), "disk": ref(disk_path) if disk else None}
    if disk:
        child = disk["child"]
        proc = Path("/proc") / str(child["pid"]) / "stat"
        actual = None
        try:
            raw = proc.read_text()
            actual = {
                "pid": child["pid"],
                "start_ticks": raw[raw.rfind(")") + 2 :].split()[19],
                "boot_id": boot,
            }
        except FileNotFoundError:
            pass
        assert actual != child, ("original child still present", child)
        assert disk["direct_child_reaped"] is True
        assert disk["cleanup_complete"] is True and disk["remaining"] == []
        assert disk["handle_closes_complete"] is True
        observations.append(
            {"expected": child, "actual": actual, "original": "ABSENT_OR_DIFFERENT"}
        )
        walls.append({"command": name, "wall_seconds": disk["wall_seconds"], "scientific": False})
    controller = record.get("controller_pid")
    if controller:
        present = (Path("/proc") / str(controller)).exists()
        assert not present, ("controller PID present; exact identity not recorded", controller)
        observations.append(
            {
                "controller_pid": controller,
                "pid_present": False,
                "controller_start_ticks": "UNKNOWN",
            }
        )
    evidence["returned_cleanup"] = returned.get("cleanup_complete") if returned else None
    evidence["returned_mask_persist"] = {
        key: returned.get(key) if returned else None
        for key in ("signal_mask_restoration", "final_record_persist")
    }
    evidence["disk_mask_persist"] = {
        key: disk.get(key) if disk else None
        for key in ("signal_mask_restoration", "final_record_persist")
    }
    receipts.append(evidence)
    if record.get("error") or (returned or {}).get("exit_code") != 0:
        failed.append(
            {
                "name": name,
                "error": record.get("error"),
                "disk_exit_code": disk.get("exit_code") if disk else None,
            }
        )

tmp = [
    str(p)
    for p in OWN.iterdir()
    if p.is_dir() and (p.name.startswith("tmp") or p.name.startswith("patch-recovery-"))
]
assert not tmp, tmp
write(
    "source-binding.json",
    {
        "status": "STOPPED_SOURCE_AND_FAKE_NN0_READY_FOR_RELATED_BOUNDARY_REVIEW",
        "issue": "quoridor-4lc.423.2",
        "before": json.loads((OWN / "before-refs.json").read_bytes()),
        "postimages": {
            "python/quoridor_training/" + name: ref(OWN / name)
            for name in (
                "common.py",
                "public_replay.py",
                "sampling.py",
                "test_teacher_refresh_inputs.py",
            )
        },
        "patch": ref(OWN / "source.patch"),
        "proof": ref(OWN / "static-proof.json"),
        "scoped_checks": ref(OWN / "finish-checks.json"),
        "fixed_spec": json.loads((OWN / "fixed-spec-refs.json").read_bytes()),
        "recipe": ref(OWN / "settings.fixed-recipe.json"),
        "actual_config_materializer": ref(OWN / "prepare-configs.py"),
        "current_publisher_gap_fragments": ref(OWN / "parent-model-gap.json"),
        "production_train_changed": False,
        "compiler_native_real_model_tests": "UNRUN",
        "actual_runtime_configs_weights_Experiment": "NOT_CREATED",
        "review_question": "changed indexed file weighting, exact tail/cost scopes, descriptor-only fresh initialization, frozen-BEST and shared-INITIAL identity; preserve accepted421 cache authority and original finalizer",
    },
)
last = json.loads((OWN / "final-docs-v1.returned.json").read_bytes())
write(
    "STOP.json",
    {
        "source_reader_writer_STOP": last["stopped_at"],
        "collector_observed_at": stamp(),
        "known_identities": observations,
        "receipts": receipts,
        "directwait_reap_handles_TMP": "recorded original child receipts and fresh identities checked",
        "owned": {key: [] for key in ("readers", "writers", "children", "jobs", "TMP", "leases")},
        "canonical_lease": "guard context returned; none owned",
        "worker_exact_UTC_exit": "UNKNOWN",
        "peak_RSS": "UNKNOWN",
        "scientific_real_forward_rows": 0,
        "original_failed_commands_preserved": failed,
        "command_walls_once": walls,
        "command_walls_sum": sum(r["wall_seconds"] for r in walls),
        "controller_nested_admin_LLM_added": False,
    },
)
write(
    "result-binding.json",
    {
        "issue": "quoridor-4lc.423.2",
        "status": "SOURCE_FAKE_NN0_COMPLETE_PARENT_FRESH_INLET_CORRECTION_REQUIRED",
        "source": ref(OWN / "source-binding.json"),
        "report": ref(OWN / "report.md"),
        "recipe": ref(OWN / "settings.fixed-recipe.json"),
        "STOP": ref(OWN / "STOP.json"),
        "new_assertions_passed": 10,
        "new_definitions_in_success_commands": 9,
        "new_definition_assertion_pass_with_failed_result_publication": 1,
        "fake_forward_rows": 72,
        "real_model_forward_rows": 0,
        "old_suite_replays": 0,
        "original_9th_command_failed": ref(OWN / "nn0-configs-v1.returned.json"),
        "actual_science_launched": False,
        "remaining": [
            "Root fresh numerical_fields and experiment_check correspondence",
            "limited related boundary review and actual source adoption",
            "actual pilot and one-time final scale/cache/view",
            "actual four configs/inputs and normal entry",
        ],
        "owner_issue": "in_progress; Root acceptance pending",
    },
)
write("affected-usage.json", {"allocated_bytes": 0, "scope": str(OWN)})
seen, allocated = set(), 0
for root, dirs, files in os.walk(OWN):
    for name in files:
        s = (Path(root) / name).lstat()
        key = (s.st_dev, s.st_ino)
        if key not in seen:
            seen.add(key)
            allocated += s.st_blocks * 512
    s = Path(root).stat()
    allocated += s.st_blocks * 512
with (OWN / "affected-usage.json").open("w") as stream:
    json.dump(
        {
            "allocated_bytes": allocated,
            "scope": str(OWN),
            "measurement": "once directed OWN allocated dev/inode bytes including directories",
            "global_actual": "UNKNOWN",
            "old_asset_scan": False,
            "refund_or_grant": False,
        },
        stream,
        indent=2,
    )
    stream.write("\n")
print(
    json.dumps(
        {
            "binding": ref(OWN / "result-binding.json"),
            "STOP": ref(OWN / "STOP.json"),
            "affected_B": allocated,
            "admin_metadata_STOP": stamp(),
        }
    )
)
