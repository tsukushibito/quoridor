"""Record one stopped R1 packet, original receipts and directed OWN usage."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat

OWN = Path(__file__).resolve().parent


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


def save(name, value):
    with (OWN / name).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


children, controllers, receipts, walls, failures = [], [], [], [], []
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
for path in sorted(OWN.glob("*.returned.json")):
    record = json.loads(path.read_bytes())
    name = path.name.removesuffix(".returned.json")
    disk_path = OWN / (name + ".guardian.process.json")
    disk = json.loads(disk_path.read_bytes()) if disk_path.exists() else None
    returned = record.get("returned")
    if disk:
        child = disk["child"]
        actual = None
        try:
            raw = (Path("/proc") / str(child["pid"]) / "stat").read_text()
            actual = {
                "pid": child["pid"],
                "start_ticks": raw[raw.rfind(")") + 2 :].split()[19],
                "boot_id": boot,
            }
        except FileNotFoundError:
            pass
        assert actual != child, child
        assert (
            disk["direct_child_reaped"]
            and disk["cleanup_complete"]
            and disk["handle_closes_complete"]
            and not disk["remaining"]
        )
        children.append({"expected": child, "actual": actual, "original": "ABSENT_OR_DIFFERENT"})
        walls.append(
            {"name": name, "original_command_wall": disk["wall_seconds"], "scientific": False}
        )
    pid = record.get("controller_pid")
    if pid:
        assert not (Path("/proc") / str(pid)).exists(), pid
        controllers.append({"pid": pid, "present": False, "start_ticks": "UNKNOWN"})
    keys = ("signal_mask_restoration", "final_record_persist")
    receipts.append(
        {
            "returned": ref(path),
            "disk": ref(disk_path) if disk else None,
            "returned_mask_persist": {k: returned.get(k) if returned else None for k in keys},
            "disk_mask_persist": {k: disk.get(k) if disk else None for k in keys},
        }
    )
    if record.get("error") or (returned or {}).get("exit_code") != 0:
        failures.append(
            {
                "name": name,
                "error": record.get("error"),
                "disk_exit": disk.get("exit_code") if disk else None,
            }
        )
assert not [
    p
    for p in OWN.iterdir()
    if p.is_dir() and (p.name.startswith("tmp") or p.name.startswith("patch-recovery-"))
]
last = json.loads((OWN / "finish-checks-v1.returned.json").read_bytes())
assert last["error"] is None and last["returned"]["exit_code"] == 0
save(
    "STOP.json",
    {
        "private_source_reader_writer_STOP": last["stopped_at"],
        "collector_observed_at": datetime.now(timezone.utc).isoformat(),
        "known_children": children,
        "controllers": controllers,
        "receipts": receipts,
        "owned": {
            k: [] for k in ("readers", "writers", "children", "jobs", "handles", "TMP", "leases")
        },
        "original_failures": failures,
        "original_command_walls_once": walls,
        "source_software_wall_sum": sum(r["original_command_wall"] for r in walls),
        "nested_controller_admin_LLM_added": False,
        "exact_worker_UTC_exit": "UNKNOWN",
        "peak_RSS": "UNKNOWN",
        "real_model_forward_rows": 0,
    },
)
save(
    "source-binding.json",
    {
        "issue": "quoridor-4lc.423.2",
        "related_question": "R1 bounded actual metadata reads and per-role cache hits only",
        "base_source": ref(OWN.parent / "common.py"),
        "base_packet": ref(OWN.parent / "result-binding.json"),
        "post": ref(OWN / "common.py"),
        "forward": ref(OWN / "source.patch"),
        "inverse": ref(OWN / "inverse.patch"),
        "before_gzip": ref(OWN / "common.before.py.gz"),
        "proof": ref(OWN / "proof.json"),
        "checks": ref(OWN / "finish-checks.json"),
        "unchanged_old_test": ref(OWN.parent / "test_final_fit_view.py"),
        "new_test": ref(OWN / "test_final_fit_view_reads.py"),
        "new_test_target": "python/quoridor_training/test_final_fit_view_reads.py",
        "original_review": ref(OWN / "original-review.md"),
        "new_NN0_definitions": 3,
        "new_NN0_replays": 0,
        "old_test_methods_run": 0,
        "real_forward_rows": 0,
        "mapping_scale_no_view_Alpha_MCTS_and_other_owner_restored_BYTE_AST_exact": True,
        "native_model_build_qualifications": "unchanged original scopes; no replay",
        "new_runtime_refs": "NOT_CREATED",
    },
)
save(
    "result-binding.json",
    {
        "issue": "quoridor-4lc.423.2",
        "status": "STOPPED_R1_SOURCE_AND_NEW_NN0_COMPLETE_RELATED_CONFIRMATION_PENDING",
        "source": ref(OWN / "source-binding.json"),
        "report": ref(OWN / "report.md"),
        "STOP": ref(OWN / "STOP.json"),
        "new_metadata_tests": "3_PASS_ONCE",
        "old5_methods_replayed": 0,
        "native_model_forward_fit": 0,
        "original_d563_b285_review_failure_and_all_prior_receipts": "UNCHANGED",
    },
)
save("affected-usage.json", {"allocated_bytes": 0})
seen = set()
allocated = 0
for root, dirs, files in os.walk(OWN):
    allocated += Path(root).stat().st_blocks * 512
    for name in files:
        s = (Path(root) / name).lstat()
        if (s.st_dev, s.st_ino) not in seen:
            seen.add((s.st_dev, s.st_ino))
            allocated += s.st_blocks * 512
with (OWN / "affected-usage.json").open("w") as stream:
    json.dump(
        {
            "scope": str(OWN),
            "allocated_bytes": allocated,
            "measurement": "once OWN dev/inode blocks including directories",
            "global_actual": "UNKNOWN",
            "old_asset_scan": False,
            "refund_or_grant": False,
        },
        stream,
        indent=2,
    )
    stream.write("\n")
print(
    json.dumps(
        {
            "result": ref(OWN / "result-binding.json"),
            "source": ref(OWN / "source-binding.json"),
            "STOP": ref(OWN / "STOP.json"),
            "affected_B": allocated,
            "metadata_helper_STOP": datetime.now(timezone.utc).isoformat(),
        }
    )
)
