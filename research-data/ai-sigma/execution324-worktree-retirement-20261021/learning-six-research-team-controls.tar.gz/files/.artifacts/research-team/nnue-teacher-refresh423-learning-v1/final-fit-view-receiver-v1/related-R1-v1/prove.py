"""R1-only bounded read delta and unchanged semantic owner proof."""

import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import tempfile

OWN = Path(__file__).resolve().parent


def ref(path):
    b = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(b).hexdigest(),
        "bytes": len(b),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


before = gzip.decompress((OWN / "common.before.py.gz").read_bytes())
assert (
    hashlib.sha256(before).hexdigest()
    == "047cedf7ca6c2978dd05aba5db907a69ac323c4d80b835adf041793c756d2426"
)
after = (OWN / "common.py").read_bytes()
old, new = before.decode(), after.decode()
start = new.index("        def read_metadata_bytes(")
end = new.index("        def read_metadata(", start)
restored = new[:start] + new[end:]
start = restored.index("        def read_metadata(")
end = restored.index("        def exact(", start)
old_start = old.index("        def read_metadata(")
old_end = old.index("        def exact(", old_start)
restored = restored[:start] + old[old_start:old_end] + restored[end:]
tail = "        # Normal caller inputs protect these metadata identities for its lifetime;"
restored = restored[: restored.index(tail)] + old[old.index(tail) :]
assert restored.encode() == before
assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse(before))
assert (OWN / "test_final_fit_view.py").read_bytes() == (
    OWN.parent / "test_final_fit_view.py"
).read_bytes()
assert (
    hashlib.sha256((OWN / "test_final_fit_view.py").read_bytes()).hexdigest()
    == "ea106d7de9d7545a7fd4c6427a229557513cf22c7274321477a328315f48c7ee"
)
target = "python/quoridor_training/common.py"
test = "python/quoridor_training/test_final_fit_view_reads.py"
test_body = (OWN / "test_final_fit_view_reads.py").read_text().splitlines(True)
forward = list(
    difflib.unified_diff(
        old.splitlines(True), new.splitlines(True), fromfile="a/" + target, tofile="b/" + target
    )
)
forward += list(difflib.unified_diff([], test_body, fromfile="/dev/null", tofile="b/" + test))
inverse = list(
    difflib.unified_diff(
        new.splitlines(True), old.splitlines(True), fromfile="a/" + target, tofile="b/" + target
    )
)
inverse += list(difflib.unified_diff(test_body, [], fromfile="a/" + test, tofile="/dev/null"))
(OWN / "source.patch").write_text("".join(forward))
(OWN / "inverse.patch").write_text("".join(inverse))
captures = []
with tempfile.TemporaryDirectory(prefix="patch-recovery-", dir=OWN) as directory:
    root = Path(directory)
    p = root / target
    p.parent.mkdir(parents=True)
    p.write_bytes(before)
    for name, expected in (("source.patch", after), ("inverse.patch", before)):
        r = subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(OWN / name)],
            cwd=root,
            capture_output=True,
            text=True,
            check=True,
        )
        captures.append(
            {"patch": name, "exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr}
        )
        assert p.read_bytes() == expected
        if name == "source.patch":
            assert (root / test).read_text().splitlines(True) == test_body
        else:
            assert not (root / test).exists()
(OWN / "proof.json").write_text(
    json.dumps(
        {
            "base_sha256": hashlib.sha256(before).hexdigest(),
            "post": ref(OWN / "common.py"),
            "affected_owner": "common_cache_config local reader/new bounded read helper/final reread only",
            "restored_entire_module_BYTE_AST_exact": True,
            "mapping_scale_no_view_Alpha_MCTS_and_all_other_owner_BYTE_AST_exact": True,
            "original_test_ea106_BYTES_exact": True,
            "old_test_methods_replayed": 0,
            "new_test_target": test,
            "new_test": ref(OWN / "test_final_fit_view_reads.py"),
            "before_gzip": ref(OWN / "common.before.py.gz"),
            "forward": ref(OWN / "source.patch"),
            "inverse": ref(OWN / "inverse.patch"),
            "strict_forward_inverse": captures,
            "TMP_removed": True,
        },
        indent=2,
    )
    + "\n"
)
print("R1-only restoration BYTE/AST and strict forward/inverse PASS")
