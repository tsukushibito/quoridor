"""Run one explicitly supplied private source/NN0 command with existing controls."""

from contextlib import nullcontext
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "lc421_receiver", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = lc
spec.loader.exec_module(lc)
name, *argv = sys.argv[1:]
private_only = bool(argv and argv[0] == "--private-only")
if private_only:
    argv.pop(0)
result = {"argv": argv, "entered_at": lc.stamp(), "returned": None, "error": None}
result["private_only_no_Main_reader_lifetime"] = private_only
try:
    with nullcontext() if private_only else lc.lease():
        lc.physical_and_quiet(
            {
                "kind": "source",
                "limits": {
                    "worker_cpu": 10,
                    "guardian_cpu": 14,
                    "family_B": 1073741824,
                    "host_reserve_B": 4294967296,
                },
            }
        )
        capture = lc.Capture(OUT / (name + ".capture.log"), 524288)
        try:
            result["returned"] = lc.process.execute(
                argv,
                OUT / (name + ".guardian.log"),
                None,
                cpu_core=10,
                resources=lc.process.CycleResources({"max_memory_bytes": 1073741824}, OUT, None),
                cwd=str(ROOT),
                output_sink=capture,
            )
        finally:
            capture.close()
except BaseException as error:
    result["error"] = lc.error_fact(error)
result["stopped_at"] = lc.stamp()
result["controller_pid"] = os.getpid()
with (OUT / (name + ".returned.json")).open("x") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(
    json.dumps(
        {
            "name": name,
            "error": result["error"],
            "exit_code": (result["returned"] or {}).get("exit_code"),
            "STOP": result["stopped_at"],
        }
    )
)
if result["error"] or (result["returned"] or {}).get("exit_code") != 0:
    sys.exit(1)
