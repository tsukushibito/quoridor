# 423 final-fit-view metadata receiver

元423とMCTS admissionの続きとして、actual accepted common7dac8888へ`common_cache_config`一関数だけの末尾分岐を追加する。Main / Git / Cargo / native / model / Torch / NumPy / payload / forward / fitは作者0。Root324が疎合成・関連確認・実binding・conversion以降を所有する。旧323 / 342.17 / learner pause、旧FAILED / RAW / 費 / UNKNOWN、models / default / sealsを変更しない。

開始contextは2026-10-16T16:53:38.117Zの保存gpt-6.1-sol / high / Main / danger-full-access / approvalPolicy neverを確認した。短いcanonical intakeでcurrent commonの完全SHA7dac8888763ecd5a7e6424eabd3faeaa4c7eb79155adaaa0c0b9cf1e7ef9c341を確認し、before gzipと実refを保存した。sourceCPU10 / guardian14、family1GiB、GPU0、reserve4GiBの既存physical / resource / cleanup guardを使い、以降の私有処理でMain全lifetimeのleaseは取得しない。

## 正本と対応

native completion61ad6e4d / 4337、binding032dcb9e / 6667、post fb712fdf / 56063、report1ba88299 / 4844、final config52e5776f / 670を必要範囲だけhash-size-mode照合した。凍結owner sectionを読んで、元configのvalidate_inputs・元rowのsource split / prefix / family確認がsampling override前に残ることを確認した。新Rustのsoftwareやconversion結果は作者が認定していない。canonical requestの表記と周期prefix長は現役`Config::global_requests`の小さいsource範囲を参照し、別split分類器・geometry・Game履歴再生を実装しない。

Root / data作者が示した原203T / 53V→最終204T / 52V、ID18のみV→Tは、このreceiverへhardcodeしない。実conversion後のcache、対応表、実metadataから検査する。作者の新規テストは6件のtoy requestsと2つのsource sliceで、独立の新実験や実256の再qualificationではない。

manifestの`final_fit_view`と、manifestに保存された`input_binding` BoundJson本文の`final_fit_view`を必ず同じ実config参照へ結ぶ。片方だけの省略・null・不一致を拒否する。Alphaでviewを要求することは拒否する。view無しかつbinding無しの旧経路は追加metadata readを行わない。bindingがある場合は、manifestからviewだけを剥がす不整合を検出するため、小さいbinding本文をSHA-boundで読む。旧data-only / absent-authorityの受理はno-view経路で保持する。

view付きのbindingは単独fragmentでなく、既存のmodel_scale_authorityを保持した加算的な実bindingとする。manifest側の既存scale validatorを通ったauthorityとの完全一致が必要。Fのnormalization / warmstart / INITIAL admissionや親のnullweight対応は別ownerのままで、trained weightsをここで開かない。

## 検査するmetadata

- final Configは既存型の完全な値としてcache common Configと一致し、batch0 / count=families。実realized_gamesとmapping全件を一致させる。
- original native config LISTFILEのBoundJsonは実dataset_shaと一致する既存MCTS検査を保持し、その本文の順序がstream_intake.batchesのconfig refsと一致する必要がある。
- 各source config本文のoriginal common Config、slice範囲、MCTS model / sims、output datasetを検査する。sourceとfinalの相違はfamilies / schedule / partition / batch範囲だけ。seed / prefix lengths / policy / excluded books等を変えない。
- SHA-bound original / final schedule・partition本文から、canonical request ID、global slot、requested prefix length、全prefix、family、source split / view splitを照合する。partition familyを再分類・再hash・再ランク付けしない。
- mappingはglobal ID / game-{id} / request / source index / prefix / family / 両splitのexact typed列とする。bool / floatを整数と同一視せず、alias・欠測・重複・reorder・extra fieldを拒否する。changed_global_idsも実split差の順序付きexact列だけ。
- final sampling familiesは最初のrealized game順のfamily表と一致する。同じfamilyを共有する複数gameを許容する。sampling gamesの順序・family code・start / rows、per-source row合計、family rows、eligible counts、最終T/V eligible censusを結ぶ。sampling.binとfamily codeの実binary照合は既存TerminalCorpus ownerのままで、ここではpayloadを開かない。

追加metadata readerはこの関数内だけに閉じる。BoundJsonのabsolute path / lowercase SHA、regular非symlink、roleごと1MiBまたは4MiB、ユニーク本文合計16MiBを上限とし、同じ参照を局所memoizeする。file dev / inode / mode / size / mtime / ctimeとSHAを開始・終了で再照合する。readに伴うatime更新はdriftと誤認しない。新しいregistry / decoder / lock / authority file / API引数は作らない。

通常callerはcache / input_binding / finalConfig / LISTFILE / 各source config / 各schedule / partitionを既存ordered inputsへ実FileRefsで結び、consumerの実lifetimeで保護する。関数内before / after検査だけでcaller lifetimeの不変を宣言しない。cacheとbindingの両方を消して別のmanifestへ作り替える行為を、この関数だけで検出するとは主張せず、実cache FileRefとnormal parent admissionの責務を維持する。将来cache / weights / INITIAL / fit configのdummy refsは作らない。

## 新しい確認

新規`FinalFitViewNN0`の5定義を一度だけ実行し全PASS、STOP2026-10-16T17:05:38.188749Z。すべて小さいtoy metadataの実JSON / SHA-bound readであり、実モデル・forward・native・公開payloadは0、旧14 fake / 72 fake rowsや成功suiteの再演は0。正例では元JSON bytes不変と、6game / 5familyの場合も受理することを確認した。改変例ではmapping / alias / source settings / schedule / partition / list order / digest drift / symlink / size bound / sampling per-sourceとfamily census / stripping / scale競合を拒否した。

scope外の旧Alpha / MCTS / 421scale / Fnormalization / warmstart / INITIAL / train / loss / finalizerは変更しない。全旧owner bodyを復元したBYTE / AST proofとzero-fuzz順逆patchを付ける。Rootの同423.4へのrelated確認は、optional view / original-source correspondence / scale preservationだけを対象とし、作者はreviewerをdispatchしない。sourceの成功はconversion / fit / strengthの成功ではない。
