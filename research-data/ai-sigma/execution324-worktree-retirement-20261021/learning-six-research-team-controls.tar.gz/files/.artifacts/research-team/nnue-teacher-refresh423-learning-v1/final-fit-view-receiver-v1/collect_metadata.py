"""Collect stopped source/helper receipts and the single directed OWN usage."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat

OWN = Path(__file__).resolve().parent


def ref(path):
    b = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(b).hexdigest(),
        "bytes": len(b),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


def save(name, value):
    with (OWN / name).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


children, controllers, receipts, walls, failures = [], [], [], [], []
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
for path in sorted(OWN.glob("*.returned.json")):
    record = json.loads(path.read_bytes())
    name = path.name.removesuffix(".returned.json")
    disk_path = OWN / (name + ".guardian.process.json")
    disk = json.loads(disk_path.read_bytes()) if disk_path.exists() else None
    returned = record.get("returned")
    if disk:
        child = disk["child"]
        actual = None
        try:
            b = (Path("/proc") / str(child["pid"]) / "stat").read_text()
            actual = {
                "pid": child["pid"],
                "start_ticks": b[b.rfind(")") + 2 :].split()[19],
                "boot_id": boot,
            }
        except FileNotFoundError:
            pass
        assert actual != child, child
        assert (
            disk["direct_child_reaped"]
            and disk["cleanup_complete"]
            and disk["handle_closes_complete"]
            and not disk["remaining"]
        )
        children.append({"expected": child, "actual": actual, "original": "ABSENT_OR_DIFFERENT"})
        walls.append(
            {"name": name, "original_command_wall": disk["wall_seconds"], "scientific": False}
        )
    pid = record.get("controller_pid")
    if pid:
        assert not (Path("/proc") / str(pid)).exists(), pid
        controllers.append({"pid": pid, "observed_present": False, "start_ticks": "UNKNOWN"})
    keys = ("signal_mask_restoration", "final_record_persist")
    receipts.append(
        {
            "returned": ref(path),
            "disk": ref(disk_path) if disk else None,
            "returned_mask_persist": {k: returned.get(k) if returned else None for k in keys},
            "disk_mask_persist": {k: disk.get(k) if disk else None for k in keys},
        }
    )
    if record.get("error") or (returned or {}).get("exit_code") != 0:
        failures.append(
            {
                "name": name,
                "error": record.get("error"),
                "disk_exit": disk.get("exit_code") if disk else None,
            }
        )
assert not [
    p
    for p in OWN.iterdir()
    if p.is_dir() and (p.name.startswith("tmp") or p.name.startswith("patch-recovery-"))
]
last = json.loads((OWN / "finish-checks-v1.returned.json").read_bytes())
assert last["error"] is None and last["returned"]["exit_code"] == 0
save(
    "STOP.json",
    {
        "Main_named_reader_STOP": json.loads((OWN / "source-after-v1.returned.json").read_bytes())[
            "stopped_at"
        ],
        "private_source_reader_writer_STOP": last["stopped_at"],
        "collector_observed_at": datetime.now(timezone.utc).isoformat(),
        "known_children": children,
        "controllers": controllers,
        "receipts": receipts,
        "owned": {
            k: [] for k in ("readers", "writers", "children", "jobs", "handles", "TMP", "leases")
        },
        "original_failures": failures,
        "original_command_walls_once": walls,
        "source_software_wall_sum": sum(r["original_command_wall"] for r in walls),
        "nested_controller_admin_LLM_added": False,
        "exact_worker_UTC_exit": "UNKNOWN",
        "peak_RSS": "UNKNOWN",
        "real_model_forward_rows": 0,
    },
)
save(
    "source-binding.json",
    {
        "issue": "quoridor-4lc.423.2",
        "owner": "common_cache_config",
        "before": json.loads((OWN / "before-ref.json").read_bytes()),
        "post": ref(OWN / "common.py"),
        "before_owner_gzip": ref(OWN / "common_cache_config.before.py.gz"),
        "after_owner": ref(OWN / "common_cache_config.after.py"),
        "forward": ref(OWN / "source.patch"),
        "inverse": ref(OWN / "inverse.patch"),
        "proof": ref(OWN / "proof.json"),
        "current_source_after": ref(OWN / "current-source-after.json"),
        "checks": ref(OWN / "finish-checks.json"),
        "new_test": ref(OWN / "test_final_fit_view.py"),
        "new_test_target": "python/quoridor_training/test_final_fit_view.py",
        "producer_completion": ref(OWN / "native-completion.json"),
        "producer_refs": ref(OWN / "native-selected-refs.json"),
        "new_NN0_definitions": 5,
        "new_NN0_replays": 0,
        "new_runtime_forward_rows": 0,
        "old_Alpha_MCTS_scale_and_all_other_owners_BYTE_AST_exact": True,
        "normal_caller_inputs_needed": "actual cache/input_binding/finalConfig/LISTFILE/sourcecfg/source-and-final schedule+partition refs protected for actual lifetime",
        "future_cache_weights_INITIAL_fit_refs": "NOT_CREATED",
        "related_review_question": "optional view stripping/conflicts, exact original-source and final sampling mapping; no new classifier or scale change",
    },
)
save(
    "result-binding.json",
    {
        "issue": "quoridor-4lc.423.2",
        "status": "STOPPED_FINAL_FIT_VIEW_SOURCE_NN0_READY_FOR_ROOT_RELATED_REVIEW_ADOPTION",
        "source": ref(OWN / "source-binding.json"),
        "report": ref(OWN / "report.md"),
        "STOP": ref(OWN / "STOP.json"),
        "new_metadata_tests": "5_PASS_ONCE",
        "actual_conversion_fit_model_native": "NOT_RUN",
        "previous_423_packets": "UNCHANGED",
    },
)
save("affected-usage.json", {"allocated_bytes": 0})
seen = set()
allocated = 0
for root, dirs, files in os.walk(OWN):
    allocated += Path(root).stat().st_blocks * 512
    for name in files:
        s = (Path(root) / name).lstat()
        if (s.st_dev, s.st_ino) not in seen:
            seen.add((s.st_dev, s.st_ino))
            allocated += s.st_blocks * 512
with (OWN / "affected-usage.json").open("w") as stream:
    json.dump(
        {
            "scope": str(OWN),
            "allocated_bytes": allocated,
            "measurement": "once OWN dev/inode blocks including directories",
            "global_actual": "UNKNOWN",
            "old_asset_scan": False,
            "refund_or_grant": False,
        },
        stream,
        indent=2,
    )
    stream.write("\n")
print(
    json.dumps(
        {
            "result": ref(OWN / "result-binding.json"),
            "source": ref(OWN / "source-binding.json"),
            "STOP": ref(OWN / "STOP.json"),
            "affected_B": allocated,
            "metadata_helper_STOP": datetime.now(timezone.utc).isoformat(),
        }
    )
)
