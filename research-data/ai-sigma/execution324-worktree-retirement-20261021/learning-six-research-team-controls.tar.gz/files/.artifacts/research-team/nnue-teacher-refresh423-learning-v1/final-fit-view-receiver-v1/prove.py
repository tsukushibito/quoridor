"""Prove only the optional metadata owner was extended; save reversible delta."""

import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import tempfile

OWN = Path(__file__).resolve().parent


def ref(path):
    b = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(b).hexdigest(),
        "bytes": len(b),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


before = gzip.decompress((OWN / "common.before.py.gz").read_bytes())
assert (
    hashlib.sha256(before).hexdigest()
    == "7dac8888763ecd5a7e6424eabd3faeaa4c7eb79155adaaa0c0b9cf1e7ef9c341"
)
after = (OWN / "common.py").read_bytes()
old_tree, new_tree = ast.parse(before), ast.parse(after)
old = next(
    n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == "common_cache_config"
)
new = next(n for n in new_tree.body if isinstance(n, ast.FunctionDef) and n.name == old.name)
addition = new.body[-2]
assert (
    isinstance(addition, ast.If)
    and ast.unparse(addition.test) == "'input_binding' in manifest or 'final_fit_view' in manifest"
)
lines = after.decode().splitlines(True)
restored = "".join(lines[: addition.lineno - 1] + lines[addition.end_lineno :])
assert restored.encode() == before
assert ast.dump(ast.parse(restored)) == ast.dump(old_tree)
old_body = ast.dump(old)
new.body.pop(-2)
assert ast.dump(new) == old_body
target = "python/quoridor_training/common.py"
test = "python/quoridor_training/test_final_fit_view.py"
newtest = (OWN / "test_final_fit_view.py").read_text().splitlines(True)
forward = list(
    difflib.unified_diff(
        before.decode().splitlines(True),
        after.decode().splitlines(True),
        fromfile="a/" + target,
        tofile="b/" + target,
    )
)
forward += list(difflib.unified_diff([], newtest, fromfile="/dev/null", tofile="b/" + test))
inverse = list(
    difflib.unified_diff(
        after.decode().splitlines(True),
        before.decode().splitlines(True),
        fromfile="a/" + target,
        tofile="b/" + target,
    )
)
inverse += list(difflib.unified_diff(newtest, [], fromfile="a/" + test, tofile="/dev/null"))
(OWN / "source.patch").write_text("".join(forward))
(OWN / "inverse.patch").write_text("".join(inverse))
captures = []
with tempfile.TemporaryDirectory(prefix="patch-recovery-", dir=OWN) as directory:
    root = Path(directory)
    path = root / target
    path.parent.mkdir(parents=True)
    path.write_bytes(before)
    for name, expected in (("source.patch", after), ("inverse.patch", before)):
        r = subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(OWN / name)],
            cwd=root,
            capture_output=True,
            text=True,
            check=True,
        )
        captures.append(
            {"patch": name, "exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr}
        )
        assert path.read_bytes() == expected
        if name == "source.patch":
            assert (root / test).read_text().splitlines(True) == newtest
        else:
            assert not (root / test).exists()
old_owner = ast.get_source_segment(before.decode(), old) + "\n"
(OWN / "common_cache_config.before.py.gz").write_bytes(gzip.compress(old_owner.encode(), mtime=0))
(OWN / "common_cache_config.after.py").write_text(
    ast.get_source_segment(
        after.decode(),
        next(
            n
            for n in ast.parse(after).body
            if isinstance(n, ast.FunctionDef) and n.name == old.name
        ),
    )
    + "\n"
)
(OWN / "proof.json").write_text(
    json.dumps(
        {
            "before": json.loads((OWN / "before-ref.json").read_bytes()),
            "post": ref(OWN / "common.py"),
            "owner": "common_cache_config",
            "new_test_target": test,
            "new_test": ref(OWN / "test_final_fit_view.py"),
            "only_one_trailing_optional_If_added": True,
            "restored_module_BYTE_AST_exact": True,
            "old_Alpha_MCTS_scale_data_only_validation_BODY_BYTE_AST_exact": True,
            "all_other_owner_functions_BYTE_AST_exact": True,
            "forward_inverse": captures,
            "forward": ref(OWN / "source.patch"),
            "inverse": ref(OWN / "inverse.patch"),
            "before_owner_gzip": ref(OWN / "common_cache_config.before.py.gz"),
            "after_owner": ref(OWN / "common_cache_config.after.py"),
            "TMP_removed": True,
            "model_native_tests_replayed": 0,
        },
        indent=2,
    )
    + "\n"
)
print("optional owner delta, old bodies and strict forward/inverse PASS")
