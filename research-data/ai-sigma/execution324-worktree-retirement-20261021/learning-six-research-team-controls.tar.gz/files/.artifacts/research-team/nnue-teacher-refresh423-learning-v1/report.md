# 423 learner source / settings

新しい423のsource準備だけを扱う。421の現在cacheとC/M、422の直接static観測、旧323 / 342.17 / mixedのUSERPAUSEは別に保持する。Main / Git / Cargo / science writerは324。本packetの作者は実Torch、モデル、forward、fit、Search、nativeを実行しない。

元契約`nnue-teacher-refresh-20261016.md`と規模訂正`nnue-teacher-refresh-20261016-size-correction.md`の双方を維持する。32 requestsはpilotであって差の判別に十分とした根拠ではない。pilotだけで四fit / 160対局を自動消費しない。256 requests / Sigma合計2Mは一度の規模解決の上限であり、全件実行・refill指示ではない。実Max spec c919d92b / 17309、completion71c2689cとsplit-correspondence fac3fd19をhash-size-mode一致後にparseした。具体的seed / LR / 端数規則をそのまま採用し、最終規模と実R / V / future cache / weightsは未生成のままにする。

## 現役入口と差分

既存normal `train --cache ABS --output ABS --config ACTUAL [--input-binding ABS]`を使う。新command、study issue/pathによる特例、別decoder、sampler基盤、registry、schedulerは追加しない。`train.py`の`build_model` / `configure_framework` / host transfer / native parameter restore / exportは変更しない。

423の元intake sourceは保存する。421 cache-scale修復の実Main採用後、current common56859420 / public_replay e5cac5fcが作者421 postimagesと完全一致することを短いguarded readerで確認した。その版を新差分のbeforeとし、`common_cache_config`とdata-only read / model-bound fitの境界を保持する。sampling61fcとtrainbd45は元intakeから不変。

## Public row weighting

`mixture.public_file_decay`はnullなら通常uniform replacement、Rの実設定では0.92。qualified public membership07d81の`source_shards`はcycle_0001..0043の順で、RECORD.shard 0..42がファイル番号1..43に対応する。重みは`decay ** (N - 1 - shard)`であり、file indexを実モデル世代や棋力と呼ばない。

`sampling.indexed_public_sample`は既存proposal RNGと`IndexedPublicCorpus.records('train', ..., training=True)`で小さいcandidate batchだけを読む。uniform T candidateをそのfile weightで受け入れ、row-levelの正規化された重み分布を得る。Rの採択RNGは別の明示`mixture.public_acceptance_seed`を使う。全corpusのprobability配列、global group keys、NPZ再decode、公開payload再hashを作らない。lossは従来のrow mean MSEのままで、lossに二重に重みを掛けない。proposal / selected per-file / completed-update per-fileを区別する。途中失敗の選択stateはUNKNOWNを残す。通常cancel / budgetチェックは各候補batchの前。例外をuniform fallbackに置換しない。nullまたは1では従来のuniform drawをそのまま使う。

## 固定scheduleと端数

`mixture.training_rows`に実training row数を明示する。U/R/Wは`S=min(8R,32768)`、Fは`S=min(64R,524288)`で、updatesはceil(S/256)。最後のbatchはremaining rowsそのものを使い、paddingして8R / 64Rを超過させない。partial mixed-source ratioが未指定のままの端数はentry前に拒否する。既存421のfull batchはこのoption未指定のまま保持する。

U/R/WはLR1e-4 / warmup min(10,U)、FはLR1e-3 / min(20,U)、4点以下のunique{0,ceil(U/3),ceil(2U/3),U}。seedはspecの整数42320261020..28をkeyで取得し、旧421 seedから推測しない。`prepare-configs.py`は実final cacheからT層抽出R / 全Vを得て通常configsを生成するだけで、launchしない。pilotだけでの呼出しを拒否し、実one-time scale/final view固定後のRootが明示して使用する。flagは新しい許可証やregistryではない。保守的な未共有INITIAL計数で四fit＋changed-weight1024が3381560 / 4Mになる上限を新しいmaterializer境界で確認する。実CLI/cache処理は作者UNRUN。

## 明示的なpublic観測scope

`mixture.public_evaluation`は`{"validation":"best"|"checkpoints","train_diagnostic":bool}`。現在の421に必要な既存scopeは未指定時に維持する。423のresolved recipeでは明示し、BESTだけのpublicV測定とnon-regression selectorの同時指定は拒否する。`planned_work`と実scopesは同じpolicyを用い、frozen BESTのpublicV一回分もall-work forward boundへ加える。

public train diagnosticをfalseにした場合、public Tのラベルやconstant-guide平均を読まない。public constantはUNKNOWNとしてnull、guide MSEもnullとし、0という見掛けのguideへ置き換えない。このstrict branchもfake NN0で確認する。実specの固定publicT8192 panelは四条件とも観測専用として設定する。Fの最適化batchのpublic row数は0で、panelラベルやguideがloss / gradient / selectorへ流れない。公開T/Vのread-only indexed mapsと小さいmembership metadataはラベル学習と区別する。Fでも観測panelと最終frozen BESTのopened publicV監視は許可された別scopeであり、public無使用とは呼ばない。

BEST-onlyの公開V監視は既存builderとrestore APIによる別model objectを使う。同じlogit/head/feature実装であり、live LASTのparameters / optimizerをBESTへ書き換えない。成功したLASTのstepを遡って誤表示しない。例外時もlive modelをfinallyで復帰し、従来の独立finalizer、primary / secondary、partial、marker、cancelとcounterを維持する。

## Fresh initializerと尺度

従来の`experiment.warm_start`でdescriptor46ec / weights046fe / evaluator96a5はU/R/Wの明示warmstart。Fは同じdescriptorを正規化metadataとして残し、`weights:null`と`evaluator_sha256:null`を明示する。既存`build_model`の通常新規初期化を使い、warmstart restore / native weight verifyを呼ばない。architecture、FP32、Zero4、tanh、output bypass OFF、Adamおよびincumbent T-only normalizationは変えない。

`warmstart_model_inputs`は両経路で同じdescriptor conventionとstatistics validatorを使う。freshではdescriptorだけを読み、trained weightsを開かない。既存input-bindingに別名weightsやINITIALを混入して読ませることも、fresh admissionでfile key / metadata一致をbody読取前に拒否する。新Fの実weights / typed evaluatorは実INITIAL export前には存在しない。

cache / external `model_scale_authority`の元BEST43 tupleは凍結normalizationの出所を表し、Fの新しいstarting weightsと偽って扱わない。Fのnormal parent modelsはdescriptor/statisticsと明示fresh config/seedを束縛する必要があり、古い必須warmweight FileRef tupleをそのまま流用しない。このnormal parentの小さい整合はRootの所有範囲。F input-bindingのfilesは実cache_manifest / descriptorだけを許容し、trained weightsや他armのINITIALを読ませない。

FのINITIALは実新規stateをexportし、BESTがstep0のままでも正体を保持する。U/R/Wの既資格INITIALは必要scopeだけ共有できるが、model / scale / cache / public membership / batch / row indices / 必要guide constantが一致する実観測だけを受け入れる。superset bankから他のscopeを今回の観測と装わず、必要scopeを抽出する。FのINITIAL共有は拒否する。

親の実未解決inletはcurrent publisher3f1dの2か所に限定できた。`numerical_fields` line858の`r["weights"]["sha256"]`はFの明示nullを参照できず、`experiment_check` lines1929–1930はdescriptorとnull weightsを通常FileRef列へ追加する。`common_study_check`のmodel tuple比較そのものは設定と同じnullを表せる。Rootはこの2consumerでfresh normalization descriptor / seed / 実configを束縛し、warm branchの必須weight、native / library / source guardは保持する必要がある。作者はpublisherを変更していない。存在しない`model_fields`関数や将来F weightのFileRefを作らない。実限定source fragmentとbefore SHAは`parent-model-gap.json`に保存した。

## 停止と未実行

新規fake NN0の最初の7定義PASS（fake47行 / real model0）と、追加したfresh admission 1定義PASSを別receiptで保持する。旧421の7定義、381、model/head/parity suiteは再演しない。9番目の新materializer定義もassertionsはPASSしたが、launcherの`nn0-result-related.json`が前の結果と衝突し、結果JSONのcreateでFileExistsErrorとなって原command全体はFAILED。前の結果は上書きしていない。原fullcapture / disk receipt / returned NULLと費を保持し、launcherだけfilter由来の一意な出力名へ修正した。9番目も含め成功assertionは再演しない。softwareの部分成功とcommand FAILEDを混同しない。完成bindingに元receiptと未実行の境界を明示する。

family / stockの既存集計に加え、同じ予測からgame別SSE / counts / sign / sumsを保存する。game keysは`TerminalCorpus.row_game_codes`の文字列表現と明記する。Rootが実cacheの`game_names`とbound scheduleへjoinしてprefix-length別を集計でき、trainingでGame / historyを開く必要はない。calibrationは同じ10binに[-1,1]の範囲とmean value / mean zを併記し、直接のraw value / z和から計算する。小値を変換後の平均から逆算せず、追加forwardは行わない。この新しい同一予測集計だけを10番目のfake NN0で確認する。

元canonical EAGAIN拒否は保持し、holderを推測しない。shared lockが必要なMain intake / test / formatterは実releaseとfresh guardでだけ入る。実資源や静穏をidle中に所有したとは主張しない。

新規10番目のgame-code / raw-calibration定義は2026-10-16T02:08:17.117707ZにPASSして停止した。追加fake25行、全scopeでfake72行 / 実model forward0 / 実Torch import0。新規10定義のassertionは成功し、うち9定義は成功command、9番目のmaterializer定義だけは前述の結果名衝突によるFAILED command内の部分成功として保持する。新launcherのfilter別result JSON保存は10番目の実commandで確認できた。旧成功定義は一つも再演していない。

最終thin patchのGNU zero-fuzz forward / inverse、outside-owner BYTE / AST、元finalizer / forward / checkpoint export不変、named current sourceのbefore / after一致、scoped Ruff format / no-cache lint、report / settingsのPrettier、JSON parseを`finish-checks-v1`で確認し、2026-10-16T02:08:53.979444Zに停止した。前のproof対象も`proof-v1-original-*`に保持し、新しい集計postimageへ静的確認だけを更新した。新しい規模・cache・modelsの観測は0。

実contextは02:06:11.811Zのsaved Sol6.1 / high / Main / danger-full-access / approvalPolicy neverを確認した。最終formatの原02:06:51.288653Z EAGAINは子未入場のまま保存し、Rootのactual release02:06:59.539582Z後に未実行formatだけを実行した。最新publisher f74e5672の変更はRootがmeasurement_configだけと通知しており、作者が確認した3f1dのF親2consumerはその原scopeの証拠のまま保持する。新publisher全体の再検査やqualificationへの昇格はしていない。

実new cacheとone-time規模解決が未着なので、R/U/steps / 将来weight / runtime Experimentのdummy refsを作らない。現在のMax specのseedとformulaは固定、final scaleは未固定である。source完成をscience-readyや効果・棋力の結果と呼ばない。Rootがactual refsとnormal numerical / library / source / physical guardsを束縛して実行する。arenaはW/BEST43の最大64family128局＋W/Dの同first16family32局だけで、旧R/U・W/U・W/F対局案は今回実施しない。原pilot / split / RAWを変更せず、最終combined fit-viewとの対応は通常metadataに残す。科学全体4M NNUE forwards / whole128MiB / decimal50GBと元FAILED / RAW / 費 / UNKNOWNは不変。
