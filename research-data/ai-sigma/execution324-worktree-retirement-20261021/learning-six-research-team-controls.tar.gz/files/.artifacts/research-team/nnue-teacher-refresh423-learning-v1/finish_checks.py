"""Final scoped formatting, source identity and sparse recovery checks only."""

import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


expected = json.loads((OWN / "before-refs.json").read_bytes())
specs = json.loads((OWN / "fixed-spec-refs.json").read_bytes())
for record in [*expected.values(), *specs.values()]:
    assert ref(Path(record["path"])) == record, record["path"]
before = {name: ref(Path(r["path"])) for name, r in expected.items()}
for name in ("source.patch", "static-proof.json"):
    original = OWN / name
    retained = OWN / ("proof-v1-original-" + name)
    if not retained.exists():
        shutil.copyfile(original, retained)

files = [
    str(OWN / (name + ".py"))
    for name in (
        "common",
        "public_replay",
        "sampling",
        "test_teacher_refresh_inputs",
        "run_tests",
        "prepare-configs",
        "prove",
        "finish_checks",
    )
]
commands = [
    [
        sys.executable,
        "-B",
        "-m",
        "ruff",
        "format",
        "--config",
        "tools/research-quality/ruff.toml",
        str(Path(__file__)),
    ],
    [
        sys.executable,
        "-B",
        "-m",
        "ruff",
        "format",
        "--check",
        "--config",
        "tools/research-quality/ruff.toml",
        *files,
    ],
    [
        sys.executable,
        "-B",
        "-m",
        "ruff",
        "check",
        "--no-cache",
        "--config",
        "tools/research-quality/ruff.toml",
        *files,
    ],
    [sys.executable, "-B", str(OWN / "prove.py")],
    [
        "/home/vscode/.local/bin/node",
        "tools/research-quality/node_modules/prettier/bin/prettier.cjs",
        "--write",
        str(OWN / "report.md"),
        str(OWN / "settings.fixed-recipe.json"),
    ],
    [
        "/home/vscode/.local/bin/node",
        "tools/research-quality/node_modules/prettier/bin/prettier.cjs",
        "--check",
        str(OWN / "report.md"),
        str(OWN / "settings.fixed-recipe.json"),
    ],
]
captures = []
for command in commands:
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    captures.append(
        {
            "argv": command,
            "exit_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    )
    print(result.stdout, end="")
    print(result.stderr, end="", file=sys.stderr)
    if result.returncode:
        (OWN / "finish-checks-failure.json").write_text(json.dumps(captures, indent=2) + "\n")
        raise RuntimeError("unfinished scoped check failed")
settings = json.loads((OWN / "settings.fixed-recipe.json").read_bytes())
assert settings["final_scale_fixed"] is False
assert settings["science_launched"] is False
assert settings["spec"] == specs["spec.json"]
for record in [*expected.values(), *specs.values()]:
    assert ref(Path(record["path"])) == record, record["path"]
(OWN / "finish-checks.json").write_text(
    json.dumps(
        {
            "captures": captures,
            "current_sources_before": before,
            "current_sources_after": {name: ref(Path(r["path"])) for name, r in expected.items()},
            "specs_checked_before_parse_and_after": specs,
            "unchanged_train_copy": ref(OWN / "train.py")["sha256"] == expected["train"]["sha256"],
            "settings_parse_and_scope": True,
            "new_tests_replayed": 0,
            "real_model_forwards": 0,
        },
        indent=2,
    )
    + "\n"
)
print(json.dumps({"checks": len(captures), "source_after": "exact", "science": 0}))
