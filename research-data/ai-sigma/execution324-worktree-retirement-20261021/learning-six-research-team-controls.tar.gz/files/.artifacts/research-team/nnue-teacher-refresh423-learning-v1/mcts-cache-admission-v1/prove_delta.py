"""Owner-only proof and strict reversible delta over the original frozen 423."""

import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import tempfile

OWN = Path(__file__).resolve().parent


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


before = (OWN.parent / "common.py").read_bytes()
after = (OWN / "common.py").read_bytes()
assert (
    hashlib.sha256(before).hexdigest()
    == "e5dc86b500f99fc6d14d218f8286a410b41676ef61a8c34e3c50d14f161388af"
)
old_tree, new_tree = ast.parse(before), ast.parse(after)
old = next(
    n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == "common_cache_config"
)
new = next(n for n in new_tree.body if isinstance(n, ast.FunctionDef) and n.name == old.name)
old_prefix = before.decode().splitlines(True)[: old.lineno - 1]
new_prefix = after.decode().splitlines(True)[: new.lineno - 1]
assert old_prefix == new_prefix
old_suffix = before.decode().splitlines(True)[old.end_lineno :]
new_suffix = after.decode().splitlines(True)[new.end_lineno :]
assert old_suffix == new_suffix
old_tree.body[-1] = new_tree.body[-1]
assert ast.dump(old_tree) == ast.dump(new_tree)
old_loop = next(n for n in old.body if isinstance(n, ast.For))
new_loop = next(n for n in new.body if isinstance(n, ast.For))
assert ast.dump(old_loop.target) == ast.dump(new_loop.target)
assert ast.dump(old_loop.iter) == ast.dump(new_loop.iter)
assert ast.dump(ast.Module(body=old_loop.body[:2], type_ignores=[])) == ast.dump(
    ast.Module(body=new_loop.body[0].orelse, type_ignores=[])
)
assert ast.dump(ast.Module(body=old_loop.body[2:], type_ignores=[])) == ast.dump(
    ast.Module(body=new_loop.body[1:], type_ignores=[])
)
authority_test = '"model_scale_authority" in manifest'
old_authority = next(
    n
    for n in old.body
    if isinstance(n, ast.If) and ast.unparse(n.test) == authority_test.replace('"', "'")
)
new_authority = next(
    n
    for n in new.body
    if isinstance(n, ast.If) and ast.dump(n.test) == ast.dump(old_authority.test)
)
assert ast.dump(old_authority) == ast.dump(new_authority)
assert ast.get_source_segment(before.decode(), old_authority) == ast.get_source_segment(
    after.decode(), new_authority
)
target = "python/quoridor_training/common.py"
test_target = "python/quoridor_training/test_mcts_cache_admission.py"
patch = list(
    difflib.unified_diff(
        before.decode().splitlines(True),
        after.decode().splitlines(True),
        fromfile="a/" + target,
        tofile="b/" + target,
    )
)
patch += list(
    difflib.unified_diff(
        [],
        (OWN / "test_mcts_cache_admission.py").read_text().splitlines(True),
        fromfile="/dev/null",
        tofile="b/" + test_target,
    )
)
(OWN / "source.patch").write_text("".join(patch))
captures = []
with tempfile.TemporaryDirectory(prefix="delta-recovery-", dir=OWN) as directory:
    stage = Path(directory)
    file = stage / target
    file.parent.mkdir(parents=True)
    file.write_bytes(before)
    for reverse in (False, True):
        command = ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(OWN / "source.patch")]
        if reverse:
            command.append("-R")
        r = subprocess.run(command, cwd=stage, capture_output=True, text=True, check=True)
        captures.append(
            {"argv": command, "exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr}
        )
        assert file.read_bytes() == (before if reverse else after)
        if reverse:
            assert not (stage / test_target).exists()
        else:
            assert (stage / test_target).read_bytes() == (
                OWN / "test_mcts_cache_admission.py"
            ).read_bytes()
assert (
    gzip.decompress((OWN / "common_cache_config.before.py.gz").read_bytes())
    == before[before.index(b"def common_cache_config(") :]
)
(OWN / "common_cache_config.after.py").write_text(
    ast.get_source_segment(after.decode(), new) + "\n"
)
(OWN / "proof.json").write_text(
    json.dumps(
        {
            "before": ref(OWN.parent / "common.py"),
            "post": ref(OWN / "common.py"),
            "before_owner_gzip": ref(OWN / "common_cache_config.before.py.gz"),
            "after_owner": ref(OWN / "common_cache_config.after.py"),
            "owner": "common_cache_config",
            "outside_owner_BYTE_AST_exact": True,
            "original_Alpha_source_loop_body_AST_exact": True,
            "original_scale_authority_BYTE_AST_exact": True,
            "original_cache_batch_cursor_AST_exact": True,
            "forward_inverse": captures,
            "patch": ref(OWN / "source.patch"),
            "test_target": test_target,
            "new_test": ref(OWN / "test_mcts_cache_admission.py"),
            "recovery_TMP_removed": True,
            "real_model_rows": 0,
        },
        indent=2,
    )
    + "\n"
)
print("owner-only BYTE/AST and strict forward/inverse PASS")
