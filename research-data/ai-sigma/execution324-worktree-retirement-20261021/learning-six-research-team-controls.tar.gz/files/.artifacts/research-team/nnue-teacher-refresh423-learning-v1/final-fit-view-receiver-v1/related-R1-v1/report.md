# final-fit-view R1 bounded-read repair

元d5633ccc / b28534a6 / common047cedf7 / newtestea106d7d / 5PASS / STOPは保持し、新しいrelated-R1-v1だけへ差分を保存した。Rootが既に採用した047cedf7からのthin deltaで、Main / Git / Cargo / model / payload / Torch / NumPy / native / fit / forwardを作者は実行しない。実context17:19:33.189ZのSol6.1 / high / Main / danger-full-access / neverを確認した。

同423.4のreview6a9e8f3aをbefore / after SHA一致で読み、R1だけを扱う。元sourceに実被害・OOMがあったとは主張しない。旧readerは用途上限をcache missでだけ検査し、stat後のread_bytesと最終再読が無制限だったため、metadata上限を実際のallocation前に保証できなかった。

## 最小変更

`common_cache_config`のlocal readerへ、小さい`read_metadata_bytes`だけを加えた。statで受理した正のregularサイズが用途上限とaggregate残容量以内であることを確認し、O_RDONLY / O_CLOEXEC / O_NOFOLLOW / O_NONBLOCKでopenする。descriptorのfstatとpathのlstatをdev / inode / mode / size / mtime / ctimeで照合し、同じregular fileである場合だけ読む。atimeは不変の要件へ追加しない。

OSへの各read要求は残りaccepted sizeと64KiBの小さい方で、合計もaccepted size以内。buffered read-aheadやunbounded read_bytesを使わない。読取後もfstat / path identity / SHA / exact byte countを確認する。ファイル増大は受理サイズを超えて読んでから検出するのではなく、その範囲内の読取後に拒否する。descriptorは成功・失敗の両方でfinally closeを試みる。

初回新規readは`min(role_limit, 16MiB - unique_metadata_bytes)`もhelperへ渡す。aggregateは以前どおりユニーク本文の計数であり、最終identity再読へ新規sourceのquotaを再配賦しない。cache hitも毎回サイズを新しい用途上限と照合し、受理した最小の用途上限を保持する。最終再読も同じhelperを使い、以前のサイズ / 最小用途上限 / identityへ束縛する。

mapping / scale / no-view / Alpha / MCTS / Fnormalization / INITIAL / loss / model / finalizer等は変更しない。新しいframework / registry / lock / certificate / APIはない。Rootのnormal Experiment入力と実lifetime前後照合を関数単独のcertificateで置き換えない。

## 新しい確認のみ

新しい`FinalFitViewReadR1NN0`3定義が一度で全PASS、STOP2026-10-16T17:25:00.033894Z。元5定義と旧suiteは実行していない。元testのFixtureというtoy JSON生成関数だけを再用し、そのsourceea106d7dはbyte不変。新maintained test pathは`python/quoridor_training/test_final_fit_view_reads.py`。

- 1つの本物のSHA-bound toy JSONを4MiB schedule用途で先にcacheし、1MiB native-config用途で再利用するケースを実関数で拒否。用途が排他的という仮定を置かず、2回目のopenなし・最初の読取要求総量も受理サイズ以内と確認した。
- 初回と最終再読のそれぞれで、open / fstat後の実file増大を注入し、accepted byte数以内のos.readだけでdrift拒否。無制限のPath.read_bytesを禁止するhook、実要求数、FD closeを検査した。実データやRootのファイルを変更していない。
- open前のregular file差替え、open前symlink、open後のpath差替え、非regularなopened fstat、read中のpath差替えを拒否。NOFOLLOW / NONBLOCK / CLOEXEC、不要なbody read前の拒否、実FD closeを確認した。

新しいfixtureは小さい私有metadataと増大用の一時bytesのみ。実model / inference / NNUE / payload / forwardは0。Rootのnative4PASS / Clippy / release / imageは別の成功scopeのまま再演しない。親の科学件数・128MiB / 50GB・旧USERPAUSE・default / model / seals / RAW / FAILED / 費UNKNOWNは変更しない。related reviewer確認とMain採用は324配送で、作者はdispatchしない。
