"""Scoped final checks of the new private admission delta only."""

import difflib
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import sys

OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


expected_parent = {
    "result-binding.json": "a56b3eba950ad265155591417afc474ffcd3c8ef8deea8c1a4554a131ca0199b",
    "source-binding.json": "f3bf8ac2fad64c16cfe81749658bf8232c89740ddccdc4b742f793fcd970b437",
    "common.py": "e5dc86b500f99fc6d14d218f8286a410b41676ef61a8c34e3c50d14f161388af",
}
before = {name: ref(OWN.parent / name) for name in expected_parent}
assert all(before[name]["sha256"] == sha for name, sha in expected_parent.items())
files = [
    str(OWN / (name + ".py"))
    for name in (
        "common",
        "test_mcts_cache_admission",
        "prepare_delta",
        "prove_delta",
        "finish_checks",
        "collect_metadata",
        "guard",
    )
]
commands = [
    [
        sys.executable,
        "-B",
        "-m",
        "ruff",
        "format",
        "--config",
        str(OWN / "ruff.project.toml"),
        str(Path(__file__)),
        str(OWN / "collect_metadata.py"),
        str(OWN / "guard.py"),
    ],
    [
        sys.executable,
        "-B",
        "-m",
        "ruff",
        "format",
        "--check",
        "--config",
        str(OWN / "ruff.project.toml"),
        *files,
    ],
    [
        sys.executable,
        "-B",
        "-m",
        "ruff",
        "check",
        "--no-cache",
        "--config",
        str(OWN / "ruff.project.toml"),
        *files,
    ],
    [
        "/home/vscode/.local/bin/node",
        "tools/research-quality/node_modules/prettier/bin/prettier.cjs",
        "--config",
        str(OWN / "prettier.private.json"),
        "--no-editorconfig",
        "--write",
        str(OWN / "report.md"),
    ],
    [
        "/home/vscode/.local/bin/node",
        "tools/research-quality/node_modules/prettier/bin/prettier.cjs",
        "--config",
        str(OWN / "prettier.private.json"),
        "--no-editorconfig",
        "--check",
        str(OWN / "report.md"),
    ],
]
captures = []
for command in commands:
    r = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    captures.append(
        {"argv": command, "exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr}
    )
    print(r.stdout, end="")
    print(r.stderr, end="", file=sys.stderr)
    if r.returncode:
        (OWN / "finish-failure.json").write_text(json.dumps(captures, indent=2) + "\n")
        raise RuntimeError("scoped source check failed")
target = "python/quoridor_training/common.py"
test = "python/quoridor_training/test_mcts_cache_admission.py"
inverse = list(
    difflib.unified_diff(
        (OWN / "common.py").read_text().splitlines(True),
        (OWN.parent / "common.py").read_text().splitlines(True),
        fromfile="a/" + target,
        tofile="b/" + target,
    )
)
inverse += list(
    difflib.unified_diff(
        (OWN / "test_mcts_cache_admission.py").read_text().splitlines(True),
        [],
        fromfile="a/" + test,
        tofile="/dev/null",
    )
)
(OWN / "inverse.patch").write_text("".join(inverse))
after = {name: ref(OWN.parent / name) for name in expected_parent}
assert before == after
(OWN / "finish-checks.json").write_text(
    json.dumps(
        {
            "captures": captures,
            "frozen_parent_before": before,
            "frozen_parent_after": after,
            "inverse": ref(OWN / "inverse.patch"),
            "new_definitions_replayed": 0,
            "Main_source_reads": 0,
            "real_forward_rows": 0,
        },
        indent=2,
    )
    + "\n"
)
print("scoped format/lint/docs and frozen parent identities PASS")
