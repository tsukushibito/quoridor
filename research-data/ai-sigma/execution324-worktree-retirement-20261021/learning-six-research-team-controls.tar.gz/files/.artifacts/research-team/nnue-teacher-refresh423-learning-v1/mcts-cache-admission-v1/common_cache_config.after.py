def common_cache_config(manifest):
    """Typed published outcome-cache lineage; no study/plan or raw-range selector."""
    mcts_fields = {"mcts_source", "mcts_datasets", "mcts_native_configs"}
    mcts = bool(mcts_fields.intersection(manifest))
    if mcts and not mcts_fields.issubset(manifest):
        raise ValueError("complete MCTS source metadata required")
    c = manifest["common_corpus"]
    cfg = c["config"]
    fields = {
        "families",
        "prefix_seed",
        "prefix_lengths",
        "split_seed",
        "root_value_policy",
        "schedule",
        "partition",
        "batch_start",
        "batch_count",
        "excluded_books",
    }

    def bound_json_ref(value):
        return (
            isinstance(value, dict)
            and set(value) == {"path", "sha256"}
            and isinstance(value["path"], str)
            and bool(value["path"])
            and isinstance(value["sha256"], str)
            and len(value["sha256"]) == 64
            and all(ch in "0123456789abcdef" for ch in value["sha256"])
        )

    if (
        manifest["schema"] != "quoridor-common-corpus-terminal-geometry-v3"
        or set(cfg) != fields
        or type(cfg["families"]) is not int
        or cfg["families"] <= 0
        or any(
            type(cfg[k]) is not int or not 0 <= cfg[k] < 2**64
            for k in ("prefix_seed", "split_seed")
        )
        or not isinstance(cfg["prefix_lengths"], list)
        or not cfg["prefix_lengths"]
        or any(type(v) is not int or not 0 < v < 200 for v in cfg["prefix_lengths"])
        or len(cfg["prefix_lengths"]) != len(set(cfg["prefix_lengths"]))
        or cfg["root_value_policy"] != "outcome_only"
        or any(not bound_json_ref(cfg[k]) for k in ("schedule", "partition"))
        or not isinstance(cfg["excluded_books"], list)
        or any(not bound_json_ref(ref) for ref in cfg["excluded_books"])
        or any(type(cfg[k]) is not int or cfg[k] < 0 for k in ("batch_start", "batch_count"))
        or cfg["batch_count"] <= 0
        or cfg["batch_start"] + cfg["batch_count"] > cfg["families"]
        or c["planned_families"] != cfg["families"]
        or c["raw_file"] != "completed-root-raw.f32"
        or c["common_mask_file"] != "common-eligible.u8"
        or c["sampling_file"] != "sampling.bin"
        or c["teacher_A"] != "actual_final_z"
        or c["rootmean_is_raw"] is not mcts
        or type(manifest["rows"]) is not int
        or manifest["rows"] < 0
        or type(c["common_eligible_rows"]) is not int
        or not 0 <= c["common_eligible_rows"] <= manifest["rows"]
    ):
        raise ValueError("published configured outcome/raw/sampling contract")
    counts = c["common_eligible_by_split"]
    if (
        set(counts) != {"train", "validation"}
        or any(type(v) is not int or v < 0 for v in counts.values())
        or sum(counts.values()) != c["common_eligible_rows"]
    ):
        raise ValueError("literal outcome T/V eligible census")

    def digest(value):
        return (
            isinstance(value, str)
            and len(value) == 64
            and all(v in "0123456789abcdef" for v in value)
        )

    if "model_scale_authority" in manifest:
        authority = manifest["model_scale_authority"]
        if (
            not isinstance(authority, dict)
            or set(authority)
            != {
                "starting_weights_sha256",
                "descriptor_sha256",
                "evaluator_sha256",
                "scale_policy",
            }
            or any(
                not digest(authority[k])
                for k in (
                    "starting_weights_sha256",
                    "descriptor_sha256",
                    "evaluator_sha256",
                )
            )
            or authority["scale_policy"] != "incumbent_descriptor_T_only"
        ):
            raise ValueError("published initializer/frozen scale authority")
    intake = manifest["stream_intake"]
    sources, bindings = manifest["source_content"], manifest["source_binding"]
    if (
        intake["status"] != "complete"
        or intake["scope"] != "common-corpus"
        or intake["publication_protocol"] != "incomplete-marker-last-v1"
        or manifest["schedule_sha256"] != cfg["schedule"]["sha256"]
        or manifest["family_partition_sha256"] != cfg["partition"]["sha256"]
        or not digest(manifest["dataset_sha"])
        or not isinstance(sources, list)
        or not sources
        or not isinstance(bindings, list)
        or len(bindings) != len(sources)
        or len(intake["batches"]) != len(sources)
    ):
        raise ValueError("published complete ordered source/global schedule/partition lineage")
    if mcts:
        model, datasets, configs = (
            manifest["mcts_source"],
            manifest["mcts_datasets"],
            manifest["mcts_native_configs"],
        )
        if (
            not isinstance(model, dict)
            or set(model) != {"model_sha256", "completed_simulations"}
            or not digest(model["model_sha256"])
            or type(model["completed_simulations"]) is not int
            or not 0 < model["completed_simulations"] < 2**32
            or not bound_json_ref(configs)
            or not Path(configs["path"]).is_absolute()
            or configs["sha256"] != manifest["dataset_sha"]
            or not isinstance(datasets, list)
            or len(datasets) != len(sources)
        ):
            raise ValueError("published MCTS model/simulations/ordered native config lineage")
        if (
            any(
                not isinstance(dataset, dict)
                or set(dataset) != {"dataset", "manifest_sha256", "rows"}
                or not isinstance(dataset["dataset"], str)
                or not Path(dataset["dataset"]).is_absolute()
                or not digest(dataset["manifest_sha256"])
                or type(dataset["rows"]) is not int
                or dataset["rows"] < 0
                for dataset in datasets
            )
            or sum(dataset["rows"] for dataset in datasets) != manifest["rows"]
        ):
            raise ValueError("published MCTS dataset manifest/row census")
    seen, cursor = set(), cfg["batch_start"]
    for source, binding, batch in zip(sources, bindings, intake["batches"]):
        if mcts:
            dataset = datasets[len(seen)]
            if (
                not isinstance(source, dict)
                or set(source) != {"encoding", "manifest"}
                or source["encoding"] != "native-teacher-dataset-shards-v1"
                or not bound_json_ref(binding)
                or not Path(binding["path"]).is_absolute()
                or source["manifest"] != binding
                or binding
                != {
                    "path": str(Path(dataset["dataset"]) / "manifest.json"),
                    "sha256": dataset["manifest_sha256"],
                }
                or binding["path"] in seen
                or set(batch) != {"batch_start", "batch_count", "config"}
                or type(batch["batch_start"]) is not int
                or batch["batch_start"] != cursor
                or type(batch["batch_count"]) is not int
                or batch["batch_count"] <= 0
                or not bound_json_ref(batch["config"])
                or not Path(batch["config"]["path"]).is_absolute()
            ):
                raise ValueError("ordered MCTS source manifest/configured batch interval")
        else:
            compressed = source["compressed"]
            if (
                set(source) != {"encoding", "compressed", "raw_sha256", "raw_bytes"}
                or source["encoding"] != "gzip-single-member-v1"
                or set(compressed) != {"path", "sha256", "bytes", "mode"}
                or not bound_json_ref(binding)
                or not Path(binding["path"]).is_absolute()
                or binding != {"path": compressed["path"], "sha256": compressed["sha256"]}
                or binding["path"] in seen
                or type(compressed["bytes"]) is not int
                or compressed["bytes"] <= 0
                or compressed["mode"] not in ("0600", "0644")
                or not digest(source["raw_sha256"])
                or type(source["raw_bytes"]) is not int
                or source["raw_bytes"] <= 0
                or set(batch) != {"batch_start", "batch_count", "config"}
                or type(batch["batch_start"]) is not int
                or batch["batch_start"] != cursor
                or type(batch["batch_count"]) is not int
                or batch["batch_count"] <= 0
                or not bound_json_ref(batch["config"])
            ):
                raise ValueError("ordered disjoint source Content/configured batch interval")
        seen.add(binding["path"])
        cursor += batch["batch_count"]
    if cursor != cfg["batch_start"] + cfg["batch_count"]:
        raise ValueError("actual batch union does not cover published interval")
    return cfg
