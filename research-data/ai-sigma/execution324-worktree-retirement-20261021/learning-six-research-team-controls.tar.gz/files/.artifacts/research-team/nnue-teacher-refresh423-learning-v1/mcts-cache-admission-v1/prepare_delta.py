"""Layer only the new producer metadata branch over the frozen learner target."""

import gzip
import hashlib
from pathlib import Path

OWN = Path(__file__).resolve().parent
before = (OWN.parent / "common.py").read_bytes()
assert (
    hashlib.sha256(before).hexdigest()
    == "e5dc86b500f99fc6d14d218f8286a410b41676ef61a8c34e3c50d14f161388af"
)
text = before.decode()
old = '    c = manifest["common_corpus"]\n'
new = """    mcts_fields = {"mcts_source", "mcts_datasets", "mcts_native_configs"}
    mcts = bool(mcts_fields.intersection(manifest))
    if mcts and not mcts_fields.issubset(manifest):
        raise ValueError("complete MCTS source metadata required")
    c = manifest["common_corpus"]
"""
assert text.count(old) == 1
text = text.replace(old, new)
assert text.count('or c["rootmean_is_raw"] is not False') == 1
text = text.replace('or c["rootmean_is_raw"] is not False', 'or c["rootmean_is_raw"] is not mcts')
anchor = '    seen, cursor = set(), cfg["batch_start"]\n'
insert = """    if mcts:
        model, datasets, configs = (
            manifest["mcts_source"],
            manifest["mcts_datasets"],
            manifest["mcts_native_configs"],
        )
        if (
            not isinstance(model, dict)
            or set(model) != {"model_sha256", "completed_simulations"}
            or not digest(model["model_sha256"])
            or type(model["completed_simulations"]) is not int
            or not 0 < model["completed_simulations"] < 2**32
            or not bound_json_ref(configs)
            or not Path(configs["path"]).is_absolute()
            or configs["sha256"] != manifest["dataset_sha"]
            or not isinstance(datasets, list)
            or len(datasets) != len(sources)
        ):
            raise ValueError("published MCTS model/simulations/ordered native config lineage")
        if any(
            not isinstance(dataset, dict)
            or set(dataset) != {"dataset", "manifest_sha256", "rows"}
            or not isinstance(dataset["dataset"], str)
            or not Path(dataset["dataset"]).is_absolute()
            or not digest(dataset["manifest_sha256"])
            or type(dataset["rows"]) is not int
            or dataset["rows"] < 0
            for dataset in datasets
        ) or sum(dataset["rows"] for dataset in datasets) != manifest["rows"]:
            raise ValueError("published MCTS dataset manifest/row census")
    seen, cursor = set(), cfg["batch_start"]
"""
assert text.count(anchor) == 1
text = text.replace(anchor, insert)
start = text.index(
    '        compressed = source["compressed"]\n', text.index("def common_cache_config(")
)
end = text.index('        seen.add(binding["path"])\n', start)
alpha = text[start:end]
mcts_branch = """        if mcts:
            dataset = datasets[len(seen)]
            if (
                not isinstance(source, dict)
                or set(source) != {"encoding", "manifest"}
                or source["encoding"] != "native-teacher-dataset-shards-v1"
                or not bound_json_ref(binding)
                or not Path(binding["path"]).is_absolute()
                or source["manifest"] != binding
                or binding != {
                    "path": str(Path(dataset["dataset"]) / "manifest.json"),
                    "sha256": dataset["manifest_sha256"],
                }
                or binding["path"] in seen
                or set(batch) != {"batch_start", "batch_count", "config"}
                or type(batch["batch_start"]) is not int
                or batch["batch_start"] != cursor
                or type(batch["batch_count"]) is not int
                or batch["batch_count"] <= 0
                or not bound_json_ref(batch["config"])
                or not Path(batch["config"]["path"]).is_absolute()
            ):
                raise ValueError("ordered MCTS source manifest/configured batch interval")
        else:
"""
text = (
    text[:start]
    + mcts_branch
    + "".join("    " + line if line.strip() else line for line in alpha.splitlines(True))
    + text[end:]
)
(OWN / "common.py").write_text(text)
start = before.index(b"def common_cache_config(")
(OWN / "common_cache_config.before.py.gz").write_bytes(gzip.compress(before[start:], mtime=0))
print("new metadata-only admission derivative prepared")
