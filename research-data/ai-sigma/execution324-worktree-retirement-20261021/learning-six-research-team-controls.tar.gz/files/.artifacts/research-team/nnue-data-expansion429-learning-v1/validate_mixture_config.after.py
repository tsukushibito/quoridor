def validate_mixture_config(config, incoming):
    """All scientific mixture choices must be explicit, including null row cap."""
    m, t, e = config["mixture"], config["training"], config["evaluation"]
    keys = set(incoming.get("mixture", {}))
    if not set(MIXTURE_FIELDS) <= keys or keys - set(MIXTURE_FIELDS) - MIXTURE_OPTIONS:
        raise ValueError("complete explicit mixture settings required; no selected defaults")
    decay = m["public_file_decay"]
    if decay is not None and (
        type(decay) not in (int, float) or not math.isfinite(decay) or not 0 < decay <= 1
    ):
        raise ValueError("public file-order decay must be null or finite in (0,1]")
    if decay is not None and (type(m["public_rows"]) is not int or m["public_rows"] <= 0):
        raise ValueError("file-weighted sampling requires a public training portion")
    if decay is not None and (
        type(m["public_acceptance_seed"]) is not int or m["public_acceptance_seed"] < 0
    ):
        raise ValueError("explicit independent public acceptance seed required")
    rows = m["training_rows"]
    if rows is not None and (
        type(rows) is not int
        or rows <= 0
        or math.ceil(rows / t["batch_size"]) != t["steps"]
        or (rows % t["batch_size"] and m["added_rows"] and m["public_rows"])
    ):
        raise ValueError(
            "exact training rows/update count; partial mixed-source ratio is not configured"
        )
    public_evaluation = m["public_evaluation"]
    if public_evaluation is not None and (
        not isinstance(public_evaluation, dict)
        or set(public_evaluation) != {"validation", "train_diagnostic"}
        or public_evaluation["validation"] not in ("checkpoints", "best")
        or type(public_evaluation["train_diagnostic"]) is not bool
        or (
            public_evaluation["validation"] == "best"
            and (
                not isinstance(m["selector"], dict)
                or m["selector"].get("public_non_regression") is not False
            )
        )
    ):
        raise ValueError("explicit public scopes; frozen BEST monitoring cannot select checkpoints")
    cap = m["train_family_row_cap"]
    if cap is not None and (type(cap) is not int or cap <= 0):
        raise ValueError("train_family_row_cap must be null or positive integer")
    if m["train_stock_strata"] is not None:
        if cap is not None:
            raise ValueError("choose either family cap or game stock strata")
        validate_stock_strata(m["train_stock_strata"])
    for name in ("output_limit_bytes",):
        if type(m[name]) is not int or m[name] <= 0:
            raise ValueError("positive mixture setting: " + name)
    for name in (
        "added_rows",
        "public_rows",
        "public_sampling_seed",
        "added_sampling_seed",
        "added_reflection_seed",
        "public_reflection_seed",
        "diagnostic_seed",
    ):
        if type(m[name]) is not int or m[name] < 0:
            raise ValueError("nonnegative mixture setting: " + name)
    if (
        type(m["added_exposures"]) not in (int, float)
        or not math.isfinite(m["added_exposures"])
        or m["added_exposures"] <= 0
    ):
        raise ValueError("finite positive added exposure limit")
    for name in ("added_reflection_probability", "public_reflection_probability"):
        if type(m[name]) not in (int, float) or not math.isfinite(m[name]) or not 0 <= m[name] <= 1:
            raise ValueError("finite source reflection probability: " + name)
    if (
        not isinstance(m["selector"], dict)
        or set(m["selector"]) != {"public_non_regression", "added_metric"}
        or type(m["selector"]["public_non_regression"]) is not bool
        or m["selector"]["added_metric"] not in ("mse", "family_mse")
    ):
        raise ValueError("explicit optional public nonregression selector required")
    for name in ("public_membership", "public_acceptance", "training_view"):
        ref = m.get(name) if name == "training_view" else m[name]
        if name == "training_view" and ref is None:
            continue
        if (
            not isinstance(ref, dict)
            or set(ref) != {"path", "sha256", "bytes", "mode"}
            or not isinstance(ref["path"], str)
            or not ref["path"]
            or type(ref["bytes"]) is not int
            or not 0 < ref["bytes"] <= (4 * 1024**2 if name == "training_view" else 1024**2)
            or not isinstance(ref["sha256"], str)
            or len(ref["sha256"]) != 64
            or any(v not in "0123456789abcdef" for v in ref["sha256"])
            or ref["mode"] not in ("0600", "0644")
        ):
            raise ValueError("actual bounded public membership/custody FileRef: " + name)
    if (
        t["target"] != "z"
        or t["batch_size"] != m["added_rows"] + m["public_rows"]
        or type(t["steps"]) is not int
        or t["steps"] <= 0
        or type(config["limits"]["samples"]) is not int
        or config["limits"]["samples"] <= 0
        or e["diagnostic_rows"] <= 0
        or t["scheduler"] != "none"
        or e["early_stopping_unit"] != "observation"
        or t["supply_workers"] != 0
    ):
        raise ValueError(
            "finite full-batch outcome mixture, all-work limit, observation selector and synchronous GPU supply required"
        )
    if t["reflection_probability"] != 0:
        raise ValueError(
            "source reflection configured only in mixture; no duplicate global augmentation"
        )
    if (
        config["experiment"]["teacher_mapping"] is not None
        or config["experiment"]["condition"] is not None
    ):
        raise ValueError("outcome mixture has no raw teacher mapping or paired arm selector")
