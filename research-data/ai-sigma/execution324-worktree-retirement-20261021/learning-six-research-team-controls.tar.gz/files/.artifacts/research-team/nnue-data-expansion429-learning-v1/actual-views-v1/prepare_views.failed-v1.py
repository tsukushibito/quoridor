"""Prepare fixed 429 row views and prospective costs; never train or predict."""

from collections import Counter
import copy
import hashlib
import json
import math
from pathlib import Path
import stat
import sys

import numpy as np

from quoridor_training.common import bound_file_bytes, resolve_config
from quoridor_training.public_features import model_keys, reflect
from quoridor_training.public_replay import planned_work, training_view_indices
from quoridor_training.sampling import FullBatchSampler, family_training_view
from quoridor_training.terminal_cache import TerminalCorpus

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
DATA = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/"
    "nnue-data-expansion429-data-v1"
)
CACHE = Path("/workspaces/quoridor/.worktree/assets/data/nnue-data-expansion429-v1/cache-v1")
CACHE_SHA = "89d3012d883355093ce11f4b5e718009bb77c8d6d98af6037f8162acb77d2431"
BANDS = [(16, 20), (8, 15), (1, 7), (0, 0)]


def file_ref(path):
    before = path.stat()
    if path.is_symlink() or not stat.S_ISREG(before.st_mode):
        raise ValueError("regular immutable input required: " + str(path))
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for part in iter(lambda: stream.read(65536), b""):
            h.update(part)
    after = path.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (
        after.st_ino,
        after.st_size,
        after.st_mtime_ns,
    ):
        raise ValueError("input changed: " + str(path))
    return {
        "path": str(path),
        "sha256": h.hexdigest(),
        "bytes": before.st_size,
        "mode": format(stat.S_IMODE(before.st_mode), "04o"),
    }


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return file_ref(path)


def read_expected(path, digest, size):
    ref = {"path": str(path), "sha256": digest, "bytes": size, "mode": "0644"}
    return json.loads(bound_file_bytes(ref, 3 * 1024 * 1024)), ref


def main():
    census, census_ref = read_expected(
        DATA / "cache-census.json",
        "71d8823aab002b5efbe5bd76118a2e998a60158f36a1a81bc76067f911265e6e",
        6545,
    )
    games, games_ref = read_expected(
        DATA / "cache-game-correspondence.json",
        "650819a34630771c4202552d116811cb4aa5832b0651fff71ab86be18efd23a6",
        543454,
    )
    recipe_ref = file_ref(OWN / "settings.proposed.json")
    if recipe_ref["sha256"] != "7f9674ff3b851d71b8ca9274d6efbdabbb9fc683db87c88494d3a50e6dd23bd4":
        raise ValueError("frozen result-blind recipe changed")
    recipe = json.loads(bound_file_bytes(recipe_ref, 65536))
    selected = json.loads((OWN / "saved423-selected-settings.json").read_bytes())
    base_ref = selected["historical_423_materializer_base"]
    base = json.loads(bound_file_bytes(base_ref, 16384))["C"]
    membership_ref = base["mixture"]["public_membership"]
    membership = json.loads(bound_file_bytes(membership_ref, 65536))
    public_rows = {
        part["name"]: part["rows"]
        for part in membership["partitions"]
        if part["name"] in ("train", "validation")
    }
    assert public_rows == {"train": 8413949, "validation": 419150}
    cache_ref = census["cache"]
    assert cache_ref["sha256"] == CACHE_SHA
    bound_file_bytes(cache_ref, 3 * 1024 * 1024)
    source_refs = []
    for module in sorted(sys.modules):
        if module.startswith("quoridor_training."):
            source = getattr(sys.modules[module], "__file__", None)
            if source and source.endswith(".py"):
                source_refs.append(file_ref(Path(source)))
    assert "torch" not in sys.modules
    corpus = None
    primary = None
    cleanup = []
    try:
        corpus = TerminalCorpus(CACHE)
        assert corpus.manifest_sha == CACHE_SHA and corpus.row_count == 62186
        for ref in census["cache_file_refs"]:
            name = Path(ref["path"]).name
            assert corpus.manifest["sha256"][name] == ref["sha256"]
            assert corpus.manifest["file_bytes"][name] == ref["bytes"]
        assert len(games) == len(corpus.game_names) == 1204
        geometry = corpus.maps[0]["geometry"]
        stock = geometry["stocks"].sum(axis=1)
        cohort = np.empty(corpus.row_count, dtype=np.uint8)
        row_game = np.empty(corpus.row_count, dtype=np.uint32)
        for code, game in enumerate(games):
            start, count = game["cache_rows"]["start"], game["cache_rows"]["count"]
            end = start + count
            assert corpus.game_names[code] == game["row_game_id"]
            assert game["row_game_id"] == "game-" + str(game["global_ordinal"])
            assert game["source_index"] == game["global_ordinal"] // 8
            assert game["cohort"] == ("early" if game["global_ordinal"] % 5 == 4 else "quantity")
            assert np.all(corpus.row_game_codes[start:end] == code)
            assert all(
                corpus.families[int(v)] == game["canonical_family"]
                for v in corpus.groups[start:end]
            )
            split = 0 if game["final_view_split"] == "train" else 1
            assert game["final_view_split"] == game["source_split"]
            assert np.all(corpus.splits[start:end] == split)
            cohort[start:end] = int(game["cohort"] == "early")
            row_game[start:end] = code
        strata = [dict(min=a, max=b, rows=8) for a, b in BANDS]
        candidates = family_training_view(
            corpus.groups,
            corpus.splits,
            corpus.eligible,
            None,
            games=corpus.row_game_codes,
            stock=stock,
            strata=strata,
        )
        assert len(candidates) == 18822
        assert Counter(cohort[candidates].tolist()) == {0: 14959, 1: 3863}
        validation = np.flatnonzero(corpus.eligible & (corpus.splits == 1))
        assert len(validation) == 12275
        keys, orbits = [], []
        # Exact maintained injective keys avoid dense FP32 input copies. Reflection
        # uses the same unchanged codec; distances and STM are not transformed.
        for first in range(0, corpus.row_count, 1024):
            records = corpus.maps[0][first : first + 1024]
            literal = [key.tobytes() for key in model_keys(records)]
            reflected = records.copy()
            reflected["geometry"] = reflect(records["geometry"])
            reflected_keys = [key.tobytes() for key in model_keys(reflected)]
            keys.extend(literal)
            orbits.extend(min(a, b) for a, b in zip(literal, reflected_keys, strict=True))
        assert len(set(keys)) == 62043
        v_orbits = {orbits[int(i)] for i in validation}
        excluded_families = {
            int(corpus.groups[i])
            for i in np.flatnonzero(corpus.eligible & (corpus.splits == 0))
            if orbits[int(i)] in v_orbits
        }

        def rank(index):
            game = games[int(row_game[index])]
            lineage = [
                "429-training-view-rank-v1",
                recipe["seeds"]["view_ranking"],
                game["source_schedule_sha256"],
                game["global_ordinal"],
                corpus.row_ids[index],
            ]
            body = json.dumps(lineage, separators=(",", ":")).encode()
            return hashlib.sha256(body).digest(), tuple(map(str, lineage))

        ranked = sorted(map(int, candidates), key=rank)
        representatives = {}
        alias_rows = []
        for index in ranked:
            if int(corpus.groups[index]) in excluded_families:
                continue
            key = keys[index]
            if key in representatives:
                other = representatives[key]
                assert int(stock[index]) == int(stock[other])
                assert cohort[index] == cohort[other]
                alias_rows.append({"representative": other, "omitted_row": index})
            else:
                representatives[key] = index
        reps = list(representatives.values())
        quantity = [[i for i in reps if cohort[i] == 0 and a <= stock[i] <= b] for a, b in BANDS]
        for bank in quantity:
            bank.sort(key=rank)
        capacities = [len(bank) for bank in quantity]
        quarters = [n // 4 for n in capacities]
        size = min(3763, sum(quarters))
        if not size:
            raise ValueError("no feasible nested quantity input")
        total = sum(quarters)
        quotas = [size * k // total for k in quarters]
        remainder_order = sorted(range(4), key=lambda j: (-(size * quarters[j] % total), j))
        for j in remainder_order[: size - sum(quotas)]:
            quotas[j] += 1
        assert sum(quotas) == size and all(q <= k for q, k in zip(quotas, quarters, strict=True))
        small = sorted(i for bank, n in zip(quantity, quotas, strict=True) for i in bank[:n])
        large = sorted(i for bank, n in zip(quantity, quotas, strict=True) for i in bank[: 4 * n])
        early = sorted((i for i in reps if cohort[i] == 1), key=rank)
        views = {"quantity-small": small, "quantity-large": large}
        if len(early) >= size:
            views["early-matched"] = sorted(early[:size])
        view_refs = {}
        descriptions = {}
        for name, indices in views.items():
            assert len(indices) == len(set(keys[i] for i in indices))
            assert all(corpus.eligible[i] and corpus.splits[i] == 0 for i in indices)
            assert all(orbits[i] not in v_orbits for i in indices)
            per_game_band = Counter(
                (int(row_game[i]), next(j for j, (a, b) in enumerate(BANDS) if a <= stock[i] <= b))
                for i in indices
            )
            assert max(per_game_band.values()) <= 8
            view_refs[name] = save(
                name + ".training-view.json",
                {"cache_manifest_sha256": CACHE_SHA, "indices": indices},
            )
            assert training_view_indices(view_refs[name], CACHE_SHA, candidates) == indices
            descriptions[name] = {
                "rows": len(indices),
                "literal_model_input_distinct": len(indices),
                "LR_orbits": len({orbits[i] for i in indices}),
                "games": len({int(row_game[i]) for i in indices}),
                "families": len({int(corpus.groups[i]) for i in indices}),
                "stock_histogram": dict(sorted(Counter(int(stock[i]) for i in indices).items())),
                "stock18_to20": sum(18 <= stock[i] <= 20 for i in indices),
                "stock_band_rows": [sum(a <= stock[i] <= b for i in indices) for a, b in BANDS],
                "max_rows_per_game_stock_band": max(per_game_band.values()),
                "per_game_selected_rows": dict(
                    sorted(Counter(corpus.game_names[int(row_game[i])] for i in indices).items())
                ),
            }
        assert set(small) <= set(large) and len(large) == 4 * len(small)
        assert descriptions["quantity-large"]["stock_band_rows"] == [
            4 * n for n in descriptions["quantity-small"]["stock_band_rows"]
        ]
        conditions = [
            ("Q-small-8exposure", "quantity-small", 8 * size, 8),
            ("Q-large-fixed-draws", "quantity-large", 8 * size, 2),
            ("Q-large-8exposure", "quantity-large", 32 * size, 8),
        ]
        if "early-matched" in views:
            conditions.append(("early-matched-8exposure", "early-matched", 8 * size, 8))
        plans = {}
        config_refs = {}
        exposure_refs = {}
        for name, view, draws, exposures in conditions:
            cfg = copy.deepcopy(base)
            updates = math.ceil(draws / 256)
            points = sorted({0, math.ceil(updates / 3), math.ceil(2 * updates / 3), updates})
            cfg["optimizer"].update(lr=1e-4, weight_decay=0)
            cfg["training"].update(
                batch_size=256,
                steps=updates,
                seed=recipe["seeds"]["training"],
                warmup_steps=min(10, updates),
                reflection_seed=recipe["seeds"]["reflection"],
                threads=2,
                device="cpu",
            )
            cfg["evaluation"].update(
                checkpoints=points,
                diagnostic_checkpoints=points,
                diagnostic_rows=8192,
                full_train=False,
                full_train_checkpoints=[],
                early_stopping_patience=0,
            )
            cfg["mixture"].update(
                train_family_row_cap=None,
                train_stock_strata=strata,
                training_view=view_refs[view],
                added_rows=256,
                public_rows=0,
                added_exposures=exposures,
                training_rows=draws,
                added_sampling_seed=recipe["seeds"]["added_row_order"],
                added_reflection_seed=recipe["seeds"]["reflection"],
                added_reflection_probability=0.5,
                diagnostic_seed=recipe["seeds"]["public_T_diagnostic"],
                public_file_decay=None,
                public_acceptance_seed=None,
                public_evaluation={"validation": "best", "train_diagnostic": True},
                selector={"public_non_regression": False, "added_metric": "family_mse"},
            )
            cfg = resolve_config(cfg)
            plan = planned_work(
                cfg, len(views[view]), len(validation), public_rows, reuse_initial=False
            )
            assert plan["updates"] == updates and plan["training_forwards"] == draws
            cfg["limits"]["samples"] = plan["forward_upper"]
            # These are proposed ordinary configs, no Experiment/support/launch.
            config_refs[name] = save(name + ".config.proposed.json", cfg)
            sampler = FullBatchSampler(
                np.asarray(views[view]), 256, recipe["seeds"]["added_row_order"]
            )
            counts = Counter()
            stream_hash = hashlib.sha256()
            remaining = draws
            while remaining:
                part = sampler.take(min(256, remaining))
                stream_hash.update(np.asarray(part, dtype="<u4").tobytes())
                counts.update(map(int, part))
                remaining -= len(part)
            assert set(counts) == set(views[view]) and set(counts.values()) == {exposures}
            exposure_refs[name] = save(
                name + ".planned-exposure.json",
                {
                    "status": "DETERMINISTIC_SAMPLER_PLAN_NOT_ACTUAL_TRAINING",
                    "seed": recipe["seeds"]["added_row_order"],
                    "draws": draws,
                    "ordered_u32_stream_sha256": stream_hash.hexdigest(),
                    "rows": [{"index": i, "count": counts[i]} for i in sorted(counts)],
                },
            )
            plans[name] = {
                "view": view,
                "selected_rows": len(views[view]),
                "training_draws": draws,
                "updates": updates,
                "full_batches": draws // 256,
                "tail": draws % 256,
                "mean_exposures": exposures,
                "normal_planned_work_no_INITIAL_credit": plan,
                "config": config_refs[name],
                "planned_exposure": exposure_refs[name],
            }
        summary = {
            "status": "ACTUAL_RESULT_BLIND_VIEWS_AND_FOUR_CONDITION_COST_PROPOSAL_NOT_SCIENCE_READY",
            "scientific_execution_authorized": False,
            "inputs": [cache_ref, census_ref, games_ref, recipe_ref, base_ref, membership_ref],
            "actual_cache_rows": corpus.row_count,
            "actual_all_shared_V": len(validation),
            "base_strata_T": len(candidates),
            "quantity_capacities_distinct_by_band": capacities,
            "quantity_floor_quarter_capacities": quarters,
            "small_quota_by_band": quotas,
            "actual_Nq": size,
            "actual_4Nq": 4 * size,
            "quantity_target_shortfalls": [3763 - size, 15052 - 4 * size],
            "early_available_distinct": len(early),
            "early_missing_to_match": max(0, size - len(early)),
            "T_families_excluded_for_literal_or_LR_alias_with_any_sharedV": [
                corpus.families[i] for i in sorted(excluded_families)
            ],
            "base_T_literal_alias_rows_removed": alias_rows,
            "key_definition": "maintained injective geometry+FP32distance model_keys (equivalent exact nativeQF1 input); LR reflect unchanged codec, not independent samples",
            "rank_domain": "429-training-view-rank-v1",
            "selection_depends_on_outcome_values": False,
            "source_OUTCOME_sanity": "normal TerminalCorpus input validation only; labels not used in rank/quota/selection",
            "old423_direct_model_input_overlap": "UNKNOWN/not reopened; no oldT inclusion, native canonical closure exclusion retained",
            "views": descriptions,
            "view_refs": view_refs,
            "prospective_conditions": plans,
            "proposed_all_fit_training_forwards": sum(v["training_draws"] for v in plans.values()),
            "proposed_all_fit_forward_upper_no_INITIAL_credit": sum(
                v["normal_planned_work_no_INITIAL_credit"]["forward_upper"] for v in plans.values()
            ),
            "changed_weight_work_or_strength_cost": None,
            "actual_Experiment_support_runtime_weights_INITIAL_observation": None,
            "unused_B_Sigma_cap_not_transferred": True,
            "source_refs": source_refs,
            "actual_model_forward_fit_Search_arena": 0,
            "sampler_simulation": "row-index/exposure metadata only; no model or feature forward",
            "constructor_context_peak_globalactual": "UNKNOWN",
        }
        save("summary.json", summary)
    except BaseException as error:
        primary = error
    finally:
        if corpus is not None:
            handles = {}
            for value in vars(corpus).values():
                for item in value if isinstance(value, list) else [value]:
                    handle = getattr(item, "_mmap", None)
                    if handle is not None:
                        handles.setdefault(id(handle), handle)
            for handle in handles.values():
                try:
                    handle.close()
                    cleanup.append({"closed": True})
                except BaseException as error:
                    cleanup.append({"closed": False, "error": repr(error)})
        after_errors = []
        for ref in [
            cache_ref,
            census_ref,
            games_ref,
            recipe_ref,
            base_ref,
            membership_ref,
            *census["cache_file_refs"],
            *source_refs,
        ]:
            try:
                assert file_ref(Path(ref["path"])) == ref
            except BaseException as error:
                after_errors.append({"path": ref["path"], "error": repr(error)})
        result = {
            "primary": repr(primary) if primary else None,
            "map_close_attempts": cleanup,
            "after_identity_errors": after_errors,
            "actual_model_forwards": 0,
            "torch_imported": "torch" in sys.modules,
        }
        save("reader-finalization.json", result)
        if primary:
            for item in cleanup + after_errors:
                if item.get("closed") is False or "error" in item:
                    primary.add_note(str(item))
            raise primary
        if any(not item["closed"] for item in cleanup) or after_errors:
            raise ValueError("metadata/map finalization failed; inspect reader-finalization.json")
        assert "torch" not in sys.modules
    print(
        json.dumps(
            {
                "saved": str(OUT / "summary.json"),
                "new_model_forwards": 0,
                "actual_Nq": size,
                "actual_4Nq": 4 * size,
                "early_available": len(early),
                "shared_V": len(validation),
            }
        )
    )


if __name__ == "__main__":
    main()
