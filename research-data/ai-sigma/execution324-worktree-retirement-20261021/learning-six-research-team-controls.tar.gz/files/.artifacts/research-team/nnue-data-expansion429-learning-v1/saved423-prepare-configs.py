"""Use final actual cache counts to materialize four configs; never launch science."""

import argparse
import copy
import hashlib
import json
from pathlib import Path


def resolved_four(base, spec, rows, validation_rows, public_rows, *, final_scale_fixed):
    from quoridor_training.common import resolve_config
    from quoridor_training.public_replay import planned_work

    if final_scale_fixed is not True:
        raise ValueError(
            "pilot is not the main study; actual one-time scale and final view must be fixed"
        )
    if (
        type(rows) is not int
        or rows <= 0
        or type(validation_rows) is not int
        or validation_rows <= 0
    ):
        raise ValueError("actual nonempty final selected T/all V required")
    seeds = spec["seeds"]
    configs, plans = {}, {}
    for arm in ("U", "R", "W", "F"):
        cfg = copy.deepcopy(base)
        fresh = arm == "F"
        public = arm in ("U", "R")
        actual_rows = min((64 if fresh else 8) * rows, 524288 if fresh else 32768)
        updates = (actual_rows + 255) // 256
        points = sorted({0, (updates + 2) // 3, (2 * updates + 2) // 3, updates})
        cfg["optimizer"]["lr"] = 1e-3 if fresh else 1e-4
        cfg["training"].update(
            batch_size=256,
            steps=updates,
            warmup_steps=min(20 if fresh else 10, updates),
            seed=seeds["F_fresh_initialization"] if fresh else seeds["U_R_W_training_base"],
            reflection_seed=seeds["reflection_stream"],
        )
        cfg["evaluation"].update(
            checkpoints=points,
            diagnostic_checkpoints=points,
            diagnostic_rows=8192,
            full_train=False,
            full_train_checkpoints=[],
            early_stopping_patience=0,
        )
        m = cfg["mixture"]
        m.update(
            train_family_row_cap=None,
            train_stock_strata=[
                dict(min=a, max=b, rows=8) for a, b in ((16, 20), (8, 15), (1, 7), (0, 0))
            ],
            added_rows=0 if public else 256,
            public_rows=256 if public else 0,
            added_exposures=64 if fresh else 8,
            training_rows=actual_rows,
            added_sampling_seed=seeds["W_F_shuffled_row_stream"],
            public_sampling_seed=seeds["U_R_uniform_proposal_stream"],
            public_acceptance_seed=seeds["R_acceptance_stream"] if arm == "R" else None,
            public_file_decay=0.92 if arm == "R" else None,
            added_reflection_probability=0.5,
            public_reflection_probability=0.5,
            added_reflection_seed=seeds["reflection_stream"],
            public_reflection_seed=seeds["reflection_stream"],
            diagnostic_seed=seeds["fixed_public_T_panel"],
            public_evaluation={"validation": "best", "train_diagnostic": True},
        )
        m["selector"] = {"public_non_regression": False, "added_metric": "family_mse"}
        if fresh:
            cfg["experiment"]["warm_start"].update(weights=None, evaluator_sha256=None)
        plan = planned_work(cfg, rows, validation_rows, public_rows)
        cfg["limits"]["samples"] = plan["forward_upper"]
        configs[arm], plans[arm] = resolve_config(cfg), plan
    # No INITIAL credit is taken without an actual saved model/scope observation.
    if (
        sum(p["forward_upper"] for p in plans.values()) + 1024
        > spec["training_schedule"]["logical_forward_ceiling"]
    ):
        raise ValueError(
            "four full plans plus changed-weight correspondence exceed whole forward cap"
        )
    return configs, plans


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--final-scale-fixed",
        action="store_true",
        help="Root has made the actual one-time postpilot scale/final T/V resolution",
    )
    args = parser.parse_args()
    if not args.final_scale_fixed:
        parser.error("no four-fit materialization from pilot alone")
    import numpy as np
    from quoridor_training.common import bound_file_bytes
    from quoridor_training.sampling import family_training_view
    from quoridor_training.terminal_cache import TerminalCorpus

    # Fixed scientific spec is a normal existing FileRef, never a future artifact.
    refs = json.loads(Path(__file__).with_name("fixed-spec-refs.json").read_bytes())
    spec = json.loads(bound_file_bytes(refs["spec.json"], 65536))
    old = (
        Path(__file__).resolve().parent.parent
        / "nnue-diverse421-learning-v1/settings.SELECTED.json"
    )
    base = json.loads(
        bound_file_bytes(
            {
                "path": str(old),
                "sha256": "fcc935ca187172aa238ff972b6f11db1d4d0812aca12960f20afe4ceaea99a3d",
                "bytes": 9422,
                "mode": "0644",
            },
            16384,
        )
    )["C"]
    corpus = TerminalCorpus(args.cache)
    primary = None
    try:
        strata = [dict(min=a, max=b, rows=8) for a, b in ((16, 20), (8, 15), (1, 7), (0, 0))]
        selected = family_training_view(
            corpus.groups,
            corpus.splits,
            corpus.eligible,
            None,
            games=corpus.row_game_codes,
            stock=corpus.maps[0]["geometry"]["stocks"].sum(axis=1),
            strata=strata,
        )
        validation_rows = int(np.count_nonzero(corpus.eligible & (corpus.splits == 1)))
        membership = json.loads(bound_file_bytes(base["mixture"]["public_membership"], 65536))
        counts = {
            p["name"]: p["rows"]
            for p in membership["partitions"]
            if p["name"] in ("train", "validation")
        }
        configs, plans = resolved_four(
            base, spec, len(selected), validation_rows, counts, final_scale_fixed=True
        )
        args.output.mkdir(exist_ok=False)
        for arm, cfg in configs.items():
            (args.output / ("fit-" + arm + ".json")).write_text(json.dumps(cfg, indent=2) + "\n")
        summary = {
            "actual_cache_manifest": str((args.cache / "cache.json").resolve()),
            "cache_manifest_sha256": hashlib.sha256(
                (args.cache / "cache.json").read_bytes()
            ).hexdigest(),
            "actual_selected_newT_rows": len(selected),
            "actual_all_newV_rows": validation_rows,
            "plans_without_assumed_INITIAL_alias": plans,
            "changed_weight_forward_reserve": 1024,
            "whole_forward_upper": sum(p["forward_upper"] for p in plans.values()) + 1024,
            "whole_forward_cap": spec["training_schedule"]["logical_forward_ceiling"],
            "final_scale_fixed_by_actual_Root_resolution": True,
            "spec": refs["spec.json"],
            "science_launched": False,
            "runtime_refs_not_created": ["weights", "Experiment", "new INITIAL observation"],
        }
        (args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "output": str(args.output),
                    "R": len(selected),
                    "forward_upper": summary["whole_forward_upper"],
                }
            )
        )
    except BaseException as error:
        primary = error
        raise
    finally:
        try:
            corpus.verify_binding()
        except BaseException as error:
            if primary is not None:
                raise BaseExceptionGroup(
                    "config preparation and cache identity failed", [primary, error]
                ) from None
            raise


if __name__ == "__main__":
    main()
