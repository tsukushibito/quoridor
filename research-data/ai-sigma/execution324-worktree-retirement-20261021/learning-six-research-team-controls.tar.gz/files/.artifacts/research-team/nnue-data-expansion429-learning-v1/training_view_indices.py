def training_view_indices(ref, cache_manifest_sha256, candidates):
    """A bound subset of the existing T-only capped view, never a new split."""
    if ref is None:
        return candidates
    view = json.loads(bound_file_bytes(ref, 4 * 1024**2))
    if (
        not isinstance(view, dict)
        or set(view) != {"cache_manifest_sha256", "indices"}
        or view["cache_manifest_sha256"] != cache_manifest_sha256
    ):
        raise ValueError("training view must bind the actual compact cache")
    indices = view["indices"]
    if (
        not isinstance(indices, list)
        or not indices
        or any(type(i) is not int for i in indices)
        or indices != sorted(set(indices))
        or not set(indices) <= set(map(int, candidates))
    ):
        raise ValueError("nonempty unique chronological subset of configured eligible T required")
    return indices
