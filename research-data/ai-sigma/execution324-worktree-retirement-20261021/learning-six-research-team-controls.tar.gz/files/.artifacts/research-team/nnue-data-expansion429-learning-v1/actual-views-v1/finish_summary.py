"""Publish existing 429 view results after a summary-only JSON scalar failure."""

from bisect import bisect_right
from collections import Counter
import hashlib
import json
from pathlib import Path
import stat
import sys

import numpy as np

from quoridor_training.public_features import RECORD

OUT = Path(__file__).resolve().parent
B = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/"
    "nnue-data-expansion429-data-v1"
)
BANDS = [(16, 20), (8, 15), (1, 7), (0, 0)]


def ref(path):
    body = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(body).hexdigest(),
        "bytes": len(body),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


def main():
    partial = (OUT / "summary.json").read_text()
    # Restore only the complete, already-persisted prefix. The original invalid
    # JSON and original FAILED process receipt are never overwritten.
    marker = '  "views": {'
    if partial.count(marker) != 1:
        raise ValueError("unexpected original partial summary boundary")
    summary = json.loads(partial.split(marker)[0].rstrip().removesuffix(",") + "\n}")
    games_path = B / "cache-game-correspondence.json"
    if (
        ref(games_path)["sha256"]
        != "650819a34630771c4202552d116811cb4aa5832b0651fff71ab86be18efd23a6"
    ):
        raise ValueError("original correspondence changed")
    games = json.loads(games_path.read_bytes())
    starts = [game["cache_rows"]["start"] for game in games]
    census = json.loads((B / "cache-census.json").read_bytes())
    geometry_ref = next(x for x in census["cache_file_refs"] if x["path"].endswith("/geometry.bin"))
    geometry_path = Path(geometry_ref["path"])
    before = geometry_path.stat()
    if geometry_path.is_symlink() or before.st_size != geometry_ref["bytes"]:
        raise ValueError("original geometry identity changed")
    original_outputs = (
        sorted(OUT.glob("*.training-view.json"))
        + sorted(OUT.glob("*.config.proposed.json"))
        + sorted(OUT.glob("*.planned-exposure.json"))
    )
    output_refs = [ref(path) for path in original_outputs]
    records = np.memmap(geometry_path, mode="r", dtype=RECORD, shape=(62186,))
    closed = False
    primary = None
    try:
        descriptions = {}
        views = {}
        for path in sorted(OUT.glob("*.training-view.json")):
            name = path.name.removesuffix(".training-view.json")
            indices = json.loads(path.read_bytes())["indices"]
            views[name] = ref(path)
            # Only descriptive missing publication fields for FIXED saved rows:
            # no candidate extraction, ranking, re-selection, or key checking.
            stocks = records["geometry"]["stocks"][indices].sum(axis=1).tolist()
            codes = [bisect_right(starts, i) - 1 for i in indices]
            descriptions[name] = {
                "rows": len(indices),
                "literal_model_input_distinct": len(indices),
                "distinct_evidence": "original materialization-v2 assertions completed before summary publication failed; not replayed",
                "LR_orbits": None,
                "LR_orbit_missingness": "not persisted before JSON failure; not recomputed for this publication repair",
                "games": len(set(codes)),
                "families": len({games[code]["canonical_family"] for code in codes}),
                "stock_histogram": dict(sorted(Counter(stocks).items())),
                "stock18_to20": sum(18 <= value <= 20 for value in stocks),
                "stock_band_rows": [sum(a <= value <= b for value in stocks) for a, b in BANDS],
                "per_game_selected_rows": dict(
                    sorted(Counter(games[code]["row_game_id"] for code in codes).items())
                ),
            }
        plans = {}
        for path in sorted(OUT.glob("*.config.proposed.json")):
            name = path.name.removesuffix(".config.proposed.json")
            config = json.loads(path.read_bytes())
            exposure_path = OUT / (name + ".planned-exposure.json")
            exposure = json.loads(exposure_path.read_bytes())
            view_ref = config["mixture"]["training_view"]
            view = Path(view_ref["path"]).name.removesuffix(".training-view.json")
            draws = config["mixture"]["training_rows"]
            upper = config["limits"]["samples"]
            updates = config["training"]["steps"]
            plans[name] = {
                "view": view,
                "selected_rows": descriptions[view]["rows"],
                "training_draws": draws,
                "updates": updates,
                "full_batches": draws // 256,
                "tail": draws % 256,
                "mean_exposures": config["mixture"]["added_exposures"],
                "observation_steps": config["evaluation"]["checkpoints"],
                "forward_upper_without_INITIAL_credit": upper,
                "measurement_forwards": upper - draws,
                "frozen_best_public_V_once": 419150,
                "cost_evidence": "original normal planned_work stored in proposed config limits.samples; not re-run",
                "config": ref(path),
                "planned_exposure": ref(exposure_path),
                "planned_ordered_row_stream_sha256": exposure["ordered_u32_stream_sha256"],
                "actual_fit_and_actual_exposures": None,
            }
        summary.update(
            status="SAVED_VIEW_SUMMARY_PUBLICATION_REPAIRED_NOT_SCIENCE_READY",
            views=descriptions,
            view_refs=views,
            prospective_conditions=plans,
            proposed_all_fit_training_forwards=sum(p["training_draws"] for p in plans.values()),
            proposed_all_fit_forward_upper_no_INITIAL_credit=sum(
                p["forward_upper_without_INITIAL_credit"] for p in plans.values()
            ),
            actual_Experiment_support_runtime_weights_INITIAL_observation=None,
            changed_weight_or_strength_cost=None,
            source_index_note="original input-source namespace preserved; not equated to producer slice/globalordinal//8",
            summary_repair="stock sums converted to builtin Python integers only in new publication; original selection/config/sampler outputs unchanged",
            selection_config_exposure_checks_replayed=0,
            no_new_fit_forward_Search_arena_model_or_old_suite=True,
            original_failed_receipts_and_partial_JSON_retained=True,
            old423_model_input_overlap="UNKNOWN; no old cache/RAW reopened",
            original_reader_source_ref_list="NOT_PERSISTED_UNKNOWN; original reader-finalization records all source/input after-identity checks passed",
            original_reader_finalization=ref(OUT / "reader-finalization.json"),
            old_data_and_model_payload_reads=0,
        )
        with (OUT / "summary.repaired.json").open("x") as stream:
            json.dump(summary, stream, indent=2, allow_nan=False)
            stream.write("\n")
    except BaseException as error:
        primary = error
    finally:
        try:
            records._mmap.close()
            closed = True
        except BaseException as error:
            if primary is None:
                primary = error
            else:
                primary.add_note("summary geometry close: " + repr(error))
        after = geometry_path.stat()
        stable = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        )
        result = {
            "primary": repr(primary) if primary else None,
            "geometry_map_closed": closed,
            "geometry_authority": geometry_ref,
            "geometry_before_after_stat_identity_same": stable,
            "geometry_SHA_scope": "original normal reader before/after passed, reused; no fresh payload rehash claimed",
            "geometry_access": "stock fields for already-saved selected indices only",
            "original_outputs_unchanged": output_refs == [ref(path) for path in original_outputs],
            "model_forward_or_fit_or_Selection_config_exposure_replay": 0,
            "torch_imported": "torch" in sys.modules,
        }
        with (OUT / "summary-publication-finalization.json").open("x") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
        if primary:
            raise primary
        if not stable or not result["original_outputs_unchanged"] or result["torch_imported"]:
            raise ValueError("summary-only publication lifetime/output mismatch")
    print(json.dumps({"saved": str(OUT / "summary.repaired.json"), "new_forwards": 0}))


if __name__ == "__main__":
    main()
