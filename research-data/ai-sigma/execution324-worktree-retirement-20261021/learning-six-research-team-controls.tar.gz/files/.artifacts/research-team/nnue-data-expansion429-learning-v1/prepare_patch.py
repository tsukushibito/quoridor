"""Create sparse owner fragments from the already-frozen bounded intake only."""

import gzip
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
common = (OUT / "common.py.scoped.txt").read_text()
prefix = common.split("# python/quoridor_training/common.py:1-125\n", 1)[1].split(
    "\ndef resolve_config(", 1
)[0]
validator = common.split("# python/quoridor_training/common.py:601-721\n", 1)[1].split(
    "\ndef bound_file_bytes(", 1
)[0]
replay = (OUT / "public_replay.py.scoped.txt").read_text()
replay_top = replay.split("# python/quoridor_training/public_replay.py:1-120\n", 1)[1]
replay_tail = replay.split("# python/quoridor_training/public_replay.py:700-855\n", 1)[1]
helper = '''def training_view_indices(ref, cache_manifest_sha256, candidates):
    """A bound subset of the existing T-only capped view, never a new split."""
    if ref is None:
        return candidates
    view = json.loads(bound_file_bytes(ref, 4 * 1024**2))
    if (
        not isinstance(view, dict)
        or set(view) != {"cache_manifest_sha256", "indices"}
        or view["cache_manifest_sha256"] != cache_manifest_sha256
    ):
        raise ValueError("training view must bind the actual compact cache")
    indices = view["indices"]
    if (
        not isinstance(indices, list)
        or not indices
        or any(type(i) is not int for i in indices)
        or indices != sorted(set(indices))
        or not set(indices) <= set(map(int, candidates))
    ):
        raise ValueError("nonempty unique chronological subset of configured eligible T required")
    return indices


'''
prefix_post = prefix.replace(
    '    "training_rows",\n', '    "training_rows",\n    "training_view",\n', 1
).replace("    training_rows=None,\n", "    training_rows=None,\n    training_view=None,\n", 1)
validator_post = validator.replace(
    'for name in ("public_membership", "public_acceptance"):',
    'for name in ("public_membership", "public_acceptance", "training_view"):',
)
validator_post = validator_post.replace(
    "        ref = m[name]\n",
    '        ref = m.get(name) if name == "training_view" else m[name]\n        if name == "training_view" and ref is None:\n            continue\n',
    1,
)
validator_post = validator_post.replace(
    'not 0 < ref["bytes"] <= 1024**2',
    'not 0 < ref["bytes"] <= (4 * 1024**2 if name == "training_view" else 1024**2)',
    1,
)
# Separately retained exact owner fragments; no persistent whole-module mirror.
for n, value in [
    ("common-prefix.before.py", prefix),
    ("common-prefix.after.py", prefix_post),
    ("validate_mixture_config.before.py", validator),
    ("validate_mixture_config.after.py", validator_post),
    ("training_view_indices.py", helper),
]:
    (OUT / n).write_text(value)
anchor = 'STUDY = "mixed-outcome"\n\n\n'
assert anchor in replay_top
module_before = (
    anchor + "def mixed_batch(added, public, added_indices, public_indices, reflection_mask):\n"
)
module_after = (
    anchor
    + helper
    + "def mixed_batch(added, public, added_indices, public_indices, reflection_mask):\n"
)
start = replay_tail.index("            train_rows = family_training_view(")
end = replay_tail.index("            initial_observation_ref = (", start)
rows_before = replay_tail[start:end]
rows_after = rows_before.replace(
    "            validation_rows = np.flatnonzero",
    '            train_rows = np.asarray(\n                training_view_indices(m.get("training_view"), added.manifest_sha, train_rows),\n                dtype=np.int64,\n            )\n            validation_rows = np.flatnonzero',
    1,
)
view_before = '                    "cache_manifest_sha256": added.manifest_sha,\n                    "indices": train_rows.tolist(),\n'
assert view_before in replay_tail
view_after = (
    view_before
    + """                    **(
                        {"training_view": m["training_view"]}
                        if m.get("training_view") is not None
                        else {}
                    ),
"""
)
chunks = [
    ("python/quoridor_training/common.py", prefix, prefix_post),
    ("python/quoridor_training/common.py", validator, validator_post),
    ("python/quoridor_training/public_replay.py", module_before, module_after),
    ("python/quoridor_training/public_replay.py", rows_before, rows_after),
    ("python/quoridor_training/public_replay.py", view_before, view_after),
]
(OUT / "owner-chunks.json").write_text(
    json.dumps([dict(path=p, before=b, after=a) for p, b, a in chunks], indent=2) + "\n"
)
# Patches are finalized after project formatting of the changed owner fragments.
(OUT / "before-owner-fragments.json.gz").write_bytes(
    gzip.compress(json.dumps([dict(path=p, before=b) for p, b, a in chunks]).encode(), mtime=0)
)
print(
    json.dumps(
        {"fragments": len(chunks), "new_data_model_calls": 0, "whole_Main_module_mirror": False}
    )
)
