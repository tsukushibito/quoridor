"""Read only named maintained owner bodies and small saved recipe metadata."""

import hashlib
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
refs = []


def read(name):
    p = ROOT / name
    a = p.stat()
    b = p.read_bytes()
    z = p.stat()
    assert (a.st_dev, a.st_ino, a.st_size, a.st_mtime_ns) == (
        z.st_dev,
        z.st_ino,
        z.st_size,
        z.st_mtime_ns,
    )
    refs.append(
        dict(
            path=str(p),
            sha256=hashlib.sha256(b).hexdigest(),
            bytes=len(b),
            mode=f"{a.st_mode & 511:04o}",
        )
    )
    return b


for name, ranges in [
    ("python/quoridor_training/sampling.py", [(1, 108), (130, 152), (202, 266)]),
    ("python/quoridor_training/public_replay.py", [(1, 120), (117, 209), (269, 362), (700, 855)]),
    ("python/quoridor_training/common.py", [(1, 125), (601, 721)]),
    ("python/quoridor_training/terminal_cache.py", [(325, 361), (429, 497)]),
]:
    lines = read(name).decode().splitlines(keepends=True)
    text = "".join(f"\n# {name}:{a}-{b}\n" + "".join(lines[a - 1 : b]) for a, b in ranges)
    (OUT / (Path(name).name + ".scoped.txt")).write_text(text)
    print(text)
p = ".worktree/learning-million/.artifacts/research-team/nnue-teacher-refresh423-learning-v1/"
for name in ("settings.fixed-recipe.json", "prepare-configs.py"):
    b = read(p + name)
    (OUT / ("saved423-" + name)).write_bytes(b)
    print(name + "\n" + b.decode())
(OUT / "intake-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
