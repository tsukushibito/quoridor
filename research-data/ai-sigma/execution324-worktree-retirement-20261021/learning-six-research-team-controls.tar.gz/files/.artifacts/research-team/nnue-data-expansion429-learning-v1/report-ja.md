# 429C: nested数量view・matched coverageと少数条件の準備

**source/config準備であり、fit/forward/対局の許可・結果ではない。** Main/Git/Cargo/実admissionは324。元423/426、428 author/courier、旧323/342.17 USERPAUSE、default/models/seals/RAW/FAILED/費UNKNOWNに変更0。actual cache/eligible行数/選択distinct/view FileRef/Experiment/重み/runtime/supportはnullのまま。

## 現在わかっている入力

Bのrules-only原実行は1280要求、1204 accepted、76 missing、1176 canonical familiesで、自己対局/推論はこの入力処理に含まれない。quantityは1024要求/1018 accepted（813T game/205V、欠6）、earlyは256/186（149T/37V、欠70）。request/game/family/eligible行/モデル入力distinctを混同しない。今の数は生成GOALや学習行数の保証ではない。

one global cycle[4,8,12,16,2]、ordinal%5!=4がquantity、==4がearly。seed/64sim/Sigma/10M/160×8req/6万rows/whole128MiBはB正本、Cから変更しない。source identityは実config/schedule SHA＋native ordinal/request ID、row identityはそれとactual compact index/row_id。bare game-nを旧新でjoinしない。小さいB input-collection/resolved-proposalのSHA-size-modeを照合した。cohort-map等の実refsはB collection、未来cache/rowsは未作成。

旧423はRAW source203T/53V、最終fit204T/52V/ID18だけsourceV→finalTという元事実を保つ。本案は新Cの全T viewへ旧423Tを**含めない**。旧423256と既知book/ALL426 poolをB canonical closureで除外した集合を使う。old Wは歴史的比較材料で、新viewのmatched controlとして再使用しない。公開全game provenance/sealed非露出はUNKNOWNで、追加scanしない。

## viewの具体的な結果非選別規則

現役 `family_training_view` は全family split・eligibilityを検査し、Tだけ各game×在庫層16..20/8..15/1..7/0から最大8をchronological等間隔で採る。候補<=8なら全部、>8ならfloor(i*(n-1)/7)、空層の補充0。この既存抽出を先に行う。Vは共有cacheの全eligible canonicalV、全条件同一で削除・再partitionしない。

数量/coverageを比較するには、単にrow IDを増やしてモデル入力distinctと呼べない。そこで**追加のbounded downsampleを明記**する。既存codecのFP32 x[2,312]とD/80 d[2]のliteral bytesを同入力とし、outcome/provenanceは同一性keyに入れない。raw aliasは全保存したまま、候補内の各literal keyにつきseed付きlineage hashで一つの代表行を固定する。代表/順序決定はzを使わず、相反zのcensusは固定後の記述だけ。これは元のrow multiplicityをそのまま維持したobjectiveではなく、selected representativeをuniform row-MSEで学ぶ設計である。各game/層<=8を上回らず、新teacher平均やrelabelを作らない。raw/候補/除外/selected row・key・LR orbit・game・family・stockを別集計する。

T/V family隔離はnative ownerを再用し、viewはrelabelしない。将来の実view準備で、共有Vとliteral/訓練LR orbitが重なる候補T familyはT viewから除外して対応を保存する。Vやcanonical splitを動かさない。LR同値をliteral distinctや独立sampleへ水増ししない。正本codec/reflectionだけを使い、Python geometry classifier/モデルforwardは追加しない。この実key/alias censusはまだ未実行である。

quantityの層別distinct capacity CjからKj=floor(Cj/4)、Nq=min(3763,sumKj)。Hamilton整数配分qj（同点は固定した層順）、同じseed rankの先頭qjをsmall、先頭4qjをlargeとする。従ってnestedかつ層別distinct比率もexact4倍。largeは4Nq<=15052、実不足はNqを下げて明記し、repeat/refillで目標を装わない。これはselected-keyの在庫比を合わせるもので、game/familyの同じ重みや統計独立性は保証しない。

early coverageはquantityに混ぜず、同じbase cap/同入力代表方針でNq distinctが足りれば別に結果盲検選択する。総distinctだけを合わせ、在庫比の変化はcoverage側の意図した違いとして示す。足りなければその比較は宣言targetで未成立と報告し、repeatや自動の追加control fitを作らない。より小さいNmatchで二条件を改めて比較する案は、実数・費用を次の短い提案へ出す。

## 学習案：四fitから三つの対比（全て未許可・未実行）

| 条件 | target distinct | target draws | updates / tail | 対比 |
| --- | ---: | ---: | --- | --- |
| Q-small-8exposure | 3763 | 30104 | 118 / 152 | 共通control |
| Q-large-fixed-draws | 15052 | 30104 | 118 / 152 | 同draw/updateで多様性、平均2露出 |
| Q-large-8exposure | 同じ15052 | 120416 | 471 / 96 | 同8露出、訓練計算4倍 |
| early-matched-8exposure | 同じ3763が実在すれば | 30104 | 118 / 152 | 総distinctを合わせたcoverage |

表はtargets成立時の算術例で、actualはnull。実drawは8Nq/32Nq、batch256、U=ceil(draws/256)、最後だけ正規tail。全条件同じBEST43/fresh Adam/LR1e-4/最初min(10,U)のupdate座標linear warmup→constant、z MSE/FP32/QF1/FT32H32/Zero4/tanh/凍結incumbent尺度/output bypassOFF/reflection.5。訓練は新Tだけ、公開optimizer rows0。新seedはsettingsに固定し、公開T診断は旧423 seed42320261025を再用する。samplerは現shuffled cyclingを再用し、異なるサイズで同seedでも同じdraw順とは呼ばない。

Aのsaved傾向はWのV family-MSEが0/40/79/118で.945876/.936110/.924908/.915511、末尾傾向が残るがundertraining/最適更新数の証明ではない。このためlong条件は提案できるが、自動fitしない。Fはfresh/LR1e-3/941updates等も変わり、初期化だけの効果ではない。

**longの118更新目を30104 drawsの代用にしない。** 現入口のtailは最終horizonだけなので、longの途中118は30208 draws、shortは30104。104行と最後のgradient batchが異なる。non-BEST中間118weightsも現INITIAL/BEST/LAST経路で必ず保存されるわけではない。これがlarge-shortを別の未来条件として予算化する理由であり、silent interior tail/checkpoint APIは足していない。

全V共通・family-MSE/tie-earliest/public gate false、end-of-horizonとBESTを別表示。short points0/40/79/118、long0/157/314/471。longはVを見る点/選択機会も違うので、BESTだけから同計算の因果を主張しない。公開Vは凍結BESTを一度、公開T8192と各view自身のT診断は各点。各T診断bankはviewで異なり、T-MSEを同一support比較とは呼ばない。現在observerのgame別SSE/countからcohort別/各familyのV集計は同じ保存予測を使って再集約できる。16..20のlossから18..20のlossは復元できずUNKNOWN。Bの18..20件数とは分ける。

targetsで四fitのtrain210728、測定を含む論理行はINITIAL信用なしで2,114,040+16V。accepted V242 game×200の構造上限なら2,888,440だが、実counts・output・必要changed-weights work・host費は未確定。これはfit上限の発行でも完了保証でもなく、旧423の4MやBの10M余剰を転用しない。future actual normal planned_workと次の費用提案が正本になる。INITIAL共有は既存のexact model/cache/scope/constants条件のまま、view違いで一般に拒否されるため仮のcredit0。

## 必要だった最小source境界

現在はcap/層抽出後の任意subsetを渡せないため、optional mixture.training_view FileRef（最大4MiB）とJSON `{cache_manifest_sha256,indices}` だけを追加する疎patchを作った。helperは既存bound_file_bytesで実SHA/size/mode/regular fileを検査し、同actual cacheとnonempty/sorted/unique/literal-intの**標準T候補部分集合**だけを許す。wrong cache、V、cap外、bool/float/重複/順序/余分field等を拒否する。非view時は同じ候補objectを返し、既存動作を保つ。sharedV式/codec/teacher/model/scale/F/INITIAL/optimizer/loss/finalizerに変更0。実viewのdistinct/alias正しさまでindex型検査が証明するとは言わず、実作成時のcensusが必要である。

normal input binding/Experimentのordered inputsとbefore/after lifetimeにactual training_view FileRefを正しくjoinするのはRoot。将来materializerはこの比較でviewが未作成ならnormal trainへ進めず、Noneを全Tの代用にしない。新schema registry/decoder/corpus/sampler/controller/certificateはない。

四つの新NN0 metadata定義を一度だけ実行しPASSした。stdlibのみで、対象helper/validatorと既存bound readerの凍結ownerをexecして検査、NumPy/Torch/model/corpus/native/head0。全成功suiteは再演していない。後のRuff100整形は実test対象とAST一致を別記録し、testを再実行していない。private scalar算術の新illustrationもrealdata/optimizerではない。source.patchは5ownerサイトだけ、変更片/minimum before gzip/strict forward/inverse/protected proofを保存。omitted gapを明示したsynthetic fragmentでのGNUzero-fuzzであり、全Main postimageを作成/検査したとは言わない。Rootがactual before refsへ疎合成し、既存idle Solへこのsubset/cache binding境界だけを確認依頼する。

## 実scopeと失敗・停止

actual context00:26:08.864Z Sol6.1/high/Main/danger-full-access/neverを最初に確認し本人claim。sourceCPU12/guardian6、physical6/3、family1GiB inclcontroller/GPU0/reserve4GiB。Rootの指示に従い、private作業ではMain寿命leaseや全runner拒否を使わず、既存CycleResources/processに実topology/RAM/affinity/同physical named-peer確認だけを組合せた。guardian6共有managementを明示し、untimed producerの別core動作と並行可能。future quiet/host全体idleは主張しない。Main owner intakeは00:29:11.427203Zに返却、以後named formatting-config等の小読取り以外はprivate凍結sourceを使う。

最初のrgで存在しないconfig.pyを指定した診断、sparse proof v1のfragment EOF/context拒否、Ruff configの最初のpyproject指定と存在しないroot ruff.toml拒否、closed済み429.1への直接配送拒否を保持した。correct projectはtools/research-quality/ruff.toml（100/py311）。failed/provisional patchと原receiptを残し、関連する未実行format/proofだけを修正、NN0成功再演0。Aへのcapability noteはRootへ配送し、closed leafをforce/reopenしない。Root返答/親closeはgateにしない。

source/readers/helperの実STOP・PID/start/boot fresh absence・directwait/reap/handles/TMP/leases/owned[]、returned-null対disk、費/peak UNKNOWN、一度のOWN affected usageは最終bindingに記録する。新fit/evalforward/arena/bootstrap/modelpayload/oldRAW fullread/source sweep/428candidate混入は0。future evaluation startsは新seedのinterfaceだけを固定し、実book/件数/計算費はnull。既知426結果に適合させず、全既知book/ALL426候補とactual429 T/Vを既存canonical ownerで除外する予定であり、新startsも作っていない。
