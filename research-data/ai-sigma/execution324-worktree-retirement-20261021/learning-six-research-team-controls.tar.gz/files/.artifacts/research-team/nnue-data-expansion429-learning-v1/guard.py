"""Run one explicitly supplied private source/NN0 command with existing controls."""

from contextlib import nullcontext
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "lc421_receiver", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = lc
spec.loader.exec_module(lc)
name, *argv = sys.argv[1:]
private_only = bool(argv and argv[0] == "--private-only")
if private_only:
    argv.pop(0)
result = {"argv": argv, "entered_at": lc.stamp(), "returned": None, "error": None}
result["private_only_no_Main_reader_lifetime"] = private_only
try:
    with nullcontext() if private_only else lc.lease():
        if private_only:
            # This untimed private source job may coexist with a disjoint producer.
            available = lc.process.available_memory()
            lc.require(available >= 1073741824 + 4294967296, "source RAM/reserve")
            affinity = os.sched_getaffinity(0)
            lc.require({12, 6} <= affinity, "source/guardian affinity")

            def core(cpu):
                path = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
                return (
                    (path / "physical_package_id").read_text().strip(),
                    (path / "core_id").read_text().strip(),
                )

            worker_core, guardian_core = core(12), core(6)
            lc.require(worker_core != guardian_core, "distinct source/guardian physical cores")
            peers = []
            for entry in Path("/proc").iterdir():
                if not entry.name.isdigit() or int(entry.name) == os.getpid():
                    continue
                try:
                    args = (entry / "cmdline").read_bytes().split(b"\0")
                    if not args or Path(os.fsdecode(args[0])).name not in {
                        "cargo",
                        "rustc",
                        "cc1plus",
                        "quoridor-runner",
                        "terminal-cache",
                        "chromium",
                        "chrome",
                    }:
                        continue
                    allowed = sorted(os.sched_getaffinity(int(entry.name)))
                    peers.append(
                        {"pid": int(entry.name), "name": os.fsdecode(args[0]), "affinity": allowed}
                    )
                    lc.require(
                        all(core(cpu) != worker_core for cpu in allowed),
                        "named compute peer shares source physical core: " + entry.name,
                    )
                except (FileNotFoundError, ProcessLookupError):
                    continue
            result["private_resource_observation"] = {
                "available_B": available,
                "worker_cpu": 12,
                "guardian_cpu": 6,
                "worker_physical_core": worker_core,
                "guardian_physical_core": guardian_core,
                "named_compute_peers": peers,
                "guardian_management_shared": True,
                "global_fair_clock_quiet_claim": False,
                "GPU": 0,
            }
            os.sched_setaffinity(0, {6})
        else:
            lc.physical_and_quiet(
                {
                    "kind": "source",
                    "limits": {
                        "worker_cpu": 12,
                        "guardian_cpu": 6,
                        "family_B": 1073741824,
                        "host_reserve_B": 4294967296,
                    },
                }
            )
        capture = lc.Capture(OUT / (name + ".capture.log"), 524288)
        try:
            result["returned"] = lc.process.execute(
                argv,
                OUT / (name + ".guardian.log"),
                None,
                cpu_core=12,
                resources=lc.process.CycleResources({"max_memory_bytes": 1073741824}, OUT, None),
                cwd=str(ROOT),
                output_sink=capture,
            )
        finally:
            capture.close()
except BaseException as error:
    result["error"] = lc.error_fact(error)
result["stopped_at"] = lc.stamp()
result["controller_pid"] = os.getpid()
with (OUT / (name + ".returned.json")).open("x") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(
    json.dumps(
        {
            "name": name,
            "error": result["error"],
            "exit_code": (result["returned"] or {}).get("exit_code"),
            "STOP": result["stopped_at"],
        }
    )
)
if result["error"] or (result["returned"] or {}).get("exit_code") != 0:
    sys.exit(1)
