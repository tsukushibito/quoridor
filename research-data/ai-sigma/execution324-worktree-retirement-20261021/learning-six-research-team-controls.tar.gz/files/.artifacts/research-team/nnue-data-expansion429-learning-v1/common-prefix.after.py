"""Configuration and measurements shared by NNUE training experiments."""

import copy
from array import array
import json
import math
import hashlib
import struct
import stat
from pathlib import Path

__all__ = [
    "resolve_config",
    "measurements",
]


DEFAULTS = {
    "model": {
        "feature_version": "QF1",
        "architecture": "scaled",
        "distance_a": 0.0,
        "distance_b": 8.0,
        "transformer_width": 32,
        "hidden_width": 32,
        "dropout": 0.0,
    },
    "optimizer": {"name": "adam", "lr": 0.001, "weight_decay": 0.0, "momentum": 0.0},
    "training": {
        "steps": 200,
        "batch_size": 128,
        "seed": 19080311,
        "target": "rootmean",
        "sampling": "epoch",
        "loss_weighting": "row",
        "scheduler": "none",
        "warmup_steps": 0,
        "lr_decay_factor": 0.5,
        "lr_decay_patience": 2,
        "min_lr": 1e-6,
        "reflection_probability": 0.0,
        "supply_workers": 0,
        "reflection_seed": 19080314,
        "device": "cpu",
        "threads": 1,
    },
    "evaluation": {
        "interval": 10,
        "checkpoints": None,
        "batch_size": 1024,
        "monitor": "game",
        "early_stopping_patience": 5,
        "early_stopping_unit": "observation",
        "min_delta": 0.0,
        "min_delta_relative": 0.0,
        "diagnostic_rows": 256,
        "diagnostic_interval": 25,
        "diagnostic_checkpoints": None,
        "full_train": True,
        "full_train_checkpoints": [],
        "full_train_every_epochs": 5,
    },
    "limits": {"seconds": 60.0, "samples": 500000},
    "data": {"overlap_policy": "error"},
    "artifacts": {
        "mode": "native_onnx",
        "save_scheduled": False,
        "checkpoint_steps": [],
    },
    "experiment": {
        "study": None,
        "teacher_mapping": None,
        "draw_policy": None,
        "warm_start": None,
        "condition": None,
        "main_volume_N": None,
        "main_volume_manifest": None,
        "main_volume_manifest_sha256": None,
    },
}
MIXTURE_FIELDS = (
    "train_family_row_cap",
    "train_stock_strata",
    "added_rows",
    "public_rows",
    "added_exposures",
    "added_sampling_seed",
    "public_sampling_seed",
    "added_reflection_probability",
    "added_reflection_seed",
    "public_reflection_probability",
    "public_reflection_seed",
    "diagnostic_seed",
    "public_membership",
    "public_acceptance",
    "selector",
    "output_limit_bytes",
)
DEFAULTS["mixture"] = dict.fromkeys(MIXTURE_FIELDS)
# These leave the currently planned mixture's existing behaviour intact when absent.
# A recipe using either new option must supply its explicit value.
MIXTURE_OPTIONS = {
    "public_file_decay",
    "public_evaluation",
    "public_acceptance_seed",
    "training_rows",
    "training_view",
}
DEFAULTS["mixture"].update(
    public_file_decay=None,
    public_evaluation=None,
    public_acceptance_seed=None,
    training_rows=None,
    training_view=None,
)


STEP_MODEL_DEFAULTS = {
    "distance_bypass": True,
    "train_transform": "F",
    "deploy_transform": "F",
}
