"""Freeze a reviewable proposal, intentionally not a runnable Experiment/config."""

import hashlib
import json
from pathlib import Path

from comparison_arithmetic import illustrative_checks

OUT = Path(__file__).resolve().parent


def ref(p):
    b = p.read_bytes()
    return dict(
        path=str(p.resolve()),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{p.stat().st_mode & 511:04o}",
    )


p = Path(
    "/workspaces/quoridor/.worktree/assets/perf/nnue-data-expansion429-analysis-v1/result.json"
)
x = json.loads(p.read_bytes())
w = x["actual_settings"]["W"]
old = Path(
    "/workspaces/quoridor/.worktree/learning-million/.artifacts/research-team/nnue-diverse421-learning-v1/settings.SELECTED.json"
)
b = old.read_bytes()
assert (
    hashlib.sha256(b).hexdigest()
    == "fcc935ca187172aa238ff972b6f11db1d4d0812aca12960f20afe4ceaea99a3d"
)
base = json.loads(b)["C"]
selected = dict(
    A_result=ref(p),
    historical_423_W=w,
    historical_423_materializer_base=ref(old),
    incumbent_normal_warm_start=base["experiment"]["warm_start"],
    public_membership=base["mixture"]["public_membership"],
    public_acceptance=base["mixture"]["public_acceptance"],
    original_W_config_sha256=w["fit_config_sha256"],
    original_W_config_direct_path="UNKNOWN/not independently read; saved actual settings and digest used",
)
(OUT / "saved423-selected-settings.json").write_text(json.dumps(selected, indent=2) + "\n")
settings = dict(
    status="PROSPECTIVE_SETTINGS_AND_SOURCE_PREPARATION_ONLY_NOT_SCIENCE_READY",
    scientific_execution_authorized=False,
    actual_cache=None,
    actual_view_FileRefs=None,
    actual_R=None,
    actual_V_rows=None,
    actual_Experiment=None,
    actual_fit_support=None,
    actual_runtime_weights=None,
    owner="quoridor-4lc.429.3; Main/Git/Cargo and future numerical admission324",
    data_interface=dict(
        cohort_rule="quantity:ordinal%5!=4; early:ordinal%5==4; one global [4,8,12,16,2] cycle",
        source_row_identity=[
            "actual config/schedule SHA",
            "native global ordinal/request_id",
            "compact row_id/index",
        ],
        new_request_counts=dict(quantity=1024, early=256),
        actual_rules_only_input=dict(
            accepted=1204,
            missing=76,
            canonical_families=1176,
            quantity=dict(accepted=1018, T_games=813, V_games=205, missing=6),
            early=dict(accepted=186, T_games=149, V_games=37, missing=70),
        ),
        outcome_rows_selected_distinct_and_TV_family_counts=None,
        B_metadata_refs=json.loads((OUT / "B-fixed-input-refs.json").read_text()),
    ),
    old423=dict(
        included_in_any_new_T_view=False,
        raw_source_TV_games=[203, 53],
        accepted_final_TV_games=[204, 52],
        historical_ID18="sourceV->acceptedfinalT; preserve exact old evidence, no new relabel",
        use="recipe/scale/start model and historical context only; not a reused matched fit control",
    ),
    view_recipe=dict(
        base="maintained family_training_view on ONE actual shared new compact cache",
        train_family_row_cap=None,
        train_stock_strata=[
            dict(min=a, max=b, rows=8) for a, b in ((16, 20), (8, 15), (1, 7), (0, 0))
        ],
        chronology="all if<=8 else floor(i*(n-1)/7),i0..7; no fill; no outcome/error/model score selection",
        shared_V="ALL eligible canonicalV in same joint quantity+early cache; no V cap/repartition",
        T_alias_isolation="before selecting: canonical family split already guarded; exclude T families with literal or train-LR model-input orbit intersecting sharedV; retain excluded audit, no relabel",
        literal_key="existing TerminalCorpus.batch FP32 QF1/STM x and D/80 d bytes, tied to unchanged encoder/incumbent scale; no new geometry decoder or model forward",
        augmentation_orbit="existing maintained LR reflection; count literal and LR-equivalence separately, never call either independent samples",
        bounded_additional_view_selection="one representative per literal input after base cap by minimum outcome-blind seeded lineage hash; all alias records/provenance/conflicting-z census retained separately; no relabel/teacher averaging",
        reason="make actual distinct count explicit and uniform selected-key objective; this is an extra result-blind downsample, not unchanged old row multiplicity or independent-family weighting",
        label_access="representative/rank frozen without reading outcome values; outcome conflict census only descriptive afterwards",
        quantity_nested="stock capacities Cj of representatives; Kj=floor(Cj/4), Nq=min(3763,sum Kj); Hamilton allocation capped byKj; per-stock small qj then large4qj from SAME seeded rank; chronological indices saved sorted",
        quantity_targets=[3763, 15052],
        actual_sizes=None,
        shortage="lower actual Nq from capacity; no repeat/refill; target not guaranteed",
        early_match="Nq keys by same outcome-blind rank policy if early capacity>=Nq; else coverage pair unavailable at declared target, report deficit; lower-N paired alternative requires explicit next cost proposal, no automatic fifth fit",
        weights="row MSE uniform over selected representatives; report true game/family/key/orbit/stock and per-record exposure, not equal family weights",
    ),
    seeds=dict(
        training=4292026101701,
        added_row_order=4292026101702,
        reflection=4292026101703,
        public_T_diagnostic=42320261025,
        view_ranking=4292026101705,
        future_unused_eval_prefix=4292026101706,
        future_unused_eval_owner=4292026101707,
    ),
    shared_settings=dict(
        study="mixed-outcome",
        initial_reference=w["initial_reference_METADATA_ONLY"],
        normalization="incumbent descriptor T-only unchanged",
        target="z",
        public_optimizer_rows=0,
        added_batch_rows=256,
        optimizer=dict(
            name="adam", lr=1e-4, betas=[0.9, 0.999], eps=1e-8, weight_decay=0, fresh=True
        ),
        model="same FT32/H32/QF1/Zero4/FP32/tanh/output-bypassOFF, no head/model design change",
        warmup="first min(10,updates) linear in update coordinates then constant; no stretching",
        reflection_probability=0.5,
        early_stopping_patience=0,
        selector=dict(added_metric="family_mse", public_non_regression=False, tie="earliest"),
        artifacts=["INITIAL", "BEST", "LAST"],
        checkpoint_steps=[],
        evaluation=dict(
            checkpoints="unique0/ceil(U/3)/ceil(2U/3)/U",
            diagnostic_rows=8192,
            full_train=False,
            full_train_checkpoints=[],
            public_evaluation=dict(validation="best", train_diagnostic=True),
        ),
        INITIAL_reuse="only actual normal exact model/cache/scope/constant identity; current differing T views generally refuse sharing; take NO assumed credit",
    ),
    prospective_conditions=[
        dict(id="Q-small-8exposure", view="quantity-small", draws="8*Nq", updates="ceil(8*Nq/256)"),
        dict(
            id="Q-large-fixed-draws",
            view="quantity-large",
            draws="8*Nq",
            updates="ceil(8*Nq/256)",
            mean_exposure=2,
        ),
        dict(
            id="Q-large-8exposure",
            view="SAME quantity-large",
            draws="8*(4*Nq)",
            updates="ceil(32*Nq/256)",
            interpretation="4x training draws relative to small; not fixed compute",
        ),
        dict(
            id="early-matched-8exposure",
            view="early-matched Nq only if enough",
            draws="8*Nq",
            updates="ceil(8*Nq/256)",
        ),
    ],
    contrasts=dict(
        quantity_fixed_draws=["Q-small-8exposure", "Q-large-fixed-draws"],
        quantity_fixed_exposure=["Q-small-8exposure", "Q-large-8exposure"],
        more_training_same_data=["Q-large-fixed-draws", "Q-large-8exposure"],
        early_coverage_matched_distinct=["Q-small-8exposure", "early-matched-8exposure"],
    ),
    budget=dict(
        training_rows_target_case=210728,  # 30104*3+120416
        whole_forward_cap=None,
        whole_output_support=None,
        reason="fit/forward/strength not authorized by429; next short concrete proposal with actual counts/cost required",
        per_fit_forward_formula="training_rows + points*(all_sharedV + min(selectedT,8192)+8192) + 419150; normal planned_work authoritative, no assumed INITIAL reuse",
        measurement_compute="sharedV is equal within pair but large ownT diagnostic supports differ; training-draw equality is not total-row-forward/wall equality",
    ),
    capability_limits=dict(
        long118_is_not_exact_short30104="118full long batches=30208 vs117full+tail152=30104; no interior tail API",
        intermediate_nonBEST_weight="not guaranteed; current INITIAL/BEST/LAST only; no extra checkpoint port added",
        shared_train_diagnostic="current scopes derive from each view, so not identical T bank; commonV primary, ownT numbers have different support",
        cohort_validation="recombine existing pergame SSE/count/family map from same saved predictions; no extra forward",
        stock_18_20_loss="current configured16..20 loss cannot resolve18..20 loss; B counts18..20 only; keep unknown",
        V_selection="shared V reused for BEST; extra selection looks in longer run; report predeclared horizon endpoint and BEST separately",
    ),
    future_eval=dict(
        prefix_seed=4292026101706,
        owner_seed=4292026101707,
        actual_book=None,
        family_count=None,
        counts_compute_holdings=None,
        exclude="all known old355/421/423/ALL426candidatepool and actual429 T/V canonical closure; no426 outcome adaptation",
        owner="existing rules-only canonical entry/native owner; no new starts/arena generated by C",
        sealed_newE=False,
    ),
)
(OUT / "settings.proposed.json").write_text(json.dumps(settings, indent=2) + "\n")
(OUT / "arithmetic-checks.json").write_text(json.dumps(illustrative_checks(), indent=2) + "\n")
print(
    json.dumps(
        {
            "saved": str(OUT / "settings.proposed.json"),
            "runnable": False,
            "actual_rows": None,
            "new_scientific_calls": 0,
        }
    )
)
