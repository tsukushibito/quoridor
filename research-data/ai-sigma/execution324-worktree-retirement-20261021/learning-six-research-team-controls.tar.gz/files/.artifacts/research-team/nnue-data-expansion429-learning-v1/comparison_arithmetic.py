"""Prospective scalar plan only; no cache, framework, sampler, or science entry."""

import math


def nested_stock_quota(capacity, target=3763, multiplier=4):
    if len(capacity) != 4 or any(type(v) is not int or v < 0 for v in capacity):
        raise ValueError("four actual nonnegative distinct-input stock capacities required")
    caps = [v // multiplier for v in capacity]
    n = min(target, sum(caps))
    if not n:
        return dict(small=0, large=0, small_by_stock=[0] * 4, large_by_stock=[0] * 4)
    total = sum(caps)
    q = [n * v // total for v in caps]
    order = sorted(range(4), key=lambda j: (-(n * caps[j] % total), j))
    for j in order[: n - sum(q)]:
        q[j] += 1
    return dict(
        small=n, large=multiplier * n, small_by_stock=q, large_by_stock=[multiplier * v for v in q]
    )


def schedule(draws, batch=256):
    if type(draws) is not int or draws <= 0:
        raise ValueError("actual positive training draws required")
    u = math.ceil(draws / batch)
    return dict(
        training_rows=draws,
        updates=u,
        full_batches=draws // batch,
        tail=draws % batch,
        checkpoints=sorted({0, math.ceil(u / 3), math.ceil(2 * u / 3), u}),
        warmup_steps=min(10, u),
        lr=1e-4,
        first_lr=1e-4 / min(10, u),
    )


def illustrative_checks():
    short = schedule(8 * 3763)
    long = schedule(8 * 15052)
    assert short["updates"] == 118 and short["full_batches"] == 117 and short["tail"] == 152
    assert long["updates"] == 471 and long["full_batches"] == 470 and long["tail"] == 96
    assert short["checkpoints"] == [0, 40, 79, 118] and long["checkpoints"] == [0, 157, 314, 471]
    assert 118 * 256 - short["training_rows"] == 104
    for capacity in ([1500, 10000, 15000, 7000], [3, 4, 7, 8], [0, 0, 0, 0], [15052, 0, 0, 0]):
        q = nested_stock_quota(capacity)
        assert q["large"] == 4 * q["small"] and sum(q["small_by_stock"]) == q["small"]
        assert all(
            b == 4 * a and b <= c
            for a, b, c in zip(q["small_by_stock"], q["large_by_stock"], capacity)
        )
    return dict(
        status="PASS_scalar_illustrations_only_not_actual_data",
        small_target_case=short,
        large_target_case=long,
        long_prefix_at118_draws=30208,
        short_terminal_draws=30104,
        cannot_reuse_long118_for_exact30104=True,
        actual_R_actual_views=None,
    )
