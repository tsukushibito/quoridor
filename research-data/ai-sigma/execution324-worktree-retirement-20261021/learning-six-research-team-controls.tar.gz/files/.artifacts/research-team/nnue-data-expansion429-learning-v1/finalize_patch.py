"""Freeze a five-site sparse delta; omitted Main regions are never mirrored."""

import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent
chunks = json.loads((OUT / "owner-chunks.json").read_text())
chunks[0]["after"] = (OUT / "common-prefix.after.py").read_text().rstrip("\n") + "\n" * (
    len(chunks[0]["before"]) - len(chunks[0]["before"].rstrip("\n"))
)
chunks[1]["after"] = (OUT / "validate_mixture_config.after.py").read_text().rstrip("\n") + "\n" * (
    len(chunks[1]["before"]) - len(chunks[1]["before"].rstrip("\n"))
)
helper = (OUT / "training_view_indices.py").read_text().rstrip() + "\n\n\n"
anchor = 'STUDY = "mixed-outcome"\n\n\n'
pass  # finalized from the exact retained source context below
replay = (OUT / "public_replay.py.scoped.txt").read_text()
top = replay.split("# python/quoridor_training/public_replay.py:1-120\n", 1)[1]
tail = replay.split("# python/quoridor_training/public_replay.py:700-855\n", 1)[1]
# Three trailing context lines avoid describing an interior owner fragment as EOF.
module_tail = "\n".join(top[top.index("def mixed_batch(") :].splitlines()[:4]) + "\n"
chunks[2]["before"] = anchor + module_tail
chunks[2]["after"] = anchor + helper + module_tail
rows_tail = "            initial_observation_ref = (\n                json.loads(Path(input_binding).read_bytes())\n"
if not chunks[3]["before"].endswith(rows_tail):
    chunks[3]["before"] += rows_tail
    chunks[3]["after"] += rows_tail
view_tail = '                    "train_family_row_cap": m["train_family_row_cap"],\n                    "stock_strata": m["train_stock_strata"],\n                    "validation_rows": len(validation_rows),\n'
if not chunks[4]["before"].endswith(view_tail):
    chunks[4]["before"] += view_tail
    chunks[4]["after"] += view_tail
bases = [
    1,
    601,
    1 + top[: top.index(anchor)].count("\n"),
    700 + tail[: tail.index(chunks[3]["before"])].count("\n"),
    700 + tail[: tail.index(chunks[4]["before"])].count("\n"),
]
patch = []
delta = {}
synthetic = {}
hunk_info = []
for chunk, base in zip(chunks, bases, strict=True):
    path, before, after = chunk["path"], chunk["before"], chunk["after"]
    if path not in synthetic:
        synthetic[path] = []
        delta[path] = 0
        patch.extend(["--- a/" + path + "\n", "+++ b/" + path + "\n"])
    lines = synthetic[path]
    while len(lines) < base - 1:
        lines.append("# omitted unowned source; not a Main mirror\n")
    assert len(lines) == base - 1
    lines.extend(before.splitlines(True))
    d = list(difflib.unified_diff(before.splitlines(True), after.splitlines(True), n=3))[2:]
    for line in d:
        if line.startswith("@@ "):
            m = re.match(r"@@ -(\d+)(,\d+)? \+(\d+)(,\d+)? @@(.*)", line)
            old = int(m[1]) + base - 1
            new = int(m[3]) + base - 1 + delta[path]
            line = f"@@ -{old}{m[2] or ''} +{new}{m[4] or ''} @@{m[5]}\n"
        patch.append(line)
    hunk_info.append(
        dict(
            path=path,
            original_line=base,
            before_sha=hashlib.sha256(before.encode()).hexdigest(),
            after_sha=hashlib.sha256(after.encode()).hexdigest(),
        )
    )
    delta[path] += len(after.splitlines(True)) - len(before.splitlines(True))
(OUT / "source.patch").write_text("".join(patch))
work = OUT / "strict-patch-TMP"
for name, lines in synthetic.items():
    p = work / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("".join(lines))
records = []
for inverse in (False, True):
    cmd = ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(OUT / "source.patch")]
    if inverse:
        cmd.insert(1, "--reverse")
    r = subprocess.run(cmd, cwd=work, text=True, capture_output=True)
    records.append(dict(argv=cmd, exit_code=r.returncode, stdout=r.stdout, stderr=r.stderr))
    (OUT / "strict-returned-records.json").write_text(json.dumps(records, indent=2) + "\n")
    r.check_returncode()
    if inverse:
        for name, lines in synthetic.items():
            assert (work / name).read_text() == "".join(lines)
    else:
        for c in chunks:
            assert c["after"] in (work / c["path"]).read_text()
for name in synthetic:
    (work / name).unlink()
for d in sorted(
    (p for p in work.rglob("*") if p.is_dir()), key=lambda p: len(p.parts), reverse=True
):
    d.rmdir()
work.rmdir()
# Only optional settings and one exact config-validation loop change in common.
restored = (
    chunks[0]["after"]
    .replace('    "training_view",\n', "", 1)
    .replace("    training_view=None,\n", "", 1)
)
assert ast.dump(ast.parse(restored), include_attributes=False) == ast.dump(
    ast.parse(chunks[0]["before"]), include_attributes=False
)
assert (
    "validation_rows = np.flatnonzero(added.eligible & (added.splits == 1))" in chunks[3]["after"]
)
assert (
    chunks[3]["after"].count("family_training_view(")
    == chunks[3]["before"].count("family_training_view(")
    == 1
)
(OUT / "owner-chunks.json").write_text(json.dumps(chunks, indent=2) + "\n")
proof = dict(
    hunks=hunk_info,
    strict_forward_inverse=records,
    proof_scope="actual exact retained owner fragments at their original line offsets; omitted gaps are explicit synthetic comments, no wholeMain proof falsely claimed",
    whole_module_postimage_created=False,
    common_existing_DEFAULTS_AST_restored_exact=True,
    sharedV_expression_BYTE_exact=True,
    original_candidate_extraction_BYTE_exact=True,
    production_model_cache_scale_INITIAL_loss_optimizer_finalizers_changed=0,
    changed_owners=[
        "common MIXTURE_OPTIONS/defaults and validate_mixture_config loop",
        "public_replay new training_view_indices helper, T subset application and optional saved provenance",
    ],
    Root_full_current_source_preimages=json.loads((OUT / "intake-refs.json").read_text())[:4],
    TMP_removed=True,
    native_framework_model_forward_fit_or_old_suite_replay=0,
)
(OUT / "source-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            "sparse_hunks": len(hunk_info),
            "strict_forward_inverse": "PASS",
            "whole_source_mirror": False,
        }
    )
)
