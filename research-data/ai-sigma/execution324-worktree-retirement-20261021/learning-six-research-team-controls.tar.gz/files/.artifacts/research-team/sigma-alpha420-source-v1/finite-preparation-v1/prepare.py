"""420 private metadata materialization only; invoke within the ordinary Root guard.

No launches, waits, model/library reads, identity computation, retries or scheduling.
Normal lifecycle admission/finalization remains the only execution boundary.
"""

from __future__ import annotations

import argparse
import copy
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
HERE = Path(__file__).resolve().parent
FROZEN = HERE.parent
RULES = "research-standard-2p-threefold-goal-first-v1"
SIGMA = "sigma-value-onnx-cpu:sha256:"
D_NAMESPACE = "original-distance-a0-b8-tanh"


def lifecycle():
    spec = importlib.util.spec_from_file_location(
        "lifecycle420prep", ROOT / "scripts/dev/research-lifecycle.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read(lc, path):
    ref, raw = lc.bound(Path(path).absolute())
    return ref, json.loads(raw)


def put(lc, path, obj):
    lc.new_json(path, obj)
    return lc.bound(path)[0]


def destination(path):
    p = Path(path).absolute()
    if not p.is_relative_to(HERE) or p == HERE or p.exists():
        raise ValueError(
            "new metadata destination must be inside finite-preparation-v1"
        )
    p.mkdir(parents=True)
    return p


def complete_manifest(lc, path, *, build=False):
    ref, obj = read(lc, path)
    if (
        obj.get("status") != "PASS"
        or obj.get("cleanup_complete") is not True
        or obj.get("remaining") != []
        or Path(path).with_name("INCOMPLETE").exists()
    ):
        raise ValueError(
            "actual sole finalized PASS/cleanup/remaining manifest required"
        )
    if build and obj.get("schema") != lc.BUILD_SCHEMA:
        raise ValueError("actual BuildManifest required")
    # Metadata correspondence only. accepted_build/source/artifact guards run at entry.
    return ref, obj


def reference(lc, args):
    packet_ref, packet = read(lc, HERE / "reference-input.json")
    result_ref, result = read(lc, args.reference_output)
    guardian_ref, guardian = read(lc, args.reference_guardian)
    identity = result.get("evaluator_identity", "")
    rows = result.get("rows")
    if (
        result.get("status") != "PASS_BOUNDED_ADAPTER_REFERENCE"
        or result.get("error") is not None
        or result.get("input_sha256") != packet_ref["sha256"]
        or result.get("reference_source_sha256") != packet["reference_source_sha256"]
        or result.get("attempted") != 5
        or not isinstance(rows, list)
        or len(rows) != 5
        or not identity.startswith(SIGMA)
        or len(identity[len(SIGMA) :]) != 64
        or any(c not in "0123456789abcdef" for c in identity[len(SIGMA) :])
        or guardian.get("exit_code") != 0
        or guardian.get("direct_child_reaped") is not True
        or guardian.get("cleanup_complete") is not True
        or guardian.get("remaining") != []
    ):
        raise ValueError("actual stopped bounded Rust reference/identity required")
    for actual, expected in zip(rows, packet["rows"], strict=True):
        if (
            actual["id"] != expected["id"]
            or actual["expected"] != expected["expected"]
            or not 0 <= actual["absolute_error"] <= 1e-6
        ):
            raise ValueError("reference result/selected literal row mismatch")
    work = result["inference_work"]
    count = work["backend"]["logical_rows"]
    if type(count) is not int or count != 5 or work["adapter_attempted_rows"] != 5:
        raise ValueError("unknown or unexpected original reference logical work")
    return packet, identity, count, [packet_ref, result_ref, guardian_ref]


def template(lc, path):
    _, obj = read(lc, path)
    if (
        obj.get("kind") != "run"
        or obj.get("schema") != "quoridor.research.lifecycle-intent.v1"
    ):
        raise ValueError("ordinary existing RUN intent template required")
    for key in (
        "owner",
        "writer",
        "cwd",
        "output",
        "data_root",
        "limits",
        "data",
        "finalizers",
    ):
        if key not in obj:
            raise ValueError("Root must bind actual resource/output field: " + key)
    if Path(obj["data_root"]).exists() or Path(obj["output"]).exists():
        raise ValueError("actual operation/output already entered; no reuse/retry")
    return obj


def experiment(
    build_ref, artifact, config, schedule, inputs, libraries, phase, slots, batch
):
    return {
        "schema": "quoridor.research.experiment.v1",
        "phase": phase,
        "build_manifest": build_ref,
        "config": config,
        "schedule": schedule,
        "inputs": inputs,
        "models": [],
        "dynamic_libraries": libraries,
        "numerical_qualification": None,
        "canonical_plan_sha256": "",  # arena fills actual plan hash before final binding
        "rules": RULES,
        "distance_units": "wall-distance/80",
        "value_perspective": "side-to-move",
        "planned_slots": slots,
        "batch": batch,
        "argv": [
            artifact["path"],
            "measure" if phase == "compare" else "arena",
            "--experiment",
            "@EXPERIMENT@",
            "--experiment-sha256",
            "@EXPERIMENT_SHA256@",
        ],
    }


def intent(lc, dest, spec, e, artifact, approved=None):
    er = put(lc, dest / "experiment.json", e)
    spec = copy.deepcopy(spec)
    spec.update(artifact=artifact, experiment=er)
    spec["argv"] = [
        s.replace("@EXPERIMENT@", er["path"]).replace(
            "@EXPERIMENT_SHA256@", er["sha256"]
        )
        for s in e["argv"]
    ]
    if approved is not None:
        spec["approved_plan"] = approved
    spec.pop("intent_sha256", None)
    spec["intent_sha256"] = lc.canonical_sha(spec)
    return put(lc, dest / "intent.json", spec)


def parent_controls(lc, args):
    br, build = complete_manifest(lc, args.build, build=True)
    packet, identity, count, evidence = reference(lc, args)
    backend = read(lc, FROZEN / "backend-inputs.json")[1]
    root_ref, _ = read(lc, HERE / "measurement-roots.json")
    specs = [
        template(lc, args.sigma_run_template),
        template(lc, args.distance_run_template),
    ]
    dest = destination(args.destination)
    refs = []
    for kind, spec in zip(("sigma", "distance"), specs, strict=True):
        d = dest / kind
        d.mkdir()
        cfg = {
            "loss_leaf_419": False,
            "roots": [
                {
                    "input": 0,
                    "pointer": f"/parents/{i}",
                    "field": "prefix",
                    "check_history": False,
                    "label": f"parent-{i}",
                }
                for i in range(6)
            ],
            "profile": "control",
            "tt_entries": 1048576,
            "use_tt": True,
            "use_pvs": True,
            "lmr": False,
            "lmr_method": "depth_rank",
            "zero_stock_approx_min_root_walls": None,
            "zero_stock_approx_method": "race",
            "zero_stock_safe_race": False,
            "namespace": {
                "evaluator": identity if kind == "sigma" else D_NAMESPACE,
                "rules": RULES,
                "selectivity": "fullwidth-PVS",
            },
            "output_bytes": 16777216,
            "record_bytes": 1048576,
        }
        inference = copy.deepcopy(packet["inference"])
        inference["logical_row_limit"] = 100000 - count
        if kind == "sigma":
            cfg["inference"] = inference
        cr = put(lc, d / "config.json", cfg)
        requests = [
            {
                "id": f"{kind}-p{i}-d{depth}",
                "session": f"{kind}-p{i}-d{depth}",
                "root": i,
                "depth": depth,
                "node_cap": 50000,
                "time_limit_ms": None,
                "warmup": False,
                "diagnostic": False,
                "observe_completed_depths": True,
                "observe_lmr": False,
            }
            for i in range(6)
            for depth in (1, 2)
        ]
        sr = put(lc, d / "requests.json", requests)
        inputs = [root_ref, *evidence]
        libraries = []
        if kind == "sigma":
            inputs.append(backend["model"])
            libraries = [
                {
                    "file": backend["library"],
                    "version": backend["loaded_version_from_existing_evidence"],
                }
            ]
        e = experiment(
            br, build["artifact"], cr, sr, inputs, libraries, "compare", 12, None
        )
        refs.append(intent(lc, d, spec, e, build["artifact"]))
    put(
        lc,
        dest / "prepared-controls.json",
        {
            "intents": refs,
            "reference_actual_logical": count,
            "parent_remaining": 100000 - count,
            "optional_419_auxiliary": "omitted; zero new entry",
            "same_owned_Sigma_backend_across_12_cold_sessions": True,
            "native_submissions": 0,
        },
    )


def arena_controls(lc, args):
    br, build = complete_manifest(lc, args.build, build=True)
    packet, identity, count, evidence = reference(lc, args)
    parent_refs = [complete_manifest(lc, p)[0] for p in args.parent_manifests]
    result_ref, result = read(lc, args.sigma_parent_result)
    if (
        result.get("status") != "COMPLETE"
        or result.get("complete") != 12
        or result.get("calls") != 12
    ):
        raise ValueError("original parent operation incomplete; do not enter arena")
    parent_count = result["inference_work"]["backend"]["logical_rows"]
    if type(parent_count) is not int or not 0 < parent_count <= 100000 - count:
        raise ValueError("unknown parent logical count or phase limit exhausted")
    dr, ds = read(lc, args.distance_identities)
    distance = next(x for x in ds if x["kind"] == "distance-tanh-f32")
    dh = distance["content_sha256"]
    if len(dh) != 64 or any(c not in "0123456789abcdef" for c in dh):
        raise ValueError(
            "actual Rust distance identity required; never compute in Python"
        )
    fixed = read(lc, FROZEN / "fixed-inputs.json")[1]
    backend = read(lc, FROZEN / "backend-inputs.json")[1]
    spec = template(lc, args.arena_run_template)
    if (
        spec.get("child_cpu_cores") != [2, 4, 6]
        or spec["limits"]["worker_cpu"] != 2
        or spec["limits"]["guardian_cpu"] != 4
        or spec["limits"]["family_B"] != 4 * 1024**3
    ):
        raise ValueError("Root must supply actual issued AI2/6/main4 family4GiB RUN")
    base_cfg = read(lc, args.arena_config_template)[1]
    dest = destination(args.destination)
    inference = copy.deepcopy(packet["inference"])
    inference["logical_row_limit"] = min(200000, 300000 - count - parent_count)
    if inference["logical_row_limit"] <= 0:
        raise ValueError("no proven arena remainder")
    slots = [
        {
            "slot": i,
            "batch": 0,
            "matchup": 0,
            "local_game": i,
            "family_id": i // 2,
            "candidate_color": i % 2,
        }
        for i in range(8)
    ]
    sr = put(lc, dest / "schedule.json", slots)
    cfg = copy.deepcopy(base_cfg)
    cfg.update(
        run_id="420-sigma-alpha-fixed-depth",
        output=spec["data_root"],
        games=8,
        workers=1,
        active_games=1,
        max_batch=1,
        max_plies=200,
        opening_plies=0,
        openings=[],
        cpu_cores=[2, 6],
        management_cpu_core=4,
        inference_cpu_core=None,
        wall_seconds=None,
        deadline_unix_ms=0,
        train_games=None,
        validation_games=None,
        cycle=None,
        inference=inference,
        ruleset="standard_2p_threefold",
        host_ram_reserve=4 * 1024**3,
        max_memory_bytes=spec["limits"]["family_B"] - 64 * 1024**2,
    )
    cfg["engines"] = [
        {
            "kind": k,
            "model": None,
            "distance_a": 0.0,
            "distance_b": 8.0,
            "depth": 2,
            "max_nodes": 50000,
            "time_ms": None,
            "simd": False,
            "ordering_profile": "control",
            "lmr": False,
            "lmr_method": "depth_rank",
        }
        for k in ("sigma_value", "distance")
    ]
    a = cfg["arena"]
    a.update(
        comparison="evaluator_fixed_depth",
        disable_continuation_static_ordering=False,
        clock_policy="strict_unknown",
        return_reserve_ms=0,
        tt_entries=1048576,
        evaluator_sha256=[identity[len(SIGMA) :], dh],
        search_artifact_sha256=[build["artifact"]["sha256"]] * 2,
        first_candidate_colors=[0] * 4,
        decision_only=False,
    )
    a["book"].update(
        id="420-canonical355-first4",
        usage="main",
        frozen_before_candidate_results=True,
        independence="Four preselected canonical families share initial/generator lineage; paired exploratory comparison, no IID/Elo claim.",
    )
    a["book"]["openings"] = [
        {
            "id": f["id"],
            "cohort": "main",
            "lineage": "existing355 canonical diagnostic family",
            "siblings": [],
            "original_seed": f["seed"],
            "reference": {
                "source_sha256": fixed["canonical_book"]["sha256"],
                "model_sha256": None,
                "settings": {
                    k: f[k] for k in ("family_id", "root_key", "history_counts")
                },
                "q_definition": None,
                "q_perspective": None,
                "q_aggregation": None,
                "q": None,
            },
            "selection_reason": "first four canonical families fixed before420 results",
            "candidate_pool_size": 1,
            "prefix": f["prefix"],
        }
        for f in fixed["arena_families"]
    ]
    cr = put(lc, dest / "config.json", cfg)
    inputs = [
        fixed["canonical_book"],
        backend["model"],
        *evidence,
        *parent_refs,
        result_ref,
        dr,
    ]
    libraries = [
        {
            "file": backend["library"],
            "version": backend["loaded_version_from_existing_evidence"],
        }
    ]
    plan = {
        "schema": "quoridor.research.arena-plan.v1",
        "phase": "arena",
        "comparison": "evaluator_fixed_depth",
        "rules": RULES,
        "distance_units": "wall-distance/80",
        "value_perspective": "side-to-move",
        "book": fixed["canonical_book"],
        "inputs": inputs,
        "models": [],
        "schedule": sr,
        "family_ids": [0, 1, 2, 3],
        "matchups": [
            {
                "id": 0,
                "inference": inference,
                "engines": cfg["engines"],
                "evaluator_sha256": a["evaluator_sha256"],
            }
        ],
        "batches": [{"batch": 0, "matchup": 0, "config": cr, "slots": list(range(8))}],
        "planned_slots": 8,
    }
    pr = put(lc, dest / "arena-plan.json", plan)
    e = experiment(br, build["artifact"], cr, sr, inputs, libraries, "arena", 8, 0)
    e["canonical_plan_sha256"] = pr["sha256"]
    put(lc, dest / "experiment.UNBOUND.json", e)
    put(lc, dest / "Root-run-template.json", spec)
    put(
        lc,
        dest / "actual-counts.json",
        {
            "reference": count,
            "Sigma_parents": parent_count,
            "arena_limit": inference["logical_row_limit"],
            "optional_auxiliary": "omitted",
            "arena_executed": False,
            "normal_numerical_qualification": "NOT_CREATED",
        },
    )


def bind_arena(lc, args):
    _, e = read(lc, args.experiment)
    br, build = complete_manifest(lc, e["build_manifest"]["path"], build=True)
    if br != e["build_manifest"]:
        raise ValueError("original BuildManifest drift")
    nr, q = read(lc, args.numerical)
    expected = lc.numerical_fields(e, build)
    if any(q.get(k) != v for k, v in expected.items()):
        raise ValueError("actual ordinary numerical correspondence mismatch")
    e["numerical_qualification"] = nr
    spec = template(lc, args.arena_run_template)
    if spec["data_root"] != read(lc, e["config"]["path"])[1]["output"]:
        raise ValueError("actual arena output binding differs")
    plan, _ = read(lc, args.plan)
    if plan["sha256"] != e["canonical_plan_sha256"]:
        raise ValueError("actual approved arena plan differs")
    dest = destination(args.destination)
    intent(lc, dest, spec, e, build["artifact"], plan)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    for name in ("parents", "arena", "bind-arena"):
        s = sub.add_parser(name)
        s.add_argument("--destination", type=Path, required=True)
        if name != "bind-arena":
            for flag in ("build", "reference-output", "reference-guardian"):
                s.add_argument("--" + flag, type=Path, required=True)
        if name == "parents":
            for flag in ("sigma-run-template", "distance-run-template"):
                s.add_argument("--" + flag, type=Path, required=True)
        elif name == "arena":
            s.add_argument("--parent-manifests", nargs=2, type=Path, required=True)
            for flag in (
                "sigma-parent-result",
                "distance-identities",
                "arena-run-template",
                "arena-config-template",
            ):
                s.add_argument("--" + flag, type=Path, required=True)
        else:
            for flag in ("experiment", "numerical", "plan", "arena-run-template"):
                s.add_argument("--" + flag, type=Path, required=True)
    args = p.parse_args()
    lc = lifecycle()
    {"parents": parent_controls, "arena": arena_controls, "bind-arena": bind_arena}[
        args.command
    ](lc, args)


if __name__ == "__main__":
    main()
