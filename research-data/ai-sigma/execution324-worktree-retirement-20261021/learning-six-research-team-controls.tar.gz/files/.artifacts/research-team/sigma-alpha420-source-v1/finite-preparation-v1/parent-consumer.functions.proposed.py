def arena_cpu_cores(spec):
    """Bind this native evaluation's launch affinity to its current AI/main roles."""
    require(spec["kind"] == "run", "evaluation CPU allocation belongs to RUN")
    experiment = document(spec["experiment"])
    require(
        experiment["phase"] == "arena"
        or (experiment["phase"] == "compare" and experiment["argv"][1] == "decisions"),
        "three cores belong to serial arena/one-parent decisions",
    )
    config = document(experiment["config"])
    ai = config.get("cpu_cores")
    main = config.get("management_cpu_core")
    require(
        config.get("arena", {}).get("comparison")
        in {"whole_wall_time", "evaluator_fixed_depth"}
        and all(config.get(k) == 1 for k in ("workers", "active_games", "max_batch"))
        and config.get("inference_cpu_core") is None
        and isinstance(ai, list)
        and len(ai) == 2
        and all(type(cpu) is int and cpu >= 0 for cpu in ai)
        and type(main) is int
        and main >= 0
        and len(set([*ai, main])) == 3,
        "one game, fixed A/B worker cores and distinct main core",
    )
    cores = sorted([*ai, main])
    require(
        spec.get("child_cpu_cores") == cores
        and spec["limits"]["worker_cpu"] == ai[0]
        and spec["limits"]["guardian_cpu"] == main,
        "actual native launch affinity equals AI/main allocation",
    )
    support = document(spec["support"])
    resources = support.get("resources", {})
    require(
        resources.get("CPU") == 3
        and resources.get("threads") == 1
        and resources.get("GPU") == 0
        and resources.get("controller_included") is True
        and type(resources.get("family_RAM_B")) is int
        and resources["family_RAM_B"] > 0
        and resources["family_RAM_B"] == spec["limits"]["family_B"],
        "actual issued three-core evaluation family, not corpus/source-only authority",
    )
    return cores


def experiment_check(spec):
    charged_roots(spec)
    experiment = document(spec["experiment"])
    require(experiment["schema"] == EXPERIMENT_SCHEMA, "experiment schema")
    experiment_phase_check(experiment)
    manifest = accepted_build(experiment["build_manifest"])
    require(manifest["artifact"] == spec["artifact"], "same actual executable")
    mixed_outcome = (
        experiment["phase"] == "fit"
        and document(experiment["config"])["experiment"]["study"] == "mixed-outcome"
    )
    if mixed_outcome:
        # Current source hashes precede importing the new metadata-only admission.
        for caller in caller_source_refs(spec, experiment):
            read_ref(caller, max(CONTROL_BYTES, caller["bytes"]))
        common_study_check(spec, experiment, manifest, approved_plan(spec, experiment))
    refs = [
        experiment["config"],
        *experiment["inputs"],
        experiment["schedule"],
    ]
    if experiment.get("numerical_qualification") is not None:
        refs.append(experiment["numerical_qualification"])
    require(
        isinstance(experiment["dynamic_libraries"], list),
        "declared library array required",
    )
    for model in experiment["models"]:
        refs.extend([model["descriptor"], model["weights"]])
    for library in experiment["dynamic_libraries"]:
        require(
            isinstance(library["version"], str) and bool(library["version"].strip()),
            "dynamically loaded library version required",
        )
        refs.append(library["file"])
    refs.extend(caller_source_refs(spec, experiment))
    streamed_inputs = set()
    if (
        experiment["phase"] == "materialize"
        and manifest.get("artifact_target") == "terminal-cache"
    ):
        streamed_inputs = {r["path"] for r in document(experiment["config"])["streams"]}
    elif mixed_outcome:
        cache_root = Path(spec["argv"][6])
        streamed_inputs = {str(cache_root / name) for name in COMPACT_CACHE_WIDTHS}
    for ref in refs:
        if ref["path"] in streamed_inputs:
            require(artifact_ref(ref["path"]) == ref, "actual streamed input identity")
        else:
            read_ref(ref, max(CONTROL_BYTES, ref["bytes"]))
    if manifest.get("artifact_target", "quoridor-runner") == "terminal-cache":
        require(
            experiment["phase"] in {"materialize", "fit"},
            "converter only serves saved materialization or pinned Python fits",
        )
        if experiment["phase"] == "materialize":
            cache_materialize_check(spec, experiment, manifest)
    else:
        require(
            experiment["phase"] != "materialize"
            or isinstance(experiment.get("numerical_qualification"), dict),
            "ordinary model materialization still requires numerical qualification",
        )
    if experiment["phase"] == "generation":
        generation_check(spec, experiment)
    require(
        type(experiment["planned_slots"]) is int
        and 0 <= experiment["planned_slots"] <= 4096,
        "bounded planned denominator",
    )
    measurement = (
        experiment["phase"] == "compare" and experiment["argv"][1] == "measure"
    )
    if measurement:
        measurement_config(experiment)
        approved = None
    else:
        approved = approved_plan(spec, experiment)
        refs.append(spec["approved_plan"])
    if (
        experiment["phase"] in {"corpus", "fit", "software-qualification"}
        and not mixed_outcome
    ):
        common_study_check(spec, experiment, manifest, approved)
    if experiment["phase"] == "compare" and experiment["argv"][1] == "decisions":
        arena_decision_plan_check(experiment, approved)
        if document(experiment["config"])["arena"]["comparison"] == "whole_wall_time":
            arena_cpu_cores(spec)
        numerical_check(experiment, manifest, refs=refs)
        require(
            document(experiment["config"])["output"] == spec["data_root"],
            "decision owned runtime output",
        )
    if experiment["phase"] == "arena":
        arena_plan_check(experiment, approved)
        arena_config = document(experiment["config"])
        if arena_config["arena"]["comparison"] == "whole_wall_time" or (
            arena_config["arena"]["comparison"] == "evaluator_fixed_depth"
            and arena_config.get("management_cpu_core") is not None
        ):
            arena_cpu_cores(spec)
        numerical_check(experiment, manifest, refs=refs)
        require(
            document(experiment["config"])["output"] == spec["data_root"],
            "arena owned runtime output",
        )
    if (
        experiment["phase"] == "analysis"
        and len(spec["argv"]) > 3
        and spec["argv"][3] == "arena-analysis"
    ):
        arena_analysis_check(spec, experiment)
        numerical_check(experiment, manifest, refs=refs)
    executable = manifest["artifact"]["path"]
    if experiment["phase"] in {"analysis", "fit", "software-qualification"}:
        python = project_interpreter(experiment)
        read_ref(python, max(CONTROL_BYTES, python["bytes"]))
        executable = str(project_python())
    expected_argv = [
        a.replace("@EXPERIMENT@", spec["experiment"]["path"]).replace(
            "@EXPERIMENT_SHA256@", spec["experiment"]["sha256"]
        )
        for a in experiment["argv"]
    ]
    require(expected_argv[0] == executable, "executable argv drift")
    require(
        spec["argv"] == measurement_argv(spec, experiment, expected_argv),
        "exact experiment/profiler argv",
    )
    if spec.get("perf") is not None:
        refs.append(spec["perf"]["tool"])
    require(bool(spec["data"]), "actual durable data required")
    owned(spec["data_root"], spec["owner"])
    if (
        measurement
        or experiment["phase"] == "arena"
        or (experiment["phase"] == "compare" and experiment["argv"][1] == "decisions")
    ) and spec.get("TMP") is not None:
        owned(spec["TMP"], spec["owner"])
        require(
            not os.path.lexists(spec["TMP"])
            and spec["env"].get("TMPDIR") == spec["TMP"]
            and spec["TMP"] in spec.get("owned_outputs", []),
            "fresh owned execution TMP",
        )
    require(
        not Path(spec["data_root"]).exists(),
        "exclusive scientific output; duplicate run refused",
    )
    if experiment["phase"] == "arena" or (
        experiment["phase"] == "compare" and experiment["argv"][1] == "decisions"
    ):
        require(
            {
                x["name"]: x["path"]
                for x in spec["data"]
                if x["name"] in {"journal", "result", "native_manifest"}
            }
            == {
                "journal": str(Path(spec["data_root"]) / "completed.jsonl.gz"),
                "result": str(Path(spec["data_root"]) / "result.json"),
                "native_manifest": str(Path(spec["data_root"]) / "manifest.json"),
            },
            "mandatory canonical archive plus bounded native summary/manifest",
        )
    for finalizer in spec["finalizers"]:
        owned(finalizer["path"], spec["owner"])
    return (
        experiment,
        manifest,
        [*refs, experiment["build_manifest"], manifest["artifact"]],
    )


def arena_model_check(experiment, plan, width):
    used = set()
    for m in plan["matchups"]:
        require(
            set(m) <= {"id", "engines", "evaluator_sha256", "inference"}
            and {"id", "engines", "evaluator_sha256"} <= set(m)
            and len(m["engines"]) == len(m["evaluator_sha256"]) == width,
            "declared engine identities",
        )
        sigma = False
        for i, engine in enumerate(m["engines"]):
            kind = engine["kind"]
            require(
                kind in {"nnue", "distance", "mcts", "sigma_value"},
                "supported numerical backend",
            )
            if kind == "nnue":
                model = next(
                    (
                        r
                        for r in plan["models"]
                        if r["descriptor"]["path"] == engine["model"]
                    ),
                    None,
                )
                require(
                    model is not None
                    and model["evaluator_sha256"] == m["evaluator_sha256"][i],
                    "declared model/evaluator",
                )
                used.add(model["descriptor"]["path"])
            elif kind == "distance":
                require(engine.get("model") is None, "pure distance model")
            elif kind == "sigma_value":
                inference = m.get("inference")
                require(
                    plan["comparison"] == "evaluator_fixed_depth"
                    and engine.get("model") is None
                    and isinstance(inference, dict)
                    and inference["backend"] == "ort"
                    and inference.get("device", 0) == 0
                    and inference.get("cuda_graph", False) is False
                    and type(inference.get("logical_row_limit")) is int
                    and inference["logical_row_limit"] > 0
                    and len(m["evaluator_sha256"][i]) == 64
                    and all(c in "0123456789abcdef" for c in m["evaluator_sha256"][i])
                    and any(
                        r["path"] == inference["model"]
                        and r["sha256"] == inference["model_sha"]
                        for r in plan["inputs"]
                    )
                    and any(
                        r["file"]["path"] == inference["library"]
                        for r in experiment["dynamic_libraries"]
                    ),
                    "closed Sigma static value model/library/native-owned identity",
                )
                # The native owner recomputes the typed identity from actual library SHA.
                sigma = True
            else:
                inference = m.get("inference")
                require(
                    plan["comparison"] == "whole_wall_time"
                    and engine.get("model") is None
                    and isinstance(inference, dict)
                    and inference["backend"] == "ort"
                    and inference.get("device", 0) == 0
                    and inference.get("cuda_graph", False) is False
                    and inference["model_sha"] == m["evaluator_sha256"][i]
                    and any(
                        r["path"] == inference["model"]
                        and r["sha256"] == inference["model_sha"]
                        for r in plan["inputs"]
                    )
                    and any(
                        library["file"]["path"] == inference["library"]
                        for library in experiment["dynamic_libraries"]
                    ),
                    "closed Sigma model/library/backend correspondence",
                )
                sigma = True
        require(sigma == (m.get("inference") is not None), "unused/missing backend")
    require(len(used) == len(plan["models"]), "duplicate/unused model")


def arena_plan_check(experiment, plan):
    """One explicit JSON arena plan; config files own engines and search/clock limits."""
    require(
        set(plan)
        == {
            "schema",
            "phase",
            "comparison",
            "rules",
            "distance_units",
            "value_perspective",
            "book",
            "inputs",
            "models",
            "schedule",
            "family_ids",
            "matchups",
            "batches",
            "planned_slots",
        }
        and plan["schema"] == "quoridor.research.arena-plan.v1"
        and plan["phase"] == experiment["phase"] == "arena"
        and len(experiment["argv"]) == 6
        and experiment["argv"][1:]
        == [
            "arena",
            "--experiment",
            "@EXPERIMENT@",
            "--experiment-sha256",
            "@EXPERIMENT_SHA256@",
        ]
        and plan["comparison"]
        in {"evaluator_fixed_depth", "evaluator_wall_time", "whole_wall_time"}
        and plan["rules"]
        == experiment["rules"]
        == "research-standard-2p-threefold-goal-first-v1"
        and plan["distance_units"] == experiment["distance_units"] == "wall-distance/80"
        and plan["value_perspective"]
        == experiment["value_perspective"]
        == "side-to-move"
        and plan["inputs"] == experiment["inputs"]
        and plan["book"] in plan["inputs"]
        and plan["models"] == experiment["models"]
        and plan["schedule"] == experiment["schedule"],
        "arena declared scientific correspondence",
    )
    schedule = document(experiment["schedule"])
    planned = planned_game_slice(experiment, schedule, plan)
    config = document(experiment["config"])
    batch = plan["batches"][experiment["batch"]]
    require(experiment["config"] == batch["config"], "approved batch config")
    matchup = next(m for m in plan["matchups"] if m["id"] == batch["matchup"])
    a = config["arena"]
    engines = config["engines"]
    require(
        config["ruleset"] == "standard_2p_threefold"
        and config["games"] == len(planned)
        and all(
            type(config[k]) is int and config[k] == 1
            for k in ("workers", "active_games", "max_batch")
        )
        and not a.get("decision_only", False)
        and config.get("inference") == matchup.get("inference")
        and (
            config.get("inference") is not None
            or config.get("inference_cpu_core") is None
        )
        and config.get("cycle") is None
        and config.get("train_games") is None
        and config.get("validation_games") is None
        and engines == matchup["engines"]
        and len(engines) == 2
        and a["evaluator_sha256"] == matchup["evaluator_sha256"]
        and a["comparison"] == plan["comparison"]
        and a["clock_policy"] == "strict_unknown"
        and type(a["tt_entries"]) is int
        and 0 < a["tt_entries"] <= 1048576
        and type(a["retained_outcome_bytes"]) is int
        and 0 < a["retained_outcome_bytes"] <= config["max_output_bytes"]
        and (
            plan["comparison"] == "whole_wall_time"
            or a["search_artifact_sha256"][0] == a["search_artifact_sha256"][1]
        ),
        "arena equal runtime/backend/retention conditions",
    )
    arena_model_check(experiment, plan, 2)
    for engine in engines:
        require(
            type(engine["depth"]) is int
            and 0 < engine["depth"] <= 200
            and type(engine["max_nodes"]) is int
            and engine["max_nodes"] > 0
            and type(engine["simd"]) is bool
            and type(engine.get("lmr", False)) is bool
            and (
                "lmr_method" not in engine
                or engine["lmr_method"]
                in (
                    "fixed_one",
                    "depth_rank",
                )
            )
            and engine.get("ordering_profile") in {None, "control", "cheap"}
            and (
                not engine.get("lmr", False)
                or engine.get("ordering_profile") is not None
            )
            and (
                engine.get("ordering_profile") is None
                or (
                    engine["kind"] in {"nnue", "distance", "sigma_value"}
                    and not a.get("disable_continuation_static_ordering", False)
                )
            )
            and all(
                type(engine[k]) in (int, float) and math.isfinite(engine[k])
                for k in ("distance_a", "distance_b")
            ),
            "finite engine limits",
        )
    require(
        plan["comparison"] == "whole_wall_time"
        or all(engines[0][k] == engines[1][k] for k in ("depth", "max_nodes", "simd")),
        "equal search limits",
    )
    if plan["comparison"] == "evaluator_fixed_depth":
        require(
            all(engine.get("time_ms") is None for engine in engines)
            and a["return_reserve_ms"] == 0,
            "completed depth has no move clock",
        )
    else:
        require(
            type(engines[0]["time_ms"]) is int
            and engines[0]["time_ms"] > 0
            and engines[1]["time_ms"] == engines[0]["time_ms"]
            and type(a["return_reserve_ms"]) is int
            and 0 <= a["return_reserve_ms"] < engines[0]["time_ms"],
            "equal thinking clocks and reserve",
        )
    require(
        type(a.get("disable_continuation_static_ordering", False)) is bool,
        "explicit alpha ordering selector",
    )
    book = document(plan["book"])
    require(
        book["complete"] is True and book["rules"] == plan["rules"],
        "complete bound book",
    )
    families = {f["family_id"]: f for f in book["families"]}
    require(
        len(families) == len(book["families"])
        and set(plan["family_ids"]) <= families.keys(),
        "book family coverage",
    )
    require(
        len(a["book"]["openings"]) * 2 == len(planned)
        and len(a["first_candidate_colors"]) == len(planned) // 2,
        "local pair book",
    )
    for i, opening in enumerate(a["book"]["openings"]):
        slot = planned[i * 2]
        f = families[slot["family_id"]]
        ref = opening["reference"]
        require(
            opening["id"] == f["id"]
            and opening["prefix"] == f["prefix"]
            and opening["original_seed"] == f["seed"]
            and ref["source_sha256"] == plan["book"]["sha256"]
            and all(
                ref["settings"][k] == f[k]
                for k in ("family_id", "root_key", "history_counts")
            )
            and a["first_candidate_colors"][i] == slot["candidate_color"],
            "immutable book/history/colour",
        )
    return planned, config
