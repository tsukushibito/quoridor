# 420.1 既存CPU raw value参照

実参照が見つかった。旧347 untimed測定の `items[i].parent.prefix` と `items[i].receipt.counters.root_nn_stm` を対応させる。`receipt.value_stm` はMCTS meanであり使わない。

原結果: `/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/live-untimed-v1/measurement-result.json`
SHA256 `cb106555804d1506f98823966d20c88befe465c0a72cee0ee9df6a00facd6986` / 61595B。旧live64-acceptanceのselected_refsで束縛されている。

| ID | full prefix | STM | raw value | MCTS mean（参照にしない） |
| --- | --- | ---: | ---: | ---: |
| 347-family-00-stm-0 | `[]` | 0 | 0.21437488496303558 | 0.20274470746517181 |
| 347-family-00-stm-1 | `[13]` | 1 | -0.19111452996730804 | -0.2063872516155243 |
| 347-family-01-stm-0 | `[13, 67]` | 0 | 0.22165998816490173 | 0.21917076408863068 |
| 347-family-02-stm-0 | `[3, 77, 152, 206]` | 0 | -0.4585413634777069 | -0.06135721504688263 |
| 347-family-02-stm-1 | `[3, 77, 152]` | 1 | -0.1042877584695816 | -0.01687895879149437 |

所有コード `sigma_clock.rs:303–306` は最初の有効backend返却 `output.value` を `root_nn` へ無変換で保存し、その後MCTS supplyへ渡す。`counters():89–97` が `root_nn_stm` を出す。MCTSのfresh root index0から最初の入力を取るので、保存full prefixのrootに対応する。旧configured workloadはfull-prefix/非terminal/legal確認済みであり、この読取では再実行していない。

両旧configのCPU ORT/model/libraryは同一。origin admissionの実bindingがmodel d790…/11663428B、library c902…/28985152Bを含み、既存374証拠の1.30.0に対応する。payloadは再hash/loadしていない。

Rootは5候補から少数を選べる。Packet.reference_source_sha256は原結果SHA、rows.expectedはraw値とする。新input/outputはこの作業では作成しない。32上限/100K・200K・300K枠、6親/8局を変更しない。原cost/time有効期限を復活させず、現在のadapterが一致するというPASSへ一般昇格しない。既存16/28suite再演、推論/モデル/RAW/テスト/ゲームは0。

正確なFileRefs、JSON pointer、FP32 bits、設定/所有コード範囲、前後一致と読取STOPはreference-locators-v1.jsonに記録。親が原helperのdirectwait/reap/handles/TMP/lease releaseを追記する。
