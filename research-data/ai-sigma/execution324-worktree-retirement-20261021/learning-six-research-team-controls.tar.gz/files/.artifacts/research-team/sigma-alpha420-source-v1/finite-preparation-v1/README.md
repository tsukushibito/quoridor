# 420 finite caller/input preparation

This directory contains metadata only. The five-row `reference-input.json` is an actual input Packet, not a result. `reference-provenance.json` preserves original FileRefs, FP32 bits, STM and raw value pointers. The reference output, current Build and native numerical results remain absent. Frozen source/STOP and earlier finite-settings remain unchanged.

`prepare.py` uses current maintained lifecycle bound/new_json/canonical_sha/numerical_fields shapes. It never submits a command or runs native/model code, never computes evaluator identity, never loops/retries operations, and never creates numerical PASS. Invoke it only inside the ordinary Root source/resource/identity guard. Root owns actual resource support, submissions, current source, numerical evidence and finalization. Its metadata destination must be a new directory below this directory; runtime outputs are the actual paths in Root-provided ordinary RUN templates and are not created by this helper.

## Root sequence

1. Run the compiled ignored `sigma_evaluator::tests::sigma_value_actual_cpu_reference_bounded` once, with this reference-input and a unique output path, under the genuine owning Build/test artifact and current inputs. Both environment variables retain the already supplied names. The Packet has max_states=5 and logical_row_limit=5. No extra warmup or logical row is allowed. The current Rust function emits `evaluator_identity`; do not calculate it in Python. Retain original guardian and setup/warm/failed/physical costs separately.
2. Materialize two normal measurement entries (12 Sigma and 12 D calls). Supply actual finalized Build, actual reference result/guardian and two actual ordinary RUN templates. No provisional/fake fields are accepted. Each request uses a distinct cold session for D1/D2, identically for both evaluators; the single Sigma Arc/backend persists across all 12 sessions. The helper binds the actual reference logical count, leaving 100000 minus that count for Sigma parents. Optional419 auxiliary inference is omitted; no extra entry is created.
3. After both parent operations' sole PASS/finalize/cleanup, supply both original manifests and the actual Sigma measurement result with its logical count. The arena preparation additionally requires actual Rust D identity metadata, an actual current ordinary arena config template, and Root's ordinary RUN template. It materializes the fixed four canonical families' eight colour slots, same Build/image, D2/50K/TT1M/PVS/Control, no clock/LMR/approximation, 200 total ply. It never starts an arena. It creates `experiment.UNBOUND.json`, not a ready Experiment or numerical proof. The real per-operation physical/fair/cancel/storage and family guard remains at the maintained actual entry.
4. Root supplies its genuine ordinary numerical correspondence after the config/schedule/plan exist. `bind-arena` checks exact current normal numerical fields before binding the actual existing proof and RUN intent; it does not create PASS or copy an old qualifier. Normal accepted_build/phase/source/input/library/owned guards still execute at launch.

Example metadata-only commands (all ACTUAL paths must exist; placeholders are prose, not FileRefs):

```text
project-env.sh python -B prepare.py parents --build ACTUAL_BUILD_MANIFEST --reference-output ACTUAL_REFERENCE_OUTPUT --reference-guardian ACTUAL_ORIGINAL_GUARDIAN --sigma-run-template ACTUAL_SIGMA_RUN_TEMPLATE --distance-run-template ACTUAL_D_RUN_TEMPLATE --destination OWN_NEW_PARENT_CONTROLS
project-env.sh python -B prepare.py arena --build SAME_ACTUAL_BUILD_MANIFEST --reference-output ACTUAL_REFERENCE_OUTPUT --reference-guardian ACTUAL_ORIGINAL_GUARDIAN --parent-manifests ORIGINAL_SIGMA_PASS ORIGINAL_D_PASS --sigma-parent-result ORIGINAL_SIGMA_RESULT --distance-identities ACTUAL_RUST_D_IDENTITIES --arena-run-template ACTUAL_ARENA_RUN_TEMPLATE --arena-config-template ACTUAL_CURRENT_ARENA_TEMPLATE --destination OWN_NEW_ARENA_CONTROLS
project-env.sh python -B prepare.py bind-arena --experiment ACTUAL_GENERATED_EXPERIMENT_UNBOUND --numerical ACTUAL_ORDINARY_NUMERICAL --plan ACTUAL_GENERATED_ARENA_PLAN --arena-run-template SAME_ACTUAL_ARENA_RUN_TEMPLATE --destination OWN_NEW_BOUND_CONTROLS
```

## Input and scope correspondence

`measurement-roots.json` contains the six already frozen full prefixes, not board-only states. Selectors are `input:0`, `pointer:/parents/i`, `field:prefix`, `check_history:false`, `loss_leaf_419:false`. Current normal root_spec directly reads that full vector; native replay derives complete legal history/STM/stock and rejects terminal roots. Original source refs and pointers stay beside each prefix. This does not claim an independently rechecked board/history before native entry or introduce 419 head/forced-tree work into420.

The literal five old raw references are distinct from MCTS mean/policy/z. Parent measurement settings use no NNUE descriptor; Sigma model is an actual input and its library an actual dynamic-library FileRef. D uses the existing native D namespace; arena D SHA must come from actual native evaluator identity metadata. Helpers never infer identity from model name or encode a Python implementation of its hash.

Arena actual logical limit is min(200000, 300000-reference_actual-parent_actual). Reference plus parents must stay <=100000. Unknown/noninteger counts refuse; no reset/refill on operation/backend recreation. One arena operation retains one Sigma Arc over all eight games. Stops/errors/partial parents do not advance to arena. No automatic game replacement or repeat is implemented.

## Precise remaining dependencies

- Actual current compatible Build/test artifact, original reference result/guardian and Rust identity are not yet available to this author. No parent/arena Experiment was generated with fake future refs/counts.
- Root must join the actual reference guardian/test artifact to its owning Build/source, and each supplied parent result to its original finalized operation. These existing custody facts are not certified by this helper's field parsing.
- Root ordinary RUN templates own CPU2/G4 parent controls, arena AI2/6/main4, family4GiB/controller allowance, support/storage/cancel/pause/output/finalizer fields. No resource allocation is issued here.
- Python arena_model_check still whitelists nnue/distance/mcts, and arena_plan_check's explicit ordering whitelist excludes sigma_value. A minimal ordinary two-function proposal is supplied separately; Main remains untouched. Further genuine arena CPU-launch predicate correspondence is checked only through its owning function, not by bypassing it.
- Actual normal numerical proof is required before bind-arena. Configuration/source readiness does not prove numeric parity or arena performance. Original32-reference/24-search/8-game/300K limits and paused learner/mixed/323/defaults/seals are unchanged.

Only parser/formatter/self-consistency checks belong to this preparation. No fake-input test campaign, production edit, native/software suite, model/library load or new numerical call is authorized for this author. The final binding records actual performed checks and any remaining guard refusal truthfully.
