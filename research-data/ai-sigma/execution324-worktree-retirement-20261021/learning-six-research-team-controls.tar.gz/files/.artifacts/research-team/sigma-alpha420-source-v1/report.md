# 420.1 Sigma value / 共通 alpha-beta 接続

本成果は私有ソースと有限設定の引渡しである。Cargo、型検査、テスト、ORT、モデルforward、Search、対局は作者から実行していない。元381/mixed/323の停止状態は不変。Main/Git/Cargo、419との疎合成、真正image、限定softwareと科学実行は324が所有する。

## 接続と所有

`config::Inference.logical_row_limit: Option<u64>` を追加し、Sigma static-valueでは正の明示値を要求する。`Engine.kind="sigma_value"`、`model=None` と同一の通常factoryを使う。`measurement::Settings.inference` は同じInferenceを任意で受ける。別のengine設定フィールドやNNUE偽descriptorは追加しない。ONNXはExperiment.inputs、ORTはdynamic_librariesの実FileRefに束縛する。

新しいnative専用 `sigma_evaluator` は既存OrtBackend/InferenceBackendをMutex内で一所有する。maintained `features(context.position())` を使い、STM valueを追加の符号反転・tanh・尺度変換なしで返す。policyはorderingへ渡さない。policyとvalueの一体計算費は残る。portable AI/Wasm、探索loop、モデル、特徴、Cargo依存を変更しない。

identityはkind、model SHA、library SHA、CPU/FP32/batch1/intra1/inter1/sequential、feature/出力意味を束縛する。pathと行予算は数値identityへ含めない。typed evaluator namespaceは `sigma-value-onnx-cpu:sha256:<actual identity>`。D/異モデル/異libraryと数値TTを共有しない。fresh SearchSessionはbackendの累積をresetしない。

terminalは共通Search正本が先に処理する。adapterへの直接terminal要求は失敗する。backend error、出力shape/nonfinite/range、予算拒否、poisonをゼロ値へ変えない。既存cancel/親復元/partial/error/finalizerを使う。非同期推論thread、queue、cache、registryは増やさない。

## 同じ固定深度 arena

既存EvaluatorFixedDepthにmanagement CPUがある場合、現役two-AI/main経路を再用する。backendはSigma AI workerの中で生成・使用・dropする。一つのowned backendは8局のゲーム境界を越えて保持し、TT/sessionのみゲーム毎にresetする。no-clockではdeadlineはNoneであり、WholeWallTimeの成功へ読み替えない。既存 `fixed_depth_completed` と受理処理がrequested depth未達をUNKNOWNへする。error/cancel時もcompleted浅層や合法fallbackで成功しない。

通常two-AI manifestにmain-owned receipt、no-clock acceptance、実TT profileを使う記載を置く。旧beginのlegacy4096推定をこの現役経路の実capacityだと主張しない。source policyの予定値、実capacity/retained bytes、timingは区別する。

## 凍結入力・設定

`fixed-inputs.json` は419の既存凍結3親と、既存355 canonical family0/1/2のopeningを結果盲検で選ぶ。arenaは同bookのfamily0/1/2/3を両色で使う。全追加prefixは4ply。419のslot4/slot5はcanonical family0の子孫で、独立な別familyではない。Rootでの真正imageによるルール/full-history/非terminal受理はまだUNRUNである。旧RAW再decode、結果依存の再選択は0。

book: `/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/value-search-strength355/maintained-build-v1/campaign-generation-v1/data/book.json`、a6abde1f…/85083B。canonical family0のprefixは[186,77,13,68]、374実RAW aliasは374-primary-batch-002-v1-family-000000である。

`backend-inputs.json` は既存374 backend-expectationの実model d790…/11663428BとORT c902…/28985152B・version1.30.0を参照する。作者は必要pathのstatのみ対応し、モデル/library payloadの再hash/loadはしていない。実Runの通常before/after入力検査はRootの責務である。

`finite-settings.json` に6親×D1/D2×2評価器=最大24 Search、50K/call・総1.2M nodes、Control/TT1M/PVS/LMR・近似・safe OFF/time None、固定深度4系統×2色=8局・D2・200 total plyを記録した。真正Build/image/typed identity/Experiment/admission/出力は未生成のためnullであり、ready証明ではない。arena/model/dataの権限を偽のaliasやphaseで得ない。

## 行予算と実費

reference最大32と任意419 witness最大256と固定親を合わせ100K logical、後の8局200K、科学総量300K以内。settingsの正のlimitは一owned backend内で強制する。通常entryでoperationを跨ぐ時は原結果のlogical消費を差し引いた残量を次設定へ渡す。新operationを作って100K/200Kを再付与しない。

推奨実行単位はreference、全12 Sigma-root callsを一measurement operation、8局を一arena operationである。Dの12 callsを加えて24 calls。referenceの実logical消費を100Kから差し引く。optional witnessの残量がなければ未実行UNKNOWNのまま止める。失敗/不明の消費から勝手に残量を作らない。残量の証拠は原normal receiptsであり、別ledgerやschedulerは追加しない。

logical、executed、warm、failed、failed-warm、capture不明、adapter試行/失敗/事前拒否、同期時間を区別する。failedはlogicalに既に含まれ得るため二重加算しない。new actual CPU reference testも同じfactoryを使い、別の評価器を写さない。policy未使用をvalue-only推論費と呼ばない。

## 新しい限定software定義

Rootでのdefault新規filterは `cargo test -p quoridor-runner --features measurement --lib sigma_value_ -- --nocapture`。新規fake NN0は6定義、実CPU reference1定義はignoreである。現在全てUNBUILT/UNTYPED/UNRUN。旧成功suiteを含めて実行しない。

- sigma_value_stm_features_and_unmodified_scalar_nn0: 両STMのmaintained特徴をbackendへ渡し、scalar bitsを無変更で返す。
- sigma_value_terminal_cancel_and_common_search_do_not_infer_nn0: goal/threefold terminal、cancel、親/history、fake warmとnode推論を区別する。
- sigma_value_backend_error_range_budget_and_reset_preserve_failure_nn0: 原backend E、空/非finite/range、累積上限と新sessionでも拒否、親/history。
- sigma_value_typed_identity_and_config_do_not_mix_numeric_tt_nn0: 同bytesでpath/limit変更は同identity、異model/libraryは異identity、CPU設定拒否とcommon Search。
- runtime::sigma_value_runtime_tests::sigma_value_fixed_depth_same_factory_no_clock_or_shallow_fallback_nn0: 現役arena factory、no-clock固定深度入口、浅層拒否。
- measurement::sigma_value_binding_tests::sigma_value_measurement_closed_inputs_and_common_control_nn0: model/library/namespaceのclosed binding、Control/非選択探索条件。

ignore定義の正確名は `sigma_evaluator::tests::sigma_value_actual_cpu_reference_bounded`。Rootが真正test artifactと通常有限numerical custodyで `--exact --ignored --nocapture` を使う場合だけ実行する。入力 `QUORIDOR_SIGMA_VALUE_REFERENCE_INPUT` と独立の新出力 `QUORIDOR_SIGMA_VALUE_REFERENCE_OUTPUT` を指定する。inputはInference、library_sha256、reference_source_sha256、max_states、rows[{id,prefix,expected}]。Rootが32以内の本物の同CPU参照とその入力FileRefsを事前束縛する。未到着/同等性不明の参照はPASSにしない。1MiB入力上限、terminal/finite/range、最大1e-6誤差、段階出力と実counterを記録する。作者が実モデルを実行するものではない。

## 419との交点・未解決の真正依存

beforeは61d783時点の必要5既存fileと新2fileで、Main419の7b79採用を上書きしない。Root報告の419 source-binding4682f577/function-subject-map668ad07bを交点とする。measurementのSettings、load_evaluator（419 canonical load_residual_modelを保持してSigma分岐を合成）、run/SearchTarget、RootSelector周辺は疎合成する。420は旧loaderへ戻さず419数学へSigmaを混ぜない。runtime factory、enum消費者は必要なSigma branchのみ合成し、419 NNUE head/forced/common-treeは保持する。

原before/postの薄いpatchと各hunk/関数を引き渡す。型検査・Clippy・実6新定義・限定CPU reference・数値比較・8局・真正出力/実費/STOPはRoot実行時の実依存で、未実行のままである。追加reviewはこの入力/STM/error/identity/同factory境界だけを既存SolへRootが配送する。source clearは数値/棋力/速度/default採用を意味しない。

## 保存・停止

ordinary source/testsの事前枠は設けない。最後にOWN packetと変更した私有sourceだけ一度使用量を数える。既存covered49,328,115,712B/global actual UNKNOWN/decimal50GBと本新差分・進行419分はRootが合成し、shared target全量の再課金や削除refundを行わない。元PRIVATE差分はOWN-before.gzに保存した。

format-v2、および実STOPを受けた次のentryでもcanonical EAGAINとなり、どちらもformatter/childは未入場だった。二件を保存し、holderを推定していない。最終formatterと厳密patch往復の結果、actual reader/writer/child/handle/TMP/lease STOPは別の固定binding/STOPを正本とする。
