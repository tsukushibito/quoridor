# 421.2 勝敗mixed-outcomeのT抽出・公開のみ比較入口

新421だけのsource/NN0成果。Main/Git/Cargo・実scienceは324所有。旧323/342.17/全旧learner prepのUSERPAUSE、旧RAW/FAILED/費/UNKNOWN、BEST43/尺度/特徴/既定を維持した。実モデル・Torch・GPU・既存公開payload・生成・native・fitは作者0。420の停止済みsource/helpersは変更していない。

固定契約はe3cb5b30、独立設計specはafa79145（7583B）。生成各手4Mは同specの事前選択で、旧2M履歴や初回D4確認の2Mを変更しない。今回の学習はz/MSEのまま、モデル・scale・head・native export・outcome_inputs・restore・学習率の意味を変えていない。

## 疎な変更と対応

- `sampling.family_training_view` は既存family/split検査を保ち、明示されたstock strataの場合だけgame単位で抽出する。既存 `row_game_codes` と `geometry.stocks` の合計を使用。4層の各8行まで、chronological端点を含む等間隔。quotaを他層へ移さず、Vとineligible/RAWを変更しない。同じcollision familyに複数gameがある場合も別gameの上限を誤ってfamily32へまとめない。
- `common` のconfigは `mixture.train_stock_strata`、`mixture.added_sampling_seed`、`selector.added_metric` を明示する。strataとfamily capは同時指定不可。`added_rows=0` を許可し、public-onlyでも空のT/Vを誤って許可しない。旧維持テストのmetadata fixtureだけ新しい明示fieldへ更新し、旧テストbodyは変更・実行していない。
- `mixed_batch` のCは追加Tをdecodeしない。Mの128+128とCのpublic256は従来と同じFP32 row平均lossを一回取る。publicの同seed系列は同じn番目のdrawを与えるが、updateごとの使用量は異なる。
- `planned_work` は公開のみのゼロ除算をなくし、明示Uを使用する。Mは従来の追加露出上限を使う。C/MのUは実viewのRから同時に解決する。earlystopは無効、BESTはnewVのfamilyごとのSSE/countを平均し、厳密改善だけ採用（同値は早い点）、publicV gateはfalse。
- 観測はfull opened-publicV/all newV、固定publicT8192/選択newT。同じ予測からrow/family/stock MSE、non-draw sign、draw数/平均絶対値、abs>=.9、10固定binのp=(v+1)/2とt=(z+1)/2を残す。空stratumの指標はnull。V選択はfamily-MSE、publicVは別監視である。
- 既存optional `--input-binding` の `files.initial_observation` に、Cの実 `initial-observation.json` FileRefを束縛できる。初期weights/descriptor/scale、cache manifest、public membership、batch、各scopeの実index SHA/count、constant、strataが完全一致する場合だけMのINITIALを実観測として再利用し、新規forwardを0計上する。不一致はモデルcall前に拒否する。新しいauthority/registryではなく既存input-bound observationであり、Rootはその実FileRefを通常Experiment.inputsにも加える。
- 既存attempted/completed/UNKNOWN LASTの区別を保持。失敗も含め、完了updateに対応するexposure保存、LAST（verifiedのみ）、result、identity-after、全closeの独立finalizerを維持する。optimizerが途中mutateして失敗した状態を以前のstepへ戻したりverified扱いにしない。

## 実設定と後段接続

`settings.SELECTED.json` は新421の解決済みrecipe。未来cache/新weights/R/Uはnullで、RUN/admissionではない。旧342.17設定は読み取り参照だけで変更せず、新specの整数seed17/18/19/20/22を完全値で束縛した。

`prepare-configs.py --cache ACTUAL --output NEW_CONTROLS` は、source採用と実conversion後にRootが既存guard内で一度使える設定materializer。maintained TerminalCorpus/family_training_view/resolve_config/planned_workを使い、実R/newVが非空のとき `U=min(64,ceil(4R/128))`、warmup `min(10,U)`、unique `{0,ceil(kU/4)}` を解決する。C/Mは同U・同BEST43からfresh Adam。helper自身はlaunch/モデルcall/未来output探索をしない。実cacheへの実行はUNRUN。

Rootの既存coded sequenceで、実64request schedule/partition→既存converterの実outcome cache→実R依存二config→C→実C STOP/finalize/cleanup→Mを結ぶ。Mには実C INITIAL観測のbindingが必要で、欠けると計画forward上界がsamplesを超えて拒否する。正常初期観測を再計算して埋めない。二fitの実LAST/BESTを凍結し、変更重みだけの有限対応（最大128states/1024rows）、既定24 D4確認、最大128arenaへRoot/data ownerが実FileRefで結ぶ。C/M間のoptimizer再利用やarenaでcheckpoint再選択はない。

R=2048/newV=12800を独立に保守上界として用いた設定算術は、二fit+1024 reserve=4,013,502行。実RのU<=51は64 unique familyかつ51Tの場合だけで、一般にはR<=2048/U<=64。小Rでは端数fullbatchにより4/5回より多く同一行が使われ得る。実visits/exposureを報告し、残り6M枠は追加実験へ転用しない。各fit32MiB local output stopはwhole256MiBやdecimal50GBの代用ではなく、Rootの実owned-union/whole guardが別に必要。

## 実softwareと限界

新規の限定NN0定義のみ。最初の4定義commandで3PASS、残り1定義はfixture期待値1.0が正しいfamily .5/row1/3と異なりFAILED。元capture/receiptを保持し、期待値だけ訂正した未完了定義を単独PASS。続くstock-owning entry、実設定の最大件数算術、draw/calibrationの新定義がそれぞれPASS。実Torch import/NNUE forwardは全て0。fake frameworkのfixture作業量は別記し、BEST43/parity/実性能/実fitの資格にしない。

Ruff format/check/lintは変更対象だけ実行。正本設定tools/research-quality/ruff.toml（100/py311）へ訂正し、変更外のformat差分は復元、AST不変を確認した。初回pyproject指定はRuff設定なしで80幅となり、2回のoutside-owner静的拒否をそのまま保持した。初回fixtureの未使用import/E402 lint拒否と、JSON receiptとstdout logを取り違えた管理read失敗も保持している。旧381/371/366/codec/head/model/frameworkの成功suiteは再実行していない。独立source確認/実compact interoperability/実Torch・native・fit・arenaはRootの次の実依存であり、この報告が科学成功を与えない。

CPU10 workerの既存guard、family1GiB/GPU0、fresh physical/quiet/NBで短いsoftwareを直接wait/reapした。guardian14は候補としてphysical検査され、初期short commandsの親affinityは明示pinされていなかった（正確なhistorical affinityはUNKNOWN）。最終proofのguardianは14へ明示pin。RSSピークはUNKNOWN、guardの上限と実peakを混同しない。Go/NodeへのAS512MiB制限は使用していない。実STOP/元PID-start-bootのfreshabsence・TMP/lease解放・postusageはbindingへ一度記録する。
