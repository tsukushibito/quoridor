# 421 C/M 現行callerの最小対応

凍結9f14/fcc9/source packetは不変。新規production/helperは不要で、既存prepare-configs.pyだけを実cache到着後に使う。cache未作成の現在はR/U、二config、MのINITIAL binding、Run/admissionを作らない。Rootが報告した生成64完了・2822行をselected TのRへ置換しない。RAWの再streamも行っていない。

通常の公開entryはproject-env.sh python -B。Run内部はparentが要求するproject_python() -B -m quoridor_training.train train --cache ACTUAL --output THIS_DATA_ROOT --config ACTUAL_CONFIG。--steps/--scale/--supply-workers/--guard-configは足さない。Cはdistinct bindingが不要ならsuffixなし、Mは--input-binding ACTUAL_BINDINGを付ける。

M bindingはcache_manifest_sha256とfiles.initial_observationの実FileRefを持つ。binding JSON自体と原C/initial-observation.jsonの実FileRefを両方Experiment.inputsへ入れる。new model重みや未来観測を代用しない。Python/currentcaller/lib/Build/モデル・scale/corpusの通常refsと、同順序inputSHA・configSHA・scheduleSHA・approved planの既存numerical correspondenceをRootが束縛する。作者はQ/PASS recordや未来FileRefを作成していない。

parentはphase fit/planned_slots0、STM/wall-distance80/threefold-goal-first、モデル1件のdescriptor/weights/evaluator一致、fresh optimizer/incumbent scaleを要求する。compact manifest+7binaryは実SHA-sizeと正の適格T/V、marker不在を検査する。公開T/V payloadをExperiment.inputsに加えると公開全量hash回避の親検査に拒否されるので、公開membership+acceptanceだけを束縛しindexed readerを使う。sealed Eは開かない。

fitのchild_cpu_coresは使用不可。parentのBLAS環境3種は1、recipeのTorch threads2は別の明示設定なので、parent predicateを緩めない。実fit用CPU/RAM/whole256MiB/6M allocation・normal custodyはRootがactual entryで成立させる。作者の10/14/1GiB/G0 source guardはfit権限ではない。local32MiBをwhole256MiBへ読み替えない。

C STOP/finalize/cleanup後に、実INITIAL identity/scopes/constant/cache/publicを束縛してMへ渡す。Mは同じBEST43/freshAdamから開始し、Cのoptimizer/学習重みを使わない。保存INITIALが不一致・欠測なら実拒否として止め、再forwardで穴埋めしない。Mのsample capは共有INITIAL0forward前提なので、binding欠落を既知のままlaunchしない。

新しいsoftware/model/forward/native/fit・元7NN0の再演0。出力はrecipe.jsonとこの説明・guard receipt/STOPだけ。実cacheを監視/pollしていない。今回の依存はactual conversionだけで、420/421 parent closeやACKではない。
