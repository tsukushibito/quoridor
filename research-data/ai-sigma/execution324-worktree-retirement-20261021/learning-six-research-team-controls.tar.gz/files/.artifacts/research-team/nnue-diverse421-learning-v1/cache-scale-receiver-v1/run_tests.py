"""Run only the four genuinely new metadata tests against private derivatives."""

import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "python"))
import quoridor_training

for name in ("common", "public_replay"):
    spec = importlib.util.spec_from_file_location("quoridor_training." + name, OWN / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    setattr(quoridor_training, name, module)
spec = importlib.util.spec_from_file_location("receiver_nn0", OWN / "test_cache_scale_binding.py")
tests = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = tests
spec.loader.exec_module(tests)
suite = unittest.defaultTestLoader.loadTestsFromTestCase(tests.CacheScaleBindingNN0)
result = unittest.TextTestRunner(verbosity=2).run(suite)
facts = {
    "tests_run": result.testsRun,
    "failures": len(result.failures),
    "errors": len(result.errors),
    "real_torch_imported": "torch" in sys.modules,
    "numpy_imported": "numpy" in sys.modules,
    "real_forward_rows": 0,
    "actual_model_or_corpus_qualification": False,
}
(OWN / "nn0-result.json").write_text(json.dumps(facts, indent=2) + "\n")
print(json.dumps(facts))
sys.exit(
    0 if result.wasSuccessful() and result.testsRun == 4 and not facts["real_torch_imported"] else 1
)
