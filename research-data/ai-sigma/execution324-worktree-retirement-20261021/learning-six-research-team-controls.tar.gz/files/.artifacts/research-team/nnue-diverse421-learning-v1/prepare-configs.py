"""Materialize only configs from an actual common cache; never launch or infer."""

import argparse
import copy
import hashlib
import json
from pathlib import Path


def resolved_pair(template, rows, validation_rows, public_rows):
    """Same data-derived finite horizon; no old epoch/update fallback."""
    from quoridor_training.common import resolve_config
    from quoridor_training.public_replay import planned_work

    if rows <= 0 or validation_rows <= 0:
        raise ValueError("actual nonempty selected T and full V required")
    updates = min(64, (4 * rows + 127) // 128)
    points = sorted({0, *((k * updates + 3) // 4 for k in range(1, 5))})
    configs, plans = {}, {}
    for arm in ("C", "M"):
        cfg = copy.deepcopy(template[arm])
        cfg["training"].update(steps=updates, warmup_steps=min(10, updates))
        cfg["evaluation"].update(checkpoints=points, diagnostic_checkpoints=points)
        plan = planned_work(cfg, rows, validation_rows, public_rows, reuse_initial=arm == "M")
        cfg["limits"]["samples"] = plan["forward_upper"]
        configs[arm], plans[arm] = resolve_config(cfg), plan
    if (
        sum(p["forward_upper"] for p in plans.values()) + template["changed_weight_forward_reserve"]
        > template["whole_forward_cap"]
    ):
        raise ValueError("two fits plus changed-weight reserve exceed original whole forward cap")
    return configs, plans


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    # Real input arrives here only after ordinary source adoption/conversion and
    # Root's actual source/data/resource guard. No payload is opened by --help.
    import numpy as np
    from quoridor_training.common import bound_file_bytes
    from quoridor_training.sampling import family_training_view
    from quoridor_training.terminal_cache import TerminalCorpus

    template = json.loads(Path(__file__).with_name("settings.SELECTED.json").read_bytes())
    corpus = TerminalCorpus(args.cache)
    primary = None
    try:
        m = template["M"]["mixture"]
        indices = family_training_view(
            corpus.groups,
            corpus.splits,
            corpus.eligible,
            m["train_family_row_cap"],
            games=corpus.row_game_codes,
            stock=corpus.maps[0]["geometry"]["stocks"].sum(axis=1),
            strata=m["train_stock_strata"],
        )
        validation_rows = int(np.count_nonzero(corpus.eligible & (corpus.splits == 1)))
        public = json.loads(bound_file_bytes(m["public_membership"], 1024**2))
        counts = {
            p["name"]: p["rows"]
            for p in public["partitions"]
            if p["name"] in ("train", "validation")
        }
        configs, plans = resolved_pair(template, len(indices), validation_rows, counts)
        args.output.mkdir(exist_ok=False)
        for arm, cfg in configs.items():
            (args.output / ("fit-" + arm + ".json")).write_text(json.dumps(cfg, indent=2) + "\n")
        manifest = args.cache / "cache.json"
        summary = {
            "actual_cache_manifest": str(manifest.resolve()),
            "cache_manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(),
            "actual_newT_R": len(indices),
            "actual_newV": validation_rows,
            "updates": plans["C"]["updates"],
            "selector_steps": plans["C"]["selector_steps"],
            "C_forward_upper": plans["C"]["forward_upper"],
            "M_forward_upper_with_shared_INITIAL": plans["M"]["forward_upper"],
            "changed_weight_forward_reserve": template["changed_weight_forward_reserve"],
            "M_requires_actual_input_binding_files_initial_observation": True,
            "whole_bulk_B": template["whole_bulk_B"],
            "science_launched": False,
        }
        (args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "output": str(args.output),
                    "R": len(indices),
                    "U": plans["C"]["updates"],
                }
            )
        )
    except BaseException as error:
        primary = error
        raise
    finally:
        try:
            corpus.verify_binding()
        except BaseException as error:
            if primary is not None:
                raise BaseExceptionGroup(
                    "config preparation and cache identity failed", [primary, error]
                ) from None
            raise


if __name__ == "__main__":
    main()
