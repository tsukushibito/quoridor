"""Freeze only the two changed owners and the new test, with strict patch recovery."""

import ast
from copy import deepcopy
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import tempfile

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": format(stat.S_IMODE(path.stat().st_mode), "04o"),
    }


def without_owner(data, name):
    lines = data.decode().splitlines(True)
    tree = ast.parse(data)
    owner = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return "".join(lines[: owner.lineno - 1] + lines[owner.end_lineno :]), owner


patches = []
results = {}
before_refs = json.loads((OWN / "before-refs.json").read_text())
for name, owner_name in (("common", "common_cache_config"), ("public_replay", "admit")):
    target = "python/quoridor_training/" + name + ".py"
    before = gzip.decompress((OWN / (name + ".before.py.gz")).read_bytes())
    after = (OWN / (name + ".py")).read_bytes()
    a, old_node = without_owner(before, owner_name)
    b, _ = without_owner(after, owner_name)
    assert a == b, "outside-owner bytes changed: " + target
    old_tree, new_tree = ast.parse(before), ast.parse(after)
    new_tree.body = [
        deepcopy(old_node) if isinstance(n, ast.FunctionDef) and n.name == owner_name else n
        for n in new_tree.body
    ]
    assert ast.dump(old_tree) == ast.dump(new_tree), "outside-owner AST changed"
    assert ref(ROOT / target) == before_refs[str(ROOT / target)], "current Main drift"
    patches.extend(
        difflib.unified_diff(
            before.decode().splitlines(True),
            after.decode().splitlines(True),
            fromfile="a/" + target,
            tofile="b/" + target,
        )
    )
    results[target] = {
        "before": before_refs[str(ROOT / target)],
        "after": ref(OWN / (name + ".py")),
        "changed_owner": owner_name,
        "outside_owner_bytes_exact": True,
        "outside_owner_AST_exact": True,
        "current_Main_matches_before": True,
    }

test_target = "python/quoridor_training/test_cache_scale_binding.py"
assert not (ROOT / test_target).exists(), "new-test path already exists"
patches.extend(
    difflib.unified_diff(
        [],
        (OWN / "test_cache_scale_binding.py").read_text().splitlines(True),
        fromfile="/dev/null",
        tofile="b/" + test_target,
    )
)
patch_data = "".join(patches).encode()
(OWN / "source.patch").write_bytes(patch_data)
with tempfile.TemporaryDirectory(prefix="strict-recovery-", dir=OWN) as directory:
    stage = Path(directory)
    for name in ("common", "public_replay"):
        path = stage / "python/quoridor_training" / (name + ".py")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(gzip.decompress((OWN / (name + ".before.py.gz")).read_bytes()))
    capture = []
    for inverse in (False, True):
        argv = ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(OWN / "source.patch")]
        if inverse:
            argv.append("-R")
        result = subprocess.run(argv, cwd=stage, capture_output=True, text=True, check=True)
        capture.append(
            {
                "argv": argv,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.returncode,
            }
        )
        for name in ("common", "public_replay"):
            actual = (stage / "python/quoridor_training" / (name + ".py")).read_bytes()
            expected = (
                gzip.decompress((OWN / (name + ".before.py.gz")).read_bytes())
                if inverse
                else (OWN / (name + ".py")).read_bytes()
            )
            assert actual == expected
        if inverse:
            assert not (stage / test_target).exists()
        else:
            assert (stage / test_target).read_bytes() == (
                OWN / "test_cache_scale_binding.py"
            ).read_bytes()

binding = json.loads((OWN / "C.input-binding.json").read_text())
selected = json.loads((OWN.parent / "settings.SELECTED.json").read_text())
warm = selected["C"]["experiment"]["warm_start"]
assert binding["files"]["weights"] == warm["weights"]
assert binding["files"]["descriptor"] == warm["descriptor"]
assert binding["model_scale_authority"] == {
    "starting_weights_sha256": warm["weights"]["sha256"],
    "descriptor_sha256": warm["descriptor"]["sha256"],
    "evaluator_sha256": warm["evaluator_sha256"],
    "scale_policy": "incumbent_descriptor_T_only",
}
assert binding["cache_manifest_sha256"] == binding["files"]["cache_manifest"]["sha256"]
(OWN / "static-proof.json").write_text(
    json.dumps(
        {
            "owners": results,
            "new_test_target": test_target,
            "new_test_absent_in_Main": True,
            "new_test": ref(OWN / "test_cache_scale_binding.py"),
            "strict_forward_inverse": capture,
            "temporary_recovery_removed": True,
            "C_binding_matches_original_warmstart_metadata": True,
            "cache_model_payload_read_or_rehashed": False,
        },
        indent=2,
    )
    + "\n"
)
print("strict zero-fuzz forward/inverse + outside-owner BYTE/AST + C binding metadata: PASS")
