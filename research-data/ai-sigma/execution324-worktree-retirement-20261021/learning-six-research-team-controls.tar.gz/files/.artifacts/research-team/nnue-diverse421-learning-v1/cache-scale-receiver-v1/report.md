# 421.2 cache / scale receiver

公開済みのdata-only compact cacheを変更せず、データ読取とfitのinitializer / scale検査を分離する、通常の受入口修復。旧9f14 / fcc9 / 180093f6と本packetは別の凍結対象である。

`common_cache_config`は`model_scale_authority`が存在する場合だけ従来の完全なfieldset、lower-case SHA、incumbent scale policyを検査する。存在しないことはデータ読取に限り許容する。source Content、global schedule / partition、outcome eligibility、batch union等の検査は変更しない。`terminal_cache`、7 binaries、cache.jsonに変更はない。

`public_replay.admit`は既存の`warmstart_model_inputs`を必ず実行する。fitにはcache内のauthority、または既存`--input-binding`の`model_scale_authority`が必要で、実際のwarmstart descriptor / weights / evaluatorおよびincumbent T-only scaleと完全一致させる。両方あれば両方一致を要求する。外部authorityでは明示`cache_manifest_sha256`と、`files.cache_manifest` / `files.descriptor` / `files.weights`の実FileRefを必要とする。全filesを既存`bound_file_bytes`で検査し、cache path/hash、model FileRefの完全一致も要求する。欠落、malformed、別model、conflict、異なるcacheへの束縛は拒否する。

## 通常callerでの接続

`C.input-binding.json`はRootが報告した実cache76ddaff5と、元の設定に束縛された実BEST43 tupleを参照する。モデルpayloadやcacheを作者が再読・再hashして資格を再認定したものではない。新しいauthority証明書やfit許可ではなく、通常input-bindingの引数である。

RootのC Experiment.inputsにはこのbinding自身のFileRef、binding.filesの全FileRefs、実cache seven binaries、current configured model / public membership / caller / library等の通常inputsを含める。既存guardianのbefore/after custodyを維持する。argvは従来のnormal trainに`--input-binding ABS_C_BINDING`を付ける。R/U/configsは修復採用後に既存prepare-configs.pyが実TerminalCorpusから得る。作者側では2822から推測して作成しない。

Mは実C STOP / finalize / cleanup後、同じauthorityと同じcache / descriptor / weightsを持つbindingに、実Cの`initial-observation.json`のFileRefを`files.initial_observation`として追加する。M binding自身とこの実観測をMのordered Experiment.inputsに含める。将来のINITIAL FileRefは本packetに作らない。既存のobservation-binding全一致検査および`reuse_initial=True`によるstep0 forward=0を維持する。Cの模型をM initializerにせず、両方とも元BEST43 fresh Adamである。

## 影響するsoftware境界

新しい4個のstdlib / fake NN0定義のみを対象にする。1) data-only読取とpresent authority検査、2) 必須fit authorityと正しいcache / external tuple、3) missing / malformed / drift / unbound / conflicting refs、4) 同じexternal authorityを保った実binding経路のINITIAL FileRef検査と既存planのstep0再測定0。モデルvalidator自体はsynthetic return hookで既資格を仮定する。stream completionもtoy hookで、実codec / model / corpus資格の再証明ではない。real Torch / NumPy / model / weights / public rows / fit / native / Searchは0。

productionで変える所有関数は`common_cache_config`と`admit`だけ。train_mixture、shared INITIAL identity比較、optimizer/LAST UNKNOWN、forward計数、loss、model math、export、codecおよびterminal_cacheは一切変更しない。新testの提案先は`python/quoridor_training/test_cache_scale_binding.py`。

検証receipt、strict forward/inverse、minimum before gzip、outside-owner BYTE/AST証明、実STOPは同packetのresult-bindingから参照する。runtime corpus interop / actual R/U / fit / nativeはRootの未実行段階として残す。科学追加、converter replay、cache編集、旧成功suite再演は行わない。
