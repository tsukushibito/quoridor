"""Check frozen one-pass inlet and input metadata; no target execution."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-data-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
refs = {}
started = time.monotonic()


# Own static readers, copied from the completed receiver checker.
def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 4095:04o}",
    )
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def body(raw, token):
    at = raw.index(token.encode())
    start = raw.rfind(b"\n", 0, at) + 1
    indent = raw[start:at].replace(b"pub(crate) ", b"").replace(b"pub ", b"")
    assert not indent.strip()
    end = raw.index(b"\n" + indent + b"}", at) + len(indent) + 2
    return raw[at:end]


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            i = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if i not in ids:
                ids.append(i)
        for child in v.values():
            find_ids(child)
    elif isinstance(v, list):
        for child in v:
            find_ids(child)


entry = now()
target = dict(
    path=str(BASE / "completion-v2.json"),
    sha256="c4df42ddeb21d39f34724fa310cbc536e362aee4fc58fb6a86b8f65fd2c32f9c",
    bytes=5816,
    mode="0644",
)
completion = json.loads(read(target))
binding_ref = next(v for v in completion["source_packets"] if "/old-q-source-v3/" in v["path"])
binding = json.loads(read(binding_ref))
forward, inverse = read(binding["forward"]), read(binding["inverse"])
proof = json.loads(read(binding["proof"]))
stop_raw = read(completion["STOP"])
draft_ref = next(v for v in completion["drafts"] if v["path"].endswith("old-q-native-draft.json"))
draft = json.loads(read(draft_ref))
inputs = json.loads(read(draft["fixed_inputs"]))
cfg = draft["config_draft"]
assert cfg["games"] == len(cfg["openings"]) == len(inputs["states"]) == len(draft["mapping"]) == 28
assert cfg["simulations"] == 64 and cfg["benchmark_repetitions"] == 1
assert cfg["inference"]["logical_row_limit"] == 10000
assert cfg["engines"] == [{"kind": "mcts"}]
assert cfg["common_study"] is None and cfg["temperature"] == 0
assert cfg["opening_plies"] == 0
for i, (prefix, source, mapping) in enumerate(
    zip(cfg["openings"], inputs["states"], draft["mapping"], strict=True)
):
    assert prefix == source["full_prefix_actions"]
    assert len(prefix) == source["ply"]
    assert mapping["request_id"] == i and mapping["state_id"] == source["state_id"]
    assert mapping["full_prefix_SHA256"] == source["prefix_actions_sha256"]
    assert mapping["source_position_record"] == source["source_position_record"]
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
fw, rv = scope["split_patch"](forward), scope["split_patch"](inverse)
assert set(fw) == set(rv) == {v["subject"] for v in binding["subjects"]}
sources = {}
hunks = 0
for row in binding["subjects"]:
    old = gzip.decompress(read(row["recovery"]))
    post = read(row["post"])
    assert hashlib.sha256(old).hexdigest() == row["before_sha256"]
    assert len(old) == row["before_bytes"]
    rebuilt, n = scope["apply"](old, fw[row["subject"]])
    restored, m = scope["apply"](post, rv[row["subject"]])
    assert rebuilt == post and restored == old and n == m
    hunks += n
    sources[row["subject"]] = (old, post)
preserved = []
for item in proof["protected_top_level_functions"]:
    old, post = sources[item["subject"]]
    token = "fn " + item["function"] + "("
    assert body(old, token) == body(post, token)
    preserved.append(dict(subject=item["subject"], function=item["function"], exact=True))
runtime = sources["crates/quoridor-runner/src/runtime.rs"][1]
bench = body(runtime, "fn benchmark_impl(")
assert bench.index(b"config.bounded_mcts() && provided.is_some()") < bench.index(
    b"config.validate()"
)
assert b"config.benchmark_repetitions.unwrap_or(4)" in bench
assert b"s.root_visits != config.simulations" in bench
assert b'"warm":repeat==0 && config.benchmark_repetitions.is_none()' in bench
assert bench.count(b"make_backend(config)?") == 1
assert bench.index(b"make_backend(config)?") < bench.index(b"for (fixture, p)")
assert bench.count(b".infer(") == 1
assert bench.count(b"admit_mcts_rows(") == 2
assert bench.index(b"admit_mcts_rows(") < bench.index(b".infer(")
assert bench.rindex(b"admit_mcts_rows(") > bench.index(b".infer(")
assert b'"root_mean_bits":(s.root_mean as f32).to_bits()' in bench
assert b'"prefix":p.opening' in bench and b'"side":context.position().turn' in bench
assert b'"backend_work":backend.as_ref().map(|b| inference_work(b.counters()))' in bench
config = sources["crates/quoridor-runner/src/config.rs"][1]
assert b"self.games != self.openings.len()" in config
assert b"repetitions != 1" in config
ids = []
find_ids(json.loads(stop_raw))
fresh = []
for identity in ids:
    assert not Path(f"/proc/{identity['pid']}").exists(), identity
    fresh.append(dict(identity=identity, fresh_pid_absent=True))
before = list(refs.values())
for ref in before:
    read(ref)
stop = now()
out = dict(
    target=target,
    binding=binding_ref,
    before=before,
    after=list(refs.values()),
    source_reader_START=entry,
    source_reader_STOP=stop,
    strict_hunks=hunks,
    preserved=preserved,
    source_clear=True,
    blockers=0,
    ordinary=0,
    fixed_inputs=dict(
        count=28, complete_prefix_metadata=True, simulations=64, inclusive_row_limit=10000
    ),
    actual_canonical_replay_model_library_current_image_and_cross_operation_remainder="NOT_RUN; Root actual entry obligations",
    target_functions_tests_native_geometry_Search_models_payload_executions=0,
    fresh_known_IDs=fresh,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="Finite foreground static helper, no subprocess; detailed plain-tool identity/handles UNKNOWN",
    source_Main_Git_index_writes=0,
    futurequiet=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            reader_STOP=stop,
            refs=len(refs),
            hunks=hunks,
            preserved=len(preserved),
            seconds=out["static_seconds"],
        )
    )
)
