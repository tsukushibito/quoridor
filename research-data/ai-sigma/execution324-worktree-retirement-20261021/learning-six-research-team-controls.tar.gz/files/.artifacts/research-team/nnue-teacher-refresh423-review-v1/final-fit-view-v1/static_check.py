"""Final fit sampling view source checks, no producer code or geometry execution."""

import ast
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-data-v1/final-fit-view-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    expected = {k: ref[k] for k in actual}
    if expected["mode"].startswith("0o"):
        expected["mode"] = f"{int(expected['mode'], 8):04o}"
    assert actual == expected
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def fn(raw, token):
    at = raw.index(token.encode())
    start = raw.rfind(b"\n", 0, at) + 1
    indent = raw[start:at].replace(b"pub(crate) ", b"").replace(b"pub ", b"")
    assert not indent.strip()
    end = raw.index(b"\n" + indent + b"}", at) + len(indent) + 2
    return raw[at:end]


def result_body(raw):
    marker = b") -> Result<()> {"
    return raw[raw.index(marker) + len(marker) :]


entry = now()
target = dict(
    path=str(BASE / "completion.json"),
    sha256="61ad6e4d7e2ad68df1c0ac755582e1ef880bd14c261ce58b69df4789e026539e",
    bytes=4337,
    mode="0644",
)
c = json.loads(read(target))
b = json.loads(read(c["source_binding"]))
recovery = next(r for r in b["refs"] if r["path"].endswith("/before/terminal_cache.rs.gz"))
old = gzip.decompress(read(recovery))
assert hashlib.sha256(old).hexdigest() == b["before"]["sha256"]
assert len(old) == b["before"]["bytes"]
post = read(c["post"])
current_main_post = {**c["post"], "path": b["before"]["path"]}
assert read(current_main_post) == post
forward, inverse = read(c["forward"]), read(c["inverse"])
read(c["report"])
stop_raw = read(c["source_STOP"])
plan = json.loads(read(c["verification_plan"]))
view = json.loads(read(c["final_view"]))
fragment = json.loads(read(c["input_binding_fragment"]))
assert fragment == {"final_fit_view": {k: c["final_view"][k] for k in ["path", "sha256"]}}
assert view["batch_start"] == 0 and view["batch_count"] == view["families"] == 256
assert view["root_value_policy"] == "outcome_only"
correspondence = json.loads(read(c["correspondence"]))
assert correspondence["slots"] == 256 and correspondence["sources"] == 32
assert [x["global_id"] for x in correspondence["changed"]] == [18]
assert correspondence["original_source_splits"] == {"train": 203, "validation": 53}
assert correspondence["final_view_splits"] == {"train": 204, "validation": 52}
protected_ref = next(r for r in b["refs"] if r["path"].endswith("/protected-proof.json"))
read(protected_ref)
dependencies = {}
for name in ["common_corpus.rs", "terminal_stream.rs"]:
    path = Path("/workspaces/quoridor/crates/quoridor-data/src") / name
    raw = path.read_bytes()
    ref = dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )
    dependencies[name] = read(ref)
canonical = fn(dependencies["common_corpus.rs"], "fn validate_inputs(")
assert b"self.validate_shape()?;" in canonical
assert b"crate::terminal::partition_families(&planned, self.split_seed)?" in canonical
assert b"serde_json::to_value(&actual)? != serde_json::to_value(&expected)?" in canonical
reader = fn(dependencies["terminal_stream.rs"], "fn read(&self)")
assert b"hex_digest(&raw) != self.sha256" in reader
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
fw, rv = scope["split_patch"](forward), scope["split_patch"](inverse)
name = "crates/quoridor-data/src/terminal_cache.rs"
assert set(fw) == set(rv) == {name}
rebuilt, hunks = scope["apply"](old, fw[name])
restored, count = scope["apply"](post, rv[name])
assert rebuilt == post and restored == old and hunks == count
for token in ["fn finish(", "fn raw(&self", "fn mcts_game_id(", "fn write(dataset:"]:
    assert fn(old, token) == fn(post, token)
old_sampling = fn(old, "fn sampling_code(")
sampling = fn(post, "fn sampling_code(")
sampling = sampling.replace(b"r: &TeacherRow, split: &crate::Split", b"r: &TeacherRow")
sampling = sampling.replace(
    b"            || !matches!(split, crate::Split::Train | crate::Split::Validation)\n", b""
)
sampling = sampling.replace(b"if &f.split != split", b"if f.split != r.split")
sampling = sampling.replace(b"split: split.clone()", b"split: r.split.clone()")
assert sampling == old_sampling
old_push = result_body(fn(old, "fn push("))
new_push = result_body(fn(post, "fn push_with_sampling_split("))
new_push = new_push.replace(b"\n        let split = sampling_split.unwrap_or(&r.split);", b"")
new_push = new_push.replace(b"self.sampling_code(r, split)?", b"self.sampling_code(r)?")
new_push = new_push.replace(
    b"*split == crate::Split::Validation", b"r.split == crate::Split::Validation"
)
new_push = new_push.replace(b"*split == crate::Split::Train", b"r.split == crate::Split::Train")
assert new_push == old_push
assert (
    result_body(fn(post, "fn push(")).strip()
    == b"self.push_with_sampling_split(r, evidence, None)\n    }"
)
old_merge = fn(old, "if let Some(total) = &mut combined")
new_merge = fn(post, "if let Some(total) = &mut combined")


def normalize(raw):
    return re.sub(rb"\s+", b"", re.sub(rb",\s*\)", b")", raw))


assert normalize(old_merge) == normalize(new_merge)
write = fn(post, "fn write_common_mcts(")
assert (
    write.index(b"common.validate_inputs()?;")
    < write.index(b"view.append_source(")
    < write.index(b"terminal_stream::publish_common_cache(")
)
assert (
    write.index(b"row.validate()?;")
    < write.index(b"row.split != assignment.split")
    < write.index(b"assignment.check_source_row(row)?;")
    < write.index(b"writer.push_with_sampling_split(")
)
assert write.index(b"view.reference.read()?;") < write.index(b'"final_fit_view".into()')
assert b"original.schedule.read()?;" in write and b"original.partition.read()?;" in write
assert b"if fit_view.is_some() && realized != common.batch_range()?.end" in write
old_tests = re.findall(rb"#\[test\]\s+fn (\w+)", old)
new_tests = re.findall(rb"#\[test\]\s+fn (\w+)", post)
added = [x.decode() for x in new_tests if x not in old_tests]
assert added == plan["new_definitions"] and len(added) == 4
for name in old_tests:
    token = "fn " + name.decode() + "("
    assert fn(old, token) == fn(post, token)
before = list(refs.values())
for ref in before:
    read(ref)
stop = now()
pid = os.getpid()
identity = dict(
    pid=pid,
    start_ticks=Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[19],
    boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
)
out = dict(
    target=target,
    source_binding=c["source_binding"],
    before=before,
    after=list(refs.values()),
    source_reader_START=entry,
    source_reader_STOP=stop,
    source_clear=True,
    historical_before=b["before"],
    before_reconstructed_from_immutable_gzip=True,
    current_Main_is_fixed_post_not_historical_before=True,
    blockers=0,
    ordinary=0,
    strict_forward_inverse_hunks=hunks,
    protected_original_labels_geometry_finish_raw_Alpha=True,
    no_view_merge_static_normalized_equal=True,
    old_test_bodies_exact=True,
    new_tests=added,
    supplied_metadata=correspondence,
    row_codec_counts_distinctness="UNKNOWN; no row/native conversion read or execution",
    Python_final_fit_view_consumer="Separate pending Root owner; not cleared",
    static_seconds=time.monotonic() - started,
    self_identity=identity,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="Foreground bounded stdlib static helper, no subprocess; tool-level handles/reap details UNKNOWN",
    target_imports_functions_tests_models_RAW_native_geometry_library_Search_executions=0,
    source_Main_Git_index_writes=0,
    futurequiet=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            reader_STOP=stop,
            refs=len(refs),
            hunks=hunks,
            identity=identity,
            seconds=out["static_seconds"],
        )
    )
)
