"""Bounded saved JSON/CSV arithmetic and joins only. No target code or resampling."""

import ast
from collections import Counter
import csv
import datetime
import hashlib
import io
import json
import math
import os
from pathlib import Path
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/final-analysis-v1/final-saved-v1"
)
ROOT = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-teacher-refresh423-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
T0 = time.monotonic()
START = datetime.datetime.now(datetime.timezone.utc).isoformat()
REFS = {}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read(ref):
    p = Path(ref["path"])
    i = p.lstat()
    assert not p.is_symlink() and i.st_size == ref["bytes"] <= 1048576
    with p.open("rb") as stream:
        b = stream.read(ref["bytes"] + 1)
    actual = dict(path=str(p), sha256=sha(b), bytes=len(b), mode=f"{i.st_mode & 4095:04o}")
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    REFS[str(p)] = actual
    return b


def witness(p):
    p = Path(p)
    i = p.lstat()
    assert i.st_size <= 1048576
    with p.open("rb") as stream:
        b = stream.read(1048577)
    ref = dict(path=str(p), sha256=sha(b), bytes=len(b), mode=f"{i.st_mode & 4095:04o}")
    return read(ref)


def parsed(ref):
    return json.loads(read(ref))


def near(a, b):
    assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12), (a, b)


root_ref = dict(
    path=str(BASE / "completion.json"),
    sha256="b0034c658737d640088c6cd2f65bd2114269af0a3412ffa22b1fc7e842b0d5e2",
    bytes=10940,
    mode="0644",
)
completion = parsed(root_ref)
refs = {Path(r["path"]).name: r for r in completion["artifacts"]}
needed = [
    "report-ja.md",
    "result.json",
    "checks.json",
    "control.json",
    "primary-global-family-interval.json",
    "families.csv",
    "games.csv",
    "curves.csv",
    "family-MSE-changes.json",
    "candidate-example.json",
    "future-plan-arithmetic.json",
    "finalize_saved_analysis.py",
    "STOP.json",
    "selectedrefs-final.json",
    "private-working-extract-minimization.json",
]
data = {n: read(refs[n]) for n in needed}
result = json.loads(data["result.json"])
interval = json.loads(data["primary-global-family-interval.json"])
collection = json.loads(witness(ROOT / "science-v1/arena160-entry-v4/collection.json"))
table = parsed(collection["family_table"])["rows"]
assert len(table) == 80
settings = parsed(collection["settings"])
plans = [parsed(settings["runs"][i]["approved_plan"]) for i in [0, 4]]
schedules = [parsed(p["schedule"]) for p in plans]
book = parsed(plans[0]["book"])
assert plans[0]["book"] == plans[1]["book"]
assert book["complete"] is True and len(book["families"]) == 64
families = list(csv.DictReader(io.StringIO(data["families.csv"].decode())))
games = list(csv.DictReader(io.StringIO(data["games.csv"].decode())))
assert len(families) == 80 and len(games) == 160
families_by = {(r["contrast"], int(r["family_id"])): r for r in families}
assert len(families_by) == 80
by_slot = {(r["contrast"], int(r["global_slot"])): r for r in games}
assert len(by_slot) == 160
join_fields = [
    "contrast",
    "operation_index",
    "global_slot",
    "local_game",
    "family_id",
    "lineage",
    "source_prefix",
    "native_family",
    "candidate_color",
    "started",
    "status",
    "failure",
    "score",
]
primary_scores = []
checks = {}
for contrast, n, p, schedule in zip(["W/BEST43", "W/D"], [64, 16], plans, schedules):
    rows = sorted([r for r in table if r["contrast"] == contrast], key=lambda r: r["family_id"])
    assert [r["family_id"] for r in rows] == list(range(n))
    assert len(schedule) == 2 * n and p["planned_slots"] == 2 * n
    schedule_by = {r["slot"]: r for r in schedule}
    seen_lineage = set()
    seen_prefix = set()
    scores = []
    flat = []
    for family in rows:
        fid = family["family_id"]
        bf = book["families"][fid]
        assert (
            bf["family_id"] == fid
            and family["source_prefix"] == bf["prefix"]
            and family["lineage"] == "423-evaluation:" + bf["id"]
        )
        seen_lineage.add(family["lineage"])
        seen_prefix.add(tuple(family["source_prefix"]))
        assert len(family["games"]) == 2 and {g["candidate_color"] for g in family["games"]} == {
            0,
            1,
        }
        for g in family["games"]:
            slot = schedule_by[g["global_slot"]]
            assert (
                slot["family_id"] == fid
                and slot["local_game"] == g["local_game"]
                and slot["candidate_color"] == g["candidate_color"]
            )
            assert slot["batch"] == (g["operation_index"] if contrast == "W/BEST43" else 0)
            assert (
                g["source_prefix"] == family["source_prefix"] and g["lineage"] == family["lineage"]
            )
            saved = by_slot[(contrast, g["global_slot"])]
            for k in join_fields:
                expected = g[k]
                actual = saved[k]
                if k == "source_prefix":
                    assert json.loads(actual) == expected
                elif k == "started":
                    assert (actual == "True") is expected
                elif k in [
                    "operation_index",
                    "global_slot",
                    "local_game",
                    "family_id",
                    "candidate_color",
                ]:
                    assert int(actual) == expected
                elif k == "score":
                    assert (None if actual == "" else float(actual)) == expected
                else:
                    assert actual == expected
            flat.append(g)
        complete = all(g["score"] is not None for g in family["games"])
        assert family["complete"] == complete
        saved = families_by[(contrast, fid)]
        assert (
            (saved["complete"] == "True") == complete
            and json.loads(saved["source_prefix"]) == family["source_prefix"]
            and saved["lineage"] == family["lineage"]
        )
        if complete:
            score = sum(g["score"] for g in family["games"]) / 2
            assert score == family["score"] == float(saved["score"])
            scores.append(score)
    assert len(seen_lineage) == len(seen_prefix) == n
    wins = sum(g["score"] == 1 for g in flat)
    losses = sum(g["score"] == 0 for g in flat)
    unknown = sum(g["score"] is None for g in flat)
    a = result["arena"][contrast]
    assert (wins, losses, unknown, len(scores)) == (
        (72, 56, 0, 64) if contrast == "W/BEST43" else (17, 10, 5, 13)
    )
    near(sum(scores) / len(scores), a["complete_pair_mean"])
    near(wins / (wins + losses), a["valid_game_score"])
    assert a["planned_score_bounds"] == [wins / (2 * n), (wins + unknown) / (2 * n)]
    checks[contrast] = dict(
        families=n,
        complete=len(scores),
        wins=wins,
        losses=losses,
        unknown=unknown,
        started=sum(g["started"] for g in flat),
        pair_mean=sum(scores) / len(scores),
        valid_game_mean=wins / (wins + losses),
        planned_bounds=a["planned_score_bounds"],
    )
    if contrast == "W/BEST43":
        primary_scores = scores
        assert len({g["native_family"] for g in flat}) == 16
    else:
        assert {g["family_id"] for g in flat if g["score"] is None} == {13, 14, 15}
        assert sum(g["started"] for g in flat if g["score"] is None) == 1
assert (
    primary_scores == interval["scores"]
    and dict(Counter(map(str, primary_scores))) == interval["scores_histogram"]
)
assert sum(primary_scores) / 64 == interval["score_mean"] == 0.5625
assert (
    interval["seed"] == 42320261027
    and interval["resamples"] == 10000
    and interval["percentile_method"] == "linear"
    and interval["unit"] == "one complete two-colour global family score"
)
assert (
    interval["percentile_95"] == [0.4765625, 0.6484375]
    and interval["percentile_95"][0] <= 0.5 <= interval["percentile_95"][1]
)
# Read actual original five small game-summary CSVs, never compressed game RAW.
for op in collection["operations"]:
    csv_rows = list(csv.DictReader(io.StringIO(read(op["original_refs"]["games.csv"]).decode())))
    assert len(csv_rows) == 32
    index = op["operation_index"]
    contrast = "W/BEST43" if index < 4 else "W/D"
    for g in [
        g
        for f in table
        if f["contrast"] == contrast
        for g in f["games"]
        if g["operation_index"] == index
    ]:
        r = next(r for r in csv_rows if int(r["game"]) == g["local_game"])
        assert (
            r["family"] == g["native_family"]
            and int(r["candidate_color"]) == g["candidate_color"]
            and r["status"] == g["status"]
            and (r["started"] == "true") == g["started"]
        )
        if g["score"] is not None:
            assert g["score"] == float(int(r["winner"]) == g["candidate_color"])
charged = result["charged_node_budget"]
assert (
    sum(charged["operations"]) == 752662738 < 1000000000
    and 800000000 - sum(charged["operations"][:4])
    == charged["primary_unused_not_lent"]
    == 247337262
    and charged["operations"][4] == 200000000
)
outcome = result["arena_operational_outcome"]
assert (
    outcome["original_job"]["outcome"] == "failed"
    and outcome["last_operation_cleanup_complete"] is False
    and outcome["native_process_cleanup_complete"] is True
)
f = result["fits_and_old_q"]
fits = f["fits"]
assert fits["R"]["native_fit_status"] == "COMPLETE" and fits["R"]["operation_status"] == "FAILED"
curves = list(csv.DictReader(io.StringIO(data["curves.csv"].decode())))
changes = json.loads(data["family-MSE-changes.json"])
for name, fit in fits.items():
    c = [r for r in curves if r["condition"] == name]
    assert len(c) == 4
    best = min(c, key=lambda r: (float(r["newV_family_MSE"]), int(r["step"])))
    assert int(best["step"]) == fit["BEST_step"]
    rows = [r for r in changes if r["condition"] == name]
    assert len(rows) == 52 and sum(r["rows"] for r in rows) == 2498
    near(sum(r["initial_MSE"] for r in rows) / 52, fit["initial_newV"]["family_mse"])
    near(sum(r["BEST_MSE"] for r in rows) / 52, fit["BEST_newV"]["family_mse"])
assert fits["F"]["BEST_step"] == 0 and fits["F"]["LAST_step"] == 941
assert (
    fits["W"]["BEST_full_publicV"]["mse"] > fits["U"]["BEST_full_publicV"]["mse"]
    and fits["W"]["BEST_full_publicV"]["mse"] > fits["R"]["BEST_full_publicV"]["mse"]
)
forward = f["forward_accounting"]
assert (
    forward["training_rows"] + forward["measurement_rows"] + forward["changed_weights_native_heads"]
    == forward["NNUE_completed_total"]
    == 2210566
    < 4000000
)
assert (
    forward["Sigma_generation"] + forward["Sigma_oldq"]
    == forward["Sigma_total"]
    == 718195
    < 2000000
)
near(
    sum(result["known_original_outer_seconds_once"].values()),
    result["known_original_outer_subtotal_seconds"],
)
candidate = json.loads(data["candidate-example.json"])
assert (
    candidate["full_prefix"] == book["families"][0]["prefix"]
    and [r["action"] for r in candidate["records"]] == [138, 146]
    and [r["completed_depth"] for r in candidate["records"]] == [4, 4]
)
assert all(r["authority_receipt_ns"] < r["deadline_ns"] for r in candidate["records"])
addendum = json.loads(witness(BASE / "admin-format-refs-v1/receipt.json"))
assert (
    addendum["consumed_fields_equal_frozen_candidate_example"] is True
    and addendum["same_bytes"] is False
)
read(addendum["current_formatted_working_extract_FileRef"])
verification = json.loads(witness(ROOT / "final-acceptance-v1/selected-analysis-verification.json"))
assert verification["completion"] == root_ref
bootstrap_receipt = json.loads(witness(BASE / "one-original-global-primary-interval-receipt.json"))
assert (
    bootstrap_receipt["returncode"] == 0
    and bootstrap_receipt["directwait_reaped"]
    and bootstrap_receipt["handles_closed"]
)
# Inspect supplied source AST only: it loads the interval; it does not contain the resampling body.
source = ast.parse(data["finalize_saved_analysis.py"])
calls = [ast.unparse(n.func) for n in ast.walk(source) if isinstance(n, ast.Call)]
assert not any(x.endswith(("default_rng", "quantile", "choice")) for x in calls)
for ref in list(REFS.values()):
    read(ref)
STOP = datetime.datetime.now(datetime.timezone.utc).isoformat()
proof = dict(
    target=root_ref,
    selected_refs=len(REFS),
    refs_before_after=REFS,
    selected_unique_bytes=sum(r["bytes"] for r in REFS.values()),
    counts=checks,
    primary_histogram=interval["scores_histogram"],
    interval=interval["percentile_95"],
    bootstrap_not_rerun=True,
    bootstrap_body_not_in_declared_sources=True,
    logical_NNUE=forward["NNUE_completed_total"],
    logical_Sigma=forward["Sigma_total"],
    charged_nodes=752662738,
    known_original_outer_subtotal=result["known_original_outer_subtotal_seconds"],
    target_functions_executed=0,
    new_statistics_or_sampling=False,
    original_RAW_decodes=0,
    start=START,
    reader_STOP=STOP,
    own_identity=dict(
        pid=os.getpid(),
        start_ticks=Path(f"/proc/{os.getpid()}/stat").read_text().rsplit(")", 1)[1].split()[19],
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    ),
    helper_wall_s=time.monotonic() - T0,
    self_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    family_continuous_peak="UNKNOWN",
    owned_readers_children_jobs_handles_TMP_leases_remaining=[],
    leases_acquired=[],
)
(OWN / "saved-checks.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            k: proof[k]
            for k in [
                "selected_refs",
                "selected_unique_bytes",
                "counts",
                "reader_STOP",
                "own_identity",
                "helper_wall_s",
                "self_ru_maxrss_KiB",
            ]
        }
    )
)
