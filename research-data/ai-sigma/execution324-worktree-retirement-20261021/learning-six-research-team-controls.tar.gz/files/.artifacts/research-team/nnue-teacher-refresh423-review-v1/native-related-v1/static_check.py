"""R1/C1 delta only; static bytes and lexical callsites, no target execution."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-data-v1/native-repair-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    b = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return b


def body(raw, token):
    at = raw.index(token.encode())
    start = raw.rfind(b"\n", 0, at) + 1
    indent = raw[start:at].replace(b"pub(crate) ", b"").replace(b"pub ", b"")
    assert not indent.strip()
    end = raw.index(b"\n" + indent + b"}", at) + len(indent) + 2
    return raw[at:end]


entry = now()
target = dict(
    path=str(BASE / "completion.json"),
    sha256="7ae08ebbeeaae079ba858c931e82059c34ad60848b132d659ad3d1ae010cd8af",
    bytes=2507,
    mode="0644",
)
completion = json.loads(read(target))
contents = {
    k: read(v)
    for k, v in completion.items()
    if isinstance(v, dict) and {"path", "sha256", "bytes", "mode"} <= v.keys()
}
binding = json.loads(contents["binding"])
old = gzip.decompress(read(binding["recovery"]))
assert (
    hashlib.sha256(old).hexdigest() == binding["before"]["sha256"]
    and len(old) == binding["before"]["bytes"]
)
assert read(binding["before"]) == old
post = contents["post"]
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
subject = binding["subject"]
f = scope["split_patch"](contents["forward"])
r = scope["split_patch"](contents["inverse"])
assert set(f) == set(r) == {subject}
rebuilt, n = scope["apply"](old, f[subject])
restored, m = scope["apply"](post, r[subject])
assert rebuilt == post and restored == old and n == m
api = body(post, "pub fn run_with_backend(")
assert api.index(b"if config.common_study.is_some()") < api.index(
    b"run_owned(config, mode, Some(backend))"
)
assert b"return Err(" in api
for token in ["fn run_inner(", "fn run_owned(", "pub fn run(", "fn attach_primary_failure("]:
    assert body(old, token) == body(post, token)
record = body(post, "fn record(&mut self, mut o: Outcome")
run = body(post, "fn run_inner(")
assert b"let mut preserve_outcome_cause = false" in record
assert b"if !preserve_outcome_cause && let Some(reason)" in record
assert b"for o in &mut outcomes {\n                attach_primary_failure(o, reason);" in run
primary = body(post, "fn attach_primary_failure(")
assert b"Failure::Cancelled | crate::arena_clock::Failure::NotStarted" in primary
assert b"outcome.failure = Some(crate::arena_clock::failure_from_reason(reason))" in primary
test = post[post.index(b"mod common_mcts_admission_cause_tests {") :]
assert b"impl InferenceBackend for MustNotEnter" in test
assert b"fn counters(" not in test
inference = subprocess.run(
    ["git", "show", "c6ce3a8d:crates/quoridor-inference/src/lib.rs"],
    cwd="/workspaces/quoridor",
    capture_output=True,
    check=True,
    timeout=20,
).stdout
trait = body(inference, "pub trait InferenceBackend:")
assert b"fn counters(&self) -> InferenceCounters;" in trait
ids = []


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            ident = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if ident not in ids:
                ids.append(ident)
        for x in v.values():
            find_ids(x)
    elif isinstance(v, list):
        for x in v:
            find_ids(x)


find_ids(json.loads(contents["STOP"]))
fresh = []
for ident in ids:
    absent = not Path(f"/proc/{ident['pid']}").exists()
    assert absent, ident
    fresh.append(dict(identity=ident, fresh_pid_absent=absent))
before = list(refs.values())
for ref in before:
    read(ref)
stop = now()
proof = dict(
    target=target,
    binding=completion["binding"],
    before=before,
    after=list(refs.values()),
    source_reader_START=entry,
    source_reader_STOP=stop,
    strict_hunks=n,
    R1_resolved=True,
    C1_remaining_final_census=True,
    C2_new_fake_missing_required_counters=True,
    counters_trait_source=dict(
        git="c6ce3a8d",
        path="crates/quoridor-inference/src/lib.rs",
        sha256=hashlib.sha256(inference).hexdigest(),
        trait_SHA256=hashlib.sha256(trait).hexdigest(),
    ),
    source_clear=False,
    blockers=0,
    ordinary=2,
    new_tests="two UNBUILT/UNTYPED/UNRUN; no reviewer test/type/build",
    fresh_known_IDs=fresh,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="One immutable Git read returned/reaped; plain tool detailed process identity/handles UNKNOWN",
    target_executions=0,
    source_Main_Git_index_writes=0,
)
(OWN / "static-proof.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        {
            k: proof[k]
            for k in ["source_reader_STOP", "strict_hunks", "static_seconds", "self_VmHWM"]
        }
    )
)
