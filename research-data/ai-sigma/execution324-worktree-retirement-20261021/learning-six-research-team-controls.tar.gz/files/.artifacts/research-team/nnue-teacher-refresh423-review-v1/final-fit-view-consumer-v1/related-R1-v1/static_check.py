"""R1 source/AST/patch inspection only. Target bodies are never executed."""

import ast
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
TEAM = OWN.parents[2]
BASE = TEAM / "nnue-teacher-refresh423-learning-v1/final-fit-view-receiver-v1/related-R1-v1"
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
START = datetime.datetime.now(datetime.timezone.utc).isoformat()
T0 = time.monotonic()
REFS = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    info = p.stat()
    assert info.st_size == ref["bytes"] <= 1048576
    with p.open("rb") as stream:
        raw = stream.read(ref["bytes"] + 1)
    actual = dict(path=str(p), sha256=sha(raw), bytes=len(raw), mode=f"{info.st_mode & 4095:04o}")
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    REFS[str(p)] = actual
    return raw


def function(module, name):
    return next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == name)


def outside(raw, owner):
    lines = raw.splitlines(keepends=True)
    return b"".join(lines[: owner.lineno - 1] + lines[owner.end_lineno :])


result_ref = dict(
    path=str(BASE / "result-binding.json"),
    sha256="065d5dae3672ce46930b599329b687e4d29c9099a931c500edd3d565911dff82",
    bytes=1246,
    mode="0644",
)
result = json.loads(read(result_ref))
binding = json.loads(read(result["source"]))
for container in [result, binding]:
    for ref in container.values():
        if isinstance(ref, dict) and "path" in ref:
            read(ref)
before = gzip.decompress(read(binding["before_gzip"]))
assert (
    sha(before) == binding["base_source"]["sha256"]
    and len(before) == binding["base_source"]["bytes"]
)
assert before == read(binding["base_source"])
post = read(binding["post"])
old_ast, new_ast = ast.parse(before), ast.parse(post)
old_fn, new_fn = function(old_ast, "common_cache_config"), function(new_ast, "common_cache_config")
assert outside(before, old_fn) == outside(post, new_fn)
old_tail, new_tail = old_fn.body[-2], new_fn.body[-2]
assert isinstance(old_tail, ast.If) and isinstance(new_tail, ast.If)
assert ast.dump(old_tail.test) == ast.dump(new_tail.test)
helper = function(new_tail, "read_metadata_bytes")
reader = function(new_tail, "read_metadata")
helper_text = ast.unparse(helper)
assert all(
    flag in helper_text
    for flag in ["os.O_RDONLY", "os.O_CLOEXEC", "os.O_NOFOLLOW", "os.O_NONBLOCK"]
)
assert "os.read(descriptor, min(remaining, 65536))" in helper_text
assert "chunks, remaining = ([], info.st_size)" in helper_text
assert "remaining -= len(block)" in helper_text
assert "len(raw) != info.st_size" in helper_text
assert "hashlib.sha256(raw).hexdigest() != sha" in helper_text
assert "metadata_identity(os.fstat(descriptor))" in helper_text
assert "metadata_identity(path.lstat())" in helper_text
assert "0 < info.st_size <= capacity" in helper_text
assert any(
    isinstance(n, ast.Try)
    and len(n.finalbody) == 1
    and ast.unparse(n.finalbody[0]) == "os.close(descriptor)"
    for n in helper.body
)
reader_text = ast.unparse(reader)
assert "min(limit, 16777216 - metadata_bytes)" in reader_text
assert "metadata_bytes += len(raw)" in reader_text
assert "0 < info.st_size <= limit" in reader_text
assert "min(previous_limit, limit)" in reader_text
final_loop = new_tail.body[-1]
assert isinstance(final_loop, ast.For)
assert (
    ast.unparse(final_loop.body[0])
    == "read_metadata_bytes(Path(path), info, min(info.st_size, limit), sha)"
)
assert not any(isinstance(n, ast.Attribute) and n.attr == "read_bytes" for n in ast.walk(new_fn))
# Restore only the new helper, local reader and final recheck; every other AST stays exact.
new_tail.body.remove(helper)
new_tail.body[new_tail.body.index(reader)] = function(old_tail, "read_metadata")
new_tail.body[-1] = old_tail.body[-1]
assert ast.dump(new_ast) == ast.dump(old_ast)
# Our earlier strict patch utility only. No target code is compiled or executed.
utility_path = TEAM / "sigma-alpha420-review-v1/static_check.py"
utility_ast = ast.parse(utility_path.read_bytes())
utility = {"re": re}
exec(
    compile(
        ast.Module(
            body=[
                n
                for n in utility_ast.body
                if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
            ],
            type_ignores=[],
        ),
        str(utility_path),
        "exec",
    ),
    utility,
)
parts = utility["split_patch"](read(binding["forward"]))
old_new = {
    "python/quoridor_training/common.py": (before, post),
    "python/quoridor_training/test_final_fit_view_reads.py": (b"", read(binding["new_test"])),
}
hunks = 0
for name, (old, new) in old_new.items():
    actual, count = utility["apply"](old, parts[name])
    inverse, reverse_count = utility["apply"](new, parts[name], True)
    assert actual == new and inverse == old and count == reverse_count
    hunks += count
lines = read(binding["inverse"]).splitlines(keepends=True)
heads = [i for i, line in enumerate(lines) if line.startswith(b"--- ")] + [len(lines)]
for a, b in zip(heads, heads[1:]):
    name = lines[a][6:].strip().decode()
    old, new = old_new[name]
    actual, _ = utility["apply"](new, b"".join(lines[a:b]))
    assert actual == old
new_test_ast = ast.parse(read(binding["new_test"]))
test_names = [
    n.name
    for n in ast.walk(new_test_ast)
    if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")
]
assert len(test_names) == 3
current_path = Path("/workspaces/quoridor/python/quoridor_training/common.py")
with current_path.open("rb") as stream:
    current = stream.read(1048577)
assert len(current) <= 1048576
current_ref = dict(
    path=str(current_path),
    sha256=sha(current),
    bytes=len(current),
    mode=f"{current_path.stat().st_mode & 4095:04o}",
)
assert sha(current) in {binding["base_source"]["sha256"], binding["post"]["sha256"]}
for ref in list(REFS.values()):
    read(ref)
STOP = datetime.datetime.now(datetime.timezone.utc).isoformat()
proof = dict(
    target=result_ref,
    binding=result["source"],
    refs_before_after=REFS,
    selected_refs=len(REFS),
    source_unique_bytes=sum(r["bytes"] for r in REFS.values()),
    strict_forward_inverse_hunks=hunks,
    explicit_inverse_exact=True,
    before_gzip_exact=True,
    outside_owner_bytes_exact=True,
    restored_only_reader_helper_and_final_loop_entire_AST_exact=True,
    original_test_sha256=binding["unchanged_old_test"]["sha256"],
    target_functions_executed=0,
    new_test_definitions_read_not_run=test_names,
    current_Main_dated_observation=current_ref,
    R1_static_resolution=dict(
        bounded_os_reads_max_65536=True,
        total_read_at_most_accepted_size=True,
        first_role_and_unique_remaining_capacity=True,
        every_cache_hit_role_limit=True,
        memoized_minimum_role_limit=True,
        final_accepted_size_min_role_no_unique_recharge=True,
        opened_regular_fstat_path_identity_before_after=True,
        exact_size_SHA_drift_refusal=True,
        finally_fd_close_attempt=True,
        no_unbounded_read_bytes_in_owner=True,
        atime_ignored=True,
    ),
    start=START,
    reader_STOP=STOP,
    own_identity=dict(
        pid=os.getpid(),
        start_ticks=Path(f"/proc/{os.getpid()}/stat").read_text().rsplit(")", 1)[1].split()[19],
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    ),
    helper_wall_s=time.monotonic() - T0,
    self_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    family_continuous_peak="UNKNOWN",
    owned_readers_children_jobs_handles_TMP_leases_remaining=[],
    leases_acquired=[],
)
(OWN / "static-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            k: proof[k]
            for k in [
                "selected_refs",
                "strict_forward_inverse_hunks",
                "reader_STOP",
                "own_identity",
                "helper_wall_s",
                "self_ru_maxrss_KiB",
                "current_Main_dated_observation",
            ]
        }
    )
)
