# 423.4 native MCTS input/teacher boundary

**source_clear=false / blockers=1 / ordinary=1**。固定completion `78b3030e0ac746885e993d680ab45a9154dfb90f772017ab032d77604272553b` / binding `6fbbf255b76bbf12335f0cb2b6dae87a25fc4d56d108536d894ae5c032a9ed4d` を確認しました。config/runtimeの2 postimages、before gzip、immutable c6ce3a8dと15 hunkの正逆再構成が一致。14 selectedrefsはSHA/size/mode前後一致、12 protected bodiesはbyte不変です。Main dcafaa1の現在survey/採用はしていません。

## R1 — supplied backend が新one-CPU/CPU-ORT routeへ入れる

runtime.rs3533–3543のcommon_study admissionはconfigだけでworkerとpumpを同一CPUへ置きます。その後3650–3661でprovided backendを受け、照合はmodel_shaだけです。公開run_with_backend(4270)にもcommon mode除外はありません。したがって正しいcommon configと同じmodel SHA metadataを持つ別backendを渡すと、make_backendを通らず新routeへ到達します。

このquota前判定はcurrent CPU ORTの「次のn rows以外のwarm/retry/captureを隠さない」という実装前提です。別backendは同じSHAを宣言しながら異なるphysical work/thread/backendを使え、成功後counter検査だけでは既に発生した超過を防げません。悪いbackendや超過を実行した主張ではなく、source上の許容経路です。通常CLI runのNoneは本物factoryへ行くことを区別します。

最小修復はcommon_study時のsupplied backendを入力/backend admission前に拒否することです。同等に強い実backend所有を既存入口で保証しても構いません。non-commonのembedding APIやMCTS/mathは変えず、このmodeの拒否/no-infer定義だけを追加してください。新registry/frameworkは不要です。

## C1 — terminal付与の二次失敗が元Outcome causeを置換する

CompletionPublication::record(4138–4144)は付与失敗時にo.reason/o.failureを無条件にterminal_targetsへ置換します。stoppedの先行primaryはget_or_insertで残りますが、既存Outcome自身の取消/errorの事実は戻りません。

具体的なsource interleavingは、winning moveのcommit後、次のworker terminal判定前にguardがcancelを設定する場合です。workerはouter cancel(1818)をterminal判定(1863)より先に処理し、genuine terminal prefixのままUNKNOWN/cancelledをfinishします。既存TerminalProvenanceはtrue terminalでUnknownを拒否するため、付与失敗枝へ入れます。そこで元のper-outcome cancelled reason/failureが別理由になります。このraceを実行・観測したものではありません。

既知の元Outcome cause/cancel factsは保持し、terminal_targetsの個別失敗を既存publication_failuresへ別保存する修復を推奨します。元causeがない場合だけ新primaryを使い、UNKNOWN/rows ineligible、最初のstopped、追加失敗全部の可視性は維持してください。通常の成功や数学を変える必要はありません。

## その他の確認と限界

既存common_corpus::validate_inputsがSHA-bound schedule/partition、canonical genuine-prefix/reflection/extension/endpoint collision closureを独立再計算します。sliceのglobal ID/family/splitを使い、missing slotを補充しません。native reportのplannedは非欠測数で、元request全分母は束縛scheduleと一緒に扱う必要があります。fit前の最終combined partitionは追加familyでpilot splitが変わり得るため明示mappingが必要で、元RAWを書換えません。

configured simulationsとroot_visitsの一致はTeacherRow/state commitより前です。true-terminal-first・greedy選択・MCTS/PUCT/encoder・既存workerは不変。logical+warm、physicalをcheckedで別々に上限照合し、UNKNOWN/overflowは拒否、failedは内数です。通常CPU ORTの単一backendはgame間でresetせず、実counterを保存します。元backend Errを成功や0評価へ置き換えません。この確認はR1の未保証なsupplied backendへ拡張できません。

canonical TerminalProvenance/attach_terminal_targetsがgenuine GOAL/thirdとfull chronologyを照合し、side1/2のzSTMを付けます。q/root_mean/root_nn/visitsは変更しません。UNKNOWN/cap/errorを勝敗教師へ変えないことと、C1のerror attribution問題を分けています。converter/old-state inletは別未完成境界です。

formal contract8ee2、correctionc726、spec c919を確認しました。元32/four8/60kはpilotで、256requests/2M rowsは後の一回の実費・実件数による規模解決の上限です。pilotだけからfourfit/160gameへ自動接続しません。実prefix/image/software/parent admissionはRoot依存で、source確認から作成した資格ではありません。

Reader STOP **2026-10-16T01:58:28.485609+00:00**、known94 source/controller/child PIDは当該windowでfresh absent。owned readers/children/jobs/handles/TMP/leases/remaining=[]、canonical/hardware lease取得なし。最終stdlib helper0.281051252秒/self VmHWM19952kB、AS512MiB/CPU0。immutable Git5読取はdirect return/reap、plain tool詳細identity/handlesと連続family peakはUNKNOWN。01:53:34のCPU0/core0、guardian6/core3、MemAvailable15060940kBはdated factsだけです。

レビュー側extractorがpub visibilityを扱えなかった原失敗(exit1/tool0.820529201s)を保持し、通常修復後の最終static結果と区別しています。対象関数/import/tests/Rust/Cargo/native/backend/model/forward/Search/game/RAW/corpusは実行・読取0。作者の新5定義はUNBUILT/UNTYPED/UNRUNです。Main/source/Git/index write0。423.4はin_progress、421.4/420履歴と旧pause/model/seal/default/RAWFAILED費/UNKNOWNを保持します。
