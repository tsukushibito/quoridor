"""Two materialization consumers, source/AST only; never import target or tests."""

import ast
import copy
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-teacher-refresh423-v1/materialize-consumer-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def dump(node):
    return ast.dump(node, include_attributes=False)


def owners(raw):
    tree = ast.parse(raw)
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    names = {"cache_materialize_check", "collect_data"}
    lines = raw.splitlines(keepends=True)
    omitted = set()
    source = {}
    for name in names:
        node = functions[name]
        omitted.update(range(node.lineno - 1, node.end_lineno))
        source[name] = b"".join(lines[node.lineno - 1 : node.end_lineno])
    outside = b"".join(line for i, line in enumerate(lines) if i not in omitted)
    return tree, functions, source, outside


entry = now()
target = dict(
    path=str(BASE / "source-binding.json"),
    sha256="f606be29bf9191f553a5d9e02dfdbe7f89cac0f3eacf09718e12489aaf1596c0",
    bytes=3008,
    mode="0644",
)
binding = json.loads(read(target))
old = gzip.decompress(read(binding["before_gzip"]))
assert hashlib.sha256(old).hexdigest().startswith("5b30823f")
post = read(binding["publisher"])
tests = read(binding["test"])
formatted = gzip.decompress(read(binding["original_failed_helper_formatted_post"]))
saved_check = json.loads(read(binding["tests_reused_once"]))
assert saved_check["exit_code"] == 0 and "Ran 2 tests" in saved_check["stderr"]
patch_path = BASE / "forward.patch"
patch_raw = patch_path.read_bytes()
patch_ref = dict(
    path=str(patch_path),
    sha256="31b50121536d1e12e4796e3c524e589dc397fc61de6a901cccd6c8df8b49fae8",
    bytes=12994,
    mode="0644",
)
assert patch_raw == read(patch_ref)
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
parts = scope["split_patch"](patch_raw)
assert set(parts) == {"scripts/dev/research-lifecycle.py"}
rebuilt, hunks = scope["apply"](old, parts["scripts/dev/research-lifecycle.py"])
restored, reverse_hunks = scope["apply"](
    post, parts["scripts/dev/research-lifecycle.py"], reverse=True
)
assert rebuilt == post and restored == old and hunks == reverse_hunks
ot, of, ob, oo = owners(old)
nt, nf, nb, no = owners(post)
_, _, executed_bodies, _ = owners(formatted)
assert oo == no and nb == executed_bodies
names = {"cache_materialize_check", "collect_data"}
assert [dump(n) for n in ot.body if not isinstance(n, ast.FunctionDef) or n.name not in names] == [
    dump(n) for n in nt.body if not isinstance(n, ast.FunctionDef) or n.name not in names
]
normalized = copy.deepcopy(nf["cache_materialize_check"])
sets = [
    n
    for n in ast.walk(normalized)
    if isinstance(n, ast.Set)
    and any(isinstance(v, ast.Constant) and v.value == "mcts_configs" for v in n.elts)
]
assert len(sets) == 1
sets[0].elts = [
    n for n in sets[0].elts if not isinstance(n, ast.Constant) or n.value != "mcts_configs"
]
index = next(
    i
    for i, n in enumerate(normalized.body)
    if isinstance(n, ast.Assign)
    and len(n.targets) == 1
    and isinstance(n.targets[0], ast.Name)
    and n.targets[0].id == "mcts"
)
assert isinstance(normalized.body[index + 1], ast.If)
del normalized.body[index : index + 2]
old_loop = next(n for n in of["cache_materialize_check"].body if isinstance(n, ast.For))
index = next(i for i, n in enumerate(normalized.body) if isinstance(n, ast.For))
normalized.body[index] = copy.deepcopy(old_loop)
flags = [
    n
    for n in normalized.body
    if isinstance(n, ast.If) and ast.unparse(n.test) == "mcts is not None"
]
assert len(flags) == 1
normalized.body.remove(flags[0])
assert dump(normalized) == dump(of["cache_materialize_check"])
normalized_collect = copy.deepcopy(nf["collect_data"])
outer = next(
    n
    for n in normalized_collect.body
    if isinstance(n, ast.If) and "'terminal-cache'" in ast.unparse(n.test)
)
attempt = outer.body[0]
assert isinstance(attempt, ast.Try)
gens = [
    n
    for n in ast.walk(attempt)
    if isinstance(n, ast.GeneratorExp)
    and isinstance(n.elt, ast.IfExp)
    and "mcts_configs" in ast.unparse(n.elt.test)
]
assert len(gens) == 1
gens[0].elt = gens[0].elt.orelse
assert len(gens[0].generators) == 1
zip_call = gens[0].generators[0].iter
assert (
    isinstance(zip_call, ast.Call)
    and isinstance(zip_call.func, ast.Name)
    and zip_call.func.id == "zip"
)
assert len(zip_call.keywords) == 1 and zip_call.keywords[0].arg == "strict"
zip_call.keywords = []
index = next(
    i
    for i, n in enumerate(attempt.body)
    if isinstance(n, ast.Assign)
    and len(n.targets) == 1
    and isinstance(n.targets[0], ast.Name)
    and n.targets[0].id == "mcts"
)
assert isinstance(attempt.body[index + 1], ast.If)
del attempt.body[index : index + 2]
assert dump(normalized_collect) == dump(of["collect_data"])
tt = ast.parse(tests)
methods = [
    n.name for n in ast.walk(tt) if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")
]
assert len(methods) == 2
before = list(refs.values())
for ref in before:
    read(ref)
stop = now()
pid = os.getpid()
identity = dict(
    pid=pid,
    start_ticks=Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[19],
    boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
)
out = dict(
    target=target,
    before=before,
    after=list(refs.values()),
    source_reader_START=entry,
    source_reader_STOP=stop,
    source_clear=True,
    blockers=0,
    ordinary=0,
    strict_forward_inverse_hunks=hunks,
    outside_two_owners_BYTE_AST_exact=True,
    tested_two_owner_bytes_exact=True,
    previous_Alpha_AST_after_removing_only_MCTS_branches=True,
    original_other_collection_AST_exact=True,
    new_test_definitions=methods,
    producer_tests="Supplied 2 PASS once/synthetic metadata; not rerun",
    original_overall_helper_FAILED="Preserved; formatting restored outside owners, not rewritten PASS",
    self_identity=identity,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    own_guard="CPU10 affinity, AS512MiB and CPU30s static-helper limits; dated physical memory/topology only; no live guardian or family-peak certificate",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="Finite foreground stdlib AST/patch helper, no subprocess; tool-level handles/reap detail UNKNOWN",
    target_imports_functions_tests_models_RAW_native_geometry_library_Search_executions=0,
    source_Main_Git_index_writes=0,
    futurequiet=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            reader_STOP=stop,
            refs=len(refs),
            hunks=hunks,
            identity=identity,
            seconds=out["static_seconds"],
        )
    )
)
