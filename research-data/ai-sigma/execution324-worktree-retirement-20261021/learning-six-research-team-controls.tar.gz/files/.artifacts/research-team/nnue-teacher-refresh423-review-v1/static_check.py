"""423 frozen native source assessment; no target/Rust/test/backend execution."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-data-v1/native-source-v2"
)
ROOT = Path("/workspaces/quoridor")
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (50, 50))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    b = p.read_bytes()
    actual = {
        "path": str(p),
        "sha256": hashlib.sha256(b).hexdigest(),
        "bytes": len(b),
        "mode": f"{p.stat().st_mode & 0o7777:04o}",
    }
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return b


def body(raw, token):
    at = raw.index(token.encode())
    line = raw.rfind(b"\n", 0, at) + 1
    indent = raw[line:at].replace(b"pub(crate) ", b"").replace(b"pub ", b"")
    assert not indent.strip(), (token, indent)
    end = raw.index(b"\n" + indent + b"}", at) + len(indent) + 2
    return raw[at:end]


def git_read(git, path):
    return subprocess.run(
        ["git", "show", f"{git}:{path}"],
        cwd=ROOT,
        capture_output=True,
        check=True,
        timeout=20,
    ).stdout


entry = now()
target = {
    "path": str(BASE / "completion.json"),
    "sha256": "78b3030e0ac746885e993d680ab45a9154dfb90f772017ab032d77604272553b",
    "bytes": 2344,
    "mode": "0644",
}
completion = json.loads(read(target))
contents = {
    k: read(v)
    for k, v in completion.items()
    if isinstance(v, dict) and {"path", "sha256", "bytes", "mode"} <= v.keys()
}
binding = json.loads(contents["source_binding"])
for key in ["contract", "correction"]:
    read(binding[key])
spec_ref = {
    "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/spec.json",
    "sha256": "c919d92bea060ebb73d205801581f34a4751b5b33bf9decf72c2aa25ee65e359",
    "bytes": 17309,
    "mode": "0644",
}
spec = json.loads(read(spec_ref))
parser = OWN.parent / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
assert len(nodes) == 2
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
fw = scope["split_patch"](contents["patch"])
rv = scope["split_patch"](contents["inverse"])
before, after, checks = {}, {}, []
for row in binding["subjects"]:
    name = row["subject"]
    old = gzip.decompress(read(row["recovery"]))
    post = read(row["post"])
    assert len(old) == row["before_bytes"]
    assert hashlib.sha256(old).hexdigest() == row["before_sha256"]
    assert git_read(binding["base"]["git"], name) == old
    rebuilt, n = scope["apply"](old, fw[name])
    restored, m = scope["apply"](post, rv[name])
    assert rebuilt == post and restored == old and n == m
    before[name], after[name] = old, post
    checks.append({"subject": name, "hunks": n, "strict_forward_inverse": True})
assert set(fw) == set(rv) == set(before)
runtime = "crates/quoridor-runner/src/runtime.rs"
config = "crates/quoridor-runner/src/config.rs"
protected = []
for record in json.loads(contents["proof"])["protected_functions"]:
    name = record["function"]
    if name == "planned original default branch":
        old = body(before[runtime], "fn planned(")
        new = body(after[runtime], "fn planned(")
        token = b"    let (train, validation) = config.split_counts()"
        assert old[old.index(token) :] == new[new.index(token) :]
        protected.append({"function": name, "exact": True})
        continue
    token = "fn " + name + "("
    old = body(before[runtime], token)
    new = body(after[runtime], token)
    assert old == new
    protected.append({"function": name, "sha256": hashlib.sha256(new).hexdigest(), "exact": True})
post = after[runtime]
run = body(post, "fn run_inner(")
plan = body(post, "fn planned(")
for token in [
    b"common.validate_inputs()?",
    b"for id in common.batch_range()?",
    b'if slots[id]["prefix"].is_null()',
    b".find(|a| a.game == requests[id].0)",
    b"opening: assignment.prefix.clone()",
    b"split: assignment.split.clone()",
    b"out.len() != config.games",
]:
    assert token in plan
commit = body(post, "fn play_completed(")
assert commit.index(b"require_completed_mcts") < commit.index(b"TeacherRow::from_context")
assert commit.index(b"require_completed_mcts") < commit.index(b"commit_action")
quota = body(post, "fn admit_mcts_rows(")
assert b".logical_rows\n        .checked_add(c.warm_rows)" in quota
assert b"c.physical_rows().and_then(|n| n.checked_add(next))" in quota
assert b"logical.is_none_or(|n| n > limit) || physical.is_none_or(|n| n > limit)" in quota
assert run.index(
    b"if config.common_study.is_some()\n                    && let Err(error) = admit_mcts_rows"
) < run.index(b"let result = b.infer(&input)")
assert b"config.common_study.is_some() && result.is_ok()" in run
assert b"pump.backend_work = Some(inference_work(b.counters()))" in run

# R1 static control-flow witness: configuration chooses the shared CPU route;
# the separately supplied trait object is subsequently checked only by model SHA.
admit_start = run.index(b"let admission = if config.common_study.is_some()")
admit_end = run.index(b"} else if evaluation", admit_start)
shared = run[admit_start:admit_end]
assert b"provided" not in shared
assert b"admission.inference_core = Some(admission.worker_cores[0])" in shared
backend_start = run.index(b"let mut backend = if let Some(backend) = provided")
backend_end = run.index(b"if matches!(mode,", backend_start)
supplied = run[backend_start:backend_end]
assert b"i.model_sha != backend.metadata().model_sha" in supplied
assert b"Some(backend)" in supplied
assert b"common_study" not in supplied
assert b"common_study" not in body(post, "pub fn run_with_backend(")
record = body(post, "fn record(&mut self, mut o: Outcome")
assert b"o.reason = Some(reason.clone())" in record
assert b"o.failure = Some(crate::arena_clock::failure_from_reason(&reason))" in record
assert record.index(b"o.reason = Some(reason.clone())") < record.index(
    b"attach_primary_failure(&mut o, reason)"
)
worker = body(post, "fn worker(")
assert worker.index(b"if cancel.load(Ordering::Relaxed)") < worker.index(
    b"if g.context.terminal_value().is_some()"
)
dependencies = []
for name, tokens in {
    "crates/quoridor-data/src/common_corpus.rs": [
        "pub fn validate_inputs(",
        "pub fn batch_range(",
        "pub fn global_requests(",
    ],
    "crates/quoridor-data/src/terminal.rs": [
        "pub fn from_context(",
        "pub fn attach_terminal_targets(",
    ],
    "crates/quoridor-inference/src/lib.rs": ["pub fn physical_rows("],
}.items():
    raw = git_read(binding["base"]["git"], name)
    selected = []
    for token in tokens:
        selected_raw = body(raw, token)
        selected.append(
            {
                "token": token,
                "sha256": hashlib.sha256(selected_raw).hexdigest(),
                "bytes": len(selected_raw),
            }
        )
    dependencies.append(
        {
            "git": binding["base"]["git"],
            "path": name,
            "sha256": hashlib.sha256(raw).hexdigest(),
            "selected": selected,
        }
    )
    if name.endswith("terminal.rs"):
        assert b"Termination::Unknown if context.terminal_value().is_some()" in raw
        assert b"UNKNOWN cannot suppress a replay-proven terminal result" in raw
assert spec["generation"]["whole_study_Sigma_rows"] == 2000000
assert spec["generation"]["simulations_per_move"] == 64
assert sum(s["Sigma_rows_ceiling"] for s in spec["generation"]["pilot"]) == 240000
ids = []


def find_ids(value):
    if isinstance(value, dict):
        if {"pid", "start_ticks", "boot_id"} <= value.keys():
            v = {k: value[k] for k in ["pid", "start_ticks", "boot_id"]}
            if v not in ids:
                ids.append(v)
        for child in value.values():
            find_ids(child)
    elif isinstance(value, list):
        for child in value:
            find_ids(child)


find_ids(json.loads(contents["STOP"]))
fresh = []
for identity in ids:
    absent = not Path(f"/proc/{identity['pid']}").exists()
    assert absent, identity
    fresh.append({"identity": identity, "fresh_pid_absent": absent})
before_refs = list(refs.values())
for ref in before_refs:
    read(ref)
stop = now()
proof = {
    "target": target,
    "source_binding": completion["source_binding"],
    "actual_reader_START": entry,
    "actual_reader_STOP": stop,
    "before": before_refs,
    "after": list(refs.values()),
    "patches": checks,
    "protected": protected,
    "immutable_dependencies": dependencies,
    "R1_shared_route_has_no_supplied_backend_exclusion": True,
    "R1_supplied_branch_model_SHA_only": True,
    "C1_terminal_failure_replaces_existing_outcome_reason_failure": True,
    "source_clear": False,
    "blockers": 1,
    "ordinary": 1,
    "new_definitions": "five UNBUILT/UNTYPED/UNRUN at author; reviewer not executed",
    "static_seconds": time.monotonic() - started,
    "self_VmHWM": next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    "continuous_family_peak": "UNKNOWN",
    "fresh_known_identities": fresh,
    "owned_readers": [],
    "owned_children": [],
    "owned_jobs": [],
    "owned_handles": [],
    "owned_TMP": [],
    "owned_leases": [],
    "remaining": [],
    "canonical_lease_acquired": False,
    "directwait": "Five immutable Git reads synchronous returned/reaped; plain tool detailed process identity/handles UNKNOWN",
    "target_functions_Rust_tests_native_model_Search_payload_executions": 0,
    "source_Main_Git_index_writes": 0,
    "future_quiet_or_hardware_reservation": False,
}
(OWN / "static-proof.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        {
            "reader_STOP": stop,
            "refs": len(refs),
            "hunks": sum(v["hunks"] for v in checks),
            "protected": len(protected),
            "fresh_absent": len(fresh),
            "seconds": proof["static_seconds"],
            "self_VmHWM": proof["self_VmHWM"],
        }
    )
)
