"""Frozen metadata-branch static checks; never import or execute target code."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/learning-million/.artifacts/research-team/nnue-teacher-refresh423-learning-v1/mcts-cache-admission-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def split(raw):
    lines = raw.splitlines(keepends=True)
    starts = [i for i, line in enumerate(lines) if line.startswith(b"--- ")]
    starts.append(len(lines))
    out = {}
    for start, end in zip(starts, starts[1:]):
        assert lines[start + 1].startswith(b"+++ ")
        old, new = lines[start][4:].strip(), lines[start + 1][4:].strip()
        named = new if new != b"/dev/null" else old
        assert named.startswith((b"a/", b"b/"))
        name = named[2:].decode()
        assert name not in out
        out[name] = b"".join(lines[start:end])
    return out


def dump(node):
    return ast.dump(node, include_attributes=False)


def owner(raw):
    tree = ast.parse(raw)
    fn = next(
        n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "common_cache_config"
    )
    lines = raw.splitlines(keepends=True)
    a, b = sum(map(len, lines[: fn.lineno - 1])), sum(map(len, lines[: fn.end_lineno]))
    return tree, fn, raw[a:b], raw[:a] + raw[b:]


entry = now()
target = dict(
    path=str(BASE / "result-binding.json"),
    sha256="fee4f291871f9061797e75a80d40df556162e5368b1192bccb590ba24d400412",
    bytes=1164,
    mode="0644",
)
result = json.loads(read(target))
binding = json.loads(read(result["source"]))
old, post = read(binding["base_frozen_common"]), read(binding["post"])
read(binding["base_frozen_423_result"])
before_gz = read(binding["owner_before_gzip"])
after_owner = read(binding["owner_post"])
test = read(binding["test"])
forward, inverse = read(binding["forward"]), read(binding["inverse"])
read(binding["proof"])
read(binding["checks"])
read(binding["producer_completion"])
read(binding["producer_selected_binding"])
read(binding["producer_metadata_refs_and_sections"])
read(result["report"])
stop_raw = read(result["STOP"])
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
functions = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name == "apply"
]
scope = {"re": re}
exec(compile(ast.Module(body=functions, type_ignores=[]), str(parser), "exec"), scope)
fw, rv = split(forward), split(inverse)
cases = {"python/quoridor_training/common.py": (old, post), binding["test_target"]: (b"", test)}
assert set(fw) == set(rv) == set(cases)
hunks = 0
for name, (before, after) in cases.items():
    rebuilt, n = scope["apply"](before, fw[name])
    restored, m = scope["apply"](after, rv[name])
    assert rebuilt == after and restored == before and n == m
    hunks += n
ot, of, ob, oo = owner(old)
nt, nf, nb, no = owner(post)
assert gzip.decompress(before_gz).rstrip(b"\n") == ob.rstrip(b"\n")
assert after_owner.rstrip(b"\n") == nb.rstrip(b"\n")
assert oo == no
assert [dump(n) for n in ot.body if n is not of] == [dump(n) for n in nt.body if n is not nf]
old_loop = next(n for n in of.body if isinstance(n, ast.For))
new_loop = next(n for n in nf.body if isinstance(n, ast.For))
assert isinstance(new_loop.body[0], ast.If)
assert [dump(n) for n in old_loop.body[:-2]] == [dump(n) for n in new_loop.body[0].orelse]
assert [dump(n) for n in old_loop.body[-2:]] == [dump(n) for n in new_loop.body[1:]]
assert [dump(n) for n in of.body[-2:]] == [dump(n) for n in nf.body[-2:]]
old_scale = next(
    n
    for n in of.body
    if isinstance(n, ast.If) and ast.unparse(n.test) == "'model_scale_authority' in manifest"
)
new_scale = next(
    n
    for n in nf.body
    if isinstance(n, ast.If) and ast.unparse(n.test) == "'model_scale_authority' in manifest"
)
assert dump(old_scale) == dump(new_scale)
assert ast.get_source_segment(old.decode(), old_scale) == ast.get_source_segment(
    post.decode(), new_scale
)
test_tree = ast.parse(test)
methods = [
    n.name
    for n in ast.walk(test_tree)
    if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")
]
assert len(methods) == binding["new_definitions"] == 4
assert b'configs["sha256"] != manifest["dataset_sha"]' in nb
assert b'c["rootmean_is_raw"] is not mcts' in nb
assert b'"native-teacher-dataset-shards-v1"' in nb
ids = []


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            identity = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if identity not in ids:
                ids.append(identity)
        for child in v.values():
            find_ids(child)
    elif isinstance(v, list):
        for child in v:
            find_ids(child)


find_ids(json.loads(stop_raw))
fresh = []
for identity in ids:
    assert not Path(f"/proc/{identity['pid']}").exists(), identity
    fresh.append(dict(identity=identity, fresh_pid_absent=True))
before = list(refs.values())
for ref in before:
    read(ref)
stop = now()
out = dict(
    target=target,
    binding=result["source"],
    before=before,
    after=list(refs.values()),
    source_reader_START=entry,
    source_reader_STOP=stop,
    source_clear=True,
    blockers=0,
    ordinary=0,
    strict_forward_inverse_hunks=hunks,
    outside_owner_BYTE_AST_exact=True,
    original_Alpha_loop_AST_exact=True,
    scale_authority_BYTE_AST_exact=True,
    original_batch_cursor_AST_exact=True,
    new_test_definitions=methods,
    producer_four_NN0="Supplied PASS_ONCE, not rerun; fake metadata, real0",
    fresh_known_IDs=fresh,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="Finite foreground stdlib AST/patch helper; no subprocess; detailed tool handles UNKNOWN",
    target_imports_functions_tests_models_RAW_native_library_Search_executions=0,
    source_Main_Git_index_writes=0,
    futurequiet=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            reader_STOP=stop,
            refs=len(refs),
            hunks=hunks,
            fresh_absent=len(fresh),
            seconds=out["static_seconds"],
        )
    )
)
