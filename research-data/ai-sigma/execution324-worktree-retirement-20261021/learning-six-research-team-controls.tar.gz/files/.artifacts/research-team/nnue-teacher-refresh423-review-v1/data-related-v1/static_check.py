"""Frozen C1/C2 patch verification only; never execute producer functions."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-data-v1/data-related-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
started = time.monotonic()
refs = {}


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def replace_once(raw, old, new):
    assert raw.count(old) == 1
    return raw.replace(old, new)


entry = now()
target = dict(
    path=str(BASE / "completion.json"),
    sha256="5f6e1aec8cb50853c681fecb1cb7bc036afeaf52cdd3f5c5a3712fd76fb608eb",
    bytes=3386,
    mode="0644",
)
completion = json.loads(read(target))
binding = json.loads(read(completion["binding"]))
old, post = read(binding["before"]), read(binding["post"])
assert gzip.decompress(read(binding["recovery"])) == old
forward, inverse = read(binding["forward"]), read(binding["inverse"])
read(binding["proof"])
read(binding["review"])
read(binding["review_control"])
read(completion["report"])
stop_raw = read(completion["STOP"])
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
fw, rv = scope["split_patch"](forward), scope["split_patch"](inverse)
name = binding["subject"]
assert set(fw) == set(rv) == {name}
rebuilt, hunks = scope["apply"](old, fw[name])
restored, inverse_hunks = scope["apply"](post, rv[name])
assert rebuilt == post and restored == old and hunks == inverse_hunks == 4
addition = b"""// Producer spelling is part of the global ID, not an arbitrary numeric alias.
fn mcts_game_id(game: &str) -> Result<usize> {
    let id = game
        .strip_prefix("game-")
        .ok_or("MCTS global game ID")?
        .parse::<usize>()?;
    if game != format!("game-{id}") {
        return Err("noncanonical MCTS global game ID spelling".into());
    }
    Ok(id)
}

"""
expected = replace_once(
    old, b"/// Normal selfplay datasets only.", addition + b"/// Normal selfplay datasets only."
)
parse = b"""                let id: usize = row
                    .game
                    .strip_prefix("game-")
                    .ok_or("MCTS global game ID")?
                    .parse()?;"""
expected = replace_once(expected, parse, b"                let id = mcts_game_id(&row.game)?;")
fixture = b"""                root_mean: raw,
                root_nn: Some(0.25),
                root_visits: 64,
                nn_calls: 1,
                edges: vec![],"""
fixed_fixture = b"""                root_mean: raw,
                root_nn: Some(0.25),
                root_visits: 64,
                nn_calls: 1,
                edges: vec![crate::Visit {
                    action: 13,
                    visits: 63,
                    prior: 1.0,
                }],"""
expected = replace_once(expected, fixture, fixed_fixture)
header = (
    b"    fn common_mcts_raw_requires_model_complete_visits_and_finite_head_without_z_mask() {\n"
)
aliases = b"""        assert_eq!(mcts_game_id("game-0").unwrap(), 0);
        assert_eq!(mcts_game_id("game-10").unwrap(), 10);
        for alias in ["game-00", "game-01", "game-+0", "game--0", "game- 0", "0"] {
            assert!(mcts_game_id(alias).is_err(), "{alias}");
        }
"""
expected = replace_once(expected, header, header + aliases)
assert expected == post
test_names = re.findall(rb"#\[test\]\s+fn (\w+)", old)
assert test_names == re.findall(rb"#\[test\]\s+fn (\w+)", post)
receiver = post[post.index(b"pub fn write_common_mcts(") :]
assert receiver.index(b"mcts_game_id(&row.game)?") < receiver.index(b"let assignment =")
assert receiver.index(b"mcts_game_id(&row.game)?") < receiver.index(b"writer.push(row, None)?")
assert 63 + 1 == 64
ids = []


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            i = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if i not in ids:
                ids.append(i)
        for child in v.values():
            find_ids(child)
    elif isinstance(v, list):
        for child in v:
            find_ids(child)


find_ids(json.loads(stop_raw))
fresh = []
for identity in ids:
    assert not Path(f"/proc/{identity['pid']}").exists(), identity
    fresh.append(dict(identity=identity, fresh_pid_absent=True))
before = list(refs.values())
for ref in before:
    read(ref)
stop = now()
out = dict(
    target=target,
    binding=completion["binding"],
    before=before,
    after=list(refs.values()),
    source_reader_START=entry,
    source_reader_STOP=stop,
    source_clear=True,
    blockers=0,
    ordinary=0,
    resolved=["C1", "C2"],
    strict_forward_inverse_hunks=hunks,
    exact_four_replacements_only=True,
    same_test_names=[v.decode() for v in test_names],
    existing_validator_reused_not_executed=True,
    fixture_static_visit_sum=64,
    fresh_known_IDs=fresh,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="Finite foreground stdlib static helper; no subprocess. Detailed plain-tool identity/handles UNKNOWN",
    target_functions_tests_native_models_RAW_library_Search_executions=0,
    source_Main_Git_index_writes=0,
    futurequiet=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            reader_STOP=stop,
            refs=len(refs),
            hunks=hunks,
            fresh_absent=len(fresh),
            seconds=out["static_seconds"],
        )
    )
)
