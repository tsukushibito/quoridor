"""Frozen Python source/patch/AST inspection only. Never execute target bodies."""

import ast
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = OWN.parents[1] / "nnue-teacher-refresh423-learning-v1" / "final-fit-view-receiver-v1"
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
START = datetime.datetime.now(datetime.timezone.utc).isoformat()
T0 = time.monotonic()
REFS = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    info = p.stat()
    assert info.st_size == ref["bytes"] <= 1048576
    with p.open("rb") as stream:
        raw = stream.read(ref["bytes"] + 1)
    actual = dict(path=str(p), sha256=sha(raw), bytes=len(raw), mode=f"{info.st_mode & 4095:04o}")
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    REFS[str(p)] = actual
    return raw


result_ref = dict(
    path=str(BASE / "result-binding.json"),
    sha256="d5633cccc11501a054fde9ec223d133b50207dcfcc70c0030595bc8f23864a38",
    bytes=1162,
    mode="0644",
)
result = json.loads(read(result_ref))
binding = json.loads(read(result["source"]))
for ref in result.values():
    if isinstance(ref, dict) and "path" in ref:
        read(ref)
for key, ref in binding.items():
    if key != "before" and isinstance(ref, dict) and "path" in ref:
        read(ref)
post = read(binding["post"])
owner_post = read(binding["after_owner"])
owner_before = gzip.decompress(read(binding["before_owner_gzip"]))
assert post.count(owner_post) == 1
before = post.replace(owner_post, owner_before, 1)
assert sha(before) == binding["before"]["sha256"] and len(before) == binding["before"]["bytes"]
old_ast, new_ast = ast.parse(before), ast.parse(post)
old_fn = next(
    n for n in old_ast.body if isinstance(n, ast.FunctionDef) and n.name == "common_cache_config"
)
new_fn = next(n for n in new_ast.body if isinstance(n, ast.FunctionDef) and n.name == old_fn.name)
assert len(new_fn.body) == len(old_fn.body) + 1
assert isinstance(new_fn.body[-2], ast.If) and isinstance(new_fn.body[-1], ast.Return)
assert ast.dump(ast.Module(body=new_fn.body[:-2] + new_fn.body[-1:], type_ignores=[])) == ast.dump(
    ast.Module(body=old_fn.body, type_ignores=[])
)
new_fn.body.pop(-2)
assert ast.dump(old_ast) == ast.dump(new_ast)
# Reuse only our own already-maintained strict unified-patch utility functions.
utility_path = OWN.parents[1] / "sigma-alpha420-review-v1" / "static_check.py"
utility_ast = ast.parse(utility_path.read_bytes())
utility = {"re": re}
exec(
    compile(
        ast.Module(
            body=[
                n
                for n in utility_ast.body
                if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
            ],
            type_ignores=[],
        ),
        str(utility_path),
        "exec",
    ),
    utility,
)
patch = read(binding["forward"])
parts = utility["split_patch"](patch)
old_new = {
    "python/quoridor_training/common.py": (before, post),
    "python/quoridor_training/test_final_fit_view.py": (b"", read(binding["new_test"])),
}
hunks = 0
for name, (old, new) in old_new.items():
    forward, count = utility["apply"](old, parts[name])
    inverse, reverse_count = utility["apply"](new, parts[name], True)
    assert forward == new and inverse == old and count == reverse_count
    hunks += count
# Explicit inverse patch independently checked, including deletion of new test.
lines = read(binding["inverse"]).splitlines(keepends=True)
heads = [i for i, line in enumerate(lines) if line.startswith(b"--- ")] + [len(lines)]
for a, b in zip(heads, heads[1:]):
    name = lines[a][6:].strip().decode()
    old, new = old_new[name]
    inverse, _ = utility["apply"](new, b"".join(lines[a:b]))
    assert inverse == old
ast_post = ast.parse(post)
owner = next(
    n for n in ast_post.body if isinstance(n, ast.FunctionDef) and n.name == "common_cache_config"
)
reader = next(
    n for n in ast.walk(owner) if isinstance(n, ast.FunctionDef) and n.name == "read_metadata"
)
reads = [
    dict(line=n.lineno, expression=ast.unparse(n))
    for n in ast.walk(owner)
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "read_bytes"
]
assert len(reads) == 2 and all(
    not n.args and not n.keywords
    for n in ast.walk(owner)
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "read_bytes"
)
cache_if = next(
    n for n in reader.body if isinstance(n, ast.If) and ast.unparse(n.test) == "key not in metadata"
)
assert any(isinstance(n, ast.Name) and n.id == "limit" for n in ast.walk(cache_if))
assert not any(
    isinstance(n, ast.Name) and n.id == "limit"
    for n in reader.body
    if n is not cache_if
    for n in ast.walk(n)
)
tests = ast.parse(read(binding["new_test"]))
names = [
    n.name for n in ast.walk(tests) if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")
]
assert len(names) == 5
# Separate dated current-Main observation, never reinterpret the historical before FileRef.
p = Path(binding["before"]["path"])
current = p.read_bytes()
current_ref = dict(
    path=str(p), sha256=sha(current), bytes=len(current), mode=f"{p.stat().st_mode & 4095:04o}"
)
assert current_ref["sha256"] in {binding["before"]["sha256"], binding["post"]["sha256"]}
# Last selected-reference read window; no custody/lease is held during later reporting.
for ref in list(REFS.values()):
    read(ref)
STOP = datetime.datetime.now(datetime.timezone.utc).isoformat()
proof = dict(
    target=result_ref,
    binding=result["source"],
    refs_before_after=REFS,
    selected_refs=len(REFS),
    before_reconstructed_sha256=sha(before),
    current_Main_observation=current_ref,
    strict_forward_inverse_hunks=hunks,
    explicit_inverse_exact=True,
    outside_owner_bytes_exact=True,
    outside_owner_AST_exact=True,
    old_owner_AST_prefix_return_exact=True,
    only_one_optional_tail=True,
    target_functions_executed=0,
    producer_new_definitions_read_not_executed=names,
    bounded_reader_static_evidence=dict(
        reads=reads, reader_line=reader.lineno, role_limit_checked_only_on_cache_miss=True
    ),
    start=START,
    reader_STOP=STOP,
    own_identity=dict(
        pid=os.getpid(),
        start_ticks=Path(f"/proc/{os.getpid()}/stat").read_text().rsplit(")", 1)[1].split()[19],
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    ),
    helper_wall_s=time.monotonic() - T0,
    self_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    family_continuous_peak="UNKNOWN",
    leases_acquired=[],
    owned_readers_children_jobs_TMP_remaining=[],
    source_inputs_total_bytes=sum(r["bytes"] for r in REFS.values()),
)
(OWN / "static-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            k: proof[k]
            for k in [
                "selected_refs",
                "strict_forward_inverse_hunks",
                "reader_STOP",
                "helper_wall_s",
                "self_ru_maxrss_KiB",
                "own_identity",
                "bounded_reader_static_evidence",
                "current_Main_observation",
            ]
        }
    )
)
