"""Frozen learner patch/AST checks and tiny scalar bounds; target never executed."""

import ast
import copy
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = OWN.parents[1] / "nnue-teacher-refresh423-learning-v1"
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (50, 50))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    v = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert v == {k: ref[k] for k in v}
    assert str(p) not in refs or refs[str(p)] == v
    refs[str(p)] = v
    return raw


def source(raw, node):
    return ast.get_source_segment(raw.decode(), node).encode()


def function(raw, name):
    return next(
        n for n in ast.walk(ast.parse(raw)) if isinstance(n, ast.FunctionDef) and n.name == name
    )


entry = now()
target = dict(
    path=str(BASE / "result-binding.json"),
    sha256="a56b3eba950ad265155591417afc474ffcd3c8ef8deea8c1a4554a131ca0199b",
    bytes=2133,
    mode="0644",
)
result = json.loads(read(target))
result_refs = {
    k: read(v)
    for k, v in result.items()
    if isinstance(v, dict) and {"path", "sha256", "bytes", "mode"} <= v.keys()
}
binding = json.loads(result_refs["source"])
contents = {
    "patch": read(binding["patch"]),
    "proof": read(binding["proof"]),
    "materializer": read(binding["actual_config_materializer"]),
    "checks": read(binding["scoped_checks"]),
    "parent_gap": read(binding["current_publisher_gap_fragments"]),
}
for ref in binding["fixed_spec"].values():
    read(ref)
proof = json.loads(contents["proof"])
post = {name: read(ref) for name, ref in binding["postimages"].items()}
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
patches = scope["split_patch"](contents["patch"])
before, patch_checks, protected = {}, [], []
changed = {
    "common": {"validate_mixed_config", "validate_mixture_config", "warmstart_model_inputs"},
    "public_replay": {
        "planned_work",
        "admit",
        "train_mixture",
        "public_observation_policy",
        "initial_observation_scopes",
    },
    "sampling": {"indexed_public_sample"},
}


def module_view(raw, key):
    tree = copy.deepcopy(ast.parse(raw))
    kept = []
    for n in tree.body:
        if isinstance(n, ast.FunctionDef) and n.name in changed[key]:
            continue
        if key == "common":
            if isinstance(n, ast.Assign) and any(
                isinstance(v, ast.Name) and v.id == "MIXTURE_OPTIONS" for v in n.targets
            ):
                continue
            if isinstance(n, ast.Expr) and source(raw, n).startswith(
                b'DEFAULTS["mixture"].update('
            ):
                continue
        if key == "public_replay" and isinstance(n, ast.ClassDef) and n.name == "Selector":
            n.body = [
                v for v in n.body if not isinstance(v, ast.FunctionDef) or v.name != "observe"
            ]
        kept.append(n)
    tree.body = kept
    return ast.dump(tree, include_attributes=False)


for name, row in proof["source_owners"].items():
    key = Path(name).stem
    old = gzip.decompress(read(row["before_gzip"]))
    expected = binding["before"][key]
    assert hashlib.sha256(old).hexdigest() == expected["sha256"] and len(old) == expected["bytes"]
    new = post[name]
    rebuilt, n = scope["apply"](old, patches[name])
    restored, m = scope["apply"](new, patches[name], reverse=True)
    assert rebuilt == new and restored == old and n == m
    assert module_view(old, key) == module_view(new, key)
    before[key] = old
    patch_checks.append(dict(subject=name, hunks=n, exact_forward_inverse=True))
    for node in ast.parse(old).body:
        if isinstance(node, ast.FunctionDef) and node.name not in changed[key]:
            match = function(new, node.name)
            assert source(old, node) == source(new, match)
            protected.append(
                dict(
                    module=key,
                    owner=node.name,
                    sha256=hashlib.sha256(source(old, node)).hexdigest(),
                )
            )
test_name = "python/quoridor_training/test_teacher_refresh_inputs.py"
new_test = post[test_name]
rebuilt, n = scope["apply"](b"", patches[test_name])
restored, m = scope["apply"](new_test, patches[test_name], reverse=True)
assert rebuilt == new_test and restored == b"" and n == m
assert set(patches) == set(post)
patch_checks.append(dict(subject=test_name, hunks=n, exact_forward_inverse=True, executed=False))
prefix = "python/quoridor_training/"
new_public = post[prefix + "public_replay.py"]
old_train = function(before["public_replay"], "train_mixture")
new_train = function(new_public, "train_mixture")
for name in ["forward", "save_checkpoint"]:
    a = source(before["public_replay"], function(before["public_replay"], name))
    b = source(new_public, function(new_public, name))
    assert a == b
    protected.append(
        dict(module="public_replay.train_mixture", owner=name, sha256=hashlib.sha256(a).hexdigest())
    )


def finalizer(raw, node):
    tr = next(
        n
        for n in ast.walk(node)
        if isinstance(n, ast.Try)
        and n.finalbody
        and any("_finalize_training" in ast.unparse(v) for v in n.finalbody)
    )
    lines = raw.splitlines(keepends=True)
    return b"".join(lines[tr.finalbody[0].lineno - 1 : tr.finalbody[-1].end_lineno])


assert finalizer(before["public_replay"], old_train) == finalizer(new_public, new_train)
sample = source(
    post[prefix + "sampling.py"], function(post[prefix + "sampling.py"], "indexed_public_sample")
)
for token in [
    b'corpus.records("train", rows, training=True)',
    b"decay ** (files - 1 - shard)",
    b"acceptance_rng is rng",
    b"check()",
]:
    assert token in sample
materializer = contents["materializer"]
for token in [
    b'arm in ("U", "R")',
    b'fresh = arm == "F"',
    b'public_acceptance_seed=seeds["R_acceptance_stream"]',
    b'public_sampling_seed=seeds["U_R_uniform_proposal_stream"]',
    b"public_rows=256 if public else 0",
    b"update(weights=None, evaluator_sha256=None)",
    b'public_evaluation={"validation": "best", "train_diagnostic": True}',
]:
    assert token in materializer
tail_cases = []
for rows in [1, 217, 4096, 8192]:
    for fresh in [False, True]:
        total = min((64 if fresh else 8) * rows, 524288 if fresh else 32768)
        updates = (total + 255) // 256
        last = total - 256 * (updates - 1)
        assert 1 <= last <= 256 and 256 * (updates - 1) + last == total
        tail_cases.append(dict(R=rows, fresh=fresh, total=total, updates=updates, final_batch=last))
spec = json.loads(read(binding["fixed_spec"]["spec.json"]))
assert spec["seeds"]["U_R_uniform_proposal_stream"] == 42320261023
assert spec["seeds"]["R_acceptance_stream"] == 42320261028
assert spec["training_schedule"]["logical_forward_ceiling"] == 4000000
first_weight = 0.92**42
assert 0 < first_weight < 1 and 0.92**0 == 1
test_methods = [
    n.name
    for n in ast.walk(ast.parse(new_test))
    if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")
]
assert len(test_methods) == 10
ids = []


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            ident = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if ident not in ids:
                ids.append(ident)
        for x in v.values():
            find_ids(x)
    elif isinstance(v, list):
        for x in v:
            find_ids(x)


find_ids(json.loads(result_refs["STOP"]))
fresh_ids = []
for ident in ids:
    absent = not Path(f"/proc/{ident['pid']}").exists()
    assert absent, ident
    fresh_ids.append(dict(identity=ident, fresh_pid_absent=absent))
before_refs = list(refs.values())
for ref in before_refs:
    read(ref)
stop = now()
out = dict(
    target=target,
    source_binding=result["source"],
    source_reader_START=entry,
    source_reader_STOP=stop,
    before=before_refs,
    after=list(refs.values()),
    patches=patch_checks,
    protected=protected,
    finalizer_BYTE_exact=True,
    scalar_tail_cases=tail_cases,
    scalar_file43_weights=dict(first=first_weight, last=1),
    actual_source_shards_membership="runtime original qualified public input remains required; no payload read",
    tests="ten supplied definitions not executed by reviewer; producer nine successful commands and ninth assertion PASS/wholeFAILED retained",
    author_fake_forward_rows=72,
    real_reviewer_forward_rows=0,
    parent_null_F_gap="Root numerical_fields/experiment_check known separate dependency; not source-cleared here",
    actual_configs_weights_Experiment="NOT_CREATED",
    fresh_known_IDs=fresh_ids,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    canonical_lease_acquired=False,
    target_functions_tests_frameworks_native_models_Search_Cargo_payload_executions=0,
    source_Main_Git_index_writes=0,
    directwait="Finite foreground stdlib static helper, no subprocess; plain tool detailed process identity/handles UNKNOWN",
    future_quiet_or_idle_lease=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        {
            "reader_STOP": stop,
            "refs": len(refs),
            "hunks": sum(v["hunks"] for v in patch_checks),
            "protected": len(protected),
            "fresh_absent": len(fresh_ids),
            "seconds": out["static_seconds"],
            "self_VmHWM": out["self_VmHWM"],
        }
    )
)
