"""C1 final-census/C2 declaration delta only; no target execution."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-data-v1/native-repair-v2"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (50, 50))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def body(raw, token):
    at = raw.index(token.encode())
    start = raw.rfind(b"\n", 0, at) + 1
    indent = raw[start:at].replace(b"pub(crate) ", b"").replace(b"pub ", b"")
    assert not indent.strip()
    end = raw.index(b"\n" + indent + b"}", at) + len(indent) + 2
    return raw[at:end]


entry = now()
target = dict(
    path=str(BASE / "completion.json"),
    sha256="ed77bf49a64aaa27a26e044970dc3bcad7312f7111a21ecbfec4be35571e77b3",
    bytes=2838,
    mode="0644",
)
completion = json.loads(read(target))
contents = {
    k: read(v)
    for k, v in completion.items()
    if isinstance(v, dict) and {"path", "sha256", "bytes", "mode"} <= v.keys()
}
binding = json.loads(contents["binding"])
old = gzip.decompress(read(binding["recovery"]))
assert (
    len(old) == binding["before"]["bytes"]
    and hashlib.sha256(old).hexdigest() == binding["before"]["sha256"]
)
assert read(binding["before"]) == old
post = contents["post"]
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
assert len(nodes) == 2
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
f = scope["split_patch"](contents["forward"])
r = scope["split_patch"](contents["inverse"])
name = binding["subject"]
assert set(f) == set(r) == {name}
rebuilt, n = scope["apply"](old, f[name])
restored, m = scope["apply"](post, r[name])
assert rebuilt == post and restored == old and n == m
old_run = body(old, "fn run_inner(")
new_run = body(post, "fn run_inner(")
original_loop = b"""if let Some(reason) = &stopped {
            for o in &mut outcomes {
                attach_primary_failure(o, reason);
            }
        }"""
new_call = b"attach_final_primary_failures(config, &pump, &mut outcomes, stopped.as_deref());"
assert old_run.count(original_loop) == 1 and new_run.count(new_call) == 1
assert new_run.replace(new_call, original_loop) == old_run
for token in [
    "pub fn run_with_backend(",
    "fn record(&mut self, mut o: Outcome",
    "fn attach_primary_failure(",
    "fn record_publication_failure(",
]:
    assert body(old, token) == body(post, token)
final = body(post, "fn attach_final_primary_failures(")
for token in [
    b"let Some(reason) = stopped else",
    b"config.common_study.is_some()",
    b"(outcome.reason.is_some() || outcome.failure.is_some())",
    b"failure.game == Some(outcome.game)",
    b'failure.reason.starts_with("terminal_targets:")',
    b"if !preserve {\n            attach_primary_failure(outcome, reason)",
]:
    assert token in final
test = post[post.index(b"mod common_mcts_admission_cause_tests {") :]
assert b"fn counters(&self) -> InferenceCounters" in test
assert b'panic!("supplied counters must not be entered")' in test
assert b"attach_final_primary_failures(&c, &pump, &mut outcomes, stopped.as_deref());" in test
assert b'assert_eq!(outcomes[0].reason.as_deref(), Some("cancelled"))' in test
assert b'assert_eq!(stopped.as_deref(), Some("earlier_backend_failure"))' in test
ids = []


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            ident = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if ident not in ids:
                ids.append(ident)
        for child in v.values():
            find_ids(child)
    elif isinstance(v, list):
        for child in v:
            find_ids(child)


find_ids(json.loads(contents["STOP"]))
fresh = []
for ident in ids:
    absent = not Path(f"/proc/{ident['pid']}").exists()
    assert absent, ident
    fresh.append(dict(identity=ident, fresh_pid_absent=absent))
before = list(refs.values())
for ref in before:
    read(ref)
stop = now()
out = dict(
    target=target,
    source_binding=completion["binding"],
    before=before,
    after=list(refs.values()),
    source_reader_START=entry,
    source_reader_STOP=stop,
    strict_hunks=n,
    run_inner_only_loop_extraction_byte_exact=True,
    R1_and_record_primary_publication_bodies_exact=True,
    C1_same_final_function_production_and_definition=True,
    C2_required_counters_signature_present=True,
    related_source_clear=True,
    source_clear=True,
    blockers=0,
    ordinary=0,
    software="changed2 definitions UNBUILT/UNTYPED/UNRUN; no reviewer type/compile/test",
    fresh_known_IDs=fresh,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        v for v in Path("/proc/self/status").read_text().splitlines() if v.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="Finite foreground stdlib helper, no subprocess; plain tool detailed process identity/handles UNKNOWN",
    target_functions_tests_native_models_Search_Cargo_payload_executions=0,
    source_Main_Git_index_writes=0,
    futurequiet_or_idle_lease=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        {
            "reader_STOP": stop,
            "refs": len(refs),
            "hunks": n,
            "fresh_absent": len(fresh),
            "static_seconds": out["static_seconds"],
            "self_VmHWM": out["self_VmHWM"],
        }
    )
)
