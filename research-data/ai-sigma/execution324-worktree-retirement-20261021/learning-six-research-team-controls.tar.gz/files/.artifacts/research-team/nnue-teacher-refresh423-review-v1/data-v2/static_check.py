"""Verify only frozen MCTS receiver sources; never execute target code."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-data-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def body(raw, token):
    at = raw.index(token.encode())
    start = raw.rfind(b"\n", 0, at) + 1
    indent = raw[start:at].replace(b"pub(crate) ", b"").replace(b"pub ", b"")
    assert not indent.strip()
    end = raw.index(b"\n" + indent + b"}", at) + len(indent) + 2
    return raw[at:end]


entry = now()
target = dict(
    path=str(BASE / "completion-v2.json"),
    sha256="c4df42ddeb21d39f34724fa310cbc536e362aee4fc58fb6a86b8f65fd2c32f9c",
    bytes=5816,
    mode="0644",
)
completion = json.loads(read(target))
binding_ref = next(v for v in completion["source_packets"] if "/data-source-v2/" in v["path"])
binding = json.loads(read(binding_ref))
forward, inverse = read(binding["forward"]), read(binding["inverse"])
proof = json.loads(read(binding["proof"]))
stop_raw = read(completion["STOP"])
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
fw, rv = scope["split_patch"](forward), scope["split_patch"](inverse)
assert set(fw) == set(rv) == {v["subject"] for v in binding["subjects"]}
sources = {}
hunks = 0
for row in binding["subjects"]:
    old = gzip.decompress(read(row["recovery"]))
    post = read(row["post"])
    assert hashlib.sha256(old).hexdigest() == row["before_sha256"]
    assert len(old) == row["before_bytes"]
    rebuilt, n = scope["apply"](old, fw[row["subject"]])
    restored, m = scope["apply"](post, rv[row["subject"]])
    assert rebuilt == post and restored == old and n == m
    hunks += n
    sources[row["subject"]] = (old, post)
preserved = []
for item in proof["protected_top_level_functions"]:
    old, post = sources[item["subject"]]
    token = "fn " + item["function"] + "("
    assert body(old, token) == body(post, token)
    preserved.append(dict(subject=item["subject"], function=item["function"], exact=True))
cache = sources["crates/quoridor-data/src/terminal_cache.rs"][1]
assert b'.strip_prefix("game-")' in cache and b".parse()?;" in cache
assert b"self.seen_games.insert(r.game.clone())" in cache
assert b'format!("game-{id}")' not in cache[: cache.index(b"mod common_mcts_codec_tests")]
fixture = body(cache, "fn row(id: usize, raw: f32)")
assert b"root_visits: 64" in fixture and b"edges: vec![]" in fixture
assert b"TeacherRow::from_context(" in fixture and b".unwrap()" in fixture
git_argv = [
    "git",
    "-C",
    "/workspaces/quoridor",
    "show",
    "7cd6b40549069145cd0b80574ca9a5648b4da47d:crates/quoridor-data/src/lib.rs",
]
git = subprocess.run(git_argv, capture_output=True, check=True, timeout=10)
lib = git.stdout
assert len(lib) < 100000
constructor = body(lib, "pub fn from_context(")
validation = body(lib, "pub fn validate(&self)")
assert b"row.validate()?;" in constructor
assert (
    b"edges.iter().map(|e| e.visits as u64).sum::<u64>() + 1 != *root_visits as u64" in validation
)
assert b"MCTS visit accounting" in validation
ids = []


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            i = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if i not in ids:
                ids.append(i)
        for child in v.values():
            find_ids(child)
    elif isinstance(v, list):
        for child in v:
            find_ids(child)


find_ids(json.loads(stop_raw))
fresh = []
for i in ids:
    assert not Path(f"/proc/{i['pid']}").exists(), i
    fresh.append(dict(identity=i, fresh_pid_absent=True))
before = list(refs.values())
for r in before:
    read(r)
stop = now()
out = dict(
    target=target,
    binding=binding_ref,
    before=before,
    after=list(refs.values()),
    immutable_dependency=dict(
        argv=git_argv,
        sha256=hashlib.sha256(lib).hexdigest(),
        bytes=len(lib),
        constructor_SHA256=hashlib.sha256(constructor).hexdigest(),
        validation_SHA256=hashlib.sha256(validation).hexdigest(),
        returncode=git.returncode,
        directwait=True,
    ),
    source_reader_START=entry,
    source_reader_STOP=stop,
    strict_hunks=hunks,
    preserved=preserved,
    source_clear=False,
    blockers=0,
    ordinary=2,
    alias_static_example=dict(numeric_IDs=[int("0"), int("00")], distinct_string_games=True),
    fixture_visit_accounting=dict(edge_visit_sum=0, root_visits=64, required_sum_plus_one=1),
    target_functions_tests_native_geometry_Search_models_payload_executions=0,
    fresh_known_IDs=fresh,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="Finite foreground static helper and one immutable git-show directwait exit0; detailed plain-tool identity/handles UNKNOWN",
    source_Main_Git_index_writes=0,
    futurequiet=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            reader_STOP=stop,
            refs=len(refs),
            hunks=hunks,
            preserved=len(preserved),
            seconds=out["static_seconds"],
        )
    )
)
