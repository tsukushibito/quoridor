"""Stopped F nullweights consumer review: static bytes/AST, no target execution."""

import ast
import copy
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-teacher-refresh423-v1/fresh-parent-repair-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
started = time.monotonic()
refs = {}


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def split(raw):
    lines = [
        line
        for line in raw.splitlines(keepends=True)
        if not line.startswith((b"diff --git ", b"index "))
    ]
    starts = [i for i, line in enumerate(lines) if line.startswith(b"--- ")]
    starts.append(len(lines))
    out = {}
    for a, b in zip(starts, starts[1:]):
        assert lines[a + 1].startswith(b"+++ b/")
        name = lines[a + 1][6:].strip().decode()
        assert name not in out
        out[name] = b"".join(lines[a:b])
    return out


def dump(node):
    return ast.dump(node, include_attributes=False)


def functions(raw):
    tree = ast.parse(raw)
    return tree, {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}


def outside(raw, nodes):
    lines = raw.splitlines(keepends=True)
    omitted = set()
    for node in nodes:
        omitted.update(range(node.lineno - 1, node.end_lineno))
    return b"".join(line for i, line in enumerate(lines) if i not in omitted)


entry = now()
target = dict(
    path=str(BASE / "final-source-binding.json"),
    sha256="4c83baf8465e531b7ed9e98922dc83f1422effa7a11507c1512bda03abf75f18",
    bytes=4106,
    mode="0644",
)
binding = json.loads(read(target))
read(binding["initial_source_binding"])
old = gzip.decompress(read(binding["before_gzip"]))
post = read(binding["after"])
old_tests = gzip.decompress(read(binding["tests_before_gzip"]))
tests = read(binding["test"])
patch = read(binding["patch"])
receipt_documents = []
for receipt in binding["test_receipts"]:
    for key, ref in receipt.items():
        raw = read(ref)
        if key != "capture":
            receipt_documents.append(json.loads(raw))
guard_path = BASE.parent / "fresh-parent-source-final-guard-v1/STOP.json"
guard_raw = guard_path.read_bytes()
guard_ref = dict(
    path=str(guard_path),
    sha256=hashlib.sha256(guard_raw).hexdigest(),
    bytes=len(guard_raw),
    mode=f"{guard_path.stat().st_mode & 0o7777:04o}",
)
guard = json.loads(read(guard_ref))
assert guard["at"] == "2026-10-16T04:28:28.770532+00:00"
assert guard["owned_readers_children_jobs_handles_leases"] == []
receipt_documents.append(guard)
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name == "apply"
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
parts = split(patch)
cases = {
    "scripts/dev/research-lifecycle.py": (old, post),
    "scripts/dev/test_research_lifecycle.py": (old_tests, tests),
}
assert set(parts) == set(cases)
hunks = 0
for name, (before, after) in cases.items():
    rebuilt, n = scope["apply"](before, parts[name])
    restored, m = scope["apply"](after, parts[name], reverse=True)
    assert rebuilt == after and restored == before and n == m
    hunks += n
ot, of = functions(old)
nt, nf = functions(post)
owners = {"numerical_fields", "experiment_check"}
assert outside(old, [of[n] for n in owners]) == outside(post, [nf[n] for n in owners])
assert [dump(n) for n in ot.body if not isinstance(n, ast.FunctionDef) or n.name not in owners] == [
    dump(n) for n in nt.body if not isinstance(n, ast.FunctionDef) or n.name not in owners
]
assert len(of["numerical_fields"].body) == 1 and len(nf["numerical_fields"].body) == 3
normal = copy.deepcopy(nf["numerical_fields"])
normal.body = normal.body[2:]
original_return = of["numerical_fields"].body[0].value
returned = normal.body[0].value
old_index = next(i for i, key in enumerate(original_return.keys) if key.value == "weights_sha256")
index = next(i for i, key in enumerate(returned.keys) if key.value == "weights_sha256")
assert isinstance(returned.values[index], ast.Name) and returned.values[index].id == "weights"
returned.values[index] = copy.deepcopy(original_return.values[old_index])
assert dump(normal) == dump(of["numerical_fields"])
new_experiment = copy.deepcopy(nf["experiment_check"])
old_loop = next(
    n
    for n in of["experiment_check"].body
    if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == "model"
)
new_index = next(
    i
    for i, n in enumerate(new_experiment.body)
    if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == "model"
)
new_loop = new_experiment.body[new_index]
new_experiment.body[new_index] = copy.deepcopy(old_loop)
assert dump(new_experiment) == dump(of["experiment_check"])
mixed = next(
    n
    for n in nf["experiment_check"].body
    if isinstance(n, ast.If) and isinstance(n.test, ast.Name) and n.test.id == "mixed_outcome"
)
assert mixed.lineno < new_loop.lineno
assert any(
    isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "common_study_check"
    for n in ast.walk(mixed)
)
assert any(
    isinstance(n, ast.Expr)
    and isinstance(n.value, ast.Call)
    and isinstance(n.value.func, ast.Name)
    and n.value.func.id == "numerical_check"
    for n in nf["common_study_check"].body
)
assert dump(of["common_study_check"]) == dump(nf["common_study_check"])
assert dump(of["numerical_check"]) == dump(nf["numerical_check"])
old_tree, new_tree = ast.parse(old_tests), ast.parse(tests)
old_class = next(
    n for n in old_tree.body if isinstance(n, ast.ClassDef) and n.name == "LifecycleDataAndPaths"
)
new_class = next(
    n for n in new_tree.body if isinstance(n, ast.ClassDef) and n.name == "LifecycleDataAndPaths"
)
new_names = {
    "test_fresh_fit_numerical_identity_binds_descriptor_config_and_seed",
    "test_fresh_fit_ref_census_omits_absent_weights_after_normal_admission",
}
added = [n for n in new_class.body if isinstance(n, ast.FunctionDef) and n.name in new_names]
assert len(added) == 2
new_class.body = [n for n in new_class.body if n not in added]
assert dump(old_tree) == dump(new_tree)
assert [n.name for n in old_class.body if isinstance(n, ast.FunctionDef)] == [
    n.name for n in new_class.body if isinstance(n, ast.FunctionDef)
]
ids = []


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            identity = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if identity not in ids:
                ids.append(identity)
        for child in v.values():
            find_ids(child)
    elif isinstance(v, list):
        for child in v:
            find_ids(child)


for document in receipt_documents:
    find_ids(document)
fresh = []
for identity in ids:
    assert not Path(f"/proc/{identity['pid']}").exists(), identity
    fresh.append(dict(identity=identity, fresh_pid_absent=True))
before = list(refs.values())
for ref in before:
    read(ref)
stop = now()
out = dict(
    target=target,
    before=before,
    after=list(refs.values()),
    final_source_guard_witness=guard_ref,
    source_reader_START=entry,
    source_reader_STOP=stop,
    source_clear=True,
    blockers=0,
    ordinary=0,
    strict_forward_inverse_hunks=hunks,
    outside_two_owners_BYTE_AST_exact=True,
    normal_nonnull_numerical_fields_return_AST_exact=True,
    experiment_check_outside_model_refs_AST_exact=True,
    prior_common_study_and_numerical_check_AST_exact=True,
    original_test_methods_AST_exact=True,
    new_metadata_test_names=sorted(new_names),
    supplied_captures="Initial test1 PASS/test2 ERROR missing build_manifest; only corrected test2 PASS. Not rerun.",
    returned_NULL_fields="Retained as NULL, not interpreted as process exit0 or whole PASS",
    fresh_known_IDs=fresh,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="Finite foreground stdlib AST/patch helper; no subprocess; detailed tool handles UNKNOWN",
    target_imports_functions_tests_models_RAW_native_library_Search_executions=0,
    source_Main_Git_index_writes=0,
    futurequiet=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            reader_STOP=stop,
            refs=len(refs),
            hunks=hunks,
            fresh_absent=len(fresh),
            seconds=out["static_seconds"],
        )
    )
)
