"""One fixed input-source delta, static only; no generation/geometry execution."""

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-data-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
refs = {}
started = time.monotonic()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def read(ref):
    p = Path(ref["path"])
    assert not p.is_symlink()
    raw = p.read_bytes()
    actual = dict(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{p.stat().st_mode & 0o7777:04o}",
    )
    assert actual == {k: ref[k] for k in actual}
    assert str(p) not in refs or refs[str(p)] == actual
    refs[str(p)] = actual
    return raw


def body(raw, token):
    at = raw.index(token.encode())
    start = raw.rfind(b"\n", 0, at) + 1
    indent = raw[start:at].replace(b"pub(crate) ", b"").replace(b"pub ", b"")
    assert not indent.strip()
    end = raw.index(b"\n" + indent + b"}", at) + len(indent) + 2
    return raw[at:end]


entry = now()
target = dict(
    path=str(BASE / "completion-v2.json"),
    sha256="c4df42ddeb21d39f34724fa310cbc536e362aee4fc58fb6a86b8f65fd2c32f9c",
    bytes=5816,
    mode="0644",
)
completion = json.loads(read(target))
binding_ref = next(v for v in completion["source_packets"] if "/input-source-v1/" in v["path"])
binding = json.loads(read(binding_ref))
forward, inverse = read(binding["forward"]), read(binding["inverse"])
proof = json.loads(read(binding["proof"]))
stop_raw = read(completion["STOP"])
parser = OWN.parents[1] / "sigma-alpha420-review-v1/static_check.py"
nodes = [
    n
    for n in ast.parse(parser.read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
]
scope = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), "exec"), scope)
fw, rv = scope["split_patch"](forward), scope["split_patch"](inverse)
row = binding["subjects"][0]
old = gzip.decompress(read(row["recovery"]))
post = read(row["post"])
assert hashlib.sha256(old).hexdigest() == row["before_sha256"] and len(old) == row["before_bytes"]
name = row["subject"]
assert set(fw) == set(rv) == {name}
rebuilt, n = scope["apply"](old, fw[name])
restored, m = scope["apply"](post, rv[name])
assert rebuilt == post and restored == old and n == m
preserved = []
for item in proof["protected_top_level_functions"]:
    token = "fn " + item["function"] + "("
    assert body(old, token) == body(post, token)
    preserved.append(dict(function=item["function"], exact=True))
old_schedule = body(old, "pub fn global_schedule(")
new_schedule = body(post, "pub fn global_schedule(")
start = old_schedule.index(b"    if families == 0")
end = old_schedule.index(b"    let requests", start)
old_guard = old_schedule[start:end]
assert (
    new_schedule.replace(b"    validate_schedule_shape(families, lengths)?;\n", old_guard)
    == old_schedule
)
prepare = body(post, "pub fn prepare_inputs(")
assert prepare.index(b"reference.read()?") < prepare.index(b"std::fs::create_dir")
assert prepare.index(b".audit(prefix)?") < prepare.index(b"std::fs::create_dir")
assert (
    prepare.index(b"filter_input_slots(slots, &excluded")
    < prepare.index(b"global_partition(&slots")
    < prepare.index(b"std::fs::create_dir")
)
assert b".take(c.families)" in prepare and b"slot.game != id" in prepare
assert b"slot.scheduled_failure.is_none()" in prepare
ids = []


def find_ids(v):
    if isinstance(v, dict):
        if {"pid", "start_ticks", "boot_id"} <= v.keys():
            i = {k: v[k] for k in ["pid", "start_ticks", "boot_id"]}
            if i not in ids:
                ids.append(i)
        for child in v.values():
            find_ids(child)
    elif isinstance(v, list):
        for child in v:
            find_ids(child)


find_ids(json.loads(stop_raw))
fresh = []
for i in ids:
    absent = not Path(f"/proc/{i['pid']}").exists()
    assert absent, i
    fresh.append(dict(identity=i, fresh_pid_absent=True))
before = list(refs.values())
for r in before:
    read(r)
stop = now()
out = dict(
    target=target,
    binding=binding_ref,
    before=before,
    after=list(refs.values()),
    source_reader_START=entry,
    source_reader_STOP=stop,
    strict_hunks=n,
    preserved=preserved,
    source_clear=True,
    blockers=0,
    ordinary=0,
    original_global_schedule_equivalent_after_shape_extraction=True,
    existing_filter_partition_exclusions_no_refill=True,
    future_inputs_partition_actual_generation="NOT_RUN; final mapping still required",
    fresh_known_IDs=fresh,
    static_seconds=time.monotonic() - started,
    self_VmHWM=next(
        x for x in Path("/proc/self/status").read_text().splitlines() if x.startswith("VmHWM:")
    ),
    continuous_family_peak="UNKNOWN",
    owned_readers=[],
    owned_children=[],
    owned_jobs=[],
    owned_handles=[],
    owned_TMP=[],
    owned_leases=[],
    remaining=[],
    lease_acquired=False,
    directwait="Finite foreground static helper, no subprocess; plain tool detailed process identity/handles UNKNOWN",
    target_functions_tests_native_geometry_Search_models_payload_executions=0,
    source_Main_Git_index_writes=0,
    futurequiet=False,
)
(OWN / "static-proof.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(
    json.dumps(
        dict(
            reader_STOP=stop,
            refs=len(refs),
            hunks=n,
            preserved=len(preserved),
            fresh_absent=len(fresh),
            seconds=out["static_seconds"],
        )
    )
)
