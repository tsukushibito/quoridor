# 423.4 native R1/C1限定再確認

**source_clear=false / blockers=0 / ordinary=2**。R1は解消、C1がfinal censusに残り、新fixtureの必須trait method欠落をC2として記録します。固定7ae08ebb / binding412a3e2c、runtimeだけ4hunkをgzipから厳密正逆再構成。v2/初回51977decのnegative記録は不変、旧成功scopeは再演していません。

R1: run_with_backendはcommon_studyがあればrun_ownedより先に拒否します。normal run(None)/run_owned/run_innerはbyte不変。拒否前のmetadata/input/admission/infer callを増やさず、non-common embedding APIも保持します。suppliedオブジェクト自体は呼出側で既作成で、drop等まで無費用と主張しません。

C1未解消: recordのlocal preserve_outcome_causeは、その関数内のattributionだけを抑制します。実run_innerのfinal censusは依然、各Outcomeへattach_primary_failure(o, stopped)を無条件に呼び、既存helperはCancelled/NotStartedをglobal reasonのfailureへ置換します。新fixtureのように元Outcome.failure=Cancelled、別stopped=earlier_backend_failureの場合、record直後は保持できてもactual final census後には別failureになります。テストはrecord直後までなのでこの差を検査しません。先行global reasonと個別publication failureは別保存しつつ、既知per-outcome cause保持を同じ最終census経路にも適用する最小修復が必要です。実行/raceを観測した主張ではありません。

C2: 新MustNotEnterのInferenceBackend implにはinfer/metadataだけがあり、必須counters(&self)->InferenceCountersがありません。immutablec6ceの実trait宣言と照合しました。source上の欠落であり、Rust compilerを実行してE0046を観測したものではありません。panicするcounters定義等を足し、拒否がそれにも到達しないことを同じ新fixtureで表せます。新2定義はUNBUILT/UNTYPED/UNRUNのままです。

Reader STOP **2026-10-16T02:22:33.704493+00:00**。全selectedref前後SHA/size/mode一致、owned readers/children/jobs/handles/TMP/leases/remaining=[]、lease取得なし。known IDsのfreshabsenceはstatic-proof参照。one immutable Git readはdirectreturn/reap、plain tool詳細identity/handles・連続family peak UNKNOWN。静的helper0.223350843秒/selfVmHWM19356kB。CPU5はRoot guardian4と同physical core2なので、source/helperは別physical CPU16/core8・guardian候補18/core9へ置換しました。02:20:41のMemAvailable15354568kBはdatedfactでfuturequietではありません。

対象関数/tests/Rust/native/model/Search/forward/geometry/RAW/Cargoを実行せず、Main/source/Git/index write0。source resultはlearner確認を待たず324へ独立返却します。新software/numeric/strength/default許可なし。旧RAWFAILED/費/masks/UNKNOWN/pauses/models/seals保持、423.4 in_progress維持。
