"""Configured RUN source/patch/AST checks only, never target execution."""

import ast
import copy
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import time

OWN = Path(__file__).parent
TEAM = OWN.parents[1]
BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-teacher-refresh423-v1/arena-preparation-v1"
)
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
T0 = time.monotonic()
START = datetime.datetime.now(datetime.timezone.utc).isoformat()
REFS = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(ref):
    p = Path(ref["path"])
    info = p.lstat()
    assert not p.is_symlink() and info.st_size == ref["bytes"] <= 1048576
    with p.open("rb") as stream:
        raw = stream.read(ref["bytes"] + 1)
    actual = dict(path=str(p), sha256=sha(raw), bytes=len(raw), mode=f"{info.st_mode & 4095:04o}")
    assert actual == {k: ref[k] for k in actual}, (actual, ref)
    REFS[str(p)] = actual
    return raw


def node(module, name):
    return next(n for n in module.body if getattr(n, "name", None) == name)


def called(n, name):
    return bool(
        n.body
        and isinstance(n.body[0], ast.Expr)
        and isinstance(n.body[0].value, ast.Call)
        and isinstance(n.body[0].value.func, ast.Name)
        and n.body[0].value.func.id == name
    )


def segment(raw, n):
    return b"".join(raw.splitlines(keepends=True)[n.lineno - 1 : n.end_lineno])


root_ref = dict(
    path=str(BASE / "configured-arena-source-binding.json"),
    sha256="56468274ce91d06e2e4847ed2d58618060d0a729bddeec330625a0d8e0fc7d28",
    bytes=2614,
    mode="0644",
)
binding = json.loads(read(root_ref))
raw = {Path(r["path"]).name: read(r) for r in binding["refs"]}
post = raw["research-lifecycle.py"]
before = gzip.decompress(raw["caller-before-run-arena.py.gz"])
old_test = gzip.decompress(raw["tests-before-run-arena.py.gz"])
new_test = raw["test_research_lifecycle.py"]
old, new = ast.parse(before), ast.parse(post)
old_limits, new_limits = node(old, "Limits"), node(new, "Limits")
old_init, new_init = node(old_limits, "__init__"), node(new_limits, "__init__")
# Independently reorder the old AST; all remaining class/function/module AST must match.
expected = copy.deepcopy(old)
init = node(node(expected, "Limits"), "__init__")
arena = next(n for n in init.body if isinstance(n, ast.If) and called(n, "selected_arena"))
run = arena.orelse[0]
assert isinstance(run, ast.If) and called(run, "selected_run")
rest = run.orelse
arena.orelse = rest
run.orelse = [arena]
init.body[init.body.index(arena)] = run
approved = node(expected, "approved_plan")
assert isinstance(approved.body[1], ast.If) and isinstance(approved.body[2], ast.If)
assert ast.unparse(approved.body[1].body[0].value).startswith("selected_arena(")
assert ast.unparse(approved.body[2].body[0].value).startswith("selected_run(")
approved.body[1], approved.body[2] = approved.body[2], approved.body[1]
assert ast.dump(expected) == ast.dump(new)


# No other owner byte changes, including selected_run/selected_arena and arena validators.
def outside(raw, module):
    lines = raw.splitlines(keepends=True)
    ranges = [
        (node(module, "Limits").lineno - 1, node(module, "Limits").end_lineno),
        (node(module, "approved_plan").lineno - 1, node(module, "approved_plan").end_lineno),
    ]
    return b"".join(line for i, line in enumerate(lines) if not any(a <= i < b for a, b in ranges))


assert outside(before, old) == outside(post, new)
for name in [
    "selected_run",
    "selected_arena",
    "arena_plan_check",
    "experiment_check",
    "prepare_selected_operation",
    "sequence",
    "document",
    "read_ref",
]:
    assert segment(before, node(old, name)) == segment(post, node(new, name)), name
# Reconstruct actual tested pre-format source from the old class and exact branch snippets.
old_if = next(n for n in old_init.body if isinstance(n, ast.If) and called(n, "selected_arena"))
old_run = old_if.orelse[0]
old_class = segment(before, old_limits)
lines = before.splitlines(keepends=True)
arena_prefix = b"".join(lines[old_if.lineno - 1 : old_run.lineno - 1])
run_prefix = b"".join(lines[old_run.lineno - 1 : old_run.orelse[0].lineno - 1])
old_combined = arena_prefix + run_prefix
replacement = run_prefix.replace(b"        elif ", b"        if ", 1) + arena_prefix.replace(
    b"        if ", b"        elif ", 1
)
assert old_class.count(old_combined) == 1
preformat_class = old_class.replace(old_combined, replacement, 1)
post_class = segment(post, new_limits)
assert post.count(post_class) == 1
preformat = post.replace(post_class, preformat_class, 1)
receipt = json.loads(raw["configured-arena-software-once.json"])
assert (
    sha(preformat) == receipt["source"]["sha256"] and len(preformat) == receipt["source"]["bytes"]
)
assert ast.dump(ast.parse(preformat)) == ast.dump(new)
assert receipt["exit_code"] == 0 and receipt["old_tests_replayed"] == 0
assert receipt["tests"]["sha256"] == sha(new_test)
# New class only in tests; all prior definitions remain byte/AST exact.
ta, tb = ast.parse(old_test), ast.parse(new_test)
newclass = node(tb, "ConfiguredArenaPlanSelection")
assert len([n for n in newclass.body if isinstance(n, ast.FunctionDef)]) == 1
test_lines = new_test.splitlines(keepends=True)
restored = b"".join(test_lines[: newclass.lineno - 1] + test_lines[newclass.end_lineno :])
assert ast.dump(ast.parse(restored)) == ast.dump(ta)
for n in ta.body:
    if isinstance(n, (ast.ClassDef, ast.FunctionDef)):
        assert segment(old_test, n) == segment(new_test, node(tb, n.name))
# Reuse our own strict patch functions only.
utility_path = TEAM / "sigma-alpha420-review-v1/static_check.py"
utility_ast = ast.parse(utility_path.read_bytes())
utility = {"re": re}
exec(
    compile(
        ast.Module(
            body=[
                n
                for n in utility_ast.body
                if isinstance(n, ast.FunctionDef) and n.name in {"apply", "split_patch"}
            ],
            type_ignores=[],
        ),
        str(utility_path),
        "exec",
    ),
    utility,
)
parts = utility["split_patch"](raw["configured-arena-dispatch.patch"])
hunks = 0
for name, b, p in [
    ("scripts/dev/research-lifecycle.py", before, post),
    ("scripts/dev/test_research_lifecycle.py", old_test, new_test),
]:
    f, n = utility["apply"](b, parts[name])
    r, m = utility["apply"](p, parts[name], True)
    assert f == p and r == b and n == m
    hunks += n
for ref in list(REFS.values()):
    read(ref)
STOP = datetime.datetime.now(datetime.timezone.utc).isoformat()
proof = dict(
    target=root_ref,
    refs_before_after=REFS,
    selected_refs=len(REFS),
    strict_forward_inverse_hunks=hunks,
    only_two_dispatch_reorderings_semantic=True,
    outside_two_owner_bytes_exact=True,
    other_owner_AST_exact=True,
    protected_functions_byte_exact=[
        "selected_run",
        "selected_arena",
        "arena_plan_check",
        "experiment_check",
        "prepare_selected_operation",
        "sequence",
        "document",
        "read_ref",
    ],
    old_test_definitions_bytes_AST_exact=True,
    preformat_tested_source_reconstructed=dict(
        sha256=sha(preformat), bytes=len(preformat), AST_exact_to_final=True
    ),
    producer_one_metadata_PASS_read_not_replayed=True,
    target_functions_tests_executed=0,
    start=START,
    reader_STOP=STOP,
    own_identity=dict(
        pid=os.getpid(),
        start_ticks=Path(f"/proc/{os.getpid()}/stat").read_text().rsplit(")", 1)[1].split()[19],
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    ),
    helper_wall_s=time.monotonic() - T0,
    self_ru_maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    family_continuous_peak="UNKNOWN",
    owned_readers_children_jobs_handles_TMP_leases_remaining=[],
    leases_acquired=[],
)
(OWN / "static-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        {
            k: proof[k]
            for k in [
                "selected_refs",
                "strict_forward_inverse_hunks",
                "reader_STOP",
                "own_identity",
                "helper_wall_s",
                "self_ru_maxrss_KiB",
                "preformat_tested_source_reconstructed",
            ]
        }
    )
)
