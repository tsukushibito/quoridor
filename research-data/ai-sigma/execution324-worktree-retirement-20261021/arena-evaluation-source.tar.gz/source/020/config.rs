use quoridor_runner::config::Config;
fn config() -> Config {
    serde_json::from_value(serde_json::json!({"ruleset":"standard_2p_threefold","run_id":"test","output":"out","games":2,"workers":1,"engines":[{"kind":"distance","depth":1}]})).unwrap()
}
#[test]
fn rejects_unknown_keys_limits_and_missing_backend() {
    assert!(config().validate().is_ok());
    assert!(serde_json::from_value::<Config>(serde_json::json!({"ruleset":"standard_2p_threefold","run_id":"test","output":"out","engines":[{"kind":"distance"}],"unknown":true})).is_err());
    let mut c = config();
    c.max_batch = 0;
    assert!(c.validate().is_err());
    c.max_batch = 8;
    c.engines[0].kind = "mcts".into();
    assert!(c.validate().is_err());
}
#[test]
fn host_reserve_is_not_overridden_by_explicit_memory() {
    let a = quoridor_runner::resources::admit(1, &[], false, 0, Some(u64::MAX)).unwrap();
    assert!(a.memory_limit <= a.memory_available);
    let b = quoridor_runner::resources::admit(1, &[65535], false, 0, None);
    assert!(b.is_err());
}

#[test]
fn paired_arena_counts_are_admitted_by_family_before_execution() {
    let mut c = config();
    c.engines.push(c.engines[0].clone());
    c.games = 8;
    assert_eq!(c.split_counts().unwrap(), (4, 2));
    assert!(c.validate().is_ok());
    c.train_games = Some(5);
    assert!(c.validate().unwrap_err().contains("color pairs"));
    c.train_games = Some(4);
    c.validation_games = Some(1);
    assert!(c.validate().is_err());
    c.validation_games = Some(2);
    c.games = 7;
    assert!(c.validate().is_err());
    c.games = 8;
    c.train_games = Some(usize::MAX - 1);
    assert!(c.validate().is_err());
}

#[test]
fn optional_job_wall_preserves_other_limits() {
    let mut c = config();
    c.wall_seconds = None;
    assert!(c.validate().is_ok());
    for bad in [0., -1., f64::NAN, f64::INFINITY] {
        c.wall_seconds = Some(bad);
        assert!(c.validate().is_err());
    }
    c.wall_seconds = None;
    c.max_plies = 0;
    assert!(c.validate().is_err());
}

#[test]
fn research_threefold_config_requires_explicit_current_convention() {
    let mut value = serde_json::to_value(config()).unwrap();
    assert_eq!(value["ruleset"], "standard_2p_threefold");
    assert_eq!(
        config().ruleset.id(),
        "research-standard-2p-threefold-goal-first-v1"
    );
    value.as_object_mut().unwrap().remove("ruleset");
    assert!(serde_json::from_value::<Config>(value.clone()).is_err());
    for old in ["rule_a", "official", "standard_2p", ""] {
        value["ruleset"] = old.into();
        assert!(serde_json::from_value::<Config>(value.clone()).is_err());
    }
    value["ruleset"] = "standard_2p_threefold".into();
    assert!(
        serde_json::from_value::<Config>(value)
            .unwrap()
            .validate()
            .is_ok()
    );
}
