"""Only new lifecycle-separation tests; synthetic metadata, no actual outcomes."""

import ast
import gzip
from pathlib import Path
import subprocess
import sys
import unittest
from unittest import mock

import io355
import observations355
import stream355
from test_strength355 import synthetic_book, synthetic_schedule


class LifecyclePreparation(unittest.TestCase):
    def setUp(self):
        self.book = synthetic_book()
        self.schedule = synthetic_schedule(self.book)
        self.index = {
            "batches": [],
            "matched_rows": [],
            "selection": None,
            "stronger_rows": [],
            "trees": [],
            "producer_bindings": {},
            "partial_errors": ["synthetic producer has not entered"],
        }
        self.inputs = mock.Mock()
        self.inputs.progress = {"rows_read": 0, "available_sections": []}

    def test_closed_current_entry_does_not_read_certificates_rows_or_publish(self):
        with (
            mock.patch.object(io355, "read_bound") as read,
            mock.patch.object(Path, "mkdir") as create,
        ):
            with self.assertRaisesRegex(RuntimeError, "schema not yet bound"):
                stream355.future_entry("/UNENTERED", {}, "/OLD_CERTIFICATE", "0" * 64, "/UNENTERED")
            read.assert_not_called()
            create.assert_not_called()
        self.assertFalse(hasattr(stream355, "read_source_lineage"))
        self.assertFalse(hasattr(stream355, "verify_engineering_qualification"))
        self.assertFalse(hasattr(io355, "future_packet_entry"))

    def test_unentered_migration_keeps_full_planned_counts_and_missingness(self):
        partial = {}
        result = observations355.aggregate_observations(
            self.index,
            self.inputs,
            partial,
            self.book,
            self.schedule,
            {"synthetic_context_only": True},
        )
        self.assertIs(result, partial)
        self.assertEqual(result["provenance"], "SYNTHETIC")
        for row in result["games"]["matchups"].values():
            self.assertEqual(row["planned_games"], 256)
            self.assertEqual(row["known_games"], 0)
            self.assertEqual(row["complete_pairs"], 0)
            self.assertEqual(row["planned_score_missingness_bounds"], [0.0, 1.0])
        self.assertEqual(result["matched"]["planned_calls"], 96)
        self.assertEqual(result["stronger"], {"status": "UNKNOWN", "campaign_upper_calls": 192})
        self.assertEqual(result["unentered_tree_family_ids"], list(range(0, 128, 16)))
        self.assertEqual(result["partial_errors"], self.index["partial_errors"])
        self.inputs.after.assert_called_once()

    def test_later_failure_preserves_original_object_and_earlier_planned_summary(self):
        primary = RuntimeError("synthetic matched input unavailable after games")
        self.index["matched_rows"] = ["UNAVAILABLE"]
        self.inputs.get.side_effect = primary
        partial = {}
        with self.assertRaises(RuntimeError) as caught:
            observations355.aggregate_observations(
                self.index, self.inputs, partial, self.book, self.schedule, {}
            )
        self.assertIs(caught.exception, primary)
        self.assertIs(primary.strength355_available_evidence, partial)
        self.assertIs(primary.strength355_input_progress, self.inputs.progress)
        self.assertIn("games", partial)
        self.assertNotIn("matched", partial)
        for row in partial["games"]["matchups"].values():
            self.assertEqual(row["planned_games"], 256)
        self.inputs.after.assert_not_called()

    def test_scientific_checker_bodies_are_unchanged_by_authority_migration(self):
        here = Path(__file__).resolve().parent
        before = ast.parse(
            gzip.decompress((here / "stream355.py.lifecycle-v7.before.gz").read_bytes())
        )
        old = next(
            node for node in before.body if isinstance(node, ast.ClassDef) and node.name == "Inputs"
        )
        current = ast.parse((here / "stream355.py").read_bytes())
        new = next(
            node
            for node in current.body
            if isinstance(node, ast.ClassDef) and node.name == "Inputs"
        )
        self.assertEqual(ast.dump(old), ast.dump(new))
        # Saved-row consumption owns no child/clock/publication/authority import.
        observed = ast.parse((here / "observations355.py").read_bytes())
        imports = {node.names[0].name for node in observed.body if isinstance(node, ast.Import)}
        self.assertEqual(imports, {"producer355", "strength355"})

    def test_retired_receipt_ports_refuse_at_cli_before_any_guard_or_child_job(self):
        here = Path(__file__).resolve().parent
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(here / "qualify_whole_support355.py"),
                "--module",
                "test_lineage355",
                "--version",
                "UNENTERED_RETIRED",
            ],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        self.assertEqual(result.returncode, 2)
        self.assertIn("invalid choice", result.stderr)
        self.assertNotIn("actual named peer", result.stderr)
        self.assertFalse((here / "whole-control-ports-STOP-UNENTERED_RETIRED.json").exists())
