"""Current lifecycle-preparation NN0 ports under the finite source-only guard."""

import datetime
import argparse
import fcntl
import importlib
import json
import os
from pathlib import Path
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--module",
        choices=("test_lifecycle_repair355",),
        default="test_lifecycle_repair355",
    )
    parser.add_argument("--version", default="v1")
    parser.add_argument("--tests", nargs="*")
    args = parser.parse_args()
    with LOCK.open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        sys.path.insert(0, str(HERE))
        # Stdlib guard source imported only under the actual lifetime lease.
        guard = importlib.import_module("io355")
        guard.named_quiet()
        guard.finite_physical()
        refs = {
            name: guard.identity(HERE / name)
            for name in (
                "io355.py",
                "stream355.py",
                "observations355.py",
                "lifecycle355.py",
                "producer355.py",
                "strength355.py",
                args.module + ".py",
                Path(__file__).name,
            )
            if (HERE / name).exists()
        }
        before = (
            sum(p.stat().st_blocks * 512 for p in HERE.rglob("*")) + HERE.stat().st_blocks * 512
        )
        if before + 262144 > 16777216:
            raise RuntimeError("source forward unsupported")
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        clock = time.monotonic()
        module = importlib.import_module(args.module)
        suite = (
            unittest.defaultTestLoader.loadTestsFromNames(args.tests, module)
            if args.tests
            else unittest.defaultTestLoader.loadTestsFromModule(module)
        )
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        for name, ref in refs.items():
            if guard.identity(HERE / name) != ref:
                raise RuntimeError("resource source-after drift")
        sampled = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/self/status").read_text().splitlines()
                    if x.startswith("VmHWM:")
                )
            )
            * 1024
            + 67108864
        )
        if sampled > 536870912:
            raise RuntimeError("sampled family allowance")
        stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
        record = {
            "schema": "quoridor.strength355.whole-control-NN0-STOP.v1",
            "issue": "quoridor-4lc.355.3",
            "actual_START": start,
            "actual_source_reader_STOP": stop,
            "PASS": result.wasSuccessful(),
            "count": result.testsRun,
            "failures": [str(x) for x, _ in result.failures],
            "errors": [str(x) for x, _ in result.errors],
            "source_refs": refs,
            "elapsed_seconds": time.monotonic() - clock,
            "sampled_family_including64MiB_B": sampled,
            "continuous_peak_admin_fees": "UNKNOWN",
            "owned_readers_children_jobs_TMP_remaining": [],
            "TMP_created": "bounded owned synthetic fixture directories removed",
            "actual_science_inputs_model_Cargo_native_Search_games": 0,
            "actual_applied_turn_context": "2026-10-10T05:49:43.315Z/fullaccessnever/gpt6.1-solhigh/originallearning-million",
            "current_hardware_reservation_after_direct_return": "NONE",
        }
        (HERE / f"whole-control-ports-STOP-{args.version}.json").write_text(
            json.dumps(record, indent=2) + "\n"
        )
        return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    raise SystemExit(main())
