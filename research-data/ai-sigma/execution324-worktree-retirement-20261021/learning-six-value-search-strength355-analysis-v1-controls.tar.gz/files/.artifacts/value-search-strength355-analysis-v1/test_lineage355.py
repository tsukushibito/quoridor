"""New Root-decision lineage/qualification tests, using metadata only."""

import copy
import json
from pathlib import Path
import unittest
from unittest import mock

import composite355 as c
import io355
import stream355

PATHS = {
    "lineage": Path(c.ROOT + "compare-source-lineage-acceptance-v1.json"),
    "composite": Path(c.ROOT + "composite-source-STOP-v2.json"),
    "derivation": Path(c.ROOT + "mechanical-lint-integration-v2.json"),
    "original": Path(c.REVIEW_PATH),
}


class LineageReceipt(unittest.TestCase):
    def setUp(self):
        self.raw = {key: json.loads(path.read_bytes()) for key, path in PATHS.items()}
        self.refs = {
            key: {"path": str(path), **io355.identity(path)} for key, path in PATHS.items()
        }

    def inputs(self, raw=None):
        raw = self.raw if raw is None else raw
        result = mock.Mock()
        result.refs = self.refs
        result.get.side_effect = lambda name, maximum=131072: raw[name]
        return result

    def read(self, raw=None):
        return stream355.read_source_lineage(self.inputs(raw), "lineage", "composite", "derivation")

    def test_actual_acceptance_retains_two_stops_and_no_runtime_permission(self):
        result = self.read()
        self.assertEqual(result["module_SHA256"], c.CURRENT_MODULE_SHA)
        self.assertEqual(result["reviewed_module_SHA256"], c.MODULE_SHA)
        self.assertEqual(result["original_review_reader_STOP"], self.raw["original"]["reader_STOP"])
        self.assertEqual(result["actual_source_reader_STOP"], "2026-10-10T00:34:38.871482+00:00")
        self.assertNotEqual(
            result["actual_source_reader_STOP"], result["original_review_reader_STOP"]
        )
        self.assertFalse(result["independently_reviewed_current_bytes"])
        self.assertFalse(result["numeric_READY"])

    def test_retargeted_review_copied_clear_or_independent_current_claim_refuses(self):
        for field, value in [
            ("source_clear", 1),
            ("blockers", False),
            ("independently_reviewed_current_bytes", True),
            ("numeric_READY", True),
            ("submit_authorized", True),
            ("original_review_reader_STOP", self.raw["lineage"]["actual_source_reader_STOP"]),
            ("actual_source_reader_STOP", "2026-10-10T00:34:38"),
            ("owned_readers", ["pending"]),
        ]:
            bad = copy.deepcopy(self.raw)
            bad["lineage"][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.read(bad)
        bad = copy.deepcopy(self.raw)
        bad["original"]["module_sha256"] = c.CURRENT_MODULE_SHA
        with self.assertRaises(ValueError):
            self.read(bad)

    def test_missing_or_mismatched_predecessor_or_derivation_refuses(self):
        for field in (
            "original_review_control",
            "mechanical_derivation",
            "stopped_current_composite",
        ):
            bad = copy.deepcopy(self.raw)
            bad["lineage"][field]["sha256"] = "0" * 64
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.read(bad)
        bad = copy.deepcopy(self.raw)
        bad["derivation"]["changes"][1]["before_SHA256"] = c.CURRENT_MODULE_SHA
        with self.assertRaises(ValueError):
            self.read(bad)
        inputs = self.inputs()
        inputs.refs = {key: value for key, value in self.refs.items() if key != "original"}
        with self.assertRaises(ValueError):
            stream355.read_source_lineage(inputs, "lineage", "composite", "derivation")

    def test_bad_lineage_refuses_in_live_entry_before_any_book_or_outcome(self):
        raw = copy.deepcopy(self.raw)
        raw["lineage"]["original_review_reader_STOP"] = raw["lineage"]["actual_source_reader_STOP"]
        inputs = self.inputs(raw)
        with self.assertRaises(ValueError):
            stream355.analyze_index(
                {
                    "composite_source": "composite",
                    "mechanical_source_derivation": "derivation",
                    "current_source_lineage": "lineage",
                },
                inputs,
                {},
            )
        self.assertTrue(all(call.args[0] in PATHS for call in inputs.get.call_args_list))

    def test_v8_null_template_stays_unqualified_and_missing_software_is_not_source_clear(self):
        path = Path(
            "/workspaces/quoridor/.worktree/value-search-strength-engineering355/.artifacts/"
            "value-search-strength355/native-qualification-template-v8.json"
        )
        q = json.loads(path.read_bytes())
        self.assertEqual(
            q["source_review"], {"path": str(PATHS["lineage"]), "sha256": c.LINEAGE_SHA}
        )
        raw = {**self.raw, "q": q}
        inputs = self.inputs(raw)
        context = {"composite_source": "composite", "mechanical_source_derivation": "derivation"}
        with self.assertRaises(ValueError):
            stream355.verify_engineering_qualification(
                inputs, "q", {"source_book_SHA256": "1" * 64}, context
            )
        self.assertEqual(inputs.get.call_count, 1)
        q = copy.deepcopy(q)
        q.update(
            book_sha256="1" * 64,
            executable_sha256="2" * 64,
            compiled_sources_sha256="3" * 64,
            generation_compiled_sources_sha256="4" * 64,
        )
        q["software_receipt"] = {"path": "/SYNTHETIC/unavailable", "sha256": "5" * 64}
        inputs = self.inputs({**self.raw, "q": q})
        with self.assertRaises(ValueError):
            stream355.verify_engineering_qualification(
                inputs, "q", {"source_book_SHA256": "1" * 64}, context
            )
        self.assertTrue(any(call.args[0] == "lineage" for call in inputs.get.call_args_list))
        self.assertFalse(
            any(call.args[0] == "/SYNTHETIC/unavailable" for call in inputs.get.call_args_list)
        )
