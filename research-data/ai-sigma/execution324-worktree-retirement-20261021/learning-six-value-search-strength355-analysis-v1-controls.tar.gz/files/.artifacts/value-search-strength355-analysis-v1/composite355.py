"""Real stopped composite/source receipt alignment; no source bodies or images."""

import datetime

import strength355 as s

COMPOSITE_SHA = "2e60e6f6ed02edc0dcb1c53c2b516740064f57d44019e5a580ce66ecde3975d6"
DERIVATION_SHA = "127aa7fd648a99cddabb9d9fe9fc4997e74a3de53efd380bf90e517d84df4302"
CURRENT_MODULE_SHA = "94fda09e07f6db245bcc281323d3b9b288562d964d4bef10b26166e14dfe5889"
REVIEW_SHA = "d4e32f2588d3cb938b35edef9151ca59d25771e228fd2d0b450f1e60f56ba130"
MODULE_SHA = "b81e5c4949084d9e0dc86966ae85be974b841a90223c0ac4e1ca81ebdd69c3ff"
TARGET_SHA = "c453f84f0ca53ad6fa2bbb6bd5f486df55dd59e9daa286b0aaa5391f9f7ea369"
LINEAGE_SHA = "4aa059f8a55f2d067b7a55c5f977c53f36e7e71d340d2898fb95361935360a8a"
ROOT = "/workspaces/quoridor/research-data/ai-sigma/value-search-strength355/"
REVIEW_PATH = (
    "/workspaces/quoridor/.worktree/learning-million/.artifacts/"
    "value-search-strength355-review-v1/compare-related-v4/control.json"
)
MANIFESTS = [
    "c4712e0872b6831e33fcf59b99d9d7f774d18a3e8d5236d7923ba65e64aabc39",
    "46ec2c4708f96dcf9fad579c2fb0d1299c6663df27412f0faac98267467715e1",
]
WEIGHTS = [
    "9ca438e43b0c105ac5f802a302946f2ba71623ea2bc443b9c54cc9a8468b75b0",
    "046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841",
]


def stopped(stamp):
    s.require(isinstance(stamp, str), "actual STOP string")
    parsed = datetime.datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    s.require(parsed.tzinfo is not None, "actual dated STOP")


def validate_derivation(receipt, identity):
    """Verify the exact stopped mechanical edge, retaining original review bytes."""
    s.require(
        {k: identity[k] for k in ("SHA256", "bytes", "mode")}
        == {"SHA256": DERIVATION_SHA, "bytes": 2528, "mode": "0644"},
        "fixed actual mechanical derivation file",
    )
    s.require(
        receipt["schema"] == "quoridor.value-search-strength.mechanical-lint-integration.v1"
        and receipt["issue"] == "quoridor-4lc.355",
        "mechanical derivation scope",
    )
    for key in ("only_three_declared_hunks", "all_nineteen_test_definitions_byte_identical"):
        s.require(receipt[key] is True, "literal mechanical proof predicate")
    s.require(receipt["owned_readers_children_jobs_TMP"] == [], "mechanical reader census")
    for key in ("producer_reader_writer_STOP", "actual_root_source_writer_STOP"):
        stopped(receipt[key])
    s.require(
        receipt["binding_SHA256"]
        == "7d47ca9abc7cabf8a74aab3bfc81af70efad478f829072d62b4f73e454eddee3"
        and receipt["patch_SHA256"]
        == "5999232d63a8b4a9ad19ba5894bf54e3dae1ca24e2d4f2798b70ce079dafc29f",
        "exact producer and mechanical patch",
    )
    expected = [
        (
            "value_search_strength.rs",
            "f02548c4c3004074a4c0b9a4641abd72aa3239ff78551c610a4c3ce0b0ad34d7",
            "1e9ef7ac4d9dba35f4685a6ef5eb6c0a22a81bdda6593eb0ff9a65f17e4dcd38",
            31753,
            31748,
        ),
        ("value_search_compare.rs", MODULE_SHA, CURRENT_MODULE_SHA, 53305, 53274),
    ]
    s.require(
        type(receipt["changes"]) is list and len(receipt["changes"]) == 2,
        "exact two mechanical source edges",
    )
    for row, (name, before, after, before_bytes, after_bytes) in zip(receipt["changes"], expected):
        s.require(
            row["relative_path"] == "crates/quoridor-runner/src/" + name
            and row["before_SHA256"] == before
            and row["after_SHA256"] == after
            and type(row["before_bytes"]) is int
            and row["before_bytes"] == before_bytes
            and type(row["bytes"]) is int
            and row["bytes"] == after_bytes
            and type(row["mode"]) is int
            and row["mode"] == 420
            and row["strict_forward_inverse"] is True
            and row["entire_test_module_byte_unchanged"] is True,
            "exact mechanical before/after and unchanged definitions",
        )
    return receipt["changes"]


def validate_composite(receipt, identity, derivation, derivation_identity):
    s.require(
        identity["SHA256"] == COMPOSITE_SHA
        and identity["bytes"] == 17774
        and identity["mode"] == "0644",
        "fixed actual composite file",
    )
    s.require(
        receipt["schema"] == "quoridor.value-search-strength.composite-source-STOP.v2"
        and receipt["issue"] == "quoridor-4lc.355",
        "composite receipt scope",
    )
    s.require(
        receipt["owned_readers_children_jobs_TMP"] == []
        and receipt["hardware_reservation"] == "NONE",
        "stopped source census",
    )
    stopped(receipt["actual_source_writer_STOP"])
    changes = validate_derivation(derivation, derivation_identity)
    s.require(
        receipt["mechanical_derivation"] == "mechanical-lint-integration-v2.json"
        and receipt["copied_changed_source"] == changes,
        "current composite links exact mechanical edges",
    )
    rows = receipt["source_build_inputs"]
    s.require(
        len(rows) == 42 and len({r["relative_path"] for r in rows}) == 42,
        "42 unique composite inputs",
    )
    for row in rows:
        s.require(row["Main_SHA256"] == row["owned_SHA256"], "Main/owned composite drift")
        s.sha(row["Main_SHA256"])
        s.integer(row["bytes"])
        s.require(row["mode"] in ("0644", "0755"), "composite source modes")
    s.require(
        sum(r["bytes"] for r in rows) == receipt["input_unique_B"] == 904478,
        "directed composite input bytes",
    )
    module = [
        r
        for r in rows
        if r["relative_path"] == "crates/quoridor-runner/src/value_search_compare.rs"
    ]
    s.require(
        len(module) == 1
        and module[0]["Main_SHA256"] == CURRENT_MODULE_SHA
        and receipt["review_controls"]["compare"] == REVIEW_SHA,
        "current derivative and unchanged original review identity",
    )
    for edge in changes:
        matches = [r for r in rows if r["relative_path"] == edge["relative_path"]]
        s.require(
            len(matches) == 1
            and matches[0]["Main_SHA256"] == edge["after_SHA256"]
            and matches[0]["bytes"] == edge["bytes"],
            "derivative in common source map",
        )
    s.require(
        receipt["one_common_target_B"] == 1073741824 and receipt["one_private_B"] == 33554432,
        "one common target/private",
    )
    return {
        "composite_SHA256": COMPOSITE_SHA,
        "module_SHA256": CURRENT_MODULE_SHA,
        "reviewed_module_SHA256": MODULE_SHA,
        "mechanical_derivation_SHA256": DERIVATION_SHA,
        "source_only": True,
        "image_private_book_input_qualified": False,
    }


def validate_source_review(receipt, expected_module=MODULE_SHA):
    required = {
        "issue",
        "fixed_target_SHA256",
        "status",
        "source_clear",
        "blockers",
        "ordinary",
        "module_sha256",
        "reader_STOP",
        "remaining",
        "owned_readers",
        "owned_children",
        "owned_jobs",
        "owned_TMP",
    }
    s.require(type(receipt) is dict and required <= receipt.keys(), "actual source receipt fields")
    s.require(
        receipt["issue"] == "quoridor-4lc.355.6"
        and receipt["fixed_target_SHA256"] == TARGET_SHA
        and receipt["module_sha256"] == expected_module == MODULE_SHA,
        "source review actual target/module scope",
    )
    s.require(
        receipt["status"] == "SOURCE_CLEAR" and receipt["source_clear"] is True,
        "actual source-only clear",
    )
    for key in ("blockers", "ordinary"):
        s.require(type(receipt[key]) is int and receipt[key] == 0, "source literal zero findings")
    for key in ("remaining", "owned_readers", "owned_children", "owned_jobs", "owned_TMP"):
        s.require(receipt[key] == [], "actual source reader census")
    stopped(receipt["reader_STOP"])
    return {
        "source_scope_clear": True,
        "numeric_READY": False,
        "module_SHA256": expected_module,
        "reader_STOP": receipt["reader_STOP"],
    }


def validate_lineage(receipt, identity, original_review, composite, derivation):
    """Current Root acceptance is distinct from the original independent review."""
    s.require(
        {k: identity[k] for k in ("SHA256", "bytes", "mode")}
        == {"SHA256": LINEAGE_SHA, "bytes": 4937, "mode": "0644"}
        and identity["path"] == ROOT + "compare-source-lineage-acceptance-v1.json",
        "fixed actual Root lineage acceptance",
    )
    s.require(
        receipt["schema"] == "quoridor.value-search-strength.compare-source-lineage-acceptance.v1"
        and receipt["issue"] == "quoridor-4lc.355"
        and receipt["integration_issue"] == "quoridor-4lc.324"
        and receipt["status"] == "SOURCE_CLEAR"
        and receipt["source_clear"] is True
        and receipt["independently_reviewed_current_bytes"] is False
        and receipt["module_sha256"] == CURRENT_MODULE_SHA
        and receipt["reviewed_original_module_sha256"] == MODULE_SHA,
        "explicit derivative acceptance, never independent current-byte review",
    )
    for key in ("blockers", "ordinary"):
        s.require(type(receipt[key]) is int and receipt[key] == 0, "lineage integer zero findings")
    for key in ("remaining", "owned_readers", "owned_children", "owned_jobs", "owned_TMP"):
        s.require(receipt[key] == [], "lineage actual empty census")
    for key in (
        "software_private_generatedbook_model_input_fair_qualification",
        "numeric_READY",
        "submit_authorized",
    ):
        s.require(receipt[key] is False, "source lineage launches nothing")
    for key in (
        "only_three_declared_hunks_in_two_modules",
        "strict_full_forward_inverse_verified_by_Root",
        "entire_nineteen_test_definition_modules_unchanged",
    ):
        s.require(receipt[key] is True, "actual literal derivative predicates")
    expected_refs = {
        "original_review_control": (REVIEW_PATH, REVIEW_SHA, 4415),
        "mechanical_derivation": (
            ROOT + "mechanical-lint-integration-v2.json",
            DERIVATION_SHA,
            2528,
        ),
        "stopped_current_composite": (ROOT + "composite-source-STOP-v2.json", COMPOSITE_SHA, 17774),
        "original_review_target": (
            "/workspaces/quoridor/.worktree/value-search-strength-engineering355/.artifacts/"
            "value-search-strength355/related-source-STOP-binding-v4.json",
            TARGET_SHA,
            5799,
        ),
    }
    for key, (path, digest, size) in expected_refs.items():
        s.require(
            receipt[key] == {"path": path, "sha256": digest, "bytes": size, "mode": "0644"},
            "actual lineage bound " + key,
        )
    reviewed = validate_source_review(original_review)
    s.require(
        receipt["original_review_reader_STOP"] == reviewed["reader_STOP"]
        and receipt["original_review_verdict"] == original_review["verdict"]
        and composite["reviewed_module_SHA256"] == MODULE_SHA
        and composite["module_SHA256"] == CURRENT_MODULE_SHA
        and composite["composite_SHA256"] == COMPOSITE_SHA
        and composite["mechanical_derivation_SHA256"] == DERIVATION_SHA
        and receipt["producer_derivative_binding"]["sha256"] == derivation["binding_SHA256"],
        "original review, mechanical proof and current composite relationships",
    )
    stopped(receipt["actual_source_reader_STOP"])
    s.require(receipt["hardware_reservation"] == "NONE", "lineage has no hardware reservation")
    rows = receipt["current_source_identities"]
    expected_paths = [
        "/workspaces/quoridor/crates/quoridor-runner/src/value_search_compare.rs",
        "/workspaces/quoridor/.worktree/value-search-strength-arena355/"
        "crates/quoridor-runner/src/value_search_compare.rs",
    ]
    s.require(
        rows
        == [
            {"path": path, "sha256": CURRENT_MODULE_SHA, "bytes": 53274, "mode": "0644"}
            for path in expected_paths
        ],
        "current Main/OWN source identities",
    )
    return {
        "lineage_SHA256": LINEAGE_SHA,
        "module_SHA256": CURRENT_MODULE_SHA,
        "reviewed_module_SHA256": MODULE_SHA,
        "original_review_reader_STOP": reviewed["reader_STOP"],
        "actual_source_reader_STOP": receipt["actual_source_reader_STOP"],
        "independently_reviewed_current_bytes": False,
        "numeric_READY": False,
    }
