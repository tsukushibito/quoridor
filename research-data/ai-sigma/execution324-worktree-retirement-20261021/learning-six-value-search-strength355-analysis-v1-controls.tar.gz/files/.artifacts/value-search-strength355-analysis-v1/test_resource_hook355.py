"""Only newly changed resource hook and v4 failure/order discriminators."""

import copy
import unittest
from unittest import mock

import failure355
import io355 as io
import producer355 as producer
import stream355 as stream
import whole_support355 as whole


def failed():
    stats = dict.fromkeys(producer.STATS_FIELDS, 0)
    stats["nodes"] = 2000001
    census = {
        "admitted_attempts": 1,
        "actual_Search_invocations": 1,
        "Ok_returns": 1,
        "Err_returns": 0,
        "nodes_or_unknown_liability": 2000000,
        "tree_expanded_leaf_nodes": 0,
        "actual_common_leaf_evaluator_calls": 0,
        "last_attempt": {"root": "SYNTHETIC", "invoked": True},
        "current_return": {
            "status": "RETURNED_UNVALIDATED",
            "return_kind": "Ok",
            "selected_action": 13,
            "PV": [13, 14],
            "nodes": 2000001,
            "value_stm": 0.25,
            "value_stm_f32_bits": 1048576000,
            "full_invocation_stats": stats,
            "validation_failed": True,
        },
        "validation_errors": [{"text": "synthetic over-admission"}],
    }
    return {
        "status": "FAILED",
        "original_error": {"text": "synthetic primary"},
        "remaining_planned": "UNKNOWN",
        "matched_census": census,
        "stronger_census": copy.deepcopy(census),
        "durable_outputs": [],
        "current_context": {"provenance": "SYNTHETIC"},
        "current_publication": {"published": None, "known_observation": {"value_stm": 0.25}},
        "whole_phase_until_failure_seconds": 0.1,
    }


class ChangedResourceEntry(unittest.TestCase):
    def test_actual_whole_hook_and_historical_source_refusal(self):
        path = whole.BASE / "resources-whole-v3.json"
        result = io.stopped_support(path, whole.FIXED[path.name])
        self.assertTrue(result["whole_storage_supported"])
        self.assertFalse(result["numeric_READY"])
        self.assertEqual(result["whole_gap_B"], 0)
        old = whole.BASE / "resources-source-corrected-v2.json"
        with self.assertRaises(ValueError):
            io.stopped_support(old, io.identity(old)["SHA256"])
        with self.assertRaises(ValueError):
            io.stopped_support(path, "0" * 64)

    def test_failed_over_admission_preserves_unvalidated_full_work_and_bits(self):
        raw = failed()
        result = failure355.consume(raw, {"SHA256": "1" * 64, "bytes": 1000, "mode": "0600"})
        capture = result["censuses"]["matched"]
        self.assertEqual(capture["known_current_return"]["nodes"], 2000001)
        self.assertEqual(capture["known_current_return"]["value_stm_f32_bits"], 1048576000)
        self.assertFalse(capture["accepted_success"])
        self.assertTrue(capture["do_not_add_current_return_to_durable_rows"])
        self.assertEqual(result["current_publication"]["known_observation"]["value_stm"], 0.25)
        self.assertIn("UNKNOWN", result["unpublished_ALLlegal_hierarchy"])

    def test_engine_error_and_publication_facts_not_replaced_or_invented(self):
        raw = failed()
        c = raw["matched_census"]
        c.update(Ok_returns=0, Err_returns=1)
        c["current_return"] = {
            "status": "UNKNOWN",
            "return_kind": "Err",
            "original_error": {"text": "synthetic distinct engine Err"},
        }
        result = failure355.consume(raw, {"SHA256": "1" * 64, "bytes": 1000, "mode": "0644"})
        self.assertEqual(result["original_error"]["text"], "synthetic primary")
        capture = result["censuses"]["matched"]
        self.assertEqual(
            capture["known_current_return"]["original_error"]["text"],
            "synthetic distinct engine Err",
        )
        self.assertNotIn("nodes", capture["known_current_return"])
        self.assertEqual(capture["available_raw"]["validation_errors"], c["validation_errors"])
        for ref in (
            {"SHA256": "1" * 64, "bytes": 1048577, "mode": "0644"},
            {"SHA256": "1" * 64, "bytes": 1000, "mode": "0777"},
        ):
            with self.assertRaises(ValueError):
                failure355.consume(raw, ref)
        bad = copy.deepcopy(raw)
        bad["matched_census"]["Ok_returns"] = True
        with self.assertRaises(ValueError):
            failure355.consume(bad, {"SHA256": "1" * 64, "bytes": 1000, "mode": "0644"})

    def test_qualification_refuses_before_outcome_read_or_bootstrap(self):
        index = {"book": "book", "schedule": "schedule", "engineering_qualification": "q"}
        inputs = mock.Mock()
        inputs.get.side_effect = [{"compiled_sources": {}}, []]
        inputs.refs = {"book": {"SHA256": "1" * 64}, "schedule": {"SHA256": "2" * 64}}
        book = {"source_book_SHA256": "1" * 64}
        primary = RuntimeError("synthetic unqualified current image")
        with (
            mock.patch.object(stream.s, "adapt_generated_book", return_value=book),
            mock.patch.object(stream.s, "adapt_schedule", return_value={}),
            mock.patch.object(stream, "verify_engineering_qualification", side_effect=primary),
            mock.patch.object(stream.s, "aggregate_games") as aggregate,
        ):
            with self.assertRaises(RuntimeError) as caught:
                stream.analyze_index(index, inputs, {})
        self.assertIs(caught.exception, primary)
        aggregate.assert_not_called()
        inputs.lines.assert_not_called()
