"""Engineering v4 bounded failure evidence; never promote unvalidated returns."""

import producer355 as producer
import strength355 as s


def consume(raw, raw_ref):
    s.require(
        raw["status"] == "FAILED" and raw["remaining_planned"] == "UNKNOWN",
        "failed producer signature",
    )
    s.sha(raw_ref["SHA256"])
    s.integer(raw_ref["bytes"], 0, 1048576)
    s.require(raw_ref["mode"] in ("0600", "0644"), "actual failure mode")
    s.require(type(raw["original_error"]) is dict, "originating producer error")
    s.require(s.finite(raw["whole_phase_until_failure_seconds"]) >= 0, "failure phase domain")
    censuses = {}
    for stage in ("matched", "stronger"):
        census = raw[stage + "_census"]
        for field in (
            "admitted_attempts",
            "actual_Search_invocations",
            "Ok_returns",
            "Err_returns",
            "nodes_or_unknown_liability",
            "tree_expanded_leaf_nodes",
            "actual_common_leaf_evaluator_calls",
        ):
            s.integer(census[field])
        returned = census["current_return"]
        if returned is not None:
            s.require(type(returned) is dict, "partial return envelope")
            stats = returned.get("full_invocation_stats")
            if stats is not None:
                s.require(set(stats) == producer.STATS_FIELDS, "available full work fields")
                for value in stats.values():
                    s.integer(value)
            if returned.get("value_stm") is not None:
                s.finite(returned["value_stm"])
            if returned.get("value_stm_f32_bits") is not None:
                s.integer(returned["value_stm_f32_bits"], 0, (1 << 32) - 1)
        s.require(type(census["validation_errors"]) is list, "validation errors independent")
        # Failed over-admission/restoration/publication may expose work beyond a
        # prior reservation. Retain it; do not fabricate a complete result or
        # reject the evidence merely for honestly reporting a failed allowance.
        censuses[stage] = {
            "available_raw": census,
            "accepted_success": False,
            "known_current_return": returned,
            "unavailable_counter_work": "UNKNOWN",
            "do_not_add_current_return_to_durable_rows": True,
        }
    return {
        "status": "FAILED_UNADMITTED",
        "raw_ref": raw_ref,
        "original_error": raw["original_error"],
        "censuses": censuses,
        "available_durable_refs": raw["durable_outputs"],
        "current_context": raw["current_context"],
        "current_publication": raw["current_publication"],
        "whole_phase_until_failure_seconds": raw["whole_phase_until_failure_seconds"],
        "raw_available_failure": raw,
        "unpublished_ALLlegal_hierarchy": "UNKNOWN; original partial file retained, no reconstruction/replay",
        "external_controller_and_primary_secondary_capture": "separate actual maintained receipts required",
    }
