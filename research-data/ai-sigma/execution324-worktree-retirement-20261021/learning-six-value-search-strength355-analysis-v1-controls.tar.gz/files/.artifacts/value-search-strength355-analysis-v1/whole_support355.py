"""Disjoint355 resource-control supplement; no old frozen source mutation.

This consumes the actual issued whole proof, which has a different schema from
the historical SOURCE_ONLY proof. Allocation is never source/image/data clear.
"""

import hashlib
import json
from pathlib import Path

BASE = Path("/workspaces/quoridor/research-data/ai-sigma/value-search-strength355")
FIXED = {
    "resources-whole-v3.json": "bd28800ea89d83e6cae9eb4dc8f20334fadc4d7987dd8b859bc7cc0089bc0676",
    "settled-retention-v1.json": "3a690b710bc6aa3f851ff9ba40f4e901c09b375459ac20477e831d8d50afd3f9",
    "joint-raw-price-v2.json": "56b3a2472c805b7259acfbe63b50804951aced3e8361e843acc5e4b84d7e78fd",
}
COMPONENTS = {
    "source": 64,
    "build_target": 1024,
    "private": 32,
    "input": 32,
    "arena": 1536,
    "raw": 256,
    "controls": 64,
    "review": 64,
    "Root_Git": 64,
    "TMP": 512,
    "failure": 128,
    "cleanup": 64,
    "analysis": 256,
}
RAW = {
    "engineering_rows_trees": 164,
    "arena16_batches_3_logs_each_1MiB": 48,
    "affected_software_logs": 16,
    "generation_materialization_logs": 8,
    "raw_headers_refs_dirs": 12,
    "raw_failure_refusal_reserve": 8,
}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def exact_int(value, expected, reason):
    need(type(value) is int and value == expected, reason)


def validate(whole, settled, raw):
    need(
        whole["schema"] == "quoridor.value-search-strength.whole-support.v1"
        and settled["schema"] == "quoridor.value-search-strength.scoped-settled-retention.v1"
        and raw["schema"] == "quoridor.value-search-strength.joint-prospective-raw-price.v1",
        "actual whole/settlement/overlay schemas",
    )
    need(all(x["issue"] == "quoridor-4lc.355" for x in (whole, settled, raw)), "same task scope")
    exact_int(whole["whole355_including_initial_B"], 4294967296, "single whole4GiB")
    exact_int(
        whole["initial_source_inclusive_ALREADY_ISSUED_B"], 134217728, "initial128MiB included"
    )
    exact_int(whole["new_additional_inclusive_whole_B"], 4160749568, "additional remainder")
    need(whole["current_source_prep_uppers_included_not_added"] is True, "no source double grant")
    need(whole["old_resources_reused_as_science_budget"] is False, "no historical borrowing")
    need(set(whole["whole_components_B"]) == set(COMPONENTS), "exact whole component census")
    for name, mib in COMPONENTS.items():
        exact_int(whole["whole_components_B"][name], mib * 1048576, "component " + name)
    exact_int(sum(whole["whole_components_B"].values()), 4294967296, "whole sum")
    exact_int(settled["total_reduction_B"], 1894617088, "actual scoped settlement")
    exact_int(settled["old_global_held_B"], 47710072832, "historical held baseline")
    exact_int(settled["after_settled_global_held_B"], 45815455744, "settled held baseline")
    exact_int(
        whole["after_settlement_held_B"], settled["after_settled_global_held_B"], "same settlement"
    )
    exact_int(whole["settled_reduction_B"], settled["total_reduction_B"], "same reduction")
    exact_int(whole["new_global_held_B"], 49976205312, "current whole held")
    exact_int(whole["supported_margin_B"], 23794688, "decimal50GB margin")
    exact_int(whole["decimal_cap_B"], 50000000000, "decimal cap")
    need(
        whole["after_settlement_held_B"] + whole["new_additional_inclusive_whole_B"]
        == whole["new_global_held_B"]
        and whole["new_global_held_B"] + whole["supported_margin_B"] == whole["decimal_cap_B"],
        "prospective arithmetic",
    )
    need(set(raw["joint_prospective_caps_MiB"]) == set(RAW), "shared raw domains")
    for name, mib in RAW.items():
        exact_int(raw["joint_prospective_caps_MiB"][name], mib, "raw " + name)
    exact_int(raw["raw_total_B"], 268435456, "shared raw256MiB")
    exact_int(sum(raw["joint_prospective_caps_MiB"].values()), 256, "shared raw sum")
    exact_int(raw["new_arena_per_log_upper_B"], 1048576, "each3logs per16batches1MiB")
    # Overlay disposition was frozen before whole issuance. Its historical
    # runtime_issued=false is NOT rewritten or used to revoke the later proof.
    return {
        "whole_storage_supported": True,
        "numeric_READY": False,
        "whole_gap_B": 0,
        "global_held_B": 49976205312,
        "margin_B": 23794688,
        "single_common_build_target_B": 1073741824,
        "single_common_private_B": 33554432,
        "arena_per_log_B": 1048576,
        "raw_shared_B": 268435456,
        "input_source_image_review_physical_peer_fair_qualifications": "PENDING actual scopes",
        "exclusive_physical_free_bytes": "UNKNOWN",
    }


def consume():
    """Small exact named metadata only; no deleted target or payload reads."""
    documents, refs = {}, []
    for name, expected in FIXED.items():
        path = BASE / name
        need(not path.is_symlink() and path.stat().st_size <= 65536, "bounded canonical metadata")
        need(path.stat().st_mode & 511 == 0o644, "exact metadata mode")
        data = path.read_bytes()
        need(hashlib.sha256(data).hexdigest() == expected, "actual fixed metadata hash")
        documents[name] = json.loads(data)
        refs.append({"path": str(path), "SHA256": expected, "bytes": len(data), "mode": "0644"})
    return validate(*(documents[name] for name in FIXED)), refs
