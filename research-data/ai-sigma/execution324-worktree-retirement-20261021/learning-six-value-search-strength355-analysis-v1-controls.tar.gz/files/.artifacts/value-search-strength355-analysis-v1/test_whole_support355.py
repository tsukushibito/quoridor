"""New stdlib resource discriminators, no science inputs or old suite replay."""

import copy
import json
import unittest

import whole_support355 as control


class WholeSupport(unittest.TestCase):
    def documents(self):
        return [json.loads((control.BASE / name).read_bytes()) for name in control.FIXED]

    def test_actual_issued_whole_is_not_numeric_ready(self):
        result, refs = control.consume()
        self.assertEqual(len(refs), 3)
        self.assertTrue(result["whole_storage_supported"])
        self.assertFalse(result["numeric_READY"])
        self.assertEqual(result["exclusive_physical_free_bytes"], "UNKNOWN")
        self.assertEqual(result["whole_gap_B"], 0)
        self.assertFalse(self.documents()[2]["runtime_issued"])  # immutable earlier overlay

    def test_double_grant_bool_and_settlement_mismatch_refuse(self):
        original = self.documents()
        for key, wrong in [
            ("new_additional_inclusive_whole_B", 4294967296),
            ("supported_margin_B", True),
            ("after_settlement_held_B", 47710072832),
            ("new_global_held_B", 50000000001),
        ]:
            docs = copy.deepcopy(original)
            docs[0][key] = wrong
            with self.assertRaises(ValueError):
                control.validate(*docs)
        docs = copy.deepcopy(original)
        docs[0]["whole_components_B"]["build_target"] *= 2
        with self.assertRaises(ValueError):
            control.validate(*docs)

    def test_three_logger_overlay_and_extra_raw_domains_fail_closed(self):
        original = self.documents()
        for wrong in (2097152, True):
            docs = copy.deepcopy(original)
            docs[2]["new_arena_per_log_upper_B"] = wrong
            with self.assertRaises(ValueError):
                control.validate(*docs)
        docs = copy.deepcopy(original)
        docs[2]["joint_prospective_caps_MiB"]["extra_cache_credit"] = -4
        with self.assertRaises(ValueError):
            control.validate(*docs)
        docs = copy.deepcopy(original)
        docs[2]["joint_prospective_caps_MiB"]["arena16_batches_3_logs_each_1MiB"] = 96
        with self.assertRaises(ValueError):
            control.validate(*docs)
