"""New metadata-only current-derivative/inherited-review discriminators."""

import copy
import json
from pathlib import Path
import unittest
from unittest import mock

import composite355 as c
import io355
import stream355

ROOT = Path("/workspaces/quoridor/research-data/ai-sigma/value-search-strength355")
COMPOSITE = ROOT / "composite-source-STOP-v2.json"
DERIVATION = ROOT / "mechanical-lint-integration-v2.json"
REVIEW = Path(
    "/workspaces/quoridor/.worktree/learning-million/.artifacts/value-search-strength355-review-v1/compare-related-v4/control.json"
)


class MechanicalReceipt(unittest.TestCase):
    def setUp(self):
        self.composite = json.loads(COMPOSITE.read_bytes())
        self.derivation = json.loads(DERIVATION.read_bytes())
        self.identity = io355.identity(COMPOSITE)
        self.edge_identity = io355.identity(DERIVATION)

    def validate(self, composite=None, derivation=None):
        return c.validate_composite(
            self.composite if composite is None else composite,
            self.identity,
            self.derivation if derivation is None else derivation,
            self.edge_identity,
        )

    def test_current_derivative_preserves_original_review_and_pending_runtime(self):
        result = self.validate()
        self.assertEqual(result["module_SHA256"], c.CURRENT_MODULE_SHA)
        self.assertEqual(result["reviewed_module_SHA256"], c.MODULE_SHA)
        review = json.loads(REVIEW.read_bytes())
        c.validate_source_review(review, result["reviewed_module_SHA256"])
        with self.assertRaises(ValueError):
            c.validate_source_review(review, result["module_SHA256"])
        retargeted = copy.deepcopy(review)
        retargeted["module_sha256"] = c.CURRENT_MODULE_SHA
        with self.assertRaises(ValueError):
            c.validate_source_review(retargeted, c.CURRENT_MODULE_SHA)
        self.assertFalse(result["image_private_book_input_qualified"])

    def test_wrong_edge_copied_booleans_counts_and_reader_census_refuse(self):
        mutations = [
            ("before_SHA256", c.CURRENT_MODULE_SHA),
            ("after_SHA256", c.MODULE_SHA),
            ("bytes", 53305),
            ("strict_forward_inverse", 1),
            ("entire_test_module_byte_unchanged", 1),
        ]
        for key, value in mutations:
            bad = copy.deepcopy(self.derivation)
            bad["changes"][1][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.validate(derivation=bad)
        for key, value in [
            ("only_three_declared_hunks", 1),
            ("all_nineteen_test_definitions_byte_identical", 1),
            ("owned_readers_children_jobs_TMP", ["pending"]),
            ("actual_root_source_writer_STOP", "2026-10-10T00:25:28"),
        ]:
            bad = copy.deepcopy(self.derivation)
            bad[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.validate(derivation=bad)

    def test_map_and_mechanical_link_drift_refuse(self):
        for name in ("copied_changed_source", "source_build_inputs"):
            bad = copy.deepcopy(self.composite)
            if name == "copied_changed_source":
                bad[name][1]["after_SHA256"] = c.MODULE_SHA
            else:
                row = next(
                    r for r in bad[name] if r["relative_path"].endswith("value_search_compare.rs")
                )
                row["Main_SHA256"] = row["owned_SHA256"] = c.MODULE_SHA
            with self.subTest(name=name), self.assertRaises(ValueError):
                self.validate(composite=bad)
        wrong_identity = {**self.edge_identity, "SHA256": "0" * 64}
        with self.assertRaises(ValueError):
            c.validate_composite(self.composite, self.identity, self.derivation, wrong_identity)

    def test_live_entry_refuses_bad_edge_before_book_or_science_reads(self):
        inputs = mock.Mock()
        inputs.refs = {
            "composite": {**self.identity, "path": str(COMPOSITE)},
            "edge": {**self.edge_identity, "path": str(DERIVATION)},
        }
        bad = copy.deepcopy(self.derivation)
        bad["only_three_declared_hunks"] = 1
        inputs.get.side_effect = [self.composite, bad]
        with self.assertRaises(ValueError):
            stream355.analyze_index(
                {"composite_source": "composite", "mechanical_source_derivation": "edge"},
                inputs,
                {},
            )
        self.assertEqual(
            inputs.get.call_args_list, [mock.call("composite", 65536), mock.call("edge", 16384)]
        )
