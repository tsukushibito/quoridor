"""New real-source-receipt and common-source metadata discriminators only."""

import copy
import json
from pathlib import Path
import unittest
from unittest import mock

import composite355 as c
import io355
import stream355

COMPOSITE = Path(
    "/workspaces/quoridor/research-data/ai-sigma/value-search-strength355/composite-source-STOP-v1.json"
)
REVIEW = Path(
    "/workspaces/quoridor/.worktree/learning-million/.artifacts/value-search-strength355-review-v1/compare-related-v4/control.json"
)


class CompositeReceipt(unittest.TestCase):
    def test_actual_named_source_receipts_do_not_qualify_images(self):
        raw = json.loads(COMPOSITE.read_bytes())
        result = c.validate_composite(raw, io355.identity(COMPOSITE))
        self.assertFalse(result["image_private_book_input_qualified"])
        review = c.validate_source_review(json.loads(REVIEW.read_bytes()), result["module_SHA256"])
        self.assertTrue(review["source_scope_clear"])
        self.assertFalse(review["numeric_READY"])
        self.assertEqual(review["reader_STOP"], "2026-10-09T23:52:32.398836+00:00")

    def test_target_module_stop_and_boolean_finding_drift_refuse(self):
        original = json.loads(REVIEW.read_bytes())
        for key, value in [
            ("blockers", False),
            ("ordinary", 0.0),
            ("module_sha256", "0" * 64),
            ("fixed_target_SHA256", "1" * 64),
            ("status", "PASS"),
            ("reader_STOP", "2026-10-09T23:52:32"),
            ("owned_children", ["pending"]),
        ]:
            bad = copy.deepcopy(original)
            bad[key] = value
            with self.assertRaises(ValueError):
                c.validate_source_review(bad)
        raw = json.loads(COMPOSITE.read_bytes())
        raw["source_build_inputs"][0]["owned_SHA256"] = "0" * 64
        with self.assertRaises(ValueError):
            c.validate_composite(raw, io355.identity(COMPOSITE))

    def test_actual_source_receipt_fields_are_used_in_qualification_branch(self):
        source = json.loads(REVIEW.read_bytes())
        q = {
            "schema": "quoridor.value-search-strength.compare-qualification.v1",
            "book_sha256": "1" * 64,
            "canonical_plan_sha256": stream355.s.PLAN_SHA,
            "executable_sha256": "2" * 64,
            "compiled_sources_sha256": "3" * 64,
            "generation_compiled_sources_sha256": "4" * 64,
            "source_review": {"path": str(REVIEW), "sha256": c.REVIEW_SHA},
            "software_receipt": {"path": "/SYNTHETIC/software", "sha256": "5" * 64},
            "input_receipt": {"path": "/SYNTHETIC/input", "sha256": "6" * 64},
            "manifests_sha256": c.MANIFESTS,
            "weights_sha256": c.WEIGHTS,
        }
        software = {
            "status": "PASS",
            "remaining": [],
            "actual_STOP": "2026-10-10T00:00:00+00:00",
            "executable_sha256": "2" * 64,
            "compiled_sources_sha256": "3" * 64,
        }
        input_receipt = {
            **software,
            "book_sha256": "1" * 64,
            "manifests_sha256": q["manifests_sha256"],
            "weights_sha256": q["weights_sha256"],
        }
        stub = mock.Mock()
        stub.refs = {
            "source": {"path": str(REVIEW), "SHA256": c.REVIEW_SHA},
            "software": {"path": "/SYNTHETIC/software", "SHA256": "5" * 64},
            "input": {"path": "/SYNTHETIC/input", "SHA256": "6" * 64},
        }
        stub.get.side_effect = [q, source, software, input_receipt]
        result = stream355.verify_engineering_qualification(
            stub, "q", {"source_book_SHA256": "1" * 64}
        )
        self.assertIs(result, q)
        self.assertEqual(stub.get.call_count, 4)
        bad = copy.deepcopy(source)
        bad["source_clear"] = 1
        stub.get.side_effect = [q, bad]
        with self.assertRaises(ValueError):
            stream355.verify_engineering_qualification(stub, "q", {"source_book_SHA256": "1" * 64})

    def test_unresolved_native_template_and_changed_model_are_not_live_qualification(self):
        path = Path(
            "/workspaces/quoridor/.worktree/value-search-strength-engineering355/.artifacts/value-search-strength355/native-qualification-template-v5.json"
        )
        q = json.loads(path.read_bytes())
        stub = mock.Mock()
        stub.get.return_value = q
        with self.assertRaises(ValueError):
            stream355.verify_engineering_qualification(stub, "q", {"source_book_SHA256": "1" * 64})
        live_shape = copy.deepcopy(q)
        live_shape.update(
            book_sha256="1" * 64,
            executable_sha256="2" * 64,
            compiled_sources_sha256="3" * 64,
            generation_compiled_sources_sha256="4" * 64,
        )
        live_shape["manifests_sha256"][1] = "f" * 64
        stub.get.return_value = live_shape
        with self.assertRaises(ValueError):
            stream355.verify_engineering_qualification(stub, "q", {"source_book_SHA256": "1" * 64})
        self.assertEqual(stub.get.call_count, 2)  # both before receipt/input reads
