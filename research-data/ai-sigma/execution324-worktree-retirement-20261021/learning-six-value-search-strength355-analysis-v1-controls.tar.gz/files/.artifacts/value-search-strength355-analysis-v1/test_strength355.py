"""New synthetic NN0 discriminators, never legal geometry or campaign results."""

import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import strength355 as s
import io355 as boundary
import producer355 as producer
import stream355 as streamed


def synthetic_book():
    families = []
    for fid in range(128):
        length = (4, 8, 12, 16)[fid // 32]
        prefix = [fid] * (length - 1) + [208 - fid]
        history = [["synthetic-common-initial", 1]] + [
            [f"synthetic-{fid}-{n}", 1] for n in range(length)
        ]
        families.append(
            {
                "family_id": fid,
                "attempt_id": 0,
                "root_key": history[-1][0],
                "prefix": prefix,
                "prefix_SHA256": s.digest(prefix),
                "counted_history": history,
                "history_SHA256": s.digest(history),
                "terminal": False,
                "current_rules": "standard_2p_threefold_goal_first",
                "lineage": {
                    "shared_root": "SYNTHETIC-common-initial",
                    "family_seed": 35520261009 + 8 * fid,
                },
            }
        )
    return {
        "schema": "quoridor.strength355.full-history-book.v1",
        "plan_SHA256": s.PLAN_SHA,
        "provenance": "SYNTHETIC",
        "source_book_SHA256": "9" * 64,
        "families": families,
    }


def synthetic_schedule(book):
    return {
        "schema": "quoridor.strength355.schedule.v1",
        "plan_SHA256": s.PLAN_SHA,
        "book_SHA256": s.check_book(book),
        "source_book_SHA256": book["source_book_SHA256"],
        "source_schedule_SHA256": "8" * 64,
        "slots": s.planned_slots(),
    }


def observation(ply, colour, accepted=True, late=False):
    begin = 1 + ply * 1000000
    returned = begin + (100000001 if late else 1000)
    accepted_at = returned + 100 if accepted else None
    return {
        "ply": ply,
        "side": ply % 2,
        "engine_index": 0 if ply % 2 == colour else 1,
        "caller_started_ns": begin,
        "returned_ns": returned,
        "deadline_ns": begin + 100000000,
        "admission_checked_ns": returned + 100,
        "accepted_ns": accepted_at,
        "thinking_seconds": (returned - begin) / 1e9,
        "accepted": accepted,
        "failure": None if accepted else "late",
        "engine_error": None,
        "action": 13,
        "completed_depth": 4,
        "pv": [13],
        "value_stm": 0.25,
        "counters": {
            "authority_receipt_ns": returned,
            "drain_finished_ns": returned,
            "clock_contract": "authority-action-receipt-v1",
            "clock_contract_sha256": "1" * 64,
            "completed_snapshot_validation_failed": False,
            "state_commit_ns": accepted_at,
            "nodes": 10,
        },
    }


def game(book, schedule, slot_id, score=1, unknown=None):
    slot = schedule["slots"][slot_id]
    family = book["families"][slot["family_id"]]
    length = len(family["prefix"])
    colour = slot["candidate_colour"]
    winner = colour if score == 1 else colour ^ 1
    number = 1 if winner == length % 2 else 2
    obs = [observation(length + n, colour) for n in range(number)]
    if unknown:
        obs = []
    return {
        "slot": slot,
        "schedule_SHA256": s.digest(schedule),
        "prefix_SHA256": family["prefix_SHA256"],
        "history_SHA256": family["history_SHA256"],
        "provenance": "SYNTHETIC",
        "outcome": {
            "started": not bool(unknown),
            "status": "unknown" if unknown else "goal",
            "winner": None if unknown else winner,
            "reason": unknown or "goal",
            "failure": unknown,
            "observations": obs,
            "moves": family["prefix"] + [13] * len(obs),
            "plies": length + len(obs),
        },
        "search_seconds": None if unknown else 0.01,
        "setup_search_drop_seconds": None if unknown else 0.02,
        "whole_phase_seconds": None,
    }


def search_row(book, fid, evaluator, action=13, depth=4, status="COMPLETE"):
    family = book["families"][fid]
    return {
        "family_id": fid,
        "evaluator": evaluator,
        "history_SHA256": family["history_SHA256"],
        "prefix_SHA256": family["prefix_SHA256"],
        "requested_depth": depth,
        "deepest_completed": depth if status == "COMPLETE" else depth - 1,
        "status": status,
        "complete_requested": status == "COMPLETE",
        "bound": "EXACT",
        "legal_action": True,
        "action": action,
        "pv": [action],
        "value_stm": 0.25,
        "nodes": 10,
        "value_perspective": "PARENT_STM",
        "score_units": "legacy-tanh-search-terminal2",
        "search_seconds": 0.01,
        "setup_search_drop_seconds": 0.02,
        "primary_error": None,
    }


def matched(book):
    rows = []
    for fid in s.MATCHED_IDS:
        for engine in s.EVALUATORS:
            action = {"D": 13, "BEST51": 14, "BEST43": 15}[engine] if fid <= 40 else 13
            rows.append(search_row(book, fid, engine, action))
    return {"book_SHA256": s.check_book(book), "rows": rows}


def common_tree():
    def values(v):
        return {e: v for e in s.EVALUATORS}

    nodes = [
        {
            "node_id": 0,
            "parent": None,
            "ply": 0,
            "values_stm": values(0.3),
            "legal_actions": [13, 14],
            "children": [{"action": 13, "node_id": 1}, {"action": 14, "node_id": 2}],
            "terminal_proof": None,
        },
        {
            "node_id": 1,
            "parent": 0,
            "ply": 1,
            "values_stm": values(-0.1),
            "legal_actions": [67],
            "children": [{"action": 67, "node_id": 3}],
            "terminal_proof": None,
        },
        {
            "node_id": 2,
            "parent": 0,
            "ply": 1,
            "values_stm": values(-0.3),
            "legal_actions": [68],
            "children": [{"action": 68, "node_id": 4}],
            "terminal_proof": None,
        },
    ]
    for node_id, parent, v in ((3, 1, 0.1), (4, 2, 0.3)):
        nodes.append(
            {
                "node_id": node_id,
                "parent": parent,
                "ply": 2,
                "values_stm": values(v),
                "legal_actions": [],
                "children": [],
                "terminal_proof": None,
            }
        )
    return {
        "family_id": 0,
        "requested_depth": 2,
        "status": "COMPLETE",
        "expanded_plus_leaf_nodes": 5,
        "ALL_legal": True,
        "missing_responses": 0,
        "root_values": values(0.3),
        "terminal_proofs": [],
        "nodes": nodes,
    }


class NewBoundaries(unittest.TestCase):
    def setUp(self):
        self.book = synthetic_book()
        self.schedule = synthetic_schedule(self.book)

    def test_fixed_counts_parity_local_global_are_distinct(self):
        slots = self.schedule["slots"]
        self.assertEqual(len(slots), 512)
        self.assertEqual(
            (
                slots[64]["matchup"],
                slots[64]["batch_id"],
                slots[64]["family_id"],
                slots[64]["candidate_colour"],
                slots[64]["local_game"],
            ),
            (s.MATCHUPS[1], 2, 16, 1, 0),
        )
        self.assertEqual(slots[96]["matchup"], s.MATCHUPS[0])
        for matchup in s.MATCHUPS:
            for fid in range(128):
                self.assertEqual(
                    sorted(
                        x["candidate_colour"]
                        for x in slots
                        if x["matchup"] == matchup and x["family_id"] == fid
                    ),
                    [0, 1],
                )

    def test_schedule_numeric_bool_alias_and_extension_refuse(self):
        bad = copy.deepcopy(self.schedule)
        bad["slots"][0]["slot_id"] = False
        with self.assertRaises(s.Refusal):
            s.check_schedule(bad, self.book)
        bad = copy.deepcopy(self.schedule)
        bad["slots"].append(bad["slots"][0])
        with self.assertRaises(s.Refusal):
            s.check_schedule(bad, self.book)

    def test_history_missing_count_and_lineage_seed_refuse(self):
        bad = copy.deepcopy(self.book)
        bad["families"][0]["counted_history"].pop()
        bad["families"][0]["history_SHA256"] = s.digest(bad["families"][0]["counted_history"])
        with self.assertRaises(s.Refusal):
            s.check_book(bad)
        bad = copy.deepcopy(self.book)
        bad["families"][127]["lineage"]["family_seed"] += 1
        with self.assertRaises(s.Refusal):
            s.check_book(bad)

    def test_all_missing_preserves_fixed_denominator_and_uncertainty(self):
        out = s.aggregate_games(self.book, self.schedule, [])
        for row in out["matchups"].values():
            self.assertEqual(
                (row["planned_games"], row["UNKNOWN_games"], row["complete_pairs"]), (256, 256, 0)
            )
            self.assertEqual(row["planned_score_missingness_bounds"], [0, 1])
            self.assertIsNone(row["conditional_interval"]["interval"])
        self.assertFalse(out["lineage"]["IID_established"])

    def test_partial_pair_excludes_primary_but_keeps_known_missingness(self):
        rows = [
            game(self.book, self.schedule, 0, 1),
            game(self.book, self.schedule, 1, unknown="engine_error"),
        ]
        out = s.aggregate_games(self.book, self.schedule, rows)["matchups"][s.MATCHUPS[0]]
        self.assertEqual(out["complete_pairs"], 0)
        self.assertEqual(out["planned_score_missingness_bounds"], [1 / 256, 1])
        self.assertEqual(out["UNKNOWN_games"], 255)

    def test_colour_not_raw_winner_and_draw_not_cap(self):
        record = game(self.book, self.schedule, 1, 1)
        score, _, _ = s.check_game(record, record["slot"], self.book, s.digest(self.schedule))
        self.assertEqual(score, 1)
        record["outcome"]["status"] = "draw"
        record["outcome"]["reason"] = "ply_cap"
        record["outcome"]["winner"] = None
        with self.assertRaises(s.Refusal):
            s.check_game(record, record["slot"], self.book, s.digest(self.schedule))

    def test_late_accepted_and_failed_state_commit_refuse(self):
        record = game(self.book, self.schedule, 0)
        record["outcome"]["observations"][0] = observation(4, 0, True, True)
        with self.assertRaises(s.Refusal):
            s.check_game(record, record["slot"], self.book, s.digest(self.schedule))
        record = game(self.book, self.schedule, 0)
        record["outcome"]["observations"][0]["counters"]["state_commit_ns"] = 1
        with self.assertRaises(s.Refusal):
            s.check_game(record, record["slot"], self.book, s.digest(self.schedule))

    def test_synthetic_relabel_duplicate_and_parent_forgery_refuse(self):
        record = game(self.book, self.schedule, 0)
        record["provenance"] = "ACTUAL_GENERATED"
        with self.assertRaises(s.Refusal):
            s.aggregate_games(self.book, self.schedule, [record])
        record = game(self.book, self.schedule, 0)
        with self.assertRaises(s.Refusal):
            s.aggregate_games(self.book, self.schedule, [record, record])
        record["history_SHA256"] = "2" * 64
        with self.assertRaises(s.Refusal):
            s.aggregate_games(self.book, self.schedule, [record])

    def test_bootstrap_fixed_seed_resamples_and_two_tail_interval(self):
        out = s.bootstrap([0, 1])
        self.assertEqual(out["interval"], [0, 1])
        self.assertEqual(
            (out["confidence"], out["resamples"], out["seed"]), (0.975, 10000, 35520261010)
        )
        with self.assertRaises(s.Refusal):
            s.bootstrap([float("nan")])

    def test_partial_depth_is_unknown_not_rescued(self):
        row = search_row(self.book, 0, "BEST51", depth=4, status="INCOMPLETE")
        self.assertFalse(s.complete_depth(row, 4))
        row["status"] = "COMPLETE"
        row["complete_requested"] = True
        with self.assertRaises(s.Refusal):
            s.complete_depth(row, 4)

    def test_first_differences_and_union_before_stronger(self):
        out = s.check_matched(self.book, matched(self.book))
        self.assertEqual(
            [x["family_id"] for x in out["selection"]["first_differences"]["BEST51"]],
            list(range(0, 32, 4)),
        )
        self.assertTrue(all(x["actions"] == [13, 14, 15] for x in out["selection"]["unions"]))
        selection = {"content": out["selection"], "content_SHA256": s.digest(out["selection"])}
        stronger = {
            "stage_events": [
                {"kind": "MATCHED_STOP", "sequence": 0},
                {
                    "kind": "SELECTION_FSYNC",
                    "sequence": 1,
                    "selection_SHA256": selection["content_SHA256"],
                },
            ],
            "rows": [],
        }
        checked = s.check_stronger(out, selection, stronger)
        self.assertEqual(checked["unentered_calls"], 96)
        stronger["stage_events"][1]["sequence"] = -1
        with self.assertRaises(s.Refusal):
            s.check_stronger(out, selection, stronger)

    def test_game_loss_or_reselected_parent_cannot_change_selection(self):
        out = s.check_matched(self.book, matched(self.book))
        content = copy.deepcopy(out["selection"])
        content["first_differences"]["BEST51"][0]["family_id"] = 44
        with self.assertRaises(s.Refusal):
            s.check_stronger(
                out,
                {"content": content, "content_SHA256": s.digest(content)},
                {"stage_events": [], "rows": []},
            )

    def test_alllegal_response_minimax_and_exact_terminal_distinct(self):
        tree = common_tree()
        self.assertEqual(s.check_tree(tree)["root_values"]["D"], 0.3)
        tree["nodes"][1]["children"] = []
        with self.assertRaises(s.Refusal):
            s.check_tree(tree)
        tree = common_tree()
        tree["nodes"][1]["values_stm"]["D"] = 0.1
        with self.assertRaises(s.Refusal):
            s.check_tree(tree)
        tree = common_tree()
        tree["status"] = "INCOMPLETE"
        tree["reason"] = "node_cap"
        self.assertEqual(s.check_tree(tree)["status"], "UNKNOWN")

    def test_cost_nesting_unknown_does_not_become_zero_or_speed(self):
        out = s.costs({"search_seconds": None, "whole_phase_seconds": 3})
        self.assertIsNone(out["search_seconds"])
        self.assertEqual(out["whole_phase_seconds"], 3)
        with self.assertRaises(s.Refusal):
            s.costs({"search_seconds": 3, "setup_search_drop_seconds": 2})

    def test_finite_duplicate_partial_and_array_json_refuse(self):
        for raw in (b'{"a":NaN}', b'{"a":1e999}', b'{"a":1,"a":2}', b'{"a":'):
            with self.assertRaises(s.Refusal):
                s.strict_json(raw)
        with self.assertRaises(s.Refusal):
            s.strict_json(json.dumps([0] * 1025).encode())

    def test_hash_mode_and_partial_jsonl_refuse_without_consuming_success(self):
        with tempfile.TemporaryDirectory(
            prefix="synthetic-", dir=Path(__file__).parent / "owned-TMP"
        ) as name:
            path = Path(name) / "synthetic.jsonl"
            path.write_bytes(b'{"synthetic":true}\n{')
            ref = boundary.identity(path)
            progress = {"rows_read": 0}
            with self.assertRaises(s.Refusal):
                list(boundary.read_jsonl(path, ref, 128, 2, progress))
            self.assertEqual(progress["rows_read"], 1)
            ref["mode"] = "0000"
            with self.assertRaises(s.Refusal):
                boundary.read_bound(path, ref, 128)

    def test_actual_source_support_refuses_before_output_or_data(self):
        path = boundary.CANONICAL / "resources-source-corrected-v2.json"
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        with self.assertRaisesRegex(s.Refusal, "runtime support NOT ISSUED"):
            boundary.stopped_support(path, sha)

    def test_native_join_uses_batch_metadata_not_local_family(self):
        slot = self.schedule["slots"][64]
        family = self.book["families"][16]
        record = game(self.book, self.schedule, 64)
        raw = {
            "game": 0,
            "family": "synthetic-local-000000",
            "candidate_color": slot["candidate_colour"],
            **record["outcome"],
        }
        native = {
            "game": 0,
            "family": raw["family"],
            "candidate_color": slot["candidate_colour"],
            "opening": family["prefix"],
        }
        settings = {"family_id": 16}
        opening = {"prefix": family["prefix"], "reference": {"settings": settings}}
        config = {
            "ruleset": "standard_2p_threefold",
            "inference": None,
            "inference_cpu_core": None,
            "arena": {"book": {"openings": [opening]}, "return_reserve_ms": 5, "tt_entries": 4096},
            "engines": [
                {
                    "kind": "nnue",
                    "distance_a": 0,
                    "distance_b": 0,
                    "time_ms": 100,
                    "depth": 64,
                    "max_nodes": 1000000,
                },
                {
                    "kind": "distance",
                    "distance_a": 0,
                    "distance_b": 8,
                    "model": None,
                    "time_ms": 100,
                    "depth": 64,
                    "max_nodes": 1000000,
                },
            ],
        }
        normalized = s.adapt_native_game(raw, native, config, slot, self.book, self.schedule)
        self.assertEqual(normalized["slot"]["family_id"], 16)
        settings["family_id"] = 0
        with self.assertRaises(s.Refusal):
            s.adapt_native_game(raw, native, config, slot, self.book, self.schedule)

    def test_exact_terminal_proof_not_goal_zero_or_boolean_draw(self):
        tree = common_tree()
        leaf = tree["nodes"][4]
        leaf["terminal_proof"] = {
            "kind": "goal",
            "rules": "standard_2p_threefold_goal_first",
            "value_stm": 0,
        }
        leaf["values_stm"] = {e: 0 for e in s.EVALUATORS}
        with self.assertRaises(s.Refusal):
            s.check_tree(tree)
        leaf["terminal_proof"]["kind"] = "legal_third_repetition"
        leaf["terminal_proof"]["value_stm"] = False
        with self.assertRaises(s.Refusal):
            s.check_tree(tree)

    def test_failed_packet_and_failed_receipt_keep_primary_and_unadmitted_marker(self):
        with tempfile.TemporaryDirectory(
            prefix="synthetic-publication-", dir=Path(__file__).parent / "owned-TMP"
        ) as name:
            directory = Path(name)
            packet = directory / "malformed.json"
            packet.write_bytes(b"{")
            lock = directory / "owned.lock"
            lock.touch()
            out = directory / "out"
            original = Path.write_bytes

            def fail_receipt(path, data):
                if path.name == "failure.json":
                    raise OSError("synthetic secondary receipt refusal")
                return original(path, data)

            with (
                mock.patch.object(boundary, "LOCK", lock),
                mock.patch.object(
                    boundary, "stopped_support", return_value={"SYNTHETIC_ONLY": True}
                ),
                mock.patch.object(Path, "write_bytes", new=fail_receipt),
            ):
                with self.assertRaises(s.Refusal) as raised:
                    boundary.future_packet_entry(
                        packet,
                        hashlib.sha256(packet.read_bytes()).hexdigest(),
                        directory / "fake-source-only",
                        "1" * 64,
                        out,
                    )
            self.assertIn("partial or malformed JSON", str(raised.exception))
            self.assertTrue(
                any("secondary receipt refusal" in n for n in raised.exception.__notes__)
            )
            self.assertTrue((out / "INCOMPLETE").exists())
            self.assertFalse((out / "summary.json").exists())

    def test_normalized_synthetic_joint_report_never_claims_actual_games(self):
        binding = {
            "book_SHA256": s.check_book(self.book),
            "schedule_SHA256": s.check_schedule(self.schedule, self.book),
        }
        stage = {
            "source_SHA256": "1" * 64,
            "private_SHA256": "2" * 64,
            "qualification_receipt_SHA256": "3" * 64,
            "stopped_input_index_SHA256": "4" * 64,
            "rules": "standard_2p_threefold_goal_first",
            "clock": "authority-action-receipt-v1",
        }
        binding.update(arena=stage, engineering=stage)
        packet = {
            "schema": "quoridor.strength355.joint-input.v1",
            "plan_SHA256": s.PLAN_SHA,
            "provenance": "SYNTHETIC",
            "producer_bindings": binding,
            "book": self.book,
            "schedule": self.schedule,
            "games": [],
            "matched": {"book_SHA256": s.check_book(self.book), "rows": []},
            "trees": [],
            "selection": None,
            "stronger": None,
            "partial_errors": [],
        }
        out = s.analyze_packet(packet)
        self.assertEqual(out["provenance"], "SYNTHETIC")
        self.assertEqual(out["matched"]["UNKNOWN_or_partial"], 96)
        self.assertEqual(len(out["unentered_tree_family_ids"]), 8)
        self.assertIn("Missing slots stay UNKNOWN", s.report(out))


def producer_root(family):
    return {
        "key": family["root_key"],
        "history": family["counted_history"],
        "ply": len(family["prefix"]),
        "rules": "research-standard-2p-threefold-goal-first-v1",
        "synthetic": False,
    }  # NN0 shape discriminator, NOT legal/replayed history


def producer_observed(depth=4):
    stats = dict.fromkeys(producer.STATS_FIELDS, 0)
    stats.update(nodes=10, evaluations=5)
    return {
        "status": "COMPLETE",
        "requested_depth": depth,
        "deepest_completed_depth": depth,
        "selected_action": 13,
        "value_stm": 0.25,
        "PV": [13],
        "legal_action": True,
        "legal_PV": True,
        "PV_matches_selected_action": True,
        "stop": "DepthComplete",
        "terminal_strength": "DEEPER_ESTIMATE_NOT_GROUNDTRUTH",
        "nodes": 10,
        "evaluations": 5,
        "full_invocation_stats": stats,
        "parent_restored": True,
        "Search_only_seconds": 0.01,
        "setup_seconds": 0.02,
        "call_until_observation_seconds": 0.04,
        "returned_search_elapsed_seconds_nested": 0.009,
    }


class ProducerBoundaries(unittest.TestCase):
    def test_exactly_two_bootstraps_shared_contrast_descriptive_only(self):
        book = synthetic_book()
        schedule = synthetic_schedule(book)
        rows = [
            game(book, schedule, slot["slot_id"], score=1)
            for slot in schedule["slots"]
            if slot["family_id"] == 0
        ]
        with mock.patch.object(s, "bootstrap", return_value={"interval": [0.5, 1]}) as sampled:
            result = s.aggregate_games(book, schedule, rows)
        self.assertEqual(sampled.call_count, 2)
        self.assertEqual(result["shared_family_contrast"]["common_complete_families"], [0])
        self.assertIsNone(result["shared_family_contrast"]["descriptive_interval"])

    def test_stream_publication_failure_keeps_original_and_available_facts(self):
        root = Path(__file__).parent / "owned-TMP"
        with tempfile.TemporaryDirectory(dir=root) as directory:
            directory = Path(directory)
            index_path = directory / "index.json"
            index_path.write_text(
                json.dumps(
                    {
                        "schema": "quoridor.strength355.stopped-input-index.v1",
                        "plan_SHA256": s.PLAN_SHA,
                        "provenance": "ACTUAL_GENERATED",
                        "files": {},
                    }
                )
            )
            original = RuntimeError("synthetic original after available rows")

            def fail(index, inputs, partial):
                partial["validated_native_scores"] = [0.25]
                inputs.progress["rows_read"] = 1
                raise original

            out = directory / "out"
            write = Path.write_bytes

            def broken(path, data):
                if path.name == "failure.json":
                    raise OSError("synthetic secondary publication")
                return write(path, data)

            with (
                mock.patch.object(boundary, "LOCK", index_path),
                mock.patch.object(
                    boundary, "stopped_support", return_value={"SYNTHETIC_FIXTURE": True}
                ),
                mock.patch.object(boundary, "named_quiet"),
                mock.patch.object(boundary, "finite_physical"),
                mock.patch.object(streamed, "analyze_index", side_effect=fail),
                mock.patch.object(Path, "write_bytes", broken),
            ):
                with self.assertRaises(RuntimeError) as caught:
                    streamed.future_entry(
                        index_path,
                        boundary.identity(index_path),
                        "synthetic-no-real-support",
                        "0" * 64,
                        out,
                    )
            self.assertIs(caught.exception, original)
            self.assertEqual(
                original.strength355_available_evidence["validated_native_scores"], [0.25]
            )
            self.assertTrue((out / "INCOMPLETE").exists())
            self.assertIn("synthetic secondary publication", " ".join(original.__notes__))
            self.assertIn('"rows_read": 1', " ".join(original.__notes__))
            self.assertFalse((out / "summary.json").exists())

    def test_runtime_gap_bool_and_copied_source_clear_refuse(self):
        path = boundary.CANONICAL / "resources-source-corrected-v2.json"
        fake = {
            "issue": "quoridor-4lc.355",
            "source_only": False,
            "heavy_entry_authorized_by_this_support": True,
            "unresolved_whole_gap_B": False,
        }
        with (
            mock.patch.object(boundary, "identity", return_value={"SHA256": "0" * 64}),
            mock.patch.object(Path, "read_bytes", return_value=json.dumps(fake).encode()),
        ):
            with self.assertRaises(s.Refusal):
                boundary.stopped_support(path, "0" * 64)
        book = synthetic_book()
        q = {
            "schema": "quoridor.value-search-strength.compare-qualification.v1",
            "book_sha256": book["source_book_SHA256"],
            "canonical_plan_sha256": s.PLAN_SHA,
            "executable_sha256": "1" * 64,
            "compiled_sources_sha256": "2" * 64,
            "generation_compiled_sources_sha256": "3" * 64,
            "source_review": {"path": "/synthetic/source", "sha256": "4" * 64},
            "software_receipt": {"path": "/synthetic/software", "sha256": "5" * 64},
            "input_receipt": {"path": "/synthetic/input", "sha256": "6" * 64},
        }
        stub = mock.Mock()
        stub.refs = {
            name: {"path": "/synthetic/" + name, "SHA256": digit * 64}
            for name, digit in (("source", "4"), ("software", "5"), ("input", "6"))
        }
        receipt = {
            "source_clear": True,
            "blockers": False,
            "remaining": [],
            "actual_STOP": "2026-10-09T23:00:00+00:00",
        }
        stub.get.side_effect = [q, receipt]
        with self.assertRaises(s.Refusal):
            streamed.verify_engineering_qualification(stub, "q", book)

    def test_terminal_and_partial_requested_depth_remain_distinct(self):
        book = synthetic_book()
        raw = producer_observed()
        raw.update(
            deepest_completed_depth=0,
            selected_action=None,
            value_stm=-2,
            PV=[],
            stop="Terminal",
            terminal_strength="EXACT_CANONICAL_TERMINAL",
        )
        row = producer.observed(raw, book["families"][0], "D", 4)
        self.assertEqual(row["deepest_completed"], 0)
        self.assertTrue(s.complete_depth(row, 4))
        raw.update(
            status="INCOMPLETE_UNKNOWN",
            stop="NodeLimit",
            deepest_completed_depth=3,
            selected_action=13,
            PV=[13],
            value_stm=0.2,
            terminal_strength="DEEPER_ESTIMATE_NOT_GROUNDTRUTH",
        )
        row = producer.observed(raw, book["families"][0], "D", 4)
        self.assertFalse(s.complete_depth(row, 4))
        for drift in (True, float("nan")):
            bad = producer_observed()
            bad["value_stm"] = drift
            with self.assertRaises(s.Refusal):
                producer.observed(bad, book["families"][0], "D", 4)

    def test_all_three_proposals_in_union_after_other_matchup_quota(self):
        book = synthetic_book()
        rows = []
        for fid in s.MATCHED_IDS:
            for evaluator in s.EVALUATORS:
                action = (
                    13
                    if evaluator == "D"
                    else 15
                    if evaluator == "BEST43"
                    else 14
                    if fid == 32
                    else 13
                )
                rows.append(search_row(book, fid, evaluator, action))
        result = s.check_matched(book, {"book_SHA256": s.check_book(book), "rows": rows})
        unions = {u["family_id"]: u["actions"] for u in result["selection"]["unions"]}
        self.assertEqual(unions[32], [13, 14, 15])
        self.assertEqual(len(result["selection"]["first_differences"]["BEST43"]), 8)

    def test_forced_child_sign_horizon_and_error_work_domains(self):
        book = synthetic_book()
        family = book["families"][0]
        child = producer_root(family)
        child["ply"] += 1
        raw = {
            "family": 0,
            "opening_id": "strength355-family-000",
            "engine": "BEST43",
            "parent_root": producer_root(family),
            "child_root": child,
            "forced_action": 14,
            "parent_total_depth": 6,
            "child_requested_depth": 5,
            "parent_restored": True,
            "parent_value_stm": -0.25,
            "observed_child": producer_observed(5),
            "selection_sha256": "a" * 64,
        }
        row = producer.search_row(raw, book, "forced")
        self.assertEqual(
            (row["requested_depth"], row["deepest_completed"], row["pv"], row["value_stm"]),
            (6, 6, [14, 13], -0.25),
        )
        self.assertIsNone(s.costs(row)["setup_search_drop_seconds"])
        raw["parent_value_stm"] = 0.25
        with self.assertRaises(s.Refusal):
            producer.search_row(raw, book, "forced")
        raw["observed_child"] = {
            "status": "UNKNOWN",
            "requested_depth": 5,
            "original_error": {"text": "synthetic original Err"},
            "reserved_unknown_nodes": 8000000,
        }
        raw["parent_value_stm"] = None
        row = producer.search_row(raw, book, "forced")
        self.assertIsNone(row["nodes"])
        self.assertEqual(row["reserved_unknown_nodes"], 8000000)
        self.assertFalse(s.complete_depth(row, 6))
        census = producer.census(
            {
                "admitted_attempts": 1,
                "actual_Search_invocations": 1,
                "Ok_returns": 0,
                "Err_returns": 1,
                "nodes_or_unknown_liability": 8000000,
            },
            [row],
            192,
            1536000000,
        )
        self.assertEqual(census["unavailable_node_work"], "UNKNOWN")

    def test_actual_common_hierarchy_stm_terminal_and_leaf_census(self):
        book = synthetic_book()
        raw = {
            "family": 0,
            "status": "COMPLETE",
            "root": producer_root(book["families"][0]),
            "values_stm": [2, 2, 2],
            "nodes": 2,
            "leaves": 1,
            "actual_leaf_evaluator_calls": 0,
            "whole_tree_seconds": 0.01,
            "ALL_legal_firstmoves_responses": [
                {
                    "action": 13,
                    "value_parent_stm": [2, 2, 2],
                    "terminal_child": -1,
                    "leaf_count": 1,
                    "responses": [],
                }
            ],
        }
        result = producer.common_tree(raw, book)
        self.assertEqual(result["nodes"][1]["terminal_proof"]["value_stm"], -2)
        self.assertEqual(s.check_tree(result)["status"], "COMPLETE")
        raw["ALL_legal_firstmoves_responses"][0]["leaf_count"] = 2
        with self.assertRaises(s.Refusal):
            producer.common_tree(raw, book)
        partial = producer.common_tree(
            {
                "family": 0,
                "status": "INCOMPLETE_UNKNOWN",
                "nodes_attempted": 9,
                "minimax": None,
                "original_error": {"text": "synthetic stopped"},
            },
            book,
        )
        self.assertEqual(s.check_tree(partial)["available_nodes"], 9)
        self.assertNotIn("root_values", s.check_tree(partial))

    def test_bound_file_map_modes_alias_partial_rows_and_prior_facts(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent / "owned-TMP") as directory:
            path = Path(directory) / "rows.jsonl"
            path.write_bytes(b'{"game":0}\n{"game":')
            ref = boundary.identity(path)
            index = {
                "schema": "quoridor.strength355.stopped-input-index.v1",
                "plan_SHA256": s.PLAN_SHA,
                "provenance": "ACTUAL_GENERATED",
                "files": {"rows": {"path": str(path), **ref}},
            }
            inputs = streamed.Inputs(index)
            iterator = inputs.lines("rows")
            self.assertEqual(next(iterator), {"game": 0})
            with self.assertRaises(s.Refusal):
                next(iterator)
            self.assertEqual(inputs.progress["rows_read"], 1)
            drift = copy.deepcopy(index)
            drift["files"]["rows"]["mode"] = "0777"
            with self.assertRaises(s.Refusal):
                streamed.Inputs(drift)
            drift = copy.deepcopy(index)
            drift["files"]["alias"] = drift["files"]["rows"]
            with self.assertRaises(s.Refusal):
                streamed.Inputs(drift)
        book = synthetic_book()
        schedule = synthetic_schedule(book)
        first = game(book, schedule, 0, unknown="synthetic unentered")
        progress = {}

        def broken():
            yield first
            raise RuntimeError("synthetic later stream error")

        with self.assertRaisesRegex(RuntimeError, "later stream"):
            s.aggregate_games(book, schedule, broken(), progress)
        self.assertEqual(progress["validated_game_scores"], {"0": None})

    def test_strict_receipt_types_source_grant_and_publish_error(self):
        with mock.patch.object(boundary, "LOCK", Path(__file__)):
            # The actual current canonical source support must refuse BEFORE
            # an absent index, output, new fixtures or science can be opened.
            source = boundary.CANONICAL / "resources-source-corrected-v2.json"
            with self.assertRaises(s.Refusal):
                streamed.future_entry(
                    "/not-opened", {}, source, boundary.identity(source)["SHA256"], "/not-created"
                )
        book = synthetic_book()
        family = book["families"][0]
        raw = producer_observed()
        raw["full_invocation_stats"]["nodes"] = True
        with self.assertRaises(s.Refusal):
            producer.observed(raw, family, "D", 4)
        bad = producer_observed()
        bad["full_invocation_stats"]["another"] = bad["full_invocation_stats"].pop("policy_calls")
        with self.assertRaises(s.Refusal):
            producer.observed(bad, family, "D", 4)


if __name__ == "__main__":
    unittest.main(verbosity=2)
