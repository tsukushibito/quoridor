"""One bounded synthetic source qualification under an actual finite NB lease."""

import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import sys
import time
import unittest
import argparse

HERE = Path(__file__).resolve().parent
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--tests", nargs="*")
    parser.add_argument("--version", default="v1")
    args = parser.parse_args()
    with LOCK.open("rb") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        pattern = re.compile(
            r"(^|/)(cargo|rustc|perf|quoridor-runner|chromium|chrome)(\s|$)|torchrun|quoridor_training.train|qualify_trained.py|current_gradients.py"
        )
        for p in Path("/proc").iterdir():
            if not p.name.isdigit() or int(p.name) in (os.getpid(), os.getppid()):
                continue
            try:
                argv = p.joinpath("cmdline").read_bytes().split(b"\0")
                if Path(os.fsdecode(argv[0])).name in ("bash", "sh", "timeout"):
                    continue
                if pattern.search(" ".join(os.fsdecode(a) for a in argv if a)):
                    raise RuntimeError("actual named competitor")
            except (OSError, IndexError):
                continue
        memory = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/meminfo").read_text().splitlines()
                    if x.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        if memory < 536870912 + 4294967296:
            raise RuntimeError("family+host RAM")
        physical = {
            str(c): [
                (Path(f"/sys/devices/system/cpu/cpu{c}/topology") / n).read_text().strip()
                for n in ("physical_package_id", "core_id")
            ]
            for c in (3, 4)
        }
        if physical["3"] == physical["4"]:
            raise RuntimeError("distinct controller physical core")
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
        allocated = (
            sum(p.stat().st_blocks * 512 for p in HERE.iterdir() if p.is_file())
            + HERE.stat().st_blocks * 512
        )
        if allocated + 1048576 > 16777216:
            raise RuntimeError("whole source forward unsupported")
        refs = {
            str(HERE / name): {
                "SHA256": hashlib.sha256((HERE / name).read_bytes()).hexdigest(),
                "bytes": (HERE / name).stat().st_size,
                "mode": f"{(HERE / name).stat().st_mode & 511:04o}",
            }
            for name in (
                "strength355.py",
                "io355.py",
                "producer355.py",
                "stream355.py",
                "test_strength355.py",
                Path(__file__).name,
            )
        }
        tmp = HERE / "owned-TMP"
        tmp.mkdir(exist_ok=False)
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        clock = time.monotonic()
        sys.path.insert(0, str(HERE))
        spec = importlib.util.spec_from_file_location(
            "owned355_synthetic_tests", HERE / "test_strength355.py"
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        suite = (
            unittest.defaultTestLoader.loadTestsFromNames(args.tests, module)
            if args.tests
            else unittest.defaultTestLoader.loadTestsFromModule(module)
        )
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        if any(tmp.iterdir()):
            raise RuntimeError("owned synthetic TMP remains")
        tmp.rmdir()
        for name, ref in refs.items():
            if hashlib.sha256(Path(name).read_bytes()).hexdigest() != ref["SHA256"]:
                raise RuntimeError("owned source-after changed")
        hwm = (
            int(
                next(
                    x.split()[1]
                    for x in Path("/proc/self/status").read_text().splitlines()
                    if x.startswith("VmHWM:")
                )
            )
            * 1024
        )
        if hwm + 67108864 > 536870912:
            raise RuntimeError("sampled family upper exceeded")
        stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
        record = {
            "schema": "quoridor.strength355.synthetic-source-STOP.v1",
            "issue": "quoridor-4lc.355.3",
            "provenance": "SYNTHETIC_ONLY_NO_GEOMETRY_OR_CAMPAIGN",
            "START": started,
            "actual_source_reader_writer_STOP": stop,
            "direct_tool_return": True,
            "owned_readers_children_jobs_TMP_remaining": [],
            "count": result.testsRun,
            "PASS": result.wasSuccessful(),
            "failures": [str(t) for t, e in result.failures],
            "errors": [str(t) for t, e in result.errors],
            "source_refs": refs,
            "elapsed_seconds": time.monotonic() - clock,
            "MemAvailable_B": memory,
            "physical": physical,
            "actual_self_VmHWM_B": hwm,
            "sampled_family_including64MiB_B": hwm + 67108864,
            "continuous_family_peak": "UNKNOWN",
            "RU_maxrss_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            "bootstrap": "only new synthetic two-score fixture; no oldscience or actual campaign",
            "model_native_geometry_Search_Torch_fit_game_calls": 0,
            "issued_source_upper_B": 16777216,
            "before_sample_B": allocated,
            "new_forward_qualification_B": 1048576,
            "no_runtime_support": True,
        }
        (HERE / f"source-ports-STOP-{args.version}.json").write_text(
            json.dumps(record, indent=2) + "\n"
        )
        raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()
