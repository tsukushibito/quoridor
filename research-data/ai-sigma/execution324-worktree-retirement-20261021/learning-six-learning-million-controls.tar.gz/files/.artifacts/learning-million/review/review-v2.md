# 公開Sigma original-only-v2 導入境界の再確認

Issue quoridor-4lc.319.1 / 同owner・thread 01a1103c-fbe0-7412-a406-fbee697a1392。
人間が選択済みのoriginal-only全43・exact T1m/V50k/E50kを対象に、review-source-binding-v2.jsonの12pathを確認。旧版の選択・費・失敗・reviewを上書きしない。

## 結論

**F1〜F5は今回の確認範囲で解消。新しい重大指摘なし。** v2の入力・STM/z・original provenance・compact caller・frozen test入口は静的に整合する。NN0 fixtureは5件PASS。Rootはこの限定導入境界の確認を採用根拠にできる。これは実corpus達成、live native/model/GPU資格、本fit、freeze後の最終test成功の認定ではない。

## 旧指摘の確認

| 指摘 | 結果と根拠 |
| --- | --- |
| F1 frozen/test corpus不照合 | 解消。train.py:929でcache_schemaをfreezeへ追加。1086–1113でfrozen bindingのschema/SHAを照合。1116–1129のpreflightがcache.jsonのschema/SHA/存在を検査し、test:1200–1202はこの順でfreeze→preflight→load、Torch importは1212。異corpus・異schema・欠落cacheのNN0 fixtureが成功。 |
| F2 UNKNOWN→unexposed | 解消。compact testはtrain.py:1276–1282のeligible_heldout_observationsと1298–1300のexposure UNKNOWNを出力。primary_eligibleは決着観測の資格としてのみ解釈され、過去未露出や未見gameを主張しない。native既存経路は今回の公開compact対象外。 |
| F3 initial追加test | 解消。train.py:1225のcompact checkpoint_names=(best,)で一候補のみ。distance/constantは1252以降。initialはT/V診断とfreeze attributionに保持されるが、sealed testのforward/metrics/checkpoint一覧には入らない。 |
| F4 primary rowMSE | 解消。train.py:160–173はcompact z / epoch / row loss / row monitor、original_only=True、dataset_revision=original-only-v2を要求。fit-config SHAがbindingに一致。 |
| F5 独立性・包含確率の過剰主張 | 解消は記述・解釈の訂正。旧seed/selection/mix64/XOR順位数学を変更せず、sampling-method-qualification.jsonで旧plan/SHA/費と実retention/tieを保存、独立IID包含確率NOT_PROVENと明記。v2 planもproducer:284–289で固定rank/nominal threshold/realized retention/独立性未証明を区別。確率的独立性を新たに立証したとはしない。 |

## v2 producer と source sign

- 旧9pathから変更はpublic_sigma.py、compact_cache.py、train.py、test_public_sigma.py。追加対象はtest_observation.py、plotting.py、qualification.py。残る5pathは旧SHAのまま。全12pathがv2 binding一致。producer-used-v1.py.txtのSHAは旧0f40528e…と完全一致し、difflibで旧snapshot→現役producerの直接差分を確認。selection/seed/constantsとnative変換の数学は変更0。
- producer:173–208はstatesの前半halfだけを入力・native資格へ供給し、213–214はvaluesの前半halfだけを採る。後半LRを教師へ混ぜず、そのaliasを復元したことにしない。row=index<half、alias=row。旧LR実byte検査をv2の資格に持ち込まない。native不正・z0/不正labelは230–245で観測単位に除外、他の有効同入力観測を群ごと消さない。
- producer:267–300は固定revision/43件、original-only-v2契約、43個の異なるblobを要求する。all43 candidate/split/rankの元規則はoriginal候補へそのまま適用する。最終exact件数と不足時raiseは旧版から維持。分母はcandidate original observationsのみ、unsampled eligibility UNKNOWN、distinct/game数は保存行数と別。
- CompactCorpus:79–90は43source header、row==alias、row<元shard半分を検査。元index/入力hash/modelhash/距離/zの対応を維持し、LRや別観測からoriginal教師を虚構復元しない。native lib/test/cache/commonは旧SHA不変なので旧reviewのlossless確認を再利用。
- C++3ファイルはrefsのbytes/SHA256に加え、blob framing付きGit SHA1を独立計算して全一致。固定revision 751186344fc52ad0c29bc65922e62c6fa915f006の提示一次sourceとして確認（ネット照合は0）。
  - 保存selfplay.hpp:1067と1078は同じg.stateのnn_input/current_playerを記録。
  - solver/PCR subsampleの628–649もstate_before.nn_input:638とstate_before.current_player:645が対応。
  - finalize_game:1129–1137は同順rec_planesをout_statesへ入れ、winner!=0でrec_player==winnerなら+1、他は-1、winner0は0。
  - engine.hpp:138–139はdepth%2のcurrent_player、458–493はown/opponentとP2上下反転・horizontal anchor行補正。canonicalSTMからQF1の2視点へ進む旧native変換と整合。
  - bindings.cpp:303–329は同get_dataのstates/valuesをmemcpyでPythonへ渡す。公開Python selfplay:294–296/328–333の保存まで符号再変換なし。
- よって旧reviewのupstream z/STM sign未確認は一次sourceによる静的確認として解消。v2はnaiveLRを採らないので、そのコピーzの幾何反転等価性を採用前提にしない。game/history欠測と過去露出UNKNOWNは継続する。

## fit・保存・停止の静的確認

- fit-config.json SHA=e0f1ca7…でbinding一致。batch128、LR3e-5、Adam wd0、distance_residual FT32/H32、dropout0、D a0/b8、epoch、row monitor、CUDA、native export。20epochはceil(1m/128)=7813 steps/epoch×20=156260。patience3epoch/min_delta1e-4。
- selector229点（250上限内）、初期0/1/2/5/10/20、2000まで25刻み、その後1250刻みと全epoch境界が含まれる。全V50kと固定Tdiag2048、epoch境界ではfullT1m。予定forwardは最大51,878,032行（train20mを含む）でsamples60m内。ただしwall内達成の証明ではない。
- 尺度/定数はtrain.py:186/209と1154–1178のix_trainだけから固定する経路。scale overrideの実artifactとv2 trainへのbindingはまだ作成・確認されていない。実data採用後にv2trainだけで固定し、旧scaleを自動流用しないことが残る実資格。
- plotting.py:249–305は記録点だけのPNG、固定diag/fulltrainを分け、primary row/secondary groupを表示。train:644–723はCSV/SVG/PNG/圧縮visitを保存。BUDGET_STOPPEDの839–856は通常予算終了をcatchしてpersistし、その後859–872でINITIAL/BEST/LASTを保存する。これはgraceful budget stopの静的経路であり、外部guardianによる強制終了・保存障害でも必ず残るという保証ではない。live動作と画像確認は未実施。
- prepare-config-v2.jsonは新output ../public-million-learning/original-only-v2/corpus、新network系列、guard335,544,320B。producerの親rootはoriginal-only-v2であり、旧corpus-v1の191.4MBは320MiB guardへ含まれない。foreground worker6600秒、CPU2/3、RAM4GiB、既存guardianの回収・pause/owner制御を再用する。
- forecast-v2は旧191.4MB+新191.4MBを同時保持し、scratch/WT/build/weights/evidence/Git/tmp/review2MiB込み646,240,512B<805,306,368B。known data費345.98秒（lower bound）+new cap6600=6945.98<7200、known差254.02秒。未知の追加費を0に補完していないため、本launch時は実累積receipt/aggregate admissionの確認を担当が維持する。livejob/大corpus/progress/sealed labelsは未読。

## 実検証・費・停止

- reviewer NN0: unittest quoridor_training.test_public_sigma **5件PASS**、unittest0.032秒、子wall0.127328秒、peak RSS45,476KiB。affinity3、OPENBLAS1、RAM/address-space512MiB、TMPDIR=review、-B。異cache拒否fixtureはhelperの直接検査であり、test全体をTorchで実行した検証ではない。source上のload/import順も確認した。
- 実行担当の28NN0 PASS、native fixture31候補/6z0/25保持/hostile LR input・label未読は提供JSON証拠として保持し、reviewer再実行結果とは区別。reviewer native/Torch/GPU/build/forward/network/大corpus/newjob/再委譲=0。
- 旧費control16.212920秒、fixture0.109659秒を累積へ加算、reset0。新commands・費・SHAと累積はreview-v2.json、fixture-v2.json、control-v2.json。旧report/JSON/失敗を上書きしない。累積read/control60秒、fixture20秒、新保存2MiBの既残内。
- issueは既に同ownerでreopen/openだったためready/showを必要scalarだけ読んで本人claimした。再開dangerFullAccess/never/cwd/model/effortをreview-permissions-v2.jsonと環境で確認。旧showのnested parent notes出力という過去逸脱は旧reportに保持し、今回は親notesを表示しない。
- source/code/main/Git index writer0。証拠のみwriter、bounded readerは終了、自己長job/生存child0。review子issueだけ完了、親319のfit/testは閉じない。実行担当とRootへ一度通知後Idle。採用後archive、常設監視0。
