# 公開Sigma compact導入境界の独立レビュー

Issue: quoridor-4lc.319.1 / reviewer codex:01a1103c-fbe0-7412-a406-fbee697a1392
対象: review-source-binding.jsonのWT固定9path（全SHA一致）。正本仕様はmain public-million-learning/task.md。追加参照SHA・command費はreview.jsonとcontrol.json、実fixtureはfixture.json。

## 結論

入力→native構造→QF1 bitset→bounded batch→trainerの対応は静的に成立し、小NN0 fixtureもPASS。ただし **最終test callerにP1が3件あり、現版のtest releaseは保留**。通常修正は実行担当の同threadへ、科学的意味の採用はRootへ戻す。ここで確認したのは導入境界であり、本fit・liveモデル資格・全43corpusの達成をcompletedとしない。

## 重大指摘

- **P1 / F1 — frozen corpusとtest cacheが照合されない。** train.py:1143–1144はverify_freeze(training)の直後にload(cache, allow_test=True)する。verify_freeze:1064–1071はtraining内のbindingだけを確認し、評価cacheのmanifest SHAとfreeze.dataset_shaを比較しない。別の有効compact corpusでも通り、そのlabelsを開けて評価する。compactでは同一cache.jsonがT/V/test-sealed全partitionのSHAを束縛しているため、**test labelsを開く前に** frozen manifest SHAと指定cacheのSHAを照合すべき。fixtureによる実行再現は未実施（Torch/forward禁止）。静的根拠は明確。
- **P1 / F2 — UNKNOWN過去露出をunexposedへ昇格する。** public_sigma.py:386–387はgame/historyと露出をUNKNOWNと記録する一方、compact_cache.py:30は全保存行をprimary_eligible=Trueとする。train.py:1211–1219はその資格を露出資格として使い、全test行をunexposedへ集計する。決着教師の適格性は過去未露出の証明ではない。公開分布のheld-out観測・露出UNKNOWNとして出力し、検証可能な旧観測照合結果だけを別途帰属すべき。input overlap許容と新しい未見game評価を混同しない。
- **P1 / F3 — sealed評価にinitialモデルが追加される。** train.py:1167–1192はinitialとbestをそれぞれforwardし、両方をreportsへ含める。契約はfreeze後の**一候補 / D / 定数を一巡**であり、異なるinitialを追加する許可はない。step0はtrain/validation曲線で確認できる。compact最終評価の経路を一候補に合わせる通常修正、又はRoot経由の明示的な評価範囲判断が必要。レビュー側は実装しない。

## 通常指摘

- **P2 / F4 — compactのprimary rowMSEがcallerで束縛されない。** train.py:154–159はz/epoch/row lossを強制するがevaluation.monitor=rowを要求しない。common.py:41の既定はgameで、train.py:562–566はその場合group等重みMSEで選定する。fit未開始なので実違反のrunは未確認。fit configをrowへ結果前固定し、compact入口でも不一致を拒否することを推奨。20epochs、patience3/min_delta1e-4、LR3e-5/batch128、250点上限等の実configは未確認。
- **P2 / F5 — priorityの独立性・採択確率の表現が強い。** selection/process_shardのXOR saltでは、original alias i^4とLR alias iのpriorityが同じmix64引数になる（両indexが範囲内なら）。複数streamは独立ではなく、同split内のtieはshard/rowで決着する。labelblindで固定・再現可能な全域bottom-priority選択自体は成立するが、sampling-planの「independent-row-salt」とcandidate*p_split*min(1,N/Q)は厳密な独立一様row reservoirの包含確率の証明ではない。根拠に合う記述へ修正し、抽出規則を変更する場合は結果前固定・重要split/sampling変更の判断をRootへ戻す。レビュワーはseed/規則を変更しない。

## 問いごとの確認

1. **座標 / STM / compact:** lib.rs:832–903はpawn one-hot、stock、h/v segmentとpadding、Position.checked、全8plane距離mapを確認し、turn=0のcanonicalSTM構造へ戻す。research.rs:411–486はP2の上下反転・own/opponent swapとh anchor行補正。QF1は別にP2を180度回転し、native ABIはview*312+idをlittle bit順で78Bへ保存。compact_cache.batchのlittle unpackbits/reshape(-1,2,312)、distance f32、labels NaN/zの順とtrainerのside=1（modelはside-1）に対応する。手書き数学変更0。原plane浮動小数値そのものの復元ではなく、資格済みnative QF1モデル入力のlossless対応。
2. **入力不正 / z0:** native statusはrow単位。producerのexcluded=(codes!=0)|~decisiveは群別削除をせず、別観測の同入力±1を保持する。z0はunknown termination理由7、不正labelは8で、元z/rowをbinary除外記録へ保存。native不正も併発するとreasonはnative優先だがzと各label集計を保持。元game/historyや終局理由の復元はしない。
3. **source alias / sampling / split / 分母:** source-selfplay_cpp-py.txt:320–333は前半original/後半np.flip(axis=3)、valuesコピー。producerは全行のnaiveLR入力byte SHAとlabelのbit一致を検査し、blob/index由来のaliasを保持する。manifestは固定43件、43個の異なるGit blob。candidate/split/priorityはzの参照前に決まり、全shard/全aliasに候補機会がある。兄弟だけを同splitへ束縛し、別cycle同盤面を排除しない。bottom-priorityは各splitの正確な保存行数まで切り詰め、不足時はraiseし水増ししない。資格分母はsampled candidate rowsのみ、unsampled eligibilityはUNKNOWN。1m/50k/50kは保存観測行数でdistinct/game数ではない。現corpus/progressは未読。
4. **隔離 / 尺度 / 主指標:** 通常loadはT/Vだけをmap・hash・label資格検査し、別test-sealed.binを開かない。fixtureはtest fileが存在しなくてもT/V batchが通ることを確認。statistics/constantの計算はix_trainだけ、distance_residualのDは結果前固定a/b。外部scale overrideのtrain-only由来は未確認。loss=row、validation target_mseはrow平均、input-group/strataはsecondaryとして実装。ただしF1–F4により最終release/primary選定を無条件に保証しない。
5. **bounded供給 / 保存 / stop:** producerは1compressed shard、states4096行、native max8192、候補rowの配列とsplit別固定reservoirを保持し、全row dict/dense corpusは保存しない。loaderはmemmap、batchのみdense展開。trainerはcompact集計と圧縮visit配列を保存する。guardianはRAM、期限、outputをpollし、pid/start identity・pidfdでTERM→KILL→waitする。outer research-jobはowner/paused/statusを確認する。prepare-configは7190秒、outerjob7200秒、affinity2/3。forecast728,000,000B < 805,306,368B。preheavy snapshotは12GiB aggregateのcurrent+unused=12,854,374,400B、cap=12,884,901,888B、UNKNOWN128MiB保持、learning319 roots/予約768MiBを含みwithin。review2MiBは同WT root・evidence80MiB内で追加予約しない。これは保存済みadmissionと静的確認であり、現runのpeak・GPUfit guardian/whole費・実子回収は未検証。

## 重要な限界と検証

- **naiveLRを正しい幾何反転と認定しない。** asymmetric wall fixtureはanchorの正しいLRと9wide plane naive flipが異なること、boundary padding不正を拒否することを示す。壁なし/距離map不変等ではnaiveLRが別の合法盤面として通り得る。全8plane一致はそのnative入力資格であり、元盤面との対称性やコピーzの真の幾何反転教師としての等価性の証明ではない。本契約の観測単位判定に従うが、受理された公開録画zを何の教師と解釈するかはRootの科学的前提として明示が必要。レビュー側がLR群や有効別観測を新たに削除しない。
- **zのupstream視点:** Python sourceではmgr.get_data()['values']をそのまま保存しLRでコピーすることまで確認。C++のvalue生成/STM sign付与本体は渡されたsourceにないため、upstream signの独立証明は未完了。native canonical viewとの対応は上記の静的検査範囲に限る。
- 外部outcomesの3native fixture（P2/非対称壁、bulk invalid中間row、z0/NaN auxiliary）は**sourceを読んだ**。binding記載の3native/15NN0/50rowstream結果は実行担当の証拠であり、こちらの再実行結果と分ける。
- reviewer実行: OPENBLAS_NUM_THREADS=1、affinity3、PYTHONPATH=WT/python、TMPDIR=review、RLIMIT_AS512MiBでpython -B -m unittest quoridor_training.test_public_sigma。**4 tests PASS**, unittest0.011s、wrapper計測0.109659s、子peak RSS41,668KiB。Torch/nativebulk/build/forward/GPU/network/newjob/再委譲0。
- source/code/main writer0、Git index/ref/commit操作0。対象だけのgit diff --numstatは3秒でtimeout、subprocess.runがkill/waitし再試行なし。差分資格は未確認、固定SHAとsourceでレビュー。
- 初回python aliasがなく失敗しpython3へ通常修復。初回showの縮約がnested dependencyを残して親description/notesを一度出力した。旧親notesを独立根拠には使わず、以後表示しない。fresh-context入力の厳密な「旧notes読0」は満たせなかったことを明示する。WTにresearch-team/jobs docsがなくmain正本を読む形へ修復。
- 実行commands/費・対象SHA・未確認・停止receiptはJSONに保存。readerは各bounded command終了時に停止、自分の長job/生存childなし。レビュー完了後はIdle、親issueは閉じない。通常修正の確認は同thread、常設監視なし。
