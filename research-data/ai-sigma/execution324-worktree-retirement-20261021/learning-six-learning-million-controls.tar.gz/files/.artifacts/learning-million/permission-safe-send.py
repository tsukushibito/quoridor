"""Explicit resume permissions before same-session task delivery; no server."""

import asyncio
import importlib.util
import json
from pathlib import Path

checkout = Path("/workspaces/quoridor/.worktree/learning-million")
p = checkout / ".artifacts/learning-million"
spec = importlib.util.spec_from_file_location(
    "session", checkout / "scripts/dev/research-session.py"
)
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)


async def main():
    root = Path("/workspaces/quoridor")
    host = client.command_json(["codex", "app-server", "daemon", "version"])
    async with client.AppServer(host) as server:
        for thread, issue in [
            ("01a0f2e9-357d-7ef3-a2fe-b16f80accda5", "quoridor-4lc"),
            ("01a11004-79f3-7c20-872c-432a2c347664", "quoridor-4lc.318"),
        ]:
            with client.dispatch_lock(root):
                client.require_owner(issue, root, thread)
                current = await server.read_thread(thread)
                if current["status"]["type"] == "notLoaded":
                    response = await server.request(
                        "thread/resume",
                        {
                            "threadId": thread,
                            "excludeTurns": True,
                            "sandbox": "danger-full-access",
                            "approvalPolicy": "never",
                        },
                    )
                    assert (
                        response["sandbox"]["type"] == "dangerFullAccess"
                        and response["approvalPolicy"] == "never"
                    )
                    (p / (issue + "-coordination-resume.json")).write_text(
                        json.dumps(
                            {
                                k: response.get(k)
                                for k in [
                                    "sandbox",
                                    "approvalPolicy",
                                    "model",
                                    "reasoningEffort",
                                    "cwd",
                                ]
                            },
                            indent=2,
                        )
                        + "\n"
                    )
                body = "Beads issue: " + issue + "\n\n" + (p / "v2-slot-report.md").read_text()
                receipt = await server.deliver(thread, body)
                (p / (issue + "-v2-slot-delivery.json")).write_text(
                    json.dumps(receipt, indent=2) + "\n"
                )
                print(json.dumps(receipt))


asyncio.run(main())
