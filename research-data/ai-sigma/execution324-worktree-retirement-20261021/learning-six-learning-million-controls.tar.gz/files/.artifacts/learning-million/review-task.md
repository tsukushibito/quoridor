# 公開Sigma compact入力導入境界の独立レビュー

親quoridor-4lc.319、ユーザーが限定委譲を承認。fresh contextで研究導入の妥当性を確認する仕事。実行者の結論への同意を求めない。実仕様はmain research-data/ai-sigma/public-million-learning/task.mdと本契約。作業cwd=/workspaces/quoridor/.worktree/learning-million、writerはreview証拠のみで製品/source/main/Gitを書かない。CPU1（affinity3を最初のshellから指定）、RAM512MiB、全read/control command wall60秒＋小NN0fixture20秒、新保存2MiBは親evidence80MiB内。build/forward/Torch/GPU/重native scan/network/newjob/再委譲0。

開始前に作成記録 .artifacts/learning-million/review-permissions.json のsandbox dangerFullAccess、approvalPolicy never、cwdを確認。実環境は同fullaccess/never。最初にtaskset -c 3の軽量pwd、Beads wrapper ready --json/show自分issueだけを必要項目へ縮約し本人claimする。旧巨大親notes全読0。commandの実wallを記録しcaps前に停止。不足でも追加権限や科学capを推定しない。

対象は .artifacts/learning-million/review-source-binding.json で固定したWT版。入力/STM変換・幾何反転・zの視点/除外・元観測alias/split・compactencoder/decoder＋trainercallerを確認する。読むべき元sourceは .artifacts/learning-million/source-selfplay_cpp-py.txt（固定revision751186344fc52ad0c29bc65922e62c6fa915f006）と crates/quoridor-core/src/research.rs、core Position checked / nnue encode_qf1 の必要範囲。手書き数学変更0、元8plane STMをsigma_plane_positionでnative構造へして独立観測ごと資格判定しbitsetへ。反射sourceは前半original/後半naiveLRとvaluesコピー。正しい幾何反転とnaive flipを混同しない。対応tests/external_outcomes.rsの非対称壁fixtureと新compact_bulkfixtureを確認（build実行0）。

親仕様: all43機会のある固定seed抽出・保存行T1m/V50k/E50k（distinct/game数とは別）。z0終了理由不明は除外、同盤面の別観測の教師多重性を保持。原観測とLR兄弟のみ同split、別cycleの同盤面許容。公開履歴game欠測/旧test露出はUNKNOWN、testはheld-out観測で完全未見gameではない。最終評価ラベルは別sealedbin、candidate/config/checkpointfreezeまで読まない。

主要files: crates/quoridor-data/src/lib.rs、tests/external_outcomes.rs、python/quoridor_training/{public_sigma,compact_cache,cache,train,common,test_public_sigma}.py。Git diffはread-onlyで対象pathだけ可（index操作0）。source-binding SHAとの差異を最初に確認。trainercallerは新compactへの接続を実装済みだが本fit未開始・liveモデル検査未了であり、その未完了をcompletedとしない。run中の大corpus/progress/labelsを開かずsource/fixtureだけ読む。小NN0fixtureは .artifacts/learning-million/review内で python -B -m unittest quoridor_training.test_public_sigma を最大20秒、OPENBLAS_NUM_THREADS=1、PYTHONPATH=python、taskset3で可（Torch/実nativebulkを呼ばない）。

問い: (1) native変換の座標/STM/bitsetとcaller lossless対応は成立するか。(2)入力不正とz0を観測単位で除外し有効教師を消さないか。(3)alias/sampling/splitの全43機会、labelblind priority、siblings拘束と正確な行数/資格分母の意味は成立するか。(4)sealedtest隔離と過去露出の扱い、train-only尺度/基準/primary rowMSEは仕様と整合するか。(5)bounded供給と保存aggregate、予算・停止・子回収に導入を妨げる欠陥はあるか。

成果: .artifacts/learning-million/review/review.md と小JSONに対象path/SHA・実行commands/費・verified範囲・重大/通常指摘・未確認を簡潔に残す。重大意味/設計/予算の変更を自分で実装しない。issueへ結果とevidence参照、source/code writer0・reader/job停止を記録しbackup sync。結果は実行担当thread01a1100f-6d45-78e0-8a87-84503ff0fbf6（宛先issue319）とRoot01a0f2e9-357d-7ef3-a2fe-b16f80accda5（宛先issuequoridor-4lc）へ既research-session.sh sendで一度だけ返す。RPC不明は繰返し再送しない。通常修正の再確認は同thread、常設監視0。issueはレビュー完了後にownerが閉じられるが親taskは閉じない。turn終了しIdle、thread/archiveは受入れ後。
