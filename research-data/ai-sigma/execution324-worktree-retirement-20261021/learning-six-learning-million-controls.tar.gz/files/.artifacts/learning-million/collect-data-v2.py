"""Bounded STOP evidence; no native/NN forward and no sealed label reads."""

import gzip
import json
import os
from pathlib import Path
import resource
import signal
import time

import numpy as np

from quoridor_training.cache import load, sha
from quoridor_training.common import resolve_config
from quoridor_training.public_sigma import RECORD
from quoridor_training.train import training_statistics


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


os.sched_setaffinity(0, {2, 3})
resource.setrlimit(resource.RLIMIT_AS, (4 * 1024**3, 4 * 1024**3))
signal.alarm(60)
started = time.monotonic()
evidence = Path(__file__).resolve().parent
root = Path(
    "/workspaces/quoridor/.worktree/assets/inputs/public-million-learning/original-only-v2/recovery-r1/corpus"
)
source = json.loads((evidence / "source-manifest.json").read_text())
manifest = json.loads((root / "cache.json").read_text())
cost = json.loads((root / "cost.json").read_text())
assert len(cost["receipts"]) == len(cost["attempts"]) == len(source["files"]) == 43
for item, attempt, receipt, header in zip(
    source["files"], cost["attempts"], cost["receipts"], manifest["source_shards"]
):
    assert item["path"] == attempt["path"] == receipt["path"] == header["file"]
    assert item["sha"] == attempt["git_blob"] == receipt["blob"] == header["blob"]
    assert item["rows"] == receipt["stored_rows"] == header["rows"]
    assert receipt["decoded_rows"] == receipt["original_observations"] == item["rows"] // 2
    assert receipt["original_only"] and attempt["status"] in ("PASS", "REUSED_PASS")

corpus = load(root)  # Caller verifies only train/validation payload SHA and model signatures.
assert corpus.row_count == 1050000 and not corpus.binding["test_opened"]
train, validation = corpus.maps
assert len(train) == 1000000 and len(validation) == 50000
tail_dtype = np.dtype(RECORD.descr[3:])  # Starts after bits78/distance8/z4; no labels.
assert tail_dtype.itemsize == 84 and RECORD.fields["shard"][1] == 90
test_metadata = bytearray(50000 * tail_dtype.itemsize)
with (root / "test-sealed.bin").open("rb") as stream:
    for index in range(50000):
        stream.seek(index * RECORD.itemsize + 90)
        part = stream.read(tail_dtype.itemsize)
        assert len(part) == tail_dtype.itemsize
        start = index * tail_dtype.itemsize
        test_metadata[start : start + tail_dtype.itemsize] = part
test = np.frombuffer(test_metadata, dtype=tail_dtype)
halves = np.array([x["rows"] // 2 for x in source["files"]], dtype=np.uint32)
prior_codes, prior_bindings = [], []
for cycle in (41, 42, 43):
    path = Path(
        f"/workspaces/quoridor/.worktree/assets/inputs/sigma-public-fix-z/canonical-v3/cycle_{cycle:04d}/candidate-input-selection-frozen.json"
    )
    old = json.loads(path.read_text())
    attempt = cost["attempts"][cycle - 1]
    assert old["source_SHA"] == attempt["sha256"]
    indices = np.asarray(old["selected_original_indices"], dtype=np.uint64)
    prior_codes.append((np.uint64(cycle - 1) << np.uint64(32)) | indices)
    prior_bindings.append({"path": str(path), "sha256": sha(path), "rows": len(indices)})
prior_codes = np.concatenate(prior_codes)
all_codes, partitions = [], {}
known = np.unique(train["model_sha"].copy().view("V32").reshape(-1))
for split, (name, rows, descriptor) in enumerate(
    zip(("train", "validation", "test-sealed"), (train, validation, test), manifest["partitions"])
):
    assert np.all(rows["split"] == split) and np.all(rows["row"] == rows["alias"])
    assert np.all(rows["row"] < halves[rows["shard"]])
    codes = (rows["shard"].astype(np.uint64) << np.uint64(32)) | rows["row"]
    assert len(np.unique(codes)) == len(rows)
    all_codes.append(codes)
    keys = rows["model_sha"].copy().view("V32").reshape(-1)
    distinct = len(np.unique(keys))
    assert distinct == descriptor["model_input_distinct"]
    assert (
        len(np.unique(rows["input_sha"].copy().view("V32")))
        == descriptor["original_input_distinct"]
    )
    shard_counts = np.bincount(rows["shard"], minlength=43)
    assert shard_counts.tolist() == descriptor["per_shard"] and np.all(shard_counts > 0)
    partitions[name] = {
        "rows": len(rows),
        "original_observation_ids_distinct": len(rows),
        "model_input_distinct": distinct,
        "original_input_distinct": descriptor["original_input_distinct"],
        "train_known_input_rows": int(np.count_nonzero(np.isin(keys, known))),
        "known_prior_canonical_v3_selected_original_observations": int(
            np.count_nonzero(np.isin(codes, prior_codes))
        ),
        "past_unexposed_claim": False,
        "other_exposure_history": "UNKNOWN",
        "priority_ties": len(rows) - len(np.unique(rows["priority"])),
        "per_shard": shard_counts.tolist(),
        "phase_proxy": np.bincount(rows["phase"], minlength=3).tolist(),
        "retention_of_qualified_candidate_rows": len(rows) / manifest["qualified_counts"][split],
    }
assert len(np.unique(np.concatenate(all_codes))) == 1100000
ix_train = np.arange(1000000, dtype=np.int64)
statistics, unused_fit = training_statistics(corpus, ix_train, 1)
constant = float(np.mean(train["z"], dtype=np.float64))
scale = {
    **statistics,
    "binding": {
        "cache_manifest_sha": sha(root / "cache.json"),
        "train_partition_sha": manifest["partitions"][0]["sha256"],
        "rows": 1000000,
        "split": "train",
        "dataset_revision": "original-only-v2",
        "target": "z",
        "weighting": "row",
        "distance_order": "STM/opponent",
        "source": "maintained train.training_statistics, bounded4096, no old scale reuse",
    },
}
save(evidence / "train-only-scale-v2.json", scale)
save(
    evidence / "train-only-constant-v2.json",
    {
        "row_mean_constant": constant,
        "binding": scale["binding"],
        "fixed_distance": {"a": 0, "b": 8},
    },
)
feature, distance, labels = corpus.batch([1000000, 0, 999999, 1049999])
for index, row_index in enumerate((1000000, 0, 999999, 1049999)):
    record = corpus.record(row_index)
    np.testing.assert_array_equal(
        feature[index].reshape(-1), np.unpackbits(record["bits"], bitorder="little")
    )
    np.testing.assert_array_equal(distance[index], record["distance"])
    assert labels[index, 1] == record["z"] and np.isnan(labels[index, 0])
exclusion_dtype = np.dtype([("shard", "<u2"), ("row", "<u4"), ("z", "<f4"), ("reason", "u1")])
with gzip.open(root / "exclusions.bin.gz", "rb") as stream:
    exclusions = np.frombuffer(stream.read(8 * 1024**2), dtype=exclusion_dtype)
    assert not stream.read(1)
candidate_rows = sum(r["candidate_observations"] for r in cost["receipts"])
native_codes = np.sum([r["native_codes"] for r in cost["receipts"]], axis=0).tolist()
assert sum(native_codes) == candidate_rows
assert candidate_rows - len(exclusions) == sum(manifest["qualified_counts"])
label_counts = {
    k: sum(r["labels"][k] for r in cost["receipts"]) for k in cost["receipts"][0]["labels"]
}
assert int(np.count_nonzero(exclusions["z"] == 0)) == label_counts["zero_unknown_termination"]
constant_z_positive = int(np.count_nonzero(train["z"] == 1))
group_count = len(corpus.families)
positive = np.bincount(corpus.groups[:1000000], weights=train["z"] == 1, minlength=group_count)
negative = np.bincount(corpus.groups[:1000000], weights=train["z"] == -1, minlength=group_count)
cfg = resolve_config(evidence / "fit-config.json")
points = cfg["evaluation"]["checkpoints"]
full = cfg["evaluation"]["full_train_checkpoints"]
assert len(points) <= 250 and cfg["evaluation"]["monitor"] == "row"
maximum_rows = (
    20000000 + len(points) * 50000 + len(full) * 1000000 + (len(points) - len(full)) * 2048
)
corpus.verify_binding()
report = {
    "status": "PASS within data/caller qualification; live native model/GPU/fit/test pending",
    "cache_manifest_sha": corpus.manifest_sha,
    "full_source_saved_rows": sum(r["stored_rows"] for r in cost["receipts"]),
    "original_rows_decoded": cost["processed_rows"],
    "native_qualified_candidate_rows": candidate_rows,
    "native_code_counts": native_codes,
    "candidate_labels": label_counts,
    "excluded_observation_rows": len(exclusions),
    "exclusion_reason_counts": np.bincount(exclusions["reason"], minlength=9).tolist(),
    "partitions": partitions,
    "cross_split_original_observation_alias_overlap": 0,
    "train_positive": constant_z_positive,
    "train_negative": 1000000 - constant_z_positive,
    "train_input_groups_with_both_outcomes": int(np.count_nonzero((positive > 0) & (negative > 0))),
    "scale": scale,
    "row_mean_constant": constant,
    "fixed_distance": {"a": 0, "b": 8},
    "unused_train_least_squares_distance": unused_fit,
    "prior_selected_observation_manifests": prior_bindings,
    "eligible_unsampled_originals": "UNKNOWN; candidate denominator only",
    "independent_IID_inclusion_probability": "NOT_PROVEN",
    "sealed_labels_read": 0,
    "sealed_payload_SHA": "producer receipt only; not reopened for independent hashing",
    "curve_plan": {
        "points": len(points),
        "full_train_points": len(full),
        "maximum_all_forward_rows_including_train": maximum_rows,
        "steps_per_epoch": 7813,
        "last_batch_rows": 64,
        "actual_training_steps_seen_epochs": 0,
        "actual_curve_observations": 0,
    },
    "seconds": time.monotonic() - started,
    "peak_RSS_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
    "native_forward_GPU_build_job": 0,
}
save(evidence / "cache-qualification-v2.json", report)
save(
    evidence / "fit-input-binding-v2.json",
    {
        "cache": str(root),
        "cache_manifest_sha": corpus.manifest_sha,
        "fit_config": str(evidence / "fit-config.json"),
        "fit_config_sha": sha(evidence / "fit-config.json"),
        "scale_artifact": str(evidence / "train-only-scale-v2.json"),
        "scale_artifact_sha": sha(evidence / "train-only-scale-v2.json"),
        "constant_artifact_sha": sha(evidence / "train-only-constant-v2.json"),
        "trainer_checkpoint_binding": "dataset_sha + exact train-only scale embedded in INITIAL/BEST/LAST; future checkpoint/freeze not yet created",
        "fit_scale_override": "none; maintained caller recomputes same v2 train-only moments",
        "test_unseen_games": "UNKNOWN; heldout public observations only",
        "actual_fit_started": False,
    },
)
print(
    json.dumps(
        {
            k: report[k]
            for k in (
                "native_code_counts",
                "native_qualified_candidate_rows",
                "candidate_labels",
                "row_mean_constant",
                "seconds",
                "peak_RSS_bytes",
            )
        },
        indent=2,
    )
)
print(json.dumps(statistics))
print(
    json.dumps(
        {
            name: {k: v for k, v in part.items() if not isinstance(v, list)}
            for name, part in partitions.items()
        },
        indent=2,
    )
)
