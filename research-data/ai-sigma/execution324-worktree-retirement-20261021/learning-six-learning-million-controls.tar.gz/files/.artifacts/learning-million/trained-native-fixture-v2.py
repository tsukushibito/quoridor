"""Bounded existing-caller parity on frozen BEST; no fitting or sealed data."""

import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import time

import numpy as np

from quoridor_training.train import build_model, verify_freeze, verify_native_parameters
from quoridor_training.common import resolve_config
from quoridor_training.cycle_process import available_memory, alive, identity, process_info


def main():
    started = time.monotonic()
    os.sched_setaffinity(0, {2, 3})
    assert available_memory() > 6 * 1024**3
    root = Path(__file__).parent
    output = Path(
        "/workspaces/quoridor/.worktree/assets/checkpoints/public-million-learning/baseline-original-v2/output"
    )
    evidence = root / "trained-native-v2-r1" / "output"
    evidence.mkdir(exist_ok=False)
    binding = json.loads((root / "baseline-native-binding.json").read_text())
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    assert sha(binding["native_binary"]) == binding["native_binary_sha"]
    frozen = verify_freeze(output)
    config = resolve_config(output / "config.json")
    native = {
        "mode": "diagnose",
        "output": str(evidence / "native.json"),
        "counter": str(evidence / "counter.json"),
        "prefixes": [
            [],
            [13, 67, 81, 66, 14, 65],
            [13, 67, 81, 66, 14, 65, 143, 126, 150, 64, 141, 151],
        ],
        "engines": [
            {
                "id": "frozen-best",
                "kind": "distance_residual",
                "manifest": str(output / "best-model/manifest.json"),
            }
        ],
        "depths": [],
        "max_nodes": 1,
        "nn_cap": 512,
        "processed_cap": 128,
        "wall_seconds": 3,
        "max_plies": 0,
        "cpu_core": 2,
        "ram_limit": 512 * 1024**2,
        "host_ram_reserve": 4 * 1024**3,
    }
    path = evidence / "config.json"
    path.write_text(json.dumps(native, indent=2) + "\n")
    child = subprocess.Popen(
        [binding["native_binary"], "--config", str(path)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    child_identity = identity(process_info(child.pid))
    try:
        stdout, stderr = child.communicate(timeout=5)
    finally:
        if child.poll() is None:
            child.kill()
            child.wait()
    (evidence / "process.json").write_text(
        json.dumps(
            {
                "returncode": child.returncode,
                "child": child_identity,
                "direct_child_waited": True,
                "stdout": stdout[-4096:],
                "stderr": stderr[-4096:],
                "exact_identity_absent": child_identity is None or not alive(child_identity),
            },
            indent=2,
        )
        + "\n"
    )
    if child.returncode:
        raise RuntimeError("native diagnostic refusal: " + stderr[-4096:])
    result = json.loads((evidence / "native.json").read_text())
    x, d, side, values = [], [], [], []
    for row in result["predictions"]:
        f = row["feature"]
        if row.get("terminal") is not None or f.get("terminal") is not None:
            continue
        features = np.zeros((2, 312), dtype=np.float32)
        for view, ids in enumerate(f["ids"]):
            features[view, ids] = 1
        x.append(features)
        d.append(f["distance"])
        side.append(f["side"] + 1)
        values.append(row["full"] if "full" in row else row["values"][0]["value"])
    import torch

    torch.set_num_threads(2)
    torch.set_num_interop_threads(2)
    checkpoint_checks = {}
    statistics = json.loads((output / "scale.json").read_text())
    for name in ("initial", "best", "last"):
        cp = torch.load(output / (name + ".pt"), map_location="cpu", weights_only=True)
        assert cp["dataset_sha"] == frozen["dataset_sha"] and cp["scale"] == statistics
        verify_native_parameters(output / (name + "-model/weights.f32"), cp["model"])
        checkpoint_checks[name] = {
            "dataset_scale_bound": True,
            "native_parameter_bytes_match_checkpoint": True,
        }
    model = build_model(config["model"], statistics)
    model.load_state_dict(
        torch.load(output / "best.pt", map_location="cpu", weights_only=True)["model"]
    )
    model.eval()
    with torch.inference_mode():
        predicted = model(
            torch.from_numpy(np.asarray(x)),
            torch.tensor(d, dtype=torch.float32),
            torch.tensor(side),
        ).numpy()
    maximum = float(np.max(np.abs(predicted - np.asarray(values))))
    assert maximum < 2e-6
    assert set(side) == {1, 2} and result["parent_history_preserved"]
    children = [r for r in result["predictions"] if "full" in r]
    assert children and all(
        r["parent_preserved"] and abs(r["full"] - r["delta"]) < 2e-6 for r in children
    )
    report = {
        "status": "PASS_LIMITED",
        "freeze_sha": sha(output / "freeze.json"),
        "native_binary_sha": binding["native_binary_sha"],
        "checkpoint_checks": checkpoint_checks,
        "trained_native_scalar_full_delta_CPU_max_error": maximum,
        "trained_rows_P1_P2": len(values),
        "native_NN_calls": result["NN"],
        "CPU_model_forwards": len(values),
        "full_delta_children": len(children),
        "parent_history_preserved": True,
        "best_last_same_weights_coverage": sha(output / "best-model/weights.f32")
        == sha(output / "last-model/weights.f32"),
        "initial_same_weights_as_accepted_GPU_qualification": True,
        "explicit_Scalar_SIMD_and_inplace_undo": "NOT_VERIFIED: immutable diagnose supports Scalar full/delta and immutable parent/history, no explicit SIMD or inplace undo switch",
        "build_GPU_search_arena_fit_sealedtest": 0,
        "wall_seconds": time.monotonic() - started,
        "child_peak_RSS_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "timing_use": "bounded qualification cost, no performance comparison",
    }
    (evidence / "result.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
