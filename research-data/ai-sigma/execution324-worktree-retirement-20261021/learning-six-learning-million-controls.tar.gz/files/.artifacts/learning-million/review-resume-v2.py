"""Same reviewer, same remaining budget, explicit full-access resume."""

import asyncio
import importlib.util
import json
from pathlib import Path

checkout = Path("/workspaces/quoridor/.worktree/learning-million")
metadata = checkout / ".artifacts/learning-million"
spec = importlib.util.spec_from_file_location(
    "session", checkout / "scripts/dev/research-session.py"
)
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)


async def main():
    root = Path("/workspaces/quoridor")
    thread = "01a1103c-fbe0-7412-a406-fbee697a1392"
    client.require_owner("quoridor-4lc.319.1", root, thread)
    host = client.command_json(["codex", "app-server", "daemon", "version"])
    async with client.AppServer(host) as server:
        with client.dispatch_lock(root):
            state = await server.read_thread(thread)
            if state["status"]["type"] != "active":
                response = await server.request(
                    "thread/resume",
                    {
                        "threadId": thread,
                        "excludeTurns": True,
                        "sandbox": "danger-full-access",
                        "approvalPolicy": "never",
                    },
                )
                applied = {
                    k: response.get(k)
                    for k in ["sandbox", "approvalPolicy", "model", "reasoningEffort", "cwd"]
                }
                applied["thread_id"] = thread
                assert (
                    applied["sandbox"]["type"] == "dangerFullAccess"
                    and applied["approvalPolicy"] == "never"
                )
                assert applied["cwd"] == str(checkout)
            else:
                applied = json.loads((metadata / "review-permissions.json").read_text())
                applied["active_existing_creation_permissions"] = True
            (metadata / "review-permissions-v2.json").write_text(
                json.dumps(applied, indent=2) + "\n"
            )
            body = (
                "Beads issue: quoridor-4lc.319.1\nTask cwd: "
                + str(checkout)
                + "\n\n"
                + (metadata / "review-followup-v2.md").read_text()
            )
            result = await server.deliver(thread, body, str(checkout))
            (metadata / "review-delivery-v2.json").write_text(json.dumps(result, indent=2) + "\n")
            print(json.dumps(result))


asyncio.run(main())
