"""One explicit-permission saved review task; no server or recursive dispatch."""

import asyncio
import importlib.util
import json
from pathlib import Path

checkout = Path("/workspaces/quoridor/.worktree/learning-million")
metadata = checkout / ".artifacts/learning-million"
spec = importlib.util.spec_from_file_location(
    "session", checkout / "scripts/dev/research-session.py"
)
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)


async def main():
    root = Path("/workspaces/quoridor")
    issue = json.loads((metadata / "review-issue.json").read_text())["id"]
    original = client.creation_issue(issue, root)
    host = client.command_json(["codex", "app-server", "daemon", "version"])
    async with client.AppServer(host) as server:
        with client.dispatch_lock(root):
            response = await server.request(
                "thread/start",
                {
                    "cwd": str(checkout),
                    "ephemeral": False,
                    "sandbox": "danger-full-access",
                    "approvalPolicy": "never",
                },
            )
            thread = response["thread"]["id"]
            applied = {
                k: response.get(k)
                for k in ["sandbox", "approvalPolicy", "model", "reasoningEffort", "cwd"]
            }
            applied["thread_id"] = thread
            (metadata / "review-permissions.json").write_text(json.dumps(applied, indent=2) + "\n")
            assert response.get("approvalPolicy") == "never", applied
            assert response.get("sandbox", {}).get("type") == "dangerFullAccess", applied
            assert response.get("cwd") == str(checkout), applied
            client.assign_created_issue(issue, root, original, thread)
            body = (
                f"Beads issue: {issue}\nTask cwd: {checkout}\n\n"
                + (metadata / "review-task.md").read_text()
            )
            result = await server.request(
                "turn/start",
                {
                    "threadId": thread,
                    "cwd": str(checkout),
                    "input": [{"type": "text", "text": body, "text_elements": []}],
                },
            )
            receipt = {
                "issue": issue,
                "thread_id": thread,
                "turn_id": result.get("turn", {}).get("id"),
                "accepted": True,
                "permissions": applied,
            }
            (metadata / "review-delivery.json").write_text(json.dumps(receipt, indent=2) + "\n")
            print(json.dumps(receipt))


asyncio.run(main())
