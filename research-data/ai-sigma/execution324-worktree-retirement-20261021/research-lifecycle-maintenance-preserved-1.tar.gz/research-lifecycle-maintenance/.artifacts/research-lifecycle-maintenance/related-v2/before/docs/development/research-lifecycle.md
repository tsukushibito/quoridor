# Research build, manifest, run and finalization

`scripts/dev/research-lifecycle.py` is the maintained entry for the current 355 campaign. It replaces the historical software-v4–v19 classifier/salvage path. Those artifacts, failures, fees and private images remain historical evidence; they are not prospective prerequisites. No source-review chain, diagnostic-span/count whitelist, transitive C/Make/header reconstruction, model copy or second scheduler is used.

A normal trusted offline Cargo build runs under frozen authored source, the adopted commit and necessary patch, Cargo.lock/dependency references, absolute tool identities/versions, features/flags and relevant environment. Generated outputs are protected by the isolated owned target and one writer. Cargo JSON `build-finished.success=true`, actual exit 0, returned guardian cleanup and structured runner executable artifacts are required. Multiple primary warning spans are ordinary Cargo output, preserved in the full bounded log. Clippy uses the ordinary affected scope with `-Dwarnings`; code must be repaired or an explicitly justified temporary code exception must name its retirement. There are no comparison-only diagnostic exceptions.

## Public commands and ownership

Submit one frozen build/run intent through existing `research-job.sh`; its `argv` is:

```text
ABS_PYTHON -B ABS/scripts/dev/research-lifecycle.py build --intent ABS_INTENT --sha256 SHA
ABS_PYTHON -B ABS/scripts/dev/research-lifecycle.py run --intent ABS_INTENT --sha256 SHA
```

The job passes its directory in `QUORIDOR_RESEARCH_JOB_DIR`; the child verifies its actual supervisor identity. `cycle_process.execute` remains the sole child guardian, extended with `cwd`, exact `env` and a bounded byte sink. Every command returns directwait, descendant/handle cleanup, mask restoration and final receipt persistence facts. Disk process records that still say pending/attempted are not substituted for returned facts. The scientific caller is a child of this guardian, not a separate lifecycle.

After the outer research-job has finished, the owner invokes:

```text
ABS_PYTHON -B ABS/scripts/dev/research-lifecycle.py finalize --operation ABS_OPERATION --job-result ABS_RESULT --sha256 SHA
```

`finalize` launches no child. It matches the actual job config to the admitted intent, checks the outer result/cleanup, checks durable data and all predeclared independent finalizers, and publishes `manifest.json`. `candidate.json` is always provisional. Readers refuse an `INCOMPLETE` marker even if a manifest file exists. All files and directory sync/close obligations precede the final marker unlink. No fallible report or cleanup operation follows that commit in the collector. A crash/durability guarantee or all-channel error recovery is not claimed.

Exclusive operation directories refuse a duplicate/restarted submit. An exclusive `finalizing` marker prevents repeating independent finalizers. Missing completion is UNKNOWN; a failed/cancelled completion is never reusable as a successful build. The original exception object is re-raised with independent capture/publication/cleanup failures attached. Partial scientific files/censuses remain available, while unpublished/missing work stays UNKNOWN. No automatic retries or salvage promotion occur.

The canonical nonblocking `/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock` covers admission, source checks, imports/TMP/children, waits and the critical data checks. No queue or idle lease is taken. The whole source/target/private/TMP/output allocation, family RSS including controller reserve, host reserve, FS and actual physical cores are checked. A current named compiler/game/browser peer refuses entry; any genuinely READY higher-priority science is honored by the owner before submission. Instantaneous scans are not future quiet certificates.

Only arena355.1 owns the one common target/private pool. The Root handover supplies literal target ownership and old-target retirement, without replaying its historical certificate chain. The stable new target has a writer/support marker and may be reused by the same writer for an ordinary affected rebuild; a foreign/unmarked target is refused. A fresh private filename preserves previous images, within the shared private cap. Maintenance does not create this target or execute Cargo before source acceptance and current admission.

## Bound files and schemas

Every persisted reference is `{path, sha256, bytes, mode}`: canonical absolute path, lowercase SHA256, exact length and a four-digit octal custody mode. Model manifests retain their actual modes, including BEST43 `0600`. `BoundControl` fields inside native configurations retain their existing `{path, sha256}` shape. They are joined to the full experiment references, not substituted for them.

- `quoridor.research.lifecycle-intent.v1`: `kind`, `owner`, `writer` for build, `cwd`, `output`, `env`, `limits`, bound `support`, bound `admission`, `intent_sha256`, `finalizers`; build adds `source`, `source_adoption`, `target_handover`, `target`, `private`, `TMP`, `tools`, `dependency_refs`, `commands`; run adds `experiment`, `artifact`, `argv`, `data_root`, `data`.
- `source`: `commit`, nullable bound `patch`, exact `files` references. Root `quoridor.research.source-adoption.v1` records `status=ACCEPTED` and this exact source once, at adoption. It is recorded in the build; it is not recursively executed per run.
- `tools`: names `CARGO`, `RUSTC`, `RUSTDOC`, `CC`, `CXX`, `AR`, and `PYTHON` when saved-only analysis is needed, each `{file, version_args, version}`. Versions are obtained by guarded finite commands. Environment is explicit, including offline/no-install/j1/incremental0 and opt3/debug0. Relevant dynamically loaded libraries have exact files and version strings in the experiment; there is no blanket dependency exemption.
- `commands`: `{name, role, argv}`, with test/lint/build/bindings roles. Cargo commands are `test`/`clippy`/`build`, `--offline --locked -j1 --message-format=json-render-diagnostics`; no `cargo run`, extra workload or lint-allow workaround is admitted. Bindings is the actual copied runner's `research-bindings` port.
- `limits`: `family_B`, `controller_B=67108864`, `host_reserve_B`, `owned_B`, `log_B`, `free_B`, `worker_cpu`, `guardian_cpu`. Issued phase admission binds these, `owner`, exact support SHA and canonical intent digest. The digest is the sorted compact JSON of the intent excluding only `admission` and `intent_sha256`, avoiding self-reference. Family maxima are 6GiB build/2GiB native, with at least 4GiB host reserve. These are refusal bounds, not predicted peaks or science horizons.
- `quoridor.research.build-manifest.v1`: `kind=build`, final `status`, `artifact`, `compiled_sources`, `source`, source-adoption reference, tools/env/dependencies, checks with actual returned guardian/full-log/Cargo facts, `outer_job_result`, cleanup/remaining, original/secondary errors and exact completion times. Only PASS with no marker admits RUN. This is the single artifact acceptance manifest.
- `quoridor.research.experiment.v1`: `phase`, bound `build_manifest`, `config`, `inputs`, `models`, `dynamic_libraries`, `schedule`, `numerical_qualification`, `canonical_plan_sha256`, `rules`, `distance_units`, `value_perspective`, `planned_slots`, nullable `batch`, exact `argv` template. Only `@EXPERIMENT@` and `@EXPERIMENT_SHA256@` are replaced with the actual bound envelope path/SHA; this avoids a self-referential SHA while the run intent freezes the full resulting argv. Phases are generation/materialize/compare/arena, or saved-only analysis. Models are `{descriptor, weights, evaluator_sha256}`; libraries are `{file, version}`. No models/cache are copied.
- `quoridor.research.numerical-qualification.v1`: actual `status=PASS`, exact `phase`, artifact/compiled-source/config/schedule/input/descriptor/weights/evaluator SHA bindings, rules, distance units, STM perspective, `remaining=[]`; compare additionally records qualified generation-source digest. It retains current numerical/history/clock qualification. The source build does not mint it.
- `quoridor.research.completion.v1`: `kind=run`, final status, experiment/build references, actual returned checks, `data` with bound durable files and partial census, outer job/finalizer facts, original/secondary errors, cleanup and times. It is an operation completion, not an independent strength certificate.

`data` intent declarations are `{name, path, limit_B}` and `data_root` is a fresh owned output. For a 355 arena operation, `journal` and `result` are mandatory. The native journal is streamed without substituting console data: full per-game moves/observations, unique local game, global family through config opening references, schedule colour, complete local batch and result correspondence are checked. The global denominator is always 512; a batch has 32 rows and never sets `global_campaign_complete=true`. Failed/partial files remain referenced; missing planned slots remain UNKNOWN. Native statuses `goal`, `draw`, `forfeit`, `unknown` are preserved, without inventing a timeout-forfeit rule.

Additional owed independent finalizers are optional predeclared `{kind: data|journal, path, limit_B}` and must produce actual bound `quoridor.research.data-finalizer.v1` receipts with PASS, remaining[], same actual intent SHA and full file references. Every obligation is attempted independently, even after another fails. They do not replace the mandatory native journal collector or require a new review per run.

## Native caller migration

The new ports use `--experiment ABS --experiment-sha256 SHA`:

```text
quoridor-runner strength-book ...
quoridor-runner strength-configs ...
quoridor-runner strength-arena ...
quoridor-runner value-search-compare ...
```

`research-bindings` is the single zero-model compiled-source/artifact port. Generic `arena --config` refuses a strength355 batch so it cannot bypass this entry. Ordinary other arena/selfplay controls remain supported.

The compare config is `quoridor.value-search-strength.compare.v2`: canonical plan/resources/book/manifests/output, with the old recursive `qualification` field removed. The experiment binds that config externally, avoiding a config↔qualification hash cycle. Its intent header is v2 with separate experiment and config SHA plus build reference; scientific result/failure/row/tree/PV/census envelopes remain v1 and keep their original actual/partial work domains.

Generation request replaces `old_admission` with `old_prefixes`, a bound JSON array of the SAME eight preserved OPEN prefixes. Its canonical scientific prefix digest, rejection logic, RNG and all128 family selection are unchanged. Materialization keeps book/templates/descriptors/weights/output; it binds the same experiment models and current image. The arena entry rederives only the maintained batch config from the current book and refuses any settings/model/colour drift before runtime. No copied engine, alternate evaluator, TT change, rule/clock change or automatic calibration is introduced.

Saved-only analysis uses the same accepted build and experiment manifest, with `phase=analysis`, a pinned Python tool from the build, exact inputs/config/argv and fresh report output. It is run by this same guardian. The child receives `QUORIDOR_LIFECYCLE_INTENT` and `QUORIDOR_LIFECYCLE_PARENT_PID`; it validates the maintained caller context and must not reacquire the canonical lease. No new registry, nested lock, build target or native/model call is needed for that saved phase.

Frozen science remains 128 families/512 colour slots, matched32/96 COMPLETE4 calls,8 ALLlegal depth2 trees and at most16 prebound differing parents/192 stronger calls. D is maintained `(0,8)` tanh of normalized wall distance; BEST51 and BEST43 exact descriptors/weights/coefficients are unchanged. Standard2p goal-first/legal-third/200 UNKNOWN, 100ms authority receipt/5ms reserve, legality outside, matching drain, PVS/fullwidth/TT4096/1MiB, ScalarFT/guarded head and thread1 remain unchanged. No N/fit/default/seal/pause323 decision is altered.
