#!/usr/bin/env python3
"""One trusted build manifest and experiment entry, under research-job/cycle_process."""

from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
from quoridor_training import cycle_process as process  # noqa: E402

LEASE = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
BUILD_SCHEMA = "quoridor.research.build-manifest.v1"
EXPERIMENT_SCHEMA = "quoridor.research.experiment.v1"
COMPLETION_SCHEMA = "quoridor.research.completion.v1"
CONTROL_BYTES = 1024 * 1024


class Refused(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Refused(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stamp():
    return datetime.now(timezone.utc).isoformat()


def error_fact(error):
    try:
        message = str(error)
    except BaseException:
        message = "<exception stringification failed>"
    fact = {
        "type": type(error).__name__,
        "message": message[:8192],
        "notes": list(getattr(error, "__notes__", [])),
    }
    if isinstance(error, BaseExceptionGroup):
        fact["errors"] = [error_fact(e) for e in error.exceptions]
    return fact


def bound(path, limit=CONTROL_BYTES):
    """No symlinks or re-open-after-admission; hash precisely the admitted bytes."""
    path = Path(path)
    require(path.is_absolute(), "absolute reference required")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as f:
        info = os.fstat(f.fileno())
        require(stat.S_ISREG(info.st_mode) and info.st_size <= limit, "reference size/type")
        data = f.read(limit + 1)
        require(len(data) == info.st_size and len(data) <= limit, "reference changed/oversize")
    return {
        "path": str(path),
        "sha256": sha(data),
        "bytes": len(data),
        "mode": format(stat.S_IMODE(info.st_mode), "04o"),
    }, data


def read_ref(ref, limit=CONTROL_BYTES):
    require(
        isinstance(ref, dict) and set(ref) == {"path", "sha256", "bytes", "mode"},
        "bound descriptor",
    )
    actual, data = bound(ref["path"], limit)
    require(actual == ref, "reference drift: " + ref["path"])
    return data


def document(ref):
    return json.loads(read_ref(ref))


def new_json(path, value):
    data = (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()
    require(len(data) <= CONTROL_BYTES, "control publication cap")
    with Path(path).open("xb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())


def allocated(path):
    total = 0
    pending = [Path(path)]
    while pending:
        base = pending.pop()
        try:
            info = base.lstat()
        except FileNotFoundError:
            continue
        require(not stat.S_ISLNK(info.st_mode), "owned namespace symlink")
        total += info.st_blocks * 512
        if stat.S_ISDIR(info.st_mode):
            with os.scandir(base) as entries:
                pending.extend(Path(e.path) for e in entries)
    return total


def owned(path, owner):
    path, owner = Path(path), Path(owner)
    require(
        path.is_absolute() and owner.is_absolute() and path.is_relative_to(owner), "write ownership"
    )
    require(path != owner, "exclusive operation must be below owner")
    require(path.resolve() == path, "write path symlink/normalization")
    return path


@contextmanager
def lease():
    with LEASE.open("a") as f:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


class Limits(process.CycleResources):
    """Reuse guardian RSS/deadline/pause; add owned positive allocation bounds."""

    def __init__(self, spec):
        self.spec = spec
        cfg = spec["limits"]
        for name in ("family_B", "host_reserve_B", "owned_B", "log_B", "free_B"):
            require(type(cfg[name]) is int and cfg[name] > 0, "positive priced limit: " + name)
        require(
            cfg["family_B"] <= (6 if spec["kind"] == "build" else 2) * 1024**3
            and cfg["host_reserve_B"] >= 4 * 1024**3,
            "issued family/host envelope",
        )
        support = document(spec["support"])
        require(support["funded_union_B"] == 4294967296, "issued whole355 support")
        require(support["global_held_B"] <= 50000000000, "global holding")
        # Admission is issued phase-specific support, not a default scientific horizon.
        admission = document(spec["admission"])
        require(admission["schema"] == "quoridor.research.phase-admission.v1", "phase admission")
        require(
            admission["owner"] == spec["owner"] and admission["limits"] == cfg,
            "issued owner/limits",
        )
        require(admission["spec_sha256"] == spec["intent_sha256"], "actual intent admission")
        require(admission["support_sha256"] == spec["support"]["sha256"], "same support")
        require(admission["ready"] is True, "phase not admitted")
        require(cfg["controller_B"] == 64 * 1024 * 1024, "whole family includes controller")
        self.charged_paths = [Path(spec["output"])]
        if spec["kind"] == "build":
            self.charged_paths += [
                Path(spec["target"]),
                Path(spec["private"]).parent,
                Path(spec["TMP"]),
            ]
        super().__init__(
            {
                "host_ram_reserve": cfg["host_reserve_B"],
                "max_memory_bytes": cfg["family_B"] - cfg["controller_B"],
                "max_output_bytes": cfg["owned_B"],
                "pause_file": spec.get("pause_file"),
            },
            spec["output"],
            None,
        )

    def check(self, children=()):
        super().check(children)
        require(
            sum(allocated(p) for p in self.charged_paths) <= self.spec["limits"]["owned_B"],
            "owned allocation limit",
        )
        require(
            shutil.disk_usage(self.spec["owner"]).free >= self.spec["limits"]["free_B"],
            "FS reserve",
        )
        if self.spec["kind"] == "build":
            h = document(self.spec["target_handover"])
            require(allocated(self.spec["target"]) <= h["target_max_B"], "target cap")
            private = allocated(Path(self.spec["private"]).parent)
            require(
                private <= h["fresh_private_forward_max_B"]
                and private + h["old_private_retained_allocated_B"] <= h["private_pool_B"],
                "retained private pool cap",
            )
            require(allocated(self.spec["TMP"]) <= 64 * 1024 * 1024, "TMP cap")


def physical_and_quiet(spec):
    cfg = spec["limits"]
    require(
        process.available_memory() >= cfg["family_B"] + cfg["host_reserve_B"],
        "physical RAM admission",
    )
    cores = [cfg["worker_cpu"], cfg["guardian_cpu"]]
    require(set(cores) <= os.sched_getaffinity(0), "CPU affinity admission")
    identities = []
    for core in cores:
        p = Path(f"/sys/devices/system/cpu/cpu{core}/topology")
        identities.append(((p / "physical_package_id").read_text(), (p / "core_id").read_text()))
    require(identities[0] != identities[1], "worker/guardian must be distinct physical cores")
    # One instantaneous named scan. Lifetime conflicts serialize through the shared lease.
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            args = (entry / "cmdline").read_bytes().split(b"\0")
        except OSError:
            continue
        if args and Path(os.fsdecode(args[0])).name in {
            "cargo",
            "rustc",
            "cc1plus",
            "quoridor-runner",
            "chromium",
            "chrome",
        }:
            raise Refused("named compute peer active: " + entry.name)
    os.sched_setaffinity(0, {cfg["guardian_cpu"]})


class Capture:
    """Full bounded bytes. Console tail is never executable/census evidence."""

    def __init__(self, path, limit):
        self.path, self.limit, self.seen = Path(path), limit, 0
        self.file = self.path.open("xb")

    def __call__(self, data):
        require(self.seen + len(data) <= self.limit, "full command capture limit")
        self.file.write(data)
        self.seen += len(data)

    def close(self):
        errors = []
        for fn in (self.file.flush, lambda: os.fsync(self.file.fileno()), self.file.close):
            try:
                fn()
            except BaseException as error:
                errors.append(error)
        if errors:
            raise BaseExceptionGroup("capture finalizers", errors)


def cargo_report(data):
    artifacts, warnings, finished = [], [], []
    for line in data.splitlines():
        try:
            item = json.loads(line)
        except ValueError:
            continue  # Human diagnostics/test output are preserved verbatim in the full log.
        if not isinstance(item, dict):
            continue
        reason = item.get("reason")
        if reason == "compiler-message" and item.get("message", {}).get("level") == "warning":
            warnings.append(item)
        elif reason == "compiler-artifact" and item.get("executable"):
            artifacts.append(item)
        elif reason == "build-finished":
            finished.append(item.get("success"))
    require(finished == [True], "normal Cargo completion missing/failed")
    return {"artifacts": artifacts, "warning_count": len(warnings)}


def settled(record):
    require(
        record.get("status") == "complete" and record.get("exit_code") == 0,
        "command not successful",
    )
    require(
        record.get("direct_child_reaped") is True and record.get("cleanup_complete") is True,
        "directwait/cleanup incomplete",
    )
    require(
        record.get("remaining") == [] and record.get("finalization_errors", []) == [],
        "remaining/finalizers",
    )
    require(
        record.get("signal_mask_restoration") == "completed"
        and record.get("final_record_persist") == "completed",
        "returned guardian finalization incomplete",
    )


def command(spec, row, directory, resources, executor=process.execute):
    capture = Capture(directory / (row["name"] + ".full.log"), spec["limits"]["log_B"])
    primary, record = None, None
    try:
        record = executor(
            row["argv"],
            directory / (row["name"] + ".log"),
            None,
            cpu_core=spec["limits"]["worker_cpu"],
            resources=resources,
            cwd=spec["cwd"],
            env=spec["env"],
            output_sink=capture,
        )
        settled(record)
    except BaseException as error:
        primary = error
    try:
        capture.close()
    except BaseException as error:
        if primary is not None:
            primary.add_note("capture secondary: " + repr(error))
        else:
            primary = error
    if primary is not None:
        raise primary
    return record, capture.path


def source_check(source):
    require(
        len(source["commit"]) == 40 and all(c in "0123456789abcdef" for c in source["commit"]),
        "frozen source commit",
    )
    for ref in source["files"]:
        read_ref(ref, max(CONTROL_BYTES, ref["bytes"]))
    if source["patch"] is not None:
        read_ref(source["patch"])


def accepted_build(ref):
    manifest = document(ref)
    require(not Path(ref["path"]).with_name("INCOMPLETE").exists(), "provisional manifest")
    require(
        manifest["schema"] == BUILD_SCHEMA and manifest["status"] == "PASS",
        "accepted build required",
    )
    require(
        manifest["cleanup_complete"] is True and manifest["remaining"] == [],
        "build completion required",
    )
    require(
        {r["role"] for r in manifest["checks"]} >= {"test", "lint", "build", "bindings"},
        "affected test/lint/build/bindings required",
    )
    read_ref(manifest["artifact"], 32 * 1024 * 1024)
    source_check(manifest["source"])
    for r in manifest["dependency_refs"]:
        read_ref(r, max(CONTROL_BYTES, r["bytes"]))
    return manifest


def experiment_check(spec):
    experiment = document(spec["experiment"])
    require(experiment["schema"] == EXPERIMENT_SCHEMA, "experiment schema")
    manifest = accepted_build(experiment["build_manifest"])
    require(manifest["artifact"] == spec["artifact"], "same actual executable")
    source_check(manifest["source"])
    refs = [
        experiment["config"],
        *experiment["inputs"],
        experiment["schedule"],
        experiment["numerical_qualification"],
    ]
    for model in experiment["models"]:
        refs.extend([model["descriptor"], model["weights"]])
    for library in experiment["dynamic_libraries"]:
        require(bool(library["version"]), "dynamically loaded library version required")
        refs.append(library["file"])
    refs.extend(
        [
            experiment["build_manifest"],
            manifest["artifact"],
            *manifest["source"]["files"],
            *manifest["dependency_refs"],
        ]
    )
    for ref in refs:
        read_ref(ref, max(CONTROL_BYTES, ref["bytes"]))
    require(experiment["planned_slots"] in (0, 512), "planned512 or non-game stage")
    executable = manifest["artifact"]["path"]
    if experiment["phase"] == "analysis":
        python = manifest["tools"]["PYTHON"]["file"]
        read_ref(python, max(CONTROL_BYTES, python["bytes"]))
        executable = python["path"]
    require(spec["argv"][0] == executable, "executable argv drift")
    expected_argv = [
        a.replace("@EXPERIMENT@", spec["experiment"]["path"]).replace(
            "@EXPERIMENT_SHA256@", spec["experiment"]["sha256"]
        )
        for a in experiment["argv"]
    ]
    require(spec["argv"] == expected_argv, "exact experiment argv")
    require(bool(spec["data"]), "actual durable data required")
    owned(spec["data_root"], spec["owner"])
    require(
        not Path(spec["data_root"]).exists(), "exclusive scientific output; duplicate run refused"
    )
    if experiment["planned_slots"] == 512:
        require(
            {x["name"] for x in spec["data"]} >= {"journal", "result"},
            "mandatory scientific journal/result",
        )
    for finalizer in spec["finalizers"]:
        owned(finalizer["path"], spec["owner"])
    return experiment, manifest, refs


def build_check(spec):
    require(Path(spec["target"]).is_relative_to(Path(spec["owner"])), "isolated owned target")
    for name in ("target", "TMP", "private"):
        owned(spec[name], spec["owner"])
        if name != "target":
            require(not Path(spec[name]).exists(), "exclusive build ownership: " + name)
    if Path(spec["target"]).exists():
        owner = json.loads((Path(spec["target"]) / ".research-owner.json").read_bytes())
        require(
            owner
            == {
                "writer": spec["writer"],
                "target": spec["target"],
                "support_sha256": spec["support"]["sha256"],
            },
            "existing isolated target belongs to another owner",
        )
    handover = document(spec["target_handover"])
    require(
        handover["schema"] == "research.target-handover.v1" and handover["status"] == "HANDED_OVER",
        "serial target handover required",
    )
    require(
        handover["target"] == spec["target"] and handover["owned_remaining"] == [],
        "target handover identity",
    )
    require(
        handover["shared_serial_pool"] is True and not Path(handover["old_target"]).exists(),
        "old/new parallel target unsupported",
    )
    require(
        spec["limits"]["owned_B"] <= 1073741824 + 33554432 + 67108864 + 8388608,
        "common build/private pool",
    )
    require(
        handover["target_writer"] == spec["writer"]
        and handover["target_max_B"] == 1073741824
        and handover["private_pool_B"] == 33554432,
        "single issued writer/pool",
    )
    adoption = document(spec["source_adoption"])
    require(
        adoption["schema"] == "quoridor.research.source-adoption.v1"
        and adoption["status"] == "ACCEPTED",
        "one source adoption required",
    )
    require(adoption["source"] == spec["source"], "accepted frozen source/patch")
    source_check(spec["source"])
    require(
        any(Path(ref["path"]).name == "Cargo.lock" for ref in spec["dependency_refs"]),
        "frozen Cargo.lock required",
    )
    for ref in spec["dependency_refs"]:
        read_ref(ref, max(CONTROL_BYTES, ref["bytes"]))
    env = spec["env"]
    require(
        env["CARGO_TARGET_DIR"] == spec["target"] and env["TMPDIR"] == spec["TMP"], "isolated env"
    )
    require(
        env["CARGO_NET_OFFLINE"] == "true" and env["RUSTUP_AUTO_INSTALL"] == "0",
        "offline/no install",
    )
    require(
        env["CARGO_BUILD_JOBS"] == "1" and env["CARGO_INCREMENTAL"] == "0", "serial bounded build"
    )
    require(
        env["CARGO_PROFILE_RELEASE_OPT_LEVEL"] == "3" and env["CARGO_PROFILE_RELEASE_DEBUG"] == "0",
        "frozen release flags",
    )
    for key in ("RUSTC", "RUSTDOC", "CC", "CXX", "AR"):
        require(env[key] == spec["tools"][key]["file"]["path"], "pinned relevant tool env")
    require(
        {c["role"] for c in spec["commands"]} >= {"test", "lint", "build", "bindings"},
        "one affected qualification",
    )
    names = [c["name"] for c in spec["commands"]]
    require(
        len(names) == len(set(names)) and all(n.replace("-", "").isalnum() for n in names),
        "unique safe command names",
    )
    for c in spec["commands"]:
        require(
            c["role"] in {"test", "lint", "build", "bindings"}, "affected software commands only"
        )
        if c["role"] != "bindings":
            a = c["argv"]
            require(a[0] == spec["tools"]["CARGO"]["file"]["path"], "trusted Cargo argv")
            require(
                a[1] == {"test": "test", "lint": "clippy", "build": "build"}[c["role"]],
                "no cargo-run/extra workload in software phase",
            )
            require(
                "--offline" in a
                and "--locked" in a
                and "-j1" in a
                and "--message-format=json-render-diagnostics" in a,
                "Cargo pinned command/JSON",
            )
            require(
                not any(x.startswith("-A") or x.startswith("--allow") for x in a),
                "no compiler/lint allowance workaround",
            )
            if c["role"] == "lint":
                require(
                    "-Dwarnings" in a and "--no-deps" in a,
                    "ordinary scoped Clippy with warnings denied",
                )


def copy_artifact(src, dst):
    desc, data = bound(src, 32 * 1024 * 1024)
    with Path(dst).open("xb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    Path(dst).chmod(int(desc["mode"], 8))
    return bound(dst, 32 * 1024 * 1024)[0]


def collect_data(spec, experiment):
    """Preserve actual durable files and partial facts; never substitute a console tail."""
    data = {
        "status": "PASS",
        "files": [],
        "errors": [],
        "planned_slots": experiment["planned_slots"],
        "observed_local_games": [],
        "missing_local_games": [],
        "batch": experiment.get("batch"),
        "global_campaign_complete": False,
    }
    values = {}
    for item in spec["data"]:
        try:
            owned(item["path"], spec["owner"])
            ref, raw = bound(item["path"], item["limit_B"])
            data["files"].append(ref)
            values[item["name"]] = raw
        except BaseException as error:
            data["errors"].append({"stage": item["name"], **error_fact(error)})
    if experiment["planned_slots"] == 512:
        try:
            schedule = document(experiment["schedule"])
            require(
                len(schedule) == 512 and [x["slot"] for x in schedule] == list(range(512)),
                "full512 frozen schedule",
            )
            planned = [x for x in schedule if x["batch"] == experiment["batch"]]
            require(
                len(planned) == 32 and sorted(x["local_game"] for x in planned) == list(range(32)),
                "whole32 batch slice",
            )
            data["planned_global_slots"] = [x["slot"] for x in planned]
            config = document(experiment["config"])
            records = []
            raw = values["journal"]
            require(not raw or raw.endswith(b"\n"), "partial journal tail")
            for line in raw.splitlines():
                require(len(line) <= 630784, "full per-game record cap")
                row = json.loads(line)
                game = row["game"]
                require(
                    type(game) is int
                    and 0 <= game < 32
                    and game not in data["observed_local_games"],
                    "duplicate/unplanned journal game",
                )
                slot = next(x for x in planned if x["local_game"] == game)
                opening = config["arena"]["book"]["openings"][game // 2]
                require(
                    opening["reference"]["settings"]["family_id"] == slot["family_id"],
                    "global family via native batch config",
                )
                require(row["candidate_color"] == slot["candidate_color"], "journal colour drift")
                require(
                    isinstance(row["observations"], list) and isinstance(row["moves"], list),
                    "full scientific per-game observations required",
                )
                require(row["status"] in {"goal", "forfeit", "draw", "unknown"}, "typed outcome")
                records.append(row)
                data["observed_local_games"].append(game)
            data["missing_local_games"] = sorted(set(range(32)) - set(data["observed_local_games"]))
            require(
                not data["missing_local_games"],
                "missing planned games; retained UNKNOWN denominator",
            )
            report = json.loads(values["result"])
            require(
                report["planned"] == 32
                and report["all_workers_joined"] is True
                and report["stopped"] is None,
                "native run incomplete",
            )
            require(
                sorted(records, key=lambda x: x["game"])
                == sorted(report["outcomes"], key=lambda x: x["game"]),
                "journal/result correspondence",
            )
        except BaseException as error:
            data["errors"].append({"stage": "scientific_journal", **error_fact(error)})
    if data["errors"]:
        data["status"] = "FAILED"
    return data


def execute(
    spec_ref,
    *,
    executor=process.execute,
    guard=physical_and_quiet,
    lock=lease,
    resource_factory=Limits,
):
    spec = document(spec_ref)
    require(spec["schema"] == "quoridor.research.lifecycle-intent.v1", "lifecycle intent schema")
    # The admitted hash excludes only the admission descriptor, to avoid a self-referential digest.
    admission_view = {k: v for k, v in spec.items() if k not in {"admission", "intent_sha256"}}
    require(
        sha(json.dumps(admission_view, sort_keys=True, separators=(",", ":")).encode())
        == spec["intent_sha256"],
        "admitted intent digest",
    )
    require(spec["kind"] in ("build", "run"), "build/run only")
    directory = owned(spec["output"], spec["owner"])
    require(not directory.exists(), "restart/duplicate operation refused")
    require(Path(spec["cwd"]).is_dir(), "owned existing cwd")
    result = {
        "schema": BUILD_SCHEMA if spec["kind"] == "build" else COMPLETION_SCHEMA,
        "kind": spec["kind"],
        "status": "UNKNOWN",
        "intent": spec_ref,
        "started_at": stamp(),
        "checks": [],
        "primary": None,
        "secondary": [],
        "cleanup_complete": False,
        "remaining": [],
        "owed_finalizers": spec["finalizers"],
    }
    primary, resources = None, None
    claimed, created_TMP = False, False
    refs = []
    try:
        guard(spec)
        with lock():
            resources = resource_factory(spec)
            resources.check()
            try:
                if spec["kind"] == "build":
                    build_check(spec)
                    refs = [
                        *spec["source"]["files"],
                        *spec["dependency_refs"],
                        *[t["file"] for t in spec["tools"].values()],
                    ]
                else:
                    experiment, manifest, refs = experiment_check(spec)
                    result.update(
                        experiment=spec["experiment"],
                        build_manifest=experiment["build_manifest"],
                        planned_slots=experiment["planned_slots"],
                    )
                directory.mkdir()
                claimed = True
                new_json(directory / "INCOMPLETE", {"intent": spec_ref, "status": "UNKNOWN"})
                new_json(directory / "intent.json", spec)
                if spec["kind"] == "build":
                    if not Path(spec["target"]).exists():
                        Path(spec["target"]).mkdir()
                        new_json(
                            Path(spec["target"]) / ".research-owner.json",
                            {
                                "writer": spec["writer"],
                                "target": spec["target"],
                                "support_sha256": spec["support"]["sha256"],
                            },
                        )
                    Path(spec["TMP"]).mkdir()
                    created_TMP = True
                    Path(spec["private"]).parent.mkdir(exist_ok=True)
                    for name, tool in spec["tools"].items():
                        read_ref(tool["file"], max(CONTROL_BYTES, tool["file"]["bytes"]))
                        row = {
                            "name": "version-" + name.lower(),
                            "argv": [tool["file"]["path"], *tool["version_args"]],
                        }
                        _, full = command(spec, row, directory, resources, executor)
                        require(
                            full.read_text().strip() == tool["version"],
                            "trusted tool version drift",
                        )
                    candidate = None
                    for row in spec["commands"]:
                        if row["role"] == "bindings":
                            require(
                                candidate is not None
                                and row["argv"] == [spec["private"], "research-bindings"],
                                "same executable bindings",
                            )
                        result["active_command"] = row
                        record, full = command(spec, row, directory, resources, executor)
                        check = {
                            "name": row["name"],
                            "role": row["role"],
                            "argv": row["argv"],
                            "guardian_return": record,
                            "full_log": bound(full, spec["limits"]["log_B"])[0],
                        }
                        result["checks"].append(check)
                        if row["role"] == "bindings":
                            metadata = json.loads(full.read_bytes())
                            require(
                                metadata["executable_sha256"] == candidate["sha256"]
                                and metadata["model_calls"] == 0,
                                "actual zero-model bindings",
                            )
                            result["compiled_sources"] = metadata["compiled_sources"]
                        else:
                            cargo = cargo_report(full.read_bytes())
                            check["cargo"] = cargo
                            if row["role"] == "build":
                                matches = [
                                    a
                                    for a in cargo["artifacts"]
                                    if a["target"]["name"] == "quoridor-runner"
                                    and a["target"]["kind"] == ["bin"]
                                    and a["profile"]["test"] is False
                                ]
                                require(len(matches) == 1, "one normal runner executable artifact")
                                src = owned(matches[0]["executable"], spec["target"])
                                candidate = copy_artifact(src, spec["private"])
                        result["active_command"] = None
                    require(
                        candidate is not None and result.get("compiled_sources"),
                        "actual artifact/bindings required",
                    )
                    result.update(
                        artifact=candidate,
                        source=spec["source"],
                        source_adoption=spec["source_adoption"],
                        tools=spec["tools"],
                        env=spec["env"],
                        dependency_refs=spec["dependency_refs"],
                    )
                else:
                    spec["env"] = {
                        **spec["env"],
                        "QUORIDOR_LIFECYCLE_INTENT": spec_ref["sha256"],
                        "QUORIDOR_LIFECYCLE_PARENT_PID": str(os.getpid()),
                    }
                    row = {"name": "run", "argv": spec["argv"]}
                    run_error = None
                    try:
                        record, full = command(spec, row, directory, resources, executor)
                        result["checks"].append(
                            {
                                "name": "run",
                                "role": "run",
                                "guardian_return": record,
                                "full_log": bound(full, spec["limits"]["log_B"])[0],
                            }
                        )
                    except BaseException as error:
                        run_error = error
                    result["data"] = collect_data(spec, experiment)
                    if result["data"]["status"] != "PASS":
                        error = Refused(
                            "durable data finalization incomplete: "
                            + json.dumps(result["data"]["errors"])
                        )
                        if run_error is not None:
                            run_error.add_note("data finalization secondary: " + str(error))
                        else:
                            run_error = error
                    if run_error is not None:
                        raise run_error
                for ref in refs:
                    read_ref(ref, max(CONTROL_BYTES, ref["bytes"]))
                result["status"] = "PENDING_FINALIZATION"
            finally:
                if created_TMP:
                    active_error = sys.exception()
                    try:
                        Path(spec["TMP"]).rmdir()
                    except BaseException as cleanup_error:
                        result["secondary"].append(
                            {"stage": "TMP_cleanup", **error_fact(cleanup_error)}
                        )
                        if active_error is not None:
                            active_error.add_note("TMP cleanup secondary: " + repr(cleanup_error))
                        else:
                            raise
                    finally:
                        created_TMP = False
    except BaseException as error:
        primary = error
        result.update(
            status="CANCELLED"
            if isinstance(error, process.CycleStopped) and "signal" in str(error)
            else "FAILED",
            primary=error_fact(error),
        )
    finally:
        if result["secondary"]:
            result["status"] = "FAILED"
        result["finished_at"] = stamp()
        result["cleanup_complete"] = primary is None and not result["secondary"]
        # This candidate is not a completion or run-admissible manifest.
        if claimed:
            try:
                new_json(directory / "candidate.json", result)
            except BaseException as error:
                if primary is not None:
                    primary.add_note("candidate save secondary: " + repr(error))
                else:
                    primary = error
    if primary is not None:
        primary.add_note("lifecycle partial facts: " + json.dumps(result, allow_nan=False))
        raise primary
    return result


def _prepare_completion(directory, job_ref):
    """No child launch. Authoritative publish happens after every independent owed finalizer."""
    directory = Path(directory)
    require(
        directory.is_absolute() and (directory / "INCOMPLETE").is_file(),
        "new pending operation required",
    )
    with (directory / "finalizing").open("xb"):
        pass  # Restart cannot run a scientific command or independent finalizers twice.
    candidate = json.loads((directory / "candidate.json").read_bytes())
    errors = []
    job = {}
    if candidate["status"] != "PENDING_FINALIZATION" or candidate["cleanup_complete"] is not True:
        errors.append({"stage": "candidate", "facts": candidate["primary"]})
    try:
        job = document(job_ref)
        require(
            job.get("outcome") == "succeeded"
            and job.get("exit_code") == 0
            and job.get("cleanup_complete") is True
            and job.get("remaining") == []
            and job.get("cleanup_errors", []) == [],
            "outer job unsuccessful or not cleaned",
        )
        cfg = json.loads(Path(job_ref["path"]).with_name("config.json").read_bytes())
        expected = [
            sys.executable,
            "-B",
            str(ROOT / "scripts/dev/research-lifecycle.py"),
            candidate["kind"],
            "--intent",
            candidate["intent"]["path"],
            "--sha256",
            candidate["intent"]["sha256"],
        ]
        require(cfg["argv"] == expected, "different lifecycle job")
    except BaseException as error:
        errors.append({"stage": "outer_job", **error_fact(error), "available_result": job})
    if candidate["kind"] == "run":
        try:
            require(candidate["data"]["status"] == "PASS", "data finalization missing/failed")
            for ref in candidate["data"]["files"]:
                read_ref(ref, max(CONTROL_BYTES, ref["bytes"]))
        except BaseException as error:
            errors.append({"stage": "data_finalization", **error_fact(error)})
    for obligation in candidate["owed_finalizers"]:
        try:
            actual, raw = bound(obligation["path"], obligation["limit_B"])
            doc = json.loads(raw)
            for ref in doc["files"]:
                read_ref(ref, max(CONTROL_BYTES, ref["bytes"]))
            obligation["actual_receipt"] = actual
            require(doc["schema"] == "quoridor.research.data-finalizer.v1", "data finalizer schema")
            require(
                doc["status"] == "PASS" and doc["remaining"] == [], "owed finalizer failed/unknown"
            )
            require(doc["intent_sha256"] == candidate["intent"]["sha256"], "same finalizer intent")
            if obligation["kind"] == "journal":
                require(
                    doc["planned_slots"] == 512 and doc["complete_planned_census"] is True,
                    "full scientific512 journal denominator",
                )
            elif obligation["kind"] != "data":
                raise Refused("unknown independent finalizer kind")
        except BaseException as error:
            errors.append({"stage": "owed_finalizer", **error_fact(error)})
    candidate["outer_job_result"] = job_ref
    candidate["secondary"].extend(errors)
    prior_status = candidate["status"]
    candidate["status"] = "FAILED" if candidate["primary"] or candidate["secondary"] else "PASS"
    if prior_status == "CANCELLED" or job.get("outcome") == "cancelled":
        candidate["status"] = "CANCELLED"
    candidate["authoritative_finished_at"] = stamp()
    candidate["remaining"] = [] if candidate["status"] == "PASS" else job.get("remaining", [])
    candidate["cleanup_complete"] = candidate["status"] == "PASS"
    if candidate["kind"] == "build" and candidate.get("artifact") is not None:
        try:
            read_ref(candidate["artifact"], 32 * 1024 * 1024)
            source_check(candidate["source"])
        except BaseException as error:
            if candidate["status"] != "CANCELLED":
                candidate["status"] = "FAILED"
            candidate["cleanup_complete"] = False
            candidate["secondary"].append({"stage": "final_artifact_source", **error_fact(error)})
    new_json(directory / "manifest.json", candidate)
    fd = os.open(directory, os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return candidate


def finalize(directory, job_ref, *, guard=physical_and_quiet, lock=lease, resource_factory=Limits):
    directory = Path(directory)
    candidate = json.loads((directory / "candidate.json").read_bytes())
    spec = document(candidate["intent"])
    require(
        owned(directory, spec["owner"]) == Path(spec["output"]), "finalization operation ownership"
    )
    guard(spec)
    with lock():
        resources = resource_factory(spec)
        resources.check()
        completion = _prepare_completion(directory, job_ref)
    # Critical reads, direct waits, data/log writes, lease/handle closes and
    # independent finalizers precede this last fallible publication operation.
    (directory / "INCOMPLETE").unlink()
    return completion


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("build", "run"):
        p = commands.add_parser(name)
        p.add_argument("--intent", type=Path, required=True)
        p.add_argument("--sha256", required=True)
    p = commands.add_parser("finalize")
    p.add_argument("--operation", type=Path, required=True)
    p.add_argument("--job-result", type=Path, required=True)
    p.add_argument("--sha256", required=True)
    args = parser.parse_args()
    if args.command == "finalize":
        ref, _ = bound(args.job_result)
        require(ref["sha256"] == args.sha256, "actual job result binding")
        result = finalize(args.operation, ref)
        return 0 if result["status"] == "PASS" else 1
    ref, _ = bound(args.intent)
    require(ref["sha256"] == args.sha256, "intent SHA")
    require(document(ref)["kind"] == args.command, "operation kind")
    runtime_path = os.environ.get("QUORIDOR_RESEARCH_JOB_DIR")
    require(runtime_path is not None, "submit build/run through research-job.sh")
    state = json.loads((Path(runtime_path) / "state.json").read_bytes())
    supervisor = state["supervisor"]
    require(
        supervisor["pid"] == os.getppid() and process.alive(supervisor),
        "actual outer job ownership",
    )
    execute(ref)
    return 0


if __name__ == "__main__":
    sys.exit(main())
