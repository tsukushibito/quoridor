import datetime, fcntl, hashlib, json, os, pathlib, shutil, sys, time

root = pathlib.Path("/workspaces/quoridor/.worktree/research-lifecycle-maintenance")
out = root / ".artifacts/generation-bootstrap355-v1/caller-repair-v2"
sys.path.insert(0, str(root / "python"))

names = ["test_saved_generation_candidate_refuses_and_manifest_retains_outer_owed_errors"]
peers = []
for p in pathlib.Path("/proc").iterdir():
    if p.name.isdigit():
        try:
            name = (p / "comm").read_text().strip()
            if name in {"cargo", "rustc", "cc1plus", "quoridor-runner", "chromium", "chrome"}:
                peers.append({"pid": int(p.name), "comm": name})
        except FileNotFoundError:
            pass
if peers:
    raise RuntimeError("named peer refusal " + repr(peers))
mem = {
    line.split(":")[0]: int(line.split()[1]) * 1024
    for line in pathlib.Path("/proc/meminfo").read_text().splitlines()
    if line.startswith("MemAvailable:")
}
if mem["MemAvailable"] < 4 * 1024**3 + 512 * 1024**2:
    raise RuntimeError("RAM reserve")
if shutil.disk_usage(root).free < 1024**3:
    raise RuntimeError("FS reserve")
if 3 not in os.sched_getaffinity(0):
    raise RuntimeError("CPU3 unavailable")
child = """import resource,sys,unittest,importlib.abc
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
class NoScience(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'numpy','torch','onnxruntime','scipy','quoridor_native'}: raise ImportError('NN0 prohibited '+fullname)
sys.meta_path.insert(0,NoScience())
suite=unittest.defaultTestLoader.loadTestsFromNames(["test_lifecycle.LifecycleTests."+n for n in NAMES])
r=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if r.wasSuccessful() else 1)
""".replace("NAMES", repr(names))
lease = open(
    "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock", "a+"
)
fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
from quoridor_training import cycle_process as cp

before = {
    str(p): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in [
        root / "scripts/dev/research-lifecycle.py",
        root / "tools/research-session/test_lifecycle.py",
    ]
}
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
resources = cp.CycleResources(
    {
        "host_ram_reserve": 4 * 1024**3,
        "max_memory_bytes": 512 * 1024**2 - 64 * 1024**2,
        "max_output_bytes": 65536,
    },
    out,
    time.monotonic() + 30,
)
failure = None
try:
    record = cp.execute(
        ["/usr/bin/python3", "-B", "-c", child],
        out / "authority-NN0.log",
        time.monotonic() + 30,
        cpu_core=3,
        resources=resources,
        cwd=root / "tools/research-session",
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "NODE_DISABLE_COMPILE_CACHE": "1"},
    )
except BaseException as error:
    failure = repr(error)
    record = None

stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
tmp = root / ".artifacts/research-lifecycle-maintenance/test-TMP"
remaining = [str(p) for p in tmp.iterdir()] if tmp.exists() else []
facts = {
    "START": start,
    "STOP": stop,
    "whole_s": time.monotonic() - tick,
    "names": names,
    "returned": record,
    "owned_TMP_remaining": remaining,
    "fresh_named_peers": peers,
    "continuous_family_peak": "UNKNOWN",
    "limits": {"AS_B": 536870912, "family_B": 536870912, "CPU": 3, "GPU": 0, "TMP_B": 8388608},
}
after = {p: hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in before}
assert before == after
facts["source_before"] = before
facts["source_after"] = after
facts["primary"] = failure
facts["known_child_absent"] = not cp.alive(record["child"]) if record else "UNKNOWN"
fcntl.flock(lease, fcntl.LOCK_UN)
lease.close()
(out / "authority-NN0-result.json").write_text(json.dumps(facts, indent=2) + "\n")
print(json.dumps(facts))
if failure is not None or record.get("exit_code") != 0:
    sys.exit(1)
