"""Bounded saved-record analysis. No evaluator, geometry oracle or model calls."""

import collections
import csv
import datetime
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path
import resource
import signal
import statistics
import struct
import time

ROOT = Path(__file__).resolve().parent
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/trained-reference-v1/native-final-v1/distance-final-v1"
)
CURVES = Path(
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/trigger-patience-v1/patience1/output/curves.jsonl.gz"
)
UPPER = 32 * 1024 * 1024
PRIOR_UPPER = 8_000_000
JSON_UPPER = 2 * 1024 * 1024
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024, 512 * 1024 * 1024))
signal.alarm(120)


class Reads:
    def __init__(self):
        self.total = 0
        self.decoded_moves = 0
        self.files = {}

    def read(self, path):
        path = Path(path)
        before = path.stat()
        assert self.total + before.st_size + PRIOR_UPPER <= UPPER
        data = path.read_bytes()
        after = path.stat()
        assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
        self.total += len(data)
        self.files[str(path)] = {"bytes": len(data), "SHA256": hashlib.sha256(data).hexdigest()}
        return data

    def load(self, path):
        assert Path(path).stat().st_size <= JSON_UPPER
        return json.loads(self.read(path))

    def lines(self, path, compressed=False, moves=False):
        data = self.read(path)
        stream = gzip.GzipFile(fileobj=io.BytesIO(data)) if compressed else io.BytesIO(data)
        with stream:
            for line in stream:
                assert len(line) <= JSON_UPPER
                if compressed:
                    self.total += len(line)
                    assert self.total + PRIOR_UPPER <= UPPER
                if moves:
                    self.decoded_moves += len(line)
                    assert self.decoded_moves <= 16 * 1024 * 1024
                if line.strip():
                    yield json.loads(line)


def same_saved(a, b, field=""):
    """Only value_stm uses shortest f32 JSON vs promoted-f64 serialization."""
    if isinstance(a, dict) and isinstance(b, dict):
        assert a.keys() == b.keys()
        return all(same_saved(a[k], b[k], k) for k in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(same_saved(x, y, field) for x, y in zip(a, b))
    if field == "value_stm" and a is not None and b is not None:
        return struct.pack("<f", a) == struct.pack("<f", b)
    return a == b


def distribution(values):
    if not values:
        return {"n": 0}
    return {
        "n": len(values),
        "min": min(values),
        "median": statistics.median(values),
        "max": max(values),
        "histogram": dict(sorted(collections.Counter(values).items())),
    }


def key(state):
    return tuple(state["pawns"]) + tuple(state["stock"]) + (state["h"], state["v"], state["turn"])


def apply_saved(state, action):
    """Replay accepted actions only; no legalgen/BFS/evaluation/counterfactual."""
    side = state["turn"]
    assert 0 <= action <= 208
    if action < 81:
        state["pawns"][side] = action
    elif action < 145:
        state["h"] |= 1 << (action - 81)
        state["stock"][side] -= 1
    else:
        assert action <= 208
        state["v"] |= 1 << (action - 145)
        state["stock"][side] -= 1
    assert min(state["stock"]) >= 0
    state["turn"] ^= 1


def gap(pawn, side):
    return 8 - pawn // 9 if side == 0 else pawn // 9


def trace(obs, before, previous_count):
    return {
        "ply": obs["ply"],
        "side": obs["side"],
        "engine": obs["engine_index"],
        "action": obs["action"],
        "kind": "pawn" if obs["action"] < 81 else "wall",
        "pawns_before": list(before["pawns"]),
        "stock_before": list(before["stock"]),
        "goal_row_gap_before": [gap(p, s) for s, p in enumerate(before["pawns"])],
        "replayed_state_prior_visits_including_prefix": previous_count,
        "completed_depth": obs["completed_depth"],
        "value_stm": obs["value_stm"],
        "pv": obs["pv"],
        "stop": obs["stop"],
        "caller_seconds": obs["caller_seconds"],
        "source": "moves.jsonl.gz observation at unique (run,game,ply)",
    }


def main():
    started_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
    started = time.monotonic()
    reads = Reads()
    summary = reads.load(BASE / "final-result-summary.json")
    assert (
        reads.files[str(BASE / "final-result-summary.json")]["SHA256"]
        == "c03c8cd76d864fda5424e2e28df19e4c37ddfeda92e9eb6ed6eca8767256706f"
    )
    all_moves = collections.defaultdict(list)
    whole = [collections.Counter(), collections.Counter()]
    engines = [
        {
            "moves": 0,
            "actions": collections.Counter(),
            "stops": collections.Counter(),
            "depth": [],
            "caller": [],
            "thinking": [],
            "by_stock_phase": collections.defaultdict(list),
            "by_absolute_ply": collections.defaultdict(list),
            "pv_length": [],
            "value": [],
            "value_abs_one_or_terminal": 0,
            "unfinished_nodes": 0,
            "whole_nodes": 0,
            "last_completed_nodes": 0,
            "after_completed_seconds": [],
            "row_gap_increases": 0,
        }
        for _ in range(2)
    ]
    games = []
    pairs = collections.defaultdict(list)
    all_failures = []
    for run in ["run-initial", "run-main"]:
        base = BASE / run
        config = reads.load(base / "config.json")
        planned = reads.load(base / "planned.json")
        manifest = reads.load(base / "manifest.json")
        result = reads.load(base / "result.json")
        csv_rows = list(csv.DictReader(io.StringIO(reads.read(base / "games.csv").decode())))
        journal = list(reads.lines(base / "completed.jsonl"))
        planned_by_game = {p["game"]: p for p in planned}
        assert len(planned_by_game) == len(journal) == len(csv_rows)
        assert same_saved(manifest["result"], result)
        for row in reads.lines(base / "moves.jsonl.gz", compressed=True, moves=True):
            all_moves[(run, row["game"])].append(row["observation"])
        for completed in journal:
            game = completed["game"]
            plan = planned_by_game[game]
            obs_rows = all_moves[(run, game)]
            assert same_saved(completed["observations"], obs_rows)
            assert completed["family"] == plan["family"]
            assert completed["candidate_color"] == plan["candidate_color"]
            assert (
                completed["status"] == "goal" and completed["started"] and not completed["failure"]
            )
            assert completed["moves"] == plan["opening"] + [
                o["action"] for o in obs_rows if o["accepted"]
            ]
            assert completed["plies"] == len(completed["moves"])
            candidate_color = plan["candidate_color"]
            won = completed["winner"] == candidate_color
            pairs[(run, plan["family"])].append(int(won))
            state = {"pawns": [4, 76], "stock": [10, 10], "h": 0, "v": 0, "turn": 0}
            visits = collections.Counter({key(state): 1})
            for action in plan["opening"]:
                apply_saved(state, action)
                visits[key(state)] += 1
            rp = plan["replay"]
            assert state == {
                "pawns": rp["pawns"],
                "stock": rp["walls_left"],
                "h": rp["horizontal"],
                "v": rp["vertical"],
                "turn": rp["turn"],
            }
            tails = []
            walls = [0, 0]
            first_empty = [None, None]
            last_wall = [None, None]
            positive_nnue = []
            retreats = []
            for i, o in enumerate(obs_rows):
                assert o["ply"] == len(plan["opening"]) + i
                assert o["side"] == state["turn"]
                assert o["engine_index"] == (0 if o["side"] == candidate_color else 1)
                assert o["accepted"] and not o["engine_error"] and not o["failure"]
                assert o["accepted_ns"] <= o["deadline_ns"]
                assert o["returned_ns"] <= o["admission_checked_ns"] <= o["accepted_ns"]
                assert (
                    o["caller_started_ns"] <= o["last_completed_iteration_ns"] <= o["returned_ns"]
                )
                assert math.isfinite(o["value_stm"]) and abs(o["value_stm"]) <= 2
                assert o["pv"] and o["pv"][0] == o["action"]
                ei = o["engine_index"]
                e = engines[ei]
                before = {**state, "pawns": list(state["pawns"]), "stock": list(state["stock"])}
                tr = trace(o, before, visits[key(state)])
                tails.append(tr)
                e["moves"] += 1
                e["actions"][tr["kind"]] += 1
                e["stops"][o["stop"]] += 1
                e["depth"].append(o["completed_depth"])
                e["caller"].append(o["caller_seconds"])
                e["thinking"].append(o["thinking_seconds"])
                e["pv_length"].append(len(o["pv"]))
                e["value"].append(o["value_stm"])
                phase = (
                    "both_stock0"
                    if sum(state["stock"]) == 0
                    else ("one_stock0" if min(state["stock"]) == 0 else "both_have_stock")
                )
                e["by_stock_phase"][phase].append(o["completed_depth"])
                e["by_absolute_ply"][
                    "0..19" if o["ply"] < 20 else ("20..39" if o["ply"] < 40 else "40+")
                ].append(o["completed_depth"])
                e["value_abs_one_or_terminal"] += int(abs(o["value_stm"]) >= 1)
                e["after_completed_seconds"].append(
                    (o["returned_ns"] - o["last_completed_iteration_ns"]) / 1e9
                )
                counters = o["counters"]
                completed_counters = o["completed_iteration_counters"]
                for k, v in counters.items():
                    if k not in [
                        "tt_generation",
                        "tt_retained_bytes",
                        "leaf_count",
                        "physical_nn_calls",
                    ]:
                        assert v is not None
                        whole[ei][k] += v
                assert counters["nodes"] >= completed_counters["nodes"]
                e["whole_nodes"] += counters["nodes"]
                e["last_completed_nodes"] += completed_counters["nodes"]
                e["unfinished_nodes"] += counters["nodes"] - completed_counters["nodes"]
                if ei == 0 and not won and o["value_stm"] > 0:
                    positive_nnue.append(tr)
                if o["action"] >= 81:
                    walls[ei] += 1
                    last_wall[ei] = tr
                else:
                    old_gap = gap(state["pawns"][o["side"]], o["side"])
                    new_gap = gap(o["action"], o["side"])
                    if new_gap > old_gap:
                        e["row_gap_increases"] += 1
                        retreats.append(tr)
                apply_saved(state, o["action"])
                visits[key(state)] += 1
                if state["stock"][o["side"]] == 0 and first_empty[ei] is None:
                    first_empty[ei] = {"ply_after": o["ply"] + 1, "trigger_action": o["action"]}
            assert gap(state["pawns"][completed["winner"]], completed["winner"]) == 0
            games.append(
                {
                    "run": run,
                    "game": game,
                    "family": plan["family"],
                    "cohort": plan["cohort"],
                    "lineage": plan["lineage"],
                    "candidate_color": candidate_color,
                    "winner": completed["winner"],
                    "NNUE_won": won,
                    "plies": completed["plies"],
                    "accepted_observations": len(obs_rows),
                    "prefix": plan["opening"],
                    "prefix_history_SHA": rp["history_sha256"],
                    "status": completed["status"],
                    "failure": completed["failure"],
                    "actions_wall_by_engine": walls,
                    "first_stock0_by_engine": first_empty,
                    "terminal_pawns": state["pawns"],
                    "terminal_stock": state["stock"],
                    "recorded_depth_by_engine": [
                        distribution(
                            [o["completed_depth"] for o in obs_rows if o["engine_index"] == j]
                        )
                        for j in range(2)
                    ],
                    "terminal_tail": tails[-6:],
                    "last_wall_by_engine": last_wall,
                    "last_positive_NNUE_root_in_loss": positive_nnue[-1] if positive_nnue else None,
                    "pawn_row_gap_increases_examples": retreats[-2:],
                    "all_observations_source_SHA": reads.files[str(base / "moves.jsonl.gz")][
                        "SHA256"
                    ],
                    "history": "accepted prefix replayed; no new legality/value/BFS; original full-history source authoritative",
                    "persistent_tt": completed["persistent_tt"],
                }
            )
        all_failures.extend([c["failure"] for c in journal if c["failure"]])
        assert config["arena"]["return_reserve_ms"] == 5 and all(
            c["time_ms"] == 100 for c in config["engines"]
        )
    for ei, e in enumerate(engines):
        saved = summary["engines"][ei]
        assert e["moves"] == saved["moves"]
        assert dict(e["stops"]) == saved["stop_reasons"]
        for k, v in saved["whole_invocation_counter_sums"].items():
            assert whole[ei][k] == v, (ei, k, whole[ei][k], v)
        assert math.isclose(sum(e["caller"]), saved["whole_caller_total_seconds"], abs_tol=1e-8)
        for k in ["depth", "pv_length"]:
            e[k] = distribution(e[k])
        for k in ["caller", "thinking", "value", "after_completed_seconds"]:
            a = e[k]
            e[k] = {
                "n": len(a),
                "min": min(a),
                "median": statistics.median(a),
                "max": max(a),
                "sum": sum(a),
            }
        e["by_stock_phase"] = {k: distribution(v) for k, v in e["by_stock_phase"].items()}
        e["by_absolute_ply"] = {k: distribution(v) for k, v in e["by_absolute_ply"].items()}
        e["whole_invocation_counters"] = dict(whole[ei])
        e["whole_minus_last_completed_iteration_scope"] = (
            "includes earlier completed depths AND final partial work; not isolated wasted/discarded work"
        )
        del e["unfinished_nodes"]
    assert len(games) == 16 and len(pairs) == 8 and all(len(v) == 2 for v in pairs.values())
    assert sum(g["NNUE_won"] for g in games) == 4
    assert sum(e["moves"] for e in engines) == 776
    curve_summary = []
    for point in reads.lines(CURVES, compressed=True):
        if point["kind"] == "full_selector":
            v = point["validation"]
            assert v["rows"] == 419150
            curve_summary.append(
                {
                    "step": point["step"],
                    "epoch": point["completed_epochs"],
                    "Vrows": v["rows"],
                    "NNUE_z_MSE": v["z_mse"],
                    "D_baseline_z_MSE": v["distance_mse"],
                    "constant_z_MSE": v["constant_mse"],
                }
            )
    best = next(p for p in curve_summary if p["step"] == 209559)
    assert best["epoch"] == 51 and best["NNUE_z_MSE"] == 0.42744088098494515
    assert len({p["D_baseline_z_MSE"] for p in curve_summary}) == 1
    out = {
        "issue": "quoridor-4lc.332",
        "source_version": "ed168d3fb713493c9d8c99cde33fef9da59edebc",
        "census": {
            "games": len(games),
            "pairs": len(pairs),
            "NNUE_wins": 4,
            "NNUE_losses": 12,
            "accepted_moves": 776,
            "errors_unknown_draw": 0,
        },
        "engines": engines,
        "games": games,
        "pairs": [{"run": k[0], "family": k[1], "NNUE_wins": sum(v)} for k, v in pairs.items()],
        "saved_teacher_metrics": {
            "BEST51": best,
            "D_metric_same_across_fullV_selector_points": len(curve_summary),
            "definition": "saved originalV decisive-z rowMSE, FP32 baseline tanh(0+8*(opponentD-STM D)); not arena move regret or new native D/fullV inference",
        },
        "input_files": reads.files,
        "limits": {
            "new_read_and_decoded_B": reads.total,
            "prior_read_upper_B": PRIOR_UPPER,
            "cumulative_upper_B": reads.total + PRIOR_UPPER,
            "decoded_moves_B": reads.decoded_moves,
            "legal_branching": "NOT_RECORDED",
            "static_root_values": "NOT_RECORDED",
            "geometry_BFS_or_models_called": 0,
        },
        "limitations": [
            "different trajectories/states; no per-node throughput/causal depth estimate",
            "search rootSTM values are selected completed search values, not static model calibration",
            "coordinate goal-row gap is not shortest-path distance or regret",
            "fixed8 correlated book families; no general population strength or universal D superiority",
        ],
    }
    output = json.dumps(out, ensure_ascii=False, indent=2) + "\n"
    assert len(output.encode()) < 320 * 1024, "report aggregate budget"
    (ROOT / "aggregates.json").write_text(output)
    control = json.loads((ROOT / "control.json").read_text())
    control["aggregation"] = {
        "actual_START_UTC": started_utc,
        "actual_STOP_UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "wall_seconds": time.monotonic() - started,
        "peak_RSS_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "CPU_affinity": sorted(os.sched_getaffinity(0)),
        "pid": os.getpid(),
        "pid_start_ticks": Path("/proc/self/stat").read_text().split()[21],
        "source_SHA256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "accepted": True,
        "directed_read_upper_B": reads.total + PRIOR_UPPER,
        "decoded_moves_B": reads.decoded_moves,
        "result_bytes": len(output.encode()),
        "remaining_readers_children": [],
        "scientific_calls": 0,
    }
    (ROOT / "control.json").write_text(json.dumps(control, ensure_ascii=False, indent=2) + "\n")
    print(
        json.dumps(
            {
                "census": out["census"],
                "engines_depth": [e["depth"] for e in engines],
                "savedV": best,
                "cost": control["aggregation"],
            },
            ensure_ascii=False,
        )
    )


def stock_analysis():
    """Final bounded disaggregation, no replay legality/evaluator queries."""
    started = time.monotonic()
    reads = Reads()
    d = json.loads((ROOT / "aggregates.json").read_text())
    prior = d["limits"]["cumulative_upper_B"]
    groups = [collections.defaultdict(list), collections.defaultdict(list)]
    for run in ["run-initial", "run-main"]:
        planned = reads.load(BASE / run / "planned.json")
        stock = {g["game"]: list(g["replay"]["walls_left"]) for g in planned}
        for row in reads.lines(BASE / run / "moves.jsonl.gz", compressed=True, moves=True):
            o = row["observation"]
            assert o["accepted"]
            label = "own_stock0" if stock[row["game"]][o["side"]] == 0 else "own_has_stock"
            groups[o["engine_index"]][label].append(o["completed_depth"])
            if o["action"] >= 81:
                stock[row["game"]][o["side"]] -= 1
                assert stock[row["game"]][o["side"]] >= 0
    for i, g in enumerate(groups):
        d["engines"][i]["by_own_stock"] = {k: distribution(v) for k, v in g.items()}
        assert sum(len(v) for v in g.values()) == d["engines"][i]["moves"]
    d["limits"]["cumulative_upper_B"] += reads.total
    d["limits"]["decoded_moves_cumulative_B"] = (
        2 * d["limits"]["decoded_moves_B"] + reads.decoded_moves
    )
    assert prior + reads.total <= UPPER
    assert d["limits"]["decoded_moves_cumulative_B"] <= 16 * 1024 * 1024
    (ROOT / "aggregates.json").write_text(json.dumps(d, ensure_ascii=False, indent=2) + "\n")
    status = {
        k: v.strip()
        for k, v in (
            line.split(":", 1)
            for line in Path("/proc/self/status").read_text().splitlines()
            if ":" in line
        )
        if k in ["VmHWM", "VmRSS", "VmPeak", "VmSize"]
    }
    c = json.loads((ROOT / "control.json").read_text())
    c["stock_disaggregation"] = {
        "wall_seconds": time.monotonic() - started,
        "rusage_maxrss_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "kernel_memory": status,
        "source_SHA256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "STOP_UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "pid": os.getpid(),
        "pid_start_ticks": Path("/proc/self/stat").read_text().split()[21],
        "directed_read_and_decode_B": reads.total,
        "directwait_exit": 0,
        "scientific_calls": 0,
        "remaining_readers_children": [],
    }
    c["all_substantive_saved_analysis_STOP"] = c["stock_disaggregation"]["STOP_UTC"]
    c["message"] = (
        "332 substantial saved-record analysis STOP; direct child exits recorded, no current/next substantive analysis/science/compile reservation. Only light report/source finalization. 16games/8pairs/4W12L/776 accepted verified. Preserve old notification notifier, no foreignkill. New 331/333 clocks may enter after own freshphysics; parent323 pause/seals unchanged."
    )
    (ROOT / "control.json").write_text(json.dumps(c, ensure_ascii=False, indent=2) + "\n")
    print(
        json.dumps(
            {
                "by_own_stock": [e["by_own_stock"] for e in d["engines"]],
                "resources": c["stock_disaggregation"],
                "cumulative_directed_upper_B": d["limits"]["cumulative_upper_B"],
            }
        )
    )


if __name__ == "__main__":
    outer_start = time.monotonic()
    try:
        import sys

        stock_analysis() if "--stock" in sys.argv else main()
    except BaseException as error:
        control_path = ROOT / "control.json"
        control = json.loads(control_path.read_text())
        control.setdefault("analysis_failures", []).append(
            {
                "primary_type": type(error).__name__,
                "primary_message": str(error),
                "wall_seconds": time.monotonic() - outer_start,
                "peak_RSS_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                "source_SHA256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "remaining_readers_children": [],
                "scientific_calls": 0,
            }
        )
        control_path.write_text(json.dumps(control, ensure_ascii=False, indent=2) + "\n")
        raise
