"""One finite guarded stdlib scope; no scientific inputs or native children."""

import ast
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time
import unittest

ROOT = Path("/workspaces/quoridor/.worktree/learning-million")
MAIN = Path("/workspaces/quoridor")
OUT = ROOT / ".artifacts/lifecycle-consumer-n3l7-v1"
OWN_MODULES = ROOT / "python/quoridor_training/research355"
MAIN_MODULES = MAIN / "python/quoridor_training/research355"
LOCK = MAIN / ".artifacts/rust-migration/target/arena-software-writer.lock"
start = datetime.now(timezone.utc).isoformat()
begin = time.monotonic()
record = {
    "start": start,
    "scope": "five repaired NEW publisher integration fixtures",
    "model_native_Search_Cargo_game_calls": 0,
    "continuous_family_peak": "UNKNOWN",
}
result = None
try:
    with LOCK.open("a+b") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        sys.path.insert(0, str(MAIN_MODULES))
        sys.path.insert(0, str(MAIN / "python"))
        import io355

        io355.named_quiet()
        io355.finite_physical()
        record["cpu"] = sorted(os.sched_getaffinity(0))
        record["AS_limit_B"] = resource.getrlimit(resource.RLIMIT_AS)[0]
        named = json.loads((OUT / "Main-before-map.json").read_text())
        # Selected publisher/import source bytes stay bound across synthetic execution.
        record["input_map_shape"] = type(named).__name__
        paths = [MAIN / "scripts/dev/research-lifecycle.py"]
        before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
        sys.path.insert(0, str(OWN_MODULES))
        import test_lifecycle_repair355

        names = [
            "test_actual_publisher_full512_obligation_refuses_32_only_census",
            "test_failed_partial_and_independent_owed_facts_survive_without_receipt_reopening",
            "test_finalized_scientific_file_integrity_is_checked_at_consumption",
            "test_later_pairing_failure_keeps_failed_producer_progress_and_unknowns",
            "test_wrong_experiment_input_and_missing_critical_binding_refuse",
        ]
        suite = unittest.TestSuite(
            test_lifecycle_repair355.ConsumerPublisherIntegration(name) for name in names
        )
        assert suite.countTestCases() == 5
        with (OUT / "NN0-integration-recovery-v2.log").open("x") as log:
            result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
        after = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
        assert before == after
        record["publisher_before_after"] = before
        record.update(
            tests=result.testsRun,
            failures=len(result.failures),
            errors=len(result.errors),
            success=result.wasSuccessful(),
        )
        for p in OWN_MODULES.glob("test_lifecycle*.py"):
            ast.parse(p.read_text())
        record["owned_TMP_remaining"] = [str(p) for p in (OUT / "TMP").iterdir()]
        assert record["owned_TMP_remaining"] == []
        record["source_reader_STOP"] = datetime.now(timezone.utc).isoformat()
        fcntl.flock(lease, fcntl.LOCK_UN)
except BaseException as exc:
    record["primary"] = {"type": type(exc).__name__, "message": str(exc)}
finally:
    record["stop"] = datetime.now(timezone.utc).isoformat()
    record["whole_seconds"] = time.monotonic() - begin
    record["process_ru_maxrss_KiB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    record["owned_children_jobs"] = []
    (OUT / "NN0-integration-recovery-v2.json").write_text(
        json.dumps(record, indent=2, allow_nan=False) + "\n"
    )
sys.exit(0 if result is not None and result.wasSuccessful() and "primary" not in record else 1)
