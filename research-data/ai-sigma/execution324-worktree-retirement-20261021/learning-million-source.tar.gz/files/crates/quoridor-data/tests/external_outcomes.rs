use quoridor_core::{Position, research::features};
use quoridor_data::{
    OutcomeImportConfig, Split, Teacher, file_sha, import_sigma_outcomes, read_dataset,
    sigma_plane_position, write_tensor_cache,
};
use std::{io::Cursor, path::PathBuf};
fn dir(name: &str) -> PathBuf {
    std::env::temp_dir().join(format!(
        "quoridor-outcome-{name}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ))
}
fn asymmetric() -> Position {
    Position {
        horizontal: 1 << 3,
        vertical: 1 << (2 * 8 + 5),
        walls_remaining: [9, 9],
        ..Position::default()
    }
}

// Independent coordinate oracle; no implementation in Python is called here.
fn reflected_position(p: Position) -> Position {
    let anchors = |bits: u64| {
        let mut result = 0u64;
        for y in 0..8 {
            for x in 0..8 {
                if bits & (1u64 << (y * 8 + x)) != 0 {
                    result |= 1u64 << (y * 8 + 7 - x);
                }
            }
        }
        result
    };
    Position {
        pawns: p.pawns.map(|cell| cell / 9 * 9 + 8 - cell % 9),
        horizontal: anchors(p.horizontal),
        vertical: anchors(p.vertical),
        ..p
    }
}

fn reflected_action(action: u16) -> u16 {
    match quoridor_core::Action::decode(action).unwrap() {
        quoridor_core::Action::Pawn(cell) => u16::from(cell / 9 * 9 + 8 - cell % 9),
        quoridor_core::Action::Horizontal(anchor) => {
            81 + u16::from(anchor / 8 * 8 + 7 - anchor % 8)
        }
        quoridor_core::Action::Vertical(anchor) => 145 + u16::from(anchor / 8 * 8 + 7 - anchor % 8),
    }
}

#[test]
fn correct_lr_native_geometry_qf1_actions_transitions_goals_and_stm_nn0() {
    let mut boards = vec![Position::default(), asymmetric()];
    // Legal predecessors exercise reflection of winning transitions too.
    for pawns in [[67, 49], [31, 13]] {
        boards.push(Position {
            pawns,
            ..Position::default()
        });
    }
    boards.push(Position {
        pawns: [31, 40],
        ..Position::default()
    });
    boards.push(Position {
        pawns: [31, 40],
        horizontal: 1 << 36,
        walls_remaining: [9, 10],
        ..Position::default()
    });
    boards.push(Position {
        pawns: [36, 37],
        vertical: 1 << 33,
        walls_remaining: [9, 10],
        ..Position::default()
    });
    for horizontal in [true, false] {
        for anchor in [0, 7, 56, 63] {
            let p = Position {
                horizontal: if horizontal { 1u64 << anchor } else { 0 },
                vertical: if horizontal { 0 } else { 1u64 << anchor },
                walls_remaining: [9, 10],
                ..Position::default()
            };
            boards.push(p);
        }
    }
    for original in boards {
        for turn in [0, 1] {
            let p = Position { turn, ..original }.checked().unwrap();
            let mirror = reflected_position(p).checked().unwrap();
            let canonical = sigma_plane_position(&features(p)).unwrap();
            let canonical_mirror = sigma_plane_position(&features(mirror)).unwrap();
            assert_eq!(canonical_mirror, reflected_position(canonical));
            assert_eq!(reflected_position(mirror), p);
            assert_eq!(mirror.turn, p.turn);
            assert_eq!(mirror.winner, p.winner);
            assert_eq!(mirror.walls_remaining, p.walls_remaining);
            let original_features = quoridor_nnue::encode_qf1(p).unwrap();
            let mirror_features = quoridor_nnue::encode_qf1(mirror).unwrap();
            assert_eq!(original_features.distance, mirror_features.distance);
            assert_eq!(original_features.side, mirror_features.side);
            for view in 0..2 {
                let mut expected: Vec<u16> = original_features.ids[view]
                    .iter()
                    .map(|&id| match id {
                        0..=80 => id / 9 * 9 + 8 - id % 9,
                        81..=161 => 81 + (id - 81) / 9 * 9 + 8 - (id - 81) % 9,
                        162..=225 => 162 + (id - 162) / 8 * 8 + 7 - (id - 162) % 8,
                        226..=289 => 226 + (id - 226) / 8 * 8 + 7 - (id - 226) % 8,
                        _ => id,
                    })
                    .collect();
                expected.sort_unstable();
                assert_eq!(expected, mirror_features.ids[view]);
            }
            let mut actions: Vec<_> = p
                .legal_action_ids()
                .into_iter()
                .map(reflected_action)
                .collect();
            actions.sort_unstable();
            let mut mirrored_actions = mirror.legal_action_ids();
            mirrored_actions.sort_unstable();
            assert_eq!(actions, mirrored_actions);
            for action in p.legal_action_ids() {
                assert_eq!(
                    reflected_position(p.play(action).unwrap()),
                    mirror.play(reflected_action(action)).unwrap()
                );
            }
        }
    }
    for (pawns, winner) in [([76, 49], 0), ([31, 4], 1)] {
        let terminal = Position {
            pawns,
            winner: Some(winner),
            turn: winner ^ 1,
            ..Position::default()
        }
        .checked()
        .unwrap();
        let mirrored = reflected_position(terminal).checked().unwrap();
        assert_eq!(mirrored.winner, terminal.winner);
        assert!(mirrored.legal_action_ids().is_empty());
        // Reflection changes no player identity. Decisive z is copied verbatim,
        // never sign-flipped as it would be for a player swap.
        let z = if terminal.winner == Some(terminal.turn) {
            1
        } else {
            -1
        };
        let mirrored_z = if mirrored.winner == Some(mirrored.turn) {
            1
        } else {
            -1
        };
        assert_eq!(z, mirrored_z);
    }
}
#[test]
fn compact_bulk_preserves_native_views_and_independent_rejections() {
    let input = features(asymmetric());
    let mut malformed = input;
    malformed[0] = f32::NAN;
    let batch: Vec<_> = [input, malformed, input].into_iter().flatten().collect();
    let mut bits = [0u8; 3 * 78];
    let mut distance = [0f32; 6];
    let mut status = [255u8; 3];
    let rc = unsafe {
        quoridor_data::quoridor_sigma_compact(
            batch.as_ptr(),
            3,
            bits.as_mut_ptr(),
            distance.as_mut_ptr(),
            status.as_mut_ptr(),
        )
    };
    assert_eq!(rc, 0);
    assert_eq!(status, [0, 1, 0]);
    let native = quoridor_nnue::encode_qf1(sigma_plane_position(&input).unwrap()).unwrap();
    for row in [0, 2] {
        for view in 0..2 {
            let decoded: Vec<u16> = (0..312)
                .filter(|id| {
                    let at = view * 312 + id;
                    bits[row * 78 + at / 8] & (1 << (at % 8)) != 0
                })
                .map(|id| id as u16)
                .collect();
            let mut expected = native.ids[view].clone();
            expected.sort_unstable();
            assert_eq!(decoded, expected);
        }
        assert_eq!(&distance[row * 2..row * 2 + 2], native.distance.as_slice());
    }
    assert!(bits[78..156].iter().all(|v| *v == 0));
}
#[test]
fn original_and_p2_canonical_maps_and_lr_padding() {
    for turn in [0, 1] {
        let p = Position {
            turn,
            ..asymmetric()
        }
        .checked()
        .unwrap();
        let input = features(p);
        let decoded = sigma_plane_position(&input).unwrap();
        assert_eq!(features(decoded), input);
        assert_eq!(decoded.turn, 0); // canonicalSTM, not original actual side
        let mut naive = [0.; 648];
        for plane in 0..8 {
            for y in 0..9 {
                for x in 0..9 {
                    naive[plane * 81 + y * 9 + x] = input[plane * 81 + y * 9 + 8 - x];
                }
            }
        }
        // A shifted interior vertical wall can still describe a legal board,
        // and its full distance maps may match when that edge is immaterial.
        // Therefore naiveLR is not universally rejectable by validity alone.
        let mirror_bits = |bits: u64| {
            let mut out = 0;
            for a in 0..64 {
                if bits & (1 << a) != 0 {
                    out |= 1 << (a / 8 * 8 + 7 - a % 8);
                }
            }
            out
        };
        let mirror = Position {
            pawns: p.pawns.map(|c| c / 9 * 9 + 8 - c % 9),
            horizontal: mirror_bits(p.horizontal),
            vertical: mirror_bits(p.vertical),
            ..p
        };
        let correct = features(mirror.checked().unwrap());
        assert!(sigma_plane_position(&correct).is_ok());
        assert_ne!(naive, correct);
        let boundary = Position {
            vertical: 1 << (2 * 8),
            ..p
        };
        let original = features(boundary.checked().unwrap());
        let mut bad_padding = [0.; 648];
        for plane in 0..8 {
            for y in 0..9 {
                for x in 0..9 {
                    bad_padding[plane * 81 + y * 9 + x] = original[plane * 81 + y * 9 + 8 - x];
                }
            }
        }
        assert!(sigma_plane_position(&bad_padding).is_err());
    }
}
#[test]
fn external_z_only_availability_zero_exclusion_and_tensor_bytes() {
    let input = features(asymmetric());
    let mut raw = Vec::new();
    for (index, z) in [1f32, 0., -1.].into_iter().enumerate() {
        raw.extend((index as u64).to_le_bytes());
        for value in input {
            raw.extend(value.to_le_bytes());
        }
        raw.extend(z.to_le_bytes());
    }
    let output = dir("dataset");
    let cfg = OutcomeImportConfig {
        source: "fixed-source".into(),
        revision: "fixed-revision".into(),
        shard: "cycle".into(),
        split: Split::Train,
        records: 3,
        output: output.clone(),
    };
    let receipt = import_sigma_outcomes(Cursor::new(raw), &cfg).unwrap();
    assert_eq!(receipt["zero"], 1);
    let rows = read_dataset(&output, false).unwrap();
    assert_eq!(rows.len(), 3);
    for row in &rows {
        assert!(matches!(row.teacher, Teacher::ExternalOutcome { .. }));
        assert_eq!(row.teacher.value(), None);
        assert!(row.history_key.is_empty());
        assert_eq!(row.game, "UNAVAILABLE");
    }
    assert!(!rows[1].eligible);
    let mut invalid = rows[1].clone();
    invalid.eligible = true;
    assert!(invalid.validate().is_err());
    let mut fractional = rows[0].clone();
    fractional.z = Some(0.5);
    assert!(fractional.validate().is_err());
    let c1 = dir("cache1");
    let c2 = dir("cache2");
    write_tensor_cache(&output, &c1, false).unwrap();
    write_tensor_cache(&output, &c2, false).unwrap();
    for name in ["x.f32", "distance.f32", "labels.f32"] {
        assert_eq!(
            file_sha(&c1.join(name)).unwrap(),
            file_sha(&c2.join(name)).unwrap()
        );
    }
    let bytes = std::fs::read(c1.join("labels.f32")).unwrap();
    for index in 0..3 {
        assert!(f32::from_le_bytes(bytes[index * 8..index * 8 + 4].try_into().unwrap()).is_nan());
    }
    let meta = std::fs::read_to_string(c1.join("rows.jsonl")).unwrap();
    let m: serde_json::Value = serde_json::from_str(meta.lines().next().unwrap()).unwrap();
    assert!(m["game"].is_null());
    assert!(m["ply"].is_null());
    assert!(m["rootmean"].is_null());
    assert_eq!(m["teacher_type"], "external_terminal_outcome");
    for p in [output, c1, c2] {
        std::fs::remove_dir_all(p).unwrap();
    }
}
