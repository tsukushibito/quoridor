"""Single finite CPU reference entry with existing child/resource ownership."""

from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time

from . import cycle_process as process
from .sigma_reference import _error_fact, _finalize_reference


def named_physics():
    """One cheap process-name/module and RAM check; no storage inventory."""
    ancestors, pid = set(), os.getpid()
    while pid and pid not in ancestors:
        ancestors.add(pid)
        info = process.process_info(pid)
        pid = info["parent"] if info else 0
    foreign = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or int(entry.name) in ancestors:
            continue
        try:
            args = (entry / "cmdline").read_bytes().split(b"\0")
        except FileNotFoundError:
            continue
        if not args or not args[0]:
            continue
        name = Path(os.fsdecode(args[0])).name
        modules = {
            "quoridor_training.train",
            "quoridor_training.qualification",
            "quoridor_training.epoch_measurement",
            "quoridor_training.sigma_reference",
            "quoridor_training.sigma_reference_control",
        }
        if (
            name in {"cargo", "rustc", "clippy-driver", "nnue-diagnose", "quoridor-research"}
            or name.startswith(("research_baseline-", "nnue_search-"))
            or any(os.fsdecode(arg) in modules for arg in args)
        ):
            info = process.process_info(int(entry.name))
            if info and info["state"] != "Z":
                foreign.append({"identity": process.identity(info), "executable": name})
    return {
        "named_foreign_science": foreign,
        "MemAvailable_after_cgroup_bytes": process.available_memory(),
        "scope": "one-shot named processes/modules; unrecognized external workload UNKNOWN",
    }


def run_guard(guard, result, output):
    if guard["issue"] != "quoridor-4lc.323.5" or guard["goal_issue"] != "quoridor-4lc":
        raise ValueError("reference issue binding")
    if any(guard[key] is not None for key in ("end_at", "notify_until", "max_runtime_seconds")):
        raise ValueError("reference scientific horizons must be null")
    os.sched_setaffinity(0, set(guard["CPU"]))
    result["actual_CPU_affinity"] = sorted(os.sched_getaffinity(0))
    if result["actual_CPU_affinity"] != [2, 3]:
        raise ValueError("reference CPU2,3 scope")
    for path, sha in guard["expected_files_sha256"].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != sha:
            raise ValueError("reference control binding changed: " + path)
    result["phase"] = "storage_admission"
    admission = json.loads(Path(guard["storage_admission"]).read_text())
    forecast = json.loads(Path(guard["storage_forecast"]).read_text())
    if (
        forecast["evidence_capacity_B"] != admission["evidence_after_B"]
        or forecast["learning_capacity_B"] != admission["learning_total_B"]
        or forecast["required_evidence_B"] > admission["evidence_after_B"]
        or forecast["required_whole_B"] > admission["learning_total_B"]
    ):
        raise process.CycleStopped("reference concrete storage admission unresolved")
    cfg = json.loads(Path(guard["reference_config"]).read_text())
    if Path(cfg["output"]) != output / "output":
        raise ValueError("owned fresh reference output path")
    result["phase"] = "physics"
    result["physics"] = named_physics()
    if result["physics"]["named_foreign_science"]:
        raise process.CycleStopped("foreign named scientific process at entry")
    if result["physics"]["MemAvailable_after_cgroup_bytes"] < (
        guard["max_memory_bytes"] + guard["host_ram_reserve"]
    ):
        raise process.CycleStopped("reference family4GiB plus host reserve admission")
    result["phase"] = "resource_admission"
    resources = process.GPUResources(guard, output, None)
    result["observed"] = resources.observed
    resources.check()
    # Only the newly declared owned root is checked by the resource guard.
    (output / "tmp").mkdir()
    os.environ.update(
        OPENBLAS_NUM_THREADS="1",
        OMP_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
        NUMEXPR_NUM_THREADS="1",
        CUDA_VISIBLE_DEVICES="",
        TMPDIR=str(output / "tmp"),
    )
    process.LOG_MAX_BYTES = guard["child_log_max_bytes"]
    result["phase"] = "reference_child"
    record = process.execute(
        [
            sys.executable,
            "-B",
            "-m",
            "quoridor_training.sigma_reference",
            guard["reference_config"],
        ],
        output / "reference.log",
        None,
        resources=resources,
    )
    result["child_process"] = record
    if not record["cleanup_complete"] or not record["direct_child_reaped"] or record["remaining"]:
        raise process.CycleStopped("reference exact cleanup incomplete")
    if record["child"] and process.alive(record["child"]):
        raise process.CycleStopped("reference recorded child still alive")
    result["phase"] = "reference_receipt"
    receipt = json.loads((output / "output" / "reference-result.json").read_text())
    if (
        receipt["status"] != "PASS_REFERENCE"
        or receipt["V_rows"] != 419150
        or receipt["V_rows_completed"] != 419150
        or not math.isfinite(receipt["NNUE_ONNX_CPU16_max_abs_error"])
        or not 0 <= receipt["NNUE_ONNX_CPU16_max_abs_error"] <= 1e-6
        or not math.isfinite(receipt["V_row_MSE"])
        or not 0 <= receipt["V_row_MSE"] <= 4
    ):
        raise ValueError("finite reference completion receipt refused")
    for model, rows in (("Sigma", 420782), ("NNUE_ORT", 1648), ("native_input", 419150)):
        counter = receipt["counts"][model]
        if any(
            counter[key] != rows
            for key in ("attempted_rows", "returned_rows", "completed_validated_rows")
        ):
            raise ValueError("reference exact completed row accounting")
    result["reference_result_SHA"] = hashlib.sha256(
        (output / "output" / "reference-result.json").read_bytes()
    ).hexdigest()
    resources.check()
    result.update(status="PASS_GUARD", phase="COMPLETED")


def main():
    result = {
        "status": "STARTED",
        "phase": "guard_configuration",
        "counts": {},
        "started_at": datetime.now(timezone.utc).isoformat(),
        "observed": "NOT_STARTED",
        "child_process": "NOT_STARTED",
        "resource_scope": "CPU2,3/family4GiB incl64MiBcontroller/whole-device6GiB/GPU0",
    }
    output, primary, secondary = None, None, []
    started = time.perf_counter()
    try:
        with process.cancellation_signals():
            guard = json.loads(Path(sys.argv[1]).read_text())
            candidate = Path(guard["output"])
            result["phase"] = "guard_output_allocation"
            candidate.mkdir(parents=True, exist_ok=False)
            output = candidate
            run_guard(guard, result, output)
    except BaseException as error:
        primary = error
        raise
    finally:
        # execute owns TERM/KILL/direct wait; inspect even its failed-child receipt.
        if output is not None and result["phase"] == "reference_child":
            try:
                record_path = output / "reference.process.json"
                if record_path.exists():
                    result["child_process"] = json.loads(record_path.read_text())
                else:
                    result["child_process"] = "NOT_RECORDED; no cleanup success inferred"
            except BaseException as error:
                secondary.append(("child_process_receipt", error))
                result["child_process_receipt_error"] = _error_fact(error)
        result["stopped_at"] = datetime.now(timezone.utc).isoformat()
        result["whole_guard_seconds"] = time.perf_counter() - started
        _finalize_reference(result, output, primary, [], secondary)
    print(
        json.dumps(
            {"status": result["status"], "whole_guard_seconds": result["whole_guard_seconds"]}
        )
    )


if __name__ == "__main__":
    main()
