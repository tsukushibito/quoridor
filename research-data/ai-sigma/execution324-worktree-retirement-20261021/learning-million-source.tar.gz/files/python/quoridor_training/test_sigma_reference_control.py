"""Model-free tests of actual Sigma reference gates and finalization handlers."""

import ast
from contextlib import nullcontext
import copy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

from . import sigma_reference as ref
from . import sigma_reference_control as control


class ReferenceControlTests(unittest.TestCase):
    def test_both_roles_refuse_nonfinite_range_dtype_and_shape(self):
        bad = [np.array([v], np.float32) for v in (np.nan, np.inf, -np.inf, 1.25, -1.25)]
        bad += [np.array([0.0], np.float64), np.zeros((2,), np.float32)]
        for value in bad:
            for role in ("Torch_reference", "ORT_export"):
                with self.subTest(role=role, value=repr(value)):
                    with self.assertRaises(ValueError) as caught:
                        ref._accept_nnue(value, role)
                    self.assertEqual(caught.exception.refused_case["role"], role)
        for v in (-1, 0, 1):
            ref._accept_nnue(np.array([v], np.float32))
            self.assertEqual(
                ref._accept_sigma(np.zeros((1, 136), np.float32), np.array([[v]], np.float32)),
                v,
            )
        with self.assertRaises(ValueError):
            ref._accept_sigma(np.zeros((1, 136), np.float32), np.array([[1.25]], np.float32))

    def test_computed_difference_itself_must_be_finite_and_prebound(self):
        a = np.array([0.25], np.float32)
        with patch.object(ref.np, "max", return_value=np.nan):
            with self.assertRaises(ValueError) as caught:
                ref._export_difference(a, a)
        self.assertEqual(caught.exception.refused_case["role"], "computed_difference")
        with self.assertRaises(ValueError):
            ref._export_difference(a, a + np.float32(2e-6))
        self.assertEqual(ref._export_difference(a, a), 0.0)

    def test_actual_qualification_loop_refuses_before_warmup(self):
        function = next(
            x
            for x in ast.parse(Path(ref.__file__).read_text()).body
            if isinstance(x, ast.FunctionDef) and x.name == "_run_reference"
        )
        start = next(
            i
            for i, x in enumerate(function.body)
            if isinstance(x, ast.Assign)
            and isinstance(x.targets[0], ast.Name)
            and x.targets[0].id == "max_difference"
        )
        end = next(
            i
            for i, x in enumerate(function.body)
            if isinstance(x, ast.Assign)
            and isinstance(x.value, ast.Constant)
            and x.value.value == "warmup"
        )
        # Compile the live qualification loop and the actual transition to warmup.
        code = ast.fix_missing_locations(
            ast.Module(body=copy.deepcopy(function.body[start : end + 1]), type_ignores=[])
        )
        for bad in (np.nan, np.inf, 1.25):
            result = {"phase": "export_qualification"}
            namespace = {
                "torch": SimpleNamespace(inference_mode=nullcontext, from_numpy=lambda x: x),
                "qfeeds": [{"features": None, "distance": None, "side": None}],
                "model": lambda *args: SimpleNamespace(numpy=lambda: np.array([bad], np.float32)),
                "nnue_value": lambda feeds: np.array([0.25], np.float32),
                "_export_difference": ref._export_difference,
                "_completed": ref._completed,
                "counts": {"NNUE_torch": ref._counter()},
                "hook": SimpleNamespace(remove=lambda: None),
                "returned_hook": SimpleNamespace(remove=lambda: None),
                "result": result,
            }
            with self.assertRaises(ValueError):
                exec(compile(code, "live-reference-qualification-loop", "exec"), namespace)
            self.assertEqual(result["phase"], "export_qualification")
            self.assertEqual(namespace["counts"]["NNUE_torch"]["completed_validated_rows"], 0)

    def result(self):
        counter = ref._counter()
        ref._attempt(counter, 4)
        ref._returned(counter, 2)
        ref._completed(counter, 1)
        return {"status": "STARTED", "phase": "Sigma_loading", "counts": {"Sigma": counter}}

    def test_all_readers_and_receipt_attempted_with_primary_and_secondary(self):
        primary, close_error, io_error = (
            KeyboardInterrupt("original cancel"),
            OSError("close"),
            OSError("persist"),
        )
        calls = []

        def close_first():
            calls.append("first")
            raise close_error

        readers = [
            SimpleNamespace(close=close_first),
            SimpleNamespace(close=lambda: calls.append("second")),
        ]
        result = self.result()
        with tempfile.TemporaryDirectory() as d:
            with patch.object(Path, "write_text", side_effect=io_error):
                with self.assertRaises(BaseExceptionGroup) as caught:
                    ref._finalize_reference(result, Path(d), primary, readers)
        self.assertEqual(calls, ["first", "second"])
        self.assertEqual(caught.exception.exceptions, (primary, close_error, io_error))
        self.assertEqual(result["status"], "FAILED")
        self.assertEqual(result["primary_error"]["type"], "KeyboardInterrupt")
        self.assertEqual(
            [x["stage"] for x in result["secondary_errors"]], ["reader_close", "receipt_persist"]
        )
        facts = caught.exception.__notes__[0]
        self.assertIn("nonrecursive reference fallback facts", facts)
        self.assertIn("attempted_not_returned_execution_UNKNOWN_rows_upper", facts)

    def test_primary_persisted_without_being_replaced(self):
        primary = ValueError("model loading refused")
        primary.refused_case = {"role": "fixed_model"}
        result = self.result()
        with tempfile.TemporaryDirectory() as d:
            ref._finalize_reference(result, Path(d), primary, [])
            saved = json.loads((Path(d) / "reference-result.json").read_text())
        self.assertEqual(saved["failed_phase"], "Sigma_loading")
        self.assertEqual(saved["refused_case"], primary.refused_case)
        self.assertEqual(
            saved["counts"]["Sigma"]["attempted_not_returned_execution_UNKNOWN_rows_upper"], 2
        )
        self.assertEqual(saved["counts"]["Sigma"]["returned_not_validated_rows"], 1)

    def test_actual_main_handler_preserves_early_primary_and_failed_receipt(self):
        for phase in ("admission", "Sigma_loading", "paired_timing"):
            primary, io_error = KeyboardInterrupt(phase), OSError("receipt unavailable")

            def body(cfg, result, readers):
                result["phase"] = phase
                raise primary

            with tempfile.TemporaryDirectory() as d:
                config = Path(d) / "config.json"
                config.write_text(json.dumps({"output": str(Path(d) / "out")}))
                with (
                    patch.object(ref.sys, "argv", ["sigma-reference", str(config)]),
                    patch.object(ref, "_run_reference", side_effect=body),
                    patch.object(Path, "write_text", side_effect=io_error),
                ):
                    with self.assertRaises(BaseExceptionGroup) as caught:
                        ref.main()
            self.assertIs(caught.exception.exceptions[0], primary)
            self.assertIs(caught.exception.exceptions[1], io_error)
            self.assertIn(phase, caught.exception.__notes__[0])

    def test_existing_output_never_overwritten_on_admission_failure(self):
        with tempfile.TemporaryDirectory() as d:
            output = Path(d) / "old"
            output.mkdir()
            receipt = output / "reference-result.json"
            receipt.write_text("old evidence")
            config = Path(d) / "config.json"
            config.write_text(json.dumps({"output": str(output)}))
            with patch.object(ref.sys, "argv", ["sigma-reference", str(config)]):
                with self.assertRaises(BaseExceptionGroup) as caught:
                    ref.main()
            self.assertIsInstance(caught.exception.exceptions[0], FileExistsError)
            self.assertEqual(receipt.read_text(), "old evidence")

    def test_actual_main_configuration_failure_has_explicit_fallback(self):
        with patch.object(ref.sys, "argv", ["sigma-reference"]):
            with self.assertRaises(BaseExceptionGroup) as caught:
                ref.main()
        self.assertIsInstance(caught.exception.exceptions[0], IndexError)
        self.assertIn('"failed_phase": "configuration"', caught.exception.__notes__[0])


class GuardianControlTests(unittest.TestCase):
    def test_observed_attempt_return_and_output_validation_are_distinct(self):
        function = next(
            x
            for x in ast.parse(Path(ref.__file__).read_text()).body
            if isinstance(x, ast.FunctionDef) and x.name == "_run_reference"
        )
        nested = next(
            x for x in function.body if isinstance(x, ast.FunctionDef) and x.name == "nnue_value"
        )
        module = ast.fix_missing_locations(
            ast.Module(body=[copy.deepcopy(nested)], type_ignores=[])
        )
        for failure_at_return in (False, True):
            count = ref._counter()
            run = lambda *args: [np.array([np.nan], np.float32)]
            if failure_at_return:

                def run(*args):
                    raise OSError("runtime return not observed")

            namespace = dict(
                counts={"NNUE_ORT": count},
                nnue=SimpleNamespace(run=run),
                _attempt=ref._attempt,
                _returned=ref._returned,
                _completed=ref._completed,
                _accept_nnue=ref._accept_nnue,
            )
            exec(compile(module, "actual-nnue-value-counter", "exec"), namespace)
            with self.assertRaises((ValueError, OSError)):
                namespace["nnue_value"]({})
            self.assertEqual(count["attempted_rows"], 1)
            self.assertEqual(count["returned_rows"], 0 if failure_at_return else 1)
            self.assertEqual(count["completed_validated_rows"], 0)

    def test_concrete_storage_deficit_refuses_before_physics_or_child(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            admission, forecast = root / "admission.json", root / "forecast.json"
            admission.write_text(json.dumps({"evidence_after_B": 1024, "learning_total_B": 2048}))
            forecast.write_text(
                json.dumps(
                    {
                        "evidence_capacity_B": 1024,
                        "learning_capacity_B": 2048,
                        "required_evidence_B": 1025,
                        "required_whole_B": 2048,
                    }
                )
            )
            guard = {
                "issue": "quoridor-4lc.323.5",
                "goal_issue": "quoridor-4lc",
                "end_at": None,
                "notify_until": None,
                "max_runtime_seconds": None,
                "CPU": [2, 3],
                "expected_files_sha256": {},
                "storage_admission": str(admission),
                "storage_forecast": str(forecast),
            }
            result = {"phase": "guard_configuration"}
            with (
                patch.object(control, "named_physics") as physics,
                patch.object(control.process, "execute") as child,
            ):
                with self.assertRaisesRegex(control.process.CycleStopped, "storage admission"):
                    control.run_guard(guard, result, root / "out")
            physics.assert_not_called()
            child.assert_not_called()
            self.assertEqual(result["phase"], "storage_admission")

    def test_actual_guard_handler_records_early_binding_failure(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            guard = root / "guard.json"
            guard.write_text(
                json.dumps(
                    {"output": str(root / "out"), "issue": "wrong", "goal_issue": "quoridor-4lc"}
                )
            )
            with patch.object(control.sys, "argv", ["guard", str(guard)]):
                with self.assertRaisesRegex(ValueError, "issue binding") as caught:
                    control.main()
            saved = json.loads((root / "out" / "reference-result.json").read_text())
        self.assertEqual(saved["status"], "FAILED")
        self.assertEqual(saved["child_process"], "NOT_STARTED")
        self.assertEqual(saved["primary_error"]["message"], str(caught.exception))

    def test_actual_guard_failed_child_record_retained_without_wait_fabrication(self):
        primary = OSError("child runtime failure")
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            output = root / "out"
            cfg = root / "config.json"
            cfg.write_text(json.dumps({"output": str(output / "output")}))
            guard = root / "guard.json"
            guard.write_text(
                json.dumps(
                    {
                        "output": str(output),
                        "issue": "quoridor-4lc.323.5",
                        "goal_issue": "quoridor-4lc",
                        "CPU": [2, 3],
                        "end_at": None,
                        "notify_until": None,
                        "max_runtime_seconds": None,
                        "expected_files_sha256": {},
                        "reference_config": str(cfg),
                        "max_memory_bytes": 4 * 1024**3,
                        "host_ram_reserve": 4 * 1024**3,
                        "child_log_max_bytes": 4096,
                    }
                )
            )
            admission = root / "admission.json"
            forecast = root / "forecast.json"
            admission.write_text(json.dumps({"evidence_after_B": 1024, "learning_total_B": 2048}))
            forecast.write_text(
                json.dumps(
                    {
                        "evidence_capacity_B": 1024,
                        "learning_capacity_B": 2048,
                        "required_evidence_B": 512,
                        "required_whole_B": 1024,
                    }
                )
            )
            value = json.loads(guard.read_text())
            value.update(storage_admission=str(admission), storage_forecast=str(forecast))
            guard.write_text(json.dumps(value))
            old_log_bound = control.process.LOG_MAX_BYTES
            old_environment = dict(control.os.environ)
            try:
                with (
                    patch.object(control.sys, "argv", ["guard", str(guard)]),
                    patch.object(
                        control,
                        "named_physics",
                        return_value={
                            "named_foreign_science": [],
                            "MemAvailable_after_cgroup_bytes": 12 * 1024**3,
                        },
                    ),
                    patch.object(
                        control.process,
                        "GPUResources",
                        return_value=SimpleNamespace(observed={}, check=lambda: None),
                    ),
                    patch.object(control.process, "execute", side_effect=primary),
                ):
                    with self.assertRaises(OSError) as caught:
                        control.main()
                saved = json.loads((output / "reference-result.json").read_text())
            finally:
                control.process.LOG_MAX_BYTES = old_log_bound
                control.os.environ.clear()
                control.os.environ.update(old_environment)
        self.assertIs(caught.exception, primary)
        self.assertEqual(saved["failed_phase"], "reference_child")
        self.assertEqual(saved["child_process"], "NOT_RECORDED; no cleanup success inferred")

    def test_actual_guard_primary_and_receipt_io_both_preserved(self):
        primary, io_error = ValueError("admission primary"), OSError("receipt IO")
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            guard = root / "guard.json"
            guard.write_text(json.dumps({"output": str(root / "out")}))
            with (
                patch.object(control.sys, "argv", ["guard", str(guard)]),
                patch.object(control, "run_guard", side_effect=primary),
                patch.object(Path, "write_text", side_effect=io_error),
            ):
                with self.assertRaises(BaseExceptionGroup) as caught:
                    control.main()
        self.assertEqual(caught.exception.exceptions, (primary, io_error))


if __name__ == "__main__":
    unittest.main()
