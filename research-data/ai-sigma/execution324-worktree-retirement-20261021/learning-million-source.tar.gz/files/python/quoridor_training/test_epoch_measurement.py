"""Observer bookkeeping tests without Torch or a model forward."""

import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

from .epoch_measurement import EpochMeasurement


class MeasurementTests(unittest.TestCase):
    def observer(self, root, mode):
        path = root / "config.json"
        path.write_text(
            json.dumps(
                {
                    "mode": mode,
                    "epochs": 1,
                    "candidate_adoption": False,
                    "profiler_steps": [1025, 1040],
                    "warmup_steps": 257,
                }
            )
        )
        return EpochMeasurement(path, root / "output")

    def test_plain_has_no_Torch_or_profiler_and_no_adoption(self):
        with tempfile.TemporaryDirectory() as tmp:
            observer = self.observer(Path(tmp), "plain")
            observer.install()
            with observer.span("anything", device=True):
                pass
            observer.begin_step(1)
            observer.end_update(2048)
            result = observer.finish({"completed_epochs": 1}, "DIAGNOSTIC", {"train": 2048})
            self.assertFalse(result["candidate_adoption"])
            self.assertEqual(result["nested_spans"], {})
            self.assertEqual(result["profiler_key_averages"], [])
            self.assertEqual(result["training_loop_rows"], 2048)

    def test_detailed_wrappers_preserve_result_and_restore(self):
        with tempfile.TemporaryDirectory() as tmp:
            observer = self.observer(Path(tmp), "detailed")
            target = types.SimpleNamespace(f=lambda x: x + 1)
            original = target.f
            with patch.dict("sys.modules", {"torch": types.SimpleNamespace()}):
                observer.wrap(target, "f", "CPU_expand")
                self.assertEqual(target.f(2), 3)
            result = observer.finish({}, "DIAGNOSTIC", {})
            self.assertIs(target.f, original)
            span = result["nested_spans"]["initialization/CPU_expand"]
            self.assertEqual(span["calls"], 1)
            self.assertGreaterEqual(span["inclusive_wall_seconds"], 0)
            self.assertEqual(span["exclusive_wall_seconds"], span["inclusive_wall_seconds"])

    def test_reject_candidate_adoption(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.observer(root, "plain")
            path = root / "config.json"
            config = json.loads(path.read_text())
            config["candidate_adoption"] = True
            path.write_text(json.dumps(config))
            with self.assertRaises(ValueError):
                EpochMeasurement(path, root)


if __name__ == "__main__":
    unittest.main()
