"""Canonical retained Sigma value-network input; no training or sealed input."""

import numpy as np

from .public_features import validate_geometry, wall_bits


def planes(geometry):
    """Canonical STM pawn/segments/stocks and two wall-only goal-distance maps."""
    validate_geometry(geometry)
    n = len(geometry)
    out = np.zeros((n, 8, 9, 9), dtype=np.float32)
    flat = out.reshape(n, 8, 81)
    ix = np.arange(n)
    flat[ix, 0, geometry["pawns"][:, 0]] = 1
    flat[ix, 1, geometry["pawns"][:, 1]] = 1
    h = wall_bits(geometry["horizontal"]).reshape(n, 8, 8)
    v = wall_bits(geometry["vertical"]).reshape(n, 8, 8)
    out[:, 2, :8, :8] = h
    out[:, 2, :8, 1:] = np.maximum(out[:, 2, :8, 1:], h)
    out[:, 3, :8, :8] = v
    out[:, 3, 1:, :8] = np.maximum(out[:, 3, 1:, :8], v)
    for player, goal in ((0, 8), (1, 0)):
        out[:, 4 + player] = (geometry["stocks"][:, player].astype(np.float64) / 10).astype(
            np.float32
        )[:, None, None]
        distance = np.full((n, 9, 9), 81, dtype=np.uint8)
        frontier = np.zeros((n, 9, 9), dtype=bool)
        distance[:, goal, :] = 0
        frontier[:, goal, :] = True
        for depth in range(1, 81):
            nxt = np.zeros_like(frontier)
            horizontal_open = out[:, 2, :8, :] == 0
            vertical_open = out[:, 3, :, :8] == 0
            nxt[:, 1:, :] |= frontier[:, :8, :] & horizontal_open
            nxt[:, :8, :] |= frontier[:, 1:, :] & horizontal_open
            nxt[:, :, 1:] |= frontier[:, :, :8] & vertical_open
            nxt[:, :, :8] |= frontier[:, :, 1:] & vertical_open
            nxt &= distance == 81
            if not nxt.any():
                break
            distance[nxt] = depth
            frontier = nxt
        scaled = (distance.astype(np.float64) / 80).astype(np.float32)
        scaled[distance == 81] = 1
        out[:, 6 + player] = scaled
    return out


import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time


def _owned_distance(view):
    """Copy record views: singleton C-contiguity can still retain a 66B stride."""
    return view.copy(order="C")


def _refuse(message, role, value=None):
    error = ValueError(message)
    error.refused_case = {"role": role}
    if value is not None:
        error.refused_case.update(
            shape=list(value.shape), dtype=str(value.dtype), value_repr=repr(value)
        )
    raise error


def _accept_nnue(value, role="NNUE"):
    if (
        value.shape not in ((1,), (1, 1))
        or value.dtype != np.dtype("float32")
        or not np.isfinite(value).all()
        or np.any(np.abs(value) > 1)
    ):
        _refuse("invalid finite FP32 tanh prediction", role, value)
    return value


def _accept_sigma(policy, value):
    if (
        policy.shape != (1, 136)
        or policy.dtype != np.dtype("float32")
        or not np.isfinite(policy).all()
    ):
        _refuse("invalid fixed Sigma policy output", "Sigma_policy", policy)
    if value.shape != (1, 1):
        _refuse("invalid fixed Sigma value shape", "Sigma_value", value)
    _accept_nnue(value, "Sigma_value")
    return float(value[0, 0])


def _export_difference(expected, actual):
    _accept_nnue(expected, "Torch_reference")
    _accept_nnue(actual, "ORT_export")
    if expected.shape != actual.shape:
        _refuse("NNUE reference export shape mismatch", "correspondence")
    difference = float(np.max(np.abs(actual - expected)))
    if not math.isfinite(difference) or difference > 1e-6:
        _refuse(
            "nonfinite or >1e-6 export correspondence error",
            "computed_difference",
            np.asarray([difference], dtype=np.float32),
        )
    return difference


def _counter():
    return {
        key: 0
        for key in (
            "attempted_invocations",
            "attempted_rows",
            "returned_invocations",
            "returned_rows",
            "completed_validated_invocations",
            "completed_validated_rows",
        )
    }


def _attempt(counter, rows):
    counter["attempted_invocations"] += 1
    counter["attempted_rows"] += rows


def _returned(counter, rows):
    counter["returned_invocations"] += 1
    counter["returned_rows"] += rows


def _completed(counter, rows):
    counter["completed_validated_invocations"] += 1
    counter["completed_validated_rows"] += rows


def _error_fact(error):
    try:
        message = str(error)
    except BaseException:
        message = "<exception stringification failed>"
    return {"type": type(error).__name__, "message": message}


def _finalize_reference(result, output, primary, readers, secondary=()):
    failures = list(secondary)
    if primary is not None:
        result["status"] = "FAILED"
        result["failed_phase"] = result["phase"]
        result["primary_error"] = _error_fact(primary)
        result["refused_case"] = getattr(primary, "refused_case", None)
    result["reader_close_attempts"] = len(readers)
    for reader in readers:
        try:
            reader.close()
        except BaseException as error:
            failures.append(("reader_close", error))
    for counter in result["counts"].values():
        counter["attempted_not_returned_execution_UNKNOWN_rows_upper"] = (
            counter["attempted_rows"] - counter["returned_rows"]
        )
        counter["returned_not_validated_rows"] = (
            counter["returned_rows"] - counter["completed_validated_rows"]
        )
    if failures:
        result["status"] = "FAILED"
        result.setdefault("failed_phase", failures[0][0])
    result["secondary_errors"] = [{"stage": stage, **_error_fact(e)} for stage, e in failures]
    try:
        if output is None:
            raise OSError("receipt destination unavailable during early configuration failure")
        (output / "reference-result.json").write_text(
            json.dumps(result, indent=2, allow_nan=False) + "\n"
        )
    except BaseException as error:
        failures.append(("receipt_persist", error))
        result["status"] = "FAILED"
        result.setdefault("failed_phase", "receipt_persist")
        result["secondary_errors"] = [{"stage": stage, **_error_fact(e)} for stage, e in failures]
    if failures:
        errors = ([primary] if primary is not None else []) + [e for _, e in failures]
        group = BaseExceptionGroup("reference primary/finalization failures", errors)
        facts = {
            key: result.get(key)
            for key in (
                "status",
                "failed_phase",
                "primary_error",
                "secondary_errors",
                "refused_case",
                "counts",
            )
        }
        group.add_note(
            "nonrecursive reference fallback facts: " + json.dumps(facts, allow_nan=False)
        )
        raise group


def main():
    result = {
        "status": "STARTED",
        "phase": "configuration",
        "counts": {
            name: _counter() for name in ("Sigma", "NNUE_ORT", "NNUE_torch", "native_input")
        },
        "count_scope": "observed Python API/forward hooks; attempted/returned/validated distinct; "
        "individual output-valid returns, not cross-runtime qualification; "
        "internal startup and TorchScript replay executions UNKNOWN",
        "torch_export_backend_execution": "NOT_STARTED",
        "Sigma_scope": "full maintained policy+value ONNX, read value only; no MCTS",
        "newE_Sigma_sealed_release": False,
        "teacher": "same already-open originalV z STM ±1",
        "public_training_history_exposure": "UNKNOWN",
        "GPU": 0,
    }
    readers, output, primary = [], None, None
    started = time.perf_counter()
    try:
        cfg = json.loads(Path(sys.argv[1]).read_text())
        os.sched_setaffinity(0, {2, 3})
        result["actual_CPU_affinity"] = sorted(os.sched_getaffinity(0))
        candidate_output = Path(cfg["output"])
        result["phase"] = "output_allocation"
        candidate_output.mkdir(exist_ok=False, parents=True)
        output = candidate_output
        _run_reference(cfg, result, readers)
    except BaseException as error:
        primary = error
        raise
    finally:
        result["whole_reference_seconds"] = time.perf_counter() - started
        _finalize_reference(result, output, primary, readers)
    print(
        json.dumps(
            {
                "status": result["status"],
                "V_rows": result["V_rows"],
                "counts": result["counts"],
            }
        )
    )


def _run_reference(cfg, result, readers):
    result["phase"] = "admission"
    import onnxruntime as ort
    from .public_features import RECORD, features, geometry_from_native
    from .public_sigma import NativeCompact

    counts = result["counts"]
    result["actual_ORT_version"] = ort.__version__
    result["backend"] = "CPUExecutionProvider/FP32/thread1/ORT sequential"
    for path, expected in cfg["expected_files_sha256"].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise ValueError("fixed reference binding changed: " + path)
    output = Path(cfg["output"])
    source = Path(cfg["cache"])
    manifest = json.loads((source / "cache.json").read_text())
    part = next(x for x in manifest["partitions"] if x["name"] == "validation")
    if part["rows"] != 419150 or part["bytes"] != part["rows"] * RECORD.itemsize:
        raise ValueError("fixed original validation denominator")
    validation_file = source / part["file"]
    if (
        part["file"] != "validation.bin"
        or hashlib.sha256(validation_file.read_bytes()).hexdigest() != part["sha256"]
    ):
        raise ValueError("fixed validation bytes")
    result["phase"] = "validation_cache"
    records = np.memmap(validation_file, dtype=RECORD, mode="r", shape=(part["rows"],))
    readers.append(records._mmap)
    if not np.isin(records["z"], (-1, 1)).all():
        raise ValueError("decisive STM teacher")
    result["phase"] = "Sigma_loading"
    native = NativeCompact(cfg["library"])
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    options.inter_op_num_threads = 1
    options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    tick = time.perf_counter()
    sigma = ort.InferenceSession(
        cfg["Sigma_model"], sess_options=options, providers=["CPUExecutionProvider"]
    )
    result["model_loading_seconds"] = time.perf_counter() - tick
    if [(x.name, x.shape, x.type) for x in sigma.get_inputs()] != [
        ("input", [1, 8, 9, 9], "tensor(float)")
    ]:
        raise ValueError("retained Sigma input")
    if [(x.name, x.shape, x.type) for x in sigma.get_outputs()] != [
        ("policy_logits", [1, 136], "tensor(float)"),
        ("value", [1, 1], "tensor(float)"),
    ]:
        raise ValueError("retained Sigma outputs")

    result["actual_Sigma_providers"] = sigma.get_providers()

    def sigma_value(x):
        _attempt(counts["Sigma"], 1)
        outputs = sigma.run(["policy_logits", "value"], {"input": x})
        _returned(counts["Sigma"], 1)
        value = _accept_sigma(*outputs)
        _completed(counts["Sigma"], 1)
        return value

    result["phase"] = "fixed_preprocessing"
    # Fixed target-blind ordinal workload; same inputs on both backends.
    ix = np.linspace(0, len(records) - 1, 16, dtype=np.int64)
    result["workload"] = {
        "V_ordinals": ix.tolist(),
        "warmup_each": 32,
        "timed_each": 1600,
        "pair_order": "each ordinal100 Sigma then NNUE",
        "ordinal_SHA": hashlib.sha256(ix.astype("<i8").tobytes()).hexdigest(),
    }
    fixed = records[ix].copy()
    result["workload"]["fixed_records_SHA"] = hashlib.sha256(fixed.tobytes()).hexdigest()
    tick = time.perf_counter()
    sx = planes(fixed["geometry"])
    result["fixed16_preprocessing_seconds"] = time.perf_counter() - tick
    qx = features(fixed["geometry"])
    model_setup_started = time.perf_counter()
    result["phase"] = "NNUE_loading"
    import torch

    result["actual_Torch_version"] = torch.__version__

    from .common import resolve_config
    from .train import build_model

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    result["actual_Torch_threads"] = torch.get_num_threads()
    fit = resolve_config(cfg["fit_config"])
    binding = json.loads(Path(cfg["input_binding"]).read_text())
    scale = json.loads(Path(binding["scale_artifact"]).read_text())
    torch.manual_seed(fit["training"]["seed"])
    model = build_model(fit["model"], scale).eval()
    checkpoint = torch.load(cfg["NNUE_checkpoint"], map_location="cpu", weights_only=True)
    if (
        checkpoint["model_config"] != fit["model"]
        or checkpoint["dataset_sha"] != binding["cache_manifest_sha"]
        or checkpoint["target"] != "z"
        or checkpoint["position"] != cfg["NNUE_checkpoint_position"]
        or any(checkpoint["scale"][key] != scale[key] for key in ("mu_f32", "sigma_f32"))
    ):
        raise ValueError("fixed trained checkpoint config/scale/data/position")
    model.load_state_dict(checkpoint["model"], strict=True)
    parameters = np.concatenate(
        [
            v.detach().numpy().astype("<f4").ravel()
            for v in (
                model.ft.weight,
                model.ft.bias,
                model.h.weight,
                model.h.bias,
                model.out.weight,
                model.out.bias,
            )
        ]
    )
    if hashlib.sha256(parameters.tobytes()).hexdigest() != cfg["NNUE_parameters_SHA"]:
        raise ValueError("trained BEST parameter identity")
    result["NNUE_checkpoint_load_model_setup_seconds"] = time.perf_counter() - model_setup_started
    result["NNUE_reference"] = {
        "checkpoint": cfg["NNUE_checkpoint"],
        "parameters_SHA": cfg["NNUE_parameters_SHA"],
        "position": cfg["NNUE_checkpoint_position"],
        "saved_originalV_MSE": cfg["NNUE_saved_V_MSE"],
    }
    args = (
        torch.from_numpy(qx[:1]),
        torch.from_numpy(_owned_distance(fixed["distance"][:1])),
        torch.ones(1, dtype=torch.long),
    )

    def forward_count(_, inputs):
        _attempt(counts["NNUE_torch"], int(inputs[0].shape[0]))

    def forward_returned(_, inputs, _output):
        _returned(counts["NNUE_torch"], int(inputs[0].shape[0]))

    hook = model.register_forward_pre_hook(forward_count)
    returned_hook = model.register_forward_hook(forward_returned)
    result["phase"] = "NNUE_export"
    result["torch_export_backend_execution"] = (
        "UNKNOWN additional internal/JIT replay; Python hooks observed only"
    )
    tick = time.perf_counter()
    torch.onnx.export(
        model,
        args,
        str(output / "TRAINED-BEST-reference.onnx"),
        input_names=["features", "distance", "side"],
        output_names=["value"],
        opset_version=17,
        dynamo=False,
    )
    result["NNUE_ONNX_export_seconds"] = time.perf_counter() - tick
    result["phase"] = "NNUE_ORT_loading"
    nnue = ort.InferenceSession(
        str(output / "TRAINED-BEST-reference.onnx"),
        sess_options=options,
        providers=["CPUExecutionProvider"],
    )
    qfeeds = [
        {
            "features": qx[i : i + 1],
            "distance": _owned_distance(fixed["distance"][i : i + 1]),
            "side": np.ones(1, dtype=np.int64),
        }
        for i in range(len(ix))
    ]

    def nnue_value(feeds):
        _attempt(counts["NNUE_ORT"], 1)
        value = nnue.run(["value"], feeds)[0]
        _returned(counts["NNUE_ORT"], 1)
        _accept_nnue(value, "ORT_export")
        _completed(counts["NNUE_ORT"], 1)
        return value

    result["actual_NNUE_providers"] = nnue.get_providers()
    result["actual_ORT_threads"] = {
        "intra": nnue.get_session_options().intra_op_num_threads,
        "inter": nnue.get_session_options().inter_op_num_threads,
    }
    result["phase"] = "export_qualification"
    max_difference = 0.0
    with torch.inference_mode():
        for feeds in qfeeds:
            expected = model(
                torch.from_numpy(feeds["features"]),
                torch.from_numpy(feeds["distance"]),
                torch.from_numpy(feeds["side"]),
            ).numpy()
            actual = nnue_value(feeds)
            difference = _export_difference(expected, actual)
            _completed(counts["NNUE_torch"], 1)
            max_difference = max(max_difference, difference)
    hook.remove()
    returned_hook.remove()
    result["NNUE_ONNX_CPU16_max_abs_error"] = max_difference
    if max_difference > 1e-6:
        raise ValueError("paired inference export boundary differs > prebound1e-6")
    result["phase"] = "warmup"
    warmup_started = time.perf_counter()
    for i in range(32):
        sigma_value(sx[i % 16 : i % 16 + 1])
        nnue_value(qfeeds[i % 16])
    result["paired_warmup_seconds"] = time.perf_counter() - warmup_started
    timings = {"Sigma": [], "NNUE_full_FT_head": []}
    # Target-blind fixed order, alternating whole-network calls, 100 per row.
    result["phase"] = "paired_timing"
    benchmark_started = time.perf_counter()
    for i in range(16):
        for _ in range(100):
            _attempt(counts["Sigma"], 1)
            tick = time.perf_counter_ns()
            outputs = sigma.run(["policy_logits", "value"], {"input": sx[i : i + 1]})
            timings["Sigma"].append(time.perf_counter_ns() - tick)
            _returned(counts["Sigma"], 1)
            _accept_sigma(*outputs)
            _completed(counts["Sigma"], 1)
            _attempt(counts["NNUE_ORT"], 1)
            tick = time.perf_counter_ns()
            value = nnue.run(["value"], qfeeds[i])[0]
            timings["NNUE_full_FT_head"].append(time.perf_counter_ns() - tick)
            _returned(counts["NNUE_ORT"], 1)
            _accept_nnue(value, "ORT_export")
            _completed(counts["NNUE_ORT"], 1)
    result["benchmark_whole_with_checks_seconds"] = time.perf_counter() - benchmark_started
    result["latency_scope"] = (
        "synchronous CPU ORT session.run, includes runtime/caller boundary; "
        "output acceptance outside per-call timer; not kernel-only latency; "
        "Sigma builds feed dict and slices inside timer; NNUE prebuilt feeds indexed inside"
    )
    result["latency_ns"] = {
        name: {
            "n": len(values),
            "median": float(np.median(values)),
            "p90": float(np.percentile(values, 90)),
            "p99": float(np.percentile(values, 99)),
        }
        for name, values in timings.items()
    }
    np.savez(
        output / "latency.npz",
        **{k: np.asarray(v, np.int64) for k, v in timings.items()},
    )
    # Equal dtype/backend/CPU/thread/batch; dense QF1 fullFT is not sparse
    # native/delta/reusedhead. Saved V accuracy is a separate observation.
    result["NNUE_timing_scope"] = (
        "fixed trainedBEST dense QF1 full two-view FT+head+D, ORT batch1; "
        "precomputed QF1 and distance outside timer, not native sparse/delta"
    )
    mse = np.float64(0)
    sign_correct = 0
    prediction_hash = hashlib.sha256()
    input_hash = hashlib.sha256()
    preprocessing = validation = forward = 0.0
    by_shard = {}
    for first in range(0, len(records), 128):
        rows = records[first : first + 128].copy()
        tick = time.perf_counter()
        x = planes(rows["geometry"])
        preprocessing += time.perf_counter() - tick
        tick = time.perf_counter()
        result["phase"] = "MSE_native_input"
        _attempt(counts["native_input"], len(rows))
        bits, distance, codes = native.convert(x.reshape(-1, 648))
        _returned(counts["native_input"], len(rows))

        if (
            np.any(codes != 0)
            or not np.array_equal(geometry_from_native(bits), rows["geometry"])
            or not np.array_equal(distance, rows["distance"])
        ):
            raise ValueError("same-V canonical Sigma/QF1/distance restoration")
        _completed(counts["native_input"], len(rows))
        validation += time.perf_counter() - tick
        input_hash.update(x.tobytes())
        tick = time.perf_counter()
        result["phase"] = "MSE_forward"
        prediction = np.asarray([sigma_value(x[i : i + 1]) for i in range(len(x))], dtype="<f4")
        forward += time.perf_counter() - tick
        prediction_hash.update(prediction.tobytes())
        result["phase"] = "MSE_aggregation"
        error = (prediction.astype(np.float64) - rows["z"].astype(np.float64)) ** 2
        mse += error.sum(dtype=np.float64)
        sign_correct += int(np.count_nonzero(np.sign(prediction) == rows["z"]))
        for shard in np.unique(rows["shard"]):
            mask = rows["shard"] == shard
            state = by_shard.setdefault(str(int(shard)), {"rows": 0, "squared_error": 0.0})
            state["rows"] += int(mask.sum())
            state["squared_error"] += float(error[mask].sum(dtype=np.float64))
        result["V_rows_completed"] = first + len(rows)
    result.update(
        status="PASS_REFERENCE",
        phase="COMPLETED",
        V_rows=len(records),
        V_row_MSE=float(mse / len(records)),
        V_sign_accuracy=sign_correct / len(records),
        V_by_shard=by_shard,
        V_prediction_f32_SHA=prediction_hash.hexdigest(),
        V_canonical_input_SHA=input_hash.hexdigest(),
        V_preprocessing_seconds=preprocessing,
        V_native_input_validation_seconds=validation,
        V_forward_and_output_checks_seconds=forward,
        predictions_preservation="stream f32 SHA+same immutable row order/targets, aggregate; no full array",
    )


if __name__ == "__main__":
    main()
