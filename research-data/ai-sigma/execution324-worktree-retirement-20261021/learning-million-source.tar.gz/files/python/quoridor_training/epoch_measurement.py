"""Measurement-only observer for one actual epoch; never a training horizon.

Plain observes lifecycle walls only. Detailed adds nested CPU clocks and one
small existing torch.profiler window. Inputs, math, sampler and guards are kept.
"""

from collections import defaultdict
from contextlib import contextmanager, nullcontext
from functools import wraps
import json
from pathlib import Path
import time


class EpochMeasurement:
    def __init__(self, config_path, output):
        self.config = json.loads(Path(config_path).read_text())
        if self.config["mode"] not in ("plain", "detailed"):
            raise ValueError("measurement mode")
        if self.config["epochs"] != 1 or self.config["candidate_adoption"] is not False:
            raise ValueError("diagnostic scope is exactly one discarded epoch")
        self.detailed = self.config["mode"] == "detailed"
        self.output = Path(output)
        self.started = time.monotonic()
        self.cpu_started = time.process_time()
        self.scope = "initialization"
        self.instrumentation = defaultdict(float)
        self.lifecycle = defaultdict(float)
        self.lifecycle_cpu = defaultdict(float)
        self.scope_started = self.started
        self.scope_cpu_started = self.cpu_started
        self.stack = []
        self.totals = defaultdict(lambda: defaultdict(float))
        self.restores = []
        self.profiler = None
        self.profiler_active = False
        self.profiler_records = []
        self.device_samples = defaultdict(list)
        self.step = 0
        self.loop_updates = 0
        self.loop_rows = 0
        self.loop_first_update = None
        self.loop_rest_wall = 0.0
        self.warmup_update_wall = 0.0
        self.post_warmup_update_wall = 0.0
        self.loop_tick = None
        self.done = False

    def set_scope(self, name):
        now, cpu = time.monotonic(), time.process_time()
        self.lifecycle[self.scope] += now - self.scope_started
        self.lifecycle_cpu[self.scope] += cpu - self.scope_cpu_started
        self.scope, self.scope_started, self.scope_cpu_started = name, now, cpu

    @contextmanager
    def scoped(self, name):
        previous = self.scope
        self.set_scope(name)
        try:
            yield
        finally:
            self.set_scope(previous)

    def span(self, name, *, device=False):
        return self._span(name, device=device) if self.detailed else nullcontext()

    @contextmanager
    def _span(self, name, *, device=False):
        import torch

        key = self.scope + "/" + name
        frame = {"wall": time.perf_counter(), "cpu": time.process_time(), "child": 0.0}
        self.stack.append(frame)
        events = None
        if device and self.profiler_active:
            events = (torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True))
            events[0].record()
        record = (
            torch.profiler.record_function("epoch_measurement/" + name)
            if self.profiler_active
            else nullcontext()
        )
        try:
            with record:
                yield
        finally:
            if events:
                events[1].record()
                self.device_samples[key].append(events)
            elapsed = time.perf_counter() - frame["wall"]
            total = self.totals[key]
            total["inclusive_wall_seconds"] += elapsed
            total["exclusive_wall_seconds"] += elapsed - frame["child"]
            total["process_cpu_seconds_inclusive"] += time.process_time() - frame["cpu"]
            total["calls"] += 1
            self.stack.pop()
            if self.stack:
                self.stack[-1]["child"] += elapsed

    def wrap(self, target, attribute, name):
        original = getattr(target, attribute)

        @wraps(original)
        def observed(*args, **kwargs):
            with self.span(name):
                return original(*args, **kwargs)

        setattr(target, attribute, observed)
        self.restores.append((target, attribute, original))

    def install(self):
        if not self.detailed:
            return
        from . import compact_cache, sampling, train

        for target, attribute, name in (
            (compact_cache.CompactCorpus, "records", "compact_gather_read"),
            (compact_cache, "features", "CPU_geometry_to_QF1"),
            (sampling.ReflectionBatches, "batch", "supply_including_reflection_RNG"),
            (sampling.EpochSampler, "next_batch", "epoch_sampling_shuffle_index"),
            (train, "training_statistics", "T_statistics"),
            (train, "load", "cache_load_hash_validate_groups"),
            (train, "write", "small_JSON_record_write"),
            (train, "export", "native_export_saved_bytes"),
            (train, "write_sampling_counts", "visit_counts_compression"),
            (train, "compact_measurements", "metric_aggregation"),
        ):
            self.wrap(target, attribute, name)

    def begin_step(self, step):
        self.step = step
        self.loop_tick = time.monotonic()
        window = self.config["profiler_steps"]
        if self.detailed and step == window[0]:
            import torch

            tick = time.monotonic()
            self.profiler = torch.profiler.profile(
                activities=[
                    torch.profiler.ProfilerActivity.CPU,
                    torch.profiler.ProfilerActivity.CUDA,
                ],
                record_shapes=False,
                profile_memory=False,
                with_stack=False,
            )
            self.profiler.__enter__()
            self.profiler_active = True
            self.instrumentation["profiler_start"] += time.monotonic() - tick

    def end_update(self, rows):
        elapsed = time.monotonic() - self.loop_tick
        self.loop_updates += 1
        self.loop_rows += rows
        if self.step <= self.config["warmup_steps"]:
            self.warmup_update_wall += elapsed
        else:
            self.post_warmup_update_wall += elapsed
        if self.loop_first_update is None:
            self.loop_first_update = elapsed
        else:
            self.loop_rest_wall += elapsed
        if self.detailed and self.step == self.config["profiler_steps"][1]:
            self.stop_profiler()

    def stop_profiler(self):
        if not self.profiler_active:
            return
        tick = time.monotonic()
        self.profiler_active = False
        self.profiler.__exit__(None, None, None)
        for event in self.profiler.key_averages():
            self.profiler_records.append(
                {
                    "key": event.key,
                    "calls": event.count,
                    "device_type": str(event.device_type),
                    "self_CPU_us": event.self_cpu_time_total,
                    "inclusive_CPU_us": event.cpu_time_total,
                    "self_device_us": event.self_device_time_total,
                    "inclusive_device_us": event.device_time_total,
                }
            )
        import torch

        torch.cuda.synchronize()
        for key, events in self.device_samples.items():
            self.totals[key]["representative_CUDA_stream_elapsed_ms"] = sum(
                start.elapsed_time(end) for start, end in events
            )
            self.totals[key]["representative_CUDA_event_pairs"] = len(events)
        self.device_samples.clear()
        self.profiler = None
        self.instrumentation["profiler_stop_aggregate"] += time.monotonic() - tick

    def finish(self, position, status, forward_rows):
        self.stop_profiler()
        self.set_scope("completed")
        for target, attribute, original in reversed(self.restores):
            setattr(target, attribute, original)
        result = {
            "schema": "actual-epoch-measurement-v1",
            "config": self.config,
            "status": status,
            "position": position,
            "whole_train_call_seconds": time.monotonic() - self.started,
            "whole_process_CPU_seconds": time.process_time() - self.cpu_started,
            "lifecycle_disjoint_wall_seconds": dict(self.lifecycle),
            "lifecycle_process_CPU_seconds": dict(self.lifecycle_cpu),
            "nested_spans": dict(self.totals),
            "instrumentation_overhead_included_seconds": dict(self.instrumentation),
            "training_loop_updates": self.loop_updates,
            "training_loop_rows": self.loop_rows,
            "first_update_wall_seconds": self.loop_first_update,
            "remaining_update_wall_seconds": self.loop_rest_wall,
            "warmup_update_wall_seconds": self.warmup_update_wall,
            "post_warmup_update_wall_seconds": self.post_warmup_update_wall,
            "profiler_key_averages": self.profiler_records,
            "forward_rows_completed": forward_rows,
            "candidate_adoption": False,
            "newE_test_opened": False,
            "clock_rules": [
                "Lifecycle scopes partition wall; nested inclusive spans must not be added.",
                "CPU spans include launch/wait; CUDA event elapsed includes stream idle/host enqueue gaps.",
                "Only profiler self-device kernel/memcpy activities measure device active time.",
                "Profiler is representative only; its whole overhead is observed against the separate plain epoch.",
                "Diagnostic one-epoch termination is not a scientific fit horizon or convergence certificate.",
            ],
        }
        self.output.mkdir(parents=True, exist_ok=True)
        (self.output / "epoch-measurement.json").write_text(
            json.dumps(result, indent=2, allow_nan=False) + "\n"
        )
        return result


def main():
    import argparse
    from .train import train

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text())
    observer = EpochMeasurement(args.config, config["output"])
    observer.install()
    try:
        result = train(
            config["cache"],
            config["output"],
            config["fit_config"],
            input_binding=config["input_binding"],
            measurement=observer,
            **({"supply_workers": config["supply_workers"]} if "supply_workers" in config else {}),
        )
        if result["position"]["completed_epochs"] != 1 or not observer.done:
            raise ValueError("actual caller did not complete the requested diagnostic epoch")
        print(json.dumps({"status": result["status"], "candidate_adoption": False}))
    finally:
        if observer.restores:
            observer.stop_profiler()
            for target, attribute, original in reversed(observer.restores):
                setattr(target, attribute, original)


if __name__ == "__main__":
    main()
