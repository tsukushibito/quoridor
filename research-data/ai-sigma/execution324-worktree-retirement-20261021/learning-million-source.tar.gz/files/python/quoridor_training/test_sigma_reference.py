"""Small independent coordinate/BFS evidence for the Sigma input boundary."""

from collections import deque
import ast
import copy
from pathlib import Path
from types import SimpleNamespace
import unittest

import numpy as np

from .public_features import GEOMETRY, RECORD, reflect
from .sigma_reference import _owned_distance, planes


def independent_reference(row):
    out = np.zeros((8, 9, 9), np.float32)
    for player in range(2):
        cell = int(row["pawns"][player])
        out[player, cell // 9, cell % 9] = 1
        out[4 + player].fill(float(row["stocks"][player]) / 10)
    blocked = set()
    for a in range(64):
        x, y = a % 8, a // 8
        if (int(row["horizontal"]) >> a) & 1:
            for xx in (x, x + 1):
                out[2, y, xx] = 1
                blocked.add(frozenset(((xx, y), (xx, y + 1))))
        if (int(row["vertical"]) >> a) & 1:
            for yy in (y, y + 1):
                out[3, yy, x] = 1
                blocked.add(frozenset(((x, yy), (x + 1, yy))))
    for player, goal in ((0, 8), (1, 0)):
        distance = {(x, goal): 0 for x in range(9)}
        queue = deque(distance)
        while queue:
            x, y = queue.popleft()
            for next_cell in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                xx, yy = next_cell
                if (
                    0 <= xx < 9
                    and 0 <= yy < 9
                    and next_cell not in distance
                    and frozenset(((x, y), next_cell)) not in blocked
                ):
                    distance[next_cell] = distance[x, y] + 1
                    queue.append(next_cell)
        for y in range(9):
            for x in range(9):
                d = distance.get((x, y), 81)
                out[6 + player, y, x] = 1 if d == 81 else d / 80
    return out


class SigmaInputContracts(unittest.TestCase):
    def rows(self):
        g = np.zeros(5, GEOMETRY)
        g["pawns"] = [[4, 76], [0, 80], [8, 72], [35, 44], [64, 16]]
        g["stocks"] = [[10, 10], [3, 7], [0, 5], [6, 2], [4, 9]]
        g["horizontal"] = [0, 1, 1 << 63, (1 << 18) | (1 << 45), 1 << 29]
        g["vertical"] = [0, 1 << 63, 1, (1 << 7) | (1 << 56), 1 << 43]
        return g

    def test_both_goal_maps_boundaries_stocks_exact_independent_BFS(self):
        g = self.rows()
        actual = planes(g)
        expected = np.stack([independent_reference(x) for x in g])
        np.testing.assert_array_equal(actual, expected)
        self.assertEqual(actual.shape, (5, 8, 9, 9))
        self.assertEqual(actual.dtype, np.float32)
        self.assertTrue(actual.flags.c_contiguous)

    def test_reflection_maps_and_identity_preserve_player_goal_stock(self):
        g = self.rows()
        before = g.tobytes()
        expected = planes(g)[:, :, :, ::-1].copy()
        expected[:, 3, :, :8] = planes(g)[:, 3, :, :8][:, :, ::-1]
        expected[:, 3, :, 8] = 0
        np.testing.assert_array_equal(planes(reflect(g)), expected)
        np.testing.assert_array_equal(planes(reflect(reflect(g))), planes(g))
        self.assertEqual(g.tobytes(), before)

    def test_bad_dtype_shape_pawns_and_stock_rejected(self):
        for g in (np.zeros(1), np.zeros((1, 1), GEOMETRY)):
            with self.assertRaises(ValueError):
                planes(g)
        for field, value in (
            ("pawns", [81, 1]),
            ("pawns", [1, 1]),
            ("stocks", [11, 1]),
        ):
            g = self.rows()
            g[field][0] = value
            with self.assertRaises(ValueError):
                planes(g)


class TrainedReferenceContracts(unittest.TestCase):
    def test_actual_feeds_strides_exact(self):
        source = ast.parse(Path(__file__).with_name("sigma_reference.py").read_text())
        node = next(
            n
            for n in ast.walk(source)
            if isinstance(n, ast.Assign)
            and isinstance(n.targets[0], ast.Name)
            and n.targets[0].id == "qfeeds"
        )
        fixed = np.zeros(16, RECORD)
        fixed["distance"] = np.arange(32, dtype=np.float32).reshape(16, 2) / 32
        old = np.ascontiguousarray(fixed["distance"][:1])
        self.assertTrue(old.flags.c_contiguous and old.strides[0] % old.itemsize)
        env = {
            "np": np,
            "fixed": fixed,
            "ix": range(16),
            "qx": np.zeros((16, 2, 312), np.float32),
            "_owned_distance": _owned_distance,
        }
        exec(
            compile(
                ast.Module(body=[node], type_ignores=[]),
                "qfeeds",
                "exec",
            ),
            env,
        )
        for i, feed in enumerate(env["qfeeds"]):
            d = feed["distance"]
            self.assertEqual(d.strides, (8, 4))
            self.assertEqual(d.tobytes(), fixed["distance"][i : i + 1].tobytes())
            self.assertFalse(np.shares_memory(d, fixed))
        for view in (fixed["distance"][:1], fixed["distance"][2:7]):
            d = _owned_distance(view)
            self.assertEqual((d.shape, d.dtype), (view.shape, view.dtype))
            self.assertEqual(d.strides, (8, 4))
            self.assertEqual(d.tobytes(), view.tobytes())
            self.assertTrue(d.flags.owndata)
            self.assertFalse(np.shares_memory(d, view))

    def production_load(self, checkpoint):
        source = Path(__file__).with_name("sigma_reference.py").read_text()
        main = next(
            x
            for x in ast.parse(source).body
            if isinstance(x, ast.FunctionDef) and x.name == "_run_reference"
        )
        body = main.body
        start = next(
            i
            for i, node in enumerate(body)
            if isinstance(node, ast.Assign)
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == "checkpoint"
        )
        statements = ast.fix_missing_locations(
            ast.Module(body=copy.deepcopy(body[start : start + 3]), type_ignores=[])
        )
        calls = []

        def load(path, **options):
            calls.append(("load", path, options))
            return checkpoint

        def load_state(state, **options):
            calls.append(("load_state", state, options))

        position = {
            "step": 209559,
            "training_seen": 429111399,
            "row_epoch": 51.0,
            "completed_epochs": 51,
            "partial_epoch_fraction": 0.0,
        }
        namespace = {
            "torch": SimpleNamespace(load=load),
            "model": SimpleNamespace(load_state_dict=load_state),
            "cfg": {
                "NNUE_checkpoint": "fixed-best.pt",
                "NNUE_checkpoint_position": position,
            },
            "fit": {"model": {"transformer_width": 32, "hidden_width": 32}},
            "binding": {"cache_manifest_sha": "fixed-cache"},
            "scale": {"mu_f32": [0.1, 0.2], "sigma_f32": [0.3, 0.4]},
        }
        exec(compile(statements, "actual-trained-checkpoint-loader", "exec"), namespace)
        return calls

    def checkpoint(self):
        return {
            "model": {"trained_tensor": "model-state"},
            "model_config": {"transformer_width": 32, "hidden_width": 32},
            "dataset_sha": "fixed-cache",
            "target": "z",
            "position": {
                "step": 209559,
                "training_seen": 429111399,
                "row_epoch": 51.0,
                "completed_epochs": 51,
                "partial_epoch_fraction": 0.0,
            },
            "scale": {"mu_f32": [0.1, 0.2], "sigma_f32": [0.3, 0.4]},
        }

    def test_actual_loader_uses_trained_state_cpu_and_strict(self):
        checkpoint = self.checkpoint()
        calls = self.production_load(checkpoint)
        self.assertEqual(
            calls[0],
            ("load", "fixed-best.pt", {"map_location": "cpu", "weights_only": True}),
        )
        self.assertIs(calls[1][1], checkpoint["model"])
        self.assertEqual(calls[1][2], {"strict": True})

    def test_actual_loader_rejects_other_dataset_target_position_scale_or_model(self):
        for key, value in (
            ("dataset_sha", "other-cache"),
            ("target", "rootmean"),
            ("position", {"step": 0}),
            ("scale", {"mu_f32": [0.2, 0.1], "sigma_f32": [0.3, 0.4]}),
            ("model_config", {"transformer_width": 64}),
        ):
            checkpoint = self.checkpoint()
            checkpoint[key] = value
            with self.assertRaisesRegex(ValueError, "fixed trained checkpoint"):
                self.production_load(checkpoint)


if __name__ == "__main__":
    unittest.main()
