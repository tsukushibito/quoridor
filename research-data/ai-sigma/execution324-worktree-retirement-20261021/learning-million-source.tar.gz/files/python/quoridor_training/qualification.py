"""Finite supply/math fixtures with discarded states, not a selected training run.

The work question fixes inputs and repetitions. Time/forward budget limits may
be genuinely null; owned child cleanup and RAM/VRAM/output controls remain.
"""

import argparse
import json
import os
import shutil
from pathlib import Path
import statistics
import sys
import time

import numpy as np

from .cache import load, sha
from .common import resolve_config
from .cycle_process import GPUResources, cancellation_signals, execute
from .sampling import ReflectionBatches
from .train import build_model, export, write


def verify_inputs(config, *, require_native=True):
    admission = json.loads(Path(config["storage_admission"]).read_text())
    binding = json.loads(Path(config["input_binding"]).read_text())
    scale = json.loads(Path(config["scale"]).read_text())
    source_binding = json.loads(Path(config["source_binding"]).read_text())
    if (
        admission.get("admission") != "within"
        or admission.get("errors")
        or sha(config["storage_admission"]) != config["storage_admission_sha"]
        or sha(Path(config["cache"]) / "cache.json") != binding["cache_manifest_sha"]
        or sha(config["fit_config"]) != binding["fit_config_sha"]
        or sha(config["scale"]) != binding["scale_artifact_sha"]
        or sha(binding["constant_artifact"]) != binding["constant_artifact_sha"]
        or sha(config["source_binding"]) != config["source_binding_sha"]
        or scale.get("binding", {}).get("cache_manifest_sha") != binding["cache_manifest_sha"]
    ):
        raise ValueError("qualification input/admission binding before child/GPU")
    for path, digest in {
        **source_binding["source_paths_SHA"],
        **config["control_source_sha"],
    }.items():
        if sha(path) != digest:
            raise ValueError("qualification source/control changed before child/GPU: " + path)
    if require_native and sha(config["native_binary"]) != config["native_binary_sha"]:
        raise ValueError("fixed native diagnostic binary changed")


def prepare_native(config, resources):
    """Build the supported maintained caller once, then bind a private immutable ELF."""
    verify_inputs(config, require_native=False)
    root = Path(config["output"]).parent
    for name, command in (
        (
            "native-control-NN0",
            [
                "cargo",
                "test",
                "--release",
                "--offline",
                "--locked",
                "-p",
                "quoridor-runner",
                "--bin",
                "nnue-diagnose",
                "qualification_tests::diagnostic_null_limits_keep_native_work_and_finite_limits_still_stop_nn0",
                "--",
                "--exact",
            ],
        ),
        (
            "native-build",
            [
                "cargo",
                "build",
                "--release",
                "--offline",
                "--locked",
                "-p",
                "quoridor-runner",
                "--bin",
                "nnue-diagnose",
            ],
        ),
    ):
        execute(command, root / (name + ".log"), None, resources=resources)
    shared = Path(config["native_build_output"])
    digest = sha(shared)
    private = root / "immutable-native" / digest / "nnue-diagnose"
    private.parent.mkdir(parents=True)
    shutil.copyfile(shared, private)
    private.chmod(0o555)
    if (
        sha(shared) != digest
        or sha(private) != digest
        or shared.stat().st_size != private.stat().st_size
    ):
        raise ValueError("native immutable snapshot correspondence")
    prepared = {**config, "native_binary": str(private), "native_binary_sha": digest}
    write(root / "prepared-config.json", prepared)
    verify_inputs(prepared)
    live_root = root / "live-fixture"
    live_root.mkdir()
    execute(
        [
            "/usr/bin/env",
            "QUORIDOR_OBSERVATION_LIVE_TESTS=1",
            "QUORIDOR_OBSERVATION_TEST_ROOT=" + str(live_root),
            sys.executable,
            "-B",
            "-m",
            "unittest",
            "quoridor_training.test_observation.LiveTrainerObservation.test_live_compact_null_horizon_scientific_stop_named_exports_and_sealing",
            "-v",
        ],
        root / "live-trainer-fixture.log",
        None,
        resources=resources,
    )
    write(
        root / "native-ready.json",
        {
            "path": str(private),
            "SHA": digest,
            "bytes": private.stat().st_size,
            "sharedtarget_reader_writer_STOP": True,
            "source_binding_SHA": config["source_binding_sha"],
        },
    )
    return prepared


def native_reference(config, model, cfg, scale, output, name):
    """Maintained native full/delta/Scalar/Simd/undo fixture, with no search."""
    manifest = export(model, cfg, scale, {"a": 0, "b": 8}, output / (name + "-model"))
    native_config = {
        "mode": "qualify",
        "output": str(output / (name + "-native.json")),
        "counter": str(output / (name + "-counter.json")),
        "prefixes": [
            [],
            [13, 67, 81, 66, 14, 65],
            [13, 67, 81, 66, 14, 65, 143, 126, 150, 64, 141, 151],
        ],
        "engines": [{"id": name, "kind": "distance_residual", "manifest": str(manifest)}],
        "depths": [],
        "max_nodes": 1,
        "nn_cap": None,
        "processed_cap": None,
        "wall_seconds": None,
        "max_plies": 0,
        "cpu_core": 2,
        "ram_limit": 512 * 1024**2,
        "host_ram_reserve": 4 * 1024**3,
    }
    path = output / (name + "-native-config.json")
    write(path, native_config)
    execute([config["native_binary"], "--config", str(path)], output / (name + "-native.log"), None)
    result = json.loads(Path(native_config["output"]).read_text())
    if result["status"] != "PASS" or not result["parent_history_ply_exact_restore"]:
        raise ValueError("native fixture unsuccessful")
    features, distances, sides, values = [], [], [], []
    for row in result["predictions"]:
        feature = np.zeros((2, 312), dtype=np.float32)
        for view, ids in enumerate(row["feature"]["ids"]):
            feature[view, ids] = 1
        features.append(feature)
        distances.append(row["feature"]["distance"])
        sides.append(row["feature"]["side"] + 1)
        values.append(row["scalar_full"])
    return (
        np.asarray(features),
        np.asarray(distances, dtype=np.float32),
        np.asarray(sides, dtype=np.int64),
        np.asarray(values, dtype=np.float32),
        result,
    )


def qualify(config):
    started = time.monotonic()
    verify_inputs(config)
    import torch

    cfg = resolve_config(config["fit_config"])
    torch.set_num_threads(2)
    torch.set_num_interop_threads(2)
    torch.manual_seed(cfg["training"]["seed"])
    torch.cuda.manual_seed_all(cfg["training"]["seed"])
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    if not torch.cuda.is_available():
        raise ValueError("CUDA not available")
    free, total = torch.cuda.mem_get_info()
    if free < 2 * 1024**3:
        raise ValueError("CUDA display/host reserve")
    torch.cuda.set_per_process_memory_fraction(min(5 * 1024**3 / total, 1.0))
    corpus = load(config["cache"])
    scale = json.loads(Path(config["scale"]).read_text())
    indices = np.sort(
        np.random.default_rng(cfg["training"]["seed"] + 3).choice(
            np.flatnonzero(corpus.splits == 0), 2048, replace=False
        )
    )
    model = build_model(cfg["model"], scale)
    initial = {k: v.detach().clone() for k, v in model.state_dict().items()}
    output = Path(config["output"])
    output.mkdir()
    forward_rows = {"CPU": 0, "CUDA": 0, "native": 0}

    def counted(module, inputs):
        forward_rows["CUDA" if inputs[0].is_cuda else "CPU"] += len(inputs[0])

    model.register_forward_pre_hook(counted)

    def supply():
        return ReflectionBatches(
            corpus, cfg["training"]["reflection_probability"], cfg["training"]["reflection_seed"]
        )

    x, d, labels = supply().batch(indices, training=True)
    tx, td, ts = torch.from_numpy(x), torch.from_numpy(d), torch.ones(2048, dtype=torch.long)
    ty = torch.from_numpy(labels[:, 1].copy())

    def state():
        return {k: v.detach().cpu().numpy().copy() for k, v in model.state_dict().items()}

    def finite_update(optimizer, loss):
        if not torch.isfinite(loss):
            raise ValueError("nonfinite qualification loss")
        loss.backward()
        if not all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None):
            raise ValueError("nonfinite qualification gradient")

    def check_parameters():
        if not all(torch.isfinite(p).all() for p in model.parameters()):
            raise ValueError("nonfinite qualification parameter")

    native_reports = []

    def check_native(name):
        nx, nd, ns, nv, report = native_reference(config, model, cfg, scale, output, name)
        forward_rows["native"] += report["NN"]
        with torch.inference_mode():
            cpu = model(torch.from_numpy(nx), torch.from_numpy(nd), torch.from_numpy(ns)).numpy()
        difference = float(np.max(np.abs(cpu - nv)))
        if difference > 2e-6:
            raise ValueError("native/CPU FP32 correspondence")
        native_reports.append(
            {"name": name, "max_native_CPU_difference": difference, "native": report}
        )
        return nx, nd, ns, nv

    nx, nd, ns, nv = check_native("initial")
    with torch.inference_mode():
        cpu = model(tx, td, ts).numpy()
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg["optimizer"]["lr"], weight_decay=0)
    cpu_states = []
    for _ in range(2):
        optimizer.zero_grad(set_to_none=True)
        finite_update(optimizer, torch.nn.functional.mse_loss(model(tx, td, ts), ty))
        optimizer.step()
        check_parameters()
        cpu_states.append(state())
    check_native("after-two-discarded-updates")
    model.load_state_dict(initial)
    model.to("cuda")
    with torch.inference_mode():
        native_cuda = (
            model(
                torch.from_numpy(nx).to("cuda"),
                torch.from_numpy(nd).to("cuda"),
                torch.from_numpy(ns).to("cuda"),
            )
            .cpu()
            .numpy()
        )
    native_cuda_difference = float(np.max(np.abs(native_cuda - nv)))
    if native_cuda_difference > 2e-6:
        raise ValueError("native/CUDA initial correspondence")
    reports = []
    for batch_size in [128, 512, 2048]:
        model.load_state_dict(initial)
        with torch.inference_mode():
            initial_cuda = model(tx.to("cuda"), td.to("cuda"), ts.to("cuda")).cpu().numpy()
        initial_difference = float(np.max(np.abs(initial_cuda - cpu)))
        if initial_difference > 2e-6:
            raise ValueError("initial fixed-input CPU/CUDA prediction correspondence")
        optimizer = torch.optim.Adam(model.parameters(), lr=cfg["optimizer"]["lr"], weight_decay=0)
        differences = []
        for update in range(2):
            optimizer.zero_grad(set_to_none=True)
            prepared = supply()
            for first in range(0, 2048, batch_size):
                sub = indices[first : first + batch_size]
                features, distance, local = prepared.batch(sub, training=True)
                prediction = model(
                    torch.from_numpy(features).to("cuda"),
                    torch.from_numpy(distance).to("cuda"),
                    torch.ones(len(sub), dtype=torch.long, device="cuda"),
                )
                loss = (
                    torch.nn.functional.mse_loss(
                        prediction, torch.from_numpy(local[:, 1].copy()).to("cuda"), reduction="sum"
                    )
                    / 2048
                )
                finite_update(optimizer, loss)
            optimizer.step()
            check_parameters()
            current = state()
            error = max(float(np.max(np.abs(current[k] - cpu_states[update][k]))) for k in current)
            if error > 2e-6:
                raise ValueError("two-update fixed-objective CPU/CUDA supply correspondence")
            differences.append(error)
        # Production timing includes one optimizer update for EACH supplied batch.
        # Five measured repetitions plus one warm-up, every optimization state discarded.
        times = []
        torch.cuda.reset_peak_memory_stats()
        for repetition in range(6):
            model.load_state_dict(initial)
            optimizer = torch.optim.Adam(
                model.parameters(), lr=cfg["optimizer"]["lr"], weight_decay=0
            )
            prepared = supply()
            torch.cuda.synchronize()
            tick = time.monotonic()
            for first in range(0, 2048, batch_size):
                sub = indices[first : first + batch_size]
                features, distance, local = prepared.batch(sub, training=True)
                optimizer.zero_grad(set_to_none=True)
                prediction = model(
                    torch.from_numpy(features).to("cuda"),
                    torch.from_numpy(distance).to("cuda"),
                    torch.ones(len(sub), dtype=torch.long, device="cuda"),
                )
                loss = torch.nn.functional.mse_loss(
                    prediction, torch.from_numpy(local[:, 1].copy()).to("cuda")
                )
                finite_update(optimizer, loss)
                optimizer.step()
                check_parameters()
            torch.cuda.synchronize()
            elapsed = time.monotonic() - tick
            if repetition:
                times.append(elapsed)
        reports.append(
            {
                "batch_size": batch_size,
                "rows_each_repetition": 2048,
                "two_update_max_parameter_difference_vs_CPU": differences,
                "initial_max_prediction_difference_vs_CPU": initial_difference,
                "measured_supply_transfer_update_seconds": times,
                "median_seconds_per_original_row": statistics.median(times) / 2048,
                "allocated_peak_bytes": torch.cuda.max_memory_allocated(),
                "reserved_peak_bytes": torch.cuda.max_memory_reserved(),
                "qualified": True,
                "optimization_states": "discarded; not candidates",
                "includes_cold_initialization": False,
            }
        )
        write(
            output / "progress.json",
            {
                "reports": reports,
                "forward_rows": forward_rows,
                "wall_seconds": time.monotonic() - started,
            },
        )
    selected = min(
        reports,
        key=lambda report: (report["median_seconds_per_original_row"], report["batch_size"]),
    )
    corpus.verify_binding()
    verify_inputs(config)
    write(
        output / "result.json",
        {
            "status": "PASS",
            "reports": reports,
            "recommended_batch": selected["batch_size"],
            "batch_selection": "fixed min median per-row production supply/transfer/update among numerically qualified conditions; no fit weights selected",
            "native_reports": native_reports,
            "native_CUDA_initial_difference": native_cuda_difference,
            "initial_weights_SHA": sha(output / "initial-model/weights.f32"),
            "scale_SHA": sha(config["scale"]),
            "config_SHA": sha(config["fit_config"]),
            "cache_manifest_SHA": corpus.binding["dataset_sha"],
            "input_indices_SHA": sha_array(indices),
            "forward_rows": forward_rows,
            "CUDA_total_bytes": total,
            "CUDA_initial_free_bytes": free,
            "whole_worker_seconds": time.monotonic() - started,
            "test_opened": False,
            "scope": "two discarded updates fixed equal2048-row objective, train-only50% reflection; finite production-supply timing; native FTScalarSimd/headScalar full/delta/undo. Not convergence/strength/whole-fit speed.",
        },
    )


def sha_array(array):
    import hashlib

    return hashlib.sha256(np.asarray(array, dtype="<i8").tobytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--prepare-native", action="store_true")
    args = parser.parse_args()
    cfg = json.loads(Path(args.config).read_text())
    verify_inputs(cfg, require_native=not args.prepare_native)
    os.sched_setaffinity(0, {2, 3})
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    if args.worker:
        qualify(cfg)
        return
    root = Path(cfg["output"]).parent
    started = time.monotonic()
    deadline = None if cfg["seconds"] is None else started + cfg["seconds"]
    resources = GPUResources(
        {
            "max_memory_bytes": 4 * 1024**3 - cfg.get("parallel_review_reserve_bytes", 0),
            "host_ram_reserve": 4 * 1024**3,
            "max_output_bytes": 4 * 1024**2,
            "max_vram_bytes": 6 * 1024**3,
            "controller_reserve_bytes": 64 * 1024**2,
        },
        root,
        deadline,
    )
    try:
        with cancellation_signals():
            if args.prepare_native:
                cfg = prepare_native(cfg, resources)
                args.config = str(root / "prepared-config.json")
            execute(
                [
                    sys.executable,
                    "-B",
                    "-m",
                    "quoridor_training.qualification",
                    "--config",
                    args.config,
                    "--worker",
                ],
                root / "supply-qualification.log",
                deadline,
                resources=resources,
            )
    finally:
        write(
            root / "observed-resources.json",
            {
                **resources.observed,
                "wall_seconds": time.monotonic() - started,
                "sampling": "guardian sampling, not continuous peak; CPU/VRAM caps include controller/device others",
            },
        )


if __name__ == "__main__":
    main()
