"""Model-free actual execute/quiet-entry regressions for the r4 related repair."""

from contextlib import ExitStack
import json
from pathlib import Path
import signal
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

from . import cycle_process as process
from . import sigma_reference_control as control


class ExecuteFinalizationTests(unittest.TestCase):
    def run_fake(self, *, exit_code=1, errors=None):
        """Call live execute with fake OS child/handles; no child is spawned."""
        errors = errors or {}
        primary = process.CycleStopped("original child exit1")
        stream, selector, pipe = MagicMock(), MagicMock(), MagicMock()
        child = SimpleNamespace(
            pid=424242,
            stdout=pipe,
            returncode=exit_code,
            poll=MagicMock(return_value=exit_code),
            wait=MagicMock(return_value=exit_code),
        )
        info = {"pid": child.pid, "start_ticks": "123", "boot_id": "fake-boot"}
        selector.select.return_value = [(SimpleNamespace(fd=47, fileobj=pipe), None)]
        saved, mask_calls = [], []
        calls = []

        def save(_path, record):
            saved.append(json.loads(json.dumps(record)))
            if len(saved) == 2 and "receipt_persist" in errors:
                raise errors["receipt_persist"]

        def mask(*args):
            mask_calls.append(args)
            if len(mask_calls) == 4 and "signal_mask_restore" in errors:
                raise errors["signal_mask_restore"]
            return set()

        def close(stage):
            calls.append(stage)
            if stage in errors:
                raise errors[stage]

        for stage, target in (
            ("selector_close", selector.close),
            ("pipe_close", pipe.close),
            ("log_close", stream.close),
        ):
            target.side_effect = lambda stage=stage: close(stage)
        if "log_flush" in errors:
            stream.flush.side_effect = errors["log_flush"]
        with ExitStack() as stack:
            mocks = [
                patch.object(Path, "open", return_value=stream),
                patch.object(process.selectors, "DefaultSelector", return_value=selector),
                patch.object(process.subprocess, "Popen", return_value=child),
                patch.object(process.os, "pidfd_open", return_value=99),
                patch.object(process.os, "set_blocking"),
                patch.object(process.os, "read", return_value=b""),
                patch.object(process.os, "close", side_effect=lambda fd: close("pidfd_close")),
                patch.object(process, "process_info", return_value=info),
                patch.object(process, "members", return_value=[]),
                patch.object(process, "alive", return_value=False),
                patch.object(process, "save_record", side_effect=save),
                patch.object(process.signal, "pthread_sigmask", side_effect=mask),
                patch.object(process, "CycleStopped", return_value=primary),
            ]
            for mock in mocks:
                stack.enter_context(mock)
            try:
                process.execute(["fake-child"], Path("new-owned.log"), None)
            except BaseException as error:
                outcome = error
            else:
                self.fail("fixture requires a failure")
        child.wait.assert_called_once_with(timeout=3)
        self.assertEqual(mask_calls[-1][0], signal.SIG_SETMASK)
        self.assertEqual(calls, ["selector_close", "pipe_close", "pidfd_close", "log_close"])
        return outcome, primary, saved

    def test_child_failure_and_final_receipt_io_keep_original_and_all_closes(self):
        io = OSError("final process receipt IO")
        outcome, primary, saved = self.run_fake(errors={"receipt_persist": io})
        self.assertIsInstance(outcome, BaseExceptionGroup)
        self.assertEqual(outcome.exceptions, (primary, io))
        facts = json.loads(outcome.__notes__[0].split(": ", 1)[1])
        self.assertTrue(facts["direct_child_reaped"])
        self.assertTrue(facts["process_cleanup_complete"])
        self.assertTrue(facts["handle_closes_complete"])
        self.assertEqual(facts["final_record_persist"], "failed_or_partial_UNKNOWN")
        self.assertEqual(facts["signal_mask_restoration"], "completed")
        self.assertEqual(saved[-1]["primary_error"]["message"], str(primary))

    def test_log_receipt_handle_and_mask_errors_do_not_skip_each_other(self):
        stages = (
            "log_flush",
            "selector_close",
            "pipe_close",
            "pidfd_close",
            "log_close",
            "receipt_persist",
            "signal_mask_restore",
        )
        errors = {stage: OSError(stage) for stage in stages}
        outcome, primary, saved = self.run_fake(errors=errors)
        self.assertEqual(outcome.exceptions, (primary, *(errors[x] for x in stages)))
        facts = json.loads(outcome.__notes__[0].split(": ", 1)[1])
        self.assertTrue(facts["process_cleanup_complete"])
        self.assertFalse(facts["cleanup_complete"])
        self.assertFalse(facts["handle_closes_complete"])
        self.assertEqual([x["stage"] for x in facts["finalization_errors"]], list(stages))
        self.assertEqual(facts["signal_mask_restoration"], "failed_UNKNOWN")
        self.assertEqual(saved[-1]["status"], "failed")

    def test_completed_child_with_close_error_is_not_saved_as_success(self):
        io = OSError("pipe close IO")
        outcome, _primary, saved = self.run_fake(exit_code=0, errors={"pipe_close": io})
        self.assertEqual(outcome.exceptions, (io,))
        self.assertEqual(saved[-1]["status"], "failed")
        self.assertEqual(saved[-1]["finalization_failed_stage"], "pipe_close")
        self.assertTrue(saved[-1]["process_cleanup_complete"])
        self.assertFalse(saved[-1]["cleanup_complete"])

    def test_existing_owned_log_and_receipt_are_not_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            log = Path(d) / "owned.log"
            receipt = log.with_suffix(".process.json")
            log.write_bytes(b"old log")
            receipt.write_bytes(b"old receipt")
            selector = MagicMock()
            with (
                patch.object(process.selectors, "DefaultSelector", return_value=selector),
                patch.object(process.subprocess, "Popen") as popen,
                patch.object(process.signal, "pthread_sigmask", return_value=set()),
            ):
                with self.assertRaises(FileExistsError):
                    process.execute(["fake-child"], log, None)
            popen.assert_not_called()
            selector.close.assert_called_once()
            self.assertEqual(log.read_bytes(), b"old log")
            self.assertEqual(receipt.read_bytes(), b"old receipt")


class NamedQuietTests(unittest.TestCase):
    def test_actual_fake_proc_finds_nnue_search_and_ignores_benign_or_zombie(self):
        for command, state, expected in (
            ("/private/nnue_search-47a35", "S", True),
            ("/private/research_baseline-abc", "S", True),
            ("/usr/bin/python", "S", False),
            ("/private/nnue_search-47a35", "Z", False),
        ):
            with self.subTest(command=command, state=state), tempfile.TemporaryDirectory() as d:
                entry = Path(d) / "222"
                entry.mkdir()
                (entry / "cmdline").write_bytes(command.encode() + b"\0")

                def info(pid):
                    return {
                        "pid": pid,
                        "parent": 0,
                        "start_ticks": "123",
                        "boot_id": "fake",
                        "state": state,
                    }

                with (
                    patch.object(control.os, "getpid", return_value=111),
                    patch.object(control.process, "process_info", side_effect=info),
                    patch.object(Path, "iterdir", return_value=iter([entry])),
                    patch.object(control.process, "available_memory", return_value=12 * 1024**3),
                ):
                    facts = control.named_physics()
                self.assertEqual(bool(facts["named_foreign_science"]), expected)

    def test_actual_guard_refuses_named_runner_before_resources_or_execute(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            admission = root / "admission.json"
            admission.write_text(json.dumps({"evidence_after_B": 2, "learning_total_B": 4}))
            forecast = root / "forecast.json"
            forecast.write_text(
                json.dumps(
                    {
                        "evidence_capacity_B": 2,
                        "learning_capacity_B": 4,
                        "required_evidence_B": 1,
                        "required_whole_B": 3,
                    }
                )
            )
            cfg = root / "config.json"
            cfg.write_text(json.dumps({"output": str(root / "output")}))
            guard = {
                "issue": "quoridor-4lc.323.5",
                "goal_issue": "quoridor-4lc",
                "end_at": None,
                "notify_until": None,
                "max_runtime_seconds": None,
                "CPU": [2, 3],
                "expected_files_sha256": {},
                "storage_admission": str(admission),
                "storage_forecast": str(forecast),
                "reference_config": str(cfg),
            }
            with (
                patch.object(
                    control,
                    "named_physics",
                    return_value={"named_foreign_science": [{"executable": "nnue_search-known"}]},
                ),
                patch.object(control.process, "GPUResources") as resources,
                patch.object(control.process, "execute") as execute,
            ):
                with self.assertRaisesRegex(process.CycleStopped, "foreign named"):
                    control.run_guard(guard, {"phase": "configuration"}, root)
            resources.assert_not_called()
            execute.assert_not_called()


if __name__ == "__main__":
    unittest.main()
