"""Freeze directed source/control evidence, without executing the Rust inlet."""

from datetime import datetime, timezone
import difflib
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import time


W = Path("/workspaces/quoridor/.worktree/tt-hash-reuse351")
ROOT = W / ".artifacts/tt-hash-reuse351"
HERE = ROOT / "cost-caller-v1"
CANONICAL = Path("/workspaces/quoridor/research-data/ai-sigma/search-optimization/tt-hash-reuse351")


def stamp():
    return datetime.now(timezone.utc).isoformat()


def row(path):
    path = Path(path)
    info = path.stat()
    data = path.read_bytes()
    return {
        "path": str(path),
        "SHA256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": stat.S_IMODE(info.st_mode),
    }


def save(name, value):
    data = (json.dumps(value, indent=2) + "\n").encode()
    assert len(data) <= 65536, "directed control output upper"
    path = HERE / name
    assert not path.exists(), "frozen file exists"
    path.write_bytes(data)
    return row(path)


def main():
    os.sched_setaffinity(0, {3})
    resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
    began = time.monotonic()
    result = {"issue": "quoridor-4lc.351", "START": stamp(), "numeric_entry_now": False}
    lease = None
    try:
        spec = importlib.util.spec_from_file_location(
            "source_guard", ROOT / "controls/software-entry-recovery-v2/worker.py"
        )
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        result["quiet"] = guard.quiet()
        lease = guard.LOCK.open("a+")
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        expected = {
            "source-assignment-v1.json": "43dc47260c1ec826ca2fbea32a60b87d488ebc4c16884ceed2a895e57b0a796e",
            "software-acceptance-v1.json": "cf6e8c40022d2fbcc556a0bfe6b2cc444b0ec23ae626fe28d4dd449101da5dd1",
            "cost-caller-resources-v2.json": "c7ddad599a43d363908d6cb61657d6f01a6a0065dd54e9071e71da2106cfd980",
            "Root-retention-forward-v3.json": "132d1487d34a739fa719526ea96048fbd12a176648d3ce839681c3d8cdbe5795",
        }
        for name, digest in expected.items():
            assert row(CANONICAL / name)["SHA256"] == digest, name
        original = json.loads(
            (ROOT / "controls/software-entry-recovery-v2/qualified-STOP.json").read_text()
        )
        source_map = {v["path"]: v for v in original["source_control_records"][:140]}
        assert len(source_map) == 140
        old_path = W / "crates/quoridor-ai/src/tt_hash_reuse351_tests.rs"
        caller = W / "crates/quoridor-ai/src/tt_hash_processing351.rs"
        before = gzip.decompress((HERE / "qualified-private-before.rs.gz").read_bytes())
        assert (
            hashlib.sha256(before).hexdigest()
            == "966d455341714c37808993a15274fd97bf4781d5fa1595fc55b8435b1072191a"
        )
        current = old_path.read_bytes()
        assert current.startswith(before), "shared algorithm/old definitions changed"
        suffix = current[len(before) :]
        assert (
            suffix
            == b'\n// One compare-only inlet reuses this private prototype, never production Zobrist.\ninclude!("tt_hash_processing351.rs");\n'
        )
        for path, expected_row in source_map.items():
            if path != str(old_path):
                assert row(path) == expected_row, path
        source_map[str(old_path)] = row(old_path)
        source_map[str(caller)] = row(caller)
        assert len(source_map) == 141
        production = source_map[str(W / "crates/quoridor-ai/src/alphabeta.rs")]
        assert (
            production["SHA256"]
            == "b976df272b273a147596f36ec503a2801b802b45389d8169ca62468d7a02b335"
        )
        delta = "".join(
            difflib.unified_diff(
                before.decode().splitlines(True),
                current.decode().splitlines(True),
                fromfile="a/crates/quoridor-ai/src/tt_hash_reuse351_tests.rs",
                tofile="b/crates/quoridor-ai/src/tt_hash_reuse351_tests.rs",
            )
        )
        delta += "".join(
            difflib.unified_diff(
                [],
                caller.read_text().splitlines(True),
                fromfile="/dev/null",
                tofile="b/crates/quoridor-ai/src/tt_hash_processing351.rs",
            )
        )
        (HERE / "source.patch").write_text(delta)
        selected = [
            old_path,
            caller,
            HERE / "qualified-private-before.rs.gz",
            HERE / "contract.md",
            HERE / "question.md",
            HERE / "software-plan.json",
            HERE / "source.patch",
            HERE / "prewrite.json",
            HERE / "freeze.py",
        ]
        selected += [CANONICAL / name for name in expected]
        selected += [
            ROOT / "controls/software-entry-recovery-v2/qualified-STOP.json",
            ROOT / "source-control-repair-v2/source-binding.json",
            ROOT / "source-control/cost-comparison-contract.md",
        ]
        binding = {
            "issue": "quoridor-4lc.351",
            "source_records": sorted(source_map.values(), key=lambda r: r["path"]),
            "directed_review_inputs": [row(path) for path in selected],
            "unchanged_production": production,
            "exact_shared_prototype_and_thirteen_definition_prefix_unchanged": True,
            "changed_paths": [str(old_path), str(caller)],
            "new_definitions": {
                "affected_filters": 3,
                "explicit_ignored_inlet": 1,
                "qualification": "NOT_BUILT_NOT_TYPECHECKED_NOT_RUN",
            },
            "numeric_entry_now": False,
            "prepared_admission": False,
            "old_private_image": original["worker"]["private"],
            "old_private_relabelled": False,
            "whole_supported_B": 922746880,
            "current_resource_SHA256": expected["cost-caller-resources-v2.json"],
            "retained_floors_B": original["retained_component_floors_B"],
            "subcaps_B": json.loads((CANONICAL / "cost-caller-resources-v2.json").read_text())[
                "next_phase_suballocations_B"
            ],
            "binding_write_UTC": stamp(),
            "remaining": [],
        }
        result["source_binding"] = save("source-binding.json", binding)
        result["binding_write_UTC"] = binding["binding_write_UTC"]
        # Verify directed rows again after the complete binding is written.
        assert all(row(v["path"]) == v for v in binding["directed_review_inputs"])
        assert all(row(v["path"]) == v for v in binding["source_records"])
        result["source_reader_writer_STOP"] = stamp()
        result["selected_before_after"] = True
        result["source_records_count"] = 141
        result["review_input_bytes"] = sum(v["bytes"] for v in binding["directed_review_inputs"])
        assert result["review_input_bytes"] <= 1048576
        result["phase_allocated_B"] = (
            HERE.stat().st_blocks * 512
            + sum(p.stat().st_blocks * 512 for p in HERE.rglob("*"))
            + caller.stat().st_blocks * 512
            + len(suffix)
        )
        assert result["phase_allocated_B"] + 32768 < 262144, "phase+remaining admin upper"
        result["compiler_dependency_status"] = (
            "previous accepted stable1.99/offline payload hashes retained; future actual recheck required, no compiler executed"
        )
        result["compiler_env"] = json.loads((HERE / "software-plan.json").read_text())["env"]
        result["new_Cargo_native_model_Search_game_calls"] = 0
        result["status"] = "STOPPED_SOURCE_RELATED_REVIEW_REQUIRED"
    except BaseException as error:
        result["status"] = "SOURCE_FREEZE_REFUSAL"
        result["error"] = repr(error)
        raise
    finally:
        if lease:
            lease.close()
        result["lease_released"] = True
        result["STOP"] = stamp()
        result["wall_s"] = time.monotonic() - began
        result["remaining_readers_children_jobs_TMP"] = []
        result["current_next_job_lock_fair_reservation"] = "NONE"
        name = (
            "source-STOP.json"
            if result["status"] == "STOPPED_SOURCE_RELATED_REVIEW_REQUIRED"
            else "source-refusal.json"
        )
        print(
            json.dumps(
                {"status": result["status"], "STOP": result["STOP"], "receipt": save(name, result)}
            )
        )


if __name__ == "__main__":
    main()
