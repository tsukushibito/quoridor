"""One finite source/delta/format binding, without executing Rust definitions."""

import ast
import datetime
import difflib
import fcntl
import hashlib
import json
import os
import resource
import re
import stat
import subprocess
import time
from pathlib import Path

W = Path("/workspaces/quoridor/.worktree/tt-hash-reuse351")
R = W / ".artifacts/tt-hash-reuse351/source-control"
BASE = "2cf15b584f18519e1139eb0ecec5cdc0fe333eda"
ALPHA = "crates/quoridor-ai/src/alphabeta.rs"
TESTS = "crates/quoridor-ai/src/tt_hash_reuse351_tests.rs"
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def row(path):
    b = path.read_bytes()
    return {
        "path": str(path),
        "SHA256": hashlib.sha256(b).hexdigest(),
        "bytes": len(b),
        "mode": stat.S_IMODE(path.stat().st_mode),
    }


def identity(pid):
    s = Path(f"/proc/{pid}/stat").read_text()
    return {
        "pid": pid,
        "start_ticks": s[s.rfind(")") + 2 :].split()[19],
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    }


def save(name, data):
    (R / name).write_text(json.dumps(data, indent=2) + "\n")


def declaration(text, name):
    prefix = ("pub " if name == "SearchStats" else "") + "struct " + name
    match = re.search(re.escape(prefix) + r"(?=[\s<{])", text)
    assert match is not None, name
    start = match.start()
    a = text.index("{", start)
    return text[start : text.index("\n}", a) + 2]


def main():
    resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
    os.sched_setaffinity(0, {3})
    begin = time.perf_counter()
    receipt = {
        "issue": "quoridor-4lc.351",
        "START": now(),
        "identity": identity(os.getpid()),
        "commands": [],
        "remaining": [],
        "errors": [],
        "scope": "source-only finite binding/static-delta/formatter; Rust tests0",
    }
    # Reuse the exact prior actual quiet predicate, not its analysis main/body.
    original = Path(
        "/workspaces/quoridor/.worktree/search-optimization/.artifacts/depth6-tail-analysis-v1/run.py"
    )
    tree = ast.parse(original.read_text())
    wanted = {"now", "identity", "finished_controller", "quiet"}
    nodes = [
        n
        for n in tree.body
        if isinstance(n, (ast.Import, ast.ImportFrom))
        or isinstance(n, ast.FunctionDef)
        and n.name in wanted
    ]
    ns = {
        "__name__": "source_quiet351",
        "CONTROLLER": Path("/workspaces/quoridor/scripts/dev/research-job.py"),
        "CONTROLLER_SHA": "e119cc8294a888c245fa6f1f9b1481343ca1d04f239dde825d03f0252918452f",
    }
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(original), "exec"), ns)
    lease = None
    try:
        receipt["preentry"] = ns["quiet"]()
        lease = LOCK.open("a")
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        receipt["lease_START"] = now()
        receipt["after_lock_quiet"] = ns["quiet"]()
        assignment = Path(
            "/workspaces/quoridor/research-data/ai-sigma/search-optimization/tt-hash-reuse351/source-assignment-v1.json"
        )
        resources = assignment.with_name("resources-v1.json")
        assert (
            row(assignment)["SHA256"]
            == "43dc47260c1ec826ca2fbea32a60b87d488ebc4c16884ceed2a895e57b0a796e"
        )
        assert (
            row(resources)["SHA256"]
            == "3fad66b9ed633ff84b16cec73a5117b1fd4840a24f0115b8d32f45bc7dcc2160"
        )
        declared = json.loads(assignment.read_text())["source_bindings"]
        before = [row(Path(p["path"])) for p in declared]
        for old, actual in zip(declared, before, strict=True):
            if old["relative"] != ALPHA:
                assert all(old[k] == actual[k] for k in ("SHA256", "bytes", "mode")), old["path"]
        assert len(declared) == 139
        source = (W / ALPHA).read_text()
        tests = (W / TESTS).read_text()
        rustfmt = "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt"
        commands = [
            [
                rustfmt,
                "--edition",
                "2024",
                "--config",
                "skip_children=true",
                "--check",
                str(W / ALPHA),
                str(W / TESTS),
            ],
            ["git", "-C", str(W), "cat-file", "blob", f"{BASE}:{ALPHA}"],
        ]
        outputs = []
        for argv in commands:
            child = None
            record = {"command": argv, "START": now(), "directwait": False}
            start = time.perf_counter()
            try:
                child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                record["identity"] = identity(child.pid)
                out, err = child.communicate(timeout=20)
                record["exit_code"] = child.returncode
                assert len(out) + len(err) < 200000
                assert child.returncode == 0, err.decode(errors="replace")
                outputs.append(out)
            finally:
                if child is not None:
                    if child.poll() is None:
                        child.kill()
                        child.wait(timeout=2)
                    record["directwait"] = child.returncode is not None
                    for stream in (child.stdout, child.stderr):
                        if stream:
                            stream.close()
                    record["handles_closed"] = all(
                        s is None or s.closed for s in (child.stdout, child.stderr)
                    )
                    record["exact_identity_absent"] = not Path(f"/proc/{child.pid}").exists()
                record["STOP"] = now()
                record["whole_s_nested"] = time.perf_counter() - start
                receipt["commands"].append(record)
        old = outputs[1].decode()
        assert (
            hashlib.sha256(outputs[1]).hexdigest()
            == "bc7c25dd06043499977df38a78f63d6ce27cfbde1120608257dddbaa57140faa"
        )
        structures = ["Key", "Entry", "Table", "SearchStats", "Search", "SearchSession"]
        layout = {name: declaration(old, name) == declaration(source, name) for name in structures}
        assert all(layout.values()), layout
        root_same = (
            old[old.index("    fn root_depth(") : old.index("    fn pv(")]
            == source[source.index("    fn root_depth(") : source.index("    fn pv(")]
        )
        assert root_same
        assert (
            old[old.index("    fn get(") : old.index("    fn probe(")]
            == source[source.index("    fn get(") : source.index("    fn probe(")]
        )
        old_admission = old[
            old.index("        if self.slots[i]") : old.index("\n}\nenum Interrupted")
        ]
        new_admission = source[
            source.index("        if self.slots[i]") : source.index("\n}\nenum Interrupted")
        ]
        assert old_admission == new_admission
        old_tail = old[old.index("enum Interrupted") :]
        # Only recursive negamax and new test module wiring differ in this tail.
        old_recursive_start = old_tail.index("    fn negamax(")
        old_recursive_end = old_tail.index("    fn root_depth(")
        new_tail = source[source.index("enum Interrupted") :]
        new_recursive_start = new_tail.index("    fn negamax(")
        new_recursive_end = new_tail.index("    fn root_depth(")
        assert old_tail[:old_recursive_start] == new_tail[:new_recursive_start]
        old_rest = old_tail[old_recursive_end:]
        new_rest = new_tail[new_recursive_end:]
        wiring = (
            '\n#[cfg(test)]\n#[path = "tt_hash_reuse351_tests.rs"]\nmod tt_hash_reuse351_tests;\n'
        )
        assert new_rest == old_rest + wiring
        assert tests.count("#[test]") == 12
        patch = "".join(
            difflib.unified_diff(
                old.splitlines(True),
                source.splitlines(True),
                fromfile="a/" + ALPHA,
                tofile="b/" + ALPHA,
            )
        )
        patch += "".join(
            difflib.unified_diff(
                [], tests.splitlines(True), fromfile="/dev/null", tofile="b/" + TESTS
            )
        )
        (R / "source.patch").write_text(patch)
        save(
            "source-delta-proof.json",
            {
                "baseline_git_blob": BASE + ":" + ALPHA,
                "baseline_SHA256": hashlib.sha256(outputs[1]).hexdigest(),
                "stored_declarations_exact": layout,
                "root_depth_exact": root_same,
                "get_retention_clear_generation_discard_exact": True,
                "admission_replacement_payload_body_exact": True,
                "all_tail_except_negamax_and_private_module_exact": True,
                "new_test_definitions": 12,
                "execution": "NOT_BUILT_NOT_TYPECHECKED_NOT_RUN",
                "proof_kind": "exact source ranges/declarations; not AST/Rust layout execution",
                "hash_counter": "actual instrumented full-Key computations; paired insert0; PV excluded",
                "read_ordering": "Initial scoped source-body reads occurred before this complete source sweep; initial alpha hash checked before edit. Not retroactive all139 hash-before-first-read.",
                "retained_admin_refusal": "Metadata config port used argv key; KeyError before body/config execution; actual field command read instead. No source/runtime/test effect inferred.",
            },
        )
        after = [row(Path(p["path"])) for p in declared]
        assert before == after
        selected = [
            W / x
            for x in [
                ALPHA,
                TESTS,
                "crates/quoridor-core/src/research.rs",
                "crates/quoridor-core/src/position.rs",
                "crates/quoridor-ai/src/lib.rs",
                "crates/quoridor-ai/Cargo.toml",
                "crates/quoridor-core/Cargo.toml",
                "Cargo.toml",
                "Cargo.lock",
            ]
        ]
        selected += [assignment, resources]
        selected += [
            R / x
            for x in [
                "contract.md",
                "cost-comparison-contract.md",
                "software-plan.json",
                "source-delta-proof.json",
                "source.patch",
            ]
        ]
        selected_rows = [row(p) for p in selected]
        assert sum(p["bytes"] for p in selected_rows) < 2097152
        binding = {
            "schema": "quoridor.tt-hash-reuse351.source.v1",
            "issue": "quoridor-4lc.351",
            "rows": selected_rows,
            "base": BASE,
            "prepared": True,
            "admission": False,
            "source_139_baseline_records_before_after_exact_except_allowed_alpha": True,
            "new_source_only_test_module": TESTS,
            "review_question": "Private same-owned-key token/counter/layout/admission factoring and private full-history Zobrist seed/incremental/owner/undo/refusal/collision boundaries only",
            "test_execution": "NONE",
            "cost_execution": "NONE",
            "default_adoption": False,
        }
        save("source-binding.json", binding)
        receipt["bindings_before_after"] = "PASS"
        receipt["source_writer_reader_STOP"] = now()
        receipt["binding"] = row(R / "source-binding.json")
        receipt["sampled_self_RSS_B"] = next(
            int(s.split()[1]) * 1024
            for s in Path("/proc/self/status").read_text().splitlines()
            if s.startswith("VmRSS:")
        )
        receipt["continuous_family_peak"] = "UNKNOWN"
        receipt["new_namespace_allocated_B"] = sum(
            p.stat().st_blocks * 512 for p in (W / ".artifacts/tt-hash-reuse351").rglob("*")
        )
        receipt["initial_increment_upper_B"] = 2097152
        assert receipt["new_namespace_allocated_B"] < receipt["initial_increment_upper_B"]
        receipt["source_forward_forecast_B"] = 6647808 + 2097152
        receipt["supported_source_B"] = 33554432
        receipt["supported_whole_B"] = 654311424
        receipt["all_phases_forward_B"] = 40252600320
        receipt["scope_outcome"] = "SOURCE_STOPPED_FOR_RELATED_REVIEW; software/numerical0"
    except BaseException as error:
        receipt["errors"].append(repr(error))
        receipt["scope_outcome"] = "REFUSED_OR_FAILED"
    finally:
        if lease is not None:
            lease.close()
        receipt["lease_released"] = True
        receipt["artifact_STOP"] = now()
        receipt["whole_s"] = time.perf_counter() - begin
        receipt["current_next_job_Cargo_model_fair"] = "NONE"
        receipt["TMP_remaining"] = []
        save("source-STOP.json", receipt)
    print(
        json.dumps(
            {
                "outcome": receipt["scope_outcome"],
                "errors": receipt["errors"],
                "STOP": receipt["artifact_STOP"],
            }
        )
    )
    if receipt["errors"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
