"""Preserve v1, rebind only formatted documentation; no Rust execution."""

import fcntl
import importlib.util
import json
from pathlib import Path
import os
import resource


HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("source_freezer", HERE / "freeze.py")
freezer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(freezer)
os.sched_setaffinity(0, {3})
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
spec = importlib.util.spec_from_file_location(
    "metadata_guard", freezer.ROOT / "controls/software-entry-recovery-v2/worker.py"
)
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)
quiet = guard.quiet()
with guard.LOCK.open("a+") as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    binding = json.loads((HERE / "source-binding.json").read_text())
    assert all(freezer.row(row["path"]) == row for row in binding["source_records"])
    for row in binding["directed_review_inputs"]:
        if row["path"] == str(HERE / "contract.md"):
            row.update(freezer.row(row["path"]))
        else:
            assert freezer.row(row["path"]) == row
    binding["directed_review_inputs"].extend(
        freezer.row(path)
        for path in [HERE / "contract-before-format.md.gz", HERE / "freeze_format.py"]
    )
    binding["previous_binding_preserved"] = freezer.row(HERE / "source-binding.json")
    binding["format_only_rebind"] = "contract Markdown; scoped no-ignore Prettier PASS"
    binding["binding_write_UTC"] = freezer.stamp()
    target = freezer.save("source-binding-v2.json", binding)
    assert all(freezer.row(row["path"]) == row for row in binding["directed_review_inputs"])
    stop = freezer.stamp()
receipt = freezer.save(
    "source-STOP-v2.json",
    {
        "issue": "quoridor-4lc.351",
        "status": "STOPPED_SOURCE_RELATED_REVIEW_REQUIRED",
        "source_binding": target,
        "source_reader_writer_STOP": stop,
        "previous_STOP_preserved": freezer.row(HERE / "source-STOP.json"),
        "quiet": quiet,
        "lease_released": True,
        "selected_before_after": True,
        "source_records_count": 141,
        "Rust_body_and_argv_env_changed_in_this_rebind": False,
        "format_check_refusal_retained": "contract ignored by default; explicit no-ignore check caught it before handoff",
        "remaining_readers_children_jobs_TMP": [],
        "current_next_job_lock_fair_reservation": "NONE",
        "new_Cargo_native_model_Search_game_calls": 0,
        "numeric_entry_now": False,
    },
)
print(json.dumps({"target": target, "STOP": stop, "receipt": receipt}))
