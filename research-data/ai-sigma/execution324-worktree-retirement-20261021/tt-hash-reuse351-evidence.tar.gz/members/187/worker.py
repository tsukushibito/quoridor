"""Ordinary two-comment compile repair; reuse stopped finite guardian unchanged."""

import fcntl
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
W = Path("/workspaces/quoridor/.worktree/tt-hash-reuse351")
ROOT = W / ".artifacts/tt-hash-reuse351"
OLD = PARENT / "actual-admission.json.gz"
BINDING = HERE / "source-comment-STOP.json"


def load_stopped_guardian():
    # Finite control-source import under the same nonblocking lock. Actual
    # phase reacquires and repeats fresh whole source/physical/quiet predicates.
    lock = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
    with lock.open("a+b") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert (
            hashlib.sha256(OLD.read_bytes()).hexdigest()
            == "6856a0179c1b2c7288dfa1cd634ed27801308c65e3d7892cec9d40ade18e735c"
        )
        previous = json.loads(gzip.decompress(OLD.read_bytes()))
        base_path = PARENT / "worker.py"
        expected_base = next(r for r in previous["control_records"] if r["path"] == str(base_path))
        assert hashlib.sha256(base_path.read_bytes()).hexdigest() == expected_base["SHA256"]
        spec = importlib.util.spec_from_file_location("stopped_finite_guardian", base_path)
        base = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(base)
        return base, previous


base, previous = load_stopped_guardian()
assert base.sha(BINDING) == "fb19f54804982ef60a799ffd583decaf907538fb3f817a5a3f4c8ddc230bfc73"
base.HERE = HERE
base.TMP = ROOT / "TMP/caller-software-recovery-v2"
base.QUAL = ROOT / "qualification/caller-software-recovery-v2"
base.RAW = ROOT / "raw/caller-software-recovery-v2"
base.PLAN = HERE / "software-plan.json"
base.REPAIR = BINDING
base.FLOORS = {
    "source": 3674112,
    "target": 517844992,
    "private": 8323072,
    "TMP": 1134592,
    "qualification": 81920,
    "raw": 8192,
    "failures": 0,
    "review": 0,
    "RootGitcleanup": 0,
}


def effective_source():
    assert base.sha(OLD) == "6856a0179c1b2c7288dfa1cd634ed27801308c65e3d7892cec9d40ade18e735c"
    assert base.sha(BINDING) == "fb19f54804982ef60a799ffd583decaf907538fb3f817a5a3f4c8ddc230bfc73"
    rows = json.loads(gzip.decompress(OLD.read_bytes()))["source_records"]
    by_path = {r["path"]: r for r in rows}
    assert len(rows) == len(by_path) == 141
    replacement = base.load(BINDING)["exact_replaced_source_rows"]
    assert len(replacement) == 1
    caller = str(W / "crates/quoridor-ai/src/tt_hash_processing351.rs")
    assert replacement[0]["path"] == caller
    assert (
        replacement[0]["SHA256"]
        == "9156a02443873c6f76b1f93cc030759aa1fbe8f0bd452e5c5c56bf0c8696d4ed"
    )
    assert (
        by_path[caller]["SHA256"]
        == "7db1cffe8e801b9e8fbefdce2cc9da21dc4bc3de65517c1f53a8a1c98e2e9eb3"
    )
    by_path[caller] = replacement[0]
    return sorted(by_path.values(), key=lambda r: r["path"])


original_paths = base.control_paths


def control_paths(admission):
    return list(
        dict.fromkeys(
            original_paths(admission)
            + [
                Path(__file__).resolve(),
                OLD,
                BINDING,
                PARENT / "failed-software-STOP.json",
                HERE / "caller-before7db.rs.gz",
                HERE / "comment-only.patch",
            ]
        )
    )


original_charges = base.charges


def charges(prepared=False):
    values, unknown = original_charges(prepared)
    cumulative, transient = base.allocated(PARENT)
    assert cumulative <= 1048576, "combined old/new contained software-control gap"
    unknown += transient
    snapshots = sum(p.stat().st_blocks * 512 for p in PARENT.rglob("*admission*.gz"))
    assert snapshots + 8192 <= 524288, "combined exact-snapshot subclass gap"
    guardians = [PARENT / "worker.py", PARENT / "fixture-ports.py", Path(__file__).resolve()]
    assert sum(p.stat().st_blocks * 512 for p in guardians) + 8192 <= 65536, "guardian subclass gap"
    return values, unknown


base.effective_source = effective_source
base.control_paths = control_paths
base.charges = charges
if __name__ == "__main__":
    if sys.argv[1:] == ["prepare"]:
        base.prepare()
    elif len(sys.argv) == 4 and sys.argv[1] == "run":
        base.run(sys.argv[2], sys.argv[3])
    else:
        raise SystemExit("prepare or run admission SHA")
