"""New intentional-link census boundary; fake filesystem ports only."""

import ast
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
from types import SimpleNamespace
import stat
import time
from unittest.mock import patch


HERE = Path(__file__).resolve().parent
WORKER = HERE / "worker.py"
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
TMP = HERE.parents[1] / "TMP/cost-caller-v1"
start = time.monotonic()
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
lease = LOCK.open("a+b")
fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
try:
    spec = importlib.util.spec_from_file_location("source_guard", WORKER)
    worker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(worker)
    guard = worker.guard_module()
    quiet = worker.quiet(guard)
    physical = guard.physical()
    os.sched_setaffinity(0, {3})
    body = WORKER.read_bytes()
    tree = ast.parse(body)
    nodes = [
        n
        for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name in ("owned_fixture_link", "allocated")
    ]
    assert len(nodes) == 2
    namespace = {"stat": stat, "Path": Path, "TMP": TMP, "json": json}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(WORKER), "exec"), namespace)
    owned = TMP / "tt351-output-guard-123/dangling"
    target = owned.parent / "absent-owned-target"
    cases = []

    def run(
        name,
        path=owned,
        prepared=True,
        target_state="missing",
        parent_mode=stat.S_IFDIR,
        link_target=target,
        census=False,
        expected=True,
    ):
        def lstat(p):
            if p == target:
                if target_state == "missing":
                    raise FileNotFoundError()
                if target_state == "permission":
                    raise PermissionError("target metadata unknown")
                return SimpleNamespace(st_mode=stat.S_IFREG, st_blocks=0)
            if p == path.parent:
                return SimpleNamespace(st_mode=parent_mode, st_blocks=8)
            if p == path:
                return SimpleNamespace(st_mode=stat.S_IFLNK, st_blocks=8)
            raise AssertionError("unplanned fake metadata port")

        with (
            patch.object(Path, "lstat", lstat),
            patch.object(Path, "readlink", lambda p: link_target),
        ):
            try:
                result = (
                    namespace["allocated"](path, prepared=prepared)[0] == 4096
                    if census
                    else namespace["owned_fixture_link"](path, prepared)
                )
                assert result is expected, (name, result, expected)
            except (AssertionError, PermissionError) as error:
                assert expected == type(error).__name__, (name, type(error).__name__, expected)
        cases.append(name)

    run("exact owned dangling link")
    run("unprepared refuses", prepared=False, expected=False)
    run("foreign namespace refuses", path=HERE / "tt351-output-guard-123/dangling", expected=False)
    run("wrong target refuses", link_target=Path("/foreign/absent"), expected=False)
    run("present target refuses", target_state="present", expected=False)
    run("target metadata error retained", target_state="permission", expected="PermissionError")
    run("parent must be directory", parent_mode=stat.S_IFREG, expected=False)
    run("lstat charges link inode", census=True)
    run(
        "census refuses foreign link",
        path=HERE / "tt351-output-guard-123/dangling",
        census=True,
        expected="AssertionError",
    )
    result = {
        "cases": cases,
        "PASS": len(cases),
        "source_SHA256": hashlib.sha256(body).hexdigest(),
        "fake_ports_only": True,
        "real_Popen": 0,
        "compiler_native_model_Search": 0,
        "quiet": quiet,
        "physical": physical,
        "whole_s": time.monotonic() - start,
        "VmHWM_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "remaining": [],
    }
finally:
    lease.close()
result["lease_released"] = True
(HERE / "fixture-ports-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
