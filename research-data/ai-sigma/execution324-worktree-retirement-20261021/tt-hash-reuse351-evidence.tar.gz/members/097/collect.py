"""Collect the completed finite software job without executing its commands."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import time


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent


def stamp():
    return datetime.now(timezone.utc).isoformat()


def load(path):
    return json.loads(Path(path).read_text())


def row(path):
    path = Path(path)
    info = path.stat()
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            digest.update(block)
    return {
        "path": str(path),
        "SHA256": digest.hexdigest(),
        "bytes": info.st_size,
        "mode": stat.S_IMODE(info.st_mode),
    }


def main():
    os.sched_setaffinity(0, {3})
    resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
    began = time.monotonic()
    receipt = {"issue": "quoridor-4lc.351", "collection_START": stamp()}
    lease = None
    try:
        spec = importlib.util.spec_from_file_location("collection_guard", HERE / "worker.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        receipt["named_quiet"] = guard.quiet()
        lease = guard.LOCK.open("a+")
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        receipt["physical"] = {
            "UTC": stamp(),
            "collector_affinity": sorted(os.sched_getaffinity(0)),
            "collector_AS_upper_B": 536870912,
            "MemAvailable_B": next(
                int(line.split()[1]) * 1024
                for line in Path("/proc/meminfo").read_text().splitlines()
                if line.startswith("MemAvailable:")
            ),
            "scope": "CPU3 metadata collector; software CPU2/4 proof remains in admission",
        }
        assert receipt["physical"]["MemAvailable_B"] >= 536870912 + 4294967296
        result = load(HERE / "runtime-v1/result.json")
        state = load(HERE / "runtime-v1/state.json")
        worker = load(HERE / "worker-result.json")
        admission = load(HERE / "actual-admission.json")
        assert result["job_id"] == state["job_id"] == "64900fcf-6e72-45a0-91c5-7e4d08fd16de"
        assert result["outcome"] == "succeeded" and result["exit_code"] == 0
        assert result["direct_child_reaped"] and result["cleanup_complete"]
        assert result["remaining"] == result["cleanup_errors"] == []
        assert worker["status"] == "PASS" and len(worker["commands"]) == 7
        assert worker["source_before_after"] and worker["component_cleanup_complete"]
        assert worker["primary_error"] is None and worker["finalization_errors"] == []
        records = admission["source_records"] + admission["control_records"]
        assert len({item["path"] for item in admission["source_records"]}) == 140
        for expected in records + admission["retained_before_records"]:
            assert row(expected["path"]) == {
                key: expected[key] for key in ("path", "SHA256", "bytes", "mode")
            }, expected["path"]
        receipt["source_control_records"] = records
        receipt["retained_failed_files_unchanged"] = admission["retained_before_records"]
        identities = [state["child"]]
        persisted = []
        for index, command in enumerate(worker["commands"]):
            returned = command["returned_record"]
            assert returned["command"] == admission["commands"][index]
            assert returned["exit_code"] == 0 and returned["remaining"] == []
            for field in (
                "direct_child_reaped",
                "cleanup_complete",
                "process_cleanup_complete",
                "handle_closes_complete",
            ):
                assert returned[field], field
            assert returned["finalization_errors"] == []
            identities.append(returned["child"])
            log = ROOT / "qualification" / HERE.name / f"{index + 1:02d}.log"
            process = log.with_name(f"{index + 1:02d}.process.json")
            saved = load(process)
            persisted.append({"file": row(process), "record": saved})
            assert saved["child"] == returned["child"]
        absent = [
            {"identity": member, "same_identity_present": guard.same_identity(member)}
            for member in identities
        ]
        assert not any(item["same_identity_present"] for item in absent)
        test_log = (ROOT / "qualification" / HERE.name / "01.log").read_text()
        assert "13 passed; 0 failed; 0 ignored; 0 measured; 39 filtered out" in test_log
        config = load(ROOT / "qualification" / HERE.name / "07.log")
        assert config["valid"] and config["models_loaded"] == 0 and config["main_volume_n"] is None
        alpha = next(v for v in admission["source_records"] if v["path"].endswith("/alphabeta.rs"))
        assert config["compiled_sources"]["ai/alphabeta.rs"] == alpha["SHA256"]
        assert row(worker["private"]["path"]) == worker["private"]
        assert row(ROOT / "target/release/quoridor-runner")["SHA256"] == worker["private"]["SHA256"]
        receipt.update(
            {
                "status": "QUALIFIED_SOFTWARE_ONLY",
                "controller_START": state["started_at"],
                "worker_START": worker["actualSTART"],
                "worker_STOP": worker["workerSTOP"],
                "source_cleanup_STOP": worker["source_cleanup_STOP"],
                "controller_STOP": result["finished_at"],
                "controller_whole_s": result["wall_seconds"],
                "known_software_controller_fees_s": result["wall_seconds"] + 1.475817985017784,
                "nested_spans_added": False,
                "controller": result,
                "worker": worker,
                "exact_command_and_guardian_absence": absent,
                "completed_metadata_notifier": {
                    "identity": state["supervisor"],
                    "same_identity_present": guard.same_identity(state["supervisor"]),
                    "classification": "finished metadata; not computation",
                },
                "persisted_process_records_separate": persisted,
                "configuration_result": config,
                "owned_TMP_absent": not (ROOT / "TMP").exists(),
                "private_current_target_SHA_match": True,
                "supported_whole_B": 654311424,
                "resources_SHA256": "3fad66b9ed633ff84b16cec73a5117b1fd4840a24f0115b8d32f45bc7dcc2160",
                "retained_component_floors_B": {
                    key: max(
                        worker["sampled"].get(key, 0),
                        worker["final_charges"][0].get(key, 0),
                        admission["held_component_floors"].get(key, 0),
                    )
                    for key in admission["components_B"]
                },
                "continuous_family_storage_peak": "UNKNOWN",
                "live_fault_certificate": False,
                "new_game_model_cost_measurements": 0,
                "numerical_cost_comparison": "NOT_RUN_NOT_ADMITTED",
                "production_Zobrist": "NOT_ADOPTED",
                "current_next_Cargo_model_game_fair_reservation": "NONE",
                "old_failure": row(ROOT / "controls/software-entry-v1/failed-STOP.json"),
                "raw_records": [
                    row(HERE / "runtime-v1" / name)
                    for name in ("result.json", "output.log", "config.json", "state.json")
                ]
                + [row(HERE / "worker-result.json"), row(HERE / "actual-admission.json")]
                + [
                    row(path) for path in sorted((ROOT / "qualification" / HERE.name).glob("*.log"))
                ],
            }
        )
    except BaseException as error:
        receipt["collection_error"] = {"type": type(error).__name__, "message": str(error)}
        receipt["status"] = "COLLECTION_REFUSED_PARTIAL"
        raise
    finally:
        if lease is not None:
            lease.close()
        receipt["lease_released"] = True
        receipt["collection_STOP"] = stamp()
        receipt["collection_whole_s"] = time.monotonic() - began
        receipt["collection_VmHWM_KiB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        receipt["owned_children_readers_TMP_remaining"] = []
        target = HERE / (
            "qualified-STOP.json"
            if receipt.get("status") == "QUALIFIED_SOFTWARE_ONLY"
            else "collection-refusal.json"
        )
        assert not target.exists(), "do not overwrite frozen collection"
        encoded = (json.dumps(receipt, indent=2) + "\n").encode()
        assert len(encoded) <= 131072, "collection inclusive control upper"
        target.write_bytes(encoded)
        print(
            json.dumps(
                {
                    "status": receipt["status"],
                    "STOP": receipt["collection_STOP"],
                    "receipt": row(target),
                }
            )
        )


if __name__ == "__main__":
    main()
