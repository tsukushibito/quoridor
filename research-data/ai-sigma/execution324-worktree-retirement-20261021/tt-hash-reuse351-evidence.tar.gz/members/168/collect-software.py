"""Bounded saved software/source/private collection; no runtime replay."""

from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import time


P = Path(__file__).resolve().parent
ROOT = P.parents[2]
start = time.monotonic()
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
lock = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
lease = lock.open("a+b")
fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def row(path):
    s = path.stat()
    return {
        "path": str(path),
        "SHA256": sha(path),
        "bytes": s.st_size,
        "mode": stat.S_IMODE(s.st_mode),
    }


def load(path):
    return json.loads(path.read_text())


def identity_observation(identity):
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    try:
        text = Path(f"/proc/{identity['pid']}/stat").read_text()
        ticks = text[text.rfind(")") + 2 :].split()[19]
        present = boot == identity["boot_id"] and ticks == identity["start_ticks"]
    except FileNotFoundError:
        present = False
    return {"identity": identity, "same_identity_present": present}


try:
    admission = P / "actual-admission.json.gz"
    assert sha(admission) == "d1510bc323b7483ecaca389cfed17e6213354b67b2e89328113df5976c4a1559"
    a = json.loads(gzip.decompress(admission.read_bytes()))
    guard_path = P.parent / "worker.py"
    expected = next(v for v in a["control_records"] if v["path"] == str(guard_path))
    assert row(guard_path) == expected
    spec = importlib.util.spec_from_file_location("stopped_collection_guard", guard_path)
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    g = guard.guard_module()
    quiet = guard.quiet(g)
    physical = g.physical()
    os.sched_setaffinity(0, {3})
    checked = a["source_records"] + a["compiler_records"] + a["control_records"]
    for expected in checked:
        assert row(Path(expected["path"])) == expected, expected["path"]
    result = load(P / "runtime-v1/result.json")
    state = load(P / "runtime-v1/state.json")
    worker = load(P / "worker-result.json")
    assert result["job_id"] == state["job_id"] == "5e69c587-2ba0-4251-a693-b661249f5ad2"
    assert result["exit_code"] == 0 and result["direct_child_reaped"] and result["cleanup_complete"]
    assert worker["status"] == "PASS_SOFTWARE_FREEZE_ONLY"
    assert (
        worker["source_before_after"]
        and worker["remaining"] == []
        and worker["finalization_errors"] == []
    )
    assert len(worker["commands"]) == 4
    assert worker["commands"][0]["returned_record"]["command"] == a["commands"][0]
    persistent = []
    identities = []
    for index, item in enumerate(worker["commands"], 1):
        returned = item["returned_record"]
        assert returned["exit_code"] == 0 and returned["direct_child_reaped"]
        assert (
            returned["handle_closes_complete"]
            and returned["cleanup_complete"]
            and returned["remaining"] == []
        )
        assert returned["signal_mask_restoration"] == "completed"
        assert returned["final_record_persist"] == "completed"
        saved = load(ROOT / f"qualification/caller-software-recovery-v2/{index:02}.process.json")
        assert saved["command"] == returned["command"] and saved["child"] == returned["child"]
        persistent.append(
            {
                "index": index,
                "signal_mask_restoration": saved["signal_mask_restoration"],
                "final_record_persist": saved["final_record_persist"],
            }
        )
        identities.append(identity_observation(returned["child"]))
    identities.append(identity_observation(state["child"]))
    assert all(r["same_identity_present"] is False for r in identities)
    private = worker["compiled_private"]["private"]
    assert row(Path(private["path"])) == private
    assert (
        row(Path(worker["compiled_private"]["source_artifact"]["path"]))
        == worker["compiled_private"]["source_artifact"]
    )
    workload = worker["qualified_workload"]
    assert row(Path(workload["path"])) == workload
    packet = load(Path(workload["path"]))
    assert [r["prefix"] for r in packet["root_catalog"]] == [[], [13, 75], [13, 75, 14, 76], [81]]
    assert len(packet["observed_context_catalog"]) == 24
    assert (
        packet["cycles"] == 64
        and packet["observations_per_method"] == 1536
        and packet["total_method_observations"] == 6144
    )
    refs = [
        row(P / n)
        for n in (
            "runtime-v1/state.json",
            "runtime-v1/result.json",
            "runtime-v1/config.json",
            "runtime-v1/output.log",
            "worker-result.json",
            "actual-admission.json.gz",
            "software-plan.json",
            "source-comment-STOP.json",
            "control-source-STOP.json",
        )
    ]
    refs += [
        row(ROOT / f"qualification/caller-software-recovery-v2/{i:02}{suffix}")
        for i in range(1, 5)
        for suffix in (".log", ".process.json")
    ]
    source_reader_stop = datetime.now(timezone.utc).isoformat()
    receipt = {
        "issue": "quoridor-4lc.351",
        "job_id": result["job_id"],
        "status": "QUALIFIED_SOFTWARE_AND_FREEZE_ONLY",
        "START": state["started_at"],
        "workerSTOP": worker["workerSTOP"],
        "source_cleanup_STOP": worker["source_cleanup_STOP"],
        "controllerSTOP": result["finished_at"],
        "whole_controller_s": result["wall_seconds"],
        "all_four_commands": worker["commands"],
        "exact_identities_fresh_absent": identities,
        "metadata_separate": identity_observation(state["supervisor"]),
        "remaining": [],
        "source_reader_STOP": source_reader_stop,
        "source_compiler_control_rows_checked": len(checked),
        "source_rows_checked": len(a["source_records"]),
        "private": worker["compiled_private"],
        "workload": workload,
        "workload_conditions_verified": {
            "prefixes": [r["prefix"] for r in packet["root_catalog"]],
            "contexts": 24,
            "wall81_legal": True,
            "planned_cycles": 64,
            "planned_observations_per_method": 1536,
            "planned_total": 6144,
            "comparison_executed": False,
        },
        "sampled": worker["sampled"],
        "final_charges": worker["final_charges"],
        "held_target_floor_next_B": max(
            worker["sampled"]["target"], worker["final_charges"][0]["target"]
        ),
        "held_private_floor_next_B": worker["final_charges"][0]["private"],
        "continuous_peaks": "UNKNOWN",
        "persisted_process_fields_distinct": persistent,
        "returned_mask_finalrecord": "completed all4",
        "fault_certificate": False,
        "old_software_fees_s_held": 156.781390120,
        "new_failed_caller_fee_s_held": 2.2388276449637488,
        "new_success_fee_s": result["wall_seconds"],
        "known_controller_total_s": 156.781390120 + 2.2388276449637488 + result["wall_seconds"],
        "nested_spans_not_added": True,
        "numeric_entry": "NOT_RUN_NOT_ADMITTED",
        "old13_success_tests_not_replayed": True,
        "old_RAW_floors_caps_masks_UNKNOWN_held": True,
        "proofs": refs,
        "collection": {
            "quiet": quiet,
            "physical": physical,
            "AS_B": 536870912,
            "CPU": 3,
            "GPU": 0,
            "wall_s": time.monotonic() - start,
            "VmHWM_status": next(
                l
                for l in Path("/proc/self/status").read_text().splitlines()
                if l.startswith("VmHWM:")
            ),
            "continuous_family_peak": "UNKNOWN",
        },
    }
finally:
    lease.close()
receipt["reader_lease_released"] = True
receipt["reader_cleanup_STOP"] = datetime.now(timezone.utc).isoformat()
data = (json.dumps(receipt, indent=2) + "\n").encode()
assert len(data) <= 32768
(P / "qualified-software-STOP.json").write_bytes(data)
print(
    json.dumps(
        {
            "receipt_SHA256": hashlib.sha256(data).hexdigest(),
            "reader_STOP": receipt["reader_cleanup_STOP"],
            "whole_controller_s": result["wall_seconds"],
            "private": private,
            "workload": workload,
            "collection_wall_s": receipt["collection"]["wall_s"],
        }
    )
)
