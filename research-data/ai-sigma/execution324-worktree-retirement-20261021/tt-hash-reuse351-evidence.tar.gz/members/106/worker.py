"""One finite affected software entry; maintained child ownership, no science."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import time

W = Path("/workspaces/quoridor/.worktree/tt-hash-reuse351")
ROOT = W / ".artifacts/tt-hash-reuse351"
HERE = Path(__file__).resolve().parent
ASSIGNMENT = Path(
    "/workspaces/quoridor/research-data/ai-sigma/search-optimization/tt-hash-reuse351/source-assignment-v1.json"
)
RESOURCES = ASSIGNMENT.with_name("resources-v1.json")
BINDING = ROOT / "source-control-repair-v2/source-binding.json"
PLAN = ROOT / "source-control-repair-v2/software-plan-v2.json"
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
CONTROLLER = Path("/workspaces/quoridor/scripts/dev/research-job.py")
CONTROLLER_SHA = "e119cc8294a888c245fa6f1f9b1481343ca1d04f239dde825d03f0252918452f"
REVIEW = Path(
    "/workspaces/quoridor/.worktree/endgame-solver335/.artifacts/tt-hash-review351-v1/repair-v2"
)
TOOLCHAIN = Path("/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin")
COMPONENTS = {
    "source": 33554432,
    "target": 536870912,
    "private": 16777216,
    "TMP": 33554432,
    "qualification": 8388608,
    "raw": 8388608,
    "failures": 8388608,
    "review": 4194304,
    "RootGitcleanup": 4194304,
}


def stamp():
    return datetime.now(timezone.utc).isoformat()


def sha(p):
    h = hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda: f.read(1048576), b""):
            h.update(b)
    return h.hexdigest()


def row(p):
    p = Path(p)
    s = p.stat()
    return {"path": str(p), "SHA256": sha(p), "bytes": s.st_size, "mode": stat.S_IMODE(s.st_mode)}


def save(p, d):
    Path(p).write_text(json.dumps(d, indent=2) + "\n")


def identity(pid):
    s = Path(f"/proc/{pid}/stat").read_text()
    f = s[s.rfind(")") + 2 :].split()
    return {
        "pid": pid,
        "start_ticks": f[19],
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    }


def same_identity(member):
    try:
        return identity(member["pid"]) == member
    except (FileNotFoundError, ProcessLookupError):
        return False


def ancestors():
    seen, pid = set(), os.getpid()
    while pid and pid not in seen:
        seen.add(pid)
        try:
            s = Path(f"/proc/{pid}/stat").read_text()
            pid = int(s[s.rfind(")") + 2 :].split()[1])
        except FileNotFoundError:
            break
    return seen


def group_info(pid):
    try:
        text = Path(f"/proc/{pid}/stat").read_text()
        fields = text[text.rfind(")") + 2 :].split()
        return {
            "pid": pid,
            "start_ticks": fields[19],
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
            "group": int(fields[2]),
            "session": int(fields[3]),
        }
    except FileNotFoundError:
        return None


def same_owned_session(candidate, owned, lookup):
    if candidate is None:
        return False
    for member in owned:
        live = lookup(member["pid"])
        if live is None or any(live[k] != member[k] for k in ("pid", "start_ticks", "boot_id")):
            continue
        # An actual owned start_new_session root, not a basename or unanchored
        # group number. This closes the fork-between-member-refresh race.
        if (
            live["group"] == live["session"] == member["pid"]
            and candidate["group"] == candidate["session"] == member["pid"]
            and candidate["boot_id"] == live["boot_id"]
        ):
            return True
    return False


def quiet(owned=()):
    allowed = ancestors() | {m["pid"] for m in owned if same_identity(m)}
    found, metadata = [], []
    for p in Path("/proc").iterdir():
        if not p.name.isdecimal() or int(p.name) in allowed:
            continue
        try:
            argv = [os.fsdecode(a) for a in (p / "cmdline").read_bytes().split(b"\0") if a]
            if not argv:
                continue
            name = Path(argv[0]).name
            scripts = [Path(a).name for a in argv[1:4] if not a.startswith("-")]
            named = name in {
                "cargo",
                "rustc",
                "rustdoc",
                "clippy-driver",
                "cargo-clippy",
                "perf",
                "quoridor-runner",
                "quoridor-arena",
                "step_reference",
                "contact_distance337",
                "chromium",
                "chrome",
                "firefox",
            } or name.startswith(("quoridor_ai-", "quoridor_nnue-", "nnue_search-"))
            named |= any(
                a.endswith(".py")
                and any(
                    x in a
                    for x in (
                        "worker",
                        "numeric",
                        "pilot",
                        "train",
                        "science",
                        "analyze",
                        "analyzer",
                    )
                )
                for a in scripts
            )
            if "research-job.py" in scripts:
                named = True
                known_python = {
                    Path("/usr/bin/python3").resolve(),
                    Path(
                        "/home/vscode/.cache/inference/envs/quoridor-research-team/bin/python"
                    ).resolve(),
                }
                if (
                    len(argv) == 6
                    and Path(argv[0]).resolve() in known_python
                    and argv[1:5] == ["-B", str(CONTROLLER), "run", "--state-dir"]
                    and Path(argv[5]).is_absolute()
                    and sha(CONTROLLER) == CONTROLLER_SHA
                ):
                    d = Path(argv[5])
                    s = json.loads((d / "state.json").read_text())
                    r = json.loads((d / "result.json").read_text())
                    if (
                        s["phase"] == "finished"
                        and s["job_id"] == r["job_id"]
                        and s["supervisor"] == identity(int(p.name))
                        and r["direct_child_reaped"] is True
                        and r["cleanup_complete"] is True
                        and r["remaining"] == []
                    ):
                        metadata.append(s["supervisor"])
                        continue
            if name in ("node", "nodejs") and any(
                "playwright" in a or "browser" in a for a in argv
            ):
                named = True
            if named and same_owned_session(group_info(int(p.name)), owned, group_info):
                continue
            if named:
                found.append(
                    {"identity": identity(int(p.name)), "executable": name, "scripts": scripts}
                )
        except FileNotFoundError:
            continue
        except (PermissionError, KeyError, ValueError, OSError) as error:
            found.append({"pid": int(p.name), "unknown": repr(error)})
    if found:
        raise RuntimeError("actual named competitor/UNKNOWN: " + json.dumps(found))
    return {"UTC": stamp(), "named_competitors": [], "finished_metadata": metadata}


def physical():
    available = next(
        int(s.split()[1]) * 1024
        for s in Path("/proc/meminfo").read_text().splitlines()
        if s.startswith("MemAvailable:")
    )
    c = Path("/sys/fs/cgroup")
    limit = (c / "memory.max").read_text().strip()
    if limit != "max":
        available = min(available, max(0, int(limit) - int((c / "memory.current").read_text())))
    assert available >= 6442450944 + 4294967296, "family6GiB+host4GiB unsupported"
    assert {2, 4} <= os.sched_getaffinity(0), "CPU affinity unavailable"
    topology = {}
    for n in [2, 4]:
        p = Path(f"/sys/devices/system/cpu/cpu{n}/topology")
        topology[str(n)] = {
            k: (p / k).read_text().strip()
            for k in ["physical_package_id", "core_id", "thread_siblings_list"]
        }
    assert (topology["2"]["physical_package_id"], topology["2"]["core_id"]) != (
        topology["4"]["physical_package_id"],
        topology["4"]["core_id"],
    )
    assert (c / "cpu.max").exists(), "quota unknown"
    quota = (c / "cpu.max").read_text().split()
    assert quota[0] == "max" or int(quota[0]) >= int(quota[1]), "CPU quota below one compiler"
    return {
        "UTC": stamp(),
        "MemAvailable_B": available,
        "CPU": topology,
        "cpu.max": " ".join(quota),
        "kernel": os.uname().release,
        "FS_available_B": shutil.disk_usage(W).free,
    }


def effective_source():
    assert sha(ASSIGNMENT) == "43dc47260c1ec826ca2fbea32a60b87d488ebc4c16884ceed2a895e57b0a796e"
    assert sha(RESOURCES) == "3fad66b9ed633ff84b16cec73a5117b1fd4840a24f0115b8d32f45bc7dcc2160"
    assert sha(BINDING) == "968b6a881de304c8d1791a9688f4a2045ca6dffffa902e3965f4fdb60e93070b"
    assert (
        sha(REVIEW / "review.md")
        == "2446e8532e1f93be4f096e9d04974d9b409042095025374c99fe0a8715063974"
    )
    assert (
        sha(REVIEW / "control.json")
        == "078ce872e683a669ec81a937b5cfb3e16a80924cb9113afbd6eada81250250c3"
    )
    original = json.loads(ASSIGNMENT.read_text())["source_bindings"]
    by_path = {}
    for v in original:
        assert v["path"] not in by_path
        by_path[v["path"]] = {k: v[k] for k in ("path", "SHA256", "bytes", "mode")}
    assert len(by_path) == 139
    b = json.loads(BINDING.read_text())
    for v in [b["unchanged_production_alpha"], *b["changed_product_source_rows"]]:
        assert Path(v["path"]).is_relative_to(W / "crates/quoridor-ai/src")
        by_path[v["path"]] = {k: v[k] for k in ("path", "SHA256", "bytes", "mode")}
    assert len(by_path) == 140
    return sorted(by_path.values(), key=lambda x: x["path"])


def validate(g):
    assert g["source_records"] == effective_source(), "admitted exact source-map mismatch"
    for v in g["source_records"] + g["control_records"] + g["compiler_records"]:
        assert row(v["path"]) == v, "changed hash/size/mode: " + v["path"]
    assert not os.environ.get("RUSTFLAGS") and not os.environ.get("CARGO_ENCODED_RUSTFLAGS"), (
        "unbound rustflags"
    )
    for p in g["Cargo_configs_absent"]:
        assert not Path(p).exists(), "new unbound Cargo config: " + p
    assert json.loads(PLAN.read_text())["commands"] == g["commands"]
    assert json.loads(PLAN.read_text())["env"] == g["env"]
    assert g["components_B"] == COMPONENTS and sum(COMPONENTS.values()) == 654311424


def allocated(p, exclude=()):
    p = Path(p)
    if not p.exists():
        return 0
    failures = []
    for attempt in range(2):
        pending, total = [p], 0
        missing = []
        while pending:
            x = pending.pop()
            if x in exclude:
                continue
            try:
                s = x.lstat()
                assert not stat.S_ISLNK(s.st_mode), "owned namespace symlink: " + str(x)
                total += s.st_blocks * 512
                if stat.S_ISDIR(s.st_mode):
                    pending.extend(x.iterdir())
            except FileNotFoundError:
                missing.append(str(x))
        if not missing:
            return total, failures
        failures.append(
            {"missing_stat": missing[:16], "transient_peak": "UNKNOWN", "attempt": attempt}
        )
    raise RuntimeError("second unstable owned census: " + json.dumps(failures))


def charges():
    d = {}
    unknown = []
    excluded = [ROOT / k for k in COMPONENTS if k not in ("source", "RootGitcleanup")]
    v, u = allocated(W, excluded)
    unknown += u
    git = Path("/workspaces/quoridor/.git/worktrees/tt-hash-reuse351")
    x, u = allocated(git)
    unknown += u
    d["source"] = v + x
    for k in COMPONENTS:
        if k in ("source", "RootGitcleanup"):
            continue
        if (ROOT / k).exists():
            v, u = allocated(ROOT / k)
            unknown += u
            d[k] = v
        else:
            d[k] = 0
    d["RootGitcleanup"] = 0  # reserved4MiB; soleRoot charges it, no credit/reclassification
    for k, v in d.items():
        assert v <= COMPONENTS[k], f"{k} unsupported gap {v - COMPONENTS[k]}B"
    return d, unknown


def retained_records():
    records = []
    for name in ("target", "private", "TMP", "qualification"):
        parent = ROOT / name
        if not parent.exists():
            continue
        for p in sorted(parent.rglob("*")):
            if p.is_file():
                value = row(p)
                value["stat"] = [p.stat().st_dev, p.stat().st_ino, p.stat().st_mtime_ns]
                records.append(value)
    return records


def check_retained(g):
    assert retained_records() == g["retained_before_records"], (
        "retained namespace changed before entry"
    )


def prepare():
    result = {
        "issue": "quoridor-4lc.351",
        "START": stamp(),
        "identity": identity(os.getpid()),
        "errors": [],
        "entry_ready": False,
    }
    lease = None
    try:
        result["prequiet"] = quiet()
        result["physical"] = physical()
        lease = LOCK.open("a+b")
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        result["lease_START"] = stamp()
        result["quiet"] = quiet()
        result["physical_after_lock"] = physical()
        sources = effective_source()
        for v in sources:
            assert row(v["path"]) == v, v["path"]
        process_paths = [
            Path("/workspaces/quoridor/python/quoridor_training") / n
            for n in ["cycle_process.py", "snapshot.py", "__init__.py"]
        ]
        controls = [
            RESOURCES,
            ASSIGNMENT,
            BINDING,
            PLAN,
            REVIEW / "review.md",
            REVIEW / "control.json",
            CONTROLLER,
            Path(__file__).resolve(),
            *process_paths,
        ]
        cargo_configs = []
        for parent in [W, *W.parents]:
            for n in ["config", "config.toml"]:
                cargo_configs.append(parent / ".cargo" / n)
        cargo_configs += [Path("/usr/local/cargo") / n for n in ["config", "config.toml"]]
        controls += [p for p in cargo_configs if p.is_file()]
        absent_configs = sorted({str(p) for p in cargo_configs if not p.exists()})
        tools = [
            row(TOOLCHAIN / n)
            for n in ["cargo", "rustc", "rustdoc", "cargo-clippy", "clippy-driver", "rustfmt"]
        ]
        toolchain_root = TOOLCHAIN.parent
        tools += [row(p) for p in (toolchain_root / "lib").glob("librustc_driver-*.so")]
        tools += [
            row(p)
            for p in (toolchain_root / "lib/rustlib/x86_64-unknown-linux-gnu/lib").iterdir()
            if p.is_file()
        ]
        tools.append(row(Path("/usr/bin/c++")))
        pinned = {
            "cargo": "e951141cc55a6cd7b9876d187bd30a3720e6086b99413af95e3b8de1cdd72f14",
            "rustc": "f3834d26669b03f6855fa54bd2381443123e860167bc0c7a8dd137e5cf6e5e4f",
            "rustdoc": "a1321a60578a6b2e3e0ff428201b8618bbd9a9fbcd475c0d0f151bbf17cb0a9e",
        }
        for v in tools:
            n = Path(v["path"]).name
            if n in pinned:
                assert v["SHA256"] == pinned[n], "qualified stable1.99 executable changed"
        plan = json.loads(PLAN.read_text())
        cfg = plan["current_config"]
        assert row(cfg["path"]) == {k: cfg[k] for k in ("path", "SHA256", "bytes", "mode")}
        controls.append(Path(cfg["path"]))
        g = {
            "issue": "quoridor-4lc.351",
            "entry_ready": True,
            "source_records": sources,
            "retained_before_records": retained_records(),
            "held_component_floors": json.loads(
                (ROOT / "controls/software-entry-v1/worker-result.json").read_text()
            )["final_charges"][0],
            "control_records": [row(p) for p in controls],
            "compiler_records": tools,
            "Cargo_configs_absent": absent_configs,
            "effective_extra_env": {
                "CARGO_HOME": "/usr/local/cargo",
                "RUSTUP_HOME": "/usr/local/rustup",
            },
            "commands": plan["commands"],
            "env": plan["env"],
            "unset_env": plan["unset_env"],
            "components_B": COMPONENTS,
            "max_runtime_seconds": 600,
            "review_readerSTOP": "2026-10-09T08:42:51.299869+00:00",
            "target_forecast_B": 536870912,
            "dev_phase_upper_B": 268435456,
            "remaining_release_upper_B": 268435456,
        }
        validate(g)
        result["charges"], result["transient_UNKNOWN"] = charges()
        check_retained(g)
        assert not (ROOT / "private/quoridor-runner").exists(), (
            "no previously successful private rebuild replay"
        )
        assert not (ROOT / "qualification" / HERE.name).exists(), "unique new command logs required"
        save(HERE / "actual-admission.json", g)
        job = {
            "issue": "quoridor-4lc.351",
            "goal_issue": "quoridor-4lc",
            "thread_id": "01a11004-79f3-7c20-872c-432a2c347664",
            "cwd": str(W),
            "argv": [
                "/usr/bin/python3",
                "-B",
                str(Path(__file__).resolve()),
                "run",
                str(HERE / "actual-admission.json"),
                sha(HERE / "actual-admission.json"),
            ],
            "end_at": None,
            "notify_until": None,
            "max_runtime_seconds": 660,
            "control_interval_seconds": 30,
            "notify_interval_seconds": 10,
            "request_timeout_seconds": 25,
            "log_max_bytes": 65536,
            "resource_contract": str(RESOURCES),
        }
        save(HERE / "job.json", job)
        result["admission_SHA256"] = sha(HERE / "actual-admission.json")
        result["entry_ready"] = True
    except BaseException as e:
        result["errors"].append(repr(e))
    finally:
        if lease:
            lease.close()
        result["STOP"] = stamp()
        result["lease_released"] = True
        result["remaining"] = []
        result["current_job_reservation"] = "NONE"
        save(HERE / "preentry-result.json", result)
    print(json.dumps(result))
    if result["errors"]:
        raise SystemExit(1)


def run(path, expected):
    result = {
        "issue": "quoridor-4lc.351",
        "status": "STARTED",
        "commands": [],
        "primary_error": None,
        "finalization_errors": [],
        "source_before_after": False,
        "remaining": [],
    }
    lease = None
    process = None
    resources = None
    primary = None
    begin = time.monotonic()
    g = None

    def attempt(stage, f):
        nonlocal primary
        try:
            return f()
        except BaseException as e:
            result["finalization_errors"].append(
                {"stage": stage, "type": type(e).__name__, "message": str(e)}
            )
            if primary is None:
                primary = e
            else:
                primary.add_note(stage + ": " + repr(e))

    try:
        assert sha(path) == expected
        g = json.loads(Path(path).read_text())
        assert g["entry_ready"] is True
        quiet()
        physical()
        lease = LOCK.open("a+b")
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        result["lease_START"] = stamp()
        quiet()
        physical()
        validate(g)
        check_retained(g)
        result["initial_charges"], result["initial_unknown"] = charges()
        for n in ["target", "private", "TMP", "qualification"]:
            (ROOT / n).mkdir(exist_ok=True)
        (ROOT / "qualification" / HERE.name).mkdir(exist_ok=False)
        os.sched_setaffinity(0, {4})
        for k in g["unset_env"]:
            os.environ.pop(k, None)
        os.environ.update(g["env"])
        os.environ.update(g["effective_extra_env"])
        os.environ["PATH"] = str(TOOLCHAIN) + ":" + os.environ.get("PATH", "")
        os.environ.update(
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
            RAYON_NUM_THREADS="1",
            PYTHONDONTWRITEBYTECODE="1",
        )
        sys.path.insert(0, "/workspaces/quoridor/python")
        process = importlib.import_module("quoridor_training.cycle_process")
        deadline = begin + g["max_runtime_seconds"]

        class Resources:
            def __init__(self):
                self.sampled = dict(g["held_component_floors"])
                self.unknown = []
                self.next_census = 0
                self.stage = 0

            def check(self, owned=()):
                if time.monotonic() >= deadline:
                    raise process.CycleStopped("finite software deadline")
                if process.available_memory() < 4294967296:
                    raise process.CycleStopped("host reserve")
                quiet(owned)
                parents = []
                for p in ancestors():
                    info = process.process_info(p)
                    if info and p not in (1,):
                        parents.append(info["rss"])
                rss = sum(parents) + sum(
                    process.process_info(m["pid"])["rss"]
                    for m in owned
                    if process.process_info(m["pid"])
                )
                self.sampled["family_RSS_B"] = max(self.sampled.get("family_RSS_B", 0), rss)
                if rss + 67108864 > 6442450944:
                    raise process.CycleStopped("family6GiB including controller")
                if time.monotonic() >= self.next_census:
                    c, u = charges()
                    self.unknown.extend(u)
                    self.next_census = time.monotonic() + 0.5
                    for k, v in c.items():
                        self.sampled[k] = max(self.sampled.get(k, 0), v)
                    if self.stage < 5 and c["target"] > 268435456:
                        raise process.CycleStopped(
                            "dev target plus prospective256MiB release exceeds512MiB"
                        )

        resources = Resources()
        result["actualSTART"] = stamp()
        result["worker_identity"] = identity(os.getpid())
        save(
            HERE / "actual-START.json",
            {
                "actualSTART": result["actualSTART"],
                "identity": result["worker_identity"],
                "admission_SHA256": expected,
                "commands": 7,
            },
        )
        with process.cancellation_signals():
            for i, argv in enumerate(g["commands"]):
                resources.stage = i
                validate(g)
                assert sha(path) == expected
                resources.check()
                if i == 6:
                    built = ROOT / "target/release/quoridor-runner"
                    assert built.is_file()
                    size = built.stat().st_blocks * 512
                    assert size + 4096 <= COMPONENTS["private"], "private exact supported gap"
                    shutil.copy2(built, ROOT / "private/quoridor-runner")
                    result["private"] = row(ROOT / "private/quoridor-runner")
                    assert result["private"]["SHA256"] == sha(built)
                log = ROOT / "qualification" / HERE.name / f"{i + 1:02}.log"
                try:
                    rec = process.execute(argv, log, deadline, cpu_core=2, resources=resources)
                    result["commands"].append({"index": i, "returned_record": rec})
                except BaseException as e:
                    p = log.with_suffix(".process.json")
                    if p.exists():
                        attempt(
                            "failed receipt",
                            lambda: result["commands"].append(
                                {"index": i, "persisted_record": json.loads(p.read_text())}
                            ),
                        )
                    raise e
                if rec["log_bytes_seen"] > process.LOG_MAX_BYTES:
                    raise process.CycleStopped("truncated qualification UNKNOWN")
                if i == 0:
                    text = log.read_text()
                    assert "13 passed; 0 failed" in text, "new13 test count/result mismatch"
                if i == 6:
                    v = json.loads(log.read_text())
                    assert (
                        v["valid"] is True
                        and v["models_loaded"] == 0
                        and v["main_volume_n"] is None
                    )
                    assert (
                        v["compiled_sources"]["ai/alphabeta.rs"]
                        == "b976df272b273a147596f36ec503a2801b802b45389d8169ca62468d7a02b335"
                    )
                resources.check()
        result["status"] = "PASS"
    except BaseException as e:
        primary = e
        result["status"] = "FAILED"
        result["primary_error"] = {"type": type(e).__name__, "message": str(e)}
    finally:
        result["workerSTOP"] = stamp()
        result["whole_worker_s"] = time.monotonic() - begin
        if resources:
            result["sampled"] = resources.sampled
            result["transient_UNKNOWN"] = resources.unknown
        result["continuous_family_peak"] = "UNKNOWN"
        if g:
            attempt("source and controls after", lambda: validate(g))
            result["source_before_after"] = not any(
                e["stage"] == "source and controls after" for e in result["finalization_errors"]
            )
        attempt("final component census", lambda: result.update(final_charges=charges()))

        def empty_tmp():
            tmp = ROOT / "TMP"
            if (
                result["commands"]
                and tmp.exists()
                and not any(tmp.iterdir())
                and all(
                    (
                        x.get("returned_record", x.get("persisted_record", {})).get(
                            "direct_child_reaped"
                        )
                        is True
                        and x.get("returned_record", x.get("persisted_record", {})).get("remaining")
                        == []
                        and x.get("returned_record", x.get("persisted_record", {})).get(
                            "cleanup_complete"
                        )
                        is True
                    )
                    for x in result["commands"]
                )
            ):
                tmp.rmdir()
                result["owned_empty_TMP_removed"] = True

        attempt("owned empty TMP after directwait", empty_tmp)
        if lease:
            attempt("canonical lock close", lease.close)
        records = [
            x.get("returned_record", x.get("persisted_record", {})) for x in result["commands"]
        ]
        result["remaining"] = [m for x in records for m in x.get("remaining", [])]
        result["component_cleanup_complete"] = bool(records) and all(
            x.get("direct_child_reaped") is True
            and x.get("cleanup_complete") is True
            and x.get("remaining") == []
            for x in records
        )
        result["no_component_cleanup_certificate"] = not result["component_cleanup_complete"]
        if primary is not None and result["status"] == "PASS":
            result["status"] = "FAILED_FINALIZATION"
        result["source_cleanup_STOP"] = stamp()
        result["lease_close_attempted"] = lease is not None
        attempt("receipt persistence", lambda: save(HERE / "worker-result.json", result))
    print(
        json.dumps(
            {
                "status": result["status"],
                "STOP": result["source_cleanup_STOP"],
                "commands": len(result["commands"]),
                "error": result["primary_error"],
            }
        ),
        flush=True,
    )
    if primary is not None:
        raise primary


if __name__ == "__main__":
    if sys.argv[1:] == ["prepare"]:
        prepare()
    elif len(sys.argv) == 4 and sys.argv[1] == "run":
        run(sys.argv[2], sys.argv[3])
    else:
        raise SystemExit("prepare | run ADMISSION SHA256")
