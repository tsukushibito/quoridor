"""Finite affected caller qualification. No comparison or old-success execution."""

from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import time


W = Path("/workspaces/quoridor/.worktree/tt-hash-reuse351")
ROOT = W / ".artifacts/tt-hash-reuse351"
HERE = Path(__file__).resolve().parent
CANONICAL = Path("/workspaces/quoridor/research-data/ai-sigma/search-optimization/tt-hash-reuse351")
PLAN = ROOT / "cost-caller-v1/software-plan.json"
REPAIR = ROOT / "cost-caller-v1/C01-C02-binding-STOP.json"
REVIEW = Path(
    "/workspaces/quoridor/.worktree/endgame-solver335/.artifacts/tt-hash-review351-v1/cost-caller-v1/repair-v2"
)
OLD_GUARD = ROOT / "controls/software-entry-recovery-v2/worker.py"
OLD_ADMISSION = ROOT / "controls/software-entry-recovery-v2/actual-admission.json"
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
TMP = ROOT / "TMP/cost-caller-v1"
QUAL = ROOT / "qualification/caller-software-entry-v1"
RAW = ROOT / "raw/cost-caller-v1"
PRIVATE = ROOT / "private/tt351-processing"
COMPONENTS = {
    "source": 33554432,
    "target": 805306368,
    "private": 16777216,
    "TMP": 33554432,
    "qualification": 8388608,
    "raw": 8388608,
    "failures": 8388608,
    "review": 4194304,
    "RootGitcleanup": 4194304,
}
FLOORS = {
    "source": 3039232,
    "target": 517763072,
    "private": 8323072,
    "TMP": 1126400,
    "qualification": 69632,
    "raw": 0,
    "failures": 0,
    "review": 0,
    "RootGitcleanup": 0,
}
PINNED = {
    "software-controls-resources-v3.json": "1d214214d0681afb767ca44ce7d03168e991c50b98fe3f32681abbac2f1c0279",
    "cost-caller-resources-v2.json": "c7ddad599a43d363908d6cb61657d6f01a6a0065dd54e9071e71da2106cfd980",
    "source-assignment-v1.json": "43dc47260c1ec826ca2fbea32a60b87d488ebc4c16884ceed2a895e57b0a796e",
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def row(path):
    path = Path(path)
    s = path.stat()
    return {
        "path": str(path),
        "SHA256": sha(path),
        "bytes": s.st_size,
        "mode": stat.S_IMODE(s.st_mode),
    }


def load(path):
    return json.loads(Path(path).read_text())


def save(name, value):
    data = (json.dumps(value, indent=2) + "\n").encode()
    assert len(data) <= 65536, "bounded controller record"
    (HERE / name).write_bytes(data)


def guard_module():
    # The previously bound standard-library guard is immutable; runtime/process
    # libraries are imported only after the canonical lifetime lock is acquired.
    assert sha(OLD_ADMISSION) == "320a8d6310c34e57a620a700cd8880aa1add94e496c413c8171d143ac52e5ed3"
    previous = load(OLD_ADMISSION)
    expected = next(v for v in previous["control_records"] if v["path"] == str(OLD_GUARD))
    assert row(OLD_GUARD) == expected
    spec = importlib.util.spec_from_file_location("stopped_owned_guard", OLD_GUARD)
    g = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(g)
    return g


def quiet(g, owned=()):
    result = g.quiet(owned)
    # New private name is not an excuse to omit an orphaned/foreign caller.
    for p in Path("/proc").iterdir():
        if not p.name.isdecimal() or int(p.name) in g.ancestors():
            continue
        try:
            args = [os.fsdecode(a) for a in (p / "cmdline").read_bytes().split(b"\0") if a]
            if not args or Path(args[0]).name != "tt351-processing":
                continue
            if any(m["pid"] == int(p.name) and g.same_identity(m) for m in owned):
                continue
            if g.same_owned_session(g.group_info(int(p.name)), owned, g.group_info):
                continue
            raise RuntimeError(
                "actual named processing caller/UNKNOWN: " + str(g.identity(int(p.name)))
            )
        except FileNotFoundError:
            continue
    return result


def priority_fact():
    # Saved one-shot direct facts, not a future host quiet or task closure gate.
    return {
        "latest_known": "347.3 S01 canonical-result predicate repair v25 stopped11:56:02, narrow review pending; no announced genuine cohort READY/START, NNUE16 unentered",
        "UTC": utc(),
    }


def effective_source():
    assert sha(REPAIR) == "4b75e6dc9fc30cb1272915babdab9b4b3de3b23c958a665875e643abf5a6fe37"
    repair = load(REPAIR)
    parent = repair["inherited_effective_source_map"]
    assert row(parent["path"]) == parent
    inherited = load(parent["path"])["source_records"]
    by_path = {v["path"]: v for v in inherited}
    assert len(inherited) == len(by_path) == 141
    replacement = repair["exact_replaced_source_rows"]
    assert len(replacement) == 1
    caller = W / "crates/quoridor-ai/src/tt_hash_processing351.rs"
    assert replacement[0]["path"] == str(caller)
    assert (
        replacement[0]["SHA256"]
        == "7db1cffe8e801b9e8fbefdce2cc9da21dc4bc3de65517c1f53a8a1c98e2e9eb3"
    )
    assert str(caller) in by_path
    by_path[str(caller)] = replacement[0]
    return sorted(by_path.values(), key=lambda x: x["path"])


def owned_fixture_link(path, prepared):
    # Count the inode itself, never follow this deliberate final dangling link.
    # Only this freshly owned TMP and the exact reviewed fixture shape qualify.
    if not prepared or path.name != "dangling" or path.parent.parent != TMP:
        return False
    name = path.parent.name
    if (
        not name.startswith("tt351-output-guard-")
        or not name.removeprefix("tt351-output-guard-").isdecimal()
    ):
        return False
    if not stat.S_ISDIR(path.parent.lstat().st_mode):
        return False
    target = path.parent / "absent-owned-target"
    if path.readlink() != target:
        return False
    try:
        target.lstat()
    except FileNotFoundError:
        return True
    return False


def allocated(path, exclude=(), prepared=False):
    path = Path(path)
    try:
        path.lstat()
    except FileNotFoundError:
        return 0, []
    errors = []
    for attempt in range(2):
        pending, total, missing = [path], 0, []
        while pending:
            p = pending.pop()
            if p in exclude:
                continue
            try:
                s = p.lstat()
                if stat.S_ISLNK(s.st_mode):
                    assert owned_fixture_link(p, prepared), (
                        "foreign/unowned symlink census refusal: " + str(p)
                    )
                total += s.st_blocks * 512
                if stat.S_ISDIR(s.st_mode):
                    pending.extend(p.iterdir())
            except FileNotFoundError:
                missing.append(str(p))
        if not missing:
            return total, errors
        errors.append(
            {"attempt": attempt, "missing_stat": missing[:16], "transient_peak": "UNKNOWN"}
        )
    raise RuntimeError("second unstable owned census: " + json.dumps(errors))


def charges(prepared=False):
    exclusions = [ROOT / k for k in COMPONENTS if k not in ("source", "RootGitcleanup")]
    source, unknown = allocated(W, exclusions, prepared)
    git, u = allocated(Path("/workspaces/quoridor/.git/worktrees/tt-hash-reuse351"))
    d = {"source": source + git, "RootGitcleanup": 0}
    unknown += u
    for name in COMPONENTS:
        if name not in d:
            d[name], u = allocated(ROOT / name, prepared=prepared)
            unknown += u
    controls, u = allocated(HERE)
    unknown += u
    assert controls <= 1048576, "contained software controls exceeded"
    for name, value in d.items():
        assert value <= COMPONENTS[name], f"{name} unsupported gap{value - COMPONENTS[name]}B"
    return d, unknown


def retained_snapshot():
    # Full current hashes under canonical lease; snapshot only, no baseline copy.
    records = []
    for name in ("target", "private", "TMP", "qualification", "raw"):
        parent = ROOT / name
        if parent.exists():
            for p in sorted(parent.rglob("*")):
                if p.is_file():
                    value = row(p)
                    s = p.stat()
                    value["stat"] = [s.st_dev, s.st_ino, s.st_mtime_ns]
                    records.append(value)
    return records


def control_paths(previous):
    paths = [
        Path(__file__).resolve(),
        OLD_GUARD,
        OLD_ADMISSION,
        PLAN,
        REPAIR,
        REVIEW / "review.md",
        REVIEW / "control.json",
        Path("/workspaces/quoridor/scripts/dev/research-job.py"),
    ]
    paths += [CANONICAL / name for name in PINNED]
    paths += [
        Path(v["path"])
        for v in previous["control_records"]
        if v["path"].startswith("/workspaces/quoridor/python/quoridor_training/")
        or "/.cargo/" in v["path"]
    ]
    return list(dict.fromkeys(paths))


def validate(a):
    assert a["source_records"] == effective_source(), "effective exact source-map mismatch"
    assert sha(OLD_ADMISSION) == "320a8d6310c34e57a620a700cd8880aa1add94e496c413c8171d143ac52e5ed3"
    previous = load(OLD_ADMISSION)
    expected_controls = {str(p) for p in control_paths(previous)}
    admitted_controls = [v["path"] for v in a["control_records"]]
    assert (
        len(admitted_controls) == len(set(admitted_controls))
        and set(admitted_controls) == expected_controls
    ), "exact control path census mismatch"
    assert a["floors_B"] == FLOORS
    assert a["max_runtime_seconds"] == 600 and a["entry_ready"] is True
    assert (
        sha(REVIEW / "review.md")
        == "1dcd1972e3feca57e5055b116db6ce98f89bab5bf38c61e7b7e296389964dc10"
    )
    assert (
        sha(REVIEW / "control.json")
        == "9adcb8f845d0b52a18c0e80cb7323d237e41b82abd757d4edcb42218827b6f6b"
    )
    assert a["compiler_records"] == previous["compiler_records"], (
        "installed stable compiler closure changed"
    )
    assert a["commands"] == load(PLAN)["commands"] and a["env"] == load(PLAN)["env"]
    assert a["unset_env"] == load(PLAN)["unset_env"]
    assert a["components_B"] == COMPONENTS and sum(COMPONENTS.values()) == 922746880
    for name, digest in PINNED.items():
        assert sha(CANONICAL / name) == digest
    for v in a["source_records"] + a["compiler_records"] + a["control_records"]:
        assert row(v["path"]) == v, v["path"]
    assert not os.environ.get("RUSTFLAGS") and not os.environ.get("CARGO_ENCODED_RUSTFLAGS")
    for path in a["Cargo_configs_absent"]:
        assert not Path(path).exists(), "new unbound Cargo config"


def prepare():
    result = {
        "issue": "quoridor-4lc.351",
        "START": utc(),
        "entry_ready": False,
        "priority_fact": priority_fact(),
    }
    lease, primary = None, None
    try:
        lease = LOCK.open("a+b")
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        g = guard_module()
        result["quiet"] = quiet(g)
        result["physical"] = g.physical()
        os.sched_setaffinity(0, {4})
        for p in [TMP, QUAL, RAW, PRIVATE]:
            assert not p.exists() and not p.is_symlink(), "new phase path already occupied: " + str(
                p
            )
        previous = load(OLD_ADMISSION)
        assert (
            sha(OLD_ADMISSION) == "320a8d6310c34e57a620a700cd8880aa1add94e496c413c8171d143ac52e5ed3"
        )
        controls = control_paths(previous)
        assert (
            sha(REVIEW / "review.md")
            == "1dcd1972e3feca57e5055b116db6ce98f89bab5bf38c61e7b7e296389964dc10"
        )
        assert (
            sha(REVIEW / "control.json")
            == "9adcb8f845d0b52a18c0e80cb7323d237e41b82abd757d4edcb42218827b6f6b"
        )
        assert sha(g.CONTROLLER) == g.CONTROLLER_SHA
        a = {
            "entry_ready": True,
            "source_records": effective_source(),
            "compiler_records": previous["compiler_records"],
            "control_records": [row(p) for p in dict.fromkeys(controls)],
            "Cargo_configs_absent": previous["Cargo_configs_absent"],
            "commands": load(PLAN)["commands"],
            "env": load(PLAN)["env"],
            "unset_env": load(PLAN)["unset_env"],
            "components_B": COMPONENTS,
            "floors_B": FLOORS,
            "review_reader_STOP": "2026-10-09T11:26:39.231291+00:00",
            "retained_before_records": retained_snapshot(),
            "max_runtime_seconds": 600,
        }
        validate(a)
        result["initial_charges"], result["transient_unknown"] = charges()
        assert (
            max(result["initial_charges"]["target"], FLOORS["target"]) + 268435456
            <= COMPONENTS["target"]
        ), "actual target + prospective closure exceeds cap"
        encoded = gzip.compress((json.dumps(a, separators=(",", ":")) + "\n").encode(), mtime=0)
        assert len(encoded) + 4096 <= 524288, "snapshot subclass unsupported gap"
        (HERE / "actual-admission.json.gz").write_bytes(encoded)
        digest = sha(HERE / "actual-admission.json.gz")
        job = {
            "issue": "quoridor-4lc.351",
            "goal_issue": "quoridor-4lc",
            "thread_id": "01a11004-79f3-7c20-872c-432a2c347664",
            "cwd": str(W),
            "argv": [
                "/usr/bin/python3",
                "-B",
                str(HERE / "worker.py"),
                "run",
                str(HERE / "actual-admission.json.gz"),
                digest,
            ],
            "end_at": None,
            "notify_until": None,
            "max_runtime_seconds": 660,
            "control_interval_seconds": 30,
            "notify_interval_seconds": 10,
            "request_timeout_seconds": 25,
            "log_max_bytes": 65536,
            "resource_contract": str(CANONICAL / "software-controls-resources-v3.json"),
        }
        save("job.json", job)
        result.update(entry_ready=True, admission_SHA256=digest)
    except BaseException as e:
        primary = e
        result["error"] = {"type": type(e).__name__, "message": str(e)}
    finally:
        result["lease_released"] = lease is None
        if lease:
            try:
                lease.close()
                result["lease_released"] = True
            except BaseException as e:
                result["lease_close_error"] = {"type": type(e).__name__, "message": str(e)}
                if primary is None:
                    primary = e
                else:
                    primary.add_note("canonical close: " + repr(e))
        result.update(
            STOP=utc(),
            remaining=[],
            current_reservation="NONE" if result["lease_released"] else "UNKNOWN",
        )
        try:
            save("preentry-result.json", result)
        except BaseException as e:
            if primary is None:
                primary = e
            else:
                primary.add_note("preentry persistence: " + repr(e))
        print(json.dumps(result), flush=True)
    if primary is not None:
        raise primary


def copy_private(log):
    artifacts, finished = [], False
    for line in log.read_text().splitlines():
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue  # merged Cargo human diagnostics remain in the bound log
        if obj.get("reason") == "build-finished":
            finished = obj.get("success") is True
        if (
            obj.get("reason") == "compiler-artifact"
            and obj.get("target", {}).get("name") == "quoridor_ai"
            and obj.get("target", {}).get("kind") == ["lib"]
            and obj.get("profile", {}).get("test") is True
            and obj.get("executable")
        ):
            artifacts.append(Path(obj["executable"]))
    assert finished and len(artifacts) == 1, (
        "one typed current libtest artifact and successful Cargo closure required"
    )
    source = artifacts[0]
    assert (
        source.is_relative_to(ROOT / "target/release/deps")
        and source.is_file()
        and not source.is_symlink()
    )
    size = source.stat().st_blocks * 512
    assert size + 4096 <= 8388608, f"private increment gap{size + 4096 - 8388608}B"
    current, _ = allocated(ROOT / "private")
    assert max(current, FLOORS["private"]) + size + 4096 <= COMPONENTS["private"]
    with source.open("rb") as original, PRIVATE.open("xb") as target:
        shutil.copyfileobj(original, target, 1048576)
    PRIVATE.chmod(stat.S_IMODE(source.stat().st_mode))
    assert sha(PRIVATE) == sha(source)
    return {"source_artifact": row(source), "private": row(PRIVATE)}


def run(path, expected):
    begin = time.monotonic()
    result = {
        "issue": "quoridor-4lc.351",
        "status": "STARTING",
        "commands": [],
        "finalization_errors": [],
        "primary_error": None,
    }
    lease, a, watch, process = None, None, None, None
    primary = None
    tmp_owned = False

    def attempt(stage, action):
        nonlocal primary
        try:
            return action()
        except BaseException as error:
            result["finalization_errors"].append(
                {"stage": stage, "type": type(error).__name__, "message": str(error)}
            )
            if primary is None:
                primary = error
            else:
                primary.add_note(stage + ": " + repr(error))

    try:
        assert sha(path) == expected
        a = json.loads(gzip.decompress(Path(path).read_bytes()))
        assert a["entry_ready"] is True
        lease = LOCK.open("a+b")
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        result["lease_START"] = utc()
        g = guard_module()
        result["prequiet"] = quiet(g)
        result["physical"] = g.physical()
        os.sched_setaffinity(0, {4})
        validate(a)
        assert retained_snapshot() == a["retained_before_records"], (
            "retained full hashes changed before child"
        )
        result["initial_charges"], result["initial_unknown"] = charges()
        for p in [TMP, QUAL, RAW]:
            assert not p.exists() and not p.is_symlink()
            p.mkdir(parents=True, exist_ok=False)
        tmp_owned = True
        for k in a["unset_env"]:
            os.environ.pop(k, None)
        os.environ.update(a["env"])
        sys.path.insert(0, "/workspaces/quoridor/python")
        process = importlib.import_module("quoridor_training.cycle_process")
        deadline = begin + a["max_runtime_seconds"]

        class Watch:
            def __init__(self):
                self.peaks = dict(FLOORS)
                self.unknown = []
                self.next = 0

            def check(self, owned=()):
                if time.monotonic() >= deadline:
                    raise process.CycleStopped("finite software deadline")
                if process.available_memory() < 4294967296:
                    raise process.CycleStopped("host4GiB reserve")
                quiet(g, owned)
                rss = sum(
                    info["rss"]
                    for pid in g.ancestors()
                    if pid != 1 and (info := process.process_info(pid))
                )
                rss += sum(
                    info["rss"] for member in owned if (info := process.process_info(member["pid"]))
                )
                self.peaks["family_RSS_B"] = max(self.peaks.get("family_RSS_B", 0), rss + 67108864)
                if rss + 67108864 > 6442450944:
                    raise process.CycleStopped("family6GiB including64MiB controller")
                if time.monotonic() >= self.next:
                    d, u = charges(prepared=tmp_owned)
                    self.unknown.extend(u)
                    self.next = time.monotonic() + 0.5
                    for name, value in d.items():
                        growth = max(0, value - result["initial_charges"].get(name, 0))
                        inclusive = max(value, FLOORS[name] + growth)
                        self.peaks[name] = max(self.peaks.get(name, 0), inclusive)
                        if inclusive > COMPONENTS[name]:
                            raise process.CycleStopped(
                                f"{name} held-floor/new-growth gap{inclusive - COMPONENTS[name]}B"
                            )
                    assert allocated(QUAL)[0] <= 1048576, "new qualification subclass"
                    assert allocated(RAW)[0] <= 1048576, "new raw subclass"
                    assert allocated(TMP, prepared=True)[0] <= 4194304, "new TMP subclass"

        watch = Watch()
        result["actualSTART"] = utc()
        result["worker_identity"] = g.identity(os.getpid())
        save(
            "actual-START.json",
            {
                "actualSTART": result["actualSTART"],
                "identity": result["worker_identity"],
                "admission_SHA256": expected,
                "commands": 4,
            },
        )
        with process.cancellation_signals():
            for index, argv in enumerate(a["commands"]):
                validate(a)
                assert sha(path) == expected
                watch.check()
                if index == 3:
                    result["compiled_private"] = copy_private(QUAL / "03.log")
                    os.environ.update(load(PLAN)["last_command_env"])
                    os.environ.pop("TT351_PACKET", None)
                log = QUAL / f"{index + 1:02}.log"
                try:
                    rec = process.execute(argv, log, deadline, cpu_core=2, resources=watch)
                    result["commands"].append({"index": index, "returned_record": rec})
                except BaseException:
                    saved = log.with_suffix(".process.json")
                    if saved.exists():
                        attempt(
                            "failed process receipt",
                            lambda: result["commands"].append(
                                {"index": index, "persisted_record": load(saved)}
                            ),
                        )
                    raise
                if rec["log_bytes_seen"] > process.LOG_MAX_BYTES:
                    raise process.CycleStopped("truncated software proof UNKNOWN")
                if index == 0:
                    assert "3 passed; 0 failed" in log.read_text()
                if index == 3:
                    assert "1 passed; 0 failed" in log.read_text()
                    packet = load(RAW / "workload.json")
                    assert (
                        packet["cycles"] == 64
                        and packet["observations_per_method"] == 1536
                        and packet["total_method_observations"] == 6144
                    )
                    assert [v["prefix"] for v in packet["root_catalog"]] == [
                        [],
                        [13, 75],
                        [13, 75, 14, 76],
                        [81],
                    ]
                    assert len(packet["observed_context_catalog"]) == 24
                    assert (RAW / "workload.json").stat().st_size <= 32768
                    result["qualified_workload"] = row(RAW / "workload.json")
                watch.check()
        result["status"] = "PASS_SOFTWARE_FREEZE_ONLY"
    except BaseException as error:
        primary = error
        result["status"] = "FAILED"
        result["primary_error"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        result["workerSTOP"] = utc()
        result["whole_worker_s"] = time.monotonic() - begin
        if watch:
            result["sampled"] = watch.peaks
            result["transient_UNKNOWN"] = watch.unknown
        result["continuous_peaks"] = "UNKNOWN"
        if a:
            attempt("source/control/compiler after", lambda: validate(a))
        result["source_before_after"] = a is not None and not any(
            x["stage"] == "source/control/compiler after" for x in result["finalization_errors"]
        )
        attempt("final census", lambda: result.update(final_charges=charges(prepared=tmp_owned)))
        records = [
            c.get("returned_record", c.get("persisted_record", {})) for c in result["commands"]
        ]
        result["component_cleanup_complete"] = bool(records) and all(
            c.get("direct_child_reaped") is True
            and c.get("cleanup_complete") is True
            and c.get("remaining") == []
            for c in records
        )
        result["remaining"] = [member for c in records for member in c.get("remaining", [])]

        def finish_tmp():
            if (
                tmp_owned
                and result["component_cleanup_complete"]
                and TMP.exists()
                and not any(TMP.iterdir())
            ):
                TMP.rmdir()
                result["owned_empty_TMP_removed"] = True
            elif tmp_owned:
                result["owned_TMP_retained_partial_or_nonempty"] = True

        attempt("owned TMP after directwait", finish_tmp)
        if lease:
            result["lease_close_attempted"] = True
            attempt("canonical lock close", lease.close)
        result["source_cleanup_STOP"] = utc()
        result["numeric_comparison"] = "NOT_RUN_NOT_ADMITTED"
        if primary is not None and result["status"] == "PASS_SOFTWARE_FREEZE_ONLY":
            result["status"] = "FAILED_FINALIZATION"
        attempt("result persistence", lambda: save("worker-result.json", result))
        if any(e["stage"] == "result persistence" for e in result["finalization_errors"]):
            result["status"] = "FAILED_FINALIZATION"
            attempt("late persistence facts", lambda: save("late-finalization.json", result))
    print(
        json.dumps(
            {
                "status": result["status"],
                "STOP": result["source_cleanup_STOP"],
                "commands": len(result["commands"]),
                "error": result["primary_error"],
            }
        ),
        flush=True,
    )
    if primary is not None:
        raise primary


if __name__ == "__main__":
    if sys.argv[1:] == ["prepare"]:
        prepare()
    elif len(sys.argv) == 4 and sys.argv[1] == "run":
        run(sys.argv[2], sys.argv[3])
    else:
        raise SystemExit("prepare or run admission SHA")
