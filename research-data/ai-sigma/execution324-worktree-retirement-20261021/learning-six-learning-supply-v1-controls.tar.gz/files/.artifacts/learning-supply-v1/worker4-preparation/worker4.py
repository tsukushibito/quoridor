"""One declared discarded diagnostic comparison; exact gates and owned cleanup."""

from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
import time

from quoridor_training.cycle_process import GPUResources, cancellation_signals, execute, alive


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalize(value):
    if isinstance(value, dict):
        return {k: normalize(v) for k, v in value.items() if k not in ("wall_seconds",)}
    if isinstance(value, list):
        return [normalize(v) for v in value]
    return value


def main():
    control = json.loads(Path(sys.argv[1]).read_text())
    os.sched_setaffinity(0, {0, 1, 2, 3})
    for p, h in control["expected_files_sha256"].items():
        if sha(p) != h:
            raise ValueError("fixed source/input/control changed: " + p)
    root = Path(control["root"])
    root.mkdir(exist_ok=False, parents=True)
    (root / "tmp").mkdir()
    resources = GPUResources(control["resources"], root, None)
    result = {
        "issue": "quoridor-4lc.323.4",
        "status": "STARTED",
        "candidate_adoption": False,
        "newE_Sigma": "CLOSED",
        "phases": [],
    }
    started = time.monotonic()
    try:
        with cancellation_signals():
            for name, command in control["phases"]:
                tick = time.monotonic()
                execute(command, root / (name + ".log"), None, resources=resources)
                process = json.loads((root / (name + ".process.json")).read_text())
                if (
                    not process["direct_child_reaped"]
                    or not process["cleanup_complete"]
                    or process["remaining"]
                    or alive(process["child"])
                ):
                    raise ValueError("exact owned phase STOP")
                result["phases"].append(
                    {
                        "name": name,
                        "whole_child_control_seconds": time.monotonic() - tick,
                        "process": process,
                    }
                )
                if name == "qualification":
                    if (
                        json.loads((root / "qualification.json").read_text())["status"]
                        != "PASS_EXACT"
                    ):
                        raise ValueError("qualification failed; no actual epoch comparison")
                elif name != "worker2cpu4":
                    reference = root / "worker2cpu4" / "output"
                    actual = root / name / "output"
                    for checkpoint in ("initial.pt", "best.pt", "last.pt"):
                        if sha(reference / checkpoint) != sha(actual / checkpoint):
                            raise ValueError(
                                "EXACT model/Adam/checkpoint state bytes differ: "
                                + name
                                + "/"
                                + checkpoint
                            )
                    for part in ("initial-model", "best-model", "last-model"):
                        if sha(reference / part / "weights.f32") != sha(
                            actual / part / "weights.f32"
                        ):
                            raise ValueError(
                                "EXACT wholeepoch model trajectory differs: " + name + "/" + part
                            )
                    for file in (
                        "curves.jsonl.gz",
                        "diagnostic-curves.jsonl.gz",
                        "batch.jsonl.gz",
                        "observations.jsonl.gz",
                    ):
                        with (
                            gzip.open(reference / file, "rt") as a,
                            gzip.open(actual / file, "rt") as b,
                        ):
                            ar = [normalize(json.loads(x)) for x in a]
                            br = [normalize(json.loads(x)) for x in b]
                        if ar != br:
                            raise ValueError(
                                "numeric/selector records differ: " + name + "/" + file
                            )
                    import numpy as np

                    with (
                        np.load(reference / "sampling-counts.npz") as a,
                        np.load(actual / "sampling-counts.npz") as b,
                    ):
                        if set(a.files) != set(b.files) or any(
                            not np.array_equal(a[k], b[k]) for k in a.files
                        ):
                            raise ValueError("actual original visit/exposure mismatch")
                write(root / "phase-journal.json", result)
        result["status"] = "PASS_EXACT_DIAGNOSTIC"
    finally:
        result.update(
            whole_worker_seconds=time.monotonic() - started,
            finished_at=datetime.now(timezone.utc).isoformat(),
            observed_resources=resources.observed,
            controller_reserve_bytes=resources.controller_reserve,
            all_completed_phases_direct_waited=True,
        )
        write(root / "worker-result.json", result)
    print(
        json.dumps(
            {"status": result["status"], "candidate_adoption": False, "newE_Sigma": "CLOSED"}
        )
    )


if __name__ == "__main__":
    main()
