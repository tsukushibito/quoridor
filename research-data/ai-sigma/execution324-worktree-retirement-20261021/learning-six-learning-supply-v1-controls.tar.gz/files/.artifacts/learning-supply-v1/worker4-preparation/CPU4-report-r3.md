CPU4の2対4ワーカー比較は、事前ルールにより2ワーカーを維持する。4ワーカーは厳密一致に合格したが、ループが0.88%、caller全体が1.14%遅かった。1回ずつの固定順測定であり、差の統計的確定や全環境の最適ワーカー数を示さない。

| 条件（両方CPU0〜3） | 学習loop秒 | 初期化・評価・保存込みcaller秒 | 合計CPU秒 |
| ------------------- | ---------: | -----------------------------: | --------: |
| worker2cpu4         |     22.149 |                         49.491 |    54.579 |
| worker4cpu4         |     22.344 |                         50.054 |    54.829 |

各4109更新、original T8,413,949、末尾765、全元行1回、反転抽選4,209,397。各model forward19,132,566（train/fullselector/固定診断を別保存）。CPU/CUDA内の入力・loss・勾配・Adam stateは各3更新で既資格2と厳密一致。INITIAL/BEST/LASTのPT全byte（model+Adam+position）、nativeweights、全数値観測（wallのみ除外）、visits NPZは両モード一致。モデル状態は破棄され、候補採用を意味しない。

初期化2=12.427/4=12.780秒、epoch境界fullT/fullV2=7.913/4=7.996秒。queue待ちは小さく、4で短縮していない。workerCPU累積・転送enqueue/lease待ちは包含・重複し、DMA純時間やwall合計としない。詳細数値はCPU4-analysis-r3.jsonに保存。

controller全費128.862603926秒、guardian128.768655447秒は包含し加算しない。以前のCPU2,3四条件271.156201977秒は別条件として保全（既知2ジョブ計400.018805903秒、旧全史費証明ではない）。START06:01:21.830744、exactSTOP06:03:30.633901Z、guardian+全3直接子wait/reaped/exit0/cleanuptrue/remaining[]、新鮮な記録science identities不存在。Root/318.3へSTOPを一度直接通知済み。RAMfamilyサンプル+controller3,010,498,560B<4GiB、wholeVRAM1,830,305,792B<6GiB、raw保存量2793472B<3.5MiB。peakはサンプリングで連続上限証明ではない。

固定版: review-binding-C1-handler-r3.json a4781dce…、train27edd302/supplyf14b84d2、現main必要alignmentはRoot別仕事。停止sourceは先の全WT archiveとr3変更2path archiveから復元可能、C1の旧失敗/原レビュー/IO補修/費を保持。今回source追加変更0、main/Git/index0。元323paused、新E/Sigmaclosed、fullfit/新method/priority3,4/最良MSE追求0。後続323.5はこの検証・終了後に別issueで入口を準備する。
