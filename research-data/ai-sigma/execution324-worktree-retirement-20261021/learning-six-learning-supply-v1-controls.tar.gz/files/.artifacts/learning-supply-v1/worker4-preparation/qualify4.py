"""Exact discarded input/loss/gradient/Adam qualification; no selected weights."""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

import numpy as np

from quoridor_training.cache import load
from quoridor_training.common import resolve_config
from quoridor_training.sampling import EpochSampler, ReflectionBatches
from quoridor_training.supply import PackedSupply
from quoridor_training.train import build_model


def digest_tensor(value):
    return hashlib.sha256(value.detach().cpu().contiguous().numpy().tobytes()).hexdigest()


def main():
    os.sched_setaffinity(0, {0, 1, 2, 3})
    config = json.loads(Path(sys.argv[1]).read_text())
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    import torch

    cfg = resolve_config(config["fit_config"])
    binding = json.loads(Path(config["input_binding"]).read_text())
    scale = json.loads(Path(binding["scale_artifact"]).read_text())
    torch.set_num_threads(2)
    torch.set_num_interop_threads(2)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    _, total = torch.cuda.mem_get_info()
    torch.cuda.set_per_process_memory_fraction(min(5 * 1024**3 / total, 1.0))
    c = load(config["cache"])
    if c.manifest_sha != binding["cache_manifest_sha"]:
        raise ValueError("cache binding")
    t = np.flatnonzero(c.splits == 0)
    spec = importlib.util.spec_from_file_location("independent_old_formula", config["old_features"])
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    result = {
        "status": "STARTED",
        "qualification": {},
        "exact_tolerance": 0,
        "candidate_adoption": False,
    }
    try:
        for device in ("cpu", "cuda"):
            reference = None
            for workers in (2, 4):
                torch.manual_seed(cfg["training"]["seed"])
                torch.cuda.manual_seed_all(cfg["training"]["seed"])
                model = build_model(cfg["model"], scale).to(device)
                initial = np.concatenate(
                    [
                        v.detach().cpu().numpy().astype("<f4").ravel()
                        for v in (
                            model.ft.weight,
                            model.ft.bias,
                            model.h.weight,
                            model.h.bias,
                            model.out.weight,
                            model.out.bias,
                        )
                    ]
                )
                if hashlib.sha256(initial.tobytes()).hexdigest() != binding["initial_weights_sha"]:
                    raise ValueError("INITIAL identity")
                optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=0)
                sampler = EpochSampler(t, 2048, cfg["training"]["seed"])
                reflection = ReflectionBatches(c, 0.5, cfg["training"]["reflection_seed"])
                pipe = (
                    None
                    if workers is None
                    else PackedSupply(
                        reflection,
                        2048,
                        device,
                        np.ones(c.row_count, np.float32),
                        1,
                        workers=workers,
                    )
                )
                rows = []
                try:
                    for step in range(1, 4):
                        ix = sampler.next_batch()
                        if pipe is None:
                            mask = reflection.generator.random(len(ix)) < 0.5
                            records = c.records(ix)
                            g = records["geometry"]
                            g[mask] = old.reflect(g[mask])
                            x = torch.from_numpy(old.features(g)).to(device)
                            d = torch.from_numpy(records["distance"].copy()).to(device)
                            side = torch.ones(len(ix), dtype=torch.long, device=device)
                            targets = torch.from_numpy(c.labels[ix, 1].copy()).to(device)
                            weights = torch.from_numpy(np.ones(len(ix), np.float32)).to(device)
                            inputs = x, d, side
                        else:
                            inputs, targets, weights = pipe.batch(
                                ix, training=True, sampler=sampler
                            )
                        optimizer.zero_grad(set_to_none=True)
                        prediction = model(*inputs)
                        per_row_loss = torch.nn.functional.mse_loss(
                            prediction, targets, reduction="none"
                        )
                        loss = (per_row_loss * weights).mean()
                        if not torch.isfinite(loss):
                            raise ValueError("nonfinite loss")
                        loss.backward()
                        if not torch.stack(
                            [
                                torch.isfinite(v.grad).all()
                                for v in model.parameters()
                                if v.grad is not None
                            ]
                        ).all():
                            raise ValueError("nonfinite gradients")
                        entry = {
                            "inputs": [digest_tensor(v) for v in inputs],
                            "targets": digest_tensor(targets),
                            "weights": digest_tensor(weights),
                            "loss": digest_tensor(loss),
                            "per_row_loss": digest_tensor(per_row_loss),
                            "gradients": {
                                k: digest_tensor(v.grad) for k, v in model.named_parameters()
                            },
                        }
                        for group in optimizer.param_groups:
                            group["lr"] = 0.01 * step / 257
                        optimizer.step()
                        if not torch.stack(
                            [torch.isfinite(v).all() for v in model.parameters()]
                        ).all():
                            raise ValueError("nonfinite parameter")
                        entry["parameters"] = {
                            k: digest_tensor(v) for k, v in model.named_parameters()
                        }
                        entry["Adam_state"] = [
                            [
                                {
                                    k: digest_tensor(v) if torch.is_tensor(v) else v
                                    for k, v in state.items()
                                }
                                for state in optimizer.state.values()
                            ]
                        ]
                        rows.append(entry)
                        if pipe:
                            pipe.release()
                        if reference is not None and entry != reference[step - 1]:
                            result["first_difference"] = {
                                "device": device,
                                "workers": workers,
                                "step": step,
                                "expected": reference[step - 1],
                                "actual": entry,
                            }
                            raise ValueError(
                                "EXACT input/loss/gradient/Adam boundary differs; no epoch comparison"
                            )
                finally:
                    if pipe:
                        pipe.close()
                old_trace = json.loads(Path(config["old_qualification"]).read_text())[
                    "qualification"
                ][f"{device}:2"]
                if rows != old_trace:
                    raise ValueError(
                        "CPU4 still must match qualified CPU2/3 same math update trace exactly"
                    )
                if reference is None:
                    reference = rows
                result["qualification"][f"{device}:{workers}"] = rows
                del model, optimizer, pipe
                if device == "cuda":
                    torch.cuda.synchronize()
                    torch.cuda.empty_cache()
        result["status"] = "PASS_EXACT"
    finally:
        Path(config["result"]).write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "status": result["status"],
                "exact_boundary": True,
                "forward_rows": 24576,
                "candidate_adoption": False,
            }
        )
    )


if __name__ == "__main__":
    main()
