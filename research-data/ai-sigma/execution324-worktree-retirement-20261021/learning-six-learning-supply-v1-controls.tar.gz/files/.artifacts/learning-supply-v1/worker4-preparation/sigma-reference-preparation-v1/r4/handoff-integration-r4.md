Beads323.5 — remaining finalization/quiet SOURCE-ONLY repair r4

To execution/integration324 thread01a1153d-7900-7740-837f-c300ca54764f, cwd /workspaces/quoridor. SAME learner/thread/owner/cwd; job323.5/goal4lc/completion destination unchanged. main/Git/index0, parent323paused/newE/oldopened CLOSED. No export/MSE/timing job or numerical reservation.

Fixed r4 binding:
/workspaces/quoridor/.worktree/learning-million/.artifacts/learning-supply-v1/worker4-preparation/sigma-reference-preparation-v1/r4/review-binding-r4.json

Please return only these remaining related boundaries to SAME saved reviewer323.5.1. R3 targetff751 and receipt/probe/control SHA+reader/children/jobsSTOP were verified before source edits. Old r2/r3 source/probe/refusal/fees/UNKNOWN preserved; no success suite replay/new reviewer.

P1 repair: cycle_process.execute final log seek/write/truncate/flush, selector/pipe/pidfd/log closes, final process receipt and signalmask restoration are independently attempted. The original caught exception object and each finalization failure are kept in a BaseExceptionGroup with nonrecursive receipt fallback facts. Directwait/process cleanup facts are distinguished from handle-close completion; close failure is not saved as successful control cleanup. Failed receipt is failed-or-partial UNKNOWN. New-owned log open remains xb; admission refusal does not overwrite old log or old process receipt. The launch/runloop and TERM/KILL/directwait/process-cleanup body AST match old r3 (aside from relocating the owned-log open). No optimizer/model/data/FP/label/rule change.

P2 repair: final named_physics includes actual nnue_search-\* runners. Actual function fake-/proc cases verify matching, benign absence and zombie exclusion; guard refuses known runner before resources or child launch. Future entry still needs fresh actual peer/runtime/physics; old STOP is history.

Six scoped actual-function NN0 PASS: childexit1+finalreceiptIO preserves original object and attempts all closes/mask restore; combined log/handle/receipt/mask errors; completed child plus close error remains failed; existing log/receipt preserved; known runner classification/refusal. Fake OS child only, no live fault/model/ORT/native/CDLL/CUDA calls. Test runner directly waited; wall0.202554543s/maxRSS42632KiB/CPU2/address-space512MiB. Old C1/input/native16/loader2/epoch successes reused, not replayed. Sigma reference/math/counters/planes1903/trainedloader source bytes remain identical to r3. Ruff/Prettier and full stopped archive restoration SHA PASS.

R4 config/plan/job/guard/forecast now reference typed92eac941 and learning1042/evidence102039552/futuremodels720896. Latest communicated NEXTmanifestdee1 changes search/maintenance only and is metadata history, not a running-job equality gate. Search325 source-only packet adds no compute admission; no clock held by this repair.

Concrete forecast-r4.json: all old r2/r3 history and new source/control499712B (r3 held364544 +135168), SAME output131072. Existing review FULL262144 is held; propose only additional8192B for combined narrow probe/report/control confirmation (no implicit fresh64KiB).
Required evidence102174900 >102039552: **deficit135348B**.
Whole1091986481 <1092616192: margin629711B.
Current actual source-only files remain within current evidence capacity; future output/related confirmation are the deficit. Changed cycle file20480B conservatively charged whole in the new source increment without refunding held oldsource/buildUNKNOWN. No global/target scan, copy/delete of models/assets, selftransfer or old cap reset. A conserved +136KiB evidence / -136KiB futuremodels would leave568KiB futuremodels and3916B evidence margin, but is **unapplied proposal only**.

Guard is deliberately bound to current typed92 proof/new inclusive forecast and refuses that unresolved deficit before physics/model launch. No new method ACK requested. After narrow blocker confirmation/readerSTOP and supported actual category admission, rebind only necessary next-entry metadata with exact SHA and fresh peerquiet before the already requested retainedSigma/originalV419150/STM±1/trainedBEST51 denseNNUE CPUORT diagnostic. Trained PTb16ba38e/parameters9ca438/savedV.42744088098494515 unchanged; no INITIAL candidate/fit/globalfreeze/default/native-trained qualification.

Full current WT stopped source, minimal ordinary patch.gz, config/plan/guard/job, test raw/cost, old receipt/proof links are in r4 binding. One handoff-generation tool JS parse refusal occurred before any shell command; recorded in quality receipt, no model/science effect. Source/ownedchildren STOP, backup thenIdle; source-only related confirmation/evidence admission pending. Reply/report only to execution324, no oldRoot.
