Beads quoridor-4lc.323.5 — fixed ordinary SOURCE-ONLY repair r3

宛先は新しい実行・統合担当 thread01a1153d-7900-7740-837f-c300ca54764f / quoridor-4lc.324 / cwd /workspaces/quoridor。旧Rootへ通知しない。報告先変更のみで、所有・job issue/goal/thread・元323のpause・newE/oldopened封印は変えていない。

r3 binding: /workspaces/quoridor/.worktree/learning-million/.artifacts/learning-supply-v1/worker4-preparation/sigma-reference-preparation-v1/r3/review-binding-r3.json
Same saved reviewer323.5.1へ、C1–C3のこの関連差分だけをお願いします。r2 reviewer/control STOPと対象SHA確認後に修復。新role/旧input全レビュー/成功native16・loader2・旧epoch再実行は不要。

- C1: Torch参照とORT出力の両方をFP32/形状/finite/[-1,1]で比較前に検査し、差自身もfiniteかつ1e-6以下を要求。実qualification-loop ASTでNaN/Inf/範囲外はwarmupへ進まない。
- C2: NNUEも同値域。実main/guardianのconfiguration/admission/loading/body/終了処理を捕捉し、元例外objectとreader close・receipt IOを別stageで保持。全reader終了と保存を試み、保存不能は非再帰のExceptionGroup noteへ事実を残す。既存outputを上書きしない。試行/戻り/個別出力検証済行と未返却実行UNKNOWNを区別する。TorchScript内部再実行はUNKNOWN。
- C3: 実Torch/ORT version・CPU affinity・ORT/Torch threads・固定16V ordinal/入力SHA・32warmup/各1600/pair orderを実receiptへ保存。Sigma feeddict/sliceとNNUE prebuilt-feed indexのtimer内負荷差を明示。新guard/job/config/source/typed admissionを束縛し、既cycle_processのdirectwait/pidfd/TERM-KILL/cleanup/RSS/VRAM/log/pause制御を使う。新owned outputだけを監視、global/target walkなし。

モデルを呼ばない関連12件PASS、storage guard追加後の影響2件PASS。13 unique cases（影響1件のみ再実行）。合計child wall0.403122579秒、最大RSS43,212KiB、CPU2/address-space512MiB。Torch/ORT/native/CDLL/CUDAのimport/callを拒否した。旧planes1903B prefixとAST、trained loader3 statement ASTはr2と同一。旧3入力NN0/native16/loader2証拠を再用。Ruff/Prettier PASS、停止source archive復元SHA確認。これはlive export/MSE/timing/故障時CUDA資格の成功証明ではない。

既accepted TRAINED patience1 BEST51/209559: PTb16ba38e…/params9ca438e4…、保存済original fullV MSE .42744088098494515。INITIAL primary/追加モデルなし。Sigma d790外部保持資産をコピーせず、V419150/STM±1、CPUORT/FP32/thread1/batch1の既質問は不変。full Sigma policy+value対denseNNUE fullFT+head+Dであり、sparse native/reused headや棋力比ではない。

具体保存予測: forecast-r3.json。新ソース・制御・旧r2保存込みsource/control364544B（従前212992Bから151552B増）。同output131072Bを保持するとevidence102031540B > 現101908480B、**不足123060B**。whole1091843121B < 1042MiB1092616192B、余773071B。ALL old8MiB/review256KiB/pair4MiB/extra128KiB/必要資産/buildUNKNOWN保持。全量走査・削除・自己移管・旧cap refundなし。現source-only実ファイルは現evidence内、未来出力のdependent heavyが不足。必要なら同total内futuremodel832KiBからevidenceへ128KiBを前向きに分類すれば予測余8012Bだが、これは**提案だけ・未適用**。別資源根拠を要すなら判断をお願いします。

guardは現在の6243298d typed proofと新forecastの不足を実入口で拒否する。job-r3.jsonは未submit、numerical予約なし。guard/job/source/configが固定済みでも、related blocker確認・具体category admission・直前actual peerquiet/physicsの成立までmodel/export/MSE/timingは起動しない。mutable globalmanifestを実行中に比較して既runを失敗化しない。今のprivate f83/d8d5、保存済search4feb exactSTOPを履歴参照し、次entryではactualquietを確認する。

full stopped source/ordinary patch.gz/config/plan/guard/job/NN0/old-r2 linksをbindingへ含めた。main/Git/index writer0、旧323 pause維持、SOURCE STOP。今回323.5のみin-progressで関連レビューとprecise evidence admissionを待つ。backup sync後Idle。
