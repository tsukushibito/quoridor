"""Independent geometry oracle and bounded deterministic worker/lease contracts."""

from copy import deepcopy
import sys
import threading
import unittest
from unittest.mock import patch

import numpy as np

from .compact_cache import CompactCorpus
from .public_features import RECORD, FeatureWorkspace, features
from .sampling import EpochSampler, ReflectionBatches
from .supply import FLOATS_PER_ROW, OrderedPrefetch, PackedSupply, payload_views
from .test_public_features import scalar_reference, scalar_reflection


class Host(np.ndarray):
    def numpy(self):
        return self


class FakeTorch:
    float32, long = np.float32, np.int64

    @staticmethod
    def empty(size, **kwargs):
        return np.empty(size, dtype=kwargs["dtype"]).view(Host)

    @staticmethod
    def ones(size, **kwargs):
        return np.ones(size, dtype=kwargs["dtype"])


def corpus(rows=4861):
    value = object.__new__(CompactCorpus)
    rng = np.random.default_rng(71)
    records = np.zeros(rows + 2, dtype=RECORD)
    records["geometry"]["pawns"] = [[0, 80]]
    records["geometry"]["stocks"] = rng.integers(0, 11, size=(rows + 2, 2))
    records["geometry"]["horizontal"] = rng.integers(0, 2**64, size=rows + 2, dtype=np.uint64)
    records["geometry"]["vertical"] = rng.integers(0, 2**64, size=rows + 2, dtype=np.uint64)
    records["distance"] = rng.random((rows + 2, 2), dtype=np.float32)
    records["z"] = rng.choice([-1, 1], rows + 2)
    records.flags.writeable = False
    value.maps, value.offsets, value.row_count = [records], np.array([0, rows + 2]), rows + 2
    value.splits = np.concatenate((np.zeros(rows, np.uint8), np.ones(2, np.uint8)))
    value.labels = np.empty((rows + 2, 2), np.float32)
    value.labels[:, 0], value.labels[:, 1] = np.nan, records["z"]
    return value


class FeatureContracts(unittest.TestCase):
    def test_independent_both_views_reflection_all_anchors(self):
        c = corpus(128)
        g = c.records(np.arange(128))["geometry"]
        mask = np.arange(128) % 3 == 0
        reference = np.stack(
            [scalar_reference(scalar_reflection(p) if mask[i] else p) for i, p in enumerate(g)]
        )
        out = np.full((128, 2, 312), 999, np.float32)
        work = FeatureWorkspace(128)
        self.assertIs(features(g, mask, out=out, workspace=work), out)
        np.testing.assert_array_equal(out, reference)
        np.testing.assert_array_equal(
            features(g, out=out, workspace=work), np.stack([scalar_reference(p) for p in g])
        )
        np.testing.assert_array_equal(g, c.maps[0]["geometry"][:128])

    def test_each_wall_decoded_once_and_full_initialization(self):
        from . import public_features

        g = corpus(3).records(np.arange(3))["geometry"]
        with patch.object(public_features, "wall_bits", wraps=public_features.wall_bits) as decode:
            out = features(g, np.ones(3, bool))
        self.assertEqual(decode.call_count, 2)
        self.assertTrue(np.isin(out, [0, 1]).all())
        self.assertEqual(out.dtype, np.float32)
        self.assertTrue(out.flags.c_contiguous)

    def test_malformed_geometry_mask_output_workspace_rejected(self):
        g = corpus(3).records(np.arange(3))["geometry"]
        for mask in (np.zeros(3, np.uint8), np.zeros(4, bool)):
            with self.assertRaises(ValueError):
                features(g, mask)
        for out in (
            np.zeros((3, 2, 312), np.float64),
            np.zeros((3, 312, 2), np.float32),
            np.zeros((3, 2, 624), np.float32)[:, :, ::2],
        ):
            with self.assertRaises(ValueError):
                features(g, out=out)
        with self.assertRaises(ValueError):
            features(g, workspace=FeatureWorkspace(2))
        invalid = g.copy()
        invalid["pawns"][0] = [1, 1]
        with self.assertRaises(ValueError):
            features(invalid)

    def test_payload_blocks_contiguous_same_dtype_no_overlap(self):
        storage = np.zeros(2048 * FLOATS_PER_ROW, np.float32)
        for n in (2048, 765):
            parts = payload_views(storage, n)
            for i, x in enumerate(parts):
                self.assertTrue(x.flags.c_contiguous)
                self.assertEqual(x.dtype, np.float32)
                self.assertTrue(np.shares_memory(storage, x))
                self.assertTrue(all(not np.shares_memory(x, y) for y in parts[:i]))
        with self.assertRaises(ValueError):
            payload_views(storage, 2049)


class WorkerContracts(unittest.TestCase):
    def test_order_capacity_and_failure_cleanup(self):
        q = OrderedPrefetch(2)
        q.submit(0, 1, lambda: 0)
        q.submit(1, 1, lambda: 1)
        q.submit(2, 1, lambda: 2)
        with self.assertRaises(ValueError):
            q.submit(3, 1, lambda: 3)
        with self.assertRaises(ValueError):
            q.take(1)
        self.assertEqual([q.take(i) for i in range(3)], [0, 1, 2])
        q.close()
        q.close()
        self.assertFalse(any(t.name.startswith("qf1-supply") for t in threading.enumerate()))

    def test_pending_failure_shutdown_and_consumed_not_success(self):
        q = OrderedPrefetch(1)
        q.submit(0, 5, lambda: (_ for _ in ()).throw(ValueError("worker failure")))
        q.submit(1, 7, lambda: 1)
        with self.assertRaisesRegex(ValueError, "worker failure"):
            q.take(0)
        q.close()
        self.assertEqual(q.dispatched_rows, 12)
        self.assertEqual(q.consumed_rows, 0)
        self.assertEqual(q.expanded_rows, 7)
        self.assertFalse(any(t.name.startswith("qf1-supply") for t in threading.enumerate()))

    def test_drain_failure_still_joins_worker(self):
        q = OrderedPrefetch(1)
        q.submit(0, 3, lambda: (_ for _ in ()).throw(ValueError("drain failure")))
        with self.assertRaisesRegex(ValueError, "drain failure"):
            q.close()
        self.assertTrue(q.closed)
        self.assertFalse(any(t.name.startswith("qf1-supply") for t in threading.enumerate()))

    def test_modes_order_masks_tail_targets_rng_and_no_corpus_duplicate(self):
        c = corpus()
        observations = []
        for workers in (0, 1, 2, 4):
            reflected = ReflectionBatches(c, 0.5, 32320261008)
            sampler = EpochSampler(np.arange(4861), 2048, 32320261007)
            reference_rng = np.random.default_rng(32320261008)
            seen, masks, sizes = [], [], []
            with patch.dict(sys.modules, {"torch": FakeTorch}):
                pipe = PackedSupply(
                    reflected, 2048, "cpu", np.ones(c.row_count, np.float32), 1, workers=workers
                )
            self.assertIs(pipe.corpus, c)
            try:
                for _ in range(2):
                    while True:
                        ix = sampler.next_batch()
                        mask = reference_rng.random(len(ix)) < 0.5
                        inputs, targets, weights = pipe.batch(ix, training=True, sampler=sampler)
                        np.testing.assert_array_equal(
                            inputs[0], features(c.records(ix)["geometry"], mask)
                        )
                        np.testing.assert_array_equal(inputs[1], c.records(ix)["distance"])
                        np.testing.assert_array_equal(inputs[2], np.ones(len(ix), np.int64))
                        np.testing.assert_array_equal(targets, c.labels[ix, 1])
                        np.testing.assert_array_equal(weights, np.ones(len(ix), np.float32))
                        self.assertTrue(
                            all(x.flags.c_contiguous for x in (*inputs, targets, weights))
                        )
                        for _, _, pending_slot in pipe.descriptors:
                            self.assertFalse(
                                np.shares_memory(pipe.active["numpy"], pending_slot["numpy"])
                            )
                        state = deepcopy(reflected.generator.bit_generator.state)
                        pipe.batch(np.array([4861, 4862]))
                        self.assertEqual(state, reflected.generator.bit_generator.state)
                        seen.extend(ix.tolist())
                        masks.extend(mask.tolist())
                        sizes.append(len(ix))
                        if sampler.cursor == 4861:
                            break
                self.assertEqual(sizes, [2048, 2048, 765] * 2)
                self.assertEqual(len(set(seen[:4861])), 4861)
                self.assertEqual(reflected.training_seen, 9722)
                self.assertEqual(reflected.reflected_seen, sum(masks))
                self.assertEqual(sampler.seen, 9722)
                observations.append(
                    (seen, masks, deepcopy(reflected.generator.bit_generator.state))
                )
            finally:
                pipe.close()
            self.assertFalse(any(t.name.startswith("qf1-supply") for t in threading.enumerate()))
        self.assertEqual(observations[0], observations[1])
        self.assertEqual(observations[0], observations[2])
        self.assertEqual(observations[0], observations[3])

    def test_bad_training_partition_capacity_and_close(self):
        c = corpus(4)
        with patch.dict(sys.modules, {"torch": FakeTorch}):
            pipe = PackedSupply(
                ReflectionBatches(c, 0.5, 2), 4, "cpu", np.ones(6, np.float32), 1, workers=1
            )
        try:
            for ix in (np.array([4]), np.arange(5), np.array([[0]])):
                with self.assertRaises(ValueError):
                    pipe.batch(ix, training=True)
        finally:
            pipe.close()
        with self.assertRaises(ValueError):
            pipe.batch(np.array([0]))


if __name__ == "__main__":
    unittest.main()
