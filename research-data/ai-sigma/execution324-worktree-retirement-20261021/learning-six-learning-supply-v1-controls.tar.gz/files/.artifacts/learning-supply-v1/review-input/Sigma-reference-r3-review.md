# 323.5.1 related r3 C1–C3 review

Target binding ff7511262090a5c763a6ae5d452d544833f52b14c287aaea90a2b0d4ac6aae21. All29 unique fixed source/control/evidence/admission/prior paths SHA match; old evidence tree unchanged; after-source match. Paths/SHA: frozen binding and324 receipt; binaries/data unopened.

C1 resolved: both predictions FP32/equalshape/finite/[-1,1], finite error<=1e-6 before warmup. Independent actual helpers reject NaN/Inf/1.25 (3 cases). C2 main covers early/body phases, primary/reader/IO objects and attempt-return-valid/UNKNOWN. Supplied13 NN0 reused; old input/native16/loader2 not replayed.

P1 remaining C2: cycle_process.py303–308 captures child exit1 as CycleStopped, but final save_record at384 can throw OSError before385–389 closes. Actual execute AST with fake child/IO: direct-wait done, final receipt IO refused; outer OSError has no original context/group, selector/pipe/fd close unattempted. Expected original failure plus IO retained and all handle closes attempted. Fix that stage/retarget concrete binding; no source edits by reviewer. Probe:0.063630615s/RSS34628KiB, no child/model/native/runtime calls (owned probe child directly waited). Not a live cleanup/fault qualification.

C3 version/CPU/thread/16/32/1600/order/scope now recorded; freshoutput/4GiB+64MiB/4KiBlog/pause/wait/TERM-KILL control supplied. P2 named_physics41–45 misses known nnue_search-* runners; include those in final fresh peerquiet check. Old624329 guard correctly refuses123060B deficit before physics/child. Prospective92eac941 schema fits existing admission code; after readerSTOP retarget guard/forecast/job SHA/capacity/NEXT0d39 only: E8012B/whole773071B margins. No job/ACK gate granted.

STOP readers/children0, source/main/Git writer0. SameCPU3/RAM512MiB/fullaccess-never; old costs/errors preserved. First reviewer count assertion mistaken25vs29 retained. No live export/MSE/timing/fault proof. Close only323.5.1/backup; notify324 thread once, oldRoot/paused323 untouched. Fees/waits/version/tree: r3-control/probe. Math/r2 reused. Idle.
