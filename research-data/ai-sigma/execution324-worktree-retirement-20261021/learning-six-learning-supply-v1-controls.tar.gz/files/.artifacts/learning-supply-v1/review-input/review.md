quoridor-4lc.323.4.1 関連独立レビュー完了。対象review-binding.json SHA ac384bbf40217238139dd9cf7636507b1787f26628e39235c08d397371985577。6source/4evidence/plan SHAを開始時・小fixture前・終了時に照合。採用blocker C1/P1が1件、通常指摘0。以下の数値・供給順の確認を、停止処理の成功認定へ拡張しない。

C1/P1: train.py1168–1175でpacked_supply.close()が例外を投げると、LAST_COMPLETED_UPDATEのLAST保存とpersist()を飛ばす。OrderedPrefetch.close83–91は未消費futureのdrain例外をshutdown(wait=True)後に再送し、PackedSupply.close277–288もevent待ち後に再送するので到達可能。既に成功更新後、次batchのprefetchがValueError/MemoryErrorで失敗し、error/cancel/early-stopから退出する入力が該当する。LASTが初期/旧保存時点のままになり、停止status/成功露出/visit countersなどの最終保存も失われる。close例外は元の停止理由を覆う場合もある。期待: worker/event回収を完了し、最後の確定更新とSTOP記録を保存してからprimary/cleanup双方の失敗を返す。実値: 回収完了だがLAST/persist呼出し0。

独立小NN0/mock（cleanup-probe.json）は、実train ASTのfinally本体を変更せず抽出し、実OrderedPrefetch/PackedSupply CPU closeに未消費765行futureのValueErrorを注入。checkpoint/persistのみspyへ置換、LAST_COMPLETED_UPDATEを指定。期待[checkpoint:last,persist]に対して実際[]、ValueError、queueclosed/workerjoin済み。Torch import拒否、モデル/forward/native/CUDA/build0、実wall0.078800278s、childRSS39856KiB。全trainer/GPUの失敗試験ではなく、この制御境界の再現である。producerによる修正と新fixed bindingで関連再確認が必要。成功epochを再実行する必要性は今回導いていない。

確認した入力/数学: public_features61–99はpawn x→8−x、H/V anchor x→7−xを最終QF1へ直接配置し、P2 viewを既存180度座標で保持。H/Vは各1decode、out全域zero、2×312 FP32 onehot、stock/D/zを変更しない。records_outはcorpus非alias、各slotのwork/index/geometryは専有。既存scalar_reference/scalar_reflectionの独立座標式と新fixtureを照合し、新実装同士の比較だけで判断していない。geometry bounds/coincident/shape/mask/contiguity/容量の拒否を維持。完全なQuoridor合法性は既native資格済みcorpusの前提であり、codecのbounds検査だけで合法性を保証しない。

Packed views: 628floats/元行のstorageをfeatures624/D2/target1/weight1の別連続blockへ分け、通常2048とtail765で各shape/dtype/stride/orderを保つ。sideはdevice上のlong ones。元のMSE(reduction=none)×objective_weights→mean、loss/gradient/parameter finite acceptanceとoptimizer成功後のvisit/seen更新は不変。既GPU finite aggregateを新最適化と扱わない。scalar copy除去は記録も利用もないcompact stepだけで、実record_update点は同じloss/grad/numerical観測を残す。precision/TF32/FMA/教師/seed/順序の変更は差分にない。

所有/順序: worker0/1/2のbounded threads、workers+1 slots/futuresと専用eval slot。入力ID/maskをcopy、realReflectionRNGは実供給時のみadvance、lookaheadはstate cloneと現epoch.orderだけ。futureを元順でtakeし、tail/次epochを越えず、evalはoriginalでreflectionRNGを消費しない。dispatched/harvested-expanded/consumed供給とsuccessful training seenを別記。拡張を完了して未harvestのfutureはexpanded集計にまだ入らない。モデルcopy/CUDA処理はworkerへ渡さず同CPU2,3で共有corpusを読む。host再利用前にready(DMA)とconsumer eventsを同期し、device消費streamがreadyを待ち、release時consumer eventを記録する。通常evalは独立slotで先読みが残ることがあり、毎evalの全worker drainを主張しない。closeはjoin/eventsを待つがC1の停止保存欠陥がある。

提供NN013PASSは9新+4既geometryoracle、log SHA一致。再実行していない。CPU/CUDAそれぞれbaseline/0/1/2workers×3更新のinputs/targets/weights/loss/per-row/gradients/parameters/Adam digestをmetadata上で完全一致と再確認（CPU↔CUDA同士のbit一致とは別）。4actualepochのupdates4109/T8413949/末尾765/V419150、forward counts、reflection counts、各row訪問min=max1、INITIAL/BEST/LASTのnativeweights/PT SHA値は一致。大corpus/labels/PT/weights/NPZは開かず、供給されたbytehash/metadata証拠の範囲で再用した。

| 条件 | loop秒 | whole caller秒 |
| --- | ---: | ---: |
| baseline | 33.8197 | 63.1794 |
| P1 sync | 28.3013 | 54.2436 |
| 1worker | 24.0639 | 51.4061 |
| 2worker | 22.3216 | 49.6338 |

固定plan SHA a86eba89…6de68d3の規則を再計算: P1 loop16.317%減、1worker/P1 14.972%減、2worker/1worker 7.240%減、2worker/baseline whole21.440%減。>5%追加loop改善とwhole非退行が成立し、報告selected2は事前規則と整合。ただし各条件1回の固定順序、cache/thermal resetなし、CI/一般速度倍率/収束/棋力を証明しない。caller enqueue/worker/lease clocksはinclusiveでDMAの純時間ではなく、nested和をwhole費としない。job89adc1cb STOPはcontroller271.156201977s、worker269.628851519s、5phase directwait/remaining[]/cleanup[]とRoot fresh6PIDabsent証拠を再用。exit0だけを数学証明にしていない。

未確認/制限: CUDA失敗/cancel時の実event待ち、異常停止後のライブcheckpoint/status（C1）、一般epoch/model/topology、worker thread負荷の連続peak、別装置への性能一般化。NN0のFakeTorchはCPUのみであり、CUDA lease failure/cancelのmock/live PASS証拠はない。既実成功epochはこの未確認を埋めない。新fit/候補採用/defaultweights/全学習後native/globalfreeze/newE/Sigmaは0。default workers0 syncの設定は維持、1/2は明示診断mode。main174B codec/no geometry+Reflection APIとWT66B fulloriginalの差は別Root依存整合前提であり、mainへのwhole trainer移入/互換性を本レビューで認定しない。

証拠 review-input/review.md/json/source-check.json/numerical-evidence-check.json/cleanup-probe.json/control.json。writerはこの256KiB枠のみ、旧費/失敗/UNKNOWN/assets/paused323を変更しない。Beads前にPythonRLIMIT_ASを掛けていない。CPU3/RAM512、外部network/GPU/native/Torch/modelcalls/build/newjob/delegate/source/main/Git/index0。reader/owned children停止。Root宛issuequoridor-4lcへ一度報告、323.4.1のみclose、backup後Idle。親323.4/paused323/旧閉issueを操作しない。
