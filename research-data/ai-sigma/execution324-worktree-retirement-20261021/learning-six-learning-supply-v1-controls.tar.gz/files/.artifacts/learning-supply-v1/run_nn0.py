import importlib.abc
import resource
import sys
import unittest
import os

os.sched_setaffinity(0, {3})
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))


class RejectTorch(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "torch" or fullname.startswith("torch."):
            raise AssertionError("NN0 must not import Torch")


sys.meta_path.insert(0, RejectTorch())
suite = unittest.defaultTestLoader.loadTestsFromNames(
    ["quoridor_training.test_supply", "quoridor_training.test_public_features.PublicGeometryTests"]
)
r = unittest.TextTestRunner(verbosity=2).run(suite)
print("Torch_imported", "torch" in sys.modules)
sys.exit(0 if r.wasSuccessful() else 1)
