# 同意味供給改善の有限診断 — quoridor-4lc.323.4

優先度1の壁decode一回/正しい反転の直接配置/再利用buffer/一括FP32転送と、優先度2のbounded1・2workerを実装・比較した。事前規則は2workerを選ぶ。全モードでCPU/CUDAの小3更新と実1epochのPT/model/Adam/nativeweight bytes・全数値観測・訪問数が完全一致した。候補モデルや本学習の再開ではなく、破棄する診断状態だけ。

| 構成             | 学習loop |  初期化 | 固定診断 | epoch末fullT/fullV等 | 終了IO | caller全体 | CPU全費 |
| ---------------- | -------: | ------: | -------: | -------------------: | -----: | ---------: | ------: |
| 画像なし従来     |  33.820s | 12.809s |   6.145s |               8.982s | 0.249s |    63.179s | 62.292s |
| 優先度1・同期    |  28.301s | 11.965s |   4.758s |               7.912s | 0.262s |    54.244s | 53.323s |
| 優先度1＋1worker |  24.064s | 12.028s |   5.771s |               8.129s | 0.252s |    51.406s | 55.588s |
| 優先度1＋2worker |  22.322s | 12.325s |   5.765s |               7.914s | 0.246s |    49.634s | 53.487s |

全構成で元T8,413,949を4,109更新/tail765で一巡。元fullV419,150・epoch1 fullT・初期の全固定診断を同一条件で実行。各forward総19,132,566行（train8,413,949/full selector9,260,441/diagnostic1,458,176）。画像生成0。初回warmup257を含むloop、固定診断、epoch境界、終了を分け、初期fullV/T診断も約1.0–1.2秒を別scopeに記録した。初期化や保存を含む全費をloopだけの比と混同しない。

優先度1のみでloop16.32%減、2workerは1workerに対して7.24%減かつcaller回帰なしで事前条件(>5%)を満たす。従来から2workerのloopは34.00%減、callerは21.44%減。ただし各条件1回・固定順（従来→同期→1worker→2worker）、OS cache/熱状態をリセットせず、CI/一般速度保証/収束費の証明はない。繰り返して有利な結果を探していない。2workerのCPU全費53.49秒、1worker55.59秒でthread費も含む。

## 実装と寿命

壁H/Vをそれぞれ1回だけunpackし、P1/P2の624値へ直接配置。反転pawn9幅とwallanchor8幅を区別し、反転対象だけ最終座標へ置く。pack→unpackの中間を廃止し、feature outputは毎回全zero初期化する。index/pawn/record workspaceはslot固有。D/zは保存f32/int教師の順序・値を変えず、元mapへ書き込まない。

host/device1本のFP32 blockをfeatures(n,2,312)/distance(n,2)/target(n)/objective weights(n)の個別contiguous viewに分ける。tailでもoffsetを実nから計算し元strideを維持。lossのnone/weights乗算/meanはそのまま。GPU側sideは従来と同じlong onesで再用しH2Dではない。有限loss/grad/parameterは各更新で保持、既存のGPU aggregateチェックを新しい改善と数えない。記録しない更新だけ不要なloss/MSE scalarのCPU取出しを省いた。

workerはThreadPoolExecutorの1/2threadで確定済みbatch全体だけを展開する。corpus/map/groupsは一つを共有し、model/CUDA stateを複製しない。元samplerの現在epoch orderと独立反転RNGのcloneで未来maskを計画し、実sampler/RNGは消費時だけ進めて一致を確認する。次epochへ先読みしない。validationは無反転でRNGを消費しない。queueはworker数+1slot、evalは別slot。

pinned host storageへの展開後、ownerだけが別CUDA transfer streamへ一回copyする。ready eventをconsumer streamが待ち、consumerの最終use eventとDMA ready eventの両方を次のhost/device再書込前に同期する。slot別device blockなので次batchの転送が現モデル入力を破壊しない。workercloseはpending全futureをdrainし、finallyでjoin、全event/streamを同期する。attempt/dispatched/expanded/consumed/successful updateを別に記録する。

## 時計・残る律速

2workerのtraining expansion worker累積7.100秒、queue wait0.0355秒、transfer enqueue1.341秒、lease wait0.0828秒。1workerは7.259/0.0374/1.441/0.0909秒、同期は4.552/0.0256/0.892/0.0785秒。worker workはモデル計算・転送と重なるため足してloopにしない。enqueueとevent caller waitを純DMA/kernel時間と呼ばない。評価用展開はこれらのtraining work合計に含まれず、fullV/fullT費は別表のscopeに含む。

今回の4epochはplain lifecycle集計のみ、詳細profiler/追加同期0。guardianの監視/出力・資源制御費はwhole-jobへ含まれる。transferの内訳分離が追加profileなしではUNKNOWNであること、startup/shuffle/queue初回の未分離部分がinitialization/first update/callerへ含まれることを保持する。IPCはthread方式のためプロセス間copy0、Future/queue/clone-mask/pinning/startup費は実caller内で計上。新trace/依存/全cache常駐化/GPU unpack/torch.compileは0。

改善後も初期化12.32秒・固定診断5.76秒・epoch境界7.91秒が残り、1epoch全体をloop22.32秒だけに短縮することはできない。初期化は複数epochで償却されるが、この有限比較から全収束時間を推定しない。loop内のGPU/finite guardの新しい支配比は未測定。ここで優先度1/2の実装・診断を止め、優先度3/4へ進まない。

## 資格・停止・採用境界

NN0 13PASS（新9/既geometry oracle4）、Torch import拒否。独立座標式の両view・reflection・H/V全anchor、shape/mask/output/record/capacity、2epoch順序/50%mask/tail/各行一度、validation RNG、worker例外/drain/join/非aliasを検査。CPU/CUDA各baseline/0/1/2workerで同じINITIALから3Adam更新、inputs/target/weights/loss/per-row loss/gradients/parameters/Adamstate hashが完全一致、許容誤差0。各device内の同意味照合であってCPU=Cudaのbit一致を主張しない。

実epochは全INITIAL/BEST/LAST PT byteSHA（model+Adam+position）とnative weightSHA、numeric全観測group payload/curves/batch/訪問NPZが一致。wall_secondsだけを数値record比較から除いた。selected学習native資格/global freeze/newE/Sigmaは未実行。

job89adc1cb actualSTART04:59:02.789535Z/naturalSTOP05:03:33.814815Z、controller271.156201977秒、guardian269.628851519秒。5phase child wallは包含値で二重合算しない。guardian＋5直接子は全wait/reaped/cleanuptrue/remaining[]、fresh6 scientific IDs absent、sourcewriterSTOP/Cargo0/current-next numeric予約0。sampled familyRSS3,013,210,112Bはcontroller64MiB込み4GiB未満、whole-deviceVRAM1,829,126,144Bは6GiB未満。瞬間絶対peak/プロセスexclusiveVRAMと混同しない。初回collectionのPYTHONPATH不足は管理失敗として別JSONに保持し数値jobを再実行しない。

停止sourceとfull package archive、WT効率差分patch、現main dependency境界は別に引き渡す。mainはまだ174B v1 codec/反転・nullhorizon callerなし、WTは既accepted66B fulloriginal callerであり、WT全trainをmainへ丸ごとcopyしない。Rootが既採用境界と必要依存を整合してから、task効率差分だけを当てる。mainへ直接適用可能な小patchと偽装せず main-integration-boundary.json に正確な不足・path/SHAを示す。default current sourceは同期0で、診断qualified2は明示train(...supply_workers=2)。採用時の2worker接続はRoot/same323.1の関連input/worker review後。余計な旧codec shimを追加しない。

## 証拠・保存

plan/forecast/control/preflight/review-binding/analysis/stop-receipt/main-integration-boundary.json、WT-efficiency-only.patch、WT-stopped-source.tar.gz、baseline-stopped-source.tar.gz、NN0-r1.log。raw/model診断rootは .worktree/assets/checkpoints/public-full-learning/supply-efficiency-v1 。既1048MiB/evidence94MiB、今回8MiB forecastを保持し、旧assets/原失敗/UNKNOWN/caps/費を削除/refund/全域scanせず、最終専有量はreceiptへ記録する。

親323 paused-by-user、323.2/.3 closed、新E/Sigma封印はそのまま。このscope後に本fit/最適化/新候補を自動起動しない。Rootだけがmain/Git/index writer。関連reviewはRootへ一度渡しsame323.1で採用前に確認、毎run/newrole/reviewerは作らない。
