"""Strict packet/input boundary only; no Torch, ORT or native imports."""

import copy
import hashlib
import importlib.abc
import math
import struct
import sys
import unittest

import numpy as np


class DenyModels(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in {"torch", "onnx", "onnxruntime"}:
            raise AssertionError("NN0 model import denied: " + fullname)
        return None


sys.meta_path.insert(0, DenyModels())
from fixture import validate_row  # noqa: E402


def row():
    dense = np.zeros((2, 312), dtype="<f4")
    dense[:, [4, 157, 300, 311]] = 1
    distance = np.asarray([0.1, 0.2], dtype="<f4")
    return {
        "ordinal": 0,
        "record_sha256": "a" * 64,
        "features_sha256": hashlib.sha256(
            dense.tobytes() + distance.tobytes() + struct.pack("<q", 1)
        ).hexdigest(),
        "ids": [[4, 157, 300, 311], [4, 157, 300, 311]],
        "distance": distance.tolist(),
        "native_side": 0,
        "torch_side": 1,
        "expected": 0.123,
    }


class PacketContracts(unittest.TestCase):
    def test_exact_dense_hash_and_side_accepted(self):
        validate_row(row())

    def test_nonfinite_or_out_of_range_expected_refused(self):
        for value in (math.nan, math.inf, -math.inf, 1.25, -1.25):
            bad = row()
            bad["expected"] = value
            with self.assertRaises(ValueError):
                validate_row(bad)

    def test_bad_ids_distance_side_and_hash_refused(self):
        base = row()
        for change in (
            {"ids": [[4, 4, 157, 300, 311], base["ids"][1]]},
            {"ids": [[4, 157, 300], base["ids"][1]]},
            {"distance": [math.nan, 0.2]},
            {"distance": [0.1, 1.1]},
            {"torch_side": 0},
            {"native_side": 1},
            {"features_sha256": "e" * 64},
        ):
            bad = copy.deepcopy(base)
            bad.update(change)
            with self.assertRaises(ValueError):
                validate_row(bad)

    def test_unknown_field_refused(self):
        bad = row()
        bad["companion"] = "outside strict packet"
        with self.assertRaises(ValueError):
            validate_row(bad)


if __name__ == "__main__":
    unittest.main()
