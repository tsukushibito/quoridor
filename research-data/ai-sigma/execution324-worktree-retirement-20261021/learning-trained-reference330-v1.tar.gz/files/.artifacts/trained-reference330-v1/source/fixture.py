"""One fixed16 independent CPU Torch reference; no native evaluator or fit."""

import hashlib
import json
from pathlib import Path
import struct
import sys
import time

import numpy as np

from quoridor_training.public_features import RECORD, features
from quoridor_training.sigma_reference import (
    _attempt,
    _completed,
    _counter,
    _finalize_reference,
    _returned,
)
from quoridor_training.test_public_features import scalar_reference


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_row(row):
    if set(row) != {
        "ordinal",
        "record_sha256",
        "features_sha256",
        "ids",
        "distance",
        "native_side",
        "torch_side",
        "expected",
    }:
        raise ValueError("strict consumer row fields")
    if row["native_side"] != 0 or row["torch_side"] != 1:
        raise ValueError("fixed STM side mapping")
    if not np.isfinite(row["expected"]) or not -1 <= row["expected"] <= 1:
        raise ValueError("finite bounded Torch expected")
    dense = np.zeros((2, 312), dtype="<f4")
    for view, ids in enumerate(row["ids"]):
        if len(ids) > 24 or ids != sorted(set(ids)) or any(not 0 <= i < 312 for i in ids):
            raise ValueError("sorted bounded QF1 IDs")
        if any(
            sum(lo <= i < hi for i in ids) != 1
            for lo, hi in ((0, 81), (81, 162), (290, 301), (301, 312))
        ):
            raise ValueError("QF1 pawn/stock slots")
        dense[view, ids] = 1
    distance = np.asarray(row["distance"], dtype="<f4")
    if (
        distance.shape != (2,)
        or not np.isfinite(distance).all()
        or not ((0 <= distance) & (distance <= 1)).all()
    ):
        raise ValueError("finite STM distance2")
    blob = dense.tobytes() + distance.tobytes() + struct.pack("<q", 1)
    if hashlib.sha256(blob).hexdigest() != row["features_sha256"]:
        raise ValueError("native input bytes hash")


def run(cfg, receipt, output):
    receipt["phase"] = "fixed_binding"
    for path, expected in cfg["expected_files_sha256"].items():
        if sha(path) != expected:
            raise ValueError("fixed source/model/input binding: " + path)
    prior = json.loads(Path(cfg["R5_result"]).read_text())
    if prior["workload"]["V_ordinals"] != cfg["ordinals"]:
        raise ValueError("same frozen target-blind16 ordinal order")
    cache = json.loads(Path(cfg["cache_manifest"]).read_text())
    part = next(p for p in cache["partitions"] if p["name"] == "validation")
    path = Path(cfg["validation"])
    if (
        part["file"] != path.name
        or part["rows"] != 419150
        or path.stat().st_size != 419150 * RECORD.itemsize
    ):
        raise ValueError("original V denominator/record layout")
    # Only16 exact seek/read records, not a corpus loader/scan or label selection.
    with path.open("rb") as stream:
        chunks = []
        for ordinal in cfg["ordinals"]:
            stream.seek(ordinal * RECORD.itemsize)
            chunk = stream.read(RECORD.itemsize)
            if len(chunk) != RECORD.itemsize:
                raise ValueError("short fixed original record")
            chunks.append(chunk)
    raw = b"".join(chunks)
    if hashlib.sha256(raw).hexdigest() != prior["workload"]["fixed_records_SHA"]:
        raise ValueError("exact R5 fixed16 record identity")
    records = np.frombuffer(raw, dtype=RECORD)
    if not np.isin(records["z"], (-1, 1)).all():
        raise ValueError("original decisive STM record qualifier")
    receipt["phase"] = "geometry_input"
    x = features(records["geometry"])
    oracle = np.stack([scalar_reference(g) for g in records["geometry"]])
    if (
        x.shape != (16, 2, 312)
        or x.dtype != np.float32
        or not np.array_equal(x.view(np.uint32), oracle.view(np.uint32))
    ):
        raise ValueError("independent bothview QF1 input bits")
    distances = np.array(records["distance"], dtype="<f4", order="C", copy=True)
    side = np.ones(16, dtype="<i8")
    if not np.isfinite(distances).all() or not ((0 <= distances) & (distances <= 1)).all():
        raise ValueError("fixed original distance")
    rows = []
    for i, ordinal in enumerate(cfg["ordinals"]):
        row = {
            "ordinal": ordinal,
            "record_sha256": hashlib.sha256(chunks[i]).hexdigest(),
            "features_sha256": hashlib.sha256(
                x[i].astype("<f4", copy=False).tobytes()
                + distances[i].tobytes()
                + side[i : i + 1].tobytes()
            ).hexdigest(),
            "ids": [np.flatnonzero(view).tolist() for view in x[i]],
            "distance": distances[i].tolist(),
            "native_side": 0,
            "torch_side": 1,
            "expected": 0.0,  # Schema/input validation placeholder, never emitted as a prediction.
        }
        validate_row(row)
        rows.append(row)
    np.savez(
        output / "fixed-inputs.npz",
        records=records,
        features=x,
        distances=distances,
        torch_side=side,
    )
    receipt["geometry"] = {
        "pure_QF1_rows": 16,
        "independent_scalar_oracle_rows": 16,
        "native_geometry_library_calls": 0,
        "native_evaluator_calls": 0,
    }
    receipt["phase"] = "Torch_checkpoint_loading"
    import torch
    from quoridor_training.common import resolve_config
    from quoridor_training.train import build_model

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    fit = resolve_config(cfg["fit_config"])
    binding = json.loads(Path(cfg["input_binding"]).read_text())
    scale = json.loads(Path(binding["scale_artifact"]).read_text())
    torch.manual_seed(fit["training"]["seed"])
    model = build_model(fit["model"], scale).eval()
    checkpoint = torch.load(cfg["checkpoint"], map_location="cpu", weights_only=True)
    if (
        checkpoint["model_config"] != fit["model"]
        or checkpoint["dataset_sha"] != binding["cache_manifest_sha"]
        or checkpoint["target"] != "z"
        or checkpoint["position"] != cfg["position"]
        or any(checkpoint["scale"][k] != scale[k] for k in ("mu_f32", "sigma_f32"))
    ):
        raise ValueError("trained BEST51 model/config/data/scale/position")
    model.load_state_dict(checkpoint["model"], strict=True)
    parameters = np.concatenate(
        [
            v.detach().numpy().astype("<f4").ravel()
            for v in (
                model.ft.weight,
                model.ft.bias,
                model.h.weight,
                model.h.bias,
                model.out.weight,
                model.out.bias,
            )
        ]
    )
    if hashlib.sha256(parameters.tobytes()).hexdigest() != cfg["weights_SHA"]:
        raise ValueError("trained parameters byte identity before forward")
    counter = receipt["counts"]["Torch"]

    def attempted(module, inputs):
        if counter["attempted_invocations"] >= 16 or tuple(inputs[0].shape) != (1, 2, 312):
            raise ValueError("finite16batch1 invocation boundary")
        _attempt(counter, 1)

    def returned(module, inputs, result):
        _returned(counter, 1)

    before = model.register_forward_pre_hook(attempted)
    after = model.register_forward_hook(returned)
    receipt["phase"] = "fixed16_Torch_forward"
    try:
        with torch.inference_mode():
            for i, row in enumerate(rows):
                prediction = model(
                    torch.from_numpy(x[i : i + 1]),
                    torch.from_numpy(distances[i : i + 1]),
                    torch.from_numpy(side[i : i + 1]),
                )
                if prediction.dtype != torch.float32 or tuple(prediction.shape) != (1,):
                    raise ValueError("Torch FP32 batch1 output")
                row["expected"] = float(prediction.numpy()[0])
                validate_row(row)
                _completed(counter, 1)
    finally:
        before.remove()
        after.remove()
    if any(
        counter[k] != 16
        for k in (
            "attempted_invocations",
            "returned_invocations",
            "completed_validated_invocations",
            "attempted_rows",
            "returned_rows",
            "completed_validated_rows",
        )
    ):
        raise ValueError("exact16 completed Torch accounting")
    receipt["phase"] = "strict_packet_persistence"
    packet = {
        "schema": "native-residual-reference-v1",
        "manifest_sha256": cfg["manifest_SHA"],
        "weights_sha256": cfg["weights_SHA"],
        "reference_source_sha256": sha(__file__),
        "rows": rows,
    }
    data = (json.dumps(packet, indent=2, allow_nan=False) + "\n").encode()
    if len(data) > 65536:
        raise ValueError("consumer packet64KiB limit")
    with (output / "native-reference-v1.json").open("xb") as stream:
        stream.write(data)
    companion = {
        "config": cfg,
        "raw16_records_SHA": hashlib.sha256(raw).hexdigest(),
        "packet_SHA256": hashlib.sha256(data).hexdigest(),
        "expected_definition": "CPU FP32 trained DistanceResidualModel: tanh(fixedD a0+b8*(opponentD-STM D)+linear residual); torch_side1/native_side0; no reflection; original input",
        "Torch_version": torch.__version__,
        "Torch_threads": torch.get_num_threads(),
        "source": sha(__file__),
        "native_predictions_used": False,
        "history": "UNKNOWN; original row geometry only, no fabricated Position/history",
        "labels": "existing originalV z qualifier only; no MSE or selection",
        "timing": "finite reference generation costs, not an inference benchmark",
    }
    (output / "binding-companion.json").write_text(
        json.dumps(companion, indent=2, allow_nan=False) + "\n"
    )
    receipt.update(
        status="PASS_FIXED16",
        phase="COMPLETED",
        packet_SHA256=companion["packet_SHA256"],
        packet_bytes=len(data),
    )


def main():
    receipt = {
        "status": "STARTED",
        "phase": "configuration",
        "counts": {"Torch": _counter()},
        "geometry": "NOT_STARTED",
        "forbidden_warmup_export_ORT_fit_gradient_fullV_MSE": 0,
    }
    output, primary = None, None
    started = time.monotonic()
    try:
        cfg = json.loads(Path(sys.argv[1]).read_text())
        output = Path(cfg["output"])
        output.mkdir(exist_ok=False)
        run(cfg, receipt, output)
    except BaseException as error:
        primary = error
        raise
    finally:
        receipt["whole_worker_seconds"] = time.monotonic() - started
        _finalize_reference(receipt, output, primary, [])


if __name__ == "__main__":
    main()
