"""Finite330 entry using accepted process ownership and finalization helpers."""

import hashlib
import json
import os
from pathlib import Path
import sys
import time

from quoridor_training import cycle_process as process
from quoridor_training.sigma_reference import _error_fact, _finalize_reference
from quoridor_training.sigma_reference_control import named_physics


class CPUResources(process.CycleResources):
    def __init__(self, guard, root):
        super().__init__(guard, root, None)
        self.controller_reserve = 64 * 1024**2
        self.observed = {"sampled_family_RSS_with_controller_B": 0}

    def check(self, owned=()):
        super().check(owned)
        infos = [
            process.process_info(os.getpid()),
            *(process.process_info(x["pid"]) for x in owned),
        ]
        rss = sum(x["rss"] for x in infos if x) + self.controller_reserve
        self.observed["sampled_family_RSS_with_controller_B"] = max(
            self.observed["sampled_family_RSS_with_controller_B"], rss
        )
        if rss > self.memory_limit:
            raise process.CycleStopped("CPU family2GiB including controller")


def main():
    result = {
        "status": "STARTED",
        "phase": "configuration",
        "counts": {},
        "child_process": "NOT_STARTED",
    }
    output, primary = None, None
    secondary = []
    started = time.monotonic()
    try:
        with process.cancellation_signals():
            guard = json.loads(Path(sys.argv[1]).read_text())
            if guard["issue"] != "quoridor-4lc.330" or guard["goal_issue"] != "quoridor-4lc":
                raise ValueError("330 owner/goal binding")
            os.sched_setaffinity(0, {2, 3})
            for path, expected in guard["expected_files_sha256"].items():
                if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
                    raise ValueError("330 fixed binding changed: " + path)
            result["phase"] = "fresh_physics"
            physics = named_physics()
            result["physics"] = physics
            if (
                physics["named_foreign_science"]
                or physics["MemAvailable_after_cgroup_bytes"] < 3 * 1024**3
            ):
                raise process.CycleStopped("330 actual namedquiet/RAM admission")
            root = Path(guard["phase_root"])
            output = Path(guard["entry_output"])
            output.mkdir(exist_ok=False)
            resources = CPUResources(guard, root)
            result["observed"] = resources.observed
            resources.check()
            result["phase"] = "fixture_child"
            process.LOG_MAX_BYTES = 8192
            record = process.execute(
                [sys.executable, "-B", guard["worker"], guard["config"]],
                output / "fixture.log",
                None,
                resources=resources,
            )
            result["child_process"] = record
            if (
                not record["cleanup_complete"]
                or not record["direct_child_reaped"]
                or record["remaining"]
                or process.alive(record["child"])
            ):
                raise process.CycleStopped("330 exact child cleanup")
            result["phase"] = "completed_receipt"
            child = json.loads((output / "fixture/reference-result.json").read_text())
            c = child["counts"]["Torch"]
            if child["status"] != "PASS_FIXED16" or any(
                c[k] != 16
                for k in (
                    "attempted_invocations",
                    "returned_invocations",
                    "completed_validated_invocations",
                    "attempted_rows",
                    "returned_rows",
                    "completed_validated_rows",
                )
            ):
                raise ValueError("330 finite16 outcome not qualified")
            resources.check()
            result.update(status="PASS_GUARD_FIXED16", phase="COMPLETED", worker_receipt=child)
    except BaseException as error:
        primary = error
        raise
    finally:
        if output is not None and result["phase"] == "fixture_child":
            path = output / "fixture.process.json"
            try:
                if path.exists():
                    result["child_process"] = json.loads(path.read_text())
                else:
                    result["child_process"] = "NOT_RECORDED; cleanup success not inferred"
            except BaseException as error:
                secondary.append(("child_receipt_read", error))
                result["child_receipt_error"] = _error_fact(error)
        result["whole_guard_seconds"] = time.monotonic() - started
        _finalize_reference(result, output, primary, [], secondary)


if __name__ == "__main__":
    main()
