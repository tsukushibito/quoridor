"""Only new C01-C05 synthetic saved-control/main ports; no native execution."""

from contextlib import ExitStack
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
PROGRESS = []


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def put(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj) + "\n")
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def refuses(action):
    try:
        action()
    except (ValueError, KeyError, TypeError, RuntimeError):
        return
    raise AssertionError("expected refusal")


def log_main_port(W, E, forecast):
    origin, fault, failures = None, "none", ()
    with tempfile.TemporaryDirectory(dir=HERE / "ports-tmp-v23") as temp:
        root = Path(temp)
        out = root / "control"
        tmp = root / "tmp"
        n = root / "native"
        n.mkdir()
        put(n / "manifest-start.json", {"synthetic": True})
        put(
            n / "result.json",
            {
                "planned": 16,
                "outcomes": [
                    {"game": g, "status": "unknown", "observations": []} for g in range(16)
                ],
            },
        )
        if fault == "malformed_result":
            (n / "result.json").write_text("{partial")
            (n / "completed.jsonl").write_text(
                json.dumps(
                    {"game": 0, "status": "unknown", "failure": "illegal_move", "observations": []}
                )
                + "\n{partial"
            )
        prior = root / "prior.json"
        put(prior, [])
        f = root / "forecast.json"
        put(f, forecast)
        cmds = [[name, ["synthetic-native", name]] for name in ("arena", "audit", "recover")]
        adm = {
            "role": "D",
            "actual_entry": True,
            "prepared_only": False,
            "pending_obligations": [],
            "required_imports": W.REQUIRED_IMPORTS,
            "bindings": {},
            "helper": "synthetic-guard",
            "evidence_helper": "synthetic-evidence",
            "whole_forecast": str(f),
            "output": str(out),
            "native_output": str(n),
            "TMP": str(tmp),
            "prior_charges": str(prior),
            "environment": {},
            "native_log_max_bytes": 8 * 1024**2,
            "commands": cmds,
        }
        adm["bindings"] = {
            p: {} for p in [adm["helper"], adm["evidence_helper"], *W.REQUIRED_IMPORTS]
        }
        ap = root / "admission.json"
        raw = json.dumps(adm).encode()
        ap.write_bytes(raw)
        executed = []
        final = []
        pins = {0, 2}
        physical_calls = []

        def affinity(pid, cpus):
            nonlocal pins
            pins = set(cpus)

        def physical():
            assert pins == {0, 2}
            physical_calls.append(set(pins))

        class Lease:
            def close(self):
                final.append("lock_close")
                if "lock_close" in failures:
                    raise OSError("synthetic lease close")

        class Base:
            def __init__(self, config, output, deadline):
                self.memory_limit = config["max_memory_bytes"]

            def check(self, owned=()):
                if len(executed) == 3 and "final_resources" in failures:
                    raise OSError("synthetic final resource")

        def execute(argv, log, deadline, **kwargs):
            assert pins == {2} and kwargs["cpu_core"] == 0
            assert package.cycle_process.LOG_MAX_BYTES == 8 * 1024**2
            executed.append(argv[-1])
            r = {
                "command": argv,
                "exit_code": 1 if origin == argv[-1] else 0,
                "direct_child_reaped": True,
                "cleanup_complete": True,
                "remaining": [],
                "log_bytes_seen": 2 * 1024**2,
                "log_bytes_retained": 2 * 1024**2,
                "finalization_errors": [],
                "handle_closes_complete": True,
                "process_cleanup_complete": True,
                "signal_mask_restoration": "completed",
                "final_record_persist": "completed",
            }
            put(log.with_suffix(".process.json"), r)
            if "receipt" in failures and argv[-1] == "recover":
                log.with_suffix(".process.json").write_text("[1]")
            return r

        def write(path, data):
            name = {
                "held-charges.json": "held_charges",
                "cohort-result.json": "result",
            }[path.name]
            final.append(name)
            if name in failures:
                raise OSError("synthetic " + name)
            put(path, data)

        def verify(*args):
            if len(executed) == 3 and "source_after" in failures:
                raise OSError("synthetic source after")

        def rmdir(path):
            if path == tmp and "owned_empty_TMP" in failures:
                final.append("owned_empty_TMP")
                raise OSError("synthetic TMP")
            return real_rmdir(path)

        def diagnostic(*args, **kwargs):
            final.append("diagnostic")
            if "diagnostic" in failures:
                raise OSError("synthetic diagnostic")

        package = ModuleType("quoridor_training")
        package.__path__ = []
        package.cycle_process = SimpleNamespace(
            LOG_MAX_BYTES=1024**2,
            CycleResources=Base,
            execute=execute,
            process_info=lambda pid: {"rss": 0},
            CycleStopped=RuntimeError,
        )
        snapshot = ModuleType("quoridor_training.snapshot")
        snapshot.write_json = write
        guard = SimpleNamespace(
            quiet=lambda: None,
            physical=physical,
            sha=lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest(),
        )
        fakeE = SimpleNamespace(
            BASELINE=prior,
            ledger=lambda rows, *args: {
                (r["component"], r["path"]): r["maximum_sampled_allocated_B"] for r in rows
            },
            rows=E.rows,
            saved_census=E.saved_census,
        )
        real_rmdir = Path.rmdir
        error = None
        real_methods = {key: getattr(Path, key) for key in ("is_file", "is_symlink", "exists")}
        targets = {
            "manifest_is_file": (n / "manifest-start.json", "is_file"),
            "manifest_is_symlink": (n / "manifest-start.json", "is_symlink"),
            "result_is_file": (n / "result.json", "is_file"),
            "result_is_symlink": (n / "result.json", "is_symlink"),
            "TMP_exists": (tmp, "exists"),
        }

        def method(key):
            def checked(path):
                if fault in targets and targets[fault] == (path, key):
                    raise OSError(5, "synthetic availability EIO " + fault)
                return real_methods[key](path)

            return checked

        with ExitStack() as stack:
            for obj, key, value in [
                (sys, "argv", ["port", str(ap), hashlib.sha256(raw).hexdigest()]),
                (W, "review_and_fixed_proofs", lambda *args: None),
                (W, "validate", lambda *args: None),
                (W, "verify", verify),
                (W, "LOCK", SimpleNamespace(open=lambda mode: Lease())),
                (
                    W,
                    "fcntl",
                    SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *args: None),
                ),
                (W.os, "sched_setaffinity", affinity),
                (W.os, "sched_getaffinity", lambda pid: set(pins)),
                (
                    W.importlib.util,
                    "spec_from_file_location",
                    lambda name, path: SimpleNamespace(
                        name=name, loader=SimpleNamespace(exec_module=lambda m: None)
                    ),
                ),
                (
                    W.importlib.util,
                    "module_from_spec",
                    lambda spec: fakeE if spec.name == "cohort_evidence" else guard,
                ),
                (Path, "rmdir", rmdir),
            ]:
                stack.enter_context(patch.object(obj, key, value))
            for key in real_methods:
                stack.enter_context(patch.object(Path, key, method(key)))
            stack.enter_context(
                patch.dict(
                    sys.modules,
                    {
                        "quoridor_training": package,
                        "quoridor_training.snapshot": snapshot,
                    },
                )
            )
            stack.enter_context(patch.dict(W.os.environ, {}, clear=False))
            stack.enter_context(patch("builtins.print", diagnostic))
            try:
                W.main()
            except BaseException as err:
                error = err
        assert executed == ["arena", "audit", "recover"]
        assert error is None and final[-1] == "lock_close"
        assert pins == {2} and physical_calls == [{0, 2}] * 4
        saved = json.loads((out / "cohort-result.json").read_text())
        assert saved["provisional_only"] and not saved["external_controller_acceptance"]
        assert saved["stage_failures"] == [] and saved["slot_census"]["planned_ids"] == list(
            range(16)
        )


def run(W, E):
    passed = PROGRESS

    def refuse(action):
        try:
            action()
        except ValueError:
            return
        raise AssertionError("Expected saved chronology refusal")

    def move(receipt, drain, start=0):
        return {
            "caller_started_ns": start,
            "deadline_ns": start + 100000000,
            "action": 13,
            "accepted": True,
            "failure": None,
            "engine_index": 0,
            "counters": {
                "clock_contract": W.CLOCK,
                "clock_contract_sha256": W.CLOCK_SHA,
                "authority_receipt_ns": receipt,
                "drain_finished_ns": drain,
                "immutable_chosen_action": 13,
                "authority_legal": True,
                "terminal_request_error": None,
                "inflight_after_drain": 0,
                "measurement_mode": None,
                "measurement_call_limit": None,
                "cost_qualification_usable_after_drain": True,
            },
        }

    def report(moves):
        return {"outcomes": [{"game": 0, "status": "goal", "observations": moves}]}

    for name, moves, valid in (
        ("drain precedes authority receipt", [move(90, 85)], True),
        ("authority receipt precedes drain", [move(85, 90)], True),
        ("next caller after both when drain first", [move(90, 85), move(200, 195, 100)], True),
        (
            "next caller before authority after drain refuses",
            [move(90, 85), move(200, 195, 87)],
            False,
        ),
        (
            "next caller before drain after authority refuses",
            [move(85, 90), move(200, 195, 87)],
            False,
        ),
        ("receipt before caller refuses", [move(99, 120, 100)], False),
        ("drain before caller refuses", [move(120, 99, 100)], False),
        ("accepted late receipt refuses even if drain timely", [move(100000000, 95)], False),
        ("missing drain refuses", [move(90, None)], False),
        ("boolean receipt refuses", [move(True, 90)], False),
    ):
        if valid:
            result = W.clock_census(report(moves))
            assert result["accepted"] == len(moves)
        else:
            refuse(lambda: W.clock_census(report(moves)))
        passed.append("saved receipt/drain source-contract case " + name)
    command = ["synthetic-native", "audit"]
    r = {
        "command": command,
        "exit_code": 0,
        "direct_child_reaped": True,
        "cleanup_complete": True,
        "remaining": [],
        "process_cleanup_complete": True,
        "handle_closes_complete": True,
        "finalization_errors": [],
        "log_bytes_seen": 2013385,
        "log_bytes_retained": 1048576,
    }
    assert W.receipt_cleanup_ok(r, command) and not W.receipt_ok(r, command)
    passed.append(
        "truncated stdout retains directwait cleanup independently but refuses full-log qualification"
    )
    for name, change in (
        ("handle close unknown", {"handle_closes_complete": False}),
        ("process cleanup unknown", {"process_cleanup_complete": False}),
        ("finalization error", {"finalization_errors": [{"stage": "close"}]}),
    ):
        changed = {**r, **change}
        assert not W.receipt_cleanup_ok(changed, command)
        passed.append("separate cleanup still refuses " + name)
    with tempfile.TemporaryDirectory(dir=HERE / "ports-tmp-v23"):
        log_main_port(
            W,
            E,
            json.loads((HERE.parent / "cohort-repair-v18/whole-forecast-v18.json").read_text()),
        )
    passed.append(
        "actual-main per-process canonical log8MiB configured before three fake2MiB returns; no native child"
    )
    return {
        "passed_new_cases": passed,
        "count": len(passed),
        "old45_plus23_plus9_successes_replayed": False,
        "actual_native_Cargo_backend_model_Search_geometry_game_replays": 0,
    }
