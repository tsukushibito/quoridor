"""Focused new metadata acceptance ports; no production import or Popen."""

import ast
import copy
import json
from pathlib import Path
import resource
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "materialization-v2/software_worker.py"


def main():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    module = ast.parse(SOURCE.read_text())
    function = next(
        n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == "main"
    )
    block = next(
        n
        for n in ast.walk(function)
        if isinstance(n, ast.Try)
        and any(
            isinstance(x, ast.For) and ast.unparse(x.target) == "command"
            for x in n.body
        )
    )
    first = next(
        i
        for i, n in enumerate(block.body)
        if ast.unparse(n).startswith("binding_records = []")
    )
    collector = compile(
        ast.fix_missing_locations(ast.Module(body=block.body[first:], type_ignores=[])),
        str(SOURCE),
        "exec",
    )
    private = "e" * 64
    configs = {
        role: {"path": "/fake/" + role, "SHA256": sha * 64}
        for role, sha in [("d", "a"), ("nnue", "b")]
    }
    admission = {
        "commands": [
            {"name": "bindings-" + r, "argv": ["fake"]} for r in ("d", "nnue")
        ],
        "cohort_configs": configs,
    }
    records = {
        role: {
            "schema": "quoridor-sigma-cost-bindings-v1",
            "backend_loaded": False,
            "model_calls": 0,
            "cost_qualification": None,
            "config_file": {"path": v["path"], "sha256": v["SHA256"]},
            "executable_sha256": private,
            "normalized_config_sha256": "c" * 64,
            "compiled_sources_sha256": "d" * 64,
            "compiled_sources": {"owned_source": "f" * 64},
        }
        for role, v in configs.items()
    }

    def run(mutate=None):
        data = copy.deepcopy(records)
        if mutate:
            mutate(data)
        saved = []
        result = {"private": {"SHA256": private}, "completed_commands": []}
        ports = {
            "admission": admission,
            "result": result,
            "json": json,
            "output": Path("/fake-output"),
            "execute": lambda name, argv: json.dumps(
                data[name.removeprefix("bindings-")]
            ),
            "write_json": lambda path, value: saved.append((str(path), value)),
        }
        exec(collector, ports)
        assert len(saved) == len(result["completed_commands"]) == 2

    start = time.monotonic()
    run()
    mutations = [
        (
            "wrong_raw_config_digest",
            lambda d: d["d"]["config_file"].update(sha256="0" * 64),
        ),
        ("wrong_private", lambda d: d["d"].update(executable_sha256="0" * 64)),
        ("backend_loaded", lambda d: d["d"].update(backend_loaded=True)),
        ("nonzero_model_calls", lambda d: d["d"].update(model_calls=1)),
        ("malformed_bool_calls", lambda d: d["d"].update(model_calls=False)),
        (
            "nonhex_normalized_digest",
            lambda d: d["d"].update(normalized_config_sha256="g" * 64),
        ),
        (
            "mixed_compiled_sources",
            lambda d: d["nnue"]["compiled_sources"].update(owned_source="0" * 64),
        ),
    ]
    passed = ["exact_two_typed_bindings"]
    for name, mutate in mutations:
        try:
            run(mutate)
        except (ValueError, KeyError):
            passed.append(name)
        else:
            raise AssertionError("refusal missing: " + name)
    expression = next(
        n.value
        for n in ast.walk(function)
        if isinstance(n, ast.Assign)
        and len(n.targets) == 1
        and ast.unparse(n.targets[0]) == "result['qualified']"
        and "len(receipts)" in ast.unparse(n.value)
    )
    census = compile(
        ast.fix_missing_locations(ast.Expression(expression)), str(SOURCE), "eval"
    )
    assert (
        eval(
            census,
            {"primary": None, "errors": [], "unknown": False, "receipts": [1, 2]},
        )
        is True
    )
    for values in [
        {"primary": None, "errors": [], "unknown": False, "receipts": [1]},
        {"primary": None, "errors": [], "unknown": False, "receipts": [1, 2, 3]},
        {
            "primary": ValueError("primary"),
            "errors": [],
            "unknown": False,
            "receipts": [1, 2],
        },
        {"primary": None, "errors": [], "unknown": True, "receipts": [1, 2]},
    ]:
        assert eval(census, values) is False
    print(
        json.dumps(
            {
                "new_metadata_ports": passed,
                "new_exact2_census": "PASS exact2/missing1/extra1/primary/unknown",
                "internal_s": time.monotonic() - start,
                "VmHWM_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                "real_external_children_private_backend_model_calls": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
