"""Only new C01-C05 synthetic saved-control/main ports; no native execution."""

from contextlib import ExitStack
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
PROGRESS = []


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def put(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj) + "\n")
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def refuses(action):
    try:
        action()
    except (ValueError, KeyError, TypeError, RuntimeError):
        return
    raise AssertionError("expected refusal")


def run(W, E, skip=()):
    cases = []

    def case(name, action):
        if name in skip:
            return
        action()
        cases.append(name)
        PROGRESS.append(name)

    with tempfile.TemporaryDirectory(dir=HERE / "ports-tmp-v17") as temporary:
        T = Path(temporary)
        baseline = json.loads(E.BASELINE.read_bytes())
        forecast = json.loads(
            (HERE.parent / "cohort-control-v15/whole-forecast-v15.json").read_bytes()
        )
        case(
            "C03 real retained metadata baseline and original joint/whole support",
            lambda: E.ledger(baseline, forecast, baseline),
        )
        for name, alter in [
            ("negative maximum", lambda rows: rows[0].update(maximum_sampled_allocated_B=-1)),
            ("boolean maximum", lambda rows: rows[0].update(maximum_sampled_allocated_B=True)),
            (
                "duplicate alternative classification",
                lambda rows: rows.append({**rows[0], "component": "D"}),
            ),
            ("erased retained baseline", lambda rows: rows.pop()),
            ("foreign named path", lambda rows: rows[0].update(path="/foreign/unsupported")),
            (
                "component overflow",
                lambda rows: rows.append(
                    {
                        "component": "D",
                        "path": str(T / "overflow"),
                        "maximum_sampled_allocated_B": 268435457,
                    }
                ),
            ),
            (
                "whole overflow",
                lambda rows: rows.append(
                    {
                        "component": "D",
                        "path": str(T / "whole"),
                        "maximum_sampled_allocated_B": 4294967297,
                    }
                ),
            ),
            (
                "joint build overflow",
                lambda rows: rows.append(
                    {
                        "component": "target",
                        "path": str(T / "joint"),
                        "maximum_sampled_allocated_B": 1200000000,
                    }
                ),
            ),
        ]:

            def check(alter=alter):
                rows = copy.deepcopy(baseline)
                alter(rows)
                refuses(lambda: E.ledger(rows, forecast, baseline))

            case("C03 " + name, check)

        def growth():
            rows = copy.deepcopy(baseline)
            rows.append(
                {
                    "component": "TMP",
                    "path": str(T / "growth"),
                    "maximum_sampled_allocated_B": 536870913,
                }
            )
            refuses(lambda: E.ledger(rows, forecast, baseline))

        case("C03 observed new maximum beyond remaining component support", growth)

        review = T / "review.json"
        target = T / "target.json"
        fp = T / "forecast.json"
        ep = str(HERE / "cohort_evidence.py")
        wp = str(HERE / "cohort_worker.py")
        put(fp, forecast)
        a = {
            "source_review": {
                "control_path": str(review),
                "control_SHA256": None,
                "target_path": str(target),
                "target_SHA256": None,
                "reader_STOP": "synthetic-readerSTOP",
            },
            "bindings": copy.deepcopy(W.FIXED_PROOFS),
            "evidence_helper": ep,
            "whole_forecast": str(fp),
            "required_control_proofs": [],
        }
        for q in (Path(ep), Path(wp), fp):
            a["bindings"][str(q)] = E.record(q)
        target_obj = {
            "source_reader_writer_STOP": "synthetic-producerSTOP",
            "owned_readers_children_jobs_TMP_remaining": [],
            "required_proof_identities": W.FIXED_PROOFS,
            "selected_refs": {q: a["bindings"][q] for q in (wp, ep, str(fp))},
        }

        def review_fixture(change=None):
            t = copy.deepcopy(target_obj)
            c = {
                "control_clear": True,
                "blockers": 0,
                "ordinary": 0,
                "target_path": str(target),
                "target_binding_SHA256": None,
                "source_reader_STOP": "synthetic-readerSTOP",
                "producer_reader_writer_STOP": "synthetic-producerSTOP",
                "remaining_readers_writers_children_pending_direct_waits_cleanup_TMP": [],
            }
            if change:
                change(c, t)
            put(target, t)
            c["target_binding_SHA256"] = E.record(target)["SHA256"]
            put(review, c)
            b = copy.deepcopy(a)
            b["bindings"].update({str(target): E.record(target), str(review): E.record(review)})
            b["source_review"].update(
                control_SHA256=E.record(review)["SHA256"], target_SHA256=E.record(target)["SHA256"]
            )
            return b

        with patch.object(W, "verify", lambda *args: None):
            case(
                "C02 actual matching stopped verdict with fixed prerequisite enforcement",
                lambda: W.review_and_fixed_proofs(review_fixture()),
            )
            changes = [
                (
                    "bound blocked certificate",
                    lambda c, t: c.update(control_clear=False, blockers=1),
                ),
                ("wrong STOP", lambda c, t: c.update(source_reader_STOP="wrong")),
                (
                    "remaining reader",
                    lambda c, t: c.update(
                        remaining_readers_writers_children_pending_direct_waits_cleanup_TMP=[1]
                    ),
                ),
                ("stale target worker", lambda c, t: t["selected_refs"][wp].update(SHA256="wrong")),
                (
                    "erased target prerequisite identities",
                    lambda c, t: t.update(required_proof_identities={}),
                ),
            ]
            for name, change in changes:
                case(
                    "C02 " + name,
                    lambda change=change: refuses(
                        lambda: W.review_and_fixed_proofs(review_fixture(change))
                    ),
                )

            def erased():
                b = review_fixture()
                b["bindings"].pop(next(iter(W.FIXED_PROOFS)))
                refuses(lambda: W.review_and_fixed_proofs(b))

            case("C02 empty caller list cannot erase fixed proof membership", erased)

        def completion_fixture(change=None):
            directory = T / "completion"
            directory.mkdir(exist_ok=True)
            native = directory / "native"
            control_out = directory / "guardian"
            runtime = directory / "runtime"
            for d in (native, control_out, runtime):
                d.mkdir(exist_ok=True)
            dc = directory / "config-d.json"
            packet = directory / "packet.json"
            plan = directory / "plan.json"
            private = directory / "synthetic-private"
            private.write_bytes(b"not executable; synthetic metadata")
            cfg = {"run_id": "synthetic-D", "output": str(native)}
            early = {
                "cohorts": {
                    "D": {
                        "normalized_config_sha256": "synthetic-normalized",
                        "slots": [{"prefix": [], "color_index": g % 2} for g in range(16)],
                    }
                }
            }
            put(dc, cfg)
            put(packet, {"synthetic": "packet"})
            put(plan, early)
            bindings = {str(q): E.record(q) for q in (dc, packet, plan, private)}
            admission_path = directory / "admission.json"
            admission = {
                "role": "D",
                "actual_entry": True,
                "prepared_only": False,
                "pending_obligations": [],
                "config": str(dc),
                "private": str(private),
                "packet": str(packet),
                "plan": str(plan),
                "bindings": copy.deepcopy(bindings),
                "output": str(control_out),
                "native_output": str(native),
            }
            commands = [
                [
                    str(private),
                    "arena",
                    "--config",
                    str(dc),
                    "--sigma-cost-qualification",
                    str(packet),
                    "--qualification-sha256",
                    bindings[str(packet)]["SHA256"],
                ],
                [str(private), "arena", "--audit", str(native)],
                [str(private), "arena", "--recover", str(native)],
            ]
            outcomes = [
                {"game": g, "status": "unknown", "observations": [], "failure": "ply_cap"}
                for g in range(16)
            ]
            report = {"run_id": "synthetic-D", "planned": 16, "outcomes": outcomes}
            census = W.clock_census(report)
            planned = [{"game": g, "opening": [], "candidate_color": g % 2} for g in range(16)]
            attempts = []
            receipts = []
            native_rows = {}
            for i, name in enumerate(("arena", "audit", "recover")):
                path = control_out / (name + ".process.json")
                entry = {"name": name, "command": commands[i], "receipt": str(path)}
                row = {
                    "command": commands[i],
                    "exit_code": 0,
                    "direct_child_reaped": True,
                    "cleanup_complete": True,
                    "remaining": [],
                    "process_cleanup_complete": True,
                    "handle_closes_complete": True,
                    "finalization_errors": [],
                    "log_bytes_seen": 1,
                    "log_bytes_retained": 1,
                    "child": {"pid": 99999901 + i, "start_ticks": "1", "boot_id": "synthetic-boot"},
                    "signal_mask_restoration": "pending",
                    "final_record_persist": "attempted",
                }
                attempts.append(entry)
                native_rows[name + "_receipt"] = row
                receipts.append({"attempt": entry, "receipt": row, "verified": True})
            guardian = {
                "role": "D",
                "provisional_only": True,
                "external_controller_acceptance": False,
                "primary_error": None,
                "stage_failures": [],
                "native_process_cleanup_complete": True,
                "native_process_cleanup_unknown": False,
                "source_STOP": "2026-10-09T08:00:01+00:00",
                "attempted_children": attempts,
                "receipts": receipts,
                "clock_census": census,
                "returned_process_finalization": {
                    n: {
                        "signal_mask_restoration": "completed",
                        "final_record_persist": "completed",
                        "handle_closes_complete": True,
                        "process_cleanup_complete": True,
                    }
                    for n in ("arena", "audit", "recover")
                },
            }
            state = {
                "issue": "quoridor-4lc.347.3",
                "thread_id": E.THREAD,
                "job_id": "synthetic-job",
                "phase": "finished",
                "outcome": "succeeded",
                "started_at": "2026-10-09T08:00:00+00:00",
                "child": {"pid": 99999900, "start_ticks": "1", "boot_id": "synthetic-boot"},
            }
            controller = {
                "job_id": "synthetic-job",
                "outcome": "succeeded",
                "error": None,
                "exit_code": 0,
                "direct_child_reaped": True,
                "cleanup_complete": True,
                "remaining": [],
                "cleanup_errors": [],
                "descendant_visibility": "observed",
                "log_bytes_seen": 0,
                "log_bytes_retained": 0,
                "finished_at": "2026-10-09T08:00:02+00:00",
            }
            objects = {
                "admission": admission,
                "guardian": guardian,
                "state": state,
                "controller": controller,
                "report": report,
                "planned": planned,
                "held_charges": [],
                **native_rows,
            }
            if change:
                change(objects)
            refs = {}
            paths = {
                "admission": admission_path,
                "guardian": control_out / "cohort-result.json",
                "state": runtime / "state.json",
                "controller": runtime / "result.json",
                "report": native / "result.json",
                "planned": native / "planned.json",
                "held_charges": control_out / "held-charges.json",
                **{
                    n + "_receipt": control_out / (n + ".process.json")
                    for n in ("arena", "audit", "recover")
                },
            }
            for k in (
                "admission",
                "guardian",
                "controller",
                "report",
                "planned",
                "arena_receipt",
                "audit_receipt",
                "recover_receipt",
                "held_charges",
            ):
                refs[k] = put(paths[k], objects[k])
                bindings[str(paths[k])] = E.record(paths[k])
            config = {
                "issue": "quoridor-4lc.347.3",
                "goal_issue": "quoridor-4lc.347",
                "thread_id": E.THREAD,
                "cwd": str(E.WT),
                "resource_contract": str(admission_path),
                "argv": [
                    "/usr/bin/python3.11",
                    "-B",
                    wp,
                    str(admission_path),
                    refs["admission"]["sha256"],
                ],
                "end_at": None,
                "notify_until": None,
                "max_runtime_seconds": None,
            }
            refs["config"] = put(runtime / "config.json", config)
            bindings[str(runtime / "config.json")] = E.record(runtime / "config.json")
            state["config_sha256"] = hashlib.sha256(
                json.dumps(config, sort_keys=True).encode()
            ).hexdigest()
            refs["state"] = put(paths["state"], state)
            bindings[str(paths["state"])] = E.record(paths["state"])
            manifest = {
                "binding": {
                    "config": cfg,
                    "config_sha256": "synthetic-normalized",
                    "planned_slots": planned,
                    "executable_sha256": bindings[str(private)]["SHA256"],
                },
                "result": objects["report"],
                "artifacts": {
                    n: {"sha256": refs[k]["sha256"], "bytes": bindings[refs[k]["path"]]["bytes"]}
                    for n, k in [("result.json", "report"), ("planned.json", "planned")]
                },
            }
            refs["manifest"] = put(native / "manifest.json", manifest)
            bindings[str(native / "manifest.json")] = E.record(native / "manifest.json")
            bundle = {"schema": "quoridor-cohort-completion-input-v1", "references": refs}
            return bundle, {"bindings": bindings}, (dc, private, packet, plan)

        def derived(change=None):
            bundle, b, paths = completion_fixture(change)
            with patch.multiple(
                E, D_CONFIG=paths[0], PRIVATE=paths[1], PACKET=paths[2], PLAN=paths[3]
            ):
                return E.completed_d(bundle, b, W.clock_census)

        def completed_ledger():
            bundle, a, paths = completion_fixture()
            with patch.multiple(
                E, D_CONFIG=paths[0], PRIVATE=paths[1], PACKET=paths[2], PLAN=paths[3]
            ):
                d = E.completed_d(bundle, a, W.clock_census)
            a["prior_charges"] = d["held_charges"]["path"]
            assert E.preceding_ledger(d, a) == []

        case(
            "C01/C03 completed D ledger re-derived and consumed for next baseline", completed_ledger
        )

        def wrong_ledger():
            bundle, a, paths = completion_fixture()
            with patch.multiple(
                E, D_CONFIG=paths[0], PRIVATE=paths[1], PACKET=paths[2], PLAN=paths[3]
            ):
                d = E.completed_d(bundle, a, W.clock_census)
            a["prior_charges"] = "erased-D-ledger"
            refuses(lambda: E.preceding_ledger(d, a))

        case("C01/C03 replacing completed D ledger with old baseline refuses", wrong_ledger)

        def legitimate():
            d = derived()
            assert d["slot_census"]["typed_observed_status"] == {"unknown": 16}
            assert d["clock_census"]["cost_disproved"] == 0

        case(
            "C01 matching successful external pipeline with all legitimate UNKNOWN outcomes",
            legitimate,
        )
        for name, change in [
            ("failed controller", lambda o: o["controller"].update(outcome="failed", exit_code=1)),
            ("cleanup unknown", lambda o: o["controller"].update(cleanup_complete=False)),
            ("wrong job", lambda o: o["state"].update(job_id="wrong")),
            ("wrong D admission config", lambda o: o["admission"].update(config="wrong")),
            (
                "hand positive guardian declaration",
                lambda o: o["guardian"].update(external_controller_acceptance=True),
            ),
            ("wrong planned color", lambda o: o["planned"][0].update(candidate_color=1)),
            ("wrong report", lambda o: o["report"].update(run_id="wrong")),
            (
                "D private identity mismatch",
                lambda o: o["admission"]["bindings"][
                    str(T / "completion/synthetic-private")
                ].update(SHA256="wrong"),
            ),
            ("failed direct receipt", lambda o: o["audit_receipt"].update(exit_code=1)),
        ]:
            case("C01 " + name, lambda change=change: refuses(lambda: derived(change)))
        case(
            "C01 positive boolean without raw evidence refuses",
            lambda: refuses(
                lambda: E.completed_d(
                    {
                        "external_controller_acceptance": True,
                        "role": "D",
                        "clock_census": {"cost_disproved": 0},
                    },
                    {"bindings": {}},
                    W.clock_census,
                )
            ),
        )

        def disproved(o):
            o["report"]["outcomes"][0]["observations"] = [
                {
                    "caller_started_ns": 0,
                    "deadline_ns": 100000000,
                    "action": None,
                    "accepted": False,
                    "failure": "cost_unqualified",
                    "engine_index": 0,
                    "counters": {
                        "clock_contract": W.CLOCK,
                        "clock_contract_sha256": W.CLOCK_SHA,
                        "authority_receipt_ns": 1,
                        "drain_finished_ns": 2,
                        "measurement_mode": None,
                        "measurement_call_limit": None,
                        "inflight_after_drain": 0,
                        "cost_qualification_usable_after_drain": False,
                    },
                }
            ]
            o["guardian"]["clock_census"] = W.clock_census(o["report"])

        case(
            "C01 completed D with disproved cost refuses NNUE",
            lambda: refuses(lambda: derived(disproved)),
        )
        native = T / "partial"
        native.mkdir()
        put(native / "manifest-start.json", {"synthetic": True})
        outcomes = [
            {"game": 0, "status": "unknown", "failure": "illegal_move", "observations": []},
            {"game": 3, "status": "unknown", "failure": "time_overrun", "observations": []},
        ]
        (native / "completed.jsonl").write_bytes(
            b"".join(json.dumps(x).encode() + b"\n" for x in outcomes) + b"{partial"
        )

        def partial():
            c = E.saved_census(native)
            assert (
                c["observed_ids"] == [0, 3]
                and len(c["missing_ids"]) == 14
                and c["partial_journal_tail"]
                and c["incomplete_pairs"] == 8
            )

        case(
            "C04 truncated journal preserves16 IDs, missing pairs and typed illegal/late UNKNOWN",
            partial,
        )
        case(
            "C04 absent output preserves all16 missing as UNKNOWN without start inference",
            lambda: E.saved_census(T / "absent"),
        )
        # Actual-main ports below mock native interfaces only, exercising every finalizer.
        for origin, failures in [
            (None, ()),
            ("arena", ()),
            ("audit", ()),
            (None, ("source_after",)),
            (None, ("final_resources",)),
            (None, ("receipt",)),
            (None, ("held_charges",)),
            (None, ("owned_empty_TMP",)),
            (None, ("result",)),
            (None, ("diagnostic",)),
            (None, ("lock_close",)),
            ("audit", ("held_charges", "result", "diagnostic", "lock_close")),
        ]:

            def main_port(origin=origin, failures=failures):
                with tempfile.TemporaryDirectory(dir=HERE / "ports-tmp-v17") as temp:
                    root = Path(temp)
                    out = root / "control"
                    tmp = root / "tmp"
                    n = root / "native"
                    n.mkdir()
                    put(n / "manifest-start.json", {"synthetic": True})
                    put(
                        n / "result.json",
                        {
                            "planned": 16,
                            "outcomes": [
                                {"game": g, "status": "unknown", "observations": []}
                                for g in range(16)
                            ],
                        },
                    )
                    prior = root / "prior.json"
                    put(prior, [])
                    f = root / "forecast.json"
                    put(f, forecast)
                    cmds = [
                        [name, ["synthetic-native", name]] for name in ("arena", "audit", "recover")
                    ]
                    adm = {
                        "role": "D",
                        "actual_entry": True,
                        "prepared_only": False,
                        "pending_obligations": [],
                        "required_imports": W.REQUIRED_IMPORTS,
                        "bindings": {},
                        "helper": "synthetic-guard",
                        "evidence_helper": "synthetic-evidence",
                        "whole_forecast": str(f),
                        "output": str(out),
                        "native_output": str(n),
                        "TMP": str(tmp),
                        "prior_charges": str(prior),
                        "environment": {},
                        "commands": cmds,
                    }
                    adm["bindings"] = {
                        p: {} for p in [adm["helper"], adm["evidence_helper"], *W.REQUIRED_IMPORTS]
                    }
                    ap = root / "admission.json"
                    raw = json.dumps(adm).encode()
                    ap.write_bytes(raw)
                    executed = []
                    final = []

                    class Lease:
                        def close(self):
                            final.append("lock_close")
                            if "lock_close" in failures:
                                raise OSError("synthetic lease close")

                    class Base:
                        def __init__(self, config, output, deadline):
                            self.memory_limit = config["max_memory_bytes"]

                        def check(self, owned=()):
                            if len(executed) == 3 and "final_resources" in failures:
                                raise OSError("synthetic final resource")

                    def execute(argv, log, deadline, **kwargs):
                        executed.append(argv[-1])
                        r = {
                            "command": argv,
                            "exit_code": 1 if origin == argv[-1] else 0,
                            "direct_child_reaped": True,
                            "cleanup_complete": True,
                            "remaining": [],
                            "log_bytes_seen": 1,
                            "log_bytes_retained": 1,
                            "handle_closes_complete": True,
                            "process_cleanup_complete": True,
                            "signal_mask_restoration": "completed",
                            "final_record_persist": "completed",
                        }
                        put(log.with_suffix(".process.json"), r)
                        if "receipt" in failures and argv[-1] == "recover":
                            log.with_suffix(".process.json").write_text("[1]")
                        return r

                    def write(path, data):
                        name = {
                            "held-charges.json": "held_charges",
                            "cohort-result.json": "result",
                        }[path.name]
                        final.append(name)
                        if name in failures:
                            raise OSError("synthetic " + name)
                        put(path, data)

                    def verify(*args):
                        if len(executed) == 3 and "source_after" in failures:
                            raise OSError("synthetic source after")

                    def rmdir(path):
                        if path == tmp and "owned_empty_TMP" in failures:
                            final.append("owned_empty_TMP")
                            raise OSError("synthetic TMP")
                        return real_rmdir(path)

                    def diagnostic(*args, **kwargs):
                        final.append("diagnostic")
                        if "diagnostic" in failures:
                            raise OSError("synthetic diagnostic")

                    package = ModuleType("quoridor_training")
                    package.__path__ = []
                    package.cycle_process = SimpleNamespace(
                        CycleResources=Base,
                        execute=execute,
                        process_info=lambda pid: {"rss": 0},
                        CycleStopped=RuntimeError,
                    )
                    snapshot = ModuleType("quoridor_training.snapshot")
                    snapshot.write_json = write
                    guard = SimpleNamespace(
                        quiet=lambda: None,
                        physical=lambda: {},
                        sha=lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                    )
                    fakeE = SimpleNamespace(
                        BASELINE=prior,
                        ledger=lambda rows, *args: {
                            (r["component"], r["path"]): r["maximum_sampled_allocated_B"]
                            for r in rows
                        },
                        rows=E.rows,
                        saved_census=E.saved_census,
                    )
                    real_rmdir = Path.rmdir
                    error = None
                    with ExitStack() as stack:
                        for obj, key, value in [
                            (sys, "argv", ["port", str(ap), hashlib.sha256(raw).hexdigest()]),
                            (W, "review_and_fixed_proofs", lambda *args: None),
                            (W, "validate", lambda *args: None),
                            (W, "verify", verify),
                            (W, "LOCK", SimpleNamespace(open=lambda mode: Lease())),
                            (
                                W,
                                "fcntl",
                                SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *args: None),
                            ),
                            (W.os, "sched_setaffinity", lambda *args: None),
                            (
                                W.importlib.util,
                                "spec_from_file_location",
                                lambda name, path: SimpleNamespace(
                                    name=name, loader=SimpleNamespace(exec_module=lambda m: None)
                                ),
                            ),
                            (
                                W.importlib.util,
                                "module_from_spec",
                                lambda spec: fakeE if spec.name == "cohort_evidence" else guard,
                            ),
                            (Path, "rmdir", rmdir),
                        ]:
                            stack.enter_context(patch.object(obj, key, value))
                        stack.enter_context(
                            patch.dict(
                                sys.modules,
                                {
                                    "quoridor_training": package,
                                    "quoridor_training.snapshot": snapshot,
                                },
                            )
                        )
                        stack.enter_context(patch.dict(W.os.environ, {}, clear=False))
                        stack.enter_context(patch("builtins.print", diagnostic))
                        try:
                            W.main()
                        except BaseException as err:
                            error = err
                    assert executed == (
                        ["arena", "recover"] if origin == "arena" else ["arena", "audit", "recover"]
                    )
                    assert (
                        final[-1] == "lock_close"
                        and "result" in final
                        and "diagnostic" in final
                        and "held_charges" in final
                    )
                    if origin or failures:
                        assert error is not None
                        text = str(error) + " " + json.dumps(getattr(error, "__notes__", []))
                        for stage in failures:
                            assert stage in text, (stage, text)
                        if origin:
                            assert origin in str(error)
                    else:
                        assert error is None
                    if (out / "cohort-result.json").exists():
                        saved = json.loads((out / "cohort-result.json").read_text())
                        assert (
                            saved["provisional_only"]
                            and not saved["external_controller_acceptance"]
                        )
                        assert (
                            "cleanup_complete" not in saved
                            and "PENDING" in saved["guardian_finalization_status"]
                        )
                        assert saved["slot_census"]["planned_ids"] == list(range(16))

            case(
                "C04/C05 actual main origin=" + str(origin) + " finalizers=" + ",".join(failures),
                main_port,
            )
    return {
        "new_affected_cases": cases,
        "count": len(cases),
        "old6_plus1_Rust_caller_live64_successes_replayed": False,
        "actual_Cargo_native_backend_Search_model_geometry_games": 0,
    }


if __name__ == "__main__":
    print(
        json.dumps(
            run(
                load(HERE / "cohort_worker.py", "worker"),
                load(HERE / "cohort_evidence.py", "evidence"),
            ),
            indent=2,
        )
    )
