"""One already planned cohort; native receipt runtime, audit and recovery only."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
EXPIRY = 1791583340854
CLOCK = "authority-action-receipt-v1"
CLOCK_SHA = "04062382f70648cdfd722e59c35be1100719169097a04749b0046ea5a19a280d"
REQUIRED_IMPORTS = {
    "/workspaces/quoridor/python/quoridor_training/__init__.py": {
        "SHA256": "05011521a4993db992001289548d4c90516495129bc60b9882d6b7211c60aee5",
        "bytes": 216,
        "mode": 420,
    },
    "/workspaces/quoridor/python/quoridor_training/cycle_process.py": {
        "SHA256": "ddaa2881335488c719ad6941ac18becf1c544debf7e28037c9977d87cd6f060b",
        "bytes": 20479,
        "mode": 420,
    },
    "/workspaces/quoridor/python/quoridor_training/snapshot.py": {
        "SHA256": "ed0814965c012d6ad5ad094e653158b42b5d4ebf17463706ce53d029bc704341",
        "bytes": 1232,
        "mode": 420,
    },
}


def verify(path, record):
    path = Path(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or path.resolve(strict=True) != path:
        raise ValueError("canonical regular bound input required")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if (digest, info.st_size, stat.S_IMODE(info.st_mode)) != (
        record["SHA256"],
        record["bytes"],
        record["mode"],
    ):
        raise ValueError("changed input: " + str(path))


def receipt_cleanup_ok(receipt, command):
    return bool(
        isinstance(receipt, dict)
        and receipt.get("command") == command
        and type(receipt.get("exit_code")) is int
        and receipt.get("direct_child_reaped") is True
        and receipt.get("cleanup_complete") is True
        and receipt.get("remaining") == []
        and receipt.get("log_bytes_seen") == receipt.get("log_bytes_retained")
    )


def receipt_ok(receipt, command):
    return receipt_cleanup_ok(receipt, command) and receipt["exit_code"] == 0


def clock_census(report):
    """Saved receipt semantics only; maintained native audit supplies geometry."""
    counts = {
        "observed_games": 0,
        "observed_moves": 0,
        "accepted": 0,
        "rejected": 0,
        "cost_disproved": 0,
        "goal": 0,
        "draw": 0,
        "unknown": 0,
    }
    ids = set()
    for outcome in report["outcomes"]:
        game = outcome["game"]
        if type(game) is not int or game not in range(16) or game in ids:
            raise ValueError("duplicate/unplanned outcome")
        ids.add(game)
        counts["observed_games"] += 1
        status = outcome["status"]
        if status not in ("goal", "draw", "unknown"):
            raise ValueError("unauthorized adjudication")
        counts[status] += 1
        previous_drain = None
        for move in outcome["observations"]:
            counts["observed_moves"] += 1
            c = move["counters"]
            started = move["caller_started_ns"]
            if c.get("clock_contract") != CLOCK or c.get("clock_contract_sha256") != CLOCK_SHA:
                raise ValueError("wrong receipt clock")
            receipt, drain = c.get("authority_receipt_ns"), c.get("drain_finished_ns")
            if (
                type(receipt) is not int
                or type(drain) is not int
                or not started <= receipt <= drain
            ):
                raise ValueError("receipt/drain chronology")
            if previous_drain is not None and started < previous_drain:
                raise ValueError("opponent clock before drain")
            previous_drain = drain
            if move["deadline_ns"] != started + 100_000_000:
                raise ValueError("changed100ms clock")
            if move["accepted"]:
                counts["accepted"] += 1
                if receipt >= move["deadline_ns"] or move["failure"] is not None:
                    raise ValueError("accepted late/error receipt")
                if move["engine_index"] == 0 and (
                    c.get("immutable_chosen_action") != move["action"]
                    or c.get("authority_legal") is not True
                    or c.get("terminal_request_error") is not None
                    or c.get("inflight_after_drain") != 0
                ):
                    raise ValueError("accepted Sigma action/reply/drain mismatch")
            else:
                counts["rejected"] += 1
                if move["failure"] is None or status != "unknown":
                    raise ValueError("rejection converted to known outcome")
            if move["engine_index"] == 0:
                if (
                    c.get("measurement_mode") is not None
                    or c.get("measurement_call_limit") is not None
                ):
                    raise ValueError("production game replaced by qualification workload")
                if c.get("inflight_after_drain") != 0:
                    raise ValueError("undrained Sigma request")
                if c.get("cost_qualification_usable_after_drain") is False:
                    counts["cost_disproved"] += 1
    return counts


def validate(a):
    if not a["actual_entry"] or a["prepared_only"] or a["pending_obligations"]:
        raise ValueError("prepared/incomplete cohort control refuses entry")
    if a["role"] not in ("D", "NNUE") or a["supported_whole_B"] != 4294967296:
        raise ValueError("unsupported cohort")
    if a["source_review"]["control_clear"] is not True or not a["source_review"]["reader_STOP"]:
        raise ValueError("changed cohort control not cleared/stopped")
    review = a["source_review"]
    if review["control_path"] not in a["bindings"] or (
        a["bindings"][review["control_path"]]["SHA256"] != review["control_SHA256"]
    ):
        raise ValueError("changed-control review evidence not bound")
    for path, record in a["bindings"].items():
        verify(path, record)
    required = {
        str(Path(__file__).resolve()),
        a["helper"],
        a["private"],
        a["config"],
        a["packet"],
        a["plan"],
        a["prior_charges"],
        *a["required_imports"],
        *a["runtime_inputs"],
        *a["required_control_proofs"],
    }
    if not required.issubset(a["bindings"]):
        raise ValueError("required source/input membership missing before imports")
    for path, record in a["required_imports"].items():
        if a["bindings"][path] != record:
            raise ValueError("import identity mismatch")
    config = json.loads(Path(a["config"]).read_bytes())
    plan = json.loads(Path(a["plan"]).read_bytes())
    packet = json.loads(Path(a["packet"]).read_bytes())
    if packet["evidence"]["path"] not in a["bindings"] or (
        a["bindings"][packet["evidence"]["path"]]["SHA256"] != packet["evidence"]["sha256"]
    ):
        raise ValueError("admitted evidence membership/SHA")
    role = plan["cohorts"][a["role"]]
    binding = packet["configurations"][0 if a["role"] == "D" else 1]
    if (
        config["games"] != 16
        or config["max_plies"] != 200
        or config["wall_seconds"] is not None
        or config["output"] != a["native_output"]
        or config["seed"] != 32710001
        or config["simulations"] != 64
        or config["cpu_cores"] != [0]
        or config["inference_cpu_core"] != 0
        or config["workers"] != 1
        or config["active_games"] != 1
        or config["max_batch"] != 1
        or config["arena"]["clock_policy"] != "strict_unknown"
        or config["arena"]["return_reserve_ms"] != 5
        or binding["file"] != {"path": a["config"], "sha256": a["bindings"][a["config"]]["SHA256"]}
        or binding["normalized_sha256"] != role["normalized_config_sha256"]
        or packet["native"]["executable_sha256"] != a["bindings"][a["private"]]["SHA256"]
        or packet["native"]["valid_until_unix_ms"] != EXPIRY
        or int(time.time() * 1000) >= EXPIRY
        or packet["scope"] != "timed-arena"
    ):
        raise ValueError("fixed config/private/packet/expiry mismatch")
    expected_commands = [
        [
            "arena",
            [
                a["private"],
                "arena",
                "--config",
                a["config"],
                "--sigma-cost-qualification",
                a["packet"],
                "--qualification-sha256",
                a["bindings"][a["packet"]]["SHA256"],
            ],
        ],
        ["audit", [a["private"], "arena", "--audit", a["native_output"]]],
        ["recover", [a["private"], "arena", "--recover", a["native_output"]]],
    ]
    if a["commands"] != expected_commands or len(role["slots"]) != 16:
        raise ValueError("exact arena/audit/recover argv or planned denominator changed")
    for slot in role["slots"]:
        opening = config["arena"]["book"]["openings"][slot["family_index"]]
        if (
            opening["id"] != slot["opening_id"]
            or opening["prefix"] != slot["prefix"]
            or slot["game"] != 2 * slot["family_index"] + slot["color_index"]
        ):
            raise ValueError("pre-outcome book/slot correspondence")
    if a["role"] == "NNUE":
        if a["preceding_completed_D"] not in a["bindings"]:
            raise ValueError("preceding D acceptance not SHA bound")
        preceding = json.loads(Path(a["preceding_completed_D"]).read_bytes())
        if (
            preceding["external_controller_acceptance"] is not True
            or preceding["role"] != "D"
            or preceding["clock_census"]["cost_disproved"]
        ):
            raise ValueError("D incomplete or cost disproved; NNUE refused")
    for name in ("output", "TMP", "native_output"):
        path = Path(a[name])
        if (
            not path.is_relative_to(ROOT)
            or path.exists()
            or path.is_symlink()
            or path.parent.resolve() != path.parent
        ):
            raise ValueError("exclusive new namespace required")
    return config


def main():
    raw = Path(sys.argv[1]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != sys.argv[2]:
        raise ValueError("actual admission SHA")
    a = json.loads(raw)
    if not a["actual_entry"] or a["prepared_only"] or a["pending_obligations"]:
        raise ValueError("prepared/incomplete cohort control refuses before imports")
    if a["required_imports"] != REQUIRED_IMPORTS:
        raise ValueError("mandatory import membership/identities changed before imports")
    # Bound the reused control module and mandatory package bodies before import.
    for path in [a["helper"], *a["required_imports"]]:
        verify(path, a["bindings"][path])
    spec = importlib.util.spec_from_file_location("receipt_guard", a["helper"])
    L = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(L)
    L.quiet()
    L.physical()
    lock = LOCK.open("r+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        L.quiet()
        validate(a)
        sys.path.insert(0, "/workspaces/quoridor/python")
        from quoridor_training import cycle_process as P
        from quoridor_training.snapshot import write_json
    except BaseException as primary:
        try:
            lock.close()
        except BaseException as secondary:
            primary.add_note("lease_close: " + repr(secondary))
        raise
    output, temporary, native = map(Path, (a["output"], a["TMP"], a["native_output"]))
    attempts, errors, receipts = [], [], []
    primary, resources = None, None
    result = {
        "role": a["role"],
        "external_controller_acceptance": False,
        "provisional_only": True,
        "planned": 16,
        "continuous_peak": "UNKNOWN",
    }

    def attempt(stage, action):
        try:
            return action()
        except BaseException as error:
            errors.append({"stage": stage, "type": type(error).__name__, "message": str(error)})
            return None

    class Resources(P.CycleResources):
        def __init__(self):
            super().__init__(
                {
                    "host_ram_reserve": 4 * 1024**3,
                    "max_memory_bytes": 2 * 1024**3,
                    "max_output_bytes": 256 * 1024**2,
                },
                output,
                None,
            )
            rows = json.loads(Path(a["prior_charges"]).read_bytes())
            self.maxima = {
                (r["component"], r["path"]): r["maximum_sampled_allocated_B"] for r in rows
            }
            if len(self.maxima) != len(rows):
                raise ValueError("duplicate retained charge")
            self.family_peak = 0

        def check(self, owned=()):
            super().check(owned)
            infos = [P.process_info(os.getpid()), *(P.process_info(x["pid"]) for x in owned)]
            self.family_peak = max(
                self.family_peak, sum(x["rss"] for x in infos if x) + 64 * 1024**2
            )
            if self.family_peak > self.memory_limit:
                raise P.CycleStopped("whole family including controller reserve")
            for component, root, cap in [
                (a["role"], output, 256 * 1024**2),
                (a["role"], native, 256 * 1024**2),
                ("TMP", temporary, 512 * 1024**2),
            ]:
                pending = [root]
                while pending:
                    path = pending.pop()
                    try:
                        info = path.lstat()
                    except FileNotFoundError:
                        continue
                    if stat.S_ISLNK(info.st_mode):
                        raise P.CycleStopped("owned output symlink")
                    self.maxima[component, str(path)] = max(
                        self.maxima.get((component, str(path)), 0), info.st_blocks * 512
                    )
                    if stat.S_ISDIR(info.st_mode):
                        pending.extend(path.iterdir())
                    elif not stat.S_ISREG(info.st_mode):
                        raise P.CycleStopped("unsupported output type")
                if sum(v for (kind, _), v in self.maxima.items() if kind == component) > cap:
                    raise P.CycleStopped("held component cap: " + component)

    def execute(name, command):
        L.quiet()
        L.physical()
        for path, record in a["bindings"].items():
            verify(path, record)
        receipt = output / (name + ".process.json")
        attempts.append({"name": name, "command": command, "receipt": str(receipt)})
        returned = P.execute(
            command, output / (name + ".log"), None, cpu_core=0, resources=resources
        )
        result.setdefault("returned_process_finalization", {})[name] = {
            key: returned.get(key, "UNKNOWN")
            for key in (
                "signal_mask_restoration",
                "final_record_persist",
                "handle_closes_complete",
                "process_cleanup_complete",
            )
        }
        if not receipt_ok(returned, command):
            raise ValueError("command/directwait/cleanup/full-log refusal: " + name)

    try:
        os.environ.update(a["environment"])
        os.sched_setaffinity(0, {2})
        output.mkdir()
        temporary.mkdir()
        os.environ["TMPDIR"] = str(temporary)
        resources = Resources()
        resources.check()
        result["actual_START"] = datetime.now(timezone.utc).isoformat()
        for name, command in a["commands"]:
            execute(name, command)
        report = json.loads((native / "result.json").read_bytes())
        result["clock_census"] = clock_census(report)
        result["run_report"] = {
            "path": str(native / "result.json"),
            "sha256": L.sha(native / "result.json"),
        }
    except BaseException as error:
        primary = error
    finally:
        attempt("source_after", lambda: [verify(p, r) for p, r in a["bindings"].items()])
        if resources is not None:
            attempt("final_resources", resources.check)
        for row in attempts:
            receipt = attempt(
                "receipt:" + row["name"],
                lambda row=row: json.loads(Path(row["receipt"]).read_bytes()),
            )
            receipts.append(
                {
                    "attempt": row,
                    "receipt": receipt,
                    "verified": receipt_ok(receipt, row["command"]),
                    "cleanup_verified": receipt_cleanup_ok(receipt, row["command"]),
                }
            )
        unknown = not all(row["cleanup_verified"] for row in receipts)
        incomplete = len(receipts) != len(a["commands"]) or not all(
            row["verified"] for row in receipts
        )
        result.update(
            primary_error=None
            if primary is None
            else {"type": type(primary).__name__, "message": str(primary)},
            attempted_children=attempts,
            receipts=receipts,
            cleanup_unknown=unknown,
            cleanup_complete=not unknown,
            source_STOP=datetime.now(timezone.utc).isoformat(),
            stage_failures=errors,
            family_RSS_sample_peak_B=None if resources is None else resources.family_peak,
        )
        if resources is not None:
            attempt(
                "held_charges",
                lambda: write_json(
                    output / "held-charges.json",
                    [
                        {"component": kind, "path": path, "maximum_sampled_allocated_B": value}
                        for (kind, path), value in sorted(resources.maxima.items())
                    ],
                ),
            )
        if not unknown and temporary.exists():
            attempt("owned_empty_TMP", temporary.rmdir)
        attempt("result", lambda: write_json(output / "cohort-result.json", result))
        attempt(
            "diagnostic",
            lambda: print(json.dumps({"provisional_cohort_facts": result}), flush=True),
        )
        attempt("lock_close", lock.close)
        if primary is not None:
            if errors:
                primary.add_note(json.dumps({"independent_finalizer_errors": errors}))
            raise primary
        if errors or unknown or incomplete:
            raise RuntimeError("cohort incomplete: " + json.dumps(errors))


if __name__ == "__main__":
    main()
