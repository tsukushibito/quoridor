"""Focused synthetic ports for the changed cohort controller; no native children."""

from contextlib import ExitStack
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
from unittest.mock import patch


def run(worker):
    cases = []

    def passed(name, action):
        action()
        cases.append(name)

    def refuses(action):
        try:
            action()
        except (ValueError, KeyError, RuntimeError):
            return
        raise AssertionError("missing refusal")

    command = ["synthetic-native", "arena"]
    receipt = {
        "command": command,
        "exit_code": 0,
        "direct_child_reaped": True,
        "cleanup_complete": True,
        "remaining": [],
        "log_bytes_seen": 1,
        "log_bytes_retained": 1,
    }

    def malformed():
        for value in [
            [1],
            "receipt",
            None,
            {**receipt, "remaining": None},
            {k: v for k, v in receipt.items() if k != "exit_code"},
        ]:
            assert not worker.receipt_cleanup_ok(value, command)
        failed = {**receipt, "exit_code": 1}
        assert worker.receipt_cleanup_ok(failed, command)
        assert not worker.receipt_ok(failed, command)

    passed("Malformed receipt and known-clean failed command remain distinct", malformed)
    move = {
        "caller_started_ns": 100,
        "deadline_ns": 100_000_100,
        "action": 13,
        "accepted": True,
        "failure": None,
        "engine_index": 0,
        "counters": {
            "clock_contract": worker.CLOCK,
            "clock_contract_sha256": worker.CLOCK_SHA,
            "authority_receipt_ns": 1000,
            "drain_finished_ns": 2000,
            "immutable_chosen_action": 13,
            "authority_legal": True,
            "terminal_request_error": None,
            "inflight_after_drain": 0,
            "measurement_mode": None,
            "measurement_call_limit": None,
            "cost_qualification_usable_after_drain": True,
        },
    }
    report = {"outcomes": [{"game": 0, "status": "goal", "observations": [move]}]}

    def clocks():
        assert worker.clock_census(report)["accepted"] == 1
        for changes in [
            {"authority_receipt_ns": 100_000_100},
            {"immutable_chosen_action": 14},
            {"inflight_after_drain": 1},
            {"measurement_call_limit": 2},
        ]:
            x = copy.deepcopy(report)
            x["outcomes"][0]["observations"][0]["counters"].update(changes)
            refuses(lambda x=x: worker.clock_census(x))
        x = copy.deepcopy(report)
        x["outcomes"][0]["observations"].append(
            {**move, "caller_started_ns": 1999, "deadline_ns": 100_001_999}
        )
        refuses(lambda: worker.clock_census(x))
        x = copy.deepcopy(report)
        x["outcomes"][0]["status"] = "unknown"
        x["outcomes"][0]["observations"][0].update(accepted=False, failure="time_overrun")
        assert worker.clock_census(x)["unknown"] == 1

    passed("Receipt/action/drain/late and production-call-limit discrimination", clocks)

    def omission():
        for missing in worker.REQUIRED_IMPORTS:
            with tempfile.TemporaryDirectory(
                dir=Path(__file__).parent / "ports-tmp-v1"
            ) as directory:
                a = {
                    "actual_entry": True,
                    "prepared_only": False,
                    "pending_obligations": [],
                    "required_imports": {
                        k: v for k, v in worker.REQUIRED_IMPORTS.items() if k != missing
                    },
                }
                p = Path(directory) / "admission.json"
                b = json.dumps(a).encode()
                p.write_bytes(b)
                with (
                    patch.object(sys, "argv", ["port", str(p), hashlib.sha256(b).hexdigest()]),
                    patch.object(
                        worker.importlib.util,
                        "spec_from_file_location",
                        side_effect=AssertionError("import attempted"),
                    ),
                ):
                    refuses(worker.main)

    passed("Each mandatory import omission refuses actual main before import", omission)

    def main_port(failure=False, close_failure=False):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent / "ports-tmp-v1") as directory:
            root = Path(directory)
            output, native, temporary = root / "control", root / "native", root / "tmp"
            native.mkdir()
            (native / "result.json").write_text(json.dumps(report))
            prior = root / "prior.json"
            prior.write_text("[]")
            commands = [[n, ["synthetic-native", n]] for n in ("arena", "audit", "recover")]
            a = {
                "role": "D",
                "actual_entry": True,
                "prepared_only": False,
                "pending_obligations": [],
                "required_imports": worker.REQUIRED_IMPORTS,
                "bindings": {},
                "helper": "bound-synthetic-helper",
                "output": str(output),
                "native_output": str(native),
                "TMP": str(temporary),
                "environment": {},
                "prior_charges": str(prior),
                "commands": commands,
            }
            a["bindings"] = {k: {} for k in [a["helper"], *a["required_imports"]]}
            p = root / "admission.json"
            b = json.dumps(a).encode()
            p.write_bytes(b)
            executed, finalizers = [], []

            class Lease:
                def close(self):
                    finalizers.append("lock_close")
                    if close_failure:
                        raise OSError("synthetic close refusal")

            class LeasePath:
                def open(self, mode):
                    return Lease()

            class BaseResources:
                def __init__(self, config, output, deadline):
                    self.memory_limit = config["max_memory_bytes"]

                def check(self, owned=()):
                    pass

            def execute(argv, log, deadline, **kwargs):
                executed.append(argv[-1])
                r = {
                    **receipt,
                    "command": argv,
                    "exit_code": 1 if failure and argv[-1] == "audit" else 0,
                }
                log.with_suffix(".process.json").write_text(json.dumps(r))
                return r

            def write_json(path, data):
                finalizers.append(path.name)
                path.write_text(json.dumps(data))

            module = SimpleNamespace(
                quiet=lambda: None,
                physical=lambda: {"synthetic": True},
                sha=lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            )
            package = ModuleType("quoridor_training")
            package.__path__ = []
            package.cycle_process = SimpleNamespace(
                CycleResources=BaseResources,
                process_info=lambda pid: {"rss": 0},
                execute=execute,
                CycleStopped=RuntimeError,
            )
            snapshot = ModuleType("quoridor_training.snapshot")
            snapshot.write_json = write_json
            with ExitStack() as stack:
                stack.enter_context(
                    patch.object(sys, "argv", ["port", str(p), hashlib.sha256(b).hexdigest()])
                )
                stack.enter_context(patch.object(worker, "verify", lambda *args: None))
                stack.enter_context(patch.object(worker, "validate", lambda *args: None))
                stack.enter_context(patch.object(worker, "LOCK", LeasePath()))
                stack.enter_context(
                    patch.object(
                        worker,
                        "fcntl",
                        SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *args: None),
                    )
                )
                stack.enter_context(
                    patch.object(worker.os, "sched_setaffinity", lambda *args: None)
                )
                stack.enter_context(
                    patch.object(
                        worker.importlib.util,
                        "spec_from_file_location",
                        lambda *args: SimpleNamespace(
                            loader=SimpleNamespace(exec_module=lambda value: None)
                        ),
                    )
                )
                stack.enter_context(
                    patch.object(worker.importlib.util, "module_from_spec", lambda *args: module)
                )
                stack.enter_context(
                    patch.dict(
                        sys.modules,
                        {"quoridor_training": package, "quoridor_training.snapshot": snapshot},
                    )
                )
                stack.enter_context(patch.dict(worker.os.environ, {}, clear=False))
                stack.enter_context(patch("builtins.print", lambda *args, **kwargs: None))
                if failure:
                    try:
                        worker.main()
                    except ValueError as error:
                        assert "audit" in str(error)
                        if close_failure:
                            assert "lock_close" in json.dumps(error.__notes__)
                    else:
                        raise AssertionError("failed audit became successful main")
                else:
                    worker.main()
            saved = json.loads((output / "cohort-result.json").read_text())
            assert saved["provisional_only"] and not saved["external_controller_acceptance"]
            assert saved["cleanup_complete"] and not saved["cleanup_unknown"]
            assert executed == (["arena", "audit"] if failure else ["arena", "audit", "recover"])
            assert "held-charges.json" in finalizers and "cohort-result.json" in finalizers
            assert finalizers[-1] == "lock_close"

    passed("Actual main three successful synthetic ports remain nonadmitting", lambda: main_port())
    passed(
        "Actual main failed audit preserves primary, known cleanup, no recovery",
        lambda: main_port(True),
    )
    passed(
        "Actual main primary plus late close retains secondary note", lambda: main_port(True, True)
    )
    return {
        "new_synthetic_port_cases": cases,
        "count": len(cases),
        "actual_native_Popen_Search_backend_model_games": 0,
    }


def load(path):
    spec = importlib.util.spec_from_file_location("cohort_worker_ports", path)
    worker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(worker)
    return worker


def review_membership_port(worker):
    admission = {
        "actual_entry": True,
        "prepared_only": False,
        "pending_obligations": [],
        "role": "D",
        "supported_whole_B": 4294967296,
        "source_review": {
            "control_clear": True,
            "reader_STOP": "synthetic-sourceSTOP",
            "control_path": "missing-review",
            "control_SHA256": "synthetic",
        },
        "bindings": {},
    }
    try:
        worker.validate(admission)
    except ValueError as error:
        assert "review evidence not bound" in str(error)
    else:
        raise AssertionError("unbound review evidence admitted")
    return {
        "new_synthetic_case": "Missing actual review evidence refuses before input/native IO",
        "actual_native_backend_model_Popen_Search_games": 0,
    }


if __name__ == "__main__":
    print(json.dumps(run(load(Path(__file__).with_name("cohort_worker.py"))), indent=2))
