"""One unfinished saved audit; provisional facts only until real outer finalization."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys


def imported(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def forward_support(support, prior):
    """Preserve named phase uppers inside existing classifications, without sample credit."""
    expected = {
        "whole_B": 4294967296,
        "D_component_cap_B": 268435456,
        "D_forward_held_native_B": 234881024,
        "D_three_native_log_uppers_B": [8388608] * 3,
        "D_three_controller_log_uppers_B": [1048576] * 3,
        "D_three_metadata_uppers_B": [1048576] * 3,
        "D_supported_forward_B": 266338304,
        "D_remaining_guard_B": 2097152,
        "saved_audit_owned_output_upper_B": 9437184,
        "audit_stdout_upper_B": 8388608,
        "saved_audit_receipts_charges_guardian_metadata_upper_B": 1048576,
        "saved_audit_controller_log_upper_B": 1048576,
        "publication_controller_candidate_descriptor_upper_B": 2097152,
        "prospective_audit_TMP_B": 67108864,
        "serial_TMP_cap_B": 536870912,
    }
    if any(type(support[k]) is not type(v) or support[k] != v for k, v in expected.items()):
        raise ValueError("fixed named forward support, no lowered/rescoped upper")
    held_tmp = max(
        support["retained_old_TMP_B"],
        sum(r["maximum_sampled_allocated_B"] for r in prior if r["component"] == "TMP"),
    )
    if (
        type(support["retained_old_TMP_B"]) is not int
        or support["retained_old_TMP_B"] < 5685248
        or held_tmp + support["prospective_audit_TMP_B"] > support["serial_TMP_cap_B"]
    ):
        raise ValueError("retained serial TMP support gap")


def main():
    path = Path(sys.argv[1])
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != sys.argv[2]:
        raise ValueError("actual saved-admission SHA")
    a = json.loads(raw)
    if a["actual_entry"] is not True or a["prepared_only"] is not False or a["pending_obligations"]:
        raise ValueError("prepared saved route refuses before imports or output")
    if a["purpose"] != "unfinished-saved-D-audit" or a["whole_B"] != 4294967296:
        raise ValueError("fixed saved-only scope")
    root = Path(__file__).resolve().parents[1]
    if (
        a["cohort_worker"] != str(root / "saved-control-repair-v23/cohort_worker.py")
        or a["science_reader"] != str(Path(__file__).with_name("stopped_science.py"))
        or a["evidence_helper"] != str(root / "cohort-repair-v18/cohort_evidence.py")
        or a["helper"] != str(root / "canonical-config-repair-v11/live_worker.py")
        or a["whole_forecast"] != str(root / "cohort-repair-v18/whole-forecast-v18.json")
    ):
        raise ValueError("fixed maintained source/ledger/physical interfaces")
    # Only stdlib source modules are loaded before the independently stopped verdict.
    worker = Path(a["cohort_worker"])
    if hashlib.sha256(worker.read_bytes()).hexdigest() != a["bindings"][str(worker)]["SHA256"]:
        raise ValueError("bound current collector source")
    W = imported(worker, "cohort_checks")
    W.review_and_fixed_proofs(a)
    review_target = json.loads(Path(a["source_review"]["target_path"]).read_bytes())
    for name in (str(Path(__file__).resolve()), a["science_reader"]):
        if review_target["selected_refs"].get(name) != a["bindings"].get(name):
            raise ValueError("saved guardian/consumer differs from current reviewed target")
        W.verify(name, a["bindings"][name])
    if a["required_imports"] != W.REQUIRED_IMPORTS or a["native_log_max_bytes"] != 8388608:
        raise ValueError("mandatory package or supported log identity")
    for name in [a["helper"], a["evidence_helper"], *a["required_imports"]]:
        W.verify(name, a["bindings"][name])
    L = imported(a["helper"], "physical_guard")
    L.quiet()
    L.physical()
    lease = W.LOCK.open("r+")
    try:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        L.quiet()
        L.physical()
        for name, record in a["bindings"].items():
            W.verify(name, record)
        E = imported(a["evidence_helper"], "saved_ledger")
        H = imported(a["science_reader"], "stopped_science")
        forecast = json.loads(Path(a["whole_forecast"]).read_bytes())
        resource_proof = json.loads(Path(forecast["resource_proof"]["path"]).read_bytes())
        if (
            forecast["supported_whole_B"] != resource_proof["new_whole_B"]
            or forecast["all_original_component_uppers_B"] != resource_proof["components_B"]
        ):
            raise ValueError("held original component/whole support")
        baseline = json.loads(E.BASELINE.read_bytes())
        prior = json.loads(Path(a["prior_charges"]).read_bytes())
        E.ledger(prior, forecast, baseline)
        if review_target["selected_refs"].get(a["forward_support"]) != a["bindings"].get(
            a["forward_support"]
        ):
            raise ValueError("reviewed forward support membership")
        forward_support(json.loads(Path(a["forward_support"]).read_bytes()), prior)
        objects, data = H.read_stopped_inputs()
        custody = H.stopped_custody(objects, data, W.clock_census, W.receipt_cleanup_ok)
        if (
            a["audit_argv"] != [a["private"], "arena", "--audit", a["native_output"]]
            or a["private"] != objects["science_admission"]["private"]
            or a["native_output"] != objects["D_config"]["output"]
        ):
            raise ValueError("only still-unrun fixed native audit, no arena/recover relaunch")
        os.environ.update(a["environment"])
        sys.path.insert(0, "/workspaces/quoridor/python")
        from quoridor_training import cycle_process as P
        from quoridor_training.snapshot import write_json

        P.LOG_MAX_BYTES = a["native_log_max_bytes"]
        for identity in custody["identities"]:
            if P.alive(identity):
                raise ValueError("original science exact process still alive")
        output, temporary = Path(a["output"]), Path(a["TMP"])
        for root in (output, temporary):
            if root.exists() or root.is_symlink() or root.parent.resolve() != root.parent:
                raise ValueError("exclusive new saved output/TMP")
    except BaseException as primary:
        try:
            lease.close()
        except BaseException as secondary:
            primary.add_note("preentry_lease_close: " + repr(secondary))
        raise
    primary, errors, attempts = None, [], []
    resources = None
    receipt = None
    result = {
        "purpose": a["purpose"],
        "provisional_only": True,
        "external_completion_acceptance": False,
        "original_science": custody,
        "full_guardian_finalization": "PENDING actual successful outer controller",
        "new_native_scientific_games": 0,
    }

    def attempt(stage, action):
        row = {"stage": stage, "status": "pending"}
        attempts.append(row)
        try:
            value = action()
            row["status"] = "completed"
            return value
        except BaseException as error:
            row["status"] = "failed_UNKNOWN"
            errors.append({"stage": stage, "type": type(error).__name__, "message": str(error)})
            return None

    class Resources(P.CycleResources):
        def __init__(self):
            super().__init__(
                {
                    "host_ram_reserve": 4294967296,
                    "max_memory_bytes": 2147483648,
                    "max_output_bytes": 9437184,
                },
                output,
                None,
            )
            self.maxima = E.ledger(prior, forecast, baseline)
            self.family_peak = 0

        def check(self, owned=()):
            E.ledger(E.rows(self.maxima), forecast, baseline)
            super().check(owned)
            infos = [P.process_info(os.getpid()), *(P.process_info(x["pid"]) for x in owned)]
            self.family_peak = max(self.family_peak, sum(x["rss"] for x in infos if x) + 67108864)
            if self.family_peak > self.memory_limit:
                raise P.CycleStopped("family including controller reserve")
            pending = [("D", output), ("TMP", temporary)]
            while pending:
                kind, path = pending.pop()
                try:
                    info = path.lstat()
                except FileNotFoundError:
                    continue
                if stat.S_ISLNK(info.st_mode):
                    raise P.CycleStopped("owned saved output symlink")
                E.ledger(E.rows(self.maxima), forecast, baseline)
                self.maxima[kind, str(path)] = max(
                    self.maxima.get((kind, str(path)), 0), info.st_blocks * 512
                )
                E.ledger(E.rows(self.maxima), forecast, baseline)
                if stat.S_ISDIR(info.st_mode):
                    pending.extend((kind, child) for child in path.iterdir())
                elif not stat.S_ISREG(info.st_mode):
                    raise P.CycleStopped("unsupported saved output type")

    try:
        os.sched_setaffinity(0, {2})
        output.mkdir()
        temporary.mkdir()
        os.environ["TMPDIR"] = str(temporary)
        resources = Resources()
        resources.check()
        L.quiet()
        W.physical_before_child(L)
        for name, record in a["bindings"].items():
            W.verify(name, record)
        H.read_stopped_inputs()
        result["actual_START"] = datetime.now(timezone.utc).isoformat()
        receipt = P.execute(
            a["audit_argv"], output / "audit.log", None, cpu_core=0, resources=resources
        )
        result["returned_audit_finalization"] = receipt
        if not W.receipt_ok(receipt, a["audit_argv"]):
            raise ValueError("actual saved audit/directwait/full capture refused")
        audit = json.loads((output / "audit.log").read_bytes())
        if audit != objects["native_manifest"]["summary"]:
            raise ValueError("maintained audit summary differs from original saved summary")
        result["audit_summary"] = audit
        result["clock_census"] = W.clock_census(objects["native_report"])
        if result["clock_census"]["cost_disproved"] != 0:
            raise ValueError("original qualified cost disproved")
    except BaseException as error:
        primary = error
    finally:
        attempt("fixed_native_inputs_after", H.read_stopped_inputs)
        attempt("source_after", lambda: [W.verify(p, v) for p, v in a["bindings"].items()])
        if resources is not None:
            attempt("final_resources", resources.check)
            attempt(
                "held_charges",
                lambda: write_json(output / "held-charges.json", E.rows(resources.maxima)),
            )
        disk_receipt = attempt(
            "audit_receipt", lambda: json.loads((output / "audit.process.json").read_bytes())
        )
        cleanup_known = W.receipt_cleanup_ok(disk_receipt, a["audit_argv"])
        result.update(
            primary_error=None
            if primary is None
            else {"type": type(primary).__name__, "message": str(primary)},
            stage_failures=errors,
            independent_finalizer_attempts=attempts,
            audit_receipt=disk_receipt,
            audit_process_cleanup_known=cleanup_known,
            source_STOP=datetime.now(timezone.utc).isoformat(),
            sampled_family_peak_B=None if resources is None else resources.family_peak,
            continuous_peak="UNKNOWN",
        )

        def temporary_stage():
            if cleanup_known and temporary.exists():
                temporary.rmdir()

        attempt("owned_empty_TMP", temporary_stage)
        attempt(
            "provisional_result",
            lambda: write_json(output / "saved-completion-result.json", result),
        )
        attempt(
            "diagnostic",
            lambda: print(json.dumps({"provisional_saved_D_completion": result}), flush=True),
        )
        attempt("lease_close", lease.close)
        terminal = {
            "independent_finalizer_errors": errors,
            "independent_finalizer_attempts": attempts,
            "audit_cleanup_known": cleanup_known,
            "external_completion_acceptance": False,
            "original_science_controller": "FAILED retained",
        }
        if primary is not None:
            primary.add_note(json.dumps(terminal))
            raise primary
        if errors or not cleanup_known or receipt is None:
            raise RuntimeError("saved completion failed: " + json.dumps(terminal))


if __name__ == "__main__":
    main()
