"""Strict source-bound custody of the stopped D records; no completed-D admission."""

import hashlib
import json
from pathlib import Path
import stat

FROZEN_SCIENCE_REFS = {
    "science_config": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-runtime-d-recovery-v2/config.json",
        "SHA256": "00319642704c4fe94d620f83fa6abf3f9bb3ba454dac491ca3b94046db6485b9",
        "bytes": 991,
        "mode": 384,
    },
    "science_state": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-runtime-d-recovery-v2/state.json",
        "SHA256": "a74a3add841e3d6a837ffdd087164d1c2e9b5dc24ad719ca09d7a176e07f61fb",
        "bytes": 706,
        "mode": 384,
    },
    "science_controller": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-runtime-d-recovery-v2/result.json",
        "SHA256": "7716df0de06b8737af37f3f40d4b533bde76a76d52b6a7a5e2a8b39c01d05365",
        "bytes": 506,
        "mode": 384,
    },
    "science_outer_log": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-runtime-d-recovery-v2/output.log",
        "SHA256": "45c838f1ba721b7a06fd0dd922a7a542b4264a745349acff1bb0dae566eec5a0",
        "bytes": 10714,
        "mode": 420,
    },
    "science_admission": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-entry-v21/admission-d.actual-v21.json",
        "SHA256": "795d7ecf1005042366065e39f949957074e71d45ac7e27cd77f88f9c58e86ac7",
        "bytes": 80275,
        "mode": 420,
    },
    "science_guardian": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/control-recovery-v2/cohort-result.json",
        "SHA256": "2b938f5d835c1641a5e554f0a22dbfd2e54825ce818fb61b5c6e7b6c541f81ff",
        "bytes": 11309,
        "mode": 384,
    },
    "arena_receipt": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/control-recovery-v2/arena.process.json",
        "SHA256": "26a71f2a3694e1ab069f1fa3cfef5b664e29e3fb5856fc96152a0d60c95d6ded",
        "bytes": 1414,
        "mode": 384,
    },
    "recover_receipt": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/control-recovery-v2/recover.process.json",
        "SHA256": "f78f505a50cf9054edba4f12d87699ae8c07b78b855eca994dd3851fb58d39df",
        "bytes": 1097,
        "mode": 384,
    },
    "science_held_charges": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/control-recovery-v2/held-charges.json",
        "SHA256": "50b8bee6f9fc2098af1a7149e854ec1f8115746e0ab1229a286e9eefa711645f",
        "bytes": 606258,
        "mode": 384,
    },
    "process_release": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/D-completion-v22/process-release-failed-D-STOP.json",
        "SHA256": "e63aaff17aee44e1a8536b908550e09e3fe5d22e3659ca4754bc9af64e6a5616",
        "bytes": 6036,
        "mode": 420,
    },
    "D_config": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/configuration-v2/config-d-16.fixed-v2.json",
        "SHA256": "f8ce5e4e37ac0161e3348d81e5e48d0140b1cf1079429b0335dc671d98e330e7",
        "bytes": 15569,
        "mode": 420,
    },
    "both_plan": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-control-v15/both-cohorts-plan.fixed-v15.json",
        "SHA256": "473a6adcf5ac58b42612e4588a730ed30611252739569bda846ee012577606c2",
        "bytes": 14854,
        "mode": 420,
    },
    "admitted_cost_packet": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/live-control-output-v1/arena-admitted-packet.json",
        "SHA256": "93e11897b983c840fdde17a9ef0d130e4b88b72fad6e56fb66e026a5838d2770",
        "bytes": 1553,
        "mode": 420,
    },
    "cost_evidence": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/live-control-output-v1/arena-evidence.json",
        "SHA256": "ace624361f518a6b9d1d628dbfa9f035feb1ebcd04896cf03fa785485c53bc25",
        "bytes": 1666,
        "mode": 420,
    },
    "native_report": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/result.json",
        "SHA256": "157472d4867fa18967eb5abfb4701f986c07e68b6ec7c3d96fe8fea729d33ffa",
        "bytes": 2013384,
        "mode": 420,
    },
    "native_manifest": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/manifest.json",
        "SHA256": "0ddaa2200b762cba52fc4d142249a2c5580ee20cd5547f54e943e5b3849df0df",
        "bytes": 2055272,
        "mode": 420,
    },
    "native_start": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/manifest-start.json",
        "SHA256": "52b8e831b71012b36f333e81ed2da084088a41462433f0152983904e5c6520c6",
        "bytes": 53923,
        "mode": 420,
    },
    "native_planned": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/planned.json",
        "SHA256": "e132afe502a61932779e1853876ec0f88b88e2f135ea209dbfa890c984d900d1",
        "bytes": 13981,
        "mode": 420,
    },
    "native_artifact:admission.json": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/admission.json",
        "SHA256": "e3e2cd9a5184ca7d64da66801ad1340d81c244b81454b58648e25f89cef96ecd",
        "bytes": 206,
        "mode": 420,
    },
    "native_artifact:completed.jsonl": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/completed.jsonl",
        "SHA256": "0b42dc2798a41ab618e65b519d3610afa696c8fdc23d5db78cc0f9a2ae869bbf",
        "bytes": 2009020,
        "mode": 420,
    },
    "native_artifact:config.json": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/config.json",
        "SHA256": "8007c46047375f22379a4f6cc1dfe7b9aa3f064e633d1c092d028bc1654d5ab6",
        "bytes": 19820,
        "mode": 420,
    },
    "native_artifact:evaluator-identities.json": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/evaluator-identities.json",
        "SHA256": "a03974e3490fa777c24a3601f8d0e28518d774d9899a1c2e399cc125f8792254",
        "bytes": 458,
        "mode": 420,
    },
    "native_artifact:games.csv": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/games.csv",
        "SHA256": "553440da708ffd53f9170299aa3df9df4b74d4c78546a5172e82a6a2c32364e7",
        "bytes": 1223,
        "mode": 420,
    },
    "native_artifact:moves.jsonl.gz": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/moves.jsonl.gz",
        "SHA256": "32edd0db2113e5e2de998f90fb90473378e5dee893579964dbb85a4248e6a7f6",
        "bytes": 207611,
        "mode": 420,
    },
    "native_artifact:planned.json": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/planned.json",
        "SHA256": "e132afe502a61932779e1853876ec0f88b88e2f135ea209dbfa890c984d900d1",
        "bytes": 13981,
        "mode": 420,
    },
    "native_artifact:result.json": {
        "path": "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-d-v1/run/result.json",
        "SHA256": "157472d4867fa18967eb5abfb4701f986c07e68b6ec7c3d96fe8fea729d33ffa",
        "bytes": 2013384,
        "mode": 420,
    },
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_stopped_inputs():
    objects, data = {}, {}
    for key, reference in FROZEN_SCIENCE_REFS.items():
        path = Path(reference["path"])
        info = path.lstat()
        require(
            stat.S_ISREG(info.st_mode) and not path.is_symlink() and path.resolve() == path,
            "canonical stopped regular input",
        )
        raw = path.read_bytes()
        require(
            hashlib.sha256(raw).hexdigest() == reference["SHA256"]
            and info.st_size == reference["bytes"]
            and stat.S_IMODE(info.st_mode) == reference["mode"],
            "stopped science input changed: " + key,
        )
        data[key] = raw
        if path.suffix == ".json":
            objects[key] = json.loads(raw)
    return objects, data


def stopped_custody(objects, data, clock_census, cleanup_check):
    """Preserve failure and independent cleanup; never return an admitting flag."""
    state, controller, config, admission, guardian = (
        objects[k]
        for k in (
            "science_state",
            "science_controller",
            "science_config",
            "science_admission",
            "science_guardian",
        )
    )
    fingerprint = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
    require(
        state["job_id"] == controller["job_id"] == "19524ce5-8edf-4d1c-a8c2-113f095efa3b"
        and state["config_sha256"] == fingerprint,
        "actual original controller identity",
    )
    require(
        state["phase"] == "finished"
        and state["outcome"] == controller["outcome"] == "failed"
        and controller["exit_code"] == 1
        and controller["error"] is None,
        "original failure must remain failed",
    )
    require(
        controller["direct_child_reaped"] is True
        and controller["cleanup_complete"] is True
        and controller["remaining"] == controller["cleanup_errors"] == []
        and controller["log_bytes_seen"] == controller["log_bytes_retained"],
        "original external directwait/cleanup/terminal log unknown",
    )
    require(
        config["issue"] == "quoridor-4lc.347.3"
        and config["goal_issue"] == "quoridor-4lc.347"
        and config["thread_id"] == "01a11062-b120-73a1-8aa3-fe2cb922c7c0"
        and config["resource_contract"] == FROZEN_SCIENCE_REFS["science_admission"]["path"],
        "science owner/config/admission",
    )
    require(
        config["argv"][3:]
        == [
            FROZEN_SCIENCE_REFS["science_admission"]["path"],
            FROZEN_SCIENCE_REFS["science_admission"]["SHA256"],
        ],
        "science exact admission argv",
    )
    require(
        admission["actual_entry"] is True
        and admission["prepared_only"] is False
        and admission["pending_obligations"] == []
        and admission["role"] == "D",
        "original actual D admission",
    )
    for key, field in (
        ("D_config", "config"),
        ("both_plan", "plan"),
        ("admitted_cost_packet", "packet"),
    ):
        require(
            admission[field] == FROZEN_SCIENCE_REFS[key]["path"]
            and admission["bindings"][admission[field]]["SHA256"]
            == FROZEN_SCIENCE_REFS[key]["SHA256"],
            "original fixed input identity",
        )
    require(
        guardian["provisional_only"] is True
        and guardian["external_controller_acceptance"] is False
        and guardian["primary_error"]
        == {"type": "ValueError", "message": "command/directwait/cleanup/full-log refusal: arena"},
        "only known guard-origin failure, no positive declaration",
    )
    require(
        guardian["stage_failures"]
        == [
            {
                "stage": "saved_recovery",
                "type": "ValueError",
                "message": "command/directwait/cleanup/full-log refusal: recover",
            },
            {
                "stage": "saved_clock_census",
                "type": "ValueError",
                "message": "receipt/drain chronology",
            },
        ],
        "unrecognized original failure cannot be hidden",
    )
    terminal = json.loads(data["science_outer_log"].decode().strip().splitlines()[-1])
    require(
        terminal["guardian_overall_cleanup"] == "failed_UNKNOWN"
        and terminal["independent_finalizer_errors"] == guardian["stage_failures"],
        "retain final terminal unknown/error attribution",
    )
    for row in terminal["independent_finalizer_attempts"]:
        expected = (
            "failed_UNKNOWN"
            if row["stage"] in ("saved_recovery", "saved_clock_census")
            else "completed"
        )
        require(row["status"] == expected, "unrecognized finalizer refusal")
    require(
        terminal["independent_finalizer_attempts"][-1]["stage"] == "lock_close",
        "final attribution must include last lease finalizer",
    )
    require(
        [row["name"] for row in guardian["attempted_children"]] == ["arena", "recover"]
        and len(guardian["receipts"]) == 2,
        "only original two native commands",
    )
    identities = [state["child"]]
    captures = {}
    for name in ("arena", "recover"):
        receipt = objects[name + "_receipt"]
        expected = admission["commands"][0 if name == "arena" else 2][1]
        require(
            cleanup_check(receipt, expected) and receipt["exit_code"] == 0,
            "native direct process cleanup unknown",
        )
        returned = guardian["returned_process_finalization"][name]
        require(
            returned["signal_mask_restoration"] == returned["final_record_persist"] == "completed"
            and returned["process_cleanup_complete"] is True
            and returned["handle_closes_complete"] is True,
            "returned native finalization unavailable",
        )
        require(
            type(receipt["log_bytes_seen"]) is int
            and type(receipt["log_bytes_retained"]) is int
            and 0 <= receipt["log_bytes_retained"] < receipt["log_bytes_seen"],
            "lost stdout facts must stay truncated",
        )
        captures[name] = {
            "seen_B": receipt["log_bytes_seen"],
            "retained_B": receipt["log_bytes_retained"],
            "lost_prefix": "UNKNOWN/not captured; not reconstructed",
        }
        identities.append(receipt["child"])
    report, manifest, planned, cfg, plan = (
        objects[k]
        for k in ("native_report", "native_manifest", "native_planned", "D_config", "both_plan")
    )
    require(
        report["run_id"] == cfg["run_id"]
        and report["planned"] == 16
        and len(report["outcomes"]) == 16,
        "complete fixed scheduled denominator",
    )
    require(
        [s["game"] for s in planned] == list(range(16))
        and all(
            s["opening"] == p["prefix"] and s["candidate_color"] == p["color_index"]
            for s, p in zip(planned, plan["cohorts"]["D"]["slots"], strict=True)
        ),
        "frozen plan lineage/color/prefix",
    )
    require(
        manifest["binding"]["config"] == cfg
        and manifest["binding"]["planned_slots"] == planned
        and manifest["binding"]["executable_sha256"]
        == admission["bindings"][admission["private"]]["SHA256"],
        "saved native/private binding",
    )
    # Rust typed f32 serialization and Python JSON numbers can differ.
    # Both raw artifacts remain fixed; only the maintained native audit may
    # establish typed report/manifest equality. No values are rewritten here.
    for filename, reference in manifest["artifacts"].items():
        key = "native_artifact:" + filename
        require(
            key in FROZEN_SCIENCE_REFS
            and reference["sha256"] == FROZEN_SCIENCE_REFS[key]["SHA256"]
            and reference["bytes"] == FROZEN_SCIENCE_REFS[key]["bytes"],
            "native artifact custody",
        )
    census = clock_census(report)
    require(census["cost_disproved"] == 0, "disproved cost cannot admit future NN")
    return {
        "science_job_id": controller["job_id"],
        "science_original_controller": "FAILED",
        "science_guardian_overall": "FAILED_UNKNOWN retained",
        "native_process_cleanup": "separately observed clean/reaped",
        "old_full_capture": captures,
        "clock_census": census,
        "planned_ids": list(range(16)),
        "identities": identities,
        "audit": "NOT_ESTABLISHED_BY_THIS_FUNCTION",
        "completed_D_admission": False,
        "new_successful_saved_only_external_completion_required": True,
    }


def derive_completed_saved_D(bundle, bindings, worker, evidence):
    """Require a NEW successful external saved-only completion; old job stays FAILED."""
    require(
        bundle.get("schema") == "quoridor.completed-D-saved-route-input.v1",
        "a positive declaration is not raw completed evidence",
    )
    refs = bundle["references"]
    required = {
        "admission",
        "config",
        "state",
        "controller",
        "guardian",
        "audit_receipt",
        "audit_log",
        "held_charges",
        "review_control",
        "review_target",
    }
    require(set(refs) == required, "complete new external saved-only reference set")
    objects = {
        key: evidence.read_ref(reference, bindings)
        for key, reference in refs.items()
        if key != "audit_log"
    }
    log_ref = refs["audit_log"]
    require(
        bindings[log_ref["path"]] == evidence.record(log_ref["path"])
        and bindings[log_ref["path"]]["SHA256"] == log_ref["sha256"],
        "actual complete audit stdout identity",
    )
    audit = json.loads(Path(log_ref["path"]).read_bytes())
    admission, config, state, controller, guardian = (
        objects[k] for k in ("admission", "config", "state", "controller", "guardian")
    )
    runtime = Path(refs["controller"]["path"]).parent
    require(
        runtime.is_relative_to(evidence.ROOT)
        and Path(refs["controller"]["path"]) == runtime / "result.json"
        and all(
            Path(refs[key]["path"]) == runtime / (key + ".json") for key in ("config", "state")
        ),
        "same authoritative completion runtime",
    )
    require(
        admission["purpose"] == "unfinished-saved-D-audit"
        and admission["actual_entry"] is True
        and admission["prepared_only"] is False
        and admission["pending_obligations"] == [],
        "only actual saved-only completion admission",
    )
    require(
        config["issue"] == "quoridor-4lc.347.3"
        and config["goal_issue"] == "quoridor-4lc.347"
        and config["thread_id"] == evidence.THREAD
        and config["cwd"] == str(evidence.WT),
        "completion owner/cwd",
    )
    require(
        config["resource_contract"] == refs["admission"]["path"]
        and config["argv"]
        == [
            "/usr/bin/python3.11",
            "-B",
            str(Path(__file__).with_name("saved_D_worker.py")),
            refs["admission"]["path"],
            refs["admission"]["sha256"],
        ]
        and all(config[k] is None for k in ("end_at", "notify_until", "max_runtime_seconds")),
        "exact new completion controller argv and horizons",
    )
    fingerprint = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
    require(
        state["config_sha256"] == fingerprint
        and state["job_id"] == controller["job_id"]
        and state["job_id"] != "19524ce5-8edf-4d1c-a8c2-113f095efa3b"
        and state["issue"] == config["issue"]
        and state["thread_id"] == evidence.THREAD
        and state["phase"] == "finished"
        and state["outcome"] == controller["outcome"] == "succeeded",
        "old failed or foreign controller cannot admit",
    )
    require(
        controller["error"] is None
        and type(controller["exit_code"]) is int
        and controller["exit_code"] == 0
        and controller["direct_child_reaped"] is True
        and controller["cleanup_complete"] is True
        and controller["remaining"] == controller["cleanup_errors"] == []
        and controller["descendant_visibility"] == "observed"
        and type(controller["log_bytes_seen"]) is int
        and type(controller["log_bytes_retained"]) is int
        and 0 <= controller["log_bytes_seen"] == controller["log_bytes_retained"],
        "failed/partial/unknown new external completion",
    )
    worker.review_and_fixed_proofs(admission)
    review = admission["source_review"]
    require(
        refs["review_control"]["path"] == review["control_path"]
        and refs["review_control"]["sha256"] == review["control_SHA256"]
        and refs["review_target"]["path"] == review["target_path"]
        and refs["review_target"]["sha256"] == review["target_SHA256"],
        "actual current stopped completion-route verdict",
    )
    target = objects["review_target"]
    for path in (str(Path(__file__).resolve()), str(Path(__file__).with_name("saved_D_worker.py"))):
        require(
            target["selected_refs"].get(path) == bindings[path] == evidence.record(path),
            "completed-route source differs from actual reviewed body",
        )
    science_objects, science_data = read_stopped_inputs()
    custody = stopped_custody(
        science_objects, science_data, worker.clock_census, worker.receipt_cleanup_ok
    )
    command = [str(evidence.PRIVATE), "arena", "--audit", science_objects["D_config"]["output"]]
    output = Path(admission["output"])
    require(
        admission["private"] == str(evidence.PRIVATE)
        and admission["audit_argv"] == command
        and admission["native_output"] == science_objects["D_config"]["output"]
        and admission["native_log_max_bytes"] == 8388608,
        "same private/single unfinished audit only",
    )
    for path in (
        str(evidence.PRIVATE),
        str(evidence.D_CONFIG),
        str(evidence.PACKET),
        str(evidence.PLAN),
    ):
        require(
            admission["bindings"][path] == bindings[path],
            "D lineage/private/config/packet identity changed",
        )
    require(
        Path(refs["guardian"]["path"]) == output / "saved-completion-result.json"
        and Path(refs["audit_receipt"]["path"]) == output / "audit.process.json"
        and Path(refs["audit_log"]["path"]) == output / "audit.log"
        and Path(refs["held_charges"]["path"]) == output / "held-charges.json",
        "exact saved-only outputs",
    )
    require(
        guardian["purpose"] == admission["purpose"]
        and guardian["provisional_only"] is True
        and guardian["external_completion_acceptance"] is False
        and guardian["primary_error"] is None
        and guardian["stage_failures"] == []
        and guardian["audit_process_cleanup_known"] is True
        and guardian["new_native_scientific_games"] == 0,
        "provisional/failed/unknown guardian cannot admit",
    )
    require(
        guardian["original_science"] == custody
        and guardian["clock_census"] == custody["clock_census"]
        and guardian["audit_summary"] == audit == science_objects["native_manifest"]["summary"],
        "actual raw-derived custody/census/audit summary",
    )
    receipt = objects["audit_receipt"]
    require(
        guardian["audit_receipt"] == receipt and worker.receipt_ok(receipt, command),
        "failed/truncated/unknown or wrong audit receipt",
    )
    returned = guardian["returned_audit_finalization"]
    require(
        returned["command"] == command
        and returned["child"] == receipt["child"]
        and returned["signal_mask_restoration"] == returned["final_record_persist"] == "completed"
        and returned["handle_closes_complete"] is True
        and returned["process_cleanup_complete"] is True
        and returned["finalization_errors"] == [],
        "actual returned completion vs persisted pending distinction",
    )
    from datetime import datetime

    require(
        datetime.fromisoformat(state["started_at"])
        <= datetime.fromisoformat(guardian["source_STOP"])
        <= datetime.fromisoformat(controller["finished_at"]),
        "new actual external STOP chronology",
    )
    require(
        audit["census"]["planned_games"] == 16
        and audit["bootstrap"]["seed"] == 331
        and audit["bootstrap"]["resamples"] == 2000,
        "maintained original deterministic audit, no changed estimator/denominator",
    )
    ledger = objects["held_charges"]
    prior = evidence.read_ref(
        {
            "path": admission["prior_charges"],
            "sha256": bindings[admission["prior_charges"]]["SHA256"],
        },
        bindings,
    )
    forecast = evidence.read_ref(
        {
            "path": admission["whole_forecast"],
            "sha256": bindings[admission["whole_forecast"]]["SHA256"],
        },
        bindings,
    )
    evidence.ledger(ledger, forecast, prior)
    return {
        "role": "D",
        "schema": "quoridor.derived-completed-D-saved-route.v1",
        "original_science_job_id": custody["science_job_id"],
        "original_science_controller_outcome": "FAILED retained",
        "original_lost_stdout": custody["old_full_capture"],
        "new_successful_completion_job_id": controller["job_id"],
        "controller_fingerprint": fingerprint,
        "controller_STOP": controller["finished_at"],
        "clock_census": custody["clock_census"],
        "slot_census": evidence.partial_census(science_objects["native_report"]["outcomes"]),
        "audit_summary": audit,
        "held_charges": refs["held_charges"],
        "identities": [*custody["identities"], state["child"], receipt["child"]],
        "new_scientific_games": 0,
        "original_expiry_unix_ms": 1791583340854,
        "full_old_capture_restored": False,
    }


def consume_completed_saved_D(proof_ref, admission, worker, evidence):
    proof = evidence.read_ref(proof_ref, admission["bindings"])
    require(
        proof.get("schema") == "quoridor.completed-D-saved-route.v1",
        "declaration or old failed completion cannot admit NNUE",
    )
    bundle = evidence.read_ref(proof["evidence_bundle"], admission["bindings"])
    derived = derive_completed_saved_D(bundle, admission["bindings"], worker, evidence)
    require(proof["derived"] == derived, "actual completed D must be independently re-derived")
    publication = proof["publication"]
    require(set(publication) == {"config", "state", "controller", "candidate"}, "publication refs")
    published = {
        key: evidence.read_ref(ref, admission["bindings"]) for key, ref in publication.items()
    }
    # Read explicitly by names; JSON object order is not an admission predicate.
    config, state, controller, candidate = (
        published[k] for k in ("config", "state", "controller", "candidate")
    )
    runtime = Path(publication["controller"]["path"]).parent
    require(
        all(Path(publication[k]["path"]) == runtime / (k + ".json") for k in ("config", "state"))
        and runtime.is_relative_to(evidence.ROOT)
        and Path(publication["controller"]["path"]) == runtime / "result.json",
        "same authoritative publication runtime",
    )
    require(
        candidate
        == {
            "schema": "quoridor.completed-D-saved-route-candidate.v1",
            "admitting": False,
            "evidence_bundle": proof["evidence_bundle"],
            "derived": derived,
        },
        "provisional candidate differs from actual derivation",
    )
    argv = config["argv"]
    require(
        config["issue"] == "quoridor-4lc.347.3"
        and config["goal_issue"] == "quoridor-4lc.347"
        and config["thread_id"] == evidence.THREAD
        and config["cwd"] == str(evidence.WT)
        and all(config[k] is None for k in ("end_at", "notify_until", "max_runtime_seconds"))
        and argv[:3] == ["/usr/bin/python3.11", "-B", str(Path(__file__).resolve())]
        and argv[3:]
        == [
            "--control",
            config["resource_contract"],
            "--control-sha256",
            admission["bindings"][config["resource_contract"]]["SHA256"],
            "--bundle",
            proof["evidence_bundle"]["path"],
            "--bundle-sha256",
            proof["evidence_bundle"]["sha256"],
            "--output",
            publication["candidate"]["path"],
        ],
        "exact saved publication owner/source/argv",
    )
    fingerprint = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
    require(
        state["job_id"] == controller["job_id"]
        and state["config_sha256"] == fingerprint
        and state["issue"] == config["issue"]
        and state["thread_id"] == evidence.THREAD
        and state["phase"] == "finished"
        and state["outcome"] == controller["outcome"] == "succeeded"
        and controller["error"] is None
        and type(controller["exit_code"]) is int
        and controller["exit_code"] == 0
        and controller["direct_child_reaped"] is True
        and controller["cleanup_complete"] is True
        and controller["remaining"] == controller["cleanup_errors"] == []
        and controller["descendant_visibility"] == "observed"
        and type(controller["log_bytes_seen"]) is int
        and type(controller["log_bytes_retained"]) is int
        and 0 <= controller["log_bytes_seen"] == controller["log_bytes_retained"],
        "publication candidate alone or failed/unknown finalization cannot admit",
    )
    from datetime import datetime

    require(
        datetime.fromisoformat(derived["controller_STOP"])
        <= datetime.fromisoformat(state["started_at"])
        <= datetime.fromisoformat(controller["finished_at"]),
        "publication must follow actual audit completion",
    )
    derived["identities"].append(state["child"])
    return derived


def main():
    """Saved publication after authoritative completion; no native execution."""
    import argparse
    import fcntl
    import importlib.util
    import os
    import resource

    parser = argparse.ArgumentParser()
    parser.add_argument("--control", required=True)
    parser.add_argument("--control-sha256", required=True)
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--bundle-sha256", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    raw = Path(args.control).read_bytes()
    require(hashlib.sha256(raw).hexdigest() == args.control_sha256, "saved publication control SHA")
    a = json.loads(raw)
    require(
        a["purpose"] == "completed-D-publication"
        and a["actual_entry"] is True
        and a["prepared_only"] is False
        and a["pending_obligations"] == [],
        "prepared publication refuses before imports",
    )
    root = Path(__file__).resolve().parents[1]
    require(
        a["cohort_worker"] == str(root / "saved-control-repair-v23/cohort_worker.py")
        and a["helper"] == str(root / "canonical-config-repair-v11/live_worker.py")
        and a["evidence_helper"] == str(root / "cohort-repair-v18/cohort_evidence.py"),
        "fixed publication interfaces",
    )
    require(
        a["bindings"][str(Path(__file__).resolve())] == file_record(__file__), "consumer source"
    )

    def load(path, name):
        require(a["bindings"][path] == file_record(path), "bound source before import")
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    W = load(a["cohort_worker"], "saved_completion_checks")
    W.review_and_fixed_proofs(a)
    target = json.loads(Path(a["source_review"]["target_path"]).read_bytes())
    for path in (str(Path(__file__).resolve()), str(Path(__file__).with_name("saved_D_worker.py"))):
        require(
            target["selected_refs"].get(path) == a["bindings"].get(path), "reviewed saved route"
        )
    require(a["required_imports"] == W.REQUIRED_IMPORTS, "fixed publication import membership")
    for path, record in W.REQUIRED_IMPORTS.items():
        require(a["bindings"].get(path) == record, "publication package identity")
    L = load(a["helper"], "saved_publication_guard")
    L.quiet()
    L.physical()
    lease = W.LOCK.open("r+")
    publication_primary = None
    try:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        L.quiet()
        L.physical()
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
        for path, record in a["bindings"].items():
            W.verify(path, record)
        E = load(a["evidence_helper"], "saved_evidence_checks")
        G = load(str(Path(__file__).with_name("saved_D_worker.py")), "saved_forward_support")
        require(
            target["selected_refs"].get(a["forward_support"])
            == a["bindings"].get(a["forward_support"]),
            "publication forward support membership",
        )
        prior = E.read_ref(
            {"path": a["prior_charges"], "sha256": a["bindings"][a["prior_charges"]]["SHA256"]},
            a["bindings"],
        )
        G.forward_support(json.loads(Path(a["forward_support"]).read_bytes()), prior)
        bundle_ref = {"path": args.bundle, "sha256": args.bundle_sha256}
        bundle = E.read_ref(bundle_ref, a["bindings"])
        derived = derive_completed_saved_D(bundle, a["bindings"], W, E)
        import sys

        sys.path.insert(0, "/workspaces/quoridor/python")
        from quoridor_training import cycle_process as P

        require(
            not any(P.alive(i) for i in derived["identities"]), "exact stopped identities alive"
        )
        output = Path(args.output)
        require(
            output.is_relative_to(Path(__file__).resolve().parent)
            and output.parent.resolve() == output.parent
            and not output.exists()
            and not output.is_symlink(),
            "new owned completed-D publication",
        )
        payload = {
            "schema": "quoridor.completed-D-saved-route-candidate.v1",
            "admitting": False,
            "evidence_bundle": bundle_ref,
            "derived": derived,
        }
        raw = (json.dumps(payload, indent=2) + "\n").encode()
        require(len(raw) <= 1048576, "declared publication control upper")
        stream = output.open("xb")
        write_primary = None
        try:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        except BaseException as primary:
            write_primary = primary
            raise
        finally:
            try:
                stream.close()
            except BaseException as secondary:
                if write_primary is not None:
                    write_primary.add_note("publication_stream_close: " + repr(secondary))
                    raise write_primary
                raise
    except BaseException as primary:
        publication_primary = primary
        raise
    finally:
        try:
            lease.close()
        except BaseException as secondary:
            if publication_primary is not None:
                publication_primary.add_note("publication_lease_close: " + repr(secondary))
                raise publication_primary
            raise
    print(json.dumps({"completed_D": str(output), "SHA256": file_record(output)["SHA256"]}))


def file_record(path):
    p = Path(path)
    info = p.lstat()
    require(stat.S_ISREG(info.st_mode) and p.resolve() == p, "canonical source or output")
    return {
        "SHA256": hashlib.sha256(p.read_bytes()).hexdigest(),
        "bytes": info.st_size,
        "mode": stat.S_IMODE(info.st_mode),
    }


if __name__ == "__main__":
    main()
