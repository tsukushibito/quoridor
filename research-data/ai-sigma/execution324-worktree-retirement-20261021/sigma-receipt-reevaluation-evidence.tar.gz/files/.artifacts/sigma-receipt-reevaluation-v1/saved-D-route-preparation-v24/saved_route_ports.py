"""New saved-audit main ports and completed-route negative evidence; native calls zero."""

from contextlib import ExitStack
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROGRESS = []


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def put(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value) + "\n")
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def refusal(action):
    try:
        action()
    except (ValueError, KeyError, TypeError, RuntimeError):
        return
    raise AssertionError("unaccepted evidence unexpectedly admitted")


def main_port(G, W, origin=False, fault=None):
    with tempfile.TemporaryDirectory(dir=HERE / "ports-TMP") as temp:
        root = Path(temp)
        out, tmp = root / "out", root / "tmp"
        baseline = root / "prior.json"
        put(baseline, [])
        proof = root / "resources.json"
        put(proof, {"new_whole_B": 4294967296, "components_B": {"synthetic": 4294967296}})
        forecast = root / "forecast.json"
        put(
            forecast,
            {
                "supported_whole_B": 4294967296,
                "all_original_component_uppers_B": {"synthetic": 4294967296},
                "resource_proof": {"path": str(proof)},
            },
        )
        target = root / "target.json"
        selected = {
            str(HERE / "saved_D_worker.py"): {},
            str(HERE / "stopped_science.py"): {},
            str(HERE / "forward-support.prepared.json"): {},
        }
        put(target, {"selected_refs": selected})
        admission = {
            "actual_entry": True,
            "prepared_only": False,
            "pending_obligations": [],
            "purpose": "unfinished-saved-D-audit",
            "whole_B": 4294967296,
            "cohort_worker": str(ROOT / "saved-control-repair-v23/cohort_worker.py"),
            "source_review": {"target_path": str(target)},
            "science_reader": str(HERE / "stopped_science.py"),
            "helper": str(ROOT / "canonical-config-repair-v11/live_worker.py"),
            "evidence_helper": str(ROOT / "cohort-repair-v18/cohort_evidence.py"),
            "required_imports": W.REQUIRED_IMPORTS,
            "native_log_max_bytes": 8388608,
            "whole_forecast": str(ROOT / "cohort-repair-v18/whole-forecast-v18.json"),
            "forward_support": str(HERE / "forward-support.prepared.json"),
            "prior_charges": str(baseline),
            "private": "same-private",
            "native_output": "already-stopped-D",
            "audit_argv": ["same-private", "arena", "--audit", "already-stopped-D"],
            "output": str(out),
            "TMP": str(tmp),
            "environment": {},
        }
        admission["bindings"] = {
            **selected,
            **{
                p: {}
                for p in [
                    admission["cohort_worker"],
                    admission["helper"],
                    admission["evidence_helper"],
                    *W.REQUIRED_IMPORTS,
                ]
            },
        }
        raw_worker = Path(admission["cohort_worker"]).read_bytes()
        admission["bindings"][admission["cohort_worker"]] = {
            "SHA256": hashlib.sha256(raw_worker).hexdigest()
        }
        ap = root / "admission.json"
        reference = put(ap, admission)
        pins = {0, 2}
        commands, actions = [], []
        summary = {"census": {"planned_games": 16}, "bootstrap": {"seed": 331, "resamples": 2000}}
        custody = {"identities": []}
        objects = {
            "science_admission": {"private": "same-private"},
            "D_config": {"output": "already-stopped-D"},
            "native_manifest": {"summary": summary},
            "native_report": {},
        }

        def physical():
            assert pins == {0, 2}

        def affinity(pid, value):
            nonlocal pins
            pins = set(value)

        def verify(*args):
            if commands and fault == "source_after":
                raise OSError("synthetic source-after failure")

        class Lease:
            def close(self):
                actions.append("lease_close")
                if fault == "lease_close":
                    raise OSError("synthetic late close")

        class Base:
            def __init__(self, config, output, deadline):
                self.memory_limit = config["max_memory_bytes"]
                assert config["max_output_bytes"] == 9437184

            def check(self, owned=()):
                if commands and fault == "final_resources":
                    raise OSError("synthetic final resources")

        def execute(argv, log, deadline, **kwargs):
            assert argv == admission["audit_argv"] and not commands
            assert pins == {2} and kwargs["cpu_core"] == 0
            assert package.cycle_process.LOG_MAX_BYTES == 8388608
            commands.append(argv)
            if origin:
                raise ValueError("synthetic originating audit refusal")
            receipt = {
                "command": argv,
                "exit_code": 0,
                "direct_child_reaped": True,
                "cleanup_complete": True,
                "remaining": [],
                "process_cleanup_complete": True,
                "handle_closes_complete": True,
                "finalization_errors": [],
                "log_bytes_seen": 100,
                "log_bytes_retained": 100,
                "signal_mask_restoration": "completed",
                "final_record_persist": "completed",
                "child": {"pid": 99999999, "start_ticks": "0", "boot_id": "synthetic"},
            }
            put(log, summary)
            disk = {
                **receipt,
                "signal_mask_restoration": "pending",
                "final_record_persist": "attempted",
            }
            if fault == "malformed_receipt":
                disk = [1]
            put(log.with_suffix(".process.json"), disk)
            return receipt

        def write(path, obj):
            stage = "held_charges" if path.name == "held-charges.json" else "provisional_result"
            actions.append(stage)
            if fault == stage:
                raise OSError("synthetic " + stage)
            put(path, obj)

        def diagnostic(*args, **kwargs):
            actions.append("diagnostic")
            if fault == "diagnostic":
                raise OSError("synthetic diagnostic")

        real_exists = Path.exists

        def exists(path):
            if path == tmp and commands and fault == "TMP_availability":
                raise OSError("synthetic TMP stat")
            return real_exists(path)

        fakeW = SimpleNamespace(
            REQUIRED_IMPORTS=W.REQUIRED_IMPORTS,
            LOCK=SimpleNamespace(open=lambda *x: Lease()),
            review_and_fixed_proofs=lambda a: None,
            verify=verify,
            receipt_ok=W.receipt_ok,
            receipt_cleanup_ok=W.receipt_cleanup_ok,
            physical_before_child=W.physical_before_child,
            clock_census=lambda report: {"cost_disproved": 0},
        )
        fakeE = SimpleNamespace(
            BASELINE=baseline,
            ledger=lambda rows, *args: {
                (r["component"], r["path"]): r["maximum_sampled_allocated_B"] for r in rows
            },
            rows=lambda maxima: [
                {"component": k, "path": p, "maximum_sampled_allocated_B": v}
                for (k, p), v in maxima.items()
            ],
        )
        fakeH = SimpleNamespace(
            read_stopped_inputs=lambda: (objects, {}), stopped_custody=lambda *x: custody
        )
        fakeL = SimpleNamespace(quiet=lambda: None, physical=physical)
        package = ModuleType("quoridor_training")
        package.__path__ = []
        package.cycle_process = SimpleNamespace(
            LOG_MAX_BYTES=1048576,
            CycleResources=Base,
            execute=execute,
            process_info=lambda pid: {"rss": 0},
            alive=lambda i: False,
            CycleStopped=RuntimeError,
        )
        snapshot = ModuleType("quoridor_training.snapshot")
        snapshot.write_json = write
        imports = {
            admission["cohort_worker"]: fakeW,
            admission["helper"]: fakeL,
            admission["evidence_helper"]: fakeE,
            admission["science_reader"]: fakeH,
        }
        error = None
        with ExitStack() as stack:
            for item in [
                patch.object(G, "imported", lambda path, name: imports[str(path)]),
                patch.object(G.fcntl, "flock", lambda *x: None),
                patch.object(G.os, "sched_setaffinity", affinity),
                patch.object(G.os, "sched_getaffinity", lambda pid: pins),
                patch.object(G, "print", diagnostic, create=True),
                patch.object(Path, "exists", exists),
                patch.object(
                    sys, "argv", [str(HERE / "saved_D_worker.py"), str(ap), reference["sha256"]]
                ),
                patch.dict(
                    sys.modules,
                    {"quoridor_training": package, "quoridor_training.snapshot": snapshot},
                ),
            ]:
                stack.enter_context(item)
            try:
                G.main()
            except BaseException as exc:
                error = exc
        assert len(commands) == 1, repr(error)
        assert actions[-1] == "lease_close"
        assert all(
            stage in actions
            for stage in ("held_charges", "provisional_result", "diagnostic", "lease_close")
        )
        if origin:
            assert (
                isinstance(error, ValueError)
                and str(error) == "synthetic originating audit refusal"
            )
            terminal = json.loads(error.__notes__[-1])
            assert terminal["external_completion_acceptance"] is False
            if fault:
                assert fault in str(terminal)
        elif fault:
            fault = "owned_empty_TMP" if fault == "TMP_availability" else fault
            assert error is not None
            assert (
                fault in str(error)
                or fault in str(getattr(error, "__notes__", []))
                or fault == "malformed_receipt"
            )
        else:
            assert error is None
            result = json.loads((out / "saved-completion-result.json").read_bytes())
            assert result["provisional_only"] and not result["external_completion_acceptance"]
            assert result["new_native_scientific_games"] == 0
            assert result["returned_audit_finalization"]["signal_mask_restoration"] == "completed"
            assert result["audit_receipt"]["signal_mask_restoration"] == "pending"
        PROGRESS.append("saved_audit_main/" + str(origin) + "/" + str(fault))


def main():
    W = load(ROOT / "saved-control-repair-v23/cohort_worker.py", "unchanged23checks")
    G = load(HERE / "saved_D_worker.py", "new_saved_audit_guard24")
    for fault in (
        None,
        "source_after",
        "final_resources",
        "held_charges",
        "malformed_receipt",
        "TMP_availability",
        "provisional_result",
        "diagnostic",
        "lease_close",
    ):
        main_port(G, W, False, fault)
    for fault in (
        None,
        "source_after",
        "final_resources",
        "held_charges",
        "provisional_result",
        "diagnostic",
        "lease_close",
    ):
        main_port(G, W, True, fault)
    H = load(HERE / "stopped_science.py", "new_saved_completion24")
    E = load(ROOT / "cohort-repair-v18/cohort_evidence.py", "retained_ledger18")
    completion_ports(H, W, E)
    new_fixed_inlet_ports(G, H)
    publication_main_ports(H, W)
    new_forward_ports(G)
    print(
        json.dumps(
            {
                "new_cases": PROGRESS,
                "passed": len(PROGRESS),
                "real_Popen_native_model_geometry_game": 0,
            }
        )
    )


def completion_ports(H, W, E):
    """Synthetic external records exercise new derivation/consumer, not native audit."""
    with tempfile.TemporaryDirectory(dir=HERE / "ports-TMP") as temp:
        root = Path(temp)
        runtime = root / "audit-runtime"
        output = root / "audit-output"
        pub = root / "publication-runtime"
        record = E.record
        bindings = {}

        def save(path, obj):
            ref = put(path, obj)
            bindings[str(path)] = record(path)
            return ref

        summary = {
            "census": {"planned_games": 16, "unknown_games": 16},
            "bootstrap": {"seed": 331, "resamples": 2000},
        }
        custody = {
            "science_job_id": "19524ce5-8edf-4d1c-a8c2-113f095efa3b",
            "old_full_capture": {"arena": {"lost_prefix": "UNKNOWN"}},
            "clock_census": {"cost_disproved": 0},
            "identities": [],
        }
        science = {
            "D_config": {"output": "fixed-stopped-D"},
            "native_manifest": {"summary": summary},
            "native_report": {
                "outcomes": [
                    {"game": i, "status": "unknown", "failure": "ply_cap", "observations": []}
                    for i in range(16)
                ]
            },
        }
        source_paths = [str(HERE / "stopped_science.py"), str(HERE / "saved_D_worker.py")]
        for path in source_paths:
            bindings[path] = record(path)
        lineage = {
            str(p): {"SHA256": "synthetic-retained-identity", "bytes": 1, "mode": 0o644}
            for p in (E.PRIVATE, E.D_CONFIG, E.PACKET, E.PLAN)
        }
        bindings.update(lineage)
        target_ref = save(
            root / "target.json", {"selected_refs": {p: bindings[p] for p in source_paths}}
        )
        control_ref = save(root / "review.json", {"control_clear": True})
        prior_ref = save(root / "prior.json", [])
        forecast_ref = save(root / "forecast.json", {})
        admission = {
            "purpose": "unfinished-saved-D-audit",
            "actual_entry": True,
            "prepared_only": False,
            "pending_obligations": [],
            "source_review": {
                "target_path": target_ref["path"],
                "target_SHA256": target_ref["sha256"],
                "control_path": control_ref["path"],
                "control_SHA256": control_ref["sha256"],
            },
            "private": str(E.PRIVATE),
            "audit_argv": [str(E.PRIVATE), "arena", "--audit", "fixed-stopped-D"],
            "native_output": "fixed-stopped-D",
            "native_log_max_bytes": 8388608,
            "output": str(output),
            "bindings": deepcopy(bindings),
            "prior_charges": prior_ref["path"],
            "whole_forecast": forecast_ref["path"],
        }
        admission_ref = save(root / "actual-admission.json", admission)
        config = {
            "issue": "quoridor-4lc.347.3",
            "goal_issue": "quoridor-4lc.347",
            "thread_id": E.THREAD,
            "cwd": str(E.WT),
            "resource_contract": admission_ref["path"],
            "argv": [
                "/usr/bin/python3.11",
                "-B",
                str(HERE / "saved_D_worker.py"),
                admission_ref["path"],
                admission_ref["sha256"],
            ],
            "end_at": None,
            "notify_until": None,
            "max_runtime_seconds": None,
        }
        state = {
            "job_id": "synthetic-new-audit",
            "config_sha256": hashlib.sha256(
                json.dumps(config, sort_keys=True).encode()
            ).hexdigest(),
            "issue": config["issue"],
            "thread_id": E.THREAD,
            "phase": "finished",
            "outcome": "succeeded",
            "started_at": "2026-10-09T12:00:00+00:00",
            "child": {"pid": 99999997, "start_ticks": "0", "boot_id": "synthetic"},
        }
        controller = {
            "job_id": state["job_id"],
            "outcome": "succeeded",
            "error": None,
            "exit_code": 0,
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
            "cleanup_errors": [],
            "descendant_visibility": "observed",
            "log_bytes_seen": 100,
            "log_bytes_retained": 100,
            "finished_at": "2026-10-09T12:00:02+00:00",
        }
        receipt = {
            "command": admission["audit_argv"],
            "exit_code": 0,
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
            "process_cleanup_complete": True,
            "handle_closes_complete": True,
            "finalization_errors": [],
            "log_bytes_seen": 100,
            "log_bytes_retained": 100,
            "child": {"pid": 99999998, "start_ticks": "0", "boot_id": "synthetic"},
        }
        returned = {
            **receipt,
            "signal_mask_restoration": "completed",
            "final_record_persist": "completed",
        }
        guardian = {
            "purpose": admission["purpose"],
            "provisional_only": True,
            "external_completion_acceptance": False,
            "primary_error": None,
            "stage_failures": [],
            "audit_process_cleanup_known": True,
            "new_native_scientific_games": 0,
            "original_science": custody,
            "clock_census": custody["clock_census"],
            "audit_summary": summary,
            "audit_receipt": receipt,
            "returned_audit_finalization": returned,
            "source_STOP": "2026-10-09T12:00:01+00:00",
        }
        objects = {
            "admission": admission,
            "config": config,
            "state": state,
            "controller": controller,
            "guardian": guardian,
            "audit_receipt": receipt,
            "audit_log": summary,
            "held_charges": [],
            "review_target": {"selected_refs": {p: bindings[p] for p in source_paths}},
            "review_control": {"control_clear": True},
        }
        refs = {
            "admission": admission_ref,
            "config": save(runtime / "config.json", config),
            "state": save(runtime / "state.json", state),
            "controller": save(runtime / "result.json", controller),
            "guardian": save(output / "saved-completion-result.json", guardian),
            "audit_receipt": save(output / "audit.process.json", receipt),
            "audit_log": save(output / "audit.log", summary),
            "held_charges": save(output / "held-charges.json", []),
            "review_target": target_ref,
            "review_control": control_ref,
        }
        bundle = {"schema": "quoridor.completed-D-saved-route-input.v1", "references": refs}
        fakeE = SimpleNamespace(
            ROOT=E.ROOT,
            WT=E.WT,
            THREAD=E.THREAD,
            PRIVATE=E.PRIVATE,
            D_CONFIG=E.D_CONFIG,
            PACKET=E.PACKET,
            PLAN=E.PLAN,
            read_ref=E.read_ref,
            record=E.record,
            partial_census=E.partial_census,
            ledger=lambda *args: {},
        )
        fakeW = SimpleNamespace(
            review_and_fixed_proofs=lambda a: None,
            clock_census=W.clock_census,
            receipt_cleanup_ok=W.receipt_cleanup_ok,
            receipt_ok=W.receipt_ok,
        )
        with (
            patch.object(H, "read_stopped_inputs", lambda: (science, {})),
            patch.object(H, "stopped_custody", lambda *args: deepcopy(custody)),
        ):
            derived = H.derive_completed_saved_D(bundle, bindings, fakeW, fakeE)
            assert derived["slot_census"]["typed_observed_status"]["unknown"] == 16
            assert derived["original_science_controller_outcome"] == "FAILED retained"
            assert derived["full_old_capture_restored"] is False
            PROGRESS.append("completion_join/typed_unknown_synthetic_success")
            cases = [
                ("controller", "outcome", "failed"),
                ("controller", "cleanup_complete", False),
                ("controller", "remaining", None),
                ("controller", "log_bytes_retained", 99),
                ("controller", "exit_code", False),
                ("guardian", "primary_error", {"type": "OSError"}),
                ("guardian", "stage_failures", [{"stage": "lease_close", "message": "failure"}]),
                ("guardian", "audit_process_cleanup_known", False),
                ("guardian", "external_completion_acceptance", True),
                ("audit_receipt", "log_bytes_retained", 99),
                ("audit_receipt", "command", ["wrong-audit"]),
                ("state", "config_sha256", "raw-file-digest"),
                ("state", "job_id", "19524ce5-8edf-4d1c-a8c2-113f095efa3b"),
            ]
            for key, field, value in cases:
                previous = deepcopy(objects[key])
                modified = {**objects[key], field: value}
                original_ref = refs[key]
                refs[key] = save(Path(original_ref["path"]), modified)
                refusal(lambda: H.derive_completed_saved_D(bundle, bindings, fakeW, fakeE))
                refs[key] = save(Path(original_ref["path"]), previous)
                PROGRESS.append("completion_join/refusal/" + key + "/" + field)
            bundle_ref = save(root / "bundle.json", bundle)
            candidate = {
                "schema": "quoridor.completed-D-saved-route-candidate.v1",
                "admitting": False,
                "evidence_bundle": bundle_ref,
                "derived": derived,
            }
            candidate_ref = save(root / "candidate.json", candidate)
            pubconfig = {
                **config,
                "resource_contract": admission_ref["path"],
                "argv": [
                    "/usr/bin/python3.11",
                    "-B",
                    str(HERE / "stopped_science.py"),
                    "--control",
                    admission_ref["path"],
                    "--control-sha256",
                    admission_ref["sha256"],
                    "--bundle",
                    bundle_ref["path"],
                    "--bundle-sha256",
                    bundle_ref["sha256"],
                    "--output",
                    candidate_ref["path"],
                ],
            }
            pubstate = {
                **state,
                "job_id": "synthetic-new-publication",
                "started_at": "2026-10-09T12:00:03+00:00",
                "config_sha256": hashlib.sha256(
                    json.dumps(pubconfig, sort_keys=True).encode()
                ).hexdigest(),
            }
            pubcontroller = {
                **controller,
                "job_id": pubstate["job_id"],
                "finished_at": "2026-10-09T12:00:04+00:00",
            }
            pubrefs = {
                "config": save(pub / "config.json", pubconfig),
                "state": save(pub / "state.json", pubstate),
                "controller": save(pub / "result.json", pubcontroller),
                "candidate": candidate_ref,
            }
            proof = {
                "schema": "quoridor.completed-D-saved-route.v1",
                "evidence_bundle": bundle_ref,
                "derived": derived,
                "publication": pubrefs,
            }
            proof_ref = save(root / "completed-proof.json", proof)
            nn = {"bindings": bindings}
            result = H.consume_completed_saved_D(proof_ref, nn, fakeW, fakeE)
            assert result["identities"][-1] == pubstate["child"]
            PROGRESS.append("NN_consumer/actual_synthetic_publication_success")
            for field, value in [
                ("outcome", "failed"),
                ("cleanup_complete", False),
                ("remaining", None),
                ("log_bytes_retained", 99),
            ]:
                pubrefs["controller"] = save(pub / "result.json", {**pubcontroller, field: value})
                proof_ref = save(root / "completed-proof.json", proof)
                refusal(lambda: H.consume_completed_saved_D(proof_ref, nn, fakeW, fakeE))
                PROGRESS.append("NN_consumer/publication_refusal/" + field)
            pubrefs["controller"] = save(pub / "result.json", pubcontroller)
            proof_ref = save(
                root / "completed-proof.json", {"schema": "declared-positive", "accepted": True}
            )
            refusal(lambda: H.consume_completed_saved_D(proof_ref, nn, fakeW, fakeE))
            PROGRESS.append("NN_consumer/declaration_refusal")


def new_fixed_inlet_ports(G, H):
    """Exercise the added mandatory interfaces before any project imports."""

    class ReachedImport(Exception):
        pass

    with tempfile.TemporaryDirectory(dir=HERE / "ports-TMP") as temp:
        root = Path(temp)
        required = {
            "cohort_worker": str(ROOT / "saved-control-repair-v23/cohort_worker.py"),
            "science_reader": str(HERE / "stopped_science.py"),
            "evidence_helper": str(ROOT / "cohort-repair-v18/cohort_evidence.py"),
            "helper": str(ROOT / "canonical-config-repair-v11/live_worker.py"),
            "whole_forecast": str(ROOT / "cohort-repair-v18/whole-forecast-v18.json"),
        }
        a = {
            **required,
            "purpose": "unfinished-saved-D-audit",
            "whole_B": 4294967296,
            "actual_entry": True,
            "prepared_only": False,
            "pending_obligations": [],
            "bindings": {required["cohort_worker"]: H.file_record(required["cohort_worker"])},
        }

        def reached(*args):
            raise ReachedImport("first import reached")

        for key in (None, *required):
            changed = deepcopy(a)
            if key:
                changed[key] = "unreviewed-selected-alias"
            ref = put(root / "guard-admission.json", changed)
            with (
                patch.object(
                    sys, "argv", [str(HERE / "saved_D_worker.py"), ref["path"], ref["sha256"]]
                ),
                patch.object(G, "imported", reached),
            ):
                if key:
                    refusal(G.main)
                else:
                    try:
                        G.main()
                    except ReachedImport:
                        pass
                    else:
                        raise AssertionError("missing first import boundary")
            PROGRESS.append("new_fixed_audit_inlet/" + str(key))
        pub = {
            **required,
            "purpose": "completed-D-publication",
            "actual_entry": True,
            "prepared_only": False,
            "pending_obligations": [],
            "bindings": {
                str(HERE / "stopped_science.py"): H.file_record(HERE / "stopped_science.py"),
                required["cohort_worker"]: H.file_record(required["cohort_worker"]),
            },
        }
        for key in (None, "actual_entry", "purpose", "cohort_worker", "helper", "evidence_helper"):
            changed = deepcopy(pub)
            if key:
                changed[key] = False if key == "actual_entry" else "invalid-interface"
            ref = put(root / "publication-control.json", changed)
            argv = [
                str(HERE / "stopped_science.py"),
                "--control",
                ref["path"],
                "--control-sha256",
                ref["sha256"],
                "--bundle",
                "not-read",
                "--bundle-sha256",
                "not-read",
                "--output",
                "not-created",
            ]
            with (
                patch.object(sys, "argv", argv),
                patch.object(importlib.util, "spec_from_file_location", reached),
            ):
                if key:
                    refusal(H.main)
                else:
                    try:
                        H.main()
                    except ReachedImport:
                        pass
                    else:
                        raise AssertionError("missing publication import boundary")
            PROGRESS.append("new_fixed_publication_inlet/" + str(key))


def publication_main_ports(H, W):
    """New publisher refuses success after late finalizer failure; candidate stays nonadmitting."""
    for fault in (None, "lease_close", "write_and_close"):
        with tempfile.TemporaryDirectory(dir=HERE / "ports-TMP") as temp:
            root = Path(temp)
            output = root / "candidate.json"
            target = root / "target.json"
            source_paths = [str(HERE / "stopped_science.py"), str(HERE / "saved_D_worker.py")]
            records = {p: H.file_record(p) for p in source_paths}
            records[str(HERE / "forward-support.prepared.json")] = H.file_record(
                HERE / "forward-support.prepared.json"
            )
            put(target, {"selected_refs": records})
            a = {
                "purpose": "completed-D-publication",
                "forward_support": str(HERE / "forward-support.prepared.json"),
                "prior_charges": str(root / "prior.json"),
                "actual_entry": True,
                "prepared_only": False,
                "pending_obligations": [],
                "cohort_worker": str(ROOT / "saved-control-repair-v23/cohort_worker.py"),
                "helper": str(ROOT / "canonical-config-repair-v11/live_worker.py"),
                "evidence_helper": str(ROOT / "cohort-repair-v18/cohort_evidence.py"),
                "source_review": {"target_path": str(target)},
                "required_imports": W.REQUIRED_IMPORTS,
                "bindings": {**records, **W.REQUIRED_IMPORTS},
            }
            for p in (a["cohort_worker"], a["helper"], a["evidence_helper"]):
                a["bindings"][p] = H.file_record(p)
            put(root / "prior.json", [])
            a["bindings"][str(root / "prior.json")] = H.file_record(root / "prior.json")
            ref = put(root / "control.json", a)
            calls = []

            class Lease:
                def fileno(self):
                    return 0

                def close(self):
                    calls.append("lease_close")
                    if fault:
                        raise OSError("synthetic publication close")

            fakeW = SimpleNamespace(
                LOCK=SimpleNamespace(open=lambda *x: Lease()),
                REQUIRED_IMPORTS=W.REQUIRED_IMPORTS,
                review_and_fixed_proofs=lambda a: None,
                verify=lambda *x: None,
            )
            modules = {
                a["cohort_worker"]: fakeW,
                a["helper"]: SimpleNamespace(quiet=lambda: None, physical=lambda: None),
                a["evidence_helper"]: SimpleNamespace(
                    read_ref=lambda ref, *x: []
                    if ref["path"] == str(root / "prior.json")
                    else {"synthetic": True}
                ),
                str(HERE / "saved_D_worker.py"): load(
                    HERE / "saved_D_worker.py", "current_forward_test"
                ),
            }

            class Loader:
                def __init__(self, obj):
                    self.obj = obj

                def create_module(self, spec):
                    return None

                def exec_module(self, module):
                    module.__dict__.update(vars(self.obj))

            def spec(name, path):
                return importlib.util.spec_from_loader(name, Loader(modules[str(path)]))

            package = ModuleType("quoridor_training")
            package.__path__ = []
            package.cycle_process = SimpleNamespace(alive=lambda i: False)
            argv = [
                str(HERE / "stopped_science.py"),
                "--control",
                ref["path"],
                "--control-sha256",
                ref["sha256"],
                "--bundle",
                "synthetic-bundle",
                "--bundle-sha256",
                "synthetic-sha",
                "--output",
                str(output),
            ]
            real_open = Path.open

            def opening(path, *args, **kwargs):
                if path == output and fault == "write_and_close":
                    raise ValueError("synthetic publication write")
                return real_open(path, *args, **kwargs)

            error = None
            with (
                patch.object(sys, "argv", argv),
                patch.object(importlib.util, "spec_from_file_location", spec),
                patch.object(H, "derive_completed_saved_D", lambda *x: {"identities": []}),
                patch.object(H.fcntl, "flock", lambda *x: None, create=True)
                if hasattr(H, "fcntl")
                else patch("fcntl.flock", lambda *x: None),
                patch.dict(sys.modules, {"quoridor_training": package}),
                patch.object(Path, "open", opening),
            ):
                try:
                    H.main()
                except BaseException as exc:
                    error = exc
            assert calls == ["lease_close"]
            if fault == "write_and_close":
                assert isinstance(error, ValueError) and str(error) == "synthetic publication write"
                assert "publication_lease_close" in error.__notes__[-1]
                assert not output.exists()
            else:
                assert json.loads(output.read_bytes())["admitting"] is False
                assert (error is None) == (fault is None)
            PROGRESS.append("publication_main/" + str(fault))


def new_forward_ports(G):
    support = json.loads((HERE / "forward-support.prepared.json").read_bytes())
    G.forward_support(support, [])
    PROGRESS.append("forward_support/fixed_uppers_success")
    cases = [
        ("D_forward_held_native_B", 1),
        ("saved_audit_owned_output_upper_B", 16777216),
        ("audit_stdout_upper_B", 1048576),
        ("D_remaining_guard_B", 0),
        ("retained_old_TMP_B", 0),
        ("retained_old_TMP_B", "5685248"),
        ("whole_B", True),
    ]
    for field, value in cases:
        refusal(lambda: G.forward_support({**support, field: value}, []))
        PROGRESS.append("forward_support/refusal/" + field)
    refusal(
        lambda: G.forward_support(
            support, [{"component": "TMP", "maximum_sampled_allocated_B": 536870912}]
        )
    )
    PROGRESS.append("forward_support/actual_retained_TMP_gap_refusal")


if __name__ == "__main__":
    main()
