"""Materialize false controls only; no private hashing, imports, jobs or native calls."""

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCE = ROOT / "cohort-entry-v21/admission-d.actual-v21.json"


def record(path):
    path = Path(path)
    info = path.lstat()
    return {
        "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": info.st_size,
        "mode": stat.S_IMODE(info.st_mode),
    }


def put(name, obj):
    (HERE / name).write_text(json.dumps(obj, indent=2) + "\n")


def main():
    old = json.loads(SOURCE.read_bytes())
    bindings = deepcopy(old["bindings"])
    names = [
        *HERE.glob("*.py"),
        ROOT / "saved-control-repair-v23/cohort_worker.py",
        Path(
            "/workspaces/quoridor/.artifacts/sigma-receipt-review347-v1/saved-control-repair-v23/completion-control.json"
        ),
        Path(
            "/workspaces/quoridor/.artifacts/sigma-receipt-review347-v1/saved-control-repair-v23/findings.md"
        ),
        Path(
            "/workspaces/quoridor/research-data/ai-sigma/sigma-receipt-reevaluation-v1/saved-D-review-resources-v23.json"
        ),
    ]
    for p in names:
        bindings[str(p)] = record(p)
    protocol = json.loads((HERE / "fixed-input-protocol.prepared.json").read_bytes())
    for ref in protocol["strict_producer_input_references"].values():
        bindings[ref["path"]] = {k: ref[k] for k in ("SHA256", "bytes", "mode")}
    forecast = {
        "whole_B": 4294967296,
        "resource_proof": old["bindings"][
            "/workspaces/quoridor/research-data/ai-sigma/sigma-receipt-reevaluation-v1/resources.json"
        ],
        "resource_proof_path": "/workspaces/quoridor/research-data/ai-sigma/sigma-receipt-reevaluation-v1/resources.json",
        "all_old_component_caps_fees_RAW_maxima_masks_UNKNOWN": "HELD, no reset/refund/cache credit",
        "D_component_cap_B": 268435456,
        "D_forward_held_native_B": 224 * 1024**2,
        "D_three_native_log_uppers_B": [8388608] * 3,
        "D_three_controller_log_uppers_B": [1048576] * 3,
        "D_three_metadata_uppers_B": [1048576] * 3,
        "D_supported_forward_B": (224 + 24 + 3 + 3) * 1024**2,
        "D_remaining_guard_B": 2 * 1024**2,
        "audit_is_unfinished_third_native_log": True,
        "saved_audit_owned_output_upper_B": 9437184,
        "audit_stdout_upper_B": 8388608,
        "saved_audit_receipts_charges_guardian_metadata_upper_B": 1048576,
        "saved_audit_controller_log_upper_B": 1048576,
        "new_source_falsecontrols_ports_review_handoff_upper_B": 1048576,
        "source_controls_component": "controller_configs_logs existing256MiB",
        "publication_controller_candidate_descriptor_upper_B": 2097152,
        "publication_component": "controller_configs_logs existing256MiB",
        "prospective_audit_TMP_B": 67108864,
        "retained_old_TMP_B": 5685248,
        "serial_TMP_cap_B": 536870912,
        "retained_target_floor_B": 498405376,
        "separate_Main_helper_target_upper_B": 536870912,
        "separate_Main_helper_TMP_upper_B": 67108864,
        "held_joint_build_B": 1102385152,
        "build_component_cap_B": 2147483648,
        "no_additional_native_science_or_recovery_calls": True,
        "actual_entry": False,
    }
    assert (
        forecast["D_supported_forward_B"] + forecast["D_remaining_guard_B"]
        == forecast["D_component_cap_B"]
    )
    assert forecast["held_joint_build_B"] < forecast["build_component_cap_B"]
    assert (
        forecast["retained_old_TMP_B"] + forecast["prospective_audit_TMP_B"]
        < forecast["serial_TMP_cap_B"]
    )
    put("forward-support.prepared.json", forecast)
    bindings[str(HERE / "forward-support.prepared.json")] = record(
        HERE / "forward-support.prepared.json"
    )
    review = {
        "control_clear": False,
        "reader_STOP": None,
        "control_path": "PENDING same347.5 new saved route",
        "control_SHA256": None,
        "target_path": str(HERE / "source-review-target-v24.json"),
        "target_SHA256": None,
    }
    common = {
        "actual_entry": False,
        "prepared_only": True,
        "pending_obligations": [
            "actual current saved-route SOURCE_CLEAR+readerSTOP",
            "fresh whole component support/storage/source/private/library/physical/owner/peer/quiet and lifetime nonblocking lease",
        ],
        "cohort_worker": str(ROOT / "saved-control-repair-v23/cohort_worker.py"),
        "science_reader": str(HERE / "stopped_science.py"),
        "completed_D_reader": str(HERE / "stopped_science.py"),
        "helper": old["helper"],
        "evidence_helper": str(ROOT / "cohort-repair-v18/cohort_evidence.py"),
        "required_imports": old["required_imports"],
        "native_log_max_bytes": 8388608,
        "whole_B": 4294967296,
        "whole_forecast": str(ROOT / "cohort-repair-v18/whole-forecast-v18.json"),
        "forward_support": str(HERE / "forward-support.prepared.json"),
        "private": old["private"],
        "native_output": old["native_output"],
        "prior_charges": str(ROOT / "cohort-d-v1/control-recovery-v2/held-charges.json"),
        "environment": old["environment"],
        "bindings": bindings,
        "source_review": review,
    }
    audit = {
        **common,
        "purpose": "unfinished-saved-D-audit",
        "audit_argv": [old["private"], "arena", "--audit", old["native_output"]],
        "output": str(ROOT / "cohort-d-v1/saved-audit-control-v24"),
        "TMP": str(ROOT / "saved-audit-TMP-v24"),
    }
    put("saved-audit-admission.prepared-v24.json", audit)
    publication = {
        **common,
        "purpose": "completed-D-publication",
        "pending_obligations": [
            *common["pending_obligations"],
            "actual successful finalized new audit controller/raw bundle",
        ],
        "candidate_admitting": False,
    }
    put("publication-admission.prepared-v24.json", publication)
    nn = deepcopy(old)
    nn.update(
        role="NNUE",
        purpose="Sigma_vs_BEST51_16",
        actual_entry=False,
        prepared_only=True,
        pending_obligations=[
            "actual successful saved audit controller and publication controller/evidence re-derivation",
            "actual new source clear/stopped reader",
            "fresh own source/private/backend/cost expiry/whole/physical/peer/quiet/nonblocking lifetime lease",
        ],
        source_review=review,
        bindings=bindings,
        completed_D_reader=str(HERE / "stopped_science.py"),
        config=str(ROOT / "configuration-v2/config-nnue-16.fixed-v2.json"),
        output=str(ROOT / "cohort-nnue-v1/control-v24"),
        native_output=str(ROOT / "cohort-nnue-v1/run"),
        TMP=str(ROOT / "cohort-nnue-TMP-v24"),
        prior_charges="PENDING actual saved audit held ledger",
        preceding_completed_D=str(HERE / "completed-D-descriptor.actual.json"),
    )
    nn["commands"] = [
        [
            "arena",
            [
                old["private"],
                "arena",
                "--config",
                nn["config"],
                "--sigma-cost-qualification",
                old["packet"],
                "--qualification-sha256",
                bindings[old["packet"]]["SHA256"],
            ],
        ],
        ["audit", [old["private"], "arena", "--audit", nn["native_output"]]],
        ["recover", [old["private"], "arena", "--recover", nn["native_output"]]],
    ]
    put("NNUE-admission.prepared-v24.json", nn)
    for phase, script, control, suffix in (
        (
            "saved-audit",
            HERE / "saved_D_worker.py",
            HERE / "saved-audit-admission.prepared-v24.json",
            [],
        ),
        (
            "publication",
            HERE / "stopped_science.py",
            HERE / "publication-admission.prepared-v24.json",
            [
                "--bundle",
                str(HERE / "raw-completion-bundle.actual.json"),
                "--bundle-sha256",
                "PENDING actual finalized audit inputs",
                "--output",
                str(HERE / "candidate-D.actual.json"),
            ],
        ),
    ):
        prefix = ["/usr/bin/python3.11", "-B", str(script)]
        arguments = (
            [str(control), record(control)["SHA256"]]
            if phase == "saved-audit"
            else ["--control", str(control), "--control-sha256", record(control)["SHA256"], *suffix]
        )
        put(
            phase + "-job.prepared-v24.json",
            {
                "issue": "quoridor-4lc.347.3",
                "goal_issue": "quoridor-4lc.347",
                "thread_id": "01a11062-b120-73a1-8aa3-fe2cb922c7c0",
                "cwd": str(ROOT.parents[1]),
                "argv": prefix + arguments,
                "resource_contract": str(control),
                "end_at": None,
                "notify_until": None,
                "max_runtime_seconds": None,
                "control_interval_seconds": 15,
                "notify_interval_seconds": 10,
                "notify_request_timeout_seconds": 25,
                "log_max_bytes": 1048576,
                "submitted": False,
                "prepared_only": True,
            },
        )
    put(
        "preparation-facts.json",
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "purpose": "false controls only",
            "private_payload_hashes_reads": 0,
            "library_model_payload_reads": 0,
            "native_backend_Search_geometry_games": 0,
            "source_or_private_rebuild": 0,
            "audit": "NOT_RUN",
            "old19524": "FAILED immutable; all16 already executed once",
            "candidate_admitting": False,
            "NNUE": "NOT_ENTERED",
            "new_resource_scope_grant": False,
        },
    )


if __name__ == "__main__":
    main()
