"""Actual guardian AST with in-memory process/IO ports; no production import."""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import sys
import time
from types import ModuleType, SimpleNamespace

SOURCE = Path(__file__).with_name("live_worker.py")
TREE = ast.parse(SOURCE.read_text())
FUNCTIONS = {node.name: node for node in TREE.body if isinstance(node, ast.FunctionDef)}


def compile_function(name, ports):
    exec(compile(ast.Module(body=[FUNCTIONS[name]], type_ignores=[]), str(SOURCE), "exec"), ports)
    return ports[name]


def run_case(mode):
    memory, commands, publications = {}, [], []

    class FakePath:
        def __init__(self, value):
            self.value = str(value)

        def __str__(self):
            return self.value

        def __truediv__(self, name):
            return FakePath(self.value + "/" + name)

        def with_suffix(self, suffix):
            return FakePath(self.value.rsplit(".", 1)[0] + suffix)

        def read_bytes(self):
            return memory[self.value]

        def read_text(self):
            return self.read_bytes().decode()

        def open(self, _):
            def close():
                if mode == "lease-close":
                    raise OSError("controlled lease close failure")

            return SimpleNamespace(close=close, fileno=lambda: 7)

        def mkdir(self):
            memory[self.value] = None

        def exists(self):
            return self.value in memory

        def is_file(self):
            return self.exists() and memory[self.value] is not None

        def is_symlink(self):
            return False

        def stat(self):
            return self.lstat()

        def lstat(self):
            if not self.exists():
                raise FileNotFoundError(self.value)
            value = memory[self.value]
            return SimpleNamespace(
                st_mode=stat.S_IFDIR if value is None else stat.S_IFREG | 0o644,
                st_blocks=0,
                st_size=0 if value is None else len(value),
            )

        def iterdir(self):
            return [
                FakePath(name)
                for name in list(memory)
                if name.startswith(self.value + "/") and "/" not in name[len(self.value) + 1 :]
            ]

        def rmdir(self):
            if mode == "TMP":
                raise OSError("controlled TMP finalizer failure")
            assert not self.iterdir()
            del memory[self.value]

    def write_json(path, value):
        if mode == "charges" and str(path).endswith("held-charges.json"):
            raise OSError("controlled charge publication failure")
        if mode == "result" and str(path).endswith("live-result.json"):
            raise OSError("controlled guardian result publication failure")
        memory[str(path)] = json.dumps(value).encode()

    ad = {
        "actual_entry": True,
        "prepared_only": False,
        "helpers": {"materializer": "materializer"},
        "output": str(SOURCE.parent / "mock-output"),
        "TMP": "tmp",
        "environment": {},
        "purpose": "sigma-receipt-live64",
        "pending_obligations": [],
        "private": {"path": "private"},
        "campaign": {"path": "campaign", "sha256": "c" * 64},
        "untimed_plan": {"path": "plan", "sha256": "p" * 64},
        "prior_charges": {"path": "charges"},
        "native_outputs": {"untimed": "first", "qualified-timed": "second"},
    }
    ad_path = str(SOURCE.parent / "mock-admission.json")
    write_json(ad_path, ad)
    write_json("charges", [])

    class CycleResources:
        def __init__(self, *args):
            self.memory_limit = 2 * 1024**3

        def check(self, owned=()):
            if mode == "resource" and (ad["output"] + "/arena-candidate.json") in memory:
                raise RuntimeError("independent final resource failure")

    def execute(command, log, deadline, **kwargs):
        commands.append(command)
        name = "untimed" if len(commands) == 1 else "qualified-timed"
        receipt = {
            "command": command,
            "exit_code": 0,
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
            "log_bytes_seen": 2,
            "log_bytes_retained": 2,
            "signal_mask_restoration": "completed",
            "final_record_persist": "completed",
            "handle_closes_complete": True,
            "process_cleanup_complete": True,
        }
        write_json(log.with_suffix(".process.json"), receipt)
        if mode == "receipt" and len(commands) == 2:
            broken = {**receipt, "cleanup_complete": False}
            memory[str(log.with_suffix(".process.json"))] = json.dumps(broken).encode()
        memory[str(log)] = b"{}"
        write_json(
            FakePath(ad["native_outputs"][name]) / "measurement-result.json",
            {"actual_native_fixture": False},
        )
        return receipt

    process = ModuleType("quoridor_training.cycle_process")
    process.CycleResources = CycleResources
    process.process_info = lambda _: {"rss": 1}
    process.execute = execute
    process.CycleStopped = RuntimeError
    package = ModuleType("quoridor_training")
    package.cycle_process = process
    snapshot = ModuleType("quoridor_training.snapshot")
    snapshot.write_json = write_json
    sys.modules["quoridor_training"] = package
    sys.modules["quoridor_training.cycle_process"] = process
    sys.modules["quoridor_training.snapshot"] = snapshot

    materializer_source = SOURCE.with_name("materialize_live.py")
    materializer_functions = {
        node.name: node
        for node in ast.parse(materializer_source.read_text()).body
        if isinstance(node, ast.FunctionDef)
    }

    def bound(path, expected):
        raw = memory[str(path)]
        assert hashlib.sha256(raw).hexdigest() == expected
        return json.loads(raw)

    def publish(path, value):
        write_json(path, value)
        if value.get("scope") == "timed-arena":
            publications.append(path)
        return {"path": str(path), "sha256": hashlib.sha256(memory[str(path)]).hexdigest()}

    def require(condition, message):
        if not condition:
            raise ValueError(message)

    mat_ports = {
        "Path": Path,
        "ROOT": SOURCE.parent.parent,
        "__file__": str(materializer_source),
        "bound": bound,
        "publish": publish,
        "require": require,
    }
    for name in ("non_admitting_candidate", "admit_completed_guardian"):
        exec(
            compile(
                ast.Module(body=[materializer_functions[name]], type_ignores=[]),
                str(materializer_source),
                "exec",
            ),
            mat_ports,
        )

    def evidence(args):
        packet = {
            "schema": "quoridor-sigma-cost-qualification-v1",
            "scope": "timed-arena" if len(args.result) == 2 else "timed-validation",
        }
        if len(args.result) == 2:
            packet = mat_ports["non_admitting_candidate"](
                packet, args.campaign, [{"path": x[0], "sha256": x[1]} for x in args.result]
            )
        return publish(args.packet_output, packet)

    materializer = SimpleNamespace(
        evidence=evidence, timed_plan=lambda args: {"path": args.output, "sha256": "t" * 64}
    )

    def source_port(_):
        if mode == "source" and (ad["output"] + "/arena-candidate.json") in memory:
            raise ValueError("controlled source finalizer failure")

    ports = {
        "Path": FakePath,
        "ROOT": FakePath("root"),
        "WT": FakePath("wt"),
        "LOCK": FakePath("lock"),
        "json": json,
        "hashlib": hashlib,
        "sys": SimpleNamespace(
            argv=["worker", ad_path, hashlib.sha256(memory[ad_path]).hexdigest()],
            path=SimpleNamespace(insert=lambda *args: None),
        ),
        "os": SimpleNamespace(
            environ={}, sched_setaffinity=lambda *args: None, getpid=lambda: 1, chdir=lambda _: None
        ),
        "stat": stat,
        "datetime": datetime,
        "timezone": timezone,
        "SimpleNamespace": SimpleNamespace,
        "BaseExceptionGroup": BaseExceptionGroup,
        "fcntl": SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *args: None),
        "time": time,
        "quiet": lambda: None,
        "physical": lambda: {},
        "validate": lambda _: None,
        "sources": source_port,
        "verify": lambda *args: None,
        "import_bound": lambda *args: materializer,
        "sha": lambda _: "r" * 64,
        "descriptor": lambda path: {"path": str(path), "sha256": "r" * 64},
    }
    compile_function("census", ports)
    error = None
    try:
        compile_function("main", ports)()
    except Exception as caught:
        error = caught
    assert len(commands) == 2, "every G01 finalizer case must complete BOTH mocked phases"
    candidate_path = ad["output"] + "/arena-candidate.json"
    candidate = json.loads(memory[candidate_path])
    assert candidate["schema"] == "quoridor-sigma-cost-nonadmitting-candidate-v1"
    assert candidate["admitting"] is False and "scope" not in candidate
    assert not publications, "guardian candidate must never expose a native admitting packet"
    runtime = str(SOURCE.parent / "mock-runtime")
    config = {
        "issue": "quoridor-4lc.347.2",
        "goal_issue": "quoridor-4lc.347",
        "thread_id": "01a11062-b120-73a1-8aa3-fe2cb922c7c0",
        "cwd": str(SOURCE.parent.parent.parents[1]),
        "resource_contract": ad_path,
        "argv": [
            "/usr/bin/python3.11",
            "-B",
            str(SOURCE),
            ad_path,
            hashlib.sha256(memory[ad_path]).hexdigest(),
        ],
    }
    config_ref = publish(runtime + "/config.json", config)
    state = {
        "job_id": "MOCK_ONLY",
        "config_sha256": config_ref["sha256"],
        "phase": "finished",
        "outcome": "succeeded" if error is None else "failed",
    }
    controller = {
        "job_id": "MOCK_ONLY",
        "outcome": state["outcome"],
        "error": None if error is None else "controlled guardian failure",
        "exit_code": 0 if error is None else 1,
        "direct_child_reaped": True,
        "cleanup_complete": True,
        "remaining": [],
        "cleanup_errors": [],
        "descendant_visibility": "observed",
        "log_bytes_seen": 0,
        "log_bytes_retained": 0,
        "finished_at": "MOCK_STOP",
    }
    if mode == "controller-failed":
        state["outcome"] = controller["outcome"] = "failed"
        controller["exit_code"] = 1
    if mode == "controller-cleanup-unknown":
        controller["cleanup_complete"] = False
    if mode == "wrong-config":
        config["argv"][-1] = "wrong_admission_SHA"
        config_ref = publish(runtime + "/config.json", config)
        state["config_sha256"] = config_ref["sha256"]
    state_ref = publish(runtime + "/state.json", state)
    controller_ref = publish(runtime + "/result.json", controller)
    guardian_path = ad["output"] + "/live-result.json"
    guardian_SHA = (
        hashlib.sha256(memory[guardian_path]).hexdigest() if guardian_path in memory else "MISSING"
    )
    args = SimpleNamespace(
        admission=[ad_path, hashlib.sha256(memory[ad_path]).hexdigest()],
        job_config=[config_ref["path"], config_ref["sha256"]],
        job_state=[state_ref["path"], state_ref["sha256"]],
        job_result=[controller_ref["path"], controller_ref["sha256"]],
        guardian_result=[guardian_path, guardian_SHA],
        candidate=[candidate_path, hashlib.sha256(memory[candidate_path]).hexdigest()],
        output=ad["output"] + "/admitted-packet.json",
    )
    refused = None
    try:
        mat_ports["admit_completed_guardian"](args)
    except (ValueError, KeyError, AssertionError) as caught:
        refused = caught
    if mode == "completed-admission":
        assert error is None and refused is None and len(publications) == 1
        assert json.loads(memory[args.output])["scope"] == "timed-arena"
    else:
        assert refused is not None and not publications
        assert error is not None or mode in (
            "controller-failed",
            "controller-cleanup-unknown",
            "wrong-config",
        )
    return mode


checks = [
    run_case(mode)
    for mode in (
        "completed-admission",
        "source",
        "resource",
        "charges",
        "TMP",
        "lease-close",
        "result",
        "receipt",
        "controller-failed",
        "controller-cleanup-unknown",
        "wrong-config",
    )
]
print(
    json.dumps(
        {
            "PASS": checks,
            "worker_SHA256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "materializer_SHA256": hashlib.sha256(
                SOURCE.with_name("materialize_live.py").read_bytes()
            ).hexdigest(),
            "scope": "G01 actual main/nonadmitting wrapper/completed-consumer AST; two mocked successful phases before each finalizer failure; no real native/backend/model/Popen/old8 replay",
            "native_calls": 0,
        },
        indent=2,
    )
)
