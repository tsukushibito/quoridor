"""Actual validate AST with bound metadata in memory, never private/model IO."""

import ast
import copy
import hashlib
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "live_worker.py"
ROOT = HERE.parent
AD = json.loads((HERE / "admission.live.prepared-v2.json").read_text())
TREE = ast.parse(SOURCE.read_text())
IMPORTS = ast.literal_eval(
    next(
        node.value
        for node in TREE.body
        if isinstance(node, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "REQUIRED_IMPORTS" for t in node.targets)
    )
)
FUNCTION = next(
    node for node in TREE.body if isinstance(node, ast.FunctionDef) and node.name == "validate"
)
MEMORY = {}
for name in ("campaign", "untimed_plan", "metadata_STOP"):
    MEMORY[AD[name]["path"]] = Path(AD[name]["path"]).read_bytes()
review_path = str(HERE / "MOCK-REVIEW-NOT-WRITTEN.json")
AD.update(actual_entry=True, prepared_only=False, pending_obligations=[])
AD["source_review"] = {
    "control_clear": True,
    "reader_STOP": "mock only",
    "target_binding_SHA256": "a" * 64,
    "path": review_path,
}
AD["bindings"][review_path] = {}
MEMORY[review_path] = json.dumps(
    {
        "blockers": 0,
        "ordinary": 0,
        "target_binding_SHA256": "a" * 64,
        "source_reader_STOP": "mock only",
        "remaining_readers_writers_children_pending_direct_waits_cleanup_TMP": [],
    }
).encode()
MEMORY[str(SOURCE)] = SOURCE.read_bytes()
SHAS = {
    AD[name]["path"]: AD[name]["sha256"]
    for name in ("campaign", "untimed_plan", "private", "metadata_STOP", "prior_charges")
}


class FakePath:
    def __init__(self, value):
        self.value = Path(value)

    def __str__(self):
        return str(self.value)

    def __eq__(self, other):
        return str(self) == str(other)

    @property
    def parent(self):
        return FakePath(self.value.parent)

    def resolve(self, strict=True):
        return self

    def read_bytes(self):
        return MEMORY[str(self)]

    def is_absolute(self):
        return self.value.is_absolute()

    def is_relative_to(self, other):
        return self.value.is_relative_to(other)

    def exists(self):
        return str(self) in MEMORY

    def is_symlink(self):
        return False


PORTS = {
    "Path": FakePath,
    "ROOT": ROOT,
    "__file__": str(SOURCE),
    "time": time,
    "EXPIRY": 1791583340854,
    "REQUIRED_IMPORTS": IMPORTS,
    "json": json,
    "sources": lambda _: None,
    "sha": lambda path: SHAS[str(path)],
}
exec(compile(ast.Module(body=[FUNCTION], type_ignores=[]), str(SOURCE), "exec"), PORTS)


checks = []
for path in IMPORTS:
    for kind in ("omission", "digest", "mode", "length"):
        ad = copy.deepcopy(AD)
        if kind == "omission":
            del ad["bindings"][path]
        else:
            key = {"digest": "SHA256", "mode": "mode", "length": "bytes"}[kind]
            ad["bindings"][path][key] = "0" * 64 if kind == "digest" else 0
        events = []
        PORTS["sources"] = lambda _: events.append("source IO")
        try:
            PORTS["validate"](ad)
            raise AssertionError("required import identity accepted: " + kind)
        except ValueError as error:
            assert not events and "required" in str(error)
        checks.append(Path(path).name + " " + kind + " before source/import/output/TMP/Popen")
PORTS["sources"] = lambda _: None
PORTS["validate"](copy.deepcopy(AD))
checks.append("complete exact imported closure accepted")
print(
    json.dumps(
        {
            "PASS": checks,
            "source_SHA256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "scope": "G02 actual validate AST; metadata in memory and IO ports; each module omission/digest/mode/size refusal before source IO/import/output/TMP/Popen; no private/model/native/library/old6 cases execution",
            "calls": 0,
        },
        indent=2,
    )
)
