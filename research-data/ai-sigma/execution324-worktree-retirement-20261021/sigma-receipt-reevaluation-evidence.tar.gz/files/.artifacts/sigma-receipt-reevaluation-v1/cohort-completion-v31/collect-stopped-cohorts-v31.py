"""Collect stopped fixed cohorts without executing native code or an estimator."""

from collections import Counter
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
ENTRY = ROOT / "NNUE-entry-recovery-v30/admission.actual-v30.json"
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")


def record(path):
    path = Path(path)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and path.resolve() == path
    raw = path.read_bytes()
    return {
        "SHA256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": stat.S_IMODE(info.st_mode),
    }


def read(path):
    return json.loads(Path(path).read_bytes())


def write(name, value):
    path = OUT / name
    assert not path.exists()
    path.write_text(json.dumps(value, indent=2) + "\n")
    return {"path": str(path), **record(path)}


def load(path, name, admission):
    assert admission["bindings"][str(path)] == record(path)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    started = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    admission = read(ENTRY)
    checks = {}
    with LOCK.open("r+") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        worker = load(
            ROOT / "saved-D-route-preparation-v24/cohort_nnue_worker.py",
            "stopped_cohort_checks",
            admission,
        )
        worker.review_and_fixed_proofs(admission)
        for path, expected in admission["required_imports"].items():
            assert admission["bindings"][path] == record(path) == expected
        guard = load(admission["helper"], "stopped_physical_guard", admission)
        guard.quiet()
        checks["physical"] = guard.physical()
        for path, expected in admission["bindings"].items():
            worker.verify(path, expected)
        evidence = load(admission["evidence_helper"], "stopped_evidence", admission)
        consumer = load(admission["completed_D_reader"], "stopped_D_consumer", admission)
        preceding = admission["preceding_completed_D"]
        completed_D = consumer.consume_completed_saved_D(
            {
                "path": preceding,
                "sha256": admission["bindings"][preceding]["SHA256"],
            },
            admission,
            worker,
            evidence,
        )
        forecast = read(admission["whole_forecast"])
        previous = read(admission["prior_charges"])
        held = read(ROOT / "cohort-nnue-v1/control-v30/held-charges.json")
        evidence.ledger(held, forecast, previous)
        guard.quiet()
        guard.physical()
        os.sched_setaffinity(0, {3})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        comparisons = {}
        references = {}
        slots_plan = read(admission["plan"])
        for role, dirname, audit_path in (
            ("D", "cohort-d-v1", "saved-audit-control-v26/audit.log"),
            ("NNUE", "cohort-nnue-v1", "control-v30/audit.log"),
        ):
            base = ROOT / dirname
            native = base / "run"
            report = read(native / "result.json")
            manifest = read(native / "manifest.json")
            audit = read(base / audit_path)
            assert audit == manifest["summary"]
            assert audit["census"]["planned_games"] == 16
            assert audit["bootstrap"]["seed"] == 331
            assert audit["bootstrap"]["resamples"] == 2000
            outcomes = report["outcomes"]
            assert len(outcomes) == 16
            assert sorted(row["game"] for row in outcomes) == list(range(16))
            assert all(type(row["started"]) is bool for row in outcomes)
            assert sum(row["started"] for row in outcomes) == audit["census"]["started_games"]
            assert evidence.partial_census(outcomes)["missing_ids"] == []
            clock = worker.clock_census(report)
            if role == "D":
                assert clock == completed_D["clock_census"]
            else:
                guardian = read(base / "control-v30/cohort-result.json")
                assert clock == guardian["clock_census"]
                assert guardian["primary_error"] is None
                assert guardian["stage_failures"] == []
            statuses = Counter(row["status"] for row in outcomes)
            wins = losses = draws = unknown = 0
            table = []
            for row in outcomes:
                status = row["status"]
                if status == "goal":
                    assert type(row["winner"]) is int and row["winner"] in (0, 1)
                    win = row["winner"] == row["candidate_color"]
                    wins += int(win)
                    losses += int(not win)
                elif status == "draw":
                    draws += 1
                else:
                    unknown += 1
                table.append(
                    {
                        key: row.get(key, "UNKNOWN")
                        for key in (
                            "game",
                            "family",
                            "candidate_color",
                            "status",
                            "winner",
                            "plies",
                            "reason",
                            "started",
                            "failure",
                        )
                    }
                )
            assert wins + losses + draws + unknown == 16
            score = (wins + 0.5 * draws) / 16
            assert audit["planned_score_range"] == [score, score + unknown / 16]
            comparisons[role] = {
                "scheduled": 16,
                "wins": wins,
                "losses": losses,
                "draws": draws,
                "UNKNOWN": unknown,
                "typed_status": dict(statuses),
                "clock_census": clock,
                "fixed_slots": slots_plan["cohorts"][role]["slots"],
                "outcomes": table,
                "saved_native_audit": audit,
                "bootstrap_replayed": False,
            }
            for name in (
                "result.json",
                "manifest.json",
                "manifest-start.json",
                "config.json",
                "admission.json",
                "planned.json",
                "completed.jsonl",
                "games.csv",
                "moves.jsonl.gz",
                "evaluator-identities.json",
            ):
                path = native / name
                references[str(path)] = record(path)
            references[str(base / audit_path)] = record(base / audit_path)
        for first, second in zip(
            comparisons["D"]["fixed_slots"], comparisons["NNUE"]["fixed_slots"], strict=True
        ):
            for key in ("game", "family_index", "color_index", "opening_id", "prefix"):
                assert first[key] == second[key]
        state = read(ROOT / "cohort-runtime-nnue-recovery-v3/state.json")
        controller = read(ROOT / "cohort-runtime-nnue-recovery-v3/result.json")
        config = read(ROOT / "cohort-runtime-nnue-recovery-v3/config.json")
        assert state["job_id"] == controller["job_id"]
        assert (
            state["config_sha256"]
            == hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
        )
        assert state["phase"] == "finished"
        assert state["outcome"] == controller["outcome"] == "succeeded"
        assert controller["error"] is None and controller["exit_code"] == 0
        assert controller["direct_child_reaped"] and controller["cleanup_complete"]
        assert controller["remaining"] == controller["cleanup_errors"] == []
        checks.update(
            {
                "source_refs_after_verified": len(admission["bindings"]),
                "completed_D_external_audit_and_publication_rederived": True,
                "native_scientific_games_replayed": 0,
                "native_audit_recover_backend_model_calls": 0,
                "new_bootstrap_calls": 0,
                "prior_failed_D_and_lost_stdout": "retained unchanged",
                "all_old_resource_maxima": "retained; typed ledger PASS",
                "continuous_peak": "UNKNOWN",
            }
        )
        packet = {
            "schema": "quoridor.fixed-new-clock-cohorts-saved-observations.v31",
            "observations": comparisons,
            "checks": checks,
            "native_references": references,
            "limitations": [
                "Sixteen scheduled slots per opponent, eight fixed OPEN families/color pairs.",
                "Correlated shared book and lineage; conditional finite observation, no Elo.",
                "Native family bootstrap reused; no universal win-probability certificate.",
                "Original D controller FAILED and lost stdout remain; saved completion is separate.",
                "Original live64 was exhausted; no recalibration or expiry refresh.",
                "Kernel isolation, continuous peaks and unmeasured costs remain UNKNOWN.",
                "No default/model adoption, N/full corpus/full generation/fits selection.",
            ],
        }
        ref = write("saved-observations-v31.json", packet)
        for path, expected in admission["bindings"].items():
            worker.verify(path, expected)
        stopped = datetime.now(timezone.utc).isoformat()
    write(
        "saved-collection-STOP-v31.json",
        {
            "START": started,
            "STOP": stopped,
            "wall_seconds": time.monotonic() - tick,
            "canonical_lifetime_lease": "released after source/output completion",
            "saved_observations": ref,
            "new_native_science_backend_model_Search_calls": 0,
            "checks": checks,
            "owned_children_readers_TMP": [],
            "current_owned_reservation": "NONE",
            "continuous_peak": "UNKNOWN",
        },
    )
    print(
        json.dumps(
            {
                role: {k: value[k] for k in ("scheduled", "wins", "losses", "draws", "UNKNOWN")}
                for role, value in comparisons.items()
            }
        )
    )


if __name__ == "__main__":
    main()
