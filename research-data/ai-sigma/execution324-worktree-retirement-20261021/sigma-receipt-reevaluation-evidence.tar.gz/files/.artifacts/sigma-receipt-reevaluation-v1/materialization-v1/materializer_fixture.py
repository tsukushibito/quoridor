"""Focused actual-function AST checks with fake result and publication ports."""

import ast
import copy
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent


def quiet():
    found = []
    names = {
        "cargo",
        "rustc",
        "clippy-driver",
        "cargo-clippy",
        "perf",
        "quoridor-runner",
        "chrome",
        "chromium",
        "chrome-headless-shell",
    }
    markers = (
        "numeric_worker",
        "numeric-worker",
        "software_guard",
        "software_worker",
        "qualify.py",
        "statistics.py",
        "train.py",
        "trainer.py",
        "matches-worker",
        "execute-retention.py",
        "finite-driver",
        "public-synthetic",
    )
    for entry in Path("/proc").iterdir():
        if not entry.name.isdecimal() or int(entry.name) == os.getpid():
            continue
        try:
            argv = [
                os.fsdecode(p)
                for p in (entry / "cmdline").read_bytes().split(b"\0")
                if p
            ]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not argv:
            continue
        executable = Path(argv[0]).name
        if (
            executable in names
            or executable.startswith(
                ("quoridor_runner-", "profile_native", "measure_native")
            )
            or (
                executable.startswith("python")
                and any(Path(arg).name.startswith(markers) for arg in argv[1:])
            )
        ):
            found.append({"pid": int(entry.name), "argv": argv})
    if found:
        raise RuntimeError("PRESTART named competitor: " + json.dumps(found))
    return found


def fixture():
    template = json.loads((ROOT / "campaign.prepared.json").read_bytes())
    template["native"] = {
        "compiled_sources_sha256": "a" * 64,
        "executable_sha256": "b" * 64,
        "backend_sha256": "d" * 64,
        "valid_until_unix_ms": 1791583340854,
    }
    for index, config in enumerate(template["configurations"]):
        config["normalized_sha256"] = str(index + 1) * 64
    objects = {("/mock/campaign", "c" * 64): template}
    plans, results, receipts = [], [], []
    for index, phase in enumerate(template["phases"]):
        plan_ref = [f"/mock/plan{index}", str(index + 3) * 64]
        result_ref = [
            f"/mock/output{index}/measurement-result.json",
            str(index + 6) * 64,
        ]
        receipt_ref = [f"/mock/process{index}", str(index + 8) * 64]
        plan = {
            "native": template["native"],
            "campaign": {"path": "/mock/campaign", "sha256": "c" * 64},
            "workload": phase["workload"],
            "mode": phase["mode"],
            "phase_id": phase["id"],
            "configurations": template["configurations"],
            "output": f"/mock/output{index}",
        }
        command = [
            "/mock/private",
            "sigma-cost-measure",
            "--plan",
            *plan_ref[:1],
            "--plan-sha256",
            plan_ref[1],
        ]
        if index:
            command += [
                "--sigma-cost-qualification",
                "/mock/validation",
                "--qualification-sha256",
                "e" * 64,
            ]
        process = {
            "command": command,
            "exit_code": 0,
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
        }
        items = []
        for ordinal, expected in enumerate(phase["workload"], 1):
            counters = {
                "nn_requests_attempted": 2,
                "inference_callback_results": 2,
                "nn_valid_replies_returned": 2,
                "terminal_request_error": None,
                "inflight_after_drain": 0,
                "authority_legal": True,
                "measurement_operations_ns": [ordinal * 1000],
                "decision_and_receipt_cost_ns": ordinal * 100,
                "measurement_mode": phase["mode"],
                "cost_qualification_usable_after_drain": True,
            }
            items.append(
                {
                    **expected,
                    "parent": {"prefix": expected["prefix"]},
                    "error": None,
                    "config_sha256": template["configurations"][
                        expected["configuration"]
                    ]["normalized_sha256"],
                    "receipt": {
                        "accepted": True,
                        "failure": None,
                        "action": 13,
                        "counters": counters,
                    },
                }
            )
        record = {
            "schema": "quoridor-sigma-receipt-measurement-result-v1",
            "native": template["native"],
            "campaign_sha256": "c" * 64,
            "phase_id": phase["id"],
            "mode": phase["mode"],
            "configuration_sha256": [
                c["normalized_sha256"] for c in template["configurations"]
            ],
            "complete": True,
            "all_workers_joined": True,
            "inflight_after_drain": 0,
            "stopped": None,
            "logical_calls_attempted": 32,
            "returned_terminal_replies": 32,
            "prior_logical_calls": index * 32,
            "allocated_logical_calls": 32,
            "plan_sha256": plan_ref[1],
            "backend_work": {"logical_rows": 32, "physical_rows": 32, "failed_rows": 0},
            "items": items,
        }
        (
            objects[tuple(plan_ref)],
            objects[tuple(result_ref)],
            objects[tuple(receipt_ref)],
        ) = plan, record, process
        plans.append(plan_ref)
        results.append(result_ref)
        receipts.append(receipt_ref)
    args = SimpleNamespace(
        campaign=["/mock/campaign", "c" * 64],
        plan=plans,
        result=results,
        receipt=receipts,
        private="/mock/private",
        validation_packet=["/mock/validation", "e" * 64],
        output="/mock/evidence",
        packet_output="/mock/packet",
    )
    return objects, args


def run_cases():
    source = (ROOT / "materialize_live.py").read_bytes()
    tree = ast.parse(source)
    functions = [
        n
        for n in tree.body
        if isinstance(n, ast.FunctionDef)
        and n.name in {"require", "positive", "evidence"}
    ]
    namespace = {"Path": Path, "U64_MAX": 2**64 - 1}
    exec(
        compile(
            ast.Module(body=functions, type_ignores=[]),
            str(ROOT / "materialize_live.py"),
            "exec",
        ),
        namespace,
    )
    passed = []

    def case(name, mutate=None, expected=None, untimed=False):
        objects, args = fixture()
        if untimed:
            args.result, args.plan, args.receipt = (
                args.result[:1],
                args.plan[:1],
                args.receipt[:1],
            )
            args.validation_packet = None
        if mutate:
            mutate(objects, args)
        publications = {}
        namespace["bound"] = lambda path, sha: copy.deepcopy(objects[(path, sha)])
        namespace["publish"] = lambda path, value: publications.setdefault(
            path, copy.deepcopy(value)
        )
        try:
            namespace["evidence"](args)
        except ValueError as error:
            assert expected and expected in str(error), (name, str(error))
            assert not publications, (name, "refusal occurred after publication")
        else:
            assert expected is None
            assert publications["/mock/evidence"]["attempted_logical_calls"] == (
                32 if untimed else 64
            )
            assert publications["/mock/packet"]["scope"] == (
                "timed-validation" if untimed else "timed-arena"
            )
        passed.append(name)

    def record(objects, args):
        return objects[tuple(args.result[0])]

    def process(objects, args):
        return objects[tuple(args.receipt[0])]

    case("exact untimed32 warm16 measurement16", untimed=True)
    case("exact joined64 and fixed empirical formula")
    case(
        "wrong campaign",
        lambda o, a: record(o, a).update(campaign_sha256="f" * 64),
        "off-campaign",
    )
    case(
        "incomplete native phase",
        lambda o, a: record(o, a).update(complete=False),
        "incomplete",
    )
    case(
        "wrong direct argv",
        lambda o, a: process(o, a).update(command=["/mock/foreign"]),
        "direct wait",
    )
    case(
        "unknown cleanup",
        lambda o, a: process(o, a).update(cleanup_complete=False),
        "direct wait",
    )
    case(
        "wrong terminal census",
        lambda o, a: record(o, a).update(returned_terminal_replies=31),
        "census",
    )
    case(
        "changed input prefix",
        lambda o, a: record(o, a)["items"][0]["parent"].update(prefix=[67]),
        "identity",
    )
    case(
        "timed bound disproof",
        lambda o, a: o[tuple(a.result[1])]["items"][0]["receipt"]["counters"].update(
            measurement_operations_ns=[999999999]
        ),
        "disproved",
    )
    return {
        "cases": passed,
        "source_SHA256": hashlib.sha256(source).hexdigest(),
        "scope": "actual evidence function AST with fake control/publication ports; no real native/private/receipt/payload IO",
        "model_calls": 0,
        "Popen": 0,
    }


def main():
    start = time.monotonic()
    policy = Path(
        "/workspaces/quoridor/research-data/ai-sigma/execution-resources-20261008.json"
    )
    assert (
        hashlib.sha256(policy.read_bytes()).hexdigest()
        == "68f528718c63be5471ed32d87984ef63816d6e7066279cc1ef37393243111f88"
    )
    proof = Path(
        "/workspaces/quoridor/research-data/ai-sigma/sigma-receipt-reevaluation-v1/resources.json"
    )
    assert (
        hashlib.sha256(proof.read_bytes()).hexdigest()
        == "a70b70c3df2b970a41d0c55cec6fb249e68026f8fa51de837bfbd5e3561c2683"
    )
    filesystem = os.statvfs(ROOT)
    assert filesystem.f_bavail * filesystem.f_frsize > 2 * 1024**2
    memory = dict(
        line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines()
    )
    available = int(memory["MemAvailable"].split()[0]) * 1024
    assert available > 4 * 1024**3 + 512 * 1024**2
    assert 3 in os.sched_getaffinity(0)
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    lock = os.open(
        "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock",
        os.O_RDWR,
    )
    quiet()
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        quiet()
        os.sched_setaffinity(0, {3})
        actual_start = datetime.now(timezone.utc).isoformat()
        result = run_cases()
        result.update(
            actual_START=actual_start,
            actual_STOP=datetime.now(timezone.utc).isoformat(),
            whole_seconds=time.monotonic() - start,
            CPU=3,
            AS_limit_B=512 * 1024**2,
            VmHWM_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            available_RAM_B=available,
            named_competitors=[],
            owned_children_TMP_remaining=[],
            continuous_family_peak="UNKNOWN",
        )
        with (ROOT / "materializer-fixture-result-v1.json").open("x") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
        print(json.dumps(result))
    finally:
        os.close(lock)


if __name__ == "__main__":
    main()
