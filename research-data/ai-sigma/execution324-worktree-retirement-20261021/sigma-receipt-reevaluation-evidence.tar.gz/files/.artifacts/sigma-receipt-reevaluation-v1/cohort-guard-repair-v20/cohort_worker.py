"""One already planned cohort; native receipt runtime, audit and recovery only."""

from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
EXPIRY = 1791583340854
CLOCK = "authority-action-receipt-v1"
CLOCK_SHA = "04062382f70648cdfd722e59c35be1100719169097a04749b0046ea5a19a280d"
REQUIRED_IMPORTS = {
    "/workspaces/quoridor/python/quoridor_training/__init__.py": {
        "SHA256": "05011521a4993db992001289548d4c90516495129bc60b9882d6b7211c60aee5",
        "bytes": 216,
        "mode": 420,
    },
    "/workspaces/quoridor/python/quoridor_training/cycle_process.py": {
        "SHA256": "ddaa2881335488c719ad6941ac18becf1c544debf7e28037c9977d87cd6f060b",
        "bytes": 20479,
        "mode": 420,
    },
    "/workspaces/quoridor/python/quoridor_training/snapshot.py": {
        "SHA256": "ed0814965c012d6ad5ad094e653158b42b5d4ebf17463706ce53d029bc704341",
        "bytes": 1232,
        "mode": 420,
    },
}


FIXED_PROOFS = {
    "/home/vscode/.cache/inference/envs/quoridor-training/lib/python3.14/site-packages/onnxruntime/capi/libonnxruntime.so.1.30.0": {
        "SHA256": "c902c70b3003c0e99fada202f37478c515ae9bba7944c2b2abd0017bae0c82ed",
        "mode": 493,
        "bytes": 28985152,
    },
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/trained-reference-v1/native-current-v1/distance-current-v1/book-full.json": {
        "SHA256": "93cb139a3b229afaf97a29a90ea843288eb6d8ab2a0c0b144de0d411d18ba969",
        "mode": 420,
        "bytes": 11989,
    },
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/trigger-patience-v1/patience1/output/best-model/manifest.json": {
        "SHA256": "c4712e0872b6831e33fcf59b99d9d7f774d18a3e8d5236d7923ba65e64aabc39",
        "mode": 420,
        "bytes": 677,
    },
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/trigger-patience-v1/patience1/output/best-model/weights.f32": {
        "SHA256": "9ca438e43b0c105ac5f802a302946f2ba71623ea2bc443b9c54cc9a8468b75b0",
        "mode": 420,
        "bytes": 49284,
    },
    "/workspaces/quoridor/.worktree/assets/models/ai-sigma/reference/sigma-pcr250/best.onnx": {
        "SHA256": "d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d",
        "mode": 420,
        "bytes": 11663428,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/both-cohorts-plan.prepared.json": {
        "SHA256": "f3112ffb24b3885a44cce0d93c12bef7d80d7af9239609cefc814bfd493c0357",
        "bytes": 11498,
        "mode": 420,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/canonical-config-repair-v11/live_worker.py": {
        "SHA256": "85194189d54b2cee4e9491f1947daf4c5ea07029753f5b5c4e51a07b1ea9356f",
        "bytes": 23019,
        "mode": 420,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-control-v15/both-cohorts-plan.fixed-v15.json": {
        "SHA256": "473a6adcf5ac58b42612e4588a730ed30611252739569bda846ee012577606c2",
        "bytes": 14854,
        "mode": 420,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/cohort-control-v15/whole-forecast-v15.json": {
        "SHA256": "2a0c599c5182947d9dfaf06e1bff850bfdbf180bf61d96b4635412f2ae7b87a5",
        "bytes": 1861,
        "mode": 420,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/configuration-v2/config-d-16.fixed-v2.json": {
        "SHA256": "f8ce5e4e37ac0161e3348d81e5e48d0140b1cf1079429b0335dc671d98e330e7",
        "bytes": 15569,
        "mode": 420,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/configuration-v2/config-nnue-16.fixed-v2.json": {
        "SHA256": "15fcb984e4da55ac94dd0db7f82571c0db21ac9e402947c4c792a8f0b43f5e21",
        "mode": 420,
        "bytes": 15701,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/live-completion-v14/completed-guardian-admission.process.json": {
        "SHA256": "2e6984601d6635192cb3eebf2a9bd27c5797aa03bf589550904ebd76ade65cc6",
        "bytes": 2687,
        "mode": 420,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/live-completion-v14/qualified-live64-STOP-v1.json": {
        "SHA256": "877e34706eaa733827e58503e5a461a7f5e8de3342f7a4e25f959ea2c0e94460",
        "bytes": 9926,
        "mode": 420,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/live-control-output-v1/arena-admitted-packet.json": {
        "SHA256": "93e11897b983c840fdde17a9ef0d130e4b88b72fad6e56fb66e026a5838d2770",
        "bytes": 1553,
        "mode": 420,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/live-control-output-v1/arena-evidence.json": {
        "SHA256": "ace624361f518a6b9d1d628dbfa9f035feb1ebcd04896cf03fa785485c53bc25",
        "bytes": 1666,
        "mode": 420,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/live-control-output-v1/held-charges.json": {
        "SHA256": "2107e2a43364151cb39f147433bafdedee113b5cc51d63724ebdcdcb12583a5a",
        "bytes": 602096,
        "mode": 384,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/materialization-v8/qualified-metadata-STOP-v7.json": {
        "SHA256": "cc4f8cc4f2e51420226c1aaa3fa39bca2c32d0c6e25c39a49e43b9dda15409dd",
        "mode": 420,
        "bytes": 14488,
    },
    "/workspaces/quoridor/.worktree/sigma-receipt-reevaluation/.artifacts/sigma-receipt-reevaluation-v1/private-current-v5/quoridor-runner": {
        "SHA256": "633f05e03889661f2f79a628efe814f5aaa9c933e6abafd0332f25fc7fffe143",
        "bytes": 7993152,
        "mode": 493,
    },
    "/workspaces/quoridor/research-data/ai-sigma/execution-resources-20261008.json": {
        "SHA256": "68f528718c63be5471ed32d87984ef63816d6e7066279cc1ef37393243111f88",
        "bytes": 7612,
        "mode": 420,
    },
    "/workspaces/quoridor/research-data/ai-sigma/sigma-receipt-reevaluation-v1/live64-acceptance-v1.json": {
        "SHA256": "83344d44307044f2a26eb53240ae5b855400c9fbecd694b53ac585dd0aef8c90",
        "bytes": 16337,
        "mode": 420,
    },
    "/workspaces/quoridor/research-data/ai-sigma/sigma-receipt-reevaluation-v1/resources.json": {
        "SHA256": "a70b70c3df2b970a41d0c55cec6fb249e68026f8fa51de837bfbd5e3561c2683",
        "bytes": 3785,
        "mode": 420,
    },
}


PAYLOAD_PATHS = {
    str(ROOT / "private-current-v5/quoridor-runner"),
    "/workspaces/quoridor/.worktree/assets/models/ai-sigma/reference/sigma-pcr250/best.onnx",
    "/home/vscode/.cache/inference/envs/quoridor-training/lib/python3.14/site-packages/onnxruntime/capi/libonnxruntime.so.1.30.0",
    "/workspaces/quoridor/.worktree/assets/checkpoints/public-full-learning/trigger-patience-v1/patience1/output/best-model/weights.f32",
}


def verify(path, record):
    path = Path(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or path.resolve(strict=True) != path:
        raise ValueError("canonical regular bound input required")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if (digest, info.st_size, stat.S_IMODE(info.st_mode)) != (
        record["SHA256"],
        record["bytes"],
        record["mode"],
    ):
        raise ValueError("changed input: " + str(path))


def receipt_cleanup_ok(receipt, command):
    return bool(
        isinstance(receipt, dict)
        and receipt.get("command") == command
        and type(receipt.get("exit_code")) is int
        and receipt.get("direct_child_reaped") is True
        and receipt.get("cleanup_complete") is True
        and receipt.get("remaining") == []
        and receipt.get("log_bytes_seen") == receipt.get("log_bytes_retained")
    )


def receipt_ok(receipt, command):
    return receipt_cleanup_ok(receipt, command) and receipt["exit_code"] == 0


def clock_census(report):
    """Saved receipt semantics only; maintained native audit supplies geometry."""
    counts = {
        "observed_games": 0,
        "observed_moves": 0,
        "accepted": 0,
        "rejected": 0,
        "cost_disproved": 0,
        "goal": 0,
        "draw": 0,
        "unknown": 0,
    }
    ids = set()
    for outcome in report["outcomes"]:
        game = outcome["game"]
        if type(game) is not int or game not in range(16) or game in ids:
            raise ValueError("duplicate/unplanned outcome")
        ids.add(game)
        counts["observed_games"] += 1
        status = outcome["status"]
        if status not in ("goal", "draw", "unknown"):
            raise ValueError("unauthorized adjudication")
        counts[status] += 1
        previous_drain = None
        for move in outcome["observations"]:
            counts["observed_moves"] += 1
            c = move["counters"]
            started = move["caller_started_ns"]
            if c.get("clock_contract") != CLOCK or c.get("clock_contract_sha256") != CLOCK_SHA:
                raise ValueError("wrong receipt clock")
            receipt, drain = c.get("authority_receipt_ns"), c.get("drain_finished_ns")
            if (
                type(receipt) is not int
                or type(drain) is not int
                or not started <= receipt <= drain
            ):
                raise ValueError("receipt/drain chronology")
            if previous_drain is not None and started < previous_drain:
                raise ValueError("opponent clock before drain")
            previous_drain = drain
            if move["deadline_ns"] != started + 100_000_000:
                raise ValueError("changed100ms clock")
            if move["accepted"]:
                counts["accepted"] += 1
                if receipt >= move["deadline_ns"] or move["failure"] is not None:
                    raise ValueError("accepted late/error receipt")
                if move["engine_index"] == 0 and (
                    c.get("immutable_chosen_action") != move["action"]
                    or c.get("authority_legal") is not True
                    or c.get("terminal_request_error") is not None
                    or c.get("inflight_after_drain") != 0
                ):
                    raise ValueError("accepted Sigma action/reply/drain mismatch")
            else:
                counts["rejected"] += 1
                if move["failure"] is None or status != "unknown":
                    raise ValueError("rejection converted to known outcome")
            if move["engine_index"] == 0:
                if (
                    c.get("measurement_mode") is not None
                    or c.get("measurement_call_limit") is not None
                ):
                    raise ValueError("production game replaced by qualification workload")
                if c.get("inflight_after_drain") != 0:
                    raise ValueError("undrained Sigma request")
                if c.get("cost_qualification_usable_after_drain") is False:
                    counts["cost_disproved"] += 1
    return counts


def review_and_fixed_proofs(a):
    """Consume the actual stopped verdict before importing any project helper."""
    review = a["source_review"]
    for path in (review["control_path"], review["target_path"]):
        if path not in a["bindings"]:
            raise ValueError("actual review/target membership missing")
        verify(path, a["bindings"][path])
    if (
        a["bindings"][review["control_path"]]["SHA256"] != review["control_SHA256"]
        or a["bindings"][review["target_path"]]["SHA256"] != review["target_SHA256"]
    ):
        raise ValueError("actual review/target SHA")
    control = json.loads(Path(review["control_path"]).read_bytes())
    target = json.loads(Path(review["target_path"]).read_bytes())
    if not (
        control["control_clear"] is True
        and control["blockers"] == 0
        and control["ordinary"] == 0
        and control["target_path"] == review["target_path"]
        and control["target_binding_SHA256"] == review["target_SHA256"]
        and control["source_reader_STOP"] == review["reader_STOP"]
        and bool(control["source_reader_STOP"])
        and control["remaining_readers_writers_children_pending_direct_waits_cleanup_TMP"] == []
        and control["producer_reader_writer_STOP"] == target["source_reader_writer_STOP"]
        and target["owned_readers_children_jobs_TMP_remaining"] == []
        and target["required_proof_identities"] == FIXED_PROOFS
    ):
        raise ValueError("blocked/stale/nonstopped actual review or erased prerequisites")
    for path in (str(Path(__file__).resolve()), a["evidence_helper"], a["whole_forecast"]):
        if path not in a["bindings"] or target["selected_refs"].get(path) != a["bindings"][path]:
            raise ValueError("reviewed worker/consumer/forecast differs from current target")
        verify(path, a["bindings"][path])
    for path, proof in FIXED_PROOFS.items():
        if a["bindings"].get(path) != proof:
            raise ValueError("fixed prerequisite identity missing/changed")
        # Payload bytes are verified under fresh quiet and the lifetime lease.
        if path not in PAYLOAD_PATHS:
            verify(path, proof)


def validate(a):
    if not a["actual_entry"] or a["prepared_only"] or a["pending_obligations"]:
        raise ValueError("prepared/incomplete cohort control refuses entry")
    if a["role"] not in ("D", "NNUE") or a["supported_whole_B"] != 4294967296:
        raise ValueError("unsupported cohort")
    if a["source_review"]["control_clear"] is not True or not a["source_review"]["reader_STOP"]:
        raise ValueError("changed cohort control not cleared/stopped")
    review = a["source_review"]
    if review["control_path"] not in a["bindings"] or (
        a["bindings"][review["control_path"]]["SHA256"] != review["control_SHA256"]
    ):
        raise ValueError("changed-control review evidence not bound")
    for path, record in a["bindings"].items():
        verify(path, record)
    required = {
        str(Path(__file__).resolve()),
        a["helper"],
        a["private"],
        a["config"],
        a["packet"],
        a["plan"],
        a["prior_charges"],
        *a["required_imports"],
        *FIXED_PROOFS,
    }
    if not required.issubset(a["bindings"]):
        raise ValueError("required source/input membership missing before imports")
    for path, record in a["required_imports"].items():
        if a["bindings"][path] != record:
            raise ValueError("import identity mismatch")
    config = json.loads(Path(a["config"]).read_bytes())
    plan = json.loads(Path(a["plan"]).read_bytes())
    packet = json.loads(Path(a["packet"]).read_bytes())
    if packet["evidence"]["path"] not in a["bindings"] or (
        a["bindings"][packet["evidence"]["path"]]["SHA256"] != packet["evidence"]["sha256"]
    ):
        raise ValueError("admitted evidence membership/SHA")
    role = plan["cohorts"][a["role"]]
    binding = packet["configurations"][0 if a["role"] == "D" else 1]
    if (
        config["games"] != 16
        or config["max_plies"] != 200
        or config["wall_seconds"] is not None
        or config["output"] != a["native_output"]
        or config["seed"] != 32710001
        or config["simulations"] != 64
        or config["cpu_cores"] != [0]
        or config["inference_cpu_core"] != 0
        or config["workers"] != 1
        or config["active_games"] != 1
        or config["max_batch"] != 1
        or config["arena"]["clock_policy"] != "strict_unknown"
        or config["arena"]["return_reserve_ms"] != 5
        or binding["file"] != {"path": a["config"], "sha256": a["bindings"][a["config"]]["SHA256"]}
        or binding["normalized_sha256"] != role["normalized_config_sha256"]
        or packet["native"]["executable_sha256"] != a["bindings"][a["private"]]["SHA256"]
        or packet["native"]["valid_until_unix_ms"] != EXPIRY
        or int(time.time() * 1000) >= EXPIRY
        or packet["scope"] != "timed-arena"
    ):
        raise ValueError("fixed config/private/packet/expiry mismatch")
    expected_commands = [
        [
            "arena",
            [
                a["private"],
                "arena",
                "--config",
                a["config"],
                "--sigma-cost-qualification",
                a["packet"],
                "--qualification-sha256",
                a["bindings"][a["packet"]]["SHA256"],
            ],
        ],
        ["audit", [a["private"], "arena", "--audit", a["native_output"]]],
        ["recover", [a["private"], "arena", "--recover", a["native_output"]]],
    ]
    if a["commands"] != expected_commands or len(role["slots"]) != 16:
        raise ValueError("exact arena/audit/recover argv or planned denominator changed")
    for slot in role["slots"]:
        opening = config["arena"]["book"]["openings"][slot["family_index"]]
        if (
            opening["id"] != slot["opening_id"]
            or opening["prefix"] != slot["prefix"]
            or slot["game"] != 2 * slot["family_index"] + slot["color_index"]
        ):
            raise ValueError("pre-outcome book/slot correspondence")
    if a["role"] == "NNUE":
        if a["preceding_completed_D"] not in a["bindings"]:
            raise ValueError("preceding D acceptance not SHA bound")
    for name in ("output", "TMP", "native_output"):
        path = Path(a[name])
        if (
            not path.is_relative_to(ROOT)
            or path.exists()
            or path.is_symlink()
            or path.parent.resolve() != path.parent
        ):
            raise ValueError("exclusive new namespace required")
    return config


def physical_before_child(guard):
    """Check actual admitted inlet CPUs, then restore the pinned guardian before launch."""
    pinned = os.sched_getaffinity(0)
    if pinned != {2}:
        raise ValueError("per-child physical guard requires exact guardian CPU2")
    primary = None
    try:
        os.sched_setaffinity(0, {0, 2})
        guard.physical()
    except BaseException as error:
        primary = error
        raise
    finally:
        try:
            os.sched_setaffinity(0, pinned)
        except BaseException as secondary:
            if primary is not None:
                primary.add_note("guardian_affinity_restore: " + repr(secondary))
                raise primary
            raise


def main():
    raw = Path(sys.argv[1]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != sys.argv[2]:
        raise ValueError("actual admission SHA")
    a = json.loads(raw)
    if not a["actual_entry"] or a["prepared_only"] or a["pending_obligations"]:
        raise ValueError("prepared/incomplete cohort control refuses before imports")
    if a["required_imports"] != REQUIRED_IMPORTS:
        raise ValueError("mandatory import membership/identities changed before imports")
    review_and_fixed_proofs(a)
    for path in [a["helper"], a["evidence_helper"], *a["required_imports"]]:
        verify(path, a["bindings"][path])

    def imported(path, name):
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    E = imported(a["evidence_helper"], "cohort_evidence")
    L = imported(a["helper"], "receipt_guard")
    L.quiet()
    L.physical()
    lock = LOCK.open("r+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        L.quiet()
        validate(a)
        forecast = json.loads(Path(a["whole_forecast"]).read_bytes())
        proof = json.loads(Path(forecast["resource_proof"]["path"]).read_bytes())
        if (
            forecast["all_original_component_uppers_B"] != proof["components_B"]
            or forecast["supported_whole_B"] != proof["new_whole_B"]
            or forecast["named_retained_target_floor_B"] != 498405376
            or forecast["separate_Main_helper_target_upper_B"] != 536870912
            or forecast["separate_Main_helper_TMP_upper_B"] != 67108864
        ):
            raise ValueError("actual bound original/joint whole support changed")
        baseline = json.loads(Path(E.BASELINE).read_bytes())
        prior = json.loads(Path(a["prior_charges"]).read_bytes())
        E.ledger(prior, forecast, baseline)
        preceding = None
        if a["role"] == "NNUE":
            path = a["preceding_completed_D"]
            preceding = E.consume_completed_d(
                {"path": path, "sha256": a["bindings"][path]["SHA256"]}, a, clock_census
            )
            baseline = E.preceding_ledger(preceding, a)
            E.ledger(prior, forecast, baseline)
        sys.path.insert(0, "/workspaces/quoridor/python")
        from quoridor_training import cycle_process as P
        from quoridor_training.snapshot import write_json

        if preceding and any(P.alive(identity) for identity in preceding["identities"]):
            raise ValueError("completed D exact native/guardian identity still alive")
    except BaseException as primary:
        try:
            lock.close()
        except BaseException as secondary:
            primary.add_note("lease_close: " + repr(secondary))
        raise
    output, temporary, native = map(Path, (a["output"], a["TMP"], a["native_output"]))
    attempts, errors, receipts, finalizers = [], [], [], []
    primary, resources = None, None
    result = {
        "role": a["role"],
        "external_controller_acceptance": False,
        "provisional_only": True,
        "planned": 16,
        "continuous_peak": "UNKNOWN",
        "guardian_finalization_status": "PENDING authoritative successful external controller",
        "publication_extent": "Before result/diagnostic/lease finalization; native process cleanup only",
    }

    def attempt(stage, action):
        row = {"stage": stage, "status": "pending"}
        finalizers.append(row)
        try:
            value = action()
            row["status"] = "completed"
            return value
        except BaseException as error:
            row["status"] = "failed_UNKNOWN"
            errors.append({"stage": stage, "type": type(error).__name__, "message": str(error)})
            return None

    class Resources(P.CycleResources):
        def __init__(self):
            super().__init__(
                {
                    "host_ram_reserve": 4 * 1024**3,
                    "max_memory_bytes": 2 * 1024**3,
                    "max_output_bytes": 256 * 1024**2,
                },
                output,
                None,
            )
            self.maxima = E.ledger(prior, forecast, baseline)
            self.family_peak = 0

        def validate_held(self):
            E.ledger(E.rows(self.maxima), forecast, baseline)

        def check(self, owned=()):
            self.validate_held()
            super().check(owned)
            infos = [P.process_info(os.getpid()), *(P.process_info(x["pid"]) for x in owned)]
            self.family_peak = max(
                self.family_peak, sum(x["rss"] for x in infos if x) + 64 * 1024**2
            )
            if self.family_peak > self.memory_limit:
                raise P.CycleStopped("whole family including controller reserve")
            for component, root in [(a["role"], output), (a["role"], native), ("TMP", temporary)]:
                pending = [root]
                while pending:
                    path = pending.pop()
                    try:
                        info = path.lstat()
                    except FileNotFoundError:
                        continue
                    if stat.S_ISLNK(info.st_mode):
                        raise P.CycleStopped("owned output symlink")
                    self.validate_held()
                    self.maxima[component, str(path)] = max(
                        self.maxima.get((component, str(path)), 0), info.st_blocks * 512
                    )
                    # An observed violating maximum stays retained even when refusal follows.
                    self.validate_held()
                    if stat.S_ISDIR(info.st_mode):
                        pending.extend(path.iterdir())
                    elif not stat.S_ISREG(info.st_mode):
                        raise P.CycleStopped("unsupported output type")

    def execute(name, command):
        L.quiet()
        physical_before_child(L)
        for path, record in a["bindings"].items():
            verify(path, record)
        resources.check()
        receipt = output / (name + ".process.json")
        attempts.append({"name": name, "command": command, "receipt": str(receipt)})
        returned = P.execute(
            command, output / (name + ".log"), None, cpu_core=0, resources=resources
        )
        result.setdefault("returned_process_finalization", {})[name] = {
            key: returned.get(key, "UNKNOWN")
            for key in (
                "signal_mask_restoration",
                "final_record_persist",
                "handle_closes_complete",
                "process_cleanup_complete",
            )
        }
        if not receipt_ok(returned, command):
            raise ValueError("command/directwait/cleanup/full-log refusal: " + name)

    try:
        os.environ.update(a["environment"])
        os.sched_setaffinity(0, {2})
        output.mkdir()
        temporary.mkdir()
        os.environ["TMPDIR"] = str(temporary)
        resources = Resources()
        resources.check()
        result["actual_START"] = datetime.now(timezone.utc).isoformat()
        for name, command in a["commands"][:2]:
            execute(name, command)
    except BaseException as error:
        primary = error
    finally:
        # Each whole availability/action stage is independently attempted.
        result["saved_recovery_availability"] = "UNKNOWN; availability not established"

        def recover_stage():
            start = native / "manifest-start.json"
            if resources is not None and start.is_file() and not start.is_symlink():
                result["saved_recovery_availability"] = "owned start manifest/resources available"
                name, command = a["commands"][2]
                execute(name, command)
            else:
                result["saved_recovery_availability"] = "unavailable owned start manifest/resources"

        attempt("saved_recovery", recover_stage)

        def census_stage():
            census = E.saved_census(native)
            result["slot_census"] = census
            if census.get("saved_evidence_errors"):
                raise ValueError(
                    "saved evidence refusals: " + json.dumps(census["saved_evidence_errors"])
                )

        attempt("saved_census", census_stage)
        report = native / "result.json"
        result["saved_report_availability"] = "UNKNOWN; availability not established"

        def clock_stage():
            if report.is_file() and not report.is_symlink():
                result["saved_report_availability"] = "available; validation separately recorded"
                result["clock_census"] = clock_census(json.loads(report.read_bytes()))
            else:
                result["saved_report_availability"] = "unavailable report"

        def report_binding_stage():
            if report.is_file() and not report.is_symlink():
                result["run_report"] = {"path": str(report), "sha256": L.sha(report)}

        attempt("saved_clock_census", clock_stage)
        attempt("run_report_binding", report_binding_stage)
        attempt("source_after", lambda: [verify(p, r) for p, r in a["bindings"].items()])
        if resources is not None:
            attempt("final_resources", resources.check)
        for row in attempts:
            receipt = attempt(
                "receipt:" + row["name"],
                lambda row=row: json.loads(Path(row["receipt"]).read_bytes()),
            )
            receipts.append(
                {
                    "attempt": row,
                    "receipt": receipt,
                    "verified": receipt_ok(receipt, row["command"]),
                    "cleanup_verified": receipt_cleanup_ok(receipt, row["command"]),
                }
            )
        unknown = not all(row["cleanup_verified"] for row in receipts)
        incomplete = len(receipts) != 3 or not all(row["verified"] for row in receipts)
        result.update(
            primary_error=None
            if primary is None
            else {"type": type(primary).__name__, "message": str(primary)},
            attempted_children=attempts,
            receipts=receipts,
            native_process_cleanup_unknown=unknown,
            native_process_cleanup_complete=not unknown,
            source_STOP=datetime.now(timezone.utc).isoformat(),
            stage_failures=errors,
            independent_finalizer_attempts=finalizers,
            family_RSS_sample_peak_B=None if resources is None else resources.family_peak,
        )
        if resources is not None:
            attempt(
                "held_charges",
                lambda: write_json(output / "held-charges.json", E.rows(resources.maxima)),
            )
        result["owned_TMP_availability"] = "UNKNOWN; availability not established"

        def temporary_stage():
            if unknown:
                result["owned_TMP_availability"] = "UNKNOWN native cleanup; retained"
            elif temporary.exists():
                result["owned_TMP_availability"] = "exists; empty removal separately recorded"
                temporary.rmdir()
            else:
                result["owned_TMP_availability"] = "absent"

        attempt("owned_empty_TMP", temporary_stage)
        attempt("result", lambda: write_json(output / "cohort-result.json", result))
        attempt(
            "diagnostic",
            lambda: print(json.dumps({"provisional_cohort_facts": result}), flush=True),
        )
        attempt("lock_close", lock.close)
        # No post-lease file publication. The external controller persists success
        # or these final facts/primary notes only after its real direct wait.
        terminal = {
            "independent_finalizer_errors": errors,
            "independent_finalizer_attempts": finalizers,
            "result_publication": next(r["status"] for r in finalizers if r["stage"] == "result"),
            "native_process_cleanup_unknown": unknown,
            "cohort_incomplete": incomplete,
            "guardian_overall_cleanup": "failed_UNKNOWN"
            if errors or unknown
            else "requires successful external controller",
        }
        if primary is not None:
            primary.add_note(json.dumps(terminal))
            raise primary
        if errors or unknown or incomplete:
            raise RuntimeError("cohort incomplete: " + json.dumps(terminal))


if __name__ == "__main__":
    main()
