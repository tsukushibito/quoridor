"""Only new C01-C05 synthetic saved-control/main ports; no native execution."""

from contextlib import ExitStack
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
PROGRESS = []


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def put(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj) + "\n")
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def refuses(action):
    try:
        action()
    except (ValueError, KeyError, TypeError, RuntimeError):
        return
    raise AssertionError("expected refusal")


def main_port(W, E, forecast):
    origin, fault, failures = None, "none", ()
    with tempfile.TemporaryDirectory(dir=HERE / "ports-tmp-v20") as temp:
        root = Path(temp)
        out = root / "control"
        tmp = root / "tmp"
        n = root / "native"
        n.mkdir()
        put(n / "manifest-start.json", {"synthetic": True})
        put(
            n / "result.json",
            {
                "planned": 16,
                "outcomes": [
                    {"game": g, "status": "unknown", "observations": []} for g in range(16)
                ],
            },
        )
        if fault == "malformed_result":
            (n / "result.json").write_text("{partial")
            (n / "completed.jsonl").write_text(
                json.dumps(
                    {"game": 0, "status": "unknown", "failure": "illegal_move", "observations": []}
                )
                + "\n{partial"
            )
        prior = root / "prior.json"
        put(prior, [])
        f = root / "forecast.json"
        put(f, forecast)
        cmds = [[name, ["synthetic-native", name]] for name in ("arena", "audit", "recover")]
        adm = {
            "role": "D",
            "actual_entry": True,
            "prepared_only": False,
            "pending_obligations": [],
            "required_imports": W.REQUIRED_IMPORTS,
            "bindings": {},
            "helper": "synthetic-guard",
            "evidence_helper": "synthetic-evidence",
            "whole_forecast": str(f),
            "output": str(out),
            "native_output": str(n),
            "TMP": str(tmp),
            "prior_charges": str(prior),
            "environment": {},
            "commands": cmds,
        }
        adm["bindings"] = {
            p: {} for p in [adm["helper"], adm["evidence_helper"], *W.REQUIRED_IMPORTS]
        }
        ap = root / "admission.json"
        raw = json.dumps(adm).encode()
        ap.write_bytes(raw)
        executed = []
        final = []
        pins = {0, 2}
        physical_calls = []

        def affinity(pid, cpus):
            nonlocal pins
            pins = set(cpus)

        def physical():
            assert pins == {0, 2}
            physical_calls.append(set(pins))

        class Lease:
            def close(self):
                final.append("lock_close")
                if "lock_close" in failures:
                    raise OSError("synthetic lease close")

        class Base:
            def __init__(self, config, output, deadline):
                self.memory_limit = config["max_memory_bytes"]

            def check(self, owned=()):
                if len(executed) == 3 and "final_resources" in failures:
                    raise OSError("synthetic final resource")

        def execute(argv, log, deadline, **kwargs):
            assert pins == {2} and kwargs["cpu_core"] == 0
            executed.append(argv[-1])
            r = {
                "command": argv,
                "exit_code": 1 if origin == argv[-1] else 0,
                "direct_child_reaped": True,
                "cleanup_complete": True,
                "remaining": [],
                "log_bytes_seen": 1,
                "log_bytes_retained": 1,
                "handle_closes_complete": True,
                "process_cleanup_complete": True,
                "signal_mask_restoration": "completed",
                "final_record_persist": "completed",
            }
            put(log.with_suffix(".process.json"), r)
            if "receipt" in failures and argv[-1] == "recover":
                log.with_suffix(".process.json").write_text("[1]")
            return r

        def write(path, data):
            name = {
                "held-charges.json": "held_charges",
                "cohort-result.json": "result",
            }[path.name]
            final.append(name)
            if name in failures:
                raise OSError("synthetic " + name)
            put(path, data)

        def verify(*args):
            if len(executed) == 3 and "source_after" in failures:
                raise OSError("synthetic source after")

        def rmdir(path):
            if path == tmp and "owned_empty_TMP" in failures:
                final.append("owned_empty_TMP")
                raise OSError("synthetic TMP")
            return real_rmdir(path)

        def diagnostic(*args, **kwargs):
            final.append("diagnostic")
            if "diagnostic" in failures:
                raise OSError("synthetic diagnostic")

        package = ModuleType("quoridor_training")
        package.__path__ = []
        package.cycle_process = SimpleNamespace(
            CycleResources=Base,
            execute=execute,
            process_info=lambda pid: {"rss": 0},
            CycleStopped=RuntimeError,
        )
        snapshot = ModuleType("quoridor_training.snapshot")
        snapshot.write_json = write
        guard = SimpleNamespace(
            quiet=lambda: None,
            physical=physical,
            sha=lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest(),
        )
        fakeE = SimpleNamespace(
            BASELINE=prior,
            ledger=lambda rows, *args: {
                (r["component"], r["path"]): r["maximum_sampled_allocated_B"] for r in rows
            },
            rows=E.rows,
            saved_census=E.saved_census,
        )
        real_rmdir = Path.rmdir
        error = None
        real_methods = {key: getattr(Path, key) for key in ("is_file", "is_symlink", "exists")}
        targets = {
            "manifest_is_file": (n / "manifest-start.json", "is_file"),
            "manifest_is_symlink": (n / "manifest-start.json", "is_symlink"),
            "result_is_file": (n / "result.json", "is_file"),
            "result_is_symlink": (n / "result.json", "is_symlink"),
            "TMP_exists": (tmp, "exists"),
        }

        def method(key):
            def checked(path):
                if fault in targets and targets[fault] == (path, key):
                    raise OSError(5, "synthetic availability EIO " + fault)
                return real_methods[key](path)

            return checked

        with ExitStack() as stack:
            for obj, key, value in [
                (sys, "argv", ["port", str(ap), hashlib.sha256(raw).hexdigest()]),
                (W, "review_and_fixed_proofs", lambda *args: None),
                (W, "validate", lambda *args: None),
                (W, "verify", verify),
                (W, "LOCK", SimpleNamespace(open=lambda mode: Lease())),
                (
                    W,
                    "fcntl",
                    SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *args: None),
                ),
                (W.os, "sched_setaffinity", affinity),
                (W.os, "sched_getaffinity", lambda pid: set(pins)),
                (
                    W.importlib.util,
                    "spec_from_file_location",
                    lambda name, path: SimpleNamespace(
                        name=name, loader=SimpleNamespace(exec_module=lambda m: None)
                    ),
                ),
                (
                    W.importlib.util,
                    "module_from_spec",
                    lambda spec: fakeE if spec.name == "cohort_evidence" else guard,
                ),
                (Path, "rmdir", rmdir),
            ]:
                stack.enter_context(patch.object(obj, key, value))
            for key in real_methods:
                stack.enter_context(patch.object(Path, key, method(key)))
            stack.enter_context(
                patch.dict(
                    sys.modules,
                    {
                        "quoridor_training": package,
                        "quoridor_training.snapshot": snapshot,
                    },
                )
            )
            stack.enter_context(patch.dict(W.os.environ, {}, clear=False))
            stack.enter_context(patch("builtins.print", diagnostic))
            try:
                W.main()
            except BaseException as err:
                error = err
        assert executed == ["arena", "audit", "recover"]
        assert error is None and final[-1] == "lock_close"
        assert pins == {2} and physical_calls == [{0, 2}] * 4
        saved = json.loads((out / "cohort-result.json").read_text())
        assert saved["provisional_only"] and not saved["external_controller_acceptance"]
        assert saved["stage_failures"] == [] and saved["slot_census"]["planned_ids"] == list(
            range(16)
        )


def run(W, E, real_guard):
    passed = PROGRESS
    for kind in (
        "normal",
        "widen_failure",
        "physical_failure",
        "restore_failure",
        "primary_plus_restore_failure",
        "wrong_pin0",
        "wrong_pin02",
    ):
        pins = {0} if kind == "wrong_pin0" else {0, 2} if kind == "wrong_pin02" else {2}
        calls = []
        origin = ValueError("synthetic physical primary")

        def set_affinity(pid, cpus):
            nonlocal pins
            calls.append(set(cpus))
            if cpus == {0, 2} and kind == "widen_failure":
                raise OSError("synthetic widen refusal")
            if cpus == {2} and kind in ("restore_failure", "primary_plus_restore_failure"):
                raise OSError("synthetic restore refusal")
            pins = set(cpus)

        def physical():
            assert pins == {0, 2}
            if kind in ("physical_failure", "primary_plus_restore_failure"):
                raise origin

        error = None
        with (
            patch.object(W.os, "sched_getaffinity", lambda pid: set(pins)),
            patch.object(W.os, "sched_setaffinity", set_affinity),
        ):
            try:
                W.physical_before_child(SimpleNamespace(physical=physical))
            except BaseException as e:
                error = e
        if kind == "normal":
            assert error is None and pins == {2} and calls == [{0, 2}, {2}]
        elif kind.startswith("wrong_pin"):
            assert isinstance(error, ValueError) and calls == []
        elif kind in ("physical_failure", "primary_plus_restore_failure"):
            assert error is origin
            if kind == "primary_plus_restore_failure":
                assert "guardian_affinity_restore" in error.__notes__[-1]
            else:
                assert pins == {2}
        else:
            assert isinstance(error, OSError)
            if kind == "widen_failure":
                assert pins == {2}
        passed.append("per-child affinity actual helper port " + kind)
    original = W.os.sched_getaffinity(0)
    try:
        W.os.sched_setaffinity(0, {2})
        W.physical_before_child(real_guard)
        assert W.os.sched_getaffinity(0) == {2}
    finally:
        W.os.sched_setaffinity(0, original)
    passed.append("actual Linux pinned guardian2 physical inlet02 check restores2; no child")
    main_port(
        W, E, json.loads((HERE.parent / "cohort-repair-v18/whole-forecast-v18.json").read_text())
    )
    passed.append(
        "actual main entry+three fake-child boundaries check02 restoreguardian2 before childCPU0"
    )
    return {
        "passed_new_cases": passed,
        "count": len(passed),
        "actual_native_Cargo_backend_Search_model_games": 0,
        "old45_plus23_successes_replayed": False,
    }
