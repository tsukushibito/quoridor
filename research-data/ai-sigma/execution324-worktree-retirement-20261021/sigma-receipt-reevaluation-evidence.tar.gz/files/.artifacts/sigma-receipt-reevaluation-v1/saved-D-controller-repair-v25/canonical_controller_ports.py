"""S01 only: actual joins refuse SHA-bound sibling controllers; no old suite execution."""

import ast
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OLD = ROOT / "saved-D-route-preparation-v24"
PROGRESS = []


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def require_refusal(action, reason):
    try:
        action()
    except ValueError as error:
        assert str(error) == reason, repr(error)
        return
    raise AssertionError("bound sibling controller or bad downstream evidence admitted")


def canonical_record(save, path, original, status):
    if status == "missing":
        path.unlink(missing_ok=True)
    elif status == "failed":
        save(path, {**original, "outcome": "failed", "exit_code": 1})
    elif status == "unknown":
        save(path, {**original, "cleanup_complete": False, "remaining": None})
    else:
        raise AssertionError(status)


def cases(
    H,
    W,
    E,
    refs,
    objects,
    bindings,
    bundle,
    root,
    runtime,
    pub,
    save,
    science,
    custody,
    config,
    state,
    controller,
    admission_ref,
):
    # The fixed v24 fixture's setup only is reused. No old test body runs.
    with (
        patch.object(H, "read_stopped_inputs", lambda: (science, {})),
        patch.object(H, "stopped_custody", lambda *args: deepcopy(custody)),
    ):
        for status in ("missing", "failed", "unknown"):
            sibling = save(runtime / "claimed-result.json", controller)
            canonical_record(save, runtime / "result.json", controller, status)
            refs["controller"] = sibling
            require_refusal(
                lambda: H.derive_completed_saved_D(bundle, bindings, W, E),
                "same authoritative completion runtime",
            )
            PROGRESS.append("audit_sibling/canonical_" + status)
        refs["controller"] = save(runtime / "result.json", controller)
        original_admission = objects["admission"]
        refs["admission"] = save(
            Path(admission_ref["path"]), {**original_admission, "purpose": "bad-downstream-purpose"}
        )
        require_refusal(
            lambda: H.derive_completed_saved_D(bundle, bindings, W, E),
            "only actual saved-only completion admission",
        )
        PROGRESS.append("audit_canonical/path_reaches_unchanged_downstream_guard")
        refs["admission"] = save(Path(admission_ref["path"]), original_admission)

    # Publication tests isolate its new canonical-result join; they do not rerun
    # the unchanged successful audit derivation or claim an actual audit.
    derived = {"role": "D", "identities": [], "controller_STOP": "2026-10-09T12:00:02+00:00"}
    bundle_ref = save(root / "bundle.json", bundle)
    candidate = {
        "schema": "quoridor.completed-D-saved-route-candidate.v1",
        "admitting": False,
        "evidence_bundle": bundle_ref,
        "derived": derived,
    }
    candidate_ref = save(root / "candidate.json", candidate)
    pubconfig = {
        **config,
        "argv": [
            "/usr/bin/python3.11",
            "-B",
            str(OLD / "stopped_science.py"),
            "--control",
            admission_ref["path"],
            "--control-sha256",
            admission_ref["sha256"],
            "--bundle",
            bundle_ref["path"],
            "--bundle-sha256",
            bundle_ref["sha256"],
            "--output",
            candidate_ref["path"],
        ],
    }
    pubstate = {
        **state,
        "job_id": "synthetic-new-publication",
        "started_at": "2026-10-09T12:00:03+00:00",
        "config_sha256": hashlib.sha256(json.dumps(pubconfig, sort_keys=True).encode()).hexdigest(),
    }
    pubcontroller = {
        **controller,
        "job_id": pubstate["job_id"],
        "finished_at": "2026-10-09T12:00:04+00:00",
    }
    pubrefs = {
        "config": save(pub / "config.json", pubconfig),
        "state": save(pub / "state.json", pubstate),
        "controller": save(pub / "result.json", pubcontroller),
        "candidate": candidate_ref,
    }
    proof = {
        "schema": "quoridor.completed-D-saved-route.v1",
        "evidence_bundle": bundle_ref,
        "derived": derived,
        "publication": pubrefs,
    }
    with patch.object(H, "derive_completed_saved_D", lambda *args: deepcopy(derived)):
        for status in ("missing", "failed", "unknown"):
            pubrefs["controller"] = save(pub / "claimed-result.json", pubcontroller)
            canonical_record(save, pub / "result.json", pubcontroller, status)
            proof_ref = save(root / "completed-proof.json", proof)
            require_refusal(
                lambda: H.consume_completed_saved_D(proof_ref, {"bindings": bindings}, W, E),
                "same authoritative publication runtime",
            )
            PROGRESS.append("publication_sibling/canonical_" + status)
        pubrefs["controller"] = save(pub / "result.json", pubcontroller)
        pubrefs["candidate"] = save(root / "candidate.json", {**candidate, "admitting": True})
        proof_ref = save(root / "completed-proof.json", proof)
        require_refusal(
            lambda: H.consume_completed_saved_D(proof_ref, {"bindings": bindings}, W, E),
            "provisional candidate differs from actual derivation",
        )
        PROGRESS.append("publication_canonical/path_reaches_unchanged_downstream_guard")


def main():
    T = load(OLD / "saved_route_ports.py", "retained_fixture_definitions24")
    H = T.load(OLD / "stopped_science.py", "S01_current_reader")
    W = T.load(ROOT / "saved-control-repair-v23/cohort_worker.py", "retained_checks23")
    E = T.load(ROOT / "cohort-repair-v18/cohort_evidence.py", "retained_ledger18")
    source = ast.parse((OLD / "saved_route_ports.py").read_text())
    fixture = deepcopy(
        next(
            n
            for n in source.body
            if isinstance(n, ast.FunctionDef) and n.name == "completion_ports"
        )
    )
    fixture.name = "fixture_setup_only"
    outer = next(n for n in fixture.body if isinstance(n, ast.With))
    cutoff = next(i for i, n in enumerate(outer.body) if isinstance(n, ast.With))
    # Compile only the existing setup plus the new eight cases, never any old
    # positive/refusal assertion body or native/worker execution.
    outer.body = (
        outer.body[:cutoff]
        + ast.parse(
            "cases(H, fakeW, fakeE, refs, objects, bindings, bundle, root, runtime, pub, save, science, custody, config, state, controller, admission_ref)"
        ).body
    )
    namespace = dict(T.__dict__)
    namespace["cases"] = cases
    namespace["tempfile"] = SimpleNamespace(
        TemporaryDirectory=lambda **kwargs: tempfile.TemporaryDirectory(dir=HERE / "ports-TMP")
    )
    module = ast.fix_missing_locations(ast.Module(body=[fixture], type_ignores=[]))
    exec(compile(module, str(HERE / "fixture-setup-only"), "exec"), namespace)
    namespace["fixture_setup_only"](H, W, E)
    print(json.dumps({"new_cases": PROGRESS, "native_model_geometry_Search_games": 0}))


if __name__ == "__main__":
    main()
