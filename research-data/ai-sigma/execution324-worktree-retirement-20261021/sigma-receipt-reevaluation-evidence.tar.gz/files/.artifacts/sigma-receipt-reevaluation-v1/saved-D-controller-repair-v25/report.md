# S01 stopped ordinary repair

Both saved-D joins now require the referenced controller be the canonical same-runtime result.json. Only two predicates changed; the rest of stopped_science.py is AST-exact against the preserved v24 preimage. Old G/NN source and false/history/failed records remain fixed.

Eight new cases passed in0.069014311s under fresh physical/namedquiet/nonblocking lifetime guards, CPU3/AS512MiB/GPU0. They exercise the actual new audit/publication joins with SHA-bound sibling success records while the canonical result is absent, failed or has unknown cleanup. Canonical paths reach their existing downstream predicates. Old62 tests and late-close evidence were reused, not executed. The publication tests mock the unchanged audit derivation; no runtime completion certificate follows.

Source/control only. No native audit, games, model/backend/geometry/Search/Cargo/private/library operation. Original19524 D16 already executed once and remains FAILED with lost captures; audit and NNUE16 remain unrun. New exact stopped target must return to SAME347.5 before actual saved work; no method or reply ACK gate. Original4GiB/caps/fees/RAW/masks/UNKNOWN/defaults/N/seals/323pause remain held.
