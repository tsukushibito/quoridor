"""Focused actual-AST fake-port checks; no build, private payload, or model call."""

import ast
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import stat
import sys
import time
from types import SimpleNamespace


def main():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    os.sched_setaffinity(0, {3})
    started = time.monotonic()
    source = (
        Path(__file__).resolve().parents[1] / "materialization-v2/software_worker.py"
    )
    raw = source.read_bytes()
    module = ast.parse(raw)
    selected = {"sha", "verify", "validate_target_lease", "validate"}
    definitions = [
        node
        for node in module.body
        if isinstance(node, ast.FunctionDef) and node.name in selected
    ]
    assert len(definitions) == 4
    state = {}
    data = b"retained fake object"
    record = {
        "SHA256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": 420,
    }
    initial = {
        "target": "/owned-target",
        "environment": {"RUSTC": "/fixed-rustc", "profile": "release3"},
        "files": {"/owned-target/object": record},
    }
    admission = {
        "target": "/owned-target",
        "environment": initial["environment"],
        "target_lease": {"path": "/lease", "SHA256": None},
    }

    class FakePath:
        def __init__(self, value):
            self.value = str(value)

        def __str__(self):
            return self.value

        def __eq__(self, other):
            return self.value == str(other)

        def read_bytes(self):
            assert self.value == "/lease"
            return state["raw"]

        def lstat(self):
            if state.get("missing"):
                raise FileNotFoundError(self.value)
            return SimpleNamespace(
                st_mode=stat.S_IFREG | state.get("mode", 420),
                st_size=state.get("size", len(data)),
            )

        def resolve(self, strict):
            assert strict
            return self

        def open(self, mode):
            assert mode == "rb"
            return io.BytesIO(state.get("payload", data))

        def is_relative_to(self, other):
            return self.value.startswith(str(other) + "/")

        def rglob(self, pattern):
            assert pattern == "*"
            return [FakePath(v) for v in state.get("actual", ["/owned-target/object"])]

        def is_file(self):
            return True

        def is_symlink(self):
            return False

    ports = {"Path": FakePath, "hashlib": hashlib, "json": json, "stat": stat}
    exec(
        compile(ast.Module(body=definitions, type_ignores=[]), str(source), "exec"),
        ports,
    )
    passed = []

    def check(name, mutation=None, refused=False):
        state.clear()
        lease = copy.deepcopy(initial)
        if mutation:
            mutation(lease)
        state["raw"] = json.dumps(lease).encode()
        ad = copy.deepcopy(admission)
        ad["target_lease"]["SHA256"] = hashlib.sha256(state["raw"]).hexdigest()
        if name == "changed_raw_digest":
            ad["target_lease"]["SHA256"] = "0" * 64
        try:
            ports["validate_target_lease"](ad)
        except (ValueError, FileNotFoundError, KeyError):
            assert refused, name
        else:
            assert not refused, name
        passed.append(name)

    if sys.argv[1:] != ["--census-only"]:
        check("matching_retained_target")
        check("changed_raw_digest", refused=True)
        check("changed_payload", lambda _: state.update(payload=b"changed"), True)
        check("wrong_mode", lambda _: state.update(mode=384), True)
        check("wrong_size", lambda _: state.update(size=len(data) + 1), True)
        check("missing_file", lambda _: state.update(missing=True), True)
        check(
            "unexpected_target_file",
            lambda _: state.update(
                actual=["/owned-target/object", "/owned-target/extra"]
            ),
            True,
        )
        check(
            "changed_compiler_profile",
            lambda lease: lease["environment"].update(profile="debug"),
            True,
        )
        check(
            "foreign_target_member",
            lambda lease: lease["files"].update({"/foreign/object": record}),
            True,
        )

        try:
            ports["validate"]({"actual_entry": False, "prepared_only": True})
        except ValueError as error:
            assert str(error) == "prepared software is not an actual entry"
        else:
            raise AssertionError("preparedfalse did not refuse before ports")
        passed.append("preparedfalse_before_inputs")

    function = next(
        node
        for node in module.body
        if isinstance(node, ast.FunctionDef) and node.name == "main"
    )
    assignment = [
        node
        for node in ast.walk(function)
        if isinstance(node, ast.Assign)
        and isinstance(node.value, ast.BoolOp)
        and any(
            isinstance(t, ast.Subscript)
            and isinstance(t.slice, ast.Constant)
            and t.slice.value == "qualified"
            for t in node.targets
        )
    ]
    assert len(assignment) == 1
    code = compile(ast.Module(body=assignment, type_ignores=[]), str(source), "exec")
    for name, count, primary, unknown, expected in [
        ("exact_new_four", 4, None, False, True),
        ("missing_new_receipt", 3, None, False, False),
        ("old_receipt_mixed_into_new_census", 5, None, False, False),
        ("primary_clears_qualification", 4, ValueError("primary"), False, False),
        ("cleanup_unknown_refuses", 4, None, True, False),
    ]:
        scope = {
            "result": {},
            "receipts": [None] * count,
            "primary": primary,
            "errors": [],
            "unknown": unknown,
        }
        exec(code, scope)
        assert scope["result"]["qualified"] is expected, name
        passed.append(name)
    status = Path("/proc/self/status").read_text().splitlines()
    hwm = next(int(line.split()[1]) for line in status if line.startswith("VmHWM:"))
    print(
        json.dumps(
            {
                "PASS": passed,
                "source_SHA256": hashlib.sha256(raw).hexdigest(),
                "internal_wall_seconds": time.monotonic() - started,
                "VmHWM_KiB": hwm,
                "CPU": 3,
                "AS_bytes": 512 * 1024**2,
                "real_payload_process_backend_model_calls": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
