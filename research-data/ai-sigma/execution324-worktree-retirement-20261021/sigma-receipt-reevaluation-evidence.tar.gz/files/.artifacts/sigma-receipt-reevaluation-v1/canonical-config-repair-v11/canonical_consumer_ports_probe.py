"""Only completed-consumer representation ports; no worker/backend/module import."""

import ast
import hashlib
import io
import json
from pathlib import Path
import stat
from types import SimpleNamespace

SOURCE = Path(__file__).with_name("materialize_live.py")
ROOT = SOURCE.parent.parent
FUNCTIONS = {
    n.name: n for n in ast.parse(SOURCE.read_text()).body if isinstance(n, ast.FunctionDef)
}
WITNESS = ROOT.parent / "deeper-teacher-generation-v1/generation-runtime-v1"
actual_raw = (WITNESS / "config.json").read_bytes()
actual_config = json.loads(actual_raw)
actual_state = json.loads((WITNESS / "state.json").read_bytes())
semantic = hashlib.sha256(json.dumps(actual_config, sort_keys=True).encode()).hexdigest()
raw_digest = hashlib.sha256(actual_raw).hexdigest()
compact = hashlib.sha256(
    json.dumps(actual_config, sort_keys=True, separators=(",", ":")).encode()
).hexdigest()
assert semantic == actual_state["config_sha256"]
assert len({semantic, raw_digest, compact}) == 3
assert actual_raw == (json.dumps(actual_config, ensure_ascii=False, indent=2) + "\n").encode()
checks = []


def case(mode):
    memory, published = {}, []
    runtime = SOURCE.parent / "FAKE-runtime"
    output = SOURCE.parent / "FAKE-output"
    ad_path = str(SOURCE.parent / "FAKE-admission.json")

    def save(path, value):
        raw = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
        memory[str(path)] = raw
        return [str(path), hashlib.sha256(raw).hexdigest()]

    admission = {
        "actual_entry": True,
        "prepared_only": False,
        "pending_obligations": [],
        "output": str(output),
        "campaign": {"path": "FAKE-campaign", "sha256": "c" * 64},
    }
    ad_ref = save(ad_path, admission)
    config = {
        "issue": "quoridor-4lc.347.2",
        "goal_issue": "quoridor-4lc.347",
        "thread_id": "01a11062-b120-73a1-8aa3-fe2cb922c7c0",
        "cwd": str(ROOT.parents[1]),
        "resource_contract": ad_path,
        "argv": ["/usr/bin/python3.11", "-B", str(SOURCE.with_name("live_worker.py")), *ad_ref],
    }
    config_ref = save(runtime / "config.json", config)
    canonical = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
    assert canonical != config_ref[1]
    state = {
        "config_sha256": canonical,
        "job_id": "FAKE-only",
        "phase": "finished",
        "outcome": "succeeded",
    }
    controller = {
        "job_id": "FAKE-only",
        "outcome": "succeeded",
        "error": None,
        "exit_code": 0,
        "direct_child_reaped": True,
        "cleanup_complete": True,
        "remaining": [],
        "cleanup_errors": [],
        "descendant_visibility": "observed",
        "log_bytes_seen": 0,
        "log_bytes_retained": 0,
        "finished_at": "FAKE-STOP",
    }
    attempts = [
        {"name": name, "command": ["FAKE-never-executed", name]}
        for name in ("untimed", "qualified-timed")
    ]
    receipts = [
        {
            "verified": True,
            "attempt": a,
            "receipt": {
                "command": a["command"],
                "exit_code": 0,
                "direct_child_reaped": True,
                "cleanup_complete": True,
                "remaining": [],
            },
        }
        for a in attempts
    ]
    native_refs = [{"path": "FAKE-result", "sha256": "r" * 64}]
    candidate = {
        "schema": "quoridor-sigma-cost-nonadmitting-candidate-v1",
        "admitting": False,
        "campaign": admission["campaign"],
        "results": native_refs,
        "packet": {"schema": "quoridor-sigma-cost-qualification-v1", "scope": "timed-arena"},
    }
    candidate_ref = save(output / "arena-candidate.json", candidate)
    guardian = {
        "arena_qualification_candidate": {"path": candidate_ref[0], "sha256": candidate_ref[1]},
        "qualified": True,
        "purpose": "sigma-receipt-live64",
        "primary_error": None,
        "stage_failures": [],
        "cleanup_unknown": False,
        "cleanup_complete": True,
        "remaining": [],
        "games_launched": 0,
        "source_STOP": "FAKE-STOP",
        "fixed_call_census": {"warmup": 16, "measurement": 16, "timed": 32, "total": 64},
        "native_result_refs": native_refs,
        "attempted_children": attempts,
        "receipts": receipts,
    }
    if mode == "raw-state":
        state["config_sha256"] = config_ref[1]
    elif mode == "compact-state":
        state["config_sha256"] = hashlib.sha256(
            json.dumps(config, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
    elif mode == "mutated-raw":
        memory[config_ref[0]] = memory[config_ref[0]].replace(
            b"quoridor-4lc.347.2", b"quoridor-4lc.347.X"
        )
    elif mode == "failed-controller":
        state["outcome"] = controller["outcome"] = "failed"
        controller["exit_code"] = 1
    elif mode == "unknown-cleanup":
        controller["cleanup_complete"] = False
    elif mode == "guardian-finalizer":
        guardian["stage_failures"] = [{"stage": "lock_close", "message": "FAKE failure"}]
    state_ref = save(runtime / "state.json", state)
    controller_ref = save(runtime / "result.json", controller)
    guardian_ref = save(output / "live-result.json", guardian)
    args = SimpleNamespace(
        admission=ad_ref,
        job_config=config_ref,
        job_state=state_ref,
        job_result=controller_ref,
        guardian_result=guardian_ref,
        candidate=candidate_ref,
        output=str(output / "FAKE-admitted.json"),
    )

    class BoundPath:
        def __init__(self, path):
            self.path = Path(path)

        def is_absolute(self):
            return self.path.is_absolute()

        def resolve(self, strict=True):
            assert str(self.path) in memory
            return self

        def __eq__(self, other):
            return isinstance(other, BoundPath) and self.path == other.path

    class Stream(io.BytesIO):
        def fileno(self):
            return 7

    def require(condition, message):
        if not condition:
            raise ValueError(message)

    def publish(path, packet):
        published.append((path, packet))
        return {"path": path, "sha256": "FAKE-only"}

    bound_ports = {
        "Path": BoundPath,
        "os": SimpleNamespace(
            O_RDONLY=0,
            O_NOFOLLOW=0,
            open=lambda path, flags: str(path.path),
            fdopen=lambda fd, mode: Stream(memory[fd]),
            fstat=lambda fd: SimpleNamespace(st_mode=stat.S_IFREG | 0o644),
        ),
        "stat": stat,
        "json": json,
        "digest": lambda b: hashlib.sha256(b).hexdigest(),
    }
    exec(
        compile(ast.Module(body=[FUNCTIONS["bound"]], type_ignores=[]), str(SOURCE), "exec"),
        bound_ports,
    )
    ports = {
        "bound": bound_ports["bound"],
        "Path": Path,
        "ROOT": ROOT,
        "__file__": str(SOURCE),
        "require": require,
        "publish": publish,
        "hashlib": hashlib,
        "json": json,
    }
    exec(
        compile(
            ast.Module(body=[FUNCTIONS["admit_completed_guardian"]], type_ignores=[]),
            str(SOURCE),
            "exec",
        ),
        ports,
    )
    try:
        ports["admit_completed_guardian"](args)
        assert mode == "canonical-success" and len(published) == 1
    except ValueError:
        assert mode != "canonical-success" and published == []
    checks.append(mode)


for mode in (
    "canonical-success",
    "raw-state",
    "compact-state",
    "mutated-raw",
    "failed-controller",
    "unknown-cleanup",
    "guardian-finalizer",
):
    case(mode)
print(
    json.dumps(
        {
            "PASS": checks,
            "source_SHA256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "actual_failed_writer_witness_only": {
                "raw": raw_digest,
                "canonical": semantic,
                "compact_not_used": compact,
            },
            "scope": "new writer-representation combinations with actual bound and completed-consumer AST/IO ports; failed real witness never admitted; no native/worker/model/Search/Popen or prior11+13 replay",
        },
        indent=2,
    )
)
