# SAME347.5: G01-C01 canonical controller identity only

Confirm only the single materializer predicate delta from fa2c/63ee27c4 to the stopped current body: bound config raw SHA remains mandatory; state config fingerprint uses the exact maintained sorted JSON representation. Read the new seven representation ports/saved result, actual afc FAILED config/state writer witness and directed controller/runtime writer definitions. Inspect supplied PASS without execution. Reuse accepted non-admitting G01/G02/old11+13/worker/source/private/formula/math proofs without replay.

Every other completed admission/finalization predicate, native evidence/campaign/expiry/formula/64 allocation and worker85194189 is unchanged. Preparedfalse; no actual admission/backend/model/game certificate or hardware reservation. Return final fixed findings/control SHAs and actual readerSTOP to347.2+324 once. Existing reviewer only; no whole348/owner/N/Main/RootreplyACK or new method gate.
