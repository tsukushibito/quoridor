"""One finite32+32 receipt qualification; maintained native delegates own calls."""

from builtins import BaseExceptionGroup
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
WT = ROOT.parents[1]
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
EXPIRY = 1791583340854
REQUIRED_IMPORTS = {
    "/workspaces/quoridor/python/quoridor_training/__init__.py": {
        "SHA256": "05011521a4993db992001289548d4c90516495129bc60b9882d6b7211c60aee5",
        "bytes": 216,
        "mode": 420,
    },
    "/workspaces/quoridor/python/quoridor_training/cycle_process.py": {
        "SHA256": "ddaa2881335488c719ad6941ac18becf1c544debf7e28037c9977d87cd6f060b",
        "bytes": 20479,
        "mode": 420,
    },
    "/workspaces/quoridor/python/quoridor_training/snapshot.py": {
        "SHA256": "ed0814965c012d6ad5ad094e653158b42b5d4ebf17463706ce53d029bc704341",
        "bytes": 1232,
        "mode": 420,
    },
}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def verify(path, record):
    path = Path(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or path.resolve(strict=True) != path:
        raise ValueError("canonical regular bound input required: " + str(path))
    if (stat.S_IMODE(info.st_mode), info.st_size, sha(path)) != (
        record["mode"],
        record["bytes"],
        record["SHA256"],
    ):
        raise ValueError("bound SHA/mode/length changed: " + str(path))


def sources(admission):
    for path, record in admission["bindings"].items():
        verify(path, record)


def descriptor(path):
    return {"path": str(path), "sha256": sha(path)}


def import_bound(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def quiet():
    names = {
        "cargo",
        "rustc",
        "clippy-driver",
        "cargo-clippy",
        "perf",
        "quoridor-runner",
        "chrome",
        "chromium",
        "chrome-headless-shell",
    }
    markers = (
        "software_worker",
        "software_guard",
        "numeric-worker",
        "numeric_worker",
        "qualify.py",
        "statistics.py",
        "train.py",
        "trainer.py",
        "matches-worker",
        "finite-driver",
        "public-synthetic",
        "execute-retention.py",
        "live_worker.py",
    )
    competitors = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdecimal() or int(entry.name) == os.getpid():
            continue
        try:
            argv = [os.fsdecode(v) for v in (entry / "cmdline").read_bytes().split(b"\0") if v]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not argv:
            continue
        executable = Path(argv[0]).name
        if (
            executable in names
            or executable.startswith(("quoridor_runner-", "measure_native", "profile_native"))
            or (
                executable.startswith("python")
                and any(Path(a).name.startswith(markers) for a in argv[1:])
            )
        ):
            competitors.append({"pid": int(entry.name), "argv": argv})
    if competitors:
        raise RuntimeError("PRESTART actual named competitor: " + json.dumps(competitors))


def physical():
    ram = next(
        int(line.split()[1]) * 1024
        for line in Path("/proc/meminfo").read_text().splitlines()
        if line.startswith("MemAvailable:")
    )
    cores = [
        tuple(
            (Path(f"/sys/devices/system/cpu/cpu{cpu}/topology") / field).read_text().strip()
            for field in ("physical_package_id", "core_id")
        )
        for cpu in (0, 2)
    ]
    fs = os.statvfs(ROOT)
    if (
        ram < 6 * 1024**3
        or not {0, 2}.issubset(os.sched_getaffinity(0))
        or cores[0] == cores[1]
        or fs.f_bavail * fs.f_frsize < 4294967296
    ):
        raise ValueError("fresh family2GiB/host4GiB/distinctCPU0,2/whole4GiB filesystem refused")
    return {
        "RAM_available_B": ram,
        "CPU0_CPU2_physical": cores,
        "filesystem_available_B": fs.f_bavail * fs.f_frsize,
    }


def validate(admission):
    # First refusal is before source/input/output/TMP or backend IO.
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared live control is not entry")
    if (
        admission["purpose"] != "sigma-receipt-live64"
        or admission["pending_obligations"]
        or admission["supported_whole_B"] != 4294967296
    ):
        raise ValueError("unresolved live entry obligations or unsupported phase")
    if set(admission["native_outputs"]) != {"untimed", "qualified-timed"}:
        raise ValueError("exact two native phase output roots required")
    if (
        admission["source_review"]["control_clear"] is not True
        or not admission["source_review"]["reader_STOP"]
    ):
        raise ValueError("changed control boundary not cleared/stopped")
    required = {
        *REQUIRED_IMPORTS,
        str(Path(__file__).resolve()),
        *admission["helpers"].values(),
        admission["campaign"]["path"],
        admission["untimed_plan"]["path"],
        admission["private"]["path"],
        admission["metadata_STOP"]["path"],
        admission["prior_charges"]["path"],
        admission["source_review"]["path"],
        *admission["runtime_inputs"],
    }
    if not required.issubset(admission["bindings"]):
        raise ValueError("required source/private/control/input/evidence unbound")
    if any(admission["bindings"][path] != identity for path, identity in REQUIRED_IMPORTS.items()):
        raise ValueError("required imported package/process/publication identity changed")
    sources(admission)
    review = json.loads(Path(admission["source_review"]["path"]).read_bytes())
    if (
        review["blockers"] != 0
        or review["ordinary"] != 0
        or review["target_binding_SHA256"] != admission["source_review"]["target_binding_SHA256"]
        or review["source_reader_STOP"] != admission["source_review"]["reader_STOP"]
        or review["remaining_readers_writers_children_pending_direct_waits_cleanup_TMP"]
    ):
        raise ValueError("actual fixed control review or reader STOP mismatched")
    for key in ("campaign", "untimed_plan", "private", "metadata_STOP", "prior_charges"):
        if sha(admission[key]["path"]) != admission[key]["sha256"]:
            raise ValueError("descriptor SHA changed: " + key)
    evidence = json.loads(Path(admission["metadata_STOP"]["path"]).read_bytes())
    if (
        evidence["job_id"] != "2ee3aab1-c1fd-4c97-a70b-3f7283df4276"
        or evidence["owned_remaining"]
        or evidence["private"]["SHA256"] != admission["private"]["sha256"]
    ):
        raise ValueError("actual software/config/private proof changed")
    campaign = json.loads(Path(admission["campaign"]["path"]).read_bytes())
    plan = json.loads(Path(admission["untimed_plan"]["path"]).read_bytes())
    expected = [
        dict(
            file=evidence["native_config_bindings"][role]["config_file"],
            normalized_sha256=evidence["native_config_bindings"][role]["normalized_config_sha256"],
        )
        for role in ("d", "nnue")
    ]
    if (
        campaign["configurations"] != expected
        or campaign["native"]["executable_sha256"] != admission["private"]["sha256"]
        or campaign["native"]["compiled_sources_sha256"]
        != evidence["native_config_bindings"]["d"]["compiled_sources_sha256"]
    ):
        raise ValueError("campaign differs from actual two-config/private/source identity")
    if (
        campaign["valid_until_unix_ms"] != EXPIRY
        or campaign["native"]["valid_until_unix_ms"] != EXPIRY
        or int(time.time() * 1000) >= EXPIRY
    ):
        raise ValueError("immutable expiry stale/retargeted")
    if campaign["maximum_total_logical_backend_rows_or_requests"] != 64 or campaign[
        "cost_formula_prebound"
    ] != {"factor": 4, "additive_margin_ns": 2000000}:
        raise ValueError("fixed64/formula changed")
    if len(campaign["phases"]) != 2:
        raise ValueError("exact untimed and timed phases required")
    for i, phase in enumerate(campaign["phases"]):
        if (
            phase["mode"] != ("untimed" if i == 0 else "qualified-timed")
            or phase["max_logical_calls"] != 32
            or len(phase["workload"]) != 16
            or len({item["id"] for item in phase["workload"]}) != 16
        ):
            raise ValueError("fixed phase/workload census changed")
        if any(
            item["max_logical_calls"] != 2 or item["warmup_logical_calls"] != (1 if i == 0 else 0)
            for item in phase["workload"]
        ):
            raise ValueError("unallocated calls or warmup")
    for left, right in zip(
        campaign["phases"][0]["workload"], campaign["phases"][1]["workload"], strict=True
    ):
        if any(
            left[key] != right[key]
            for key in ("id", "configuration", "prefix", "max_logical_calls")
        ):
            raise ValueError("timed inputs differ from fixed same cases")
    if (
        plan["campaign"] != admission["campaign"]
        or plan["native"] != campaign["native"]
        or plan["configurations"] != expected
        or plan["mode"] != "untimed"
        or plan["workload"] != campaign["phases"][0]["workload"]
        or plan["max_logical_calls"] != 32
        or plan["prior_logical_calls"] != 0
        or plan["prior_results"] != []
        or plan["output"] != admission["native_outputs"]["untimed"]
    ):
        raise ValueError("untimed plan differs from prebound campaign")
    for value in (admission["output"], admission["TMP"], *admission["native_outputs"].values()):
        path = Path(value)
        if (
            not path.is_absolute()
            or not path.is_relative_to(ROOT)
            or path.parent.resolve(strict=True) != path.parent
            or path.exists()
            or path.is_symlink()
        ):
            raise ValueError("new exclusive owned namespace required")


def census(attempts, receipts, expected):
    return (
        len(attempts) == len(receipts) == 2
        and [item["name"] for item in attempts] == ["untimed", "qualified-timed"]
        and [item["command"] for item in attempts] == expected
        and all(row["verified"] and row["receipt"]["exit_code"] == 0 for row in receipts)
    )


def main():
    raw = Path(sys.argv[1]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != sys.argv[2]:
        raise ValueError("immutable actual admission SHA")
    admission = json.loads(raw)
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared live control is not entry")
    # Verify all helpers before importing even their source-only module bodies.
    quiet()
    physical()
    lock = LOCK.open("r+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet()
        validate(admission)
        materializer = import_bound(admission["helpers"]["materializer"], "live_materializer")
        sys.path.insert(0, "/workspaces/quoridor/python")
        from quoridor_training import cycle_process as P
        from quoridor_training.snapshot import write_json

        output, temporary = Path(admission["output"]), Path(admission["TMP"])
        os.environ.update(admission["environment"])
        P.LOG_MAX_BYTES = 8 * 1024**2
    except BaseException as primary:
        try:
            lock.close()
        except BaseException as cleanup:
            raise BaseExceptionGroup("entry and lease-close refusal", [primary, cleanup]) from None
        raise
    attempts, errors, expected_commands = [], [], []
    result = {
        "qualified": False,
        "purpose": admission["purpose"],
        "native_result_refs": [],
        "returned_process_finalization": {},
        "games_launched": 0,
        "continuous_peak": "UNKNOWN",
        "old_fees_raw_masks_assets_UNKNOWN": "HELD",
    }
    resources = None
    primary = None

    class Resources(P.CycleResources):
        def __init__(self):
            super().__init__(
                {
                    "host_ram_reserve": 4 * 1024**3,
                    "max_memory_bytes": 2 * 1024**3,
                    "max_output_bytes": 64 * 1024**2,
                },
                output,
                None,
            )
            prior = json.loads(Path(admission["prior_charges"]["path"]).read_bytes())
            self.maxima = {
                (row["component"], row["path"]): row["maximum_sampled_allocated_B"] for row in prior
            }
            if len(prior) != len(self.maxima):
                raise ValueError("duplicate held charge")
            self.family_peak = 0

        def check(self, owned=()):
            super().check(owned)
            infos = [P.process_info(os.getpid()), *(P.process_info(item["pid"]) for item in owned)]
            self.family_peak = max(
                self.family_peak, sum(item["rss"] for item in infos if item) + 64 * 1024**2
            )
            if self.family_peak > self.memory_limit:
                raise P.CycleStopped("family RAM including controller reserve")
            for kind, root, cap in [
                ("live", output, 64 * 1024**2),
                *[
                    ("live", Path(path), 64 * 1024**2)
                    for path in admission["native_outputs"].values()
                ],
                ("TMP", temporary, 512 * 1024**2),
            ]:
                pending = [root]
                while pending:
                    path = pending.pop()
                    try:
                        info = path.lstat()
                    except FileNotFoundError:
                        continue  # Only this newly owned output/TMP; old charges stay held.
                    if stat.S_ISLNK(info.st_mode):
                        raise P.CycleStopped("owned output symlink")
                    self.maxima[kind, str(path)] = max(
                        self.maxima.get((kind, str(path)), 0), info.st_blocks * 512
                    )
                    if stat.S_ISDIR(info.st_mode):
                        pending.extend(path.iterdir())
                    elif not stat.S_ISREG(info.st_mode):
                        raise P.CycleStopped("unsupported owned output type")
                if (
                    sum(value for (component, _), value in self.maxima.items() if component == kind)
                    > cap
                ):
                    raise P.CycleStopped("held component allocation exceeds " + kind)

    def attempt(stage, action):
        try:
            return action()
        except BaseException as error:
            errors.append({"stage": stage, "type": type(error).__name__, "message": str(error)})
            return None

    def execute(name, command):
        quiet()
        sources(admission)
        log = output / (name + ".log")
        receipt = log.with_suffix(".process.json")
        attempts.append({"name": name, "command": command, "receipt": str(receipt)})
        record = P.execute(command, log, None, cpu_core=0, resources=resources)
        result["returned_process_finalization"][name] = {
            key: record.get(key, "UNKNOWN")
            for key in (
                "signal_mask_restoration",
                "final_record_persist",
                "handle_closes_complete",
                "process_cleanup_complete",
            )
        }
        if (
            record["command"] != command
            or record["exit_code"] != 0
            or record["direct_child_reaped"] is not True
            or record["cleanup_complete"] is not True
            or record["remaining"]
            or record["log_bytes_seen"] != record["log_bytes_retained"]
        ):
            raise ValueError("native command/wait/cleanup/log refusal: " + name)
        sources(admission)
        result_path = Path(admission["native_outputs"][name]) / "measurement-result.json"
        if (
            not result_path.is_file()
            or result_path.is_symlink()
            or result_path.stat().st_size > 1024 * 1024
        ):
            raise ValueError("native result missing/oversize/nonregular")
        ref = descriptor(result_path)
        result["native_result_refs"].append(ref)
        return ref

    def evidence(plans, replies, validation=None):
        return materializer.evidence(
            SimpleNamespace(
                campaign=[admission["campaign"]["path"], admission["campaign"]["sha256"]],
                result=[[ref["path"], ref["sha256"]] for ref in replies],
                plan=[[ref["path"], ref["sha256"]] for ref in plans],
                receipt=[[item["receipt"], sha(item["receipt"])] for item in attempts],
                private=admission["private"]["path"],
                validation_packet=None
                if validation is None
                else [validation["path"], validation["sha256"]],
                output=str(
                    output
                    / ("validation-evidence.json" if validation is None else "arena-evidence.json")
                ),
                packet_output=str(
                    output
                    / ("validation-packet.json" if validation is None else "arena-candidate.json")
                ),
            )
        )

    try:
        quiet()
        result["physical_admission"] = physical()
        sources(admission)
        os.sched_setaffinity(0, {2})
        os.chdir(WT)
        output.mkdir()
        temporary.mkdir()
        os.environ["TMPDIR"] = str(temporary)
        resources = Resources()
        resources.check()
        result["actual_START"] = datetime.now(timezone.utc).isoformat()
        plan = admission["untimed_plan"]
        command = [
            admission["private"]["path"],
            "sigma-cost-measure",
            "--plan",
            plan["path"],
            "--plan-sha256",
            plan["sha256"],
        ]
        expected_commands.append(command)
        first = execute("untimed", command)
        validation = evidence([plan], [first])
        timed = materializer.timed_plan(
            SimpleNamespace(
                campaign=[admission["campaign"]["path"], admission["campaign"]["sha256"]],
                prior=[first["path"], first["sha256"]],
                output=str(output / "timed-plan.json"),
                native_output=admission["native_outputs"]["qualified-timed"],
            )
        )
        # Generated controls bind the exact prior result before the second Popen.
        verify(
            validation["path"],
            {
                "SHA256": validation["sha256"],
                "mode": stat.S_IMODE(Path(validation["path"]).stat().st_mode),
                "bytes": Path(validation["path"]).stat().st_size,
            },
        )
        command = [
            admission["private"]["path"],
            "sigma-cost-measure",
            "--plan",
            timed["path"],
            "--plan-sha256",
            timed["sha256"],
            "--sigma-cost-qualification",
            validation["path"],
            "--qualification-sha256",
            validation["sha256"],
        ]
        expected_commands.append(command)
        second = execute("qualified-timed", command)
        result["arena_qualification_candidate"] = evidence(
            [plan, timed], [first, second], validation
        )
        result["arena_admission"] = (
            "PENDING successful authoritative controller completion and guardian finalization; candidate never admits"
        )
        result["fixed_call_census"] = {"warmup": 16, "measurement": 16, "timed": 32, "total": 64}
    except BaseException as error:
        primary = error
    finally:
        attempt("source_after", lambda: sources(admission))
        if resources is not None:
            attempt("final_resources", resources.check)
        receipts, remaining, unknown = [], [], False
        for entry in attempts:
            receipt = attempt(
                "receipt:" + entry["name"],
                lambda entry=entry: json.loads(Path(entry["receipt"]).read_bytes()),
            )
            verified = bool(
                receipt
                and receipt.get("command") == entry["command"]
                and receipt.get("direct_child_reaped") is True
                and receipt.get("cleanup_complete") is True
                and receipt.get("remaining") == []
            )
            unknown |= not verified
            receipts.append({"attempt": entry, "receipt": receipt, "verified": verified})
            if receipt:
                remaining.extend(receipt.get("remaining", []))
        result.update(
            primary_error=None
            if primary is None
            else {"type": type(primary).__name__, "message": str(primary)},
            receipts=receipts,
            attempted_children=attempts,
            cleanup_unknown=unknown,
            remaining=remaining,
            cleanup_complete=not unknown and not remaining,
            source_STOP=datetime.now(timezone.utc).isoformat(),
            stage_failures=errors,
            family_RSS_sample_peak_B=None if resources is None else resources.family_peak,
        )
        if resources is not None:
            attempt(
                "held_charges",
                lambda: write_json(
                    output / "held-charges.json",
                    [
                        {"component": kind, "path": path, "maximum_sampled_allocated_B": value}
                        for (kind, path), value in sorted(resources.maxima.items())
                    ],
                ),
            )
        if not unknown and not remaining and temporary.exists():
            attempt("owned_empty_TMP", temporary.rmdir)
        attempt("lock_close", lock.close)
        result["qualified"] = (
            primary is None
            and not errors
            and not unknown
            and census(attempts, receipts, expected_commands)
        )
        attempt("result", lambda: write_json(output / "live-result.json", result))
        if errors:
            result["qualified"] = False
            print(json.dumps({"terminal_failure_facts": result}), flush=True)
        if primary is not None:
            raise primary
        if errors or unknown or not result["qualified"]:
            raise RuntimeError(
                "live qualification incomplete; games refused: " + json.dumps(result)
            )


if __name__ == "__main__":
    main()
