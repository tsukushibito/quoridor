"""Materialize the frozen live campaign and native-result evidence; never launch work."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import stat

ROOT = Path(__file__).resolve().parents[1]
U64_MAX = 2**64 - 1


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def bound(path, expected):
    path = Path(path)
    if not path.is_absolute() or path.resolve(strict=True) != path:
        raise ValueError("canonical absolute control required")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError("regular control required")
        raw = stream.read(1024 * 1024 + 1)
    if len(raw) > 1024 * 1024 or digest(raw) != expected:
        raise ValueError("bound control size/SHA changed")
    return json.loads(raw)


def descriptor(path):
    path = Path(path)
    if not path.is_absolute() or path.resolve(strict=True) != path:
        raise ValueError("canonical descriptor required")
    return {"path": str(path), "sha256": digest(path.read_bytes())}


def publish(path, value):
    path = Path(path)
    if path.parent.resolve(strict=True) != path.parent or not path.is_relative_to(ROOT):
        raise ValueError("existing owned canonical output parent required")
    raw = (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()
    if len(raw) > 1024 * 1024:
        raise ValueError("control output exceeds native bound-reader limit")
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return descriptor(path)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def positive(value):
    require(type(value) is int and 0 < value <= U64_MAX, "positive u64 cost required")
    return value


def native_output(path):
    path = Path(path)
    require(
        path.is_absolute()
        and path.is_relative_to(ROOT)
        and path.parent.resolve(strict=True) == path.parent
        and not path.exists()
        and not path.is_symlink(),
        "new owned canonical native output required",
    )
    return str(path)


def campaign(args):
    template = bound(*args.template)
    expected = bound(*args.backend)
    records = [bound(*pair) for pair in (args.d_bindings, args.nnue_bindings)]
    require(
        template["prepared_only"] is True and template["actual_entry"] is False,
        "only the frozen prepared campaign may be materialized",
    )
    for planned, record in zip(template["configurations"], records, strict=True):
        require(
            record["schema"] == "quoridor-sigma-cost-bindings-v1"
            and record["backend_loaded"] is False
            and record["model_calls"] == 0
            and record["cost_qualification"] is None
            and record["config_file"] == planned["file"],
            "actual binding route/config mismatch",
        )
        bound(planned["file"]["path"], planned["file"]["sha256"])
        planned["normalized_sha256"] = record["normalized_config_sha256"]
    for key in ("compiled_sources", "compiled_sources_sha256", "executable_sha256"):
        require(
            records[0][key] == records[1][key],
            "one identical private/source body required",
        )
    native = template["native"]
    native["compiled_sources_sha256"] = records[0]["compiled_sources_sha256"]
    native["executable_sha256"] = records[0]["executable_sha256"]
    native["backend_sha256"] = expected["expected_descriptor_digest_SHA256"]
    for key in ("prepared_only", "actual_entry", "missing_before_materialization"):
        template.pop(key)
    campaign_ref = publish(args.output, template)
    phase = template["phases"][0]
    return publish(
        args.plan_output,
        {
            "schema": "quoridor-sigma-receipt-measurement-v1",
            "phase_id": phase["id"],
            "campaign": campaign_ref,
            "configurations": template["configurations"],
            "native": native,
            "output": native_output(args.native_output),
            "mode": phase["mode"],
            "max_logical_calls": phase["max_logical_calls"],
            "prior_logical_calls": 0,
            "prior_results": [],
            "workload": phase["workload"],
        },
    )


def timed_plan(args):
    frozen = bound(*args.campaign)
    prior = bound(*args.prior)
    phase = frozen["phases"][1]
    require(
        prior["complete"] is True
        and prior["all_workers_joined"] is True
        and prior["stopped"] is None
        and prior["inflight_after_drain"] == 0
        and prior["logical_calls_attempted"] == 32
        and prior["native"] == frozen["native"]
        and prior["campaign_sha256"] == args.campaign[1]
        and prior["phase_id"] == frozen["phases"][0]["id"],
        "failed/incomplete/off-campaign prior cannot materialize timed continuation",
    )
    return publish(
        args.output,
        {
            "schema": "quoridor-sigma-receipt-measurement-v1",
            "phase_id": phase["id"],
            "campaign": {"path": args.campaign[0], "sha256": args.campaign[1]},
            "configurations": frozen["configurations"],
            "native": frozen["native"],
            "output": native_output(args.native_output),
            "mode": phase["mode"],
            "max_logical_calls": phase["max_logical_calls"],
            "prior_logical_calls": 32,
            "prior_results": [{"path": args.prior[0], "sha256": args.prior[1]}],
            "workload": phase["workload"],
        },
    )


def evidence(args):
    frozen = bound(*args.campaign)
    results = [bound(*pair) for pair in args.result]
    require(len(results) in (1, 2), "one untimed result or untimed plus timed only")
    require(
        len(args.plan) == len(args.receipt) == len(results),
        "one actual plan and direct process receipt per native phase required",
    )
    require(
        (len(results) == 2) == (args.validation_packet is not None),
        "timed phase requires its exact validation-packet descriptor",
    )
    totals = [0, 0, 0]
    peak_operation = peak_decision = 0
    for index, record in enumerate(results):
        phase = frozen["phases"][index]
        plan = bound(*args.plan[index])
        process = bound(*args.receipt[index])
        command = [
            args.private,
            "sigma-cost-measure",
            "--plan",
            args.plan[index][0],
            "--plan-sha256",
            args.plan[index][1],
        ]
        if index == 1:
            command.extend(
                [
                    "--sigma-cost-qualification",
                    args.validation_packet[0],
                    "--qualification-sha256",
                    args.validation_packet[1],
                ]
            )
        require(
            process["command"] == command
            and process["exit_code"] == 0
            and process["direct_child_reaped"] is True
            and process["cleanup_complete"] is True
            and process["remaining"] == [],
            "native phase lacks matching successful direct wait/cleanup receipt",
        )
        require(
            record["plan_sha256"] == args.plan[index][1]
            and plan["campaign"] == {"path": args.campaign[0], "sha256": args.campaign[1]}
            and plan["native"] == frozen["native"]
            and plan["workload"] == phase["workload"]
            and plan["mode"] == phase["mode"]
            and plan["phase_id"] == phase["id"]
            and plan["configurations"] == frozen["configurations"]
            and Path(args.result[index][0]) == Path(plan["output"]) / "measurement-result.json",
            "native result path/plan/campaign/source differs from actual attempted phase",
        )
        require(
            record["schema"] == "quoridor-sigma-receipt-measurement-result-v1"
            and record["complete"] is True
            and record["all_workers_joined"] is True
            and record["inflight_after_drain"] == 0
            and record["stopped"] is None
            and record["native"] == frozen["native"]
            and record["campaign_sha256"] == args.campaign[1]
            and record["phase_id"] == phase["id"]
            and record["mode"] == phase["mode"]
            and record["configuration_sha256"]
            == [c["normalized_sha256"] for c in frozen["configurations"]],
            "failed/incomplete/off-campaign native result; games refused",
        )
        require(
            record["logical_calls_attempted"] == record["returned_terminal_replies"] == 32
            and record["prior_logical_calls"] == index * 32
            and record["allocated_logical_calls"] == 32
            and record["backend_work"]["logical_rows"] == 32
            and record["backend_work"]["physical_rows"] == 32
            and record["backend_work"]["failed_rows"] == 0
            and len(record["items"]) == len(phase["workload"]) == 16,
            "native phase call/work census mismatch",
        )
        for expected, item in zip(phase["workload"], record["items"], strict=True):
            require(
                all(
                    item[k] == expected[k]
                    for k in ("id", "configuration", "stage", "warmup_logical_calls")
                )
                and item["parent"]["prefix"] == expected["prefix"]
                and item["config_sha256"]
                == frozen["configurations"][expected["configuration"]]["normalized_sha256"]
                and item["error"] is None,
                "native item identity/error mismatch",
            )
            receipt = item["receipt"]
            counters = receipt["counters"]
            require(
                receipt["accepted"] is True
                and receipt["failure"] is None
                and type(receipt["action"]) is int
                and counters["nn_requests_attempted"]
                == counters["inference_callback_results"]
                == counters["nn_valid_replies_returned"]
                == 2
                and counters["terminal_request_error"] is None
                and counters["inflight_after_drain"] == 0
                and counters["authority_legal"] is True,
                "unfinished or invalid authority receipt",
            )
            operations = counters["measurement_operations_ns"]
            require(bool(operations), "complete-operation samples missing")
            operation = max(positive(value) for value in operations)
            decision = positive(counters["decision_and_receipt_cost_ns"])
            if index == 0:
                peak_operation = max(peak_operation, operation)
                peak_decision = max(peak_decision, decision)
                totals[0] += item["warmup_logical_calls"]
                totals[1] += 2 - item["warmup_logical_calls"]
            else:
                require(
                    operation <= 4 * peak_operation + 2000000
                    and decision <= 4 * peak_decision + 2000000
                    and counters["measurement_mode"] == "qualified-timed"
                    and counters["cost_qualification_usable_after_drain"] is True,
                    "timed validation disproved bound; games refused",
                )
                totals[2] += 2
    operation_bound = positive(4 * peak_operation + 2000000)
    decision_bound = positive(4 * peak_decision + 2000000)
    require(
        totals == [16, 16, 32 if len(results) == 2 else 0],
        "fixed aggregate64 census mismatch",
    )
    result_refs = [{"path": pair[0], "sha256": pair[1]} for pair in args.result]
    evidence_ref = publish(
        args.output,
        {
            "schema": "quoridor-sigma-cost-evidence-v1",
            "complete": True,
            "configuration_sha256": [c["normalized_sha256"] for c in frozen["configurations"]],
            "native": frozen["native"],
            "whole_operation_upper_ns": operation_bound,
            "decision_communication_upper_ns": decision_bound,
            "warmup_logical_calls": totals[0],
            "measurement_logical_calls": totals[1],
            "timed_logical_calls": totals[2],
            "attempted_logical_calls": sum(totals),
            "returned_terminal_replies": sum(totals),
            "errors": 0,
            "inflight_after_drain": 0,
            "workload": {"path": args.campaign[0], "sha256": args.campaign[1]},
            "results": result_refs,
        },
    )
    packet = {
        "schema": "quoridor-sigma-cost-qualification-v1",
        "scope": "timed-arena" if len(results) == 2 else "timed-validation",
        "configurations": frozen["configurations"],
        "native": frozen["native"],
        "evidence": evidence_ref,
        "whole_operation_upper_ns": operation_bound,
        "decision_communication_upper_ns": decision_bound,
    }
    # Full native observations remain honest; the guardian's finalizers have
    # not yet run. Only the saved completed-guardian route can expose this as
    # a native timed-arena packet.
    if len(results) == 2:
        packet = non_admitting_candidate(packet, args.campaign, result_refs)
    return publish(args.packet_output, packet)


def non_admitting_candidate(packet, campaign, results):
    return {
        "schema": "quoridor-sigma-cost-nonadmitting-candidate-v1",
        "admitting": False,
        "packet": packet,
        "campaign": {"path": campaign[0], "sha256": campaign[1]},
        "results": results,
    }


def admit_completed_guardian(args):
    admission = bound(*args.admission)
    config = bound(*args.job_config)
    state = bound(*args.job_state)
    controller = bound(*args.job_result)
    guardian = bound(*args.guardian_result)
    candidate = bound(*args.candidate)
    runtime = Path(args.job_result[0]).parent
    require(
        Path(args.job_config[0]) == runtime / "config.json"
        and Path(args.job_state[0]) == runtime / "state.json"
        and Path(args.job_result[0]) == runtime / "result.json",
        "authoritative state/result/config must belong to one runtime",
    )
    require(
        admission["actual_entry"] is True
        and admission["prepared_only"] is False
        and admission["pending_obligations"] == []
        and config["issue"] == "quoridor-4lc.347.2"
        and config["goal_issue"] == "quoridor-4lc.347"
        and config["thread_id"] == "01a11062-b120-73a1-8aa3-fe2cb922c7c0"
        and config["cwd"] == str(ROOT.parents[1])
        and config["resource_contract"] == args.admission[0]
        and config["argv"]
        == [
            "/usr/bin/python3.11",
            "-B",
            str(Path(__file__).with_name("live_worker.py")),
            args.admission[0],
            args.admission[1],
        ]
        and state["config_sha256"]
        == hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
        and state["job_id"] == controller["job_id"]
        and state["phase"] == "finished"
        and state["outcome"] == controller["outcome"] == "succeeded"
        and controller["error"] is None
        and type(controller["exit_code"]) is int
        and controller["exit_code"] == 0
        and controller["direct_child_reaped"] is True
        and controller["cleanup_complete"] is True
        and controller["remaining"] == controller["cleanup_errors"] == []
        and controller["descendant_visibility"] == "observed"
        and controller["log_bytes_seen"] == controller["log_bytes_retained"]
        and controller["finished_at"],
        "failed/unfinished/UNKNOWN/wrong-identity guardian controller cannot admit",
    )
    require(
        Path(args.guardian_result[0]) == Path(admission["output"]) / "live-result.json"
        and Path(args.candidate[0]) == Path(admission["output"]) / "arena-candidate.json"
        and guardian["arena_qualification_candidate"]
        == {
            "path": args.candidate[0],
            "sha256": args.candidate[1],
        }
        and guardian["qualified"] is True
        and guardian["purpose"] == "sigma-receipt-live64"
        and guardian["primary_error"] is None
        and guardian["stage_failures"] == []
        and guardian["cleanup_unknown"] is False
        and guardian["cleanup_complete"] is True
        and guardian["remaining"] == []
        and guardian["games_launched"] == 0
        and guardian["source_STOP"]
        and guardian["fixed_call_census"]
        == {
            "warmup": 16,
            "measurement": 16,
            "timed": 32,
            "total": 64,
        }
        and candidate["schema"] == "quoridor-sigma-cost-nonadmitting-candidate-v1"
        and candidate["admitting"] is False
        and candidate["campaign"] == admission["campaign"]
        and candidate["results"] == guardian["native_result_refs"],
        "failed/partial/mismatched guardian candidate cannot admit",
    )
    receipts = guardian["receipts"]
    require(
        len(receipts) == len(guardian["attempted_children"]) == 2
        and [row["name"] for row in guardian["attempted_children"]]
        == ["untimed", "qualified-timed"]
        and all(
            row["verified"] is True
            and row["attempt"] == attempt
            and row["receipt"]["command"] == attempt["command"]
            and type(row["receipt"]["exit_code"]) is int
            and row["receipt"]["exit_code"] == 0
            and row["receipt"]["direct_child_reaped"] is True
            and row["receipt"]["cleanup_complete"] is True
            and row["receipt"]["remaining"] == []
            for row, attempt in zip(receipts, guardian["attempted_children"], strict=True)
        ),
        "two exact successful native direct receipts required",
    )
    packet = candidate["packet"]
    require(
        packet["schema"] == "quoridor-sigma-cost-qualification-v1"
        and packet["scope"] == "timed-arena",
        "only completed timed-arena candidate can admit",
    )
    # This existing publication operation is reached only after the immutable
    # successful external controller STOP. No backend/native work is replayed.
    return publish(args.output, packet)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    routes = parser.add_subparsers(dest="command", required=True)
    prepare = routes.add_parser("campaign")
    for flag in ("template", "backend", "d-bindings", "nnue-bindings"):
        prepare.add_argument("--" + flag, nargs=2, required=True, metavar=("PATH", "SHA"))
    for flag in ("output", "plan-output", "native-output"):
        prepare.add_argument("--" + flag, required=True)
    timed = routes.add_parser("timed-plan")
    for flag in ("campaign", "prior"):
        timed.add_argument("--" + flag, nargs=2, required=True, metavar=("PATH", "SHA"))
    timed.add_argument("--output", required=True)
    timed.add_argument("--native-output", required=True)
    collect = routes.add_parser("evidence")
    collect.add_argument("--campaign", nargs=2, required=True, metavar=("PATH", "SHA"))
    collect.add_argument(
        "--result", nargs=2, action="append", required=True, metavar=("PATH", "SHA")
    )
    for flag in ("plan", "receipt"):
        collect.add_argument(
            "--" + flag,
            nargs=2,
            action="append",
            required=True,
            metavar=("PATH", "SHA"),
        )
    collect.add_argument("--private", required=True)
    collect.add_argument("--validation-packet", nargs=2, metavar=("PATH", "SHA"))
    collect.add_argument("--output", required=True)
    collect.add_argument("--packet-output", required=True)
    admit = routes.add_parser("admit-completed-guardian")
    for flag in (
        "admission",
        "job-config",
        "job-state",
        "job-result",
        "guardian-result",
        "candidate",
    ):
        admit.add_argument("--" + flag, nargs=2, required=True, metavar=("PATH", "SHA"))
    admit.add_argument("--output", required=True)
    args = parser.parse_args()
    handler = {
        "campaign": campaign,
        "timed-plan": timed_plan,
        "evidence": evidence,
        "admit-completed-guardian": admit_completed_guardian,
    }[args.command]
    print(json.dumps(handler(args)))


if __name__ == "__main__":
    main()
