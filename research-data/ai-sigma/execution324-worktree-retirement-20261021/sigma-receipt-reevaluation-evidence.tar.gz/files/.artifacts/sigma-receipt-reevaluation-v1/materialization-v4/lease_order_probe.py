"""Actual pre-import main AST against fake ports; no real child or payload."""

import ast
from builtins import BaseExceptionGroup
import copy
import hashlib
import json
import os
from pathlib import Path
import resource
import time
from types import SimpleNamespace


def main():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    os.sched_setaffinity(0, {3})
    started = time.monotonic()
    path = Path(__file__).resolve().parents[1] / "materialization-v2/software_worker.py"
    raw = path.read_bytes()
    tree = ast.parse(raw)
    function = copy.deepcopy(
        next(
            n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "main"
        )
    )
    index = next(
        i
        for i, n in enumerate(function.body)
        if isinstance(n, ast.ImportFrom) and n.module == "quoridor_training"
    )
    function.body = function.body[:index]
    code = compile(ast.Module(body=[function], type_ignores=[]), str(path), "exec")
    passed = []
    for case in [
        "success",
        "preparedfalse",
        "quiet_refusal",
        "physical_refusal",
        "lock_refusal",
        "source_refusal",
        "target_refusal",
        "source_and_close_refusal",
    ]:
        trace = []
        primary = ValueError("original primary")
        cleanup = OSError("individual lease-close failure")
        admission = {
            "actual_entry": case != "preparedfalse",
            "prepared_only": case == "preparedfalse",
        }
        body = json.dumps(admission).encode()

        class FakePath:
            def __init__(self, value):
                assert value == "/admission"

            def read_bytes(self):
                trace.append("admission")
                return body

        class Lease:
            held = False

            def close(self):
                trace.append("close")
                self.held = False
                if case == "source_and_close_refusal":
                    raise cleanup

        lease = Lease()

        def open_lock(mode):
            assert mode == "r+"
            trace.append("open")
            return lease

        def flock(value, flags):
            assert value is lease and flags == 6
            trace.append("flock")
            if case == "lock_refusal":
                raise primary
            lease.held = True

        def quiet():
            trace.append("quiet")
            if case == "quiet_refusal":
                raise primary

        def physical():
            trace.append("physical")
            if case == "physical_refusal":
                raise primary

        def verify(ad):
            assert ad == admission and lease.held
            trace.append("verify_under_lease")
            if case in {"source_refusal", "source_and_close_refusal"}:
                raise primary

        def target(ad):
            assert ad == admission and lease.held
            trace.append("full_target_under_lease")
            if case == "target_refusal":
                raise primary

        ports = {
            "Path": FakePath,
            "sys": SimpleNamespace(
                argv=["worker", "/admission", hashlib.sha256(body).hexdigest()], path=[]
            ),
            "hashlib": hashlib,
            "json": json,
            "LOCK": SimpleNamespace(open=open_lock),
            "fcntl": SimpleNamespace(LOCK_EX=2, LOCK_NB=4, flock=flock),
            "quiet": quiet,
            "physical": physical,
            "validate": verify,
            "validate_target_lease": target,
        }
        exec(code, ports)
        error = None
        try:
            ports["main"]()
        except BaseException as value:
            error = value
        if case == "success":
            assert error is None and lease.held
            assert trace == [
                "admission",
                "quiet",
                "physical",
                "open",
                "flock",
                "quiet",
                "verify_under_lease",
                "full_target_under_lease",
            ]
            lease.close()  # Fake fixture cleanup; real main keeps it through command finalization.
        elif case == "preparedfalse":
            assert (
                isinstance(error, ValueError)
                and str(error) == "prepared software is not an actual entry"
            )
            assert trace == ["admission"]
        elif case in {"quiet_refusal", "physical_refusal"}:
            assert error is primary and "open" not in trace
        elif case == "source_and_close_refusal":
            assert isinstance(error, BaseExceptionGroup) and error.exceptions == (
                primary,
                cleanup,
            )
            assert trace[-1] == "close" and not lease.held
        else:
            assert error is primary and trace[-1] == "close" and not lease.held
        passed.append(case)
    hwm = next(
        int(s.split()[1])
        for s in Path("/proc/self/status").read_text().splitlines()
        if s.startswith("VmHWM:")
    )
    print(
        json.dumps(
            {
                "PASS": passed,
                "source_SHA256": hashlib.sha256(raw).hexdigest(),
                "internal_wall_seconds": time.monotonic() - started,
                "VmHWM_KiB": hwm,
                "CPU": 3,
                "AS_B": 512 * 1024**2,
                "real_lock_payload_import_Popen_model_game": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
