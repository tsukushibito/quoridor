"""Actual guardian AST with in-memory process/IO ports; no production import."""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import sys
import time
from types import ModuleType, SimpleNamespace

SOURCE = Path(__file__).with_name("live_worker.py")
TREE = ast.parse(SOURCE.read_text())
FUNCTIONS = {node.name: node for node in TREE.body if isinstance(node, ast.FunctionDef)}


def compile_function(name, ports):
    exec(compile(ast.Module(body=[FUNCTIONS[name]], type_ignores=[]), str(SOURCE), "exec"), ports)
    return ports[name]


checks = []
for flags in [(False, True), (True, True), (False, False)]:
    called = []
    ports = {"sources": lambda _: called.append("IO")}
    function = compile_function("validate", ports)
    try:
        function({"actual_entry": flags[0], "prepared_only": flags[1]})
        raise AssertionError("prepared admission accepted")
    except ValueError as error:
        assert str(error) == "prepared live control is not entry" and not called
    checks.append("prepared gate before all input IO " + str(flags))


def run_case(mode):
    memory, commands = {}, []

    class FakePath:
        def __init__(self, value):
            self.value = str(value)

        def __str__(self):
            return self.value

        def __truediv__(self, name):
            return FakePath(self.value + "/" + name)

        def with_suffix(self, suffix):
            return FakePath(self.value.rsplit(".", 1)[0] + suffix)

        def read_bytes(self):
            return memory[self.value]

        def read_text(self):
            return self.read_bytes().decode()

        def open(self, _):
            return SimpleNamespace(close=lambda: None, fileno=lambda: 7)

        def mkdir(self):
            memory[self.value] = None

        def exists(self):
            return self.value in memory

        def is_file(self):
            return self.exists() and memory[self.value] is not None

        def is_symlink(self):
            return False

        def stat(self):
            return self.lstat()

        def lstat(self):
            if not self.exists():
                raise FileNotFoundError(self.value)
            value = memory[self.value]
            return SimpleNamespace(
                st_mode=stat.S_IFDIR if value is None else stat.S_IFREG | 0o644,
                st_blocks=0,
                st_size=0 if value is None else len(value),
            )

        def iterdir(self):
            return [
                FakePath(name)
                for name in list(memory)
                if name.startswith(self.value + "/") and "/" not in name[len(self.value) + 1 :]
            ]

        def rmdir(self):
            assert not self.iterdir()
            del memory[self.value]

    def write_json(path, value):
        memory[str(path)] = json.dumps(value).encode()

    ad = {
        "actual_entry": True,
        "prepared_only": False,
        "helpers": {"materializer": "materializer"},
        "output": "out",
        "TMP": "tmp",
        "environment": {},
        "purpose": "sigma-receipt-live64",
        "private": {"path": "private"},
        "campaign": {"path": "campaign", "sha256": "c" * 64},
        "untimed_plan": {"path": "plan", "sha256": "p" * 64},
        "prior_charges": {"path": "charges"},
        "native_outputs": {"untimed": "first", "qualified-timed": "second"},
    }
    write_json("admission", ad)
    write_json("charges", [])

    class CycleResources:
        def __init__(self, *args):
            self.memory_limit = 2 * 1024**3

        def check(self, owned=()):
            if mode == "resource-failure-after-native" and commands:
                raise RuntimeError("independent final resource failure")

    def execute(command, log, deadline, **kwargs):
        commands.append(command)
        name = "untimed" if len(commands) == 1 else "qualified-timed"
        receipt = {
            "command": command,
            "exit_code": 1 if mode == "first-command-failed" and len(commands) == 1 else 0,
            "direct_child_reaped": True,
            "cleanup_complete": mode != "cleanup-unknown",
            "remaining": [],
            "log_bytes_seen": 2,
            "log_bytes_retained": 2,
            "signal_mask_restoration": "completed",
            "final_record_persist": "completed",
            "handle_closes_complete": True,
            "process_cleanup_complete": True,
        }
        write_json(log.with_suffix(".process.json"), receipt)
        memory[str(log)] = b"{}"
        write_json(
            FakePath(ad["native_outputs"][name]) / "measurement-result.json",
            {"actual_native_fixture": False},
        )
        return receipt

    process = ModuleType("quoridor_training.cycle_process")
    process.CycleResources = CycleResources
    process.process_info = lambda _: {"rss": 1}
    process.execute = execute
    process.CycleStopped = RuntimeError
    package = ModuleType("quoridor_training")
    package.cycle_process = process
    snapshot = ModuleType("quoridor_training.snapshot")
    snapshot.write_json = write_json
    sys.modules["quoridor_training"] = package
    sys.modules["quoridor_training.cycle_process"] = process
    sys.modules["quoridor_training.snapshot"] = snapshot

    def evidence(args):
        if mode in ("evidence-refused", "resource-failure-after-native"):
            raise ValueError("native evidence refused")
        write_json(args.packet_output, {"fixture": True})
        return {"path": args.packet_output, "sha256": "v" * 64}

    materializer = SimpleNamespace(
        evidence=evidence, timed_plan=lambda args: {"path": args.output, "sha256": "t" * 64}
    )
    ports = {
        "Path": FakePath,
        "ROOT": FakePath("root"),
        "WT": FakePath("wt"),
        "LOCK": FakePath("lock"),
        "json": json,
        "hashlib": hashlib,
        "sys": SimpleNamespace(
            argv=["worker", "admission", hashlib.sha256(memory["admission"]).hexdigest()],
            path=SimpleNamespace(insert=lambda *args: None),
        ),
        "os": SimpleNamespace(
            environ={}, sched_setaffinity=lambda *args: None, getpid=lambda: 1, chdir=lambda _: None
        ),
        "stat": stat,
        "datetime": datetime,
        "timezone": timezone,
        "SimpleNamespace": SimpleNamespace,
        "BaseExceptionGroup": BaseExceptionGroup,
        "fcntl": SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *args: None),
        "time": time,
        "quiet": lambda: None,
        "physical": lambda: {},
        "validate": lambda _: None,
        "sources": lambda _: None,
        "verify": lambda *args: None,
        "import_bound": lambda *args: materializer,
        "sha": lambda _: "r" * 64,
        "descriptor": lambda path: {"path": str(path), "sha256": "r" * 64},
    }
    compile_function("census", ports)
    error = None
    try:
        compile_function("main", ports)()
    except Exception as caught:
        error = caught
    result = json.loads(memory["out/live-result.json"])
    if mode == "matching-two":
        assert (
            error is None
            and result["qualified"] is True
            and len(commands) == 2
            and result["fixed_call_census"]["total"] == 64
        )
    else:
        assert error is not None and result["qualified"] is False and len(commands) == 1
        if mode == "resource-failure-after-native":
            assert isinstance(error, ValueError) and str(error) == "native evidence refused"
            assert any(row["stage"] == "final_resources" for row in result["stage_failures"])
        if mode == "cleanup-unknown":
            assert result["cleanup_unknown"] is True
    assert result["games_launched"] == 0
    return mode


for mode in (
    "matching-two",
    "first-command-failed",
    "evidence-refused",
    "cleanup-unknown",
    "resource-failure-after-native",
):
    checks.append(run_case(mode))
print(
    json.dumps(
        {
            "PASS": checks,
            "source_SHA256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "ports_scope": "main AST branch/finalization and prepared gate; validate input checks otherwise mocked; no native/backend/model/process/runtime imports",
            "native_calls": 0,
            "Popen": 0,
        },
        indent=2,
    )
)
