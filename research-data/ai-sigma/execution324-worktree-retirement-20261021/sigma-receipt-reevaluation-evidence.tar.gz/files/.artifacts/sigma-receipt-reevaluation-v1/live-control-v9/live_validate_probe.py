"""Actual validate AST with bound metadata in memory, never private/model IO."""

import ast
import copy
import hashlib
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "live_worker.py"
ROOT = HERE.parent
AD = json.loads((HERE / "admission.live.prepared-v1.json").read_text())
TREE = ast.parse(SOURCE.read_text())
FUNCTION = next(
    node for node in TREE.body if isinstance(node, ast.FunctionDef) and node.name == "validate"
)
MEMORY = {}
for name in ("campaign", "untimed_plan", "metadata_STOP"):
    MEMORY[AD[name]["path"]] = Path(AD[name]["path"]).read_bytes()
review_path = str(HERE / "MOCK-REVIEW-NOT-WRITTEN.json")
AD.update(actual_entry=True, prepared_only=False, pending_obligations=[])
AD["source_review"] = {
    "control_clear": True,
    "reader_STOP": "mock only",
    "target_binding_SHA256": "a" * 64,
    "path": review_path,
}
AD["bindings"][review_path] = {}
MEMORY[review_path] = json.dumps(
    {
        "blockers": 0,
        "ordinary": 0,
        "target_binding_SHA256": "a" * 64,
        "source_reader_STOP": "mock only",
        "remaining_readers_writers_children_pending_direct_waits_cleanup_TMP": [],
    }
).encode()
MEMORY[str(SOURCE)] = SOURCE.read_bytes()
SHAS = {
    AD[name]["path"]: AD[name]["sha256"]
    for name in ("campaign", "untimed_plan", "private", "metadata_STOP", "prior_charges")
}


class FakePath:
    def __init__(self, value):
        self.value = Path(value)

    def __str__(self):
        return str(self.value)

    def __eq__(self, other):
        return str(self) == str(other)

    @property
    def parent(self):
        return FakePath(self.value.parent)

    def resolve(self, strict=True):
        return self

    def read_bytes(self):
        return MEMORY[str(self)]

    def is_absolute(self):
        return self.value.is_absolute()

    def is_relative_to(self, other):
        return self.value.is_relative_to(other)

    def exists(self):
        return str(self) in MEMORY

    def is_symlink(self):
        return False


PORTS = {
    "Path": FakePath,
    "ROOT": ROOT,
    "__file__": str(SOURCE),
    "time": time,
    "EXPIRY": 1791583340854,
    "json": json,
    "sources": lambda _: None,
    "sha": lambda path: SHAS[str(path)],
}
exec(compile(ast.Module(body=[FUNCTION], type_ignores=[]), str(SOURCE), "exec"), PORTS)


def run(name, mutation=None):
    ad = copy.deepcopy(AD)
    original = copy.deepcopy(MEMORY)
    if mutation:
        mutation(ad)
    try:
        PORTS["validate"](ad)
        assert mutation is None, name + " unexpectedly accepted"
    except ValueError:
        assert mutation is not None, name + " unexpectedly refused"
    finally:
        MEMORY.clear()
        MEMORY.update(original)
    return name


def campaign_change(field, value):
    def mutate(ad):
        record = json.loads(MEMORY[ad["campaign"]["path"]])
        record[field] = value
        MEMORY[ad["campaign"]["path"]] = json.dumps(record).encode()

    return mutate


def wrong_source(ad):
    record = json.loads(MEMORY[ad["campaign"]["path"]])
    record["native"]["compiled_sources_sha256"] = "0" * 64
    MEMORY[ad["campaign"]["path"]] = json.dumps(record).encode()


def missing_warmup(ad):
    record = json.loads(MEMORY[ad["campaign"]["path"]])
    record["phases"][0]["workload"][0]["warmup_logical_calls"] = 0
    MEMORY[ad["campaign"]["path"]] = json.dumps(record).encode()


def bad_timed_prefix(ad):
    record = json.loads(MEMORY[ad["campaign"]["path"]])
    record["phases"][1]["workload"][0]["prefix"] = [13]
    MEMORY[ad["campaign"]["path"]] = json.dumps(record).encode()


if __name__ == "__main__" and len(sys.argv) > 1:
    checks = [run("phase-output missing", lambda ad: ad["native_outputs"].pop("qualified-timed"))]
else:
    checks = [
        run("matching fixed metadata and64 allocation"),
        run("wrong compiled source", wrong_source),
        run(
            "65 logical allocation",
            campaign_change("maximum_total_logical_backend_rows_or_requests", 65),
        ),
        run("expiry refresh", campaign_change("valid_until_unix_ms", 1791583340855)),
        run("missing warmup", missing_warmup),
        run("timed input substitution", bad_timed_prefix),
        run("phase-output missing", lambda ad: ad["native_outputs"].pop("qualified-timed")),
    ]

print(
    json.dumps(
        {
            "PASS": checks,
            "source_SHA256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "scope": "actual validate AST; metadata/source bound checks mocked; fake review only memory/not a production certificate; private/ELF/model/framework/Popen/calls0",
        },
        indent=2,
    )
)
