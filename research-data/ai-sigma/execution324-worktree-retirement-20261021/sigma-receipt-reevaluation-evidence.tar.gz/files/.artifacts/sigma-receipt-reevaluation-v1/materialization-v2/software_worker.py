"""Remaining zero-backend config bindings; verified software/private are reused."""

from builtins import BaseExceptionGroup
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
WT = ROOT.parents[1]
LOCK = Path(
    "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
)


def sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


def verify(path, expected):
    path = Path(path)
    info = path.lstat()
    if (
        not stat.S_ISREG(info.st_mode)
        or path.resolve(strict=True) != path
        or (stat.S_IMODE(info.st_mode), info.st_size, sha(path))
        != (expected["mode"], expected["bytes"], expected["SHA256"])
    ):
        raise ValueError("bound source/tool/control changed: " + str(path))


def quiet():
    names = {
        "cargo",
        "rustc",
        "clippy-driver",
        "cargo-clippy",
        "perf",
        "quoridor-runner",
        "chrome",
        "chromium",
        "chrome-headless-shell",
    }
    markers = (
        "software_worker",
        "software_guard",
        "numeric-worker",
        "numeric_worker",
        "qualify.py",
        "statistics.py",
        "train.py",
        "trainer.py",
        "matches-worker",
        "finite-driver",
        "public-synthetic",
        "execute-retention.py",
    )
    competitors = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdecimal() or int(entry.name) == os.getpid():
            continue
        try:
            argv = [
                os.fsdecode(v)
                for v in (entry / "cmdline").read_bytes().split(b"\0")
                if v
            ]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not argv:
            continue
        executable = Path(argv[0]).name
        if (
            executable in names
            or executable.startswith(
                ("quoridor_runner-", "measure_native", "profile_native")
            )
            or (
                executable.startswith("python")
                and any(Path(a).name.startswith(markers) for a in argv[1:])
            )
        ):
            competitors.append({"pid": int(entry.name), "argv": argv})
    if competitors:
        raise RuntimeError(
            "PRESTART actual named competitor: " + json.dumps(competitors)
        )


def physical():
    available = next(
        int(line.split()[1]) * 1024
        for line in Path("/proc/meminfo").read_text().splitlines()
        if line.startswith("MemAvailable:")
    )
    if available < 10 * 1024**3 or not {2, 4}.issubset(os.sched_getaffinity(0)):
        raise ValueError(
            "fresh family6GiB/host4GiB RAM or physical affinity unavailable"
        )
    cores = [
        tuple(
            (Path(f"/sys/devices/system/cpu/cpu{cpu}/topology") / name)
            .read_text()
            .strip()
            for name in ("physical_package_id", "core_id")
        )
        for cpu in (2, 4)
    ]
    if cores[0] == cores[1]:
        raise ValueError("compiler/controller require distinct physical cores")
    fs = os.statvfs(ROOT)
    if fs.f_bavail * fs.f_frsize < 4294967296:
        raise ValueError("fresh inclusive phase filesystem forecast unavailable")
    return {
        "available_RAM_B": available,
        "CPU2_CPU4_physical": cores,
        "free_filesystem_B": fs.f_bavail * fs.f_frsize,
    }


def sources(admission):
    for path, record in admission["bindings"].items():
        verify(path, record)


def validate(admission):
    # Prepared controls refuse before input, tool, resource or process ports.
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared software is not an actual entry")
    if (
        admission["pending_obligations"]
        or admission["purpose"] != "sigma-receipt-metadata-only"
    ):
        raise ValueError("unresolved software entry obligations")
    if set(admission["cohort_configs"]) != {"d", "nnue"}:
        raise ValueError("exact two cohort configuration roles required")
    if (
        admission["supported_whole_B"] != 4294967296
        or admission["source_review_binding"]
        != "7f78176ef1e8e4ab77771d837aa423f027ee1fb5c6351bddd573b2b5140e52bf"
    ):
        raise ValueError("wrong supported phase/reviewed source")
    required = {
        str(Path(__file__).resolve()),
        str(WT / "Cargo.toml"),
        str(WT / "Cargo.lock"),
        *[
            str(WT / "crates/quoridor-runner/src" / name)
            for name in (
                "main.rs",
                "lib.rs",
                "runtime.rs",
                "sigma_clock.rs",
                "sigma_qualification.rs",
            )
        ],
        "/workspaces/quoridor/python/quoridor_training/__init__.py",
        "/workspaces/quoridor/python/quoridor_training/cycle_process.py",
        "/workspaces/quoridor/python/quoridor_training/snapshot.py",
        "/workspaces/quoridor/scripts/dev/research-job.py",
        "/workspaces/quoridor/scripts/dev/research-job.sh",
        "/workspaces/quoridor/scripts/dev/research-runtime.py",
        "/workspaces/quoridor/research-data/ai-sigma/sigma-receipt-reevaluation-v1/resources.json",
        "/workspaces/quoridor/research-data/ai-sigma/execution-resources-20261008.json",
        admission["environment"]["RUSTC"],
        admission["environment"]["RUSTDOC"],
        admission["commands"][0]["argv"][0],
        admission["plan"]["path"],
        admission["review"]["path"],
        admission["predecessor"]["path"],
        admission["prior_charges"]["path"],
        admission["target_lease"]["path"],
        admission["qualified_software"]["path"],
        admission["current_private"]["path"],
        *[record["path"] for record in admission["cohort_configs"].values()],
    }
    if not required.issubset(admission["bindings"]):
        raise ValueError("required source/tool/controller/proof/config input unbound")
    sources(admission)
    plan_raw = Path(admission["plan"]["path"]).read_bytes()
    if hashlib.sha256(plan_raw).hexdigest() != admission["plan"]["SHA256"]:
        raise ValueError("software plan raw digest changed")
    plan = json.loads(plan_raw)
    if admission["commands"] != plan["commands"]:
        raise ValueError(
            "remaining software commands differ from frozen Clippy/rebuild plan"
        )
    review = admission["review"]
    if review["path"] not in admission["bindings"]:
        raise ValueError("source review absent from bound input membership")
    raw = Path(review["path"]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != review["SHA256"]:
        raise ValueError("review raw SHA mismatch")
    confirmation = json.loads(raw)
    if (
        confirmation["blockers"] != 0
        or confirmation["ordinary"] != 0
        or confirmation["target_binding_SHA256"] != admission["source_review_binding"]
        or not confirmation["source_reader_STOP"]
        or confirmation[
            "remaining_readers_writers_children_pending_direct_waits_cleanup_TMP"
        ]
    ):
        raise ValueError("related reviewed source/readers not clear")
    for name in ("output", "TMP"):
        path = Path(admission[name])
        if (
            not path.is_absolute()
            or not path.is_relative_to(ROOT)
            or path.exists()
            or path.is_symlink()
        ):
            raise ValueError("new exclusive owned software namespace required")
    target = Path(admission["target"])
    if not target.is_relative_to(ROOT) or not target.is_dir() or target.is_symlink():
        raise ValueError("remaining software requires the declared retained OWN target")
    expected = [
        {
            "name": "bindings-" + role,
            "argv": [
                admission["current_private"]["path"],
                "sigma-cost-bindings",
                "--config",
                admission["cohort_configs"][role]["path"],
                "--config-sha256",
                admission["cohort_configs"][role]["SHA256"],
            ],
            "acceptance": "actual metadata only; backend false/model0/same private",
        }
        for role in ("d", "nnue")
    ]
    if admission["commands"] != expected:
        raise ValueError("only exact two unfinished metadata commands permitted")
    supplied = json.loads(Path(admission["qualified_software"]["path"]).read_bytes())
    if (
        supplied["job_id"] != "596fa417-38fc-4ea6-b04e-e96174ba5cfc"
        or supplied["current_fullscope_no_deps_Clippy_Dwarnings_keepgoing"] != "PASS"
        or supplied["affected_release"] != "PASS"
        or supplied["private"] != admission["current_private"]
        or supplied["owned_remaining"]
        or supplied["stage_failures"]
        or len(supplied["receipts"]) != 3
        or [row["receipt"]["exit_code"] for row in supplied["receipts"]] != [0, 0, 1]
        or not all(row["verified"] for row in supplied["receipts"])
    ):
        raise ValueError("current compiled/private partial software proof changed")
    current = admission["current_private"]
    verify(current["path"], admission["bindings"][current["path"]])
    if not Path(current["path"]).is_relative_to(ROOT):
        raise ValueError("current private must remain the exact retained OWN image")
    predecessor = json.loads(Path(admission["predecessor"]["path"]).read_bytes())
    if (
        predecessor["job_id"] != "be9d501e-fa7e-4d49-bcd1-531ce23e8938"
        or predecessor["new13_exact_tests"] != "PASS; no zero-test selections"
        or predecessor["affected_release"] != "PASS"
        or len(predecessor["receipts"]) != 15
        or predecessor["outcome"] != "FAILED Clippy only; predecessor is not success"
        or predecessor["owned_remaining"]
    ):
        raise ValueError("predecessor source/wait/partial PASS proof changed")


def validate_target_lease(admission):
    raw = Path(admission["target_lease"]["path"]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != admission["target_lease"]["SHA256"]:
        raise ValueError("retained target lease raw digest changed")
    lease = json.loads(raw)
    if (
        lease["target"] != admission["target"]
        or lease["environment"] != admission["environment"]
    ):
        raise ValueError("retained target path/compiler/profile environment changed")
    for path, record in lease["files"].items():
        if not Path(path).is_relative_to(Path(admission["target"])):
            raise ValueError("foreign path in retained target lease")
        verify(path, record)
    actual = {
        str(p)
        for p in Path(admission["target"]).rglob("*")
        if p.is_file() or p.is_symlink()
    }
    if actual != set(lease["files"]):
        raise ValueError("retained target namespace changed before remaining work")


def main():
    raw = Path(sys.argv[1]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != sys.argv[2]:
        raise ValueError("immutable actual software admission digest")
    admission = json.loads(raw)
    # The declared refusal precedes source/target IO and lease acquisition.
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared software is not an actual entry")
    quiet()
    physical()
    lock = LOCK.open("r+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet()
        validate(admission)
        validate_target_lease(admission)
    except BaseException as primary:
        try:
            lock.close()
        except BaseException as cleanup:
            raise BaseExceptionGroup(
                "entry refusal and lease-close failure", [primary, cleanup]
            ) from None
        raise
    try:
        # Import the maintained ownership API only after bound validation under lease.
        sys.path.insert(0, "/workspaces/quoridor/python")
        from quoridor_training import cycle_process as P
        from quoridor_training.snapshot import write_json

        P.LOG_MAX_BYTES = 8 * 1024**2
        for key in (
            "RUSTC_WRAPPER",
            "RUSTC_WORKSPACE_WRAPPER",
            "RUSTFLAGS",
            "CARGO_ENCODED_RUSTFLAGS",
        ):
            os.environ.pop(key, None)
        os.environ.update(admission["environment"])
        if (
            os.environ["RUSTUP_AUTO_INSTALL"] != "0"
            or os.environ["CARGO_NET_OFFLINE"] != "true"
            or any(not Path(os.environ[k]).is_absolute() for k in ("RUSTC", "RUSTDOC"))
        ):
            raise ValueError("explicit compiler/no-install/offline required")
        output = Path(admission["output"])
        temporary = Path(admission["TMP"])
    except BaseException as primary:
        try:
            lock.close()
        except BaseException as cleanup:
            raise BaseExceptionGroup(
                "maintained import/setup failure and lease-close failure",
                [primary, cleanup],
            ) from None
        raise
    attempts, errors = [], []
    result = {
        "qualified": False,
        "purpose": admission["purpose"],
        "model_calls": 0,
        "live_calls": 0,
        "all13_new_Rust_definitions": "PASS supplied predecessor exact13; not replayed",
        "predecessor_failed_job": admission["predecessor"],
        "continuous_peak": "UNKNOWN",
        "completed_commands": [],
        "private": admission["current_private"],
        "current_Clippy_release": "PASS supplied596fa proof; not replayed",
    }
    primary = None

    class Resources(P.CycleResources):
        def __init__(self):
            super().__init__(
                {
                    "host_ram_reserve": 4 * 1024**3,
                    "max_memory_bytes": 6 * 1024**3,
                    "max_output_bytes": 256 * 1024**2,
                },
                output,
                time.monotonic() + 900,
            )
            prior = json.loads(Path(admission["prior_charges"]["path"]).read_bytes())
            self.maxima = {
                (row["component"], row["path"]): row["maximum_sampled_allocated_B"]
                for row in prior
            }
            if len(self.maxima) != len(prior):
                raise ValueError("duplicate prior held-charge path")
            self.family_peak = 0

        def check(self, owned=()):
            super().check(owned)
            infos = [
                P.process_info(os.getpid()),
                *(P.process_info(v["pid"]) for v in owned),
            ]
            family = sum(v["rss"] for v in infos if v) + 64 * 1024**2
            self.family_peak = max(self.family_peak, family)
            if family > self.memory_limit:
                raise P.CycleStopped("family RAM including controller reserve")
            for component, root_name, cap in (
                ("target", "target", 2 * 1024**3),
                ("private", "private", 128 * 1024**2),
                ("TMP", "TMP", 512 * 1024**2),
                ("software_controls", "output", 64 * 1024**2),
            ):
                root = Path(admission[root_name])
                pending = [root]
                while pending:
                    parent = pending.pop()
                    try:
                        info = parent.lstat()
                    except FileNotFoundError:
                        continue  # Only these newly owned output/temporary namespaces.
                    if stat.S_ISLNK(info.st_mode):
                        raise P.CycleStopped("owned output symlink")
                    self.maxima[component, str(parent)] = max(
                        self.maxima.get((component, str(parent)), 0),
                        info.st_blocks * 512,
                    )
                    if stat.S_ISDIR(info.st_mode):
                        pending.extend(parent.iterdir())
                    elif not stat.S_ISREG(info.st_mode):
                        raise P.CycleStopped("unsupported owned output kind")
                if (
                    sum(v for (kind, _), v in self.maxima.items() if kind == component)
                    > cap
                ):
                    raise P.CycleStopped(
                        "held named-path allocation exceeds " + component
                    )

    resources = None

    def execute(name, command):
        sources(admission)
        log = output / (name + ".log")
        path = log.with_suffix(".process.json")
        attempts.append({"name": name, "command": command, "receipt": str(path)})
        record = P.execute(command, log, None, cpu_core=2, resources=resources)
        result.setdefault("returned_process_finalization", {})[name] = {
            "signal_mask_restoration": record.get("signal_mask_restoration", "UNKNOWN"),
            "final_record_persist": record.get("final_record_persist", "UNKNOWN"),
            "handle_closes_complete": record.get("handle_closes_complete"),
            "process_cleanup_complete": record.get("process_cleanup_complete"),
        }
        if (
            record["command"] != command
            or record["exit_code"] != 0
            or record["direct_child_reaped"] is not True
            or record["cleanup_complete"] is not True
            or record["remaining"]
            or record["log_bytes_seen"] != record["log_bytes_retained"]
        ):
            raise ValueError("actual command/wait/cleanup/log failed: " + name)
        text = log.read_text()
        sources(admission)
        return text

    def attempt(stage, action):
        try:
            return action()
        except BaseException as error:
            errors.append(
                {"stage": stage, "type": type(error).__name__, "message": str(error)}
            )
            return None

    try:
        quiet()
        result["physical_admission"] = physical()
        sources(admission)
        validate_target_lease(admission)
        os.sched_setaffinity(0, {4})
        output.mkdir()
        temporary.mkdir()
        os.environ["TMPDIR"] = str(temporary)
        os.chdir(WT)
        resources = Resources()
        resources.check()
        result["actual_START"] = datetime.now(timezone.utc).isoformat()
        binding_records = []
        for command in admission["commands"]:
            record = json.loads(execute(command["name"], command["argv"]))
            role = command["name"].removeprefix("bindings-")
            config = admission["cohort_configs"][role]
            if (
                record["schema"] != "quoridor-sigma-cost-bindings-v1"
                or record["backend_loaded"] is not False
                or type(record["model_calls"]) is not int
                or record["model_calls"] != 0
                or record["cost_qualification"] is not None
                or record["config_file"]
                != {"path": config["path"], "sha256": config["SHA256"]}
                or record["executable_sha256"] != result["private"]["SHA256"]
                or not isinstance(record["compiled_sources"], dict)
                or any(
                    not isinstance(record[key], str)
                    or len(record[key]) != 64
                    or any(char not in "0123456789abcdef" for char in record[key])
                    for key in ("normalized_config_sha256", "compiled_sources_sha256")
                )
            ):
                raise ValueError("metadata changed config/private or invoked backend")
            binding_records.append(record)
            write_json(output / (command["name"] + ".json"), record)
            result["completed_commands"].append(
                {"name": command["name"], "command": command["argv"], "PASS": True}
            )
        if (
            binding_records[0]["compiled_sources"]
            != binding_records[1]["compiled_sources"]
            or binding_records[0]["compiled_sources_sha256"]
            != binding_records[1]["compiled_sources_sha256"]
        ):
            raise ValueError("two configuration metadata source identities differ")
        result["software_commands"] = "two previously unfinished metadata bindings only"
    except BaseException as error:
        primary = error
    finally:
        attempt("source_after", lambda: sources(admission))
        if resources is not None:
            attempt("final_resources", resources.check)
        receipts = []
        unknown = False
        remaining = []
        for entry in attempts:
            receipt = attempt(
                "receipt:" + entry["name"],
                lambda entry=entry: json.loads(Path(entry["receipt"]).read_bytes()),
            )
            verified = bool(
                receipt
                and receipt.get("command") == entry["command"]
                and receipt.get("direct_child_reaped") is True
                and receipt.get("cleanup_complete") is True
                and receipt.get("remaining") == []
            )
            unknown |= not verified
            receipts.append(
                {"attempt": entry, "receipt": receipt, "verified": verified}
            )
            if receipt:
                remaining.extend(receipt.get("remaining", []))
        result.update(
            primary_error=None
            if primary is None
            else {"type": type(primary).__name__, "message": str(primary)},
            receipts=receipts,
            attempted_children=attempts,
            cleanup_unknown=unknown,
            remaining=remaining,
            cleanup_complete=not unknown and not remaining,
            source_STOP=datetime.now(timezone.utc).isoformat(),
            stage_failures=errors,
            family_RSS_sample_peak_B=None
            if resources is None
            else resources.family_peak,
        )
        if resources is not None:
            charges = [
                {"component": kind, "path": path, "maximum_sampled_allocated_B": value}
                for (kind, path), value in sorted(resources.maxima.items())
            ]
            attempt(
                "held_charges",
                lambda: write_json(output / "held-charges.json", charges),
            )
        attempt("lock_close", lock.close)
        result["qualified"] = (
            primary is None and not errors and not unknown and len(receipts) == 2
        )
        attempt("result", lambda: write_json(output / "software-result.json", result))
        if errors:
            result["qualified"] = False
            print(json.dumps({"terminal_failure_facts": result}), flush=True)
        if primary is not None:
            raise primary
        if errors or unknown or not result["qualified"]:
            raise RuntimeError(
                "software qualification incomplete: " + json.dumps(result)
            )


if __name__ == "__main__":
    main()
