"""Only new C01-C05 synthetic saved-control/main ports; no native execution."""

from contextlib import ExitStack
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
PROGRESS = []


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def put(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj) + "\n")
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def refuses(action):
    try:
        action()
    except (ValueError, KeyError, TypeError, RuntimeError):
        return
    raise AssertionError("expected refusal")


def main_port(W, E, forecast, origin, fault):
    failures = ()
    with tempfile.TemporaryDirectory(dir=HERE / "ports-tmp-v18") as temp:
        root = Path(temp)
        out = root / "control"
        tmp = root / "tmp"
        n = root / "native"
        n.mkdir()
        put(n / "manifest-start.json", {"synthetic": True})
        put(
            n / "result.json",
            {
                "planned": 16,
                "outcomes": [
                    {"game": g, "status": "unknown", "observations": []} for g in range(16)
                ],
            },
        )
        if fault == "malformed_result":
            (n / "result.json").write_text("{partial")
            (n / "completed.jsonl").write_text(
                json.dumps(
                    {"game": 0, "status": "unknown", "failure": "illegal_move", "observations": []}
                )
                + "\n{partial"
            )
        prior = root / "prior.json"
        put(prior, [])
        f = root / "forecast.json"
        put(f, forecast)
        cmds = [[name, ["synthetic-native", name]] for name in ("arena", "audit", "recover")]
        adm = {
            "role": "D",
            "actual_entry": True,
            "prepared_only": False,
            "pending_obligations": [],
            "required_imports": W.REQUIRED_IMPORTS,
            "bindings": {},
            "helper": "synthetic-guard",
            "evidence_helper": "synthetic-evidence",
            "whole_forecast": str(f),
            "output": str(out),
            "native_output": str(n),
            "TMP": str(tmp),
            "prior_charges": str(prior),
            "environment": {},
            "commands": cmds,
        }
        adm["bindings"] = {
            p: {} for p in [adm["helper"], adm["evidence_helper"], *W.REQUIRED_IMPORTS]
        }
        ap = root / "admission.json"
        raw = json.dumps(adm).encode()
        ap.write_bytes(raw)
        executed = []
        final = []

        class Lease:
            def close(self):
                final.append("lock_close")
                if "lock_close" in failures:
                    raise OSError("synthetic lease close")

        class Base:
            def __init__(self, config, output, deadline):
                self.memory_limit = config["max_memory_bytes"]

            def check(self, owned=()):
                if len(executed) == 3 and "final_resources" in failures:
                    raise OSError("synthetic final resource")

        def execute(argv, log, deadline, **kwargs):
            executed.append(argv[-1])
            r = {
                "command": argv,
                "exit_code": 1 if origin == argv[-1] else 0,
                "direct_child_reaped": True,
                "cleanup_complete": True,
                "remaining": [],
                "log_bytes_seen": 1,
                "log_bytes_retained": 1,
                "handle_closes_complete": True,
                "process_cleanup_complete": True,
                "signal_mask_restoration": "completed",
                "final_record_persist": "completed",
            }
            put(log.with_suffix(".process.json"), r)
            if "receipt" in failures and argv[-1] == "recover":
                log.with_suffix(".process.json").write_text("[1]")
            return r

        def write(path, data):
            name = {
                "held-charges.json": "held_charges",
                "cohort-result.json": "result",
            }[path.name]
            final.append(name)
            if name in failures:
                raise OSError("synthetic " + name)
            put(path, data)

        def verify(*args):
            if len(executed) == 3 and "source_after" in failures:
                raise OSError("synthetic source after")

        def rmdir(path):
            if path == tmp and "owned_empty_TMP" in failures:
                final.append("owned_empty_TMP")
                raise OSError("synthetic TMP")
            return real_rmdir(path)

        def diagnostic(*args, **kwargs):
            final.append("diagnostic")
            if "diagnostic" in failures:
                raise OSError("synthetic diagnostic")

        package = ModuleType("quoridor_training")
        package.__path__ = []
        package.cycle_process = SimpleNamespace(
            CycleResources=Base,
            execute=execute,
            process_info=lambda pid: {"rss": 0},
            CycleStopped=RuntimeError,
        )
        snapshot = ModuleType("quoridor_training.snapshot")
        snapshot.write_json = write
        guard = SimpleNamespace(
            quiet=lambda: None,
            physical=lambda: {},
            sha=lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest(),
        )
        fakeE = SimpleNamespace(
            BASELINE=prior,
            ledger=lambda rows, *args: {
                (r["component"], r["path"]): r["maximum_sampled_allocated_B"] for r in rows
            },
            rows=E.rows,
            saved_census=E.saved_census,
        )
        real_rmdir = Path.rmdir
        error = None
        real_methods = {key: getattr(Path, key) for key in ("is_file", "is_symlink", "exists")}
        targets = {
            "manifest_is_file": (n / "manifest-start.json", "is_file"),
            "manifest_is_symlink": (n / "manifest-start.json", "is_symlink"),
            "result_is_file": (n / "result.json", "is_file"),
            "result_is_symlink": (n / "result.json", "is_symlink"),
            "TMP_exists": (tmp, "exists"),
        }

        def method(key):
            def checked(path):
                if fault in targets and targets[fault] == (path, key):
                    raise OSError(5, "synthetic availability EIO " + fault)
                return real_methods[key](path)

            return checked

        with ExitStack() as stack:
            for obj, key, value in [
                (sys, "argv", ["port", str(ap), hashlib.sha256(raw).hexdigest()]),
                (W, "review_and_fixed_proofs", lambda *args: None),
                (W, "validate", lambda *args: None),
                (W, "verify", verify),
                (W, "LOCK", SimpleNamespace(open=lambda mode: Lease())),
                (
                    W,
                    "fcntl",
                    SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *args: None),
                ),
                (W.os, "sched_setaffinity", lambda *args: None),
                (
                    W.importlib.util,
                    "spec_from_file_location",
                    lambda name, path: SimpleNamespace(
                        name=name, loader=SimpleNamespace(exec_module=lambda m: None)
                    ),
                ),
                (
                    W.importlib.util,
                    "module_from_spec",
                    lambda spec: fakeE if spec.name == "cohort_evidence" else guard,
                ),
                (Path, "rmdir", rmdir),
            ]:
                stack.enter_context(patch.object(obj, key, value))
            for key in real_methods:
                stack.enter_context(patch.object(Path, key, method(key)))
            stack.enter_context(
                patch.dict(
                    sys.modules,
                    {
                        "quoridor_training": package,
                        "quoridor_training.snapshot": snapshot,
                    },
                )
            )
            stack.enter_context(patch.dict(W.os.environ, {}, clear=False))
            stack.enter_context(patch("builtins.print", diagnostic))
            try:
                W.main()
            except BaseException as err:
                error = err
            expected = ["arena"] if origin == "arena" else ["arena", "audit"]
        if not fault.startswith("manifest_"):
            expected.append("recover")
        assert executed == expected, (fault, origin, executed)
        assert final[-1] == "lock_close" and all(
            x in final for x in ("result", "diagnostic", "held_charges")
        )
        assert error is not None
        details = (
            json.loads(error.__notes__[-1])
            if origin
            else json.loads(str(error).split("cohort incomplete: ", 1)[1])
        )
        if origin:
            assert origin in str(error) and type(error) is ValueError
        stages = {x["stage"]: x["status"] for x in details["independent_finalizer_attempts"]}
        for name in (
            "saved_recovery",
            "saved_census",
            "saved_clock_census",
            "run_report_binding",
            "source_after",
            "final_resources",
            "held_charges",
            "owned_empty_TMP",
            "result",
            "diagnostic",
            "lock_close",
        ):
            assert name in stages, (fault, name)
        assert stages["result"] == stages["diagnostic"] == stages["lock_close"] == "completed"
        assert (
            details["independent_finalizer_errors"]
            and details["guardian_overall_cleanup"] == "failed_UNKNOWN"
        )
        saved = json.loads((out / "cohort-result.json").read_text())
        assert saved["provisional_only"] and not saved["external_controller_acceptance"]
        assert "PENDING" in saved["guardian_finalization_status"]
        key = (
            "saved_recovery_availability"
            if fault.startswith("manifest_")
            else "owned_TMP_availability"
            if fault == "TMP_exists"
            else "saved_report_availability"
        )
        if fault != "malformed_result":
            assert saved[key].startswith("UNKNOWN"), (fault, saved[key])
        else:
            assert (
                saved["slot_census"]["observed_ids"] == [0]
                and saved["slot_census"]["partial_journal_tail"]
            )
            assert stages["saved_census"] == "failed_UNKNOWN"


def run(W, E):
    passed = PROGRESS
    forecast = json.loads((HERE.parent / "cohort-repair-v17/whole-forecast-v17.json").read_text())
    for origin in (None, "arena", "audit"):
        for fault in (
            "manifest_is_file",
            "manifest_is_symlink",
            "result_is_file",
            "result_is_symlink",
            "TMP_exists",
        ):
            main_port(W, E, forecast, origin, fault)
            passed.append(f"C05-R1 actual-main availability={fault} origin={origin}")
    main_port(W, E, forecast, "arena", "malformed_result")
    passed.append("C04-R1 actual-main malformed result preserves journal and refuses admission")
    with tempfile.TemporaryDirectory(dir=HERE / "ports-tmp-v18") as temp:
        root = Path(temp)
        rows = [
            {"game": 0, "status": "unknown", "failure": "illegal_move", "observations": []},
            {"game": 3, "status": "unknown", "failure": "time_overrun", "observations": []},
        ]
        for kind in (
            "malformed_truncated",
            "wrong_denominator",
            "malformed_no_journal",
            "report_stat_refusal",
            "journal_read_refusal",
            "invalid_journal_row",
            "valid_report_priority",
        ):
            n = root / kind
            n.mkdir()
            report, journal = n / "result.json", n / "completed.jsonl"
            report.write_text("{partial")
            journal.write_bytes(b"".join(json.dumps(x).encode() + b"\n" for x in rows))
            if kind == "malformed_truncated":
                with journal.open("ab") as f:
                    f.write(b"{partial")
            elif kind == "wrong_denominator":
                put(report, {"planned": 15, "outcomes": []})
            elif kind == "malformed_no_journal":
                journal.unlink()
            elif kind == "invalid_journal_row":
                journal.write_text(
                    json.dumps(rows[0])
                    + "\n"
                    + json.dumps({"game": 16, "status": "unknown"})
                    + "\n"
                )
            elif kind == "valid_report_priority":
                put(report, {"planned": 16, "outcomes": rows[:1]})
            real_file, real_open = Path.is_file, Path.open

            def is_file(path):
                if kind == "report_stat_refusal" and path == report:
                    raise PermissionError("synthetic report stat")
                return real_file(path)

            def opened(path, *args, **kwargs):
                if kind in ("journal_read_refusal", "valid_report_priority") and path == journal:
                    raise OSError("synthetic journal read")
                return real_open(path, *args, **kwargs)

            with patch.object(Path, "is_file", is_file), patch.object(Path, "open", opened):
                c = E.saved_census(n)
            expected = (
                [0]
                if kind in ("valid_report_priority", "invalid_journal_row")
                else []
                if kind in ("malformed_no_journal", "journal_read_refusal")
                else [0, 3]
            )
            assert c["observed_ids"] == expected and c["planned_ids"] == list(range(16))
            assert len(c["missing_ids"]) == 16 - len(expected) and c["incomplete_pairs"] == 8
            assert not c["finalized_report_qualified"]
            assert bool(c["saved_evidence_errors"]) == (kind != "valid_report_priority")
            if kind in ("malformed_truncated", "invalid_journal_row", "journal_read_refusal"):
                assert c["partial_journal_tail"]
            if expected:
                assert c["typed_observed_status"] == {"unknown": len(expected)}
                assert "illegal_move" in c["typed_observed_reasons"]
            passed.append("C04-R1 saved census " + kind)
    return {
        "passed_new_cases": passed,
        "count": len(passed),
        "old45_and_all_other_successes_replayed": False,
        "actual_native_Cargo_backend_model_Search_geometry_games": 0,
    }


if __name__ == "__main__":
    print(
        json.dumps(
            run(
                load(HERE / "cohort_worker.py", "worker"),
                load(HERE / "cohort_evidence.py", "evidence"),
            ),
            indent=2,
        )
    )
