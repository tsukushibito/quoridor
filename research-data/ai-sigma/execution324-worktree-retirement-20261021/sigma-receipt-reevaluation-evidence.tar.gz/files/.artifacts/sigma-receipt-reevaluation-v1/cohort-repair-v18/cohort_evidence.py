"""Thin saved-evidence, retained-ledger and partial-census consumers. No native calls."""

from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path(__file__).resolve().parents[1]
WT = ROOT.parents[1]
THREAD = "01a11062-b120-73a1-8aa3-fe2cb922c7c0"
PRIVATE = ROOT / "private-current-v5/quoridor-runner"
PACKET = ROOT / "live-control-output-v1/arena-admitted-packet.json"
D_CONFIG = ROOT / "configuration-v2/config-d-16.fixed-v2.json"
PLAN = ROOT / "cohort-control-v15/both-cohorts-plan.fixed-v15.json"
BASELINE = ROOT / "live-control-output-v1/held-charges.json"
CLASSIFICATION = {
    "target": "build_deps_link",
    "private": "one_private_image_and_backend_artifacts",
    "live": "live_qualification_raw",
    "software_controls": "controller_configs_logs",
    "D": "Sigma_D_16_raw",
    "NNUE": "Sigma_BEST51_16_raw",
    "TMP": "serial_TMP",
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def record(path):
    p = Path(path)
    info = p.lstat()
    require(
        stat.S_ISREG(info.st_mode) and not p.is_symlink() and p.resolve() == p,
        "canonical regular saved input",
    )
    h = hashlib.sha256()
    with p.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
    return {"SHA256": h.hexdigest(), "bytes": info.st_size, "mode": stat.S_IMODE(info.st_mode)}


def read_ref(ref, bindings):
    path = ref["path"]
    require(path in bindings and bindings[path] == record(path), "saved evidence binding changed")
    require(ref["sha256"] == bindings[path]["SHA256"], "saved evidence SHA mismatch")
    return json.loads(Path(path).read_bytes())


def ledger(rows, forecast, baseline):
    """Consume existing classifications/caps; retain every sampled maximum."""
    require(isinstance(rows, list), "retained ledger must be a list")
    caps = forecast["all_original_component_uppers_B"]
    require(
        forecast["supported_whole_B"] == 4294967296 and sum(caps.values()) == 4294967296,
        "original whole support",
    )
    maxima, paths, totals = {}, set(), Counter()
    for row in rows:
        kind, path, value = row["component"], row["path"], row["maximum_sampled_allocated_B"]
        require(
            kind in CLASSIFICATION and isinstance(path, str) and type(value) is int and value >= 0,
            "typed nonnegative classified retained maximum",
        )
        p = Path(path)
        require(
            p.is_absolute() and p.is_relative_to(WT) and str(p) == path and ".." not in p.parts,
            "owned named retained path",
        )
        require(path not in paths, "duplicate or alternatively classified retained path")
        paths.add(path)
        maxima[kind, path] = value
        totals[CLASSIFICATION[kind]] += value
    for row in baseline:
        key = row["component"], row["path"]
        require(
            key in maxima and maxima[key] >= row["maximum_sampled_allocated_B"],
            "retained baseline maximum erased or credited",
        )
    require(sum(totals.values()) <= forecast["supported_whole_B"], "retained whole overflow")
    for kind, value in totals.items():
        require(value <= caps[kind], "retained component overflow: " + kind)
    target = max(totals["build_deps_link"], forecast["named_retained_target_floor_B"])
    joint = (
        target
        + forecast["separate_Main_helper_target_upper_B"]
        + forecast["separate_Main_helper_TMP_upper_B"]
    )
    require(joint <= caps["build_deps_link"], "held joint build/Main target/TMP overflow")
    # Unobserved original components remain reserved at their declared upper.
    accounted = sum(totals.get(kind, cap) for kind, cap in caps.items())
    accounted += max(0, joint - totals["build_deps_link"])
    require(
        accounted <= forecast["supported_whole_B"],
        "whole including joint/unobserved support overflow",
    )
    return maxima


def rows(maxima):
    return [
        {"component": k, "path": p, "maximum_sampled_allocated_B": v}
        for (k, p), v in sorted(maxima.items())
    ]


def partial_census(outcomes, planned=16, partial_tail=False, availability="report"):
    require(planned == 16, "fixed16 denominator")
    indexed, reasons = {}, Counter()
    for outcome in outcomes:
        game = outcome["game"]
        require(
            type(game) is int and game in range(16) and game not in indexed,
            "unique planned outcome ID",
        )
        require(outcome["status"] in ("goal", "draw", "unknown"), "typed outcome status")
        indexed[game] = outcome
        if outcome.get("failure") is not None:
            reasons[str(outcome["failure"])] += 1
        for move in outcome.get("observations", []):
            for key in ("failure", "engine_error", "stop"):
                if move.get(key) is not None:
                    reasons[key + ":" + str(move[key])] += 1
    missing = sorted(set(range(16)) - indexed.keys())
    pairs = [
        {
            "family_index": i,
            "planned_ids": [2 * i, 2 * i + 1],
            "observed_ids": [g for g in (2 * i, 2 * i + 1) if g in indexed],
            "known_complete": all(
                g in indexed and indexed[g]["status"] in ("goal", "draw")
                for g in (2 * i, 2 * i + 1)
            ),
        }
        for i in range(8)
    ]
    return {
        "planned_ids": list(range(16)),
        "observed_ids": sorted(indexed),
        "missing_ids": missing,
        "pair_coverage": pairs,
        "known_complete_pairs": sum(p["known_complete"] for p in pairs),
        "incomplete_pairs": sum(not p["known_complete"] for p in pairs),
        "typed_observed_status": dict(Counter(o["status"] for o in outcomes)),
        "typed_observed_reasons": dict(reasons),
        "missing_status": "UNKNOWN; no inferred start or outcome",
        "partial_journal_tail": partial_tail,
        "availability": availability,
    }


def saved_census(native):
    native = Path(native)
    report_path, journal = native / "result.json", native / "completed.jsonl"
    errors = []

    def refused(stage, error):
        errors.append({"stage": stage, "type": type(error).__name__, "message": str(error)})

    def finish(census):
        census["saved_evidence_errors"] = errors
        census["finalized_report_qualified"] = False
        return census

    try:
        if report_path.is_file() and not report_path.is_symlink():
            report = json.loads(report_path.read_bytes())
            require(report["planned"] == 16, "saved report fixed denominator")
            return finish(
                partial_census(
                    report["outcomes"], availability="saved result, audit separately qualified"
                )
            )
    except Exception as error:
        refused("result_read_parse_census", error)
    # An invalid final report never erases an independently readable durable prefix.
    outcomes, partial = [], False
    journal_available = False
    try:
        if journal.is_file() and not journal.is_symlink():
            journal_available = True
            with journal.open("rb") as stream:
                for line in stream:
                    if not line.endswith(b"\n"):
                        partial = True
                        break
                    try:
                        outcome = json.loads(line)
                        partial_census([*outcomes, outcome])
                    except Exception as error:
                        refused("journal_row_decode_census", error)
                        partial = True
                        break
                    outcomes.append(outcome)
    except Exception as error:
        refused("journal_availability_read", error)
        partial = True
    return finish(
        partial_census(
            outcomes,
            partial_tail=partial,
            availability="durable journal only; native recovery separately recorded"
            if journal_available
            else "unavailable output; no inferred start/outcome; read refusals retained separately",
        )
    )


def completed_d(bundle, a, clock_check):
    """Derive admission facts from exact stopped external and native saved records."""
    require(
        bundle.get("schema") == "quoridor-cohort-completion-input-v1",
        "positive declaration is not D evidence",
    )
    refs = bundle["references"]
    required = {
        "admission",
        "config",
        "state",
        "controller",
        "guardian",
        "report",
        "planned",
        "manifest",
        "arena_receipt",
        "audit_receipt",
        "recover_receipt",
        "held_charges",
    }
    require(set(refs) == required, "complete external D reference set")
    objects = {key: read_ref(ref, a["bindings"]) for key, ref in refs.items()}
    admission, config, state, controller, guardian = (
        objects[k] for k in ("admission", "config", "state", "controller", "guardian")
    )
    runtime = Path(refs["controller"]["path"]).parent
    require(
        runtime.is_relative_to(ROOT)
        and all(
            Path(refs[k]["path"]) == runtime / (name + ".json")
            for k, name in (("config", "config"), ("state", "state"), ("controller", "result"))
        ),
        "same authoritative runtime",
    )
    require(
        admission["role"] == "D"
        and admission["actual_entry"] is True
        and admission["prepared_only"] is False
        and admission["pending_obligations"] == []
        and admission["config"] == str(D_CONFIG)
        and admission["private"] == str(PRIVATE)
        and admission["packet"] == str(PACKET)
        and admission["plan"] == str(PLAN),
        "fixed actual D admission",
    )
    for path in (str(D_CONFIG), str(PRIVATE), str(PACKET), str(PLAN)):
        require(
            admission["bindings"][path] == a["bindings"][path],
            "D plan/config/private/packet identity",
        )
    require(
        config["issue"] == "quoridor-4lc.347.3"
        and config["goal_issue"] == "quoridor-4lc.347"
        and config["thread_id"] == THREAD
        and config["cwd"] == str(WT)
        and config["resource_contract"] == refs["admission"]["path"]
        and config["argv"]
        == [
            "/usr/bin/python3.11",
            "-B",
            str(Path(__file__).with_name("cohort_worker.py")),
            refs["admission"]["path"],
            refs["admission"]["sha256"],
        ]
        and all(config[k] is None for k in ("end_at", "notify_until", "max_runtime_seconds")),
        "D controller identity/argv",
    )
    fingerprint = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
    require(
        state["config_sha256"] == fingerprint
        and state["issue"] == config["issue"]
        and state["thread_id"] == THREAD
        and state["job_id"] == controller["job_id"]
        and state["phase"] == "finished"
        and state["outcome"] == controller["outcome"] == "succeeded"
        and controller["error"] is None
        and type(controller["exit_code"]) is int
        and controller["exit_code"] == 0
        and controller["direct_child_reaped"] is True
        and controller["cleanup_complete"] is True
        and controller["remaining"] == controller["cleanup_errors"] == []
        and controller["descendant_visibility"] == "observed"
        and controller["log_bytes_seen"] == controller["log_bytes_retained"]
        and controller["finished_at"],
        "failed/partial/UNKNOWN/off-identity external D controller",
    )
    require(
        Path(refs["guardian"]["path"]) == Path(admission["output"]) / "cohort-result.json"
        and guardian["role"] == "D"
        and guardian["provisional_only"] is True
        and guardian["external_controller_acceptance"] is False
        and guardian["primary_error"] is None
        and guardian["stage_failures"] == []
        and guardian["native_process_cleanup_complete"] is True
        and guardian["native_process_cleanup_unknown"] is False
        and guardian["source_STOP"],
        "failed/partial/provisional declaration D guardian",
    )
    require(
        datetime.fromisoformat(state["started_at"])
        <= datetime.fromisoformat(guardian["source_STOP"])
        <= datetime.fromisoformat(controller["finished_at"]),
        "D exact STOP chronology",
    )
    attempts, receipts = guardian["attempted_children"], guardian["receipts"]
    require(
        len(attempts) == len(receipts) == 3
        and [x["name"] for x in attempts] == ["arena", "audit", "recover"],
        "D three direct commands",
    )
    native = Path(admission["native_output"])
    require(
        Path(refs["held_charges"]["path"]) == Path(admission["output"]) / "held-charges.json"
        and isinstance(objects["held_charges"], list),
        "completed D retained ledger identity",
    )
    config_d = read_ref(
        {"path": str(D_CONFIG), "sha256": a["bindings"][str(D_CONFIG)]["SHA256"]}, a["bindings"]
    )
    plan = read_ref(
        {"path": str(PLAN), "sha256": a["bindings"][str(PLAN)]["SHA256"]}, a["bindings"]
    )
    expected = [
        [
            str(PRIVATE),
            "arena",
            "--config",
            str(D_CONFIG),
            "--sigma-cost-qualification",
            str(PACKET),
            "--qualification-sha256",
            a["bindings"][str(PACKET)]["SHA256"],
        ],
        [str(PRIVATE), "arena", "--audit", str(native)],
        [str(PRIVATE), "arena", "--recover", str(native)],
    ]
    identities = [state["child"]]
    for entry, row, command in zip(attempts, receipts, expected, strict=True):
        key = entry["name"] + "_receipt"
        receipt = objects[key]
        require(
            entry["command"] == command
            and Path(refs[key]["path"])
            == Path(admission["output"]) / (entry["name"] + ".process.json")
            and row["attempt"] == entry
            and row["receipt"] == receipt
            and row["verified"] is True
            and receipt["command"] == command
            and type(receipt["exit_code"]) is int
            and receipt["exit_code"] == 0
            and receipt["direct_child_reaped"] is True
            and receipt["cleanup_complete"] is True
            and receipt["process_cleanup_complete"] is True
            and receipt["handle_closes_complete"] is True
            and receipt["remaining"] == receipt["finalization_errors"] == []
            and receipt["log_bytes_seen"] == receipt["log_bytes_retained"],
            "D exact successful direct receipt",
        )
        returned = guardian["returned_process_finalization"][entry["name"]]
        require(
            returned["signal_mask_restoration"] == returned["final_record_persist"] == "completed"
            and returned["handle_closes_complete"] is True
            and returned["process_cleanup_complete"] is True,
            "D returned finalization vs persisted pending distinction",
        )
        identities.append(receipt["child"])
    for identity in identities:
        require(
            type(identity["pid"]) is int
            and identity["pid"] > 0
            and isinstance(identity["start_ticks"], str)
            and identity["start_ticks"].isdigit()
            and isinstance(identity["boot_id"], str),
            "D process identity",
        )
    report, planned, manifest = (objects[k] for k in ("report", "planned", "manifest"))
    require(
        Path(refs["report"]["path"]) == native / "result.json"
        and Path(refs["planned"]["path"]) == native / "planned.json"
        and Path(refs["manifest"]["path"]) == native / "manifest.json"
        and native == Path(config_d["output"])
        and report["run_id"] == config_d["run_id"]
        and report["planned"] == 16
        and len(report["outcomes"]) == 16,
        "D final planned/report identity",
    )
    require(
        len(planned) == 16
        and [s["game"] for s in planned] == list(range(16))
        and all(
            s["opening"] == early["prefix"] and s["candidate_color"] == early["color_index"]
            for s, early in zip(planned, plan["cohorts"]["D"]["slots"], strict=True)
        ),
        "D frozen planned prefixes/colors",
    )
    binding = manifest["binding"]
    require(
        binding["config"] == config_d
        and binding["config_sha256"] == plan["cohorts"]["D"]["normalized_config_sha256"]
        and binding["planned_slots"] == planned
        and manifest["result"] == report
        and binding["executable_sha256"] == a["bindings"][str(PRIVATE)]["SHA256"],
        "D native manifest/private/report binding",
    )
    for name, key in (("result.json", "report"), ("planned.json", "planned")):
        require(
            manifest["artifacts"][name]["sha256"] == refs[key]["sha256"]
            and manifest["artifacts"][name]["bytes"] == a["bindings"][refs[key]["path"]]["bytes"],
            "D manifest artifact hash/length",
        )
    census = clock_check(report)
    require(census["cost_disproved"] == 0, "disproved original cost cannot admit NNUE")
    require(guardian["clock_census"] == census, "D derived clock census differs")
    return {
        "role": "D",
        "job_id": controller["job_id"],
        "controller_fingerprint": fingerprint,
        "clock_census": census,
        "slot_census": partial_census(report["outcomes"]),
        "controller_STOP": controller["finished_at"],
        "identities": identities,
        "held_charges": refs["held_charges"],
        "valid_UNKNOWN_outcomes_preserved": True,
    }


def consume_completed_d(proof_ref, a, clock_check):
    proof = read_ref(proof_ref, a["bindings"])
    require(
        proof.get("schema") == "quoridor-derived-completed-D-v1",
        "declared acceptance flag cannot admit",
    )
    bundle = read_ref(proof["evidence_bundle"], a["bindings"])
    derived = completed_d(bundle, a, clock_check)
    require(proof["derived"] == derived, "completed D evidence must be re-derived")
    return derived


def preceding_ledger(derived, a):
    require(
        a["prior_charges"] == derived["held_charges"]["path"], "NNUE must retain completed D ledger"
    )
    return read_ref(derived["held_charges"], a["bindings"])


def main():
    """One saved-only derivation after actual external STOP, without replay."""
    import argparse
    import fcntl
    import importlib.util
    import os

    parser = argparse.ArgumentParser()
    parser.add_argument("--control", required=True)
    parser.add_argument("--control-sha256", required=True)
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--bundle-sha256", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    require(record(args.control)["SHA256"] == args.control_sha256, "saved control SHA")
    a = json.loads(Path(args.control).read_bytes())
    worker_path = Path(__file__).with_name("cohort_worker.py")
    require(
        a["bindings"][str(worker_path)] == record(worker_path)
        and a["bindings"][str(Path(__file__).resolve())] == record(Path(__file__).resolve()),
        "saved consumer/worker identity before import",
    )
    spec = importlib.util.spec_from_file_location("cohort_saved_worker", worker_path)
    worker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(worker)
    worker.review_and_fixed_proofs(a)
    worker.verify(a["helper"], a["bindings"][a["helper"]])
    spec = importlib.util.spec_from_file_location("cohort_saved_guard", a["helper"])
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    guard.quiet()
    guard.physical()
    with guard.LOCK.open("r+") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        guard.quiet()
        bundle_ref = {"path": args.bundle, "sha256": args.bundle_sha256}
        bundle = read_ref(bundle_ref, a["bindings"])
        derived = completed_d(bundle, a, worker.clock_census)
        output = Path(args.output)
        require(
            output.is_relative_to(ROOT) and not output.exists() and not output.is_symlink(),
            "new owned derived evidence",
        )
        payload = {
            "schema": "quoridor-derived-completed-D-v1",
            "evidence_bundle": bundle_ref,
            "derived": derived,
        }
        with output.open("x") as stream:
            json.dump(payload, stream, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
    print(
        json.dumps(
            {
                "saved_derived_D": str(output),
                "sha256": record(output)["SHA256"],
                "native_backend_model_Search_game_calls": 0,
            }
        )
    )


if __name__ == "__main__":
    main()
