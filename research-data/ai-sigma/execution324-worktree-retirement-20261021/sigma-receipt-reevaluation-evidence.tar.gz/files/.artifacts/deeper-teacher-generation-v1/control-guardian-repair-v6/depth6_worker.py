"""One fixed four-game generation, saved audit, and exact owned finalization."""

from builtins import BaseExceptionGroup
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
WT = ROOT.parents[1]
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
ASSET = Path("/workspaces/quoridor/.worktree/assets/data/deeper-teacher-generation-v1/depth6-four")
SCHEMA = "quoridor-fixed-d-depth6-throughput-v1"
POLICY = "fixed-d-depth6-independent-games-v1"
IDS = [f"deeper-teacher-depth6-four-game-{i:03}" for i in range(4)]


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def verify(path, expected):
    path = Path(path)
    info = path.lstat()
    if (
        not stat.S_ISREG(info.st_mode)
        or path.resolve(strict=True) != path
        or (stat.S_IMODE(info.st_mode), info.st_size, sha(path))
        != (expected["mode"], expected["bytes"], expected["SHA256"])
    ):
        raise ValueError("bound SHA/mode/size changed: " + str(path))


def sources(admission):
    for path, expected in admission["bindings"].items():
        verify(path, expected)


def quiet():
    names = {
        "cargo",
        "rustc",
        "clippy-driver",
        "cargo-clippy",
        "perf",
        "quoridor-runner",
        "chrome",
        "chromium",
        "chrome-headless-shell",
    }
    markers = (
        "software_worker",
        "software_guard",
        "numeric-worker",
        "numeric_worker",
        "qualify.py",
        "statistics.py",
        "train.py",
        "trainer.py",
        "matches-worker",
        "finite-driver",
        "public-synthetic",
        "execute-retention.py",
        "live_worker.py",
        "depth6_worker.py",
    )
    competitors = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdecimal() or int(entry.name) == os.getpid():
            continue
        try:
            argv = [os.fsdecode(v) for v in (entry / "cmdline").read_bytes().split(b"\0") if v]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not argv:
            continue
        executable = Path(argv[0]).name
        if (
            executable in names
            or executable.startswith(("quoridor_runner-", "measure_native", "profile_native"))
            or (
                executable.startswith("python")
                and any(Path(a).name.startswith(markers) for a in argv[1:])
            )
        ):
            competitors.append({"pid": int(entry.name), "argv": argv})
    if competitors:
        raise RuntimeError("PRESTART actual named competitor: " + json.dumps(competitors))


def physical():
    ram = next(
        int(line.split()[1]) * 1024
        for line in Path("/proc/meminfo").read_text().splitlines()
        if line.startswith("MemAvailable:")
    )
    cores = [
        tuple(
            (Path(f"/sys/devices/system/cpu/cpu{cpu}/topology") / field).read_text().strip()
            for field in ("physical_package_id", "core_id")
        )
        for cpu in (0, 2, 4)
    ]
    quota = Path("/sys/fs/cgroup/cpu.max").read_text().split()
    if (
        ram < 6 * 1024**3
        or not {0, 2, 4}.issubset(os.sched_getaffinity(0))
        or len(set(cores)) != 3
        or (quota[0] != "max" and int(quota[0]) < 3 * int(quota[1]))
    ):
        raise ValueError("family2GiB/host4GiB/distinct0,2,4/three-core quota refused")
    fs = os.statvfs(ROOT)
    if fs.f_bavail * fs.f_frsize < 1610612736:
        raise ValueError("whole supported filesystem forecast unavailable")
    return {
        "RAM_available_B": ram,
        "CPU0_CPU2_CPU4_physical": cores,
        "cpu_max": quota,
        "filesystem_available_B": fs.f_bavail * fs.f_frsize,
        "scheduler_isolation": "UNKNOWN",
    }


def validate(admission):
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared four-game control is not entry")
    if (
        admission["pending_obligations"]
        or admission["purpose"] != "depth6-fixed-four"
        or admission["supported_whole_B"] != 1610612736
    ):
        raise ValueError("unsupported or unresolved four-game entry")
    required = {
        str(Path(__file__).resolve()),
        admission["private"]["path"],
        admission["config"]["path"],
        admission["plan"]["path"],
        admission["helper_STOP"]["path"],
        admission["control_review"]["path"],
        *admission["maintained_sources"],
    }
    if not required.issubset(admission["bindings"]):
        raise ValueError("necessary private/source/config/proof/control unbound")
    sources(admission)
    helper = json.loads(Path(admission["helper_STOP"]["path"]).read_bytes())
    if (
        helper["private_executable"] != admission["private"]
        or helper["affected_tests_passed"] != 6
        or helper["build_status"] != "PASS"
        or helper["CLI_config_only"] != "PASS"
        or helper["review"]["blockers"] != 0
        or helper["owned_readers_children_TMP_remaining"]
    ):
        raise ValueError("stopped helper/private/source proof differs")
    review = json.loads(Path(admission["control_review"]["path"]).read_bytes())
    if (
        review["blockers"] != 0
        or review["ordinary"] != 0
        or review["target_binding_SHA256"] != admission["control_review"]["target_binding_SHA256"]
        or not review["source_reader_STOP"]
        or review["remaining_readers_writers_children_pending_direct_waits_cleanup_TMP"]
    ):
        raise ValueError("fixed changed control boundary not cleared/stopped")
    plan = json.loads(Path(admission["plan"]["path"]).read_bytes())
    if (
        plan["config"]["path"] != admission["config"]["path"]
        or plan["config"]["SHA256"] != admission["config"]["SHA256"]
        or plan["same_private"] != admission["private"]
        or plan["argv"] != admission["commands"]
        or plan["fixed_scientific_game_count"] != 4
        or plan["gameIDs"] != IDS
        or plan["N"] is not None
    ):
        raise ValueError("fixed plan/config/private/argv/census changed")
    config = json.loads(Path(admission["config"]["path"]).read_bytes())
    expected = {
        "phase": "depth6_throughput",
        "main_volume_n": None,
        "ruleset": "standard_2p_threefold",
        "run_id": "depth6-four-throughput-348-v1",
        "output": str(ASSET),
        "planned_games": 4,
        "prefix_seed": 20261008,
        "attempts_per_prefix": 32,
        "depth": 6,
        "max_nodes": 2**64 - 1,
        "tt_slots": 4096,
        "use_pvs": True,
        "solver_order_contact": False,
        "distance_a": 0.0,
        "distance_b": 8.0,
        "per_move_timeout_ms": None,
        "max_total_plies": 200,
        "cpu_core": 0,
        "game_workers": 2,
        "worker_cores": [0, 2],
        "host_ram_reserve": 4294967296,
        "max_memory_bytes": 2013265920,
        "max_output_bytes": 67108864,
    }
    if config != expected or admission["config_body"] != expected:
        raise ValueError("exact four-game depth6/no-time/u64MAX/config scope changed")
    private, path = admission["private"]["path"], admission["config"]["path"]
    expected_argv = [
        [private, "teacher-pilot", "--config", path, "--check-config"],
        ["/usr/bin/taskset", "--cpu-list", "0,2", private, "teacher-pilot", "--config", path],
        [private, "teacher-pilot", "--audit", str(ASSET)],
    ]
    if [item["argv"] for item in admission["commands"]] != expected_argv:
        raise ValueError("only exact config-binding/generation/saved-audit stages admitted")
    for value in (admission["output"], admission["TMP"], str(ASSET)):
        path = Path(value)
        if (
            not path.is_absolute()
            or path.parent.resolve(strict=True) != path.parent
            or path.exists()
            or path.is_symlink()
        ):
            raise ValueError("new canonical exclusive output namespace required")
    if any(not Path(admission[key]).is_relative_to(ROOT) for key in ("output", "TMP")):
        raise ValueError("guardian logs/TMP outside owned phase")


def collect_stream(path, admission, audited):
    # Native saved auditor owns geometry/chronology/labels. This census binds its
    # exact output to current private/config and all four scheduled identities.
    digest = hashlib.sha256()
    header, footer, indexed = None, None, []
    seen = 0
    requests_seen = False
    with Path(path).open("rb") as stream:
        for raw in stream:
            seen += len(raw)
            digest.update(raw)
            if (
                seen > 64 * 1024**2
                or len(raw) > 16 * 1024**2 + 1
                or raw[-1:] != b"\n"
                or footer is not None
            ):
                raise ValueError("partial/oversized/afterfooter authoritative stream")
            record = json.loads(raw)
            if record["type"] == "requests" and seen == len(raw):
                if (
                    record["schema"] != SCHEMA
                    or record["planned"] != 4
                    or record["requested"]
                    != [[value, length] for value, length in zip(IDS, [4, 8, 12, 16], strict=True)]
                    or record["config_sha256"] != admission["config"]["SHA256"]
                ):
                    raise ValueError("four planned request identity changed")
                requests_seen = True
            elif record["type"] == "header" and requests_seen and header is None and not indexed:
                header = record["record"]
                if (
                    header["schema"] != SCHEMA
                    or header["generator_version"] != POLICY
                    or header["config_sha256"] != admission["config"]["SHA256"]
                    or header["executable_sha256"] != admission["private"]["SHA256"]
                    or header["config"] != admission["config_body"]
                    or header["resource_admission"]["worker_cores"] != [0, 2]
                    or header["compiled_sources"] != admission["compiled_sources"]
                    or [item["request_id"] for item in header["scheduled"]] != IDS
                    or header["evaluator"] != "original-distance-a0-b8-tanh"
                ):
                    raise ValueError("header source/private/config/scheduled identity differs")
            elif record["type"] == "game" and header is not None:
                game = record["record"]
                if game["index"] != len(indexed) or len(indexed) >= 4:
                    raise ValueError("missing/duplicate/extra or reordered outcome")
                indexed.append(game["result"])
            elif record["type"] == "footer" and header is not None and len(indexed) == 4:
                footer = record["record"]
            else:
                raise ValueError("partial/unknown authoritative record ordering")
    if footer is None or footer != audited:
        raise ValueError("saved audit/footer mismatch or incomplete four outcomes")
    if (
        footer["scheduled"] != 4
        or footer["recorded"] != 4
        or footer["goals"] + footer["draws"] + footer["unknown"] != 4
        or footer["full_volume_n"] is not None
    ):
        raise ValueError("planned outcome denominator or N changed")
    details = footer["depth6"]
    if (
        details["policy"] != POLICY
        or details["requested_depth"] != 6
        or details["max_nodes"] != 2**64 - 1
        or details["game_workers"] != details["workers_joined"]
        or details["workers_joined"] != 2
        or details["search_threads_per_game"] != 1
        or details["queue_slots_per_worker"] != 1
        or details["completed_games_per_hour"] is not None
        or details["eligible_rows_per_hour"] is not None
    ):
        raise ValueError("depth6/join/rate scope differs")
    return {
        "stream_SHA256": digest.hexdigest(),
        "stream_bytes": seen,
        "audited": audited,
        "indexed_outcome_status": [item["status"] for item in indexed],
        "all_four_retained": True,
        "sample_limits": "four fixed targetblind lengths; no d3 extrapolation/N/strength claim",
    }


def receipt_fields(receipt, entry):
    if type(receipt) is not dict or type(receipt.get("remaining")) is not list:
        raise ValueError("malformed receipt object/remaining list")
    if type(receipt.get("exit_code")) is not int:
        raise ValueError("missing or malformed receipt exit_code")
    verified = (
        receipt.get("command") == entry["command"]
        and receipt.get("direct_child_reaped") is True
        and receipt.get("cleanup_complete") is True
        and receipt["remaining"] == []
    )
    return verified, receipt["remaining"]


def receipt_census(attempts, receipts, commands):
    return (
        len(attempts) == len(receipts) == len(commands) == 3
        and [item["command"] for item in attempts] == [item["argv"] for item in commands]
        and all(
            type(item) is dict
            and item.get("verified") is True
            and type(item.get("receipt")) is dict
            and type(item["receipt"].get("exit_code")) is int
            and item["receipt"]["exit_code"] == 0
            for item in receipts
        )
    )


def main():
    started = time.monotonic()
    raw = Path(sys.argv[1]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != sys.argv[2]:
        raise ValueError("immutable actual four-game admission SHA")
    admission = json.loads(raw)
    if admission["actual_entry"] is not True or admission["prepared_only"] is not False:
        raise ValueError("prepared four-game control is not entry")
    quiet()
    physical()
    lock = LOCK.open("r+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        quiet()
        validate(admission)
        sys.path.insert(0, "/workspaces/quoridor/python")
        from quoridor_training import cycle_process as P
        from quoridor_training.snapshot import write_json

        P.LOG_MAX_BYTES = 8 * 1024**2
        output, temporary = Path(admission["output"]), Path(admission["TMP"])
        os.environ.update(admission["environment"])
    except BaseException as primary:
        try:
            lock.close()
        except BaseException as cleanup:
            raise BaseExceptionGroup("entry and lease-close failure", [primary, cleanup]) from None
        raise
    errors, attempts = [], []
    primary, resources = None, None
    begin = started
    result = {
        "qualified": False,
        "planned_games": 4,
        "N": None,
        "science_retry": False,
        "model_calls": 0,
        "qualification_scope": "exact four scheduled outcomes and saved audit; failed/UNKNOWN outcomes retained, not four completed games",
        "returned_process_finalization": {},
        "continuous_peak": "UNKNOWN",
        "old_fees_raw_masks_assets_UNKNOWN": "HELD",
    }

    class Resources(P.CycleResources):
        def __init__(self):
            super().__init__(
                {
                    "host_ram_reserve": 4 * 1024**3,
                    "max_memory_bytes": 2 * 1024**3,
                    "max_output_bytes": 8 * 1024**2,
                },
                output,
                None,
            )
            self.maxima = dict(admission["retained_component_floors_B"])
            self.paths = {}
            self.family_peak = 0

        def check(self, owned=()):
            super().check(owned)
            infos = [P.process_info(os.getpid()), *(P.process_info(item["pid"]) for item in owned)]
            self.family_peak = max(
                self.family_peak, sum(item["rss"] for item in infos if item) + 64 * 1024**2
            )
            if self.family_peak > self.memory_limit:
                raise P.CycleStopped("family2GiB includes controller64MiB")
            for kind, root, cap in [
                ("raw", ASSET, 64 * 1024**2),
                ("controls", output, 128 * 1024**2),
                ("TMP", temporary, 64 * 1024**2),
            ]:
                pending = [root]
                while pending:
                    path = pending.pop()
                    try:
                        info = path.lstat()
                    except FileNotFoundError:
                        continue  # Newly owned namespaces only; retained floors remain.
                    if stat.S_ISLNK(info.st_mode):
                        raise P.CycleStopped("owned output symlink")
                    self.paths[kind, str(path)] = max(
                        self.paths.get((kind, str(path)), 0), info.st_blocks * 512
                    )
                    if stat.S_ISDIR(info.st_mode):
                        pending.extend(path.iterdir())
                    elif not stat.S_ISREG(info.st_mode):
                        raise P.CycleStopped("owned output type")
                used = sum(
                    value for (component, _), value in self.paths.items() if component == kind
                )
                if used + self.maxima.get(kind, 0) > cap:
                    raise P.CycleStopped("held plus prospective component cap: " + kind)

    def attempt(stage, action):
        try:
            return action()
        except BaseException as error:
            errors.append({"stage": stage, "type": type(error).__name__, "message": str(error)})
            return None

    def execute(item):
        quiet()
        sources(admission)
        log = output / (item["name"] + ".log")
        path = log.with_suffix(".process.json")
        attempts.append({"name": item["name"], "command": item["argv"], "receipt": str(path)})
        record = P.execute(item["argv"], log, None, cpu_core=None, resources=resources)
        result["returned_process_finalization"][item["name"]] = {
            key: record.get(key, "UNKNOWN")
            for key in (
                "signal_mask_restoration",
                "final_record_persist",
                "handle_closes_complete",
                "process_cleanup_complete",
            )
        }
        if (
            record["command"] != item["argv"]
            or record["exit_code"] != 0
            or record["direct_child_reaped"] is not True
            or record["cleanup_complete"] is not True
            or record["remaining"]
            or record["log_bytes_seen"] != record["log_bytes_retained"]
        ):
            raise ValueError("exact stage/log/directwait/cleanup failed: " + item["name"])
        sources(admission)
        return json.loads(log.read_bytes())

    try:
        quiet()
        result["physical_admission"] = physical()
        sources(admission)
        os.sched_setaffinity(0, {4})
        os.chdir(WT)
        output.mkdir()
        temporary.mkdir()
        os.environ["TMPDIR"] = str(temporary)
        resources = Resources()
        resources.check()
        result["actual_START"] = datetime.now(timezone.utc).isoformat()
        checked = execute(admission["commands"][0])
        if (
            checked["valid"] is not True
            or type(checked["models_loaded"]) is not int
            or checked["models_loaded"] != 0
            or checked["main_volume_n"] is not None
            or checked["pilot_config_sha256"] != admission["config"]["SHA256"]
            or checked["compiled_sources"] != admission["compiled_sources"]
            or checked["fixed_D"] != "original-distance-a0-b8-tanh"
        ):
            raise ValueError("current config-only private/source binding refused")
        generated = execute(admission["commands"][1])
        audited = execute(admission["commands"][2])
        if generated != audited:
            raise ValueError("generation and saved-only audit reports differ")
        result["observations"] = collect_stream(ASSET / "pilot-stream.jsonl", admission, audited)
    except BaseException as error:
        primary = error
    finally:
        attempt("source_after", lambda: sources(admission))
        if resources is not None:
            attempt("final_resources", resources.check)
        receipts, remaining, unknown = [], [], False
        for entry in attempts:
            receipt = attempt(
                "receipt:" + entry["name"],
                lambda entry=entry: json.loads(Path(entry["receipt"]).read_bytes()),
            )
            fields = attempt(
                "receipt_fields:" + entry["name"],
                lambda receipt=receipt, entry=entry: receipt_fields(receipt, entry),
            )
            verified = fields is not None and fields[0] is True
            unknown |= not verified
            receipts.append({"attempt": entry, "receipt": receipt, "verified": verified})
            if fields is not None:
                remaining.extend(fields[1])
        if resources is not None:
            attempt(
                "held_charges",
                lambda: write_json(
                    output / "held-charges.json",
                    {
                        "retained_component_floors_B": resources.maxima,
                        "new_held_path_maxima": [
                            {"component": kind, "path": path, "maximum_sampled_allocated_B": value}
                            for (kind, path), value in sorted(resources.paths.items())
                        ],
                    },
                ),
            )
        if not unknown and not remaining and temporary.exists():
            attempt("owned_empty_TMP", temporary.rmdir)
        result.update(
            primary_error=None
            if primary is None
            else {"type": type(primary).__name__, "message": str(primary)},
            receipts=receipts,
            remaining=remaining,
            cleanup_unknown=unknown,
            source_STOP=datetime.now(timezone.utc).isoformat(),
            stage_failures=errors,
            sampled_family_peak_B=None if resources is None else resources.family_peak,
        )
        census = attempt(
            "receipt_census", lambda: receipt_census(attempts, receipts, admission["commands"])
        )
        result["qualified"] = primary is None and not errors and not unknown and census is True
        whole = time.monotonic() - begin
        result["guardian_observed_through_prepublication_s"] = whole
        result["completed_games_per_hour"] = None
        result["eligible_rows_per_hour"] = None
        result["primary_rate_interval"] = (
            "PENDING exact external controller whole through directwait/final cleanup STOP; owner saved-only collection computes rates, no native/audit replay"
        )
        attempt("result", lambda: write_json(output / "depth6-result.json", result))
        if errors:
            result["qualified"] = False
            attempt(
                "terminal_diagnostic",
                lambda: print(json.dumps({"terminal_failure_facts": result}), flush=True),
            )
            attempt(
                "terminal_failure_result", lambda: write_json(output / "depth6-result.json", result)
            )
        attempt("lock_close", lock.close)
        if primary is not None:
            if errors:
                BaseException.add_note(
                    primary, json.dumps({"independent_finalizer_errors": errors})
                )
            raise primary
        if errors or unknown or not result["qualified"]:
            raise RuntimeError("four-game qualification incomplete: " + json.dumps(result))


if __name__ == "__main__":
    main()
