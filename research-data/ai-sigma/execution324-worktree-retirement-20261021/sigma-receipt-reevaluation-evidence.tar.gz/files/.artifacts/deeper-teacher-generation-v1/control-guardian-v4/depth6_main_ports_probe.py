"""Actual new guardian main AST; fake execution/IO only, no native process."""

import ast
from builtins import BaseExceptionGroup
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import sys
import time
from types import ModuleType, SimpleNamespace

SOURCE = Path(__file__).with_name("depth6_worker.py")
TREE = ast.parse(SOURCE.read_text())
FUNCTIONS = {node.name: node for node in TREE.body if isinstance(node, ast.FunctionDef)}


def run(mode):
    memory, commands = {}, []

    class FakePath:
        def __init__(self, value):
            self.value = str(value)

        def __str__(self):
            return self.value

        def __truediv__(self, name):
            return FakePath(self.value + "/" + name)

        def with_suffix(self, suffix):
            return FakePath(self.value.rsplit(".", 1)[0] + suffix)

        def read_bytes(self):
            return memory[self.value]

        def open(self, _):
            return SimpleNamespace(close=lambda: None, fileno=lambda: 1)

        def mkdir(self):
            memory[self.value] = None

        def exists(self):
            return self.value in memory

        def lstat(self):
            if not self.exists():
                raise FileNotFoundError(self.value)
            return SimpleNamespace(
                st_mode=stat.S_IFDIR if memory[self.value] is None else stat.S_IFREG, st_blocks=0
            )

        def iterdir(self):
            return [
                FakePath(name)
                for name in list(memory)
                if name.startswith(self.value + "/") and "/" not in name[len(self.value) + 1 :]
            ]

        def rmdir(self):
            assert not self.iterdir()
            del memory[self.value]

    def write_json(path, value):
        memory[str(path)] = json.dumps(value).encode()

    admission = {
        "purpose": "depth6-fixed-four",
        "actual_entry": True,
        "prepared_only": False,
        "output": "out",
        "TMP": "tmp",
        "environment": {},
        "config": {"SHA256": "c" * 64},
        "compiled_sources": {"mock": "s" * 64},
        "retained_component_floors_B": {},
        "commands": [
            {"name": name, "argv": ["private", name]} for name in ("config", "generation", "audit")
        ],
    }
    write_json("admission", admission)
    report = {"scheduled": 4, "goals": 0, "draws": 0, "unknown": 4, "eligible_rows": 0}

    class Resources:
        def __init__(self, *args):
            self.memory_limit = 2 * 1024**3

        def check(self, owned=()):
            if mode == "primary-and-final-resource-failure" and len(commands) == 2:
                raise RuntimeError("independent final resource failure")

    def execute(command, log, deadline, **kwargs):
        commands.append(command)
        name = command[1]
        exit_code = (
            1
            if mode in ("generation-failed", "primary-and-final-resource-failure")
            and name == "generation"
            else 0
        )
        record = {
            "command": command,
            "exit_code": exit_code,
            "direct_child_reaped": True,
            "cleanup_complete": mode != "audit-cleanup-unknown" or name != "audit",
            "remaining": [],
            "log_bytes_seen": 2,
            "log_bytes_retained": 2,
            "signal_mask_restoration": "completed",
            "final_record_persist": "completed",
            "handle_closes_complete": True,
            "process_cleanup_complete": True,
        }
        write_json(log.with_suffix(".process.json"), record)
        value = (
            report
            if name != "config"
            else {
                "valid": True,
                "models_loaded": 0,
                "main_volume_n": None,
                "pilot_config_sha256": "c" * 64,
                "compiled_sources": {"mock": "s" * 64},
                "fixed_D": "original-distance-a0-b8-tanh",
            }
        )
        if mode == "config-refused" and name == "config":
            value = {**value, "models_loaded": 1}
        write_json(log, value)
        return record

    process = ModuleType("quoridor_training.cycle_process")
    process.CycleResources = Resources
    process.process_info = lambda _: {"rss": 1}
    process.execute = execute
    process.CycleStopped = RuntimeError
    package = ModuleType("quoridor_training")
    package.cycle_process = process
    snapshot = ModuleType("quoridor_training.snapshot")
    snapshot.write_json = write_json
    sys.modules["quoridor_training"] = package
    sys.modules["quoridor_training.cycle_process"] = process
    sys.modules["quoridor_training.snapshot"] = snapshot
    ports = {
        "Path": FakePath,
        "ROOT": FakePath("root"),
        "WT": FakePath("wt"),
        "LOCK": FakePath("lock"),
        "ASSET": FakePath("asset"),
        "json": json,
        "hashlib": hashlib,
        "sys": SimpleNamespace(
            argv=["worker", "admission", hashlib.sha256(memory["admission"]).hexdigest()],
            path=SimpleNamespace(insert=lambda *args: None),
        ),
        "os": SimpleNamespace(
            environ={}, sched_setaffinity=lambda *args: None, getpid=lambda: 1, chdir=lambda _: None
        ),
        "stat": stat,
        "datetime": datetime,
        "timezone": timezone,
        "BaseExceptionGroup": BaseExceptionGroup,
        "fcntl": SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *args: None),
        "time": time,
        "quiet": lambda: None,
        "physical": lambda: {},
        "validate": lambda _: None,
        "sources": lambda _: None,
        "collect_stream": lambda *args: {"audited": report},
    }
    for name in ("receipt_census", "main"):
        exec(
            compile(ast.Module(body=[FUNCTIONS[name]], type_ignores=[]), str(SOURCE), "exec"), ports
        )
    caught = None
    try:
        ports["main"]()
    except Exception as error:
        caught = error
    result = json.loads(memory["out/depth6-result.json"])
    expected_count = {
        "matching-three": 3,
        "config-refused": 1,
        "generation-failed": 2,
        "primary-and-final-resource-failure": 2,
        "audit-cleanup-unknown": 3,
    }[mode]
    assert len(commands) == expected_count
    if mode == "matching-three":
        assert caught is None and result["qualified"] is True
        assert (
            result["completed_games_per_hour"] is None and result["eligible_rows_per_hour"] is None
        )
    else:
        assert caught is not None and result["qualified"] is False
    if mode == "primary-and-final-resource-failure":
        assert isinstance(caught, ValueError) and "generation" in str(caught)
        assert any(row["stage"] == "final_resources" for row in result["stage_failures"])
    if mode == "audit-cleanup-unknown":
        assert result["cleanup_unknown"] is True
    assert result["planned_games"] == 4 and result["N"] is None
    return mode


checks = [
    run(mode)
    for mode in (
        "matching-three",
        "config-refused",
        "generation-failed",
        "primary-and-final-resource-failure",
        "audit-cleanup-unknown",
    )
]
print(
    json.dumps(
        {
            "PASS": checks,
            "source_SHA256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "scope": "actual main AST; source validation/physical/native/collector ports mocked; new sequencing/partial refusal/independent finalization/external-rate-only behavior, no Popen/native/model/geometry or old tests",
            "calls": 0,
        },
        indent=2,
    )
)
