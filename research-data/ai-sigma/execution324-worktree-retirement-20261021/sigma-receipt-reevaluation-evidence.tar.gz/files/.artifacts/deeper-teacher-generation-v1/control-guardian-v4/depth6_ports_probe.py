"""New collector/receipt AST tests with in-memory streams; no native or geometry."""

import ast
import copy
import hashlib
import json
from pathlib import Path

SOURCE = Path(__file__).with_name("depth6_worker.py")
TREE = ast.parse(SOURCE.read_text())
FUNCTIONS = {node.name: node for node in TREE.body if isinstance(node, ast.FunctionDef)}
IDS = [f"deeper-teacher-depth6-four-game-{i:03}" for i in range(4)]
POLICY = "fixed-d-depth6-independent-games-v1"
SCHEMA = "quoridor-fixed-d-depth6-throughput-v1"
admission = {
    "config": {"SHA256": "c" * 64},
    "config_body": {"mock": True},
    "private": {"SHA256": "e" * 64},
    "compiled_sources": {"mock_source": "s" * 64},
}
footer = {
    "scheduled": 4,
    "recorded": 4,
    "goals": 1,
    "draws": 1,
    "unknown": 2,
    "eligible_rows": 2,
    "full_volume_n": None,
    "depth6": {
        "policy": POLICY,
        "requested_depth": 6,
        "max_nodes": 2**64 - 1,
        "game_workers": 2,
        "workers_joined": 2,
        "search_threads_per_game": 1,
        "queue_slots_per_worker": 1,
        "completed_games_per_hour": None,
        "eligible_rows_per_hour": None,
    },
}
records = [
    {
        "type": "requests",
        "schema": SCHEMA,
        "planned": 4,
        "requested": [
            [identity, length] for identity, length in zip(IDS, [4, 8, 12, 16], strict=True)
        ],
        "config_sha256": "c" * 64,
    },
    {
        "type": "header",
        "record": {
            "schema": SCHEMA,
            "generator_version": POLICY,
            "config_sha256": "c" * 64,
            "config": {"mock": True},
            "resource_admission": {"worker_cores": [0, 2]},
            "executable_sha256": "e" * 64,
            "compiled_sources": {"mock_source": "s" * 64},
            "scheduled": [{"request_id": identity} for identity in IDS],
            "evaluator": "original-distance-a0-b8-tanh",
        },
    },
]
records += [
    {
        "type": "game",
        "record": {"index": index, "result": {"status": "returned" if index < 2 else "failed"}},
    }
    for index in range(4)
]
records += [{"type": "footer", "record": footer}]
stream_lines = []


class Stream:
    def __enter__(self):
        return iter(stream_lines)

    def __exit__(self, *args):
        return False


class FakePath:
    def __init__(self, value):
        pass

    def open(self, mode):
        assert mode == "rb"
        return Stream()


ports = {
    "Path": FakePath,
    "hashlib": hashlib,
    "json": json,
    "SCHEMA": SCHEMA,
    "POLICY": POLICY,
    "IDS": IDS,
}
for name in ("collect_stream", "receipt_census"):
    exec(compile(ast.Module(body=[FUNCTIONS[name]], type_ignores=[]), str(SOURCE), "exec"), ports)


def check(name, mutate=None, audit_mutate=None, truncate=False):
    values = copy.deepcopy(records)
    audited = copy.deepcopy(footer)
    if mutate:
        mutate(values)
    if audit_mutate:
        audit_mutate(audited)
    stream_lines.clear()
    stream_lines.extend((json.dumps(value) + "\n").encode() for value in values)
    if truncate:
        stream_lines[-1] = stream_lines[-1][:-1]
    try:
        result = ports["collect_stream"]("MOCK ONLY", admission, audited)
        assert mutate is None and audit_mutate is None and not truncate, name + " accepted"
        assert result["indexed_outcome_status"] == ["returned", "returned", "failed", "failed"]
    except ValueError:
        assert mutate is not None or audit_mutate is not None or truncate, name + " refused"
    return name


checks = [
    check("all4 with failed outcomes retained"),
    check("missing requests", lambda values: values.pop(0)),
    check("changed config", lambda values: values[0].update(config_sha256="0" * 64)),
    check("wrong private", lambda values: values[1]["record"].update(executable_sha256="0" * 64)),
    check(
        "wrong effective CPUs",
        lambda values: values[1]["record"]["resource_admission"].update(worker_cores=[0, 1]),
    ),
    check("duplicate index", lambda values: values[3]["record"].update(index=0)),
    check("missing outcome", lambda values: values.pop(3)),
    check("extra after footer", lambda values: values.append(values[-1])),
    check("partial line", truncate=True),
    check("audit/footer disagreement", audit_mutate=lambda audited: audited.update(goals=2)),
]
commands = [{"argv": ["private", name]} for name in ("config-only", "generation", "audit")]
attempts = [{"command": command["argv"]} for command in commands]
receipts = [{"verified": True, "receipt": {"exit_code": 0}} for _ in commands]
assert ports["receipt_census"](attempts, receipts, commands)
assert not ports["receipt_census"](attempts[:-1], receipts[:-1], commands)
wrong = copy.deepcopy(attempts)
wrong[1]["command"] = ["private", "EXTRA"]
assert not ports["receipt_census"](wrong, receipts, commands)
uncertain = copy.deepcopy(receipts)
uncertain[1]["verified"] = False
assert not ports["receipt_census"](attempts, uncertain, commands)
checks.extend(
    [
        "exact3 receipts",
        "missing receipt refusal",
        "argv substitution refusal",
        "unknown cleanup refusal",
    ]
)
called = []
prepared = {"actual_entry": False, "prepared_only": True}
gate_ports = {"sources": lambda _: called.append("IO")}
exec(
    compile(ast.Module(body=[FUNCTIONS["validate"]], type_ignores=[]), str(SOURCE), "exec"),
    gate_ports,
)
try:
    gate_ports["validate"](prepared)
    raise AssertionError("prepared passed")
except ValueError as error:
    assert str(error) == "prepared four-game control is not entry" and not called
checks.append("preparedfalse before input IO")
print(
    json.dumps(
        {
            "PASS": checks,
            "source_SHA256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "scope": "new collector identity/order/footer/receipt and prepared AST with memory/audit ports; no geometry/labels/native/realSearch/model/Popen or old successful fixture replay",
            "calls": 0,
        },
        indent=2,
    )
)
