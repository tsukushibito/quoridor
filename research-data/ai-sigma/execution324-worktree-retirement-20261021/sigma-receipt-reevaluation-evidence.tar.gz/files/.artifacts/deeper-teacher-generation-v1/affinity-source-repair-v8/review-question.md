# SAME348.3: changed depth6 inlet and prior-config receipt join

Review only the f9f532bb -> current worker delta, corrected prepared plan/admission/job and new8 supplied ports. Reuse prior G1 clear aad450/b536, helper/source/private/B1/Rust/math and old20+8+1 proof without replay.

Does the four-distinct-core/quota4 mask0246 match unchanged native resources admission while preserving actual workers02 and guardian4? Does the SHA-bound successful same-config/private prior command remain separate from the exactly2 new generation/audit receipt registry, with malformed/unknown/stale evidence refused? Are execution, scientific collector, source/resource/finalization and UNKNOWN refusal unchanged? Source-only; no native/model/Search/geometry/fixture execution. Preparedfalse and fresh actual-entry predicates remain mandatory.

Return fixed findings/control SHAs and actual readerSTOP to348.2+324 once. No new role, whole-owner ACK, hardware reservation or method gate.
