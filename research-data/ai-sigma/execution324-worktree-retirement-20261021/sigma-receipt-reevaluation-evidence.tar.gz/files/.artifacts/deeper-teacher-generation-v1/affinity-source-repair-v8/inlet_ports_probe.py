"""New affinity/partial-config-reuse AST ports, no native code or process."""

import ast
import copy
import json
from pathlib import Path
import re
from types import SimpleNamespace
import hashlib

SOURCE = Path(__file__).with_name("depth6_worker.py")
functions = {
    n.name: n for n in ast.parse(SOURCE.read_text()).body if isinstance(n, ast.FunctionDef)
}
checks = []


class PhysicalPath:
    def __init__(self, value):
        self.value = str(value)

    def __truediv__(self, value):
        return PhysicalPath(self.value + "/" + value)

    def read_text(self):
        if self.value == "/proc/meminfo":
            return "MemAvailable: 12582912 kB\n"
        if self.value == "/sys/fs/cgroup/cpu.max":
            return quota
        match = re.search(r"cpu(\d+)/topology/(.+)$", self.value)
        assert match
        return "0" if match[2] == "physical_package_id" else str(int(match[1]) // 2)


ports = {
    "Path": PhysicalPath,
    "ROOT": "mock",
    "os": SimpleNamespace(
        sched_getaffinity=lambda _: affinity,
        statvfs=lambda _: SimpleNamespace(f_bavail=3 * 1024**3, f_frsize=1),
    ),
}
exec(compile(ast.Module(body=[functions["physical"]], type_ignores=[]), str(SOURCE), "exec"), ports)
affinity = {0, 2, 4, 6}
quota = "400000 100000"
ports["physical"]()
checks.append("four physical cores admit two workers plus native host reserves")
for affinity, quota, name in [
    ({0, 2, 4}, "400000 100000", "missing native reserved core refused"),
    ({0, 2, 4, 6}, "300000 100000", "three-core quota refused"),
]:
    try:
        ports["physical"]()
        raise AssertionError(name)
    except ValueError:
        checks.append(name)

ad = json.loads((SOURCE.parent / "admission.depth6.prepared-v4.json").read_text())
memory = {role: Path(path).read_bytes() for role, path in ad["prior_config_binding"].items()}


class BoundPath:
    def __init__(self, value):
        self.value = str(value)

    def read_bytes(self):
        return memory[
            next(role for role, path in ad["prior_config_binding"].items() if path == self.value)
        ]


cache_ports = {"Path": BoundPath, "json": json}
exec(
    compile(ast.Module(body=[functions["cached_config"]], type_ignores=[]), str(SOURCE), "exec"),
    cache_ports,
)
checked = cache_ports["cached_config"](ad)
assert checked["models_loaded"] == 0 and checked["pilot_config_sha256"] == ad["config"]["SHA256"]
checks.append("actual successful first config proof reused without CLI execution")
original = copy.deepcopy(memory)
for mutation, name in [
    ("exit_code", "prior failed exit refuses cache"),
    ("cleanup_complete", "prior unknown cleanup refuses cache"),
    ("proof_digest", "wrong prior artifact digest refuses cache"),
]:
    memory.clear()
    memory.update(original)
    if mutation == "proof_digest":
        stop = json.loads(memory["STOP"])
        stop["immutable_runtime_refs"][ad["prior_config_binding"]["log"]]["SHA256"] = "0" * 64
        memory["STOP"] = json.dumps(stop).encode()
    else:
        receipt = json.loads(memory["receipt"])
        receipt[mutation] = 1 if mutation == "exit_code" else False
        memory["receipt"] = json.dumps(receipt).encode()
    try:
        cache_ports["cached_config"](ad)
        raise AssertionError(name)
    except ValueError:
        checks.append(name)
# Actual changed census accepts only two NEW records; prior config is not copied into registry.
exec(
    compile(ast.Module(body=[functions["receipt_census"]], type_ignores=[]), str(SOURCE), "exec"),
    cache_ports,
)
commands = ad["commands"][1:]
attempts = [{"command": c["argv"]} for c in commands]
receipts = [{"verified": True, "receipt": {"exit_code": 0}} for _ in commands]
assert cache_ports["receipt_census"](attempts, receipts, commands) is True
assert (
    cache_ports["receipt_census"](
        attempts + [{"command": ad["commands"][0]["argv"]}],
        receipts + [receipts[0]],
        commands + [ad["commands"][0]],
    )
    is False
)
checks.append("new2 registry excludes prior config receipt")
print(
    json.dumps(
        {
            "PASS": checks,
            "source_SHA256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "scope": "new physical/cached-config/census AST with fake hardware and saved metadata; no native/Popen/model/Search/geometry or old proof/test replay",
        },
        indent=2,
    )
)
