"""NEW synthetic selected-plan, byte-codec and fake-array curve boundaries only."""

import ast
from contextlib import ExitStack
import copy
import gzip
import hashlib
import importlib.util
import math
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest

ROOT = Path(__file__).resolve().parent
BEFORE = ROOT.parent / "encoding-related-v4"
spec = importlib.util.spec_from_file_location(
    "fixture_before_v4", BEFORE / "test_current_encoding.py"
)
fixture_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture_module)  # Fixtures only: no predecessor unittest scope executes.
package = types.ModuleType("repair_ports")
package.__path__ = [str(BEFORE), "/workspaces/quoridor/python/quoridor_training"]
sys.modules[package.__name__] = package
common = types.ModuleType("repair_ports.common")
common.__package__ = package.__name__
sys.modules[common.__name__] = common
exec(
    compile(
        gzip.decompress((ROOT / "common-post.py.gz").read_bytes()), "common-post.py.gz", "exec"
    ),
    common.__dict__,
)
distance_steps = __import__("repair_ports.distance_steps", fromlist=["distance_steps"])
# Existing scaled-statistics import is an unrelated port, never a real model load.
scaled = types.ModuleType("repair_ports.scaled_model")
scaled.validate_statistics = lambda value: value
sys.modules[scaled.__name__] = scaled


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_bytes(fixture_module.encode(value))


def file_ref(path):
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size, "mode": "0644"}


def recipe():
    # Complete fake selected settings; no human method is selected by this fixture.
    cfg = copy.deepcopy(common.DEFAULTS)
    cfg["model"].update(architecture="distance_residual", distance_b=0)
    cfg["optimizer"].update(lr=1e-4, betas=[0.9, 0.999], eps=1e-8)
    cfg["training"].update(target="z", batch_size=256)
    cfg["evaluation"]["monitor"] = "row"
    cfg["artifacts"]["mode"] = "native"
    cfg["experiment"].update(
        study=common.WARMSTART_STUDY,
        main_volume_N=2,
        teacher_mapping="exclude_outside_unit",
        draw_policy="include_threefold",
        warm_start={
            "descriptor": {"sha256": common.BEST43_DESCRIPTOR},
            "weights": {"sha256": common.BEST43_WEIGHTS},
            "evaluator_sha256": common.BEST43_EVALUATOR,
            "optimizer": "fresh",
            "scale": "incumbent",
        },
    )
    return common.resolve_config(cfg)


def rebind(root, m):
    # Physical file identities are fresh and consistent even on semantic corruptions.
    for name in m["files"]:
        m["sha256"][name] = sha(root / name)
    write_json(root / "cache.json", m)


def binary_fixture(root):
    m, index, events, game_indexes = fixture_module.fixture(root)
    # Known synthetic RECORD wire layout from the maintained native encoder.
    # No geometry, history replay or rules helper is executed.
    raw_input = struct.pack("<4BQQ2f", 0, 80, 10, 10, 0, 0, 3 / 80, 4 / 80)
    h = hashlib.sha256(raw_input).digest()
    (root / "geometry.bin").write_bytes(raw_input + struct.pack("<bBI", 1, 0, 0) + h)
    index["input_geometry_SHA256"] = h.hex()
    rc = fixture_module.content(root / "rows.jsonl.gz", fixture_module.encode(index) + b"\n")
    m["compressed_metadata"]["rows.jsonl.gz"] = rc
    rebind(root, m)
    return m


def terminal_ports():
    env, sentinel = fixture_module.terminal_ports()
    env.update(
        ExitStack=ExitStack,
        common_cache_config=common.common_cache_config,
        dual_teacher_targets=common.dual_teacher_targets,
        iter_common_cache_rows=common.iter_common_cache_rows,
        common_row_metadata=common.common_row_metadata,
    )
    tree = ast.parse(gzip.decompress((ROOT / "terminal_cache-post.py.gz").read_bytes()))
    body = [
        x
        for x in tree.body
        if isinstance(x, (ast.ClassDef, ast.FunctionDef))
        and x.name in {"TerminalRows", "TerminalCorpus", "validate_terminal_metadata"}
    ]
    exec(compile(ast.Module(body=body, type_ignores=[]), "terminal_cache-post.py.gz", "exec"), env)
    return env, sentinel


class A:
    """Tiny labelled vector port; never imports NumPy/Torch or evaluates a model."""

    def __init__(self, data):
        self.data = data.data if isinstance(data, A) else data

    def __len__(self):
        return len(self.data)

    def __iter__(self):
        return iter(self.data)

    def __getitem__(self, key):
        if isinstance(key, tuple):
            rows, col = key
            return A([r[col] for r in self.data[rows]])
        if isinstance(key, slice):
            return A(self.data[key])
        if isinstance(key, A):
            key = key.data
        if isinstance(key, list):
            return (
                A([self.data[i] for i in range(len(self.data)) if key[i]])
                if key and type(key[0]) is bool
                else A([self.data[i] for i in key])
            )
        return self.data[key]

    def __setitem__(self, key, value):
        if isinstance(key, A):
            key = key.data
        for i in key:
            self.data[i] = value

    def astype(self, dtype):
        return self

    def sum(self, dtype=None):
        return sum(self.data)

    def all(self):
        return all(self.data)

    def op(self, other, fun):
        other = other.data if isinstance(other, A) else other
        if isinstance(self.data, list):
            return (
                A([fun(a, b) for a, b in zip(self.data, other)])
                if isinstance(other, list)
                else A([fun(a, other) for a in self.data])
            )
        return (
            A([fun(self.data, b) for b in other])
            if isinstance(other, list)
            else A(fun(self.data, other))
        )

    def __radd__(self, other):
        return self.__add__(other)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __rsub__(self, other):
        return self.op(other, lambda a, b: b - a)

    def __add__(self, other):
        return self.op(other, lambda a, b: a + b)

    def __sub__(self, other):
        return self.op(other, lambda a, b: a - b)

    def __mul__(self, other):
        return self.op(other, lambda a, b: a * b)

    def __truediv__(self, other):
        return self.op(other, lambda a, b: a / b)

    def __pow__(self, other):
        return self.op(other, lambda a, b: a**b)

    def __gt__(self, other):
        return self.op(other, lambda a, b: a > b)

    def __ge__(self, other):
        return self.op(other, lambda a, b: a >= b)

    def __eq__(self, other):
        return self.op(other, lambda a, b: a == b)


class F(float):
    def astype(self, dtype):
        return float(self)


def fake_numpy():
    np = types.ModuleType("numpy")
    np.float32 = F
    np.float64 = np.int64 = np.int8 = np.bool_ = float
    np.zeros = lambda n, dtype=None: A([0] * n)
    np.asarray = lambda a, dtype=None: A(a)
    np.mean = lambda a: sum(a.data) / len(a)
    np.unique = lambda a: sorted(set(a.data))
    np.isfinite = lambda a: A([math.isfinite(v) for v in a.data])
    np.abs = lambda a: A([abs(v) for v in a.data])
    np.count_nonzero = lambda a: sum(bool(v) for v in a.data)
    np.tanh = lambda a: A([math.tanh(v) for v in a.data])

    def add_at(out, groups, values):
        values = values.data if isinstance(values, A) else [values] * len(groups)
        for i, value in zip(groups.data, values):
            out.data[i] += value

    np.add = types.SimpleNamespace(at=add_at)
    return np


class RepairTests(unittest.TestCase):
    def test_R1_selected_settings_bind_each_normalized_recipe_before_assets(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            selected = recipe()
            settings = copy.deepcopy(selected)
            settings["training"].pop("target")
            plan = {"next_learning_study": {"common_learner_settings": settings}}
            plan_path = root / "plan.json"
            binding = root / "binding.json"
            real_bytes = common.bound_file_bytes

            class AssetEntry(Exception):
                pass

            def no_asset(ref, limit):
                if ref.get("sha256") == common.BEST43_DESCRIPTOR:
                    raise AssetEntry("selected settings proved before model/framework/cache arrays")
                return real_bytes(ref, limit)

            common.bound_file_bytes = no_asset
            try:

                def run(cfg, selected_settings):
                    plan["next_learning_study"]["common_learner_settings"] = selected_settings
                    write_json(plan_path, plan)
                    refs = []
                    for teacher in ("z", "completed_root_raw"):
                        x = copy.deepcopy(cfg)
                        x["training"]["target"] = teacher
                        p = root / (teacher + ".json")
                        write_json(p, x)
                        refs.append(file_ref(p))
                    write_json(
                        binding,
                        {
                            "paired_fit_configs": refs,
                            "selected_plan": {"path": str(plan_path), "sha256": sha(plan_path)},
                        },
                    )
                    common.warmstart_inputs(
                        cfg, cache=root, config_path=refs[0]["path"], input_binding=binding
                    )

                with self.assertRaises(AssetEntry):
                    run(selected, settings)
                for section, key, value in [
                    ("training", "batch_size", 512),
                    ("optimizer", "lr", 3e-4),
                    ("training", "warmup_steps", 10),
                    ("training", "seed", 999),
                    ("training", "reflection_probability", 0.5),
                    ("training", "steps", 250),
                    ("evaluation", "early_stopping_patience", 9),
                ]:
                    cfg = copy.deepcopy(selected)
                    cfg[section][key] = value
                    with self.assertRaisesRegex(ValueError, "canonical selected settings"):
                        run(cfg, settings)
                for malformed in (None, {}, {k: v for k, v in settings.items() if k != "limits"}):
                    with self.assertRaises(ValueError):
                        run(selected, malformed)
                bad = copy.deepcopy(settings)
                bad["optimizer"]["lr"] = float("nan")
                with self.assertRaises(ValueError):
                    run(selected, bad)
                bad = copy.deepcopy(settings)
                bad["training"]["target"] = "z"
                with self.assertRaises(ValueError):
                    run(selected, bad)
                bad = copy.deepcopy(settings)
                bad["evaluation"].pop("batch_size")
                with self.assertRaises(ValueError):
                    run(selected, bad)
            finally:
                common.bound_file_bytes = real_bytes

    def test_R2_all_binary_correspondence_before_fake_array_entry(self):
        env, sentinel = terminal_ports()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            m = binary_fixture(root)
            with self.assertRaises(sentinel):
                env["TerminalCorpus"](root)
            cases = [
                ("geometry.bin", 0, 1),
                ("geometry.bin", 20, 1),
                ("geometry.bin", 28, 0),
                ("geometry.bin", 29, 1),
                ("geometry.bin", 30, 1),
                ("geometry.bin", 34, 1),
                ("distance-steps.u8", 0, 4),
                ("terminal-margin.f32", 3, 0),
                ("labels.f32", 3, 0),
                ("labels.f32", 7, 0),
                ("completed-root-raw.f32", 3, 0),
                ("common-eligible.u8", 0, 0),
            ]
            for name, pos, value in cases:
                before = (root / name).read_bytes()
                changed = bytearray(before)
                changed[pos] = value
                self.assertNotEqual(bytes(changed), before)
                (root / name).write_bytes(changed)
                rebind(root, m)
                with self.assertRaises(ValueError):
                    env["TerminalCorpus"](root)
                (root / name).write_bytes(before)
                rebind(root, m)
            for name in m["files"]:
                if name.endswith(".gz"):
                    continue
                before = (root / name).read_bytes()
                (root / name).write_bytes(before + b"x")
                rebind(root, m)
                with self.assertRaises(ValueError):
                    env["TerminalCorpus"](root)
                (root / name).write_bytes(before)
                rebind(root, m)
            with self.assertRaises(sentinel):
                env["TerminalCorpus"](root)

    def test_C1_T_only_mapped_constants_and_each_teacher_guides_reach_views(self):
        np = fake_numpy()
        tree = ast.parse(gzip.decompress((ROOT / "train-post.py.gz").read_bytes()))
        train = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "train")
        metric = next(
            n
            for n in tree.body
            if isinstance(n, ast.FunctionDef) and n.name == "compact_measurements"
        )
        block = next(
            n
            for n in train.body
            if isinstance(n, ast.If)
            and any(
                isinstance(q, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == "dual_constants" for t in q.targets)
                for q in n.body
            )
        )

        class Corpus:
            families = ["T", "V"]
            groups = A([0, 0, 1, 1])
            common_teacher_mapping = {"teacher_B_scale": 0.5}
            labels = A([[0.5, 1, 4, 0.5], [1, -1, 4, 2], [0, 0, 0, 1], [-1, 1, -4, -1]])

            def metadata(self, ix):
                return (
                    A([[0.1, 0.2] for _ in ix]),
                    self.labels[ix],
                    A([0 for _ in ix]),
                    A([0 for _ in ix]),
                )

        corpus = Corpus()
        env = {"np": np, "warm_admission": {}, "corpus": corpus, "ix_train": A([0, 1])}
        exec(compile(ast.Module(body=[block], type_ignores=[]), "T-only constants", "exec"), env)
        self.assertEqual(env["dual_constants"], {"z": 0, "completed_root_raw": 0.625})
        fn_env = {"math": math}
        old_np = sys.modules.get("numpy")
        sys.modules["numpy"] = np
        try:
            exec(
                compile(ast.Module(body=[metric], type_ignores=[]), "compact_measurements", "exec"),
                fn_env,
            )

            def metrics(ix):
                return fn_env["compact_measurements"](
                    corpus,
                    A(ix),
                    A([0.2, -0.3]),
                    0,
                    {"a": 0, "b": 8},
                    A([0, 1]),
                    column=1,
                    dual=True,
                    dual_constants=env["dual_constants"],
                )

            parts = {"train": metrics([0, 1]), "validation": metrics([2, 3])}
            for scope, indices in [("train", [0, 1]), ("validation", [2, 3])]:
                for teacher, col, scale in [("z", 1, 1), ("completed_root_raw", 3, 0.5)]:
                    targets = [corpus.labels.data[i][col] * scale for i in indices]
                    constant = env["dual_constants"][teacher]
                    self.assertAlmostEqual(
                        parts[scope][teacher + "_constant_mse"],
                        sum((constant - x) ** 2 for x in targets) / 2,
                    )
                    self.assertAlmostEqual(
                        parts[scope][teacher + "_distance_mse"],
                        sum((math.tanh(0.8) - x) ** 2 for x in targets) / 2,
                    )
                    self.assertEqual(parts[scope][teacher + "_T_only_constant"], constant)
            persist = next(
                n
                for n in train.body
                if isinstance(n, ast.FunctionDef) and n.name == "persist_curves"
            )
            views = []
            plot = types.ModuleType("repair_ports.plotting")
            plot.render_learning_curves = lambda values, path, **kw: views.append(
                (path.name, values)
            )
            sys.modules[plot.__name__] = plot
            pe = {
                "__package__": "repair_ports",
                "time": types.SimpleNamespace(monotonic=lambda: 0),
                "persisted_curve_counts": {"curves": 1, "diagnostic-curves": 0},
                "curve": [{**parts, "step": 0}],
                "diagnostic_curve": [],
                "warm_admission": {},
                "output": Path("/synthetic-output-not-written"),
                "best_step": 0,
                "target": "z",
                "phase_seconds": {"logging": 0},
            }
            exec(compile(ast.Module(body=[persist], type_ignores=[]), "persist_curves", "exec"), pe)
            pe["persist_curves"]()
            self.assertEqual(len(views), 2)
            for name, records in views:
                teacher = name.removesuffix("-curves.svg")
                for scope in ("train", "validation"):
                    for key in (
                        "constant_mse",
                        "constant_game_equal_mse",
                        "distance_mse",
                        "distance_group_equal_mse",
                    ):
                        self.assertEqual(records[0][scope][key], parts[scope][teacher + "_" + key])
                self.assertEqual(records[0]["used_for_selection"], teacher == "z")
                if teacher != "z":
                    self.assertEqual(
                        records[0]["validation_scope"], "full_held_family_not_selector"
                    )
        finally:
            if old_np is None:
                sys.modules.pop("numpy", None)
            else:
                sys.modules["numpy"] = old_np


if __name__ == "__main__":
    unittest.main()
