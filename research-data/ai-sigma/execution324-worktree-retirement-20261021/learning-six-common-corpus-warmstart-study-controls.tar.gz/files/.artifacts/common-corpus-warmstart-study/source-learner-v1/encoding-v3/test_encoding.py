"""New NN0 gzip reader scope. Synthetic records/stdlib encoder, not producer admission."""

import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("encoding_common", ROOT / "common.py")
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)


def reference(path):
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": "0644",
    }


class EncodingTests(unittest.TestCase):
    def test_lossless_content_bits_order_limits_and_corrupt_partial(self):
        # This is ONLY a labelled byte-port fixture, not a cache or numerical result.
        rows = [
            {
                "id": "synthetic-zero",
                "raw": -0.0,
                "raw_bits": 0x80000000,
                "mask": 0,
                "history": [["stock0-turn1-wallA", 2]],
                "primary": {"type": "SyntheticError", "message": "original"},
                "secondary": [],
            },
            {
                "id": "synthetic-terminal",
                "raw": 2.0,
                "raw_bits": 0x40000000,
                "mask": 1,
                "history": [["stock1-turn2-wallB", 1]],
                "UNKNOWN": None,
                "secondary": [{"stage": "finalize", "message": "retained"}],
            },
        ]
        original = b"".join(json.dumps(r, separators=(",", ":")).encode() + b"\n" for r in rows)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "detail.jsonl.gz"
            # stdlib streaming write, not a second maintained publisher implementation.
            with path.open("wb") as output:
                with gzip.GzipFile(fileobj=output, mode="wb", mtime=0) as stream:
                    for first in range(0, len(original), 11):
                        stream.write(original[first : first + 11])
            bound = reference(path)
            kwargs = {
                "raw_sha256": hashlib.sha256(original).hexdigest(),
                "raw_bytes": len(original),
                "records": 2,
                "max_line_B": 1024,
            }

            def consume(ref=bound, options=kwargs):
                return list(common.iter_compressed_jsonl(ref, **options))

            actual = consume()
            self.assertEqual(b"".join(line for _, line in actual), original)
            self.assertEqual([offset for offset, _ in actual], [0, len(actual[0][1])])
            decoded = [json.loads(line) for _, line in actual]
            self.assertEqual(decoded, rows)
            for row in decoded:
                self.assertEqual(
                    struct.unpack("<I", struct.pack("<f", row["raw"]))[0], row["raw_bits"]
                )
            self.assertEqual(decoded[0]["primary"], rows[0]["primary"])
            self.assertEqual(decoded[1]["secondary"], rows[1]["secondary"])
            for key, value in (
                ("raw_sha256", "0" * 64),
                ("raw_bytes", len(original) - 1),
                ("records", 1),
                ("records", 3),
                ("max_line_B", 8),
            ):
                options = {**kwargs, key: value}
                with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                    consume(options=options)
            for key, value in (
                ("sha256", "f" * 64),
                ("bytes", bound["bytes"] + 1),
                ("mode", "0600"),
            ):
                with self.subTest(key=key), self.assertRaises(ValueError):
                    consume({**bound, key: value})
            target = root / "other.gz"
            target.symlink_to(path)
            with self.assertRaises(ValueError):
                consume({**bound, "path": str(target)})
            canonical = path.read_bytes()
            for variant in (
                canonical[:-1],
                canonical[:-8],
                b"not gzip",
                canonical[:-8] + b"\0" * 8,
            ):
                path.write_bytes(variant)
                with (
                    self.subTest(variant=len(variant)),
                    self.assertRaises((ValueError, OSError, EOFError)),
                ):
                    consume(reference(path))
            # A valid gzip with a torn JSONL tail also refuses, despite available prefix.
            torn = original[:-1]
            path.write_bytes(gzip.compress(torn, mtime=0))
            options = {
                **kwargs,
                "raw_bytes": len(torn),
                "raw_sha256": hashlib.sha256(torn).hexdigest(),
            }
            iterator = common.iter_compressed_jsonl(reference(path), **options)
            first = next(iterator)
            self.assertEqual(first, actual[0])
            with self.assertRaises(ValueError):
                list(iterator)
            # Prefix availability is retained by caller, never sufficient for full admission.
            self.assertEqual(json.loads(first[1])["primary"], rows[0]["primary"])
            reversed_content = b"".join(line for _, line in reversed(actual))
            path.write_bytes(gzip.compress(reversed_content, mtime=0))
            with self.assertRaises(ValueError):
                consume(reference(path))
            changed = copy.deepcopy(rows)
            changed[1]["raw_bits"] = 0
            changed_content = b"".join(
                json.dumps(r, separators=(",", ":")).encode() + b"\n" for r in changed
            )
            path.write_bytes(gzip.compress(changed_content, mtime=0))
            with self.assertRaises(ValueError):
                consume(reference(path))
            # Empty gzip is valid only with the exact empty raw/count identity.
            path.write_bytes(gzip.compress(b"", mtime=0))
            self.assertEqual(
                consume(
                    reference(path),
                    {
                        "raw_sha256": hashlib.sha256(b"").hexdigest(),
                        "raw_bytes": 0,
                        "records": 0,
                        "max_line_B": 1024,
                    },
                ),
                [],
            )


if __name__ == "__main__":
    unittest.main()
