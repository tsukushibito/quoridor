"""Study-specific NN0 ports: synthetic metadata/arrays only, no Torch/native model calls."""

import copy
import hashlib
import importlib
import json
import os
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest

ROOT = Path(__file__).resolve().parent
package = types.ModuleType("warmstart_port")
package.__path__ = [
    str(ROOT / "changed/python/quoridor_training"),
    "/workspaces/quoridor/python/quoridor_training",
]
sys.modules["warmstart_port"] = package
common = importlib.import_module("warmstart_port.common")
trainer = importlib.import_module("warmstart_port.train")


def row(value=0.25, side=1, reason="goal"):
    # Labels/contexts are deliberately synthetic; no legality/geometry proof is claimed.
    rules = "research-standard-2p-threefold-goal-first-v1"
    history = [["SYNTHETIC full-state-key", 1]]
    winner = 1 if reason == "goal" else None
    z = (
        None
        if reason == "unknown"
        else (0 if reason == "threefold" else (1 if side == winner else -1))
    )
    return {
        "id": "synthetic-row",
        "side": side,
        "prefix": [0],
        "ply": 1,
        "group": "synthetic-family",
        "split": "train",
        "primary_eligible": reason != "unknown",
        "research_ruleset": rules,
        "action": 1,
        "state_key": history[0][0],
        "history_key": hashlib.sha256(
            json.dumps([rules, history], separators=(",", ":")).encode()
        ).hexdigest(),
        "z": z,
        "terminal_targets": {
            "outcome_z": z,
            "provenance": {
                "reason": reason,
                "winner": winner,
                "ruleset": rules,
                "final_prefix": [0, 1],
            },
        },
        "stream_evidence": {
            "game_record_sha256": "b" * 64,
            "search": {
                "raw_value": value,
                "raw_value_bits": struct.unpack("<I", struct.pack("<f", value))[0],
                "completed_depth": 6,
                "accepted": True,
                "failure": None,
                "stop": "depth_cap",
                "action": 1,
                "pv": [1],
                "parent": {
                    "stm": side - 1,
                    "ply": 1,
                    "ruleset": rules,
                    "history": history,
                    "state_key": history[0][0],
                },
            },
        },
    }


def selected_synthetic_config():
    # Complete explicit values are fixture choices, not proposed/approved scientific settings.
    c = copy.deepcopy(common.DEFAULTS)
    c["optimizer"].update(betas=[0.9, 0.999], eps=1e-8)
    c["model"].update(architecture="distance_residual", distance_a=0.0, distance_b=0.0)
    c["training"].update(target="z", sampling="epoch", loss_weighting="row")
    c["evaluation"]["monitor"] = "row"
    c["artifacts"]["mode"] = "native"
    c["experiment"].update(
        study=common.WARMSTART_STUDY,
        main_volume_N=8,
        teacher_mapping="exclude_terminal_scores",
        draw_policy="include",
        warm_start={
            "descriptor": {
                "path": "/synthetic/manifest.json",
                "sha256": common.BEST43_DESCRIPTOR,
                "bytes": 677,
                "mode": "0600",
            },
            "weights": {
                "path": "/synthetic/weights.f32",
                "sha256": common.BEST43_WEIGHTS,
                "bytes": 49284,
                "mode": "0644",
            },
            "evaluator_sha256": common.BEST43_EVALUATOR,
            "optimizer": "fresh",
            "scale": "incumbent",
        },
    )
    return c


class CommonWarmstartTests(unittest.TestCase):
    def test_raw_D6_terminal_choices_outcomes_unknown_and_history_are_common(self):
        for side, z in ((1, 1), (2, -1)):
            facts = common.dual_teacher_targets(
                row(side=side), "exclude_terminal_scores", "include"
            )
            self.assertEqual(facts["z"], z)
            self.assertTrue(facts["eligible"])
            self.assertEqual(facts["raw_score"], 0.25)
        for raw in (-2.0, 2.0):
            r = row(raw)
            excluded = common.dual_teacher_targets(r, "exclude_terminal_scores", "include")
            signed = common.dual_teacher_targets(r, "terminal_sign", "include")
            self.assertFalse(excluded["eligible"])
            self.assertEqual(signed["rootmean"], raw / 2)
            self.assertEqual(signed["raw_score"], raw)
            self.assertTrue(signed["eligible"])
        draw = row(reason="threefold")
        self.assertTrue(common.dual_teacher_targets(draw, "terminal_sign", "include")["eligible"])
        self.assertFalse(common.dual_teacher_targets(draw, "terminal_sign", "exclude")["eligible"])
        self.assertFalse(
            common.dual_teacher_targets(row(reason="unknown"), "terminal_sign", "include")[
                "eligible"
            ]
        )
        partial = row()
        partial["stream_evidence"]["search"]["completed_depth"] = 5
        self.assertFalse(
            common.dual_teacher_targets(partial, "terminal_sign", "include")["eligible"]
        )
        for field, value in (
            ("history_key", "c" * 64),
            ("side", 2),
            ("z", -1),
            ("action", 2),
            ("research_ruleset", "wrong"),
        ):
            r = row()
            r[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                common.dual_teacher_targets(r, "terminal_sign", "include")
        for value in (float("nan"), float("inf"), 1.25, True):
            r = row()
            r["stream_evidence"]["search"]["raw_value"] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                common.dual_teacher_targets(r, "terminal_sign", "include")
        r = row()
        r["stream_evidence"]["search"]["raw_value_bits"] += 1
        with self.assertRaises(ValueError):
            common.dual_teacher_targets(r, "terminal_sign", "include")
        with self.assertRaises(ValueError):
            common.dual_teacher_targets(row(), None, "include")

    def test_selected_recipe_required_and_only_teacher_differs(self):
        with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as directory:
            path = Path(directory) / "config.json"
            selected = selected_synthetic_config()

            def resolve(value):
                path.write_text(json.dumps(value))
                return common.resolve_config(path)

            a = resolve(selected)
            b = copy.deepcopy(selected)
            b["training"]["target"] = "rootmean"
            b = resolve(b)
            a["training"].pop("target")
            b["training"].pop("target")
            self.assertEqual(a, b)
            for section, key in (
                ("optimizer", "lr"),
                ("training", "warmup_steps"),
                ("training", "seed"),
                ("training", "steps"),
                ("limits", "samples"),
            ):
                c = copy.deepcopy(selected)
                del c[section][key]
                with self.subTest(missing=f"{section}.{key}"), self.assertRaises(ValueError):
                    resolve(c)
            for key, value in (
                ("main_volume_N", None),
                ("main_volume_N", True),
                ("teacher_mapping", None),
                ("draw_policy", None),
            ):
                c = copy.deepcopy(selected)
                c["experiment"][key] = value
                with self.subTest(key=key), self.assertRaises(ValueError):
                    resolve(c)
            for key, value in (
                ("optimizer", "resume"),
                ("scale", "new_T"),
                ("evaluator_sha256", "a" * 64),
            ):
                c = copy.deepcopy(selected)
                c["experiment"]["warm_start"][key] = value
                with self.subTest(warm=key), self.assertRaises(ValueError):
                    resolve(c)
            c = copy.deepcopy(selected)
            c["model"]["distance_b"] = 8
            with self.assertRaises(ValueError):
                resolve(c)

    def test_full_cross_teacher_curve_is_readable_without_claiming_selection(self):
        plotting = importlib.import_module("warmstart_port.plotting")
        with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as directory:
            curve = [
                {
                    "step": 0,
                    "training_seen": 0,
                    "row_epoch": 0,
                    "completed_epochs": 0,
                    "train_scope": "full_train",
                    "used_for_selection": False,
                    "validation_scope": "full_held_family_not_selector",
                    "train": {"target_mse": 0.3, "target_game_equal_mse": 0.3},
                    "validation": {"target_mse": 0.4, "target_game_equal_mse": 0.4},
                }
            ]
            output = Path(directory) / "SYNTHETIC-curves.svg"
            plotting.render_learning_curves(
                curve, output, sampling="epoch", title="Synthetic other-teacher curve"
            )
            text = output.read_text()
            self.assertIn("full held-family, not used for selection", text)
            self.assertIn('data-scope="validation_full_not_selector"', text)
            self.assertNotIn('data-scope="validation_diagnostic_subset"', text)
        self.assertNotIn("torch", sys.modules)
        self.assertNotIn("numpy", sys.modules)

    def test_exact_native_codec_and_all_parameter_copy_with_fake_Torch_port(self):
        # Fake Tensor is a six-array copy port only; no inference/optimizer/framework imported.
        class Tensor:
            dtype = "synthetic-FP32"
            device = "synthetic-device"
            requires_grad = True

            def __init__(self, values, shape):
                self.values = list(values)
                self.shape = shape

            def reshape(self, shape):
                self.shape = shape
                return self

            def copy_(self, other):
                self.values = list(other.values)

        class Context:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        torch = types.ModuleType("torch")
        torch.float32 = Tensor.dtype
        torch.no_grad = Context
        torch.tensor = lambda values, **kw: Tensor(values, ())
        state = {
            k: Tensor([-99] * len(v), common.PARAMETER_SHAPES[k])
            for k, v in common.ordered_parameter_values(
                struct.pack("<12321f", *([0.125] * 12321))
            ).items()
        }

        class Model:
            def state_dict(self):
                return state

            def parameters(self):
                return iter(state.values())

        with tempfile.TemporaryDirectory(dir=os.environ["TMPDIR"]) as directory:
            path = Path(directory) / "SYNTHETIC_NOT_MODEL.f32"
            raw = struct.pack("<12321f", *([0.125] * 12321))
            path.write_bytes(raw)
            path.chmod(0o644)
            ref = {
                "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": "0644",
            }
            before = set(sys.modules)
            sys.modules["torch"] = torch
            try:
                trainer.restore_warmstart_parameters(Model(), ref)
            finally:
                del sys.modules["torch"]
            self.assertEqual(before, set(sys.modules))
            self.assertTrue(all(v.values == [0.125] * len(v.values) for v in state.values()))
            self.assertEqual(
                state["out.bias"].values, [0.125]
            )  # Output head was copied, not reset.
            with self.assertRaises(ValueError):
                common.bound_file_bytes({**ref, "sha256": "a" * 64}, 49284)
            with self.assertRaises(ValueError):
                common.bound_file_bytes({**ref, "mode": "0600"}, 49284)
            with self.assertRaises(ValueError):
                common.ordered_parameter_values(raw[:-4])
            with self.assertRaises(ValueError):
                common.ordered_parameter_values(struct.pack("<f", float("nan")) + raw[4:])
        self.assertNotIn("torch", sys.modules)
        self.assertNotIn("numpy", sys.modules)


if __name__ == "__main__":
    unittest.main()
