"""NEW v2 metadata-only integration. Synthetic records/fake array inlet, no geometry."""

import ast
from array import array
import copy
import gzip
import hashlib
import importlib
import json
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest

ROOT = Path(__file__).resolve().parent
package = types.ModuleType("current_encoding")
package.__path__ = [str(ROOT), "/workspaces/quoridor/python/quoridor_training"]
sys.modules[package.__name__] = package
common = importlib.import_module("current_encoding.common")
distance_steps = importlib.import_module("current_encoding.distance_steps")
RULES = "research-standard-2p-threefold-goal-first-v1"


def encode(obj):
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode()


def content(path, raw):
    path.write_bytes(gzip.compress(raw, mtime=0))
    compressed = path.read_bytes()
    return {
        "encoding": "gzip-single-member-v1",
        "compressed": {
            "path": str(path),
            "sha256": hashlib.sha256(compressed).hexdigest(),
            "bytes": len(compressed),
            "mode": "0644",
        },
        "raw_sha256": hashlib.sha256(raw).hexdigest(),
        "raw_bytes": len(raw),
    }


def fixture(root):
    # Exact producer fieldsets; values are fake metadata, not admitted runtime receipts.
    cfg = {
        "selected_plan": {
            "path": "/workspaces/quoridor/research-data/ai-sigma/teacher-distance-tanh-v1/plan.json",
            "sha256": "c" * 64,
        },
        "families": 2,
        "prefix_seed": 1,
        "prefix_lengths": [4],
        "split_seed": 2,
        "root_value_policy": "exclude_outside_unit",
        "draw_policy": "include_threefold",
    }
    pilot = {
        "phase": "common_corpus",
        "main_volume_n": 2,
        "planned_games": 2,
        "common_study": cfg,
        "depth": 6,
        "ruleset": "standard_2p_threefold",
        "distance_a": 0,
        "distance_b": 8,
        "tt_slots": 4096,
        "use_pvs": True,
        "solver_order_contact": False,
        "per_move_timeout_ms": None,
        "max_total_plies": 200,
        "attempts_per_prefix": 32,
        "max_nodes": 100,
    }
    config_file = root / "config.json"
    config_file.write_bytes(encode(pilot))
    config_sha = hashlib.sha256(config_file.read_bytes()).hexdigest()
    partition = {
        "schema": "synthetic-partition-shape",
        "seed": 2,
        "rounding": "synthetic",
        "assignments": [
            {"game": "g0", "prefix": [0], "family": "family0", "split": "train"},
            {"game": "g1", "prefix": [2], "family": "family1", "split": "validation"},
        ],
    }
    partition_sha = hashlib.sha256(encode(partition)).hexdigest()
    header = {
        "schema": "quoridor-fixed-d-common-corpus-v1",
        "generator_version": "fixed-d-common-corpus-warmstart-v1",
        "config": pilot,
        "config_sha256": config_sha,
        "compiled_sources": {"fixture.rs": "d" * 64},
        "evaluator": "original-distance-a0-b8-tanh",
        "executable_sha256": "e" * 64,
        "scheduled": [{"request_id": "g0", "prefix": [0]}, {"request_id": "g1", "prefix": [2]}],
        "family_partition": partition,
        "resource_admission": {"synthetic_fixture": False},
    }
    history = [["synthetic-position", 1]]
    targets = {
        "outcome_z": 1,
        "margin_target_steps": 4,
        "terminal_geometric_margin_steps": 4,
        "current_distance_steps_stm_opponent": [3, 4],
        "provenance": {
            "schema": "quoridor-terminal-teachers-v1",
            "reason": "goal",
            "winner": 1,
            "ruleset": RULES,
            "final_prefix": [0, 1],
            "final_distance_p1_p2": [0, 4],
            "terminal_distance_p1_p2": [0, 4],
        },
    }
    teacher = {
        "id": "row0",
        "game": "g0",
        "family": "family0",
        "split": "train",
        "ply": 1,
        "prefix": [0],
        "state_key": history[0][0],
        "history_key": hashlib.sha256(encode([RULES, history])).hexdigest(),
        "research_ruleset": RULES,
        "ids": [[0], [1]],
        "distance": [3 / 80, 4 / 80],
        "side": 1,
        "action": 1,
        "teacher": {
            "type": "alpha_beta",
            "value": 0.5,
            "depth": 6,
            "nodes": 3,
            "bound": "completed_root",
            "pv": [1],
        },
        "z": 1,
        "terminal_targets": targets,
        "eligible": True,
        "model_sha": "original-distance-a0-b8-tanh",
        "feature_signature": "synthetic",
    }
    search = {
        "action": 1,
        "raw_value": 0.5,
        "raw_value_bits": 0x3F000000,
        "completed_depth": 6,
        "pv": [1],
        "stop": "depth_cap",
        "counters": {"nodes": 3},
        "returned_search_wall_ns": 1,
        "parent": {
            "ruleset": RULES,
            "stm": 0,
            "ply": 1,
            "state_key": history[0][0],
            "history": history,
        },
        "accepted": True,
        "failure": None,
    }
    game = {
        "game": 0,
        "request_id": "g0",
        "family": "family0",
        "initial_prefix": [0],
        "final_prefix": [0, 1],
        "final_context": {"synthetic": True},
        "provenance": targets["provenance"],
        "termination": {"type": "goal"},
        "rows": [{"teacher": teacher, "search": search}],
        "failed_search": None,
        "attempted_search_calls": 1,
        "wall_ns": 3,
    }
    failure = {
        "status": "failed",
        "started": True,
        "reason": "synthetic original error; opaque calls UNKNOWN",
    }
    records = [
        {"type": "requests", "planned": 2},
        {"type": "header", "record": header},
        {
            "type": "game",
            "record": {"index": 0, "result": {"status": "returned", "value": game, "whole_ns": 4}},
        },
        {"type": "game", "record": {"index": 1, "result": failure}},
        {"type": "footer", "record": {"synthetic": "not a scientific PASS"}},
    ]
    lines = [encode(x) + b"\n" for x in records]
    offsets = [sum(map(len, lines[:i])) for i in range(len(lines))]
    index = {
        "metadata_schema": "quoridor-common-corpus-row-index-v2",
        "id": "row0",
        "group": "family0",
        "game": "g0",
        "split": "train",
        "primary_eligible": True,
        "common_eligible": True,
        "completed_root_raw_bits": 0x3F000000,
        "z": 1,
        "teacher_B_target": 0.5,
        "input_geometry_SHA256": "1" * 64,
        "source_record_offset": offsets[2],
        "source_row_index": 0,
        "source_record_sha256": hashlib.sha256(lines[2]).hexdigest(),
    }
    game_indexes = [
        {
            "metadata_schema": "quoridor-common-corpus-game-index-v2",
            **{
                k: game[k]
                for k in (
                    "game",
                    "request_id",
                    "family",
                    "termination",
                    "attempted_search_calls",
                    "wall_ns",
                )
            },
            "source_record_offset": offsets[2],
            "source_record_sha256": index["source_record_sha256"],
            "row_count": 1,
        },
        {
            "metadata_schema": "quoridor-common-corpus-game-index-v2",
            "game": 1,
            "source_record_offset": offsets[3],
            "source_record_sha256": hashlib.sha256(lines[3]).hexdigest(),
            "result": failure,
            "row_count": 0,
        },
    ]
    source = content(root / "pilot-stream.jsonl.gz", b"".join(lines))
    row_content = content(root / "rows.jsonl.gz", encode(index) + b"\n")
    game_content = content(
        root / "stream-games.jsonl.gz", b"".join(encode(g) + b"\n" for g in game_indexes)
    )
    compact = {
        k: header[k]
        for k in (
            "schema",
            "generator_version",
            "config_sha256",
            "compiled_sources",
            "evaluator",
            "executable_sha256",
        )
    }
    compact.update(
        family_partition_sha256=partition_sha,
        planned=2,
        detailed_schedule_history="display text may change",
    )
    m = {
        "schema": "quoridor-common-corpus-terminal-geometry-v2",
        "rows": 1,
        "feature_count": 312,
        "allow_test": False,
        "label_columns": ["rootmean", "z", "terminal_margin", "completed_root_raw"],
        "common_corpus": {
            "config": cfg,
            "common_eligible_rows": 1,
            "planned_families": 2,
            "raw_file": "completed-root-raw.f32",
            "common_mask_file": "common-eligible.u8",
            "teacher_A": "actual_final_z",
            "teacher_B": "explicit_mapping_of_completed_root_raw",
            "rootmean_is_raw": False,
            "same_mask_and_family_partition_for_both": True,
        },
        "source_content": source,
        "source_binding": {
            "path": source["compressed"]["path"],
            "sha256": source["compressed"]["sha256"],
        },
        "dataset_sha": source["compressed"]["sha256"],
        "family_partition_sha256": partition_sha,
        "compressed_metadata": {"rows.jsonl.gz": row_content},
        "stream_intake": {
            "status": "complete",
            "scope": "common-corpus",
            "publication_protocol": "incomplete-marker-last-v1",
            "human_quantity_n": 2,
            "config": {"path": str(config_file), "sha256": config_sha},
            "provenance": {
                "header": compact,
                "requests": None,
                "games_file": {
                    "file": "stream-games.jsonl.gz",
                    "sha256": game_content["compressed"]["sha256"],
                    "content": game_content,
                },
            },
        },
    }
    binaries = {
        "geometry.bin": b"\0" * 66,
        "distance-steps.u8": bytes([3, 4]),
        "terminal-margin.f32": struct.pack("<f", 4),
        "labels.f32": struct.pack("<ff", 0.5, 1),
        "completed-root-raw.f32": struct.pack("<f", 0.5),
        "common-eligible.u8": b"\1",
    }
    for name, data in binaries.items():
        (root / name).write_bytes(data)
    m["files"] = {name: name for name in [*binaries, "rows.jsonl.gz"]}
    m["sha256"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in m["files"]
    }
    (root / "cache.json").write_bytes(encode(m))
    return m, index, records, game_indexes


def terminal_ports():
    # AST imports only the actual classes/terminal metadata validator. The fake array
    # inlet prevents NumPy/geometry execution; neither scientific validation nor
    # affected source/index reconstruction is mocked.
    tree = ast.parse((ROOT / "terminal_cache.py").read_bytes())
    wanted = {"TerminalRows", "TerminalCorpus", "validate_terminal_metadata"}
    selected = ast.Module(
        body=[
            n
            for n in tree.body
            if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in wanted
        ],
        type_ignores=[],
    )

    class ArrayEntry(Exception):
        pass

    class FakeNumpy:
        def memmap(self, *args, **kwargs):
            raise ArrayEntry("actual pre-array boundary reached")

    env = {
        "Sequence": __import__("collections.abc", fromlist=["Sequence"]).Sequence,
        "CompactCorpus": object,
        "Path": Path,
        "array": array,
        "json": json,
        "hashlib": hashlib,
        "struct": struct,
        "gzip": gzip,
        "np": FakeNumpy(),
        "RECORD": "synthetic record port",
        "SCHEMA": "quoridor-terminal-geometry-v1",
        "COMMON_SCHEMA": "quoridor-common-corpus-terminal-geometry-v2",
        "FILES": {
            "geometry.bin",
            "distance-steps.u8",
            "terminal-margin.f32",
            "labels.f32",
            "rows.jsonl",
        },
        "COMMON_FILES": {"completed-root-raw.f32", "common-eligible.u8"},
        "sha": lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest(),
        "require_completed_stream_cache": distance_steps.require_completed_stream_cache,
        "common_cache_config": common.common_cache_config,
        "dual_teacher_targets": common.dual_teacher_targets,
        "iter_common_cache_rows": common.iter_common_cache_rows,
        "common_row_metadata": common.common_row_metadata,
    }
    exec(compile(selected, str(ROOT / "terminal_cache.py"), "exec"), env)
    return env, ArrayEntry


class CurrentEncodingTests(unittest.TestCase):
    def test_single_member_no_trailing_sticky_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            p = root / "one.gz"
            raw = b'{"synthetic":-0.0,"bits":2147483648}\n'
            c = content(p, raw)

            def read(ref):
                return list(
                    common.iter_compressed_jsonl(
                        ref["compressed"],
                        raw_sha256=ref["raw_sha256"],
                        raw_bytes=ref["raw_bytes"],
                        records=1,
                        max_line_B=1024,
                    )
                )

            self.assertEqual(read(c), [(0, raw)])
            first = p.read_bytes()
            for encoded in (
                first + gzip.compress(raw, mtime=0),
                first + b"\0",
                first + b"x",
                first[:-1],
                first[:-8] + b"\0" * 8,
            ):
                p.write_bytes(encoded)
                c["compressed"]["sha256"] = hashlib.sha256(encoded).hexdigest()
                c["compressed"]["bytes"] = len(encoded)
                reader = common.iter_compressed_jsonl(
                    c["compressed"],
                    raw_sha256=c["raw_sha256"],
                    raw_bytes=c["raw_bytes"],
                    records=1,
                    max_line_B=1024,
                )
                with self.assertRaises(ValueError) as original_error:
                    list(reader)
                with self.assertRaises(ValueError) as repeated_error:
                    next(reader)
                self.assertIs(repeated_error.exception, original_error.exception)

    def test_exact_v2_cache_index_to_canonical_row_and_before_arrays(self):
        env, array_entry = terminal_ports()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            m, index, records, game_indexes = fixture(root)
            values = list(common.iter_common_cache_rows(root, m))
            self.assertEqual(len(values), 1)
            offset, actual_index, row = values[0]
            self.assertEqual(actual_index, index)
            self.assertEqual(row["completed_root_raw"], 0.5)
            self.assertTrue(row["common_eligible"])
            self.assertEqual(
                row["terminal_targets"],
                records[2]["record"]["result"]["value"]["rows"][0]["teacher"]["terminal_targets"],
            )
            self.assertEqual(game_indexes[1]["result"], records[3]["record"]["result"])
            self.assertNotIn("attempted_search_calls", game_indexes[1])
            with self.assertRaises(array_entry):
                env["TerminalCorpus"](root)
            corpus = types.SimpleNamespace(
                common=True,
                path=root,
                manifest=m,
                row_count=1,
                row_offsets=[offset],
                source_offsets=[index["source_record_offset"]],
                source_rows=[0],
                source_hashes=[bytes.fromhex(index["source_record_sha256"])],
            )
            lazy = env["TerminalRows"](corpus)[0]
            self.assertEqual(lazy["stream_evidence"]["search"], row["stream_evidence"]["search"])
            self.assertEqual(lazy["prefix"], row["prefix"])
            # Candidate identities/markers never admit a cache or touch the array port.
            for marker in ("intake-incomplete.json", "intake-failure.json", ".intake.partial"):
                (root / marker).write_bytes(b"{}")
                with self.assertRaises(ValueError):
                    env["TerminalCorpus"](root)
                (root / marker).unlink()
            for mutate in (
                lambda v: v.update(schema="quoridor-common-corpus-terminal-geometry-v1"),
                lambda v: v["compressed_metadata"]["rows.jsonl.gz"].update(encoding="gzip-other"),
                lambda v: v["source_content"].update(raw_sha256="0" * 64),
                lambda v: v["stream_intake"]["provenance"]["header"].update(
                    family_partition_sha256="0" * 64
                ),
            ):
                bad = copy.deepcopy(m)
                mutate(bad)
                with self.assertRaises(ValueError):
                    list(common.iter_common_cache_rows(root, bad))
            for key, value in (
                ("source_record_offset", 0),
                ("source_row_index", 1),
                ("source_record_sha256", "0" * 64),
                ("group", "wrong-family"),
                ("split", "validation"),
                ("completed_root_raw_bits", 0),
                ("common_eligible", False),
                ("z", -1),
            ):
                bad = copy.deepcopy(m)
                item = {**index, key: value}
                c = content(root / "rows.jsonl.gz", encode(item) + b"\n")
                bad["compressed_metadata"]["rows.jsonl.gz"] = c
                bad["sha256"]["rows.jsonl.gz"] = c["compressed"]["sha256"]
                with self.subTest(key=key), self.assertRaises(ValueError):
                    list(common.iter_common_cache_rows(root, bad))
            # Restore the row index, then a failed-call ZERO fabrication must refuse.
            restored = content(root / "rows.jsonl.gz", encode(index) + b"\n")
            m["compressed_metadata"]["rows.jsonl.gz"] = restored
            m["sha256"]["rows.jsonl.gz"] = restored["compressed"]["sha256"]
            bad_indexes = copy.deepcopy(game_indexes)
            bad_indexes[1]["attempted_search_calls"] = 0
            c = content(
                root / "stream-games.jsonl.gz", b"".join(encode(x) + b"\n" for x in bad_indexes)
            )
            m["stream_intake"]["provenance"]["games_file"].update(
                sha256=c["compressed"]["sha256"], content=c
            )
            with self.assertRaises(ValueError):
                list(common.iter_common_cache_rows(root, m))


if __name__ == "__main__":
    unittest.main()
