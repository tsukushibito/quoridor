"""Finite NN0 qualification wrapper, existing guardian and canonical serial lifetime only."""

import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, "/workspaces/quoridor/python")


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def allocated(root):
    return sum(p.lstat().st_blocks * 512 for p in [root, *root.rglob("*")])


record = {
    "schema": "research.NN0-affected-qualification.v1",
    "source_only": True,
    "START": stamp(),
    "primary": None,
    "returned_guardian": None,
    "scientific_calls": 0,
    "child_entered": False,
    "peaks": "UNKNOWN",
}
lease = None
try:
    lease = open(
        "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock", "r+"
    )
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert allocated(ROOT.parent) + 8192 + 131072 + 131072 <= 1179648, (
        "owner retained floors plus forward do not fit"
    )
    assert {0, 3} <= os.sched_getaffinity(0), "invocation affinity excludes worker3/guardian0"

    def core(cpu):
        p = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        return ((p / "physical_package_id").read_text(), (p / "core_id").read_text())

    assert core(0) != core(3), "distinct physical cores required"
    peers = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            argv = (entry / "cmdline").read_bytes().split(b"\0")
        except OSError:
            continue
        if argv and Path(os.fsdecode(argv[0])).name in {
            "cargo",
            "rustc",
            "cc1plus",
            "quoridor-runner",
            "chromium",
            "chrome",
        }:
            peers.append(entry.name)
    assert not peers, "named quantitative peer entered: " + str(peers)
    fs = os.statvfs(ROOT)
    assert fs.f_bavail * fs.f_frsize > 1048576, "physical FS"
    os.sched_setaffinity(0, {0})
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    resource.setrlimit(resource.RLIMIT_FSIZE, (65536, 65536))
    from quoridor_training.cycle_process import (
        execute,
        CycleResources,
        available_memory,
        cancellation_signals,
    )

    assert available_memory() >= 512 * 1024**2 + 4 * 1024**3, "physical RAM reserve"
    selected = [
        ROOT / "test_encoding.py",
        ROOT / "common.py",
        Path("/workspaces/quoridor/python/quoridor_training/cycle_process.py"),
        Path("/workspaces/quoridor/python/quoridor_training/snapshot.py"),
    ]
    before = {str(p): sha(p) for p in selected}
    scratch = ROOT / "tiny-TMP"
    scratch.mkdir(exist_ok=False)
    deadline = time.monotonic() + 60
    resources = CycleResources(
        {
            "max_memory_bytes": 512 * 1024**2,
            "host_ram_reserve": 4 * 1024**3,
            "max_output_bytes": 65536,
        },
        scratch,
        deadline,
    )
    env = {
        **os.environ,
        "TMPDIR": str(scratch),
        "PYTHONDONTWRITEBYTECODE": "1",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
    }
    capture_seen = [0]

    def capture(data):
        capture_seen[0] += len(data)
        if capture_seen[0] > 8192:
            raise RuntimeError("new bounded synthetic full capture exceeds8192B; FAILED retained")

    record["child_entered"] = True
    with cancellation_signals():
        returned = execute(
            [
                sys.executable,
                "-B",
                str(ROOT / "test_encoding.py"),
                "EncodingTests.test_lossless_content_bits_order_limits_and_corrupt_partial",
            ],
            ROOT / "NN0-encoding.log",
            deadline,
            cpu_core=3,
            resources=resources,
            cwd=str(ROOT),
            env=env,
            output_sink=capture,
        )
    record["returned_guardian"] = returned
    assert {str(p): sha(p) for p in selected} == before, "source changed"
    assert not list(scratch.iterdir()), "owned TMP remains"
    scratch.rmdir()
    record["source_SHA_before_after"] = before
    record["status"] = "PASS_PORT_SCOPE_ONLY"
except BaseException as error:
    record["status"] = "REFUSED_OR_FAILED"
    record["primary"] = {"type": type(error).__name__, "message": str(error)}
finally:
    record["STOP"] = stamp()
    record["owned_TMP"] = (
        [str(p) for p in (ROOT / "tiny-TMP").glob("*")] if (ROOT / "tiny-TMP").exists() else []
    )
    record["owned_readers"] = []
    record["owned_jobs"] = []
    record["owned_children"] = (
        "UNKNOWN"
        if record["child_entered"] and record["primary"] and record["returned_guardian"] is None
        else []
    )
    if lease is not None:
        fcntl.flock(lease, fcntl.LOCK_UN)
        lease.close()
    text = json.dumps(record, indent=2, allow_nan=False) + "\n"
    assert len(text.encode()) <= 16384, "receipt prepriced bound"
    (ROOT / "NN0-encoding-receipt.json").write_text(text)
    print(json.dumps({k: record[k] for k in ("status", "primary", "START", "STOP")}))
