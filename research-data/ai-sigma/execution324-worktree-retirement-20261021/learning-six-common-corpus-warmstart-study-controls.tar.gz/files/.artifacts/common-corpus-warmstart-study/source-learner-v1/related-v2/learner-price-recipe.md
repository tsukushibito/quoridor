### 362 common-corpus learner alignment and additions

Proposal only. Human N, mapping, draws, recipe and evaluation remain unselected. The old 80/160/320 whole table and terminal-sign proposal remain immutable history. Data-owner options are 32/64/128 families, with balanced prefix lengths 4/8/12/16; provisional T/V 25/7, 51/13, 102/26 and disjoint evaluation 8/16/32 families. Recommend 64, but these are not grants or entry controls.

Recommend `exclude_outside_unit` for both candidates' SAME producer mask, and `include_threefold`. A learns actual final STM z; B learns `completed-root-raw.f32`, never legacy `labels.f32[0]`. Alternative `divide_by_two` divides EVERY B value, including interior values: raw 0.5 becomes 0.25 and raw 2 becomes 1. This retains more rows but compresses the entire B teacher; A uses exactly the same resulting mask. Excluding genuine threefold draws removes real zero outcomes from both fits. Search estimates remain estimates, not terminal truth. Neither policy is selected by this recommendation.

Recommend identical fresh Adam (betas 0.9/0.999, eps 1e-8, weight decay 0), LR 1e-4, batch256, row-weighted epoch supply0, seed36220261011, online LR reflection0.5/seed36220261012, explicit one-epoch warmup, plateau factor0.5/patience2/minLR1e-6. Use full T/V observations at INITIAL and each epoch, strict selected-teacher full-V BEST, early stopping absolute1e-5/relative1e-4/patience10, finite 100-epoch ceiling. Alternative LR3e-5 is more conservative adaptation; 3e-4 risks more forgetting. A 50-epoch ceiling bounds work sooner but may stop before convergence. These are nearby choices, not a sweep or defaults. Human must supply explicit update counts from actual shared eligible T rows and select all fields. Both start from identical BEST43 parameters, incumbent T-only scale, fresh optimizer; no head reset/freeze/new-T normalization. INITIAL/BEST/LAST and readable curves on BOTH teachers are required. Opened V is comparative evidence with selection/shared-family limitations.

Learner-only prospective additional storage (MiB):

| Component                                   | 32 families | 64 families | 128 families | Lifetime                            |
| ------------------------------------------- | ----------: | ----------: | -----------: | ----------------------------------- |
| Two fits: checkpoints/exports/curves/visits |          48 |          72 |          112 | two retained outputs ADD            |
| Framework affected qualification capture    |          16 |          16 |           16 | one retained scope                  |
| Two native candidate qualification captures |          32 |          32 |           32 | 16 per candidate ADD                |
| Fit/qualification TMP                       |         128 |         128 |          128 | serial MAX, never concurrent        |
| Fit failure retention                       |         128 |         128 |          128 | 64 per fit ADD, no retries priced   |
| Fit/qualification controls and cleanup      |          12 |          12 |           12 | three 4MiB retained scopes ADD      |
| **Learner additions**                       |     **364** |     **388** |      **428** | **381681664/406847488/448790528 B** |

Assumptions: at most 200 mainline rows/family, FT32/H32 six-tensor weights49284B; three snapshots/exports per fit, 101 full observations, finite 100 epochs. Worst-case all rows T conservatively gives at most 2500/5000/10000 updates; capture ceiling4096B/update. Per-fit 24/36/56MiB includes that ceiling, row/visit arrays, curves, snapshots, headers and rounding. Caps refuse before growth; they do not guarantee output or completion. 50 epochs halves update work ceiling, not automatically all retained allowances. Future duration, RSS, continuous storage peaks and framework/native completion are UNKNOWN.

Generation/cache/raw/evaluation/target/private, source/Root/review/Git are owned/priced elsewhere and EXCLUDED here. Serial shared target/private custody is not another learner allocation. Installed dependencies are referenced only when actually supported at future entry; incremental download assumed0 conditionally, missing dependencies REFUSE rather than minting a 320MiB allowance. Framework/native qualification needs actual affected cache/array/weight/export equality proof before fit/game entry. Exact masks, partition, SHA files and recipe pair remain required.

Fresh353 measured1020.9682838969165s is a conditional example only: twice that is2041.936567793833s, not a warm-start duration bound. No D3/D6 generation extrapolation here. Global held49996652544B/margin3347456B is NOT fresh headroom; NONE of these learner-heavy additions is issued by source support. Root must combine nonduplicated producer prices and actual settled retention before entry.
