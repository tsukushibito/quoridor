"""NEW producer-shaped NN0 metadata/binary codecs; all states and plans synthetic."""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("common_alignment_port", ROOT / "common.py")
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
RULES = "research-standard-2p-threefold-goal-first-v1"


def row(raw=0.5, mapping="exclude_outside_unit", draw="include_threefold", reason="goal"):
    # Producer field layout, deliberately synthetic history/action/outcome; no geometry audit.
    history = [["synthetic-state", 1]]
    bits = struct.unpack("<I", struct.pack("<f", raw))[0]
    z = {"goal": 1, "threefold": 0, "unknown": None}[reason]
    mapped = raw / 2 if mapping == "divide_by_two" else (raw if abs(raw) <= 1 else None)
    eligible = z is not None and mapped is not None and not (z == 0 and draw == "exclude_threefold")
    return {
        "side": 1,
        "prefix": [0],
        "ply": 1,
        "group": "synthetic-family",
        "split": "train",
        "primary_eligible": z is not None,
        "research_ruleset": RULES,
        "action": 1,
        "state_key": "synthetic-state",
        "history_key": hashlib.sha256(
            json.dumps([RULES, history], separators=(",", ":")).encode()
        ).hexdigest(),
        "z": z,
        "rootmean": 1 if abs(raw) == 2 else raw,
        "model_sha": "original-distance-a0-b8-tanh",
        "search": {
            "type": "alpha_beta",
            "value": raw,
            "depth": 6,
            "bound": "completed_root",
            "nodes": 3,
            "pv": [1],
        },
        "terminal_targets": {
            "outcome_z": z,
            "provenance": {
                "reason": reason,
                "winner": 1 if reason == "goal" else None,
                "ruleset": RULES,
                "final_prefix": [0, 1],
            },
        },
        "stream_evidence": {
            "game_record_sha256": "b" * 64,
            "search": {
                "raw_value": raw,
                "raw_value_bits": bits,
                "completed_depth": 6,
                "accepted": True,
                "failure": None,
                "stop": "depth_cap",
                "action": 1,
                "pv": [1],
                "parent": {
                    "stm": 0,
                    "ply": 1,
                    "ruleset": RULES,
                    "history": history,
                    "state_key": "synthetic-state",
                },
            },
        },
        "completed_root_raw": raw,
        "completed_root_raw_bits": bits,
        "common_eligible": eligible,
        "teacher_B_target": mapped if eligible else None,
        "raw_value_perspective": "root_side_to_move",
        "raw_value_units": "maintained_fixedD_a0b8_tanh_nonterminal_abs1_terminal_abs2",
        "rootmean_semantics": "display may change; legacy terminal converted, never B",
    }


def manifest():
    cfg = {
        "selected_plan": {
            "path": "/workspaces/quoridor/research-data/ai-sigma/teacher-distance-tanh-v1/plan.json",
            "sha256": "c" * 64,
        },
        "families": 32,
        "prefix_seed": 1,
        "prefix_lengths": [4, 8, 12, 16],
        "split_seed": 2,
        "root_value_policy": "exclude_outside_unit",
        "draw_policy": "include_threefold",
    }
    m = {
        "schema": "quoridor-common-corpus-terminal-geometry-v1",
        "rows": 1,
        "common_corpus": {
            "config": cfg,
            "common_eligible_rows": 1,
            "planned_families": 32,
            "raw_file": "completed-root-raw.f32",
            "common_mask_file": "common-eligible.u8",
            "teacher_A": "actual_final_z",
            "teacher_B": "explicit_mapping_of_completed_root_raw",
            "rootmean_is_raw": False,
            "same_mask_and_family_partition_for_both": True,
        },
        "stream_intake": {
            "status": "complete",
            "scope": "common-corpus",
            "publication_protocol": "incomplete-marker-last-v1",
            "human_quantity_n": 32,
            "provenance": {
                "header": {
                    "evaluator": "original-distance-a0-b8-tanh",
                    "config": {
                        "phase": "common_corpus",
                        "depth": 6,
                        "main_volume_n": 32,
                        "planned_games": 32,
                        "common_study": cfg,
                    },
                }
            },
        },
    }
    p = {
        "next_learning_study": {
            "issue": "quoridor-4lc.362",
            "scientific_entry": True,
            "starting_weights_SHA256": common.BEST43_WEIGHTS,
            "descriptor_SHA256": common.BEST43_DESCRIPTOR,
            "typed_evaluator_content_SHA256": common.BEST43_EVALUATOR,
            "corpus": {
                "offtrajectory_rows": 0,
                "quantity_families": 32,
                "blind_schedule": {
                    "version": "fixed-d-common-corpus-warmstart-v1",
                    "prefix_seed": 1,
                    "prefix_lengths": [4, 8, 12, 16],
                    "ordering": "round_robin_lengths",
                    "attempts_per_family": 32,
                    "old_games_included": False,
                },
                "whole_family_T_V_partition": {
                    "algorithm": "canonical_LR_family_SHA256_seed_rank_train_floor_4F_over_5",
                    "seed": 2,
                    "before_outcomes": True,
                },
            },
            "range_terminal_handling": {
                "root_value_policy": "exclude_outside_unit",
                "draw_policy": "include_threefold",
            },
            "common_learner_settings": {"synthetic": "shape-only; not a selected human recipe"},
        }
    }
    return m, p


class AlignmentTests(unittest.TestCase):
    def test_producer_raw_mask_file_domain_and_shared_eligibility(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for mapping in ("exclude_outside_unit", "divide_by_two"):
                for draw in ("include_threefold", "exclude_threefold"):
                    for raw in (0.5, -0.5, 1.5, 2.0, -2.0):
                        for reason in ("goal", "threefold", "unknown"):
                            r = row(raw, mapping, draw, reason)
                            data = struct.pack("<f", raw)
                            mask = bytes([int(r["common_eligible"])])
                            (root / "raw").write_bytes(data)
                            (root / "mask").write_bytes(mask)

                            def read(name):
                                path = root / name
                                return common.bound_file_bytes(
                                    {
                                        "path": str(path),
                                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                                        "bytes": path.stat().st_size,
                                        "mode": "0644",
                                    },
                                    16,
                                )

                            bits = struct.unpack("<I", read("raw"))[0]
                            facts = common.dual_teacher_targets(
                                r, mapping, draw, raw_file_bits=bits, mask_byte=read("mask")[0]
                            )
                            self.assertEqual(facts["eligible"], bool(mask[0]))
                            self.assertEqual(facts["raw_score"], raw)
                            self.assertEqual(facts["completed_root_target"], r["teacher_B_target"])
                            if mapping == "divide_by_two" and reason == "goal":
                                self.assertEqual(facts["completed_root_target"], raw / 2)
                            if abs(raw) == 2:
                                self.assertNotEqual(r["rootmean"], facts["raw_score"])
            r = row()

            def check(value, bits=r["completed_root_raw_bits"], mask=1):
                return common.dual_teacher_targets(
                    value,
                    "exclude_outside_unit",
                    "include_threefold",
                    raw_file_bits=bits,
                    mask_byte=mask,
                )

            check(r)
            for key, value in (
                ("completed_root_raw_bits", 0),
                ("common_eligible", False),
                ("teacher_B_target", 0.1),
                ("model_sha", "other"),
                ("raw_value_units", "logits"),
                ("raw_value_perspective", "player1"),
            ):
                bad = copy.deepcopy(r)
                bad[key] = value
                with self.subTest(key=key), self.assertRaises(ValueError):
                    check(bad)
            for mutate in (
                lambda v: v["stream_evidence"]["search"].update(completed_depth=5),
                lambda v: v["stream_evidence"]["search"]["parent"].update(stm=1),
                lambda v: v["search"].update(value=1.0),
                lambda v: v.update(z=-1),
            ):
                bad = copy.deepcopy(r)
                mutate(bad)
                with self.assertRaises(ValueError):
                    check(bad)
            for bits, mask in (
                (0, 1),
                (r["completed_root_raw_bits"], 0),
                (r["completed_root_raw_bits"], 2),
            ):
                with self.assertRaises(ValueError):
                    check(r, bits, mask)
            path = root / "raw"
            original = path.read_bytes()
            ref = {
                "path": str(path),
                "sha256": hashlib.sha256(original).hexdigest(),
                "bytes": len(original),
                "mode": "0644",
            }
            path.write_bytes(b"xxxx")
            with self.assertRaises(ValueError):
                common.bound_file_bytes(ref, 16)

    def test_exact_selected_common_plan_scope_and_partition(self):
        m, p = manifest()
        cfg = m["common_corpus"]["config"]
        experiment = {
            "main_volume_N": 32,
            "teacher_mapping": "exclude_outside_unit",
            "draw_policy": "include_threefold",
        }
        self.assertEqual(common.common_cache_config(m, experiment, cfg["selected_plan"], p), cfg)
        for mutate in (
            lambda v: v.update(schema="quoridor-terminal-geometry-v1"),
            lambda v: v["stream_intake"].update(scope="full-volume"),
            lambda v: v["stream_intake"].update(status="FAILED"),
            lambda v: v["common_corpus"].update(rootmean_is_raw=True),
            lambda v: v["stream_intake"]["provenance"]["header"]["config"].update(depth=5),
            lambda v: v["common_corpus"]["config"].update(root_value_policy="terminal_sign"),
            lambda v: v["common_corpus"]["config"].update(draw_policy="include"),
        ):
            bad = copy.deepcopy(m)
            mutate(bad)
            with self.assertRaises(ValueError):
                common.common_cache_config(bad, experiment, cfg["selected_plan"], p)
        for mutate in (
            lambda v: v["next_learning_study"].update(scientific_entry=False),
            lambda v: v["next_learning_study"]["corpus"]["whole_family_T_V_partition"].update(
                seed=3
            ),
            lambda v: v["next_learning_study"]["range_terminal_handling"].update(
                root_value_policy="divide_by_two"
            ),
            lambda v: v["next_learning_study"]["corpus"].update(quantity_families=64),
        ):
            bad = copy.deepcopy(p)
            mutate(bad)
            with self.assertRaises(ValueError):
                common.common_cache_config(m, experiment, cfg["selected_plan"], bad)
        wrong = {**cfg["selected_plan"], "sha256": "d" * 64}
        with self.assertRaises(ValueError):
            common.common_cache_config(m, experiment, wrong, p)


if __name__ == "__main__":
    unittest.main()
