"""One new fake-array boundary: native JSON doubles must retain their own f32 bits."""

import ast
from array import array
from collections.abc import Sequence
from contextlib import ExitStack
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor/python/quoridor_training")
package = types.ModuleType("fp32_repair")
package.__path__ = [str(ROOT), str(MAIN)]
sys.modules[package.__name__] = package
spec = importlib.util.spec_from_file_location("fp32_repair.common", ROOT / "common.py")
common = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = common
spec.loader.exec_module(common)
from fp32_repair import distance_steps

spec = importlib.util.spec_from_file_location(
    "frozen_builders_only", ROOT.parent / "test_current_framework.py"
)
builders = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builders)  # Only labelled tiny builders, no old test method.


def bits(value):
    return struct.unpack("<I", struct.pack("<f", value))[0]


def fixture(path, value, search_value, target, declared):
    """Rebind tiny synthetic source and indexes; no actual corpus or admission."""
    manifest = builders.synthetic_cache(path)
    events = [
        json.loads(x)
        for x in gzip.decompress((path / "pilot-stream.jsonl.gz").read_bytes()).splitlines()
    ]
    rows = [
        json.loads(x) for x in gzip.decompress((path / "rows.jsonl.gz").read_bytes()).splitlines()
    ]
    games = [
        json.loads(x)
        for x in gzip.decompress((path / "stream-games.jsonl.gz").read_bytes()).splitlines()
    ]
    offset = i = 0
    for event in events:
        if event["type"] == "game":
            pair = event["record"]["result"]["value"]["rows"][0]
            pair["search"].update(raw_value=value, raw_value_bits=declared)
            pair["teacher"]["teacher"]["value"] = search_value
            pair["teacher"]["z"] = 1.0  # Actual producer float outcome shape.
        raw = builders.encoded(event) + b"\n"
        if event["type"] == "game":
            digest = hashlib.sha256(raw).hexdigest()
            rows[i].update(
                completed_root_raw_bits=declared,
                teacher_B_target=target,
                z=1.0,
                source_record_offset=offset,
                source_record_sha256=digest,
            )
            games[i].update(source_record_offset=offset, source_record_sha256=digest)
            i += 1
        offset += len(raw)
    source = builders.fixture.content(
        path / "pilot-stream.jsonl.gz", b"".join(builders.encoded(x) + b"\n" for x in events)
    )
    row_content = builders.fixture.content(
        path / "rows.jsonl.gz", b"".join(builders.encoded(x) + b"\n" for x in rows)
    )
    game_content = builders.fixture.content(
        path / "stream-games.jsonl.gz", b"".join(builders.encoded(x) + b"\n" for x in games)
    )
    manifest.update(
        dataset_sha=source["compressed"]["sha256"],
        source_content=source,
        source_binding={k: source["compressed"][k] for k in ("path", "sha256")},
    )
    manifest["compressed_metadata"]["rows.jsonl.gz"] = row_content
    manifest["stream_intake"]["provenance"]["games_file"] = {
        "file": "stream-games.jsonl.gz",
        "sha256": game_content["compressed"]["sha256"],
        "content": game_content,
    }
    (path / "completed-root-raw.f32").write_bytes(struct.pack("<2f", value, value))
    (path / "labels.f32").write_bytes(struct.pack("<4f", value, 1.0, value, 1.0))
    manifest["sha256"] = {
        name: hashlib.sha256((path / name).read_bytes()).hexdigest() for name in manifest["files"]
    }
    (path / "cache.json").write_bytes(builders.encoded(manifest))
    return manifest


class ArrayBoundary(Exception):
    pass


class FakeArrays:
    def memmap(self, *args, **kwargs):
        raise ArrayBoundary("all source and binary checks exhausted before arrays")

    def empty(self, *args, **kwargs):
        raise AssertionError("unexpected array allocation")


def loader():
    source = MAIN / "terminal_cache.py"
    wanted = {"TerminalRows", "TerminalCorpus", "validate_terminal_metadata"}
    body = [
        n
        for n in ast.parse(source.read_bytes()).body
        if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in wanted
    ]
    env = {
        "Sequence": Sequence,
        "CompactCorpus": object,
        "Path": Path,
        "array": array,
        "ExitStack": ExitStack,
        "json": json,
        "hashlib": hashlib,
        "struct": struct,
        "gzip": gzip,
        "np": FakeArrays(),
        "RECORD": "fake dtype; arrays never reached",
        "SCHEMA": "quoridor-terminal-geometry-v1",
        "COMMON_SCHEMA": "quoridor-common-corpus-terminal-geometry-v2",
        "FILES": {
            "geometry.bin",
            "distance-steps.u8",
            "terminal-margin.f32",
            "labels.f32",
            "rows.jsonl",
        },
        "COMMON_FILES": {"completed-root-raw.f32", "common-eligible.u8"},
        "sha": lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest(),
        "require_completed_stream_cache": distance_steps.require_completed_stream_cache,
        "common_cache_config": common.common_cache_config,
        "dual_teacher_targets": common.dual_teacher_targets,
        "iter_common_cache_rows": common.iter_common_cache_rows,
        "common_row_metadata": common.common_row_metadata,
    }
    exec(compile(ast.Module(body=body, type_ignores=[]), str(source), "exec"), env)
    return env["TerminalCorpus"]


class FP32JsonTests(unittest.TestCase):
    def test_native_json_bits_metadata_and_first_pass_without_arrays(self):
        corpus = loader()
        compact, expanded, declared = -0.09966802, -0.09966801851987839, 3184271039
        self.assertNotEqual(compact, expanded)
        self.assertEqual(bits(compact), declared)
        cases = [
            ("compact-json", compact, compact, expanded, declared, True),
            ("expanded-json", expanded, expanded, compact, declared, True),
            ("raw-bit-drift", -0.1, compact, expanded, declared, False),
            ("search-bit-drift", compact, -0.1, expanded, declared, False),
            ("index-target-bit-drift", compact, compact, -0.1, declared, False),
            ("declared-bit-drift", compact, compact, expanded, declared ^ 1, False),
            ("negative-zero", -0.0, -0.0, -0.0, 0x80000000, True),
            ("search-zero-sign-drift", -0.0, 0.0, -0.0, 0x80000000, False),
            ("index-zero-sign-drift", -0.0, -0.0, 0.0, 0x80000000, False),
        ]
        with tempfile.TemporaryDirectory() as tmp:
            for name, value, search_value, target, declared, accepts in cases:
                with self.subTest(name=name):
                    path = Path(tmp) / name
                    path.mkdir()
                    manifest = fixture(path, value, search_value, target, declared)
                    before = {
                        p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in path.iterdir()
                    }
                    if accepts:
                        rows = list(common.iter_common_cache_rows(path, manifest))
                        self.assertEqual(len(rows), 2)
                        for _, _, row in rows:
                            for scalar in (
                                row["completed_root_raw"],
                                row["search"]["value"],
                                row["teacher_B_target"],
                                row["rootmean"],
                            ):
                                self.assertEqual(bits(scalar), declared)
                                self.assertEqual(
                                    scalar, struct.unpack("<f", struct.pack("<I", declared))[0]
                                )
                        with self.assertRaises(ArrayBoundary):
                            corpus(path)
                    else:
                        with self.assertRaises(ValueError):
                            corpus(path)
                    self.assertEqual(
                        before,
                        {
                            p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in path.iterdir()
                        },
                    )


if __name__ == "__main__":
    unittest.main()
