"""One new synthetic producer-float boundary; fake array entry, no frameworks."""

import ast
from array import array
from collections.abc import Sequence
from contextlib import ExitStack
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, "/workspaces/quoridor/python")
from quoridor_training import common, distance_steps

ROOT = Path(__file__).resolve().parent
builder_spec = importlib.util.spec_from_file_location(
    "qualified_builders_only", ROOT.parent / "test_current_framework.py"
)
builders = importlib.util.module_from_spec(builder_spec)
builder_spec.loader.exec_module(builders)  # Builders only; no old test is executed.


def producer_float_fixture(path, *, z=1.0, drift=False):
    manifest = builders.synthetic_cache(path)
    events = [
        json.loads(line)
        for line in gzip.decompress((path / "pilot-stream.jsonl.gz").read_bytes()).splitlines()
    ]
    rows = [
        json.loads(line)
        for line in gzip.decompress((path / "rows.jsonl.gz").read_bytes()).splitlines()
    ]
    games = [
        json.loads(line)
        for line in gzip.decompress((path / "stream-games.jsonl.gz").read_bytes()).splitlines()
    ]
    offset, i = 0, 0
    for event in events:
        if event["type"] == "game":
            event["record"]["result"]["value"]["rows"][0]["teacher"]["z"] = z
        raw = builders.encoded(event) + b"\n"
        if event["type"] == "game":
            digest = hashlib.sha256(raw).hexdigest()
            rows[i].update(z=z, source_record_offset=offset, source_record_sha256=digest)
            games[i].update(source_record_offset=offset, source_record_sha256=digest)
            i += 1
        offset += len(raw)
    source = builders.fixture.content(
        path / "pilot-stream.jsonl.gz", b"".join(builders.encoded(x) + b"\n" for x in events)
    )
    row_content = builders.fixture.content(
        path / "rows.jsonl.gz", b"".join(builders.encoded(x) + b"\n" for x in rows)
    )
    game_content = builders.fixture.content(
        path / "stream-games.jsonl.gz", b"".join(builders.encoded(x) + b"\n" for x in games)
    )
    manifest.update(
        dataset_sha=source["compressed"]["sha256"],
        source_content=source,
        source_binding={k: source["compressed"][k] for k in ("path", "sha256")},
    )
    manifest["compressed_metadata"]["rows.jsonl.gz"] = row_content
    manifest["stream_intake"]["provenance"]["games_file"] = {
        "file": "stream-games.jsonl.gz",
        "sha256": game_content["compressed"]["sha256"],
        "content": game_content,
    }
    if drift:
        raw = bytearray((path / "geometry.bin").read_bytes())
        raw[28] = 255  # Signed -1 conflicts with the canonical final-outcome +1.
        (path / "geometry.bin").write_bytes(raw)
    manifest["sha256"] = {
        name: hashlib.sha256((path / name).read_bytes()).hexdigest() for name in manifest["files"]
    }
    (path / "cache.json").write_bytes(builders.encoded(manifest))


class ArrayBoundary(Exception):
    pass


class FakeArrays:
    def memmap(self, *args, **kwargs):
        raise ArrayBoundary("all maintained source/binary checks passed before arrays")

    def empty(self, *args, **kwargs):
        raise AssertionError("unexpected array allocation")


def loader():
    source = ROOT / "terminal_cache.py"
    wanted = {"TerminalRows", "TerminalCorpus", "validate_terminal_metadata"}
    tree = ast.parse(source.read_bytes())
    body = [
        node
        for node in tree.body
        if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in wanted
    ]
    env = {
        "Sequence": Sequence,
        "CompactCorpus": object,
        "Path": Path,
        "array": array,
        "ExitStack": ExitStack,
        "json": json,
        "hashlib": hashlib,
        "struct": struct,
        "gzip": gzip,
        "np": FakeArrays(),
        "RECORD": "synthetic codec only",
        "SCHEMA": "quoridor-terminal-geometry-v1",
        "COMMON_SCHEMA": "quoridor-common-corpus-terminal-geometry-v2",
        "FILES": {
            "geometry.bin",
            "distance-steps.u8",
            "terminal-margin.f32",
            "labels.f32",
            "rows.jsonl",
        },
        "COMMON_FILES": {"completed-root-raw.f32", "common-eligible.u8"},
        "sha": lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest(),
        "require_completed_stream_cache": distance_steps.require_completed_stream_cache,
        "common_cache_config": common.common_cache_config,
        "dual_teacher_targets": common.dual_teacher_targets,
        "iter_common_cache_rows": common.iter_common_cache_rows,
        "common_row_metadata": common.common_row_metadata,
    }
    exec(compile(ast.Module(body=body, type_ignores=[]), str(source), "exec"), env)
    return env["TerminalCorpus"]


class ZByteCodecTests(unittest.TestCase):
    def test_actual_producer_float_z_before_arrays_and_same_hash_bound_refusals(self):
        corpus = loader()
        with tempfile.TemporaryDirectory() as tmp:
            for name, z, drift, expected in [
                ("float-outcome", 1.0, False, ArrayBoundary),
                ("invalid-fraction", 0.5, False, ValueError),
                ("refreshed-binary-drift", 1.0, True, ValueError),
            ]:
                with self.subTest(name=name):
                    path = Path(tmp) / name
                    path.mkdir()
                    producer_float_fixture(path, z=z, drift=drift)
                    with self.assertRaises(expected):
                        corpus(path)


if __name__ == "__main__":
    unittest.main()
