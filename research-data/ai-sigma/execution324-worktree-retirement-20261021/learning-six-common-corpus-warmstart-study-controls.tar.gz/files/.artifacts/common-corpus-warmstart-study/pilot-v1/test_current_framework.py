"""Affected pilot software tests only: synthetic records and no model forward or fit."""

import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, "/workspaces/quoridor/python")
ROOT = Path(__file__).resolve().parent
FIXTURE = ROOT.parent / "source-learner-v1/encoding-related-v4/test_current_encoding.py"
spec = importlib.util.spec_from_file_location("old_fixture_helpers", FIXTURE)
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)  # Only builders; none of its old unittest scopes execute.


def encoded(value):
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode()


def synthetic_cache(path):
    """Tiny publisher-shaped codec input; fake histories/image identities are NOT science."""
    m, old_index, events, indexes = fixture.fixture(path)
    second = copy.deepcopy(events[2])
    game = second["record"]["result"]["value"]
    second["record"]["index"] = 1
    game.update(game=1, request_id="g1", family="family1", initial_prefix=[2], final_prefix=[2, 1])
    teacher = game["rows"][0]["teacher"]
    teacher.update(id="row1", game="g1", family="family1", split="validation", prefix=[2])
    teacher["terminal_targets"]["provenance"]["final_prefix"] = [2, 1]
    events[3] = second
    row_indexes, game_indexes, records, distances, labels, margins, raw_scores, masks = (
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
    )
    offset = 0
    for event in events:
        if event["type"] == "game":
            value = event["record"]["result"]["value"]
            teacher = value["rows"][0]["teacher"]
            # Exact maintained RECORD bytes, one synthetic native two-view input.
            teacher["ids"] = [[0, 161, 300, 311], [0, 161, 300, 311]]
            raw_input = struct.pack("<4BQQ2f", 0, 80, 10, 10, 0, 0, 3 / 80, 4 / 80)
            input_hash = hashlib.sha256(raw_input).digest()
            i = event["record"]["index"]
            records.append(raw_input + struct.pack("<bBI", 1, 0, i) + input_hash)
            distances.append(bytes([3, 4]))
            labels.append(struct.pack("<2f", 0.5, 1))
            margins.append(struct.pack("<f", 4))
            raw_scores.append(struct.pack("<f", 0.5))
            masks.append(b"\1")
        raw_line = encoded(event) + b"\n"
        if event["type"] == "game":
            value = event["record"]["result"]["value"]
            teacher = value["rows"][0]["teacher"]
            record_hash = hashlib.sha256(raw_line).hexdigest()
            index = copy.deepcopy(old_index)
            index.update(
                id=teacher["id"],
                group=teacher["family"],
                game=teacher["game"],
                split=teacher["split"],
                input_geometry_SHA256=input_hash.hex(),
                source_record_offset=offset,
                source_record_sha256=record_hash,
            )
            row_indexes.append(index)
            game_indexes.append(
                {
                    "metadata_schema": "quoridor-common-corpus-game-index-v2",
                    "source_record_offset": offset,
                    "source_record_sha256": record_hash,
                    **{
                        k: value[k]
                        for k in (
                            "game",
                            "request_id",
                            "family",
                            "termination",
                            "attempted_search_calls",
                            "wall_ns",
                        )
                    },
                    "row_count": 1,
                }
            )
        offset += len(raw_line)
    source = fixture.content(
        path / "pilot-stream.jsonl.gz", b"".join(encoded(x) + b"\n" for x in events)
    )
    rows = fixture.content(
        path / "rows.jsonl.gz", b"".join(encoded(x) + b"\n" for x in row_indexes)
    )
    games = fixture.content(
        path / "stream-games.jsonl.gz", b"".join(encoded(x) + b"\n" for x in game_indexes)
    )
    m.update(
        rows=2,
        dataset_sha=source["compressed"]["sha256"],
        source_content=source,
        source_binding={
            "path": source["compressed"]["path"],
            "sha256": source["compressed"]["sha256"],
        },
    )
    m["common_corpus"]["common_eligible_rows"] = 2
    m["compressed_metadata"]["rows.jsonl.gz"] = rows
    m["stream_intake"]["provenance"]["games_file"] = {
        "file": "stream-games.jsonl.gz",
        "sha256": games["compressed"]["sha256"],
        "content": games,
    }
    for name, pieces in [
        ("geometry.bin", records),
        ("distance-steps.u8", distances),
        ("labels.f32", labels),
        ("terminal-margin.f32", margins),
        ("completed-root-raw.f32", raw_scores),
        ("common-eligible.u8", masks),
    ]:
        (path / name).write_bytes(b"".join(pieces))
    m["sha256"] = {
        name: hashlib.sha256((path / name).read_bytes()).hexdigest() for name in m["files"]
    }
    (path / "cache.json").write_bytes(encoded(m))
    return m


class CurrentFrameworkTests(unittest.TestCase):
    def test_actual_shared_binary_cache_arrays_preserve_teacher_bits_and_scope(self):
        import numpy as np
        from quoridor_training.terminal_cache import TerminalCorpus

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            m = synthetic_cache(path)
            corpus = TerminalCorpus(path)
            corpus.prepare_common_teachers("exclude_outside_unit", "include_threefold")
            self.assertEqual(corpus.row_count, 2)
            self.assertEqual(corpus.splits.tolist(), [0, 1])
            self.assertEqual(corpus.eligible.tolist(), [True, True])
            self.assertEqual(
                corpus.labels[:, 0].astype("<f4").tobytes(), struct.pack("<2f", 0.5, 0.5)
            )
            self.assertEqual(corpus.labels[:, 1].astype("<f4").tobytes(), struct.pack("<2f", 1, 1))
            self.assertEqual(
                corpus.labels[:, 3].astype("<f4").tobytes(), struct.pack("<2f", 0.5, 0.5)
            )
            x, d, y = corpus.batch(np.array([0, 1], dtype=np.int64))
            self.assertEqual(x.shape, (2, 2, 312))
            self.assertEqual(x.dtype, np.float32)
            self.assertEqual(
                d.astype("<f4").tobytes(), struct.pack("<4f", 3 / 80, 4 / 80, 3 / 80, 4 / 80)
            )
            self.assertEqual([corpus.rows[i]["game"] for i in range(2)], ["g0", "g1"])
            corpus.verify_binding()
            # Both fits read THIS same cache/mask; no per-model copy or scale estimate.
            self.assertEqual(m["common_corpus"]["common_mask_file"], "common-eligible.u8")

    def test_exact_native_warmstart_all_six_tensors_scale_fresh_optimizer_no_forward(self):
        import numpy as np
        import torch
        from quoridor_training.common import (
            resolve_config,
            bound_file_bytes,
            ordered_parameter_values,
        )
        from quoridor_training.scaled_model import validate_statistics
        from quoridor_training import train

        cfg = resolve_config(ROOT / "fit-A.json")
        warm = cfg["experiment"]["warm_start"]
        descriptor = json.loads(bound_file_bytes(warm["descriptor"], 16384))
        raw = bound_file_bytes(warm["weights"], 49284)
        values = ordered_parameter_values(raw)
        stats = validate_statistics(descriptor)
        model = train.build_model(cfg["model"], stats)
        # Forbid every model forward in this qualification; only affected loading/export.
        model.forward = lambda *args, **kw: (_ for _ in ()).throw(
            AssertionError("no extra model forward")
        )
        train.restore_warmstart_parameters(model, warm["weights"])
        self.assertEqual(set(model.state_dict()), set(values))
        self.assertTrue(all(p.requires_grad for p in model.parameters()))
        for name, tensor in model.state_dict().items():
            self.assertEqual(tensor.dtype, torch.float32)
            self.assertEqual(
                tensor.detach().cpu().numpy().astype("<f4").tobytes(),
                np.asarray(values[name], dtype="<f4").tobytes(),
            )
        self.assertEqual(model.mu.detach().tolist(), stats["mu_f32"])
        self.assertEqual(model.sigma.detach().tolist(), stats["sigma_f32"])
        self.assertEqual(model.coefficient.detach().tolist(), [0, 0])
        opts = [
            torch.optim.Adam(
                model.parameters(),
                lr=cfg["optimizer"]["lr"],
                betas=tuple(cfg["optimizer"]["betas"]),
                eps=cfg["optimizer"]["eps"],
                weight_decay=0,
            )
            for _ in range(2)
        ]
        self.assertTrue(all(not opt.state for opt in opts))
        self.assertIsNot(opts[0], opts[1])
        with tempfile.TemporaryDirectory() as tmp:
            export = Path(tmp)
            train.export(model, cfg, stats, {"a": 0, "b": 0}, export)
            self.assertEqual((export / "weights.f32").read_bytes(), raw)
            train.verify_native_parameters(export / "weights.f32", model.state_dict())
            exported = json.loads((export / "manifest.json").read_text())
            for key in (
                "schema",
                "feature",
                "dense_feature_version",
                "mu_f32",
                "sigma_f32",
                "distance_fit",
                "value_perspective",
                "route_mode",
                "route_mu_f32",
                "route_sigma_f32",
            ):
                self.assertEqual(exported[key], descriptor[key])

    def test_real_numpy_both_teacher_guides_and_actual_view_renderer(self):
        import numpy as np
        from quoridor_training import train

        corpus = types.SimpleNamespace(
            families=["T", "V"],
            groups=np.array([0, 0, 1, 1]),
            common_teacher_mapping={"teacher_B_scale": 1},
        )
        labels = np.array(
            [[0.5, 1, 4, 0.5], [-0.5, -1, -4, -0.5], [0.25, 0, 0, 0.25], [0.75, 1, 4, 0.75]],
            dtype=np.float32,
        )
        corpus.metadata = lambda ix: (
            np.asarray([[0.1, 0.2]] * len(ix), dtype=np.float32),
            labels[ix],
            np.zeros(len(ix), np.int8),
            np.zeros(len(ix), np.int8),
        )
        tree = ast.parse(Path(train.__file__).read_bytes())
        body = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == "train")
        block = next(
            x
            for x in body.body
            if isinstance(x, ast.If)
            and any(
                isinstance(y, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == "dual_constants" for t in y.targets)
                for y in x.body
            )
        )
        env = {"np": np, "corpus": corpus, "ix_train": np.array([0, 1]), "warm_admission": {}}
        exec(
            compile(
                ast.Module(body=[block], type_ignores=[]), "actual T-only constant block", "exec"
            ),
            env,
        )
        self.assertEqual(env["dual_constants"], {"z": 0, "completed_root_raw": 0})
        metrics = {
            name: train.compact_measurements(
                corpus,
                np.array(ix),
                np.array([0.2, -0.3], np.float32),
                0,
                {"a": 0, "b": 8},
                np.array([0, 1]),
                column=1,
                dual=True,
                dual_constants=env["dual_constants"],
            )
            for name, ix in [("train", [0, 1]), ("validation", [2, 3])]
        }
        persist = next(
            x for x in body.body if isinstance(x, ast.FunctionDef) and x.name == "persist_curves"
        )
        with tempfile.TemporaryDirectory() as tmp:
            env = {
                "__package__": "quoridor_training",
                "time": train.time,
                "output": Path(tmp),
                "curve": [{**metrics, "step": 0}],
                "diagnostic_curve": [],
                "persisted_curve_counts": {"curves": 1, "diagnostic-curves": 0},
                "warm_admission": {},
                "target": "z",
                "best_step": 0,
                "phase_seconds": {"logging": 0},
            }
            exec(
                compile(
                    ast.Module(body=[persist], type_ignores=[]), "actual persist_curves", "exec"
                ),
                env,
            )
            env["persist_curves"]()
            for teacher in ("z", "completed_root_raw"):
                svg = (Path(tmp) / (teacher + "-curves.svg")).read_text()
                self.assertIn('data-kind="distance"', svg)
                self.assertIn('data-kind="constant"', svg)
                self.assertIn("INITIAL is frozen BEST43", svg)
            self.assertNotEqual(
                metrics["validation"]["z_constant_mse"],
                metrics["validation"]["completed_root_raw_constant_mse"],
            )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result", type=Path, required=True)
    args, rest = parser.parse_known_args()
    result = unittest.main(argv=[sys.argv[0], *rest], exit=False).result
    document = {
        "schema": "quoridor.common-corpus-framework-qualification.v1",
        "status": "PASS" if result.wasSuccessful() else "FAILED",
        "tests_run": result.testsRun,
        "failures": [{"test": str(test), "traceback": text} for test, text in result.failures],
        "errors": [{"test": str(test), "traceback": text} for test, text in result.errors],
        "scope": "affected actual arrays/warmstart/export/curve software only; synthetic records",
        "actual_model_forwards": 0,
        "fit_updates": 0,
        "scientific_corpus_qualified": False,
        "runtime_remaining": "parent guardian owns exact directwait/cleanup proof",
    }
    with args.result.open("x") as stream:
        json.dump(document, stream, indent=2, allow_nan=False)
        stream.write("\n")
    sys.exit(0 if result.wasSuccessful() else 1)
