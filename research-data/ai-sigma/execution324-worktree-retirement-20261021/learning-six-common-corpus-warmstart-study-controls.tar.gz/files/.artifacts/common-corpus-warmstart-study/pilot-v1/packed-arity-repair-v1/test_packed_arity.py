"""One affected real-tensor/supply/caller test; synthetic model/data, no scientific fit."""

import argparse
import ast
from copy import deepcopy
from pathlib import Path
import resource
import time
import unittest

resource.setrlimit(resource.RLIMIT_CPU, (20, 20))

import numpy as np  # noqa: E402
import torch  # noqa: E402
from quoridor_training.residual_model import DistanceResidualModel  # noqa: E402
from quoridor_training.sampling import ReflectionBatches  # noqa: E402
from quoridor_training.supply import PackedSupply  # noqa: E402

SOURCE = None


class SyntheticTerminal:
    """Fake two-row payload fill only; no geometry, publication or real corpus."""

    compact = terminal = True

    def __init__(self):
        self.splits = np.array([0, 0], dtype=np.uint8)
        self.labels = np.array([[0.0, 1.0], [0.0, -1.0]], dtype=np.float32)
        self.integer_distances = np.array([[3, 4], [5, 6]], dtype=np.uint8)

    def batch_into(self, index, mask, features, distances, *, records_out, workspace):
        features.fill(0.0)
        distances[:] = self.integer_distances[index].astype(np.float32) / 80
        records_out.fill(0)


def exact_caller(supply, step_score):
    tree = ast.parse(SOURCE.read_bytes())
    train = next(
        node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "train"
    )
    batch = next(
        node for node in train.body if isinstance(node, ast.FunctionDef) and node.name == "batch"
    )
    # Bind the exact maintained nested function to a tiny owner closure. No batch/mock replacement.
    wrapper = ast.parse("""
def owner():
    training_payload = None
    def payload():
        return training_payload
    return batch, payload
""")
    wrapper.body[0].body.insert(1, deepcopy(batch))
    ast.fix_missing_locations(wrapper)
    context = {
        "device": "cpu",
        "torch": torch,
        "time": time,
        "packed_supply": supply,
        "step_score": step_score,
        "epoch_sampler": None,
        "phase_seconds": {"transfer": 0.0},
    }
    exec(compile(wrapper, str(SOURCE), "exec"), context)
    return context["owner"](), context


class PackedArity(unittest.TestCase):
    def test_terminal_packed_args_match_selected_model(self):
        torch.set_num_threads(1)
        # Four subcases are one new method, not a training/old-suite replay.
        for step_score in (False, True):
            for training in (False, True):
                with self.subTest(selected_distance_steps=step_score, training=training):
                    corpus = SyntheticTerminal()
                    reflection = ReflectionBatches(corpus, 0.0, 0)
                    weights = np.array([0.5, 1.5], dtype=np.float32)
                    supply = PackedSupply(reflection, 2, "cpu", weights, 1, workers=0)
                    try:
                        (batch, payload), context = exact_caller(supply, step_score)
                        args = batch(np.array([0, 1]), training=training)
                        self.assertEqual(len(args), 4 if step_score else 3)
                        self.assertEqual(args[0].shape, (2, 2, 312))
                        self.assertEqual(args[1].shape, (2, 2))
                        self.assertTrue(torch.equal(args[2], torch.ones(2, dtype=torch.long)))
                        self.assertIsNotNone(supply.active)  # Caller must retain the supply lease.
                        if training:
                            target, actual_weights = payload()
                            self.assertTrue(torch.equal(target, torch.tensor([1.0, -1.0])))
                            self.assertTrue(torch.equal(actual_weights, torch.tensor([0.5, 1.5])))
                            self.assertEqual(reflection.training_seen, 2)
                        else:
                            self.assertIsNone(payload())
                            self.assertEqual(reflection.training_seen, 0)
                        if step_score:
                            # The four-input dispatch is real; step-model numerical work is not run.
                            self.assertTrue(
                                torch.equal(args[3], torch.tensor([[3.0, 4.0], [5.0, 6.0]]))
                            )
                        else:
                            # Actual selected class/signature, synthetic random parameters and scale.
                            # No BEST43 weights/checkpoint or optimizer is loaded or updated.
                            config = {"transformer_width": 32, "hidden_width": 32, "dropout": 0.0}
                            model = DistanceResidualModel(
                                config,
                                {"mu_f32": [0.0, 0.0], "sigma_f32": [1.0, 1.0]},
                                a=0.0,
                                b=0.0,
                            ).eval()
                            with torch.no_grad():
                                values = model(*args)
                            self.assertEqual(values.shape, (2,))
                            self.assertEqual(values.dtype, torch.float32)
                            self.assertTrue(torch.isfinite(values).all())
                        self.assertGreaterEqual(context["phase_seconds"]["transfer"], 0.0)
                        supply.release()
                        self.assertIsNone(supply.active)
                    finally:
                        supply.close()
                    self.assertTrue(supply.closed and supply.queue.closed)
                    self.assertIsNone(supply.active)
                    self.assertEqual(len(supply.free), 1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    args = parser.parse_args()
    SOURCE = args.source
    unittest.main(argv=["test_packed_arity"], verbosity=2)
