"""One actual compact-cache interoperability entry; no model, fit or fake corpus."""

import builtins
import gzip
import json
from pathlib import Path
import resource
from unittest.mock import patch

resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))

import numpy as np  # noqa: E402
from quoridor_training import cache  # noqa: E402
from quoridor_training.sampling import EpochSampler  # noqa: E402
from quoridor_training.supply import ReflectionBatches  # noqa: E402

root = Path("/workspaces/quoridor/.worktree/assets/data/common-corpus-warmstart-study/pilot-v1")
compact = root / "cache-compact-v3"
names = {
    "cache.json",
    "geometry.bin",
    "distance-steps.u8",
    "terminal-margin.f32",
    "labels.f32",
    "completed-root-raw.f32",
    "common-eligible.u8",
    "sampling.bin",
}
seen = set()
original_path_open = Path.open
original_open = builtins.open


def check(path):
    if isinstance(path, (str, bytes, Path)):
        path = Path(path)
        if path.is_relative_to(root):
            if path.parent != compact or path.name not in names:
                raise AssertionError(
                    "detailed canonical/index/history/control read refused: " + str(path)
                )
            seen.add(path.name)


def path_open(path, *args, **kwargs):
    check(path)
    return original_path_open(path, *args, **kwargs)


def file_open(path, *args, **kwargs):
    check(path)
    return original_open(path, *args, **kwargs)


with (
    patch.object(Path, "open", path_open),
    patch.object(builtins, "open", file_open),
    patch.object(gzip, "open", side_effect=AssertionError("detailed gzip read refused")),
):
    corpus = cache.load(compact)
    corpus.prepare_common_teachers("exclude_outside_unit", "include_threefold")
    assert corpus.compact and len(corpus.rows) == 341
    train = np.flatnonzero((corpus.splits == 0) & corpus.eligible)
    validation = np.flatnonzero((corpus.splits == 1) & corpus.eligible)
    assert len(train) == 217 and len(validation) == 76
    assert np.count_nonzero(~corpus.eligible) == 48
    assert all(row["primary_eligible"] for row in corpus.rows)
    assert len(set(corpus.groups[train])) == 6
    assert len(set(corpus.groups[validation])) == 2
    assert not set(corpus.groups[train]) & set(corpus.groups[validation])
    ix = EpochSampler(train, 64, 36220261011).next_batch()
    supply = ReflectionBatches(corpus, 0.5, 36220261012)
    features, distance, labels = supply.batch(ix, training=True)
    assert features.shape == (64, 2, 312) and features.dtype == np.float32
    assert np.isfinite(features).all() and np.isfinite(distance).all()
    assert np.isfinite(labels).all()
    corpus.verify_binding()
    assert seen == names, (seen, names)
print(
    json.dumps(
        {
            "scope": "actual341 compact-only real-array/cache sampling/reflection entry",
            "rows": 341,
            "train": 217,
            "validation": 76,
            "excluded_both": 48,
            "detailed_reads": "deliberately refused",
            "opened_cache_files": sorted(seen),
            "actual_model_forwards": 0,
            "fit_updates": 0,
            "native_Search_games": 0,
            "result": "PASS",
            "old_successful_scopes_replayed": 0,
        }
    )
)
