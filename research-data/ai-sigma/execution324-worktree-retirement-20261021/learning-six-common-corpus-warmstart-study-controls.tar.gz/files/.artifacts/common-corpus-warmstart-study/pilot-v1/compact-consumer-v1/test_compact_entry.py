"""New real-array entry through published v3 binaries; no model/fit/native calls."""

import ast
import builtins
import gzip
import hashlib
import importlib.util
import math
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor/python/quoridor_training")
package = types.ModuleType("compact_consumer")
package.__path__ = [str(ROOT), str(MAIN)]
sys.modules[package.__name__] = package
from compact_consumer import cache, common
from compact_consumer.sampling import EpochSampler, ReflectionBatches
import numpy as np

spec = importlib.util.spec_from_file_location(
    "frozen_tiny_builders_only", ROOT.parent / "test_current_framework.py"
)
builders = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builders)  # No old unittest definition executes.


def fixture(path):
    """Fake lineage, three tiny records; current producer manifest/binary layout."""
    m = builders.synthetic_cache(path)
    m.update(schema="quoridor-common-corpus-terminal-geometry-v3", rows=3)
    m["common_corpus"].update(
        common_eligible_rows=2,
        common_eligible_by_split={"train": 1, "validation": 1},
        sampling_file="sampling.bin",
    )
    for name in ("row_index_file", "source_offset_domain"):
        m["common_corpus"].pop(name, None)
    m["model_scale_authority"] = {
        "selected_plan": m["common_corpus"]["config"]["selected_plan"],
        "starting_weights_sha256": common.BEST43_WEIGHTS,
        "descriptor_sha256": common.BEST43_DESCRIPTOR,
        "evaluator_sha256": common.BEST43_EVALUATOR,
        "scale_policy": "incumbent_descriptor_T_only",
    }
    m["sampling"] = {
        "schema": "quoridor-common-corpus-sampling-v1",
        "file": "sampling.bin",
        "format": "<IBB",
        "width_B": 6,
        "families": [
            {"family": "1" * 64, "game": "g0", "split": "train"},
            {"family": "2" * 64, "game": "g1", "split": "validation"},
        ],
        "row_ids": ["original0", "original1", "original2"],
        "rows_by_family": [2, 1],
        "common_eligible_by_family": [1, 1],
    }
    original = (path / "geometry.bin").read_bytes()[:66]
    records = [
        original[:28] + struct.pack("<bBI", z, 0, i) + original[34:66]
        for i, z in enumerate([1, -1, 1])
    ]
    raw = struct.unpack("<f", struct.pack("<f", -0.09966802))[0]
    files = {
        "geometry.bin": b"".join(records),
        "distance-steps.u8": bytes([3, 4]) * 3,
        "terminal-margin.f32": struct.pack("<3f", 4, -4, 4),
        "labels.f32": struct.pack("<6f", raw, 1, 0.5, -1, 1, 1),
        "completed-root-raw.f32": struct.pack("<3f", raw, 0.5, 2),
        "common-eligible.u8": bytes([1, 1, 0]),
        "sampling.bin": struct.pack("<IBBIBBIBB", 0, 0, 1, 1, 1, 1, 0, 0, 1),
    }
    for name, data in files.items():
        (path / name).write_bytes(data)
    m["files"] = {n: n for n in files}
    m["sha256"] = {n: hashlib.sha256(data).hexdigest() for n, data in files.items()}
    m["file_bytes"] = {n: len(data) for n, data in files.items()}
    # Detailed old indexes remain fake reconstruction files, not current cache inputs.
    m.pop("compressed_metadata", None)
    (path / "cache.json").write_bytes(builders.encoded(m))
    return m


def compact_metrics():
    source = MAIN / "train.py"
    node = next(
        n
        for n in ast.parse(source.read_bytes()).body
        if isinstance(n, ast.FunctionDef) and n.name == "compact_measurements"
    )
    env = {"math": math}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(source), "exec"), env)
    return env["compact_measurements"]


class CompactEntryTests(unittest.TestCase):
    def test_real_arrays_sampling_reflection_and_both_guides_without_detailed_json(self):
        metrics = compact_metrics()
        with tempfile.TemporaryDirectory() as tmp:
            for case in (
                "valid",
                "schema",
                "columns",
                "count",
                "split",
                "census",
                "corrupt-file",
                "partial",
            ):
                with self.subTest(case=case):
                    path = Path(tmp) / case
                    path.mkdir()
                    m = fixture(path)
                    if case == "schema":
                        m["schema"] = "quoridor-common-corpus-terminal-geometry-v2"
                    if case == "columns":
                        m["label_columns"][3] = "legacy-rootmean"
                    if case == "count":
                        m["rows"] = 4
                    if case == "census":
                        m["sampling"]["rows_by_family"] = [1, 2]
                    if case == "split":
                        data = bytearray((path / "sampling.bin").read_bytes())
                        data[4] = 1
                        (path / "sampling.bin").write_bytes(data)
                        m["sha256"]["sampling.bin"] = hashlib.sha256(data).hexdigest()
                    if case == "corrupt-file":
                        data = bytearray((path / "completed-root-raw.f32").read_bytes())
                        data[0] ^= 1
                        (path / "completed-root-raw.f32").write_bytes(data)
                    if case == "partial":
                        (path / "intake-incomplete.json").write_text("original partial publication")
                    (path / "cache.json").write_bytes(builders.encoded(m))
                    denied = {
                        str(path / n)
                        for n in ("pilot-stream.jsonl.gz", "rows.jsonl.gz", "stream-games.jsonl.gz")
                    }
                    denied.add(m["stream_intake"]["config"]["path"])
                    original_path_open = Path.open
                    original_open = builtins.open

                    def path_open(p, *args, **kwargs):
                        if str(p) in denied:
                            raise AssertionError("trainer opened detailed source/control JSON")
                        return original_path_open(p, *args, **kwargs)

                    def file_open(p, *args, **kwargs):
                        if str(p) in denied:
                            raise AssertionError("trainer opened detailed source/control JSON")
                        return original_open(p, *args, **kwargs)

                    with (
                        patch.object(Path, "open", path_open),
                        patch.object(builtins, "open", file_open),
                        patch.object(
                            gzip, "open", side_effect=AssertionError("trainer opened a gzip stream")
                        ),
                    ):
                        if case != "valid":
                            with self.assertRaises((ValueError, KeyError)):
                                cache.load(path)
                            continue
                        corpus = cache.load(path)
                        corpus.prepare_common_teachers("exclude_outside_unit", "include_threefold")
                        self.assertTrue(corpus.compact)
                        self.assertEqual(corpus.groups.tolist(), [0, 1, 0])
                        self.assertEqual(corpus.splits.tolist(), [0, 1, 0])
                        self.assertEqual(corpus.eligible.tolist(), [True, True, False])
                        self.assertTrue(corpus.rows[2]["primary_eligible"])
                        self.assertEqual(
                            [row["id"] for row in corpus.rows], m["sampling"]["row_ids"]
                        )
                        self.assertEqual(
                            corpus.rows[0]["completed_root_raw"],
                            struct.unpack("<f", struct.pack("<I", 3184271039))[0],
                        )
                        self.assertEqual(corpus.rows[1]["outcome_steps"], -80)
                        ix = np.flatnonzero((corpus.splits == 0) & corpus.eligible)
                        self.assertEqual(
                            EpochSampler(ix, 64, 36220261011).next_batch().tolist(), [0]
                        )
                        supply = ReflectionBatches(corpus, 1.0, 36220261012)
                        x, d, y = supply.batch(ix, training=True)
                        self.assertEqual(x.shape, (1, 2, 312))
                        self.assertEqual(x.dtype, np.float32)
                        self.assertEqual(
                            d.astype("<f4").tobytes(), struct.pack("<2f", 3 / 80, 4 / 80)
                        )
                        self.assertEqual(supply.reflected_seen, 1)
                        with self.assertRaises(ValueError):
                            supply.batch(np.array([1]), training=True)
                        constants = {
                            "z": float(corpus.labels[ix, 1].mean(dtype=np.float64)),
                            "completed_root_raw": float(
                                corpus.labels[ix, 3].mean(dtype=np.float64)
                            ),
                        }
                        report = metrics(
                            corpus,
                            np.array([1]),
                            np.array([0.0], dtype=np.float32),
                            constants["z"],
                            {"a": 0, "b": 8},
                            ix,
                            column=1,
                            dual=True,
                            dual_constants=constants,
                        )
                        self.assertEqual(report["z_T_only_constant"], 1.0)
                        self.assertEqual(
                            report["completed_root_raw_T_only_constant"],
                            corpus.rows[0]["completed_root_raw"],
                        )
                        self.assertIn("completed_root_raw_distance_mse", report)
                        corpus.verify_binding()


if __name__ == "__main__":
    unittest.main()
