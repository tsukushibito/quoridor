"""One metadata-only current-recipe/immutable-generation-plan boundary test.

Uses actual selected plan/A/B and compact manifest, real recipe/cache validators.
Only descriptor/weight byte reads are faked, with explicitly synthetic scale.
No baseline asset read, arrays, detailed source, model/framework or fit call.
"""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

MAIN = Path("/workspaces/quoridor")
DATA = MAIN / "research-data/ai-sigma/teacher-distance-tanh-v1"
CACHE = MAIN / ".worktree/assets/data/common-corpus-warmstart-study/pilot-v1/cache-compact-v3"
EXPECTED = {
    DATA / "plan.json": ("9779a274fcd0c7cbb5d46c07f02ee5500eb05bac0d65c7ec30e14002f5be55b9", 52044),
    DATA / "pilot-fit-A-v2.json": (
        "9865c84d97b1dace07dc5e7dcd6cfae162c6c969c3334d2d5a43ca397c85a700",
        2540,
    ),
    DATA / "pilot-fit-B-v2.json": (
        "ad3fbff736a28f4fae03400f8679b15580a777b0fb24d8d49f369c9015aaa63e",
        2557,
    ),
    CACHE / "cache.json": (
        "522b2dd661ff3ddfdb858ca80a9fc5585dfe599cc3039fa9bbfa96f6703bc37d",
        43204,
    ),
}


def read_metadata(path):
    raw = path.read_bytes()
    digest, size = EXPECTED[path]
    assert len(raw) == size and hashlib.sha256(raw).hexdigest() == digest
    assert path.stat().st_mode & 0o777 == 0o644
    return json.loads(raw)


def ref(path):
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), mode="0644")


def dump(path, value):
    path.write_text(json.dumps(value, allow_nan=False) + "\n")
    return ref(path)


def load(source):
    spec = importlib.util.spec_from_file_location("quoridor_training.lineage_repair", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_current_recipe_and_immutable_corpus(source):
    common = load(source)
    plan = read_metadata(DATA / "plan.json")
    configs = [read_metadata(DATA / f"pilot-fit-{teacher}-v2.json") for teacher in ("A", "B")]
    manifest = read_metadata(CACHE / "cache.json")
    assert plan["next_learning_study"]["common_learner_settings"]["limits"]["samples"] == 16023
    assert (
        manifest["common_corpus"]["config"]["selected_plan"]["sha256"]
        == "285e6d9ecded3709d0e23dc8ff45e89184cec053e314d6d2f61fd2e5fc9eeac1"
    )
    warm = configs[0]["experiment"]["warm_start"]
    # Fake metadata matches the fixed descriptor structure, NOT baseline asset bytes.
    descriptor = dict(
        weights_SHA=common.BEST43_WEIGHTS,
        weights_B=49284,
        little_endian_f32=12321,
        schema="quoridor-nnue-distance-residual-v3",
        feature="QF1-route4-f32-STM-scaled-residual-v3",
        dense_feature_version="shortest-dag4-f32-STM-v1",
        topology={"ft_width": 32, "hidden_width": 32},
        distance_fit={"a": 0, "b": 0},
        route_mode="zero4",
        route_mu_f32=[0.0] * 4,
        route_sigma_f32=[1.0] * 4,
        value_perspective="side-to-move",
        value_parameterization="fixed-distance-logit-plus-linear-residual-tanh",
        weights=Path(warm["weights"]["path"]).name,
        mu_f32=[0.0, 0.0],
        sigma_f32=[1.0, 1.0],
    )
    real_bound = common.bound_file_bytes
    asset_reads = []

    def fake_asset_bytes(value, limit):
        if value == warm["descriptor"]:
            asset_reads.append("FAKE descriptor")
            return json.dumps(descriptor).encode()
        if value == warm["weights"]:
            asset_reads.append("FAKE weights; not numerical evidence")
            return b"\0" * 49284
        return real_bound(value, limit)

    cases = []
    with tempfile.TemporaryDirectory(prefix="lineage-", dir=Path(__file__).parent) as tmp:
        tmp = Path(tmp)

        def invoke(p=plan, cs=configs, m=manifest, teacher=0, binding_change=None):
            pref = ref(DATA / "plan.json") if p is plan else dump(tmp / "plan.json", p)
            crefs = [dump(tmp / f"{i}.json", c) for i, c in enumerate(cs)]
            if m is manifest:
                cache = CACHE
                mref = ref(CACHE / "cache.json")
            else:
                cache = tmp
                mref = dump(tmp / "cache.json", m)
            binding = dict(
                paired_fit_configs=crefs,
                selected_plan={"path": pref["path"], "sha256": pref["sha256"]},
                fit_config_sha=crefs[teacher]["sha256"],
                initial_weights_sha=common.BEST43_WEIGHTS,
                warm_start=cs[teacher]["experiment"]["warm_start"],
                cache_manifest_sha=mref["sha256"],
                schedule_sha256=manifest["schedule_sha256"],
                family_partition_sha256=manifest["family_partition_sha256"],
                dataset=manifest["source_binding"],
            )
            if binding_change:
                binding.update(binding_change)
            dump(tmp / "binding.json", binding)
            cfg = common.resolve_config(cs[teacher])
            with patch.object(common, "bound_file_bytes", fake_asset_bytes):
                return common.warmstart_inputs(
                    cfg,
                    cache=cache,
                    config_path=crefs[teacher]["path"],
                    input_binding=tmp / "binding.json",
                )

        def refuse(name, action, message):
            try:
                action()
            except ValueError as error:
                assert message in str(error), (name, str(error))
                cases.append(name)
            else:
                raise AssertionError("accepted incompatible " + name)

        for teacher in (0, 1):
            result = invoke(teacher=teacher)
            assert result["expected"]["selected_plan"]["sha256"] == EXPECTED[DATA / "plan.json"][0]
            assert result["statistics"] == {"mu_f32": [0.0, 0.0], "sigma_f32": [1.0, 1.0]}
            cases.append("current A" if teacher == 0 else "current B")
        # Distinguish the repaired caller from the unchanged validator's explicit raw-plan option.
        refuse(
            "explicit historical raw-plan mismatch",
            lambda: common.common_cache_config(
                manifest,
                configs[0]["experiment"],
                {"path": str(DATA / "plan.json"), "sha256": EXPECTED[DATA / "plan.json"][0]},
                plan,
            ),
            "selected-plan mismatch",
        )
        changes = [
            ("quantity", ("corpus", "quantity_families"), 12),
            ("prefix seed", ("corpus", "blind_schedule", "prefix_seed"), 1),
            ("split seed", ("corpus", "whole_family_T_V_partition", "seed"), 1),
            ("split algorithm", ("corpus", "whole_family_T_V_partition", "algorithm"), "other"),
            ("range", ("range_terminal_handling", "root_value_policy"), "divide_by_two"),
            ("draw", ("range_terminal_handling", "draw_policy"), "exclude_threefold"),
            ("weights", ("starting_weights_SHA256",), "0" * 64),
            ("descriptor", ("descriptor_SHA256",), "0" * 64),
            ("evaluator", ("typed_evaluator_content_SHA256",), "0" * 64),
        ]
        for name, keys, value in changes:
            changed = copy.deepcopy(plan)
            slot = changed["next_learning_study"]
            for key in keys[:-1]:
                slot = slot[key]
            slot[keys[-1]] = value
            refuse(name, lambda changed=changed: invoke(p=changed), "selected human plan")
        changed = copy.deepcopy(manifest)
        changed["model_scale_authority"]["scale_policy"] = "new_T_scale"
        refuse("scale authority", lambda: invoke(m=changed), "model/scale authority")
        changed = copy.deepcopy(configs)
        for cfg in changed:
            cfg["training"]["batch_size"] = 32
        before = len(asset_reads)
        refuse(
            "equal-pair recipe mismatch", lambda: invoke(cs=changed), "canonical selected settings"
        )
        assert len(asset_reads) == before, "recipe refusal must precede fake asset reads"
        refuse(
            "current config raw hash drift",
            lambda: invoke(binding_change={"fit_config_sha": "0" * 64}),
            "actual common corpus",
        )
        refuse(
            "schedule binding drift",
            lambda: invoke(binding_change={"schedule_sha256": "0" * 64}),
            "actual common corpus",
        )
        refuse(
            "partition binding drift",
            lambda: invoke(binding_change={"family_partition_sha256": "0" * 64}),
            "actual common corpus",
        )
    assert not any(name.startswith(("numpy", "torch")) for name in sys.modules)
    for path in EXPECTED:
        read_metadata(path)
    print(
        json.dumps(
            {
                "status": "PASS",
                "definition": "ONE real warmstart_inputs/common_cache_config metadata boundary",
                "cases": cases,
                "count": len(cases),
                "fake": "only baseline descriptor/weight byte hook; synthetic scale; no asset qualification",
                "frameworks_arrays_models_native_fits": 0,
            }
        )
    )


if __name__ == "__main__":
    import resource

    resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    test_current_recipe_and_immutable_corpus(Path(sys.argv[1]))
