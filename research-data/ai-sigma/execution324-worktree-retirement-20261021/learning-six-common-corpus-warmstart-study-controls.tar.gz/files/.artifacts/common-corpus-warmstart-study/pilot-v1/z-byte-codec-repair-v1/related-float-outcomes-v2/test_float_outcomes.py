"""New missing signed/draw/UNKNOWN cases; prior positive-float PASS is reused."""

import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "stopped_z_builders", ROOT.parent / "test_z_byte_codec.py"
)
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)  # Only frozen builders; no predecessor test runs.


def outcome_fixture(path, kind):
    previous.producer_float_fixture(path)
    manifest = json.loads((path / "cache.json").read_bytes())
    events = [
        json.loads(x)
        for x in gzip.decompress((path / "pilot-stream.jsonl.gz").read_bytes()).splitlines()
    ]
    rows = [
        json.loads(x) for x in gzip.decompress((path / "rows.jsonl.gz").read_bytes()).splitlines()
    ]
    games = [
        json.loads(x)
        for x in gzip.decompress((path / "stream-games.jsonl.gz").read_bytes()).splitlines()
    ]
    z = {"negative": -1.0, "draw": 0.0, "unknown": None, "invalid": 0.25}[kind]
    eligible = kind != "unknown"
    reason = {"negative": "goal", "draw": "threefold", "unknown": "unknown", "invalid": "goal"}[
        kind
    ]
    winner = 2 if kind == "negative" else (1 if kind == "invalid" else None)
    final = (
        [4, 0]
        if kind == "negative"
        else ([3, 4] if kind == "draw" else ([0, 4] if kind == "invalid" else None))
    )
    geometric = (
        -4 if kind == "negative" else (1 if kind == "draw" else (4 if kind == "invalid" else None))
    )
    margin = 0 if kind == "draw" else geometric
    offset, i = 0, 0
    for event in events:
        if event["type"] == "game":
            value = event["record"]["result"]["value"]
            teacher = value["rows"][0]["teacher"]
            teacher.update(z=z, eligible=eligible)
            targets = teacher["terminal_targets"]
            targets.update(
                outcome_z=None if z is None else (1 if kind == "invalid" else int(z)),
                margin_target_steps=margin,
                terminal_geometric_margin_steps=geometric,
            )
            targets["provenance"].update(
                reason=reason,
                winner=winner,
                terminal_distance_p1_p2=final,
                final_distance_p1_p2=final if final is not None else [3, 4],
            )
            value["provenance"] = targets["provenance"].copy()
            value["termination"] = {"type": reason}  # Labelled synthetic terminal metadata.
        raw = previous.builders.encoded(event) + b"\n"
        if event["type"] == "game":
            digest = hashlib.sha256(raw).hexdigest()
            rows[i].update(
                z=z,
                primary_eligible=eligible,
                common_eligible=eligible,
                teacher_B_target=0.5 if eligible else None,
                source_record_offset=offset,
                source_record_sha256=digest,
            )
            games[i].update(
                source_record_offset=offset,
                source_record_sha256=digest,
                termination=value["termination"],
            )
            i += 1
        offset += len(raw)
    content = previous.builders.fixture.content
    encoded = previous.builders.encoded
    source = content(path / "pilot-stream.jsonl.gz", b"".join(encoded(x) + b"\n" for x in events))
    row_content = content(path / "rows.jsonl.gz", b"".join(encoded(x) + b"\n" for x in rows))
    game_content = content(
        path / "stream-games.jsonl.gz", b"".join(encoded(x) + b"\n" for x in games)
    )
    manifest.update(
        dataset_sha=source["compressed"]["sha256"],
        source_content=source,
        source_binding={k: source["compressed"][k] for k in ("path", "sha256")},
    )
    manifest["compressed_metadata"]["rows.jsonl.gz"] = row_content
    manifest["stream_intake"]["provenance"]["games_file"] = {
        "file": "stream-games.jsonl.gz",
        "sha256": game_content["compressed"]["sha256"],
        "content": game_content,
    }
    manifest["common_corpus"]["common_eligible_rows"] = 2 if eligible else 0
    records = bytearray((path / "geometry.bin").read_bytes())
    for n in range(2):
        records[n * 66 + 28] = 255 if kind == "negative" else (1 if kind == "invalid" else 0)
    (path / "geometry.bin").write_bytes(records)
    (path / "common-eligible.u8").write_bytes(bytes([int(eligible)]) * 2)
    (path / "labels.f32").write_bytes(struct.pack("<2f", 0.5, float("nan") if z is None else z) * 2)
    (path / "terminal-margin.f32").write_bytes(
        struct.pack("<f", float("nan") if margin is None else margin) * 2
    )
    manifest["sha256"] = {
        name: hashlib.sha256((path / name).read_bytes()).hexdigest() for name in manifest["files"]
    }
    (path / "cache.json").write_bytes(encoded(manifest))


class FloatOutcomeTests(unittest.TestCase):
    def test_new_negative_draw_unknown_and_invalid_before_arrays_preserve_f32(self):
        corpus = previous.loader()
        with tempfile.TemporaryDirectory() as tmp:
            for kind in ["negative", "draw", "unknown", "invalid"]:
                with self.subTest(kind=kind):
                    path = Path(tmp) / kind
                    path.mkdir()
                    outcome_fixture(path, kind)
                    before = {
                        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in path.iterdir()
                        if p.is_file()
                    }
                    with self.assertRaises(
                        ValueError if kind == "invalid" else previous.ArrayBoundary
                    ):
                        corpus(path)
                    self.assertEqual(
                        before,
                        {
                            p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in path.iterdir()
                            if p.is_file()
                        },
                    )


if __name__ == "__main__":
    unittest.main()
