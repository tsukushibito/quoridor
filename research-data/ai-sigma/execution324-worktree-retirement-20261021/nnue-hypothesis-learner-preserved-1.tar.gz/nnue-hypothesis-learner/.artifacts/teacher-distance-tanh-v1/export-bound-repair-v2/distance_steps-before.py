"""Raw-distance-step experiment contract; NN0 import, no implicit dataset/model job."""

import copy
import math
import json
from pathlib import Path

SCORE_SCHEMA = "quoridor-nnue-distance-step-v1"
CONDITIONS = {
    "A": ("outcome_steps", True, "F"),
    "B": ("terminal_margin", True, "F"),
    "C": ("outcome_steps", True, "raw"),
    "D": ("outcome_steps", False, "F"),
}
VIEWS = {
    "A-F": ("A", "F"),
    "A-raw": ("A", "raw"),
    "B-F": ("B", "F"),
    "C-raw": ("C", "raw"),
    "C-F": ("C", "F"),
    "D-F": ("D", "F"),
}


def recipe(condition, main_volume_N=None):
    if condition not in CONDITIONS:
        raise ValueError("explicit A/B/C/D condition required")
    target, bypass, transform = CONDITIONS[condition]
    return {
        "model": {
            "architecture": "distance_steps",
            "distance_bypass": bypass,
            "train_transform": transform,
            "deploy_transform": transform,
            "transformer_width": 32,
            "hidden_width": 32,
            "dropout": 0,
        },
        "optimizer": {"name": "adam", "lr": 0.01, "weight_decay": 0},
        "training": {
            "steps": None,
            "batch_size": 2048,
            "seed": 19080311,
            "target": target,
            "sampling": "epoch",
            "loss_weighting": "row",
            "scheduler": "plateau",
            "warmup_steps": 257,
            "lr_decay_factor": 0.5,
            "lr_decay_patience": 1,
            "min_lr": 1e-6,
            "reflection_probability": 0.5,
            "reflection_seed": 19080314,
            "supply_workers": 2,
        },
        "evaluation": {
            "monitor": "row",
            "early_stopping_patience": 8,
            "early_stopping_unit": "epoch",
            "min_delta": 1e-8,
            "min_delta_relative": 1e-4,
            "full_train": False,
        },
        "limits": {"seconds": None, "samples": None},
        "artifacts": {"mode": "native"},
        "experiment": {
            "condition": condition,
            "main_volume_N": main_volume_N,
            "main_volume_manifest": None,
        },
    }


def require_main_volume(config):
    """Refuse before Torch/corpus/model/optimizer or output creation."""
    if config["model"]["architecture"] != "distance_steps":
        return
    experiment = config["experiment"]
    if (
        type(experiment["main_volume_N"]) is not int
        or experiment["main_volume_N"] <= 0
        or not experiment["main_volume_manifest"]
    ):
        raise ValueError(
            "human full-generation N and frozen main-volume manifest are unset; four fits are not admitted"
        )
    manifest = json.loads(Path(experiment["main_volume_manifest"]).read_text())
    if (
        manifest.get("scope") != "full-volume"
        or manifest.get("human_quantity_N") != experiment["main_volume_N"]
        or manifest.get("planned_games") != experiment["main_volume_N"]
    ):
        raise ValueError(
            "full-volume manifest must bind the explicit human N; pilot is not a fit corpus"
        )


def validate_condition(config):
    c = config["experiment"]["condition"]
    if c not in CONDITIONS:
        raise ValueError("distance-step condition A/B/C/D required")
    target, bypass, transform = CONDITIONS[c]
    if (
        config["training"]["target"],
        config["model"]["distance_bypass"],
        config["model"]["train_transform"],
    ) != (target, bypass, transform):
        raise ValueError("condition teacher/bypass/training transform mismatch")
    if type(config["model"]["distance_bypass"]) is not bool or config["model"][
        "deploy_transform"
    ] not in ("F", "raw"):
        raise ValueError("explicit score view")
    if (
        config["model"]["transformer_width"] != 32
        or config["model"]["hidden_width"] != 32
        or config["model"]["dropout"] != 0
    ):
        raise ValueError("distance-step contract requires FT32/H32/Zero4/dropout0")
    if config["artifacts"]["mode"] != "native":
        raise ValueError(
            "new experiment uses its explicit native score/view export, not an implicit ONNX path"
        )
    # Freeze method now; data/scale/recipe manifest is finalized only after N.
    expected = recipe(c)
    for section in ("optimizer", "training", "evaluation", "limits"):
        for key, value in expected[section].items():
            if section == "training" and key == "warmup_steps":
                if not 0 <= config[section][key] <= 257:
                    raise ValueError("warmup must be min(257, updates_per_epoch)")
                continue
            if config[section][key] != value:
                raise ValueError("common fixed recipe mismatch: " + section + "." + key)


def view_manifest(config, name):
    if name not in VIEWS or VIEWS[name][0] != config["experiment"]["condition"]:
        raise ValueError("view does not belong to this fit")
    result = copy.deepcopy(config)
    result["model"]["deploy_transform"] = VIEWS[name][1]
    return result


def significant_improvement(value, reference, absolute=1e-8, relative=1e-4):
    if not math.isfinite(value) or math.isnan(reference) or reference == -math.inf:
        raise ValueError("nonfinite selector metric")
    return reference == math.inf or value < reference - max(absolute, relative * abs(reference))


def transform_score(score, transform):
    if not math.isfinite(score) or transform not in ("F", "raw"):
        raise ValueError("finite score and explicit output transform required")
    return 80 * math.tanh(score / 80) if transform == "F" else score


def build_model(config, statistics, *, deployed=False):
    """One maintained residual head, fresh initialization; integer bypass is explicit."""
    import torch
    from .residual_model import DistanceResidualModel

    class DistanceStepModel(DistanceResidualModel):
        def forward(self, x, distance, side, integer_distance):
            if integer_distance.ndim != 2 or integer_distance.shape != distance.shape:
                raise ValueError("canonical integer STM/opponent distance shape")
            if (
                not torch.isfinite(integer_distance).all()
                or (integer_distance < 0).any()
                or (integer_distance > 80).any()
                or (integer_distance != integer_distance.round()).any()
            ):
                raise ValueError(
                    "canonical integer wall distance required; no rounded-feature reconstruction"
                )
            _, residual = self.residual_components(x, distance, side)
            score = residual
            if config["distance_bypass"]:
                score = integer_distance[:, 1] - integer_distance[:, 0] + score
            if config["deploy_transform" if deployed else "train_transform"] == "F":
                score = 80 * torch.tanh(score / 80)
            return score

    return DistanceStepModel(config, statistics, a=0, b=1)


def nonterminal_bound(arrays, statistics, bypass):
    """Outward FP32 interval envelope over binary QF1, D in[0,1], Zero4.

    Bounds include FP32 rounding at every positive multiply/add. Refuse overflow
    rather than clipping raw scores. This is deliberately wider than legal sparsity.
    """
    import numpy as np

    ft_w, ft_b, h_w, h_b, out_w, out_b = arrays
    if (
        ft_w.shape != (32, 312)
        or h_w.shape != (32, 70)
        or out_w.shape != (1, 32)
        or ft_b.shape != (32,)
        or h_b.shape != (32,)
        or out_b.shape != (1,)
    ):
        raise ValueError("score bound topology")
    if any(not np.isfinite(a).all() for a in arrays):
        raise ValueError("finite parameters required")

    def up(value):
        if not math.isfinite(value) or value < 0 or value >= np.finfo(np.float32).max:
            raise ValueError("unsafe/unrepresentable raw score bound")
        rounded = (
            0.0 if value == 0 else float(np.nextafter(np.float32(value), np.float32(math.inf)))
        )
        if not math.isfinite(rounded):
            raise ValueError("unsafe/unrepresentable rounded raw score bound")
        return rounded

    def add(a, b):
        return up(float(a) + float(b))

    def mul(a, b):
        return up(float(a) * float(b))

    def dot(weights, bounds, bias):
        result = abs(float(bias))
        for weight, bound in zip(weights, bounds, strict=True):
            result = add(result, mul(abs(float(weight)), bound))
        return result

    ft = [dot(w, [1.0] * 312, b) for w, b in zip(ft_w, ft_b, strict=True)]
    dense = [
        up(add(1, abs(mu)) / sigma)
        for mu, sigma in zip(statistics["mu_f32"], statistics["sigma_f32"], strict=True)
    ]
    inputs = ft + ft + dense + [0.0] * 4
    hidden = [dot(w, inputs, b) for w, b in zip(h_w, h_b, strict=True)]
    residual = dot(out_w[0], hidden, out_b[0])
    return add(80 if bypass else 0, residual)
