# 342.1 export envelope repair SOURCESTOP

Current18-path source map is binding.json; previous eb149854/full17 packet remains immutable. Apply previous learner-maintained.patch then this export-range-only.patch. Only nonterminal_bound and4newNN0 definitions changed. All other distance_steps AST (including build_model, train/F/raw/recipe/N refusal) is equal to prior54f886. train e67f/residual bf8/supply/labels unchanged; no4initialmodel replay, no model/Torch/native/library/build/fit/optimizer/geometry calls.

The old fullencode binary312 norm did not cover inherited200 generaldelta transitions. New exporter uses the stopped native2a46eff0 LegalEnvelope::derive/round_envelope exact counts and positive arithmetic: FT24+48*200 additions*maximum absolute column+bias, outward f64 nextafter norms; fullFP32epsilon2^-23/minimumsubnormal2^-149 growth; finalFP32ceil, dense subtraction/division each1, hidden2*70+16, head2*32+16, bypass80+residual oneoperation. Zero norm stays0. Refuse overflow/nonfinite/>MAX/4 and non-FP32 parameters/scales; no clipping, declared-bound fallback, score or training arithmetic change. Growth cache repeats identical arithmetic once percount only.

Four affected export-envelope NN0 PASS0.072943749s/directwait/remaining[], CPU2/RLIMIT_AS512MiB. Independent highprecision Decimal worst-growth lower bound checks generaldelta envelope; zerohead/bypass/dense/bias/subnormal and invalid/overflow refusals covered. This is source/stdlib+NumPy envelope evidence, NOT executed Rust-loader crosslanguage parity or native model certificate. Existing four synthetic CPU initial output/parameter evidence is reused within its source scope; Nnull/fullgeneration/fits96 remain forbidden.

Native producer source packet d375af594f7ff4403fa6da9438898ca314f0fbd13f614b3f0ce112dc51f2db4b and bound source2a46eff09cdff601bd7a68eee7fe6d69275cc30f522831946fb8b21f347d999a were read by exact SHA only. Learner native-source readerSTOP17:13:33.735657Z/remaining[], no content edits; preserve search342.6 immutabletarget untilactualleaseSTOP. Narrow existing math/score confirmation can consume this stopped producer range source when its lease permits, without new reviewer or old numerical/model suite replay.

Inclusive ownphase+heldcheckout/external+remainingcontrol967520256<2721968128/proof9a4891dd. Oldoriginal2Guppers/nightly557707264/installerUNKNOWN/raw/failures/TMP/fees allheld. No current-nextCargo/model/fairreservation, no idleclock. MinimalDpilot sourcec370/lib6bbed/test35fb and sevenlabelproof remain unchanged/unblocked by this unused NNUE range completion.

DISPLAY: exportの範囲保証を最大200回の一般delta更新と丸め誤差に合わせました。新規4件のNN0検証が合格し、forward・学習数学・旧4出力は変更していません。native loaderでの実行時照合は未実施です。

Exact SOURCESTOP 2026-10-08T17:14:44.570890+00:00
Binding SHA256 5b4f7f7b1588a055b3f073262876f8d102d620ad949ce39291a9425b6e4291bb
Patch SHA256 f7893a17e91d258ccc662f2031ecace9fa10391bcf147c347afdac9db101561b
Distance_steps postSHA 26e34a399859cfa202083f1e0109cfd5959cc70b89e5c5605f0f703b665e589c
