"""One exact initial constructor/serialization; every Module call is refused."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
import time
from unittest.mock import patch

from quoridor_training.snapshot import write_json


EXPECTED = "7dd66213177996ba30a8ec7e729299322c10cc616fba202ae326c7dbc6a63708"
ORDER = ("ft.weight", "ft.bias", "h.weight", "h.bias", "out.weight", "out.bias")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    spec_path = Path(sys.argv[1])
    spec = json.loads(spec_path.read_text())
    root = spec_path.parent
    result = {
        "status": "STARTED",
        "phase": "source_acceptance",
        "constructor_attempted": 0,
        "constructor_returned": 0,
        "parameters_validated": 0,
        "module_calls_refused": 0,
        "forward_calls": 0,
        "optimizer_steps": 0,
        "geometry_calls": 0,
        "primary_error": None,
        "finalization_errors": [],
        "START": datetime.now(timezone.utc).isoformat(),
    }
    start = time.monotonic()
    primary = None
    try:
        for path, expected in spec["refs"].items():
            if sha(path) != expected:
                raise ValueError("fixed source/input/framework/proof changed: " + path)
        native = Path(spec["native_bound_source"]).read_text()
        declaration = native.split("pub struct StepManifest {", 1)[1].split("\n}", 1)[0]
        keys = set(re.findall(r"pub (\w+):", declaration))
        keys.difference_update(("weights_sha", "weights_bytes"))
        keys.update(("weights_SHA", "weights_B"))
        if len(keys) != 25:
            raise ValueError("bound strict StepManifest schema changed")
        log = Path(spec["prior_log"]).read_text()
        for name, value in zip("ABCD", spec["prior_values"], strict=True):
            if f"INITIAL_FORWARD_RETURN {name} {value}" not in log:
                raise ValueError("saved prior return not bound")
        result["phase"] = "framework_import"
        import numpy as np
        import torch

        if torch.__version__ != "2.14.0+cu130":
            raise ValueError("different initialization framework")
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        result["framework"] = {
            "Torch": torch.__version__,
            "device": "CPU",
            "threads": torch.get_num_threads(),
            "interop": torch.get_num_interop_threads(),
        }
        from quoridor_training.common import resolve_config
        from quoridor_training.distance_steps import recipe, build_model, nonterminal_bound, VIEWS
        from quoridor_training.scaled_model import validate_statistics
        from quoridor_training.train import export

        stats = validate_statistics({"mu_f32": [0.1, 0.1], "sigma_f32": [0.05, 0.05]})
        config_path = root / "initial-A-recipe.json"
        write_json(config_path, recipe("A"))
        cfg = resolve_config(config_path)

        def refuse_call(*args, **kwargs):
            result["module_calls_refused"] += 1
            raise AssertionError("all forward/Module calls forbidden in export-only entry")

        original_call = torch.nn.Module._call_impl
        try:
            with patch.object(torch.nn.Module, "_call_impl", refuse_call):
                result["phase"] = "one_initial_constructor"
                torch.manual_seed(19080311)
                result["constructor_attempted"] = 1
                model = build_model(cfg["model"], stats)
                result["constructor_returned"] = 1
                state = model.state_dict()
                if tuple(state) != ORDER:
                    raise ValueError("initial parameter ordering")
                shapes = ((32, 312), (32,), (32, 70), (32,), (1, 32), (1,))
                arrays = []
                for name, shape in zip(ORDER, shapes, strict=True):
                    value = state[name]
                    if value.dtype != torch.float32 or tuple(value.shape) != shape:
                        raise ValueError("initial FP32 parameter shape")
                    array = value.detach().cpu().numpy()
                    if not np.isfinite(array).all():
                        raise ValueError("initial nonfinite parameter")
                    arrays.append(array)
                payload = b"".join(a.astype("<f4").tobytes() for a in arrays)
                result["actual_parameter_SHA256"] = hashlib.sha256(payload).hexdigest()
                if len(payload) != 49284 or result["actual_parameter_SHA256"] != EXPECTED:
                    raise ValueError("same-seed parameter identity refused before serialization")
                if np.count_nonzero(arrays[4]) or np.count_nonzero(arrays[5]):
                    raise ValueError("initial output head not zero")
                if (
                    model.mu.tolist() != stats["mu_f32"]
                    or model.sigma.tolist() != stats["sigma_f32"]
                ):
                    raise ValueError("effective constructor scale mismatch")
                result["parameters_validated"] = 1
                result["phase"] = "accepted_single_weights_export"
                output = root / "payload"
                if output.exists():
                    raise ValueError("new output required; retained assets cannot be overwritten")
                export(model, cfg, stats, {"a": 0, "b": 1}, output)
                if sha(output / "weights.f32") != EXPECTED:
                    raise ValueError("serialized ordered bytes differ")
                base = json.loads((output / "manifest.json").read_text())
                if set(base) != keys:
                    raise ValueError("strict native schema mismatch")
                if base["mu_f32"] != stats["mu_f32"] or base["sigma_f32"] != stats["sigma_f32"]:
                    raise ValueError("serialized effective scale mismatch")
                if base["nonterminal_raw_abs_bound"] != nonterminal_bound(arrays, stats, True):
                    raise ValueError("declared bound mismatch")
                (output / "manifest.json").rename(output / "A-F.manifest.json")
                manifests = {"A-F": sha(output / "A-F.manifest.json")}
                for name, (condition, transform) in VIEWS.items():
                    if name == "A-F":
                        continue
                    item = base.copy()
                    item.update(
                        condition=condition,
                        distance_bypass=condition != "D",
                        train_transform="raw" if condition == "C" else "F",
                        deploy_transform=transform,
                        nonterminal_raw_abs_bound=nonterminal_bound(
                            arrays, stats, condition != "D"
                        ),
                    )
                    if set(item) != keys or item["weights"] != "weights.f32":
                        raise ValueError("shared single-payload view schema")
                    path = output / (name + ".manifest.json")
                    if path.exists():
                        raise ValueError("manifest overwrite refused")
                    write_json(path, item)
                    manifests[name] = sha(path)
                fixture = {
                    "schema": "initial-step-general-synthetic-math-v1",
                    "scope": "GENERAL synthetic mathematical feature IDs, NOT legal geometry",
                    "native_ids": [[], []],
                    "dense_x_shape": [1, 2, 312],
                    "dense_x": "all zero FP32; source-defined, not saved input byte capture",
                    "distance_f32": [
                        struct.unpack("<f", struct.pack("<f", v))[0] for v in (0.1, 0.2)
                    ],
                    "integer_distance": [8, 16],
                    "native_side": 0,
                    "torch_side": 1,
                    "expected_raw_by_condition": {n: 0 if n == "D" else 8 for n in "ABCD"},
                    "expected_raw_scope": "analytic zero-head components, no new Torch observations",
                    "prior_returned_outputs": dict(zip("ABCD", spec["prior_values"], strict=True)),
                    "prior_output_source": spec["prior_log"],
                    "prior_output_SHA256": spec["refs"][spec["prior_log"]],
                    "legal_codec_rows_Torch_predictions": "NOT_SAVED/NOT_RUN; not inherited",
                    "weight_SHA256": EXPECTED,
                    "mu_f32": stats["mu_f32"],
                    "sigma_f32": stats["sigma_f32"],
                }
                write_json(output / "synthetic-reference.json", fixture)
                result["manifests"] = manifests
                result["weights"] = {
                    "path": str(output / "weights.f32"),
                    "SHA256": EXPECTED,
                    "bytes": 49284,
                }
                result["effective_scale"] = stats
        finally:
            result["Module_call_guard_restored"] = torch.nn.Module._call_impl is original_call
        if not result["Module_call_guard_restored"] or result["module_calls_refused"]:
            raise ValueError("forward refusal/guard restoration")
        result["status"] = "PASS"
        result["phase"] = "one_constructor_six_manifests_zero_forward_complete"
    except BaseException as error:
        primary = error
        result["status"] = "FAILED"
        result["primary_error"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        result["STOP"] = datetime.now(timezone.utc).isoformat()
        result["whole_seconds"] = time.monotonic() - start
        try:
            write_json(root / "export-receipt.json", result)
        except BaseException as error:
            result["finalization_errors"].append({"stage": "receipt", "error": repr(error)})
            print(json.dumps(result), flush=True)
            if primary is None:
                primary = error
    if primary:
        raise primary
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
