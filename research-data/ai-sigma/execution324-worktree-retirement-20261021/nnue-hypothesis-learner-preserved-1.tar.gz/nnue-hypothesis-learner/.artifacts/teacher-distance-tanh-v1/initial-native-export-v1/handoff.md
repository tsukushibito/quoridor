# 342.1 one initial export-only reconstruction COMPLETE

Combined actualSTART+STOP (already finished at first state read): job19c16efd-f091-427f-a49d-dc98db75bc1b START2026-10-08T17:38:58.766986Z/workerSTOP17:39:00.500677Z/controllerSTOP17:39:01.337729Z/exit0. Whole2.5711506030056626s; one export child directwait/handles/processcleanup[], child1182355t73433429+guardian1182329t73433389 freshly absent. Finished metadata1182235 distinct; no ongoing-running claim/current-nextCargo-model-fairreservationNONE. Canonical lock lifetime ended. New owned empty TMP root removed only after exacttrue reap/cleanup/emptycensus/freshchild absence; no oldTMP/assets deletion.

ExactlyONE constructor attempted/returned/parametersvalidated, same CPU Torch2.14.0+cu130/thread1/interop1/seed19080311. Ordered parameters matched7dd66213177996ba30a8ec7e729299322c10cc616fba202ae326c7dbc6a63708 BEFORE accepted serialization. Zero-head verified. Module \_call_impl guard rejects every invocation and was restored; modulecallrefusals0/forward0/geometry0/optimizer0/fit0. Original four forwards remain4; no successful model/Torch replay. These are initial representation/serialization facts, NOT native loader/model-parity/trained/strength qualification.

Payload root: /workspaces/quoridor/.worktree/nnue-hypothesis-learner/.artifacts/teacher-distance-tanh-v1/initial-native-export-v1/payload.

Single weights.f3249284B/12321LE-f32 SHA7dd662 as above; SIX strict25field StepManifests A-F,A-raw,B-F,C-raw,C-F,D-F all reference SAMEweights.f32 with identicalbytes/SHA, no four copied payloads. Fullmanifest paths+SHA are in qualified-STOP.json. Bound80.00001525878906 for A/B/C; D0.0. Effective constructor mu=[0.10000000149011612]*2/sigma=[0.05000000074505806]*2; no scale refit or raw .1/.05-as-FP64 reinterpretation. Maintained producer export generated first manifest and scalar-bool/config view substitutions generated the other declared views; strictnative keymap bound to source2a46/d375. Unknown/extra fields refused; no clipping/effectivebound fallback.

synthetic-reference.json freezes GENERAL mathematics metadata: source-defined x=zeros[1,2,312] /native IDs empty both/side1(native0)/dFP32 .1,.2/integer8,16. NOT legal geometry. Saved A/B7.973439693450928/C8/D0 are only priorlog8d5b observed returns; raw8/0 are analytic zero-head components, not new Torch predictions. Newlegalcodec2row inputs remain codec/analytic scope with Torch outputs NOT_SAVED/NOT_RUN. No legal chronology or historical target is forged.

Exact source/framework/input/proof and artifact provenance refs99/wholeguard/sourceSTOP/parameters/payload in qualified-STOP.json, plus export-receipt.json/raw log/process/result. Returned mask/finalpersist completed versus persisted pending/attempted retained separately; no liveIO/fault/all-host certificate. Sampledfamily689201152B incl64MiBcontroller/samplephase967692288B/continuouspeakUNKNOWN. New namespace allocated217088B before collection (<prospective1MiB); heldwhole2721968128 proof9a4891dd/alloriginal2Guppers/externalnightly/installerUNKNOWN/oldfailedfee+raw held. Knownfourcontroller total56.585555508965626s, nestedworker/childspans notadded.

Native342.2 owns strict loader/currentpayload qualification after its fixed math/source conditions; existing342.6 source review target/foreign18sources remain immutable and learnernative reader is STOP. D64pilot independent. Main/Git/index sole324, Nnull/fullgeneration/fits96/323USERPAUSE/seals/default unchanged. Parent342.1 staysin_progress for pilot evidence and later volume pricing, not closed by export.

DISPLAY: 同じ初期パラメータをCPU構築1回で再現し、SHA一致後に単一の重みと6manifestを保存しました。forward追加0、既存4回は再実行していません。一般数学fixtureと合法codecを区別し、native loaderの実行時資格は未認定です。

qualified-STOP.json SHA256 d27e4595c693675dea688c8e5a9ea3cbb2f34ce3c3e2433a08b8970c7b26d4bf
synthetic-reference.json SHA256 f1c8dcb8e84f8535c737fcde9d7bd1631f742e410de1228d594ef240a5133c99
