import ast, builtins, json, pathlib

old_import = builtins.__import__


def guarded(name, *a, **kw):
    if name.split(".")[0] in {"torch", "numpy", "onnxruntime", "ctypes"}:
        raise AssertionError("model/native imports refused")
    return old_import(name, *a, **kw)


builtins.__import__ = guarded
from quoridor_training.scaled_model import validate_statistics

w = pathlib.Path("/workspaces/quoridor/.worktree/nnue-hypothesis-learner")
a = w / ".artifacts/teacher-distance-tanh-v1"
b = a / "initial-scale-fixture-v3"
old = ast.parse((b / "test_distance_steps_model-before.py").read_text())
new = ast.parse((w / "python/quoridor_training/test_distance_steps_model.py").read_text())
assignment = [
    n
    for n in ast.walk(new)
    if isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == "stats" for t in n.targets)
][0]
values = eval(
    compile(ast.Expression(assignment.value), "<actual initial stats assignment>", "eval"),
    {"validate_statistics": validate_statistics},
)
expected = json.loads((a / "initial-native-export-v1/export-receipt.json").read_text())[
    "effective_scale"
]
assert values == expected
assert validate_statistics(values) == values
assert validate_statistics(ast.literal_eval(assignment.value.args[0])) == values
new.body = [
    n for n in new.body if not (isinstance(n, ast.ImportFrom) and n.module == "scaled_model")
]
assignment.value = assignment.value.args[0]
assert ast.dump(old, include_attributes=False) == ast.dump(new, include_attributes=False)
print(
    json.dumps(
        {
            "actual_stats_assignment_PASS": True,
            "effective_scale": values,
            "all_other_AST_equal": True,
            "model_imports_or_calls": 0,
        }
    )
)
