"""One maintained-main typecheck; this control caller lives for this intake only."""

from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import runpy
import sys
import time

from quoridor_training import cycle_process as process


def main():
    guard = json.loads(Path(sys.argv[1]).read_text())
    support = runpy.run_path(guard["qualified_control_source"], run_name="control_ports")
    result = {
        "issue": guard["issue"],
        "status": "PRESTART",
        "commands": [],
        "primary_error": None,
        "finalization_errors": [],
        "scope": "ONE main data-bin check; tests/model/data/fit/science0",
    }
    start = time.monotonic()
    primary = lock = resources = record = None
    tmp_created = False
    try:
        for key, value in guard["compiler_environment"].items():
            if key + "=" + value not in guard["command"]:
                raise ValueError("absolute effective compiler environment")
        result["physics"] = support["validate"](guard)
        lock = open(guard["Cargo_lock"], "a+b")
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        result["physics_after_lock"] = support["validate"](guard)
        for info in Path("/proc").iterdir():
            if not info.name.isdigit():
                continue
            try:
                args = (info / "cmdline").read_bytes().split(b"\0")
            except (FileNotFoundError, ProcessLookupError):
                continue
            if args and Path(os.fsdecode(args[0])).name in {
                "chromium",
                "chrome",
                "firefox",
                "teacher-qualify",
                "teacher-pilot",
            }:
                raise process.CycleStopped("actual named browser/generator competitor")
        for path, expected in guard["source_modes_sizes"].items():
            info = Path(path).stat()
            if info.st_size != expected["bytes"] or info.st_mode & 0o777 != expected["mode"]:
                raise ValueError("immutable main source size/mode")
        if Path(guard["target"]).is_symlink() or not Path(guard["target"]).is_dir():
            raise ValueError("retained exclusive OWN target")
        Path(guard["TMP"]).mkdir(exist_ok=False)
        tmp_created = True

        class MainResources(support["Resources"]):
            def check(self, owned=()):
                super().check(owned)
                current = (
                    support["allocated"](guard["target"])
                    + sum(support["allocated"](path) for path in guard["retained_TMP_paths"])
                    + support["allocated"](guard["TMP"])
                )
                growth = max(0, current - guard["named_target_TMP_current_before_B"])
                inclusive = guard["target_TMP_retained_floor_B"] + growth
                self.sampled["held_floor_plus_observed_growth"] = max(
                    inclusive, self.sampled.get("held_floor_plus_observed_growth", 0)
                )
                if inclusive > guard["effective_target_TMP_forward_upper_B"]:
                    raise process.CycleStopped("held floor plus prospective main check growth")

        resources = MainResources(guard)
        resources.deadline = time.monotonic() + 180
        os.sched_setaffinity(0, {guard["controller_CPU"]})
        result["actualSTART"] = datetime.now(timezone.utc).isoformat()
        result["controller_affinity"] = sorted(os.sched_getaffinity(0))
        result["compiler_affinity"] = [guard["compiler_CPU"]]
        try:
            record = process.execute(
                guard["command"],
                Path(guard["output"]) / "main-data-check.log",
                resources.deadline,
                resources=resources,
            )
        except BaseException:
            try:
                record = json.loads(
                    (Path(guard["output"]) / "main-data-check.process.json").read_text()
                )
                if record["command"] != guard["command"]:
                    raise ValueError("failed command receipt identity")
            except BaseException as error:
                result["finalization_errors"].append(
                    {"stage": "failed receipt", "error": str(error)}
                )
            raise
        result["status"] = "PASS"
    except BaseException as error:
        primary = error
        result["status"] = "FAILED"
        result["primary_error"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        if record is not None:
            result["commands"].append({"name": "main-data-check", "record": record})
        try:
            verified = (
                isinstance(record, dict)
                and record.get("direct_child_reaped") is True
                and record.get("cleanup_complete") is True
                and type(record.get("remaining")) is list
                and record["remaining"] == []
            )
            if tmp_created and verified and not process.alive(record["child"]):
                # Only this fresh, empty owned directory; unexpected files remain retained.
                Path(guard["TMP"]).rmdir()
                result["owned_new_TMP_cleanup"] = "empty directory removed after directwait"
            elif tmp_created:
                result["owned_new_TMP_cleanup"] = "retained; direct cleanup not verified"
        except BaseException as error:
            result["finalization_errors"].append({"stage": "owned new TMP", "error": str(error)})
        try:
            result["source_after_match"] = all(
                support["sha"](path) == sha for path, sha in guard["refs"].items()
            )
            result["source_modes_after_match"] = all(
                Path(path).stat().st_size == v["bytes"]
                and Path(path).stat().st_mode & 0o777 == v["mode"]
                for path, v in guard["source_modes_sizes"].items()
            )
        except BaseException as error:
            result["finalization_errors"].append({"stage": "source after", "error": str(error)})
        if resources:
            result["sampled"] = resources.sampled
        if lock:
            try:
                lock.close()
            except BaseException as error:
                result["finalization_errors"].append(
                    {"stage": "Cargo lock close", "error": str(error)}
                )
        result["actualSTOP"] = datetime.now(timezone.utc).isoformat()
        result["whole_seconds"] = time.monotonic() - start
        result["continuous_peaks"] = "UNKNOWN"
        try:
            process.write_json(Path(guard["output"]) / "receipt.json", result)
        except BaseException as error:
            result["finalization_errors"].append(
                {"stage": "receipt persistence", "error": str(error)}
            )
            if primary is None:
                primary = error
        print(json.dumps(result), flush=True)
    if primary:
        raise primary
    if (
        result["finalization_errors"]
        or not result.get("source_after_match")
        or not result.get("source_modes_after_match")
    ):
        raise RuntimeError("main check finalization/source refusal")


if __name__ == "__main__":
    main()
