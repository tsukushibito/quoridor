"""Finite new-data/source qualification using maintained exact child ownership."""

from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import time
from quoridor_training import cycle_process as process


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def allocated(root):
    total = 0
    pending = [Path(root)]
    while pending:
        path = pending.pop()
        try:
            info = path.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode):
            raise ValueError("owned phase symlink refused")
        total += info.st_blocks * 512
        if stat.S_ISDIR(info.st_mode):
            try:
                pending.extend(path.iterdir())
            except FileNotFoundError:
                continue  # Owned transient vanished after its sampled stat; peak is UNKNOWN.
    return total


def quiet():
    found = []
    for path in Path("/proc").iterdir():
        if not path.name.isdigit():
            continue
        try:
            args = [os.fsdecode(x) for x in (path / "cmdline").read_bytes().split(b"\0") if x]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if not args:
            continue
        name = Path(args[0]).name
        named = name in {
            "cargo",
            "rustc",
            "clippy-driver",
            "perf",
            "quoridor-arena",
            "quoridor-runner",
            "quoridor-research",
        }
        named |= name.startswith(
            ("nnue_search-", "research_baseline-", "feature_delta-", "criterion_bench-")
        )
        named |= any(
            x.startswith(
                (
                    "quoridor_training.train",
                    "quoridor_training.qualification",
                    "quoridor_training.sigma_reference",
                    "quoridor_training.epoch_measurement",
                )
            )
            for x in args
        )
        if named:
            info = process.process_info(int(path.name))
            if info and info["state"] != "Z":
                found.append(process.identity(info))
    return found


class Resources(process.CycleResources):
    def __init__(self, guard):
        super().__init__(guard, guard["phase"], None)
        self.guard = guard
        self.sampled = {
            "family_RSS_with_controller": 0,
            "phase_allocated_with_checkout_reserve": 0,
            "target_TMP_allocated": 0,
        }

    def check(self, owned=()):
        super().check(owned)
        infos = [
            process.process_info(os.getpid()),
            *(process.process_info(x["pid"]) for x in owned),
        ]
        rss = sum(x["rss"] for x in infos if x) + self.guard["controller_reserve_bytes"]
        amount = (
            allocated(self.output)
            + self.guard["checkout_reserve_bytes"]
            + self.guard["external_retained_and_prospective_reserve_bytes"]
        )
        dependency = allocated(self.guard["target"]) + allocated(self.guard["TMP"])
        self.sampled["family_RSS_with_controller"] = max(
            rss, self.sampled["family_RSS_with_controller"]
        )
        self.sampled["phase_allocated_with_checkout_reserve"] = max(
            amount, self.sampled["phase_allocated_with_checkout_reserve"]
        )
        self.sampled["target_TMP_allocated"] = max(dependency, self.sampled["target_TMP_allocated"])
        if (
            rss > self.memory_limit
            or amount > self.guard["whole_bytes"]
            or dependency > self.guard["dependency_TMP_bytes"]
        ):
            raise process.CycleStopped("inclusive family/phase/dependency guard")


def validate(guard):
    if guard.get("entry_ready") is not True:
        raise ValueError("source-preparation only: actual inclusive admission not yet frozen")
    for path, expected in guard["refs"].items():
        if sha(path) != expected:
            raise ValueError("source/proof/compiler binding changed: " + path)
    proof = json.loads(Path(guard["proof"]).read_text())
    original = json.loads(Path(guard["original_proof"]).read_text())
    if (
        proof["learner_future_inclusive_whole_bytes"] != guard["whole_bytes"]
        or proof["learner_original_whole_bytes"] != original["phases"]["learner"]["whole_bytes"]
        or proof["additional_whole_bytes"]
        != guard["external_retained_and_prospective_reserve_bytes"]
        or guard["whole_bytes"]
        != sum(original["phases"]["learner"]["components_bytes"].values())
        + proof["additional_whole_bytes"]
        or proof["all_phases_covered_forward_upper_bytes"] > proof["cap_bytes"]
        or proof["cap_bytes"] != 50000000000
    ):
        raise ValueError("supported original-plus-external inclusive forecast")
    expected_env = guard["compiler_environment"]
    for name, command in guard["commands"]:
        if name in ("Rust-terminal-teachers", "data-scoped-Clippy"):
            if any(key + "=" + value not in command for key, value in expected_env.items()):
                raise ValueError("explicit effective compiler environment")
    if quiet():
        raise process.CycleStopped("actual named compiler/model/fair competitor")
    physical = []
    for cpu in guard["CPU"]:
        topology = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        physical.append(
            (
                (topology / "physical_package_id").read_text().strip(),
                (topology / "core_id").read_text().strip(),
            )
        )
    if len(set(physical)) != len(physical):
        raise ValueError("declared CPUs must be distinct physical cores")
    if not set(guard["CPU"]).issubset(os.sched_getaffinity(0)):
        raise ValueError("CPU availability")
    if process.available_memory() < guard["max_memory_bytes"] + guard["host_ram_reserve"]:
        raise process.CycleStopped("physical RAM")
    if shutil.disk_usage(guard["phase"]).free < guard["whole_bytes"]:
        raise process.CycleStopped("physical filesystem")
    return {
        "CPU": guard["CPU"],
        "physical_cores": physical,
        "MemAvailable": process.available_memory(),
        "filesystem_free": shutil.disk_usage(guard["phase"]).free,
        "named": [],
        "unobserved_work": "UNKNOWN",
    }


def main():
    guard = json.loads(Path(sys.argv[1]).read_text())
    result = {
        "issue": guard["issue"],
        "status": "STARTED",
        "commands": [],
        "primary_error": None,
        "finalization_errors": [],
        "science": "new synthetic data/initial math only; no fit/optimizer/old assets",
    }
    start = time.monotonic()
    primary = None
    lock = None
    resources = None
    try:
        result["physics"] = validate(guard)
        lock = open(guard["Cargo_lock"], "a+b")
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        result["physics_after_lock"] = validate(guard)
        os.sched_setaffinity(0, set(guard["CPU"]))
        target = Path(guard["target"])
        if guard["reuse_owned_target"]:
            if target.is_symlink() or not target.is_dir():
                raise ValueError("declared retained target ownership")
        else:
            target.mkdir(parents=True, exist_ok=False)
        Path(guard["TMP"]).mkdir(parents=True, exist_ok=False)
        resources = Resources(guard)
        result["actualSTART"] = datetime.now(timezone.utc).isoformat()
        for name, command in guard["commands"]:
            result["active_stage"] = name
            validate(
                guard
            )  # Exact source/compiler/proof/environment and fresh quiet before each child.
            try:
                record = process.execute(
                    command, Path(guard["output"]) / (name + ".log"), None, resources=resources
                )
            except BaseException:
                try:
                    record = json.loads(
                        (Path(guard["output"]) / (name + ".process.json")).read_text()
                    )
                    if record["command"] != command:
                        raise ValueError("failed command receipt identity")
                    result["commands"].append({"name": name, "record": record})
                except BaseException as receipt_error:
                    result["finalization_errors"].append(
                        {
                            "stage": "failed-command-receipt",
                            "type": type(receipt_error).__name__,
                            "message": str(receipt_error),
                        }
                    )
                raise
            result["commands"].append({"name": name, "record": record})
        result["status"] = "PASS"
    except BaseException as error:
        primary = error
        result["status"] = "FAILED"
        result["primary_error"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        result["actualSTOP"] = datetime.now(timezone.utc).isoformat()
        result["whole_seconds"] = time.monotonic() - start
        if resources:
            result["sampled"] = resources.sampled
        result["continuous_peak"] = "UNKNOWN"
        try:
            result["retained_TMP_bytes"] = process.directory_bytes(Path(guard["TMP"]))
        except BaseException as error:
            result["retained_TMP_bytes"] = "UNKNOWN"
            result["finalization_errors"].append(
                {"stage": "TMP_census", "type": type(error).__name__, "message": str(error)}
            )
        if lock:
            try:
                lock.close()
            except BaseException as error:
                result["finalization_errors"].append(
                    {
                        "stage": "Cargo_lock_close",
                        "type": type(error).__name__,
                        "message": str(error),
                    }
                )
        try:
            result["source_after_match"] = all(
                sha(path) == expected for path, expected in guard["refs"].items()
            )
        except BaseException as error:
            result["finalization_errors"].append(
                {"stage": "source_check", "type": type(error).__name__, "message": str(error)}
            )
        try:
            process.write_json(Path(guard["output"]) / "receipt.json", result)
        except BaseException as error:
            result["finalization_errors"].append(
                {"stage": "receipt", "type": type(error).__name__, "message": str(error)}
            )
            print(json.dumps(result), flush=True)
            if primary is None:
                primary = error
    if primary:
        raise primary
    if result["finalization_errors"] or not result.get("source_after_match"):
        raise RuntimeError("qualification finalization/source refusal")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
