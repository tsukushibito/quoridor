# C01–C03 ordinary source repair

The changed entry admits no fit while N isnull. Direct train and guarded train perform the same stdlib-only check before NumPy/cache/framework imports, non-control input hashes, resources/child or output. Array helpers import locally; legacy controls remain available on legacy architecture entries. Seven new admission NN0 methods PASS, actual direct and guarded entry included; all framework/library imports are refused. Direct child20:45:40.860906..20:45:40.985786, whole0.124908989s, directwait0, child ru_maxrss28932KiB, owned fixture TMP empty/removed. No old suite, constructor, model, geometry, forward, optimizer, cache rows or games were executed.

The existing experiment record now requires main_volume_manifest_sha256. The exact permit bytes bind scope/full-volume, explicit N/planned_games and a common_input_freeze descriptor(path/sha256). The existing per-fit input_binding is mandatory. It points to the same immutable common freeze and permit SHA and binds actual fit_config SHA. No registry, signature, approval or method choice is added.

The common freeze records:

- cache_manifest_sha, matched to the actual --cache/cache.json bytes;
- dataset(path/sha256), matched to cache manifest source_binding;
- schedule(path/sha256), with planned_games=N and common family_partition_sha256, both also bound by the cache manifest;
- recipes_sha256 for A/B/C/D, hashing the resolved configuration excluding the experiment permit section;
- initialization(seed, zero_output_head=true, ordered_parameters_sha256), checked against the common seed and expected weights, then against actual ordered constructor bytes before optimizer/forward;
- scale(path/sha256), required to contain original, target-independent T-only D/80 statistics;
- constants by condition(path/sha256), shared with the existing per-fit input record.

This is a fail-closed completion of the existing volume/common binding. No actual full-volume record is minted by these NN0 fixtures. Future stream/cache intake must emit the bound source/schedule/family fields; the current pilot/Arrow fixture lacks the full-volume permit and cannot become a fit corpus by declaration alone. Actual loaded cache SHA is additionally checked by the existing input guard; actual recomputed T statistics must match the entire frozen provenance-bearing record. Admission receipt hashes are included in the final candidate freeze.

Any --scale override is refused on new fits. A supply override is accepted only as explicit integer2; 0/bool/other values refuse before frameworks. Legacy scale/workers behavior is preserved on non-experiment entries. Existing forward/objective/teacher/reflection/selection/update and numerical helper ASTs are unchanged aside from local imports; the constructor hash check is a provenance guard. Nonterminal envelope and DistanceStepModel ASTs remain exact. Existing label/native/outward-bound/initial-four proofs are reused within their scopes, not replayed.

The separately stopped initial scale fixture uses validate_statistics for the effective FP32 moments already used by the constructor. Its scalar/AST-only proof and old4 outputs remain distinct; no new forward accompanies that one-path glue correction.

Apply order: original17path patch → outward-envelope delta → initial scale fixture-only delta → this four-path admission delta. The combined current map has19 owned paths. Read-only inverse apply checkPASS; main/Git/index/foreign writes0. All before bytes, original review counterexamples and failed fees/UNKNOWN remain held. Independent related confirmation is pending; no SOURCE-clear claim is made here.

Source/control/archive upper1MiB is inside the held402,653,184B component and learner whole2,721,968,128B/proof9a4891dd. No new resource grant, refund or deletion. Full N/fits/generation/96 remain unadmitted. Parent323USERPAUSE/defaults/sealed labels remain. Own current-next Cargo/model/fair reservationNONE; source is stopped for the same342.8 reviewer’s narrow confirmation.
