"""Saved pilot counts and compact-cache byte formulas; no raw replay or model."""

from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time


ARENA = Path(
    "/workspaces/quoridor/.worktree/nnue-hypothesis-arena/.artifacts/teacher-distance-pilot-v1/final-report-v1"
)
OUTPUT = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    start = time.monotonic()
    packet_path = ARENA / "report-source-STOP-v1.json"
    if sha(packet_path) != "5de643cce2e944989541b89bed843c2cc5711ed4c961ce8f01a93e3778cbdfc9":
        raise ValueError("stopped pilot report binding")
    packet = json.loads(packet_path.read_text())
    inputs = {}
    for name in ("summary.json", "games.csv", "volume-options.json"):
        path = ARENA / name
        if sha(path) != packet["bindings"][str(path)]["SHA256"]:
            raise ValueError("saved pilot report changed: " + name)
        inputs[str(path)] = sha(path)
    summary = json.loads((ARENA / "summary.json").read_text())
    with (ARENA / "games.csv").open() as stream:
        games = list(csv.DictReader(stream))
    observed = summary["verified_native_and_audit_report"]
    assert len(games) == observed["scheduled"] == observed["recorded"] == 64
    assert len({g["request_id"] for g in games}) == len({g["family"] for g in games}) == 64
    assert sum(int(g["rows"]) for g in games) == observed["rows"] == 2798
    assert sum(int(g["attempted_search_calls"]) for g in games) == 2798
    assert Counter(g["split"] for g in games) == summary["game_split_counts"]
    assert Counter(int(g["prefix_length"]) for g in games) == {n: 4 for n in range(4, 20)}
    assert Counter(g["termination"] for g in games) == {"goal": 64}
    assert Counter(g["winner_absolute"] for g in games) == summary["winner_absolute_counts"]
    assert observed["achieved_depths"] == {"3": 2798}
    assert sum(summary["row_outcome_target_counts"].values()) == 2798
    assert sum(summary["row_margin_target_counts"].values()) == 2798
    assert sum(observed["wall_stock_positions"].values()) == 2798
    assert summary["N"] is None
    binary_width = {
        "geometry.bin": 66,
        "distance-steps.u8": 2,
        "labels.f32": 8,
        "terminal-margin.f32": 4,
    }
    width = sum(binary_width.values())
    options = json.loads((ARENA / "volume-options.json").read_text())
    projected = []
    for option in options["options"]:
        n = option["proposed_scheduled_games"]
        rows = option["projected_rows"]
        projected.append(
            {
                **option,
                "compact_binary_arrays_B": int(rows * width),
                "dense_two_view_mirror_B_avoided": int(rows * 2 * 312 * 4),
                "current_512MiB_pilot_cache_analysis_component": 536870912,
                "binary_only_exceeds_component_B": max(0, int(rows * width) - 536870912),
                "N_selected_or_admitted": False,
                "full_metadata_offsets_manifest_TMP_train_outputs": "UNPRICED; binaries alone are not the whole cache",
                "total_rows_projection_formula": f"2798 * {n}/64, not a bound",
            }
        )
    result = {
        "issue": "quoridor-4lc.342.1",
        "scope": "saved summary/64game CSV arithmetic only, no raw/position/history/model replay",
        "inputs": inputs,
        "pilot_report_packet_SHA256": sha(packet_path),
        "authoritative_raw_reference_only": packet["authoritative_raw"],
        "games_families_rows": [64, 64, 2798],
        "family_game_splits": summary["game_split_counts"],
        "row_splits": summary["row_split_counts"],
        "pilot_training_updates_per_epoch_if_it_were_a_fit_corpus": "NOT_A_FIT_CORPUS; no actual updates",
        "goal_draw_UNKNOWN": [64, 0, 0],
        "distinct_duplicate_positions_supplied_native_report": [2798, 0],
        "coverage_fraction": {
            "contact": observed["contact_positions"] / 2798,
            "opening": observed["opening_positions"] / 2798,
            "endgame": observed["endgame_positions"] / 2798,
            "both_stocks_zero": observed["wall_stock_positions"]["0,0"] / 2798,
        },
        "observed_target_units": {
            "outcome_steps": [-80, 80],
            "outcome_z_counts": summary["row_outcome_target_counts"],
            "margin_steps_range": [
                min(map(int, summary["row_margin_target_counts"])),
                max(map(int, summary["row_margin_target_counts"])),
            ],
            "margin_absolute_range": [
                min(abs(int(n)) for n in summary["row_margin_target_counts"]),
                max(abs(int(n)) for n in summary["row_margin_target_counts"]),
            ],
            "loss_normalizer": 6400,
            "MSE_model_predictions": "NOT_MEASURED; label scales only",
        },
        "compact_cache_binary_layout_B_per_row": binary_width,
        "pilot_compact_binary_arrays_B": width * 2798,
        "pilot_dense_mirror_B_avoided": 2 * 312 * 4 * 2798,
        "pilot_metadata_manifest_offsets_TMP_peak": "NOT_MATERIALIZED/UNKNOWN",
        "intake_gap": "Current terminal_cache::write consumes maintained Arrow dataset iterator. Authoritative new pilot is requests/header-game(rows+actualSearchEvidence)-footer JSONL. Direct stream intake/provenance/source qualification remains before real cache construction; no Arrow mirror created or current pilot gate added.",
        "proposed_options_unselected": projected,
        "whole_work_required_after_human_N": "held assets/source/build/private/old failures + future generation/audit/direct stream cache/metadata/T statistics + four finite-stop fits/checkpoints/records + six-view native qualification + 96evaluation/343clock + TMP/review/Git/cleanup",
        "full_fit_updates_epochs_GPU_RSS_outputs_sixviews96_cost": "UNKNOWN; no convergence epoch or guaranteed throughput invented",
        "actual_jobs_new_geometry_forward_fit_generation_calls": 0,
        "N": None,
        "old_caps_assets_raw_fees_UNKNOWN": "held; no subtraction or allocation from projections",
        "directwait": True,
        "remaining": [],
        "analysis_STOP": datetime.now(timezone.utc).isoformat(),
        "analysis_seconds": time.monotonic() - start,
    }
    (OUTPUT / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "scope": result["scope"],
                "binary_B": result["pilot_compact_binary_arrays_B"],
                "N": None,
            }
        )
    )


if __name__ == "__main__":
    main()
