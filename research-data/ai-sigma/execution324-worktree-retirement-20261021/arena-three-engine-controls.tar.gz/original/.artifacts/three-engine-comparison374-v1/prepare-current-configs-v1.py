"""Prepare selected374 configs/plan on the existing ports; no inference or native entry."""

import copy
import importlib.util
import json
import os
import stat
import subprocess
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
OUT = OWN / "current-controls-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def selected(path, digest, size):
    r = ref(path)
    lc.require(r["sha256"] == digest and r["bytes"] == size, "frozen metadata input")
    return r, lc.document(r)


input_ref, current = selected(
    OWN / "current-build-input-handoff-v1.json",
    "e7e778ae39a454a540f1e65a26e0c0faeef5c0dd7b51ddae05bfb233623faec8",
    5339,
)
recipe_ref, recipe = selected(
    OWN / "preparation-recipe-v2.json",
    "19e0e6a201f7f9dac275d04bf0bed4cf8127d81e70b4566d8a0ebdb0b2a70c28",
    68751,
)
controls_ref = current["original_controls"]
controls = lc.document(controls_ref)
support = controls["support"]
lc.require(
    support["sha256"] == "4a3a5d390eef2a70d280121d98644de98fc31f9547d4b28240245b7f870f1e3c",
    "issued374 support",
)
lc.document(support)
book_ref = recipe["book"]
book = lc.document(book_ref)
schedule_ref = next(
    r
    for r in current["original_frozen_inputs_checked_SHA_size_mode"]
    if r["path"].endswith("/schedule-v1.json")
)
schedule = lc.document(schedule_ref)
case_ref = controls["cases_template"]
cases = lc.document(case_ref)
build_ref = current["Build"]
build = lc.accepted_build(build_ref)
artifact = build["artifact"]
requirement = lc.document(recipe["sigma_clock_origin_requirement"])
origin_ref = requirement["origin_config_FileRef"]
origin = lc.document(origin_ref)
common_entry_ref = recipe["qualified_common_public_entry"]
common_entry = lc.document(common_entry_ref)
qualified_environment_ref = recipe["current_environment_import_fact_ref"]
lc.document(qualified_environment_ref)
paths = [
    MAIN / "scripts/dev/research-lifecycle.py",
    MAIN / "scripts/dev/research-job.py",
    MAIN / "python/quoridor_training/cycle_process.py",
    MAIN / "python/quoridor_training/snapshot.py",
]
caller_refs = [ref(p) for p in paths]
lc.caller_source_refs({"caller_sources": caller_refs}, {"phase": "sigma-cost-qualification"})
entry_refs = [
    ref(MAIN / "scripts/dev/project-env.sh"),
    common_entry["pyvenv_cfg"],
    common_entry["regular_interpreter"],
]
for r in entry_refs:
    lc.read_ref(r, max(lc.CONTROL_BYTES, r["bytes"]))
model_refs = [
    {k: r[k] for k in ("path", "sha256", "bytes", "mode")} for r in recipe["named_model_metadata"]
]
model_stats = []
for r in model_refs:
    p = Path(r["path"])
    info = p.lstat()
    lc.require(
        stat.S_ISREG(info.st_mode)
        and info.st_size == r["bytes"]
        and format(stat.S_IMODE(info.st_mode), "04o") == r["mode"],
        "named model metadata drift",
    )
    model_stats.append(
        {
            "selected_FileRef": r,
            "dev": info.st_dev,
            "ino": info.st_ino,
            "size_mode_MATCH": True,
            "current_payload_SHA_checked": False,
        }
    )
lib_path = Path(recipe["Sigma"]["library_path"])
lib = lib_path.lstat()
lc.require(stat.S_ISREG(lib.st_mode), "named installed library regular file")
library_stat = {
    "path": str(lib_path),
    "dev": lib.st_dev,
    "ino": lib.st_ino,
    "bytes": lib.st_size,
    "mode": format(stat.S_IMODE(lib.st_mode), "04o"),
    "sha256": None,
    "actual_native_loaded_version": None,
    "scope": "Current named lstat only; package/version metadata is historical qualification, no payload hash/load",
}
limits = {
    "family_B": 512 * 1024**2,
    "host_reserve_B": 4 * 1024**3,
    "worker_cpu": 1,
    "guardian_cpu": 3,
}
spec = {"cwd": str(MAIN), "limits": limits}
lc.physical_and_quiet(spec)
with lc.lease():
    lc.require(not OUT.exists(), "exclusive current config controls")
    # One conservative assigned-component observation; private images are separate retained custody.
    used = lc.allocated(OWN) - lc.allocated(OWN / "private-images")
    lc.require(used + 8 * 1024**2 <= 48 * 1024**2, "current control component containment")
    lc.require(lc.shutil.disk_usage(OWN).free >= 4 * 1024**3, "filesystem reserve")
    OUT.mkdir()
    lc.new_json(
        OUT / "preprice.json",
        {
            "support": support,
            "old_assigned_namespace_except_private_allocated_B": used,
            "new_controls_formatting_collection_forward_B": 8 * 1024**2,
            "control_component_B": 48 * 1024**2,
            "whole_B": 809500672,
            "global_held_B": 49996492800,
            "target_private_model_library_growth": 0,
            "new_grant_refund_borrow": 0,
            "at": lc.stamp(),
        },
    )
    lc.require(
        book["complete"]
        and [f["family_id"] for f in book["families"]] == list(range(128))
        and len(schedule) == 768,
        "original full book/schedule",
    )
    families = {f["family_id"]: f for f in book["families"]}
    sigma = copy.deepcopy(origin["engines"][0])
    distance = copy.deepcopy(origin["engines"][1])
    nnue = {**distance, "kind": "nnue", "model": model_refs[1]["path"]}
    engines = [[sigma, distance], [sigma, nnue], [distance, nnue]]
    evals = [
        [model_refs[0]["sha256"], recipe["fixedD"]["evaluator_sha256"]],
        [model_refs[0]["sha256"], recipe["NNUE"]["evaluator_sha256"]],
        [recipe["fixedD"]["evaluator_sha256"], recipe["NNUE"]["evaluator_sha256"]],
    ]
    inference = copy.deepcopy(origin["inference"])
    inference.update(
        model=model_refs[0]["path"], model_sha=model_refs[0]["sha256"], library=str(lib_path)
    )

    def opening(f):
        return {
            "id": f["id"],
            "cohort": "main",
            "lineage": "immutable355-family-" + str(f["family_id"]),
            "siblings": [],
            "original_seed": f["seed"],
            "reference": {
                "source_sha256": book_ref["sha256"],
                "model_sha256": None,
                "settings": copy.deepcopy(f),
                "q_definition": None,
                "q_perspective": None,
                "q_aggregation": None,
                "q": None,
            },
            "selection_reason": "All original128 book families fixed before outputs; no outcome selection",
            "candidate_pool_size": 1,
            "prefix": list(f["prefix"]),
        }

    def config(matchup, fs, colors, name, data):
        c = copy.deepcopy(origin)
        c.update(
            run_id=name,
            output=str(data),
            games=2 * len(fs),
            cpu_cores=[1],
            inference_cpu_core=1 if matchup < 2 else None,
            engines=copy.deepcopy(engines[matchup]),
            inference=copy.deepcopy(inference) if matchup < 2 else None,
            max_memory_bytes=3 * 1024**3 - 64 * 1024**2,
            max_output_bytes=8 * 1024**2,
        )
        c["arena"] = {
            "comparison": "whole_wall_time",
            "disable_continuation_static_ordering": True,
            "clock_policy": "strict_unknown",
            "return_reserve_ms": 5,
            "tt_entries": 4096,
            "bootstrap_seed": 37420261012,
            "bootstrap_resamples": 10000,
            "evaluator_sha256": evals[matchup],
            "search_artifact_sha256": [artifact["sha256"]] * 2,
            "first_candidate_colors": colors,
            "retained_outcome_bytes": 630784,
            "book": {
                "id": "374-original355-book-" + name,
                "usage": "main",
                "frozen_before_candidate_results": True,
                "independence": "Original128 shared PRNG/book families; pair/family is unit; correlated descriptive strata",
                "openings": [opening(f) for f in fs],
            },
        }
        return c

    files = []
    measurement = []
    for m, label in [(0, "Sigma-D"), (1, "Sigma-BEST43")]:
        p = OUT / ("full-" + label + ".json")
        lc.new_json(
            p,
            config(
                m,
                book["families"],
                [i % 2 for i in range(128)],
                "374-cost-subject-" + label + "-v1",
                OWN / "cost-subject-data-v1" / label,
            ),
        )
        files.append(p)
        measurement.append(p)
    batch_dir = OUT / "primary-configs"
    batch_dir.mkdir()
    batch_paths = []
    for i in range(384):
        pair = schedule[2 * i : 2 * i + 2]
        lc.require(
            pair[0]["batch"] == pair[1]["batch"] == i
            and pair[0]["family_id"] == pair[1]["family_id"]
            and pair[0]["matchup"] == pair[1]["matchup"]
            and {p["candidate_color"] for p in pair} == {0, 1},
            "frozen batch correspondence",
        )
        p = batch_dir / f"batch-{i:03d}.json"
        lc.new_json(
            p,
            config(
                pair[0]["matchup"],
                [families[pair[0]["family_id"]]],
                [pair[0]["candidate_color"]],
                f"374-primary-batch-{i:03d}-v1",
                OWN / "primary-output-v1" / f"batch-{i:03d}" / "data",
            ),
        )
        files.append(p)
        batch_paths.append(p)
    prettier = MAIN / "tools/research-quality/node_modules/.bin/prettier"
    settings = MAIN / "tools/research-quality/.prettierrc.json"
    result = subprocess.run(
        [
            str(prettier),
            "--config",
            str(settings),
            "--ignore-path",
            "/dev/null",
            "--write",
            *map(str, files),
        ],
        capture_output=True,
        text=True,
        timeout=120,
        env={**os.environ, "NODE_OPTIONS": "--max-old-space-size=128"},
    )
    lc.require(
        result.returncode == 0
        and len(result.stdout.encode()) + len(result.stderr.encode()) <= 256 * 1024,
        "scoped current config formatting",
    )
    (OUT / "config-format.log").write_text(result.stdout + result.stderr)
    config_refs = [ref(p) for p in measurement]
    # Actual serde-resolved digest is an owning native metadata fact, not Python imitation.
    records = [
        {"file": {k: r[k] for k in ("path", "sha256")}, "normalized_sha256": None}
        for r in config_refs
    ]
    cases_current = {**copy.deepcopy(cases), "configurations": records}
    lc.new_json(OUT / "cost-cases.derivative.json", cases_current)
    current_case_ref = ref(OUT / "cost-cases.derivative.json")
    matchups = [
        {
            "id": i,
            "engines": copy.deepcopy(engines[i]),
            "evaluator_sha256": evals[i],
            **({"inference": inference, "sigma_cost_qualification": None} if i < 2 else {}),
        }
        for i in range(3)
    ]
    batches = [
        {
            "batch": i,
            "matchup": schedule[2 * i]["matchup"],
            "config": ref(p),
            "slots": [2 * i, 2 * i + 1],
        }
        for i, p in enumerate(batch_paths)
    ]
    plan = {
        "schema": "quoridor.research.arena-plan.v1",
        "phase": "arena",
        "comparison": "whole_wall_time",
        "rules": recipe["rules"],
        "distance_units": "wall-distance/80",
        "value_perspective": "side-to-move",
        "book": book_ref,
        "inputs": [book_ref, model_refs[0], current_case_ref],
        "models": [
            {
                "descriptor": model_refs[1],
                "weights": model_refs[2],
                "evaluator_sha256": recipe["NNUE"]["evaluator_sha256"],
            }
        ],
        "schedule": schedule_ref,
        "family_ids": list(range(128)),
        "matchups": matchups,
        "batches": batches,
        "planned_slots": 768,
        "sigma_cost_cases": current_case_ref,
    }
    lc.new_json(OUT / "approved-plan.derivative.json", plan)
    campaign = copy.deepcopy(controls["campaign_template"])
    campaign.update(
        configurations=records,
        native={
            "executable_sha256": artifact["sha256"],
            "backend_sha256": None,
            "valid_until_unix_ms": None,
        },
        approved_plan=None,
    )
    lc.new_json(OUT / "cost-campaign.derivative.json", campaign)
    for r in [
        input_ref,
        recipe_ref,
        controls_ref,
        book_ref,
        schedule_ref,
        case_ref,
        build_ref,
        *caller_refs,
        *entry_refs,
    ]:
        lc.read_ref(r, max(lc.CONTROL_BYTES, r["bytes"]))
    lc.accepted_build(build_ref)
    for r in model_refs:
        info = Path(r["path"]).lstat()
        lc.require(
            info.st_size == r["bytes"] and format(stat.S_IMODE(info.st_mode), "04o") == r["mode"],
            "model named metadata after",
        )
    info = lib_path.lstat()
    lc.require(
        (info.st_dev, info.st_ino, info.st_size, stat.S_IMODE(info.st_mode))
        == (lib.st_dev, lib.st_ino, lib.st_size, stat.S_IMODE(lib.st_mode)),
        "named library metadata after",
    )
    source_STOP = lc.stamp()
lease_STOP = lc.stamp()
packet = {
    "issue": "quoridor-4lc.374.1",
    "status": "STOPPED_CONFIG_PLAN_TUPLE_PREPARATION_NOT_SUBMITTABLE",
    "ready": False,
    "support": support,
    "preprice": ref(OUT / "preprice.json"),
    "authentic_Build": build_ref,
    "artifact": artifact,
    "Build_original_source": build["source_adoption"],
    "full_current_two_configs": config_refs,
    "primary_batch_count": 384,
    "primary_plan_derivative": ref(OUT / "approved-plan.derivative.json"),
    "current_cost_cases_derivative": current_case_ref,
    "current_campaign_derivative": ref(OUT / "cost-campaign.derivative.json"),
    "retained_case_definition": case_ref,
    "normal_current_caller_refs_before_after": caller_refs,
    "common_entry": common_entry_ref,
    "qualified_environment": qualified_environment_ref,
    "actual_entry_environment_refs_before_after": entry_refs,
    "selected_model_FileRefs_named_metadata": model_stats,
    "NNUE_selected_descriptor_semantics": recipe["NNUE"],
    "D_selected": recipe["fixedD"],
    "named_library_current_lstat_before_after": library_stat,
    "runtime_dynamic_libraries": None,
    "actual_backend_binding": None,
    "native_config_normalized_digests": [None, None],
    "fresh_positive_cost_bounds": None,
    "fresh_usable_Q": None,
    "qualification_started_unix_ms": None,
    "valid_until_unix_ms": None,
    "approved_plan_actual_Root_FileRef": None,
    "admission": None,
    "job": None,
    "only_normal_remaining_gap": "Owning current runtime binding and Rust-resolved Config serialization: actual model/library FileRefs plus loaded backend/version/digest and normalized config digests, then Root actual approved plan/current intent. Do not imitate serializer/guess backend or transplant expired347. Current64 remains unentered;24h is set at actual admitted launch only.",
    "counts": {
        "games": 768,
        "pairs": 384,
        "families": 128,
        "diagnostic_parents": 78,
        "diagnostic_proposals": 234,
        "missing": 18,
        "fresh_cost_requests_max": 64,
    },
    "format": "Project Prettier on386 current configs; stdlib metadata generation; no Rust type/runtime qualification claimed",
    "source_reader_STOP": source_STOP,
    "canonical_release": lease_STOP,
    "owned_readers_children_jobs_TMP_remaining": [],
    "reservation": None,
    "actual_native_model_library_heads_Sigma_Search_game_calls": 0,
    "original_sources_Q_FAILED_models_floors_fees_masks_UNKNOWN": "HELD unchanged",
}
lc.new_json(OUT / "stopped-config-binding.json", packet)
print(
    json.dumps(
        {
            "binding": ref(OUT / "stopped-config-binding.json"),
            "configs": config_refs,
            "plan": packet["primary_plan_derivative"],
            "STOP": source_STOP,
            "release": lease_STOP,
        }
    )
)
