"""Materialize one current common374+376 BUILD with the single affected metadata assertion."""

import importlib.util
import json
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1/clock-return-repair-v1/common-software-v1"
)
PHASE = OWN / "build-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


adoption = ref(
    MAIN / "research-data/ai-sigma/three-engine-comparison374/source-adoption-clock376-v1.json"
)
lc.require(
    adoption["sha256"] == "7fa7862b6020b28e29a257cb3572abb877e7fb1d49fc5a7de446e43338574823",
    "current Source",
)
source = lc.document(adoption)["source"]
handover_ref = ref(
    MAIN / ".artifacts/research-team/integration324/374-common-build-v1/target-handover-v2.json"
)
lc.require(
    handover_ref["sha256"] == "5b0d283a92efbd0aef970c36102a0bcef6c5b39bfe265afb54a894c20d1f8161",
    "current custody",
)
handover = lc.document(handover_ref)
support = handover["support"]
lc.document(support)
prior = json.loads(
    (
        MAIN
        / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1/software-build-v4/intent.json"
    ).read_bytes()
)
tools = prior["tools"]
env = {**prior["env"], "TMPDIR": str(PHASE / "TMP-v1")}
limits = {
    "family_B": 3 * 1024**3,
    "controller_B": 64 * 1024**2,
    "host_reserve_B": 4 * 1024**3,
    "owned_B": handover["target_max_B"] + handover["private_pool_B"] + 64 * 1024**2 + 4 * 1024**2,
    "log_B": 128 * 1024,
    "free_B": 4 * 1024**3,
    "worker_cpu": 1,
    "guardian_cpu": 3,
}
cargo = tools["CARGO"]["file"]["path"]
common = [
    "--offline",
    "--locked",
    "--manifest-path",
    source["manifest"]["path"],
    "-j1",
    "--message-format=json-render-diagnostics",
]
commands = [
    {
        "name": "affected-retained-native-clock376",
        "role": "test",
        "argv": [
            cargo,
            "test",
            *common,
            "-p",
            "quoridor-runner",
            "--lib",
            "--features",
            "ordering-assessment",
            "research_manifest::build379_provenance_tests::build379_retained_input_scope_never_relabels_original_image",
            "--",
            "--exact",
            "--test-threads=1",
        ],
    },
    {
        "name": "clippy-common374376",
        "role": "lint",
        "argv": [
            cargo,
            "clippy",
            *common,
            "--keep-going",
            "-p",
            "quoridor-ai",
            "-p",
            "quoridor-data",
            "-p",
            "quoridor-inference",
            "-p",
            "quoridor-nnue",
            "-p",
            "quoridor-runner",
            "--lib",
            "--bin",
            "quoridor-runner",
            "--tests",
            "--features",
            "quoridor-runner/ordering-assessment",
            "--no-deps",
            "--",
            "-Dwarnings",
        ],
    },
    {
        "name": "release-common374376",
        "role": "build",
        "argv": [
            cargo,
            "build",
            *common,
            "--release",
            "-p",
            "quoridor-runner",
            "--bin",
            "quoridor-runner",
            "--features",
            "ordering-assessment",
        ],
    },
]
lc.require(
    commands[-1]["argv"] == next(c["argv"] for c in prior["commands"] if c["role"] == "build"),
    "unchanged admitted release argv",
)
spec = {
    "schema": "quoridor.research.lifecycle-intent.v1",
    "kind": "build",
    "owner": str(MAIN / ".worktree"),
    "writer": "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0",
    "cwd": str(MAIN),
    "output": str(PHASE / "operation-v1"),
    "env": env,
    "limits": limits,
    "support": support,
    "source_adoption": adoption,
    "target_handover": handover_ref,
    "source": source,
    "tools": tools,
    "target": handover["target"],
    "private": handover["candidate"],
    "TMP": str(PHASE / "TMP-v1"),
    "commands": commands,
    "finalizers": [],
    "artifact_target": "quoridor-runner",
}
import os

os.sched_setaffinity(0, {1, 3})
lc.physical_and_quiet(spec)
with lc.lease():
    lc.require(not PHASE.exists(), "exclusive common374376 phase")
    lc.build_check(spec)
    for tool in tools.values():
        lc.read_ref(tool["file"], max(lc.CONTROL_BYTES, tool["file"]["bytes"]))
    target_before = lc.allocated(spec["target"])
    lc.require(target_before <= handover["target_max_B"], "actual target cap")
    lc.require(
        lc.allocated(Path(spec["private"]).parent) <= handover["fresh_private_forward_max_B"],
        "private parent cap",
    )
    PHASE.mkdir()
    lc.new_json(
        PHASE / "preflight.json",
        {
            "at": lc.stamp(),
            "target_allocated_B": target_before,
            "target_cap_B": handover["target_max_B"],
            "retained_floor_B": handover["effective_retained_floor_B"],
            "private_allocated_B": lc.allocated(Path(spec["private"]).parent),
            "physical_available_B": lc.process.available_memory(),
            "FS_free_B": lc.shutil.disk_usage(spec["owner"]).free,
            "physical_namedquiet": "Maintained fresh guard passed, repeated at actual entry",
            "canonical_NB": "held during current Git/Cargo/tool/owner/cap checks, released on helper return",
            "source": adoption,
            "handover": handover_ref,
            "support": support,
            "expected_assertions_executed": 1,
            "test_scope": "One changed retained-native metadata assertion only; original clock4/379two/376nine/374twelve+eight scopes remain historical",
            "scope": "One affected synthetic schedule assertion/unfinished Clippy/release only; no models/heads/library/geometry/Search/games",
        },
    )
    digest = lc.sha(json.dumps(spec, sort_keys=True, separators=(",", ":")).encode())
    spec["intent_sha256"] = digest
    lc.new_json(
        PHASE / "admission.json",
        {
            "schema": "quoridor.research.phase-admission.v1",
            "owner": spec["owner"],
            "limits": limits,
            "spec_sha256": digest,
            "support_sha256": support["sha256"],
            "ready": True,
            "current_global_held_B": 49996492800,
            "preflight": ref(PHASE / "preflight.json"),
        },
    )
    spec["admission"] = ref(PHASE / "admission.json")
    lc.new_json(PHASE / "intent.json", spec)
    intent = ref(PHASE / "intent.json")
    config = {
        "issue": "quoridor-4lc.374.1",
        "goal_issue": "quoridor-4lc.374",
        "thread_id": "01a11062-b120-73a1-8aa3-fe2cb922c7c0",
        "cwd": str(MAIN),
        "argv": [
            __import__("sys").executable,
            "-B",
            str(MAIN / "scripts/dev/research-lifecycle.py"),
            "build",
            "--intent",
            intent["path"],
            "--sha256",
            intent["sha256"],
        ],
        "end_at": None,
        "notify_until": None,
        "max_runtime_seconds": None,
        "control_interval_seconds": 30,
        "notify_interval_seconds": 10,
        "request_timeout_seconds": 25,
        "log_max_bytes": 65536,
        "resource_contract": support["path"],
    }
    lc.new_json(PHASE / "config.json", config)
    print(
        json.dumps(
            {
                "intent": intent,
                "config": ref(PHASE / "config.json"),
                "preflight": ref(PHASE / "preflight.json"),
                "STOP": lc.stamp(),
            }
        )
    )
