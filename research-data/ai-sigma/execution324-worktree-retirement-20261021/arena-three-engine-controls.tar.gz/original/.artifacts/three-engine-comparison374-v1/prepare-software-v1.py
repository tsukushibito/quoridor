"""Materialize the one selected BUILD using maintained admission functions."""

import importlib.util
import json
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
PHASE = OWN / "software-build-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


base = MAIN / "research-data/ai-sigma/three-engine-comparison374"
adoption = ref(base / "source-adoption-v1.json")
handover_ref = ref(base / "target-handover-v1.json")
support = ref(base / "support-v2.json")
source = lc.document(adoption)["source"]
handover = lc.document(handover_ref)
prior = json.loads(
    (
        MAIN
        / ".worktree/ordering-cost372/.artifacts/ordering-cost372-v1/build-B-v1/operation-v1/manifest.json"
    ).read_bytes()
)
tools = prior["tools"]
tools["PYTHON"] = {
    "file": {
        "path": "/home/vscode/.cache/inference/python/cpython-3.14.7-linux-x86_64-gnu/bin/python3.14",
        "sha256": "5a91882290532b2719eaca77c0f3a7448bd73b9214e56df57bc59004560a80c6",
        "bytes": 32418544,
        "mode": "0755",
    },
    "version_args": ["--version"],
    "version": "Python 3.14.7",
}
env = {
    **prior["env"],
    "TMPDIR": str(PHASE / "TMP-v1"),
    "CUDA_VISIBLE_DEVICES": "",
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1",
    "ORT_DISABLE_TELEMETRY": "1",
}
limits = {
    "family_B": 3 * 1024**3,
    "controller_B": 64 * 1024**2,
    "host_reserve_B": 4 * 1024**3,
    "owned_B": handover["target_max_B"] + handover["private_pool_B"] + 64 * 1024**2 + 8 * 1024**2,
    "log_B": 512 * 1024,
    "free_B": 4 * 1024**3,
    "worker_cpu": 1,
    "guardian_cpu": 3,
}
cargo = tools["CARGO"]["file"]["path"]
common = [
    "--offline",
    "--locked",
    "--manifest-path",
    source["manifest"]["path"],
    "-j1",
    "--message-format=json-render-diagnostics",
]
private = str(OWN / "private-images/quoridor-runner374-v1")
commands = [
    {
        "name": "test-ai-three-engine374",
        "role": "test",
        "argv": [
            cargo,
            "test",
            *common,
            "-p",
            "quoridor-ai",
            "--lib",
            "three_engine_374",
            "--",
            "--test-threads=1",
        ],
    },
    {
        "name": "test-runner-three-engine374",
        "role": "test",
        "argv": [
            cargo,
            "test",
            *common,
            "-p",
            "quoridor-runner",
            "--lib",
            "--bin",
            "quoridor-runner",
            "--features",
            "ordering-assessment",
            "three_engine_374",
            "--",
            "--test-threads=1",
        ],
    },
    {
        "name": "clippy-three-engine374",
        "role": "lint",
        "argv": [
            cargo,
            "clippy",
            *common,
            "--keep-going",
            "-p",
            "quoridor-ai",
            "-p",
            "quoridor-data",
            "-p",
            "quoridor-inference",
            "-p",
            "quoridor-nnue",
            "-p",
            "quoridor-runner",
            "--lib",
            "--bin",
            "quoridor-runner",
            "--tests",
            "--features",
            "quoridor-runner/ordering-assessment",
            "--no-deps",
            "--",
            "-Dwarnings",
        ],
    },
    {
        "name": "release-three-engine374",
        "role": "build",
        "argv": [
            cargo,
            "build",
            *common,
            "--release",
            "-p",
            "quoridor-runner",
            "--bin",
            "quoridor-runner",
            "--features",
            "ordering-assessment",
        ],
    },
    {
        "name": "bindings-three-engine374",
        "role": "bindings",
        "argv": [private, "research-bindings"],
    },
]
spec = {
    "schema": "quoridor.research.lifecycle-intent.v1",
    "kind": "build",
    "owner": str(MAIN / ".worktree"),
    "writer": "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0",
    "cwd": str(MAIN),
    "output": str(PHASE / "operation-v1"),
    "env": env,
    "limits": limits,
    "support": support,
    "source_adoption": adoption,
    "target_handover": handover_ref,
    "source": source,
    "tools": tools,
    "target": handover["target"],
    "private": private,
    "TMP": str(PHASE / "TMP-v1"),
    "dependency_refs": [
        r
        for r in source["files"]
        if r["path"].endswith("Cargo.toml") or r["path"] == source["lock"]["path"]
    ],
    "commands": commands,
    "finalizers": [],
    "artifact_target": "quoridor-runner",
}
lc.physical_and_quiet(spec)
with lc.lease():
    assert lc.allocated(OWN) + 32 * 1024**2 < 48 * 1024**2
    target_before = lc.allocated(spec["target"])
    assert target_before <= handover["target_max_B"]
    lc.build_check(spec)
    for tool in tools.values():
        lc.read_ref(tool["file"], max(lc.CONTROL_BYTES, tool["file"]["bytes"]))
    for name in ("cargo-clippy", "clippy-driver"):
        spec["dependency_refs"].append(ref(Path(cargo).parent / name))
    PHASE.mkdir()
    preflight = {
        "at": lc.stamp(),
        "target_allocated_B": target_before,
        "target_cap_B": handover["target_max_B"],
        "retained_floor_B": handover["effective_retained_floor_B"],
        "physical_available_B": lc.process.available_memory(),
        "FS_free_B": lc.shutil.disk_usage(spec["owner"]).free,
        "physical_namedquiet": "Maintained guard passed once, repeated at actual entry",
        "canonical_NB": "Held during source/tool/dependency/owner/cap checks, then released",
        "source": adoption,
        "handover": handover_ref,
        "support": support,
        "expected_assertions": {"AI_lib": 1, "runner_lib": 10, "runner_bin": 1},
        "model_Search_calls": 0,
    }
    lc.new_json(PHASE / "preflight.json", preflight)
    digest = lc.sha(json.dumps(spec, sort_keys=True, separators=(",", ":")).encode())
    spec["intent_sha256"] = digest
    admission = {
        "schema": "quoridor.research.phase-admission.v1",
        "owner": spec["owner"],
        "limits": limits,
        "spec_sha256": digest,
        "support_sha256": support["sha256"],
        "ready": True,
        "current_global_held_B": 49988104192,
        "preflight": ref(PHASE / "preflight.json"),
    }
    lc.new_json(PHASE / "admission.json", admission)
    spec["admission"] = ref(PHASE / "admission.json")
    lc.new_json(PHASE / "intent.json", spec)
    intent = ref(PHASE / "intent.json")
    config = {
        "issue": "quoridor-4lc.374.1",
        "goal_issue": "quoridor-4lc.374",
        "thread_id": "01a11062-b120-73a1-8aa3-fe2cb922c7c0",
        "cwd": str(MAIN),
        "argv": [
            tools["PYTHON"]["file"]["path"],
            "-B",
            str(MAIN / "scripts/dev/research-lifecycle.py"),
            "build",
            "--intent",
            intent["path"],
            "--sha256",
            intent["sha256"],
        ],
        "end_at": None,
        "notify_until": None,
        "max_runtime_seconds": None,
        "control_interval_seconds": 30,
        "notify_interval_seconds": 10,
        "request_timeout_seconds": 25,
        "log_max_bytes": 65536,
        "resource_contract": support["path"],
    }
    lc.new_json(PHASE / "config.json", config)
    print(
        json.dumps(
            {
                "intent": intent,
                "config": ref(PHASE / "config.json"),
                "preflight": ref(PHASE / "preflight.json"),
                "STOP": lc.stamp(),
            }
        )
    )
