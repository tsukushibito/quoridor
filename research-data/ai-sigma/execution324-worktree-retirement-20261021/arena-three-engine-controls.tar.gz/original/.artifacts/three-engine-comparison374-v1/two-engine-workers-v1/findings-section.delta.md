### 人間選択：AI二者のworkerとmain対局管理（374、2026-10-13）

棋力評価は同時対局1、AI A/Bごとに長寿命worker1本、main threadによる対局・時計管理へ移す。各AI workerが自分のmodel/evaluator/session/TT、探索と同期評価を所有し、Sigma CPU ORTはintra/inter threads1・sequential・batch1とする。両AIの同時探索やponder、評価用の共有推論pump・専用推論thread・Sigmaだけのauthority受領threadは採用しない。並列自己対局・CPU/GPU batch生成が実際に使う共有queueは別機能として維持する。

mainは実full history・反復・goal・合法着手、手番開始、実応答receipt/deadline、取消・terminal回収・記録を持つ。モデル推論・長い探索・遅い保存をreceiptのcritical pathへ置かない。実100ms receipt/5ms reserve、完成済み結果の選択、zero-completion合法fallback/null value、original error/cancel、実receipt-return-terminal drainと次手番前の旧work回収を保持する。同期ORTの強制停止は仮定せず、期限前receiptとterminal完了を区別し、遅いreplyやerrorを過去snapshotで救済しない。

利用可能な3物理コアに管理mainと等条件の二者を配置する案を、実affinity/cgroup/SMT/host reserveとwhole費用で確認する。configのworkersを3へ増やして並列対局にする変更ではない。CPU/thread構成は旧timing cohortと異なる条件として記録する。固定Sigma-Web751186と現mainはCPU WASMを明示するが、crossOriginIsolated時の最大8推論threadsとその他1を区別し、公開版の通常対局が常に1threadとは主張しない。今回のCPU・AI各1worker/推論1threadは人間選択の評価条件である。

[旧構成BUILD7の実結果](../.worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1/no-cost-prediction-v1/software-build-v1/build-v7/qualified-collection-v1/completion-handoff.json)は通常PASSで、未完了だったsynthetic integration1、Clippy、releaseと7versionsを確認した。旧7native/Python2は元scopeで保持し、再実行・新構成への証拠移植をしない。private8d066438は旧構成imageとして保存し、旧構成を完成させるだけの追加build・対局は発行しない。新しい所有/時計境界はSAME374の実装・affected checksと既存related reviewerの一度の限定確認を経てMainへ採用する。現時点では新構成のsource/software/棋力PASSではない。

元0/1局はFAILED/raw2goal/validatedUNKNOWNのまま再実行せず、残り766局と既存78parents/234proposals/18missingだけを継続する。models/weights/features/float、Sigma policy/value/PUCT/K、alpha math/PVS/TT、rules/temperature/100ms/5msは不変。追加64・calibration・推論時間予測を復活させない。既存772MiB/global decimal50GB内で実source/build/private/test/review/RAW/TMP/failureを配分し、実CPU・保存不足だけを具体的に報告する。349継続と374実timing優先、sole Main/Cargo writer、323 USERPAUSE/defaults/N/seals/fits96を保持し、Policy返信・全task完了をgateにしない。

374二AI/mainのsource提案では、WholeWallTimeだけをmain管理のserial pathへ分け、各AI worker内にevaluator/backend/sessionを置く。CPUのgame worker数1とengine owner数2を分け、nativeのmanagement core・順序付きA/B coresとnormal callerの実三コアlaunchを一致させる。mainは95msで期限内完成またはcache済み合法ゼロ仕事fallbackを固定し、実100ms receiptを拒否境界とする。遅い同期forward・元のエラー・cancel・matching terminal回収を別の事実として保持し、回収前に次手を始めない。self-play CPU/GPU queueは実機能に残す。

新definitionはnative unit6 + NN0 integration1、Python metadata3。まだUNBUILT/UNTYPED/UNRUNで、静的整形・unchanged scopeの再利用は新architecture/image/gameのPASSではない。変更所有/時計境界のrelated necessity/correctnessを一度確認してから通常の採用・affected software・current immutable artifact・実RUN admissionへ進む。ordinary storageは省略し一度のpost-work usageを記録する。旧private/target/category forecastを新開始gateへ戻さない。

旧entered slots0/1のFAILED/raw goals2/1166calls/validated UNKNOWN、旧architecture Build/image/Qと各料金/returned-vs-disk masksは固定履歴。0/1を再実行せず、未来の766 games/batches1..383、78parents234proposals/18missingを同じ選択と時計で移行する。extra64/prediction/calibration、model/head replay、training/fit/default/score/N/seals/323 pauseの変更はない。
