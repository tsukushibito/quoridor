"""Saved-only arithmetic using the maintained arena publication readers."""

from collections import Counter, defaultdict
import importlib.util
import json
from pathlib import Path

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
BASE = OWN.parent
loader = importlib.util.spec_from_file_location("lc", ROOT / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def describe(rows):
    counts = Counter()
    points = 0
    for row in rows:
        counts["validated_records"] += 1
        counts["started"] += int(row["started"])
        if row["status"] == "draw" and row["winner"] is None:
            counts["D"] += 1
            points += 0.5
        elif row["status"] in {"goal", "forfeit"} and row["winner"] in (0, 1):
            candidate_won = row["winner"] == row["candidate_color"]
            counts["W" if candidate_won else "L"] += 1
            points += int(candidate_won)
            counts["forfeit"] += int(row["status"] == "forfeit")
        else:
            counts["UNKNOWN"] += 1
        if row["failure"] is not None:
            counts["failure:" + row["failure"]] += 1
    known = counts["W"] + counts["D"] + counts["L"]
    return {
        **{
            key: counts[key]
            for key in ("validated_records", "started", "W", "D", "L", "UNKNOWN", "forfeit")
        },
        "failures": {key[8:]: value for key, value in counts.items() if key.startswith("failure:")},
        "points": points,
        "known_outcome_score": points / known if known else None,
    }


def main():
    lc.physical_and_quiet(
        {
            "kind": "run",
            "limits": {
                "family_B": 512 * 1024**2,
                "host_reserve_B": 4 * 1024**3,
                "worker_cpu": 4,
                "guardian_cpu": 6,
            },
        }
    )
    with lc.lease():
        caller = lc.bound(ROOT / "scripts/dev/research-lifecycle.py")[0]
        completion_ref = json.loads((OWN / "intake.json").read_text())["completion"]
        completion = lc.document(completion_ref)
        aggregate_refs = [lc.bound(BASE / f"finite-arena374-v{n}/result.json")[0] for n in (1, 2)]
        aggregate_refs.append(completion["original_aggregate"])
        sources = []
        selected = {}
        aggregates = []
        for ref in aggregate_refs:
            aggregate = lc.document(ref)
            lc.document(aggregate["settings"])
            aggregates.append(
                {"result": ref, "settings": aggregate["settings"], "status": aggregate["status"]}
            )
            for operation in aggregate["operations"]:
                if operation["kind"] == "arena" and operation.get("manifest") is not None:
                    batch = operation["index"]
                    lc.require(batch not in selected, "original arena operation duplicated")
                    selected[batch] = operation["manifest"]
        for batch in range(2, 6):
            collection_ref = lc.bound(
                BASE
                / f"primary-controls-two-ai-v1/batch-{batch:03d}/collection-v1/collection-result.json"
            )[0]
            collection = lc.document(collection_ref)
            sources.append(collection_ref)
            selected[batch] = collection["manifest"]
        selected[0] = lc.bound(BASE / "primary-controls-v3/batch-000/operation-v1/manifest.json")[0]
        selected[1] = lc.bound(
            BASE / "primary-controls-two-ai-v1/batch-001/operation-v1/manifest.json"
        )[0]
        lc.require(set(selected) == set(range(384)), "complete original operation census")
        rows = []
        retained_failed = []
        cohorts = {}
        schedule_ref = None
        schedule = None
        plans = {}
        for batch, manifest_ref in sorted(selected.items()):
            manifest = lc.document(manifest_ref)
            if manifest["status"] != "PASS":
                retained_failed.append(
                    {
                        "batch": batch,
                        "completion": manifest_ref,
                        "status": manifest["status"],
                        "primary": manifest["primary"],
                        "data_status": manifest["data"]["status"],
                    }
                )
                continue
            lc.require(
                manifest["primary"] is None
                and manifest["cleanup_complete"] is True
                and manifest["remaining"] == [],
                "original completion not fully settled",
            )
            experiment = lc.document(manifest["experiment"])
            intent = lc.document(manifest["intent"])
            plan_ref = intent["approved_plan"]
            if plan_ref["sha256"] not in plans:
                plans[plan_ref["sha256"]] = lc.document(plan_ref)
            plan = plans[plan_ref["sha256"]]
            lc.require(
                experiment["canonical_plan_sha256"] == plan_ref["sha256"]
                and intent["experiment"] == manifest["experiment"]
                and experiment["batch"] == batch,
                "original subject correspondence",
            )
            if schedule_ref is None:
                schedule_ref = experiment["schedule"]
                schedule = lc.document(schedule_ref)
            lc.require(experiment["schedule"] == schedule_ref, "frozen scientific schedule changed")
            planned, config = lc.arena_plan_check(experiment, plan)
            build = lc.document(experiment["build_manifest"])
            by_path = {ref["path"]: ref for ref in manifest["data"]["files"]}
            files = {
                name: by_path[str(Path(config["output"]) / filename)]
                for name, filename in (
                    ("journal", "completed.jsonl.gz"),
                    ("result", "result.json"),
                    ("native_manifest", "manifest.json"),
                )
            }
            native = lc.arena_reference_report(config, files, expected_build=build)
            lc.require(
                len(native["outcomes"]) == len(planned) == 2, "full original colour pair records"
            )
            key = (plan_ref["sha256"], experiment["build_manifest"]["sha256"])
            if key not in cohorts:
                cohorts[key] = {
                    "plan": plan_ref,
                    "build": experiment["build_manifest"],
                    "artifact": build["artifact"],
                    "batch_ids": [],
                    "engine_cpu_cores": [e.get("cpu_core") for e in config["engines"]],
                    "main_cpu_core": config.get("main_cpu_core"),
                    "inference_cpu_core": config.get("inference_cpu_core"),
                    "child_cpu_cores": intent.get("child_cpu_cores"),
                    "inference": {
                        k: v
                        for k, v in (config.get("inference") or {}).items()
                        if k not in ("model", "library")
                    },
                    "rows": [],
                }
            cohort = cohorts[key]
            cohort["batch_ids"].append(batch)
            for original in native["outcomes"]:
                slot = next(item for item in planned if item["local_game"] == original["game"])
                lc.require(
                    original["candidate_color"] == slot["candidate_color"]
                    and original["family"]
                    == f"{config['run_id']}-family-{original['game'] // 2:06}",
                    "original scheduled row correspondence",
                )
                lc.arena_observation(config, original)
                row = {
                    name: original[name]
                    for name in (
                        "status",
                        "started",
                        "winner",
                        "reason",
                        "failure",
                        "plies",
                        "candidate_color",
                    )
                }
                row.update(
                    slot=slot["slot"],
                    batch=batch,
                    matchup=slot["matchup"],
                    family_id=slot["family_id"],
                    observations=len(original["observations"]),
                    completion=manifest_ref,
                )
                rows.append(row)
                cohort["rows"].append(row)
            if batch % 48 == 0:
                print(json.dumps({"saved_batches_processed": batch + 1}), flush=True)
        lc.require(
            len(rows) == 762 and len({r["slot"] for r in rows}) == 762,
            "actual validated census differs",
        )
        missing = [r for r in schedule if r["slot"] not in {row["slot"] for row in rows}]
        lc.require(
            [r["slot"] for r in missing] == [0, 1, 2, 3, 12, 13], "retained missing slots changed"
        )
        by_family = defaultdict(list)
        for row in rows:
            by_family[(row["matchup"], row["family_id"])].append(row)
        family_rows = []
        for matchup in range(3):
            for family in range(128):
                values = by_family[(matchup, family)]
                values.sort(key=lambda r: r["candidate_color"])
                facts = describe(values)
                complete = len(values) == 2 and facts["UNKNOWN"] == 0
                family_rows.append(
                    {
                        "matchup": matchup,
                        "family_id": family,
                        "slots": [r["slot"] for r in values],
                        "complete_colour_pair": complete,
                        "pair_score": facts["points"] / 2 if complete else None,
                        **facts,
                    }
                )
        tables = []
        for matchup, label in enumerate(("Sigma–D", "Sigma–BEST43", "D–BEST43")):
            values = [r for r in rows if r["matchup"] == matchup]
            facts = describe(values)
            families = [r for r in family_rows if r["matchup"] == matchup]
            complete = [r["pair_score"] for r in families if r["complete_colour_pair"]]
            absent = [r for r in missing if r["matchup"] == matchup]
            unknown = facts["UNKNOWN"] + len(absent)
            tables.append(
                {
                    "matchup": matchup,
                    "label": label,
                    "planned_games": 256,
                    **facts,
                    "missing_failed_slots": [r["slot"] for r in absent],
                    "complete_colour_pairs": len(complete),
                    "complete_pair_mean": sum(complete) / len(complete) if complete else None,
                    "fixed_denominator_missingness_bounds": [
                        facts["points"] / 256,
                        (facts["points"] + unknown) / 256,
                    ],
                    "by_candidate_colour": {
                        str(side): describe([r for r in values if r["candidate_color"] == side])
                        for side in (0, 1)
                    },
                    "family_pair_score_counts": dict(
                        Counter(str(r["pair_score"]) for r in families)
                    ),
                    "conditional_interval": None,
                }
            )
        for cohort in cohorts.values():
            values = cohort.pop("rows")
            cohort["by_matchup"] = {
                str(m): describe([r for r in values if r["matchup"] == m]) for m in range(3)
            }
        selection_ref = lc.bound(BASE / "diagnostic-selection-v1.json")[0]
        selection = lc.document(selection_ref)
        diagnostic_schedule_ref = lc.bound(BASE / "diagnostic-schedule-v1.json")[0]
        diagnostic_schedule = lc.document(diagnostic_schedule_ref)
        diagnostic_book_ref = lc.bound(BASE / "diagnostic-book-v1.json")[0]
        diagnostic_book = lc.document(diagnostic_book_ref)
        lc.require(
            selection["selected_before_outputs"] is True
            and len(selection["parents"]) == len(diagnostic_book["openings"]) == 78
            and len(selection["exclusions"]) == 18
            and len(diagnostic_schedule) == 234,
            "original diagnostic denominator",
        )
        lc.require(
            Counter(row["family_id"] for row in diagnostic_schedule)
            == Counter({i: 3 for i in range(78)}),
            "three selected proposals per parent",
        )
        for ref in (
            completion_ref,
            caller,
            schedule_ref,
            selection_ref,
            diagnostic_schedule_ref,
            diagnostic_book_ref,
            *aggregate_refs,
        ):
            lc.read_ref(ref, ref["bytes"])
        result = {
            "schema": "quoridor.arena-comparison.summary.v1",
            "planned": 768,
            "validated_records": len(rows),
            "complete_colour_pairs": sum(t["complete_colour_pairs"] for t in tables),
            "retained_FAILED_UNKNOWN_slots": [r["slot"] for r in missing],
            "original_completion": completion_ref,
            "original_aggregates_and_settings": aggregates,
            "original_manual_collection_refs": sources,
            "original_failed_completions": retained_failed,
            "schedule": schedule_ref,
            "matchups": tables,
            "families": family_rows,
            "cohorts": list(cohorts.values()),
            "interval_status": "NOT_COMPUTED: existing arena_analysis binds one producer plan and Build and requires a decision plan matching the nonempty diagnostic selection. No mixed-cohort/arena-only saved-analysis control is present here; no new estimator or fabricated subjects were introduced.",
            "frozen_interval_method": {
                "unit": "complete family colour pair",
                "bootstrap_resamples": 10000,
                "bootstrap_seed": 37420261012,
                "central_interval": "98.33333333333333%",
                "scope": "conditional exploratory resampling; no IID/population/Elo guarantee",
            },
            "diagnostics": {
                "selection": selection_ref,
                "book": diagnostic_book_ref,
                "schedule": diagnostic_schedule_ref,
                "selected_parents": 78,
                "planned_single_proposals": 234,
                "original_missing_milestones": 18,
                "executed_by_this_collection": 0,
                "status": "Frozen selection/book/schedule exist. Current inspected arena controls contain no adopted width1 decision plan/config/Experiment/admission or diagnostic completion; preparation and actual admitted proposals remain unfinished.",
                "next_inlet": "Existing arena_decision_plan_check: Root approved compare plan with width1 three-engine configurations, current artifact and two-AI/main/runtime CPU correspondence, full history and single proposal per selected parent; normal numerical/model/input/library ownership and authentic Run settings/admission. No head/model readiness or ready admission inferred.",
            },
            "saved_games": rows,
            "limitations": [
                "Pooled W/D/L and pair means describe this fixed saved study with version/timing cohorts; not a homogeneous new strength cohort.",
                "FAILED/raw goals are excluded; original768 denominator and six unknown slots retained without replay/refill.",
                "Intervals are unavailable through the present existing saved-analysis inlet; no replacement estimator or model calls.",
                "No general strength, Elo, default adoption, model improvement, causal hypothesis or hard-realtime claim.",
            ],
            "reader_STOP": lc.stamp(),
            "new_model_native_head_Search_game_Cargo_test_calls": 0,
            "owned_readers_children_jobs_TMP_remaining": [],
            "storage_budget": None,
        }
        lc.new_json(OWN / "summary.json", result)
        print(
            json.dumps(
                {
                    "matchups": tables,
                    "cohorts": [
                        {k: v for k, v in c.items() if k not in ("inference", "plan", "build")}
                        for c in cohorts.values()
                    ],
                    "reader_STOP": result["reader_STOP"],
                }
            ),
            flush=True,
        )
    print(json.dumps({"canonical_release": lc.stamp()}), flush=True)


if __name__ == "__main__":
    main()
