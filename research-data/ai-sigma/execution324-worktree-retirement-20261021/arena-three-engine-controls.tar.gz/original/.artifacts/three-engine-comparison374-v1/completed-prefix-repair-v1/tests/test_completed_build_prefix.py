"""NEW NN0 owning metadata definitions, UNRUN pending reviewed adoption.

All executables, Cargo/source maps and old/new outer jobs below are synthetic
bytes/records. No tool, native image, model, framework or Search is executed.
The actual maintained helper/execute/finalizer reads bounded fixture files.
Physical/lease/outer-origin ports are disclosed mocks for these definitions;
the eventual software command still needs its own real external guardian.
"""

import copy
from contextlib import nullcontext
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

MAIN = Path("/workspaces/quoridor")
sys.path.insert(0, str(MAIN / "python"))
SOURCE = Path(os.environ.get("ARENA_361_LIFECYCLE", MAIN / "scripts/dev/research-lifecycle.py"))
module = importlib.util.spec_from_file_location("completed_prefix_lifecycle", SOURCE)
lc = importlib.util.module_from_spec(module)
module.loader.exec_module(lc)


class CompletedBuildPrefixTests(unittest.TestCase):
    def file(self, relative, value):
        p = self.root / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        raw = value if isinstance(value, bytes) else (json.dumps(value, indent=2) + "\n").encode()
        p.write_bytes(raw)
        return lc.bound(p)[0]

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.root_patch = patch.object(lc, "ROOT", self.root)
        self.root_patch.start()
        self.addCleanup(self.root_patch.stop)
        self.alive_patch = patch.object(lc.process, "alive", return_value=False)
        self.alive_patch.start()
        self.addCleanup(self.alive_patch.stop)
        self.writer = "codex:synthetic-owner"
        self.old_dir = self.root / "old-operation"
        self.old_dir.mkdir()
        self.target = self.root / "target"
        self.target.mkdir()
        self.private = self.file(
            "private/FAKE_NATIVE_NEVER_EXECUTED", b"not executable; NN0 fixture"
        )
        manifest = self.file("Cargo.toml", b"synthetic Cargo witness")
        lock = self.file("Cargo.lock", b"synthetic lock witness")
        data = self.file("crates/data/lossless_jsonl.rs", b"synthetic codec witness")
        native = self.file("crates/runner/synthetic.rs", b"synthetic native witness")
        before = self.file("scripts/dev/research-lifecycle.py", b"synthetic BEFORE publisher")
        self.old_source = {
            "workspace": str(self.root),
            "commit": "a" * 40,
            "files": [manifest, lock, data, native, before],
            "manifest": manifest,
            "lock": lock,
            "patch": None,
            "compiled_sources": {"data/lossless_jsonl.rs": data, "runner/synthetic.rs": native},
            "generator_compiled_sources": {"runner/synthetic.rs": native},
            "cargo_configs": [],
        }
        self.metadata_source = copy.deepcopy(self.old_source)
        self.metadata_source["generator_compiled_sources"]["data/lossless_jsonl.rs"] = data
        after = self.file("scripts/dev/research-lifecycle.py", b"synthetic AFTER owning publisher")
        self.current_source = copy.deepcopy(self.metadata_source)
        self.current_source["commit"] = "b" * 40
        self.current_source["files"][-1] = after
        self.pair = {"before": before, "after": after}
        cargo_home = self.root / "cargo-home"
        cargo_home.mkdir()
        configs = {
            str(p / ".cargo" / n)
            for p in [self.root, *self.root.parents]
            for n in ("config", "config.toml")
        } | {str(cargo_home / n) for n in ("config", "config.toml")}
        witnesses = [{"path": p, "file": None} for p in sorted(configs)]
        for s in (self.old_source, self.metadata_source, self.current_source):
            s["cargo_configs"] = witnesses
        self.tools = {
            name: {
                "file": self.file("tools/" + name, b"synthetic tool NOT_EXECUTED " + name.encode()),
                "version_args": ["--version"],
                "version": "synthetic " + name + " v1",
            }
            for name in ("CARGO", "RUSTC", "RUSTDOC", "CC", "CXX", "AR", "PYTHON")
        }
        self.support = self.file(
            "support.json",
            {"schema": "quoridor.research.phase-support.v1", "funded_union_B": 2**31},
        )
        self.handover = self.file(
            "handover.json",
            {
                "schema": "research.target-handover.v1",
                "status": "HANDED_OVER",
                "target": str(self.target),
                "target_writer": self.writer,
                "owned_remaining": [],
                "shared_serial_pool": True,
                "old_target": str(self.root / "absent-old-target"),
                "target_max_B": 2**27,
                "private_pool_B": 2**25,
                "fresh_private_root": str(Path(self.private["path"]).parent),
                "fresh_private_forward_max_B": 2**24,
                "private_candidate_upper_B": 2**23,
                "old_private_retained_allocated_B": 0,
            },
        )
        self.file(
            "target/.research-owner.json",
            {
                "writer": self.writer,
                "target": str(self.target),
                "support_sha256": self.support["sha256"],
            },
        )
        cargo = self.tools["CARGO"]["file"]["path"]
        common = [
            "--offline",
            "--locked",
            "--manifest-path",
            manifest["path"],
            "-j1",
            "--message-format=json-render-diagnostics",
        ]
        self.commands = [
            {"name": "compile", "role": "test", "argv": [cargo, "test", *common, "--no-run"]},
            {
                "name": "lint",
                "role": "lint",
                "argv": [cargo, "clippy", *common, "--no-deps", "--", "-Dwarnings"],
            },
            {"name": "release", "role": "build", "argv": [cargo, "build", *common, "--release"]},
            {
                "name": "bindings",
                "role": "bindings",
                "argv": [self.private["path"], "research-bindings"],
            },
        ]
        env = {
            "CARGO_HOME": str(cargo_home),
            "CARGO_TARGET_DIR": str(self.target),
            "TMPDIR": str(self.root / "old-TMP"),
            "CARGO_NET_OFFLINE": "true",
            "RUSTUP_AUTO_INSTALL": "0",
            "CARGO_BUILD_JOBS": "1",
            "CARGO_INCREMENTAL": "0",
            "CARGO_PROFILE_RELEASE_OPT_LEVEL": "3",
            "CARGO_PROFILE_RELEASE_DEBUG": "0",
            **{
                name: self.tools[name]["file"]["path"]
                for name in ("RUSTC", "RUSTDOC", "CC", "CXX", "AR")
            },
        }
        adoption = {
            "schema": "quoridor.research.source-adoption.v1",
            "status": "ACCEPTED",
            "issue": "synthetic-leaf",
            "source": self.old_source,
        }
        self.old = {
            "schema": "quoridor.research.lifecycle-intent.v1",
            "kind": "build",
            "owner": str(self.root),
            "writer": self.writer,
            "cwd": str(self.root),
            "output": str(self.old_dir),
            "target": str(self.target),
            "private": self.private["path"],
            "TMP": env["TMPDIR"],
            "source": self.old_source,
            "source_adoption": self.file("old-source.json", adoption),
            "support": self.support,
            "target_handover": self.handover,
            "tools": self.tools,
            "dependency_refs": [lock],
            "commands": self.commands,
            "env": env,
            "finalizers": [],
            "limits": {"owned_B": 2**27 + 2**25 + 67108864 + 8388608},
        }
        self.old["intent_sha256"] = lc.canonical_sha(self.old)
        self.old["admission"] = self.file(
            "old-admission.json",
            {
                "ready": True,
                "owner": self.old["owner"],
                "limits": self.old["limits"],
                "support_sha256": self.support["sha256"],
                "spec_sha256": self.old["intent_sha256"],
            },
        )
        self.old_intent = self.file("old-intent.json", self.old)
        identity = lambda pid: {
            "pid": pid,
            "start_ticks": str(pid * 10),
            "boot_id": "synthetic-boot",
        }
        cfg = {
            "issue": "synthetic-leaf",
            "thread_id": "synthetic-owner",
            "cwd": str(self.root),
            "argv": [
                self.tools["PYTHON"]["file"]["path"],
                "-B",
                str(self.root / "scripts/dev/research-lifecycle.py"),
                "build",
                "--intent",
                self.old_intent["path"],
                "--sha256",
                self.old_intent["sha256"],
            ],
        }
        self.origin = {
            "runtime": str(self.root / "old-runtime"),
            "job_id": "synthetic-old-job",
            "supervisor": identity(1),
            "child": identity(2),
            "config": self.file("old-runtime/config.json", cfg),
            "config_sha256": lc.sha(json.dumps(cfg, sort_keys=True).encode()),
        }
        state = {
            "phase": "finished",
            "job_id": self.origin["job_id"],
            "supervisor": self.origin["supervisor"],
            "child": self.origin["child"],
            "config_sha256": self.origin["config_sha256"],
            "outcome": "failed",
        }
        outer = {
            "job_id": self.origin["job_id"],
            "outcome": "failed",
            "exit_code": 1,
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
            "cleanup_errors": [],
        }
        self.old_outer_ref = self.file("old-runtime/result.json", outer)
        self.maps = {k: r["sha256"] for k, r in self.metadata_source["compiled_sources"].items()}
        self.generator = {
            k: r["sha256"] for k, r in self.metadata_source["generator_compiled_sources"].items()
        }
        self.native_metadata = {
            "compiled_sources": self.maps,
            "generator_compiled_sources": self.generator,
            "model_calls": 0,
            "executable_sha256": self.private["sha256"],
        }
        rows = [
            {
                "name": "version-" + k.lower(),
                "role": "version",
                "argv": [t["file"]["path"], *t["version_args"]],
            }
            for k, t in self.tools.items()
        ] + self.commands
        checks = []
        for i, row in enumerate(rows):
            if row["role"] == "version":
                raw = (self.tools[row["name"][8:].upper()]["version"] + "\n").encode()
            elif row["role"] == "bindings":
                raw = json.dumps(self.native_metadata).encode()
            else:
                records = []
                if row["role"] == "build":
                    records.append(
                        {
                            "reason": "compiler-artifact",
                            "target": {"name": "quoridor-runner", "kind": ["bin"]},
                            "profile": {"test": False},
                            "executable": str(self.target / "release/FAKE_NATIVE"),
                        }
                    )
                records.append({"reason": "build-finished", "success": True})
                raw = b"\n".join(json.dumps(r).encode() for r in records) + b"\n"
            returned = {
                "command": row["argv"],
                "child": identity(10 + i),
                "status": "complete",
                "exit_code": 0,
                "direct_child_reaped": True,
                "cleanup_complete": True,
                "remaining": [],
                "finalization_errors": [],
                "primary_error": None,
                "process_cleanup_complete": True,
                "handle_closes_complete": True,
                "signal_mask_restoration": "completed",
                "final_record_persist": "completed",
                "log_bytes_seen": len(raw),
                "log_bytes_retained": len(raw),
            }
            disk = {
                **returned,
                "signal_mask_restoration": "pending",
                "final_record_persist": "attempted",
            }
            check = {
                **row,
                "status": "PASS",
                "primary": None,
                "secondary": [],
                "capture_complete": True,
                "guardian_return": returned,
                "full_log": self.file("old-operation/" + row["name"] + ".full.log", raw),
                "persisted_process_receipt": self.file(
                    "old-operation/" + row["name"] + ".process.json", disk
                ),
            }
            if row["role"] not in ("version", "bindings"):
                check["cargo"] = lc.cargo_report(raw)
            checks.append(check)
        primary = {"type": "Refused", "message": "current generator source binding", "notes": []}
        self.prior = {
            "schema": lc.BUILD_SCHEMA,
            "kind": "build",
            "status": "FAILED",
            "cleanup_complete": True,
            "process_cleanup_complete": True,
            "remaining": [],
            "owed_finalizers": [],
            "primary": primary,
            "secondary": [
                {"stage": "candidate", "facts": primary},
                {
                    "stage": "outer_job",
                    "type": "Refused",
                    "message": "outer job unsuccessful or not cleaned",
                    "notes": [],
                    "available_result": outer,
                },
            ],
            "authoritative_finished_at": "synthetic-finished",
            "intent": self.old_intent,
            "originating_job": self.origin,
            "outer_job_state": self.file("old-runtime/state.json", state),
            "outer_job_result": self.old_outer_ref,
            "compiled_sources": self.maps,
            "checks": checks,
        }
        self.metadata_adoption = self.file(
            "metadata-source.json", {**adoption, "source": self.metadata_source}
        )
        self.spec = {
            **copy.deepcopy(self.old),
            "source": self.current_source,
            "output": str(self.root / "new-operation"),
            "TMP": str(self.root / "new-TMP"),
        }
        self.spec["env"]["TMPDIR"] = self.spec["TMP"]
        self.rebind()

    def rebind(self):
        self.prefix_ref = self.file("old-operation/manifest.json", self.prior)
        adoption = {
            "schema": "quoridor.research.source-adoption.v1",
            "status": "ACCEPTED",
            "issue": "synthetic-leaf",
            "source": self.spec["source"],
            "completed_build_prefix": {
                "manifest": self.prefix_ref,
                "artifact": self.private,
                "metadata_source_adoption": self.metadata_adoption,
                "publisher": self.pair,
            },
        }
        self.spec["completed_prefix"] = self.prefix_ref
        self.spec["source_adoption"] = self.file("current-source.json", adoption)
        self.spec.pop("admission", None)
        self.spec.pop("intent_sha256", None)
        self.spec["intent_sha256"] = lc.canonical_sha(self.spec)
        self.spec["admission"] = self.file("new-admission.json", {})
        return self.file("new-intent.json", self.spec)

    def test_completed_prefix_preserves_exact_original_scopes_and_flat_native_shape(self):
        p = lc.completed_build_prefix(self.spec)
        self.assertEqual(p["checks"], self.prior["checks"])
        self.assertEqual(p["artifact"], self.private)
        self.assertEqual(p["generator_compiled_sources"], self.generator)
        for index, retained in enumerate(p["retained_checks"]):
            self.assertEqual(retained["origin_operation"], self.prefix_ref)
            self.assertEqual(retained["origin_check_index"], index)
            self.assertEqual(
                {
                    k: v
                    for k, v in retained.items()
                    if k not in {"origin_operation", "origin_check_index"}
                },
                self.prior["checks"][index],
            )
            self.assertEqual(retained["guardian_return"]["signal_mask_restoration"], "completed")
            self.assertEqual(
                lc.document(retained["persisted_process_receipt"])["signal_mask_restoration"],
                "pending",
            )
        lc.build_check(self.spec)
        self.assertFalse(Path(self.spec["TMP"]).exists())

    def test_completed_prefix_refuses_drift_unknown_capture_foreign_origin_and_partial(self):
        baseline = copy.deepcopy(self.prior)
        changes = [
            ("failed_scope", lambda p: p["checks"][-1].update(status="FAILED")),
            ("unknown_return", lambda p: p["checks"][-1].update(guardian_return=None)),
            (
                "unknown_handles",
                lambda p: p["checks"][-1]["guardian_return"].update(handle_closes_complete=None),
            ),
            ("incomplete_capture", lambda p: p["checks"][-1].update(capture_complete=False)),
            (
                "pending_return",
                lambda p: p["checks"][-1]["guardian_return"].update(
                    signal_mask_restoration="pending"
                ),
            ),
            ("missing_scope", lambda p: p["checks"].pop()),
            ("changed_argv", lambda p: p["checks"][-1]["argv"].append("unselected")),
            ("failed_cleanup", lambda p: p.update(cleanup_complete=False)),
            ("foreign_origin", lambda p: p["originating_job"].update(job_id="foreign")),
            ("additional_error", lambda p: p["secondary"].append({"stage": "unresolved"})),
        ]
        for label, mutate in changes:
            with self.subTest(label=label):
                self.prior = copy.deepcopy(baseline)
                mutate(self.prior)
                self.rebind()
                with self.assertRaises((lc.Refused, KeyError, TypeError)):
                    lc.completed_build_prefix(self.spec)
        self.prior = copy.deepcopy(baseline)
        self.rebind()
        for field in ("env", "tools", "commands", "source"):
            with self.subTest(drift=field):
                spec = copy.deepcopy(self.spec)
                if field == "env":
                    spec[field]["CARGO_INCREMENTAL"] = "1"
                elif field == "tools":
                    spec[field]["CARGO"]["version"] = "changed"
                elif field == "commands":
                    spec[field][0]["argv"].append("--other")
                else:
                    spec[field]["compiled_sources"]["runner/synthetic.rs"]["sha256"] = "0" * 64
                with self.assertRaises(lc.Refused):
                    lc.completed_build_prefix(spec)
        marker = self.old_dir / "INCOMPLETE"
        marker.write_bytes(b"pending")
        with self.assertRaises(lc.Refused):
            lc.completed_build_prefix(self.spec)
        marker.unlink()
        capture = Path(self.prior["checks"][-1]["full_log"]["path"])
        raw = capture.read_bytes()
        capture.write_bytes(raw + b"torn trailing bytes")
        with self.assertRaises(lc.Refused):
            lc.completed_build_prefix(self.spec)
        capture.write_bytes(raw)
        image = Path(self.private["path"])
        image.write_bytes(b"changed binary bits")
        with self.assertRaises(lc.Refused):
            lc.completed_build_prefix(self.spec)

    def test_completed_prefix_normal_new_origin_finalization_without_any_executor_call(self):
        old_bytes = Path(self.prefix_ref["path"]).read_bytes()
        spec_ref = self.rebind()
        own_runtime = self.root / "new-runtime"
        new_origin = copy.deepcopy(self.origin)
        new_origin.update(runtime=str(own_runtime), job_id="new-owning-job")
        cfg = {
            "cwd": self.spec["cwd"],
            "argv": [
                sys.executable,
                "-B",
                str(self.root / "scripts/dev/research-lifecycle.py"),
                "build",
                "--intent",
                spec_ref["path"],
                "--sha256",
                spec_ref["sha256"],
            ],
        }
        new_origin["config"] = self.file("new-runtime/config.json", cfg)
        new_origin["config_sha256"] = lc.sha(json.dumps(cfg, sort_keys=True).encode())

        class Resources:
            def __init__(self, _):
                pass

            def check(self, *_):
                pass

        def forbidden(*_, **__):
            raise AssertionError("No tool/compiler/native executor may run for this completion")

        with patch.object(lc, "originating_job", return_value=new_origin):
            result = lc.execute(
                spec_ref,
                executor=forbidden,
                guard=lambda _: None,
                lock=nullcontext,
                resource_factory=Resources,
            )
        self.assertEqual(result["originating_job"]["job_id"], "new-owning-job")
        self.assertEqual(result["status"], "PENDING_FINALIZATION")
        self.assertEqual(result["commands_executed"], 0)
        self.assertTrue(result["process_cleanup_complete"])
        self.assertFalse(Path(self.spec["TMP"]).exists())
        state = {
            "phase": "finished",
            "job_id": "new-owning-job",
            "supervisor": new_origin["supervisor"],
            "child": new_origin["child"],
            "config_sha256": new_origin["config_sha256"],
            "outcome": "succeeded",
        }
        self.file("new-runtime/state.json", state)
        job_ref = self.file(
            "new-runtime/result.json",
            {
                "job_id": "new-owning-job",
                "outcome": "succeeded",
                "exit_code": 0,
                "finished_at": "synthetic-new-finished",
                "direct_child_reaped": True,
                "cleanup_complete": True,
                "remaining": [],
                "cleanup_errors": [],
            },
        )
        finished = lc.finalize(
            Path(self.spec["output"]),
            job_ref,
            guard=lambda _: None,
            lock=nullcontext,
            resource_factory=Resources,
        )
        self.assertEqual(finished["status"], "PASS")
        self.assertTrue(finished["cleanup_complete"])
        self.assertFalse((Path(self.spec["output"]) / "INCOMPLETE").exists())
        actual = lc.accepted_build(lc.bound(Path(self.spec["output"]) / "manifest.json")[0])
        self.assertEqual(actual["originating_job"]["job_id"], "new-owning-job")
        self.assertEqual(Path(self.prefix_ref["path"]).read_bytes(), old_bytes)
        self.assertEqual(lc.document(self.prefix_ref)["status"], "FAILED")
        self.assertEqual(lc.document(self.old_outer_ref)["exit_code"], 1)

    def test_completed_prefix_new_failed_outer_job_cannot_inherit_old_command_success(self):
        old_bytes = Path(self.prefix_ref["path"]).read_bytes()
        spec_ref = self.rebind()
        own_runtime = self.root / "new-runtime"
        new_origin = copy.deepcopy(self.origin)
        new_origin.update(runtime=str(own_runtime), job_id="new-owning-job")
        cfg = {
            "cwd": self.spec["cwd"],
            "argv": [
                sys.executable,
                "-B",
                str(self.root / "scripts/dev/research-lifecycle.py"),
                "build",
                "--intent",
                spec_ref["path"],
                "--sha256",
                spec_ref["sha256"],
            ],
        }
        new_origin["config"] = self.file("new-runtime/config.json", cfg)
        new_origin["config_sha256"] = lc.sha(json.dumps(cfg, sort_keys=True).encode())

        class Resources:
            def __init__(self, _):
                pass

            def check(self, *_):
                pass

        def forbidden(*_, **__):
            raise AssertionError("No tool/compiler/native executor may run for this completion")

        with patch.object(lc, "originating_job", return_value=new_origin):
            result = lc.execute(
                spec_ref,
                executor=forbidden,
                guard=lambda _: None,
                lock=nullcontext,
                resource_factory=Resources,
            )
        self.assertEqual(result["originating_job"]["job_id"], "new-owning-job")
        self.assertEqual(result["status"], "PENDING_FINALIZATION")
        self.assertEqual(result["commands_executed"], 0)
        self.assertTrue(result["process_cleanup_complete"])
        self.assertFalse(Path(self.spec["TMP"]).exists())
        state = {
            "phase": "finished",
            "job_id": "new-owning-job",
            "supervisor": new_origin["supervisor"],
            "child": new_origin["child"],
            "config_sha256": new_origin["config_sha256"],
            "outcome": "failed",
        }
        self.file("new-runtime/state.json", state)
        job_ref = self.file(
            "new-runtime/result.json",
            {
                "job_id": "new-owning-job",
                "outcome": "failed",
                "exit_code": 1,
                "finished_at": "synthetic-new-finished",
                "direct_child_reaped": True,
                "cleanup_complete": True,
                "remaining": [],
                "cleanup_errors": [],
            },
        )
        finished = lc.finalize(
            Path(self.spec["output"]),
            job_ref,
            guard=lambda _: None,
            lock=nullcontext,
            resource_factory=Resources,
        )
        self.assertEqual(finished["status"], "FAILED")
        self.assertTrue(finished["cleanup_complete"])
        self.assertFalse((Path(self.spec["output"]) / "INCOMPLETE").exists())
        with self.assertRaises(lc.Refused):
            lc.accepted_build(lc.bound(Path(self.spec["output"]) / "manifest.json")[0])
        self.assertTrue(any(e["stage"] == "outer_job" for e in finished["secondary"]))
        self.assertEqual(Path(self.prefix_ref["path"]).read_bytes(), old_bytes)
        self.assertEqual(lc.document(self.prefix_ref)["status"], "FAILED")
        self.assertEqual(lc.document(self.old_outer_ref)["exit_code"], 1)


if __name__ == "__main__":
    unittest.main()
