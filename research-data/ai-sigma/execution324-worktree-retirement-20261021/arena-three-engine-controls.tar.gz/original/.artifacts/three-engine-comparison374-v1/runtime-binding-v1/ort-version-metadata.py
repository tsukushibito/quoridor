"""Read the maintained OrtApiBase metadata ABI; never create a model session."""

import ctypes
import hashlib
import json
import os
import stat
import sys
from pathlib import Path


def ref(path):
    path = Path(path)
    before = path.stat()
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_dev,
        after.st_ino,
        after.st_size,
        after.st_mtime_ns,
    )
    return {
        "path": str(path),
        "sha256": digest.hexdigest(),
        "bytes": after.st_size,
        "mode": format(stat.S_IMODE(after.st_mode), "04o"),
    }


def mapped_elf_paths():
    paths = set()
    for line in Path("/proc/self/maps").read_text().splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) != 6 or not fields[5].startswith("/"):
            continue
        assert not fields[5].endswith(" (deleted)"), "deleted mapped file"
        path = Path(fields[5])
        with path.open("rb") as source:
            if source.read(4) == b"\x7fELF":
                paths.add(str(path))
    return paths


# Exact two function-pointer fields from maintained onnxruntime_c_api.h OrtApiBase.
GET_API = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_uint32)
GET_VERSION = ctypes.CFUNCTYPE(ctypes.c_char_p)


class OrtApiBase(ctypes.Structure):
    _fields_ = [("GetApi", GET_API), ("GetVersionString", GET_VERSION)]


library_path = Path(sys.argv[1]).resolve(strict=True)
before_ref = ref(library_path)
baseline = mapped_elf_paths()
library = ctypes.CDLL(str(library_path), mode=os.RTLD_NOW | os.RTLD_LOCAL)
entry = library.OrtGetApiBase
entry.argtypes = []
entry.restype = ctypes.POINTER(OrtApiBase)
base = entry()
assert base, "missing OrtApiBase"
version = base.contents.GetVersionString().decode("utf-8")
assert version and len(version) < 128
api23_supported = bool(base.contents.GetApi(23))
assert api23_supported, "maintained native ABI API23 unsupported"
loaded = mapped_elf_paths()
assert str(library_path) in loaded, "named library absent from actual mappings"
mapped_refs = [ref(p) for p in sorted(loaded)]
assert ref(library_path) == before_ref, "library changed while loaded"
print(
    json.dumps(
        {
            "scope": "Actual C API metadata only; no CreateEnv/CreateSession/Run/backend construction",
            "library": before_ref,
            "loaded_version": version,
            "api23_supported": api23_supported,
            "actual_loaded_ELF_FileRefs": mapped_refs,
            "ELF_paths_added_by_ORT_load": sorted(loaded - baseline),
            "baseline_ELF_paths": sorted(baseline),
            "model_sessions": 0,
            "model_calls": 0,
            "current_Rust_backend_factory_checked": False,
            "process_id": os.getpid(),
            "exit_releases_loaded_library": True,
        }
    )
)
