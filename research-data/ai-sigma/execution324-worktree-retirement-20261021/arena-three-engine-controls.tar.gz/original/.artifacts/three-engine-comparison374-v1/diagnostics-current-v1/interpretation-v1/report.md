# Saved common-position diagnostics374

The original234 single proposals completed on all78 frozen parents:78 each from Sigma, fixed-D-evaluator alpha search, and BEST43 NNUE alpha search. All234 saved outcomes passed the maintained plan/publication/clock/terminal reader checks. No proposal is missing or UNKNOWN, no zero-completed fallback was selected, and no new native/Search/model/head call was made by this interpretation. The original18 unavailable source milestones remain excluded without replacement. This is a common-position action comparison, not games, a teacher oracle, or a strength estimate.

All three actions agree on22/78 parents (28.2%); at least two differ on56/78 (71.8%).

| Saved action comparison | Same | Different | Compared parents |
|---|---:|---:|---:|
| Sigma vs fixed-D evaluator | 33 | 45 | 78 |
| Sigma vs BEST43 NNUE | 36 | 42 | 78 |
| fixed-D evaluator vs BEST43 NNUE | 27 | 51 | 78 |

Differences identify positions for inspection; they do not identify the correct engine. The fixed-D label names its evaluator, not a completed depth6 search. It completed depths3–64 (depth4 on56 parents); NNUE completed depths3–64 (depth3 on30 and depth4 on29). Sigma completed21–64 simulations, arithmetic mean26. All selected responses have real receipt before their deadline and matching terminal/drain records. These observations describe this run only.

| Engine | Accepted / planned | Mean selected receipt (ms) | Maximum receipt (ms) | Mean terminal/drain (ms) |
|---|---:|---:|---:|---:|
| Sigma | 78 / 78 | 90.729 | 94.966 | 94.659 |
| fixedD | 78 / 78 | 51.877 | 92.732 | 93.873 |
| BEST43-NNUE | 78 / 78 | 41.762 | 94.870 | 93.852 |

Receipt refers to the actual selected completed response; terminal/drain can finish later. It is not predicted inference latency or a hard-realtime guarantee. Sigma stopped via decision notification74, internal time limit1, simulation cap3; both alpha engines stopped via internal time limit77 and depth cap1. No inference prediction/calibration prerequisite is revived.

The machine result retains the existing reader's first12 disagreement examples with action/PV/accepted depth/stop/counters and explicit value roles. Sigma root NN/rootmean/selected-child Q and alpha searched-root values are distinct quantities. NNUE static pretanh/posttanh/saturation are UNKNOWN_NOT_RECORDED; searched values cannot substitute for them. Position-trait counters were absent, so the maintained diagnostic-strata output is empty. Neither gap is filled by geometry replay, another forward, or a new diagnostic campaign.

All234 diagnostics belong to one original Build3a131494/artifact4fe17a0a cohort, CPU AI1/4 and main6, child affinity1/4/6, synchronous per-AI evaluation. This is distinct from earlier primary arena artifact/cohort records; no mixed-cohort interval or bootstrap is computed. The original primary762/768 validated games and381 complete pairs remain separate. Six original FAILED/UNKNOWN slots0/1/2/3/12/13 and their RAW remain immutable and are never replayed or promoted.

Original lifecycle census234 PASS, errors[]. Original operation command wall62.64187888606102s is counted once; native wall/archive rows remain separate observations and are not added to controller/command wall. Original aggregate and Root completion preserve all other fees/partial/UNKNOWN facts. Returned guardians234 report mask restoration completed/persist completed; all234 original persisted receipts retain pending/attempted. No historical record was rewritten.

This interpretation uses original settings-v4, sequence result11c9d839 and completion55e47a6d, referenced in result.json; native manifests and journals are joined through the original authoritative per-operation records. Saved-only reader wall2.682968431006884s, source/caller reader STOP2026-10-13T20:13:58.588270Z, canonical release20:13:58.590411Z, remaining readers/children/jobs/TMP/leases[]. Common-entry wrapper directwait exited0; environment SH ended at wrapper return, independent release UTC unknown. CPU3/RAM512MiB/GPU0, fresh physical/namedquiet/canonicalNB/environment guards; storage omitted.

The finite diagnostic scope is fully recorded. Next is Root's integration of the saved interpretation alongside the separate primary result; no outstanding proposal, model/head check, replay, new CI/bootstrap, or scientific launch is authorized or required by this report. Any important adopted strength conclusion retains the existing narrow related-review boundary. Defaults/N/seals/fits96 and323 USERPAUSE remain unchanged.
