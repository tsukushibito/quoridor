"""Prepare the already selected saved-parent decisions; never launch native work."""

import copy
import gzip
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
loader = importlib.util.spec_from_file_location("lc", ROOT / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def saved(name):
    return json.loads(gzip.decompress((BASE / (name + "-before.json.gz")).read_bytes()))


def write(path, value):
    lc.new_json(path, value)
    return lc.bound(path)[0]


def main():
    lc.physical_and_quiet(
        {
            "kind": "run",
            "limits": {
                "family_B": 512 * 1024**2,
                "host_reserve_B": 4 * 1024**3,
                "worker_cpu": 3,
                "guardian_cpu": 6,
            },
        }
    )
    with lc.lease():
        template = json.loads((BASE / "actual-template.json").read_text())
        plan = saved("plan")
        old_experiment = saved("experiment")
        config = saved("config")
        book_ref = json.loads((BASE / "diagnostic-book-v1.json.ref.json").read_text())
        schedule_ref = json.loads((BASE / "diagnostic-schedule-v1.json.ref.json").read_text())
        book = lc.document(book_ref)
        schedule = lc.document(schedule_ref)
        assert len(book["openings"]) == 78 and len(schedule) == 234
        matchups = [
            {
                "id": 0,
                "engines": [plan["matchups"][0]["engines"][0]],
                "evaluator_sha256": [plan["matchups"][0]["evaluator_sha256"][0]],
                "inference": plan["matchups"][0]["inference"],
            },
            {
                "id": 1,
                "engines": [plan["matchups"][0]["engines"][1]],
                "evaluator_sha256": [plan["matchups"][0]["evaluator_sha256"][1]],
            },
            {
                "id": 2,
                "engines": [plan["matchups"][1]["engines"][1]],
                "evaluator_sha256": [plan["matchups"][1]["evaluator_sha256"][1]],
            },
        ]
        inputs = [book_ref, *[ref for ref in plan["inputs"] if ref != plan["book"]]]
        new_plan = {
            **plan,
            "phase": "compare",
            "book": book_ref,
            "inputs": inputs,
            "schedule": schedule_ref,
            "family_ids": list(range(78)),
            "matchups": matchups,
            "batches": [],
            "planned_slots": 234,
        }
        configs = BASE / "configs-v1"
        configs.mkdir()
        for index, slot in enumerate(schedule):
            assert slot == {
                "slot": index,
                "batch": index,
                "matchup": index % 3,
                "local_game": 0,
                "family_id": index // 3,
                "candidate_color": 0,
            }
            matchup = matchups[slot["matchup"]]
            c = copy.deepcopy(config)
            c.update(
                run_id=f"374-decisions-parent-{slot['family_id']:03d}-engine-{slot['matchup']}",
                output=str(BASE / "output-v1" / f"batch-{index:03d}" / "data"),
                games=1,
                engines=matchup["engines"],
                inference=matchup.get("inference"),
            )
            c["arena"].update(
                decision_only=True,
                evaluator_sha256=matchup["evaluator_sha256"],
                search_artifact_sha256=[template["artifact"]["sha256"]],
                book={**book, "openings": [book["openings"][slot["family_id"]]]},
            )
            ref = write(configs / f"batch-{index:03d}.json", c)
            new_plan["batches"].append(
                {"batch": index, "matchup": slot["matchup"], "config": ref, "slots": [index]}
            )
        plan_ref = write(BASE / "plan.derivative-v1.json", new_plan)
        experiment = copy.deepcopy(old_experiment)
        experiment.update(
            phase="compare",
            config=new_plan["batches"][0]["config"],
            inputs=inputs,
            schedule=schedule_ref,
            canonical_plan_sha256=plan_ref["sha256"],
            planned_slots=234,
            batch=0,
        )
        experiment["argv"][1] = "decisions"
        prior = saved("numerical")
        manifest = lc.accepted_build(experiment["build_manifest"])
        numerical = lc.numerical_fields(experiment, manifest)
        for key in ("original_evidence", "correspondence_only", "scope", "new_model_or_head_calls"):
            numerical[key] = prior[key]
        experiment["numerical_qualification"] = write(
            BASE / "numerical-template-v1.json", numerical
        )
        experiment_ref = write(BASE / "experiment-template-v1.json", experiment)
        template.update(
            experiment=experiment_ref,
            approved_plan=plan_ref,
            data_root=lc.document(experiment["config"])["output"],
        )
        template["argv"] = [
            a.replace("@EXPERIMENT@", experiment_ref["path"]).replace(
                "@EXPERIMENT_SHA256@", experiment_ref["sha256"]
            )
            for a in experiment["argv"]
        ]
        template["output"] = str(BASE / "template-operation-v1")
        template["TMP"] = str(BASE / "template-TMP-v1")
        template["env"]["TMPDIR"] = template["TMP"]
        template["caller_sources"] = [
            lc.bound(ref["path"])[0] for ref in template["caller_sources"]
        ]
        template["owned_outputs"] = [*template["owned_outputs"], str(BASE)]
        for item in template["data"]:
            item["path"] = str(Path(template["data_root"]) / Path(item["path"]).name)
        settings = {
            "kind": "sequence",
            "output": str(BASE / "sequence-v1"),
            "arena": {"range": [0, 233], "template": template},
            "measurements": [],
            "arena_block": 234,
            "serial_order": ["arena", "measure"],
        }
        settings_ref = write(BASE / "settings.derivative-v1.json", settings)
        planned, _ = lc.arena_decision_plan_check(experiment, new_plan)
        assert len(planned) == 1
        stop = lc.stamp()
    write(
        BASE / "preparation-STOP.json",
        {
            "settings": settings_ref,
            "plan": plan_ref,
            "experiment": experiment_ref,
            "status": "PREPARED_NOT_ADOPTED",
            "remaining": [
                "Root canonical plan adoption",
                "finite compare/decisions intake correction in Python and native",
                "genuine compatible native artifact after correction and truthful current config bindings",
                "normal scientific admission/fresh guards",
            ],
            "parents": 78,
            "proposals": 234,
            "frozen_missing": 18,
            "new_native_model_head_calls": 0,
            "reader_STOP": stop,
            "owned_remaining": [],
        },
    )
    print(json.dumps({"settings": settings_ref, "reader_STOP": stop, "owned_remaining": []}))


if __name__ == "__main__":
    main()
