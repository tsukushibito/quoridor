"""Interpret immutable diagnostic proposals using maintained saved publication readers."""

from collections import Counter, defaultdict
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent / "current-v2"
BASE = OUT.parent.parent
loader = importlib.util.spec_from_file_location(
    "lc", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def diagnostic_summary(decisions, decision_rows, config):
    # Same descriptive diagnostic section as the maintained arena_analysis;
    # no primary-game interval/bootstrap stage is invoked.
    result = {}
    by_parent = {}
    diagnostic_counts = {
        "planned": len(decisions),
        "proposed": 0,
        "unknown": 0,
        "missing": 0,
    }
    examples = []
    for slot in decisions:
        item = decision_rows.get(slot["slot"])
        if item is None:
            diagnostic_counts["missing"] += 1
            diagnostic_counts["unknown"] += 1
            continue
        row, c = item
        observation = row["observations"][0] if row["observations"] else None
        if (
            row["status"] != "decision"
            or observation is None
            or not observation["accepted"]
        ):
            diagnostic_counts["unknown"] += 1
            continue
        diagnostic_counts["proposed"] += 1
        by_parent.setdefault(slot["family_id"], []).append((slot, observation))
    disagreements = 0
    complete = 0
    for parent, rows in sorted(by_parent.items()):
        if len(rows) != 3:
            continue
        complete += 1
        if len({obs["action"] for _, obs in rows}) > 1:
            disagreements += 1
            if len(examples) < 12:
                examples.append(
                    {
                        "parent": parent,
                        "selection": config["diagnostic_selection"],
                        "proposals": [
                            {
                                "slot": slot["slot"],
                                "engine": slot["matchup"],
                                "action": obs["action"],
                                "PV": obs["pv"],
                                "accepted_depth": obs["completed_depth"],
                                "stop": obs["stop"],
                                "searched_value_stm": obs["value_stm"]
                                if slot["matchup"] != 0
                                else None,
                                "value_role": "Sigma rootmean"
                                if slot["matchup"] == 0
                                else "alpha searched root; not NNUE static",
                                "Sigma_root_nn": obs["counters"].get("root_nn"),
                                "Sigma_rootmean": obs["counters"].get("root_mean"),
                                "Sigma_selected_child_q": obs["counters"].get(
                                    "selected_child_q"
                                ),
                                "counters": obs["counters"],
                                "NNUE_static_pretanh": None,
                                "NNUE_static_posttanh": None,
                                "NNUE_saturation": None,
                                "missing_metric_reason": "not recorded by admitted same-forward path; searched/terminal values are not NNUE static outputs",
                            }
                            for slot, obs in rows
                        ],
                    }
                )
    diagnostic_strata = {}
    for parent, rows in sorted(by_parent.items()):
        if len(rows) != 3:
            continue
        traits = rows[0][1]["counters"].get("parent_traits")
        if traits is None:
            continue
        disagreement = len({obs["action"] for _, obs in rows}) > 1
        for name in (
            "stock_sum_stratum",
            "distance_difference_stratum",
            "either_distance_le_2",
            "pawn_contact",
            "legal_jump_available",
            "current_repetition_count",
            "any_recorded_repetition",
            "phase_stratum",
        ):
            key = (name, str(traits[name]))
            cell = diagnostic_strata.setdefault(key, {"parents": 0, "disagreements": 0})
            cell["parents"] += 1
            cell["disagreements"] += int(disagreement)
    result["diagnostic_strata"] = [
        {"trait": key[0], "stratum": key[1], **cell}
        for key, cell in sorted(diagnostic_strata.items())
    ]
    result["diagnostics"] = {
        **diagnostic_counts,
        "complete_three_engine_parents": complete,
        "action_disagreement_parents": disagreements,
        "linked_examples": examples,
        "NNUE_pretanh_posttanh_saturation": "UNKNOWN_NOT_RECORDED_NO_EXTRA_FORWARD",
    }
    return result


def main():
    affinity = sorted(os.sched_getaffinity(0))
    os.sched_setaffinity(0, affinity)
    spec = {
        "kind": "software",
        "limits": {
            "family_B": 512 * 1024**2,
            "host_reserve_B": 4 * 1024**3,
            "worker_cpu": 3,
            "guardian_cpu": 4,
        },
    }
    lc.physical_and_quiet(spec)
    primary = None
    summary = None
    started = lc.stamp()
    wall_start = lc.time.monotonic()
    with (
        lc.lease(),
        Path(os.environ["QUORIDOR_PROJECT_ENV"] + ".setup.lock").open("r") as env,
    ):
        fcntl.flock(env, fcntl.LOCK_SH | fcntl.LOCK_NB)
        os.sched_setaffinity(0, {3})
        resources = lc.process.CycleResources(
            {
                "host_ram_reserve": 4 * 1024**3,
                "max_memory_bytes": 512 * 1024**2,
                "max_output_bytes": None,
            },
            OUT,
            None,
        )
        source_paths = [
            ROOT / "scripts/dev/research-lifecycle.py",
            ROOT / "scripts/dev/project-env.sh",
            ROOT / "python/quoridor_training/cycle_process.py",
            ROOT / "python/quoridor_training/snapshot.py",
            Path(__file__).resolve(),
            Path(sys.executable).resolve(),
            Path(sys.prefix) / "pyvenv.cfg",
        ]
        source_refs = [lc.bound(p, 128 * 1024**2)[0] for p in source_paths]
        intake_ref = lc.bound(OUT.parent / "intake.json")[0]
        intake = lc.document(intake_ref)
        try:
            completion = lc.document(intake["completion"])
            aggregate = lc.document(intake["aggregate"])
            settings = lc.document(intake["settings"])
            lc.require(
                completion["aggregate"] == intake["aggregate"]
                and completion["original_settings"]
                == aggregate["settings"]
                == intake["settings"],
                "original saved joins",
            )
            lc.require(
                aggregate["status"] == completion["status"] == "PASS"
                and aggregate["completed_operations"]
                == completion["completed_operations"]
                == 234
                and settings["arena"]["range"] == [0, 233]
                and len(aggregate["operations"]) == 234,
                "original complete selected234",
            )
            plan = lc.document(intake["plan"])
            schedule = lc.document(plan["schedule"])
            book = lc.document(plan["book"])
            selection_refs = {
                json.dumps(o["reference"]["settings"]["selection"], sort_keys=True)
                for o in book["openings"]
            }
            lc.require(len(selection_refs) == 1, "one frozen parent selection")
            selection_ref = json.loads(next(iter(selection_refs)))
            selection = lc.document(selection_ref)
            lc.require(
                len(book["openings"]) == len(selection["parents"]) == 78
                and len(selection["exclusions"]) == 18
                and len(schedule) == 234,
                "original78/234/18 scope",
            )
            rows = {}
            cohorts = {}
            native_costs = []
            operation_wall = 0.0
            returned_mask = Counter()
            persisted_mask = Counter()
            lifecycle_counts = Counter()
            engine_counts = defaultdict(Counter)
            engine_times = defaultdict(lambda: defaultdict(list))
            errors = []
            for op in aggregate["operations"]:
                resources.check()
                batch = op["index"]
                m = lc.document(op["manifest"])
                e = lc.document(m["experiment"])
                intent = lc.document(m["intent"])
                job_result = lc.document(op["job_result"])
                lifecycle_counts[m["status"]] += 1
                lc.require(
                    op["completed"]
                    and m["status"] == "PASS"
                    and m["primary"] is None
                    and m["secondary"] == []
                    and m["cleanup_complete"]
                    and m["remaining"] == []
                    and job_result["outcome"] == "succeeded",
                    "original lifecycle settled",
                )
                lc.require(
                    intent["approved_plan"] == intake["plan"]
                    and e["canonical_plan_sha256"] == intake["plan"]["sha256"]
                    and intent["experiment"] == m["experiment"]
                    and e["batch"] == batch,
                    "original subject correspondence",
                )
                planned, config = lc.arena_decision_plan_check(e, plan)
                build = lc.document(e["build_manifest"])
                by_path = {r["path"]: r for r in m["data"]["files"]}
                files = {
                    name: by_path[str(Path(config["output"]) / filename)]
                    for name, filename in (
                        ("journal", "completed.jsonl.gz"),
                        ("result", "result.json"),
                        ("native_manifest", "manifest.json"),
                    )
                }
                native = lc.arena_reference_report(config, files, expected_build=build)
                lc.require(
                    native["schema"] == "quoridor-decisions-v1"
                    and native["all_workers_joined"]
                    and native["stopped"] is None
                    and native["dataset"] is None
                    and native["score"] is None
                    and native["rows"] == 0
                    and len(native["outcomes"]) == len(planned) == 1,
                    "decision census, no game/score/dataset",
                )
                pub = json.loads(lc.read_ref(files["result"]))
                for check in m["checks"]:
                    returned = check.get("guardian_return")
                    if returned is not None:
                        operation_wall += returned["wall_seconds"]
                        returned_mask[
                            (
                                returned["signal_mask_restoration"],
                                returned["final_record_persist"],
                            )
                        ] += 1
                    if check.get("persisted_process_receipt") is not None:
                        disk = lc.document(check["persisted_process_receipt"])
                        persisted_mask[
                            (
                                disk["signal_mask_restoration"],
                                disk["final_record_persist"],
                            )
                        ] += 1
                native_costs.append(
                    {
                        "slot": planned[0]["slot"],
                        "native_wall_seconds": native["wall_seconds"],
                        "archive_wall_seconds": pub["archive_wall_seconds"],
                        "archive_allocated_bytes": pub["archive_allocated_bytes"],
                    }
                )
                key = e["build_manifest"]["sha256"]
                if key not in cohorts:
                    cohorts[key] = {
                        "build": e["build_manifest"],
                        "artifact": build["artifact"],
                        "planned_proposals": 0,
                        "AI_cores": config["cpu_cores"],
                        "main_core": config.get("management_cpu_core"),
                        "inference_cpu_core": config.get("inference_cpu_core"),
                        "child_cpu_cores": intent.get("child_cpu_cores"),
                        "models": e["models"],
                        "dynamic_libraries": e["dynamic_libraries"],
                    }
                cohorts[key]["planned_proposals"] += 1
                row = native["outcomes"][0]
                slot = planned[0]
                lc.require(
                    slot["slot"] not in rows
                    and row["game"] == slot["local_game"]
                    and row["winner"] is None
                    and row["moves"]
                    == config["arena"]["book"]["openings"][row["game"]]["prefix"]
                    and row["status"] in {"decision", "unknown"}
                    and len(row["observations"]) <= 1,
                    "one frozen common parent, no duplicate/branch",
                )
                lc.arena_observation(config, row)
                rows[slot["slot"]] = (row, config)
                name = ["Sigma", "fixedD", "BEST43-NNUE"][slot["matchup"]]
                cell = engine_counts[name]
                cell["planned"] += 1
                obs = row["observations"][0] if row["observations"] else None
                if row["status"] == "decision" and obs is not None and obs["accepted"]:
                    cell["accepted"] += 1
                    cell["fallback_zero_completed"] += int(
                        (obs["counters"].get("selection_reason") or "").startswith(
                            "legal_fallback_no_completed"
                        )
                    )
                    for field in ("completed_depth",):
                        if obs.get(field) is not None:
                            cell[f"{field}:{obs[field]}"] += 1
                    cell["stop:" + str(obs["stop"])] += 1
                    ct = obs["counters"]
                    engine_times[name]["receipt_elapsed_ns"].append(
                        ct["authority_receipt_ns"] - obs["caller_started_ns"]
                    )
                    engine_times[name]["terminal_drain_elapsed_ns"].append(
                        obs["returned_ns"] - obs["caller_started_ns"]
                    )
                    if ct.get("completed_simulations") is not None:
                        engine_times[name]["completed_simulations"].append(
                            ct["completed_simulations"]
                        )
                else:
                    cell["UNKNOWN"] += 1
                if row.get("failure") is not None:
                    errors.append({"slot": slot["slot"], "failure": row["failure"]})
            summary = diagnostic_summary(
                schedule, rows, {"diagnostic_selection": selection_ref}
            )
            pairwise = Counter()
            parent_rows = defaultdict(dict)
            for slot in schedule:
                row, c = rows[slot["slot"]]
                if (
                    row["status"] == "decision"
                    and row["observations"]
                    and row["observations"][0]["accepted"]
                ):
                    parent_rows[slot["family_id"]][slot["matchup"]] = row[
                        "observations"
                    ][0]
            compact_parents = []
            for parent, observations in sorted(parent_rows.items()):
                for a, b in ((0, 1), (0, 2), (1, 2)):
                    if a in observations and b in observations:
                        pairwise[f"{a}-{b}:compared"] += 1
                        pairwise[f"{a}-{b}:different"] += int(
                            observations[a]["action"] != observations[b]["action"]
                        )
                if len(observations) == 3:
                    compact_parents.append(
                        {
                            "parent": parent,
                            "actions": [observations[i]["action"] for i in range(3)],
                            "value_stm": [
                                observations[i]["value_stm"] for i in range(3)
                            ],
                            "depths": [
                                observations[i]["completed_depth"] for i in range(3)
                            ],
                        }
                    )
            stats = {
                name: {
                    field: {
                        "count": len(v),
                        "min": min(v),
                        "max": max(v),
                        "arithmetic_mean": sum(v) / len(v),
                    }
                    for field, v in fields.items()
                    if v
                }
                for name, fields in engine_times.items()
            }
            summary.update(
                scope="Original saved width1 proposals; no game/teacher truth/strength claim",
                settings=intake["settings"],
                original_sequence=intake["aggregate"],
                original_completion=intake["completion"],
                plan=intake["plan"],
                selection=selection_ref,
                book=plan["book"],
                schedule=plan["schedule"],
                original_missing_milestones=selection["exclusions"],
                lifecycle_counts=dict(lifecycle_counts),
                errors=errors,
                cohorts=list(cohorts.values()),
                engine_counts={k: dict(v) for k, v in engine_counts.items()},
                saved_observation_descriptive_stats=stats,
                pairwise_action_counts=dict(pairwise),
                parent_actions=compact_parents,
                native_costs=native_costs,
                original_operation_wall_seconds_once=operation_wall,
                cost_scope="Original per-operation command wall once; nested native/archive times not added. Historical aggregate/Root costs preserved by reference.",
                returned_finalization_counts=[
                    {"mask": k[0], "persist": k[1], "count": v}
                    for k, v in returned_mask.items()
                ],
                persisted_finalization_counts=[
                    {"mask": k[0], "persist": k[1], "count": v}
                    for k, v in persisted_mask.items()
                ],
                limitations=[
                    "Prospective fixed 78 common parents from original358 traces;18 missing milestones not replaced.",
                    "Action disagreement is descriptive, not incorrectness, oracle/teacher truth or strength.",
                    "Sigma root NN/rootmean/selected-child Q and alpha searched values have different roles; NNUE static saturation is unrecorded.",
                    "No mixed-cohort CI/bootstrap, extra geometry/Search/forward/head/library payload or calibration calls.",
                    "Original primary762/768 games and381 complete pairs remain separate; six FAILED/UNKNOWN slots are not replayed.",
                ],
            )
            summary["saved_reader_field_correction"] = (
                "Current records use parent_traits; first interpretation used obsolete position_traits. No source/native/scientific change."
            )
            summary["retained_first_interpretation"] = lc.bound(
                OUT.parent / "result.json"
            )[0]
            lc.new_json(OUT / "result.json", summary)
        except BaseException as error:
            primary = lc.error_fact(error)
        finally:
            for ref in source_refs:
                try:
                    lc.read_ref(ref, max(lc.CONTROL_BYTES, ref["bytes"]))
                except BaseException as error:
                    if primary is None:
                        primary = lc.error_fact(error)
            reader_stop = lc.stamp()
    canonical_release = lc.stamp()
    os.sched_setaffinity(0, affinity)
    lc.new_json(
        OUT / "reader-STOP.json",
        {
            "status": "FAILED" if primary else "PASS",
            "primary": primary,
            "started": started,
            "reader_STOP": reader_stop,
            "canonical_release": canonical_release,
            "wall_seconds_once": lc.time.monotonic() - wall_start,
            "current_caller_refs_before_after": source_refs,
            "owned_readers_children_jobs_TMP_leases_remaining": [],
            "storage_budget": None,
            "new_native_model_Search_game_fit_entry": False,
            "env_release_UTC": "UNKNOWN; ends wrapper return",
        },
    )
    print(
        json.dumps(
            {
                "status": "FAILED" if primary else "PASS",
                "primary": primary,
                "result": lc.bound(OUT / "result.json")[0]
                if (OUT / "result.json").exists()
                else None,
                "reader_STOP": reader_stop,
                "canonical_release": canonical_release,
            }
        )
    )
    if primary:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
