"""Bound the requested saved inputs and inspect their schema; saved data only."""

import importlib.util
import json
from pathlib import Path
import resource

resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
ROOT = Path("/workspaces/quoridor")
BASE = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
)
OUT = BASE / "nnue-loss-cases383-v1"
s = importlib.util.spec_from_file_location(
    "lc", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(s)
s.loader.exec_module(lc)
items = [
    (
        "primary",
        BASE / "saved-results-v1/result.json",
        "9252635232e7059d3733c00ed80e87510105b8576f7f573ff37c81d7f08ff3c5",
        632029,
    ),
    (
        "diagnostics",
        BASE / "diagnostics-current-v1/interpretation-v1/current-v2/result.json",
        "6f6d5b5b89d2a59a1cdc5c8794a8957cac581dec9ade5954ebf1524c004e3f62",
        241592,
    ),
    (
        "diagnostic_report",
        BASE / "diagnostics-current-v1/interpretation-v1/current-v2/report.md",
        "3267174b8334952b3270410589e75ddbc6a094333b4a2b520d2920e13296a110",
        6813,
    ),
]
refs = {}
values = {}
for name, p, sha, n in items:
    ref, b = lc.bound(p)
    lc.require(
        ref["sha256"] == sha and ref["bytes"] == n and ref["mode"] == "0644",
        "explicit original " + name,
    )
    refs[name] = ref
    if p.suffix == ".json":
        values[name] = json.loads(b)
x = values["primary"]
lc.new_json(OUT / "input-refs.json", refs)
print(
    json.dumps(
        {
            "primary_keys": list(x),
            "saved_games_first": x.get("saved_games", [None])[0],
            "cohorts": x.get("cohorts"),
            "by_matchup": x.get("by_matchup"),
        },
        ensure_ascii=False,
    )
)
