"""Validate actual selected case evidence and report correspondence; saved data only."""

import importlib.util
import json
from pathlib import Path
import resource

resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
s = importlib.util.spec_from_file_location(
    "lc", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(s)
s.loader.exec_module(lc)
result = lc.document(lc.bound(OUT / "analysis-v2/result.json")[0])
selection = lc.document(result["selection"])
inputs = lc.document(lc.bound(OUT / "input-refs.json")[0])
primary = lc.document(inputs["primary"])
checks = []


def check(ok, name):
    lc.require(ok, name)
    checks.append(name)


check(
    len(result["cases"]) == 12 and len(result["positions"]) == 36,
    "12 selected games / exactly3 positions per game",
)
check(
    sum(v["original_actions"] for v in result["validation"]) == 569,
    "full original569 actions accounted",
)
check(
    len({c["slot"] for c in result["cases"]}) == 12, "no duplicate selected game/slot"
)
for op in ["mcts", "distance"]:
    candidates = []
    for g in primary["saved_games"]:
        if g["matchup"] not in [1, 2]:
            continue
        # Reuse plan/config mapping established by the original selected metadata.
        sample = next(c for c in selection["selected"] if c["matchup"] == g["matchup"])
        if sample["opponent_kind"] != op:
            continue
        nnue_colour = g["candidate_color"] ^ 1
        if g["status"] == "goal" and g["winner"] != nnue_colour:
            candidates.append({**g, "nnue_colour": nnue_colour})
    candidates.sort(key=lambda g: (g["family_id"], g["nnue_colour"], g["slot"]))
    check(
        [g["slot"] for g in candidates[:6]]
        == [g["slot"] for g in selection["selected"] if g["opponent_kind"] == op],
        op + " exact first6 family/NNUE-colour selection, no refill",
    )
for c in result["cases"]:
    game = lc.document(c["original_game"])
    geo = lc.document(c["geometry"])
    views = geo["views"]
    nn = c["nnue_colour"]
    check(
        len(views) == c["plies"] + 1 and views[-1]["winner"] == nn ^ 1,
        f"slot{c['slot']} whole history/terminal winner",
    )
    check(len(c["positions"]) == 3, f"slot{c['slot']} three concrete points")
    for r in c["positions"]:
        p = lc.document(r)
        o = p["original_observation"]
        v = views[p["ply"]]
        check(
            p["state"] == v
            and p["prefix_actions"] == game["full_trace_actions"][: p["ply"]]
            and p["nnue_action"]["id"] == game["full_trace_actions"][p["ply"]]
            and o["side"] == nn
            and v["legalMask"][o["action"]] == 1,
            f"slot{c['slot']} ply{p['ply']} exact state/actor/prefix/action/legal record",
        )
        check(
            len(p["full_history"]["ordered_history_keys"]) == p["ply"] + 1
            and p["recorded_attributes"]["stock_sum"] == sum(v["wallsRemaining"]),
            f"slot{c['slot']} ply{p['ply']} full history/stock",
        )
        for f in p["original_record"]["files"].values():
            lc.read_ref(f, f["bytes"])
        lc.read_ref(p["board"])
        check(
            p["uncertain"]["alternative_avoids_loss"].startswith("UNKNOWN")
            and p["value_role"].startswith("Actual searched root"),
            f"slot{c['slot']} ply{p['ply']} uncertainty/value role explicit",
        )
report = (OUT / "analysis-v2/report-ja.md").read_text()
check(
    report.count("### 候補") == 36
    and report.count("## 例") == 12
    and report.count("![slot") == 36,
    "Japanese36 point tables/figures,12 full trajectories",
)
check(
    result["missed_saved_legal_immediate_goal_cases"] == []
    and not result["cause_claims_adopted"]
    and result["new_model_Search_MCTS_alternatechild_game_fit_build_calls"] == 0,
    "no fabricated legal goal miss/causal adoption/new science",
)
p = OUT / "analysis-v2/validation.json"
lc.new_json(
    p,
    {
        "status": "PASS",
        "checks": checks,
        "count": len(checks),
        "scope": "Actual saved record/geometry/report joins, not old suite replay",
        "old_unavailable_preserved": result["retained_unknown_slots"],
        "new_scientific_calls": 0,
    },
)
print(json.dumps({"validation": lc.bound(p)[0], "checks": len(checks)}))
