"""Select the specified validated NNUE losses and read their actual saved trajectories."""

from collections import Counter, defaultdict
import importlib.util
import json
from pathlib import Path
import resource

resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
s = importlib.util.spec_from_file_location(
    "lc", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(s)
s.loader.exec_module(lc)
inputs = lc.document(lc.bound(OUT / "input-refs.json")[0])
primary = lc.document(inputs["primary"])
cache = {}
plans = {}
builds = {}
mapped = []
for g in primary["saved_games"]:
    key = g["completion"]["sha256"]
    if key not in cache:
        m = lc.document(g["completion"])
        e = lc.document(m["experiment"])
        intent = lc.document(m["intent"])
        pr = intent["approved_plan"]
        if pr["sha256"] not in plans:
            plans[pr["sha256"]] = lc.document(pr)
        planned, config = lc.arena_plan_check(e, plans[pr["sha256"]])
        lc.require(
            m["status"] == "PASS"
            and m["cleanup_complete"]
            and m["remaining"] == []
            and m["primary"] is None,
            "validated original completion",
        )
        cache[key] = (m, e, intent, pr, planned, config)
    m, e, intent, pr, planned, c = cache[key]
    kinds = [z["kind"] for z in c["engines"]]
    if kinds.count("nnue") != 1:
        continue
    nnue_index = kinds.index("nnue")
    opponent_index = nnue_index ^ 1
    nnue_colour = g["candidate_color"] if nnue_index == 0 else g["candidate_color"] ^ 1
    slot = next(z for z in planned if z["slot"] == g["slot"])
    lc.require(
        slot["family_id"] == g["family_id"]
        and slot["candidate_color"] == g["candidate_color"]
        and e["batch"] == g["batch"],
        "actual schedule colour/family join",
    )
    rec = {
        **g,
        "nnue_engine_index": nnue_index,
        "nnue_colour": nnue_colour,
        "opponent_engine_index": opponent_index,
        "opponent_kind": kinds[opponent_index],
        "nnue_won": g["winner"] == nnue_colour if g["winner"] is not None else None,
        "plan": pr,
        "config": e["config"],
        "build": e["build_manifest"],
        "origin": "manual" if g["batch"] in range(2, 6) else "finite",
        "CPU": {"AI": c.get("cpu_cores"), "main": c.get("management_cpu_core")},
    }
    mapped.append(rec)
lc.require(
    len(primary["saved_games"]) == 762 and primary["planned"] == 768,
    "original denominator",
)
pools = {
    op: sorted(
        [
            g
            for g in mapped
            if g["opponent_kind"] == op
            and g["status"] in ["goal", "forfeit"]
            and g["winner"] is not None
            and not g["nnue_won"]
        ],
        key=lambda g: (g["family_id"], g["nnue_colour"], g["slot"]),
    )
    for op in ["mcts", "distance"]
}
selected = [g for op in ["mcts", "distance"] for g in pools[op][:6]]
selection = {
    "inputs": inputs,
    "method": "Post-hoc descriptive; first up to6 validated NNUE losses per actual opponent kind, sorted family_id then actual NNUE colour; global slot only uniqueness tie-breaker",
    "planned": 768,
    "validated": 762,
    "retained_failed_unknown_slots": primary["retained_FAILED_UNKNOWN_slots"],
    "no_refill": True,
    "pools": {
        op: {"eligible_losses": len(rows), "selected": len(rows[:6])}
        for op, rows in pools.items()
    },
    "selected": selected,
    "population_counts": {},
    "cohort_colour_counts": [],
}
for op in ["mcts", "distance"]:
    rows = [g for g in mapped if g["opponent_kind"] == op]
    selection["population_counts"][op] = {
        "validated_games": len(rows),
        "NNUE_W": sum(g["nnue_won"] is True for g in rows),
        "NNUE_L": len(pools[op]),
        "draw": sum(g["status"] == "draw" for g in rows),
        "other": sum(g["status"] not in ["goal", "forfeit", "draw"] for g in rows),
    }
    groups = defaultdict(list)
    for g in rows:
        groups[(g["build"]["sha256"], g["origin"], g["nnue_colour"])].append(g)
    for (build, origin, colour), gs in groups.items():
        selection["cohort_colour_counts"].append(
            {
                "opponent": op,
                "build_sha256": build,
                "origin": origin,
                "nnue_colour": colour,
                "games": len(gs),
                "losses": sum(z["nnue_won"] is False for z in gs),
                "family_count": len({z["family_id"] for z in gs}),
            }
        )
lc.new_json(OUT / "selection.json", selection)
(OUT / "games").mkdir()
case_stats = []
for idx, g in enumerate(selected):
    m, e, intent, pr, planned, c = cache[g["completion"]["sha256"]]
    if e["build_manifest"]["sha256"] not in builds:
        builds[e["build_manifest"]["sha256"]] = lc.document(e["build_manifest"])
    build = builds[e["build_manifest"]["sha256"]]
    files_by_path = {r["path"]: r for r in m["data"]["files"]}
    files = {
        n: files_by_path[str(Path(c["output"]) / f)]
        for n, f in [
            ("journal", "completed.jsonl.gz"),
            ("result", "result.json"),
            ("native_manifest", "manifest.json"),
        ]
    }
    report = lc.arena_reference_report(c, files, expected_build=build)
    local = next(z["local_game"] for z in planned if z["slot"] == g["slot"])
    raw = next(z for z in report["outcomes"] if z["game"] == local)
    lc.arena_observation(c, raw)
    lc.require(
        raw["winner"] == g["winner"]
        and raw["candidate_color"] == g["candidate_color"]
        and raw["plies"] == g["plies"]
        and raw["status"] == g["status"]
        and len(raw["observations"]) == g["observations"],
        "original selected row exact summary correspondence",
    )
    opening = c["arena"]["book"]["openings"][local // 2]["prefix"]
    lc.require(
        raw["moves"][: len(opening)] == opening
        and len(raw["moves"]) == raw["plies"]
        and raw["winner"] != g["nnue_colour"],
        "full opening/continuation to original loss",
    )
    nnue = [
        z for z in raw["observations"] if z["engine_index"] == g["nnue_engine_index"]
    ]
    lc.require(
        all(
            z["side"] == g["nnue_colour"]
            and z["accepted"]
            and raw["moves"][z["ply"]] == z["action"]
            for z in nnue
        ),
        "actual NNUE side/action trace",
    )
    # Save the selected original record only once as the requested detailed evidence;
    # no unrelated trajectory/corpus is read or materialized.
    record = {
        "selection_index": idx,
        "selection": g,
        "original_files": files,
        "original_experiment": m["experiment"],
        "original_intent": m["intent"],
        "artifact": build["artifact"],
        "engine_mapping": c["engines"],
        "model_refs": e["models"],
        "library_refs": e["dynamic_libraries"],
        "rules": e["rules"],
        "opening_actions": opening,
        "opening_book": pr,
        "configuration": e["config"],
        "original_record_game": local,
        "actual_raw_record_sha256": lc.sha(
            (
                json.dumps(raw, sort_keys=True, separators=(",", ":"), allow_nan=False)
                + "\n"
            ).encode()
        ),
        "record_hash_role": "Semantic reserialization identity of verified original outcome, not original journal byte hash or engine position/TT key",
        "full_trace_actions": raw["moves"],
        "outcome": {k: v for k, v in raw.items() if k != "observations"},
        "NNUE_observations": nnue,
        "opponent_observations": [
            z
            for z in raw["observations"]
            if z["engine_index"] == g["opponent_engine_index"]
        ],
    }
    name = f"game-{idx + 1:02d}-slot-{g['slot']:03d}.json"
    lc.new_json(OUT / "games" / name, record)
    depths = Counter(z["completed_depth"] for z in nnue)
    end = nnue[-1]
    case_stats.append(
        {
            "file": name,
            "slot": g["slot"],
            "opponent": g["opponent_kind"],
            "family": g["family_id"],
            "nnue_colour": g["nnue_colour"],
            "plies": g["plies"],
            "depth_counts": dict(depths),
            "last_observation": {
                k: end.get(k)
                for k in ["ply", "action", "pv", "completed_depth", "stop", "value_stm"]
            },
            "last_parent_traits": end["counters"].get("parent_traits"),
            "nnue_count": len(nnue),
            "lowwall_count": sum(
                z["counters"].get("parent_traits", {}).get("stock_sum", 21) <= 5
                for z in nnue
            ),
        }
    )
lc.new_json(
    OUT / "case-index.json", {"selected_count": len(selected), "cases": case_stats}
)
print(
    json.dumps(
        {"selection": lc.bound(OUT / "selection.json")[0], "cases": case_stats},
        ensure_ascii=False,
    )
)
