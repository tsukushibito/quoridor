"""Guard one saved-data reader using the maintained command port."""

import argparse
import fcntl
import importlib.util
import json
import os
import re
import stat
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
OUT = OWN / "extract-command-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
parser = argparse.ArgumentParser()
parser.add_argument("--root-stop", required=True)
parser.add_argument("--root-stop-sha256", required=True)
args = parser.parse_args()
methods = []
test = OWN / "extract.py"
limits = {
    "family_B": 512 * 1024**2,
    "controller_B": 64 * 1024**2,
    "host_reserve_B": 4 * 1024**3,
    "worker_cpu": 3,
    "guardian_cpu": 4,
    "log_B": 128 * 1024,
}
spec = {
    "kind": "software",
    "cwd": str(MAIN),
    "limits": limits,
    "env": {
        **os.environ,
        "TMPDIR": str(OUT / "TMP"),
        "PYTHONDONTWRITEBYTECODE": "1",
        "ARENA_361_MAIN_ROOT": str(MAIN),
        "ARENA_361_LIFECYCLE": str(MAIN / "scripts/dev/research-lifecycle.py"),
        "CUDA_VISIBLE_DEVICES": "",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
    },
}


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


root_STOP = ref(Path(args.root_stop))
lc.require(root_STOP["sha256"] == args.root_stop_sha256, "actual Root adoption STOP")
lc.document(root_STOP)
available_affinity = sorted(os.sched_getaffinity(0))
os.sched_setaffinity(0, available_affinity)
lc.physical_and_quiet(spec)
with (
    lc.lease(),
    Path("/home/vscode/.cache/inference/envs/quoridor-training.setup.lock").open(
        "r"
    ) as environment_reader,
):
    fcntl.flock(environment_reader, fcntl.LOCK_SH | fcntl.LOCK_NB)
    lc.require(not OUT.exists(), "exclusive four-method output")
    import sys

    python = ref(Path(sys.executable).resolve())
    lc.read_ref(python, python["bytes"])
    paths = [
        test,
        MAIN / "scripts/dev/research-lifecycle.py",
        MAIN / "scripts/dev/project-env.sh",
        MAIN / "python/quoridor_training/cycle_process.py",
        MAIN / "python/quoridor_training/snapshot.py",
        Path(__file__).resolve(),
        Path(sys.prefix) / "pyvenv.cfg",
    ]
    refs = [ref(p) for p in paths]
    lc.require(lc.shutil.disk_usage(OWN).free >= 4 * 1024**3, "free filesystem reserve")
    OUT.mkdir()
    (OUT / "TMP").mkdir()
    argv = [
        "/bin/bash",
        str(MAIN / "scripts/dev/project-env.sh"),
        "python",
        "-B",
        str(test),
    ]
    resources = lc.process.CycleResources(
        {
            "host_ram_reserve": limits["host_reserve_B"],
            "max_memory_bytes": limits["family_B"] - limits["controller_B"],
            "max_output_bytes": None,
        },
        OUT,
        None,
    )
    checks, primary, secondary, cleanup = [], None, [], []
    started = lc.stamp()
    controller_start = lc.time.monotonic()
    try:
        os.sched_setaffinity(0, available_affinity)
        lc.physical_and_quiet(spec)
        lc.command(
            spec,
            {"name": "saved-loss-extract", "role": "software", "argv": argv},
            OUT,
            resources,
            ledger=checks,
        )
    except BaseException as error:
        primary = lc.error_fact(error)
    # Inspect only exact owned TMP children after directwait; do not hide unknown files.
    try:
        returned = checks[0]["guardian_return"]
        identity = (
            returned["child"]
            if returned is not None
            else lc.document(checks[0]["persisted_process_receipt"])["child"]
        )
        proc = Path("/proc") / str(identity["pid"]) / "stat"
        boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        current = (
            None
            if not proc.exists()
            else {
                "pid": identity["pid"],
                "start_ticks": proc.read_text().rsplit(")", 1)[1].split()[19],
                "boot_id": boot,
            }
        )
        lc.require(current != identity, "original child still present")
        for p in (OUT / "TMP").iterdir():
            before = p.lstat()
            lc.require(
                re.fullmatch(r"uv-[0-9a-f]+\.lock", p.name) is not None
                and stat.S_ISREG(before.st_mode)
                and before.st_size == 0,
                "unknown or nonempty TMP subject",
            )
            openers = []
            for proc_dir in Path("/proc").iterdir():
                if not proc_dir.name.isdigit():
                    continue
                try:
                    for fd in (proc_dir / "fd").iterdir():
                        try:
                            info = fd.stat()
                            if (info.st_dev, info.st_ino) == (
                                before.st_dev,
                                before.st_ino,
                            ):
                                openers.append(str(fd))
                        except OSError:
                            pass
                except OSError:
                    pass
            lc.require(not openers, "owned TMP lock has open FD")
            facts = {
                "before": ref(p),
                "dev": before.st_dev,
                "ino": before.st_ino,
                "open_FDs": openers,
                "original_child": identity,
                "current_child": current,
            }
            after = p.lstat()
            lc.require(
                (after.st_dev, after.st_ino, after.st_size)
                == (before.st_dev, before.st_ino, 0),
                "TMP subject drift",
            )
            lc.require(after.st_uid == os.getuid(), "owned empty TMP lock uid")
            with p.open("r+b") as lock:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                opened = __import__("os").fstat(lock.fileno())
                lc.require(
                    (opened.st_dev, opened.st_ino, opened.st_size)
                    == (before.st_dev, before.st_ino, 0),
                    "exclusive empty lock identity",
                )
                p.unlink()
            cleanup.append(facts)
        (OUT / "TMP").rmdir()
    except BaseException as error:
        secondary.append({"stage": "exact_owned_TMP_cleanup", **lc.error_fact(error)})
    for r in [*refs, python]:
        try:
            lc.read_ref(r, max(lc.CONTROL_BYTES, r["bytes"]))
        except BaseException as error:
            secondary.append(
                {
                    "stage": "current_source_artifact_python_after",
                    **lc.error_fact(error),
                }
            )
    try:
        lc.document(root_STOP)
    except BaseException as error:
        secondary.append(
            {"stage": "Root_fixture_adoption_STOP_after", **lc.error_fact(error)}
        )
    source_STOP = lc.stamp()
    controller_wall_seconds = lc.time.monotonic() - controller_start
lease_STOP = lc.stamp()
os.sched_setaffinity(0, available_affinity)
receipt = {
    "issue": "quoridor-4lc.383.1",
    "scope": "Saved-only input binding and schema inspection; no tests, model or scientific entry",
    "status": "FAILED" if primary or secondary else "PASS",
    "current_fixture_adoption_STOP": root_STOP,
    "Python": python,
    "storage_budget": None,
    "limits": limits,
    "available_affinity_before_after": available_affinity,
    "controller_wall_seconds_once": controller_wall_seconds,
    "methods": methods,
    "actual_source_refs_before_after": refs,
    "started_at": started,
    "checks": checks,
    "primary": primary,
    "secondary": secondary,
    "exact_TMP_cleanup": cleanup,
    "actual_source_caller_env_reader_STOP": source_STOP,
    "actual_canonical_release": lease_STOP,
    "owned_readers_children_jobs_TMP_remaining": []
    if not (OUT / "TMP").exists()
    else ["OWN TMP retained"],
    "reservation": None,
    "actual_native_model_library_Sigma_Search_games_entry": False,
    "old_receipts_rewritten": False,
    "child_worker_UTC_STOP": "UNKNOWN; directwait/source-reader STOP is independently recorded",
    "continuous_RAM_peak": "UNKNOWN",
}
lc.new_json(OUT / "receipt.json", receipt)
print(
    json.dumps(
        {
            "status": receipt["status"],
            "receipt": ref(OUT / "receipt.json"),
            "STOP": source_STOP,
            "release": lease_STOP,
        }
    )
)
if primary or secondary:
    raise SystemExit(1)
