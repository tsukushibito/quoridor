"""Concrete descriptive cases from bound original records and maintained rule views."""

import hashlib
import html
import importlib.util
import json
from pathlib import Path
import resource

resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
ROOT = Path("/workspaces/quoridor")
BASE = Path(__file__).resolve().parent
OUT = BASE / "analysis-v2"
OUT.mkdir()
s = importlib.util.spec_from_file_location(
    "lc", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(s)
s.loader.exec_module(lc)
inputs = lc.document(lc.bound(BASE / "input-refs.json")[0])
selection = lc.document(lc.bound(BASE / "selection.json")[0])
index = lc.document(lc.bound(BASE / "case-index.json")[0])
diag = lc.document(inputs["diagnostics"])
# The three positions per selected game are concrete descriptive hypotheses,
# chosen after reading each complete original trajectory (never a new experiment).
points = {
    6: [16, 22, 46],
    7: [15, 33, 49],
    17: [14, 46, 64],
    16: [17, 37, 47],
    20: [10, 18, 30],
    21: [15, 31, 47],
    5: [12, 28, 52],
    4: [11, 39, 53],
    8: [16, 32, 48],
    9: [21, 31, 41],
    22: [18, 22, 32],
    27: [20, 24, 36],
}
notes = {
    6: [
        "壁を置く判断と相手の応手の後に、自分の壁距離8→10、さらに10→15へ悪化。深さ3のrootはまだ+0.9246だった。壁の遅延効果と自分の迂回を見積もる被覆/到達深さの仮説。",
        "深さ4でも+0.4196、距離は自分14/相手5。実際は2手後にrootが負へ転じる。PVが想定した相手手と実応手を対照する候補。",
    ],
    7: [
        "自分距離7/相手4で+0.7769、深さ3。その2手後には自分10/相手5となり、その後rootは負へ。将来の壁による迂回を浅い完成snapshotが捉え切れなかった可能性。",
        "相手距離1に対する壁。実手順で相手goalは直ちには起きず、後に距離3となるが、rootはほぼ−1。単一手の悪さより、既に苦しい防御を迫られた局面として追う。",
    ],
    17: [
        "同じ距離5/5で+0.8740、深さ3。実応手を経て6/5、9/5、11/5へ悪化。どの壁・応手で見通しが変わったかを確認する起点。",
        "低壁数3・自分距離12/相手6なのに、深さ5で+0.1065。その後は+値が維持されず−0.9873になる。深くなってもrootの見通しが揺れる具体例。",
    ],
    16: [
        "横壁を選択、深さ3で+0.9763、自分9/相手7。次の自分手番でroot−0.0736となり、以後さらに迂回。壁の評価と浅いhorizonの具体的検討候補。",
        "壁残合計4・自分7/相手2で縦壁を使い、root−1。実際は相手goalを数手遅らせたが、その後に勝った証拠はない。遅らせる防御と勝敗を分ける例。",
    ],
    20: [
        "横壁選択時+0.9220、深さ3、自分9/相手8。2手後には自分13/相手8。その応手込みの変化を、自分の壁による自損とは即断せず具体的に点検する。",
        "縦壁を追加、root+0.8426だが自分12/相手6。残壁はまだ合計10ある。相手を止める壁と自分の通路を両立する見積もりの候補。",
    ],
    21: [
        "相手距離4・自分8なのに横壁後のroot+0.4245、深さ3。次の自分手番で−0.6467。浅い完成snapshotと実応手の差を確認する。",
        "相手距離1に壁を置く選択。実手順の後続で相手距離5となり、即時goalは遅れたがroot−1で、後に敗戦。延命を勝ち筋と混同しない。",
    ],
    5: [
        "横壁選択、深さ3で+0.8752、自分6/相手5。2手後は自分9/相手5。その後低壁数で自分だけ大きく迂回し、比較的高いrootが残る。",
        "自分距離19/相手8、残壁合計3でroot+0.9684、深さ4。後続の実手順では迂回が長く、やがて深さ11でroot−2。探索rootの楽観と終局までの見通しの隔たり。",
    ],
    4: [
        "縦壁を選択、root+0.9595、深さ3、自分8/相手7。次には自分13/相手8。壁と相手応手の複合効果を読む具体的起点。",
        "残壁合計2・距離自分16/相手4でも、深さ5でroot+0.9993。次は深さ9で+0.1237、その次は深さ10で−1。深さ3だけの問題では説明し切れない評価の変化。",
    ],
    8: [
        "横壁に+0.9590、深さ3、自分5/相手4。後続2手ずつで自分7、13、16へ悪化。相手の遮断と自分の壁の絡みを具体的に追う。",
        "残壁合計2・距離自分22/相手7、深さ6で−0.6931。それでも迂回が解消されず、さらに深い完成snapshotでは−2。深さが上がった時点で既に不利になっていた可能性。",
    ],
    9: [
        "pawn手に+0.9174、深さ3、自分7/相手4。2手後の自分距離12・root−0.5554。実際に相手が置いた壁とPV予測の相違を読む候補。",
        "横壁を置くが自分23/相手4・残壁合計4、root−0.5566。後続でも自分の距離が27へ達する。低壁数/大迂回への被覆仮説を示す局面。",
    ],
    22: [
        "縦壁に+0.6021、深さ3、自分5/相手3。2手後に自分8/相手3、さらに自分15へ。連続する壁と応手による通路変化の起点。",
        "深さ4でroot−0.9764、自分15/相手3、残壁合計11。その後も自分20、24へ。残壁が多い段階から既に通路見通しが悪化した例。",
    ],
    27: [
        "縦壁に+0.9259、深さ3、自分7/相手4。2手後は自分13/相手4、root−0.7266。浅い完成snapshotの楽観と実応手による迂回の差。",
        "深さ3でroot+0.2153、自分15/相手4。その2手後に−0.9148、さらに自分距離16、19へ。単調に悲観へ進まず、局所の+値が再出現する具体例。",
    ],
}


def sha_json(x):
    return hashlib.sha256(
        json.dumps(x, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def ref(p):
    return lc.bound(p, 128 * 1024**2)[0]


def action(a):
    if a < 81:
        return f"{chr(97 + a % 9)}{a // 9 + 1}"
    orientation = "H" if a < 145 else "V"
    n = a - (81 if a < 145 else 145)
    return f"{orientation}({chr(97 + n % 8)}{n // 8 + 1})"


def svg(view, nnue, name, title):
    size = 36
    start = 40
    parts = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="390" height="420" viewBox="0 0 390 420">',
        '<rect width="390" height="420" fill="white"/>',
        f'<text x="12" y="18" font-size="12">{html.escape(title)}</text>',
    ]
    for y in range(9):
        parts.append(
            f'<text x="20" y="{start + y * size + 20}" font-size="12">{y + 1}</text>'
        )
        for x in range(9):
            parts.append(
                f'<rect x="{start + x * size}" y="{start + y * size}" width="28" height="28" fill="#f3eee1" stroke="#bbb"/>'
            )
    for x in range(9):
        parts.append(
            f'<text x="{start + x * size + 10}" y="35" font-size="12">{chr(97 + x)}</text>'
        )
    for n in view["horizontalWalls"]:
        x = start + (n % 8) * size
        y = start + (n // 8 + 1) * size - 4
        parts.append(
            f'<line x1="{x}" y1="{y}" x2="{x + 64}" y2="{y}" stroke="#222" stroke-width="5"/>'
        )
    for n in view["verticalWalls"]:
        x = start + (n % 8 + 1) * size - 4
        y = start + (n // 8) * size
        parts.append(
            f'<line x1="{x}" y1="{y}" x2="{x}" y2="{y + 64}" stroke="#222" stroke-width="5"/>'
        )
    for player, n in enumerate(view["pawns"]):
        x = start + (n % 9) * size + 14
        y = start + (n // 9) * size + 14
        colour = "#176bbb" if player == nnue else "#cf492e"
        label = "N" if player == nnue else "O"
        parts += [
            f'<circle cx="{x}" cy="{y}" r="11" fill="{colour}"/>',
            f'<text x="{x - 4}" y="{y + 4}" font-size="12" fill="white">{label}</text>',
        ]
    parts += [
        f'<text x="12" y="385" font-size="12">N=NNUE(player{nnue}); O=opponent; stock N/O={view["wallsRemaining"][nnue]}/{view["wallsRemaining"][nnue ^ 1]}</text>',
        '<text x="12" y="405" font-size="12">player0 goal=row9; player1 goal=row1; before NNUE action</text>',
        "</svg>",
    ]
    p = OUT / "boards" / name
    p.write_text("".join(parts) + "\n")
    return ref(p)


(OUT / "boards").mkdir()
(OUT / "positions").mkdir()
geomindex = lc.document(ref(BASE / "geometry/index.json"))
diagbook = lc.document(diag["book"])
diagparents = {o["reference"]["settings"]["parent_id"]: o for o in diagbook["openings"]}
rows = []
case_summary = []
validation = []
allgoalmiss = []
comparison_matches = []
for case in index["cases"]:
    gp = BASE / "games" / case["file"]
    gr = ref(gp)
    g = lc.document(gr)
    geometry = next(
        z["geometry"] for z in geomindex["results"] if z["slot"] == case["slot"]
    )
    geo = lc.document(geometry)
    views = geo["views"]
    nn = g["selection"]["nnue_colour"]
    obsby = {o["ply"]: o for o in g["NNUE_observations"]}
    allobs = {o["ply"]: o for o in g["NNUE_observations"] + g["opponent_observations"]}
    # Exact original byte-line identity, beyond the earlier semantic record digest.
    pub = json.loads(lc.read_ref(g["original_files"]["result"]))
    compressed = lc.read_ref(
        g["original_files"]["journal"], g["original_files"]["journal"]["bytes"]
    )
    dec = lc.zlib.decompressobj(wbits=31)
    raw = dec.decompress(compressed, pub["archive"]["raw_bytes"] + 1)
    lc.require(
        dec.eof
        and not dec.unused_data
        and len(raw) == pub["archive"]["raw_bytes"]
        and lc.sha(raw) == pub["archive"]["raw_sha256"],
        "bounded original archive identity",
    )
    line = next(
        line
        for line in raw.splitlines(keepends=True)
        if json.loads(line)["game"] == g["original_record_game"]
    )
    original = json.loads(line)
    lc.require(
        original["moves"] == g["full_trace_actions"]
        and original["winner"] == g["outcome"]["winner"],
        "selected original raw line correspondence",
    )
    original_config = lc.document(g["configuration"])
    opening = original_config["arena"]["book"]["openings"][
        g["original_record_game"] // 2
    ]
    # Native original config embeds this family and its exact complete prefix.
    lc.require(opening["prefix"] == g["opening_actions"], "original full book prefix")
    for o in g["NNUE_observations"]:
        v = views[o["ply"]]
        goalrow = 8 if nn == 0 else 0
        goals = [
            a for a, ok in enumerate(v["legalMask"][:81]) if ok and a // 9 == goalrow
        ]
        if goals and o["action"] not in goals:
            allgoalmiss.append(
                {
                    "slot": case["slot"],
                    "ply": o["ply"],
                    "legal_immediate_goals": goals,
                    "chosen": o["action"],
                }
            )
    for j, p in enumerate(points[case["slot"]]):
        o = obsby[p]
        v = views[p]
        t = o["counters"]["parent_traits"]
        moves = g["full_trace_actions"]
        nextown = next((z for z in g["NNUE_observations"] if z["ply"] > p), None)
        prior = [z for z in g["NNUE_observations"] if z["ply"] < p]
        lc.require(
            v["turn"] == nn
            and moves[p] == o["action"]
            and v["legalMask"][o["action"]] == 1,
            "selected actual legal NNUE decision",
        )
        history = [z["researchHistoryKey"] for z in views[: p + 1]]
        prefix = moves[:p]
        immediate = g["outcome"]["plies"] == p + 2 and g["outcome"]["winner"] == nn ^ 1
        reason = (
            notes[case["slot"]][j]
            if j < 2
            else "終局の直前。root−2とPVの相手goal手が実際の次手goalと対応する。ここを原因の起点と断定せず、深さの大きさだけでは過去の悪化を修復しないことを示す終局anchor。"
        )
        future = []
        for ply in range(p, min(len(moves), p + 6)):
            follow = allobs.get(ply)
            future.append(
                {
                    "ply": ply,
                    "move_number": ply + 1,
                    "side": views[ply]["turn"],
                    "action": moves[ply],
                    "coordinate": action(moves[ply]),
                    "position_key_after": views[ply + 1]["positionKey"],
                    "pawns_after": views[ply + 1]["pawns"],
                    "stocks_after": views[ply + 1]["wallsRemaining"],
                    "completed_depth": follow["completed_depth"] if follow else None,
                    "value_stm": follow["value_stm"] if follow else None,
                    "stop": follow["stop"] if follow else None,
                }
            )
        goal_actions = [
            a
            for a, ok in enumerate(v["legalMask"][:81])
            if ok and a // 9 == (8 if nn == 0 else 0)
        ]
        comparable = []
        for parent, entry in diagparents.items():
            if (
                entry["prefix"] == prefix
                and g["rules"] == "research-standard-2p-threefold-goal-first-v1"
            ):
                comp = next(
                    (r for r in diag["parent_actions"] if r["parent"] == parent), None
                )
                same_models = g["model_refs"] == diag["cohorts"][0]["models"]
                same_libraries = (
                    g["library_refs"] == diag["cohorts"][0]["dynamic_libraries"]
                )
                comparable.append(
                    {
                        "parent": parent,
                        "exact_initial_origin_prefix_and_full_history": True,
                        "model_refs_exact": same_models,
                        "library_refs_exact": same_libraries,
                        "recorded_proposals": comp,
                        "role": "Descriptive only; different action is not oracle or value-scale equality",
                    }
                )
        comparison_matches.extend(comparable)
        pos = {
            "case_index": g["selection_index"] + 1,
            "position_index": j + 1,
            "slot": case["slot"],
            "family_id": case["family"],
            "nnue_colour": nn,
            "candidate_colour": g["selection"]["candidate_color"],
            "opponent": case["opponent"],
            "cohort": {
                "plan": g["selection"]["plan"],
                "build": g["selection"]["build"],
                "artifact": g["artifact"],
                "origin": g["selection"]["origin"],
                "CPU": g["selection"]["CPU"],
            },
            "original_record": {
                "files": g["original_files"],
                "game": g["original_record_game"],
                "raw_line_sha256": lc.sha(line),
                "raw_line_bytes": len(line),
                "derived_game": gr,
            },
            "ply": p,
            "move_number": p + 1,
            "continuation_ply": p - len(g["opening_actions"]),
            "prefix_actions": prefix,
            "prefix_actions_sha256": sha_json(prefix),
            "full_history": {
                "rules": g["rules"],
                "native_history_key_from_maintained_rules_view": v[
                    "researchHistoryKey"
                ],
                "position_key": v["positionKey"],
                "ordered_history_keys": history,
                "ordered_history_sha256": sha_json(history),
                "game_geometry": geometry,
                "view_index": p,
                "repetition_count": v["currentRepetitionCount"],
                "role": "Rule-only reconstruction of actual original full trajectory; not a new engine/TT/qualification receipt",
            },
            "state": v,
            "recorded_attributes": t,
            "goal_distance_nnue_opponent": [
                t["wall_goal_distances"][nn],
                t["wall_goal_distances"][nn ^ 1],
            ],
            "nnue_action": {
                "id": o["action"],
                "coordinate": action(o["action"]),
                "origin_pawn_coordinate": action(v["pawns"][nn]),
            },
            "original_observation": o,
            "PV_coordinates": [action(a) for a in o["pv"]],
            "value_role": "Actual searched root, side-to-move=NNUE; not NNUE static pretanh/posttanh/saturation and not commensurate with D score",
            "elapsed_ns": {
                "selected_completion": o["counters"]["authority_receipt_ns"]
                - o["caller_started_ns"],
                "terminal_drain": o["returned_ns"] - o["caller_started_ns"],
                "recorded_last_completed_iteration": o["last_completed_iteration_ns"]
                - o["caller_started_ns"]
                if o["last_completed_iteration_ns"] is not None
                else None,
            },
            "support": {
                "actual_action_legal": True,
                "actual_following_moves": future,
                "actual_final_outcome": g["outcome"]["status"],
                "winner": g["outcome"]["winner"],
                "immediate_next_reply_goal": immediate,
                "legal_immediate_nnue_goal_actions": goal_actions,
                "actual_PV_next_matches_reply": len(o["pv"]) > 1
                and p + 1 < len(moves)
                and o["pv"][1] == moves[p + 1],
            },
            "specific_suspicion": reason,
            "classification": "terminal_loss_anchor_not_origin"
            if j == 2
            else "descriptive_suspicious_decision_hypothesis",
            "uncertain": {
                "alternative_avoids_loss": "UNKNOWN; no alternate-child/search/forward performed",
                "move_was_first_forced_loss": "UNKNOWN",
                "candidate_static_and_saturation": "UNKNOWN_NOT_RECORDED",
                "teacher_truth": "UNKNOWN",
            },
            "minimum_further_observation_not_issued": "Exact same position+full history/rules/model/settings and candidate-level static+searched scores/completed work are needed to distinguish horizon/cost/value/strategy effects; legal avoidance or same-depth compatible evidence is needed before bad-move/causal adoption.",
            "exact_compatible_saved_diagnostic_proposals": comparable,
        }
        pos["board"] = svg(
            v,
            nn,
            f"case-{g['selection_index'] + 1:02d}-ply-{p:03d}.svg",
            f"slot{case['slot']} ply{p} NNUE {action(o['action'])}; before",
        )
        pp = OUT / "positions" / f"case-{g['selection_index'] + 1:02d}-p{j + 1}.json"
        lc.new_json(pp, pos)
        pos["position_record"] = ref(pp)
        rows.append(pos)
    trace = [
        {
            "move_number": ply + 1,
            "ply": ply,
            "side": views[ply]["turn"],
            "action": a,
            "coordinate": action(a),
            "is_opening": ply < len(g["opening_actions"]),
        }
        for ply, a in enumerate(g["full_trace_actions"])
    ]
    case_summary.append(
        {
            "index": g["selection_index"] + 1,
            "slot": case["slot"],
            "family": case["family"],
            "nnue_colour": nn,
            "candidate_colour": g["selection"]["candidate_color"],
            "opponent": case["opponent"],
            "plies": case["plies"],
            "depth_counts": case["depth_counts"],
            "original_game": gr,
            "geometry": geometry,
            "artifact": g["artifact"],
            "origin": g["selection"]["origin"],
            "build": g["selection"]["build"],
            "trace": trace,
            "positions": [
                z["position_record"] for z in rows if z["slot"] == case["slot"]
            ],
        }
    )
    validation.append(
        {
            "slot": case["slot"],
            "raw_original_line_sha256": lc.sha(line),
            "raw_line_bytes": len(line),
            "full_history_views": len(views),
            "original_actions": len(g["full_trace_actions"]),
            "actual_terminal_matches": True,
            "all_original_actions_legal": True,
            "no_prior_threefold": True,
            "recorded_stock_and_repetition_counts_match": True,
            "positions": points[case["slot"]],
        }
    )
result = {
    "scope": "Post-hoc descriptive concrete12 validated NNUE loss games, up to3 positions/game; no causal/strength/default adoption",
    "inputs": inputs,
    "selection": ref(BASE / "selection.json"),
    "population_counts": selection["population_counts"],
    "cohort_colour_counts": selection["cohort_colour_counts"],
    "cases": case_summary,
    "positions": [
        {
            k: v
            for k, v in p.items()
            if k
            not in ["state", "original_observation", "prefix_actions", "full_history"]
        }
        for p in rows
    ],
    "validation": validation,
    "missed_saved_legal_immediate_goal_cases": allgoalmiss,
    "exact_compatible_diagnostic_matches_at_selected_positions": len(
        comparison_matches
    ),
    "new_model_Search_MCTS_alternatechild_game_fit_build_calls": 0,
    "rule_only_original_actions": geomindex["results"],
    "cause_claims_adopted": False,
    "retained_unknown_slots": selection["retained_failed_unknown_slots"],
}
lc.new_json(OUT / "result.json", result)
report = [
    "# NNUE敗戦の具体的な着手・実展開の点検（383）",
    "",
    "## 何を確認できたか",
    "",
    "元374の762 validated gamesから、**NNUE対SigmaとNNUE対Dの実敗戦を各6局、計12局**点検した。相手ごとにfamily ID→実NNUE colour順の先頭6局で、別局で補充していない。後付けの記述例であり、勝率・母集団の原因・棋力の推定集合ではない。6 FAILED/UNKNOWNは原物のまま除外し、元768分母と381 complete pairsを変更しない。",
    "",
    "12局の全棋譜569 actionsを現役RulesGameで合法再生し、原票のgoal/winner、記録壁残数、反復回数と一致した。product geometryはstandard2pであるため、全chronologyを数え、researchのgoal-first/3回反復drawを途中で越えていないことを別途照合した。AI・model・探索・仮想childは実行していない。各図は実NNUE着手直前の盤面。",
    "",
    "**深さ3～4で楽観的なroot値のまま自分の通路が長くなる例**と、**深さ5でも+0.9993から実後続で急に悲観へ変わる例**がある。一方、終局直前に深さ13/27/33/64・root−2へ達したことは、その直前の手が最初の敗因だったことも、全代替手が負けることも証明しない。",
    "",
    "全NNUE実観測の合法手maskを点検したが、この12局で「その時点の合法な即時goal手を選ばず逃した」例はなかった。したがって以下は主に**要検討の判断/実展開と終局anchor**であり、回避可能だった悪手と断定しない。",
    "",
    "## 母数・実割当",
    "",
    "| 相手（実config kind） | validated NNUE games | NNUE勝/敗/draw | 選択 |",
    "|---|---:|---:|---:|",
    "| Sigma / mcts | 254 | 14 / 235 / 5 | 先頭6敗戦 |",
    "| D / distance | 254 | 90 / 164 / 0 | 先頭6敗戦 |",
    "",
    "plan/configでNNUEはengine index1、相手はindex0と確認した。実NNUE colourはcandidate_colourの反対。colour0はplayer0/先手側でgoal row9、colour1はplayer1/後手側でgoal row1。候補engineの先後をNNUE先後と取り違えない。手番・分母・CPU/image cohortは機械結果で保持する。手/plyは独立標本ではない。",
    "",
    "| 例 | 相手 | family | NNUE colour | candidate colour | global slot / batch | 全plies | 実NNUE完成深さ（観測数） |",
    "|---|---|---:|---:|---:|---|---:|---|",
]
for c in case_summary:
    g = next(z for z in selection["selected"] if z["slot"] == c["slot"])
    depths = ", ".join(f"{d}:{n}" for d, n in c["depth_counts"].items())
    report.append(
        f"| {c['index']:02d} | {'Sigma' if c['opponent'] == 'mcts' else 'D'} | {c['family']} | {c['nnue_colour']} | {c['candidate_colour']} | {c['slot']} / {g['batch']} | {c['plies']} | {depths} |"
    )
report += [
    "",
    "manual批次2～5のdd199514 cohortとfinite批次のfbd0ab82 cohortを混同しない。これらは診断234の4fe17a0a cohortとも別。モデル/evaluator/rulesの原参照は各game evidenceにあるが、この分析は旧355/358の数値を似た局面へ移植しない。選択36局面に完全な初期原点＋chronological prefixの一致する保存診断があれば明示し、違う着手だけをoracleとはしない。",
    "",
    f"今回の選択36局面でその厳密prefixに一致した保存診断は{len(comparison_matches)}件。",
    "",
    "## 読み方",
    "",
    "plyは0始まりで、NNUEの次の着手番号はply+1。初期4手openingを含め、全historyを標準初期盤面から追う。a～iは列、1～9は上から下、H(a1)はa1/b1とa2/b2の間の横壁、V(a1)はa1/a2とb1/b2の間の縦壁。N=NNUE、O=相手。PVは記録された仮想手列の座標表示だけで、再探索/仮想child再生はしない。",
    "",
    "値は**その手番のNNUE searched root値**で、player1でもここではSTMを反転しない。NNUE static pre/posttanh・飽和・候補手別staticは未記録でUNKNOWN。D値やSigma rootmeanとの数値差を誤差と呼ばない。選択完成時刻/authority receiptと全terminal drainは異なる。浅い完成snapshotが20msで届いても、whole_searchには95ms付近までの追加workがあるため「20msしか探索しなかった」と解釈しない。",
    "",
]
for c in case_summary:
    ps = [p for p in rows if p["slot"] == c["slot"]]
    nn = c["nnue_colour"]
    opp = "Sigma" if c["opponent"] == "mcts" else "D"
    goal = next(z for z in c["trace"] if z["ply"] == c["plies"] - 1)
    report += [
        f"## 例{c['index']:02d} — {opp}、family{c['family']}、NNUE player{nn}、slot{c['slot']}",
        "",
        f"{c['plies']}pliesで相手player{nn ^ 1}が{goal['coordinate']}へgoal。image {c['artifact']['sha256'][:8]}、{c['origin']} cohort。全原票: [{Path(c['original_game']['path']).name}]({c['original_game']['path']})、[rule-only全history]({c['geometry']['path']})。",
        "",
        "| 候補 | NNUE実手 / ply | 記録root / depth / stop | 現在paw​ns N/O・stocks N/O・壁goal距離 N/O | 実際の直後の手順 |",
        "|---|---|---|---|---|",
    ]
    for p in ps:
        o = p["original_observation"]
        v = p["state"]
        t = p["recorded_attributes"]
        future = " → ".join(
            f"{z['move_number']}:{'N' if z['side'] == nn else 'O'} {z['coordinate']}"
            for z in p["support"]["actual_following_moves"]
        )
        report.append(
            f"| {p['position_index']} | {p['nnue_action']['coordinate']} / {p['ply']} | {o['value_stm']:.7g} / {o['completed_depth']} / {o['stop']} | {action(v['pawns'][nn])}/{action(v['pawns'][nn ^ 1])}・{v['wallsRemaining'][nn]}/{v['wallsRemaining'][nn ^ 1]}・{p['goal_distance_nnue_opponent'][0]}/{p['goal_distance_nnue_opponent'][1]} | {future} |"
        )
    for p in ps:
        o = p["original_observation"]
        whole = o["counters"]["whole_search"]
        snap = o["completed_iteration_counters"] or {}
        v = p["state"]
        t = p["recorded_attributes"]
        report += [
            "",
            f"### 候補{p['position_index']}：{p['specific_suspicion']}",
            "",
            f"![slot{p['slot']} ply{p['ply']} actual board]({p['board']['path']})",
            "",
            f"実着手は{p['nnue_action']['origin_pawn_coordinate']}から{p['nnue_action']['coordinate']}（壁ならpawn移動ではない）。PV: {' → '.join(p['PV_coordinates'])}。完成snapshot nodes={snap.get('nodes')} / static_evaluations={snap.get('static_evaluations')}、whole_search nodes={whole.get('nodes')} / static_evaluations={whole.get('static_evaluations')}。残るTT/cutoff/update等の全記録workは[位置evidence]({p['position_record']['path']})に保持。physical_nn_calls/leaf_countがnullの場合は0に置換しない。",
            "",
            f"authority receipt {p['elapsed_ns']['selected_completion'] / 1e6:.3f}ms、matching terminal/drain {p['elapsed_ns']['terminal_drain'] / 1e6:.3f}ms。phase={t['phase_stratum']}、local_ply={t['local_ply']}、pawn_contact={t['pawn_contact']}、legal_jump={t['legal_jump_available']}、現在反復回数={v['currentRepetitionCount']}。",
            "",
            f"full-history現在key: `{v['researchHistoryKey']}`。ordered history SHA256: `{p['full_history']['ordered_history_sha256']}`。全prefix/actions、盤面key、元journal FileRef＋原行SHA、ply/view indexは[位置evidence]({p['position_record']['path']})で照合できる。",
            "",
            "| 支持する実事実 | まだ支持しない主張 |",
            "|---|---|",
            f"| 実着手は現役rulesの合法手。記録されたPV次手と実相手応手は{'一致' if p['support']['actual_PV_next_matches_reply'] else '不一致/比較不能'}。{'次の実相手手でgoal・選択lineの敗戦は確定' if p['support']['immediate_next_reply_goal'] else '後続手順と最終goalは原票に存在する'}。 | この手で初めて負けが確定した/別手なら勝つ/相手proposalが正解、とはしない。 |",
            "| pawns/壁/stocks/全chronologyはmaintained RulesGame、距離/属性/work/値は実観測。 | 距離の不利だけでゲーム理論の敗勢、root≈±1だけでNNUE静的飽和、とはしない。 |",
            "",
        ]
    report += [
        "<details><summary>全chronological棋譜（openingを含む）</summary>",
        "",
        " / ".join(
            f"{z['move_number']}:{'N' if z['side'] == nn else 'O'} {z['coordinate']}"
            + (" [opening]" if z["is_opening"] else "")
            for z in c["trace"]
        ),
        "",
        "</details>",
        "",
    ]
report += [
    "## 最小限の追加観測（このtaskでは発行しない）",
    "",
    "| 不確実性 | 既に分かること | 判断に本当に不足する最小観測 |",
    "|---|---|---|",
    "| 浅い完成depth/計算費が楽観へ寄与したか | 同100ms/5ms条件で選択されたdepth3～4と全work/receipt/drain、実応手を記録。 | その正確なposition＋全history/rules/modelで、候補別の完成depth/workと同条件のsearched score。違う局面のD深さは代用にならない。 |",
    "| 深さ5の高root値が低壁数/長迂回で誤っていたか | 例08 ply39は+0.9993/depth5の後、depth9→10の実snapshotで値が大きく変わる。 | 同じ全historyでの候補手ごとのscore/PVと、合法な実回避の証拠。後続が違えば勝つか、は保存だけでは未知。 |",
    "| NNUE static飽和・被覆不足か | searched root値がほぼ±1になる例、壁残/距離/phaseと敗戦展開は保存。 | 同じ元入力のcandidate static pretanh/posttanhとscale/入力identity。searched root/terminal−2で置き換えない。必要でない追加forwardはしない。 |",
    "| 具体的悪手/敗因を採用できるか | 即時goal見逃しはこの12局に無し。次手goalと合法selected lineは確認済み。 | 実際の同position＋fullhistoryで合法な明確な回避、または同深さ互換の既存比較証拠。勝ちへの影響は別に確認する。 |",
    "",
    "因果・棋力・default変更は採用していない。もしRootが「この手が原因」等の意味ある結論を採用するなら、その限定claimと元位置/合法回避の根拠だけを既存の関連確認へ渡す。新しいteacher、全suite、calibration、generation/fit/256arena、323USERPAUSE解除はこの成果に含まれない。",
]
(OUT / "report-ja.md").write_text("\n".join(report) + "\n")
print(
    json.dumps(
        {
            "result": ref(OUT / "result.json"),
            "report": ref(OUT / "report-ja.md"),
            "cases": len(case_summary),
            "positions": len(rows),
            "immediate_goal_misses": allgoalmiss,
        }
    )
)
