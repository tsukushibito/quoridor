// Replay only original saved actions through the maintained rules-only product API.
// Never import or call an AI, evaluator, search, or counterfactual-child API.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

const own = path.dirname(new URL(import.meta.url).pathname);
const input = JSON.parse(fs.readFileSync(path.join(own, 'geometry-input.json'), 'utf8'));
function requireFact(ok, message) {
  if (!ok) throw new Error(message);
}
function readRef(ref) {
  const bytes = fs.readFileSync(ref.path);
  requireFact(
    bytes.length === ref.bytes &&
      crypto.createHash('sha256').update(bytes).digest('hex') === ref.sha256,
    `bound reader drift: ${ref.path}`,
  );
  return bytes;
}
const module = await import(pathToFileURL(input.rules_js.path));
module.initSync({ module: readRef(input.rules_wasm) });
readRef(input.rules_js);
const output = path.join(own, 'geometry');
fs.mkdirSync(output);
function historyKey(v) {
  const pawn = (n) => `${n % 9},${Math.floor(n / 9)}`;
  const anchors = (a) =>
    a
      .map((n) => `${n % 8},${Math.floor(n / 8)}`)
      .sort()
      .join(';');
  return `${pawn(v.pawns[0])}|${pawn(v.pawns[1])}|${v.turn}|${anchors(v.horizontalWalls)}|${anchors(v.verticalWalls)}|${v.wallsRemaining[0]},${v.wallsRemaining[1]}`;
}
function publish(name, value) {
  const bytes = Buffer.from(JSON.stringify(value) + '\n');
  requireFact(bytes.length <= 1024 * 1024, 'one saved game geometry record cap');
  fs.writeFileSync(path.join(output, name), bytes, { flag: 'wx' });
  return {
    path: path.join(output, name),
    bytes: bytes.length,
    sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
    mode: '0644',
  };
}
const result = [];
for (const item of input.games) {
  const record = JSON.parse(readRef(item));
  const game = new module.RulesGame(
    JSON.stringify({ firstPlayer: 0, wallsPerPlayer: 10, humanPlayer: 0 }),
  );
  try {
    const views = [];
    const counts = new Map();
    const capture = () => {
      const v = JSON.parse(game.get_view());
      const key = historyKey(v);
      counts.set(key, (counts.get(key) ?? 0) + 1);
      requireFact(
        v.rulesetId === 'standard-2p-v1' && v.legalMask.length === 209,
        'maintained rules view schema',
      );
      // Research adds automatic threefold; no selected goal trace may cross it.
      requireFact(
        v.winner !== null || counts.get(key) < 3,
        'selected goal trajectory crosses earlier research threefold',
      );
      views.push({ ...v, researchHistoryKey: key, currentRepetitionCount: counts.get(key) });
      return v;
    };
    capture();
    for (const action of record.full_trace_actions) {
      const before = views.at(-1);
      requireFact(
        before.winner === null && before.legalMask[action] === 1,
        'original stored action is legal before actual transition',
      );
      game.apply_action(JSON.stringify(action));
      capture();
    }
    const final = views.at(-1);
    requireFact(
      final.ply === record.outcome.plies && final.winner === record.outcome.winner,
      'actual original terminal goal/winner correspondence',
    );
    for (const obs of [...record.NNUE_observations, ...record.opponent_observations]) {
      const view = views[obs.ply];
      requireFact(
        view.turn === obs.side &&
          record.full_trace_actions[obs.ply] === obs.action &&
          view.legalMask[obs.action] === 1,
        'original observed actor/action exact',
      );
      const traits = obs.counters.parent_traits;
      if (traits) {
        requireFact(
          traits.stock_sum === view.wallsRemaining[0] + view.wallsRemaining[1],
          'recorded stock sum matches maintained geometry',
        );
        requireFact(
          traits.current_repetition_count === view.currentRepetitionCount,
          'actual research history count matches recorded traits',
        );
      }
    }
    const refs = publish(`slot-${String(record.selection.slot).padStart(3, '0')}.json`, {
      original_game: item,
      rules_module: input.rules_js,
      rules_wasm: input.rules_wasm,
      scope:
        'Only actual original moves through RulesGame; goal-first and no prior research third repetition verified; no alternate branch, AI or search.',
      views,
      final_history_counts: [...counts].sort(([a], [b]) => a.localeCompare(b)),
      actual_actions_applied: record.full_trace_actions.length,
      original_terminal: record.outcome,
    });
    result.push({
      slot: record.selection.slot,
      geometry: refs,
      original_actions_applied: record.full_trace_actions.length,
      terminal_winner: final.winner,
      legal_history_stock_checks: 'PASS',
    });
  } finally {
    game.free();
  }
}
publish('index.json', {
  input,
  results: result,
  original_games_reconstructed: result.length,
  new_search_model_alternate_child_calls: 0,
});
console.log(
  JSON.stringify({
    original_games_reconstructed: result.length,
    total_original_actions: result.reduce((s, x) => s + x.original_actions_applied, 0),
    new_scientific_calls: 0,
  }),
);
