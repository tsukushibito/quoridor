"""Inspect authoritative mapping and raw saved records; no engine calls."""

import importlib.util
import json
from pathlib import Path
import resource

resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
s = importlib.util.spec_from_file_location(
    "lc", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(s)
s.loader.exec_module(lc)
inputs = lc.document(lc.bound(OUT / "input-refs.json")[0])
x = lc.document(inputs["primary"])
for matchup in sorted({g["matchup"] for g in x["saved_games"]}):
    g = next(g for g in x["saved_games"] if g["matchup"] == matchup)
    m = lc.document(g["completion"])
    e = lc.document(m["experiment"])
    intent = lc.document(m["intent"])
    p = lc.document(intent["approved_plan"])
    planned, c = lc.arena_plan_check(e, p)
    print(
        "MAPPING",
        json.dumps(
            {
                "matchup": matchup,
                "engines": c["engines"],
                "ruleset": c["ruleset"],
                "arena": {k: v for k, v in c["arena"].items() if k != "book"},
                "plan_matchups": [
                    {k: v for k, v in z.items() if k in ["id", "name", "engines"]}
                    for z in p["matchups"]
                ],
            }
        ),
    )
    if matchup == 1:
        build = lc.document(e["build_manifest"])
        by_path = {r["path"]: r for r in m["data"]["files"]}
        files = {
            n: by_path[str(Path(c["output"]) / f)]
            for n, f in [
                ("journal", "completed.jsonl.gz"),
                ("result", "result.json"),
                ("native_manifest", "manifest.json"),
            ]
        }
        raw = lc.arena_reference_report(c, files, expected_build=build)
        print("RAW_KEYS", list(raw["outcomes"][0]))
        obs = raw["outcomes"][0]["observations"][0]
        print("OBS", json.dumps(obs))
