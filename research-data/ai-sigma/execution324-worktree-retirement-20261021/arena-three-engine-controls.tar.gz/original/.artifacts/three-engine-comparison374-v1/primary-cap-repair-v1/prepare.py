"""Generate the selected publication-cap correction without runtime calls."""

import copy
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import resource

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
OUT = OWN / "primary-cap-repair-v1"
loader = importlib.util.spec_from_file_location("lc", MAIN / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def now():
    return datetime.now(timezone.utc).isoformat()


def ref(path):
    return lc.bound(path)[0]


def encoded(value):
    # Generated metadata uses compact JSON so each config occupies one page.
    return (json.dumps(value, separators=(",", ":"), allow_nan=False) + "\n").encode()


def publish(path, data):
    with path.open("xb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())


resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
assert os.environ["QUORIDOR_PROJECT_ENV"] == "/home/vscode/.cache/inference/envs/quoridor-training"
lc.physical_and_quiet(
    {
        "cwd": str(MAIN),
        "limits": {
            "family_B": 512 * 1024**2,
            "host_reserve_B": 4 * 1024**3,
            "worker_cpu": 1,
            "guardian_cpu": 3,
        },
    }
)
with lc.lease():
    price = lc.document(ref(OUT / "preprice.json"))
    old_ref = price["old_plan"]
    old_bytes = lc.read_ref(old_ref)
    old = json.loads(old_bytes)
    plan = copy.deepcopy(old)
    assert len(plan["batches"]) == 384 and plan["planned_slots"] == 768
    config_dir = OUT / "primary-configs"
    assert not config_dir.exists()
    config_dir.mkdir()
    before_after = []
    replacements = {}
    original_outputs = []
    preserved_failed = {
        "path": str(OWN / "primary-controls-v2/batch-000/operation-v1/manifest.json"),
        "sha256": "54d03543823b151495adc89026367729ebc92abd9c9b0ad64c14e5f3e5e1e830",
        "bytes": 10048,
        "mode": "0644",
    }
    assert lc.document(preserved_failed)["status"] == "FAILED"
    for index, batch in enumerate(plan["batches"]):
        before = batch["config"]
        raw = lc.read_ref(before)
        config = json.loads(raw)
        assert config["max_output_bytes"] == 8388608 and config["games"] == 2
        assert config["output"] not in original_outputs
        original_outputs.append(config["output"])
        assert not os.path.lexists(config["output"]), "output already exists"
        updated = copy.deepcopy(config)
        updated["max_output_bytes"] = 16777216
        data = encoded(updated)
        assert len(data) < 4096
        path = config_dir / f"batch-{index:03d}.json"
        publish(path, data)
        after = ref(path)
        inverse = json.loads(lc.read_ref(after))
        inverse["max_output_bytes"] = 8388608
        assert inverse == config
        assert encoded(inverse) == encoded(config)
        assert lc.read_ref(before) == raw
        before_after.append({"batch": index, "before": before, "after": after})
        replacements[before["path"]] = after
        batch["config"] = after

    pointer_sites = []

    def replace_input_refs(value, location=""):
        if isinstance(value, dict):
            if set(value) == {"path", "sha256", "bytes", "mode"}:
                if value["path"] in replacements:
                    original = next(row["before"] for row in before_after if row["before"] == value)
                    pointer_sites.append({"location": location, "before": original})
                    return copy.deepcopy(replacements[value["path"]])
                return value
            return {
                key: replace_input_refs(item, location + "/" + key) for key, item in value.items()
            }
        if isinstance(value, list):
            return [
                replace_input_refs(item, location + "/" + str(i)) for i, item in enumerate(value)
            ]
        return value

    # Only actual pointer-input occurrences are changed; no new inputs are added.
    for key in ("inputs",):
        plan[key] = replace_input_refs(plan[key], "/" + key)
    inverse_plan = copy.deepcopy(plan)
    for batch, row in zip(inverse_plan["batches"], before_after, strict=True):
        batch["config"] = row["before"]
    for site in pointer_sites:
        parts = site["location"].strip("/").split("/")
        parent = inverse_plan
        for part in parts[:-1]:
            parent = parent[int(part)] if isinstance(parent, list) else parent[part]
        key = int(parts[-1]) if isinstance(parent, list) else parts[-1]
        parent[key] = site["before"]
    assert inverse_plan == old
    assert encoded(inverse_plan) == encoded(old)
    assert lc.read_ref(old_ref) == old_bytes
    plan_path = OUT / "approved-plan.derivative.json"
    publish(plan_path, encoded(plan))
    assert json.loads(plan_path.read_bytes()) == plan
    proof = {
        "issue": "quoridor-4lc.374.1",
        "old_plan": old_ref,
        "new_plan_derivative": ref(plan_path),
        "config_pairs": before_after,
        "necessary_pointer_input_sites": pointer_sites,
        "config_changed_field": "max_output_bytes",
        "before_B": 8388608,
        "after_B": 16777216,
        "exact_JSON_inverse_count": 384,
        "exact_plan_JSON_inverse": True,
        "original_byte_refs_after_match": True,
        "generated_format": "compact JSON; no Rust normalization or digest claim",
        "output_paths_unchanged_and_uncreated_count": len(original_outputs),
        "original_failed_manifest": preserved_failed,
        "schedule_slots_models_cost_Q_epoch_window_unchanged": True,
        "planned_games_pairs_families": [768, 384, 128],
        "diagnostic_actual_parents_proposals_missing": [78, 234, 18],
        "native_model_library_head_Search_game_calls": 0,
        "admission_or_runtime_submission": None,
        "actual_source_config_reader_STOP": now(),
    }
    publish(OUT / "inverse-proof.json", encoded(proof))
    helper = ref(OUT / "prepare.py")
    publisher = ref(MAIN / "scripts/dev/research-lifecycle.py")
    actual = lc.allocated(OUT)
    assert actual + 64 * 1024 <= price["inclusive_new_component_B"]
    primary = lc.allocated(OWN / "primary-controls-v2") + actual
    assert primary + 64 * 1024 <= price["primary_control_cap_B"]
    lc.new_json(
        OUT / "preparation-STOP.json",
        {
            "issue": "quoridor-4lc.374.1",
            "status": "STOPPED_PUBLICATION_CAP_CONFIG_PREPARATION",
            "proof": ref(OUT / "inverse-proof.json"),
            "plan_derivative": ref(plan_path),
            "original_plan": old_ref,
            "helper": helper,
            "publisher_read_only": publisher,
            "new_component_actual_B_before_STOP": actual,
            "inclusive_new_component_cap_B": price["inclusive_new_component_B"],
            "remaining_collection_tail_B": 64 * 1024,
            "current_primary_union_B_before_STOP": primary,
            "primary_cap_B": price["primary_control_cap_B"],
            "no_Main_env_lib_model_image_target_mutation": True,
            "native_model_Search_game_calls": 0,
            "original_failed_manifest": preserved_failed,
            "source_reader_writer_STOP": now(),
            "canonical_lease_release": "context return after this record",
            "environment_lease_release": "public-entry directwait after this record",
            "new_grant_refund_borrow_B": 0,
        },
    )
print(json.dumps({"status": "STOPPED", "configs": 384, "plan": ref(plan_path)}))
