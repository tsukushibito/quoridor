"""Collect two current typed-config replies and zero-model loaded-library metadata."""

import importlib.util
import json
import os
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
OUT = OWN / "runtime-binding-v2"
ORIGINAL_AFFINITY = os.sched_getaffinity(0)
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def exact(path, digest, size, mode="0644"):
    value = ref(path)
    lc.require(
        (value["sha256"], value["bytes"], value["mode"]) == (digest, size, mode),
        "exact supplied FileRef",
    )
    return value


def gone(identity):
    proc = Path("/proc") / str(identity["pid"]) / "stat"
    return not proc.exists() or (
        proc.read_text().rsplit(")", 1)[1].split()[19] != identity["start_ticks"]
        or Path("/proc/sys/kernel/random/boot_id").read_text().strip() != identity["boot_id"]
    )


limits = {
    "family_B": 3 * 1024**3,
    "controller_B": 64 * 1024**2,
    "host_reserve_B": 4 * 1024**3,
    "worker_cpu": 1,
    "guardian_cpu": 3,
    "log_B": 256 * 1024,
}
spec = {
    "cwd": str(MAIN),
    "limits": limits,
    "env": {
        **os.environ,
        "TMPDIR": str(OUT / "child-TMP"),
        "CUDA_VISIBLE_DEVICES": "",
        "PYTHONDONTWRITEBYTECODE": "1",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
    },
}
os.sched_setaffinity(0, ORIGINAL_AFFINITY)
lc.physical_and_quiet(spec)
checks, primary, secondary, replies, library_metadata = [], None, [], [], None
refs, identities = [], []
started = lc.stamp()
with lc.lease():
    binding_ref = exact(
        OWN / "current-controls-v1/stopped-config-binding.json",
        "af9d78c81b2bd1efd0c0e39aa6dcdc5e962fef904d2f77c4a28bc7ef4e0a4c48",
        10415,
    )
    binding = lc.document(binding_ref)
    lc.document(binding["support"])
    preprice = ref(OWN / "runtime-binding-v1/preprice.json")
    lc.require(lc.document(preprice)["inclusive_forward_B"] == 2 * 1024**2, "issued forward scope")
    build_ref = binding["authentic_Build"]
    build = lc.accepted_build(build_ref)
    lc.require(build["artifact"] == binding["artifact"], "authentic immutable private")
    spec["caller_sources"] = binding["normal_current_caller_refs_before_after"]
    lc.caller_source_refs(spec, {"phase": "sigma-cost-qualification"})
    models = [m["selected_FileRef"] for m in binding["selected_model_FileRefs_named_metadata"]]
    configs = binding["full_current_two_configs"]
    refs = [
        binding_ref,
        build_ref,
        build["artifact"],
        *configs,
        *models,
        *spec["caller_sources"],
        *binding["actual_entry_environment_refs_before_after"],
        binding["common_entry"],
        binding["qualified_environment"],
        ref(OUT / "run-binding.py"),
        ref(OUT / "ort-version-metadata.py"),
        preprice,
    ]
    for item in refs:
        lc.read_ref(item, max(lc.CONTROL_BYTES, item["bytes"]))
    library_ref = ref(binding["named_library_current_lstat_before_after"]["path"])
    refs.append(library_ref)
    lc.require(library_ref["bytes"] == 28985152 and library_ref["mode"] == "0755", "named library")
    lc.require(
        lc.allocated(OUT) + lc.allocated(OWN / "runtime-binding-v1") + 1536 * 1024 <= 2 * 1024**2,
        "inclusive phase forward capacity",
    )
    lc.require(lc.shutil.disk_usage(OWN).free >= 4 * 1024**3, "free filesystem reserve")
    (OUT / "child-TMP").mkdir()
    resources = lc.process.CycleResources(
        {
            "host_ram_reserve": limits["host_reserve_B"],
            "max_memory_bytes": limits["family_B"] - limits["controller_B"],
            "max_output_bytes": 2 * 1024**2,
        },
        OUT,
        None,
    )
    try:
        for i, config in enumerate(configs):
            os.sched_setaffinity(0, ORIGINAL_AFFINITY)
            lc.physical_and_quiet(spec)
            lc.command(
                spec,
                {
                    "name": f"typed-config-{i}",
                    "role": "software",
                    "argv": [
                        build["artifact"]["path"],
                        "sigma-cost-bindings",
                        "--config",
                        config["path"],
                        "--config-sha256",
                        config["sha256"],
                    ],
                },
                OUT,
                resources,
                ledger=checks,
            )
            reply = json.loads(lc.read_ref(checks[-1]["full_log"]))
            lc.require(
                reply["schema"] == "quoridor-sigma-cost-bindings-v1"
                and reply["executable_sha256"] == build["artifact"]["sha256"]
                and reply["config_file"] == {"path": config["path"], "sha256": config["sha256"]}
                and reply["backend_loaded"] is False
                and reply["model_calls"] == 0
                and reply["cost_qualification"] is None
                and len(reply["normalized_config_sha256"]) == 64,
                "actual typed metadata reply",
            )
            replies.append(reply)
        os.sched_setaffinity(0, ORIGINAL_AFFINITY)
        lc.physical_and_quiet(spec)
        lc.command(
            spec,
            {
                "name": "loaded-ORT-metadata",
                "role": "software",
                "argv": [
                    str(lc.project_python()),
                    "-B",
                    str(OUT / "ort-version-metadata.py"),
                    library_ref["path"],
                ],
            },
            OUT,
            resources,
            ledger=checks,
        )
        library_metadata = json.loads(lc.read_ref(checks[-1]["full_log"]))
        lc.require(
            library_metadata["library"] == library_ref
            and library_metadata["model_sessions"] == 0
            and library_metadata["model_calls"] == 0,
            "zero-model actual loaded metadata",
        )
        refs.extend(library_metadata["actual_loaded_ELF_FileRefs"])
    except BaseException as error:
        primary = lc.error_fact(error)
    for check in checks:
        try:
            returned = check["guardian_return"]
            disk = lc.document(check["persisted_process_receipt"])
            identity = (returned if returned is not None else disk)["child"]
            lc.require(gone(identity), "original child still present")
            identities.append({"original": identity, "absent_or_different": True})
        except BaseException as error:
            secondary.append({"stage": "original_child_after", **lc.error_fact(error)})
    try:
        lc.require(not list((OUT / "child-TMP").iterdir()), "unexpected retained child TMP")
        (OUT / "child-TMP").rmdir()
    except BaseException as error:
        secondary.append({"stage": "owned_child_TMP_cleanup", **lc.error_fact(error)})
    for item in refs:
        try:
            lc.read_ref(item, max(lc.CONTROL_BYTES, item["bytes"]))
        except BaseException as error:
            secondary.append({"stage": "bound_subject_after", "file": item, **lc.error_fact(error)})
    source_STOP = lc.stamp()
release = lc.stamp()
receipt = {
    "issue": "quoridor-4lc.374.1",
    "status": "FAILED" if primary or secondary else "PASS",
    "scope": "Two actual typed native config calls and one loaded ORT C API metadata command; zero models/heads/inference/Search/games",
    "preprice": preprice,
    "build": build_ref,
    "artifact": build["artifact"],
    "binding": binding_ref,
    "checks": checks,
    "typed_replies": replies,
    "loaded_library_metadata": library_metadata,
    "current_FileRefs_before_after": refs,
    "original_child_identities_after": identities,
    "primary": primary,
    "secondary": secondary,
    "started_at": started,
    "source_caller_library_reader_STOP": source_STOP,
    "canonical_release": release,
    "parent_common_entry_env_reader_STOP": "Pending original parent directwait",
    "owned_child_TMP_remaining": []
    if not (OUT / "child-TMP").exists()
    else [str(OUT / "child-TMP")],
    "reservation": None,
    "actual_backend_factory_binding": None,
    "positive_cost_bounds": None,
    "usable_Q": None,
    "qualification_launch": None,
    "NativeIdentity_expectation": None,
    "counts": {
        "typed_native_calls_entered": min(2, len(checks)),
        "model_calls": 0,
        "heads": 0,
        "Search": 0,
        "games": 0,
    },
    "child_exact_UTC_STOP": "UNKNOWN; directwait and reader STOP independently recorded",
}
lc.new_json(OUT / "receipt.json", receipt)
print(
    json.dumps(
        {
            "status": receipt["status"],
            "receipt": ref(OUT / "receipt.json"),
            "STOP": source_STOP,
            "release": release,
        }
    )
)
if primary or secondary:
    raise SystemExit(1)
