"""Collect the single common374+376 BUILD and release its finite source custody."""

import fcntl
import importlib.util
import json
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
PHASE = OWN / "build-v7"
OUT = PHASE / "qualified-collection-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


spec = lc.document(ref(PHASE / "intent.json"))
manifest_ref = ref(PHASE / "operation-v1/manifest.json")
manifest = lc.accepted_build(manifest_ref)
job_ref = ref(PHASE / "runtime-v1/result.json")
job = lc.document(job_ref)
lc.require(job["job_id"] == manifest["originating_job"]["job_id"], "actual unique originating job")
lc.require(job["cleanup_complete"] and job["remaining"] == [], "outer cleanup")
lc.require(not OUT.exists(), "exclusive collection")
identities = [manifest["originating_job"]["supervisor"], manifest["originating_job"]["child"]]
checks = manifest["checks"]
lc.require(len(checks) == 10, "seven versions plus one unfinished integration/lint/build")
for check in checks:
    lc.require(check["status"] == "PASS" and check["capture_complete"], "completed original scope")
    lc.settled(check["guardian_return"])
    identities.append(check["guardian_return"]["child"])
    for field in ["full_log", "persisted_process_receipt"]:
        lc.read_ref(check[field], max(lc.CONTROL_BYTES, check[field]["bytes"]))
    lc.require(
        check["full_log"]["bytes"] == check["guardian_return"]["log_bytes_seen"], "full capture"
    )
selection = json.loads((OWN / "selection.json").read_bytes())
executed = []
for test in (c for c in checks if c["role"] == "test"):
    names = selection["expected_native_names"][test["name"]]
    text = lc.read_ref(test["full_log"]).decode()
    actual = [
        line.removeprefix("test ").removesuffix(" ... ok")
        for line in text.splitlines()
        if line.startswith("test ") and line.endswith(" ... ok")
    ]
    lc.require(sorted(actual) == sorted(names), "exact current named assertion set")
    lc.require(
        f"running {len(names)} test" in text
        and f"test result: ok. {len(names)} passed; 0 failed; 0 ignored; 0 measured;" in text,
        "current scope census",
    )
    lc.cargo_report(lc.read_ref(test["full_log"]))
    executed.extend(names)
lc.require(len(executed) == 1, "one unfinished synthetic pump assertion")
lc.require(manifest["cargo_artifact"]["fresh"] is False, "Cargo rebuild evidence")
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
absence = []
for identity in identities:
    p = Path("/proc") / str(identity["pid"]) / "stat"
    try:
        ticks = p.read_text().rsplit(")", 1)[1].split()[19]
        current = {"pid": identity["pid"], "start_ticks": ticks, "boot_id": boot}
    except FileNotFoundError:
        current = None
    lc.require(current != identity, "same original process still live")
    absence.append({"original": identity, "current": current, "same_identity_live": False})
__import__("os").sched_setaffinity(0, {1, 3})
lc.physical_and_quiet(spec)
with (
    lc.lease(),
    Path("/home/vscode/.cache/inference/envs/quoridor-training.setup.lock").open("r") as env_reader,
):
    fcntl.flock(env_reader, fcntl.LOCK_SH | fcntl.LOCK_NB)
    lc.source_check(spec["source"])
    for tool in spec["tools"].values():
        lc.read_ref(tool["file"], max(lc.CONTROL_BYTES, tool["file"]["bytes"]))
    lc.document(spec["source_adoption"])
    handover = lc.document(spec["target_handover"])
    marker = json.loads((Path(spec["target"]) / ".research-owner.json").read_bytes())
    lc.require(marker == handover["after_owner_marker"], "current target owner")
    allocated = lc.allocated(spec["target"])
    private_allocated = lc.allocated(Path(spec["private"]).parent)
    lc.require(allocated <= handover["target_max_B"], "target cap")
    lc.require(private_allocated <= handover["fresh_private_forward_max_B"], "private parent cap")
    artifact = ref(spec["private"])
    lc.require(artifact == manifest["artifact"], "actual private image identity")
    emitted = ref(manifest["cargo_artifact"]["executable"])
    lc.require(
        emitted["sha256"] == artifact["sha256"] and emitted["bytes"] == artifact["bytes"],
        "Cargo/private same bytes",
    )
    lc.require(not Path(spec["TMP"]).exists(), "TMP removed")
    caller_paths = [
        MAIN / "scripts/dev/research-lifecycle.py",
        MAIN / "scripts/dev/project-env.sh",
        MAIN / "python/quoridor_training/cycle_process.py",
        MAIN / "python/quoridor_training/snapshot.py",
        MAIN / "pyproject.toml",
        MAIN / "uv.lock",
        Path("/home/vscode/.cache/inference/envs/quoridor-training/pyvenv.cfg"),
    ]
    caller_refs = [ref(p) for p in caller_paths]
    current_python = str(__import__("sys").executable)
    current_python_regular = ref(Path(current_python).resolve())
    finalizer = lc.document(ref(PHASE / "finalization-v1/receipt.json"))
    lc.settled(finalizer["guardian_return"])
    lc.require(
        finalizer["capture_complete"]
        and finalizer["primary"] is None
        and finalizer["secondary"] == [],
        "actual finalization guardian/capture",
    )
    lc.require(
        not lc.process.alive(finalizer["guardian_return"]["child"]),
        "original finalizer identity live",
    )
    for caller_ref in caller_refs:
        lc.read_ref(caller_ref, max(lc.CONTROL_BYTES, caller_ref["bytes"]))
    source_STOP = lc.stamp()
lease_STOP = lc.stamp()
lc.require(
    lc.allocated(OWN) + 131072 <= 5242880, "actual inclusive5MiB controls plus collection tail"
)
OUT.mkdir()
record = {
    "issue": "quoridor-4lc.374.1",
    "status": "PASS_AUTHENTIC_CURRENT_BUILD_ONLY",
    "manifest": manifest_ref,
    "outer_job": job_ref,
    "outer_log": ref(PHASE / "runtime-v1/output.log"),
    "intent": ref(PHASE / "intent.json"),
    "source_adoption": spec["source_adoption"],
    "support": spec["support"],
    "handover": spec["target_handover"],
    "artifact": artifact,
    "Cargo_emitted_artifact": emitted,
    "Cargo_release_report": manifest["cargo_artifact"],
    "checks": [
        {
            k: c[k]
            for k in [
                "name",
                "role",
                "status",
                "full_log",
                "persisted_process_receipt",
                "capture_complete",
                "guardian_return",
            ]
        }
        for c in checks
    ],
    "affected_assertions_passed_once": executed,
    "assertions_executed": 1,
    "prior_clock4_two379_nine376_twelve374_eight_python_scope": "Immutable original scope, no replay",
    "authoritative_finished_at": manifest["authoritative_finished_at"],
    "inner_cleanup_complete": manifest["cleanup_complete"],
    "outer_cleanup_complete": job["cleanup_complete"],
    "primary": manifest["primary"],
    "secondary": manifest["secondary"],
    "returned_vs_persisted": "Returned guardians settled completed; original persisted receipts separately bound, pending/attempted fields not rewritten",
    "controller_whole_wall_seconds_counted_once": job["wall_seconds"],
    "same_common_BUILD_controllers_once_seconds": job["wall_seconds"],
    "nested_walls_not_added": True,
    "original_process_identities": absence,
    "actual_source_private_tool_reader_STOP": source_STOP,
    "actual_canonical_release": lease_STOP,
    "target_allocated_after_B": allocated,
    "target_retained_floor_B": max(allocated, 1388646400),
    "target_cap_B": handover["target_max_B"],
    "private_allocated_B": private_allocated,
    "TMP_absent": True,
    "owned_readers_children_jobs_TMP_remaining": [],
    "reservation": None,
    "continuous_peak": "UNKNOWN",
    "two_new_Python": ref(OWN / "python-metadata-v1/receipt.json"),
    "prior_seven_native_PASS_original_scope": ref(OWN / "build-v4/operation-v1/manifest.json"),
    "common_current_caller_refs": caller_refs,
    "current_common_entry_interpreter": current_python,
    "current_regular_Python": current_python_regular,
    "normal_finalizer": ref(PHASE / "finalization-v1/receipt.json"),
    "actual_control_union_B": lc.allocated(OWN),
    "inclusive_controls_cap_B": 5242880,
    "current_factory_library_model_head_numerical": "NOT_ESTABLISHED_BY_SOFTWARE_IMAGE; no cost prediction/Q producer exists",
    "original875_Q8f9_64_epoch_expiry_FAILED_RAW": "IMMUTABLE_NO_RETARGET_OR_REPLAY",
    "numerical_model_library_Sigma_Search_game_entry": False,
}
lc.new_json(OUT / "qualified-build-STOP.json", record)
print(
    json.dumps(
        {
            "STOP": source_STOP,
            "release": lease_STOP,
            "record": ref(OUT / "qualified-build-STOP.json"),
            "manifest": manifest_ref,
            "artifact": artifact,
            "target_B": allocated,
            "private_B": private_allocated,
        }
    )
)
