"""Prepare the existing BUILD body only after real Root Source/custody are supplied.

No submission, native commands, ready admission or pending/null Source is created.
Root seals this body with its actual SHA-bound admission at the normal boundary.
"""

import argparse
import fcntl
import importlib.util
import json
import os
import sys
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
PHASE = OWN / "build-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def bound(path, sha):
    ref, _ = lc.bound(Path(path))
    lc.require(ref["sha256"] == sha, "supplied exact Root record")
    return ref


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-adoption", required=True)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--handover", required=True)
    parser.add_argument("--handover-sha256", required=True)
    args = parser.parse_args()
    adoption = bound(args.source_adoption, args.source_sha256)
    handover_ref = bound(args.handover, args.handover_sha256)
    source = lc.document(adoption)["source"]  # VERBATIM existing standard Git/Cargo owner.
    handover = lc.document(handover_ref)
    lc.require(handover["status"] == "HANDED_OVER", "normal Source-bound handover")
    prior = json.loads((OWN / "prior-build-inputs.json").read_bytes())
    lc.document(prior["original_manifest"])
    lc.document(prior["original_intent"])
    commands = json.loads((OWN / "commands.json").read_bytes())
    lc.require(
        commands[-1]["argv"]
        == next(x["argv"] for x in prior["original_commands"] if x["role"] == "build"),
        "frozen release argv",
    )
    tools = prior["tools"]
    limits = {
        "family_B": 3 * 1024**3,
        "controller_B": 64 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "worker_cpu": 1,
        "guardian_cpu": 3,
        "owned_B": handover["target_max_B"]
        + handover["private_pool_B"]
        + 64 * 1024**2
        + 4 * 1024**2,
        "log_B": 128 * 1024,
        "free_B": 4 * 1024**3,
    }
    spec = {
        "schema": "quoridor.research.lifecycle-intent.v1",
        "kind": "build",
        "owner": str(MAIN / ".worktree"),
        "writer": "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0",
        "cwd": str(MAIN),
        "output": str(PHASE / "operation-v1"),
        "env": {**prior["env"], "TMPDIR": str(PHASE / "TMP-v1")},
        "limits": limits,
        "support": handover["support"],
        "source_adoption": adoption,
        "target_handover": handover_ref,
        "source": source,
        "tools": tools,
        "target": handover["target"],
        "private": handover["candidate"],
        "TMP": str(PHASE / "TMP-v1"),
        "commands": commands,
        "finalizers": [],
        "artifact_target": "quoridor-runner",
    }
    os.sched_setaffinity(0, {1, 3})
    lc.physical_and_quiet(spec)
    with (
        lc.lease(),
        Path("/home/vscode/.cache/inference/envs/quoridor-training.setup.lock").open(
            "r"
        ) as env_reader,
    ):
        fcntl.flock(env_reader, fcntl.LOCK_SH | fcntl.LOCK_NB)
        lc.require(not PHASE.exists(), "unique unfinished normal BUILD")
        lc.build_check(spec)
        for tool in tools.values():
            lc.read_ref(tool["file"], max(lc.CONTROL_BYTES, tool["file"]["bytes"]))
        target = lc.allocated(spec["target"])
        lc.require(target <= handover["target_max_B"], "hard actual target cap")
        private = lc.allocated(Path(spec["private"]).parent)
        lc.require(private <= handover["fresh_private_forward_max_B"], "private parent cap")
        lc.require(lc.allocated(OWN) < 4 * 1024**2, "issued software component")
        PHASE.mkdir()
        digest = lc.sha(json.dumps(spec, sort_keys=True, separators=(",", ":")).encode())
        lc.new_json(PHASE / "intent-body.json", spec)
        lc.new_json(
            PHASE / "admission-request.json",
            {
                "ready": False,
                "spec_sha256": digest,
                "support": spec["support"],
                "source_adoption": adoption,
                "target_handover": handover_ref,
                "limits": limits,
                "preflight": {
                    "target_allocated_B": target,
                    "private_allocated_B": private,
                    "reader_STOP": lc.stamp(),
                },
            },
        )
        lc.new_json(
            PHASE / "job-selection.json",
            {
                "issue": "quoridor-4lc.374.1",
                "goal_issue": "quoridor-4lc.374",
                "thread_id": "01a11062-b120-73a1-8aa3-fe2cb922c7c0",
                "cwd": str(MAIN),
                "current_common_entry_python": sys.executable,
                "entry": str(MAIN / "scripts/dev/research-lifecycle.py"),
                "command": "build",
                "sealed_intent_destination": str(PHASE / "intent.json"),
                "runtime_destination": str(PHASE / "runtime-v1"),
                "max_runtime_seconds": None,
                "end_at": None,
                "notify_until": None,
                "log_max_bytes": 16384,
                "resource_contract": spec["support"]["path"],
                "status": "Root must bind actual ready admission and sealed intent SHA; this is not a job config",
            },
        )
        source_stop = lc.stamp()
    lc.new_json(
        PHASE / "preparation-STOP.json",
        {
            "source_reader_STOP": source_stop,
            "lease_release": lc.stamp(),
            "remaining": [],
            "reservation": None,
            "native_commands": 0,
        },
    )
    print(
        json.dumps(
            {
                "body": lc.bound(PHASE / "intent-body.json")[0],
                "request": lc.bound(PHASE / "admission-request.json")[0],
                "ready": False,
            }
        )
    )


if __name__ == "__main__":
    main()
