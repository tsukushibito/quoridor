"""Run only the newly affected NN0 sequence definitions through the existing guardian."""

import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
loader = importlib.util.spec_from_file_location("lc", ROOT / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
paths = [
    OWN / "post/scripts/dev/research-lifecycle.py",
    OWN / "post/tools/research-session/test_sequence.py",
    ROOT / "scripts/dev/research-job.py",
    ROOT / "python/quoridor_training/cycle_process.py",
]
before = [lc.bound(path)[0] for path in paths]
lc.physical_and_quiet(
    {
        "kind": "run",
        "limits": {
            "family_B": 512 * 1024**2,
            "host_reserve_B": 4 * 1024**3,
            "worker_cpu": 4,
            "guardian_cpu": 6,
        },
    }
)
out = OWN / "python-v1"
out.mkdir()
tmp = out / "TMP"
tmp.mkdir()
with lc.lease():
    capture = lc.Capture(out / "full.log", 256 * 1024)
    returned = None
    primary = None
    secondary = []
    try:
        returned = lc.process.execute(
            [sys.executable, "-B", str(paths[1]), "SequenceTests", "-v"],
            out / "command.log",
            None,
            cpu_cores=[4, 6],
            cwd=ROOT,
            env={**os.environ, "TMPDIR": str(tmp), "RESEARCH_LIFECYCLE_SOURCE": str(paths[0])},
            resources=lc.process.CycleResources(
                {
                    "host_ram_reserve": 4 * 1024**3,
                    "max_memory_bytes": 512 * 1024**2,
                    "max_output_bytes": None,
                },
                out,
                None,
            ),
            output_sink=capture,
        )
    except BaseException as error:
        primary = lc.error_fact(error)
    finally:
        for stage, action in [("capture_close", capture.close), ("owned_TMP_cleanup", tmp.rmdir)]:
            try:
                action()
            except BaseException as error:
                secondary.append({"stage": stage, **lc.error_fact(error)})
    for value in before:
        lc.read_ref(value, value["bytes"])
    lc.new_json(
        out / "result.json",
        {
            "returned_guardian": returned,
            "primary": primary,
            "secondary": secondary,
            "full_capture": lc.bound(out / "full.log")[0],
            "before_after_MATCH": before,
            "actual_reader_STOP": lc.stamp(),
            "source_scope": "NN0 new sequence tests only",
            "actual_model_native_Search_game_calls": 0,
        },
    )
print(json.dumps({"result": lc.bound(out / "result.json")[0], "canonical_release": lc.stamp()}))
raise SystemExit(0 if returned is not None and primary is None and not secondary else 1)
