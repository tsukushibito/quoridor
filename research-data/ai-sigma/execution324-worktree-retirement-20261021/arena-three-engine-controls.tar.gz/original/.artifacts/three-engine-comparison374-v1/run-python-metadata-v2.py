"""Run only the eight selected metadata assertions through the existing guardian."""

import importlib.util
import json
import os
import time
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
OUT = OWN / "python-software-v2"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
test = MAIN / "tools/research-session/test_arena_plan.py"
methods = [
    "test_three_engine_374_issued_family_budget_refuses_unissued_or_wider_envelopes",
    "test_three_engine_374_actual_cost_phase_binds_case_order_image_plan_and_full_requests",
    "test_three_engine_374_closed_sigma_backend_and_current_libraries",
    "test_three_engine_374_single_parent_engine_schedule_and_unknown_denominator",
    "test_three_engine_374_sigma_authority_receipt_is_distinct_from_drain",
    "test_three_engine_374_exact_full_prefix_is_distinct_from_accepted_suffix",
    "test_three_engine_374_reference_roundtrip_partial_torn_and_first_primary",
    "test_three_engine_374_saved_analysis_keeps_missing_denominators",
]
limits = {
    "family_B": 3 * 1024**3,
    "host_reserve_B": 4 * 1024**3,
    "worker_cpu": 1,
    "guardian_cpu": 3,
    "log_B": 1024**2,
}
spec = {
    "cwd": str(MAIN),
    "limits": limits,
    "env": {
        **os.environ,
        "TMPDIR": str(OUT / "TMP"),
        "PYTHONDONTWRITEBYTECODE": "1",
        "CUDA_VISIBLE_DEVICES": "",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "ARENA_361_LIFECYCLE": str(MAIN / "scripts/dev/research-lifecycle.py"),
    },
}
lc.physical_and_quiet(spec)
with lc.lease():
    assert lc.allocated(OWN) + 2 * 1024**2 <= 48 * 1024**2
    assert lc.shutil.disk_usage(OWN).free >= 4 * 1024**3
    build_ref = lc.bound(OWN / "software-build-v2/operation-v2/manifest.json")[0]
    manifest = lc.accepted_build(build_ref)
    selected = {r["path"]: r for r in manifest["source"]["files"]}
    paths = [
        test,
        MAIN / "scripts/dev/research-lifecycle.py",
        MAIN / "python/quoridor_training/cycle_process.py",
        MAIN / "python/quoridor_training/snapshot.py",
        MAIN / "python/quoridor_training/__init__.py",
    ]
    refs = [selected[str(path)] for path in paths]
    for ref in refs:
        lc.read_ref(ref)
    OUT.mkdir()
    (OUT / "TMP").mkdir()
    argv = [
        "/bin/bash",
        str(MAIN / "scripts/dev/project-env.sh"),
        "python",
        "-B",
        str(test),
        *["ArenaPlanTests." + name for name in methods],
        "-v",
    ]
    resources = lc.process.CycleResources(
        {
            "host_ram_reserve": limits["host_reserve_B"],
            "max_memory_bytes": limits["family_B"] - 64 * 1024**2,
            "max_output_bytes": 2 * 1024**2,
        },
        OUT,
        time.monotonic() + 300,
    )
    row = {"name": "python-eight374", "role": "software", "argv": argv}
    checks = []
    primary = None
    started = lc.stamp()
    try:
        lc.command(spec, row, OUT, resources, ledger=checks)
    except BaseException as error:
        primary = lc.error_fact(error)
    secondary = []
    for ref in refs:
        try:
            lc.read_ref(ref)
        except BaseException as error:
            secondary.append({"stage": "source_after", **lc.error_fact(error)})
    try:
        (OUT / "TMP").rmdir()
    except BaseException as error:
        secondary.append({"stage": "TMP_cleanup", **lc.error_fact(error)})
    receipt = {
        "scope": "Eight current NN0 metadata methods only; synthetic source/build/model/backend/guardian ports, no real native/model/inference/Search calls",
        "build_manifest": build_ref,
        "actual_source_refs_before_after": refs,
        "methods": methods,
        "started_at": started,
        "checks": checks,
        "primary": primary,
        "secondary": secondary,
        "status": "FAILED" if primary or secondary else "PASS",
        "reader_STOP": lc.stamp(),
        "owned_readers_children_jobs_TMP_remaining": [],
        "reservation": "NONE after exact guardian return/source-after/cleanup",
        "child_worker_UTC_STOP": "UNKNOWN; parent return is not an independent child clock",
    }
    lc.new_json(OUT / "receipt.json", receipt)
    print(json.dumps({"status": receipt["status"], "receipt": lc.bound(OUT / "receipt.json")[0]}))
    if primary or secondary:
        raise SystemExit(1)
