"""Seal and submit only the original first pair with genuine Root-issued admission."""

import argparse
import importlib.util
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
HERE = OWN / "primary-controls-v3"
PHASE = HERE / "batch-000"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--admission", type=Path, required=True)
parser.add_argument("--admission-sha256", required=True)
args = parser.parse_args()
current_python = lc.document(ref(PHASE / "current-Python.json"))
lc.require(
    sys.executable == current_python["sys_executable"], "same current qualified public-entry Python"
)
lc.read_ref(current_python["resolved_binary"], 64 * 1024**2)
original_affinity = os.sched_getaffinity(0)
lc.require(
    not (PHASE / "submission.json").exists()
    and not (PHASE / "runtime-v1").exists()
    and not (PHASE / "intent.json").exists(),
    "original first pair only; ambiguous/repeated submission refused",
)
admission_ref = ref(args.admission)
lc.require(admission_ref["sha256"] == args.admission_sha256, "actual supplied admission SHA")
admission = lc.document(admission_ref)
spec = lc.document(ref(PHASE / "intent-body.json"))
lc.require(
    spec["kind"] == "run"
    and spec["owner"] == str(OWN)
    and spec["output"] == str(PHASE / "operation-v1")
    and admission["ready"] is True
    and admission["owner"] == spec["owner"]
    and admission["approved_plan"] == spec["approved_plan"]
    and admission["limits"] == spec["limits"]
    and admission["spec_sha256"] == spec["intent_sha256"]
    and admission["support_sha256"] == spec["support"]["sha256"],
    "genuine selected phase admission",
)
spec["admission"] = admission_ref
lc.physical_and_quiet(spec)
with lc.lease():
    lc.experiment_check(spec)
    resources = lc.Limits(spec)
    resources.check()
    lc.require(not Path(spec["TMP"]).exists(), "unique current serial TMP")
    Path(spec["TMP"]).mkdir()
    lc.new_json(PHASE / "intent.json", spec)
    intent = ref(PHASE / "intent.json")
    lc.accepted_build(lc.document(spec["experiment"])["build_manifest"])
    job_config = {
        "issue": "quoridor-4lc.374.1",
        "goal_issue": "quoridor-4lc.374",
        "thread_id": "01a11062-b120-73a1-8aa3-fe2cb922c7c0",
        "cwd": str(MAIN),
        "argv": [
            sys.executable,
            "-B",
            str(MAIN / "scripts/dev/research-lifecycle.py"),
            "run",
            "--intent",
            intent["path"],
            "--sha256",
            intent["sha256"],
        ],
        "end_at": None,
        "notify_until": None,
        "max_runtime_seconds": None,
        "control_interval_seconds": 30,
        "notify_interval_seconds": 10,
        "request_timeout_seconds": 25,
        "log_max_bytes": 16384,
        "resource_contract": spec["support"]["path"],
    }
    lc.new_json(PHASE / "config.json", job_config)
    lc.new_json(
        PHASE / "launch-preflight.json",
        {
            "at": lc.stamp(),
            "intent": intent,
            "admission": admission_ref,
            "physical_available_B": lc.process.available_memory(),
            "owned_union_B": sum(lc.allocated(p) for p in lc.charged_roots(spec)),
            "FS_free_B": lc.shutil.disk_usage(OWN).free,
            "current_normal_experiment_guard": "PASS; parent repeats full lifetime guards",
            "games_before_submit": 0,
        },
    )
lease_STOP = lc.stamp()
# Submission follows release of this finite preflight lease; the real worker repeats it.
os.sched_setaffinity(0, original_affinity)
result = subprocess.run(
    [
        "bash",
        str(MAIN / "scripts/dev/research-job.sh"),
        "submit",
        "--config",
        str(PHASE / "config.json"),
        "--state-dir",
        str(PHASE / "runtime-v1"),
    ],
    capture_output=True,
    text=True,
    timeout=45,
    env={**os.environ, "GOMEMLIMIT": "128MiB", "NODE_OPTIONS": "--max-old-space-size=128"},
)
lc.new_json(
    PHASE / "submission.json",
    {
        "exit_code": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "preflight_lease_STOP": lease_STOP,
        "intent": intent,
        "config": ref(PHASE / "config.json"),
        "note": "Submission is not native START/PASS; original completion event owns collection, no polling or retry",
    },
)
print(result.stdout)
print(result.stderr)
raise SystemExit(result.returncode)
