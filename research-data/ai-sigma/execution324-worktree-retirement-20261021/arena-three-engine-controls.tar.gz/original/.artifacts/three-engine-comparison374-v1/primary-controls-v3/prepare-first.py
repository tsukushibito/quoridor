"""Prepare the original first arena pair on current normal metadata ports only."""

import copy
import importlib.util
import json
import os
import resource
from pathlib import Path
import sys

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
OUT = OWN / "primary-controls-v3"
ENTRY = OUT / "batch-000"
loader = importlib.util.spec_from_file_location("lc", MAIN / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def document(path):
    return lc.document(ref(path))


def prepare():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))

    plan_ref = ref(MAIN / "research-data/ai-sigma/three-engine-comparison374/approved-plan-v3.json")
    lc.require(
        (plan_ref["sha256"], plan_ref["bytes"], plan_ref["mode"])
        == ("9bdce0bb8fcca86b9e168080f31d7a58c99e8e0b3d5160cac860607e5fc2302a", 126152, "0644"),
        "actual current Root-approved plan",
    )
    plan = lc.document(plan_ref)
    support = ref(MAIN / "research-data/ai-sigma/three-engine-comparison374/support-v2.json")
    lc.require(
        support["sha256"] == "4a3a5d390eef2a70d280121d98644de98fc31f9547d4b28240245b7f870f1e3c",
        "existing whole support",
    )
    document(OUT / "preprice.json")
    preparation_limits = {
        "family_B": 512 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "worker_cpu": 1,
        "guardian_cpu": 3,
    }
    lc.physical_and_quiet({"cwd": str(MAIN), "limits": preparation_limits})
    old_spec = document(OWN / "cost-qualification-v1/phase1-entry-v1/intent.json")
    build_ref = lc.document(old_spec["experiment"])["build_manifest"]
    build = lc.accepted_build(build_ref)
    artifact = build["artifact"]
    tuple_ref = ref(OWN / "runtime-binding-v2/stopped-tuple-binding.json")
    tuple_record = lc.document(tuple_ref)
    lc.require(
        tuple_ref["sha256"] == "7bc52119f3848a222d16c95a4226d083209db7a2d9df7704c08af79f39db670d"
        and artifact["sha256"]
        == "875a49bcade5f4a0234a41eee07ea07d3d5561bdb8f344f5ac3173687e260a9d",
        "genuine runtime tuple and private image",
    )
    batch = plan["batches"][0]
    config = lc.document(batch["config"])
    lc.require(
        batch["slots"] == [0, 1]
        and batch["matchup"] == 0
        and batch["config"]["sha256"]
        == "994bd4c12c95422dbd48efc97aa89a2f526f7fb27393a13048f50fb52fa5cb34"
        and [engine["kind"] for engine in config["engines"]] == ["mcts", "distance"]
        and config["games"] == 2
        and config["max_output_bytes"] == 16777216
        and not os.path.lexists(config["output"]),
        "original first Sigma-D pair, no active NNUE engine",
    )
    callers = copy.deepcopy(old_spec["caller_sources"])
    runtime_refs = [
        ref(MAIN / "scripts/dev/project-env.sh"),
        ref(Path(sys.executable).resolve()),
        ref(Path(sys.prefix) / "pyvenv.cfg"),
        *tuple_record["loaded_ELF_subjects"],
    ]
    lc.require(
        sys.executable == "/home/vscode/.cache/inference/envs/quoridor-training/bin/python"
        and str(Path(sys.prefix).resolve()) == os.environ["QUORIDOR_PROJECT_ENV"],
        "actual current project-entry Python, independent of historical BUILD tools",
    )
    dynamic = [
        {
            "file": value,
            "version": (
                tuple_record["actual_loaded_CAPI_version"]
                if value == tuple_record["actual_loaded_ORT_library"]
                else "UNKNOWN; exact ELF FileRef, not a separately observed semantic version"
            ),
        }
        for value in tuple_record["loaded_ELF_subjects"]
        if value["path"] != str(Path(sys.executable).resolve())
    ]
    evidence_paths = [
        MAIN
        / "research-data/ai-sigma/sigma-receipt-reevaluation-v1/bounded-cohort-acceptance-v31.json",
        MAIN / "research-data/ai-sigma/fixed-depth-comparison358/acceptance-v1.json",
        MAIN / "research-data/ai-sigma/three-engine-comparison374/backend-expectation-v1.json",
        MAIN / "research-data/ai-sigma/three-engine-comparison374/source-adoption-v1.json",
        MAIN / "research-data/ai-sigma/build-provenance379/acceptance-v1.json",
        OWN / "source-proof-v1.json",
        OWN / "related-v2/current-source-proof-v2.json",
        OWN / "fault-repair-v3/source-STOP-binding.json",
    ]
    # The original coverage locator is taken from its stopped record, never guessed.
    coverage_stop = document(OWN / "software-build-v3/failed-STOP-binding.json")
    coverage_refs = []
    for key, value in coverage_stop.items():
        if "coverage" in key and isinstance(value, dict) and "path" in value:
            coverage_refs.append(value)
    proof_refs = [ref(path) for path in evidence_paths] + coverage_refs
    proof_refs += [build_ref, tuple_ref]
    lc.require(not ENTRY.exists(), "unique unentered first-pair controls")
    inputs = [
        *plan["inputs"],
        *callers,
        *runtime_refs,
        *proof_refs,
        plan_ref,
        batch["config"],
        plan["schedule"],
        support,
        artifact,
    ]
    for model in plan["models"]:
        inputs += [model["descriptor"], model["weights"]]
    inputs = list({value["path"]: value for value in inputs}.values())
    for value in inputs:
        lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
    lc.require(
        sum(
            lc.allocated(p)
            for p in [OUT, OWN / "primary-controls-v2", OWN / "primary-cap-repair-v1"]
        )
        + 1024**2
        <= 49 * 1024**2,
        "first inlet controls contained",
    )
    ENTRY.mkdir()
    experiment = {
        "schema": lc.EXPERIMENT_SCHEMA,
        "phase": "arena",
        "build_manifest": build_ref,
        "config": batch["config"],
        "inputs": plan["inputs"],
        "models": plan["models"],
        "dynamic_libraries": dynamic,
        "schedule": plan["schedule"],
        "numerical_qualification": None,
        "canonical_plan_sha256": plan_ref["sha256"],
        "rules": plan["rules"],
        "distance_units": plan["distance_units"],
        "value_perspective": plan["value_perspective"],
        "planned_slots": plan["planned_slots"],
        "batch": 0,
        "argv": [
            artifact["path"],
            "arena",
            "--experiment",
            "@EXPERIMENT@",
            "--experiment-sha256",
            "@EXPERIMENT_SHA256@",
        ],
    }
    lc.new_json(
        ENTRY / "original-evidence-scopes.json",
        {
            "refs": proof_refs,
            "scope": "Original subjects remain original; current numerical_fields is an exact loader correspondence dictionary, not a new numerical result",
            "Sigma": "Current factory/tuple expectation proof and original64 cost rows bind current model/backend. Original347 accepted receipt/codec/rules evidence retains old image/config/window; expired cost packet is not used",
            "D": "Retained fixed a0/b8 distance evaluator, unchanged evaluator/rule/history routines cited by reviewed source proof and old347/358 actual executions; changed374 envelope/selector/publication has its actual reviewed source and synthetic software scope",
            "book": "Original355 immutable a6ab book, full histories and target-blind family selection; source proof retains replay; current plan/config checks bind original prefix/history/colour",
            "NNUE": "Descriptor/weights remain plan lifetime identities across all three matchups; neither first-pair active engine is NNUE. Original358 model scope is not a current image head result",
            "new_head_or_model_calls": 0,
            "strength_default_or_hard_realtime_claim": False,
            "original_receipts_modified": False,
        },
    )
    numerical = lc.numerical_fields(experiment, build)
    numerical.update(
        correspondence_only=True,
        new_model_or_head_calls=0,
        original_evidence=ref(ENTRY / "original-evidence-scopes.json"),
        scope="PASS of exact current loader/config/plan/model identities backed by original-scoped evidence; no fresh forward/head/game/strength PASS",
    )
    lc.new_json(ENTRY / "numerical-correspondence.json", numerical)
    experiment["numerical_qualification"] = ref(ENTRY / "numerical-correspondence.json")
    lc.new_json(ENTRY / "Experiment.json", experiment)
    spec = {
        k: copy.deepcopy(v) for k, v in old_spec.items() if k not in {"admission", "intent_sha256"}
    }
    spec.update(
        output=str(ENTRY / "operation-v1"),
        experiment=ref(ENTRY / "Experiment.json"),
        approved_plan=plan_ref,
        data_root=config["output"],
        TMP=str(OWN / "primary-serial-TMP-v2"),
        owned_outputs=[
            str(OUT),
            str(OWN / "primary-controls-v2"),
            str(OWN / "primary-cap-repair-v1"),
            str(OWN / "primary-output-v1"),
        ],
        finalizers=[],
    )
    spec["env"]["TMPDIR"] = spec["TMP"]
    spec["limits"].update(owned_B=(49 + 468 + 64 + 32) * 1024**2, log_B=16384)
    spec["data"] = [
        {
            "name": "journal",
            "path": str(Path(spec["data_root"]) / "completed.jsonl.gz"),
            "limit_B": 2 * (630784 + 1) + 65536,
        },
        {"name": "result", "path": str(Path(spec["data_root"]) / "result.json"), "limit_B": 65536},
        {
            "name": "native_manifest",
            "path": str(Path(spec["data_root"]) / "manifest.json"),
            "limit_B": 65536,
        },
    ]
    spec["argv"] = [
        a.replace("@EXPERIMENT@", spec["experiment"]["path"]).replace(
            "@EXPERIMENT_SHA256@", spec["experiment"]["sha256"]
        )
        for a in experiment["argv"]
    ]
    spec["intent_sha256"] = lc.sha(json.dumps(spec, sort_keys=True, separators=(",", ":")).encode())
    lc.new_json(ENTRY / "intent-body.json", spec)
    lc.new_json(
        ENTRY / "admission-request.json",
        {
            "schema": "quoridor.research.phase-admission.v1",
            "owner": spec["owner"],
            "limits": spec["limits"],
            "spec_sha256": spec["intent_sha256"],
            "support_sha256": support["sha256"],
            "approved_plan": plan_ref,
            "ready": False,
        },
    )
    lc.new_json(
        ENTRY / "current-Python.json",
        {
            "sys_executable": sys.executable,
            "resolved_binary": ref(Path(sys.executable).resolve()),
            "prefix": sys.prefix,
            "public_entry": ref(MAIN / "scripts/dev/project-env.sh"),
        },
    )
    # These are owning metadata checks, never a native/model launch or ready admission.
    # Full experiment_check requires genuine Root admission; this is preparation only.
    lc.experiment_phase_check(experiment)
    lc.caller_source_refs(spec, experiment)
    lc.arena_plan_check(experiment, plan)
    lc.numerical_check(experiment, build)
    for value in inputs:
        lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
    lc.new_json(
        ENTRY / "preparation-receipt.json",
        {
            "status": "STOPPED_FIRST_PAIR_NORMAL_METADATA_PREPARED_NOT_ADMITTED_NOT_SUBMITTED",
            "intent": ref(ENTRY / "intent-body.json"),
            "Experiment": ref(ENTRY / "Experiment.json"),
            "config": batch["config"],
            "current_numerical_correspondence": experiment["numerical_qualification"],
            "original_evidence_scopes": ref(ENTRY / "original-evidence-scopes.json"),
            "actual_current_refs_before_after_MATCH": inputs,
            "normal_experiment_check": "Pending actual ready Root admission; only pre-admission metadata functions checked",
            "normal_charged_roots": [str(path) for path in lc.charged_roots(spec)],
            "new_native_model_head_Search_game_calls": 0,
            "reader_STOP": lc.stamp(),
            "owned_readers_children_jobs_TMP_remaining": [],
            "whole_control_projection_pending": False,
            "current_allocator": ref(
                MAIN
                / ".artifacts/research-team/integration324/374-primary-controls-settlement-v1/controls-support.json"
            ),
            "operational_cap_adoption": ref(
                MAIN
                / ".artifacts/research-team/integration324/374-output-cap-plan-v3/adoption.json"
            ),
            "old_failed_first_entry": ref(
                OWN / "primary-controls-v2/batch-000/operation-v1/manifest.json"
            ),
        },
    )


with lc.lease():
    prepare()
print(json.dumps({"first_pair_prepared": True, "canonical_lease_released": lc.stamp()}))
