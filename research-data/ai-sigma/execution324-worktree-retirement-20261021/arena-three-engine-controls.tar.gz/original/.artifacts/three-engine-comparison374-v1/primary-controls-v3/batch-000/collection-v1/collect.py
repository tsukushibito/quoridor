"""Retain the original failed pair's saved facts without runtime replay."""

import collections
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import subprocess

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
ENTRY = OWN / "primary-controls-v3/batch-000"
OUT = ENTRY / "collection-v1"
loader = importlib.util.spec_from_file_location("lc", MAIN / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def document(path):
    return lc.document(ref(path))


def same_identity(identity):
    path = Path(f"/proc/{identity['pid']}/stat")
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    if not path.exists():
        return "ABSENT"
    ticks = path.read_text().rsplit(")", 1)[1].split()[19]
    lc.require(
        boot != identity["boot_id"] or ticks != str(identity["start_ticks"]),
        "original selected process still exists",
    )
    return "DIFFERENT"


resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
lc.physical_and_quiet(
    {
        "cwd": str(MAIN),
        "limits": {
            "family_B": 512 * 1024**2,
            "host_reserve_B": 4 * 1024**3,
            "worker_cpu": 1,
            "guardian_cpu": 3,
        },
    }
)
with lc.lease():
    price = document(OUT / "preprice.json")
    before = document(ENTRY / "preparation-receipt.json")
    refs = before["actual_current_refs_before_after_MATCH"]
    for value in refs:
        lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
    manifest_ref = ref(ENTRY / "operation-v1/manifest.json")
    manifest = lc.document(manifest_ref)
    lc.require(
        manifest["status"] == "FAILED" and not (ENTRY / "operation-v1/INCOMPLETE").exists(),
        "original authoritative failure already finalized once",
    )
    job = document(ENTRY / "runtime-v1/result.json")
    state = document(ENTRY / "runtime-v1/state.json")
    disk = document(ENTRY / "operation-v1/run.process.json")
    lc.require(
        job["job_id"] == state["job_id"] == "1a11e5ab-513f-4b6a-a487-b7894ce91874",
        "original job scope",
    )
    identities = [state["supervisor"], state["child"], disk["child"]]
    identities.append(document(OUT / "finalize-return.json")["child_identity"])
    after = [{"identity": i, "observed": same_identity(i)} for i in identities]
    spec = document(ENTRY / "intent.json")
    data = Path(spec["data_root"])
    result_ref = ref(data / "result.json")
    result = lc.document(result_ref)
    archive_ref = result["archive"]["compressed"]
    lc.read_ref(archive_ref, spec["data"][0]["limit_B"])
    rows = []
    samples = []
    raw_hash = hashlib.sha256()
    raw_bytes = 0
    accepted_sigma = 0
    other_false = collections.Counter()
    # This only labels the already-returned conjunct refusal. It is not an
    # alternate validator, outcome acceptance, geometry replay or model call.
    with gzip.open(archive_ref["path"], "rb") as handle:
        for line in handle:
            lc.require(len(line) <= 630785, "declared original outcome byte bound")
            raw_hash.update(line)
            raw_bytes += len(line)
            row = json.loads(line)
            rows.append(
                {
                    **{
                        key: row[key]
                        for key in (
                            "game",
                            "family",
                            "candidate_color",
                            "status",
                            "winner",
                            "plies",
                            "started",
                            "reason",
                            "nn_calls",
                        )
                    },
                    "observation_count": len(row["observations"]),
                }
            )
            for index, observation in enumerate(row["observations"]):
                if not observation["accepted"] or observation["engine_index"] != 0:
                    continue
                accepted_sigma += 1
                counters = observation["counters"]
                if observation["returned_ns"] < counters["authority_receipt_ns"]:
                    samples.append(
                        {
                            "game": row["game"],
                            "observation_index": index,
                            "ply": observation["ply"],
                            "action": observation["action"],
                            "returned_ns": observation["returned_ns"],
                            "drain_finished_ns": counters["drain_finished_ns"],
                            "authority_receipt_ns": counters["authority_receipt_ns"],
                            "inversion_ns": counters["authority_receipt_ns"]
                            - observation["returned_ns"],
                            "deadline_ns": observation["deadline_ns"],
                        }
                    )
                conditions = {
                    "before_deadline": counters["authority_receipt_ns"]
                    < observation["deadline_ns"],
                    "authority_legal": counters["authority_legal"] is True,
                    "inflight_zero": counters["inflight_after_drain"] == 0,
                    "positive_simulations": counters["completed_simulations"] > 0,
                    "clock_contract": counters["clock_contract"] == "authority-action-receipt-v1",
                    "contract_sha": counters["clock_contract_sha256"]
                    == "04062382f70648cdfd722e59c35be1100719169097a04749b0046ea5a19a280d",
                    "drain_equals_return": counters["drain_finished_ns"]
                    == observation["returned_ns"],
                    "no_depth": observation["completed_depth"] is None,
                    "no_PV": observation["pv"] == [],
                }
                other_false.update(key for key, value in conditions.items() if not value)
    lc.require(
        raw_hash.hexdigest() == result["archive"]["raw_sha256"]
        and raw_bytes == result["archive"]["raw_bytes"]
        and len(rows) == result["outcome_count"] == result["journal_count"] == 2,
        "original closed archive identity/count",
    )
    directed = []
    original_build_git = "b54c836870b657d2172562a2f8963b7e6003f530"
    for relative in (
        "crates/quoridor-runner/src/runtime.rs",
        "crates/quoridor-runner/src/arena.rs",
    ):
        current_ref, current = lc.bound(MAIN / relative)
        history = subprocess.run(
            ["git", "-C", str(MAIN), "show", original_build_git + ":" + relative],
            capture_output=True,
            check=True,
        ).stdout
        lc.require(current == history, "directed built error-path subject changed")
        directed.append({"path": relative, "current": current_ref, "built_git_blob_exact": True})
    source = (MAIN / "crates/quoridor-runner/src/runtime.rs").read_text()
    at = source.index("let drained = Instant::now();\n        drop(notify_tx);")
    joined = source.index("let receipt = authority\n            .join()", at)
    lc.require(at < joined, "directed timestamp placement")
    lc.new_json(
        OUT / "smallest-condition.json",
        {
            "issue": "quoridor-4lc.374.1",
            "original_manifest": manifest_ref,
            "original_archive": archive_ref,
            "original_result": result_ref,
            "scope": "Saved original facts/directed actual refusal, NOT a replacement validator or accepted outcome",
            "raw_finished_game_rows": rows,
            "raw_started_goal_count": 2,
            "validated_observed_local_games": manifest["data"]["observed_local_games"],
            "normal_missing_local_games": manifest["data"]["missing_local_games"],
            "global_slots": [0, 1],
            "remaining_campaign_unentered": 766,
            "accepted_Sigma_observation_count": accepted_sigma,
            "return_before_receipt_count": len(samples),
            "by_game": dict(collections.Counter(row["game"] for row in samples)),
            "first_original_violation": samples[0],
            "maximum_inversion_ns": max(row["inversion_ns"] for row in samples),
            "other_Sigma_conjunct_false_counts": dict(other_false),
            "clock_order_labels": samples,
            "raw_bytes": raw_bytes,
            "raw_sha256": raw_hash.hexdigest(),
            "directed_builtin_scope": directed,
            "built_git": original_build_git,
            "source_cause": "Runtime captures drained before joining the authority thread; returned/drain_finished reuse that earlier timestamp. Authority receipt can occur later. Native and Python accepted-observation guards reject returned_ns < receipt_ns",
            "smallest_owning_gap": "Correct real returned/drain timestamp after both inference drain and authority receipt/join; keep genuine100ms authority receipt, resource/cancel/error/refusal guards and original timestamps/FAILED/raw untouched. Root owns source repair/adjudication; no future runtime entry or acceptance from this packet",
            "source_reader_STOP": lc.stamp(),
            "new_model_or_head_Search_game_calls": 0,
        },
    )
    for value in refs:
        lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
    lc.new_json(
        OUT / "current-refs-process-STOP.json",
        {
            "actual_current_refs_before_after_MATCH": refs,
            "original_identities_after": after,
            "original_job": ref(ENTRY / "runtime-v1/result.json"),
            "manifest": manifest_ref,
            "data_refs": [archive_ref, result_ref, ref(data / "manifest.json")],
            "data_all_workers_joined": result["report"]["all_workers_joined"],
            "backend_cleanup_seconds_original": result["report"]["pump"]["backend_cleanup_seconds"],
            "original_backend_work": result["report"]["pump"]["backend_work"],
            "source_model_library_input_image_caller_reader_STOP": lc.stamp(),
            "owned_readers_children_jobs_remaining": [],
            "TMP_cleanup": "Exact own empty uv lock cleanup follows metadata directwait",
            "native_model_head_Search_game_replay": 0,
        },
    )
    lc.require(
        lc.allocated(OUT) + 65536 <= price["inclusive_collection_upper_B"],
        "collection control tail contained",
    )
print(json.dumps({"saved_only": True, "original_status": "FAILED", "lease_RELEASED": lc.stamp()}))
