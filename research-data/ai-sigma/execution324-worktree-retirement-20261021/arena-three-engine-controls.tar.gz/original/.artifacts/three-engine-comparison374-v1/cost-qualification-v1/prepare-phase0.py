"""Prepare the fixed normal cost phase; Root supplies its one actual launch epoch."""

import argparse
import copy
import importlib.util
import json
import os
from pathlib import Path
import time

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
HERE = OWN / "cost-qualification-v1"
PHASE = HERE / "phase0-entry-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def exact(path, digest, size):
    value = ref(path)
    lc.require(
        (value["sha256"], value["bytes"], value["mode"]) == (digest, size, "0644"),
        "supplied metadata FileRef",
    )
    return value


def write(path, value):
    lc.new_json(path, value)
    return ref(path)


def control(value):
    return {"path": value["path"], "sha256": value["sha256"]}


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--launch-unix-ms", type=int)
args = parser.parse_args()
proof_ref = exact(
    MAIN / "research-data/ai-sigma/three-engine-comparison374/backend-expectation-v1.json",
    "a2bbb16185ce2b42f16ac5cf0b22817d5f72e45bccfd3ff80e243a7835f7881c",
    7306,
)
proof = lc.document(proof_ref)
approved = exact(
    MAIN / "research-data/ai-sigma/three-engine-comparison374/approved-plan-v1.json",
    "2dd5cc1d5073910ca0ba8c8a95a61f45021ec9482571b5fdaafccc5eb17d88b6",
    158905,
)
root_STOP = exact(
    MAIN / ".artifacts/research-team/integration324/374-backend-expectation-v1/Root-Git-STOP.json",
    "ad540f7ba75d82e91b4aef5ba73dd840e37773cec8ed53bc3bc56be3070d411f",
    1216,
)
lc.document(root_STOP)
tuple_ref = proof["current_stopped_tuple"]
bindings = lc.document(tuple_ref)
support = bindings["support"]
lc.document(support)
preprice = lc.document(ref(HERE / "preprice.json"))
lc.require(preprice["inclusive_two_phase_upper_B"] == 24 * 1024**2, "issued cost containment")
cases_ref = lc.document(approved)["sigma_cost_cases"]
lc.require(cases_ref == bindings["new_cases_derivative"], "unchanged actual approved cases")
cases = lc.document(cases_ref)
campaign_original = lc.document(bindings["new_campaign_derivative"])
expected = proof["expected_backend_sha256_reused_by_reference"]
lc.require(
    expected == "ca4330c4b1dad25d7e16fc7def7d990a5e495235dc2faea38011cab3b1a21f60"
    and proof["current_actual_CAPI_library_ref"] == proof["origin_bound_library_ref"]
    and proof["current_model_ref"] == proof["origin_bound_model_ref"]
    and proof["actual_current_Rust_backend_factory_constructed_verified"] is False,
    "exact source-derived expectation, not current actual backend or Q",
)
build_ref = bindings["authentic_immutable_Build"]
build = lc.accepted_build(build_ref)
artifact = bindings["artifact"]
lc.require(artifact == build["artifact"], "immutable genuine artifact")
caller_paths = {
    str(MAIN / "scripts/dev/research-lifecycle.py"),
    str(MAIN / "scripts/dev/research-job.py"),
    str(MAIN / "python/quoridor_training/cycle_process.py"),
    str(MAIN / "python/quoridor_training/snapshot.py"),
}
callers = [r for r in bindings["current_runtime_refs_before_after"] if r["path"] in caller_paths]
lc.require(len(callers) == 4, "normal native cost caller4")
for item in callers:
    lc.read_ref(item, max(lc.CONTROL_BYTES, item["bytes"]))
campaign = copy.deepcopy(campaign_original)
lc.require(
    campaign["native"]["backend_sha256"] is None
    and campaign["qualification_started_unix_ms"] is None
    and campaign["approved_plan"] is None,
    "original unlaunched current campaign",
)
campaign["native"]["backend_sha256"] = expected
campaign["approved_plan"] = approved
lc.require(
    campaign["configurations"] == cases["configurations"] and campaign["phases"] == cases["phases"],
    "fixed full configs/digests/case order",
)
if args.launch_unix_ms is not None:
    lc.require(0 < args.launch_unix_ms <= time.time_ns() // 1000000, "actual Root launch epoch")
    lc.require(not (HERE / "campaign.json").exists(), "original launch cannot reset")
    campaign["qualification_started_unix_ms"] = args.launch_unix_ms
    campaign["valid_until_unix_ms"] = args.launch_unix_ms + 86400000
    campaign["native"]["valid_until_unix_ms"] = campaign["valid_until_unix_ms"]
    campaign_ref = write(HERE / "campaign.json", campaign)
else:
    campaign_ref = {
        "path": str(HERE / "campaign.json"),
        "sha256": None,
        "bytes": None,
        "mode": "0644",
    }
phase = cases["phases"][0]
lc.require(
    phase["mode"] == "untimed"
    and len(phase["workload"]) == 16
    and sum(x["warmup_logical_calls"] for x in phase["workload"]) == 16
    and sum(x["max_logical_calls"] for x in phase["workload"]) == 32,
    "original16warm16measured",
)
measurement = {
    "schema": "quoridor-sigma-receipt-measurement-v1",
    "phase_id": phase["id"],
    "campaign": control(campaign_ref),
    "configurations": cases["configurations"],
    "native": campaign["native"],
    "output": str(PHASE / "data-v1"),
    "mode": "untimed",
    "max_logical_calls": 32,
    "prior_logical_calls": 0,
    "prior_results": [],
    "workload": phase["workload"],
}
inputs = [
    campaign_ref,
    *[
        r
        for r in bindings["current_runtime_refs_before_after"]
        if r["path"] not in caller_paths and "runtime-binding-v" not in r["path"]
    ],
    proof_ref,
    root_STOP,
]
# Only actual existing subjects; remove repeated device-independent FileRefs by path.
inputs = list({r["path"]: r for r in inputs}.values())
library = {
    "file": proof["current_actual_CAPI_library_ref"],
    "version": proof["current_actual_CAPI_loaded_version"],
}
experiment = {
    "schema": "quoridor.research.experiment.v1",
    "phase": "sigma-cost-qualification",
    "build_manifest": build_ref,
    "config": None,
    "inputs": inputs,
    "models": [],
    "dynamic_libraries": [library],
    "schedule": cases_ref,
    "numerical_qualification": None,
    "canonical_plan_sha256": approved["sha256"],
    "rules": "research-standard-2p-threefold-goal-first-v1",
    "distance_units": "wall-distance/80",
    "value_perspective": "side-to-move",
    "planned_slots": 64,
    "batch": 0,
    "argv": [
        artifact["path"],
        "sigma-cost-measure",
        "--experiment",
        "@EXPERIMENT@",
        "--experiment-sha256",
        "@EXPERIMENT_SHA256@",
    ],
}
limits = {
    "family_B": 3 * 1024**3,
    "controller_B": 64 * 1024**2,
    "host_reserve_B": 4 * 1024**3,
    "owned_B": (24 + 64) * 1024**2,
    "log_B": 4 * 1024**2,
    "free_B": 4 * 1024**3,
    "worker_cpu": 1,
    "guardian_cpu": 3,
}
env = {
    "PATH": os.environ["PATH"],
    "TMPDIR": str(HERE / "TMP"),
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONPATH": str(MAIN / "python"),
    "QUORIDOR_PROJECT_ROOT": str(MAIN),
    "QUORIDOR_PROJECT_ENV": os.environ["QUORIDOR_PROJECT_ENV"],
    "UV_PROJECT_ENVIRONMENT": os.environ["QUORIDOR_PROJECT_ENV"],
    "CUDA_VISIBLE_DEVICES": "",
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "ORT_DISABLE_TELEMETRY": "1",
}
spec = {
    "schema": "quoridor.research.lifecycle-intent.v1",
    "kind": "run",
    "owner": str(OWN),
    "writer": "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0",
    "cwd": str(MAIN),
    "output": str(PHASE / "operation-v1"),
    "env": env,
    "limits": limits,
    "support": support,
    "approved_plan": approved,
    "artifact": artifact,
    "experiment": None,
    "caller_sources": callers,
    "data_root": measurement["output"],
    "owned_outputs": [str(HERE)],
    "TMP": str(HERE / "TMP"),
    "data": [
        {
            "name": "measurement",
            "path": str(PHASE / "data-v1/measurement-result.json"),
            "limit_B": lc.CONTROL_BYTES,
        }
    ],
    "finalizers": [],
    "argv": None,
}
lc.caller_source_refs(spec, experiment)
if args.launch_unix_ms is not None:
    lc.require(not PHASE.exists(), "unique original phase0 entry")
    PHASE.mkdir()
    measurement_ref = write(PHASE / "measurement-plan.json", measurement)
    experiment["config"] = measurement_ref
    experiment_ref = write(PHASE / "Experiment.json", experiment)
    spec["experiment"] = experiment_ref
    spec["argv"] = [
        a.replace("@EXPERIMENT@", experiment_ref["path"]).replace(
            "@EXPERIMENT_SHA256@", experiment_ref["sha256"]
        )
        for a in experiment["argv"]
    ]
    spec["intent_sha256"] = lc.sha(json.dumps(spec, sort_keys=True, separators=(",", ":")).encode())
    write(PHASE / "intent-body.json", spec)
    request = {
        "schema": "quoridor.research.phase-admission.v1",
        "owner": spec["owner"],
        "limits": limits,
        "spec_sha256": spec["intent_sha256"],
        "support_sha256": support["sha256"],
        "approved_plan": approved,
        "ready": False,
    }
    write(PHASE / "admission-request.json", request)
    print(
        json.dumps(
            {
                "status": "MATERIALIZED_NOT_ADMITTED_NOT_SUBMITTED",
                "intent_body": ref(PHASE / "intent-body.json"),
                "admission_request": ref(PHASE / "admission-request.json"),
                "launch_unix_ms": args.launch_unix_ms,
                "cost_calls": 0,
            }
        )
    )
else:
    templates = HERE / "preparation"
    lc.require(not templates.exists(), "immutable stopped preparation")
    templates.mkdir()
    for name, value in [
        ("campaign.template.json", campaign),
        ("measurement-plan.template.json", measurement),
        ("Experiment.template.json", experiment),
        ("intent.template.json", spec),
    ]:
        write(templates / name, value)
    print(
        json.dumps(
            {
                "status": "PREPARED_NOT_SUBMITTABLE_EPOCH_AND_ROOT_ADMISSION_REQUIRED",
                "launch_epoch": None,
                "cost_calls": 0,
                "STOP": lc.stamp(),
            }
        )
    )
for item in [*callers, proof_ref, approved, tuple_ref, build_ref]:
    lc.read_ref(item, max(lc.CONTROL_BYTES, item["bytes"]))
