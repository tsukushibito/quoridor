"""Collect original phase1 and assemble the existing saved-only arena packet."""

import importlib.util
import json
import os
from pathlib import Path
import time

MAIN = Path("/workspaces/quoridor")
COST = (
    MAIN
    / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1/cost-qualification-v1"
)
PHASE = COST / "phase1-entry-v1"
OUT = PHASE / "collection-v1"
loader = importlib.util.spec_from_file_location("lc", MAIN / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def document(path):
    return lc.document(ref(path))


def control(value):
    return {"path": value["path"], "sha256": value["sha256"]}


spec = document(PHASE / "intent.json")
manifest = document(PHASE / "operation-v1/manifest.json")
experiment = lc.document(spec["experiment"])
lc.require(
    manifest["status"] == "PASS"
    and manifest["cleanup_complete"] is True
    and manifest["primary"] is None
    and manifest["secondary"] == manifest["remaining"] == []
    and not (PHASE / "operation-v1/INCOMPLETE").exists(),
    "original authoritative phase1 completion",
)
lc.physical_and_quiet(spec)
with lc.lease():
    refs = [
        *experiment["inputs"],
        *spec["caller_sources"],
        experiment["config"],
        experiment["schedule"],
        spec["approved_plan"],
        spec["support"],
        spec["admission"],
        ref(PHASE / "intent.json"),
        ref(PHASE / "runtime-v1/config.json"),
        ref(PHASE / "runtime-v1/result.json"),
        ref(PHASE / "operation-v1/manifest.json"),
    ]
    refs = list({value["path"]: value for value in refs}.values())
    for value in refs:
        lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
    lc.accepted_build(experiment["build_manifest"])
    campaign_ref = ref(COST / "campaign.json")
    lc.require(
        campaign_ref["sha256"]
        == "5d0f15a46caa814ac530a740ee9264f819cd278a72ea60e39c434bd274f55db8",
        "original frozen campaign",
    )
    campaign = lc.document(campaign_ref)
    raw_refs = [
        ref(COST / "phase0-entry-v1/data-v1/measurement-result.json"),
        manifest["data"]["files"][0],
    ]
    results = [lc.document(value) for value in raw_refs]
    lc.require(
        raw_refs[0]["sha256"] == "70f6d4a7c0c186880e64734a113ed0e5d0644c55062560234e2d429819bc52bb"
        and raw_refs[1]["sha256"]
        == "64c8be5b8daf2530e2bca656000d7fc64d4adfe3ffa0641ceb38637a83072263",
        "original two raw subjects",
    )
    configurations = [value["normalized_sha256"] for value in campaign["configurations"]]
    operation_bound, decision_bound = 35800216, 2054040
    for index, result in enumerate(results):
        phase = campaign["phases"][index]
        lc.require(
            result["complete"] is True
            and result["stopped"] is None
            and result["all_workers_joined"] is True
            and result["logical_calls_attempted"] == result["returned_terminal_replies"] == 32
            and result["inflight_after_drain"] == result["games_played"] == 0
            and result["campaign_sha256"] == campaign_ref["sha256"]
            and result["native"] == campaign["native"]
            and result["configuration_sha256"] == configurations
            and result["phase_id"] == phase["id"]
            and result["mode"] == phase["mode"]
            and len(result["items"]) == len(phase["workload"]) == 16
            and result["backend_work"]["failed_rows"] == 0
            and result["backend_work"]["physical_rows"] == 32,
            "saved complete original phase census",
        )
        for item, expected in zip(result["items"], phase["workload"], strict=True):
            receipt = item["receipt"]
            counters = receipt["counters"]
            lc.require(
                item["id"] == expected["id"]
                and item["configuration"] == expected["configuration"]
                and item["parent"]["prefix"] == expected["prefix"]
                and item["stage"] == expected["stage"]
                and item["warmup_logical_calls"] == expected["warmup_logical_calls"]
                and item["error"] is None
                and receipt["engine_error"] is None
                and receipt["failure"] is None
                and receipt["accepted"] is True
                and counters["authority_legal"] is True
                and counters["terminal_request_error"] is None
                and counters["inflight_after_drain"] == 0
                and counters["nn_requests_attempted"]
                == counters["inference_callback_results"]
                == counters["nn_valid_replies_returned"]
                == expected["max_logical_calls"]
                and len(counters["measurement_operations_ns"]) == expected["max_logical_calls"],
                "ordered terminal receipt and counters",
            )
            if index == 1:
                lc.require(
                    counters["cost_qualification_usable_after_drain"] is True
                    and counters["measurement_mode"] == "qualified-timed"
                    and max(counters["measurement_operations_ns"]) <= operation_bound
                    and counters["decision_and_receipt_cost_ns"] <= decision_bound,
                    "each timed receipt satisfies original frozen bounds",
                )
    peaks = [
        {
            "operation_peak_ns": max(
                ns
                for item in result["items"]
                for ns in item["receipt"]["counters"]["measurement_operations_ns"]
            ),
            "decision_peak_ns": max(
                item["receipt"]["counters"]["decision_and_receipt_cost_ns"]
                for item in result["items"]
            ),
        }
        for result in results
    ]
    lc.require(
        peaks[0]["operation_peak_ns"] * 4 + 2000000 == operation_bound
        and peaks[0]["decision_peak_ns"] * 4 + 2000000 == decision_bound
        and campaign["qualification_started_unix_ms"] == 1791837339836
        and campaign["valid_until_unix_ms"] == 1791923739836
        and time.time_ns() // 1000000 < campaign["valid_until_unix_ms"],
        "unchanged original formula and live window",
    )
    evidence = document(PHASE / "CostEvidence.json")
    evidence.update(
        timed_logical_calls=32,
        attempted_logical_calls=64,
        returned_terminal_replies=64,
        results=[control(value) for value in raw_refs],
    )
    lc.new_json(OUT / "CostEvidence.json", evidence)
    packet = document(PHASE / "QualificationPacket.json")
    packet.update(scope="timed-arena", evidence=control(ref(OUT / "CostEvidence.json")))
    lc.new_json(OUT / "QualificationPacket.json", packet)
    check = manifest["checks"][0]
    guardian = check["guardian_return"]
    for key in ["full_log", "persisted_process_receipt"]:
        lc.read_ref(check[key], max(lc.CONTROL_BYTES, check[key]["bytes"]))
    lc.require(
        check["status"] == "PASS"
        and check["capture_complete"] is True
        and guardian["exit_code"] == 0
        and guardian["direct_child_reaped"] is True
        and guardian["cleanup_complete"] is True
        and guardian["remaining"] == []
        and guardian["log_bytes_seen"]
        == guardian["log_bytes_retained"]
        == check["full_log"]["bytes"],
        "full returned native capture and directwait",
    )
    origin = manifest["originating_job"]
    identities = [origin["supervisor"], origin["child"], guardian["child"]]
    after = []
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    for identity in identities:
        path = Path(f"/proc/{identity['pid']}/stat")
        ticks = None
        if path.exists():
            raw = path.read_text()
            ticks = raw[raw.rindex(")") + 2 :].split()[19]
        same = boot == identity["boot_id"] and ticks == identity["start_ticks"]
        lc.require(not same, "original exact process identity stopped")
        after.append(
            {"original": identity, "current_ticks": ticks, "current_boot": boot, "same": same}
        )
    for value in refs:
        lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
    lc.new_json(
        OUT / "saved-data-collection.json",
        {
            "manifest": ref(PHASE / "operation-v1/manifest.json"),
            "raw_results": raw_refs,
            "evidence": ref(OUT / "CostEvidence.json"),
            "packet": ref(OUT / "QualificationPacket.json"),
            "peaks": peaks,
            "bounds": [operation_bound, decision_bound],
            "requests_total": 64,
            "warm_measurement_timed": [16, 16, 32],
            "extra_inference_calls": 0,
            "current_FileRefs_before_after_MATCH": refs,
            "original_identities_after": after,
            "returned_guardian": guardian,
            "persisted_receipt": lc.document(check["persisted_process_receipt"]),
            "full_native_capture": check["full_log"],
            "controller_result": manifest["outer_job_result"],
            "phase0_lifecycle": "FAILED original immutable; native32 component accepted separately",
            "final_packet_scope": "Existing timed-arena CostEvidence/QualificationPacket, saved-only assembly; later native selection remains owning gate",
            "remaining_conditions": [
                "Root trusted plan and final cost-packet correspondence plus phase-specific admission",
                "Honest current model/head qualification correspondence, only necessary bounded checks",
                "Fresh nonconflicting physical/current caller-model-library-image and lifetime guards",
            ],
            "games_diagnostics_heads_entered": 0,
            "reader_STOP": lc.stamp(),
            "collector_pid": os.getpid(),
        },
    )
print(json.dumps({"saved_only_collection": "complete", "lease_released": lc.stamp()}))
