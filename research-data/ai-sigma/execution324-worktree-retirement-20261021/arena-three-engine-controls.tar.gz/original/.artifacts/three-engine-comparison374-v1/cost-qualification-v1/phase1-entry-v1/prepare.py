"""Bind saved phase0 data to the existing timed-validation packet and phase1."""

import copy
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
COST = OWN / "cost-qualification-v1"
PHASE = COST / "phase1-entry-v1"
PRIOR = COST / "phase0-entry-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def control(value):
    return {"path": value["path"], "sha256": value["sha256"]}


acceptance_ref = ref(
    MAIN / "research-data/ai-sigma/three-engine-comparison374/phase0-measurement-acceptance-v1.json"
)
lc.require(
    (acceptance_ref["sha256"], acceptance_ref["bytes"], acceptance_ref["mode"])
    == ("2e77c680127a0f11c616dc35e0adbc9b7141dd7a15c19c4bd3d1dd3206aa1177", 2933, "0644"),
    "actual component acceptance",
)
acceptance = lc.document(acceptance_ref)
lc.document(ref(PHASE / "preprice.json"))
result_ref = acceptance["measurement_result"]
result = lc.document(result_ref)
manifest_ref = acceptance["original_manifest"]
manifest = lc.document(manifest_ref)
lc.require(
    manifest["status"] == "FAILED" and manifest["data"]["files"] == [result_ref],
    "original FAILED remains immutable, saved measurement subject exact",
)
prior_spec = lc.document(manifest["intent"])
prior_experiment = lc.document(prior_spec["experiment"])
campaign_ref = ref(COST / "campaign.json")
lc.require(
    campaign_ref["sha256"] == "5d0f15a46caa814ac530a740ee9264f819cd278a72ea60e39c434bd274f55db8"
    and campaign_ref["bytes"] == 12777,
    "one original frozen campaign",
)
campaign = lc.document(campaign_ref)
lc.require(
    campaign["qualification_started_unix_ms"] == 1791837339836
    and campaign["valid_until_unix_ms"]
    == campaign["native"]["valid_until_unix_ms"]
    == 1791923739836
    and time.time_ns() // 1000000 < campaign["valid_until_unix_ms"],
    "same live original window",
)
lc.require(
    result["native"] == campaign["native"]
    and result["campaign_sha256"] == campaign_ref["sha256"]
    and result["complete"] is True
    and result["logical_calls_attempted"] == result["returned_terminal_replies"] == 32,
    "exact accepted native32 data",
)
operation_peak = max(
    ns
    for item in result["items"]
    for ns in item["receipt"]["counters"]["measurement_operations_ns"]
)
decision_peak = max(
    item["receipt"]["counters"]["decision_and_receipt_cost_ns"]
    for item in result["items"]
    if isinstance(item["receipt"]["action"], int)
)
lc.require(
    operation_peak == acceptance["observed_operation_peak_ns"] == 8450054
    and decision_peak == acceptance["observed_decision_peak_ns"] == 13510,
    "original observed whole sample peaks",
)
operation_bound, decision_bound = operation_peak * 4 + 2000000, decision_peak * 4 + 2000000
lc.require(
    operation_bound == acceptance["derived_untimed_operation_upper_ns"] == 35800216
    and decision_bound == acceptance["derived_untimed_decision_upper_ns"] == 2054040,
    "fixed4x+2ms formula without retuning",
)
evidence = {
    "schema": "quoridor-sigma-cost-evidence-v1",
    "complete": True,
    "configuration_sha256": result["configuration_sha256"],
    "native": campaign["native"],
    "whole_operation_upper_ns": operation_bound,
    "decision_communication_upper_ns": decision_bound,
    "measurement_logical_calls": 16,
    "timed_logical_calls": 0,
    "warmup_logical_calls": 16,
    "attempted_logical_calls": 32,
    "returned_terminal_replies": 32,
    "errors": 0,
    "inflight_after_drain": 0,
    "workload": control(campaign_ref),
    "results": [control(result_ref)],
}
lc.new_json(PHASE / "CostEvidence.json", evidence)
evidence_ref = ref(PHASE / "CostEvidence.json")
packet = {
    "schema": "quoridor-sigma-cost-qualification-v1",
    "scope": "timed-validation",
    "configurations": campaign["configurations"],
    "native": campaign["native"],
    "evidence": control(evidence_ref),
    "whole_operation_upper_ns": operation_bound,
    "decision_communication_upper_ns": decision_bound,
}
lc.new_json(PHASE / "QualificationPacket.json", packet)
packet_ref = ref(PHASE / "QualificationPacket.json")
phase = campaign["phases"][1]
lc.require(
    phase["mode"] == "qualified-timed" and phase["max_logical_calls"] == 32,
    "original genuinely unfinished timed32",
)
measurement = {
    "schema": "quoridor-sigma-receipt-measurement-v1",
    "phase_id": phase["id"],
    "campaign": control(campaign_ref),
    "configurations": campaign["configurations"],
    "native": campaign["native"],
    "output": str(PHASE / "data-v1"),
    "mode": "qualified-timed",
    "max_logical_calls": 32,
    "prior_logical_calls": 32,
    "prior_results": [control(result_ref)],
    "workload": phase["workload"],
}
lc.new_json(PHASE / "measurement-plan.json", measurement)
measurement_ref = ref(PHASE / "measurement-plan.json")
experiment = copy.deepcopy(prior_experiment)
experiment.update(config=measurement_ref, numerical_qualification=packet_ref, batch=1)
inputs = [*experiment["inputs"], evidence_ref, packet_ref, result_ref, manifest_ref, acceptance_ref]
experiment["inputs"] = list({r["path"]: r for r in inputs}.values())
lc.new_json(PHASE / "Experiment.json", experiment)
experiment_ref = ref(PHASE / "Experiment.json")
# Standard current public-entry selection, independent of historical BUILD tools.
lc.require(
    str(Path(sys.prefix).resolve()) == os.environ["QUORIDOR_PROJECT_ENV"],
    "actual qualified common prefix",
)
current_python = {
    "sys_executable": sys.executable,
    "resolved_binary": ref(Path(sys.executable).resolve()),
    "prefix": sys.prefix,
    "public_entry": ref(MAIN / "scripts/dev/project-env.sh"),
}
lc.new_json(PHASE / "current-Python.json", current_python)
spec = {
    k: copy.deepcopy(v) for k, v in prior_spec.items() if k not in {"admission", "intent_sha256"}
}
spec.update(
    output=str(PHASE / "operation-v1"),
    experiment=experiment_ref,
    data_root=str(PHASE / "data-v1"),
    TMP=str(COST / "TMP-phase1-v1"),
    data=[
        {
            "name": "measurement",
            "path": str(PHASE / "data-v1/measurement-result.json"),
            "limit_B": lc.CONTROL_BYTES,
        }
    ],
)
spec["env"]["TMPDIR"] = spec["TMP"]
spec["argv"] = [
    a.replace("@EXPERIMENT@", experiment_ref["path"]).replace(
        "@EXPERIMENT_SHA256@", experiment_ref["sha256"]
    )
    for a in experiment["argv"]
]
lc.caller_source_refs(spec, experiment)
for item in spec["caller_sources"]:
    lc.read_ref(item, max(lc.CONTROL_BYTES, item["bytes"]))
spec["intent_sha256"] = lc.sha(json.dumps(spec, sort_keys=True, separators=(",", ":")).encode())
lc.new_json(PHASE / "intent-body.json", spec)
lc.new_json(
    PHASE / "admission-request.json",
    {
        "schema": "quoridor.research.phase-admission.v1",
        "owner": spec["owner"],
        "limits": spec["limits"],
        "spec_sha256": spec["intent_sha256"],
        "support_sha256": spec["support"]["sha256"],
        "approved_plan": spec["approved_plan"],
        "ready": False,
    },
)
for item in [manifest_ref, result_ref, campaign_ref, acceptance_ref, *spec["caller_sources"]]:
    lc.read_ref(item, max(lc.CONTROL_BYTES, item["bytes"]))
print(
    json.dumps(
        {
            "status": "PREPARED_TIMED_VALIDATION_METADATA_NOT_ADMITTED_NOT_SUBMITTED",
            "evidence": evidence_ref,
            "packet": packet_ref,
            "Experiment": experiment_ref,
            "intent_body": ref(PHASE / "intent-body.json"),
            "current_python": current_python,
            "actual_native_validation_pending_before_inference": True,
            "requests_entered": 0,
            "STOP": lc.stamp(),
        }
    )
)
