"""Collect one original completed pair's saved records, without replay or finalization."""

import argparse
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import resource

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
HERE = OWN / "primary-controls-two-ai-v1"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--batch", type=int, required=True)
parser.add_argument("--job-id", required=True)
args = parser.parse_args()
PHASE = HERE / f"batch-{args.batch:03d}"
OUT = PHASE / "collection-v1"
loader = importlib.util.spec_from_file_location("lc", MAIN / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def document(path):
    return lc.document(ref(path))


def identity_after(identity):
    path = Path(f"/proc/{identity['pid']}/stat")
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    try:
        ticks = path.read_text().rsplit(")", 1)[1].split()[19]
    except FileNotFoundError:
        return {"identity": identity, "observed": "ABSENT"}
    lc.require(
        boot != identity["boot_id"] or ticks != str(identity["start_ticks"]),
        "original selected process still exists; no stopped claim",
    )
    return {"identity": identity, "observed": "DIFFERENT"}


resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
lc.physical_and_quiet(
    {
        "kind": "run",
        "limits": {
            "family_B": 512 * 1024**2,
            "host_reserve_B": 4 * 1024**3,
            "worker_cpu": 1,
            "guardian_cpu": 6,
        },
    }
)
with lc.lease():
    spec = document(PHASE / "intent.json")
    experiment = lc.document(spec["experiment"])
    plan = lc.document(spec["approved_plan"])
    batch = plan["batches"][args.batch]
    lc.require(
        args.batch >= 2 and experiment["batch"] == args.batch and min(batch["slots"]) >= 4,
        "actual original wholly unentered pair scope",
    )
    manifest_ref = ref(PHASE / "operation-v1/manifest.json")
    manifest = lc.document(manifest_ref)
    lc.require(
        manifest["status"] == "PASS"
        and manifest["data"]["status"] == "PASS"
        and not (PHASE / "operation-v1/INCOMPLETE").exists(),
        "genuine original once-finalized manifest and owning data validation",
    )
    job = document(PHASE / "runtime-v1/result.json")
    state = document(PHASE / "runtime-v1/state.json")
    disk = document(PHASE / "operation-v1/run.process.json")
    finalize = document(OUT / "finalize-return.json")
    lc.require(job["job_id"] == state["job_id"] == args.job_id, "actual original completion")
    native = manifest["checks"][0]
    guardian = native["guardian_return"]
    lc.require(
        native["capture_complete"]
        and guardian["exit_code"] == 0
        and guardian["cleanup_complete"]
        and guardian["direct_child_reaped"]
        and not guardian["remaining"],
        "full native capture and settled returned guardian",
    )
    lc.read_ref(native["full_log"], spec["limits"]["log_B"])
    after = [
        identity_after(identity)
        for identity in (
            state["supervisor"],
            state["child"],
            disk["child"],
            finalize["guardian_return"]["child"],
        )
    ]
    refs = document(PHASE / "preparation-receipt.json")["current_refs_before_after_MATCH"]
    for value in refs:
        lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
    result_ref = ref(Path(spec["data_root"]) / "result.json")
    result = lc.document(result_ref)
    archive_ref = result["archive"]["compressed"]
    lc.read_ref(archive_ref, spec["data"][0]["limit_B"])
    raw_hash = hashlib.sha256()
    raw_bytes = 0
    outcomes = []
    observations = []
    for_global_slots = batch["slots"]
    with gzip.open(archive_ref["path"], "rb") as stream:
        for line in stream:
            lc.require(len(line) <= 630785, "complete original outcome line bound")
            raw_hash.update(line)
            raw_bytes += len(line)
            outcome = json.loads(line)
            local = outcome["game"]
            lc.require(local < len(for_global_slots), "original local/global slot mapping")
            outcomes.append(
                {
                    "global_slot": for_global_slots[local],
                    **{
                        k: outcome[k]
                        for k in (
                            "game",
                            "candidate_color",
                            "started",
                            "status",
                            "winner",
                            "plies",
                            "reason",
                            "failure",
                            "nn_calls",
                        )
                    },
                    "observations": len(outcome["observations"]),
                }
            )
            observations.extend(outcome["observations"])
    lc.require(
        raw_hash.hexdigest() == result["archive"]["raw_sha256"]
        and raw_bytes == result["archive"]["raw_bytes"]
        and len(outcomes) == result["outcome_count"] == 2
        and {r["global_slot"] for r in outcomes} == set(batch["slots"]),
        "complete original journal census and raw digest",
    )
    tmp = Path(spec["TMP"])
    lc.require(tmp == PHASE / "TMP-v1", "literal owned TMP")
    lc.require(tmp.is_dir() and not tmp.is_symlink() and not list(tmp.iterdir()), "owned TMP empty")
    tmp.rmdir()
    for value in refs:
        lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
    clocks = [o["counters"] for o in observations]
    lc.new_json(
        OUT / "collection-result.json",
        {
            "status": "STOPPED_ORIGINAL_PAIR_PASS_SAVED_CENSUS",
            "manifest": manifest_ref,
            "result": result_ref,
            "archive": archive_ref,
            "original_job_result": ref(PHASE / "runtime-v1/result.json"),
            "submission": ref(PHASE / "submission.json"),
            "native_full_capture": native["full_log"],
            "returned_native_guardian": guardian,
            "persisted_native_receipt": disk,
            "returned_finalizer_guardian": finalize["guardian_return"],
            "persisted_finalizer_receipt": document(OUT / "finalize.process.json"),
            "outer_result": job,
            "controller_seconds_once": job["wall_seconds"],
            "nested_native_seconds_not_added": disk["wall_seconds"],
            "census": outcomes,
            "owning_native_arena_summary": result["report"]["arena_summary"],
            "scope": "One frozen family/matched-colour pair only; no global strength/Elo/default/model/head qualification claim. Existing owning publication validated these records; saved-only collection adds no engine/rules/model replay.",
            "saved_clock_owner_facts": {
                "observations": len(observations),
                "accepted": sum(o["accepted"] for o in observations),
                "main_core_counts": dict(Counter(c.get("authority_core") for c in clocks)),
                "main_tid_counts": dict(Counter(c.get("authority_tid") for c in clocks)),
                "AI_core_counts": dict(Counter(c.get("AI_worker_core") for c in clocks)),
                "AI_tid_counts": dict(Counter(c.get("AI_worker_tid") for c in clocks)),
                "matching_terminal": sum(
                    c.get("matching_terminal_collected") is True for c in clocks
                ),
                "inflight_after_drain_nonzero": sum(
                    c.get("inflight_after_drain") != 0 for c in clocks
                ),
                "accepted_receipt_at_or_after_deadline": sum(
                    o["accepted"]
                    and c.get("authority_receipt_ns", o["returned_ns"]) >= o["deadline_ns"]
                    for o, c in zip(observations, clocks, strict=True)
                ),
                "Sigma_ORT_requests": result["report"]["nn_calls"],
                "NNUE_physical_head_calls": "UNKNOWN; existing counters' physical_nn_calls null is preserved, not re-labelled zero",
            },
            "after_selected_identities": after,
            "current_source_model_library_image_input_caller_refs_before_after_MATCH": refs,
            "actual_source_model_library_image_input_caller_reader_STOP": lc.stamp(),
            "TMP_cleanup": "Literal owned empty directory removed after original exact process absence",
            "owned_readers_children_jobs_TMP_remaining": [],
            "new_native_model_head_Search_game_calls_by_collection": 0,
            "storage_budget_for_collection": None,
            "original0_1_2_and_partial3": "FAILED/raw/validatedUNKNOWN unchanged; NEVER replay/refill",
        },
    )
print(
    json.dumps({"collection": ref(OUT / "collection-result.json"), "canonical_release": lc.stamp()})
)
