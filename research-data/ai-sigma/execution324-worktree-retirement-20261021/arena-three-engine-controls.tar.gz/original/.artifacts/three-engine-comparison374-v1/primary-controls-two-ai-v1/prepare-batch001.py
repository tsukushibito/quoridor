"""Prepare the still-unentered original slots 2/3; never submit a game."""

import copy
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
HERE = OWN / "primary-controls-two-ai-v1"
PHASE = HERE / "batch-001"
loader = importlib.util.spec_from_file_location("lc", MAIN / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def exact(path, digest, size, mode="0644"):
    value = ref(path)
    lc.require(
        (value["sha256"], value["bytes"], value["mode"]) == (digest, size, mode),
        "issued current FileRef: " + str(path),
    )
    return value


def prepare():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    lc.require(not PHASE.exists(), "exclusive original batch001 preparation")
    lc.require(
        sys.executable == "/home/vscode/.cache/inference/envs/quoridor-training/bin/python"
        and str(Path(sys.prefix).resolve()) == os.environ["QUORIDOR_PROJECT_ENV"],
        "current qualified common-entry interpreter",
    )
    original_affinity = os.sched_getaffinity(0)
    lc.physical_and_quiet(
        {
            "kind": "run",
            "limits": {
                "family_B": 512 * 1024**2,
                "host_reserve_B": 4 * 1024**3,
                "worker_cpu": 1,
                "guardian_cpu": 6,
            },
        }
    )
    with lc.lease():
        plan_ref = exact(
            MAIN / "research-data/ai-sigma/three-engine-comparison374/approved-plan-v4.json",
            "e0f6f2cdd32211ae64a7fb5eebfdb4f4be861eeaba103b2fa05ce9438bc24958",
            154153,
        )
        plan = lc.document(plan_ref)
        support_ref = exact(
            MAIN
            / "research-data/ai-sigma/three-engine-comparison374/support-two-ai-runtime-v1.json",
            "c74ef29d4e1ba00a2270ddb72b6ba673885d6aceb8378851c1abf1eadebeb7ab",
            2447,
        )
        support = lc.document(support_ref)
        build_ref = exact(
            MAIN
            / ".artifacts/research-team/integration324/two-ai-composition-v1/build-v4/operation-v1/manifest.json",
            "85d6019b1b1760b92ca6033630cfb235da004a2e0d0e61ad12713808795846de",
            44783,
        )
        build = lc.accepted_build(build_ref)
        artifact = build["artifact"]
        lc.require(
            artifact == support["artifact"] and build_ref == support["build_manifest"],
            "same accepted compatible image and actual runtime support",
        )
        batch = plan["batches"][1]
        config_ref = batch["config"]
        lc.require(
            config_ref
            == exact(
                config_ref["path"],
                "1b273f12821d0973fba5744a871aa913d50292170ad0612bb3ac4aad2fe97fb9",
                2993,
            ),
            "actual first unentered config",
        )
        config = lc.document(config_ref)
        lc.require(
            batch["slots"] == [2, 3]
            and batch["batch"] == 1
            and [engine["kind"] for engine in config["engines"]] == ["mcts", "nnue"]
            and config["cpu_cores"] == [1, 4]
            and config["management_cpu_core"] == 6
            and config["inference_cpu_core"] is None
            and config["games"] == 2
            and config["max_output_bytes"] == 16 * 1024**2
            and not os.path.lexists(config["output"]),
            "original unentered Sigma-NNUE matched pair; old batch0 never selected",
        )
        old_scope_ref = ref(OWN / "primary-controls-v3/batch-000/original-evidence-scopes.json")
        old_scope = lc.document(old_scope_ref)
        tuple_ref = next(
            r for r in old_scope["refs"] if r["path"].endswith("stopped-tuple-binding.json")
        )
        tuple_record = lc.document(tuple_ref)
        libraries = [
            {
                "file": value,
                "version": (
                    tuple_record["actual_loaded_CAPI_version"]
                    if value == tuple_record["actual_loaded_ORT_library"]
                    else "UNKNOWN; exact ELF identity, no separately observed semantic version"
                ),
            }
            for value in tuple_record["loaded_ELF_subjects"]
            if value["path"] != str(Path(sys.executable).resolve())
        ]
        callers = [
            ref(MAIN / name)
            for name in (
                "scripts/dev/research-lifecycle.py",
                "scripts/dev/research-job.py",
                "python/quoridor_training/cycle_process.py",
                "python/quoridor_training/snapshot.py",
            )
        ]
        python_refs = [
            ref(MAIN / "scripts/dev/project-env.sh"),
            ref(Path(sys.executable).resolve()),
            ref(Path(sys.prefix) / "pyvenv.cfg"),
        ]
        before_after = [
            plan_ref,
            support_ref,
            build_ref,
            artifact,
            config_ref,
            plan["schedule"],
            *plan["inputs"],
            *callers,
            *python_refs,
            *[library["file"] for library in libraries],
            *[
                value
                for model in plan["models"]
                for value in (model["descriptor"], model["weights"])
            ],
            old_scope_ref,
            *old_scope["refs"],
        ]
        before_after = list({r["path"]: r for r in before_after}.values())
        for value in before_after:
            lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
        experiment = {
            "schema": lc.EXPERIMENT_SCHEMA,
            "phase": "arena",
            "build_manifest": build_ref,
            "config": config_ref,
            "inputs": plan["inputs"],
            "models": plan["models"],
            "dynamic_libraries": libraries,
            "schedule": plan["schedule"],
            "numerical_qualification": None,
            "canonical_plan_sha256": plan_ref["sha256"],
            "rules": plan["rules"],
            "distance_units": plan["distance_units"],
            "value_perspective": plan["value_perspective"],
            "planned_slots": plan["planned_slots"],
            "batch": 1,
            "argv": [
                artifact["path"],
                "arena",
                "--experiment",
                "@EXPERIMENT@",
                "--experiment-sha256",
                "@EXPERIMENT_SHA256@",
            ],
        }
        PHASE.mkdir()
        lc.new_json(
            PHASE / "original-evidence-scopes.json",
            {
                "original_scopes": old_scope_ref,
                "refs": old_scope["refs"],
                "scope": "Current loader correspondence only; original numerical/model receipts remain original subjects.",
                "Sigma": "Original unchanged model/codec/history/math evidence; no current inference prediction, calibration, old Q or expiry prerequisite.",
                "NNUE": "Unchanged46ec descriptor/046fe weights/96a5 evaluator and retained math/model/history evidence, including accepted original BEST43-v-D358. Original completed-depth4 outcome is not a current head, new clock-cohort or strength result.",
                "ownership": "Accepted two-AI boundary review and current real NN0 software scope; no real model/head session performed by preparation.",
                "library_version": "Previously observed CAPI1.30.0 reused only with byte-identical current library. Current native worker loading remains future; no extra library/backend session.",
                "new_head_model_game_calls": 0,
                "original_receipts_modified": False,
            },
        )
        numerical = lc.numerical_fields(experiment, build)
        numerical.update(
            correspondence_only=True,
            new_model_or_head_calls=0,
            original_evidence=ref(PHASE / "original-evidence-scopes.json"),
            scope="PASS of current loader/config/plan/model identity correspondence; original proper-scoped numerical evidence, no new forward/head/strength result",
        )
        lc.new_json(PHASE / "numerical-correspondence.json", numerical)
        experiment["numerical_qualification"] = ref(PHASE / "numerical-correspondence.json")
        lc.new_json(PHASE / "Experiment.json", experiment)
        old_spec = lc.document(ref(OWN / "primary-controls-v3/batch-000/intent-body.json"))
        spec = {
            key: copy.deepcopy(old_spec[key])
            for key in ("schema", "kind", "owner", "writer", "cwd")
        }
        spec.update(
            output=str(PHASE / "operation-v1"),
            env={
                **{
                    k: os.environ[k]
                    for k in (
                        "PATH",
                        "PYTHONPATH",
                        "QUORIDOR_PROJECT_ROOT",
                        "QUORIDOR_PROJECT_ENV",
                        "UV_PROJECT_ENVIRONMENT",
                    )
                },
                "TMPDIR": str(PHASE / "TMP-v1"),
                "PYTHONDONTWRITEBYTECODE": "1",
                "CUDA_VISIBLE_DEVICES": "",
                "OMP_NUM_THREADS": "1",
                "OPENBLAS_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1",
                "ORT_DISABLE_TELEMETRY": "1",
            },
            limits={
                "family_B": 3 * 1024**3,
                "controller_B": 64 * 1024**2,
                "host_reserve_B": 4 * 1024**3,
                "owned_B": support["storage"]["large_primary_retained_output_and_controls_B"],
                "free_B": None,
                "log_B": 16384,
                "worker_cpu": 1,
                "guardian_cpu": 6,
            },
            support=support_ref,
            approved_plan=plan_ref,
            artifact=artifact,
            experiment=ref(PHASE / "Experiment.json"),
            caller_sources=callers,
            child_cpu_cores=[1, 4, 6],
            data_root=config["output"],
            owned_outputs=[str(HERE), str(OWN / "primary-output-v1")],
            TMP=str(PHASE / "TMP-v1"),
            finalizers=[],
        )
        spec["data"] = [
            {
                "name": "journal",
                "path": str(Path(config["output"]) / "completed.jsonl.gz"),
                "limit_B": 2 * (630784 + 1) + 65536,
            },
            {
                "name": "result",
                "path": str(Path(config["output"]) / "result.json"),
                "limit_B": 65536,
            },
            {
                "name": "native_manifest",
                "path": str(Path(config["output"]) / "manifest.json"),
                "limit_B": 65536,
            },
        ]
        spec["argv"] = [
            arg.replace("@EXPERIMENT@", spec["experiment"]["path"]).replace(
                "@EXPERIMENT_SHA256@", spec["experiment"]["sha256"]
            )
            for arg in experiment["argv"]
        ]
        spec["intent_sha256"] = lc.canonical_sha(spec)
        lc.experiment_phase_check(experiment)
        lc.caller_source_refs(spec, experiment)
        lc.arena_plan_check(experiment, plan)
        lc.numerical_check(experiment, build)
        lc.charged_roots(spec)
        lc.arena_cpu_cores(spec)
        os.sched_setaffinity(0, original_affinity)
        lc.physical_and_quiet(spec)
        lc.new_json(PHASE / "intent-body.json", spec)
        lc.new_json(
            PHASE / "admission-request.json",
            {
                "schema": "quoridor.research.phase-admission.v1",
                "owner": spec["owner"],
                "limits": spec["limits"],
                "spec_sha256": spec["intent_sha256"],
                "support_sha256": support_ref["sha256"],
                "approved_plan": plan_ref,
                "ready": False,
            },
        )
        lc.new_json(
            PHASE / "current-Python.json",
            {
                "sys_executable": sys.executable,
                "resolved_binary": python_refs[1],
                "prefix": sys.prefix,
                "public_entry": python_refs[0],
                "pyvenv": python_refs[2],
            },
        )
        for value in before_after:
            lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
        lc.new_json(
            PHASE / "preparation-receipt.json",
            {
                "status": "STOPPED_NORMAL_BATCH001_PREPARED_NOT_ADMITTED_OR_SUBMITTED",
                "intent": ref(PHASE / "intent-body.json"),
                "request": ref(PHASE / "admission-request.json"),
                "Experiment": spec["experiment"],
                "current_numerical_correspondence": experiment["numerical_qualification"],
                "slots": [2, 3],
                "original_entered0_1": "FAILED/raw/validatedUNKNOWN; NEVER replay",
                "current_refs_before_after_MATCH": before_after,
                "pre_admission_checks": "Existing accepted_build/phase/caller/plan/numerical/CPU roles and fresh physical/namedquiet/NB/env checked; actual ready admission/owning Limits/experiment_check remain real launch inputs",
                "job_and_collector_python": sys.executable,
                "storage_budget_for_preparation": None,
                "scientific_large_output_whole_B": spec["limits"]["owned_B"],
                "native_model_head_Search_game_calls": 0,
                "actual_metadata_reader_writer_STOP": lc.stamp(),
                "owned_readers_children_jobs_TMP_remaining": [],
            },
        )
    os.sched_setaffinity(0, original_affinity)
    print(
        json.dumps(
            {
                "prepared": str(PHASE),
                "canonical_release": lc.stamp(),
                "spec_sha256": spec["intent_sha256"],
            }
        )
    )


prepare()
