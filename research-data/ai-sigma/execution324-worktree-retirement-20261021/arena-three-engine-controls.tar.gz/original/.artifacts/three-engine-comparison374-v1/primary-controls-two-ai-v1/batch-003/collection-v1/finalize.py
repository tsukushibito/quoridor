"""Once-finalize the original completed batch003 through the existing guardian."""

import importlib.util
import json
from pathlib import Path
import resource
import sys

MAIN = Path("/workspaces/quoridor")
PHASE = (
    MAIN
    / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1/primary-controls-two-ai-v1/batch-003"
)
OUT = PHASE / "collection-v1"
loader = importlib.util.spec_from_file_location("lc", MAIN / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
result_ref = ref(PHASE / "runtime-v1/result.json")
lc.require(
    result_ref["sha256"] == "be148735cafe9a7749f8bd1aceb51f2b7cb950a81789dbceccb89c883f5f1d35"
    and lc.document(result_ref)["job_id"] == "1c3d2a55-e513-4610-a130-f9ccacbfe36e",
    "actual original completion result",
)
lc.require(not (PHASE / "operation-v1/manifest.json").exists(), "once FINALIZE only")
spec = lc.document(ref(PHASE / "intent.json"))
current_python = lc.document(ref(PHASE / "current-Python.json"))
lc.require(sys.executable == current_python["sys_executable"], "same common-entry interpreter")
lc.physical_and_quiet(spec)
capture = lc.Capture(OUT / "finalize.full.log", 1024**2)
guardian = None
primary = None
secondary = []
try:
    guardian = lc.process.execute(
        [
            sys.executable,
            "-B",
            str(MAIN / "scripts/dev/research-lifecycle.py"),
            "finalize",
            "--operation",
            str(PHASE / "operation-v1"),
            "--job-result",
            result_ref["path"],
            "--sha256",
            result_ref["sha256"],
        ],
        OUT / "finalize.log",
        None,
        resources=lc.Limits(spec),
        cpu_cores=[1, 4, 6],
        cwd=MAIN,
        env=spec["env"],
        output_sink=capture,
    )
except BaseException as error:
    primary = lc.error_fact(error)
finally:
    try:
        capture.close()
    except BaseException as error:
        secondary.append(lc.error_fact(error))
lc.new_json(
    OUT / "finalize-return.json",
    {
        "original_result": result_ref,
        "guardian_return": guardian,
        "primary": primary,
        "secondary": secondary,
        "full_capture": ref(OUT / "finalize.full.log"),
        "same_commonentry_interpreter": sys.executable,
        "child_cpu_cores": [1, 4, 6],
        "returned_at": lc.stamp(),
        "no_native_model_game_replay": True,
    },
)
print(
    json.dumps(
        {
            "manifest_created": (PHASE / "operation-v1/manifest.json").exists(),
            "primary": primary,
            "secondary": secondary,
        }
    )
)
raise SystemExit(0 if guardian is not None and primary is None and not secondary else 1)
