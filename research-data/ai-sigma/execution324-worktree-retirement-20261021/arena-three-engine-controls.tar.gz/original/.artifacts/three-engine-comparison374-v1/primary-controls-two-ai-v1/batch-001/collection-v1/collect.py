"""Collect saved original batch001 failure; no native replay or acceptance override."""

from collections import Counter
import importlib.util
import json
import os
from pathlib import Path
import resource

MAIN = Path("/workspaces/quoridor")
OWN = MAIN / ".worktree/arena-evaluation/.artifacts/three-engine-comparison374-v1"
PHASE = OWN / "primary-controls-two-ai-v1/batch-001"
OUT = PHASE / "collection-v1"
loader = importlib.util.spec_from_file_location("lc", MAIN / "scripts/dev/research-lifecycle.py")
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def document(path):
    return lc.document(ref(path))


def identity_after(identity):
    path = Path(f"/proc/{identity['pid']}/stat")
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    try:
        ticks = path.read_text().rsplit(")", 1)[1].split()[19]
    except FileNotFoundError:
        return {"identity": identity, "observed": "ABSENT"}
    same = boot == identity["boot_id"] and ticks == str(identity["start_ticks"])
    lc.require(not same, "original selected process still present; no stopped assertion")
    return {"identity": identity, "observed": "DIFFERENT"}


resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
lc.physical_and_quiet(
    {
        "kind": "run",
        "limits": {
            "family_B": 512 * 1024**2,
            "host_reserve_B": 4 * 1024**3,
            "worker_cpu": 1,
            "guardian_cpu": 6,
        },
    }
)
with lc.lease():
    manifest_ref = ref(PHASE / "operation-v1/manifest.json")
    manifest = lc.document(manifest_ref)
    lc.require(
        manifest["status"] == "FAILED" and not (PHASE / "operation-v1/INCOMPLETE").exists(),
        "original normal onceFINALIZED failure",
    )
    spec = document(PHASE / "intent.json")
    job = document(PHASE / "runtime-v1/result.json")
    state = document(PHASE / "runtime-v1/state.json")
    disk = document(PHASE / "operation-v1/run.process.json")
    finalize = document(OUT / "finalize-return.json")
    lc.require(
        job["job_id"] == state["job_id"] == "178ab21f-bd50-4043-854d-d66bafb46582",
        "original completion identity",
    )
    lc.require(
        finalize["exit_code"] == 1 and finalize["direct_child_reaped"] and finalize["pipes_closed"],
        "failed owning finalizer directwait",
    )
    after = [
        identity_after(identity)
        for identity in (
            state["supervisor"],
            state["child"],
            disk["child"],
            finalize["child_identity"],
        )
    ]
    before = document(PHASE / "preparation-receipt.json")
    refs = before["current_refs_before_after_MATCH"]
    for value in refs:
        lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
    data = Path(spec["data_root"])
    failure_ref = ref(data / "publication-failure.json")
    failure = lc.document(failure_ref)
    available = failure["available_outcomes"]
    census = [
        {
            "global_slot": 2 + outcome["game"],
            **{
                k: outcome[k]
                for k in (
                    "game",
                    "candidate_color",
                    "started",
                    "status",
                    "winner",
                    "plies",
                    "reason",
                    "failure",
                    "nn_calls",
                )
            },
            "observations": len(outcome["observations"]),
            "validated_status": "UNKNOWN; publication failed, no canonical success",
        }
        for outcome in available
    ]
    observation_sizes = [
        (
            outcome["game"],
            observation["ply"],
            observation["engine_index"],
            len(
                json.dumps(
                    observation, separators=(",", ":"), ensure_ascii=False, allow_nan=False
                ).encode()
            ),
        )
        for outcome in available
        for observation in outcome["observations"]
    ]
    scalar_sizes = [row[3] for row in observation_sizes]
    sizes_by_engine = {
        str(engine): max(row[3] for row in observation_sizes if row[2] == engine)
        for engine in {row[2] for row in observation_sizes}
    }
    tmp = Path(spec["TMP"])
    lc.require(tmp == PHASE / "TMP-v1", "literal owned TMP")
    lc.require(
        tmp.is_dir() and not tmp.is_symlink() and not list(tmp.iterdir()), "exact empty owned TMP"
    )
    tmp.rmdir()
    lc.require(not os.path.lexists(tmp), "actual owned TMP removed after child absence")
    for value in refs:
        lc.read_ref(value, max(lc.CONTROL_BYTES, value["bytes"]))
    files = {
        name: ref(path)
        for name, path in {
            "manifest": PHASE / "operation-v1/manifest.json",
            "candidate": PHASE / "operation-v1/candidate.json",
            "original_result": PHASE / "runtime-v1/result.json",
            "submission": PHASE / "submission.json",
            "outer_tail": PHASE / "runtime-v1/output.log",
            "native_full_log": PHASE / "operation-v1/run.full.log",
            "persisted_native_receipt": PHASE / "operation-v1/run.process.json",
            "publication_failure": data / "publication-failure.json",
            "journal_raw": data / "completed.raw.jsonl",
            "incomplete_archive": data / "completed.jsonl.gz",
            "finalizer_return": OUT / "finalize-return.json",
        }.items()
        if path.exists()
    }
    lc.new_json(
        OUT / "collection-result.json",
        {
            "status": "STOPPED_ORIGINAL_FAILED_NO_REPLAY",
            "refs": files,
            "manifest_status": manifest["status"],
            "primary": manifest["primary"],
            "secondary": manifest["secondary"],
            "inner_cleanup_complete": manifest["cleanup_complete"],
            "inner_process_cleanup_complete": manifest.get("process_cleanup_complete"),
            "returned_guardian": manifest["checks"][0]["guardian_return"],
            "returned_capture_complete": manifest["checks"][0]["capture_complete"],
            "persisted_native_directwait_cleanup_masks": disk,
            "outer_result": job,
            "outer_capture": {
                "seen": job["log_bytes_seen"],
                "retained": job["log_bytes_retained"],
                "complete": job["log_bytes_seen"] == job["log_bytes_retained"],
                "scope": "Outer controller JSON tail; native full164B log retained separately. Tail is not full scientific capture.",
            },
            "controller_seconds_once": job["wall_seconds"],
            "native_nested_seconds_not_added": disk.get("wall_seconds"),
            "saved_available_census": census,
            "counts": {
                "requested": 2,
                "started": sum(outcome["started"] for outcome in available),
                "raw_goals": sum(outcome["status"] == "goal" for outcome in available),
                "canonical_successes": 0,
                "validated_UNKNOWN": 2,
                "saved_nn_calls": sum(outcome["nn_calls"] for outcome in available),
                "complete_pairs": 0,
            },
            "saved_observation_diagnostic": {
                "count": len(observation_sizes),
                "max_compact_stdlib_JSON_B": max(scalar_sizes, default=0),
                "max_by_engine": sizes_by_engine,
                "count_over_existing3072": sum(size > 3072 for size in scalar_sizes),
                "raw_engine_counts": dict(Counter(row[2] for row in observation_sizes)),
                "scope": "Saved-only stdlib JSON diagnostic, not exact Rust serialization, timestamp repair, acceptance certificate or model/backend digest.",
            },
            "literal_owning_gap": "value_search_strength::retained_outcome has hard3072B per-observation cap as well as current630784B outcome cap. Current truthful two-AI/NNUE metadata includes completed and whole-search counters, exceeding3072. Native report preserves CAPTURE_OUTCOME_OR_OBSERVATION_LIMIT, then unjournaled-started-outcome archive refusal. No raising scientific total bounds, detail truncation or acceptance waiver performed.",
            "minimum_next_step": "Root ordinary owning capture-layout correction before entering another pair. Existing630784 outcome/16MiB pair ceilings and fail-closed full-capture guards stay. Do not replay entered global2 or relaunch the partial pair; global3 remains UNKNOWN/unstarted until explicit exact future scope disposition. No knowingly failing batch2 submission.",
            "after_selected_identities": after,
            "current_source_model_library_artifact_caller_refs_before_after_MATCH": refs,
            "actual_source_input_model_library_private_caller_reader_STOP": lc.stamp(),
            "TMP_cleanup": "Exact owned empty directory removed after original children and finalizer absent; no blanket file deletion",
            "owned_readers_children_jobs_TMP_remaining": [],
            "new_native_model_head_Search_game_calls": 0,
            "storage_budget_for_collection": None,
        },
    )
print(
    json.dumps({"collection": ref(OUT / "collection-result.json"), "canonical_release": lc.stamp()})
)
