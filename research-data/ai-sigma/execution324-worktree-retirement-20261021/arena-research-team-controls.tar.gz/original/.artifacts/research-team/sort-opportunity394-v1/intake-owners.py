"""Read only newly identified owners and selected saved metadata pointers."""

import gzip
import hashlib
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent


def bound(path, limit=4 * 1024**2):
    data = path.read_bytes()
    if len(data) > limit:
        raise ValueError(f"selected bounded source/metadata exceeds limit: {path}")
    return data, {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


source_paths = [
    "crates/quoridor-ai/src/continuation_history.rs",
    "crates/quoridor-ai/src/tt_first386_tests.rs",
    "crates/quoridor-ai/src/move_ordering_tests.rs",
]
bindings = []
for relative in source_paths:
    data, binding = bound(MAIN / relative, 512 * 1024)
    binding["relative"] = relative
    bindings.append(binding)
    target = OWN / "before" / (relative.replace("/", "__") + ".gz")
    with target.open("xb") as output:
        output.write(gzip.compress(data, mtime=0))

selected = [
    ".artifacts/research-team/integration324/control-tt-first386-v1/acceptance-v1/result.json",
    ".artifacts/research-team/integration324/wall-map-invariance391-v1/acceptance-v1/result.json",
    ".artifacts/research-team/integration324/fixed-d-generation392-v1/finite24-v1/coverage.json",
    "research-data/ai-sigma/control-ranking-perf390/receipt.json",
]


def pointers(value, pointer=""):
    if isinstance(value, dict):
        if {"path", "sha256", "bytes"} <= value.keys():
            yield {"pointer": pointer, "FileRef": value}
        for key, child in value.items():
            yield from pointers(child, pointer + "/" + key)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from pointers(child, pointer + "/" + str(index))


metadata = []
for relative in selected:
    path = MAIN / relative
    if not path.exists():
        metadata.append({"path": str(path), "absent": True})
        continue
    data, binding = bound(path)
    parsed = json.loads(data)
    metadata.append(
        {
            "binding": binding,
            "top_keys": list(parsed),
            "FileRef_pointers": list(pointers(parsed)),
            "small_facts": {
                key: value
                for key, value in parsed.items()
                if isinstance(value, (str, int, float, bool)) or value is None
            },
        }
    )
for binding in bindings:
    _, after = bound(Path(binding["path"]), 512 * 1024)
    assert all(after[key] == binding[key] for key in ("sha256", "bytes", "mode"))
result = {
    "issue": "quoridor-4lc.394.1",
    "before_after": bindings,
    "selected_metadata": metadata,
    "Search_model_native_build_calls": 0,
}
(OWN / "intake-owners.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
print(json.dumps({"status": "PASS", "receipt": bound(OWN / "intake-owners.json")[1]}))
