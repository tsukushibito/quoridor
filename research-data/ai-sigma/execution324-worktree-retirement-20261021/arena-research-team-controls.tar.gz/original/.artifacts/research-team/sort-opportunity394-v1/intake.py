"""Bounded read-only ordering intake; no algorithm or model execution."""

import gzip
import hashlib
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent


def ref(path, limit=1024 * 1024):
    data = path.read_bytes()
    if len(data) > limit:
        raise ValueError(f"bounded metadata/source subject too large: {path}")
    return data, {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


subjects = [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-ai/src/move_ordering.rs",
    "crates/quoridor-ai/src/lib.rs",
    "crates/quoridor-runner/src/measurement.rs",
    "crates/quoridor-ai/Cargo.toml",
]
before = OWN / "before"
before.mkdir()
bindings = []
for relative in subjects:
    data, binding = ref(MAIN / relative, 512 * 1024)
    binding["relative"] = relative
    bindings.append(binding)
    target = before / (relative.replace("/", "__") + ".gz")
    with target.open("xb") as output:
        output.write(gzip.compress(data, mtime=0))

findings, findings_ref = ref(MAIN / "docs/research-findings.md", 4 * 1024**2)
lines = findings.decode().splitlines()
selected = []
for index, line in enumerate(lines):
    if any(
        word in line
        for word in ("cutoff rank", "cutoff_rank", "390", "391", "386", "scored_nodes")
    ):
        selected.append({"line": index + 1, "text": line})
if len(selected) > 100:
    selected = selected[-100:]

root = MAIN / ".artifacts/research-team/integration324"
named_scopes = [
    "control-tt-first386-v1",
    "nnue-map-reuse387-v1",
    "distance-map-first391-v1",
    "fixed-d-generation392-v1",
]
saved = []
for name in named_scopes:
    scope = root / name
    if not scope.is_dir():
        saved.append({"scope": str(scope), "absent": True})
        continue
    children = []
    for child in sorted(scope.iterdir()):
        if child.is_dir():
            children.append(
                {
                    "directory": child.name,
                    "metadata_names": [
                        p.name
                        for p in sorted(child.iterdir())
                        if p.is_file() and p.suffix in (".json", ".md")
                    ],
                }
            )
        elif child.suffix in (".json", ".md"):
            children.append({"metadata": child.name, "bytes": child.stat().st_size})
    saved.append({"scope": str(scope), "children": children})

for binding in bindings:
    data, after = ref(Path(binding["path"]), 512 * 1024)
    assert all(after[key] == binding[key] for key in ("sha256", "bytes", "mode"))

result = {
    "issue": "quoridor-4lc.394.1",
    "before_after": bindings,
    "findings_ref": findings_ref,
    "selected_findings_lines": selected,
    "named_saved_metadata": saved,
    "source_only": True,
    "Search_model_native_build_calls": 0,
    "mixed342_17": "USERPAUSE",
}
(OWN / "intake.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
print(json.dumps({"status": "PASS", "intake": ref(OWN / "intake.json")[1]}))
