"""Compose only the ordering observation delta from the frozen private intake."""

import gzip
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
OWN = Path(__file__).resolve().parent
OUT = OWN / "temporary-edited-subjects"


def before(relative):
    return gzip.decompress(
        (OWN / "before" / (relative.replace("/", "__") + ".gz")).read_bytes()
    ).decode()


def once(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new, 1)


alpha = "crates/quoridor-ai/src/alphabeta.rs"
history = "crates/quoridor-ai/src/continuation_history.rs"
measurement = "crates/quoridor-runner/src/measurement.rs"
original = {path: before(path) for path in (alpha, history, measurement)}
post = dict(original)
post[history] = once(
    post[history],
    "pub struct OrderingStats {\n",
    "pub struct OrderingStats {\n    /// None with observation OFF; existing cutoff-rank fields keep their old scope.\n    pub work: Option<Box<OrderingWorkStats>>,\n",
)
post[history] += "\n" + (OWN / "ordering-work-fragment.rs").read_text()
text = once(
    post[alpha],
    "use continuation_history::{ContinuationHistory, PlayedMove};",
    "use continuation_history::{ContinuationHistory, OrderingNodeWork, PlayedMove};",
)
text = once(
    text,
    "        let scores = self.ordering_scores(c, accumulator, &ids)?;",
    "        if self.ordering_diagnostics {\n            self.stats.ordering.observe_preparation(ids.len());\n        }\n        let scores = self.ordering_scores(c, accumulator, &ids)?;",
)
text = once(
    text,
    "        if matches!(\n            self.static_scratch.as_ref(),\n            Some(StaticScratch::CheapControl)\n        ) {\n            ranking.sort_control",
    "        if self.ordering_diagnostics {\n            self.stats.ordering.observe_sort(ids.len());\n        }\n        if matches!(\n            self.static_scratch.as_ref(),\n            Some(StaticScratch::CheapControl)\n        ) {\n            ranking.sort_control",
)
text = once(
    text,
    "        let mut deferred = None;\n        // Ordering diagnostics",
    "        let mut deferred = None;\n        let mut node_work = self.ordering_diagnostics\n            .then(|| OrderingNodeWork::start(&mut self.stats.ordering, false));\n        // Ordering diagnostics",
)
text = once(
    text,
    "        self.control()?;\n        if moves\n",
    "        if let Some(work) = node_work.as_mut() {\n            work.sorted_size = moves.as_ref().map(|moves| moves.len());\n        }\n        self.control()?;\n        if moves\n",
)
text = once(
    text,
    "            let action = if let Some(action) = first_tt.take() {\n                action\n",
    "            let action = if let Some(action) = first_tt.take() {\n                if let Some(work) = node_work.as_mut() {\n                    work.read(false, &mut self.stats.ordering);\n                }\n                action\n",
)
text = once(
    text,
    "                    moves = Some(self.ordered(c, a, None, ply, remaining)?.into_iter());\n                    self.control()?;",
    "                    moves = Some(self.ordered(c, a, None, ply, remaining)?.into_iter());\n                    if let Some(work) = node_work.as_mut() {\n                        work.sorted_size = moves.as_ref().map(|moves| moves.len());\n                    }\n                    self.control()?;",
)
text = once(
    text,
    "                let Some(action) = moves.as_mut().and_then(|moves| moves.next()) else {\n                    break;\n                };\n                action",
    "                let Some(action) = moves.as_mut().and_then(|moves| moves.next()) else {\n                    break;\n                };\n                if let Some(work) = node_work.as_mut() {\n                    work.read(true, &mut self.stats.ordering);\n                }\n                action",
)
text = once(
    text,
    "            if let Some(actions) = returned.as_mut() {",
    "            if let Some(work) = node_work.as_mut() {\n                work.returned(&mut self.stats.ordering);\n            }\n            if let Some(actions) = returned.as_mut() {",
)
text = once(
    text,
    "        Ok(value)\n    }\n    fn root_depth(",
    "        if let Some(work) = node_work {\n            work.finish(&mut self.stats.ordering, cutoff_winner.is_some());\n        }\n        Ok(value)\n    }\n    fn root_depth(",
)
text = once(
    text,
    "        let moves = self.ordered(c, a, previous, 0, legal.unwrap_or_else(|| c.legal_ids()))?;",
    "        let mut node_work = self.ordering_diagnostics\n            .then(|| OrderingNodeWork::start(&mut self.stats.ordering, true));\n        let moves = self.ordered(c, a, previous, 0, legal.unwrap_or_else(|| c.legal_ids()))?;\n        if let Some(work) = node_work.as_mut() {\n            work.sorted_size = Some(moves.len());\n        }",
)
text = once(
    text,
    "        for (i, action) in moves.into_iter().enumerate() {",
    "        for (i, action) in moves.into_iter().enumerate() {\n            if let Some(work) = node_work.as_mut() {\n                work.read(true, &mut self.stats.ordering);\n            }",
)
start = text.index("    fn root_depth(")
head, tail = text[:start], text[start:]
tail = once(
    tail,
    "            if v > value {",
    "            if let Some(work) = node_work.as_mut() {\n                work.returned(&mut self.stats.ordering);\n            }\n            if v > value {",
)
tail = once(
    tail,
    "        Ok((best, value))",
    "        if let Some(work) = node_work {\n            work.finish(&mut self.stats.ordering, false);\n        }\n        Ok((best, value))",
)
post[alpha] = (
    head
    + tail
    + '\n#[cfg(all(test, feature = "research-diagnostics"))]\n#[path = "ordering_work394_tests.rs"]\nmod ordering_work394_tests;\n'
)

text = post[measurement]
start = text.index("    let o = &s.ordering;")
end = text.index("\n}", start)
block = text[start:end]
assert block.count("    json!({") == 1
block = block.replace("    json!({", "    let mut result = json!({", 1)
assert block.endswith("}})")
block += ';\n    if let Some(w) = o.work.as_deref() {\n        result["ordering"]["work"] = json!({\n'
fields = [
    "nodes_started",
    "nodes_finished",
    "roots_finished",
    "preparation_calls_started",
    "preparation_actions_requested",
    "sort_calls_started",
    "sort_actions_started",
    "nontrivial_sort_calls_started",
    "sorted_reads_started",
    "sorted_returns_started",
    "tt_first_reads_started",
    "tt_first_returns_started",
    "sort_nodes_finished",
    "scored_actions_finished",
    "sort_actions_finished",
    "nontrivial_sort_nodes_finished",
    "sorted_reads_finished",
    "sorted_returns_finished",
    "tt_first_returns_finished",
    "cutoff_nodes_finished",
    "cutoff_unread_sorted_actions",
    "all_sorted_read_nodes",
    "first_sorted_cutoff_nodes",
    "tt_only_no_sort_cutoff_nodes",
    "empty_sorted_nodes_finished",
    "single_sorted_nodes_finished",
    "sort_size_started",
    "sort_size_finished",
    "consumed_fraction_finished",
]
block += ",\n".join(f'            "{field}": w.{field}' for field in fields)
block += ',\n            "nodes_unfinished": w.nodes_started - w.nodes_finished\n        });\n    }\n    result'
post[measurement] = text[:start] + block + text[end:]
text = post[measurement]
text = once(
    text,
    "    #[serde(default)]\n    warmup: bool,",
    "    #[serde(default)]\n    warmup: bool,\n    #[serde(default)]\n    observe_completed_depths: bool,",
)
text = once(
    text,
    "        let result = session.search(root, &limits, cancel);",
    """        let mut completed_depths = Vec::new();
        let result = if request.observe_completed_depths {
            session.search_with_updates(root, &limits, cancel, &mut |completed| {
                completed_depths.push(completed_depth_observation(completed));
            })
        } else {
            session.search(root, &limits, cancel)
        };""",
)
text = once(
    text,
    '        row["Search_call_seconds"] = json!(search_seconds);',
    '        if request.observe_completed_depths {\n            row["completed_depth_observations"] = json!(completed_depths);\n        }\n        row["Search_call_seconds"] = json!(search_seconds);',
)
text = once(
    text,
    "fn observed(r: &SearchResult) -> Value {",
    """// The existing completed-depth callback is outside per-node hot paths. These
// are cumulative actual counters, not predicted branching/cost or a D6 result.
fn completed_depth_observation(r: &SearchResult) -> Value {
    let s = &r.stats;
    json!({"completed_depth":r.completed_depth,"action":r.action,
        "value_bits":r.value.map(f32::to_bits),"elapsed_seconds":r.elapsed.as_secs_f64(),
        "cumulative_work":{"nodes":s.nodes,"evaluations":s.evaluations,
            "terminal":s.terminal,"cutoffs":s.cutoffs,"TT_probes":s.tt_probes,
            "TT_hits":s.tt_hits,"TT_usable_depth":s.tt_usable_depth,
            "TT_cutoffs":s.tt_cutoffs,"TT_order_only":s.tt_order_only,
            "TT_index_collisions":s.tt_index_collisions,"TT_replacements":s.tt_replacements,
            "PVS_researches":s.pvs_researches,"delta_updates":s.delta_updates,
            "TT_generation":s.tt_generation,"TT_retained_bytes":s.tt_retained_bytes}})
}
fn observed(r: &SearchResult) -> Value {""",
)
# The existing test Request constructor needs the new optional field; no old
# successful assertion changes or replay are requested.
text = once(
    text,
    "            warmup: false,",
    "            warmup: false,\n            observe_completed_depths: false,",
)
post[measurement] = (
    text
    + '\n#[cfg(test)]\n#[path = "measurement_ordering394_tests.rs"]\nmod measurement_ordering394_tests;\n'
)
new = "crates/quoridor-ai/src/ordering_work394_tests.rs"
post[new] = (OWN / "ordering_work394_tests.rs").read_text()
new_measurement = "crates/quoridor-runner/src/measurement_ordering394_tests.rs"
post[new_measurement] = (OWN / "measurement_ordering394_tests.rs").read_text()
OUT.mkdir()
for relative, data in post.items():
    path = OUT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data)
(OWN / "composition-input.json").write_text(
    json.dumps(
        {
            "changed_existing_paths": list(original),
            "new_paths": [new, new_measurement],
            "frozen_intake": "intake.json + intake-owners.json",
            "native": "UNBUILT/UNTYPED/UNRUN",
        },
        indent=2,
    )
    + "\n"
)
print(json.dumps({"private_composition_prepared": True, "paths": list(post)}))
