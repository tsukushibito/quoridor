"""Guarded private composition/format/roundtrip, never Main source mutation."""

import difflib
import gzip
import importlib.util
import json
import os
import shutil
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
OUT = OWN / "format-v1"
TEMP = OWN / "temporary-edited-subjects"
loader = importlib.util.spec_from_file_location(
    "lc", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


bindings = json.loads((OWN / "intake.json").read_text())["before_after"]
bindings += json.loads((OWN / "intake-owners.json").read_text())["before_after"]
paths = [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-ai/src/continuation_history.rs",
    "crates/quoridor-runner/src/measurement.rs",
]
before_refs = {
    b["relative"]: {k: b[k] for k in ("path", "sha256", "bytes", "mode")}
    for b in bindings
    if b["relative"] in paths
}
original = {}
for path, binding in before_refs.items():
    original[path] = lc.read_ref(binding).decode()
    saved = gzip.decompress(
        (OWN / "before" / (path.replace("/", "__") + ".gz")).read_bytes()
    ).decode()
    lc.require(saved == original[path], "private actual before bytes")
new = [
    "crates/quoridor-ai/src/ordering_work394_tests.rs",
    "crates/quoridor-runner/src/measurement_ordering394_tests.rs",
]
for path in new:
    lc.require(not os.path.lexists(MAIN / path), "new Main test subject absent")
lc.require(
    not OUT.exists() and not TEMP.exists(), "exclusive first private source composition"
)
OUT.mkdir()
spec = {
    "kind": "software",
    "cwd": str(MAIN),
    "env": dict(os.environ),
    "limits": {
        "family_B": 384 * 1024**2,
        "controller_B": 64 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "worker_cpu": 5,
        "guardian_cpu": 6,
        "log_B": 128 * 1024,
    },
}
resources = lc.process.CycleResources(
    {"host_ram_reserve": 4 * 1024**3, "max_memory_bytes": 320 * 1024**2}, OUT, None
)
checks = []


def command(name, argv):
    lc.command(
        spec,
        {"name": name, "role": "source", "argv": argv},
        OUT,
        resources,
        ledger=checks,
    )


all_paths = paths + new
primary = None
try:
    import sys

    command("private-compose", [sys.executable, "-B", str(OWN / "prepare-patch.py")])
    rustfmt = shutil.which("rustfmt")
    lc.require(rustfmt is not None, "existing Rust formatter")
    command(
        "rustfmt",
        [
            rustfmt,
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            *[str(TEMP / p) for p in all_paths],
        ],
    )
    command(
        "rustfmt-check",
        [
            rustfmt,
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            "--check",
            *[str(TEMP / p) for p in all_paths],
        ],
    )
    formatted = {path: (TEMP / path).read_text() for path in all_paths}
    patch = "".join(
        "".join(
            difflib.unified_diff(
                original.get(path, "").splitlines(True),
                formatted[path].splitlines(True),
                fromfile="a/" + path if path in original else "/dev/null",
                tofile="b/" + path,
            )
        )
        for path in all_paths
    )
    patch_path = OWN / "ordering-observation394.patch"
    patch_path.write_text(patch)
    post_refs = [
        {
            "logical_Main_path": str(MAIN / path),
            **{k: v for k, v in ref(TEMP / path).items() if k != "path"},
        }
        for path in all_paths
    ]
    command(
        "inverse",
        [
            "/usr/bin/patch",
            "--batch",
            "--reverse",
            "--no-backup-if-mismatch",
            "-p1",
            "-d",
            str(TEMP),
            "-i",
            str(patch_path),
        ],
    )
    for path, text in original.items():
        lc.require((TEMP / path).read_text() == text, "exact inverse before bytes")
    for path in new:
        lc.require(not (TEMP / path).exists(), "inverse new-file absence")
    command(
        "forward",
        [
            "/usr/bin/patch",
            "--batch",
            "--forward",
            "--no-backup-if-mismatch",
            "-p1",
            "-d",
            str(TEMP),
            "-i",
            str(patch_path),
        ],
    )
    for path, text in formatted.items():
        lc.require((TEMP / path).read_text() == text, "exact formatted forward bytes")
    for binding in before_refs.values():
        lc.read_ref(binding)
    for path in new:
        lc.require(not os.path.lexists(MAIN / path), "Main new subject still absent")
except BaseException as error:
    primary = lc.error_fact(error)
finally:
    if TEMP.exists():
        for path in all_paths:
            target = TEMP / path
            if target.exists():
                target.unlink()
        for directory in sorted(
            [p for p in TEMP.rglob("*") if p.is_dir()],
            key=lambda p: len(p.parts),
            reverse=True,
        ):
            directory.rmdir()
        lc.require(not list(TEMP.iterdir()), "unknown temporary source retained")
        TEMP.rmdir()
STOP = lc.stamp()
result = {
    "issue": "quoridor-4lc.394.1",
    "status": "FAILED" if primary else "PASS",
    "primary": primary,
    "checks": checks,
    "Main_before_after": list(before_refs.values()),
    "new_Main_files_absent": new,
    "source_reader_writer_STOP": STOP,
    "temporary_source_remaining": [],
    "native": "UNBUILT/UNTYPED/UNRUN",
    "model_Search_build_calls": 0,
    "storage_budget": None,
    "mixed342_17": "USERPAUSE",
}
if not primary:
    result.update(
        patch=ref(patch_path),
        formatted_postimages=post_refs,
        exact_forward_inverse=True,
    )
lc.new_json(OUT / "result.json", result)
print(
    json.dumps(
        {"status": result["status"], "result": ref(OUT / "result.json"), "STOP": STOP}
    )
)
if primary:
    raise SystemExit(1)
