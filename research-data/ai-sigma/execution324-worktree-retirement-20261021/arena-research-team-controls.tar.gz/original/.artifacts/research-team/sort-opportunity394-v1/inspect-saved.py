"""Inspect only selected small original metadata/results, never RAW or model payloads."""

import hashlib
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
OWN = Path(__file__).resolve().parent
selected = json.loads((OWN / "intake-owners.json").read_text())["selected_metadata"]


def read(binding):
    path = Path(binding["path"])
    data = path.read_bytes()
    assert len(data) == binding["bytes"] <= 4 * 1024**2
    assert hashlib.sha256(data).hexdigest() == binding["sha256"]
    assert format(path.stat().st_mode & 0o777, "04o") == binding["mode"]
    return json.loads(data)


def summarize(value, pointer=""):
    found = []
    if isinstance(value, dict):
        if "ordering" in value:
            found.append(
                {
                    "pointer": pointer,
                    "ordering": value["ordering"],
                    "diagnostic": value.get("diagnostic"),
                    "status": value.get("status"),
                }
            )
        for key, child in value.items():
            if isinstance(child, dict) and {"path", "sha256", "bytes"} <= child.keys():
                found.append({"pointer": pointer + "/" + key, "FileRef": child})
            elif isinstance(child, (dict, list)):
                found.extend(summarize(child, pointer + "/" + key))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found.extend(summarize(child, pointer + "/" + str(index)))
    return found


results = []
for item in selected:
    if item.get("absent"):
        continue
    value = read(item["binding"])
    name = Path(item["binding"]["path"]).parts
    wanted = {
        "/saved_comparison",
        "/references/finite_result",
        "/references/interpretation",
    }
    for pointer in item["FileRef_pointers"]:
        if pointer["pointer"] not in wanted:
            continue
        binding = pointer["FileRef"]
        result = read(binding)
        results.append(
            {
                "bound_from": item["binding"],
                "binding": binding,
                "top_keys": list(result),
                "ordering_and_result_pointers": summarize(result),
            }
        )
    if "control-ranking-perf390" in name:
        results.append(
            {
                "binding": item["binding"],
                "groups": value.get("groups"),
                "passes": value.get("passes"),
                "diagnostic_samples": summarize(value),
                "limit": "Perf time shares do not encode sorted-list consumption",
            }
        )
(OWN / "saved-inspection.json").write_text(
    json.dumps(
        {
            "issue": "quoridor-4lc.394.1",
            "selected_results": results,
            "Search_model_calls": 0,
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "selected_result_count": len(results),
            "ordering_dicts": sum(
                sum(
                    "ordering" in row
                    for row in item.get("ordering_and_result_pointers", [])
                )
                for item in results
            ),
        }
    )
)
