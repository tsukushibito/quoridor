# 採点・sortで使われない仕事の確認（固定私有source）

現在のControlのコードは、合法TT手を先に読んでcutoffした場合、そのnodeの残りの採点・sortをすでに省いている。一方、TT手が無い場合や先行TT手でcutoffしない場合は、対象を全部採点・整列してから順に読む。後半が未読になる機会はあるが、未読手の採点まで全部不要だったとはいえない。最優先手の選択にも候補の比較が必要である。

今回の範囲は保存統計の適否と最小観測の準備まで。heap、MovePicker、radix、sort差替え、TT保存量、採点省略は実装・採用しない。実Search、公開モデルpayload、NN forward、Cargo、Perf、対局は作者が実行しない。

## 保存で分かることと足りない分母

対象Mainのalphabeta／move_ordering／continuation_history／measurementをbounded intakeで束縛した。Main beforeimageはintake.jsonとintake-owners.json、実読取・caller/environment after・process/TMP cleanupは各guard receiptにある。旧376のconstructorを現在のControlへ同一視せず、386以後のTT-firstと現在の合成比較キーの経路を使う。

既存OrderingStatsはordered_nodes、scored_actions、completed_cutoff_events、cutoff_rank_sum、first_child_cutoffs等を持つが、完成したordered nodeの対象数と読取数の対応、TT-only no-sort event、途中nodeのsort/read/returnを保存しない。ordered_nodesの加算はordering_scoresの途中にあり、すべての準備開始でもnode完了でもない。cutoff rankはTT-only cutoffも含む。そのため、単純なcutoff_rank_sum/completed_cutoff_eventsをordered node全体の仕事や未読率へ換算できない。

保存386比較はTT-first採用の有限結果であり、5rootでwork差があった原FAILを保つ。391はNNUE/BEST43の同30work一致24call比較であり、geometryの局所判定頻度やBFS回避数を認定しない。その両比較の小さい原collection/resultと391 interpretationをSHA・size・mode照合して読んだが、対象の新しい分母は提供されていない。390の元receiptは18call／9session、同image・同記録workの保存profileである。Perf時間割合には未読の手数やfinished-nodeの分母がなく、14%から一手の回避費を逆算しない。原RAWは読み直していない。

392の診断OFFの0は仕事0ではない。元有限試験は20 COMPLETE D4と4 UNKNOWN NodeLimit（完成D5）であって24 COMPLETEではない。unsupported generatorControlをCoverageへ戻した工程はRootの別仕事であり、そのratioをControl D6や同workの速度へ転用しない。固定Dの現在Controlについても、上の分母が不足する。

したがってNNUEと固定Dの両方で新しい分母が必要。片方の結果を他方へ外挿しない。376の別constructorや観測OFFの旧結果を追加で広く読むことでは、存在しない消費counterは復元できない。現段階のnative実行数は0。最大12の新観測を作者が発行するものではない。

## 最小counter案

既存OrderingStatsにdiagnostic workを任意項目として加える。OFFはNoneのまま、ONで必要になる一つの小さい集計だけを確保する。新しい局面・history snapshot、prepared IDsのcopy、二度の手走査、per-node時計・ログは置かない。現在の採点、比較キー、整列、history・TT更新、child/PVS、評価、合法性、undo、cancel/errorはそのままにする。

準備の呼出し開始／要求action数とsort呼出し／対象数を別々に記録する。0/1対象でも採点・key準備があり得るため、sort呼出し数と2以上のnontrivial sort呼出し数を区別する。ここでnontrivialは対象サイズの分類であり、標準sort内部の比較回数・swap・cycle数の観測ではない。

TTの値・boundだけで終わるcache cutoff、leaf、terminalはordering-node分母から除く。合法列を扱い始めたnodeのstartedと、元control/restoration・TT publication後のfinishedを記録する。rootも実際にsortされるので含め、roots_finishedで区別する。started-finishedが未完了node数であり、取消やerrorを0 workのfinished nodeへしない。

sort済みiteratorから異なるactionを取り出す時点をread、同じactionの必要なPVS再探索まで終わった時点をterminal returnとして別々に数える。TT-firstの手は別counter。同手のPVS二回呼出しは一read・一returnである。finished nodeについて対象数、read/return、cutoff時未読数、全手read、最初のsorted手でのcutoff、TT-only no-sort、0/1対象を対応づける。sort sizeと消費割合は6区分の固定histogramだけにする。

SearchがErrを返してSearchResultを公開しなかった場合、元measurementはUNKNOWN/errorを保存する。現在の案は捨てられたSearchStatsを推測して公開しない。そのerror operationの内部counterはUNKNOWNのまま。NodeLimit／Cancelled等でSearchResultが返る場合はstarted/finishedとpartial workが実記録に残る。この区別を結果の限界に明示する。

## 今回説明できる分類

| 分類 | コードまたは保存から言えること | 数量・時間の限界 |
|---|---|---|
| すでに省いている処理 | ControlのTT-first cutoffではsiblingsの準備・採点・sortを行わない。空のdeferred remainderもsortしない | 旧cutoff rankからこのevent数を分離できない |
| 同順位でも整列が不要 | 対象0/1には手同士の順序が無い | 現在key/採点の全体を省くとerror/validationの時点まで変わり得る。未採用 |
| 早いcutoffで使われない残順序 | 最後より前にcutoffしたnodeでは、残りの手同士の順序は読まれない | 完成nodeごとの未読数が不足。候補採点・最優先選択まで無駄とはいえない |
| 全順序を読む処理 | cutoff無し、最後でcutoff、rootの全手列では全手を読む | PVS再探索は異なる手の数と別。TT/cache/leaf/terminalとも別 |
| 費用を分離できない処理 | 全候補の採点・key構築・順位選択・実整列、setup/drop | 未読数から時間利益、heap優位、採点全省略を認定しない |

次の候補を選ぶには、finished nodeのサイズと消費分布、TT-onlyの分離、途中仕事が必要。診断ON時間には集計の費用が入るので性能主張に使わない。今回の結果だけで次のsort実装や比較を自動発行しない。

## 必要な次の入力（未launch）

Rootが両評価器について既存6rootsを各1passとする最小診断を実際のresolved settingsに束縛する。cold D4 family102、cold D6 family34、warm D4 family0 local0/2/4/6。同一warm session順、TT4096、PVS、全history／rules、D4各2M・D6各8M。両方で最大12call／6session／36M。新しいpayloadやfuture artifactのFileRefはまだ作らない。

finished/depth/value/action/PV/legal/history/parent/stopを正直に保存し、NodeLimit等はUNKNOWN/partialのまま。原20/4や旧成功を再演・refill・promotionしない。必要software後、他の実timingと重ならない現在324の既存共通計測入口が所有する。固定patch b4746343／39022Bは既存3subjectと新しい玩具2subjectだけ。対象限定Rustfmt/check、private GNU patch逆向き・順向きの全byte照合、新file不在は実PASS。型検査・玩具8定義（AI6、出力/callback2）はUNBUILT／UNTYPED／UNRUN。Mainは変更していない。

09:25:08.455947Zに保存reader leaseを解放後、393の実timing準備に合わせてcheckpoint-before393.json（cfb5ecfe／4057B）でfresh本人child identity不在・directreap/handles・TMP不在・owned[]を報告した。実393 timingSTOP後に元scopeを再開した。source/formatter reader STOP09:48:39.300750Z、caller/environment reader STOP.373703、canonical release.374295。すべて2026-10-14。元393候補はRootが全24COMPLETE・all30work一致でもwhole1.0958117で不支持として候補だけ戻した別の有限結果であり、このcounter案の利益・資格ではない。混合342.17のsource/preparation/generation/converter/fit/newweights/256と323はUSERPAUSEを保つ。


## depth別の実不足と既存callbackへの任意項目

元measurementのRequestはdiagnostic/warmupまでで、session.searchの完成depth callbackを保存へ渡していない。保存比較の終端workやcompleted_depthから、各完成depth時点の累積node/evaluation/TT/PVS仕事を復元できない。完成D5・最終8MのD6未完了は、その8MをD5仕事として扱えない。既存on_completedは整合・PV検査後に完成depthだけを公開するため、Search本体に新しいdepth hookは不要。

Request.observe_completed_depthsをserde defaultfalseで追加し、選択時だけ同じSearchSession.search_with_updatesを使う。callbackはcompleted_depth、action、value_bits、既存elapsedと15個の累積work scalarを保存する（nodes/evaluations/terminal/cutoffs/TT probes・hits・usable depth・cutoffs・order-only・index collisions・replacements/PVS re-search/delta updates/TT generation・retained bytes）。PVやhistoryの追加copy、時計の追加サンプル、追加Searchはない。OFFでは元session.search経路、depth vectorは空でallocationなし、出力項目もない。

出力completed_depth_observationsは完成depthの累積値。最後の部分depthは元final rowのworkとstop/UNKNOWNに残る。callback記録を最終完成へ昇格させない。SearchがErrになっても、それ以前の本物の完成callbackは残すが、失敗中depthの内部statsはUNKNOWN。新しいrunner定義は出力追加前後の旧fields不変、および実toyのD1完成／D2 NodeLimitでcallback累積とfinal partialの分離・ON/OFF同work・親復元／teardownを検査する未実行定義である。

396との共有は固定D coldD6 family34の同じactual requestにobserve_completed_depths=trueを付けるだけの方向。根・fullhistory/rules・実constructor・評価器・TTsession・nodecap等が一致する実設定をRootが一度束縛する。同じcallを共有できない設定差があれば、暗黙に置き換えたり、別callを足したりしない。作者は396のgeneration/control数学・TT/history最適化を変更していない。

format guard whole controllerは元receiptへ一度だけ数え、内側compose/formatter/patch wallを加算しない。原saved readのfresh physical拒否6653とDocker再開前checkpointcfb5は保持。最終fresh本人identity/TMP/lease/usage STOPとBeads backup・一度のcurrent324 deliveryを別のSTOP.jsonに保存する。
