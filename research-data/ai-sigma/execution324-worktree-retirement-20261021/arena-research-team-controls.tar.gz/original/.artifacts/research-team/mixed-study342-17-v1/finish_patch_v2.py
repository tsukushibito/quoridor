"""Format one temporary publisher and verify only the affected saved collector."""

import ast
import difflib
import importlib.util
import json
import os
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
OUT = OWN / "collector-check-v2"
loader = importlib.util.spec_from_file_location(
    "lc", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
original_result_ref = lc.bound(OWN / "preparation-result.json")[0]
result = lc.document(original_result_ref)
before_ref = result["collector_current_beforeimage"]
original = lc.read_ref(before_ref).decode()
old = """            if (
                experiment["phase"] == "materialize"
                and item["name"] in COMPACT_CACHE_WIDTHS
            ):
"""
new = """            if (
                experiment["phase"] == "materialize"
                and item["name"] in COMPACT_CACHE_WIDTHS
            ) or (
                experiment["phase"] == "corpus" and item["name"] == "pilot_stream"
            ):
"""
lc.require(original.count(old) == 1, "one exact collector beforeimage")
post = original.replace(old, new).replace(
    '"declared compact output size"', '"declared streamed output size"'
)
post = post.replace(
    '                    read_ref(ref, ref["bytes"])',
    '                    require(artifact_ref(ref["path"]) == ref, "canonical corpus stream identity drift")',
)
OUT.mkdir()
temporary = OUT / "temporary-publisher.py"
temporary.write_text(post)
spec = {
    "kind": "software",
    "cwd": str(MAIN),
    "env": dict(os.environ),
    "limits": {
        "family_B": 384 * 1024**2,
        "controller_B": 64 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "worker_cpu": 5,
        "guardian_cpu": 6,
        "log_B": 64 * 1024,
    },
}
resources = lc.process.CycleResources(
    {"host_ram_reserve": 4 * 1024**3, "max_memory_bytes": 320 * 1024**2},
    OUT,
    None,
)
ruff = "/home/vscode/.cache/inference/envs/quoridor-training/bin/ruff"
checks = []
try:
    for name, argv in [
        (
            "collector-format",
            [ruff, "format", "--config", str(MAIN / "pyproject.toml"), str(temporary)],
        ),
        (
            "collector-format-check",
            [
                ruff,
                "format",
                "--check",
                "--config",
                str(MAIN / "pyproject.toml"),
                str(temporary),
            ],
        ),
        (
            "collector-NN0",
            [
                str(lc.project_python()),
                "-B",
                str(OWN / "test_corpus_stream_v2.py"),
                str(temporary),
            ],
        ),
    ]:
        lc.command(
            spec,
            {"name": name, "role": "software", "argv": argv},
            OUT,
            resources,
            ledger=checks,
        )
    formatted = temporary.read_text()
    lc.require(
        ast.dump(ast.parse(formatted), include_attributes=False)
        == ast.dump(ast.parse(post), include_attributes=False),
        "format AST unchanged",
    )
    lc.read_ref(before_ref)
    patch = "".join(
        difflib.unified_diff(
            original.splitlines(True),
            formatted.splitlines(True),
            fromfile="a/scripts/dev/research-lifecycle.py",
            tofile="b/scripts/dev/research-lifecycle.py",
        )
    )
    patch_path = OWN / "corpus-stream-collector.current.patch"
    patch_path.write_text(patch)
    text = lc.read_ref(checks[-1]["full_log"]).decode()
    lc.require(
        "Ran 1 test" in text and "\nOK\n" in text, "exact one new NN0 definition"
    )
    facts = {
        "source_before_after": before_ref,
        "original_preparation": original_result_ref,
        "patch": lc.bound(patch_path)[0],
        "checks": checks,
        "format_AST_exact": True,
        "test_definition": lc.bound(OWN / "test_corpus_stream_v2.py")[0],
        "native_model_Search_game_fit_calls": 0,
        "temporary_postimage_before_removal": lc.bound(temporary)[0],
        "scope": "One new saved gzip hash/cap/ownership collector definition; no original success replay",
    }
finally:
    temporary.unlink()
facts["temporary_publisher_remaining"] = []
facts["actual_source_reader_writer_STOP"] = lc.stamp()
lc.new_json(OUT / "result.json", facts)
# Fix only the mislabeled metadata ref: loop-local config_ref named the last batch.
# The original raw CLI/captures/inputs and initial result remain immutable.
result["input_config"] = lc.bound(OWN / "global-input-settings.selected.json")[0]
result["collector_patch"] = lc.bound(patch_path)[0]
forensic = {
    "path": "/workspaces/quoridor/.artifacts/research-team/integration324/mixed-study342-17-v1/resources.json",
    "sha256": "5150507478eebc77ec70767382c44ee65f12ea424bf8204bca5fbc0d5bfece38",
    "bytes": 3194,
    "mode": "0644",
}
support = lc.document(forensic)
root_plan_ref = support["selected_plan"]
lc.read_ref(root_plan_ref)
result["actual_Root_support"] = forensic
result["actual_Root_selected_plan"] = root_plan_ref
sequence = lc.document(result["sequence_draft"])
for run in sequence["runs"]:
    run["owner"] = str(MAIN)
    run["support"] = forensic
    run["owned_outputs"] = support["storage_budget"]["owned_union"]
    run["data"].append(
        {
            "name": "generation_result",
            "path": str(Path(run["data_root"]) / "generation-result.json"),
            "limit_B": 1024**2,
        }
    )
    run["approved_plan"] = root_plan_ref
    experiment = lc.document(run["experiment"])
    experiment["canonical_plan_sha256"] = root_plan_ref["sha256"]
    numerical = lc.document(experiment["numerical_qualification"])
    numerical["canonical_plan_sha256"] = root_plan_ref["sha256"]
    batch = Path(run["experiment"]["path"]).name.split("-experiment")[0]
    qpath = OWN / (batch + "-correspondence-current.json")
    lc.new_json(qpath, numerical)
    experiment["numerical_qualification"] = lc.bound(qpath)[0]
    epath = OWN / (batch + "-experiment-current.json")
    lc.new_json(epath, experiment)
    run["experiment"] = lc.bound(epath)[0]
sequence["owner"] = str(MAIN)
sequence["output"] = str(
    MAIN
    / ".artifacts/research-team/integration324/mixed-study342-17-v1/generation-sequence-v1"
)
sequence["remaining_actual_launch_inputs"] = [
    "Root integrate collector patch and bind its changed caller refs",
    "Root choose ordinary operation placement under selected sequence output rather than current owner/basename derivation",
    "actual outer originating job/config and fresh guards",
]
current_sequence = OWN / "generation-sequence-current.draft.json"
lc.new_json(current_sequence, sequence)
result["sequence_draft"] = lc.bound(current_sequence)[0]
result["experiments"] = [run["experiment"] for run in sequence["runs"]]
result["runtime_gap"] = (
    "Root collector/caller adoption and operation placement plus actual originating job; support now supplied; no readyfalse/None submitted"
)
result["original_preparation_result"] = original_result_ref
result["metadata_correction"] = (
    "input_config now names actual original global InputConfig; no native/rules replay"
)
lc.new_json(OWN / "preparation-result-current.json", result)
print(
    json.dumps(
        {
            "result": lc.bound(OWN / "preparation-result-current.json")[0],
            "collector_check": lc.bound(OUT / "result.json")[0],
        }
    )
)
