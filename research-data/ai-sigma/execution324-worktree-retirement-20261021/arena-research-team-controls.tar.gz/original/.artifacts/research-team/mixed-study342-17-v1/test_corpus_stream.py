"""One new NN0 collector boundary definition; actual gzip and maintained helpers."""

import ast
import gzip
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path

POST = Path(sys.argv[1])
sys.argv = [sys.argv[0]]
MAIN = Path("/workspaces/quoridor")
loader = importlib.util.spec_from_file_location(
    "lc", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
module = ast.parse(POST.read_text())
function = next(
    node
    for node in module.body
    if isinstance(node, ast.FunctionDef) and node.name == "collect_data"
)
namespace = dict(lc.__dict__)
exec(
    compile(ast.Module(body=[function], type_ignores=[]), str(POST), "exec"), namespace
)


class CorpusStreamTests(unittest.TestCase):
    def test_corpus_stream_hash_preserves_size_and_ownership_refusal_without_bulk_read(
        self,
    ):
        with tempfile.TemporaryDirectory() as temporary:
            owner = Path(temporary)
            data_root = owner / "data"
            data_root.mkdir()
            stream = data_root / "pilot-stream.jsonl.gz"
            stream.write_bytes(
                gzip.compress(b'{"saved_synthetic_record":true}\n', mtime=0)
            )
            expected = lc.artifact_ref(stream)
            calls = []

            def ordinary_bound(path, limit=lc.CONTROL_BYTES):
                calls.append(str(path))
                if Path(path) == stream:
                    raise AssertionError("corpus stream must not allocate via bound")
                return lc.bound(path, limit)

            namespace["bound"] = ordinary_bound
            experiment = {
                "phase": "corpus",
                "planned_slots": 1,
                "batch": None,
                "argv": ["synthetic-unused-executable", "teacher-pilot"],
            }
            spec = {
                "owner": str(owner),
                "data_root": str(data_root),
                "data": [
                    {
                        "name": "pilot_stream",
                        "path": str(stream),
                        "limit_B": expected["bytes"],
                    }
                ],
            }
            actual = namespace["collect_data"](spec, experiment)
            self.assertEqual(actual["status"], "PASS")
            self.assertEqual(actual["files"], [expected])
            self.assertEqual(actual["errors"], [])
            self.assertEqual(actual["planned_slots"], 1)
            self.assertEqual(actual["observed_local_games"], [])
            self.assertFalse(actual["global_campaign_complete"])
            self.assertEqual(calls, [])
            spec["data"][0]["limit_B"] = expected["bytes"] - 1
            overflow = namespace["collect_data"](spec, experiment)
            self.assertEqual(overflow["status"], "FAILED")
            self.assertEqual(overflow["files"], [])
            self.assertEqual(overflow["errors"][0]["stage"], "pilot_stream")
            self.assertIn(
                "declared streamed output size", overflow["errors"][0]["message"]
            )
            self.assertEqual(calls, [])
            spec["owner"] = str(owner / "another-owner")
            refusal = namespace["collect_data"](spec, experiment)
            self.assertEqual(refusal["status"], "FAILED")
            self.assertEqual(refusal["files"], [])
            self.assertIn("write ownership", refusal["errors"][0]["message"])
            self.assertEqual(calls, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
