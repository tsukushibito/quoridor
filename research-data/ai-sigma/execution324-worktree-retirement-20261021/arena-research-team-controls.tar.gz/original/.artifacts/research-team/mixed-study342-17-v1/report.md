# 混合学習342.17：事前入力と4生成設定

人間の最新の直接指示で選択された初期recipeを準備した。旧342.16のe268c0f7/806172f3および381のUNSELECTED設定は変更していない。現在の正しい参照は `preparation-result-current.json`（SHA256 `09870bfcf48d2ac963dd90a0e01a3f8e6d310fb0965e67892e78b222d2d3a6d1` / 24618B）。元resultのinput_configがloop最後のbatch003を指したmetadata誤りだけを新resultで訂正した。元result・返却JSON・入力CLI実行はそのまま保持した。

## 実入力

genuine381 runner `9a63d2f3…` / Build `f8890ea6…` の維持された `teacher-pilot --prepare-inputs SETTINGS --input-sha256 SHA` を2回だけ実行した。これはlegal/history/family処理であり、Search・NN/model forward・生成対局・fit・BUILDは0回である。

| 入力 | 実数と参照 |
|---|---|
| 全体schedule | 1280 requests、4/8/12/16ply各320・round-robin、seed38020261013。全prefix成功、失敗0。SHA `b72cd087…` / 1324742B。 |
| family partition | 実unique F=1280、T=1024/V=256（requestsも今回同数）。seed38020261014、維持されたLR・extension・same endpoint groupingとfloor(4F/5)。SHA `89b9343f…` / 224548B。 |
| 既存book除外 | 現355/374の実128 family book `a6abde1f…` / 85083Bを使う。family形式からprefix/idだけをopenings形式へ投影し、元FileRefを保持した。旧old_open8配列はこの現128 bookのopeningではない。 |
| 新評価履歴 | 64成功履歴・64別collision family、4/8/12/16ply各16、seed38020261018。入力CLIがstudy全体と既存128 bookに対するLR・extension・endpoint非衝突を保存前に確認した。 |
| 新評価book | `inputs/evaluation-book.json` SHA `2b903467…` / 150708B。actual prefix/root/historyとfamily参照を保存。2色×BEST43/D=256予定局は未実行。共通PRNG/初期盤面による相関は残り、population independenceを証明しない。 |

1280件から1024T/256Vになることを事前に仮定したわけではない。今回の実Fに対する結果であり、別scheduleや生成後のoutcome eligibilityを保証しない。対局結果を見たroot補充・並べ替え・label付与はない。新cache・stream・weightsには架空FileRefを作っていない。

actual InputConfig、schedule、partition、評価schedule/partition/bookの完全FileRefはcurrent resultに含む。selected assetsの親とinputsは初回にabsentを確認した。入力ファイルだけをその専用namespaceへ作成した。

## 選択済み生成設定と通常入口

4個の `generation-batch-000..003.json` は連続global slices 0/320/640/960、各320 requests。固定D(0,8 tanh)同士のcompleted D6/PVS/TT4096、attempts32、1手100M nodes、各batch共有40G/全160G、序盤込み200ply、goal-first/真正threefold、root_value_policy=outcome_onlyを使う。GOAL/true THREEFOLDだけがzSTM教師となり、UNKNOWN/censorにはzを付けず、raw Dの±2も保持する。旧raw範囲mask・refill・entered replayは導入していない。

generationは1つのprocess内に独立2 workers、cores0/2、guardian4/reserve6、child affinity [0,2,4,6]、family2GiB（controller64MiBを含む）、host reserve4GiB、GPU0である。実スレッドのpin・shared node budget・ordered journal・cancel/joinは既存native入口が担当する。affinityを未来のquiet保証としない。native config memoryはfamily-controller分を宣言する。

native output ceilingは選択済みwhole8GiBを使う。4回分の個別grantではなく、Rootがissued owned unionの全retained stagesに一つの実8GiB guardを適用する。1280完了の容量保証はしない。Root resources `51505074…` /3194Bは、保守的retained upper32,210,563,072B＋whole8GiB=40,800,497,664B、decimal50GB未満を支持する。これは測定済みglobal actualではない。

4つのcurrent Experimentとcorrespondenceは、実Root plan `2d27a84a…`、Build/image、入力、current callers/venv/system ELF、実libc CAPI versionに束縛した。数値status欄はmodel-free固定D/rules/config/inputの現correspondenceであり、新しいNNUE head/strengthのPASSではない。入力/partitionの現4 production subjectsは採用381 postimagesとbyte一致した。current Rust/Git全体一致をRUN条件にしていない。

`generation-sequence-current.draft.json` は既存finite sequenceの4 RUNs/finalizers=[]を使う。nativeが実際に保存するgeneration-result.json、stream-content.json、sources.json、schedule.json、pilot-stream.jsonl.gzを含む。common-entry venv Pythonをjob/collectorへ使う。科学entryはしていない。Rootの実origin/config、nested operation path修復、変更callerの再binding、各entryのfresh physical/quiet/canonical/environment/input/artifact guardsが通常の残作業である。

## 実collector gapと限定確認

現collect_dataはcorpus gzipを `bound` で全量RAMへ読むほか、stream-content照合でも `read_ref` で全量読む。large streamはfamily2GiBを超え得る。`corpus-stream-collector.current.patch`（1352B、SHA `c66ee3bd…`）は既存streaming `artifact_ref` を両箇所で使用し、byte/hash/mode・declared output size・sidecar identityの拒否を保持する。その他phase/codec/model/label機構は変更しない。新規NN0定義は実synthetic gzipとsidecar/censusを使い、全量boundが呼ばれないこと、byte upper超過とwrite owner逸脱のFAILEDを確認しPASSした。整形およびAST同一性確認もPASS。

最初の同定義はfixtureのgeneration_result欠落によりFAILED。元log/NULL returned guardianとdisk pending/attempted事実は保持し、直接reap/handles/TMP cleanupを区別した。fixtureに実consumerが読むcensusとsidecarを追加し、もう一つの全量read箇所も含めたowning修正後のPASSは別scopeである。成功済みの1280/eval64準備や旧381/342.16 assertionsは再演しなかった。

ownerMainのwhole unionに対して、prepare_selected_operationの現在のowner/basename(output)式はnested outputを外す。Rootが通知した通り、configured sequence outputをoperationの親にする小さい修復が必要である。authorはこのMain修復や新schedulerを実装していない。

## 後段の実データ条件

生成4streamのactual refsをglobal slice順に一つのconverterへ渡すのはRoot。outcome_only v3/seven binary91B/row、sampling `<IBB`、groups/families/splits/row_idsとchronological orderのconsumer APIは変更していない。実eligible T family rows LからTview=sum min(64,L)、Vは全eligible rows、更新数U=min(512,ceil(8Tview/1024))と実観測点を、生成/変換後にlearnerが導出する。今はeligible件数・cache・new weightsが未生成で、仮の件数を作らない。raw±2とUNKNOWN maskの意味を維持し、公開payloadや封印Vをこの入力準備で読んでいない。

publisher readerSTOP 2026-10-14T05:12:32.342185Z、canonical release05:12:32.342938Z。正確なprocess/guardian/returned-versus-disk/TMPと一回のOWN＋作成inputs usageは `completion.json` に記録する。Main/Git/Cargo/source/image/env/modelのauthor変更なし。323USERPAUSE・old fits96・seals/defaults/N、旧RAW/FAILED/費用/UNKNOWNを保持した。
