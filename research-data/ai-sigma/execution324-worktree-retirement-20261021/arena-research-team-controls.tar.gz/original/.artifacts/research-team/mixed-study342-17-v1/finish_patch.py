"""Format one temporary publisher and verify only the affected saved collector."""

import ast
import difflib
import importlib.util
import json
import os
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
OUT = OWN / "collector-check-v1"
loader = importlib.util.spec_from_file_location(
    "lc", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
original_result_ref = lc.bound(OWN / "preparation-result.json")[0]
result = lc.document(original_result_ref)
before_ref = result["collector_current_beforeimage"]
original = lc.read_ref(before_ref).decode()
old = """            if (
                experiment["phase"] == "materialize"
                and item["name"] in COMPACT_CACHE_WIDTHS
            ):
"""
new = """            if (
                experiment["phase"] == "materialize"
                and item["name"] in COMPACT_CACHE_WIDTHS
            ) or (
                experiment["phase"] == "corpus" and item["name"] == "pilot_stream"
            ):
"""
lc.require(original.count(old) == 1, "one exact collector beforeimage")
post = original.replace(old, new).replace(
    '"declared compact output size"', '"declared streamed output size"'
)
OUT.mkdir()
temporary = OUT / "temporary-publisher.py"
temporary.write_text(post)
spec = {
    "kind": "software",
    "cwd": str(MAIN),
    "env": dict(os.environ),
    "limits": {
        "family_B": 384 * 1024**2,
        "controller_B": 64 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "worker_cpu": 5,
        "guardian_cpu": 6,
        "log_B": 64 * 1024,
    },
}
resources = lc.process.CycleResources(
    {"host_ram_reserve": 4 * 1024**3, "max_memory_bytes": 320 * 1024**2},
    OUT,
    None,
)
ruff = "/home/vscode/.cache/inference/envs/quoridor-training/bin/ruff"
checks = []
try:
    for name, argv in [
        (
            "collector-format",
            [ruff, "format", "--config", str(MAIN / "pyproject.toml"), str(temporary)],
        ),
        (
            "collector-format-check",
            [
                ruff,
                "format",
                "--check",
                "--config",
                str(MAIN / "pyproject.toml"),
                str(temporary),
            ],
        ),
        (
            "collector-NN0",
            [
                str(lc.project_python()),
                "-B",
                str(OWN / "test_corpus_stream.py"),
                str(temporary),
            ],
        ),
    ]:
        lc.command(
            spec,
            {"name": name, "role": "software", "argv": argv},
            OUT,
            resources,
            ledger=checks,
        )
    formatted = temporary.read_text()
    lc.require(
        ast.dump(ast.parse(formatted), include_attributes=False)
        == ast.dump(ast.parse(post), include_attributes=False),
        "format AST unchanged",
    )
    lc.read_ref(before_ref)
    patch = "".join(
        difflib.unified_diff(
            original.splitlines(True),
            formatted.splitlines(True),
            fromfile="a/scripts/dev/research-lifecycle.py",
            tofile="b/scripts/dev/research-lifecycle.py",
        )
    )
    patch_path = OWN / "corpus-stream-collector.formatted.patch"
    patch_path.write_text(patch)
    text = lc.read_ref(checks[-1]["full_log"]).decode()
    lc.require(
        "Ran 1 test" in text and "\nOK\n" in text, "exact one new NN0 definition"
    )
    facts = {
        "source_before_after": before_ref,
        "original_preparation": original_result_ref,
        "patch": lc.bound(patch_path)[0],
        "checks": checks,
        "format_AST_exact": True,
        "test_definition": lc.bound(OWN / "test_corpus_stream.py")[0],
        "native_model_Search_game_fit_calls": 0,
        "temporary_postimage_before_removal": lc.bound(temporary)[0],
        "scope": "One new saved gzip hash/cap/ownership collector definition; no original success replay",
    }
finally:
    temporary.unlink()
facts["temporary_publisher_remaining"] = []
facts["actual_source_reader_writer_STOP"] = lc.stamp()
lc.new_json(OUT / "result.json", facts)
# Fix only the mislabeled metadata ref: loop-local config_ref named the last batch.
# The original raw CLI/captures/inputs and initial result remain immutable.
result["input_config"] = lc.bound(OWN / "global-input-settings.selected.json")[0]
result["collector_patch"] = lc.bound(patch_path)[0]
result["original_preparation_result"] = original_result_ref
result["metadata_correction"] = (
    "input_config now names actual original global InputConfig; no native/rules replay"
)
lc.new_json(OWN / "preparation-result-current.json", result)
print(
    json.dumps(
        {
            "result": lc.bound(OWN / "preparation-result-current.json")[0],
            "collector_check": lc.bound(OUT / "result.json")[0],
        }
    )
)
