"""Run the existing input-only CLI twice, then freeze selected generation metadata."""

import ctypes
import difflib
import importlib.util
import json
import os
import re
import resource
import sys
from collections import Counter
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
CHECKS = OWN / "native-input-checks-v1"
ASSET = MAIN / ".worktree/assets/data/fixed-d-sigma-mixture380-v1"
INPUTS = ASSET / "inputs"
loader = importlib.util.spec_from_file_location(
    "lc", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def reference(path):
    return lc.bound(path, 64 * 1024**2)[0]


def document(path):
    return json.loads(lc.read_ref(reference(path), 64 * 1024**2))


def write(path, value):
    with path.open("xb") as out:
        out.write((json.dumps(value, indent=2, allow_nan=False) + "\n").encode())
        out.flush()
        os.fsync(out.fileno())
    return reference(path)


def bound_json(ref):
    return {key: ref[key] for key in ("path", "sha256")}


lc.require(not INPUTS.exists() and not os.path.lexists(INPUTS), "fresh selected inputs")
lc.require(not CHECKS.exists(), "exclusive native input checks")
CHECKS.mkdir()
historical_settings = reference(
    MAIN
    / ".worktree/learning-million/.artifacts/research-team/mixed-runtime342-16-v1/settings.UNSELECTED.json"
)
lc.require(historical_settings["sha256"].startswith("e268c0f7"), "original settings")
settings = document(
    MAIN
    / ".artifacts/research-team/integration324/mixed-outcome381-v1/runtime-settings-v1/settings.UNSELECTED.json"
)
artifact = settings["generation"]["artifact"]
build_ref = settings["generation"]["build_manifest"]
lc.require(artifact["sha256"].startswith("9a63d2f3"), "selected genuine381 image")
build = lc.accepted_build(build_ref)
lc.require(build["artifact"] == artifact, "genuine immutable Build/artifact join")
lc.read_ref(artifact, artifact["bytes"])
plan374_ref = reference(
    MAIN / "research-data/ai-sigma/three-engine-comparison374/approved-plan-v5.json"
)
plan374 = json.loads(lc.read_ref(plan374_ref))
book_ref = plan374["book"]
book = json.loads(lc.read_ref(book_ref))
lc.require(book["complete"] is True and len(book["families"]) == 128, "current128 book")
lc.require(
    all(row["prefix"] for row in book["families"]), "current nonempty book roots"
)
excluded = write(
    OWN / "existing-book-exclusion.json",
    {
        "source": book_ref,
        "scope": "Actual active128 families; historical old_open8 seed inputs are not the active book",
        "openings": [
            {"id": row["id"], "prefix": row["prefix"]} for row in book["families"]
        ],
    },
)
source_binding_ref = reference(
    MAIN
    / ".worktree/arena-evaluation/.artifacts/configurable-fixed-d381-v1/source-binding-v1.json"
)
source_binding = json.loads(lc.read_ref(source_binding_ref))
needed = {
    "crates/quoridor-runner/src/teacher_pilot.rs",
    "crates/quoridor-runner/src/teacher_pilot/depth6.rs",
    "crates/quoridor-data/src/common_corpus.rs",
    "crates/quoridor-data/src/terminal.rs",
}
source_refs = []
for change in source_binding["changes"]:
    if change["target"] in needed:
        current = reference(MAIN / change["target"])
        lc.require(
            (current["sha256"], current["bytes"])
            == (change["post"]["sha256"], change["post"]["bytes"]),
            "current input preparation/partition production compatibility",
        )
        source_refs.append(current)
lc.require(len(source_refs) == len(needed), "four owning input sources")
caller_refs = [
    reference(MAIN / "scripts/dev" / name)
    for name in ("research-lifecycle.py", "research-job.py", "project-env.sh")
] + [
    reference(MAIN / "python/quoridor_training" / name)
    for name in ("cycle_process.py", "snapshot.py")
]
python_ref = reference(Path(sys.executable).resolve())
environment_ref = reference(Path(sys.prefix) / "pyvenv.cfg")
input_config = {
    "families": 1280,
    "prefix_seed": 38020261013,
    "prefix_lengths": [4, 8, 12, 16],
    "split_seed": 38020261014,
    "excluded_books": [bound_json(excluded)],
    "output": str(INPUTS),
}
config_ref = write(OWN / "global-input-settings.selected.json", input_config)
lc.require(ASSET.resolve() == ASSET, "normal owned asset path")
ASSET.mkdir(exist_ok=True)
spec = {
    "kind": "software",
    "cwd": str(MAIN),
    "env": dict(os.environ),
    "limits": {
        "family_B": 384 * 1024**2,
        "controller_B": 64 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "worker_cpu": 5,
        "guardian_cpu": 6,
        "log_B": 64 * 1024,
    },
}
resources = lc.process.CycleResources(
    {"host_ram_reserve": 4 * 1024**3, "max_memory_bytes": 320 * 1024**2},
    CHECKS,
    None,
)
checks = []
available = sorted(os.sched_getaffinity(0))


def command(name, argv):
    lc.command(
        spec,
        {"name": name, "role": "input-preparation", "argv": argv},
        CHECKS,
        resources,
        ledger=checks,
    )
    return lc.read_ref(checks[-1]["full_log"], spec["limits"]["log_B"])


def prepare(name, ref):
    raw = command(
        name,
        [
            artifact["path"],
            "teacher-pilot",
            "--prepare-inputs",
            ref["path"],
            "--input-sha256",
            ref["sha256"],
        ],
    )
    returned = json.loads(raw)
    lc.require(returned["result"]["search_calls"] == 0, "rules-only returned scope")
    return returned


started = lc.stamp()
wall_start = lc.time.monotonic()
try:
    returned = prepare("global-schedule1280", config_ref)
    schedule_ref = reference(INPUTS / "schedule.json")
    partition_ref = reference(INPUTS / "partition.json")
    schedule = document(INPUTS / "schedule.json")
    partition = document(INPUTS / "partition.json")
    slots = schedule["scheduled"]
    lc.require(len(slots) == 1280, "actual global planned denominator")
    lc.require(
        Counter(row["requested_prefix_length"] for row in slots)
        == {4: 320, 8: 320, 12: 320, 16: 320},
        "actual selected round-robin strata",
    )
    lc.require(
        all(
            row["game"] == i and row["requested_prefix_length"] == [4, 8, 12, 16][i % 4]
            for i, row in enumerate(slots)
        ),
        "actual chronological global order",
    )
    study_book_ref = write(
        OWN / "study-family-exclusion.json",
        {
            "source": schedule_ref,
            "openings": [
                {"id": row["request_id"], "prefix": row["prefix"]}
                for row in slots
                if row["prefix"] is not None
            ],
        },
    )
    eval_config = {
        "families": 64,
        "prefix_seed": 38020261018,
        "prefix_lengths": [4, 8, 12, 16],
        "split_seed": 38020261014,
        "excluded_books": [bound_json(excluded), bound_json(study_book_ref)],
        "output": str(INPUTS / "evaluation-preparation"),
    }
    eval_config_ref = write(
        OWN / "evaluation-input-settings.selected.json", eval_config
    )
    eval_return = prepare("evaluation-histories64", eval_config_ref)
    eval_schedule_ref = reference(INPUTS / "evaluation-preparation/schedule.json")
    eval_partition_ref = reference(INPUTS / "evaluation-preparation/partition.json")
    eval_slots = document(INPUTS / "evaluation-preparation/schedule.json")["scheduled"]
    eval_assignments = document(INPUTS / "evaluation-preparation/partition.json")[
        "assignments"
    ]
    lc.require(
        len(eval_slots) == 64
        and all(s["prefix"] is not None for s in eval_slots)
        and len({a["family"] for a in eval_assignments}) == 64,
        "64 actual distinct collision families; no automatic refill",
    )
    assignments = {a["game"]: a for a in eval_assignments}
    openings = []
    for row in eval_slots:
        assignment = assignments[row["request_id"]]
        openings.append(
            {
                "id": f"mixed342-17-evaluation-{row['game']:03d}",
                "cohort": "main",
                "lineage": f"preoutcome-seed38020261018/family-{assignment['family']}",
                "siblings": [],
                "original_seed": 38020261018,
                "reference": {
                    "source_sha256": eval_schedule_ref["sha256"],
                    "model_sha256": None,
                    "settings": {
                        "family_id": row["game"],
                        "collision_family": assignment["family"],
                        "root_key": row["root"]["state_key"],
                        "history_counts": row["root"]["history"],
                        "requested_prefix_length": row["requested_prefix_length"],
                        "source_request_id": row["request_id"],
                    },
                    "q_definition": None,
                    "q_perspective": None,
                    "q_aggregation": None,
                    "q": None,
                },
                "selection_reason": "Pre-outcome sorted-legal xorshift64; full LR/extension/endpoint disjoint from current128 book and study schedule; no model/Search/outcome selection",
                "candidate_pool_size": len(row["attempts"]),
                "prefix": row["prefix"],
            }
        )
    eval_book = write(
        INPUTS / "evaluation-book.json",
        {
            "id": "mixed342-17-independent-evaluation-v1",
            "usage": "main",
            "frozen_before_candidate_results": True,
            "independence": "64 distinct pre-outcome collision families under maintained LR/extension/endpoint grouping; common PRNG and initial game limit population independence claims",
            "openings": openings,
        },
    )
    # System ELF identities are ordinary runtime inputs; this does not initialize ORT.
    raw = command(
        "runtime-ELF-dependencies", ["/usr/bin/ldd", artifact["path"]]
    ).decode()
    dependencies = []
    for line in raw.splitlines():
        match = re.search(r"(?:=>\s*)?(/[^\s]+)\s+\(0x", line)
        if match:
            ref = reference(Path(match.group(1)).resolve())
            if ref not in dependencies:
                dependencies.append(ref)
    lc.require(
        dependencies and "not found" not in raw, "actual resolved ELF dependencies"
    )
    loaded_libc = ctypes.CDLL(None)
    loaded_libc.gnu_get_libc_version.restype = ctypes.c_char_p
    glibc_version = loaded_libc.gnu_get_libc_version().decode()
    dynamic_libraries = [
        {"file": ref, "version": glibc_version}
        for ref in dependencies
        if Path(ref["path"]).name == "libc.so.6"
    ]
    lc.require(len(dynamic_libraries) == 1, "loaded system libc metadata")
    config_refs = []
    for batch, start in enumerate([0, 320, 640, 960]):
        config = {
            "common_study": {
                **input_config,
                "root_value_policy": "outcome_only",
                "schedule": bound_json(schedule_ref),
                "partition": bound_json(partition_ref),
                "batch_start": start,
                "batch_count": 320,
            },
            **settings["generation"]["fixed_fields"],
            "run_id": f"mixed342-17-fixed-d6-batch-{batch:03d}",
            "output": str(ASSET / f"generation/batch-{batch:03d}"),
            "planned_games": 320,
            "prefix_seed": 38020261013,
            "cpu_core": 0,
            "game_workers": 2,
            "worker_cores": [0, 2],
            "host_ram_reserve": 4 * 1024**3,
            "max_memory_bytes": 2 * 1024**3 - 64 * 1024**2,
            "max_output_bytes": 8 * 1024**3,
        }
        # InputConfig.output belongs to preparation; never serialize it into common_study.
        config["common_study"].pop("output")
        lc.require(not Path(config["output"]).exists(), "unentered batch output")
        config_refs.append(write(OWN / f"generation-batch-{batch:03d}.json", config))
    plan_ref = write(
        OWN / "generation-plan.selected.json",
        {
            "study": "mixed-outcome",
            "issue": "quoridor-4lc.342.17",
            "selection": "INITIAL_RECIPE_SELECTED_DIRECTLY",
            "configs": config_refs,
            "schedule": schedule_ref,
            "partition": partition_ref,
            "excluded_book": excluded,
            "source_book": book_ref,
            "evaluation_book": eval_book,
            "evaluation_schedule": eval_schedule_ref,
            "generator": artifact,
            "build_manifest": build_ref,
            "total_requests": 1280,
            "batch_shared_node_cap": 40000000000,
            "whole_node_cap": 160000000000,
            "bulk_whole_bytes": 8 * 1024**3,
            "capacity_policy": "Root actual shared whole guard; partial FAILED/UNKNOWN retained; no replay/refill",
            "evaluation": {
                "families": 64,
                "colours": 2,
                "opponents": ["BEST43", "fixedD"],
                "games": 256,
                "clock_ms": 100,
                "reserve_ms": 5,
                "future_new_weights": "UNCREATED",
            },
        },
    )
    inputs = [
        schedule_ref,
        partition_ref,
        excluded,
        book_ref,
        *dependencies,
        *caller_refs,
        python_ref,
        environment_ref,
    ]
    experiments = []
    drafts = []
    for batch, config_ref in enumerate(config_refs):
        experiment = {
            "schema": lc.EXPERIMENT_SCHEMA,
            "phase": "corpus",
            "build_manifest": build_ref,
            "config": config_ref,
            "inputs": inputs,
            "models": [],
            "dynamic_libraries": dynamic_libraries,
            "schedule": schedule_ref,
            "canonical_plan_sha256": plan_ref["sha256"],
            "rules": "research-standard-2p-threefold-goal-first-v1",
            "distance_units": "wall-distance/80",
            "value_perspective": "side-to-move",
            "planned_slots": 320,
            "batch": None,
            "argv": [
                artifact["path"],
                "teacher-pilot",
                "--experiment",
                "@EXPERIMENT@",
                "--experiment-sha256",
                "@EXPERIMENT_SHA256@",
            ],
        }
        numerical = lc.numerical_fields(experiment, build)
        numerical.update(
            correspondence_only=True,
            new_model_or_head_calls=0,
            scope="Current model-free D/rules/config/input correspondence; original381 software and unchanged production scope, no new head/strength proof",
            original_evidence=[build_ref, source_binding_ref],
        )
        q_ref = write(
            OWN / f"generation-batch-{batch:03d}-correspondence.json", numerical
        )
        experiment["numerical_qualification"] = q_ref
        experiment_ref = write(
            OWN / f"generation-batch-{batch:03d}-experiment.json", experiment
        )
        experiments.append(experiment_ref)
        data_root = document(Path(config_ref["path"]))["output"]
        drafts.append(
            {
                "schema": "quoridor.research.lifecycle-intent.v1",
                "kind": "run",
                "owner": str(ASSET),
                "cwd": str(MAIN),
                "artifact": artifact,
                "experiment": experiment_ref,
                "approved_plan": plan_ref,
                "caller_sources": caller_refs,
                "child_cpu_cores": [0, 2, 4, 6],
                "limits": {
                    "family_B": 2 * 1024**3,
                    "controller_B": 64 * 1024**2,
                    "host_reserve_B": 4 * 1024**3,
                    "worker_cpu": 0,
                    "guardian_cpu": 4,
                    "owned_B": 8 * 1024**3,
                    "log_B": 256 * 1024,
                },
                "env": {
                    **os.environ,
                    "OMP_NUM_THREADS": "1",
                    "OPENBLAS_NUM_THREADS": "1",
                    "MKL_NUM_THREADS": "1",
                    "CUDA_VISIBLE_DEVICES": "",
                    "RAYON_NUM_THREADS": "1",
                },
                "data_root": data_root,
                "data": [
                    {
                        "name": "pilot_stream",
                        "path": str(Path(data_root) / "pilot-stream.jsonl.gz"),
                        "limit_B": 8 * 1024**3,
                    },
                    *[
                        {
                            "name": name,
                            "path": str(Path(data_root) / filename),
                            "limit_B": 16 * 1024**2,
                        }
                        for name, filename in [
                            ("stream_content", "stream-content.json"),
                            ("sources", "sources.json"),
                            ("schedule", "schedule.json"),
                        ]
                    ],
                ],
                "finalizers": [],
                "owned_outputs": [str(ASSET)],
            }
        )
    sequence_ref = write(
        OWN / "generation-sequence.draft.json",
        {
            "kind": "sequence",
            "owner": str(ASSET),
            "output": str(ASSET / "generation-sequence-v1"),
            "runs": drafts,
            "measurements": [],
            "arena": None,
            "ready_for_scientific_entry": False,
            "remaining_actual_launch_inputs": [
                "Root support actual whole8GiB/global50GB binding and originating outer job/config",
                "apply minimal corpus stream collector repair",
                "fresh hardware/quiet/affinity/canonical/environment guards",
            ],
            "interpreter": str(lc.project_python()),
        },
    )
    # One owning correction: do not allocate a multi-GiB saved corpus stream in RAM.
    publisher_path = MAIN / "scripts/dev/research-lifecycle.py"
    publisher_ref = reference(publisher_path)
    original = lc.read_ref(publisher_ref).decode()
    old = """            if (
                experiment["phase"] == "materialize"
                and item["name"] in COMPACT_CACHE_WIDTHS
            ):
"""
    new = """            if (
                experiment["phase"] == "materialize"
                and item["name"] in COMPACT_CACHE_WIDTHS
            ) or (
                experiment["phase"] == "corpus" and item["name"] == "pilot_stream"
            ):
"""
    lc.require(original.count(old) == 1, "one actual durable-output collector")
    post = original.replace(old, new).replace(
        '"declared compact output size"', '"declared streamed output size"'
    )
    patch = "".join(
        difflib.unified_diff(
            original.splitlines(True),
            post.splitlines(True),
            fromfile="a/scripts/dev/research-lifecycle.py",
            tofile="b/scripts/dev/research-lifecycle.py",
        )
    )
    (OWN / "corpus-stream-collector.patch").write_text(patch)
    partitions = {a["family"]: a["split"] for a in partition["assignments"]}
    lc.require(
        len(set(partitions)) * 4 // 5 == sum(s == "train" for s in partitions.values()),
        "unique-family floor4/5 split",
    )
    all_refs = [
        artifact,
        build_ref,
        book_ref,
        plan374_ref,
        historical_settings,
        source_binding_ref,
        *source_refs,
        *caller_refs,
        python_ref,
        environment_ref,
        *dependencies,
        publisher_ref,
    ]
    for ref in all_refs:
        lc.read_ref(ref, max(lc.CONTROL_BYTES, ref["bytes"]))
    lc.require(
        all(not Path(d["data_root"]).exists() for d in drafts), "no generation entered"
    )
    result = {
        "issue": "quoridor-4lc.342.17.2",
        "status": "ACTUAL_SELECTED_INPUTS_PREPARED_RUNTIME_DRAFT_STOPPED",
        "input_config": config_ref,
        "global_return": returned,
        "evaluation_input_config": eval_config_ref,
        "evaluation_return": eval_return,
        "schedule": schedule_ref,
        "partition": partition_ref,
        "evaluation_book": eval_book,
        "evaluation_schedule": eval_schedule_ref,
        "evaluation_partition": eval_partition_ref,
        "actual_counts": {
            "requests": len(slots),
            "accepted_prefixes": sum(s["prefix"] is not None for s in slots),
            "failed_prefixes": sum(s["prefix"] is None for s in slots),
            "unique_families": len(partitions),
            "family_splits": dict(Counter(partitions.values())),
            "request_splits": dict(
                Counter(a["split"] for a in partition["assignments"])
            ),
            "evaluation_histories": len(eval_slots),
            "evaluation_collision_families": len(
                set(a["family"] for a in eval_assignments)
            ),
        },
        "config_refs": config_refs,
        "experiments": experiments,
        "selected_plan": plan_ref,
        "sequence_draft": sequence_ref,
        "collector_patch": reference(OWN / "corpus-stream-collector.patch"),
        "collector_current_beforeimage": publisher_ref,
        "ELF_dependencies": dependencies,
        "loaded_glibc_version": glibc_version,
        "dynamic_libraries": dynamic_libraries,
        "current_refs_before_after": all_refs,
        "checks": checks,
        "old_UNSELECTED_settings_immutable": historical_settings,
        "source_compatibility": "Four current owning input/partition production subjects byte-exact to adopted381",
        "rules_only_native_prepare_calls": 2,
        "Search_model_game_fit_build_calls": 0,
        "future_outputs": {
            "generation": "UNCREATED",
            "compact": "UNCREATED",
            "new_weights": "UNCREATED",
            "evaluation_games": "UNENTERED",
        },
        "max_output_bytes_semantics": "Each batch maximum ceiling uses selected whole8GiB; Root must enforce one shared actual whole across retained batches/other stages; not four grants",
        "runtime_gap": "support/origin/current collector repair at Root; no None or readyfalse submitted",
        "started_at": started,
        "controller_seconds_once": lc.time.monotonic() - wall_start,
        "actual_source_input_caller_library_reader_STOP": lc.stamp(),
        "storage_budget": None,
    }
    write(OWN / "preparation-result.json", result)
    print(
        json.dumps(
            {
                "result": reference(OWN / "preparation-result.json"),
                "actual_counts": result["actual_counts"],
            }
        )
    )
finally:
    os.sched_setaffinity(0, available)
