"""Prepare only an NNUE patch; format temporary subjects through the normal guard."""

import difflib
import hashlib
import importlib.util
import json
import os
import resource
import shutil
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
OUT = OWN / "patch-preparation-v2"
loader = importlib.util.spec_from_file_location(
    "lc", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
refs = lc.document(lc.bound(OWN / "source-input-refs.json")[0])
paths = [
    "crates/quoridor-nnue/src/lib.rs",
    "crates/quoridor-nnue/src/features.rs",
    "crates/quoridor-nnue/src/residual.rs",
    "crates/quoridor-nnue/Cargo.toml",
]
before = {p: lc.read_ref(refs[p]) for p in paths}
original = before[paths[0]].decode()
start = original.index("    pub fn delta_move_into(")
end = original.index("    fn update_columns", start)
body = original[start:end]
anchor = "        if features::matches_position(&parent.features, before) {"
block = """        // A pooled destination can retain immutable geometry from the preceding
        // child at this ply. Keep the matching parent-map path preferred.
        let previous_maps = parent
            .maps
            .as_ref()
            .filter(|maps| maps.distances_for(after).is_some())
            .or(child.maps.as_ref());
"""
lc.require(body.count(anchor) == 1, "unique validated move branch")
lc.require(body.count("parent.maps.as_ref()") == 2, "only two geometry consumers")
changed = body.replace("parent.maps.as_ref()", "previous_maps")
changed = changed.replace(anchor, block + anchor)
declaration = '#[cfg(all(test, feature = "research"))]\nmod map_reuse_tests;\n'
post = original[:start] + changed + original[end:]
post += "\n" + declaration
draft = (OWN / "map_reuse_tests.pending.txt").read_text()
old = "    invalid.features.ids[0].insert(0, invalid.features.ids[0][0]);"
lc.require(draft.count(old) == 1, "unique draft borrow correction")
draft = draft.replace(
    old,
    "    let duplicate = invalid.features.ids[0][0];\n"
    "    invalid.features.ids[0].insert(0, duplicate);",
)
lc.require(not OUT.exists(), "exclusive patch preparation")
OUT.mkdir()
temporary = OUT / "temporary-subjects"
temporary.mkdir()
lib = temporary / "lib.rs"
test = temporary / "map_reuse_tests.rs"
lib.write_text(post)
test.write_text(draft)
rustfmt = shutil.which("rustfmt")
lc.require(rustfmt is not None, "normal Rustfmt executable")
tool = lc.bound(Path(rustfmt).resolve(), 128 * 1024**2)[0]
settings = {
    "kind": "software",
    "cwd": str(MAIN),
    "env": dict(os.environ),
    "limits": {
        "family_B": 384 * 1024**2,
        "controller_B": 64 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "worker_cpu": 1,
        "guardian_cpu": 4,
        "log_B": 64 * 1024,
    },
}
resources = lc.process.CycleResources(
    {"host_ram_reserve": 4 * 1024**3, "max_memory_bytes": 320 * 1024**2},
    OUT,
    None,
)
checks = []
temporary_refs = []
try:
    for name, extra in [("rustfmt", []), ("rustfmt-check", ["--check"])]:
        lc.command(
            settings,
            {
                "name": name,
                "role": "software",
                "argv": [
                    rustfmt,
                    "--edition",
                    "2024",
                    "--config",
                    "skip_children=true",
                    *extra,
                    str(lib),
                    str(test),
                ],
            },
            OUT,
            resources,
            ledger=checks,
        )
    formatted = lib.read_text()
    inverse = formatted.removesuffix("\n" + declaration).replace(block, "", 1)
    inverse_start = inverse.index("    pub fn delta_move_into(")
    inverse_end = inverse.index("    fn update_columns", inverse_start)
    restored_body = inverse[inverse_start:inverse_end].replace(
        "previous_maps", "parent.maps.as_ref()"
    )
    inverse = inverse[:inverse_start] + restored_body + inverse[inverse_end:]
    lc.require(inverse.encode() == before[paths[0]], "full byte inverse exact")
    for p in paths:
        lc.require(lc.read_ref(refs[p]) == before[p], "Main NNUE before/after exact")
    lc.read_ref(tool, tool["bytes"])
    formatted_test = test.read_text()
    patch = "".join(
        difflib.unified_diff(
            original.splitlines(keepends=True),
            formatted.splitlines(keepends=True),
            fromfile="a/" + paths[0],
            tofile="b/" + paths[0],
        )
    ) + "".join(
        difflib.unified_diff(
            [],
            formatted_test.splitlines(keepends=True),
            fromfile="/dev/null",
            tofile="b/crates/quoridor-nnue/src/map_reuse_tests.rs",
        )
    )
    (OWN / "nnue-map-reuse.patch").write_text(patch)
    (OWN / "map_reuse_tests.rs").write_text(formatted_test)
    temporary_refs = [lc.bound(p)[0] for p in (lib, test)]
    result = {
        "issue": "quoridor-4lc.387.1",
        "Main_before_after": [refs[p] for p in paths],
        "temporary_formatted_subjects_removed_at_STOP": temporary_refs,
        "patch": lc.bound(OWN / "nnue-map-reuse.patch")[0],
        "new_test_preparation": lc.bound(OWN / "map_reuse_tests.rs")[0],
        "production_postimage_sha256": hashlib.sha256(formatted.encode()).hexdigest(),
        "production_postimage_bytes": len(formatted.encode()),
        "full_byte_inverse_exact": True,
        "formatter": tool,
        "formatter_checks": checks,
        "native_type_compile_assertions": "UNBUILT/UNTYPED/UNRUN",
        "model_payload_forward_Search_perf_game_calls": 0,
        "storage_budget": None,
    }
finally:
    # These two exact private subjects were created here; retain logs on failure.
    lib.unlink()
    test.unlink()
    temporary.rmdir()
result["temporary_subjects_remaining"] = []
result["actual_source_writer_STOP"] = lc.stamp()
lc.new_json(OUT / "result.json", result)
print(json.dumps({"result": lc.bound(OUT / "result.json")[0]}))
