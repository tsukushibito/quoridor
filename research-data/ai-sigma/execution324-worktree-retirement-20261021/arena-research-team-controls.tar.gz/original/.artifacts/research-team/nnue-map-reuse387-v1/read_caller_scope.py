"""Bind the current caller while retaining only the actual child/PVS scope."""

import importlib.util
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
loader = importlib.util.spec_from_file_location(
    "lc", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
path = MAIN / "crates/quoridor-ai/src/alphabeta.rs"
binding, data = lc.bound(path)
text = data.decode()
start = text.index("    fn child(\n")
end = text.index("    fn negamax(\n", start)
child = text[start:end]
lc.require("self.child_buffers[ply].take()" in child, "actual child slot take")
lc.require("self.child_buffers[ply] = a;" in child, "actual child slot return")
lc.require("c.unmake_move(undo)" in child, "actual canonical undo")
lc.require("advance_move_context" in child, "actual maintained NNUE callback")
root_start = text.index("    fn root_depth(")
root_end = text.index("\n    fn ", root_start + 10)
scopes = {"child": child}
for name, body in [
    ("negamax", text[end:root_start]),
    ("root_depth", text[root_start:root_end]),
]:
    lines = body.splitlines(keepends=True)
    found = []
    for i, line in enumerate(lines):
        if "pvs_researches += 1" in line:
            found.append("".join(lines[max(0, i - 7) : i + 4]))
    lc.require(len(found) == 1, "one actual PVS repeat per selected function")
    scopes[name + "_PVS_repeat"] = found[0]
setup = [line for line in text.splitlines() if "child_buffers =" in line]
lc.require(len(setup) == 1, "one child-buffer allocation")
lc.read_ref(binding)
result = {
    "actual_current_caller_before_after": binding,
    "initial_caller_ref_retained_historical": True,
    "scope": scopes,
    "child_storage_allocation": setup,
    "native_Search_model_calls": 0,
}
lc.new_json(OWN / "current-caller-scope.json", result)
print(json.dumps(result, ensure_ascii=False))
