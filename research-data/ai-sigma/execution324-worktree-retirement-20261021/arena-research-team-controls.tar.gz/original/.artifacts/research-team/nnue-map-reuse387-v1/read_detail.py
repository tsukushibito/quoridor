"""Read only the remaining current source guarantees needed for the narrow patch."""

import importlib.util
from pathlib import Path
import resource

resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
loader = importlib.util.spec_from_file_location(
    "lc", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
refs = lc.document(lc.bound(OUT / "source-input-refs.json")[0])
for rel, ranges in {
    "crates/quoridor-nnue/src/lib.rs": [(1, 46), (300, 339), (382, 480), (637, 714)],
    "crates/quoridor-nnue/tests/move_buffer.rs": [(148, 218)],
}.items():
    data = lc.read_ref(refs[rel])
    lines = data.decode().splitlines()
    for first, last in ranges:
        print(rel, first, last)
        for i in range(first - 1, min(last, len(lines))):
            print(f"{i + 1}: {lines[i]}")
