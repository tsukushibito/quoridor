"""Finite current Main source intake; no native/model calls or source mirror."""

import importlib.util
from pathlib import Path
import json
import resource

resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
l = importlib.util.spec_from_file_location(
    "lc", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(l)
l.loader.exec_module(lc)
subjects = {
    "crates/quoridor-nnue/src/lib.rs": [(170, 225), (340, 385), (700, 780)],
    "crates/quoridor-nnue/src/features.rs": [(146, 245)],
    "crates/quoridor-nnue/src/residual.rs": [(215, 260)],
    "crates/quoridor-ai/src/alphabeta.rs": [
        (270, 315),
        (1205, 1227),
        (1280, 1340),
        (1410, 1465),
        (1890, 1910),
    ],
    "crates/quoridor-nnue/tests/move_buffer.rs": [(1, 240)],
    "crates/quoridor-nnue/Cargo.toml": [(1, 60)],
}
refs = {}
for path, ranges in subjects.items():
    r, data = lc.bound(MAIN / path, 1024 * 1024)
    refs[path] = r
    lines = data.decode().splitlines()
    print("SUBJECT", path, json.dumps(r))
    for first, last in ranges:
        print(f"LINES {first}-{last}")
        for i in range(first - 1, min(last, len(lines))):
            print(f"{i + 1}: {lines[i]}")
lc.new_json(OUT / "source-input-refs.json", refs)
