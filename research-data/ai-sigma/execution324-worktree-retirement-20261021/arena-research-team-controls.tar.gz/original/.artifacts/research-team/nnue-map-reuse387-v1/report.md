# 387：既存子バッファの壁マップ再利用候補

Main NNUEに対する小さい可逆差分を準備した。対象は `Model::delta_move_into` の壁マップ候補選択だけであり、現在のMainは未変更。整形・静的な全byte逆差分確認は完了した。新規5定義の型検査・コンパイル・native実行は **UNBUILT / UNTYPED / UNRUN**。改善率・実際のhit頻度・数値比較・採用は未確認である。

正本は同じディレクトリの `nnue-map-reuse.patch`、`patch-preparation-v2/result.json`、実行の `patch-guard-v2/receipt.json`。前後のNNUE参照と、削除済みの整形用一時postimageのSHA/sizeを結果に記録した。元の `lib.rs` は SHA256 `66f9ac049594390f9f457e3ea3076d77d0106d96f36b4ff81c3c4ee43809afa0` / 26225B、予定postimageは `b53d0f70cc92fa9c61743c4bdd632cc8698ab0c3713cafa6ab6cb48fd485552a` / 26606B。差分はproductionの7行追加・2箇所の引数変更と、test専用module宣言・新規testファイルである。

## 所有と実際の再訪経路

現在のcallerは `current-caller-scope.json` に限定した関数本文・before/after参照を保存した。`alphabeta.rs` の現SHAは `3ff34c5c24edb665b9dca364ec381eabb61fe122c80ce8b3dfa991bb5f21001d` / 121811B。最初の `c61c6c…` whole-file参照は歴史的参照のまま保持し、現在版に置換していない。386のTT-first negamax変更と今回のNNUE候補は別の変更である。

`Search::child` → `ResidualEvaluator::advance_move_context` → `ResidualModel::delta_move_into` → `Model::delta_move_into` → `features::move_features_into` / `maps_for` が実経路である。Residual側はbaseへの委譲であり、今回変更しない。

子storageは探索開始時に `max_depth + 1` 個用意される。childは `get_mut(ply).and_then(Option::take)` でそのplyのstorageをローカルへ取り出す。active childと深いplyの再帰storageは別である。成功・評価error・budget/cancel errorを受けたclosureの終了後にも、pooledなstorageを同じplyへ戻す。一般PVSではnull window後の必要なfull window再探索が同じaction・同じ `ply + 1` を再使用し、root PVSでも同じaction・ply1を再使用する。したがって前回の目的壁配置がprivate mapとして残る具体的な経路がある。ただし全PVS再探索が壁手またはmap hitであるとは限らない。

controlはmake前とadvance後にも存在する。終局goal/threefoldではFT/head更新を迂回する。closure後にpathをpopしcanonical unmake、parentのboard/contextを戻す。canonical undo失敗では数値authorityのcontext/boardをclearしてerrorを返し、復元成功とは記録しない。このcallerの処理は差分外である。途中の失敗childを評価する許可は追加しない。

## コピーと検証の境界

| 対象 | 現在の意味と保持する処理 |
|---|---|
| parent FT値 | childへ両playerの値を正確にコピーしてから、元の順序でcolumn除去・追加する。親を直接変更せず、逆算undoの丸めを避けるための必要なコピー。 |
| feature IDs | canonical pathは親IDsをcloneしてchecked moveのdeltaを適用する。general pathは子のfull encodingとmembership比較を保持する。削除・追加順序とIDコピーは変更しない。 |
| public features / FT / model | mutableなIDs・distance・side、幅・有限性・fingerprintを既存境界で検証する。private mapの一致からこれらを正しいと推論しない。 |
| private wall map | immutable `Arc<WallMaps>` のH/Vマスクと整数距離だけ。pawn位置・turn・stock・履歴・モデルとは別。親または既存子のmapを借り、既存 `maps_for` が完全なH/V一致を再確認してArc clone、そうでなければ通常のBFSを作る。 |
| parent/child入口 | parentのfingerprint・幅・有限FT・feature bounds/order/side/distance → child幅/ID capacity → checked transitionの順序を保持する。leaf/model/headの既存検証とpublic APIも差分外。 |
| 部分失敗 | childは上書き途中の値を持ち得る。private mapが正しいままでもFTやfingerprintの正常性は保証しない。次の成功上書き前に評価してはいけない。 |

## 差分の条件

checked transitionの `after` に対して親mapが一致する場合は、従来の親mapを優先する。親が一致しない場合だけ既存子mapを候補にする。候補のH/Vが不一致・mapがない場合は既存 `maps_for` が通常どおり構築する。canonical/generalの両経路へ同じ候補を渡す。新しいcache owner、永続cache、validity証明、skip-validation API、別deltaやcodecを作らない。

旧経路で親H/Vが不一致かつ子H/Vが目的位置に一致する場合に、BFS構築1回をArc cloneへ置き換えるというコード上の差がある。親mapの一致確認を追加するため、hitが少ない場合の純利益は不明。既存pawn-map共有を新規の削減と数えない。384 Controlのhistorical profile share（map10.68、delta5.25、validation3.15、head11.03）を現在の386後rankや速度見込みとして使わない。`PVS_researches` はmap一致数ではなく、追加計測や数値比較は実行していない。

## 新規定義と実際の検証

`map_reuse_tests.rs` の5定義はtoy weightsだけを使うRoot実行用の準備であり、author側では実行していない。

| 新規定義 | 区別する事実 |
|---|---|
| wall_retry_keeps_destination_map_and_parent_bits | 同じwallをmake/unmakeして再訪。Scalar/Simdで子mapのArc同一性、元のdeltaとのFT bits/features、整数距離、親bits・history復元。 |
| wall_identity_miss_and_matching_parent_preference | 別のH/Vでは古い子mapを拒否。親と子の両方が一致するpawn手では親Arcを優先。 |
| public_parent_and_child_shape_model_and_transition_guards_are_unchanged | 不正IDs、非有限parent、別model、異なるchecked context、子幅・capacity不一致の拒否と親/子の保持。 |
| general_features_keep_delta_meaning_with_retained_destination_map | canonicalでないが有効なpublic parent featuresでもgeneral deltaの意味・FT bitsを保持し、mapだけを再利用。 |
| numeric_failure_then_success_reuses_only_geometry_and_restores_parent | finite toy weightsからのFT overflowを実errorとして扱う。失敗childを評価せずcontextをundoし、正常model/parentによる成功上書きで値・features・model/modeを復元。private geometryはモデルから独立。 |

Rustfmt edition2024と `--check` はactual guardian/directwait/full captureでPASS。それぞれstdout/stderrは0B、returned mask restoration/persist/handles/cleanup完了。全byte逆差分は旧Main `lib.rs` と一致し、features/residual/Cargoもbefore/after一致した。Ruffは新しいOWN helperの範囲だけ整形・lint済み。Rustfmtはsyntax/format処理でありRust型検査ではない。

準備上の失敗は別記録として保持する。detail読取の旧guardはpeer529910を見てlease/child/TMP前に拒否した。patch-v1はRustfmt proxyのFileRefが通常control上限を超えて拒否し、Rustfmt自体は未実行だった。original returned guardianはNULL、disk receiptのdirectreap/cleanupとfresh exact child不在を区別し、当該2個の一時subjectだけ別cleanup記録で回収した。上限のみ通常実行ファイルの128MiB読取へ直したv2で未実行の整形を完了した。caller-v1のOWN読取helperは実装を `[ply].take()` と書き方まで仮定して拒否したため、元失敗を保持し、実際の `get_mut(ply).and_then(Option::take)` 本文をv2で記録した。これらをnative test/model failureまたはPASSに読み替えない。初回OWN readerのRuff E741警告も元記録のまま保持する。

## Rootへの次の小さい入力

固定patchを対象に、既存related reviewerへ一度だけ質問する：private H/V geometryの一致で目的子のmapを借りても、親優先・一般feature意味・model/error/部分上書き・undoの既存境界を壊さないか。caller/数学全体の再調査を求めない。次いでRootのsole writerで5新定義を型検査・実行し、必要な影響範囲のlint/通常incremental buildとimmutable artifactを一つ作る。古い成功suite/モデル/head/実ゲームの再演は不要。

実測387は **NOT_AUTHORIZED**。実際の386解析とcurrent baselineが揃った後、Policyへ最小候補を提示する。候補は既存same-semantics固定Control設定を使うO-N-N-O（6既存roots × 4passes = 24calls、12sessions、各3M上限ならwhole72M）で、Oは実際に確定した386 image、Nは将来Rootが作る387 imageとする。これは比較案であり、NのSHA/ready admission・baseline値・計測開始・時間見積もりを作らない。ソフトウェアは5小さいtoy定義と通常affected build、数値比較は別の有限24callsがwhole cost。CPU/RAM/host/fairness/取消とimage寿命の成立は真のlaunch境界で必要であり、実時間・compiler/RAM peak・速度利益はUNKNOWN。hit条件のコード上の差だけで実測を選ばないという選択肢もある。

実際のreader/writer/process/TMP/lease STOPとOWN usageは `completion.json` に参照付きで記録する。Main/Git/index/target/private/models/環境はauthor未変更。323 USERPAUSE、旧FAILED/RAW/費用/masks/UNKNOWN、fits96、モデル/default/N/sealsを保持する。387 leafはRootの固定source受入れまで未closeとする。
