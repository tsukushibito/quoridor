"""Present the completed saved analysis; never open an original game archive."""

import hashlib
import json
from pathlib import Path

OWN = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


before = ref(OWN / "result.json")
r = json.loads((OWN / "result.json").read_text())
methods = r["methods"]
checks = []


def check(name, condition):
    if not condition:
        raise ValueError(name)
    checks.append({"name": name, "pass": True})


check("four contrasts / eight methods", len(r["contrasts"]) == 4 and len(methods) == 8)
check("128 unique saved games", len(r["games"]) == 128)
total = sum(m["counts"]["observations"] for m in methods.values())
check("6567 accepted observations", total == 6567)
families = [f["family_id"] for f in r["contrasts"][0]["family_scores"]]
check("16 distinct shared families", len(set(families)) == 16)
for c in r["contrasts"]:
    check(f"batch{c['batch']} WDL census", sum(c["WDL_A"].values()) == 32)
    fs = c["family_scores"]
    check(f"batch{c['batch']} family order", [f["family_id"] for f in fs] == families)
    check(
        f"batch{c['batch']} two-colour family and score identity",
        all(
            len(f["A_scores"]) == 2 and sum(f["A_scores"]) / 2 == f["score"] for f in fs
        )
        and sum(f["score"] for f in fs) / 16 == c["mean_A_score"]
        and (c["WDL_A"].get("W", 0) + c["WDL_A"].get("D", 0) / 2) / 32
        == c["mean_A_score"],
    )
    check(
        f"batch{c['batch']} complete pair census",
        c["native_census"]["complete_pairs"] == 16
        and c["native_census"]["unknown_games"] == 0,
    )

for key, m in methods.items():
    d = m["selected_completed_depth"]
    n = m["counts"]["observations"]
    check(
        key + " depth histogram",
        sum(d["histogram"].values()) == d["n"] == n
        and sum(int(k) * v for k, v in d["histogram"].items()) / n == d["mean"],
    )
    check(key + " accepted completed exposure", m["counts"]["accepted"] == n)
    check(
        key + " colours / TT actual slots / retained gauge",
        all(x["game_exposures"] == 16 for x in m["by_color"].values())
        and m["gauges"]["effective_tt_slots"] == [1048576]
        and m["gauges"]["retained_bytes_peak"] == [83886128],
    )
    check(
        key + " authority / drain",
        m["counts"]["receipt_late_or_equal"] == 0
        and m["counts"]["matching_terminal_collected_true"] == n
        and m["counts"]["inflight_zero"] == n,
    )
    check(
        key + " terminal/profile nested identity",
        m["persistent_profile_sums"]["search_invocations"] == n
        and m["LMR_views"]["terminal"]["attempts"]
        == m["persistent_profile_sums"]["lmr_attempts"],
    )

lines = [
    "# 固定1手LMRと深さ・順位LMR：原128局の保存解析",
    "",
    "A=fixed_one、B=depth_rank。4本の元manifestはすべてPASSで、128局が一意に対応し、64色ペアが完成した。127局goal、1局native draw、UNKNOWN・未回収・不完全ペアは0。新しい探索・対局・bootstrapは実行していない。",
    "",
    "## 勝敗と条件付き幅",
    "",
    "以下はA側。区間は元native publicationのfamily-pair bootstrap 95%を引用した。各対照は同じ16開幕familyを共有し、128局を独立128標本とは扱わない。条件付きの探索的結果で、Elo・非劣性・母集団優越・既定昇格の認定ではない。",
    "",
    "|評価器 / ordering|A勝|分|A敗|A score|保存95%区間|",
    "|---|---:|---:|---:|---:|---|",
]
for c in r["contrasts"]:
    w = c["WDL_A"]
    ci = c["native_interval"]["percentile_95"]
    lines.append(
        f"|{c['evaluator']} / {c['profile']}|{w.get('W', 0)}|{w.get('D', 0)}|{w.get('L', 0)}|{c['mean_A_score']:.6f}|[{ci[0]}, {ci[1]}]|"
    )
lines += [
    "",
    "Bの点推定が4対照すべてで上回った。固定D Controlの保存区間はA=0.5を含まないが、16固定family・共有family・多重対照という範囲を超える確証にはしない。最終的な採否はRootと既存関連確認に委ねる。",
    "",
    "|family|NNUE Control|NNUE Cheap|D Control|D Cheap|",
    "|---:|---:|---:|---:|---:|",
]
for i, family in enumerate(families):
    lines.append(
        "|"
        + "|".join(
            [str(family)]
            + [str(c["family_scores"][i]["score"]) for c in r["contrasts"]]
        )
        + "|"
    )
lines += [
    "",
    "各値は二色のA score平均。個々の二色結果・global/local index・batch・family・色・元journal参照はresult.jsonに保存した。prefix長4/8/12/16各4familyで、各対照の事前選択と同じである。",
    "",
    "## accepted completed snapshotの深さ",
    "",
    "6567 accepted observationsだけを集計した。両方式ともLMR ONの選択的な名目深さであり、全幅完了の証明ではない。中央値を主表示する。",
    "",
    "|評価器 / ordering / method|n|中央値|平均|p95|深さ64件数|",
    "|---|---:|---:|---:|---:|---:|",
]
for key, m in methods.items():
    d = m["selected_completed_depth"]
    lines.append(
        f"|{key}|{d['n']}|{d['median']:g}|{d['mean']:.3f}|{d['p95']}|{m['counts']['selected_depth64']}|"
    )
lines += [
    "",
    "中央値はBが一律に深くなっていない。全histogramはresult.jsonにある。平均には深い尾部が寄与し、対局軌跡・手数・終盤構成が異なるため、深さの差を勝因や演算単体費へ変換しない。保存parent traitsは全件欠け、実際の壁在庫・盤面終盤比はUNKNOWN。代わりに各棋譜の最後20plyを時系列proxyとして分離した（終盤の幾何判定ではない）。",
    "",
    "|method|最後20ply proxy n / 深さ中央値|それ以前 n / 深さ中央値|",
    "|---|---|---|",
]
for key, m in methods.items():
    a, b = m["final20_recorded_plies_proxy"], m["earlier_recorded_plies"]
    lines.append(f"|{key}|{a['n']} / {a['median']:g}|{b['n']} / {b['median']:g}|")
lines += [
    "",
    "## work・時計・永続TT",
    "",
    "各行の分母は上表のn回のaccepted要求。selectedは採用済みcompleted snapshot、terminalは同じ要求の終了時累積値である。selectedはterminalに内包され、合算しない。TT profileにも同じworkが現れるため二重加算しない。",
    "",
    "|method|selected nodes|terminal nodes|terminal static eval|terminal delta|terminal PVS再探索|",
    "|---|---:|---:|---:|---:|---:|",
]
for key, m in methods.items():
    s, t = m["work_views"]["selected"], m["work_views"]["terminal"]
    lines.append(
        f"|{key}|{s['nodes']}|{t['nodes']}|{t['static_evaluations']}|{t['delta_updates']}|{t['pvs_researches']}|"
    )
lines += [
    "",
    "|method|terminal LMR試行|通常深さ確認|full-window再探索|記録worker invocation秒|caller中央値ms|receipt余裕中央値ms|drain中央値ms|",
    "|---|---:|---:|---:|---:|---:|---:|---:|",
]
for key, m in methods.items():
    lmr, c, p = m["LMR_views"]["terminal"], m["clocks"], m["persistent_profile_sums"]
    lines.append(
        f"|{key}|{lmr['attempts']}|{lmr['full_depth_confirmations']}|{lmr['full_window_researches']}|{p['search_invocation_seconds']:.6f}|{c['caller_seconds']['median'] * 1000:.3f}|{c['receipt_slack_ms']['median']:.3f}|{c['receipt_to_terminal_drain_ms']['median']:.3f}|"
    )
late_return = sum(m["counts"]["return_after_deadline"] for m in methods.values())
late_commit = sum(m["counts"]["commit_after_deadline"] for m in methods.values())
lines += [
    "",
    f"全6567件のauthority receiptはdeadlineより前（同時・超過0）。一方、terminal returnがdeadline後{late_return}件、commitが後{late_commit}件ある。100msはaction receipt authorityであり、全process returnが100ms以内という主張ではない。全件matching terminal回収・inflight0・合法採用を既存consumerで検証した。5ms reserve停止はuser cancelと別で、internal cancellationやinternal_time_limitを対局エラーへ昇格しない。",
    "",
    "|method|元stop reason / 件数|TT profile cancellations|",
    "|---|---|---:|",
]
for key, m in methods.items():
    lines.append(
        f"|{key}|{json.dumps(m['stops'], ensure_ascii=False)}|{m['persistent_profile_sums']['cancellations']}|"
    )
lines += [
    "",
    "fallback・engine error・control error・completed snapshot validation failure・forfeitは保存検査scopeで0。唯一のdrawをmaxply/error由来と推測していない。元GAME statusをそのまま使った。各methodは32局exposure、各色16局。全色のactual requested/effective TTは1048576、persistent TT retained/capは各83886128B、二色167772256B。これは永続gaugeで、要求回数や局数で合算しない。main/authority core4、A worker core2・B worker core6、別TIDおよびdrain対応を保存値で検証した。将来のquiet/physicalを保証するものではない。",
    "",
    "native reported peak RSSは4operationで206663680 / 206622720 / 209346560 / 209784832B（元process報告scope）。continuous family RSS peakはUNKNOWN。記録worker invocation秒はその名前付きspanだけで、全process Search CPU時間ではない。physical NN forward、leaf数、LMR/static評価の孤立費はUNKNOWN。general nn_calls=0とnull physical counterをforward0へ変換しない。その他全記録work・TT・時計の分母はresult.jsonにある。",
    "",
    "## 実設定と証拠",
    "",
    "同じ真正image bb63fc17、Build e934c534、source0abbb3c7。NNUE BEST43と固定D(0,8tanh)、Control/Cheap、近似OFF、TT1048576、PVS、100ms receipt/5ms reserve、node safety1M・depth64・200plyを使用した。actual requested method・effective method・reduction ruleとnative namespaceを各observation/TT profileで照合し、namespace文字列から設定を逆生成していない。",
    "",
    "- A: `lmr400-late4-depth3-minus1-pvs-verify-v1`。内部残depth>=3・distinct rank>=4でextra1。",
    "- B: `lmr408-depth-rank-log63-extra0to3-pvs-verify-v1`。lnの引数を63でclampし、extraを0..min(3,d-2)にする固定表。TT/goal/killer保護と通常深さ確認/PVSは元software/関連確認の資格を引用し、再ソース監査していない。",
    "",
    "元pre-game arena128-v1はforecast49057749Bが32MiBを超えて拒否され、Search/対局0、FAILEDのまま。Rootが上限64MiBとfresh pathsだけを修復し、今回の未入場128局を一度実施した。元失敗・returned NULLとpersisted masks・費を保持し、再finalizeや旧400/402結果の混入はない。元arena outer670.089668092秒と各native spanはnestedであり合算しない。cost96の生データは再読していない。",
    "",
    "settings・plan・schedule・config・4 manifests/publications/archivesをhash-size-modeでparse前/読取後に照合。immutable Gitの実caller bytesと一致する既存arena_reference_report/arena_observationを使用した。詳細はselected-refs.json、intake-refs.json、reader-source-refs.json、validation.json。本文の深さ・score集計はその保存結果のみから作成した。",
    "",
    "helperの初回短縮Git名解決失敗（exit128）と、管理用一時ready JSONのEXDEV移動失敗を原receiptに保持。後者は当該所有一時ファイルだけを削除済み。後続は完全immutable Gitと実caller SHA一致を確認して進めた。科学実行・元データ変更・成功suite再演はいずれも0。",
    "",
    "結果はこの16family/二色/固定条件でB側の点推定が良かったことと、受理・完了・深さ・workの観測である。一般棋力、勝因、A/Bの孤立演算速度、既定昇格は未確立。追加call・追試・tuningは発行していない。actual saved reader/child/TMP/lease STOPと対象使用量はcompletion.jsonとSTOP.jsonを参照。Main/Beads/backup/closeは324に委ねる。",
]
check("presentation read leaves analysis unchanged", before == ref(OWN / "result.json"))
(OWN / "report.md").write_text("\n".join(lines) + "\n")
(OWN / "validation.json").write_text(
    json.dumps(
        {
            "result": before,
            "checks": checks,
            "new_raw_decode": False,
            "new_bootstrap": False,
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "checks": len(checks),
            "total_accepted": total,
            "late_terminal_return": late_return,
            "late_commit": late_commit,
            "report": ref(OWN / "report.md"),
        }
    )
)
