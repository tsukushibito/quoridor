import hashlib
import json
from pathlib import Path

own = Path(__file__).resolve().parent
base = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-adaptive408-v1/arena128-unentered-v1"
)
seq = json.loads(
    Path(
        "/workspaces/quoridor/.worktree/assets/perf/lmr-adaptive408-arena128-unentered-v1/execution-v1/result.json"
    ).read_bytes()
)
refs = []
for op in seq["operations"]:
    expected = op["manifest"]
    path = Path(expected["path"])
    body = path.read_bytes()
    actual = dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )
    assert actual == expected
    refs.append(actual)
    manifest = json.loads(body)
    print(
        "MANIFEST",
        op["index"],
        json.dumps(manifest, indent=2) if op["index"] == 0 else list(manifest),
    )
print("REPAIR", (base / "ordinary-output-repair.json").read_text()[:5000])
source = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/shared-signed-ordering402-analysis-v1/analyze.py"
)
if source.exists():
    text = source.read_text()
    print(
        "PREVIOUS_HELPER_DEFINITIONS",
        [line for line in text.splitlines() if line.startswith("def ")],
    )
    print("HELPER_START", text[:5000])
(own / "manifest-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
