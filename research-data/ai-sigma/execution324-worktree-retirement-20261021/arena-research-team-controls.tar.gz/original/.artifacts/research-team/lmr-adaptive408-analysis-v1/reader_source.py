"""Named immutable bytes of the actual saved consumer, no mutable Main import."""

import gzip
import hashlib
import json
import subprocess
from pathlib import Path

own = Path(__file__).resolve().parent
base = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-adaptive408-v1/arena128-unentered-v1"
)
settings = json.loads((base / "settings.json").read_bytes())
refs = settings["arena"]["template"]["caller_sources"]
commit = subprocess.run(
    ["git", "rev-parse", "HEAD"], check=True, capture_output=True, text=True
).stdout.strip()
origins = []
for name in [
    "scripts/dev/research-lifecycle.py",
    "python/quoridor_training/cycle_process.py",
    "python/quoridor_training/snapshot.py",
]:
    expected = next(
        item for item in refs if item["path"] == "/workspaces/quoridor/" + name
    )
    child = subprocess.Popen(
        ["git", "show", commit + ":" + name],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    identity = dict(
        pid=child.pid,
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    )
    try:
        identity["start_ticks"] = (
            Path(f"/proc/{child.pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
        )
    except FileNotFoundError:
        identity["start_ticks"] = "UNKNOWN-fast-child"
    body, error = child.communicate()
    child.stdout.close()
    child.stderr.close()
    assert child.returncode == 0, error
    assert (
        len(body) == expected["bytes"]
        and hashlib.sha256(body).hexdigest() == expected["sha256"]
    ), (name, commit, hashlib.sha256(body).hexdigest(), expected)
    (own / (Path(name).name + ".immutable.gz")).write_bytes(
        gzip.compress(body, mtime=0)
    )
    origins.append(
        dict(
            git=commit,
            path=name,
            actual_before_expected=expected,
            identity=identity,
            directwait_exit=child.returncode,
            reaped=True,
            handles_closed=True,
        )
    )
    if name.endswith("research-lifecycle.py"):
        lines = body.decode().splitlines()
        for function in [
            "arena_reference_report",
            "arena_observation",
            "arena_plan_check",
        ]:
            start = next(
                i
                for i, line in enumerate(lines)
                if line.startswith("def " + function + "(")
            )
            end = next(
                (
                    i
                    for i in range(start + 1, len(lines))
                    if lines[i].startswith("def ")
                ),
                len(lines),
            )
            text = "\n".join(lines[start:end])
            if function == "arena_reference_report":
                print(text)
            else:
                print(lines[start])
print("PINNED", commit, "all3 exact actual caller bytes")
(own / "reader-source-refs.json").write_text(json.dumps(origins, indent=2) + "\n")
