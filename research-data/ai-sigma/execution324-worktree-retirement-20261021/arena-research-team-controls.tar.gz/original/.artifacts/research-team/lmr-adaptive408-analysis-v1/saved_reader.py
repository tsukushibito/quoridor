"""Load exactly the recorded consumer bytes; no model/native imports or calls."""

import gzip
import hashlib
import json
import sys
import types
from pathlib import Path

OWN = Path(__file__).resolve().parent
ORIGINS = json.loads((OWN / "reader-source-refs.json").read_bytes())


def load(name, filename):
    origin = next(item for item in ORIGINS if Path(item["path"]).name == filename)
    expected = origin["actual_before_expected"]
    body = gzip.decompress((OWN / (filename + ".immutable.gz")).read_bytes())
    assert (
        len(body) == expected["bytes"]
        and hashlib.sha256(body).hexdigest() == expected["sha256"]
    )
    module = types.ModuleType(name)
    module.__file__ = expected["path"]
    module.__package__ = name.rpartition(".")[0]
    sys.modules[name] = module
    exec(compile(body, module.__file__, "exec"), module.__dict__)
    return module


package = types.ModuleType("quoridor_training")
package.__path__ = []
sys.modules["quoridor_training"] = package
load("quoridor_training.snapshot", "snapshot.py")
package.cycle_process = load("quoridor_training.cycle_process", "cycle_process.py")
lc = load("saved408_arena_lifecycle", "research-lifecycle.py")
