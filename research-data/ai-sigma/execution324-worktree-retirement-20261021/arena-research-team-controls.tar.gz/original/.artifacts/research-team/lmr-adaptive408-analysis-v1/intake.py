import hashlib
import json
from pathlib import Path

own = Path(__file__).resolve().parent
root = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-adaptive408-v1/arena128-unentered-v1"
)
refs = []


def load(path, expected=None):
    path = Path(path)
    b = path.read_bytes()
    actual = dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )
    if expected:
        assert all(actual[k] == expected[k] for k in expected)
    refs.append(actual)
    return json.loads(b)


stop = load(
    root / "collection-v1/STOP.json",
    dict(
        sha256="fbd87f99806b3ed18cccab3ca709cf96f94fc5e43e67025f9879bf177545c041",
        bytes=7969,
        mode="0644",
    ),
)
print("STOPkeys", list(stop))
settings = load(root / "settings.json")
print("SETTINGS", {k: v for k, v in settings.items() if k != "arena"})
print("ARENAKEYS", list(settings["arena"]))
print("TEMPLATEKEYS", list(settings["arena"]["template"]))
plan_ref = settings["arena"]["template"]["approved_plan"]
plan = load(plan_ref["path"], plan_ref)
print("PLAN", {k: v for k, v in plan.items() if k not in ["matchups", "batches"]})
print("FIRSTBATCH", plan["batches"][0])
print("MATCHUP", plan["matchups"][0])
seq = load(Path(settings["output"]) / "result.json")
print("SEQUENCE", json.dumps(seq)[:18000])
(own / "intake-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
