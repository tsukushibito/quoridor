import gzip
import hashlib
import json
import subprocess
from pathlib import Path

base = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-adaptive408-v1/arena128-unentered-v1"
)
own = Path(__file__).resolve().parent


def load(expected):
    p = Path(expected["path"])
    b = p.read_bytes()
    assert (
        len(b) == expected["bytes"]
        and hashlib.sha256(b).hexdigest() == expected["sha256"]
        and f"{p.stat().st_mode & 0o777:04o}" == expected["mode"]
    )
    return json.loads(b)


settings = json.loads((base / "settings.json").read_bytes())
print("CALLERS", settings["arena"]["template"]["caller_sources"])
plan = load(settings["arena"]["template"]["approved_plan"])
seq = json.loads((Path(settings["output"]) / "result.json").read_bytes())
manifest = load(seq["operations"][0]["manifest"])
pub = load(manifest["data"]["files"][1])
print("PUBLICATION", json.dumps(pub, indent=2))
native = load(manifest["data"]["files"][2])
print("NATIVE_MANIFEST_KEYS", list(native))
for key, value in native.items():
    if key not in [
        "config",
        "resolved_config",
        "source",
        "hardware",
        "environment",
        "args",
        "argv",
        "build",
    ]:
        print("NATIVE", key, str(value)[:7000])
raw_ref = manifest["data"]["files"][0]
p = Path(raw_ref["path"])
assert hashlib.sha256(p.read_bytes()).hexdigest() == raw_ref["sha256"]
with gzip.open(p, "rt") as stream:
    row = json.loads(next(stream))
print("ROW_KEYS", list(row))
print(
    "ROW_SUMMARY",
    json.dumps(
        {k: v for k, v in row.items() if k not in ["observations", "moves"]}, indent=2
    )[:13000],
)
print("OBSERVATION", json.dumps(row["observations"][0], indent=2))
print("ENGINE", json.dumps(load(plan["batches"][0]["config"])["engines"]))
helper = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/shared-signed-ordering402-analysis-v1/saved_reader.py"
)
print("SAVED_READER_SOURCE", helper.read_text()[:14000])
commit = subprocess.run(
    ["git", "rev-parse", "0abbb"], check=True, capture_output=True, text=True
).stdout.strip()
print("PINNED_COMMIT", commit)
body = subprocess.run(
    ["git", "show", commit + ":scripts/dev/research-lifecycle.py"],
    check=True,
    capture_output=True,
).stdout
print("IMMUTABLE_LC", len(body), hashlib.sha256(body).hexdigest())
(own / "immutable-lc.before.gz").write_bytes(gzip.compress(body, mtime=0))
(own / "source-intake.json").write_text(
    json.dumps(
        dict(
            git=commit,
            bytes=len(body),
            sha256=hashlib.sha256(body).hexdigest(),
            callers=settings["arena"]["template"]["caller_sources"],
        ),
        indent=2,
    )
    + "\n"
)
