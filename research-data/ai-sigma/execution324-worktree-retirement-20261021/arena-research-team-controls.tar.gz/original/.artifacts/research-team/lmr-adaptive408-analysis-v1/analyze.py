"""Original408 arena128 saved interpretation, not a new experimental harness."""

import collections
import hashlib
import json
import math
import os
import resource
import time
from pathlib import Path

from saved_reader import ORIGINS, lc

OWN = Path(__file__).resolve().parent
ROOT = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-adaptive408-v1/arena128-unentered-v1"
)
FAMILIES = [14, 16, 23, 27, 37, 38, 39, 44, 64, 74, 82, 86, 103, 109, 118, 124]
SELECTED = {}
GAUGES = {"tt_generation", "tt_retained_bytes"}


def file_ref(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def read(expected):
    body = lc.read_ref(expected, max(lc.CONTROL_BYTES, expected["bytes"]))
    SELECTED[expected["path"]] = expected
    return body


def document(expected):
    return json.loads(read(expected))


def local(path):
    return document(file_ref(path))


def measured(values):
    if not values:
        return dict(n=0, median=None, mean=None, min=None, max=None, p95=None)
    values = sorted(values)
    n = len(values)
    return dict(
        n=n,
        median=(values[(n - 1) // 2] + values[n // 2]) / 2,
        mean=math.fsum(values) / n,
        min=values[0],
        max=values[-1],
        p95=values[math.ceil(n * 0.95) - 1],
    )


class Aggregate:
    def __init__(self):
        self.counts = collections.Counter()
        self.depths = []
        self.depth_tail20 = []
        self.depth_else = []
        self.by_color = {color: collections.Counter() for color in [0, 1]}
        self.stops = collections.Counter()
        self.selection_reasons = collections.Counter()
        self.failures = collections.Counter()
        self.clocks = collections.defaultdict(list)
        self.work = {view: collections.Counter() for view in ["selected", "terminal"]}
        self.work_present = {
            view: collections.Counter() for view in ["selected", "terminal"]
        }
        self.work_null = {
            view: collections.Counter() for view in ["selected", "terminal"]
        }
        self.lmr = {view: collections.Counter() for view in ["selected", "terminal"]}
        self.gauges = collections.defaultdict(set)
        self.namespaces = set()
        self.ids = set()
        self.rules = set()
        self.requested = set()
        self.profile_sums = collections.Counter()
        self.profile_field_n = collections.Counter()

    def observe(self, obs, engine, profile, color, final_ply):
        c = obs["counters"]
        self.counts["observations"] += 1
        self.by_color[color]["observations"] += 1
        self.counts["accepted"] += obs["accepted"]
        self.counts["not_accepted"] += not obs["accepted"]
        self.counts["failure"] += obs["failure"] is not None
        self.counts["engine_error"] += obs["engine_error"] is not None
        self.stops[str(obs["stop"])] += 1
        self.selection_reasons[str(c.get("selection_reason"))] += 1
        self.counts["fallback"] += (
            c.get("selection_reason") == "legal_fallback_no_completed_iteration"
        )
        for field in ["failure", "engine_error"]:
            if obs[field] is not None:
                self.failures[field + ":" + str(obs[field])] += 1
        if obs["accepted"]:
            assert c["requested_lmr_method"] == engine["lmr_method"]
            assert (
                c["actual_lmr_enabled"] is True
                and profile["actual_lmr_enabled"] is True
            )
            assert c["actual_lmr_method_id"] == profile["actual_lmr_method_id"]
            assert c["lmr_reduction_rule"] == profile["lmr_reduction_rule"]
            assert c["actual_search_namespace"] == profile["actual_namespace"]
            self.namespaces.add(
                json.dumps(c["actual_search_namespace"], sort_keys=True)
            )
            self.ids.add(c["actual_lmr_method_id"])
            self.rules.add(c["lmr_reduction_rule"])
            self.requested.add(c["requested_lmr_method"])
            depth = obs["completed_depth"]
            if type(depth) is int:
                assert 0 < depth <= engine["depth"]
                self.depths.append(depth)
                self.by_color[color]["selected_completed_depth_n"] += 1
                (
                    self.depth_tail20
                    if final_ply - obs["ply"] <= 20
                    else self.depth_else
                ).append(depth)
                self.counts["selected_depth_ge16"] += depth >= 16
                self.counts["selected_depth_ge32"] += depth >= 32
                self.counts["selected_depth64"] += depth == 64
            else:
                self.counts["accepted_without_completed_depth"] += 1
        for field in ["caller_seconds", "thinking_seconds"]:
            value = obs.get(field)
            if value is not None:
                assert type(value) in (int, float) and math.isfinite(value)
                self.clocks[field].append(value)
        receipt, deadline = c.get("authority_receipt_ns"), obs.get("deadline_ns")
        if type(receipt) is int and type(deadline) is int:
            self.counts["receipt_deadline_n"] += 1
            self.counts["receipt_late_or_equal"] += receipt >= deadline
            self.counts["return_after_deadline"] += obs["returned_ns"] >= deadline
            self.counts["commit_after_deadline"] += (
                obs["accepted_ns"] >= deadline
                if type(obs.get("accepted_ns")) is int
                else False
            )
            self.clocks["receipt_slack_ms"].append((deadline - receipt) / 1e6)
            self.clocks["receipt_to_terminal_drain_ms"].append(
                (obs["returned_ns"] - receipt) / 1e6
            )
            assert deadline - obs["caller_started_ns"] == 100000000
        for field in [
            "matching_terminal_collected",
            "terminal_collected",
            "reserve_stop_is_not_user_cancel",
            "authority_legal",
        ]:
            self.counts[field + "_true"] += c.get(field) is True
        self.counts["inflight_zero"] += c.get("inflight_after_drain") == 0
        self.counts["first_receipt_or_control_error"] += (
            c.get("first_receipt_or_control_error") is not None
        )
        self.counts["completed_snapshot_validation_failed"] += (
            c.get("completed_snapshot_validation_failed") is not False
        )
        self.counts["position_traits_available"] += any(
            obs.get(k) is not None or c.get(k) is not None
            for k in ["parent_traits", "position_traits", "attributes"]
        )
        self.gauges["authority_core"].add(c.get("authority_core"))
        self.gauges["AI_worker_core"].add(c.get("AI_worker_core"))
        for view, data in [
            ("selected", obs.get("completed_iteration_counters")),
            ("terminal", c.get("whole_search")),
        ]:
            self.counts[view + "_counters_n"] += isinstance(data, dict)
            if isinstance(data, dict):
                for key, value in data.items():
                    if value is None:
                        self.work_null[view][key] += 1
                    elif type(value) is int:
                        if key in GAUGES:
                            self.gauges[view + ":" + key].add(value)
                        else:
                            self.work[view][key] += value
                            self.work_present[view][key] += 1
        for view, field in [
            ("selected", "lmr_work_completed"),
            ("terminal", "lmr_work_terminal"),
        ]:
            if isinstance(c.get(field), dict):
                for key, value in c[field].items():
                    assert type(value) is int and value >= 0
                    self.lmr[view][key] += value
        if isinstance(obs.get("completed_iteration_counters"), dict) and isinstance(
            c.get("whole_search"), dict
        ):
            for key in [
                "nodes",
                "static_evaluations",
                "delta_updates",
                "pvs_researches",
            ]:
                assert (
                    c["whole_search"][key] >= obs["completed_iteration_counters"][key]
                )

    def profile(self, profile, color):
        self.counts["game_exposures"] += 1
        self.by_color[color]["game_exposures"] += 1
        for key, value in profile.items():
            if type(value) in (int, float):
                if key in [
                    "retained_bytes_peak",
                    "requested_tt_entries",
                    "effective_tt_slots",
                    "persistent_tt_byte_cap",
                    "session_metadata_bytes_peak",
                    "shared_evaluator_bytes",
                ]:
                    self.gauges[key].add(value)
                    self.by_color[color][key + "=" + str(value)] += 1
                else:
                    self.profile_sums[key] += value
                    self.profile_field_n[key] += 1
        if profile["attempts"]:
            assert (
                profile["requested_tt_entries"]
                == profile["effective_tt_slots"]
                == 1048576
            )
            assert (
                profile["persistent_tt_byte_cap"]
                == profile["retained_bytes_peak"]
                == 83886128
            )

    def output(self):
        return dict(
            counts=dict(self.counts),
            selected_completed_depth=dict(
                **measured(self.depths),
                histogram=dict(sorted(collections.Counter(self.depths).items())),
            ),
            final20_recorded_plies_proxy=measured(self.depth_tail20),
            earlier_recorded_plies=measured(self.depth_else),
            by_color=self.by_color,
            stops=dict(self.stops),
            reasons=dict(self.selection_reasons),
            failures=dict(self.failures),
            clocks={
                key: dict(**measured(values), sum=math.fsum(values))
                for key, values in self.clocks.items()
            },
            work_views=self.work,
            work_present_n=self.work_present,
            work_null_n=self.work_null,
            LMR_views=self.lmr,
            persistent_profile_sums=dict(self.profile_sums),
            persistent_profile_field_n=dict(self.profile_field_n),
            gauges={k: sorted(v, key=str) for k, v in self.gauges.items()},
            actual_namespace=[json.loads(s) for s in sorted(self.namespaces)],
            actual_method_ids=sorted(self.ids),
            actual_requested_method=sorted(self.requested),
            actual_reduction_rules=sorted(self.rules),
            unknown=dict(
                physical_NN_forwards="UNKNOWN; null native counters/general nn_calls0 do not establish zero",
                continuous_family_RSS_peak="UNKNOWN",
                isolated_evaluation_LMR_cost="UNKNOWN",
                actual_wall_stock_endgame_mix="UNKNOWN if parent traits absent",
                complete_all_process_Search_CPU_time="UNKNOWN; only named recorded worker invocation spans summed",
            ),
        )


start = time.monotonic()
settings = local(ROOT / "settings.json")
sequence = local(Path(settings["output"]) / "result.json")
assert (
    sequence["status"] == "PASS"
    and sequence["completed_operations"] == sequence["selected_operations"] == 4
)
plan = document(settings["arena"]["template"]["approved_plan"])
schedule = document(plan["schedule"])
assert plan["family_ids"] == FAMILIES and len(schedule) == plan["planned_slots"] == 128
assert [s["slot"] for s in schedule] == list(range(128))
artifact = settings["arena"]["template"]["artifact"]
assert artifact["sha256"].startswith("bb63fc17")
aggregates = {}
contrasts, games, global_seen = [], [], set()
original_operation_refs = []
for op in sequence["operations"]:
    batch_index = op["index"]
    batch = plan["batches"][batch_index]
    config = document(batch["config"])
    manifest = document(op["manifest"])
    assert (
        manifest["status"] == manifest["data"]["status"] == "PASS"
        and not manifest["primary"]
        and not manifest["remaining"]
        and manifest["cleanup_complete"]
    )
    assert (
        manifest["build_manifest"]["sha256"]
        == "e934c534bedce904189c30ede4489a53a25c6664d876b87d5ca861b9ca7f56c2"
    )
    original_operation_refs.append(op["manifest"])
    experiment = document(manifest["experiment"])
    assert experiment["config"] == batch["config"]
    matchup = plan["matchups"][batch["matchup"]]
    assert config["engines"] == matchup["engines"]
    assert [e["lmr_method"] for e in config["engines"]] == ["fixed_one", "depth_rank"]
    assert (
        config["arena"]["tt_entries"] == 1048576
        and config["arena"]["return_reserve_ms"] == 5
    )
    assert (
        config["cpu_cores"] == [2, 6]
        and config["management_cpu_core"] == 4
        and config["max_plies"] == 200
    )
    assert all(
        e["lmr"]
        and e["depth"] == 64
        and e["max_nodes"] == 1000000
        and e["time_ms"] == 100
        for e in config["engines"]
    )
    assert config["arena"]["search_artifact_sha256"] == [artifact["sha256"]] * 2
    files = {
        key: next(r for r in manifest["data"]["files"] if Path(r["path"]).name == name)
        for key, name in [
            ("journal", "completed.jsonl.gz"),
            ("result", "result.json"),
            ("native_manifest", "manifest.json"),
        ]
    }
    values = {key: read(value) for key, value in files.items()}
    report = lc.arena_reference_report(
        config, files, values=values, expected_build={"artifact": artifact}
    )
    native = json.loads(values["native_manifest"])
    summary = native["summary"]
    assert report["arena_summary"] == summary
    assert report["stopped"] is None and report["all_workers_joined"]
    assert (
        summary["census"]["complete_pairs"] == 16
        and summary["census"]["completed_games"] == 32
        and summary["census"]["unknown_games"] == 0
    )
    for engine in config["engines"]:
        key = (
            engine["kind"]
            + ":"
            + engine["ordering_profile"]
            + ":"
            + engine["lmr_method"]
        )
        assert key not in aggregates
        aggregates[key] = Aggregate()
    wdl = collections.Counter()
    family_scores = collections.defaultdict(list)
    statuses = collections.Counter()
    for row in report["outcomes"]:
        lc.arena_observation(config, row)
        local_game = row["game"]
        slot = schedule[batch["slots"][local_game]]
        assert (
            slot["batch"] == batch_index
            and slot["local_game"] == local_game
            and slot["candidate_color"] == row["candidate_color"]
        )
        assert slot["slot"] not in global_seen
        global_seen.add(slot["slot"])
        opening = config["arena"]["book"]["openings"][local_game // 2]
        assert opening["reference"]["settings"]["family_id"] == slot["family_id"]
        assert len(opening["prefix"]) == [4, 8, 12, 16][(local_game // 2) // 4]
        statuses[row["status"]] += 1
        if row["status"] in {"goal", "forfeit"} and row["winner"] in [0, 1]:
            score = float(row["winner"] == row["candidate_color"])
            outcome = "W" if score else "L"
        elif row["status"] == "draw" and row["winner"] is None:
            score, outcome = 0.5, "D"
        else:
            score, outcome = None, "UNKNOWN"
        wdl[outcome] += 1
        if score is not None:
            family_scores[slot["family_id"]].append(score)
        counts_by_engine = collections.Counter(
            o["engine_index"] for o in row["observations"]
        )
        for index, engine in enumerate(config["engines"]):
            profile = row["persistent_tt"][index]
            assert profile["search_invocations"] == counts_by_engine[index]
            key = (
                engine["kind"]
                + ":"
                + engine["ordering_profile"]
                + ":"
                + engine["lmr_method"]
            )
            color = row["candidate_color"] ^ index
            aggregates[key].profile(profile, color)
        for obs in row["observations"]:
            index = obs["engine_index"]
            assert index == (0 if obs["side"] == row["candidate_color"] else 1)
            engine = config["engines"][index]
            key = (
                engine["kind"]
                + ":"
                + engine["ordering_profile"]
                + ":"
                + engine["lmr_method"]
            )
            aggregates[key].observe(
                obs, engine, row["persistent_tt"][index], obs["side"], row["plies"]
            )
        games.append(
            dict(
                global_slot=slot["slot"],
                batch=batch_index,
                local_game=local_game,
                family_id=slot["family_id"],
                prefix_length=len(opening["prefix"]),
                candidate_color=row["candidate_color"],
                started=row["started"],
                status=row["status"],
                winner=row["winner"],
                reason=row["reason"],
                failure=row["failure"],
                A_result=outcome,
                A_score=score,
                plies=row["plies"],
                observations=len(row["observations"]),
                record_identity=dict(journal=files["journal"], game=local_game),
            )
        )
    assert len(family_scores) == 16 and all(len(v) == 2 for v in family_scores.values())
    scores = [
        dict(
            family_id=family,
            score=math.fsum(family_scores[family]) / 2,
            A_scores=family_scores[family],
        )
        for family in FAMILIES
    ]
    assert math.fsum(v["score"] for v in scores) / 16 == summary["complete_pair_mean"]
    assert [v["score"] for v in scores] == [v["score"] for v in summary["pairs"]]
    contrasts.append(
        dict(
            batch=batch_index,
            evaluator=config["engines"][0]["kind"],
            profile=config["engines"][0]["ordering_profile"],
            left="fixed_one",
            right="depth_rank",
            games=32,
            entered=sum(g["started"] for g in games if g["batch"] == batch_index),
            returned=len(report["outcomes"]),
            WDL_A=dict(wdl),
            statuses=dict(statuses),
            family_scores=scores,
            mean_A_score=summary["complete_pair_mean"],
            native_interval=summary["bootstrap"],
            native_census=summary["census"],
            original_manifest=op["manifest"],
            publication=files["result"],
            archive=files["journal"],
            archive_raw_bytes=native["result"]["archive"]["raw_bytes"],
            archive_raw_sha256=native["result"]["archive"]["raw_sha256"],
            native_report_wall_seconds=report["wall_seconds"],
            native_report_peak_rss=report["peak_rss"],
            evaluator_initialization_seconds=native["evaluator_initialization_seconds"],
            reported_general_nn_calls=report["nn_calls"],
            declared_model_identity=matchup["evaluator_sha256"],
        )
    )
    del report, values, native
assert global_seen == set(range(128)) and len(games) == 128
methods = {key: value.output() for key, value in aggregates.items()}
assert len(methods) == 8 and all(
    len(m["actual_method_ids"]) == len(m["actual_namespace"]) == 1
    for m in methods.values()
)
total = collections.Counter()
for method in methods.values():
    total.update(method["counts"])
assert total["accepted"] == total["observations"]
for expected in SELECTED.values():
    assert file_ref(expected["path"]) == expected
result = dict(
    issue="quoridor-4lc.408.4",
    status="SAVED_ORIGINAL128_ANALYSIS_COMPLETE",
    settings=file_ref(ROOT / "settings.json"),
    sequence=file_ref(Path(settings["output"]) / "result.json"),
    original_operation_manifests=original_operation_refs,
    image_declared_only=artifact,
    build_declared_only=manifest["build_manifest"],
    current_consumer_sources=ORIGINS,
    global_census=dict(
        planned=128,
        unique=128,
        entered=sum(g["started"] for g in games),
        returned=128,
        complete_pairs=64,
        unknown=sum(c["WDL_A"].get("UNKNOWN", 0) for c in contrasts),
        shared_families=16,
        contrasts=4,
    ),
    contrasts=contrasts,
    methods=methods,
    observation_census=dict(total),
    games=games,
    clocks_and_work="Terminal totals and selected snapshots nested/nonadditive; persistentTT byte fields gauges; recorded invocation spans not all-process CPU",
    source_qualification="Original408 B clamp63/maxextra3 and protections/PVS verification cited; no source audit/replay; approximationOFF in resolved original contract",
    no_new_native_Search_forward_games_bootstrap=0,
    costs=dict(
        saved_analysis_seconds=time.monotonic() - start,
        self_ru_maxrss_B=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        family_continuous_peak="UNKNOWN",
        actual_worker_affinity=sorted(os.sched_getaffinity(0)),
    ),
    limitations=[
        "same16families reused across4 contrasts; not128independent samples",
        "native interval quoted, no bootstrap repeated",
        "selective nominal depth not full-width proof",
        "different trajectories/final20ply proxy not physical wall-stock endgame",
        "no old400/402 pooling/RAW reads",
        "important strength/adoption Root+same408.3 only",
    ],
)
(OWN / "result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
(OWN / "selected-refs.json").write_text(
    json.dumps(list(SELECTED.values()), indent=2) + "\n"
)
print(
    json.dumps(
        dict(
            census=result["global_census"],
            contrasts=[
                {k: c[k] for k in ["evaluator", "profile", "WDL_A", "mean_A_score"]}
                for c in contrasts
            ],
            methods={
                key: dict(
                    depth=value["selected_completed_depth"], counts=value["counts"]
                )
                for key, value in methods.items()
            },
            costs=result["costs"],
        )
    )
)
