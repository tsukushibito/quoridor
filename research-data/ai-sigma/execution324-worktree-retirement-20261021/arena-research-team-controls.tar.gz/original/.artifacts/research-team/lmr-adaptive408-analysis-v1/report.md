# 固定1手LMRと深さ・順位LMR：原128局の保存解析

A=fixed_one、B=depth_rank。4本の元manifestはすべてPASSで、128局が一意に対応し、64色ペアが完成した。127局goal、1局native draw、UNKNOWN・未回収・不完全ペアは0。新しい探索・対局・bootstrapは実行していない。

## 勝敗と条件付き幅

以下はA側。区間は元native publicationのfamily-pair bootstrap 95%を引用した。各対照は同じ16開幕familyを共有し、128局を独立128標本とは扱わない。条件付きの探索的結果で、Elo・非劣性・母集団優越・既定昇格の認定ではない。

| 評価器 / ordering  | A勝 |  分 | A敗 |  A score | 保存95%区間          |
| ------------------ | --: | --: | --: | -------: | -------------------- |
| nnue / control     |  13 |   0 |  19 | 0.406250 | [0.28125, 0.53125]   |
| nnue / cheap       |  12 |   1 |  19 | 0.390625 | [0.234375, 0.546875] |
| distance / control |  12 |   0 |  20 | 0.375000 | [0.25, 0.46875]      |
| distance / cheap   |  12 |   0 |  20 | 0.375000 | [0.25, 0.5]          |

Bの点推定が4対照すべてで上回った。固定D Controlの保存区間はA=0.5を含まないが、16固定family・共有family・多重対照という範囲を超える確証にはしない。最終的な採否はRootと既存関連確認に委ねる。

| family | NNUE Control | NNUE Cheap | D Control | D Cheap |
| -----: | -----------: | ---------: | --------: | ------: |
|     14 |          0.5 |        1.0 |       0.5 |     0.5 |
|     16 |          0.5 |        0.0 |       0.5 |     0.5 |
|     23 |          0.0 |        0.5 |       0.0 |     1.0 |
|     27 |          0.5 |        0.5 |       0.0 |     0.5 |
|     37 |          0.0 |        0.5 |       0.5 |     0.5 |
|     38 |          0.5 |        1.0 |       0.5 |     0.5 |
|     39 |          0.5 |        0.0 |       0.0 |     0.5 |
|     44 |          0.0 |        0.5 |       0.5 |     0.0 |
|     64 |          0.0 |        0.5 |       0.5 |     0.5 |
|     74 |          0.5 |        0.5 |       0.0 |     0.0 |
|     82 |          0.5 |       0.25 |       0.5 |     0.5 |
|     86 |          1.0 |        0.0 |       0.5 |     0.0 |
|    103 |          0.5 |        0.0 |       0.5 |     0.0 |
|    109 |          0.5 |        0.5 |       0.5 |     0.5 |
|    118 |          0.5 |        0.0 |       0.5 |     0.5 |
|    124 |          0.5 |        0.5 |       0.5 |     0.0 |

各値は二色のA score平均。個々の二色結果・global/local index・batch・family・色・元journal参照はresult.jsonに保存した。prefix長4/8/12/16各4familyで、各対照の事前選択と同じである。

## accepted completed snapshotの深さ

6567 accepted observationsだけを集計した。両方式ともLMR ONの選択的な名目深さであり、全幅完了の証明ではない。中央値を主表示する。

| 評価器 / ordering / method  |   n | 中央値 |   平均 | p95 | 深さ64件数 |
| --------------------------- | --: | -----: | -----: | --: | ---------: |
| nnue:control:fixed_one      | 769 |      6 |  9.730 |  24 |          2 |
| nnue:control:depth_rank     | 772 |      5 |  9.869 |  23 |          6 |
| nnue:cheap:fixed_one        | 763 |      5 |  9.037 |  22 |         13 |
| nnue:cheap:depth_rank       | 767 |      5 |  8.795 |  21 |         10 |
| distance:control:fixed_one  | 864 |     10 | 12.466 |  29 |         18 |
| distance:control:depth_rank | 868 |     10 | 12.796 |  33 |         27 |
| distance:cheap:fixed_one    | 880 |      9 | 11.590 |  23 |         17 |
| distance:cheap:depth_rank   | 884 |      9 | 11.995 |  24 |         25 |

中央値はBが一律に深くなっていない。全histogramはresult.jsonにある。平均には深い尾部が寄与し、対局軌跡・手数・終盤構成が異なるため、深さの差を勝因や演算単体費へ変換しない。保存parent traitsは全件欠け、実際の壁在庫・盤面終盤比はUNKNOWN。代わりに各棋譜の最後20plyを時系列proxyとして分離した（終盤の幾何判定ではない）。

| method                      | 最後20ply proxy n / 深さ中央値 | それ以前 n / 深さ中央値 |
| --------------------------- | ------------------------------ | ----------------------- |
| nnue:control:fixed_one      | 320 / 17                       | 449 / 4                 |
| nnue:control:depth_rank     | 320 / 16                       | 452 / 4                 |
| nnue:cheap:fixed_one        | 319 / 11                       | 444 / 4                 |
| nnue:cheap:depth_rank       | 319 / 11                       | 448 / 4                 |
| distance:control:fixed_one  | 320 / 18                       | 544 / 5                 |
| distance:control:depth_rank | 320 / 18                       | 548 / 5                 |
| distance:cheap:fixed_one    | 320 / 17                       | 560 / 5                 |
| distance:cheap:depth_rank   | 320 / 17                       | 564 / 4                 |

## work・時計・永続TT

各行の分母は上表のn回のaccepted要求。selectedは採用済みcompleted snapshot、terminalは同じ要求の終了時累積値である。selectedはterminalに内包され、合算しない。TT profileにも同じworkが現れるため二重加算しない。

| method                      | selected nodes | terminal nodes | terminal static eval | terminal delta | terminal PVS再探索 |
| --------------------------- | -------------: | -------------: | -------------------: | -------------: | -----------------: |
| nnue:control:fixed_one      |       50384894 |       71548248 |             36676956 |       68101355 |              18336 |
| nnue:control:depth_rank     |       49203106 |       72058114 |             38844190 |       68563166 |              20658 |
| nnue:cheap:fixed_one        |       29821280 |       42249267 |             22735654 |       40294510 |              16000 |
| nnue:cheap:depth_rank       |       29444815 |       43237029 |             24333927 |       41442902 |              16933 |
| distance:control:fixed_one  |      101930532 |      145064627 |             72231636 |              0 |               5984 |
| distance:control:depth_rank |      102040043 |      153017187 |             84446025 |              0 |               5551 |
| distance:cheap:fixed_one    |       49297432 |       70866702 |             36943574 |              0 |               4451 |
| distance:cheap:depth_rank   |       50469385 |       72960703 |             39623404 |              0 |               4607 |

| method                      | terminal LMR試行 | 通常深さ確認 | full-window再探索 | 記録worker invocation秒 | caller中央値ms | receipt余裕中央値ms | drain中央値ms |
| --------------------------- | ---------------: | -----------: | ----------------: | ----------------------: | -------------: | ------------------: | ------------: |
| nnue:control:fixed_one      |          3936784 |        26860 |               769 |               74.850132 |         98.748 |              33.821 |        32.327 |
| nnue:control:depth_rank     |          2593994 |        20975 |               198 |               74.800658 |         98.752 |              35.858 |        34.347 |
| nnue:cheap:fixed_one        |          2599486 |        18167 |               599 |               73.807683 |         99.389 |              31.537 |        30.368 |
| nnue:cheap:depth_rank       |          1625120 |        15941 |               123 |               74.256309 |         99.216 |              33.149 |        32.027 |
| distance:control:fixed_one  |          7960530 |        70711 |               377 |               83.233994 |         99.375 |              31.976 |        30.105 |
| distance:control:depth_rank |          5419288 |        47109 |                90 |               82.947252 |         99.238 |              32.182 |        29.894 |
| distance:cheap:fixed_one    |          3360396 |        22727 |               230 |               84.921175 |         99.188 |              32.369 |        30.649 |
| distance:cheap:depth_rank   |          1960443 |        12440 |                52 |               84.713587 |         99.153 |              32.297 |        30.520 |

全6567件のauthority receiptはdeadlineより前（同時・超過0）。一方、terminal returnがdeadline後408件、commitが後441件ある。100msはaction receipt authorityであり、全process returnが100ms以内という主張ではない。全件matching terminal回収・inflight0・合法採用を既存consumerで検証した。5ms reserve停止はuser cancelと別で、internal cancellationやinternal_time_limitを対局エラーへ昇格しない。

| method                      | 元stop reason / 件数                                          | TT profile cancellations |
| --------------------------- | ------------------------------------------------------------- | -----------------------: |
| nnue:control:fixed_one      | {"internal_time_limit": 766, "cancelled": 1, "depth_cap": 2}  |                        1 |
| nnue:control:depth_rank     | {"internal_time_limit": 762, "depth_cap": 6, "cancelled": 4}  |                        4 |
| nnue:cheap:fixed_one        | {"internal_time_limit": 747, "depth_cap": 13, "cancelled": 3} |                        3 |
| nnue:cheap:depth_rank       | {"internal_time_limit": 757, "depth_cap": 10}                 |                        0 |
| distance:control:fixed_one  | {"internal_time_limit": 843, "depth_cap": 18, "cancelled": 3} |                        3 |
| distance:control:depth_rank | {"internal_time_limit": 840, "depth_cap": 27, "cancelled": 1} |                        1 |
| distance:cheap:fixed_one    | {"internal_time_limit": 861, "depth_cap": 17, "cancelled": 2} |                        2 |
| distance:cheap:depth_rank   | {"internal_time_limit": 857, "depth_cap": 25, "cancelled": 2} |                        2 |

fallback・engine error・control error・completed snapshot validation failure・forfeitは保存検査scopeで0。唯一のdrawをmaxply/error由来と推測していない。元GAME statusをそのまま使った。各methodは32局exposure、各色16局。全色のactual requested/effective TTは1048576、persistent TT retained/capは各83886128B、二色167772256B。これは永続gaugeで、要求回数や局数で合算しない。main/authority core4、A worker core2・B worker core6、別TIDおよびdrain対応を保存値で検証した。将来のquiet/physicalを保証するものではない。

native reported peak RSSは4operationで206663680 / 206622720 / 209346560 / 209784832B（元process報告scope）。continuous family RSS peakはUNKNOWN。記録worker invocation秒はその名前付きspanだけで、全process Search CPU時間ではない。physical NN forward、leaf数、LMR/static評価の孤立費はUNKNOWN。general nn_calls=0とnull physical counterをforward0へ変換しない。その他全記録work・TT・時計の分母はresult.jsonにある。

## 実設定と証拠

同じ真正image bb63fc17、Build e934c534、source0abbb3c7。NNUE BEST43と固定D(0,8tanh)、Control/Cheap、近似OFF、TT1048576、PVS、100ms receipt/5ms reserve、node safety1M・depth64・200plyを使用した。actual requested method・effective method・reduction ruleとnative namespaceを各observation/TT profileで照合し、namespace文字列から設定を逆生成していない。

- A: `lmr400-late4-depth3-minus1-pvs-verify-v1`。内部残depth>=3・distinct rank>=4でextra1。
- B: `lmr408-depth-rank-log63-extra0to3-pvs-verify-v1`。lnの引数を63でclampし、extraを0..min(3,d-2)にする固定表。TT/goal/killer保護と通常深さ確認/PVSは元software/関連確認の資格を引用し、再ソース監査していない。

元pre-game arena128-v1はforecast49057749Bが32MiBを超えて拒否され、Search/対局0、FAILEDのまま。Rootが上限64MiBとfresh pathsだけを修復し、今回の未入場128局を一度実施した。元失敗・returned NULLとpersisted masks・費を保持し、再finalizeや旧400/402結果の混入はない。元arena outer670.089668092秒と各native spanはnestedであり合算しない。cost96の生データは再読していない。

settings・plan・schedule・config・4 manifests/publications/archivesをhash-size-modeでparse前/読取後に照合。immutable Gitの実caller bytesと一致する既存arena_reference_report/arena_observationを使用した。詳細はselected-refs.json、intake-refs.json、reader-source-refs.json、validation.json。本文の深さ・score集計はその保存結果のみから作成した。

helperの初回短縮Git名解決失敗（exit128）と、管理用一時ready JSONのEXDEV移動失敗を原receiptに保持。後者は当該所有一時ファイルだけを削除済み。後続は完全immutable Gitと実caller SHA一致を確認して進めた。科学実行・元データ変更・成功suite再演はいずれも0。

結果はこの16family/二色/固定条件でB側の点推定が良かったことと、受理・完了・深さ・workの観測である。一般棋力、勝因、A/Bの孤立演算速度、既定昇格は未確立。追加call・追試・tuningは発行していない。actual saved reader/child/TMP/lease STOPと対象使用量はcompletion.jsonとSTOP.jsonを参照。Main/Beads/backup/closeは324に委ねる。

報告helperの初回Ruff checkはE741（変数名l）で失敗した。その原receipt・diskのpending/attemptedを保持し、変数名だけをlmrへ修正した。修正後format/checkと保存算術61項目がPASS。元arena/analysisは再実行していない。
