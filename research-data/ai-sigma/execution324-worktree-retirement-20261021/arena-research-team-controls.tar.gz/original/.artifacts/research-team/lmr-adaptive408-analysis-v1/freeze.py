"""Close the bounded saved reader and bind its selected immutable inputs."""

import datetime
import hashlib
import json
import os
import resource
from pathlib import Path

OWN = Path(__file__).resolve().parent


def ref(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    st = path.stat()
    return {
        "path": str(path),
        "sha256": digest.hexdigest(),
        "bytes": st.st_size,
        "mode": f"{st.st_mode & 0o777:04o}",
    }


bound = []
for name in ["selected-refs.json", "intake-refs.json"]:
    for expected in json.loads((OWN / name).read_text()):
        actual = ref(Path(expected["path"]))
        if expected != actual:
            raise ValueError(f"immutable selected input changed: {expected['path']}")
        bound.append(actual)

root = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-adaptive408-v1"
)
repair = root / "arena128-unentered-v1/ordinary-output-repair.json"
repair_ref = ref(repair)
if not repair_ref["sha256"].startswith("7d95d59d"):
    raise ValueError("ordinary repair metadata identity")
refusal = root / "arena128-v1/collection-refusal-v1/STOP.json"
refusal_ref = ref(refusal)
if refusal_ref != {
    "path": str(refusal),
    "sha256": "ee8e560ec8de6faabb286ea353eeae0bb9082b1cdf4592eb18693316b145fccc",
    "bytes": 2099,
    "mode": "0644",
}:
    raise ValueError("original refusal STOP identity")

report = OWN / "report.md"
report_text = report.read_text()
if "E741" not in report_text:
    report.write_text(
        report_text + "\n報告helperの初回Ruff checkはE741（変数名l）で失敗した。"
        "その原receipt・diskのpending/attemptedを保持し、変数名だけをlmrへ修正した。"
        "修正後format/checkと保存算術61項目がPASS。元arena/analysisは再実行していない。\n"
    )

result = json.loads((OWN / "result.json").read_text())
draws = [g for g in result["games"] if g["status"] == "draw"]
receipt = {
    "issue": "quoridor-4lc.408.4",
    "status": "saved inputs unchanged after analysis",
    "selected_refs_after": bound,
    "ordinary_output_repair": repair_ref,
    "original_pre_game_refusal_STOP": refusal_ref,
    "draw_record_metadata": draws,
    "reader_finish_UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "affinity": sorted(os.sched_getaffinity(0)),
    "self_ru_maxrss_B": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
    "continuous_family_peak": "UNKNOWN",
    "new_archive_decode": False,
    "new_science": False,
    "no_Main_canonical_hardware_lease_acquired": True,
}
(OWN / "reader-finish.json").write_text(
    json.dumps(receipt, ensure_ascii=False, indent=2) + "\n"
)
print(
    json.dumps(
        {
            "input_refs_exact": len(bound),
            "reader_finish": receipt["reader_finish_UTC"],
            "draws": draws,
        },
        ensure_ascii=False,
    )
)
