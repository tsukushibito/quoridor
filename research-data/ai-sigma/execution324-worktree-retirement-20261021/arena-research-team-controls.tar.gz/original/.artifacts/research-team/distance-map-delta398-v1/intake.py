"""Bound only current geometry subjects and protected caller identity."""

import gzip
import hashlib
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent


def read(path, limit=512 * 1024):
    data = path.read_bytes()
    assert len(data) <= limit
    return data, {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


paths = [
    "crates/quoridor-core/src/position.rs",
    "crates/quoridor-core/src/lib.rs",
    "crates/quoridor-nnue/src/features.rs",
    "crates/quoridor-nnue/src/lib.rs",
]
readonly_paths = [
    "crates/quoridor-core/tests/support/queue_reference.rs",
    "crates/quoridor-nnue/src/map_reuse_tests.rs",
    "crates/quoridor-ai/src/alphabeta.rs",
]
before = OWN / "before"
before.mkdir()
bindings = []
for relative in paths + readonly_paths:
    data, binding = read(MAIN / relative)
    binding["relative"] = relative
    binding["write_scope"] = relative in paths
    bindings.append(binding)
    # No caller/source mirror. Changed subjects only have compressed recovery;
    # the read-only oracle/toy scopes and caller are held by immutable references.
    if relative in paths:
        with (before / (relative.replace("/", "__") + ".gz")).open("xb") as output:
            output.write(gzip.compress(data, mtime=0))

cost_candidates = [
    MAIN
    / ".artifacts/research-policy/distance-delta-source-cost-inspection-20261014.md",
    MAIN
    / ".artifacts/research-team/integration324/distance-map-delta393-v1/distance-delta-source-cost-inspection-20261014.md",
]
cost = None
for candidate in cost_candidates:
    if candidate.is_file():
        data, binding = read(candidate, 128 * 1024)
        cost = {"binding": binding, "text": data.decode()}
        break

for binding in bindings:
    _, after = read(Path(binding["path"]))
    assert all(after[key] == binding[key] for key in ("sha256", "bytes", "mode"))
result = {
    "issue": "quoridor-4lc.398.1",
    "before_after": bindings,
    "cost_inspection": cost,
    "absent_cost_candidates_if_not_found": [str(p) for p in cost_candidates]
    if cost is None
    else [],
    "author_geometry_Search_model_native_tests_calls": 0,
    "mixed": "USERPAUSE",
}
(OWN / "intake.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
print(json.dumps({"status": "PASS", "intake": read(OWN / "intake.json")[1]}))
