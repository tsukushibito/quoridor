"""Bounded source-only composition, scoped format and reversible patch checks."""

import difflib
import gzip
import hashlib
import json
import os
import resource
import runpy
import stat
import subprocess
import time
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (320 * 1024**2, 320 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
TEMP = OWN / "temporary-edited-subjects"
CHECK = Path(os.environ["TMPDIR"]) / "patch-roundtrip"
RUSTFMT = Path(
    "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt"
)
PATCH = Path("/usr/bin/patch")


def bound(path):
    data = path.read_bytes()
    assert len(data) <= 512 * 1024
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    return data, {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": format(info.st_mode & 0o777, "04o"),
    }


def identity(pid):
    p = Path("/proc") / str(pid) / "stat"
    if not p.exists():
        return None
    try:
        ticks = p.read_text().rsplit(")", 1)[1].split()[19]
    except FileNotFoundError:
        return None
    return {
        "pid": pid,
        "start_ticks": ticks,
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    }


commands = []


def command(name, argv, cwd):
    started = time.monotonic()
    stdout, stderr = OWN / f"{name}.stdout.log", OWN / f"{name}.stderr.log"
    with stdout.open("xb") as out, stderr.open("xb") as err:
        with subprocess.Popen(
            argv, cwd=cwd, stdout=out, stderr=err, close_fds=True
        ) as child:
            original = identity(child.pid)
            code = child.wait()
    after = identity(child.pid)
    assert original is None or after != original
    for path in (stdout, stderr):
        assert path.stat().st_size <= 128 * 1024, "full capture overflow"
    commands.append(
        {
            "name": name,
            "argv": argv,
            "cwd": str(cwd),
            "identity": original,
            "fresh_identity_after_directwait": after,
            "directwait_exit": code,
            "reaped": True,
            "handles_closed": True,
            "stdout": bound(stdout)[1],
            "stderr": bound(stderr)[1],
            "nested_wall_seconds_not_added": time.monotonic() - started,
        }
    )
    (OWN / "format-command-facts.json").write_text(
        json.dumps(commands, indent=2) + "\n"
    )
    assert code == 0, f"{name} failed: {code}"


intake = json.loads(bound(OWN / "intake.json")[0])
current = []
for binding in intake["before_after"]:
    _, actual = bound(Path(binding["path"]))
    assert all(actual[k] == binding[k] for k in ("sha256", "bytes", "mode")), binding[
        "path"
    ]
    current.append(actual)
wall_test = MAIN / "crates/quoridor-core/tests/wall_map391.rs"
wall_data, wall_binding = bound(wall_test)
recovery = OWN / "before/crates__quoridor-core__tests__wall_map391.rs.gz"
with recovery.open("xb") as output:
    output.write(gzip.compress(wall_data, mtime=0))
current.append(wall_binding)
new = [
    "crates/quoridor-core/src/distance_geometry.rs",
    "crates/quoridor-core/src/distance_geometry398_tests.rs",
    "crates/quoridor-nnue/src/distance_delta398_tests.rs",
]
assert all(not (MAIN / p).exists() for p in new)
tools = [bound(p)[1] for p in (RUSTFMT, PATCH)]
config = []
for name in ("rustfmt.toml", ".rustfmt.toml"):
    if (MAIN / name).is_file():
        config.append(bound(MAIN / name)[1])
assert not TEMP.exists() and not CHECK.exists()
runpy.run_path(str(OWN / "compose.py"), run_name="__main__")
composition = json.loads((OWN / "composition-input.json").read_text())
paths = composition["existing"] + composition["new"]
argv = [str(RUSTFMT), "--edition", "2024", "--config", "skip_children=true"]
if config:
    argv += ["--config-path", str(Path(config[0]["path"]))]
command("rustfmt398", argv + [str(TEMP / p) for p in paths], MAIN)
command("rustfmt398-check", argv + ["--check"] + [str(TEMP / p) for p in paths], MAIN)
before = {
    p: gzip.decompress((OWN / "before" / (p.replace("/", "__") + ".gz")).read_bytes())
    for p in composition["existing"]
}
post = {p: bound(TEMP / p)[0] for p in paths}
position = paths[0]
old, after = before[position].decode(), post[position].decode()
protected = []
for name, start, end in [
    ("395legal", "    pub fn legal_pawn_mask", "    pub fn play"),
    ("395wall_edges", "    fn with_wall(", "/// Caller-local obstacle graph"),
    ("395wall_posts", "/// Caller-local obstacle graph", None),
]:
    a = old[old.index(start) : old.index(end) if end is not None else len(old)]
    b = after[after.index(start) : after.index(end) if end is not None else len(after)]
    assert a == b, f"protected {name} changed"
    protected.append(
        {
            "scope": name,
            "bytes": len(a.encode()),
            "before_after_sha256": hashlib.sha256(a.encode()).hexdigest(),
        }
    )
nnue_lib = "crates/quoridor-nnue/src/lib.rs"
assert post[nnue_lib].startswith(before[nnue_lib]), "NNUE production/model/math changed"
protected.append(
    {
        "scope": "NNUE lib original whole body byte-preserved; test module only appended",
        "bytes": len(before[nnue_lib]),
        "before_after_sha256": hashlib.sha256(before[nnue_lib]).hexdigest(),
    }
)
forward = ""
inverse = ""
for p in paths:
    a, b = before.get(p, b""), post[p]
    forward += "".join(
        difflib.unified_diff(
            a.decode().splitlines(True),
            b.decode().splitlines(True),
            fromfile="a/" + p if p in before else "/dev/null",
            tofile="b/" + p,
        )
    )
    inverse += "".join(
        difflib.unified_diff(
            b.decode().splitlines(True),
            a.decode().splitlines(True),
            fromfile="a/" + p,
            tofile="b/" + p if p in before else "/dev/null",
        )
    )
(OWN / "forward.patch").write_text(forward)
(OWN / "inverse.patch").write_text(inverse)
CHECK.mkdir()
for p, data in before.items():
    target = CHECK / p
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
command(
    "patch398-forward",
    [str(PATCH), "--batch", "--fuzz=0", "-p1", "-i", str(OWN / "forward.patch")],
    CHECK,
)
assert all((CHECK / p).read_bytes() == post[p] for p in paths)
command(
    "patch398-inverse",
    [str(PATCH), "--batch", "--fuzz=0", "-p1", "-i", str(OWN / "inverse.patch")],
    CHECK,
)
assert all((CHECK / p).read_bytes() == before[p] for p in before)
assert all(not (CHECK / p).exists() for p in new)
for binding in current + tools + config:
    _, actual = bound(Path(binding["path"]))
    assert actual == binding, binding["path"]
post_refs = []
for p in paths:
    post_refs.append(
        {
            "path": str(MAIN / p),
            "sha256": hashlib.sha256(post[p]).hexdigest(),
            "bytes": len(post[p]),
            "mode": "0644",
            "state": "PROPOSED_NOT_MAIN",
        }
    )
# Keep only new subjects plus thin patches and compressed original reconstruction.
for p in new:
    (OWN / Path(p).name).write_bytes(post[p])
for root, data in ((TEMP, post), (CHECK, before)):
    expected = {root / p for p in data}
    actual = {p for p in root.rglob("*") if p.is_file() or p.is_symlink()}
    assert actual == expected, "unknown temporary subject retained"
    for path in expected:
        assert path.read_bytes() == data[str(path.relative_to(root))]
        path.unlink()
    for directory in sorted(
        (p for p in root.rglob("*") if p.is_dir()),
        key=lambda p: len(p.parts),
        reverse=True,
    ):
        directory.rmdir()
    root.rmdir()
result = {
    "issue": "quoridor-4lc.398.1",
    "status": "SOURCE_STATIC_PASS",
    "current_before_refs": current,
    "proposed_after_refs": post_refs,
    "before_recovery": [bound(p)[1] for p in sorted((OWN / "before").glob("*.gz"))],
    "forward_patch": bound(OWN / "forward.patch")[1],
    "inverse_patch": bound(OWN / "inverse.patch")[1],
    "tools": tools,
    "rustfmt_configuration": config,
    "protected_bytes": protected,
    "new_Main_files_absent_before_after": new,
    "roundtrip": "GNU patch fuzz=0 forward/inverse exact bytes; new-file absence restored",
    "commands": commands,
    "temporary_source_and_roundtrip_removed": True,
    "native": "UNBUILT/UNTYPED/UNRUN",
    "actual_geometry_Search_model_calls": 0,
    "storage_budget": None,
    "mixed": "USERPAUSE",
}
(OWN / "source-static-result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
print(
    json.dumps(
        {
            "status": result["status"],
            "result": bound(OWN / "source-static-result.json")[1],
        }
    )
)
