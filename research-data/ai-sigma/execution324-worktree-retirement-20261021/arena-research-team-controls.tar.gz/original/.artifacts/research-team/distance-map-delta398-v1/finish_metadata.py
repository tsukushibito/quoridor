"""Saved OWN source facts only; no canonical/native/model reader or execution."""

import hashlib
import json
import re
import resource
from datetime import datetime, timezone
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
OWN = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    assert len(data) <= 2 * 1024**2
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


def document(path):
    return json.loads(path.read_bytes())


core_names = re.findall(
    r"fn (wall398_\w+)\(", (OWN / "distance_geometry398_tests.rs").read_text()
)
nnue_names = re.findall(
    r"fn (wall398_\w+)\(", (OWN / "distance_delta398_tests.rs").read_text()
)
assert len(core_names) == 4 and len(nnue_names) == 2
base = [
    "cargo",
    "test",
    "--offline",
    "--locked",
    "-j1",
    "--manifest-path",
    "/workspaces/quoridor/Cargo.toml",
    "--message-format=json-render-diagnostics",
]
verification = {
    "issue": "quoridor-4lc.398.1",
    "native": "UNBUILT/UNTYPED/UNRUN",
    "selected_commands": [
        {
            "argv": base
            + [
                "-p",
                "quoridor-core",
                "--lib",
                "--features",
                "research",
                "wall398_",
                "--",
                "--test-threads=1",
            ],
            "expected_named_passes": core_names,
            "expected_count": 4,
        },
        {
            "argv": base
            + [
                "-p",
                "quoridor-nnue",
                "--lib",
                "--features",
                "research",
                "wall398_",
                "--",
                "--test-threads=1",
            ],
            "expected_named_passes": nnue_names,
            "expected_count": 2,
        },
    ],
    "required_expected_counts": {
        "failed": 0,
        "ignored": 0,
        "measured": 0,
        "cargo_build_finished": True,
    },
    "existing_owning_tests": "Mechanical391 API/private-field migrations compile only; no old successful11suite replay",
    "required_current_software": "Root existing normal core/NNUE/AI research and research-diagnostics compile/Clippy, genuine optimized artifact on one source. Do not invent another target or image port.",
    "limited_review": "Private cache lineage, simultaneous two-edge DAG invalidation, unequal seed/minimum label/tie support, early exact BFS fallback, immutable parent/new key/stale child/partial error/model ownership.",
    "later_finite_comparison": "Root actual latest accepted O + only398 N, approved Control ONNO24/12sessions72M; allCOMPLETE mandatory+all30work MATCH, whole Nmedian<=O and no same-root bothN>Omedian1.10. No extra calls/refill/sweep.",
    "size_alignment_copy_hit_skip_profit": "UNKNOWN/UNRUN; source-work bound is not timing",
    "author_native_geometry_Search_model_calls": 0,
    "mixed_USERPAUSE": True,
}
(OWN / "verification-plan.json").write_text(
    json.dumps(verification, ensure_ascii=False, indent=2) + "\n"
)
guards = [
    document(OWN / folder / "receipt.json")
    for folder in [
        "intake-guard-v1",
        "format-guard-v1",
        "format-guard-v2",
        "format-guard-v3",
    ]
]
binding = {
    "issue": "quoridor-4lc.398.1",
    "status": "FROZEN_SOURCE_READY_INTEGRATION_UNVERIFIED",
    "patch": ref(OWN / "forward.patch"),
    "inverse": ref(OWN / "inverse.patch"),
    "current_before_proposed_after_protected_scope_and_roundtrip": ref(
        OWN / "source-static-result.json"
    ),
    "report": ref(OWN / "report-ja.md"),
    "verification": ref(OWN / "verification-plan.json"),
    "source_intake": ref(OWN / "intake.json"),
    "selected_source_guard": ref(OWN / "format-guard-v3/receipt.json"),
    "retained_preformatter_failures": [
        ref(OWN / folder / "receipt.json")
        for folder in ["format-guard-v1", "format-guard-v2"]
    ],
    "Main_write": False,
    "native": "UNBUILT/UNTYPED/UNRUN",
    "author_actual_geometry_Search_model_calls": 0,
    "leaf": "in_progress until required actual integration verification/acceptance",
    "review_dispatch": "324 only after frozen source; author did not dispatch",
    "original393_failure_and_rollback": "IMMUTABLE",
    "mixed_learner_323": "USERPAUSE",
}
(OWN / "source-binding.json").write_text(
    json.dumps(binding, ensure_ascii=False, indent=2) + "\n"
)
originals = []
for guard in guards:
    for check in guard["checks"]:
        returned = check["guardian_return"]
        persisted_ref = check["persisted_process_receipt"]
        assert ref(Path(persisted_ref["path"])) == persisted_ref
        persisted = document(Path(persisted_ref["path"]))
        child = returned["child"] if returned is not None else persisted["child"]
        originals.append(
            {
                "origin": check["name"],
                "identity": child,
                "returned_guardian": returned,
                "persisted_receipt": persisted_ref,
                "returned_versus_persisted": "distinct; NULL return is retained as NULL",
                "fullcapture": check["full_log"],
                "capture_complete": check["capture_complete"],
            }
        )
for fact in document(OWN / "source-static-result.json")["commands"]:
    originals.append(
        {
            "origin": fact["name"],
            "identity": fact["identity"],
            "directwait_exit": fact["directwait_exit"],
            "reaped": fact["reaped"],
            "handles_closed": fact["handles_closed"],
        }
    )
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
for fact in originals:
    original = fact["identity"]
    if original is None:
        fact["fresh_exact_identity"] = (
            "UNKNOWN: not observed at creation; directwait exit retained"
        )
        continue
    p = Path("/proc") / str(original["pid"]) / "stat"
    try:
        current = {
            "pid": original["pid"],
            "start_ticks": p.read_text().rsplit(")", 1)[1].split()[19],
            "boot_id": boot,
        }
    except FileNotFoundError:
        current = None
    assert current != original, "original command still present"
    fact["fresh_exact_identity"] = current
temporary = [OWN / "temporary-edited-subjects"] + [
    OWN / f"{folder}/TMP"
    for folder in [
        "intake-guard-v1",
        "format-guard-v1",
        "format-guard-v2",
        "format-guard-v3",
    ]
]
assert all(not p.exists() for p in temporary)
# One directed affected-scope observation; never walk assets/cache/global data.
files = [p for p in OWN.rglob("*") if p.is_file()]
usage = {
    "scope": str(OWN),
    "files": len(files),
    "allocated_B": sum(p.stat().st_blocks * 512 for p in files),
    "apparent_B": sum(p.stat().st_size for p in files),
    "storage_budget": None,
    "excluded": "This finalSTOP plus subsequent tiny handoff/admin receipt; all untouched assets/cache/privateimages/TMP/globaldata",
    "abnormal_growth": False,
    "global_actual_and_peak": "UNKNOWN; not scanned",
}
stamp = datetime.now(timezone.utc).isoformat()
stop = {
    "issue": "quoridor-4lc.398.1",
    "source_binding": ref(OWN / "source-binding.json"),
    "original_source_model_caller_reader_STOP": guards[-1][
        "actual_source_caller_env_reader_STOP"
    ],
    "actual_canonical_release": guards[-1]["actual_canonical_release"],
    "environment_independent_release_UTC": "UNKNOWN; selected common-entry wrapper returned normally",
    "actual_original_command_fresh_observation_and_private_metadata_STOP": stamp,
    "source_command_facts": originals,
    "outer_wrapper": "Original guarded invocation directwait exit0; PID/start not separately recorded. No fresh outer identity invented.",
    "temporary_paths_absent": [str(p) for p in temporary],
    "owned_readers_writers_children_jobs_TMP_handles_leases_remaining": [],
    "reservation": None,
    "source_controller_seconds_once": [
        {"status": g["status"], "seconds": g["controller_wall_seconds_once"]}
        for g in guards
    ],
    "nested_command_walls": "recorded in original receipts, excluded from controller cost sum",
    "postusage_once": usage,
    "native": "UNBUILT/UNTYPED/UNRUN",
    "author_actual_geometry_Search_model_calls": 0,
    "Main_source_writes": False,
    "394_admin_close": "Metadata-only canonicalfbcf40c2 and original0419/b474/de7bf matched, own394.1 CLOSED and backup synced; original STOP unchanged",
    "mixed_learner_323": "USERPAUSE",
}
(OWN / "STOP.json").write_text(json.dumps(stop, ensure_ascii=False, indent=2) + "\n")
metadata = {
    "dashboard": {
        "stage": "Frozen geometry candidate source/static verification ready",
        "wait_kind": "dependency",
        "next_action": "324 sparse integration, affected6 native definitions/compile/Clippy/artifact and limitedgeometry review then authorized finiteONNO24",
        "wait_reason": "Source only. Native UNBUILT/UNTYPED/UNRUN; geometry profit/size/hits UNKNOWN; no author science entry",
        "runtime_dirs": [],
        "evidence_paths": [
            str(OWN / name)
            for name in [
                "source-binding.json",
                "report-ja.md",
                "verification-plan.json",
                "STOP.json",
            ]
        ],
    }
}
(OWN / "dashboard.json").write_text(
    json.dumps(metadata, ensure_ascii=False, indent=2) + "\n"
)
receiver = document(OWN / "current324.json")[0]
assert receiver["id"] == "quoridor-4lc.324"
thread = receiver["assignee"].removeprefix("codex:")
assert thread == "01a1376a-bfd3-75d2-bd64-61e9416b3b13"
body = (
    f"398.1 fixed source ready: patch {binding['patch']['sha256']}/{binding['patch']['bytes']}, "
    f"binding {ref(OWN / 'source-binding.json')}, report {ref(OWN / 'report-ja.md')}, "
    f"STOP {ref(OWN / 'STOP.json')}. "
    "Output-row/min-label pending<=4 + shared frontier routes; no81bucket init, early source-work fallback before distance copy/small repair. "
    "395legal/WallEdges/WallPosts and NNUE original lib/AI caller byteexact; GNU forward/inverse/newabsence+Rustfmt PASS. "
    "core4+NNUE2 newdefinitions UNBUILTUNTYPEDUNRUN; no actualgeometry/Search/model/native. "
    "Source readerSTOP11:37:24.894728Z/canonicalrelease.895563; allknown originalcommand identities freshly absent/different/directwait/handles, allTMP/sourceTEMP/leases[]; no idlehold. "
    "Original preformatter tool-size/AS-inheritance refusals retained. New-file absence field erratum in report: intake/noMainwrite, not separatefreshafterprobe. "
    "Savedmetadata160B information/fullconstruction maintenance/copy/hits/benefit remain UNKNOWN; sourcebound is not time. "
    "Please use current O plus398only N, necessary normalsoftware/relatedgeometryreview/approved ONNO24 through maintained Root ports. "
    "394.1 metadata-only acceptedfbcf40c2 +own0419/b474/de7bf verified, leaf CLOSED/backedup, originalSTOP unchanged. "
    "398 remainsin_progress for requiredacceptance; mixed/learner/323USERPAUSE unchanged. No Policycopy/replyACK."
)
(OWN / "completion-body.txt").write_text(body + "\n")
print(
    json.dumps(
        {
            "binding": ref(OWN / "source-binding.json"),
            "STOP": ref(OWN / "STOP.json"),
            "usage": usage,
            "recipient": thread,
        },
        ensure_ascii=False,
    )
)
