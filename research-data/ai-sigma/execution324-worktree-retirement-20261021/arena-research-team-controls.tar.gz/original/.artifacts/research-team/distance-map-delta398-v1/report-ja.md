398 私有source候補：出力距離行による少数ラベル修復とfrontier方向maskの共用

一候補を実装し、project edition2024の対象Rustfmt、GNU patchのforward/inverse byte一致・新file撤去、395保護領域とNNUEモデル本体のbyte一致まで確認した。Mainには未適用。nativeは **UNBUILT / UNTYPED / UNRUN**、実geometry/Search/model/Perf/game呼出しは0。速度・採用・型検証の証拠ではない。

現在Mainの391局所不変geometry＋395合法手を直接beforeとしている。393のposition全postimageは使っていない。AI callerはintakeに束縛したalphabeta657b6ae5/126346Bのまま一致。TT397、history/scoring/runner、モデル・FT加算順、合法手順序、既存validation/error/cancelは変更しない。混合/learner/323 USERPAUSEを維持する。

| 指摘された費用 | 今回の変更 | 残る費用・限界 |
|---|---|---|
| 少数セルでも81×u128を初期化 | 修復の候補ラベルを必要な出力距離行に置き、pending u128から最小距離のfrontierを選ぶ。1296B/playerのbucket配列・heap・世代管理を使わない。異なる境界seedを距離順に扱う。 | partial/不変rowの81Bコピー、最大4セルのpending最小値走査、scalarの初期boundary処理は残る。実stack/layout/命令数は未測定。 |
| marked初期化・boundary・確定・下降再構成の重複 | 初期distance・boundary・支持方向を同じneighbor走査で設定する。確定frontierから一度作る4方向source maskを、候補ラベル更新と全同距離下降linkの更新に共用。別のsettled distance代入走査、settled-cellのneighbor再導出、post-map81走査を外す。 | 初期markedごとのexpand＋neighbor確認、pending最小値走査、adjacent候補のラベル確認は必要。すべての走査を消したとは主張しない。 |
| 広域判定後に部分準備してfull BFS | 無効化伝播中に単一の事前固定した処理量判定を行い、超過時はそのrowをcanonical BFSへ直接戻す。row距離コピー・少数修復準備・全parent cloneを先行しない。 | 各rowの4×u128下降maskを局所コピーし、塞いだedgeと無効化の判定を行う費用は残る。広域full BFSには下降metadata構築も必要。切替の時間交差点はUNKNOWN。 |
| hit/不変row/追加情報の維持 | parent-after/child-after exact hitとparent優先を最初に保持。strict追加は保存WallEdgesへ2edgeをORし、wall一覧からの再構築をしない。距離不変でも閉じた下降edgeは除き、new wall key/new Arcで公開する。 | 新metadataは方向128B＋edges32Bの情報本体160B。初期BFSの各layerで4方向maskを構築し、新Arc/row/maskコピーは残る。391にもrow copy/new Arcがあり、その全費用を新削減とは数えない。alignment/Arc総size/実copy codegen/hit頻度/BFS skip/部位利益はUNKNOWN。 |

切替は `m(m+1)/2 + 16m <= 81` の一つに固定した。mは無効化されたセル数。候補ラベル最小値走査の上限は三角数、initial neighbor確認・支持direction書込・relax候補・frontier direction処理を最大16mの仕事単位とする。これによりpartialはm≤4、超過時は伝播を止めて全BFSへ戻る。これは81セルの全row準備と比較する保守的な**source上の仕事量方針**であり、異なる仕事単位を同じcycleとする証明でも、wall-key/無効化/コピー/Arcを含む全時間上限でもない。複数閾値を測るsweepは行っていない。

正しさの境界は次の通り。

- 全BFSは一つの既存bitparallel kernelに任意下降metadata出力を加える。NNUE cacheの構築時は前layerと現在layerからlinkを同時に作り、後付け81セル走査はしない。plain row利用はmetadataなし。None分岐やprevious変数の最適化後費用は未測定で、固定Dへの利益は推定しない。
- 真正private immutable cacheのwall keyと正確な距離・下降DAGを使用する。public mutable Features/任意距離表を信頼するAPIは残さず、既存raw-row追加APIと専用retains_distancesを退役し、実callerと391 owning testsの呼出しだけを機械移行した。
- 一枚H/V追加の2edgeを同時に消し、全下降supportを失った正距離セルだけをmarkする。goal0/unreachable81には元linkがない。代替supportで伝播を止める。親cacheは書き換えない。
- 未mark領域の確定距離を境界seedにし、pendingの最小ラベルを選ぶ。同じ距離のfrontierを一括確定してrelax/link構築を行う。無効化された有限old DAGセルは距離が厳密に増えるので、伝播時に除いたunmarked→marked旧linkが新下降linkになることはない。全metadataの再走査を避ける根拠はこの不変条件であり、単に最終距離が合ったことではない。
- 非一枚追加・削除・置換・multi差分はcanonical経路。pawnでは元Arcを共有。stale childは真正parentに使わず、exact destination hitは元の順序で優先。partial accumulatorがerrorで残っても評価に使わず、元のModel/形状/finite/transition検査と後続完全overwrite・undoを保持する。

新しいsoftware選択はcore4定義＋NNUE2 toy FT/geometry定義のみ（verification-plan.json）。独立cellqueue oracleの距離と実open-edgeによる全4方向link照合、unequal seedの最小順、2edgeのpartial/fallback混在、代替link、不達/goal/border/wide、strict/nonadd/key/親不変、full/delta FT bits、exacthit/一般Features/model error/partial overwrite/undoを対象にした。最初のseed定義は同じgraph上の4セルを不確定領域として再修復し、順序を直接検査する。実wall削除によるmarkは別の定義で検査する。authorはどの定義も実行していない。旧391/387/393成功定義は名前・意味を保持し、変更APIの必要compileだけで、旧11suiteの自動再演は求めない。

限定geometry確認の質問は「opaque cacheの真正lineage、2edge無効化とDAG support、m≤4 repairの不等seed最小順とtie link、early full fallback、新key/immutable親、stale/partial/error/model ownershipが保たれるか」に絞る。authorからreviewをdispatchしない。Rootの真正software/Clippy/optimized Nと限定review、その後latest accepted O＋398のみNのONNO24で有限採否する。旧393の時間を今回Oへ転用しない。速度・一般利益・実hit分布・棋力/defaultは現時点UNKNOWN。

source実STOPはformat-guard-v3/receipt.jsonの2026-10-14T11:37:24.894728+00:00、canonical解放は11:37:24.895563。returned guardianはexit0/directreap/remaining[]/handles/capture/mask persist完了、persisted receiptは別ref。source temporaryとpatch-roundtripは除去し、空uv lockをinode/owner/no-open-FD/exclusive lock照合後に除去、TMPなし。環境SHの独立UTCはUNKNOWN、wrapper returnで終了する。

原失敗2件は不変で保持：format-v1はsource用512KiB上限をrustfmt本体に適用してformatter前に停止、format-v2はcomposeがworkerの320MiB AS hard limitを448MiBへ上げようとして停止。各guardはFAILED/directwait/STOP/cleanupの元記録を保持し、native0/formatter0。v3はツール本体の正常上限とAS継承だけを直した私有準備で、科学・native再実行ではない。source-static-result.jsonの`new_Main_files_absent_before_after`はintakeでの不在確認と、canonical保持中のMain非書込みを意味する。終了時の別fresh new-file probeは実施していないため、Root適用時は現実の新file不在を確認する。元生成receiptは書き換えない。

自然な398 sourceSTOP後、394.1はcanonical acceptance fbcf40c2/4448と原own binding0419/patchb474/STOPde7bfをmetadata-only照合し本人close/backupした。原394 STOPを398現在STOPへ変更していない。12calls/6sessionsの11COMPLETE1UNKNOWNと未読尾部の量はRoot受入れ済みの記述事実であり、時間利益・新最適化の採用ではない。398 leafは必要integration検証までin_progressを維持する。
