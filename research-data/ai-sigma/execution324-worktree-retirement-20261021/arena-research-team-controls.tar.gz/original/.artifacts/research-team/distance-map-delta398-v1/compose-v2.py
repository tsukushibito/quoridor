"""Sparse current-before transforms; no old393 position postimage is installed."""

import gzip
import json
import re
from pathlib import Path

OWN = Path(__file__).resolve().parent
TEMP = OWN / "temporary-edited-subjects"
paths = [
    "crates/quoridor-core/src/position.rs",
    "crates/quoridor-core/src/lib.rs",
    "crates/quoridor-nnue/src/features.rs",
    "crates/quoridor-nnue/src/lib.rs",
    "crates/quoridor-core/tests/wall_map391.rs",
]
original = {
    path: gzip.decompress(
        (OWN / "before" / (path.replace("/", "__") + ".gz")).read_bytes()
    ).decode()
    for path in paths
}
post = dict(original)


def once(text, old, new):
    assert text.count(old) == 1, old[:80]
    return text.replace(old, new, 1)


position = once(
    post[paths[0]],
    "use std::fmt;\n",
    'use std::fmt;\n\n#[path = "distance_geometry.rs"]\nmod distance_geometry;\npub use distance_geometry::WallDistanceGeometry;\n',
)
start = position.index(
    "    /// Reuse exact parent rows after strictly one H/V wall-bit addition."
)
end = position.index("    pub fn legal_pawn_mask", start)
position = (
    position[:start]
    + """    /// Private-lineage cached wall geometry; pawns and turn do not obstruct it.
    /// This is not legal-game or mutable-feature validation.
    pub fn wall_distance_geometry(self) -> WallDistanceGeometry {
        WallDistanceGeometry::of(self)
    }
"""
    + position[end:]
)
position = once(
    position,
    "#[derive(Clone, Copy)]\nstruct WallEdges",
    "#[derive(Clone, Copy, Debug, PartialEq, Eq)]\nstruct WallEdges",
)
start = position.index(
    "    // One reverse BFS implementation for both full rebuild and changed rows."
)
end = position.index("    fn with_wall(", start)
position = (
    position[:start]
    + """    // One canonical reverse BFS. Plain callers construct no descent metadata.
    fn distance_map(&self, player: usize) -> [u8; 81] {
        self.distance_map_with_descent(player, None)
    }
    fn distance_map_and_descent(&self, player: usize) -> ([u8; 81], [u128; 4]) {
        let mut descent = [0; 4];
        let row = self.distance_map_with_descent(player, Some(&mut descent));
        (row, descent)
    }
    fn distance_map_with_descent(&self, player: usize, mut descent: Option<&mut [u128; 4]>) -> [u8; 81] {
        let mut result = [81u8; 81];
        let mut frontier = if player == 0 { 0x1ffu128 << 72 } else { 0x1ff };
        let mut previous = 0;
        let mut reached = frontier;
        let mut distance = 0;
        while frontier != 0 {
            if let Some(links) = descent.as_deref_mut() {
                let sources = distance_geometry::descent_sources(self, previous);
                for direction in 0..4 { links[direction] |= frontier & sources[direction]; }
            }
            let mut cells = frontier;
            while cells != 0 {
                result[cells.trailing_zeros() as usize] = distance;
                cells &= cells - 1;
            }
            previous = frontier;
            frontier = self.expand(frontier) & !reached;
            reached |= frontier;
            distance += 1;
        }
        result
    }
"""
    + position[end:]
)
post[paths[0]] = position
post[paths[1]] = once(
    post[paths[1]],
    "pub use position::{Action, Position, RULESET_ID, RulesError};",
    "pub use position::{Action, Position, RULESET_ID, RulesError, WallDistanceGeometry};\n\n// Reuse the unchanged independent cell-queue oracle in private geometry tests.\n#[cfg(test)]\nextern crate self as quoridor_core;",
)
features = once(
    post[paths[2]],
    "use quoridor_core::Position;",
    "use quoridor_core::{Position, WallDistanceGeometry};",
)
features = once(
    features,
    "    horizontal: u64,\n    vertical: u64,\n    distances: [[u8; 81]; 2],\n",
    "    geometry: WallDistanceGeometry,\n",
)
features = once(
    features,
    "        (self.horizontal == p.horizontal && self.vertical == p.vertical).then_some(&self.distances)",
    "        self.geometry.distances_for(p)",
)
start = features.index("    let distances = parent\n")
end = features.index("\n}\n\nfn distance(", start)
features = (
    features[:start]
    + """    let geometry = parent
        .filter(|(before, maps)| maps.distances_for(*before).is_some())
        .and_then(|(_, maps)| maps.geometry.after_addition(p))
        .unwrap_or_else(|| p.wall_distance_geometry());
    Arc::new(WallMaps { geometry })"""
    + features[end:]
)
features = once(
    features,
    '    if maps.horizontal != p.horizontal || maps.vertical != p.vertical {\n        return Err(Error::Input("integer distance wall-map mismatch".into()));\n    }\n',
    '    let rows = maps.distances_for(p).ok_or_else(|| Error::Input("integer distance wall-map mismatch".into()))?;\n',
)
features = (
    features.replace("maps.distances[player]", "maps.geometry.distances()[player]")
    .replace("maps.distances[side]", "rows[side]")
    .replace("maps.distances[side ^ 1]", "rows[side ^ 1]")
)
# Existing tests remain their original names/scopes; only their moved private
# fields change. New native selection does not replay these successful tests.
features = (
    features.replace(
        "fresh.distances, parent.distances",
        "fresh.geometry.distances(), parent.geometry.distances()",
    )
    .replace(
        "miss.distances, after.wall_distance_maps()",
        "*miss.geometry.distances(), after.wall_distance_maps()",
    )
    .replace(
        "maps.distances, other.wall_distance_maps()",
        "*maps.geometry.distances(), other.wall_distance_maps()",
    )
)
post[paths[2]] = features
post[paths[3]] += (
    '\n#[cfg(all(test, feature = "research"))]\nmod distance_delta398_tests;\n'
)
test = re.sub(
    r"(\w+)\s*\.wall_distance_maps_after_addition\((\w+), &(\w+)\)",
    lambda m: f"{m[2]}.wall_distance_geometry().after_addition({m[1]}).map(|geometry| *geometry.distances())",
    post[paths[4]],
)
assert "wall_distance_maps_after_addition" not in test
strict = test.index("fn wall391_strict_addition")
test = test[:strict] + test[strict:].replace(
    "    let old = parent.wall_distance_maps();\n", "", 1
)
post[paths[4]] = test
new = {
    "crates/quoridor-core/src/distance_geometry.rs": "distance_geometry.rs",
    "crates/quoridor-core/src/distance_geometry398_tests.rs": "distance_geometry398_tests.rs",
    "crates/quoridor-nnue/src/distance_delta398_tests.rs": "distance_delta398_tests.rs",
}
for relative, name in new.items():
    post[relative] = (OWN / name).read_text()
TEMP.mkdir()
for relative, text in post.items():
    target = TEMP / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
(OWN / "composition-input.json").write_text(
    json.dumps(
        {
            "existing": paths,
            "new": list(new),
            "old393position_installed": False,
            "native": "UNBUILT/UNTYPED/UNRUN",
        },
        indent=2,
    )
    + "\n"
)
print(
    json.dumps({"status": "PRIVATE_COMPOSED", "existing": len(paths), "new": len(new)})
)
