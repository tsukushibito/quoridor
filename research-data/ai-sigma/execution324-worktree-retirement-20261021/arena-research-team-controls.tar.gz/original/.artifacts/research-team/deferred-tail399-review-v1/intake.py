"""Reconstruct only the frozen review subjects in owned temporary storage."""

import gzip
import hashlib
import json
import resource
import subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
OWN = Path(__file__).resolve().parent
TARGET = Path(
    "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/deferred-tail399-v1/source-STOP.json"
)
TEMP = OWN / "review-TEMP"
observed = []


def read(binding):
    p = Path(binding["path"])
    with p.open("rb") as source:
        data = source.read(512 * 1024 + 1)
    assert len(data) <= 512 * 1024
    actual = {
        "path": str(p),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": format(p.stat().st_mode & 0o777, "04o"),
    }
    assert actual == binding, str(p)
    observed.append(actual)
    return data


stop_ref = {
    "path": str(TARGET),
    "sha256": "e7f55b27a4eb2cf8318b62675393bd00a514982195ae769e677b3bf162eb1d86",
    "bytes": 47168,
    "mode": "0644",
}
stop = json.loads(read(stop_ref))
refs = stop["refs"]
intake = json.loads(read(refs["current-intake.json"]))
proof = json.loads(read(refs["static-proof.json"]))
companion = json.loads(read(refs["measurement-companion.json"]))
report = read(refs["report.md"]).decode()
patch = read(refs["deferred-tail399.patch"])
read(refs["deferred-tail399.inverse.patch"])
companion_patch = read(refs["measurement-companion.patch"]).decode()
before_fragment = read(refs["measurement-output-before.rs.fragment"]).decode()
after_fragment = read(refs["measurement-output-after.rs.fragment"]).decode()
subjects = stop["subjects"]
before_by_hash = {}
for name, r in refs.items():
    if name.endswith(".Main-before.gz"):
        data = gzip.decompress(read(r))
        assert len(data) <= 256 * 1024
        before_by_hash[hashlib.sha256(data).hexdigest()] = data
assert not TEMP.exists()
TEMP.mkdir()
for subject in subjects:
    if subject["before"] == "ABSENT":
        continue
    data = before_by_hash[subject["before"]["sha256"]]
    assert len(data) == subject["before"]["bytes"]
    target = TEMP / subject["relative"]
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
with (
    (OWN / "patch.stdout.log").open("xb") as out,
    (OWN / "patch.stderr.log").open("xb") as err,
):
    with subprocess.Popen(
        [
            "/usr/bin/patch",
            "--batch",
            "--fuzz=0",
            "-p1",
            "-i",
            refs["deferred-tail399.patch"]["path"],
        ],
        cwd=TEMP,
        stdout=out,
        stderr=err,
        close_fds=True,
    ) as child:
        p = Path("/proc") / str(child.pid) / "stat"
        identity = (
            None
            if not p.exists()
            else {
                "pid": child.pid,
                "start_ticks": p.read_text().rsplit(")", 1)[1].split()[19],
                "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
            }
        )
        code = child.wait()
assert code == 0, "static patch reconstruction failed"
after_refs = []
for subject in subjects:
    p = TEMP / subject["relative"]
    data = p.read_bytes()
    expected = subject["after"]
    assert (
        hashlib.sha256(data).hexdigest() == expected["sha256"]
        and len(data) == expected["bytes"]
    )
    after_refs.append(
        {
            "relative": subject["relative"],
            "sha256": expected["sha256"],
            "bytes": len(data),
        }
    )
for binding in list(observed):
    read(binding)
result = {
    "target": stop_ref,
    "target_refs_before_after": observed[: len(observed) // 2],
    "subject_before_after": subjects,
    "reconstructed_after_refs": after_refs,
    "intake_metadata": intake,
    "static_proof": proof,
    "measurement_companion": companion,
    "source_report": report,
    "new_tests": stop["new_tests"],
    "affected_tests": stop["affected_tests"],
    "source_reader_STOP_original": stop["source_guard_last_STOP"],
    "author_original_errors": [
        {"status": p["status"], "primary": p["primary"]}
        for p in stop["phases"]
        if p["status"] == "FAILED"
    ],
    "patch_tool_directwait": {
        "identity": identity,
        "exit": code,
        "directreaped": True,
        "handles_closed": True,
        "native_engine": False,
    },
    "review_TEMP": str(TEMP),
    "native": "UNBUILT/UNTYPED/UNRUN",
}
(OWN / "intake.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
(OWN / "companion-review.txt").write_text(
    companion_patch + "\nBEFORE\n" + before_fragment + "\nAFTER\n" + after_fragment
)
print(
    json.dumps(
        {
            "status": "FROZEN_REVIEW_SUBJECTS_BOUND",
            "subjects": after_refs,
            "target": stop_ref,
        }
    )
)
