399 独立source確認：source_clear=true、blockers=0、ordinary=0。

対象はauthor source-STOP e7f55b27/47168、AI forward139dd2bc/34716・inverse3989e6ad/34716の5subjects、およびrunner measurement companion e9528769/5249（before22423996/42851）で固定した。私有gzip＋patchから5subjectsを一時再構成し、全after SHA/bytesを確認して読んだ。Main source、モデル、過去の科学RAW、archive payloadは読まず、native/test/Search/Perf/geometry/fitを実行していない。Rootのtest-only Policy lifetime修復b3ee1be8/1369とcomposition-v2 2d5198f4/2812は後着metadataとして別scopeで照合した。authorの元targetをこの修復へ書き換えていない。

| 確認した境界 | 判断と具体的根拠 |
|---|---|
| 必要性・範囲 | 全候補の採点は元時点のまま。Control/no-provider/signed内部nodeで先頭だけ必要な場合にtail整列を発行しない候補であり、未読数から採点全部を省けるとはしていない。rootは元eager、provider/policy/unsigned/Cheap/Coverageはeagerへ戻る。method/default/TT量/モデル変更はない。 |
| exact keyと全順序 | 既存Rankingの優先tier・goal/killer・policy total_cmp・signed/unsigned comparator・ID tieは独立にbefore/after byte一致を確認。元sort_controlのkey構築も、そのままcontrol_keysへ移動したbyte一致。signed32bitのXOR＋反転が降順を表し、rankのbit40以上、scoreのbit8..39、ActionIDの下位8bitが分離する。0..208の一意IDに対しkeyも一意なので、最小keyを先に選び、同じ保存keyで残りを並べれば元の総順序になる。 |
| tail一度・0/1・PVS | PreparedMovesは既存legal Vecを所有し、先頭をswapするだけで集合を変えない。cursor0で一度だけ最小選択、cursor1かつlist>2でtailを一度だけ整列する。空・1手・1要素tailはsortを発行せず元scoring/validationは通る。PVS同手再探索はnextの外にあり、distinct next/read/returnは一組。heap/Vecclone/全IDコピー/毎手線形選択/key再生成をproductionへ加えていない。 |
| key固定の時点 | 非TT経路は旧orderedと同じordering_scores時点。TT-firstがcutoffしなかった場合は、元childが親を復元した後、TT IDを除いたsiblingsを旧時点でprepareする。その時点のscore/rank/goal/killerから所有key配列を作り、以降の子history/killer更新を再参照しない。 |
| parent/error/cancel/数学 | control・enter・ordering_scores・child・root_depth、TT/合法手の準備前領域、子/PVSからhistory/TT publicationのepilogue、actor/lag/index/history算術/agingを独立before/after比較し11領域一致。childの評価失敗、control停止、checked undo、context/board復元の既存責務を保持する。次手要求はchildの復元・return後。undo失敗を正常parentと認定する追加経路はない。 |
| OFFとON | OFFではObservation/OrderingNodeWorkを作らず、baseline scan・observerだけのtail整列・ID snapshot/copyを発行しない。実keyとnextはON/OFF共通。core key保存はOFFにも必要な候補実装の費用であり、observer費用と混同しない。ONだけのfirst-choice baseline scanとscalar/histogram更新は明示されている。 |
| 診断の分母 | prepared actionsからTTを除外し、selectedと実sortedのdistinct reads/returnsを分ける。first_selection_calls/actionsは最初のmin処理、selected_reads/returnsは未整列の先頭**および1要素tail**、sorted_sizeは実eager listまたは実整列したtailだけ。ノード完了後の消費率は(selected+sorted)/prepared。途中error/cancelではstartedだけを残しfinishしない。TT-only child cutoffと、TT numeric cutoff/leafの早期returnは別scopeで、ordering nodesは全Search nodesの分母ではない。 |
| full-order比較とconsumer | history_changed/history_compared、static_changed/static_comparedは実eager整列時のadjacency比較だけ。deferredのfirst_choice_changed/comparedは同tier＋IDのhistory無し先頭との差だけで、tail関係はUNKNOWN。measurement companionは必要scalarと各分母を既存結果に出し、request/config/result選択権限を変更しない。旧394のordered_nodes分母やsorted数の意味を新結果へ移植してはいけない。新consumer/文書ではこの新分母、selectedの1要素tailを含む意味、OFF未観測をそのまま使用する。 |

新6定義は正本Ranking・明示tier期待値、全ID/符号極値/tie、policy±0/unsigned除外、first cutoffでsort無しと全消費時sort一度、history/killer変更後のkey固定、TT-first/PVS重複評価とdistinct消費分離、provider/空/1手/cancelの入口を扱う。影響394三定義はresidual TT除外、selected/tail/rootの実分母、停止/error/NodeLimitとparent復元を検査する。実装の旧loopやcomparatorを別oracleとしてコピーしていない。これらは必要native検証の対象であり、本reviewは定義を読んだだけで実行していない。

後着Root修復はlocal unit Policyをstatic unit POLICYへ替え参照を修正するfixture lifetime対応のみ。metadataのbeforeは元new-test44a66c1c、afterは3a81958dで一致し、productionとassertionが変わらない別scopeである。原v1 research compile PASS、diagnostics E0597 FAILED、8.445832476s・元mask/cleanup/captureは保持する。v2の実成功は本reviewから推論しない。

保存key本体209×8=1672Bが再帰中に生存する。enumの除外eager frameへの影響、padding/実copy/RSS/stack/cache、whole費用はUNKNOWN。局所large_enum_variant許可はnode毎heapを避ける明示判断であり、速度や最適性の証拠ではない。O/Nの同条件software・RAM・全work一致とRootの有限採否が別途必要。NNUE4K/BEST43とfixedD1Mの各ONNO24は別stratumであり、同じ8MでfixedDのD6未完成は原UNKNOWNのまま。source clearを採用/速度/棋力/defaultへ昇格しない。追加calls/sweep/review gateは発行しない。

実review reader STOPは2026-10-14T12:25:52.285794+00:00、environment reader解放観測12:25:52.285815。canonical/Main source leaseは取っていない。2回のguardはPASS、returned guardian/directwait/reap/handles/capture/mask-persistとpersisted receiptは別参照で保持。一時5subjectsをSHA再照合して削除し、空uv lockをowner/inode/no-open-FD/exclusive lock確認後に除去、TMP/reader/child/job/leaseは空。高速patch子の独立UTC/未捕捉PID、連続peakはUNKNOWNのまま。元author EAGAIN checks[]と後段NodeENOENT after earlierPASSも保持する。混合/learner sourceprep・全pipeline/323 USERPAUSE、defaults/models/N/seals/fits96/旧RAW/FAILED/fees/UNKNOWNを変更しない。
