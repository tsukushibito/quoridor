"""Independent static checks and exact removal of owned reconstruction subjects."""

import gzip
import hashlib
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
OWN = Path(__file__).resolve().parent
TEMP = OWN / "review-TEMP"
intake = json.loads((OWN / "intake.json").read_text())
refs = intake["target_refs_before_after"]
before = {}
for binding in refs:
    p = Path(binding["path"])
    data = p.read_bytes()
    assert (
        hashlib.sha256(data).hexdigest(),
        len(data),
        format(p.stat().st_mode & 0o777, "04o"),
    ) == (binding["sha256"], binding["bytes"], binding["mode"])
    if p.name.endswith(".Main-before.gz"):
        plain = gzip.decompress(data)
        before[hashlib.sha256(plain).hexdigest()] = plain.decode()
subjects = intake["subject_before_after"]
texts = {}
old = {}
expected_paths = set()
for s in subjects:
    p = TEMP / s["relative"]
    data = p.read_bytes()
    assert (
        hashlib.sha256(data).hexdigest() == s["after"]["sha256"]
        and len(data) == s["after"]["bytes"]
    )
    texts[s["relative"]] = data.decode()
    expected_paths.add(p)
    if s["before"] != "ABSENT":
        old[s["relative"]] = before[s["before"]["sha256"]]


def body(text, start, end):
    return text[text.index(start) : text.index(end, text.index(start))]


checks = []
alpha = "crates/quoridor-ai/src/alphabeta.rs"
for start, end in [
    ("    fn control(", "    fn enter("),
    ("    fn enter(", "    fn ordered("),
    ("    fn ordered(", "    fn ordering_scores("),
    ("    fn ordering_scores(", "    fn child("),
    ("    fn child(", "    fn negamax("),
    ("    fn root_depth(", "\n}\n"),
]:
    a = body(old[alpha], start, end)
    b = body(texts[alpha], start, end)
    if start == "    fn ordered(":
        b = b[: b.index("    fn prepared_moves(")]
    assert a == b, start
    checks.append(
        {
            "scope": start.strip(),
            "before_after_sha256": hashlib.sha256(a.encode()).hexdigest(),
        }
    )
for start, end in [
    ("        let alpha_original = alpha;", "        let mut deferred = None;"),
    ("            let mut v = if self.limits.use_pvs", "        Ok(value)\n"),
]:
    a = body(old[alpha], start, end)
    b = body(texts[alpha], start, end)
    assert a == b, start
    checks.append(
        {
            "scope": start.strip(),
            "before_after_sha256": hashlib.sha256(a.encode()).hexdigest(),
        }
    )
ordering = "crates/quoridor-ai/src/move_ordering.rs"
a = body(old[ordering], "impl<'a> Ranking", "    pub fn sort_control(")
b = body(texts[ordering], "impl<'a> Ranking", "    pub fn sort_control(")
assert a == b
checks.append(
    {
        "scope": "Ranking priority/goal/killer/policy total_cmp/signed/unsigned/comparator/ID and eager sort",
        "before_after_sha256": hashlib.sha256(a.encode()).hexdigest(),
    }
)
a = body(
    old[ordering], "        let mut keys = [0u64; 209];", "        ids.sort_unstable_by"
)
b = body(texts[ordering], "        let mut keys = [0u64; 209];", "        Some(keys)")
assert a == b
checks.append(
    {
        "scope": "Authoritative old Control composite key construction moved without changes",
        "before_after_sha256": hashlib.sha256(a.encode()).hexdigest(),
    }
)
history = "crates/quoridor-ai/src/continuation_history.rs"
a = body(old[history], "pub(super) const LAGS", "/// Observation-only work.")
b = body(texts[history], "pub(super) const LAGS", "/// Observation-only work.")
# New stats declarations precede all old arithmetic; compare the owning body.
a = a[a.index("/// Actual mover before make_move") :]
b = b[b.index("/// Actual mover before make_move") :]
assert a == b
checks.append(
    {
        "scope": "Actor/path indexing/history scoring/update/aging and original owning test bodies",
        "before_after_sha256": hashlib.sha256(a.encode()).hexdigest(),
    }
)
actual = {p for p in TEMP.rglob("*") if p.is_file() or p.is_symlink()}
assert actual == expected_paths, "unknown review temporary subject"
for p in expected_paths:
    p.unlink()
for p in sorted(
    (p for p in TEMP.rglob("*") if p.is_dir()), key=lambda p: len(p.parts), reverse=True
):
    p.rmdir()
TEMP.rmdir()
(OWN / "independent-static-checks.json").write_text(
    json.dumps(
        {
            "status": "STATIC_MATCH",
            "checks": checks,
            "target": intake["target"],
            "reconstructed_sources_removed": True,
            "source_clear_is_not_native_correctness_or_speed": True,
            "native_type_tests": "UNBUILT/UNTYPED/UNRUN",
            "author_native_Search_model_calls": 0,
        },
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "status": "STATIC_MATCH",
            "protected_checks": len(checks),
            "review_TEMP_removed": True,
        }
    )
)
