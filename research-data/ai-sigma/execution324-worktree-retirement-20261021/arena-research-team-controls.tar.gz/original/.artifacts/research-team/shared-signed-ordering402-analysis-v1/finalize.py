"""Bind the original outer result and final metadata; no journal reanalysis."""

import collections
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
from saved_reader import ORIGINS, lc  # noqa: E402

OWN = Path(__file__).resolve().parent
root = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/shared-signed-ordering402-v1/arena128-v1"
)
refs = json.loads((OWN / "selectedrefs.json").read_text())
outer_ref, outer_raw = lc.bound(root / "job/result.json")
outer = json.loads(outer_raw)
assert outer["exit_code"] == 0 and outer["cleanup_complete"] is True
assert abs(outer["wall_seconds"] - 689.0777808060084) < 1e-9
assert not outer.get("cleanup_errors")
refs.append(outer_ref)
(OWN / "selectedrefs.json").write_text(
    json.dumps(refs, ensure_ascii=False, indent=2) + "\n"
)
result = json.loads((OWN / "result.json").read_text())
games = json.loads((OWN / "game-index.json").read_text())
assert len(games) == 128 and sorted(g["slot"] for g in games) == list(range(128))
assert all(
    g["started"] and g["status"] == "goal" and g["failure"] is None for g in games
)
assert (
    len(result["batches"]) == 8
    and result["complete_pairs"] == 64
    and result["unknown_games"] == 0
)
for b in result["batches"]:
    assert b["lifecycle_status_original"] == "PASS" and b["tt_entries"] == 1048576
    census = collections.Counter(
        (g["family_id"], g["candidate_colour"])
        for g in games
        if g["batch"] == b["batch"]
    )
    assert len(census) == 16 and all(v == 1 for v in census.values())
    assert all(
        (f, c) in census for f in (23, 29, 34, 46, 64, 93, 105, 108) for c in (0, 1)
    )
assert (
    sum(
        r["counts"]["accepted"]
        for r in result["method_exposures_not_independent"].values()
    )
    == 6679
)
result["original_outer_job_result"] = outer_ref
result["original_outer_controller_seconds_once"] = outer["wall_seconds"]
result["whole_wall_scope"] = (
    "689.0777808060084s original outer controller once; native/per-operation/analysis clocks retained separately and not added"
)
(OWN / "result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
with (OWN / "report.md").open("a") as report:
    report.write(
        "\n原outer job04a9925cの689.077780806秒はcontroller wholeとして一度だけ記録し、内包native/operation時間や今回saved解析費を加算しない。exit0だけで対局PASSとせず、8original final manifestsと保存consumerの128局照合を根拠とした。\n\n"
    )
    report.write(
        "|method|receipt期限余裕中央値ms|receipt→terminal return中央値ms|caller n/中央値秒|\n|---|---:|---:|---|\n"
    )
    for method, r in result["method_exposures_not_independent"].items():
        report.write(
            f"|{method}|{r['deadline_minus_actual_receipt_ms']['median']:.3f}|{r['returned_minus_actual_receipt_ms']['median']:.3f}|{r['caller_seconds']['n']}/{r['caller_seconds']['median']:.6f}|\n"
        )
    report.write(
        "\nreceiptとterminal完了は別の時点。receiptは全件deadline未満だがterminalはdeadline後まで続き得る。これは保存したexact drain/次turn前のjoinと整合し、遅い完成を選択したという意味ではない。\n"
    )
processes = {}


def collect(value):
    if isinstance(value, dict):
        if all(k in value for k in ("pid", "start_ticks", "boot_id")):
            processes[(value["pid"], str(value["start_ticks"]), value["boot_id"])] = (
                value
            )
        for v in value.values():
            collect(v)
    elif isinstance(value, list):
        for v in value:
            collect(v)


receipts = []
for path in sorted(OWN.glob("*/*.process.json")):
    if path.parent.name == "finalize-guard-v1":
        continue
    binding, raw = lc.bound(path)
    receipts.append(binding)
    collect(json.loads(raw))
for n in ("consumer-origins.json", "source-semantics.json"):
    collect(json.loads((OWN / n).read_text()))
for path in sorted(OWN.glob("*-guard-*/receipt.json")):
    if path.parent.name != "finalize-guard-v1":
        collect(json.loads(path.read_text()))
facts = []
for old in processes.values():
    now = lc.process.identity(lc.process.process_info(old["pid"]))
    assert now != old, (old, now)
    facts.append(
        {
            "original": old,
            "fresh": now,
            "state": "ABSENT" if now is None else "DIFFERENT_IDENTITY",
        }
    )
assert lc.read_ref(outer_ref) == outer_raw
validation = json.loads((OWN / "presentation-validation.json").read_text())
validation["final_unique_colourpair_mapping"] = True
validation["outer_job_result"] = outer_ref
validation["final_file_refs"] = [
    lc.bound(OWN / n, max(1024 * 1024, (OWN / n).stat().st_size))[0]
    for n in (
        "report.md",
        "result.json",
        "game-index.json",
        "selectedrefs.json",
        "source-semantics.json",
    )
]
(OWN / "final-validation.json").write_text(
    json.dumps(validation, ensure_ascii=False, indent=2) + "\n"
)
(OWN / "owned-readers-STOP.json").write_text(
    json.dumps(
        {
            "checked_at": lc.stamp(),
            "original_guardian_records": receipts,
            "fresh_original_reader_children": facts,
            "finalizer_current_child": "still owned by guard until actual return; final guard receipt binds its later directwait/reap/handles/TMP cleanup",
            "immutable_guard_source_origins": ORIGINS,
            "canonical_lease": False,
            "model_Search_native_geometry_bootstrap_calls": 0,
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "games": 128,
            "pairs": 64,
            "accepted": 6679,
            "outer_original": outer_ref,
            "fresh_original_source_children": len(facts),
        }
    )
)
