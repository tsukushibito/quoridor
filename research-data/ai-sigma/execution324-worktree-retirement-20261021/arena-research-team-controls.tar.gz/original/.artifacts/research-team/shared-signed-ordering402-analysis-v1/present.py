"""Present already validated saved128 facts; named immutable source semantics only."""

import collections
import hashlib
import json
import math
import resource
import stat
import subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }


def measured(values):
    if not values:
        return {"n": 0, "median": None, "mean": None}
    values = sorted(values)
    n = len(values)
    return {
        "n": n,
        "median": (values[(n - 1) // 2] + values[n // 2]) / 2,
        "mean": math.fsum(values) / n,
    }


bindings = [
    ref(OWN / n) for n in ("result.json", "game-index.json", "selectedrefs.json")
]
result = json.loads((OWN / "result.json").read_text())
games = json.loads((OWN / "game-index.json").read_text())
selected = json.loads((OWN / "selectedrefs.json").read_text())
assert len(games) == 128 and len({g["slot"] for g in games}) == 128
sources = []
snippets = {}
for relative, keys in [
    (
        "crates/quoridor-ai/src/alphabeta.rs",
        [
            "pub fn set_lmr",
            "pub fn lmr_enabled",
            "LMR_METHOD",
            "ordering_parent_maps",
            "parent_wall_distances",
            "wall_distances_for_both",
            "fn namespace",
            "pub fn new_with_ordering",
        ],
    ),
    (
        "crates/quoridor-ai/src/cheap_static_ordering.rs",
        [
            "pub",
            "score +=",
            "scores[",
            "parent_maps",
            "advance",
            "progress",
            "pawn",
            "walls",
            "stock",
            "distance",
        ],
    ),
]:
    argv = [
        "git",
        "-C",
        "/workspaces/quoridor",
        "show",
        "93cbcd70b3a30ba3dc69ef0f1c45f6ee1b201f36:" + relative,
    ]
    child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        info = Path("/proc") / str(child.pid) / "stat"
        identity = {
            "pid": child.pid,
            "start_ticks": info.read_text().rsplit(")", 1)[1].split()[19],
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        }
    except FileNotFoundError:
        identity = None
    try:
        data, error = child.communicate()
        assert child.returncode == 0, error.decode()
    finally:
        child.stdout.close()
        child.stderr.close()
    assert len(data) < 256 * 1024
    sources.append(
        {
            "Git": "93cbcd70b3a30ba3dc69ef0f1c45f6ee1b201f36",
            "path": relative,
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
            "argv": argv,
            "identity": identity,
            "directwait_exit": child.returncode,
            "reaped": True,
            "handles_closed": True,
        }
    )
    lines = data.decode().splitlines()
    keep = set()
    for i, line in enumerate(lines):
        if any(k in line for k in keys):
            keep.update(range(max(0, i - 2), min(len(lines), i + 12)))
    snippets[relative] = "\n".join(f"{i + 1}: {lines[i]}" for i in sorted(keep))
(OWN / "source-semantics.json").write_text(
    json.dumps(
        {
            "immutable_Git_sources": sources,
            "selected_source_text": snippets,
            "no_mutable_Main_source_read": True,
            "model_payload_native_forward_Search_calls": 0,
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
methods = result["method_exposures_not_independent"]
phases = collections.defaultdict(lambda: collections.defaultdict(list))
for game in games:
    batch = result["batches"][game["batch"]]
    obs = game.pop("move_depth_rows")
    assert len(obs) == game["observations"]
    for j, o in enumerate(obs):
        engine = batch["engines"][o["engine"]]
        method = f"{engine['kind']}/{engine['ordering_profile']}/{'ON' if engine.get('lmr', False) else 'OFF'}"
        if o["accepted"] and o["selected_depth"] is not None:
            phases[method][
                "last_quarter_of_actual_continuation"
                if 4 * j >= 3 * len(obs)
                else "first_three_quarters_of_actual_continuation"
            ].append(o["selected_depth"])
    game["continuation_observations_by_engine"] = {
        str(i): sum(o["engine"] == i for o in obs) for i in (0, 1)
    }
    game["selected_depth_by_engine"] = {
        str(i): measured(
            [
                o["selected_depth"]
                for o in obs
                if o["engine"] == i
                and o["accepted"]
                and o["selected_depth"] is not None
            ]
        )
        for i in (0, 1)
    }
for method, r in methods.items():
    hist = {int(k): v for k, v in r["selected_depth_histogram"].items()}
    assert (
        sum(hist.values())
        == r["observed_selected_depth"]["n"]
        == r["counts"]["accepted"]
    )
    r["selected_depth_small_histogram"] = {
        "1..3": sum(v for k, v in hist.items() if k <= 3),
        "4..5": sum(v for k, v in hist.items() if 4 <= k <= 5),
        "6..8": sum(v for k, v in hist.items() if 6 <= k <= 8),
        "9..15": sum(v for k, v in hist.items() if 9 <= k <= 15),
        "16..31": sum(v for k, v in hist.items() if 16 <= k <= 31),
        "32..63": sum(v for k, v in hist.items() if 32 <= k <= 63),
        "64": hist.get(64, 0),
    }
    r["chronological_sensitivity_descriptive_only"] = {
        phase: measured(values) for phase, values in phases[method].items()
    }
    r["endgame_caveat"] = (
        "Actual last-quarter chronology is not a board/endgame classification. Pawn/wall/goal-distance attributes are not present; no reconstruction/model/Search was run. Unequal trajectories and move counts weight the mean differently."
    )
    r["TT_gauge_meaning"] = (
        "83886128B per persistent colour session, not RSS; recorded peaks not summed with terminal or completed-snapshot counters"
    )
result["source_semantics"] = ref(OWN / "source-semantics.json")
result["analysis_limits"] = {
    "conditional_family_unit": "same8 reused across8 contrasts; 128 games/64pairs are not independent population samples",
    "interval": "saved native family bootstrap only; new resampling0",
    "same_time": "100ms receipt/5ms reserve within actual saved guard/chronology scope; terminal drain may finish after receipt deadline",
    "depth": "accepted selected completed nominal snapshot only; LMR ON is selective, not full-width qualification",
    "work": "terminal totals, selected snapshots and persistent TT views kept separate and not added",
    "physical_NN": "physical_nn_calls and leaf_count null remain UNKNOWN; native nn_calls0 is not physicalforward0",
    "RSS": "continuous family peak and isolated eval/map/scoring/LMR costs UNKNOWN",
    "adoption": "Root+related reviewer; descriptive saved analysis only",
    "old400": "not read or pooled; no old-versus-new causal speedup",
    "new_calls_games_bootstrap": 0,
}
result["original_source_binding"] = {
    "commit": "93cbcd70b3a30ba3dc69ef0f1c45f6ee1b201f36",
    "Build": result["batches"][0]["original_Build"],
    "image_sha256": result["image_sha256"],
}
for binding in bindings:
    assert ref(Path(binding["path"])) == binding
for binding in selected:
    path = Path(binding["path"])
    actual = ref(path)
    assert actual == binding, (binding, actual)
(OWN / "result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
(OWN / "game-index.json").write_text(
    json.dumps(games, ensure_ascii=False, indent=2) + "\n"
)
lines = [
    "# 共通signed ordering整理後：LMR/Control/Cheapの固定128局",
    "",
    "新しい同一image1cc34b4b・Build1108141f・source93cbcd70による128局を一度ずつ照合した。8原operationは全て正常final manifest PASS、128unique・64完成色pair、全局goal、draw/forfeit/UNKNOWN・欠測・重複は0。追加探索・対局・モデルforward・geometry・bootstrapは0。旧400の勝敗・RAW・費用は再集計も混入もしていない。",
    "",
    "## 対照の保存勝敗",
    "",
    "左条件の勝-分-負-UNKNOWN。区間は保存nativeのfamily-pair bootstrap95%を引用し、再計算0。全対照で同じ8開幕familyを共有し、条件固定book内の幅である。128独立標本、正式棋力/Elo、非劣性、静的項単独の因果効果へ置換しない。",
    "",
    "|評価|左 vs 右|勝-分-負-UNKNOWN|左family平均|保存95%区間|",
    "|---|---|---:|---:|---:|",
]


def label(e):
    return e["ordering_profile"].capitalize() + (
        " ON" if e.get("lmr", False) else " OFF"
    )


for b in result["batches"]:
    left, right = b["engines"]
    w = b["wdl_left"]
    ci = b["native_bootstrap_not_recomputed"]["percentile_95"]
    lines.append(
        f"|{'NNUE/BEST43' if left['kind'] == 'nnue' else '固定D(0,8tanh)'}|{label(left)} vs {label(right)}|{w['wins']}-{w['draws']}-{w['losses']}-{w['unknown']}|{b['mean_family_score_left']:.4f}|[{ci[0]:.4f}, {ci[1]:.4f}]|"
    )
lines += [
    "",
    "NNUEのControl OFF/ONは9勝7敗、Cheap OFF/ONは8勝8敗。Control/Cheap対照はOFF同士でControlが11勝5敗、ON同士でControlが6勝10敗。固定DではControl OFF/ONが7勝9敗、Cheap OFF/ONは8勝8敗、Control/CheapはOFFが10勝6敗、ONは8勝8敗だった。全8対照の保存95%区間は0.5を含む。固定D Cheap OFF/ONの[0.5,0.5]は全familyの二色scoreが0.5だったための条件付き再標本化結果で、集団の確実な同等性を証明しない。方法/evaluatorをまたぐ一般優劣や採否はここから確定しない。",
    "",
    "## 同じ8familyの二色score",
    "",
    "左条件の二色平均。色別WDL・global/local game・実model/namespace・原final authority・journal参照はresult.json/game-index.json/selectedrefs.json。family名とbookIDを混同せず、plan/configのfamily_idとnative lineageを対応させた。",
    "",
    "|batch|23|29|34|46|64|93|105|108|",
    "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
]
for b in result["batches"]:
    lines.append(
        "|"
        + str(b["batch"])
        + "|"
        + "|".join(str(f["score_left"]) for f in b["family_scores"])
        + "|"
    )
lines += [
    "",
    "batch0..3はNNUE、4..7はD。各々Control OFF/ON、Cheap OFF/ON、Control OFF/Cheap OFF、Control ON/Cheap ONの順。開幕長4/8/12/16各2family、同じ事前seed40020261014。再使用familyは対照間で相関し、複数の独立bookではない。",
    "",
    "## accepted完成snapshotの深さ",
    "",
    "各methodは二対照・32game exposures。全accepted観測に完成snapshotがあり、深さの分母nを以下に示す。中央値を主表示し、平均・小histogramも併記する。設定64はnominal上限、LMR ONの選択深さは選択的nominalで全幅探索depthの証明ではない。異なる局面軌跡/手数/終盤比率と深い尾部で平均が変わるため、同depthの計算単体費・棋力利益へ直結しない。",
    "",
    "|method|n|中央値|平均|min..max|depth 1..3 / 4..5 / 6..8 / 9..15 / 16..31 / 32..63 / 64|",
    "|---|---:|---:|---:|---:|---|",
]
for method, r in methods.items():
    d = r["observed_selected_depth"]
    h = r["selected_depth_small_histogram"]
    lines.append(
        f"|{method}|{d['n']}|{d['median']:g}|{d['mean']:.3f}|{d['min']}..{d['max']}|"
        + " / ".join(str(v) for v in h.values())
        + "|"
    )
lines += [
    "",
    "NNUEは両profileでOFF中央値5、ON中央値6。固定DはControl8→10、Cheap8→9。これらは今回のaccepted手の記述値であり、旧400中央値の移植ではない。終盤のpawn/wall/goal-distance属性は保存観測に無く、正確な終盤比はUNKNOWN。既に保存した手順順序の最終四分の一と前半四分の三の深さ分布はmachine resultに補助表示したが、盤面終盤分類ではない。新geometryやcallbackは使っていない。",
    "",
    "## receipt・drain・workの分母",
    "",
    "全6679観測はaccepted。zero-completed fallback、engine_error、failure、receipt>=deadline、未回収matching terminal、残inflight、first receipt/control errorは0。既存arena_reference_report/arena_observationで全実clock/method/core/terminal・opening→accepted手→原movesを保存照合。cancelled stopの件数は下表およびmachine resultにそのまま残し、reserve_stop_is_not_user_cancel=trueの完成snapshot選択と区別する。user pauseや失敗をdrawに変えていない。",
    "",
    "nodes/evals/LMRはterminal whole_search/lmr_work_terminal総和のみ。selected completed snapshotは内包された別view、persistent TTは容量/gaugeと別scopeのworkで、三者を足さない。",
    "",
    "|method|accepted|cancelled stop|terminal nodes|static evals|LMR attempt/全depth確認/全window再探索|",
    "|---|---:|---:|---:|---:|---|",
]
for method, r in methods.items():
    t = r["terminal_work"]
    w = r["lmr_terminal_work"]
    lines.append(
        f"|{method}|{r['counts']['accepted']}|{r['stops'].get('cancelled', 0)}|{t.get('nodes', 'UNKNOWN')}|{t.get('static_evaluations', 'UNKNOWN')}|{w.get('attempts', 0)}/{w.get('full_depth_confirmations', 0)}/{w.get('full_window_researches', 0)}|"
    )
lines += [
    "",
    "各scalarの実記録件数/null数、PVS/TT/error/selection reason、caller・selected thinking・deadline slack・receipt→terminal returnのn/median/mean/範囲をresult.jsonに分離した。terminalのphysical_nn_calls/leaf_countはnullでUNKNOWN。native nn_calls=0を物理forward0と解釈しない。全検索時間、部位別採点/map/LMR費、連続process-family RSS peakはUNKNOWN。native一回のpeak_rss記録はその実scopeだけを保存している。",
    "",
    "## 実設定と解釈限界",
    "",
    "NNUE BEST43と固定D(0,8tanh)はいずれもTT1048576。各色sessionのactual effective slots1048576、persistent TT byte cap/retained peak83886128Bを128局×2sessionsで確認した。二色TTは167772256B相当だがRSSではなく、metadataやevaluatorを含むfamily peakとは別。各局100ms main authority receipt/5ms reserve、depth64/node1M/200ply、AI2/6・main4、直列1game・二者persistentworker・inference pumpなし。future quietnessを過去STOPから推定しない。",
    "",
    "実Control/Cheap/LMR getterとnamespaceを保存configのmodel/evaluator/rulesと照合し、Control/Cheap suffix、LMRON suffixで実method/TT資格が分離している。source-semantics.jsonはgenuine Buildのimmutable Git93cbcd70にある必要alphabeta/Cheapの短い参照。採点係数・fixedDで真正parentmapが無い場合の既存正本距離生成・LMR既存規則は変更していない。NNUEの観測をDへ外挿せず、旧400との別時刻比から共通化のcausal speedupを認定しない。",
    "",
    "この固定bookではLMR追加の勝敗は広い幅で保留、Cheapの勝敗方向もevaluator/modeで異なる。選択深さの上昇と勝敗は別の事実で、採用/default/正式強さの確定ではない。Rootの別96探索費と並べて同関連reviewerが必要解釈を確認する。追加試合・探索・parameter tuning・bootstrap・追試は発行しない。",
    "",
    "## 元記録と停止",
    "",
    "原8manifest/Build/config/settings/圧縮journal/native summary/native manifestはSHA-size-modeをparse前と対象読取後に照合。原400・新402のFAILED/RAW/費・returned guardianとdisk masksは変更0。最初の本解析helperは未使用import/E402で解析前lint拒否、原receiptを保存しhelperだけ修正した。正常解析は一度で、科学再演0。実readerSTOP・exact child/reap/handles/TMP/owned[]・source identity・一回OWN usageはcompletion.jsonに結び付ける。Main/Git/Cargo/Beads変更0、mixed/learner全prep/pipeline・323 USERPAUSEとモデル/defaults/weights/seals/oldfits96を維持。",
]
(OWN / "report.md").write_text("\n".join(lines) + "\n")
(OWN / "presentation-validation.json").write_text(
    json.dumps(
        {
            "inputs_before_after": bindings,
            "selectedrefs_after_verified": len(selected),
            "immutable_source_refs": sources,
            "original_unique_games": 128,
            "complete_pairs": 64,
            "accepted": 6679,
            "new_bootstrap_calls_geometry_model": 0,
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "report": ref(OWN / "report.md"),
            "result": ref(OWN / "result.json"),
            "games": 128,
            "pairs": 64,
            "accepted": 6679,
        }
    )
)
