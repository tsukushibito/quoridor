"""Use named immutable versions of the maintained saved consumer and guardian."""

import hashlib
import json
import subprocess
import sys
import types
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
GIT = "2001f68"
ORIGINS = []


def load(name, relative, expected=None):
    command = ["git", "-C", str(MAIN), "show", GIT + ":" + relative]
    child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    proc = Path("/proc") / str(child.pid) / "stat"
    try:
        identity = {
            "pid": child.pid,
            "start_ticks": proc.read_text().rsplit(")", 1)[1].split()[19],
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        }
    except FileNotFoundError:
        identity = None
    try:
        data, error = child.communicate()
        assert child.returncode == 0, error.decode()
    finally:
        child.stdout.close()
        child.stderr.close()
    digest = hashlib.sha256(data).hexdigest()
    assert len(data) < 256 * 1024 and (expected is None or digest == expected)
    ORIGINS.append(
        {
            "Git": GIT,
            "path": relative,
            "sha256": digest,
            "bytes": len(data),
            "identity": identity,
            "directwait_exit": child.returncode,
            "reaped": True,
            "handles_closed": True,
        }
    )
    module = types.ModuleType(name)
    module.__file__ = str(MAIN / relative)
    module.__package__ = name.rpartition(".")[0]
    sys.modules[name] = module
    exec(compile(data, module.__file__, "exec"), module.__dict__)
    return module


package = types.ModuleType("quoridor_training")
package.__path__ = []
sys.modules["quoridor_training"] = package
load(
    "quoridor_training.snapshot",
    "python/quoridor_training/snapshot.py",
    "ed0814965c012d6ad5ad094e653158b42b5d4ebf17463706ce53d029bc704341",
)
package.cycle_process = load(
    "quoridor_training.cycle_process",
    "python/quoridor_training/cycle_process.py",
    "d6410c0c31956a31927f87c4e5a51d84064b841197cbfa4aa683ac76ea9c45e3",
)
lc = load(
    "saved_arena_lifecycle",
    "scripts/dev/research-lifecycle.py",
    "1b1a94450a577b4957a7e1cdf2c9bf49bf510343f6c261480d40f317c8b895da",
)
