# 共通signed ordering整理後：LMR/Control/Cheapの固定128局

新しい同一image1cc34b4b・Build1108141f・source93cbcd70による128局を一度ずつ照合した。8原operationは全て正常final manifest PASS、128unique・64完成色pair、全局goal、draw/forfeit/UNKNOWN・欠測・重複は0。追加探索・対局・モデルforward・geometry・bootstrapは0。旧400の勝敗・RAW・費用は再集計も混入もしていない。

## 対照の保存勝敗

左条件の勝-分-負-UNKNOWN。区間は保存nativeのfamily-pair bootstrap95%を引用し、再計算0。全対照で同じ8開幕familyを共有し、条件固定book内の幅である。128独立標本、正式棋力/Elo、非劣性、静的項単独の因果効果へ置換しない。

|評価|左 vs 右|勝-分-負-UNKNOWN|左family平均|保存95%区間|
|---|---|---:|---:|---:|
|NNUE/BEST43|Control OFF vs Control ON|9-0-7-0|0.5625|[0.3750, 0.7500]|
|NNUE/BEST43|Cheap OFF vs Cheap ON|8-0-8-0|0.5000|[0.3125, 0.6875]|
|NNUE/BEST43|Control OFF vs Cheap OFF|11-0-5-0|0.6875|[0.4375, 0.9375]|
|NNUE/BEST43|Control ON vs Cheap ON|6-0-10-0|0.3750|[0.1250, 0.6250]|
|固定D(0,8tanh)|Control OFF vs Control ON|7-0-9-0|0.4375|[0.1875, 0.6875]|
|固定D(0,8tanh)|Cheap OFF vs Cheap ON|8-0-8-0|0.5000|[0.5000, 0.5000]|
|固定D(0,8tanh)|Control OFF vs Cheap OFF|10-0-6-0|0.6250|[0.3750, 0.8750]|
|固定D(0,8tanh)|Control ON vs Cheap ON|8-0-8-0|0.5000|[0.2500, 0.7500]|

NNUEのControl OFF/ONは9勝7敗、Cheap OFF/ONは8勝8敗。Control/Cheap対照はOFF同士でControlが11勝5敗、ON同士でControlが6勝10敗。固定DではControl OFF/ONが7勝9敗、Cheap OFF/ONは8勝8敗、Control/CheapはOFFが10勝6敗、ONは8勝8敗だった。全8対照の保存95%区間は0.5を含む。固定D Cheap OFF/ONの[0.5,0.5]は全familyの二色scoreが0.5だったための条件付き再標本化結果で、集団の確実な同等性を証明しない。方法/evaluatorをまたぐ一般優劣や採否はここから確定しない。

## 同じ8familyの二色score

左条件の二色平均。色別WDL・global/local game・実model/namespace・原final authority・journal参照はresult.json/game-index.json/selectedrefs.json。family名とbookIDを混同せず、plan/configのfamily_idとnative lineageを対応させた。

|batch|23|29|34|46|64|93|105|108|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|0|0.5|0.0|0.5|0.5|0.5|0.5|1.0|1.0|
|1|0.5|0.5|0.5|1.0|0.5|0.5|0.5|0.0|
|2|1.0|1.0|0.0|0.5|0.5|0.5|1.0|1.0|
|3|0.0|0.5|0.5|0.5|0.0|1.0|0.5|0.0|
|4|0.5|0.0|0.0|0.5|0.5|1.0|1.0|0.0|
|5|0.5|0.5|0.5|0.5|0.5|0.5|0.5|0.5|
|6|1.0|0.5|1.0|0.0|1.0|0.5|0.5|0.5|
|7|0.0|0.5|1.0|0.0|0.5|0.5|0.5|1.0|

batch0..3はNNUE、4..7はD。各々Control OFF/ON、Cheap OFF/ON、Control OFF/Cheap OFF、Control ON/Cheap ONの順。開幕長4/8/12/16各2family、同じ事前seed40020261014。再使用familyは対照間で相関し、複数の独立bookではない。

## accepted完成snapshotの深さ

各methodは二対照・32game exposures。全accepted観測に完成snapshotがあり、深さの分母nを以下に示す。中央値を主表示し、平均・小histogramも併記する。設定64はnominal上限、LMR ONの選択深さは選択的nominalで全幅探索depthの証明ではない。異なる局面軌跡/手数/終盤比率と深い尾部で平均が変わるため、同depthの計算単体費・棋力利益へ直結しない。

|method|n|中央値|平均|min..max|depth 1..3 / 4..5 / 6..8 / 9..15 / 16..31 / 32..63 / 64|
|---|---:|---:|---:|---:|---|
|nnue/control/OFF|790|5|10.306|3..64|53 / 385 / 68 / 125 / 127 / 2 / 30|
|nnue/control/ON|779|6|11.072|3..64|3 / 361 / 95 / 131 / 162 / 4 / 23|
|nnue/cheap/OFF|794|5|9.379|3..64|144 / 290 / 121 / 72 / 145 / 1 / 21|
|nnue/cheap/ON|789|6|10.227|3..64|79 / 311 / 104 / 93 / 181 / 2 / 19|
|distance/control/OFF|885|8|12.295|4..64|0 / 382 / 68 / 112 / 293 / 7 / 23|
|distance/control/ON|876|10|12.784|4..64|0 / 314 / 105 / 145 / 288 / 7 / 17|
|distance/cheap/OFF|887|8|11.874|3..64|29 / 374 / 68 / 146 / 228 / 8 / 34|
|distance/cheap/ON|879|9|11.474|3..64|23 / 324 / 73 / 189 / 251 / 4 / 15|

NNUEは両profileでOFF中央値5、ON中央値6。固定DはControl8→10、Cheap8→9。これらは今回のaccepted手の記述値であり、旧400中央値の移植ではない。終盤のpawn/wall/goal-distance属性は保存観測に無く、正確な終盤比はUNKNOWN。既に保存した手順順序の最終四分の一と前半四分の三の深さ分布はmachine resultに補助表示したが、盤面終盤分類ではない。新geometryやcallbackは使っていない。

## receipt・drain・workの分母

全6679観測はaccepted。zero-completed fallback、engine_error、failure、receipt>=deadline、未回収matching terminal、残inflight、first receipt/control errorは0。既存arena_reference_report/arena_observationで全実clock/method/core/terminal・opening→accepted手→原movesを保存照合。cancelled stopの件数は下表およびmachine resultにそのまま残し、reserve_stop_is_not_user_cancel=trueの完成snapshot選択と区別する。user pauseや失敗をdrawに変えていない。

nodes/evals/LMRはterminal whole_search/lmr_work_terminal総和のみ。selected completed snapshotは内包された別view、persistent TTは容量/gaugeと別scopeのworkで、三者を足さない。

|method|accepted|cancelled stop|terminal nodes|static evals|LMR attempt/全depth確認/全window再探索|
|---|---:|---:|---:|---:|---|
|nnue/control/OFF|790|0|71810499|41689788|0/0/0|
|nnue/control/ON|779|0|71312480|36732401|4120836/23394/951|
|nnue/cheap/OFF|794|0|48120375|28937186|0/0/0|
|nnue/cheap/ON|789|2|45557505|23468181|2628112/16114/575|
|distance/control/OFF|885|2|165944909|96874518|0/0/0|
|distance/control/ON|876|1|149534025|74456846|7030810/85336/352|
|distance/cheap/OFF|887|0|77217272|44550953|0/0/0|
|distance/cheap/ON|879|3|70504663|35758797|3417664/32782/260|

各scalarの実記録件数/null数、PVS/TT/error/selection reason、caller・selected thinking・deadline slack・receipt→terminal returnのn/median/mean/範囲をresult.jsonに分離した。terminalのphysical_nn_calls/leaf_countはnullでUNKNOWN。native nn_calls=0を物理forward0と解釈しない。全検索時間、部位別採点/map/LMR費、連続process-family RSS peakはUNKNOWN。native一回のpeak_rss記録はその実scopeだけを保存している。

## 実設定と解釈限界

NNUE BEST43と固定D(0,8tanh)はいずれもTT1048576。各色sessionのactual effective slots1048576、persistent TT byte cap/retained peak83886128Bを128局×2sessionsで確認した。二色TTは167772256B相当だがRSSではなく、metadataやevaluatorを含むfamily peakとは別。各局100ms main authority receipt/5ms reserve、depth64/node1M/200ply、AI2/6・main4、直列1game・二者persistentworker・inference pumpなし。future quietnessを過去STOPから推定しない。

実Control/Cheap/LMR getterとnamespaceを保存configのmodel/evaluator/rulesと照合し、Control/Cheap suffix、LMRON suffixで実method/TT資格が分離している。source-semantics.jsonはgenuine Buildのimmutable Git93cbcd70にある必要alphabeta/Cheapの短い参照。採点係数・fixedDで真正parentmapが無い場合の既存正本距離生成・LMR既存規則は変更していない。NNUEの観測をDへ外挿せず、旧400との別時刻比から共通化のcausal speedupを認定しない。

この固定bookではLMR追加の勝敗は広い幅で保留、Cheapの勝敗方向もevaluator/modeで異なる。選択深さの上昇と勝敗は別の事実で、採用/default/正式強さの確定ではない。Rootの別96探索費と並べて同関連reviewerが必要解釈を確認する。追加試合・探索・parameter tuning・bootstrap・追試は発行しない。

## 元記録と停止

原8manifest/Build/config/settings/圧縮journal/native summary/native manifestはSHA-size-modeをparse前と対象読取後に照合。原400・新402のFAILED/RAW/費・returned guardianとdisk masksは変更0。最初の本解析helperは未使用import/E402で解析前lint拒否、原receiptを保存しhelperだけ修正した。正常解析は一度で、科学再演0。実readerSTOP・exact child/reap/handles/TMP/owned[]・source identity・一回OWN usageはcompletion.jsonに結び付ける。Main/Git/Cargo/Beads変更0、mixed/learner全prep/pipeline・323 USERPAUSEとモデル/defaults/weights/seals/oldfits96を維持。

原outer job04a9925cの689.077780806秒はcontroller wholeとして一度だけ記録し、内包native/operation時間や今回saved解析費を加算しない。exit0だけで対局PASSとせず、8original final manifestsと保存consumerの128局照合を根拠とした。

|method|receipt期限余裕中央値ms|receipt→terminal return中央値ms|caller n/中央値秒|
|---|---:|---:|---|
|nnue/control/OFF|37.094|33.749|790/0.099092|
|nnue/control/ON|34.833|32.114|779/0.099093|
|nnue/cheap/OFF|35.875|33.392|794/0.099220|
|nnue/cheap/ON|30.685|28.990|789/0.099303|
|distance/control/OFF|41.469|38.687|885/0.099308|
|distance/control/ON|32.974|31.372|876/0.099463|
|distance/cheap/OFF|34.855|32.563|887/0.099155|
|distance/cheap/ON|31.765|30.100|879/0.099189|

receiptとterminal完了は別の時点。receiptは全件deadline未満だがterminalはdeadline後まで続き得る。これは保存したexact drain/次turn前のjoinと整合し、遅い完成を選択したという意味ではない。
