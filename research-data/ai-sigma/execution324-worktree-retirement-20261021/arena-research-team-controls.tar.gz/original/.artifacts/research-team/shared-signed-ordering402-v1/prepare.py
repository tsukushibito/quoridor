"""New-subject draft generation from bounded named metadata, never launch."""

import copy
import hashlib
import json
import resource
import stat
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
NEW_ROOT = MAIN / ".artifacts/research-team/integration324/shared-signed-ordering402-v1"
COST_OWNER = MAIN / ".worktree/assets/perf/shared-signed-ordering402-cost96-v1"
ARENA_OWNER = MAIN / ".worktree/assets/perf/shared-signed-ordering402-arena128-v1"
old = json.loads((OWN / "intake.json").read_text())
meta = json.loads((OWN / "scout.json").read_text())
refs = {r["path"]: r for r in meta["selectedrefs"]}
for path in [COST_OWNER, ARENA_OWNER, NEW_ROOT]:
    # Root namespace may be present for source work; only future runtime is absent.
    if path != NEW_ROOT:
        assert not path.exists(), path


def ref(path):
    raw = path.read_bytes()
    info = path.stat()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


def read(binding):
    path = Path(binding["path"])
    assert ref(path) == binding and binding["bytes"] < 2 * 1024**2
    refs[str(path)] = binding
    return json.loads(path.read_bytes())


def put(path, data):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    assert json.loads(path.read_text()) == data
    return ref(path)


def remap_paths(value, source_owner, new_owner):
    if isinstance(value, str):
        return value.replace(str(source_owner), str(new_owner))
    if isinstance(value, list):
        return [remap_paths(v, source_owner, new_owner) for v in value]
    if isinstance(value, dict):
        return {k: remap_paths(v, source_owner, new_owner) for k, v in value.items()}
    return value


original_to_new = []
cost_rows = []
cost_specs = []
cost_configs = {}
for item in meta["cost"]:
    index = item["index"]
    cfg = item["config"]
    evaluator = "nnue4k" if cfg["tt_entries"] == 4096 else "fixedD1M"
    profile = cfg["profile"]
    mode = "ON" if cfg["lmr"] else "OFF"
    assert cfg["use_tt"] and cfg["use_pvs"] and cfg["profile"] in {"control", "cheap"}
    assert cfg["lmr"] == [False, True, True, False][index % 4]
    key = (evaluator, profile, mode)
    if key not in cost_configs:
        cost_configs[key] = put(
            OWN / "cost-configs" / f"{evaluator}-{profile}-{mode}.json", cfg
        )
    requests = read(item["experiment"]["schedule"])
    request_path = OWN / "cost-requests.json"
    if not request_path.exists():
        request_ref = put(request_path, requests)
    else:
        assert json.loads(request_path.read_text()) == requests
        request_ref = ref(request_path)
    ex = copy.deepcopy(item["experiment"])
    ex.update(
        build_manifest=None,
        config=None,
        schedule=request_ref,
        argv=[
            None,
            "measure",
            "--experiment",
            "@EXPERIMENT@",
            "--experiment-sha256",
            "@EXPERIMENT_SHA256@",
        ],
    )
    exref = put(OWN / "cost-experiment-drafts" / f"experiment-{index:03}.json", ex)
    original = old["cost_settings"]["measurements"][index]
    spec = remap_paths(copy.deepcopy(original), original["owner"], COST_OWNER)
    spec.update(
        artifact=None,
        experiment=None,
        caller_sources=None,
        support=None,
        argv=[None, "measure", "--experiment", None, "--experiment-sha256", None],
    )
    cost_specs.append(spec)
    original_to_new.append(
        {
            "kind": "measure",
            "index": index,
            "original_config": item["original_config"],
            "config_draft": cost_configs[key],
            "original_experiment": item["original_experiment"],
            "experiment_draft": exref,
            "new_Root_config_ref": None,
            "new_Root_experiment_ref": None,
            "new_output": spec["data_root"],
        }
    )
    cost_rows.append(
        {
            "index": index,
            "evaluator": evaluator,
            "profile": profile,
            "lmr": cfg["lmr"],
            "pass_in_OFF_ON_ON_OFF": index % 4,
            "expected_calls": 6,
            "expected_sessions": 3,
            "new_status": "UNENTERED",
            "actual_manifest": None,
            "actual_settings": None,
            "actual_result": None,
            "actual_whole_seconds": None,
        }
    )
cost_settings = remap_paths(
    copy.deepcopy(old["cost_settings"]), old["cost_settings"]["owner"], COST_OWNER
)
cost_settings["measurements"] = cost_specs
put(OWN / "cost96-settings-draft.json", cost_settings)

schedule = copy.deepcopy(old["arena_schedule"])
assert len(schedule) == 128 and sorted(s["slot"] for s in schedule) == list(range(128))
schedule_ref = put(OWN / "arena-schedule.json", schedule)
plan = copy.deepcopy(old["arena_plan"])
plan["schedule"] = schedule_ref
for item in old["arena_configs"]:
    index = item["batch"]
    cfg = copy.deepcopy(item["config"])
    cfg["run_id"] = cfg["run_id"].replace("400-", "402-", 1)
    cfg["output"] = str(ARENA_OWNER / f"batch-{index:03}" / "data")
    cfg["arena"]["search_artifact_sha256"] = [None, None]
    cfg["arena"]["book"]["id"] = cfg["arena"]["book"]["id"].replace("400-", "402-", 1)
    cfgref = put(OWN / "arena-config-drafts" / f"config-{index:03}.json", cfg)
    plan["batches"][index]["config"] = cfgref
    ex = copy.deepcopy(meta["arena_experiment"])
    ex.update(
        build_manifest=None,
        config=None,
        schedule=schedule_ref,
        numerical_qualification=None,
        canonical_plan_sha256=None,
        batch=index,
        argv=[
            None,
            "arena",
            "--experiment",
            "@EXPERIMENT@",
            "--experiment-sha256",
            "@EXPERIMENT_SHA256@",
        ],
    )
    exref = put(OWN / "arena-experiment-drafts" / f"experiment-{index:03}.json", ex)
    original_to_new.append(
        {
            "kind": "arena",
            "batch": index,
            "original_config": item["ref"],
            "config_draft": cfgref,
            "experiment_draft": exref,
            "new_Root_config_ref": None,
            "new_Root_experiment_ref": None,
            "new_output": cfg["output"],
        }
    )
    back = copy.deepcopy(cfg)
    back["run_id"] = item["config"]["run_id"]
    back["output"] = item["config"]["output"]
    back["arena"]["search_artifact_sha256"] = item["config"]["arena"][
        "search_artifact_sha256"
    ]
    back["arena"]["book"]["id"] = item["config"]["arena"]["book"]["id"]
    assert back == item["config"], index
plan_ref = put(OWN / "arena-plan-draft.json", plan)
arena_settings = remap_paths(
    copy.deepcopy(old["arena_settings"]), old["arena_settings"]["owner"], ARENA_OWNER
)
template = arena_settings["arena"]["template"]
template.update(
    artifact=None,
    experiment=None,
    approved_plan=None,
    caller_sources=None,
    support=None,
    argv=[None, "arena", "--experiment", None, "--experiment-sha256", None],
)
put(OWN / "arena128-settings-draft.json", arena_settings)
put(OWN / "original-to-new.json", original_to_new)
put(
    OWN / "result-table-draft.json",
    {
        "study_subject": "shared-signed-ordering402 only; do not merge old400 data",
        "actual_newimage_Build_runtime_refs": None,
        "cost_operation_rows": cost_rows,
        "cost_root_columns": [
            "evaluator",
            "profile",
            "lmr",
            "pass",
            "actual_input_history_root",
            "session/reset/warm",
            "target_depth",
            "completed_nominal_depth",
            "status/stop/error",
            "valuebits",
            "action",
            "exactPV",
            "whole_search/setup/drop_seconds",
            "nodes",
            "static_evaluations",
            "LMR_attempts/confirm/fullwindow",
            "PVS_researches",
            "TT_probes/hits/cutoffs/collisions/retained",
            "legal/history/parent_restored",
        ],
        "cost_summary_rows": [
            {
                "evaluator": e,
                "profile": p,
                "lmr": enabled,
                "actual_absolute_whole_median": None,
                "actual_nodes": None,
                "actual_evals": None,
                "actual_depth_work": None,
                "planned_calls": 12,
                "recorded_calls": 0,
            }
            for e in ["nnue4k", "fixedD1M"]
            for p in ["control", "cheap"]
            for enabled in [False, True]
        ],
        "arena_contrast_rows": [
            {
                "batch": i,
                "engines": plan["matchups"][i]["engines"],
                "planned_games": 16,
                "planned_colourpairs": 8,
                "status": "UNENTERED",
                "actual_W_D_L_UNKNOWN": None,
                "actual_native_family_scores8": None,
                "actual_saved_native_bootstrap95": None,
                "actual_move_depth_work_clock_fallback_errors": None,
                "actual_refs": None,
            }
            for i in range(8)
        ],
        "arena_game_columns": [
            "global_slot",
            "local_game",
            "familyID/lineage",
            "candidate_colour",
            "actual_engine_mapping",
            "actual_namespace/LMR/TT",
            "started/unentered",
            "native_status/winner/reason/error",
            "selected_snapshot_vs_terminal_work",
            "actual_receipt/return/drain",
        ],
        "root_value_PV_work_differences": "Observe between static/LMR modes; not the old same-work adoption gate",
        "unknown_incomplete_failure": "Preserve actual native stop/status, do not upgrade node-limitD5 toD6 or maxply/error to draw; stop unexpectedfailure with no refill/replay",
        "statistics": "Native complete-family-pair summary/bootstrap only; conditional fixed8families and reused/multiple contrasts, no new bootstrap or Elo/noninferiority/default certificate",
        "old400": "Separate genuine oldprofile cohort; different-time ratios do not establish shared-key causal speedup",
    },
)
put(
    OWN / "pending-bindings.json",
    {
        "new_image": None,
        "new_Build": None,
        "current_caller_refs": None,
        "Root_actual_config_Experiment_sequence_runtime_refs": None,
        "Root_actual_source_support_currentenv_dynamic_libraries_model_refs": None,
        "genuine_402_factory_namespace_and_commonkey_identity": None,
        "Root_exact_numerical_correspondence": None,
        "actual_physical_quiet_admission": None,
        "draft_arena_plan": plan_ref,
        "known_old_Build_image_refs_are_historical_only": {
            "artifact": old["arena_settings"]["arena"]["template"]["artifact"],
            "Build": meta["arena_experiment"]["build_manifest"],
        },
        "caller_baseline": "immutableGit2001f68 LCwhole1b1a9445; Root actual caller/source-entry binding required, not legacy savedcaller refs",
        "not_a_new_gate": "Root ordinary current source/software/settings intake; no author science/admission/qualification",
    },
)
for binding in list(refs.values()):
    read(binding)
put(OWN / "selectedrefs.json", list(refs.values()))
print(
    json.dumps(
        {
            "new_draft_cost_operations": 16,
            "new_draft_arena_games": 128,
            "arena_schedule_exact": True,
            "new_image_Build_runtime": None,
            "source_native_model_Search_game_test_calls": 0,
        }
    )
)
