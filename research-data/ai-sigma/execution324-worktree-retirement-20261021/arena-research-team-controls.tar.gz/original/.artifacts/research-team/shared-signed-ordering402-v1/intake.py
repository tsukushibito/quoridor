"""Named immutable settings/config intake only; no saved RAW or execution."""

import hashlib
import json
import resource
import stat
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor/.artifacts/research-team/integration324/lmr400-v1")
refs = {}


def read(path, expected=None):
    path = Path(path)
    info = path.stat()
    assert stat.S_ISREG(info.st_mode) and info.st_size < 2 * 1024**2
    raw = path.read_bytes()
    ref = {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }
    if expected is not None:
        assert ref == expected, (ref, expected)
    refs[str(path)] = ref
    return json.loads(raw)


cost = read(ROOT / "cost96-v2/settings.json")
costref = refs[str(ROOT / "cost96-v2/settings.json")]
assert costref["sha256"].startswith("e0d0b788") and costref["bytes"] == 91706
arena = read(ROOT / "arena128-v4/settings.json")
planref = arena["arena"]["template"]["approved_plan"]
plan = read(planref["path"], planref)
assert planref["sha256"].startswith("6b832956")
schedule = read(plan["schedule"]["path"], plan["schedule"])
configs = []
for batch in plan["batches"]:
    configs.append(
        {
            "batch": batch["batch"],
            "config": read(batch["config"]["path"], batch["config"]),
            "ref": batch["config"],
        }
    )
for ref in list(refs.values()):
    read(ref["path"], ref)
(OWN / "intake.json").write_text(
    json.dumps(
        {
            "cost_settings": cost,
            "arena_settings": arena,
            "arena_plan": plan,
            "arena_schedule": schedule,
            "arena_configs": configs,
            "selectedrefs": list(refs.values()),
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "config_intake": True,
            "selectedrefs": len(refs),
            "science_source_test_calls": 0,
        }
    )
)
