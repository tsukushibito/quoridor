"""Short new-draft parser and correspondence arithmetic; no old runtime checks."""

import hashlib
import json
import resource
import stat
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent


def pairs(items):
    out = {}
    for key, value in items:
        assert key not in out, key
        out[key] = value
    return out


def load(path):
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


paths = [
    OWN / name
    for name in [
        "cost96-settings-draft.json",
        "cost-requests.json",
        "arena128-settings-draft.json",
        "arena-plan-draft.json",
        "arena-schedule.json",
        "original-to-new.json",
        "result-table-draft.json",
        "pending-bindings.json",
    ]
]
for dirname in [
    "cost-configs",
    "cost-experiment-drafts",
    "arena-config-drafts",
    "arena-experiment-drafts",
]:
    paths.extend(sorted((OWN / dirname).glob("*.json")))
for path in paths:
    load(path)
cost = load(OWN / "cost96-settings-draft.json")
requests = load(OWN / "cost-requests.json")
assert len(cost["measurements"]) == 16 and len(requests) == 6
assert len({row["session"] for row in requests}) == 3
assert sum(row["node_cap"] for row in requests) * 16 == 288_000_000
assert all(
    row["time_limit_ms"] is None
    and row["diagnostic"] is False
    and row["observe_completed_depths"] is False
    and row["warmup"] is False
    for row in requests
)
assert [row["depth"] for row in requests] == [4, 6, 4, 4, 4, 4]
assert [row["root"] for row in requests] == list(range(6))
for row in cost["measurements"]:
    assert (
        row["artifact"] is None
        and row["experiment"] is None
        and row["caller_sources"] is None
        and row["support"] is None
    )
    assert "lmr400" not in row["owner"] and "lmr400" not in row["output"]
    assert row["argv"][0] is None
plan = load(OWN / "arena-plan-draft.json")
schedule = load(OWN / "arena-schedule.json")
old = load(OWN / "intake.json")
assert schedule == old["arena_schedule"] and len(schedule) == 128
assert sorted(row["slot"] for row in schedule) == list(range(128))
assert plan["family_ids"] == [23, 29, 34, 46, 64, 93, 105, 108]
for index, batch in enumerate(plan["batches"]):
    config = load(Path(batch["config"]["path"]))
    assert (
        config["games"] == 16
        and config["workers"] == config["active_games"] == config["max_batch"] == 1
    )
    assert config["arena"]["search_artifact_sha256"] == [None, None]
    assert config["management_cpu_core"] == 4 and config["cpu_cores"] == [2, 6]
    assert config["arena"]["return_reserve_ms"] == 5 and config["max_plies"] == 200
    assert all(
        e["depth"] == 64 and e["max_nodes"] == 1_000_000 and e["time_ms"] == 100
        for e in config["engines"]
    )
    rows = [row for row in schedule if row["batch"] == index]
    assert len(rows) == 16
    for f in plan["family_ids"]:
        assert sorted(
            row["candidate_color"] for row in rows if row["family_id"] == f
        ) == [0, 1]
assert len(load(OWN / "original-to-new.json")) == 24
selected = load(OWN / "selectedrefs.json")
for ref in selected:
    path = Path(ref["path"])
    info = path.stat()
    assert (
        info.st_size == ref["bytes"]
        and f"{stat.S_IMODE(info.st_mode):04o}" == ref["mode"]
    )
    assert hashlib.sha256(path.read_bytes()).hexdigest() == ref["sha256"]
outputs = []
for path in paths:
    raw = path.read_bytes()
    outputs.append(
        {
            "path": str(path),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
        }
    )
(OWN / "draft-parser-result.json").write_text(
    json.dumps(
        {
            "status": "NEW_DRAFT_SYNTAX_CORRESPONDENCE_PASS_NOT_RUNTIME_READY",
            "drafts": outputs,
            "cost_calls_sessions_cap": [96, 48, 288000000],
            "arena_games_colourpairs": [128, 64],
            "selectedrefs_before_after_count": len(selected),
            "old_RAW_decode_parser_suite_replay": 0,
            "new_source_native_model_Search_geometry_Perf_game_test_fit_calls": 0,
            "uncreated_refs_are_null": True,
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(json.dumps({"drafts_checked": len(paths), "PASS": True, "new_science": 0}))
