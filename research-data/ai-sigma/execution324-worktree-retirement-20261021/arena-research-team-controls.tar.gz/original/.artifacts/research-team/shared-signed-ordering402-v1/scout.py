"""Follow only the explicit old Config/Experiment metadata references."""

import hashlib
import json
import resource
import stat
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
old = json.loads((OWN / "intake.json").read_text())
refs = {r["path"]: r for r in old["selectedrefs"]}


def read(ref):
    path = Path(ref["path"])
    info = path.stat()
    raw = path.read_bytes()
    actual = {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }
    assert actual == ref and len(raw) < 2 * 1024**2
    refs[str(path)] = ref
    return json.loads(raw)


cost = []
for i, spec in enumerate(old["cost_settings"]["measurements"]):
    experiment = read(spec["experiment"])
    config = read(experiment["config"])
    cost.append(
        {
            "index": i,
            "experiment": experiment,
            "config": config,
            "original_experiment": spec["experiment"],
            "original_config": experiment["config"],
        }
    )
arena_experiment = read(old["arena_settings"]["arena"]["template"]["experiment"])
for ref in list(refs.values()):
    read(ref)
(OWN / "scout.json").write_text(
    json.dumps(
        {
            "cost": cost,
            "arena_experiment": arena_experiment,
            "selectedrefs": list(refs.values()),
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(json.dumps({"old_cost_configs": len(cost), "new_native_calls": 0}))
