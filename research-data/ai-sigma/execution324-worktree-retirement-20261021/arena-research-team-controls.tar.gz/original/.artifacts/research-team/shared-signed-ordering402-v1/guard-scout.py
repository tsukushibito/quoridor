"""One finite private-source reader through the maintained software command port."""

import fcntl
import importlib.util
import json
import os
import re
import stat
import sys
from pathlib import Path

MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
OUT = OWN / "scout-guard-v1"
loader = importlib.util.spec_from_file_location(
    "lifecycle", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
limits = {
    "family_B": 512 * 1024**2,
    "controller_B": 64 * 1024**2,
    "host_reserve_B": 4 * 1024**3,
    "worker_cpu": 5,
    "guardian_cpu": 11,
    "log_B": 128 * 1024,
}
spec = {
    "kind": "software",
    "cwd": str(OWN),
    "limits": limits,
    "env": {
        **os.environ,
        "TMPDIR": str(OUT / "TMP"),
        "PYTHONDONTWRITEBYTECODE": "1",
        "ARENA_361_MAIN_ROOT": str(MAIN),
        "ARENA_361_LIFECYCLE": str(MAIN / "scripts/dev/research-lifecycle.py"),
        "CUDA_VISIBLE_DEVICES": "",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
    },
}


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


available = sorted(os.sched_getaffinity(0))
os.sched_setaffinity(0, available)
lc.physical_and_quiet(spec)
lc.require(not OUT.exists(), "exclusive private reader")
with (
    Path("/home/vscode/.cache/inference/envs/quoridor-training.setup.lock").open(
        "r"
    ) as environment,
):
    fcntl.flock(environment, fcntl.LOCK_SH | fcntl.LOCK_NB)
    refs = [
        ref(p)
        for p in [
            Path(__file__).resolve(),
            MAIN / "scripts/dev/research-lifecycle.py",
            MAIN / "scripts/dev/project-env.sh",
            MAIN / "python/quoridor_training/cycle_process.py",
            Path(sys.executable).resolve(),
            Path(sys.prefix) / "pyvenv.cfg",
        ]
    ]
    OUT.mkdir()
    (OUT / "TMP").mkdir()
    resources = lc.process.CycleResources(
        {
            "host_ram_reserve": limits["host_reserve_B"],
            "max_memory_bytes": limits["family_B"] - limits["controller_B"],
            "max_output_bytes": None,
        },
        OUT,
        None,
    )
    checks, primary, secondary, cleanup = [], None, [], []
    started = lc.stamp()
    clock = lc.time.monotonic()
    try:
        os.sched_setaffinity(0, available)
        lc.command(spec, {"name": "format-intake", "role": "software", "argv": [str(Path(sys.prefix) / "bin/ruff"), "format", "--config", str(MAIN / "pyproject.toml"), str(OWN / "scout.py")]}, OUT, resources, ledger=checks)
        refs.append(ref(OWN / "scout.py"))
        os.sched_setaffinity(0, available)

        refs.append(ref(OWN / "scout.py"))
        os.sched_setaffinity(0, available)
        lc.physical_and_quiet(spec)
        lc.command(
            spec,
            {
                "name": "config-scout",
                "role": "software",
                "argv": [
                    "/bin/bash",
                    str(MAIN / "scripts/dev/project-env.sh"),
                    "python",
                    "-B",
                    str(OWN / "scout.py"),
                ],
            },
            OUT,
            resources,
            ledger=checks,
        )
    except BaseException as error:
        primary = lc.error_fact(error)
    try:
        returned = checks[0]["guardian_return"]
        persisted = checks[0]["persisted_process_receipt"]
        child = (
            returned["child"]
            if returned is not None
            else lc.document(persisted)["child"]
        )
        proc = Path("/proc") / str(child["pid"]) / "stat"
        current = (
            None
            if not proc.exists()
            else {
                "pid": child["pid"],
                "start_ticks": proc.read_text().rsplit(")", 1)[1].split()[19],
                "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
            }
        )
        lc.require(current != child, "original reader still present")
        for p in (OUT / "TMP").iterdir():
            before = p.lstat()
            lc.require(
                re.fullmatch(r"uv-[0-9a-f]+\.lock", p.name) is not None
                and stat.S_ISREG(before.st_mode)
                and before.st_size == 0
                and before.st_uid == os.getuid(),
                "unknown TMP subject",
            )
            openers = []
            for directory in Path("/proc").iterdir():
                if not directory.name.isdigit():
                    continue
                try:
                    for fd in (directory / "fd").iterdir():
                        try:
                            info = fd.stat()
                            if (info.st_dev, info.st_ino) == (
                                before.st_dev,
                                before.st_ino,
                            ):
                                openers.append(str(fd))
                        except OSError:
                            pass
                except OSError:
                    pass
            lc.require(not openers, "TMP lock still open")
            facts = {
                "ref_before": ref(p),
                "dev": before.st_dev,
                "ino": before.st_ino,
                "open_FDs": openers,
            }
            with p.open("r+b") as lock:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                actual = os.fstat(lock.fileno())
                lc.require(
                    (actual.st_dev, actual.st_ino, actual.st_size)
                    == (before.st_dev, before.st_ino, 0),
                    "TMP identity drift",
                )
                p.unlink()
            cleanup.append(facts)
        (OUT / "TMP").rmdir()
    except BaseException as error:
        secondary.append({"stage": "exact TMP cleanup", **lc.error_fact(error)})
    for binding in refs:
        try:
            lc.read_ref(binding, max(lc.CONTROL_BYTES, binding["bytes"]))
        except BaseException as error:
            secondary.append({"stage": "tool/helper/env after", **lc.error_fact(error)})
    reader_STOP = lc.stamp()
    wall = lc.time.monotonic() - clock
env_wrapper_return_observed = lc.stamp()
os.sched_setaffinity(0, available)
receipt = {
    "issue": "quoridor-4lc.402.2",
    "status": "FAILED" if primary or secondary else "PASS",
    "scope": "Named immutable saved inputs under common-environment reader; no canonical lease required",
    "storage_budget": None,
    "limits": limits,
    "available_affinity_before_after": available,
    "started_at": started,
    "reader_STOP": reader_STOP,
    "environment_reader_release_observed": env_wrapper_return_observed,
    "tool_helper_environment_refs_before_after": refs,
    "checks": checks,
    "primary": primary,
    "secondary": secondary,
    "exact_TMP_cleanup": cleanup,
    "controller_seconds_once": wall,
    "nested_wall_not_added": True,
    "source_TEMP": "No source TEMP or science entry; only saved metadata reader",
    "owned_readers_children_jobs_TMP_handles_leases_remaining": [
        str(p) for p in (OUT / "TMP", OWN / "source-TEMP") if p.exists()
    ],
    "canonical_lease_taken": False,
    "native_tests_geometry_Search_model_calls": 0,
    "native_child_UTC": "UNKNOWN; returned directwait and readerSTOP separately recorded",
    "continuous_peak": "UNKNOWN",
    "mixed_learner_323": "USERPAUSE",
}
lc.new_json(OUT / "receipt.json", receipt)
print(
    json.dumps(
        {
            "status": receipt["status"],
            "receipt": ref(OUT / "receipt.json"),
            "reader_STOP": reader_STOP,
        }
    )
)
if primary or secondary:
    raise SystemExit(1)
