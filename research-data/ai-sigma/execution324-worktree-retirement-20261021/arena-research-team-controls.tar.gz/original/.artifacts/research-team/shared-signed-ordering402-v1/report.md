# 共通signed ordering：新96探索・128局の設定準備

旧比較の名前付き設定だけを読み、新しいsubjectのreviewable draftを作成した。source/production/Main/Git/Cargoの変更、新しい探索・対局・モデル評価・native・test実行は0。旧400の結果、RAW、FAILED、費用、採否は変更せず、静的項だけの効果へ再解釈していない。

今回の到達仕様は、Control/Cheapの準備、combined key、TT-first、exact-firstからtail一度、LMR保護情報を同じ正本へ揃え、採点側のstatic整数項だけを分けるもの。新sourceと真正imageは探索作者とRootが所有し、この設定準備から実装成立・同work・性能・棋力を認定しない。

## 保存したdraft

|対象|私有出力|内容|
|---|---|---|
|探索sequence|cost96-settings-draft.json|既存sequence形式、16 operation、OFF→ON→ON→OFF|
|探索config|cost-configs/|NNUE4K / fixedD1M × Control/Cheap × OFF/ONの8設定|
|探索schedule|cost-requests.json|共通の既存6root/3session、同じwarm/reset順|
|探索Experiment案|cost-experiment-drafts/|16案、未生成Build/config実参照はnull|
|対局sequence|arena128-settings-draft.json|既存sequenceの8batch案|
|対局config|arena-config-drafts/|8対照、各16games|
|対局plan/schedule|arena-plan-draft.json / arena-schedule.json|同128slotのfamily・色・全history対応|
|対局Experiment案|arena-experiment-drafts/|8案、未生成Build/実config/数値対応はnull|
|移行対応|original-to-new.json|旧実config/Experimentから新draft・新ownerへの対応|
|結果表|result-table-draft.json|空の実結果欄と既存consumerから取得する列|
|未確定入力|pending-bindings.json|新image/Build/caller/実設定/Experiment/runtime等はnull|

draftにある自分のファイルは実際に作成したので実FileRefを保存した。一方、Root採用後のconfig/Experiment/sequence/runtime、image、Build、実guardは未生成であり、架空SHAやready admissionは作っていない。nullを含むdraftは提出・実行可能な入力ではない。コピーした旧env/limitsは設定案の出発点で、将来のcurrent environment/resource発行ではない。

新しい出力owner候補はshared-signed-ordering402-cost96-v1とshared-signed-ordering402-arena128-v1。旧lmr400の出力先を再使用しない。Root新namespaceやassets候補には書いていない。Rootは真正image/Buildとcurrentcallerをbindし、既存measurement/arena/sequence/collectorへそのまま接続する。新scheduler、別harness、registry、資格・承認frameworkは追加していない。

## 探索条件

同一新imageのNNUE BEST43/TT4096と固定D(0,8tanh)/TT1048576を別stratumにする。各Control/CheapでOFF→ON→ON→OFF。毎operationはcoldD4 family102、coldD6 family34、warmD4 family0 local0/2/4/6の6calls・3sessions。D4各2M/D6各8Mで18M/operation、全16operation＝96calls/48sessions/288M上限。

既存configのprofile、LMR、namespace基底、TT/PVS、root pointer/prefix/fullhistory指定をbyte内容として保持した。requestsも既存sourceとJSON完全一致し、time_limit_ms=null、diagnostic=false、observe_completed_depths=false、warmup=falseを保持する。warm-family0の4callsは同sessionのまま、新warmupやreset変更はない。

将来の表はControl/Cheapの絶対whole、setup/drop、nodes/evals、選択的nominal depth、LMR確認・全window・PVS・TTと各rootのstop/合法/history/parent対応を分ける。static/LMR間のvalue/action/PV/work差は観測対象で、旧同work採否規則を流用しない。旧比較との別時刻比から共通化の因果speedupを認定しない。旧2件のD6 UNKNOWNを新結果へ移植せず、現在は全新operationがUNENTERED、実結果はnull。

## 対局条件

同じ8family（23/29/34/46/64/93/105/108、4/8/12/16各2）とseed40020261014、元の事前順・色順を保持。NNUE/D各々Control OFF対ON、Cheap OFF対ON、Control OFF対Cheap OFF、ON同士の4対照、各8family×2色＝128局/64pair。

全scheduleの128slotは元JSONと完全一致。configはrun_id/book表示ID・新output・未生成imageのnull以外を逆置換すると元configと完全一致した。bookの参照、opening ID/lineage/prefix/root_key/history、選択理由、model/evaluator、係数、LMR規則、TT、100ms authority receipt/5ms reserve/200ply、depth64/node safety1M、AI2/6/main4を変更していない。bookの旧由来・sealed/OPAQUE等の限界を解除・再資格化していない。

将来のW/D/L/UNKNOWN、8family pair scoreとnative保存bootstrap95%、accepted/fallback/error/forfeit/late/cancel、選択snapshotとterminal workは別欄。未開始、未完成、資源拒否、node limit、maxply、errorを勝敗や完成へ昇格しない。各対照が同familyを再使用する条件付き幅で、128独立標本・新book母集団・Elo/非劣性認定ではない。新bootstrapも旧RAW decodeも行っていない。failure/cancel/pauseでstage停止、skip/refill/replay無し。

## bind前に残る通常入力

Rootの402 source/software・真正image/Build、actual factory namespace/common-key identity、current caller、通常model/library/input correspondence、actual configs/Experiment/plan/sequence、numerical fields、supportとphysical/quiet/CPU/RAM/GPU/TMPの実guardが未確定。歴史の400 image66c0daac/Buildde4は旧参照としてのみ残す。新weightsやモデル変更はなく、モデルpayload/libraryの読取り・初期化・probeは0。

既存callerの出発点はimmutableGit2001f68に対応するLC whole-file SHA1b1a9445であり、旧9827body値と混同しない。使用するmaintained guardは同byteを確認し、Main/canonical EXNB leaseを取らず短命environment readerで実行した。Rootや相手の全完了・返答を準備入口の条件にはしていない。

## 検証と停止

限定した旧settings、Config、Experiment、request、plan/scheduleのFileRefをhash-size-mode beforeparse/afterで照合。新手書きhelperはproject Ruffで整形・syntaxlint、新JSONは2space整形・短いparserと対応算術だけで確認する。旧成功parser/suite/資格、モデル、旧400/374科学結果の再演は0。

実reader/writer STOP、返却guardianとpersisted maskの別参照、directwait/reap/handles、fresh exactidentity、TMP不在、owned[]、対象OWN usage一回はcompletion.jsonに保存する。storageNone、global actual/peakと将来の実quiet/RAM/科学結果はUNKNOWN。親採否・実入場・publicationはRootが所有する。混合・learner全source準備/全pipelineと323 USERPAUSE、oldfits96/defaults/models/seals、foreign devcontainer、393/398 rejectionと全旧RAW/FAILED/費/UNKNOWNを保持する。
