# 423.1 固定pilot設計・本比較規模の一度の解決方法

SAME Sol/max/Main/fullneverの実turnを確認済み。旧420/421を再開・取消せず、423.1本人private scopeだけで科学0の設計を固定しました。元32は費用・family/row密度のpilotであり、必要データ量や四fit/160局の判別力の根拠ではありません。

元32四slice各60kは保持。256requests/Sigma2Mの全体上限内で、実pilotのT/V family・選択row・distinct入力・stock分布・forward/bytesからsuffix規模を一度だけ解決します。coverage目安はT128/V32/選択T4096/distinct2048（効果保証ではない）。理想pilot25T/7V/R=D800ならN_data164の例ですが、これは実入場件数ではありません。実pilotがない現在final_scale_fixed=false。32だけで四fit/160へ自動接続せず、費用/容量が不足すれば具体不足とPILOT_ONLYを保持し、Max/324の同依頼内で一度の実規模判断を行います。

対局配分を結果前に固定：主要W/BEST43 最大64family/128games、W/Dは同じ先頭16family/32games。計160のまま。R/U,W/U,W/Fの直接棋力比較は外し、各curveは残します。worstSD=.5のnormal設計近似は64familyでも95%半幅12.25pt、80%差目安17.5pt。5pt差に十分という主張はできません。旧412実SDからの参考値も別分布として明記、bootstrap再演/旧sample合算0です。

U/R/WはS=min(8R,32768)、同実tail batch/updates/LR1e-4。FはS_F=min(64R,524288)、LR1e-3/20までwarmupの一条件（scratch妥当性は未確認）。newV selector最大4点、frozenBEST full publicV一度。独立上界3,381,560logicalNNUErows<4M、実INITIAL共有ならさらに少なく、未使用を追加fitへ回しません。固定seed群はspec.json。元public番号は世代/弱さではありません。

old-qは保存383のgame/stock層でchronological最初という規則から28状態/12games（層1/11/12/4）を固定し32へ補充しません。全prefix hashは元保存値と一致。新rules replay0、実native from_prefixは通常admission。422七状態はdirect staticでMCTS qではなく、source CLOSEDから数値成功を推定しません。

現役inletの必要差分を実Git bbfba2cc断片へ束縛：MCTS実row-budget接続（現logical_row_limitはstatic専用）、既存full-prefix/q/codec、R compact-provenance sampler、真のtail batch/newV-only selector/publicBEST一度、同正規化F fresh-init admission。新エンジン/encoder/registry/学習済みpayload再decodeなし。source作者への通常具体化に使い、software PASS/independent sourceclear/strength grantとはしません。

actual selected readerSTOP 2026-10-16T01:34:05.005648Z、directreap .008569Z。元guard/proc raceのID/reap UNKNOWNは保持、捕捉済み二失敗は非0のままdirectreap/handles/freshabsence保持。全既知85identitiesはfreeze時freshabsent/different。以後formatter/adminは別receipt、TMP/job/lease/reader残存なし。one directed OWN usageは同directory/usage.json、後続軽adminのtailsはそのsnapshot外。

423.1はoriginal assignee/in_progressのまま、実pilot small summary（specの列）による一度の規模解決→本比較の保存分析を待ちます。人間/Root ACK、421/422/423親closeはgateにしません。Main/Git/Cargo/実科学は324のみ。普通の依存成果物が揃えばsource/software/pilotを進めてください。

固定completion FileRef:

```json
{
  "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/completion.json",
  "sha256": "71c2689c4c10b3ec93f642d664ca2e2e05f54dabf8adcfc3f9060a1961285687",
  "bytes": 7126,
  "mode": "0644"
}
```

固定7成果のFileRefs:

```json
[
  {
    "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/spec.json",
    "sha256": "c919d92bea060ebb73d205801581f34a4751b5b33bf9decf72c2aa25ee65e359",
    "bytes": 17309,
    "mode": "0644"
  },
  {
    "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/spec-ja.md",
    "sha256": "f00f2233cb2bb20566c6086cf4f76ad0379aa67318b3a66a2a0deef8f5bf925d",
    "bytes": 11821,
    "mode": "0644"
  },
  {
    "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/design-arithmetic.json",
    "sha256": "9eb87ccdc2c785d3a6982747291a491d1f8a1879c2415334bc94ac80e211d6f9",
    "bytes": 4821,
    "mode": "0644"
  },
  {
    "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/old-q-inputs.json",
    "sha256": "ddedbafc7606235238ce4cea7c7ae535ba43358ab7cc1cdc0161cc6054924794",
    "bytes": 75239,
    "mode": "0644"
  },
  {
    "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/control.json",
    "sha256": "d805f85e0c5da238717bcde7f217ceb701e6b17601b32c304bcac43b05ac759f",
    "bytes": 1883,
    "mode": "0644"
  },
  {
    "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/readerSTOP.json",
    "sha256": "4cafa68618b9fda6a6303160e7894c8a1125ea86619c1c173d4fea6988261b8a",
    "bytes": 37121,
    "mode": "0644"
  },
  {
    "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/verification.json",
    "sha256": "b695cf3ef7219576067f25f6aeb07587b43ce90e7a0b82d9823c4c4c073f9411",
    "bytes": 4078,
    "mode": "0644"
  }
]
```

補足：accepted423.3 native-source-v2のcanonical全family ranking事実はspecのsplit方針と一致。元pilot RAW/split/cacheを変更せず、最終combinedbookのfit-view assignmentを元game/family IDへ対応させ通常prepared/converter metadataに束縛します。元spec/STOP/completionは不変、今回metadata読取は別receiptに保持。補足FileRef:

```json
{
  "path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/split-correspondence.json",
  "sha256": "fac3fd19b549da176e3093bd5dc8f06c6b7dd1a6958fdb4363b4560e878c4bab",
  "bytes": 2124,
  "mode": "0644"
}
```
