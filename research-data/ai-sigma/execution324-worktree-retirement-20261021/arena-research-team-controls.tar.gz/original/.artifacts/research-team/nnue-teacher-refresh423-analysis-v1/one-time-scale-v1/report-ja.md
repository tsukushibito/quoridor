423の本比較を合計256 generation requests（原pilot32を再用し、真正未入場のID32..255の224件だけ継続）で一度固定する。これは効果量から算出した必要標本数ではない。元spec c919d92bと規模訂正を保持し、実変換密度・実推論費・保存量から、許可枠内で解釈できる有限比較を選んだ。本人による生成・forward・fit・Search・対局の入場は0。423.1は後の保存分析までin_progressを維持する。

| 項目                                 |            原pilot実績 |         合計256件の計画・密度シナリオ |
| ------------------------------------ | ---------------------: | ------------------------------------: |
| generation requests                  |             32、全GOAL |         256、成功や完了の保証ではない |
| canonical family T/V                 |                 25 / 7 |           固定入力partitionは204 / 52 |
| 適格T / V行                          |             1289 / 415 |            約10518 / 3083行、外挿のみ |
| 選択T行 / distinct入力               |              460 / 460 | 約3754行、distinctは実変換までUNKNOWN |
| 選択T、残壁16..20 / 8..15 / 1..7 / 0 |    43 / 140 / 200 / 77 |         同じ層別cap、空層を補充しない |
| Sigma論理・物理・実行行              | 各95544、warm/failed 0 |       下記の固定上限と実counterで管理 |

選択Tの実密度は25T系列あたり460行、1系列18.4行で、旧例示800行の57.5%だった。既定coverage式の各項はT系列163.84件、V系列約146.29件、選択T約284.94件、distinct約142.47件となり、4件単位のN_dataは288件となる。256上限では選択T4096行の目安を約342行下回る見込みだが、204T/52Vという系列の広がりと数千の入力で、Wの有限な追加学習の問いは扱えると判断した。256は単に上限だから使う数字ではなく、このcoverage式を推論費・保存量・許可件数で制約した結果である。実際の入力重複や未完了は外挿で消さない。

旧8game/217T/76Vの反復過多から大きく離れる一方、数千状態で十分な効果が出る公式も保証もない。Wでは「凍結BEST43から、この多系列・限定露出の手順で有限な改善が観測されるか」を見る。Fは新規重みからの小規模な学習の探索であり、不改善やINITIAL選択を、教師無効・新規初期化不可能・旧重みの優劣へ変換しない。Fには同じ入力正規化を引き継ぎ、LR・更新数・露出もWと違うため、初期化だけの因果比較ではない。

suffixは既存controllerで8件×28操作とし、各操作60,000 Sigma行を維持する。各操作のID区間はresolution.jsonに固定済みで、原32の再演・未完了の補充・余った操作枠の貸借を行わない。64 completed simulations/move、temp0、200ply、同じSigmaモデル/factory/codecを維持する。suffix seedは元specの42320261104、global IDとの対応は既存nativeの正本に従う。実並列幅1..4はRootが実入場のphysical/RAM条件で決め、幅比較はしない。

原4sliceの実Sigma行は24545 / 23819 / 25731 / 21449。最重sliceの1件3216.375行に25%を載せると、suffixは900585行、pilotと旧q・境界確認予約10000を含め1006129行と見積もる。固定capの和でも95544 + 28×60000 + 10000 = **1785544行 <= 2M**であり、残214456行を追加対局や補充へ自動配分しない。simulation数とforward行数、論理/物理/warm/failedは別に記録する。

固定済みprospective256 partitionは204T/52V・256別familyである。原pilotとのprefix/familyは同一で、ID18（fixed-d-family-000018）だけpilot Vから最終fit-view Tへ変わる。原RAW・pilot split・cacheを上書きしない。既存canonical ownerと元fac3fd19の対応方針で、最終schedule、global game ID、実row game code、最終fit-view割当を結ぶ。slice側の原split provenanceと最終fit-viewは別に残す。欠測を理由に成功分だけを再rankしたり、結果を見て分割し直したりしない。

この一度のsuffix停止後、実R/distinct/T/V/層/prefix長・forward算術を凍結する。今回の主比較を実施する実用上の最低coverageは適格T128系列、V32系列、distinct選択T2048と事前に定める。統計的十分性の基準ではない。大きく満たせなければPILOT_ONLYとして不足を返し、枠を使うためだけに四fitへ進めず、二度目の規模解決や補充をしない。選択T4096は目標であり、3754見込みを保証値や隠れた必須条件にはしない。

四fitの条件は元specどおり。U/R/Wは同じ実RからS=min(8R,32768)、batch256・端数そのまま、同じBEST43/fresh Adam/LR1e-4/warmupを使う。Rだけ全43公開源のrow weightを0.92^(43-i)へ変え、古い世代が弱いとは仮定しない。Wは新Sigma zのみ、Fは同じ新TのS_F=min(64R,524288)、fresh初期化/LR1e-3とする。W/Fの同じshuffled row stream、実各行露出を残す。例としてR=3754ならU/R/Wは30032行・118更新・最終batch80、Fは240256行・939更新・最終batch128となるが、これは実設定を先取りする数字ではない。

204T/52Vの全入力が完了する場合でも、選択T最大6528、V最大10400行である。四fit訓練516096 + 最大16観測×25120 + 四つのBEST公開V1676600 + changed-weight対応1024 = **2595640 logical NNUE rows <= 4M**。INITIAL共有を仮定しない上界である。curveは最大4点/条件、全newT/newVと公開T8192、full public V419150は各distinct frozen BESTに一度。421のC/Uや存在しないINITIALの成功観測を代用しない。qは保存説明のみで、fit教師はzだけ。Search/arenaのnode仕事は別枠として残す。

対局配分も元specどおり、主要W対BEST43は先頭64 canonical開始family×二色=128games、副次W対Dはそのうち先頭16family×二色=32gamesとする。合計160上限・1G nodes、同じ開始familyの依存とUNKNOWNを保持する。U/R/Fの直接棋力比較はこの配分にはない。64familyでも範囲[0,1]からの正規近似による95%半幅は最大約12.25pt、80%検出差の粗い目安は約17.5ptで、小改善を保証できない。保存412の98familyの分散0.13749/0.06956を便宜上移すと半幅約9.08/6.46ptになるが、別条件の分散が今回へ移る資格はなく、planning情報に限る。新bootstrap、旧結果とのpool、Eloや正式優越の主張はしない。

保存量は原conversionの四つの指定science rootだけの実allocated 3477504Bを使った。suffixの生成・変換増分を同密度×1.25で30428160B、四fit/model/curve/controlを32MiB、arena保存物を48MiB、serial TMP等を8MiBと置くと、合計forecastは**126180352B、既存128MiBの内側に8037376B**となる。arenaの参考は既に保存した196game原raw最大39308906Bを160gameへ比例させ25%を載せた約40.11MBで、48MiB allowance内である。これらは計画上の内訳であり、別の予算枠や実測peakではない。過去serial TMP peakはUNKNOWN、将来の実owner output forecastと既存whole guardを正本にし、出力capで部分停止し得る。128MiBで全完了を保証せず、旧RAWを削除して合わせない。

Rootの15:21:25 storage-support-applicationは重複coverだけを一度訂正し、covered49040753664B/headroom959246336B（以後small tails前）、421/423の既存supportを保持した。実使用量の減少・費用refund・旧512MiBの再適用は0、global actualはUNKNOWNのまま。この解決済みgapをPILOT_ONLY理由に使わない。今回も全target/assetの再計上やglobal inventoryを行っていない。

既知の原outerはpilot422.15621964397724sとconversion4.450889509986155sを各一度、合計426.6071091539634s。nested nativeを足さない。suffixの時間計画は最重の保存native sliceを基に約3927s（逐次換算）で、実並列・将来fit/arena全費用やkill期限ではない。source/LLM/admin等の全費用・continuous RSS peakはUNKNOWN、元FAILED/NULL-vs-disk masks/EIO/format拒否を保持する。

必要な小算術はchecks.jsonにPASS、手書きhelperはRuff整形・lint、文書/JSONは限定Prettierを行う。選択refのSHA-size-mode前後と最終安定確認、実reader/directwait-reap/handles/TMP/owned[]はSTOP/completionへ結ぶ。新しいsource・モデル・payload・RAW decode・forward・native/test/solver・bootstrapは0。Root324が普通のsource/software/実入力/資源条件で元suffixを実入場し、同じ423.1へ保存結果を戻す。人間/Root ACKや421/422親closeを入口にしない。
